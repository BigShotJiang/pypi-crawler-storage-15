"""WOF Explorer CLI scripts."""
