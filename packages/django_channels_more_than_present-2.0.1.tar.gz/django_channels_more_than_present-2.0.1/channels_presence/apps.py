from django.apps import AppConfig


class RoomsConfig(AppConfig):
    name = 'channels_presence'
    default_auto_field = 'django.db.models.BigAutoField'
