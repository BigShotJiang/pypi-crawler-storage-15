default_app_config = (
    "core_federated_search_app.apps.CoreFederatedSearchAppConfig"
)
