Waelstow
========
    [wel stoʊ]  / *noun*

    1) literal: "death field" or "slaugher field";
    2) Anglo Saxon term for battlefields
    3) A collection of Python testing utilities

Installation
============

.. code-block:: bash

    $ pip install waelstow

Supports
========

Tested with Python 3.10 - Python 3.14

Docs & Source
=============

Docs: http://waelstow.readthedocs.io/en/latest/

Source: https://github.com/cltrudeau/waelstow
