"""Init file for Celery models."""
