
<!-- markdownlint-disable-next-line MD041-->
*[API]: Application Programming Interface
*[CD]: Continuous Deployment
*[CI]: Continuous Integration
*[CLI]: Command Line Interface
*[ML]: Machine Learning
*[PR]: Pull Request
*[PRs]: Pull Requests
