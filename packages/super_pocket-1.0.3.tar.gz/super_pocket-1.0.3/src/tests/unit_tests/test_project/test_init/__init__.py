"""
Integration tests for project init feature.

This package contains comprehensive integration tests for the project
initialization feature, testing all 6 templates with various configurations.
"""
