"""Tests for README generator module."""
