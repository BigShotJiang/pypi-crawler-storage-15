"""Tests for project init module."""
