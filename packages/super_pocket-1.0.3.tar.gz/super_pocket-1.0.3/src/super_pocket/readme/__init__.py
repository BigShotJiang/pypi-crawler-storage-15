"""README generator for Super Pocket."""

__version__ = "0.1.0"
