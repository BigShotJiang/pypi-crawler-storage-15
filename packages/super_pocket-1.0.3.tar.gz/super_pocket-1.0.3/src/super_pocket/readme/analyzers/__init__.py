"""Project analyzers for different languages."""

from .python import PythonAnalyzer

__all__ = ["PythonAnalyzer"]
