from rapid_api_client import RapidApi


class BaseController(RapidApi):
    pass
