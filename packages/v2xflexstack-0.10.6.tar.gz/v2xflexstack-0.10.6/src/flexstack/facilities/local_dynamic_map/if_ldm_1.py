class InterfaceLDM1:
    """
    Class specified is described in TS 102 723-5.
    The IF.LDM.1 interface is responsible communication with the management layer.

    Attributes
    ----------
    TODO: Add attributes
    TODO: Finish once Managament Layer is implemented

    """
    def __init__(self) -> None:
        pass
