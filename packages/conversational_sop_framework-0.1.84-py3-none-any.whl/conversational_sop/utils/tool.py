import importlib
import logging
from typing import Dict, Any

from langchain_core.tools import tool
from pydantic import create_model, Field

logger = logging.getLogger()


TYPE_MAP = {
    "string": str,
    "number": float,
    "integer": int,
    "boolean": bool,
    "array": list,
    "object": dict
}


def json_schema_to_pydantic(schema: Dict[str, Any], model_name: str = "ToolInput"):
    if not schema or  not (properties := schema.get('properties')):
        return None
    
    required_fields = set(schema.get('required', []))
    field_definitions = {}
    
    for field_name, field_spec in properties.items():
        field_type_str = field_spec.get('type', 'string')
        field_desc = field_spec.get('description', '')
        
        python_type = TYPE_MAP.get(field_type_str, str)
        
        is_required = field_name in required_fields
        
        if is_required:
            field_definitions[field_name] = (python_type, Field(..., description=field_desc))
        else:
            field_definitions[field_name] = (python_type, Field(default=None, description=field_desc))
    
    return create_model(model_name, **field_definitions)


class ToolRepository:
    def __init__(self, tool_config):
        self._cache: Dict[str, Any] = {}
        self.tool_config = tool_config

    def load(self, tool_name):
        if tool_name in self._cache:
            logger.info(f"Tool '{tool_name}' found in cache")
            return self._cache[tool_name]

        tool_info = next((t for t in self.tool_config.get('tools') if t['name']==tool_name), None)
        if not tool_info:
            raise RuntimeError(f"Tool '{tool_name}' not found in tool config")

        tool_description = tool_info.get("description", "")
        function_path = tool_info.get("callable")
        input_schema = tool_info.get("input_schema")

        module_name, function_name = function_path.rsplit('.', 1)

        try:
            module = importlib.import_module(module_name)
        except ImportError as e:
            raise RuntimeError(f"Failed to import module '{module_name}': {e}")

        if not hasattr(module, function_name):
            raise RuntimeError(f"Module '{module_name}' has no function '{function_name}'")

        func = getattr(module, function_name)

        if not callable(func):
            raise RuntimeError(f"'{function_path}' is not callable (type: {type(func).__name__})")
        
        pydantic_model = json_schema_to_pydantic(
            input_schema, 
            f"{tool_name.title().replace('_', '')}Input"
        ) if input_schema else None

        self._cache[function_path] = (tool_name, tool_description, pydantic_model, func)
        logger.debug(f"Successfully loaded and cached function: {function_path}")
        return tool_name, tool_description, pydantic_model, func
