# coding: utf-8

"""
    API REST FactPulse

     API REST pour la facturation électronique en France : Factur-X, AFNOR PDP/PA, signatures électroniques.  ## 🎯 Fonctionnalités principales  ### 📄 Génération de factures Factur-X - **Formats** : XML seul ou PDF/A-3 avec XML embarqué - **Profils** : MINIMUM, BASIC, EN16931, EXTENDED - **Normes** : EN 16931 (directive UE 2014/55), ISO 19005-3 (PDF/A-3), CII (UN/CEFACT) - **🆕 Format simplifié** : Génération à partir de SIRET + auto-enrichissement (API Chorus Pro + Recherche Entreprises)  ### ✅ Validation et conformité - **Validation XML** : Schematron (45 à 210+ règles selon profil) - **Validation PDF** : PDF/A-3, métadonnées XMP Factur-X, signatures électroniques - **VeraPDF** : Validation stricte PDF/A (146+ règles ISO 19005-3) - **Traitement asynchrone** : Support Celery pour validations lourdes (VeraPDF)  ### 📡 Intégration AFNOR PDP/PA (XP Z12-013) - **Soumission de flux** : Envoi de factures vers Plateformes de Dématérialisation Partenaires - **Recherche de flux** : Consultation des factures soumises - **Téléchargement** : Récupération des PDF/A-3 avec XML - **Directory Service** : Recherche d'entreprises (SIREN/SIRET) - **Multi-client** : Support de plusieurs configs PDP par utilisateur (stored credentials ou zero-storage)  ### ✍️ Signature électronique PDF - **Standards** : PAdES-B-B, PAdES-B-T (horodatage RFC 3161), PAdES-B-LT (archivage long terme) - **Niveaux eIDAS** : SES (auto-signé), AdES (CA commerciale), QES (PSCO) - **Validation** : Vérification intégrité cryptographique et certificats - **Génération de certificats** : Certificats X.509 auto-signés pour tests  ### 🔄 Traitement asynchrone - **Celery** : Génération, validation et signature asynchrones - **Polling** : Suivi d'état via `/taches/{id_tache}/statut` - **Pas de timeout** : Idéal pour gros fichiers ou validations lourdes  ## 🔒 Authentification  Toutes les requêtes nécessitent un **token JWT** dans le header Authorization : ``` Authorization: Bearer YOUR_JWT_TOKEN ```  ### Comment obtenir un token JWT ?  #### 🔑 Méthode 1 : API `/api/token/` (Recommandée)  **URL :** `https://www.factpulse.fr/api/token/`  Cette méthode est **recommandée** pour l'intégration dans vos applications et workflows CI/CD.  **Prérequis :** Avoir défini un mot de passe sur votre compte  **Pour les utilisateurs inscrits via email/password :** - Vous avez déjà un mot de passe, utilisez-le directement  **Pour les utilisateurs inscrits via OAuth (Google/GitHub) :** - Vous devez d'abord définir un mot de passe sur : https://www.factpulse.fr/accounts/password/set/ - Une fois le mot de passe créé, vous pourrez utiliser l'API  **Exemple de requête :** ```bash curl -X POST https://www.factpulse.fr/api/token/ \\   -H \"Content-Type: application/json\" \\   -d '{     \"username\": \"votre_email@example.com\",     \"password\": \"votre_mot_de_passe\"   }' ```  **Paramètre optionnel `client_uid` :**  Pour sélectionner les credentials d'un client spécifique (PA/PDP, Chorus Pro, certificats de signature), ajoutez `client_uid` :  ```bash curl -X POST https://www.factpulse.fr/api/token/ \\   -H \"Content-Type: application/json\" \\   -d '{     \"username\": \"votre_email@example.com\",     \"password\": \"votre_mot_de_passe\",     \"client_uid\": \"550e8400-e29b-41d4-a716-446655440000\"   }' ```  Le `client_uid` sera inclus dans le JWT et permettra à l'API d'utiliser automatiquement : - Les credentials AFNOR/PDP configurés pour ce client - Les credentials Chorus Pro configurés pour ce client - Les certificats de signature électronique configurés pour ce client  **Réponse :** ```json {   \"access\": \"eyJ0eXAiOiJKV1QiLCJhbGc...\",  // Token d'accès (validité: 30 min)   \"refresh\": \"eyJ0eXAiOiJKV1QiLCJhbGc...\"  // Token de rafraîchissement (validité: 7 jours) } ```  **Avantages :** - ✅ Automatisation complète (CI/CD, scripts) - ✅ Gestion programmatique des tokens - ✅ Support du refresh token pour renouveler automatiquement l'accès - ✅ Intégration facile dans n'importe quel langage/outil  #### 🖥️ Méthode 2 : Génération via Dashboard (Alternative)  **URL :** https://www.factpulse.fr/dashboard/  Cette méthode convient pour des tests rapides ou une utilisation occasionnelle via l'interface graphique.  **Fonctionnement :** - Connectez-vous au dashboard - Utilisez les boutons \"Generate Test Token\" ou \"Generate Production Token\" - Fonctionne pour **tous** les utilisateurs (OAuth et email/password), sans nécessiter de mot de passe  **Types de tokens :** - **Token Test** : Validité 24h, quota 1000 appels/jour (gratuit) - **Token Production** : Validité 7 jours, quota selon votre forfait  **Avantages :** - ✅ Rapide pour tester l'API - ✅ Aucun mot de passe requis - ✅ Interface visuelle simple  **Inconvénients :** - ❌ Nécessite une action manuelle - ❌ Pas de refresh token - ❌ Moins adapté pour l'automatisation  ### 📚 Documentation complète  Pour plus d'informations sur l'authentification et l'utilisation de l'API : https://www.factpulse.fr/documentation-api/     

    The version of the OpenAPI document: 1.0.0
    Generated by OpenAPI Generator (https://openapi-generator.tech)

    Do not edit the class manually.
"""  # noqa: E501


from __future__ import annotations
import pprint
import re  # noqa: F401
import json

from pydantic import BaseModel, ConfigDict, Field, StrictBool, StrictStr
from typing import Any, ClassVar, Dict, List, Optional, Union
from typing_extensions import Annotated
from factpulse.models.champ_verifie_schema import ChampVerifieSchema
from factpulse.models.dimension_page_schema import DimensionPageSchema
from factpulse.models.note_obligatoire_schema import NoteObligatoireSchema
from typing import Optional, Set
from typing_extensions import Self

class ReponseVerificationSucces(BaseModel):
    """
    Réponse de vérification réussie avec données unifiées.
    """ # noqa: E501
    est_conforme: StrictBool = Field(description="True si aucun écart critique")
    score_conformite: Union[Annotated[float, Field(le=100.0, strict=True, ge=0.0)], Annotated[int, Field(le=100, strict=True, ge=0)]] = Field(description="Score de conformité (0-100%)")
    champs_verifies: Optional[Annotated[int, Field(strict=True, ge=0)]] = Field(default=0, description="Nombre de champs vérifiés")
    champs_conformes: Optional[Annotated[int, Field(strict=True, ge=0)]] = Field(default=0, description="Nombre de champs conformes")
    est_facturx: Optional[StrictBool] = Field(default=False, description="True si le PDF contient du XML Factur-X")
    profil_facturx: Optional[StrictStr] = None
    champs: Optional[List[ChampVerifieSchema]] = Field(default=None, description="Liste des champs vérifiés avec valeurs, statuts et coordonnées PDF")
    notes_obligatoires: Optional[List[NoteObligatoireSchema]] = Field(default=None, description="Notes obligatoires (PMT, PMD, AAB) avec localisation PDF")
    dimensions_pages: Optional[List[DimensionPageSchema]] = Field(default=None, description="Dimensions de chaque page du PDF (largeur, hauteur)")
    avertissements: Optional[List[StrictStr]] = Field(default=None, description="Avertissements non bloquants")
    __properties: ClassVar[List[str]] = ["est_conforme", "score_conformite", "champs_verifies", "champs_conformes", "est_facturx", "profil_facturx", "champs", "notes_obligatoires", "dimensions_pages", "avertissements"]

    model_config = ConfigDict(
        populate_by_name=True,
        validate_assignment=True,
        protected_namespaces=(),
    )


    def to_str(self) -> str:
        """Returns the string representation of the model using alias"""
        return pprint.pformat(self.model_dump(by_alias=True))

    def to_json(self) -> str:
        """Returns the JSON representation of the model using alias"""
        # TODO: pydantic v2: use .model_dump_json(by_alias=True, exclude_unset=True) instead
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, json_str: str) -> Optional[Self]:
        """Create an instance of ReponseVerificationSucces from a JSON string"""
        return cls.from_dict(json.loads(json_str))

    def to_dict(self) -> Dict[str, Any]:
        """Return the dictionary representation of the model using alias.

        This has the following differences from calling pydantic's
        `self.model_dump(by_alias=True)`:

        * `None` is only added to the output dict for nullable fields that
          were set at model initialization. Other fields with value `None`
          are ignored.
        """
        excluded_fields: Set[str] = set([
        ])

        _dict = self.model_dump(
            by_alias=True,
            exclude=excluded_fields,
            exclude_none=True,
        )
        # override the default output from pydantic by calling `to_dict()` of each item in champs (list)
        _items = []
        if self.champs:
            for _item_champs in self.champs:
                if _item_champs:
                    _items.append(_item_champs.to_dict())
            _dict['champs'] = _items
        # override the default output from pydantic by calling `to_dict()` of each item in notes_obligatoires (list)
        _items = []
        if self.notes_obligatoires:
            for _item_notes_obligatoires in self.notes_obligatoires:
                if _item_notes_obligatoires:
                    _items.append(_item_notes_obligatoires.to_dict())
            _dict['notes_obligatoires'] = _items
        # override the default output from pydantic by calling `to_dict()` of each item in dimensions_pages (list)
        _items = []
        if self.dimensions_pages:
            for _item_dimensions_pages in self.dimensions_pages:
                if _item_dimensions_pages:
                    _items.append(_item_dimensions_pages.to_dict())
            _dict['dimensions_pages'] = _items
        # set to None if profil_facturx (nullable) is None
        # and model_fields_set contains the field
        if self.profil_facturx is None and "profil_facturx" in self.model_fields_set:
            _dict['profil_facturx'] = None

        return _dict

    @classmethod
    def from_dict(cls, obj: Optional[Dict[str, Any]]) -> Optional[Self]:
        """Create an instance of ReponseVerificationSucces from a dict"""
        if obj is None:
            return None

        if not isinstance(obj, dict):
            return cls.model_validate(obj)

        _obj = cls.model_validate({
            "est_conforme": obj.get("est_conforme"),
            "score_conformite": obj.get("score_conformite"),
            "champs_verifies": obj.get("champs_verifies") if obj.get("champs_verifies") is not None else 0,
            "champs_conformes": obj.get("champs_conformes") if obj.get("champs_conformes") is not None else 0,
            "est_facturx": obj.get("est_facturx") if obj.get("est_facturx") is not None else False,
            "profil_facturx": obj.get("profil_facturx"),
            "champs": [ChampVerifieSchema.from_dict(_item) for _item in obj["champs"]] if obj.get("champs") is not None else None,
            "notes_obligatoires": [NoteObligatoireSchema.from_dict(_item) for _item in obj["notes_obligatoires"]] if obj.get("notes_obligatoires") is not None else None,
            "dimensions_pages": [DimensionPageSchema.from_dict(_item) for _item in obj["dimensions_pages"]] if obj.get("dimensions_pages") is not None else None,
            "avertissements": obj.get("avertissements")
        })
        return _obj


