from symai import shell

shell.run()
