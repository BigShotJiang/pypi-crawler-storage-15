__all__ = ["UserWebsocket"]


class UserWebsocket:
    """Пользовательский вебсокет Okx."""

    pass
