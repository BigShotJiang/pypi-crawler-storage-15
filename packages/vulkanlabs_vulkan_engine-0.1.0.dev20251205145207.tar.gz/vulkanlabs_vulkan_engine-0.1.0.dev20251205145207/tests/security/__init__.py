"""Tests for security module"""
