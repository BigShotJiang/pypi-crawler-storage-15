"""Tests for encryption service."""

import base64
import os

import pytest
import vulkan_engine.security.encryption_service as enc_module
from vulkan_engine.security import (
    EncryptedData,
    EncryptionService,
    get_encryption_service,
)


class TestEncryptionService:
    @pytest.fixture
    def encryption_key(self):
        key = os.urandom(32)
        return base64.b64encode(key).decode("ascii")

    @pytest.fixture
    def service(self, encryption_key):
        return EncryptionService(key_b64=encryption_key)

    def test_encrypt_returns_encrypted_data(self, service):
        """Test encryption returns EncryptedData."""
        plaintext = "my-secret-password"
        encrypted = service.encrypt(plaintext)

        assert isinstance(encrypted, EncryptedData)
        assert encrypted.encrypted_value
        assert encrypted.nonce
        assert encrypted.tag
        assert encrypted.encryption_version == 1

    def test_decrypt_returns_plaintext(self, service):
        """Test decryption returns original plaintext."""
        plaintext = "my-secret-password"
        encrypted = service.encrypt(plaintext)

        decrypted = service.decrypt(
            encrypted.encrypted_value,
            encrypted.nonce,
            encrypted.tag,
            encrypted.encryption_version,
        )

        assert decrypted == plaintext

    def test_encrypt_different_nonce_each_time(self, service):
        """Test each encryption uses unique nonce."""
        plaintext = "my-secret-password"
        encrypted1 = service.encrypt(plaintext)
        encrypted2 = service.encrypt(plaintext)

        assert encrypted1.nonce != encrypted2.nonce
        assert encrypted1.encrypted_value != encrypted2.encrypted_value

    def test_decrypt_wrong_key_fails(self, encryption_key):
        """Test decryption with wrong key fails."""
        service1 = EncryptionService(key_b64=encryption_key)
        plaintext = "my-secret-password"
        encrypted = service1.encrypt(plaintext)

        different_key = base64.b64encode(os.urandom(32)).decode("ascii")
        service2 = EncryptionService(key_b64=different_key)

        with pytest.raises(ValueError, match="Decryption failed"):
            service2.decrypt(
                encrypted.encrypted_value,
                encrypted.nonce,
                encrypted.tag,
                encrypted.encryption_version,
            )

    def test_decrypt_tampered_ciphertext_fails(self, service):
        """Test tampering with ciphertext is detected."""
        plaintext = "my-secret-password"
        encrypted = service.encrypt(plaintext)

        tampered = base64.b64decode(encrypted.encrypted_value)
        tampered = bytes([b ^ 1 for b in tampered])
        tampered_b64 = base64.b64encode(tampered).decode("ascii")

        with pytest.raises(ValueError, match="Decryption failed"):
            service.decrypt(
                tampered_b64,
                encrypted.nonce,
                encrypted.tag,
                encrypted.encryption_version,
            )

    def test_invalid_key_length_raises_error(self):
        """Test invalid key length raises error."""
        invalid_key = base64.b64encode(os.urandom(16)).decode("ascii")

        with pytest.raises(ValueError, match="Key must be 32 bytes"):
            EncryptionService(key_b64=invalid_key)

    def test_empty_key_raises_error(self):
        """Test empty key raises error."""
        with pytest.raises(ValueError, match="Encryption key is required"):
            EncryptionService(key_b64="")


class TestGetEncryptionService:
    def test_get_encryption_service_creates_singleton(self, monkeypatch):
        """Test get_encryption_service returns singleton."""
        key = base64.b64encode(os.urandom(32)).decode("ascii")
        monkeypatch.setenv("CREDENTIAL_ENCRYPTION_KEY", key)

        enc_module._encryption_service = None

        service1 = get_encryption_service()
        service2 = get_encryption_service()

        assert service1 is service2

    def test_get_encryption_service_loads_from_env(self, monkeypatch):
        """Test service loads config from environment."""
        key = base64.b64encode(os.urandom(32)).decode("ascii")
        monkeypatch.setenv("CREDENTIAL_ENCRYPTION_KEY", key)

        enc_module._encryption_service = None

        service = get_encryption_service()

        assert len(service.key) == 32
