# slowql.formatters package
__all__ = ["console"]
