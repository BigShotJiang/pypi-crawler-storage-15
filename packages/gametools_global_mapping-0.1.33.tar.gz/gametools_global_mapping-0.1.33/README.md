A module that contains all mapping required by Game Tools 

https://www.npmjs.com/package/gametools-global-mapping
https://pypi.org/project/gametools-global-mapping/