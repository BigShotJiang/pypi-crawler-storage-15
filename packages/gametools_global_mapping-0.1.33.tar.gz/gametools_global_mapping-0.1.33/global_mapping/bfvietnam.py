MAP_LIST = [
    "CAMBODIAN INCURSION",
    "LANDING ZONE ALBANY",
    "OPERATION HASTINGS",
    "SAIGON 1968",
    "FALL OF LANG VEI",
    "OPERATION CEDAR FALLS",
    "OPERATION IRVING",
    "SIEGE OF KHE SAHN",
    "FALL OF SAIGON",
    "OPERATION FLAMING DART",
    "QUẢNG TRỊ",
    "THE IA DRANG VALLEY",
    "HO CHI MINH TRAIL",
    "OPERATION GAME WARDEN",
    "RECLAIMING HUE",
    "WAKE ISLAND",
]
MODE = {
    "conquest": "Conquest",
    "coop": "Co-op",
    "customcombat": "Custom Combat",
    "evolution": "Evolution",
}
SMALLMODE = {
    "conquest": "CQ",
    "coop": "COOP",
    "customcombat": "CC",
    "evolution": "EVOL",
}