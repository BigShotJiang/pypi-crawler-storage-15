from datasette import hookimpl, Response


@hookimpl
def register_routes(datasette):
    config = datasette.plugin_config("datasette-redirects") or {}

    routes = []

    for status_code_str, redirects in config.items():
        try:
            status_code = int(status_code_str)
        except ValueError:
            continue

        if not isinstance(redirects, dict):
            continue

        for source_path, destination in redirects.items():
            # Normalize source path - remove leading/trailing slashes
            source_path = source_path.strip("/")

            # Create route handler for this redirect
            def make_handler(dest, code):
                async def redirect_handler(request):
                    return Response.redirect(dest, status=code)

                return redirect_handler

            handler = make_handler(destination, status_code)

            # Create regex that matches both /path and /path/
            pattern = rf"^/{source_path}/?$"
            routes.append((pattern, handler))

    return routes
