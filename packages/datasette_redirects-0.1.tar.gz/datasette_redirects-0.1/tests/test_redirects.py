from datasette_test import Datasette
import pytest


@pytest.mark.asyncio
async def test_plugin_is_installed():
    datasette = Datasette(memory=True)
    response = await datasette.client.get("/-/plugins.json")
    assert response.status_code == 200
    installed_plugins = {p["name"] for p in response.json()}
    assert "datasette-redirects" in installed_plugins


@pytest.fixture
def datasette_with_redirects():
    return Datasette(
        memory=True,
        plugin_config={
            "datasette-redirects": {
                "301": {
                    "foo": "https://example.com/",
                    "old-page": "https://example.com/new-page",
                    "/with-slash": "https://example.com/slashed",
                },
                "302": {
                    "temp": "/somewhere-else",
                },
            }
        },
    )


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "path,expected_status,expected_location",
    [
        # 301 redirects
        ("/foo", 301, "https://example.com/"),
        ("/foo/", 301, "https://example.com/"),
        ("/old-page", 301, "https://example.com/new-page"),
        ("/old-page/", 301, "https://example.com/new-page"),
        # 302 redirects
        ("/temp", 302, "/somewhere-else"),
        ("/temp/", 302, "/somewhere-else"),
        # Leading slash in config should be normalized
        ("/with-slash", 301, "https://example.com/slashed"),
        ("/with-slash/", 301, "https://example.com/slashed"),
    ],
)
async def test_redirects(
    datasette_with_redirects, path, expected_status, expected_location
):
    response = await datasette_with_redirects.client.get(path, follow_redirects=False)
    assert response.status_code == expected_status
    assert response.headers["location"] == expected_location


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "path",
    [
        "/unknown",
        "/bar",
        "/foobar",
        "/foo/extra",
    ],
)
async def test_no_redirect_for_unknown_paths(datasette_with_redirects, path):
    response = await datasette_with_redirects.client.get(path, follow_redirects=False)
    assert response.status_code == 404


@pytest.mark.asyncio
async def test_no_config():
    datasette = Datasette(memory=True)
    response = await datasette.client.get("/anything", follow_redirects=False)
    assert response.status_code == 404
