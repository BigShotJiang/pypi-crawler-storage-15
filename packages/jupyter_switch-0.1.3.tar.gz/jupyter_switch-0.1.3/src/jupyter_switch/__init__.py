"""
Jupyter Switch - Convert between Markdown and Jupyter Notebook formats
"""

from .switch_between_md_and_ipynb import main

__version__ = "0.1.0"
__all__ = ["main"]
