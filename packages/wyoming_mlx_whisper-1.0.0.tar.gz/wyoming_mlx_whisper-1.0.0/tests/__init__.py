"""Tests for wyoming-mlx-whisper."""
