import '@jupyterlab/logconsole';
import '@jupyterlab/console';
import '@jupyterlite/apputils';
