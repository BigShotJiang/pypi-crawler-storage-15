from setuptools import setup, find_packages

setup(
    name="mcmst_clust",
    version="1.0.3",
    description="Multi-Center Minimum Spanning Tree Clustering algorithm",
    author="Ali Şenol",
    author_email="alisenol@tarsus.edu.tr",
    url="https://github.com/senolali/MCMSTClustering",
    packages=find_packages(),
    install_requires=[
        "numpy",
        "scipy",
        "networkx",
    ],
    python_requires=">=3.7",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
)
