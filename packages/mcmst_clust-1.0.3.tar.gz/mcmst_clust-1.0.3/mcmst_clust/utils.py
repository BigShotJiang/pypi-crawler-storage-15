import numpy as np
from sklearn.preprocessing import MinMaxScaler

def normalize(X: np.ndarray) -> np.ndarray:
    """Min-max normalize features to [0,1] using sklearn's MinMaxScaler."""
    scaler = MinMaxScaler()
    return scaler.fit_transform(X)