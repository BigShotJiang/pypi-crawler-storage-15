# YouBikePython
YouBike API for python
# 安裝
從PyPI安裝：
```shell
pip install YouBikePython
```
如果上面的不行用，用這個：
```shell
pip install git+https://github.com/AvianJay/YouBikePython
```
# 使用
使用 `youbike -h` 來取得幫助。