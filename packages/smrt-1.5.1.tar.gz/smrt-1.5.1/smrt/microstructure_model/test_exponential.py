

from .exponential import Exponential


def test_constructor():

    exp = Exponential({'corr_length': 0.01, 'frac_volume': 0.3})



