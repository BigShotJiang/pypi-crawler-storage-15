

try:
    import numba

except ImportError:
    numba = None
