#define ANKERL_NANOBENCH_IMPLEMENT
#include <nanobench.h>
