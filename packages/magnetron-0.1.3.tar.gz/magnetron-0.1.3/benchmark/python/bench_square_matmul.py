# (c) 2025 Mario Sieg. <mario.sieg.64@gmail.com>

from bench import bench_square_matmul

bench_square_matmul(dim_lim=2048, step=256)
