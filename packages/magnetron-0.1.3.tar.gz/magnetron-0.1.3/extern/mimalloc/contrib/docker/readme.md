Various example docker files used for testing.

Usage:

```
> cd <host>
> docker build -t <host>-mimalloc .
> docker run -it <host>-mimalloc
>> make test
```
