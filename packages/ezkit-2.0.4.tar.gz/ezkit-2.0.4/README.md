# Python Easy Kit

Command:

```sh
# Install or Update
pip install -i https://pypi.org/simple --trusted-host pypi.org -U ezKit
```
