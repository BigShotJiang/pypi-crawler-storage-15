===============
Getting started
===============

TODO: Write about how to include Resolwe in a Django project and explain
settings parameters. Create an example Django project in the ``docs/example``
folder and give code references where a detailed explanation is needed.
