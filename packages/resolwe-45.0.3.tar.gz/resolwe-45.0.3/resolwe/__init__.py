""".. Ignore pydocstyle D400.

=======
Resolwe
=======

Open source enterprise dataflow engine in Django.

"""
