"""Workflow expression engine exceptions."""


class EvaluationError(Exception):
    """Raised for errors that occur during expression evaluation."""
