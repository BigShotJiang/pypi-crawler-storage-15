The build context should be base resolwe folder, two directories up.
Build example:

docker build -f Dockerfile.communication -t resolwe/com:python-3.9 ../../