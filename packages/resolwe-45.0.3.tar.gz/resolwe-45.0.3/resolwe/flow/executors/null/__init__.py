""".. Ignore pydocstyle D400.

==================
Null Flow Executor
==================

.. automodule:: resolwe.flow.executors.null.run

"""
