"""Custom exceptions."""


class SlugError(Exception):
    """Slug error."""
