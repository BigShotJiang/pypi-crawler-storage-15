""".. Ignore pydocstyle D400.

=========
Audit log
=========

Methods and helpers for logging access to endpoints that are based od Django
Rest Framework Viewsets.
"""
