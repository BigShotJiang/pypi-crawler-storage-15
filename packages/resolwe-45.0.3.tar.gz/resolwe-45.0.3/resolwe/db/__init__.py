"""Resolwe's database related functionalities."""
