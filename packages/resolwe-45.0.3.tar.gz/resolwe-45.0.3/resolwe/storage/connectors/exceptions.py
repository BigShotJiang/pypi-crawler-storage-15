"""Exceptions used in storage module."""


class DataTransferError(Exception):
    """Notify data transfer failure."""
