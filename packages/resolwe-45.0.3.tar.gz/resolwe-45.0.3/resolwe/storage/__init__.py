""".. Ignore pydocstyle D400.

=======
Storage
=======

"""
