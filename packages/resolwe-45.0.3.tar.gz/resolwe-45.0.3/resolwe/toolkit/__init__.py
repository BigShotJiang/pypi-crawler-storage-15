""".. Ignore pydocstyle D400.

===============
Resolwe Toolkit
===============

This module includes general processes, schemas, tools and docker image
definitions.

"""
