""".. Ignore pydocstyle D400.

====================
Observers Management
====================

.. automodule:: resolwe.observers.management.commands.register
    :members:

"""
