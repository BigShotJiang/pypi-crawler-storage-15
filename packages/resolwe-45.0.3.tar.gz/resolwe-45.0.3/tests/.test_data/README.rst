Resolwe doesn't create `data`, `upload` and `runtime` directories automatically
so they have to be commited into git.
