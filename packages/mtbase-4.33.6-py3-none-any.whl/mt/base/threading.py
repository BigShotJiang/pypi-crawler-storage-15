from threading import *
from mt.threading import *

# MT-TODO: make the module deprecated starting from v4.0.
