"""Useful functions dealing with paths.

2023/01/14
==========

Soon this module will be replaced by :module:`mt.path`.
"""

from mt.path import *
