"""Monkey-patching contextlib.

For python 3.6 or earlier, this module corresponds to :module:`contextlib2`. Otherwise, it
corresponds to :module:`contextlib`.
"""

from mt.ctx import *

# MT-TODO: make the module deprecated starting from v4.0.
