# https://pyrocko.org/grond - GPLv3
#
# The Grond Developers, 21st Century
from grond.setup_info import version as __version__  # noqa
