Example Grond W-Phase Inversion
===============================

For detailed instructions see the documentation https://pyrocko.org/grond/current.
