def main():
	print("Hello from rbac!")


if __name__ == "__main__":
	main()
