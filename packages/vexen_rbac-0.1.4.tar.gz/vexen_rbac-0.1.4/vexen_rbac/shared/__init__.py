"""Shared resources for vexen-rbac."""
