"""
SQLAlchemy 2.0 implementation for RBAC persistence layer.
"""
