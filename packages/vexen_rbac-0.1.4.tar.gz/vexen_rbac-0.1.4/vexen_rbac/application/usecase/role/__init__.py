"""
Role use cases.
"""

from .factory import RoleUseCaseFactory

__all__ = [
	"RoleUseCaseFactory",
]
