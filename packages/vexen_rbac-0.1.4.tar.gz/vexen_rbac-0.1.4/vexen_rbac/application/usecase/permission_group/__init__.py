"""
PermissionGroup use cases.
"""

from .factory import PermissionGroupUseCaseFactory

__all__ = [
	"PermissionGroupUseCaseFactory",
]
