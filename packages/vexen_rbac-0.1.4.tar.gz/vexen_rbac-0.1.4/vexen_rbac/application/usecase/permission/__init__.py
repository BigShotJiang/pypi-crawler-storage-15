"""
Permission use cases.
"""

from vexen_rbac.application.usecase.permission.factory import PermissionUseCaseFactory

__all__ = [
	"PermissionUseCaseFactory",
]
