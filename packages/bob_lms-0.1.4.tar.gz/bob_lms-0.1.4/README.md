# B.O.B — Library Manager CLI

A full-featured library management system running in your terminal.

## Install
pip install bob-lms

## Run
bob
