# collectiontools [![CI](https://github.com/tillahoffmann/collectiontools/actions/workflows/main.yml/badge.svg)](https://github.com/tillahoffmann/collectiontools/actions/workflows/main.yml) [![Documentation Status](https://readthedocs.org/projects/collectiontools/badge/?version=latest)](https://collectiontools.readthedocs.io/en/latest/?badge=latest)

This package implements functions to handle [`collections`](https://docs.python.org/3/library/collections.html) efficiently.
