<a id="{id}" class="docs-object-method">&nbsp;</a>
```python
{decorator}{name}{signature}: 
```
{description}{parameters}

{examples}