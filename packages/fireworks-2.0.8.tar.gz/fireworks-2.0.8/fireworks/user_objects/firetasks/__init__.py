"""Collection of built-in Firetasks for common workflows."""

__author__ = "ajain"
