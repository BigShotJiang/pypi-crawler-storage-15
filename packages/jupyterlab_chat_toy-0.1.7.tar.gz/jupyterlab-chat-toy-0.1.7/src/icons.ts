import { LabIcon } from '@jupyterlab/ui-components';

// 简单的聊天图标 SVG
const chatIconSvg = `
<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
</svg>
`;

export const chatIcon = new LabIcon({
  name: 'jupyterlab-chat:chat',
  svgstr: chatIconSvg
});