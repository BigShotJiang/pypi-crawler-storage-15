default_burnman_layer_params = {
    'material_source'     : None,
    'temperature_mode'    : 'adiabatic',
    'fixed_temperature'   : None,
    'top_temperature'     : None,
    'interp_lookup_method': 'mid',
    'slices'              : 50
    }
