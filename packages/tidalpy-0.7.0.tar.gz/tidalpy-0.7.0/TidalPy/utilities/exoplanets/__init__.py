from .data_download import get_exoplanet_data as get_exoplanet_data
