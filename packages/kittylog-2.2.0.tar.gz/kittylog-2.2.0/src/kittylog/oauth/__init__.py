"""OAuth authentication modules for kittylog."""
