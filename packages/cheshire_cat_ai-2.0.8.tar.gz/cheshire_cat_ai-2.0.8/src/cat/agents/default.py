from .base import BaseAgent

class DefaultAgent(BaseAgent):
    # just in case we need custom behaviour for the default agent
    pass