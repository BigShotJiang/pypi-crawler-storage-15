# How to write a plugin

Please refer to [this documentation](https://cheshire-cat-ai.github.io/docs/plugins/plugins/)

# Notes

- do not remove a plugin by just deleting the folder. Use the ui or the endpoint.
