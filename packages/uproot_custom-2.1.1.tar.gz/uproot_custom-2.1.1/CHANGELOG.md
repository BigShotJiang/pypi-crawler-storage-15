## v1.1.3

- Support optionally keep `TObject` data by specifying `item_path` in `TObjectReader`.
