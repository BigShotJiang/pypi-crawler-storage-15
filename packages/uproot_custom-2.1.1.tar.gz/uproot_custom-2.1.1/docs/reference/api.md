# API documentation

```{toctree}
---
maxdepth: 3
hidden: false
---
api/cpp-api
api/uproot-custom-ref
```
