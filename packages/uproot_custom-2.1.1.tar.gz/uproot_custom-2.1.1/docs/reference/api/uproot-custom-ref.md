# Module reference

This chapter documents the `uproot-custom` module, including both the Python factories and the C++ readers.

```{toctree}
---
maxdepth: 3
hidden: false
---
Python reference <uproot_custom>
C++ reference <cpp-module>
```
