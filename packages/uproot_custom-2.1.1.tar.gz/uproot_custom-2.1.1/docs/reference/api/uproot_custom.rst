uproot\_custom package
======================

Submodules
----------

uproot\_custom.AsCustom module
------------------------------

.. automodule:: uproot_custom.AsCustom
   :members:
   :show-inheritance:
   :undoc-members:

uproot\_custom.factories module
-------------------------------

.. automodule:: uproot_custom.factories
   :members:
   :show-inheritance:
   :undoc-members:

uproot\_custom.utils module
---------------------------

.. automodule:: uproot_custom.utils
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: uproot_custom
   :members:
   :show-inheritance:
   :undoc-members:
