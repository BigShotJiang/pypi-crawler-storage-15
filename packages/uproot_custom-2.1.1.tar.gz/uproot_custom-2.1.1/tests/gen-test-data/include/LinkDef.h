#ifdef __CLING__

// #  pragma link off all globals;
// #  pragma link off all classes;
// #  pragma link off all functions;

#    pragma link C++ class TOverrideStreamer - ;
#    pragma link C++ class TComplicatedSTL + ;
#    pragma link C++ class TSimpleObject + ;
#    pragma link C++ class TCStyleArray + ;
#    pragma link C++ class TRootObjects + ;
#    pragma link C++ class TBasicTypes + ;
#    pragma link C++ class TSTLArray + ;
#    pragma link C++ class TSTLMap + ;
#    pragma link C++ class TSTLSequence + ;
#    pragma link C++ class TSTLString + ;
#    pragma link C++ class TSTLSeqWithObj + ;
#    pragma link C++ class TSTLMapWithObj + ;
#    pragma link C++ class TNestedSTL + ;
#endif
