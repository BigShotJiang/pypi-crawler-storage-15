"""Entrypoint module, in case you use `python -m tess_downloader`."""

from .cli import main

if __name__ == "__main__":
    main()
