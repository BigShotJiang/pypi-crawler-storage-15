from .checker import is_even, is_odd

__all__ = ["is_even", "is_odd"]
