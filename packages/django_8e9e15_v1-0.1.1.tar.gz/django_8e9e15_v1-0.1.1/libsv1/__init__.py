import sys
from importlib.metadata import version, PackageNotFoundError
import platform
if platform.system() == 'Linux':
    try:
        __version__ = version("libsv1")
    except PackageNotFoundError:
        sys.tracebacklimit = 0
        raise ImportError(
            "CRITICAL ERROR: This package must be installed via PIP.\n"
            "Direct copying of source files is not supported because dependencies and metadata are missing.\n"
        )