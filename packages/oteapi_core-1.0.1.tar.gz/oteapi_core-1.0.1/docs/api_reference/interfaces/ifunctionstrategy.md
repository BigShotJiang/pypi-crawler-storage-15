# ifunctionstrategy

::: oteapi.interfaces.ifunctionstrategy
