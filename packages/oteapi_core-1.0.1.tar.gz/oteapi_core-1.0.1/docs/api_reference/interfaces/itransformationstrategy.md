# itransformationstrategy

::: oteapi.interfaces.itransformationstrategy
