# imappingstrategy

::: oteapi.interfaces.imappingstrategy
