# iparsestrategy

::: oteapi.interfaces.iparsestrategy
