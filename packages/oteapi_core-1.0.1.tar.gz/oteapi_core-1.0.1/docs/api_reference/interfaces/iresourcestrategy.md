# iresourcestrategy

::: oteapi.interfaces.iresourcestrategy
