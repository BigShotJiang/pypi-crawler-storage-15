# ifilterstrategy

::: oteapi.interfaces.ifilterstrategy
