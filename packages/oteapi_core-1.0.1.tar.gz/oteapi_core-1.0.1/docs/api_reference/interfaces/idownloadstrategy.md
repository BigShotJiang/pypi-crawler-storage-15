# idownloadstrategy

::: oteapi.interfaces.idownloadstrategy
