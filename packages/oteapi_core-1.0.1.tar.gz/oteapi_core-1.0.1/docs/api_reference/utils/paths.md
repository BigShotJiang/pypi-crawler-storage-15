# paths

::: oteapi.utils.paths
