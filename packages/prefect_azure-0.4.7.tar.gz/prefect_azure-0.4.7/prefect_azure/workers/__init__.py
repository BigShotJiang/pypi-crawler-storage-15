"""
Worker classes for Azure
"""
