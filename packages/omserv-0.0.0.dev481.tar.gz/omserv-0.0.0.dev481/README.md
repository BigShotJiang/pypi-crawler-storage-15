# Overview

Request serving code.

# Notable packages

- **[server](https://github.com/wrmsr/omlish/blob/master/omserv/server)** - Production web server based on
  [hypercorn](https://github.com/pgjones/hypercorn). Converted to anyio, but still being refined and integrated with the
  codebase.
