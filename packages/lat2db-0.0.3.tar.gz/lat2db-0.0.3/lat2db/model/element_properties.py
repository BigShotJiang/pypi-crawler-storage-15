from pydantic.dataclasses import dataclass
from .element import  Element

@dataclass
class ElementProperties(Element):
    pass