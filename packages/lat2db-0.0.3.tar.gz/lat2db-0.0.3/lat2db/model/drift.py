from lat2db.model.element import Element


class Drift(Element):
    #: should go to pyat calc info
    #: passmethod: Optional[str] = None
    pass
