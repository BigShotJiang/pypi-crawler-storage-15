from lat2db.model.element import Element


class BeamPositionMonitor(Element):
    pass
