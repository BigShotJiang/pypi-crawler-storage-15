from pydantic import BaseModel


class Monitor(BaseModel):
    pass
