from pydantic.dataclasses import dataclass


@dataclass
class GeometricInfo:
    is_ring: bool