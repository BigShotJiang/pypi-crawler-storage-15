from truss.base import truss_config

print(truss_config)
