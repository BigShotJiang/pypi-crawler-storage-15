These examples are used in the
[chains docs](https://docs.baseten.co/chains/overview). If code is changed
here, the docs might need to be update too.
