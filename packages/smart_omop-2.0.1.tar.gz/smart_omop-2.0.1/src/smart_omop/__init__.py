"""
smart-omop: OHDSI OMOP CDM Data Fetching for Healthcare AI

A production-grade Python package for fetching and managing OMOP Common Data Model
cohorts from OHDSI WebAPI instances. Supports cohort creation, generation,
characterization (Heracles), and results retrieval.

Author: Ankur Lohachab
Affiliation: Department of Advanced Computing Sciences, Maastricht University
License: MIT
"""

__version__ = "1.0.1"
__author__ = "Ankur Lohachab"
__affiliation__ = "Department of Advanced Computing Sciences, Maastricht University"

from smart_omop.client import OMOPClient
from smart_omop.cohort import CohortBuilder, CohortDefinition, Gender
from smart_omop.fetcher import (
    fetch_cohort_data,
    fetch_concept_sets,
    create_and_generate_cohort,
    poll_generation_status
)

# Full cohort building
from smart_omop.cohort_full import (
    CohortBuilderFull,
    ConceptSet,
    ConceptItem,
    CriteriaType,
    AgeOperator,
    InclusionRule,
    create_simple_cohort
)

# Heracles characterization
from smart_omop.heracles import (
    HeraclesJobConfig,
    HeraclesJobManager,
    HeraclesAnalysisBuilder,
    create_standard_job,
    DEFAULT_ANALYSES,
    DEMO_ANALYSES,
    CONDITION_ANALYSES,
    DRUG_ANALYSES,
    PROCEDURE_ANALYSES,
    MEASUREMENT_ANALYSES
)

# MedSynth integration
from smart_omop.medsynth_source import (
    MedSynthOMOPSource,
    load_from_medsynth_directory,
    generate_synthetic_omop
)

# Visualizations
from smart_omop.visualizations import (
    CohortVisualizer,
    create_cohort_visualizations
)

__all__ = [
    # Core client
    "OMOPClient",

    # Basic cohort building
    "CohortBuilder",
    "CohortDefinition",
    "Gender",

    # Full cohort building
    "CohortBuilderFull",
    "ConceptSet",
    "ConceptItem",
    "CriteriaType",
    "AgeOperator",
    "InclusionRule",
    "create_simple_cohort",

    # Fetchers
    "fetch_cohort_data",
    "fetch_concept_sets",
    "create_and_generate_cohort",
    "poll_generation_status",

    # Heracles
    "HeraclesJobConfig",
    "HeraclesJobManager",
    "HeraclesAnalysisBuilder",
    "create_standard_job",
    "DEFAULT_ANALYSES",
    "DEMO_ANALYSES",
    "CONDITION_ANALYSES",
    "DRUG_ANALYSES",
    "PROCEDURE_ANALYSES",
    "MEASUREMENT_ANALYSES",

    # MedSynth
    "MedSynthOMOPSource",
    "load_from_medsynth_directory",
    "generate_synthetic_omop",

    # Visualizations
    "CohortVisualizer",
    "create_cohort_visualizations"
]
