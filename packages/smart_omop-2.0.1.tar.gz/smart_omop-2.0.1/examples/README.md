# smart-omop Examples

This directory contains standalone example scripts demonstrating various features of the smart-omop package.

## Running Examples

Before running examples, update the configuration variables:
- `BASE_URL` - Replace with your OHDSI WebAPI URL
- `MEDSYNTH_DIR` - Replace with path to MedSynth output directory (for MedSynth example)
- Cohort IDs and source keys as needed

## Examples

### example_quickstart.py
Basic OMOPClient operations:
- List data sources
- Fetch cohort definitions
- Generate cohorts
- Retrieve results

```bash
python examples/example_quickstart.py
```

### example_simple_cohort.py
Simple cohort building using CohortBuilder:
- Condition-based cohort
- Age and gender filters
- Create cohort on WebAPI

```bash
python examples/example_simple_cohort.py
```

### example_circe_syntax.py
Complex cohort building with full CIRCE syntax:
- Multiple concept sets
- Primary criteria
- Observation windows
- Inclusion rules with demographics

```bash
python examples/example_circe_syntax.py
```

### example_heracles.py
Heracles characterization:
- Custom analysis sets
- Job configuration
- Job submission

```bash
python examples/example_heracles.py
```

### example_medsynth.py
MedSynth CSV data integration:
- Loading OMOP tables from CSV
- Filtering by condition and demographics
- Creating cohort summaries

```bash
python examples/example_medsynth.py
```

### example_visualizations.py
Interactive visualizations:
- Age pyramid by gender
- Condition prevalence treemap
- Cohort dashboard

```bash
python examples/example_visualizations.py
```

## Additional Examples

See also:
- `example.py` - Basic cohort operations
- `example_full.py` - Comprehensive feature demonstration
