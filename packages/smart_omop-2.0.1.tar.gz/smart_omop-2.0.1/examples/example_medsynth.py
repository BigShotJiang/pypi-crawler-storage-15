"""
MedSynth CSV Data Integration Example

Demonstrates using MedSynth-generated OMOP CSV data:
- Loading OMOP tables from CSV
- Filtering by condition and demographics
- Creating cohort summaries

Author: Ankur Lohachab
Department of Advanced Computing Sciences, Maastricht University
"""

from smart_omop import MedSynthOMOPSource, Gender

# Replace with your MedSynth output directory
MEDSYNTH_DIR = "/path/to/medsynth/output"

def main():
    try:
        source = MedSynthOMOPSource(MEDSYNTH_DIR)

        print(f"MedSynth source loaded")
        print(f"Directory: {MEDSYNTH_DIR}")
        print(f"Total persons: {source.get_person_count()}")

        # Filter by condition (COPD concept ID: 255573)
        persons = source.filter_by_condition([255573])
        print(f"\nCOPD patients: {len(persons)}")

        # Apply demographics filter
        filtered = source.filter_by_age_gender(
            persons,
            min_age=60,
            gender_concept_ids=[Gender.FEMALE.value]
        )
        print(f"COPD patients (female, 60+): {len(filtered)}")

        # Create cohort summary
        summary = source.create_cohort_summary(
            concept_ids=[255573],
            min_age=60,
            gender_concept_ids=[Gender.FEMALE.value]
        )

        print(f"\nCohort Summary:")
        print(f"  Person count: {summary['personCount']}")
        print(f"  Average age: {summary['demographics']['average_age']:.1f}")

    except Exception as e:
        print(f"Error: {e}")
        print("Note: This example requires MedSynth-generated OMOP CSV data")


if __name__ == "__main__":
    main()
