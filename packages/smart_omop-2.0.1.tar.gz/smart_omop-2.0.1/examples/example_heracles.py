"""
Heracles Characterization Example

Demonstrates creating and submitting Heracles characterization jobs:
- Building custom analysis sets
- Creating job configuration
- Submitting jobs with polling

Author: Ankur Lohachab
Department of Advanced Computing Sciences, Maastricht University
"""

from smart_omop import OMOPClient, HeraclesJobManager, HeraclesAnalysisBuilder

# Replace with your WebAPI URL
BASE_URL = "http://your-webapi:8080/WebAPI"

def main():
    with OMOPClient(BASE_URL) as client:
        mgr = HeraclesJobManager(client)

        # Build analysis set
        analyses = HeraclesAnalysisBuilder()
        analyses.add_demographics()
        analyses.add_conditions()
        analyses.add_drugs()

        # Create job
        job = mgr.create_job(
            cohort_ids=[1],
            source_key="MY_CDM",
            job_name="COPD_Characterization",
            analysis_ids=analyses.build(),
            small_cell_count=5
        )

        print(f"Job Name: {job.job_name}")
        print(f"Cohort IDs: {job.cohort_definition_ids}")
        print(f"Analysis IDs: {len(job.analysis_ids)}")
        print(f"Small Cell Count: {job.small_cell_count}")

        # Print job configuration
        import json
        print("\nJob Configuration:")
        print(json.dumps(job.to_dict(), indent=2))

        # Submit job (uncomment to actually submit)
        # result = mgr.submit_job(job, poll=True, timeout=1800)
        # print(f"\nJob completed: {result}")


if __name__ == "__main__":
    main()
