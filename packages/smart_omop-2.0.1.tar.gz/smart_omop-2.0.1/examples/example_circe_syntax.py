"""
Full CIRCE Syntax Example

Demonstrates creating complex cohorts with full CIRCE expression syntax:
- Multiple concept sets
- Primary criteria (condition, procedure, drug, measurement)
- Observation windows
- Inclusion rules with demographics

Author: Ankur Lohachab
Department of Advanced Computing Sciences, Maastricht University
"""

from smart_omop import CohortBuilderFull, Gender, AgeOperator, OMOPClient

# Replace with your WebAPI URL
BASE_URL = "http://your-webapi:8080/WebAPI"

def main():
    builder = CohortBuilderFull("Complex Cohort", "Multiple criteria")

    # Concept sets
    copd = builder.add_concept_set("COPD")
    copd.add_concept(255573, "Chronic obstructive lung disease", include_descendants=True)

    htn = builder.add_concept_set("Hypertension")
    htn.add_concept(316866, "Hypertensive disorder", include_descendants=True)

    # Primary criterion
    builder.add_primary_condition(concept_set_id=0)

    # Observation window
    builder.set_observation_window(prior_days=365, post_days=0)

    # Inclusion rules
    rule = builder.add_inclusion_rule("Demographics")
    rule.add_age_criterion(AgeOperator.GTE, 60)
    rule.add_age_criterion(AgeOperator.LTE, 85)
    rule.add_gender_criterion(Gender.FEMALE)

    cohort_def = builder.build()

    print(f"Cohort: {cohort_def['name']}")
    print(f"Concept Sets: {len(cohort_def['expression']['ConceptSets'])}")
    print(f"Inclusion Rules: {len(cohort_def['expression']['InclusionRules'])}")

    # Create on WebAPI
    with OMOPClient(BASE_URL) as client:
        created = client.create_cohort(cohort_def)
        print(f"\nCohort created with ID: {created['id']}")


if __name__ == "__main__":
    main()
