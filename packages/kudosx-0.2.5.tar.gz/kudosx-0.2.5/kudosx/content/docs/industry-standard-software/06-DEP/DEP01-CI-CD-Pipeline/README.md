# DEP01 - CI/CD Pipeline

Continuous Integration và Continuous Deployment.

## Best Practices

| # | Best Practice | Mô tả |
|---|---------------|-------|
| BP01 | [CI/CD Best Practices](DEP01-BP01-CI-CD-Best-Practices.md) | Build automation và deployment |

## Tham khảo

- GitHub Actions Documentation
- GitLab CI/CD
- Jenkins Best Practices
