# DEP02 - Containerization

Docker và Kubernetes best practices.

## Best Practices

| # | Best Practice | Mô tả |
|---|---------------|-------|
| BP01 | [Docker Best Practices](DEP02-BP01-Docker-Best-Practices.md) | Viết Dockerfile tối ưu |

## Tham khảo

- Docker Documentation
- Kubernetes Best Practices
- The Twelve-Factor App
