# IMP02 - Code Review

Quy trình review code hiệu quả.

## Best Practices

| # | Best Practice | Mô tả |
|---|---------------|-------|
| BP01 | [Code Review Process](IMP02-BP01-Code-Review-Process.md) | Quy trình và guidelines cho code review |

## Tham khảo

- Google Engineering Practices - Code Review
- SmartBear - Best Practices for Code Review
