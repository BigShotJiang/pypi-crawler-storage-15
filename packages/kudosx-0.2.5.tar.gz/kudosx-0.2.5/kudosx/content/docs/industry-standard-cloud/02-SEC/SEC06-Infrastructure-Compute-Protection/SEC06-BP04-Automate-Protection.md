# SEC06-BP04: Automate compute protection

## Description

Automated patching.

## Implementation Guidance

- Automated OS patching
- Immutable infrastructure
- Auto-scaling with latest AMIs
- Automated security updates
- Configuration management

## Risk Level

Medium - Manual patching lags behind threats.
