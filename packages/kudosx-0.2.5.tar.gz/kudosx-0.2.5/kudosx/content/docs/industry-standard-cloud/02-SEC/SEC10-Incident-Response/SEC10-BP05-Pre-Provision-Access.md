# SEC10-BP05: Pre-provision access

## Description

IR access ready.

## Implementation Guidance

- Break-glass accounts ready
- IR tooling pre-deployed
- Cross-account access configured
- Access testing verified
- Access documented

## Risk Level

Medium - Access delays slow response.
