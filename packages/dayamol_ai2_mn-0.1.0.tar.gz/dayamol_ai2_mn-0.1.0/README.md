# dayamol_ai2

A lightweight AI helper Python library with simple text utilities.

## Installation

```sh
pip install aimon
```
