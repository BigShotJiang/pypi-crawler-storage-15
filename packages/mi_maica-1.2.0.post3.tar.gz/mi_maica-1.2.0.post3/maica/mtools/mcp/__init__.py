
from .mcp_serp import asearch

__all__ = [
    'asearch',
]

from .mcp_serp import pkg_init_mcp_serp
def pkg_init_mcp():
    pkg_init_mcp_serp()