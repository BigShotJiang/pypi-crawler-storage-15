"""
As name suggested, this module is just a file-storage folder. Nothing special here.
For packing-up, you may have to manually create this folder to have MVista working.
"""