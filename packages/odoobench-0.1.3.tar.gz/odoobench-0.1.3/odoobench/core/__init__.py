"""Core backup and restore functionality"""

from .backup_restore import OdooBench

__all__ = ["OdooBench"]
