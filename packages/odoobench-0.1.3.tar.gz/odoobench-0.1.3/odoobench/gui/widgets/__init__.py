"""GUI widgets for OdooBench"""
