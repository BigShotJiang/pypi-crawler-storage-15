"""Utility functions for OdooBench"""
