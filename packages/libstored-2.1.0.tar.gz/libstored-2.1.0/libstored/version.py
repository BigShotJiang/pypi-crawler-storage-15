# SPDX-FileCopyrightText: 2020-2023 Jochem Rutgers
#
# SPDX-License-Identifier: MPL-2.0

__version__ = '2.1.0'
libstored_version = '2.1.0'

