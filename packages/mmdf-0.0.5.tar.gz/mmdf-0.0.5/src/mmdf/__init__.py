"""Macromolecular structures as pandas dataframes."""

from .functions import read, write

__all__ = ["read", "write"]
