"""Higher order application aware reusable components."""
