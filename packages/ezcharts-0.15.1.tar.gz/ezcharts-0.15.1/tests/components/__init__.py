"""Test report components."""
