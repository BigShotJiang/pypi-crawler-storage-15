from zoneinfo import ZoneInfo

from ._version import get_package_version

AOC_TZ = ZoneInfo("America/New_York")
VERSION = get_package_version()
