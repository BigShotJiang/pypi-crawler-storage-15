"""Maxim integration for Pydantic AI agent framework."""

from .client import instrument_pydantic_ai

__all__ = ["instrument_pydantic_ai"] 