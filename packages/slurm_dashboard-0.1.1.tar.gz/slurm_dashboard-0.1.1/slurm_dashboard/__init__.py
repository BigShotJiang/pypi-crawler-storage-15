"""Slurm Dashboard - A lightweight web dashboard for monitoring Slurm jobs."""

__version__ = "0.1.0"
