"""Route blueprints for the Slurm Dashboard."""
