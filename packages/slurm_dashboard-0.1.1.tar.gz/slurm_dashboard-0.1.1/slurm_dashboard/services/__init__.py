"""Service modules for Slurm and log file operations."""
