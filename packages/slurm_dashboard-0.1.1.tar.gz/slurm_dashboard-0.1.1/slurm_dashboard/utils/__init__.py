"""Utility functions for the Slurm Dashboard."""
