__version__ = "0.1.1"
__author__ = "Nilavo Boral"

from .manager import CloudAgentManager