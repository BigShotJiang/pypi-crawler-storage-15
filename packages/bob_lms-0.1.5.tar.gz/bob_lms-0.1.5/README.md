# B.O.B – Python CLI Library Management System (`bob-lms`)

[![PyPI version](https://img.shields.io/pypi/v/bob-lms)](https://pypi.org/project/bob-lms/)
[![Python Version](https://img.shields.io/badge/python-3.8%2B-blue)](https://www.python.org/)

**B.O.B** (short for *Books on Board*) is a Python-based Command-Line Interface (CLI) Library Management System designed for simplicity, flexibility, and efficiency. It allows users to manage books, track users, and maintain library operations directly from the terminal — ideal for personal, educational, or small-scale library setups.

Built with a focus on **modular architecture, clean code, and scalability**, B.O.B is perfect for developers looking to expand CLI tooling and for users who want a lightweight library system without heavy databases or GUIs.

---

## Table of Contents

1. [Features](#features)
2. [Installation](#installation)
3. [Usage](#usage)
4. [Project Structure](#project-structure)
5. [Configuration](#configuration)
6. [Development & Contribution](#development--contribution)
7. [Dependencies](#dependencies)
8. [License](#license)

---

## Features

* Full **CLI-based library management** — no GUI required
* User authentication and role-based access (Admin / Standard user)
* Add, edit, delete, and search books
* Track users and roles
* Persistent data storage with modular Python files
* Modular, maintainable code for easy extension

---

## Installation

### From PyPI

```bash
pip install bob-lms==<version-number>
```
---

## Usage

Run the CLI:

```bash
bob-lms
```
---

## Configuration

B.O.B stores persistent configuration data (users, roles, books) inside the package by default. Advanced configuration options, such as changing data paths or CLI behavior, can be managed via the `bob config` command.

---

## Dependencies

* [Python 3.8+](https://www.python.org/)

---

## License

This project is licensed under the **MIT License** – see [LICENSE](LICENSE) for details.

---

## Additional Notes

B.O.B is designed as a **lightweight, modular, production-ready CLI system**. You can extend it to integrate databases, web interfaces, or cloud storage. Ideal for Python enthusiasts looking to explore CLI-based software design.