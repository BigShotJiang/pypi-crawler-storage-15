NAME_TYPE_LAYER_COLOR = {
    'x_d' : (
}
