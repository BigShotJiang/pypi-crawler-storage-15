from behaverify.behaverify import main

main()
