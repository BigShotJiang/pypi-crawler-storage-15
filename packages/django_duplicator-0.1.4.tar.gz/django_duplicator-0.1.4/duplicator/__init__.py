from .admin import DuplicatorAdminMixin
from .models import DuplicatorMixin
