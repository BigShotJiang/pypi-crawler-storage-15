"""
Constants for core explore common app
"""

from django.conf import settings

LOCAL_QUERY_NAME = settings.CUSTOM_NAME
LOCAL_QUERY_URL = "core_explore_common_local_query"
