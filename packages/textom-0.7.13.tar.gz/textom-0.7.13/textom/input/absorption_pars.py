
mode = 'off' # 'SAXS', 'WAXS' or 'off

# absorption tomogram
# or
# density tomogram + average absorption coefficient