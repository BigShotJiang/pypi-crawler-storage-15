"""The package with utilities for multi-objective optimization."""
