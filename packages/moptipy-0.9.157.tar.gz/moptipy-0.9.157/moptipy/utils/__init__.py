"""Utilities used in other moptipy modules."""
