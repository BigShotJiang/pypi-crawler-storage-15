"""An internal file with the version of the `moptipy` package."""
from typing import Final

#: the version string of `moptipy`
__version__: Final[str] = "0.9.157"
