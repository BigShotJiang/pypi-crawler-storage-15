"""The single-objective optimization algorithms of the `moptipy` package."""
