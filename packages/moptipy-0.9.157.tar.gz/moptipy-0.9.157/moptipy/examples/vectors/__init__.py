"""Examples for continuous vector-based objective functions."""
