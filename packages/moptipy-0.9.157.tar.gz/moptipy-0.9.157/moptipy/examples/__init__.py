"""
A package with example problems and operators.

You can find many more applications and examples at in our `moptipyapps`
package building on `moptipy` at <https://thomasweise.github.io/moptipyapps>.
Here, we mainly include examples that are useful for verifying the algorithms
and modules implemented in `moptipy` and those useful for our "Optimization
Algorithms" book (see <https://thomasweise.github.io/oa>).
"""
