"""Test suite for exe-analyzer-mcp."""
