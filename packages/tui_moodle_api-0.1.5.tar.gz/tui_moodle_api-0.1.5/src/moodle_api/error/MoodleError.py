class MoodleError(Exception):
    pass
