from .MoodleError import MoodleError


class MoodleParseError(MoodleError):
    pass
