"""Fastpy CLI - Create production-ready FastAPI projects."""

__version__ = "1.1.2"
__author__ = "Vutia Enterprise"
__email__ = "hello@ve.ke"
