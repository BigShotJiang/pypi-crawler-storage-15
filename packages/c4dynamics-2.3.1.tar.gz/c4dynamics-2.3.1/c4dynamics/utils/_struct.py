# -*- coding: utf-8 -*-
# pragma: no cover


class struct: 
  def __init__(self, **kwargs): 
    self.__dict__.update(kwargs)

  def __iter__(self):
    return iter(self.__dict__.items())
