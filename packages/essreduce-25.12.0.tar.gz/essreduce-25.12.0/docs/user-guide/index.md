# User Guide

```{toctree}
---
maxdepth: 2
---

installation
tof/index
widget
reduction-workflow-guidelines
```
