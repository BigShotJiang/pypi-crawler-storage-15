import django_tables2 as tables


class DummyTable(tables.Table):
    export_filename = "dummytable"
