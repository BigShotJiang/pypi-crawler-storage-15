"""
Constants module for API URLs and configuration.
"""

from .urls import API_URLS

__all__ = ["API_URLS"]
