API_URLS={
    "HUBSPOT_CRM_OBJECTS_API_BASE_URL": "https://api.hubapi.com/crm/v3/objects",
    "HUBSPOT_CRM_API_BASE_URL": "https://api.hubapi.com/crm/v3",
    "HUBSPOT_API_BASE_URL": "https://api.hubapi.com"
}