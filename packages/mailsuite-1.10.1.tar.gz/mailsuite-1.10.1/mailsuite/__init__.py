"""A Python package to simplify receiving, parsing, and sending email"""

__version__ = "1.10.1"
