---
name: "\U0001F514 Feature Request"
about: Suggestions for how we can improve the algorand platform.
title: ""
labels: enhancement
assignees: ""
---

## Problem

<!-- What is the problem that we’re trying to solve? -->

## Solution

<!-- Do you have a potential/suggested solution? Document more than one if possible. -->

### Proposal

<!-- Describe the solution you’d like in detail. -->

### Pros and Cons

<!-- What are the advantages and disadvantages of this solution? -->

## Dependencies

<!-- Does the solution have any team or design dependencies? -->
