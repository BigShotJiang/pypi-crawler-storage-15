---
name: "\U0001F41C Bug report"
about: Report a reproducible bug.
title: ""
labels: bug
assignees: ""
---

### Subject of the issue

<!-- Describe your issue here. -->

### Your environment

<!--
* Please provide the version of the package used and output of `algokit doctor` command response,
* This will give us a good idea about your environment
-->

### Steps to reproduce

1.
2.

### Expected behaviour

### Actual behaviour
