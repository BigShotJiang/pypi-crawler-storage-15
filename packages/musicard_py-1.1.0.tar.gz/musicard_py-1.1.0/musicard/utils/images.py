import requests
from PIL import Image, ImageDraw, ImageFilter
from typing import Tuple
import io

def load_image(path_or_url: str) -> Image.Image:
    """Load an image from a local path or URL."""
    if path_or_url.startswith('http://') or path_or_url.startswith('https://'):
        response = requests.get(path_or_url)
        response.raise_for_status()
        return Image.open(io.BytesIO(response.content))
    else:
        return Image.open(path_or_url)

def resize_image(image: Image.Image, size: tuple[int, int]) -> Image.Image:
    """Resize an image to the given size."""
    return image.resize(size, Image.Resampling.LANCZOS)

def blur_image(image: Image.Image, radius: int = 5) -> Image.Image:
    """Apply Gaussian blur to an image."""
    return image.filter(ImageFilter.GaussianBlur(radius))

def create_gradient(size: tuple[int, int], start_color: tuple[int, int, int], end_color: tuple[int, int, int], direction: str = 'vertical') -> Image.Image:
    """Create a gradient image."""
    width, height = size
    gradient = Image.new('RGB', size)
    pixels = gradient.load()

    if direction == 'vertical':
        for y in range(height):
            r = int(start_color[0] + (end_color[0] - start_color[0]) * y / height)
            g = int(start_color[1] + (end_color[1] - start_color[1]) * y / height)
            b = int(start_color[2] + (end_color[2] - start_color[2]) * y / height)
            for x in range(width):
                pixels[x, y] = (r, g, b)
    elif direction == 'horizontal':
        for x in range(width):
            r = int(start_color[0] + (end_color[0] - start_color[0]) * x / width)
            g = int(start_color[1] + (end_color[1] - start_color[1]) * x / width)
            b = int(start_color[2] + (end_color[2] - start_color[2]) * x / width)
            for y in range(height):
                pixels[x, y] = (r, g, b)

    return gradient

def draw_rounded_rectangle(draw: ImageDraw.ImageDraw, xy: Tuple[int, int, int, int], radius: int, fill=None, outline=None, width=1):
    """Draw a rounded rectangle."""
    x1, y1, x2, y2 = xy
    draw.rectangle([x1 + radius, y1, x2 - radius, y2], fill=fill, outline=outline, width=width)
    draw.rectangle([x1, y1 + radius, x2, y2 - radius], fill=fill, outline=outline, width=width)
    draw.ellipse([x1, y1, x1 + 2*radius, y1 + 2*radius], fill=fill, outline=outline, width=width)
    draw.ellipse([x2 - 2*radius, y1, x2, y1 + 2*radius], fill=fill, outline=outline, width=width)
    draw.ellipse([x1, y2 - 2*radius, x1 + 2*radius, y2], fill=fill, outline=outline, width=width)
    draw.ellipse([x2 - 2*radius, y2 - 2*radius, x2, y2], fill=fill, outline=outline, width=width)