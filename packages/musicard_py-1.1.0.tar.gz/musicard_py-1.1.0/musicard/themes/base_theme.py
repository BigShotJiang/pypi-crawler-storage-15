from abc import ABC, abstractmethod
from PIL import Image, ImageDraw
from typing import Dict, Any

class BaseTheme(ABC):
    @abstractmethod
    def render(self, image: Image.Image, draw: ImageDraw.ImageDraw, metadata: Dict[str, Any]) -> None:
        """Render the theme on the image."""
        pass