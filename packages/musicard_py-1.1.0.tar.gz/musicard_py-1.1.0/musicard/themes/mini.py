from .base_theme import BaseTheme
from ..utils.images import load_image, resize_image
from ..utils.text import load_font, draw_text_with_shadow
from PIL import Image, ImageDraw
import math

class MiniTheme(BaseTheme):
    def render(self, image: Image.Image, draw: ImageDraw.ImageDraw, metadata: dict):
        title = metadata.get('title', 'Musicard')
        artist = metadata.get('artist', 'By Unburn')
        progress = metadata.get('progress', 0.0)
        thumbnail_url = metadata.get('thumbnail')
        background_color = metadata.get('background_color', '#070707')
        menu_color = metadata.get('menu_color', '#FF7A00')
        progress_color = metadata.get('progress_color', '#FF7A00')
        paused = metadata.get('paused', False)

        # Truncate
        if len(title) > 15:
            title = title[:15] + '...'
        if len(artist) > 15:
            artist = artist[:15] + '...'

        # Background
        draw.rectangle([(0, 0), (image.width, image.height)], fill=background_color)

        # Thumbnail on left
        if thumbnail_url:
            try:
                thumb = load_image(thumbnail_url)
                thumb = resize_image(thumb, (100, 100))
                image.paste(thumb, (10, 10))
            except:
                pass

        # Menu bar with rounded corners
        draw.rounded_rectangle([120, 10, 130, 110], radius=5, fill=menu_color)

        # Progress bar at bottom
        bar_width = image.width - 140
        bar_height = 10
        bar_x = 140
        bar_y = image.height - 20
        draw.rectangle([bar_x, bar_y, bar_x + bar_width, bar_y + bar_height], fill='#333333')
        progress_width = int(bar_width * progress)
        draw.rectangle([bar_x, bar_y, bar_x + progress_width, bar_y + bar_height], fill=progress_color)

        # Title and artist with shadows
        title_font = load_font('PlusJakartaSans-Bold.ttf', 24)
        draw_text_with_shadow(draw, title, title_font, '#FFFFFF', '#000000', (140, 20))

        artist_font = load_font('PlusJakartaSans-Regular.ttf', 18)
        draw_text_with_shadow(draw, artist, artist_font, '#CCCCCC', '#000000', (140, 50))

        # Paused indicator
        if paused:
            draw.text((140, 80), '⏸️', font=title_font, fill='#FFFFFF')