from enum import Enum


class BoilerplateOptions(str, Enum):
    basic = "basic"


class TrainingStatus(str, Enum):
    """Training job status enum."""

    PENDING = "pending"
    INITIALIZING = "initializing"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class SSEEventType(str, Enum):
    """Server-Sent Events event types for training streams."""

    STATUS = "status"
    METRICS = "metrics"
    HEARTBEAT = "heartbeat"
    ERROR = "error"
