from enum import Enum


class KonicCLIEnvVars(str, Enum):
    KONIC_HOST = "KONIC_HOST"
