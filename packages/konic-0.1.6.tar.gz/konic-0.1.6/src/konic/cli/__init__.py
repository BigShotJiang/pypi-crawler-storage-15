from konic.cli.root import app


def main():
    app()


__all__ = ["app", "main"]
