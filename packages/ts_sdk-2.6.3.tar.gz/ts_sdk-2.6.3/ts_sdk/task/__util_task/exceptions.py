class ContainerStoppedException(Exception):
    pass


class TaskUpdateConflictException(Exception):
    pass


class FailedPollTaskException(Exception):
    pass
