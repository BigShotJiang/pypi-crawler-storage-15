from abc import ABC, abstractmethod
from typing import Callable, Iterator, TypeVar, Union

A = TypeVar("A")
B = TypeVar("B")


class Result(ABC):
    @abstractmethod
    def match(
        self,
        ok: Callable[[object], A],
        err: Callable[[object], B],
    ) -> Union[A, B]: ...

    @abstractmethod
    def __iter__(self) -> Iterator[object]: ...


class Ok(Result):
    __match_args__ = ("value",)

    def __init__(self, value: object):
        self.value = value

    def match(
        self,
        ok: Callable[[object], A],
        err: Callable[[object], B],
    ) -> A:
        return ok(self.value)

    def __iter__(self) -> Iterator[object]:
        return iter((self.value, None))

    def __repr__(self):
        return f"Ok({self.value.__repr__()})"

    def __eq__(self, other):
        return isinstance(other, Ok) and other.value == self.value


class Err(Result):
    __match_args__ = ("error",)

    def __init__(self, error: object):
        self.error = error

    def match(
        self,
        ok: Callable[[object], A],
        err: Callable[[object], B],
    ) -> B:
        return err(self.error)

    def __iter__(self) -> Iterator[object]:
        return iter((None, self.error))

    def __repr__(self):
        return f"Err({self.error.__repr__()})"

    def __eq__(self, other):
        return isinstance(other, Err) and other.error == self.error
