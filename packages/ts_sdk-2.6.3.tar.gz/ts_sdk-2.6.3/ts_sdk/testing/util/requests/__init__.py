from . import responses
from .decorators import after, before, replacing
from .patch import patch_requests
