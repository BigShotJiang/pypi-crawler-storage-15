class SetupException(Exception):
    pass
