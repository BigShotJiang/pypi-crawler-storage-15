"""Algorithm tools support the development of algorithms for the vantage6 platform."""

# make sure the version is available
from vantage6.algorithm.client._version import __version__  # noqa: F401
