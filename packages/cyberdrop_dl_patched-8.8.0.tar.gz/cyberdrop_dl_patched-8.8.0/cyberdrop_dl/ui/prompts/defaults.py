from InquirerPy.base.control import Choice

EXIT_CHOICE = Choice("Exit")
DONE_CHOICE = Choice("Done")
ALL_CHOICE = Choice("All of the above")

DEFAULT_OPTIONS = {"long_instruction": "ARROW KEYS: Navigate | ENTER: Select", "vi_mode": False}
