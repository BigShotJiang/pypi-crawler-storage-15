#!/usr/bin/env python3
# This software is distributed under the terms of the MIT License.
# Copyright (c) 2025 Dmitry Ponomarev.
# Author: Dmitry Ponomarev <ponomarevda96@gmail.com>
"""
Main window
"""

import os
import sys
import signal
import logging
import argparse
from pathlib import Path
from importlib.metadata import version, PackageNotFoundError

from tsugite.ui.desktop.widgets import WidgetFactory, TableWidget
from tsugite.loader import load_yaml_with_includes
from tsugite.backend.backend import instanciate_backend, BackendInitializationError
from tsugite.ui.desktop.welcome_panel import WelcomePanel
from tsugite.utils import fetch_cached_icon

# Restore the default OS behavior for SIGINT (Ctrl+C).
# Without it, Qt overrides Python’s signal handling,
# so pressing Ctrl+C does nothing until you close the window manually.
signal.signal(signal.SIGINT, signal.SIG_DFL)

logger = logging.getLogger(__name__)

try:
    from PySide6.QtWidgets import (
        QApplication,
        QMainWindow,
        QPushButton,
        QVBoxLayout,
        QHBoxLayout,
        QWidget,
        QStackedWidget,
        QSizePolicy,
        QMenu,
    )
    from PySide6.QtCore import Qt, QTimer, QSize
    from PySide6.QtGui import QKeySequence, QShortcut, QPixmap, QIcon
except ModuleNotFoundError:
    logger.critical("PySide6 required: pip install PySide6>=6.10.0")
    sys.exit(1)

def get_app_version() -> str:
    try:
        return version("tsugite")
    except PackageNotFoundError:
        return "dev"

class MainWindow(QMainWindow):
    def __init__(self, config: dict, communicator: object, config_path: Path | None = None):
        super().__init__()
        self.config = config
        self.communicator = communicator
        self.config_path = config_path

        app_version = get_app_version()
        self.setWindowTitle(f"Tsugite v{app_version}")
        self.resize(600, 400)
        main_layout = QVBoxLayout()

        nav_bar = QHBoxLayout()
        nav_bar.setContentsMargins(0, 0, 0, 0)
        nav_bar.setSpacing(8)

        self.stack = QStackedWidget()
        self.nav_items: list[dict] = []

        # --- Welcome panel (always index 0 / Alt+1) ---
        welcome_panel = WelcomePanel(
            config=self.config,
            communicator=self.communicator,
            reload_callback=self._reload_config,
            reconnect_callback=self._reconnect_backend,
            connect_callback=None,
            initial_config_path=self.config_path,
        )
        self.stack.addWidget(welcome_panel)

        welcome_btn = QPushButton("Welcome")
        welcome_btn.setCheckable(True)
        welcome_item = {"btn": welcome_btn, "pages": [0], "current_page": 0}
        self.nav_items.append(welcome_item)
        welcome_btn.clicked.connect(lambda checked=False, ni=0: self._activate_nav_item(ni))
        nav_bar.addWidget(welcome_btn)

        # --- Build the rest of navigation from config["panels"] ---
        self._build_panel_navigation(nav_bar)

        nav_bar.addStretch()
        main_layout.addLayout(nav_bar)
        main_layout.addWidget(self.stack)

        # Alt+1..9 for visible top-level buttons (Welcome + panel entries)
        max_shortcuts = min(9, len(self.nav_items))
        for idx in range(max_shortcuts):
            shortcut = QShortcut(QKeySequence(f"Alt+{idx + 1}"), self)
            shortcut.activated.connect(
                lambda checked=False, ni=idx: self._activate_nav_item(ni)
            )

        # select Welcome
        self.switch_panel(0)

        container = QWidget()
        container.setLayout(main_layout)
        self.setCentralWidget(container)

    # --------------------------------------------------------------------- helpers
    def _build_panel_navigation(self, nav_bar: QHBoxLayout) -> None:
        panels_cfg = self.config.get("panels") or {}

        for entry_name, entry_cfg in panels_cfg.items():
            # ---- GROUP ENTRY ----
            if isinstance(entry_cfg, dict) and "panels" in entry_cfg:
                group_cfg = entry_cfg
                group_panels_cfg = group_cfg.get("panels") or {}
                if not group_panels_cfg:
                    continue

                group_icon_path = group_cfg.get("icon")
                group_icon_url = group_cfg.get("icon_url")

                panel_names = list(group_panels_cfg.keys())
                panel_infos = [group_panels_cfg[name] for name in panel_names]

                page_indices: list[int] = []
                panel_infos_by_page: dict[int, dict] = {}

                for panel_info in panel_infos:
                    page_index = self.stack.addWidget(self.create_panel(panel_info))
                    page_indices.append(page_index)
                    panel_infos_by_page[page_index] = panel_info

                current_page_index = page_indices[0]
                current_panel_name = panel_names[0]

                btn = QPushButton(current_panel_name)
                btn.setCheckable(True)
                btn.setToolTip(group_cfg.get("title") or entry_name)

                # icon for default selected panel
                default_info = panel_infos_by_page[current_page_index]
                icon = self._make_icon(
                    default_info.get("icon") or group_icon_path,
                    default_info.get("icon_url") or group_icon_url,
                )
                if icon is not None:
                    btn.setIcon(icon)
                    btn.setIconSize(QSize(20, 20))

                item = {
                    "btn": btn,
                    "pages": page_indices,
                    "current_page": current_page_index,
                    "panel_infos_by_page": panel_infos_by_page,
                    "group_icon": group_icon_path,
                    "group_icon_url": group_icon_url,
                }
                nav_index = len(self.nav_items)
                self.nav_items.append(item)

                # dropdown with icons for each panel
                menu = QMenu(btn)
                for panel_name, page_index, panel_info in zip(
                    panel_names, page_indices, panel_infos
                ):
                    action = menu.addAction(panel_name)
                    action_icon = self._make_icon(
                        panel_info.get("icon") or group_icon_path,
                        panel_info.get("icon_url") or group_icon_url,
                    )
                    if action_icon is not None:
                        action.setIcon(action_icon)
                    action.triggered.connect(
                        lambda checked=False,
                               ni=nav_index,
                               pi=page_index,
                               pn=panel_name: self._on_group_panel_selected(
                                   ni, pi, pn
                               )
                    )
                btn.setMenu(menu)

                btn.clicked.connect(
                    lambda checked=False, ni=nav_index: self._activate_nav_item(ni)
                )
                nav_bar.addWidget(btn)

            # ---- REGULAR ENTRY ----
            else:
                panel_name = entry_name
                panel_info = entry_cfg
                if not isinstance(panel_info, dict):
                    continue

                page_index = self.stack.addWidget(self.create_panel(panel_info))

                btn = QPushButton(panel_name)
                btn.setCheckable(True)
                self._set_button_icon(
                    btn,
                    panel_info.get("icon"),
                    panel_info.get("icon_url"),
                )

                item = {
                    "btn": btn,
                    "pages": [page_index],
                    "current_page": page_index,
                }
                nav_index = len(self.nav_items)
                self.nav_items.append(item)

                btn.clicked.connect(
                    lambda checked=False, ni=nav_index: self._activate_nav_item(ni)
                )
                nav_bar.addWidget(btn)

    # --------------------------- icon helpers ---------------------------

    def _make_icon(self, icon_path: str | None, icon_url: str | None) -> QIcon | None:
        """Create a QIcon from a local path or cached URL."""
        if icon_path:
            pixmap = QPixmap(icon_path)
            if not pixmap.isNull():
                return QIcon(pixmap)

        if icon_url:
            logger.debug("icon_url: %s", icon_url)
            local_icon = fetch_cached_icon(icon_url)
            if local_icon:
                pixmap = QPixmap(local_icon)
                if not pixmap.isNull():
                    return QIcon(pixmap)

        return None

    def _set_button_icon(self, btn: QPushButton, icon_path: str | None, icon_url: str | None) -> None:
        icon = self._make_icon(icon_path, icon_url)
        if icon is not None:
            btn.setIcon(icon)
            btn.setIconSize(QSize(20, 20))

    # ----------------------------------------------------------------- navigation

    def _activate_nav_item(self, nav_index: int) -> None:
        """Called by Alt+N and by clicking a top-level button."""
        if 0 <= nav_index < len(self.nav_items):
            page_index = self.nav_items[nav_index]["current_page"]
            self.switch_panel(page_index)

    def _on_group_panel_selected(self, nav_index: int, page_index: int, panel_name: str) -> None:
        """
        User picked a specific panel from a dropdown:
        - remember it as the group's 'current' page
        - update group button label and icon
        - switch to that page
        """
        if not (0 <= nav_index < len(self.nav_items)):
            return

        item = self.nav_items[nav_index]
        item["current_page"] = page_index
        btn = item["btn"]
        btn.setText(panel_name)

        # pick icon for the selected panel
        panel_infos_by_page = item.get("panel_infos_by_page", {})
        panel_info = panel_infos_by_page.get(page_index, {}) or {}

        group_icon_path = item.get("group_icon")
        group_icon_url = item.get("group_icon_url")

        icon = self._make_icon(
            panel_info.get("icon") or group_icon_path,
            panel_info.get("icon_url") or group_icon_url,
        )
        if icon is not None:
            btn.setIcon(icon)
            btn.setIconSize(QSize(20, 20))
        else:
            btn.setIcon(QIcon())  # clear icon if none

        self.switch_panel(page_index)

    # ----------------------------------------------------------------- panel creation

    def create_panel(self, panel_info: dict) -> QWidget:
        """Dynamically create a QWidget based on panel definition."""
        panel = QWidget()
        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(2)
        layout.setAlignment(Qt.AlignTop)

        for widget_cfg in panel_info.get("widgets", []):
            widget_cfg["communicator"] = self.communicator # HACK: pass communicator to widgets
            widget = WidgetFactory.create(widget_cfg)
            if isinstance(widget, TableWidget):
                widget.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
            layout.addWidget(widget)

        panel.setLayout(layout)
        return panel

    def switch_panel(self, index: int):
        """Switch visible panel by stacked index and update button checked state."""
        self.stack.setCurrentIndex(index)
        for item in self.nav_items:
            btn = item["btn"]
            btn.setChecked(index in item["pages"])

    def _reload_config(self):
        logger.info("Reload config not implemented yet")

    def _reconnect_backend(self):
        logger.info("Reconnect backend not implemented yet")


def configure_logger(verbose) -> None:
    def get_log_path() -> Path:
        """Return platform-appropriate log path."""
        if os.name == "nt":  # Windows
            base = Path(os.getenv("APPDATA", Path.home() / "AppData" / "Roaming"))
        else:  # Linux / macOS
            base = Path.home()
        log_dir = base / ".tsugite" if os.name != "nt" else base / "tsugite"
        log_dir /= "Logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        return log_dir / "log.txt"

    log_path = get_log_path()
    formatter = logging.Formatter(
        "[%(asctime)s] [%(levelname)s] %(message)s", "%H:%M:%S"
    )

    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.DEBUG if verbose else logging.INFO)
    console_handler.setFormatter(formatter)

    file_handler = logging.FileHandler(log_path, mode="w", encoding="utf-8")
    file_handler.setLevel(logging.DEBUG)  # Always capture all messages
    file_handler.setFormatter(formatter)

    root_logger = logging.getLogger()
    root_logger.setLevel(logging.DEBUG)  # Let handlers decide what to show
    root_logger.handlers.clear()
    root_logger.addHandler(console_handler)
    root_logger.addHandler(file_handler)

    root_logger.info("Logging to %s", log_path)

def main(args: argparse.Namespace) -> None:
    configure_logger(args.verbose)

    config_path = args.config
    if config_path.exists():
        config_path = args.config
    else:
        tsugite_dir = Path(__file__).resolve().parent.parent.parent
        example_config = tsugite_dir / args.config
        if example_config.exists():
            config_path = example_config
        else:
            logger.critical("YAML config not found: %s / %s", args.config, example_config)
            sys.exit(1)

    try:
        config = load_yaml_with_includes(config_path)
    except Exception as e:
        logger.error("Failed to load YAML: %s", e)
        sys.exit(1)

    app = QApplication()

    try:
        communicator = instanciate_backend(args.backend, args.iface, args.node_id)
    except BackendInitializationError as e:
        logger.critical(str(e))
        sys.exit(1)

    window = MainWindow(config, communicator, config_path=config_path)
    window.show()

    tick_hz = 100
    timer = QTimer()
    timer.timeout.connect(communicator.tick)
    timer.start(int(1000 / tick_hz))  # milliseconds per tick

    sys.exit(app.exec())
