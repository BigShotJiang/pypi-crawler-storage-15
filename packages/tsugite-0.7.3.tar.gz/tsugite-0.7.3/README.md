# Tsugite [![PyPI](https://img.shields.io/pypi/v/tsugite?logo=pypi&style=flat)](https://pypi.org/project/tsugite/) [![TestPyPI](https://img.shields.io/pypi/v/tsugite?label=TestPyPI&logo=pypi&pypiBaseUrl=https://test.pypi.org&include_prereleases=true&style=flat)](https://test.pypi.org/project/tsugite/) ![coverage](https://img.shields.io/badge/dynamic/json?url=https://gist.githubusercontent.com/ponomarevda/20c5b223bf0056aa734fec26e21d939d/raw/coverage.json&label=coverage&query=$.coverage&color=blue) [![Downloads](https://static.pepy.tech/badge/tsugite)](https://pepy.tech/project/tsugite)

A system-oriented dashboard for Cyphal (CAN + UDP) & DroneCAN. Render live panels from a YAML manifest - so you watch the system, not just the bus.

> 🪵 “Tsugite” (継ぎ手) - a Japanese word for traditional wood joinery - symbolizes how separate modules fit together into one solid structure, just like nodes in your robotics system.

## Why Tsugite?

Most tools are **bus-oriented**: they show frames, subjects, and IDs.  
But field work needs **system-oriented** views:

- “Is my **VTOL** healthy right now?”
- “Which **nodes** are missing from the network?”
- “Are all **critical topics** alive?”
- “Can I watch it remotely from my laptop or tablet?”

Tsugite focuses on:

- A **YAML system manifest** that describes your nodes, panels, and topics.
- A **backend** that speaks Cyphal (CAN + UDP) and DroneCAN.
- A **desktop GUI** (PySide6) that renders dashboards dynamically from that manifest.

You describe the system once in YAML – Tsugite builds the UI and wiring for you.

## Usage

Latest stable from PyPI:

```bash
# Create and activate a venv (Python 3.10+)
python3 -m venv .venv && source ".venv/bin/activate"

# Upgrade pip inside the venv
python -m pip install --upgrade pip

# Install Tsugite
pip install "tsugite[dronecan]"

# (Optionally) Install a tsugite.desktop launcher (Linux only)
tsugite --install-desktop

# Then you can run:
tsugite --help
```

## MVP scope

- ✅ **Transports**: SocketCAN / SLCAN (Linux, macOS, Windows where supported), UDP (Cyphal).
- ✅ **Protocols**: Cyphal, DroneCAN.
- ✅ **YAML manifest**: Define nodes, panels, widgets, and data bindings.
- ✅ **Widgets**: Dynamic system panels with labels, buttons, GPS, and plotting.
- ✅ **Node list**: Health, uptime, firmware version, voltages, temperature, and bootloader state.
- ✅ **Parameters panel**: Inspect and modify node parameters.
- ✅ **Component QA** (Node-level, active): run automated node-level tests to verify firmware, parameters, and behavior compliance — ensuring each device meets specification before deployment.
- ✅ **Bus analysis** (System-level, passive): review overall system traffic, measure total and per-node bandwidth, and detect missing frames or termination issues — a non-intrusive pre-flight consistency check.
- ✅ **CLI launcher**: `tsugite` or `python -m tsugite.cli` to run the GUI.

## Contributing

For development:

```bash
git clone git@github.com:PonomarevDA/tsugite.git
pip install -e .[all]
```

For testing:

```bash
pip install -i https://test.pypi.org/simple/ "tsugite[dronecan]"
```
