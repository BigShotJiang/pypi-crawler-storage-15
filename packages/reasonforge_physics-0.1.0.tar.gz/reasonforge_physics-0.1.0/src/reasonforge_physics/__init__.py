"""ReasonForge Physics - Physics and Quantum Computing
MCP server with 16 tools for physics and quantum mechanics."""
__version__ = "0.1.0"
