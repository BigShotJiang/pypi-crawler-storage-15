# Basic sanity test to ensure testing infrastructure works
def test_sanity():
    assert 1 + 1 == 2
