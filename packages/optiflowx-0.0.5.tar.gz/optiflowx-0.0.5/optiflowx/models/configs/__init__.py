"""
All model configuration classes.
Each config defines:
"""

from .svc_config import SVCConfig
from .random_forest_config import RandomForestConfig
from .xgboost_config import XGBoostConfig
from .mlp_config import MLPConfig
from .decision_tree_config import DecisionTreeConfig
from .knn_config import KNNConfig
from .linear_regression_config import LinearRegressionConfig
from .logistic_regression_config import LogisticRegressionConfig
from .custom_model_config import CustomModelConfig

__all__ = [
    "SVCConfig",
    "RandomForestConfig",
    "XGBoostConfig",
    "MLPConfig",
    "DecisionTreeConfig",
    "KNNConfig",
    "LinearRegressionConfig",
    "LogisticRegressionConfig",
    "CustomModelConfig",
]
