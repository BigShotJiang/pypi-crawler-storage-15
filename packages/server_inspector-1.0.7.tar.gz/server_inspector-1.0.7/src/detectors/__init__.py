"""Hardware detection modules"""
