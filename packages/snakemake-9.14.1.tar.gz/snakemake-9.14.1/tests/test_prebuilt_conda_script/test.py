import dummy

with open('output.txt', 'w') as file:
	file.write("something\n")
