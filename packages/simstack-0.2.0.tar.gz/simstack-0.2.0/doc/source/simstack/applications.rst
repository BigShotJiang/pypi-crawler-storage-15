applications package
====================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   applications.electronic_structure
   applications.general
   applications.group

Module contents
---------------

.. automodule:: applications
   :members:
   :show-inheritance:
   :undoc-members:
