examples package
================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   examples.core
   examples.file_operations
   examples.interface
   examples.science

Submodules
----------

examples.binary\_operations module
----------------------------------

.. automodule:: examples.binary_operations
   :members:
   :show-inheritance:
   :undoc-members:

examples.local\_example module
------------------------------

.. automodule:: examples.local_example
   :members:
   :show-inheritance:
   :undoc-members:

examples.node\_example module
-----------------------------

.. automodule:: examples.node_example
   :members:
   :show-inheritance:
   :undoc-members:

examples.slurm\_example module
------------------------------

.. automodule:: examples.slurm_example
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: examples
   :members:
   :show-inheritance:
   :undoc-members:
