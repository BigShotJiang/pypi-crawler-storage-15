examples.science.electronic\_structure.transition\_states.c2h6 package
======================================================================

Submodules
----------

examples.science.electronic\_structure.transition\_states.c2h6.ts\_search module
--------------------------------------------------------------------------------

.. automodule:: examples.science.electronic_structure.transition_states.c2h6.ts_search
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: examples.science.electronic_structure.transition_states.c2h6
   :members:
   :show-inheritance:
   :undoc-members:
