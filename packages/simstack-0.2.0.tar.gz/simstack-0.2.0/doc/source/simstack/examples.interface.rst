examples.interface package
==========================

Submodules
----------

examples.interface.interface\_testing module
--------------------------------------------

.. automodule:: examples.interface.interface_testing
   :members:
   :show-inheritance:
   :undoc-members:

examples.interface.plot\_example module
---------------------------------------

.. automodule:: examples.interface.plot_example
   :members:
   :show-inheritance:
   :undoc-members:

examples.interface.table\_example2 module
-----------------------------------------

.. automodule:: examples.interface.table_example2
   :members:
   :show-inheritance:
   :undoc-members:

examples.interface.table\_example\_automatic module
---------------------------------------------------

.. automodule:: examples.interface.table_example_automatic
   :members:
   :show-inheritance:
   :undoc-members:

examples.interface.table\_example\_manual module
------------------------------------------------

.. automodule:: examples.interface.table_example_manual
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: examples.interface
   :members:
   :show-inheritance:
   :undoc-members:
