applications.general package
============================

Module contents
---------------

.. automodule:: applications.general
   :members:
   :show-inheritance:
   :undoc-members:
