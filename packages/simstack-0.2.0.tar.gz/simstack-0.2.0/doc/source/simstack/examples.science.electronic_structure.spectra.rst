examples.science.electronic\_structure.spectra package
======================================================

Submodules
----------

examples.science.electronic\_structure.spectra.fc\_classes module
-----------------------------------------------------------------

.. automodule:: examples.science.electronic_structure.spectra.fc_classes
   :members:
   :show-inheritance:
   :undoc-members:

examples.science.electronic\_structure.spectra.fcc module
---------------------------------------------------------

.. automodule:: examples.science.electronic_structure.spectra.fcc
   :members:
   :show-inheritance:
   :undoc-members:

examples.science.electronic\_structure.spectra.plot\_spectra module
-------------------------------------------------------------------

.. automodule:: examples.science.electronic_structure.spectra.plot_spectra
   :members:
   :show-inheritance:
   :undoc-members:

examples.science.electronic\_structure.spectra.run\_vb\_spectra module
----------------------------------------------------------------------

.. automodule:: examples.science.electronic_structure.spectra.run_vb_spectra
   :members:
   :show-inheritance:
   :undoc-members:

examples.science.electronic\_structure.spectra.scrap\_clean module
------------------------------------------------------------------

.. automodule:: examples.science.electronic_structure.spectra.scrap_clean
   :members:
   :show-inheritance:
   :undoc-members:

examples.science.electronic\_structure.spectra.vibrational\_spectra module
--------------------------------------------------------------------------

.. automodule:: examples.science.electronic_structure.spectra.vibrational_spectra
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: examples.science.electronic_structure.spectra
   :members:
   :show-inheritance:
   :undoc-members:
