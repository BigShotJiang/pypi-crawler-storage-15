applications.electronic\_structure.util package
===============================================

Submodules
----------

applications.electronic\_structure.util.add\_hydrogen\_to\_molecule module
--------------------------------------------------------------------------

.. automodule:: applications.electronic_structure.util.add_hydrogen_to_molecule
   :members:
   :show-inheritance:
   :undoc-members:

applications.electronic\_structure.util.cdx\_to\_molecule\_rdkit module
-----------------------------------------------------------------------

.. automodule:: applications.electronic_structure.util.cdx_to_molecule_rdkit
   :members:
   :show-inheritance:
   :undoc-members:

applications.electronic\_structure.util.lib\_functions\_conf\_generation module
-------------------------------------------------------------------------------

.. automodule:: applications.electronic_structure.util.lib_functions_conf_generation
   :members:
   :show-inheritance:
   :undoc-members:

applications.electronic\_structure.util.molecule\_to\_pymatgen module
---------------------------------------------------------------------

.. automodule:: applications.electronic_structure.util.molecule_to_pymatgen
   :members:
   :show-inheritance:
   :undoc-members:

applications.electronic\_structure.util.smiles module
-----------------------------------------------------

.. automodule:: applications.electronic_structure.util.smiles
   :members:
   :show-inheritance:
   :undoc-members:

applications.electronic\_structure.util.smiles\_to\_molecule module
-------------------------------------------------------------------

.. automodule:: applications.electronic_structure.util.smiles_to_molecule
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: applications.electronic_structure.util
   :members:
   :show-inheritance:
   :undoc-members:
