simstack.server.routes package
==============================

Submodules
----------

simstack.server.routes.artifacts module
---------------------------------------

.. automodule:: simstack.server.routes.artifacts
   :members:
   :show-inheritance:
   :undoc-members:

simstack.server.routes.files module
-----------------------------------

.. automodule:: simstack.server.routes.files
   :members:
   :show-inheritance:
   :undoc-members:

simstack.server.routes.input\_template\_routes module
-----------------------------------------------------

.. automodule:: simstack.server.routes.input_template_routes
   :members:
   :show-inheritance:
   :undoc-members:

simstack.server.routes.model\_routes module
-------------------------------------------

.. automodule:: simstack.server.routes.model_routes
   :members:
   :show-inheritance:
   :undoc-members:

simstack.server.routes.user\_routes module
------------------------------------------

.. automodule:: simstack.server.routes.user_routes
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: simstack.server.routes
   :members:
   :show-inheritance:
   :undoc-members:
