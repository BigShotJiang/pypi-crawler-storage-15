tests package
=============

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   tests.core
   tests.methods
   tests.server
   tests.util

Submodules
----------

tests.conftest module
---------------------

.. automodule:: tests.conftest
   :members:
   :show-inheritance:
   :undoc-members:

tests.test\_pandas\_model module
--------------------------------

.. automodule:: tests.test_pandas_model
   :members:
   :show-inheritance:
   :undoc-members:

tests.test\_path\_manager module
--------------------------------

.. automodule:: tests.test_path_manager
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: tests
   :members:
   :show-inheritance:
   :undoc-members:
