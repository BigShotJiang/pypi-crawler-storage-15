examples.science.electronic\_structure package
==============================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   examples.science.electronic_structure.gaussian
   examples.science.electronic_structure.orca
   examples.science.electronic_structure.spectra
   examples.science.electronic_structure.transition_states

Submodules
----------

examples.science.electronic\_structure.pes\_generator module
------------------------------------------------------------

.. automodule:: examples.science.electronic_structure.pes_generator
   :members:
   :show-inheritance:
   :undoc-members:

examples.science.electronic\_structure.separator module
-------------------------------------------------------

.. automodule:: examples.science.electronic_structure.separator
   :members:
   :show-inheritance:
   :undoc-members:

examples.science.electronic\_structure.t1\_single\_point module
---------------------------------------------------------------

.. automodule:: examples.science.electronic_structure.t1_single_point
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: examples.science.electronic_structure
   :members:
   :show-inheritance:
   :undoc-members:
