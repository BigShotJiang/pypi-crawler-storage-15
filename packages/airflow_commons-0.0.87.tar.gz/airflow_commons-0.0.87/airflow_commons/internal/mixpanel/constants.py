BASE_URL = "https://api.mixpanel.com/"
ENGAGE_API_URL = BASE_URL + "engage?ip=0"
ENGAGE_BATCH_SIZE = 50
IMPORT_API_URL = BASE_URL + "import?strict=1&project_id="
