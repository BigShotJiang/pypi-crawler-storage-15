import json
from typing import List

import requests

from airflow_commons.internal.mixpanel.auth import Connection
from airflow_commons.internal.mixpanel.constants import (
    ENGAGE_API_URL,
    IMPORT_API_URL,
    ENGAGE_BATCH_SIZE,
)
from airflow_commons.internal.mixpanel.defaults import TIMEOUT


class ServiceAccount(object):
    def __init__(self, username, secret):
        self.username = username
        self.secret = secret


class MixpanelOperator(object):
    def __init__(
        self,
        project_id: str = None,
        service_account_name: str = None,
        service_account_secret: str = None,
        access_token: str = None,
        timeout: int = TIMEOUT,
    ):
        self.session = requests.Session()
        self.project_id = project_id
        self.connection = Connection(
            service_account_name=service_account_name,
            service_account_secret=service_account_secret,
            access_token=access_token,
        )
        self.timeout = timeout

    def engage(self, values: List[dict]):
        token = self.connection.get_access_token()
        for value in values:
            value["$token"] = token
        batches = [
            values[i : i + ENGAGE_BATCH_SIZE]
            for i in range(0, len(values), ENGAGE_BATCH_SIZE)
        ]
        for batch in batches:
            request = requests.Request(
                "POST",
                ENGAGE_API_URL,
                headers={"Content-Type": "application/json"},
                data=json.dumps(batch),
            )
            response = self._send_request(request)
            response.raise_for_status()

    def import_events(self, values: List[dict]):
        url = IMPORT_API_URL + self.project_id
        request = requests.Request(
            "POST",
            url,
            headers={"Accept": "application/json", "Content-Type": "application/json"},
            auth=self.connection.get_service_account_credentials(),
            data=json.dumps(values),
        )
        response = self._send_request(request)
        response.raise_for_status()
        return response

    def _send_request(self, request: requests.Request):
        prep = request.prepare()
        return self.session.send(prep, timeout=self.timeout)
