SELECT {column_names} FROM
    `{table_name}`
WHERE
    {where_statement};