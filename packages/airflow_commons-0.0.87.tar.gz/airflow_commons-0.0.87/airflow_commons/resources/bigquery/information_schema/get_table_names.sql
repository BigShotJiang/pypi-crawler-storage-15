SELECT
  table_name
FROM
    {project_id}.{dataset_id}.INFORMATION_SCHEMA.TABLES;
