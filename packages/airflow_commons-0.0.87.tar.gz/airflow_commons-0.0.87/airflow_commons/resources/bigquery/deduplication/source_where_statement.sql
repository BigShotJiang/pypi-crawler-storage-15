{source_partition_field} BETWEEN '{start_date}'
        AND '{end_date}' AND {target_partition_field} >= '{oldest_allowable_target_partition}'