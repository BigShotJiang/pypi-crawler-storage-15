from moxn_types import base


class Schema(base.BaseSchema): ...
