"""Wrapper filesystem base class."""

from __future__ import annotations

import asyncio
import inspect
from typing import TYPE_CHECKING, Any, Literal, overload

from fsspec.asyn import AsyncFileSystem, sync_wrapper
from fsspec.implementations.asyn_wrapper import AsyncFileSystemWrapper
from fsspec.implementations.local import LocalFileSystem
from upath.registry import get_upath_class

from upathtools.async_upath import AsyncUPath


if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    from fsspec.spec import AbstractFileSystem
    from upath import UPath

    # Callback for single info dict: receives info dict + filesystem, returns enriched dict
    InfoCallback = Callable[
        [dict[str, Any], "WrapperFileSystem"],
        dict[str, Any] | Awaitable[dict[str, Any]],
    ]
    # Callback for batch info dicts: receives list of info dicts + filesystem, returns enriched list
    LsInfoCallback = Callable[
        [list[dict[str, Any]], "WrapperFileSystem"],
        list[dict[str, Any]] | Awaitable[list[dict[str, Any]]],
    ]


def _to_async(filesystem: AbstractFileSystem) -> AsyncFileSystem:
    """Convert a sync filesystem to async if needed."""
    if isinstance(filesystem, AsyncFileSystem):
        return filesystem
    return AsyncFileSystemWrapper(filesystem)


class WrapperFileSystem(AsyncFileSystem):
    """Base class for filesystems that wrap another filesystem.

    This class delegates most operations to the wrapped filesystem using __getattr__.
    Only methods that need custom behavior (like applying info callbacks) are overridden.

    The info_callback and ls_info_callback can be used to enrich file info dicts:
    - info_callback: Applied to single info dicts (from _info/info)
    - ls_info_callback: Applied to lists of info dicts (from _ls/ls)
      If not provided, falls back to applying info_callback to each item.
    """

    protocol = "wrapper"

    def __init__(
        self,
        fs: AbstractFileSystem | None = None,
        target_protocol: str | None = None,
        target_options: dict[str, Any] | None = None,
        info_callback: InfoCallback | None = None,
        ls_info_callback: LsInfoCallback | None = None,
        **storage_options: Any,
    ) -> None:
        """Initialize wrapper filesystem.

        Args:
            fs: An instantiated filesystem to wrap.
            target_protocol: Protocol to use if fs is not provided.
            target_options: Options for target filesystem if fs is not provided.
            info_callback: Optional callback to enrich single info dict. Receives (info, fs)
                          and returns enriched info dict. Can be sync or async.
            ls_info_callback: Optional callback to enrich batch of info dicts. Receives
                             (infos, fs) and returns enriched list. Can be sync or async.
                             If not provided, falls back to applying info_callback individually.
            **storage_options: Additional storage options passed to parent.
        """
        super().__init__(**storage_options)

        if fs is None:
            from fsspec import filesystem

            fs = filesystem(protocol=target_protocol, **(target_options or {}))
        self.fs = _to_async(fs)
        self._info_callback = info_callback
        self._ls_info_callback = ls_info_callback

    def __getattr__(self, name: str) -> Any:
        """Delegate attribute access to wrapped filesystem."""
        # Avoid infinite recursion for attributes accessed during __init__
        if name in ("fs", "_info_callback", "_ls_info_callback"):
            raise AttributeError(name)
        return getattr(self.fs, name)

    # Callback helpers

    async def _apply_info_callback(self, info: dict[str, Any]) -> dict[str, Any]:
        """Apply the info callback if set."""
        if self._info_callback is None:
            return info
        result = self._info_callback(info, self)
        if inspect.isawaitable(result):
            return await result
        return result

    async def _apply_ls_info_callback(self, infos: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Apply the ls_info_callback or fall back to info_callback individually."""
        if self._ls_info_callback is not None:
            result = self._ls_info_callback(infos, self)
            if inspect.isawaitable(result):
                return await result
            return result
        if self._info_callback is not None:
            return list(await asyncio.gather(*[self._apply_info_callback(i) for i in infos]))
        return infos

    # UPath helper

    @overload
    def get_upath(self, path: str | None = None, *, as_async: Literal[True]) -> AsyncUPath: ...

    @overload
    def get_upath(self, path: str | None = None, *, as_async: Literal[False] = False) -> UPath: ...

    @overload
    def get_upath(
        self, path: str | None = None, *, as_async: bool = False
    ) -> UPath | AsyncUPath: ...

    def get_upath(self, path: str | None = None, *, as_async: bool = False) -> UPath | AsyncUPath:
        """Get a UPath object for the given path.

        Args:
            path: The path to the file or directory. If None, the root path is returned.
            as_async: If True, return an AsyncUPath wrapper
        """
        upath_cls = get_upath_class(self.protocol)
        assert upath_cls
        path_obj = upath_cls(path if path is not None else self.root_marker)
        path_obj._fs_cached = self  # pyright: ignore[reportAttributeAccessIssue]

        if as_async:
            return AsyncUPath._from_upath(path_obj)
        return path_obj

    def is_local(self) -> bool:
        """Check if the wrapped filesystem is local."""
        return isinstance(self.fs, LocalFileSystem)

    # Async methods that need callback application

    async def _info(self, path: str, **kwargs: Any) -> dict[str, Any]:
        info = await self.fs._info(path, **kwargs)
        return await self._apply_info_callback(info)

    @overload
    async def _ls(
        self, path: str, detail: Literal[True] = ..., **kwargs: Any
    ) -> list[dict[str, Any]]: ...

    @overload
    async def _ls(self, path: str, detail: Literal[False], **kwargs: Any) -> list[str]: ...

    async def _ls(
        self, path: str, detail: bool = True, **kwargs: Any
    ) -> list[str] | list[dict[str, Any]]:
        result = await self.fs._ls(path, detail=detail, **kwargs)
        if detail and (self._ls_info_callback is not None or self._info_callback is not None):
            return await self._apply_ls_info_callback(result)  # type: ignore[arg-type]
        return result

    # Explicit sync wrappers for commonly used methods
    info = sync_wrapper(_info)
    ls = sync_wrapper(_ls)  # pyright: ignore[reportAssignmentType]

    def __repr__(self) -> str:
        return f"{self.__class__.__qualname__}(fs={self.fs})"
