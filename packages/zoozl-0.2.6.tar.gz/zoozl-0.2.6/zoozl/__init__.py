"""Zoozl package allows to build chatbots that answer over network server."""
