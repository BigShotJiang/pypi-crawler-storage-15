from typing import Dict

__all__ = ["JSONSchema"]

JSONSchema = Dict
