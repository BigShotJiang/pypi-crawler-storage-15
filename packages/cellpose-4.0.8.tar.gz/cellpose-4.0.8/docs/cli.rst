.. _Cellpose CLI:

Cellpose CLI
------------------------

See example usage at :ref:`CLI examples <Command line examples>`. A description
of the most important settings can be found on the :ref:`Settings` page.

Command Line Usage
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
.. argparse::
   :module: cellpose.cli
   :func: get_arg_parser
   :prog: cellpose
