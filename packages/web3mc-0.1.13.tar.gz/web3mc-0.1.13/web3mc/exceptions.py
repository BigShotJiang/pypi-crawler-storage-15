class MaxRetriesExceeded(Exception):
    pass
