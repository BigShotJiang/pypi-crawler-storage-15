from .multicall import Multicall

multicall = Multicall()
