
import sys
from . import UAMT

def run():
    try:
        # If the compiled module has a main() function, run it
        if hasattr(UAMT, 'main'):
            UAMT.main()
    except KeyboardInterrupt:
        pass
    except Exception as e:
        print(f"Error: {e}")
