from .cli import main as cli
from ._version import __version__, __version_tuple__

VERSION = _version.version_tuple