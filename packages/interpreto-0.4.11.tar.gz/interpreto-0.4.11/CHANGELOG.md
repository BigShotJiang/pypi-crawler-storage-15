# Changelog

*This file contains a high-level description of changes that were merged into the main branch since the last release. Refer to the releases page for an exhaustive overview of changes introduced at each release.*