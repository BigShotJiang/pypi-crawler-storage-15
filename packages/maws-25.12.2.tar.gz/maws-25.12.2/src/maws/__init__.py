__app_name__ = "maws"
__version__ = "25.12.2"
