# 🌌 Coherence-Sim

**Библиотека для моделирования когерентности Вселенной**

[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![CI](https://github.com/xtimon/coherence/actions/workflows/ci.yml/badge.svg)](https://github.com/xtimon/coherence/actions/workflows/ci.yml)
[![codecov](https://codecov.io/gh/xtimon/coherence/branch/main/graph/badge.svg)](https://codecov.io/gh/xtimon/coherence)
[![PyPI](https://img.shields.io/pypi/v/coherence-sim.svg)](https://pypi.org/project/coherence-sim/)

---

## 📖 О проекте

**Coherence-Sim** — это Python-библиотека, реализующая математическую модель роста когерентности (сложности) во Вселенной. Модель основана на рекуррентном соотношении с эффектом "осаждения" и связывает эволюцию сложности с фундаментальными физическими константами.

### Центральная идея

Когерентность на каждом этапе эволюции Вселенной зависит от накопленного потенциала всех предыдущих этапов:

$$K(n) = K_0 + \alpha \cdot \sum_{k=0}^{n-1} \frac{K(k)}{N - k}$$

где:
- $K(n)$ — когерентность на этапе $n$
- $K_0$ — начальная когерентность
- $\alpha$ — параметр осаждения (скрытый потенциал)
- $N$ — общее число этапов

### Связь с физикой

Эффективный параметр $\alpha$ связан с фундаментальными константами через **голографическую формулу**:

$$k = \pi \cdot \alpha_{fs} \cdot \frac{\ln(1/A_s)}{n_s}$$

где:
- $\alpha_{fs} \approx 1/137$ — постоянная тонкой структуры
- $A_s \approx 2.1 \times 10^{-9}$ — амплитуда скалярных возмущений
- $n_s \approx 0.965$ — спектральный индекс

**Ключевое соотношение:**  $k/\alpha_{fs} \approx 66$

---

## 🚀 Установка

### Через pip (рекомендуется)

```bash
pip install coherence-sim
```

### Из исходников

```bash
git clone https://github.com/xtimon/coherence.git
cd coherence
pip install -e .
```

### Зависимости

```bash
pip install -r requirements.txt
```

Основные зависимости:
- `numpy>=1.20.0`
- `matplotlib>=3.5.0`
- `scipy>=1.7.0`

---

## 📚 Быстрый старт

### Базовое использование

```python
from coherence import CoherenceModel, UniverseConstants

# Создание модели
model = CoherenceModel()

# Эволюция когерентности за 12 этапов
K, C, Total = model.evolve(N=12, alpha=0.66)

print(f"Начальная когерентность: {K[0]:.2f}")
print(f"Финальная когерентность: {K[-1]:.2f}")
print(f"Рост: {K[-1]/K[0]:.2f}x")
```

### Анализ констант

```python
from coherence import UniverseConstants

constants = UniverseConstants()

print(constants.summary())
# Постоянная тонкой структуры α = 0.0072973526
# 1/α = 137.0360
# k/α ≈ 66
```

### Предсказания и интерпретации

```python
from coherence import (
    physical_interpretation,
    compare_with_observations,
    find_beautiful_coincidences,
    get_testable_predictions
)

# Физическая интерпретация параметра k
interp = physical_interpretation(k=0.4747)
print(f"Эффективность передачи: {interp.efficiency*100:.1f}%")
print(f"Режим: {'подкритический' if not interp.is_critical else 'надкритический'}")

# Сравнение с наблюдениями
obs = compare_with_observations(k=0.4747)
print(f"Согласие: {obs['_statistics']['overall_assessment']}")

# Связь с фундаментальными константами
coincidences = find_beautiful_coincidences(k=0.4747)
print(f"Лучшее совпадение: {coincidences[0]['expression']}")

# Проверяемые предсказания
predictions = get_testable_predictions()
for p in predictions[:3]:
    print(f"  - {p['prediction']}")
```

### Статистический анализ

```python
from coherence import UniverseSimulator

# Генерация 1000 случайных вселенных
simulator = UniverseSimulator()
universes = simulator.generate(n=1000, with_coherence=True)

# Статистика
stats = simulator.statistical_analysis(universes)
print(f"Средний k: {stats['k']['mean']:.4f}")
print(f"Наша Вселенная в {stats['our_universe_percentile']:.1f} процентиле")
```

### Визуализация

```python
from coherence import create_full_visualization

# Создание полной визуализации (9 графиков)
fig, results = create_full_visualization(
    save_path='coherence_analysis.png',
    n_universes=500
)
```

---

## 🔬 Модули

### `coherence.constants`

Фундаментальные константы Вселенной.

```python
from coherence.constants import UniverseConstants, UNIVERSE_STAGES

constants = UniverseConstants()

# Постоянная тонкой структуры
alpha = constants.alpha  # ≈ 0.00729...

# Голографический параметр
k = constants.k_observed  # ≈ 0.4837

# Формулы для k
k_new = constants.k_formula_new()  # π × α × ln(1/A_s) / n_s
k_old = constants.k_formula_old()  # (49/8) × α × Δm

# Эффективный α для модели когерентности
alpha_eff = constants.effective_alpha()  # ≈ 0.66
```

### `coherence.models`

Модели когерентности.

```python
from coherence.models import CoherenceModel, DepositionModel, SymmetryBreaking

# Модель когерентности Вселенной
model = CoherenceModel()
K, C, Total = model.evolve(N=12, alpha=0.66, gamma=0.2)

# Модель осаждения (аналогия)
dep = DepositionModel(M0=1.0, N=10, alpha=0.5, gamma=0.3)
concentration, consumption, total = dep.calculate()

# Спонтанное нарушение симметрии
phi, V_sym, V_broken = SymmetryBreaking.phase_transition()
```

### `coherence.analysis`

Анализ и симуляции.

```python
from coherence.analysis import UnifiedAnalysis, UniverseSimulator

# Объединённый анализ
analysis = UnifiedAnalysis()
correspondence = analysis.analyze_correspondence()
simulation = analysis.run_simulation()

# Генератор вселенных
simulator = UniverseSimulator()
universes = simulator.generate(n=1000)
stats = simulator.statistical_analysis(universes)
```

### `coherence.visualization`

Визуализация результатов.

```python
from coherence.visualization import (
    plot_coherence_evolution,
    plot_universe_distribution,
    plot_phase_diagram,
    create_full_visualization
)

# Отдельные графики
fig1 = plot_coherence_evolution(simulation_results)
fig2 = plot_universe_distribution(universes)
fig3 = plot_phase_diagram(our_alpha=0.66)

# Полная визуализация
fig, results = create_full_visualization()
```

---

## 📊 Примеры

### Пример 1: Эволюция когерентности

```python
from coherence import CoherenceModel, UNIVERSE_STAGES
import matplotlib.pyplot as plt

model = CoherenceModel()
K, C, Total = model.evolve(N=12, alpha=0.66)

plt.figure(figsize=(10, 5))
plt.bar(range(12), K, color='steelblue', alpha=0.7)
plt.xticks(range(12), [s[:6] for s in UNIVERSE_STAGES], rotation=45)
plt.ylabel('Когерентность K(n)')
plt.title('Эволюция когерентности Вселенной')
plt.tight_layout()
plt.show()
```

### Пример 2: Сравнение вселенных

```python
from coherence import UniverseSimulator, UniverseConstants
import numpy as np

simulator = UniverseSimulator()
universes = simulator.generate(n=5000, with_coherence=True)

# Найти вселенные с когерентностью выше нашей
our_coherence = 3.62
better = [u for u in universes if u['final_coherence'] > our_coherence]
print(f"Вселенных с большей когерентностью: {len(better)/50:.1f}%")
```

### Пример 3: Поиск оптимального α

```python
from coherence import CoherenceModel

model = CoherenceModel()

# Найти α для 10-кратного роста когерентности
alpha_opt = model.find_optimal_alpha(target_growth=10.0, N=12)
print(f"Для 10x роста нужно α = {alpha_opt:.3f}")
```

### Пример 4: Модели роста и информационный анализ

```python
from coherence import CoherenceModel, FUTURE_STAGES

model = CoherenceModel()

# Разные модели роста
K_basic, _, _ = model.evolve(12, alpha=0.66)
K_corr, _, _ = model.evolve_corrected(12, alpha=0.66)
K_quantum, _, _ = model.evolve_quantum(12, alpha=0.66)

# Информационный анализ
info = model.information_content(K_basic)
print(f"Энтропия: {info['entropy']:.4f} бит")
print(f"Эффективность: {info['efficiency']:.2%}")

# Прогноз будущего (этапы 13-24)
K_future, stages = model.predict_future(12, 24)
for stage, k in zip(stages, K_future):
    print(f"{FUTURE_STAGES[stage]}: K = {k:.2f}")
```

### Пример 5: Формулы для параметра k

```python
from coherence import UniverseConstants

c = UniverseConstants()

# 6 формул для расчёта k
print(f"k наблюдаемое:    {c.k_observed:.6f}")
print(f"k голографич.:    {c.k_formula_new():.6f}")
print(f"k с массами:      {c.k_formula_old():.6f}")
print(f"k энтропийная:    {c.k_formula_entropic():.6f}")
print(f"k информационная: {c.k_formula_information():.6f}")
print(f"k с тёмной энерг.:{c.k_formula_dark_energy():.6f}")
```

### Пример 6: Расширенный анализ

```bash
# Установка пакета (один раз)
pip install -e .

# Запуск расширенного анализа (10 модулей)
python3 examples/extended_analysis.py
```

Расширенный анализ включает:
- **Анализ чувствительности** — влияние параметров на результат
- **Monte Carlo симуляции** — оценка неопределённостей
- **Корреляционный анализ** — связи между параметрами
- **Критические точки** — фазовые переходы модели
- **Сравнение формул** — точность различных формул для k
- **Информационная ёмкость** — битовая интерпретация
- **Прогноз будущего** — эволюция на 24 этапа
- **Сравнение моделей роста** — базовая, исправленная, квантовая
- **Расширенный прогноз** — сценарии с разными α
- **Комплексный анализ k** — 6 формул с визуализацией

---

## 🧮 Математика модели

### Рекуррентное соотношение

Модель основана на идее **осаждения** — каждый этап накапливает потенциал, который используется на последующих этапах:

$$K(n) = K_0 + \alpha \cdot \sum_{k=0}^{n-1} \frac{K(k)}{N - k}$$

### Параметры модели

| Параметр | Обозначение | Значение для нашей Вселенной |
|----------|-------------|------------------------------|
| Скрытый потенциал | α | ≈ 0.66 |
| Реализованный порядок | γ | ≈ 0.2 |
| Энтропийные потери | β | ≈ 0.14 |

Ограничение: $\alpha + \beta + \gamma = 1$

### Голографическая связь

$$\alpha_{eff} = \frac{k}{100 \cdot \alpha_{fs}} = \frac{\pi \cdot \ln(1/A_s)}{100 \cdot n_s} \approx 0.66$$

### Размерный анализ

Все величины в модели **безразмерные**, что обеспечивает согласованность формул:

| Величина | Размерность | Описание |
|----------|-------------|----------|
| K(n), K₀ | безразмерная | Нормированная когерентность |
| α, β, γ | безразмерная | Доли (сумма = 1) |
| N, n, k | безразмерная | Счётные индексы |
| α_fs | безразмерная | Постоянная тонкой структуры ≈ 1/137 |
| A_s | безразмерная | Амплитуда скалярных возмущений |
| n_s | безразмерная | Спектральный индекс |
| k (голограф.) | безразмерная | Голографический параметр |

**Формулы для k:**

1. **Голографическая** (безразмерная):
   $$k = \pi \cdot \alpha_{fs} \cdot \frac{\ln(1/A_s)}{n_s} \approx 0.475$$

2. **С массами бозонов** (требует нормировки):
   $$k = \frac{49}{8} \cdot \alpha_{fs} \cdot \frac{\Delta m}{M_{ref}}$$
   
   где $\Delta m = m_Z - m_W \approx 10.81$ ГэВ, $M_{ref} = 1$ ГэВ (условно).

> ⚠️ **Примечание:** Формула с массами численно работает при $M_{ref} = 1$ ГэВ, но физическое обоснование этого масштаба требует дополнительного исследования.

### Модели роста когерентности

Библиотека предоставляет три модели роста:

| Модель | Формула | Особенности |
|--------|---------|-------------|
| **Базовая** | `evolve()` | Стандартный рост с осаждением |
| **Исправленная** | `evolve_corrected()` | С учётом убывающего потенциала |
| **Квантовая** | `evolve_quantum()` | С эффектами квантовой когерентности |

### Будущие этапы эволюции

| Этап | Название | Прогнозируемый рост |
|------|----------|---------------------|
| 13 | Техносфера | +5.6% |
| 14 | Киберсфера | +11.9% |
| 15 | Ноосфера | +19.2% |
| 16 | Планетарный разум | +27.8% |
| 20 | Вселенский разум | +88.7% |
| 24 | Омега-точка | +448.4% |

### Трёхкомпонентная физическая модель

Модуль `physical_model.py` реализует физическую модель с тремя компонентами:

| Компонента | Описание | Физические процессы |
|------------|----------|---------------------|
| **Гравитационная** | Рост структуры | Тёмная материя, гало, скопления |
| **Информационная** | Накопление сложности | Звездообразование, металличность, ЧД |
| **Сложностная** | Самоорганизация | Иерархия, обратная связь |

```python
from coherence import ThreeComponentModel, physical_coherence, validate_model

# Трёхкомпонентная модель по z
model = ThreeComponentModel()
components = model.components_at_z(z=0)
print(components)  # {'gravitational': 1.5, 'informational': 1.0, ...}

# Физическая рекуррентная модель (13 этапов)
K, processes = physical_coherence(N=13, k=0.67)

# Валидация с наблюдениями
result = validate_model(K)
print(f"Качество: {result.quality}")
```

---

## 🔗 Физические аналогии

| Модель осаждения | Космологическая модель |
|------------------|------------------------|
| Этап процесса | Этап эволюции Вселенной |
| Концентрация | Уровень когерентности |
| Осаждение (α) | Скрытый потенциал самоорганизации |
| Потребление (γ) | Реализованная сложность |
| Потери (β) | Энтропийные потери |

---

## 📁 Структура проекта

```
coherence/
├── coherence/              # Основной пакет
│   ├── __init__.py         # Экспорт API
│   ├── constants.py        # Фундаментальные константы
│   ├── models.py           # Модели когерентности
│   ├── analysis.py         # Анализ и симуляции
│   ├── predictions.py      # Предсказания и интерпретации
│   ├── physical_model.py   # Трёхкомпонентная физическая модель
│   └── visualization.py    # Визуализация
├── examples/               # Примеры использования
│   ├── basic_usage.py      # Базовые примеры (12 примеров)
│   ├── full_analysis.py    # Полный анализ (7 модулей)
│   ├── extended_analysis.py # Расширенный анализ (10 модулей)
│   └── final_analysis.py   # Финальный анализ (11 модулей)
├── tests/                  # Юнит-тесты
│   ├── test_constants.py   # Тесты констант
│   ├── test_models.py      # Тесты моделей
│   └── test_analysis.py    # Тесты анализа
├── requirements.txt        # Зависимости
├── setup.py                # Установка (legacy)
├── pyproject.toml          # Конфигурация проекта
└── README.md               # Документация
```

### Модули библиотеки

| Модуль | Описание |
|--------|----------|
| `constants.py` | Фундаментальные константы (α, A_s, n_s, k) и формулы |
| `models.py` | CoherenceModel, DepositionModel, SymmetryBreaking |
| `analysis.py` | UnifiedAnalysis, UniverseSimulator, CoefficientAnalyzer |
| `predictions.py` | Предсказания, интерпретации, сравнение с наблюдениями |
| `physical_model.py` | ThreeComponentModel, PhysicalRecurrenceModel |
| `visualization.py` | Графики и визуализации |

---

## 🤝 Вклад в проект

Приветствуются pull requests! Для крупных изменений сначала откройте issue для обсуждения.

---

## 📄 Лицензия

MIT License — см. файл [LICENSE](LICENSE) для деталей.

---

## 📚 Ссылки

- [Постоянная тонкой структуры](https://en.wikipedia.org/wiki/Fine-structure_constant)
- [Космологические параметры Planck 2018](https://arxiv.org/abs/1807.06209)
- [Голографический принцип](https://en.wikipedia.org/wiki/Holographic_principle)

