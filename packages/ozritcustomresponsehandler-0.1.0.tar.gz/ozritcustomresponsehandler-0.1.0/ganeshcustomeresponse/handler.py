from typing import Any, Dict, Iterable, Optional, Type
from urllib.parse import urlencode
from decimal import Decimal
import uuid
from datetime import datetime, date

from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.core.exceptions import ValidationError
from django.contrib.auth.password_validation import validate_password

from rest_framework.response import Response
from rest_framework import status
from rest_framework.serializers import Serializer


MAX_PAGE_SIZE = 100
DEFAULT_PAGE_SIZE = 10


# ---------------------------------------------------------
#  SAFE CONVERSION (Decimal → float, UUID → str, datetime → ISO)
# ---------------------------------------------------------
def safe_convert(obj):
    """Convert non-serializable objects into JSON serializable formats."""

    if isinstance(obj, Decimal):
        return float(obj)

    if isinstance(obj, (uuid.UUID,)):
        return str(obj)

    if isinstance(obj, (datetime, date)):
        return obj.isoformat()

    if isinstance(obj, list):
        return [safe_convert(item) for item in obj]

    if isinstance(obj, dict):
        return {key: safe_convert(value) for key, value in obj.items()}

    return obj


# ---------------------------------------------------------
#  MAIN RESPONSE HANDLER
# ---------------------------------------------------------
class CustomResponseHandler:
    """Unified response handler for all APIs."""

    def __init__(self, serializer_class: Optional[Type[Serializer]] = None) -> None:
        self.serializer_class = serializer_class

    # -----------------------------------------------------
    # PRIVATE RESPONSE BUILDER
    # -----------------------------------------------------
    def _build_response(
        self,
        success: bool,
        message: str,
        data=None,
        status_code: int = status.HTTP_200_OK,
    ) -> Response:

        try:
            data = safe_convert(data)
        except Exception:
            pass

        return Response(
            {
                "success": success,
                "status": status_code,
                "message": message,
                "data": data if data is not None else None,
            },
            status=status_code,
        )

    # -----------------------------------------------------
    # SUCCESS RESPONSES
    # -----------------------------------------------------
    def success_200(self, message="Request successful.", data=None, request=None):
        return self._build_response(True, message, data, status.HTTP_200_OK)

    def success_201(self, message="Created successfully.", data=None, request=None):
        return self._build_response(True, message, data, status.HTTP_201_CREATED)

    def success_202(self, message="Request accepted for processing.", data=None, request=None):
        return self._build_response(True, message, data, status.HTTP_202_ACCEPTED)

    def success_204(self, message="No content.", data=None, request=None):
        return self._build_response(True, message, None, status.HTTP_204_NO_CONTENT)

    # -----------------------------------------------------
    # ERROR RESPONSES
    # -----------------------------------------------------
    def bad_request_400(self, message="Bad request.", data=None, request=None):
        return self._build_response(False, message, data, status.HTTP_400_BAD_REQUEST)

    def unauthorized_401(self, message="Unauthorized access.", data=None, request=None):
        return self._build_response(False, message, data, status.HTTP_401_UNAUTHORIZED)

    def forbidden_403(self, message="Forbidden.", data=None, request=None):
        return self._build_response(False, message, data, status.HTTP_403_FORBIDDEN)

    def not_found_404(self, message="Resource not found.", data=None, request=None):
        return self._build_response(False, message, data, status.HTTP_404_NOT_FOUND)

    def request_timeout_408(self, message="Request timeout.", data=None, request=None):
        return self._build_response(False, message, data, status.HTTP_408_REQUEST_TIMEOUT)

    def conflict_409(self, message="Conflict occurred.", data=None, request=None):
        return self._build_response(False, message, data, status.HTTP_409_CONFLICT)

    def gone_410(self, message="Resource no longer available.", data=None, request=None):
        return self._build_response(False, message, data, status.HTTP_410_GONE)

    def payload_too_large_413(self, message="Payload too large.", data=None, request=None):
        return self._build_response(False, message, data, status.HTTP_413_REQUEST_ENTITY_TOO_LARGE)

    def unsupported_media_415(self, message="Unsupported media type.", data=None, request=None):
        return self._build_response(False, message, data, status.HTTP_415_UNSUPPORTED_MEDIA_TYPE)

    def unprocessable_422(self, message="Validation failed.", errors=None, request=None):
        return self._build_response(False, message, errors, status.HTTP_422_UNPROCESSABLE_ENTITY)

    def too_many_requests_429(self, message="Too many requests.", data=None, request=None):
        return self._build_response(False, message, data, status.HTTP_429_TOO_MANY_REQUESTS)

    def bad_gateway_502(self, message="Bad gateway.", data=None, request=None):
        return self._build_response(False, message, data, status.HTTP_502_BAD_GATEWAY)

    def service_unavailable_503(self, message="Service unavailable.", data=None, request=None):
        return self._build_response(False, message, data, status.HTTP_503_SERVICE_UNAVAILABLE)

    def gateway_timeout_504(self, message="Gateway timeout.", data=None, request=None):
        return self._build_response(False, message, data, status.HTTP_504_GATEWAY_TIMEOUT)

    def server_error_500(self, message="Internal server error.", data=None, request=None):
        return self._build_response(False, message, data, status.HTTP_500_INTERNAL_SERVER_ERROR)

    # -----------------------------------------------------
    # PASSWORD VALIDATION
    # -----------------------------------------------------
    def validate_password_strength(self, password: str):
        try:
            validate_password(password)
        except ValidationError as e:
            return list(e.messages)
        return []

    # -----------------------------------------------------
    # PAGE HELPERS
    # -----------------------------------------------------
    def _coerce_int(self, value: Any, default: int, min_v: int, max_v: Optional[int] = None) -> int:
        try:
            v = int(value)
        except (TypeError, ValueError):
            return default

        v = max(min_v, v)
        if max_v is not None:
            v = min(v, max_v)

        return v

    def _page_links(self, request, page_number: int, page_size: int, total_pages: int) -> Dict[str, Optional[str]]:
        def with_params(pn: int) -> str:
            params = request.query_params.copy()
            params["page"] = pn
            params["limit"] = page_size
            return f"{request.build_absolute_uri(request.path)}?{urlencode(params, doseq=True)}"

        next_url = with_params(page_number + 1) if page_number < total_pages else None
        prev_url = with_params(page_number - 1) if page_number > 1 else None

        return {"next": next_url, "previous": prev_url}

    # -----------------------------------------------------
    # PAGINATION RESPONSE
    # -----------------------------------------------------
    def success_pagination_200(
        self,
        request,
        queryset: Iterable[Any],
        message: str = "Paginated data retrieved successfully.",
        serializer_class: Optional[Type[Serializer]] = None,
    ) -> Response:

        ser_cls = serializer_class or self.serializer_class
        if ser_cls is None:
            return self.unprocessable_422("Serializer class is required for pagination.")

        raw_page = request.query_params.get("page", 1)
        raw_limit = request.query_params.get("limit", DEFAULT_PAGE_SIZE)

        page_size = self._coerce_int(raw_limit, DEFAULT_PAGE_SIZE, min_v=1, max_v=MAX_PAGE_SIZE)
        paginator = Paginator(queryset, page_size)

        try:
            page_number = self._coerce_int(raw_page, 1, min_v=1)
            page_obj = paginator.page(page_number)
        except PageNotAnInteger:
            page_obj = paginator.page(1)
        except EmptyPage:
            page_obj = paginator.page(paginator.num_pages)

        current_page = page_obj.number
        serializer = ser_cls(page_obj, many=True, context={"request": request})

        links = self._page_links(request, current_page, page_size, paginator.num_pages)

        data = {
            "count": paginator.count,
            "total_pages": paginator.num_pages,
            "current_page": current_page,
            "page_size": page_size,
            "next": links["next"],
            "previous": links["previous"],
            "results": safe_convert(serializer.data),
        }

        return self.success_200(message=message, data=data)