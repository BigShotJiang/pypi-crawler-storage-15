# Orzitcustomeresponse

A reusable Django REST Framework custom response handler that standardizes API responses across all services.

## Features
- Unified success response
- Unified error response
- Pagination response formatting
- Validation error wrapper
- Authentication/Authorization error wrapper
- DRF plug-and-play design

## Installation
