## Test

```
cargo run --bin parse_halo PATH_TO_HPL_FILE
```
