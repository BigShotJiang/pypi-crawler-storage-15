class ApiRequestError(Exception):
    pass


class CliArgumentError(Exception):
    pass
