
import pydmm6500.dmm6500 as dmm6500

if __name__ == "__main__":
    
    options = dmm6500.Options(
        name = "Test",
        ip = "192.168.1.10",
        reset = False,
        debug = True
    )
    
    dmm = dmm6500.DMM6500(options)
    
    

