
# pyDMM6500: A Python library for [Keithley's DMM6500](https://www.tek.com/en/products/keithley/digital-multimeter/dmm6500)


> ⚠️ Work in progress


# Installation

```bash
pip install pydmm6500
```

# Documentation

# References

* [DMM6500 Datasheet](https://www.tek.com/en/datasheet/dmm6500-6-1-2-digit-bench-system-digital-multimeter-datasheet)
* [DMM6500 User’s Manual](https://www.tek.com/en/manual/model-dmm6500-6-1-2-digit-multimeter-user-manual)
* [DMM6500 Reference Manual](https://www.tek.com/en/tektronix-and-keithley-digital-multimeter/dmm6500-manual/model-dmm6500-6-1-2-digit-multimeter-3)

# Upload to PyPi

1. Remove build files

```bash
rm -rf dist build *.egg-info
```

2. Update version in [`pyproject.toml`](pyproject.toml)

```toml
[project]
version = "202x.x.x"
```

3. Build new version

```bash
python3 -m build
```

4. Upload new version to PyPi

```bash
python3 -m twine upload dist/*
```
