"""Module for cluster recipe classes."""
