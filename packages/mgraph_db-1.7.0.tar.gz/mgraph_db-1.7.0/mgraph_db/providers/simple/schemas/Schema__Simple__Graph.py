from mgraph_db.mgraph.schemas.Schema__MGraph__Graph           import Schema__MGraph__Graph
from mgraph_db.providers.simple.schemas.Schema__Simple__Types import Schema__Simple__Types


class Schema__Simple__Graph(Schema__MGraph__Graph):
    schema_types : Schema__Simple__Types