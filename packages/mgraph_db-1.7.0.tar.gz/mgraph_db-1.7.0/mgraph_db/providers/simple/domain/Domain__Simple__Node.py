from mgraph_db.mgraph.domain.Domain__MGraph__Node          import Domain__MGraph__Node
from mgraph_db.providers.simple.models.Model__Simple__Node import Model__Simple__Node


class Domain__Simple__Node(Domain__MGraph__Node):
    node: Model__Simple__Node




