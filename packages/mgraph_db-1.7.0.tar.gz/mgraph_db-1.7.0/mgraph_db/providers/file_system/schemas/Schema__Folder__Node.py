from mgraph_db.providers.file_system.schemas.Schema__File_System__Item import Schema__File_System__Item

class Schema__Folder__Node(Schema__File_System__Item):
    folder_name  : str