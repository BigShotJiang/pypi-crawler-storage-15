from mgraph_db.providers.time_series.schemas.Schema__MGraph__Node__Value__Timestamp__Data import Schema__MGraph__Node__Value__Timestamp__Data
from mgraph_db.mgraph.schemas.Schema__MGraph__Node                                        import Schema__MGraph__Node

class Schema__MGraph__Node__Value__Timestamp(Schema__MGraph__Node):
    node_data: Schema__MGraph__Node__Value__Timestamp__Data