from mgraph_db.mgraph.schemas.Schema__MGraph__Node__Data import Schema__MGraph__Node__Data


class Schema__MGraph__Node__Value__Timezone__Name__Data(Schema__MGraph__Node__Data):
    value: str