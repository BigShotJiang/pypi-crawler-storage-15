from mgraph_db.mgraph.actions.MGraph__Screenshot import MGraph__Screenshot


class MGraph__Time_Series__Screenshot(MGraph__Screenshot):
    pass

