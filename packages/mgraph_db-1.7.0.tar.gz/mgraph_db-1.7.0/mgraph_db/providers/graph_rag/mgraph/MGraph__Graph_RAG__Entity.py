from mgraph_db.mgraph.MGraph import MGraph

class MGraph__Graph_RAG__Entity(MGraph):                    # todo see why this is needed, since at the moment we could just use MGraph
    pass