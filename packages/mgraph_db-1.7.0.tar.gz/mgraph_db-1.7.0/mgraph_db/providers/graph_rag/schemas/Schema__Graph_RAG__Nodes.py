from mgraph_db.mgraph.schemas.Schema__MGraph__Node__Value import Schema__MGraph__Node__Value

class Schema__MGraph__RAG__Node__Source_Id  (Schema__MGraph__Node__Value): pass
class Schema__MGraph__RAG__Node__Text_Id    (Schema__MGraph__Node__Value): pass
class Schema__MGraph__RAG__Node__Entity     (Schema__MGraph__Node__Value): pass
class Schema__MGraph__RAG__Node__Concept    (Schema__MGraph__Node__Value): pass
class Schema__MGraph__RAG__Node__Role       (Schema__MGraph__Node__Value): pass
class Schema__MGraph__RAG__Node__Domain     (Schema__MGraph__Node__Value): pass
class Schema__MGraph__RAG__Node__Standard   (Schema__MGraph__Node__Value): pass
class Schema__MGraph__RAG__Node__Platform   (Schema__MGraph__Node__Value): pass
class Schema__MGraph__RAG__Node__Technology (Schema__MGraph__Node__Value): pass