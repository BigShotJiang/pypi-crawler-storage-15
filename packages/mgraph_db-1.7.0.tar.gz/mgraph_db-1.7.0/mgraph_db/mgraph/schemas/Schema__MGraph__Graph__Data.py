from osbot_utils.type_safe.Type_Safe import Type_Safe

class Schema__MGraph__Graph__Data(Type_Safe):
    pass