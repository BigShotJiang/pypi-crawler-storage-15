from osbot_utils.type_safe.Type_Safe import Type_Safe


class MGraph__Export__Dot__Config__Font(Type_Safe):
    name     : str = None                                                     # Font name
    size     : int = None                                                     # Font size
    color    : str = None