def timestamp():
    raise NotImplementedError
