# popxf metapackage

## Install all popxf packages at once

`pip install popxf` installs all available popxf packages in one go.

This is an empty metapackage for user convenience.
