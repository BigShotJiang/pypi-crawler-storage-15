docs = [
    {
        "path": "../docs/anchor/terraform.md",
    }
]
