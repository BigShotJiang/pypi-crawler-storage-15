import sys
import os
import httpx
from typing import Dict, Any, List
from rich.console import Console

console = Console()

class CIHandler:
    def __init__(self, fail_on: str = "HIGH", format: str = "text"):
        self.fail_on = fail_on.upper()
        self.format = format.lower()
        self.risk_levels = {"CRITICAL": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1, "SAFE": 0, "ACCEPTED": 0}
        self.threshold = self.risk_levels.get(self.fail_on, 3)

    async def comment_on_pr(self, message: str):
        token = os.getenv("GITHUB_TOKEN")
        repo = os.getenv("GITHUB_REPOSITORY")
        ref = os.getenv("GITHUB_REF") 
        
        if not token or not repo:
            if self.format == "github":
                print("::warning::Detected GitHub Actions but missing GITHUB_TOKEN or GITHUB_REPOSITORY for PR comments.")
            return

        pr_number = None
        if "GITHUB_PR_NUMBER" in os.environ:
             pr_number = os.environ["GITHUB_PR_NUMBER"]
        elif ref and "refs/pull/" in ref:
             try:
                 pr_number = ref.split("/")[2]
             except: pass
        
        if not pr_number:
            return

        url = f"https://api.github.com/repos/{repo}/issues/{pr_number}/comments"
        
        headers = {
            "Authorization": f"Bearer {token}",
            "Accept": "application/vnd.github.v3+json"
        }
        
        try:
           async with httpx.AsyncClient() as client:
                resp = await client.post(url, json={"body": message}, headers=headers)
                if resp.status_code == 201:
                    console.print(f"[green][+] Successfully commented on PR #{pr_number}[/]")
                else:
                    console.print(f"[yellow][!] Failed to comment on PR: {resp.status_code} {resp.text}[/]")
        except Exception as e:
            console.print(f"[red][!] Error commenting on PR: {e}[/]")

    async def evaluate(self, report: Dict[str, Any], diff: Dict[str, Any] = None) -> None:
        failure_reasons = []
        findings = report.get("findings", {})

        if findings.get("auth", {}).get("leaked"):
            failure_reasons.append("Auth Leak Detected")
            self._print_error("Auth Leak Detected: Public access to users table!", "CRITICAL")

        rls_issues = findings.get("rls", [])
        for r in rls_issues:
            risk = r.get("risk", "SAFE")
            if self.risk_levels.get(risk, 0) >= self.threshold:
                failure_reasons.append(f"RLS Issue: {r['table']} ({risk})")
                self._print_error(f"RLS Risk in {r['table']}: {risk}", risk)

        rpc_issues = findings.get("rpc", [])
        for r in rpc_issues:
            risk = r.get("risk", "SAFE")
            if self.risk_levels.get(risk, 0) >= self.threshold:
                failure_reasons.append(f"RPC Issue: {r['name']} ({risk})")
                self._print_error(f"RPC Risk in {r['name']}: {risk}", risk)
                
        for category, items in findings.items():
            if category in ["auth", "rls", "rpc"]: continue
            if isinstance(items, list):
                for item in items:
                    if isinstance(item, dict):
                        risk = item.get("risk", "SAFE")
                        if self.risk_levels.get(risk, 0) >= self.threshold:
                            failure_reasons.append(f"{category.title()} Issue ({risk})")
                            self._print_error(f"{category.title()} Risk: {item.get('issue', 'Unknown')} ({risk})", risk)

        if diff:
            new_rls = diff.get("rls", {}).get("new", [])
            if new_rls:
                failure_reasons.append(f"{len(new_rls)} New RLS Regressions")
                for r in new_rls:
                    self._print_error(f"Regression: New RLS issue in {r['table']}", r.get('risk', 'UNKNOWN'))
        
        summary_md = f"## 🛡️ SSF Security Scan Report\n\n"
        if failure_reasons:
            summary_md += f"❌ **Scan Failed**: Found {len(failure_reasons)} critical/high issues.\n\n"
            summary_md += "| Issue | Severity |\n|---|---|\n"
            for fr in failure_reasons:
                 sev = fr.split("(")[-1].replace(")", "") if "(" in fr else "HIGH"
                 summary_md += f"| {fr.split('(')[0]} | {sev} |\n"
        else:
            summary_md += "✅ **Scan Passed**: No issues found meeting risk threshold.\n"

        if self.format == "github":
            await self.comment_on_pr(summary_md)

        if failure_reasons:
            if self.format == "text":
                console.print(f"\n[bold red]❌ CI Failure: {len(failure_reasons)} issues found.[/]")
            sys.exit(1)
        else:
            if self.format == "text":
                console.print("\n[bold green]✔ CI Passed: No issues found meeting failure criteria.[/]")
            sys.exit(0)

    def _print_error(self, message: str, level: str):
        if self.format == "github":
            print(f"::error title=SSF {level}::{message}")
        else:
            console.print(f"[red][!] {message}[/]")