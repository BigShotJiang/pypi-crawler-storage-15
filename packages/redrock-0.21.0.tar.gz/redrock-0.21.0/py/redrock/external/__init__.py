"""
redrock.external
================

This provides interfaces to actual data files.
"""
