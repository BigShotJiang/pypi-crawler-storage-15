"""
redrock
=======

Redrock redshift fitter.
"""

from __future__ import absolute_import, division, print_function

from ._version import __version__
