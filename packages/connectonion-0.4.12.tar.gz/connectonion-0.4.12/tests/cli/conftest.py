import pytest

# Mark all tests in this folder as CLI tests
pytestmark = pytest.mark.cli

