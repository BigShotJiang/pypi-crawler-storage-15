On some Manufacturing orders, we need to block them in "progress" on a
work operation for some time before being able to continue the process
or close the MO.

This module allow to set a delay on a work order operation and to block
changes on the MO until the delay is over.
