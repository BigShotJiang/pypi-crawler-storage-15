To use this module, you need to:

1.  Go to *Manufacturing* and create an Operation.
2.  Check the case blocking stage on the Operation to use blocking time.
3.  Set the time (in hours) to block the stage.
