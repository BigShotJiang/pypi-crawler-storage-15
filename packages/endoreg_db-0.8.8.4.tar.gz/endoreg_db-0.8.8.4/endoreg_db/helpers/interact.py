from endoreg_db.models import EndoscopyProcessor
from django.core.management.base import BaseCommand
from typing import TYPE_CHECKING
from django.db.models import QuerySet


