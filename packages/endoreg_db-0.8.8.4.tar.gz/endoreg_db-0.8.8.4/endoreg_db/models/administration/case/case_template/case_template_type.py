"""Deprecated case template type model has been removed."""

__all__: list[str] = []
