"""Deprecated case template models have been removed."""

__all__: list[str] = []
