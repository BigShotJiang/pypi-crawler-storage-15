/**
 * Load controllers for dependency resolver
 */
$(document).ready(function() {
    $('.resolve').on('click', resolveDependenciesType);
});
