import requests, json, zlib
import numpy as np
import msgpack
from .crypto import get_checksum, json_zip, json_unzip
from .exceptions import raise_exception

class Index:
    def __init__(self, name:str, key:str, token:str, url:str, version:int=1, params=None):
        self.name = name
        self.key = key
        self.token = token
        self.url = url
        self.version = version
        self.checksum = get_checksum(self.key)
        self.lib_token = params["lib_token"]
        self.count = params["total_elements"]
        self.space_type = params["space_type"]
        self.dimension = params["dimension"]
        self.precision = "float16" if params["use_fp16"] else "float32"
        self.M = params["M"]

    def __str__(self):
        return self.name
    
    def _normalize_vector(self, vector):
        # Convert to numpy array if not already
        vector = np.array(vector, dtype=np.float32)
        # Check dimension of the vector
        if vector.ndim != 1 or vector.shape[0] != self.dimension:
            raise ValueError(f"Vector dimension mismatch: expected {self.dimension}, got {vector.shape[0]}")
        # Normalize only if using cosine distance
        if self.space_type != "cosine":
            return vector, 1.0
        norm = np.linalg.norm(vector)
        if norm == 0:
            return vector, 1.0
        normalized_vector = vector / norm
        return normalized_vector, float(norm)

    def upsert(self, input_array):
        """Insert or update vectors in the index.
        
        Args:
            input_array: List of dicts with keys 'id', 'vector', 'meta', 'filter'
            
        Returns:
            Success message string
            
        Raises:
            ValueError: If trying to insert more than 1000 vectors at once
        """
        max_batch_size = 1000
        if len(input_array) > max_batch_size:
            raise ValueError(f"Cannot insert more than {max_batch_size} vectors at a time")
        
        vector_batch_for_api = []
        normalized_vectors = []
        vector_norms = []
        
        # Normalize all vectors first
        for vector_item in input_array:
            normalized_vector, vector_norm = self._normalize_vector(vector_item['vector'])
            normalized_vectors.append(normalized_vector)
            vector_norms.append(vector_norm)

        # Stack vectors into matrix for batch processing
        vectors_matrix = np.vstack(normalized_vectors).astype(np.float32)

        # Prepare batch data for API
        for index, vector_item in enumerate(input_array):
            compressed_metadata = json_zip(data_dict=vector_item.get('meta', {}))

            vector_record = [
                str(vector_item.get('id', '')),
                compressed_metadata,
                json.dumps(vector_item.get('filter', {})),
                float(vector_norms[index]),
                vectors_matrix[index].tolist()
            ]
            vector_batch_for_api.append(vector_record)

        # Serialize and send to API
        serialized_batch = msgpack.packb(vector_batch_for_api, use_bin_type=True, use_single_float=True)
        request_headers = {
            'Authorization': self.token,
            'Content-Type': 'application/msgpack'
        }
        
        response = requests.post(
            f'{self.url}/index/{self.name}/vector/insert', 
            headers=request_headers, 
            data=serialized_batch
        )

        if response.status_code != 200:
            raise_exception(response.status_code, response.text)
        return "Vectors inserted successfully"

    def query(self, vector, top_k=10, filter=None, ef=128, include_vectors=False, log=False):
        """Search for similar vectors in the index.
        
        Args:
            vector: Query vector to search for
            top_k: Number of results to return (max 256)
            filter: Optional filter criteria
            ef: HNSW search parameter (max 1024)
            include_vectors: Whether to include vector data in results
            log: Deprecated parameter (for backwards compatibility)
            
        Returns:
            List of result dictionaries with similarity scores and metadata
        """
        max_top_k = 256
        max_ef_search = 1024
        
        if top_k > max_top_k:
            raise ValueError(f"top_k cannot be greater than {max_top_k}")
        if ef > max_ef_search:
            raise ValueError(f"ef search cannot be greater than {max_ef_search}")

        # Normalize query vector if using cosine distance
        normalized_query_vector, query_norm = self._normalize_vector(vector)

        # Prepare search request
        request_headers = {
            'Authorization': f'{self.token}',
            'Content-Type': 'application/json'
        }

        search_payload = {
            'vector': normalized_query_vector.tolist(),
            'k': top_k,
            'ef': ef,
            'include_vectors': include_vectors
        }

        if filter:
            search_payload['filter'] = json.dumps(filter)

        response = requests.post(
            f'{self.url}/index/{self.name}/search',
            headers=request_headers,
            json=search_payload
        )

        if response.status_code != 200:
            raise_exception(response.status_code, response.text)

        raw_results = msgpack.unpackb(response.content, raw=False)

        # Parse results: [similarity, id, meta, filter, norm, vector]
        processed_results = []

        for raw_result in raw_results:
            similarity_score = raw_result[0]
            vector_id = raw_result[1]
            compressed_metadata = raw_result[2]
            filter_json_string = raw_result[3]
            norm_value = raw_result[4]
            vector_data = raw_result[5] if len(raw_result) > 5 else []

            result_dict = {
                'id': vector_id,
                'similarity': similarity_score,
                'distance': 1.0 - similarity_score,
                'meta': json_unzip(compressed_metadata),
                'norm': norm_value
            }

            if filter_json_string:
                result_dict['filter'] = json.loads(filter_json_string)

            if include_vectors and vector_data:
                result_dict['vector'] = list(vector_data)

            processed_results.append(result_dict)

        return processed_results

    
    def delete_vector(self, id):
        """Delete a single vector by ID.
        
        Args:
            id: ID of the vector to delete
            
        Returns:
            Success message with deletion count
        """
        calculated_checksum = get_checksum(self.key)
        request_headers = {
            'Authorization': f'{self.token}',
        }
        response = requests.delete(
            f'{self.url}/index/{self.name}/vector/{id}/delete', 
            headers=request_headers
        )
        if response.status_code != 200:
            raise_exception(response.status_code, response.text)
        return response.text + " rows deleted"
    
    def delete_with_filter(self, filter):
        """Delete multiple vectors matching a filter criteria.
        
        Args:
            filter: Filter dictionary to match vectors for deletion
            
        Returns:
            Success message with deletion count
        """
        calculated_checksum = get_checksum(self.key)
        request_headers = {
            'Authorization': f'{self.token}',
            'Content-Type': 'application/json'
        }
        deletion_payload = {"filter": filter}
        print(f"Deleting vectors with filter: {filter}")
        
        response = requests.delete(
            f'{self.url}/index/{self.name}/vectors/delete', 
            headers=request_headers, 
            json=deletion_payload
        )
        if response.status_code != 200:
            print(response.text)
            raise_exception(response.status_code, response.text)
        return response.text
    
    def get_vector(self, id):
        """Retrieve a single vector by ID.
        
        Args:
            id: ID of the vector to retrieve
            
        Returns:
            Dictionary containing vector data, metadata, and attributes
        """
        calculated_checksum = get_checksum(self.key)
        request_headers = {
            'Authorization': f'{self.token}',
            'Content-Type': 'application/json'
        }
        
        # Use POST method with the ID in the request body
        response = requests.post(
            f'{self.url}/index/{self.name}/vector/get',
            headers=request_headers,
            json={'id': id}
        )
        
        if response.status_code != 200:
            raise_exception(response.status_code, response.text)
        
        # Parse the msgpack response: [id, meta, filter, norm, vector]
        vector_record = msgpack.unpackb(response.content, raw=False)
        
        vector_result = {
            'id': vector_record[0],
            'meta': json_unzip(vector_record[1]),
            'filter': vector_record[2],
            'norm': vector_record[3],
            'vector': list(vector_record[4])
        }
        
        return vector_result

    def describe(self):
        """Get index metadata and configuration.
        
        Returns:
            Dictionary containing index properties
        """
        index_metadata = {
            "name": self.name,
            "space_type": self.space_type,
            "dimension": self.dimension,
            "count": self.count,
            "precision": self.precision,
            "M": self.M,
        }
        return index_metadata