import requests, re
from typing import List, Optional, Dict
import json

class User:
    """User and authentication management for ND.
    
    Handles user operations, token management, and user type configuration.
    """
    
    def __init__(self, base_url: str = "http://localhost:8080/api/v1", token: str | None = None):
        """Initialize User management client.
        
        Args:
            base_url: API base URL
            token: User authentication token
        """
        self.base_url = base_url.rstrip('/')
        self.token = token

    def set_token(self, auth_token: str) -> None:
        """Set or update the authentication token.
        
        Args:
            auth_token: User authentication token
        """
        self.token = auth_token

    def generate_root_token(self) -> str:
        """Generate a root token (can only be done once per server).
        
        Returns:
            Root token string
            
        Note:
            This operation can only be performed once per server installation.
        """
        response = requests.post(f"{self.base_url}/root/token")
        return response.text

    def create_user(self, username: str, root_token: str) -> str:
        """Create a new user (requires root credentials).
        
        Args:
            username: Username for the new user
            root_token: Root authentication token
            
        Returns:
            User token for the newly created user
        """
        request_headers = {"Authorization": root_token}
        request_payload = {"username": username}
        response = requests.post(
            f"{self.base_url}/users",
            headers=request_headers,
            json=request_payload
        )
        return response.text

    def delete_user(self, username: str) -> str:
        """Delete a user (requires root credentials).
        
        Deletes the user, all their indexes, and all associated tokens.
        
        Args:
            username: Username to delete
            
        Returns:
            Success message
            
        Raises:
            Exception: If not root user or attempting to delete root
        """
        # Verify caller is root user
        current_user = self.token.split(":")[0]
        if current_user != "root":
            raise Exception("Only root user can delete other users")
        if username == "root":
            raise Exception("Cannot delete root user")
        
        request_headers = {"Authorization": self.token}
        response = requests.delete(
            f"{self.base_url}/users/{username}",
            headers=request_headers
        )
        response.raise_for_status()
        return response.text

    def deactivate_user(self, username: str) -> None:
        """Deactivate a user and delete all their tokens (requires root).
        
        Marks the user as inactive and removes all associated tokens.
        
        Args:
            username: Username to deactivate
            
        Raises:
            Exception: If not root user or attempting to deactivate root
        """
        if username == "root":
            raise Exception("Cannot deactivate root user")
        
        current_user = self.token.split(":")[0]
        if current_user != "root":
            raise Exception("Only root user can deactivate other users")
        
        request_headers = {"Authorization": self.token}
        response = requests.post(
            f"{self.base_url}/users/{username}/deactivate",
            headers=request_headers
        )
        response.raise_for_status()

    def generate_token(self, token_name: str) -> str:
        """Generate a new authentication token for the current user.
        
        Args:
            token_name: Name for the new token (alphanumeric and underscore only)
            
        Returns:
            New authentication token string
            
        Raises:
            Exception: If user token not set or token name is invalid
        """
        if self.token is None:
            raise Exception("User token not set. Please set the user token using the set_token method.")
        
        # Validate token name format (alphanumeric and underscore only)
        token_name_pattern = r'^[a-zA-Z0-9_]+$'
        if not re.match(token_name_pattern, token_name):
            raise Exception("Token name should only contain alphanumeric characters and underscore (_)")
        
        request_headers = {"Authorization": self.token}
        request_payload = {"name": token_name}
        response = requests.post(
            f"{self.base_url}/tokens",
            headers=request_headers,
            json=request_payload
        )
        print(response.text)
        response.raise_for_status()
        return response.text

    def list_tokens(self) -> List[Dict]:
        """List all authentication tokens for the current user.
        
        Returns:
            List of token information dictionaries
            
        Raises:
            Exception: If user token not set
        """
        if self.token is None:
            raise Exception("User token not set. Please set the user token using the set_token method.")
        
        request_headers = {"Authorization": self.token}
        response = requests.get(
            f"{self.base_url}/tokens",
            headers=request_headers
        )
        response.raise_for_status()
        tokens_list = response.json()["tokens"]
        return tokens_list

    def delete_token(self, token_name: str) -> None:
        """Delete a specific authentication token.
        
        Args:
            token_name: Name of the token to delete
            
        Raises:
            Exception: If user token not set
        """
        if self.token is None:
            raise Exception("User token not set. Please set the user token using the set_token method.")
        
        request_headers = {"Authorization": self.token}
        response = requests.delete(
            f"{self.base_url}/tokens/{token_name}",
            headers=request_headers
        )
        response.raise_for_status()
    def get_user_info(self, username: str) -> Dict:
        """Get detailed information about a user.
        
        Requires root credentials or querying own user information.
        
        Args:
            username: Username to query
            
        Returns:
            Dictionary containing user information
            
        Raises:
            Exception: If user token not set
        """
        if self.token is None:
            raise Exception("User token not set. Please set the user token using the set_token method.")
        
        request_headers = {"Authorization": self.token}
        response = requests.get(
            f"{self.base_url}/users/{username}/info",
            headers=request_headers
        )
        response.raise_for_status()
        user_info = response.json()
        return user_info

    def get_user_type(self, username: str) -> str:
        """Get the subscription type of a user (Free, Starter, or Pro).
        
        Args:
            username: Username to query
            
        Returns:
            User type string ("Free", "Starter", or "Pro")
            
        Raises:
            Exception: If user token not set
        """
        if self.token is None:
            raise Exception("User token not set. Please set the user token using the set_token method.")
        
        request_headers = {"Authorization": self.token}
        response = requests.get(
            f"{self.base_url}/users/{username}/type",
            headers=request_headers
        )
        response.raise_for_status()
        user_type = response.json()["user_type"]
        return user_type

    def set_user_type(self, username: str, user_type: str) -> None:
        """Set the subscription type of a user (requires root).
        
        Args:
            username: Username to update
            user_type: New user type ("Free", "Starter", or "Pro")
            
        Raises:
            Exception: If not root user, user type invalid, or token not set
        """
        if self.token is None:
            raise Exception("User token not set. Please set the user token using the set_token method.")
        
        current_user = self.token.split(":")[0]
        if current_user != "root":
            raise Exception("Only root user can set user types")
        
        valid_user_types = ["Free", "Starter", "Pro"]
        if user_type not in valid_user_types:
            raise Exception(f"User type must be one of: {', '.join(valid_user_types)}")
        
        request_headers = {"Authorization": self.token}
        request_payload = {"user_type": user_type}
        response = requests.put(
            f"{self.base_url}/users/{username}/type",
            headers=request_headers,
            json=request_payload
        )
        response.raise_for_status()

    def get_all_indices(self) -> List[Dict]:
        """Get a list of all indices across all users (requires root).
        
        Returns:
            List of index information dictionaries
            
        Raises:
            Exception: If not root user or token not set
        """
        if self.token is None:
            raise Exception("User token not set. Please set the user token using the set_token method.")
        
        current_user = self.token.split(":")[0]
        if current_user != "root":
            raise Exception("Only root user can view all indices")
        
        request_headers = {"Authorization": self.token}
        response = requests.get(
            f"{self.base_url}/index/all",
            headers=request_headers
        )
        response.raise_for_status()
        indices_list = response.json()["indices"]
        return indices_list

