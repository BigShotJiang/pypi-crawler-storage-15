# Endee - High-Performance Vector Database

Endee is a high-performance vector database designed for speed and efficiency. It enables rapid Approximate Nearest Neighbor (ANN) searches for applications requiring robust vector search capabilities with advanced filtering and metadata support.

## Key Features

- **Fast ANN Searches**: Efficient similarity searches on vector data using HNSW algorithm
- **Multiple Distance Metrics**: Support for cosine, L2, and inner product distance metrics
- **Metadata Support**: Attach and search with metadata and filters
- **High Performance**: Optimized for speed and efficiency
- **Scalable**: Handle millions of vectors with ease

## Installation

```bash
pip install endee
```

## Quick Start

```python
from endee.endee_client import Endee

# Initialize client with your API token
client = Endee(token="api_token")

# Create a new index
client.create_index(
    name="my_vectors",
    dimension=1536,  # Your vector dimension
    space_type="cosine"  # Distance metric (cosine, l2, ip)
)

# Get index reference
index = client.get_index(name="my_vectors")

# Insert vectors
index.upsert([
    {
        "id": "doc1",
        "vector": [0.1, 0.2, 0.3, ...],  # Your vector data
        "meta": {"text": "Example document", "category": "reference"},
        "filter": {"category": "reference"}
    }
])

# Query similar vectors
results = index.query(
    vector=[0.2, 0.3, 0.4, ...],  # Query vector
    top_k=10,
    filter={"category": "reference"}  # Optional filter
)

# Process results
for item in results:
    print(f"ID: {item['id']}, Similarity: {item['similarity']}")
    print(f"Metadata: {item['meta']}")
```

## Basic Usage

### Initializing the Client

```python
from endee.endee_client import Endee

# Development environment
client = Endee(token="api_token")


```

### Managing Indexes

```python
# List all indexes
indexes = client.list_indexes()

# Create an index with custom parameters
client.create_index(
    name="my_custom_index",
    dimension=384,
    space_type="l2",
    M=32,             # Graph connectivity parameter
    ef_con=200,       # Construction-time parameter
    use_fp16=True     # Use half-precision for storage optimization
)

# Delete an index
client.delete_index("my_index")
```

### Working with Vectors

```python
# Get index reference
index = client.get_index(name="my_index")

# Insert multiple vectors in a batch
index.upsert([
    {
        "id": "item1",
        "vector": [...],  # Your vector
        "meta": {"title": "First document", "tags": ["important"]},
        "filter": {"visibility": "private"}
    },
    {
        "id": "item2",
        "vector": [...],  # Another vector
        "meta": {"title": "Second document"},
        "filter": {"visibility": "public"}
    }
])

# Query with custom parameters
results = index.query(
    vector=[...],      # Query vector
    top_k=5,           # Number of results to return
    filter={"visibility": "public"},  # Filter for matching
    ef=128,            # Runtime parameter for search quality
    include_vectors=True  # Include vector data in results
)

# Delete vectors
index.delete_vector("item1")
index.delete_with_filter({"visibility": "public"})

# Get a specific vector
vector = index.get_vector("item1")
```

## API Reference

### Endee Class
- `__init__(token=None)`: Initialize with optional API token
- `set_token(token)`: Set API token
- `set_base_url(base_url)`: Set custom API endpoint
- `create_index(name, dimension, space_type, ...)`: Create a new index
- `list_indexes()`: List all indexes
- `delete_index(name)`: Delete an index
- `get_index(name)`: Get reference to an index
- `get_user()`: Get user management instance

### Index Class
- `upsert(input_array)`: Insert or update vectors
- `query(vector, top_k, filter, ef, include_vectors)`: Search for similar vectors
- `delete_vector(id)`: Delete a vector by ID
- `delete_with_filter(filter)`: Delete vectors matching a filter
- `get_vector(id)`: Get a specific vector
- `describe()`: Get index statistics and info

## License

MIT License
