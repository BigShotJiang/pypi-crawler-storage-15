#!/usr/bin/env python3
"""
Oscilloscope operations implementation for both PicoScope and Rigol devices.

This script handles:
- enable/disable channel
- start/stop/start_single capture
- force trigger

For PicoScope: Uses WebSocket commands to the oscilloscope-daemon
For Rigol: Uses VISA/SCPI commands via the Net/Mapper infrastructure
"""

import json
import os
import sys
import asyncio

# Constants
LOCAL_NETS_PATH = "/etc/lager/saved_nets.json"
DAEMON_HOST = "localhost"
DAEMON_COMMAND_PORT = 8085

# ANSI color codes
GREEN = '\033[92m'
RED = '\033[91m'
YELLOW = '\033[93m'
RESET = '\033[0m'


def load_saved_nets():
    """Load nets from the saved nets file."""
    try:
        with open(LOCAL_NETS_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return []
    except Exception as e:
        print(f"{RED}Error loading saved nets: {e}{RESET}", file=sys.stderr)
        return []


def get_net_info(netname):
    """Get net info by name from saved nets."""
    nets = load_saved_nets()
    for net in nets:
        if net.get("name") == netname and net.get("role") == "scope":
            return net
    return None


def is_picoscope(net_info):
    """Check if the net is a PicoScope based on instrument name."""
    if not net_info:
        return False
    instrument = net_info.get("instrument", "").lower()
    return "pico" in instrument or "picoscope" in instrument


def is_rigol(net_info):
    """Check if the net is a Rigol oscilloscope."""
    if not net_info:
        return False
    instrument = net_info.get("instrument", "").lower()
    return "rigol" in instrument or "mso" in instrument


# ============ PicoScope operations (via WebSocket daemon) ============

def send_command_pico(command: dict) -> dict:
    """Send a command to the PicoScope daemon via WebSocket."""
    try:
        import websockets
    except ImportError:
        return {"error": "websockets library not installed"}

    async def send_async():
        uri = f"ws://{DAEMON_HOST}:{DAEMON_COMMAND_PORT}"
        try:
            async with websockets.connect(uri, close_timeout=5) as ws:
                await ws.send(json.dumps(command))
                response = await asyncio.wait_for(ws.recv(), timeout=10.0)
                return json.loads(response)
        except ConnectionRefusedError:
            return {"error": "Oscilloscope daemon not running"}
        except asyncio.TimeoutError:
            return {"error": "Timeout waiting for daemon response"}
        except Exception as e:
            return {"error": f"Communication error: {str(e)}"}

    return asyncio.get_event_loop().run_until_complete(send_async())


def map_channel_pico(channel):
    """Map channel number/letter to PicoScope daemon format."""
    channel_str = str(channel)
    if channel_str in ("A", "1"):
        return {"Alphabetic": "A"}
    elif channel_str in ("B", "2"):
        return {"Alphabetic": "B"}
    elif channel_str in ("C", "3"):
        return {"Alphabetic": "C"}
    elif channel_str in ("D", "4"):
        return {"Alphabetic": "D"}
    return {"Alphabetic": "A"}


def enable_channel_pico(channel):
    """Enable a PicoScope channel."""
    response = send_command_pico({
        "command": "EnableChannel",
        "channel": map_channel_pico(channel)
    })
    if "error" in response:
        print(f"{RED}Error enabling channel: {response['error']}{RESET}")
        return False
    print(f"{GREEN}Channel {channel} enabled{RESET}")
    return True


def disable_channel_pico(channel):
    """Disable a PicoScope channel."""
    response = send_command_pico({
        "command": "DisableChannel",
        "channel": map_channel_pico(channel)
    })
    if "error" in response:
        print(f"{RED}Error disabling channel: {response['error']}{RESET}")
        return False
    print(f"{GREEN}Channel {channel} disabled{RESET}")
    return True


def start_capture_pico():
    """Start PicoScope capture."""
    response = send_command_pico({
        "command": "StartAcquisition",
        "trigger_position_percent": 50.0
    })
    if "error" in response:
        print(f"{RED}Error starting capture: {response['error']}{RESET}")
        return False
    print(f"{GREEN}Capture started{RESET}")
    return True


def stop_capture_pico():
    """Stop PicoScope capture."""
    response = send_command_pico({"command": "StopAcquisition"})
    if "error" in response:
        print(f"{RED}Error stopping capture: {response['error']}{RESET}")
        return False
    print(f"{GREEN}Capture stopped{RESET}")
    return True


def start_single_pico():
    """Start single capture on PicoScope."""
    # First set capture mode to single
    response = send_command_pico({
        "command": "SetCaptureMode",
        "capture_mode": "single"
    })
    if "error" in response:
        print(f"{YELLOW}Warning: Could not set single mode: {response['error']}{RESET}")

    # Then start acquisition
    response = send_command_pico({
        "command": "StartAcquisition",
        "trigger_position_percent": 50.0
    })
    if "error" in response:
        print(f"{RED}Error starting single capture: {response['error']}{RESET}")
        return False
    print(f"{GREEN}Single capture started{RESET}")
    return True


def force_trigger_pico():
    """Force trigger on PicoScope."""
    response = send_command_pico({"command": "ForceTrigger"})
    if "error" in response:
        print(f"{RED}Error forcing trigger: {response['error']}{RESET}")
        return False
    print(f"{GREEN}Trigger forced{RESET}")
    return True


# ============ Rigol operations (via VISA/SCPI) ============

def get_rigol_net(netname):
    """Get a Rigol Net object using Net.get()."""
    from lager.pcb.net import Net
    from lager.pcb.constants import NetType

    # Get the net using Net.get() which handles loading from saved nets
    net = Net.get(netname, NetType.Analog)
    return net


def enable_channel_rigol(netname):
    """Enable a Rigol scope channel."""
    try:
        net = get_rigol_net(netname)
        net.enable()
        print(f"{GREEN}Channel enabled{RESET}")
        return True
    except Exception as e:
        print(f"{RED}Error enabling channel: {e}{RESET}")
        return False


def disable_channel_rigol(netname):
    """Disable a Rigol scope channel."""
    try:
        net = get_rigol_net(netname)
        net.disable()
        print(f"{GREEN}Channel disabled{RESET}")
        return True
    except Exception as e:
        print(f"{RED}Error disabling channel: {e}{RESET}")
        return False


def start_capture_rigol(netname):
    """Start Rigol scope capture."""
    try:
        net = get_rigol_net(netname)
        net.start_capture()
        print(f"{GREEN}Capture started{RESET}")
        return True
    except Exception as e:
        print(f"{RED}Error starting capture: {e}{RESET}")
        return False


def stop_capture_rigol(netname):
    """Stop Rigol scope capture."""
    try:
        net = get_rigol_net(netname)
        net.stop_capture()
        print(f"{GREEN}Capture stopped{RESET}")
        return True
    except Exception as e:
        print(f"{RED}Error stopping capture: {e}{RESET}")
        return False


def start_single_rigol(netname):
    """Start single capture on Rigol scope."""
    try:
        net = get_rigol_net(netname)
        net.start_single_capture()
        print(f"{GREEN}Single capture started{RESET}")
        return True
    except Exception as e:
        print(f"{RED}Error starting single capture: {e}{RESET}")
        return False


def force_trigger_rigol(netname):
    """Force trigger on Rigol scope."""
    try:
        net = get_rigol_net(netname)
        net.force_trigger()
        print(f"{GREEN}Trigger forced{RESET}")
        return True
    except Exception as e:
        print(f"{RED}Error forcing trigger: {e}{RESET}")
        return False


# ============ Main dispatcher ============

def enable_net(netname):
    """Enable scope channel - dispatches to PicoScope or Rigol."""
    net_info = get_net_info(netname)
    if not net_info:
        print(f"{RED}Net '{netname}' not found or not a scope net{RESET}")
        return False

    channel = net_info.get("pin", 1)

    if is_picoscope(net_info):
        return enable_channel_pico(channel)
    elif is_rigol(net_info):
        return enable_channel_rigol(netname)
    else:
        print(f"{YELLOW}Unknown scope type for {netname}, trying Rigol...{RESET}")
        return enable_channel_rigol(netname)


def disable_net(netname):
    """Disable scope channel - dispatches to PicoScope or Rigol."""
    net_info = get_net_info(netname)
    if not net_info:
        print(f"{RED}Net '{netname}' not found or not a scope net{RESET}")
        return False

    channel = net_info.get("pin", 1)

    if is_picoscope(net_info):
        return disable_channel_pico(channel)
    elif is_rigol(net_info):
        return disable_channel_rigol(netname)
    else:
        print(f"{YELLOW}Unknown scope type for {netname}, trying Rigol...{RESET}")
        return disable_channel_rigol(netname)


def start_capture(netname):
    """Start capture - dispatches to PicoScope or Rigol."""
    net_info = get_net_info(netname)
    if not net_info:
        print(f"{RED}Net '{netname}' not found or not a scope net{RESET}")
        return False

    if is_picoscope(net_info):
        return start_capture_pico()
    elif is_rigol(net_info):
        return start_capture_rigol(netname)
    else:
        print(f"{YELLOW}Unknown scope type for {netname}, trying Rigol...{RESET}")
        return start_capture_rigol(netname)


def stop_capture(netname):
    """Stop capture - dispatches to PicoScope or Rigol."""
    net_info = get_net_info(netname)
    if not net_info:
        print(f"{RED}Net '{netname}' not found or not a scope net{RESET}")
        return False

    if is_picoscope(net_info):
        return stop_capture_pico()
    elif is_rigol(net_info):
        return stop_capture_rigol(netname)
    else:
        print(f"{YELLOW}Unknown scope type for {netname}, trying Rigol...{RESET}")
        return stop_capture_rigol(netname)


def start_single(netname):
    """Start single capture - dispatches to PicoScope or Rigol."""
    net_info = get_net_info(netname)
    if not net_info:
        print(f"{RED}Net '{netname}' not found or not a scope net{RESET}")
        return False

    if is_picoscope(net_info):
        return start_single_pico()
    elif is_rigol(net_info):
        return start_single_rigol(netname)
    else:
        print(f"{YELLOW}Unknown scope type for {netname}, trying Rigol...{RESET}")
        return start_single_rigol(netname)


def force_trigger(netname):
    """Force trigger - dispatches to PicoScope or Rigol."""
    net_info = get_net_info(netname)
    if not net_info:
        print(f"{RED}Net '{netname}' not found or not a scope net{RESET}")
        return False

    if is_picoscope(net_info):
        return force_trigger_pico()
    elif is_rigol(net_info):
        return force_trigger_rigol(netname)
    else:
        print(f"{YELLOW}Unknown scope type for {netname}, trying Rigol...{RESET}")
        return force_trigger_rigol(netname)


def main():
    """Main entry point."""
    command_data = os.environ.get("LAGER_COMMAND_DATA", "{}")

    try:
        data = json.loads(command_data)
    except json.JSONDecodeError as e:
        print(f"{RED}Error parsing command data: {e}{RESET}", file=sys.stderr)
        sys.exit(1)

    action = data.get("action", "")
    params = data.get("params", {})
    netname = params.get("netname")

    if not netname:
        print(f"{RED}No netname provided{RESET}", file=sys.stderr)
        sys.exit(1)

    actions = {
        "enable_net": lambda: enable_net(netname),
        "disable_net": lambda: disable_net(netname),
        "start_capture": lambda: start_capture(netname),
        "stop_capture": lambda: stop_capture(netname),
        "start_single": lambda: start_single(netname),
        "force_trigger": lambda: force_trigger(netname),
    }

    if action in actions:
        success = actions[action]()
        sys.exit(0 if success else 1)
    else:
        print(f"{RED}Unknown action: {action}{RESET}", file=sys.stderr)
        print(f"Available actions: {', '.join(actions.keys())}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
