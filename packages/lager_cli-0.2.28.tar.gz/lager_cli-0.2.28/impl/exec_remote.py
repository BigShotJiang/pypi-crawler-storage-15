#!/usr/bin/env python3
"""
Execute a command on the remote box
"""
import sys
import subprocess

def main():
    if len(sys.argv) < 2:
        print("Error: No command specified", file=sys.stderr)
        sys.exit(1)

    command = sys.argv[1]

    # Execute the command using bash
    result = subprocess.run(
        ['/bin/bash', '-c', command],
        capture_output=False,  # Let output go directly to stdout/stderr
        text=True
    )

    sys.exit(result.returncode)

if __name__ == '__main__':
    main()
