"""
    lager.exec.commands

    Execute commands on remote Lager boxes
"""
import click
from ..config import get_devenv_json
from ..context import get_impl_path
from ..paramtypes import EnvVarType
from ..python.commands import run_python_internal
from ..dut_storage import resolve_and_validate_dut_with_name

def _get_devenv_config_with_defaults(data, path):
    """
    Get DEVENV configuration with sensible defaults if not present.
    Returns a tuple of (devenv_config, is_default)
    """
    if 'DEVENV' in data:
        return data['DEVENV'], False

    # Provide sensible defaults when DEVENV is missing
    default_config = {
        'image': 'lagerdata/devenv-cortexm',
        'mount_dir': '/app',
        'shell': '/bin/bash',
    }
    return default_config, True


@click.command(name='exec', context_settings={"ignore_unknown_options": True})
@click.pass_context
@click.argument('cmd_name', required=False, metavar='[COMMAND]')
@click.argument('extra_args', required=False, nargs=-1, metavar='[EXTRA_ARGS]')
@click.option('--command', help='Command string to execute', metavar='\'<cmdline>\'')
@click.option('--save-as', default=None, help='Save command with this alias', metavar='<alias>', show_default=True)
@click.option('--warn/--no-warn', default=True, help='Warn when overwriting saved command', show_default=True)
@click.option(
    '--env',
    multiple=True, type=EnvVarType(), help='Environment variable (FOO=BAR)')
@click.option(
    '--passenv',
    multiple=True, help='Environment variable to inherit')
@click.option('--mount', '-m', help='Volume to mount', required=False)
@click.option('--interactive/--no-interactive', '-i', is_flag=True, help='Keep STDIN open even if not attached', default=True, show_default=True)
@click.option('--tty/--no-tty', '-t', is_flag=True, help='Allocate a pseudo-TTY', default=True, show_default=True)
@click.option('--user', '-u', help='User to run as', default=None)
@click.option('--group', '-g', help='Group to run as', default=None)
@click.option('--verbose', '-v', is_flag=True, help='Show verbose output including the full docker command')
@click.option('--box', required=True, help='Lagerbox name or IP to run command on')
@click.option('--dut', required=False, hidden=True, help='Lagerbox name or IP (deprecated: use --box)')
def exec_(ctx, cmd_name, extra_args, command, save_as, warn, env, passenv, mount, interactive, tty, user, group, verbose, box, dut):
    """Execute saved or ad-hoc commands on a remote box"""
    if not cmd_name and not command:
        click.echo(exec_.get_help(ctx))
        ctx.exit(0)

    # Use box or dut (box takes precedence)
    target_box = box or dut

    # Resolve and validate the box
    resolved_box, box_name = resolve_and_validate_dut_with_name(ctx, target_box)

    # Determine the command to run
    if command:
        cmd_to_run = command
    elif cmd_name:
        # Need to get DEVENV config to look up saved command
        path, data = get_devenv_json()
        devenv_config, is_default = _get_devenv_config_with_defaults(data, path)
        key = f'cmd.{cmd_name}'
        if key not in devenv_config:
            if is_default:
                raise click.UsageError(
                    f'Command `{cmd_name}` not found.\n'
                    f'No DEVENV configuration found.\n'
                    f'Run `lager devenv add {cmd_name} "<command>"` to save a command\n'
                    f'Or use: lager exec --command \'<command>\' --box {target_box}'
                )
            else:
                raise click.UsageError(
                    f'Command `{cmd_name}` not found.\n'
                    f'Run `lager devenv add {cmd_name} "<command>"` to add it.'
                )
        cmd_to_run = devenv_config.get(key)
    else:
        raise click.UsageError('Must specify either a command name or --command')

    # Add any extra args to the command
    if extra_args:
        cmd_to_run = f"{cmd_to_run} {' '.join(extra_args)}"

    if verbose or ctx.obj.debug:
        click.echo(f'Running on box: {resolved_box}', err=True)
        click.echo(f'Command: {cmd_to_run}', err=True)

    # Run the command on the remote box using run_python_internal
    run_python_internal(
        ctx,
        get_impl_path('exec_remote.py'),
        resolved_box,
        image='',
        env=env,
        passenv=passenv,
        kill=False,
        download=(),
        allow_overwrite=False,
        signum='SIGTERM',
        timeout=0,
        detach=False,
        port=(),
        org=None,
        args=(cmd_to_run,),  # Pass the command as an argument
        dut_name=box_name,
    )
