# Seg2Stream

Real-time pipeline for segmenting text into a sentence stream.
