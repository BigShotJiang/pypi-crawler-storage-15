"""multids package"""

__all__ = ["interfaces", "connectors", "ai"]
__version__ = "0.1.0"

from . import interfaces  # re-exported for convenience
