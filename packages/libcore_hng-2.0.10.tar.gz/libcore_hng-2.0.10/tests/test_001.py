from libcore_hng.testmodule import test_function

print(test_function())
