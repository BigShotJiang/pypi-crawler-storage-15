"""Version information for kittylog."""

__version__ = "2.8.0"
