"""functions and classes for working with designing DEL DNA barcodes"""
