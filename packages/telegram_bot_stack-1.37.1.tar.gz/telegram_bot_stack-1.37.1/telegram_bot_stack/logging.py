"""Comprehensive logging for telegram-bot-stack framework.

This module provides detailed logging for all CLI commands and operations
to help with debugging, monitoring, and issue analysis.
"""

import functools
import json
import logging
import os
import sys
import time
import traceback
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, Optional

# Global logger instance
_framework_logger: Optional[logging.Logger] = None
_log_file_handler: Optional[logging.FileHandler] = None

# Logger mode: "disabled", "console", or "full" (default)
_configured_logger_mode: Optional[str] = None


def _get_logger_mode() -> str:
    """Read current logger mode from environment."""
    return os.getenv("SYSTEM_LOGGING", "full").lower()


def get_logger() -> logging.Logger:
    """Get or create the framework logger instance.

    Logger mode is controlled by SYSTEM_LOGGING environment variable:
    - "disabled": No logging at all
    - "console": Console output only (for tests)
    - "full": Console + file logging (default)

    Returns:
        Configured logger instance
    """
    global _framework_logger, _log_file_handler, _configured_logger_mode

    logger_mode = _get_logger_mode()

    if _framework_logger is not None and _configured_logger_mode == logger_mode:
        return _framework_logger

    if _framework_logger is not None and _configured_logger_mode != logger_mode:
        close_logger()

    # Create logger
    _framework_logger = logging.getLogger("telegram_bot_stack")
    _framework_logger.setLevel(logging.DEBUG)
    _framework_logger.propagate = False  # Prevent propagation to root logger

    # Prevent duplicate handlers
    if _framework_logger.handlers:
        return _framework_logger

    # Formatter with detailed information
    detailed_formatter = logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    if logger_mode == "disabled":
        # No logging at all
        _framework_logger.addHandler(logging.NullHandler())
    elif logger_mode == "console":
        # Console output only (for tests)
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(logging.INFO)
        console_handler.setFormatter(detailed_formatter)
        _framework_logger.addHandler(console_handler)
    else:
        # Full logging: console + file (default)
        try:
            # Create logs directory if it doesn't exist
            logs_dir = Path.cwd() / ".logs"
            logs_dir.mkdir(exist_ok=True)

            # Create log file with timestamp
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            log_file = logs_dir / f"framework_{timestamp}.log"

            _log_file_handler = logging.FileHandler(log_file, encoding="utf-8")
            _log_file_handler.setLevel(logging.DEBUG)
            _log_file_handler.setFormatter(detailed_formatter)
            _framework_logger.addHandler(_log_file_handler)

            # Also add console handler
            console_handler = logging.StreamHandler(sys.stdout)
            console_handler.setLevel(logging.INFO)
            console_handler.setFormatter(detailed_formatter)
            _framework_logger.addHandler(console_handler)

            _framework_logger.info(
                f"Framework logger initialized. Log file: {log_file}"
            )
        except Exception as e:
            # If file creation fails, fallback to console only
            console_handler = logging.StreamHandler(sys.stdout)
            console_handler.setLevel(logging.INFO)
            console_handler.setFormatter(detailed_formatter)
            _framework_logger.addHandler(console_handler)
            _framework_logger.warning(f"Could not create log file: {e}")

    _configured_logger_mode = logger_mode

    return _framework_logger


def close_logger() -> None:
    """Close and cleanup the logger (useful for tests).

    This function closes all handlers and resets the global logger state.
    """
    global _framework_logger, _log_file_handler, _configured_logger_mode

    if _framework_logger is not None:
        # Remove and close all handlers
        for handler in _framework_logger.handlers[:]:
            handler.close()
            _framework_logger.removeHandler(handler)

        _framework_logger = None
        _log_file_handler = None
        _configured_logger_mode = None


def log_command_start(
    command_name: str,
    parameters: Dict[str, Any],
    context: Optional[Dict[str, Any]] = None,
) -> None:
    """Log the start of a command execution.

    Args:
        command_name: Name of the command being executed
        parameters: Command parameters/options
        context: Additional context (working directory, environment, etc.)
    """
    if _get_logger_mode() == "disabled":
        return

    logger = get_logger()
    context = context or {}

    log_data = {
        "event": "command_start",
        "command": command_name,
        "timestamp": datetime.now().isoformat(),
        "parameters": _sanitize_parameters(parameters),
        "context": {
            "cwd": str(Path.cwd()),
            "python_version": sys.version,
            "platform": sys.platform,
            **context,
        },
    }

    logger.info(f"COMMAND START: {command_name}")
    logger.debug(f"Command details: {json.dumps(log_data, indent=2, default=str)}")


def log_command_end(
    command_name: str,
    success: bool,
    duration_seconds: float,
    result: Optional[Dict[str, Any]] = None,
    error: Optional[Exception] = None,
) -> None:
    """Log the end of a command execution.

    Args:
        command_name: Name of the command that finished
        success: Whether the command succeeded
        duration_seconds: How long the command took
        result: Result data (if successful)
        error: Exception if command failed
    """
    if _get_logger_mode() == "disabled":
        return

    logger = get_logger()

    log_data = {
        "event": "command_end",
        "command": command_name,
        "timestamp": datetime.now().isoformat(),
        "success": success,
        "duration_seconds": duration_seconds,
        "result": result,
    }

    if error:
        log_data["error"] = {
            "type": type(error).__name__,
            "message": str(error),
            "traceback": traceback.format_exc(),
        }

    status = "SUCCESS" if success else "FAILED"
    logger.info(f"COMMAND END: {command_name} - {status} ({duration_seconds:.2f}s)")
    logger.debug(f"Command result: {json.dumps(log_data, indent=2, default=str)}")

    if error:
        logger.error(f"Command failed: {error}", exc_info=True)


def log_step(
    step_name: str,
    step_description: str,
    success: Optional[bool] = None,
    details: Optional[Dict[str, Any]] = None,
    error: Optional[Exception] = None,
) -> None:
    """Log a step within a command execution.

    Args:
        step_name: Name/identifier of the step
        step_description: Human-readable description
        success: Whether the step succeeded (None if in progress)
        details: Additional step details
        error: Exception if step failed
    """
    if _get_logger_mode() == "disabled":
        return

    logger = get_logger()

    log_data = {
        "event": "step",
        "step": step_name,
        "description": step_description,
        "timestamp": datetime.now().isoformat(),
        "success": success,
        "details": details or {},
    }

    if error:
        log_data["error"] = {
            "type": type(error).__name__,
            "message": str(error),
            "traceback": traceback.format_exc(),
        }

    status = ""
    if success is True:
        status = " ✓"
    elif success is False:
        status = " ✗"

    logger.info(f"STEP{status}: {step_name} - {step_description}")
    logger.debug(f"Step details: {json.dumps(log_data, indent=2, default=str)}")

    if error:
        logger.error(f"Step failed: {error}", exc_info=True)


def log_operation(
    operation_name: str,
    operation_type: str,
    parameters: Optional[Dict[str, Any]] = None,
    result: Optional[Any] = None,
    error: Optional[Exception] = None,
) -> None:
    """Log a specific operation (file operation, API call, etc.).

    Args:
        operation_name: Name of the operation
        operation_type: Type of operation (file_create, file_read, api_call, etc.)
        parameters: Operation parameters
        result: Operation result
        error: Exception if operation failed
    """
    if _get_logger_mode() == "disabled":
        return

    logger = get_logger()

    log_data = {
        "event": "operation",
        "operation": operation_name,
        "type": operation_type,
        "timestamp": datetime.now().isoformat(),
        "parameters": _sanitize_parameters(parameters or {}),
    }

    if result is not None:
        log_data["result"] = _sanitize_result(result)

    if error:
        log_data["error"] = {
            "type": type(error).__name__,
            "message": str(error),
            "traceback": traceback.format_exc(),
        }

    logger.debug(f"OPERATION: {operation_type} - {operation_name}")
    logger.debug(f"Operation details: {json.dumps(log_data, indent=2, default=str)}")

    if error:
        logger.error(f"Operation failed: {error}", exc_info=True)


def log_file_operation(
    operation: str,
    file_path: Path,
    success: bool,
    details: Optional[Dict[str, Any]] = None,
    error: Optional[Exception] = None,
) -> None:
    """Log a file operation.

    Args:
        operation: Type of operation (create, read, write, delete, etc.)
        file_path: Path to the file
        success: Whether operation succeeded
        details: Additional details (size, permissions, etc.)
        error: Exception if operation failed
    """
    if _get_logger_mode() == "disabled":
        return

    logger = get_logger()

    log_data = {
        "event": "file_operation",
        "operation": operation,
        "file_path": str(file_path),
        "file_exists": file_path.exists(),
        "timestamp": datetime.now().isoformat(),
        "success": success,
        "details": details or {},
    }

    if file_path.exists():
        try:
            stat = file_path.stat()
            log_data["file_info"] = {
                "size": stat.st_size,
                "is_file": file_path.is_file(),
                "is_dir": file_path.is_dir(),
            }
        except Exception:
            pass

    if error:
        log_data["error"] = {
            "type": type(error).__name__,
            "message": str(error),
            "traceback": traceback.format_exc(),
        }

    status = "✓" if success else "✗"
    logger.info(f"FILE {status}: {operation} - {file_path}")
    logger.debug(
        f"File operation details: {json.dumps(log_data, indent=2, default=str)}"
    )

    if error:
        logger.error(f"File operation failed: {error}", exc_info=True)


def log_subprocess_command(
    command: list[str],
    cwd: Optional[Path] = None,
    success: bool = False,
    returncode: Optional[int] = None,
    stdout: Optional[str] = None,
    stderr: Optional[str] = None,
    duration: Optional[float] = None,
    error: Optional[Exception] = None,
) -> None:
    """Log a subprocess command execution.

    Args:
        command: Command and arguments as list
        cwd: Working directory
        success: Whether command succeeded
        returncode: Process return code
        stdout: Standard output (truncated if too long)
        stderr: Standard error (truncated if too long)
        duration: Command duration in seconds
        error: Exception if command failed
    """
    if _get_logger_mode() == "disabled":
        return

    logger = get_logger()

    # Truncate long output
    max_output_length = 1000
    if stdout and len(stdout) > max_output_length:
        stdout = (
            stdout[:max_output_length] + f"\n... (truncated, {len(stdout)} total chars)"
        )
    if stderr and len(stderr) > max_output_length:
        stderr = (
            stderr[:max_output_length] + f"\n... (truncated, {len(stderr)} total chars)"
        )

    log_data: Dict[str, Any] = {
        "event": "subprocess",
        "command": command,
        "cwd": str(cwd) if cwd else None,
        "timestamp": datetime.now().isoformat(),
        "success": success,
        "returncode": returncode,
        "duration_seconds": duration,
        "stdout": stdout,
        "stderr": stderr,
    }

    if error:
        log_data["error"] = {
            "type": type(error).__name__,
            "message": str(error),
            "traceback": traceback.format_exc(),
        }

    status = "✓" if success else "✗"
    cmd_str = " ".join(str(c) for c in command)
    logger.info(f"SUBPROCESS {status}: {cmd_str}")
    logger.debug(f"Subprocess details: {json.dumps(log_data, indent=2, default=str)}")

    if error:
        logger.error(f"Subprocess failed: {error}", exc_info=True)


def log_deployment_operation(
    operation: str,
    deployment_method: str,
    bot_name: str,
    vps_host: str,
    success: bool,
    details: Optional[Dict[str, Any]] = None,
    error: Optional[Exception] = None,
) -> None:
    """Log a deployment operation.

    Args:
        operation: Type of operation (init, up, update, down, etc.)
        deployment_method: Deployment method (docker, systemd)
        bot_name: Name of the bot
        vps_host: VPS hostname/IP
        success: Whether operation succeeded
        details: Additional deployment details
        error: Exception if operation failed
    """
    if _get_logger_mode() == "disabled":
        return

    logger = get_logger()

    log_data = {
        "event": "deployment",
        "operation": operation,
        "deployment_method": deployment_method,
        "bot_name": bot_name,
        "vps_host": vps_host,
        "timestamp": datetime.now().isoformat(),
        "success": success,
        "details": details or {},
    }

    if error:
        log_data["error"] = {
            "type": type(error).__name__,
            "message": str(error),
            "traceback": traceback.format_exc(),
        }

    status = "✓" if success else "✗"
    logger.info(
        f"DEPLOYMENT {status}: {operation} - {bot_name} on {vps_host} "
        f"({deployment_method})"
    )
    logger.debug(f"Deployment details: {json.dumps(log_data, indent=2, default=str)}")

    if error:
        logger.error(f"Deployment failed: {error}", exc_info=True)


def log_validation_check(
    check_name: str,
    check_type: str,
    passed: bool,
    message: str,
    details: Optional[Dict[str, Any]] = None,
) -> None:
    """Log a validation check.

    Args:
        check_name: Name of the check
        check_type: Type of check (file_exists, env_var, dependency, etc.)
        passed: Whether check passed
        message: Check result message
        details: Additional check details
    """
    if _get_logger_mode() == "disabled":
        return

    logger = get_logger()

    log_data = {
        "event": "validation",
        "check": check_name,
        "type": check_type,
        "timestamp": datetime.now().isoformat(),
        "passed": passed,
        "message": message,
        "details": details or {},
    }

    status = "✓" if passed else "✗"
    logger.info(f"VALIDATION {status}: {check_name} - {message}")
    logger.debug(f"Validation details: {json.dumps(log_data, indent=2, default=str)}")


def _sanitize_parameters(params: Dict[str, Any]) -> Dict[str, Any]:
    """Sanitize parameters to remove sensitive information.

    Args:
        params: Parameters dictionary

    Returns:
        Sanitized parameters
    """
    sensitive_keys = {
        "password",
        "token",
        "secret",
        "key",
        "api_key",
        "ssh_key",
        "bot_token",
        "bot_token_env",
    }

    sanitized: Dict[str, Any] = {}
    for key, value in params.items():
        key_lower = key.lower()
        if any(sensitive in key_lower for sensitive in sensitive_keys):
            sanitized[key] = "***REDACTED***"
        elif isinstance(value, dict):
            sanitized[key] = _sanitize_parameters(value)
        elif isinstance(value, (list, tuple)):
            sanitized[key] = [
                _sanitize_parameters(item) if isinstance(item, dict) else item
                for item in value
            ]
        else:
            sanitized[key] = value

    return sanitized


def _sanitize_result(result: Any) -> Any:
    """Sanitize result to remove sensitive information.

    Args:
        result: Result value

    Returns:
        Sanitized result
    """
    if isinstance(result, dict):
        return _sanitize_parameters(result)
    elif isinstance(result, (list, tuple)):
        return [
            _sanitize_result(item) if isinstance(item, (dict, list, tuple)) else item
            for item in result
        ]
    else:
        return result


def get_log_file_path() -> Optional[Path]:
    """Get the path to the current log file.

    Returns:
        Path to log file or None if logger not initialized
    """
    global _log_file_handler
    if _log_file_handler and hasattr(_log_file_handler, "baseFilename"):
        return Path(_log_file_handler.baseFilename)
    return None


def log_command(func: Callable) -> Callable:
    """Decorator to automatically log command execution.

    Wraps a Click command function to automatically log start, end, and errors.

    Args:
        func: Click command function to wrap

    Returns:
        Wrapped function with logging
    """

    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        command_name = func.__name__
        start_time = time.time()
        success = False
        error = None
        result = None

        # Extract parameters for logging
        parameters = {}
        if args:
            parameters["args"] = args
        parameters.update(kwargs)

        # Log command start
        log_command_start(
            command_name=command_name,
            parameters=parameters,
            context={
                "function": func.__name__,
                "module": func.__module__,
            },
        )

        try:
            # Execute command
            result = func(*args, **kwargs)
            success = True
            return result
        except Exception as e:
            error = e
            success = False
            raise
        finally:
            # Log command end
            duration = time.time() - start_time
            log_command_end(
                command_name=command_name,
                success=success,
                duration_seconds=duration,
                result={"return_value": str(result) if result is not None else None},
                error=error,
            )

    return wrapper
