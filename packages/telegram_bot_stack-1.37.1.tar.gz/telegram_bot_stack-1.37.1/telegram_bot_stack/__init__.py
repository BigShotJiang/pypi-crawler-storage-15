"""telegram-bot-stack: Reusable framework for building Telegram bots.

This package provides a solid foundation for building Telegram bots with
common patterns and best practices built-in.

Key Features:
    - User and admin management out of the box
    - Multiple storage backends (JSON, Memory)
    - Command handling infrastructure
    - Graceful shutdown handling
    - Easy customization through hooks

Quick Start:
    >>> from telegram_bot_stack import BotBase
    >>> from telegram_bot_stack.storage import JSONStorage
    >>>
    >>> # Create storage and bot
    >>> storage = JSONStorage(base_dir="data")
    >>> bot = BotBase(storage, bot_name="My Bot")
    >>>
    >>> # Customize behavior by overriding hooks
    >>> class MyBot(BotBase):
    ...     def get_welcome_message(self) -> str:
    ...         return "Welcome to My Custom Bot!"

For more information, see the documentation at:
https://github.com/sensiloles/telegram-bot-stack
"""

from .admin_manager import AdminManager
from .bot_base import BotBase
from .decorators import rate_limit
from .error_reporter import ErrorReporter, get_error_reporter, report_error
from .storage import (
    JSONStorage,
    MemoryStorage,
    Storage,
    StorageBackend,
    create_storage,
)
from .user_manager import UserManager

__version__ = "1.37.1"
__author__ = "telegram-bot-stack contributors"
__license__ = "Business Source License 1.1"

# Minimum supported version enforcement
MINIMUM_SUPPORTED_VERSION = "1.35.1"


def _parse_version(version_str: str) -> tuple:
    """Parse version string to tuple for comparison.

    Args:
        version_str: Version string like '1.35.1'

    Returns:
        Tuple of (major, minor, patch) integers
    """
    try:
        parts = version_str.split(".")
        return tuple(int(p) for p in parts[:3])
    except (ValueError, AttributeError):
        return (0, 0, 0)


def _check_version() -> None:
    """Verify that the current version meets minimum requirements.

    This function is called automatically on import to prevent usage of
    deprecated versions that may have security issues or critical bugs.

    Raises:
        RuntimeError: If current version is below minimum supported version
    """
    current = _parse_version(__version__)
    minimum = _parse_version(MINIMUM_SUPPORTED_VERSION)

    if current < minimum:
        error_msg = (
            f"\n{'='*80}\n"
            f"❌ ERROR: telegram-bot-stack v{__version__} is DEPRECATED!\n"
            f"\n"
            f"This version is no longer supported due to security and stability issues.\n"
            f"Minimum supported version: v{MINIMUM_SUPPORTED_VERSION}\n"
            f"\n"
            f"Please upgrade immediately:\n"
            f"  pip install --upgrade 'telegram-bot-stack>={MINIMUM_SUPPORTED_VERSION}'\n"
            f"\n"
            f"For more information, visit:\n"
            f"  https://github.com/sensiloles/telegram-bot-stack\n"
            f"{'='*80}\n"
        )
        raise RuntimeError(error_msg)


# Enforce version check on import
_check_version()


__all__ = [
    # Core classes
    "BotBase",
    "UserManager",
    "AdminManager",
    # Decorators
    "rate_limit",
    # Storage
    "StorageBackend",
    "JSONStorage",
    "MemoryStorage",
    "Storage",
    "create_storage",
    # Error reporting
    "ErrorReporter",
    "get_error_reporter",
    "report_error",
    # Metadata
    "__version__",
]
