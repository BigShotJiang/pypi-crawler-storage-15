"""Validate bot configuration and environment."""

import os
import sys
import time
from importlib import metadata as importlib_metadata
from pathlib import Path
from typing import Optional

import click

from telegram_bot_stack.logging import (
    get_logger,
    log_command_end,
    log_command_start,
    log_file_operation,
    log_validation_check,
)


@click.command()
@click.option(
    "--strict/--no-strict",
    default=False,
    help="Exit with error if validation fails",
)
def validate(strict: bool) -> None:
    """Validate bot configuration and environment.

    Checks:
    - BOT_TOKEN is set and valid format
    - Required files exist (bot.py)
    - Python dependencies are installed
    - Storage configuration (if applicable)

    Example:

        telegram-bot-stack validate

        telegram-bot-stack validate --strict
    """
    start_time = time.time()
    get_logger()  # Initialize logger

    # Log command start
    log_command_start(
        command_name="validate",
        parameters={"strict": strict},
    )

    success = False
    error: Optional[Exception] = None

    click.secho("\n🔍 Validating bot configuration...\n", fg="cyan", bold=True)

    errors = []
    warnings = []

    # 1. Check bot.py exists
    bot_file = Path.cwd() / "bot.py"
    log_validation_check(
        "bot_file_exists",
        "file_exists",
        bot_file.exists(),
        "bot.py found" if bot_file.exists() else "bot.py not found",
    )
    if bot_file.exists():
        log_file_operation("read", bot_file, success=True)
        click.secho("✅ bot.py found", fg="green")
    else:
        log_file_operation("read", bot_file, success=False)
        errors.append("bot.py not found in current directory")
        click.secho("❌ bot.py not found", fg="red")

    # 2. Check .env file
    env_file = Path.cwd() / ".env"
    env_exists = env_file.exists()
    log_validation_check(
        "env_file_exists",
        "file_exists",
        env_exists,
        ".env file found" if env_exists else ".env file not found",
    )
    if env_exists:
        log_file_operation("read", env_file, success=True)
        click.secho("✅ .env file found", fg="green")
    else:
        log_file_operation("read", env_file, success=False)
        warnings.append(".env file not found")
        click.secho("⚠️  .env file not found", fg="yellow")

    # 3. Check BOT_TOKEN
    bot_token = os.getenv("BOT_TOKEN")
    if bot_token:
        # Basic validation of token format
        if ":" in bot_token and len(bot_token) > 40:
            log_validation_check(
                "bot_token_valid", "env_var", True, "BOT_TOKEN is set and looks valid"
            )
            click.secho("✅ BOT_TOKEN is set and looks valid", fg="green")
        else:
            log_validation_check(
                "bot_token_valid", "env_var", False, "BOT_TOKEN format looks invalid"
            )
            warnings.append("BOT_TOKEN format looks invalid")
            click.secho("⚠️  BOT_TOKEN format looks invalid", fg="yellow")
    else:
        log_validation_check(
            "bot_token_exists", "env_var", False, "BOT_TOKEN not set in environment"
        )
        errors.append("BOT_TOKEN not set in environment")
        click.secho("❌ BOT_TOKEN not set", fg="red")

    # 4. Check telegram-bot-stack is installed
    try:
        import telegram_bot_stack

        try:
            package_version = importlib_metadata.version("telegram-bot-stack")
        except importlib_metadata.PackageNotFoundError:
            package_version = getattr(telegram_bot_stack, "__version__", "unknown")

        log_validation_check(
            "telegram_bot_stack_installed",
            "dependency",
            True,
            f"telegram-bot-stack installed (v{package_version})",
        )
        click.secho(
            f"✅ telegram-bot-stack installed (v{package_version})",
            fg="green",
        )
    except ImportError:
        log_validation_check(
            "telegram_bot_stack_installed",
            "dependency",
            False,
            "telegram-bot-stack not installed",
        )
        errors.append("telegram-bot-stack not installed")
        click.secho("❌ telegram-bot-stack not installed", fg="red")

    # 5. Check python-telegram-bot is installed
    try:
        import telegram

        _ = telegram  # Mark as used
        log_validation_check(
            "python_telegram_bot_installed",
            "dependency",
            True,
            "python-telegram-bot installed",
        )
        click.secho("✅ python-telegram-bot installed", fg="green")
    except ImportError:
        log_validation_check(
            "python_telegram_bot_installed",
            "dependency",
            False,
            "python-telegram-bot not installed",
        )
        errors.append("python-telegram-bot not installed")
        click.secho("❌ python-telegram-bot not installed", fg="red")

    # 6. Check for common issues
    if bot_file.exists():
        content = bot_file.read_text()

        # Check if BotBase is imported
        if "BotBase" not in content:
            warnings.append("bot.py doesn't seem to import BotBase")
            click.secho("⚠️  bot.py doesn't import BotBase", fg="yellow")

        # Check if storage is configured
        if "Storage" not in content:
            warnings.append("No storage configuration found in bot.py")
            click.secho("⚠️  No storage configuration found", fg="yellow")

    # Summary
    click.echo("\n" + "=" * 70)

    if errors:
        click.secho(
            f"\n❌ Validation failed with {len(errors)} error(s):", fg="red", bold=True
        )
        for err_msg in errors:
            click.secho(f"  • {err_msg}", fg="red")

    if warnings:
        click.secho(f"\n⚠️  {len(warnings)} warning(s):", fg="yellow", bold=True)
        for warn_msg in warnings:
            click.secho(f"  • {warn_msg}", fg="yellow")

    if not errors and not warnings:
        click.secho(
            "\n✅ All checks passed! Your bot is ready to run.", fg="green", bold=True
        )

    click.echo("\n" + "=" * 70 + "\n")

    success = len(errors) == 0
    if not success:
        error = ValueError(
            f"Validation failed with {len(errors)} error(s) and {len(warnings)} warning(s)"
        )

    # Exit with error if strict mode and there are errors
    if strict and errors:
        duration = time.time() - start_time
        log_command_end(
            command_name="validate",
            success=success,
            duration_seconds=duration,
            result={"errors": errors, "warnings": warnings},
            error=error,
        )
        sys.exit(1)

    duration = time.time() - start_time
    log_command_end(
        command_name="validate",
        success=success,
        duration_seconds=duration,
        result={"errors": errors, "warnings": warnings},
        error=error if not success else None,
    )
