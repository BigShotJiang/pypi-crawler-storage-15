"""Automatic error reporting to GitHub Issues for framework bugs.

This module provides functionality to automatically report uncaught exceptions
and errors to the telegram-bot-stack GitHub repository. This helps improve
the framework by catching real-world issues.

Usage:
    Set TELEGRAM_BOT_STACK_ERROR_REPORTING=true in environment to enable.
    Optionally set TELEGRAM_BOT_STACK_GITHUB_TOKEN for authenticated requests
    (increases rate limits).
"""

import logging
import os
import platform
import sys
import traceback
from datetime import datetime
from typing import Any, Optional
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

logger = logging.getLogger(__name__)


class ErrorReporter:
    """Reports framework errors to GitHub Issues automatically.

    This class captures uncaught exceptions and framework errors, then creates
    GitHub issues with relevant debugging information including stack traces,
    system info, and framework version.

    Attributes:
        enabled: Whether error reporting is enabled
        github_token: Optional GitHub token for authenticated API requests
        repo_owner: GitHub repository owner (default: sensiloles)
        repo_name: GitHub repository name (default: telegram-bot-stack)
    """

    GITHUB_API_URL = "https://api.github.com"
    DEFAULT_REPO_OWNER = "sensiloles"
    DEFAULT_REPO_NAME = "telegram-bot-stack"

    def __init__(
        self,
        enabled: Optional[bool] = None,
        github_token: Optional[str] = None,
        repo_owner: Optional[str] = None,
        repo_name: Optional[str] = None,
    ) -> None:
        """Initialize error reporter.

        Args:
            enabled: Enable error reporting (default: from env TELEGRAM_BOT_STACK_ERROR_REPORTING)
            github_token: GitHub token (default: from env TELEGRAM_BOT_STACK_GITHUB_TOKEN)
            repo_owner: Repository owner (default: sensiloles)
            repo_name: Repository name (default: telegram-bot-stack)
        """
        # Check if enabled via environment or parameter
        if enabled is None:
            enabled = os.getenv("TELEGRAM_BOT_STACK_ERROR_REPORTING", "").lower() in (
                "true",
                "1",
                "yes",
            )
        self.enabled = enabled

        # Get GitHub token from env if not provided
        if github_token is None:
            github_token = os.getenv("TELEGRAM_BOT_STACK_GITHUB_TOKEN")
        self.github_token = github_token

        self.repo_owner = repo_owner or self.DEFAULT_REPO_OWNER
        self.repo_name = repo_name or self.DEFAULT_REPO_NAME

        if self.enabled:
            logger.info(
                "✅ Error reporting enabled - Framework errors will be reported to GitHub"
            )
            if not self.github_token:
                logger.info(
                    "💡 Set TELEGRAM_BOT_STACK_GITHUB_TOKEN for higher API rate limits"
                )

    def _get_system_info(self) -> dict[str, Any]:
        """Collect system information for bug report.

        Returns:
            Dictionary with system information
        """
        try:
            from telegram_bot_stack import __version__ as framework_version
        except ImportError:
            framework_version = "unknown"

        return {
            "framework_version": framework_version,
            "python_version": sys.version,
            "platform": platform.platform(),
            "platform_system": platform.system(),
            "platform_release": platform.release(),
            "platform_machine": platform.machine(),
        }

    def _format_issue_body(
        self,
        error: Exception,
        context: Optional[dict[str, Any]] = None,
    ) -> str:
        """Format the GitHub issue body with error details.

        Args:
            error: The exception that occurred
            context: Optional additional context information

        Returns:
            Formatted markdown issue body
        """
        # Get stack trace
        tb_lines = traceback.format_exception(type(error), error, error.__traceback__)
        stack_trace = "".join(tb_lines)

        # Get system info
        sys_info = self._get_system_info()

        # Format issue body
        body_parts = [
            "## 🐛 Automatic Bug Report",
            "",
            "This issue was automatically created by the telegram-bot-stack error reporting system.",
            "",
            "### Error Details",
            f"**Error Type:** `{type(error).__name__}`",
            f"**Error Message:** {str(error)}",
            "",
            "### Stack Trace",
            "```python",
            stack_trace.strip(),
            "```",
            "",
            "### System Information",
            f"- **Framework Version:** `{sys_info['framework_version']}`",
            f"- **Python Version:** `{sys_info['python_version']}`",
            f"- **Platform:** `{sys_info['platform']}`",
            f"- **OS:** `{sys_info['platform_system']} {sys_info['platform_release']}`",
            f"- **Architecture:** `{sys_info['platform_machine']}`",
            "",
            f"**Timestamp:** {datetime.utcnow().isoformat()}Z",
        ]

        # Add custom context if provided
        if context:
            body_parts.extend(
                [
                    "",
                    "### Additional Context",
                ]
            )
            for key, value in context.items():
                body_parts.append(f"- **{key}:** {value}")

        body_parts.extend(
            [
                "",
                "---",
                "",
                "*This issue was automatically generated. Please review and add any additional context if needed.*",
            ]
        )

        return "\n".join(body_parts)

    def _make_github_request(
        self, endpoint: str, method: str = "GET", data: Optional[bytes] = None
    ) -> Any:
        """Make a request to GitHub API.

        Args:
            endpoint: API endpoint (e.g., '/repos/owner/repo/issues')
            method: HTTP method
            data: Optional request body (already encoded as bytes)

        Returns:
            Response data (dict or list depending on endpoint)

        Raises:
            HTTPError: If request fails
            URLError: If network error occurs
        """
        url = f"{self.GITHUB_API_URL}{endpoint}"

        headers = {
            "Accept": "application/vnd.github.v3+json",
            "User-Agent": "telegram-bot-stack-error-reporter",
        }

        # Add authentication if token is available
        if self.github_token:
            headers["Authorization"] = f"token {self.github_token}"

        if data:
            headers["Content-Type"] = "application/json"

        request = Request(url, data=data, headers=headers, method=method)

        try:
            with urlopen(request, timeout=10) as response:
                import json

                response_data = response.read().decode("utf-8")
                return json.loads(response_data)
        except HTTPError as e:
            error_body = e.read().decode("utf-8")
            logger.error(f"GitHub API error: {e.code} - {error_body}")
            raise
        except URLError as e:
            logger.error(f"Network error while contacting GitHub: {e}")
            raise

    def _check_existing_issue(self, error_type: str) -> Optional[int]:
        """Check if similar issue already exists.

        Args:
            error_type: The type of error to search for

        Returns:
            Issue number if found, None otherwise
        """
        try:
            # Search for open issues with the same error type and auto-report label
            endpoint = f"/repos/{self.repo_owner}/{self.repo_name}/issues"
            params = "?state=open&labels=auto-report,bug&per_page=10"

            issues = self._make_github_request(endpoint + params)

            # Check if any issue title matches our error type
            search_title = f"[Auto] {error_type}"
            for issue in issues:
                if isinstance(issue, dict) and issue.get("title", "").startswith(
                    search_title
                ):
                    return issue.get("number")

            return None
        except Exception as e:
            logger.warning(f"Could not check for existing issues: {e}")
            return None

    def report_error(
        self,
        error: Exception,
        context: Optional[dict[str, Any]] = None,
        title_prefix: str = "[Auto]",
    ) -> Optional[str]:
        """Report an error to GitHub Issues.

        Args:
            error: The exception to report
            context: Optional additional context
            title_prefix: Prefix for issue title

        Returns:
            URL of created/updated issue, or None if reporting failed/disabled
        """
        if not self.enabled:
            return None

        try:
            error_type = type(error).__name__
            error_message = str(error)[:100]  # Truncate long messages

            # Check if similar issue exists
            existing_issue = self._check_existing_issue(error_type)

            if existing_issue:
                logger.info(
                    f"Similar issue already exists: #{existing_issue}. Skipping duplicate report."
                )
                return f"https://github.com/{self.repo_owner}/{self.repo_name}/issues/{existing_issue}"

            # Create issue title
            title = f"{title_prefix} {error_type}: {error_message}"
            if len(title) > 256:
                title = title[:253] + "..."

            # Format issue body
            body = self._format_issue_body(error, context)

            # Create issue payload
            import json

            payload = {
                "title": title,
                "body": body,
                "labels": ["auto-report", "bug", "support"],
            }

            # Create the issue
            endpoint = f"/repos/{self.repo_owner}/{self.repo_name}/issues"
            response_data = self._make_github_request(
                endpoint, method="POST", data=json.dumps(payload).encode("utf-8")
            )

            # Extract issue details
            if not isinstance(response_data, dict):
                logger.error("Unexpected response format from GitHub API")
                return None

            issue_url = response_data.get("html_url")
            issue_number = response_data.get("number")

            logger.info(f"✅ Bug report created: {issue_url}")
            logger.info(
                f"Issue #{issue_number} - Thank you for helping improve telegram-bot-stack!"
            )

            return issue_url

        except HTTPError as e:
            if e.code == 401:
                logger.error(
                    "❌ GitHub authentication failed. Check TELEGRAM_BOT_STACK_GITHUB_TOKEN"
                )
            elif e.code == 403:
                logger.error("❌ GitHub API rate limit exceeded or access forbidden")
            elif e.code == 404:
                logger.error(
                    f"❌ Repository not found: {self.repo_owner}/{self.repo_name}"
                )
            else:
                logger.error(f"❌ Failed to create GitHub issue: HTTP {e.code}")
            return None

        except URLError as e:
            logger.error(f"❌ Network error while reporting bug: {e}")
            return None

        except Exception as e:
            # Don't let error reporting break the application
            logger.error(f"❌ Unexpected error while reporting bug: {e}")
            return None


# Global error reporter instance
_global_reporter: Optional[ErrorReporter] = None


def get_error_reporter() -> ErrorReporter:
    """Get or create the global error reporter instance.

    Returns:
        Global ErrorReporter instance
    """
    global _global_reporter
    if _global_reporter is None:
        _global_reporter = ErrorReporter()
    return _global_reporter


def report_error(
    error: Exception,
    context: Optional[dict[str, Any]] = None,
) -> Optional[str]:
    """Convenience function to report an error using the global reporter.

    Args:
        error: The exception to report
        context: Optional additional context

    Returns:
        URL of created issue, or None if reporting failed/disabled
    """
    reporter = get_error_reporter()
    return reporter.report_error(error, context)
