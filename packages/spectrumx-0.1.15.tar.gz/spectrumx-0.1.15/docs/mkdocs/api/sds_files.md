# SDS Files API | `<Client>.sds_files`

## ::: spectrumx.api.sds_files
