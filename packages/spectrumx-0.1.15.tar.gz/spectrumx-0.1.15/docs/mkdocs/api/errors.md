# Errors Module | `spectrumx.errors`

## Classes

### ::: spectrumx.errors.Result

---

## Functions

### ::: spectrumx.errors.process_upload_results

---

## Exceptions

### ::: spectrumx.errors.SDSError

### ::: spectrumx.errors.AuthError

### ::: spectrumx.errors.NetworkError

### ::: spectrumx.errors.ServiceError

### ::: spectrumx.errors.FileError

### ::: spectrumx.errors.CaptureError

### ::: spectrumx.errors.DatasetError

### ::: spectrumx.errors.ExperimentError
