"""Equity Data."""
