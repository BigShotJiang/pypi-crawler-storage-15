"""Equity Price."""
