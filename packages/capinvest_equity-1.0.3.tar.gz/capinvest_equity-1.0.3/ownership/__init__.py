"""Equity Ownership."""
