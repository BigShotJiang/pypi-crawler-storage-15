"""Fundamentals."""
