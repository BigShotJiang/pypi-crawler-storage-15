# oddoreven-checker

A simple Python package to check if a number is odd or even.

## Usage

```python
from oddoreven import is_even, is_odd

print(is_even(10))  # True
print(is_odd(7))    # True
