from .core.converter import (
    codes_to_chars, 
    chars_to_codes,
    UNICODE_OFFSET,
    UNICODE_OFFSET_LARGE,
)

__version__ = "1.4.1"