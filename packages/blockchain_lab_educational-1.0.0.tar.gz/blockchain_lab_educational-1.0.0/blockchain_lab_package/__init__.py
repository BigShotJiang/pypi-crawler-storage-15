"""
Blockchain Lab Package
=====================

This package contains various blockchain implementations and cryptographic utilities
developed for blockchain laboratory exercises.

Modules:
- rsa_key_generator: RSA key generation using OpenSSL
- simple_blockchain: Basic blockchain implementation with proof-of-work
- wallet_shell: Interactive crypto wallet shell using Web3
- merkle_blockchain: Advanced blockchain with Merkle tree verification

Usage:
    from blockchain_lab_package import rsa_key_generator
    from blockchain_lab_package import simple_blockchain
    from blockchain_lab_package import wallet_shell
    from blockchain_lab_package import merkle_blockchain
    
    # To print source code of any module:
    blockchain_lab_package.print_source('rsa_key_generator')
"""

import inspect
import sys
from . import rsa_key_generator
from . import simple_blockchain
from . import wallet_shell
from . import merkle_blockchain

__version__ = "1.0.0"
__author__ = "Blockchain Lab"

def print_source(module_name):
    """Print the source code of a specified module."""
    modules = {
        'rsa_key_generator': rsa_key_generator,
        'simple_blockchain': simple_blockchain,
        'wallet_shell': wallet_shell,
        'merkle_blockchain': merkle_blockchain
    }
    
    if module_name not in modules:
        print(f"Module '{module_name}' not found. Available modules: {list(modules.keys())}")
        return
    
    try:
        source = inspect.getsource(modules[module_name])
        print(f"\n{'='*60}")
        print(f"SOURCE CODE FOR: {module_name.upper()}")
        print(f"{'='*60}")
        print(source)
        print(f"{'='*60}")
    except Exception as e:
        print(f"Error retrieving source code: {e}")

def list_modules():
    """List all available modules in the package."""
    modules = ['rsa_key_generator', 'simple_blockchain', 'wallet_shell', 'merkle_blockchain']
    print("Available modules:")
    for i, module in enumerate(modules, 1):
        print(f"{i}. {module}")

def print_all_sources():
    """Print source code of all modules."""
    modules = ['rsa_key_generator', 'simple_blockchain', 'wallet_shell', 'merkle_blockchain']
    for module in modules:
        print_source(module)
        print("\n" + "="*80 + "\n")