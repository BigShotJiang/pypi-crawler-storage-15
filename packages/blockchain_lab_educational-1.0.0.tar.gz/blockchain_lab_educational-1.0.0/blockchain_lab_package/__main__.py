"""
Main entry point for the blockchain lab package.
Provides a simple CLI interface to access all modules and their source codes.
"""

import sys
import blockchain_lab_package

def main():
    """Main CLI interface for the blockchain lab package."""
    if len(sys.argv) < 2:
        print("Blockchain Lab Package - CLI Interface")
        print("\nUsage:")
        print("  blockchain-lab list                    # List all modules")
        print("  blockchain-lab print <module_name>     # Print source of specific module")
        print("  blockchain-lab print-all               # Print all source codes")
        print("  blockchain-lab demo <module_name>      # Run module demo")
        print("\nAvailable modules: rsa_key_generator, simple_blockchain, wallet_shell, merkle_blockchain")
        return
    
    command = sys.argv[1]
    
    if command == "list":
        blockchain_lab_package.list_modules()
    elif command == "print" and len(sys.argv) > 2:
        blockchain_lab_package.print_source(sys.argv[2])
    elif command == "print-all":
        blockchain_lab_package.print_all_sources()
    elif command == "demo" and len(sys.argv) > 2:
        module_name = sys.argv[2]
        try:
            if module_name == "rsa_key_generator":
                from blockchain_lab_package import rsa_key_generator
                rsa_key_generator.demo()
            elif module_name == "simple_blockchain":
                from blockchain_lab_package import simple_blockchain
                simple_blockchain.demo()
            elif module_name == "wallet_shell":
                from blockchain_lab_package import wallet_shell
                wallet_shell.demo()
            elif module_name == "merkle_blockchain":
                from blockchain_lab_package import merkle_blockchain
                merkle_blockchain.demo()
            else:
                print(f"Unknown module: {module_name}")
        except Exception as e:
            print(f"Error running demo: {e}")
    else:
        print("Invalid command. Use 'blockchain-lab' without arguments for help.")

if __name__ == "__main__":
    main()