"""
RSA Key Generator Module
========================

This module provides functionality to generate RSA key pairs using OpenSSL.
"""

import subprocess

def generate_rsa_keys(private_key_file="private.pem", public_key_file="public.pem", bits=2048):
    """
    Generate RSA key pair using OpenSSL.
    
    Args:
        private_key_file (str): Filename for the private key
        public_key_file (str): Filename for the public key
        bits (int): Key size in bits
    """
    # Generate private key
    subprocess.run([
        "openssl", "genpkey",
        "-algorithm", "RSA",
        "-pkeyopt", f"rsa_keygen_bits:{bits}",
        "-out", private_key_file
    ], check=True)
    
    # Generate public key from private key
    subprocess.run([
        "openssl", "pkey",
        "-in", private_key_file,
        "-pubout",
        "-out", public_key_file
    ], check=True)
    
    # Read and print the public key
    with open(public_key_file, "r") as f:
        public_key_content = f.read()
    
    print(f"Keys generated successfully ")
    print(f"Private key saved in: {private_key_file}")
    print(f"Public key saved in: {public_key_file}\n")
    print(" Public Key (PEM format):\n")
    print(public_key_content)

def demo():
    """Run a demonstration of RSA key generation."""
    print("Running RSA Key Generator Demo...")
    generate_rsa_keys()

if __name__ == "__main__":
    demo()