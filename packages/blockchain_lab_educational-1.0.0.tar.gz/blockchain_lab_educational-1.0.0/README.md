# Blockchain Lab Package

A comprehensive Python package containing various blockchain implementations and cryptographic utilities developed for blockchain laboratory exercises.

## Features

- **RSA Key Generator**: Generate RSA key pairs using OpenSSL
- **Simple Blockchain**: Basic blockchain implementation with proof-of-work
- **Wallet Shell**: Interactive crypto wallet shell using Web3
- **Merkle Blockchain**: Advanced blockchain with Merkle tree verification

## Installation

### Option 1: Install from source

```bash
cd blockchain-lab-7th-sem
pip install -e .
```

### Option 2: Install dependencies manually

```bash
pip install web3
```

## Usage

### Import and use modules

```python
# Import the package
import blockchain_lab_package

# List available modules
blockchain_lab_package.list_modules()

# Print source code of any module
blockchain_lab_package.print_source('simple_blockchain')

# Print all source codes
blockchain_lab_package.print_all_sources()

# Use individual modules
from blockchain_lab_package import simple_blockchain, rsa_key_generator

# Run demonstrations
simple_blockchain.demo()
rsa_key_generator.demo()
```

### Interactive Examples

#### Simple Blockchain

```python
from blockchain_lab_package.simple_blockchain import Blockchain

# Create a blockchain
chain = Blockchain()
chain.add_block("Alice pays Bob 10 coins")
chain.add_block("Bob pays Charlie 5 coins")

# Validate the chain
print("Valid chain:", chain.is_chain_valid())
```

#### RSA Key Generator

```python
from blockchain_lab_package.rsa_key_generator import generate_rsa_keys

# Generate RSA keys
generate_rsa_keys("my_private.pem", "my_public.pem", 2048)
```

#### Wallet Shell

```python
from blockchain_lab_package.wallet_shell import start_shell

# Start interactive wallet shell
start_shell()
```

#### Merkle Blockchain

```python
from blockchain_lab_package.merkle_blockchain import Blockchain, MerkleTree

# Create advanced blockchain
bc = Blockchain(diff=2)
block = bc.add(["Alice->Bob:5", "Carol->Dave:2"])

# Generate and verify Merkle proof
tree = MerkleTree(block.txs)
proof = tree.proof(0)
is_valid = tree.verify(block.txs[0], proof, tree.root())
```

## Quick Start - Print Source Codes

The primary feature of this package is to easily access and print source codes:

```python
import blockchain_lab_package as blp

# Print specific module source
blp.print_source('rsa_key_generator')
blp.print_source('simple_blockchain')
blp.print_source('wallet_shell')
blp.print_source('merkle_blockchain')

# Or print all at once
blp.print_all_sources()
```

## Requirements

- Python 3.7+
- web3 (for wallet shell functionality)
- OpenSSL (for RSA key generation)

## Modules Overview

### 1. RSA Key Generator (`rsa_key_generator`)

- Generate RSA public/private key pairs
- Uses OpenSSL for secure key generation
- Configurable key sizes

### 2. Simple Blockchain (`simple_blockchain`)

- Basic blockchain implementation
- SHA-256 hashing
- Chain validation
- Genesis block creation

### 3. Wallet Shell (`wallet_shell`)

- Interactive command-line wallet
- Web3 integration with Ethereum test provider
- Send/receive transactions
- Balance checking
- Block inspection

### 4. Merkle Blockchain (`merkle_blockchain`)

- Advanced blockchain with Merkle trees
- Proof-of-work mining
- Transaction verification
- Merkle proof generation and verification

## License

MIT License

## Author

Blockchain Lab - Educational Implementation
