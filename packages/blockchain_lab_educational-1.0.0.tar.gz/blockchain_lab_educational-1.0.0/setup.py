from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="blockchain-lab-educational",  # Changed to avoid conflicts
    version="1.0.0",
    author="Mihir",  # Use your actual name
    author_email="mihir.blockchain@gmail.com",  # Use your email
    description="Educational blockchain implementations with source code printing functionality",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/mihir/blockchain-lab-educational",  # Update with your GitHub
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Education",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Education",
        "Topic :: Security :: Cryptography",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    keywords="blockchain, education, cryptography, merkle-tree, rsa, web3, ethereum",
    python_requires=">=3.7",
    install_requires=[
        "web3>=6.0.0",
    ],
    extras_require={
        "dev": [
            "pytest>=6.0",
            "black",
            "flake8",
            "twine",
            "build",
        ],
    },
    entry_points={
        "console_scripts": [
            "blockchain-lab=blockchain_lab_package.__main__:main",
        ],
    },
    project_urls={
        "Bug Reports": "https://github.com/mihir/blockchain-lab-educational/issues",
        "Source": "https://github.com/mihir/blockchain-lab-educational",
        "Documentation": "https://github.com/mihir/blockchain-lab-educational#readme",
    },
)