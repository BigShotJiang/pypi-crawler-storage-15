LOGGER_NAME = "sunagent_app"
"""str: Logger name used for app logging"""
