## 2.3.12 / 2025-12-03

- Made checking for missing tensor parameters more efficient.

## 2.3.11 / 2023-02-05

- Using geopandas to calculate distances from various regimes (fixing bug).

## 2.3.10 / 2023-02-05

- Removed dependency on typer from pyproject.toml.

## 2.3.9 / 2023-02-05

- Removed references to typer which is no longer used.

## 2.3.8 / 2023-02-05

- Fixed minor bug in strec_cfg.

## 2.3.6 / 2023-02-05

- Switched to using requests instead of urlopen for users in self-signed SSL certificate environments.
- Switched from typer CLI package back to argparse.

## 2.3.3 / 2023-02-05

- Remove cap on python version.

## 2.3.2 / 2023-10-16

- Including manifest file.

## 2.3.0 / 2023-10-16

- Now including package data in PyPI.

## 2.2.9 / 2023-10-16

- Initial commit of this file - changing designation of "HotSpot" to "Volcanic".
