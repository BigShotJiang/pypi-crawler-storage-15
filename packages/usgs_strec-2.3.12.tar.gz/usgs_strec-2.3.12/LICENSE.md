License
=======

Unless otherwise noted, This project is in the public domain in the United
States because it contains materials that originally came from the United
States Geological Survey, an agency of the United States Department of
Interior. For more information, see the official USGS copyright policy at
https://www2.usgs.gov/visual-id/credit_usgs.html#copyright

This information is preliminary or provisional and is subject to
revision. It is being provided to meet the need for timely best
science. The information has not received final approval by the USGS
and is provided on the condition that neither the USGS nor the
U.S. Government shall be held liable for any damages resulting from
the authorized or unauthorized use of the information.
