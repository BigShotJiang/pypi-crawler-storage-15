Error store
===========

.. automodule:: marshmallow.error_store
    :members:
    :private-members:
