.. seealso::
  Need help upgrading to newer versions? Check out the :doc:`upgrading guide <upgrading>`.

.. include:: ../CHANGELOG.rst
