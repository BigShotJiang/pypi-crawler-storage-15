Schema
======

.. autoclass:: marshmallow.schema.Schema
    :members:
    :autosummary:
    :exclude-members: OPTIONS_CLASS

.. autoclass:: marshmallow.schema.SchemaOpts
