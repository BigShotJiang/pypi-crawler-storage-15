"""
QALDRON API Package

REST API for secure multi-agent communication.
"""

__version__ = "1.0.0"
