"""
Web Grading API

FastAPI-based backend for the web grading interface.
"""

__version__ = "0.1.0"
