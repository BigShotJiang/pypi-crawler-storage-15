"""
graphnode
========

graphnode is a Python package for the creation, manipulation, and study of the
structure, dynamics, and functions of complex networks.

See https://networkx.org for complete documentation.
"""

__version__ = "1.1.0"


def __getattr__(name):
    """Remove functions and provide informative error messages."""
    if name == "nx_yaml":
        raise ImportError(
            "\nThe nx_yaml module has been removed from graphnode.\n"
            "Please use the `yaml` package directly for working with yaml data.\n"
            "For example, a graphnode.Graph `G` can be written to and loaded\n"
            "from a yaml file with:\n\n"
            "    import yaml\n\n"
            "    with open('path_to_yaml_file', 'w') as fh:\n"
            "        yaml.dump(G, fh)\n"
            "    with open('path_to_yaml_file', 'r') as fh:\n"
            "        G = yaml.load(fh, Loader=yaml.Loader)\n\n"
            "Note that yaml.Loader is considered insecure - see the pyyaml\n"
            "documentation for further details.\n\n"
        )
    if name == "read_yaml":
        raise ImportError(
            "\nread_yaml has been removed from graphnode, please use `yaml`\n"
            "directly:\n\n"
            "    import yaml\n\n"
            "    with open('path', 'r') as fh:\n"
            "        yaml.load(fh, Loader=yaml.Loader)\n\n"
            "Note that yaml.Loader is considered insecure - see the pyyaml\n"
            "documentation for further details.\n\n"
        )
    if name == "write_yaml":
        raise ImportError(
            "\nwrite_yaml has been removed from graphnode, please use `yaml`\n"
            "directly:\n\n"
            "    import yaml\n\n"
            "    with open('path_for_yaml_output', 'w') as fh:\n"
            "        yaml.dump(G_to_be_yaml, path_for_yaml_output, **kwds)\n\n"
        )
    raise AttributeError(f"module {__name__} has no attribute {name}")


# These are import orderwise
from graphnode.exception import *

from graphnode import utils

from graphnode import classes
from graphnode.classes import filters
from graphnode.classes import *

from graphnode import convert
from graphnode.convert import *

from graphnode import convert_matrix
from graphnode.convert_matrix import *

from graphnode import relabel
from graphnode.relabel import *

from graphnode import generators
from graphnode.generators import *

from graphnode import readwrite
from graphnode.readwrite import *

# Need to test with SciPy, when available
from graphnode import algorithms
from graphnode.algorithms import *

from graphnode import linalg
from graphnode.linalg import *

from graphnode.testing.test import run as test

from graphnode import drawing
from graphnode.drawing import *
