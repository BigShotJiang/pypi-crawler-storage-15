from graphnode.algorithms.coloring.greedy_coloring import *
from graphnode.algorithms.coloring.equitable_coloring import equitable_color

__all__ = ["greedy_color", "equitable_color"]
