.. include:: ../INSTALL.rst
