# DremioFrame (currently in alpha)

DremioFrame is a Python library that provides a dataframe builder interface for interacting with Dremio Cloud & Dremio Software. It allows you to list data, perform CRUD operations, and administer Dremio resources using a familiar API.

## Documentation

### 🚀 Getting Started
- [Installation](#installation)
- [Optional Dependencies](docs/getting_started/dependencies.md)
- [S3 Integration](docs/getting_started/s3_integration.md)
- [Quick Start](#quick-start)
- [Configuration](docs/getting_started/configuration.md)
- [Connecting to Dremio](docs/getting_started/connection.md)
- [Tutorial: ETL Pipeline](docs/getting_started/tutorial_etl.md)
- [Cookbook / Recipes](docs/getting_started/cookbook.md)
- [Troubleshooting](docs/getting_started/troubleshooting.md)
- [API Compatibility Guide](docs/api_compatibility.md)

### 🛠️ Data Engineering
- [Dataframe Builder API](docs/data_engineering/builder.md)
- [Querying Data](docs/data_engineering/querying.md)
- [Joins & Transformations](docs/data_engineering/joins.md)
- [Aggregation](docs/data_engineering/aggregation.md)
- [Sorting & Filtering](docs/data_engineering/sorting.md)
- [Ingestion API](docs/data_engineering/ingestion.md)
- [Ingestion Patterns](docs/data_engineering/ingestion_patterns.md)
- [dlt Integration](docs/data_engineering/dlt_integration.md)
- [Database Ingestion](docs/data_engineering/database_ingestion.md)
- [File System Ingestion](docs/data_engineering/file_system_ingestion.md)
- [File Upload](docs/data_engineering/file_upload.md)
- [Exporting Data](docs/data_engineering/export.md)
- [Working with Files](docs/data_engineering/files.md)
- [Caching](docs/data_engineering/caching.md)
- [Pydantic Integration](docs/data_engineering/pydantic_integration.md)
- [Iceberg Tables](docs/data_engineering/iceberg.md)
- [Iceberg Lakehouse Management](docs/data_engineering/guide_iceberg_management.md)
- [Schema Evolution](docs/data_engineering/schema_evolution.md)
- [Incremental Processing](docs/data_engineering/incremental_processing.md)
- [Query Templates](docs/data_engineering/query_templates.md)
- [Export Formats](docs/data_engineering/export_formats.md)
- [SQL Linting](docs/data_engineering/sql_linting.md)

### 📊 Analysis & Visualization
- [Charting & Plotting](docs/analysis/charting.md)
- [Interactive Plotting](docs/analysis/plotting.md)
- [Query Profiling](docs/analysis/profiling.md)

### 🧠 AI Capabilities and AI Agent
**note:** this libraries embdedded agent is primarily meant as a code generation assist tool, not meant as an alternative to the integrated Dremio agent for deeper administration and natural language analytics. Login to your Dremio instance's UI to leverage integrated agent.
- [Overview](docs/ai/overview.md)
- [DremioAgent Class](docs/ai/agent.md)
- [MCP Server Integration](docs/ai/mcp_integration.md)
- [Document Extraction](docs/ai/document_extraction.md)
- [Script Generation](docs/ai/generation.md)
- [SQL Generation](docs/ai/sql.md)
- [API Call Generation](docs/ai/api.md)
- [Observability](docs/ai/observability.md)
- [Reflections](docs/ai/reflections.md)
- [Governance](docs/ai/governance.md)
- [Data Quality](docs/ai/data_quality.md)
- [SQL Optimization](docs/ai/optimization.md)
- [CLI Chat](docs/ai/cli_chat.md)

### 📐 Data Modeling
- [Medallion Architecture](docs/modeling/medallion.md)
- [Dimensional Modeling](docs/modeling/dimensional.md)
- [Slowly Changing Dimensions](docs/modeling/scd.md)
- [Semantic Views](docs/modeling/views.md)
- [Documenting Datasets](docs/modeling/documentation.md)

### ⚙️ Orchestration
- [Overview](docs/orchestration/overview.md)
- [Tasks & Sensors](docs/orchestration/tasks.md)
- [Extensions](docs/orchestration/extensions.md)
- [Scheduling](docs/orchestration/scheduling.md)
- [Dremio Jobs](docs/orchestration/dremio_jobs.md)
- [Iceberg Tasks](docs/orchestration/iceberg.md)
- [Reflection Tasks](docs/orchestration/reflections.md)
- [Data Quality Task](docs/orchestration/dq_task.md)
- [Distributed Execution](docs/orchestration/distributed.md)
- [Deployment](docs/orchestration/deployment.md)
- [CLI & UI](docs/orchestration/cli.md)
- [Web UI](docs/orchestration/ui.md)
- [Backends](docs/orchestration/backend.md)
- [Best Practices](docs/orchestration/best_practices.md)

### ✅ Data Quality
- [DQ Framework](docs/data_quality.md)
- [YAML Syntax](docs/data_quality/yaml_syntax.md)
- [Recipes](docs/data_quality/recipes.md)

### 🔧 Administration & Governance
- [Administration](docs/admin_governance/admin.md)
- [Catalog Management](docs/admin_governance/catalog.md)
- [Reflections Management](docs/admin_governance/reflections.md)
- [User Defined Functions (UDFs)](docs/admin_governance/udf.md)
- [Security Best Practices](docs/admin_governance/security.md)
- [Security Patterns](docs/admin_governance/security_patterns.md)
- [Governance: Masking & Row Access](docs/admin_governance/masking_and_row_access.md)
- [Governance: Tags](docs/admin_governance/tags.md)
- [Governance: Lineage](docs/admin_governance/lineage.md)
- [Governance: Privileges](docs/admin_governance/privileges.md)
- [Space & Folder Management](docs/admin_governance/spaces_folders.md)
- [Batch Operations](docs/admin_governance/batch_operations.md)
- [Lineage Tracking](docs/admin_governance/lineage_tracking.md)

### 🔗 Integrations
- [Airflow Integration](docs/integrations/airflow.md)
- [Notebook Integration](docs/integrations/notebook.md)

### 🚀 Performance & Deployment
- [Performance Tuning](docs/performance/tuning.md)
- [Bulk Loading Optimization](docs/performance/bulk_loading.md)
- [Connection Pooling](docs/performance/connection_pooling.md)
- [Query Cost Estimation](docs/performance/cost_estimation.md)
- [CI/CD & Deployment](docs/deployment/cicd.md)

### 📚 Reference
- [Function Reference](docs/reference/function_reference.md)
- [SQL Functions Guide](docs/reference/functions_guide.md)
- [CLI Reference](docs/reference/cli.md)
- [API Reference](docs/reference/client.md)
- [Async Client](docs/reference/async_client.md)

### 🧪 Testing
- [Mock/Testing Framework](docs/testing/mocking.md)
- [Advanced Usage](docs/reference/advanced.md)
- [Architecture](architecture.md)
- [Testing Guide](docs/reference/testing.md)
- [Contributing](CONTRIBUTING.md)

## Installation
 
> [!NOTE]
> DremioFrame has many optional dependencies for advanced features like AI, Chart Exporting, and Distributed Orchestration. See [Optional Dependencies](docs/getting_started/dependencies.md) for a full list.
```bash
pip install dremioframe
```

To install with optional dependencies (e.g., for static image export):
```bash
pip install "dremioframe[image_export]"
```

## Quick Start

### Dremio Cloud

```python
from dremioframe.client import DremioClient

# Assumes DREMIO_PAT and DREMIO_PROJECT_ID are set in env
client = DremioClient()

# Query a table
df = client.table('finance.bronze.transactions').select("transaction_id", "amount", "customer_id").limit(5).collect()
print(df)
```

### Dremio Software v26+

```python
# Assumes DREMIO_SOFTWARE_HOST and DREMIO_SOFTWARE_PAT are set in env
client = DremioClient(mode="v26")

# Or with explicit parameters
client = DremioClient(
    hostname="v26.dremio.org",
    pat="your_pat_here",
    tls=True,
    mode="v26"
)
```

### Dremio Software v25

```python
client = DremioClient(
    hostname="localhost",
    username="admin",
    password="password123",
    tls=False,
    mode="v25"
)
```

## Features

```python
from dremioframe.client import DremioClient

# Assumes DREMIO_PAT and DREMIO_PROJECT_ID are set in env
client = DremioClient()

# List catalog
print(client.catalog.list_catalog())

# Query data
df = client.table('finance.bronze.transactions').select("transaction_id", "amount", "customer_id").filter("amount > 1000").collect()
print(df)

# Calculated Columns
df.mutate(amount_with_tax="amount * 1.08").show()

# Aggregation
df.group_by("customer_id").agg(total_spent="SUM(amount)").show()

# Joins
customers = client.table('finance.silver.customers')
df.join(customers, on="transactions.customer_id = customers.customer_id").show()

# Iceberg Time Travel
df.at_snapshot("123456789").show()

# API Ingestion
client.ingest_api(
    url="https://api.example.com/users",
    table_name="finance.bronze.users",
    mode="merge",
    pk="id"
)

# Charting
sales_summary = client.table('finance.gold.sales_summary')
sales_summary.chart(kind="bar", x="category", y="total_sales", save_to="sales.png")

# Export
df.to_csv("transactions.csv")
df.to_parquet("transactions.parquet")

# Insert Data (Batched)
import pandas as pd
data = pd.DataFrame({"id": [1, 2], "name": ["A", "B"]})
client.table("finance.bronze.raw_data").insert("finance.bronze.raw_data", data=data, batch_size=1000)

# SQL Functions
from dremioframe import F

client.table("finance.silver.sales") \
    .select(
        F.col("dept"),
        F.sum("amount").alias("total_sales"),
        F.rank().over(F.Window.order_by("amount")).alias("rank")
    ) \
    .show()

# Merge (Upsert)
client.table("finance.silver.customers").merge(
    target_table="finance.silver.customers",
    on="customer_id",
    matched_update={"name": "source.name", "updated_at": "source.updated_at"},
    not_matched_insert={"customer_id": "source.customer_id", "name": "source.name"},
    data=data
)

# Data Quality
df.quality.expect_not_null("customer_id")
df.quality.expect_row_count("amount > 10000", 5, "ge") # Expect at least 5 large transactions

# Query Explanation
print(df.explain())

# Reflection Management
client.admin.create_reflection(dataset_id="...", name="my_ref", type="RAW", display_fields=["col1"])

# Async Client
# async with AsyncDremioClient() as client: ...

# CLI
# dremio-cli query "SELECT * FROM finance.gold.sales_summary LIMIT 10"

# Local Caching
# client.table("finance.bronze.transactions").cache("my_cache", ttl_seconds=300).sql("SELECT * FROM my_cache").show()

# Interactive Plotting
# df.chart(kind="scatter", backend="plotly").show()

# UDF Manager
# client.udf.create("add_one", {"x": "INT"}, "INT", "x + 1")

# Raw SQL
# df = client.query("SELECT * FROM finance.silver.customers")

# Source Management
# client.admin.create_source_s3("my_datalake", "bucket")

# Query Profiling
# client.admin.get_job_profile("job_123").visualize().show()

# Iceberg Client
# client.iceberg.list_tables("finance")

# Orchestration CLI
# dremio-cli pipeline list
# dremio-cli pipeline ui --port 8080

# Data Quality Framework
# dremio-cli dq run tests/dq
```

## Sample .env

```
# Dremio Cloud Configuration
# Required for Dremio Cloud connections
# DREMIO_PAT: Personal Access Token for Dremio Cloud
# DREMIO_PROJECT_ID: The Project ID of your Dremio Cloud project
DREMIO_PAT=your_dremio_cloud_pat_here
DREMIO_PROJECT_ID=your_dremio_project_id_here

# Optional Dremio Cloud Configuration
# DREMIO_URL: Custom base URL for Dremio Cloud (defaults to data.dremio.cloud)
# Note: DREMIO_URL is REQUIRED for running integration tests (tests/test_integration.py)
# DREMIO_URL=data.dremio.cloud

# Dremio Software Configuration
# Required for connecting to Dremio Software (v26+ recommended)
# DREMIO_SOFTWARE_PAT: Personal Access Token for Dremio Software
# DREMIO_SOFTWARE_HOST: Hostname/URL of your Dremio Software instance (e.g. dremio.example.com)
#
# The following variables are specifically used by the test suite (tests/test_integration_software.py)
# and for legacy authentication (v25 or v26 without PAT):
# DREMIO_SOFTWARE_PORT: Port for the Dremio Flight/REST service (default: 32010 for Flight)
# DREMIO_SOFTWARE_USER: Username for Dremio Software
# DREMIO_SOFTWARE_PASSWORD: Password for Dremio Software
# DREMIO_SOFTWARE_TLS: Enable TLS/SSL (true/false, default: false)
#
# Note: If using Software, comment out Cloud variables above to avoid confusion, though the client 'mode' determines which are used.
# DREMIO_SOFTWARE_PAT=your_software_pat_here
# DREMIO_SOFTWARE_HOST=dremio.example.com
# DREMIO_SOFTWARE_PORT=32010
# DREMIO_SOFTWARE_USER=your_username
# DREMIO_SOFTWARE_PASSWORD=your_password
# DREMIO_SOFTWARE_TLS=false
# DREMIO_SOFTWARE_TESTING_FOLDER=Space.Folder

# Test Suite Configuration
# TEST_FOLDER: The namespace (Space) to use for creating temporary test folders and tables.
# Defaults to "testing" if not set. Ensure this Space exists in Dremio.
# TEST_FOLDER=testing

# AI Provider Configuration
# Required for AI features (DremioAgent, SQL generation, etc.)
# Uncomment the one you wish to use.

# OpenAI (Default)
# OPENAI_API_KEY=sk-...

# Anthropic (Claude)
# ANTHROPIC_API_KEY=sk-ant-...

# Google (Gemini)
# GOOGLE_API_KEY=AIza...
```