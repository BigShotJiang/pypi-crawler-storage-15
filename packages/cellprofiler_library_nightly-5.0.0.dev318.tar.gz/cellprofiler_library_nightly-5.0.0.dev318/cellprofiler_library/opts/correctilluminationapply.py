from enum import Enum

class Method(str, Enum):
    DIVIDE = "Divide"
    SUBTRACT = "Subtract"
