"""Test package for probabilistic Hough line transform."""
