"""IATPWallet creation script using IATPWalletFactory.

This script creates a new IATPWallet by calling the IATPWalletFactory contract.
It generates an operator keypair and deploys a wallet for a given owner.

Uses centralized contract configuration from traia_iatp.contracts.config.
"""

import os
import json
from typing import Dict, Optional, Tuple
from pathlib import Path
from eth_account import Account
from web3 import Web3
from web3.contract import Contract


def get_contract_config(network: str = "sepolia") -> Dict:
    """Load contract addresses and ABIs for a network.
    
    Uses the centralized config module from traia_iatp.contracts.config.
    
    Args:
        network: Network name (sepolia, base-sepolia, etc.)
        
    Returns:
        Dict with addresses and ABIs
    """
    from traia_iatp.contracts.iatp_contracts_config import get_contract_address, get_contract_abi
    
    # Get all contract addresses and ABIs
    contract_names = ["IATPWalletFactory", "IATPSettlementLayer", "IATPWallet", "RoleManager"]
    addresses = {}
    abis = {}
    
    for name in contract_names:
        try:
            address = get_contract_address(name, network)
            if address:
                addresses[name] = address
            
            abi = get_contract_abi(name, network)
            if abi:
                abis[name] = {"abi": abi}
        except Exception as e:
            # Some contracts may not be on all networks
            pass
    
    return {
        "addresses": addresses,
        "abis": abis
    }


def create_wallet(
    owner_private_key: str,
    network: str = "sepolia",
    rpc_url: Optional[str] = None,
    maintainer_private_key: Optional[str] = None
) -> Tuple[str, str, str]:
    """Create a new IATPWallet using IATPWalletFactory.
    
    Args:
        owner_private_key: Private key of the wallet owner
        network: Network name (default: sepolia)
        rpc_url: Optional RPC URL (uses default if not provided)
        maintainer_private_key: Optional maintainer key (if calling createWalletFor)
        
    Returns:
        Tuple of (wallet_address, operator_address, operator_private_key)
    """
    # Setup Web3
    if not rpc_url:
        rpc_urls = {
            "sepolia": os.getenv("SEPOLIA_RPC_URL", "https://ethereum-sepolia-rpc.publicnode.com"),
            "base-sepolia": os.getenv("BASE_SEPOLIA_RPC_URL", "https://sepolia.base.org"),
            "arbitrum-sepolia": os.getenv("ARBITRUM_SEPOLIA_RPC_URL", "https://sepolia-rollup.arbitrum.io/rpc"),
        }
        rpc_url = rpc_urls.get(network)
    
    w3 = Web3(Web3.HTTPProvider(rpc_url))
    
    if not w3.is_connected():
        raise ConnectionError(f"Could not connect to {network} at {rpc_url}")
    
    print(f"✅ Connected to {network}")
    print(f"   RPC: {rpc_url}")
    print(f"   Chain ID: {w3.eth.chain_id}")
    
    # Load contract config
    config = get_contract_config(network)
    factory_address = config["addresses"].get("IATPWalletFactory")
    factory_abi = config["abis"].get("IATPWalletFactory", {}).get("abi")
    
    if not factory_address:
        raise ValueError(f"IATPWalletFactory address not found for {network}")
    
    if not factory_abi:
        raise ValueError(f"IATPWalletFactory ABI not found for {network}")
    
    print(f"\n📝 Contract Configuration:")
    print(f"   Factory: {factory_address}")
    
    # Create owner account
    if owner_private_key.startswith("0x"):
        owner_private_key = owner_private_key[2:]
    owner_account = Account.from_key(owner_private_key)
    print(f"\n👤 Owner Account: {owner_account.address}")
    
    # Check owner balance
    owner_balance = w3.eth.get_balance(owner_account.address)
    print(f"   Balance: {w3.from_wei(owner_balance, 'ether')} ETH")
    
    if owner_balance == 0:
        print(f"   ⚠️  Warning: Owner has no ETH for gas")
    
    # Generate operator keypair
    operator_account = Account.create()
    operator_address = operator_account.address
    operator_private_key = operator_account.key.hex()
    
    print(f"\n🔑 Generated Operator:")
    print(f"   Address: {operator_address}")
    print(f"   Private Key: {operator_private_key}")
    
    # Create factory contract instance
    factory_contract = w3.eth.contract(
        address=Web3.to_checksum_address(factory_address),
        abi=factory_abi
    )
    
    # Determine which method to call
    if maintainer_private_key:
        # Use createWalletFor (maintainer only)
        if maintainer_private_key.startswith("0x"):
            maintainer_private_key = maintainer_private_key[2:]
        caller_account = Account.from_key(maintainer_private_key)
        
        print(f"\n📞 Calling createWalletFor() as maintainer")
        print(f"   Maintainer: {caller_account.address}")
        
        # Build transaction
        tx = factory_contract.functions.createWalletFor(
            owner_account.address,
            operator_address
        ).build_transaction({
            'from': caller_account.address,
            'nonce': w3.eth.get_transaction_count(caller_account.address),
            'gas': 2000000,
            'gasPrice': w3.eth.gas_price,
            'chainId': w3.eth.chain_id
        })
        
        # Sign and send
        signed_tx = w3.eth.account.sign_transaction(tx, maintainer_private_key)
    else:
        # Use createWallet (owner calls)
        print(f"\n📞 Calling createWallet() as owner")
        
        # Build transaction
        tx = factory_contract.functions.createWallet(
            operator_address
        ).build_transaction({
            'from': owner_account.address,
            'nonce': w3.eth.get_transaction_count(owner_account.address),
            'gas': 2000000,
            'gasPrice': w3.eth.gas_price,
            'chainId': w3.eth.chain_id
        })
        
        # Sign and send
        signed_tx = w3.eth.account.sign_transaction(tx, owner_private_key)
    
    print(f"\n🚀 Sending transaction...")
    tx_hash = w3.eth.send_raw_transaction(signed_tx.raw_transaction)
    print(f"   TX Hash: {tx_hash.hex()}")
    
    print(f"\n⏳ Waiting for confirmation...")
    tx_receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=120)
    
    if tx_receipt['status'] == 1:
        print(f"✅ Transaction confirmed!")
        print(f"   Block: {tx_receipt['blockNumber']}")
        print(f"   Gas Used: {tx_receipt['gasUsed']}")
        
        # Parse logs to get wallet address
        wallet_created_event = factory_contract.events.WalletCreated()
        logs = wallet_created_event.process_receipt(tx_receipt)
        
        if logs:
            wallet_address = logs[0]['args']['wallet']
            print(f"\n🎉 Wallet Created!")
            print(f"   Wallet Address: {wallet_address}")
            print(f"   Owner: {logs[0]['args']['owner']}")
            print(f"   Operator: {logs[0]['args']['operatorAddress']}")
            
            return wallet_address, operator_address, operator_private_key
        else:
            raise Exception("WalletCreated event not found in logs")
    else:
        raise Exception(f"Transaction failed: {tx_receipt}")


def main():
    """CLI entry point for wallet creation."""
    import argparse
    
    parser = argparse.ArgumentParser(description="Create IATPWallet using IATPWalletFactory")
    parser.add_argument("--owner-key", required=True, help="Owner's private key")
    parser.add_argument("--network", default="sepolia", help="Network name (default: sepolia)")
    parser.add_argument("--rpc-url", help="Custom RPC URL")
    parser.add_argument("--maintainer-key", help="Maintainer key (for createWalletFor)")
    parser.add_argument("--output", help="Output file for wallet info (JSON)")
    
    args = parser.parse_args()
    
    try:
        wallet_address, operator_address, operator_private_key = create_wallet(
            owner_private_key=args.owner_key,
            network=args.network,
            rpc_url=args.rpc_url,
            maintainer_private_key=args.maintainer_key
        )
        
        result = {
            "wallet_address": wallet_address,
            "operator_address": operator_address,
            "operator_private_key": operator_private_key,
            "owner_address": Account.from_key(args.owner_key).address,
            "network": args.network
        }
        
        if args.output:
            with open(args.output, 'w') as f:
                json.dump(result, f, indent=2)
            print(f"\n💾 Wallet info saved to: {args.output}")
        
        print(f"\n{'='*80}")
        print("Wallet Created Successfully!")
        print(f"{'='*80}")
        print(json.dumps(result, indent=2))
        
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0


if __name__ == "__main__":
    import sys
    sys.exit(main())

