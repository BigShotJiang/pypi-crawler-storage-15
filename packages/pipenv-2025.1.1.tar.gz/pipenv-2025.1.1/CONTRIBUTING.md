Contributing to Pipenv
======================

Please see: [docs](https://pipenv.pypa.io/en/latest/dev/contributing.html).
