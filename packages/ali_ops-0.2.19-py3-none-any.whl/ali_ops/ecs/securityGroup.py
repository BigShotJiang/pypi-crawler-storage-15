
from alibabacloud_ecs20140526.client import Client as Ecs20140526Client
from alibabacloud_ecs20140526 import models as ecs_20140526_models
from alibabacloud_tea_util import models as util_models
from ..client.client import ClientConf
import json  

class SECGROUP(object):
    
    def __init__(self):
        # 使用 ClientConf 单例获取已配置好凭证的 config
        client_conf = ClientConf()
        if client_conf.config is None:
            print("配置文件不存在, 请使用ali config regen 命令生成配置文件。")
            self.__client = None
            return
        
        self.region = client_conf.region
        client_conf.config.endpoint = f'ecs.{self.region}.aliyuncs.com'
        self.__client = Ecs20140526Client(client_conf.config)
        self.sgp_id = None 


    @staticmethod
    def _getsgp():
        if ClientConf().config is None:
            print("ECS客户端未初始化，请先配置阿里云凭证")
            return
        try:
            describe_security_groups_request = ecs_20140526_models.DescribeSecurityGroupsRequest(
                region_id=ClientConf().region 
            )
            runtime = util_models.RuntimeOptions()
            ClientConf().config.endpoint = f'ecs.{ClientConf().region}.aliyuncs.com'
            res = Ecs20140526Client(ClientConf().config).describe_security_groups_with_options(describe_security_groups_request, runtime)
            # print(json.dumps(res.to_map(), indent=2, ensure_ascii=False))
            return res 
        except Exception as error:
            # 判断是否为阿里云 SDK 异常
            if hasattr(error, 'data') and error.data:
                print(f"阿里云建议: {error.data.get('Recommend')}")
            if hasattr(error, 'message'):
                print(f"错误信息: {error.message}")
            else:
                print(f"获取安全组列表失败: {error}")


    @staticmethod 
    def ls():
        """列出当前区域的安全组信息"""
        res = SECGROUP._getsgp()
        if res is None:
            return
        
        body = res.body
        security_groups = body.security_groups.security_group
        
        if not security_groups:
            print("当前区域没有安全组")
            return
        
        print(f"\n区域: {body.region_id}  共 {body.total_count} 个安全组\n")
        
        for sg in security_groups:
            create_time = sg.creation_time.replace('T', ' ').replace('Z', '')
            print(f"安全组ID: {sg.security_group_id}")
            print(f"名称:     {sg.security_group_name}")
            print(f"规则数:   {sg.rule_count}")
            print(f"创建时间: {create_time}")
            print(f"VPC ID:   {sg.vpc_id}")
            print("-" * 50)
    


    def lsattr(self):
        
        pass 