

from alibabacloud_ecs20140526.client import Client as Ecs20140526Client
from alibabacloud_ecs20140526 import models as ecs_20140526_models
from alibabacloud_tea_util import models as util_models
from alibabacloud_tea_util.client import Client as UtilClient
import json

from ..client.client import ClientConf

class ECS(object): 
    """
    阿里云ECS服务
    """
    
    def __init__(self):
        # 使用 ClientConf 单例获取已配置好凭证的 config
        client_conf = ClientConf()
        if client_conf.config is None:
            print("配置文件不存在, 请使用ali config regen 命令生成配置文件。")
            self.__client = None
            return
        
        self.region = client_conf.region
        client_conf.config.endpoint = f'ecs.{self.region}.aliyuncs.com'
        self.__client = Ecs20140526Client(client_conf.config)
    

    
        
    
    def creat_instance(
        self,
        v_switch_id: str,
        instance_type: str,
        image_id: str,
        security_group_ids: list[str],
        password: str='ggmm12LPP!',
        instance_name: str='test',
        private_ip_address: str = None,
        system_disk_category: str = 'cloud_essd',
        system_disk_size: str = '30'
    ):
        """
        创建按量付费实例 或者竞价实例
        
        参数:
            v_switch_id: 交换机ID
            instance_type: 实例规格类型
            image_id: 镜像ID
            security_group_ids: 安全组ID列表
            password: 实例密码
            instance_name: 实例名称
            private_ip_address: 私网IP地址（可选）
            system_disk_category: 系统盘类型（可选，默认为 'cloud_essd'）
            system_disk_size: 系统盘大小（可选，默认为 '30'）
        """
        if self.__client is None:
            print("ECS客户端未初始化，请先配置阿里云凭证")
            return
        
        private_dns_name_options = ecs_20140526_models.RunInstancesRequestPrivateDnsNameOptions(
            hostname_type='IpBased',
            enable_instance_id_dns_arecord=True,
            enable_instance_id_dns_aaaarecord=True,
            enable_ip_dns_arecord=True,
            enable_ip_dns_ptr_record=True
        )
        image_options = ecs_20140526_models.RunInstancesRequestImageOptions(
            login_as_non_root=True
        )
        system_disk = ecs_20140526_models.RunInstancesRequestSystemDisk(
            category=system_disk_category,
            size=system_disk_size
        )
        run_instances_request = ecs_20140526_models.RunInstancesRequest(
            instance_charge_type='PostPaid',  # 后付费实例 和PrePaid 相对
            region_id=self.region,
            v_switch_id=v_switch_id,
            private_ip_address=private_ip_address,
            instance_type=instance_type,
            spot_strategy='SpotAsPriceGo', # 最优方式就是系统自动出价 
            spot_interruption_behavior='Stop',
            image_id=image_id,
            system_disk=system_disk,
            internet_charge_type='PayByTraffic',
            internet_max_bandwidth_out=100,
            security_group_ids=security_group_ids,
            password=password,
            image_options=image_options,
            instance_name=instance_name,
            private_dns_name_options=private_dns_name_options
            
        )
        runtime = util_models.RuntimeOptions()
        try:
            res=self.__client.run_instances_with_options(run_instances_request, runtime)
            print(json.dumps(res.to_map(), indent=2, ensure_ascii=False))
        except Exception as error:
            print(error.message)
            print(error.data.get("Recommend"))
            UtilClient.assert_as_string(error.message)





    @staticmethod
    def _getecs():
        if ClientConf().config is None:
            print("ECS客户端未初始化，请先配置阿里云凭证")
            return

        describe_instances_request = ecs_20140526_models.DescribeInstancesRequest(
            region_id=ClientConf().region
        )
        runtime = util_models.RuntimeOptions()
        ClientConf().config.endpoint = f'ecs.{ClientConf().region}.aliyuncs.com'
        res=Ecs20140526Client(ClientConf().config).describe_instances_with_options(describe_instances_request, runtime)
        
        # print(json.dumps(res.to_map(), indent=2, ensure_ascii=False))
        return res 



    @staticmethod
    def ls(block=True) -> None:
        """
        列出当前region下的所有ECS实例
        """
        try:
            res=ECS._getecs()
            # print(json.dumps(res.to_map(), indent=2, ensure_ascii=False))

            # 找出 res.body.Instances.Instance 当中的所有 instance 
            # 然后 针对每个 instance 列出他们的  
            #   InstanceId PublicIpAddress InstanceName InstanceType InternetChargeType 
            #   RegionId PrimaryIpAddress ImageId  SecurityGroupIds VSwitchId  VpcId
            instances = res.body.instances.instance
            for instance in instances:
                # 获取主私网IP
                primary_ip = ""
                if instance.network_interfaces and instance.network_interfaces.network_interface:
                    primary_ip = instance.network_interfaces.network_interface[0].primary_ip_address
                
                # 获取交换机ID和专有网络ID
                vswitch_id = ""
                vpc_id = ""
                if instance.vpc_attributes:
                    vswitch_id = instance.vpc_attributes.v_switch_id
                    vpc_id = instance.vpc_attributes.vpc_id
                
                if block:
                    # 多行输出模式
                    print(f"实例ID: {instance.instance_id}")
                    print(f"实例状态: {instance.status}")
                    print(f"公网IP: {instance.public_ip_address}")
                    print(f"实例名称: {instance.instance_name}")
                    print(f"实例规格: {instance.instance_type}")
                    print(f"网络计费类型: {instance.internet_charge_type}")
                    print(f"地域ID: {instance.region_id}")
                    print(f"主私网IP: {primary_ip}")
                    print(f"镜像ID: {instance.image_id}")
                    print(f"安全组ID: {instance.security_group_ids}")
                    print(f"交换机ID: {vswitch_id}")
                    print(f"专有网络ID: {vpc_id}")
                    print("-" * 50)
                else:
                    # 单行输出模式
                    print(f"实例ID: {instance.instance_id} | 状态: {instance.status} | 公网IP: {instance.public_ip_address} | 名称: {instance.instance_name} | 规格: {instance.instance_type} | 计费: {instance.internet_charge_type} | 地域: {instance.region_id} | 私网IP: {primary_ip} | 镜像: {instance.image_id} | 安全组: {instance.security_group_ids} | 交换机: {vswitch_id} | VPC: {vpc_id}")


        except Exception as error:
            # 此处仅做打印展示，请谨慎对待异常处理，在工程项目中切勿直接忽略异常。
            # 错误 message
            print(f"Error occurred: {str(error)}")
            # 如果是阿里云SDK的异常，尝试获取更多信息
            if hasattr(error, 'data') and error.data:
                print(f"Recommend: {error.data.get('Recommend', 'No recommendation available')}")
            UtilClient.assert_as_string(str(error))



    def delserver(self):
        client = self.__client
        delete_instance_request = ecs_20140526_models.DeleteInstanceRequest(
            instance_id='i-wz9fa9elu2hn7sz0vilu'
        )
        runtime = util_models.RuntimeOptions()
        try:
            # 复制代码运行请自行打印 API 的返回值
            res=client.delete_instance_with_options(delete_instance_request, runtime)
            return res 
        except Exception as error:
            # 此处仅做打印展示，请谨慎对待异常处理，在工程项目中切勿直接忽略异常。
            # 错误 message
            print(error.message)
            # 诊断地址
            print(error.data.get("Recommend"))
            UtilClient.assert_as_string(error.message)
    
    
    def _get_instance_type(self):
        client = self.__client
        describe_available_resource_request = ecs_20140526_models.DescribeAvailableResourceRequest(
            region_id='cn-shenzhen',
            destination_resource='InstanceType',
            instance_charge_type='PostPaid',
            spot_strategy='SpotAsPriceGo'
        )
        runtime = util_models.RuntimeOptions()
        try:
            # 复制代码运行请自行打印 API 的返回值
            res=client.describe_available_resource_with_options(describe_available_resource_request, runtime)
            # print(json.dumps(res.to_map(), indent=2, ensure_ascii=False))
            return res 
        except Exception as error:
            # 此处仅做打印展示，请谨慎对待异常处理，在工程项目中切勿直接忽略异常。
            # 错误 message
            print(error.message)
            # 诊断地址
            print(error.data.get("Recommend"))
            UtilClient.assert_as_string(error.message)
    
    def list_instance_types(self):
        """
        列出所有可用的实例规格类型
        返回一个包含所有可用 instance_type 的列表
        但是他会返回某个大区的 所有可用区的可用资源 
        """
        try:
            res = self._get_instance_type()
            if res is None:
                return []
            
            instance_types = []
            # 遍历可用区和资源信息
            if res.body.available_zones and res.body.available_zones.available_zone:
                for zone in res.body.available_zones.available_zone:
                    if zone.available_resources and zone.available_resources.available_resource:
                        for resource in zone.available_resources.available_resource:
                            if resource.supported_resources and resource.supported_resources.supported_resource:
                                for supported in resource.supported_resources.supported_resource:
                                    if supported.value and supported.value not in instance_types:
                                        instance_types.append(supported.value)
            
            # 打印所有可用的实例类型
            print(f"共找到 {len(instance_types)} 种可用实例规格:")
            for instance_type in sorted(instance_types):
                print(f"  - {instance_type}")
            
            return instance_types
            
        except Exception as error:
            print(f"获取实例规格失败: {str(error)}")
            if hasattr(error, 'data') and error.data:
                print(f"建议: {error.data.get('Recommend', '无')}")
            return []

    def get_regions(self):
        client = self.__client
        describe_regions_request = ecs_20140526_models.DescribeRegionsRequest(
            instance_charge_type='PostPaid',
            resource_type='instance'
        )
        runtime = util_models.RuntimeOptions()
        try:
            # 复制代码运行请自行打印 API 的返回值
            res=client.describe_regions_with_options(describe_regions_request, runtime)
            # print(json.dumps(res.to_map(), indent=2, ensure_ascii=False))
            # 这里需要返回一个字典  key是 res的 body.Regions.Region.RegionId 然后value是 body.Regions.Region.RegionId 加上 body.Regions.Region.LocalName
            
            regions_dict = {}
            if res.body.regions and res.body.regions.region:
                for region in res.body.regions.region:
                    regions_dict[region.region_id] = f"{region.region_id} {region.local_name}"
            
            return regions_dict
            
        except Exception as error:
            # 此处仅做打印展示，请谨慎对待异常处理，在工程项目中切勿直接忽略异常。
            # 错误 message
            print(error.message)
            # 诊断地址
            print(error.data.get("Recommend"))
            UtilClient.assert_as_string(error.message)
            
    @staticmethod
    def get_zones():
        client_conf = ClientConf()
        client_conf.config.endpoint = f'ecs.{client_conf.region}.aliyuncs.com'
        client = Ecs20140526Client(client_conf.config)
        describe_zones_request = ecs_20140526_models.DescribeZonesRequest(
            region_id=client_conf.region,
            verbose=False,
            instance_charge_type='PostPaid'
        )
        runtime = util_models.RuntimeOptions()
        try:
            # 复制代码运行请自行打印 API 的返回值
            res=client.describe_zones_with_options(describe_zones_request, runtime)
            # print(json.dumps(res.to_map(), indent=2, ensure_ascii=False))
            # 这里需要返回一个字典  key是 Zones.Zone.ZoneId  他的value是  ZoneId 加 LocalName 加 ZoneType
            
            zones_dict = {}
            if res.body.zones and res.body.zones.zone:
                for zone in res.body.zones.zone:
                    zones_dict[zone.zone_id] = f"{zone.zone_id} {zone.local_name} {zone.zone_type}"
            
            return zones_dict
            
        except Exception as error:
            # 此处仅做打印展示，请谨慎对待异常处理，在工程项目中切勿直接忽略异常。
            # 错误 message
            print(error.message)
            # 诊断地址
            print(error.data.get("Recommend"))
            UtilClient.assert_as_string(error.message)