from __future__ import annotations

from collections import deque
import os
from copy import copy, deepcopy
from datetime import datetime, timedelta, timezone
from time import perf_counter
from typing import TYPE_CHECKING

import qtpy

from loggerplus import RobustLogger
from qtpy import QtCore
from qtpy.QtCore import QMetaObject, QThread, QTimer, Qt
from qtpy.QtWidgets import (
    QApplication,
    QMessageBox,
    QOpenGLWidget,  # pyright: ignore[reportPrivateImportUsage]
)

from pykotor.gl.scene import Scene
from pykotor.resource.formats.bwm.bwm_data import BWM
from pykotor.resource.formats.lyt.lyt_data import LYT
from pykotor.resource.generics.git import GITInstance
from pykotor.resource.type import ResourceType
from utility.common.geometry import Vector2, Vector3
from utility.error_handling import assert_with_variable_trace

if TYPE_CHECKING:
    from glm import vec3  # pyright: ignore[reportMissingImports]
    from qtpy.QtCore import QPoint  # pyright: ignore[reportAttributeAccessIssue]
    from qtpy.QtGui import QFocusEvent, QKeyEvent, QMouseEvent, QOpenGLContext, QResizeEvent, QWheelEvent
    from qtpy.QtWidgets import QWidget

    from pykotor.common.module import Module, ModuleResource
    from pykotor.gl.modern_renderer import ModernGLRenderer
    from pykotor.gl.scene import RenderObject
    from pykotor.resource.formats.bwm import BWMFace
    from pykotor.resource.formats.lyt.lyt_data import LYT, LYTDoorHook, LYTObstacle, LYTRoom, LYTTrack
    from toolset.data.installation import HTInstallation


class FrameStats:
    """Lightweight frame statistics tracker used to estimate FPS."""

    __slots__ = ("_timestamps", "_frame_count")

    def __init__(self, max_samples: int = 512):
        self._timestamps: deque[float] = deque(maxlen=max_samples)
        self._frame_count: int = 0

    def reset(self) -> None:
        self._timestamps.clear()
        self._frame_count = 0

    def frame_rendered(self) -> None:
        self._timestamps.append(perf_counter())
        self._frame_count += 1

    @property
    def frame_count(self) -> int:
        return self._frame_count

    def average_fps(self, window_seconds: float | None = 1.0) -> float:
        """Return the average frames-per-second over the requested window."""
        if len(self._timestamps) < 2:
            return 0.0

        if window_seconds is not None:
            cutoff = self._timestamps[-1] - window_seconds
            while len(self._timestamps) > 2 and self._timestamps[0] < cutoff:
                self._timestamps.popleft()

        elapsed = self._timestamps[-1] - self._timestamps[0]
        if elapsed <= 0:
            return float("inf")
        return (len(self._timestamps) - 1) / elapsed


class ModuleRenderer(QOpenGLWidget):
    sig_renderer_initialized = QtCore.Signal()  # pyright: ignore[reportPrivateImportUsage]
    """Signal emitted when the context is being setup, the QMainWindow must be in an activated/unhidden state."""

    sig_scene_initialized = QtCore.Signal()  # pyright: ignore[reportPrivateImportUsage]
    """Signal emitted when scene has been initialized."""

    sig_mouse_moved = QtCore.Signal(object, object, object, object, object)  # screen coords, screen delta, world/mouse pos, mouse, keys  # pyright: ignore[reportPrivateImportUsage]  # noqa: E501
    """Signal emitted when mouse is moved over the widget."""

    sig_mouse_scrolled = QtCore.Signal(object, object, object)  # screen delta, mouse, keys  # pyright: ignore[reportPrivateImportUsage]
    """Signal emitted when mouse is scrolled over the widget."""

    sig_mouse_released = QtCore.Signal(object, object, object)  # screen coords, mouse, keys  # pyright: ignore[reportPrivateImportUsage]
    """Signal emitted when a mouse button is released after being pressed on the widget."""

    sig_mouse_pressed = QtCore.Signal(object, object, object)  # screen coords, mouse, keys  # pyright: ignore[reportPrivateImportUsage]
    """Signal emitted when a mouse button is pressed on the widget."""

    sig_keyboard_pressed = QtCore.Signal(object, object)  # mouse, keys  # pyright: ignore[reportPrivateImportUsage]

    sig_keyboard_released = QtCore.Signal(object, object)  # mouse, keys  # pyright: ignore[reportPrivateImportUsage]

    sig_object_selected = QtCore.Signal(object)  # pyright: ignore[reportPrivateImportUsage]
    """Signal emitted when an object has been selected through the renderer."""

    sig_lyt_updated = QtCore.Signal(object)  # pyright: ignore[reportPrivateImportUsage]
    """Signal emitted when the LYT data has been updated."""

    def __init__(self, parent: QWidget):
        super().__init__(parent)

        from toolset.gui.windows.module_designer import (
            ModuleDesignerSettings,  # noqa: PLC0415  # pylint: disable=C0415
        )

        self._scene: Scene | None = None
        self.settings: ModuleDesignerSettings = ModuleDesignerSettings()
        self._module: Module | None = None
        self._installation: HTInstallation | None = None
        self._lyt: LYT | None = None
        self._lyt_editor = None  # Will hold the LYT editor instance

        self.loop_timer: QTimer = QTimer(self)
        self.loop_timer.timeout.connect(self.loop)
        self.loop_interval: int = 16  # ms, approx 60 FPS (improved from 30)

        self._render_time: int = 0
        self._keys_down: set[Qt.Key] = set()
        self._mouse_down: set[Qt.MouseButton] = set()
        self._mouse_prev: Vector2 = Vector2(self.cursor().pos().x(), self.cursor().pos().y())
        self._mouse_press_time: datetime = datetime.now(tz=timezone.utc).astimezone()

        self.do_select: bool = False  # Set to true to select object at mouse pointer
        self.free_cam: bool = False  # Changes how screenDelta is calculated in mouseMoveEvent
        self.delta: float = 0.0166  # Approx 60 FPS frame time
        self._frame_stats: FrameStats = FrameStats()
        self._modern_renderer: ModernGLRenderer | None = None
        self._modern_context: moderngl.Context | None = None
        # Default to ModernGL if available, fallback to PyOpenGL
        default_moderngl = bool(int(os.environ.get("PYKOTOR_USE_MODERNGL", "1")))
        self._use_moderngl = default_moderngl
        self._initializing = False  # Flag to prevent resize events during initialization
        self._gl_initialized = False  # Track if initializeGL has been called

    @property
    def scene(self) -> Scene:
        if self._scene is None:
            instance: QtCore.QCoreApplication | None = QApplication.instance()  # pyright: ignore[reportAttributeAccessIssue]
            assert instance is not None
            if QThread.currentThread() == instance.thread():
                self.show_scene_not_ready_message()
            else:
                QMetaObject.invokeMethod(self, "showSceneNotReadyMessage", Qt.ConnectionType.QueuedConnection)
            raise ValueError("Scene is not initialized.")
        assert self._scene is not None
        return self._scene

    def show_scene_not_ready_message(self):
        from toolset.gui.common.localization import translate as tr
        QMessageBox.warning(self, tr("Scene Not Ready"), tr("The scene is not ready yet."))

    def isReady(self) -> bool:
        return bool(self._module and self._installation)

    def initialize_renderer(
        self,
        installation: HTInstallation,
        module: Module,
    ):
        RobustLogger().debug("Initialize ModuleRenderer")
        self.shutdown_renderer()
        self._initializing = True  # Set flag to prevent resize events during initialization
        try:
            self.show()
        finally:
            # Flag will be cleared after initializeGL is called
            pass
        QApplication.processEvents()  # Force the application to process all pending events
        self.sig_renderer_initialized.emit()  # Tell QMainWindow to show itself, required for a gl context to be created.

        # Check if the widget and its top-level window are visible
        if not self.isVisible() or (self.window() and not self.window().isVisible()):
            RobustLogger().error("Widget or its window is not visible; OpenGL context may not be initialized.")
            raise RuntimeError("The OpenGL context is not available because the widget or its parent window is not visible.")

        # Wait for OpenGL context to be created and initialized
        # Qt calls initializeGL() when the widget is first shown, but this may happen asynchronously
        # In headless/offscreen mode, we need to wait a bit longer and process events
        max_attempts = 50
        for attempt in range(max_attempts):
            ctx = self.context()
            if ctx is not None and ctx.isValid():
                # Try to make the context current to ensure initializeGL was called
                try:
                    self.makeCurrent()
                    # Force initializeGL call if it hasn't been called yet (headless mode workaround)
                    # Qt should call it automatically, but in headless mode we may need to ensure it
                    if hasattr(self, '_gl_initialized') and not self._gl_initialized:
                        self.initializeGL()
                        self._gl_initialized = True
                    break  # Context is ready
                except Exception:
                    pass  # Context exists but not ready yet
            
            # Process events to allow Qt to call initializeGL
            QApplication.processEvents()
            QApplication.processEvents()  # Process twice to ensure events are handled
            
            if attempt < max_attempts - 1:
                from time import sleep
                sleep(0.01)  # Small delay to allow Qt to initialize
        
        # Final check if a context is available
        ctx = self.context()
        if ctx is None or not ctx.isValid():
            RobustLogger().error("initializeGL was not called or did not complete successfully after waiting.")
            raise RuntimeError("Failed to initialize OpenGL context. Ensure that the widget is visible and properly integrated into the application's window.")

        # Ensure OpenGL context is current before creating Scene
        # Note: makeCurrent() returns None in PyQt5, so we can't check its return value
        self.makeCurrent()

        self._installation = installation
        self._module = module
        self._scene = Scene(installation=installation, module=module)

        # Initialize module data
        lyt: ModuleResource[LYT] | None = module.layout()
        if lyt is not None:
            self._scene.layout = lyt.resource()

        self.scene.camera.fov = self.settings.fieldOfView
        self.scene.camera.width = self.width()
        self.scene.camera.height = self.height()
        self.sig_scene_initialized.emit()
        self.resume_render_loop()

    def initializeGL(self):
        RobustLogger().debug("ModuleRenderer.initializeGL called.")
        # Ensure OpenGL context is current
        self.makeCurrent()

        super().initializeGL()
        self._gl_initialized = True  # Mark as initialized
        self._initializing = False  # Clear initialization flag - resize events are now safe
        RobustLogger().debug("ModuleRenderer.initializeGL - opengl context setup.")
        if self._use_moderngl:
            try:
                import moderngl  # pyright: ignore[reportMissingImports]  # noqa: WPS433
                from pykotor.gl.modern_renderer import ModernGLRenderer  # noqa: WPS433

                # Ensure context is current before creating ModernGL context
                # ModernGL will wrap the existing Qt OpenGL context
                if not self.context() or not self.context().isValid():
                    raise RuntimeError("Qt OpenGL context is not valid")
                
                # Create ModernGL context from existing Qt context
                # moderngl.create_context() automatically detects the current OpenGL context
                # when called with an active OpenGL context (which we have from Qt)
                self._modern_context = moderngl.create_context()
                self._modern_renderer: ModernGLRenderer = ModernGLRenderer(self._modern_context)
                RobustLogger().info("ModernGL renderer initialised successfully")
            except Exception as exc:  # noqa: BLE001
                self._modern_renderer = None
                self._modern_context = None
                self._use_moderngl = False
                RobustLogger().warning("Failed to initialise ModernGL renderer: %s", exc)

    def resizeEvent(self, e: QResizeEvent):  # pyright: ignore[reportIncompatibleMethodOverride]
        RobustLogger().debug("ModuleRenderer resizeEvent called.")
        # Skip resize events during initialization to avoid access violations
        if self._initializing:
            RobustLogger().debug("Skipping resizeEvent during initialization")
            return
        
        # Ensure OpenGL context is valid and current before Qt tries to resize
        # This is critical for ModernGL to avoid access violations
        ctx = self.context()
        if ctx is None or not ctx.isValid():
            RobustLogger().warning("OpenGL context not valid in resizeEvent, skipping resize")
            return
        
        try:
            self.makeCurrent()
            # If ModernGL is active, ensure it's initialized before resizing
            if self._use_moderngl and self._modern_context is None:
                RobustLogger().debug("ModernGL not initialized yet, deferring resize")
                # ModernGL will be initialized in initializeGL, resize will happen later
                return
        except Exception as exc:
            RobustLogger().warning("Failed to make context current in resizeEvent: %s", exc)
            return
        
        super().resizeEvent(e)

    def resizeGL(  # pyright: ignore[reportIncompatibleMethodOverride]
        self,
        width: int,
        height: int,
    ):
        RobustLogger().debug("ModuleRenderer resizeGL called.")
        # Ensure context is current before Qt tries to resize
        # This is critical for ModernGL to avoid access violations
        try:
            self.makeCurrent()
        except Exception:
            RobustLogger().warning("Failed to make context current in resizeGL, continuing anyway")
        super().resizeGL(width, height)
        if not self._scene:
            RobustLogger().debug("ignoring scene camera width/height updates in ModuleRenderer resizeGL - the scene is not initialized yet.")
            return
        self.scene.camera.width = width
        self.scene.camera.height = height

    def resume_render_loop(self):
        """Resumes the rendering loop by starting the timer."""
        RobustLogger().debug("ModuleRenderer - resumeRenderLoop called.")
        if not self.loop_timer.isActive():
            self.loop_timer.start(self.loop_interval)
        self.scene.camera.width = self.width()
        self.scene.camera.height = self.height()

    def pause_render_loop(self):
        """Pauses the rendering loop by stopping the timer."""
        RobustLogger().debug("ModuleRenderer - pauseRenderLoop called.")
        if self.loop_timer.isActive():
            self.loop_timer.stop()

    def shutdown_renderer(self):
        """Stops the rendering loop, unloads the module and installation, and attempts to destroy the OpenGL context."""
        RobustLogger().debug("ModuleRenderer - shutdownRenderer called.")
        self.pause_render_loop()
        self._frame_stats.reset()
        self._module = None
        self._installation = None
        self._lyt = None

        # Attempt to destroy the OpenGL context
        gl_context: QOpenGLContext | None = self.context()
        if gl_context:
            gl_context.doneCurrent()  # Ensure the context is not current
            self.update()  # Trigger an update which will indirectly handle context recreation when needed
        self._modern_renderer = None
        if self._modern_context is not None:
            try:
                self._modern_context.release()
            except Exception:  # noqa: BLE001
                pass
            self._modern_context = None

        self.hide()
        self._scene = None

    def set_lyt(self, lyt: LYT) -> None:
        """Set the current LYT data and update the scene."""
        self._lyt = deepcopy(lyt)
        if self._scene:
            self._scene.layout = self._lyt
            self.update()
        self.sig_lyt_updated.emit(self._lyt)

    def get_lyt(self) -> LYT | None:
        """Returns the current LYT data."""
        return self._lyt

    def add_room(
        self,
        room: LYTRoom,
    ):
        """Adds a new room to the LYT data and triggers a redraw."""
        if self._lyt is not None:
            self._lyt.rooms.append(room)
            self.sig_lyt_updated.emit(self._lyt)
            self.update()

    def add_track(
        self,
        track: LYTTrack,
    ):
        """Adds a new track to the LYT data and triggers a redraw."""
        if self._lyt is not None:
            self._lyt.tracks.append(track)
            self.sig_lyt_updated.emit(self._lyt)
            self.update()

    def add_obstacle(
        self,
        obstacle: LYTObstacle,
    ):
        """Adds a new obstacle to the LYT data and triggers a redraw."""
        if self._lyt is not None:
            self._lyt.obstacles.append(obstacle)
            self.sig_lyt_updated.emit(self._lyt)
            self.update()

    def add_door_hook(
        self,
        doorhook: LYTDoorHook,
    ):
        """Adds a new doorhook to the LYT data and triggers a redraw."""
        if self._lyt is not None:
            self._lyt.doorhooks.append(doorhook)
            self.sig_lyt_updated.emit(self._lyt)
            self.update()

    def update_lyt_preview(self) -> None:
        """Update the LYT preview in the scene."""
        if self._scene and self._lyt:
            self._scene.layout = self._lyt
            self.update()
            self.sig_lyt_updated.emit(self._lyt)

    def remove_room(self, room: LYTRoom) -> None:
        """Remove a room from the LYT."""
        if self._lyt and room in self._lyt.rooms:
            self._lyt.rooms.remove(room)
            self.update_lyt_preview()

    def remove_track(self, track: LYTTrack) -> None:
        """Remove a track from the LYT."""
        if self._lyt and track in self._lyt.tracks:
            self._lyt.tracks.remove(track)
            self.update_lyt_preview()

    def remove_obstacle(self, obstacle: LYTObstacle) -> None:
        """Remove an obstacle from the LYT."""
        if self._lyt and obstacle in self._lyt.obstacles:
            self._lyt.obstacles.remove(obstacle)
            self.update_lyt_preview()

    def remove_door_hook(
        self,
        doorhook: LYTDoorHook,
    ) -> None:
        """Remove a door hook from the LYT."""
        if self._lyt and doorhook in self._lyt.doorhooks:
            self._lyt.doorhooks.remove(doorhook)
            self.update_lyt_preview()

    def paintGL(self):
        """Optimized paintGL with lazy cursor updates.
        
        Performance optimizations:
        - Cursor world position only calculated when mouse is within bounds
        - screen_to_world only called when cursor position has changed significantly
        - Selection picking separated from rendering
        
        Reference: Standard game engine practice - minimize expensive per-frame operations
        """
        if not self.loop_timer.isActive():
            return
        if not self.isReady():
            return  # Do nothing if not initialized

        # Ensure OpenGL context is current before any GL calls
        self.makeCurrent()
        super().paintGL()
        
        # Handle object selection (only when requested)
        if self.do_select:
            self.do_select = False
            obj: RenderObject | None = self.scene.pick(self._mouse_prev.x, self.height() - self._mouse_prev.y)

            if obj is not None and isinstance(obj.data, GITInstance):
                self.sig_object_selected.emit(obj.data)
            else:
                self.scene.selection.clear()
                self.sig_object_selected.emit(None)

        # Update cursor position only when mouse is within bounds
        # This is an expensive operation so we throttle it
        screen_cursor: QPoint = self.mapFromGlobal(self.cursor().pos())
        cursor_in_bounds = (
            0 <= screen_cursor.x() < self.width() and
            0 <= screen_cursor.y() < self.height()
        )
        
        if cursor_in_bounds:
            # Only update world cursor if screen position has changed enough
            # This avoids expensive screen_to_world calls every frame
            cursor_delta = abs(screen_cursor.x() - self._mouse_prev.x) + abs(screen_cursor.y() - self._mouse_prev.y)
            if cursor_delta > 2 or not hasattr(self, "_last_cursor_update"):  # Threshold of 2 pixels
                world_cursor: Vector3 = self.scene.screen_to_world(screen_cursor.x(), screen_cursor.y())
                self.scene.cursor.set_position(world_cursor.x, world_cursor.y, world_cursor.z)
                self._last_cursor_update = True

        # Main render pass
        if self._modern_renderer is not None and self._use_moderngl:
            self._modern_renderer.render(self.scene)
        else:
            self.scene.render()
        self._frame_stats.frame_rendered()

    def loop(self):
        """Repaints and checks for keyboard input on mouse press.

        Processing Logic:
        ----------------
            - Always repaints to ensure smooth rendering
            - Checks if mouse is over object and keyboard keys are pressed
            - Emits keyboardPressed signal with mouse/key info
        """
        # Use update() instead of repaint() - this schedules a repaint rather than
        # forcing an immediate synchronous paint. Qt will batch multiple update()
        # calls into a single paint, which is more efficient.
        # repaint() bypasses the event queue and can cause stuttering.
        self.update()
        
        if self.underMouse() and self.free_cam and len(self._keys_down) > 0:
            self.sig_keyboard_pressed.emit(self._mouse_down, self._keys_down)

    @property
    def frame_stats(self) -> FrameStats:
        """Expose frame statistics for diagnostics and tests."""
        return self._frame_stats

    def average_fps(self, window_seconds: float | None = 1.0) -> float:
        """Return the average FPS calculated over the requested time window."""
        return self._frame_stats.average_fps(window_seconds)

    def set_renderer_type(self, use_moderngl: bool) -> None:
        """Set the renderer type to use.
        
        Args:
            use_moderngl: If True, use ModernGL renderer; if False, use PyOpenGL renderer.
        """
        if self._use_moderngl == use_moderngl:
            return  # No change needed
        
        self._use_moderngl = use_moderngl
        
        # If switching to ModernGL and not already initialized, initialize it
        if use_moderngl and self._modern_renderer is None:
            self.makeCurrent()
            try:
                import moderngl  # noqa: WPS433
                from pykotor.gl.modern_renderer import ModernGLRenderer  # noqa: WPS433

                # Ensure context is valid before creating ModernGL context
                ctx = self.context()
                if ctx is None or not ctx.isValid():
                    raise RuntimeError("Qt OpenGL context is not valid")
                
                # Create ModernGL context from existing Qt context
                # moderngl.create_context() automatically detects the current OpenGL context
                self._modern_context = moderngl.create_context()
                self._modern_renderer = ModernGLRenderer(self._modern_context)
                RobustLogger().info("ModernGL renderer initialized on demand")
            except Exception as exc:  # noqa: BLE001
                self._modern_renderer = None
                self._modern_context = None
                self._use_moderngl = False
                RobustLogger().warning("Failed to initialize ModernGL renderer: %s", exc)
                raise RuntimeError(f"Failed to initialize ModernGL renderer: {exc}") from exc

    @property
    def renderer_type(self) -> str:
        """Return the current renderer type as a string."""
        if self._use_moderngl and self._modern_renderer is not None:
            return "moderngl"
        return "pyopengl"

    def walkmesh_point(
        self,
        x: float,
        y: float,
        default_z: float = 0.0,
    ) -> Vector3:
        """Finds the face and z-height at a point on the walkmesh.

        Args:
        ----
            x: float - The x coordinate of the point
            y: float - The y coordinate of the point
            default_z: float = 0.0 - The default z height if no face is found

        Returns:
        -------
            Vector3 - The (x, y, z) position on the walkmesh

        Processing Logic:
        ----------------
            - Iterates through walkmesh resources to find the face at the given (x,y) coordinates
            - Checks if the found face is walkable, and overrides any previous less walkable face
            - Returns a Vector3 with the input x,y coords and either the face z height or default z if no face.
        """
        face: BWMFace | None = None
        assert self._module is not None
        for module_resource in self._module.resources.values():
            if module_resource.restype() is not ResourceType.WOK:
                continue
            walkmesh_resource = module_resource.resource()
            if walkmesh_resource is None:
                continue
            assert isinstance(walkmesh_resource, BWM), assert_with_variable_trace(isinstance(walkmesh_resource, BWM))
            over: BWMFace | None = walkmesh_resource.faceAt(x, y)
            if over is None:
                continue
            if face is None:  # noqa: SIM114
                face = over
            elif not face.material.walkable() and over.material.walkable():
                face = over

        z: float = default_z if face is None else face.determine_z(x, y)
        return Vector3(x, y, z)

    def reset_buttons_down(self):
        self._mouse_down.clear()

    def reset_keys_down(self):
        self._keys_down.clear()

    def reset_all_down(self):
        self._mouse_down.clear()
        self._keys_down.clear()

    # region Accessors
    def keys_down(self) -> set[Qt.Key]:
        return copy(self._keys_down)

    def mouse_down(self) -> set[Qt.MouseButton]:
        return copy(self._mouse_down)

    # endregion

    # region Camera Transformations
    def snap_camera_to_point(
        self,
        point: Vector3,
        distance: float = 6.0,
    ):
        camera = self.scene.camera
        camera.x, camera.y, camera.z = point.x, point.y, point.z + 1.0
        camera.distance = distance

    def pan_camera(
        self,
        forward: float,
        right: float,
        up: float,
    ):
        forward_vec: vec3 = forward * self.scene.camera.forward()
        sideways: vec3 = right * self.scene.camera.sideward()

        self.scene.camera.x += forward_vec.x + sideways.x
        self.scene.camera.y += forward_vec.y + sideways.y
        self.scene.camera.z += up

    def move_camera(
        self,
        forward: float,
        right: float,
        up: float,
    ):
        forward_vec: vec3 = forward * self.scene.camera.forward(ignore_z=False)
        sideways: vec3 = right * self.scene.camera.sideward(ignore_z=False)
        upward: vec3 = -up * self.scene.camera.upward(ignore_xy=False)

        self.scene.camera.x += upward.x + sideways.x + forward_vec.x
        self.scene.camera.y += upward.y + sideways.y + forward_vec.y
        self.scene.camera.z += upward.z + sideways.z + forward_vec.z

    def rotate_camera(
        self,
        yaw: float,
        pitch: float,
        *,
        clamp_rotations: bool = True,  # noqa: FBT001
    ):
        self.scene.camera.rotate(yaw, pitch, clamp=clamp_rotations)

    def zoom_camera(
        self,
        distance: float,
    ):
        self.scene.camera.distance -= distance
        self.scene.camera.distance = max(self.scene.camera.distance, 0)

    # endregion

    # region Events

    def focusOutEvent(self, e: QFocusEvent):  # pyright: ignore[reportIncompatibleMethodOverride]
        self._mouse_down.clear()  # Clears the set when focus is lost
        self._keys_down.clear()  # Clears the set when focus is lost
        super().focusOutEvent(e)  # Ensures that the default handler is still executed
        print("ModuleRenderer.focusOutEvent: clearing all keys/buttons held down.")

    def wheelEvent(self, e: QWheelEvent):  # pyright: ignore[reportIncompatibleMethodOverride]
        super().wheelEvent(e)
        if e is None:
            return
        self.sig_mouse_scrolled.emit(Vector2(e.angleDelta().x(), e.angleDelta().y()), self._mouse_down, self._keys_down)

    def mouseMoveEvent(self, e: QMouseEvent):  # pyright: ignore[reportIncompatibleMethodOverride]
        #super().mouseMoveEvent(e)
        if e is None:
            return
        pos: QPoint = e.pos() if qtpy.QT5 else e.position().toPoint()  # type: ignore[attr-defined] # pyright: ignore[reportAttributeAccessIssue]
        screen: Vector2 = Vector2(pos.x(), pos.y())
        if self.free_cam:
            screenDelta = Vector2(screen.x - self.width() / 2, screen.y - self.height() / 2)
        else:
            screenDelta = Vector2(screen.x - self._mouse_prev.x, screen.y - self._mouse_prev.y)

        world = self.scene.cursor.position()
        if datetime.now(tz=timezone.utc).astimezone() - self._mouse_press_time > timedelta(milliseconds=60):
            self.sig_mouse_moved.emit(screen, screenDelta, world, self._mouse_down, self._keys_down)
        self._mouse_prev = screen  # Always assign mouse_prev after emitting: allows signal handlers (e.g. ModuleDesigner, GITEditor) to handle cursor lock.

    def mousePressEvent(self, e: QMouseEvent):  # pyright: ignore[reportIncompatibleMethodOverride]
        super().mousePressEvent(e)
        self._mouse_press_time = datetime.now(tz=timezone.utc).astimezone()
        button: Qt.MouseButton = e.button()
        self._mouse_down.add(button)
        pos: QPoint = e.pos() if qtpy.QT5 else e.position().toPoint()  # type: ignore[attr-defined] # pyright: ignore[reportAttributeAccessIssue]
        coords: Vector2 = Vector2(pos.x(), pos.y())
        self.sig_mouse_pressed.emit(coords, self._mouse_down, self._keys_down)
        #RobustLogger().debug(f"ModuleRenderer.mousePressEvent: {self._mouse_down}, e.button() '{button}'")

    def mouseReleaseEvent(self, e: QMouseEvent):  # pyright: ignore[reportIncompatibleMethodOverride]
        super().mouseReleaseEvent(e)
        button = e.button()
        self._mouse_down.discard(button)

        pos: QPoint = e.pos() if qtpy.QT5 else e.position().toPoint()  # type: ignore[attr-defined] # pyright: ignore[reportAttributeAccessIssue]
        coords: Vector2 = Vector2(pos.x(), pos.y())
        self.sig_mouse_released.emit(coords, self._mouse_down, self._keys_down)
        #RobustLogger().debug(f"ModuleRenderer.mouseReleaseEvent: {self._mouse_down}, e.button() '{button}'")

    def keyPressEvent(  # pyright: ignore[reportIncompatibleMethodOverride]
        self,
        e: QKeyEvent | None,
        bubble: bool = True,  # noqa: FBT001, FBT002
    ):
        super().keyPressEvent(e)
        if e is None:
            return
        key = e.key()
        self._keys_down.add(key)  # pyright: ignore[reportArgumentType]
        if self.underMouse() and not self.free_cam:
            self.sig_keyboard_pressed.emit(self._mouse_down, self._keys_down)
        #key_name = get_qt_key_string_localized(key)
        #RobustLogger().debug(f"ModuleRenderer.keyPressEvent: {self._keys_down}, e.key() '{key_name}'")

    def keyReleaseEvent(  # pyright: ignore[reportIncompatibleMethodOverride]
        self,
        e: QKeyEvent | None,
        bubble: bool = True,  # noqa: FBT002, FBT001
    ):
        super().keyReleaseEvent(e)
        if e is None:
            return
        key: Qt.Key | int = e.key()
        self._keys_down.discard(key)  # pyright: ignore[reportArgumentType]
        if self.underMouse() and not self.free_cam:
            self.sig_keyboard_released.emit(self._mouse_down, self._keys_down)
        # key_name = get_qt_key_string_localized(key)
        # RobustLogger().debug(f"ModuleRenderer.keyReleaseEvent: {self._keys_down}, e.key() '{key_name}'")

    # endregion
