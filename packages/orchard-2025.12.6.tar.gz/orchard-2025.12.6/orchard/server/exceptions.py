class InferenceError(Exception):
    """Custom exception for inference-related errors."""

    pass
