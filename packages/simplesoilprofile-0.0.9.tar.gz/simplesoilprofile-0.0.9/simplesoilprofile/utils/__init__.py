"""Utility functions and configuration for the simplesoilprofile package."""
