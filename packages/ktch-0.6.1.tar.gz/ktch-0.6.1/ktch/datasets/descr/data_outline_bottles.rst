Momocs Bottle Outline Dataset
======================================