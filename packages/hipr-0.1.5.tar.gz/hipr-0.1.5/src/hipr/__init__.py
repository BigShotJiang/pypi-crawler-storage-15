"""hipr - Automatic Pydantic config generation from function signatures."""

__version__ = "0.1.5"

from hipr.config import (
  DEFAULT,
  ConfigurableIndicator,
  Ge,
  Gt,
  Hyper,
  Le,
  Lt,
  MakeableModel,
  MaxLen,
  MinLen,
  MultipleOf,
  Pattern,
  configurable,
  validate_config,  # pyright: ignore[reportAttributeAccessIssue, reportUnknownVariableType]
)
from hipr.constraints import InvalidPatternError

__all__ = [
  "DEFAULT",
  "ConfigurableIndicator",
  "Ge",
  "Gt",
  "Hyper",
  "InvalidPatternError",
  "Le",
  "Lt",
  "MakeableModel",
  "MaxLen",
  "MinLen",
  "MultipleOf",
  "Pattern",
  "__version__",
  "configurable",
  "validate_config",
]
