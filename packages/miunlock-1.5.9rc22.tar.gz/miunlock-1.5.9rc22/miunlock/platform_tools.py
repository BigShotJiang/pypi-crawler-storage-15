import os
import subprocess
import platform
import shutil
import urllib.request
import zipfile
import stat
from pathlib import Path

def fix_termux_repo(PREFIX):
    sources_file = f"{PREFIX}/etc/apt/sources.list"
    
    try:
        with open(sources_file, 'r') as f:
            content = f.read()
        
        if 'packages-cf.termux.dev' in content:
            backup = f"{sources_file}.bak"
            shutil.copy2(sources_file, backup)
            
            content = content.replace(
                'packages-cf.termux.dev/apt/termux-main',
                'grimler.se/termux-main'
            )
            
            with open(sources_file, 'w') as f:
                f.write(content)
            
            return True
            
    except Exception as e:
        print(f"Could not check/fix mirror: {e}")
    
    return False

def ensure_termux_repo_working(PREFIX):
    result = subprocess.run(
        "yes | apt update",
        shell=True,
        capture_output=True,
        text=True,
        timeout=30
    )
    
    error_indicators = [
        'Could not connect',
        'Connection timed out',
        'Network is unreachable',
        'Failed to fetch'
    ]
    
    has_connection_error = any(
        indicator in result.stderr or indicator in result.stdout
        for indicator in error_indicators
    )
    
    if has_connection_error or result.returncode != 0:
        fix_termux_repo(PREFIX)
        
        alternative_mirrors = [
            "https://grimler.se/termux-main",
            "https://packages.termux.dev/apt/termux-main",
            "https://termux.mentality.rip/termux-main"
        ]
        
        sources_file = f"{PREFIX}/etc/apt/sources.list"
        
        for mirror in alternative_mirrors:
            with open(sources_file, 'w') as f:
                f.write(f"deb {mirror} stable main\n")
            
            test_result = subprocess.run(
                "yes | apt update",
                shell=True,
                capture_output=True,
                text=True,
                timeout=30
            )
            
            if test_result.returncode == 0:
                return True
        
        return False
    
    return True

def main(PREFIX):
    if not ensure_termux_repo_working(PREFIX):
        return {'error': 'All repository mirrors failed. Please check your internet connection.'}
    
    result = subprocess.run("yes | apt update", shell=True, capture_output=True, text=True)
    if result.returncode != 0:
        return {'error': 'update failed'}

    result = subprocess.run("yes | apt upgrade", shell=True, capture_output=True, text=True)
    if result.returncode != 0:
        return {'error': 'upgrade failed'}

    result = subprocess.run("yes | apt install coreutils gnupg curl", shell=True, capture_output=True, text=True)
    if result.returncode != 0:
        return {'error': 'install packages failed'}

    repo_file = f"{PREFIX}/etc/apt/sources.list.d/termux-adb.list"

    if not os.path.isfile(repo_file):
        os.makedirs(f"{PREFIX}/etc/apt/sources.list.d", exist_ok=True)
        
        with open(repo_file, 'w') as f:
            f.write("deb https://nohajc.github.io termux extras\n")

        gpg_path = f"{PREFIX}/etc/apt/trusted.gpg.d/nohajc.gpg"
        
        result = subprocess.run(
            f"curl -fsSL -o {gpg_path} https://nohajc.github.io/nohajc.gpg",
            shell=True,
            timeout=30
        )
        
        if result.returncode != 0:
            return {'error': 'curl GPG key failed'}

        result = subprocess.run("yes | apt update", shell=True, capture_output=True, text=True)
        if result.returncode != 0:
            return {'error': 'update after repo add failed'}

    result = subprocess.run("yes | apt install termux-adb", shell=True, capture_output=True, text=True)
    if result.returncode != 0:
        return {'error': 'install termux-adb failed'}

    fastboot_path = f"{PREFIX}/bin/termux-fastboot"

    if os.path.isfile(fastboot_path):
        return fastboot_path
    else:
        return {'error': 'termux-fastboot not found after installation'}


s = platform.system()

def check_fastboot():
    if s == "Linux" and os.path.exists("/data/data/com.termux"):      
        if not os.path.exists("/data/data/com.termux.api"):
            return {"error": "com.termux.api app is not installed\nPlease install it first"}

        PREFIX = os.environ.get('PREFIX', '/data/data/com.termux/files/usr')
        fastboot_path = f"{PREFIX}/bin/termux-fastboot"

        if not os.path.isfile(fastboot_path):
            print("\nSetting up termux-fastboot ... from https://github.com/nohajc/termux-adb\n")
            result = main(PREFIX)
            return result

        return fastboot_path

    cmd = shutil.which("fastboot")        
    if cmd is not None:
        return cmd

    tools_dir = Path.home() / ".android-tools" / "platform-tools"
    
    fastboot_path = tools_dir / "fastboot"
    if s == "Windows":
        fastboot_path = tools_dir / "fastboot.exe"

    if fastboot_path.exists():
        return str(fastboot_path)

    print("\nDownloading platform-tools...")
    
    system_map = {
        "Linux": "linux",
        "Darwin": "darwin",
        "Windows": "windows"
    }
    
    os_name = system_map.get(s, s.lower())
    url = f"https://dl.google.com/android/repository/platform-tools-latest-{os_name}.zip"

    tools_dir.parent.mkdir(parents=True, exist_ok=True)
    zip_path = tools_dir.parent / "platform-tools.zip"

    try:
        urllib.request.urlretrieve(url, str(zip_path))

        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(str(tools_dir.parent))

        zip_path.unlink()

        if s in ["Linux", "Darwin"]:
            st = os.stat(fastboot_path)
            os.chmod(fastboot_path, st.st_mode | stat.S_IEXEC)

        return str(fastboot_path)

    except Exception as e:
        return {"error": f"Failed to download platform-tools: {str(e)}"}
