"""hygrep - Hybrid grep: fast scanning + neural reranking."""

__version__ = "0.0.12"
