# treesa-ai-helper

A simple AI helper library created by Treesa for generating responses using Gemini.

## Installation

```bash
pip install treesa-ai-helper

from treesa_ai import get_response

reply = get_response("Explain Python functions")
print(reply)