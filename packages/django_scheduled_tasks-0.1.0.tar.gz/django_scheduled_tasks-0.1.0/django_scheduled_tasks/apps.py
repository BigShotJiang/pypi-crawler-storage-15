from django.apps import AppConfig


class DjangoScheduledTasksConfig(AppConfig):
    name = "django_scheduled_tasks"
