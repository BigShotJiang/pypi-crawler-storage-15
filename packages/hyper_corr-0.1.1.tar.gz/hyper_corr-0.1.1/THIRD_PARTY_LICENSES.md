# Third-Party Licenses

## SciPy (BSD-3-Clause)

This project incorporates and adapts routines originally implemented in SciPy. The following copyright attributions apply to
those portions:

- Copyright (c) 2001-2002 Enthought, Inc. All rights reserved.
- Copyright (c) 2003-2023 SciPy Developers. All rights reserved.

The unmodified BSD-3-Clause license text that governs the upstream SciPy code is bundled once at
[`licenses/SciPy_LICENSE.txt`](licenses/SciPy_LICENSE.txt) for redistribution clarity.
