"""Outputs initialization."""
