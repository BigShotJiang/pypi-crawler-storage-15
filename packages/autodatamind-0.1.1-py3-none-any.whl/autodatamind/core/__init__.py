"""Core modules initialization."""
