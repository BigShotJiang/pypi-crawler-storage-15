from .time_average_map import TerraTimeAverageMap

__all__ = ["TerraTimeAverageMap"]