import panel as pn

pn.extension()

pn.panel("Here for technical reasons (Ruff).").servable()
