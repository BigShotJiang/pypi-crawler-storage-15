""" Test settings
"""

SECRET_KEY = "fake-key"
INSTALLED_APPS = []

MONGODB_INDEXING = False
MONGODB_ASYNC_SAVE = False
