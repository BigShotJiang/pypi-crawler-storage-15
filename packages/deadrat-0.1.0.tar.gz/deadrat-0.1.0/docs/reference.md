# Справочник API

---

::: deadrat.Bot

---

## Декораторы

Используйте эти методы для регистрации функций-обработчиков.

::: deadrat.Bot.command

::: deadrat.Bot.on_message

::: deadrat.Bot.event

---

::: deadrat.Message

---

::: deadrat.SentMessage

---

::: deadrat.Author
