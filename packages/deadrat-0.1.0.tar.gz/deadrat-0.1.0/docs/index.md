# DeadRat Bot Framework 🐀

Легкий синхронный фреймворк для Telegram ботов.

## Установка

```bash
pip install deadrat
```

## Первый бот

Создайте файл `main.py` и вставьте следующий код:

```python
from deadrat import Bot, Message

# 1. Инициализация
bot = Bot("API_KEY") # Замените на свой ключ

# 2. Обработка команды /start
@bot.command("/start")
def start(msg: Message):
    msg.reply(f"Привет, {msg.author.username}!")

# 3. Запуск
bot.run()
```

---

### 📚 Возможности

Этим функционал не ограничивается. Фреймворк умеет:

- Отправлять файлы и картинки.
- Редактировать и удалять сообщения.
- Обрабатывать аргументы команд (например, `/ban user`).
- Ловить системные события (ошибки, старт, выключение).
  </br></br>
  [📖 Читать полную документацию API](reference.md){ .md-button .md-button--primary }
