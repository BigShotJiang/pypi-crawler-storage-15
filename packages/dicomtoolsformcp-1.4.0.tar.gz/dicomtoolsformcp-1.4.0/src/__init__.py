"""
Src package initialization.
"""
