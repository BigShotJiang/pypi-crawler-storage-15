from html_to_markdown.cli_proxy import main

__all__ = ["main"]
