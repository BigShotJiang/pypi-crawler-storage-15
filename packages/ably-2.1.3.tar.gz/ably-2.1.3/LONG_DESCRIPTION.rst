Official Ably Bindings for Python
==================================

A Python client library for Ably Realtime messaging.


Setup
-----

You can install this package by using the pip tool and installing:

    pip install ably


Using Ably for Python
---------------------

- Sign up for Ably at https://ably.com/sign-up
- Get usage examples at https://github.com/ably/ably-python
- Visit https://ably.com/docs for a complete API reference and more examples
