"""XMU Rollcall CLI Package"""

__version__ = "3.1.5"

