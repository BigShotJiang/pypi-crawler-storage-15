def main():
    print("Hello, this is a packaged Python app!")

if __name__ == "__main__":
    main()
