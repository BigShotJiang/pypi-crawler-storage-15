# MCP Git Analyzer

Git 저장소를 분석하여 코드 구조, 알고리즘 패턴, 문서를 추출하고 DB에 저장하는 MCP 서버입니다.

## Features

- **저장소 클론 및 관리**: Git URL로 저장소 클론, 브랜치 지정 가능
- **다중 언어 파싱**: Python, JavaScript, TypeScript 지원 (tree-sitter 기반)
- **코드 분석**: 함수, 클래스, import, docstring 추출
- **알고리즘 추출**: 핵심 알고리즘 자동 감지 및 복잡도 분석
- **패턴 감지**: 알고리즘 패턴 (재귀, DP, 정렬 등) 식별
- **전문 검색**: SQLite FTS5 기반 키워드 검색
- **임베딩 유사도 검색**: 의미적으로 유사한 알고리즘 찾기
- **ANN 최적화**: FAISS 기반 고속 벡터 유사도 검색 (O(log n))
- **차원 축소**: PCA를 통한 임베딩 차원 축소 및 저장 공간 절약
- **호출 그래프**: 함수 호출 관계 분석 (JSON/Mermaid)
- **보고서 생성**: 다양한 형식의 분석 보고서 (JSON/Markdown/HTML)
- **LLM 친화적**: 구조화된 JSON 응답

## Installation

### 기본 설치
```bash
uv pip install -e .
```

### ANN 최적화 기능 포함 설치
대규모 저장소 분석 시 권장:
```bash
uv pip install -e ".[ann]"
```

이 명령어는 다음 패키지를 추가로 설치합니다:
- `faiss-cpu` - 고속 벡터 유사도 검색
- `numpy` - 수치 연산
- `scikit-learn` - PCA 차원 축소

자세한 내용은 [ANN 최적화 가이드](docs/ANN_OPTIMIZATION.md)를 참조하세요.

## Configuration

환경변수로 저장 경로를 설정합니다:

| 환경변수 | 설명 | 기본값 |
|---------|------|--------|
| `GIT_ANALYZER_REPOS_PATH` | 클론된 저장소 저장 경로 | `~/.mcp-git-analyzer/repos` |
| `GIT_ANALYZER_DB_PATH` | SQLite DB 파일 경로 | `~/.mcp-git-analyzer/analysis.db` |

## Claude Desktop 설정

`claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "git-analyzer": {
      "command": "uv",
      "args": ["run", "mcp-git-analyzer"],
      "env": {
        "GIT_ANALYZER_REPOS_PATH": "C:/repos",
        "GIT_ANALYZER_DB_PATH": "C:/repos/analysis.db"
      }
    }
  }
}
```

## Available Tools

### Git 관리 (4 tools)
- `clone_repo(url, branch?)` - 저장소 클론
- `list_repos()` - 등록된 저장소 목록
- `get_repo_tree(repo_id, max_depth)` - 저장소 파일 구조
- `delete_repo(repo_id, delete_files?)` - 저장소 삭제

### 분석 (3 tools)
- `analyze_repo(repo_id, force_reanalyze?)` - 전체 저장소 분석
- `get_file_analysis(repo_id, file_path)` - 파일 상세 분석
- `get_symbol_info(symbol_name, repo_id?)` - 심볼 정보 및 패턴

### 검색 (4 tools)
- `search_symbols(query, symbol_type?, repo_id?, limit)` - 심볼 전문 검색
- `find_patterns(pattern_type, pattern_name?, repo_id?, limit)` - 패턴 검색
- `search_imports(module_name, repo_id?, limit)` - import 검색
- `list_symbols(repo_id, symbol_type?, limit)` - 심볼 목록

### 호출 그래프 (3 tools)
- `get_call_graph(repo_id, symbol_name?, format)` - 호출 그래프 생성
- `get_function_callers(repo_id, function_name)` - 함수 호출자 찾기
- `get_function_calls(repo_id, function_name)` - 함수가 호출하는 함수 찾기

### 알고리즘 분석 (10 tools)
- `extract_algorithms(repo_id, min_lines?, force_reextract?)` - 알고리즘 추출
- `get_algorithm_analysis_prompt(algorithm_id)` - LLM 분석용 프롬프트 생성
- `save_algorithm_llm_analysis(algorithm_id, analysis_json)` - LLM 분석 결과 저장
- `save_algorithm_embedding(algorithm_id, embedding)` - 임베딩 저장
- `find_similar_algorithms(algorithm_id, method, threshold?, limit?)` - 유사 알고리즘 검색
- `get_algorithm(algorithm_id)` - 알고리즘 상세 정보
- `list_algorithms(repo_id, category?, category_type?, min_complexity?, limit?)` - 알고리즘 목록
- `search_algorithms(query, repo_id?, limit?)` - 알고리즘 전문 검색
- `build_similarity_index(repo_id?, index_type)` - **NEW** ANN 인덱스 구축
- `reduce_embedding_dimensions(target_dimension, repo_id?, method)` - **NEW** 차원 축소

### 보고서 (1 tool)
- `generate_report(repo_id, report_type, format, options?)` - 분석 보고서 생성

**총 32개 도구 지원** (2개 신규 추가)

## License

MIT
