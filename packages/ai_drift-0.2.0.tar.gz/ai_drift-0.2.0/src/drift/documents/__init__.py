"""Document loading and processing for drift analysis."""

from drift.documents.loader import DocumentLoader

__all__ = ["DocumentLoader"]
