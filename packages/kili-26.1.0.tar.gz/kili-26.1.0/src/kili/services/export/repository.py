"""Gets the."""

from abc import ABC, abstractmethod
from collections.abc import Iterator
from typing import Any

from kili.adapters.http_client import HttpClient
from kili.core.helpers import get_response_json, log_raise_for_status

from .exceptions import DownloadError


class AbstractContentRepository(ABC):
    """Interface to the content repository."""

    def __init__(self, router_endpoint: str, http_client: HttpClient) -> None:
        self.router_endpoint = router_endpoint
        self.http_client = http_client
        assert router_endpoint, "The router endpoint string should not be empty"

    @abstractmethod
    def get_frames(self, content_url: str) -> list[str]:
        """Get asset content frames."""

    @abstractmethod
    def get_content_stream(self, content_url: str, block_size: int) -> Iterator[Any]:
        """Get asset content stream."""

    def get_content_frames_paths(self, asset: dict) -> list[str]:
        """Get list of links to frames from the file located at asset[jsonContent].

        Returns an empty list if `content` in the asset exists.
        """
        content_frames = []

        if not asset["content"] and asset["jsonContent"]:
            content_frames = self.get_frames(asset["jsonContent"])

        return content_frames

    def is_serving(self, url: str) -> bool:
        """Return a boolean defining if the asset is served by Kili or not."""
        return url.startswith(self.router_endpoint)


class SDKContentRepository(AbstractContentRepository):
    """Handle content fetching from the server from the SDK."""

    def get_frames(self, content_url: str) -> list[str]:
        frames: list[str] = []
        json_content_resp = self.http_client.get(content_url, timeout=30)

        log_raise_for_status(json_content_resp)
        json_response = get_response_json(json_content_resp)

        if json_content_resp.ok:
            frames = list(json_response.values())
        return frames

    def get_content_stream(self, content_url: str, block_size: int) -> Iterator[Any]:
        response = self.http_client.get(content_url, stream=True, timeout=30)
        if not response.ok:
            raise DownloadError(f"Error while downloading image {content_url}")

        return response.iter_content(block_size)
