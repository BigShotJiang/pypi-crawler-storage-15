"""Errors raised by the mutations module."""


class MutationError(Exception):
    """Errors raised when mutation fails."""
