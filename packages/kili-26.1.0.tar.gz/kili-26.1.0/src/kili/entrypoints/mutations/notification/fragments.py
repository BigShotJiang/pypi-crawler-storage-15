"""Fragments of notification mutations."""

NOTIFICATION_FRAGMENT = """
id
"""
