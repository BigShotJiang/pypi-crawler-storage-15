=======
Credits
=======

* Johan Lübcke <johan@lubcke.se>
* Anders Hovmöller <boxed@killingar.net>
* Maren Leithe
* Fredrik Westermark <fredrik.westermark@trioptima.com>
* Tore Lundqvist <tore.lundqvist@trioptima.com>
* Gabriel Lima
* Johan Hägg
* Esse Woods <esbjorn.ekberg@trioptima.com>
* Lars-Erik Hannelius <larserik.hannelius@trioptima.com>
* Stefan Chyssler <stefan.chyssler@trioptima.com>
* Simon Percivall
* Simon Lundmark Ornstein <simon.ornstein@trioptima.com>
* Erik Sjöstedt
* Daniel Vinntreus
* Ludvig Boström <ludvig.bostrom@trioptima.com>
* Andreas Rasmusson <andreas.rasmusson@trioptima.com>
* Martin Barksten <martin.barksten@trioptima.com>
* Rasmus Spiegelberg <rasmus.spiegelberg@trioptima.com>
* Benedikt Grundmann <benedikt.grundmann@gmail.com>
* flying_sausages
* Nigel Metheringham <nigel.metheringham@gmail.com>
* Maximilian Albert <https://github.com/maxalbert>
* Yury Bulka <setthemfree@privacyrequired.com>
* Mickey McClellan <77741738+MickeyM79@users.noreply.github.com>
* Oana Fatu <oana.fatu@trioptima.com>
* Viktor <dpedesigns@hotmail.com>
* Bery <info@berycz.net>
* Sytrus Ivkus <aiueclipse@mail.com>
* Braintelligence <Braintelligence@users.noreply.github.com>
* David D Wang <duendwang@users.noreply.github.com>
* MareksNo <ulmanismareks@gmail.com>
* Milton Johansson <milton.johansson@trioptima.com>
* astrocbxy <chrisbehrmann00@gmail.com>
* yanhuixie <yanhuixie@gmail.com>
* Sam Mangham <mangham@gmail.com>
