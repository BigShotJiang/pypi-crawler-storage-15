from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .context import Context


async def check_python(ctx: Context) -> None:
    pass


async def install_pyenv(ctx: Context) -> None:
    pass


async def install_python(ctx: Context) -> None:
    pass
