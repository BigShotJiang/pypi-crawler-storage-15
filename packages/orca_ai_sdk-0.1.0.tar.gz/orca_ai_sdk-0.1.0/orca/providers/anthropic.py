"""
Anthropic Provider Implementation

Full implementation of the Anthropic Claude API including:
- Messages API (streaming and non-streaming)
- Model listing
"""

from typing import Any, AsyncIterator, Iterator, Optional
import json

from ..utils.format import (
    normalize_anthropic_model,
    normalize_anthropic_response,
    normalize_anthropic_stream_chunk,
    translate_to_anthropic,
)
from ..utils.types import OrcaModel, OrcaResponse, OrcaStreamChunk
from .base import BaseProvider


class AnthropicProvider(BaseProvider):
    """Anthropic Claude API provider."""
    
    def chat(
        self,
        model: str,
        messages: list[dict[str, Any]],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        stream: bool = False,
        **kwargs: Any,
    ) -> OrcaResponse | Iterator[OrcaStreamChunk]:
        """Send a message request to Anthropic."""
        payload = translate_to_anthropic(
            messages=messages, model=model, temperature=temperature,
            max_tokens=max_tokens, stream=stream, **kwargs,
        )
        
        if stream:
            return self._stream_chat(payload, model)
        
        response = self._make_request("chat", data=payload)
        latency = response.pop("_orca_latency_ms", 0)
        return normalize_anthropic_response(response, latency)
    
    async def chat_async(
        self,
        model: str,
        messages: list[dict[str, Any]],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        stream: bool = False,
        **kwargs: Any,
    ) -> OrcaResponse | AsyncIterator[OrcaStreamChunk]:
        """Async message request."""
        payload = translate_to_anthropic(
            messages=messages, model=model, temperature=temperature,
            max_tokens=max_tokens, stream=stream, **kwargs,
        )
        
        if stream:
            return self._stream_chat_async(payload, model)
        
        response = await self._make_request_async("chat", data=payload)
        latency = response.pop("_orca_latency_ms", 0)
        return normalize_anthropic_response(response, latency)
    
    def _stream_chat(self, payload: dict, model: str) -> Iterator[OrcaStreamChunk]:
        """Handle streaming message response."""
        raw_stream = self._make_stream_request("chat", data=payload)
        accumulated = ""
        current_event = None
        
        for raw_line in raw_stream:
            line = raw_line.decode("utf-8") if isinstance(raw_line, bytes) else raw_line
            line = line.strip()
            if not line:
                continue
            if line.startswith("event: "):
                current_event = line[7:]
                continue
            if line.startswith("data: "):
                try:
                    data = json.loads(line[6:])
                except json.JSONDecodeError:
                    continue
                chunk = normalize_anthropic_stream_chunk(current_event or "", data, model)
                accumulated += chunk.delta_text
                chunk.accumulated_text = accumulated
                if chunk.delta_text or chunk.is_final:
                    yield chunk
                if chunk.is_final:
                    return
    
    async def _stream_chat_async(self, payload: dict, model: str) -> AsyncIterator[OrcaStreamChunk]:
        """Handle async streaming."""
        raw_stream = self._make_stream_request_async("chat", data=payload)
        accumulated = ""
        current_event = None
        
        async for raw_line in raw_stream:
            line = raw_line.decode("utf-8") if isinstance(raw_line, bytes) else raw_line
            line = line.strip()
            if not line:
                continue
            if line.startswith("event: "):
                current_event = line[7:]
                continue
            if line.startswith("data: "):
                try:
                    data = json.loads(line[6:])
                except json.JSONDecodeError:
                    continue
                chunk = normalize_anthropic_stream_chunk(current_event or "", data, model)
                accumulated += chunk.delta_text
                chunk.accumulated_text = accumulated
                if chunk.delta_text or chunk.is_final:
                    yield chunk
                if chunk.is_final:
                    return
    
    def list_models(self) -> list[OrcaModel]:
        """Fetch available models from Anthropic."""
        response = self._make_request("models", method="GET")
        return [normalize_anthropic_model(m) for m in response.get("data", [])]
    
    async def list_models_async(self) -> list[OrcaModel]:
        """Async fetch available models."""
        response = await self._make_request_async("models", method="GET")
        return [normalize_anthropic_model(m) for m in response.get("data", [])]
