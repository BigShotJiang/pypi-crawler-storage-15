"""
Orca Response Formatters and Argument Normalizers

Handles bidirectional translation between Orca's unified format
and each provider's native API format.
"""

from datetime import datetime
from typing import Any, Optional

from .types import (
    FinishReason,
    MessageRole,
    OrcaChoice,
    OrcaEmbedding,
    OrcaImage,
    OrcaMessage,
    OrcaModel,
    OrcaResponse,
    OrcaStreamChunk,
    TokenUsage,
)


# =============================================================================
# Response Normalizers - Convert provider responses to OrcaResponse
# =============================================================================


def normalize_openai_response(
    raw: dict[str, Any],
    latency_ms: int = 0,
) -> OrcaResponse:
    """Normalize OpenAI chat completion response."""
    choices = []
    output_text = None
    finish_reason = None
    
    for choice in raw.get("choices", []):
        message_data = choice.get("message", {})
        message = OrcaMessage(
            role=MessageRole(message_data.get("role", "assistant")),
            content=message_data.get("content"),
            tool_calls=message_data.get("tool_calls"),
        )
        
        fr = _parse_finish_reason(choice.get("finish_reason"))
        choices.append(OrcaChoice(
            index=choice.get("index", 0),
            message=message,
            finish_reason=fr,
        ))
        
        if choice.get("index", 0) == 0:
            output_text = message_data.get("content")
            finish_reason = fr
    
    usage = raw.get("usage", {})
    tokens = TokenUsage(
        prompt_tokens=usage.get("prompt_tokens", 0),
        completion_tokens=usage.get("completion_tokens", 0),
        total_tokens=usage.get("total_tokens", 0),
    )
    
    return OrcaResponse(
        provider="openai",
        model=raw.get("model", ""),
        raw=raw,
        output_text=output_text,
        tokens_used=tokens,
        latency_ms=latency_ms,
        choices=choices,
        finish_reason=finish_reason,
        request_id=raw.get("id"),
        system_fingerprint=raw.get("system_fingerprint"),
        created_at=datetime.fromtimestamp(raw["created"]) if "created" in raw else None,
    )


def normalize_anthropic_response(
    raw: dict[str, Any],
    latency_ms: int = 0,
) -> OrcaResponse:
    """Normalize Anthropic messages response."""
    content_blocks = raw.get("content", [])
    output_text = ""
    
    for block in content_blocks:
        if block.get("type") == "text":
            output_text += block.get("text", "")
    
    usage = raw.get("usage", {})
    tokens = TokenUsage(
        prompt_tokens=usage.get("input_tokens", 0),
        completion_tokens=usage.get("output_tokens", 0),
        total_tokens=usage.get("input_tokens", 0) + usage.get("output_tokens", 0),
    )
    
    finish_reason = _parse_finish_reason(raw.get("stop_reason"))
    
    message = OrcaMessage(
        role=MessageRole.ASSISTANT,
        content=output_text,
    )
    
    choices = [OrcaChoice(
        index=0,
        message=message,
        finish_reason=finish_reason,
    )]
    
    return OrcaResponse(
        provider="anthropic",
        model=raw.get("model", ""),
        raw=raw,
        output_text=output_text,
        tokens_used=tokens,
        latency_ms=latency_ms,
        choices=choices,
        finish_reason=finish_reason,
        request_id=raw.get("id"),
    )


def normalize_gemini_response(
    raw: dict[str, Any],
    model: str = "",
    latency_ms: int = 0,
) -> OrcaResponse:
    """Normalize Gemini generateContent response."""
    candidates = raw.get("candidates", [])
    output_text = None
    finish_reason = None
    choices = []
    
    for i, candidate in enumerate(candidates):
        content = candidate.get("content", {})
        parts = content.get("parts", [])
        text = ""
        for part in parts:
            if "text" in part:
                text += part["text"]
        
        fr = _parse_gemini_finish_reason(candidate.get("finishReason"))
        
        message = OrcaMessage(
            role=MessageRole.ASSISTANT,
            content=text,
        )
        
        choices.append(OrcaChoice(
            index=i,
            message=message,
            finish_reason=fr,
        ))
        
        if i == 0:
            output_text = text
            finish_reason = fr
    
    # Gemini usage metadata
    usage_meta = raw.get("usageMetadata", {})
    tokens = TokenUsage(
        prompt_tokens=usage_meta.get("promptTokenCount", 0),
        completion_tokens=usage_meta.get("candidatesTokenCount", 0),
        total_tokens=usage_meta.get("totalTokenCount", 0),
    )
    
    return OrcaResponse(
        provider="gemini",
        model=model,
        raw=raw,
        output_text=output_text,
        tokens_used=tokens,
        latency_ms=latency_ms,
        choices=choices,
        finish_reason=finish_reason,
    )


def normalize_openrouter_response(
    raw: dict[str, Any],
    latency_ms: int = 0,
) -> OrcaResponse:
    """Normalize OpenRouter response (OpenAI-compatible format)."""
    # OpenRouter uses OpenAI format, so reuse that normalizer
    response = normalize_openai_response(raw, latency_ms)
    response.provider = "openrouter"
    return response


# =============================================================================
# Streaming Chunk Normalizers
# =============================================================================


def normalize_openai_stream_chunk(
    chunk: dict[str, Any],
    model: str = "",
) -> OrcaStreamChunk:
    """Parse OpenAI streaming chunk."""
    delta = {}
    delta_text = ""
    finish_reason = None
    
    choices = chunk.get("choices", [])
    if choices:
        choice = choices[0]
        delta = choice.get("delta", {})
        delta_text = delta.get("content", "")
        if choice.get("finish_reason"):
            finish_reason = _parse_finish_reason(choice["finish_reason"])
    
    return OrcaStreamChunk(
        provider="openai",
        model=chunk.get("model", model),
        delta_text=delta_text,
        finish_reason=finish_reason,
        is_final=finish_reason is not None,
        raw=chunk,
    )


def normalize_anthropic_stream_chunk(
    event_type: str,
    data: dict[str, Any],
    model: str = "",
) -> OrcaStreamChunk:
    """Parse Anthropic streaming event."""
    delta_text = ""
    finish_reason = None
    is_final = False
    
    if event_type == "content_block_delta":
        delta = data.get("delta", {})
        if delta.get("type") == "text_delta":
            delta_text = delta.get("text", "")
    elif event_type == "message_stop":
        is_final = True
        finish_reason = FinishReason.STOP
    elif event_type == "message_delta":
        if data.get("delta", {}).get("stop_reason"):
            finish_reason = _parse_finish_reason(data["delta"]["stop_reason"])
            is_final = True
    
    return OrcaStreamChunk(
        provider="anthropic",
        model=model,
        delta_text=delta_text,
        finish_reason=finish_reason,
        is_final=is_final,
        raw=data,
    )


def normalize_gemini_stream_chunk(
    chunk: dict[str, Any],
    model: str = "",
) -> OrcaStreamChunk:
    """Parse Gemini streaming chunk."""
    delta_text = ""
    finish_reason = None
    
    candidates = chunk.get("candidates", [])
    if candidates:
        candidate = candidates[0]
        content = candidate.get("content", {})
        parts = content.get("parts", [])
        for part in parts:
            if "text" in part:
                delta_text += part["text"]
        
        if candidate.get("finishReason"):
            finish_reason = _parse_gemini_finish_reason(candidate["finishReason"])
    
    return OrcaStreamChunk(
        provider="gemini",
        model=model,
        delta_text=delta_text,
        finish_reason=finish_reason,
        is_final=finish_reason is not None,
        raw=chunk,
    )


# =============================================================================
# Argument Translators - Convert unified args to provider format
# =============================================================================


def translate_to_openai(
    messages: list[dict[str, Any]],
    model: str,
    temperature: Optional[float] = None,
    max_tokens: Optional[int] = None,
    top_p: Optional[float] = None,
    stop: Optional[list[str]] = None,
    stream: bool = False,
    **kwargs: Any,
) -> dict[str, Any]:
    """Translate unified arguments to OpenAI format."""
    payload: dict[str, Any] = {
        "model": model,
        "messages": messages,
    }
    
    if temperature is not None:
        payload["temperature"] = temperature
    if max_tokens is not None:
        payload["max_tokens"] = max_tokens
    if top_p is not None:
        payload["top_p"] = top_p
    if stop:
        payload["stop"] = stop
    if stream:
        payload["stream"] = True
    
    # Pass through any extra kwargs
    payload.update(kwargs)
    
    return payload


def translate_to_anthropic(
    messages: list[dict[str, Any]],
    model: str,
    temperature: Optional[float] = None,
    max_tokens: Optional[int] = None,
    top_p: Optional[float] = None,
    stop: Optional[list[str]] = None,
    stream: bool = False,
    **kwargs: Any,
) -> dict[str, Any]:
    """Translate unified arguments to Anthropic format."""
    # Extract system message if present
    system_content = None
    filtered_messages = []
    
    for msg in messages:
        role = msg.get("role", "")
        if role == "system":
            system_content = msg.get("content", "")
        else:
            # Map 'assistant' role correctly
            filtered_messages.append({
                "role": role,
                "content": msg.get("content", ""),
            })
    
    payload: dict[str, Any] = {
        "model": model,
        "messages": filtered_messages,
        "max_tokens": max_tokens or 4096,  # Anthropic requires max_tokens
    }
    
    if system_content:
        payload["system"] = system_content
    if temperature is not None:
        payload["temperature"] = temperature
    if top_p is not None:
        payload["top_p"] = top_p
    if stop:
        payload["stop_sequences"] = stop
    if stream:
        payload["stream"] = True
    
    # Pass through extra kwargs
    for key in ["metadata", "tools", "tool_choice"]:
        if key in kwargs:
            payload[key] = kwargs[key]
    
    return payload


def translate_to_gemini(
    messages: list[dict[str, Any]],
    model: str,
    temperature: Optional[float] = None,
    max_tokens: Optional[int] = None,
    top_p: Optional[float] = None,
    stop: Optional[list[str]] = None,
    stream: bool = False,
    **kwargs: Any,
) -> dict[str, Any]:
    """Translate unified arguments to Gemini format."""
    contents = []
    system_instruction = None
    
    for msg in messages:
        role = msg.get("role", "user")
        content = msg.get("content", "")
        
        if role == "system":
            system_instruction = content
            continue
        
        # Map roles
        gemini_role = "model" if role == "assistant" else "user"
        contents.append({
            "role": gemini_role,
            "parts": [{"text": content}],
        })
    
    payload: dict[str, Any] = {
        "contents": contents,
    }
    
    if system_instruction:
        payload["systemInstruction"] = {"parts": [{"text": system_instruction}]}
    
    # Generation config
    gen_config: dict[str, Any] = {}
    if temperature is not None:
        gen_config["temperature"] = temperature
    if max_tokens is not None:
        gen_config["maxOutputTokens"] = max_tokens
    if top_p is not None:
        gen_config["topP"] = top_p
    if stop:
        gen_config["stopSequences"] = stop
    
    if gen_config:
        payload["generationConfig"] = gen_config
    
    return payload


def translate_to_openrouter(
    messages: list[dict[str, Any]],
    model: str,
    temperature: Optional[float] = None,
    max_tokens: Optional[int] = None,
    top_p: Optional[float] = None,
    stop: Optional[list[str]] = None,
    stream: bool = False,
    **kwargs: Any,
) -> dict[str, Any]:
    """Translate unified arguments to OpenRouter format (OpenAI-compatible)."""
    # OpenRouter uses OpenAI format
    return translate_to_openai(
        messages=messages,
        model=model,
        temperature=temperature,
        max_tokens=max_tokens,
        top_p=top_p,
        stop=stop,
        stream=stream,
        **kwargs,
    )


# =============================================================================
# Model Normalizers
# =============================================================================


def normalize_openai_model(data: dict[str, Any]) -> OrcaModel:
    """Normalize OpenAI model list entry."""
    model_id = data.get("id", "")
    
    # Infer capabilities from model ID
    capabilities = ["chat"]
    if "embedding" in model_id:
        capabilities = ["embeddings"]
    elif "dall-e" in model_id or "image" in model_id:
        capabilities = ["images"]
    elif "whisper" in model_id:
        capabilities = ["audio"]
    elif "tts" in model_id:
        capabilities = ["speech"]
    
    return OrcaModel(
        id=model_id,
        provider="openai",
        name=model_id,
        owned_by=data.get("owned_by"),
        created=datetime.fromtimestamp(data["created"]) if "created" in data else None,
        capabilities=capabilities,
        metadata=data,
    )


def normalize_anthropic_model(data: dict[str, Any]) -> OrcaModel:
    """Normalize Anthropic model list entry."""
    return OrcaModel(
        id=data.get("id", ""),
        provider="anthropic",
        name=data.get("display_name", data.get("id", "")),
        created=datetime.fromisoformat(data["created_at"].replace("Z", "+00:00")) if "created_at" in data else None,
        capabilities=["chat"],
        metadata=data,
    )


def normalize_gemini_model(data: dict[str, Any]) -> OrcaModel:
    """Normalize Gemini model list entry."""
    name = data.get("name", "")
    # Gemini returns "models/gemini-pro", we want just "gemini-pro"
    model_id = name.replace("models/", "") if name.startswith("models/") else name
    
    capabilities = []
    supported = data.get("supportedGenerationMethods", [])
    if "generateContent" in supported:
        capabilities.append("chat")
    if "embedContent" in supported:
        capabilities.append("embeddings")
    
    return OrcaModel(
        id=model_id,
        provider="gemini",
        name=data.get("displayName", model_id),
        context_length=data.get("inputTokenLimit"),
        capabilities=capabilities,
        metadata=data,
    )


def normalize_openrouter_model(data: dict[str, Any]) -> OrcaModel:
    """Normalize OpenRouter model list entry."""
    model_id = data.get("id", "")
    
    return OrcaModel(
        id=model_id,
        provider="openrouter",
        name=data.get("name", model_id),
        context_length=data.get("context_length"),
        capabilities=["chat"],
        pricing={
            "prompt": data.get("pricing", {}).get("prompt", 0),
            "completion": data.get("pricing", {}).get("completion", 0),
        },
        metadata=data,
    )


# =============================================================================
# Embedding Normalizers
# =============================================================================


def normalize_openai_embedding(
    raw: dict[str, Any],
    model: str = "",
    latency_ms: int = 0,
) -> OrcaEmbedding:
    """Normalize OpenAI embeddings response."""
    embeddings = [item["embedding"] for item in raw.get("data", [])]
    usage = raw.get("usage", {})
    
    return OrcaEmbedding(
        provider="openai",
        model=raw.get("model", model),
        embeddings=embeddings,
        tokens_used=TokenUsage(
            prompt_tokens=usage.get("prompt_tokens", 0),
            total_tokens=usage.get("total_tokens", 0),
        ),
        latency_ms=latency_ms,
        raw=raw,
    )


def normalize_gemini_embedding(
    raw: dict[str, Any],
    model: str = "",
    latency_ms: int = 0,
) -> OrcaEmbedding:
    """Normalize Gemini embeddings response."""
    embedding = raw.get("embedding", {}).get("values", [])
    
    return OrcaEmbedding(
        provider="gemini",
        model=model,
        embeddings=[embedding] if embedding else [],
        latency_ms=latency_ms,
        raw=raw,
    )


# =============================================================================
# Image Normalizers
# =============================================================================


def normalize_openai_image(
    raw: dict[str, Any],
    model: str = "",
    latency_ms: int = 0,
) -> OrcaImage:
    """Normalize OpenAI image generation response."""
    images = raw.get("data", [])
    
    return OrcaImage(
        provider="openai",
        model=model,
        images=images,
        latency_ms=latency_ms,
        raw=raw,
    )


# =============================================================================
# Helper Functions
# =============================================================================


def _parse_finish_reason(reason: Optional[str]) -> FinishReason:
    """Parse finish reason string to enum."""
    if not reason:
        return FinishReason.UNKNOWN
    
    reason_map = {
        "stop": FinishReason.STOP,
        "end_turn": FinishReason.STOP,
        "length": FinishReason.LENGTH,
        "max_tokens": FinishReason.LENGTH,
        "tool_calls": FinishReason.TOOL_CALLS,
        "tool_use": FinishReason.TOOL_CALLS,
        "content_filter": FinishReason.CONTENT_FILTER,
    }
    
    return reason_map.get(reason.lower(), FinishReason.UNKNOWN)


def _parse_gemini_finish_reason(reason: Optional[str]) -> FinishReason:
    """Parse Gemini-specific finish reason."""
    if not reason:
        return FinishReason.UNKNOWN
    
    reason_map = {
        "STOP": FinishReason.STOP,
        "MAX_TOKENS": FinishReason.LENGTH,
        "SAFETY": FinishReason.CONTENT_FILTER,
        "RECITATION": FinishReason.CONTENT_FILTER,
    }
    
    return reason_map.get(reason, FinishReason.UNKNOWN)
