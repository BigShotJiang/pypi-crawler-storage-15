"""
Orca Type Definitions

Unified response types and data models for normalized provider responses.
Uses Pydantic for validation and serialization.
"""

from datetime import datetime
from enum import Enum
from typing import Any, Iterator, Optional, Union

from pydantic import BaseModel, Field


class MessageRole(str, Enum):
    """Standard message roles across providers."""
    
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"
    TOOL = "tool"
    FUNCTION = "function"  # Legacy, maps to tool


class OrcaMessage(BaseModel):
    """
    Unified message format for chat interfaces.
    
    Attributes:
        role: Message role (system, user, assistant, tool)
        content: Message text content
        name: Optional name for function/tool messages
        tool_calls: Optional list of tool calls from assistant
        tool_call_id: ID of the tool call this message responds to
    """
    
    role: MessageRole
    content: Optional[str] = None
    name: Optional[str] = None
    tool_calls: Optional[list[dict[str, Any]]] = None
    tool_call_id: Optional[str] = None
    
    def to_openai(self) -> dict[str, Any]:
        """Convert to OpenAI message format."""
        msg: dict[str, Any] = {"role": self.role.value}
        if self.content is not None:
            msg["content"] = self.content
        if self.name:
            msg["name"] = self.name
        if self.tool_calls:
            msg["tool_calls"] = self.tool_calls
        if self.tool_call_id:
            msg["tool_call_id"] = self.tool_call_id
        return msg
    
    def to_anthropic(self) -> dict[str, Any]:
        """Convert to Anthropic message format."""
        # Anthropic doesn't include system in messages array
        if self.role == MessageRole.SYSTEM:
            return {}
        return {
            "role": self.role.value,
            "content": self.content or "",
        }
    
    def to_gemini(self) -> dict[str, Any]:
        """Convert to Gemini message format."""
        role_map = {
            MessageRole.USER: "user",
            MessageRole.ASSISTANT: "model",
            MessageRole.SYSTEM: "user",  # Gemini uses system instruction separately
        }
        return {
            "role": role_map.get(self.role, "user"),
            "parts": [{"text": self.content or ""}],
        }


class TokenUsage(BaseModel):
    """Token usage information from API response."""
    
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    
    # Provider-specific fields
    cached_tokens: Optional[int] = None
    reasoning_tokens: Optional[int] = None


class FinishReason(str, Enum):
    """Reasons for response completion."""
    
    STOP = "stop"
    LENGTH = "length"
    TOOL_CALLS = "tool_calls"
    CONTENT_FILTER = "content_filter"
    ERROR = "error"
    UNKNOWN = "unknown"


class OrcaChoice(BaseModel):
    """A single choice/candidate from the response."""
    
    index: int = 0
    message: Optional[OrcaMessage] = None
    finish_reason: FinishReason = FinishReason.UNKNOWN
    
    # For streaming
    delta: Optional[dict[str, Any]] = None


class OrcaResponse(BaseModel):
    """
    Unified response object for all Orca API calls.
    
    Attributes:
        provider: Source provider name
        model: Model identifier used
        raw: Original raw response from provider
        output_text: Extracted text content (convenience accessor)
        tokens_used: Token usage breakdown
        latency_ms: Request latency in milliseconds
        choices: List of response choices/candidates
        created_at: Response timestamp
        request_id: Provider-assigned request ID
    """
    
    provider: str
    model: str
    raw: dict[str, Any] = Field(default_factory=dict)
    output_text: Optional[str] = None
    tokens_used: Optional[TokenUsage] = None
    latency_ms: int = 0
    choices: list[OrcaChoice] = Field(default_factory=list)
    created_at: Optional[datetime] = None
    request_id: Optional[str] = None
    
    # Additional metadata
    finish_reason: Optional[FinishReason] = None
    system_fingerprint: Optional[str] = None
    
    @property
    def text(self) -> str:
        """Shortcut to get the first response text."""
        return self.output_text or ""
    
    @property
    def usage(self) -> dict[str, int]:
        """Get token usage as dictionary."""
        if self.tokens_used:
            return {
                "prompt": self.tokens_used.prompt_tokens,
                "completion": self.tokens_used.completion_tokens,
                "total": self.tokens_used.total_tokens,
            }
        return {}
    
    def __str__(self) -> str:
        return self.output_text or ""
    
    def __repr__(self) -> str:
        return (
            f"OrcaResponse(provider='{self.provider}', model='{self.model}', "
            f"tokens={self.tokens_used.total_tokens if self.tokens_used else 0}, "
            f"latency={self.latency_ms}ms)"
        )


class OrcaStreamChunk(BaseModel):
    """
    A single chunk from a streaming response.
    
    Attributes:
        provider: Source provider
        model: Model identifier
        delta_text: New text content in this chunk
        finish_reason: Set when stream completes
        is_final: Whether this is the last chunk
        raw: Original chunk data
    """
    
    provider: str
    model: str
    delta_text: str = ""
    finish_reason: Optional[FinishReason] = None
    is_final: bool = False
    raw: dict[str, Any] = Field(default_factory=dict)
    
    # Accumulated state
    accumulated_text: str = ""
    
    def __str__(self) -> str:
        return self.delta_text


class OrcaModel(BaseModel):
    """
    Model information from provider registry.
    
    Attributes:
        id: Model identifier (e.g., "gpt-4", "claude-3-opus")
        provider: Provider that hosts this model
        name: Display name
        created: Model creation timestamp
        owned_by: Model owner/organization
        context_length: Maximum context window
        capabilities: Supported capabilities (chat, embeddings, images)
        pricing: Pricing information if available
    """
    
    id: str
    provider: str
    name: Optional[str] = None
    created: Optional[datetime] = None
    owned_by: Optional[str] = None
    context_length: Optional[int] = None
    capabilities: list[str] = Field(default_factory=list)
    pricing: Optional[dict[str, float]] = None
    
    # Raw provider metadata
    metadata: dict[str, Any] = Field(default_factory=dict)
    
    def supports(self, capability: str) -> bool:
        """Check if model supports a capability."""
        return capability.lower() in [c.lower() for c in self.capabilities]
    
    def __repr__(self) -> str:
        return f"OrcaModel(id='{self.id}', provider='{self.provider}')"


class OrcaEmbedding(BaseModel):
    """Embedding response for text embedding requests."""
    
    provider: str
    model: str
    embeddings: list[list[float]]
    tokens_used: Optional[TokenUsage] = None
    latency_ms: int = 0
    raw: dict[str, Any] = Field(default_factory=dict)
    
    @property
    def vector(self) -> list[float]:
        """Get the first embedding vector."""
        return self.embeddings[0] if self.embeddings else []
    
    @property
    def dimensions(self) -> int:
        """Get embedding dimensionality."""
        return len(self.vector)


class OrcaImage(BaseModel):
    """Image generation response."""
    
    provider: str
    model: str
    images: list[dict[str, Any]]  # Contains url or b64_json
    latency_ms: int = 0
    raw: dict[str, Any] = Field(default_factory=dict)
    
    @property
    def urls(self) -> list[str]:
        """Get list of image URLs."""
        return [img.get("url", "") for img in self.images if "url" in img]
    
    @property
    def first_url(self) -> Optional[str]:
        """Get first image URL."""
        urls = self.urls
        return urls[0] if urls else None


# Type aliases for convenience
Messages = list[Union[OrcaMessage, dict[str, Any]]]
StreamIterator = Iterator[OrcaStreamChunk]
