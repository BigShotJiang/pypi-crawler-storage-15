from pycarmat.GUI.epsilon.gui_optim import main

if __name__ == "__main__":
    main()