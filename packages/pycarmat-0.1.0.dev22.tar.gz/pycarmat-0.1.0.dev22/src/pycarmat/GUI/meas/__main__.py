from pycarmat.GUI.meas.gui_meas import main

if __name__ == "__main__":
    main()