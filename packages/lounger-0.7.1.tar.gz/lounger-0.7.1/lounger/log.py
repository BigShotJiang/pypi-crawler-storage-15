"""
this is pytest_req log
"""
from pytest_req.log import log as req_log
from pytest_req.log import log_cfg as req_log_cfg

log = req_log
log_cfg = req_log_cfg
