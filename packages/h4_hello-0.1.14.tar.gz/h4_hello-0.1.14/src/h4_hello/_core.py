def hello() -> str:
    return "Hello!"


def goodbye() -> str:
    return "Goodbye!"
