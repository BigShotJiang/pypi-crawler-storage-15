"""Tests for Linear adapter modules."""
