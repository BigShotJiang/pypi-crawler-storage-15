"""RF3 - RosettaFold3 model implementation."""

__version__ = "0.1.0"
