# Nova Research Agent: MCP Client

Click [here](..) for more details on how to use the Nova Research Agent MCP Client.
