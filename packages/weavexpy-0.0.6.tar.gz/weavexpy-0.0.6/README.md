# WeavexPy - 0.0.6 - beta

**0.0.1** -> **0.0.3** = not available

---
**0.0.4** = test launch

---
**0.0.5** = official beta version

---
**0.0.6** = In this version, we added a function that displays all the application console data (logs, errors, etc.) in the Python console, for example:

Web console:

Hello World

Python console:

DD/MM/YYYY HH:MM:SS - [console:log] - Hello World

---