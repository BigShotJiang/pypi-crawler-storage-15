#!/usr/bin/env python3
# This software is distributed under the terms of the MIT License.
# Copyright (c) 2025 Dmitry Ponomarev.
# Author: Dmitry Ponomarev <ponomarevda96@gmail.com>

import pytest
from tsugite.utils import ValueTransformer


def test_no_transform_on_non_numeric():
    t = ValueTransformer({})
    assert t.transform("abc") == "abc"
    assert t.transform([1, 2, 3]) == [1, 2, 3]
    assert t.transform(None) is None


def test_multiplier_and_offset():
    t = ValueTransformer({"multiplier": 2.0, "offset": 3.0})
    assert t.transform(5) == 13  # auto → int
    assert t.transform(2.5) == pytest.approx(8.0)


def test_auto_preserves_int():
    t = ValueTransformer({"multiplier": 2.0})
    assert isinstance(t.transform(10), int)
    assert t.transform(10) == 20


def test_auto_preserves_float():
    t = ValueTransformer({"offset": 0.5})
    out = t.transform(1.0)
    assert isinstance(out, float)
    assert out == pytest.approx(1.5)


def test_auto_preserves_bool():
    t = ValueTransformer({"multiplier": 10})
    assert t.transform(True) is True    # 10 != 0
    assert t.transform(False) is False  # 0 != 0 → False


def test_field_type_int():
    t = ValueTransformer({"field_type": "int"})
    assert t.transform(3.7) == 3


def test_field_type_float():
    t = ValueTransformer({"field_type": "float"})
    assert t.transform(3) == 3.0


def test_field_type_bool():
    t = ValueTransformer({"field_type": "bool"})
    assert t.transform(0.0) is False
    assert t.transform(0.1) is True
    assert t.transform(-5) is True

def test_combined_transform_and_type():
    t = ValueTransformer({"multiplier": 0.5, "offset": 1.0, "field_type": "float"})
    assert t.transform(10) == pytest.approx(6.0)

if __name__ == "__main__":
    pytest.main([__file__])
