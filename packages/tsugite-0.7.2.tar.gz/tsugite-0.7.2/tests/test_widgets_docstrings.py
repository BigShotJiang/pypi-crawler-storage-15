#!/usr/bin/env python3
# This software is distributed under the terms of the MIT License.
# Copyright (c) 2025 Dmitry Ponomarev.
# Author: Dmitry Ponomarev <ponomarevda96@gmail.com>

import os
import yaml
import pytest
import inspect
import textwrap

# Run Qt in headless mode
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from tsugite.ui.desktop.widgets import (
    WidgetFactory,
    ConstLabelWidget,
    BoundLabelWidget,
    InfoLabelWidget,
    VersionButtonWidget,
)
from tsugite.backend.dummy_backend import DummyBackend


def yaml_from_widget_class(cls) -> str:
    def yaml_from_docstring(cls) -> str:
        """Return the YAML example block from a widget docstring."""
        doc = inspect.getdoc(cls) or ""
        lines = doc.splitlines()

        start = None
        for i, line in enumerate(lines):
            if line.strip().startswith("YAML example:"):
                start = i + 1
                break

        if start is None:
            return None

        block = "\n".join(lines[start:])
        return textwrap.dedent(block)

    yaml_text = yaml_from_docstring(cls)
    return yaml.safe_load(yaml_text) if yaml_text is not None else None

WIDGET_CLASSES_WITH_EXAMPLES = [
    ConstLabelWidget,
    BoundLabelWidget,
    InfoLabelWidget,
    # EnumLabelWidget,
    # HealthLabelWidget,
    # ButtonWidget,
    # LatchingButtonWidget,
    # ThreeStateButtonWidget,
    VersionButtonWidget,
    # ParamEditorWidget,
    # HorizontalSliderWidget,
    # DialWidget,
    # PublisherWidget,
    # BoundImageWidget,
    # PlotWidget,
    # GpsMapWidget,
    # CanGraphWidget,
    # TableWidget,
    # TemplateTableWidget,
]

@pytest.mark.parametrize("WidgetClass", WIDGET_CLASSES_WITH_EXAMPLES)
def test_docstring_example(qtbot, WidgetClass):
    cfg = yaml_from_widget_class(WidgetClass)
    assert cfg is not None, f"{WidgetClass} has no 'YAML example:' in docstring"
    cfg["communicator"] = DummyBackend()

    widget = WidgetFactory.create(cfg)
    qtbot.addWidget(widget)

    # Smoke-test: widget instantiates without errors
    assert widget is not None

