#!/usr/bin/env python3
# This software is distributed under the terms of the MIT License.
# Copyright (c) 2025 Dmitry Ponomarev.
# Author: Dmitry Ponomarev <ponomarevda96@gmail.com>
"""
Tsugite - A system-oriented dashboard for Cyphal (CAN + UDP) & DroneCAN (from YAML)
that renders live panels from a YAML manifest—so you watch the system, not just the bus.
"""

import os
import sys
import shutil
from pathlib import Path
import argparse
from importlib import resources

from tsugite.ui.desktop import pyside_window


def install_desktop_entry() -> None:
    """Install tsugite.desktop in the user's applications dir (Linux only)."""
    if not sys.platform.startswith("linux"):
        print("Desktop entry installation is supported only on Linux.", file=sys.stderr)
        return

    # XDG_DATA_HOME is a magic env var that tells apps where to store user-specific data files
    # If it’s not set (most common), the default is ~/.local/share
    xdg_data_home = os.environ.get("XDG_DATA_HOME")
    data_home = Path(xdg_data_home) if xdg_data_home else Path.home() / ".local" / "share"

    applications_dir = data_home / "applications"
    applications_dir.mkdir(parents=True, exist_ok=True)

    desktop_path = applications_dir / "tsugite.desktop"

    # Resolve the executable path: prefer the 'tsugite' console script
    exe = shutil.which("tsugite") or os.path.abspath(sys.argv[0])

    # Resolve icon from package data
    try:
        icon_resource = resources.files("tsugite") / "assets" / "icon.png"
        icon_path = str(icon_resource)
    except Exception:
        icon_path = ""

    desktop_contents = f"""[Desktop Entry]
Type=Application
Name=Tsugite
Comment=System-oriented dashboards for DroneCAN & Cyphal
Exec={exe} --backend dummy
Icon={icon_path}
Terminal=false
Categories=Development;Utility;
"""

    desktop_path.write_text(desktop_contents, encoding="utf-8")
    desktop_path.chmod(0o755)

    print(f"Installed desktop entry to: {desktop_path}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)

    default_config = Path("configs/examples/example.yaml")
    parser.add_argument(
        "--config",
        type=Path,
        default=Path(default_config),
        help=f"Path to YAML configuration file (default: {default_config})",
    )

    parser.add_argument(
        "--backend",
        type=str,
        default="dronecan",
        help="Communicator backend to use: dronecan|cyphal|dummy (default: dronecan)",
    )

    default_iface = "slcan:COM3@1000000" if os.name == "nt" else "slcan:/dev/ttyACM0"
    parser.add_argument(
        "--iface",
        type=str,
        default=default_iface,
        help=f"(default: {default_iface})",
    )

    parser.add_argument(
        "--node-id",
        type=int,
        default=100,
        help="(default: 100)",
    )

    parser.add_argument(
        "-v", "--verbose", action="store_true", help="Enable verbose logging"
    )

    parser.add_argument(
        "--install-desktop",
        action="store_true",
        help="Install a tsugite.desktop launcher (Linux only) and exit",
    )

    args = parser.parse_args()

    if args.install_desktop:
        install_desktop_entry()
        return

    pyside_window.main(args)

if __name__ == "__main__":
    main()
