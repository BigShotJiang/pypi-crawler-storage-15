#!/usr/bin/env python3
# This software is distributed under the terms of the MIT License.
# Copyright (c) 2025 Dmitry Ponomarev.
# Author: Dmitry Ponomarev <ponomarevda96@gmail.com>

import logging
import os
import webbrowser
from pathlib import Path

from PySide6.QtWidgets import (
    QWidget,
    QLabel,
    QVBoxLayout,
    QHBoxLayout,
    QPushButton,
    QFrame,
    QLineEdit,
    QFileDialog,
    QComboBox,
    QSpinBox,
    QGridLayout,
    QSizePolicy,
)
from PySide6.QtCore import Qt

logger = logging.getLogger(__name__)


class WelcomePanel(QWidget):
    """Welcome/info panel displayed on app startup."""

    def __init__(
        self,
        config,
        communicator,
        reload_callback=None,
        reconnect_callback=None,
        connect_callback=None,
        initial_config_path=None,
    ):
        super().__init__()
        self.config = config or {}
        self.communicator = communicator
        self.reload_callback = reload_callback
        self.reconnect_callback = reconnect_callback
        self.connect_callback = connect_callback

        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignTop)
        layout.setSpacing(10)
        layout.setContentsMargins(20, 20, 20, 20)

        # ------------------------------------------------------------------
        # 1. ABOUT
        # ------------------------------------------------------------------
        about_title = QLabel("ABOUT")
        about_title.setStyleSheet("font-weight: bold;")
        layout.addWidget(about_title)

        about_frame = QFrame()
        about_frame.setFrameShape(QFrame.StyledPanel)
        about_layout = QVBoxLayout(about_frame)
        about_layout.setContentsMargins(8, 6, 8, 6)

        about_label = QLabel(
            "Tsugite – a system-oriented dashboard for Cyphal (CAN + UDP) & DroneCAN."
            "<br>"
            "Panels are rendered from a YAML manifest, so you watch the "
            "system, not just the bus."
        )
        about_label.setWordWrap(True)
        about_layout.addWidget(about_label)

        layout.addWidget(about_frame)

        # ------------------------------------------------------------------
        # 2. APPLICATION SETUP
        # ------------------------------------------------------------------
        connection_title = QLabel("APPLICATION SETUP")
        connection_title.setStyleSheet("font-weight: bold;")
        layout.addWidget(connection_title)

        setup_frame = QFrame()
        setup_frame.setFrameShape(QFrame.StyledPanel)
        setup_layout = QVBoxLayout(setup_frame)
        setup_layout.setContentsMargins(8, 8, 8, 8)
        setup_layout.setSpacing(6)

        grid = QGridLayout()
        grid.setHorizontalSpacing(8)
        grid.setVerticalSpacing(4)
        grid.setColumnStretch(1, 1)

        # -- Protocol backend row
        backend_label = QLabel("Protocol backend:")
        self.backend_combo = QComboBox()
        self.backend_combo.addItems(["dronecan", "cyphal", "dummy"])
        self.backend_combo.setToolTip(
            "Choose protocol stack: Cyphal, DroneCAN or Dummy."
        )

        backend_name = getattr(self.communicator, "backend_name", "Unknown")
        current_backend = (backend_name or "").strip()
        idx = self.backend_combo.findText(current_backend, Qt.MatchFixedString)
        if idx >= 0:
            self.backend_combo.setCurrentIndex(idx)
        elif current_backend and current_backend not in ["Unknown", "-"]:
            self.backend_combo.addItem(current_backend)
            self.backend_combo.setCurrentText(current_backend)

        grid.addWidget(backend_label, 0, 0)
        grid.addWidget(self.backend_combo, 0, 1)

        # -- Transport interface row (editable combo)
        iface_label = QLabel("Transport interface:")
        iface = getattr(self.communicator, "iface", "-")

        self.iface_combo = QComboBox()
        self.iface_combo.setEditable(True)
        self.iface_combo.setToolTip(
            "Serial port or SocketCAN interface (slcan, canX, vcanX)."
        )

        initial_iface = iface if iface and iface != "-" else ""
        if initial_iface:
            self.iface_combo.addItem(initial_iface)
            self.iface_combo.setCurrentText(initial_iface)

        grid.addWidget(iface_label, 1, 0)
        grid.addWidget(self.iface_combo, 1, 1)

        # -- Config file row
        config_label = QLabel("Config file:")
        self.config_path_edit = QLineEdit()
        self.config_path_edit.setPlaceholderText("Path to YAML config...")
        self.config_path_edit.setToolTip(
            "Path to Tsugite YAML config manifest."
        )

        if initial_config_path:
            try:
                self.config_path_edit.setText(str(initial_config_path))
            except Exception:
                logger.warning(
                    "Failed to set initial_config_path %r", initial_config_path
                )

        browse_btn = QPushButton("Browse…")
        browse_btn.clicked.connect(self._browse_config)

        config_field_layout = QHBoxLayout()
        config_field_layout.setContentsMargins(0, 0, 0, 0)
        config_field_layout.setSpacing(4)
        config_field_layout.addWidget(self.config_path_edit)
        config_field_layout.addWidget(browse_btn)

        config_field_widget = QWidget()
        config_field_widget.setLayout(config_field_layout)

        grid.addWidget(config_label, 2, 0)
        grid.addWidget(config_field_widget, 2, 1)

        # -- Node ID row
        node_id_label = QLabel("Node ID:")
        self.node_id_spin = QSpinBox()
        self.node_id_spin.setRange(0, 127)
        node_id = getattr(self.communicator, "node_id", 100)
        try:
            self.node_id_spin.setValue(int(node_id))
        except Exception:
            self.node_id_spin.setValue(100)
        self.node_id_spin.setToolTip("Local node-ID used by Tsugite.")

        node_field_layout = QHBoxLayout()
        node_field_layout.setContentsMargins(0, 0, 0, 0)
        node_field_layout.setSpacing(4)
        node_field_layout.addWidget(self.node_id_spin)
        node_field_layout.addStretch(1)

        node_field_widget = QWidget()
        node_field_widget.setLayout(node_field_layout)

        grid.addWidget(node_id_label, 3, 0)
        grid.addWidget(node_field_widget, 3, 1)

        setup_layout.addLayout(grid)

        # -- Apply button (full width inside setup frame)
        apply_btn = QPushButton("Apply new settings")
        apply_btn.setDefault(True)
        apply_btn.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        apply_btn.clicked.connect(self._on_connect_clicked)
        setup_layout.addWidget(apply_btn)

        layout.addWidget(setup_frame)

        # ------------------------------------------------------------------
        # 3. TIP AT THE BOTTOM
        # ------------------------------------------------------------------
        layout.addStretch()
        layout.addWidget(self._divider())

        hint = QLabel("💡 Tip: Use <b>ALT + N</b> to switch between panels.")
        hint.setStyleSheet("color: #666; font-size: 12px; margin-top: 8px;")
        hint.setAlignment(Qt.AlignRight)
        layout.addWidget(hint)

        self.setLayout(layout)

    # ------------------------------------------------------------------ #
    # Helpers & event handlers
    # ------------------------------------------------------------------ #

    def _divider(self) -> QFrame:
        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setFrameShadow(QFrame.Sunken)
        line.setStyleSheet("color: #444;")
        return line

    def _browse_config(self):
        """Open a file dialog to choose a YAML config."""
        start_dir = str(Path.home())
        filename, _ = QFileDialog.getOpenFileName(
            self,
            "Select YAML config",
            start_dir,
            "YAML files (*.yaml *.yml);;All files (*)",
        )
        if filename:
            self.config_path_edit.setText(filename)

    def _on_connect_clicked(self):
        """Collect values from the settings widgets and forward them."""
        settings = {
            "config_path": self.config_path_edit.text().strip(),
            "backend": self.backend_combo.currentText().strip(),
            "iface": self.iface_combo.currentText().strip(),
            "node_id": self.node_id_spin.value(),
        }
        logger.info("Apply new settings clicked with settings: %s", settings)

        if self.connect_callback:
            self.connect_callback(settings)

    # The reload/reconnect/log helpers are kept in case you reintroduce controls later.

    def _reload_config(self):
        if self.reload_callback:
            self.reload_callback()

    def _reconnect(self):
        if self.reconnect_callback:
            self.reconnect_callback()
        elif hasattr(self.communicator, "reconnect"):
            try:
                self.communicator.reconnect()
            except Exception as e:
                logger.error("Reconnect failed: %s", e)

    def _open_logs(self):
        """
        Open log directory in file browser.

        Convention:
        - Linux/macOS: ~/.tsugite/Logs
        - Windows: %APPDATA%/tsugite/Logs
        """
        if os.name == "nt":
            base = Path(os.getenv("APPDATA", Path.home() / "AppData" / "Roaming"))
            logs_dir = base / "tsugite" / "Logs"
        else:
            base = Path.home()
            logs_dir = base / ".tsugite" / "Logs"

        logs_dir.mkdir(parents=True, exist_ok=True)
        webbrowser.open(str(logs_dir))
