#!/usr/bin/env python3
# This software is distributed under the terms of the MIT License.
# Copyright (c) 2025 Dmitry Ponomarev.
# Author: Dmitry Ponomarev <ponomarevda96@gmail.com>

import sys
import logging
import importlib
from enum import Enum, auto
from collections import deque
from abc import abstractmethod
from typing import Optional, Tuple, List
from PySide6.QtCore import Qt, QUrl, QTimer, QThread, QSize, QMetaObject, Q_ARG, Slot, QEvent
from PySide6.QtGui import QFontMetrics, QPixmap, QColor, QPalette
from PySide6.QtWebEngineCore import QWebEnginePage
from PySide6.QtWidgets import (
    QLabel,
    QMessageBox,
    QCheckBox,
    QPushButton,
    QButtonGroup,
    QVBoxLayout,
    QHBoxLayout,
    QWidget,
    QSizePolicy,
    QSlider,
)

from tsugite.utils import resolve_field_path, ValueTransformer, load_firmware_index
from tsugite.firmware_manager import FirmwareManager
from tsugite.i18n import tr as _tr
from tsugite.backend.backend import BaseBackend

logger = logging.getLogger(__name__)

def get_optional_int(cfg: dict, key: str) -> Optional[int]:
    val = cfg.get(key)
    return None if val is None else int(val)

def lazy_import_module(widget_name, module_name):
    """ Lazy imports: only load these when widget is created """
    try:
        return importlib.import_module(module_name)
    except ModuleNotFoundError:
        logger.critical(f"{widget_name} required {module_name}. You can install it: pip install {module_name}")
        sys.exit(1)

class BaseWidget(QWidget):
    """Abstract base class for all widgets."""

    def __init__(self, cfg: dict):
        super().__init__()
        self.cfg = cfg
        self.communicator: BaseBackend = cfg.get("communicator")

        self.layout = QVBoxLayout()
        self.layout.setContentsMargins(0, 0, 0, 0)
        self.layout.setSpacing(0)
        self.setLayout(self.layout)
        self.init_ui()

    @abstractmethod
    def init_ui(self):
        """Initialize widget UI."""
        raise NotImplementedError

    def require_communicator(self):
        if self.communicator is None:
            raise ValueError(
                f"{self.__class__.__name__} requires 'communicator' in the widget config."
            )

    def require_node_id(self):
        if self.node_id is None:
            raise ValueError(
                f"{self.__class__.__name__} requires 'node_id'."
            )

    def tr(self, key: str, **kwargs) -> str:
        return _tr(key, **kwargs)

    @staticmethod
    def parse_topic_field(topic_str: str) -> Tuple[str, str]:
        assert isinstance(topic_str, str), "Internal error: topic_str must be str"
        if "::" not in topic_str:
            raise ValueError(
                f"Invalid topic format '{topic_str}'. Expected 'topic::field'"
            )
        return topic_str.split("::", 1)

    def parse_topic_field_pairs(self, topics: list) -> List[Tuple[str, str]]:
        assert isinstance(topics, list), "Internal error: topic must be list"
        topic_field_pairs = []
        for t in topics:
            if not t:
                continue
            try:
                dtype, field = self.parse_topic_field(t)
            except ValueError as err:
                logger.error(f"{self.__class__.__name__}: {err}")
                continue
            topic_field_pairs.append((dtype, field))
        return topic_field_pairs

    def parse_topic_config(self, cfg: dict) -> List[Tuple[str, str]]:
        assert isinstance(cfg, dict), "Internal error: cfg must be dict"
        topics = cfg.get("topics")
        if not topics or not isinstance(topics, list):
            error_text = f"{self.__class__.__name__}: 'topics' array is required."
            logger.error(error_text)
            raise ValueError(error_text)

        topic_field_pairs = self.parse_topic_field_pairs(topics)

        if not topic_field_pairs:
            error_text = f"{self.__class__.__name__}: No valid topic::field entries."
            logger.error(error_text)
            raise ValueError(error_text)

        return topic_field_pairs

    def subscribe(self, cfg: dict, backend: BaseBackend, cb):
        assert isinstance(cfg, dict), "Internal error: cfg must be dict"
        assert isinstance(backend, BaseBackend), "Internal error: backend must be BaseBackend"
        topic_field_pairs = self.parse_topic_config(cfg)
        for dtype, field in topic_field_pairs:
            backend.subscribe(
                dtype=dtype,
                cb=lambda t, msg, f=field: cb(msg, f),
                node_id=get_optional_int(cfg, "node_id"),
            )
        return topic_field_pairs

    def register_periodic_publisher(self, cfg: dict, backend: BaseBackend):
        assert isinstance(cfg, dict), "Internal error: cfg must be dict"
        assert isinstance(backend, BaseBackend), "Internal error: backend must be BaseBackend"
        topic_field_pairs = self.parse_topic_config(cfg)
        frequency = float(cfg.get("frequency", 1.0))
        for dtype, field in topic_field_pairs:
            try:
                backend.advertise(dtype, field, frequency)
            except Exception as err:
                text = (f"{self.__class__.__name__}: "
                        f"register_periodic_publisher failed for {dtype}::{field}: {err}")
                logger.critical(text)
        return topic_field_pairs

    def update_publisher_value(self, topic_field_pairs: list, backend: BaseBackend, value):
        """This function doesn't publish the value, but only changes the value"""
        assert isinstance(topic_field_pairs, list), "Internal error: topic_field_pairs must be list"
        assert isinstance(backend, BaseBackend), "Internal error: backend must be BaseBackend"
        for dtype, field in topic_field_pairs:
            try:
                backend.set_publisher_field(dtype=dtype, field=field, value=value)
            except Exception as err:
                text = f"{self.__class__.__name__}: update_publisher_value failed for {dtype}::{field}: {err}"
                logger.error(text)

class WidgetFactory:
    """Factory for creating widgets from YAML definitions."""

    registry = {
        # Labels
        "const_label":              lambda cfg: ConstLabelWidget(cfg),
        "bound_label":              lambda cfg: BoundLabelWidget(cfg),
        "info_label":               lambda cfg: InfoLabelWidget(cfg),
        "enum_label":               lambda cfg: EnumLabelWidget(cfg),
        "health_label":             lambda cfg: HealthLabelWidget(cfg),

        # Buttons
        "button":                   lambda cfg: ButtonWidget(cfg),
        "version_button":           lambda cfg: VersionButtonWidget(cfg),
        "three_state_button":       lambda cfg: ThreeStateButtonWidget(cfg),
        "latching_button":          lambda cfg: LatchingButtonWidget(cfg),

        # Control
        "param_editor":             lambda cfg: ParamEditorWidget(cfg),
        "horizontal_slider":        lambda cfg: HorizontalSliderWidget(cfg),
        "dial":                     lambda cfg: DialWidget(cfg),
        "publisher":                lambda cfg: PublisherWidget(cfg),

        # Visualization
        "bound_image":              lambda cfg: BoundImageWidget(cfg),
        "plot" :                    lambda cfg: PlotWidget(cfg),
        "gps_map":                  lambda cfg: GpsMapWidget(cfg),
        "can_graph":                lambda cfg: CanGraphWidget(cfg),

        # Tables
        "table":                    lambda cfg: TableWidget(cfg),
        "template_table":           lambda cfg: TemplateTableWidget(cfg),
    }

    @classmethod
    def create(cls, cfg: dict) -> BaseWidget:
        wtype = cfg.get("type", "")
        if wtype in cls.registry:
            return cls.registry[wtype](cfg)
        return ConstLabelWidget({"text": f"{wtype} - Unknown widget type"})

#
# Label widgets
#
class ConstLabelWidget(BaseWidget):
    """
    A simple static text label widget.

    YAML example:
      type: const_label
      text: "Firmware Version"
    """

    def init_ui(self):
        text = str(self.cfg.get("text"))
        label = QLabel(text)
        self.layout.addWidget(label)

class BoundLabelWidget(BaseWidget):
    """
    A label that updates from one or more communicator topics.

    YAML example:
      type: bound_label
      topics:
        - dronecan.uavcan.protocol.NodeStatus::uptime_sec
        - cyphal.uavcan.node.Heartbeat_1_0::uptime
      default: "-"
      precision: 1
      unit: "s"
    """

    def init_ui(self):
        self.default_text = str(self.cfg.get("default", self.cfg.get("text", "-")))
        self.label = QLabel(self.default_text)
        self.layout.addWidget(self.label)

        self.require_communicator()
        self.tf = ValueTransformer(self.cfg)
        try:
            self.topic_field_pairs = self.subscribe(self.cfg, self.communicator, self._on_msg)
        except ValueError:
            return

    def _on_msg(self, msg, field):
        value = resolve_field_path(msg, field)
        if value is None:
            self.label.setText(self.default_text)
            return
        self._update_text(value)

    def _update_text(self, raw):
        self.label.setText(str(self.tf.transform(raw)))

class InfoLabelWidget(BaseWidget):
    """
    A label that displays a node info field via subscribe_get_info.

    YAML example:
      type: info_label
      info: "software_version"
      node_id: 51
      default: "-"
      precision: 2
    """

    def init_ui(self):
        self.default_text = str(self.cfg.get("default", self.cfg.get("text", "-")))
        self.label = QLabel(self.default_text)
        self.layout.addWidget(self.label)

        self.require_communicator()
        self.node_id = get_optional_int(self.cfg, "node_id")
        self.info_key = self.cfg.get("info")
        self.tf = ValueTransformer(self.cfg)
        if not self.info_key or self.node_id is None:
            logger.warning("InfoLabelWidget requires both 'info' and 'node_id'")
            return
        self.communicator.subscribe_get_info(
            self.node_id,
            self.info_key,
            self._on_info
        )

    def _on_info(self, value):
        if value is None:
            self.label.setText(self.default_text)
            return
        self.label.setText(str(self.tf.transform(value)))


class FirmwareUpdateState(Enum):
    NO_INFO = auto()
    OUTDATED = auto()
    UP_TO_DATE = auto()

FIRMWARE_STATE_EMOJI = {
    FirmwareUpdateState.NO_INFO:    "❔",
    FirmwareUpdateState.OUTDATED:   "⬆️",
    FirmwareUpdateState.UP_TO_DATE: "✅",
}

def determine_firmware_state(current: str | None, latest: str | None) -> FirmwareUpdateState:
    if not current or not latest:
        return FirmwareUpdateState.NO_INFO

    current = current.strip()
    latest = latest.strip()

    if not current or not latest:
        return FirmwareUpdateState.NO_INFO

    if current == latest:
        return FirmwareUpdateState.UP_TO_DATE

    return FirmwareUpdateState.OUTDATED

class VersionButtonWidget(BaseWidget):
    """
    A button that shows device software version and update status.

    YAML example:
      type: version_button
      node_id: 42
    """
    def init_ui(self):
        self.button = QPushButton("")
        self.layout.addWidget(self.button)
        self.button.clicked.connect(self._on_click)

        self.require_communicator()
        self.state = FirmwareUpdateState.NO_INFO
        self.node_id: int | None = get_optional_int(self.cfg, "node_id")
        self.firmware_index = load_firmware_index(self.cfg.get("firmware_index", None))
        self.current_version: str | None = None
        self.latest_version: str | None = None
        self.name: str | None = None
        self.communicator.subscribe_get_info(self.node_id, "software_version", self._on_software_version)
        self.communicator.subscribe_get_info(self.node_id, "name", self._on_name)

    def _on_software_version(self, value):
        self.current_version = str(value) if value is not None else None
        self._update_text()

    def _on_name(self, value):
        self.name = str(value) if value is not None else None
        self._update_text()

    def _update_text(self):
        firmware_context = self.firmware_index.get(self.name, {})
        self.latest_version = firmware_context.get("latest_version", None)

        self.state = determine_firmware_state(current=self.current_version, latest=self.latest_version)
        emoji = FIRMWARE_STATE_EMOJI.get(self.state, "❔")
        text = f"{self.current_version} {emoji}" if self.current_version else emoji
        logger.debug("%s: %s %s %s", self.__class__.__name__, self.node_id, text, self.latest_version)
        self.button.setText(text)

    def _on_click(self):
        self.require_node_id()
        if self.state is FirmwareUpdateState.NO_INFO:
            logger.warning("upgrade_firmware: NO_INFO")
            QMessageBox.warning(
                self,
                self.tr("firmware.update.title"),
                self.tr("firmware.update.no_info"),
            )
            return
        if self.state is FirmwareUpdateState.UP_TO_DATE:
            logger.warning("upgrade_firmware: UP_TO_DATE")
            QMessageBox.information(
                self,
                self.tr("firmware.update.title"),
                self.tr("firmware.update.up_to_date"),
            )
            return

        firmware_context = self.firmware_index.get(self.name, {})
        current = self.current_version or "?"
        latest = self.latest_version or "?"
        node = self.node_id
        name = self.name or "?"

        question_text = self.tr(
            "firmware.update.question",
            node_id=node,
            name=name,
            current=current,
            latest=latest,
        )

        reply = QMessageBox.question(
            self,
            self.tr("firmware.update.title"),
            question_text,
            QMessageBox.Yes | QMessageBox.No,
        )
        if reply != QMessageBox.Yes:
            logger.info("upgrade_firmware: user cancelled")
            return

        try:
            # This is a temp hack for a fast way to upload the firmware
            # At the moment it supports only: artifact: "file:./firmware/co.rl.mini-v1.3.bin"
            # It should also suport artifact: "url:https://example.com/fw/co.rl.gnss-v0.5.bin"
            # And this: artifact: "gh:my-org/my-firmware-repo@v2.0-deadbeef:build/output.bin"
            FirmwareManager.upload_firmware(firmware_context["artifact"][5:])
            # self.communicator.execute_command(node_id=self.node_id, command="upgrade_firmware", context=firmware_context)
        except Exception as e:
            logger.warning("upgrade_firmware command failed: %s", e)
            QMessageBox.critical(
                self,
                self.tr("firmware.update.failed_title"),
                self.tr("firmware.update.failed_message", error=e),
            )


class EnumLabelWidget(BaseWidget):
    """
    Color-coded enum label from one or more topic::field pairs.

    YAML:
      type: EnumLabelWidget
      topics:
        - cyphal.uavcan.node.Heartbeat_1_0::health
        - dronecan.uavcan.protocol.NodeStatus::health
      node_id: 42
      mapping:
        None: {text: "OFF",  color: "red"}
        0:    {text: "OK",   color: "green"}
        1:    {text: "WARN", color: "yellow"}
        2:    {text: "ERR",  color: "purple"}
        3:    {text: "CRIT", color: "red"}
    """

    def init_ui(self):
        self.label = QLabel(self.cfg.get("text", "-"))
        self.layout.addWidget(self.label)

        self.require_communicator()
        try:
            self.topic_field_pairs = self.subscribe(self.cfg, self.communicator, self._on_msg)
        except ValueError:
            return

        raw_mapping = self.cfg.get("mapping", {})
        self.mapping = {}

        for k, v in raw_mapping.items():
            if k in (None, "None", "none", "null", "NULL"):
                self.mapping[None] = v
            else:
                try:
                    self.mapping[int(k)] = v
                except Exception:
                    self.mapping[k] = v

        self.offline_entry = self.mapping.get(None, {"text": "OFF", "color": "red"})
        self._apply_style(self.offline_entry["text"], self.offline_entry["color"])

    def _on_msg(self, msg, field):
        value = resolve_field_path(msg, field)
        entry = self.mapping.get(value, self.offline_entry)
        self._apply_style(entry["text"], entry["color"])

    def _apply_style(self, text: str, color: str):
        self.label.setText(text)
        self.label.setStyleSheet(f"color: {color} !important; font-weight: bold;")


class HealthLabelWidget(EnumLabelWidget):
    """
    Specialized EnumLabelWidget for standard UAVCAN/Cyphal node health.

    YAML:
      type: HealthLabelWidget
      node_id: 42
    """

    def __init__(self, cfg):
        base_cfg = dict(cfg)

        base_cfg.setdefault("topics", [
            "dronecan.uavcan.protocol.NodeStatus::health",
            "cyphal.uavcan.node.Heartbeat_1_0::health.value",
        ])

        base_cfg.setdefault("mapping", {
            None: {"text": "OFF",  "color": "red"},
            0:    {"text": "OK",   "color": "green"},
            1:    {"text": "WARN", "color": "yellow"},
            2:    {"text": "ERR",  "color": "purple"},
            3:    {"text": "CRIT", "color": "red"},
        })

        super().__init__(base_cfg)

class ParamEditorWidget(BaseWidget):
    """
    Editable parameter widget that both fetches and allows updating a parameter.

    YAML example:
      type: ParamEditorWidget
      param: "pwm1.min"
      node_id: 51
      editable: true
      refresh: 2.0   # optional: refresh interval in seconds
    """

    def init_ui(self):
        from PySide6.QtWidgets import QHBoxLayout, QLabel, QLineEdit

        self.editable = bool(self.cfg.get("editable", True))
        self.default_value = str(self.cfg.get("default", ""))
        self.prev_text = ""

        # Layout
        h = QHBoxLayout()
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(4)

        # Editable value field
        self.input = QLineEdit()
        self.input.setAlignment(Qt.AlignLeft)
        self.input.setFixedWidth(80)
        self.input.setEnabled(self.editable)
        self.input.setText(self.default_value)
        h.addWidget(self.input)

        self.layout.addLayout(h)

        # Signals for user edits
        self.input.editingFinished.connect(self._on_user_edit)
        self.normal_palette = self.input.palette()  # save current palette

        self.require_communicator()
        self.param_name = self.cfg.get("param")
        self.node_id = int(self.cfg.get("node_id"))
        if not self.param_name or self.node_id is None:
            self.input.setText("ERR")
            return

        self.communicator.subscribe_param(self.node_id, self.param_name, self.setText)

    def setText(self, text):
        """Thread-safe: may be called from any thread."""
        if QThread.currentThread() != self.thread():
            # We're in a background thread → re-invoke safely in GUI thread
            QMetaObject.invokeMethod(
                self,
                "_setText_internal",
                Qt.QueuedConnection,
                Q_ARG(str, text)
            )
            return

        # We're already in GUI thread → safe to update immediately
        self._setText_internal(text)

    @Slot(str)
    def _setText_internal(self, text):
        """Actual UI update logic (runs in GUI thread only)."""
        if text in (None, "", "offline"):
            text = self.default_value

        self.prev_text = text
        self.input.setText(text)

        # Restore normal tint with a short success flash
        self._set_field_tint(QColor("#8fce00"))  # green tint
        QTimer.singleShot(200, lambda: self._set_field_tint(None))

    def _on_user_edit(self):
        """Handle manual edit by user."""
        text = self.input.text().strip()
        if not text:
            return

        if text == self.prev_text:
            return  # skip because nothing has changed

        try:
            if "." in text:
                val = float(text)
            else:
                val = int(text)
        except ValueError:
            # Not a number — treat as string
            val = text

        # Optional validation:
        if isinstance(val, str) and len(val) > 63:
            logger.warning(f"String too long for parameter {self.param_name}")
            self._set_field_tint(QColor("#ff4d4d"))  # red tint for invalid
            QTimer.singleShot(1000, lambda: self._set_field_tint(None))
            return

        # set pending tint (soft yellow)
        self._set_field_tint(QColor("#ffd966"))

        self.communicator.request_param_set(self.node_id, self.param_name, val)

    def _set_field_tint(self, color: QColor | None):
        """Apply a temporary background tint (theme-safe)."""
        pal = self.normal_palette
        if color:
            pal = QPalette(pal)
            base = pal.color(QPalette.Base)
            # Mix base with tint (70% base, 30% tint)
            mixed = QColor(
                int(base.red() * 0.7 + color.red() * 0.3),
                int(base.green() * 0.7 + color.green() * 0.3),
                int(base.blue() * 0.7 + color.blue() * 0.3),
            )
            pal.setColor(QPalette.Base, mixed)
        self.input.setPalette(pal)

    def focusInEvent(self, event):
        """Mark as user editing to prevent background refreshes."""
        super().focusInEvent(event)

    def focusOutEvent(self, event):
        """Write value when leaving the field."""
        self._on_user_edit()
        super().focusOutEvent(event)


class ButtonWidget(BaseWidget):
    """
    A configurable button that performs different actions.

    YAML example:
      type: ButtonWidget
      text: "Save all parameters"
      action: noop | save_all | reboot | update_firmware
      node_id: 63
    """

    def init_ui(self):
        self.require_communicator()

        self.button = QPushButton(self.cfg.get("text", "Button"))
        self.layout.addWidget(self.button)

        self.action = self.cfg.get("action", "noop")
        self.node_id = get_optional_int(self.cfg, "node_id")

        self._blink_timer = None
        self._blink_on = False

        def execute_command_callback():
            self.communicator.execute_command(node_id=self.node_id, command=self.action, context={})
        self.button.clicked.connect(execute_command_callback)

        if self.action == "save_all":
            self.communicator.register_action(self.node_id, self.action, self.start_hint)

    def start_hint(self, duration: float | None = None):
        """Start blinking the button to attract user's attention."""
        if self._blink_timer is not None:
            return

        self._blink_timer = QTimer(self)
        self._blink_timer.timeout.connect(self._toggle_blink)
        self._blink_timer.start(500)
        logger.debug("Blinking started for button '%s'", self.button.text())

        if duration is not None and duration > 0:
            QTimer.singleShot(int(duration * 1000), self.stop_hint)

    def stop_hint(self):
        """Stop blinking and restore the button style."""
        if self._blink_timer:
            self._blink_timer.stop()
            self._blink_timer = None
        self.button.setStyleSheet("")
        self.button.style().unpolish(self.button)
        self.button.style().polish(self.button)
        self.button.update()
        self._blink_on = False
        logger.debug("Blinking stopped for button '%s'", self.button.text())

    def _toggle_blink(self):
        """Toggle between two visual styles."""
        self._blink_on = not self._blink_on
        if self._blink_on:
            self.button.setStyleSheet("background-color: #fff4b3; color: black; font-weight: bold;")
        else:
            self.button.setStyleSheet("")

        self.button.style().unpolish(self.button)
        self.button.style().polish(self.button)
        self.button.update()

class RowWidget(QWidget):
    """Dynamic table row with flexible columns based on header definition.

    Cells may be:
      - QWidget instances (used directly)
      - dict: a widget config (must include "type"; WidgetFactory.create will be used)
      - list: a sequence of widget configs or widgets (rendered horizontally inside the cell)
      - scalar: treated as text and wrapped by ConstLabelWidget

    The optional communicator is injected into nested widget configs when present.
    """

    def __init__(self, fields: list[str], values: dict | list, widths=None, bold=False, communicator=None):
        super().__init__()
        layout = QHBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(10)
        layout.setAlignment(Qt.AlignTop)

        style_suffix = "font-weight: bold;" if bold else ""
        self.fields = fields
        self.widths = widths or []
        self.communicator = communicator

        # Normalize data
        if isinstance(values, dict):
            cell_values = [values.get(key, "") for key in fields]
        else:
            cell_values = [v for v in values]

        max_height = 0
        for i, (key, cell_value) in enumerate(zip(fields, cell_values)):
            widget = None

            # If the cell is already a QWidget, use it directly
            if isinstance(cell_value, QWidget):
                widget = cell_value

            # If the cell is a dict with 'widgets' key -> composite cell
            elif isinstance(cell_value, dict) and "widgets" in cell_value and isinstance(cell_value["widgets"], list):
                container = QWidget()
                h = QHBoxLayout()
                h.setContentsMargins(0, 0, 0, 0)
                h.setSpacing(6)
                # create each inner widget
                for sub in cell_value["widgets"]:
                    sub_cfg = dict(sub) if isinstance(sub, dict) else sub
                    if isinstance(sub_cfg, dict) and self.communicator and "communicator" not in sub_cfg:
                        sub_cfg["communicator"] = self.communicator
                    sub_widget = sub_cfg if isinstance(sub_cfg, QWidget) else WidgetFactory.create(sub_cfg) if isinstance(sub_cfg, dict) else ConstLabelWidget({"text": str(sub_cfg)})
                    h.addWidget(sub_widget)
                    try:
                        hint = sub_widget.sizeHint().height()
                        if hint > max_height:
                            max_height = hint
                    except Exception as err:
                        logger.error(err)
                container.setLayout(h)
                widget = container

            # If the cell is a list -> render each element inside a container
            elif isinstance(cell_value, list):
                container = QWidget()
                h = QHBoxLayout()
                h.setContentsMargins(0, 0, 0, 0)
                h.setSpacing(6)
                for sub in cell_value:
                    if isinstance(sub, QWidget):
                        sub_widget = sub
                    elif isinstance(sub, dict):
                        sub_cfg = dict(sub)
                        if self.communicator and "communicator" not in sub_cfg:
                            sub_cfg["communicator"] = self.communicator
                        sub_widget = WidgetFactory.create(sub_cfg)
                    else:
                        sub_widget = ConstLabelWidget({"text": str(sub)})
                    h.addWidget(sub_widget)
                    try:
                        hint = sub_widget.sizeHint().height()
                        if hint > max_height:
                            max_height = hint
                    except Exception as err:
                        logger.error(err)
                container.setLayout(h)
                widget = container

            # If the cell is a dict -> treat as a single widget config
            elif isinstance(cell_value, dict):
                cfg = dict(cell_value)
                if self.communicator and "communicator" not in cfg:
                    cfg["communicator"] = self.communicator
                widget = WidgetFactory.create(cfg)

            # fallback: treat as scalar text
            else:
                widget = ConstLabelWidget({"text": str(cell_value)})

            # Apply styling (best-effort; widgets may override)
            try:
                # Skip styling for color-aware widgets
                if isinstance(widget, (EnumLabelWidget, BoundLabelWidget, BoundImageWidget)):
                    pass
                else:
                    color = self._text_color(key, str(cell_value), bold)
                    widget.setStyleSheet(f"color: {color}; {style_suffix} padding: 0; margin: 0;")
            except Exception as err:
                logger.error(err)

            # Apply width if requested
            if i < len(self.widths):
                try:
                    widget.setFixedWidth(self.widths[i])
                except Exception as err:
                    logger.error(err)

            layout.addWidget(widget)
            # update max height from sizeHint
            try:
                hint = widget.sizeHint().height()
                # Clamp images to a reasonable max row height
                if isinstance(widget, QLabel) and widget.pixmap() is not None:
                    hint = min(hint, 32)  # e.g. max 32 px high
                if hint > max_height:
                    max_height = hint
            except Exception as err:
                logger.error(err)

        self.setLayout(layout)
        # keep rows compact but large enough for contents
        if max_height > 0:
            self.setFixedHeight(max(20, max_height + 2))
        else:
            self.setFixedHeight(20)

    def _text_color(self, key: str, text: str, bold: bool) -> str:
        if bold:
            return "#ccc"
        s = str(text).lower()
        if key in ("status", "update"):
            if "ok" in s:
                return "#00ff88"
            elif "off" in s:
                return "#ff4444"
            elif "warn" in s:
                return "#ffaa00"
        return "white"


class TableWidget(BaseWidget):
    """Generic table widget using header dict for field mapping, with auto column width.

    Cells inside rows may be provided as widget configs (dict with 'type') or plain scalars.
    TableWidget will inject the parent/ panel communicator into nested widget configs when present.
    """

    def __init__(self, cfg: dict):
        # keep cfg/communicator for nested widgets in cells
        self.communicator = cfg.get("communicator")
        self.header_dict = cfg.get("header", {})
        self.fields = list(self.header_dict.keys())
        self.header_labels = list(self.header_dict.values())
        self.rows = cfg.get("rows", [])

        QWidget.__init__(self)
        self.layout = QVBoxLayout()
        self.layout.setContentsMargins(0, 0, 0, 0)
        self.layout.setSpacing(0)
        self.layout.setAlignment(Qt.AlignTop)
        self.setLayout(self.layout)
        self.init_ui()

    def compute_column_widths(self, font_metrics):
        """Compute max text width for each column.

        If a cell is a dict with a 'text' key, use that text. Otherwise fall back
        to string conversion. Also handle lists/composite cells by inspecting
        their first text-like element.
        """
        widths = [0] * len(self.fields)

        for i, label in enumerate(self.header_labels):
            widths[i] = max(widths[i], font_metrics.horizontalAdvance(str(label)))

        for row in self.rows:
            for i, key in enumerate(self.fields):
                val = row.get(key, "")
                text = ""
                # extract representative text if it's a widget config or composite
                if isinstance(val, dict):
                    if "text" in val:
                        text = val.get("text")
                    elif "widgets" in val and isinstance(val["widgets"], list) and val["widgets"]:
                        first = val["widgets"][0]
                        text = first.get("text", str(first)) if isinstance(first, dict) else str(first)
                    else:
                        text = val.get("label", val.get("name", ""))
                elif isinstance(val, list) and val:
                    first = val[0]
                    if isinstance(first, dict):
                        text = first.get("text", first.get("name", ""))
                    else:
                        text = str(first)
                else:
                    text = str(val)

                widths[i] = max(widths[i], font_metrics.horizontalAdvance(text))

        # small padding for cell margins
        return [w + 16 for w in widths]

    def init_ui(self):
        self.require_communicator()

        fm = QFontMetrics(self.font())
        col_widths = self.compute_column_widths(fm)

        if self.header_labels:
            header_row = RowWidget(self.fields, self.header_labels, widths=col_widths, bold=True, communicator=self.communicator)
            header_row.setStyleSheet("background-color: #222;")
            self.layout.addWidget(header_row)

        for row in self.rows:
            self.layout.addWidget(RowWidget(self.fields, row, widths=col_widths, communicator=self.communicator))

class TemplateTableWidget(BaseWidget):
    """
    Pattern-driven table with optional discovery via registry.online_id_set().

    Behavior:
      - Seed (hardcoded) nodes are created first in the given order and are ALWAYS visible.
      - Discovered nodes (not in seeds) are appended after seeds.
      - Discovered rows are shown only while online; when offline they are hidden.
      - Rows are never deleted.
      - Column widths are derived ONLY from header labels (like TableWidget baseline).
    """

    def __init__(self, cfg: dict):
        self.communicator = cfg.get("communicator")
        self.registry = getattr(self.communicator, "registry", None)

        # --- config ---
        self.header_labels: list[str] = [str(x) for x in (cfg.get("header") or [])]
        self.pattern_list: list = list(cfg.get("pattern") or [])
        self.items: list[dict] = list(cfg.get("items") or [])
        self.discover: bool = bool(cfg.get("discover", True))

        # derive simple field keys (for RowWidget)
        self.fields = [self._to_key(lbl) for lbl in self.header_labels]

        # align pattern length with header length
        n = len(self.header_labels)
        if len(self.pattern_list) > n:
            self.pattern_list = self.pattern_list[:n]
        elif len(self.pattern_list) < n:
            self.pattern_list += [""] * (n - len(self.pattern_list))

        # seeds and friendly names (keep order as provided)
        self.seed_ids: list[int] = [it["id"] for it in self.items if "id" in it]
        self.name_by_id: dict = {it["id"]: it.get("name", f"Node {it['id']}") for it in self.items if "id" in it}

        QWidget.__init__(self)
        self.layout = QVBoxLayout()
        self.layout.setContentsMargins(0, 0, 0, 0)
        self.layout.setSpacing(0)
        self.layout.setAlignment(Qt.AlignTop)
        self.setLayout(self.layout)

        # --- column widths based ONLY on headers ---
        fm = QFontMetrics(self.font())
        self.col_widths = self._header_based_widths(fm, self.header_labels)

        # header row (apply widths so columns align)
        if self.header_labels:
            header = RowWidget(self.fields, self.header_labels,
                               widths=self.col_widths, bold=True,
                               communicator=self.communicator)
            header.setStyleSheet("background-color: #222;")
            self.layout.addWidget(header)

        # container for rows; never delete, only hide/show
        self.rows_by_id: dict[int, RowWidget] = {}

        # initial rows: create ALL seeds first (keep their order)
        initial_online = self._get_discovered_ids()
        for nid in self.seed_ids:
            self._ensure_row(nid)

        # then create discovered extras (exclude seeds), sorted
        for nid in sorted(initial_online - set(self.seed_ids), key=self._sort_key):
            self._ensure_row(nid)

        # set visibility (seeds always visible; extras only if online)
        self._apply_online_visibility(initial_online)

        # polling (fixed 1s)
        self._timer = None
        if self.discover and self.registry:
            self._timer = QTimer(self)
            self._timer.timeout.connect(self._poll_discovery)
            self._timer.start(1000)

    def init_ui(self):
        self.require_communicator()

    # ---------- discovery / visibility ----------
    def _get_discovered_ids(self) -> set[int]:
        if self.registry and hasattr(self.registry, "online_id_set"):
            try:
                return set(self.registry.online_id_set())
            except Exception:
                return set()
        return set()

    def _poll_discovery(self):
        online = self._get_discovered_ids()

        # create rows for any newly-seen IDs that are not seeds
        for nid in sorted(online - set(self.seed_ids), key=self._sort_key):
            if nid not in self.rows_by_id:
                self._ensure_row(nid)

        # update visibility (seeds always visible; extras only while online)
        self._apply_online_visibility(online)

    def _apply_online_visibility(self, online_ids: set[int]):
        online = set(online_ids)
        seed_set = set(self.seed_ids)

        for nid, row in self.rows_by_id.items():
            if nid in seed_set:
                # seeds: mandatory, always visible
                row.setVisible(True)
            else:
                # extras: only visible while online
                row.setVisible(nid in online)

    # ---------- row creation ----------
    def _ensure_row(self, node_id: int):
        """Create row once; subsequent updates just toggle visibility."""
        if node_id in self.rows_by_id:
            return

        cells = self._filled_cells_for_id(node_id)
        row = RowWidget(self.fields, cells,
                        widths=self.col_widths,
                        communicator=self.communicator)
        self.rows_by_id[node_id] = row
        self.layout.addWidget(row)

    def _filled_cells_for_id(self, node_id: int) -> list:
        """Fill pattern with mapping for the given node_id; return list of cell configs."""
        # find item dict for this ID (if any)
        item = next((it for it in self.items if it.get("id") == node_id), {})
        # build mapping with defaults and all custom fields
        mapping = dict(item)
        mapping.setdefault("id", node_id)
        mapping.setdefault("name", self.name_by_id.get(node_id, f"Node {node_id}"))

        cells = []
        for tmpl in self.pattern_list:
            filled = self._fill_placeholders(tmpl, mapping)
            if isinstance(filled, dict) and "type" in filled:
                f2 = dict(filled)
                if self.communicator and "communicator" not in f2:
                    f2["communicator"] = self.communicator
                filled = f2
            cells.append(filled)
        return cells

    # ---------- helpers ----------
    @staticmethod
    def _to_key(label: str) -> str:
        import re
        s = re.sub(r"\s+", "_", str(label).strip().lower())
        s = re.sub(r"[^a-z0-9_]", "", s)
        return s or "col"

    @staticmethod
    def _sort_key(x):
        try:
            return (0, int(x))
        except Exception:
            return (1, str(x))

    def _fill_placeholders(self, obj, mapping: dict):
        """Recursively format strings in dict/list structures using mapping."""
        if isinstance(obj, str):
            try:
                return obj.format(**mapping)
            except KeyError:
                return obj  # leave unchanged if key missing
        elif isinstance(obj, dict):
            return {k: self._fill_placeholders(v, mapping) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [self._fill_placeholders(x, mapping) for x in obj]
        return obj

    def _header_based_widths(self, fm: QFontMetrics, headers: list[str]) -> list[int]:
        """Compute per-column widths using only header labels (like TableWidget baseline)."""
        widths = [0] * len(headers)
        for i, lbl in enumerate(headers):
            widths[i] = max(widths[i], fm.horizontalAdvance(str(lbl)))
        # small padding for cell margins
        return [w + 16 for w in widths]

    def closeEvent(self, e):
        if self._timer:
            self._timer.stop()
            self._timer = None
        super().closeEvent(e)

class BoundImageWidget(BaseWidget):
    """
    Display one of two images depending on a numeric field value.

    YAML:
      type: BoundImageWidget
      topics:
        - dronecan.uavcan.equipment.actuator.Status::power_rating_pct
      node_id: 51
      threshold: 30
      image_low: "assets/low.png"
      image_high: "assets/high.png"
    """

    def init_ui(self):
        self.require_communicator()

        # QLabel setup
        self.label = QLabel()
        self.label.setAlignment(Qt.AlignCenter)
        self.layout.addWidget(self.label)
        self.layout.setContentsMargins(0, 0, 0, 0)
        self.layout.setSpacing(0)
        self.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Minimum)

        self.threshold = float(self.cfg.get("threshold", 30))
        self.image_low_path = self.cfg.get("image_low", "assets/low.png")
        self.image_high_path = self.cfg.get("image_high", "assets/high.png")

        # Load both images
        self.image_low = QPixmap(self.image_low_path)
        self.image_high = QPixmap(self.image_high_path)

        if not self.image_low or self.image_low.isNull():
            logger.warning(f"BoundImageWidget: missing image_low: {self.image_low_path}")
        if not self.image_high or self.image_high.isNull():
            logger.warning(f"BoundImageWidget: missing image_high: {self.image_high_path}")

        # Default image
        self.current_image = self.image_low
        self.label.setPixmap(self._fit_pixmap(self.image_low))

        try:
            self.topic_field_pairs = self.subscribe(self.cfg, self.communicator, self._on_msg)
        except ValueError:
            return

    def _fit_pixmap(self, pixmap: QPixmap) -> QPixmap:
        """Scale image only if needed for the current cell size."""
        if not pixmap or pixmap.isNull():
            return QPixmap()

        target_w = max(1, self.width() or self.label.width() or 24)
        target_h = max(1, self.height() or self.label.height() or 24)
        img_w = pixmap.width()
        img_h = pixmap.height()

        if img_w > target_w or img_h > target_h:
            return pixmap.scaled(target_w, target_h,
                                 Qt.KeepAspectRatio,
                                 Qt.SmoothTransformation)

        return pixmap

    def resizeEvent(self, event):
        if self.current_image and not self.current_image.isNull():
            self.label.setPixmap(self._fit_pixmap(self.current_image))
        super().resizeEvent(event)

    def _on_msg(self, msg, field):
        """Update image depending on subscribed field value."""
        value = resolve_field_path(msg, field)
        if value is None:
            return

        try:
            val = float(value)
        except (TypeError, ValueError):
            return

        new_img = self.image_high if val >= self.threshold else self.image_low
        if new_img.cacheKey() != self.current_image.cacheKey():
            self.current_image = new_img
            self.label.setPixmap(self._fit_pixmap(self.current_image))

    def sizeHint(self):
        """Small default to avoid window expansion."""
        if self.current_image and not self.current_image.isNull():
            img_size = self.current_image.size()
            return QSize(min(img_size.width(), 32),
                         min(img_size.height(), 32))
        return QSize(24, 24)


class PlotWidget(BaseWidget):
    """Real-time plotting widget using only topic::field pairs."""

    def init_ui(self):
        self.require_communicator()

        self.pg = lazy_import_module("PlotWidget", "pyqtgraph")

        try:
            self.topic_field_pairs = self.subscribe(self.cfg, self.communicator, self._on_msg)
        except ValueError:
            return

        # Extract fields
        self.fields = [field for _, field in self.topic_field_pairs]

        # Legend names
        self.names = self.cfg.get("names", self.fields)

        # Node ID (optional)
        self.node_id = get_optional_int(self.cfg, "node_id")

        # Plot parameters
        self.window = int(self.cfg.get("window", 200))
        self.refresh_rate = float(self.cfg.get("refresh_rate", 20))
        self.title = self.cfg.get("title", None)
        self.xlabel = self.cfg.get("xlabel", "Samples")
        self.ylabel = self.cfg.get("ylabel", "Value")

        # Data storage
        self.data = {f: deque(maxlen=self.window) for f in self.fields}
        self.xdata = deque(maxlen=self.window)
        self.counter = 0

        # --- Setup pyqtgraph ---
        self.plot_widget = self.pg.PlotWidget()
        self.plot_widget.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.plot_widget.setMinimumHeight(150)
        self.plot_widget.showGrid(x=True, y=True, alpha=0.3)

        if self.title:
            self.plot_widget.setTitle(self.title)
        self.plot_widget.setLabel("bottom", self.xlabel)
        self.plot_widget.setLabel("left", self.ylabel)
        self.plot_widget.addLegend(offset=(10, 10))

        # Create curves
        colors = ["y", "c", "m", "g", "r", "b"]
        self.curves = {}

        for i, (field, name) in enumerate(zip(self.fields, self.names)):
            pen = self.pg.mkPen(colors[i % len(colors)], width=2)
            self.curves[field] = self.plot_widget.plot([], [], pen=pen, name=name)

        self.layout.addWidget(self.plot_widget)

        # --- Timer for redrawing ---
        self.timer = QTimer()
        self.timer.timeout.connect(self._update_plot)
        self.timer.start(int(1000 / self.refresh_rate))

    def _on_msg(self, msg, field):
        self.counter += 1
        self.xdata.append(self.counter)

        val = resolve_field_path(msg, field)
        if isinstance(val, (int, float)):
            self.data[field].append(val)
        else:
            self.data[field].append(float("nan"))

    def _update_plot(self):
        for field, curve in self.curves.items():
            y = list(self.data[field])
            if not y:
                continue
            x = list(self.xdata)[-len(y):]
            curve.setData(x, y)

class HorizontalSliderWidget(BaseWidget):
    """
    Horizontal slider bound to one or more topic::field pairs.

    New YAML:

      - type: HorizontalSlider
        topics:
          - dronecan.uavcan.equipment.actuator.ArrayCommand::commands[0].command_value
        min: -90
        max: 90
        step: 1
        initial: 0
        unit: "°"
        multiplier: 0.01111111111
        frequency: 10.0
    """

    def init_ui(self):
        self.require_communicator()

        try:
            self.topic_field_pairs = self.register_periodic_publisher(self.cfg, self.communicator)
        except ValueError:
            return

        # UI parameters
        cfg = self.cfg
        self.unit = cfg.get("unit", "")
        self.min = int(cfg.get("min", 0))
        self.max = int(cfg.get("max", 100))
        self.step = int(cfg.get("step", 1))
        self.value = int(cfg.get("initial", self.min))
        self.tf = ValueTransformer(cfg)

        # --- UI layout ---
        h = QHBoxLayout()
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(6)

        self.label = QLabel()
        fm = QFontMetrics(self.label.font())
        widest_text = f"{self.max}{self.unit}"
        self.label.setFixedWidth(fm.horizontalAdvance(widest_text) + 10)
        self.label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.label.setText(f"{self.value}{self.unit}")
        h.addWidget(self.label)

        self.slider = QSlider(Qt.Horizontal)
        self.slider.setRange(self.min, self.max)
        self.slider.setSingleStep(self.step)
        self.slider.setValue(self.value)
        self.slider.valueChanged.connect(self._on_value_changed)
        h.addWidget(self.slider, 1)

        self.layout.addLayout(h)

    def _on_value_changed(self, value):
        self.label.setText(f"{value}{self.unit}")
        value = self.tf.transform(value)
        self.update_publisher_value(self.topic_field_pairs, self.communicator, value)

class DialWidget(BaseWidget):
    """
    Rotary dial that publishes values to one or more topic::field pairs.

    NEW YAML:
      type: DialWidget
      topics:
        - dronecan.uavcan.equipment.esc.RawCommand::cmd[0]
      min: 0
      max: 2000
      step: 10
      initial: 0
      unit: "rpm"
      frequency: 5
    """

    def init_ui(self):
        self.require_communicator()

        from PySide6.QtWidgets import QVBoxLayout, QLabel, QDial

        cfg = self.cfg

        try:
            self.topic_field_pairs = self.register_periodic_publisher(self.cfg, self.communicator)
        except ValueError:
            return

        # --- Parameters ---
        self.text_label = cfg.get("text", "")
        self.unit = cfg.get("unit", "")
        self.min = float(cfg.get("min", 0))
        self.max = float(cfg.get("max", 100))
        self.step = float(cfg.get("step", 1))
        self.value = float(cfg.get("initial", self.min))
        self.tf = ValueTransformer(cfg)

        # --- Layout ---
        v = QVBoxLayout()
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(4)

        if self.text_label:
            title = QLabel(self.text_label)
            title.setAlignment(Qt.AlignCenter)
            v.addWidget(title)

        # --- Dial ---
        self.dial = QDial()
        self.dial.setRange(int(self.min / self.step), int(self.max / self.step))
        self.dial.setNotchesVisible(True)
        self.dial.setValue(int(self.value / self.step))
        self.dial.valueChanged.connect(self._on_value_changed)
        v.addWidget(self.dial, alignment=Qt.AlignCenter)

        # --- Value Label ---
        self.value_label = QLabel(f"{self.value:.1f}{self.unit}")
        self.value_label.setAlignment(Qt.AlignCenter)
        v.addWidget(self.value_label)

        self.layout.addLayout(v)

    def _on_value_changed(self, raw_steps):
        raw_value = raw_steps * self.step
        self.value_label.setText(f"{raw_value:.1f}{self.unit}")
        value = self.tf.transform(raw_value)
        self.update_publisher_value(self.topic_field_pairs, self.communicator, value)


class PublisherWidget(BaseWidget):
    """
    Editable field that periodically publishes a value to one or more topic::field pairs.

    YAML:
      type: PublisherWidget
      topics:
        - cyphal.uavcan.node.ExecuteCommand_1_1::command
      text: "Cmd"
      unit: ""
      frequency: 5
      initial: 1.0
      multiplier: 1.0
      offset: 0.0
    """

    def init_ui(self):
        self.require_communicator()

        from PySide6.QtWidgets import QHBoxLayout, QLabel, QLineEdit

        cfg = self.cfg

        try:
            self.topic_field_pairs = self.register_periodic_publisher(self.cfg, self.communicator)
        except ValueError:
            return

        # --- UI parameters ---
        self.node_id = get_optional_int(cfg, "node_id")
        self.text_label = cfg.get("text", "")
        self.unit = cfg.get("unit", "")
        self.frequency = float(cfg.get("frequency", 10.0))
        self.value = float(cfg.get("initial", 0))
        self.tf = ValueTransformer(cfg=cfg)

        # --- UI Layout ---
        h = QHBoxLayout()
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(4)

        if self.text_label:
            label = QLabel(self.text_label)
            h.addWidget(label)

        self.input = QLineEdit(str(self.value))
        self.input.setFixedWidth(80)
        self.input.setAlignment(Qt.AlignLeft)
        h.addWidget(self.input)

        if self.unit:
            unit_label = QLabel(self.unit)
            unit_label.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
            h.addWidget(unit_label)

        self.layout.addLayout(h)

        # --- Timer for periodic publishing ---
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._on_value_changed)
        self.timer.start(int(1000 / self.frequency))

        # User events
        self.input.editingFinished.connect(self._on_user_edit)
        self.input.returnPressed.connect(self._on_user_edit)

    def _on_user_edit(self):
        text = self.input.text().strip()
        if not text:
            return
        try:
            self.value = float(text)
        except ValueError:
            logger.warning(f"PublisherWidget: invalid input '{text}'")
            return
        self._on_value_changed()

    def _on_value_changed(self):
        value = self.tf.transform(self.value)
        self.update_publisher_value(self.topic_field_pairs, self.communicator, value)


class CanGraphWidget(BaseWidget):
    """Visualizes CAN topology (nodes, hubs, connections) as a graph."""

    def init_ui(self):
        self.require_communicator()

        self.pg = lazy_import_module("CanGraphWidget", "pyqtgraph")
        self.topology = self.cfg.get("topology", {})
        self.refresh_rate = float(self.cfg.get("refresh_rate", 2))

        # Prepare graph view
        self.graph_widget = self.pg.GraphItem()
        self.plot = self.pg.PlotWidget()
        self.plot.setAspectLocked(True)
        self.plot.hideAxis('bottom')
        self.plot.hideAxis('left')
        self.plot.addItem(self.graph_widget)
        self.layout.addWidget(self.plot)

        # Periodic updates
        self.timer = QTimer()
        self.timer.timeout.connect(self._update_graph)
        self.timer.start(int(1000 / self.refresh_rate))

        self.text_items = []

        self._update_graph()

    def _update_graph(self):
        """Draw or refresh graph based on topology."""
        elements = self.topology.get("elements", [])
        connections = self.topology.get("connections", [])

        # Build node map
        ids = [str(e["id"]) for e in elements]
        names = [e.get("name", str(e["id"])) for e in elements]
        colors = []
        for e in elements:
            if e.get("type") in ("mixer", "hub", "repeater"):
                colors.append((150, 150, 255, 255))  # bluish
            else:
                colors.append((150, 255, 150, 255))  # greenish

        n = len(ids)
        pos = {i: (i % 5, i // 5) for i in range(n)}  # simple grid layout
        adj = []
        for c in connections:
            if len(c) == 2 and str(c[0]) in ids and str(c[1]) in ids:
                i1, i2 = ids.index(str(c[0])), ids.index(str(c[1]))
                adj.append((i1, i2))

        # Convert to arrays
        import numpy as np
        pos_array = np.array([pos[i] for i in range(n)])
        adj_array = np.array(adj)
        symbols = ["o" if "node" in elements[i]["type"] else "s" for i in range(n)]
        brushes = [self.pg.mkBrush(*c) for c in colors]

        self.graph_widget.setData(
            pos=pos_array,
            adj=adj_array,
            symbol=symbols,
            size=20,
            pxMode=True,
            brush=brushes,
            pen="w",
            texts=names,
            textPen="w"
        )

        # Clear old labels
        for t in self.text_items:
            self.plot.removeItem(t)
        self.text_items.clear()

        # Add text labels near each node
        for (x, y), name in zip(pos_array, names):
            label = self.pg.TextItem(text=name, color=(230, 230, 230), anchor=(0.5, -0.3))
            label.setPos(x, y)
            self.plot.addItem(label)
            self.text_items.append(label)

class _LoggingPage(QWebEnginePage):
    def javaScriptConsoleMessage(self, level, message, lineNumber, sourceID):
        lvl_map = {
            QWebEnginePage.InfoMessageLevel: "INFO",
            QWebEnginePage.WarningMessageLevel: "WARNING",
            QWebEnginePage.ErrorMessageLevel: "ERROR",
        }
        lvl = lvl_map.get(level, "INFO")
        logger.log(getattr(logging, lvl), f"[JS:{lvl}] {sourceID}:{lineNumber} {message}")

class GpsMapWidget(BaseWidget):
    """
    Minimal GPS map (no blinking):
      - Renders Leaflet once via setHtml().
      - Moves marker via JS on each message.
      - Pans only if marker leaves current view.

    Extra config (optional):
      - min_height: default 260 (ensures widget is tall enough in splitters/layouts)
      - zoom_start: default 14
      - recenter_if_out_of_view: default True
    """

    # --- sizing hints so splitters/layouts give us real space ---
    def sizeHint(self):
        h = int(self.cfg.get("min_height", 260)) if hasattr(self, "cfg") else 260
        return QSize(480, h)

    def minimumSizeHint(self):
        return QSize(320, int(self.cfg.get("min_height", 260)) if hasattr(self, "cfg") else 260)

    def init_ui(self):
        self.require_communicator()

        # --- Layout ---
        if not hasattr(self, "layout"):
            self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(0, 0, 0, 0)
        self.layout.setSpacing(0)

        # --- WebView ---
        QWebEngineWidgets = importlib.import_module("PySide6.QtWebEngineWidgets")
        QWebEngineCore = importlib.import_module("PySide6.QtWebEngineCore")
        self.QWebEngineView = getattr(QWebEngineWidgets, "QWebEngineView")
        self.QWebEngineSettings = getattr(QWebEngineCore, "QWebEngineSettings")

        self.view = self.QWebEngineView(self)
        self.view.setPage(_LoggingPage(self.view))  # capture JS console
        s = self.view.settings()
        s.setAttribute(self.QWebEngineSettings.LocalContentCanAccessRemoteUrls, True)
        s.setAttribute(self.QWebEngineSettings.LocalContentCanAccessFileUrls, True)

        # Ask the layout/splitter for space
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.view.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setMinimumHeight(int(self.cfg.get("min_height", 260)))

        self.layout.addWidget(self.view)

        # --- Config ---
        cfg = self.cfg
        self.topic = cfg.get("topic")
        self.field_lat = cfg.get("field_lat", "lat")
        self.field_lon = cfg.get("field_lon", "lon")
        self.node_id = get_optional_int(cfg, "node_id")

        self.tf = ValueTransformer(cfg=self.cfg)

        self.zoom_start = int(cfg.get("zoom_start", 14))
        self.recenter_if_out = bool(cfg.get("recenter_if_out_of_view", True))

        # --- State ---
        self._page_ready = False
        self._first_fix = True
        self._pending = None  # (lat, lon, force_center)

        # Load minimal HTML directly (no temp files)
        html = self._leaflet_html(0.0, 0.0, self.zoom_start)
        self.view.setHtml(html, baseUrl=QUrl("https://unpkg.com/"))
        self.view.loadFinished.connect(self._on_load_finished)

        # --- Subscribe ---
        if self.topic:
            self.communicator.subscribe(
                dtype=self.topic,
                cb=self._on_msg,
                node_id=self.node_id
            )

    # Ensure Leaflet recalculates tiles when we’re resized by splitters/layouts
    def resizeEvent(self, e):
        super().resizeEvent(e)
        if getattr(self, "_page_ready", False):
            QTimer.singleShot(0, lambda: self.view.page().runJavaScript("map.invalidateSize();"))

    # ---------------- HTML ----------------
    def _leaflet_html(self, lat, lon, zoom):
        # The map div fills the whole page; Leaflet gets an explicit invalidateSize on resizes.
        return f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="initial-scale=1, width=device-width"/>
<title>GPS</title>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
<style>
  html, body {{ height:100%; margin:0; padding:0; }}
  #map {{ position:absolute; inset:0; }} /* fill container */
  .leaflet-container {{ background:#f0f0f0; }}
</style>
</head>
<body>
<div id="map"></div>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
  const map = L.map('map', {{ zoomControl:true }}).setView([{lat}, {lon}], {zoom});
  L.tileLayer('https://{{s}}.tile.openstreetmap.org/{{z}}/{{x}}/{{y}}.png', {{
    maxZoom: 19,
    attribution: '&copy; OpenStreetMap contributors'
  }}).addTo(map);

  const gpsIcon = L.icon({{
    iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
    iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
    shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
    iconSize: [25,41], iconAnchor: [12,41], popupAnchor: [1,-34], shadowSize: [41,41]
  }});

  const gpsMarker = L.marker([{lat}, {lon}], {{ icon:gpsIcon, title:'GPS' }}).addTo(map);

  function recenterIfNeeded() {{
    const inside = map.getBounds().contains(gpsMarker.getLatLng());
    if (!inside) map.panTo(gpsMarker.getLatLng(), {{ animate:true }});
  }}

  window.updateMarker = function(lat, lon, forceCenter) {{
    gpsMarker.setLatLng([lat, lon]);
    if (forceCenter) {{
      map.setView([lat, lon], map.getZoom());
    }} else {{
      recenterIfNeeded();
    }}
  }}

  // If the container changes size after load, make Leaflet relayout.
  window.addEventListener('resize', () => map.invalidateSize());
  setTimeout(() => map.invalidateSize(), 0);
</script>
</body>
</html>"""

    # ---------------- Page/JS bridge ----------------
    def _on_load_finished(self, ok: bool):
        self._page_ready = bool(ok)
        if not ok:
            logger.error("GPS map failed to load (loadFinished=False). Check network/CDN access.")
            return
        # Ensure correct layout after initial paint
        QTimer.singleShot(0, lambda: self.view.page().runJavaScript("map.invalidateSize();"))
        if self._pending is not None:
            lat, lon, force_center = self._pending
            self._pending = None
            self._js_update(lat, lon, force_center)

    def _js_update(self, lat: float, lon: float, force_center: bool):
        if not self._page_ready:
            self._pending = (lat, lon, force_center)
            return
        self.view.page().runJavaScript(
            f"window.updateMarker({lat:.8f}, {lon:.8f}, {str(force_center).lower()});"
        )

    # ---------------- Incoming data ----------------
    def _on_msg(self, topic, msg):
        lat = getattr(msg, self.field_lat, None) if not isinstance(msg, dict) else msg.get(self.field_lat)
        lon = getattr(msg, self.field_lon, None) if not isinstance(msg, dict) else msg.get(self.field_lon)
        if lat is None or lon is None:
            return
        try:
            lat = float(self.tf.transform(float(lat)))
            lon = float(self.tf.transform(float(lon)))
        except (ValueError, TypeError):
            logger.warning(f"Invalid GPS data: lat={lat}, lon={lon}")
            return

        force_center = self._first_fix
        self._first_fix = False
        self._js_update(lat, lon, force_center)

class BasePublishingButtonWidget(BaseWidget):
    """Base for buttons that publish a state periodically using topic::field syntax."""

    def init_publisher(self):
        try:
            self.topic_field_pairs = self.register_periodic_publisher(self.cfg, self.communicator)
        except ValueError:
            return

        self.frequency = float(self.cfg.get("frequency", 1.0))

        # Start periodic publisher timer
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._publish_state)
        self.timer.start(int(1000 / self.frequency))

    def _publish_state(self):
        value = self.current_state
        self.update_publisher_value(self.topic_field_pairs, self.communicator, value)

class LatchingButtonWidget(BasePublishingButtonWidget):
    """A toggle button that alternates between two states and publishes its value."""

    def init_ui(self):
        self.require_communicator()

        cfg = self.cfg

        self.state_on = float(cfg.get("state_on", 1.0))
        self.state_off = float(cfg.get("state_off", 0.0))
        self.text_on = cfg.get("text_on", "ON")
        self.text_off = cfg.get("text_off", "OFF")

        self.current_state = self.state_off

        self.checkbox = QCheckBox(self.text_off)
        self.checkbox.setChecked(False)
        self.checkbox.stateChanged.connect(self._toggle)
        self.layout.addWidget(self.checkbox)

        # Simple flat switch appearance
        self.checkbox.setStyleSheet("""
            QCheckBox::indicator { width: 50px; height: 20px; }
            QCheckBox::indicator:unchecked { background-color: #bbb; border-radius: 10px; }
            QCheckBox::indicator:checked { background-color: #4CAF50; border-radius: 10px; }
        """)

        self.init_publisher()

    def _toggle(self, state):
        checked = self.checkbox.isChecked()
        self.current_state = self.state_on if checked else self.state_off
        self.checkbox.setText(self.text_on if checked else self.text_off)
        self._publish_state()

class ThreeStateButtonWidget(BasePublishingButtonWidget):
    """
    A 3-position selector that publishes one of three discrete states.
    Uses topic::field syntax only.
    """

    def init_ui(self):
        self.require_communicator()

        cfg = self.cfg

        self.states = cfg.get("states", [-1.0, 0.0, 1.0])
        self.labels = cfg.get("labels", ["DOWN", "MID", "UP"])

        self.index = 0
        self.current_state = self.states[self.index]

        h = QHBoxLayout()
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(4)

        self.button_group = QButtonGroup(self)
        self.button_group.setExclusive(True)
        self.buttons = []

        for i, label in enumerate(self.labels):
            btn = QPushButton(label)
            btn.setCheckable(True)
            btn.setChecked(i == self.index)
            btn.setFixedHeight(28)
            self.button_group.addButton(btn, i)
            self.buttons.append(btn)
            h.addWidget(btn)

        self.layout.addLayout(h)

        # Qt6 preferred signal
        try:
            self.button_group.idClicked.connect(self._state_selected)
        except AttributeError:
            self.button_group.buttonClicked.connect(self._state_selected_button)

        self.init_publisher()
        self._update_button_styles()

    def _state_selected(self, index: int):
        self.index = index
        self.current_state = self.states[self.index]
        QTimer.singleShot(0, self._update_button_styles)
        self._publish_state()

    def _state_selected_button(self, button):
        index = self.button_group.id(button)
        self.index = index
        self.current_state = self.states[self.index]
        QTimer.singleShot(0, self._update_button_styles)
        self._publish_state()

    def _update_button_styles(self):
        """Highlight the active button."""
        for btn in self.buttons:
            if btn.isChecked():
                btn.setStyleSheet("background-color: #4CAF50; color: white; font-weight: bold;")
            else:
                btn.setStyleSheet("background-color: none; color: black; font-weight: normal;")
            btn.style().unpolish(btn)
            btn.style().polish(btn)
            btn.update()
