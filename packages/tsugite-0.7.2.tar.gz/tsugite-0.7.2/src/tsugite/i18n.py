#!/usr/bin/env python3
# This software is distributed under the terms of the MIT License.
# Copyright (c) 2025 Dmitry Ponomarev.
# Author: Dmitry Ponomarev <ponomarevda96@gmail.com>
import os
from pathlib import Path
import logging

import yaml

logger = logging.getLogger(__name__)


class Translator:
    def __init__(self, lang: str, base_dir: str):
        self.lang = lang
        self._catalog = {}
        self._load(base_dir)

    def _load_yaml(self, path: Path) -> dict:
        if not path.exists():
            logger.warning("i18n: file not found: %s", path)
            return {}
        with path.open("r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
        return data

    def _load(self, base_dir: str):
        base_dir = Path(base_dir)

        # 1) English as base
        base = self._load_yaml(base_dir / "strings.en.yaml")

        # 2) Overlay selected language if not English
        if self.lang != "en":
            overlay = self._load_yaml(base_dir / f"strings.{self.lang}.yaml")
            self._deep_update(base, overlay)

        self._catalog = base

    def _deep_update(self, dst: dict, src: dict):
        for k, v in src.items():
            if isinstance(v, dict) and isinstance(dst.get(k), dict):
                self._deep_update(dst[k], v)
            else:
                dst[k] = v

    def tr(self, key: str, **kwargs) -> str:
        """
        key: dot-separated path, e.g. "firmware.update.title"
        kwargs: optional .format() arguments
        """
        node = self._catalog
        for part in key.split("."):
            if not isinstance(node, dict):
                node = None
                break
            node = node.get(part)

        if node is None:
            # fallback: show key itself
            text = key
        else:
            text = str(node)

        if kwargs:
            try:
                text = text.format(**kwargs)
            except (KeyError, IndexError, ValueError) as e:
                logger.warning("i18n format failed for key %s: %s", key, e)
        return text


# simple global instance (for now)
_lang = os.getenv("TSUGITE_LANG", "en")  # or from your config
_base_dir = os.path.join(os.path.dirname(__file__), "translations")  # tsugite/translations/
translator = Translator(_lang, _base_dir)


def tr(key: str, **kwargs) -> str:
    return translator.tr(key, **kwargs)
