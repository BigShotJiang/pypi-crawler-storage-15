#!/usr/bin/env python3
# This software is distributed under the terms of the MIT License.
# Copyright (c) 2025 Dmitry Ponomarev.
# Author: Dmitry Ponomarev <ponomarevda96@gmail.com>
"""
Utils
"""
import os
import re
import socket
import hashlib
import logging
import importlib
import collections.abc
import urllib.request

import yaml

logger = logging.getLogger(__name__)

def resolve_field_path(obj, field_path: str):
    """
    Resolve a nested/indexed field path such as:
      - "timestamp.usec"
      - "accelerometer_integral[0]"
      - "data.vector[2].x"

    Works for both dicts and objects with attributes.
    Returns None if any intermediate attribute is missing.
    """
    if obj is None or not field_path:
        return None

    parts = re.split(r"\.(?![^\[]*\])", field_path)
    cur = obj

    for part in parts:
        if cur is None:
            return None

        # Match 'name[3]'
        m = re.match(r"([A-Za-z0-9_]+)\[(\d+)\]$", part)
        if m:
            attr, idx = m.groups()
            idx = int(idx)
            cur = getattr(cur, attr, None) if not isinstance(cur, dict) else cur.get(attr)

            # handle both lists, tuples, and "array-like" objects
            if isinstance(cur, collections.abc.Sequence) or hasattr(cur, "__getitem__"):
                try:
                    cur = cur[idx]
                except (IndexError, TypeError):
                    return None
            else:
                return None
        else:
            cur = getattr(cur, part, None) if not isinstance(cur, dict) else cur.get(part)

    return cur

def data_type_name_to_obj(dtype: str):
    if not isinstance(dtype, str):
        raise ValueError("Data type must be a string")

    try:
        parts = dtype.split(".")
        module = importlib.import_module(parts[0])
        data_type = module
        for p in parts[1:]:
            data_type = getattr(data_type, p)
    except (ModuleNotFoundError, AttributeError) as e:
        logger.error("Failed to resolve topic '%s': %s", dtype, e)
        return None

    return data_type

def make_field_setter(root, path: str):
    """Returns a lightweight lambda that sets a nested field efficiently."""
    parts = re.split(r'\.(?![^[]*\])', path)  # split on '.' ignoring inside brackets

    # Resolve the object and final attribute/index once
    def resolve_parent():
        target = root
        for part in parts[:-1]:
            match = re.match(r'(\w+)\[(\d+)\]', part)
            if match:
                name, idx = match.groups()
                target = getattr(target, name)[int(idx)]
            else:
                target = getattr(target, part)
        return target, parts[-1]

    # Resolve once, build direct setter to target attr
    target, last = resolve_parent()
    match = re.match(r'(\w+)\[(\d+)\]', last)
    if match:
        name, idx = match.groups()
        seq = getattr(target, name)
        current = seq[int(idx)]
        attr_type = type(current)
        return lambda val, s=seq, i=int(idx), t=attr_type: s.__setitem__(i, t(val))

    current = getattr(target, last, None)
    attr_type = type(current) if current is not None else type
    return lambda val, o=target, a=last, t=attr_type: setattr(o, a, t(val))

# --- cache helpers ----------------------------------------------------
# --- $HOME/.tsugite/cache/icons
# --- icons
# --- firmware YAML (or other YAML configs)
def _cache_subdir(name: str) -> str:
    base = os.path.expanduser("~/.tsugite/cache")
    path = os.path.join(base, name)
    os.makedirs(path, exist_ok=True)
    return path

def _hash_url(url: str) -> str:
    return hashlib.sha256(url.encode("utf-8")).hexdigest()[:16]

def _fetch_cached_file(url: str, subdir: str, default_ext: str) -> str | None:
    cache_dir = _cache_subdir(subdir)
    ext = os.path.splitext(url)[1] or default_ext
    filename = _hash_url(url) + ext
    local_path = os.path.join(cache_dir, filename)

    if os.path.exists(local_path):
        logger.debug("Cache hit (%s): %s", subdir, local_path)
        return local_path

    logger.info("Downloading %s: %s", subdir, url)

    try:
        # Use context manager for urlopen → keeps linter happy
        with urllib.request.urlopen(url, timeout=5) as resp:
            data = resp.read()

        # Use context manager for file → keeps linter happy
        with open(local_path, "wb") as f:
            f.write(data)

        logger.info("Saved to cache (%s): %s", subdir, local_path)
        return local_path

    except (urllib.error.URLError, urllib.error.HTTPError, socket.timeout, OSError) as e:
        logger.warning("Failed to download %s '%s': %s", subdir, url, e)
        return None

def fetch_cached_icon(url: str) -> str | None:
    """Download an icon once and reuse it from ~/.tsugite/cache/icons."""
    return _fetch_cached_file(url, subdir="icons", default_ext=".png")

def fetch_cached_yaml(url: str) -> str | None:
    """
    Download a YAML file once and reuse it from ~/.tsugite/cache/firmware.

    Returns the local path to the cached file, or None on error.
    """
    return _fetch_cached_file(url, subdir="firmware", default_ext=".yaml")
def load_firmware_index(url: str) -> dict:
    if url is None:
        return {}

    path = fetch_cached_yaml(url)
    if not path:
        return {}

    try:
        with open(path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    except (OSError, yaml.YAMLError) as e:
        logger.warning("Failed to parse firmware index '%s': %s", path, e)
        return {}
# --- cache helpers ----------------------------------------------------


class ValueTransformer:
    """Applies numeric scaling (multiplier/offset) and optional type conversion."""
    def __init__(self, cfg: dict):
        self.multiplier = float(cfg["multiplier"]) if "multiplier" in cfg else None
        self.offset = float(cfg.get("offset")) if "offset" in cfg else None
        self.precision = int(cfg.get("precision")) if "precision" in cfg else None

        # field_type: "int", "float", "bool", "auto"
        self.field_type = cfg.get("field_type", "auto")

    def transform(self, original_value):
        """Apply optional multiplier, offset, and type conversion to a value."""
        # Only apply numeric transforms to numeric values
        if not isinstance(original_value, (int, float)):
            return original_value

        transformed_value = original_value

        # Apply linear transform first
        if self.multiplier is not None:
            transformed_value *= self.multiplier
        if self.offset is not None:
            transformed_value += self.offset

        result = transformed_value  # default

        # Explicit conversion
        if self.field_type == "int":
            result = int(transformed_value)
        elif self.field_type == "float":
            result = float(transformed_value)
        elif self.field_type == "bool":
            result = bool(transformed_value != 0)
        elif self.field_type == "auto":
            # AUTO MODE → match original type
            if isinstance(original_value, bool):
                result = transformed_value != 0
            elif isinstance(original_value, int):
                result = int(transformed_value)
            else:  # float or others treated as float
                result = float(transformed_value)

        # Apply rounding if precision is provided
        if self.precision is not None and isinstance(result, float):
            result = round(float(result), int(self.precision))

        return result
