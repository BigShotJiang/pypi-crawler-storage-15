"""
Test suite for RepTree-ML

This test suite provides comprehensive coverage for all components
of the RepTree-ML library including decision trees, pruning, metrics,
and preprocessing functionality.
"""
