celescope fusion mkref \
 --genome_name BCR_ABL1_PML_RARA_all \
 --fasta BCR_ABL1_PML_RARA_all.fasta \
 --fusion_pos BCR_ABL1_PML_RARA_all_pos.txt
