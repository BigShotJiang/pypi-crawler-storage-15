STEPS = [
    "sample",
    "starsolo",
    "analysis",
]
__ASSAY__ = "space"
