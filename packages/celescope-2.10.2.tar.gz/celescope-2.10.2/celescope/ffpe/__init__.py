STEPS = [
    "sample",
    "starsolo",
    "analysis",
    "cells",
]
__ASSAY__ = "ffpe"
REMOVE_FROM_MULTI = {
    "cells",
}
