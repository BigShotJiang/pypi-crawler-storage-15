STEPS = ["sample", "barcode", "mapping_tag", "count_cite", "analysis_cite"]
__ASSAY__ = "citeseq"
