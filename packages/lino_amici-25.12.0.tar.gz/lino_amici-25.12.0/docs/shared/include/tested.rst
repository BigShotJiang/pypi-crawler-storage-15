A tested document
=================

This is a :ref:`tested document <tested_docs>`.  The following instructions are
used for initialization:
