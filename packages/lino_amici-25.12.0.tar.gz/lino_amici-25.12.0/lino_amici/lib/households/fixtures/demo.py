from lino_xl.lib.households.fixtures.demo import objects
