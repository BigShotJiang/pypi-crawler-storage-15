from lino_xl.lib.cal.fixtures.std import objects
