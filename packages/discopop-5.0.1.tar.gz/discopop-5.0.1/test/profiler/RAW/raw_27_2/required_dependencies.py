from typing import List


required_dependencies_list: List[str] = [
    "1:11 RAW 1:10|a",
]
