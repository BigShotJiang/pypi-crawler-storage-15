from typing import List


required_dependencies_list: List[str] = [
    "1:10 RAW 1:4|a",
]
