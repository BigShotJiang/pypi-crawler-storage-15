from typing import List


required_dependencies_list: List[str] = [
    "1:9 RAW 1:8|a",
]
