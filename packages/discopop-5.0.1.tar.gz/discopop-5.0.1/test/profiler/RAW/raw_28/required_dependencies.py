from typing import List


required_dependencies_list: List[str] = [
    "1:4 RAW 1:10|x",
]
