from typing import List


required_dependencies_list: List[str] = [
    "1:5 RAW 1:4|GEPRESULT_arr",
]
