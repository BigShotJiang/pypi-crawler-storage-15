from typing import List


required_dependencies_list: List[str] = [
    "1:8 RAW 1:4|GEPRESULT_arr",
]
