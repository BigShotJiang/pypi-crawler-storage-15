from typing import List


required_dependencies_list: List[str] = [
    "1:7 RAW 1:6|a",
]
