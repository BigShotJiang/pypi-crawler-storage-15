from typing import List


required_dependencies_list: List[str] = [
    "1:12 RAW 1:11|y",
]
