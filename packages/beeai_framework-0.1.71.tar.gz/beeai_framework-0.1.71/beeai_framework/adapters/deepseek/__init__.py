# Copyright 2025 © BeeAI a Series of LF Projects, LLC
# SPDX-License-Identifier: Apache-2.0

from beeai_framework.adapters.deepseek.backend.chat import DeepseekChatModel

__all__ = ["DeepseekChatModel"]
