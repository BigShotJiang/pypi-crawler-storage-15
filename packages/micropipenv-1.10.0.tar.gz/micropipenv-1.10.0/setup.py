"""Setup file for micropipenv python package."""
from setuptools import setup

# See setup.cfg.
setup()
