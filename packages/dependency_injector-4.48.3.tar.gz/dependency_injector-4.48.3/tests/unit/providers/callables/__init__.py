"""Tests for callables."""
