"""Sample code for testing."""
