"""Wiring tests."""
