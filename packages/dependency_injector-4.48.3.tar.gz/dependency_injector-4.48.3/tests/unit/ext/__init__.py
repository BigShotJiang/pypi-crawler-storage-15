"""Extension tests."""
