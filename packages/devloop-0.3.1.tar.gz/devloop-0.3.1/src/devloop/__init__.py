"""DevLoop - Background agents for development workflow automation."""

__version__ = "0.3.1"
