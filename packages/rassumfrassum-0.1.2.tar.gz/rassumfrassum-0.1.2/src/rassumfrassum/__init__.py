"""rassumfrassum - A simple LSP multiplexer that forwards JSONRPC messages."""

__version__ = "0.1.2"
