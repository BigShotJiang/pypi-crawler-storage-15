from gigachat_cli.main import Main

def main():
    app = Main()
    app.run()

if __name__ == "__main__":
    main()
