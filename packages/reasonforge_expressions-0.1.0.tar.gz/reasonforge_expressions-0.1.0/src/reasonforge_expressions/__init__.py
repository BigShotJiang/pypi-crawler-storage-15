"""
ReasonForge Expressions - Essential Symbolic Expression Manipulation

MCP server providing 15 essential tools for symbolic expression manipulation
and basic calculus operations.
"""

__version__ = "0.1.0"
