class ConversionError(Exception):
    pass

