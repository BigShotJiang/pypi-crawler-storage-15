"""Public test for MatplotLibAPI."""
