from .parser import ConfigParser

__all__ = ("ConfigParser",)
