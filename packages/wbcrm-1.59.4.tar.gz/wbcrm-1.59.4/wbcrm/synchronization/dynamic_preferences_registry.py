import wbcrm.synchronization.activity.dynamic_preferences_registry  # noqa
