from tamar_model_client.schemas.inputs.bfl.flux_images import BFLInput, BFLFlux2Input

__all__ = [
    "BFLInput",
    "BFLFlux2Input",
]
