"""Placeholder test to verify pytest setup."""


def test_placeholder():
    """Basic test that always passes."""
    assert True
