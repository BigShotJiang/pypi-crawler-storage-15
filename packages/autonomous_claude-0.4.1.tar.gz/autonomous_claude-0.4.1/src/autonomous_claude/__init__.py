"""Autonomous Claude - Build apps autonomously with Claude Code CLI."""

__version__ = "0.2.0"
