"""MCP Server for City By Api Ninjas"""
