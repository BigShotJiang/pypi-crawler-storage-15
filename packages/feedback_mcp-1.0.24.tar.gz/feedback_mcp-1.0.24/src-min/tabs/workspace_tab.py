"""
工作空间标签页 - 显示工作空间信息
"""
import os
import re
import subprocess
import platform
from typing import Optional
from functools import partial
from PySide6.QtWidgets import QVBoxLayout, QHBoxLayout, QWidget, QPushButton, QLabel, QMessageBox, QGridLayout
from PySide6.QtCore import Qt

try:
    from .base_tab import BaseTab
except ImportError:
    from base_tab import BaseTab

try:
    from ..components.markdown_display import MarkdownDisplayWidget
except ImportError:
    try:
        from components.markdown_display import MarkdownDisplayWidget
    except ImportError:
        from PySide6.QtWidgets import QTextEdit
        MarkdownDisplayWidget = QTextEdit

try:
    from ..workspace_manager import WorkspaceManager
except ImportError:
    try:
        from workspace_manager import WorkspaceManager
    except ImportError:
        WorkspaceManager = None


class WorkspaceTab(BaseTab):
    """工作空间标签页 - 显示工作空间详细信息"""

    def __init__(self, workspace_id: str, project_path: Optional[str] = None, parent=None):
        super().__init__(parent)
        self.workspace_id = workspace_id
        self.project_path = project_path
        self.workspace_config = None
        self.stage_template = None

        # 加载工作空间配置
        self._load_workspace_config()

        # 创建UI
        self.create_ui()

    def _load_workspace_config(self):
        """加载工作空间配置"""
        if not WorkspaceManager:
            return

        try:
            manager = WorkspaceManager(self.project_path)
            self.workspace_config = manager.load_workspace_config(self.workspace_id)

            # 加载阶段模板
            if self.workspace_config:
                stage_template_id = self.workspace_config.get('stage_template_id')
                if stage_template_id:
                    self.stage_template = manager.load_stage_template(stage_template_id)
        except Exception:
            # 静默处理加载失败
            self.workspace_config = None
            self.stage_template = None

    def create_ui(self):
        """创建工作空间标签页UI"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)

        # 使用 MarkdownDisplayWidget 显示工作空间基本信息
        display_widget = MarkdownDisplayWidget()

        # 格式化工作空间信息为Markdown
        markdown_content = self._format_workspace_info()
        display_widget.setMarkdownText(markdown_content)

        layout.addWidget(display_widget)

        # 添加文件列表区域（如果有文件）
        files = self.workspace_config.get('files', []) if self.workspace_config else []
        if files:
            self._create_files_section(layout, files)

    def _format_workspace_info(self) -> str:
        """格式化工作空间信息为Markdown文本

        Returns:
            str: 格式化的Markdown文本
        """
        if not self.workspace_config:
            return "## ⚠️ 无法加载工作空间配置\n\n请检查工作空间ID是否正确。"

        parts = []

        # 1. 工作空间基本信息
        parts.append("## 📦 工作空间信息")
        parts.append("")
        parts.append(f"**ID:** `{self.workspace_id}`")

        goal = self.workspace_config.get('goal', '未设置')
        parts.append(f"**目标:** {goal}")

        status = self.workspace_config.get('status', '未知')
        parts.append(f"**状态:** {status}")

        created_at = self.workspace_config.get('created_at', '未知')
        parts.append(f"**创建时间:** {created_at}")

        updated_at = self.workspace_config.get('updated_at', '未知')
        parts.append(f"**更新时间:** {updated_at}")

        parts.append("")

        # 2. 阶段信息
        parts.append("## 📍 阶段信息")
        parts.append("")

        stage_template_id = self.workspace_config.get('stage_template_id', '未设置')
        parts.append(f"**模板:** `{stage_template_id}`")

        current_stage_id = self.workspace_config.get('current_stage_id', '未设置')
        parts.append(f"**当前阶段:** `{current_stage_id}`")

        # 显示当前阶段详细信息
        if self.stage_template and current_stage_id:
            workflow = self.stage_template.get('workflow', {})
            steps = workflow.get('steps', [])

            for step in steps:
                if step.get('id') == current_stage_id:
                    parts.append("")
                    parts.append(f"**阶段标题:** {step.get('title', '未知')}")
                    parts.append(f"**阶段描述:** {step.get('des', '无描述')}")
                    break

        parts.append("")

        # 3. 相关文档列表
        documents = self.workspace_config.get('documents', [])
        if documents:
            parts.append("## 📄 相关文档")
            parts.append("")
            for doc in documents:
                if isinstance(doc, dict):
                    title = doc.get('title', '未命名文档')
                    path = doc.get('path', '')
                    parts.append(f"- **{title}** (`{path}`)")
                else:
                    parts.append(f"- `{doc}`")
            parts.append("")

        # 注意：相关文件列表改为独立组件显示，不再在Markdown中显示

        return "\n".join(parts)

    def _create_files_section(self, layout, files: list):
        """创建文件列表显示区域

        Args:
            layout: 父布局
            files: 文件路径列表
        """
        # 导入配置管理
        try:
            from feedback_config import FeedbackConfig
        except ImportError:
            FeedbackConfig = None

        # 获取配置的IDE
        def get_configured_ide():
            """获取配置的IDE名称，优先级：配置文件 > 环境变量 > 默认值"""
            ide_name = None

            # 1. 尝试从配置文件读取
            if FeedbackConfig and self.project_path:
                try:
                    config_manager = FeedbackConfig(self.project_path)
                    ide_name = config_manager.get_ide()
                except Exception:
                    pass

            # 2. 如果配置文件没有，使用环境变量
            if not ide_name:
                ide_name = os.getenv('IDE')

            # 3. 最后使用默认值
            if not ide_name:
                ide_name = 'cursor'

            return ide_name

        # 文件去重并保持顺序
        unique_files = list(dict.fromkeys(files))

        # 路径规范化（移除tag前缀 + 相对路径转绝对路径）
        normalized_files = []
        for file_path in unique_files:
            # 移除路径开头的tag（如 Edit:, Create:, Read: 等）
            cleaned_path = re.sub(r'^[A-Za-z]+:', '', file_path)

            if not os.path.isabs(cleaned_path) and self.project_path:
                # 相对路径转绝对路径
                abs_path = os.path.join(self.project_path, cleaned_path)
                normalized_files.append(abs_path)
            else:
                normalized_files.append(cleaned_path)

        # 创建文件列表标题
        title_container = QWidget()
        title_layout = QHBoxLayout(title_container)
        title_layout.setContentsMargins(5, 10, 5, 5)
        title_layout.setSpacing(5)

        title_label = QLabel("📁 相关文件")
        title_label.setStyleSheet("""
            QLabel {
                font-size: 14px;
                font-weight: bold;
                color: #FFA500;
                padding: 5px 0;
            }
        """)
        title_layout.addWidget(title_label)
        title_layout.addStretch()

        layout.addWidget(title_container)

        # 创建文件列表容器（使用网格布局实现自动换行）
        files_container = QWidget()
        # 移除高度限制，让容器根据内容自动调整高度
        files_container_layout = QGridLayout(files_container)
        files_container_layout.setContentsMargins(5, 5, 5, 5)
        files_container_layout.setSpacing(10)

        # 每行显示的按钮数量
        columns = 3

        # 为每个文件创建紧凑的可点击标签
        for i, file_path in enumerate(normalized_files):
            row = i // columns
            col = i % columns

            file_name = os.path.basename(file_path)
            # 如果文件名太长，截断显示
            display_name = file_name if len(file_name) <= 20 else file_name[:17] + "..."

            file_btn = QPushButton(display_name)
            # 获取IDE名称（使用配置）
            ide_name = get_configured_ide()
            # IDE显示名称映射
            ide_display_names = {
                'cursor': 'Cursor',
                'kiro': 'Kiro',
                'vscode': 'VSCode',
                'code': 'VSCode'
            }
            display_ide = ide_display_names.get(ide_name.lower(), ide_name)
            file_btn.setToolTip(f"点击在{display_ide}中打开: {file_path}")
            file_btn.setCursor(Qt.PointingHandCursor)  # 设置手形光标
            file_btn.setStyleSheet("""
                QPushButton {
                    background-color: rgba(76, 175, 80, 20);
                    color: #4CAF50;
                    border: 1px solid rgba(76, 175, 80, 40);
                    padding: 3px 8px;
                    border-radius: 3px;
                    font-size: 11px;
                    font-weight: 500;
                }
                QPushButton:hover {
                    background-color: rgba(76, 175, 80, 40);
                    border: 1px solid #4CAF50;
                }
                QPushButton:pressed {
                    background-color: rgba(76, 175, 80, 60);
                }
            """)

            # 使用partial函数绑定参数，避免闭包问题
            def open_with_ide(file_path):
                try:
                    # 导入ide_utils模块
                    import sys
                    parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
                    if parent_dir not in sys.path:
                        sys.path.insert(0, parent_dir)
                    from ide_utils import open_project_with_ide

                    # 获取IDE名称（使用配置）
                    ide_name = get_configured_ide()

                    # 使用通用的IDE打开函数
                    success = open_project_with_ide(file_path, ide_name)

                    if not success:
                        # 如果失败，使用系统默认编辑器打开
                        if platform.system() == "Darwin":
                            subprocess.run(["open", file_path], check=True)
                        elif platform.system() == "Windows":
                            os.startfile(file_path)
                        else:
                            subprocess.run(["xdg-open", file_path], check=True)

                except Exception as e:
                    # 使用系统默认编辑器打开作为最终后备
                    try:
                        if platform.system() == "Darwin":
                            subprocess.run(["open", file_path], check=True)
                        elif platform.system() == "Windows":
                            os.startfile(file_path)
                        else:
                            subprocess.run(["xdg-open", file_path], check=True)
                    except Exception as e2:
                        QMessageBox.warning(self, "打开失败",
                            f"无法打开文件: {file_name}\n"
                            f"路径: {file_path}\n"
                            f"错误: {str(e2)}")

            file_btn.clicked.connect(partial(open_with_ide, file_path))
            files_container_layout.addWidget(file_btn, row, col)

        layout.addWidget(files_container)
