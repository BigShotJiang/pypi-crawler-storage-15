from ftm_lakehouse.api.main import app

__all__ = ["app"]
