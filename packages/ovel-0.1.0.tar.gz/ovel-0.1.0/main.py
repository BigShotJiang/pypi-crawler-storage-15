def main():
    print("Hello from ovel-python!")


if __name__ == "__main__":
    main()
