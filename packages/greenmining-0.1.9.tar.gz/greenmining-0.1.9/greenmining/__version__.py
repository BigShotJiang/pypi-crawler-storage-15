"""Version information for greenmining."""

__version__ = "0.1.7"
