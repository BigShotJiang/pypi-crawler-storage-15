"""Observability interface for Jupyter notebooks."""

from .observability import Observability

__all__ = ["Observability"]
