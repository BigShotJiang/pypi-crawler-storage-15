"""Evaluation client for Python scripts and notebooks."""

from .client import Evaluation

__all__ = ["Evaluation"]
