"""Utils for AgentCore Starter Toolkit CLI."""
