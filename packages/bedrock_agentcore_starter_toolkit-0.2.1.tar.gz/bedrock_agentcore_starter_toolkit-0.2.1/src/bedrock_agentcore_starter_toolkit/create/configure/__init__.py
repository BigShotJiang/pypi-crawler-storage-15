"""Implementation to support running create on a pre-configured project."""
