"""Tests for Policy CLI commands."""
