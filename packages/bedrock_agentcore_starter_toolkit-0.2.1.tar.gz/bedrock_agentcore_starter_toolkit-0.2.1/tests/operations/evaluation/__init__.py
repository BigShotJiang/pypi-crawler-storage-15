"""Tests for evaluation operations."""
