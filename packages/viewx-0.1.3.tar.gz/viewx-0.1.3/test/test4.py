from viewx.datasets import load_dataset
from viewx import Report


df = load_dataset("iris.csv")

report = Report(df, theme="article", filename="iris_report")

report.title("Análisis del Iris Dataset", author="Emmanuel")

report.section("Resumen")
report.text("Este documento contiene un análisis automático del dataset Iris.")

report.section("Tablas")
report.table(columns="all")

report.section("Gráficas")
report.plot(x="sepal_length", y="sepal_width", kind="scatter", title="Relación entre sépalos")
report.plot(x="species", y="petal_length", kind="bar", title="Longitud de pétalo por especie")

report.build()
