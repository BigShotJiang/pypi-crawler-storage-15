from viewx import DashBoard, HTML
from viewx.datasets import load_dataset
import pandas as pd

df = load_dataset("iris.csv")

page = HTML(data=df, title="Dataset Iris")

page.add_title("Reporte Automático")
page.add_table()
page.add_plot(kind="scatter", x=df["petal_length"], y=df["petal_width"])

page.export("reporte.html")