# ============================================================
#                     EJEMPLO DE USO COMPLETO
# ============================================================

if __name__ == "__main__":
    from viewx.datasets import load_dataset
    from viewx import HTML


    df = load_dataset("iris.csv")

    # HTML(df, "Reporte Demo", template=1) \
    #     .add_valuebox("Filas", df.shape[0], icon="📁", color="#3C8DAD", slot="div1") \
    #     .add_valuebox("Columnas", df.shape[1], icon="📐", color="#4C6EF5", slot="div2") \
    #     .add_text(slot="div3")\
    #     .add_text(slot="div4")\
    #     .add_plot(x="sepal_length", y="sepal_width", kind="scatter",
    #             title="Relación de medidas", slot="div5") \
    #     .add_plot(x="species", y="petal_length", kind="box",
    #             title="Distribución por especie", slot="div6") \
    #     .add_text(slot="div7")\
    #     .add_text(slot="div8")\
    #     .add_text(slot="div9")\
    #     .add_table(columns="all", slot="div10", number_table=1) \
    #     .add_plot(x="petal_length", kind="hist", slot="div11") \
    #     .add_text("Este es un texto de prueba colocado en div12.", slot="div12") \
    #     .show("demo_report.html", port=8000)

    css_parent = """.parent {
display: grid;
grid-template-columns: repeat(8, 1fr);
grid-template-rows: repeat(8, 1fr);
grid-column-gap: 0px;
grid-row-gap: 0px;
}"""
    css_div = """
.div1 { grid-area: 1 / 1 / 3 / 3; }
.div2 { grid-area: 1 / 3 / 3 / 5; }
.div3 { grid-area: 1 / 5 / 3 / 7; }
.div4 { grid-area: 1 / 7 / 3 / 9; }
.div5 { grid-area: 3 / 1 / 7 / 3; }
.div6 { grid-area: 3 / 3 / 7 / 7; }
.div7 { grid-area: 3 / 7 / 7 / 9; }
.div8 { grid-area: 7 / 1 / 9 / 4; }
.div9 { grid-area: 7 / 4 / 9 / 6; }
.div10 { grid-area: 7 / 6 / 9 / 9; }
"""

    HTML(df, "Reporte Demo", template=0, css_parent=css_parent, css_divs=css_div, num_divs=10) \
        .add_valuebox("Filas", df.shape[0], icon="📁", color="#3C8DAD", slot="div1") \
        .add_valuebox("Columnas", df.shape[1], icon="📐", color="#4C6EF5", slot="div2") \
        .add_valuebox("Columnas", df.shape[1], icon="📐", color="#4C6EF5", slot="div3") \
        .add_valuebox("Columnas", df.shape[1], icon="📐", color="#4C6EF5", slot="div4") \
        .add_valuebox("Columnas", df.shape[1], icon="📐", color="#4C6EF5", slot="div5") \
        .add_valuebox("Columnas", df.shape[1], icon="📐", color="#4C6EF5", slot="div6") \
        .add_valuebox("Columnas", df.shape[1], icon="📐", color="#4C6EF5", slot="div7") \
        .add_valuebox("Columnas", df.shape[1], icon="📐", color="#4C6EF5", slot="div8") \
        .add_valuebox("Columnas", df.shape[1], icon="📐", color="#4C6EF5", slot="div9") \
        .add_valuebox("Columnas", df.shape[1], icon="📐", color="#4C6EF5", slot="div10") \
        .show("demo_report2.html", port=8001)

# HTML(df, "Test", css_parent=css_parent, css_divs=css_div, num_divs=1, template=0)\
#     .add_plot(x="sepal_length", y="sepal_width", kind="scatter", slot="div1")\
#     .show("test.html", port=8000)

