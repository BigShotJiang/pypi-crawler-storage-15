from viewx import Report


# =============================================================================
# EJEMPLO DE USO (si se ejecuta directamente)
# =============================================================================
if __name__ == "__main__":
    # Solo se ejecuta si el archivo se corre directamente
    try:
        from viewx.datasets import load_dataset
        import seaborn as sns
    except ImportError:
        print("[ViewX] No se pudo importar viewx.datasets, usando datos de ejemplo...")
        # Crear datos de ejemplo
        import pandas as pd
        import numpy as np
        np.random.seed(42)
        df = pd.DataFrame({
            'sepal_length': np.random.randn(150) * 0.8 + 5.8,
            'sepal_width': np.random.randn(150) * 0.3 + 3.0,
            'petal_length': np.random.randn(150) * 1.7 + 3.8,
            'petal_width': np.random.randn(150) * 0.8 + 1.2,
            'species': np.random.choice(['setosa', 'versicolor', 'virginica'], 150)
        })
    else:
        # Cargar datos de ejemplo
        try:
            df = load_dataset("iris.csv")
        except:
            # Datos de ejemplo si no se puede cargar el dataset
            import pandas as pd
            import numpy as np
            np.random.seed(42)
            df = pd.DataFrame({
                'sepal_length': np.random.randn(150) * 0.8 + 5.8,
                'sepal_width': np.random.randn(150) * 0.3 + 3.0,
                'petal_length': np.random.randn(150) * 1.7 + 3.8,
                'petal_width': np.random.randn(150) * 0.8 + 1.2,
                'species': np.random.choice(['setosa', 'versicolor', 'virginica'], 150)
            })
    
    import matplotlib.pyplot as plt
    
    # Crear reporte
    r = Report(df, theme="article", auto_install=False, outdir="output")
    
    # Título y metadatos
    r.title("Análisis del Dataset Iris", 
            author="ViewX Report System", 
            date="\\today")
    
    # Resumen
    r.add_section("Resumen")
    r.add_text("Este reporte fue generado automáticamente con ViewX + LaTeX. "
               "Contiene análisis exploratorio del famoso dataset Iris.")
    
    # Gráfico
    r.add_section("Análisis Exploratorio")
    r.add_subsection("Gráfico de dispersión")
    plt.figure(figsize=(6, 4))
    sns.scatterplot(data=df, x="sepal_length", y="sepal_width", hue="species")
    plt.title("Relación entre largo y ancho del sépalo")
    plt.xlabel("Longitud del sépalo (cm)")
    plt.ylabel("Ancho del sépalo (cm)")
    r.add_plot_matplotlib(caption="Distribución de especies según medidas del sépalo.")
    
    # Tabla de estadísticas
    r.add_subsection("Estadísticas descriptivas")
    stats_df = df.describe()
    # Ahora pasamos el DataFrame directamente
    r.add_table(df=stats_df, caption="Estadísticas descriptivas del dataset", label="stats")
    
    # También podemos mostrar una tabla del DataFrame original
    r.add_subsection("Muestra de datos")
    r.add_table(columns=["species", "sepal_length", "sepal_width"], 
                caption="Primeras 10 filas del dataset", 
                label="sample")
    
    # Código de ejemplo
    r.add_section("Implementación")
    r.add_text("A continuación se muestra un ejemplo de código para generar este análisis:")
    
    code_example = """# Ejemplo de análisis con ViewX
import pandas as pd
from viewx import Report

# Cargar datos
df = pd.read_csv("iris.csv")

# Crear reporte
r = Report(df)
r.title("Mi Análisis")

# Agregar gráficos y tablas
r.add_section("Resultados")
# ... más código aquí

# Generar PDF
r.build("mi_reporte")"""
    
    r.add_code(code_example, language="python", caption="Ejemplo de uso de ViewX")
    
    # Ecuación
    r.add_section("Modelo Matemático")
    r.add_text("Para la regresión lineal utilizada en el análisis:")
    r.add_equation(r"y = \beta_0 + \beta_1 x + \epsilon", label="eq:regression")
    
    # Exportar PDF
    r.build("reporte_iris_ejemplo", clean_tex=True, ensure_dependencies=False)
    
    print("\n[ViewX] Proceso completado. Revisa la carpeta 'output' para ver los resultados.")