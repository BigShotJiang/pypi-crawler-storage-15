import os
import json
import pandas as pd
import plotly.express as px
from http.server import HTTPServer, SimpleHTTPRequestHandler
import threading
import webbrowser

# ============================================================
#                         ViewX PRO
# ============================================================

class HTML:
    def __init__(self, data=None, title="ViewX Report", 
                template: int = 0, css_parent: str = None, css_divs: str = None, num_divs: int = 1):
        """
        Para usar css_parent y css_divs, debe estra template=0, para luego generar los codigos en: https://cssgrid-generator.netlify.app/
        """
        self.data = data
        self.title = title
        self.css_parent = css_parent
        self.css_divs = css_divs
        self.num_divs = num_divs
        if template < 0:
            self.template = 0
        else:
            self.template = template
        self.slots = {f"div{i}": [] for i in range(1, self.num_divs + 1)}  # div1 ... div12

    # ========================================================
    #               REGISTRO DE BLOQUES EN DIVS
    # ========================================================
    def _add_to_slot(self, html, slot):
        if slot not in self.slots:
            raise ValueError(f"El slot '{slot}' no existe en la plantilla.")
        self.slots[slot].append(html)

    # ========================================================
    #                     VALUEBOX
    # ========================================================
    def add_valuebox(
            self,
            title,
            value,
            icon="📊",
            color="#4C6EF5",
            slot="div5",
            position_icon="left"  # left o right
        ):

        # Layout dinámico según posición del icono
        if position_icon == "right":
            direction = "row-reverse"
        else:
            direction = "row"

        box = f"""
        <div style="
            background:{color};
            padding:20px;
            border-radius:15px;
            color:white;
            font-family:Arial;
            box-shadow: 0 3px 10px rgba(0,0,0,0.15);
            margin-bottom:10px;
            width:100%; height:100%;
            box-sizing:border-box;

            display:flex;
            flex-direction:{direction};
            align-items:center;
            gap:15px;
        ">
            
            <!-- ICONO -->
            <div style="
                font-size:50px;
                display:flex;
                align-items:center;
                justify-content:center;
                min-width:100px;
            ">{icon}</div>

            <!-- TEXTO -->
            <div style="display:flex; flex-direction:column;">
                <div style="font-size:30px;font-weight:bold; justify-content: right; align-items: right">{value}</div>
                <div style="opacity:0.85; font-size:20px; justify-content: right; align-items: right">{title}</div>
            </div>
        </div>
        """
        self._add_to_slot(box, slot)
        return self



    # ========================================================
    #                       GRÁFICOS
    # ========================================================
    def add_plot(self, x, y=None, z=None, kind="scatter", title="", slot="div1"):
        if self.data is None:
            raise ValueError("No hay datos cargados")

        import plotly.express as px

        match kind:
            case "scatter":
                fig = px.scatter(self.data, x=x, y=y, title=title)
            case "line":
                fig = px.line(self.data, x=x, y=y, title=title)
            case "bar":
                fig = px.bar(self.data, x=x, y=y, title=title)
            case "hist":
                fig = px.histogram(self.data, x=x, title=title)
            case "box":
                fig = px.box(self.data, x=x, y=y, title=title)
            case "pie":
                fig = px.pie(self.data, names=x, values=y, title=title)
            case "sunburst":
                fig = px.sunburst(self.data, path=[x, y], values=y, title=title)
            case "treemap":
                fig = px.treemap(self.data, path=[x, y], values=y, title=title)
            case "scatter_3d":
                fig = px.scatter_3d(self.data, x=x, y=y, z=z, title=title)
            case _:
                raise ValueError(f"Tipo '{kind}' no soportado")

        html_plot = fig.to_html(full_html=False, include_plotlyjs="cdn")
        self._add_to_slot(html_plot, slot)
        return self

    # ========================================================
    #                        TABLAS
    # ========================================================
    
    def add_table(self, columns=None, slot="div1", number_table: int = 1):
        if self.data is None:
            raise ValueError("No hay datos cargados")

        # --- Columnas ---
        if columns is None or columns == "all":
            df = self.data
        else:
            if isinstance(columns, str):
                columns = [columns]

            missing = [c for c in columns if c not in self.data.columns]
            if missing:
                raise ValueError(f"Columnas no encontradas: {missing}")

            df = self.data[columns]

        # --- Render ---
        html_table = df.to_html(classes=f"table{number_table}", border=0)

        box = f"""
        <div style="overflow-y:auto;
            border:1px solid #ddd; padding:10px; border-radius:12px;
            width:100%; height:100%; box-sizing:border-box;">
            {html_table}
        </div>
        """

        self._add_to_slot(box, slot)
        return self

    
    # ========================================================
    #                        TEXTO
    # ========================================================

    def add_text(self, content: str = "Default Text", slot="div1"):
        box = f"""
        <div style="overflow-y:auto;
            border:1px solid #ddd; padding:10px; border-radius:12px; width:100%; height:100%; box-sizing:border-box;">
            {content}
        </div>
        """
        self._add_to_slot(box, slot)
        return self


    # ========================================================
    #                 RENDERIZAR CADA DIV
    # ========================================================
    def _render_slot(self, slot):
        return "\n".join(self.slots[slot])

    # ========================================================
    #                        EXPORT
    # ========================================================
    def export(self, filename="report.html"):
        template = self.template
        css_parent = self.css_parent   # contiene .parent {...}
        css_divs = self.css_divs       # contiene .div1 {...} .div2 {...}
        num_divs = self.num_divs

        match template:
            case 0:
                html_template = f"""
<html>
    <head>
        <meta charset="UTF-8">
        <title>{self.title}</title>

        <style>
            html, body {{
                height: 100%;
                margin: 0;
                padding: 0;
            }}


            /* Estilos base del contenedor */
            .parent {{
                width:100%;
                height:100%;
                box-sizing:border-box;
            }}

            /* Layout personalizado */
            {css_parent}

            /* Áreas de grid */
            {css_divs}

            table {{
                border-collapse: collapse;
                width: 100%;
                font-family: Arial, sans-serif;
                font-size: 13px;
            }}

            th, td {{
                border: 1px solid #ccc;
                padding: 6px 8px;
                text-align: left;
            }}

            th {{
                background: #f4f4f4;
                font-weight: bold;
            }}

            tbody tr:nth-child(odd) {{
                background: #fafafa;
            }}

        </style>
    </head>

    <body>
        <div class="parent">
            {"".join(
                f'<div class="div{i}">{self._render_slot(f"div{i}")}</div>'
                for i in range(1, self.num_divs + 1)
            )}
        </div>
    </body>
</html>
"""

            case 1: 
                html_template = f"""
<html>
    <head>
        <meta charset="UTF-8">
        <title>{self.title}</title>
        <style>
            .parent {{
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            grid-template-rows: repeat(7, 1fr);
            grid-column-gap: 0px;
            grid-row-gap: 0px;
            width:100%; height:100%; box-sizing:border-box;}}

            table {{
                border-collapse: collapse;
                width: 100%;
                font-family: Arial, sans-serif;
                font-size: 13px;
            }}

            th, td {{
                border: 1px solid #ccc;
                padding: 6px 8px;
                text-align: left;
            }}

            th {{
                background: #f4f4f4;
                font-weight: bold;
            }}

            tbody tr:nth-child(odd) {{
                background: #fafafa;
            }}

            .div1 {{ grid-area: 1 / 1 / 2 / 2; }}
            .div2 {{ grid-area: 1 / 2 / 2 / 3; }}
            .div3 {{ grid-area: 1 / 3 / 2 / 4; }}
            .div4 {{ grid-area: 1 / 4 / 2 / 5; }}
            .div5 {{ grid-area: 2 / 1 / 5 / 3; }}
            .div6 {{ grid-area: 2 / 3 / 5 / 5; }}
            .div7 {{ grid-area: 5 / 1 / 6 / 2; }}
            .div8 {{ grid-area: 6 / 1 / 7 / 2; }}
            .div9 {{ grid-area: 7 / 1 / 8 / 2; }}
            .div10 {{ grid-area: 5 / 2 / 8 / 4; }}
            .div11 {{ grid-area: 5 / 4 / 7 / 5; }}
            .div12 {{ grid-area: 7 / 4 / 8 / 5; }}
        </style>
    </head>

    <body>
        <div class="parent">
            <div class="div1">{self._render_slot("div1")}</div>
            <div class="div2">{self._render_slot("div2")}</div>
            <div class="div3">{self._render_slot("div3")}</div>
            <div class="div4">{self._render_slot("div4")}</div>
            <div class="div5">{self._render_slot("div5")}</div>
            <div class="div6">{self._render_slot("div6")}</div>
            <div class="div7">{self._render_slot("div7")}</div>
            <div class="div8">{self._render_slot("div8")}</div>
            <div class="div9">{self._render_slot("div9")}</div>
            <div class="div10">{self._render_slot("div10")}</div>
            <div class="div11">{self._render_slot("div11")}</div>
            <div class="div12">{self._render_slot("div12")}</div>
        </div>
    </body>
</html>
"""
        with open(filename, "w", encoding="utf-8") as f:
            f.write(html_template)

        return filename



    # ========================================================
    #                        SERVIDOR LOCAL
    # ========================================================

    def show(self, filename="report.html", port=8000):
        path = os.path.abspath(filename)
        self.export(filename)

        directory = os.path.dirname(path)

        class CustomHandler(SimpleHTTPRequestHandler):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, directory=directory, **kwargs)

        def run_server():
            server = HTTPServer(("localhost", port), CustomHandler)
            print(f"Servidor activo en http://localhost:{port}")
            server.serve_forever()

        # Servidor NO daemon para que no muera al instante
        thread = threading.Thread(target=run_server, daemon=False)
        thread.start()

        # Abrir navegador
        webbrowser.open(f"http://localhost:{port}/{os.path.basename(filename)}")

        # Mantener vivo el hilo principal
        try:
            thread.join()
        except KeyboardInterrupt:
            print("Servidor detenido.")
