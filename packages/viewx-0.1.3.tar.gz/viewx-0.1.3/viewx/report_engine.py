import os
import subprocess
import shutil
from pylatex import Document, Section, Subsection, Command
from pylatex import Table, Tabular, NoEscape
import pandas as pd
from pylatex.utils import NoEscape
import platform
import matplotlib.pyplot as plt
import uuid
from pylatex import Figure, NoEscape

class Report:
    def __init__(self, df=None, theme="article", auto_install=True, outdir="output"):
        self.df = df
        self.theme = theme
        self.auto_install = auto_install
        self.outdir = outdir

        # Crear carpeta si no existe
        os.makedirs(self.outdir, exist_ok=True)

        self.doc = Document(theme)
        
        # Configuraciones por defecto
        self._setup_preamble()

    # ----------------------------------------------------------------------
    #  CONFIGURACIÓN PRELIMINAR
    # ----------------------------------------------------------------------
    def _setup_preamble(self):
        """Configura paquetes y estilos en el preámbulo."""
        # Paquetes necesarios
        packages = [
            "geometry",
            "graphicx",
            "xcolor",
            "float",
            "caption",
            "listings",
            "tcolorbox",
            "wrapfig",
            "titlesec",
            "tocloft",
            "amsmath",
            "booktabs",
            "array",
            "multicol"
        ]
        
        for pkg in packages:
            self.doc.packages.append(Command("usepackage", pkg))
        
        # Configuración de listings para código
        self.doc.preamble.append(NoEscape(r"""
\lstset{
    frame=single,
    breaklines=true,
    postbreak=\mbox{\textcolor{red}{$\hookrightarrow$}\space},
    basicstyle=\ttfamily\small,
    keywordstyle=\color{blue},
    commentstyle=\color{green!60!black},
    stringstyle=\color{orange}
}
        """))

    # ----------------------------------------------------------------------
    #  VERIFICACIÓN DE DEPENDENCIAS
    # ----------------------------------------------------------------------
    def _command_exists(self, cmd):
        """Return True if command exists in PATH."""
        return shutil.which(cmd) is not None

    def ensure_latex_pkg(self, pkg):
        os_name = platform.system().lower()

        # --- Windows: MikTeX uses mpm ---
        if os_name == "windows":
            if self._command_exists("mpm"):
                print(f"[ViewX] Checking MikTeX package: {pkg}")
                subprocess.run(["mpm", "--install", pkg], check=False)
            else:
                print(f"[ViewX] WARNING: MikTeX 'mpm' not found. "
                    f"No automatic install for package: {pkg}")
            return

        # --- Unix/macOS: TeXLive uses tlmgr ---
        if self._command_exists("tlmgr"):
            print(f"[ViewX] Checking TeXLive package: {pkg}")
            subprocess.run(["tlmgr", "install", pkg], check=False)
            return

        # --- Nothing available ---
        print(f"[ViewX] WARNING: No TeX package manager found. "
            f"Skipping install for: {pkg}")

    def ensure_dependencies(self):
        required = [
            "pgf", "pgfplots", "xcolor", "graphicx", "float",
            "caption", "listings", "fancyhdr", "tcolorbox",
            "wrapfig", "titlesec", "tocloft", "geometry",
            "amsmath", "booktabs", "array", "multicol"
        ]

        print("[ViewX] Verificando paquetes LaTeX requeridos...")

        for pkg in required:
            self.ensure_latex_pkg(pkg)

    # ----------------------------------------------------------------------
    #  FUNCIONES DE CREACIÓN DEL DOCUMENTO
    # ----------------------------------------------------------------------
    def title(self, title="Reporte", author="", date=None):
        """Agrega título al documento."""
        self.doc.preamble.append(Command("title", title))
        self.doc.preamble.append(Command("author", author))
        if date is None:
            self.doc.preamble.append(Command("date", NoEscape(r"\\today")))
        else:
            self.doc.preamble.append(Command("date", date))
        
        self.doc.append(NoEscape(r"\maketitle"))

    def add_section(self, title, columns=1):
        """Agrega una sección al documento."""
        if columns == 1:
            self.doc.append(Section(title))
        else:
            self.doc.append(NoEscape(r"\begin{multicols}{" + str(columns) + "}"))
            self.doc.append(Section(title))
            self.doc.append(NoEscape(r"\end{multicols}"))

    def add_subsection(self, title):
        """Agrega una subsección."""
        self.doc.append(Subsection(title))

    def add_text(self, txt):
        """Agrega texto normal."""
        self.doc.append(txt)

    def add_plot_matplotlib(self, fig=None, caption="", width=0.9, position='h!'):
        """
        Inserta una figura de Matplotlib dentro del PDF generado.
        """
        if fig is None:
            fig = plt.gcf()

        # Crear nombre temporal único
        img_name = f"plot_{uuid.uuid4().hex}.png"
        img_path = os.path.join(self.outdir, img_name)

        # Guardar imagen
        fig.savefig(img_path, dpi=300, bbox_inches='tight')

        # Insertarla en LaTeX
        with self.doc.create(Figure(position=position)) as fig_env:
            fig_env.add_image(img_path, width=NoEscape(f"{width}\\linewidth"))
            if caption:
                fig_env.add_caption(caption)

        print(f"[ViewX] Gráfico agregado: {img_path}")

        # Guardar el path para limpiar luego
        if not hasattr(self, "_temp_images"):
            self._temp_images = []
        self._temp_images.append(img_path)

        # Cerrar figura para liberar memoria
        plt.close(fig)
        
        return img_path

    def add_table(self, df=None, columns="all", caption="Tabla", position="h!", label=None, 
                  index=False, escape=False, float_format=None):
        """
        Inserta una tabla de pandas en el reporte LaTeX.
        
        Args:
            df: DataFrame de pandas (si es None, usa self.df)
            columns: "all", lista de columnas, o un DataFrame
            caption: Título de la tabla
            position: Posición en LaTeX (h!, t, b, etc.)
            label: Etiqueta para referencia
            index: Incluir índice
            escape: Escapar caracteres especiales
            float_format: Formato para números flotantes
        """
        # Determinar qué DataFrame usar
        if df is None:
            if self.df is None:
                print("[ViewX] WARNING: No hay DataFrame cargado para add_table().")
                return
            df_to_use = self.df
        else:
            df_to_use = df
        
        # Seleccionar columnas si se especifica
        if isinstance(columns, list):
            df_to_use = df_to_use[columns]
        elif columns != "all" and not isinstance(columns, pd.DataFrame):
            # Si columns no es "all", una lista, o un DataFrame, asumimos que es un string
            df_to_use = df_to_use[[columns]]
        
        # Si columns es un DataFrame, usarlo directamente
        if isinstance(columns, pd.DataFrame):
            df_to_use = columns
        
        # Crear etiqueta para LaTeX
        latex_label = f"tab:{label}" if label else None
        
        # Configurar formato para números
        if float_format:
            formatters = {col: float_format for col in df_to_use.select_dtypes(include=['float']).columns}
        else:
            formatters = None
        
        # Convertir a LaTeX
        try:
            latex_table = df_to_use.to_latex(
                index=index,
                escape=escape,
                caption=caption,
                label=latex_label,
                position=position,
                formatters=formatters
            )
            
            # Insertar en el documento
            self.doc.append(NoEscape(latex_table))
            print("[ViewX] Tabla agregada correctamente.")
            
        except Exception as e:
            print(f"[ViewX] Error al convertir tabla a LaTeX: {e}")
            # Crear una tabla simple como respaldo
            with self.doc.create(Table(position=position)) as table_env:
                if caption:
                    table_env.add_caption(caption)
                if label:
                    table_env.add_label(f"tab:{label}")
                
                # Crear tabla manualmente
                with table_env.create(Tabular('c' * len(df_to_use.columns))) as tabular:
                    # Encabezados
                    tabular.add_row(df_to_use.columns.tolist())
                    tabular.add_hline()
                    # Datos
                    for _, row in df_to_use.iterrows():
                        tabular.add_row([str(val) for val in row])
            
            print("[ViewX] Tabla agregada (formato simple).")

    def add_code(self, code, language="python", caption=None):
        """
        Inserta un bloque de código formateado usando listings.
        """
        # Usar entorno lstlisting
        if caption:
            self.doc.append(NoEscape(r"\begin{lstlisting}[caption={" + caption + f"], language={language}]"))
        else:
            self.doc.append(NoEscape(r"\begin{lstlisting}[language=" + language + "]"))
        
        self.doc.append(NoEscape(code))
        self.doc.append(NoEscape(r"\end{lstlisting}"))
        print("[ViewX] Código agregado.")

    def add_equation(self, equation, label=None):
        """
        Inserta una ecuación centrada en el documento.
        """
        if label:
            self.doc.append(NoEscape(f"\\begin{{equation}}\\label{{{label}}}"))
        else:
            self.doc.append(NoEscape(r"\begin{equation}"))
        
        self.doc.append(NoEscape(equation))
        self.doc.append(NoEscape(r"\end{equation}"))
        print("[ViewX] Ecuación agregada.")

    def add_image(self, image_path, caption="", width=0.8, position='h!'):
        """
        Inserta una imagen externa en el documento.
        """
        with self.doc.create(Figure(position=position)) as fig_env:
            fig_env.add_image(image_path, width=NoEscape(f"{width}\\linewidth"))
            if caption:
                fig_env.add_caption(caption)
        print(f"[ViewX] Imagen agregada: {image_path}")

    def add_custom_latex(self, latex_code):
        """
        Inserta código LaTeX personalizado.
        """
        self.doc.append(NoEscape(latex_code))

    # ----------------------------------------------------------------------
    #  LIMPIEZA
    # ----------------------------------------------------------------------
    def cleanup_temp_images(self):
        """Elimina imágenes temporales generadas."""
        if hasattr(self, "_temp_images"):
            for img in self._temp_images:
                try:
                    if os.path.exists(img):
                        os.remove(img)
                        print(f"[ViewX] Imagen temporal eliminada: {img}")
                except Exception as e:
                    print(f"[ViewX] Error eliminando {img}: {e}")
            # Limpiar la lista
            self._temp_images.clear()

    # ----------------------------------------------------------------------
    #  EXPORTACIÓN DEL PDF
    # ----------------------------------------------------------------------
    def build(self, filename="report", clean_tex=True, ensure_dependencies=False):
        """
        Genera el archivo PDF.
        
        Args:
            filename (str): Nombre del archivo (sin extensión)
            clean_tex (bool): Si es True, elimina archivos auxiliares .tex, .log, etc.
            ensure_dependencies (bool): Si es True, verifica e instala paquetes LaTeX
        """
        print("[ViewX] Preparando compilación del PDF...")

        if ensure_dependencies and self.auto_install:
            self.ensure_dependencies()

        print("[ViewX] Generando PDF...")
        
        # Ruta completa del archivo
        filepath = os.path.join(self.outdir, filename)
        
        try:
            # Generar PDF
            self.doc.generate_pdf(
                filepath=filepath,
                clean_tex=clean_tex,
                compiler='pdflatex',
                compiler_args=['-interaction=nonstopmode', '-shell-escape']
            )
            
            print(f"[ViewX] PDF generado exitosamente: {filepath}.pdf")
            
        except Exception as e:
            print(f"[ViewX] Error generando PDF: {e}")
            print("[ViewX] Intentando generar solo el archivo .tex...")
            
            # Generar solo archivo .tex como respaldo
            try:
                self.doc.generate_tex(filepath)
                print(f"[ViewX] Archivo .tex generado: {filepath}.tex")
            except Exception as tex_error:
                print(f"[ViewX] Error generando .tex: {tex_error}")
        
        finally:
            # Limpiar imágenes temporales
            self.cleanup_temp_images()

    def __del__(self):
        """Destructor para limpieza."""
        self.cleanup_temp_images()