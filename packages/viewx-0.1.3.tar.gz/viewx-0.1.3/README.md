# 📦 ViewX — Librería de Visualización Adaptativa para Python

**ViewX** es un paquete moderno de Python diseñado para generar **páginas HTML interactivas**, **dashboards dinámicos** y **visualizaciones inteligentes** que se adaptan automáticamente a los objetos agregados por el usuario.

Este proyecto ofrece una solución **ligera, intuitiva y escalable**, ideal para crear interfaces visuales llamativas sin depender de frameworks pesados… aunque también puede integrarse con Streamlit o Dash mediante dependencias opcionales.

---

## ✨ Características principales

- ⚡ **Rápido y minimalista**: cero dependencias pesadas por defecto.  
- 🧩 **API intuitiva**: crea páginas y dashboards en segundos.  
- 📐 **Diseño adaptativo**: cada componente se acomoda automáticamente.  
- 🌐 **Modo HTML**: genera páginas `.html` totalmente autónomas.  
- 📊 **Modo Dashboard**: plantillas escalables con soporte opcional para Streamlit/Dash.  
- 🛠️ **Extensible**: añade tus propias plantillas y módulos personalizados.  
- 🔮 **Visión a futuro**: pensado para expandirse a interfaces inteligentes.

---

## 🚀 Ejemplo rápido

### Crear una página HTML
```python
from viewx.datasets import load_dataset
from viewx import HTML


df = load_dataset("iris.csv")

HTML(df, "Reporte Demo", template=1) \
    .add_valuebox("Filas", df.shape[0], icon="📁", color="#3C8DAD", slot="div1") \
    .add_valuebox("Columnas", df.shape[1], icon="📐", color="#4C6EF5", slot="div2") \
    .add_text(slot="div3")\
    .add_text(slot="div4")\
    .add_plot(x="sepal_length", y="sepal_width", kind="scatter",
            title="Relación de medidas", slot="div5") \
    .add_plot(x="species", y="petal_length", kind="box",
            title="Distribución por especie", slot="div6") \
    .add_text(slot="div7")\
    .add_text(slot="div8")\
    .add_text(slot="div9")\
    .add_table(columns="all", slot="div10", number_table=1) \
    .add_plot(x="petal_length", kind="hist", slot="div11") \
    .add_text("Este es un texto de prueba colocado en div12.", slot="div12") \
    .show("demo_report.html", port=8000)

```

### Crear un DashBoard
```python
from viewx import DashBoard
from viewx.datasets import load_dataset

df = load_dataset("iris.csv")

db = DashBoard(df, title="StreamOps: Mini Dashboard", title_align="center")
db.set_theme(background="#071021", text="#E9F6F2", primary="#19D3A3", card="#0b1620")
# Sidebar
db.add_sidebar(db.comp_text("Parámetros del reporte"))
db.add_sidebar(db.comp_metric("Longitud del dataset", df.shape[0]))
db.add_sidebar(db.comp_metric("Cantidad de Flores", df["species"].unique().shape[0]))
# Main layout
db.add_blank()
db.add_row(
    col_widths=[1, 2, 1],
    components=[
        db.comp_blank(),
        db.comp_plot(x="sepal_length", y="sepal_width", kind="scatter", color="#FFB86B"),
        db.comp_metric("sepal_width", df["sepal_width"].sum(), delta="▲ 5%")
    ]
)

db.add_tabs({
    "Overview": [
        db.comp_title("Resumen por Región"),
        db.comp_table()
    ],
    "Details": [
        db.comp_title("Distribución de Flores"),
        db.comp_plot(x="species", y=None, kind="hist", color="#7C4DFF")
    ]
})

db.add_expander("Detalles técnicos", [
    db.comp_text("Este panel fue generado automáticamente."),
    db.comp_text("Metadata: filas=" + str(len(df)), size="12px")
], expanded=True)

db.run(open_browser=True)   
```

### Crear un Reporte

```python
from viewx.datasets import load_dataset
import seaborn as sns
import matplotlib.pyplot as plt
    
    # Crear reporte
    r = Report(df, theme="article", auto_install=False, outdir="output")
    
    # Título y metadatos
    r.title("Análisis del Dataset Iris", 
            author="ViewX Report System", 
            date="\\today")
    
    # Resumen
    r.add_section("Resumen")
    r.add_text("Este reporte fue generado automáticamente con ViewX + LaTeX. "
               "Contiene análisis exploratorio del famoso dataset Iris.")
    
    # Gráfico
    r.add_section("Análisis Exploratorio")
    r.add_subsection("Gráfico de dispersión")
    plt.figure(figsize=(6, 4))
    sns.scatterplot(data=df, x="sepal_length", y="sepal_width", hue="species")
    plt.title("Relación entre largo y ancho del sépalo")
    plt.xlabel("Longitud del sépalo (cm)")
    plt.ylabel("Ancho del sépalo (cm)")
    r.add_plot_matplotlib(caption="Distribución de especies según medidas del sépalo.")
    
    # Tabla de estadísticas
    r.add_subsection("Estadísticas descriptivas")
    stats_df = df.describe()
    # Ahora pasamos el DataFrame directamente
    r.add_table(df=stats_df, caption="Estadísticas descriptivas del dataset", label="stats")
    
    # También podemos mostrar una tabla del DataFrame original
    r.add_subsection("Muestra de datos")
    r.add_table(columns=["species", "sepal_length", "sepal_width"], 
                caption="Primeras 10 filas del dataset", 
                label="sample")
    
    # Código de ejemplo
    r.add_section("Implementación")
    r.add_text("A continuación se muestra un ejemplo de código para generar este análisis:")
    
    code_example = """# Ejemplo de análisis con ViewX
import pandas as pd
from viewx import Report

# Cargar datos
df = pd.read_csv("iris.csv")

# Crear reporte
r = Report(df)
r.title("Mi Análisis")

# Agregar gráficos y tablas
r.add_section("Resultados")
# ... más código aquí

# Generar PDF
r.build("mi_reporte")"""
    
    r.add_code(code_example, language="python", caption="Ejemplo de uso de ViewX")
    
    # Ecuación
    r.add_section("Modelo Matemático")
    r.add_text("Para la regresión lineal utilizada en el análisis:")
    r.add_equation(r"y = \beta_0 + \beta_1 x + \epsilon", label="eq:regression")
    
    # Exportar PDF
    r.build("reporte_iris_ejemplo", clean_tex=True, ensure_dependencies=False)
    
    print("\n[ViewX] Proceso completado. Revisa la carpeta 'output' para ver los resultados.")
```


## Instalacion
```python
pip install viewx
```

## 🤝 Contribuciones

¡Todas las ideas, mejoras y plantillas son bienvenidas!
ViewX está diseñado para crecer y evolucionar con la comunidad.

## 📬 Contacto:
ascendraemmanuel@gmail.com