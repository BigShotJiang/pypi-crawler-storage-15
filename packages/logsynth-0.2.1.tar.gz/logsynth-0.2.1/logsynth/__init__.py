"""LogSynth - Flexible synthetic log generator."""

__version__ = "0.2.1"
