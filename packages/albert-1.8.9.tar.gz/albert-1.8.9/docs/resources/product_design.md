::: albert.resources.product_design
