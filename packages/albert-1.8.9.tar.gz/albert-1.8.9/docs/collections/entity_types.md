::: albert.collections.entity_types.EntityTypeCollection
