"""AgentBill LangChain Integration

Zero-config callback handler for tracking LangChain usage in AgentBill.
"""

from .callback import AgentBillCallback

__version__ = "6.8.3"
__all__ = ["AgentBillCallback"]
