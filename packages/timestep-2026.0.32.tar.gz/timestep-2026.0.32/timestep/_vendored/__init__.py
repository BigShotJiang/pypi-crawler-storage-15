"""Vendored dependencies."""

