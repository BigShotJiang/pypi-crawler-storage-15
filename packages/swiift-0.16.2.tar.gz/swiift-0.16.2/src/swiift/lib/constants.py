from math import pi, sqrt

PI = pi
PI_2 = 2 * PI
PI_D4 = PI / 4
SQR2 = sqrt(2)
