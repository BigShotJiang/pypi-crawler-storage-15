"""BloodHound CLI package entrypoint."""

__version__ = "1.2.5"
__all__ = ["__version__"]

# End of package metadata
