"""Tests for DimCalc calculator."""

import pytest

from dimcalc import DimCalc, Dimensions, Product


class TestDimCalc:
    def test_dimensional_weight_calculation(self):
        calc = DimCalc(dimensional_factor=5.0)
        dims = Dimensions(length=30, width=20, height=10)  # 6000 cm³

        result = calc.calculate_dimensional_weight(dims, quantity=1)

        assert result == 1200  # 6000 / 5 = 1200g

    def test_dimensional_weight_with_quantity(self):
        calc = DimCalc(dimensional_factor=5.0)
        dims = Dimensions(length=30, width=20, height=10)

        result = calc.calculate_dimensional_weight(dims, quantity=3)

        assert result == 3600  # 6000 * 3 / 5 = 3600g

    def test_chargeable_weight_uses_actual_when_heavier(self):
        calc = DimCalc(dimensional_factor=5.0)
        dims = Dimensions(length=10, width=10, height=10)  # 1000 cm³ = 200g dim weight

        result = calc.calculate_chargeable_weight(
            actual_weight=500,
            dimensions=dims,
            quantity=1,
        )

        assert result.chargeable_weight == 500
        assert result.is_dimensional_used is False

    def test_chargeable_weight_uses_dimensional_when_heavier(self):
        calc = DimCalc(dimensional_factor=5.0)
        dims = Dimensions(length=30, width=20, height=10)  # 6000 cm³ = 1200g dim weight

        result = calc.calculate_chargeable_weight(
            actual_weight=500,
            dimensions=dims,
            quantity=1,
        )

        assert result.chargeable_weight == 1200
        assert result.is_dimensional_used is True

    def test_no_dimensions_uses_actual_weight(self):
        calc = DimCalc()

        result = calc.calculate_chargeable_weight(
            actual_weight=500,
            dimensions=None,
            quantity=2,
        )

        assert result.chargeable_weight == 1000
        assert result.dimensional_weight == 0
        assert result.is_dimensional_used is False

    def test_invalid_dimensional_factor_raises_error(self):
        with pytest.raises(ValueError, match="must be positive"):
            DimCalc(dimensional_factor=0)

        with pytest.raises(ValueError, match="must be positive"):
            DimCalc(dimensional_factor=-5)

    def test_calculate_for_products(self):
        calc = DimCalc(dimensional_factor=5.0)
        products = [
            Product(weight=500, quantity=2, dimensions=Dimensions(length=30, width=20, height=10)),
            Product(weight=300, quantity=1, dimensions=Dimensions(length=10, width=10, height=5)),
        ]

        result = calc.calculate_for_products(products)

        # Total actual: 500*2 + 300*1 = 1300g
        assert result.actual_weight == 1300
        # Dimensional: 6000*2/5 + 500*1/5 = 2400 + 100 = 2500g
        assert result.dimensional_weight == 2500
        assert result.chargeable_weight == 2500
        assert result.is_dimensional_used is True

    def test_calculate_for_products_without_dimensions(self):
        calc = DimCalc(dimensional_factor=5.0)
        products = [
            Product(weight=500, quantity=2),
            Product(weight=300, quantity=1),
        ]

        result = calc.calculate_for_products(products)

        assert result.actual_weight == 1300
        assert result.dimensional_weight == 0
        assert result.chargeable_weight == 1300
        assert result.is_dimensional_used is False

    def test_calculate_dimensional_weight_for_box(self):
        from dimcalc import Box

        calc = DimCalc(dimensional_factor=5.0)
        box = Box(id="test", length=30, width=20, height=10)

        result = calc.calculate_dimensional_weight_for_box(box)

        assert result == 1200  # 6000 / 5 = 1200g

    def test_weight_result_weight_difference(self):
        calc = DimCalc(dimensional_factor=5.0)
        dims = Dimensions(length=30, width=20, height=10)

        result = calc.calculate_chargeable_weight(
            actual_weight=500,
            dimensions=dims,
            quantity=1,
        )

        assert result.weight_difference == 700  # 1200 - 500
