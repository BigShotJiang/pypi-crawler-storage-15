"""Tests for BoxSelector."""

import pytest

from dimcalc import Box, BoxSelector, Dimensions, Product


class TestBoxSelector:
    @pytest.fixture
    def boxes(self):
        return [
            Box(id="s", length=20, width=15, height=10, name="Small"),
            Box(id="m", length=30, width=25, height=15, name="Medium"),
            Box(id="l", length=40, width=30, height=20, name="Large"),
        ]

    def test_selects_smallest_fitting_box(self, boxes):
        selector = BoxSelector(boxes=boxes, volume_buffer_percentage=0)
        products = [
            Product(weight=100, dimensions=Dimensions(length=10, width=10, height=5))  # 500 cm³
        ]

        result = selector.select_box(products)

        assert result.box.id == "s"  # Small box (3000 cm³) fits 500 cm³

    def test_respects_volume_buffer(self, boxes):
        selector = BoxSelector(boxes=boxes, volume_buffer_percentage=100)
        products = [
            Product(weight=100, dimensions=Dimensions(length=15, width=12, height=8))  # 1440 cm³
        ]
        # With 100% buffer: 1440 * 2 = 2880 cm³ needed
        # Small box is 3000 cm³, should still fit

        result = selector.select_box(products)

        assert result.box.id == "s"

    def test_respects_max_dimension_constraint(self, boxes):
        selector = BoxSelector(boxes=boxes, volume_buffer_percentage=0)
        products = [
            Product(
                weight=100, dimensions=Dimensions(length=25, width=5, height=5)
            )  # 625 cm³ but 25cm long
        ]
        # Small box max dim is 20cm, can't fit 25cm product

        result = selector.select_box(products)

        assert result.box.id == "m"  # Medium box (max 30cm) is needed

    def test_uses_largest_box_when_nothing_fits(self, boxes):
        selector = BoxSelector(boxes=boxes, volume_buffer_percentage=0)
        products = [
            Product(weight=100, dimensions=Dimensions(length=50, width=50, height=50))  # Way too big
        ]

        result = selector.select_box(products)

        assert result.box.id == "l"  # Falls back to largest

    def test_returns_none_for_empty_products(self, boxes):
        selector = BoxSelector(boxes=boxes)

        result = selector.select_box([])

        assert result is None

    def test_returns_none_when_no_dimensions(self, boxes):
        selector = BoxSelector(boxes=boxes)
        products = [Product(weight=100, dimensions=None)]

        result = selector.select_box(products)

        assert result is None

    def test_can_fit_returns_true_for_fitting_products(self, boxes):
        selector = BoxSelector(boxes=boxes)
        products = [Product(weight=100, dimensions=Dimensions(length=10, width=10, height=5))]

        assert selector.can_fit(products) is True

    def test_can_fit_returns_false_for_oversized_products(self, boxes):
        selector = BoxSelector(boxes=boxes)
        # Large box is 40x30x20 = 24000 cm³, max dim 40
        products = [
            Product(weight=100, dimensions=Dimensions(length=50, width=50, height=50))  # 125000 cm³
        ]

        assert selector.can_fit(products) is False

    def test_can_fit_returns_true_for_empty_products(self, boxes):
        selector = BoxSelector(boxes=boxes)

        assert selector.can_fit([]) is True

    def test_can_fit_returns_true_when_no_dimensions(self, boxes):
        selector = BoxSelector(boxes=boxes)
        products = [Product(weight=100, dimensions=None)]

        assert selector.can_fit(products) is True

    def test_raises_error_for_empty_boxes_list(self):
        with pytest.raises(ValueError, match="At least one box"):
            BoxSelector(boxes=[])

    def test_raises_error_for_negative_buffer(self, boxes):
        with pytest.raises(ValueError, match="cannot be negative"):
            BoxSelector(boxes=boxes, volume_buffer_percentage=-10)

    def test_boxes_sorted_by_volume(self):
        # Create boxes in random order
        boxes = [
            Box(id="l", length=40, width=30, height=20),
            Box(id="s", length=20, width=15, height=10),
            Box(id="m", length=30, width=25, height=15),
        ]
        selector = BoxSelector(boxes=boxes)

        # Should be sorted by volume
        assert selector.boxes[0].id == "s"
        assert selector.boxes[1].id == "m"
        assert selector.boxes[2].id == "l"

    def test_utilization_percentage(self, boxes):
        selector = BoxSelector(boxes=boxes, volume_buffer_percentage=0)
        products = [
            Product(weight=100, dimensions=Dimensions(length=10, width=10, height=10))  # 1000 cm³
        ]

        result = selector.select_box(products)

        # Small box is 3000 cm³
        expected_utilization = (1000 / 3000) * 100  # ~33.33%
        assert abs(result.utilization_percentage - expected_utilization) < 0.01

    def test_weight_calculation_in_result(self, boxes):
        selector = BoxSelector(boxes=boxes, volume_buffer_percentage=0)
        products = [
            Product(weight=100, quantity=2, dimensions=Dimensions(length=10, width=10, height=5))
        ]

        result = selector.select_box(products)

        assert result.weight.actual_weight == 200  # 100 * 2
        # Small box dim weight: 3000 / 5 = 600g
        assert result.weight.dimensional_weight == 600
        assert result.weight.chargeable_weight == 600
        assert result.weight.is_dimensional_used is True
