"""Tests for WeightDistributor."""

import pytest

from dimcalc import (
    Box,
    BoxSelectionResult,
    Product,
    WeightDistributor,
    WeightResult,
)


class TestWeightDistributor:
    def test_distributes_proportionally(self):
        products = [
            Product(weight=600, quantity=1),  # 60% of weight
            Product(weight=400, quantity=1),  # 40% of weight
        ]
        box_result = BoxSelectionResult(
            box=Box(id="test", length=30, width=20, height=10),
            weight=WeightResult(
                actual_weight=1000,
                dimensional_weight=1200,
                chargeable_weight=1200,
                is_dimensional_used=True,
            ),
            total_products_volume=5000,
            utilization_percentage=83.3,
        )

        distributed = WeightDistributor.distribute(products, box_result)

        assert distributed[0].distributed_weight == 720  # 60% of 1200
        assert distributed[1].distributed_weight == 480  # 40% of 1200

    def test_handles_quantity(self):
        products = [
            Product(weight=100, quantity=2),  # 200g total
            Product(weight=300, quantity=1),  # 300g total
        ]
        box_result = BoxSelectionResult(
            box=Box(id="test", length=30, width=20, height=10),
            weight=WeightResult(
                actual_weight=500,
                dimensional_weight=1000,
                chargeable_weight=1000,
                is_dimensional_used=True,
            ),
            total_products_volume=5000,
            utilization_percentage=83.3,
        )

        distributed = WeightDistributor.distribute(products, box_result)

        # First product: 200/500 = 40%, gets 400g, per unit = 200g
        assert distributed[0].distributed_weight == 200
        # Second product: 300/500 = 60%, gets 600g, per unit = 600g
        assert distributed[1].distributed_weight == 600

    def test_preserves_original_weight(self):
        products = [
            Product(weight=500, quantity=1),
            Product(weight=300, quantity=2),
        ]
        box_result = BoxSelectionResult(
            box=Box(id="test", length=30, width=20, height=10),
            weight=WeightResult(
                actual_weight=1100,
                dimensional_weight=1200,
                chargeable_weight=1200,
                is_dimensional_used=True,
            ),
            total_products_volume=5000,
            utilization_percentage=83.3,
        )

        distributed = WeightDistributor.distribute(products, box_result)

        assert distributed[0].original_weight == 500
        assert distributed[1].original_weight == 300

    def test_preserves_quantity(self):
        products = [
            Product(weight=500, quantity=3),
            Product(weight=300, quantity=2),
        ]
        box_result = BoxSelectionResult(
            box=Box(id="test", length=30, width=20, height=10),
            weight=WeightResult(
                actual_weight=2100,
                dimensional_weight=1200,
                chargeable_weight=2100,
                is_dimensional_used=False,
            ),
            total_products_volume=5000,
            utilization_percentage=83.3,
        )

        distributed = WeightDistributor.distribute(products, box_result)

        assert distributed[0].quantity == 3
        assert distributed[1].quantity == 2

    def test_sets_is_dimensional_used(self):
        products = [Product(weight=500, quantity=1)]

        # Test with dimensional weight used
        box_result_dim = BoxSelectionResult(
            box=Box(id="test", length=30, width=20, height=10),
            weight=WeightResult(
                actual_weight=500,
                dimensional_weight=1200,
                chargeable_weight=1200,
                is_dimensional_used=True,
            ),
            total_products_volume=5000,
            utilization_percentage=83.3,
        )
        distributed = WeightDistributor.distribute(products, box_result_dim)
        assert distributed[0].is_dimensional_used is True

        # Test without dimensional weight used
        box_result_actual = BoxSelectionResult(
            box=Box(id="test", length=30, width=20, height=10),
            weight=WeightResult(
                actual_weight=1500,
                dimensional_weight=1200,
                chargeable_weight=1500,
                is_dimensional_used=False,
            ),
            total_products_volume=5000,
            utilization_percentage=83.3,
        )
        distributed = WeightDistributor.distribute(products, box_result_actual)
        assert distributed[0].is_dimensional_used is False

    def test_handles_zero_total_weight(self):
        products = [
            Product(weight=0, quantity=1),
            Product(weight=0, quantity=2),
        ]
        box_result = BoxSelectionResult(
            box=Box(id="test", length=30, width=20, height=10),
            weight=WeightResult(
                actual_weight=0,
                dimensional_weight=1200,
                chargeable_weight=1200,
                is_dimensional_used=True,
            ),
            total_products_volume=5000,
            utilization_percentage=83.3,
        )

        distributed = WeightDistributor.distribute(products, box_result)

        assert distributed[0].distributed_weight == 0
        assert distributed[1].distributed_weight == 0

    def test_distribute_evenly(self):
        products = [
            Product(weight=600, quantity=2),  # 2 units
            Product(weight=400, quantity=3),  # 3 units
        ]
        # Total 5 units

        distributed = WeightDistributor.distribute_evenly(products, 1000)

        # 1000 / 5 = 200 per unit
        assert distributed[0].distributed_weight == 200
        assert distributed[1].distributed_weight == 200
