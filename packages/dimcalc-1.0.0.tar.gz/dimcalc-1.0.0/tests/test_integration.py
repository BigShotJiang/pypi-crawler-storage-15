"""Integration tests for dimcalc library."""

import pytest

from dimcalc import (
    Box,
    BoxSelector,
    DimCalc,
    Dimensions,
    Product,
    WeightDistributor,
)
from dimcalc.presets import (
    DIMENSIONAL_FACTORS,
    IRAN_POST_BOXES,
    get_iran_post_selector,
)


class TestDimensionsModel:
    def test_create_dimensions(self):
        dims = Dimensions(length=30, width=20, height=10)

        assert dims.length == 30
        assert dims.width == 20
        assert dims.height == 10

    def test_volume_calculation(self):
        dims = Dimensions(length=30, width=20, height=10)

        assert dims.volume == 6000

    def test_max_dimension(self):
        dims = Dimensions(length=30, width=20, height=10)

        assert dims.max_dimension == 30

    def test_from_dict(self):
        data = {"length": 30, "width": 20, "height": 10}
        dims = Dimensions(**data)

        assert dims.length == 30
        assert dims.width == 20
        assert dims.height == 10

    def test_invalid_dimensions_raises_error(self):
        from pydantic import ValidationError

        with pytest.raises(ValidationError):
            Dimensions(length=0, width=20, height=10)

        with pytest.raises(ValidationError):
            Dimensions(length=30, width=-5, height=10)


class TestBoxModel:
    def test_create_box(self):
        box = Box(id="test", length=30, width=20, height=10, name="Test Box")

        assert box.id == "test"
        assert box.name == "Test Box"
        assert box.volume == 6000

    def test_box_dimensions_property(self):
        box = Box(id="test", length=30, width=20, height=10)
        dims = box.dimensions

        assert isinstance(dims, Dimensions)
        assert dims.length == 30


class TestProductModel:
    def test_create_product(self):
        dims = Dimensions(length=10, width=10, height=5)
        product = Product(weight=500, quantity=2, dimensions=dims)

        assert product.weight == 500
        assert product.quantity == 2
        assert product.total_weight == 1000
        assert product.total_volume == 1000  # 500 * 2

    def test_product_without_dimensions(self):
        product = Product(weight=500, quantity=2)

        assert product.dimensions is None
        assert product.total_volume is None


class TestPresetsIntegration:
    def test_iran_post_boxes_exist(self):
        assert len(IRAN_POST_BOXES) == 8
        assert IRAN_POST_BOXES[0].id == "box_1"
        assert IRAN_POST_BOXES[-1].name == "4XL - Post Jumbo"

    def test_dimensional_factors(self):
        assert DIMENSIONAL_FACTORS["iran_post"] == 5.0
        assert DIMENSIONAL_FACTORS["dhl"] == 5000.0

    def test_get_iran_post_selector(self):
        selector = get_iran_post_selector()

        assert isinstance(selector, BoxSelector)
        assert len(selector.boxes) == 8
        assert selector.volume_buffer_percentage == 20.0


class TestFullWorkflow:
    """Test complete workflows as described in the integration guide."""

    def test_simple_dimensional_weight_calculation(self):
        """Test the simple workflow from the docstring."""
        calc = DimCalc(dimensional_factor=5.0)
        dims = Dimensions(length=30, width=20, height=10)

        result = calc.calculate_chargeable_weight(
            actual_weight=500,
            dimensions=dims,
            quantity=2,
        )

        # Volume: 30*20*10 = 6000 cm³ per unit, 12000 cm³ total
        # Dimensional weight: 12000 / 5 = 2400g
        # Actual weight: 500 * 2 = 1000g
        # Chargeable: max(1000, 2400) = 2400g
        assert result.chargeable_weight == 2400
        assert result.is_dimensional_used is True

    def test_box_based_calculation_workflow(self):
        """Test box-based calculation as described in docs."""
        selector = BoxSelector(boxes=IRAN_POST_BOXES)
        products = [
            Product(
                weight=500,
                quantity=2,
                dimensions=Dimensions(length=30, width=20, height=10),
            ),
            Product(
                weight=300,
                quantity=1,
                dimensions=Dimensions(length=10, width=10, height=5),
            ),
        ]

        box_result = selector.select_box(products)

        assert box_result is not None
        assert box_result.box is not None
        assert box_result.weight.chargeable_weight > 0

    def test_weight_distribution_workflow(self):
        """Test weight distribution after box selection."""
        selector = BoxSelector(boxes=IRAN_POST_BOXES, volume_buffer_percentage=0)
        products = [
            Product(weight=600, quantity=1, dimensions=Dimensions(length=20, width=15, height=10)),
            Product(weight=400, quantity=1, dimensions=Dimensions(length=10, width=10, height=5)),
        ]

        box_result = selector.select_box(products)
        distributed = WeightDistributor.distribute(products, box_result)

        assert len(distributed) == 2
        # Check that weights are distributed proportionally
        total_distributed = sum(
            d.distributed_weight * d.quantity for d in distributed
        )
        # Should be close to chargeable weight (some rounding may occur)
        assert abs(total_distributed - box_result.weight.chargeable_weight) < 10

    def test_to_dict_serialization(self):
        """Test that results can be serialized to dict."""
        selector = BoxSelector(boxes=IRAN_POST_BOXES)
        products = [
            Product(weight=500, quantity=1, dimensions=Dimensions(length=20, width=15, height=10)),
        ]

        box_result = selector.select_box(products)
        data = box_result.to_dict()

        assert "box_id" in data
        assert "box_name" in data
        assert "box_dimensions" in data
        assert "weight" in data
        assert "packing_info" in data
        assert data["weight"]["chargeable_weight_g"] == box_result.weight.chargeable_weight


class TestEdgeCases:
    def test_single_product_no_dimensions(self):
        """Test handling of products without dimensions."""
        calc = DimCalc()
        result = calc.calculate_chargeable_weight(actual_weight=500)

        assert result.chargeable_weight == 500
        assert result.dimensional_weight == 0

    def test_mixed_products_with_and_without_dimensions(self):
        """Test mix of products with and without dimensions."""
        calc = DimCalc(dimensional_factor=5.0)
        products = [
            Product(weight=500, quantity=1, dimensions=Dimensions(length=30, width=20, height=10)),
            Product(weight=300, quantity=2),  # No dimensions
        ]

        result = calc.calculate_for_products(products)

        # Actual: 500 + 600 = 1100g
        # Dimensional: 6000/5 = 1200g (only from first product)
        assert result.actual_weight == 1100
        assert result.dimensional_weight == 1200
        assert result.chargeable_weight == 1200

    def test_very_small_product(self):
        """Test with minimal dimensions."""
        calc = DimCalc(dimensional_factor=5.0)
        dims = Dimensions(length=1, width=1, height=1)  # 1 cm³

        result = calc.calculate_dimensional_weight(dims)

        assert result == 0  # 1 / 5 = 0 (truncated)

    def test_large_quantity(self):
        """Test with large quantities."""
        calc = DimCalc(dimensional_factor=5.0)
        dims = Dimensions(length=10, width=10, height=10)

        result = calc.calculate_chargeable_weight(
            actual_weight=100,
            dimensions=dims,
            quantity=1000,
        )

        # Volume: 1000 cm³ * 1000 = 1,000,000 cm³
        # Dimensional: 1,000,000 / 5 = 200,000g
        assert result.dimensional_weight == 200000
        assert result.actual_weight == 100000
        assert result.chargeable_weight == 200000
