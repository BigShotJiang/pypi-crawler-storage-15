"""Core dimensional weight calculator."""

from typing import List, Optional

from .models import Box, Dimensions, Product, WeightResult


class DimCalc:
    """
    Dimensional weight calculator.

    The dimensional factor (also called DIM factor or DIM divisor) converts
    volume to weight. Common values:
    - 5000 for cm³ to kg (international standard)
    - 5.0 for cm³ to grams (used in this implementation)
    - 6000 for some carriers

    Formula: dimensional_weight = volume / dimensional_factor
    """

    DEFAULT_FACTOR = 5.0  # cm³ to grams

    def __init__(self, dimensional_factor: float = DEFAULT_FACTOR):
        """
        Initialize calculator with a dimensional factor.

        Args:
            dimensional_factor: Divisor for volume-to-weight conversion.
                               Default is 5.0 (volume_cm³ / 5 = weight_grams)
        """
        if dimensional_factor <= 0:
            raise ValueError("Dimensional factor must be positive")
        self.dimensional_factor = dimensional_factor

    def calculate_dimensional_weight(
        self,
        dimensions: Dimensions,
        quantity: int = 1,
    ) -> int:
        """
        Calculate dimensional weight for given dimensions.

        Args:
            dimensions: Product dimensions (L x W x H in cm)
            quantity: Number of units

        Returns:
            Dimensional weight in grams (integer, rounded down)
        """
        volume = dimensions.volume * quantity
        return int(volume / self.dimensional_factor)

    def calculate_dimensional_weight_for_box(self, box: Box) -> int:
        """
        Calculate dimensional weight for a box.

        Args:
            box: Box with dimensions

        Returns:
            Dimensional weight in grams
        """
        return int(box.volume / self.dimensional_factor)

    def calculate_chargeable_weight(
        self,
        actual_weight: int,
        dimensions: Optional[Dimensions] = None,
        quantity: int = 1,
    ) -> WeightResult:
        """
        Calculate chargeable weight (max of actual and dimensional).

        Args:
            actual_weight: Weight per unit in grams
            dimensions: Optional product dimensions
            quantity: Number of units

        Returns:
            WeightResult with all weight calculations
        """
        total_actual = actual_weight * quantity

        if dimensions is None:
            return WeightResult(
                actual_weight=total_actual,
                dimensional_weight=0,
                chargeable_weight=total_actual,
                is_dimensional_used=False,
            )

        dimensional = self.calculate_dimensional_weight(dimensions, quantity)
        chargeable = max(total_actual, dimensional)

        return WeightResult(
            actual_weight=total_actual,
            dimensional_weight=dimensional,
            chargeable_weight=chargeable,
            is_dimensional_used=dimensional > total_actual,
        )

    def calculate_for_products(
        self,
        products: List[Product],
    ) -> WeightResult:
        """
        Calculate combined chargeable weight for multiple products.

        This is the per-item calculation mode (legacy behavior).
        Each product's dimensional weight is calculated separately
        and summed.

        Args:
            products: List of products with weights and optional dimensions

        Returns:
            Combined WeightResult
        """
        total_actual = 0
        total_dimensional = 0

        for product in products:
            total_actual += product.total_weight

            if product.dimensions:
                dim_weight = self.calculate_dimensional_weight(
                    product.dimensions,
                    product.quantity,
                )
                total_dimensional += dim_weight

        chargeable = max(total_actual, total_dimensional)

        return WeightResult(
            actual_weight=total_actual,
            dimensional_weight=total_dimensional,
            chargeable_weight=chargeable,
            is_dimensional_used=total_dimensional > total_actual,
        )
