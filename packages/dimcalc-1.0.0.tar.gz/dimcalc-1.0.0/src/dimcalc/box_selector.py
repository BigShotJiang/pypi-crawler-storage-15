"""Box selection algorithm for optimal shipping box."""

from typing import List, Optional

from .calculator import DimCalc
from .models import Box, BoxSelectionResult, Product, WeightResult


class BoxSelector:
    """
    Selects the optimal shipping box for a set of products.

    Algorithm:
    1. Calculate total volume of all products
    2. Add buffer percentage (default 20%) for packing inefficiency
    3. Find smallest box that:
       a. Has volume >= required volume with buffer
       b. Has max dimension >= largest product dimension
    4. If no box fits, use largest available box
    """

    def __init__(
        self,
        boxes: List[Box],
        volume_buffer_percentage: float = 20.0,
        calculator: Optional[DimCalc] = None,
    ):
        """
        Initialize box selector.

        Args:
            boxes: Available box sizes (will be sorted by volume)
            volume_buffer_percentage: Extra space buffer (default 20%)
            calculator: DimCalc instance for weight calculations
        """
        if not boxes:
            raise ValueError("At least one box must be provided")
        if volume_buffer_percentage < 0:
            raise ValueError("Buffer percentage cannot be negative")

        self.boxes = sorted(boxes, key=lambda b: b.volume)
        self.volume_buffer_percentage = volume_buffer_percentage
        self.calculator = calculator or DimCalc()

    def select_box(
        self,
        products: List[Product],
    ) -> Optional[BoxSelectionResult]:
        """
        Select optimal box for given products.

        Args:
            products: List of products to pack

        Returns:
            BoxSelectionResult or None if no products with dimensions
        """
        if not products:
            return None

        # Calculate total actual weight
        total_actual_weight = sum(p.total_weight for p in products)

        # Get products with dimensions for volume calculation
        products_with_dims = [p for p in products if p.dimensions]

        if not products_with_dims:
            # No dimensions - return None (caller should use actual weight)
            return None

        # Calculate total volume
        total_volume = sum(
            p.total_volume for p in products_with_dims if p.total_volume is not None
        )

        # Apply buffer
        required_volume = total_volume * (1 + self.volume_buffer_percentage / 100)

        # Find max dimension constraint
        max_product_dimension = max(
            p.dimensions.max_dimension for p in products_with_dims if p.dimensions
        )

        # Find suitable box
        selected_box = self._find_suitable_box(required_volume, max_product_dimension)

        # Calculate dimensional weight for the box
        box_dimensional_weight = self.calculator.calculate_dimensional_weight_for_box(
            selected_box
        )

        chargeable = max(total_actual_weight, box_dimensional_weight)

        weight_result = WeightResult(
            actual_weight=total_actual_weight,
            dimensional_weight=box_dimensional_weight,
            chargeable_weight=chargeable,
            is_dimensional_used=box_dimensional_weight > total_actual_weight,
        )

        utilization = (total_volume / selected_box.volume) * 100

        return BoxSelectionResult(
            box=selected_box,
            weight=weight_result,
            total_products_volume=total_volume,
            utilization_percentage=utilization,
        )

    def _find_suitable_box(
        self,
        required_volume: float,
        max_dimension: float,
    ) -> Box:
        """Find smallest box that fits the requirements."""
        for box in self.boxes:
            # Check dimension constraint
            if box.max_dimension < max_dimension:
                continue

            # Check volume constraint
            if box.volume >= required_volume:
                return box

        # Fallback to largest box
        return self.boxes[-1]

    def can_fit(self, products: List[Product]) -> bool:
        """Check if products can fit in any available box."""
        if not products:
            return True

        products_with_dims = [p for p in products if p.dimensions]
        if not products_with_dims:
            return True

        total_volume = sum(
            p.total_volume for p in products_with_dims if p.total_volume is not None
        )
        max_dim = max(
            p.dimensions.max_dimension for p in products_with_dims if p.dimensions
        )

        largest_box = self.boxes[-1]
        return largest_box.max_dimension >= max_dim and largest_box.volume >= total_volume
