"""Data models for dimcalc library."""

from typing import Any, Optional

from pydantic import BaseModel, Field, computed_field, model_validator


class Dimensions(BaseModel):
    """Represents physical dimensions in centimeters."""

    model_config = {"frozen": True}

    length: float = Field(..., gt=0, description="Length in centimeters")
    width: float = Field(..., gt=0, description="Width in centimeters")
    height: float = Field(..., gt=0, description="Height in centimeters")

    @computed_field
    @property
    def volume(self) -> float:
        """Calculate volume in cubic centimeters (cm³)."""
        return self.length * self.width * self.height

    @computed_field
    @property
    def max_dimension(self) -> float:
        """Return the largest single dimension."""
        return max(self.length, self.width, self.height)


class Box(BaseModel):
    """Represents a shipping box with standard dimensions."""

    model_config = {"frozen": True}

    id: str = Field(..., description="Unique identifier for the box")
    length: float = Field(..., gt=0, description="Length in centimeters")
    width: float = Field(..., gt=0, description="Width in centimeters")
    height: float = Field(..., gt=0, description="Height in centimeters")
    name: Optional[str] = Field(default=None, description="Human-readable box name")

    @computed_field
    @property
    def volume(self) -> float:
        """Calculate box volume in cubic centimeters."""
        return self.length * self.width * self.height

    @computed_field
    @property
    def max_dimension(self) -> float:
        """Return the largest single dimension."""
        return max(self.length, self.width, self.height)

    @property
    def dimensions(self) -> Dimensions:
        """Return dimensions as a Dimensions object."""
        return Dimensions(length=self.length, width=self.width, height=self.height)


class Product(BaseModel):
    """Represents a product for weight/box calculation."""

    model_config = {"frozen": True}

    weight: int = Field(..., ge=0, description="Weight per unit in grams")
    quantity: int = Field(default=1, ge=1, description="Number of units")
    dimensions: Optional[Dimensions] = Field(
        default=None, description="Product dimensions"
    )

    @computed_field
    @property
    def total_weight(self) -> int:
        """Total weight considering quantity."""
        return self.weight * self.quantity

    @computed_field
    @property
    def total_volume(self) -> Optional[float]:
        """Total volume considering quantity, or None if no dimensions."""
        if self.dimensions is None:
            return None
        return self.dimensions.volume * self.quantity


class WeightResult(BaseModel):
    """Result of a dimensional weight calculation."""

    model_config = {"frozen": True}

    actual_weight: int = Field(..., ge=0, description="Total actual weight in grams")
    dimensional_weight: int = Field(
        ..., ge=0, description="Calculated dimensional weight in grams"
    )
    chargeable_weight: int = Field(
        ..., ge=0, description="Chargeable weight (max of actual and dimensional)"
    )
    is_dimensional_used: bool = Field(
        ..., description="True if dimensional weight exceeds actual weight"
    )

    @computed_field
    @property
    def weight_difference(self) -> int:
        """Difference between chargeable and actual weight."""
        return self.chargeable_weight - self.actual_weight


class BoxSelectionResult(BaseModel):
    """Result of box selection with weight calculation."""

    model_config = {"frozen": True}

    box: Box = Field(..., description="Selected box")
    weight: WeightResult = Field(..., description="Weight calculation result")
    total_products_volume: float = Field(
        ..., ge=0, description="Total volume of all products in cm³"
    )
    utilization_percentage: float = Field(
        ..., ge=0, description="Box utilization percentage"
    )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "box_id": self.box.id,
            "box_name": self.box.name,
            "box_dimensions": {
                "length_cm": self.box.length,
                "width_cm": self.box.width,
                "height_cm": self.box.height,
                "volume_cm3": self.box.volume,
            },
            "weight": {
                "actual_weight_g": self.weight.actual_weight,
                "dimensional_weight_g": self.weight.dimensional_weight,
                "chargeable_weight_g": self.weight.chargeable_weight,
                "is_dimensional_used": self.weight.is_dimensional_used,
            },
            "packing_info": {
                "total_products_volume_cm3": self.total_products_volume,
                "utilization_percentage": round(self.utilization_percentage, 2),
            },
        }


class DistributedWeight(BaseModel):
    """Weight distributed proportionally to a single item."""

    original_weight: int = Field(..., ge=0, description="Original actual weight per unit")
    distributed_weight: int = Field(
        ..., ge=0, description="Proportionally distributed weight per unit"
    )
    quantity: int = Field(..., ge=0, description="Number of units")
    is_dimensional_used: bool = Field(
        ..., description="True if dimensional weight was used"
    )
