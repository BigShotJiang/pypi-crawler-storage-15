"""Predefined box configurations and dimensional factors."""

from .models import Box

# Iran Post Standard Boxes
IRAN_POST_BOXES = [
    Box(id="box_1", length=15, width=10, height=10, name="XS"),
    Box(id="box_2", length=20, width=15, height=10, name="S"),
    Box(id="box_3", length=25, width=20, height=15, name="M"),
    Box(id="box_4", length=30, width=25, height=15, name="L"),
    Box(id="box_5", length=40, width=30, height=20, name="XL - Post Standard"),
    Box(id="box_6", length=45, width=35, height=25, name="2XL - Post Large"),
    Box(id="box_7", length=50, width=40, height=30, name="3XL - Post XLarge"),
    Box(id="box_8", length=60, width=45, height=35, name="4XL - Post Jumbo"),
]

# Common dimensional factors by carrier
DIMENSIONAL_FACTORS = {
    "iran_post": 5.0,  # cm³ to grams
    "dhl": 5000.0,  # cm³ to kg (international)
}


def get_iran_post_selector():
    """Get a BoxSelector configured for Iran Post standards."""
    from .box_selector import BoxSelector
    from .calculator import DimCalc

    return BoxSelector(
        boxes=IRAN_POST_BOXES,
        volume_buffer_percentage=20.0,
        calculator=DimCalc(dimensional_factor=DIMENSIONAL_FACTORS["iran_post"]),
    )
