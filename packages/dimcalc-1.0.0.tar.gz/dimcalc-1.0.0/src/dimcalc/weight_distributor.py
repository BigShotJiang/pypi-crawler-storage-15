"""Weight distribution algorithms for proportional cost allocation."""

from typing import List

from .models import BoxSelectionResult, DistributedWeight, Product


class WeightDistributor:
    """
    Distributes chargeable weight proportionally across products.

    When using box-based calculation, the total chargeable weight needs
    to be distributed back to individual items for per-item cost calculation.

    Distribution is proportional to each item's actual weight contribution.
    """

    @staticmethod
    def distribute(
        products: List[Product],
        box_result: BoxSelectionResult,
    ) -> List[DistributedWeight]:
        """
        Distribute box chargeable weight proportionally to products.

        Args:
            products: Original products with weights
            box_result: Result from box selection

        Returns:
            List of DistributedWeight, one per product (in same order)
        """
        total_actual = box_result.weight.actual_weight
        total_chargeable = box_result.weight.chargeable_weight
        is_dimensional = box_result.weight.is_dimensional_used

        results = []

        for product in products:
            if total_actual > 0:
                # Calculate proportion based on actual weight
                proportion = (product.weight * product.quantity) / total_actual
                proportional_weight = int(total_chargeable * proportion)

                # Calculate per-unit weight
                per_unit = (
                    proportional_weight // product.quantity
                    if product.quantity > 0
                    else proportional_weight
                )
            else:
                per_unit = 0

            results.append(
                DistributedWeight(
                    original_weight=product.weight,
                    distributed_weight=per_unit,
                    quantity=product.quantity,
                    is_dimensional_used=is_dimensional,
                )
            )

        return results

    @staticmethod
    def distribute_evenly(
        products: List[Product],
        total_chargeable_weight: int,
    ) -> List[DistributedWeight]:
        """
        Distribute weight evenly across products (alternative strategy).

        Args:
            products: Products to distribute to
            total_chargeable_weight: Total weight to distribute

        Returns:
            List of DistributedWeight
        """
        total_units = sum(p.quantity for p in products)

        if total_units == 0:
            return [
                DistributedWeight(
                    original_weight=p.weight,
                    distributed_weight=0,
                    quantity=p.quantity,
                    is_dimensional_used=False,
                )
                for p in products
            ]

        weight_per_unit = total_chargeable_weight // total_units

        return [
            DistributedWeight(
                original_weight=p.weight,
                distributed_weight=weight_per_unit,
                quantity=p.quantity,
                is_dimensional_used=True,  # Assuming dimensional if distributing
            )
            for p in products
        ]
