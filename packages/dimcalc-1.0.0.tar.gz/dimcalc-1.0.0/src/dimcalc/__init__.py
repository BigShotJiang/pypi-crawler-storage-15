"""
dimcalc - Dimensional Weight Calculator

A library for calculating shipping dimensional weight and selecting optimal boxes.

Quick Start:
    from dimcalc import DimCalc, BoxSelector, Dimensions, Product
    from dimcalc.presets import IRAN_POST_BOXES

    # Simple dimensional weight calculation
    calc = DimCalc(dimensional_factor=5.0)
    dims = Dimensions(length=30, width=20, height=10)
    result = calc.calculate_chargeable_weight(
        actual_weight=500,  # grams
        dimensions=dims,
        quantity=2
    )
    print(f"Chargeable weight: {result.chargeable_weight}g")

    # Box-based calculation
    selector = BoxSelector(boxes=IRAN_POST_BOXES)
    products = [
        Product(weight=500, quantity=2, dimensions=dims),
        Product(weight=300, quantity=1, dimensions=Dimensions(10, 10, 5))
    ]
    box_result = selector.select_box(products)
    print(f"Selected box: {box_result.box.name}")
    print(f"Chargeable weight: {box_result.weight.chargeable_weight}g")
"""

from .box_selector import BoxSelector
from .calculator import DimCalc
from .exceptions import (
    DimCalcError,
    InvalidConfigError,
    InvalidDimensionsError,
    NoBoxAvailableError,
)
from .models import (
    Box,
    BoxSelectionResult,
    Dimensions,
    DistributedWeight,
    Product,
    WeightResult,
)
from .weight_distributor import WeightDistributor

__version__ = "1.0.0"
__all__ = [
    # Models
    "Dimensions",
    "Box",
    "Product",
    "WeightResult",
    "BoxSelectionResult",
    "DistributedWeight",
    # Core classes
    "DimCalc",
    "BoxSelector",
    "WeightDistributor",
    # Exceptions
    "DimCalcError",
    "InvalidDimensionsError",
    "NoBoxAvailableError",
    "InvalidConfigError",
]
