"""Custom exceptions for dimcalc library."""


class DimCalcError(Exception):
    """Base exception for dimcalc library."""

    pass


class InvalidDimensionsError(DimCalcError):
    """Raised when dimensions are invalid (zero or negative)."""

    def __init__(self, dimension_name: str, value: float):
        self.dimension_name = dimension_name
        self.value = value
        super().__init__(f"Invalid {dimension_name}: {value} (must be positive)")


class NoBoxAvailableError(DimCalcError):
    """Raised when no box can fit the products."""

    def __init__(self, required_volume: float, max_dimension: float):
        self.required_volume = required_volume
        self.max_dimension = max_dimension
        super().__init__(
            f"No box available for volume={required_volume}cm³, "
            f"max_dimension={max_dimension}cm"
        )


class InvalidConfigError(DimCalcError):
    """Raised when configuration is invalid."""

    pass
