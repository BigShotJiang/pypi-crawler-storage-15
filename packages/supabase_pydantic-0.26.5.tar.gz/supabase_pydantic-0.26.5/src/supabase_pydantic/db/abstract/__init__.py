"""Abstract base classes for database operations."""
