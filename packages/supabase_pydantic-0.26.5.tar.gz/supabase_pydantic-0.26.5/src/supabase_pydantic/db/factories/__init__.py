"""Factory classes for database operations."""
