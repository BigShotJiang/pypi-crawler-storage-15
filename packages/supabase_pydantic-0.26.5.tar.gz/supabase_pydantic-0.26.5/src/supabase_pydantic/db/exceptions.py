class ConnectionError(Exception):
    """Raised when a connection to the Supabase API cannot be established."""

    pass
