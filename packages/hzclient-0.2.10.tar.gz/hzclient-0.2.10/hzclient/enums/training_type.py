from enum import IntEnum

class TrainingType(IntEnum):
  STAMINA = 1
  STRENGTH = 2
  CRITICAL = 3
  DODGE = 4
  NONE = 0