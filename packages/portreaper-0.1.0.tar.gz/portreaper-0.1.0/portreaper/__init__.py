# PortReaper
# The Grim Reaper for port-hogging processes

__version__ = "0.1.0"
__author__ = "Your Name"
__description__ = "Find, kill, scan, and monitor network ports with deadly precision"

from .main import cli

__all__ = ["cli"]