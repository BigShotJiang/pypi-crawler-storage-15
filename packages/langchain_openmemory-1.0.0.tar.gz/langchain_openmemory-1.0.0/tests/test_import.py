def test_import():
    from langchain_openmemory import Memory
    assert Memory is not None
