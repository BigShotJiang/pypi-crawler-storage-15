import logging
import operator
from core.utils.OPTools import OPTools
from core.smc.SMCBase import SMCBase


class SMCStruct(SMCBase):
    BULLISH_TREND = 'Bullish'
    BEARISH_TREND = 'Bearish'
    STRUCT_COL = "struct"
    STRUCT_HIGH_COL = "struct_high"
    STRUCT_LOW_COL = "struct_low"
    STRUCT_MID_COL = "struct_mid"
    STRUCT_HIGH_INDEX_COL = "struct_high_index"
    STRUCT_LOW_INDEX_COL = "struct_low_index"
    STRUCT_DIRECTION_COL = "struct_direction"
    HIGH_START_COL = "high_start"
    LOW_START_COL = "low_start"
    DIRECTION_COL = "direction"

    def __init__(self):  
        super().__init__()
        self.logger = logging.getLogger(__name__)
      
   
    def build_struct(self, data, tf=None, is_struct_body_break=True, struct_timeout_bars=100):
        """处理价格结构,识别高低点突破和结构方向
        
        Args:
            data: 数据框
            tf: 时间周期
            window: 寻找结构极值的窗口大小
            is_struct_body_break: 是否使用收盘价判断突破
            struct_timeout_bars: 结构点超时阈值（K线数量），默认100根K线
                               设置为0或None禁用超时重置功能
            
        Returns:
            处理后的数据框,包含结构相关列
        """
        # 参数验证
        if struct_timeout_bars is not None and struct_timeout_bars < 0:
            raise ValueError(
                f"struct_timeout_bars must be non-negative or None, "
                f"got {struct_timeout_bars}"
            )
        
        # 复制数据并去掉最后一条记录，因为最后一条记录不是完成状态的K线
        # 根据时间周期处理数据框
        df = data.copy()
        if tf == '1m':
            df = df.iloc[:-1]  # 1分钟周期去掉最后一条未完成的K线
            
            
        check_columns = [self.HIGH_COL, self.LOW_COL, self.CLOSE_COL]
        self.check_columns(df, check_columns)
        
        # 初始化结构相关列
        # 定义结构相关的列名
        struct_columns = [self.STRUCT_COL, self.STRUCT_HIGH_COL, self.STRUCT_LOW_COL, 
                         self.STRUCT_HIGH_INDEX_COL, self.STRUCT_LOW_INDEX_COL, self.STRUCT_DIRECTION_COL, self.DIRECTION_COL]
        
        # 初始化结构相关列的默认值
        default_values = {
            self.STRUCT_COL: None,  # 结构类型列初始化为None
            self.STRUCT_HIGH_COL: self.toDecimal('0.0'),  # 结构高点价格初始化为0
            self.STRUCT_LOW_COL: self.toDecimal('0.0'),  # 结构低点价格初始化为0
            self.STRUCT_HIGH_INDEX_COL: 0,  # 结构高点索引初始化为0 
            self.STRUCT_LOW_INDEX_COL: 0,  # 结构低点索引初始化为0
            self.STRUCT_DIRECTION_COL: None,  # 结构方向初始化为0
            self.DIRECTION_COL: 0  # 结构方向初始化为0
        }
        
        # 为每个结构列赋默认值
        for col in struct_columns:
            df[col] = default_values[col]
            
        # 初始化结构变量
        structure = {
            self.HIGH_COL: df[self.HIGH_COL].iloc[0],
            self.LOW_COL: df[self.LOW_COL].iloc[0],
            self.HIGH_START_COL: -1,
            self.LOW_START_COL: -1,
            self.DIRECTION_COL: 0
        }

        # 确定突破判断列
        break_price_col = self.CLOSE_COL if is_struct_body_break else self.HIGH_COL
        break_price_col_low = self.CLOSE_COL if is_struct_body_break else self.LOW_COL
        structLabelNo = 0

        for i in range(1, len(df)):
            curr_prices = {
                self.HIGH_COL: self.toDecimal(df[break_price_col].iloc[i]),
                self.LOW_COL: self.toDecimal(df[break_price_col_low].iloc[i])
            }
            
            # # 获取前3根K线价格
            # prev_prices = {
            #     self.HIGH_COL: df[break_price_col].iloc[i-3:i].values,
            #     self.LOW_COL: df[break_price_col_low].iloc[i-3:i].values
            # }

            # 检查结构点超时并重置（在结构突破检查之前）
            try:
                if struct_timeout_bars:
                    is_high_timeout, is_low_timeout = self._check_structure_timeout(
                        i, structure, struct_timeout_bars
                    )
                    
                    # 处理高点超时
                    if is_high_timeout:
                        old_high = structure[self.HIGH_COL]
                        old_high_index = structure[self.HIGH_START_COL]
                        duration = i - old_high_index
                        
                        structure = self._reset_structure_point(
                            df, i, structure, reset_type='high'
                        )
                        
                        self.logger.info(
                            f"Structure high timeout reset at index {i}: "
                            f"{old_high} -> {structure[self.HIGH_COL]}, "
                            f"duration: {duration} bars"
                        )
                    
                    # 处理低点超时
                    if is_low_timeout:
                        old_low = structure[self.LOW_COL]
                        old_low_index = structure[self.LOW_START_COL]
                        duration = i - old_low_index
                        
                        structure = self._reset_structure_point(
                            df, i, structure, reset_type='low'
                        )
                        
                        self.logger.info(
                            f"Structure low timeout reset at index {i}: "
                            f"{old_low} -> {structure[self.LOW_COL]}, "
                            f"duration: {duration} bars"
                        )
            except Exception as e:
                self.logger.error(f"Error in structure timeout check at index {i}: {e}")
                # 继续执行，不中断主流程

            # 判断结构突破
            is_high_broken = self._check_structure_break(
                curr_price=curr_prices[self.HIGH_COL],
                struct_price=structure[self.HIGH_COL],
                df = df,
                struct_start = structure[self.HIGH_START_COL],
                mode=self.HIGH_COL
            )

 
            is_low_broken = self._check_structure_break(
                curr_price=curr_prices[self.LOW_COL],
                struct_price=structure[self.LOW_COL],
                df = df,
                struct_start = structure[self.LOW_START_COL],
                mode=self.LOW_COL
            )
  
            # 处理低点突破
            if is_low_broken:
                extreme_idx = self._get_structure_extreme_bar(
                    df, i, 
                    struct_index=structure[self.LOW_START_COL],
                    mode=self.HIGH_COL
                )
                
                if extreme_idx != 0:
                    struct_type = 'SMS' if structure[self.DIRECTION_COL] == 1 else 'CHOCH'
                     # 使用字典优化结构类型判断逻辑
                    if struct_type == 'CHOCH':
                        structLabelNo = 0
                    else:  # struct_type == 'SMS'
                        if structLabelNo == 0:
                            structLabelNo = 1
                        elif structLabelNo == 1:
                            struct_type = 'BOS'
                    structure = self._handle_structure_break(
                        df, i, structure,
                        break_type=self.LOW_COL,
                        struct_type=struct_type,
                        extreme_idx=extreme_idx
                    )
                else:
                    is_low_broken = False

            # 处理高点突破    
            if is_high_broken :
                extreme_idx = self._get_structure_extreme_bar(
                    df, i,
                    struct_index=structure[self.HIGH_START_COL],
                    mode=self.LOW_COL
                )
                
                if extreme_idx != 0:
                    # 根据方向判断结构类型
                    struct_type = 'SMS' if structure[self.DIRECTION_COL] == 2 else 'CHOCH'
                    
                    # 使用字典优化结构类型判断逻辑
                    if struct_type == 'CHOCH':
                        structLabelNo = 0
                    else:  # struct_type == 'SMS'
                        if structLabelNo == 0:
                            structLabelNo = 1
                        elif structLabelNo == 1:
                            struct_type = 'BOS'

                    structure = self._handle_structure_break(
                        df, i, structure, 
                        break_type=self.HIGH_COL,
                        struct_type=struct_type,
                        extreme_idx=extreme_idx
                    )
                else:
                    is_high_broken = False

            # 如果没有突破发生，更新当前结构
            if not any([is_low_broken, is_high_broken]):
                structure = self._update_current_structure(
                    df, i, structure,
                    is_struct_body_break=is_struct_body_break
                )
            
            # 更新数据框结构列
            self._update_structure_columns(df, i, structure)

        return df

    def _get_structure_extreme_bar(self, df, bar_index,  struct_index, mode='high'):
        """
        获取结构最高点或最低点
        :param df: DataFrame数据
        :param bar_index: 当前K线索引
        :param struct_index: 结构开始索引
        :param mode: high 寻找最高点,low 寻找最低点
        :return: 结构极值点的索引
        """
        df = df.copy()
        window_start = max(0, struct_index)
        
        window = df.iloc[window_start : bar_index + 1]
 
        
        # 获取窗口内的极值点索引
        if mode == self.HIGH_COL:
            # extremeBar = window[self.HIGH_COL].argmax() 
            extremeBar = window[self.HIGH_COL].idxmax() 
            price_col = self.HIGH_COL
            comp_func = lambda x, y: x > y
        else:
            # extremeBar = window[self.LOW_COL].argmin() 
            extremeBar = window[self.LOW_COL].idxmin() 
            price_col = self.LOW_COL
            comp_func = lambda x, y: x < y

        # 初始化记录点
        pivot = 0
        # 从后向前遍历寻找结构极值点
        # for i in range(lookback - 1, -1, -1):
        for idx in range(bar_index, struct_index, -1):
            # 计算当前位置的索引
            # idx = bar_index - i
            if idx < 2 or idx >= len(df):
                continue
                
            price_prev = df[price_col].iloc[idx - 1]
            price_prev2 = df[price_col].iloc[idx - 2]
            price_curr = df[price_col].iloc[idx]
            
            # 记录满足条件的点位
            if (comp_func(price_prev, price_prev2) and
                not comp_func(price_curr, price_prev) 
                and idx - 1 >= extremeBar
                ):
                if pivot == 0:
                    pivot = idx - 1
                    continue
                else:                   
                    # 比较当前点位与之前记录的极值点的价格,因为在区间内有多个极致点，需要比较
                    if comp_func(df[price_col].iloc[idx-1], df[price_col].iloc[pivot]):
                        pivot = idx - 1
                
        return pivot

    def _check_structure_break(self, curr_price, struct_price, df, struct_start, mode='high'):
        """检查结构是否突破"""
        comp = operator.gt if mode == self.HIGH_COL else operator.lt
        # reverse_comp = operator.le if mode == self.HIGH_COL else operator.ge
        
        # basic_break = (
        #     comp(curr_price, struct_price) and
        #     all(reverse_comp(p, struct_price) for p in prev_prices) and
        #     all(i-j > struct_start for j in range(1,4))
        # )
        
        direction_break = comp(curr_price, struct_price)


        # 判断 是否是
        extreme_idx = self._get_structure_extreme_bar(
            df, bar_index=struct_start+1,
            struct_index=struct_start,
            mode=mode
        )

        is_extreme = extreme_idx != 0
        
        return direction_break and is_extreme

    def _check_structure_timeout(self, current_index, structure, timeout_bars):
        """检查结构点是否超时
        
        Args:
            current_index: 当前K线索引
            structure: 当前结构字典
            timeout_bars: 超时阈值（K线数量），0或None表示禁用
            
        Returns:
            tuple: (is_high_timeout, is_low_timeout)
        """
        # 如果禁用超时检查，返回False
        if timeout_bars is None or timeout_bars == 0:
            return (False, False)
        
        # 检查高点是否超时
        is_high_timeout = False
        if structure[self.HIGH_START_COL] >= 0:  # 不是初始状态
            high_duration = current_index - structure[self.HIGH_START_COL]
            is_high_timeout = high_duration > timeout_bars
        
        # 检查低点是否超时
        is_low_timeout = False
        if structure[self.LOW_START_COL] >= 0:  # 不是初始状态
            low_duration = current_index - structure[self.LOW_START_COL]
            is_low_timeout = low_duration > timeout_bars
        
        return (is_high_timeout, is_low_timeout)

    def _reset_structure_point(self, df, current_index, structure, reset_type='high'):
        """重置结构高点或低点
        
        Args:
            df: DataFrame
            current_index: 当前K线索引
            structure: 当前结构字典
            reset_type: 'high' 或 'low'
            
        Returns:
            dict: 更新后的结构字典
        """
        # 复制当前结构字典避免直接修改
        new_structure = structure.copy()
        
        if reset_type == 'high':
            # 重置高点
            new_structure[self.HIGH_COL] = self.toDecimal(df[self.HIGH_COL].iloc[current_index])
            new_structure[self.HIGH_START_COL] = current_index
        else:  # reset_type == 'low'
            # 重置低点
            new_structure[self.LOW_COL] = self.toDecimal(df[self.LOW_COL].iloc[current_index])
            new_structure[self.LOW_START_COL] = current_index
        
        # 保持结构方向不变
        # DIRECTION_COL 不需要修改
        
        return new_structure

    def _handle_structure_break(self, df, i, structure, break_type, struct_type, extreme_idx ):
        """处理结构突破"""
        is_high_break = break_type == self.HIGH_COL

        # 更新结构信息
        new_structure = structure.copy()
        new_structure[self.DIRECTION_COL] = 2 if is_high_break else 1
        
        if is_high_break:
            new_structure.update({
                self.LOW_COL: self.toDecimal(df[self.LOW_COL].iloc[extreme_idx]),
                self.HIGH_COL: self.toDecimal(df[self.HIGH_COL].iloc[i]),
                self.LOW_START_COL: extreme_idx,
                self.HIGH_START_COL: i
            })
        else:
            new_structure.update({
                self.HIGH_COL: self.toDecimal(df[self.HIGH_COL].iloc[extreme_idx]),
                self.LOW_COL: self.toDecimal(df[self.LOW_COL].iloc[i]),
                self.HIGH_START_COL: extreme_idx,
                self.LOW_START_COL: i
            })
            
        # 更新DataFrame结构信息
        # df.at[i, self.STRUCT_DIRECTION_COL] = new_structure[self.DIRECTION_COL] 

        df.at[i, self.STRUCT_DIRECTION_COL] = self.BULLISH_TREND if is_high_break else self.BEARISH_TREND
        df.at[i, self.STRUCT_COL] = f"{self.BULLISH_TREND if is_high_break else self.BEARISH_TREND}_{struct_type}"
        
        return new_structure

    def _update_current_structure(self, df, i, structure, is_struct_body_break):
        """更新当前结构"""
        new_structure = structure.copy()
        
        # 检查是否需要更新高点
        if (structure[self.DIRECTION_COL] in (2,0)) and self.toDecimal(df.at[i,self.HIGH_COL]) > structure[self.HIGH_COL]:
            # if not (is_struct_body_break and all(i-j > structure[self.HIGH_START_COL] for j in range(1,4))):
            new_structure[self.HIGH_COL] = df.at[i,self.HIGH_COL]
            new_structure[self.HIGH_START_COL] = i
                
        # 检查是否需要更新低点
        elif (structure[self.DIRECTION_COL] in (1,0)) and self.toDecimal(df.at[i,self.LOW_COL]) < structure[self.LOW_COL]:
            # if not (is_struct_body_break and all(i-j > structure[self.LOW_START_COL] for j in range(1,4))):
            new_structure[self.LOW_COL] = df.at[i,self.LOW_COL]
            new_structure[self.LOW_START_COL] = i
                
        return new_structure

    def _update_structure_columns(self, df, i, structure):
        """更新数据框中的结构列"""
        df.at[i, self.STRUCT_HIGH_COL] = self.toDecimal(structure[self.HIGH_COL])
        df.at[i, self.STRUCT_LOW_COL] = self.toDecimal(structure[self.LOW_COL] )
        df.at[i, self.STRUCT_HIGH_INDEX_COL] = structure[self.HIGH_START_COL]
        df.at[i, self.STRUCT_LOW_INDEX_COL] = structure[self.LOW_START_COL]
        df.at[i, self.DIRECTION_COL] = structure[self.DIRECTION_COL]

    def get_latest_struct(self, df, is_struct_body_break=True):
        """
        获取最新的结构
        """
        check_columns = [self.STRUCT_COL]
        # if not self.check_columns(df, check_columns):
        try :
            self.check_columns(df, check_columns)
        except ValueError:
            df = self.build_struct(df, is_struct_body_break=is_struct_body_break)
            # raise ValueError("struct not found in DataFrame")
 
        data = df.copy()
       
        # 筛选有效结构且在prd范围内的数据
        last_struct = None
        mask = data[self.STRUCT_COL].notna()
        valid_structs = data[ mask ]
        if not valid_structs.empty:
            # 获取最近的结构
            last_struct = valid_structs.iloc[-1]
            return {
                self.STRUCT_COL: last_struct[self.STRUCT_COL],
                self.STRUCT_HIGH_COL: last_struct[self.STRUCT_HIGH_COL],
                self.STRUCT_LOW_COL: last_struct[self.STRUCT_LOW_COL], 
                self.STRUCT_MID_COL: (last_struct[self.STRUCT_HIGH_COL] + last_struct[self.STRUCT_LOW_COL]) / 2,
                self.STRUCT_HIGH_INDEX_COL: last_struct[self.STRUCT_HIGH_INDEX_COL],
                self.STRUCT_LOW_INDEX_COL: last_struct[self.STRUCT_LOW_INDEX_COL],
                self.STRUCT_DIRECTION_COL: last_struct[self.STRUCT_DIRECTION_COL]
            }

        return last_struct

