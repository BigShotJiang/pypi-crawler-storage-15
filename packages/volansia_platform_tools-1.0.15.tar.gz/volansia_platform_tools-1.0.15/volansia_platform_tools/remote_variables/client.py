"""Remote variables client"""
from typing import Any, Dict, List, Optional, TypeVar

from ..http_client import HTTPClient, get_http_client

T = TypeVar("T")


class RemoteVariable:
    """Remote variable model"""

    def __init__(self, id: str, value: Any):
        self.id = id
        self.value = value


class RemoteVariablesClient:
    """Client for retrieving remote variables"""

    def __init__(
        self,
        http_client: HTTPClient,
        endpoint: str,
        header_propagation_prefixes: Optional[List[str]] = None,
    ):
        """
        Initialize remote variables client

        Args:
            http_client: HTTP client instance
            endpoint: API endpoint base URL
            header_propagation_prefixes: Header prefixes to propagate
        """
        self.http_client = http_client
        self.endpoint = endpoint.rstrip("/")
        self.header_propagation_prefixes = header_propagation_prefixes or []

    def get_variable(self, id: str, headers: Optional[Dict[str, str]] = None) -> Optional[RemoteVariable]:
        """
        Get a single remote variable

        Args:
            id: Variable ID
            headers: Optional headers to propagate

        Returns:
            RemoteVariable or None
        """
        url = f"{self.endpoint}/platform/remoteVariables/{id}"
        response = self.http_client.get(url, headers=headers or {})
        response.raise_for_status()
        data = response.json()
        return RemoteVariable(id=data["id"], value=data.get("value"))

    def get_variables(
        self, ids: Optional[List[str]] = None, headers: Optional[Dict[str, str]] = None
    ) -> List[RemoteVariable]:
        """
        Get remote variables

        Args:
            ids: Optional list of variable IDs (if None, gets all)
            headers: Optional headers to propagate

        Returns:
            List of RemoteVariable
        """
        if ids:
            url = f"{self.endpoint}/platform/remoteVariables"
            response = self.http_client.post(
                url, json={"ids": ids}, headers=headers or {}
            )
        else:
            url = f"{self.endpoint}/platform/remoteVariables"
            response = self.http_client.get(url, headers=headers or {})

        response.raise_for_status()
        data = response.json()
        return [
            RemoteVariable(id=item["id"], value=item.get("value"))
            for item in data
        ]


def get_remote_variables_client(
    endpoint: str, header_propagation_prefixes: Optional[List[str]] = None
) -> RemoteVariablesClient:
    """
    Get a remote variables client

    Args:
        endpoint: API endpoint base URL
        header_propagation_prefixes: Header prefixes to propagate

    Returns:
        RemoteVariablesClient instance
    """
    http_client = get_http_client("unknown", internal=True)
    return RemoteVariablesClient(http_client, endpoint, header_propagation_prefixes)

