"""Google Cloud Pub/Sub client"""
from typing import Any, Dict, Optional

from google.cloud import pubsub_v1
from google.cloud.pubsub_v1 import PublisherClient, SubscriberClient

from ..logging import LoggerFactory


class PubSubClient:
    """Google Cloud Pub/Sub client"""

    def __init__(
        self,
        publisher: PublisherClient,
        subscriber: SubscriberClient,
        project_id: str,
        logger_factory: LoggerFactory,
    ):
        """
        Initialize Pub/Sub client

        Args:
            publisher: Publisher client
            subscriber: Subscriber client
            project_id: GCP project ID
            logger_factory: Logger factory
        """
        self.publisher = publisher
        self.subscriber = subscriber
        self.project_id = project_id
        self.logger = logger_factory.get_logger("PubSubClient")

    def push_event_to_queue(self, topic: str, message: Dict[str, Any]) -> None:
        """
        Publish a message to a topic

        Args:
            topic: Pub/Sub topic name
            message: Message to publish (will be JSON serialized)
        """
        import json

        topic_path = self.publisher.topic_path(self.project_id, topic)
        message_data = json.dumps(message).encode("utf-8")

        future = self.publisher.publish(topic_path, message_data)
        message_id = future.result()
        self.logger.info(
            f"Pushed event to topic {topic} with message id {message_id}.",
            {"topic": topic, "messageId": message_id},
        )


def get_pubsub_client(
    logger_factory: LoggerFactory,
    project_id: Optional[str] = None,
    **pubsub_options: Any,
) -> PubSubClient:
    """
    Get a Pub/Sub client instance

    Args:
        logger_factory: Logger factory
        project_id: GCP project ID (optional, can be inferred from credentials)
        **pubsub_options: Additional Pub/Sub client options

    Returns:
        PubSubClient instance
    """
    publisher = pubsub_v1.PublisherClient(**pubsub_options)
    subscriber = pubsub_v1.SubscriberClient(**pubsub_options)

    if not project_id:
        # Try to get from environment or credentials
        import os
        project_id = os.getenv("GOOGLE_CLOUD_PROJECT") or os.getenv("GCP_PROJECT")

    if not project_id:
        raise ValueError("project_id must be provided or set in environment")

    return PubSubClient(publisher, subscriber, project_id, logger_factory)

