"""Firebase Authentication client"""
from typing import Optional, Tuple

from firebase_admin import auth as firebase_auth

from ..http_client import HTTPClient
from ..logging import LoggerFactory


class AuthClient:
    """Firebase Authentication client"""

    def __init__(
        self,
        http_client: HTTPClient,
        firebase_auth_instance: firebase_auth.Client,
        firebase_api_key: str,
        firebase_url: str,
        logger_factory: LoggerFactory,
    ):
        """
        Initialize auth client

        Args:
            http_client: HTTP client instance
            firebase_auth_instance: Firebase Admin Auth instance
            firebase_api_key: Firebase API key
            firebase_url: Firebase URL
            logger_factory: Logger factory
        """
        self.http_client = http_client
        self.auth = firebase_auth_instance
        self.firebase_api_key = firebase_api_key
        self.firebase_url = firebase_url
        self.logger = logger_factory.get_logger("AuthClient")

    def get_user_id(self, authorization_header: Optional[str] = None) -> Optional[str]:
        """
        Get user ID from authorization header

        Args:
            authorization_header: Authorization header value

        Returns:
            User ID or None
        """
        token = self._get_token_from_header(authorization_header)
        if not token:
            return None

        try:
            claims = self.auth.verify_id_token(token)
            return claims.get("uid")
        except Exception as e:
            self.logger.error("Failed to verify token", {"error": str(e)})
            return None

    def get_user_id_or_guest_id(
        self, authorization_header: Optional[str] = None
    ) -> Tuple[Optional[str], Optional[str]]:
        """
        Get user ID or guest ID

        Returns:
            Tuple of (user_id, guest_id)
        """
        token = self._get_token_from_header(authorization_header)
        if not token:
            return None, None

        try:
            # Try to verify as guest token first
            guest_token = self._verify_guest_token(token)
            if guest_token:
                claims = self.auth.verify_id_token(guest_token)
                if claims.get("isGuest"):
                    return None, claims.get("uid")
                return claims.get("uid"), None

            # Try regular token
            claims = self.auth.verify_id_token(token)
            return claims.get("uid"), None
        except Exception as e:
            self.logger.error("Failed to verify token", {"error": str(e)})
            return None, None

    def _get_token_from_header(self, authorization_header: Optional[str]) -> Optional[str]:
        """Extract token from authorization header"""
        if not authorization_header:
            return None
        parts = authorization_header.split(" ")
        return parts[1] if len(parts) > 1 else None

    def _verify_guest_token(self, token: str) -> Optional[str]:
        """Verify guest token and return ID token"""
        url = f"{self.firebase_url}/accounts:signInWithCustomToken?key={self.firebase_api_key}"
        try:
            response = self.http_client.post(
                url, json={"token": token, "returnSecureToken": True}
            )
            if response.status_code == 200:
                data = response.json()
                return data.get("idToken")
        except Exception as e:
            self.logger.warn("Failed to verify guest token", {"error": str(e)})
        return None

