"""HTTP client with request context propagation"""
from typing import Any, Dict, Optional

import requests
from requests import Response

from ..request_context import REQUEST_ID_HEADER_NAME, CLIENT_ID_HEADER_NAME
from ..request_context.holder import RequestContextHolder


class HTTPClient:
    """HTTP client with request context propagation"""

    def __init__(
        self,
        client_id: str,
        internal: bool = True,
        request_context_holder: Optional[RequestContextHolder] = None,
        session: Optional[requests.Session] = None,
    ):
        """
        Initialize HTTP client

        Args:
            client_id: ID for the service creating this instance
            internal: True if making requests to internal services
            request_context_holder: Request context holder for header propagation
            session: Optional requests Session instance
        """
        self.client_id = client_id
        self.internal = internal
        self.request_context_holder = request_context_holder
        self.session = session or requests.Session()
        self.default_headers: Dict[str, str] = {}

    def add_default_header(self, name: str, value: str) -> None:
        """Add a default header to all requests"""
        self.default_headers[name] = value

    def _prepare_headers(self) -> Dict[str, str]:
        """Prepare headers with context and defaults"""
        headers = self.default_headers.copy()

        if self.internal and self.request_context_holder:
            request_context = self.request_context_holder.get_request_context()
            if request_context:
                if request_context.request_id:
                    headers[REQUEST_ID_HEADER_NAME] = request_context.request_id
                headers[CLIENT_ID_HEADER_NAME] = self.client_id

        return headers

    def request(
        self, method: str, url: str, **kwargs: Any
    ) -> Response:
        """
        Make an HTTP request

        Args:
            method: HTTP method (GET, POST, etc.)
            url: Request URL
            **kwargs: Additional arguments passed to requests

        Returns:
            Response object
        """
        headers = self._prepare_headers()
        if "headers" in kwargs:
            headers.update(kwargs["headers"])
        kwargs["headers"] = headers

        return self.session.request(method, url, **kwargs)

    def get(self, url: str, **kwargs: Any) -> Response:
        """Make a GET request"""
        return self.request("GET", url, **kwargs)

    def post(self, url: str, **kwargs: Any) -> Response:
        """Make a POST request"""
        return self.request("POST", url, **kwargs)

    def put(self, url: str, **kwargs: Any) -> Response:
        """Make a PUT request"""
        return self.request("PUT", url, **kwargs)

    def delete(self, url: str, **kwargs: Any) -> Response:
        """Make a DELETE request"""
        return self.request("DELETE", url, **kwargs)


def get_http_client(
    client_id: str,
    internal: bool = True,
    request_context_holder: Optional[RequestContextHolder] = None,
    session: Optional[requests.Session] = None,
) -> HTTPClient:
    """
    Get an HTTP client instance

    Args:
        client_id: ID for the service
        internal: True if making internal requests
        request_context_holder: Request context holder
        session: Optional requests Session

    Returns:
        HTTPClient instance
    """
    return HTTPClient(client_id, internal, request_context_holder, session)

