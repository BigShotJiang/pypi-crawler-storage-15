"""Logger factory for creating logger instances"""
import logging as std_logging
import os
from typing import Any, Callable, Dict, Optional

import structlog
from structlog.types import Processor

from .logger import Logger
from .structlog_logger import StructlogLogger


class LoggerFactory:
    """Factory for creating logger instances"""

    def __init__(
        self,
        service: str,
        environment: str,
        level: str = "info",
        additional_meta: Optional[Dict[str, Any]] = None,
        request_context_holder: Optional[Any] = None,
        extra_properties_factory: Optional[Callable[[], Dict[str, Any]]] = None,
    ):
        """
        Initialize logger factory

        Args:
            service: Name of the service producing logs
            environment: Environment name (e.g., 'production', 'development')
            level: Log level ('debug', 'info', 'warn', 'error')
            additional_meta: Additional metadata to include in all logs
            request_context_holder: Request context holder for adding request info
            extra_properties_factory: Factory function for additional log properties
        """
        self.service = service
        self.environment = environment
        self.level = level
        self.additional_meta = additional_meta or {}
        self.request_context_holder = request_context_holder
        self.extra_properties_factory = extra_properties_factory

        # Configure structlog
        processors: list[Processor] = [
            structlog.contextvars.merge_contextvars,
            structlog.processors.add_log_level,
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.processors.JSONRenderer(),
        ]

        # Add New Relic processor if available
        try:
            import newrelic.agent
            # New Relic will automatically capture logs if agent is initialized
            pass
        except ImportError:
            pass

        structlog.configure(
            processors=processors,
            wrapper_class=structlog.make_filtering_bound_logger(
                self._get_log_level(level)
            ),
            context_class=dict,
            logger_factory=structlog.PrintLoggerFactory(),
            cache_logger_on_first_use=True,
        )

    def _get_log_level(self, level: str) -> int:
        """Convert string level to logging level"""
        level_map = {
            "debug": std_logging.DEBUG,
            "info": std_logging.INFO,
            "warn": std_logging.WARNING,
            "error": std_logging.ERROR,
        }
        return level_map.get(level.lower(), std_logging.INFO)

    def get_logger(self, name: str) -> Logger:
        """
        Get a logger instance

        Args:
            name: Name of the logger (typically class/module name)

        Returns:
            Logger instance
        """
        logger = structlog.get_logger(name)
        return StructlogLogger(
            logger=logger,
            service=self.service,
            environment=self.environment,
            name=name,
            additional_meta=self.additional_meta,
            request_context_holder=self.request_context_holder,
            extra_properties_factory=self.extra_properties_factory,
        )


def get_access_log_middleware(logger_factory: LoggerFactory):
    """
    Get access log middleware for Flask/FastAPI

    Note: This is a placeholder. Implement based on your web framework.
    """
    logger = logger_factory.get_logger("access-log")

    def middleware(request, response):
        # Implement based on your framework
        logger.info(
            "HTTP request",
            {
                "method": getattr(request, "method", "UNKNOWN"),
                "path": getattr(request, "path", "UNKNOWN"),
                "status": getattr(response, "status_code", None),
            },
        )

    return middleware

