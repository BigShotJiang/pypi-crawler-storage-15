"""Structlog-based logger implementation"""
from typing import Any, Callable, Dict, Optional

import structlog

from .logger import Logger


class StructlogLogger(Logger):
    """Structlog-based logger implementation"""

    def __init__(
        self,
        logger: structlog.BoundLogger,
        service: str,
        environment: str,
        name: str,
        additional_meta: Dict[str, Any],
        request_context_holder: Optional[Any] = None,
        extra_properties_factory: Optional[Callable[[], Dict[str, Any]]] = None,
    ):
        self.logger = logger
        self.service = service
        self.environment = environment
        self.name = name
        self.additional_meta = additional_meta
        self.request_context_holder = request_context_holder
        self.extra_properties_factory = extra_properties_factory

    def _build_log_data(
        self, message: str, context: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Build log data with context"""
        log_data = {
            "message": message,
            "service": self.service,
            "environment": self.environment,
            "name": self.name,
            **self.additional_meta,
        }

        # Add request context if available
        if self.request_context_holder:
            try:
                request_context = self.request_context_holder.get_request_context()
                if request_context:
                    log_data["requestId"] = getattr(request_context, "request_id", None)
                    log_data["clientId"] = getattr(request_context, "client_id", None)
            except Exception:
                pass

        # Add extra properties
        if self.extra_properties_factory:
            try:
                extra = self.extra_properties_factory()
                log_data.update(extra)
            except Exception:
                pass

        # Add context data
        if context:
            log_data.update(context)

        return log_data

    def debug(self, message: str, context: Optional[Dict[str, Any]] = None) -> None:
        """Log debug message"""
        self.logger.debug(**self._build_log_data(message, context))

    def info(self, message: str, context: Optional[Dict[str, Any]] = None) -> None:
        """Log info message"""
        self.logger.info(**self._build_log_data(message, context))

    def warn(self, message: str, context: Optional[Dict[str, Any]] = None) -> None:
        """Log warning message"""
        self.logger.warning(**self._build_log_data(message, context))

    def error(self, message: str, context: Optional[Dict[str, Any]] = None) -> None:
        """Log error message"""
        self.logger.error(**self._build_log_data(message, context))

    def log(self, message: str, context: Optional[Dict[str, Any]] = None) -> None:
        """Log message (alias for info)"""
        self.info(message, context)

