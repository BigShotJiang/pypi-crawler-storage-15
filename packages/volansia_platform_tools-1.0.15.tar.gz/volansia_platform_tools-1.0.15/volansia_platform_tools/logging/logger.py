"""Logger interface"""
from abc import ABC, abstractmethod
from typing import Any, Dict, Optional


class Logger(ABC):
    """Logger interface"""

    @abstractmethod
    def debug(self, message: str, context: Optional[Dict[str, Any]] = None) -> None:
        """Log a debug message"""
        pass

    @abstractmethod
    def info(self, message: str, context: Optional[Dict[str, Any]] = None) -> None:
        """Log an info message"""
        pass

    @abstractmethod
    def warn(self, message: str, context: Optional[Dict[str, Any]] = None) -> None:
        """Log a warning message"""
        pass

    @abstractmethod
    def error(self, message: str, context: Optional[Dict[str, Any]] = None) -> None:
        """Log an error message"""
        pass

    @abstractmethod
    def log(self, message: str, context: Optional[Dict[str, Any]] = None) -> None:
        """Log a message (alias for info)"""
        pass

