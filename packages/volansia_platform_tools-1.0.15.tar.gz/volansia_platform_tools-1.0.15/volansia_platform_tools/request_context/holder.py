"""Request context holder using contextvars"""
from contextvars import ContextVar
from typing import Generic, Optional, TypeVar

T = TypeVar("T")

REQUEST_ID_HEADER_NAME = "via-request-id"
CLIENT_ID_HEADER_NAME = "via-client-id"

_request_context_var: ContextVar[Optional["RequestContext"]] = ContextVar(
    "request_context", default=None
)


class RequestContext(Generic[T]):
    """Request-scoped context"""

    def __init__(self, request_id: str, client_id: str, context: T):
        self.request_id = request_id
        self.client_id = client_id
        self.context = context


class RequestContextHolder(Generic[T]):
    """Holder for request context using contextvars"""

    def __init__(self):
        self._context_var = _request_context_var

    def set_request_context(self, context: RequestContext[T]) -> None:
        """Set request context in current context"""
        self._context_var.set(context)

    def get_request_context(self) -> Optional[RequestContext[T]]:
        """Get request context from current context"""
        return self._context_var.get()

    def clear_request_context(self) -> None:
        """Clear request context"""
        self._context_var.set(None)


def get_request_context_holder() -> RequestContextHolder:
    """Get a new request context holder instance"""
    return RequestContextHolder()

