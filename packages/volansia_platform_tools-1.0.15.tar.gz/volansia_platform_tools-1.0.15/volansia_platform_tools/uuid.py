"""UUID utilities"""
import uuid as uuid_lib


def random_uuid() -> str:
    """Generate a random UUID v4 string"""
    return str(uuid_lib.uuid4())

