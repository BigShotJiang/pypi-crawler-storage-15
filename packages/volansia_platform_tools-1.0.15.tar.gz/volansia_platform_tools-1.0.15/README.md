# platform-tools-python

Python implementation of Volans AI platform tooling.

## Installation

```bash
pip install volansia-platform-tools
```

## Usage

### Logging

```python
from volansia_platform_tools import logging

# Create a logger factory
logger_factory = logging.LoggerFactory(
    service="my-service",
    environment="production",
    level="info",
    additional_meta={"region": "us-east-1"}
)

# Get a logger instance
logger = logger_factory.get_logger("MyClass")

# Use the logger
logger.info("User logged in", {"userId": "123"})
logger.error("Failed to process request", {"error": str(err)})
logger.warn("Rate limit approaching", {"remaining": 5})
logger.debug("Debug information", {"data": some_data})
```

### Request Context

```python
from volansia_platform_tools import request_context, uuid

# Create request context holder
holder = request_context.get_request_context_holder()

# Build request context
request_id = uuid.random_uuid()
client_id = request.headers.get("via-client-id", "unknown")

req_ctx = request_context.RequestContext(
    request_id=request_id,
    client_id=client_id,
    context={"ip": request.remote_addr}
)

# Set context
holder.set_request_context(req_ctx)

# Access context
ctx = holder.get_request_context()
print(ctx.request_id)
print(ctx.client_id)
```

### HTTP Client

```python
from volansia_platform_tools import http_client, request_context

# Create request context holder
holder = request_context.get_request_context_holder()

# Create HTTP client
client = http_client.get_http_client(
    client_id="my-service",
    internal=True,
    request_context_holder=holder
)

# Make requests
response = client.get("https://api.example.com/users")
response = client.post("https://api.example.com/users", json={"name": "John"})
```

### Redis

```python
from volansia_platform_tools import redis, logging

logger_factory = logging.LoggerFactory("my-service", "production")

# Create Redis client
redis_client = redis.get_redis_client(
    logger_factory,
    host="redis.example.com",
    port=6379,
    password="your-password"
)

# Use Redis
redis_client.set("key", {"name": "value"})
value = redis_client.get("key")
redis_client.set("key", "value", ttl=3600)  # With TTL
redis_client.delete("key:*")  # Delete by pattern
```

### Pub/Sub

```python
from volansia_platform_tools import pubsub, logging

logger_factory = logging.LoggerFactory("my-service", "production")

# Create Pub/Sub client
pubsub_client = pubsub.get_pubsub_client(
    logger_factory,
    project_id="my-project-id"
)

# Publish a message
pubsub_client.push_event_to_queue("my-topic", {
    "userId": "123",
    "action": "login"
})
```

### Remote Variables

```python
from volansia_platform_tools import remote_variables

# Create client
client = remote_variables.get_remote_variables_client(
    endpoint="https://config-api.example.com",
    header_propagation_prefixes=["via-"]
)

# Get a variable
var = client.get_variable("API_KEY")

# Get multiple variables
vars = client.get_variables(["API_KEY", "FEATURE_FLAG"])
```

### Authentication

```python
from volansia_platform_tools import auth
import firebase_admin
from firebase_admin import auth as firebase_auth

# Initialize Firebase
firebase_admin.initialize_app()

# Create auth client
auth_client = auth.AuthClient(
    http_client=http_client_instance,
    firebase_auth_instance=firebase_auth,
    firebase_api_key="your-api-key",
    firebase_url="https://identitytoolkit.googleapis.com",
    logger_factory=logger_factory
)

# Get user ID
user_id = auth_client.get_user_id(request.headers.get("Authorization"))

# Get user ID or guest ID
user_id, guest_id = auth_client.get_user_id_or_guest_id(
    request.headers.get("Authorization")
)
```

### Auth Utilities

```python
from volansia_platform_tools import auth, logging

logger_factory = logging.LoggerFactory("my-service", "production")

# Create auth utility
auth_util = auth.AuthUtil(logger_factory, seconds_allowed=30)

# Generate signature
timestamp = str(int(time.time()))
signature = auth_util.get_signature(api_key, shared_secret, timestamp)

# Generate auth header
auth_header = auth_util.get_auth_header(api_key, shared_secret, timestamp)

# Validate auth header
is_valid = auth_util.validate_auth_header(api_key, shared_secret, auth_header)
```

## Requirements

- Python 3.8+
- See `pyproject.toml` for dependencies

## License

UNLICENSED

