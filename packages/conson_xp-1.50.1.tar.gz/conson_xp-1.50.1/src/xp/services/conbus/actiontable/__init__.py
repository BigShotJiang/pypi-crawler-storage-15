"""Action table services for Conbus."""
