"""Server services for XP protocol variants."""
