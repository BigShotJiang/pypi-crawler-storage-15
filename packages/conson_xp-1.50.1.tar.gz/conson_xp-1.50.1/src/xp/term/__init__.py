"""TUI (Terminal User Interface) module for XP."""
