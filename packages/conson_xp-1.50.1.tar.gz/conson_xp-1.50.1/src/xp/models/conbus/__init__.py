"""Conbus communication models."""
