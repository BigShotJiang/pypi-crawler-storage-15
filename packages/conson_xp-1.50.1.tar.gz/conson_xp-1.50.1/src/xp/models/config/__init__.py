"""Configuration models package."""
