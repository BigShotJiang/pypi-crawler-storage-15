"""Term CLI commands package for TUI interfaces."""

from xp.cli.commands.term.term import term

__all__ = ["term"]
