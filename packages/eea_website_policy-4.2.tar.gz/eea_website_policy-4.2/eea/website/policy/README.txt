Overview
========
eea.website.policy is a revolutionary plone package that redefines Plone Add-ons.

  * See more: http://github.com/eea/eea.website.policy


Installation
============
  * Go to admin > Site Setup > Add-ons
  * Activate eea.website.policy


Authors
=======
  "European Environment Agency", mailto:eea-edw-a-team-alerts@googlegroups.com
