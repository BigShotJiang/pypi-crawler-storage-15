"""ReasonForge Statistics - Probability and Data Science
MCP server with 16 tools for statistics and data analysis."""
__version__ = "0.1.0"
