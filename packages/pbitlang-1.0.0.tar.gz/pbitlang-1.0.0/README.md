# PbitLang

**Domain-Specific Language for Thermodynamic Computing**

[![Python](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![License](https://img.shields.io/badge/license-Proprietary-red.svg)](LICENSE)

PbitLang is a domain-specific language for expressing Hamiltonians (energy functions) with compile-time physics validation. It's designed for thermodynamic computing systems including P-bits, Ising machines, and quantum annealers.

## Features

- **Type System**: Dedicated types for spins (Ising, Potts, clock, continuous)
- **Lattice Geometries**: Built-in support for chains, square, triangular, honeycomb, etc.
- **Physics Validation**: Compile-time warnings about frustration, critical temperatures, symmetry violations
- **Standard Library**: Common models (Ising, Heisenberg, Potts) pre-implemented
- **Zero Dependencies**: Core has no required dependencies

## Installation

```bash
pip install pbitlang
```

## Quick Start

```python
import pbitlang

# Define a Hamiltonian
source = '''
hamiltonian IsingChain(n: int, J: real) -> ising on chain(n) {
    coupling: sum((i,j) in neighbors) { -J * s[i] * s[j] }
}
'''

# Compile and instantiate
model = pbitlang.compile(source)
hamiltonian = model.instantiate(n=10, J=1.0)
```

## Example: 2D Ising Model

```pbitlang
hamiltonian IsingSquare2D {
    lattice: square(10, 10, periodic)
    spins: ising
    
    // Ferromagnetic coupling
    energy: -sum over neighbors(i, j) {
        J * s[i] * s[j]
    }
    
    // External field
    energy: -h * sum over i { s[i] }
    
    param J: real = 1.0
    param h: real = 0.1
}
```

## CLI Usage

```bash
# Compile a Hamiltonian file
pbitlang compile my_model.pbit

# Interactive REPL
pbitlang repl
```

## Documentation

- [Language Specification](https://github.com/dmjdxb/Thermodynamic-Computing-Platform-/blob/main/pbitlang/docs/SPECIFICATION.txt)
- [User Manual](https://github.com/dmjdxb/Thermodynamic-Computing-Platform-/blob/main/pbitlang/docs/USER_MANUAL.txt)

## Part of the Thermodynamic Computing Platform

PbitLang is part of the [Thermodynamic Computing Platform](https://github.com/dmjdxb/Thermodynamic-Computing-Platform-), a comprehensive software stack for P-bit and thermodynamic hardware.

## License

**Proprietary Software** - Copyright © 2024 David Johnson. All Rights Reserved.

You may install and use this software, but modification and redistribution are prohibited without written consent. See [LICENSE](LICENSE) for full terms.

## Contact

- **GitHub**: [dmjdxb](https://github.com/dmjdxb)
- **Repository**: [Thermodynamic Computing Platform](https://github.com/dmjdxb/Thermodynamic-Computing-Platform-)

