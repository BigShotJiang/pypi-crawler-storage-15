"""Tests for the PbitLang lexer."""

import pytest
from pbitlang.parser.lexer import Lexer, TokenType


class TestLexer:
    """Test the lexer tokenization."""

    def test_empty_source(self):
        """Empty source produces only EOF."""
        lexer = Lexer("")
        tokens = lexer.tokenize()
        assert len(tokens) == 1
        assert tokens[0].type == TokenType.EOF

    def test_keywords(self):
        """Keywords are recognized correctly."""
        source = "hamiltonian param const let sum"
        lexer = Lexer(source)
        tokens = lexer.tokenize()

        assert tokens[0].type == TokenType.HAMILTONIAN
        assert tokens[1].type == TokenType.PARAM
        assert tokens[2].type == TokenType.CONST
        assert tokens[3].type == TokenType.LET
        assert tokens[4].type == TokenType.SUM

    def test_spin_types(self):
        """Spin type keywords are recognized."""
        source = "ising binary potts clock continuous"
        lexer = Lexer(source)
        tokens = lexer.tokenize()

        assert tokens[0].type == TokenType.ISING
        assert tokens[1].type == TokenType.BINARY
        assert tokens[2].type == TokenType.POTTS
        assert tokens[3].type == TokenType.CLOCK
        assert tokens[4].type == TokenType.CONTINUOUS

    def test_lattice_types(self):
        """Lattice type keywords are recognized."""
        source = "chain square triangular honeycomb kagome cubic"
        lexer = Lexer(source)
        tokens = lexer.tokenize()

        assert tokens[0].type == TokenType.CHAIN
        assert tokens[1].type == TokenType.SQUARE
        assert tokens[2].type == TokenType.TRIANGULAR
        assert tokens[3].type == TokenType.HONEYCOMB
        assert tokens[4].type == TokenType.KAGOME
        assert tokens[5].type == TokenType.CUBIC

    def test_integer_literals(self):
        """Integer literals are parsed correctly."""
        source = "42 0 100"
        lexer = Lexer(source)
        tokens = lexer.tokenize()

        assert tokens[0].type == TokenType.INT
        assert tokens[0].value == "42"
        assert tokens[1].type == TokenType.INT
        assert tokens[1].value == "0"
        assert tokens[2].type == TokenType.INT
        assert tokens[2].value == "100"

    def test_negative_literals_after_operator(self):
        """Negative literals are parsed as single tokens after operators."""
        source = "(-17)"
        lexer = Lexer(source)
        tokens = lexer.tokenize()

        # LPAREN, INT(-17), RPAREN, EOF
        assert tokens[0].type == TokenType.LPAREN
        assert tokens[1].type == TokenType.INT
        assert tokens[1].value == "-17"
        assert tokens[2].type == TokenType.RPAREN

    def test_float_literals(self):
        """Float literals are parsed correctly."""
        source = "3.14 2.5e-3 1.0"
        lexer = Lexer(source)
        tokens = lexer.tokenize()

        assert tokens[0].type == TokenType.REAL
        assert tokens[0].value == "3.14"
        assert tokens[1].type == TokenType.REAL
        assert tokens[1].value == "2.5e-3"

    def test_operators(self):
        """Operators are recognized correctly."""
        source = "+ - * / ^ = == != < > <= >="
        lexer = Lexer(source)
        tokens = lexer.tokenize()

        expected = [
            TokenType.PLUS, TokenType.MINUS, TokenType.STAR, TokenType.SLASH,
            TokenType.CARET, TokenType.ASSIGN, TokenType.EQ,
            TokenType.NE, TokenType.LT, TokenType.GT,
            TokenType.LE, TokenType.GE
        ]

        for i, expected_type in enumerate(expected):
            assert tokens[i].type == expected_type

    def test_delimiters(self):
        """Delimiters are recognized correctly."""
        source = "( ) [ ] { } , : ;"
        lexer = Lexer(source)
        tokens = lexer.tokenize()

        expected = [
            TokenType.LPAREN, TokenType.RPAREN,
            TokenType.LBRACKET, TokenType.RBRACKET,
            TokenType.LBRACE, TokenType.RBRACE,
            TokenType.COMMA, TokenType.COLON, TokenType.SEMICOLON
        ]

        for i, expected_type in enumerate(expected):
            assert tokens[i].type == expected_type

    def test_single_line_comments(self):
        """Single line comments are skipped."""
        source = "a // this is a comment\nb"
        lexer = Lexer(source)
        tokens = lexer.tokenize()

        # Filter out NEWLINE tokens for simpler assertion
        ident_tokens = [t for t in tokens if t.type == TokenType.IDENT]
        assert len(ident_tokens) == 2
        assert ident_tokens[0].value == "a"
        assert ident_tokens[1].value == "b"

    def test_identifiers(self):
        """Identifiers are recognized correctly."""
        source = "myVar _private CamelCase var123"
        lexer = Lexer(source)
        tokens = lexer.tokenize()

        ident_tokens = [t for t in tokens if t.type == TokenType.IDENT]
        assert len(ident_tokens) == 4
        assert ident_tokens[0].value == "myVar"
        assert ident_tokens[1].value == "_private"
        assert ident_tokens[2].value == "CamelCase"
        assert ident_tokens[3].value == "var123"

    def test_hamiltonian_declaration(self):
        """Full hamiltonian declaration is tokenized."""
        source = """
        hamiltonian MyIsing(n: int, J: real = 1.0)
            -> ising on chain(n, periodic) {
            coupling: sum((i, j) in neighbors) { -J * s[i] * s[j] }
        }
        """
        lexer = Lexer(source)
        tokens = lexer.tokenize()

        # Should have many tokens and end with EOF
        assert len(tokens) > 20
        assert tokens[-1].type == TokenType.EOF

        # Check key tokens are present
        token_types = [t.type for t in tokens]
        assert TokenType.HAMILTONIAN in token_types
        assert TokenType.ISING in token_types
        assert TokenType.CHAIN in token_types
        assert TokenType.SUM in token_types


class TestLexerEdgeCases:
    """Test edge cases and error handling."""

    def test_string_literals(self):
        """String literals are parsed."""
        source = '"hello world"'
        lexer = Lexer(source)
        tokens = lexer.tokenize()

        assert tokens[0].type == TokenType.STRING
        assert tokens[0].value == "hello world"

    def test_arrow_operator(self):
        """Arrow operator -> is recognized."""
        source = "a -> b"
        lexer = Lexer(source)
        tokens = lexer.tokenize()

        assert tokens[1].type == TokenType.ARROW

    def test_range_operators(self):
        """Range operators are recognized."""
        source = "0..n 0...n"
        lexer = Lexer(source)
        tokens = lexer.tokenize()

        # 0..n produces: INT(0), DOTDOT, IDENT(n)
        # 0...n produces: INT(0), DOTDOTDOT, IDENT(n)
        assert tokens[1].type == TokenType.DOTDOT
        assert tokens[4].type == TokenType.DOTDOTDOT

    def test_line_tracking(self):
        """Line numbers are tracked correctly."""
        source = "a\nb\nc"
        lexer = Lexer(source)
        tokens = lexer.tokenize()

        # Filter for just identifiers
        ident_tokens = [t for t in tokens if t.type == TokenType.IDENT]
        assert ident_tokens[0].location.line == 1
        assert ident_tokens[1].location.line == 2
        assert ident_tokens[2].location.line == 3
