"""Tests for the PbitLang parser."""

import pytest
from pbitlang.parser.lexer import Lexer
from pbitlang.parser.parser import Parser
from pbitlang.ast.nodes import (
    HamiltonianDef, LatticeExpr, SumExpr, BinaryOp
)


class TestParser:
    """Test the parser."""

    def parse(self, source: str):
        """Helper to parse source code."""
        lexer = Lexer(source)
        tokens = lexer.tokenize()
        parser = Parser(tokens)
        return parser.parse_program()

    def test_simple_hamiltonian(self):
        """Parse a simple hamiltonian declaration."""
        source = """
        hamiltonian Test(n: int)
            -> ising on chain(n) {
            energy: sum(i in sites) { s[i] }
        }
        """
        ast = self.parse(source)

        assert len(ast.hamiltonians) == 1
        ham = ast.hamiltonians[0]
        assert isinstance(ham, HamiltonianDef)
        assert ham.name == "Test"

    def test_parameters_with_defaults(self):
        """Parse parameters with default values."""
        source = """
        hamiltonian Test(n: int, J: real = 1.0, h: real = 0.0)
            -> ising on chain(n) {
            energy: sum(i in sites) { s[i] }
        }
        """
        ast = self.parse(source)
        ham = ast.hamiltonians[0]

        assert len(ham.params) == 3
        assert ham.params[0].name == "n"
        assert ham.params[0].default is None
        assert ham.params[1].name == "J"
        assert ham.params[1].default == 1.0
        assert ham.params[2].name == "h"
        assert ham.params[2].default == 0.0

    def test_spin_types(self):
        """Parse different spin types."""
        for spin_type in ["ising", "binary"]:
            source = f"""
            hamiltonian Test(n: int)
                -> {spin_type} on chain(n) {{
                energy: sum(i in sites) {{ s[i] }}
            }}
            """
            ast = self.parse(source)
            ham = ast.hamiltonians[0]
            assert ham.spin_type.name == spin_type

    def test_potts_spin_type(self):
        """Parse Potts spin type with q parameter."""
        source = """
        hamiltonian Test(n: int, q: int)
            -> potts(q) on chain(n) {
            energy: sum((i,j) in neighbors) { delta(sigma[i], sigma[j]) }
        }
        """
        ast = self.parse(source)
        ham = ast.hamiltonians[0]
        assert ham.spin_type.name == "potts"

    def test_lattice_types(self):
        """Parse different lattice types."""
        lattices = [
            ("chain(n)", "chain"),
            ("square(n, n)", "square"),
            ("triangular(n)", "triangular"),
            ("honeycomb(n)", "honeycomb"),
            ("cubic(n, n, n)", "cubic"),
        ]

        for lattice_str, lattice_name in lattices:
            source = f"""
            hamiltonian Test(n: int)
                -> ising on {lattice_str} {{
                energy: sum(i in sites) {{ s[i] }}
            }}
            """
            ast = self.parse(source)
            ham = ast.hamiltonians[0]
            assert isinstance(ham.lattice, LatticeExpr)
            assert ham.lattice.lattice_type == lattice_name

    def test_periodic_boundary(self):
        """Parse lattice with periodic boundary."""
        source = """
        hamiltonian Test(n: int)
            -> ising on chain(n, periodic) {
            energy: sum(i in sites) { s[i] }
        }
        """
        ast = self.parse(source)
        ham = ast.hamiltonians[0]
        # periodic should be parsed as part of lattice arguments

    def test_sum_over_neighbors(self):
        """Parse sum over neighbor pairs."""
        source = """
        hamiltonian Test(n: int, J: real)
            -> ising on chain(n) {
            coupling: sum((i, j) in neighbors) { -J * s[i] * s[j] }
        }
        """
        ast = self.parse(source)
        ham = ast.hamiltonians[0]

        assert len(ham.terms) == 1
        assert ham.terms[0].name == "coupling"

    def test_sum_over_sites(self):
        """Parse sum over sites."""
        source = """
        hamiltonian Test(n: int, h: real)
            -> ising on chain(n) {
            field: sum(i in sites) { -h * s[i] }
        }
        """
        ast = self.parse(source)
        ham = ast.hamiltonians[0]

        assert len(ham.terms) == 1
        assert ham.terms[0].name == "field"

    def test_multiple_terms(self):
        """Parse hamiltonian with multiple terms."""
        source = """
        hamiltonian Test(n: int, J: real, h: real)
            -> ising on chain(n) {
            coupling: sum((i, j) in neighbors) { -J * s[i] * s[j] }
            field: sum(i in sites) { -h * s[i] }
        }
        """
        ast = self.parse(source)
        ham = ast.hamiltonians[0]

        assert len(ham.terms) == 2
        assert ham.terms[0].name == "coupling"
        assert ham.terms[1].name == "field"

    def test_where_clause(self):
        """Parse hamiltonian with where clause."""
        source = """
        hamiltonian Test(n: int, q: int)
            -> potts(q) on chain(n)
            where q >= 2 {
            energy: sum(i in sites) { sigma[i] }
        }
        """
        ast = self.parse(source)
        ham = ast.hamiltonians[0]
        assert ham.constraints is not None

    def test_arithmetic_expressions(self):
        """Parse arithmetic expressions."""
        source = """
        hamiltonian Test(n: int, J: real)
            -> ising on chain(n) {
            energy: sum((i, j) in neighbors) { -J * s[i] * s[j] + 1.0 }
        }
        """
        ast = self.parse(source)
        # Should parse without error

    def test_power_operator(self):
        """Parse power operator."""
        source = """
        hamiltonian Test(n: int, alpha: real)
            -> ising on chain(n) {
            energy: sum((i, j) in all_pairs) { 1.0 / distance(i, j)^alpha * s[i] * s[j] }
        }
        """
        ast = self.parse(source)
        # Should parse without error


class TestParserErrors:
    """Test parser error handling."""

    def parse(self, source: str):
        """Helper to parse source code."""
        lexer = Lexer(source)
        tokens = lexer.tokenize()
        parser = Parser(tokens)
        return parser.parse_program()

    def test_missing_brace(self):
        """Missing closing brace raises error."""
        source = """
        hamiltonian Test(n: int)
            -> ising on chain(n) {
            energy: sum(i in sites) { s[i] }
        """
        with pytest.raises(Exception):
            self.parse(source)

    def test_missing_parameter_type(self):
        """Missing parameter type raises error."""
        source = """
        hamiltonian Test(n)
            -> ising on chain(n) {
            energy: sum(i in sites) { s[i] }
        }
        """
        with pytest.raises(Exception):
            self.parse(source)
