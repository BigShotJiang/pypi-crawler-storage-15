"""Tests for the standard library models."""

import pytest
from pbitlang.stdlib.models import (
    IsingChain, Ising2D, Ising3D, Potts2D, MaxCut, Hopfield, RBM,
    IsingTriangular, IsingHoneycomb,
    SherringtonKirkpatrick, EdwardsAnderson,
    Clock2D, QUBO, MaxSAT,
    STDLIB_SOURCES,
    StdlibModel,
)


class TestStdlibModel:
    """Test the StdlibModel base class."""

    def test_model_has_required_fields(self):
        """All models have required fields."""
        for model in [IsingChain, Ising2D, Potts2D, MaxCut, Hopfield, RBM]:
            assert hasattr(model, 'name')
            assert hasattr(model, 'source')
            assert hasattr(model, 'description')
            assert hasattr(model, 'category')
            assert hasattr(model, 'references')

    def test_model_source_not_empty(self):
        """All models have non-empty source code."""
        for model in [IsingChain, Ising2D, Potts2D, MaxCut, Hopfield, RBM]:
            assert len(model.source.strip()) > 0


class TestIsingChain:
    """Test IsingChain model."""

    def test_name(self):
        """Model has correct name."""
        assert IsingChain.name == "IsingChain"

    def test_category(self):
        """Model is in ising category."""
        assert IsingChain.category == "ising"

    def test_source_contains_hamiltonian(self):
        """Source contains hamiltonian declaration."""
        assert "hamiltonian" in IsingChain.source
        assert "IsingChain" in IsingChain.source

    def test_source_has_chain_lattice(self):
        """Source uses chain lattice."""
        assert "chain" in IsingChain.source

    def test_source_has_neighbors(self):
        """Source sums over neighbors."""
        assert "neighbors" in IsingChain.source

    def test_has_reference(self):
        """Model has historical reference."""
        assert len(IsingChain.references) > 0
        assert "Ising" in IsingChain.references[0]


class TestIsing2D:
    """Test 2D Ising model."""

    def test_name(self):
        """Model has correct name."""
        assert Ising2D.name == "Ising2D"

    def test_category(self):
        """Model is in ising category."""
        assert Ising2D.category == "ising"

    def test_source_contains_square_lattice(self):
        """Source uses square lattice."""
        assert "square" in Ising2D.source

    def test_has_onsager_reference(self):
        """Model references Onsager's solution."""
        assert len(Ising2D.references) > 0
        assert "Onsager" in Ising2D.references[0]


class TestPotts2D:
    """Test 2D Potts model."""

    def test_name(self):
        """Model has correct name."""
        assert Potts2D.name == "Potts2D"

    def test_category(self):
        """Model is in potts category."""
        assert Potts2D.category == "potts"

    def test_source_has_potts_spin_type(self):
        """Source uses potts spin type."""
        assert "potts" in Potts2D.source

    def test_source_has_delta_function(self):
        """Source uses delta function for Potts interaction."""
        assert "delta" in Potts2D.source


class TestMaxCut:
    """Test MaxCut optimization problem."""

    def test_name(self):
        """Model has correct name."""
        assert MaxCut.name == "MaxCut"

    def test_category(self):
        """Model is in optimization category."""
        assert MaxCut.category == "optimization"

    def test_source_uses_ising(self):
        """MaxCut is formulated with Ising spins."""
        assert "ising" in MaxCut.source


class TestHopfield:
    """Test Hopfield network."""

    def test_name(self):
        """Model has correct name."""
        assert Hopfield.name == "Hopfield"

    def test_category(self):
        """Model is in neural category."""
        assert Hopfield.category == "neural"

    def test_source_uses_complete_graph(self):
        """Hopfield uses complete graph (all-to-all)."""
        assert "complete" in Hopfield.source

    def test_has_hopfield_reference(self):
        """Model references Hopfield's paper."""
        assert len(Hopfield.references) > 0
        assert "Hopfield" in Hopfield.references[0]


class TestRBM:
    """Test Restricted Boltzmann Machine."""

    def test_name(self):
        """Model has correct name."""
        assert RBM.name == "RBM"

    def test_category(self):
        """Model is in neural category."""
        assert RBM.category == "neural"

    def test_source_uses_binary(self):
        """RBM uses binary spins."""
        assert "binary" in RBM.source

    def test_source_uses_bipartite(self):
        """RBM uses bipartite graph."""
        assert "bipartite" in RBM.source


class TestSpinGlasses:
    """Test spin glass models."""

    def test_sk_model(self):
        """SK model exists and has correct category."""
        assert SherringtonKirkpatrick.name == "SherringtonKirkpatrick"
        assert SherringtonKirkpatrick.category == "spin_glass"

    def test_ea_model(self):
        """EA model exists and has correct category."""
        assert EdwardsAnderson.name == "EdwardsAnderson"
        assert EdwardsAnderson.category == "spin_glass"


class TestOtherModels:
    """Test other model variants."""

    def test_ising_3d_exists(self):
        """3D Ising model exists."""
        assert Ising3D.name == "Ising3D"
        assert "cubic" in Ising3D.source

    def test_triangular_exists(self):
        """Triangular lattice Ising exists."""
        assert IsingTriangular.name == "IsingTriangular"
        assert "triangular" in IsingTriangular.source

    def test_honeycomb_exists(self):
        """Honeycomb lattice Ising exists."""
        assert IsingHoneycomb.name == "IsingHoneycomb"
        assert "honeycomb" in IsingHoneycomb.source

    def test_clock_exists(self):
        """Clock model exists."""
        assert Clock2D.name == "Clock2D"
        assert "clock" in Clock2D.source


class TestStdlibSources:
    """Test the STDLIB_SOURCES dictionary."""

    def test_all_models_in_sources(self):
        """All standard models have source code in dictionary."""
        expected = [
            "IsingChain", "Ising2D", "Ising3D",
            "IsingTriangular", "IsingHoneycomb",
            "SherringtonKirkpatrick", "EdwardsAnderson",
            "Potts2D", "Clock2D",
            "MaxCut", "QUBO", "MaxSAT",
            "Hopfield", "RBM"
        ]
        for name in expected:
            assert name in STDLIB_SOURCES

    def test_sources_match_models(self):
        """Source code in dictionary matches model source."""
        assert STDLIB_SOURCES["IsingChain"] == IsingChain.source
        assert STDLIB_SOURCES["Ising2D"] == Ising2D.source
        assert STDLIB_SOURCES["Potts2D"] == Potts2D.source
