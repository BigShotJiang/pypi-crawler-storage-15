"""
PbitLang Standard Library

Pre-defined physics models ready for use.

Usage:
    >>> from pbitlang.stdlib import IsingChain, Ising2D, MaxCut, RBM
    >>>
    >>> # Create a 10-spin Ising chain
    >>> model = IsingChain.instantiate(n=10, J=1.0, h=0.1)
    >>>
    >>> # Or use the source for customization
    >>> print(IsingChain.source)
"""

from pbitlang.stdlib.models import (
    # Ising family
    IsingChain,
    Ising2D,
    Ising3D,
    IsingTriangular,
    IsingHoneycomb,
    # Spin glasses
    SherringtonKirkpatrick,
    EdwardsAnderson,
    # Potts and clock
    Potts2D,
    Clock2D,
    # Optimization
    MaxCut,
    QUBO,
    MaxSAT,
    # Neural networks
    Hopfield,
    RBM,
    # Source strings
    STDLIB_SOURCES,
)

__all__ = [
    "IsingChain",
    "Ising2D",
    "Ising3D",
    "IsingTriangular",
    "IsingHoneycomb",
    "SherringtonKirkpatrick",
    "EdwardsAnderson",
    "Potts2D",
    "Clock2D",
    "MaxCut",
    "QUBO",
    "MaxSAT",
    "Hopfield",
    "RBM",
    "STDLIB_SOURCES",
]
