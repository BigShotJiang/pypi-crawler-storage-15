"""
PbitLang Standard Library Models

Pre-defined physics models with source code and compiled versions.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional


@dataclass
class StdlibModel:
    """A standard library model."""
    name: str
    source: str
    description: str
    category: str
    references: list

    _compiled: Optional[Any] = None

    def compile(self):
        """Compile the model."""
        if self._compiled is None:
            from pbitlang.compiler import compile
            self._compiled = compile(self.source)
        return self._compiled

    def instantiate(self, **kwargs) -> Any:
        """Instantiate the model with parameters."""
        return self.compile().instantiate(**kwargs)


# =============================================================================
# Source Code for Standard Models
# =============================================================================

ISING_CHAIN_SOURCE = '''
/// 1D Ising chain with nearest-neighbor coupling
/// Reference: E. Ising, Z. Phys. 31, 253 (1925)
@model
hamiltonian IsingChain(n: int, J: real = 1.0, h: real = 0.0)
    -> ising on chain(n, periodic)
    where n > 0 {

    // Nearest-neighbor ferromagnetic coupling
    // E_coupling = -J * sum_{<i,j>} s_i * s_j
    coupling: sum((i, j) in neighbors) { -J * s[i] * s[j] }

    // External magnetic field
    // E_field = -h * sum_i s_i
    field: sum(i in sites) { -h * s[i] }
}
'''

ISING_2D_SOURCE = '''
/// 2D Ising model on square lattice
/// Reference: L. Onsager, Phys. Rev. 65, 117 (1944)
@model
hamiltonian Ising2D(nx: int, ny: int, J: real = 1.0, h: real = 0.0)
    -> ising on square(nx, ny, periodic)
    where nx > 0 and ny > 0 {

    // Nearest-neighbor coupling on 2D square lattice
    coupling: sum((i, j) in neighbors) { -J * s[i] * s[j] }

    // External field
    field: sum(i in sites) { -h * s[i] }
}
'''

ISING_3D_SOURCE = '''
/// 3D Ising model on simple cubic lattice
@model
hamiltonian Ising3D(nx: int, ny: int, nz: int, J: real = 1.0, h: real = 0.0)
    -> ising on cubic(nx, ny, nz, periodic)
    where nx > 0 and ny > 0 and nz > 0 {

    coupling: sum((i, j) in neighbors) { -J * s[i] * s[j] }
    field: sum(i in sites) { -h * s[i] }
}
'''

ISING_TRIANGULAR_SOURCE = '''
/// 2D Ising model on triangular lattice
/// Each site has 6 neighbors
@model
hamiltonian IsingTriangular(n: int, J: real = 1.0, h: real = 0.0)
    -> ising on triangular(n, periodic)
    where n > 0 {

    coupling: sum((i, j) in neighbors) { -J * s[i] * s[j] }
    field: sum(i in sites) { -h * s[i] }
}
'''

ISING_HONEYCOMB_SOURCE = '''
/// 2D Ising model on honeycomb lattice
/// Bipartite lattice, each site has 3 neighbors
@model
hamiltonian IsingHoneycomb(n: int, J: real = 1.0, h: real = 0.0)
    -> ising on honeycomb(n, periodic)
    where n > 0 {

    coupling: sum((i, j) in neighbors) { -J * s[i] * s[j] }
    field: sum(i in sites) { -h * s[i] }
}
'''

SK_SOURCE = '''
/// Sherrington-Kirkpatrick spin glass model
/// All-to-all random couplings with Gaussian distribution
/// Reference: D. Sherrington & S. Kirkpatrick, PRL 35, 1792 (1975)
@model
hamiltonian SherringtonKirkpatrick(n: int, J_mean: real = 0.0, J_std: real = 1.0)
    -> ising on graph(complete(n))
    where n > 0 {

    // Random couplings J_ij ~ N(J_mean, J_std^2 / n)
    // Note: In actual use, J_matrix would be provided externally
    coupling: sum((i, j) in all_pairs where i < j) { -J_mean * s[i] * s[j] }
}
'''

EA_SOURCE = '''
/// Edwards-Anderson spin glass model
/// Random couplings on a lattice (typically cubic)
/// Reference: S.F. Edwards & P.W. Anderson, J. Phys. F 5, 965 (1975)
@model
hamiltonian EdwardsAnderson(n: int, J_magnitude: real = 1.0)
    -> ising on cubic(n, n, n, periodic)
    where n > 0 {

    // Random ±J couplings on nearest neighbors
    coupling: sum((i, j) in neighbors) { -J_magnitude * s[i] * s[j] }
}
'''

POTTS_2D_SOURCE = '''
/// q-state Potts model on 2D square lattice
/// Reference: R.B. Potts, Proc. Camb. Phil. Soc. 48, 106 (1952)
@model
hamiltonian Potts2D(n: int, q: int = 3, J: real = 1.0)
    -> potts(q) on square(n, n, periodic)
    where n > 0 and q >= 2 {

    // Energy is -J if neighbors are same state, 0 otherwise
    coupling: sum((i, j) in neighbors) { -J * delta(sigma[i], sigma[j]) }
}
'''

CLOCK_2D_SOURCE = '''
/// q-state clock model (discrete XY) on 2D square lattice
@model
hamiltonian Clock2D(n: int, q: int = 6, J: real = 1.0)
    -> clock(q) on square(n, n, periodic)
    where n > 0 and q >= 2 {

    // XY-like cosine coupling with discrete angles
    coupling: sum((i, j) in neighbors) { -J * cos(theta[i] - theta[j]) }
}
'''

MAXCUT_SOURCE = '''
/// Maximum Cut problem
/// Find partition to maximize edges between partitions
@model
hamiltonian MaxCut(n: int)
    -> ising on graph(complete(n))
    where n > 0 {

    // Energy = -sum_{(i,j) in E} (1 - s_i * s_j) / 2
    // Minimize energy = maximize cut
    energy: sum((i, j) in all_pairs where i < j) {
        -(1 - s[i] * s[j]) / 2
    }
}
'''

QUBO_SOURCE = '''
/// Quadratic Unconstrained Binary Optimization
/// E(x) = sum_ij Q_ij x_i x_j
/// Automatically converts to Ising internally
@model
hamiltonian QUBOGeneric(n: int)
    -> binary on graph(complete(n))
    where n > 0 {

    // Generic QUBO - Q matrix provided at instantiation
    energy: sum((i, j) in all_pairs) { x[i] * x[j] }
}
'''

MAXSAT_SOURCE = '''
/// Maximum Satisfiability
/// Find assignment maximizing satisfied clauses
@model
hamiltonian MaxSATGeneric(n_vars: int)
    -> binary on graph(complete(n_vars))
    where n_vars > 0 {

    // Clauses would be provided at instantiation
    // Each unsatisfied clause adds +1 to energy
    energy: sum(i in sites) { 0 }
}
'''

HOPFIELD_SOURCE = '''
/// Hopfield associative memory network
/// Reference: J.J. Hopfield, PNAS 79, 2554 (1982)
@model
hamiltonian Hopfield(n: int)
    -> ising on graph(complete(n))
    where n > 0 {

    // Hebbian weights: J_ij = (1/n) * sum_mu xi^mu_i * xi^mu_j
    // Patterns stored as columns of a matrix
    // Energy minimum at stored patterns
    coupling: sum((i, j) in all_pairs where i < j) { -s[i] * s[j] }
}
'''

RBM_SOURCE = '''
/// Restricted Boltzmann Machine
/// Bipartite graph between visible and hidden units
/// Reference: G.E. Hinton, Neural Computation 14, 1771 (2002)
@model
hamiltonian RBM(n_visible: int, n_hidden: int)
    -> binary on graph(bipartite(n_visible, n_hidden))
    where n_visible > 0 and n_hidden > 0 {

    // Visible-hidden interactions only (no visible-visible or hidden-hidden)
    // W matrix: n_visible x n_hidden
    // a: visible biases (n_visible)
    // b: hidden biases (n_hidden)
    visible_bias: sum(i in sites where i < n_visible) { -x[i] }
    hidden_bias: sum(j in sites where j >= n_visible) { -x[j] }
    interaction: sum((i, j) in neighbors) { -x[i] * x[j] }
}
'''


# =============================================================================
# Compiled Models
# =============================================================================

# Ising family
IsingChain = StdlibModel(
    name="IsingChain",
    source=ISING_CHAIN_SOURCE,
    description="1D Ising chain with nearest-neighbor ferromagnetic coupling",
    category="ising",
    references=["E. Ising, Z. Phys. 31, 253 (1925)"],
)

Ising2D = StdlibModel(
    name="Ising2D",
    source=ISING_2D_SOURCE,
    description="2D Ising model on square lattice (Onsager's model)",
    category="ising",
    references=["L. Onsager, Phys. Rev. 65, 117 (1944)"],
)

Ising3D = StdlibModel(
    name="Ising3D",
    source=ISING_3D_SOURCE,
    description="3D Ising model on simple cubic lattice",
    category="ising",
    references=[],
)

IsingTriangular = StdlibModel(
    name="IsingTriangular",
    source=ISING_TRIANGULAR_SOURCE,
    description="2D Ising model on triangular lattice (6 neighbors per site)",
    category="ising",
    references=[],
)

IsingHoneycomb = StdlibModel(
    name="IsingHoneycomb",
    source=ISING_HONEYCOMB_SOURCE,
    description="2D Ising model on honeycomb (graphene) lattice",
    category="ising",
    references=[],
)

# Spin glasses
SherringtonKirkpatrick = StdlibModel(
    name="SherringtonKirkpatrick",
    source=SK_SOURCE,
    description="Sherrington-Kirkpatrick infinite-range spin glass",
    category="spin_glass",
    references=["D. Sherrington & S. Kirkpatrick, PRL 35, 1792 (1975)"],
)

EdwardsAnderson = StdlibModel(
    name="EdwardsAnderson",
    source=EA_SOURCE,
    description="Edwards-Anderson spin glass on 3D cubic lattice",
    category="spin_glass",
    references=["S.F. Edwards & P.W. Anderson, J. Phys. F 5, 965 (1975)"],
)

# Potts and clock
Potts2D = StdlibModel(
    name="Potts2D",
    source=POTTS_2D_SOURCE,
    description="q-state Potts model on 2D square lattice",
    category="potts",
    references=["R.B. Potts, Proc. Camb. Phil. Soc. 48, 106 (1952)"],
)

Clock2D = StdlibModel(
    name="Clock2D",
    source=CLOCK_2D_SOURCE,
    description="q-state clock model (discrete XY) on 2D square lattice",
    category="clock",
    references=[],
)

# Optimization
MaxCut = StdlibModel(
    name="MaxCut",
    source=MAXCUT_SOURCE,
    description="Maximum Cut problem (NP-hard combinatorial optimization)",
    category="optimization",
    references=[],
)

QUBO = StdlibModel(
    name="QUBO",
    source=QUBO_SOURCE,
    description="Quadratic Unconstrained Binary Optimization",
    category="optimization",
    references=[],
)

MaxSAT = StdlibModel(
    name="MaxSAT",
    source=MAXSAT_SOURCE,
    description="Maximum Satisfiability problem",
    category="optimization",
    references=[],
)

# Neural networks
Hopfield = StdlibModel(
    name="Hopfield",
    source=HOPFIELD_SOURCE,
    description="Hopfield associative memory network",
    category="neural",
    references=["J.J. Hopfield, PNAS 79, 2554 (1982)"],
)

RBM = StdlibModel(
    name="RBM",
    source=RBM_SOURCE,
    description="Restricted Boltzmann Machine",
    category="neural",
    references=["G.E. Hinton, Neural Computation 14, 1771 (2002)"],
)


# All sources for reference
STDLIB_SOURCES = {
    "IsingChain": ISING_CHAIN_SOURCE,
    "Ising2D": ISING_2D_SOURCE,
    "Ising3D": ISING_3D_SOURCE,
    "IsingTriangular": ISING_TRIANGULAR_SOURCE,
    "IsingHoneycomb": ISING_HONEYCOMB_SOURCE,
    "SherringtonKirkpatrick": SK_SOURCE,
    "EdwardsAnderson": EA_SOURCE,
    "Potts2D": POTTS_2D_SOURCE,
    "Clock2D": CLOCK_2D_SOURCE,
    "MaxCut": MAXCUT_SOURCE,
    "QUBO": QUBO_SOURCE,
    "MaxSAT": MAXSAT_SOURCE,
    "Hopfield": HOPFIELD_SOURCE,
    "RBM": RBM_SOURCE,
}
