"""
PbitLang Abstract Syntax Tree Node Definitions

This module defines all AST node types used to represent PbitLang programs.
Each node type corresponds to a syntactic construct in the language.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Dict, List, Optional, Tuple, Union


# =============================================================================
# Source Location
# =============================================================================

@dataclass(frozen=True)
class SourceLocation:
    """Location in source code for error reporting."""
    file: str = "<unknown>"
    line: int = 0
    column: int = 0
    end_line: Optional[int] = None
    end_column: Optional[int] = None

    def __str__(self) -> str:
        if self.end_line and self.end_line != self.line:
            return f"{self.file}:{self.line}:{self.column}-{self.end_line}:{self.end_column}"
        return f"{self.file}:{self.line}:{self.column}"


# =============================================================================
# Base Node
# =============================================================================

@dataclass(kw_only=True)
class Node(ABC):
    """Base class for all AST nodes."""
    location: SourceLocation = field(default_factory=SourceLocation)
    annotations: Dict[str, Any] = field(default_factory=dict)

    def with_location(self, loc: SourceLocation) -> "Node":
        """Return copy with new location."""
        self.location = loc
        return self


# =============================================================================
# Types
# =============================================================================

class PrimitiveKind(Enum):
    """Primitive type kinds."""
    INT = auto()
    REAL = auto()
    BOOL = auto()
    COMPLEX = auto()


class SpinKind(Enum):
    """Spin variable types."""
    ISING = auto()      # s ∈ {-1, +1}
    BINARY = auto()     # x ∈ {0, 1}
    POTTS = auto()      # σ ∈ {0, ..., q-1}
    CLOCK = auto()      # θ = 2πk/q
    CONTINUOUS = auto() # θ ∈ [0, 2π)


class BoundaryCondition(Enum):
    """Lattice boundary conditions."""
    PERIODIC = auto()   # Wrap around (torus)
    OPEN = auto()       # Free boundaries
    FIXED = auto()      # Fixed boundary spins


@dataclass
class Type(Node, ABC):
    """Base class for all types."""
    pass


@dataclass
class PrimitiveType(Type):
    """Primitive types: int, real, bool, complex."""
    kind: PrimitiveKind

    def __str__(self) -> str:
        return self.kind.name.lower()


@dataclass
class SpinType(Type):
    """
    Spin variable type.

    Examples:
        ising           -> SpinType(ISING, None)
        binary          -> SpinType(BINARY, None)
        potts(3)        -> SpinType(POTTS, 3)
        clock(6)        -> SpinType(CLOCK, 6)
        continuous      -> SpinType(CONTINUOUS, None)
    """
    kind: SpinKind
    q: Optional[int] = None  # Number of states for Potts/Clock

    def __str__(self) -> str:
        if self.q is not None:
            return f"{self.kind.name.lower()}({self.q})"
        return self.kind.name.lower()

    @property
    def num_states(self) -> Optional[int]:
        """Number of discrete states, or None for continuous."""
        if self.kind == SpinKind.ISING:
            return 2
        elif self.kind == SpinKind.BINARY:
            return 2
        elif self.kind in (SpinKind.POTTS, SpinKind.CLOCK):
            return self.q
        return None

    @property
    def is_discrete(self) -> bool:
        return self.kind != SpinKind.CONTINUOUS


@dataclass
class ArrayType(Type):
    """Array type: array[T, n]."""
    element_type: Type
    size: Optional["Expression"] = None  # None = dynamic

    def __str__(self) -> str:
        if self.size:
            return f"array[{self.element_type}, {self.size}]"
        return f"array[{self.element_type}]"


@dataclass
class MatrixType(Type):
    """Matrix type: matrix[T, rows, cols]."""
    element_type: Type
    rows: Optional["Expression"] = None
    cols: Optional["Expression"] = None

    def __str__(self) -> str:
        if self.rows and self.cols:
            return f"matrix[{self.element_type}, {self.rows}, {self.cols}]"
        return f"matrix[{self.element_type}]"


@dataclass
class LatticeType(Type):
    """Lattice structure type."""
    geometry: str  # "chain", "square", "triangular", etc.
    dimensions: List["Expression"] = field(default_factory=list)
    boundary: BoundaryCondition = BoundaryCondition.PERIODIC

    def __str__(self) -> str:
        dims = ", ".join(str(d) for d in self.dimensions)
        return f"{self.geometry}({dims}, {self.boundary.name.lower()})"


@dataclass
class GraphType(Type):
    """Arbitrary graph structure type."""
    adjacency: Optional["Expression"] = None  # Adjacency matrix or edge list

    def __str__(self) -> str:
        return "graph"


@dataclass
class CouplingType(Type):
    """
    Coupling type appropriate for a spin type.

    For Ising/binary: scalar coupling J_ij
    For Potts: q×q matrix coupling
    """
    spin_type: SpinType

    def __str__(self) -> str:
        return f"coupling[{self.spin_type}]"


# =============================================================================
# Expressions
# =============================================================================

@dataclass(kw_only=True)
class Expression(Node, ABC):
    """Base class for all expressions."""
    inferred_type: Optional[Type] = None  # Set during type checking


@dataclass
class Literal(Expression, ABC):
    """Base class for literal values."""
    pass


@dataclass
class IntLiteral(Literal):
    """Integer literal: 42, -17, 0x2A."""
    value: int

    def __str__(self) -> str:
        return str(self.value)


@dataclass
class RealLiteral(Literal):
    """Real literal: 3.14, 2.5e-3."""
    value: float

    def __str__(self) -> str:
        return str(self.value)


@dataclass
class BoolLiteral(Literal):
    """Boolean literal: true, false."""
    value: bool

    def __str__(self) -> str:
        return "true" if self.value else "false"


@dataclass
class StringLiteral(Literal):
    """String literal: "hello"."""
    value: str

    def __str__(self) -> str:
        return f'"{self.value}"'


@dataclass
class Identifier(Expression):
    """Variable or function identifier."""
    name: str

    def __str__(self) -> str:
        return self.name


class BinaryOperator(Enum):
    """Binary operators."""
    # Arithmetic
    ADD = "+"
    SUB = "-"
    MUL = "*"
    DIV = "/"
    POW = "^"
    MOD = "%"
    # Comparison
    EQ = "=="
    NE = "!="
    LT = "<"
    GT = ">"
    LE = "<="
    GE = ">="
    # Logical
    AND = "and"
    OR = "or"


class UnaryOperator(Enum):
    """Unary operators."""
    NEG = "-"
    POS = "+"
    NOT = "not"


@dataclass
class BinaryOp(Expression):
    """Binary operation: a + b, x * y."""
    operator: BinaryOperator
    left: Expression
    right: Expression

    def __str__(self) -> str:
        return f"({self.left} {self.operator.value} {self.right})"


@dataclass
class UnaryOp(Expression):
    """Unary operation: -x, not b."""
    operator: UnaryOperator
    operand: Expression

    def __str__(self) -> str:
        return f"({self.operator.value} {self.operand})"


@dataclass
class Subscript(Expression):
    """Array/matrix subscript: a[i], M[i,j]."""
    base: Expression
    indices: List[Expression]

    def __str__(self) -> str:
        idx = ", ".join(str(i) for i in self.indices)
        return f"{self.base}[{idx}]"


@dataclass
class FunctionCall(Expression):
    """Function call: f(x, y), neighbors(L)."""
    function: str
    arguments: List[Expression]
    keyword_args: Dict[str, Expression] = field(default_factory=dict)

    def __str__(self) -> str:
        args = ", ".join(str(a) for a in self.arguments)
        kwargs = ", ".join(f"{k}={v}" for k, v in self.keyword_args.items())
        all_args = ", ".join(filter(None, [args, kwargs]))
        return f"{self.function}({all_args})"


@dataclass
class FieldAccess(Expression):
    """Field/property access: obj.field."""
    base: Expression
    field: str

    def __str__(self) -> str:
        return f"{self.base}.{self.field}"


@dataclass
class ArrayExpr(Expression):
    """Array literal: [1, 2, 3]."""
    elements: List[Expression]

    def __str__(self) -> str:
        elems = ", ".join(str(e) for e in self.elements)
        return f"[{elems}]"


@dataclass
class MatrixExpr(Expression):
    """Matrix literal: [[1, 2], [3, 4]]."""
    rows: List[List[Expression]]

    def __str__(self) -> str:
        row_strs = []
        for row in self.rows:
            elems = ", ".join(str(e) for e in row)
            row_strs.append(f"[{elems}]")
        return f"[{', '.join(row_strs)}]"


@dataclass
class RangeExpr(Expression):
    """Range expression: 0..n, 1...10."""
    start: Expression
    end: Expression
    inclusive: bool = False  # .. vs ...

    def __str__(self) -> str:
        op = "..." if self.inclusive else ".."
        return f"{self.start}{op}{self.end}"


@dataclass
class ConditionalExpr(Expression):
    """Conditional expression: if cond then a else b."""
    condition: Expression
    then_expr: Expression
    else_expr: Expression

    def __str__(self) -> str:
        return f"if {self.condition} then {self.then_expr} else {self.else_expr}"


@dataclass
class LetExpr(Expression):
    """Local binding in expression: let x = e1 in e2."""
    name: str
    value: Expression
    body: Expression
    type_annotation: Optional[Type] = None

    def __str__(self) -> str:
        type_str = f": {self.type_annotation}" if self.type_annotation else ""
        return f"let {self.name}{type_str} = {self.value} in {self.body}"


# =============================================================================
# Sum and Product Expressions (Core for Hamiltonians)
# =============================================================================

@dataclass
class Pattern(Node, ABC):
    """Pattern for binding in sum/product."""
    pass


@dataclass
class TuplePattern(Pattern):
    """Tuple pattern: (i, j)."""
    elements: List[str]

    def __str__(self) -> str:
        return f"({', '.join(self.elements)})"


@dataclass
class SumExpr(Expression):
    """
    Sum expression: sum(pattern in domain [where condition]) { body }

    Examples:
        sum(i in sites) { -h * s[i] }
        sum((i,j) in neighbors where i < j) { -J * s[i] * s[j] }
    """
    pattern: Union[str, TuplePattern]
    domain: Expression
    body: Expression
    condition: Optional[Expression] = None

    def __str__(self) -> str:
        pat = str(self.pattern) if isinstance(self.pattern, TuplePattern) else self.pattern
        cond = f" where {self.condition}" if self.condition else ""
        return f"sum({pat} in {self.domain}{cond}) {{ {self.body} }}"


@dataclass
class ProductExpr(Expression):
    """
    Product expression: product(pattern in domain) { body }
    """
    pattern: Union[str, TuplePattern]
    domain: Expression
    body: Expression
    condition: Optional[Expression] = None

    def __str__(self) -> str:
        pat = str(self.pattern) if isinstance(self.pattern, TuplePattern) else self.pattern
        cond = f" where {self.condition}" if self.condition else ""
        return f"product({pat} in {self.domain}{cond}) {{ {self.body} }}"


# =============================================================================
# Declarations
# =============================================================================

@dataclass
class Declaration(Node, ABC):
    """Base class for declarations."""
    pass


@dataclass
class Parameter(Declaration):
    """
    Parameter declaration: param n: int, param J: real = 1.0

    Parameters are provided when instantiating a Hamiltonian.
    """
    name: str
    type: Type
    default: Optional[Expression] = None
    constraint: Optional[Expression] = None  # where constraint

    def __str__(self) -> str:
        type_str = f": {self.type}"
        default_str = f" = {self.default}" if self.default else ""
        constraint_str = f" where {self.constraint}" if self.constraint else ""
        return f"param {self.name}{type_str}{default_str}{constraint_str}"


@dataclass
class Constant(Declaration):
    """Constant declaration: const pi: real = 3.14159."""
    name: str
    type: Optional[Type]
    value: Expression

    def __str__(self) -> str:
        type_str = f": {self.type}" if self.type else ""
        return f"const {self.name}{type_str} = {self.value}"


@dataclass
class LetBinding(Declaration):
    """Let binding within Hamiltonian: let J_eff = J / k_B / T."""
    name: str
    indices: Optional[List[str]] = None  # For indexed bindings: let J[i,j] = ...
    value: Expression = None
    type_annotation: Optional[Type] = None

    def __str__(self) -> str:
        idx = f"[{', '.join(self.indices)}]" if self.indices else ""
        type_str = f": {self.type_annotation}" if self.type_annotation else ""
        return f"let {self.name}{idx}{type_str} = {self.value}"


@dataclass
class Import(Declaration):
    """Import declaration: import random from stdlib."""
    module: str
    items: Optional[List[str]] = None  # None = import all
    alias: Optional[str] = None

    def __str__(self) -> str:
        if self.items:
            items_str = ", ".join(self.items)
            return f"from {self.module} import {items_str}"
        alias_str = f" as {self.alias}" if self.alias else ""
        return f"import {self.module}{alias_str}"


# =============================================================================
# Constraints
# =============================================================================

@dataclass
class Constraint(Node, ABC):
    """Base class for constraints."""
    pass


@dataclass
class WhereClause(Constraint):
    """Where constraint: where q >= 2."""
    condition: Expression
    message: Optional[str] = None

    def __str__(self) -> str:
        return f"where {self.condition}"


@dataclass
class RequireClause(Constraint):
    """Require constraint: require symmetric(J)."""
    property: str
    target: Expression
    message: Optional[str] = None

    def __str__(self) -> str:
        return f"require {self.property}({self.target})"


# =============================================================================
# Lattice Expressions
# =============================================================================

@dataclass(kw_only=True)
class LatticeExpr(Node, ABC):
    """Base class for lattice definitions."""
    boundary: BoundaryCondition = BoundaryCondition.PERIODIC


@dataclass
class ChainLattice(LatticeExpr):
    """1D chain lattice."""
    length: Expression

    def __str__(self) -> str:
        return f"chain({self.length}, {self.boundary.name.lower()})"


@dataclass
class SquareLattice(LatticeExpr):
    """2D square lattice."""
    width: Expression
    height: Expression

    def __str__(self) -> str:
        return f"square({self.width}, {self.height}, {self.boundary.name.lower()})"


@dataclass
class TriangularLattice(LatticeExpr):
    """2D triangular lattice."""
    size: Expression

    def __str__(self) -> str:
        return f"triangular({self.size}, {self.boundary.name.lower()})"


@dataclass
class HoneycombLattice(LatticeExpr):
    """2D honeycomb (graphene) lattice."""
    size: Expression

    def __str__(self) -> str:
        return f"honeycomb({self.size}, {self.boundary.name.lower()})"


@dataclass
class KagomeLattice(LatticeExpr):
    """2D Kagome lattice."""
    size: Expression

    def __str__(self) -> str:
        return f"kagome({self.size}, {self.boundary.name.lower()})"


@dataclass
class CubicLattice(LatticeExpr):
    """3D cubic lattice."""
    x: Expression
    y: Expression
    z: Expression

    def __str__(self) -> str:
        return f"cubic({self.x}, {self.y}, {self.z}, {self.boundary.name.lower()})"


@dataclass
class CustomLattice(LatticeExpr):
    """Custom lattice from adjacency matrix or edge list."""
    adjacency: Optional[Expression] = None
    edges: Optional[Expression] = None

    def __str__(self) -> str:
        if self.adjacency:
            return f"from_adjacency({self.adjacency})"
        return f"from_edges({self.edges})"


# =============================================================================
# Energy Terms
# =============================================================================

@dataclass(kw_only=True)
class EnergyTerm(Node, ABC):
    """Base class for energy terms in a Hamiltonian."""
    name: Optional[str] = None  # Optional label for the term


@dataclass
class CouplingTerm(EnergyTerm):
    """
    Coupling term: spin-spin interactions.

    Example:
        coupling: sum((i,j) in neighbors) { -J * s[i] * s[j] }
    """
    expression: SumExpr

    def __str__(self) -> str:
        label = f"{self.name}: " if self.name else "coupling: "
        return f"{label}{self.expression}"


@dataclass
class FieldTerm(EnergyTerm):
    """
    Field term: external field on spins.

    Example:
        field: sum(i in sites) { -h * s[i] }
    """
    expression: SumExpr

    def __str__(self) -> str:
        label = f"{self.name}: " if self.name else "field: "
        return f"{label}{self.expression}"


@dataclass
class CustomTerm(EnergyTerm):
    """
    Custom energy term for arbitrary expressions.

    Example:
        energy: sum(i in sites) { penalty * x[i] * (1 - x[i]) }
    """
    expression: Expression

    def __str__(self) -> str:
        label = f"{self.name}: " if self.name else "energy: "
        return f"{label}{self.expression}"


# =============================================================================
# Hamiltonian Definition
# =============================================================================

@dataclass
class HamiltonianDef(Node):
    """
    Complete Hamiltonian definition.

    Example:
        @model
        hamiltonian IsingChain(n: int, J: real = 1.0, h: real = 0.0)
            -> ising on chain(n, periodic)
            where n > 0 {
            coupling: sum((i,j) in neighbors) { -J * s[i] * s[j] }
            field:    sum(i in sites) { -h * s[i] }
        }
    """
    name: str
    parameters: List[Parameter]
    spin_type: SpinType
    lattice: LatticeExpr
    terms: List[EnergyTerm]
    constraints: List[Constraint] = field(default_factory=list)
    let_bindings: List[LetBinding] = field(default_factory=list)
    decorators: List[str] = field(default_factory=list)
    docstring: Optional[str] = None

    def __str__(self) -> str:
        decorators = "\n".join(f"@{d}" for d in self.decorators)
        params = ", ".join(str(p) for p in self.parameters)
        constraints = " ".join(str(c) for c in self.constraints)
        terms = "\n    ".join(str(t) for t in self.terms)
        return f"""{decorators}
hamiltonian {self.name}({params})
    -> {self.spin_type} on {self.lattice}
    {constraints} {{
    {terms}
}}"""


@dataclass
class SystemDef(Node):
    """
    System definition for pre-configured spin systems.

    Example:
        system spins: ising on square(10, 10, periodic)
    """
    name: str
    spin_type: SpinType
    lattice: LatticeExpr

    def __str__(self) -> str:
        return f"system {self.name}: {self.spin_type} on {self.lattice}"


# =============================================================================
# Program
# =============================================================================

@dataclass
class Program(Node):
    """
    Complete PbitLang program.

    A program consists of imports, constants, and Hamiltonian definitions.
    """
    imports: List[Import] = field(default_factory=list)
    constants: List[Constant] = field(default_factory=list)
    systems: List[SystemDef] = field(default_factory=list)
    hamiltonians: List[HamiltonianDef] = field(default_factory=list)

    def __str__(self) -> str:
        parts = []
        if self.imports:
            parts.append("\n".join(str(i) for i in self.imports))
        if self.constants:
            parts.append("\n".join(str(c) for c in self.constants))
        if self.systems:
            parts.append("\n".join(str(s) for s in self.systems))
        if self.hamiltonians:
            parts.append("\n\n".join(str(h) for h in self.hamiltonians))
        return "\n\n".join(parts)


# =============================================================================
# Visitor Pattern
# =============================================================================

class NodeVisitor(ABC):
    """Base class for AST visitors."""

    def visit(self, node: Node) -> Any:
        """Dispatch to appropriate visit method."""
        method_name = f"visit_{type(node).__name__}"
        visitor = getattr(self, method_name, self.generic_visit)
        return visitor(node)

    def generic_visit(self, node: Node) -> Any:
        """Default visitor for unhandled nodes."""
        raise NotImplementedError(f"No visitor for {type(node).__name__}")


class NodeTransformer(ABC):
    """Base class for AST transformers."""

    def transform(self, node: Node) -> Node:
        """Dispatch to appropriate transform method."""
        method_name = f"transform_{type(node).__name__}"
        transformer = getattr(self, method_name, self.generic_transform)
        return transformer(node)

    def generic_transform(self, node: Node) -> Node:
        """Default transformer returns node unchanged."""
        return node
