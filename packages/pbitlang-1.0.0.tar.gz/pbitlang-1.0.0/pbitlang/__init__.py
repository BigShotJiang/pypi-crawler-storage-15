"""
PbitLang - Domain-Specific Language for Thermodynamic Computing

A scientifically rigorous language for expressing Hamiltonians and energy
functions that compile to PHAL for execution on P-bit hardware.

Basic usage:
    >>> import pbitlang
    >>>
    >>> source = '''
    ... hamiltonian IsingChain(n: int, J: real) -> ising on chain(n) {
    ...     coupling: sum((i,j) in neighbors) { -J * s[i] * s[j] }
    ... }
    ... '''
    >>>
    >>> model = pbitlang.compile(source)
    >>> hamiltonian = model.instantiate(n=10, J=1.0)
    >>> # hamiltonian is a phal.Hamiltonian ready for sampling

Submodules:
    - parser: Lexer and parser
    - ast: Abstract syntax tree types
    - types: Type system
    - physics: Physical validation and checks
    - compiler: Code generation
    - stdlib: Standard library of physics models
"""

from pbitlang._version import __version__

from pbitlang.compiler.compile import (
    compile,
    compile_file,
    CompiledModel,
)
from pbitlang.parser.lexer import tokenize
from pbitlang.parser.parser import parse
from pbitlang.types.checker import typecheck
from pbitlang.physics.validator import validate
from pbitlang.ast.nodes import (
    HamiltonianDef,
    SpinType,
    LatticeType,
)

__all__ = [
    "__version__",
    "compile",
    "compile_file",
    "CompiledModel",
    "tokenize",
    "parse",
    "typecheck",
    "validate",
    "HamiltonianDef",
    "SpinType",
    "LatticeType",
]
