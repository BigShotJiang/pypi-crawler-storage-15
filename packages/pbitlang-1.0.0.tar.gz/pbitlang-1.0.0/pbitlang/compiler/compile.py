"""
PbitLang Compiler Main Module

Orchestrates the full compilation pipeline:
    Source -> Tokens -> AST -> Typed AST -> Validated AST -> PHAL Hamiltonian
"""

from __future__ import annotations

import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Union

# Import AST types
from pbitlang.ast.nodes import (
    Program,
    HamiltonianDef,
    Parameter,
    SpinType,
    SpinKind,
    LatticeExpr,
    ChainLattice,
    SquareLattice,
    TriangularLattice,
    HoneycombLattice,
    KagomeLattice,
    CubicLattice,
    CustomLattice,
    BoundaryCondition,
    IntLiteral,
)

# Import pipeline stages
from pbitlang.parser import tokenize, parse, ParseError
from pbitlang.types import typecheck
from pbitlang.physics import validate
from pbitlang.physics.lattices import (
    LatticeGeometry,
    BoundaryType,
    generate_chain,
    generate_square,
    generate_triangular,
    generate_honeycomb,
    generate_kagome,
    generate_cubic,
    generate_complete,
)


class CompileError(Exception):
    """Compilation error."""

    def __init__(self, message: str, phase: str = "compile"):
        self.message = message
        self.phase = phase
        super().__init__(f"[{phase}] {message}")


@dataclass
class CompiledModel:
    """
    A compiled PbitLang model ready for instantiation.

    The compiled model can be instantiated with parameter values
    to produce a PHAL Hamiltonian.
    """
    name: str
    parameters: List[Parameter]
    spin_type: SpinType
    lattice_expr: LatticeExpr
    source_ast: HamiltonianDef
    _evaluator: "Evaluator" = None

    def instantiate(self, **kwargs) -> "Any":  # Returns phal.Hamiltonian
        """
        Instantiate the model with parameter values.

        Args:
            **kwargs: Parameter values (must include all required params)

        Returns:
            phal.Hamiltonian ready for sampling

        Example:
            >>> model = compile(source)
            >>> ham = model.instantiate(n=10, J=1.0, h=0.1)
            >>> device.sample(ham, num_samples=1000, beta=1.0)
        """
        # Validate parameters
        provided = set(kwargs.keys())
        required = set()
        defaults = {}

        for param in self.parameters:
            if param.default is None:
                required.add(param.name)
            else:
                # Evaluate default
                if isinstance(param.default, IntLiteral):
                    defaults[param.name] = param.default.value
                elif hasattr(param.default, 'value'):
                    defaults[param.name] = param.default.value
                else:
                    defaults[param.name] = 0  # Fallback

        missing = required - provided
        if missing:
            raise CompileError(
                f"Missing required parameters: {missing}",
                phase="instantiate"
            )

        # Merge with defaults
        params = {**defaults, **kwargs}

        # Generate lattice
        lattice = self._generate_lattice(params)

        # Generate Hamiltonian
        from pbitlang.compiler.codegen import CodeGenerator
        generator = CodeGenerator(params, lattice, self.spin_type)
        return generator.generate(self.source_ast)

    def _generate_lattice(self, params: Dict[str, Any]) -> LatticeGeometry:
        """Generate the lattice geometry from the lattice expression."""
        lattice = self.lattice_expr

        # Map boundary condition
        boundary = BoundaryType.PERIODIC
        if hasattr(lattice, 'boundary'):
            if lattice.boundary == BoundaryCondition.OPEN:
                boundary = BoundaryType.OPEN
            elif lattice.boundary == BoundaryCondition.FIXED:
                boundary = BoundaryType.FIXED

        def eval_expr(expr) -> int:
            """Evaluate an expression to an integer."""
            if isinstance(expr, IntLiteral):
                return expr.value
            elif hasattr(expr, 'name') and expr.name in params:
                return int(params[expr.name])
            elif hasattr(expr, 'value'):
                return int(expr.value)
            return 10  # Default fallback

        if isinstance(lattice, ChainLattice):
            n = eval_expr(lattice.length)
            return generate_chain(n, boundary)

        elif isinstance(lattice, SquareLattice):
            nx = eval_expr(lattice.width)
            ny = eval_expr(lattice.height)
            return generate_square(nx, ny, boundary)

        elif isinstance(lattice, TriangularLattice):
            n = eval_expr(lattice.size)
            return generate_triangular(n, boundary)

        elif isinstance(lattice, HoneycombLattice):
            n = eval_expr(lattice.size)
            return generate_honeycomb(n, boundary)

        elif isinstance(lattice, KagomeLattice):
            n = eval_expr(lattice.size)
            return generate_kagome(n, boundary)

        elif isinstance(lattice, CubicLattice):
            nx = eval_expr(lattice.x)
            ny = eval_expr(lattice.y)
            nz = eval_expr(lattice.z)
            return generate_cubic(nx, ny, nz, boundary)

        elif isinstance(lattice, CustomLattice):
            # Would need to evaluate the adjacency matrix
            raise CompileError("Custom lattices not yet supported", "instantiate")

        else:
            raise CompileError(f"Unknown lattice type: {type(lattice)}", "instantiate")

    def get_parameter_info(self) -> Dict[str, Dict[str, Any]]:
        """Get information about model parameters."""
        info = {}
        for param in self.parameters:
            default = None
            if param.default:
                if isinstance(param.default, IntLiteral):
                    default = param.default.value
                elif hasattr(param.default, 'value'):
                    default = param.default.value

            info[param.name] = {
                "type": str(param.type),
                "default": default,
                "required": param.default is None,
            }
        return info

    def __repr__(self) -> str:
        params = ", ".join(
            f"{p.name}: {p.type}" + (f" = {p.default}" if p.default else "")
            for p in self.parameters
        )
        return f"CompiledModel({self.name}({params}) -> {self.spin_type})"


def compile(
    source: str,
    filename: str = "<input>",
    strict: bool = False,
) -> Union[CompiledModel, List[CompiledModel]]:
    """
    Compile PbitLang source code.

    Args:
        source: PbitLang source code
        filename: Source filename for error messages
        strict: Treat warnings as errors

    Returns:
        CompiledModel if source contains one Hamiltonian,
        List[CompiledModel] if multiple

    Raises:
        CompileError: If compilation fails

    Example:
        >>> source = '''
        ... hamiltonian Ising(n: int, J: real = 1.0) -> ising on chain(n) {
        ...     coupling: sum((i,j) in neighbors) { -J * s[i] * s[j] }
        ... }
        ... '''
        >>> model = compile(source)
        >>> ham = model.instantiate(n=10)
    """
    # Stage 1: Parse
    try:
        program = parse(source, filename)
    except ParseError as e:
        raise CompileError(str(e), phase="parse") from e

    # Stage 2: Type check
    type_errors, type_warnings = typecheck(program)
    if type_errors:
        error_msgs = "\n".join(str(e) for e in type_errors)
        raise CompileError(f"Type errors:\n{error_msgs}", phase="typecheck")

    for warning in type_warnings:
        print(f"Warning: {warning}", file=sys.stderr)

    # Stage 3: Physics validation
    physics_issues, has_errors = validate(program, strict=strict)

    from pbitlang.physics.validator import Severity
    for issue in physics_issues:
        if issue.severity == Severity.ERROR:
            print(f"Error [{issue.code}]: {issue.message}", file=sys.stderr)
        elif issue.severity == Severity.WARNING:
            print(f"Warning [{issue.code}]: {issue.message}", file=sys.stderr)
        else:
            print(f"Info [{issue.code}]: {issue.message}", file=sys.stderr)

    if has_errors:
        raise CompileError("Physics validation failed", phase="validate")

    # Stage 4: Create compiled models
    models = []
    for ham in program.hamiltonians:
        model = CompiledModel(
            name=ham.name,
            parameters=ham.parameters,
            spin_type=ham.spin_type,
            lattice_expr=ham.lattice,
            source_ast=ham,
        )
        models.append(model)

    if len(models) == 1:
        return models[0]
    return models


def compile_file(
    path: Union[str, Path],
    strict: bool = False,
) -> Union[CompiledModel, List[CompiledModel]]:
    """
    Compile a PbitLang source file.

    Args:
        path: Path to .pbit file
        strict: Treat warnings as errors

    Returns:
        Compiled model(s)
    """
    path = Path(path)
    if not path.exists():
        raise CompileError(f"File not found: {path}", phase="io")

    source = path.read_text(encoding="utf-8")
    return compile(source, filename=str(path), strict=strict)


# Convenience function for quick REPL use
def quick_compile(source: str) -> "Any":
    """
    Quickly compile and return a function to instantiate.

    Returns a function that takes parameters and returns a PHAL Hamiltonian.

    Example:
        >>> ising = quick_compile('''
        ...     hamiltonian Ising(n: int, J: real) -> ising on chain(n) {
        ...         coupling: sum((i,j) in neighbors) { -J * s[i] * s[j] }
        ...     }
        ... ''')
        >>> ham = ising(n=10, J=1.0)
    """
    model = compile(source)
    if isinstance(model, list):
        model = model[0]
    return model.instantiate
