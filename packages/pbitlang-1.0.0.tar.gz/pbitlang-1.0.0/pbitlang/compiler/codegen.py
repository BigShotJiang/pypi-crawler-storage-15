"""
PbitLang Code Generator

Generates PHAL Hamiltonians from typed and validated ASTs.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

from pbitlang.ast.nodes import (
    HamiltonianDef,
    Expression,
    IntLiteral,
    RealLiteral,
    BoolLiteral,
    Identifier,
    BinaryOp,
    BinaryOperator,
    UnaryOp,
    UnaryOperator,
    Subscript,
    FunctionCall,
    SumExpr,
    ProductExpr,
    TuplePattern,
    LetExpr,
    ConditionalExpr,
    CouplingTerm,
    FieldTerm,
    CustomTerm,
    SpinType,
    SpinKind,
)
from pbitlang.physics.lattices import LatticeGeometry

# Try to import PHAL (optional dependency)
try:
    from phal.core.program import Hamiltonian, HamiltonianType
    PHAL_AVAILABLE = True
except ImportError:
    PHAL_AVAILABLE = False
    Hamiltonian = None
    HamiltonianType = None


class CodeGenError(Exception):
    """Code generation error."""
    pass


@dataclass
class EvaluationContext:
    """
    Context for expression evaluation during code generation.

    Tracks:
    - Parameter values
    - Let bindings
    - Loop variables (i, j for sum/product)
    - Spin values (for energy calculation)
    """
    params: Dict[str, Any] = field(default_factory=dict)
    bindings: Dict[str, Any] = field(default_factory=dict)
    loop_vars: Dict[str, int] = field(default_factory=dict)
    spins: Optional[List[int]] = None

    def get(self, name: str) -> Any:
        """Get a value from the context."""
        if name in self.loop_vars:
            return self.loop_vars[name]
        if name in self.bindings:
            return self.bindings[name]
        if name in self.params:
            return self.params[name]
        raise CodeGenError(f"Undefined variable: {name}")

    def with_loop_vars(self, **vars) -> "EvaluationContext":
        """Create a new context with additional loop variables."""
        new_loop_vars = {**self.loop_vars, **vars}
        return EvaluationContext(
            params=self.params,
            bindings=self.bindings,
            loop_vars=new_loop_vars,
            spins=self.spins,
        )

    def with_binding(self, name: str, value: Any) -> "EvaluationContext":
        """Create a new context with an additional binding."""
        new_bindings = {**self.bindings, name: value}
        return EvaluationContext(
            params=self.params,
            bindings=new_bindings,
            loop_vars=self.loop_vars,
            spins=self.spins,
        )


class Evaluator:
    """
    Expression evaluator for code generation.

    Evaluates PbitLang expressions to numeric values.
    """

    def __init__(
        self,
        context: EvaluationContext,
        lattice: LatticeGeometry,
        spin_type: SpinType,
    ):
        self.context = context
        self.lattice = lattice
        self.spin_type = spin_type

    def evaluate(self, expr: Expression) -> Any:
        """Evaluate an expression to a value."""

        if isinstance(expr, IntLiteral):
            return expr.value

        if isinstance(expr, RealLiteral):
            return expr.value

        if isinstance(expr, BoolLiteral):
            return expr.value

        if isinstance(expr, Identifier):
            return self._eval_identifier(expr)

        if isinstance(expr, BinaryOp):
            return self._eval_binary_op(expr)

        if isinstance(expr, UnaryOp):
            return self._eval_unary_op(expr)

        if isinstance(expr, Subscript):
            return self._eval_subscript(expr)

        if isinstance(expr, FunctionCall):
            return self._eval_function_call(expr)

        if isinstance(expr, SumExpr):
            return self._eval_sum(expr)

        if isinstance(expr, ProductExpr):
            return self._eval_product(expr)

        if isinstance(expr, LetExpr):
            return self._eval_let(expr)

        if isinstance(expr, ConditionalExpr):
            return self._eval_conditional(expr)

        raise CodeGenError(f"Cannot evaluate expression type: {type(expr).__name__}")

    def _eval_identifier(self, expr: Identifier) -> Any:
        """Evaluate identifier."""
        name = expr.name

        # Special spin variables
        if name in ("s", "x", "σ", "sigma", "θ", "theta"):
            if self.context.spins is None:
                raise CodeGenError(f"Spin variable {name} used outside energy evaluation")
            # Return a special marker - actual spin value is resolved in subscript
            return ("SPIN", self.context.spins)

        return self.context.get(name)

    def _eval_binary_op(self, expr: BinaryOp) -> Any:
        """Evaluate binary operation."""
        left = self.evaluate(expr.left)
        right = self.evaluate(expr.right)

        ops = {
            BinaryOperator.ADD: lambda a, b: a + b,
            BinaryOperator.SUB: lambda a, b: a - b,
            BinaryOperator.MUL: lambda a, b: a * b,
            BinaryOperator.DIV: lambda a, b: a / b if b != 0 else 0,
            BinaryOperator.POW: lambda a, b: a ** b,
            BinaryOperator.MOD: lambda a, b: a % b if b != 0 else 0,
            BinaryOperator.EQ: lambda a, b: a == b,
            BinaryOperator.NE: lambda a, b: a != b,
            BinaryOperator.LT: lambda a, b: a < b,
            BinaryOperator.GT: lambda a, b: a > b,
            BinaryOperator.LE: lambda a, b: a <= b,
            BinaryOperator.GE: lambda a, b: a >= b,
            BinaryOperator.AND: lambda a, b: a and b,
            BinaryOperator.OR: lambda a, b: a or b,
        }

        if expr.operator not in ops:
            raise CodeGenError(f"Unknown operator: {expr.operator}")

        return ops[expr.operator](left, right)

    def _eval_unary_op(self, expr: UnaryOp) -> Any:
        """Evaluate unary operation."""
        operand = self.evaluate(expr.operand)

        if expr.operator == UnaryOperator.NEG:
            return -operand
        if expr.operator == UnaryOperator.POS:
            return +operand
        if expr.operator == UnaryOperator.NOT:
            return not operand

        raise CodeGenError(f"Unknown unary operator: {expr.operator}")

    def _eval_subscript(self, expr: Subscript) -> Any:
        """Evaluate subscript expression."""
        base = self.evaluate(expr.base)

        # Handle spin subscript
        if isinstance(base, tuple) and base[0] == "SPIN":
            spins = base[1]
            idx = int(self.evaluate(expr.indices[0]))
            if 0 <= idx < len(spins):
                return spins[idx]
            raise CodeGenError(f"Spin index {idx} out of range")

        # Handle array/matrix subscript
        if isinstance(base, (list, tuple)):
            indices = [int(self.evaluate(i)) for i in expr.indices]
            result = base
            for idx in indices:
                result = result[idx]
            return result

        raise CodeGenError(f"Cannot subscript {type(base)}")

    def _eval_function_call(self, expr: FunctionCall) -> Any:
        """Evaluate function call."""
        func = expr.function
        args = [self.evaluate(a) for a in expr.arguments]

        # Math functions
        math_funcs = {
            "cos": math.cos,
            "sin": math.sin,
            "exp": math.exp,
            "log": math.log,
            "sqrt": math.sqrt,
            "abs": abs,
        }

        if func in math_funcs:
            return math_funcs[func](*args)

        # Lattice functions - return iterators
        if func == "neighbors":
            return list(self.lattice.neighbor_pairs())

        if func == "all_pairs":
            return list(self.lattice.all_pairs())

        if func == "sites":
            return list(range(self.lattice.num_sites))

        if func == "distance":
            if len(args) >= 2:
                return self.lattice.distance(int(args[0]), int(args[1]))
            return 0.0

        # Potts delta function
        if func == "delta":
            if len(args) >= 2:
                return 1 if args[0] == args[1] else 0
            return 0

        # Length function
        if func == "len":
            if args and isinstance(args[0], (list, tuple)):
                return len(args[0])
            return self.lattice.num_sites

        raise CodeGenError(f"Unknown function: {func}")

    def _eval_sum(self, expr: SumExpr) -> float:
        """Evaluate sum expression."""
        domain = self.evaluate(expr.domain)
        total = 0.0

        for item in domain:
            # Bind loop variables
            if isinstance(expr.pattern, TuplePattern):
                if isinstance(item, (tuple, list)) and len(item) == len(expr.pattern.elements):
                    loop_vars = dict(zip(expr.pattern.elements, item))
                else:
                    continue
            else:
                loop_vars = {expr.pattern: item}

            new_ctx = self.context.with_loop_vars(**loop_vars)
            new_eval = Evaluator(new_ctx, self.lattice, self.spin_type)

            # Check condition
            if expr.condition:
                if not new_eval.evaluate(expr.condition):
                    continue

            # Evaluate body
            value = new_eval.evaluate(expr.body)
            total += float(value)

        return total

    def _eval_product(self, expr: ProductExpr) -> float:
        """Evaluate product expression."""
        domain = self.evaluate(expr.domain)
        result = 1.0

        for item in domain:
            if isinstance(expr.pattern, TuplePattern):
                if isinstance(item, (tuple, list)):
                    loop_vars = dict(zip(expr.pattern.elements, item))
                else:
                    continue
            else:
                loop_vars = {expr.pattern: item}

            new_ctx = self.context.with_loop_vars(**loop_vars)
            new_eval = Evaluator(new_ctx, self.lattice, self.spin_type)

            if expr.condition:
                if not new_eval.evaluate(expr.condition):
                    continue

            value = new_eval.evaluate(expr.body)
            result *= float(value)

        return result

    def _eval_let(self, expr: LetExpr) -> Any:
        """Evaluate let expression."""
        value = self.evaluate(expr.value)
        new_ctx = self.context.with_binding(expr.name, value)
        new_eval = Evaluator(new_ctx, self.lattice, self.spin_type)
        return new_eval.evaluate(expr.body)

    def _eval_conditional(self, expr: ConditionalExpr) -> Any:
        """Evaluate conditional expression."""
        cond = self.evaluate(expr.condition)
        if cond:
            return self.evaluate(expr.then_expr)
        return self.evaluate(expr.else_expr)


class CodeGenerator:
    """
    Generates PHAL Hamiltonians from PbitLang ASTs.
    """

    def __init__(
        self,
        params: Dict[str, Any],
        lattice: LatticeGeometry,
        spin_type: SpinType,
    ):
        self.params = params
        self.lattice = lattice
        self.spin_type = spin_type
        self.context = EvaluationContext(params=params)

    def generate(self, hamiltonian: HamiltonianDef) -> "Hamiltonian":
        """Generate a PHAL Hamiltonian from a definition."""

        # Process let bindings first
        for binding in hamiltonian.let_bindings:
            evaluator = Evaluator(self.context, self.lattice, self.spin_type)
            value = evaluator.evaluate(binding.value)
            self.context = self.context.with_binding(binding.name, value)

        # Determine Hamiltonian type based on spin type
        if self.spin_type.kind in (SpinKind.ISING, SpinKind.BINARY):
            return self._generate_ising(hamiltonian)
        else:
            raise CodeGenError(f"Unsupported spin type: {self.spin_type}")

    def _generate_ising(self, hamiltonian: HamiltonianDef) -> "Hamiltonian":
        """Generate an Ising-type Hamiltonian."""
        n = self.lattice.num_sites

        # Initialize coupling matrix and field vector
        J = [[0.0] * n for _ in range(n)]
        h = [0.0] * n

        # Process energy terms
        for term in hamiltonian.terms:
            if isinstance(term, CouplingTerm):
                self._process_coupling_term(term.expression, J)
            elif isinstance(term, FieldTerm):
                self._process_field_term(term.expression, h)
            elif isinstance(term, CustomTerm):
                # Try to classify the custom term
                self._process_custom_term(term.expression, J, h)

        # Create PHAL Hamiltonian
        if PHAL_AVAILABLE:
            return Hamiltonian.ising(J, h)
        else:
            # Return a dict representation if PHAL not available
            return {
                "type": "ising",
                "coupling": J,
                "field": h,
                "num_spins": n,
            }

    def _process_coupling_term(self, expr: SumExpr, J: List[List[float]]) -> None:
        """Process a coupling term and fill the J matrix."""
        if not isinstance(expr, SumExpr):
            return

        # Get the domain (neighbor pairs)
        evaluator = Evaluator(self.context, self.lattice, self.spin_type)
        domain = evaluator.evaluate(expr.domain)

        for item in domain:
            if not isinstance(item, (tuple, list)) or len(item) != 2:
                continue

            i, j = int(item[0]), int(item[1])

            # Create context with loop variables
            if isinstance(expr.pattern, TuplePattern):
                loop_vars = dict(zip(expr.pattern.elements, [i, j]))
            else:
                continue  # Coupling needs pair pattern

            new_ctx = self.context.with_loop_vars(**loop_vars)

            # Check condition
            if expr.condition:
                cond_eval = Evaluator(new_ctx, self.lattice, self.spin_type)
                if not cond_eval.evaluate(expr.condition):
                    continue

            # Evaluate the coupling coefficient
            # We need to extract the coefficient from -J * s[i] * s[j]
            coeff = self._extract_coupling_coefficient(expr.body, new_ctx)

            # Store in J matrix (symmetric)
            J[i][j] = coeff
            J[j][i] = coeff

    def _process_field_term(self, expr: SumExpr, h: List[float]) -> None:
        """Process a field term and fill the h vector."""
        if not isinstance(expr, SumExpr):
            return

        evaluator = Evaluator(self.context, self.lattice, self.spin_type)
        domain = evaluator.evaluate(expr.domain)

        for item in domain:
            i = int(item) if not isinstance(item, (tuple, list)) else int(item[0])

            # Create context
            if isinstance(expr.pattern, TuplePattern):
                loop_vars = {expr.pattern.elements[0]: i}
            else:
                loop_vars = {expr.pattern: i}

            new_ctx = self.context.with_loop_vars(**loop_vars)

            # Check condition
            if expr.condition:
                cond_eval = Evaluator(new_ctx, self.lattice, self.spin_type)
                if not cond_eval.evaluate(expr.condition):
                    continue

            # Extract field coefficient
            coeff = self._extract_field_coefficient(expr.body, new_ctx)
            h[i] = coeff

    def _process_custom_term(
        self,
        expr: Expression,
        J: List[List[float]],
        h: List[float],
    ) -> None:
        """Process a custom term - try to classify and add to J or h."""
        # For now, try to evaluate as a sum
        if isinstance(expr, SumExpr):
            # Determine if it's coupling or field based on pattern
            if isinstance(expr.pattern, TuplePattern) and len(expr.pattern.elements) == 2:
                self._process_coupling_term(expr, J)
            else:
                self._process_field_term(expr, h)

    def _extract_coupling_coefficient(
        self,
        expr: Expression,
        ctx: EvaluationContext,
    ) -> float:
        """
        Extract coupling coefficient from expression like -J * s[i] * s[j].

        Returns the value of J (the coupling strength).
        """
        # Simple case: -J * s[i] * s[j] or J * s[i] * s[j]
        # We need to find the coefficient by removing spin terms

        if isinstance(expr, BinaryOp) and expr.operator == BinaryOperator.MUL:
            # Check if left or right is spin product
            left = expr.left
            right = expr.right

            # Try to evaluate non-spin part
            if self._is_spin_product(right):
                # Coefficient is on the left
                evaluator = Evaluator(ctx, self.lattice, self.spin_type)
                return evaluator.evaluate(left)
            elif self._is_spin_product(left):
                # Coefficient is on the right
                evaluator = Evaluator(ctx, self.lattice, self.spin_type)
                return evaluator.evaluate(right)

            # Check for nested structure: (coeff * s[i]) * s[j]
            if isinstance(left, BinaryOp) and left.operator == BinaryOperator.MUL:
                if self._is_spin_expr(left.right) and self._is_spin_expr(right):
                    evaluator = Evaluator(ctx, self.lattice, self.spin_type)
                    return evaluator.evaluate(left.left)

        if isinstance(expr, UnaryOp) and expr.operator == UnaryOperator.NEG:
            # -(...) -> negate the coefficient
            return -self._extract_coupling_coefficient(expr.operand, ctx)

        # Fallback: try to evaluate entire expression with spin values = 1
        # This gives us the coefficient for ferromagnetic alignment
        ctx_with_spins = EvaluationContext(
            params=ctx.params,
            bindings=ctx.bindings,
            loop_vars=ctx.loop_vars,
            spins=[1] * self.lattice.num_sites,  # All spins +1
        )
        evaluator = Evaluator(ctx_with_spins, self.lattice, self.spin_type)
        try:
            return evaluator.evaluate(expr)
        except:
            return 0.0

    def _extract_field_coefficient(
        self,
        expr: Expression,
        ctx: EvaluationContext,
    ) -> float:
        """Extract field coefficient from expression like -h * s[i]."""
        if isinstance(expr, BinaryOp) and expr.operator == BinaryOperator.MUL:
            left = expr.left
            right = expr.right

            if self._is_spin_expr(right):
                evaluator = Evaluator(ctx, self.lattice, self.spin_type)
                return evaluator.evaluate(left)
            elif self._is_spin_expr(left):
                evaluator = Evaluator(ctx, self.lattice, self.spin_type)
                return evaluator.evaluate(right)

        if isinstance(expr, UnaryOp) and expr.operator == UnaryOperator.NEG:
            return -self._extract_field_coefficient(expr.operand, ctx)

        # Fallback
        ctx_with_spins = EvaluationContext(
            params=ctx.params,
            bindings=ctx.bindings,
            loop_vars=ctx.loop_vars,
            spins=[1] * self.lattice.num_sites,
        )
        evaluator = Evaluator(ctx_with_spins, self.lattice, self.spin_type)
        try:
            return evaluator.evaluate(expr)
        except:
            return 0.0

    def _is_spin_expr(self, expr: Expression) -> bool:
        """Check if expression is a spin variable (s[i], x[i], etc.)."""
        if isinstance(expr, Subscript):
            if isinstance(expr.base, Identifier):
                return expr.base.name in ("s", "x", "σ", "sigma", "θ", "theta")
        return False

    def _is_spin_product(self, expr: Expression) -> bool:
        """Check if expression is a product of two spin variables."""
        if isinstance(expr, BinaryOp) and expr.operator == BinaryOperator.MUL:
            return self._is_spin_expr(expr.left) and self._is_spin_expr(expr.right)
        return False


def generate_coupling_matrix(
    hamiltonian: HamiltonianDef,
    params: Dict[str, Any],
    lattice: LatticeGeometry,
) -> List[List[float]]:
    """
    Generate coupling matrix from Hamiltonian definition.

    Convenience function for extracting just the J matrix.
    """
    spin_type = hamiltonian.spin_type
    generator = CodeGenerator(params, lattice, spin_type)
    result = generator.generate(hamiltonian)

    if isinstance(result, dict):
        return result["coupling"]
    return result.coupling


def generate_field_vector(
    hamiltonian: HamiltonianDef,
    params: Dict[str, Any],
    lattice: LatticeGeometry,
) -> List[float]:
    """
    Generate field vector from Hamiltonian definition.

    Convenience function for extracting just the h vector.
    """
    spin_type = hamiltonian.spin_type
    generator = CodeGenerator(params, lattice, spin_type)
    result = generator.generate(hamiltonian)

    if isinstance(result, dict):
        return result["field"]
    return result.field
