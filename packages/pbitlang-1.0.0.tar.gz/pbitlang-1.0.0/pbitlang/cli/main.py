"""PbitLang command-line interface implementation."""

import argparse
import sys
import json
from pathlib import Path
from typing import Optional, Dict, Any

from ..compiler.compile import compile_source, CompilationResult
from ..stdlib.models import STANDARD_MODELS


def parse_param(param_str: str) -> tuple:
    """Parse a parameter string like 'n=10' or 'J=1.5'."""
    if "=" not in param_str:
        raise ValueError(f"Invalid parameter format: {param_str}. Expected 'name=value'")

    name, value_str = param_str.split("=", 1)
    name = name.strip()
    value_str = value_str.strip()

    # Try to parse as int, then float, then string
    try:
        value = int(value_str)
    except ValueError:
        try:
            value = float(value_str)
        except ValueError:
            if value_str.lower() == "true":
                value = True
            elif value_str.lower() == "false":
                value = False
            else:
                value = value_str

    return name, value


def cmd_compile(args) -> int:
    """Compile a PbitLang source file."""
    source_path = Path(args.source)

    if not source_path.exists():
        print(f"Error: File not found: {source_path}", file=sys.stderr)
        return 1

    # Read source
    source = source_path.read_text()

    # Parse parameters
    params = {}
    if args.param:
        for param_str in args.param:
            try:
                name, value = parse_param(param_str)
                params[name] = value
            except ValueError as e:
                print(f"Error: {e}", file=sys.stderr)
                return 1

    # Compile
    try:
        result = compile_source(source, params)
    except Exception as e:
        print(f"Compilation error: {e}", file=sys.stderr)
        return 1

    # Print warnings
    for warning in result.warnings:
        print(f"Warning: {warning}", file=sys.stderr)

    # Output based on target
    if args.target == "phal":
        hamiltonian = result.to_phal()
        output = {
            "num_spins": hamiltonian.num_spins,
            "spin_type": hamiltonian.spin_type,
            "coupling_shape": list(hamiltonian.coupling.shape) if hamiltonian.coupling is not None else None,
            "has_bias": hamiltonian.bias is not None,
        }
        print(json.dumps(output, indent=2))

    elif args.target == "json":
        output = {
            "hamiltonian_type": result.hamiltonian_type,
            "num_spins": result.num_spins,
            "coupling": result.coupling.tolist() if result.coupling is not None else None,
            "bias": result.bias.tolist() if result.bias is not None else None,
            "warnings": result.warnings,
        }

        if args.output:
            Path(args.output).write_text(json.dumps(output, indent=2))
            print(f"Written to {args.output}")
        else:
            print(json.dumps(output, indent=2))

    elif args.target == "info":
        print(f"Hamiltonian type: {result.hamiltonian_type}")
        print(f"Number of spins: {result.num_spins}")
        if result.coupling is not None:
            density = (result.coupling != 0).sum() / result.coupling.size
            print(f"Coupling matrix: {result.coupling.shape}, density={density:.2%}")
        if result.bias is not None:
            print(f"Bias vector: {result.bias.shape}")
        if result.warnings:
            print(f"Warnings: {len(result.warnings)}")

    else:
        print(f"Error: Unknown target '{args.target}'", file=sys.stderr)
        return 1

    return 0


def cmd_check(args) -> int:
    """Check a PbitLang source file for errors."""
    source_path = Path(args.source)

    if not source_path.exists():
        print(f"Error: File not found: {source_path}", file=sys.stderr)
        return 1

    source = source_path.read_text()

    # Try to parse and validate
    try:
        from ..parser.lexer import Lexer
        from ..parser.parser import Parser
        from ..types.checker import TypeChecker
        from ..physics.validator import PhysicsValidator

        # Lexical analysis
        lexer = Lexer(source)
        tokens = lexer.tokenize()
        if args.verbose:
            print(f"Lexer: {len(tokens)} tokens")

        # Parsing
        parser = Parser(tokens)
        ast = parser.parse()
        if args.verbose:
            print(f"Parser: AST with {len(ast.definitions)} definitions")

        # Type checking
        checker = TypeChecker()
        typed_ast = checker.check(ast)
        if args.verbose:
            print("Type checker: passed")

        # Physics validation
        validator = PhysicsValidator()
        warnings = validator.validate(typed_ast)

        if warnings:
            for warning in warnings:
                print(f"Warning: {warning}")

        print(f"OK: {source_path}")
        return 0

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def cmd_stdlib(args) -> int:
    """List or show standard library models."""
    if args.action == "list":
        print("Standard Library Models:")
        print("-" * 40)
        for name, model_class in STANDARD_MODELS.items():
            doc = model_class.__doc__ or "No description"
            doc_line = doc.strip().split("\n")[0]
            print(f"  {name:25} {doc_line}")
        return 0

    elif args.action == "info":
        if not args.model:
            print("Error: Model name required for 'info'", file=sys.stderr)
            return 1

        model_name = args.model
        if model_name not in STANDARD_MODELS:
            print(f"Error: Unknown model '{model_name}'", file=sys.stderr)
            print(f"Available: {', '.join(STANDARD_MODELS.keys())}")
            return 1

        model_class = STANDARD_MODELS[model_name]
        print(f"Model: {model_name}")
        print("-" * 40)
        if model_class.__doc__:
            print(model_class.__doc__)

        # Show source if available
        if hasattr(model_class, 'SOURCE'):
            print("\nSource:")
            print(model_class.SOURCE)

        return 0

    else:
        print(f"Error: Unknown stdlib action '{args.action}'", file=sys.stderr)
        return 1


def cmd_version(args) -> int:
    """Show version information."""
    print("PbitLang 1.0.0")
    print("A domain-specific language for thermodynamic computing Hamiltonians")
    print("Compiles to PHAL (P-bit Hardware Abstraction Layer)")
    return 0


def cli(argv: Optional[list] = None) -> int:
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        prog="pbitlang",
        description="PbitLang: Domain-specific language for thermodynamic computing"
    )

    subparsers = parser.add_subparsers(dest="command", help="Commands")

    # compile command
    compile_parser = subparsers.add_parser("compile", help="Compile a PbitLang source file")
    compile_parser.add_argument("source", help="Source file path")
    compile_parser.add_argument("-p", "--param", action="append", help="Parameter (name=value)")
    compile_parser.add_argument("-o", "--output", help="Output file path")
    compile_parser.add_argument("-t", "--target", default="info",
                                choices=["phal", "json", "info"],
                                help="Output target format")
    compile_parser.set_defaults(func=cmd_compile)

    # check command
    check_parser = subparsers.add_parser("check", help="Check source for errors")
    check_parser.add_argument("source", help="Source file path")
    check_parser.add_argument("-v", "--verbose", action="store_true", help="Verbose output")
    check_parser.set_defaults(func=cmd_check)

    # stdlib command
    stdlib_parser = subparsers.add_parser("stdlib", help="Standard library operations")
    stdlib_parser.add_argument("action", choices=["list", "info"], help="Action to perform")
    stdlib_parser.add_argument("model", nargs="?", help="Model name (for info)")
    stdlib_parser.set_defaults(func=cmd_stdlib)

    # version command
    version_parser = subparsers.add_parser("version", help="Show version")
    version_parser.set_defaults(func=cmd_version)

    args = parser.parse_args(argv)

    if not args.command:
        parser.print_help()
        return 0

    return args.func(args)


def main():
    """Entry point for console script."""
    sys.exit(cli())


if __name__ == "__main__":
    main()
