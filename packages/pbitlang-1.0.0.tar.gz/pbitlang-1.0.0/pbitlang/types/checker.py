"""
PbitLang Type Checker

Performs type checking and inference on PbitLang ASTs.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Tuple, Union

from pbitlang.ast.nodes import (
    Node,
    SourceLocation,
    # Types
    Type,
    PrimitiveType,
    PrimitiveKind,
    SpinType,
    SpinKind,
    ArrayType,
    MatrixType,
    CouplingType,
    # Expressions
    Expression,
    IntLiteral,
    RealLiteral,
    BoolLiteral,
    StringLiteral,
    Identifier,
    BinaryOp,
    BinaryOperator,
    UnaryOp,
    UnaryOperator,
    Subscript,
    FunctionCall,
    ArrayExpr,
    MatrixExpr,
    RangeExpr,
    ConditionalExpr,
    LetExpr,
    SumExpr,
    ProductExpr,
    TuplePattern,
    # Declarations
    Parameter,
    Constant,
    LetBinding,
    # Energy
    EnergyTerm,
    CouplingTerm,
    FieldTerm,
    CustomTerm,
    # Top-level
    HamiltonianDef,
    Program,
)


class TypeError(Exception):
    """Type checking error."""

    def __init__(self, message: str, location: SourceLocation, notes: List[str] = None):
        self.message = message
        self.location = location
        self.notes = notes or []
        super().__init__(self.format_message())

    def format_message(self) -> str:
        msg = f"Type error at {self.location}: {self.message}"
        for note in self.notes:
            msg += f"\n  note: {note}"
        return msg


@dataclass
class TypeEnvironment:
    """
    Type environment for type checking.

    Maintains bindings from names to types, supporting nested scopes.
    """
    bindings: Dict[str, Type] = field(default_factory=dict)
    parent: Optional["TypeEnvironment"] = None

    # Special entries for Hamiltonian context
    spin_type: Optional[SpinType] = None
    lattice_size: Optional[int] = None

    def lookup(self, name: str) -> Optional[Type]:
        """Look up a name in the environment."""
        if name in self.bindings:
            return self.bindings[name]
        if self.parent:
            return self.parent.lookup(name)
        return None

    def bind(self, name: str, type: Type) -> None:
        """Bind a name to a type in current scope."""
        self.bindings[name] = type

    def child(self) -> "TypeEnvironment":
        """Create a child environment."""
        return TypeEnvironment(parent=self, spin_type=self.spin_type,
                              lattice_size=self.lattice_size)


# Built-in function signatures
BUILTIN_FUNCTIONS = {
    # Lattice functions
    "neighbors": ("lattice", "iterator[(int, int)]"),
    "next_neighbors": ("lattice", "iterator[(int, int)]"),
    "all_pairs": ("lattice", "iterator[(int, int)]"),
    "sites": ("lattice", "iterator[int]"),
    "distance": ("(int, int)", "real"),
    "coordination": ("int", "int"),

    # Math functions
    "cos": ("real", "real"),
    "sin": ("real", "real"),
    "exp": ("real", "real"),
    "log": ("real", "real"),
    "sqrt": ("real", "real"),
    "abs": ("real", "real"),

    # Spin functions
    "delta": ("(spin, spin)", "int"),  # Kronecker delta for Potts

    # Utility
    "len": ("array", "int"),
    "sum": ("array[real]", "real"),
    "min": ("array[real]", "real"),
    "max": ("array[real]", "real"),
}


class TypeChecker:
    """
    Type checker for PbitLang.

    Validates types and performs type inference.
    """

    def __init__(self):
        self.errors: List[TypeError] = []
        self.warnings: List[str] = []

    def error(self, message: str, location: SourceLocation, notes: List[str] = None) -> None:
        """Record a type error."""
        self.errors.append(TypeError(message, location, notes))

    def warn(self, message: str, location: SourceLocation) -> None:
        """Record a warning."""
        self.warnings.append(f"{location}: {message}")

    # =========================================================================
    # Type utilities
    # =========================================================================

    def types_equal(self, t1: Type, t2: Type) -> bool:
        """Check if two types are equal."""
        if type(t1) != type(t2):
            return False

        if isinstance(t1, PrimitiveType):
            return t1.kind == t2.kind

        if isinstance(t1, SpinType):
            return t1.kind == t2.kind and t1.q == t2.q

        if isinstance(t1, ArrayType):
            return self.types_equal(t1.element_type, t2.element_type)

        if isinstance(t1, MatrixType):
            return self.types_equal(t1.element_type, t2.element_type)

        return True

    def is_numeric(self, t: Type) -> bool:
        """Check if type is numeric."""
        if isinstance(t, PrimitiveType):
            return t.kind in (PrimitiveKind.INT, PrimitiveKind.REAL, PrimitiveKind.COMPLEX)
        return False

    def is_real_or_int(self, t: Type) -> bool:
        """Check if type is real or int."""
        if isinstance(t, PrimitiveType):
            return t.kind in (PrimitiveKind.INT, PrimitiveKind.REAL)
        return False

    def common_numeric_type(self, t1: Type, t2: Type) -> Optional[Type]:
        """Get common type for numeric operation."""
        if not (self.is_numeric(t1) and self.is_numeric(t2)):
            return None

        # Promotion rules: int < real < complex
        if isinstance(t1, PrimitiveType) and isinstance(t2, PrimitiveType):
            if t1.kind == PrimitiveKind.COMPLEX or t2.kind == PrimitiveKind.COMPLEX:
                return PrimitiveType(PrimitiveKind.COMPLEX)
            if t1.kind == PrimitiveKind.REAL or t2.kind == PrimitiveKind.REAL:
                return PrimitiveType(PrimitiveKind.REAL)
            return PrimitiveType(PrimitiveKind.INT)

        return None

    # =========================================================================
    # Expression type checking
    # =========================================================================

    def check_expression(self, expr: Expression, env: TypeEnvironment) -> Type:
        """Type check an expression and return its type."""

        if isinstance(expr, IntLiteral):
            t = PrimitiveType(PrimitiveKind.INT)
            expr.inferred_type = t
            return t

        if isinstance(expr, RealLiteral):
            t = PrimitiveType(PrimitiveKind.REAL)
            expr.inferred_type = t
            return t

        if isinstance(expr, BoolLiteral):
            t = PrimitiveType(PrimitiveKind.BOOL)
            expr.inferred_type = t
            return t

        if isinstance(expr, StringLiteral):
            # Strings are mainly for annotations, treat as opaque
            t = PrimitiveType(PrimitiveKind.INT)  # Placeholder
            expr.inferred_type = t
            return t

        if isinstance(expr, Identifier):
            return self._check_identifier(expr, env)

        if isinstance(expr, BinaryOp):
            return self._check_binary_op(expr, env)

        if isinstance(expr, UnaryOp):
            return self._check_unary_op(expr, env)

        if isinstance(expr, Subscript):
            return self._check_subscript(expr, env)

        if isinstance(expr, FunctionCall):
            return self._check_function_call(expr, env)

        if isinstance(expr, ArrayExpr):
            return self._check_array_expr(expr, env)

        if isinstance(expr, MatrixExpr):
            return self._check_matrix_expr(expr, env)

        if isinstance(expr, RangeExpr):
            return self._check_range_expr(expr, env)

        if isinstance(expr, ConditionalExpr):
            return self._check_conditional(expr, env)

        if isinstance(expr, LetExpr):
            return self._check_let_expr(expr, env)

        if isinstance(expr, SumExpr):
            return self._check_sum_expr(expr, env)

        if isinstance(expr, ProductExpr):
            return self._check_product_expr(expr, env)

        self.error(f"Unknown expression type: {type(expr).__name__}", expr.location)
        return PrimitiveType(PrimitiveKind.INT)  # Fallback

    def _check_identifier(self, expr: Identifier, env: TypeEnvironment) -> Type:
        """Type check identifier."""
        # Check for spin variable
        if expr.name == "s" and env.spin_type:
            if env.spin_type.kind in (SpinKind.ISING, SpinKind.BINARY):
                t = env.spin_type
                expr.inferred_type = t
                return t

        # Look up in environment
        t = env.lookup(expr.name)
        if t is None:
            self.error(f"Undefined variable: {expr.name}", expr.location)
            return PrimitiveType(PrimitiveKind.INT)

        expr.inferred_type = t
        return t

    def _check_binary_op(self, expr: BinaryOp, env: TypeEnvironment) -> Type:
        """Type check binary operation."""
        left_type = self.check_expression(expr.left, env)
        right_type = self.check_expression(expr.right, env)

        # Arithmetic operators
        if expr.operator in (BinaryOperator.ADD, BinaryOperator.SUB,
                            BinaryOperator.MUL, BinaryOperator.DIV,
                            BinaryOperator.POW, BinaryOperator.MOD):
            result = self.common_numeric_type(left_type, right_type)
            if result is None:
                self.error(
                    f"Cannot apply {expr.operator.value} to {left_type} and {right_type}",
                    expr.location
                )
                result = PrimitiveType(PrimitiveKind.REAL)
            expr.inferred_type = result
            return result

        # Comparison operators
        if expr.operator in (BinaryOperator.EQ, BinaryOperator.NE,
                            BinaryOperator.LT, BinaryOperator.GT,
                            BinaryOperator.LE, BinaryOperator.GE):
            if not (self.is_numeric(left_type) and self.is_numeric(right_type)):
                self.error(
                    f"Cannot compare {left_type} and {right_type}",
                    expr.location
                )
            result = PrimitiveType(PrimitiveKind.BOOL)
            expr.inferred_type = result
            return result

        # Logical operators
        if expr.operator in (BinaryOperator.AND, BinaryOperator.OR):
            if not (isinstance(left_type, PrimitiveType) and
                    left_type.kind == PrimitiveKind.BOOL):
                self.error(f"Expected bool, got {left_type}", expr.left.location)
            if not (isinstance(right_type, PrimitiveType) and
                    right_type.kind == PrimitiveKind.BOOL):
                self.error(f"Expected bool, got {right_type}", expr.right.location)
            result = PrimitiveType(PrimitiveKind.BOOL)
            expr.inferred_type = result
            return result

        self.error(f"Unknown operator: {expr.operator}", expr.location)
        return PrimitiveType(PrimitiveKind.INT)

    def _check_unary_op(self, expr: UnaryOp, env: TypeEnvironment) -> Type:
        """Type check unary operation."""
        operand_type = self.check_expression(expr.operand, env)

        if expr.operator in (UnaryOperator.NEG, UnaryOperator.POS):
            if not self.is_numeric(operand_type):
                self.error(
                    f"Cannot apply {expr.operator.value} to {operand_type}",
                    expr.location
                )
            expr.inferred_type = operand_type
            return operand_type

        if expr.operator == UnaryOperator.NOT:
            if not (isinstance(operand_type, PrimitiveType) and
                    operand_type.kind == PrimitiveKind.BOOL):
                self.error(f"Expected bool for 'not', got {operand_type}", expr.location)
            result = PrimitiveType(PrimitiveKind.BOOL)
            expr.inferred_type = result
            return result

        return operand_type

    def _check_subscript(self, expr: Subscript, env: TypeEnvironment) -> Type:
        """Type check subscript expression."""
        base_type = self.check_expression(expr.base, env)

        # Check indices are integers
        for idx in expr.indices:
            idx_type = self.check_expression(idx, env)
            if not (isinstance(idx_type, PrimitiveType) and
                    idx_type.kind == PrimitiveKind.INT):
                # Allow identifiers as well (for field access)
                if not isinstance(idx, Identifier):
                    self.error(f"Index must be integer, got {idx_type}", idx.location)

        # Determine result type
        if isinstance(base_type, ArrayType):
            expr.inferred_type = base_type.element_type
            return base_type.element_type

        if isinstance(base_type, MatrixType):
            if len(expr.indices) == 2:
                expr.inferred_type = base_type.element_type
                return base_type.element_type
            elif len(expr.indices) == 1:
                result = ArrayType(base_type.element_type)
                expr.inferred_type = result
                return result

        if isinstance(base_type, SpinType):
            # s[i] is a spin value
            expr.inferred_type = base_type
            return base_type

        # Fallback for unknown base types
        result = PrimitiveType(PrimitiveKind.REAL)
        expr.inferred_type = result
        return result

    def _check_function_call(self, expr: FunctionCall, env: TypeEnvironment) -> Type:
        """Type check function call."""
        # Check argument types
        for arg in expr.arguments:
            self.check_expression(arg, env)

        for arg in expr.keyword_args.values():
            self.check_expression(arg, env)

        # Built-in functions
        if expr.function in BUILTIN_FUNCTIONS:
            _, return_type = BUILTIN_FUNCTIONS[expr.function]
            # Simplified: return real for most numeric functions
            if return_type == "real":
                result = PrimitiveType(PrimitiveKind.REAL)
            elif return_type == "int":
                result = PrimitiveType(PrimitiveKind.INT)
            elif return_type.startswith("iterator"):
                # Iterator types are handled specially in sum/product
                result = PrimitiveType(PrimitiveKind.INT)  # Placeholder
            else:
                result = PrimitiveType(PrimitiveKind.REAL)
            expr.inferred_type = result
            return result

        # User-defined functions would be looked up here
        self.warn(f"Unknown function: {expr.function}", expr.location)
        result = PrimitiveType(PrimitiveKind.REAL)
        expr.inferred_type = result
        return result

    def _check_array_expr(self, expr: ArrayExpr, env: TypeEnvironment) -> Type:
        """Type check array expression."""
        if not expr.elements:
            result = ArrayType(PrimitiveType(PrimitiveKind.REAL))
            expr.inferred_type = result
            return result

        elem_types = [self.check_expression(e, env) for e in expr.elements]
        # Use first element's type
        result = ArrayType(elem_types[0])
        expr.inferred_type = result
        return result

    def _check_matrix_expr(self, expr: MatrixExpr, env: TypeEnvironment) -> Type:
        """Type check matrix expression."""
        if not expr.rows or not expr.rows[0]:
            result = MatrixType(PrimitiveType(PrimitiveKind.REAL))
            expr.inferred_type = result
            return result

        # Check all elements
        for row in expr.rows:
            for elem in row:
                self.check_expression(elem, env)

        # Use first element's type
        elem_type = expr.rows[0][0].inferred_type or PrimitiveType(PrimitiveKind.REAL)
        result = MatrixType(elem_type)
        expr.inferred_type = result
        return result

    def _check_range_expr(self, expr: RangeExpr, env: TypeEnvironment) -> Type:
        """Type check range expression."""
        start_type = self.check_expression(expr.start, env)
        end_type = self.check_expression(expr.end, env)

        if not (isinstance(start_type, PrimitiveType) and
                start_type.kind == PrimitiveKind.INT):
            self.error(f"Range start must be int, got {start_type}", expr.start.location)

        if not (isinstance(end_type, PrimitiveType) and
                end_type.kind == PrimitiveKind.INT):
            self.error(f"Range end must be int, got {end_type}", expr.end.location)

        result = ArrayType(PrimitiveType(PrimitiveKind.INT))
        expr.inferred_type = result
        return result

    def _check_conditional(self, expr: ConditionalExpr, env: TypeEnvironment) -> Type:
        """Type check conditional expression."""
        cond_type = self.check_expression(expr.condition, env)

        if not (isinstance(cond_type, PrimitiveType) and
                cond_type.kind == PrimitiveKind.BOOL):
            self.error(f"Condition must be bool, got {cond_type}", expr.condition.location)

        then_type = self.check_expression(expr.then_expr, env)
        else_type = self.check_expression(expr.else_expr, env)

        # Types should be compatible
        result = self.common_numeric_type(then_type, else_type)
        if result is None:
            result = then_type  # Use then branch type

        expr.inferred_type = result
        return result

    def _check_let_expr(self, expr: LetExpr, env: TypeEnvironment) -> Type:
        """Type check let expression."""
        value_type = self.check_expression(expr.value, env)

        # Create new scope with binding
        child_env = env.child()
        child_env.bind(expr.name, expr.type_annotation or value_type)

        result = self.check_expression(expr.body, child_env)
        expr.inferred_type = result
        return result

    def _check_sum_expr(self, expr: SumExpr, env: TypeEnvironment) -> Type:
        """Type check sum expression."""
        # Check domain
        self.check_expression(expr.domain, env)

        # Create scope with iteration variables
        child_env = env.child()

        if isinstance(expr.pattern, TuplePattern):
            for elem in expr.pattern.elements:
                child_env.bind(elem, PrimitiveType(PrimitiveKind.INT))
        else:
            child_env.bind(expr.pattern, PrimitiveType(PrimitiveKind.INT))

        # Check condition if present
        if expr.condition:
            cond_type = self.check_expression(expr.condition, child_env)
            if not (isinstance(cond_type, PrimitiveType) and
                    cond_type.kind == PrimitiveKind.BOOL):
                self.error(f"Where condition must be bool", expr.condition.location)

        # Check body
        body_type = self.check_expression(expr.body, child_env)

        if not self.is_numeric(body_type):
            self.error(f"Sum body must be numeric, got {body_type}", expr.body.location)

        # Result is same as body type (summed)
        result = body_type
        expr.inferred_type = result
        return result

    def _check_product_expr(self, expr: ProductExpr, env: TypeEnvironment) -> Type:
        """Type check product expression."""
        # Similar to sum
        self.check_expression(expr.domain, env)

        child_env = env.child()

        if isinstance(expr.pattern, TuplePattern):
            for elem in expr.pattern.elements:
                child_env.bind(elem, PrimitiveType(PrimitiveKind.INT))
        else:
            child_env.bind(expr.pattern, PrimitiveType(PrimitiveKind.INT))

        if expr.condition:
            self.check_expression(expr.condition, child_env)

        body_type = self.check_expression(expr.body, child_env)
        expr.inferred_type = body_type
        return body_type

    # =========================================================================
    # Declaration type checking
    # =========================================================================

    def check_parameter(self, param: Parameter, env: TypeEnvironment) -> None:
        """Type check a parameter declaration."""
        env.bind(param.name, param.type)

        if param.default:
            default_type = self.check_expression(param.default, env)
            if not self.types_equal(param.type, default_type):
                # Allow int -> real promotion
                if not (isinstance(param.type, PrimitiveType) and
                        param.type.kind == PrimitiveKind.REAL and
                        isinstance(default_type, PrimitiveType) and
                        default_type.kind == PrimitiveKind.INT):
                    self.error(
                        f"Default value type {default_type} doesn't match "
                        f"parameter type {param.type}",
                        param.location
                    )

        if param.constraint:
            self.check_expression(param.constraint, env)

    def check_let_binding(self, binding: LetBinding, env: TypeEnvironment) -> None:
        """Type check a let binding."""
        value_type = self.check_expression(binding.value, env)

        if binding.type_annotation:
            if not self.types_equal(binding.type_annotation, value_type):
                self.error(
                    f"Let binding type {binding.type_annotation} doesn't match "
                    f"value type {value_type}",
                    binding.location
                )
            env.bind(binding.name, binding.type_annotation)
        else:
            env.bind(binding.name, value_type)

    # =========================================================================
    # Hamiltonian type checking
    # =========================================================================

    def check_hamiltonian(self, ham: HamiltonianDef, env: TypeEnvironment) -> None:
        """Type check a Hamiltonian definition."""
        # Create environment with parameters
        ham_env = env.child()
        ham_env.spin_type = ham.spin_type

        # Bind parameters
        for param in ham.parameters:
            self.check_parameter(param, ham_env)

        # Bind spin variable
        if ham.spin_type.kind == SpinKind.ISING:
            ham_env.bind("s", ham.spin_type)
        elif ham.spin_type.kind == SpinKind.BINARY:
            ham_env.bind("x", ham.spin_type)
        elif ham.spin_type.kind == SpinKind.POTTS:
            ham_env.bind("σ", ham.spin_type)
            ham_env.bind("sigma", ham.spin_type)  # ASCII alias
        elif ham.spin_type.kind in (SpinKind.CLOCK, SpinKind.CONTINUOUS):
            ham_env.bind("θ", ham.spin_type)
            ham_env.bind("theta", ham.spin_type)

        # Check constraints
        for constraint in ham.constraints:
            if hasattr(constraint, 'condition'):
                self.check_expression(constraint.condition, ham_env)

        # Check let bindings
        for binding in ham.let_bindings:
            self.check_let_binding(binding, ham_env)

        # Check energy terms
        for term in ham.terms:
            self._check_energy_term(term, ham_env)

    def _check_energy_term(self, term: EnergyTerm, env: TypeEnvironment) -> None:
        """Type check an energy term."""
        if isinstance(term, CouplingTerm):
            result_type = self.check_expression(term.expression, env)
            if not self.is_numeric(result_type):
                self.error(
                    f"Coupling term must be numeric, got {result_type}",
                    term.location
                )

        elif isinstance(term, FieldTerm):
            result_type = self.check_expression(term.expression, env)
            if not self.is_numeric(result_type):
                self.error(
                    f"Field term must be numeric, got {result_type}",
                    term.location
                )

        elif isinstance(term, CustomTerm):
            result_type = self.check_expression(term.expression, env)
            if not self.is_numeric(result_type):
                self.error(
                    f"Energy term must be numeric, got {result_type}",
                    term.location
                )

    # =========================================================================
    # Program type checking
    # =========================================================================

    def check_program(self, program: Program) -> List[TypeError]:
        """Type check a complete program."""
        self.errors = []
        self.warnings = []

        env = TypeEnvironment()

        # Check constants
        for const in program.constants:
            value_type = self.check_expression(const.value, env)
            env.bind(const.name, const.type or value_type)

        # Check Hamiltonians
        for ham in program.hamiltonians:
            self.check_hamiltonian(ham, env)

        return self.errors


def typecheck(program: Program) -> Tuple[List[TypeError], List[str]]:
    """
    Type check a PbitLang program.

    Args:
        program: The AST to type check

    Returns:
        Tuple of (errors, warnings)
    """
    checker = TypeChecker()
    errors = checker.check_program(program)
    return errors, checker.warnings
