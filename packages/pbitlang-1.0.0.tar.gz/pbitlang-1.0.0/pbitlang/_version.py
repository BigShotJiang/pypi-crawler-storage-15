"""PbitLang version information."""

__version__ = "1.0.0"
__version_info__ = (1, 0, 0)

# Language version (for compatibility checking)
LANGUAGE_VERSION = "1.0"
