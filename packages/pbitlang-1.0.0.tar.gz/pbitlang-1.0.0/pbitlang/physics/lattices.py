"""
Lattice Geometry Generation

Generates adjacency structures for common lattice types.
These are used during compilation to PHAL Hamiltonians.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Dict, Iterator, List, Set, Tuple


class BoundaryType(Enum):
    """Boundary condition type."""
    PERIODIC = auto()
    OPEN = auto()
    FIXED = auto()


@dataclass
class LatticeGeometry:
    """
    Represents a lattice geometry.

    Stores the site positions and neighbor relationships.
    """
    num_sites: int
    dimension: int
    neighbors: Dict[int, List[int]]  # site -> list of neighbor sites
    positions: Dict[int, Tuple[float, ...]] = field(default_factory=dict)
    coordination: int = 0  # Number of neighbors per site (regular lattices)

    def get_neighbors(self, site: int) -> List[int]:
        """Get neighbors of a site."""
        return self.neighbors.get(site, [])

    def neighbor_pairs(self) -> Iterator[Tuple[int, int]]:
        """Iterate over all neighbor pairs (i, j) with i < j."""
        seen = set()
        for i, neighs in self.neighbors.items():
            for j in neighs:
                pair = (min(i, j), max(i, j))
                if pair not in seen:
                    seen.add(pair)
                    yield pair

    def all_pairs(self) -> Iterator[Tuple[int, int]]:
        """Iterate over all pairs (i, j) with i < j."""
        for i in range(self.num_sites):
            for j in range(i + 1, self.num_sites):
                yield (i, j)

    def distance(self, i: int, j: int) -> float:
        """Euclidean distance between two sites."""
        if i not in self.positions or j not in self.positions:
            return 0.0
        pos_i = self.positions[i]
        pos_j = self.positions[j]
        return math.sqrt(sum((a - b) ** 2 for a, b in zip(pos_i, pos_j)))

    def to_adjacency_matrix(self) -> List[List[int]]:
        """Convert to adjacency matrix."""
        adj = [[0] * self.num_sites for _ in range(self.num_sites)]
        for i, neighs in self.neighbors.items():
            for j in neighs:
                adj[i][j] = 1
        return adj

    def to_edge_list(self) -> List[Tuple[int, int]]:
        """Convert to edge list."""
        return list(self.neighbor_pairs())


def generate_chain(
    n: int,
    boundary: BoundaryType = BoundaryType.PERIODIC,
) -> LatticeGeometry:
    """
    Generate 1D chain lattice.

    Args:
        n: Number of sites
        boundary: Boundary condition

    Returns:
        LatticeGeometry with chain structure
    """
    neighbors = {}
    positions = {}

    for i in range(n):
        positions[i] = (float(i),)
        neighs = []

        # Left neighbor
        if i > 0:
            neighs.append(i - 1)
        elif boundary == BoundaryType.PERIODIC:
            neighs.append(n - 1)

        # Right neighbor
        if i < n - 1:
            neighs.append(i + 1)
        elif boundary == BoundaryType.PERIODIC:
            neighs.append(0)

        neighbors[i] = neighs

    return LatticeGeometry(
        num_sites=n,
        dimension=1,
        neighbors=neighbors,
        positions=positions,
        coordination=2,
    )


def generate_square(
    nx: int,
    ny: int,
    boundary: BoundaryType = BoundaryType.PERIODIC,
) -> LatticeGeometry:
    """
    Generate 2D square lattice.

    Sites are numbered row by row: site = x + y * nx

    Args:
        nx: Width
        ny: Height
        boundary: Boundary condition

    Returns:
        LatticeGeometry with square lattice structure
    """
    n = nx * ny
    neighbors = {}
    positions = {}

    def site_index(x: int, y: int) -> int:
        return x + y * nx

    for y in range(ny):
        for x in range(nx):
            i = site_index(x, y)
            positions[i] = (float(x), float(y))
            neighs = []

            # Left
            if x > 0:
                neighs.append(site_index(x - 1, y))
            elif boundary == BoundaryType.PERIODIC:
                neighs.append(site_index(nx - 1, y))

            # Right
            if x < nx - 1:
                neighs.append(site_index(x + 1, y))
            elif boundary == BoundaryType.PERIODIC:
                neighs.append(site_index(0, y))

            # Down
            if y > 0:
                neighs.append(site_index(x, y - 1))
            elif boundary == BoundaryType.PERIODIC:
                neighs.append(site_index(x, ny - 1))

            # Up
            if y < ny - 1:
                neighs.append(site_index(x, y + 1))
            elif boundary == BoundaryType.PERIODIC:
                neighs.append(site_index(x, 0))

            neighbors[i] = neighs

    return LatticeGeometry(
        num_sites=n,
        dimension=2,
        neighbors=neighbors,
        positions=positions,
        coordination=4,
    )


def generate_triangular(
    n: int,
    boundary: BoundaryType = BoundaryType.PERIODIC,
) -> LatticeGeometry:
    """
    Generate 2D triangular lattice.

    Each site has 6 neighbors. Uses a skewed coordinate system.

    Args:
        n: Size (n x n sites)
        boundary: Boundary condition

    Returns:
        LatticeGeometry with triangular lattice structure
    """
    num_sites = n * n
    neighbors = {}
    positions = {}

    def site_index(x: int, y: int) -> int:
        return x + y * n

    # Basis vectors for triangular lattice
    a1 = (1.0, 0.0)
    a2 = (0.5, math.sqrt(3) / 2)

    for y in range(n):
        for x in range(n):
            i = site_index(x, y)
            # Position in real space
            px = x * a1[0] + y * a2[0]
            py = x * a1[1] + y * a2[1]
            positions[i] = (px, py)

            neighs = []

            # 6 neighbors in triangular lattice
            neighbor_offsets = [
                (1, 0), (-1, 0),   # along a1
                (0, 1), (0, -1),   # along a2
                (1, -1), (-1, 1),  # along a1-a2
            ]

            for dx, dy in neighbor_offsets:
                nx_coord = x + dx
                ny_coord = y + dy

                if boundary == BoundaryType.PERIODIC:
                    nx_coord = nx_coord % n
                    ny_coord = ny_coord % n
                    neighs.append(site_index(nx_coord, ny_coord))
                elif 0 <= nx_coord < n and 0 <= ny_coord < n:
                    neighs.append(site_index(nx_coord, ny_coord))

            neighbors[i] = neighs

    return LatticeGeometry(
        num_sites=num_sites,
        dimension=2,
        neighbors=neighbors,
        positions=positions,
        coordination=6,
    )


def generate_honeycomb(
    n: int,
    boundary: BoundaryType = BoundaryType.PERIODIC,
) -> LatticeGeometry:
    """
    Generate 2D honeycomb (graphene) lattice.

    Each site has 3 neighbors. Uses a 2-site unit cell.

    Args:
        n: Size (n x n unit cells, so 2*n*n sites)
        boundary: Boundary condition

    Returns:
        LatticeGeometry with honeycomb structure
    """
    num_sites = 2 * n * n
    neighbors = {}
    positions = {}

    def site_index(x: int, y: int, sublattice: int) -> int:
        return 2 * (x + y * n) + sublattice

    # Honeycomb lattice vectors
    a1 = (1.5, math.sqrt(3) / 2)
    a2 = (1.5, -math.sqrt(3) / 2)

    for y in range(n):
        for x in range(n):
            # A sublattice (sublattice 0)
            i_a = site_index(x, y, 0)
            px_a = x * a1[0] + y * a2[0]
            py_a = x * a1[1] + y * a2[1]
            positions[i_a] = (px_a, py_a)

            # B sublattice (sublattice 1)
            i_b = site_index(x, y, 1)
            px_b = px_a + 1.0
            py_b = py_a
            positions[i_b] = (px_b, py_b)

            # Neighbors of A site: 3 B neighbors
            neighs_a = []
            # Same unit cell B
            neighs_a.append(i_b)
            # B in (-1, 0) cell
            if boundary == BoundaryType.PERIODIC or x > 0:
                nx = (x - 1) % n if boundary == BoundaryType.PERIODIC else x - 1
                if nx >= 0:
                    neighs_a.append(site_index(nx, y, 1))
            # B in (0, -1) cell
            if boundary == BoundaryType.PERIODIC or y > 0:
                ny = (y - 1) % n if boundary == BoundaryType.PERIODIC else y - 1
                if ny >= 0:
                    neighs_a.append(site_index(x, ny, 1))

            neighbors[i_a] = neighs_a

            # Neighbors of B site: 3 A neighbors
            neighs_b = []
            # Same unit cell A
            neighs_b.append(i_a)
            # A in (+1, 0) cell
            if boundary == BoundaryType.PERIODIC or x < n - 1:
                nx = (x + 1) % n if boundary == BoundaryType.PERIODIC else x + 1
                if nx < n:
                    neighs_b.append(site_index(nx, y, 0))
            # A in (0, +1) cell
            if boundary == BoundaryType.PERIODIC or y < n - 1:
                ny = (y + 1) % n if boundary == BoundaryType.PERIODIC else y + 1
                if ny < n:
                    neighs_b.append(site_index(x, ny, 0))

            neighbors[i_b] = neighs_b

    return LatticeGeometry(
        num_sites=num_sites,
        dimension=2,
        neighbors=neighbors,
        positions=positions,
        coordination=3,
    )


def generate_kagome(
    n: int,
    boundary: BoundaryType = BoundaryType.PERIODIC,
) -> LatticeGeometry:
    """
    Generate 2D Kagome lattice.

    Corner-sharing triangles. Each site has 4 neighbors.
    Uses a 3-site unit cell.

    Args:
        n: Size (n x n unit cells, so 3*n*n sites)
        boundary: Boundary condition

    Returns:
        LatticeGeometry with Kagome structure
    """
    num_sites = 3 * n * n
    neighbors = {}
    positions = {}

    def site_index(x: int, y: int, sublattice: int) -> int:
        return 3 * (x + y * n) + sublattice

    # Unit cell has 3 sites forming a triangle
    for y in range(n):
        for x in range(n):
            # Site positions within unit cell
            base_x = 2.0 * x + y
            base_y = math.sqrt(3) * y

            # Sublattice 0
            i0 = site_index(x, y, 0)
            positions[i0] = (base_x, base_y)

            # Sublattice 1
            i1 = site_index(x, y, 1)
            positions[i1] = (base_x + 1.0, base_y)

            # Sublattice 2
            i2 = site_index(x, y, 2)
            positions[i2] = (base_x + 0.5, base_y + math.sqrt(3) / 2)

            # Each Kagome site has 4 neighbors
            # This is simplified - full implementation would be more complex
            neighbors[i0] = [i1, i2]
            neighbors[i1] = [i0, i2]
            neighbors[i2] = [i0, i1]

            # Add inter-cell neighbors
            if boundary == BoundaryType.PERIODIC or x > 0:
                nx = (x - 1) % n if boundary == BoundaryType.PERIODIC else x - 1
                if nx >= 0:
                    neighbors[i0].append(site_index(nx, y, 1))

            if boundary == BoundaryType.PERIODIC or y > 0:
                ny = (y - 1) % n if boundary == BoundaryType.PERIODIC else y - 1
                if ny >= 0:
                    neighbors[i0].append(site_index(x, ny, 2))

    return LatticeGeometry(
        num_sites=num_sites,
        dimension=2,
        neighbors=neighbors,
        positions=positions,
        coordination=4,
    )


def generate_cubic(
    nx: int,
    ny: int,
    nz: int,
    boundary: BoundaryType = BoundaryType.PERIODIC,
) -> LatticeGeometry:
    """
    Generate 3D simple cubic lattice.

    Each site has 6 neighbors.

    Args:
        nx, ny, nz: Dimensions
        boundary: Boundary condition

    Returns:
        LatticeGeometry with cubic structure
    """
    n = nx * ny * nz
    neighbors = {}
    positions = {}

    def site_index(x: int, y: int, z: int) -> int:
        return x + y * nx + z * nx * ny

    for z in range(nz):
        for y in range(ny):
            for x in range(nx):
                i = site_index(x, y, z)
                positions[i] = (float(x), float(y), float(z))
                neighs = []

                # 6 neighbors
                neighbor_offsets = [
                    (1, 0, 0), (-1, 0, 0),
                    (0, 1, 0), (0, -1, 0),
                    (0, 0, 1), (0, 0, -1),
                ]

                for dx, dy, dz in neighbor_offsets:
                    nx_c = x + dx
                    ny_c = y + dy
                    nz_c = z + dz

                    if boundary == BoundaryType.PERIODIC:
                        nx_c = nx_c % nx
                        ny_c = ny_c % ny
                        nz_c = nz_c % nz
                        neighs.append(site_index(nx_c, ny_c, nz_c))
                    elif (0 <= nx_c < nx and 0 <= ny_c < ny and 0 <= nz_c < nz):
                        neighs.append(site_index(nx_c, ny_c, nz_c))

                neighbors[i] = neighs

    return LatticeGeometry(
        num_sites=n,
        dimension=3,
        neighbors=neighbors,
        positions=positions,
        coordination=6,
    )


def generate_complete(n: int) -> LatticeGeometry:
    """
    Generate complete graph (all-to-all connectivity).

    Args:
        n: Number of sites

    Returns:
        LatticeGeometry where every site connects to every other
    """
    neighbors = {}
    positions = {}

    # Arrange in a circle for visualization
    for i in range(n):
        angle = 2 * math.pi * i / n
        positions[i] = (math.cos(angle), math.sin(angle))
        neighbors[i] = [j for j in range(n) if j != i]

    return LatticeGeometry(
        num_sites=n,
        dimension=2,
        neighbors=neighbors,
        positions=positions,
        coordination=n - 1,
    )


def generate_bipartite(n_a: int, n_b: int) -> LatticeGeometry:
    """
    Generate bipartite graph (for RBM-like structures).

    All A sites connect to all B sites, no A-A or B-B connections.

    Args:
        n_a: Number of sites in partition A
        n_b: Number of sites in partition B

    Returns:
        LatticeGeometry with bipartite structure
    """
    n = n_a + n_b
    neighbors = {}
    positions = {}

    # Position A sites on left, B sites on right
    for i in range(n_a):
        positions[i] = (-1.0, float(i) / max(1, n_a - 1) * 2 - 1)
        neighbors[i] = list(range(n_a, n_a + n_b))  # Connect to all B sites

    for j in range(n_b):
        positions[n_a + j] = (1.0, float(j) / max(1, n_b - 1) * 2 - 1)
        neighbors[n_a + j] = list(range(n_a))  # Connect to all A sites

    return LatticeGeometry(
        num_sites=n,
        dimension=2,
        neighbors=neighbors,
        positions=positions,
        coordination=max(n_a, n_b),
    )


# =============================================================================
# Convenience functions that return neighbor lists directly
# =============================================================================

def generate_chain_neighbors(n: int, periodic: bool = True) -> List[Tuple[int, int]]:
    """Return neighbor pairs for 1D chain."""
    boundary = BoundaryType.PERIODIC if periodic else BoundaryType.OPEN
    lattice = generate_chain(n, boundary)
    return lattice.to_edge_list()


def generate_square_neighbors(nx: int, ny: int, periodic: bool = True) -> List[Tuple[int, int]]:
    """Return neighbor pairs for 2D square lattice."""
    boundary = BoundaryType.PERIODIC if periodic else BoundaryType.OPEN
    lattice = generate_square(nx, ny, boundary)
    return lattice.to_edge_list()


def generate_triangular_neighbors(n: int, periodic: bool = True) -> List[Tuple[int, int]]:
    """Return neighbor pairs for 2D triangular lattice."""
    boundary = BoundaryType.PERIODIC if periodic else BoundaryType.OPEN
    lattice = generate_triangular(n, boundary)
    return lattice.to_edge_list()
