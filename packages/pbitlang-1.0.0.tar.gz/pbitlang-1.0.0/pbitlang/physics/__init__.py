"""
PbitLang Physics Validation

Validates physical correctness of Hamiltonians.
"""

from pbitlang.physics.validator import (
    PhysicsValidator,
    PhysicsError,
    PhysicsWarning,
    validate,
)
from pbitlang.physics.lattices import (
    LatticeGeometry,
    generate_chain,
    generate_square,
    generate_triangular,
    generate_honeycomb,
    generate_kagome,
    generate_cubic,
)
from pbitlang.physics.critical import (
    ising_critical_temperature_1d,
    ising_critical_temperature_2d,
    potts_critical_temperature,
)

__all__ = [
    "PhysicsValidator",
    "PhysicsError",
    "PhysicsWarning",
    "validate",
    "LatticeGeometry",
    "generate_chain",
    "generate_square",
    "generate_triangular",
    "generate_honeycomb",
    "generate_kagome",
    "generate_cubic",
    "ising_critical_temperature_1d",
    "ising_critical_temperature_2d",
    "potts_critical_temperature",
]
