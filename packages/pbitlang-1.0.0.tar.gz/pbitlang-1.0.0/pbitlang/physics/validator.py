"""
PbitLang Physics Validator

Validates physical correctness of Hamiltonians and coupling matrices.
Ensures:
  - Coupling matrices are symmetric (for undirected models)
  - Temperature parameters are physically valid
  - Detects frustrated systems
  - Warns about critical points
  - Validates spin-lattice compatibility
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from enum import Enum, auto
from typing import Any, Dict, List, Optional, Tuple

from pbitlang.ast.nodes import (
    SourceLocation,
    HamiltonianDef,
    Program,
    SpinType,
    SpinKind,
    ChainLattice,
    SquareLattice,
    TriangularLattice,
    HoneycombLattice,
    KagomeLattice,
    CubicLattice,
    LatticeExpr,
    BoundaryCondition,
    SumExpr,
    TuplePattern,
    BinaryOp,
    BinaryOperator,
    UnaryOp,
    UnaryOperator,
    Identifier,
    Subscript,
    RealLiteral,
    IntLiteral,
)


class Severity(Enum):
    """Severity level for physics issues."""
    ERROR = auto()    # Must be fixed
    WARNING = auto()  # Should be reviewed
    INFO = auto()     # Informational


@dataclass
class PhysicsIssue:
    """A physics validation issue."""
    severity: Severity
    message: str
    location: SourceLocation
    code: str  # Error/warning code
    notes: List[str]
    help_text: Optional[str] = None


class PhysicsError(Exception):
    """Physics validation error."""

    def __init__(self, message: str, location: SourceLocation, code: str = "E0000"):
        self.message = message
        self.location = location
        self.code = code
        super().__init__(f"[{code}] {location}: {message}")


class PhysicsWarning:
    """Physics validation warning."""

    def __init__(self, message: str, location: SourceLocation, code: str = "W0000"):
        self.message = message
        self.location = location
        self.code = code

    def __str__(self):
        return f"[{self.code}] {self.location}: {self.message}"


# Physical constants
K_B = 1.380649e-23  # Boltzmann constant (J/K)
K_B_EV = 8.617333262e-5  # Boltzmann constant (eV/K)


class PhysicsValidator:
    """
    Validates physical correctness of PbitLang Hamiltonians.

    Checks:
    1. Matrix symmetry (coupling matrices must be symmetric)
    2. Diagonal elements (typically should be zero for Ising)
    3. Frustration detection (antiferro on triangular = frustrated)
    4. Critical temperature warnings
    5. Numerical stability (condition number)
    6. Spin-interaction compatibility
    """

    def __init__(self, strict: bool = False):
        """
        Initialize validator.

        Args:
            strict: If True, treat warnings as errors
        """
        self.strict = strict
        self.issues: List[PhysicsIssue] = []

    def error(
        self,
        code: str,
        message: str,
        location: SourceLocation,
        notes: List[str] = None,
        help_text: str = None,
    ) -> None:
        """Record an error."""
        self.issues.append(PhysicsIssue(
            Severity.ERROR, message, location, code, notes or [], help_text
        ))

    def warning(
        self,
        code: str,
        message: str,
        location: SourceLocation,
        notes: List[str] = None,
        help_text: str = None,
    ) -> None:
        """Record a warning."""
        severity = Severity.ERROR if self.strict else Severity.WARNING
        self.issues.append(PhysicsIssue(
            severity, message, location, code, notes or [], help_text
        ))

    def info(
        self,
        code: str,
        message: str,
        location: SourceLocation,
        notes: List[str] = None,
    ) -> None:
        """Record informational message."""
        self.issues.append(PhysicsIssue(
            Severity.INFO, message, location, code, notes or []
        ))

    # =========================================================================
    # Matrix Validation
    # =========================================================================

    def validate_coupling_matrix(
        self,
        matrix: List[List[float]],
        location: SourceLocation,
        is_directed: bool = False,
    ) -> None:
        """
        Validate a coupling matrix.

        Args:
            matrix: The coupling matrix J
            location: Source location for errors
            is_directed: If True, skip symmetry check
        """
        n = len(matrix)
        if n == 0:
            self.error("E0010", "Empty coupling matrix", location)
            return

        # Check square
        for i, row in enumerate(matrix):
            if len(row) != n:
                self.error(
                    "E0011",
                    f"Coupling matrix is not square: row {i} has {len(row)} elements, "
                    f"expected {n}",
                    location
                )
                return

        # Check symmetry
        if not is_directed:
            asymmetric_pairs = []
            for i in range(n):
                for j in range(i + 1, n):
                    if abs(matrix[i][j] - matrix[j][i]) > 1e-10:
                        asymmetric_pairs.append((i, j, matrix[i][j], matrix[j][i]))

            if asymmetric_pairs:
                examples = asymmetric_pairs[:3]
                example_strs = [
                    f"J[{i},{j}]={v1} ≠ J[{j},{i}]={v2}"
                    for i, j, v1, v2 in examples
                ]
                self.error(
                    "E0042",
                    "Asymmetric coupling matrix",
                    location,
                    notes=[
                        "Ising coupling matrices must be symmetric: J[i,j] = J[j,i]",
                        *example_strs,
                    ],
                    help_text="For directed interactions, use @directed annotation"
                )

        # Check diagonal
        nonzero_diagonal = []
        for i in range(n):
            if abs(matrix[i][i]) > 1e-10:
                nonzero_diagonal.append((i, matrix[i][i]))

        if nonzero_diagonal:
            examples = nonzero_diagonal[:3]
            self.warning(
                "W0012",
                "Non-zero diagonal elements in coupling matrix",
                location,
                notes=[
                    "Self-coupling J[i,i] is typically zero for Ising models",
                    "Non-zero diagonal shifts the energy but doesn't affect physics",
                    *[f"J[{i},{i}] = {v}" for i, v in examples],
                ]
            )

        # Check for NaN/Inf
        for i in range(n):
            for j in range(n):
                if math.isnan(matrix[i][j]):
                    self.error(
                        "E0013",
                        f"NaN in coupling matrix at [{i},{j}]",
                        location
                    )
                elif math.isinf(matrix[i][j]):
                    self.error(
                        "E0014",
                        f"Infinity in coupling matrix at [{i},{j}]",
                        location
                    )

        # Check condition number (numerical stability)
        self._check_condition_number(matrix, location)

    def _check_condition_number(
        self,
        matrix: List[List[float]],
        location: SourceLocation,
    ) -> None:
        """Check matrix condition number for numerical stability."""
        # Simplified: estimate using ratio of max to min absolute values
        max_val = 0.0
        min_val = float('inf')

        for row in matrix:
            for val in row:
                abs_val = abs(val)
                if abs_val > 0:
                    max_val = max(max_val, abs_val)
                    min_val = min(min_val, abs_val)

        if min_val > 0 and max_val / min_val > 1e8:
            self.warning(
                "W0015",
                "Large dynamic range in coupling matrix may cause numerical issues",
                location,
                notes=[
                    f"Max |J| = {max_val:.2e}, Min |J| = {min_val:.2e}",
                    f"Ratio = {max_val/min_val:.2e}",
                    "Consider rescaling the problem"
                ]
            )

    # =========================================================================
    # Frustration Detection
    # =========================================================================

    def detect_frustration(
        self,
        spin_type: SpinType,
        lattice: LatticeExpr,
        coupling_sign: float,
        location: SourceLocation,
    ) -> None:
        """
        Detect geometric frustration.

        Frustration occurs when:
        - Antiferromagnetic (J < 0) coupling on triangular-like lattices
        - Certain disorder configurations
        """
        is_antiferro = coupling_sign < 0

        # Triangular lattices with antiferro coupling are frustrated
        frustrated_lattices = (TriangularLattice, KagomeLattice)

        if is_antiferro and isinstance(lattice, frustrated_lattices):
            lattice_name = type(lattice).__name__.replace("Lattice", "").lower()
            self.warning(
                "W0017",
                f"Frustrated system detected: antiferromagnetic coupling on {lattice_name} lattice",
                location,
                notes=[
                    f"Antiferromagnetic coupling on {lattice_name} lattice is geometrically frustrated",
                    "Ground state is highly degenerate",
                    "This may cause slow thermalization"
                ],
                help_text="Consider using parallel tempering for sampling"
            )

        # Honeycomb is bipartite, so antiferro is NOT frustrated
        # (can alternate perfectly)

    # =========================================================================
    # Critical Temperature Analysis
    # =========================================================================

    def analyze_critical_temperature(
        self,
        spin_type: SpinType,
        lattice: LatticeExpr,
        coupling_magnitude: float,
        location: SourceLocation,
    ) -> None:
        """
        Analyze critical temperature and warn if near phase transition.

        Known exact results:
        - 1D Ising: Tc = 0 (no phase transition)
        - 2D square Ising: kT_c/J = 2/ln(1+√2) ≈ 2.269
        - 2D triangular Ising: kT_c/J = 4/ln(3) ≈ 3.641
        """
        if spin_type.kind not in (SpinKind.ISING, SpinKind.BINARY):
            return

        J = abs(coupling_magnitude)
        if J == 0:
            return

        if isinstance(lattice, ChainLattice):
            self.info(
                "I0020",
                "1D Ising chain has no phase transition (Tc = 0)",
                location,
                notes=[
                    "The 1D Ising model is exactly solvable",
                    "It has no spontaneous magnetization at any T > 0",
                    "Correlation length diverges only as T → 0"
                ]
            )

        elif isinstance(lattice, SquareLattice):
            # Onsager's exact result
            Tc_over_J = 2.0 / math.log(1 + math.sqrt(2))
            Tc = Tc_over_J * J

            self.info(
                "I0021",
                f"2D square Ising critical temperature: kT_c = {Tc:.4f} (β_c = {1/Tc:.4f})",
                location,
                notes=[
                    "Onsager's exact result: kT_c/J = 2/ln(1+√2) ≈ 2.269",
                    "Critical slowing down occurs near T_c",
                    "Sampling efficiency drops dramatically at the critical point"
                ]
            )

        elif isinstance(lattice, TriangularLattice):
            # Exact result for triangular
            Tc_over_J = 4.0 / math.log(3)
            Tc = Tc_over_J * J

            self.info(
                "I0022",
                f"2D triangular Ising critical temperature: kT_c = {Tc:.4f}",
                location,
                notes=[
                    "Exact result: kT_c/J = 4/ln(3) ≈ 3.641",
                ]
            )

        elif isinstance(lattice, HoneycombLattice):
            # Exact result for honeycomb
            Tc_over_J = 2.0 / math.log(2 + math.sqrt(3))
            Tc = Tc_over_J * J

            self.info(
                "I0023",
                f"2D honeycomb Ising critical temperature: kT_c = {Tc:.4f}",
                location,
                notes=[
                    "Exact result: kT_c/J = 2/ln(2+√3) ≈ 1.519",
                ]
            )

        elif isinstance(lattice, CubicLattice):
            # 3D cubic: numerical result
            Tc_over_J = 4.5115  # High-precision Monte Carlo result

            self.info(
                "I0024",
                f"3D cubic Ising critical temperature: kT_c/J ≈ {Tc_over_J:.4f}",
                location,
                notes=[
                    "Numerical result from Monte Carlo simulations",
                    "3D Ising has continuous phase transition"
                ]
            )

    # =========================================================================
    # Spin-Interaction Compatibility
    # =========================================================================

    def validate_spin_interaction(
        self,
        spin_type: SpinType,
        interaction_type: str,
        location: SourceLocation,
    ) -> None:
        """
        Validate that interaction is appropriate for spin type.

        Rules:
        - Ising/Binary: s_i * s_j or x_i * x_j products
        - Potts: delta(σ_i, σ_j) Kronecker delta
        - Clock/XY: cos(θ_i - θ_j) coupling
        """
        valid_interactions = {
            SpinKind.ISING: {"multiply", "product"},
            SpinKind.BINARY: {"multiply", "product"},
            SpinKind.POTTS: {"delta", "kronecker"},
            SpinKind.CLOCK: {"cos", "cosine"},
            SpinKind.CONTINUOUS: {"cos", "sin", "dot"},
        }

        allowed = valid_interactions.get(spin_type.kind, set())

        if interaction_type.lower() not in allowed:
            self.warning(
                "W0030",
                f"Unusual interaction '{interaction_type}' for {spin_type} spins",
                location,
                notes=[
                    f"Standard interactions for {spin_type.kind.name}: {', '.join(allowed)}",
                    "This may be intentional for non-standard models"
                ]
            )

    # =========================================================================
    # Hamiltonian Validation
    # =========================================================================

    def validate_hamiltonian(self, ham: HamiltonianDef) -> None:
        """Validate a complete Hamiltonian definition."""

        # Check spin type validity
        if ham.spin_type.kind == SpinKind.POTTS:
            if ham.spin_type.q is None:
                self.error(
                    "E0040",
                    "Potts spin type requires number of states q",
                    ham.location
                )
            elif ham.spin_type.q < 2:
                self.error(
                    "E0041",
                    f"Potts states q must be >= 2, got {ham.spin_type.q}",
                    ham.location
                )

        if ham.spin_type.kind == SpinKind.CLOCK:
            if ham.spin_type.q is None:
                self.error(
                    "E0042",
                    "Clock spin type requires number of states q",
                    ham.location
                )
            elif ham.spin_type.q < 2:
                self.error(
                    "E0043",
                    f"Clock states q must be >= 2, got {ham.spin_type.q}",
                    ham.location
                )

        # Analyze energy terms
        coupling_sign = self._detect_coupling_sign(ham)
        if coupling_sign is not None:
            self.detect_frustration(
                ham.spin_type,
                ham.lattice,
                coupling_sign,
                ham.location
            )

        coupling_magnitude = abs(coupling_sign) if coupling_sign else 1.0
        self.analyze_critical_temperature(
            ham.spin_type,
            ham.lattice,
            coupling_magnitude,
            ham.location
        )

    def _detect_coupling_sign(self, ham: HamiltonianDef) -> Optional[float]:
        """
        Try to detect the sign of the coupling constant.

        Returns:
            Positive for ferromagnetic, negative for antiferromagnetic,
            None if cannot determine.
        """
        for term in ham.terms:
            if hasattr(term, 'expression') and isinstance(term.expression, SumExpr):
                expr = term.expression
                # Try to find coefficient
                body = expr.body

                if isinstance(body, BinaryOp):
                    if body.operator == BinaryOperator.MUL:
                        # Check for -J * ... pattern
                        left = body.left
                        if isinstance(left, UnaryOp) and left.operator == UnaryOperator.NEG:
                            # Negative coefficient means ferromagnetic convention
                            return 1.0  # Ferromagnetic
                        elif isinstance(left, Identifier) or isinstance(left, RealLiteral):
                            # Positive coefficient
                            if isinstance(left, RealLiteral):
                                if left.value < 0:
                                    return 1.0  # Ferromagnetic
                                else:
                                    return -1.0  # Antiferromagnetic

        return None

    # =========================================================================
    # Program Validation
    # =========================================================================

    def validate_program(self, program: Program) -> List[PhysicsIssue]:
        """Validate all Hamiltonians in a program."""
        self.issues = []

        for ham in program.hamiltonians:
            self.validate_hamiltonian(ham)

        return self.issues


def validate(
    program: Program,
    strict: bool = False,
) -> Tuple[List[PhysicsIssue], bool]:
    """
    Validate physical correctness of a PbitLang program.

    Args:
        program: The AST to validate
        strict: Treat warnings as errors

    Returns:
        Tuple of (issues, has_errors)
    """
    validator = PhysicsValidator(strict=strict)
    issues = validator.validate_program(program)

    has_errors = any(issue.severity == Severity.ERROR for issue in issues)

    return issues, has_errors
