"""
Critical Temperature Calculations

Exact and numerical results for phase transitions in spin systems.

This module provides scientifically accurate critical temperature values
based on:
- Exact analytical solutions (where available)
- High-precision Monte Carlo results
- Series expansions

References:
    [1] L. Onsager, Phys. Rev. 65, 117 (1944) - 2D Ising exact solution
    [2] R. J. Baxter, "Exactly Solved Models in Statistical Mechanics" (1982)
    [3] F. Y. Wu, Rev. Mod. Phys. 54, 235 (1982) - Potts model review
"""

from __future__ import annotations

import math
from enum import Enum
from typing import Optional, Tuple


class LatticeType(Enum):
    """Lattice types with known critical temperatures."""
    CHAIN = "chain"
    SQUARE = "square"
    TRIANGULAR = "triangular"
    HONEYCOMB = "honeycomb"
    KAGOME = "kagome"
    CUBIC = "cubic"
    BCC = "bcc"  # Body-centered cubic
    FCC = "fcc"  # Face-centered cubic


# =============================================================================
# Exact Results for 2D Ising Model
# =============================================================================

def ising_critical_temperature_1d(J: float = 1.0) -> Tuple[float, str]:
    """
    Critical temperature for 1D Ising model.

    The 1D Ising model has NO phase transition at finite temperature.
    T_c = 0 (only at absolute zero).

    Args:
        J: Coupling constant (positive = ferromagnetic)

    Returns:
        Tuple of (T_c, explanation)

    Scientific basis:
        The transfer matrix method shows the partition function is analytic
        for all T > 0. Spontaneous magnetization is zero for all T > 0.
    """
    return (
        0.0,
        "1D Ising model: No phase transition at T > 0 (Tc = 0). "
        "This is an exact result from the transfer matrix solution."
    )


def ising_critical_temperature_2d(
    J: float = 1.0,
    lattice: LatticeType = LatticeType.SQUARE,
) -> Tuple[float, str]:
    """
    Critical temperature for 2D Ising model.

    Returns the exact critical temperature for various 2D lattices.

    Args:
        J: Coupling constant (positive = ferromagnetic)
        lattice: Lattice geometry

    Returns:
        Tuple of (kT_c/|J|, explanation)

    Scientific basis:
        Square lattice: Onsager's exact solution (1944)
            sinh(2J/kT_c) = 1
            => kT_c/J = 2/ln(1 + √2) ≈ 2.26918...

        Triangular lattice: Exact solution
            kT_c/J = 4/ln(3) ≈ 3.6409...

        Honeycomb lattice: Exact solution (star-triangle transformation)
            kT_c/J = 2/ln(2 + √3) ≈ 1.5186...

        These satisfy the duality relation for planar graphs.
    """
    abs_J = abs(J)

    if lattice == LatticeType.SQUARE:
        # Onsager's exact result
        # sinh(2β_c J) = 1 => β_c J = ln(1 + √2)/2
        # => kT_c/J = 2/ln(1 + √2)
        kTc_over_J = 2.0 / math.log(1 + math.sqrt(2))
        explanation = (
            "Onsager's exact solution (1944): "
            "sinh(2J/kT_c) = 1, giving kT_c/J = 2/ln(1+√2)"
        )

    elif lattice == LatticeType.TRIANGULAR:
        # Exact result for triangular lattice
        kTc_over_J = 4.0 / math.log(3)
        explanation = (
            "Exact solution for triangular Ising: "
            "kT_c/J = 4/ln(3) ≈ 3.641"
        )

    elif lattice == LatticeType.HONEYCOMB:
        # Exact result via star-triangle transformation
        kTc_over_J = 2.0 / math.log(2 + math.sqrt(3))
        explanation = (
            "Exact solution for honeycomb Ising "
            "(star-triangle transformation): "
            "kT_c/J = 2/ln(2+√3) ≈ 1.519"
        )

    elif lattice == LatticeType.KAGOME:
        # Kagome Ising: no finite T transition (frustrated)
        # For ferromagnetic: has a transition
        kTc_over_J = 2.143  # Numerical estimate for ferromagnetic
        explanation = (
            "Kagome lattice (ferromagnetic): "
            "kT_c/J ≈ 2.143 (numerical)"
        )

    else:
        raise ValueError(f"Unknown 2D lattice: {lattice}")

    return (kTc_over_J * abs_J, explanation)


def ising_critical_temperature_3d(
    J: float = 1.0,
    lattice: LatticeType = LatticeType.CUBIC,
) -> Tuple[float, str]:
    """
    Critical temperature for 3D Ising model.

    No exact solution exists. Values from high-precision Monte Carlo.

    Args:
        J: Coupling constant
        lattice: Lattice geometry

    Returns:
        Tuple of (kT_c/|J|, explanation)

    Scientific basis:
        Simple cubic: High-precision MC gives β_c J = 0.2216544(3)
            => kT_c/J ≈ 4.5115

        These are among the most precisely known values in statistical mechanics,
        obtained from finite-size scaling of Monte Carlo simulations.
    """
    abs_J = abs(J)

    if lattice == LatticeType.CUBIC:
        # High-precision Monte Carlo result
        # β_c J = 0.2216544(3) [Ferrenberg & Landau, PRB 44, 5081 (1991)]
        beta_c_J = 0.2216544
        kTc_over_J = 1.0 / beta_c_J
        explanation = (
            "3D cubic Ising (Monte Carlo): "
            f"β_c J = {beta_c_J:.7f}, "
            f"kT_c/J ≈ {kTc_over_J:.4f}"
        )

    elif lattice == LatticeType.BCC:
        # Body-centered cubic
        beta_c_J = 0.1573  # Approximate
        kTc_over_J = 1.0 / beta_c_J
        explanation = (
            "3D BCC Ising (Monte Carlo): "
            f"kT_c/J ≈ {kTc_over_J:.3f}"
        )

    elif lattice == LatticeType.FCC:
        # Face-centered cubic
        beta_c_J = 0.1023  # Approximate
        kTc_over_J = 1.0 / beta_c_J
        explanation = (
            "3D FCC Ising (Monte Carlo): "
            f"kT_c/J ≈ {kTc_over_J:.3f}"
        )

    else:
        raise ValueError(f"Unknown 3D lattice: {lattice}")

    return (kTc_over_J * abs_J, explanation)


# =============================================================================
# Potts Model Critical Temperatures
# =============================================================================

def potts_critical_temperature(
    q: int,
    J: float = 1.0,
    lattice: LatticeType = LatticeType.SQUARE,
) -> Tuple[float, Optional[str], str]:
    """
    Critical temperature for q-state Potts model.

    Args:
        q: Number of Potts states (q >= 2)
        J: Coupling constant
        lattice: Lattice geometry

    Returns:
        Tuple of (kT_c/|J|, transition_order, explanation)
        transition_order is "first" or "second" (or None if unknown)

    Scientific basis:
        For 2D square lattice, exact result:
            exp(J/kT_c) = 1 + √q
            => kT_c/J = 1/ln(1 + √q)

        Phase transition is:
            - Second order (continuous) for q ≤ 4
            - First order (discontinuous) for q > 4

        Reference: F. Y. Wu, Rev. Mod. Phys. 54, 235 (1982)
    """
    if q < 2:
        raise ValueError(f"Potts states q must be >= 2, got {q}")

    abs_J = abs(J)

    if lattice == LatticeType.SQUARE:
        # Exact result for 2D square Potts
        # exp(βJ) = 1 + √q  at criticality
        kTc_over_J = 1.0 / math.log(1 + math.sqrt(q))

        if q <= 4:
            transition_order = "second"
            order_note = "continuous (second-order) transition"
        else:
            transition_order = "first"
            order_note = "discontinuous (first-order) transition"

        explanation = (
            f"{q}-state Potts on square lattice: "
            f"exp(J/kT_c) = 1 + √{q}, "
            f"kT_c/J = 1/ln(1+√{q}) ≈ {kTc_over_J:.4f}. "
            f"This is a {order_note}."
        )

    elif lattice == LatticeType.TRIANGULAR:
        # Exact result for triangular Potts
        kTc_over_J = 1.0 / math.log(1 + math.sqrt(q))  # Similar form
        transition_order = "second" if q <= 4 else "first"
        explanation = (
            f"{q}-state Potts on triangular lattice"
        )

    else:
        # Numerical estimates for other lattices
        kTc_over_J = 1.0 / math.log(1 + math.sqrt(q))  # Approximate
        transition_order = None
        explanation = f"{q}-state Potts (numerical estimate)"

    return (kTc_over_J * abs_J, transition_order, explanation)


# =============================================================================
# XY Model Critical Temperatures
# =============================================================================

def xy_critical_temperature(
    J: float = 1.0,
    lattice: LatticeType = LatticeType.SQUARE,
) -> Tuple[float, str]:
    """
    Critical temperature for classical XY model.

    The 2D XY model has a Berezinskii-Kosterlitz-Thouless (BKT) transition,
    not a conventional order-disorder transition.

    Args:
        J: Coupling constant
        lattice: Lattice geometry

    Returns:
        Tuple of (kT_BKT/|J|, explanation)

    Scientific basis:
        The BKT transition is topological, driven by vortex unbinding.
        Below T_BKT: quasi-long-range order, power-law correlations
        Above T_BKT: exponentially decaying correlations

        For square lattice: kT_BKT/J ≈ 0.893 (Monte Carlo)

        Reference: Berezinskii (1971), Kosterlitz & Thouless (1973)
    """
    abs_J = abs(J)

    if lattice == LatticeType.SQUARE:
        # Monte Carlo result for BKT transition
        kT_BKT_over_J = 0.893
        explanation = (
            "2D XY model on square lattice: "
            "Berezinskii-Kosterlitz-Thouless transition at "
            f"kT_BKT/J ≈ {kT_BKT_over_J:.3f}. "
            "This is a topological transition (vortex unbinding), "
            "not a conventional order-disorder transition."
        )

    elif lattice == LatticeType.TRIANGULAR:
        kT_BKT_over_J = 1.45  # Approximate
        explanation = (
            "2D XY model on triangular lattice: "
            f"kT_BKT/J ≈ {kT_BKT_over_J:.2f}"
        )

    else:
        kT_BKT_over_J = 0.9  # Rough estimate
        explanation = "2D XY model (estimate)"

    return (kT_BKT_over_J * abs_J, explanation)


# =============================================================================
# Heisenberg Model Critical Temperatures
# =============================================================================

def heisenberg_critical_temperature_3d(
    J: float = 1.0,
    lattice: LatticeType = LatticeType.CUBIC,
) -> Tuple[float, str]:
    """
    Critical temperature for 3D classical Heisenberg model.

    No exact solution exists. 2D Heisenberg has no finite-T transition
    (Mermin-Wagner theorem).

    Args:
        J: Coupling constant
        lattice: Lattice geometry

    Returns:
        Tuple of (kT_c/|J|, explanation)

    Scientific basis:
        3D cubic Heisenberg: kT_c/J ≈ 1.443 (Monte Carlo)

        The Mermin-Wagner theorem proves that 2D Heisenberg and XY models
        cannot have spontaneous magnetization at T > 0.
    """
    abs_J = abs(J)

    if lattice == LatticeType.CUBIC:
        kTc_over_J = 1.443  # Monte Carlo result
        explanation = (
            "3D Heisenberg on cubic lattice: "
            f"kT_c/J ≈ {kTc_over_J:.3f} (Monte Carlo). "
            "Unlike 2D, 3D Heisenberg has true long-range order below T_c."
        )

    else:
        kTc_over_J = 1.4  # Rough estimate
        explanation = "3D Heisenberg (estimate)"

    return (kTc_over_J * abs_J, explanation)


# =============================================================================
# Utility Functions
# =============================================================================

def mixing_time_estimate(
    T: float,
    T_c: float,
    system_size: int,
    dimension: int,
) -> float:
    """
    Estimate mixing time for MCMC near critical point.

    Near T_c, critical slowing down causes mixing time to diverge as:
        τ ~ L^z * |T - T_c|^(-z*ν)

    where z is the dynamic critical exponent and ν is the correlation
    length exponent.

    Args:
        T: Temperature
        T_c: Critical temperature
        system_size: Linear system size L
        dimension: Spatial dimension

    Returns:
        Estimated mixing time (in units of MC sweeps)

    Scientific basis:
        For Ising model:
            - 2D: z ≈ 2.17 (local updates), z ≈ 0.25 (cluster updates)
            - 3D: z ≈ 2.02 (local)
    """
    L = system_size

    # Dynamic exponent (approximate, for local updates)
    z = 2.0  # Typical for local Metropolis/Gibbs

    # Correlation length exponent
    nu = {
        1: float('inf'),  # No transition in 1D
        2: 1.0,           # 2D Ising: ν = 1 exactly
        3: 0.63,          # 3D Ising: ν ≈ 0.63
    }.get(dimension, 1.0)

    # Base mixing time scales as L^z
    tau_base = L ** z

    # Near critical point, additional factor
    if T_c > 0:
        epsilon = abs(T - T_c) / T_c
        if epsilon < 0.01:
            # Very close to T_c: severe slowing down
            tau_factor = (0.01 / max(epsilon, 1e-6)) ** (z * nu)
        elif epsilon < 0.1:
            # Moderately close
            tau_factor = (0.1 / epsilon) ** (z * nu / 2)
        else:
            # Far from T_c
            tau_factor = 1.0
    else:
        tau_factor = 1.0

    return tau_base * tau_factor


def correlation_length_estimate(
    T: float,
    T_c: float,
    dimension: int,
) -> float:
    """
    Estimate correlation length.

    Near T_c, correlation length diverges as:
        ξ ~ |T - T_c|^(-ν)

    Args:
        T: Temperature
        T_c: Critical temperature
        dimension: Spatial dimension

    Returns:
        Estimated correlation length in lattice units
    """
    if T_c <= 0:
        # No transition (1D)
        return 1.0 / max(T, 0.01)  # ξ ~ 1/T for 1D Ising

    nu = {
        2: 1.0,    # 2D Ising
        3: 0.63,   # 3D Ising
    }.get(dimension, 0.7)

    epsilon = abs(T - T_c) / T_c
    if epsilon < 1e-6:
        epsilon = 1e-6  # Prevent divergence

    xi = epsilon ** (-nu)
    return min(xi, 1000.0)  # Cap at 1000 lattice units


# =============================================================================
# Convenience Functions (Aliases for backward compatibility)
# =============================================================================

# Onsager's exact result for 2D square Ising
ONSAGER_EXACT = 2.0 / math.log(1 + math.sqrt(2))


def ising_chain_critical_temp(J: float = 1.0) -> float:
    """Critical temperature for 1D Ising chain (always 0)."""
    return 0.0


def ising_square_critical_temp(J: float = 1.0) -> float:
    """Critical temperature for 2D square Ising (Onsager)."""
    return (2.0 / math.log(1 + math.sqrt(2))) * abs(J)


def ising_triangular_critical_temp(J: float = 1.0) -> float:
    """Critical temperature for 2D triangular Ising."""
    return (4.0 / math.log(3)) * abs(J)


def ising_honeycomb_critical_temp(J: float = 1.0) -> float:
    """Critical temperature for 2D honeycomb Ising."""
    return (2.0 / math.log(2 + math.sqrt(3))) * abs(J)


def potts_square_critical_temp(q: int, J: float = 1.0) -> float:
    """Critical temperature for q-state Potts on square lattice."""
    return (1.0 / math.log(1 + math.sqrt(q))) * abs(J)
