"""
PbitLang Parser

Recursive descent parser for PbitLang source code.
Produces an AST from a token stream.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, List, Optional, Set, Tuple, Union

from pbitlang.ast.nodes import (
    # Base
    Node,
    SourceLocation,
    # Types
    Type,
    PrimitiveType,
    PrimitiveKind,
    SpinType,
    SpinKind,
    ArrayType,
    MatrixType,
    LatticeType,
    BoundaryCondition,
    # Expressions
    Expression,
    IntLiteral,
    RealLiteral,
    BoolLiteral,
    StringLiteral,
    Identifier,
    BinaryOp,
    BinaryOperator,
    UnaryOp,
    UnaryOperator,
    Subscript,
    FunctionCall,
    ArrayExpr,
    MatrixExpr,
    RangeExpr,
    ConditionalExpr,
    LetExpr,
    SumExpr,
    ProductExpr,
    TuplePattern,
    # Declarations
    Parameter,
    Constant,
    LetBinding,
    Import,
    # Constraints
    WhereClause,
    RequireClause,
    # Lattice
    LatticeExpr,
    ChainLattice,
    SquareLattice,
    TriangularLattice,
    HoneycombLattice,
    KagomeLattice,
    CubicLattice,
    CustomLattice,
    # Energy
    EnergyTerm,
    CouplingTerm,
    FieldTerm,
    CustomTerm,
    # Top-level
    HamiltonianDef,
    SystemDef,
    Program,
)
from pbitlang.parser.lexer import Token, TokenType, tokenize


class ParseError(Exception):
    """Error during parsing."""

    def __init__(self, message: str, location: SourceLocation, hint: str = None):
        self.message = message
        self.location = location
        self.hint = hint
        super().__init__(self.format_message())

    def format_message(self) -> str:
        msg = f"Parse error at {self.location}: {self.message}"
        if self.hint:
            msg += f"\n  hint: {self.hint}"
        return msg


class Parser:
    """
    Recursive descent parser for PbitLang.

    Parses a token stream into an AST.
    """

    def __init__(self, tokens: List[Token], source: str = ""):
        self.tokens = tokens
        self.source = source
        self.pos = 0
        self.decorators: List[str] = []
        self.doc_comment: Optional[str] = None

    # =========================================================================
    # Token management
    # =========================================================================

    def current(self) -> Token:
        """Get current token."""
        if self.pos < len(self.tokens):
            return self.tokens[self.pos]
        return self.tokens[-1]  # EOF

    def peek(self, offset: int = 0) -> Token:
        """Peek at token at offset from current position."""
        pos = self.pos + offset
        if pos < len(self.tokens):
            return self.tokens[pos]
        return self.tokens[-1]

    def check(self, *types: TokenType) -> bool:
        """Check if current token is one of the given types."""
        return self.current().type in types

    def match(self, *types: TokenType) -> Optional[Token]:
        """If current token matches, consume and return it."""
        if self.check(*types):
            return self.advance()
        return None

    def advance(self) -> Token:
        """Consume and return current token."""
        token = self.current()
        self.pos += 1
        return token

    def expect(self, token_type: TokenType, message: str = None) -> Token:
        """Expect a specific token type, raise error if not found."""
        if not self.check(token_type):
            msg = message or f"Expected {token_type.name}, got {self.current().type.name}"
            raise ParseError(msg, self.current().location)
        return self.advance()

    def skip_newlines(self) -> None:
        """Skip any newline tokens."""
        while self.check(TokenType.NEWLINE):
            self.advance()

    def at_end(self) -> bool:
        """Check if at end of tokens."""
        return self.check(TokenType.EOF)

    # =========================================================================
    # Type parsing
    # =========================================================================

    def parse_type(self) -> Type:
        """Parse a type annotation."""
        loc = self.current().location

        # Primitive types
        if self.match(TokenType.INT_TYPE):
            return PrimitiveType(PrimitiveKind.INT, location=loc)
        if self.match(TokenType.REAL_TYPE):
            return PrimitiveType(PrimitiveKind.REAL, location=loc)
        if self.match(TokenType.BOOL_TYPE):
            return PrimitiveType(PrimitiveKind.BOOL, location=loc)
        if self.match(TokenType.COMPLEX_TYPE):
            return PrimitiveType(PrimitiveKind.COMPLEX, location=loc)

        # Spin types
        if self.match(TokenType.ISING):
            return SpinType(SpinKind.ISING, location=loc)
        if self.match(TokenType.BINARY):
            return SpinType(SpinKind.BINARY, location=loc)
        if self.match(TokenType.CONTINUOUS):
            return SpinType(SpinKind.CONTINUOUS, location=loc)

        if self.match(TokenType.POTTS):
            self.expect(TokenType.LPAREN)
            q = self.parse_expression()
            self.expect(TokenType.RPAREN)
            # Evaluate q if it's a literal
            q_val = q.value if isinstance(q, IntLiteral) else None
            return SpinType(SpinKind.POTTS, q=q_val, location=loc)

        if self.match(TokenType.CLOCK):
            self.expect(TokenType.LPAREN)
            q = self.parse_expression()
            self.expect(TokenType.RPAREN)
            q_val = q.value if isinstance(q, IntLiteral) else None
            return SpinType(SpinKind.CLOCK, q=q_val, location=loc)

        # Array type
        if self.match(TokenType.ARRAY):
            self.expect(TokenType.LBRACKET)
            elem_type = self.parse_type()
            size = None
            if self.match(TokenType.COMMA):
                size = self.parse_expression()
            self.expect(TokenType.RBRACKET)
            return ArrayType(elem_type, size, location=loc)

        # Matrix type
        if self.match(TokenType.MATRIX):
            self.expect(TokenType.LBRACKET)
            elem_type = self.parse_type()
            rows = None
            cols = None
            if self.match(TokenType.COMMA):
                rows = self.parse_expression()
                if self.match(TokenType.COMMA):
                    cols = self.parse_expression()
            self.expect(TokenType.RBRACKET)
            return MatrixType(elem_type, rows, cols, location=loc)

        raise ParseError(f"Expected type, got {self.current().type.name}",
                        self.current().location)

    def parse_spin_type(self) -> SpinType:
        """Parse a spin type specifically."""
        loc = self.current().location

        if self.match(TokenType.ISING):
            return SpinType(SpinKind.ISING, location=loc)
        if self.match(TokenType.BINARY):
            return SpinType(SpinKind.BINARY, location=loc)
        if self.match(TokenType.CONTINUOUS):
            return SpinType(SpinKind.CONTINUOUS, location=loc)

        if self.match(TokenType.POTTS):
            self.expect(TokenType.LPAREN)
            q_expr = self.parse_expression()
            self.expect(TokenType.RPAREN)
            q_val = q_expr.value if isinstance(q_expr, IntLiteral) else None
            return SpinType(SpinKind.POTTS, q=q_val, location=loc)

        if self.match(TokenType.CLOCK):
            self.expect(TokenType.LPAREN)
            q_expr = self.parse_expression()
            self.expect(TokenType.RPAREN)
            q_val = q_expr.value if isinstance(q_expr, IntLiteral) else None
            return SpinType(SpinKind.CLOCK, q=q_val, location=loc)

        raise ParseError("Expected spin type (ising, binary, potts, clock, continuous)",
                        self.current().location)

    # =========================================================================
    # Lattice parsing
    # =========================================================================

    def parse_boundary(self) -> BoundaryCondition:
        """Parse boundary condition."""
        if self.match(TokenType.PERIODIC):
            return BoundaryCondition.PERIODIC
        if self.match(TokenType.OPEN):
            return BoundaryCondition.OPEN
        if self.match(TokenType.FIXED):
            return BoundaryCondition.FIXED
        return BoundaryCondition.PERIODIC  # Default

    def parse_lattice(self) -> LatticeExpr:
        """Parse lattice definition."""
        loc = self.current().location

        if self.match(TokenType.CHAIN):
            self.expect(TokenType.LPAREN)
            length = self.parse_expression()
            boundary = BoundaryCondition.PERIODIC
            if self.match(TokenType.COMMA):
                boundary = self.parse_boundary()
            self.expect(TokenType.RPAREN)
            return ChainLattice(length, boundary=boundary, location=loc)

        if self.match(TokenType.SQUARE):
            self.expect(TokenType.LPAREN)
            width = self.parse_expression()
            self.expect(TokenType.COMMA)
            height = self.parse_expression()
            boundary = BoundaryCondition.PERIODIC
            if self.match(TokenType.COMMA):
                boundary = self.parse_boundary()
            self.expect(TokenType.RPAREN)
            return SquareLattice(width, height, boundary=boundary, location=loc)

        if self.match(TokenType.TRIANGULAR):
            self.expect(TokenType.LPAREN)
            size = self.parse_expression()
            boundary = BoundaryCondition.PERIODIC
            if self.match(TokenType.COMMA):
                boundary = self.parse_boundary()
            self.expect(TokenType.RPAREN)
            return TriangularLattice(size, boundary=boundary, location=loc)

        if self.match(TokenType.HONEYCOMB):
            self.expect(TokenType.LPAREN)
            size = self.parse_expression()
            boundary = BoundaryCondition.PERIODIC
            if self.match(TokenType.COMMA):
                boundary = self.parse_boundary()
            self.expect(TokenType.RPAREN)
            return HoneycombLattice(size, boundary=boundary, location=loc)

        if self.match(TokenType.KAGOME):
            self.expect(TokenType.LPAREN)
            size = self.parse_expression()
            boundary = BoundaryCondition.PERIODIC
            if self.match(TokenType.COMMA):
                boundary = self.parse_boundary()
            self.expect(TokenType.RPAREN)
            return KagomeLattice(size, boundary=boundary, location=loc)

        if self.match(TokenType.CUBIC):
            self.expect(TokenType.LPAREN)
            x = self.parse_expression()
            self.expect(TokenType.COMMA)
            y = self.parse_expression()
            self.expect(TokenType.COMMA)
            z = self.parse_expression()
            boundary = BoundaryCondition.PERIODIC
            if self.match(TokenType.COMMA):
                boundary = self.parse_boundary()
            self.expect(TokenType.RPAREN)
            return CubicLattice(x, y, z, boundary=boundary, location=loc)

        if self.match(TokenType.GRAPH):
            self.expect(TokenType.LPAREN)
            edges = self.parse_expression()
            self.expect(TokenType.RPAREN)
            return CustomLattice(edges=edges, location=loc)

        raise ParseError("Expected lattice type", self.current().location)

    # =========================================================================
    # Expression parsing (precedence climbing)
    # =========================================================================

    PRECEDENCE = {
        TokenType.OR: 1,
        TokenType.AND: 2,
        TokenType.EQ: 3,
        TokenType.NE: 3,
        TokenType.LT: 4,
        TokenType.GT: 4,
        TokenType.LE: 4,
        TokenType.GE: 4,
        TokenType.PLUS: 5,
        TokenType.MINUS: 5,
        TokenType.STAR: 6,
        TokenType.SLASH: 6,
        TokenType.PERCENT: 6,
        TokenType.CARET: 7,  # Right associative
    }

    BINARY_OPS = {
        TokenType.PLUS: BinaryOperator.ADD,
        TokenType.MINUS: BinaryOperator.SUB,
        TokenType.STAR: BinaryOperator.MUL,
        TokenType.SLASH: BinaryOperator.DIV,
        TokenType.CARET: BinaryOperator.POW,
        TokenType.PERCENT: BinaryOperator.MOD,
        TokenType.EQ: BinaryOperator.EQ,
        TokenType.NE: BinaryOperator.NE,
        TokenType.LT: BinaryOperator.LT,
        TokenType.GT: BinaryOperator.GT,
        TokenType.LE: BinaryOperator.LE,
        TokenType.GE: BinaryOperator.GE,
        TokenType.AND: BinaryOperator.AND,
        TokenType.OR: BinaryOperator.OR,
    }

    def parse_expression(self, min_prec: int = 0) -> Expression:
        """Parse expression with precedence climbing."""
        left = self.parse_unary()

        while True:
            token = self.current()
            if token.type not in self.PRECEDENCE:
                break

            prec = self.PRECEDENCE[token.type]
            if prec < min_prec:
                break

            self.advance()
            op = self.BINARY_OPS[token.type]

            # Right associative for ^
            next_prec = prec + 1 if token.type != TokenType.CARET else prec

            right = self.parse_expression(next_prec)
            left = BinaryOp(op, left, right, location=token.location)

        return left

    def parse_unary(self) -> Expression:
        """Parse unary expression."""
        loc = self.current().location

        if self.match(TokenType.MINUS):
            operand = self.parse_unary()
            return UnaryOp(UnaryOperator.NEG, operand, location=loc)

        if self.match(TokenType.PLUS):
            operand = self.parse_unary()
            return UnaryOp(UnaryOperator.POS, operand, location=loc)

        if self.match(TokenType.NOT):
            operand = self.parse_unary()
            return UnaryOp(UnaryOperator.NOT, operand, location=loc)

        return self.parse_postfix()

    def parse_postfix(self) -> Expression:
        """Parse postfix expressions (subscript, call, field access)."""
        expr = self.parse_primary()

        while True:
            if self.match(TokenType.LBRACKET):
                # Subscript
                loc = self.current().location
                indices = [self.parse_expression()]
                while self.match(TokenType.COMMA):
                    indices.append(self.parse_expression())
                self.expect(TokenType.RBRACKET)
                expr = Subscript(expr, indices, location=loc)

            elif self.match(TokenType.LPAREN):
                # Function call (only if expr is identifier)
                loc = self.current().location
                if isinstance(expr, Identifier):
                    args = []
                    kwargs = {}
                    if not self.check(TokenType.RPAREN):
                        self._parse_call_args(args, kwargs)
                    self.expect(TokenType.RPAREN)
                    expr = FunctionCall(expr.name, args, kwargs, location=loc)
                else:
                    raise ParseError("Only identifiers can be called", loc)

            elif self.match(TokenType.DOT):
                # Check for range
                if self.check(TokenType.DOT):
                    # This is actually a range, backtrack
                    self.pos -= 1
                    break

                # Field access
                loc = self.current().location
                field = self.expect(TokenType.IDENT).value
                expr = Subscript(expr, [Identifier(field)], location=loc)

            else:
                break

        return expr

    def _parse_call_args(self, args: List[Expression], kwargs: dict) -> None:
        """Parse function call arguments."""
        while True:
            # Check for keyword argument
            if self.check(TokenType.IDENT) and self.peek(1).type == TokenType.ASSIGN:
                name = self.advance().value
                self.advance()  # =
                value = self.parse_expression()
                kwargs[name] = value
            else:
                args.append(self.parse_expression())

            if not self.match(TokenType.COMMA):
                break

    def parse_primary(self) -> Expression:
        """Parse primary expression."""
        loc = self.current().location

        # Literals
        if self.check(TokenType.INT):
            token = self.advance()
            value = int(token.value, 0)  # Handles hex, binary
            return IntLiteral(value, location=loc)

        if self.check(TokenType.REAL):
            token = self.advance()
            return RealLiteral(float(token.value), location=loc)

        if self.match(TokenType.TRUE):
            return BoolLiteral(True, location=loc)

        if self.match(TokenType.FALSE):
            return BoolLiteral(False, location=loc)

        if self.check(TokenType.STRING):
            token = self.advance()
            return StringLiteral(token.value, location=loc)

        # Parenthesized expression or tuple
        if self.match(TokenType.LPAREN):
            # Check for tuple pattern
            if self.check(TokenType.IDENT):
                first = self.advance().value
                if self.match(TokenType.COMMA):
                    elements = [first]
                    elements.append(self.expect(TokenType.IDENT).value)
                    while self.match(TokenType.COMMA):
                        elements.append(self.expect(TokenType.IDENT).value)
                    self.expect(TokenType.RPAREN)
                    return TuplePattern(elements, location=loc)
                else:
                    # Just a parenthesized identifier
                    self.pos -= 1  # Put back the identifier
                    self.pos -= 1  # Put back what we consumed after it
                    self.advance()  # Re-consume (

            expr = self.parse_expression()
            self.expect(TokenType.RPAREN)
            return expr

        # Array literal
        if self.match(TokenType.LBRACKET):
            return self._parse_array_or_matrix(loc)

        # Sum expression
        if self.match(TokenType.SUM):
            return self._parse_sum(loc)

        # Product expression
        if self.match(TokenType.PRODUCT):
            return self._parse_product(loc)

        # Let expression
        if self.match(TokenType.LET):
            return self._parse_let_expr(loc)

        # If expression
        if self.match(TokenType.IF):
            return self._parse_conditional(loc)

        # Built-in functions
        builtins = {
            TokenType.NEIGHBORS, TokenType.NEXT_NEIGHBORS, TokenType.ALL_PAIRS,
            TokenType.SITES, TokenType.DISTANCE, TokenType.DELTA,
            TokenType.COS, TokenType.SIN, TokenType.EXP, TokenType.LOG,
            TokenType.SQRT, TokenType.ABS,
        }
        if self.current().type in builtins:
            name = self.advance().value
            if self.match(TokenType.LPAREN):
                args = []
                kwargs = {}
                if not self.check(TokenType.RPAREN):
                    self._parse_call_args(args, kwargs)
                self.expect(TokenType.RPAREN)
                return FunctionCall(name, args, kwargs, location=loc)
            return Identifier(name, location=loc)

        # Identifier
        if self.check(TokenType.IDENT):
            return Identifier(self.advance().value, location=loc)

        raise ParseError(f"Unexpected token: {self.current().type.name}",
                        self.current().location)

    def _parse_array_or_matrix(self, loc: SourceLocation) -> Expression:
        """Parse array or matrix literal."""
        if self.check(TokenType.RBRACKET):
            self.advance()
            return ArrayExpr([], location=loc)

        first = self.parse_expression()

        # Check if this is a matrix (first element is array)
        if isinstance(first, ArrayExpr) or self.check(TokenType.LBRACKET):
            rows = []
            if isinstance(first, ArrayExpr):
                rows.append(first.elements)
            while self.match(TokenType.COMMA):
                self.skip_newlines()
                row_expr = self.parse_expression()
                if isinstance(row_expr, ArrayExpr):
                    rows.append(row_expr.elements)
            self.expect(TokenType.RBRACKET)
            return MatrixExpr(rows, location=loc)

        # Array
        elements = [first]
        while self.match(TokenType.COMMA):
            self.skip_newlines()
            elements.append(self.parse_expression())
        self.expect(TokenType.RBRACKET)

        # Check for range
        if len(elements) == 1 and self.check(TokenType.DOTDOT, TokenType.DOTDOTDOT):
            start = elements[0]
            inclusive = self.match(TokenType.DOTDOTDOT)
            if not inclusive:
                self.expect(TokenType.DOTDOT)
            end = self.parse_expression()
            return RangeExpr(start, end, inclusive, location=loc)

        return ArrayExpr(elements, location=loc)

    def _parse_sum(self, loc: SourceLocation) -> SumExpr:
        """Parse sum expression."""
        self.expect(TokenType.LPAREN)

        # Parse pattern
        pattern = self._parse_iteration_pattern()

        self.expect(TokenType.IN)
        domain = self.parse_expression()

        # Optional where clause
        condition = None
        if self.match(TokenType.WHERE):
            condition = self.parse_expression()

        self.expect(TokenType.RPAREN)
        self.expect(TokenType.LBRACE)
        self.skip_newlines()
        body = self.parse_expression()
        self.skip_newlines()
        self.expect(TokenType.RBRACE)

        return SumExpr(pattern, domain, body, condition, location=loc)

    def _parse_product(self, loc: SourceLocation) -> ProductExpr:
        """Parse product expression."""
        self.expect(TokenType.LPAREN)

        pattern = self._parse_iteration_pattern()

        self.expect(TokenType.IN)
        domain = self.parse_expression()

        condition = None
        if self.match(TokenType.WHERE):
            condition = self.parse_expression()

        self.expect(TokenType.RPAREN)
        self.expect(TokenType.LBRACE)
        self.skip_newlines()
        body = self.parse_expression()
        self.skip_newlines()
        self.expect(TokenType.RBRACE)

        return ProductExpr(pattern, domain, body, condition, location=loc)

    def _parse_iteration_pattern(self) -> Union[str, TuplePattern]:
        """Parse pattern for sum/product iteration."""
        loc = self.current().location

        if self.match(TokenType.LPAREN):
            elements = [self.expect(TokenType.IDENT).value]
            while self.match(TokenType.COMMA):
                elements.append(self.expect(TokenType.IDENT).value)
            self.expect(TokenType.RPAREN)
            return TuplePattern(elements, location=loc)

        return self.expect(TokenType.IDENT).value

    def _parse_let_expr(self, loc: SourceLocation) -> LetExpr:
        """Parse let expression."""
        name = self.expect(TokenType.IDENT).value

        type_ann = None
        if self.match(TokenType.COLON):
            type_ann = self.parse_type()

        self.expect(TokenType.ASSIGN)
        value = self.parse_expression()

        self.expect(TokenType.IN)
        body = self.parse_expression()

        return LetExpr(name, value, body, type_ann, location=loc)

    def _parse_conditional(self, loc: SourceLocation) -> ConditionalExpr:
        """Parse conditional expression."""
        condition = self.parse_expression()
        self.expect(TokenType.THEN)
        then_expr = self.parse_expression()
        self.expect(TokenType.ELSE)
        else_expr = self.parse_expression()
        return ConditionalExpr(condition, then_expr, else_expr, location=loc)

    # =========================================================================
    # Declaration parsing
    # =========================================================================

    def parse_parameter(self) -> Parameter:
        """Parse parameter declaration."""
        loc = self.current().location
        self.expect(TokenType.PARAM)

        name = self.expect(TokenType.IDENT).value
        self.expect(TokenType.COLON)
        param_type = self.parse_type()

        default = None
        if self.match(TokenType.ASSIGN):
            default = self.parse_expression()

        constraint = None
        if self.match(TokenType.WHERE):
            constraint = self.parse_expression()

        return Parameter(name, param_type, default, constraint, location=loc)

    def parse_constant(self) -> Constant:
        """Parse constant declaration."""
        loc = self.current().location
        self.expect(TokenType.CONST)

        name = self.expect(TokenType.IDENT).value

        type_ann = None
        if self.match(TokenType.COLON):
            type_ann = self.parse_type()

        self.expect(TokenType.ASSIGN)
        value = self.parse_expression()

        return Constant(name, type_ann, value, location=loc)

    def parse_let_binding(self) -> LetBinding:
        """Parse let binding in Hamiltonian body."""
        loc = self.current().location
        self.expect(TokenType.LET)

        name = self.expect(TokenType.IDENT).value

        indices = None
        if self.match(TokenType.LBRACKET):
            indices = [self.expect(TokenType.IDENT).value]
            while self.match(TokenType.COMMA):
                indices.append(self.expect(TokenType.IDENT).value)
            self.expect(TokenType.RBRACKET)

        type_ann = None
        if self.match(TokenType.COLON):
            type_ann = self.parse_type()

        self.expect(TokenType.ASSIGN)
        value = self.parse_expression()

        return LetBinding(name, indices, value, type_ann, location=loc)

    def parse_import(self) -> Import:
        """Parse import declaration."""
        loc = self.current().location

        if self.match(TokenType.FROM):
            module = self.expect(TokenType.IDENT).value
            self.expect(TokenType.IMPORT)
            items = [self.expect(TokenType.IDENT).value]
            while self.match(TokenType.COMMA):
                items.append(self.expect(TokenType.IDENT).value)
            return Import(module, items, location=loc)

        self.expect(TokenType.IMPORT)
        module = self.expect(TokenType.IDENT).value
        alias = None
        if self.match(TokenType.AS):
            alias = self.expect(TokenType.IDENT).value
        return Import(module, None, alias, location=loc)

    # =========================================================================
    # Energy term parsing
    # =========================================================================

    def parse_energy_term(self) -> EnergyTerm:
        """Parse an energy term in Hamiltonian body."""
        loc = self.current().location

        # Check for labeled term
        name = None
        if self.check(TokenType.IDENT) and self.peek(1).type == TokenType.COLON:
            name = self.advance().value
            self.advance()  # :

        # Parse the expression
        expr = self.parse_expression()

        # Classify the term
        if isinstance(expr, SumExpr):
            # Check if it's coupling or field based on pattern
            if isinstance(expr.pattern, TuplePattern) and len(expr.pattern.elements) == 2:
                return CouplingTerm(expr, name=name, location=loc)
            else:
                return FieldTerm(expr, name=name, location=loc)

        return CustomTerm(expr, name=name, location=loc)

    # =========================================================================
    # Hamiltonian parsing
    # =========================================================================

    def parse_hamiltonian(self) -> HamiltonianDef:
        """Parse Hamiltonian definition."""
        loc = self.current().location
        decorators = self.decorators
        doc = self.doc_comment
        self.decorators = []
        self.doc_comment = None

        self.expect(TokenType.HAMILTONIAN)
        name = self.expect(TokenType.IDENT).value

        # Parameters
        self.expect(TokenType.LPAREN)
        parameters = []
        if not self.check(TokenType.RPAREN):
            parameters.append(self._parse_param_in_signature())
            while self.match(TokenType.COMMA):
                parameters.append(self._parse_param_in_signature())
        self.expect(TokenType.RPAREN)

        # -> spin_type on lattice
        self.skip_newlines()
        self.expect(TokenType.ARROW)
        spin_type = self.parse_spin_type()

        # Check for 'on' keyword
        on_token = self.expect(TokenType.IDENT)
        if on_token.value != "on":
            raise ParseError("Expected 'on' after spin type", on_token.location)

        lattice = self.parse_lattice()

        # Optional constraints
        constraints = []
        while self.match(TokenType.WHERE):
            constraint_expr = self.parse_expression()
            constraints.append(WhereClause(constraint_expr, location=self.current().location))

        # Body
        self.skip_newlines()
        self.expect(TokenType.LBRACE)
        self.skip_newlines()

        let_bindings = []
        terms = []

        while not self.check(TokenType.RBRACE):
            self.skip_newlines()
            if self.check(TokenType.RBRACE):
                break

            if self.check(TokenType.LET):
                let_bindings.append(self.parse_let_binding())
            else:
                terms.append(self.parse_energy_term())

            self.skip_newlines()

        self.expect(TokenType.RBRACE)

        return HamiltonianDef(
            name=name,
            parameters=parameters,
            spin_type=spin_type,
            lattice=lattice,
            terms=terms,
            constraints=constraints,
            let_bindings=let_bindings,
            decorators=decorators,
            docstring=doc,
            location=loc,
        )

    def _parse_param_in_signature(self) -> Parameter:
        """Parse a parameter in function signature."""
        loc = self.current().location
        name = self.expect(TokenType.IDENT).value
        self.expect(TokenType.COLON)
        param_type = self.parse_type()

        default = None
        if self.match(TokenType.ASSIGN):
            default = self.parse_expression()

        constraint = None
        if self.match(TokenType.WHERE):
            constraint = self.parse_expression()

        return Parameter(name, param_type, default, constraint, location=loc)

    # =========================================================================
    # Program parsing
    # =========================================================================

    def parse_program(self) -> Program:
        """Parse complete program."""
        imports = []
        constants = []
        systems = []
        hamiltonians = []

        while not self.at_end():
            self.skip_newlines()
            if self.at_end():
                break

            # Collect decorators
            while self.match(TokenType.AT):
                decorator = self.expect(TokenType.IDENT).value
                self.decorators.append(decorator)
                self.skip_newlines()

            # Collect doc comments
            if self.check(TokenType.DOC_COMMENT):
                self.doc_comment = self.advance().value

            self.skip_newlines()

            if self.check(TokenType.IMPORT, TokenType.FROM):
                imports.append(self.parse_import())
            elif self.check(TokenType.CONST):
                constants.append(self.parse_constant())
            elif self.check(TokenType.SYSTEM):
                systems.append(self._parse_system())
            elif self.check(TokenType.HAMILTONIAN):
                hamiltonians.append(self.parse_hamiltonian())
            elif self.at_end():
                break
            else:
                raise ParseError(
                    f"Unexpected token at top level: {self.current().type.name}",
                    self.current().location
                )

            self.skip_newlines()

        return Program(imports, constants, systems, hamiltonians)

    def _parse_system(self) -> SystemDef:
        """Parse system definition."""
        loc = self.current().location
        self.expect(TokenType.SYSTEM)
        name = self.expect(TokenType.IDENT).value
        self.expect(TokenType.COLON)
        spin_type = self.parse_spin_type()

        on_token = self.expect(TokenType.IDENT)
        if on_token.value != "on":
            raise ParseError("Expected 'on' after spin type", on_token.location)

        lattice = self.parse_lattice()

        return SystemDef(name, spin_type, lattice, location=loc)


def parse(source: str, filename: str = "<input>") -> Program:
    """
    Parse PbitLang source code into an AST.

    Args:
        source: PbitLang source code
        filename: Source filename for error messages

    Returns:
        Program AST

    Raises:
        ParseError: If parsing fails
    """
    tokens = tokenize(source, filename)
    parser = Parser(tokens, source)
    return parser.parse_program()
