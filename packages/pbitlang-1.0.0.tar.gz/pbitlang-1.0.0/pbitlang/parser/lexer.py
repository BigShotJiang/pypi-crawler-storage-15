"""
PbitLang Lexer

Tokenizes PbitLang source code into a stream of tokens.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from enum import Enum, auto
from typing import Iterator, List, Optional, Tuple

from pbitlang.ast.nodes import SourceLocation


class TokenType(Enum):
    """Token types for PbitLang."""

    # Literals
    INT = auto()
    REAL = auto()
    STRING = auto()
    TRUE = auto()
    FALSE = auto()

    # Identifiers and keywords
    IDENT = auto()

    # Type keywords
    INT_TYPE = auto()
    REAL_TYPE = auto()
    BOOL_TYPE = auto()
    COMPLEX_TYPE = auto()

    # Spin type keywords
    ISING = auto()
    BINARY = auto()
    POTTS = auto()
    CLOCK = auto()
    CONTINUOUS = auto()
    SPIN = auto()

    # Declaration keywords
    HAMILTONIAN = auto()
    SYSTEM = auto()
    PARAM = auto()
    CONST = auto()
    LET = auto()
    IMPORT = auto()
    FROM = auto()
    AS = auto()

    # Control keywords
    SUM = auto()
    PRODUCT = auto()
    OVER = auto()
    WHERE = auto()
    FOR = auto()
    IN = auto()
    IF = auto()
    THEN = auto()
    ELSE = auto()

    # Lattice keywords
    CHAIN = auto()
    SQUARE = auto()
    TRIANGULAR = auto()
    HONEYCOMB = auto()
    KAGOME = auto()
    CUBIC = auto()
    GRAPH = auto()
    LATTICE = auto()

    # Boundary keywords
    PERIODIC = auto()
    OPEN = auto()
    FIXED = auto()

    # Builtin functions
    NEIGHBORS = auto()
    NEXT_NEIGHBORS = auto()
    ALL_PAIRS = auto()
    SITES = auto()
    DISTANCE = auto()
    DELTA = auto()
    COS = auto()
    SIN = auto()
    EXP = auto()
    LOG = auto()
    SQRT = auto()
    ABS = auto()

    # Constraint keywords
    REQUIRE = auto()
    ASSERT = auto()
    SYMMETRIC = auto()
    POSITIVE = auto()
    NORMALIZED = auto()

    # Logical operators
    AND = auto()
    OR = auto()
    NOT = auto()

    # Type keywords
    ARRAY = auto()
    MATRIX = auto()
    COUPLING = auto()
    FIELD = auto()

    # Operators
    PLUS = auto()
    MINUS = auto()
    STAR = auto()
    SLASH = auto()
    CARET = auto()
    PERCENT = auto()

    EQ = auto()
    NE = auto()
    LT = auto()
    GT = auto()
    LE = auto()
    GE = auto()

    ASSIGN = auto()
    WALRUS = auto()
    ARROW = auto()
    DOUBLE_ARROW = auto()

    # Punctuation
    LPAREN = auto()
    RPAREN = auto()
    LBRACKET = auto()
    RBRACKET = auto()
    LBRACE = auto()
    RBRACE = auto()
    COMMA = auto()
    COLON = auto()
    SEMICOLON = auto()
    DOT = auto()
    DOTDOT = auto()
    DOTDOTDOT = auto()
    AT = auto()
    PIPE = auto()

    # Special
    NEWLINE = auto()
    EOF = auto()
    COMMENT = auto()
    DOC_COMMENT = auto()


# Keywords mapping
KEYWORDS = {
    # Type keywords
    "int": TokenType.INT_TYPE,
    "real": TokenType.REAL_TYPE,
    "bool": TokenType.BOOL_TYPE,
    "complex": TokenType.COMPLEX_TYPE,

    # Spin types
    "ising": TokenType.ISING,
    "binary": TokenType.BINARY,
    "potts": TokenType.POTTS,
    "clock": TokenType.CLOCK,
    "continuous": TokenType.CONTINUOUS,
    "spin": TokenType.SPIN,

    # Declaration
    "hamiltonian": TokenType.HAMILTONIAN,
    "system": TokenType.SYSTEM,
    "param": TokenType.PARAM,
    "const": TokenType.CONST,
    "let": TokenType.LET,
    "import": TokenType.IMPORT,
    "from": TokenType.FROM,
    "as": TokenType.AS,

    # Control
    "sum": TokenType.SUM,
    "product": TokenType.PRODUCT,
    "over": TokenType.OVER,
    "where": TokenType.WHERE,
    "for": TokenType.FOR,
    "in": TokenType.IN,
    "if": TokenType.IF,
    "then": TokenType.THEN,
    "else": TokenType.ELSE,

    # Lattice
    "chain": TokenType.CHAIN,
    "square": TokenType.SQUARE,
    "triangular": TokenType.TRIANGULAR,
    "honeycomb": TokenType.HONEYCOMB,
    "kagome": TokenType.KAGOME,
    "cubic": TokenType.CUBIC,
    "graph": TokenType.GRAPH,
    "lattice": TokenType.LATTICE,

    # Boundary
    "periodic": TokenType.PERIODIC,
    "open": TokenType.OPEN,
    "fixed": TokenType.FIXED,

    # Builtins
    "neighbors": TokenType.NEIGHBORS,
    "next_neighbors": TokenType.NEXT_NEIGHBORS,
    "all_pairs": TokenType.ALL_PAIRS,
    "sites": TokenType.SITES,
    "distance": TokenType.DISTANCE,
    "delta": TokenType.DELTA,
    "cos": TokenType.COS,
    "sin": TokenType.SIN,
    "exp": TokenType.EXP,
    "log": TokenType.LOG,
    "sqrt": TokenType.SQRT,
    "abs": TokenType.ABS,

    # Constraints
    "require": TokenType.REQUIRE,
    "assert": TokenType.ASSERT,
    "symmetric": TokenType.SYMMETRIC,
    "positive": TokenType.POSITIVE,
    "normalized": TokenType.NORMALIZED,

    # Logical
    "and": TokenType.AND,
    "or": TokenType.OR,
    "not": TokenType.NOT,

    # Literals
    "true": TokenType.TRUE,
    "false": TokenType.FALSE,

    # Aggregate types
    "array": TokenType.ARRAY,
    "matrix": TokenType.MATRIX,
    "coupling": TokenType.COUPLING,
    "field": TokenType.FIELD,

    # Other
    "on": TokenType.IDENT,  # Context-sensitive
}


@dataclass
class Token:
    """A single token from the lexer."""
    type: TokenType
    value: str
    location: SourceLocation

    def __str__(self) -> str:
        return f"Token({self.type.name}, {self.value!r}, {self.location})"


class LexerError(Exception):
    """Error during lexical analysis."""

    def __init__(self, message: str, location: SourceLocation):
        self.message = message
        self.location = location
        super().__init__(f"{location}: {message}")


class Lexer:
    """
    Lexer for PbitLang.

    Converts source text into a stream of tokens.
    """

    def __init__(self, source: str, filename: str = "<input>"):
        self.source = source
        self.filename = filename
        self.pos = 0
        self.line = 1
        self.column = 1
        self.tokens: List[Token] = []

    def location(self) -> SourceLocation:
        """Current source location."""
        return SourceLocation(self.filename, self.line, self.column)

    def peek(self, offset: int = 0) -> str:
        """Peek at character at current position + offset."""
        pos = self.pos + offset
        if pos >= len(self.source):
            return ""
        return self.source[pos]

    def advance(self) -> str:
        """Advance one character and return it."""
        if self.pos >= len(self.source):
            return ""
        char = self.source[self.pos]
        self.pos += 1
        if char == "\n":
            self.line += 1
            self.column = 1
        else:
            self.column += 1
        return char

    def skip_whitespace(self) -> None:
        """Skip whitespace (except newlines which may be significant)."""
        while self.peek() in " \t\r":
            self.advance()

    def skip_comment(self) -> Optional[Token]:
        """Skip or return comment token."""
        loc = self.location()

        if self.peek() == "/" and self.peek(1) == "/":
            # Line comment
            self.advance()  # /
            self.advance()  # /

            # Check for doc comment ///
            is_doc = self.peek() == "/"
            if is_doc:
                self.advance()

            content = ""
            while self.peek() and self.peek() != "\n":
                content += self.advance()

            if is_doc:
                return Token(TokenType.DOC_COMMENT, content.strip(), loc)
            return None  # Skip regular comments

        elif self.peek() == "/" and self.peek(1) == "*":
            # Block comment
            self.advance()  # /
            self.advance()  # *
            content = ""
            while self.peek():
                if self.peek() == "*" and self.peek(1) == "/":
                    self.advance()  # *
                    self.advance()  # /
                    break
                content += self.advance()
            return None  # Skip block comments

        elif self.peek() == "#":
            # Hash comment
            while self.peek() and self.peek() != "\n":
                self.advance()
            return None

        return None

    def read_number(self) -> Token:
        """Read integer or real literal."""
        loc = self.location()
        value = ""

        # Check for hex/binary prefix
        if self.peek() == "0" and self.peek(1) in "xXbB":
            value += self.advance()  # 0
            value += self.advance()  # x or b
            while self.peek() and (self.peek().isalnum() or self.peek() == "_"):
                if self.peek() != "_":
                    value += self.advance()
                else:
                    self.advance()  # Skip underscore
            return Token(TokenType.INT, value, loc)

        # Read integer part
        while self.peek().isdigit() or self.peek() == "_":
            if self.peek() != "_":
                value += self.advance()
            else:
                self.advance()

        # Check for decimal
        if self.peek() == "." and self.peek(1).isdigit():
            value += self.advance()  # .
            while self.peek().isdigit() or self.peek() == "_":
                if self.peek() != "_":
                    value += self.advance()
                else:
                    self.advance()

        # Check for exponent
        if self.peek() in "eE":
            value += self.advance()  # e
            if self.peek() in "+-":
                value += self.advance()
            while self.peek().isdigit():
                value += self.advance()

        if "." in value or "e" in value.lower():
            return Token(TokenType.REAL, value, loc)
        return Token(TokenType.INT, value, loc)

    def read_string(self) -> Token:
        """Read string literal."""
        loc = self.location()
        quote = self.advance()  # " or '
        value = ""

        while self.peek() and self.peek() != quote:
            if self.peek() == "\\":
                self.advance()  # backslash
                escape = self.advance()
                if escape == "n":
                    value += "\n"
                elif escape == "t":
                    value += "\t"
                elif escape == "r":
                    value += "\r"
                elif escape == "\\":
                    value += "\\"
                elif escape == quote:
                    value += quote
                else:
                    value += escape
            elif self.peek() == "\n":
                raise LexerError("Unterminated string literal", loc)
            else:
                value += self.advance()

        if not self.peek():
            raise LexerError("Unterminated string literal", loc)

        self.advance()  # Closing quote
        return Token(TokenType.STRING, value, loc)

    def read_identifier(self) -> Token:
        """Read identifier or keyword."""
        loc = self.location()
        value = ""

        while self.peek() and (self.peek().isalnum() or self.peek() == "_"):
            value += self.advance()

        # Check for keyword
        token_type = KEYWORDS.get(value, TokenType.IDENT)
        return Token(token_type, value, loc)

    def read_operator(self) -> Token:
        """Read operator or punctuation."""
        loc = self.location()
        char = self.peek()

        # Two-character operators
        two_char = char + self.peek(1)
        three_char = two_char + self.peek(2)

        if three_char == "...":
            self.advance()
            self.advance()
            self.advance()
            return Token(TokenType.DOTDOTDOT, "...", loc)

        if two_char == "..":
            self.advance()
            self.advance()
            return Token(TokenType.DOTDOT, "..", loc)

        if two_char == "->":
            self.advance()
            self.advance()
            return Token(TokenType.ARROW, "->", loc)

        if two_char == "=>":
            self.advance()
            self.advance()
            return Token(TokenType.DOUBLE_ARROW, "=>", loc)

        if two_char == ":=":
            self.advance()
            self.advance()
            return Token(TokenType.WALRUS, ":=", loc)

        if two_char == "==":
            self.advance()
            self.advance()
            return Token(TokenType.EQ, "==", loc)

        if two_char == "!=":
            self.advance()
            self.advance()
            return Token(TokenType.NE, "!=", loc)

        if two_char == "<=":
            self.advance()
            self.advance()
            return Token(TokenType.LE, "<=", loc)

        if two_char == ">=":
            self.advance()
            self.advance()
            return Token(TokenType.GE, ">=", loc)

        # Single character
        self.advance()

        operators = {
            "+": TokenType.PLUS,
            "-": TokenType.MINUS,
            "*": TokenType.STAR,
            "/": TokenType.SLASH,
            "^": TokenType.CARET,
            "%": TokenType.PERCENT,
            "<": TokenType.LT,
            ">": TokenType.GT,
            "=": TokenType.ASSIGN,
            "(": TokenType.LPAREN,
            ")": TokenType.RPAREN,
            "[": TokenType.LBRACKET,
            "]": TokenType.RBRACKET,
            "{": TokenType.LBRACE,
            "}": TokenType.RBRACE,
            ",": TokenType.COMMA,
            ":": TokenType.COLON,
            ";": TokenType.SEMICOLON,
            ".": TokenType.DOT,
            "@": TokenType.AT,
            "|": TokenType.PIPE,
        }

        if char in operators:
            return Token(operators[char], char, loc)

        raise LexerError(f"Unexpected character: {char!r}", loc)

    def tokenize(self) -> List[Token]:
        """Tokenize the entire source."""
        self.tokens = []

        while self.pos < len(self.source):
            self.skip_whitespace()

            if not self.peek():
                break

            # Newline (may be significant)
            if self.peek() == "\n":
                loc = self.location()
                self.advance()
                # Only emit if previous token isn't already a newline
                if not self.tokens or self.tokens[-1].type != TokenType.NEWLINE:
                    self.tokens.append(Token(TokenType.NEWLINE, "\\n", loc))
                continue

            # Comments
            if self.peek() == "/" and self.peek(1) in "/*":
                comment_token = self.skip_comment()
                if comment_token:
                    self.tokens.append(comment_token)
                continue

            if self.peek() == "#":
                self.skip_comment()
                continue

            # Numbers
            if self.peek().isdigit():
                self.tokens.append(self.read_number())
                continue

            # Negative numbers (if preceded by operator)
            if self.peek() == "-" and self.peek(1).isdigit():
                if not self.tokens or self.tokens[-1].type in (
                    TokenType.LPAREN, TokenType.LBRACKET, TokenType.COMMA,
                    TokenType.ASSIGN, TokenType.COLON, TokenType.PLUS,
                    TokenType.MINUS, TokenType.STAR, TokenType.SLASH,
                    TokenType.CARET, TokenType.EQ, TokenType.NE,
                    TokenType.LT, TokenType.GT, TokenType.LE, TokenType.GE,
                ):
                    loc = self.location()
                    self.advance()  # -
                    num_token = self.read_number()
                    num_token.value = "-" + num_token.value
                    num_token.location = loc
                    self.tokens.append(num_token)
                    continue

            # Strings
            if self.peek() in "\"'":
                self.tokens.append(self.read_string())
                continue

            # Identifiers and keywords
            if self.peek().isalpha() or self.peek() == "_":
                self.tokens.append(self.read_identifier())
                continue

            # Operators and punctuation
            self.tokens.append(self.read_operator())

        # Add EOF
        self.tokens.append(Token(TokenType.EOF, "", self.location()))
        return self.tokens


def tokenize(source: str, filename: str = "<input>") -> List[Token]:
    """Convenience function to tokenize source code."""
    lexer = Lexer(source, filename)
    return lexer.tokenize()
