from .h5_utilities import *

__doc__="""\

H5 Utilities API
============

Generic
-------
.. autosummary::
   :toctree: .

   h5_utilities

"""