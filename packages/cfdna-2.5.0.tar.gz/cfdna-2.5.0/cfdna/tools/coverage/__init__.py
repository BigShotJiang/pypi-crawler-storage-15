from .gene_activity import *


__doc__="""\

Processing API
============
.. currentmodule:: cfdna

Generic
-------
.. autosummary::
   :toctree: .

   gene_activity

"""