# my_ai_lib

A simple AI helper library for generating responses using AI.

## Installation

## Usage Example

```python
from my_ai_lib import get_response

output = get_response("Hello, how are you?")
print(output)
