ENABLE_PARALLEL = False
ENABLE_FAST_MATH = True


class InvalidRangeException(Exception):
    pass
