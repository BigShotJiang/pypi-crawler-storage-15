
class KociError(Exception):
    """Generic errors."""
    pass
