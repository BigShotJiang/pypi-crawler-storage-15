"""
koci Core Module

Contains the core data models, parser, and expression evaluator.
"""

from .models import (
    Pipeline,
    Stage,
    Job,
    Step,
    Service,
    Artifact,
    MatrixConfig,
    StepType,
    JobStatus,
)
from .parser import (
    PipelineParser,
    parse_pipeline,
    parse_pipeline_string,
    ParserError,
    ValidationError,
)
from .expressions import (
    ExecutionContext,
    evaluate_when,
    evaluate_if,
    evaluate_condition,
    ExpressionError,
)
from .exc import KociError

__all__ = [
    # Models
    'Pipeline',
    'Stage',
    'Job',
    'Step',
    'Service',
    'Artifact',
    'MatrixConfig',
    'StepType',
    'JobStatus',
    # Parser
    'PipelineParser',
    'parse_pipeline',
    'parse_pipeline_string',
    'ParserError',
    'ValidationError',
    # Expressions
    'ExecutionContext',
    'evaluate_when',
    'evaluate_if',
    'evaluate_condition',
    'ExpressionError',
    # Exceptions
    'KociError',
]
