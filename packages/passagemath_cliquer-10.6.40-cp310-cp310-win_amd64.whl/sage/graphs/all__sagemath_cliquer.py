# sage_setup: distribution = sagemath-cliquer
