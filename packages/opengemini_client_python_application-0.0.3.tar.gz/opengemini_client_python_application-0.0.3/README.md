# project-name

> **Make it your own — a clean foundation to kickstart new projects.**

This template provides a simple, structured starting point for building new ideas quickly and consistently.

## Variables

> Replace the following variables (e.g., `git-repo-name`) with your project details using your editor's `find-and-replace` tool.

- git-org-name: the Git organization name
- git-repo-name: the Git repository name
- pypi-package-name: the PyPI package name
