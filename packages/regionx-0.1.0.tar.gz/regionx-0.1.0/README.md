# regionx. Regions on the sky.

The purpose of regionx is to be able to apply footprints and masks, easily on catalogue data.


