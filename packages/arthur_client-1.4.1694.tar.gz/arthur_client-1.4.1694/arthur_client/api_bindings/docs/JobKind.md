# JobKind


## Enum

* `METRICS_CALCULATION` (value: `'metrics_calculation'`)

* `CONNECTOR_CHECK` (value: `'connector_check'`)

* `LIST_DATASETS` (value: `'list_datasets'`)

* `SCHEMA_INSPECTION` (value: `'schema_inspection'`)

* `FETCH_DATA` (value: `'fetch_data'`)

* `ALERT_CHECK` (value: `'alert_check'`)

* `SCHEDULE_JOBS` (value: `'schedule_jobs'`)

* `CREATE_MODEL_TASK` (value: `'create_model_task'`)

* `CREATE_MODEL_LINK_TASK` (value: `'create_model_link_task'`)

* `UPDATE_MODEL_TASK_RULES` (value: `'update_model_task_rules'`)

* `DELETE_MODEL_TASK` (value: `'delete_model_task'`)

* `FETCH_MODEL_TASK` (value: `'fetch_model_task'`)

* `REGENERATE_TASK_VALIDATION_KEY` (value: `'regenerate_task_validation_key'`)

* `TEST_CUSTOM_AGGREGATION` (value: `'test_custom_aggregation'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


