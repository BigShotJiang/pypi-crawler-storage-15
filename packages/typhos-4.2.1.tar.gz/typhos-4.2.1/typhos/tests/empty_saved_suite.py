# Note: this file is used in test_utils

# Typhos expects to have saved something in this file which it will not find
# This causes ``test_load_suite_with_bad_py_file`` to fail with ``AttributeError``
