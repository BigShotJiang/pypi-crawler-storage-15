635 bug_parametertree_value
###########################

API Breaks
----------
- N/A

Features
--------
- N/A

Bugfixes
--------
- Ensures value is provided at __init__ for all subclasses of pyqtgraph.parametertree.Parameter

Maintenance
-----------
- N/A

Contributors
------------
- tangkong
