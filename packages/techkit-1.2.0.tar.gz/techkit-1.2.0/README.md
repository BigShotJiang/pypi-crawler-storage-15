# TechKit Python Bindings

High-performance Python bindings for TechKit technical analysis library.

## Features

- **189 Technical Indicators** - Moving averages, oscillators, volatility, volume indicators, and more
- **100% TA-Lib Compatible** - Drop-in replacement API for easy migration
- **High Performance** - C++ core with zero-copy NumPy integration
- **Streaming Support** - Both incremental (streaming) and batch calculation modes
- **Type Hints** - Full typing support for IDE integration
- **Cross-Platform** - Windows, Linux, macOS support

## Installation

### From PyPI (when available)

```bash
pip install techkit
```

### From Source

```bash
cd bindings/python
pip install -e .
```

## Quick Start

### OOP API (Recommended)

```python
from techkit import SMA, RSI, MACD, BBANDS
import numpy as np

# Sample data
prices = np.random.randn(100).cumsum() + 100

# Simple Moving Average
sma = SMA(period=20)
result = sma.calculate(prices)  # Batch calculation

# Incremental/streaming updates
sma.reset()
for price in prices:
    result = sma.update(price)
    if result.valid:
        print(f"SMA: {result.value}")

# Multi-output indicators
macd = MACD(fast=12, slow=26, signal=9)
result = macd.calculate(prices)
print(f"MACD: {result.macd[-1]}")
print(f"Signal: {result.signal[-1]}")
print(f"Histogram: {result.histogram[-1]}")

# Bollinger Bands
bbands = BBANDS(period=20, std_up=2.0, std_dn=2.0)
result = bbands.calculate(prices)
upper, middle, lower = result  # Can unpack
```

### TA-Lib Compatible API

```python
from techkit import talib_compat as ta

# Same API as TA-Lib
sma = ta.SMA(prices, timeperiod=20)
rsi = ta.RSI(prices, timeperiod=14)
macd, signal, hist = ta.MACD(prices)
upper, middle, lower = ta.BBANDS(prices, timeperiod=20)

# OHLCV indicators
atr = ta.ATR(high, low, close, timeperiod=14)
slowk, slowd = ta.STOCH(high, low, close)
```

### Indicator Chaining

```python
from techkit import Chain, RSI, EMA

# Smoothed RSI: RSI(14) -> EMA(9)
chain = Chain([RSI(14), EMA(9)])
smoothed_rsi = chain.calculate(prices)
```

## Available Indicators

### Moving Averages
- SMA, EMA, WMA, DEMA, TEMA, KAMA, TRIMA, T3

### Momentum
- RSI, MACD, MOM, ROC, CCI, ADX, WILLR, STOCH, MFI, TRIX, ULTOSC, CMO, etc.

### Volatility
- ATR, NATR, TRANGE, BBANDS

### Volume
- OBV, AD, ADOSC

### Statistics
- STDDEV, VAR, LINEARREG, TSF, BETA, CORREL

### Price Transform
- AVGPRICE, MEDPRICE, TYPPRICE, WCLPRICE

### Math Operators
- MAX, MIN, SUM, MIDPOINT, MIDPRICE, MINMAX

### Hilbert Transform
- HT_DCPERIOD, HT_DCPHASE, HT_TRENDMODE, HT_TRENDLINE, HT_PHASOR, HT_SINE

### Parabolic SAR
- SAR

## Performance

TechKit is designed for high performance:

- C++ core compiled with optimizations
- Zero-copy NumPy integration
- O(1) incremental updates
- O(period) memory footprint
- Thread-safe (no global state)

## Requirements

- Python 3.10, 3.11, 3.12, or 3.13
- NumPy >= 1.21.0

## License

MIT License

