"""Basic TechKit usage examples

This script demonstrates the main features of TechKit:
1. OOP API for indicators
2. Batch vs incremental calculation
3. Multi-output indicators
4. Indicator chaining
5. TA-Lib compatible API
"""

import numpy as np


def demo_oop_api():
    """Demonstrate the OOP API for indicators"""
    print("=" * 60)
    print("OOP API Demo")
    print("=" * 60)
    
    from techkit import SMA, RSI, MACD, BBANDS
    
    # Generate sample data
    np.random.seed(42)
    prices = 100 + np.cumsum(np.random.randn(100) * 0.5)
    
    # Simple Moving Average
    sma = SMA(period=20)
    sma_values = sma.calculate(prices)
    print(f"SMA(20) last 5 values: {sma_values[-5:]}")
    print(f"SMA lookback: {sma.lookback}")
    
    # RSI
    rsi = RSI(period=14)
    rsi_values = rsi.calculate(prices)
    print(f"\nRSI(14) last 5 values: {rsi_values[-5:]}")
    
    # MACD (multi-output)
    macd = MACD(fast=12, slow=26, signal=9)
    result = macd.calculate(prices)
    print(f"\nMACD: {result.macd[-1]:.4f}")
    print(f"Signal: {result.signal[-1]:.4f}")
    print(f"Histogram: {result.histogram[-1]:.4f}")
    
    # Bollinger Bands (multi-output)
    bbands = BBANDS(period=20, std_up=2.0, std_dn=2.0)
    bb_result = bbands.calculate(prices)
    print(f"\nBollinger Bands at last bar:")
    print(f"  Upper: {bb_result.upper[-1]:.2f}")
    print(f"  Middle: {bb_result.middle[-1]:.2f}")
    print(f"  Lower: {bb_result.lower[-1]:.2f}")


def demo_incremental():
    """Demonstrate incremental (streaming) updates"""
    print("\n" + "=" * 60)
    print("Incremental Updates Demo")
    print("=" * 60)
    
    from techkit import RSI
    
    # Generate sample data
    np.random.seed(42)
    prices = 100 + np.cumsum(np.random.randn(30) * 0.5)
    
    # Incremental update
    rsi = RSI(14)
    print("Streaming RSI values:")
    for i, price in enumerate(prices):
        result = rsi.update(price)
        if result.valid:
            print(f"  Bar {i:2d}: Price={price:7.2f}, RSI={result.value:5.1f}")


def demo_chain():
    """Demonstrate indicator chaining"""
    print("\n" + "=" * 60)
    print("Indicator Chaining Demo")
    print("=" * 60)
    
    from techkit import Chain, RSI, EMA, SMA
    
    # Generate sample data
    np.random.seed(42)
    prices = 100 + np.cumsum(np.random.randn(100) * 0.5)
    
    # Chain 1: RSI smoothed with EMA
    chain = Chain([RSI(14), EMA(9)])
    smoothed_rsi = chain.calculate(prices)
    print(f"Smoothed RSI (RSI(14) -> EMA(9)) last 5 values:")
    print(f"  {smoothed_rsi[-5:]}")
    
    # Chain 2: Double SMA for extra smoothing
    chain2 = Chain([SMA(10), SMA(5)])
    double_sma = chain2.calculate(prices)
    print(f"\nDouble SMA (SMA(10) -> SMA(5)) last 5 values:")
    print(f"  {double_sma[-5:]}")


def demo_talib_compat():
    """Demonstrate TA-Lib compatible API"""
    print("\n" + "=" * 60)
    print("TA-Lib Compatible API Demo")
    print("=" * 60)
    
    from techkit import talib_compat as ta
    
    # Generate sample OHLCV data
    np.random.seed(42)
    n = 100
    close = 100 + np.cumsum(np.random.randn(n) * 0.5)
    open_ = close + np.random.randn(n) * 0.1
    high = close + np.abs(np.random.randn(n) * 0.3)
    low = close - np.abs(np.random.randn(n) * 0.3)
    volume = np.random.randint(1000, 10000, n).astype(float)
    
    # Simple functions
    sma = ta.SMA(close, timeperiod=20)
    print(f"SMA(20) last value: {sma[-1]:.2f}")
    
    rsi = ta.RSI(close, timeperiod=14)
    print(f"RSI(14) last value: {rsi[-1]:.2f}")
    
    # Multi-output functions
    macd, signal, hist = ta.MACD(close, fastperiod=12, slowperiod=26, signalperiod=9)
    print(f"\nMACD: {macd[-1]:.4f}")
    print(f"Signal: {signal[-1]:.4f}")
    print(f"Histogram: {hist[-1]:.4f}")
    
    # OHLC functions
    atr = ta.ATR(high, low, close, timeperiod=14)
    print(f"\nATR(14) last value: {atr[-1]:.4f}")
    
    slowk, slowd = ta.STOCH(high, low, close, fastk_period=5, slowk_period=3, slowd_period=3)
    print(f"Stoch %K: {slowk[-1]:.2f}")
    print(f"Stoch %D: {slowd[-1]:.2f}")
    
    # Volume functions
    obv = ta.OBV(close, volume)
    print(f"\nOBV last value: {obv[-1]:.0f}")


def demo_batch_vs_incremental():
    """Compare batch and incremental calculation"""
    print("\n" + "=" * 60)
    print("Batch vs Incremental Comparison")
    print("=" * 60)
    
    from techkit import SMA
    
    # Generate sample data
    np.random.seed(42)
    prices = 100 + np.cumsum(np.random.randn(50) * 0.5)
    
    # Batch calculation
    sma = SMA(20)
    batch_result = sma.calculate(prices)
    
    # Incremental calculation
    sma.reset()
    incremental_result = []
    for price in prices:
        r = sma.update(price)
        incremental_result.append(r.value if r.valid else np.nan)
    
    incremental_result = np.array(incremental_result)
    
    # Compare
    diff = np.nanmax(np.abs(batch_result - incremental_result))
    print(f"Max difference between batch and incremental: {diff}")
    print(f"Results match: {diff < 1e-10}")


def main():
    """Run all demos"""
    print("TechKit Python Bindings Demo")
    print("============================\n")
    
    try:
        demo_oop_api()
        demo_incremental()
        demo_chain()
        demo_talib_compat()
        demo_batch_vs_incremental()
        
        print("\n" + "=" * 60)
        print("All demos completed successfully!")
        print("=" * 60)
    except ImportError as e:
        print(f"Error: Could not import techkit module.")
        print(f"Make sure to build and install the package first:")
        print(f"  pip install -e .")
        print(f"\nOriginal error: {e}")
        return 1
    
    return 0


if __name__ == "__main__":
    exit(main())

