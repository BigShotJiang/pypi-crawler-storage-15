"""Tests for TA-Lib compatibility layer"""

import pytest
import numpy as np

# Skip all tests if _core is not available
pytest.importorskip("techkit._core")

from techkit import talib_compat as ta


@pytest.fixture
def sample_data():
    """Generate sample OHLCV data"""
    np.random.seed(42)
    n = 500
    close = 100 + np.cumsum(np.random.randn(n) * 0.5)
    return {
        "open": close + np.random.randn(n) * 0.1,
        "high": close + np.abs(np.random.randn(n) * 0.3),
        "low": close - np.abs(np.random.randn(n) * 0.3),
        "close": close,
        "volume": np.random.randint(1000, 10000, n).astype(float),
    }


class TestMovingAverages:
    def test_sma(self, sample_data):
        result = ta.SMA(sample_data["close"], timeperiod=20)
        assert len(result) == len(sample_data["close"])
        assert np.isnan(result[:19]).all()
        assert not np.isnan(result[19:]).any()

    def test_ema(self, sample_data):
        result = ta.EMA(sample_data["close"], timeperiod=20)
        assert len(result) == len(sample_data["close"])

    def test_wma(self, sample_data):
        result = ta.WMA(sample_data["close"], timeperiod=20)
        assert len(result) == len(sample_data["close"])

    def test_dema(self, sample_data):
        result = ta.DEMA(sample_data["close"], timeperiod=20)
        assert len(result) == len(sample_data["close"])

    def test_tema(self, sample_data):
        result = ta.TEMA(sample_data["close"], timeperiod=20)
        assert len(result) == len(sample_data["close"])

    def test_kama(self, sample_data):
        result = ta.KAMA(sample_data["close"], timeperiod=30)
        assert len(result) == len(sample_data["close"])

    def test_trima(self, sample_data):
        result = ta.TRIMA(sample_data["close"], timeperiod=20)
        assert len(result) == len(sample_data["close"])

    def test_t3(self, sample_data):
        result = ta.T3(sample_data["close"], timeperiod=5, vfactor=0.7)
        assert len(result) == len(sample_data["close"])


class TestBollingerBands:
    def test_bbands(self, sample_data):
        upper, middle, lower = ta.BBANDS(sample_data["close"], timeperiod=20)
        assert len(upper) == len(sample_data["close"])
        assert len(middle) == len(sample_data["close"])
        assert len(lower) == len(sample_data["close"])

        # Upper >= Middle >= Lower
        valid = ~np.isnan(upper)
        assert (upper[valid] >= middle[valid]).all()
        assert (middle[valid] >= lower[valid]).all()


class TestMomentum:
    def test_rsi(self, sample_data):
        result = ta.RSI(sample_data["close"], timeperiod=14)
        assert len(result) == len(sample_data["close"])
        valid = result[~np.isnan(result)]
        assert (valid >= 0).all() and (valid <= 100).all()

    def test_mom(self, sample_data):
        result = ta.MOM(sample_data["close"], timeperiod=10)
        assert len(result) == len(sample_data["close"])

    def test_roc(self, sample_data):
        result = ta.ROC(sample_data["close"], timeperiod=10)
        assert len(result) == len(sample_data["close"])

    def test_rocp(self, sample_data):
        result = ta.ROCP(sample_data["close"], timeperiod=10)
        assert len(result) == len(sample_data["close"])

    def test_rocr(self, sample_data):
        result = ta.ROCR(sample_data["close"], timeperiod=10)
        assert len(result) == len(sample_data["close"])

    def test_rocr100(self, sample_data):
        result = ta.ROCR100(sample_data["close"], timeperiod=10)
        assert len(result) == len(sample_data["close"])

    def test_apo(self, sample_data):
        result = ta.APO(sample_data["close"], fastperiod=12, slowperiod=26)
        assert len(result) == len(sample_data["close"])

    def test_ppo(self, sample_data):
        result = ta.PPO(sample_data["close"], fastperiod=12, slowperiod=26)
        assert len(result) == len(sample_data["close"])

    def test_cmo(self, sample_data):
        result = ta.CMO(sample_data["close"], timeperiod=14)
        assert len(result) == len(sample_data["close"])

    def test_trix(self, sample_data):
        result = ta.TRIX(sample_data["close"], timeperiod=30)
        assert len(result) == len(sample_data["close"])


class TestMACD:
    def test_macd(self, sample_data):
        macd, signal, hist = ta.MACD(sample_data["close"])
        assert len(macd) == len(sample_data["close"])
        assert len(signal) == len(sample_data["close"])
        assert len(hist) == len(sample_data["close"])

    def test_macd_custom_periods(self, sample_data):
        macd, signal, hist = ta.MACD(
            sample_data["close"], fastperiod=8, slowperiod=17, signalperiod=9
        )
        assert len(macd) == len(sample_data["close"])


class TestVolatility:
    def test_atr(self, sample_data):
        result = ta.ATR(
            sample_data["high"],
            sample_data["low"],
            sample_data["close"],
            timeperiod=14,
        )
        assert len(result) == len(sample_data["close"])
        valid = result[~np.isnan(result)]
        assert (valid >= 0).all()

    def test_natr(self, sample_data):
        result = ta.NATR(
            sample_data["high"],
            sample_data["low"],
            sample_data["close"],
            timeperiod=14,
        )
        assert len(result) == len(sample_data["close"])

    def test_trange(self, sample_data):
        result = ta.TRANGE(
            sample_data["high"], sample_data["low"], sample_data["close"]
        )
        assert len(result) == len(sample_data["close"])


class TestDirectionalMovement:
    def test_adx(self, sample_data):
        result = ta.ADX(
            sample_data["high"],
            sample_data["low"],
            sample_data["close"],
            timeperiod=14,
        )
        assert len(result) == len(sample_data["close"])

    def test_adxr(self, sample_data):
        result = ta.ADXR(
            sample_data["high"],
            sample_data["low"],
            sample_data["close"],
            timeperiod=14,
        )
        assert len(result) == len(sample_data["close"])

    def test_dx(self, sample_data):
        result = ta.DX(
            sample_data["high"],
            sample_data["low"],
            sample_data["close"],
            timeperiod=14,
        )
        assert len(result) == len(sample_data["close"])

    def test_minus_di(self, sample_data):
        result = ta.MINUS_DI(
            sample_data["high"],
            sample_data["low"],
            sample_data["close"],
            timeperiod=14,
        )
        assert len(result) == len(sample_data["close"])

    def test_plus_di(self, sample_data):
        result = ta.PLUS_DI(
            sample_data["high"],
            sample_data["low"],
            sample_data["close"],
            timeperiod=14,
        )
        assert len(result) == len(sample_data["close"])

    def test_minus_dm(self, sample_data):
        result = ta.MINUS_DM(
            sample_data["high"], sample_data["low"], timeperiod=14
        )
        assert len(result) == len(sample_data["close"])

    def test_plus_dm(self, sample_data):
        result = ta.PLUS_DM(sample_data["high"], sample_data["low"], timeperiod=14)
        assert len(result) == len(sample_data["close"])


class TestOscillators:
    def test_willr(self, sample_data):
        result = ta.WILLR(
            sample_data["high"],
            sample_data["low"],
            sample_data["close"],
            timeperiod=14,
        )
        assert len(result) == len(sample_data["close"])
        valid = result[~np.isnan(result)]
        assert (valid >= -100).all() and (valid <= 0).all()

    def test_cci(self, sample_data):
        result = ta.CCI(
            sample_data["high"],
            sample_data["low"],
            sample_data["close"],
            timeperiod=14,
        )
        assert len(result) == len(sample_data["close"])

    def test_stoch(self, sample_data):
        slowk, slowd = ta.STOCH(
            sample_data["high"],
            sample_data["low"],
            sample_data["close"],
            fastk_period=5,
            slowk_period=3,
            slowd_period=3,
        )
        assert len(slowk) == len(sample_data["close"])
        assert len(slowd) == len(sample_data["close"])

    def test_mfi(self, sample_data):
        result = ta.MFI(
            sample_data["high"],
            sample_data["low"],
            sample_data["close"],
            sample_data["volume"],
            timeperiod=14,
        )
        assert len(result) == len(sample_data["close"])

    def test_ultosc(self, sample_data):
        result = ta.ULTOSC(
            sample_data["high"],
            sample_data["low"],
            sample_data["close"],
            timeperiod1=7,
            timeperiod2=14,
            timeperiod3=28,
        )
        assert len(result) == len(sample_data["close"])

    def test_aroon(self, sample_data):
        down, up = ta.AROON(
            sample_data["high"], sample_data["low"], timeperiod=14
        )
        assert len(up) == len(sample_data["close"])
        assert len(down) == len(sample_data["close"])

    def test_aroonosc(self, sample_data):
        result = ta.AROONOSC(
            sample_data["high"], sample_data["low"], timeperiod=14
        )
        assert len(result) == len(sample_data["close"])


class TestVolume:
    def test_obv(self, sample_data):
        result = ta.OBV(sample_data["close"], sample_data["volume"])
        assert len(result) == len(sample_data["close"])

    def test_ad(self, sample_data):
        result = ta.AD(
            sample_data["high"],
            sample_data["low"],
            sample_data["close"],
            sample_data["volume"],
        )
        assert len(result) == len(sample_data["close"])

    def test_adosc(self, sample_data):
        result = ta.ADOSC(
            sample_data["high"],
            sample_data["low"],
            sample_data["close"],
            sample_data["volume"],
            fastperiod=3,
            slowperiod=10,
        )
        assert len(result) == len(sample_data["close"])


class TestStatistics:
    def test_stddev(self, sample_data):
        result = ta.STDDEV(sample_data["close"], timeperiod=5, nbdev=1.0)
        assert len(result) == len(sample_data["close"])
        valid = result[~np.isnan(result)]
        assert (valid >= 0).all()

    def test_var(self, sample_data):
        result = ta.VAR(sample_data["close"], timeperiod=5, nbdev=1.0)
        assert len(result) == len(sample_data["close"])
        valid = result[~np.isnan(result)]
        assert (valid >= 0).all()

    def test_linearreg(self, sample_data):
        result = ta.LINEARREG(sample_data["close"], timeperiod=14)
        assert len(result) == len(sample_data["close"])

    def test_linearreg_slope(self, sample_data):
        result = ta.LINEARREG_SLOPE(sample_data["close"], timeperiod=14)
        assert len(result) == len(sample_data["close"])

    def test_linearreg_intercept(self, sample_data):
        result = ta.LINEARREG_INTERCEPT(sample_data["close"], timeperiod=14)
        assert len(result) == len(sample_data["close"])

    def test_linearreg_angle(self, sample_data):
        result = ta.LINEARREG_ANGLE(sample_data["close"], timeperiod=14)
        assert len(result) == len(sample_data["close"])

    def test_tsf(self, sample_data):
        result = ta.TSF(sample_data["close"], timeperiod=14)
        assert len(result) == len(sample_data["close"])


class TestPriceTransform:
    def test_avgprice(self, sample_data):
        result = ta.AVGPRICE(
            sample_data["open"],
            sample_data["high"],
            sample_data["low"],
            sample_data["close"],
        )
        assert len(result) == len(sample_data["close"])

    def test_medprice(self, sample_data):
        result = ta.MEDPRICE(sample_data["high"], sample_data["low"])
        assert len(result) == len(sample_data["close"])

    def test_typprice(self, sample_data):
        result = ta.TYPPRICE(
            sample_data["high"], sample_data["low"], sample_data["close"]
        )
        assert len(result) == len(sample_data["close"])

    def test_wclprice(self, sample_data):
        result = ta.WCLPRICE(
            sample_data["high"], sample_data["low"], sample_data["close"]
        )
        assert len(result) == len(sample_data["close"])


class TestMathOperators:
    def test_max(self, sample_data):
        result = ta.MAX(sample_data["close"], timeperiod=30)
        assert len(result) == len(sample_data["close"])

    def test_min(self, sample_data):
        result = ta.MIN(sample_data["close"], timeperiod=30)
        assert len(result) == len(sample_data["close"])

    def test_sum(self, sample_data):
        result = ta.SUM(sample_data["close"], timeperiod=30)
        assert len(result) == len(sample_data["close"])

    def test_minmax(self, sample_data):
        min_result, max_result = ta.MINMAX(sample_data["close"], timeperiod=30)
        assert len(min_result) == len(sample_data["close"])
        assert len(max_result) == len(sample_data["close"])
        valid = ~np.isnan(min_result)
        assert (min_result[valid] <= max_result[valid]).all()


class TestHilbertTransform:
    def test_ht_dcperiod(self, sample_data):
        result = ta.HT_DCPERIOD(sample_data["close"])
        assert len(result) == len(sample_data["close"])

    def test_ht_dcphase(self, sample_data):
        result = ta.HT_DCPHASE(sample_data["close"])
        assert len(result) == len(sample_data["close"])

    def test_ht_trendmode(self, sample_data):
        result = ta.HT_TRENDMODE(sample_data["close"])
        assert len(result) == len(sample_data["close"])

    def test_ht_trendline(self, sample_data):
        result = ta.HT_TRENDLINE(sample_data["close"])
        assert len(result) == len(sample_data["close"])

    def test_ht_phasor(self, sample_data):
        inphase, quadrature = ta.HT_PHASOR(sample_data["close"])
        assert len(inphase) == len(sample_data["close"])
        assert len(quadrature) == len(sample_data["close"])

    def test_ht_sine(self, sample_data):
        sine, leadsine = ta.HT_SINE(sample_data["close"])
        assert len(sine) == len(sample_data["close"])
        assert len(leadsine) == len(sample_data["close"])


class TestPandasIntegration:
    def test_pandas_series(self, sample_data):
        """Test that pandas Series works as input"""
        try:
            import pandas as pd

            close = pd.Series(sample_data["close"])
            result = ta.SMA(close, timeperiod=20)
            assert len(result) == len(close)
        except ImportError:
            pytest.skip("pandas not installed")

    def test_pandas_dataframe_column(self, sample_data):
        """Test that DataFrame column works as input"""
        try:
            import pandas as pd

            df = pd.DataFrame(sample_data)
            result = ta.RSI(df["close"], timeperiod=14)
            assert len(result) == len(df)
        except ImportError:
            pytest.skip("pandas not installed")

