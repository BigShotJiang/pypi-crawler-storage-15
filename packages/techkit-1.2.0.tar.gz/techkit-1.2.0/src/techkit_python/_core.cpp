/**
 * @file _core.cpp
 * @brief TechKit Python bindings using pybind11
 * 
 * This module exposes TechKit's C API to Python with NumPy integration
 * for high-performance technical analysis.
 */

#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>
#include <pybind11/stl.h>
#include <techkit/techkit_c.h>
#include <cmath>
#include <string>
#include <stdexcept>
#include <tuple>

namespace py = pybind11;

/*============================================================
 * Result Types
 *============================================================*/

struct PyResult {
    double value;
    bool valid;
};

struct PyMACDResult {
    double macd;
    double signal;
    double histogram;
    bool valid;
};

struct PyBBandsResult {
    double upper;
    double middle;
    double lower;
    bool valid;
};

struct PyStochResult {
    double slowk;
    double slowd;
    bool valid;
};

struct PyAroonResult {
    double up;
    double down;
    bool valid;
};

struct PyADXResult {
    double plus_di;
    double minus_di;
    double adx;
    bool valid;
};

struct PyHTPhasorResult {
    double inphase;
    double quadrature;
    bool valid;
};

struct PyHTSineResult {
    double sine;
    double leadsine;
    bool valid;
};

struct PyMinMaxResult {
    double min;
    double max;
    bool valid;
};

/*============================================================
 * Base Indicator Wrapper
 *============================================================*/

class PyIndicator {
public:
    explicit PyIndicator(tk_indicator ind) : ind_(ind) {
        if (!ind_) throw std::runtime_error("Failed to create indicator");
    }
    
    ~PyIndicator() {
        if (ind_) tk_free(ind_);
    }
    
    // Disable copy, enable move
    PyIndicator(const PyIndicator&) = delete;
    PyIndicator& operator=(const PyIndicator&) = delete;
    PyIndicator(PyIndicator&& other) noexcept : ind_(other.ind_) { 
        other.ind_ = nullptr; 
    }
    PyIndicator& operator=(PyIndicator&& other) noexcept {
        if (this != &other) {
            if (ind_) tk_free(ind_);
            ind_ = other.ind_;
            other.ind_ = nullptr;
        }
        return *this;
    }
    
    // Incremental update (single value)
    PyResult update(double value) {
        tk_result r = tk_update(ind_, value);
        return {r.value, r.valid != 0};
    }
    
    // Incremental update (OHLCV)
    PyResult update_ohlcv(double open, double high, double low, 
                          double close, double volume) {
        tk_ohlcv bar = {open, high, low, close, volume};
        tk_result r = tk_update_ohlcv(ind_, &bar);
        return {r.value, r.valid != 0};
    }
    
    // NumPy batch calculation (zero-copy input)
    py::array_t<double> calculate(py::array_t<double, py::array::c_style> input) {
        py::buffer_info buf = input.request();
        if (buf.ndim != 1) {
            throw std::runtime_error("Input must be 1-dimensional");
        }
        
        double* data = static_cast<double*>(buf.ptr);
        size_t size = static_cast<size_t>(buf.size);
        
        // Create output array
        py::array_t<double> output(size);
        double* out = static_cast<double*>(output.request().ptr);
        
        // Reset and calculate
        tk_reset(ind_);
        for (size_t i = 0; i < size; ++i) {
            tk_result r = tk_update(ind_, data[i]);
            out[i] = r.valid ? r.value : std::nan("");
        }
        return output;
    }
    
    // Batch calculation for OHLCV indicators
    py::array_t<double> calculate_ohlcv(
        py::array_t<double, py::array::c_style> open,
        py::array_t<double, py::array::c_style> high,
        py::array_t<double, py::array::c_style> low,
        py::array_t<double, py::array::c_style> close,
        py::array_t<double, py::array::c_style> volume
    ) {
        size_t size = static_cast<size_t>(close.request().size);
        const double* o = static_cast<const double*>(open.request().ptr);
        const double* h = static_cast<const double*>(high.request().ptr);
        const double* l = static_cast<const double*>(low.request().ptr);
        const double* c = static_cast<const double*>(close.request().ptr);
        const double* v = static_cast<const double*>(volume.request().ptr);
        
        py::array_t<double> output(size);
        double* out = static_cast<double*>(output.request().ptr);
        
        tk_reset(ind_);
        for (size_t i = 0; i < size; ++i) {
            tk_ohlcv bar = {o[i], h[i], l[i], c[i], v[i]};
            tk_result r = tk_update_ohlcv(ind_, &bar);
            out[i] = r.valid ? r.value : std::nan("");
        }
        return output;
    }
    
    void reset() { tk_reset(ind_); }
    bool is_ready() const { return tk_is_ready(ind_) != 0; }
    int lookback() const { return tk_lookback(ind_); }
    std::string name() const { return tk_name(ind_); }

protected:
    tk_indicator ind_;
};

/*============================================================
 * Multi-Output Indicator Wrappers
 *============================================================*/

// MACD Indicator with 3 outputs
class PyMACDIndicator : public PyIndicator {
public:
    PyMACDIndicator(int fast, int slow, int signal) 
        : PyIndicator(tk_macd_new(fast, slow, signal)) {}
    
    PyMACDResult update_macd(double value) {
        tk_macd_result r = tk_macd_update(ind_, value);
        return {r.macd, r.signal, r.histogram, r.valid != 0};
    }
    
    std::tuple<py::array_t<double>, py::array_t<double>, py::array_t<double>>
    calculate_macd(py::array_t<double, py::array::c_style> input) {
        py::buffer_info buf = input.request();
        size_t size = static_cast<size_t>(buf.size);
        double* data = static_cast<double*>(buf.ptr);
        
        py::array_t<double> out_macd(size);
        py::array_t<double> out_signal(size);
        py::array_t<double> out_hist(size);
        
        double* macd = static_cast<double*>(out_macd.request().ptr);
        double* signal = static_cast<double*>(out_signal.request().ptr);
        double* hist = static_cast<double*>(out_hist.request().ptr);
        
        tk_reset(ind_);
        for (size_t i = 0; i < size; ++i) {
            tk_macd_result r = tk_macd_update(ind_, data[i]);
            if (r.valid) {
                macd[i] = r.macd;
                signal[i] = r.signal;
                hist[i] = r.histogram;
            } else {
                macd[i] = signal[i] = hist[i] = std::nan("");
            }
        }
        return std::make_tuple(out_macd, out_signal, out_hist);
    }
};

// Bollinger Bands with 3 outputs
class PyBBandsIndicator : public PyIndicator {
public:
    PyBBandsIndicator(int period, double std_up, double std_dn)
        : PyIndicator(tk_bbands_new(period, std_up, std_dn)) {}
    
    PyBBandsResult update_bbands(double value) {
        tk_bbands_result r = tk_bbands_update(ind_, value);
        return {r.upper, r.middle, r.lower, r.valid != 0};
    }
    
    std::tuple<py::array_t<double>, py::array_t<double>, py::array_t<double>>
    calculate_bbands(py::array_t<double, py::array::c_style> input) {
        py::buffer_info buf = input.request();
        size_t size = static_cast<size_t>(buf.size);
        double* data = static_cast<double*>(buf.ptr);
        
        py::array_t<double> out_upper(size);
        py::array_t<double> out_middle(size);
        py::array_t<double> out_lower(size);
        
        double* upper = static_cast<double*>(out_upper.request().ptr);
        double* middle = static_cast<double*>(out_middle.request().ptr);
        double* lower = static_cast<double*>(out_lower.request().ptr);
        
        tk_reset(ind_);
        for (size_t i = 0; i < size; ++i) {
            tk_bbands_result r = tk_bbands_update(ind_, data[i]);
            if (r.valid) {
                upper[i] = r.upper;
                middle[i] = r.middle;
                lower[i] = r.lower;
            } else {
                upper[i] = middle[i] = lower[i] = std::nan("");
            }
        }
        return std::make_tuple(out_upper, out_middle, out_lower);
    }
};

// Stochastic with 2 outputs
class PyStochIndicator : public PyIndicator {
public:
    PyStochIndicator(int k_period, int k_slow, int d_period)
        : PyIndicator(tk_stoch_new(k_period, k_slow, d_period)) {}
    
    PyStochResult update_stoch(double open, double high, double low, 
                               double close, double volume) {
        tk_ohlcv bar = {open, high, low, close, volume};
        tk_stoch_result r = tk_stoch_update(ind_, &bar);
        return {r.slowk, r.slowd, r.valid != 0};
    }
    
    std::tuple<py::array_t<double>, py::array_t<double>>
    calculate_stoch(
        py::array_t<double, py::array::c_style> high,
        py::array_t<double, py::array::c_style> low,
        py::array_t<double, py::array::c_style> close
    ) {
        size_t size = static_cast<size_t>(close.request().size);
        const double* h = static_cast<const double*>(high.request().ptr);
        const double* l = static_cast<const double*>(low.request().ptr);
        const double* c = static_cast<const double*>(close.request().ptr);
        
        py::array_t<double> out_k(size);
        py::array_t<double> out_d(size);
        
        double* k = static_cast<double*>(out_k.request().ptr);
        double* d = static_cast<double*>(out_d.request().ptr);
        
        tk_reset(ind_);
        for (size_t i = 0; i < size; ++i) {
            tk_ohlcv bar = {0, h[i], l[i], c[i], 0};  // open/volume not needed
            tk_stoch_result r = tk_stoch_update(ind_, &bar);
            if (r.valid) {
                k[i] = r.slowk;
                d[i] = r.slowd;
            } else {
                k[i] = d[i] = std::nan("");
            }
        }
        return std::make_tuple(out_k, out_d);
    }
};

// Aroon with 2 outputs
class PyAroonIndicator : public PyIndicator {
public:
    explicit PyAroonIndicator(int period)
        : PyIndicator(tk_aroon_new(period)) {}
    
    PyAroonResult update_aroon(double open, double high, double low, 
                               double close, double volume) {
        tk_ohlcv bar = {open, high, low, close, volume};
        tk_aroon_result r = tk_aroon_update(ind_, &bar);
        return {r.up, r.down, r.valid != 0};
    }
    
    std::tuple<py::array_t<double>, py::array_t<double>>
    calculate_aroon(
        py::array_t<double, py::array::c_style> high,
        py::array_t<double, py::array::c_style> low
    ) {
        size_t size = static_cast<size_t>(high.request().size);
        const double* h = static_cast<const double*>(high.request().ptr);
        const double* l = static_cast<const double*>(low.request().ptr);
        
        py::array_t<double> out_up(size);
        py::array_t<double> out_down(size);
        
        double* up = static_cast<double*>(out_up.request().ptr);
        double* down = static_cast<double*>(out_down.request().ptr);
        
        tk_reset(ind_);
        for (size_t i = 0; i < size; ++i) {
            tk_ohlcv bar = {0, h[i], l[i], 0, 0};
            tk_aroon_result r = tk_aroon_update(ind_, &bar);
            if (r.valid) {
                up[i] = r.up;
                down[i] = r.down;
            } else {
                up[i] = down[i] = std::nan("");
            }
        }
        return std::make_tuple(out_up, out_down);
    }
};

// ADX with 3 outputs
class PyADXIndicator : public PyIndicator {
public:
    explicit PyADXIndicator(int period)
        : PyIndicator(tk_adx_new(period)) {}
    
    PyADXResult update_adx(double open, double high, double low, 
                           double close, double volume) {
        tk_ohlcv bar = {open, high, low, close, volume};
        tk_adx_result r = tk_adx_update(ind_, &bar);
        return {r.plus_di, r.minus_di, r.adx, r.valid != 0};
    }
    
    std::tuple<py::array_t<double>, py::array_t<double>, py::array_t<double>>
    calculate_adx(
        py::array_t<double, py::array::c_style> high,
        py::array_t<double, py::array::c_style> low,
        py::array_t<double, py::array::c_style> close
    ) {
        size_t size = static_cast<size_t>(close.request().size);
        const double* h = static_cast<const double*>(high.request().ptr);
        const double* l = static_cast<const double*>(low.request().ptr);
        const double* c = static_cast<const double*>(close.request().ptr);
        
        py::array_t<double> out_plus_di(size);
        py::array_t<double> out_minus_di(size);
        py::array_t<double> out_adx(size);
        
        double* plus_di = static_cast<double*>(out_plus_di.request().ptr);
        double* minus_di = static_cast<double*>(out_minus_di.request().ptr);
        double* adx = static_cast<double*>(out_adx.request().ptr);
        
        tk_reset(ind_);
        for (size_t i = 0; i < size; ++i) {
            tk_ohlcv bar = {0, h[i], l[i], c[i], 0};
            tk_adx_result r = tk_adx_update(ind_, &bar);
            if (r.valid) {
                plus_di[i] = r.plus_di;
                minus_di[i] = r.minus_di;
                adx[i] = r.adx;
            } else {
                plus_di[i] = minus_di[i] = adx[i] = std::nan("");
            }
        }
        return std::make_tuple(out_plus_di, out_minus_di, out_adx);
    }
};

// Hilbert Transform Phasor with 2 outputs
class PyHTPhasorIndicator : public PyIndicator {
public:
    PyHTPhasorIndicator() : PyIndicator(tk_ht_phasor_new()) {}
    
    PyHTPhasorResult update_phasor(double value) {
        tk_ht_phasor_result r = tk_ht_phasor_update(ind_, value);
        return {r.inphase, r.quadrature, r.valid != 0};
    }
    
    std::tuple<py::array_t<double>, py::array_t<double>>
    calculate_phasor(py::array_t<double, py::array::c_style> input) {
        py::buffer_info buf = input.request();
        size_t size = static_cast<size_t>(buf.size);
        double* data = static_cast<double*>(buf.ptr);
        
        py::array_t<double> out_inphase(size);
        py::array_t<double> out_quadrature(size);
        
        double* inphase = static_cast<double*>(out_inphase.request().ptr);
        double* quadrature = static_cast<double*>(out_quadrature.request().ptr);
        
        tk_reset(ind_);
        for (size_t i = 0; i < size; ++i) {
            tk_ht_phasor_result r = tk_ht_phasor_update(ind_, data[i]);
            if (r.valid) {
                inphase[i] = r.inphase;
                quadrature[i] = r.quadrature;
            } else {
                inphase[i] = quadrature[i] = std::nan("");
            }
        }
        return std::make_tuple(out_inphase, out_quadrature);
    }
};

// Hilbert Transform Sine with 2 outputs
class PyHTSineIndicator : public PyIndicator {
public:
    PyHTSineIndicator() : PyIndicator(tk_ht_sine_new()) {}
    
    PyHTSineResult update_sine(double value) {
        tk_ht_sine_result r = tk_ht_sine_update(ind_, value);
        return {r.sine, r.leadsine, r.valid != 0};
    }
    
    std::tuple<py::array_t<double>, py::array_t<double>>
    calculate_sine(py::array_t<double, py::array::c_style> input) {
        py::buffer_info buf = input.request();
        size_t size = static_cast<size_t>(buf.size);
        double* data = static_cast<double*>(buf.ptr);
        
        py::array_t<double> out_sine(size);
        py::array_t<double> out_leadsine(size);
        
        double* sine = static_cast<double*>(out_sine.request().ptr);
        double* leadsine = static_cast<double*>(out_leadsine.request().ptr);
        
        tk_reset(ind_);
        for (size_t i = 0; i < size; ++i) {
            tk_ht_sine_result r = tk_ht_sine_update(ind_, data[i]);
            if (r.valid) {
                sine[i] = r.sine;
                leadsine[i] = r.leadsine;
            } else {
                sine[i] = leadsine[i] = std::nan("");
            }
        }
        return std::make_tuple(out_sine, out_leadsine);
    }
};

// MinMax with 2 outputs
class PyMinMaxIndicator : public PyIndicator {
public:
    explicit PyMinMaxIndicator(int period)
        : PyIndicator(tk_minmax_new(period)) {}
    
    PyMinMaxResult update_minmax(double value) {
        tk_minmax_result r = tk_minmax_update(ind_, value);
        return {r.min, r.max, r.valid != 0};
    }
    
    std::tuple<py::array_t<double>, py::array_t<double>>
    calculate_minmax(py::array_t<double, py::array::c_style> input) {
        py::buffer_info buf = input.request();
        size_t size = static_cast<size_t>(buf.size);
        double* data = static_cast<double*>(buf.ptr);
        
        py::array_t<double> out_min(size);
        py::array_t<double> out_max(size);
        
        double* min_out = static_cast<double*>(out_min.request().ptr);
        double* max_out = static_cast<double*>(out_max.request().ptr);
        
        tk_reset(ind_);
        for (size_t i = 0; i < size; ++i) {
            tk_minmax_result r = tk_minmax_update(ind_, data[i]);
            if (r.valid) {
                min_out[i] = r.min;
                max_out[i] = r.max;
            } else {
                min_out[i] = max_out[i] = std::nan("");
            }
        }
        return std::make_tuple(out_min, out_max);
    }
};

/*============================================================
 * Module Definition
 *============================================================*/

PYBIND11_MODULE(_core, m) {
    m.doc() = "TechKit - High-performance technical analysis library";
    
    // Version info
    m.def("version", &tk_version_string, "Get version string");
    m.def("version_tuple", []() {
        return py::make_tuple(tk_version_major(), tk_version_minor(), tk_version_patch());
    }, "Get version as (major, minor, patch) tuple");
    
    /*============================================================
     * Result types
     *============================================================*/
    
    py::class_<PyResult>(m, "Result")
        .def_readonly("value", &PyResult::value)
        .def_readonly("valid", &PyResult::valid)
        .def("__bool__", [](const PyResult& r) { return r.valid; })
        .def("__repr__", [](const PyResult& r) {
            return r.valid ? 
                "Result(" + std::to_string(r.value) + ")" : 
                "Result(invalid)";
        });
    
    py::class_<PyMACDResult>(m, "MACDResult")
        .def_readonly("macd", &PyMACDResult::macd)
        .def_readonly("signal", &PyMACDResult::signal)
        .def_readonly("histogram", &PyMACDResult::histogram)
        .def_readonly("valid", &PyMACDResult::valid)
        .def("__bool__", [](const PyMACDResult& r) { return r.valid; })
        .def("__repr__", [](const PyMACDResult& r) {
            if (r.valid) {
                return "MACDResult(macd=" + std::to_string(r.macd) + 
                       ", signal=" + std::to_string(r.signal) + 
                       ", histogram=" + std::to_string(r.histogram) + ")";
            }
            return std::string("MACDResult(invalid)");
        });
    
    py::class_<PyBBandsResult>(m, "BBandsResult")
        .def_readonly("upper", &PyBBandsResult::upper)
        .def_readonly("middle", &PyBBandsResult::middle)
        .def_readonly("lower", &PyBBandsResult::lower)
        .def_readonly("valid", &PyBBandsResult::valid)
        .def("__bool__", [](const PyBBandsResult& r) { return r.valid; });
    
    py::class_<PyStochResult>(m, "StochResult")
        .def_readonly("slowk", &PyStochResult::slowk)
        .def_readonly("slowd", &PyStochResult::slowd)
        .def_readonly("valid", &PyStochResult::valid)
        .def("__bool__", [](const PyStochResult& r) { return r.valid; });
    
    py::class_<PyAroonResult>(m, "AroonResult")
        .def_readonly("up", &PyAroonResult::up)
        .def_readonly("down", &PyAroonResult::down)
        .def_readonly("valid", &PyAroonResult::valid)
        .def("__bool__", [](const PyAroonResult& r) { return r.valid; });
    
    py::class_<PyADXResult>(m, "ADXResult")
        .def_readonly("plus_di", &PyADXResult::plus_di)
        .def_readonly("minus_di", &PyADXResult::minus_di)
        .def_readonly("adx", &PyADXResult::adx)
        .def_readonly("valid", &PyADXResult::valid)
        .def("__bool__", [](const PyADXResult& r) { return r.valid; });
    
    py::class_<PyHTPhasorResult>(m, "HTPhasorResult")
        .def_readonly("inphase", &PyHTPhasorResult::inphase)
        .def_readonly("quadrature", &PyHTPhasorResult::quadrature)
        .def_readonly("valid", &PyHTPhasorResult::valid)
        .def("__bool__", [](const PyHTPhasorResult& r) { return r.valid; });
    
    py::class_<PyHTSineResult>(m, "HTSineResult")
        .def_readonly("sine", &PyHTSineResult::sine)
        .def_readonly("leadsine", &PyHTSineResult::leadsine)
        .def_readonly("valid", &PyHTSineResult::valid)
        .def("__bool__", [](const PyHTSineResult& r) { return r.valid; });
    
    py::class_<PyMinMaxResult>(m, "MinMaxResult")
        .def_readonly("min", &PyMinMaxResult::min)
        .def_readonly("max", &PyMinMaxResult::max)
        .def_readonly("valid", &PyMinMaxResult::valid)
        .def("__bool__", [](const PyMinMaxResult& r) { return r.valid; });
    
    /*============================================================
     * Base indicator class
     *============================================================*/
    
    py::class_<PyIndicator>(m, "Indicator")
        .def("update", &PyIndicator::update, py::arg("value"),
             "Update indicator with a single value (incremental)")
        .def("update_ohlcv", &PyIndicator::update_ohlcv,
             py::arg("open"), py::arg("high"), py::arg("low"), 
             py::arg("close"), py::arg("volume"),
             "Update indicator with OHLCV bar data")
        .def("calculate", &PyIndicator::calculate, py::arg("data"),
             "Calculate indicator for entire array (batch)")
        .def("calculate_ohlcv", &PyIndicator::calculate_ohlcv,
             py::arg("open"), py::arg("high"), py::arg("low"),
             py::arg("close"), py::arg("volume"),
             "Calculate indicator from OHLCV arrays (batch)")
        .def("reset", &PyIndicator::reset,
             "Reset indicator to initial state")
        .def("is_ready", &PyIndicator::is_ready,
             "Check if indicator has completed warmup period")
        .def_property_readonly("lookback", &PyIndicator::lookback,
             "Number of bars required for warmup")
        .def_property_readonly("name", &PyIndicator::name,
             "Indicator name");
    
    /*============================================================
     * Multi-output indicator classes
     *============================================================*/
    
    py::class_<PyMACDIndicator, PyIndicator>(m, "MACDIndicator")
        .def(py::init<int, int, int>(), 
             py::arg("fast") = 12, py::arg("slow") = 26, py::arg("signal") = 9,
             "Create MACD indicator")
        .def("update_macd", &PyMACDIndicator::update_macd, py::arg("value"),
             "Update with single value, returns MACDResult")
        .def("calculate_macd", &PyMACDIndicator::calculate_macd, py::arg("data"),
             "Calculate MACD for entire array, returns (macd, signal, histogram)");
    
    py::class_<PyBBandsIndicator, PyIndicator>(m, "BBandsIndicator")
        .def(py::init<int, double, double>(),
             py::arg("period") = 20, py::arg("std_up") = 2.0, py::arg("std_dn") = 2.0,
             "Create Bollinger Bands indicator")
        .def("update_bbands", &PyBBandsIndicator::update_bbands, py::arg("value"),
             "Update with single value, returns BBandsResult")
        .def("calculate_bbands", &PyBBandsIndicator::calculate_bbands, py::arg("data"),
             "Calculate Bollinger Bands for array, returns (upper, middle, lower)");
    
    py::class_<PyStochIndicator, PyIndicator>(m, "StochIndicator")
        .def(py::init<int, int, int>(),
             py::arg("k_period") = 14, py::arg("k_slow") = 3, py::arg("d_period") = 3,
             "Create Stochastic Oscillator indicator")
        .def("update_stoch", &PyStochIndicator::update_stoch,
             py::arg("open"), py::arg("high"), py::arg("low"),
             py::arg("close"), py::arg("volume"),
             "Update with OHLCV bar, returns StochResult")
        .def("calculate_stoch", &PyStochIndicator::calculate_stoch,
             py::arg("high"), py::arg("low"), py::arg("close"),
             "Calculate Stochastic for arrays, returns (slowk, slowd)");
    
    py::class_<PyAroonIndicator, PyIndicator>(m, "AroonIndicator")
        .def(py::init<int>(), py::arg("period") = 14,
             "Create Aroon indicator")
        .def("update_aroon", &PyAroonIndicator::update_aroon,
             py::arg("open"), py::arg("high"), py::arg("low"),
             py::arg("close"), py::arg("volume"),
             "Update with OHLCV bar, returns AroonResult")
        .def("calculate_aroon", &PyAroonIndicator::calculate_aroon,
             py::arg("high"), py::arg("low"),
             "Calculate Aroon for arrays, returns (up, down)");
    
    py::class_<PyADXIndicator, PyIndicator>(m, "ADXIndicator")
        .def(py::init<int>(), py::arg("period") = 14,
             "Create ADX indicator")
        .def("update_adx", &PyADXIndicator::update_adx,
             py::arg("open"), py::arg("high"), py::arg("low"),
             py::arg("close"), py::arg("volume"),
             "Update with OHLCV bar, returns ADXResult")
        .def("calculate_adx", &PyADXIndicator::calculate_adx,
             py::arg("high"), py::arg("low"), py::arg("close"),
             "Calculate ADX for arrays, returns (plus_di, minus_di, adx)");
    
    py::class_<PyHTPhasorIndicator, PyIndicator>(m, "HTPhasorIndicator")
        .def(py::init<>(), "Create Hilbert Transform Phasor indicator")
        .def("update_phasor", &PyHTPhasorIndicator::update_phasor, py::arg("value"),
             "Update with single value, returns HTPhasorResult")
        .def("calculate_phasor", &PyHTPhasorIndicator::calculate_phasor, py::arg("data"),
             "Calculate HT Phasor for array, returns (inphase, quadrature)");
    
    py::class_<PyHTSineIndicator, PyIndicator>(m, "HTSineIndicator")
        .def(py::init<>(), "Create Hilbert Transform Sine indicator")
        .def("update_sine", &PyHTSineIndicator::update_sine, py::arg("value"),
             "Update with single value, returns HTSineResult")
        .def("calculate_sine", &PyHTSineIndicator::calculate_sine, py::arg("data"),
             "Calculate HT Sine for array, returns (sine, leadsine)");
    
    py::class_<PyMinMaxIndicator, PyIndicator>(m, "MinMaxIndicator")
        .def(py::init<int>(), py::arg("period") = 30,
             "Create MinMax indicator")
        .def("update_minmax", &PyMinMaxIndicator::update_minmax, py::arg("value"),
             "Update with single value, returns MinMaxResult")
        .def("calculate_minmax", &PyMinMaxIndicator::calculate_minmax, py::arg("data"),
             "Calculate MinMax for array, returns (min, max)");
    
    /*============================================================
     * Factory functions for single-output indicators
     *============================================================*/
    
    // Moving Averages
    m.def("sma", [](int p) { return PyIndicator(tk_sma_new(p)); }, 
          py::arg("period"), "Simple Moving Average");
    m.def("ema", [](int p) { return PyIndicator(tk_ema_new(p)); }, 
          py::arg("period"), "Exponential Moving Average");
    m.def("wma", [](int p) { return PyIndicator(tk_wma_new(p)); }, 
          py::arg("period"), "Weighted Moving Average");
    m.def("dema", [](int p) { return PyIndicator(tk_dema_new(p)); }, 
          py::arg("period"), "Double Exponential Moving Average");
    m.def("tema", [](int p) { return PyIndicator(tk_tema_new(p)); }, 
          py::arg("period"), "Triple Exponential Moving Average");
    m.def("kama", [](int p) { return PyIndicator(tk_kama_new(p)); }, 
          py::arg("period"), "Kaufman Adaptive Moving Average");
    m.def("trima", [](int p) { return PyIndicator(tk_trima_new(p)); }, 
          py::arg("period"), "Triangular Moving Average");
    m.def("t3", [](int p, double v) { return PyIndicator(tk_t3_new(p, v)); }, 
          py::arg("period"), py::arg("volume_factor") = 0.7, "T3 Moving Average");
    
    // Momentum Indicators
    m.def("rsi", [](int p) { return PyIndicator(tk_rsi_new(p)); }, 
          py::arg("period") = 14, "Relative Strength Index");
    m.def("mom", [](int p) { return PyIndicator(tk_mom_new(p)); }, 
          py::arg("period") = 10, "Momentum");
    m.def("roc", [](int p) { return PyIndicator(tk_roc_new(p)); }, 
          py::arg("period") = 10, "Rate of Change");
    m.def("rocp", [](int p) { return PyIndicator(tk_rocp_new(p)); }, 
          py::arg("period") = 10, "Rate of Change Percentage");
    m.def("rocr", [](int p) { return PyIndicator(tk_rocr_new(p)); }, 
          py::arg("period") = 10, "Rate of Change Ratio");
    m.def("rocr100", [](int p) { return PyIndicator(tk_rocr100_new(p)); }, 
          py::arg("period") = 10, "Rate of Change Ratio * 100");
    m.def("cci", [](int p) { return PyIndicator(tk_cci_new(p)); }, 
          py::arg("period") = 20, "Commodity Channel Index");
    m.def("adx", [](int p) { return PyIndicator(tk_adx_new(p)); }, 
          py::arg("period") = 14, "Average Directional Index");
    m.def("adxr", [](int p) { return PyIndicator(tk_adxr_new(p)); }, 
          py::arg("period") = 14, "ADX Rating");
    m.def("apo", [](int f, int s) { return PyIndicator(tk_apo_new(f, s)); }, 
          py::arg("fast") = 12, py::arg("slow") = 26, "Absolute Price Oscillator");
    m.def("ppo", [](int f, int s) { return PyIndicator(tk_ppo_new(f, s)); }, 
          py::arg("fast") = 12, py::arg("slow") = 26, "Percentage Price Oscillator");
    m.def("cmo", [](int p) { return PyIndicator(tk_cmo_new(p)); }, 
          py::arg("period") = 14, "Chande Momentum Oscillator");
    m.def("dx", [](int p) { return PyIndicator(tk_dx_new(p)); }, 
          py::arg("period") = 14, "Directional Movement Index");
    m.def("willr", [](int p) { return PyIndicator(tk_willr_new(p)); }, 
          py::arg("period") = 14, "Williams %R");
    m.def("mfi", [](int p) { return PyIndicator(tk_mfi_new(p)); }, 
          py::arg("period") = 14, "Money Flow Index");
    m.def("plus_di", [](int p) { return PyIndicator(tk_plus_di_new(p)); }, 
          py::arg("period") = 14, "Plus Directional Indicator");
    m.def("minus_di", [](int p) { return PyIndicator(tk_minus_di_new(p)); }, 
          py::arg("period") = 14, "Minus Directional Indicator");
    m.def("plus_dm", [](int p) { return PyIndicator(tk_plus_dm_new(p)); }, 
          py::arg("period") = 14, "Plus Directional Movement");
    m.def("minus_dm", [](int p) { return PyIndicator(tk_minus_dm_new(p)); }, 
          py::arg("period") = 14, "Minus Directional Movement");
    m.def("trix", [](int p) { return PyIndicator(tk_trix_new(p)); }, 
          py::arg("period") = 30, "Triple Exponential Average");
    m.def("ultosc", [](int p1, int p2, int p3) { 
              return PyIndicator(tk_ultosc_new(p1, p2, p3)); 
          }, py::arg("period1") = 7, py::arg("period2") = 14, py::arg("period3") = 28,
          "Ultimate Oscillator");
    m.def("aroonosc", [](int p) { return PyIndicator(tk_aroonosc_new(p)); }, 
          py::arg("period") = 14, "Aroon Oscillator");
    m.def("bop", []() { return PyIndicator(tk_bop_new()); }, 
          "Balance of Power");
    
    // Volatility Indicators
    m.def("atr", [](int p) { return PyIndicator(tk_atr_new(p)); }, 
          py::arg("period") = 14, "Average True Range");
    m.def("natr", [](int p) { return PyIndicator(tk_natr_new(p)); }, 
          py::arg("period") = 14, "Normalized Average True Range");
    m.def("trange", []() { return PyIndicator(tk_trange_new()); }, 
          "True Range");
    
    // Volume Indicators
    m.def("obv", []() { return PyIndicator(tk_obv_new()); }, 
          "On Balance Volume");
    m.def("ad", []() { return PyIndicator(tk_ad_new()); }, 
          "Accumulation/Distribution");
    m.def("adosc", [](int f, int s) { return PyIndicator(tk_adosc_new(f, s)); },
          py::arg("fast") = 3, py::arg("slow") = 10, "A/D Oscillator");
    
    // Statistics
    m.def("stddev", [](int p, double nbdev) { return PyIndicator(tk_stddev_new(p, nbdev)); }, 
          py::arg("period") = 5, py::arg("nbdev") = 1.0, "Standard Deviation");
    m.def("var", [](int p) { return PyIndicator(tk_var_new(p)); }, 
          py::arg("period") = 5, "Variance");
    m.def("linearreg", [](int p) { return PyIndicator(tk_linearreg_new(p)); }, 
          py::arg("period") = 14, "Linear Regression");
    m.def("linearreg_slope", [](int p) { return PyIndicator(tk_linearreg_slope_new(p)); }, 
          py::arg("period") = 14, "Linear Regression Slope");
    m.def("linearreg_intercept", [](int p) { return PyIndicator(tk_linearreg_intercept_new(p)); }, 
          py::arg("period") = 14, "Linear Regression Intercept");
    m.def("linearreg_angle", [](int p) { return PyIndicator(tk_linearreg_angle_new(p)); }, 
          py::arg("period") = 14, "Linear Regression Angle");
    m.def("tsf", [](int p) { return PyIndicator(tk_tsf_new(p)); }, 
          py::arg("period") = 14, "Time Series Forecast");
    m.def("beta", [](int p) { return PyIndicator(tk_beta_new(p)); }, 
          py::arg("period") = 5, "Beta");
    m.def("correl", [](int p) { return PyIndicator(tk_correl_new(p)); }, 
          py::arg("period") = 30, "Pearson Correlation");
    
    // Price Transform
    m.def("avgprice", []() { return PyIndicator(tk_avgprice_new()); }, 
          "Average Price");
    m.def("medprice", []() { return PyIndicator(tk_medprice_new()); }, 
          "Median Price");
    m.def("typprice", []() { return PyIndicator(tk_typprice_new()); }, 
          "Typical Price");
    m.def("wclprice", []() { return PyIndicator(tk_wclprice_new()); }, 
          "Weighted Close Price");
    
    // Math Operators
    m.def("max", [](int p) { return PyIndicator(tk_max_new(p)); }, 
          py::arg("period") = 30, "Highest Value");
    m.def("min", [](int p) { return PyIndicator(tk_min_new(p)); }, 
          py::arg("period") = 30, "Lowest Value");
    m.def("sum", [](int p) { return PyIndicator(tk_sum_new(p)); }, 
          py::arg("period") = 30, "Sum");
    m.def("midpoint", [](int p) { return PyIndicator(tk_midpoint_new(p)); }, 
          py::arg("period") = 14, "Midpoint over Period");
    m.def("midprice", [](int p) { return PyIndicator(tk_midprice_new(p)); }, 
          py::arg("period") = 14, "Midpoint Price");
    
    // Hilbert Transform
    m.def("ht_dcperiod", []() { return PyIndicator(tk_ht_dcperiod_new()); }, 
          "Hilbert Transform - Dominant Cycle Period");
    m.def("ht_dcphase", []() { return PyIndicator(tk_ht_dcphase_new()); }, 
          "Hilbert Transform - Dominant Cycle Phase");
    m.def("ht_trendmode", []() { return PyIndicator(tk_ht_trendmode_new()); }, 
          "Hilbert Transform - Trend vs Cycle Mode");
    m.def("ht_trendline", []() { return PyIndicator(tk_ht_trendline_new()); }, 
          "Hilbert Transform - Instantaneous Trendline");
    
    // Parabolic SAR
    m.def("sar", [](double accel, double max) { 
              return PyIndicator(tk_sar_new(accel, max)); 
          }, py::arg("acceleration") = 0.02, py::arg("maximum") = 0.2,
          "Parabolic SAR");
    
    /*============================================================
     * Multi-output indicator factory functions
     *============================================================*/
    
    m.def("macd", [](int f, int s, int sig) { 
              return PyMACDIndicator(f, s, sig); 
          }, py::arg("fast") = 12, py::arg("slow") = 26, py::arg("signal") = 9,
          "MACD");
    
    m.def("bbands", [](int p, double up, double dn) { 
              return PyBBandsIndicator(p, up, dn); 
          }, py::arg("period") = 20, py::arg("std_up") = 2.0, py::arg("std_dn") = 2.0,
          "Bollinger Bands");
    
    m.def("stoch", [](int k, int ks, int d) { 
              return PyStochIndicator(k, ks, d); 
          }, py::arg("k_period") = 14, py::arg("k_slow") = 3, py::arg("d_period") = 3,
          "Stochastic Oscillator");
    
    m.def("aroon", [](int p) { 
              return PyAroonIndicator(p); 
          }, py::arg("period") = 14,
          "Aroon");
    
    m.def("adx_full", [](int p) { 
              return PyADXIndicator(p); 
          }, py::arg("period") = 14,
          "ADX (with +DI, -DI)");
    
    m.def("ht_phasor", []() { 
              return PyHTPhasorIndicator(); 
          }, "Hilbert Transform - Phasor Components");
    
    m.def("ht_sine", []() { 
              return PyHTSineIndicator(); 
          }, "Hilbert Transform - Sine Wave");
    
    m.def("minmax", [](int p) { 
              return PyMinMaxIndicator(p); 
          }, py::arg("period") = 30,
          "Min and Max over Period");
}

