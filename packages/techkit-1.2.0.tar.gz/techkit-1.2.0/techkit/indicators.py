"""High-level Pythonic indicator classes

This module provides a user-friendly OOP interface for TechKit indicators.
Each indicator class wraps the low-level C++ implementation and provides:
- Incremental updates via update() method
- Batch calculation via calculate() method
- Proper type hints for IDE support
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Union, Iterator

import numpy as np
from numpy.typing import NDArray

import techkit._core as _tk


# ============================================================
# Result Types
# ============================================================


@dataclass
class IndicatorResult:
    """Result from incremental indicator update"""

    value: float
    valid: bool

    def __bool__(self) -> bool:
        return self.valid

    def __repr__(self) -> str:
        if self.valid:
            return f"IndicatorResult({self.value:.6f})"
        return "IndicatorResult(invalid)"


@dataclass
class MACDResult:
    """Result from MACD calculation"""

    macd: NDArray[np.float64]
    signal: NDArray[np.float64]
    histogram: NDArray[np.float64]

    def __iter__(self) -> Iterator[NDArray[np.float64]]:
        return iter([self.macd, self.signal, self.histogram])


@dataclass
class BBandsResult:
    """Result from Bollinger Bands calculation"""

    upper: NDArray[np.float64]
    middle: NDArray[np.float64]
    lower: NDArray[np.float64]

    def __iter__(self) -> Iterator[NDArray[np.float64]]:
        return iter([self.upper, self.middle, self.lower])


@dataclass
class StochResult:
    """Result from Stochastic calculation"""

    slowk: NDArray[np.float64]
    slowd: NDArray[np.float64]

    def __iter__(self) -> Iterator[NDArray[np.float64]]:
        return iter([self.slowk, self.slowd])


@dataclass
class AroonResult:
    """Result from Aroon calculation"""

    up: NDArray[np.float64]
    down: NDArray[np.float64]

    def __iter__(self) -> Iterator[NDArray[np.float64]]:
        return iter([self.up, self.down])


@dataclass
class MinMaxResult:
    """Result from MinMax calculation"""

    min: NDArray[np.float64]
    max: NDArray[np.float64]

    def __iter__(self) -> Iterator[NDArray[np.float64]]:
        return iter([self.min, self.max])


# ============================================================
# Base Indicator Class
# ============================================================


class Indicator:
    """Base class for all indicators"""

    def __init__(self, indicator: _tk.Indicator) -> None:
        self._indicator = indicator

    def update(self, value: float) -> IndicatorResult:
        """Update indicator with a single value (incremental)"""
        r = self._indicator.update(value)
        return IndicatorResult(r.value, r.valid)

    def calculate(self, data: Union[np.ndarray, list]) -> NDArray[np.float64]:
        """Calculate indicator for entire array (batch)"""
        arr = np.asarray(data, dtype=np.float64)
        return self._indicator.calculate(arr)

    def reset(self) -> None:
        """Reset indicator state"""
        self._indicator.reset()

    @property
    def lookback(self) -> int:
        """Number of values needed before first valid output"""
        return self._indicator.lookback

    @property
    def name(self) -> str:
        """Indicator name"""
        return self._indicator.name

    @property
    def is_ready(self) -> bool:
        """Whether indicator has enough data for valid output"""
        return self._indicator.is_ready()


# ============================================================
# Moving Averages
# ============================================================


class SMA(Indicator):
    """Simple Moving Average"""

    def __init__(self, period: int = 20) -> None:
        super().__init__(_tk.sma(period))
        self.period = period


class EMA(Indicator):
    """Exponential Moving Average"""

    def __init__(self, period: int = 20) -> None:
        super().__init__(_tk.ema(period))
        self.period = period


class WMA(Indicator):
    """Weighted Moving Average"""

    def __init__(self, period: int = 20) -> None:
        super().__init__(_tk.wma(period))
        self.period = period


class DEMA(Indicator):
    """Double Exponential Moving Average"""

    def __init__(self, period: int = 20) -> None:
        super().__init__(_tk.dema(period))
        self.period = period


class TEMA(Indicator):
    """Triple Exponential Moving Average"""

    def __init__(self, period: int = 20) -> None:
        super().__init__(_tk.tema(period))
        self.period = period


class KAMA(Indicator):
    """Kaufman Adaptive Moving Average"""

    def __init__(self, period: int = 30) -> None:
        super().__init__(_tk.kama(period))
        self.period = period


class TRIMA(Indicator):
    """Triangular Moving Average"""

    def __init__(self, period: int = 20) -> None:
        super().__init__(_tk.trima(period))
        self.period = period


class T3(Indicator):
    """T3 Moving Average"""

    def __init__(self, period: int = 5, volume_factor: float = 0.7) -> None:
        super().__init__(_tk.t3(period, volume_factor))
        self.period = period
        self.volume_factor = volume_factor


# ============================================================
# Momentum Indicators
# ============================================================


class RSI(Indicator):
    """Relative Strength Index"""

    def __init__(self, period: int = 14) -> None:
        super().__init__(_tk.rsi(period))
        self.period = period


class MOM(Indicator):
    """Momentum"""

    def __init__(self, period: int = 10) -> None:
        super().__init__(_tk.mom(period))
        self.period = period


class ROC(Indicator):
    """Rate of Change"""

    def __init__(self, period: int = 10) -> None:
        super().__init__(_tk.roc(period))
        self.period = period


class ROCP(Indicator):
    """Rate of Change Percentage"""

    def __init__(self, period: int = 10) -> None:
        super().__init__(_tk.rocp(period))
        self.period = period


class ROCR(Indicator):
    """Rate of Change Ratio"""

    def __init__(self, period: int = 10) -> None:
        super().__init__(_tk.rocr(period))
        self.period = period


class ROCR100(Indicator):
    """Rate of Change Ratio * 100"""

    def __init__(self, period: int = 10) -> None:
        super().__init__(_tk.rocr100(period))
        self.period = period


class CCI(Indicator):
    """Commodity Channel Index"""

    def __init__(self, period: int = 20) -> None:
        super().__init__(_tk.cci(period))
        self.period = period

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


class ADX(Indicator):
    """Average Directional Index"""

    def __init__(self, period: int = 14) -> None:
        super().__init__(_tk.adx(period))
        self.period = period

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


class ADXR(Indicator):
    """Average Directional Index Rating"""

    def __init__(self, period: int = 14) -> None:
        super().__init__(_tk.adxr(period))
        self.period = period

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


class APO(Indicator):
    """Absolute Price Oscillator"""

    def __init__(self, fast: int = 12, slow: int = 26) -> None:
        super().__init__(_tk.apo(fast, slow))
        self.fast = fast
        self.slow = slow


class PPO(Indicator):
    """Percentage Price Oscillator"""

    def __init__(self, fast: int = 12, slow: int = 26) -> None:
        super().__init__(_tk.ppo(fast, slow))
        self.fast = fast
        self.slow = slow


class CMO(Indicator):
    """Chande Momentum Oscillator"""

    def __init__(self, period: int = 14) -> None:
        super().__init__(_tk.cmo(period))
        self.period = period


class DX(Indicator):
    """Directional Movement Index"""

    def __init__(self, period: int = 14) -> None:
        super().__init__(_tk.dx(period))
        self.period = period

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


class WILLR(Indicator):
    """Williams %R"""

    def __init__(self, period: int = 14) -> None:
        super().__init__(_tk.willr(period))
        self.period = period

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


class MFI(Indicator):
    """Money Flow Index"""

    def __init__(self, period: int = 14) -> None:
        super().__init__(_tk.mfi(period))
        self.period = period

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


class PLUS_DI(Indicator):
    """Plus Directional Indicator"""

    def __init__(self, period: int = 14) -> None:
        super().__init__(_tk.plus_di(period))
        self.period = period

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


class MINUS_DI(Indicator):
    """Minus Directional Indicator"""

    def __init__(self, period: int = 14) -> None:
        super().__init__(_tk.minus_di(period))
        self.period = period

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


class PLUS_DM(Indicator):
    """Plus Directional Movement"""

    def __init__(self, period: int = 14) -> None:
        super().__init__(_tk.plus_dm(period))
        self.period = period

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


class MINUS_DM(Indicator):
    """Minus Directional Movement"""

    def __init__(self, period: int = 14) -> None:
        super().__init__(_tk.minus_dm(period))
        self.period = period

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


class TRIX(Indicator):
    """Triple Exponential Average"""

    def __init__(self, period: int = 30) -> None:
        super().__init__(_tk.trix(period))
        self.period = period


class ULTOSC(Indicator):
    """Ultimate Oscillator"""

    def __init__(self, period1: int = 7, period2: int = 14, period3: int = 28) -> None:
        super().__init__(_tk.ultosc(period1, period2, period3))
        self.period1 = period1
        self.period2 = period2
        self.period3 = period3

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


class AROONOSC(Indicator):
    """Aroon Oscillator"""

    def __init__(self, period: int = 14) -> None:
        super().__init__(_tk.aroonosc(period))
        self.period = period

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


class BOP(Indicator):
    """Balance of Power"""

    def __init__(self) -> None:
        super().__init__(_tk.bop())

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


class MACD(Indicator):
    """Moving Average Convergence Divergence"""

    def __init__(self, fast: int = 12, slow: int = 26, signal: int = 9) -> None:
        self._indicator = _tk.macd(fast, slow, signal)
        self.fast = fast
        self.slow = slow
        self.signal_period = signal

    def update(self, value: float) -> _tk.MACDResult:
        """Update with single value, returns MACDResult"""
        return self._indicator.update_macd(value)

    def calculate(self, data: Union[np.ndarray, list]) -> MACDResult:
        """Calculate MACD for entire array"""
        arr = np.asarray(data, dtype=np.float64)
        macd, signal, hist = self._indicator.calculate_macd(arr)
        return MACDResult(macd, signal, hist)


class STOCH(Indicator):
    """Stochastic Oscillator"""

    def __init__(
        self, k_period: int = 14, k_slow: int = 3, d_period: int = 3
    ) -> None:
        self._indicator = _tk.stoch(k_period, k_slow, d_period)
        self.k_period = k_period
        self.k_slow = k_slow
        self.d_period = d_period

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> _tk.StochResult:
        """Update with OHLCV bar"""
        return self._indicator.update_stoch(open, high, low, close, volume)

    def calculate(
        self,
        high: np.ndarray,
        low: np.ndarray,
        close: np.ndarray,
    ) -> StochResult:
        """Calculate Stochastic for arrays"""
        h = np.asarray(high, dtype=np.float64)
        l = np.asarray(low, dtype=np.float64)
        c = np.asarray(close, dtype=np.float64)
        k, d = self._indicator.calculate_stoch(h, l, c)
        return StochResult(k, d)


class AROON(Indicator):
    """Aroon Indicator"""

    def __init__(self, period: int = 14) -> None:
        self._indicator = _tk.aroon(period)
        self.period = period

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> _tk.AroonResult:
        """Update with OHLCV bar"""
        return self._indicator.update_aroon(open, high, low, close, volume)

    def calculate(
        self,
        high: np.ndarray,
        low: np.ndarray,
    ) -> AroonResult:
        """Calculate Aroon for arrays"""
        h = np.asarray(high, dtype=np.float64)
        l = np.asarray(low, dtype=np.float64)
        up, down = self._indicator.calculate_aroon(h, l)
        return AroonResult(up, down)


# ============================================================
# Volatility Indicators
# ============================================================


class ATR(Indicator):
    """Average True Range"""

    def __init__(self, period: int = 14) -> None:
        super().__init__(_tk.atr(period))
        self.period = period

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)

    def calculate(  # type: ignore[override]
        self,
        open: np.ndarray,
        high: np.ndarray,
        low: np.ndarray,
        close: np.ndarray,
        volume: Optional[np.ndarray] = None,
    ) -> NDArray[np.float64]:
        """Calculate ATR for arrays"""
        o = np.asarray(open, dtype=np.float64)
        h = np.asarray(high, dtype=np.float64)
        l = np.asarray(low, dtype=np.float64)
        c = np.asarray(close, dtype=np.float64)
        v = np.zeros_like(c) if volume is None else np.asarray(volume, dtype=np.float64)
        return self._indicator.calculate_ohlcv(o, h, l, c, v)


class NATR(ATR):
    """Normalized Average True Range"""

    def __init__(self, period: int = 14) -> None:
        Indicator.__init__(self, _tk.natr(period))
        self.period = period


class TRANGE(Indicator):
    """True Range"""

    def __init__(self) -> None:
        super().__init__(_tk.trange())

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


class BBANDS(Indicator):
    """Bollinger Bands"""

    def __init__(
        self, period: int = 20, std_up: float = 2.0, std_dn: float = 2.0
    ) -> None:
        self._indicator = _tk.bbands(period, std_up, std_dn)
        self.period = period
        self.std_up = std_up
        self.std_dn = std_dn

    def update(self, value: float) -> _tk.BBandsResult:
        """Update with single value"""
        return self._indicator.update_bbands(value)

    def calculate(self, data: Union[np.ndarray, list]) -> BBandsResult:
        """Calculate Bollinger Bands for array"""
        arr = np.asarray(data, dtype=np.float64)
        upper, middle, lower = self._indicator.calculate_bbands(arr)
        return BBandsResult(upper, middle, lower)


# ============================================================
# Volume Indicators
# ============================================================


class OBV(Indicator):
    """On Balance Volume"""

    def __init__(self) -> None:
        super().__init__(_tk.obv())

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


class AD(Indicator):
    """Accumulation/Distribution"""

    def __init__(self) -> None:
        super().__init__(_tk.ad())

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


class ADOSC(Indicator):
    """A/D Oscillator"""

    def __init__(self, fast: int = 3, slow: int = 10) -> None:
        super().__init__(_tk.adosc(fast, slow))
        self.fast = fast
        self.slow = slow

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


# ============================================================
# Statistics
# ============================================================


class STDDEV(Indicator):
    """Standard Deviation"""

    def __init__(self, period: int = 5, nbdev: float = 1.0) -> None:
        super().__init__(_tk.stddev(period, nbdev))
        self.period = period
        self.nbdev = nbdev


class VAR(Indicator):
    """Variance"""

    def __init__(self, period: int = 5) -> None:
        super().__init__(_tk.var(period))
        self.period = period


class LINEARREG(Indicator):
    """Linear Regression"""

    def __init__(self, period: int = 14) -> None:
        super().__init__(_tk.linearreg(period))
        self.period = period


class LINEARREG_SLOPE(Indicator):
    """Linear Regression Slope"""

    def __init__(self, period: int = 14) -> None:
        super().__init__(_tk.linearreg_slope(period))
        self.period = period


class LINEARREG_INTERCEPT(Indicator):
    """Linear Regression Intercept"""

    def __init__(self, period: int = 14) -> None:
        super().__init__(_tk.linearreg_intercept(period))
        self.period = period


class LINEARREG_ANGLE(Indicator):
    """Linear Regression Angle"""

    def __init__(self, period: int = 14) -> None:
        super().__init__(_tk.linearreg_angle(period))
        self.period = period


class TSF(Indicator):
    """Time Series Forecast"""

    def __init__(self, period: int = 14) -> None:
        super().__init__(_tk.tsf(period))
        self.period = period


class BETA(Indicator):
    """Beta"""

    def __init__(self, period: int = 5) -> None:
        super().__init__(_tk.beta(period))
        self.period = period


class CORREL(Indicator):
    """Pearson Correlation"""

    def __init__(self, period: int = 30) -> None:
        super().__init__(_tk.correl(period))
        self.period = period


# ============================================================
# Price Transform
# ============================================================


class AVGPRICE(Indicator):
    """Average Price"""

    def __init__(self) -> None:
        super().__init__(_tk.avgprice())

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


class MEDPRICE(Indicator):
    """Median Price"""

    def __init__(self) -> None:
        super().__init__(_tk.medprice())

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


class TYPPRICE(Indicator):
    """Typical Price"""

    def __init__(self) -> None:
        super().__init__(_tk.typprice())

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


class WCLPRICE(Indicator):
    """Weighted Close Price"""

    def __init__(self) -> None:
        super().__init__(_tk.wclprice())

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


# ============================================================
# Math Operators
# ============================================================


class MAX(Indicator):
    """Highest Value over Period"""

    def __init__(self, period: int = 30) -> None:
        super().__init__(_tk.max(period))
        self.period = period


class MIN(Indicator):
    """Lowest Value over Period"""

    def __init__(self, period: int = 30) -> None:
        super().__init__(_tk.min(period))
        self.period = period


class SUM(Indicator):
    """Sum over Period"""

    def __init__(self, period: int = 30) -> None:
        super().__init__(_tk.sum(period))
        self.period = period


class MIDPOINT(Indicator):
    """Midpoint over Period"""

    def __init__(self, period: int = 14) -> None:
        super().__init__(_tk.midpoint(period))
        self.period = period


class MIDPRICE(Indicator):
    """Midpoint Price"""

    def __init__(self, period: int = 14) -> None:
        super().__init__(_tk.midprice(period))
        self.period = period

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


class MINMAX(Indicator):
    """Min and Max over Period"""

    def __init__(self, period: int = 30) -> None:
        self._indicator = _tk.minmax(period)
        self.period = period

    def update(self, value: float) -> _tk.MinMaxResult:
        """Update with single value"""
        return self._indicator.update_minmax(value)

    def calculate(self, data: Union[np.ndarray, list]) -> MinMaxResult:
        """Calculate MinMax for array"""
        arr = np.asarray(data, dtype=np.float64)
        min_arr, max_arr = self._indicator.calculate_minmax(arr)
        return MinMaxResult(min_arr, max_arr)


# ============================================================
# Hilbert Transform
# ============================================================


class HT_DCPERIOD(Indicator):
    """Hilbert Transform - Dominant Cycle Period"""

    def __init__(self) -> None:
        super().__init__(_tk.ht_dcperiod())


class HT_DCPHASE(Indicator):
    """Hilbert Transform - Dominant Cycle Phase"""

    def __init__(self) -> None:
        super().__init__(_tk.ht_dcphase())


class HT_TRENDMODE(Indicator):
    """Hilbert Transform - Trend vs Cycle Mode"""

    def __init__(self) -> None:
        super().__init__(_tk.ht_trendmode())


class HT_TRENDLINE(Indicator):
    """Hilbert Transform - Instantaneous Trendline"""

    def __init__(self) -> None:
        super().__init__(_tk.ht_trendline())


class HT_PHASOR(Indicator):
    """Hilbert Transform - Phasor Components"""

    def __init__(self) -> None:
        self._indicator = _tk.ht_phasor()

    def update(self, value: float) -> _tk.HTPhasorResult:
        """Update with single value"""
        return self._indicator.update_phasor(value)

    def calculate(
        self, data: Union[np.ndarray, list]
    ) -> tuple[NDArray[np.float64], NDArray[np.float64]]:
        """Calculate HT Phasor for array, returns (inphase, quadrature)"""
        arr = np.asarray(data, dtype=np.float64)
        return self._indicator.calculate_phasor(arr)


class HT_SINE(Indicator):
    """Hilbert Transform - Sine Wave"""

    def __init__(self) -> None:
        self._indicator = _tk.ht_sine()

    def update(self, value: float) -> _tk.HTSineResult:
        """Update with single value"""
        return self._indicator.update_sine(value)

    def calculate(
        self, data: Union[np.ndarray, list]
    ) -> tuple[NDArray[np.float64], NDArray[np.float64]]:
        """Calculate HT Sine for array, returns (sine, leadsine)"""
        arr = np.asarray(data, dtype=np.float64)
        return self._indicator.calculate_sine(arr)


# ============================================================
# Parabolic SAR
# ============================================================


class SAR(Indicator):
    """Parabolic SAR"""

    def __init__(self, acceleration: float = 0.02, maximum: float = 0.2) -> None:
        super().__init__(_tk.sar(acceleration, maximum))
        self.acceleration = acceleration
        self.maximum = maximum

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


# ============================================================
# Indicator Chain
# ============================================================


class Chain:
    """Chain multiple indicators together

    Example:
        # Smoothed RSI: RSI(14) -> EMA(9)
        chain = Chain([RSI(14), EMA(9)])
        smoothed_rsi = chain.calculate(prices)
    """

    def __init__(self, indicators: List[Indicator]) -> None:
        self.indicators = indicators

    def calculate(self, data: Union[np.ndarray, list]) -> NDArray[np.float64]:
        """Calculate chain: each indicator feeds into the next"""
        result = np.asarray(data, dtype=np.float64)
        for ind in self.indicators:
            ind.reset()
            result = ind.calculate(result)
        return result

    def update(self, value: float) -> IndicatorResult:
        """Update chain incrementally"""
        current = value
        for ind in self.indicators:
            r = ind.update(current)
            if not r.valid:
                return IndicatorResult(np.nan, False)
            current = r.value
        return IndicatorResult(current, True)

    def reset(self) -> None:
        """Reset all indicators in chain"""
        for ind in self.indicators:
            ind.reset()

