"""TechKit - High-performance technical analysis library

TechKit provides 189 technical indicators with:
- High performance (C++ core with pybind11)
- Both incremental (streaming) and batch calculation modes
- NumPy integration for efficient array operations
- TA-Lib compatible API for easy migration

Example usage:

    # OOP API (recommended)
    from techkit import SMA, RSI, MACD
    
    sma = SMA(period=20)
    result = sma.calculate(prices)  # Batch
    result = sma.update(price)      # Incremental
    
    # TA-Lib compatible API
    from techkit import talib_compat as ta
    
    sma = ta.SMA(prices, timeperiod=20)
    macd, signal, hist = ta.MACD(prices)
"""

# Version from setuptools_scm or fallback
try:
    from importlib.metadata import version as _get_version
    __version__ = _get_version("techkit")
except Exception:
    __version__ = "0.0.0.dev0"

from techkit._core import version, version_tuple
from techkit.indicators import (
    # Base
    Indicator,
    IndicatorResult,
    # Moving Averages
    SMA,
    EMA,
    WMA,
    DEMA,
    TEMA,
    KAMA,
    TRIMA,
    T3,
    # Momentum
    RSI,
    MACD,
    MOM,
    ROC,
    ROCP,
    ROCR,
    ROCR100,
    CCI,
    ADX,
    ADXR,
    APO,
    PPO,
    CMO,
    DX,
    WILLR,
    MFI,
    PLUS_DI,
    MINUS_DI,
    PLUS_DM,
    MINUS_DM,
    TRIX,
    ULTOSC,
    AROON,
    AROONOSC,
    BOP,
    STOCH,
    # Volatility
    ATR,
    NATR,
    TRANGE,
    BBANDS,
    # Volume
    OBV,
    AD,
    ADOSC,
    # Statistics
    STDDEV,
    VAR,
    LINEARREG,
    LINEARREG_SLOPE,
    LINEARREG_INTERCEPT,
    LINEARREG_ANGLE,
    TSF,
    BETA,
    CORREL,
    # Price Transform
    AVGPRICE,
    MEDPRICE,
    TYPPRICE,
    WCLPRICE,
    # Math
    MAX,
    MIN,
    SUM,
    MIDPOINT,
    MIDPRICE,
    MINMAX,
    # Hilbert Transform
    HT_DCPERIOD,
    HT_DCPHASE,
    HT_TRENDMODE,
    HT_TRENDLINE,
    HT_PHASOR,
    HT_SINE,
    # Parabolic SAR
    SAR,
    # Utility
    Chain,
    # Result types
    MACDResult,
    BBandsResult,
    StochResult,
    AroonResult,
)

__all__ = [
    # Version
    "__version__",
    "version",
    "version_tuple",
    # Base
    "Indicator",
    "IndicatorResult",
    # Moving Averages
    "SMA",
    "EMA",
    "WMA",
    "DEMA",
    "TEMA",
    "KAMA",
    "TRIMA",
    "T3",
    # Momentum
    "RSI",
    "MACD",
    "MOM",
    "ROC",
    "ROCP",
    "ROCR",
    "ROCR100",
    "CCI",
    "ADX",
    "ADXR",
    "APO",
    "PPO",
    "CMO",
    "DX",
    "WILLR",
    "MFI",
    "PLUS_DI",
    "MINUS_DI",
    "PLUS_DM",
    "MINUS_DM",
    "TRIX",
    "ULTOSC",
    "AROON",
    "AROONOSC",
    "BOP",
    "STOCH",
    # Volatility
    "ATR",
    "NATR",
    "TRANGE",
    "BBANDS",
    # Volume
    "OBV",
    "AD",
    "ADOSC",
    # Statistics
    "STDDEV",
    "VAR",
    "LINEARREG",
    "LINEARREG_SLOPE",
    "LINEARREG_INTERCEPT",
    "LINEARREG_ANGLE",
    "TSF",
    "BETA",
    "CORREL",
    # Price Transform
    "AVGPRICE",
    "MEDPRICE",
    "TYPPRICE",
    "WCLPRICE",
    # Math
    "MAX",
    "MIN",
    "SUM",
    "MIDPOINT",
    "MIDPRICE",
    "MINMAX",
    # Hilbert Transform
    "HT_DCPERIOD",
    "HT_DCPHASE",
    "HT_TRENDMODE",
    "HT_TRENDLINE",
    "HT_PHASOR",
    "HT_SINE",
    # Parabolic SAR
    "SAR",
    # Utility
    "Chain",
    # Result types
    "MACDResult",
    "BBandsResult",
    "StochResult",
    "AroonResult",
]
