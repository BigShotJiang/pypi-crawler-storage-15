"""TA-Lib compatible function API

This module provides drop-in replacement functions for TA-Lib.
Simply change your import from:
    import talib
to:
    from techkit import talib_compat as talib

And your existing code will work with TechKit.

Example:
    from techkit import talib_compat as ta
    
    sma = ta.SMA(close, timeperiod=20)
    macd, signal, hist = ta.MACD(close)
    upper, middle, lower = ta.BBANDS(close, timeperiod=20)
"""

from typing import Tuple, Union

import numpy as np
from numpy.typing import NDArray

import techkit._core as _tk


def _ensure_array(data: Union[np.ndarray, list]) -> NDArray[np.float64]:
    """Convert input to numpy array, handles pandas Series"""
    if hasattr(data, "values"):
        # pandas Series or DataFrame column
        return np.asarray(data.values, dtype=np.float64)
    return np.asarray(data, dtype=np.float64)


# ============================================================
# Overlap Studies (Moving Averages)
# ============================================================


def SMA(real: Union[np.ndarray, list], timeperiod: int = 30) -> NDArray[np.float64]:
    """Simple Moving Average"""
    return _tk.sma(timeperiod).calculate(_ensure_array(real))


def EMA(real: Union[np.ndarray, list], timeperiod: int = 30) -> NDArray[np.float64]:
    """Exponential Moving Average"""
    return _tk.ema(timeperiod).calculate(_ensure_array(real))


def WMA(real: Union[np.ndarray, list], timeperiod: int = 30) -> NDArray[np.float64]:
    """Weighted Moving Average"""
    return _tk.wma(timeperiod).calculate(_ensure_array(real))


def DEMA(real: Union[np.ndarray, list], timeperiod: int = 30) -> NDArray[np.float64]:
    """Double Exponential Moving Average"""
    return _tk.dema(timeperiod).calculate(_ensure_array(real))


def TEMA(real: Union[np.ndarray, list], timeperiod: int = 30) -> NDArray[np.float64]:
    """Triple Exponential Moving Average"""
    return _tk.tema(timeperiod).calculate(_ensure_array(real))


def KAMA(real: Union[np.ndarray, list], timeperiod: int = 30) -> NDArray[np.float64]:
    """Kaufman Adaptive Moving Average"""
    return _tk.kama(timeperiod).calculate(_ensure_array(real))


def TRIMA(real: Union[np.ndarray, list], timeperiod: int = 30) -> NDArray[np.float64]:
    """Triangular Moving Average"""
    return _tk.trima(timeperiod).calculate(_ensure_array(real))


def T3(
    real: Union[np.ndarray, list], timeperiod: int = 5, vfactor: float = 0.7
) -> NDArray[np.float64]:
    """T3 Moving Average"""
    return _tk.t3(timeperiod, vfactor).calculate(_ensure_array(real))


def BBANDS(
    real: Union[np.ndarray, list],
    timeperiod: int = 5,
    nbdevup: float = 2.0,
    nbdevdn: float = 2.0,
    matype: int = 0,
) -> Tuple[NDArray[np.float64], NDArray[np.float64], NDArray[np.float64]]:
    """Bollinger Bands

    Returns: (upper, middle, lower)
    """
    ind = _tk.bbands(timeperiod, nbdevup, nbdevdn)
    return ind.calculate_bbands(_ensure_array(real))


def MIDPOINT(real: Union[np.ndarray, list], timeperiod: int = 14) -> NDArray[np.float64]:
    """Midpoint over Period"""
    return _tk.midpoint(timeperiod).calculate(_ensure_array(real))


def MIDPRICE(
    high: Union[np.ndarray, list],
    low: Union[np.ndarray, list],
    timeperiod: int = 14,
) -> NDArray[np.float64]:
    """Midpoint Price over Period"""
    h = _ensure_array(high)
    l = _ensure_array(low)
    ind = _tk.midprice(timeperiod)
    
    size = len(h)
    result = np.empty(size)
    ind.reset()
    for i in range(size):
        r = ind.update_ohlcv(0, h[i], l[i], 0, 0)
        result[i] = r.value if r.valid else np.nan
    return result


def SAR(
    high: Union[np.ndarray, list],
    low: Union[np.ndarray, list],
    acceleration: float = 0.02,
    maximum: float = 0.2,
) -> NDArray[np.float64]:
    """Parabolic SAR"""
    h = _ensure_array(high)
    l = _ensure_array(low)
    ind = _tk.sar(acceleration, maximum)
    
    size = len(h)
    result = np.empty(size)
    ind.reset()
    for i in range(size):
        r = ind.update_ohlcv(0, h[i], l[i], 0, 0)
        result[i] = r.value if r.valid else np.nan
    return result


# ============================================================
# Momentum Indicators
# ============================================================


def RSI(real: Union[np.ndarray, list], timeperiod: int = 14) -> NDArray[np.float64]:
    """Relative Strength Index"""
    return _tk.rsi(timeperiod).calculate(_ensure_array(real))


def MOM(real: Union[np.ndarray, list], timeperiod: int = 10) -> NDArray[np.float64]:
    """Momentum"""
    return _tk.mom(timeperiod).calculate(_ensure_array(real))


def ROC(real: Union[np.ndarray, list], timeperiod: int = 10) -> NDArray[np.float64]:
    """Rate of Change"""
    return _tk.roc(timeperiod).calculate(_ensure_array(real))


def ROCP(real: Union[np.ndarray, list], timeperiod: int = 10) -> NDArray[np.float64]:
    """Rate of Change Percentage"""
    return _tk.rocp(timeperiod).calculate(_ensure_array(real))


def ROCR(real: Union[np.ndarray, list], timeperiod: int = 10) -> NDArray[np.float64]:
    """Rate of Change Ratio"""
    return _tk.rocr(timeperiod).calculate(_ensure_array(real))


def ROCR100(real: Union[np.ndarray, list], timeperiod: int = 10) -> NDArray[np.float64]:
    """Rate of Change Ratio * 100"""
    return _tk.rocr100(timeperiod).calculate(_ensure_array(real))


def APO(
    real: Union[np.ndarray, list], fastperiod: int = 12, slowperiod: int = 26, matype: int = 0
) -> NDArray[np.float64]:
    """Absolute Price Oscillator"""
    return _tk.apo(fastperiod, slowperiod).calculate(_ensure_array(real))


def PPO(
    real: Union[np.ndarray, list], fastperiod: int = 12, slowperiod: int = 26, matype: int = 0
) -> NDArray[np.float64]:
    """Percentage Price Oscillator"""
    return _tk.ppo(fastperiod, slowperiod).calculate(_ensure_array(real))


def CMO(real: Union[np.ndarray, list], timeperiod: int = 14) -> NDArray[np.float64]:
    """Chande Momentum Oscillator"""
    return _tk.cmo(timeperiod).calculate(_ensure_array(real))


def TRIX(real: Union[np.ndarray, list], timeperiod: int = 30) -> NDArray[np.float64]:
    """Triple Exponential Average"""
    return _tk.trix(timeperiod).calculate(_ensure_array(real))


def CCI(
    high: Union[np.ndarray, list],
    low: Union[np.ndarray, list],
    close: Union[np.ndarray, list],
    timeperiod: int = 14,
) -> NDArray[np.float64]:
    """Commodity Channel Index"""
    h = _ensure_array(high)
    l = _ensure_array(low)
    c = _ensure_array(close)
    ind = _tk.cci(timeperiod)

    size = len(c)
    result = np.empty(size)
    ind.reset()
    for i in range(size):
        r = ind.update_ohlcv(0, h[i], l[i], c[i], 0)
        result[i] = r.value if r.valid else np.nan
    return result


def MACD(
    real: Union[np.ndarray, list],
    fastperiod: int = 12,
    slowperiod: int = 26,
    signalperiod: int = 9,
) -> Tuple[NDArray[np.float64], NDArray[np.float64], NDArray[np.float64]]:
    """MACD

    Returns: (macd, signal, histogram)
    """
    ind = _tk.macd(fastperiod, slowperiod, signalperiod)
    return ind.calculate_macd(_ensure_array(real))


def ADX(
    high: Union[np.ndarray, list],
    low: Union[np.ndarray, list],
    close: Union[np.ndarray, list],
    timeperiod: int = 14,
) -> NDArray[np.float64]:
    """Average Directional Index"""
    h = _ensure_array(high)
    l = _ensure_array(low)
    c = _ensure_array(close)
    ind = _tk.adx(timeperiod)

    size = len(c)
    result = np.empty(size)
    ind.reset()
    for i in range(size):
        r = ind.update_ohlcv(0, h[i], l[i], c[i], 0)
        result[i] = r.value if r.valid else np.nan
    return result


def ADXR(
    high: Union[np.ndarray, list],
    low: Union[np.ndarray, list],
    close: Union[np.ndarray, list],
    timeperiod: int = 14,
) -> NDArray[np.float64]:
    """Average Directional Movement Index Rating"""
    h = _ensure_array(high)
    l = _ensure_array(low)
    c = _ensure_array(close)
    ind = _tk.adxr(timeperiod)

    size = len(c)
    result = np.empty(size)
    ind.reset()
    for i in range(size):
        r = ind.update_ohlcv(0, h[i], l[i], c[i], 0)
        result[i] = r.value if r.valid else np.nan
    return result


def DX(
    high: Union[np.ndarray, list],
    low: Union[np.ndarray, list],
    close: Union[np.ndarray, list],
    timeperiod: int = 14,
) -> NDArray[np.float64]:
    """Directional Movement Index"""
    h = _ensure_array(high)
    l = _ensure_array(low)
    c = _ensure_array(close)
    ind = _tk.dx(timeperiod)

    size = len(c)
    result = np.empty(size)
    ind.reset()
    for i in range(size):
        r = ind.update_ohlcv(0, h[i], l[i], c[i], 0)
        result[i] = r.value if r.valid else np.nan
    return result


def MINUS_DI(
    high: Union[np.ndarray, list],
    low: Union[np.ndarray, list],
    close: Union[np.ndarray, list],
    timeperiod: int = 14,
) -> NDArray[np.float64]:
    """Minus Directional Indicator"""
    h = _ensure_array(high)
    l = _ensure_array(low)
    c = _ensure_array(close)
    ind = _tk.minus_di(timeperiod)

    size = len(c)
    result = np.empty(size)
    ind.reset()
    for i in range(size):
        r = ind.update_ohlcv(0, h[i], l[i], c[i], 0)
        result[i] = r.value if r.valid else np.nan
    return result


def MINUS_DM(
    high: Union[np.ndarray, list],
    low: Union[np.ndarray, list],
    timeperiod: int = 14,
) -> NDArray[np.float64]:
    """Minus Directional Movement"""
    h = _ensure_array(high)
    l = _ensure_array(low)
    ind = _tk.minus_dm(timeperiod)

    size = len(h)
    result = np.empty(size)
    ind.reset()
    for i in range(size):
        r = ind.update_ohlcv(0, h[i], l[i], 0, 0)
        result[i] = r.value if r.valid else np.nan
    return result


def PLUS_DI(
    high: Union[np.ndarray, list],
    low: Union[np.ndarray, list],
    close: Union[np.ndarray, list],
    timeperiod: int = 14,
) -> NDArray[np.float64]:
    """Plus Directional Indicator"""
    h = _ensure_array(high)
    l = _ensure_array(low)
    c = _ensure_array(close)
    ind = _tk.plus_di(timeperiod)

    size = len(c)
    result = np.empty(size)
    ind.reset()
    for i in range(size):
        r = ind.update_ohlcv(0, h[i], l[i], c[i], 0)
        result[i] = r.value if r.valid else np.nan
    return result


def PLUS_DM(
    high: Union[np.ndarray, list],
    low: Union[np.ndarray, list],
    timeperiod: int = 14,
) -> NDArray[np.float64]:
    """Plus Directional Movement"""
    h = _ensure_array(high)
    l = _ensure_array(low)
    ind = _tk.plus_dm(timeperiod)

    size = len(h)
    result = np.empty(size)
    ind.reset()
    for i in range(size):
        r = ind.update_ohlcv(0, h[i], l[i], 0, 0)
        result[i] = r.value if r.valid else np.nan
    return result


def WILLR(
    high: Union[np.ndarray, list],
    low: Union[np.ndarray, list],
    close: Union[np.ndarray, list],
    timeperiod: int = 14,
) -> NDArray[np.float64]:
    """Williams %R"""
    h = _ensure_array(high)
    l = _ensure_array(low)
    c = _ensure_array(close)
    ind = _tk.willr(timeperiod)

    size = len(c)
    result = np.empty(size)
    ind.reset()
    for i in range(size):
        r = ind.update_ohlcv(0, h[i], l[i], c[i], 0)
        result[i] = r.value if r.valid else np.nan
    return result


def STOCH(
    high: Union[np.ndarray, list],
    low: Union[np.ndarray, list],
    close: Union[np.ndarray, list],
    fastk_period: int = 5,
    slowk_period: int = 3,
    slowk_matype: int = 0,
    slowd_period: int = 3,
    slowd_matype: int = 0,
) -> Tuple[NDArray[np.float64], NDArray[np.float64]]:
    """Stochastic

    Returns: (slowk, slowd)
    """
    h = _ensure_array(high)
    l = _ensure_array(low)
    c = _ensure_array(close)
    ind = _tk.stoch(fastk_period, slowk_period, slowd_period)
    return ind.calculate_stoch(h, l, c)


def AROON(
    high: Union[np.ndarray, list],
    low: Union[np.ndarray, list],
    timeperiod: int = 14,
) -> Tuple[NDArray[np.float64], NDArray[np.float64]]:
    """Aroon

    Returns: (aroondown, aroonup)
    Note: TA-Lib returns (down, up), TechKit returns (up, down)
    """
    h = _ensure_array(high)
    l = _ensure_array(low)
    ind = _tk.aroon(timeperiod)
    up, down = ind.calculate_aroon(h, l)
    return down, up  # TA-Lib order: down, up


def AROONOSC(
    high: Union[np.ndarray, list],
    low: Union[np.ndarray, list],
    timeperiod: int = 14,
) -> NDArray[np.float64]:
    """Aroon Oscillator"""
    h = _ensure_array(high)
    l = _ensure_array(low)
    ind = _tk.aroonosc(timeperiod)

    size = len(h)
    result = np.empty(size)
    ind.reset()
    for i in range(size):
        r = ind.update_ohlcv(0, h[i], l[i], 0, 0)
        result[i] = r.value if r.valid else np.nan
    return result


def BOP(
    open_: Union[np.ndarray, list],
    high: Union[np.ndarray, list],
    low: Union[np.ndarray, list],
    close: Union[np.ndarray, list],
) -> NDArray[np.float64]:
    """Balance of Power"""
    o = _ensure_array(open_)
    h = _ensure_array(high)
    l = _ensure_array(low)
    c = _ensure_array(close)
    ind = _tk.bop()

    size = len(c)
    result = np.empty(size)
    ind.reset()
    for i in range(size):
        r = ind.update_ohlcv(o[i], h[i], l[i], c[i], 0)
        result[i] = r.value if r.valid else np.nan
    return result


def MFI(
    high: Union[np.ndarray, list],
    low: Union[np.ndarray, list],
    close: Union[np.ndarray, list],
    volume: Union[np.ndarray, list],
    timeperiod: int = 14,
) -> NDArray[np.float64]:
    """Money Flow Index"""
    h = _ensure_array(high)
    l = _ensure_array(low)
    c = _ensure_array(close)
    v = _ensure_array(volume)
    ind = _tk.mfi(timeperiod)

    size = len(c)
    result = np.empty(size)
    ind.reset()
    for i in range(size):
        r = ind.update_ohlcv(0, h[i], l[i], c[i], v[i])
        result[i] = r.value if r.valid else np.nan
    return result


def ULTOSC(
    high: Union[np.ndarray, list],
    low: Union[np.ndarray, list],
    close: Union[np.ndarray, list],
    timeperiod1: int = 7,
    timeperiod2: int = 14,
    timeperiod3: int = 28,
) -> NDArray[np.float64]:
    """Ultimate Oscillator"""
    h = _ensure_array(high)
    l = _ensure_array(low)
    c = _ensure_array(close)
    ind = _tk.ultosc(timeperiod1, timeperiod2, timeperiod3)

    size = len(c)
    result = np.empty(size)
    ind.reset()
    for i in range(size):
        r = ind.update_ohlcv(0, h[i], l[i], c[i], 0)
        result[i] = r.value if r.valid else np.nan
    return result


# ============================================================
# Volatility Indicators
# ============================================================


def ATR(
    high: Union[np.ndarray, list],
    low: Union[np.ndarray, list],
    close: Union[np.ndarray, list],
    timeperiod: int = 14,
) -> NDArray[np.float64]:
    """Average True Range"""
    h = _ensure_array(high)
    l = _ensure_array(low)
    c = _ensure_array(close)
    o = np.zeros_like(c)
    v = np.zeros_like(c)
    return _tk.atr(timeperiod).calculate_ohlcv(o, h, l, c, v)


def NATR(
    high: Union[np.ndarray, list],
    low: Union[np.ndarray, list],
    close: Union[np.ndarray, list],
    timeperiod: int = 14,
) -> NDArray[np.float64]:
    """Normalized Average True Range"""
    h = _ensure_array(high)
    l = _ensure_array(low)
    c = _ensure_array(close)
    o = np.zeros_like(c)
    v = np.zeros_like(c)
    return _tk.natr(timeperiod).calculate_ohlcv(o, h, l, c, v)


def TRANGE(
    high: Union[np.ndarray, list],
    low: Union[np.ndarray, list],
    close: Union[np.ndarray, list],
) -> NDArray[np.float64]:
    """True Range"""
    h = _ensure_array(high)
    l = _ensure_array(low)
    c = _ensure_array(close)
    o = np.zeros_like(c)
    v = np.zeros_like(c)
    return _tk.trange().calculate_ohlcv(o, h, l, c, v)


# ============================================================
# Volume Indicators
# ============================================================


def OBV(
    close: Union[np.ndarray, list],
    volume: Union[np.ndarray, list],
) -> NDArray[np.float64]:
    """On Balance Volume"""
    c = _ensure_array(close)
    v = _ensure_array(volume)
    ind = _tk.obv()

    size = len(c)
    result = np.empty(size)
    ind.reset()
    for i in range(size):
        r = ind.update_ohlcv(0, 0, 0, c[i], v[i])
        result[i] = r.value if r.valid else np.nan
    return result


def AD(
    high: Union[np.ndarray, list],
    low: Union[np.ndarray, list],
    close: Union[np.ndarray, list],
    volume: Union[np.ndarray, list],
) -> NDArray[np.float64]:
    """Accumulation/Distribution"""
    h = _ensure_array(high)
    l = _ensure_array(low)
    c = _ensure_array(close)
    v = _ensure_array(volume)
    ind = _tk.ad()

    size = len(c)
    result = np.empty(size)
    ind.reset()
    for i in range(size):
        r = ind.update_ohlcv(0, h[i], l[i], c[i], v[i])
        result[i] = r.value if r.valid else np.nan
    return result


def ADOSC(
    high: Union[np.ndarray, list],
    low: Union[np.ndarray, list],
    close: Union[np.ndarray, list],
    volume: Union[np.ndarray, list],
    fastperiod: int = 3,
    slowperiod: int = 10,
) -> NDArray[np.float64]:
    """A/D Oscillator"""
    h = _ensure_array(high)
    l = _ensure_array(low)
    c = _ensure_array(close)
    v = _ensure_array(volume)
    ind = _tk.adosc(fastperiod, slowperiod)

    size = len(c)
    result = np.empty(size)
    ind.reset()
    for i in range(size):
        r = ind.update_ohlcv(0, h[i], l[i], c[i], v[i])
        result[i] = r.value if r.valid else np.nan
    return result


# ============================================================
# Statistics
# ============================================================


def STDDEV(
    real: Union[np.ndarray, list], timeperiod: int = 5, nbdev: float = 1.0
) -> NDArray[np.float64]:
    """Standard Deviation"""
    return _tk.stddev(timeperiod, nbdev).calculate(_ensure_array(real))


def VAR(
    real: Union[np.ndarray, list], timeperiod: int = 5, nbdev: float = 1.0
) -> NDArray[np.float64]:
    """Variance"""
    result = _tk.var(timeperiod).calculate(_ensure_array(real))
    return result * nbdev


def LINEARREG(real: Union[np.ndarray, list], timeperiod: int = 14) -> NDArray[np.float64]:
    """Linear Regression"""
    return _tk.linearreg(timeperiod).calculate(_ensure_array(real))


def LINEARREG_SLOPE(real: Union[np.ndarray, list], timeperiod: int = 14) -> NDArray[np.float64]:
    """Linear Regression Slope"""
    return _tk.linearreg_slope(timeperiod).calculate(_ensure_array(real))


def LINEARREG_INTERCEPT(
    real: Union[np.ndarray, list], timeperiod: int = 14
) -> NDArray[np.float64]:
    """Linear Regression Intercept"""
    return _tk.linearreg_intercept(timeperiod).calculate(_ensure_array(real))


def LINEARREG_ANGLE(real: Union[np.ndarray, list], timeperiod: int = 14) -> NDArray[np.float64]:
    """Linear Regression Angle"""
    return _tk.linearreg_angle(timeperiod).calculate(_ensure_array(real))


def TSF(real: Union[np.ndarray, list], timeperiod: int = 14) -> NDArray[np.float64]:
    """Time Series Forecast"""
    return _tk.tsf(timeperiod).calculate(_ensure_array(real))


def CORREL(
    real0: Union[np.ndarray, list],
    real1: Union[np.ndarray, list],
    timeperiod: int = 30,
) -> NDArray[np.float64]:
    """Pearson's Correlation Coefficient"""
    r0 = _ensure_array(real0)
    r1 = _ensure_array(real1)
    ind = _tk.correl(timeperiod)

    size = len(r0)
    result = np.empty(size)
    ind.reset()
    # Note: CORREL needs dual input - this is a simplified implementation
    # For full compatibility, would need tk_correl_update with two values
    for i in range(size):
        result[i] = np.nan  # Placeholder - needs proper implementation
    return result


def BETA(
    real0: Union[np.ndarray, list],
    real1: Union[np.ndarray, list],
    timeperiod: int = 5,
) -> NDArray[np.float64]:
    """Beta"""
    r0 = _ensure_array(real0)
    r1 = _ensure_array(real1)
    ind = _tk.beta(timeperiod)

    size = len(r0)
    result = np.empty(size)
    ind.reset()
    # Note: BETA needs dual input - this is a simplified implementation
    for i in range(size):
        result[i] = np.nan  # Placeholder - needs proper implementation
    return result


# ============================================================
# Price Transform
# ============================================================


def AVGPRICE(
    open_: Union[np.ndarray, list],
    high: Union[np.ndarray, list],
    low: Union[np.ndarray, list],
    close: Union[np.ndarray, list],
) -> NDArray[np.float64]:
    """Average Price"""
    o = _ensure_array(open_)
    h = _ensure_array(high)
    l = _ensure_array(low)
    c = _ensure_array(close)
    v = np.zeros_like(c)
    return _tk.avgprice().calculate_ohlcv(o, h, l, c, v)


def MEDPRICE(
    high: Union[np.ndarray, list],
    low: Union[np.ndarray, list],
) -> NDArray[np.float64]:
    """Median Price"""
    h = _ensure_array(high)
    l = _ensure_array(low)
    o = np.zeros_like(h)
    c = np.zeros_like(h)
    v = np.zeros_like(h)
    return _tk.medprice().calculate_ohlcv(o, h, l, c, v)


def TYPPRICE(
    high: Union[np.ndarray, list],
    low: Union[np.ndarray, list],
    close: Union[np.ndarray, list],
) -> NDArray[np.float64]:
    """Typical Price"""
    h = _ensure_array(high)
    l = _ensure_array(low)
    c = _ensure_array(close)
    o = np.zeros_like(c)
    v = np.zeros_like(c)
    return _tk.typprice().calculate_ohlcv(o, h, l, c, v)


def WCLPRICE(
    high: Union[np.ndarray, list],
    low: Union[np.ndarray, list],
    close: Union[np.ndarray, list],
) -> NDArray[np.float64]:
    """Weighted Close Price"""
    h = _ensure_array(high)
    l = _ensure_array(low)
    c = _ensure_array(close)
    o = np.zeros_like(c)
    v = np.zeros_like(c)
    return _tk.wclprice().calculate_ohlcv(o, h, l, c, v)


# ============================================================
# Math Operators
# ============================================================


def MAX(real: Union[np.ndarray, list], timeperiod: int = 30) -> NDArray[np.float64]:
    """Highest value over a specified period"""
    return _tk.max(timeperiod).calculate(_ensure_array(real))


def MIN(real: Union[np.ndarray, list], timeperiod: int = 30) -> NDArray[np.float64]:
    """Lowest value over a specified period"""
    return _tk.min(timeperiod).calculate(_ensure_array(real))


def SUM(real: Union[np.ndarray, list], timeperiod: int = 30) -> NDArray[np.float64]:
    """Sum over a specified period"""
    return _tk.sum(timeperiod).calculate(_ensure_array(real))


def MINMAX(
    real: Union[np.ndarray, list], timeperiod: int = 30
) -> Tuple[NDArray[np.float64], NDArray[np.float64]]:
    """Lowest and Highest values over a specified period

    Returns: (min, max)
    """
    ind = _tk.minmax(timeperiod)
    return ind.calculate_minmax(_ensure_array(real))


# ============================================================
# Hilbert Transform
# ============================================================


def HT_DCPERIOD(real: Union[np.ndarray, list]) -> NDArray[np.float64]:
    """Hilbert Transform - Dominant Cycle Period"""
    return _tk.ht_dcperiod().calculate(_ensure_array(real))


def HT_DCPHASE(real: Union[np.ndarray, list]) -> NDArray[np.float64]:
    """Hilbert Transform - Dominant Cycle Phase"""
    return _tk.ht_dcphase().calculate(_ensure_array(real))


def HT_TRENDMODE(real: Union[np.ndarray, list]) -> NDArray[np.float64]:
    """Hilbert Transform - Trend vs Cycle Mode"""
    return _tk.ht_trendmode().calculate(_ensure_array(real))


def HT_TRENDLINE(real: Union[np.ndarray, list]) -> NDArray[np.float64]:
    """Hilbert Transform - Instantaneous Trendline"""
    return _tk.ht_trendline().calculate(_ensure_array(real))


def HT_PHASOR(
    real: Union[np.ndarray, list],
) -> Tuple[NDArray[np.float64], NDArray[np.float64]]:
    """Hilbert Transform - Phasor Components

    Returns: (inphase, quadrature)
    """
    ind = _tk.ht_phasor()
    return ind.calculate_phasor(_ensure_array(real))


def HT_SINE(
    real: Union[np.ndarray, list],
) -> Tuple[NDArray[np.float64], NDArray[np.float64]]:
    """Hilbert Transform - SineWave

    Returns: (sine, leadsine)
    """
    ind = _tk.ht_sine()
    return ind.calculate_sine(_ensure_array(real))

