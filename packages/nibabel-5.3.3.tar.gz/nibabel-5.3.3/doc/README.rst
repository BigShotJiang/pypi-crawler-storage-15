#####################
Nibabel documentation
#####################

To build the documentation, change to the root directory (containing
``pyproject.toml``) and run::

    pip install -r doc-requirements.txt
    make -C doc html
