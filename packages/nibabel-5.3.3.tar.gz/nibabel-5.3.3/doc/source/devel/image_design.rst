:orphan:

########################
The nibabel image object
########################

The latest version of this page is now at :doc:`../nibabel_images`.
