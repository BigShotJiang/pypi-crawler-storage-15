"""
AsyncAPI client code generator for chanx.

This module provides tools to generate type-safe WebSocket client code
from AsyncAPI 3.0 schemas.
"""
