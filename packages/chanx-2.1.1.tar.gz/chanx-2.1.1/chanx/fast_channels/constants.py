"""Constants definition of fast_channels ext"""

ASYNCAPI_TITLE_POSTFIX = " AsyncAPI documentation"
