.. SPDX-License-Identifier: GPL-3.0-or-later
.. FileType: DOCUMENTATION
.. FileCopyrightText: 2025, GFZ Helmholtz Centre for Geosciences
.. FileCopyrightText: 2025, Daniel Scheffler (danschef@gfz.de)



.. _usage:

Usage
=====


To use EnFROSP EnMAP-Box-App in a project::

    import enfrosp_enmapboxapp

----
