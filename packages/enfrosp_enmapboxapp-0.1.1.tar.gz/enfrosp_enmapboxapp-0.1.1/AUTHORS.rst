.. SPDX-License-Identifier: GPL-3.0-or-later
.. FileType: DOCUMENTATION
.. FileCopyrightText: 2025, GFZ Helmholtz Centre for Geosciences, Daniel Scheffler (danschef@gfz.de)



=======
Credits
=======

Development Lead
----------------

* Daniel Scheffler <daniel.scheffler@gfz.de>

Contributors
------------

None yet. Why not be the first?
