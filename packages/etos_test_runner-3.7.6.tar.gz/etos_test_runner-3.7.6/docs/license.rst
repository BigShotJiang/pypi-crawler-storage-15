.. _license:

=======
License
=======

.. literalinclude:: ../LICENSE.txt
