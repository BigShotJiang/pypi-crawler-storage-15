class AbstractMethodException(Exception):
    pass
