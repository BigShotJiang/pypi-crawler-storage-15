"""Version information for caca-transformers"""

__version__ = "1.1.0"
__author__ = "Lyon"
__email__ = "cacatransformers@gmail.com"
__description__ = "Modern Transformer Architecture with GQA, RoPE, SwiGLU & Flash Attention"
__url__ = "https://github.com/Lyon-28/caca-transformers"
__license__ = "Apache-2.0"
