__version__ = "2025.12.3"
__prog__ = "webscout"
