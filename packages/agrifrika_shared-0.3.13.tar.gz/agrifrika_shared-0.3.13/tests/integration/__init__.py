"""Integration tests for agrifrika-shared package."""
