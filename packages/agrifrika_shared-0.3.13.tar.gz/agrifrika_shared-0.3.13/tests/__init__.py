"""Test suite for agrifrika-shared package."""
