"""
Agrifrika Shared Package

Shared utilities, models, and AWS clients for all Agrifrika microservices.
"""

__version__ = "0.3.9"
