"""Cache management for GrepMap."""

from grepmap.cache.manager import CacheManager

__all__ = ['CacheManager']
