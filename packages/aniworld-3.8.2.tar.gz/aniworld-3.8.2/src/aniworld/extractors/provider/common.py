# This should contain common functions between providers in future
