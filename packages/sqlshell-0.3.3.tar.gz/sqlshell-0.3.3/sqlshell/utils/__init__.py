"""
Utility functions for SQLShell
"""

# Import profile_entropy for convenient access
from sqlshell.utils.profile_entropy import profile, visualize_profile, EntropyProfiler

# Empty init file to make the directory a package 