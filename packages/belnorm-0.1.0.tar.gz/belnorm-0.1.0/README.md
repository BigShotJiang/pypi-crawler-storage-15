Belarusian Text Normalization Library
=====================================

This library provides tools for preparing Belarusian text for Text-to-Speech (TTS) applications. Key features include:

- Splitting text into sentences
- Normalizing numbers and abbreviations
- Handling common Belarusian contractions and special symbols

Designed for easy integration, this library helps ensure that text is correctly formatted and pronounced by TTS systems.
