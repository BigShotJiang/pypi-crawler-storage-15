from .splitter import BelSplitter

__all__ = ["BelSplitter"]
