import stanza
from stanza.pipeline.core import DownloadMethod


class SentenceInfo:
    def __init__(self, sentence):
        self._sentence = sentence

    @property
    def text(self) -> str:
        """ Access the list of sentences for this document. """
        return self._sentence.text

    ALLOWED_CHARS = set("ёйцукенгшўзхфывапролджэячсмітьбюЁЙЦУКЕНГШЎЗХФЫВАПРОЛДЖЭЯЧСМІТЬБЮґ-‒'’")
    KNOWN_ISSUES = ["?!."]

    def is_normalized(self) -> bool:
        return not self.debug_notnormalized()

    def debug_notnormalized(self) -> str:
        for word in self._sentence.words:
            if word.upos == 'PUNCT' or word.upos == 'SYM':  # TODO : праверыць SYM
                continue  # пунктуацыю не правяраем
            if any(char not in self.ALLOWED_CHARS for char in word.text):
                if word.text not in self.KNOWN_ISSUES:
                    return word.text
        return None

    def __repr__(self) -> str:
        return f"Sentence({self._sentence.text}, normalized={self.is_normalized()})"


class BelSplitter:
    # Перадавайце check_normalized=True калі вы збіраецеся правяраць словы на is_normalized.
    # Калі проста падзяліць на сказы - check_normalized=True будзе працаваць разы ў тры хутчэй
    def __init__(self, check_normalized: bool = True):
        if check_normalized:
            self.nlp = stanza.Pipeline('be', processors='tokenize,pos', download_method=DownloadMethod.REUSE_RESOURCES)
        else:
            self.nlp = stanza.Pipeline('be', processors='tokenize', download_method=DownloadMethod.REUSE_RESOURCES)

    # Splits text to separate sentences
    # text - array of paragraphs
    # result - paragraphs contains sentences
    def parse(self, paragraphs: list[str]) -> list[list[SentenceInfo]]:
        result_paragraphs = self.nlp.bulk_process(paragraphs)
        # print(result_paragraphs)
        return [[SentenceInfo(s) for s in p.sentences] for p in result_paragraphs]
