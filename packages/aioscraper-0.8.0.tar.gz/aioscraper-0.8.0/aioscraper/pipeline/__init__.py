from .base import BasePipeline

__all__ = ("BasePipeline",)
