__title__ = "aioscraper"

__author__ = "darkstussy"

__copyright__ = f"Copyright (c) 2025 {__author__}"

from .scraper import AIOScraper, run_scraper

__all__ = ("AIOScraper", "run_scraper")
