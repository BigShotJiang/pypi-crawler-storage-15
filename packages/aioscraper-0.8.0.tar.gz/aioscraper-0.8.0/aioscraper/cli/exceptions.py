class CLIError(Exception):
    "Raised when CLI arguments are invalid or cannot be resolved."
