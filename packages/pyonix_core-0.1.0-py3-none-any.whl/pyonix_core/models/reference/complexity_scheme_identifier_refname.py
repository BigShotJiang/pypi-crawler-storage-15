from enum import Enum

__NAMESPACE__ = "http://ns.editeur.org/onix/3.0/reference"


class ComplexitySchemeIdentifierRefname(Enum):
    COMPLEXITY_SCHEME_IDENTIFIER = "ComplexitySchemeIdentifier"
