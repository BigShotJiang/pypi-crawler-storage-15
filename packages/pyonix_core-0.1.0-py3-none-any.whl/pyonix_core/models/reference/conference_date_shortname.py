from enum import Enum

__NAMESPACE__ = "http://ns.editeur.org/onix/3.0/reference"


class ConferenceDateShortname(Enum):
    B054 = "b054"
