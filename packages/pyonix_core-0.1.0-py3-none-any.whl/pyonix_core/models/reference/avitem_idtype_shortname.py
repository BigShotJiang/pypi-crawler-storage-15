from enum import Enum

__NAMESPACE__ = "http://ns.editeur.org/onix/3.0/reference"


class AvitemIdtypeShortname(Enum):
    X541 = "x541"
