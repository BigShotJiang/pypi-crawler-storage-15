from enum import Enum

__NAMESPACE__ = "http://ns.editeur.org/onix/3.0/reference"


class AudienceCodeTypeNameRefname(Enum):
    AUDIENCE_CODE_TYPE_NAME = "AudienceCodeTypeName"
