from enum import Enum

__NAMESPACE__ = "http://ns.editeur.org/onix/3.0/reference"


class BibleContentsShortname(Enum):
    B352 = "b352"
