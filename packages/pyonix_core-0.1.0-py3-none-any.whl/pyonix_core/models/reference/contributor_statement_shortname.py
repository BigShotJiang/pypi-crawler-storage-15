from enum import Enum

__NAMESPACE__ = "http://ns.editeur.org/onix/3.0/reference"


class ContributorStatementShortname(Enum):
    B049 = "b049"
