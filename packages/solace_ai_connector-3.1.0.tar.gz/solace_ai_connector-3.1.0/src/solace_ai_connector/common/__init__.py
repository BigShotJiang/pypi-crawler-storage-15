# Directory for all common code
from solace.messaging.config.message_acknowledgement_configuration import Outcome as Message_NACK_Outcome
