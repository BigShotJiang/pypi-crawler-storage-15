"""Unit tests for the messaging module."""
