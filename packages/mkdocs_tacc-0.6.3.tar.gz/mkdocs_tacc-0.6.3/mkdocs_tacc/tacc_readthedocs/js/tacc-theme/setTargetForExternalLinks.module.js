import findLinksAndSetTargets from 'https://cdn.jsdelivr.net/gh/TACC/Core-CMS@v4.25.4/taccsite_cms/static/site_cms/js/modules/setTargetForExternalLinks.js';

findLinksAndSetTargets( document.querySelectorAll('a') );
