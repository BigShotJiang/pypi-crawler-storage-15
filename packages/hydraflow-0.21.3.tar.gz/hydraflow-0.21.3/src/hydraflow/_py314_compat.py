# pyright: reportAttributeAccessIssue=false
# pyright: reportUnknownLambdaType=false
# pyright: reportUnknownMemberType=false
# pyright: reportUnknownVariableType=false
# pyright: reportUnreachable=false

# The following code is copied from `hydra-zen` (https://github.com/mit-ll-responsible-ai/hydra-zen)
# which is licensed under the MIT license.
#
# Copyright (c) 2025 Massachusetts Institute of Technology
# SPDX-License-Identifier: MIT
"""Python 3.14 compatibility patches for Hydra.

This module contains patches to fix compatibility issues with Hydra on Python 3.14.
Must be imported before any Hydra imports occur.
"""

from __future__ import annotations

import sys


def apply_hydra_argparse_patch() -> None:  # pragma: no cover
    """Apply Python 3.14 compatibility patch for Hydra's argparse usage.

    Python 3.14 added validation in argparse._check_help that checks if '%'
    is in the help string. Hydra's LazyCompletionHelp object doesn't support
    the 'in' operator, causing a TypeError during argument parser creation.

    This patch temporarily disables the validation during Hydra's parser
    creation, then immediately restores it. This is safe because:
    1. The validation is purely for catching developer errors early
    2. It's new in Python 3.14 (didn't exist in earlier versions)
    3. Hydra's help strings work correctly when actually displayed
    4. We restore normal behavior immediately after
    """
    if sys.version_info < (3, 14):
        return

    try:
        import argparse
        from functools import wraps

        from hydra._internal import utils as hydra_utils

        original_get_args_parser = hydra_utils.get_args_parser
        original_check_help = argparse.ArgumentParser._check_help

        @wraps(original_get_args_parser)
        def patched_get_args_parser():  # type: ignore
            """Patched version that disables help validation during parser creation."""
            argparse.ArgumentParser._check_help = lambda self, action: None
            try:
                return original_get_args_parser()
            finally:
                argparse.ArgumentParser._check_help = original_check_help

        hydra_utils.get_args_parser = patched_get_args_parser

        if "hydra.main" in sys.modules:
            sys.modules["hydra.main"].get_args_parser = patched_get_args_parser

    except (ImportError, AttributeError):
        pass
