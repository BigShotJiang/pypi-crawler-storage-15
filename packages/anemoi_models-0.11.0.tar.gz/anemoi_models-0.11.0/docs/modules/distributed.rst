#############
 Distributed
#############

*******
 graph
*******

.. automodule:: anemoi.models.distributed.graph
   :members:
   :no-undoc-members:
   :show-inheritance:

************
 khop_edges
************

.. automodule:: anemoi.models.distributed.khop_edges
   :members:
   :no-undoc-members:
   :show-inheritance:

..
   *************

..
   primitives

..
   *************

..
   .. automodule:: anemoi.models.distributed.primitives

..
   :members:

..
   :no-undoc-members:

..
   :show-inheritance:

********
 shapes
********

.. automodule:: anemoi.models.distributed.shapes
   :members:
   :no-undoc-members:
   :show-inheritance:

*************
 transformer
*************

.. automodule:: anemoi.models.distributed.transformer
   :members:
   :no-undoc-members:
   :show-inheritance:

*******
 utils
*******

.. automodule:: anemoi.models.distributed.utils
   :members:
   :no-undoc-members:
   :show-inheritance:
