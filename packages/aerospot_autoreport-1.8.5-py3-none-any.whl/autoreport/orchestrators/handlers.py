"""编排器阶段处理器适配器 - Stage 5 集成

为现有的编排器（ResourceAndDataOrchestrator、DataProcessingOrchestrator等）
创建StageHandler适配器，使其能够与StageOrchestrator和PipelineV2集成。
"""

from typing import Any, Dict, Optional
from autoreport.orchestrators.stage import (
    StageHandler,
    StageHandlerContext,
    StageHandlerResult,
)
from autoreport.orchestrators.execution_modes.base import ExecutionContext


class ResourceAndDataOrchestratorHandler(StageHandler):
    """资源和数据编排器处理器适配器"""

    def __init__(self, orchestrator_instance: Any):
        """初始化适配器

        Args:
            orchestrator_instance: ResourceAndDataOrchestrator 实例
        """
        super().__init__("resource_and_data_orchestrator")
        self.orchestrator = orchestrator_instance

    def execute(self, context: StageHandlerContext) -> StageHandlerResult:
        """执行资源和数据处理

        Args:
            context: 处理器执行上下文

        Returns:
            StageHandlerResult: 执行结果
        """
        try:
            generator = context.get_data("generator")
            if not generator:
                return StageHandlerResult(
                    success=False,
                    message="生成器未在上下文中设置",
                )

            # 执行编排器
            result = self.orchestrator.orchestrate(generator)

            if not result:
                return StageHandlerResult(
                    success=False,
                    message="资源和数据处理失败",
                )

            # 保存处理结果到上下文
            context.set_data("resource_data", {
                "success": True,
                "orchestrator": self.orchestrator,
            })

            return StageHandlerResult(
                success=True,
                message="资源和数据处理成功",
                data={"orchestrator": self.orchestrator},
            )

        except Exception as e:
            self.logger.error(f"资源和数据处理异常: {str(e)}", exc_info=True)
            return StageHandlerResult(
                success=False,
                message=f"资源和数据处理异常: {str(e)}",
                error=e,
            )

    def validate(self, context: StageHandlerContext) -> bool:
        """验证执行条件

        Args:
            context: 处理器执行上下文

        Returns:
            bool: 验证是否通过
        """
        generator = context.get_data("generator")
        if not generator:
            self.logger.error("生成器未在上下文中设置")
            return False
        return True


class DataProcessingOrchestratorHandler(StageHandler):
    """数据处理编排器处理器适配器"""

    def __init__(self, orchestrator_instance: Any):
        """初始化适配器

        Args:
            orchestrator_instance: DataProcessingOrchestrator 实例
        """
        super().__init__("data_processing_orchestrator")
        self.orchestrator = orchestrator_instance

    def execute(self, context: StageHandlerContext) -> StageHandlerResult:
        """执行数据处理

        Args:
            context: 处理器执行上下文

        Returns:
            StageHandlerResult: 执行结果
        """
        try:
            generator = context.get_data("generator")
            if not generator:
                return StageHandlerResult(
                    success=False,
                    message="生成器未在上下文中设置",
                )

            # 执行数据处理
            result = self.orchestrator.process(generator.report_data)

            if not result:
                return StageHandlerResult(
                    success=False,
                    message="数据处理失败",
                )

            return StageHandlerResult(
                success=True,
                message="数据处理成功",
                data={"processed_data": result},
            )

        except Exception as e:
            self.logger.error(f"数据处理异常: {str(e)}", exc_info=True)
            return StageHandlerResult(
                success=False,
                message=f"数据处理异常: {str(e)}",
                error=e,
            )

    def validate(self, context: StageHandlerContext) -> bool:
        """验证执行条件"""
        generator = context.get_data("generator")
        if not generator:
            self.logger.error("生成器未在上下文中设置")
            return False
        return True


class MapGenerationOrchestratorHandler(StageHandler):
    """地图生成编排器处理器适配器"""

    def __init__(self, orchestrator_instance: Any):
        """初始化适配器

        Args:
            orchestrator_instance: MapGenerationOrchestrator 实例
        """
        super().__init__("map_generation_orchestrator")
        self.orchestrator = orchestrator_instance

    def execute(self, context: StageHandlerContext) -> StageHandlerResult:
        """执行地图生成

        Args:
            context: 处理器执行上下文

        Returns:
            StageHandlerResult: 执行结果
        """
        try:
            generator = context.get_data("generator")
            if not generator:
                return StageHandlerResult(
                    success=False,
                    message="生成器未在上下文中设置",
                )

            # 执行地图生成
            result = self.orchestrator.generate(generator.report_data)

            if not result:
                return StageHandlerResult(
                    success=False,
                    message="地图生成失败",
                )

            return StageHandlerResult(
                success=True,
                message="地图生成成功",
                data={"maps_generated": result},
            )

        except Exception as e:
            self.logger.error(f"地图生成异常: {str(e)}", exc_info=True)
            return StageHandlerResult(
                success=False,
                message=f"地图生成异常: {str(e)}",
                error=e,
            )

    def validate(self, context: StageHandlerContext) -> bool:
        """验证执行条件"""
        generator = context.get_data("generator")
        if not generator:
            self.logger.error("生成器未在上下文中设置")
            return False
        return True


class ReportGenerationOrchestratorHandler(StageHandler):
    """报告生成编排器处理器适配器"""

    def __init__(self, orchestrator_instance: Any):
        """初始化适配器

        Args:
            orchestrator_instance: ReportGenerationOrchestrator 实例
        """
        super().__init__("report_generation_orchestrator")
        self.orchestrator = orchestrator_instance

    def execute(self, context: StageHandlerContext) -> StageHandlerResult:
        """执行报告生成

        Args:
            context: 处理器执行上下文

        Returns:
            StageHandlerResult: 执行结果
        """
        try:
            generator = context.get_data("generator")
            if not generator:
                return StageHandlerResult(
                    success=False,
                    message="生成器未在上下文中设置",
                )

            config_path = context.get_data("config_path")
            if not config_path:
                return StageHandlerResult(
                    success=False,
                    message="配置路径未在上下文中设置",
                )

            # 执行报告生成
            result = self.orchestrator.generate_full_report(
                generator.report_data,
                config_path,
            )

            if not result:
                return StageHandlerResult(
                    success=False,
                    message="报告生成失败",
                )

            return StageHandlerResult(
                success=True,
                message="报告生成成功",
                data={"report_generated": result},
            )

        except Exception as e:
            self.logger.error(f"报告生成异常: {str(e)}", exc_info=True)
            return StageHandlerResult(
                success=False,
                message=f"报告生成异常: {str(e)}",
                error=e,
            )

    def validate(self, context: StageHandlerContext) -> bool:
        """验证执行条件"""
        generator = context.get_data("generator")
        if not generator:
            self.logger.error("生成器未在上下文中设置")
            return False

        config_path = context.get_data("config_path")
        if not config_path:
            self.logger.error("配置路径未在上下文中设置")
            return False

        return True


class ModelTrainingOrchestratorHandler(StageHandler):
    """模型训练处理器适配器"""

    def __init__(self, generator_instance: Any):
        """初始化适配器

        Args:
            generator_instance: 报告生成器实例
        """
        super().__init__("model_training")
        self.generator = generator_instance

    def execute(self, context: StageHandlerContext) -> StageHandlerResult:
        """执行模型训练

        Args:
            context: 处理器执行上下文

        Returns:
            StageHandlerResult: 执行结果
        """
        try:
            if not hasattr(self.generator, "train_water_quality_models"):
                return StageHandlerResult(
                    success=True,
                    message="模型训练方法未实现，跳过",
                )

            result = self.generator.train_water_quality_models()

            if not result:
                return StageHandlerResult(
                    success=False,
                    message="模型训练失败",
                )

            return StageHandlerResult(
                success=True,
                message="模型训练成功",
                data={"model_trained": True},
            )

        except Exception as e:
            self.logger.error(f"模型训练异常: {str(e)}", exc_info=True)
            return StageHandlerResult(
                success=False,
                message=f"模型训练异常: {str(e)}",
                error=e,
            )

    def validate(self, context: StageHandlerContext) -> bool:
        """验证执行条件"""
        return hasattr(self.generator, "train_water_quality_models")


def create_orchestrator_handlers(
    resource_and_data_orch: Any,
    data_processing_orch: Any,
    map_generation_orch: Any,
    report_generation_orch: Any,
    generator: Any,
) -> Dict[str, StageHandler]:
    """创建所有编排器处理器适配器

    Args:
        resource_and_data_orch: ResourceAndDataOrchestrator 实例
        data_processing_orch: DataProcessingOrchestrator 实例
        map_generation_orch: MapGenerationOrchestrator 实例
        report_generation_orch: ReportGenerationOrchestrator 实例
        generator: 报告生成器实例

    Returns:
        Dict[str, StageHandler]: 处理器名称到处理器的映射
    """
    return {
        "resource_and_data": ResourceAndDataOrchestratorHandler(resource_and_data_orch),
        "data_processing": DataProcessingOrchestratorHandler(data_processing_orch),
        "map_generation": MapGenerationOrchestratorHandler(map_generation_orch),
        "report_generation": ReportGenerationOrchestratorHandler(report_generation_orch),
        "model_training": ModelTrainingOrchestratorHandler(generator),
    }
