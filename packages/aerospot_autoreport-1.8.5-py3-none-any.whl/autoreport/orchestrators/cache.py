"""缓存管理系统 - Stage 6 性能优化

提供阶段级别的缓存管理和性能优化功能。
"""

import hashlib
import json
import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, Optional, Callable
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)


@dataclass
class CacheEntry:
    """缓存条目

    存储缓存数据和元信息。
    """
    key: str
    value: Any
    created_at: float
    ttl_seconds: Optional[float] = None  # 生存时间（秒），None 表示无过期时间
    hit_count: int = 0
    last_accessed: float = field(default_factory=lambda: datetime.now().timestamp())

    def is_expired(self) -> bool:
        """检查缓存是否已过期"""
        if self.ttl_seconds is None:
            return False
        elapsed = datetime.now().timestamp() - self.created_at
        return elapsed > self.ttl_seconds

    def mark_accessed(self) -> None:
        """标记为已访问"""
        self.hit_count += 1
        self.last_accessed = datetime.now().timestamp()


class CacheBackend(ABC):
    """缓存后端抽象基类"""

    @abstractmethod
    def get(self, key: str) -> Optional[Any]:
        """获取缓存值"""
        pass

    @abstractmethod
    def set(self, key: str, value: Any, ttl_seconds: Optional[float] = None) -> None:
        """设置缓存值"""
        pass

    @abstractmethod
    def delete(self, key: str) -> None:
        """删除缓存"""
        pass

    @abstractmethod
    def clear(self) -> None:
        """清除所有缓存"""
        pass

    @abstractmethod
    def has(self, key: str) -> bool:
        """检查缓存是否存在"""
        pass

    @abstractmethod
    def get_stats(self) -> Dict[str, Any]:
        """获取缓存统计信息"""
        pass


class MemoryCache(CacheBackend):
    """内存缓存实现"""

    def __init__(self, max_size: int = 1000):
        """初始化内存缓存

        Args:
            max_size: 最大缓存条目数
        """
        self.max_size = max_size
        self._cache: Dict[str, CacheEntry] = {}
        self.logger = logging.getLogger(f"{__name__}.MemoryCache")

    def get(self, key: str) -> Optional[Any]:
        """获取缓存值"""
        if key not in self._cache:
            return None

        entry = self._cache[key]

        # 检查是否过期
        if entry.is_expired():
            del self._cache[key]
            self.logger.debug(f"缓存已过期: {key}")
            return None

        # 标记为已访问
        entry.mark_accessed()
        return entry.value

    def set(self, key: str, value: Any, ttl_seconds: Optional[float] = None) -> None:
        """设置缓存值"""
        # 如果缓存已满，删除最少使用的条目
        if len(self._cache) >= self.max_size and key not in self._cache:
            # 找到最少使用的条目
            least_used = min(
                self._cache.items(),
                key=lambda x: (x[1].hit_count, x[1].last_accessed),
            )
            del self._cache[least_used[0]]
            self.logger.debug(f"删除最少使用缓存: {least_used[0]}")

        self._cache[key] = CacheEntry(
            key=key,
            value=value,
            created_at=datetime.now().timestamp(),
            ttl_seconds=ttl_seconds,
        )
        self.logger.debug(f"缓存已设置: {key} (TTL: {ttl_seconds})")

    def delete(self, key: str) -> None:
        """删除缓存"""
        if key in self._cache:
            del self._cache[key]
            self.logger.debug(f"缓存已删除: {key}")

    def clear(self) -> None:
        """清除所有缓存"""
        self._cache.clear()
        self.logger.info("所有缓存已清除")

    def has(self, key: str) -> bool:
        """检查缓存是否存在"""
        if key not in self._cache:
            return False

        entry = self._cache[key]
        if entry.is_expired():
            del self._cache[key]
            return False

        return True

    def get_stats(self) -> Dict[str, Any]:
        """获取缓存统计信息"""
        total_hits = sum(entry.hit_count for entry in self._cache.values())
        expired_count = sum(1 for entry in self._cache.values() if entry.is_expired())

        return {
            "backend": "memory",
            "size": len(self._cache),
            "max_size": self.max_size,
            "total_hits": total_hits,
            "expired_entries": expired_count,
        }


class StageCacheManager:
    """阶段缓存管理器

    管理各个执行阶段的缓存，支持：
    - 基于键的缓存
    - TTL（生存时间）支持
    - 缓存统计
    - 缓存清理
    """

    def __init__(self, backend: Optional[CacheBackend] = None):
        """初始化缓存管理器

        Args:
            backend: 缓存后端实现（默认使用内存缓存）
        """
        self.backend = backend or MemoryCache()
        self.logger = logging.getLogger(__name__)

    def get_cache_key(
        self,
        stage: str,
        handler: str,
        data: Optional[Dict[str, Any]] = None,
    ) -> str:
        """生成缓存键

        基于阶段、处理器和数据内容生成唯一键。

        Args:
            stage: 执行阶段
            handler: 处理器名称
            data: 输入数据（用于生成哈希）

        Returns:
            str: 缓存键
        """
        key_parts = [stage, handler]

        if data:
            # 生成数据哈希
            data_str = json.dumps(data, sort_keys=True, default=str)
            data_hash = hashlib.md5(data_str.encode()).hexdigest()
            key_parts.append(data_hash[:8])

        return ":".join(key_parts)

    def get(self, key: str) -> Optional[Any]:
        """获取缓存值"""
        value = self.backend.get(key)
        if value is not None:
            self.logger.debug(f"缓存命中: {key}")
        else:
            self.logger.debug(f"缓存未命中: {key}")
        return value

    def set(
        self,
        key: str,
        value: Any,
        ttl_seconds: Optional[float] = None,
    ) -> None:
        """设置缓存值"""
        self.backend.set(key, value, ttl_seconds)

    def delete(self, key: str) -> None:
        """删除缓存"""
        self.backend.delete(key)

    def clear(self) -> None:
        """清除所有缓存"""
        self.backend.clear()

    def get_stats(self) -> Dict[str, Any]:
        """获取缓存统计信息"""
        return self.backend.get_stats()

    def set_cache_decorator(
        self,
        ttl_seconds: Optional[float] = None,
    ):
        """缓存装饰器工厂

        使用方式：
        ```python
        cache_mgr = StageCacheManager()

        @cache_mgr.set_cache_decorator(ttl_seconds=3600)
        def expensive_function(arg1, arg2):
            return compute_result(arg1, arg2)
        ```

        Args:
            ttl_seconds: 缓存生存时间（秒）

        Returns:
            装饰器函数
        """

        def decorator(func: Callable) -> Callable:
            def wrapper(*args, **kwargs) -> Any:
                # 生成缓存键
                key_data = {
                    "func": func.__name__,
                    "args": args,
                    "kwargs": kwargs,
                }
                cache_key = self.get_cache_key(
                    "decorator",
                    func.__name__,
                    key_data,
                )

                # 尝试从缓存获取
                cached_value = self.get(cache_key)
                if cached_value is not None:
                    self.logger.debug(f"函数缓存命中: {func.__name__}")
                    return cached_value

                # 执行函数
                result = func(*args, **kwargs)

                # 缓存结果
                self.set(cache_key, result, ttl_seconds)

                return result

            return wrapper

        return decorator
