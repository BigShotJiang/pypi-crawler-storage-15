#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""报告生成编排器模块

协调报告配置生成和最终报告文档的生成。
"""

import json
import logging
import os
from typing import Any, Dict, Optional

from ..core.configuration_service import ConfigurationService
from ..utils.path import PathManager
from ..core.generator import ReportGenerator
from ..models.report_data import ReportData
from ..processor.config import create_updated_config
from .orchestrator import Orchestrator

logger = logging.getLogger(__name__)


class ReportGenerationOrchestrator(Orchestrator):
    """报告生成编排器

    职责：
    - 协调报告配置的生成
    - 协调报告文档的生成
    - 管理报告生成的完整流程

    原始职责来自：
    - AeroSpotReportGenerator.generate_config() 的第 880-908 行
    - AeroSpotReportGenerator.generate_report() 的第 952-983 行

    示例：
        >>> orchestrator = ReportGenerationOrchestrator(
        ...     config_service=config_service,
        ...     path_manager=path_manager
        ... )
        >>> config_path = orchestrator.generate_config(report_data)
        >>> orchestrator.generate_report(config_path, report_data)
    """

    def __init__(
        self,
        config_service: ConfigurationService,
        path_manager: PathManager,
    ) -> None:
        """初始化报告生成编排器

        Args:
            config_service: 配置服务实例，提供水质等级配置
            path_manager: 路径管理器实例，提供文件路径管理
        """
        super().__init__()
        self.config_service: ConfigurationService = config_service
        self.path_manager: PathManager = path_manager
        self.logger: logging.Logger = logger
        self.last_config_path: Optional[str] = None
        self.last_report_path: Optional[str] = None

    def execute(self, data: ReportData) -> ReportData:
        """执行编排流程（Orchestrator 接口实现）

        Args:
            data: ReportData模型实例

        Returns:
            ReportData: 处理后的模型实例
        """
        # 生成报告配置
        config_path = self.generate_config(data)
        if not config_path:
            data.update_processing_state("failed", "报告配置生成失败")
            return data

        # 生成报告文档
        success = self.generate_report(config_path, data)
        if success:
            data.update_processing_state("success")
        else:
            data.update_processing_state("failed", "报告生成失败")

        return data

    def validate_input(self, data: ReportData) -> bool:
        """验证输入数据的有效性（Orchestrator 接口实现）

        Args:
            data: 需要验证的报告数据模型

        Returns:
            bool: 验证通过返回 True；失败返回 False
        """
        if data is None:
            self.logger.error("输入数据为 None")
            return False

        if data.config is None:
            self.logger.error("配置信息缺失")
            return False

        return True

    def generate_config(
        self,
        report_data: ReportData,
    ) -> Optional[str]:
        """生成报告配置结构

        根据处理后的报告数据生成报告结构 JSON 文件。

        Args:
            report_data: ReportData模型实例，包含处理后的报告数据

        Returns:
            Optional[str]: 报告结构文件路径，失败返回 None

        Raises:
            Exception: 配置生成过程中的任何错误
        """
        try:
            self.logger.info("开始生成报告结构")

            # 直接传递 ReportData 到 create_updated_config
            structure_path = create_updated_config(
                report_data=report_data,
                report_structure_file=self.path_manager.get_file_path(
                    "reports", "report_structure.json"
                ),
                config_service=self.config_service,
            )

            if not structure_path:
                self.logger.error("生成报告结构失败")
                return None

            self.logger.info(f"报告结构已生成: {structure_path}")
            self.last_config_path = structure_path

            return structure_path

        except Exception as e:
            self.logger.exception(f"生成报告配置失败: {e}")
            return None

    def generate_report(
        self,
        config_path: str,
        report_data: ReportData,
    ) -> bool:
        """生成最终的报告文档

        使用报告配置生成最终的 Word 文档报告。

        Args:
            config_path: 报告结构配置文件路径
            report_data: ReportData模型实例

        Returns:
            bool: 报告是否生成成功
        """
        try:
            self.logger.info("开始生成报告文档")

            # 验证配置文件是否存在
            if not os.path.exists(config_path):
                self.logger.error(f"报告结构文件不存在: {config_path}")
                return False

            # 读取报告结构
            with open(config_path, "r", encoding="utf-8") as f:
                report_structure = json.load(f)

            # 从 ReportData 中提取数据用于报告生成
            # 与 generate_config() 保持一致的字段结构
            update_data = {
                # 必需的配置信息
                "company_info": report_data.config.get("company_info", {}),

                # 数据处理结果 - 使用强类型容器的属性（不再从config读取）
                "merged_data": report_data.uav_data.data if (report_data.uav_data and report_data.uav_data.is_valid) else None,
                "measure_data": report_data.measure_data.data if (report_data.measure_data and report_data.measure_data.is_valid) else None,
                "pred_data": report_data.prediction_results.pred_data if report_data.prediction_results else None,
                "all_pred_data": report_data.prediction_results.all_pred_data if report_data.prediction_results else None,
                "comparison_data": report_data.comparison_results.__dict__ if report_data.comparison_results else {},

                # 地图数据
                "maps": report_data.maps,

                # 图片资源
                "image_resources": {
                    "logo": report_data.image_resources.logo,
                    "satellite": report_data.image_resources.satellite,
                    "wayline": report_data.image_resources.wayline,
                },

                # 其他配置
                "visualization_mode": report_data.config.get("visualization_mode", "qualitative"),
            }

            # 创建报告生成器
            generator = ReportGenerator(
                output_path=self.path_manager.get_report_path("AeroSpotReport自动报告"),
                report_structure=report_structure,
                update_data=update_data,
            )

            # 生成报告
            output_file = generator.generate()

            if not output_file or not os.path.exists(output_file):
                self.logger.error("报告生成失败，输出文件不存在")
                return False

            self.logger.info(f"报告已生成: {output_file}")
            self.last_report_path = os.path.abspath(output_file)

            return True

        except json.JSONDecodeError as e:
            self.logger.exception(f"报告结构 JSON 解析失败: {e}")
            return False
        except Exception as e:
            self.logger.exception(f"生成报告文档失败: {e}")
            return False

    def generate_full_report(
        self,
        report_data: ReportData,
    ) -> bool:
        """生成完整的报告（配置 + 文档）

        在单个方法中完成报告配置和文档的生成。

        Args:
            report_data: ReportData模型实例

        Returns:
            bool: 完整报告是否生成成功
        """
        try:
            self.logger.info("开始生成完整报告")

            # 第一步：生成报告配置
            config_path = self.generate_config(report_data)
            if not config_path:
                self.logger.error("报告配置生成失败")
                return False

            # 第二步：生成报告文档
            result = self.generate_report(config_path, report_data)
            if not result:
                self.logger.error("报告文档生成失败")
                return False

            self.logger.info("完整报告生成完成")
            return True

        except Exception as e:
            self.logger.exception(f"生成完整报告失败: {e}")
            return False

    def get_last_config_path(self) -> Optional[str]:
        """获取最后一次生成的配置文件路径

        Returns:
            Optional[str]: 配置文件路径，若无则返回 None
        """
        return self.last_config_path

    def get_last_report_path(self) -> Optional[str]:
        """获取最后一次生成的报告文件路径

        Returns:
            Optional[str]: 报告文件路径，若无则返回 None
        """
        return self.last_report_path

    def validate_data(
        self,
        report_data: ReportData,
    ) -> bool:
        """验证报告数据的有效性

        Args:
            report_data: ReportData模型实例

        Returns:
            bool: 数据是否有效
        """
        try:
            # 检查报告数据不为空
            if not report_data:
                self.logger.error("报告数据为空或 None")
                return False

            # 检查关键字段是否有效
            # UAV数据或预测数据至少要有一个（从强类型容器读取）
            has_uav_or_pred = (
                report_data.uav_data is not None
                or report_data.prediction_results is not None
            )

            if not has_uav_or_pred:
                self.logger.error("报告数据缺少 UAV 数据或预测数据")
                return False

            self.logger.debug("报告数据有效")
            return True

        except Exception as e:
            self.logger.exception(f"报告数据验证异常: {e}")
            return False

    def clear_paths(self) -> None:
        """清除保存的路径记录"""
        self.last_config_path = None
        self.last_report_path = None
        self.logger.debug("已清除保存的路径记录")
