#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""几何体验证混合类

提供几何体验证和修复的可复用功能。
"""

import logging
from typing import Any, Optional

logger = logging.getLogger(__name__)


class GeometryValidationMixin:
    """几何体验证混合类

    为任何类提供几何体验证和修复的功能。
    这个混合类整合了 KML 修复逻辑，使其可以在任何需要处理几何体的地方使用。

    使用示例：
        >>> class MapGenerator(GeometryValidationMixin):
        ...     def generate(self, data):
        ...         geom = self.validate_geometry(data.boundary_geom)
        ...         # 使用修复后的几何体
        ...         return geom

    方法：
        - validate_geometry(): 验证和修复几何体
        - is_valid_geometry(): 检查几何体是否有效
        - get_geometry_bounds(): 获取几何体的边界
    """

    @staticmethod
    def validate_geometry(geom: Any, max_attempts: int = 3) -> Optional[Any]:
        """验证和修复几何体

        这是核心方法，使用 KML 修复逻辑对几何体进行验证和修复。

        Args:
            geom: 输入的几何体（可以是 shapely Polygon/MultiPolygon 或其他格式）
            max_attempts: 最大修复尝试次数（默认 3 次）

        Returns:
            Optional[Any]: 修复后的几何体；如果无法修复则返回 None

        示例：
            >>> from shapely.geometry import Polygon
            >>> polygon = Polygon([(0, 0), (1, 0), (1, 1), (0, 1)])
            >>> fixed_geom = GeometryValidationMixin.validate_geometry(polygon)
        """
        if geom is None:
            logger.debug("几何体为 None，跳过验证")
            return None

        try:
            from ..utils.kml import _fix_geometry_with_retry

            logger.debug(f"开始验证几何体: {type(geom).__name__}")
            fixed_geom = _fix_geometry_with_retry(geom, max_attempts=max_attempts)

            if fixed_geom is None:
                logger.warning("几何体无法修复，将被设置为 None")
            else:
                logger.info("几何体验证和修复成功")

            return fixed_geom

        except Exception as e:
            logger.error(
                f"几何体验证失败: {str(e)}",
                exc_info=True,
            )
            return None

    @staticmethod
    def is_valid_geometry(geom: Any) -> bool:
        """检查几何体是否有效

        Args:
            geom: 需要检查的几何体

        Returns:
            bool: 几何体有效返回 True；否则返回 False
        """
        if geom is None:
            return False

        try:
            # 如果是 shapely 几何体，使用 is_valid 属性
            if hasattr(geom, "is_valid"):
                return bool(geom.is_valid)

            # 如果是其他类型，尝试调用验证方法
            if hasattr(geom, "validate"):
                geom.validate()
                return True

            # 默认认为非 None 的几何体是有效的
            return True

        except Exception as e:
            logger.debug(f"几何体有效性检查失败: {str(e)}")
            return False

    @staticmethod
    def get_geometry_bounds(geom: Any) -> Optional[tuple]:
        """获取几何体的边界框

        Args:
            geom: 几何体对象

        Returns:
            Optional[tuple]: 边界框 (minx, miny, maxx, maxy)；如果获取失败返回 None
        """
        if geom is None:
            return None

        try:
            # 如果是 shapely 几何体
            if hasattr(geom, "bounds"):
                bounds = geom.bounds
                if bounds:
                    logger.debug(f"获取几何体边界框成功: {bounds}")
                    return bounds

            logger.warning("无法获取几何体的边界框")
            return None

        except Exception as e:
            logger.error(f"获取几何体边界框失败: {str(e)}")
            return None

    @staticmethod
    def validate_multiple_geometries(
        geometries: list[Any], max_attempts: int = 3
    ) -> list[Optional[Any]]:
        """验证多个几何体

        Args:
            geometries: 几何体列表
            max_attempts: 最大修复尝试次数

        Returns:
            list[Optional[Any]]: 修复后的几何体列表

        示例：
            >>> from shapely.geometry import Polygon
            >>> geoms = [
            ...     Polygon([(0, 0), (1, 0), (1, 1), (0, 1)]),
            ...     Polygon([(2, 2), (3, 2), (3, 3), (2, 3)])
            ... ]
            >>> fixed_geoms = GeometryValidationMixin.validate_multiple_geometries(geoms)
        """
        fixed_geoms = []
        for i, geom in enumerate(geometries):
            try:
                fixed_geom = GeometryValidationMixin.validate_geometry(
                    geom, max_attempts
                )
                fixed_geoms.append(fixed_geom)
                logger.debug(f"几何体 {i} 验证完成")
            except Exception as e:
                logger.error(f"几何体 {i} 验证失败: {str(e)}")
                fixed_geoms.append(None)

        return fixed_geoms
