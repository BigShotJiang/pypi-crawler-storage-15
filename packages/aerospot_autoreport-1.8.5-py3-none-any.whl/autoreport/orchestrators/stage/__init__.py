"""Stage Registry Module

提供动态阶段注册和管理功能。

Stage 1 (基础设施)：
- StageRegistry: 阶段处理器动态注册表

Stage 4 (阶段处理器系统)：
- StageHandler: 阶段处理器抽象基类
- StageHandlerContext: 处理器执行上下文
- StageHandlerResult: 处理器执行结果
- HandlerMiddleware: 中间件抽象基类
- LoggingMiddleware: 日志中间件
- ErrorRecoveryMiddleware: 错误恢复中间件
- ValidationMiddleware: 验证中间件
- StageOrchestrator: 阶段编排器
- StageExecutionResult: 阶段执行结果聚合
"""

from .registry import StageRegistry
from .handler import (
    StageHandler,
    StageHandlerContext,
    StageHandlerResult,
    HandlerMiddleware,
    LoggingMiddleware,
    ErrorRecoveryMiddleware,
    ValidationMiddleware,
)
from .orchestrator import StageOrchestrator, StageExecutionResult

__all__ = [
    # Stage 1
    "StageRegistry",
    # Stage 4
    "StageHandler",
    "StageHandlerContext",
    "StageHandlerResult",
    "HandlerMiddleware",
    "LoggingMiddleware",
    "ErrorRecoveryMiddleware",
    "ValidationMiddleware",
    "StageOrchestrator",
    "StageExecutionResult",
]
