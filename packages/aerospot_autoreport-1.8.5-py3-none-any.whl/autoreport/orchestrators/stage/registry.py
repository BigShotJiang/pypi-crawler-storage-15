"""Stage Registry - 动态注册和管理执行阶段处理器

这个模块提供了 StageRegistry 类，用于在运行时动态注册和查询阶段处理器。
这替代了原来硬编码在 pipeline.py 中的阶段处理映射。

核心功能：
- 注册阶段处理器（lambda 或函数）
- 获取指定阶段的处理器
- 列出所有可用阶段

设计原则：
- 简单：只关注注册和查询
- 灵活：支持运行时动态注册
- 解耦：Pipeline 不需要知道具体的处理器实现
"""

from typing import Callable, Dict, List, Optional
from ..execution_modes.base import ExecutionStage


class StageRegistry:
    """Stage 处理器注册表

    提供统一的接口来注册和查询执行阶段的处理器。

    Attributes:
        _handlers: 阶段到处理器的映射字典

    Examples:
        >>> registry = StageRegistry()
        >>> registry.register(
        ...     ExecutionStage.PROCESS_DATA,
        ...     lambda context: context.generator.process_data()
        ... )
        >>> handler = registry.get_handler(ExecutionStage.PROCESS_DATA)
        >>> handler(context)
    """

    def __init__(self) -> None:
        """初始化 StageRegistry"""
        self._handlers: Dict[ExecutionStage, Callable] = {}

    def register(
        self,
        stage: ExecutionStage,
        handler: Callable
    ) -> None:
        """注册一个阶段处理器

        Args:
            stage: 要注册的执行阶段
            handler: 处理该阶段的可调用对象（函数或 lambda）

        Raises:
            TypeError: 如果 handler 不可调用
            ValueError: 如果尝试重复注册同一阶段

        Examples:
            >>> registry.register(
            ...     ExecutionStage.PROCESS_DATA,
            ...     process_data_handler
            ... )
        """
        if not callable(handler):
            raise TypeError(
                f"Handler must be callable, got {type(handler).__name__}"
            )

        if stage in self._handlers:
            raise ValueError(
                f"Stage {stage.value} is already registered. "
                f"Use update() to replace it."
            )

        self._handlers[stage] = handler

    def update(
        self,
        stage: ExecutionStage,
        handler: Callable
    ) -> None:
        """更新一个阶段处理器（允许覆盖现有处理器）

        Args:
            stage: 要更新的执行阶段
            handler: 新的处理器

        Raises:
            TypeError: 如果 handler 不可调用
        """
        if not callable(handler):
            raise TypeError(
                f"Handler must be callable, got {type(handler).__name__}"
            )
        self._handlers[stage] = handler

    def get_handler(
        self,
        stage: ExecutionStage
    ) -> Optional[Callable]:
        """获取指定阶段的处理器

        Args:
            stage: 要查询的执行阶段

        Returns:
            处理器函数，如果未注册则返回 None

        Examples:
            >>> handler = registry.get_handler(ExecutionStage.PROCESS_DATA)
            >>> if handler:
            ...     handler(context)
        """
        return self._handlers.get(stage)

    def has_handler(self, stage: ExecutionStage) -> bool:
        """检查是否已注册指定阶段的处理器

        Args:
            stage: 要检查的执行阶段

        Returns:
            如果已注册则返回 True，否则返回 False
        """
        return stage in self._handlers

    def list_stages(self) -> List[ExecutionStage]:
        """列出所有已注册的执行阶段

        Returns:
            已注册阶段的列表

        Examples:
            >>> stages = registry.list_stages()
            >>> for stage in stages:
            ...     print(stage.value)
        """
        return list(self._handlers.keys())

    def list_stage_names(self) -> List[str]:
        """列出所有已注册的执行阶段名称

        Returns:
            已注册阶段名称的列表（字符串格式）
        """
        return [stage.value for stage in self._handlers.keys()]

    def unregister(self, stage: ExecutionStage) -> None:
        """注销一个阶段处理器

        Args:
            stage: 要注销的执行阶段

        Raises:
            ValueError: 如果阶段未注册
        """
        if stage not in self._handlers:
            raise ValueError(f"Stage {stage.value} is not registered")
        del self._handlers[stage]

    def clear(self) -> None:
        """清空所有已注册的处理器"""
        self._handlers.clear()

    def get_handler_count(self) -> int:
        """获取已注册处理器的数量

        Returns:
            已注册处理器数量
        """
        return len(self._handlers)
