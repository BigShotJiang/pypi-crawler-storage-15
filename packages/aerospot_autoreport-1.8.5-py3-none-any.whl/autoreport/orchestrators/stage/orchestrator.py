"""阶段编排器 - Stage 4 核心

管理阶段处理器的执行、中间件链、生命周期和结果聚合。
"""

import time
import logging
from typing import Dict, List, Optional
from dataclasses import dataclass, field

from ..execution_modes.base import ExecutionStage
from .handler import (
    StageHandler,
    StageHandlerContext,
    StageHandlerResult,
    HandlerMiddleware,
    LoggingMiddleware,
    ValidationMiddleware,
)

logger = logging.getLogger(__name__)


@dataclass
class StageExecutionResult:
    """阶段执行结果聚合

    包含一个阶段内所有处理器的执行结果和统计信息。
    """
    stage: ExecutionStage
    success: bool
    handlers_executed: List[str] = field(default_factory=list)
    handlers_failed: List[str] = field(default_factory=list)
    total_duration: float = 0.0
    results: Dict[str, StageHandlerResult] = field(default_factory=dict)

    def is_success(self) -> bool:
        """检查阶段是否成功"""
        return self.success

    def add_handler_result(
        self, handler_name: str, result: StageHandlerResult
    ) -> None:
        """添加处理器结果"""
        self.results[handler_name] = result
        self.handlers_executed.append(handler_name)
        if not result.is_success():
            self.handlers_failed.append(handler_name)

    def to_dict(self) -> Dict:
        """转换为字典格式"""
        return {
            "stage": self.stage.value,
            "success": self.success,
            "handlers_executed": self.handlers_executed,
            "handlers_failed": self.handlers_failed,
            "total_duration": self.total_duration,
            "results": {k: v.to_dict() for k, v in self.results.items()},
        }


class StageOrchestrator:
    """阶段编排器

    管理特定阶段的所有处理器执行，包括：
    - 处理器注册和管理
    - 中间件链的建立和执行
    - 处理器执行的生命周期管理
    - 执行结果的收集和聚合
    """

    def __init__(self, stage: ExecutionStage):
        """初始化阶段编排器

        Args:
            stage: 执行阶段
        """
        self.stage = stage
        self.logger = logging.getLogger(f"{__name__}.{stage.value}")

        # 处理器管理
        self.handlers: Dict[str, StageHandler] = {}
        self.handler_order: List[str] = []

        # 中间件管理
        self.middleware_chain: Optional[HandlerMiddleware] = None
        self._setup_default_middleware()

        # 执行历史
        self.last_result: Optional[StageExecutionResult] = None

    def _setup_default_middleware(self) -> None:
        """设置默认的中间件链

        默认中间件顺序：
        1. ValidationMiddleware - 验证处理器执行条件
        2. LoggingMiddleware - 记录执行日志
        """
        validation = ValidationMiddleware("validation")
        logging = LoggingMiddleware("logging")
        validation.set_next(logging)
        self.middleware_chain = validation

    def register_handler(self, name: str, handler: StageHandler) -> None:
        """注册阶段处理器

        Args:
            name: 处理器名称（用于识别和执行顺序）
            handler: StageHandler 实例

        Raises:
            ValueError: 处理器已存在
            TypeError: handler 不是 StageHandler 的实例
        """
        if not isinstance(handler, StageHandler):
            raise TypeError(
                f"handler 必须是 StageHandler 的实例，收到: {type(handler)}"
            )

        if name in self.handlers:
            raise ValueError(f"处理器已存在: {name}")

        self.handlers[name] = handler
        self.handler_order.append(name)
        self.logger.info(f"注册处理器: {name} (阶段: {self.stage.value})")

    def unregister_handler(self, name: str) -> None:
        """注销阶段处理器

        Args:
            name: 处理器名称

        Raises:
            ValueError: 处理器不存在
        """
        if name not in self.handlers:
            raise ValueError(f"处理器不存在: {name}")

        del self.handlers[name]
        self.handler_order.remove(name)
        self.logger.info(f"注销处理器: {name}")

    def insert_handler(self, name: str, handler: StageHandler, before: Optional[str] = None) -> None:
        """在指定位置插入处理器

        Args:
            name: 处理器名称
            handler: StageHandler 实例
            before: 在哪个处理器之前插入（None 则添加到末尾）

        Raises:
            ValueError: 处理器已存在或位置不合法
        """
        if name in self.handlers:
            raise ValueError(f"处理器已存在: {name}")

        if before is None:
            self.register_handler(name, handler)
        elif before not in self.handlers:
            raise ValueError(f"目标处理器不存在: {before}")
        else:
            if not isinstance(handler, StageHandler):
                raise TypeError(
                    f"handler 必须是 StageHandler 的实例，收到: {type(handler)}"
                )

            idx = self.handler_order.index(before)
            self.handlers[name] = handler
            self.handler_order.insert(idx, name)
            self.logger.info(f"在 {before} 之前插入处理器: {name}")

    def get_handler(self, name: str) -> Optional[StageHandler]:
        """获取处理器

        Args:
            name: 处理器名称

        Returns:
            StageHandler: 处理器实例，如果不存在则返回 None
        """
        return self.handlers.get(name)

    def list_handlers(self) -> List[str]:
        """列出所有处理器（按执行顺序）

        Returns:
            List[str]: 处理器名称列表
        """
        return self.handler_order.copy()

    def add_middleware(self, middleware: HandlerMiddleware) -> None:
        """添加中间件到链的末尾

        Args:
            middleware: HandlerMiddleware 实例
        """
        if self.middleware_chain is None:
            self.middleware_chain = middleware
        else:
            # 找到链的末尾
            current = self.middleware_chain
            while current.next_middleware is not None:
                current = current.next_middleware
            current.set_next(middleware)

        self.logger.info(f"添加中间件: {middleware.name}")

    def execute(self, context: StageHandlerContext) -> StageExecutionResult:
        """执行阶段内所有的处理器

        执行流程：
        1. 创建阶段执行结果
        2. 按顺序执行每个处理器
        3. 应用中间件链
        4. 收集和聚合结果
        5. 调用生命周期回调

        Args:
            context: 阶段处理器执行上下文

        Returns:
            StageExecutionResult: 阶段执行结果
        """
        stage_result = StageExecutionResult(stage=self.stage, success=True)
        stage_start_time = time.time()

        self.logger.info(f"开始执行阶段: {self.stage.value}")

        for handler_name in self.handler_order:
            handler = self.handlers[handler_name]
            handler_start_time = time.time()

            try:
                # 验证和执行处理器
                context.add_to_history(handler_name)

                # 执行中间件的前置钩子
                if self.middleware_chain:
                    should_continue = self.middleware_chain.before_execute(context, handler)
                    if not should_continue:
                        self.logger.warning(f"处理器被中间件阻止: {handler_name}")
                        result = StageHandlerResult(
                            success=False,
                            message="处理器被中间件阻止"
                        )
                        stage_result.add_handler_result(handler_name, result)
                        handler.on_failure(context, result)
                        stage_result.success = False
                        continue

                # 执行处理器
                result = handler.execute(context)
                result.duration_seconds = time.time() - handler_start_time

                # 执行中间件的后置钩子
                if self.middleware_chain:
                    result = self.middleware_chain.execute_chain(context, handler, result)

                # 调用生命周期回调
                if result.is_success():
                    handler.on_success(context, result)
                else:
                    handler.on_failure(context, result)
                    stage_result.success = False

                # 收集结果
                stage_result.add_handler_result(handler_name, result)

            except Exception as e:
                self.logger.error(f"处理器异常: {handler_name} - {str(e)}", exc_info=True)

                result = StageHandlerResult(
                    success=False,
                    message=f"处理器异常: {str(e)}",
                    error=e,
                    duration_seconds=time.time() - handler_start_time,
                )

                handler.on_failure(context, result)
                stage_result.add_handler_result(handler_name, result)
                stage_result.success = False

            finally:
                # 清理资源
                try:
                    handler.cleanup(context, stage_result.results.get(handler_name))
                except Exception as e:
                    self.logger.warning(f"处理器清理异常: {handler_name} - {str(e)}")

        # 计算总耗时
        stage_result.total_duration = time.time() - stage_start_time

        # 记录阶段执行结果
        if stage_result.is_success():
            self.logger.info(
                f"阶段执行成功: {self.stage.value} "
                f"(处理器: {len(stage_result.handlers_executed)}, "
                f"耗时: {stage_result.total_duration:.2f}s)"
            )
        else:
            self.logger.error(
                f"阶段执行失败: {self.stage.value} "
                f"(失败处理器: {stage_result.handlers_failed})"
            )

        self.last_result = stage_result
        return stage_result

    def get_last_result(self) -> Optional[StageExecutionResult]:
        """获取最后一次执行的结果

        Returns:
            StageExecutionResult: 最后一次执行的结果，如果未执行过则返回 None
        """
        return self.last_result

    def get_stage(self) -> ExecutionStage:
        """获取阶段"""
        return self.stage

    def get_handler_count(self) -> int:
        """获取处理器总数"""
        return len(self.handlers)

    def is_empty(self) -> bool:
        """检查是否没有处理器"""
        return len(self.handlers) == 0

    def clear_handlers(self) -> None:
        """清除所有处理器"""
        self.handlers.clear()
        self.handler_order.clear()
        self.logger.info(f"清除阶段 {self.stage.value} 的所有处理器")
