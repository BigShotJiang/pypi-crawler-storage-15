"""执行模式配置模型

定义所有执行模式的配置基类和具体实现。

这个模块替代了直接修改全局状态（如 global_rendering_config）的做法，
实现了显式的配置注入和类型安全的参数传递。

Phase D 改进：
- 重命名布尔参数遵循 PEP 8 规范（is_/has_/use_/enable_/should_ 前缀）
- 添加统一的 ExecutionConfig 作为顶层配置入口
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any


@dataclass
class ExecutionModeConfig(ABC):
    """执行模式配置基类

    所有执行模式的配置都应该继承自此类，以确保类型安全和可序列化。

    这个基类定义了通用的配置模式，子类可以扩展以支持特定模式的配置。
    """

    @abstractmethod
    def to_dict(self) -> Dict[str, Any]:
        """将配置转换为字典格式

        Returns:
            配置字典

        Examples:
            >>> config = FullReportConfig()
            >>> config_dict = config.to_dict()
        """
        pass

    @classmethod
    @abstractmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ExecutionModeConfig":
        """从字典构建配置

        Args:
            data: 配置字典

        Returns:
            ExecutionModeConfig 实例

        Examples:
            >>> config_dict = {"visualization_mode": "quantitative"}
            >>> config = FullReportConfig.from_dict(config_dict)
        """
        pass


@dataclass
class RenderingConfig(ExecutionModeConfig):
    """渲染配置

    用于控制地图渲染的各种参数。

    Attributes:
        colorbar_label_font: colorbar 标签字体大小
        colorbar_tick_font: colorbar 刻度字体大小
        title_font: 标题字体大小
        dpi: 输出分辨率
        figsize: 图形大小 (宽, 高)
        background_color: 背景色
        use_transparent_background: 是否使用透明背景 (改名：transparent -> use_transparent_background)
        enable_colored_console: 是否启用彩色控制台输出 (改名：colored_console)
    """

    colorbar_label_font: int = 12
    colorbar_tick_font: int = 10
    title_font: int = 12
    dpi: int = 300
    figsize: tuple = field(default_factory=lambda: (10, 8))
    background_color: Optional[str] = None
    use_transparent_background: bool = False  # ✨ 改名：transparent -> use_transparent_background
    enable_colored_console: bool = True  # ✨ 改名：colored_console

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary format"""
        return {
            "colorbar_label_font": self.colorbar_label_font,
            "colorbar_tick_font": self.colorbar_tick_font,
            "title_font": self.title_font,
            "dpi": self.dpi,
            "figsize": self.figsize,
            "background_color": self.background_color,
            "use_transparent_background": self.use_transparent_background,
            "enable_colored_console": self.enable_colored_console,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "RenderingConfig":
        """Create from dictionary

        ✨ Phase D 改进：支持旧参数名用于向后兼容
        - transparent (旧) -> use_transparent_background (新)
        - colored_console (旧) -> enable_colored_console (新)
        """
        return cls(
            colorbar_label_font=data.get("colorbar_label_font", 10),
            colorbar_tick_font=data.get("colorbar_tick_font", 8),
            title_font=data.get("title_font", 12),
            dpi=data.get("dpi", 300),
            figsize=data.get("figsize", (10, 8)),
            background_color=data.get("background_color"),
            # 支持新旧参数名
            use_transparent_background=data.get(
                "use_transparent_background",
                data.get("transparent", False)  # 向后兼容
            ),
            enable_colored_console=data.get(
                "enable_colored_console",
                data.get("colored_console", True)  # 向后兼容
            ),
        )


@dataclass
class MapGenerationConfig(ExecutionModeConfig):
    """地图生成配置

    用于控制地图生成过程的各种参数。

    Attributes:
        allowed_types: 允许的地图类型列表
        should_generate_standalone_colorbar: 是否生成独立的 colorbar 文件 (改名：generate_standalone_colorbar -> should_generate_standalone_colorbar)
        interpolation_method: 插值方法 ("kriging", "rbf", "linear")
        boundary_detection_method: 边界检测方法 ("kml", "alpha_shape", "convex_hull")
        grid_resolution: 网格分辨率
        mask_value: 掩码值
        kriging_method: 克里金方法详细配置
    """

    allowed_types: Optional[List[str]] = field(default_factory=list)
    should_generate_standalone_colorbar: bool = False  # ✨ 改名：generate_standalone_colorbar
    interpolation_method: str = "kriging"
    boundary_detection_method: str = "alpha_shape"
    grid_resolution: int = 100
    mask_value: float = -9999.0
    kriging_method: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary format"""
        return {
            "allowed_types": self.allowed_types,
            "should_generate_standalone_colorbar": self.should_generate_standalone_colorbar,
            "interpolation_method": self.interpolation_method,
            "boundary_detection_method": self.boundary_detection_method,
            "grid_resolution": self.grid_resolution,
            "mask_value": self.mask_value,
            "kriging_method": self.kriging_method,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MapGenerationConfig":
        """Create from dictionary

        ✨ Phase D 改进：支持旧参数名用于向后兼容
        - generate_standalone_colorbar (旧) -> should_generate_standalone_colorbar (新)
        """
        return cls(
            allowed_types=data.get("allowed_types"),
            # 支持新旧参数名
            should_generate_standalone_colorbar=data.get(
                "should_generate_standalone_colorbar",
                data.get("generate_standalone_colorbar", False)  # 向后兼容
            ),
            interpolation_method=data.get("interpolation_method", "kriging"),
            boundary_detection_method=data.get("boundary_detection_method", "alpha_shape"),
            grid_resolution=data.get("grid_resolution", 100),
            mask_value=data.get("mask_value", -9999.0),
            kriging_method=data.get("kriging_method"),
        )


@dataclass
class FullReportConfig(ExecutionModeConfig):
    """完整报告执行模式配置

    Attributes:
        visualization_mode: 可视化模式 ("quantitative" 或 "qualitative")
        rendering_config: 渲染配置
        map_generation_config: 地图生成配置
        should_include_model_training: 是否包含模型训练 (改名：include_model_training -> should_include_model_training)
        should_include_advanced_analysis: 是否包含高级分析 (改名：include_advanced_analysis -> should_include_advanced_analysis)
    """

    visualization_mode: str = "quantitative"
    rendering_config: RenderingConfig = field(default_factory=RenderingConfig)
    map_generation_config: MapGenerationConfig = field(default_factory=MapGenerationConfig)
    should_include_model_training: bool = True  # ✨ 改名：include_model_training
    should_include_advanced_analysis: bool = True  # ✨ 改名：include_advanced_analysis

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary format"""
        return {
            "visualization_mode": self.visualization_mode,
            "rendering_config": self.rendering_config.to_dict(),
            "map_generation_config": self.map_generation_config.to_dict(),
            "should_include_model_training": self.should_include_model_training,
            "should_include_advanced_analysis": self.should_include_advanced_analysis,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "FullReportConfig":
        """Create from dictionary

        ✨ Phase D 改进：支持旧参数名用于向后兼容
        - include_model_training (旧) -> should_include_model_training (新)
        - include_advanced_analysis (旧) -> should_include_advanced_analysis (新)
        """
        rendering_data = data.get("rendering_config", {})
        map_gen_data = data.get("map_generation_config", {})

        return cls(
            visualization_mode=data.get("visualization_mode", "quantitative"),
            rendering_config=RenderingConfig.from_dict(rendering_data),
            map_generation_config=MapGenerationConfig.from_dict(map_gen_data),
            # 支持新旧参数名
            should_include_model_training=data.get(
                "should_include_model_training",
                data.get("include_model_training", True)  # 向后兼容
            ),
            should_include_advanced_analysis=data.get(
                "should_include_advanced_analysis",
                data.get("include_advanced_analysis", True)  # 向后兼容
            ),
        )


@dataclass
class HeatmapOnlyConfig(ExecutionModeConfig):
    """仅热力图执行模式配置

    Attributes:
        rendering_config: 渲染配置
        map_generation_config: 地图生成配置
        should_include_distribution_maps: 是否包含分布图 (改名：include_distribution_maps -> should_include_distribution_maps)
    """

    rendering_config: RenderingConfig = field(default_factory=RenderingConfig)
    map_generation_config: MapGenerationConfig = field(
        default_factory=lambda: MapGenerationConfig(
            allowed_types=["clean_interpolation_svg"],
            should_generate_standalone_colorbar=True,
        )
    )
    should_include_distribution_maps: bool = True  # ✨ 改名：include_distribution_maps

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary format"""
        return {
            "rendering_config": self.rendering_config.to_dict(),
            "map_generation_config": self.map_generation_config.to_dict(),
            "should_include_distribution_maps": self.should_include_distribution_maps,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "HeatmapOnlyConfig":
        """Create from dictionary

        ✨ Phase D 改进：支持旧参数名用于向后兼容
        - include_distribution_maps (旧) -> should_include_distribution_maps (新)
        """
        rendering_data = data.get("rendering_config", {})
        map_gen_data = data.get("map_generation_config", {})

        return cls(
            rendering_config=RenderingConfig.from_dict(rendering_data),
            map_generation_config=MapGenerationConfig.from_dict(map_gen_data),
            # 支持新旧参数名
            should_include_distribution_maps=data.get(
                "should_include_distribution_maps",
                data.get("include_distribution_maps", True)  # 向后兼容
            ),
        )


@dataclass
class ModelingOnlyConfig(ExecutionModeConfig):
    """仅建模执行模式配置

    Attributes:
        model_type: 模型类型
        should_include_validation: 是否包含验证 (改名：include_validation -> should_include_validation)
        cross_validation_folds: 交叉验证折数
    """

    model_type: str = "water_quality"
    should_include_validation: bool = True  # ✨ 改名：include_validation
    cross_validation_folds: int = 5

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary format"""
        return {
            "model_type": self.model_type,
            "should_include_validation": self.should_include_validation,
            "cross_validation_folds": self.cross_validation_folds,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ModelingOnlyConfig":
        """Create from dictionary

        ✨ Phase D 改进：支持旧参数名用于向后兼容
        - include_validation (旧) -> should_include_validation (新)
        """
        return cls(
            model_type=data.get("model_type", "water_quality"),
            # 支持新旧参数名
            should_include_validation=data.get(
                "should_include_validation",
                data.get("include_validation", True)  # 向后兼容
            ),
            cross_validation_folds=data.get("cross_validation_folds", 5),
        )
