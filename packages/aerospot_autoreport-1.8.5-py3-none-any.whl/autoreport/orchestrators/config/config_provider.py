"""配置提供者 - 替代全局配置状态

这个模块提供了 ConfigProvider 类，用于管理所有执行模式的配置。
它替代了之前硬编码的全局变量（如 global_rendering_config），
实现了显式的配置注入和作用域隔离。

核心原则：
- 无默认 fallback 机制：缺少配置时抛出异常，不是使用默认值
- 显式注入：所有配置都通过构造函数或 setter 显式设置
- 作用域隔离：每个执行上下文可以有独立的 ConfigProvider 实例
"""

from typing import Optional, Dict, Any
from .execution_config import (
    RenderingConfig,
    MapGenerationConfig,
    ExecutionModeConfig,
)


class ConfigProvider:
    """配置提供者 - 管理所有执行配置

    替代全局配置变量，提供显式的、作用域隔离的配置管理。

    这个类遵循以下原则：
    1. 显式注入：配置必须显式设置
    2. 无默认 fallback：缺少配置时抛出异常
    3. 类型安全：所有配置都是类型化的对象
    4. 作用域隔离：每个执行上下文有独立实例

    Attributes:
        _rendering_config: 渲染配置
        _map_generation_config: 地图生成配置
        _execution_mode_config: 执行模式配置
        _custom_configs: 自定义配置字典

    Examples:
        >>> provider = ConfigProvider()
        >>> provider.set_rendering_config(RenderingConfig(dpi=300))
        >>> config = provider.get_rendering_config()
        >>> config.dpi
        300
    """

    def __init__(self) -> None:
        """初始化配置提供者"""
        self._rendering_config: Optional[RenderingConfig] = None
        self._map_generation_config: Optional[MapGenerationConfig] = None
        self._execution_mode_config: Optional[ExecutionModeConfig] = None
        self._custom_configs: Dict[str, Any] = {}

    # ============ 渲染配置 ============

    def set_rendering_config(self, config: RenderingConfig) -> None:
        """设置渲染配置

        Args:
            config: RenderingConfig 实例

        Raises:
            TypeError: 如果 config 不是 RenderingConfig 类型

        Examples:
            >>> provider.set_rendering_config(RenderingConfig(dpi=300))
        """
        if not isinstance(config, RenderingConfig):
            raise TypeError(
                f"Expected RenderingConfig, got {type(config).__name__}"
            )
        self._rendering_config = config

    def get_rendering_config(self) -> RenderingConfig:
        """获取渲染配置

        Returns:
            RenderingConfig 实例

        Raises:
            RuntimeError: 如果渲染配置未设置

        Examples:
            >>> config = provider.get_rendering_config()
        """
        if self._rendering_config is None:
            raise RuntimeError(
                "Rendering config not set. Use set_rendering_config() first."
            )
        return self._rendering_config

    def has_rendering_config(self) -> bool:
        """检查是否已设置渲染配置

        Returns:
            如果已设置返回 True，否则返回 False
        """
        return self._rendering_config is not None

    # ============ 地图生成配置 ============

    def set_map_generation_config(self, config: MapGenerationConfig) -> None:
        """设置地图生成配置

        Args:
            config: MapGenerationConfig 实例

        Raises:
            TypeError: 如果 config 不是 MapGenerationConfig 类型

        Examples:
            >>> provider.set_map_generation_config(
            ...     MapGenerationConfig(grid_resolution=150)
            ... )
        """
        if not isinstance(config, MapGenerationConfig):
            raise TypeError(
                f"Expected MapGenerationConfig, got {type(config).__name__}"
            )
        self._map_generation_config = config

    def get_map_generation_config(self) -> MapGenerationConfig:
        """获取地图生成配置

        Returns:
            MapGenerationConfig 实例

        Raises:
            RuntimeError: 如果地图生成配置未设置
        """
        if self._map_generation_config is None:
            raise RuntimeError(
                "Map generation config not set. Use set_map_generation_config() first."
            )
        return self._map_generation_config

    def has_map_generation_config(self) -> bool:
        """检查是否已设置地图生成配置

        Returns:
            如果已设置返回 True，否则返回 False
        """
        return self._map_generation_config is not None

    # ============ 执行模式配置 ============

    def set_execution_mode_config(self, config: ExecutionModeConfig) -> None:
        """设置执行模式配置

        Args:
            config: ExecutionModeConfig 实例或其子类

        Raises:
            TypeError: 如果 config 不是 ExecutionModeConfig 类型

        Examples:
            >>> from execution_config import FullReportConfig
            >>> provider.set_execution_mode_config(FullReportConfig())
        """
        if not isinstance(config, ExecutionModeConfig):
            raise TypeError(
                f"Expected ExecutionModeConfig, got {type(config).__name__}"
            )
        self._execution_mode_config = config

    def get_execution_mode_config(self) -> ExecutionModeConfig:
        """获取执行模式配置

        Returns:
            ExecutionModeConfig 实例

        Raises:
            RuntimeError: 如果执行模式配置未设置
        """
        if self._execution_mode_config is None:
            raise RuntimeError(
                "Execution mode config not set. Use set_execution_mode_config() first."
            )
        return self._execution_mode_config

    def has_execution_mode_config(self) -> bool:
        """检查是否已设置执行模式配置

        Returns:
            如果已设置返回 True，否则返回 False
        """
        return self._execution_mode_config is not None

    # ============ 自定义配置 ============

    def set_custom_config(self, key: str, value: Any) -> None:
        """设置自定义配置值

        Args:
            key: 配置键
            value: 配置值

        Examples:
            >>> provider.set_custom_config("custom_param", 42)
        """
        self._custom_configs[key] = value

    def get_custom_config(self, key: str, default: Any = None) -> Any:
        """获取自定义配置值

        Args:
            key: 配置键
            default: 如果键不存在时返回的默认值

        Returns:
            配置值或默认值

        Examples:
            >>> value = provider.get_custom_config("custom_param", 0)
        """
        return self._custom_configs.get(key, default)

    def has_custom_config(self, key: str) -> bool:
        """检查是否存在指定的自定义配置

        Args:
            key: 配置键

        Returns:
            如果存在返回 True，否则返回 False
        """
        return key in self._custom_configs

    # ============ 完整配置导出 ============

    def to_dict(self) -> Dict[str, Any]:
        """将所有配置导出为字典

        Returns:
            包含所有配置的字典

        Examples:
            >>> config_dict = provider.to_dict()
        """
        result = {
            "rendering_config": (
                self._rendering_config.to_dict()
                if self._rendering_config
                else None
            ),
            "map_generation_config": (
                self._map_generation_config.to_dict()
                if self._map_generation_config
                else None
            ),
            "execution_mode_config": (
                self._execution_mode_config.to_dict()
                if self._execution_mode_config
                else None
            ),
            "custom_configs": self._custom_configs.copy(),
        }
        return result

    # ============ 清空和重置 ============

    def clear(self) -> None:
        """清空所有配置

        Examples:
            >>> provider.clear()
        """
        self._rendering_config = None
        self._map_generation_config = None
        self._execution_mode_config = None
        self._custom_configs.clear()

    def clear_rendering_config(self) -> None:
        """清空渲染配置"""
        self._rendering_config = None

    def clear_map_generation_config(self) -> None:
        """清空地图生成配置"""
        self._map_generation_config = None

    def clear_execution_mode_config(self) -> None:
        """清空执行模式配置"""
        self._execution_mode_config = None

    # ============ 验证 ============

    def is_complete(self) -> bool:
        """检查所有必要的配置是否已完整设置

        Returns:
            如果所有必要配置都已设置返回 True

        Examples:
            >>> if provider.is_complete():
            ...     # 可以开始执行
            ...     pass
        """
        return (
            self._rendering_config is not None
            and self._map_generation_config is not None
            and self._execution_mode_config is not None
        )

    def get_missing_configs(self) -> list:
        """获取未设置的配置列表

        Returns:
            未设置配置的名称列表

        Examples:
            >>> missing = provider.get_missing_configs()
            >>> if missing:
            ...     print(f"Missing configs: {missing}")
        """
        missing = []
        if self._rendering_config is None:
            missing.append("rendering_config")
        if self._map_generation_config is None:
            missing.append("map_generation_config")
        if self._execution_mode_config is None:
            missing.append("execution_mode_config")
        return missing
