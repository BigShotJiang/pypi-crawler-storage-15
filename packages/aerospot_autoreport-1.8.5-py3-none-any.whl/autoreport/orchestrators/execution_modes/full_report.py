import os
from .base import ExecutionModeStrategy, ExecutionStage, ExecutionContext
from ..config.execution_config import FullReportConfig, ExecutionModeConfig
from typing import List, Dict, Any


class FullReportStrategy(ExecutionModeStrategy):
    """完整报告生成模式

    执行所有必需的阶段，生成完整的分析报告。

    包含的阶段：
    1. INIT - 初始化
    2. LOAD_CONFIG - 加载配置
    3. PROCESS_DATA - 数据处理
    4. GENERATE_MAPS - 生成地图
    5. SAVE_CONFIG - 保存配置
    6. GENERATE_STRUCTURE - 生成报告结构
    7. GENERATE_REPORT - 生成最终报告
    """

    def __init__(self, config: FullReportConfig = None):
        """初始化完整报告策略

        Args:
            config: FullReportConfig 实例，如果为 None 使用默认值
        """
        self._config = config or FullReportConfig()

    @property
    def mode_name(self) -> str:
        """返回模式名称"""
        return "full"

    @property
    def required_stages(self) -> List[ExecutionStage]:
        """返回该模式需要执行的所有阶段"""
        return [
            ExecutionStage.INIT,
            ExecutionStage.LOAD_CONFIG,
            ExecutionStage.PROCESS_DATA,
            ExecutionStage.GENERATE_MAPS,
            ExecutionStage.SAVE_CONFIG,
            ExecutionStage.GENERATE_STRUCTURE,
            ExecutionStage.GENERATE_REPORT,
        ]

    def get_execution_config(self, context: ExecutionContext) -> ExecutionModeConfig:
        """获取完整报告模式的配置（Stage 2 新增）

        Returns:
            FullReportConfig 实例，包含该模式的所有配置参数
        """
        return self._config

    def configure_environment(self, context: ExecutionContext) -> None:
        """配置执行环境

        完整模式使用 FullReportConfig 的默认配置。
        """
        pass  # 配置由 get_execution_config() 返回

    def format_output(self, context: ExecutionContext) -> Dict[str, Any]:
        """格式化输出结果

        返回完整报告模式的结果字典，包含报告路径、模型二进制文件和历史数据。

        路径信息来源：
        - report: 从 context.generator.get_last_report_path() 读取，包含完整文件名
        - bin: 从 report_data.config["model_bin_path"] 读取，由 DataProcessingOrchestrator 设置
        - historical_data: 从 report_data.config["historical_data_path"] 读取，由 DataProcessingOrchestrator 设置

        Returns:
            包含报告信息的字典，格式为：
            {
                "report": "/path/to/report_YYYYMMDD_HHMMSS/reports/AeroSpotReport自动报告.docx",
                "bin": "/path/to/models/model.bin" (如果有),
                "historical_data": "/path/to/models/historical_data.h5" (如果有)
            }
        """
        output = {}

        # 添加报告文件完整路径（包含文件名）
        report_path = context.generator.get_last_report_path()
        if report_path:
            output["report"] = report_path

        # 从 prediction_results 获取模型文件路径（不再从 config 读取）
        try:
            if hasattr(context.generator, 'report_data') and context.generator.report_data:
                pred_results = context.generator.report_data.prediction_results

                if pred_results is not None:
                    # 添加模型二进制文件路径（转换为绝对路径）
                    if pred_results.model_bin_path:
                        output['bin'] = os.path.abspath(pred_results.model_bin_path)

                    # 添加历史数据文件路径（从 training_metadata 读取）
                    if pred_results.training_metadata:
                        historical_path = pred_results.training_metadata.get('historical_data_path')
                        if historical_path:
                            output['historical_data'] = os.path.abspath(historical_path)
        except (AttributeError, KeyError, TypeError):
            # 如果从 prediction_results 读取失败，尝试从 print_info 回退
            pass

        # 回退：尝试从 generator.print_info 读取（用于向后兼容）
        if 'bin' not in output:
            if hasattr(context.generator, 'print_info') and context.generator.print_info:
                if 'bin' in context.generator.print_info:
                    output['bin'] = os.path.abspath(context.generator.print_info['bin'])

        if 'historical_data' not in output:
            if hasattr(context.generator, 'print_info') and context.generator.print_info:
                if 'historical_data' in context.generator.print_info:
                    output['historical_data'] = os.path.abspath(context.generator.print_info['historical_data'])

        return output