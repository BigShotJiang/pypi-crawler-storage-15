from .base import ExecutionModeStrategy, ExecutionStage, ExecutionContext
from .configs import RenderingConfig, MapGenerationConfig
from ..config.execution_config import ModelingOnlyConfig, ExecutionModeConfig
from typing import List, Dict, Any


class ModelingOnlyStrategy(ExecutionModeStrategy):
    """仅建模模式（训练水质模型）

    此模式专注于模型训练，用于基于收集的数据训练水质预测模型。

    包含的阶段：
    1. INIT - 初始化
    2. LOAD_CONFIG - 加载配置
    3. PROCESS_DATA - 数据处理
    4. TRAIN_MODEL - 训练模型（跳过地图生成）
    5. OUTPUT_RESULT - 输出模型路径

    特点：
    - 跳过地图生成步骤
    - 专注于数据处理和模型训练
    - 输出模型文件和相关元数据
    """

    def __init__(self, config: ModelingOnlyConfig = None):
        """初始化仅建模策略

        Args:
            config: ModelingOnlyConfig 实例，如果为 None 使用默认值
        """
        self._config = config or ModelingOnlyConfig()

    @property
    def mode_name(self) -> str:
        """返回模式名称"""
        return "modeling_only"

    @property
    def required_stages(self) -> List[ExecutionStage]:
        """返回该模式需要执行的阶段"""
        return [
            ExecutionStage.INIT,
            ExecutionStage.LOAD_CONFIG,
            ExecutionStage.PROCESS_DATA,
            ExecutionStage.TRAIN_MODEL,   # 训练模型
            ExecutionStage.OUTPUT_RESULT, # 输出模型路径
        ]

    def get_execution_config(self, context: ExecutionContext) -> ExecutionModeConfig:
        """获取仅建模模式的配置（Stage 2 新增）

        Returns:
            ModelingOnlyConfig 实例，包含该模式的所有配置参数
        """
        return self._config

    def configure_environment(self, context: ExecutionContext) -> None:
        """配置建模参数

        禁用地图生成，启用模型训练
        """
        # 禁用地图生成
        context.map_generation_config = MapGenerationConfig(
            allowed_types=[]  # 空列表表示不生成任何地图
        )

    def format_output(self, context: ExecutionContext) -> Dict[str, Any]:
        """返回模型路径的 JSON

        Returns:
            包含模型路径和相关元数据的字典
        """
        model_paths = getattr(context.generator.report_data, 'model_paths', {}) or {}

        return {
            "mode": self.mode_name,
            "models": {
                indicator: {
                    "model_path": path,
                    "indicator": indicator,
                }
                for indicator, path in model_paths.items()
            },
            "output_dir": context.generator.output_dir,
        }
