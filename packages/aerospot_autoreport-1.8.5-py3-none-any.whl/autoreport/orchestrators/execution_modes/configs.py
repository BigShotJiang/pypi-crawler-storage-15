from dataclasses import dataclass
from typing import List, Optional

@dataclass
class RenderingConfig:
    """渲染配置数据类，用于传递渲染相关的配置参数

    替代直接修改global_rendering_config全局状态，实现配置隔离
    """
    # Colorbar 配置
    colorbar_label_font: int = 12
    colorbar_tick_font: int = 10

    # 标题配置
    title_font: int = 12

    # 其他渲染配置
    dpi: int = 300
    figsize: tuple = (10, 8)

@dataclass
class MapGenerationConfig:
    """地图生成配置数据类，用于传递地图生成相关的配置参数
    
    替代动态设置map_types_filter属性，实现显式依赖注入
    """
    # 允许的地图类型列表
    allowed_types: Optional[List[str]] = None
    
    # 是否生成独立的colorbar文件
    generate_standalone_colorbar: bool = False
    
    # 插值配置
    interpolation_method: str = "kriging"
    
    # 边界检测配置
    boundary_detection_method: str = "alpha_shape"
    
    # 其他地图生成配置
    grid_resolution: int = 100
    mask_value: float = -9999.0
