from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional
from dataclasses import dataclass
from enum import Enum
from .configs import RenderingConfig, MapGenerationConfig
from ..config.execution_config import ExecutionModeConfig

class ExecutionStage(Enum):
    """标准执行阶段枚举"""
    INIT = "init"
    LOAD_CONFIG = "load_config"
    PROCESS_DATA = "process_data"
    GENERATE_MAPS = "generate_maps"
    SAVE_CONFIG = "save_config"
    GENERATE_STRUCTURE = "generate_structure"
    GENERATE_REPORT = "generate_report"
    TRAIN_MODEL = "train_model"  # NEW
    OUTPUT_RESULT = "output_result"

@dataclass
class ExecutionContext:
    """执行上下文（不可变）"""
    generator: Any  # AeroSpotReportGenerator
    config_path: str
    output_dir: str
    cache_enabled: bool
    start_time: float

    # 配置对象（显式传递，替代全局状态和动态属性）
    rendering_config: RenderingConfig = None
    map_generation_config: MapGenerationConfig = None

    # 执行结果（可变）
    result: Dict[str, Any] = None

class ExecutionModeStrategy(ABC):
    """执行模式策略抽象基类

    定义执行模式的核心行为和配置方式。

    所有执行模式（完整报告、仅热力图、仅建模）都应该继承此类，
    并实现所有抽象方法以支持新架构的配置注入。

    Stage 2 改进：
    - 添加 get_execution_config() 抽象方法，返回类型安全的配置对象
    - 配置由策略返回，而不是硬编码到全局状态
    - 支持 ConfigProvider 显式注入模式
    """

    @property
    @abstractmethod
    def mode_name(self) -> str:
        """模式名称

        Returns:
            执行模式的名称（如 'full'、'heatmap_only'、'modeling_only'）

        Examples:
            >>> strategy.mode_name
            'full'
        """
        pass

    @property
    @abstractmethod
    def required_stages(self) -> List[ExecutionStage]:
        """该模式需要执行的阶段列表（按顺序）

        Returns:
            按执行顺序排列的 ExecutionStage 列表

        Examples:
            >>> strategy.required_stages
            [ExecutionStage.INIT, ExecutionStage.LOAD_CONFIG, ...]
        """
        pass

    @abstractmethod
    def get_execution_config(self, context: ExecutionContext) -> ExecutionModeConfig:
        """获取此执行模式的类型安全的配置对象（Stage 2 新增）

        返回包含模式特定的所有配置参数的 ExecutionModeConfig 及其子类实例。
        这个方法替代了之前通过 configure_environment() 修改全局状态的做法。

        Args:
            context: 执行上下文

        Returns:
            ExecutionModeConfig 的子类实例（如 FullReportConfig、HeatmapOnlyConfig 等）

        Examples:
            >>> config = strategy.get_execution_config(context)
            >>> config.rendering_config.dpi
            300
        """
        pass

    @abstractmethod
    def configure_environment(self, context: ExecutionContext) -> None:
        """配置模式特定的环境（如全局配置）

        在执行阶段前调用，用于设置模式特定的参数。

        注意：在新架构中，此方法与 get_execution_config() 一起工作：
        - get_execution_config() 返回新的配置对象
        - configure_environment() 可以用于其他初始化（可选）
        """
        pass

    @abstractmethod
    def format_output(self, context: ExecutionContext) -> Dict[str, Any]:
        """格式化输出结果

        在所有阶段执行完成后调用，返回模式特定的输出格式。
        """
        pass

    def should_skip_stage(
        self,
        stage: ExecutionStage,
        context: ExecutionContext
    ) -> bool:
        """判断是否跳过某个阶段（钩子方法）

        默认实现：只执行 required_stages 中的阶段。
        子类可以覆盖以实现更复杂的逻辑。
        """
        return stage not in self.required_stages

    def on_stage_success(
        self,
        stage: ExecutionStage,
        context: ExecutionContext
    ) -> None:
        """阶段成功后的钩子（可选）"""
        pass

    def on_stage_failure(
        self,
        stage: ExecutionStage,
        context: ExecutionContext,
        error: Exception
    ) -> bool:
        """阶段失败后的钩子

        Returns:
            bool: True 表示继续执行，False 表示中止流程
        """
        return False  # 默认：失败即中止