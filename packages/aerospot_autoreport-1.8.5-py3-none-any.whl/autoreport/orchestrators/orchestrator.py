#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""编排器基类定义

提供所有编排器的统一接口和协议，确保模块间通信的一致性。
"""

import logging
from abc import ABC, abstractmethod
from typing import Optional

from ..models.report_data import ReportData

logger = logging.getLogger(__name__)


class Orchestrator(ABC):
    """所有编排器的抽象基类

    定义了编排器的核心接口，包括执行、验证和错误处理等方法。
    所有具体的编排器都应该继承此基类。

    属性：
        logger: 日志记录器实例

    示例：
        >>> class MyOrchestrator(Orchestrator):
        ...     def execute(self, data: ReportData) -> ReportData:
        ...         # 实现具体逻辑
        ...         return data
        ...     def validate_input(self, data: ReportData) -> bool:
        ...         # 实现输入验证
        ...         return True
    """

    def __init__(self) -> None:
        """初始化编排器

        子类应该调用 super().__init__() 来初始化基类。
        """
        self.logger = logging.getLogger(self.__class__.__name__)

    @abstractmethod
    def execute(self, data: ReportData) -> ReportData:
        """执行编排流程

        这是编排器的核心方法，包含了该编排阶段的所有业务逻辑。

        Args:
            data: 输入的报告数据模型

        Returns:
            ReportData: 处理后的报告数据模型

        Raises:
            Exception: 处理过程中遇到的任何错误（具体异常类型由子类定义）
        """
        pass

    @abstractmethod
    def validate_input(self, data: ReportData) -> bool:
        """验证输入数据的有效性

        在执行之前对输入数据进行验证，确保数据满足该编排阶段的要求。

        Args:
            data: 需要验证的报告数据模型

        Returns:
            bool: 验证通过返回 True；失败返回 False
        """
        pass

    def validate_and_execute(self, data: ReportData) -> ReportData:
        """验证输入并执行编排流程

        这是一个便利方法，组合了验证和执行步骤。
        子类通常不需要覆盖此方法。

        Args:
            data: 输入的报告数据模型

        Returns:
            ReportData: 处理后的报告数据模型

        Raises:
            ValueError: 输入验证失败时
            Exception: 执行过程中遇到的错误
        """
        if not self.validate_input(data):
            error_msg = (
                f"{self.__class__.__name__} 输入验证失败: "
                f"报告数据不满足该编排阶段的要求"
            )
            self.logger.error(error_msg)
            raise ValueError(error_msg)

        self.logger.info(f"开始执行 {self.__class__.__name__}")
        result = self.execute(data)
        self.logger.info(f"{self.__class__.__name__} 执行完成")

        return result

    def get_stage_name(self) -> str:
        """获取该编排器所处的流程阶段名称

        Returns:
            str: 阶段名称（通常是类名去掉 'Orchestrator' 后缀）
        """
        class_name = self.__class__.__name__
        if class_name.endswith("Orchestrator"):
            return class_name[:-12]  # 去掉 'Orchestrator' 后缀
        return class_name
