"""执行上下文模块

提供类型安全的执行上下文和结果模型。
"""

from .execution_context_v2 import ExecutionContextV2
from .execution_result import ExecutionResult

__all__ = [
    "ExecutionContextV2",
    "ExecutionResult",
]
