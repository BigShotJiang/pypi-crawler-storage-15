#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
AeroSpot自动化报告生成工具V2版本 (优化版)

主要功能：
1. 从远程服务器下载数据资源
2. 解压数据文件，提取必要信息
3. 处理无人机数据和人工采样数据
4. 根据数据生成报告结构配置
5. 生成完整的遥感报告文档
"""

import argparse
import json
import logging
import os
import sys
from datetime import datetime
from typing import Any, Dict, Optional, Tuple, cast

from dotenv import load_dotenv

from .core.config_models import get_default_app_config
from .core.configuration_service import ConfigurationService
from .core.report_data_builder import ReportDataBuilder
from .core import ErrorHandler, safe_operation, configure_logging
from .core import (
    ReportGenerationError,
)

# 导入自定义模块
from .core.boundary_manager import BoundaryManager
from .core.extractor import ZipExtractor
from .core.resource_manager import ResourceManager
from .processor.data import DataProcessor
from .utils.path import PathManager

# 导入编排器（延迟导入避免循环依赖）
from .processor.data.prediction_saver import PredictionSaver

# 加载环境变量
load_dotenv()

# 获取logger
logger = logging.getLogger(__name__)


class AeroSpotReportGenerator:
    """AeroSpot报告生成器主类 (优化版)"""

    def __init__(
        self,
        output_dir: Optional[str] = None,
        config: Optional[Dict[str, Any]] = None,
        cache_enabled: Optional[bool] = None,
    ):
        """初始化报告生成器

        Args:
            output_dir: 输出目录，如果为None则使用默认目录
            config: 配置字典或配置文件路径
            cache_enabled: 是否启用缓存，如果为None则使用默认值
        """
        # 设置输出目录
        if output_dir is None:
            # 使用默认的输出目录
            self.output_dir = os.path.join(
                os.path.dirname(os.path.dirname(__file__)), "AutoReportResults"
            )
        else:
            self.output_dir = output_dir

        # 确保输出目录存在
        os.makedirs(self.output_dir, exist_ok=True)

        # 初始化路径管理器
        self.path_manager = PathManager(self.output_dir)

        # 日志系统已由 main() 函数配置，避免重复配置生成多个日志文件
        # configure_logging() 调用已在 main() 函数中处理

        # 初始化错误���理器
        self.error_handler = ErrorHandler(logger)

        # 初始化配置服务（新）
        self.config_service: Optional[ConfigurationService] = None
        # 保留字典形式用于向后兼容
        self.config: Dict[str, Any] = {}

        # 加载配置
        if isinstance(config, str) and os.path.exists(config):
            self.load_config(config)
        elif isinstance(config, dict):
            self._setup_config_from_dict(config)
        else:
            self._setup_default_config()

        # 初始化资源管理器
        if cache_enabled is not None:
            self.resource_manager = ResourceManager(
                self.path_manager, cache_enabled=cache_enabled
            )
        else:
            self.resource_manager = ResourceManager(self.path_manager)

        # 初始化解压器
        self.extractor = ZipExtractor(self.path_manager)

        # 初始化数据处理器
        self.data_processor = DataProcessor(config_service=self.config_service)

        # 初始化边界管理器（暂时为None，在download_resources后初始化）
        self.boundary_manager: Optional[BoundaryManager] = None

        # 创建报告数据,用于收集信息
        self.create_report_data()

        logger.info(f"初始化完成，输出目录: {self.output_dir}")

        self.print_info: Dict[str, str] = {}

        # 初始化路径追踪属性
        self.last_config_path: Optional[str] = None
        self.last_report_path: Optional[str] = None

    def _setup_config_from_dict(self, config_dict: Dict[str, Any]) -> None:
        """从字典设置配置

        Args:
            config_dict: 配置字典
        """
        try:
            self.config_service = ConfigurationService.load_from_dict(config_dict)
            self.config_service.validate()
            # 为向后兼容保留字典形式
            self.config = self.config_service.to_dict()
            logger.info("从字典加载配置成功")
        except (ValueError, KeyError, TypeError) as e:
            logger.error(f"配置验证失败: {e}", exc_info=True)
            # 降级使用默认配置
            self._setup_default_config()

    def _setup_default_config(self) -> None:
        """使用默认配置"""
        try:
            self.config_service = ConfigurationService(get_default_app_config())
            self.config = self.config_service.to_dict()
            logger.info("使用默认配置")
        except Exception as e:
            logger.error(f"初始化默认配置失败: {e}")
            raise

    def create_report_data(self) -> None:
        """创建报告数据结构

        使用 ReportDataBuilder 从配置服务构建报告数据。
        """
        # 确保配置服务已初始化
        if self.config_service is None:
            logger.warning("配置服务未初始化，使用默认配置")
            self._setup_default_config()

        # 类型收窄：在上面的if块中已保证config_service不为None
        config_service = cast(ConfigurationService, self.config_service)

        # 使用 ReportDataBuilder 构建报告数据
        builder = ReportDataBuilder(config_service, self.output_dir)
        self.report_data = builder.build()
        logger.info("已创建报告数据结构")

    @safe_operation(error_msg="加载配置文件失败", default_return=False)
    def load_config(self, config_path: str) -> bool:
        """加载并验证配置文件

        Args:
            config_path: 配置文件路径

        Returns:
            bool: 是否成功加载
        """
        try:
            # 使用新的配置服务加载
            self.config_service = ConfigurationService.load_from_file(config_path)
            self.config_service.validate()

            # 为向后兼容保留字典形式
            self.config = self.config_service.to_dict()

            logger.info(f"成功加载配置文件: {config_path}")

            # 输出配置的关键信息
            if self.config_service is not None:
                config_service = cast(ConfigurationService, self.config_service)
                logger.info(f"数据根目录: {config_service.get_data_root()}")

                company = config_service.get_company_info()
                logger.info(f"公司名称: {company.name}")

                # 资源URL
                logger.info("资源URL:")
                urls = config_service.get_resource_urls()
                for key, value in urls.items():
                    if isinstance(value, list):
                        display_value = f"{value}" if value else "未指定"
                    elif value:
                        display_value = (
                            f"{value[:30]}..." if len(str(value)) > 30 else value
                        )
                    else:
                        display_value = "未指定"
                    logger.info(f"  {key}: {display_value}")

                sources = config_service.get_pollution_sources()
                logger.info(
                    f"污染源信息: {', '.join(sources.keys()) if sources else '未指定'}"
                )

            return True
        except Exception as e:
            logger.error(f"加载配置文件失败: {e}")
            return False

    @safe_operation(error_msg="处理数据失败", default_return=False)
    def process_data(self) -> bool:
        """处理数据文件和资源 - 委托给编排器

        包含资源下载和数据处理两个阶段。

        Returns:
            bool: 是否处理成功
        """
        logger.info("开始数据和资源处理流程...")

        # 延迟导入避免循环依赖
        from .orchestrators.resource_and_data_orchestrator import (
            ResourceAndDataOrchestrator,
        )

        # 使用 ResourceAndDataOrchestrator 处理资源下载和数据处理
        orchestrator = ResourceAndDataOrchestrator(
            config_service=self.config_service,
            resource_manager=self.resource_manager,
            boundary_manager=self.boundary_manager,
            path_manager=self.path_manager,
            data_processor=self.data_processor,
            extractor=self.extractor,
        )

        # orchestrate() 现在返回 ReportData 对象
        result = orchestrator.orchestrate(self.report_data)

        # 检查是否成功
        success = result.processing_state == "success"

        if success:
            # 更新报告数据
            self.report_data = result
            # 更新 boundary_manager（在资源下载后由 orchestrator 初始化）
            self.boundary_manager = orchestrator.boundary_manager
        else:
            # 记录失败原因
            logger.error(f"数据处理失败: {result.error_message}")

        return success

    @safe_operation(error_msg="生成报告结构失败", default_return=None)
    def generate_config(self) -> Optional[str]:
        """生成报告配置

        使用 ReportGenerationOrchestrator 生成报告结构

        Returns:
            str: 报告结构文件路径，失败返回None
        """
        logger.info("开始生成报告结构...")

        # 延迟导入避免循环依赖
        from .orchestrators.report_generation_orchestrator import (
            ReportGenerationOrchestrator,
        )

        # 使用编排器生成报告配置
        orchestrator = ReportGenerationOrchestrator(
            config_service=self.config_service,
            path_manager=self.path_manager,
        )
        config_path = orchestrator.generate_config(self.report_data)

        if not config_path:
            raise ReportGenerationError("生成报告结构失败")

        logger.info(f"报告结构已生成: {config_path}")

        # 读取并记录报告结构信息
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                structure = json.load(f)

            # 验证结构完整性
            if isinstance(structure.get("chapters"), list):
                logger.info(f"报告结构包含 {len(structure['chapters'])} 个章节")
                for chapter in structure["chapters"]:
                    logger.info(
                        f"  - 第{chapter.get('chapter_num', '?')}章：{chapter.get('title', '未命名')}"
                    )
        except (FileNotFoundError, json.JSONDecodeError, ValueError) as e:
            logger.warning(f"无法完全记录报告结构信息: {e}")

        self.last_config_path = config_path
        return config_path

    @safe_operation(error_msg="生成报告失败", default_return=False)
    def generate_report(self, config_path: str) -> bool:
        """生成报告

        使用 ReportGenerationOrchestrator 生成报告文档

        Args:
            config_path: 配置文件路径（报告结构JSON文件）

        Returns:
            bool: 是否生成成功
        """
        logger.info("开始生成报告...")

        # 延迟导入避免循环依赖
        from .orchestrators.report_generation_orchestrator import (
            ReportGenerationOrchestrator,
        )

        # 使用编排器生成报告
        orchestrator = ReportGenerationOrchestrator(
            config_service=self.config_service,
            path_manager=self.path_manager,
        )
        success = orchestrator.generate_report(config_path, self.report_data)

        if not success:
            raise ReportGenerationError("报告生成失败")

        # 获取报告路径并保存到 print_info
        report_path = orchestrator.get_last_report_path()
        if report_path:
            self.print_info["report"] = report_path
            self.last_report_path = report_path
            logger.info(f"报告已生成: {report_path}")
        else:
            raise ReportGenerationError("无法获取报告路径")

        return True

    @safe_operation(error_msg="保存配置失败", default_return=None)
    def save_processed_config(self) -> Optional[str]:
        """保存处理后的配置

        Returns:
            str: 保存的配置文件路径，失败返回None
        """
        output_path = self.path_manager.get_file_path(
            "reports", "processed_config.json"
        )
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(self.config, f, indent=2, ensure_ascii=False)

        logger.info(f"处理后的配置已保存到: {output_path}")
        self.last_config_path = output_path
        return output_path

    @safe_operation(error_msg="创建指标卫星图失败", default_return=False)
    def generate_indicator_maps(self) -> bool:
        """利用satellite_image和各指标的反演值生成图片

        简化的地图生成主入口，直接处理指标流程。

        Returns:
            bool: 是否成功生成所有地图。若无预处理数据或渲染器初始化失败则返回 False

        Raises:
            ReportGenerationError: 地图生成过程中的异常（通过 @safe_operation 装饰器处理）
        """
        logger.info("开始地图生成流程...")

        from .orchestrators.map_generation_orchestrator import (
            MapGenerationOrchestrator,
        )

        orchestrator = MapGenerationOrchestrator(
            config_service=self.config_service,
            path_manager=self.path_manager,
            boundary_manager=self.boundary_manager,
            map_generation_config=getattr(self, "map_generation_config", None),
            rendering_config=getattr(self, "rendering_config", None),
        )

        # 调用generate返回ReportData，更新self.report_data
        result = orchestrator.generate(self.report_data)
        self.report_data = result
        # 检查处理状态
        return result.processing_state != "failed"

    @safe_operation(error_msg="保存模型文件到.bin文件失败", default_return=False)
    def save_model_func(self) -> bool:
        """将训练好的水质模型系数加密保存到 .bin 文件

        使用 PredictionSaver 将 report_data 中的模型函数加密存储，采用 AES 加密算法。

        架构设计说明:
            加密密钥 (password, salt, iv) 硬编码在此代码中。
            这是有意的架构设计，原因如下：

            1. 项目使用 Nuitka 编译为 .so 二进制文件分发
            2. 密钥在编译后被嵌入到二进制中
            3. 从二进制中提取密钥需要复杂的逆向工程
            4. 避免了在 .env 配置文件中暴露敏感信息
            5. 简化了部署流程：只需分发二进制文件

        安全考虑:
            - 如需更换密钥，请修改此代码并重新编译
            - 日志记录中绝不能输出这些密钥值
            - 代码审查应检查是否有意外的密钥泄露

        Returns:
            bool: 是否成功保存。如果 report_data 中没有模型函数则返回 True

        Raises:
            OSError: 文件写入失败时（通过 @safe_operation 装饰器处理）

        Examples:
            >>> generator = AeroSpotReportGenerator(output_dir="./output", config="config.json")
            >>> generator.process_data()
            >>> success = generator.save_model_func()
        """
        # 从 prediction_results 获取模型函数（不再从 config 读取）
        model_func = None
        if self.report_data.prediction_results is not None:
            model_func = self.report_data.prediction_results.model_func

        if not model_func:
            logger.warning("建模结果为空，没有结果可以加密保存")
            return True

        # 使用 PredictionSaver 保存加密的模型
        saver = PredictionSaver()
        success = saver.save_model(
            model_func=model_func,
            output_path=os.path.join(self.path_manager.get_path("models"), "model.bin"),
            password=b"water_quality_analysis_key",  # 编译时嵌入
            salt=b"water_quality_salt",
            iv=b"fixed_iv_16bytes",
        )

        if success:
            saved_files = saver.get_saved_files()
            if "model" in saved_files:
                model_path = saved_files["model"]
                self.print_info["bin"] = os.path.abspath(model_path)
                logger.info(f"模型已加密保存到: {model_path}")
        else:
            logger.error("加密保存模型失败")

        return success

    def get_last_config_path(self) -> Optional[str]:
        """获取最后一次生成的配置文件路径

        Returns:
            Optional[str]: 配置文件路径，若无则返回 None
        """
        return self.last_config_path

    def get_last_report_path(self) -> Optional[str]:
        """获取最后一次生成的报告文件路径

        Returns:
            Optional[str]: 报告文件路径，若无则返回 None
        """
        return self.last_report_path


def check_pipe_input() -> bool:
    """检查是否有管道输入"""
    try:
        return not sys.stdin.isatty()
    except Exception:
        # 在某些环境下isatty可能不可用
        import select

        try:
            ready, _, _ = select.select([sys.stdin], [], [], 0)
            return bool(ready)
        except Exception:
            # 如果所有检测方法都失败，则默认为没有管道输入
            return False


def update_output_readme(base_dir: str, timestamp: str, report_path: str) -> None:
    """更新输出目录的README文件，添加本次报告生成记录

    Args:
        base_dir: 基础输出目录
        timestamp: 时间戳
        report_path: 报告文件路径
    """
    readme_path = os.path.join(base_dir, "README.md")

    # 如果README不存在，创建一个新的
    if not os.path.exists(readme_path):
        with open(readme_path, "w", encoding="utf-8") as f:
            f.write("# AeroSpot遥感报告生成记录\n\n")
            f.write("本文件自动记录每次报告生成的时间和位置。\n\n")
            f.write("## 生成历史\n\n")

    # 添加新的记录
    with open(readme_path, "a", encoding="utf-8") as f:
        report_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        relative_path = os.path.relpath(report_path, base_dir)
        f.write(f"- **{report_time}**: 生成报告 `{relative_path}`\n")

    logger.info(f"已更新报告生成记录: {readme_path}")


def main() -> int:
    """主函数 - 使用 PipelineV2 (新一代管道)

    Features:
        - 依赖注入架构
        - 动态阶段处理
        - 多执行模式支持
        - 内置性能追踪

    Returns:
        int: 退出代码（0=成功, 1=失败）
    """
    # 解析命令行参数
    parser = argparse.ArgumentParser(
        description="AeroSpot自动化报告生成工具V3 - Pipeline版本"
    )
    parser.add_argument("config", nargs="?", help="配置文件路径")
    parser.add_argument("-o", "--output", help="输出目录")
    parser.add_argument(
        "--cache-enabled",
        type=str,
        default="false",
        help="是否启用缓存 (true/false)",
    )
    args = parser.parse_args()

    # 解析缓存设置
    cache_enabled = args.cache_enabled.lower() in ("true", "1", "yes", "on")

    # 确定配置文件路径
    config_path = get_config_path(args)
    if not config_path:
        logger.error("无法获取配置文件路径")
        return 1

    # 加载配置文件
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            config = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError) as e:
        logger.error(f"无法加载配置文件 {config_path}: {str(e)}")
        return 1

    # 创建输出目录
    output_dir, original_output_dir, timestamp = create_output_directory(args, config)
    if not output_dir:
        return 1

    # 配置日志记录
    log_path = os.path.join(output_dir, "logs")
    os.makedirs(log_path, exist_ok=True)
    configure_logging(log_dir=log_path, level=logging.INFO, console=False)

    logger.info(f"输出目录: {output_dir}")
    logger.info(f"配置文件: {config_path}")
    logger.info(f"缓存启用: {cache_enabled}")

    # 创建并执行 PipelineV2（新版本）
    from .orchestrators import PipelineV2
    import time

    start_time = time.time()
    logger.info("=" * 60)
    logger.info("使用新的 PipelineV2 管道进行报告生成...")
    logger.info("=" * 60)

    pipeline = PipelineV2(config_path=config_path, output_dir=output_dir)

    # 执行报告生成流程
    result = pipeline.execute()

    # 记录总耗时
    total_duration = time.time() - start_time

    # 处理结果
    if result.success:
        report_path = result.get_path("report") or os.path.join(
            output_dir, "reports", "AeroSpotReport自动报告.docx"
        )

        # 更新README记录
        if os.path.exists(report_path):
            update_output_readme(original_output_dir, timestamp, report_path)

            logger.info("=" * 60)
            logger.info("报告生成成功 (PipelineV2)")
            logger.info("=" * 60)
            logger.info(f"报告路径: {report_path}")
            logger.info(f"总耗时: {total_duration:.2f} 秒")

            # 输出各阶段执行时间
            if result.completed_stages:
                logger.info("已完成的阶段：")
                for stage_name in result.completed_stages:
                    logger.info(f"  [完成] {stage_name}")

            if result.failed_stages:
                logger.info("失败的阶段：")
                for stage_name in result.failed_stages:
                    logger.info(f"  [失败] {stage_name}")

            # JSON输出已由pipeline._output_result()处理，在这里直接返回
            return 0
        else:
            logger.warning("报告生成完成，但报告文件未找到")
            logger.warning(f"   输出目录: {output_dir}")
            return 0
    else:
        logger.error("=" * 60)
        logger.error("报告生成失败 (PipelineV2)")
        logger.error("=" * 60)
        logger.error(f"错误信息: {result.error if result.error else '未知错误'}")
        logger.error(f"总耗时: {total_duration:.2f} 秒")

        # 输出失败阶段详情
        if result.failed_stages:
            logger.error("失败阶段详情：")
            for stage_name in result.failed_stages:
                logger.error(f"  [失败] {stage_name}")

        return 1


def get_config_path(args: Any) -> Optional[str]:
    """获取配置文件路径

    Args:
        args: 命令行参数

    Returns:
        str: 配置文件路径或None
    """
    # 检查是否有管道输入
    if check_pipe_input():
        # 从标准输入读取内容
        try:
            stdin_content = sys.stdin.read().strip()
            if stdin_content:
                # 尝试将输入作为文件路径
                if os.path.exists(stdin_content):
                    return stdin_content
                else:
                    logger.error("从标准输入读取的文件路径无效")
                    return None
            else:
                logger.error("从标准输入读取的内容为空")
                return None
        except Exception as e:
            logger.error(f"读取标准输入时出错: {str(e)}")
            return None
    else:
        # 使用位置参数的配置文件路径
        if args.config and os.path.exists(args.config):
            return args.config
        # 尝试使用默认配置文件
        else:
            default_config = os.path.join(
                os.path.dirname(os.path.abspath(__file__)), "test.json"
            )
            if os.path.exists(default_config):
                logger.info(f"使用默认配置文件: {default_config}")
                return default_config
            else:
                logger.error("未提供配置文件路径，也找不到默认配置文件")
                return None


def create_output_directory(args, config) -> Tuple[Optional[str], Optional[str], str]:
    """创建输出目录

    Args:
        args: 命令行参数
        config: 配置字典

    Returns:
        Tuple[Optional[str], Optional[str], str]: (输出目录, 原始输出目录, 时间戳)
    """
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    # 获取配置中的数据根目录
    data_root = config.get("data_root")

    if args.output:
        # 如果命令行指定了输出目录，优先使用
        original_output_dir = args.output
    elif data_root:
        # 如果配置文件中指定了data_root，直接使用
        original_output_dir = data_root
    else:
        logger.error("未指定输出目录，且配置文件中没有data_root")
        return None, None, timestamp

    # 在输出目录下创建时间戳子目录
    output_dir = os.path.join(original_output_dir, f"report_{timestamp}")
    os.makedirs(output_dir, exist_ok=True)
    logger.info(f"创建时间戳输出目录: {output_dir}")

    return output_dir, original_output_dir, timestamp
