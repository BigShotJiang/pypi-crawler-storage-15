"""
水质分级标准 Pydantic 模型

遵循 Python 项目开发准则，使用 Pydantic v2 进行配置验证和类型检查。
支持从 YAML 配置文件加载并自动验证。

Author: 水质建模团队
"""

from typing import Any, Dict, List

from pydantic import BaseModel, ConfigDict, Field, field_validator


# ================================================================================
# GB 3838-2002 国标分级映射表（���典格式，供其他模块使用）
# ================================================================================

INDICATOR_GRADE_CONFIG: Dict[str, Dict[str, Any]] = {
    # COD（化学需氧量，mg/L）- GB 3838-2002 标准
    "COD": {
        "thresholds": [15, 15, 20, 30, 40],
        "labels": ["Ⅰ类", "Ⅱ类", "Ⅲ类", "Ⅳ类", "Ⅴ类", "劣五类"],
        "colors": ["#1E90FF", "#00FF7F", "#FFFF00", "#FFA500", "#FF0000", "#8B0000"],
        "description": "化学需氧量（mg/L）",
    },
    # 氨氮 NH3-N（mg/L）
    "NH3-N": {
        "thresholds": [0.15, 0.5, 1.0, 1.5, 2.0],
        "labels": ["Ⅰ类", "Ⅱ类", "Ⅲ类", "Ⅳ类", "Ⅴ类", "劣五类"],
        "colors": ["#1E90FF", "#00FF7F", "#FFFF00", "#FFA500", "#FF0000", "#8B0000"],
        "description": "氨氮（mg/L）",
    },
    # 总磷 TP（mg/L）
    "TP": {
        "thresholds": [0.02, 0.1, 0.2, 0.3, 0.4],
        "labels": ["Ⅰ类", "Ⅱ类", "Ⅲ类", "Ⅳ类", "Ⅴ类", "劣五类"],
        "colors": ["#1E90FF", "#00FF7F", "#FFFF00", "#FFA500", "#FF0000", "#8B0000"],
        "description": "总磷（mg/L）",
    },
    # 总氮 TN（mg/L）
    "TN": {
        "thresholds": [0.2, 0.5, 1.0, 1.5, 2.0],
        "labels": ["Ⅰ类", "Ⅱ类", "Ⅲ类", "Ⅳ类", "Ⅴ类", "劣五类"],
        "colors": ["#1E90FF", "#00FF7F", "#FFFF00", "#FFA500", "#FF0000", "#8B0000"],
        "description": "总氮（mg/L）",
    },
    # 溶解氧 DO（mg/L，越高越好，分级反向）
    "DO": {
        "thresholds": [2, 3, 5, 6, 7.5],
        "labels": ["劣五类", "Ⅴ类", "Ⅳ类", "Ⅲ类", "Ⅱ类", "Ⅰ类"],
        "colors": ["#8B0000", "#FF0000", "#FFA500", "#FFFF00", "#00FF7F", "#1E90FF"],
        "reverse": True,
        "description": "溶解氧（mg/L，越高越好）",
    },
    # 高锰酸盐指数 CODMn（mg/L）
    "CODMn": {
        "thresholds": [2, 4, 6, 10, 15],
        "labels": ["Ⅰ类", "Ⅱ类", "Ⅲ类", "Ⅳ类", "Ⅴ类", "劣五类"],
        "colors": ["#1E90FF", "#00FF7F", "#FFFF00", "#FFA500", "#FF0000", "#8B0000"],
        "description": "高锰酸盐指数（mg/L）",
    },
    # 五日生化需氧量 BOD5（mg/L）
    "BOD": {
        "thresholds": [3, 3, 4, 6, 10],
        "labels": ["Ⅰ类", "Ⅱ类", "Ⅲ类", "Ⅳ类", "Ⅴ类", "劣五类"],
        "colors": ["#1E90FF", "#00FF7F", "#FFFF00", "#FFA500", "#FF0000", "#8B0000"],
        "description": "五日生化需氧量（mg/L）",
    },
}


class IndicatorGradeConfig(BaseModel):
    """单个指标的分级配置"""

    full_name: str = Field(..., description="指标全名")

    unit: str = Field(..., description="指标单位")

    description: str = Field(..., description="指标描述")

    thresholds: List[float] = Field(
        ...,
        description="分级阈值列表（5 个阈值对应 6 个等级）",
        min_length=4,
        max_length=5,
    )

    labels: List[str] = Field(
        ..., description="分级标签列表（6 个标签）", min_length=6, max_length=6
    )

    colors: List[str] = Field(
        ..., description="分级颜色列表（6 个颜色）", min_length=6, max_length=6
    )

    reverse: bool = Field(default=False, description="是否反向分级（如 DO，越高越好）")

    @field_validator("colors")
    @classmethod
    def validate_hex_colors(cls, v: List[str]) -> List[str]:
        """验证颜色代码格式（16 进制）"""
        for color in v:
            if not (
                isinstance(color, str) and color.startswith("#") and len(color) == 7
            ):
                raise ValueError(f"颜色代码格式错误: '{color}'，应为 '#RRGGBB' 格式")
            try:
                int(color[1:], 16)
            except ValueError:
                raise ValueError(f"无效的十六进制颜色代码: '{color}'")
        return v

    @field_validator("thresholds")
    @classmethod
    def validate_thresholds_ordered(cls, v: List[float]) -> List[float]:
        """验证阈值是否按升序排列"""
        if not all(v[i] <= v[i + 1] for i in range(len(v) - 1)):
            raise ValueError("阈值必须按升序排列")
        return v


class WaterQualityGradesConfig(BaseModel):
    """完整的水质分级配置"""

    indicator_units: dict[str, str] = Field(..., description="指标单位映射")

    indicators: dict[str, IndicatorGradeConfig] = Field(
        ..., description="指标分级配置字典"
    )

    color_scheme: dict[str, str] = Field(..., description="分级颜色标准（通用配置）")

    def get_indicator_config(self, indicator: str) -> IndicatorGradeConfig | None:
        """获取指定指标的分级配置

        Args:
            indicator: 指标名称

        Returns:
            IndicatorGradeConfig | None: 指标配置，若不存在返回 None

        Examples:
            >>> config = grades_cfg.get_indicator_config("COD")
            >>> if config:
            ...     print(config.thresholds)
        """
        return self.indicators.get(indicator)

    def get_unit(self, indicator: str) -> str | None:
        """获取指标的单位

        Args:
            indicator: 指标名称

        Returns:
            str | None: 单位字符串，若不存在返回 None

        Examples:
            >>> unit = config.get_unit("COD")
            >>> print(unit)  # "mg/L"
        """
        return self.indicator_units.get(indicator)

    def get_color_for_value(self, indicator: str, value: float) -> str | None:
        """根据指标值获取对应的分级颜色

        Args:
            indicator: 指标名称
            value: 指标值

        Returns:
            str | None: 对应的颜色（十六进制），如 '#FF0000'

        Examples:
            >>> color = config.get_color_for_value("COD", 25)
            >>> print(color)  # "#FFA500"
        """
        indicator_config = self.get_indicator_config(indicator)
        if indicator_config is None:
            return None

        thresholds = indicator_config.thresholds
        labels = indicator_config.labels
        colors = indicator_config.colors

        # 确定值在哪个等级
        # 无论正向还是反向分级，逻辑相同：
        # 阈值：[a, b, c, d, e]，标签：[label0, label1, label2, label3, label4, label5]
        # value < a -> label0 (colors[0])
        # a <= value < b -> label1 (colors[1])
        # ...
        # value >= e -> label5 (colors[5])
        for i, threshold in enumerate(thresholds):
            if value < threshold:
                return colors[i]
        return colors[-1]  # 最后的等级

    def get_grade_label(self, indicator: str, value: float) -> str | None:
        """根据指标值获取分级标签

        Args:
            indicator: 指标名称
            value: 指标值

        Returns:
            str | None: 分级标签，如 'Ⅲ类'

        Examples:
            >>> label = config.get_grade_label("COD", 25)
            >>> print(label)  # "Ⅳ类"
        """
        indicator_config = self.get_indicator_config(indicator)
        if indicator_config is None:
            return None

        thresholds = indicator_config.thresholds
        labels = indicator_config.labels

        # 确定值在哪个等级
        # 无论正向还是反向分级，逻辑相同：
        # 阈值：[a, b, c, d, e]，标签：[label0, label1, label2, label3, label4, label5]
        # value < a -> label0
        # a <= value < b -> label1
        # ...
        # value >= e -> label5
        for i, threshold in enumerate(thresholds):
            if value < threshold:
                return labels[i]
        return labels[-1]  # 最后的等级

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "indicator_units": {
                    "COD": "mg/L",
                    "NH3-N": "mg/L",
                },
                "indicators": {
                    "COD": {
                        "full_name": "化学需氧量",
                        "unit": "mg/L",
                        "description": "COD 是衡量水体有机污染程度的主要指标",
                        "thresholds": [15, 15, 20, 30, 40],
                        "labels": ["Ⅰ类", "Ⅱ类", "Ⅲ类", "Ⅳ类", "Ⅴ类", "劣五类"],
                        "colors": [
                            "#1E90FF",
                            "#00FF7F",
                            "#FFFF00",
                            "#FFA500",
                            "#FF0000",
                            "#8B0000",
                        ],
                        "reverse": False,
                    }
                },
                "color_scheme": {
                    "excellent": "#1E90FF",
                    "good": "#00FF7F",
                },
            }
        }
    )
