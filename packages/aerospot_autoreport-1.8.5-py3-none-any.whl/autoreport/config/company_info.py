"""公司信息配置模块 - 向后兼容导入层

该模块从 core.config_models 中导入公司信息相关的常量，
以保持与旧代码的向后兼容性。

所有配置的单一定义来源是 src/autoreport/core/config_models.py
"""

# 从统一的core.config_models导入公司信息常量
from ..core.config_models import DEFAULT_COMPANY_INFO, DEFAULT_IMAGES_DIR

__all__ = ["DEFAULT_COMPANY_INFO", "DEFAULT_IMAGES_DIR"]

