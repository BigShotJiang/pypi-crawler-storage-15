#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Models package for AeroSpot AutoReport

本包包含所有数据模型定义，分为两个部分：
1. 报告数据模型 (report_data.py): ReportData, ImageResources
2. 强类型数据容器 (data_containers.py): ProcessedDataSet, PredictionResults, MapDataSet, ComparisonResult
3. 地图数据模型 (map_data.py): 地图相关的数据结构
"""

from .report_data import ReportData, ImageResources
from .data_containers import (
    ProcessedDataSet,
    PredictionResults,
    MapDataSet,
    ComparisonResult,
)
from .map_data import (
    IndicatorContext,
    InterpolationResult,
    MapPrepData,
    RenderingResult,
    SatelliteInfo,
)

__all__ = [
    # 报告数据模型
    "ReportData",
    "ImageResources",
    # 强类型数据容器
    "ProcessedDataSet",
    "PredictionResults",
    "MapDataSet",
    "ComparisonResult",
    # 地图数据模型
    "MapPrepData",
    "IndicatorContext",
    "InterpolationResult",
    "RenderingResult",
    "SatelliteInfo",
]
