#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
KML文件解析和区域提取工具模块 (改进版 - 使用Shapely)

功能：
1. 解析KML文件中的几何图形
2. 支持多边形、环形区域（Polygon with holes）
3. 支持按name标签分别提取保留和移除区域，并计算差集
4. 自动修复自交和无效几何体（使用智能循环buffer策略）
5. 转换为Shapely几何体或numpy掩码
"""

import os
import logging
from typing import List, Tuple, Optional
import xml.etree.ElementTree as ET

import numpy as np
from shapely.geometry import Polygon, MultiPolygon, Point
from shapely.ops import unary_union
from shapely.validation import explain_validity

logger = logging.getLogger(__name__)


def _fix_geometry_with_retry(
    geom: Optional[Polygon | MultiPolygon],
    max_attempts: int = 3,
    buffer_distance: float = 0,
) -> Optional[Polygon | MultiPolygon]:
    """
    修复自交/无效几何体，使用智能循环buffer策略

    采用循环而非递归，避免栈深度问题。动态停止条件：第一个有效结果立即返回。

    Args:
        geom: 输入的Shapely几何体（可为None）
        max_attempts: 最大修复尝试次数（默认3次）
        buffer_distance: buffer距离，0表示无扩展，仅修复拓扑 (默认0)

    Returns:
        修复后的有效几何体，或None（无法修复时）

    Algorithm:
        1. None检查 → 直接返回None
        2. 有效性检查 → 已有效则直接返回（快速路径）
        3. 循环修复：
           - 每次迭代应用buffer(buffer_distance)
           - 检查有效性 → 有效则立即返回（动态停止）
           - 无效则继续下一次迭代
        4. 所有尝试失败 → 记录详细错误后返回None

    Examples:
        >>> geom = Polygon([(0,0), (2,2), (2,0), (0,2), (0,0)])  # 自交多边形
        >>> fixed = _fix_geometry_with_retry(geom, max_attempts=3)
        >>> assert fixed is None or fixed.is_valid  # None或有效几何

    Notes:
        - 循环优于递归：避免Python递归深度限制(默认1000)
        - 动态停止优于固定迭代：通常1-2次就能修复，极少需要3次
        - buffer_distance=0是官方推荐做法：修复拓扑而不改变几何位置
    """
    if geom is None:
        return None

    # 快速路径：已有效则无需修复
    if geom.is_valid:
        logger.debug(f"几何体已有效，无需修复 ({type(geom).__name__})")
        return geom

    # 记录原始错误信息用于诊断
    original_error = explain_validity(geom)
    logger.warning(f"检测到无效几何体: {original_error}")

    # 循环修复（智能停止）
    for attempt in range(max_attempts):
        try:
            # 应用buffer修复
            geom = geom.buffer(buffer_distance)

            # 检查修复结果
            if geom.is_valid:
                logger.info(
                    f"第{attempt + 1}次修复成功 "
                    f"(buffer_distance={buffer_distance}, "
                    f"几何类型={type(geom).__name__})"
                )
                return geom
            else:
                # 仍无效，记录当前状态并继续下一次迭代
                current_error = explain_validity(geom)
                logger.debug(
                    f"第{attempt + 1}次修复后仍无效: {current_error} "
                    f"(将继续尝试，剩余{max_attempts - attempt - 1}次)"
                )
                continue

        except Exception as e:
            logger.error(
                f"第{attempt + 1}次修复异常 "
                f"(buffer_distance={buffer_distance}): {type(e).__name__}: {str(e)}"
            )
            if attempt == max_attempts - 1:
                # 最后一次尝试也失败了
                logger.error(f"修复异常导致无法继续")
            continue

    # 所有尝试都失败
    final_error = explain_validity(geom) if geom else "geom is None"
    logger.error(
        f"经过{max_attempts}次修复仍然无效。"
        f"原始错误={original_error}, "
        f"最终错误={final_error}, "
        f"最终几何类型={type(geom).__name__ if geom else 'None'}"
    )
    return None


def parse_kml_to_shapely_by_name(
    kml_path: str,
) -> Tuple[Optional[Polygon | MultiPolygon], Optional[Polygon | MultiPolygon]]:
    """
    从KML文件按name标签分别解析保留区域和移除区域

    Args:
        kml_path: KML文件路径

    Returns:
        (keep_geometry, remove_geometry)
        - keep_geometry: name="1"的所有多边形的并集
        - remove_geometry: name="0"的所有多边形的并集

    Examples:
        >>> keep_geom, remove_geom = parse_kml_to_shapely_by_name("boundary.kml")
        >>> final_geom = keep_geom.difference(remove_geom)

    Raises:
        FileNotFoundError: KML文件不存在
        ET.ParseError: KML文件格式错误
    """
    if not os.path.exists(kml_path):
        raise FileNotFoundError(f"KML文件不存在: {kml_path}")

    try:
        tree = ET.parse(kml_path)
        root = tree.getroot()

        # KML命名空间（支持有无命名空间的KML）
        namespaces = {"kml": "http://www.opengis.net/kml/2.2"}

        keep_polygons = []  # name="1"
        remove_polygons = []  # name="0"

        # 查找所有Placemark元素（需要考虑命名空间）
        placemarks = root.findall(".//kml:Placemark", namespaces)
        if not placemarks:
            # 尝试无命名空间查找（备用方案）
            placemarks = root.findall(".//Placemark")

        logger.info(f"KML文件中找到 {len(placemarks)} 个Placemark")

        for placemark in placemarks:
            # 获取name标签（需要考虑命名空间）
            name_elem = placemark.find("kml:name", namespaces)
            if name_elem is None:
                name_elem = placemark.find("name")

            if name_elem is None or name_elem.text is None:
                logger.warning("Placemark缺少name标签，跳过")
                continue

            name = name_elem.text.strip()

            # 解析Polygon（需要考虑命名空间）
            polygon_elem = placemark.find("kml:Polygon", namespaces)
            if polygon_elem is None:
                polygon_elem = placemark.find("Polygon")

            if polygon_elem is None:
                logger.warning(f"Placemark(name={name})缺少Polygon，跳过")
                continue

            shapely_polygon = _parse_polygon_element(polygon_elem, namespaces)

            if shapely_polygon is None:
                logger.warning(f"Placemark(name={name})的Polygon解析失败，跳过")
                continue

            # ✨ 新增：修复无效几何体（自交、重复点等）
            shapely_polygon = _fix_geometry_with_retry(shapely_polygon, max_attempts=3)

            if shapely_polygon is None:
                logger.error(
                    f"Placemark(name={name})的多边形无法修复，跳过此Placemark"
                )
                continue

            # 按name分类
            if name == "1":
                keep_polygons.append(shapely_polygon)
                logger.debug("Placemark(name=1)已添加到保留区域")
            elif name == "0":
                remove_polygons.append(shapely_polygon)
                logger.debug("Placemark(name=0)已添加到移除区域")
            else:
                logger.warning(f"未知的name值: {name}，忽略此Placemark")

        # 计算并集
        keep_geom = None
        remove_geom = None

        if keep_polygons:
            if len(keep_polygons) == 1:
                keep_geom = keep_polygons[0]
            else:
                keep_geom = unary_union(keep_polygons)

            # ✨ 新增：修复合并后的几何体
            keep_geom = _fix_geometry_with_retry(keep_geom, max_attempts=3)

            if keep_geom is None:
                logger.error("保留区域合并或修复失败，无法继续")
                raise ValueError("KML保留区域(name=1)无法修复")

            logger.info(f"保留区域: {len(keep_polygons)}个多边形已合并并修复")
        else:
            logger.warning("未找到任何保留区域(name=1)")

        if remove_polygons:
            if len(remove_polygons) == 1:
                remove_geom = remove_polygons[0]
            else:
                remove_geom = unary_union(remove_polygons)

            # ✨ 新增：修复合并后的几何体
            remove_geom = _fix_geometry_with_retry(remove_geom, max_attempts=3)

            if remove_geom is None:
                logger.warning("移除区域合并或修复失败，将不进行扣除")
                remove_geom = None
            else:
                logger.info(f"移除区域: {len(remove_polygons)}个多边形已合并并修复")
        else:
            logger.info("未找到任何移除区域(name=0)，将不进行扣除")

        return keep_geom, remove_geom

    except ET.ParseError as e:
        logger.error(f"KML文件解析失败: {kml_path}, 错误: {str(e)}")
        raise
    except Exception as e:
        logger.error(f"处理KML文件异常: {kml_path}, 错误: {str(e)}")
        raise


def _parse_polygon_element(polygon_elem, namespaces: dict) -> Optional[Polygon]:
    """
    解析单个Polygon元素

    支持：
    - outerBoundaryIs（外边界，必需）
    - innerBoundaryIs（内孔，可选，可多个）
    """
    try:
        # 解析外边界（需要考虑命名空间）
        xpath = "kml:outerBoundaryIs/kml:LinearRing/kml:coordinates"
        outer_boundary = polygon_elem.find(xpath, namespaces)
        if outer_boundary is None:
            # 尝试不带命名空间的路径
            outer_boundary = polygon_elem.find("outerBoundaryIs/LinearRing/coordinates")

        if outer_boundary is None or outer_boundary.text is None:
            logger.warning("Polygon缺少outerBoundaryIs")
            return None

        outer_coords = _parse_coordinates(outer_boundary.text.strip())
        if len(outer_coords) < 3:
            logger.warning("外边界坐标数少于3个，无法形成多边形")
            return None

        # 解析内孔（可选）（需要考虑命名空间）
        holes = []
        inner_xpath = "kml:innerBoundaryIs/kml:LinearRing/kml:coordinates"
        inner_boundaries = polygon_elem.findall(inner_xpath, namespaces)
        if not inner_boundaries:
            # 尝试不带命名空间的路径
            inner_boundaries = polygon_elem.findall(
                "innerBoundaryIs/LinearRing/coordinates"
            )

        for inner_coords_elem in inner_boundaries:
            if inner_coords_elem.text:
                inner_coords = _parse_coordinates(inner_coords_elem.text.strip())
                if len(inner_coords) >= 3:
                    holes.append(inner_coords)

        # 创建Shapely Polygon（支持holes）
        if holes:
            shapely_polygon = Polygon(outer_coords, holes=holes)
            outer_pts = len(outer_coords)
            inner_cnt = len(holes)
            logger.debug(f"创建Polygon: 外边界{outer_pts}点, 内孔{inner_cnt}个")
        else:
            shapely_polygon = Polygon(outer_coords)
            logger.debug(f"创建Polygon: {len(outer_coords)}点")

        return shapely_polygon

    except Exception as e:
        logger.error(f"解析Polygon元素失败: {str(e)}")
        return None


def _parse_coordinates(coords_text: str) -> List[Tuple[float, float]]:
    """
    解析KML坐标字符串

    格式: "lon1,lat1,0 lon2,lat2,0 lon3,lat3,0"
    返回: [(lon, lat), (lon, lat), ...]
    """
    coords = []
    try:
        for coord_str in coords_text.split():
            parts = coord_str.split(",")
            if len(parts) >= 2:
                try:
                    # 使用numpy.float64提高解析精度
                    import numpy as np
                    lon, lat = np.float64(parts[0]), np.float64(parts[1])
                    coords.append((lon, lat))
                except ValueError:
                    logger.warning(f"无法解析坐标: {coord_str}")
                    continue
    except Exception as e:
        logger.error(f"解析坐标文本失败: {str(e)}")

    return coords


def create_kml_boundary_mask(
    grid_lon: np.ndarray, grid_lat: np.ndarray, kml_path: str
) -> np.ndarray:
    """
    生成KML边界掩膜（支持多边形和环形，支持name=1 - name=0差集）

    Args:
        grid_lon: 经度网格 (M, N)
        grid_lat: 纬度网格 (M, N)
        kml_path: KML文件路径

    Returns:
        布尔掩膜数组，True表示在边界内
    """
    try:
        keep_geom, remove_geom = parse_kml_to_shapely_by_name(kml_path)

        if keep_geom is None:
            logger.error("未找到保留区域(name=1)，返回全False掩膜")
            return np.zeros_like(grid_lon, dtype=bool)

        # 计算差集：keep - remove
        if remove_geom is not None:
            final_geom = keep_geom.difference(remove_geom)
            logger.info("已应用差集操作: keep - remove")
        else:
            final_geom = keep_geom
            logger.info("未找到移除区域，仅使用保留区域")

        # 向量化点包含判断
        points = np.column_stack((grid_lon.ravel(), grid_lat.ravel()))
        mask = np.array([final_geom.contains(Point(lon, lat)) for lon, lat in points])

        # 重新塑形为网格形状
        mask = mask.reshape(grid_lon.shape)

        inside_count = np.sum(mask)
        logger.info(f"KML掩膜生成完成，边界内网格点数: {inside_count}/{mask.size}")

        return mask

    except Exception as e:
        logger.error(f"生成KML掩膜失败: {str(e)}")
        logger.warning("返回全True掩膜（无掩膜处理）")
        return np.ones_like(grid_lon, dtype=bool)


def get_kml_boundary_points(kml_path: str) -> Optional[np.ndarray]:
    """
    获取KML最终边界的顶点坐标（向后兼容）

    Returns:
        最终边界的外边界顶点坐标数组
    """
    try:
        keep_geom, remove_geom = parse_kml_to_shapely_by_name(kml_path)

        if keep_geom is None:
            return None

        # 计算差集
        if remove_geom is not None:
            final_geom = keep_geom.difference(remove_geom)
        else:
            final_geom = keep_geom

        # 提取外边界顶点
        if isinstance(final_geom, Polygon):
            coords = np.array(final_geom.exterior.coords[:-1])  # 排除闭合点
        elif isinstance(final_geom, MultiPolygon):
            # 对于MultiPolygon，返回凸包
            from scipy.spatial import ConvexHull

            all_coords = []
            for poly in final_geom.geoms:
                all_coords.extend(poly.exterior.coords[:-1])
            coords = np.array(all_coords)
            if len(coords) > 2:
                hull = ConvexHull(coords)
                coords = coords[hull.vertices]
        else:
            return None

        return coords

    except Exception as e:
        logger.error(f"获取KML边界点失败: {str(e)}")
        return None


# 向后兼容函数（保留旧接口）
def parse_kml_to_shapely(kml_path: str) -> Optional[Polygon | MultiPolygon]:
    """旧接口，现已由parse_kml_to_shapely_by_name替代"""
    try:
        keep_geom, remove_geom = parse_kml_to_shapely_by_name(kml_path)
        if keep_geom is None:
            return None
        if remove_geom is not None:
            return keep_geom.difference(remove_geom)
        return keep_geom
    except Exception as e:
        logger.error(f"旧接口parse_kml_to_shapely失败: {str(e)}")
        return None
