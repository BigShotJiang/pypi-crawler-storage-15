#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""历史数据加载器

负责从文件系统加载和管理历史建模数据。
"""

import logging
from typing import Any, Optional, Tuple

import pandas as pd

logger = logging.getLogger(__name__)


class HistoricalDataLoader:
    """历史数据加载器

    职责：
    - 从配置中获取历史数据路径
    - 加载历史建模数据
    - 验证历史数据与当前数据的兼容性
    - 处理数据加载错误

    原始职责来自：
    - AeroSpotReportGenerator._match_analyze_data() 的第 536-568 行

    示例：
        >>> loader = HistoricalDataLoader(config_service)
        >>> his_data = loader.load_historical_data()
        >>> if his_data:
        ...     ref, merged, measure = his_data
    """

    def __init__(self, config_service: Any) -> None:
        """初始化历史数据加载器

        Args:
            config_service: 配置服务实例，提供 get_company_info 方法
        """
        self.config_service = config_service
        self.logger = logger
        self.historical_data = None
        self.historical_bundle: Optional[Any] = None

    def load_historical_data(
        self,
    ) -> Optional[Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]]:
        """加载历史建模数据

        从配置服务获取历史数据路径，加载历史数据文件。

        Returns:
            Optional[Tuple]: 包含（historical_ref, historical_merged, historical_measure）
                            若加载失败或配置中无历史数据，返回 None

        Note:
            - 历史数据文件应该是 HistoryDataBundle 格式
            - 加载失败会被记录但不会抛异常
        """
        try:
            # 检查配置服务
            if self.config_service is None:
                self.logger.debug("配置服务为 None，无法加载历史数据")
                return None

            # 获取公司信息
            company_info = self.config_service.get_company_info()
            historical_data_path = getattr(company_info, "historical_data", None)

            # 检查是否配置了历史数据路径
            if not historical_data_path:
                self.logger.debug("配置中未指定历史数据路径")
                return None

            # 加载历史数据
            self.logger.info(f"开始加载历史数据: {historical_data_path}")
            return self._load_from_file(historical_data_path)

        except Exception as e:
            self.logger.exception(f"加载历史数据时出错: {e}")
            return None

    def _load_from_file(
        self, historical_data_path: str
    ) -> Optional[Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]]:
        """从文件加载历史数据

        Args:
            historical_data_path: 历史数据文件路径

        Returns:
            Optional[Tuple]: 包含（historical_ref, historical_merged, historical_measure）
                            若加载失败则返回 None
        """
        try:
            from ..data.save_history import HistoryDataBundle

            # 加载历史数据文件
            historical_bundle = HistoryDataBundle.load_from_file([historical_data_path])

            # 提取数据框
            historical_ref = historical_bundle.ref_df
            historical_merged = historical_bundle.merged_df
            historical_measure = historical_bundle.measure_df

            # 保存实例供后续使用
            self.historical_bundle = historical_bundle

            self.logger.info(
                f"成功加载历史数据，共 {len(historical_ref)} 条历史样本数据"
            )
            return historical_ref, historical_merged, historical_measure

        except ImportError:
            self.logger.warning("HistoryDataBundle 模块不可用")
            return None
        except Exception as e:
            self.logger.exception(f"从文件加载历史数据失败: {e}")
            return None

    def validate_compatibility(
        self, current_spectrum_data: pd.DataFrame, historical_spectrum_data: pd.DataFrame
    ) -> bool:
        """验证历史数据与当前数据的兼容性

        检查光谱波段是否匹配。

        Args:
            current_spectrum_data: 当前光谱反射率数据
            historical_spectrum_data: 历史光谱反射率数据

        Returns:
            bool: 两份数据是否兼容（光谱波段相同）
        """
        try:
            if current_spectrum_data is None or historical_spectrum_data is None:
                self.logger.warning("数据为 None，无法验证兼容性")
                return False

            # 比较列名是否相同
            if not current_spectrum_data.columns.equals(historical_spectrum_data.columns):
                self.logger.warning(
                    "历史数据光谱波段和此次建模数据光谱波段不匹配，无法拼接"
                )
                return False

            self.logger.info("历史数据与当前数据兼容")
            return True

        except Exception as e:
            self.logger.exception(f"验证数据兼容性时出错: {e}")
            return False

    def get_historical_bundle(self) -> Any:
        """获取历史数据捆绑

        Returns:
            Any: HistoryDataBundle 实例，若未加载则返回 None
        """
        return self.historical_bundle
