"""
数据处理接口和提供者模块

定义数据处理的抽象接口和具体实现。
遵循 SOLID 依赖反转原则 (DIP)。

Author: 水质建模团队
"""

from typing import Any, Protocol

import pandas as pd


class IIndicatorUnitProvider(Protocol):
    """指标单位提供者接口"""

    def get_unit(self, indicator: str) -> str:
        """获取指标单位

        Args:
            indicator: 指标名称

        Returns:
            单位字符串，如 'mg/L'
        """
        ...


class ConfigurationUnitProvider:
    """从配置服务获取指标单位的提供者

    通过 ConfigurationService 从 Pydantic 模型获取单位配置。
    """

    def __init__(self, config_service: Any) -> None:
        """初始化配置单位提供者

        Args:
            config_service: ConfigurationService 实例
        """
        self.config_service = config_service

    def get_unit(self, indicator: str) -> str:
        """从配置服务获取指标单位

        Args:
            indicator: 指标名称

        Returns:
            单位字符串

        Raises:
            AttributeError: 如果配置服务不可用
        """
        units_config = self.config_service.get_indicator_units_config()
        return units_config.get_unit(indicator)


class DefaultUnitProvider:
    """使用默认配置获取指标单位的提供者

    当配置服务不可用时的备用方案，使用硬编码或简单字典。
    """

    def __init__(self, config: dict | None = None) -> None:
        """初始化默认单位提供者

        Args:
            config: 配置字典（可选）
        """
        self.config = config or {}

    def get_unit(self, indicator: str) -> str:
        """从配置字典获取指标单位

        Args:
            indicator: 指标名称

        Returns:
            单位字符串

        Notes:
            调用 get_indicator_unit 辅助函数获取单位。
            如果指标未找到，返回默认值 '未知'。
        """
        from .utils import get_indicator_unit

        return get_indicator_unit(indicator, self.config)


class IDataStandardizer(Protocol):
    """数据标准化器接口"""

    def standardize(self, data: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
        """标准化数据

        Args:
            data: 原始数据 DataFrame

        Returns:
            Tuple[pd.DataFrame, dict]: 标准化后的数据和映射关系
        """
        ...


class StandardizerService:
    """数据标准化服务"""

    def standardize_columns(self, data: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
        """标准化列名

        Args:
            data: 原始数据 DataFrame

        Returns:
            Tuple[pd.DataFrame, dict]: 标准化后的数据和列名映射
        """
        from .standardizer import standardize_column_names

        return standardize_column_names(data)

    def standardize_indicators(
        self, data: pd.DataFrame, indicators: list[str]
    ) -> tuple[pd.DataFrame, list[str]]:
        """标准化指标名

        Args:
            data: 数据 DataFrame
            indicators: 指标列表

        Returns:
            Tuple[pd.DataFrame, list[str]]: 标准化后的数据和指标名
        """
        from .standardizer import standardize_indicator_names

        return standardize_indicator_names(data, indicators)


class IDataAnalyzer(Protocol):
    """数据分析器接口"""

    def calculate_statistics(
        self,
        data: pd.DataFrame,
        indicators: list[str],
        unit_provider: IIndicatorUnitProvider,
    ) -> dict:
        """计算统计信息

        Args:
            data: 数据 DataFrame
            indicators: 指标列表
            unit_provider: 单位提供者

        Returns:
            统计信息字典
        """
        ...


class DataAnalysisService:
    """数据分析服务"""

    def calculate_statistics(
        self,
        data: pd.DataFrame,
        indicators: list[str],
        unit_provider: IIndicatorUnitProvider,
    ) -> dict:
        """计算统计信息

        Args:
            data: 数据 DataFrame
            indicators: 指标列表
            unit_provider: 单位提供者

        Returns:
            统计信息字典
        """
        from .analyzer import calculate_statistics

        return calculate_statistics(data, indicators, unit_provider.get_unit)

    def generate_summary(self, data: pd.DataFrame, indicators: list[str]) -> dict:
        """生成数据摘要

        Args:
            data: 数据 DataFrame
            indicators: 指标列表

        Returns:
            数据摘要字典
        """
        from .analyzer import generate_data_summary

        return generate_data_summary(data, indicators)
