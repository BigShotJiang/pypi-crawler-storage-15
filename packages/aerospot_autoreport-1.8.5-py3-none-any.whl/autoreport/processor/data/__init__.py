"""
数据处理模块
提供数据处理和分析功能

✨ 迁移说明：已从 processor.py 迁移到 processor_v2.py（Phase 2 重构）
使用新的职责分离架构，通过 DataMatchingAnalyzer 处理数据匹配和分析。
"""

from .processor_v2 import DataProcessor
from .analyzer import analyze_errors

__all__ = ["DataProcessor", "analyze_errors"]
