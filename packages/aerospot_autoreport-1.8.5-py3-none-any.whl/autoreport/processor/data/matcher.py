"""
数据匹配模块
提供航测数据与人工采样数据的匹配和分析功能
"""

import logging
from typing import List, Any, Tuple, Optional

import numpy as np
import pandas as pd

from ...utils.coordinates import haversine

logger = logging.getLogger(__name__)


def find_common_indicators(
    processed_uav_data: pd.DataFrame, measure_data: pd.DataFrame
) -> List[str]:
    """
    查找共同的指标列

    Args:
        processed_uav_data: 处理后的航测数据DataFrame
        measure_data: 人工采样数据DataFrame

    Returns:
        List[str]: 共同的指标列名列表
    """
    intersection_indicators = list(set(processed_uav_data.columns) & set(measure_data.columns))
    # intersection_indicators = [col for col in intersection_indicators if col not in ['index', 'Latitude', 'longitude']]

    if not intersection_indicators:
        logger.warning("没有找到共同的指标列")
    else:
        logger.info(f"找到共同指标: {', '.join(intersection_indicators)}")

    return intersection_indicators


def match_nearest_points(
    measure_data: pd.DataFrame, all_uav_data: pd.DataFrame
) -> List[int]:
    """
    为每个人工采样点找到最近的航测点

    Args:
        measure_data: 人工采样数据DataFrame
        all_uav_data: 完整的航测数据DataFrame

    Returns:
        List[int]: 匹配的航测点索引列表

    Raises:
        ValueError: 当输入数据无效或为空时
    """
    matched_idx: List[int] = []

    # 防御性检查：验证输入数据
    if measure_data is None:
        raise ValueError("measure_data 不能为 None")

    if all_uav_data is None:
        raise ValueError("all_uav_data 不能为 None")

    if measure_data.empty:
        logger.error("measure_data 为空，无法进行匹配分析")
        raise ValueError("measure_data 为空，无有效的采样点数据")

    if all_uav_data.empty:
        logger.error("all_uav_data 为空，无法进行匹配分析")
        logger.error(f"measure_data 有 {len(measure_data)} 行，但 all_uav_data 无有效航测数据")
        raise ValueError("all_uav_data 为空，无有效的航测点数据")

    # 验证必需的列
    required_cols = {"Latitude", "Longitude"}
    measure_missing = required_cols - set(measure_data.columns)
    uav_missing = required_cols - set(all_uav_data.columns)

    if measure_missing:
        raise ValueError(f"measure_data 缺少必需列: {measure_missing}")

    if uav_missing:
        raise ValueError(f"all_uav_data 缺少必需列: {uav_missing}")

    logger.info(
        f"开始匹配人工采样点与航测点，总共 {len(measure_data)} 个人工采样点，{len(all_uav_data)} 个航测点。"
    )

    # 对每个人工采样点，找到最近的航测点
    for idx, measure_row in measure_data.iterrows():
        measure_lat = measure_row["Latitude"]
        measure_lon = measure_row["Longitude"]

        # 验证坐标值有效性
        if pd.isna(measure_lat) or pd.isna(measure_lon):
            logger.warning(f"采样点 {idx} 的坐标无效 (lat: {measure_lat}, lon: {measure_lon})，跳过此点")
            continue

        # 计算到所有航测点的距离
        distances = []
        for _, merged_row in all_uav_data.iterrows():
            uav_lat = merged_row["Latitude"]
            uav_lon = merged_row["Longitude"]

            # 验证航测点坐标
            if pd.isna(uav_lat) or pd.isna(uav_lon):
                continue

            dist = haversine(
                measure_lat,
                measure_lon,
                uav_lat,
                uav_lon,
            )
            distances.append(dist)

        # 防御性检查：确保有有效的距离值
        if not distances:
            logger.error(
                f"采样点 {idx} (lat: {measure_lat}, lon: {measure_lon}) 无有效航测点进行匹配 (所有航测点坐标无效)"
            )
            raise ValueError(
                f"采样点 {idx} 无有效的航测点可匹配 (所有 {len(all_uav_data)} 个航测点坐标均无效)"
            )

        # 找到最近的点
        min_dist_idx = int(np.argmin(distances))
        matched_idx.append(min_dist_idx)
        logger.debug(
            f"采样点 {idx} (lat: {measure_lat}, lon: {measure_lon}) → 航测点索引 {min_dist_idx}，距离 {distances[min_dist_idx]:.2f} 米"
        )

    if not matched_idx:
        logger.error("所有采样点匹配失败，未获得任何有效匹配")
        raise ValueError("匹配过程失败，未获得任何有效匹配结果")

    logger.info(f"所有 {len(matched_idx)} 个采样点已完成匹配")
    return matched_idx


def handle_invalid_values(
    pred_data: pd.DataFrame, matched_merged_df: pd.DataFrame
) -> pd.DataFrame:
    """
    处理无效值，用原始航测数据替换

    Args:
        pred_data: 预测数据DataFrame
        matched_merged_df: 匹配的原始航测数据DataFrame

    Returns:
        pd.DataFrame: 处理后的预测数据DataFrame
    """
    # 检查pred_data中缺失的列
    missing_cols = set(matched_merged_df.columns) - set(pred_data.columns)
    if missing_cols:
        logger.warning(f"发现{len(missing_cols)}个缺失列: {', '.join(missing_cols)}")
        # 从matched_merged_df中复制缺失的列
        for col in missing_cols:
            pred_data[col] = matched_merged_df[col]
        logger.info("已从原始航测数据补充缺失列")

    # 检查pred_data中的无效值
    invalid_mask = pred_data.isna() | (pred_data <= 0)
    invalid_count = invalid_mask.sum().sum()

    if invalid_count > 0:
        logger.warning(f"发现{invalid_count}个无效值(NA或非正数)")

        # 记录每个指标中无效值的数量
        for col in pred_data.columns:
            col_invalid = invalid_mask[col].sum()
            if col_invalid > 0:
                logger.warning(f"指标 {col} 中存在 {col_invalid} 个无效值")

                # 记录具体的行索引
                invalid_rows = pred_data.index[invalid_mask[col]].tolist()
                logger.warning(f"无效值出现在行: {invalid_rows}")

        # 用matched_merged_df的值替换无效值
        pred_data = pred_data.where(~invalid_mask, matched_merged_df)
        logger.info("已用原始航测数据替换所有无效值")
    else:
        logger.info("未发现无效值")

    # 按照matched_merged_df的列顺序重新排列pred_data的列
    # pred_data = pred_data[matched_merged_df.columns]

    return pred_data


class DataMatcher:
    """数据匹配处理器

    职责：
    - 匹配 UAV 反演数据与实地测量数据
    - 进行水质模型的优化和建模
    - 管理建模结果数据

    原始职责来自：
    - AeroSpotReportGenerator._match_analyze_data() 的第 571-579 行

    示例：
        >>> matcher = DataMatcher(data_processor)
        >>> results = matcher.match_and_analyze(
        ...     merged_data, measure_data, spectrum_data,
        ...     hist_ref, hist_merged, hist_measure
        ... )
    """

    def __init__(self, data_processor: Any) -> None:
        """初始化数据匹配器

        Args:
            data_processor: 数据处理器实例，提供 match_and_analyze_data 方法
        """
        self.data_processor = data_processor
        self.logger = logger
        self.last_results = None

    def match_and_analyze(
        self,
        current_uav_data: pd.DataFrame,
        measure_data: pd.DataFrame,
        spectrum_data: pd.DataFrame,
        historical_ref: Optional[pd.DataFrame] = None,
        historical_merged: Optional[pd.DataFrame] = None,
        historical_measure: Optional[pd.DataFrame] = None,
    ) -> Any:
        """执行数据匹配和建模分析

        将当前数据与历史数据组合，进行模型优化和预测。

        Args:
            current_uav_data: 当前 UAV 反演数据
            measure_data: 当前实地测量数据
            spectrum_data: 当前光谱反射率数据
            historical_ref: 历史光谱反射率数据（可选）
            historical_merged: 历史 UAV 反演数据（可选）
            historical_measure: 历史实地测量数据（可选）

        Returns:
            Tuple[Any, Any, Any, Any, Any]: 包含以下内容：
                - comparison_data: 对比数据
                - pred_data: 预测数据
                - model_func: 模型函数
                - all_pred_data: 所有预测数据
                - his_instance: 历史数据实例

        Raises:
            Exception: 匹配或建模过程中的任何错误
        """
        try:
            self.logger.info("开始数据匹配和建模")

            # 调用数据处理器的匹配方法
            results = self.data_processor.match_and_analyze_data(
                current_uav_data,
                measure_data,
                spectrum_data,
                historical_ref,
                historical_merged,
                historical_measure,
            )

            # 保存结果以供后续使用
            self.last_results = results

            self.logger.info("数据匹配和建模完成")
            return results

        except Exception as e:
            self.logger.exception(f"数据匹配失败: {e}")
            raise

    def get_last_results(self) -> Optional[Tuple]:
        """获取最后一次匹配的结果

        Returns:
            Optional[Tuple]: 最后一次匹配的结果，若无则返回 None
        """
        return self.last_results

    def validate_data(
        self,
        input_uav_data: pd.DataFrame,
        measure_data: pd.DataFrame,
        spectrum_data: pd.DataFrame,
    ) -> bool:
        """验证输入数据的有效性

        Args:
            input_uav_data: UAV 反演数据
            measure_data: 实地测量数据
            spectrum_data: 光谱反射率数据

        Returns:
            bool: 数据是否有效
        """
        try:
            # 检查数据框不为空
            if input_uav_data is None or input_uav_data.empty:
                self.logger.error("input_uav_data 为空或 None")
                return False

            if measure_data is None or measure_data.empty:
                self.logger.error("measure_data 为空或 None")
                return False

            if spectrum_data is None or spectrum_data.empty:
                self.logger.error("spectrum_data 为空或 None")
                return False

            self.logger.debug("输入数据有效")
            return True

        except Exception as e:
            self.logger.exception(f"数据验证异常: {e}")
            return False
