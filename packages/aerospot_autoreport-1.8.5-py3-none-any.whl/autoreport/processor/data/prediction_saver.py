#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""预测结果保存器模块

提供预测结果、历史数据和模型的保存功能。
"""

import logging
import os
from typing import Any, Optional

import pandas as pd

from .save_history import HistoryDataBundle

# 尝试导入加密函数（从 autowaterqualitymodeler 模块）
try:
    from autowaterqualitymodeler.utils.encryption import (
        encrypt_data_to_file,
    )
except ImportError:
    encrypt_data_to_file = None  # type: ignore

logger = logging.getLogger(__name__)


class PredictionSaver:
    """预测结果保存器

    职责：
    - 保存预测结果到 CSV 文件
    - 保存历史数据到 h5 文件
    - 保存加密的模型到 bin 文件
    - 管理文件保存路径

    原始职责来自：
    - AeroSpotReportGenerator._match_analyze_data() 的第 582-594 行
    - AeroSpotReportGenerator.save_model_func() 的第 1433-1489 行

    示例：
        >>> saver = PredictionSaver()
        >>> saver.save_predictions(
        ...     predictions_df=pred_df,
        ...     output_path="predict/predict_result.csv"
        ... )
        >>> saver.save_history(
        ...     history_bundle=his_instance,
        ...     output_path="models/historical_data.h5"
        ... )
    """

    def __init__(self) -> None:
        """初始化预测结果保存器"""
        self.logger = logger
        self.saved_files: dict[str, str] = {}

    def save_predictions(self, predictions_df: pd.DataFrame, output_path: str) -> bool:
        """保存预测结果到 CSV 文件

        Args:
            predictions_df: 预测结果 DataFrame
            output_path: 输出文件路径（CSV 格式）

        Returns:
            bool: 保存是否成功
        """
        try:
            # 验证输入
            if predictions_df is None or predictions_df.empty:
                self.logger.error("预测数据为空或 None")
                return False

            if not output_path or not output_path.endswith(".csv"):
                self.logger.error("输出路径无效或不是 CSV 文件")
                return False

            # 创建目录（如果不存在）
            output_dir = os.path.dirname(output_path)
            if output_dir:
                os.makedirs(output_dir, exist_ok=True)

            # 保存到 CSV
            predictions_df.to_csv(output_path, index=False)

            self.logger.info(f"预测结果已保存到: {output_path}")
            self.saved_files["predictions"] = output_path

            return True

        except Exception as e:
            self.logger.exception(f"保存预测结果失败: {e}")
            return False

    def save_history(
        self,
        history_bundle: HistoryDataBundle,
        output_path: str,
    ) -> bool:
        """保存历史数据到 h5 文件

        Args:
            history_bundle: 历史数据包对象
            output_path: 输出文件路径（h5 格式）

        Returns:
            bool: 保存是否成功
        """
        try:
            # 验证输入
            if history_bundle is None:
                self.logger.error("历史数据包为 None")
                return False

            if not output_path or not output_path.endswith(".h5"):
                self.logger.error("输出路径无效或不是 h5 文件")
                return False

            # 保存历史数据
            history_bundle.save_to_file(output_path)

            self.logger.info(f"历史数据已保存到: {output_path}")
            self.saved_files["history"] = output_path

            return True

        except Exception as e:
            self.logger.exception(f"保存历史数据失败: {e}")
            return False

    def save_model(
        self,
        model_func: Any,
        output_path: str,
        password: Optional[bytes] = None,
        salt: Optional[bytes] = None,
        iv: Optional[bytes] = None,
    ) -> bool:
        """保存加密的模型到 bin 文件

        Args:
            model_func: 模型函数对象
            output_path: 输出文件路径（bin 格式）
            password: 加密密码（字节），默认为预设值
            salt: 盐值（字节），默认为预设值
            iv: 初始化向量（字节），默认为预设值

        Returns:
            bool: 保存是否成功

        Note:
            - 默认使用预设的密钥、盐和 IV
            - 可通过参数覆盖默认值
            - 使用 AES 加密算法
        """
        try:
            # 验证输入
            if model_func is None:
                self.logger.error("模型对象为 None")
                return False

            if not output_path or not output_path.endswith(".bin"):
                self.logger.error("输出路径无效或不是 bin 文件")
                return False

            # 检查加密函数是否可用
            if encrypt_data_to_file is None:
                self.logger.warning("加密模块不可用，跳过模型加密")
                return False

            # 设置默认密钥
            if password is None:
                password = b"water_quality_analysis_key"
            if salt is None:
                salt = b"water_quality_salt"
            if iv is None:
                iv = b"fixed_iv_16bytes"

            # 创建目录（如果不存在）
            output_dir = os.path.dirname(output_path)
            if output_dir:
                os.makedirs(output_dir, exist_ok=True)

            # 保存加密的模型
            encrypted_path = encrypt_data_to_file(
                data_obj=model_func,
                password=password,
                salt=salt,
                iv=iv,
                output_dir=output_dir or ".",
                logger=self.logger,
            )

            self.logger.info(f"加密模型已保存到: {encrypted_path}")
            self.saved_files["model"] = encrypted_path

            return True

        except Exception as e:
            self.logger.exception(f"保存加密模型失败: {e}")
            return False

    def get_saved_files(self) -> dict[str, str]:
        """获取所有已保存的文件路径

        Returns:
            dict[str, str]: 文件类型到路径的映射
        """
        return self.saved_files.copy()

    def clear_history(self) -> None:
        """清除保存的文件记录"""
        self.saved_files.clear()
        self.logger.debug("已清除保存的文件记录")
