"""
误差分析器模块

专职处理误差分析，遵循单一职责原则。

Author: 水质建模团队
"""

import logging
from typing import Any, Dict, Optional

import pandas as pd

from .analyzer import analyze_errors

logger = logging.getLogger(__name__)


class ErrorAnalyzer:
    """误差分析器

    专职处理水质模型的误差分析，包括：
    - 相对误差计算
    - 绝对误差计算
    - 统计分析

    Examples:
        >>> analyzer = ErrorAnalyzer()
        >>> result = analyzer.analyze(
        ...     measured_data=measure_df,
        ...     predicted_data=pred_df,
        ...     output_file="errors.csv"
        ... )
    """

    def __init__(self) -> None:
        """初始化误差分析器"""
        logger.debug("误差分析器已初始化")

    def analyze(
        self,
        measured_data: pd.DataFrame,
        predicted_data: pd.DataFrame,
        output_file: Optional[str] = None,
    ) -> Dict[str, Any]:
        """分析测量值和预测值的误差

        Args:
            measured_data: 测量数据 DataFrame
            predicted_data: 预测数据 DataFrame
            output_file: 可选的输出文件路径，用于保存误差结果

        Returns:
            Dict[str, Any]: 包含以下键的误差分析结果：
                - errors: 误差数据框
                - summary: 误差统计摘要
                - metrics: 误差指标（MAE、RMSE、MAPE 等）

        Raises:
            ValueError: 当输入数据格式不正确时

        Examples:
            >>> analyzer = ErrorAnalyzer()
            >>> result = analyzer.analyze(
            ...     measured_data=pd.DataFrame({'value': [10, 20, 30]}),
            ...     predicted_data=pd.DataFrame({'value': [11, 19, 31]})
            ... )
            >>> print(result['summary'])
        """
        logger.info("开始分析数据误差")

        try:
            # 验证输入
            if measured_data is None or measured_data.empty:
                raise ValueError("测量数据为空或未提供")
            if predicted_data is None or predicted_data.empty:
                raise ValueError("预测数据为空或未提供")

            # 使用现有的分析函数
            error_result = analyze_errors(
                matched_measure_df=measured_data,
                pred_data=predicted_data,
                output_file=output_file,
            )

            logger.info("误差分析完成")
            return error_result

        except Exception as e:
            logger.error(f"误差分析失败: {str(e)}")
            raise ValueError(f"误差分析失败: {str(e)}") from e
