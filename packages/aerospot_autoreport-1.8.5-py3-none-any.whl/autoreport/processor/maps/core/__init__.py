"""核心算法模块。

包含克里金插值、边界检测、数据转换和工具类的核心算法。

导出的类和配置：
- InterpolationEngine: 插值引擎
- BoundaryDetector: 边界检测器
- DataTransformer: 数据转换器
- DataValidator: 数据验证工具
- GridBuilder: 网格构建工具
- BoundaryDetectionChain: 链式边界检测
- MapGenerationTask: 地图生成任务
- DeprecationHelper: 废弃 API 处理
- KRIGING_CONFIG: 克里金配置字典
- GLOBAL_KRIGING_METHOD: 全局克里金方法
"""

from .kriging_config import KRIGING_CONFIG, GLOBAL_KRIGING_METHOD
from .data_transform import DataTransformer
from .boundaries import BoundaryDetector
from .interpolation import InterpolationEngine
from .validators import DataValidator
from .grid_builder import GridBuilder
from .boundary_chain import BoundaryDetectionChain, create_boundary_detection_chain
from .map_task import MapGenerationTask
from .deprecation import DeprecationHelper

__all__ = [
    "InterpolationEngine",
    "BoundaryDetector",
    "DataTransformer",
    "DataValidator",
    "GridBuilder",
    "BoundaryDetectionChain",
    "create_boundary_detection_chain",
    "MapGenerationTask",
    "DeprecationHelper",
    "KRIGING_CONFIG",
    "GLOBAL_KRIGING_METHOD",
]
