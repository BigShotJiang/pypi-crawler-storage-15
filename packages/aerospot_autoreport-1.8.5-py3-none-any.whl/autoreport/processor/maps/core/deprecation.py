"""废弃 API 处理模块。

提供工厂函数生成标准化的废弃 API 包装，避免手动编写重复的包装函数。
统一弃用警告的格式和行为。

Author: 水质建模团队
"""

import logging
import warnings
from typing import Any, Callable, Optional

logger = logging.getLogger(__name__)


class DeprecationHelper:
    """废弃 API 处理工厂类。

    提供静态方法生成标准化的废弃 API 包装函数。
    每个包装函数会：
    1. 发出 DeprecationWarning
    2. 调用新的实现
    3. 返回结果

    这避免了手动编写 250+ 行重复的包装函数。

    Examples:
        >>> from .data_transform import DataTransformer
        >>>
        >>> # 创建废弃函数包装
        >>> wrapper = DeprecationHelper.create_deprecated_wrapper(
        ...     'transform_data_for_kriging',
        ...     lambda v, m="log": DataTransformer.transform_for_kriging(v, m),
        ...     'DataTransformer.transform_for_kriging'
        ... )
        >>>
        >>> # 调用包装函数
        >>> result = wrapper(values, method='log')  # 发出警告，返回结果
        >>>
        >>> # 在模块初始化时，批量创建所有废弃包装
        >>> deprecated_wrappers = {
        ...     'transform_data_for_kriging': DeprecationHelper.create_deprecated_wrapper(...),
        ...     'inverse_transform_data': DeprecationHelper.create_deprecated_wrapper(...),
        ...     # ... 其他 20 个
        ... }
        >>>
        >>> # 批量导出到模块命名空间
        >>> for name, wrapper in deprecated_wrappers.items():
        ...     globals()[name] = wrapper
    """

    @staticmethod
    def create_deprecated_wrapper(
        old_name: str,
        new_callable: Callable,
        new_name: str,
        module_hint: Optional[str] = None,
    ) -> Callable:
        """创建废弃 API 的包装函数。

        生成一个包装函数，在调用时发出 DeprecationWarning 并委托给新实现。

        Args:
            old_name: 旧函数名称（用于警告消息）
            new_callable: 新的可调用对象（新实现）
            new_name: 新函数的完整名称（用于建议消息）
                - 例如：'DataTransformer.transform_for_kriging'
            module_hint: 可选的模块提示（用于补充警告信息）
                - 例如：'from autoreport.processor.maps.core.data_transform import DataTransformer'

        Returns:
            Callable: 包装函数，调用时会：
                1. 发出 DeprecationWarning
                2. 调用 new_callable 并传递所有参数
                3. 返回结果

        Examples:
            >>> # 简单的包装
            >>> wrapper = DeprecationHelper.create_deprecated_wrapper(
            ...     'transform_data_for_kriging',
            ...     lambda v, m="log": DataTransformer.transform_for_kriging(v, m),
            ...     'DataTransformer.transform_for_kriging'
            ... )
            >>>
            >>> # 使用包装函数（会发出警告）
            >>> result = wrapper(values)  # DeprecationWarning 已发出
            >>>
            >>> # 带模块提示的包装
            >>> wrapper = DeprecationHelper.create_deprecated_wrapper(
            ...     'kriging_interpolation',
            ...     InterpolationEngine.kriging_interpolate,
            ...     'InterpolationEngine.kriging_interpolate',
            ...     module_hint='from autoreport.processor.maps.core.interpolation import InterpolationEngine'
            ... )
        """

        def deprecated_wrapper(*args, **kwargs) -> Any:
            """内层包装函数。

            发出废弃警告，然后委托给新实现。
            """
            # 构建警告消息
            warning_msg = f"{old_name}() 已弃用。请改为使用 {new_name}()。"
            if module_hint:
                warning_msg += f"\n建议: {module_hint}"

            # 发出 DeprecationWarning
            warnings.warn(
                warning_msg,
                category=DeprecationWarning,
                stacklevel=2,  # 指向调用方而非包装函数本身
            )

            logger.debug(f"调用已弃用的函数: {old_name}()，建议使用: {new_name}()")

            # 委托给新实现
            return new_callable(*args, **kwargs)

        # 设置包装函数的元信息（便于调试和文档）
        deprecated_wrapper.__name__ = old_name
        deprecated_wrapper.__doc__ = (
            f"[已弃用] {old_name}()\n\n"
            f"此函数已弃用，请改为使用 {new_name}()。\n\n"
            f"这是为了向后兼容而保留的包装函数。"
        )

        return deprecated_wrapper

    @staticmethod
    def create_deprecated_wrappers_batch(
        wrapper_specs: dict,
    ) -> dict:
        """批量创建多个废弃 API 包装。

        简化批量生成多个包装函数的过程。

        Args:
            wrapper_specs: 包装规格字典，格式为：
                {
                    'old_name_1': {
                        'new_callable': callable,
                        'new_name': 'NewClass.new_method',
                        'module_hint': 'from ... import ...'  # 可选
                    },
                    'old_name_2': {
                        ...
                    }
                }

        Returns:
            dict: 包装函数字典，键为旧函数名，值为包装函数

        Examples:
            >>> specs = {
            ...     'transform_data_for_kriging': {
            ...         'new_callable': DataTransformer.transform_for_kriging,
            ...         'new_name': 'DataTransformer.transform_for_kriging'
            ...     },
            ...     'inverse_transform_data': {
            ...         'new_callable': DataTransformer.inverse_transform,
            ...         'new_name': 'DataTransformer.inverse_transform'
            ...     }
            ... }
            >>>
            >>> wrappers = DeprecationHelper.create_deprecated_wrappers_batch(specs)
            >>>
            >>> for name, wrapper in wrappers.items():
            ...     globals()[name] = wrapper
        """
        wrappers = {}

        for old_name, spec in wrapper_specs.items():
            wrapper = DeprecationHelper.create_deprecated_wrapper(
                old_name=old_name,
                new_callable=spec["new_callable"],
                new_name=spec["new_name"],
                module_hint=spec.get("module_hint"),
            )
            wrappers[old_name] = wrapper
            logger.debug(f"已创建废弃包装: {old_name} → {spec['new_name']}")

        logger.info(f"已批量创建 {len(wrappers)} 个废弃 API 包装")

        return wrappers
