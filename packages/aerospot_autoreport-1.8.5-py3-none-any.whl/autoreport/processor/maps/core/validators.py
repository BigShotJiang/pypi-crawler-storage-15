"""数据验证工具模块。

为克里金插值提供统一的数据验证和坐标提取功能，包括：
- 坐标列自动检测和提取
- 数据点合法性验证
- 数据值有效性检查
- 地理边界合法性验证

Author: 水质建模团队
"""

import logging
from typing import Optional, Tuple

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


class DataValidator:
    """数据验证工具类。

    提供静态方法用于数据验证，支持多种列名约定和边界检查。

    Examples:
        >>> import numpy as np
        >>> import pandas as pd
        >>> data = pd.DataFrame({
        ...     'Longitude': [1, 2, 3],
        ...     'Latitude': [4, 5, 6],
        ...     'COD': [10, 20, 30]
        ... })
        >>> points = DataValidator.extract_points(data)
        >>> assert points.shape == (3, 2)
        >>> DataValidator.validate_points(points)
        >>> values = data['COD'].values
        >>> DataValidator.validate_values(values)
    """

    # 支持的坐标列名别名
    COORD_ALIASES = {
        "longitude": ["Longitude", "longitude", "lon", "Lon", "LNG"],
        "latitude": ["Latitude", "latitude", "lat", "Lat", "LAT"],
    }

    # 需要排除的坐标列名
    EXCLUDED_COLS = [
        "Longitude",
        "Latitude",
        "lon",
        "lat",
        "index",
        "Lon",
        "Lat",
        "LNG",
        "LAT",
    ]

    @staticmethod
    def extract_points(
        data: pd.DataFrame, coord_cols: Optional[list] = None
    ) -> np.ndarray:
        """智能提取坐标点，支持多种列名约定。

        优先使用显式指定的列名，其次自动检测别名，最后回退到前两列。

        Args:
            data: 包含坐标数据的 DataFrame
            coord_cols: 显式指定的坐标列名 [lon_col, lat_col]，如果为 None 则自动检测

        Returns:
            np.ndarray: 坐标数组，shape (N, 2)，格式 [[lon, lat], ...]

        Raises:
            ValueError: 无法找到坐标列时

        Examples:
            >>> data = pd.DataFrame({
            ...     'Longitude': [1, 2, 3],
            ...     'Latitude': [4, 5, 6]
            ... })
            >>> points = DataValidator.extract_points(data)
            >>> assert points.shape == (3, 2)
        """
        if coord_cols is not None:
            # 显式指定列名
            if len(coord_cols) != 2:
                raise ValueError("coord_cols 必须包含恰好 2 个列名")
            if not all(col in data.columns for col in coord_cols):
                raise ValueError(f"坐标列 {coord_cols} 不存在于数据中")
            return data[coord_cols].values

        # 自动检测坐标列
        lon_col = None
        lat_col = None

        # 查找经度列
        for alias in DataValidator.COORD_ALIASES["longitude"]:
            if alias in data.columns:
                lon_col = alias
                break

        # 查找纬度列
        for alias in DataValidator.COORD_ALIASES["latitude"]:
            if alias in data.columns:
                lat_col = alias
                break

        if lon_col and lat_col:
            logger.debug(f"自动检测坐标列：{lon_col}, {lat_col}")
            return data[[lon_col, lat_col]].values

        # 回退：使用前两列
        if len(data.columns) >= 2:
            logger.warning("未找到命名的坐标列，使用数据的前两列作为坐标")
            return data.iloc[:, :2].values

        raise ValueError("无法找到坐标列，且数据列数不足")

    @staticmethod
    def validate_points(points: np.ndarray, min_count: int = 3) -> bool:
        """验证点集的合法性。

        检查点的数量、数据类型和有效性。

        Args:
            points: 坐标数组，shape (N, 2)
            min_count: 最少点数要求，默认 3

        Returns:
            bool: 合法返回 True

        Raises:
            ValueError: 点集不合法时

        Examples:
            >>> points = np.array([[0, 0], [1, 1], [2, 2]])
            >>> DataValidator.validate_points(points)
            True
        """
        if not isinstance(points, np.ndarray):
            raise ValueError("points 必须是 numpy 数组")

        if points.ndim != 2 or points.shape[1] != 2:
            raise ValueError(f"points 形状必须是 (N, 2)，得到 {points.shape}")

        if len(points) < min_count:
            raise ValueError(f"数据点不足（{len(points)} < {min_count}），无法进行插值")

        # 检查坐标有效性
        if np.any(np.isnan(points)) or np.any(np.isinf(points)):
            raise ValueError("坐标包含 NaN 或无穷大值")

        logger.debug(f"点集验证通过：{len(points)} 个点")
        return True

    @staticmethod
    def validate_values(values: np.ndarray, allow_nan: bool = False) -> bool:
        """验证指标数据的有效性。

        检查数据是否为空、是否全为 NaN 或无穷大。

        Args:
            values: 数据值数组，shape (N,)
            allow_nan: 是否允许 NaN 值

        Returns:
            bool: 有效返回 True

        Raises:
            ValueError: 数据无效时

        Examples:
            >>> values = np.array([1.0, 2.0, 3.0])
            >>> DataValidator.validate_values(values)
            True
        """
        if len(values) == 0:
            raise ValueError("指标数据为空")

        # 检查是否全为 NaN 或无穷大
        valid_mask = ~(np.isnan(values) | np.isinf(values))
        if not np.any(valid_mask):
            raise ValueError("指标数据全为 NaN 或无穷大")

        if not allow_nan:
            # 检查是否有 NaN 值
            if np.any(np.isnan(values)):
                nan_count = np.sum(np.isnan(values))
                logger.warning(f"指标数据中有 {nan_count} 个 NaN 值")

        logger.debug(f"值验证通过：{np.sum(valid_mask)}/{len(values)} 个有效值")
        return True

    @staticmethod
    def validate_bounds(bounds: Tuple[float, float, float, float]) -> bool:
        """验证地理边界的合法性。

        检查边界坐标的有效性和大小关系。

        Args:
            bounds: (lon_min, lat_min, lon_max, lat_max) 元组

        Returns:
            bool: 合法返回 True

        Raises:
            ValueError: 边界不合法时

        Examples:
            >>> bounds = (100, 20, 105, 25)
            >>> DataValidator.validate_bounds(bounds)
            True
        """
        if len(bounds) != 4:
            raise ValueError("bounds 必须包含恰好 4 个值")

        lon_min, lat_min, lon_max, lat_max = bounds

        # 检查是否有 NaN 或无穷大
        if any(np.isnan(v) or np.isinf(v) for v in bounds):
            raise ValueError("边界包含 NaN 或无穷大值")

        # 检查大小关系
        if not (lon_min < lon_max):
            raise ValueError(
                f"边界不合法：经度范围 [{lon_min}, {lon_max}]，"
                f"应满足 lon_min < lon_max"
            )

        if not (lat_min < lat_max):
            raise ValueError(
                f"边界不合法：纬度范围 [{lat_min}, {lat_max}]，"
                f"应满足 lat_min < lat_max"
            )

        logger.debug(
            f"边界验证通过：lon[{lon_min}, {lon_max}], " f"lat[{lat_min}, {lat_max}]"
        )
        return True

    @staticmethod
    def extract_and_validate(
        data: pd.DataFrame, indicator_col: Optional[str] = None, min_points: int = 3
    ) -> Tuple[np.ndarray, np.ndarray]:
        """一次性提取和验证坐标及指标数据。

        这是一个便利方法，结合了坐标提取和数据验证。

        Args:
            data: 包含坐标和指标数据的 DataFrame
            indicator_col: 指标列名，如果为 None 则使用第一个非坐标列
            min_points: 最少点数要求

        Returns:
            Tuple[np.ndarray, np.ndarray]: (points, values) 元组

        Raises:
            ValueError: 数据不合法时

        Examples:
            >>> data = pd.DataFrame({
            ...     'Longitude': [1, 2, 3],
            ...     'Latitude': [4, 5, 6],
            ...     'COD': [10, 20, 30]
            ... })
            >>> points, values = DataValidator.extract_and_validate(
            ...     data, indicator_col='COD'
            ... )
        """
        # 提取坐标
        points = DataValidator.extract_points(data)
        DataValidator.validate_points(points, min_count=min_points)

        # 提取指标值
        if indicator_col is not None:
            if indicator_col not in data.columns:
                raise ValueError(f"指标列 '{indicator_col}' 不存在")
            values = data[indicator_col].values
        else:
            # 自动选择第一个非坐标列
            value_cols = [
                col for col in data.columns if col not in DataValidator.EXCLUDED_COLS
            ]

            if len(value_cols) == 0:
                raise ValueError("未找到有效的指标数据列")

            indicator_col = value_cols[0]
            values = data[indicator_col].values
            logger.info(f"自动选择指标列：{indicator_col}")

        # 验证值
        DataValidator.validate_values(values)

        return points, values
