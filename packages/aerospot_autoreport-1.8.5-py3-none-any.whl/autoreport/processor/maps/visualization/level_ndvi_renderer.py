"""NDVI 藻华程度分级检测图渲染模块。

专门用于渲染基于等级分类的 NDVI 藻华程度检测图。
分级标准（转换后的值）：
- <= 0: 无藻华（蓝色）
- 0 < value <= 0.3: 轻度藻华（绿色）
- 0.3 < value <= 0.6: 中度藻华（黄色）
- > 0.6: 重度藻华（红色）

Author: 水质建模团队
"""

import logging
from typing import TYPE_CHECKING, Any, Optional

import matplotlib.patches as mpatches
import numpy as np
from matplotlib.colors import BoundaryNorm, ListedColormap

from .base_renderer import RendererBase
from .render_session import RenderingSession

if TYPE_CHECKING:
    from .base_renderer import RenderingEnvironment

logger = logging.getLogger(__name__)


class LevelNDVIRenderer(RendererBase):
    """NDVI 藻华程度分级检测图渲染器。

    专门用于基于等级分类的 NDVI 检测，将结果分为四个等级：
    - 无藻华（蓝色）
    - 轻度藻华（绿色）
    - 中度藻华（黄色）
    - 重度藻华（红色）

    使用转换公式：(NDVI + 0.2) / 1.01 来规范化数据范围。

    This renderer follows SRP principle by focusing solely on level classification.

    Examples:
        >>> renderer = LevelNDVIRenderer(satellite_info, geo_bounds, layout_manager)
        >>> map_path = renderer.render(
        ...     indicator="NDVI",
        ...     save_path="/path/to/output.png",
        ...     Z=ndvi_grid,
        ...     grid_lon=lon_grid,
        ...     grid_lat=lat_grid,
        ...     session=rendering_session
        ... )
    """

    # 分级标准定义
    _GRADE_LABELS = ["无藻华", "轻度", "中度", "重度"]
    _GRADE_COLORS = ["#0000FF", "#00FF00", "#FFFF00", "#FF0000"]
    _GRADE_THRESHOLDS = [0.0, 0.3, 0.6]  # 分级边界值

    # 数据转换参数
    _TRANSFORM_SCALE = 1.01
    _TRANSFORM_OFFSET = 0.2

    def _prepare_data(self, **kwargs: Any) -> Any:
        """【钩子方法】准备 NDVI 分级图的数据。

        处理 NDVI 特定的数据准备逻辑：
        - 验证 Z 是否有效
        - 应用转换公式
        - 执行分级处理

        Args:
            **kwargs: 包含以下参数：
                - Z: np.ndarray（NDVI 值）
                - 其他参数会被保留在返回字典中

        Returns:
            Dict[str, Any]: 准备好的数据字典，包含 grade_map
        """
        Z = kwargs.get("Z")

        if Z is None:
            logger.warning("插值数据 Z 为空，返回空数据")
            return super()._prepare_data(**kwargs)

        # 应用转换公式并执行分级
        Z_transformed = self._transform_data(Z)
        grade_map = self._create_grade_map(Z_transformed)

        # 调用基类的 _prepare_data
        env = super()._prepare_data(**kwargs)

        # 添加 NDVI 特定的数据
        env["grade_map"] = grade_map

        return env

    def render(
        self,
        indicator: str,
        save_path: str,
        Z: np.ndarray,
        grid_lon: Optional[np.ndarray],
        grid_lat: Optional[np.ndarray],
        session: RenderingSession,
    ) -> str:
        """渲染 NDVI 藻华程度分级图。

        基于转换公式 (NDVI + 0.2) / 1.01 后的值进行分级。

        Args:
            indicator: 指标名称（NDVI）
            save_path: 保存路径
            Z: 插值后的 NDVI 值网格
            grid_lon: 网格经度（可选）
            grid_lat: 网格纬度（可选）
            session: 渲染会话对象，包含所有共享参数

        Returns:
            str: 保存路径或 "skip" 如果无有效数据

        Raises:
            Exception: 渲染过程中的任何错误

        Note:
            使用模板方法模式，通过钩子方法实现分级藻华检测图特定逻辑。
        """
        if Z is None:
            logger.warning("插值数据 Z 为空，跳过 NDVI 藻华程度分级图生成")
            return "skip"

        # 核心：应用转换公式并执行分级
        Z_transformed = self._transform_data(Z)
        grade_map = self._create_grade_map(Z_transformed)

        # 调用模板方法，传递分级藻华检测图特定数据
        return self._execute_template_render(
            indicator=indicator,
            save_path=save_path,
            session=session,
            has_right_element=True,
            right_element_type="legend",
            title_template="基于 {indicator} 的藻华程度分级图",
            all_points_outside=False,
            # 传递给钩子方法的分级特定数据
            grade_map=grade_map,
            grid_lon=grid_lon,
            grid_lat=grid_lat,
        )

    def _draw_content(
        self,
        ax: Any,
        session: RenderingSession,
        env: "RenderingEnvironment",
        indicator: str,
        hook_context: dict,
        **kwargs: Any,
    ) -> None:
        """【钩子方法】绘制分级藻华检测图。

        Args:
            ax: matplotlib Axes对象
            session: 渲染会话对象
            env: 渲染环境对象
            indicator: 指标名称
            hook_context: 钩子上下文字典，用于在钩子间传递数据
            **kwargs: 包含 grade_map
        """
        grade_map = kwargs["grade_map"]
        geo_bounds = session.geo_bounds

        # 创建分级颜色图
        cmap = ListedColormap(self._GRADE_COLORS)
        bounds = list(range(1, len(self._GRADE_LABELS) + 2))
        norm = BoundaryNorm(bounds, cmap.N)

        # 确定 extent（显示范围）
        extent = [
            geo_bounds[0],
            geo_bounds[2],
            geo_bounds[1],
            geo_bounds[3],
        ]

        # 绘制分级图
        ax.imshow(
            grade_map,
            extent=extent,
            aspect="auto",
            origin="lower",
            cmap=cmap,
            norm=norm,
        )

        # 保存 patches 到共享上下文供装饰方法使用
        patches = [
            mpatches.Patch(color=self._GRADE_COLORS[i], label=self._GRADE_LABELS[i])
            for i in range(len(self._GRADE_LABELS))
        ]
        hook_context["_patches"] = patches

    def _add_decorations(
        self,
        fig: Any,
        ax: Any,
        indicator: str,
        session: RenderingSession,
        env: "RenderingEnvironment",
        hook_context: dict,
        **kwargs: Any,
    ) -> None:
        """【钩子方法】添加图例。

        Args:
            fig: matplotlib Figure对象
            ax: matplotlib Axes对象
            indicator: 指标名称
            session: 渲染会话对象
            env: 渲染环境对象
            hook_context: 钩子上下文字典，包含 _patches (图例补丁列表)
            **kwargs: 额外参数
        """
        patches = hook_context.get("_patches")
        if patches is None:
            return

        # 使用基类的统一图例创建方法
        self._create_legend(ax, patches, session.font_sizes)

    def _transform_data(self, Z: np.ndarray) -> np.ndarray:
        """应用转换公式规范化数据。

        公式: (NDVI + 0.2) / 1.01

        Args:
            Z: 原始 NDVI 值网格

        Returns:
            转换后的数据
        """
        Z_transformed = (Z + self._TRANSFORM_OFFSET) / self._TRANSFORM_SCALE
        logger.info(
            f"转换后数值范围: [{np.nanmin(Z_transformed):.3f}, "
            f"{np.nanmax(Z_transformed):.3f}]"
        )
        return Z_transformed

    def _create_grade_map(self, Z_transformed: np.ndarray) -> np.ndarray:
        """创建分级分类图。

        根据阈值 [0.0, 0.3, 0.6] 进行分级：
        - 1: <= 0.0（无藻华）
        - 2: 0.0 < x <= 0.3（轻度）
        - 3: 0.3 < x <= 0.6（中度）
        - 4: > 0.6（重度）

        Args:
            Z_transformed: 转换后的 NDVI 值网格

        Returns:
            分级分类图（1-4）
        """
        grade_map = np.digitize(
            Z_transformed, bins=self._GRADE_THRESHOLDS, right=False
        ).astype(float)
        # digitize 返回 0~len(bins)，调整为 1~len(bins)+1 的类别编号
        grade_map = grade_map + 1

        # 保持 NaN 区域
        nan_mask = np.isnan(Z_transformed)
        grade_map[nan_mask] = np.nan

        logger.debug(
            f"分级统计: 无={np.sum(grade_map == 1)}, "
            f"轻度={np.sum(grade_map == 2)}, "
            f"中度={np.sum(grade_map == 3)}, "
            f"重度={np.sum(grade_map == 4)} 个点"
        )

        return grade_map
