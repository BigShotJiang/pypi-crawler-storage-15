"""新的地图渲染引擎模块（使用专用渲染器的包装版本）。

提供与原 MapRenderer 兼容的接口，但内部使用专用渲染器实现，
提高代码组织性和可维护性。

Author: 水质建模团队
"""

import logging
from typing import Optional, Tuple

import numpy as np
import pandas as pd

from .distribution_renderer import DistributionRenderer
from .interpolation_renderer import InterpolationRenderer
from .level_renderer import LevelRenderer
from .binary_ndvi_renderer import BinaryNDVIRenderer
from .level_ndvi_renderer import LevelNDVIRenderer
from .level_fci_renderer import LevelFCIRenderer
from .render_session import RenderingSession
from .layout import VisualizationLayout
from .grades import GradeManager

logger = logging.getLogger(__name__)


class MapRenderer:
    """地图渲染引擎（包装版本）。

    提供统一的地图渲染接口，支持多种地图类型（散点、热力、等级等）。
    内部使用专用渲染器实现，避免代码重复，提高可维护性。

    Examples:
        >>> renderer = MapRenderer(satellite_info, geo_bounds, layout_manager)
        >>> map_path = renderer.render_distribution(data, "COD", save_path)
    """

    def __init__(
        self,
        satellite_info: Optional[Tuple] = None,
        geo_bounds: Optional[list] = None,
        layout_manager: Optional[VisualizationLayout] = None,
    ):
        """初始化地图渲染器（延迟初始化优化）。

        Args:
            satellite_info: 卫星信息 (width, height, img_data)
            geo_bounds: 地理边界 [min_lon, min_lat, max_lon, max_lat]
            layout_manager: 布局管理器实例

        Note:
            渲染器采用延迟初始化策略，只在首次使用时创建，
            提高初始化性能并减少内存占用。
        """
        self.satellite_info = satellite_info
        self.geo_bounds = geo_bounds
        self.layout_manager = layout_manager or VisualizationLayout()
        self.grade_manager = GradeManager()

        # 延迟初始化：渲染器缓存字典
        self._renderers_cache = {}

        logger.debug("MapRenderer (延迟初始化版) 已初始化")

    def _get_renderer(self, renderer_class):
        """延迟初始化并缓存渲染器实例（共享 GradeManager）。

        Args:
            renderer_class: 渲染器类（如 DistributionRenderer）

        Returns:
            渲染器实例（从缓存或新创建）

        Note:
            使用缓存避免重复创建相同的渲染器，提高性能。
            所有子类渲染器共享 MapRenderer 的 GradeManager 实例，
            消除重复初始化的冗余。
        """
        if renderer_class not in self._renderers_cache:
            logger.debug(f"创建渲��器: {renderer_class.__name__}")
            self._renderers_cache[renderer_class] = renderer_class(
                self.satellite_info,
                self.geo_bounds,
                self.layout_manager,
                self.grade_manager,  # 传递共享的 GradeManager
            )
        return self._renderers_cache[renderer_class]

    def prepare_rendering_session(
        self,
        indicator: str,
        data: pd.DataFrame,
        satellite_geo_bounds: Optional[list],
        data_geo_bounds: Optional[list],
        all_points_outside: bool,
        colorbar_mode: str = "quantitative",
        has_colorbar: bool = True,
    ) -> RenderingSession:
        """准备渲染会话（代理到基础渲染器）。

        Args:
            indicator: 指标名称
            data: 数据 DataFrame
            satellite_geo_bounds: 卫星图地理边界
            data_geo_bounds: 数据地理边界
            all_points_outside: 是否所有点在边界外
            colorbar_mode: Colorbar 模式
            has_colorbar: 是否需要 colorbar

        Returns:
            RenderingSession: 渲染会话对象
        """
        renderer = self._get_renderer(DistributionRenderer)
        return renderer.prepare_rendering_session(
            indicator=indicator,
            data=data,
            satellite_geo_bounds=satellite_geo_bounds,
            data_geo_bounds=data_geo_bounds,
            all_points_outside=all_points_outside,
            colorbar_mode=colorbar_mode,
            has_colorbar=has_colorbar,
        )

    def render_distribution(
        self,
        data: pd.DataFrame,
        indicator: str,
        save_path: str,
        session: RenderingSession,
    ) -> str:
        """渲染散点分布图。

        Args:
            data: 包含经纬度和指标数据的 DataFrame
            indicator: 指标名称
            save_path: 保存路径
            session: 渲染会话，包含共享参数

        Returns:
            str: 保存的文件路径
        """
        renderer = self._get_renderer(DistributionRenderer)
        return renderer.render(
            data=data,
            indicator=indicator,
            save_path=save_path,
            session=session,
        )

    def render_interpolation(
        self,
        data: pd.DataFrame,
        indicator: str,
        Z: np.ndarray,
        grid_lon: np.ndarray,
        grid_lat: np.ndarray,
        save_path: str,
        session: RenderingSession,
    ) -> str:
        """渲染插值热力图。

        Args:
            data: 原始数据 DataFrame
            indicator: 指标名称
            Z: 插值结果网格
            grid_lon: 经度网格
            grid_lat: 纬度网格
            save_path: 保存路径
            session: 渲染会话，包含共享参数

        Returns:
            str: 保存的文件路径
        """
        renderer = self._get_renderer(InterpolationRenderer)
        return renderer.render(
            data=data,
            indicator=indicator,
            Z=Z,
            grid_lon=grid_lon,
            grid_lat=grid_lat,
            save_path=save_path,
            session=session,
        )

    def render_level(
        self,
        Z: np.ndarray,
        grid_lon: np.ndarray,
        grid_lat: np.ndarray,
        indicator: str,
        save_path: str,
        session: RenderingSession,
    ) -> str:
        """渲染国标等级分布图。

        Args:
            Z: 插值结果网格
            grid_lon: 经度网格
            grid_lat: 纬度网格
            indicator: 指标名称
            save_path: 保存路径
            session: 渲染会话，包含共享参数

        Returns:
            str: 保存的文件路径
        """
        renderer = self._get_renderer(LevelRenderer)
        return renderer.render(
            Z=Z,
            grid_lon=grid_lon,
            grid_lat=grid_lat,
            indicator=indicator,
            save_path=save_path,
            session=session,
        )

    def render_ndvi_binary(
        self,
        indicator: str,
        save_path: str,
        Z: np.ndarray,
        session: RenderingSession,
        grid_lon: Optional[np.ndarray] = None,
        grid_lat: Optional[np.ndarray] = None,
    ) -> str:
        """渲染 NDVI 二值化藻华检测图。

        Args:
            indicator: 指标名称（NDVI）
            save_path: 保存路径
            Z: 插值后的 NDVI 值网格
            session: 渲染会话，包含共享参数
            grid_lon: 网格经度（可选）
            grid_lat: 网格纬度（可选）

        Returns:
            str: 保存路径
        """
        renderer = self._get_renderer(BinaryNDVIRenderer)
        return renderer.render(
            indicator=indicator,
            save_path=save_path,
            Z=Z,
            grid_lon=grid_lon,
            grid_lat=grid_lat,
            session=session,
        )

    def render_ndvi_bloom_level(
        self,
        indicator: str,
        save_path: str,
        Z: np.ndarray,
        session: RenderingSession,
        grid_lon: Optional[np.ndarray] = None,
        grid_lat: Optional[np.ndarray] = None,
    ) -> str:
        """渲染 NDVI 藻华程度分级图。

        Args:
            indicator: 指标名称（NDVI）
            save_path: 保存路径
            Z: 插值后的 NDVI 值网格
            session: 渲染会话，包含共享参数
            grid_lon: 网格经度（可选）
            grid_lat: 网格纬度（可选）

        Returns:
            str: 保存路径
        """
        renderer = self._get_renderer(LevelNDVIRenderer)
        return renderer.render(
            indicator=indicator,
            save_path=save_path,
            Z=Z,
            grid_lon=grid_lon,
            grid_lat=grid_lat,
            session=session,
        )

    def render_fci_grade_level(
        self,
        indicator: str,
        save_path: str,
        Z: np.ndarray,
        session: RenderingSession,
        grid_lon: Optional[np.ndarray] = None,
        grid_lat: Optional[np.ndarray] = None,
    ) -> str:
        """渲染 FCI 水质指数等级图。

        Args:
            indicator: 指标名称（FCI）
            save_path: 保存路径
            Z: 插值后的 FCI 值网格
            session: 渲染会话，包含共享参数
            grid_lon: 网格经度（可选）
            grid_lat: 网格纬度（可选）

        Returns:
            str: 保存路径
        """
        renderer = self._get_renderer(LevelFCIRenderer)
        return renderer.render(
            indicator=indicator,
            save_path=save_path,
            Z=Z,
            grid_lon=grid_lon,
            grid_lat=grid_lat,
            session=session,
        )

    def render_colorbar_standalone(
        self,
        indicator: str,
        save_path: str,
        session: RenderingSession,
    ) -> Optional[str]:
        """生成独立的 colorbar 文件（heatmap_only 模式使用）。

        使用 ColorbarBase 独立创建 colorbar，参考 waterqsvg 的最佳实践。
        支持处理边界情况（vmin==vmax）、定量/定性模式、透明背景等。

        Args:
            indicator: 指标名称
            save_path: colorbar 保存路径
            session: 渲染会话对象（包含 vmin, vmax, colorbar_mode）

        Returns:
            Optional[str]: 保存的文件路径，或 None 如果失败

        Examples:
            >>> renderer = MapRenderer(satellite_info, geo_bounds, layout_manager)
            >>> result = renderer.render_colorbar_standalone(
            ...     indicator="pH",
            ...     save_path="/path/to/ph_colorbar.png",
            ...     session=rendering_session
            ... )
        """
        # 使用任意渲染器（如 DistributionRenderer）来代理调用
        # 因为 render_colorbar_standalone 是在 RendererBase 中实现的，
        # 所有子类渲染器都继承了这个方法
        renderer = self._get_renderer(DistributionRenderer)
        return renderer.render_colorbar_standalone(
            indicator=indicator,
            save_path=save_path,
            session=session,
        )
