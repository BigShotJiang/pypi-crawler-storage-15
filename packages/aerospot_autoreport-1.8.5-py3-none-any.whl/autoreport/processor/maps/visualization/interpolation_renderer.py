"""插值热力图渲染模块。

提供专用的插值热力图（Kriging插值结果可视化）渲染功能。

Author: 水质建模团队
"""

import logging
from typing import TYPE_CHECKING, Any, Optional

import numpy as np
import pandas as pd

from .base_renderer import RendererBase
from .render_session import RenderingSession

if TYPE_CHECKING:
    from .base_renderer import RenderingEnvironment

logger = logging.getLogger(__name__)


class InterpolationRenderer(RendererBase):
    """插值热力图渲染器。

    专门用于渲染 Kriging 插值结果的热力图，支持定量和定性两种 colorbar 模式。

    Examples:
        >>> renderer = InterpolationRenderer(satellite_info, geo_bounds, layout_manager)
        >>> map_path = renderer.render(data, "COD", Z, grid_lon, grid_lat, save_path, ...)
    """

    def _prepare_data(self, **kwargs: Any) -> Any:
        """【钩子方法】准备插值热力图的数据。

        处理插值特定的数据准备逻辑：
        - 创建或验证 session
        - 计算原始数据范围
        - 选择地理边界
        - 计算 Z 的数值范围用于调试

        Args:
            **kwargs: 包含以下参数：
                - indicator: 指标名称
                - data: DataFrame（原始数据）
                - Z: np.ndarray（插值结果）
                - session: 渲染会话（可选）
                - satellite_geo_bounds: 卫星地理边界（可选）
                - data_geo_bounds: 数据地理边界（可选）
                - all_points_outside: 是否所有点在边界外
                - colorbar_mode: Colorbar 模式

        Returns:
            Dict[str, Any]: 准备好的数据字典
        """
        # 获取参数
        indicator = kwargs.get("indicator")
        data = kwargs.get("data")
        Z = kwargs.get("Z")
        session = kwargs.get("session")
        satellite_geo_bounds = kwargs.get("satellite_geo_bounds")
        data_geo_bounds = kwargs.get("data_geo_bounds")
        all_points_outside = kwargs.get("all_points_outside", False)

        # 如果没有提供 session，创建一个（向后兼容）
        if session is None:
            session = self.prepare_rendering_session(
                indicator=indicator,
                data=data,
                satellite_geo_bounds=satellite_geo_bounds,
                data_geo_bounds=data_geo_bounds,
                all_points_outside=all_points_outside,
                colorbar_mode=kwargs.get("colorbar_mode", "quantitative"),
            )

        # 计算原始数据范围（用于定性/定量模式）
        original_values = data[indicator].values
        vmin_orig, vmax_orig = np.min(original_values), np.max(original_values)

        # 调试信息：输出Z的数值范围
        z_min, z_max = np.nanmin(Z), np.nanmax(Z)
        logger.debug(f"[DEBUG] {indicator} 插值结果Z的范围: [{z_min:.6f}, {z_max:.6f}]")
        logger.debug(f"[DEBUG] Z的形状: {Z.shape}, 包含NaN数量: {np.isnan(Z).sum()}")
        logger.debug(
            f"[DEBUG] {indicator} 原始数据范围: [{vmin_orig:.6f}, {vmax_orig:.6f}]"
        )

        # 选择地理边界
        geo_bounds = self._select_geo_bounds(
            all_points_outside, satellite_geo_bounds, data_geo_bounds
        )

        # 更新 session 的 geo_bounds
        session.geo_bounds = geo_bounds

        # 调用基类的 _prepare_data，包含所有参数
        env = super()._prepare_data(**kwargs)

        # 添加插值特定的数据
        env["session"] = session
        env["vmin_orig"] = vmin_orig
        env["vmax_orig"] = vmax_orig

        return env

    def render(
        self,
        data: pd.DataFrame,
        indicator: str,
        Z: np.ndarray,
        grid_lon: np.ndarray,
        grid_lat: np.ndarray,
        save_path: str,
        session: Optional["RenderingSession"] = None,
        satellite_geo_bounds: Optional[list] = None,
        data_geo_bounds: Optional[list] = None,
        all_points_outside: bool = False,
        colorbar_mode: str = "quantitative",
    ) -> str:
        """渲染插值热力图。

        Args:
            data: 原始数据 DataFrame
            indicator: 指标名称
            Z: 插值结果网格
            grid_lon: 经度网格
            grid_lat: 纬度网格
            save_path: 保存路径
            session: 渲染会话（可选，用于向后兼容）
            satellite_geo_bounds: 卫星边界
            data_geo_bounds: 数据地理边界
            all_points_outside: 是否所有点都在边界外
            colorbar_mode: colorbar 模式

        Returns:
            str: 保存的文件路径

        Note:
            使用模板方法模式，通过钩子方法实现插值热力图特定逻辑。
        """
        # 如果没有提供 session，创建一个（向后兼容）
        if session is None:
            session = self.prepare_rendering_session(
                indicator=indicator,
                data=data,
                satellite_geo_bounds=satellite_geo_bounds,
                data_geo_bounds=data_geo_bounds,
                all_points_outside=all_points_outside,
                colorbar_mode=colorbar_mode,
            )

        # 计算原始数据范围（用于定性/定量模式）
        original_values = data[indicator].values
        vmin_orig, vmax_orig = np.min(original_values), np.max(original_values)

        # 调试信息：输出Z的数值范围和colorbar参数
        z_min, z_max = np.nanmin(Z), np.nanmax(Z)
        logger.debug(f"[DEBUG] {indicator} 插值结果Z的范围: [{z_min:.6f}, {z_max:.6f}]")
        logger.debug(f"[DEBUG] Z的形状: {Z.shape}, 包含NaN数量: {np.isnan(Z).sum()}")
        logger.debug(
            f"[DEBUG] {indicator} 原始数据范围: [{vmin_orig:.6f}, {vmax_orig:.6f}]"
        )

        # 选择地理边界
        geo_bounds = self._select_geo_bounds(
            all_points_outside, satellite_geo_bounds, data_geo_bounds
        )

        # 更新 session 的 geo_bounds（确保模板方法使用正确的边界）
        session.geo_bounds = geo_bounds

        # 调用模板方法，传递插值特定数据
        return self._execute_template_render(
            indicator=indicator,
            save_path=save_path,
            session=session,
            has_right_element=True,
            right_element_type="colorbar",
            title_template="高光谱反演水质指标 {indicator} 热力图",
            all_points_outside=all_points_outside,
            # 传递给钩子方法的插值特定数据
            data=data,  # 【关键修复】传递原始数据，供 _prepare_data 使用
            Z=Z,
            grid_lon=grid_lon,
            grid_lat=grid_lat,
            vmin_orig=vmin_orig,
            vmax_orig=vmax_orig,
            colorbar_mode=colorbar_mode,
        )

    def _draw_content(
        self,
        ax: Any,
        session: RenderingSession,
        env: "RenderingEnvironment",
        indicator: str,
        hook_context: dict,
        **kwargs: Any,
    ) -> None:
        """【钩子方法】绘制插值热力图。

        Args:
            ax: matplotlib Axes对象
            session: 渲染会话对象
            env: 渲染环境对象
            indicator: 指标名称
            hook_context: 钩子上下文字典，用于在钩子间传递数据
            **kwargs: 包含 Z、grid_lon、grid_lat、vmin_orig、vmax_orig
        """
        try:
            Z = kwargs.get("Z")
            grid_lon = kwargs.get("grid_lon")
            grid_lat = kwargs.get("grid_lat")
            vmin_orig = kwargs.get("vmin_orig")
            vmax_orig = kwargs.get("vmax_orig")
            geo_bounds = session.geo_bounds

            # 验证必要参数
            logger.debug(
                f"[DRAW_DEBUG] Z类型: {type(Z)}, shape: {Z.shape if hasattr(Z, 'shape') else 'N/A'}"
            )
            logger.debug(
                f"[DRAW_DEBUG] grid_lon类型: {type(grid_lon)}, grid_lat类型: {type(grid_lat)}"
            )
            logger.debug(f"[DRAW_DEBUG] geo_bounds: {geo_bounds}")

            if Z is None:
                raise ValueError("Z参数为None")
            if geo_bounds is None:
                raise ValueError("geo_bounds为None")

            # 绘制热力图，使用 geo_bounds 而不是网格范围，确保与 distribution 图的可视化范围一致
            im = ax.imshow(
                Z,
                cmap="jet",
                aspect="auto",
                extent=[geo_bounds[0], geo_bounds[2], geo_bounds[1], geo_bounds[3]],
                origin="lower",
                interpolation="bilinear",
                vmin=vmin_orig,
                vmax=vmax_orig,
            )

            # 保存 im 对象到共享上下文供装饰方法使用
            hook_context["_im"] = im
        except Exception as e:
            logger.error(
                f"绘制 {indicator} 插值热力图内容失败: {str(e)}", exc_info=True
            )
            logger.error(f"[ERROR_CONTEXT] Z: {type(kwargs.get('Z'))}")
            logger.error(
                f"[ERROR_CONTEXT] geo_bounds: {session.geo_bounds if session else 'session为None'}"
            )
            raise

    def _add_decorations(
        self,
        fig: Any,
        ax: Any,
        indicator: str,
        session: RenderingSession,
        env: "RenderingEnvironment",
        hook_context: dict,
        **kwargs: Any,
    ) -> None:
        """【钩子方法】添加 colorbar。

        Args:
            fig: matplotlib Figure对象
            ax: matplotlib Axes对象
            indicator: 指标名称
            session: 渲染会话对象
            env: 渲染环境对象
            hook_context: 钩子上下文字典，包含 _im (imshow对象)
            **kwargs: 额外参数（会被忽略，colorbar_mode 从 session 获取）
        """
        im = hook_context.get("_im")
        if im is None:
            return

        # 从 session 获取 colorbar_mode（不从kwargs）
        # session 中的 colorbar_mode 已经根据 visualization_mode 正确设置
        colorbar_mode = session.colorbar_mode

        # 使用基类的统一colorbar创建方法
        if env.layout_params:
            left, bottom, width, height = env.layout_params
        else:
            left, bottom, width, height = 0, 0, 1, 1

        self._create_and_configure_colorbar(
            fig=fig,
            mappable=im,
            indicator=indicator,
            colorbar_mode=colorbar_mode,
            font_sizes=session.font_sizes,
            left=left,
            width=width,
            bottom=bottom,
            height=height,
        )
