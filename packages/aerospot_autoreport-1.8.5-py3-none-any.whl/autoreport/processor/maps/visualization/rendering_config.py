"""渲染配置管理模块。

提供全局的渲染配置，统一管理硬编码参数。
实现"单一真相来源"原则，所有渲染器共享同一个配置。

Author: 水质建模团队
"""

from dataclasses import dataclass
from typing import Dict, Tuple


@dataclass
class RenderingConfig:
    """全局渲染配置（单一真相来源）。

    集中管理所有渲染过程中的硬编码参数，包括：
    - DPI分辨率配置
    - 布局和间距配置
    - 字体大小配置
    - 保存格式配置

    所有渲染器通过此类获取配置参数，确保一致性。

    Examples:
        >>> config = RenderingConfig()
        >>> dpi = config.DEFAULT_DPI
        >>> cbar_width = config.COLORBAR_WIDTH
    """

    # ==================== DPI 配置 ====================
    #: 默认DPI（生产环境）
    DEFAULT_DPI: int = 100

    #: 高质量DPI（打印/报告用）
    HIGH_QUALITY_DPI: int = 300

    # ==================== Colorbar 配置 ====================
    #: colorbar 宽度（相对于figure宽度）
    COLORBAR_WIDTH: float = 0.03

    #: colorbar 与主axes间距（相对于figure宽度）
    COLORBAR_SPACING: float = 0.01

    # ==================== Legend 配置 ====================
    #: legend 与主axes间距（相对于figure宽度）
    LEGEND_SPACING: float = 0.02

    # ==================== 标题配置 ====================
    #: 标题距离axes顶部的padding
    TITLE_PAD: int = 30

    # ==================== 图形保存配置 ====================
    #: 保存时的padding（inch）
    SAVE_PAD_INCHES: int = 0

    #: 保存格式
    SAVE_FORMAT: str = "png"

    # ==================== 网格配置 ====================
    #: 网格线风格
    GRID_LINESTYLE: str = "--"

    #: 网格线透明度
    GRID_ALPHA: float = 0.3

    # ==================== 字体大小配置 ====================
    #: 基础字体大小
    BASE_FONT_SIZE: int = 48

    #: 标题字体大小（当font_sizes中不存在时的默认值）
    DEFAULT_TITLE_FONT: int = 14

    #: colorbar标签字体大小
    DEFAULT_COLORBAR_LABEL_FONT: int = 10

    #: colorbar刻度字体大小
    DEFAULT_COLORBAR_TICK_FONT: int = 8

    #: legend字体大小
    DEFAULT_LEGEND_FONT: int = 10

    # ==================== 布局参数配置 ====================
    #: 布局左边界（默认值，仅在无卫星图信息时使用）
    #: 正常情况下使用 LayoutStrategy.get_layout_params() 动态计算
    DEFAULT_LAYOUT_LEFT: float = 0.04

    #: 布局下边界（默认值，仅在无卫星图信息时使用）
    #: 正常情况下使用 LayoutStrategy.get_layout_params() 动态计算
    DEFAULT_LAYOUT_BOTTOM: float = 0.08

    #: 布局宽度（默认值，仅在无卫星图信息时使用）
    #: 正常情况下使用 LayoutStrategy.get_layout_params() 动态计算
    DEFAULT_LAYOUT_WIDTH: float = 0.82

    #: 布局高度（默认值，仅在无卫星图信息时使用）
    #: 正常情况下使用 LayoutStrategy.get_layout_params() 动态计算
    DEFAULT_LAYOUT_HEIGHT: float = 0.82

    # ==================== 插值配置 ====================
    #: 默认插值方法（'universal_kriging', 'ordinary_kriging', 'linear'）
    DEFAULT_INTERPOLATION_METHOD: str = "universal_kriging"

    #: Kriging方法的变差函数类型
    KRIGING_VARIOGRAM_MODEL: str = "gaussian"

    # ==================== 适配性参数 ====================
    #: 字体大小的最小倍数
    MIN_SIZE_FACTOR: float = 0.6

    #: 字体大小的最大倍数
    MAX_SIZE_FACTOR: float = 1.2

    def get_colorbar_position(
        self, left: float, width: float, bottom: float, height: float
    ) -> Tuple[float, float, float, float]:
        """计算colorbar的位置坐标。

        Args:
            left: 主axes的左边界
            width: 主axes的宽度
            bottom: 主axes的下边界
            height: 主axes的高度

        Returns:
            Tuple[float, float, float, float]: colorbar的 (left, bottom, width, height)
        """
        cbar_left = left + width + self.COLORBAR_SPACING
        cbar_width = self.COLORBAR_WIDTH
        cbar_height = height

        return cbar_left, bottom, cbar_width, cbar_height

    def get_font_sizes(self) -> Dict[str, int]:
        """获取默认字体大小字典。

        Returns:
            Dict[str, int]: 包含各种文本元素的字体大小
        """
        return {
            "global": self.BASE_FONT_SIZE,
            "title": self.DEFAULT_TITLE_FONT,
            "colorbar_label": self.DEFAULT_COLORBAR_LABEL_FONT,
            "colorbar_tick": self.DEFAULT_COLORBAR_TICK_FONT,
            "legend": self.DEFAULT_LEGEND_FONT,
        }

    def __post_init__(self):
        """验证配置参数的合理性。"""
        assert self.DEFAULT_DPI > 0, "DPI必须大于0"
        assert 0 < self.COLORBAR_WIDTH < 1, "colorbar宽度必须在0-1之间"
        assert 0 < self.COLORBAR_SPACING < 1, "colorbar间距必须在0-1之间"
        assert 0 < self.DEFAULT_LAYOUT_WIDTH < 1, "布局宽度必须在0-1之间"
        assert self.MIN_SIZE_FACTOR > 0, "最小尺寸倍数必须大于0"
        assert self.MAX_SIZE_FACTOR > 0, "最大尺寸倍数必须大于0"


# 全局配置实例（单例模式）
global_rendering_config = RenderingConfig()
