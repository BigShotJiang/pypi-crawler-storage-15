"""绘图元素策略类模块 - 策略模式实现。

提供colorbar和legend的不同实现策略，实现开闭原则(OCP)。
支持不同的绘图需求而无需修改主体代码。

Author: 水质建模团队
"""

import logging
from abc import ABC, abstractmethod
from typing import List, Any, Dict, Optional


logger = logging.getLogger(__name__)


# ==================== Colorbar Strategies ====================


class ColorbarStrategy(ABC):
    """Colorbar创建策略基类（抽象）。

    定义colorbar创建和配置的通用接口。
    """

    @abstractmethod
    def configure(
        self,
        cbar: Any,
        vmin: float,
        vmax: float,
        indicator: str,
        font_sizes: Dict[str, int],
    ) -> None:
        """配置colorbar。

        Args:
            cbar: matplotlib colorbar对象
            vmin: 最小值
            vmax: 最大值
            indicator: 指标名称
            font_sizes: 字体大小字典
        """
        pass


class QuantitativeColorbarStrategy(ColorbarStrategy):
    """定量colorbar策略 - 连续数值映射。

    用于连续数值的colorbar展示，显示指标名称和单位。
    """

    def configure(
        self,
        cbar: Any,
        vmin: float,
        vmax: float,
        indicator: str,
        font_sizes: Dict[str, int],
    ) -> None:
        """配置定量colorbar。

        Args:
            cbar: matplotlib colorbar对象
            vmin: 最小值
            vmax: 最大值
            indicator: 指标名称
            font_sizes: 字体大小字典

        Note:
            定量模式下colorbar标签显示指标名称和单位（如有）。
        """
        # 标签已在base_renderer._create_and_configure_colorbar中设置
        # 这里可以添加定量模式的额外配置
        logger.debug(f"定量Colorbar配置: {indicator}, 范围=[{vmin:.3f}, {vmax:.3f}]")


class QualitativeColorbarStrategy(ColorbarStrategy):
    """定性colorbar策略 - 分类数据映射。

    用于分类或等级数据，显示"低"、"高"等定性标签。
    """

    def configure(
        self,
        cbar: Any,
        vmin: float,
        vmax: float,
        indicator: str,
        font_sizes: Dict[str, int],
    ) -> None:
        """配置定性colorbar。

        配置定性模式colorbar：
        1. 处理vmin==vmax的特殊情况（扩展显示范围）
        2. 设置刻度为[vmin, vmax]
        3. 设置刻度标签为["低", "高"]

        Args:
            cbar: matplotlib colorbar对象
            vmin: 最小值
            vmax: 最大值
            indicator: 指标名称
            font_sizes: 字体大小字典
        """
        # 处理vmin==vmax的情况：扩展显示范围
        if vmin == vmax:
            display_range = (
                vmin - abs(vmin) * 0.1 if vmin != 0 else 0,
                vmax + abs(vmax) * 0.1 if vmax != 0 else 1,
            )
            cbar.mappable.set_clim(display_range)
            cbar.set_ticks([display_range[0], display_range[1]])
            logger.debug(
                f"定性Colorbar (vmin==vmax扩展): {indicator}, "
                f"显示范围=[{display_range[0]:.3f}, {display_range[1]:.3f}]"
            )
        else:
            cbar.set_ticks([vmin, vmax])
            logger.debug(f"定性Colorbar: {indicator}, 范围=[{vmin:.3f}, {vmax:.3f}]")

        # 设置定性标签
        cbar.set_ticklabels(["低", "高"])


class ColorbarStrategyFactory:
    """Colorbar策略工厂类。

    根据colorbar_mode参数选择合适的策略。
    """

    _strategies = {
        "quantitative": QuantitativeColorbarStrategy,
        "qualitative": QualitativeColorbarStrategy,
    }

    @classmethod
    def create(cls, colorbar_mode: str) -> ColorbarStrategy:
        """创建指定模式的colorbar策略。

        Args:
            colorbar_mode: colorbar模式 ("quantitative" 或 "qualitative")

        Returns:
            ColorbarStrategy: 对应的策略实现

        Raises:
            ValueError: 当colorbar_mode不存在时
        """
        if colorbar_mode not in cls._strategies:
            raise ValueError(
                f"未知的colorbar模式: {colorbar_mode}. "
                f"支持的模式: {list(cls._strategies.keys())}"
            )

        strategy_class = cls._strategies[colorbar_mode]
        return strategy_class()

    @classmethod
    def register(cls, mode: str, strategy_class: type) -> None:
        """注册新的colorbar策略。

        支持扩展：新增colorbar模式时无需修改factory代码。

        Args:
            mode: colorbar模式名称
            strategy_class: ColorbarStrategy的子类
        """
        if not issubclass(strategy_class, ColorbarStrategy):
            raise TypeError(f"{strategy_class} 必须是 ColorbarStrategy 的子类")
        cls._strategies[mode] = strategy_class
        logger.info(f"已注册colorbar策略: {mode}")


# ==================== Legend Strategies ====================


class LegendStrategy(ABC):
    """图例创建策略基类（抽象）。

    定义图例创建的通用接口。
    """

    @abstractmethod
    def create(
        self,
        ax: Any,
        patches: List[Any],
        font_sizes: Dict[str, int],
        rendering_config: Optional[Any] = None,
    ) -> None:
        """创建图例。

        Args:
            ax: matplotlib Axes对象
            patches: mpatches.Patch对象列表
            font_sizes: 字体大小字典
        """
        pass


class DefaultLegendStrategy(LegendStrategy):
    """默认图例策略 - 标准图例创建。

    创建位于axes右侧的标准图例。
    """

    def create(
        self,
        ax: Any,
        patches: List[Any],
        font_sizes: Dict[str, int],
        rendering_config: Optional[Any] = None,
    ) -> None:
        """创建默认位置的图例。

        在axes右侧外创建图例，避免与主图内容重叠。

        Args:
            ax: matplotlib Axes对象
            patches: mpatches.Patch对象列表
            font_sizes: 字体大小字典
            rendering_config: 渲染配置对象
        """
        from .rendering_config import global_rendering_config
        config = rendering_config or global_rendering_config

        ax.legend(
            handles=patches,
            bbox_to_anchor=(1.02, 1),  # 右侧外
            loc="upper left",
            fontsize=font_sizes.get(
                "legend", config.DEFAULT_LEGEND_FONT
            ),
            frameon=True,
            fancybox=False,
            shadow=False,
            ncol=1,
            columnspacing=0.5,
            handlelength=1.5,
            handletextpad=0.5,
        )
        logger.debug(f"图例已创建: {len(patches)}个项目")


class InlineLegendStrategy(LegendStrategy):
    """内嵌图例策略 - 图形内部图例。

    创建位于图形内部的紧凑图例（用于空间有限的情况）。
    """

    def create(
        self,
        ax: Any,
        patches: List[Any],
        font_sizes: Dict[str, int],
        rendering_config: Optional[Any] = None,
    ) -> None:
        """创建图形内部的图例。

        在图形内部右上角创建图例，更节省空间。

        Args:
            ax: matplotlib Axes对象
            patches: mpatches.Patch对象列表
            font_sizes: 字体大小字典
            rendering_config: 渲染配置对象
        """
        from .rendering_config import global_rendering_config
        config = rendering_config or global_rendering_config

        ax.legend(
            handles=patches,
            loc="upper right",  # 内部右上
            fontsize=font_sizes.get(
                "legend", config.DEFAULT_LEGEND_FONT
            ),
            frameon=True,
            fancybox=False,
            shadow=False,
            ncol=1,
        )
        logger.debug(f"内嵌图例已创建: {len(patches)}个项目")


class LegendStrategyFactory:
    """图例策略工厂类。

    根据需求选择合适的图例创建策略。
    """

    _strategies = {
        "default": DefaultLegendStrategy,
        "inline": InlineLegendStrategy,
    }

    @classmethod
    def create(cls, legend_style: str = "default") -> LegendStrategy:
        """创建指定风格的图例策略。

        Args:
            legend_style: 图例风格 ("default" 或 "inline")

        Returns:
            LegendStrategy: 对应的策略实现

        Raises:
            ValueError: 当legend_style不存在时
        """
        if legend_style not in cls._strategies:
            raise ValueError(
                f"未知的图例风格: {legend_style}. "
                f"支持的风格: {list(cls._strategies.keys())}"
            )

        strategy_class = cls._strategies[legend_style]
        return strategy_class()

    @classmethod
    def register(cls, style: str, strategy_class: type) -> None:
        """注册新的图例策略。

        支持扩展：新增图例风格时无需修改factory代码。

        Args:
            style: 图例风格名称
            strategy_class: LegendStrategy的子类
        """
        if not issubclass(strategy_class, LegendStrategy):
            raise TypeError(f"{strategy_class} 必须是 LegendStrategy 的子类")
        cls._strategies[style] = strategy_class
        logger.info(f"已注册图例策略: {style}")
