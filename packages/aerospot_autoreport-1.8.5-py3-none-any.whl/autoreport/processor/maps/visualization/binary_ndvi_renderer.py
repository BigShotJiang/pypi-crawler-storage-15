"""NDVI 二值化藻华检测图渲染模块。

专门用于渲染基于二值化阈值的 NDVI 藻华检测图。
分类标准：
- < 0: 无藻华（蓝色）
- >= 0: 有藻华（绿色）

Author: 水质建模团队
"""

import logging
from typing import TYPE_CHECKING, Any, Optional

import matplotlib.patches as mpatches
import numpy as np
from matplotlib.colors import BoundaryNorm, ListedColormap

from .base_renderer import RendererBase
from .render_session import RenderingSession

if TYPE_CHECKING:
    from .base_renderer import RenderingEnvironment

logger = logging.getLogger(__name__)


class BinaryNDVIRenderer(RendererBase):
    """NDVI 二值化藻华检测图渲染器。

    专门用于二值化 NDVI 检测，将结果分为两个类别：
    - 无藻华（NDVI < 0）
    - 有藻华（NDVI >= 0）

    This renderer follows SRP principle by focusing solely on binary classification.

    Examples:
        >>> renderer = BinaryNDVIRenderer(satellite_info, geo_bounds, layout_manager)
        >>> map_path = renderer.render(
        ...     indicator="NDVI",
        ...     save_path="/path/to/output.png",
        ...     Z=ndvi_grid,
        ...     grid_lon=lon_grid,
        ...     grid_lat=lat_grid,
        ...     session=rendering_session
        ... )
    """

    # 二值化类别定义
    _GRADE_LABELS = ["无藻华", "有藻华"]
    _GRADE_COLORS = ["#0000FF", "#00FF00"]  # 蓝色、绿色
    _THRESHOLD = 0  # 二值化阈值

    def _prepare_data(self, **kwargs: Any) -> Any:
        """【钩子方法】准备二值化 NDVI 图的数据。

        处理二值化 NDVI 特定的数据准备逻辑：
        - 验证 Z 是否有效
        - 执行二值化处理

        Args:
            **kwargs: 包含以下参数：
                - Z: np.ndarray（NDVI 值）
                - 其他参数会被保留在返回字典中

        Returns:
            Dict[str, Any]: 准备好的数据字典，包含 binary_map
        """
        Z = kwargs.get("Z")

        if Z is None:
            logger.warning("插值数据 Z 为空，返回空数据")
            return super()._prepare_data(**kwargs)

        # 创建二值化分类图
        binary_map = self._create_binary_map(Z)

        # 调用基类的 _prepare_data
        env = super()._prepare_data(**kwargs)

        # 添加二值化特定的数据
        env["binary_map"] = binary_map

        return env

    def render(
        self,
        indicator: str,
        save_path: str,
        Z: np.ndarray,
        grid_lon: Optional[np.ndarray],
        grid_lat: Optional[np.ndarray],
        session: RenderingSession,
    ) -> str:
        """渲染 NDVI 二值化藻华检测图。

        基于阈值 0 进行二值化分类：
        - < 0: 无藻华（蓝色）
        - >= 0: 有藻华（绿色）

        Args:
            indicator: 指标名称（NDVI）
            save_path: 保存路径
            Z: 插值后的 NDVI 值网格
            grid_lon: 网格经度（可选）
            grid_lat: 网格纬度（可选）
            session: 渲染会话对象，包含所有共享参数

        Returns:
            str: 保存路径或 "skip" 如果无有效数据

        Raises:
            Exception: 渲染过程中的任何错误

        Note:
            使用模板方法模式，通过钩子方法实现二值化藻华检测图特定逻辑。
        """
        if Z is None:
            logger.warning("插值数据 Z 为空，跳过 NDVI 二值化藻华检测图生成")
            return "skip"

        # 核心：基于阈值 0 进行二值化
        binary_map = self._create_binary_map(Z)

        # 调用模板方法，传递二值化藻华检测图特定数据
        return self._execute_template_render(
            indicator=indicator,
            save_path=save_path,
            session=session,
            has_right_element=True,
            right_element_type="legend",
            title_template="基于 {indicator} 的藻华二值化分布图",
            all_points_outside=False,
            # 传递给钩子方法的二值化特定数据
            binary_map=binary_map,
            grid_lon=grid_lon,
            grid_lat=grid_lat,
        )

    def _draw_content(
        self,
        ax: Any,
        session: RenderingSession,
        env: "RenderingEnvironment",
        indicator: str,
        hook_context: dict,
        **kwargs: Any,
    ) -> None:
        """【钩子方法】绘制二值化藻华检测图。

        Args:
            ax: matplotlib Axes对象
            session: 渲染会话对象
            env: 渲染环境对象
            indicator: 指标名称
            hook_context: 钩子上下文字典，用于在钩子间传递数据
            **kwargs: 包含 binary_map
        """
        binary_map = kwargs["binary_map"]
        geo_bounds = session.geo_bounds

        # 创建分级颜色图
        cmap = ListedColormap(self._GRADE_COLORS)
        bounds = [1, 2, 3]
        norm = BoundaryNorm(bounds, cmap.N)

        # 确定 extent（显示范围）
        extent = [
            geo_bounds[0],
            geo_bounds[2],
            geo_bounds[1],
            geo_bounds[3],
        ]

        # 绘制二值化图
        ax.imshow(
            binary_map,
            extent=extent,
            aspect="auto",
            origin="lower",
            cmap=cmap,
            norm=norm,
        )

        # 保存 patches 到共享上下文供装饰方法使用
        patches = [
            mpatches.Patch(color=self._GRADE_COLORS[i], label=self._GRADE_LABELS[i])
            for i in range(len(self._GRADE_LABELS))
        ]
        hook_context["_patches"] = patches

    def _add_decorations(
        self,
        fig: Any,
        ax: Any,
        indicator: str,
        session: RenderingSession,
        env: "RenderingEnvironment",
        hook_context: dict,
        **kwargs: Any,
    ) -> None:
        """【钩子方法】添加图例。

        Args:
            fig: matplotlib Figure对象
            ax: matplotlib Axes对象
            indicator: 指标名称
            session: 渲染会话对象
            env: 渲染环境对象
            hook_context: 钩子上下文字典，包含 _patches (图例补丁列表)
            **kwargs: 额外参数
        """
        patches = hook_context.get("_patches")
        if patches is None:
            return

        # 使用基类的统一图例创建方法
        self._create_legend(ax, patches, session.font_sizes)

    def _create_binary_map(self, Z: np.ndarray) -> np.ndarray:
        """创建二值化分类图。

        Args:
            Z: 原始 NDVI 值网格

        Returns:
            二值化后的分类图（1 或 2）
        """
        binary_map = np.full_like(Z, np.nan)
        binary_map[Z < self._THRESHOLD] = 1  # 无藻华
        binary_map[Z >= self._THRESHOLD] = 2  # 有藻华

        # 保持 NaN 区域
        nan_mask = np.isnan(Z)
        binary_map[nan_mask] = np.nan

        logger.debug(
            f"二值化分类: <{self._THRESHOLD}={np.sum(Z < self._THRESHOLD)} 个点, "
            f">={self._THRESHOLD}={np.sum(Z >= self._THRESHOLD)} 个点"
        )

        return binary_map
