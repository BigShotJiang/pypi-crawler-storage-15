"""Maps 模块 - 模块化地图生成系统。

原始的 2600 行单文件已分解为 9 个专注的模块，采用模块化和面向对象设计。

## 快速开始

### 使用新的面向对象 API（推荐）

```python
from autoreport.processor.maps import (
    InterpolationEngine,
    MapRenderer,
    RendererFactory,
    GeoUtilities,
    SatelliteImageLoader,
)

# 解析地理边界
geo_utilities = GeoUtilities()
geo_bounds = geo_utilities.parse_bounds(geo_info)

# 加载卫星图像
satellite_loader = SatelliteImageLoader()
satellite_info = satellite_loader.load(satellite_path)

# 创建插值引擎
engine = InterpolationEngine()
Z, lon, lat, mask, boundary = engine.enhanced_interpolate(
    data=pred_data,
    indicator_col='COD',
    geo_bounds=geo_bounds,
    boundary_manager=boundary_manager
)

# 创建渲染工厂和渲染器
factory = RendererFactory(satellite_info=satellite_info, geo_bounds=geo_bounds)
renderer = factory.get_renderer()

# 生成地图
dist_path = renderer.render_distribution(
    data=pred_data,
    indicator='COD',
    save_path='distribution.png',
    satellite_info=satellite_info,
    geo_bounds=geo_bounds
)

interp_path = renderer.render_interpolation(
    data=pred_data,
    indicator='COD',
    Z=Z,
    grid_lon=lon,
    grid_lat=lat,
    save_path='interpolation.png',
    satellite_info=satellite_info,
    geo_bounds=geo_bounds
)
```

## 模块结构

- **core/**: 核心算法
  - kriging_config.py: 克里金配置
  - data_transform.py: 数据转换
  - boundaries.py: 边界检测
  - interpolation.py: 插值引擎
  - validators.py: 数据验证
  - grid_builder.py: 网格构建
  - boundary_chain.py: 边界链式检测
  - map_task.py: 地图生成任务
  - deprecation.py: 废弃 API 工具

- **visualization/**: 可视化和渲染
  - layout.py: 布局管理
  - grades.py: 分级标准
  - renderers.py: 地图渲染
  - renderer_factory.py: 渲染工厂

- **utilities/**: 工具函数
  - geo.py: 地理转换
  - satellite.py: 卫星图像处理

## 设计模式

- **Factory Pattern**: RendererFactory 用于延迟初始化和缓存
- **Strategy Pattern**: BoundaryDetectionChain 和 LayoutStrategy 用于灵活的算法选择
- **Chain of Responsibility**: BoundaryDetectionChain 用于多级回退
"""

# ==================== 核心导出 ====================

from .core import (
    InterpolationEngine,
    BoundaryDetector,
    DataTransformer,
    DataValidator,
    GridBuilder,
    BoundaryDetectionChain,
    MapGenerationTask,
    KRIGING_CONFIG,
    GLOBAL_KRIGING_METHOD,
)

from .visualization import (
    VisualizationLayout,
    GradeManager,
    MapRenderer,
    RendererFactory,
    LayoutStrategy,
    INDICATOR_GRADE_CONFIG,
)

from .utilities import (
    GeoUtilities,
    SatelliteImageLoader,
)

# ==================== Phase 1 新增（heatmap_only独立实现）====================

from .heatmap_generator import HeatmapGenerator
from .colorbar_generator import ColorbarGenerator
from .precise_boundary_calculator import PreciseBoundaryCalculator

# ==================== 导出列表 ====================

__all__ = [
    # Core - 核心类
    "InterpolationEngine",
    "BoundaryDetector",
    "DataTransformer",
    "DataValidator",
    "GridBuilder",
    "BoundaryDetectionChain",
    "MapGenerationTask",
    # Core - 配置
    "KRIGING_CONFIG",
    "GLOBAL_KRIGING_METHOD",
    # Visualization - 渲染类
    "MapRenderer",
    "RendererFactory",
    "VisualizationLayout",
    "LayoutStrategy",
    "GradeManager",
    # Visualization - 配置
    "INDICATOR_GRADE_CONFIG",
    # Utilities - 工具类
    "GeoUtilities",
    "SatelliteImageLoader",
    # Phase 1 新增 - heatmap_only独立实现
    "HeatmapGenerator",
    "ColorbarGenerator",
    "PreciseBoundaryCalculator",
]
