"""卫星图像加载工具模块。

提供卫星图像文件的读取和处理功能。

Author: 水质建模团队
"""

import logging
import os
from typing import List, Optional

import matplotlib.image as mpimg
from PIL import Image

logger = logging.getLogger(__name__)


class SatelliteImageLoader:
    """卫星图像加载工具类。

    提供卫星图像文件的读取和处理。

    Examples:
        >>> result = SatelliteImageLoader.load('satellite.png')
        >>> if result[0] is not None:
        ...     width, height, img_data = result
        ...     print(f'Image size: {width}x{height}')
    """

    @staticmethod
    def load(img_path: str) -> List[Optional[object]]:
        """读取卫星图像文件。

        从文件系统读取卫星图像，返回图像的宽度、高度和像素数据。
        如果文件不存在或读取失败，返回 [None, None, None]。

        Args:
            img_path: 卫星图像文件路径

        Returns:
            List[Optional]:
                - img_width: 图像宽度（像素）
                - img_height: 图像高度（像素）
                - original_img: 图像像素数据（numpy 数组，RGB）
                如果读取失败则返回 [None, None, None]

        Notes:
            - 使用 PIL 读取图像尺寸
            - 使用 matplotlib 读取像素数据（RGB 三通道）
            - 自动错误处理和日志记录

        Examples:
            >>> # 成功读取
            >>> width, height, img_data = SatelliteImageLoader.load('satellite.png')
            >>> if width is not None:
            ...     print(f'Image loaded: {width}x{height}')
            >>> else:
            ...     print('Failed to load image')
        """
        if os.path.exists(img_path):
            try:
                # 读取卫星图像
                satellite_img = Image.open(img_path)
                img_width, img_height = satellite_img.size

                # 读取原始图像（RGB 三通道）
                original_img = mpimg.imread(img_path)[:, :, :3]

                logger.info(f"成功读取卫星图像: {img_path} ({img_width}x{img_height})")

                return [img_width, img_height, original_img]
            except Exception as e:
                logger.error(
                    f"读取或处理卫星图像失败: {str(e)}, 将使用空白背景绘制点..."
                )
                return [None, None, None]
        else:
            logger.warning(f"找不到卫星图像 {img_path}，将使用空白背景")
            return [None, None, None]
