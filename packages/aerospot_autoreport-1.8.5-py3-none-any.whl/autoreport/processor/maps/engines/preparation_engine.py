#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
地图准备引擎

负责从报告数据中提取和准备地图生成所需的所有数据。
这是从 AeroSpotReportGenerator._prepare_map_generation_data() 提取的逻辑。
"""

import logging
from typing import Any, Dict, Optional

import pandas as pd

from ....models.map_data import MapPrepData, SatelliteInfo
from ..utilities.coordinate_projection import GeoUtilities
from ..utilities.satellite import SatelliteImageLoader

logger = logging.getLogger(__name__)


class MapPreparationEngine:
    """地图数据准备引擎

    职责：
    1. 从报告数据中提取必要的数据源（pred_data, uav_data, measure_data）
    2. 确定数据源优先级（pred_data > uav_data）
    3. 解析和验证地理边界
    4. 加载卫星图像信息
    5. 提取有效指标列表
    6. 返回强类型的 MapPrepData 对象
    """

    def __init__(
        self,
        geo_utilities: GeoUtilities,
        satellite_loader: SatelliteImageLoader,
    ) -> None:
        """初始化地图准备引擎

        Args:
            geo_utilities: 地理工具实例
            satellite_loader: 卫星图像加载器实例
        """
        self.geo_utilities = geo_utilities
        self.satellite_loader = satellite_loader

    def prepare(
        self,
        report_data: Dict[str, Any],
        visualization_mode: str = "quantitative",
    ) -> Optional[MapPrepData]:
        """准备地图生成所需的数据

        从 report_data 中提取所有必要数据，用于地图生成。

        Args:
            report_data: 报告数据字典，包含 geo_info, image_resources, uav_data 等
            visualization_mode: 可视化模式 ("quantitative" 或 "qualitative")

        Returns:
            MapPrepData: 包含所有必要数据的强类型对象，如果出错返回 None
        """
        try:
            # 1. 获取必要的数据
            geo_info = report_data["geo_info"]
            satellite_img = report_data["image_resources"]["satellite_img"]
            pred_data = report_data.get("all_pred_data", None)
            uav_data = report_data.get("uav_data", None)
            measure_data = report_data.get("measure_data", None)

            logger.info(f"读取到的可视化模式: {visualization_mode}")

            # 2. 确定使用哪个数据源（降级逻辑：优先 pred_data，其次 uav_data）
            data_to_process = self._select_data_source(pred_data, uav_data)
            if data_to_process is None:
                logger.warning(
                    "模型优化后数据和无人机反演数据都为空或无效，跳过地图生成"
                )
                return None

            # 3. 解析地理边界
            satellite_geo_bounds = self._parse_geo_bounds(geo_info)
            if satellite_geo_bounds is None:
                return None

            # 4. 计算数据地理边界
            data_geo_bounds = self._calculate_data_bounds(data_to_process)
            if data_geo_bounds is None:
                return None

            # 5. 检查数据点是否都在卫星图范围外
            all_points_outside = self._check_points_outside(
                data_geo_bounds, satellite_geo_bounds
            )

            # 6. 加载卫星图像
            satellite_info = self._load_satellite_image(
                satellite_img, satellite_geo_bounds
            )
            if satellite_info is None:
                return None

            # 7. 获取指标列表（从数据中）
            indicator_columns = self._extract_indicator_columns(data_to_process)
            if not indicator_columns:
                logger.warning("未找到有效指标列，跳过地图生成")
                return None

            # 8. 检查是否有实测数据（用于决定 colorbar 模式）
            has_measured_data = measure_data is not None and not measure_data.empty
            logger.info(f"是否有实测数据: {has_measured_data}")

            # 9. 构建并返回 MapPrepData
            prep_data = MapPrepData(
                geo_info=geo_info,
                satellite_info=satellite_info,
                visualization_mode=visualization_mode,
                data_to_process=data_to_process,
                pred_data=pred_data,
                uav_data=uav_data,
                measure_data=measure_data,
                satellite_geo_bounds=satellite_geo_bounds,
                data_geo_bounds=data_geo_bounds,
                all_points_outside=all_points_outside,
                indicator_columns=indicator_columns,
                has_measured_data=has_measured_data,
                satellite_img=satellite_img,
            )

            # 验证数据完整性
            prep_data.validate()
            logger.info(f"地图准备数据创建成功: {prep_data.get_data_summary()}")
            return prep_data

        except Exception as e:
            logger.error(f"准备地图生成数据失败: {str(e)}", exc_info=True)
            return None

    def _select_data_source(
        self,
        pred_data: Optional[pd.DataFrame],
        uav_data: Optional[pd.DataFrame],
    ) -> Optional[pd.DataFrame]:
        """选择数据源（优先级：pred_data > uav_data）

        Args:
            pred_data: 模型优化后的数据
            uav_data: 无人机反演数据

        Returns:
            选中的数据源，如果都无效则返回 None
        """
        if pred_data is not None and not pred_data.empty:
            logger.info(f"使用 模型优化后数据，包含 {len(pred_data)} 条记录")
            return pred_data
        elif uav_data is not None and not uav_data.empty:
            logger.warning(f"使用 无人机反演数据，包含 {len(uav_data)} 条记录")
            return uav_data
        else:
            return None

    def _parse_geo_bounds(
        self, geo_info: Dict[str, Any]
    ) -> Optional[tuple[float, float, float, float]]:
        """解析地理边界

        Args:
            geo_info: 地理信息字典

        Returns:
            地理边界元组 (min_lon, min_lat, max_lon, max_lat)，失败返回 None
        """
        try:
            geo_bounds = self.geo_utilities.parse_bounds(geo_info)
            logger.info(f"卫星图地理边界: {geo_bounds}")
            return geo_bounds
        except Exception as e:
            logger.error(f"解析地理边界失败: {str(e)}")
            return None

    def _calculate_data_bounds(
        self, data: pd.DataFrame
    ) -> Optional[tuple[float, float, float, float]]:
        """计算数据地理边界

        Args:
            data: 包含 Longitude 和 Latitude 列的数据

        Returns:
            数据地理边界元组 (min_lon, min_lat, max_lon, max_lat)，失败返回 None
        """
        try:
            data_geo_bounds = (
                float(data["Longitude"].min()),
                float(data["Latitude"].min()),
                float(data["Longitude"].max()),
                float(data["Latitude"].max()),
            )
            logger.info(f"数据地理边界: {data_geo_bounds}")
            return data_geo_bounds
        except Exception as e:
            logger.error(f"计算数据地理边界失败: {str(e)}")
            return None

    def _check_points_outside(
        self,
        data_bounds: tuple[float, float, float, float],
        satellite_bounds: tuple[float, float, float, float],
    ) -> bool:
        """检查数据点是否都在卫星图范围外

        Args:
            data_bounds: 数据地理边界
            satellite_bounds: 卫星图地理边界

        Returns:
            True 如果所有点都在范围外，否则 False
        """
        try:
            all_points_outside = (
                data_bounds[0] > satellite_bounds[2]
                or data_bounds[2] < satellite_bounds[0]
                or data_bounds[1] > satellite_bounds[3]
                or data_bounds[3] < satellite_bounds[1]
            )
            if all_points_outside:
                logger.warning("所有数据点都在卫星图像范围外")
            return all_points_outside
        except Exception as e:
            logger.error(f"检查点范围失败: {str(e)}")
            return False

    def _load_satellite_image(
        self, satellite_img: str, geo_bounds: tuple[float, float, float, float]
    ) -> Optional[SatelliteInfo]:
        """加载卫星图像

        Args:
            satellite_img: 卫星图像路径或 URL
            geo_bounds: 地理边界

        Returns:
            SatelliteInfo 对象，失败返回 None
        """
        try:
            # 使用 satellite_loader 加载图像
            # 返回 [width, height, img_data]
            result = self.satellite_loader.load(satellite_img)
            logger.info("卫星图像加载成功")

            # 提取宽度和高度
            width = result[0] if result and len(result) > 0 else None
            height = result[1] if result and len(result) > 1 else None

            # 构建元数据字典
            metadata: Dict[str, Any] = {
                "img_data": result[2] if result and len(result) > 2 else None
            }

            # 转换为 SatelliteInfo 对象
            satellite_info = SatelliteInfo(
                path=satellite_img,
                geo_bounds=geo_bounds,
                width=width,  # type: ignore
                height=height,  # type: ignore
                metadata=metadata,
            )
            satellite_info.validate()
            return satellite_info

        except Exception as e:
            logger.error(f"加载卫星图像失败: {str(e)}")
            return None

    def _extract_indicator_columns(self, data: pd.DataFrame) -> list[str]:
        """提取有效指标列名

        Args:
            data: 数据 DataFrame

        Returns:
            指标列名列表（排除 Longitude, Latitude, index）
        """
        indicator_columns = [
            col for col in data.columns if col not in ["Longitude", "Latitude", "index"]
        ]
        logger.info(f"提取到 {len(indicator_columns)} 个指标列: {indicator_columns}")
        return indicator_columns
