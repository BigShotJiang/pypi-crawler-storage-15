#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
渲染引擎

负责地图的统一渲染逻辑，消除 _render_* 方法中的重复代码。
使用策略模式和模板方法模式来处理不同的地图类型。
"""

import logging
from typing import Any, Callable, Dict, Optional

import numpy as np
import pandas as pd

from ....models.map_data import RenderingResult
from ....processor.maps.visualization.render_session import RenderingSession

logger = logging.getLogger(__name__)


class RenderingEngine:
    """地图渲染引擎

    职责：
    1. 提供统一的渲染接口（使用模板方法模式）
    2. 消除重复的错误处理和日志记录代码
    3. 支持不同地图类型的渲染
    4. 返回强类型的 RenderingResult 对象
    """

    # 渲染方法映射
    RENDER_METHODS = {
        "distribution": "render_distribution",
        "interpolation": "render_interpolation",
        "clean_interpolation_svg": "render_clean_interpolation_svg",
        "level": "render_level",
        "ndvi_binary": "render_ndvi_binary",
        "ndvi_bloom_level": "render_ndvi_bloom_level",
        "fci_grade_level": "render_fci_grade_level",
    }

    def __init__(self, renderer: Any) -> None:
        """初始化渲染引擎

        Args:
            renderer: 地图渲染器实例（通常是 RendererFactory 的输出）
        """
        self.renderer = renderer

    def render_distribution(
        self,
        data: pd.DataFrame,
        indicator: str,
        save_path: str,
        session: RenderingSession,
    ) -> Optional[str]:
        """渲染散点分布图

        Args:
            data: 数据 DataFrame
            indicator: 指标名称
            save_path: 保存路径
            session: 渲染会话

        Returns:
            生成的文件路径，失败返回 None
        """
        return self._render_with_template(
            lambda: self.renderer.render_distribution(
                data=data,
                indicator=indicator,
                save_path=save_path,
                session=session,
            ),
            map_type="distribution",
            indicator=indicator,
        )

    def render_interpolation(
        self,
        indicator: str,
        save_path: str,
        session: RenderingSession,
        data: pd.DataFrame,
        Z: np.ndarray,
        grid_lon: np.ndarray,
        grid_lat: np.ndarray,
    ) -> Optional[str]:
        """渲染插值热力图

        Args:
            indicator: 指标名称
            save_path: 保存路径
            session: 渲染会话
            data: 原始数据 DataFrame
            Z: 插值结果网格
            grid_lon: 经度网格
            grid_lat: 纬度网格

        Returns:
            生成的文件路径，失败返回 None
        """
        return self._render_with_template(
            lambda: self.renderer.render_interpolation(
                data=data,
                indicator=indicator,
                Z=Z,
                grid_lon=grid_lon,
                grid_lat=grid_lat,
                save_path=save_path,
                session=session,
            ),
            map_type="interpolation",
            indicator=indicator,
            debug_context={
                "Z_type": str(type(Z)),
                "Z_shape": Z.shape if hasattr(Z, "shape") else "N/A",
                "grid_lon_type": str(type(grid_lon)),
                "grid_lat_type": str(type(grid_lat)),
                "save_path": save_path,
            },
        )

    def render_clean_interpolation_svg(
        self,
        indicator: str,
        save_path: str,
        session: RenderingSession,
        Z: np.ndarray,
        grid_lon: np.ndarray,
        grid_lat: np.ndarray,
    ) -> Optional[str]:
        """渲染清洁热力图（SVG 格式）

        Args:
            indicator: 指标名称
            save_path: 保存路径
            session: 渲染会话
            Z: 插值结果网格
            grid_lon: 经度网格
            grid_lat: 纬度网格

        Returns:
            生成的文件路径，失败返回 None
        """
        return self._render_with_template(
            lambda: self.renderer.render_clean_interpolation_svg(
                indicator=indicator,
                Z=Z,
                grid_lon=grid_lon,
                grid_lat=grid_lat,
                save_path=save_path,
                session=session,
            ),
            map_type="clean_interpolation_svg",
            indicator=indicator,
        )

    def render_level(
        self,
        indicator: str,
        save_path: str,
        session: RenderingSession,
        Z: np.ndarray,
        grid_lon: np.ndarray,
        grid_lat: np.ndarray,
    ) -> Optional[str]:
        """渲染分级地图

        Args:
            indicator: 指标名称
            save_path: 保存路径
            session: 渲染会话
            Z: 插值结果网格
            grid_lon: 经度网格
            grid_lat: 纬度网格

        Returns:
            生成的文件路径，失败返回 None
        """
        return self._render_with_template(
            lambda: self.renderer.render_level(
                indicator=indicator,
                Z=Z,
                grid_lon=grid_lon,
                grid_lat=grid_lat,
                save_path=save_path,
                session=session,
            ),
            map_type="level",
            indicator=indicator,
        )

    def render_ndvi_binary(
        self,
        indicator: str,
        save_path: str,
        session: RenderingSession,
        Z: np.ndarray,
        grid_lon: np.ndarray,
        grid_lat: np.ndarray,
    ) -> Optional[str]:
        """渲染 NDVI 二值图

        Args:
            indicator: 指标名称
            save_path: 保存路径
            session: 渲染会话
            Z: 插值结果网格
            grid_lon: 经度网格
            grid_lat: 纬度网格

        Returns:
            生成的文件路径，失败返回 None
        """
        return self._render_with_template(
            lambda: self.renderer.render_ndvi_binary(
                indicator=indicator,
                Z=Z,
                grid_lon=grid_lon,
                grid_lat=grid_lat,
                save_path=save_path,
                session=session,
            ),
            map_type="ndvi_binary",
            indicator=indicator,
        )

    def render_ndvi_bloom_level(
        self,
        indicator: str,
        save_path: str,
        session: RenderingSession,
        Z: np.ndarray,
        grid_lon: np.ndarray,
        grid_lat: np.ndarray,
    ) -> Optional[str]:
        """渲染 NDVI 开花分级图

        Args:
            indicator: 指标名称
            save_path: 保存路径
            session: 渲染会话
            Z: 插值结果网格
            grid_lon: 经度网格
            grid_lat: 纬度网格

        Returns:
            生成的文件路径，失败返回 None
        """
        return self._render_with_template(
            lambda: self.renderer.render_ndvi_bloom_level(
                indicator=indicator,
                Z=Z,
                grid_lon=grid_lon,
                grid_lat=grid_lat,
                save_path=save_path,
                session=session,
            ),
            map_type="ndvi_bloom_level",
            indicator=indicator,
        )

    def _render_with_template(
        self,
        render_func: Callable[[], Optional[str]],
        map_type: str,
        indicator: str,
        debug_context: Optional[Dict[str, Any]] = None,
    ) -> Optional[str]:
        """通用渲染模板方法

        这是所有渲染方法的公共模板，处理：
        1. 执行渲染函数
        2. 验证返回值
        3. 记录日志
        4. 捕获异常
        5. 返回结果

        Args:
            render_func: 执行实际渲染的函数
            map_type: 地图类型
            indicator: 指标名称
            debug_context: 调试上下文（可选的额外信息）

        Returns:
            生成的文件路径，失败返回 None
        """
        try:
            logger.debug(f"开始渲染 {indicator} 的 {map_type} 地图")

            result = render_func()

            if result:
                logger.info(f"{indicator} {map_type} 生成成功")
                return result
            else:
                logger.warning(f"✗ {indicator} {map_type} 生成失败：渲染器返回空结果")
                return None

        except Exception as e:
            logger.error(
                f"生成 {indicator} {map_type} 失败: {str(e)}",
                exc_info=True,
            )

            # 如果提供了调试上下文，记录额外的信息
            if debug_context:
                for key, value in debug_context.items():
                    logger.error(f"[DEBUG_CONTEXT] {key}: {value}")

            return None

    def batch_render(
        self,
        render_tasks: list[Dict[str, Any]],
    ) -> Dict[str, RenderingResult]:
        """批量渲染多个地图

        Args:
            render_tasks: 渲染任务列表，每个任务是一个字典，包含：
                - map_type: 地图类型
                - indicator: 指标名称
                - render_func: 渲染函数
                - debug_context: 可选的调试上下文

        Returns:
            结果字典，键为 "{indicator}_{map_type}"，值为 RenderingResult
        """
        results = {}

        for task in render_tasks:
            map_type = task["map_type"]
            indicator = task["indicator"]
            render_func = task["render_func"]
            debug_context = task.get("debug_context")

            file_path = self._render_with_template(
                render_func,
                map_type=map_type,
                indicator=indicator,
                debug_context=debug_context,
            )

            result_key = f"{indicator}_{map_type}"
            if file_path:
                results[result_key] = RenderingResult(
                    success=True,
                    file_path=file_path,
                    map_type=map_type,
                    indicator=indicator,
                )
            else:
                results[result_key] = RenderingResult(
                    success=False,
                    error_message=f"渲染 {indicator} {map_type} 失败",
                    map_type=map_type,
                    indicator=indicator,
                )

        return results
