"""
数据模型和容器类

提供数据结构定义和类型化容器。
"""

from dataclasses import dataclass
from typing import Optional


@dataclass
class DataFilesInfo:
    """数据文件信息容器

    用于存储从解压目录中发现的数据文件路径。
    确保类型安全，避免混淆文件路径和列表。

    Attributes:
        extract_dir: 解压目录的路径
        indices_file: INDEXS.CSV 文件的完整路径 (可能为None)
        pos_file: POS.TXT 文件的完整路径 (可能为None)
        ref_files: 光谱数据文件路径列表 (REFL_*.csv 文件)

    Examples:
        >>> info = DataFilesInfo(
        ...     extract_dir="/path/to/extracted",
        ...     indices_file="/path/to/INDEXS.CSV",
        ...     pos_file="/path/to/POS.TXT",
        ...     ref_files=["/path/to/REFL_0.csv", "/path/to/REFL_1.csv"]
        ... )
        >>> info.is_valid()
        True
        >>> info.indices_file
        '/path/to/INDEXS.CSV'
    """

    extract_dir: str
    """解压目录的路径"""

    indices_file: Optional[str]
    """INDEXS.CSV 文件路径，未找到时为 None"""

    pos_file: Optional[str]
    """POS.TXT 文件路径，未找到时为 None"""

    ref_files: list[str]
    """光谱数据文件路径列表"""

    def is_valid(self) -> bool:
        """验证必需的数据文件是否存在

        Returns:
            bool: 当 indices_file 和 pos_file 都不为 None 时返回 True，
                  否则返回 False

        Examples:
            >>> info = DataFilesInfo(
            ...     extract_dir="/path",
            ...     indices_file="/path/INDEXS.CSV",
            ...     pos_file="/path/POS.TXT",
            ...     ref_files=[]
            ... )
            >>> info.is_valid()
            True

            >>> info = DataFilesInfo(
            ...     extract_dir="/path",
            ...     indices_file=None,
            ...     pos_file="/path/POS.TXT",
            ...     ref_files=[]
            ... )
            >>> info.is_valid()
            False
        """
        return bool(self.indices_file and self.pos_file)

    def __repr__(self) -> str:
        """返回数据文件信息的字符串表示"""
        return (
            f"DataFilesInfo("
            f"extract_dir={self.extract_dir!r}, "
            f"indices_file={self.indices_file!r}, "
            f"pos_file={self.pos_file!r}, "
            f"ref_files={len(self.ref_files)} files)"
        )
