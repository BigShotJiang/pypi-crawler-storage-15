#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""AeroSpot自动化报告生成工具的核心模块

该模块包含所有基础设施和核心功能组件：

**异常定义:**
  from autoreport.core import AeroSpotError, ConfigValidationError, ...

**基础设施工具:**
  from autoreport.core import ConfigValidator, ErrorHandler, safe_operation, configure_logging

**资源管理:**
  from autoreport.core import ResourceManager

**文件处理:**
  from autoreport.core import ZipExtractor

**报告生成:**
  from autoreport.core import ReportGenerator

**指标映射（配置相关）:**
  from autoreport.core import get_default_indicator_aliases, get_indicator_name_mapping

历史迁移记录：
  - Phase 2.3: ResourceManager 迁移至 core/
  - Phase 2.4: ZipExtractor 迁移至 core/
  - Phase 3: 异常类、配置验证、错误处理、日志配置集中至 core/
  - Phase 7: 指标映射函数统一至 config_models
"""

# 异常类（Phase 3 迁移至 core）
from .exceptions import (
    AeroSpotError,
    ResourceError,
    DownloadError,
    ResourceNotFoundError,
    DataProcessingError,
    DataFileNotFoundError,
    DataExtractionError,
    DataParsingError,
    ConfigError,
    ConfigValidationError,
    ReportGenerationError,
    DocumentGenerationError,
    WatermarkError,
    StyleApplicationError,
    ImageInsertionError,
    TemporaryFileError,
    ConfigGenerationError,
    InvalidConfigError,
)

# 基础设施工具（Phase 3 迁移至 core）
from .config_validator import ConfigValidator, load_and_validate_config
from .error_handler import ErrorHandler, safe_operation
from .log_config import configure_logging

# 核心组件（已在 core 中）
from .generator import ReportGenerator
from .resource_manager import ResourceManager
from .extractor import ZipExtractor

# 指标映射工具（Phase 7：统一管理指标别名和映射）
from .config_models import (
    _get_default_indicator_aliases as get_default_indicator_aliases,
    _get_indicator_name_mapping as get_indicator_name_mapping,
)

__all__ = [
    # 异常类
    "AeroSpotError",
    "ResourceError",
    "DownloadError",
    "ResourceNotFoundError",
    "DataProcessingError",
    "DataFileNotFoundError",
    "DataExtractionError",
    "DataParsingError",
    "ConfigError",
    "ConfigValidationError",
    "ReportGenerationError",
    "DocumentGenerationError",
    "WatermarkError",
    "StyleApplicationError",
    "ImageInsertionError",
    "TemporaryFileError",
    "ConfigGenerationError",
    "InvalidConfigError",
    # 基础设施工具
    "ConfigValidator",
    "load_and_validate_config",
    "ErrorHandler",
    "safe_operation",
    "configure_logging",
    # 核心组件
    "ReportGenerator",
    "ResourceManager",
    "ZipExtractor",
    # 指标映射工具
    "get_default_indicator_aliases",
    "get_indicator_name_mapping",
]

