"""日志工具模块 - 提供统一的日志记录接口

改进日志的一致性、减少冗余、提高可读性。

Author: 日志优化小组
"""

import logging
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any, Dict, Optional


logger = logging.getLogger(__name__)


@dataclass
class IndicatorProcessStats:
    """指标处理统计数据"""
    name: str
    start_time: float = field(default_factory=time.time)
    end_time: Optional[float] = None
    maps_generated: int = 0
    success: bool = False
    error: Optional[str] = None
    colorbar_range: Optional[tuple] = None

    @property
    def elapsed(self) -> float:
        """计算耗时"""
        end = self.end_time or time.time()
        return end - self.start_time

    @property
    def success(self) -> bool:
        """是否成功"""
        return self.error is None

    @property
    def status_emoji(self) -> str:
        """状态表情符号"""
        return "✓" if self.success else "✗"


class StageLogger:
    """统一的阶段日志记录器"""

    def __init__(self, name: str, logger_obj: Optional[logging.Logger] = None):
        """初始化阶段日志记录器

        Args:
            name: 阶段名称
            logger_obj: 日志对象（如果为None，使用全局logger）
        """
        self.name = name
        self.logger = logger_obj or logger
        self.start_time = None
        self.context = {}

    def start(self, context: Optional[Dict[str, Any]] = None) -> None:
        """记录阶段开始

        Args:
            context: 上下文信息（如数据量、输入参数等）
        """
        self.start_time = time.time()
        self.context = context or {}

        context_str = self._format_context(self.context)
        if context_str:
            self.logger.info(f"[{self.name:20}] 开始 | {context_str}")
        else:
            self.logger.info(f"[{self.name:20}] 开始")

    def complete(self, output_context: Optional[Dict[str, Any]] = None) -> float:
        """记录阶段完成

        Args:
            output_context: 输出信息

        Returns:
            float: 阶段耗时
        """
        elapsed = time.time() - self.start_time if self.start_time else 0

        output_str = self._format_context(output_context or {})
        if output_str:
            self.logger.info(
                f"[{self.name:20}] ✓ 完成 | 耗时={elapsed:.2f}s | {output_str}"
            )
        else:
            self.logger.info(f"[{self.name:20}] ✓ 完成 | 耗时={elapsed:.2f}s")

        return elapsed

    def error(self, error_msg: str) -> None:
        """记录阶段错误

        Args:
            error_msg: 错误信息
        """
        elapsed = time.time() - self.start_time if self.start_time else 0
        self.logger.error(
            f"[{self.name:20}] ✗ 失败 | 耗时={elapsed:.2f}s | 错误: {error_msg}"
        )

    def warning(self, warning_msg: str) -> None:
        """记录警告

        Args:
            warning_msg: 警告信息
        """
        self.logger.warning(f"[{self.name:20}] ⚠️  {warning_msg}")

    def debug(self, debug_msg: str) -> None:
        """记录调试信息

        Args:
            debug_msg: 调试信息
        """
        self.logger.debug(f"[{self.name:20}] {debug_msg}")

    def info(self, info_msg: str) -> None:
        """记录信息

        Args:
            info_msg: 信息内容
        """
        self.logger.info(f"[{self.name:20}] {info_msg}")

    @staticmethod
    def _format_context(context: Dict[str, Any]) -> str:
        """格式化上下文信息

        Args:
            context: 上下文字典

        Returns:
            str: 格式化的字符串
        """
        if not context:
            return ""

        parts = []
        for key, value in context.items():
            if isinstance(value, (int, float)):
                if isinstance(value, int):
                    parts.append(f"{key}={value:,}")
                else:
                    parts.append(f"{key}={value:.2f}")
            else:
                parts.append(f"{key}={value}")

        return " | ".join(parts)


@contextmanager
def log_stage(
    stage_name: str,
    input_context: Optional[Dict[str, Any]] = None,
    logger_obj: Optional[logging.Logger] = None,
):
    """上下文管理器：记录阶段执行

    Args:
        stage_name: 阶段名称
        input_context: 输入信息
        logger_obj: 日志对象

    Yields:
        StageLogger: 阶段日志记录器实例

    Example:
        >>> with log_stage("数据处理", {"rows": 1000}) as stage:
        ...     process_data()
        ...     stage.complete({"output_rows": 950})
    """
    stage = StageLogger(stage_name, logger_obj)
    stage.start(input_context)

    try:
        yield stage
    except Exception as e:
        stage.error(str(e))
        raise


def log_batch_operation(
    operation_name: str,
    total_items: int,
    completed_items: int,
    failed_items: int = 0,
    logger_obj: Optional[logging.Logger] = None,
    elapsed_time: Optional[float] = None,
) -> None:
    """记录批量操作的结果

    Args:
        operation_name: 操作名称
        total_items: 总项数
        completed_items: 完成项数
        failed_items: 失败项数
        logger_obj: 日志对象
        elapsed_time: 耗时（秒）
    """
    if logger_obj is None:
        logger_obj = logger

    success_rate = (completed_items / total_items * 100) if total_items > 0 else 0
    msg = f"[{operation_name:20}] 批量操作完成: {completed_items}/{total_items} 成功 ({success_rate:.1f}%)"

    if failed_items > 0:
        msg += f", {failed_items} 失败"

    if elapsed_time is not None:
        speed = total_items / elapsed_time if elapsed_time > 0 else 0
        msg += f" | 耗时: {elapsed_time:.2f}s, 速度: {speed:.1f} 项/s"

    level = logging.WARNING if success_rate < 80 else logging.INFO
    logger_obj.log(level, msg)
