#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""AeroSpot自动化报告生成工具的异常类定义"""

from typing import Optional


class AeroSpotError(Exception):
    """所有自定义异常的基类"""

    def __init__(self, message: str, error_code: Optional[int] = None) -> None:
        self.message: str = message
        self.error_code: Optional[int] = error_code
        super().__init__(self.message)


# 资源类异常
class ResourceError(AeroSpotError):
    """资源相关错误的基类"""

    pass


class DownloadError(ResourceError):
    """下载资源时的错误"""

    pass


class ResourceNotFoundError(ResourceError):
    """资源未找到错误"""

    pass


# 数据处理类异常
class DataProcessingError(AeroSpotError):
    """数据处理相关错误的基类"""

    pass


class DataFileNotFoundError(DataProcessingError):
    """数据文件未找到异常

    当必需的数据文件（INDEXS.CSV、POS.TXT）缺失时抛出此异常。
    不同于一般的数据处理异常，此异常表示无法继续处理。

    Examples:
        >>> raise DataFileNotFoundError("INDEXS.CSV file not found in extracted directory")
    """

    pass


class DataExtractionError(DataProcessingError):
    """数据解压缩错误"""

    pass


class DataParsingError(DataProcessingError):
    """数据解析错误"""

    pass


# 配置类异常
class ConfigError(AeroSpotError):
    """配置相关错误的基类"""

    pass


class ConfigValidationError(ConfigError):
    """配置验证错误"""

    pass


# 报告生成类异常
class ReportGenerationError(AeroSpotError):
    """报告生成相关错误的基类"""

    pass


class ConfigGenerationError(ReportGenerationError):
    """配置生成错误

    当报告结构配置生成失败时抛出此异常，包括：
    - 文件写入失败
    - JSON 序列化失败
    - 数据结构不完整

    Examples:
        >>> raise ConfigGenerationError("无法保存报告结构到指定路径")
    """

    pass


class InvalidConfigError(ConfigError):
    """无效配置错误

    当输入的配置数据不符合要求时抛出此异常，包括：
    - 缺少必需字段
    - 数据类型不正确
    - 路径无效

    Examples:
        >>> raise InvalidConfigError("updated_data 缺少必需键: company_info")
    """

    pass


# 文档生成相关异常
class DocumentGenerationError(ReportGenerationError):
    """文档生成异常基类

    用于处理 Word 文档生成过程中的各种错误。

    Examples:
        >>> raise DocumentGenerationError("无法初始化 Word 文档")
    """

    pass


class WatermarkError(DocumentGenerationError):
    """水印添加异常

    当使用 Spire.Doc 添加水印失败时抛出此异常，包括：
    - Spire.Doc 模块未安装或导入失败
    - 水印参数无效
    - 临时文件创建或处理失败

    Examples:
        >>> raise WatermarkError("未找到 watermark 模块，无法添加水印")
    """

    pass


class StyleApplicationError(DocumentGenerationError):
    """样式应用异常

    当文档样式设置失败时抛出此异常，包括：
    - 字体设置失败
    - 页面大小设置失败
    - 样式创建失败

    Examples:
        >>> raise StyleApplicationError("无法设置页面大小为 A4")
    """

    pass


class ImageInsertionError(DocumentGenerationError):
    """图片插入异常

    当向文档插入图片失败时抛出此异常，包括：
    - 图片文件不存在或无法读取
    - 图片格式不支持
    - 图片大小设置失败

    Examples:
        >>> raise ImageInsertionError(f"未找到图片文件: {image_path}")
    """

    pass


class TemporaryFileError(DocumentGenerationError):
    """临时文件处理异常

    当临时文件的创建、使用或清理失败时抛出此异常。

    Examples:
        >>> raise TemporaryFileError("无法创建临时 DOCX 文件")
    """

    pass
