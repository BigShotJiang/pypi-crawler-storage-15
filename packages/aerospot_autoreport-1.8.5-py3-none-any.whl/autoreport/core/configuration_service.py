"""
配置服务 - 提供统一的配置访问接口

该模块提供 ConfigurationService 类，用于统一管理和访问应用程序配置。
所有模块都应该通过这个服务来获取配置，而不是直接访问配置字典。
"""

import logging
from typing import Optional, Dict, Any, Union, List

from .config_models import (
    AppConfig,
    WatermarkConfig,
    CompanyInfo,
    KrigingConfig,
    WaterQualityGradesConfig,
    MapRenderingConfig,
    IndicatorUnitsConfig,
    CacheConfig,
)

logger = logging.getLogger(__name__)


class ConfigurationService:
    """配置服务类

    提供统一的配置访问接口，管理应用程序的所有配置。
    """

    def __init__(self, config: AppConfig) -> None:
        """初始化配置服务

        Args:
            config: AppConfig 对象
        """
        self._config = config
        self._validated = False

    @classmethod
    def load_from_file(cls, file_path: str) -> "ConfigurationService":
        """从 JSON 文件加载配置

        Args:
            file_path: JSON 配置文件路径

        Returns:
            ConfigurationService: 初始化的服务实例

        Raises:
            FileNotFoundError: 文件不存在
            json.JSONDecodeError: JSON 解析失败
            ValidationError: 配置验证失败
        """
        config = AppConfig.load_from_file(file_path)
        logger.info(f"从文件加载配置: {file_path}")
        return cls(config)

    @classmethod
    def load_from_dict(cls, config_dict: Dict[str, Any]) -> "ConfigurationService":
        """从字典加载配置

        Args:
            config_dict: 配置字典

        Returns:
            ConfigurationService: 初始化的服务实例

        Raises:
            ValidationError: 配置验证失败
        """
        config = AppConfig(**config_dict)
        logger.info("从字典加载配置")
        return cls(config)

    def validate(self) -> None:
        """验证配置的有效性

        这是在加载配置后的第一步，确保所有配置字段都是有效的。
        Pydantic 已经在 __init__ 时进行了验证，这个方法是对外的接口。

        Raises:
            ValidationError: 配置验证失败
        """
        # Pydantic 已经在模型初始化时进行了验证
        self._validated = True
        logger.info("配置验证成功")

    def get_watermark_config(self) -> WatermarkConfig:
        """获取水印配置

        Returns:
            WatermarkConfig: 水印配置对象
        """
        return self._config.company_info.watermark_config

    def get_company_info(self) -> CompanyInfo:
        """获取公司信息

        Returns:
            CompanyInfo: 公司信息对象
        """
        return self._config.company_info

    def get_resource_urls(self) -> Dict[str, Union[Optional[str], Optional[List[str]]]]:
        """获取所有资源 URL

        Returns:
            Dict: 资源 URL 字典，其中 historical_data 值为 Optional[List[str]]，
                  其他字段为 Optional[str]
        """
        company = self._config.company_info
        return {
            "logo_path": company.logo_path,
            "satellite_img": company.satellite_img,
            "wayline_img": company.wayline_img,
            "file_url": company.file_url,
            "measure_data": company.measure_data,
            "kml_boundary_url": company.kml_boundary_url,
            "bin_url": company.bin_url,
            "historical_data": company.historical_data,
        }

    def get_geo_bounds(self) -> Dict[str, Optional[str]]:
        """获取地理边界坐标

        Returns:
            Dict[str, Optional[str]]: 地理边界字典
        """
        company = self._config.company_info
        return {
            "north_east": company.north_east,
            "south_west": company.south_west,
            "south_east": company.south_east,
            "north_west": company.north_west,
        }

    def get_pollution_sources(self) -> Dict[str, str]:
        """获取污染源信息

        Returns:
            Dict[str, str]: 污染源字典
        """
        return self._config.pollution_source

    def get_visualization_mode(self) -> str:
        """获取可视化模式

        Returns:
            str: 可视化模式 ('quantitative' 或 'qualitative')
        """
        return self._config.visualization_mode

    def get_data_root(self) -> str:
        """获取数据根目录

        Returns:
            str: 数据根目录路径
        """
        return self._config.data_root

    def get_config(self) -> AppConfig:
        """获取完整的 AppConfig 对象

        Returns:
            AppConfig: 应用配置对象
        """
        return self._config

    def to_dict(self) -> Dict[str, Any]:
        """将配置转换为字典 (用于向后兼容)

        Returns:
            Dict[str, Any]: 配置字典
        """
        return self._config.to_dict()

    def save_to_file(self, file_path: str) -> None:
        """将配置保存到文件

        Args:
            file_path: 输出文件路径
        """
        self._config.save_to_file(file_path)
        logger.info(f"配置已保存到: {file_path}")

    # =========================================================================
    # Phase 2A 新增方法
    # =========================================================================

    def get_kriging_config(self) -> KrigingConfig:
        """获取 Kriging 插值配置

        返回 Kriging 插值的配置，包括方法、方差模型、最近邻点数等。

        Returns:
            KrigingConfig: Kriging 插值配置对象

        Examples:
            >>> service = ConfigurationService.load_from_file("config.json")
            >>> kriging = service.get_kriging_config()
            >>> print(f"Method: {kriging.method}, Variogram: {kriging.variogram_model}")
            Method: ordinary_kriging_spherical, Variogram: spherical
        """
        return self._config.kriging

    def get_water_quality_grades_config(self) -> WaterQualityGradesConfig:
        """获取水质等级配置

        返回按 GB 3838-2002 标准定义的水质等级配置，包括各指标的阈值、标签、颜色等。

        Returns:
            WaterQualityGradesConfig: 水质等级配置对象

        Examples:
            >>> service = ConfigurationService.load_from_file("config.json")
            >>> grades = service.get_water_quality_grades_config()
            >>> label, color = grades.get_grade_for_value("COD", 25)
            >>> print(f"COD=25: {label}, Color: {color}")
            COD=25: Ⅲ类, Color: #FFFF00
        """
        return self._config.water_quality_grades

    def get_map_rendering_config(self) -> MapRenderingConfig:
        """获取地图渲染配置

        返回地图生成时的渲染配置，包括 DPI、图像尺寸、透明度、字体等。

        Returns:
            MapRenderingConfig: 地图渲染配置对象

        Examples:
            >>> service = ConfigurationService.load_from_file("config.json")
            >>> rendering = service.get_map_rendering_config()
            >>> width_px, height_px = rendering.get_image_size_pixels()
            >>> print(f"Image size: {width_px} x {height_px} pixels")
            Image size: 2196 x 1647 pixels
        """
        return self._config.map_rendering

    def get_indicator_units_config(self) -> IndicatorUnitsConfig:
        """获取指标单位配置

        返回所有水质指标的单位映射和别名配置，支持通过别名查询。

        Returns:
            IndicatorUnitsConfig: 指标单位配置对象

        Examples:
            >>> service = ConfigurationService.load_from_file("config.json")
            >>> units = service.get_indicator_units_config()
            >>> unit = units.get_unit("NH3-N")
            >>> print(f"NH3-N unit: {unit}")
            NH3-N unit: mg/L
            >>> unit_by_alias = units.get_unit("氨氮")  # 通过中文别名查询
            >>> print(f"氨氮 unit: {unit_by_alias}")
            氨氮 unit: mg/L
        """
        return self._config.indicator_units

    def get_cache_config(self) -> CacheConfig:
        """获取缓存配置

        返回资源缓存的配置，包括 TTL、最大大小、清理间隔等。

        Returns:
            CacheConfig: 缓存配置对象

        Examples:
            >>> service = ConfigurationService.load_from_file("config.json")
            >>> cache = service.get_cache_config()
            >>> ttl_days = cache.get_ttl_days()
            >>> print(f"Cache TTL: {ttl_days} days")
            Cache TTL: 3 days
        """
        return self._config.cache
