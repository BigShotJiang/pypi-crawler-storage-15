#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""报告数据构建器

从 ConfigurationService 构建 ReportData 数据结构。
"""

import logging
import time
from typing import Any, Dict

from .configuration_service import ConfigurationService
from ..models.report_data import ReportData, ImageResources

logger = logging.getLogger(__name__)


class ReportDataBuilder:
    """报告数据构建器

    职责：
    1. 从 ConfigurationService 构建 ReportData 数据结构
    2. 初始化输出目录
    3. 设置默认值和格式化信息

    返回格式：始终返回 ReportData 模型（Phase 5完全迁移）
    """

    def __init__(self, config_service: ConfigurationService, output_dir: str) -> None:
        """初始化报告数据构建器

        Args:
            config_service: 配置服务实例
            output_dir: 输出目录路径
        """
        self.config_service = config_service
        self.output_dir = output_dir

    def build(self) -> ReportData:
        """构建报告数据结构

        从 ConfigurationService 中提取信息，构建 ReportData 模型。

        Returns:
            ReportData: 报告数据模型实例

        Raises:
            ValueError: 当构建失败时
        """
        try:
            # 从配置服务获取各类配置信息
            company = self.config_service.get_company_info()
            watermark = self.config_service.get_watermark_config()
            geo_bounds = self.config_service.get_geo_bounds()
            sources = self.config_service.get_pollution_sources()

            # 构建内部配置字典（用于ReportData）
            config_dict = {
                "data_root": self.output_dir,
                "visualization_mode": self.config_service.get_visualization_mode(),
                "execution_mode": self.config_service.get_config().execution_mode,
                # 公司基本信息
                "company_info": {
                    "name": company.name,
                    "address": company.address,
                    "email": company.email,
                    "phone": company.phone,
                    "profile": company.profile,
                    "date": time.strftime("%Y年%m月%d日", time.localtime()),
                    "watermark_enabled": watermark.enabled,
                    "watermark_text": watermark.text,
                    "watermark_size": watermark.size,
                    "watermark_color": watermark.color,
                    "watermark_diagonal": watermark.diagonal,
                    "watermark_use_spire": watermark.use_spire,
                },
                # 地理坐标信息
                "geo_info": {
                    "north_east": geo_bounds.get("north_east", ""),
                    "south_west": geo_bounds.get("south_west", ""),
                    "south_east": geo_bounds.get("south_east", ""),
                    "north_west": geo_bounds.get("north_west", ""),
                },
                # 污染源信息
                "pollution_source": sources,
            }

            # 构建并返回 ReportData 模型
            report_data_model = ReportData(
                config=config_dict,
                output_dir=self.output_dir,
                image_resources=ImageResources(
                    logo=company.logo_path or None,
                    wayline=company.wayline_img or None,
                    satellite=company.satellite_img or None,
                ),
                processing_state="pending"
            )

            logger.info("报告数据结构创建成功（ReportData模型）")
            return report_data_model

        except Exception as e:
            logger.error(f"创建报告数据结构失败: {str(e)}", exc_info=True)
            raise ValueError(f"Failed to build report data: {str(e)}")

