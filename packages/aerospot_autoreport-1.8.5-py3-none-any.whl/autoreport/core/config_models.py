"""
配置数据模型定义 - 使用 Pydantic v2

该模块定义了应用程序所有配置相关的强类型数据模型，
包括水印配置、公司信息和顶层应用配置。

所有默认值都从 src/autoreport/config/company_info.py 中迁移而来。
"""

import os
import json
from typing import Optional, Dict, Any, List
from pydantic import (
    BaseModel,
    Field,
    field_validator,
    model_validator,
)

# 从统一的config模块导入水质分级配置
from ..config.grades_config_models import INDICATOR_GRADE_CONFIG


# ============================================================================
# 默认值常量 - 从旧的 company_info.py 迁移
# ============================================================================

# 默认图片资源目录路径
_DEFAULT_IMAGES_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "resources",
    "images",
)

# 默认公司简介 (长文本)
_DEFAULT_COMPANY_PROFILE = (
    "无锡谱视界科技有限公司于2021年成立于无锡，由江苏双利合谱科技有限公司、"
    "长春长光辰谱科技有限公司和核心团队共同出资组建。公司目前员工40余人，"
    "研发团队占比2/3，核心团队来自中国科学院长春光学精密机械与物理研究所、"
    "北京卓立汉光仪器有限公司（上市公司）等国内顶尖的研究机构和相关龙头企业。\n"
    "无锡谱视界科技有限公司拥有基于像元级镀膜分光技术开发的快照式光谱遥感成像和"
    "AI大模型光谱数据解析两大核心技术。其中像元级镀膜技术是由中国科学院长春光学"
    "精密机械与物理研究所成果转化而来，曾应用于珠海一号、吉林一号等多型号遥感卫星。"
    "在水环境监测领域，无锡谱视界科技有限公司基于像元级镀膜核心技术开发了可用于"
    "水生态环境监测的机载快照式光谱成像指数分析仪、智能小型机载光谱指数分析基站、"
    "岸基高光谱水质监测仪、全天候光谱水质监测仪、高光谱塔基水质监测仪和手持式高光谱"
    "智水仪等多个产品，是国内唯一一家将像元级镀膜技术产品化并成功应用于水生态环境"
    "监测的企业。公司目前授权专利11项（其中发明专利8项，实用新型3项），"
    "软件著作权15个，与多家研究单位进行产学研合作，获2022年中国产学研合作创新与"
    "促进奖（产学研合作创新奖）。"
)

# 默认资源路径
_DEFAULT_LOGO_PATH = os.path.join(_DEFAULT_IMAGES_DIR, "logo.png")
_DEFAULT_WATERMARK_PATH = os.path.join(_DEFAULT_IMAGES_DIR, "waterpicture.png")


# ============================================================================
# Phase 2A 默认值工厂函数 (在模型定义之前)
# ============================================================================


def _get_default_water_quality_grades() -> Dict[str, Dict[str, Any]]:
    """获取默认的水质等级定义 (GB 3838-2002)

    返回与 grades.py 中 INDICATOR_GRADE_CONFIG 完全一致的结构。
    每个指标包含：
    - thresholds: 5个阈值（I-V类的分界线）
    - labels: 6个标签（I-V类 + 劣五类）
    - colors: 6个颜色（对应6个等级）
    - description: 指���描述
    - reverse (可选): 是否反向分级（如DO，越高越好）
    """
    return INDICATOR_GRADE_CONFIG


def _get_default_indicator_units() -> Dict[str, str]:
    """获取默认的指标单位映射

    单位来自 src/autoreport/processor/data/utils.py:23-40
    其中 default_units 包含系统实际使用的所有指标单位。
    """
    return {
        "Turb": "NTU",  # 浊度
        "SS": "mg/L",  # 悬浮物
        "Chla": "μg/L",  # 叶绿素
        "DO": "mg/L",  # 溶解氧
        "pH": "",  # pH值
        "Temp": "°C",  # 温度
        "EC": "μS/cm",  # 电导率
        "COD": "mg/L",  # 化学需氧量
        "CODMn": "mg/L",  # 高锰酸盐指数
        "BOD": "mg/L",  # 生化需氧量
        "NH3-N": "mg/L",  # 氨氮
        "TN": "mg/L",  # 总氮
        "TP": "mg/L",  # 总磷
        "BGA": "%",  # 蓝绿藻
        "Chroma": "Hazen",  # 色度
        "SD": "cm",  # 透明度
        "NDVI": "",  # 归一化植被指数
        "RVI": "",  # 红外植被指数
        "FCI": "%",  # 单像元蓝藻水华覆盖度
    }


def _get_default_indicator_aliases() -> Dict[str, list[str]]:
    """获取指标别名映射（唯一真值来源）

    格式：标准名 -> [别名列表]
    这是指标别名映射的唯一真值来源，避免在多处维护相同的数据。

    映射规则：标准指标名 -> 别名列表
    """
    return {
        # 浊度别名
        "Turb": ["turbidity", "浊度", "turb"],
        # 悬浮物别名
        "SS": ["ss", "悬浮物", "suspended solids"],
        # 溶解氧别名
        "DO": ["do", "溶解氧", "dissolved oxygen"],
        # 化学需氧量别名
        "COD": ["cod", "化学需氧量", "chemical oxygen demand"],
        # 高锰酸盐指数别名
        "CODMn": ["codmn", "高锰酸盐", "高锰酸盐指数"],
        # 生化需氧量别名
        "BOD": ["bod", "bod5", "生化需氧量", "biochemical oxygen demand"],
        # 氨氮别名
        "NH3-N": ["nh3-n", "nh3n", "氨氮", "nh3_n", "ammonia nitrogen"],
        # 总氮别名
        "TN": ["tn", "总氮", "total nitrogen"],
        # 总磷别名
        "TP": ["tp", "总磷", "total phosphorus"],
        # pH值别名
        "pH": ["ph", "ph值"],
        # 电导率别名
        "EC": ["ec", "电导率", "conductivity"],
        # 温度别名
        "Temp": ["temp", "温度", "temperature"],
        # 蓝绿藻别名
        "BGA": ["bga", "蓝绿藻"],
        # 叶绿素别名
        "Chla": ["chla", "叶绿素", "chlorophyll", "chl", "chl_a"],
        # 透明度别名
        "SD": ["sd", "透明度", "Sd"],
        # 色度别名
        "Chroma": ["Chroma", "色度", "chroma"],
        # NDVI别名
        "NDVI": ["ndvi", "归一化植被指数", "normalized difference vegetation index"],
        # FCI别名
        "FCI": ["FCI", "fci", "单像元蓝藻水华覆盖度"],
        # ABL别名
        "ABL": ["abl", "蓝藻生物量", "藻类生物量"],
    }


def _get_indicator_name_mapping() -> Dict[str, str]:
    """从分组格式动态生成平面化映射（用于数据处理）

    这个函数从 _get_default_indicator_aliases() 动态生成平面化的别名映射，
    确保 standardizer.py 中使用的映射与这里的定义始终一致。

    Returns:
        Dict[str, str]: 别名(小写) -> 标准指标名

    Examples:
        >>> mapping = _get_indicator_name_mapping()
        >>> mapping["浊度"]
        'Turb'
        >>> mapping["nh3-n"]
        'NH3-N'
    """
    alias_dict = _get_default_indicator_aliases()
    flat_mapping = {}

    for standard_name, aliases in alias_dict.items():
        for alias in aliases:
            # 使用小写作为键，便于不区分大小写的查找
            flat_mapping[alias.lower()] = standard_name

    return flat_mapping


class WatermarkConfig(BaseModel):
    """水印配置模型

    管理报告生成时的水印相关配置，包括启用状态、文本、大小、颜色等。
    """

    enabled: bool = Field(
        default=True,
        description="是否启用水印",
    )
    text: str = Field(
        default="无锡谱视界科技有限公司",
        description="水印文本内容",
        min_length=0,
        max_length=100,
    )
    size: int = Field(
        default=65,
        description="水印字体大小 (磅)",
        ge=10,
        le=200,
    )
    color: tuple[int, int, int] = Field(
        default=(200, 0, 0),
        description="水印颜色 (RGB 格式)",
    )
    diagonal: bool = Field(
        default=True,
        description="是否使用对角线布局",
    )
    use_spire: bool = Field(
        default=True,
        description="是否使用 Spire.Doc 添加水印",
    )

    @field_validator("color", mode="before")
    @classmethod
    def validate_color(cls, v: Any) -> tuple[int, int, int]:
        """验证颜色值"""
        if isinstance(v, (list, tuple)) and len(v) == 3:
            color = tuple(v)
            for i, c in enumerate(color):
                if not isinstance(c, int) or not (0 <= c <= 255):
                    raise ValueError(f"RGB 值必须是 0-255 的整数，当前: {c}")
            return color
        raise ValueError(f"颜色必须是三元组 (R, G, B)，当前: {v}")

    @model_validator(mode="after")
    def validate_watermark_consistency(self) -> "WatermarkConfig":
        """验证水印配置一致性"""
        if self.enabled and not self.text:
            raise ValueError("启用水印时，水印文本不能为空")
        return self


class CompanyInfo(BaseModel):
    """公司信息模型

    管理公司相关的所有配置，包括基本信息、资源路径、地理边界等。
    """

    name: str = Field(
        default="无锡谱视界科技有限公司",
        description="公司名称",
        min_length=1,
        max_length=200,
    )
    address: str = Field(
        default="江苏省无锡市新吴区菱湖大道200号E2-111",
        description="公司地址",
        min_length=1,
        max_length=500,
    )
    email: str = Field(
        default="company@specvision.com.cn",
        description="公司邮箱",
    )
    phone: str = Field(
        default="0510-85290662",
        description="公司电话",
        min_length=1,
        max_length=50,
    )
    profile: str = Field(
        default=_DEFAULT_COMPANY_PROFILE,
        description="公司简介",
    )
    logo_path: Optional[str] = Field(
        default=_DEFAULT_LOGO_PATH,
        description="公司 Logo 路径或 URL",
    )
    watermark_path: Optional[str] = Field(
        default=_DEFAULT_WATERMARK_PATH,
        description="水印图片路径或 URL",
    )
    satellite_img: Optional[str] = Field(
        default=None,
        description="卫星影像路径或 URL",
    )
    wayline_img: Optional[str] = Field(
        default=None,
        description="航线影像路径或 URL",
    )
    file_url: Optional[str] = Field(
        default=None,
        description="数据文件 (ZIP) 路径或 URL",
    )
    measure_data: Optional[str] = Field(
        default=None,
        description="测量数据 (CSV) 路径或 URL",
    )
    kml_boundary_url: Optional[str] = Field(
        default=None,
        description="KML 边界文件路径或 URL",
    )
    bin_url: Optional[str] = Field(
        default=None,
        description="模型文件路径或 URL",
    )
    historical_data: Optional[List[str]] = Field(
        default=None,
        description="历史数据文件路径列表（HDF5 格式），支持多文件加载",
    )
    north_east: Optional[str] = Field(
        default=None,
        description="东北角地理坐标 (lng,lat)",
    )
    south_west: Optional[str] = Field(
        default=None,
        description="西南角地理坐标 (lng,lat)",
    )
    south_east: Optional[str] = Field(
        default=None,
        description="东南角地理坐标 (lng,lat)",
    )
    north_west: Optional[str] = Field(
        default=None,
        description="西北角地理坐标 (lng,lat)",
    )
    watermark_config: WatermarkConfig = Field(
        default_factory=WatermarkConfig,
        description="水印配置",
    )

    @field_validator("email")
    @classmethod
    def validate_email(cls, v: str) -> str:
        """验证邮箱格式"""
        if "@" not in v or "." not in v:
            raise ValueError(f"无效的邮箱格式: {v}")
        return v


# ============================================================================
# Phase 2A: 新增配置模型 - 完成配置系统迁移
# ============================================================================


class KrigingConfig(BaseModel):
    """Kriging 插值配置模型

    管理 Kriging 插值算法的参数，用于水质数据的空间插值。

    当前全局默认使用 ordinary_kriging_spherical 方法，与 ArcGIS 标准一致。
    """

    method: str = Field(
        default="ordinary_kriging_spherical",
        description="Kriging 方法 (universal_kriging|ordinary_kriging_spherical|ordinary_kriging_exponential)",
        pattern="^(universal_kriging|ordinary_kriging_spherical|ordinary_kriging_exponential)$",
    )
    variogram_model: str = Field(
        default="spherical",
        description="方差模型 (gaussian|spherical|exponential) - spherical 是 ArcGIS 标准",
        pattern="^(gaussian|spherical|exponential)$",
    )
    drift_terms: str = Field(
        default="regional_linear",
        description="漂移项 (仅用于 universal_kriging)",
    )
    enabled: bool = Field(
        default=True,
        description="是否启用 Kriging 插值",
    )
    n_closest_points: int = Field(
        default=12,
        description="搜索最近邻点数（ArcGIS 标准）",
        ge=1,
        le=50,
    )
    search_radius_factor: float = Field(
        default=0.3,
        description="搜索半径相对于数据范围的比例 (0-1)",
        ge=0.0,
        le=1.0,
    )
    transform: str = Field(
        default="clip",
        description="负数处理方法 (none|log|clip)",
        pattern="^(none|log|clip)$",
    )
    enforce_positive: bool = Field(
        default=True,
        description="是否强制插值结果为正数",
    )

    @field_validator("variogram_model")
    @classmethod
    def validate_variogram(cls, v: str) -> str:
        """验证方差模型"""
        allowed = {"gaussian", "spherical", "exponential"}
        if v not in allowed:
            raise ValueError(f"方差模型必须是 {allowed} 之一，当前: {v}")
        return v


class WaterQualityGradesConfig(BaseModel):
    """水质等级配置模型

    管理按 GB 3838-2002 标准的水质等级定义及其对应的阈值和颜色。

    配置结构与 src/autoreport/processor/maps/visualization/grades.py 中
    的 INDICATOR_GRADE_CONFIG 完全一致，支持所有标准指标。
    """

    standard: str = Field(
        default="GB3838-2002",
        description="遵循的水质标准",
    )
    grades: Dict[str, Dict[str, Any]] = Field(
        default_factory=_get_default_water_quality_grades,
        description="等级定义字典 (指标名 -> {thresholds, labels, colors, description, reverse})",
    )

    def get_grade_for_value(
        self, indicator: str, value: float
    ) -> tuple[Optional[str], Optional[str]]:
        """根据指标值获取对应的等级和颜色

        使用与 grades.py 中 GradeManager.get_color_for_value() 相同的逻辑。

        Args:
            indicator: 指标名称（如 'COD', 'DO' 等）
            value: 指标数值

        Returns:
            (等级标签, 对应颜色) 元组，如 ('III类', '#FFFF00')
            如果指标不存在，返回 (None, None)

        Examples:
            >>> config = WaterQualityGradesConfig()
            >>> label, color = config.get_grade_for_value('COD', 25)
            >>> print(f"COD=25: {label}, {color}")
            COD=25: III类, #FFFF00
        """
        if indicator not in self.grades:
            return None, None

        config = self.grades[indicator]
        thresholds = config.get("thresholds", [])
        labels = config.get("labels", [])
        colors = config.get("colors", [])
        reverse = config.get("reverse", False)

        if not thresholds or not labels or not colors:
            return None, None

        # 根据阈值确定分级
        if reverse:
            # 反向分级（如 DO，越高越好）
            for i, threshold in enumerate(thresholds):
                if value >= threshold:
                    continue
                else:
                    return labels[i], colors[i]
            # 所有阈值都满足，返回最高分级
            return labels[-1], colors[-1]
        else:
            # 正常分级
            for i, threshold in enumerate(thresholds):
                if value <= threshold:
                    return labels[i], colors[i]
            # 所有阈值都超过，返回最低分级（劣五类）
            return labels[-1], colors[-1]


class MapRenderingConfig(BaseModel):
    """地图渲染配置模型

    管理生成地图时的渲染参数，包括图像质量、尺寸、颜色等。
    """

    dpi: int = Field(
        default=150,
        description="渲染分辨率 (DPI)",
        ge=72,
        le=300,
    )
    image_width_inches: float = Field(
        default=14.64,
        description="图像宽度 (英寸)",
        gt=0,
    )
    colorbar_format: str = Field(
        default="%.2f",
        description="颜色条数值格式 (printf 风格)",
    )
    transparency: float = Field(
        default=0.8,
        description="透明度 (0-1)",
        ge=0.0,
        le=1.0,
    )
    font_name: str = Field(
        default="SimSun",
        description="默认字体名",
    )
    font_size: int = Field(
        default=10,
        description="默认字体大小 (磅)",
        ge=8,
        le=24,
    )
    formats: list[str] = Field(
        default_factory=lambda: ["png", "svg"],
        description="输出格式列表",
    )

    def get_image_size_pixels(self) -> tuple[int, int]:
        """根据 DPI 和宽度计算像素尺寸

        Returns:
            (宽度, 高度) 像素元组，假设 4:3 比例
        """
        width_px = int(self.image_width_inches * self.dpi)
        height_px = int(width_px * 0.75)  # 4:3 比例
        return (width_px, height_px)


class IndicatorUnitsConfig(BaseModel):
    """指标单位配置模型

    管理各类水质指标的单位及别名映射，用于数据处理和展示。
    """

    units: Dict[str, str] = Field(
        default_factory=_get_default_indicator_units,
        description="指标名 -> 单位的映射",
    )
    aliases: Dict[str, list[str]] = Field(
        default_factory=_get_default_indicator_aliases,
        description="指标别名映射 (规范名 -> 别名列表)",
    )

    def get_unit(self, indicator: str) -> str:
        """获取指标的单位

        先直接查找，再通过别名查找。

        Args:
            indicator: 指标名称

        Returns:
            单位字符串，未找到则返回空字符串
        """
        # 直接查找
        if indicator in self.units:
            return self.units[indicator]

        # 通过别名查找
        for canonical_name, alias_list in self.aliases.items():
            if indicator in alias_list:
                return self.units.get(canonical_name, "")

        return ""

    def add_indicator(
        self, name: str, unit: str, aliases: list[str] | None = None
    ) -> None:
        """动态添加指标配置

        Args:
            name: 指标规范名
            unit: 指标单位
            aliases: 别名列表 (可选)
        """
        self.units[name] = unit
        if aliases:
            self.aliases[name] = aliases


class CacheConfig(BaseModel):
    """缓存配置模型

    管理资源和数据缓存的相关参数。
    """

    ttl_seconds: int = Field(
        default=3 * 24 * 3600,  # 3 天
        description="缓存 TTL (秒)",
        ge=3600,  # 最少 1 小时
        le=90 * 24 * 3600,  # 最多 90 天
    )
    max_size_mb: int = Field(
        default=500,
        description="最大缓存大小 (MB)",
        ge=10,
        le=5000,
    )
    cleanup_interval_hours: int = Field(
        default=24,
        description="清理间隔 (小时)",
        ge=1,
        le=168,
    )
    enabled: bool = Field(
        default=True,
        description="是否启用缓存",
    )

    def get_ttl_days(self) -> int:
        """获取 TTL 天数"""
        return self.ttl_seconds // (24 * 3600)


class AppConfig(BaseModel):
    """顶层应用配置模型

    包含整个应用程序的全局配置，包括公司信息、数据根目录、可视化模式
    以及 Phase 2A 新增的插值、地图渲染、指标单位等配置。
    """

    company_info: CompanyInfo = Field(
        default_factory=CompanyInfo,
        description="公司信息配置",
    )
    data_root: str = Field(
        default="./AutoReportResults/",
        description="输出数据根目录",
        min_length=1,
    )
    visualization_mode: str = Field(
        default="quantitative",
        description="可视化模式 (quantitative|qualitative)",
    )
    execution_mode: str = Field(
        default="full",
        description="执行模式 (full|heatmap_only)",
    )
    pollution_source: Dict[str, str] = Field(
        default_factory=dict,
        description="污染源信息字典",
    )

    # Phase 2A 新增字段
    kriging: KrigingConfig = Field(
        default_factory=KrigingConfig,
        description="Kriging 插值配置",
    )
    water_quality_grades: WaterQualityGradesConfig = Field(
        default_factory=WaterQualityGradesConfig,
        description="水质等级配置",
    )
    map_rendering: MapRenderingConfig = Field(
        default_factory=MapRenderingConfig,
        description="地图渲染配置",
    )
    indicator_units: IndicatorUnitsConfig = Field(
        default_factory=IndicatorUnitsConfig,
        description="指标单位配置",
    )
    cache: CacheConfig = Field(
        default_factory=CacheConfig,
        description="缓存配置",
    )

    @field_validator("visualization_mode")
    @classmethod
    def validate_visualization_mode(cls, v: str) -> str:
        """验证可视化模式"""
        valid_modes = ("quantitative", "qualitative")
        if v not in valid_modes:
            raise ValueError(f"可视化模式必须是 {valid_modes} 之一，当前: {v}")
        return v

    @classmethod
    def load_from_file(cls, file_path: str) -> "AppConfig":
        """从 JSON 文件加载配置

        Args:
            file_path: JSON 文件路径

        Returns:
            AppConfig: 加载的配置对象

        Raises:
            FileNotFoundError: 文件不存在
            json.JSONDecodeError: JSON 解析失败
            ValidationError: 配置验证失败
        """
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return cls(**data)

    def save_to_file(self, file_path: str) -> None:
        """将配置保存到 JSON 文件

        Args:
            file_path: 输出 JSON 文件路径
        """
        os.makedirs(os.path.dirname(file_path) or ".", exist_ok=True)
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(
                self.model_dump(exclude_none=True), f, ensure_ascii=False, indent=2
            )

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式 (用于向后兼容)

        Returns:
            Dict[str, Any]: 配置字典
        """
        return self.model_dump(exclude_none=False)


# ============================================================================
# 向后兼容函数
# ============================================================================


def get_default_company_info() -> CompanyInfo:
    """获取包含所有默认值的公司信息配置

    这个函数用于向后兼容旧的 company_info.py 的 DEFAULT_COMPANY_INFO。
    它返回一个完全初始化的 CompanyInfo 对象，包含所有默认值。

    Returns:
        CompanyInfo: 包含所有默认值的公司信息对象

    Example:
        >>> company = get_default_company_info()
        >>> print(company.name)
        '无锡谱视界科技有限公司'
        >>> print(company.logo_path)
        '/path/to/resources/images/logo.png'
    """
    return CompanyInfo()


def get_default_app_config() -> AppConfig:
    """获取包含所有默认值的应用配置

    这个函数创建一个完全初始化的 AppConfig 对象，包含所有默认值。

    Returns:
        AppConfig: 包含所有默认值的应用配置对象

    Example:
        >>> config = get_default_app_config()
        >>> print(config.company_info.name)
        '无锡谱视界科技有限公司'
    """
    return AppConfig()


def get_legacy_company_info_dict() -> Dict[str, Any]:
    """获取兼容旧 DEFAULT_COMPANY_INFO 格式的字典

    这个函数用于向后兼容旧的代码，返回的字典格式与旧的
    src/autoreport/config/company_info.py 中的 DEFAULT_COMPANY_INFO 相同。

    Returns:
        Dict[str, Any]: 兼容旧格式的公司信息字典

    Note:
        这个函数返回的字典还包含嵌套的 watermark 字段，
        以完全兼容旧的代码。

    Example:
        >>> old_dict = get_legacy_company_info_dict()
        >>> print(old_dict['name'])
        '无锡谱视界科技有限公司'
        >>> print(old_dict['watermark_text'])
        '无锡谱视界科技有限公司'
    """
    company = get_default_company_info()
    watermark = company.watermark_config

    # 构建兼容旧格式的字典
    return {
        "name": company.name,
        "address": company.address,
        "email": company.email,
        "phone": company.phone,
        "logo_path": company.logo_path,
        "watermark_path": company.watermark_path,
        "profile": company.profile,
        # Spire.Doc 水印配置 (展平到顶层)
        "watermark_enabled": watermark.enabled,
        "watermark_text": watermark.text,
        "watermark_size": watermark.size,
        "watermark_color": watermark.color,
        "watermark_diagonal": watermark.diagonal,
        "watermark_use_spire": watermark.use_spire,
    }


# ============================================================================
# Phase 2A 默认值工厂函数（公共 API）
# ============================================================================


def get_default_kriging_config() -> KrigingConfig:
    """获取包含所有默认值的 Kriging 配置

    Returns:
        KrigingConfig: 包含所有默认值的 Kriging 配置对象

    Example:
        >>> kriging = get_default_kriging_config()
        >>> print(kriging.method)
        'universal'
        >>> print(kriging.variogram_model)
        'gaussian'
    """
    return KrigingConfig()


def get_default_water_quality_grades_config() -> WaterQualityGradesConfig:
    """获取包含所有默认值的水质等级配置

    Returns:
        WaterQualityGradesConfig: 包含水质等级定义的配置对象

    Example:
        >>> grades = get_default_water_quality_grades_config()
        >>> print(grades.standard)
        'GB3838-2002'
    """
    return WaterQualityGradesConfig()


def get_default_map_rendering_config() -> MapRenderingConfig:
    """获取包含所有默认值的地图渲染配置

    Returns:
        MapRenderingConfig: 包含所有默认值的地图渲染配置对象

    Example:
        >>> rendering = get_default_map_rendering_config()
        >>> print(rendering.dpi)
        150
        >>> print(rendering.get_image_size_pixels())
        (2196, 1647)
    """
    return MapRenderingConfig()


def get_default_indicator_units_config() -> IndicatorUnitsConfig:
    """获取包含所有默认值的指标单位配置

    Returns:
        IndicatorUnitsConfig: 包含指标单位映射的配置对象

    Example:
        >>> units = get_default_indicator_units_config()
        >>> print(units.get_unit("氨氮"))
        'mg/L'
        >>> print(units.get_unit("NH3-N"))
        'mg/L'
    """
    return IndicatorUnitsConfig()


def get_default_cache_config() -> CacheConfig:
    """获取包含所有默认值的缓存配置

    Returns:
        CacheConfig: 包含所有默认值的缓存配置对象

    Example:
        >>> cache = get_default_cache_config()
        >>> print(cache.get_ttl_days())
        3
        >>> print(cache.max_size_mb)
        500
    """
    return CacheConfig()


# ============================================================================
# 向后兼容常量导出（供 config/company_info.py 使用）
# ============================================================================

# 默认图片资源目录路径（与config/company_info.py保持一致）
DEFAULT_IMAGES_DIR = _DEFAULT_IMAGES_DIR

# 默认公司信息（兼容旧的 DEFAULT_COMPANY_INFO 格式）
DEFAULT_COMPANY_INFO = get_legacy_company_info_dict()
