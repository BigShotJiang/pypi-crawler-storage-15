# setup.py

# due to a limitation in Setuptools support for PEP 660,
# adding a setup.py will work around this to allow for editable installs

from setuptools import setup

setup()
