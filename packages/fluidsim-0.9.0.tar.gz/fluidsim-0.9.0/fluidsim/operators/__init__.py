"""Numerical operators
======================

Provides

.. autosummary::
   :toctree:

   base
   operators0d
   operators2d
   operators3d
   sphericalharmo
   op_finitediff1d
   op_finitediff2d

"""
