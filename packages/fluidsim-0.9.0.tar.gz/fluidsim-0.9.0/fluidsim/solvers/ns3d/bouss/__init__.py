"""Boussinesq Navier-Stokes 3D solvers (:mod:`fluidsim.solvers.ns3d.bouss`)
===========================================================================

Provides:

.. autosummary::
   :toctree:

   solver

"""
