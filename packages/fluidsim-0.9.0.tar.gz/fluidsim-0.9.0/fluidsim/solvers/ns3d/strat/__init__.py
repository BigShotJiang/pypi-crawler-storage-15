"""Stratified Navier-Stokes 3D solvers (:mod:`fluidsim.solvers.ns3d.strat`)
===========================================================================

Provides:

.. autosummary::
   :toctree:

   solver
   state
   output

"""
