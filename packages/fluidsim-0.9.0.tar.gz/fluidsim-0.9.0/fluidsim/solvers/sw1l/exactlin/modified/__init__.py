"""Modified SW1L (:mod:`fluidsim.solvers.sw1l.exactlin.modified`)
=================================================================

.. autosummary::
   :toctree:

   solver
   output


"""
