"""SW1L with linear terms solved exactly (:mod:`fluidsim.solvers.sw1l.exactlin`)
================================================================================

.. autosummary::
   :toctree:

   solver
   state

.. autosummary::
   :toctree:

   modified

"""
