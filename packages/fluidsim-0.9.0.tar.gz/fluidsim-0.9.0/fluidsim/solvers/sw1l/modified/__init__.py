"""Modified SW1L (:mod:`fluidsim.solvers.sw1l.modified`)
========================================================

.. autosummary::
   :toctree:

   solver
   state
   output

"""
