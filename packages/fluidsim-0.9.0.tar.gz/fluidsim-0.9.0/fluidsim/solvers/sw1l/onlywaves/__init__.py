"""SW1L without vortices (:mod:`fluidsim.solvers.sw1l.onlywaves`)
=================================================================

.. autosummary::
   :toctree:

   solver
   state
   output

"""
