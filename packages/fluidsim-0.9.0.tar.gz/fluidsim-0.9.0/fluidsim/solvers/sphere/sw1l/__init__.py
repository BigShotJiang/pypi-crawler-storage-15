"""1-layer Shallow-Water solvers over a sphere (:mod:`fluidsim.solvers.sphere.sw1l`)
====================================================================================

Provides

.. autosummary::
   :toctree:

   solver
   state

"""
