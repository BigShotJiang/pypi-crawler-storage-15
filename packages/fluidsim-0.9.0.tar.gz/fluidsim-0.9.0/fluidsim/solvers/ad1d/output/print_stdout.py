from fluidsim.solvers.ns2d.output.print_stdout import PrintStdOutNS2D


class PrintStdOutAD1D(PrintStdOutNS2D):
    """Used to print in both the stdout and the stdout.txt file, and also
    to print simple info on the current state of the simulation.

    """
