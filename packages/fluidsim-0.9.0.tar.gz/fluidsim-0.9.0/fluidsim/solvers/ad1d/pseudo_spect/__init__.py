"""Advection-diffusion 1D solvers (:mod:`fluidsim.solvers.ad1d.pseudo_spect`)
=============================================================================

Provides:

.. autosummary::
   :toctree:

   solver
   state

"""
