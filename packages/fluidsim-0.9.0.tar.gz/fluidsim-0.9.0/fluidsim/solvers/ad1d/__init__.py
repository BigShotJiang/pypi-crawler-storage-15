"""Advection-diffusion 1D solvers (:mod:`fluidsim.solvers.ad1d`)
================================================================

Provides:

.. autosummary::
   :toctree:

   solver
   state
   init_fields

"""
