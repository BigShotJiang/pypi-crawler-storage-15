"""Lorenz solver (:mod:`fluidsim.solvers.models0d.lorenz`)
==========================================================

Provides:

.. autosummary::
   :toctree:

   solver
   output

"""
