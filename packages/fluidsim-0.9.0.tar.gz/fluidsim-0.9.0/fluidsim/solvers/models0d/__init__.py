"""Models 0 dimension (:mod:`fluidsim.solvers.models0d`)
========================================================

Provides:

.. autosummary::
   :toctree:

   predaprey
   lorenz

"""
