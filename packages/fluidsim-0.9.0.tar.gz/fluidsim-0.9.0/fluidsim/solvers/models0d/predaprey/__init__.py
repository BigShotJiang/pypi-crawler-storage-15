"""Predator-prey solver (:mod:`fluidsim.solvers.models0d.predaprey`)
====================================================================

Provides:

.. autosummary::
   :toctree:

   solver
   output

"""
