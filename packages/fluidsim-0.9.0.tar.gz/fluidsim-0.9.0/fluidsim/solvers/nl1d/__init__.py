"""Simple non-linear 1D solver (:mod:`fluidsim.solvers.nl1d`)
=============================================================

.. autosummary::
   :toctree:

   solver

"""
