"""Plate2d solvers (:mod:`fluidsim.solvers.plate2d`)
==========================================================


Provides:

.. autosummary::
   :toctree:

   solver
   state
   operators
   output
   init_fields
   forcing
   dimensional

"""
