"""Burgers 1D solver (:mod:`fluidsim.solvers.burgers1d`)
========================================================

Provides:

.. autosummary::
   :toctree:

   solver

"""
