"""Burgers 1D solver skew-symmteric form (:mod:`fluidsim.solvers.burgers1d.skew_sym`)
=====================================================================================

Provides:

.. autosummary::
   :toctree:

   solver

"""
