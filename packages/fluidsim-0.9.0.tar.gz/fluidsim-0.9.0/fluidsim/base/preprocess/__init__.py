"""Preprocessing of parameters (:mod:`fluidsim.base.preprocess`)
================================================================

Provides:

.. autosummary::
   :toctree:

   base
   pseudo_spect
   .. TODO: finite_diff

"""
