"""Solver based on Spherical Harmonic (:mod:`fluidsim.base.sphericalharmo`)
===========================================================================

Provides:

.. autosummary::
   :toctree:

   solver
   state

"""
