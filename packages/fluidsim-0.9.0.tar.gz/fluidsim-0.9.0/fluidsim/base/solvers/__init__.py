"""Base simulations (:mod:`fluidsim.base.solvers`)
========================================================


Provides:

.. autosummary::
   :toctree:

   base
   pseudo_spect
   finite_diff
   info_base

"""
