"""Time stepping (:mod:`fluidsim.base.time_stepping`)
===========================================================


Provides:

.. autosummary::
   :toctree:

   base
   pseudo_spect
   finite_diff

"""
