"""
python -m vmprof simul_profile2d_vmprof.py

http://vmprof.readthedocs.io/en/latest/vmprof.html

"""

from simul_profile2d import sim

sim.time_stepping.start()
