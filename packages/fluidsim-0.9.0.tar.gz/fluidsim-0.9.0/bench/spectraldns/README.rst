Benchmarking and profiling spectralDNS solvers
==============================================

https://github.com/spectralDNS/spectralDNS

Progress
--------

 - Installation is not a one-liner, if done through git and pip - but
   manageable. The developers maintains a conda channel though.

 - Benchmarks (2D/3D) and profile (3D) scripts added


.. todo::

        - Plot profiles, reusing code from fluidsim.util.console?
