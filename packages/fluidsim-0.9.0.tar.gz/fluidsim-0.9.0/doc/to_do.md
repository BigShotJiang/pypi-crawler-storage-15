# To do list

## Long term

- better integration with

  - paraview
  - VAPOR is the Visualization and Analysis Platform for Ocean, Atmosphere, and Solar
    Researchers (<https://www.vapor.ucar.edu/>)
  - VisIt is a free [and open-source], interactive parallel visualization and graphical
    analysis tool (<https://wci.llnl.gov/simulation/computer-codes/visit>)

## Inline to do items

```{eval-rst}
.. todolist::

```
