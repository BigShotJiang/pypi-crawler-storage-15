# Examples

```{toctree}
---
maxdepth: 2
---
examples/running-simul-onlineplot
examples/running-simul-cluster
examples/running-simul-restart
examples/init-fields-in-script
examples/init-fields-in-script-3d
examples/forcing-in-script
examples/static-layers
ipynb/executed/taylor-green
```

There are more interesting examples in
<https://foss.heptapod.net/fluiddyn/fluidsim/tree/branch/default/doc/examples>!
