conda activate env_fluidsim
