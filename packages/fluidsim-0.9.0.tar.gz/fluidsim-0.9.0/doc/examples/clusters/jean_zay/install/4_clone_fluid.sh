cd $WORK/Dev
rm -rf fluiddyn fluidfft

hg clone https://foss.heptapod.net/fluiddyn/fluidfft

cd $WORK/Dev/fluidsim/doc/examples/clusters/jean_zay/install
