from distutils.core import setup

setup(
    name="fluidjean_zay",
    description="Launch jobs on Jean-Zay",
    author="Pierre Augier",
    packages=["fluidjean_zay"],
)
