from distutils.core import setup

setup(
    name="fluidlicallo",
    description="Launch jobs on Licallo",
    author="Vincent Labarre",
    packages=["fluidlicallo"],
)
