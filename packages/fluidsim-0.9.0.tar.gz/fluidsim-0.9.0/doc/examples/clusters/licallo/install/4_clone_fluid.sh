cd $HOME/Dev
rm -rf fluidfft

hg clone https://foss.heptapod.net/fluiddyn/fluidfft

cd $HOME/Dev/fluidsim/doc/examples/clusters/licallo/install
