source ./setup_env_base.sh

conda activate env_fluidsim
