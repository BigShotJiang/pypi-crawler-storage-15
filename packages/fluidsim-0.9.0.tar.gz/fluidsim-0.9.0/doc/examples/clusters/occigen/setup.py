from distutils.core import setup

setup(
    name="fluidoccigen",
    description="Launch jobs on Occigen",
    author="Pierre Augier",
    packages=["fluidoccigen"],
)
