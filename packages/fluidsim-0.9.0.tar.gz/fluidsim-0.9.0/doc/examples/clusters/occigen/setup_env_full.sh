source setup_env_base.sh

conda activate env_$USER
