export MINICONDA=$SCRATCHDIR/../augier/miniconda3
export PATH=$MINICONDA/condabin/app:$PATH
