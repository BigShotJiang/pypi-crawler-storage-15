conda activate env_$USER
