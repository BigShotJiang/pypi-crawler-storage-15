#!/bin/bash
set -e

cp -rT ../conf_files $HOME/.
