Forcing defined in the launching script
=======================================

.. literalinclude:: simul_ns2dstrat_forcing_in_script.py
