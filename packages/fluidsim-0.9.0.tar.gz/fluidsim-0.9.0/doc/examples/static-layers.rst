Simulation with one dense layer
===============================

.. literalinclude:: simul_ns2dbouss_staticlayer.py
