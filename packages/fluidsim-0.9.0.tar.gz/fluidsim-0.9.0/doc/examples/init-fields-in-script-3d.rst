Initialization of the fields in the launching script (3d)
=========================================================

.. literalinclude:: simul_ns3dbouss_initfields_in_script.py
