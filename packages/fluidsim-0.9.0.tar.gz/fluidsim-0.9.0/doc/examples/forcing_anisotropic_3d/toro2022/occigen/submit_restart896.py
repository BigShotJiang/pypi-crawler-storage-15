from util import submit_restart, nb_nodes_from_N_896

submit_restart(nh=896, t_end=40.0, nb_nodes_from_N=nb_nodes_from_N_896)
