from util import submit_restart, nb_nodes_from_N_1792


submit_restart(nh=1792, t_end=48.0, nb_nodes_from_N=nb_nodes_from_N_1792)
