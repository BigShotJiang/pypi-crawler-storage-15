from util import submit_restart, nb_nodes_from_N_1344


submit_restart(nh=1344, t_end=44.0, nb_nodes_from_N=nb_nodes_from_N_1344)
