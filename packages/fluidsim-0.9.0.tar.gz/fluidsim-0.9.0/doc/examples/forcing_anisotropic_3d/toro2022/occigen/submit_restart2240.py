from util import submit_restart, nb_nodes_from_N_2240


submit_restart(nh=2240, t_end=50.0, nb_nodes_from_N=nb_nodes_from_N_2240)
