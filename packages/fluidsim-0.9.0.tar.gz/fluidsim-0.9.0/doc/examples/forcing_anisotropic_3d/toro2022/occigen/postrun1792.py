from util import postrun, couples2240


postrun(
    t_end=48.0,
    nh=1792,
    coef_modif_resol="5/4",
    couples_larger_resolution=couples2240,
)
