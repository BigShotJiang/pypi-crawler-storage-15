from util import postrun, couples1792


postrun(
    t_end=44.0,
    nh=1344,
    coef_modif_resol="4/3",
    couples_larger_resolution=couples1792,
)
