Initialization of the fields in the launching script (2d)
=========================================================

.. literalinclude:: simul_ns2dbouss_initfields_in_script.py
