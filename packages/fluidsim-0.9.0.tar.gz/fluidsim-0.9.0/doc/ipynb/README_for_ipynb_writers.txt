
Please read the file fluiddyn/doc/ipynb/README_for_ipynb_writers.rst

(http://fluiddyn.readthedocs.io/en/latest/ipynb/README_for_ipynb_writers.html)
