:orphan:

Creating news fragments
=======================

This directory contains "news fragments" which are short files that contain a
small **ReST**-formatted text that will be added to the next what's new page.
Read more about it here_.

.. _here: https://fluiddyn.readthedocs.io/en/latest/newsfragments/README.html
