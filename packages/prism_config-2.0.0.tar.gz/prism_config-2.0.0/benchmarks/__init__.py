"""
Benchmark suite for prism-config performance testing.

This module provides benchmarks to measure and track the performance
of configuration loading, secret resolution, and other operations.
"""
