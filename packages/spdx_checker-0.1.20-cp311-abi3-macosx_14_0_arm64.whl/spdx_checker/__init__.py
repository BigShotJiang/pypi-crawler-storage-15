from .spdx_checker import check_license

__all__ = ["check_license"]