
bat --color=always --theme=base16 --style=numbers,grid,header --line-range=300 $args

