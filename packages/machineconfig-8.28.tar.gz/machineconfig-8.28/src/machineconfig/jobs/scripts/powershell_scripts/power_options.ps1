
# power and sleep options.
Powercfg /Change monitor-timeout-ac 60
Powercfg /Change monitor-timeout-dc 0
Powercfg /Change standby-timeout-ac 0
Powercfg /Change standby-timeout-dc 0

