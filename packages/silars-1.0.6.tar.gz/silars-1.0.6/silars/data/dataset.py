# Copyright (c) ZhangYundi.
# Licensed under the MIT License. 
# Created on 2025/10/27 14:13
# Description:

from __future__ import annotations

from enum import Enum

import lidb
from functools import partial
import polars.selectors as cs
import polars as pl
from typing import Callable, Literal
import logair
import xcals
import ygo

class InstrumentType(Enum):

    STOCK = "Stock" # 股票
    ETF = "ETF" #
    CB = "ConvertibleBond" # 可转债

def complete_data(fn, date, save_path, partitions):

    logger = logair.get_logger(__name__)
    try:
        data = fn(date=date)
        if data is None:
            # 保存数据的逻辑在fn中实现了
            return
        # 剔除以 `_` 开头的列
        data = data.select(~cs.starts_with("_"))
        if not isinstance(data, (pl.DataFrame, pl.LazyFrame)):
            logger.error(f"{save_path}: Result of dataset.fn must be polars.DataFrame or polars.LazyFrame.")
            return
        if isinstance(data, pl.LazyFrame):
            data = data.collect()
        cols = data.columns
        if "date" not in cols:
            data = data.with_columns(pl.lit(date).alias("date")).select("date", *cols)

        lidb.put(data, save_path, abs_path=True, partitions=partitions)
    except Exception as e:
        logger.error(f"{save_path}: Error when complete data for {date}")
        logger.warning(e)

class Dataset:

    def __init__(self,
                 fn: Callable[..., pl.DataFrame],
                 tb: str,
                 update_time: str = "",
                 partitions: list[str] = None,
                 by_asset: bool = True,
                 by_time: bool = False):
        """

        Parameters
        ----------
        fn: str
            数据集计算函数
        tb: str
            数据集保存表格
        update_time: str
            更新时间: 默认没有-实时更新，也就是可以取到当天值
        partitions: list[str]
            分区
        by_asset: bool
            是否按照标的进行分区，默认 True
        by_time: bool
            是否按照标的进行分区，默认 False
        """
        self.fn = fn
        self.fn_params_sig = ygo.fn_signature_params(fn)
        self._by_asset = by_asset
        self._by_time = by_time
        self._append_partitions = ["asset", "date"] if by_asset else ["date", ]
        if by_time:
            self._append_partitions.append("time")
        if partitions is not None:
            partitions = [k for k in partitions if k not in self._append_partitions]
            partitions = [*partitions, *self._append_partitions]
        else:
            partitions = self._append_partitions
        self.partitions = partitions
        self._type_asset = "asset" in self.fn_params_sig
        self.update_time = update_time

        self.tb = tb
        self.save_path = lidb.tb_path(tb)
        fn_params = ygo.fn_params(self.fn)
        self.fn_params = {k: v for (k, v) in fn_params}
        self.constraints = dict()
        for k in self.partitions[:-len(self._append_partitions)]:
            if k in self.fn_params:
                v = self.fn_params[k]
                if isinstance(v, (list, tuple)) and not isinstance(v, str):
                    v = sorted(v)
                self.constraints[k] = v
                self.save_path = self.save_path / f"{k}={v}"

    def is_empty(self, path) -> bool:
        return not any(path.rglob("*.parquet"))

    def __call__(self, *fn_args, **fn_kwargs):
        # self.fn =
        fn = partial(self.fn, *fn_args, **fn_kwargs)
        ds = Dataset(fn=fn,
                     tb=self.tb,
                     partitions=self.partitions,
                     by_asset=self._by_asset,
                     by_time=self._by_time,
                     update_time=self.update_time)
        return ds

    def get_value(self, date, **constraints):
        """
        取值: 不保证未来数据
        Parameters
        ----------
        date: str
            取值日期
        constraints: dict
            取值的过滤条件

        Returns
        -------

        """
        _constraints = {k: v for k, v in constraints.items() if k in self.partitions}
        _limits = {k: v for k, v in constraints.items() if k not in self.partitions}
        search_path = self.save_path
        for k, v in _constraints.items():
            if isinstance(v, (list, tuple)) and not isinstance(v, str):
                v = sorted(v)
            search_path = search_path / f"{k}={v}"
        search_path = search_path / f"date={date}"

        if not self.is_empty(search_path):
            lf = lidb.scan(search_path, abs_path=True).cast({"date": pl.Utf8}).filter(date=date, **_limits)
            data = lf.collect()
            if not data.is_empty():
                return data
        fn = self.fn
        save_path = self.save_path

        if self._type_asset:
            if "asset" in _constraints:
                fn = ygo.delay(self.fn)(asset=_constraints["asset"])
        if len(self.constraints) < len(self.partitions) - len(self._append_partitions):
            # 如果分区指定的字段没有在Dataset定义中指定，需要在get_value中指定
            params = dict()
            for k in self.partitions[:-len(self._append_partitions)]:
                if k not in self.constraints:
                    v = constraints[k]
                    params[k] = v
                    save_path =save_path / f"{k}={v}"
            fn = ygo.delay(self.fn)(**params)
        logger = logair.get_logger(__name__)

        today = xcals.today()
        now = xcals.now()
        if (date > today) or (date == today and now < self.update_time):
            logger.warning(f"{self.tb}: {date} is not ready, waiting for {self.update_time}")
            return
        complete_data(fn, date, save_path, self._append_partitions)

        return lidb.scan(search_path, abs_path=True).cast({"date": pl.Utf8}).filter(date=date, **_limits).collect()

    def get_pit(self, date: str, time: str, **contraints):
        """取值：如果取值时间早于更新时间，则返回上一天的值"""
        if not self.update_time:
            return self.get_value(date, **contraints)
        val_date = date
        if time < self.update_time:
            val_date = xcals.shift_tradeday(date, -1)
        return self.get_value(val_date, **contraints).with_columns(date=pl.lit(date))

    def get_history(self,
                    dateList: list[str],
                    n_jobs: int = 5,
                    backend: Literal["threading", "multiprocessing", "loky"] = "loky",
                    eager: bool = True,
                    rep_asset: str = "000001", # 默认 000001
                    **constraints):
        """获取历史值: 不保证未来数据"""
        _constraints = {k: v for k, v in constraints.items() if k in self.partitions}
        search_path = self.save_path
        for k, v in _constraints.items():
            if isinstance(v, (list, tuple)) and not isinstance(v, str):
                v = sorted(v)
            search_path = search_path / f"{k}={v}"
        if self.is_empty(search_path):
            # 需要补全全部数据
            missing_dates = dateList
        else:
            if not self._type_asset:
                _search_path = self.save_path
                for k, v in _constraints.items():
                    if k != "asset":
                        _search_path = _search_path / f"{k}={v}"
                    else:
                        _search_path = _search_path / f"asset={rep_asset}"
                hive_info = lidb.parse_hive_partition_structure(_search_path)
            else:
                hive_info = lidb.parse_hive_partition_structure(search_path)
            exist_dates = hive_info["date"].to_list()
            missing_dates = set(dateList).difference(set(exist_dates))
            missing_dates = sorted(list(missing_dates))
        if missing_dates:
            fn = self.fn
            save_path = self.save_path

            if self._type_asset:
                if "asset" in _constraints:
                    fn = ygo.delay(self.fn)(asset=_constraints["asset"])

            if len(self.constraints) < len(self.partitions) - len(self._append_partitions):
                params = dict()
                for k in self.partitions[:-len(self._append_partitions)]:
                    if k not in self.constraints:
                        v = constraints[k]
                        params[k] = v
                        save_path =save_path / f"{k}={v}"
                fn = ygo.delay(self.fn)(**params)

            with ygo.pool(n_jobs=n_jobs, backend=backend) as go:
                info_path = self.save_path
                try:
                    info_path = info_path.relative_to(lidb.DB_PATH)
                except:
                    pass
                for date in missing_dates:
                    go.submit(complete_data, job_name=f"Completing {info_path}")(
                        fn=fn,
                        date=date,
                        save_path=save_path,
                        partitions=self._append_partitions,
                    )
                go.do()
        data = lidb.scan(search_path, abs_path=True).cast({"date": pl.Utf8}).filter(pl.col("date").is_in(dateList), **constraints)
        data = data.sort("date")
        if eager:
            return data.collect()
        return data


