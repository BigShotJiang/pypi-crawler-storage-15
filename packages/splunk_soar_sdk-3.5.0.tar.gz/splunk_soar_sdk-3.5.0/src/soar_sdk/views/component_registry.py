from soar_sdk.views.components.pie_chart import PieChartData

COMPONENT_REGISTRY = {
    PieChartData: "pie_chart",
}
