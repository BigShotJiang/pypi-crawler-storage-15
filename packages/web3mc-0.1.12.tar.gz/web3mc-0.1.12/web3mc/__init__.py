from .multicall import Multicall

__all__ = ["Multicall"]
