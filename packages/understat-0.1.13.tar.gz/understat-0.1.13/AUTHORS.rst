Maintainer
``````````

- Amos Bastian <amosbastian@gmail.com> `@amosbastian <https://github.com/amosbastian>`_

Contributors
````````````

- Chris Musson <chris.musson@hotmail.com> `@ChrisMusson <https://github.com/ChrisMusson>`_
- Gracjan Strzelec <gracjanss98@gmail.com> `@gracjans <https://github.com/gracjans>`_