## 1.2.1

* Removed version cap from NumPy and SciPy dependencies
* Introduction of the changelog

## 1.2.0

* Adds significance tests. Only currently added test is *Whitenoise significance check*.
