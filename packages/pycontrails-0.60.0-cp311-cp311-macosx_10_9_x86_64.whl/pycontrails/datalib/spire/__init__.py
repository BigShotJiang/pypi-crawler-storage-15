"""`Spire Aviation <https://spire.com/aviation/>`_ ADS-B data support."""

from pycontrails.datalib.spire.spire import ValidateTrajectoryHandler

__all__ = ["ValidateTrajectoryHandler"]
