"""Physical and thermodynamic relations."""
