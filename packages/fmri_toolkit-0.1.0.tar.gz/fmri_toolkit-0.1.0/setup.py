"""Setup script for fmri-toolkit package.

For modern Python packaging, see pyproject.toml.
This file is provided for backward compatibility.
"""

from setuptools import setup

if __name__ == "__main__":
    setup()
