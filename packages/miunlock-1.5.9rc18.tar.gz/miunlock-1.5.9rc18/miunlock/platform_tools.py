import os
import platform
import shutil

def check_fastboot():
    if platform.system() == "Linux" and os.path.exists("/data/data/com.termux"):      
        if not os.path.exists("/data/data/com.termux.api"):
            return {"error": "\ncom.termux.api app is not installed\nPlease install it first"}
        cmd = shutil.which("termux-fastboot")        
        if cmd is None:
            return {"error": "\ntermux-fastboot is not installed!\nPlease install it first\n https://github.com/nohajc/termux-adb"}
        else:
            return cmd
    else:
        cmd = shutil.which("fastboot")        
        if cmd is None:
            return {"error": "\nfastboot is not installed or not in PATH"}
        else:
            return cmd