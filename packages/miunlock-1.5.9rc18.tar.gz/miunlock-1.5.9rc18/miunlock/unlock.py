from miunlock.utils import _send
from miunlock.commands import get_device_token, get_product
import random
import hashlib
import io
import subprocess
import os
import time
from pathlib import Path

def unlock_device(domain, ssecurity, cookies, pcId, fastboot_cmd):
    userId = cookies.get("userId")
        
    r = "".join(random.choices("abcdefghijklmnopqrstuvwxyz", k=16))
    nonce_resp = _send("/api/v2/nonce", ["r", "sid"], {"r": r}, domain, ssecurity, cookies)
    
    if "error" in nonce_resp:
        print(nonce_resp)
        return 
    nonce = nonce_resp.get("nonce")
    if not nonce:
        print("Failed to get nonce")
        return 

    [print(char, end='', flush=True) or time.sleep(0.01) for char in "\nEnsure you're in Bootloader mode (fastboot mode)\n\n"]

    product = get_product(fastboot_cmd)

    data = {"product": product}

    clear =  _send(
        "/api/v2/unlock/device/clear",
        ["appId", "data", "nonce", "sid"],
        {"appId": "1", "data": data, "nonce": nonce},
        domain, ssecurity, cookies
    )

    if "error" in clear:
        print(clear)
        return 

    print("\n" + "\n".join([f"{key}: {value}" for key, value in clear.items()]))

    input("\nPress 'Enter' to continue — get encryptData")

    device_token = get_device_token(fastboot_cmd)

    data = {
        "clientId": "2",
        "clientVersion": "7.6.727.43",
        "deviceInfo": {
            "boardVersion": "",
            "deviceName": "",
            "product": product,
            "socId": ""
        },
        "deviceToken": device_token,
        "language": "en",
        "operate": "unlock",
        "pcId": hashlib.md5(pcId.encode()).hexdigest(),
        "region": "",
        "uid": userId
    }

    unlock_result =  _send(
        "/api/v3/ahaUnlock",
        ["appId", "data", "nonce", "sid"],
        {"appId": "1", "data": data, "nonce": nonce},
        domain, ssecurity, cookies
    )

    if "error" in unlock_result:
        print(unlock_result)

    print("\n" + "\n".join([f"{key}: {value}" for key, value in unlock_result.items()]))

    if "code" in unlock_result and unlock_result["code"] == 0:
        encryptData = unlock_result["encryptData"]
        ed = io.BytesIO(bytes.fromhex(encryptData))
        filename = Path.home() / f"{int(time.time())}encryptData"
        with open(filename, "wb") as edfile:
            edfile.write(ed.getvalue())
        print(f"\nEncrypted data saved to: {filename}")
        try:
            result_stage = subprocess.run([fastboot_cmd, "stage", filename], check=True, capture_output=True, text=True)
            result_unlock = subprocess.run([fastboot_cmd, "oem", "unlock"], check=True, capture_output=True, text=True)
            print(f"\nUnlock successful\n")
            return
        except subprocess.CalledProcessError as e:
            print(e.stderr)
            return 
            
