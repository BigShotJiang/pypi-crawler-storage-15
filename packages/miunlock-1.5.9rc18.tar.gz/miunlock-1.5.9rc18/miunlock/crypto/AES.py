
import os
import sys
import abc
from os import urandom

# --- From Cryptodome.Random ---
get_random_bytes = urandom

# --- From Cryptodome.Util.py3compat ---
if sys.version_info[0] == 2:
    def _copy_bytes(start, end, seq):
        if isinstance(seq, memoryview):
            return seq[start:end].tobytes()
        elif isinstance(seq, bytearray):
            return bytes(seq[start:end])
        else:
            return seq[start:end]
    def byte_string(s):
        return isinstance(s, str)
else:
    def _copy_bytes(start, end, seq):
        if isinstance(seq, memoryview):
            return seq[start:end].tobytes()
        elif isinstance(seq, bytearray):
            return bytes(seq[start:end])
        else:
            return seq[start:end]
    def byte_string(s):
        return isinstance(s, bytes)

# --- From Cryptodome.Util._raw_api ---
if sys.version_info[0] < 3:
    import imp
    extension_suffixes = []
    for ext, mod, typ in imp.get_suffixes():
        if typ == imp.C_EXTENSION:
            extension_suffixes.append(ext)
else:
    from importlib import machinery
    extension_suffixes = machinery.EXTENSION_SUFFIXES

_buffer_type = (bytearray, memoryview)

class _VoidPointer(object):
    @abc.abstractmethod
    def get(self): return
    @abc.abstractmethod
    def address_of(self): return

try:
    if '__pypy__' not in sys.builtin_module_names and sys.flags.optimize == 2:
        raise ImportError("CFFI with optimize=2 fails due to pycparser bug.")
    if sys.version_info >= (3, 12) and os.name == "nt":
        raise ImportError("CFFI is not compatible with Python 3.12 on Windows")
    from cffi import FFI
    ffi = FFI()
    uint8_t_type = ffi.typeof(ffi.new("const uint8_t*"))
    _Array = ffi.new("uint8_t[1]").__class__.__bases__
    def load_lib(name, cdecl):
        if hasattr(ffi, "RTLD_DEEPBIND") and not os.getenv('PYCRYPTODOME_DISABLE_DEEPBIND'):
            lib = ffi.dlopen(name, ffi.RTLD_DEEPBIND)
        else:
            lib = ffi.dlopen(name)
        ffi.cdef(cdecl)
        return lib
    def c_size_t(x): return x
    def create_string_buffer(init_or_size, size=None):
        if isinstance(init_or_size, bytes):
            size = max(len(init_or_size) + 1, size)
            result = ffi.new("uint8_t[]", size)
            result[:] = init_or_size
        else:
            if size: raise ValueError("Size must be specified once only")
            result = ffi.new("uint8_t[]", init_or_size)
        return result
    def get_raw_buffer(buf): return ffi.buffer(buf)[:]
    def c_uint8_ptr(data):
        if isinstance(data, _buffer_type): return ffi.cast(uint8_t_type, ffi.from_buffer(data))
        elif byte_string(data) or isinstance(data, _Array): return data
        else: raise TypeError("Object type %s cannot be passed to C code" % type(data))
    class VoidPointer_cffi(_VoidPointer):
        def __init__(self): self._pp = ffi.new("void *[1]")
        def get(self): return self._pp[0]
        def address_of(self): return self._pp
    def VoidPointer(): return VoidPointer_cffi()
except ImportError:
    import ctypes
    from ctypes import (CDLL, c_void_p, byref, c_size_t, create_string_buffer)
    from ctypes.util import find_library
    from ctypes import Array as _Array
    cached_architecture = []
    def load_lib(name, cdecl):
        if not cached_architecture:
            import platform
            cached_architecture[:] = platform.architecture()
        bits, linkage = cached_architecture
        if "." not in name and not linkage.startswith("Win"):
            full_name = find_library(name)
            if full_name is None: raise OSError("Cannot load library '%s'" % name)
            name = full_name
        return CDLL(name)
    def get_raw_buffer(buf): return buf.raw
    _c_ssize_t = ctypes.c_ssize_t
    _PyBUF_SIMPLE = 0
    _PyObject_GetBuffer = ctypes.pythonapi.PyObject_GetBuffer
    _PyBuffer_Release = ctypes.pythonapi.PyBuffer_Release
    _py_object = ctypes.py_object
    class _Py_buffer(ctypes.Structure):
        _fields_ = [('buf', c_void_p), ('obj', ctypes.py_object), ('len', _c_ssize_t), ('itemsize', _c_ssize_t), ('readonly', ctypes.c_int), ('ndim', ctypes.c_int), ('format', ctypes.c_char_p), ('shape', ctypes.POINTER(_c_ssize_t)), ('strides', ctypes.POINTER(_c_ssize_t)), ('suboffsets', ctypes.POINTER(_c_ssize_t)), ('internal', c_void_p)]
        if sys.version_info[0] == 2: _fields_.insert(-1, ('smalltable', _c_ssize_t * 2))
    def c_uint8_ptr(data):
        if byte_string(data) or isinstance(data, _Array): return data
        elif isinstance(data, _buffer_type):
            obj = _py_object(data)
            buf = _Py_buffer()
            _PyObject_GetBuffer(obj, byref(buf), _PyBUF_SIMPLE)
            try:
                buffer_type = ctypes.c_ubyte * buf.len
                return buffer_type.from_address(buf.buf)
            finally: _PyBuffer_Release(byref(buf))
        else: raise TypeError("Object type %s cannot be passed to C code" % type(data))
    class VoidPointer_ctypes(_VoidPointer):
        def __init__(self): self._p = c_void_p()
        def get(self): return self._p
        def address_of(self): return byref(self._p)
    def VoidPointer(): return VoidPointer_ctypes()

class SmartPointer(object):
    def __init__(self, raw_pointer, destructor):
        self._raw_pointer = raw_pointer
        self._destructor = destructor
    def get(self): return self._raw_pointer
    def release(self):
        rp, self._raw_pointer = self._raw_pointer, None
        return rp
    def __del__(self):
        try:
            if self._raw_pointer is not None:
                self._destructor(self._raw_pointer)
                self._raw_pointer = None
        except AttributeError: pass

def load_pycryptodome_raw_lib(name, cdecl):
    dir_path = os.path.dirname(os.path.abspath(__file__))
    attempts = []
    for ext in extension_suffixes:
        try:
            filename = name + ext
            full_name = os.path.join(dir_path, filename)
            if not os.path.isfile(full_name):
                attempts.append("Not found '%s'" % filename)
                continue
            return load_lib(full_name, cdecl)
        except OSError as exp:
            attempts.append("Cannot load '%s': %s" % (filename, str(exp)))
    raise OSError("Cannot load native module '%s': %s" % (name, ", ".join(attempts)))

def is_writeable_buffer(x):
    return (isinstance(x, bytearray) or (isinstance(x, memoryview) and not x.readonly))

_raw_cpuid_lib = load_pycryptodome_raw_lib("_cpuid_c", "int have_aes_ni(void); int have_clmul(void);")
def have_aes_ni(): return _raw_cpuid_lib.have_aes_ni()

class AES:
    MODE_CBC = 2
    block_size = 16
    key_size = (16, 24, 32)

    @staticmethod
    def new(key, mode, *args, **kwargs):
        return _create_cipher(key, mode, *args, **kwargs)

_cproto_AES = """
        int AES_start_operation(const uint8_t key[], size_t key_len, void **pResult);
        int AES_encrypt(const void *state, const uint8_t *in, uint8_t *out, size_t data_len);
        int AES_decrypt(const void *state, const uint8_t *in, uint8_t *out, size_t data_len);
        int AES_stop_operation(void *state);
        """
_raw_aes_lib = load_pycryptodome_raw_lib("_raw_aes", _cproto_AES)
try:
    _raw_aesni_lib = None
    if have_aes_ni():
        _raw_aesni_lib = load_pycryptodome_raw_lib("_raw_aesni", _cproto_AES.replace("AES", "AESNI"))
except OSError:
    pass

_cproto_CBC = """
        int CBC_start_operation(void *cipher, const uint8_t iv[], size_t iv_len, void **pResult);
        int CBC_encrypt(void *cbcState, const uint8_t *in, uint8_t *out, size_t data_len);
        int CBC_decrypt(void *cbcState, const uint8_t *in, uint8_t *out, size_t data_len);
        int CBC_stop_operation(void *state);
        """
raw_cbc_lib = load_pycryptodome_raw_lib("_raw_cbc", _cproto_CBC)

class CbcMode(object):
    def __init__(self, block_cipher, iv):
        self._state = VoidPointer()
        result = raw_cbc_lib.CBC_start_operation(block_cipher.get(), c_uint8_ptr(iv), c_size_t(len(iv)), self._state.address_of())
        if result: raise ValueError("Error %d while instantiating the CBC mode" % result)
        self._state = SmartPointer(self._state.get(), raw_cbc_lib.CBC_stop_operation)
        block_cipher.release()
        self.block_size = len(iv)
        self.iv = _copy_bytes(None, None, iv)
        self.IV = self.iv
        self._next = ["encrypt", "decrypt"]

    def encrypt(self, plaintext, output=None):
        if "encrypt" not in self._next: raise TypeError("encrypt() cannot be called after decrypt()")
        self._next = ["encrypt"]
        if output is None:
            ciphertext = create_string_buffer(len(plaintext))
        else:
            ciphertext = output
            if not is_writeable_buffer(output): raise TypeError("output must be a bytearray or a writeable memoryview")
            if len(plaintext) != len(output): raise ValueError("output must have the same length as the input")
        result = raw_cbc_lib.CBC_encrypt(self._state.get(), c_uint8_ptr(plaintext), c_uint8_ptr(ciphertext), c_size_t(len(plaintext)))
        if result:
            if result == 3: raise ValueError("Data must be padded to %d byte boundary in CBC mode" % self.block_size)
            raise ValueError("Error %d while encrypting in CBC mode" % result)
        return get_raw_buffer(ciphertext) if output is None else None

    def decrypt(self, ciphertext, output=None):
        if "decrypt" not in self._next: raise TypeError("decrypt() cannot be called after encrypt()")
        self._next = ["decrypt"]
        if output is None:
            plaintext = create_string_buffer(len(ciphertext))
        else:
            plaintext = output
            if not is_writeable_buffer(output): raise TypeError("output must be a bytearray or a writeable memoryview")
            if len(ciphertext) != len(output): raise ValueError("output must have the same length as the input")
        result = raw_cbc_lib.CBC_decrypt(self._state.get(), c_uint8_ptr(ciphertext), c_uint8_ptr(plaintext), c_size_t(len(ciphertext)))
        if result:
            if result == 3: raise ValueError("Data must be padded to %d byte boundary in CBC mode" % self.block_size)
            raise ValueError("Error %d while decrypting in CBC mode" % result)
        return get_raw_buffer(plaintext) if output is None else None

def _create_base_cipher(dict_parameters):
    use_aesni = dict_parameters.pop("use_aesni", True)
    try:
        key = dict_parameters.pop("key")
    except KeyError:
        raise TypeError("Missing 'key' parameter")
    if len(key) not in AES.key_size:
        raise ValueError("Incorrect AES key length (%d bytes)" % len(key))
    if use_aesni and _raw_aesni_lib:
        start_operation = _raw_aesni_lib.AESNI_start_operation
        stop_operation = _raw_aesni_lib.AESNI_stop_operation
    else:
        start_operation = _raw_aes_lib.AES_start_operation
        stop_operation = _raw_aes_lib.AES_stop_operation
    cipher = VoidPointer()
    result = start_operation(c_uint8_ptr(key), c_size_t(len(key)), cipher.address_of())
    if result:
        raise ValueError("Error %X while instantiating the AES cipher" % result)
    return SmartPointer(cipher.get(), stop_operation)

def _create_cbc_cipher(kwargs):
    cipher_state = _create_base_cipher(kwargs)
    iv = kwargs.pop("IV", None)
    IV = kwargs.pop("iv", None)
    if (None, None) == (iv, IV):
        iv = get_random_bytes(AES.block_size)
    if iv is not None:
        if IV is not None: raise TypeError("You must either use 'iv' or 'IV', not both")
    else:
        iv = IV
    if len(iv) != AES.block_size:
        raise ValueError("Incorrect IV length (it must be %d bytes long)" % AES.block_size)
    if kwargs:
        raise TypeError("Unknown parameters for CBC: %s" % str(kwargs))
    return CbcMode(cipher_state, iv)

def _create_cipher(key, mode, *args, **kwargs):
    if mode != AES.MODE_CBC:
        raise ValueError("Only CBC mode is supported")
    kwargs["key"] = key
    if args:
        if len(args) > 1:
            raise TypeError("Too many arguments for this mode")
        kwargs["IV"] = args[0]
    return _create_cbc_cipher(kwargs)
