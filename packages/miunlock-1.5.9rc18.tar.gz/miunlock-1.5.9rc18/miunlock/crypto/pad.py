
import sys

if sys.version_info[0] == 2:
    def bchr(s):
        return chr(s)
else:
    def bchr(s):
        return bytes([s])

def pad(data_to_pad, block_size, style='pkcs7'):
    padding_len = block_size - len(data_to_pad) % block_size
    if style == 'pkcs7':
        padding = bchr(padding_len) * padding_len
    elif style == 'x923':
        padding = bchr(0)*(padding_len-1) + bchr(padding_len)
    elif style == 'iso7816':
        padding = bchr(128) + bchr(0) * (padding_len-1)
    else:
        raise ValueError("Unknown padding style")
    return data_to_pad + padding
