"""Tests for grounding tools."""
