# tunacode-cli

[![PyPI version](https://badge.fury.io/py/tunacode-cli.svg)](https://badge.fury.io/py/tunacode-cli)
[![Downloads](https://pepy.tech/badge/tunacode-cli)](https://pepy.tech/project/tunacode-cli)
[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

A TUI code agent.

> **Development Status:** This project is under heavy active development. The tool is stable and the current architecture is final, serving as the foundation for future improvements. However, you may still encounter bugs. This is a personal project developed in my spare time, so your patience is appreciated.

> "The best thing about a boolean is even if you are wrong, you are only off by a bit."

## Interface

![TUI Interface](docs/images/tui.png)

The Textual-based terminal user interface provides a clean, interactive environment for AI-assisted coding, with a design heavily inspired by the classic NeXTSTEP user interface.

## Theme Support

The interface supports multiple themes for different preferences and environments.

![Theme](docs/images/theme.png)

Customize the appearance with built-in themes or create your own color schemes.

## Model Setup

Configure your AI models and settings through the provided setup interface.

![TUI Model Setup](docs/images/tui-model-setup.png)

**Note:** TunaCode has full bash shell access. This tool assumes you know what you're doing. If you're concerned, run it in a sandboxed environment.

## v0.1.1 - Major Rewrite

This release is a complete rewrite with a new Textual-based TUI.

**Upgrading from v1?** The legacy v1 codebase is preserved in the `legacy-v1` branch and will only receive security updates.

## Requirements

- Python 3.11+

## Installation

```bash
uv tool install tunacode-cli
```

## Quick Start

1. Run the setup wizard to configure your API key:

```bash
tunacode --setup
```

2. Start coding:

```bash
tunacode
```

## Configuration

Set your API key as an environment variable or use the setup wizard:

```bash
export OPENAI_API_KEY="your-key"
# or
export ANTHROPIC_API_KEY="your-key"
```

Config file location: `~/.config/tunacode.json`

## Commands

| Command  | Description             |
| -------- | ----------------------- |
| /help    | Show available commands |
| /model   | Change AI model         |
| /clear   | Clear conversation      |
| /compact | Compress context        |
| exit     | Quit tunacode           |

## License

MIT
