'''
            OMArk - Quality assesment of coding-gene repertoire annotation
            (C) 2022 Yannis Nevers <yannis.nevers@unil.ch>
            This file is part of OMArk.
            OMArk is free software: you can redistribute it and/or modify
            it under the terms of the GNU Lesser General Public License as published by
            the Free Software Foundation, either version 3 of the License, or
            (at your option) any later version.
            OMArk is distributed in the hope that it will be useful,
            but WITHOUT ANY WARRANTY; without even the implied warranty of
            MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
            GNU Lesser General Public License for more details.
            You should have received a copy of the GNU Lesser General Public License
            along with OMArk. If not, see <http://www.gnu.org/licenses/>.
        '''

import os
import sys
from . import files as io
from . import species_determination as spd
from . import omamer_utils as outils
from . import scoring as sc
from . import graphics as graph
from .utils import LOG, set_log_level


def get_omamer_qscore(omamerfile, dbpath, stordir, taxid=None, contamination= True, original_FASTA_file = None, force = True, isoform_file = None, min_n_species=5, taxonomic_rank= None, extract_conserved_only=True):
    allres = dict()
    
    basefile = '.'.join(omamerfile.split('/')[-1].split('.')[:-1])
    if force or not os.path.isfile(stordir+'/'+basefile+".omq"): 
        #Extract OMAmer data
        LOG.info('Extracting data from input file: '+omamerfile)

        omamdata, not_mapped  = io.parseOmamer(omamerfile)

        #Check omamer version:
        if "hoglevel" in omamdata[0]:
            omamer_version = "2.0.0"
        else:
            omamer_version = "0.2.0"
        hog_tab, prot_tab, sp_tab, tax_tab, fam_tab, cprot_buff, tax_buff, chog_buff, hogtax_buff, hog_id_buff = outils.open_db(dbpath)


        if isoform_file:
            LOG.info('An isoform_file was provided.')
            LOG.info('Extracting data from isoform file '+isoform_file)
            isoform_data = io.parse_isoform_file(isoform_file)
            omamdata, not_mapped, selected_isoforms = io.select_isoform(isoform_data, omamdata, omamer_version)

        #Get only full match for placements
        full_match_data, partials, fragments = io.filter_partial_matches(omamdata)

        LOG.info('Determinating species composition from HOG placements')

        #Determine species and contamination
        if omamer_version == "2.0.0":
            placements = spd.get_present_lineages(full_match_data, hog_tab, tax_tab, tax_buff, sp_tab, chog_buff)
        else:
            placements = spd.get_present_lineages(full_match_data, hog_tab, tax_tab, tax_buff, sp_tab, chog_buff, family_score_filter=None, cutoff_percentage=0.001)


        #Get the proteins placed in species correspoding to each placement in a dictionary
        prot_clade = spd.get_prot_by_clades(placements, omamdata, hog_tab, tax_tab, tax_buff, chog_buff)
        #Reorganize the placements to consider the species with most proteins to be the main one. (Needed in edge cases where the proteins of the contaminant
        #is an exhaustive set).
        placements = spd.reorganized_placement(placements, prot_clade)
        
        #Procedure when the user do not give taxonomu information. Will use the main species from the placement
        if taxid==None:

            likely_clade =  placements[0][0]
            LOG.info('No taxid was provided. From HOG placements, the query taxon is '+likely_clade)

        #Otherwise find the closest clade in the OMAmer database from the given taxid
        else :
            lin = spd.get_lineage_ncbi(taxid)
            likely_clade = spd.find_taxa_from_ncbi(lin, tax_tab, sp_tab,tax_buff)
            #Used in case the placement main species conflict with the given taxid, will chose the given clade as reference
            placements = spd.reorganize_placements_from_taxid(placements, likely_clade,tax_tab, tax_buff)
            LOG.info('A taxid was provided. The query taxon is '+likely_clade)

        #Get the proteins belonging to contaminants
        contaminant_prots = spd.get_contaminant_proteins(placements, prot_clade)
        #Add the taxid information to the species description list.
        placements = spd.add_taxid(placements, tax_tab)
        placements, prot_clade = spd.add_uncertain_contaminants(placements, prot_clade)
        #Get the first parent of the chosen clade with at least min_n_species species
        closest_corr = spd.get_sampled_taxa(likely_clade, min_n_species , tax_tab, sp_tab, tax_buff, taxonomic_rank)

        LOG.info('Ancestral lineage is '+closest_corr)

        #Conshog : HOG with 80% representative of the target lineage
        #Cladehog : HOG with at least 1 representative of the target lineage present in the common ancestir
        LOG.info('Estimating ancestral and conserved HOG content')

        conshog, cladehog = sc.get_conserved_hogs(closest_corr, hog_tab, prot_tab, sp_tab, tax_tab, fam_tab,  cprot_buff,chog_buff, tax_buff, hogtax_buff, True, threshold=0.8)
        lineage_rhog = sc.get_root_HOGs_descendants(closest_corr, tax_tab, hog_tab, fam_tab,tax_buff)

        cladehog = cladehog + lineage_rhog

        LOG.info(str(len(cladehog))+" HOGs are associated to the query's lineage and will be used for consistency assesment")
        LOG.info(str(len(conshog))+' conserved ancestral HOGs will be used from completeness assesment')

        LOG.info('Comparing the query gene repertoire to lineage-associated HOGs')
        wholeres, found_clade, nic = sc.found_with_omamer(omamdata ,cladehog, hog_tab, chog_buff, hog_id_buff)
        res_proteomes = sc.score_whole_proteome(found_clade, nic, partials, fragments, not_mapped, contaminant_prots)

        LOG.info('Comparing the query gene repertoire to conserved ancestral HOGs')
        res_completeness, found_cons, nicons = sc.found_with_omamer(omamdata ,conshog, hog_tab, chog_buff, hog_id_buff)

        LOG.info('Writing OMArk output files')

        #Store the taxonomic choices
        io.store_close_level(stordir+'/'+basefile+".tax", {'Sampled': str(closest_corr),
                                                                            'Closest' : str(likely_clade) })

        #Write optionnal taxa files
        if original_FASTA_file:
            if contamination :
                io.store_contaminant_FASTA(stordir, basefile, prot_clade, original_FASTA_file)
            io.store_incorrect_map_FASTA(stordir, basefile, not_mapped, nic, original_FASTA_file)


        if isoform_file:
            io.store_list(stordir+'/'+basefile+"_selected_isoforms.txt", selected_isoforms)
        #Write results files
        io.store_results(stordir+'/'+basefile+".ump", { key : res_proteomes[key] for key in ['Consistent_Full', 'Consistent_Partial', 'Consistent_Fragment',
                                                                                             'Inconsistent_Full', 'Inconsistent_Partial', 'Inconsistent_Fragment',
                                                                                             'Contamination_Full', 'Contamination_Partial', 'Contamination_Fragment',
                                                                                             'Unknown']})
        io.store_results(stordir+'/'+basefile+".omq", res_completeness) 
        io.write_templated_report('summarized_report.txt', stordir+'/'+basefile+".sum", res_completeness, res_proteomes, closest_corr, placements)

        io.write_templated_report('textual_report.txt', stordir+'/'+basefile+"_detailed_summary.txt", res_completeness, res_proteomes, closest_corr, placements)
        #Write graphical representation
        plot_res = {'pdf': os.path.join(stordir, basefile + ".pdf"),
                    'png': os.path.join(stordir, basefile + ".png")}
        graph.plot_omark_results(plot_res, res_completeness, res_proteomes)



def get_only_conserved_HOGs(dbpath, stordir, taxid, taxonomic_rank=None):
    hog_tab, prot_tab, sp_tab, tax_tab, fam_tab, cprot_buff, tax_buff, chog_buff, hogtax_buff, hog_id_buff = outils.open_db(dbpath)
    lin = spd.get_lineage_ncbi(taxid)
    likely_clade = spd.find_taxa_from_ncbi(lin, tax_tab, sp_tab,tax_buff)
    LOG.info('A taxid was provided. The query taxon is '+likely_clade)

    closest_corr = spd.get_sampled_taxa(likely_clade, 5 , tax_tab, sp_tab, tax_buff, taxonomic_rank)
    LOG.info('Ancestral lineage is '+closest_corr)
    LOG.info('Estimating ancestral HOG content')
    conshog, cladehog = sc.get_conserved_hogs(closest_corr, hog_tab, prot_tab, sp_tab, tax_tab, fam_tab,  cprot_buff,chog_buff, tax_buff, hogtax_buff, True, threshold=0.8)
    LOG.info(str(len(conshog))+" HOGs are conserved in the query's lineage.")


    hog_list = [outils.get_hog_id(x, hog_id_buff) for x in conshog]
    io.store_list(stordir+'/conserved_HOGs.txt', hog_list, comment=[f'Ancestral lineage: {closest_corr}'])

def summarize_species_db(dbpath,output_file):
    hog_tab, prot_tab, sp_tab, tax_tab, fam_tab, cprot_buff, tax_buff, chog_buff, hogtax_buff, hog_id_buff = outils.open_db(dbpath)
    full_summary = []
    spec_by_tax = outils.get_spec_by_tax(tax_tab,sp_tab, tax_buff )
    nr_sp_by_tax = {x : len(y) for x,y in spec_by_tax.items() if len(y)>=5}
    name_to_taxid= outils.get_name_to_taxid([x for x in spec_by_tax.keys()], tax_tab)
    all_taxids =  name_to_taxid.values()

    taxid_ranks = spd.get_ranks(all_taxids)
    for spec in spec_by_tax:
        all_sp = sorted(list(spec_by_tax.get(spec)))
        nr_spec = nr_sp_by_tax.get(spec,0)
        if nr_spec<5:
            continue
        conshog, cladehog = sc.get_conserved_hogs(spec, hog_tab, prot_tab, sp_tab, tax_tab, fam_tab,  cprot_buff,chog_buff, tax_buff, hogtax_buff, True, threshold=0.8)
        lineage_rhog = sc.get_root_HOGs_descendants(spec, tax_tab, hog_tab, fam_tab,tax_buff)
        nr_cons_hog  = len(conshog)
        nr_hog_taxon = len(cladehog+lineage_rhog)
        taxid = name_to_taxid[spec]
        rank = taxid_ranks.get(taxid,None)
        all_data_spec  = (spec, taxid, rank,nr_spec, nr_cons_hog, nr_hog_taxon,",".join(all_sp))
        full_summary.append(all_data_spec)
    io.write_db_summary(output_file, full_summary)

def check_parameters(omamerfile, dbpath, stordir, taxid=None, original_FASTA_file = None,  isoform_file = None, taxonomic_rank=None):

    omamerfile_valid = io.check_omamerfile(omamerfile)

    database_valid = outils.check_database(dbpath)

    taxid_valid = spd.check_taxid(taxid)

    output_directory_valid = io.check_and_create_output_folder(stordir)

    if original_FASTA_file:
        fasta_valid = io.check_FASTA(original_FASTA_file, omamerfile)
    else:
        fasta_valid = True

    if isoform_file:
        isoform_valid = io.check_isoform_file(isoform_file, omamerfile)
    else:
        isoform_valid = True

    if taxonomic_rank:
        taxonomic_rank = spd.check_rank(taxonomic_rank)
    else:
        taxonomic_rank = True

    return omamerfile_valid and database_valid and output_directory_valid and taxid_valid and fasta_valid and isoform_valid and taxonomic_rank

def launcher(args):
    omamerfile = args.file
    dbpath = args.database
    outdir = args.outputFolder
    taxid = args.taxid
    original_fasta = args.og_fasta
    isoform_file = args.isoform_file
    min_n_species = args.min_n_species
    taxonomic_rank = args.taxonomic_rank
    verbose = args.verbose
    only_conserved_HOGs = args.output_cHOGs
    ete_ncbi_db = args.ete_ncbi_db
    summarize_db = args.summarize_db
    log_level = 'INFO' if verbose else 'WARNING'
    set_log_level(log_level)
    LOG.info('Starting OMArk')
    if ete_ncbi_db is not None:
        LOG.info(f'A custom path was offered fot the ete3 NCBI database. {ete_ncbi_db} will be used.')
        spd.set_ete_taxa_path(ete_ncbi_db)
    if only_conserved_HOGs: 
        LOG.info('The option to output only conserved_HOGs was selected')
        if not taxid :
            LOG.error('A taxid must be provided for this use-case')
            sys.exit(1)
        if spd.check_taxid(taxid) and io.check_and_create_output_folder(outdir):
            get_only_conserved_HOGs(dbpath, outdir, taxid,taxonomic_rank=taxonomic_rank )
            LOG.info('Done')
        else:
            LOG.error('Exiting because one or more parameters are incorrect')
            sys.exit(1)
    elif summarize_db:
        LOG.info('The option to create a summary of the database content was selected. This can take a long time, please refer to the file available at https://omabrowser.org/oma/current/ if you are using the current LUCA DB.')
        if outils.check_database(dbpath) and io.check_and_create_output_folder(outdir):
            summarize_species_db(dbpath,os.path.join(outdir,"db_summary.omark.tsv"))
            LOG.info('Done')

        else:
            LOG.error('Exiting because one or more parameters are incorrect')
            sys.exit(1)
    elif check_parameters(omamerfile, dbpath, outdir,taxid,original_fasta,isoform_file,taxonomic_rank):
        LOG.info('Input parameters passed validity check')
        get_omamer_qscore(omamerfile, dbpath, outdir, taxid, original_FASTA_file = original_fasta, isoform_file=isoform_file,min_n_species = min_n_species, taxonomic_rank=taxonomic_rank)
        LOG.info('Done')

    else:
        LOG.error('Exiting because one or more parameters are incorrect')
        sys.exit(1)

