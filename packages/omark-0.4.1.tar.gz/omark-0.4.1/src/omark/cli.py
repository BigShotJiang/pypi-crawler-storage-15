'''
            OMArk - Quality assesment of coding-gene repertoire annotation
            (C) 2022 Yannis Nevers <yannis.nevers@unil.ch>
            This file is part of OMArk.
            OMArk is free software: you can redistribute it and/or modify
            it under the terms of the GNU Lesser General Public License as published by
            the Free Software Foundation, either version 3 of the License, or
            (at your option) any later version.
            OMArk is distributed in the hope that it will be useful,
            but WITHOUT ANY WARRANTY; without even the implied warranty of
            MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
            GNU Lesser General Public License for more details.
            You should have received a copy of the GNU Lesser General Public License
            along with OMArk. If not, see <http://www.gnu.org/licenses/>.
        '''

import argparse
from . import omark

def build_arg_parser():
    """Handle the parameter sent when executing the script from the terminal

    Returns
    -----------
    A parser object with the chosen option and parameters"""

    parser = argparse.ArgumentParser(description="Compute an OMA quality score from the OMAmer file of a proteome.")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('-f', '--file', type=str, help="Input OMAmer file - obtained as output from an OMAmer search.")    
    group.add_argument('-c', '--output_cHOGs', help='Switch OMArk mode to only computing a list of conserved HOGs and output it as list. Can be used to obtain a set of genes on which to train', action='store_true')
    group.add_argument('-s', '--summarize_db', help='Switch OMArk mode to summarize the clade content of the OMAmer DB (Number of species per clade, number of HOGs used,...). This mode will take a few hours to run. Refer to the data available' \
    'at https://omabrowser.org/oma/current/ if you are using the default database.', action='store_true')

    parser.add_argument('-d', '--database', type=str, help="The OMAmer database.", required=True)
    parser.add_argument('-t', '--taxid', type=int, help='Taxonomic identifier', default=None)
    parser.add_argument('-o', '--outputFolder', type=str, help="The folder containing output data the script wilp generate.", default="./omark_output/")
    parser.add_argument('-n', "--min_n_species", type=int, help="The minimal number of species in the database belonging to a clade to select it as an ancestral lineage", default=5)
    parser.add_argument('-r', '--taxonomic_rank', type=str, help='The narrowest taxonomic rank (genus, order, family...) that should be used as ancestral lineage.', default=None)
    parser.add_argument('-e', '--ete_ncbi_db', help='Path to the ete3 NCBI database to be used. Default will use the default location at ~/.etetoolkit/taxa.sqlite', default=None)

    parser.add_argument('-of', '--og_fasta', type=str, help='Original FASTA file', default=None)
    parser.add_argument('-i', '--isoform_file', type=str, help='A semi-colon separated file, listing all isoforoms of each genes, with one gene per line.', default=None)
    parser.add_argument('-v', '--verbose', help='Turn on logging information about OMArk process', action='store_true')


    return parser


def main():
    parser = build_arg_parser()  
    arg = parser.parse_args()
    omark.launcher(arg)
