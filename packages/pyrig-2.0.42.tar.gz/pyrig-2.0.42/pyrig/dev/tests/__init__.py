"""Test infrastructure for pyrig-based projects.

This package provides pytest fixtures, utilities, and configuration
for automated testing of pyrig projects.
"""
