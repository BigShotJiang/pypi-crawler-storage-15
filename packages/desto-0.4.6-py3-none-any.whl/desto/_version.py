"""Version information for desto package."""

__version__ = "0.4.6"
