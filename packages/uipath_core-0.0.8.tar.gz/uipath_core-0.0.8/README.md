# UiPath Core

Core abstractions and contracts for the UiPath Python SDK.
