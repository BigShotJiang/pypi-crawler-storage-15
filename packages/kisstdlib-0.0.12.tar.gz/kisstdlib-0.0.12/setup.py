#!/usr/bin/env python3
"""Setup."""
from setuptools import setup

setup()
