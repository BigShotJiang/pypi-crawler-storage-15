from .open_telemetry_service import configure_telemetry
