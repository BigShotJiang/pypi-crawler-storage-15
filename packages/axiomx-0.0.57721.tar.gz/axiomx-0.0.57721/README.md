# AxiomX 0.0.57721 - The Euler Mascheroni Edition

We are proud to release the Euler-Mascheroni Edition of AxiomX. This is one of the first version, where we add calculus to our library. Here are some of the functions added:

## Calculus
1. integrate(function, lowlim, uplim) - This function integrates a function from lowlim to uplim.
2. summation(lowlim, uplim, function) - This function sums an expression from lowlim to uplim.

## Number-Related
1. bernoulli(n) - This method returns the nth Bernoulli number.
2. stieltjes(n) - This method returns the nth Stieltjes number.

## Version

`0.0.57721`

## Implementation

```
import AxiomX as ax

print(ax.sin(ax.pi / 2))
```

## Notes
We have included the number-related functions only for the Euler-Mascheroni Edition. These methods will be deprecated from the next release.