import requests

def _download_and_parse_mesh_tree(mesh_url = "https://nlmpubs.nlm.nih.gov/projects/mesh/MESH_FILES/asciimesh/d2025.bin") -> dict:
    """
    Download and parse the MeSH (Medical Subject Headings) tree structure from NLM.
    This function downloads the MeSH ASCII file from the National Library of Medicine
    and parses it to extract the hierarchical tree structure that relates medical terms
    to their tree numbers.
    :param mesh_url: URL to the MeSH ASCII file. Defaults to the 2025 descriptor file
                    from nlmpubs.nlm.nih.gov
    :type mesh_url: str, optional
    :return: Dictionary mapping MeSH headings to their corresponding tree numbers.
            Each heading maps to a list of tree number strings that represent its
            position(s) in the MeSH hierarchy. Returns an empty dictionary if the
            download or parsing fails.
    :rtype: dict
    :raises: Does not raise exceptions; prints warnings and returns empty dict on failure
    .. note::
    The MeSH ASCII file format contains records with lines prefixed by:
    - 'MH = ' for MeSH Headings (medical terms)
    - 'MN = ' for Tree Numbers (hierarchical classifications)
    - 'ENTRY' or '*NEWRECORD' to mark record boundaries
    .. example::
    >>> mesh_tree = _download_and_parse_mesh_tree()
    Downloading MeSH tree structure from https://nlmpubs.nlm.nih.gov/...
    MeSH tree loaded: 30000 headings
    >>> mesh_tree['Aspirin']
    ['D02.886.590.159', 'D26.255.260']
    """
    print(f"Downloading MeSH tree structure from {mesh_url}...")
    
    try:
        response = requests.get(mesh_url, timeout=60)
        response.raise_for_status()
        
        # Parse the MeSH ASCII file
        mesh_tree = {}
        current_heading = None
        current_trees = []
        
        for line in response.text.split('\n'):
            line = line.strip()
            
            # MH = MeSH Heading
            if line.startswith('MH = '):
                current_heading = line[5:].strip()
                current_trees = []
            
            # MN = Tree Number
            elif line.startswith('MN = '):
                tree_num = line[5:].strip()
                current_trees.append(tree_num)
            
            # Entry = end of record, store the data
            elif line.startswith('ENTRY') or line.startswith('*NEWRECORD'):
                if current_heading and current_trees:
                    mesh_tree[current_heading] = current_trees
                    current_heading = None
                    current_trees = []
        
        print(f"MeSH tree loaded: {len(mesh_tree)} headings")
        return mesh_tree
        
    except Exception as e:
        print(f"Warning: Could not download MeSH tree: {e}")
        return {}

def descendants(mesh_heading: str) -> list:
    """
    Get all descendant MeSH headings for a given MeSH heading in the hierarchy.
    This function traverses the MeSH tree structure to find all headings that are
    descendants of the specified MeSH heading, based on their tree number hierarchy.
    A descendant is any heading whose tree number starts with the parent's tree number
    followed by a dot.
    :param mesh_heading: The MeSH heading for which to find descendants.
    :type mesh_heading: str
    :returns: List of MeSH headings including the original heading and all its
              descendants in the hierarchy. If the heading is not found in the tree,
              returns a list containing only the original heading.
    :rtype: list
    :Example:
    >>> mesh_tree = {
    ...     "Diseases": ["C"],
    ...     "Infections": ["C01"],
    ...     "Bacterial Infections": ["C01.252"]
    ... }
    >>> descendants(mesh_tree, "Infections")
    Found 2 MeSH headings for 'Infections' (including all descendants)
    ['Infections', 'Bacterial Infections']
    .. note::
       The function prints diagnostic information about tree numbers found and
       the total count of descendants.
    """
    # Get the full tree info (headings with their tree numbers)
    full_tree = _download_and_parse_mesh_tree()
    
    # Get tree numbers for the requested heading
    parent_trees = full_tree.get(mesh_heading)
    if not parent_trees:
        print(f"No tree numbers found for '{mesh_heading}', using exact match only")
        return [mesh_heading]
    
    print(f"Tree numbers for '{mesh_heading}': {parent_trees}")
    
    # Find all descendants recursively based on tree number hierarchy
    descendants = set([mesh_heading])
    
    # Check all headings to see if any of their tree numbers are descendants
    for heading, tree_nums in full_tree.items():
        for tree_num in tree_nums:
            # Check if this tree number is under any of the parent tree numbers
            for parent_tree in parent_trees:
                if tree_num.startswith(parent_tree + '.'):
                    descendants.add(heading)
                    break
    
    result = list(descendants)
    print(f"Found {len(result)} MeSH headings for '{mesh_heading}' (including all descendants)")
    return result

# run when file is directly executed
if __name__ == '__main__': 
   # Save the parsed tree structure
   import pickle
   from subprocess import run
   mesh_tree = _download_and_parse_mesh_tree()
   with open('d2025.pkl', 'wb') as f:
       pickle.dump(mesh_tree, f)
   print("Uploading MeSH tree to S3...")
   run(['aws', 's3', 'cp', 'd2025.pkl', 's3://alethiotx-artemis/data/mesh/d2025.pkl'])
   print("MeSH tree uploaded to S3")
   
   print("Testing descendants function...")
   dscndnts = descendants('Breast Neoplasms')
   print("Descendants of 'Breast Neoplasms':")
   print(dscndnts)