from pandas import DataFrame, merge, read_csv
from datetime import date
from numpy import sum
from ..mesh.get import descendants as mesh_descendants

def compute(mesh_heading = 'Breast Neoplasms', chembl_version = '36', trials_only_last_n_years = None) -> DataFrame:
   """
   Compute clinical scores for drug targets across different disease indications.
   This function retrieves clinical trial data from ChEMBL, processes it to calculate
   clinical scores based on trial phases, and identifies approved targets. The clinical
   score is calculated as the sum of phase numbers (excluding phase 4) plus a bonus of
   20 points for approved drugs.
   :param chembl_version: Version of ChEMBL database to use, defaults to '36'
   :type chembl_version: str, optional
   :param trials_only_last_n_years: If specified, filters trials to only include those
      from the last N years. If None, includes all trials, defaults to None
   :type trials_only_last_n_years: int, optional
   :return: DataFrame containing clinical scores with columns:
      - mesh_heading: Disease indication (MeSH heading)
      - target_gene_name: Gene name of the drug target
      - phase_scores: Sum of clinical trial phases (excluding phase 4)
      - approved: Boolean indicating if target has at least one phase 4 (approved) trial
      - clinical_scores: Total clinical score (phase_scores + 20 if approved)
   :rtype: DataFrame
   :raises: May raise exceptions related to S3 access or CSV file operations
   """
   d = read_csv(f's3://alethiotx-artemis/data/chembl/{chembl_version}/all_molecules.csv')
   # select only recent trials
   if trials_only_last_n_years is not None:
      current_year = int(date.today().strftime("%Y"))
      d = d[d['trial_year'] >= current_year - trials_only_last_n_years]
   # identify targets that have been approved (phase 4) in at least one clinical trial per mesh_heading
   approved = d.groupby(['mesh_heading', 'target_gene_name'])['phase'].apply(lambda x: True if (x == 4).any() else False).reset_index()
   approved.rename(columns = {'phase': 'approved'}, inplace=True)
   # compute clinical scores as sum of phase numbers (except 4) + 20 for approved drugs
   phase_scores = d.groupby(['mesh_heading', 'target_gene_name'])['phase'].apply(lambda x: x[x != 4].sum()).reset_index()
   phase_scores.rename(columns = {'phase': 'phase_scores'}, inplace=True)
   res = merge(phase_scores, approved)
   # filter by mesh heading and all descendants in the MeSH tree
   mesh_headings = mesh_descendants(mesh_heading)
   print(f"Including MeSH headings: {mesh_headings}")
   res = res[res['mesh_heading'].isin(mesh_headings)].reset_index(drop=True)
   # compute final clinical scores
   # sum up phase scores across all mesh headings per target
   approved = res.groupby(['target_gene_name'])['approved'].apply(lambda x: True if x.any() else False).reset_index()
   phase_scores = res.groupby(['target_gene_name'])['phase_scores'].apply(sum).reset_index()
   res1 = merge(phase_scores, approved)
   res1['clinical_scores'] = res1['phase_scores'] + 20 * res1['approved'].astype(int)
   res1.sort_values('clinical_scores', ascending=False, inplace=True)

   return(res1)

def load(date = '2025-11-11'):
   """
   Retrieve clinical scores for multiple disease types from S3 storage.

   This function reads CSV files containing clinical target data for various diseases
   from an S3 bucket, organized by date.

   :param date: The date string used to construct the S3 file paths, defaults to ``2025-11-11``
   :type date: str, optional
   :return: A tuple containing DataFrames for breast, lung, prostate, melanoma, bowel,
            diabetes, and cardiovascular clinical scores (in that order)
   :rtype: tuple of pandas.DataFrame
   :raises FileNotFoundError: If any of the CSV files do not exist at the specified S3 paths
   :raises ValueError: If the CSV files cannot be parsed correctly

   .. note::

      All CSV files are expected to be located in the S3 bucket at:
      ``s3://alethiotx-artemis/data/clinical_scores/{date}/{disease}.csv``

   .. warning::

      Ensure data exists
      for the specified date before calling this function.

   **Example**
   >>> breast, lung, prostate, melanoma, bowel, diabetes, cardio = load_clinical_scores('2025-11-11')
   >>> print(breast.shape)
   (100, 5)
   """
   breast = read_csv("s3://alethiotx-artemis/data/clinical_scores/" + date + "/breast.csv")
   lung = read_csv("s3://alethiotx-artemis/data/clinical_scores/" + date + "/lung.csv")
   prostate = read_csv("s3://alethiotx-artemis/data/clinical_scores/" + date + "/prostate.csv")
   melanoma = read_csv("s3://alethiotx-artemis/data/clinical_scores/" + date + "/melanoma.csv")
   bowel = read_csv("s3://alethiotx-artemis/data/clinical_scores/" + date + "/bowel.csv")
   diabetes = read_csv("s3://alethiotx-artemis/data/clinical_scores/" + date + "/diabetes.csv")
   cardiovascular = read_csv("s3://alethiotx-artemis/data/clinical_scores/" + date + "/cardiovascular.csv")

   return(breast, lung, prostate, melanoma, bowel, diabetes, cardiovascular)

# run when file is directly executed
if __name__ == '__main__':
   # d = compute('Breast Neoplasms', chembl_version='36', trials_only_last_n_years=6)
   # d.to_csv("breast.csv", index=False)

   # d = compute('Intestinal Neoplasms', chembl_version='36', trials_only_last_n_years=6)
   # d.to_csv("intestinal.csv", index=False)

   # d = compute('Lung Neoplasms', chembl_version='36', trials_only_last_n_years=6)
   # d.to_csv("lung.csv", index=False)

   # d = compute('Skin Neoplasms', chembl_version='36', trials_only_last_n_years=6)
   # d.to_csv("skin.csv", index=False)

   # d = compute('Prostatic Neoplasms', chembl_version='36', trials_only_last_n_years=6)
   # d.to_csv("prostate.csv", index=False)

   # d = compute('Diabetes Mellitus, Type 2', chembl_version='36', trials_only_last_n_years=6)
   # d.to_csv("diabetes.csv", index=False)

   d = compute('Cardiovascular Diseases', chembl_version='36', trials_only_last_n_years=6)
   d.to_csv("cardiovascular.csv", index=False)

   # print("\nLoading clinical scores for multiple diseases from S3:")
   # breast, lung, prostate, melanoma, bowel, diabetes, cardiovascular = load('2025-11-11')
   # print("Clinical scores loaded:")
   # print(breast)
   # print(lung)
   # print(prostate)
   # print(melanoma)
   # print(bowel)
   # print(diabetes)
   # print(cardiovascular)