from exasol.ai.mcp.server.main import mcp_server
