from .inference import Autoencoder
from .inference import Autoencoder as AutoencoderInferenceModel
