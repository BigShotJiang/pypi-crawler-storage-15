from linear_cae.components.diffusion import Diffusion
from linear_cae.components.generator import UNet