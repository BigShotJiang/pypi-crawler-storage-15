"""
Copyright (c) 2023 Henry Schreiner. All rights reserved.

check-sdist: Check the contents of an SDist vs. git
"""

from __future__ import annotations

__version__ = "1.3.1"

__all__ = ["__version__"]
