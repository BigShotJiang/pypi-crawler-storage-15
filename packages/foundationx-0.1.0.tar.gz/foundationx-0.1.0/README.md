# FoundationX Bootstrap

Bootstrap functions for the FoundationX Commercial software
