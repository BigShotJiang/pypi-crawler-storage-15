---
name: Security bug report
about: How to report security vulnerabilities
---

For all security related bugs, email security@ansible.com instead of using this issue tracker and you will receive a prompt response.

For more information, see https://docs.ansible.com/projects/ansible/latest/community/reporting_bugs_and_features.html
