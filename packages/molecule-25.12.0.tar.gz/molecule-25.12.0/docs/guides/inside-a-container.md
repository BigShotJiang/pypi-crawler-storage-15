## Running inside a container

Molecule is built into a Docker image by the [Ansible Dev Tools](https://docs.ansible.com/projects/dev-tools/container/) project.

Any questions or bugs related to use of Molecule from within a container
should be addressed by the Ansible Dev Tools
project.
