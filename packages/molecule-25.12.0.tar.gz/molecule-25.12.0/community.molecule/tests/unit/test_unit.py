"""Collection unit tests."""  # noqa: INP001

from __future__ import annotations


def test_foo() -> None:
    """Sample test."""
