"""Collection integration tests."""  # noqa: INP001

from __future__ import annotations


def test_integration() -> None:
    """Sample integration test."""
