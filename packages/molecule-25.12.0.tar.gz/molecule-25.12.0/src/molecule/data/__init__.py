"""Module containing molecule data files."""
