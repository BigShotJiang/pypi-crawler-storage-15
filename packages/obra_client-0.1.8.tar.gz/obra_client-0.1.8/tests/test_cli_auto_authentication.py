"""
Regression tests for ISSUE-SAAS-004: CLI commands should auto-exchange tokens.

This test verifies that CLI commands (orchestrate, status, resume, version)
automatically exchange license keys for auth tokens when:
1. No auth_token exists in config
2. auth_token has expired

Before fix: CLI commands create APIClient() directly, passing auth_token=None
After fix: CLI commands use APIClient.from_config() which auto-exchanges

Related:
- ISSUE-SAAS-004: License key exchange fails with 500 error and orchestrate CLI bypasses automatic token exchange
- docs/quality/investigations/ISSUE-SAAS-004_RCA.md
"""

import pytest
from unittest.mock import patch, MagicMock, mock_open
from pathlib import Path
import yaml
from datetime import datetime, timedelta
from click.exceptions import Exit as ClickExit

# This test should FAIL before fix (commands use constructor)
# This test should PASS after fix (commands use from_config)


class TestCLIAutoAuthentication:
    """Test CLI commands automatically exchange license keys for auth tokens."""

    @pytest.fixture
    def fresh_config_no_token(self, tmp_path):
        """Config with license_key but no auth_token (fresh setup scenario)."""
        config = {
            "api_base_url": "https://us-central1-obra-205b0.cloudfunctions.net",
            "license_key": "OBRA-test-license-key",
            "user_id": "test_user",
            # No auth_token - this is the fresh setup scenario
        }
        config_path = tmp_path / "client-config.yaml"
        with open(config_path, 'w') as f:
            yaml.dump(config, f)
        return config_path

    @pytest.fixture
    def expired_token_config(self, tmp_path):
        """Config with expired auth_token."""
        yesterday = datetime.now() - timedelta(days=1)
        config = {
            "api_base_url": "https://us-central1-obra-205b0.cloudfunctions.net",
            "license_key": "OBRA-test-license-key",
            "user_id": "test_user",
            "auth_token": "expired_token_12345",
            "token_expires_at": yesterday.isoformat()
        }
        config_path = tmp_path / "client-config.yaml"
        with open(config_path, 'w') as f:
            yaml.dump(config, f)
        return config_path

    def test_issue_saas_004_orchestrate_auto_exchanges_token_on_fresh_config(self, fresh_config_no_token):
        """
        REGRESSION TEST for ISSUE-SAAS-004 (Issue #2)

        Verify that the orchestrate command automatically exchanges license key
        for auth token when auth_token is missing from config.

        BEFORE FIX: orchestrate uses APIClient() constructor directly
        - Passes auth_token=None
        - Results in 401 Unauthorized error
        - User must manually exchange token

        AFTER FIX: orchestrate uses APIClient.from_config()
        - Detects missing auth_token
        - Automatically calls exchange_license_key()
        - Saves token to config
        - Subsequent API calls succeed
        """
        from obra_client.cli import orchestrate
        from obra_client.api_client import APIClient

        # Mock APIClient.from_config to verify it's called (after fix)
        # Before fix, this won't be called - APIClient() constructor will be used instead
        with patch('obra_client.cli.APIClient.from_config') as mock_from_config, \
             patch('obra_client.cli.require_config') as mock_require_config, \
             patch('obra_client.cli.require_terms_accepted') as mock_terms, \
             patch('obra_client.cli.PromptEnricher'), \
             patch('obra_client.cli.ClaudeCodeExecutor'), \
             patch('obra_client.cli.SessionManager'), \
             patch('obra_client.cli.console'):

            # Setup mocks
            with open(fresh_config_no_token) as f:
                config = yaml.safe_load(f)
            mock_require_config.return_value = config

            # Create mock client with exchange capability
            mock_client = MagicMock()
            mock_client.orchestrate.return_value = {
                "session_id": "test_session_123",
                "base_prompt": "Test prompt",  # CLI expects base_prompt, not strategic_prompt
                "status": "active",
                "metadata": {},
            }
            mock_from_config.return_value = mock_client

            # Call orchestrate command
            try:
                orchestrate(
                    objective="Create a test feature",
                    project_dir="/tmp/test",
                    task_type="feature"
                )
            except (SystemExit, ClickExit):
                # Command may exit after first step, that's OK for this test
                pass

            # VERIFICATION: After fix, from_config should be called
            # Before fix, this assertion will FAIL because constructor is used instead
            mock_from_config.assert_called_once()

            # The from_config method should have automatically exchanged the license key
            # and the client should be ready to make authenticated API calls

    def test_issue_saas_004_orchestrate_constructor_bypass_fails(self, fresh_config_no_token):
        """
        VERIFICATION TEST: Direct constructor usage (buggy pattern) should fail.

        This test demonstrates the bug: when using APIClient() constructor directly
        with a config that has no auth_token, the client cannot make authenticated calls.
        """
        from obra_client.api_client import APIClient

        with open(fresh_config_no_token) as f:
            config = yaml.safe_load(f)

        # BUGGY PATTERN (current code before fix):
        # api_client = APIClient(
        #     base_url=config["api_base_url"],
        #     auth_token=config.get("auth_token"),  # None!
        # )

        client = APIClient(
            base_url=config["api_base_url"],
            auth_token=config.get("auth_token")  # This is None
        )

        # Verify that auth_token is indeed None (fresh config)
        assert client.auth_token is None

        # This client will fail authenticated API calls with 401 errors
        # because it has no auth_token and didn't auto-exchange

    def test_issue_saas_004_status_command_auto_exchanges(self, fresh_config_no_token):
        """Verify status command uses from_config (after fix)."""
        from obra_client.cli import status

        with patch('obra_client.cli.APIClient.from_config') as mock_from_config, \
             patch('obra_client.cli.require_config') as mock_require_config, \
             patch('obra_client.cli.require_terms_accepted') as mock_terms, \
             patch('obra_client.cli.console'):

            with open(fresh_config_no_token) as f:
                config = yaml.safe_load(f)
            mock_require_config.return_value = config

            mock_client = MagicMock()
            mock_client.get_status.return_value = {
                "session_id": "test_123",
                "status": "running",
                "current_iteration": 1,
                "objective": "Test objective",
                "task_type": "feature",
            }
            mock_from_config.return_value = mock_client

            try:
                status(session_id="test_123")
            except (SystemExit, ClickExit):
                pass

            # After fix, should use from_config
            mock_from_config.assert_called_once()

    def test_issue_saas_004_version_command_auto_exchanges(self, fresh_config_no_token):
        """Verify version command uses from_config (after fix)."""
        from obra_client.cli import version

        with patch('obra_client.cli.APIClient.from_config') as mock_from_config, \
             patch('obra_client.cli.require_config') as mock_require_config, \
             patch('obra_client.cli.require_terms_accepted') as mock_terms, \
             patch('obra_client.cli.console'):

            with open(fresh_config_no_token) as f:
                config = yaml.safe_load(f)
            mock_require_config.return_value = config

            mock_client = MagicMock()
            mock_client.get_version.return_value = {
                "api_version": "1.0.0",
                "min_client_version": "0.1.0",
                "features": ["orchestrate", "resume"],
            }
            mock_from_config.return_value = mock_client

            try:
                version()
            except (SystemExit, ClickExit):
                pass

            # After fix, should use from_config
            mock_from_config.assert_called_once()

    def test_issue_saas_004_expired_token_auto_refresh(self, expired_token_config):
        """
        Verify that from_config auto-refreshes expired tokens.

        This tests the second part of the auto-exchange logic:
        not just missing tokens, but also expired tokens.
        """
        from obra_client.api_client import APIClient

        with patch.object(APIClient, 'exchange_license_key') as mock_exchange:
            mock_exchange.return_value = None  # exchange_license_key updates client state

            # Use from_config with expired token
            client = APIClient.from_config(expired_token_config)

            # Verify exchange_license_key was called to refresh
            mock_exchange.assert_called_once_with("OBRA-test-license-key")
