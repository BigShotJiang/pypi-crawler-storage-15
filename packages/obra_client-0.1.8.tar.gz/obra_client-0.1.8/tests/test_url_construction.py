"""Tests for API client URL construction (ISSUE-SAAS-003 regression prevention).

Validates that urljoin() behavior works correctly with both production URLs
(no path component) and emulator URLs (with path component).
"""

from urllib.parse import urljoin

import pytest


class TestURLConstruction:
    """Verify URL construction for production and emulator environments."""

    def test_production_url_construction(self):
        """Production URLs should work with or without leading slash."""
        base_url = "https://us-central1-obra-205b0.cloudfunctions.net"

        # Without leading slash (preferred)
        result = urljoin(base_url, "health")
        assert result == "https://us-central1-obra-205b0.cloudfunctions.net/health"

        # With leading slash (works but deprecated)
        result = urljoin(base_url, "/health")
        assert result == "https://us-central1-obra-205b0.cloudfunctions.net/health"

    def test_emulator_url_construction_without_leading_slash(self):
        """Emulator URLs REQUIRE endpoints without leading slash AND trailing slash on base."""
        # Base URL MUST end with trailing slash for urljoin() to work correctly
        base_url = "http://localhost:5001/obra-205b0/us-central1/"

        # WITHOUT leading slash - CORRECT ✅
        result = urljoin(base_url, "health")
        assert result == "http://localhost:5001/obra-205b0/us-central1/health"

        result = urljoin(base_url, "version")
        assert result == "http://localhost:5001/obra-205b0/us-central1/version"

        result = urljoin(base_url, "orchestrate")
        assert result == "http://localhost:5001/obra-205b0/us-central1/orchestrate"

        result = urljoin(base_url, "exchange_license_key")
        assert result == "http://localhost:5001/obra-205b0/us-central1/exchange_license_key"

    def test_emulator_url_construction_with_leading_slash_fails(self):
        """Emulator URLs with leading slash endpoints STRIP the path (bug)."""
        base_url = "http://localhost:5001/obra-205b0/us-central1"

        # WITH leading slash - WRONG ❌ (demonstrates the bug)
        result = urljoin(base_url, "/health")
        # Path component is STRIPPED!
        assert result == "http://localhost:5001/health"  # WRONG but expected behavior

        # This is why we MUST NOT use leading slashes with emulator URLs
        assert result != "http://localhost:5001/obra-205b0/us-central1/health"

    def test_all_api_client_endpoints_have_no_leading_slash(self):
        """Verify all endpoints in APIClient use correct format (no leading slash).

        This is a regression test for ISSUE-SAAS-003.
        """
        # Read the api_client.py file
        import inspect
        from pathlib import Path

        client_file = Path(__file__).parent.parent / "obra_client" / "api_client.py"
        source = client_file.read_text()

        # Check for endpoint definitions with leading slash
        # Pattern: endpoint="/<something>"
        import re

        pattern = r'endpoint\s*=\s*["\']\/[^"\']*["\']'
        matches = re.findall(pattern, source)

        if matches:
            pytest.fail(
                f"Found {len(matches)} endpoint(s) with leading slash:\n"
                + "\n".join(f"  - {m}" for m in matches)
                + "\n\nEndpoints should NOT have leading slashes to work with Firebase emulator."
            )

    def test_rfc3986_urljoin_behavior(self):
        """Document RFC 3986 behavior for URL resolution.

        This test serves as documentation for why leading slashes cause issues.
        """
        base = "http://example.com/path/to/resource"

        # Relative URL (no leading slash) - APPENDS to base path
        assert urljoin(base, "endpoint") == "http://example.com/path/to/endpoint"

        # Absolute path (leading slash) - REPLACES base path
        assert urljoin(base, "/endpoint") == "http://example.com/endpoint"

        # This is RFC 3986 compliant behavior, NOT a Python bug
        # See: https://datatracker.ietf.org/doc/html/rfc3986#section-5.2.2


class TestAPIClientURLConstruction:
    """Integration tests for APIClient URL construction."""

    def test_api_client_constructs_correct_urls_for_emulator(self):
        """APIClient should construct correct URLs for Firebase emulator."""
        from obra_client.api_client import APIClient

        # Create client with emulator base URL
        client = APIClient(
            base_url="http://localhost:5001/obra-205b0/us-central1",
            auth_token="test-token",
        )

        # Test that base_url is stored correctly (trailing slash added)
        assert client.base_url == "http://localhost:5001/obra-205b0/us-central1/"

        # Test URL construction via _request (without actually making requests)
        # We'll verify the URL construction logic directly
        from unittest.mock import MagicMock, patch

        with patch.object(client.session, "request") as mock_request:
            # Configure mock to return 200 with empty JSON
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_response.json.return_value = {"status": "healthy"}
            mock_request.return_value = mock_response

            # Call health_check (uses "health" endpoint)
            try:
                client.health_check()
            except Exception:
                pass  # We don't care if it fails, just want to check URL

            # Verify the URL was constructed correctly
            call_args = mock_request.call_args
            actual_url = call_args[1]["url"]
            expected_url = "http://localhost:5001/obra-205b0/us-central1/health"

            assert actual_url == expected_url, (
                f"URL construction failed!\n"
                f"  Expected: {expected_url}\n"
                f"  Actual:   {actual_url}"
            )

    def test_api_client_constructs_correct_urls_for_production(self):
        """APIClient should construct correct URLs for production."""
        from obra_client.api_client import APIClient

        # Create client with production base URL
        client = APIClient(
            base_url="https://us-central1-obra-205b0.cloudfunctions.net",
            auth_token="test-token",
        )

        assert client.base_url == "https://us-central1-obra-205b0.cloudfunctions.net/"

        from unittest.mock import MagicMock, patch

        with patch.object(client.session, "request") as mock_request:
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_response.json.return_value = {"api_version": "0.1.0"}
            mock_request.return_value = mock_response

            try:
                client.get_version()
            except Exception:
                pass

            call_args = mock_request.call_args
            actual_url = call_args[1]["url"]
            expected_url = "https://us-central1-obra-205b0.cloudfunctions.net/version"

            assert actual_url == expected_url
