"""LLM proxy executor for invoking Claude Code CLI with enriched prompts.

Provides flexible CLI invocation with automatic capability detection,
supporting both file-based prompts and stdin-based prompts.
"""

import json
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import List, Literal, Optional

from obra_client.exceptions import ExecutionError


@dataclass
class ExecutionResult:
    """Result from LLM execution.

    Attributes:
        stdout: Standard output from LLM
        stderr: Standard error output
        exit_code: Process exit code (0 = success)
        success: Whether execution was successful
        output_format: Format of output ("json" or "text")
        parsed_output: Parsed JSON output (if output_format="json")
    """

    stdout: str
    stderr: str
    exit_code: int
    success: bool
    output_format: Literal["json", "text"]
    parsed_output: Optional[dict]


class ClaudeCodeExecutor:
    """Executor for Claude Code CLI with flexible invocation patterns.

    Automatically detects available CLI capabilities and uses the best
    available method:
    1. File-based with JSON output (preferred)
    2. Stdin-based with text output (fallback)

    Example:
        executor = ClaudeCodeExecutor()
        result = executor.execute(
            prompt="Enriched prompt here",
            working_dir="/home/user/myproject"
        )
        if result.success:
            print(result.stdout)
    """

    def __init__(
        self,
        claude_code_path: Optional[str] = None,
        timeout: int = 600,
    ) -> None:
        """Initialize ClaudeCodeExecutor.

        Args:
            claude_code_path: Path to claude-code binary (auto-detected if None)
            timeout: Execution timeout in seconds (default: 10 minutes)
        """
        self.claude_code_path = claude_code_path or self._find_claude_code()
        self.timeout = timeout
        self.capabilities = self._detect_capabilities()

    def execute(
        self,
        prompt: str,
        working_dir: str | Path,
        timeout: Optional[int] = None,
    ) -> ExecutionResult:
        """Execute Claude Code with enriched prompt.

        Args:
            prompt: Enriched prompt (strategic + tactical context)
            working_dir: Project working directory
            timeout: Optional timeout override (seconds)

        Returns:
            ExecutionResult with output and metadata

        Raises:
            ExecutionError: If execution fails critically
        """
        timeout = timeout or self.timeout
        working_path = Path(working_dir).resolve()

        if not working_path.exists():
            raise ExecutionError(f"Working directory does not exist: {working_dir}")

        # Use best available invocation method
        if self.capabilities["file_based"] and self.capabilities["json_output"]:
            return self._execute_file_based_json(prompt, working_path, timeout)
        elif self.capabilities["stdin_based"]:
            return self._execute_stdin_based(prompt, working_path, timeout)
        else:
            raise ExecutionError(
                "Claude Code CLI does not support any known invocation method"
            )

    def _execute_file_based_json(
        self,
        prompt: str,
        working_dir: Path,
        timeout: int,
    ) -> ExecutionResult:
        """Execute using file-based prompt with JSON output (preferred).

        Args:
            prompt: Enriched prompt
            working_dir: Working directory
            timeout: Timeout in seconds

        Returns:
            ExecutionResult
        """
        # Create temporary file for prompt
        with tempfile.NamedTemporaryFile(
            mode="w",
            suffix=".txt",
            delete=False,
            encoding="utf-8",
        ) as f:
            f.write(prompt)
            prompt_file = f.name

        try:
            # Execute with prompt file
            result = subprocess.run(
                [
                    self.claude_code_path,
                    "--dangerously-skip-permissions",
                    "--prompt-file",
                    prompt_file,
                    "--output-format",
                    "json",
                ],
                cwd=working_dir,
                capture_output=True,
                text=True,
                timeout=timeout,
            )

            # Parse JSON output
            parsed_output = None
            if result.stdout:
                try:
                    parsed_output = json.loads(result.stdout)
                except json.JSONDecodeError:
                    # Invalid JSON - treat as text
                    pass

            return ExecutionResult(
                stdout=result.stdout,
                stderr=result.stderr,
                exit_code=result.returncode,
                success=result.returncode == 0,
                output_format="json" if parsed_output else "text",
                parsed_output=parsed_output,
            )

        except subprocess.TimeoutExpired as e:
            raise ExecutionError(
                f"Claude Code execution timed out after {timeout}s",
                exit_code=-1,
                stderr=str(e),
            ) from e

        except Exception as e:
            raise ExecutionError(
                f"Claude Code execution failed: {e}",
                exit_code=-1,
                stderr=str(e),
            ) from e

        finally:
            # Clean up prompt file
            try:
                Path(prompt_file).unlink()
            except Exception:
                pass

    def _execute_stdin_based(
        self,
        prompt: str,
        working_dir: Path,
        timeout: int,
    ) -> ExecutionResult:
        """Execute using stdin-based prompt (fallback).

        Args:
            prompt: Enriched prompt
            working_dir: Working directory
            timeout: Timeout in seconds

        Returns:
            ExecutionResult
        """
        try:
            result = subprocess.run(
                [self.claude_code_path, "--dangerously-skip-permissions"],
                input=prompt,
                cwd=working_dir,
                capture_output=True,
                text=True,
                timeout=timeout,
            )

            return ExecutionResult(
                stdout=result.stdout,
                stderr=result.stderr,
                exit_code=result.returncode,
                success=result.returncode == 0,
                output_format="text",
                parsed_output=None,
            )

        except subprocess.TimeoutExpired as e:
            raise ExecutionError(
                f"Claude Code execution timed out after {timeout}s",
                exit_code=-1,
                stderr=str(e),
            ) from e

        except Exception as e:
            raise ExecutionError(
                f"Claude Code execution failed: {e}",
                exit_code=-1,
                stderr=str(e),
            ) from e

    def _find_claude_code(self) -> str:
        """Find Claude Code CLI binary in PATH.

        Returns:
            Path to claude-code binary

        Raises:
            ExecutionError: If claude-code not found
        """
        # Common binary names
        binary_names = ["claude-code", "claude", "ccode"]

        for name in binary_names:
            try:
                result = subprocess.run(
                    ["which", name],
                    capture_output=True,
                    text=True,
                    timeout=5,
                )

                if result.returncode == 0:
                    return result.stdout.strip()

            except (subprocess.TimeoutExpired, FileNotFoundError):
                continue

        raise ExecutionError(
            "Claude Code CLI not found in PATH. "
            "Please install Claude Code or specify path in config."
        )

    def _detect_capabilities(self) -> dict[str, bool]:
        """Detect Claude Code CLI capabilities.

        Returns:
            Dictionary of capability flags:
            - file_based: Supports --prompt-file
            - json_output: Supports --output-format json
            - stdin_based: Supports stdin input
        """
        capabilities = {
            "file_based": False,
            "json_output": False,
            "stdin_based": False,
        }

        try:
            # Check help output for supported flags
            result = subprocess.run(
                [self.claude_code_path, "--help"],
                capture_output=True,
                text=True,
                timeout=10,
            )

            help_text = result.stdout + result.stderr

            # Check for flags
            if "--prompt-file" in help_text:
                capabilities["file_based"] = True

            if "--output-format" in help_text:
                capabilities["json_output"] = True

            # Assume stdin is always available (fallback)
            capabilities["stdin_based"] = True

        except Exception:
            # If we can't detect, assume basic stdin capability
            capabilities["stdin_based"] = True

        return capabilities

    def get_version(self) -> Optional[str]:
        """Get Claude Code CLI version.

        Returns:
            Version string if available, None otherwise
        """
        try:
            result = subprocess.run(
                [self.claude_code_path, "--version"],
                capture_output=True,
                text=True,
                timeout=5,
            )

            if result.returncode == 0:
                return result.stdout.strip()

        except Exception:
            pass

        return None
