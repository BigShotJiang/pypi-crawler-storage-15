"""Error tracker utility for parsing error logs and extracting recent errors.

Provides error detection from common log files for prompt enrichment
(Tier 2 context injection).
"""

import re
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import List, Optional


@dataclass
class ErrorInfo:
    """Information about a detected error.

    Attributes:
        message: Error message or exception text
        error_type: Type of error (e.g., "ValueError", "AttributeError")
        location: File and line number where error occurred (if available)
        timestamp: When error was detected
        context_lines: Surrounding lines for context
        minutes_ago: Minutes since error occurred
    """

    message: str
    error_type: Optional[str]
    location: Optional[str]
    timestamp: datetime
    context_lines: List[str]
    minutes_ago: float


class ErrorTracker:
    """Tracks recent errors from log files.

    Parses common log formats (Python tracebacks, pytest output, etc.)
    to extract error information for prompt enrichment.

    Example:
        tracker = ErrorTracker()
        recent_errors = tracker.get_recent_errors(
            project_dir="/home/user/myproject",
            since_minutes=30
        )
        for error in recent_errors:
            print(f"{error.error_type}: {error.message}")
    """

    # Common log file patterns to search
    DEFAULT_LOG_PATTERNS = [
        "*.log",
        "stderr.log",
        "error.log",
        "app.log",
        "test.log",
        "pytest.log",
        ".pytest_cache/v/cache/lastfailed",
    ]

    # Regex patterns for error detection
    PYTHON_ERROR_PATTERN = re.compile(
        r"^(?P<error_type>\w+Error|Exception):\s*(?P<message>.+)$", re.MULTILINE
    )

    PYTHON_TRACEBACK_PATTERN = re.compile(
        r'File "(?P<file>[^"]+)", line (?P<line>\d+)', re.MULTILINE
    )

    PYTEST_FAILED_PATTERN = re.compile(r"FAILED (?P<test>[\w/:.]+) - (?P<reason>.+)")

    def __init__(self, log_patterns: List[str] | None = None) -> None:
        """Initialize ErrorTracker.

        Args:
            log_patterns: Custom log file patterns (merged with defaults)
        """
        self.log_patterns = self.DEFAULT_LOG_PATTERNS.copy()
        if log_patterns:
            self.log_patterns.extend(log_patterns)

    def get_recent_errors(
        self,
        project_dir: str | Path,
        since_minutes: int = 30,
        max_errors: int = 10,
    ) -> List[ErrorInfo]:
        """Get errors from log files within the last N minutes.

        Args:
            project_dir: Project root directory to scan for log files
            since_minutes: Look back window in minutes (default: 30)
            max_errors: Maximum number of errors to return (default: 10)

        Returns:
            List of ErrorInfo objects, sorted by most recent first

        Raises:
            ValueError: If project_dir doesn't exist
        """
        project_path = Path(project_dir).resolve()

        if not project_path.exists():
            raise ValueError(f"Project directory does not exist: {project_dir}")

        # Calculate cutoff time
        now = datetime.now()
        cutoff_time = now - timedelta(minutes=since_minutes)

        # Find and parse log files
        errors: List[ErrorInfo] = []

        for pattern in self.log_patterns:
            for log_file in project_path.rglob(pattern):
                if not log_file.is_file():
                    continue

                try:
                    # Check if file was modified recently
                    stat = log_file.stat()
                    modified_time = datetime.fromtimestamp(stat.st_mtime)

                    if modified_time < cutoff_time:
                        continue  # Skip old log files

                    # Parse log file for errors
                    file_errors = self._parse_log_file(log_file, cutoff_time, now)
                    errors.extend(file_errors)

                except (OSError, PermissionError, UnicodeDecodeError):
                    # Skip files we can't read
                    continue

        # Sort by most recent first
        errors.sort(key=lambda e: e.timestamp, reverse=True)

        # Deduplicate similar errors (same error type + similar message)
        errors = self._deduplicate_errors(errors)

        # Limit to max_errors
        return errors[:max_errors]

    def _parse_log_file(
        self,
        log_file: Path,
        cutoff_time: datetime,
        now: datetime,
    ) -> List[ErrorInfo]:
        """Parse a single log file for errors.

        Args:
            log_file: Path to log file
            cutoff_time: Only include errors after this time
            now: Current time for calculating minutes_ago

        Returns:
            List of ErrorInfo objects found in file
        """
        errors: List[ErrorInfo] = []

        try:
            content = log_file.read_text(encoding="utf-8", errors="ignore")
            lines = content.splitlines()

            # Use file modification time as error timestamp
            # (more accurate parsing would require timestamp in logs)
            file_mtime = datetime.fromtimestamp(log_file.stat().st_mtime)

            if file_mtime < cutoff_time:
                return errors

            minutes_ago = (now - file_mtime).total_seconds() / 60

            # Parse Python errors/exceptions
            for match in self.PYTHON_ERROR_PATTERN.finditer(content):
                error_type = match.group("error_type")
                message = match.group("message").strip()

                # Find traceback location (if available)
                location = None
                traceback_matches = list(self.PYTHON_TRACEBACK_PATTERN.finditer(content))
                if traceback_matches:
                    last_trace = traceback_matches[-1]
                    file_path = last_trace.group("file")
                    line_num = last_trace.group("line")
                    location = f"{file_path}:{line_num}"

                # Get context lines
                error_line_num = content[: match.start()].count("\n")
                context_lines = self._get_context_lines(lines, error_line_num, context=2)

                error_info = ErrorInfo(
                    message=message,
                    error_type=error_type,
                    location=location,
                    timestamp=file_mtime,
                    context_lines=context_lines,
                    minutes_ago=minutes_ago,
                )
                errors.append(error_info)

            # Parse pytest failures
            for match in self.PYTEST_FAILED_PATTERN.finditer(content):
                test_name = match.group("test")
                reason = match.group("reason").strip()

                error_info = ErrorInfo(
                    message=f"Test failed: {reason}",
                    error_type="TestFailure",
                    location=test_name,
                    timestamp=file_mtime,
                    context_lines=[],
                    minutes_ago=minutes_ago,
                )
                errors.append(error_info)

        except Exception:
            # Fail silently - error tracking shouldn't break the flow
            pass

        return errors

    @staticmethod
    def _get_context_lines(
        lines: List[str],
        line_num: int,
        context: int = 2,
    ) -> List[str]:
        """Get surrounding lines for context.

        Args:
            lines: All lines in file
            line_num: Line number where error occurred
            context: Number of lines before/after to include

        Returns:
            List of context lines
        """
        start = max(0, line_num - context)
        end = min(len(lines), line_num + context + 1)
        return lines[start:end]

    @staticmethod
    def _deduplicate_errors(errors: List[ErrorInfo]) -> List[ErrorInfo]:
        """Remove duplicate/similar errors.

        Args:
            errors: List of ErrorInfo objects

        Returns:
            Deduplicated list (keeps most recent of each type)
        """
        seen: set[tuple[str, str]] = set()
        deduplicated: List[ErrorInfo] = []

        for error in errors:
            # Create signature (error_type + first 50 chars of message)
            error_type = error.error_type or "UnknownError"
            message_prefix = error.message[:50] if error.message else ""
            signature = (error_type, message_prefix)

            if signature not in seen:
                seen.add(signature)
                deduplicated.append(error)

        return deduplicated

    def format_for_prompt(
        self,
        errors: List[ErrorInfo],
        max_message_length: int = 300,
    ) -> str:
        """Format error list for prompt injection.

        Args:
            errors: List of ErrorInfo objects
            max_message_length: Maximum message length (truncate if longer)

        Returns:
            Formatted string for prompt enrichment

        Example Output:
            Recent Errors (last 30 minutes):
            - ValueError at src/auth.py:42 (15.3m ago)
              Message: Invalid token format
            - TestFailure: test_login_flow (8.7m ago)
              Message: Test failed: AssertionError: Expected 200, got 401
        """
        if not errors:
            return "No recent errors detected."

        lines = ["Recent Errors:"]

        for error in errors:
            # Build error header
            error_type = error.error_type or "Error"
            location = error.location or "unknown location"
            time_str = f"{error.minutes_ago:.1f}m ago"

            lines.append(f"  - {error_type} at {location} ({time_str})")

            # Truncate long messages
            message = error.message
            if len(message) > max_message_length:
                message = message[:max_message_length] + "..."

            lines.append(f"    {message}")

        return "\n".join(lines)
