"""Tests for the shared layer."""
