"""Gmail Archiver - A CLI tool to archive old Gmail messages to local mbox files."""

try:
    from ._version import __version__
except ImportError:
    __version__ = "0.0.0.dev0"
