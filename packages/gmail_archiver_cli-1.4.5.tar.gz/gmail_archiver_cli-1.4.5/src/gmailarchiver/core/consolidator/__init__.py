"""Archive consolidator package."""

from gmailarchiver.core.consolidator.facade import ArchiveConsolidator, ConsolidationResult

__all__ = ["ArchiveConsolidator", "ConsolidationResult"]
