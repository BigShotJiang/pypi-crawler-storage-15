# Metadata files

This guide will show you how to access and use metadata files.
