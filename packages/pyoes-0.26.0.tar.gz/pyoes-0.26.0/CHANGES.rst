0.26.0 (03-12-2025)
===================

- Burgerprofiel updates:
  - 'profiel' knop toevoegen (#355)
  - 'wisselen' knop toevoegen (#344)
  - gebruik loket id's voor test pagina's pyoes (4e493d5bb90eea8982f2ba606ca4d3b002cc8b0d)
 - Maak navbar iets breder om de knoppen te alignen (#343)
 - Plausible snippet updaten (#348)


0.25.1 (25-11-2025)
===================

- Requirements nakijken en versies niet zo strict vastpinnen (#325)
- Nieuwe flow voor npm package (#345)

0.25.0 (19-08-2025)
===================

- placeholder kleur vast leggen voor alle UI's (#336)

0.24.3 (06-08-2025)
===================

- Fix typo in block naam (#333)

0.24.2 (16-05-2025)
===================

- Bump python version (#327)

0.24.1 (22-04-2025)
===================

- Fix string concat (#324)

0.24.0 (22-04-2025)
===================

- Plausible: vervang script src door https://plausible.io/js/script.js (#315)
- noindex toevoegen aan header op dev en test (#317)

0.23.0 (11-09-2024)
===================

- Migratie pyproject + GH Actions (#306)

0.22.0 (27-08-2024)
===================

- Links in header terug mogelijk maken (#300)
- Burgerprofiel - "Hulp nodig" menu configureerbaar maken (#301)

0.21.1 (08-04-2024)
===================

- Foundation laadt niet goed op publieke pagina's (#294)

0.21.0 (13-03-2024)
===================

- Plausible file download tracking (#289)
- PackageManager verwijderen (#288)

0.20.1 (14-12-2023)
===================

- bump versie voor verkeerde pypi release

0.20.0 (14-12-2023)
===================

- Pas jinja's aan voor nieuwe vlaanderen header & footer (#282)
- Upgrade naar Pyramid 2.0 & alle requirements update (#215)

0.19.0 (11-10-2023)
===================

- mismatch tussen static_views benodigde files en MANIFEST (#278)

0.18.0 (31-08-2023)
===================

- decouple common css variables from foundation logic (#273)

0.17.0 (26-07-2023)
===================

- Verwijder pyoes cookiebanner scss (#261)
- Nieuwe vlaanderen header & footer (#268)

0.16.1 (24-02-2023)
===================

- main_nav updaten zodat het ook css kan zetten (#262)

0.16.0 (14-12-2022)
===================

- Google Analytics en cookie banner verwijderen (#256)

0.15.0 (21-11-2022)
===================

- Update pyoes header (#250)
- Fix bgimage, bgimage-bouwkunde image url (#252)


0.14.2 (04-07-2022)
===================

- header staat niet gecentreerd (#245)

0.14.1 (27-06-2022)
===================

- Check inbouwen of persoonsgegevens bestaat voor het attribuut wordt gebruikt (#241)

0.14.0 (27-04-2022)
===================

- checkboxes & radio buttons styling (#235)

0.13.0 (17-03-2022)
===================

- pyoes styles npm package (#228)
- Keycloak migratie (#231)

0.12.7 (22-12-2021)
===================

- Aanpassingen zodat de wrapper mee scaled als een scherm groter/kleiner wordt. (#224)

0.12.6 (04-11-2021)
===================

- haal app.css import uit plausible macro (#221)

0.12.5 (10-10-2021)
===================

- Mobiele cookiebanner smaller gemaakt (#216)

0.12.4 (11-05-2021)
===================

- Fix boolean check cookiebanner (#211)

0.12.3 (05-05-2021)
===================

- Tekst cookiebanner aanpassen (#207)

0.12.2 (05-04-2021)
===================

- Cookiebanner toevoegen (#190)
- Plausible toevoegen (#201)

0.12.1 (22-03-2021)
===================

- Versprongen SVG oplossen (#197)

0.12.0 (15-03-2021)
===================

- Tijdelijke boodschap tonen (#167)

0.11.3 (23-10-2020)
===================
- Font size en color bij select in leesmodus aanpassen + Placeholder text lichter grijs maken (#182)

0.11.2 (28-07-2020)
===================
- Responsive header aanpassen (#177)
- Icons toelaten in main navigatie (#176)

0.11.1 (14-05-2020)
===================
- Header herbekijken ikv mobile layout (#169)

0.11.0 (27-01-2020)
===================
- Update van Vlaanderen header en footer (#162)

0.10.0 (14-01-2020)
===================
- height van selects weghalen (#148)
- input[type="email"] zelfde stijl als input[type="text"] maken (#153)
- updates dependencies via dependabot

0.9.2 (05-11-2019)
==================
- Compile errors door unrecognized characters (#149)

0.9.1 (08-08-2019)
==================
- "Flanders Art Sans Bold" ontbreekt in _oe-type.scss (#146)

0.9.0 (26-06-2019)
==================
- Libs updaten - security alert (#140)
- Mobiele layout verbeteren (#139)

0.8.0 (22-02-2019)
==================
- Header - contact & over ons links (#135)

0.7.0 (18-07-2018)
==================
- Updaten van GA macro (#125)
- Aanpassen kleur active in menubar (#124)

0.6.0 (04-07-2018)
==================

- Fix jquery versie in public scaffold bower.json (#97)
- admin bower.json template updaten (#98)
- Display aangemelde gebruiker in geval gebruiker geen Actor object heeft (#104)
- Aanpassen link color (#110)
- Privacybeleid link in footer (#116)

0.5.0 (27-0-2018)
==================

* Added new jinja2 filter specific for formatting fuzzy_dates (also for dates before 1900)

0.4.8 (22-03-2018)
==================

* Updates/aanpassingen voor oa Inventaris (#109)

0.4.7 (02-02-2017)
==================

* bugfix datum
* favicon
* IE compatibility
* link ict mailbox

0.4.6 (30-06-2016)
==================

* bugfix in code voor dropdowns

0.4.5 (29-06-2016
=================

* mogelijkheid toegevoegd om dropdown in het menu te tonen
* enkele verbeteringen in de error pagina's
* uitlijning van de Vlaanderen banners
* verschillende verbeteringen voor de admin stijl

0.4.4 (03-02-2016)
==================

* Proces scaffold toegevoegd
* verbeterde error page templates
* nieuw Home icon
* verbeterde footer links
* social media links toegevoegd
* verschillende stijl verbeteringen
* update naar jinja2 2.8

0.4.3 (02-07-2015)
==================

* Bugfix error pages
* Lijstweergave zoekresultaten aangepast
* Detailpagina besluitentype geupdate
* zoekwidget toegevoegd

0.4.2 (09-06-2015)
==================

* Kleine layout fixes
* Admin interface update

0.4.1 (29-05-2015)
==================
* Toevoegen van een textarea element met een inline label 
* Toevoegen van een checkbox met een placeholder
* Toevoegen van een generieke profile template
* Toevoegen van een macro om een URI voor een resource te genereren
* Toevoegen van een generiek datetime format filter
* Opkuisen van het project
* Schrijven van nieuwe tests om coverage te vergroten

0.4.0 (24-04-2015)
==================

* fix voor favicon
* Speciale input velden toegevoegd
* Voorbeeldtemplates verder uitgewerkt
* Generieke 404/500 templates toegevoegd
* Alertblock toegevoegd
* Mediaqueries toegevoegd die problemen met header op mobile devices oplost
* Problemen met footer verholpen

0.3.3 (04-03-2015)
==================
* Fix voor gebruikersnamen
* Documentatie geupdate ivm admin scaffold

0.3.2 (26-02-2015)
==================
* Aanpassingen vooral aan admin scaffold


0.3.1 (23-02-2015)
==================

* Admin scaffold toegevoegd
* Aanmelden/Afmelden knop toegevoegd
* Google analytics geupdate naar Universal analytics
* Font-awesome toegevoegd als bower dependency

0.3.0 (12-02-2015)
==================

* Erfgoedstijl aangepast aan vereisten van de nieuwe Vlaamse Huisstijl


0.2.1 (25-11-2014)
==================

* Released as open source on PyPI.
* Copyright date can be changed again. Now works with a variable instead of 
  a block.

0.2.0 (14-08-2014)
==================

* Andere manier van omgaan met Foundation dependency. Gaat nu via bower.
* Upgraden naar Foundation 5.3.x. Bower zal steeds de laatste versie in de 5.3
  reeks proberen aan te houden.
* Toevoegen van Foundation Icon Fonts 3
* Unit tests naar py.test ipv nose.
* Basistemplate is nu meer responsive dan vroeger.
* Standaard breedte van de css grid werd nu gelijk geschakeld met die van de
  corporate site.
* Footer werd gewijzigd zodat er blauw over de ganse breedte is.

0.1.1 (06-08-2014)
==================

* Toevoegen van een mogelijkheid om css_files in de html header te injecteren. (#7) [JonathanGeosolutions]
* Toevoegen van een mogelijkheid om de HTML header te overriden in een template.
* Testen ook laten uitvoeren op py33 en py34.

0.1.0
=====

* Eerste stabiele release.
* Maakt nu gebruik van onze eigen typekit code.

0.1.0b2
=======

* Terug naar TypeKit. Voorlopig gebruiken we de account van Glue. Op een bepaald
  moment zal iemand wel eens voor onze eigen accout moeten betalen.

0.1.0b1
=======

* Extra documentatie met sphinx. (#5)
* Static files zoals favicon en robots.txt kunnen geleverd worden door pyoes. (#6)
* Niet meer nodig om pyoes:static view te includen. Vanaf nu moet pyoes zelf 
  wel geinclude worden, deze handelt dan de rest af.
* De scaffold zal meteen een sass bestand voor de applicatie specifieke css
  aanmaken.

0.1.0a3
=======

* Overschakelen op open fonts. (#4)
* Js files kunnen doorgegeven worden door extended templates. (#3)
* Verwijderen van een onbestaande dit in het install_compass_extensions script werkt. (#1)
* Docs wat uitgebreid. (#2)
* Layout van de breadcrumbs wat compacter gemaakt.

0.1.0a2
=======

* Zorgend dat jquery protocol onafhankelijk kan geladen worden. Gaf problemen 
  op https sites.

0.1.0a1
=======

* eerste versie die getagged wordt
* aantal jinja2 templates
* sass files
* nog zeer onvolledig en met gebrekkige documentatie
