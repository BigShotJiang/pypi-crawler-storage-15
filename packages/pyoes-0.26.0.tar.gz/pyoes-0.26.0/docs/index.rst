.. PYramid Onroerend Erfgoed Style documentation master file, created by
   sphinx-quickstart on Wed Aug 28 18:25:11 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

pyoes: PYramid Onroerend Erfgoed Style
======================================

Pyoes is een package om het makkelijker te maken om layout te delen 
tussen de verschillende OE sites.

.. toctree::
   :maxdepth: 2

   install
   gebruik
   development
   api
   changes
   glossary


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

