mod generic;

pub use generic::BlockEntity;
