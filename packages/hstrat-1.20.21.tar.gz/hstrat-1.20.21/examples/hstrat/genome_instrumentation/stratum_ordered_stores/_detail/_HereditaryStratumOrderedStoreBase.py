class HereditaryStratumOrderedStoreBase:
    """Dummy class to faciliate recognition of HereditaryStratumOrderedStore classes."""
