class PolicySpecBase:
    """Dummy class to faciliate recognition of PolicySpec classes."""
