class PolicyCouplerBase:
    """Dummy class to faciliate recognition of instantiations of the
    PolicyCoupler class across different calls to the PolicyCoupler factory."""
