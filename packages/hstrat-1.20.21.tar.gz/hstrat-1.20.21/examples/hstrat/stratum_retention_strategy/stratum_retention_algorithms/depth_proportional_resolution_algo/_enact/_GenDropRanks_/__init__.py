from ._FromPredKeepRank import FromPredKeepRank
from ._GenDropRanks import GenDropRanks

_GenDropRanks_impls = (FromPredKeepRank, GenDropRanks)
