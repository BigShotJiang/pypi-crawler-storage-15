from ._TriePostprocessorBase import TriePostprocessorBase

__all__ = [
    "TriePostprocessorBase",
]
