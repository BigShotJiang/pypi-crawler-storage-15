"""Implementation helpers."""

from ._dispatch_impl import dispatch_impl

# adapted from https://stackoverflow.com/a/31079085
__all__ = [
    "dispatch_impl",
]
