"""CapInvest News extension."""
