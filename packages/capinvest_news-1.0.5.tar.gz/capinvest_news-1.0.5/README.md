# CapInvest News Extension

This extension provides news for the CapInvest Platform.

 


