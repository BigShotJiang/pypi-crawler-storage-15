"""Inference, evaluation, and visualization scripts for trained models."""
