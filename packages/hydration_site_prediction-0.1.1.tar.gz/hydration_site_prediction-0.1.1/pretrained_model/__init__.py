"""Pretrained model weights for HydrationSitePrediction."""
