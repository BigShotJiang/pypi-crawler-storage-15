"""
Sources
"""

NAME = "Shadow4 \u23F5 Preprocessors"

DESCRIPTION = "Preprocessors."

BACKGROUND = "#b9d47a"

ICON = "icons/ingranaggio.png"

PRIORITY = 4.2