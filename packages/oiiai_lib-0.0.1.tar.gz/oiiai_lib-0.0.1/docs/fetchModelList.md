# fetchModelList 模块

获取各 AI 提供商的可用模型列表。

## 安装依赖

```bash
pip install requests
```

## 基类

### ModelFetcher

所有模型获取器的抽象基类。

```python
from oiiai import ModelFetcher

class MyFetcher(ModelFetcher):
    @property
    def provider(self) -> str:
        return "my_provider"
    
    def fetch_models(self) -> List[str]:
        # 实现获取逻辑
        return ["model-1", "model-2"]
```

## 内置实现

### OpenRouterModelFetcher

从 OpenRouter API 获取模型列表。

```python
from oiiai import OpenRouterModelFetcher

# 使用 API Key（可选，不传则从环境变量 OPENROUTER_API_KEY 获取）
fetcher = OpenRouterModelFetcher(api_key="your-api-key")

# 获取模型列表
models = fetcher.fetch_models()
print(models)  # ['openai/gpt-4o', 'anthropic/claude-3-opus', ...]
```

### ZhipuModelFetcher

从智谱 AI 官方文档页面解析模型列表。

```python
from oiiai import ZhipuModelFetcher

fetcher = ZhipuModelFetcher()
models = fetcher.fetch_models()
print(models)  # ['glm-4-flash', 'glm-4', ...]
```

### ModelScopeFetcher

从 ModelScope API 获取模型列表。

```python
from oiiai import ModelScopeFetcher

fetcher = ModelScopeFetcher()
models = fetcher.fetch_models()
print(models)  # ['deepseek-ai/DeepSeek-R1-0528', 'Qwen/Qwen2.5-72B-Instruct', ...]
```

### SiliconFlowFetcher

从 SiliconFlow API 获取模型列表。需要设置环境变量 `SILICONFLOW_API_KEY`。

```python
from oiiai import SiliconFlowFetcher

fetcher = SiliconFlowFetcher()
models = fetcher.fetch_models()
print(models)  # ['deepseek-ai/DeepSeek-R1', 'Qwen/Qwen2.5-72B-Instruct', ...]
```

### IFlowFetcher

从 IFlow 平台获取模型列表。

```python
from oiiai import IFlowFetcher

fetcher = IFlowFetcher()
models = fetcher.fetch_models()
print(models)  # ['qwen3-max', 'deepseek-r1', 'kimi-k2', ...]
```

## 扩展

实现自定义获取器只需继承 `ModelFetcher` 并实现 `provider` 属性和 `fetch_models()` 方法。
