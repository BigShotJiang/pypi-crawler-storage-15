#!/usr/bin/env python3
"""测试 SiliconFlow 模型获取器的原始输出"""

import requests
import os
from typing import List

# 直接复制 SiliconFlowFetcher 的代码，避免依赖问题

class SiliconFlowFetcher:
    @property
    def provider(self) -> str:
        return "siliconflow"

    def fetch_models(self) -> List[str]:
        url = "https://api.siliconflow.cn/v1/models"
        api_key = os.getenv("SILICONFLOW_API_KEY")
        if not api_key:
            print("SILICONFLOW_API_KEY environment variable not set.")
            return []

        headers = {"Authorization": f"Bearer {api_key}"}

        try:
            response = requests.get(url, headers=headers)
            response.raise_for_status()  # Raise an exception for HTTP errors
            data = response.json()
            # Assuming the API returns a list of model IDs directly or in a 'data' field
            # Adjust this based on the actual API response structure
            if isinstance(data, dict) and "data" in data and isinstance(data["data"], list):
                return [model["id"] for model in data["data"]]
            elif isinstance(data, list):
                return data
            else:
                print(f"Unexpected response format from SiliconFlow API: {data}")
                return []
        except requests.exceptions.RequestException as e:
            print(f"Error fetching models from SiliconFlow: {e}")
            return []

def test_siliconflow_fetcher():
    fetcher = SiliconFlowFetcher()
    result = fetcher.fetch_models()
    print(result)
    return result

if __name__ == "__main__":
    test_siliconflow_fetcher()