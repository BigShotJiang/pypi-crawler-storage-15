#!/usr/bin/env python3
"""测试OpenRouter模型获取器的原始输出"""

import os
import requests
from typing import List

# 直接复制 OpenRouterModelFetcher 的代码，避免依赖问题

OPENROUTER_API_URL = "https://openrouter.ai/api/v1/models"

class OpenRouterModelFetcher:
    """OpenRouter 模型列表获取器"""

    def __init__(self, api_key: str = None):
        """
        初始化 OpenRouter 模型获取器。
        
        Args:
            api_key: OpenRouter API 密钥，如不传则从环境变量 OPENROUTER_API_KEY 获取
        """
        self._api_key = api_key or os.getenv("OPENROUTER_API_KEY", "")

    @property
    def provider(self) -> str:
        return "openrouter"

    def fetch_models(self) -> List[str]:
        """从 OpenRouter API 获取可用模型列表"""
        headers = {}
        if self._api_key:
            headers["Authorization"] = f"Bearer {self._api_key}"

        response = requests.get(OPENROUTER_API_URL, headers=headers, timeout=30)
        response.raise_for_status()

        data = response.json()
        models = data.get("data", [])

        return [m.get("id") for m in models if m.get("id")]

def test_openrouter_fetcher():
    fetcher = OpenRouterModelFetcher()
    result = fetcher.fetch_models()
    print(result)
    return result

if __name__ == "__main__":
    test_openrouter_fetcher()