#!/usr/bin/env python3
"""测试 IFlow 模型获取器的原始输出"""

import requests
import os
from typing import List, Dict

# 直接复制 IFlowFetcher 的代码，避免依赖问题

class IFlowFetcher:
    """IFlow 模型列表获取器"""

    @property
    def provider(self) -> str:
        return "iflow"

    def fetch_models(self) -> List[str]:
        """
        从 IFlow 获取模型列表
        """
        url = "https://iflow.cn/api/platform/models/list"

        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
            "Content-Type": "application/json",
            # "Cookie": "..." # 经测试，该接口无需 Cookie 即可访问
        }

        payload = {}

        try:
            # POST 请求
            response = requests.post(url, json=payload, headers=headers, timeout=30)

            response.raise_for_status()
            data = response.json()

            models = []

            if isinstance(data, dict) and "data" in data and isinstance(data["data"], dict):
                for category, model_list in data["data"].items():
                    if isinstance(model_list, list):
                        for model in model_list:
                            if isinstance(model, dict):
                                # 优先使用 modelName，如果没有则尝试其他字段
                                model_name = model.get("modelName") or model.get("showName") or model.get("id")
                                if model_name:
                                    models.append(str(model_name))

            return models

        except requests.exceptions.RequestException as e:
            print(f"Error fetching models from iflow: {e}")
            return []

def test_iflow_fetcher():
    fetcher = IFlowFetcher()
    result = fetcher.fetch_models()
    print(result)
    return result

if __name__ == "__main__":
    test_iflow_fetcher()