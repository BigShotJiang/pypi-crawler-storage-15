"""
oiiai - 简单的 AI 模型调用工具包

提供模型列表获取和模型调用功能。
"""

from .fetchModelList import (
    ModelFetcher,
    ZhipuModelFetcher,
    OpenRouterModelFetcher,
    ModelScopeFetcher,
    SiliconFlowFetcher,
    IFlowFetcher,
)

__all__ = [
    # 模型列表获取
    "ModelFetcher",
    "ZhipuModelFetcher",
    "OpenRouterModelFetcher",
    "ModelScopeFetcher",
    "SiliconFlowFetcher",
    "IFlowFetcher",
]