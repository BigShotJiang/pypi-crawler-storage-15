"""
OpenRouter model list fetching
"""

import os
import requests
from typing import List

from .base import ModelFetcher

OPENROUTER_API_URL = "https://openrouter.ai/api/v1/models"


class OpenRouterModelFetcher(ModelFetcher):
    """OpenRouter model list fetcher"""

    def __init__(self, api_key: str = None):
        """
        Initialize OpenRouter model fetcher.
        
        Args:
            api_key: OpenRouter API key, if not provided, get from environment variable OPENROUTER_API_KEY
        """
        self._api_key = api_key or os.getenv("OPENROUTER_API_KEY", "")

    @property
    def provider(self) -> str:
        return "openrouter"

    def fetch_models(self) -> List[str]:
        """Fetch available model list from OpenRouter API"""
        headers = {}
        if self._api_key:
            headers["Authorization"] = f"Bearer {self._api_key}"

        response = requests.get(OPENROUTER_API_URL, headers=headers, timeout=30)
        response.raise_for_status()

        data = response.json()
        models = data.get("data", [])

        return [m.get("id") for m in models if m.get("id")]
