import requests
from typing import List
from .base import ModelFetcher


class ModelScopeFetcher(ModelFetcher):
    @property
    def provider(self) -> str:
        return "modelscope"

    def fetch_models(self) -> List[str]:
        url = "https://api-inference.modelscope.cn/v1/models"
        try:
            response = requests.get(url)
            response.raise_for_status()  # Raise HTTP error exception
            data = response.json()
            # Assume API directly returns list of model IDs or in 'data' field
            # Adjust according to actual API response structure
            if isinstance(data, list):
                return data
            elif isinstance(data, dict) and "data" in data and isinstance(data["data"], list):
                return [model["id"] for model in data["data"]]
            else:
                print(f"ModelScope API returned unexpected format: {data}")
                return []
        except requests.exceptions.RequestException as e:
            print(f"Error fetching models from ModelScope: {e}")
            return []
