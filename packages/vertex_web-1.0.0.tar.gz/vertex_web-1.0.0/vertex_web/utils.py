import re
import validators

def validate_domain(domain):
    """Validate domain format"""
    if not domain:
        return True
    
    # Basic domain validation
    pattern = r'^[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z]{2,})+$'
    
    if re.match(pattern, domain) or validators.domain(domain):
        return True
    
    return False

def get_available_port(start_port=5552):
    """Get next available port"""
    import socket
    
    port = start_port
    while port < 65535:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            if s.connect_ex(('localhost', port)) != 0:
                return port
        port += 1
    
    return None