import socket
import requests
import dns.resolver

def check_domain_availability(domain):
    """
    Check if a domain/subdomain is available
    """
    try:
        # Remove protocol if present
        domain = domain.replace('http://', '').replace('https://', '').split('/')[0]
        
        # Try to resolve DNS
        try:
            dns.resolver.resolve(domain, 'A')
            return False  # Domain exists
        except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer):
            pass
        
        # Try socket connection
        try:
            socket.gethostbyname(domain)
            return False  # Domain exists
        except socket.gaierror:
            pass
        
        # Try HTTP/HTTPS
        for protocol in ['http', 'https']:
            try:
                url = f"{protocol}://{domain}"
                response = requests.get(url, timeout=5)
                if response.status_code < 400:
                    return False  # Domain exists and responds
            except:
                continue
        
        return True  # Domain appears available
        
    except Exception as e:
        print(f"⚠️  Domain check error: {e}")
        return True  # Assume available on error