VARIANT_FREQUENCY_KEY = "@@variant_frequency"
