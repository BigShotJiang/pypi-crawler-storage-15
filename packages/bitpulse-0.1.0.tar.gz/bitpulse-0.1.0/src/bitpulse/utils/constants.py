FINISH_REASON_MAPPING = {
    "stop": "stop",
    "length": "length",
    "max_tokens": "length",
    "tool": "tool_calls",
    "filter": "content_filter",
    "error": "error",
}
