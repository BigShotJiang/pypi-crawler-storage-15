class StorageError(Exception):
    """Base exception for storage errors."""

    pass


class InstrumentationErrrr(Exception):
    """Base exception for instrumentation errors."""

    pass
