"""
aiida_gromacs

A plugin for using GROMACS with AiiDA for molecular dymanics simulations.
"""