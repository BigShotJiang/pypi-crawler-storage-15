"""
aiida_gromacs

A plugin for using GROMACS with AiiDA for molecular dymanics simulations.
"""

__version__ = "2.1.1"
