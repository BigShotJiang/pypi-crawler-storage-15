.. _admin:

**************
Administration
**************

The administrator can see assets and users here.

Assets
------

Listing all assets:

.. image:: https://github.com/FlexMeasures/screenshots/raw/main/screenshot_assets.png
    :align: center
..    :scale: 40%



Users
-----

Listing all users:

.. image:: https://github.com/FlexMeasures/screenshots/raw/main/screenshot_users.png
    :align: center
..    :scale: 40%


Viewing one user:

.. image:: https://github.com/FlexMeasures/screenshots/raw/main/screenshot_user.png
    :align: center
..    :scale: 40%
