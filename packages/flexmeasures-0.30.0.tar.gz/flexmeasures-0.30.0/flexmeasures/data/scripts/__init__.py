"""
Useful scripts
"""
