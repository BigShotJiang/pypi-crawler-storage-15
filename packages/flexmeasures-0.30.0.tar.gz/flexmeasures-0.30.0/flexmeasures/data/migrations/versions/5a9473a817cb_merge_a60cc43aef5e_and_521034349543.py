"""merge a60cc43aef5e and 521034349543

Revision ID: 5a9473a817cb
Revises: a60cc43aef5e, 521034349543
Create Date: 2023-10-19 11:35:50.865203

"""

# revision identifiers, used by Alembic.
revision = "5a9473a817cb"
down_revision = ("a60cc43aef5e", "521034349543")
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
