"""merge

Revision ID: 5bde9835fbe3
Revises: b526da466b74, f5a9e0effa17
Create Date: 2025-07-29 14:58:05.822909

"""

# revision identifiers, used by Alembic.
revision = "5bde9835fbe3"
down_revision = ("b526da466b74", "f5a9e0effa17")
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
