"""merge

Revision ID: f5a9e0effa17
Revises: 0f64e22d6b9e, f0ee99278f6f
Create Date: 2025-07-10 14:12:41.642766

"""

# revision identifiers, used by Alembic.
revision = "f5a9e0effa17"
down_revision = ("0f64e22d6b9e", "f0ee99278f6f")
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
