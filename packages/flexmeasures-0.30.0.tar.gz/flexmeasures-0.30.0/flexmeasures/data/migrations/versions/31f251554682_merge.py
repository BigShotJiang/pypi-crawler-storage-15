"""merge

Revision ID: 31f251554682
Revises: b2b43f0eec40, 61bfc6e45c4d
Create Date: 2018-09-20 12:05:36.768426

"""

# revision identifiers, used by Alembic.
revision = "31f251554682"
down_revision = ("b2b43f0eec40", "61bfc6e45c4d")
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
