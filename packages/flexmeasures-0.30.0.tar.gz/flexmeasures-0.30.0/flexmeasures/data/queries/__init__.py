"""
Data query functions
"""
