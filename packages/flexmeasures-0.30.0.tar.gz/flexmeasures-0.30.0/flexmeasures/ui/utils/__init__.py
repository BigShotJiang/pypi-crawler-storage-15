"""
Utility functions for UI logic
"""
