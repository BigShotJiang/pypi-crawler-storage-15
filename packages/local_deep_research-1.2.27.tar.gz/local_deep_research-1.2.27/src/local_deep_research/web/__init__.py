"""Web interface for Local Deep Research"""
