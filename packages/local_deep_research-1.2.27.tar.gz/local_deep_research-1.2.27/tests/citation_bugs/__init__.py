"""Tests for citation formatting bugs."""
