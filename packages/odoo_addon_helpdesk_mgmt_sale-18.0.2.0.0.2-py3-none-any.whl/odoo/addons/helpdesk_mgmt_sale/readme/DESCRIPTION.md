This module extends the Helpdesk functionality in Odoo to allow an
integration between Helpdesk tickets and sales orders. A ticket can have
several sales orders associated with it, which in turn will have the
ticket associated with it, allowing tickets and sales to be related.
