# ai_helpers

A simple Python library for AI-like text processing.

## Installation
pip install textflow_ai

## Usage
from textflow_ai import get_response, summarize_text, format_response

print(get_response("Hello"))
