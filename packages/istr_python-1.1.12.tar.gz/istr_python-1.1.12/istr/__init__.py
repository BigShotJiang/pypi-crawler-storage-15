from .istr import *
from .istr import __version__