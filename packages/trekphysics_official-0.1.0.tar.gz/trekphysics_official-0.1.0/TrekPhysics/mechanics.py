class Hiker:
    """
    Represents a trekker with specific body stats and gear.
    """
    def __init__(self, body_mass_kg, pack_weight_kg=0.0):
        """
        Initialize a new Hiker.
        
        Args:
            body_mass_kg (float): Weight of the person.
            pack_weight_kg (float): Weight of the backpack (default 0).
        """
        if body_mass_kg <= 0:
            raise ValueError("Body mass must be positive.")
        if pack_weight_kg < 0:
            raise ValueError("Pack weight cannot be negative.")
            
        self.body_mass = body_mass_kg
        self.pack_weight = pack_weight_kg
        self.total_mass = body_mass_kg + pack_weight_kg

    def set_pack_weight(self, new_weight):
        """Updates pack weight and recalculates total mass."""
        if new_weight < 0:
            raise ValueError("Pack weight cannot be negative.")
        self.pack_weight = new_weight
        self.total_mass = self.body_mass + new_weight

    def calculate_metabolic_power(self, velocity_ms, gradient_percent, terrain_factor=1.0):
        """
        Calculates instantaneous power output in Watts using the Pandolf Equation.
        """
        # 1. Standing Cost (Basal)
        stand_cost = 1.5 * self.body_mass
        
        # 2. Load Cost
        load_ratio = (self.pack_weight / self.body_mass) ** 2
        load_cost = 2.0 * self.total_mass * load_ratio
        
        # 3. Terrain & Movement Cost
        move_cost = terrain_factor * self.total_mass * (1.5 * (velocity_ms**2) + 0.35 * velocity_ms * gradient_percent)
        
        total_watts = stand_cost + load_cost + move_cost
        return round(total_watts, 2)

    def get_calorie_burn(self, velocity_ms, gradient_percent, terrain_factor=1.0):
        """Returns energy expenditure in kcal/hour."""
        watts = self.calculate_metabolic_power(velocity_ms, gradient_percent, terrain_factor)
        # Conversion: 1 Watt = 0.8598 kcal/hr
        return round(watts * 0.8598, 1)

    def calculate_item_penalty(self, item_mass_kg, distance_km, velocity_ms, gradient_percent, terrain_factor=1.0):
        """
        Calculates the EXTRA calories burned just by carrying a specific item.
        
        Args:
            item_mass_kg (float): Weight of the luxury item (e.g., 1.5kg camera).
            distance_km (float): Total length of the trip.
            velocity_ms (float): Speed.
            gradient_percent (float): Slope.
            
        Returns:
            float: The extra calories consumed due to this item.
        """
        # 1. Calculate burn rate WITHOUT the item (Current state)
        watts_before = self.calculate_metabolic_power(velocity_ms, gradient_percent, terrain_factor)
        
        # 2. Add item weight temporarily
        original_pack = self.pack_weight
        self.set_pack_weight(original_pack + item_mass_kg)
        
        # 3. Calculate burn rate WITH the item
        watts_after = self.calculate_metabolic_power(velocity_ms, gradient_percent, terrain_factor)
        
        # 4. Revert weight back to normal (Cleanup)
        self.set_pack_weight(original_pack)
        
        # 5. Calculate Difference
        watt_diff = watts_after - watts_before
        
        # Calculate Duration of walk (Hours = Distance / Speed)
        # speed is m/s, so we multiply by 3600 to get m/hr, then divide distance (meters)
        time_hours = (distance_km * 1000) / (velocity_ms * 3600)
        
        # Total Extra Energy = (Power Diff converted to kcal/hr) * Time
        extra_calories = (watt_diff * 0.8598) * time_hours
        
        return round(extra_calories, 1)