import math

class Respiration:
    """
    Handles oxygen calculations, hypoxia risk, and hydration.
    """
    
    @staticmethod
    def calculate_effective_oxygen(altitude_meters):
        """
        Returns the effective oxygen percentage relative to sea level.
        """
        # Pressure decay approximation
        pressure_ratio = math.exp(-0.00012 * altitude_meters)
        effective_o2 = 20.9 * pressure_ratio
        return round(effective_o2, 1)

    def assess_risk(self, altitude_meters):
        """
        Returns a risk assessment string based on altitude.
        """
        o2_level = self.calculate_effective_oxygen(altitude_meters)
        
        if o2_level > 19.0:
            return f"Safe ({o2_level}%)"
        elif o2_level > 15.0:
            return f"Low Risk ({o2_level}%) - Expect fatigue"
        elif o2_level > 10.0:
            return f"Moderate Risk ({o2_level}%) - AMS possible"
        else:
            return f"HIGH RISK ({o2_level}%) - Severe Hypoxia"

    def calculate_hydration_need(self, metabolic_calories_hr, altitude_meters):
        """
        Calculates water needs based on exertion and altitude dryness.
        
        The Formula:
        1. Base Need: 0.5 Liters (Standard baseline)
        2. Sweat Loss: ~1 Liter for every 1000 kcal burned.
        3. Respiratory Loss: High altitude air is dry. You lose ~100ml 
           per hour for every 1000m of elevation.
           
        Args:
            metabolic_calories_hr (float): Energy burned per hour.
            altitude_meters (float): Current elevation.
            
        Returns:
            float: Liters of water recommended per hour.
        """
        # 1. Exertion Loss (Sweat)
        sweat_loss_liters = metabolic_calories_hr / 1000.0
        
        # 2. Respiration Loss (Breathing dry air)
        respiratory_loss = (altitude_meters / 1000.0) * 0.1
        
        total_liters = 0.5 + sweat_loss_liters + respiratory_loss
        return round(total_liters, 2)
    
    