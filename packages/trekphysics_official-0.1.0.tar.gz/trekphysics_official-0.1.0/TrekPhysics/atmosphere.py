import math

class Atmosphere:
    """
    Models the thermodynamic state of the air at a specific altitude.
    """
    # Physics Constants (Class Variables)
    P0 = 101325  # Sea level pressure (Pa)
    T0 = 288.15  # Sea level temp (K)
    G = 9.80665  # Gravity
    M = 0.02896  # Molar mass of air
    R = 8.31447  # Gas constant

    def __init__(self, altitude_meters):
        self.altitude = altitude_meters

    @property
    def pressure_pa(self):
        """Calculates atmospheric pressure in Pascals."""
        # The Barometric Formula
        exponent = (-self.G * self.M * self.altitude) / (self.R * self.T0)
        return round(self.P0 * math.exp(exponent), 0)

    @property
    def boiling_point(self):
        """Calculates boiling point of water in Celsius."""
        # Simplified Magnus approximation
        # Water boils approx 1 degree C lower for every 285m elevation
        return round(100 - (self.altitude / 285.0), 1)

    @property
    def cook_time_multiplier(self):
        """Returns how much longer cooking takes (e.g., 1.5x)."""
        # Heuristic: +5% time for every 300m
        return round(1 + (0.05 * (self.altitude / 300.0)), 2)
        
    def get_report(self):
        """Returns a dictionary summary of the environment."""
        return {
            "altitude": self.altitude,
            "pressure": self.pressure_pa,
            "boiling_point": self.boiling_point,
            "cook_factor": self.cook_time_multiplier
        }