# Expose the OOP Classes to the outside world
from .mechanics import Hiker
from .atmosphere import Atmosphere
from .physiology import Respiration
from .plotting import TrekVisualizer

__version__ = "0.2.0"