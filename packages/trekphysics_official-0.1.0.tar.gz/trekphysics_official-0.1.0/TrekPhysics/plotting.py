import matplotlib.pyplot as plt
from .atmosphere import Atmosphere
from .physiology import Respiration

class TrekVisualizer:
    """
    Handles the generation of graphs for trek profiles.
    """
    def __init__(self, elevation_profile):
        """
        Args:
            elevation_profile (list): List of altitudes in meters.
        """
        self.profile = elevation_profile

    def plot_environmental_impact(self):
        """Generates the dual-axis chart."""
        x_points = range(len(self.profile))
        
        # Create temporary objects to calculate data points
        # List comprehension creates an Atmosphere object for every height in the list
        boiling_points = [Atmosphere(h).boiling_point for h in self.profile]
        oxygen_levels = [Respiration.calculate_effective_oxygen(h) for h in self.profile]

        # --- Plotting Logic ---
        fig, ax1 = plt.subplots(figsize=(10, 6))
        
        # Axis 1: Elevation (Blue)
        ax1.fill_between(x_points, self.profile, color='skyblue', alpha=0.3, label='Terrain')
        ax1.plot(x_points, self.profile, color='blue', linewidth=2)
        ax1.set_xlabel('Checkpoint #')
        ax1.set_ylabel('Elevation (m)', color='blue')
        ax1.grid(True, linestyle='--', alpha=0.5)
        
        # Axis 2: Oxygen (Red)
        ax2 = ax1.twinx()
        ax2.plot(x_points, oxygen_levels, color='red', linestyle='--', marker='o', label='O2 Level')
        ax2.set_ylabel('Effective Oxygen (%)', color='red')
        
        # Title
        plt.title('TrekPhysics: Environmental Analysis (OOP Version)')
        fig.tight_layout()
        plt.show()