"""Tool implementations for Ripperdoc."""
