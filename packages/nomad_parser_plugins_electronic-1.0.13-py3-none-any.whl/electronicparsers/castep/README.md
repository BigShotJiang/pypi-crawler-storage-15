This is a NOMAD parser for [CASTEP](http://www.castep.org/). It will read CASTEP input and
output files and provide all information in NOMAD's unified Metainfo based Archive format.

For CASTEP please provide at least the files from this table if applicable to your
calculations (remember that you can provide more files if you want):



