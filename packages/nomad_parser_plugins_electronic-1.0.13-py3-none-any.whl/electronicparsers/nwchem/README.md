This is a NOMAD parser for [NWChem](https://nwchemgit.github.io/). It will read NWChem input and
output files and provide all information in NOMAD's unified Metainfo based Archive format.

For NWChem please provide at least the files from this table if applicable to your
calculations (remember that you can provide more files if you want):



