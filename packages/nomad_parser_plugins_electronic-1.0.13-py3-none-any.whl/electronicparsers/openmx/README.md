This is a NOMAD parser for [OpenMX](http://www.openmx-square.org/). It will read OpenMX input and
output files and provide all information in NOMAD's unified Metainfo based Archive format.

For OpenMX please provide at least the files from this table if applicable to your
calculations (remember that you can provide more files if you want):

|Input Filename| Description|
|--- | --- |
|`<systemname>.out` | **Mainfile** in OpenMX specific plain-text |
