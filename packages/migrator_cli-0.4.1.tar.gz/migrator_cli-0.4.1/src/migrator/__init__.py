"""Migrator - Universal migration CLI for Python apps"""

from migrator.version import __version__

__all__ = ["__version__"]
