"""Version information for migrator CLI"""

__version__ = "0.4.1"
