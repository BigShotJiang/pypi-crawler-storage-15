"""
API routes for the Data Manager service.
"""
