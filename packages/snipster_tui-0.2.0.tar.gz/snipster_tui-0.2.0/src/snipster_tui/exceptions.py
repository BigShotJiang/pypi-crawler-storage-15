class SnippetNotFoundError(Exception):
    pass


class NoMatches(Exception):
    pass
