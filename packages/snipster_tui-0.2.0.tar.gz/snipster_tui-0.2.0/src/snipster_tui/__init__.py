def main() -> None:
    print("Hello from pybites-cohort!")
