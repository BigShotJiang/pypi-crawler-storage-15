The creative artwork for HERMES is Copyright (c) 2025 [Maxim Yudayev](https://yudayev.com), all rights reserved.

The logo is trademark (or service mark) of Maxim Yudayev and is licensed under the 
Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (CC BY-NC-ND 4.0).

Use of this logo does not constitute an endorsement by Maxim Yudayev.

Any commercial use, modification, or use in a manner that suggests endorsement or association 
with the project's source or origin is strictly prohibited without a separate written agreement.
