## Changelog 

### Fixed

- Using `cdf data upload dir` no longer fails on Canvas that have
missing resources.
- Using `cdf data download canvas` now skips references that does not
exists in CDF.