"""FAISS vector-store provider implementation."""

from __future__ import annotations

import logging
import os

from agentfoundry.utils.config import Config
from agentfoundry.vectorstores.base import VectorStore
from agentfoundry.vectorstores.factory import VectorStoreFactory

logger = logging.getLogger(__name__)


@VectorStoreFactory.register_provider("faiss")
class FAISSVectorStoreProvider(VectorStore):
    """Local persistent FAISS index wrapped as a LangChain VectorStore."""

    _instance = None

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self, **kwargs):
        if getattr(self, "_initialized", False):
            return
        super().__init__(**kwargs)

        from langchain_community.vectorstores import FAISS  # local import to delay heavy deps
        from langchain_openai.embeddings import OpenAIEmbeddings

        cfg = Config()

        # Resolve index path; treat empty/whitespace as unset and use a sensible default
        raw_path = cfg.get("FAISS.INDEX_PATH", None)
        index_path: str = str(raw_path or "").strip()
        if not index_path:
            try:
                data_dir = cfg.get("DATA_DIR")
                index_path = os.path.join(data_dir, "faiss_index")
            except Exception:
                index_path = "./faiss_index"
        embeddings = OpenAIEmbeddings()

        if os.path.exists(index_path):
            logger.info(f"Loading FAISS index from {index_path}")
            self._store = FAISS.load_local(index_path, embeddings, allow_dangerous_deserialization=True)
        else:
            raise RuntimeError(f"FAISS index not found at '{index_path}'. Initialize the index with real data before use.")
        self._initialized = True

    def get_store(self, *args, **kwargs):
        logger.debug("FAISSVectorStoreProvider.get_store called")
        return self._store
