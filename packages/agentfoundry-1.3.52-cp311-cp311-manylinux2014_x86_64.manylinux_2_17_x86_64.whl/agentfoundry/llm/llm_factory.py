__author__ = "Chris Steel"
__copyright__ = "Copyright 2023, Syntheticore Corporation"
__credits__ = ["Chris Steel"]
__date__ = "2/9/2025"
__license__ = "Syntheticore Confidential"
__version__ = "1.0"
__email__ = "csteel@syntheticore.com"
__status__ = "Production"

import logging
import sys
import os

from langchain_openai import ChatOpenAI

from agentfoundry.llm.ollama_llm import OllamaLLM
from agentfoundry.utils.config import load_config

# Try to import AgentConfig for typing (optional to avoid circular deps if any)
try:
    from agentfoundry.utils.agent_config import AgentConfig
except ImportError:
    AgentConfig = None

logger = logging.getLogger(__name__)


class LLMFactory:
    """Singleton factory caching LLM clients per (provider, model, api_key_hash)."""

    _instance = None
    _CACHE: dict[tuple[str, str, str], object] = {}
    _LOGGED_CONFIG_ONCE: bool = False

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    @staticmethod
    def get_llm_model(provider: str | None = None, llm_model: str | None = None, config: AgentConfig | None = None):
        """
        Returns an instance of an LLM based on configuration.

        Args:
            provider: Explicit provider override (e.g. 'openai').
            llm_model: Explicit model override (e.g. 'gpt-4').
            config: An AgentConfig object containing credentials and settings.
                    If provided, this takes precedence over global config/env vars.
        """
        # Determine source of truth
        if config:
            provider = provider or config.llm.provider
            llm_model = llm_model or config.llm.model_name
            api_key_val = config.get_api_key() or ""
            api_base = config.llm.api_base
        else:
            # Fallback to global config singleton
            legacy_cfg = load_config()
            provider = provider or legacy_cfg.get("LLM_PROVIDER", "openai")
            llm_model = llm_model or legacy_cfg.get("OPENAI_MODEL") or legacy_cfg.get("OLLAMA.MODEL") or "o4-mini"
            # Attempt to find API key in legacy config/env
            if provider == "openai":
                api_key_val = legacy_cfg.get("OPENAI_API_KEY", "")
            elif provider == "grok":
                api_key_val = os.getenv("XAI_API_KEY") or legacy_cfg.get("XAI_API_KEY", "")
            elif provider == "gemini":
                api_key_val = legacy_cfg.get("GEMINI_API_KEY") or legacy_cfg.get("GOOGLE_API_KEY") or os.getenv("GOOGLE_API_KEY", "")
            else:
                api_key_val = ""
            api_base = legacy_cfg.get("OLLAMA.HOST") if provider == "ollama" else None

        # Create a cache key that includes the API key (hashed or raw) to prevent tenant leakage
        cache_key = (str(provider), str(llm_model), str(api_key_val))
        
        if cache_key in LLMFactory._CACHE:
            return LLMFactory._CACHE[cache_key]

        logger.info(f"Creating LLM model: provider={provider} model={llm_model}")

        if provider == "ollama":
            model_name = llm_model or "gemma3:27b"
            host = api_base or "http://127.0.0.1:11434"
            try:
                llm = OllamaLLM(model=model_name, base_url=host)
                LLMFactory._CACHE[cache_key] = llm
                return llm
            except Exception as e:
                logger.error(f"Failed to create ChatOllama LLM: {e}")
                raise

        elif provider == "openai":
            if not api_key_val:
                raise ValueError("OPENAI_API_KEY must be provided for OpenAI LLM.")
            
            # Temperature handling
            restricted_prefixes = ("o1", "o2", "o3", "o4", "gpt-4o")
            temp_cfg = os.getenv("TEMPERATURE", "")
            pass_temperature = True
            if isinstance(llm_model, str) and llm_model.lower().startswith(restricted_prefixes):
                pass_temperature = False
            if temp_cfg in (None, ""):
                pass_temperature = False
            
            try:
                temperature = float(temp_cfg) if pass_temperature else None
                if temperature is None:
                    llm = ChatOpenAI(model=llm_model, api_key=api_key_val)
                else:
                    llm = ChatOpenAI(model=llm_model, api_key=api_key_val, temperature=temperature)
                LLMFactory._CACHE[cache_key] = llm
                return llm
            except Exception as e:
                logger.error(f"Failed to create OpenAI LLM: {e}")
                raise

        elif provider == "grok":
            if not api_key_val:
                raise ValueError("XAI_API_KEY must be provided for Grok LLM.")
            # Return logging-enabled ChatXAI to integrate cleanly with LangGraph
            from agentfoundry.llm.grok_chatxai_logging import LoggingChatXAI
            llm = LoggingChatXAI(model=llm_model, api_key=api_key_val)
            LLMFactory._CACHE[cache_key] = llm
            return llm

        elif provider == "gemini":
            from agentfoundry.llm.gemini_llm import GeminiLLM
            if not api_key_val:
                raise ValueError("GEMINI_API_KEY must be provided for Gemini LLM.")
            llm = GeminiLLM(model=llm_model, api_key=api_key_val)
            LLMFactory._CACHE[cache_key] = llm
            return llm

        else:
            raise ValueError(f"Unknown LLM provider: {provider}")


if __name__ == "__main__":
    # Quick test
    logging.basicConfig(level=logging.INFO)
    try:
        openai_llm = LLMFactory.get_llm_model(provider="openai")
        print("OpenAI LLM:", openai_llm)
    except Exception as e:
        print(f"Skipping OpenAI test: {e}")