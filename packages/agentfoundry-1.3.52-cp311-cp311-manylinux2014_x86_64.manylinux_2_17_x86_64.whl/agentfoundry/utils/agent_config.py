from __future__ import annotations

import os
from pathlib import Path
from typing import Optional, Dict, Any, Union

from pydantic import BaseModel, Field, SecretStr, model_validator

# Try to import Config for backward compatibility defaults
try:
    from agentfoundry.utils.config import Config
    _HAS_LEGACY_CONFIG = True
except ImportError:
    _HAS_LEGACY_CONFIG = False


class VectorStoreConfig(BaseModel):
    provider: str = "milvus"
    collection_name: str = "agentfoundry"
    url: Optional[str] = None
    persist_dir: Optional[str] = None
    api_key: Optional[SecretStr] = None
    index_path: Optional[str] = None # For FAISS


class LLMConfig(BaseModel):
    provider: str = "openai"
    model_name: str = "gpt-4o"
    api_key: Optional[SecretStr] = None
    api_base: Optional[str] = None
    # Provider-specific extras (e.g. Ollama host)
    extra_params: Dict[str, Any] = Field(default_factory=dict)


class AgentConfig(BaseModel):
    """
    Explicit configuration object for AgentFoundry Orchestrator.
    
    This replaces the implicit global singleton for library usage.
    """
    # Identity & Scope
    org_id: str = "default"
    user_id: str = "default_user"
    thread_id: str = "default_thread"
    security_level: int = 0

    # Components
    llm: LLMConfig = Field(default_factory=LLMConfig)
    vector_store: VectorStoreConfig = Field(default_factory=VectorStoreConfig)
    
    # Paths (if using local storage)
    data_dir: Optional[Path] = None
    tools_dir: Optional[Path] = None
    
    # Global settings
    log_level: str = "INFO"
    
    # Allow arbitrary extra config for plugins
    extra: Dict[str, Any] = Field(default_factory=dict)

    @classmethod
    def from_legacy_config(cls) -> "AgentConfig":
        """
        Factory to create an AgentConfig from the existing global/env system.
        Useful for backward compatibility or CLI usage.
        """
        if not _HAS_LEGACY_CONFIG:
            return cls()
            
        legacy = Config()
        
        # Helper to safely get from legacy
        def get(k, default=None):
            try:
                return legacy.get(k, default)
            except Exception:
                return default

        # Map legacy keys to new structure
        return cls(
            org_id=get("ORG_ID", "default"),
            llm=LLMConfig(
                provider=get("LLM_PROVIDER", "openai"),
                model_name=get("OPENAI_MODEL") or get("OLLAMA.MODEL") or "gpt-4o",
                api_key=SecretStr(get("OPENAI_API_KEY") or get("GEMINI_API_KEY") or "") if (get("OPENAI_API_KEY") or get("GEMINI_API_KEY")) else None,
                api_base=get("OLLAMA.HOST") if get("LLM_PROVIDER") == "ollama" else None
            ),
            vector_store=VectorStoreConfig(
                provider=get("VECTORSTORE.PROVIDER", "milvus"),
                url=get("CHROMA.URL"),
                persist_dir=get("CHROMADB_PERSIST_DIR"),
                index_path=get("FAISS.INDEX_PATH")
            ),
            data_dir=Path(get("DATA_DIR")) if get("DATA_DIR") else None,
            tools_dir=Path(get("TOOLS_DIR")) if get("TOOLS_DIR") else None,
            log_level=get("LOGGING.LEVEL", "INFO")
        )

    def get_api_key(self) -> Optional[str]:
        """Helper to get the raw API key string."""
        return self.llm.api_key.get_secret_value() if self.llm.api_key else None
