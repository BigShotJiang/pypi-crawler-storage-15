import time
from typing import Any, Optional
from loguru import logger
from ohcs.lcm.models import DTemplate, VmInfo
from ohcs.lcm.utils import DemoStore
from ohcs.utils import PluginException

_demo = DemoStore()


def _get_vm(template: DTemplate, vmId: str) -> VmInfo:
    vm = _demo.get(template.id, vmId)
    if not vm:
        raise PluginException(f"VM not found: {template.id}/{vmId}")
    return vm


def init() -> Optional[dict[str, Any]]:
    logger.info("Initializing demo plugin")
    return None


def health(template: DTemplate, params: dict[str, Any]) -> dict[str, Any]:
    return _demo.get_state()


def prepare_template(template: DTemplate, params: dict[str, Any]) -> Optional[dict[str, Any]]:
    pass


def destroy_template(template: DTemplate, params: dict[str, Any]) -> None:
    _demo.remove_template(template.id)


def list_vms(template: DTemplate, params: dict[str, Any]) -> list[VmInfo]:
    return _demo.list_vms(template.id)


def get_vm(template: DTemplate, vmId: str) -> VmInfo:
    return _get_vm(template, vmId)


def create_vm(template: DTemplate, vmId: str, params: dict[str, Any]) -> VmInfo:
    vm = VmInfo(id=vmId, cloudId=vmId, powerState="PoweredOn")

    # With real deployment, the following custom_data must be properly placed in the guest OS as:
    #   file: C:\AzureData\CustomData.bin
    #   Owner of the file: SYSTEM
    custom_data = params["customData"]  # noqa: F841

    # simulate long running operation
    time.sleep(10)

    _demo.add(template.id, vmId, vm)
    return vm


def delete_vm(template: DTemplate, vmId: str, params: dict[str, Any]) -> None:
    _demo.remove(template.id, vmId)


def power_on_vm(template: DTemplate, vmId: str, params: dict[str, Any]) -> VmInfo:
    vm = _get_vm(template, vmId)
    vm.powerState = "PoweredOn"
    return vm


def power_off_vm(template: DTemplate, vmId: str, params: dict[str, Any]) -> VmInfo:
    vm = _get_vm(template, vmId)
    vm.powerState = "PoweredOff"
    return vm


def restart_vm(template: DTemplate, vmId: str, params: dict[str, Any]) -> VmInfo:
    vm = _get_vm(template, vmId)
    vm.powerState = "PoweredOn"
    return vm


def shutdown_vm(template: DTemplate, vmId: str, params: dict[str, Any]) -> VmInfo:
    vm = _get_vm(template, vmId)
    vm.powerState = "PoweredOff"
    return vm
