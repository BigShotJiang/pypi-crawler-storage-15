"""Playwright configuration constants."""

# Default timeout for all Playwright actions (ms)
DEFAULT_TIMEOUT = 5000
