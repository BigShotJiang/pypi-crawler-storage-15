# flake8: noqa

from skrobot.models.fetch import Fetch
from skrobot.models.kuka import Kuka
from skrobot.models.nextage import Nextage
from skrobot.models.panda import Panda
from skrobot.models.pr2 import PR2
from skrobot.models.r8_6 import R8_6
