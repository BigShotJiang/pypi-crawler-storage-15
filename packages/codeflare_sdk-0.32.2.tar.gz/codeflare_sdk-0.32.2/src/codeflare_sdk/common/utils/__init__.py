"""
Common utilities for the CodeFlare SDK.
"""

from .k8s_utils import get_current_namespace

__all__ = ["get_current_namespace"]
