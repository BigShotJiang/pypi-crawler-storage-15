There is no way to achieve Storck Request and Stock Request Orders. It
should be developed taking into account that only Cancel and Done stock
request can be archived.

It is also required to manage active field logically from Orders to SRs.
