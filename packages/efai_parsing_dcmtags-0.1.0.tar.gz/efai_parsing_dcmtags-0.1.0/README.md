# efai\_parsing\_dcmtags

This is a simple example package.

