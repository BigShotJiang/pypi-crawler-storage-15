from __future__ import annotations

from pathlib import Path
from typing import Literal, Optional, TextIO

from .core.integrate import extract_workbook
from .core.cells import set_table_detection_params
from .engine import ExStructEngine, OutputOptions, StructOptions
from .io import save_as_json, save_as_toon, save_as_yaml, save_sheets, serialize_workbook
from .models import CellRow, Chart, ChartSeries, Shape, SheetData, WorkbookData
from .render import export_pdf, export_sheet_images

__all__ = [
    "extract",
    "export",
    "export_sheets",
    "export_pdf",
    "export_sheet_images",
    "process_excel",
    "ExtractionMode",
    "CellRow",
    "Shape",
    "ChartSeries",
    "Chart",
    "SheetData",
    "WorkbookData",
    "set_table_detection_params",
    "ExStructEngine",
    "StructOptions",
    "OutputOptions",
]


ExtractionMode = Literal["light", "standard", "verbose"]


def extract(file_path: str | Path, mode: ExtractionMode = "standard") -> WorkbookData:
    """Extract workbook semantic structure and return WorkbookData."""
    include_links = True if mode == "verbose" else False
    engine = ExStructEngine(options=StructOptions(mode=mode, include_cell_links=include_links))
    return engine.extract(file_path, mode=mode)


def export(
    data: WorkbookData,
    path: str | Path,
    fmt: Optional[Literal["json", "yaml", "yml", "toon"]] = None,
    *,
    pretty: bool = False,
    indent: int | None = None,
) -> None:
    """Export WorkbookData to supported file formats (json/yaml/toon)."""
    dest = Path(path)
    format_hint = (fmt or dest.suffix.lstrip(".") or "json").lower()
    match format_hint:
        case "json":
            save_as_json(data, dest, pretty=pretty, indent=indent)
        case "yaml" | "yml":
            save_as_yaml(data, dest)
        case "toon":
            save_as_toon(data, dest)
        case _:
            raise ValueError(f"Unsupported export format: {format_hint}")


def export_sheets(data: WorkbookData, dir_path: str | Path) -> dict[str, Path]:
    """
    Export each sheet as a JSON file (book_name + SheetData) into a directory.
    Returns a mapping of sheet name to written path.
    """
    return save_sheets(data, Path(dir_path), fmt="json")


def export_sheets_as(
    data: WorkbookData,
    dir_path: str | Path,
    fmt: Literal["json", "yaml", "yml", "toon"] = "json",
    *,
    pretty: bool = False,
    indent: int | None = None,
) -> dict[str, Path]:
    """
    Export each sheet in the given format (json/yaml/toon), including book_name and SheetData; returns sheet name → path map.
    """
    return save_sheets(data, Path(dir_path), fmt=fmt, pretty=pretty, indent=indent)


def process_excel(
    file_path: Path,
    output_path: Path | None = None,
    out_fmt: str = "json",
    image: bool = False,
    pdf: bool = False,
    dpi: int = 72,
    mode: ExtractionMode = "standard",
    pretty: bool = False,
    indent: int | None = None,
    sheets_dir: Path | None = None,
    stream: TextIO | None = None,
) -> None:
    """
    Convenience wrapper for CLI: export workbook and optionally PDF/PNG images (Excel required for rendering).
    - If output_path is None, writes the serialized workbook to stdout (or provided stream).
    - If sheets_dir is given, also writes per-sheet files into that directory.
    """
    engine = ExStructEngine(
        options=StructOptions(mode=mode),
        output=OutputOptions(fmt=out_fmt, pretty=pretty, indent=indent, sheets_dir=sheets_dir, stream=stream),
    )
    engine.process(
        file_path=file_path,
        output_path=output_path,
        out_fmt=out_fmt,
        image=image,
        pdf=pdf,
        dpi=dpi,
        mode=mode,
        pretty=pretty,
        indent=indent,
        sheets_dir=sheets_dir,
        stream=stream,
    )
