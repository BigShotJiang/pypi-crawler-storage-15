# Obra Client

LLM Proxy Client with prompt enrichment for Obra Firebase SaaS deployment.

## Installation

```bash
pip install obra-client
```

## Quick Start

```bash
# First-time setup
obra-client setup

# Start orchestration
obra-client orchestrate "Add user authentication"

# Check session status
obra-client status SESSION_ID
```
