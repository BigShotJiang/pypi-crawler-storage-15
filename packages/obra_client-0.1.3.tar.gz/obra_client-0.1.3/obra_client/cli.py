"""CLI entry point for Obra Client."""

import json
import os
import sys
import time
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

from obra_client import __version__
from obra_client.api_client import APIClient
from obra_client.exceptions import APIError, ConfigurationError, ExecutionError
from obra_client.executor import ClaudeCodeExecutor
from obra_client.prompt_enricher import PromptEnricher
from obra_client.session_manager import SessionManager

app = typer.Typer(
    name="obra-client",
    help="Obra SaaS Client - LLM Proxy with prompt enrichment for Cloud Functions orchestration",
    add_completion=False,
)

console = Console()


def load_config() -> dict:
    """Load configuration from ~/.obra/client-config.yaml.

    Returns:
        Configuration dictionary

    Raises:
        ConfigurationError: If config file doesn't exist or is invalid
    """
    config_path = Path.home() / ".obra" / "client-config.yaml"

    if not config_path.exists():
        raise ConfigurationError(
            f"Configuration file not found: {config_path}\n"
            "Run 'obra-client setup' to create it."
        )

    import yaml

    try:
        with open(config_path) as f:
            config = yaml.safe_load(f)
            return config or {}
    except Exception as e:
        raise ConfigurationError(f"Failed to load config: {e}") from e


@app.command()
def setup() -> None:
    """Run first-time setup and configuration.

    Creates ~/.obra/client-config.yaml with:
    - Firebase project ID
    - API base URL
    - License key (for authentication)
    - User ID
    - Project ID (optional)
    - Claude Code CLI path (optional)
    """
    import yaml

    config_path = Path.home() / ".obra" / "client-config.yaml"

    console.print("\n[bold]🔧 Obra Client Setup[/bold]")
    console.print("=" * 50)

    # Check if config already exists
    if config_path.exists():
        console.print(f"\n[yellow]⚠️  Configuration file already exists:[/yellow] {config_path}")
        overwrite = typer.confirm("Overwrite existing configuration?", default=False)
        if not overwrite:
            console.print("[dim]Setup cancelled[/dim]")
            raise typer.Exit(0)

    console.print("\n[bold]Step 1: API Configuration[/bold]")

    # API Base URL
    default_api_url = "https://us-central1-obra-205b0.cloudfunctions.net"
    api_base_url = typer.prompt(
        "API Base URL",
        default=default_api_url,
        show_default=True,
    )

    console.print("\n[bold]Step 2: Authentication[/bold]")

    # License key (will be used to get auth token)
    license_key = typer.prompt(
        "License Key (from beta invitation)",
        hide_input=True,
    )

    # User ID
    user_id = typer.prompt(
        "User ID (email or unique identifier)",
    )

    console.print("\n[bold]Step 3: Project Configuration (Optional)[/bold]")

    # Project ID (optional)
    project_id = typer.prompt(
        "Default Project ID",
        default="default",
        show_default=True,
    )

    # Claude Code CLI path (optional)
    claude_code_path = typer.prompt(
        "Claude Code CLI path (leave empty for auto-detect)",
        default="",
        show_default=False,
    )

    # Build configuration
    config = {
        "api_base_url": api_base_url,
        "license_key": license_key,
        "user_id": user_id,
        "project_id": project_id if project_id != "default" else None,
        "claude_code_path": claude_code_path if claude_code_path else None,
    }

    # Create .obra directory if needed
    config_path.parent.mkdir(parents=True, exist_ok=True)

    # Save configuration
    try:
        with open(config_path, "w") as f:
            yaml.safe_dump(config, f, default_flow_style=False, sort_keys=False)

        console.print(f"\n[green]✓[/green] Configuration saved to: {config_path}")

        # Verify API connectivity
        console.print("\n[bold]Verifying API connectivity...[/bold]")

        try:
            api_client = APIClient(
                base_url=config["api_base_url"],
                auth_token=None,  # Not authenticated yet
            )

            # Check health endpoint (doesn't require auth)
            health = api_client.health_check()
            console.print(f"[green]✓[/green] API is reachable (status: {health['status']})")

            # Check version
            version_info = api_client.get_version()
            console.print(
                f"[green]✓[/green] API Version: {version_info['api_version']}"
            )

            # Check client compatibility
            client_version = __version__
            min_version = version_info.get("min_client_version", "0.1.0")

            if client_version < min_version:
                console.print(
                    f"\n[yellow]⚠️  Warning: Your client version ({client_version}) "
                    f"is below minimum required ({min_version})[/yellow]"
                )
                console.print("[dim]Consider upgrading: pip install --upgrade obra-client[/dim]")

        except APIError as e:
            console.print(f"[yellow]⚠️  Warning: Could not verify API connectivity:[/yellow] {e}")
            console.print("[dim]You can still use the client, but check your API base URL[/dim]")

        console.print("\n[bold green]✨ Setup complete![/bold green]")
        console.print("\n[bold]Next steps:[/bold]")
        console.print("  1. Ensure ANTHROPIC_API_KEY environment variable is set")
        console.print("  2. Run: obra-client orchestrate \"your task description\"")
        console.print("\n[dim]Configuration can be edited at:[/dim]")
        console.print(f"[dim]{config_path}[/dim]")

    except Exception as e:
        console.print(f"\n[red]❌ Failed to save configuration:[/red] {e}")
        raise typer.Exit(1)


@app.command()
def orchestrate(
    objective: str,
    project_dir: Optional[str] = None,
    task_type: str = "feature",
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show detailed debug output"),
) -> None:
    """Start orchestration session with Cloud Functions.

    Args:
        objective: Task objective (e.g., "Add user authentication")
        project_dir: Project directory (default: current directory)
        task_type: Type of task (feature, bug_fix, refactor, etc.)
        verbose: Show detailed debug output including server responses

    Example:
        obra-client orchestrate "Add rate limiting to API"
        obra-client orchestrate "Fix login bug" --task-type bug_fix
        obra-client orchestrate "Add feature" --verbose
    """
    try:
        # Load configuration
        config = load_config()

        # Determine project directory
        working_dir = Path(project_dir or os.getcwd()).resolve()

        if not working_dir.exists():
            console.print(f"[red]❌ Project directory not found: {working_dir}[/red]")
            raise typer.Exit(1)

        console.print(f"\n[bold]🚀 Starting Orchestration[/bold]")
        console.print(f"[dim]Objective:[/dim] {objective}")
        console.print(f"[dim]Project:[/dim] {working_dir}")
        console.print(f"[dim]Type:[/dim] {task_type}\n")

        # Initialize components
        # Use from_config() to enable automatic license key exchange
        api_client = APIClient.from_config()

        enricher = PromptEnricher()

        executor = ClaudeCodeExecutor(
            claude_code_path=config.get("claude_code_path"),
        )

        session_manager = SessionManager()

        # Step 1: Start orchestration session
        console.print("[bold]📡 Contacting server...[/bold]")

        session_response = api_client.orchestrate(
            user_id=config["user_id"],
            project_id=config.get("project_id", "default"),
            working_dir=str(working_dir),
            objective=objective,
            task_type=task_type,
        )

        session_id = session_response["session_id"]
        base_prompt = session_response["base_prompt"]

        console.print(f"[green]✓[/green] Session created: [dim]{session_id}[/dim]\n")

        if verbose:
            console.print("[dim]─── Server Response ───[/dim]")
            console.print(f"[dim]  Status: {session_response.get('status', 'N/A')}[/dim]")
            console.print(f"[dim]  Base prompt: {len(base_prompt)} chars[/dim]")
            if session_response.get("metadata"):
                console.print(f"[dim]  Metadata: {json.dumps(session_response['metadata'], indent=2)}[/dim]")
            console.print("[dim]───────────────────────[/dim]\n")

        # Save checkpoint for resume capability
        session_manager.save_checkpoint(
            session_id=session_id,
            objective=objective,
            task_type=task_type,
            project_dir=str(working_dir),
            iteration=1,
            status="active",
        )

        # Orchestration loop
        iteration = 1
        max_iterations = 20  # Safety limit

        while iteration <= max_iterations:
            iteration_start = time.time()
            console.print(f"[bold]🔄 Iteration {iteration}[/bold]")

            # Step 2: Enrich prompt with local context
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                task = progress.add_task("Enriching prompt with local context...", total=None)
                enriched_prompt = enricher.enrich_prompt(base_prompt, str(working_dir))
                progress.update(task, completed=True)

            console.print(f"[green]✓[/green] Prompt enriched (~{len(enriched_prompt)} chars)\n")

            if verbose:
                console.print(f"[dim]  Base prompt: {len(base_prompt)} chars[/dim]")
                console.print(f"[dim]  Enriched prompt: {len(enriched_prompt)} chars[/dim]")
                console.print(f"[dim]  Context added: +{len(enriched_prompt) - len(base_prompt)} chars[/dim]")

            # Step 3: Execute LLM
            console.print("[bold]🤖 Executing with Claude Code...[/bold]")

            result = executor.execute(
                prompt=enriched_prompt,
                working_dir=working_dir,
            )

            if not result.success:
                console.print(f"[red]❌ LLM execution failed (exit code {result.exit_code})[/red]")
                console.print(f"[dim]{result.stderr}[/dim]")

                # Submit failure to server
                api_client.llm_result(
                    session_id=session_id,
                    result=result.stdout or result.stderr,
                    status="failure",
                )
                raise typer.Exit(1)

            console.print(f"[green]✓[/green] LLM execution complete\n")

            # Step 4: Submit result to server
            console.print("[bold]📤 Submitting result...[/bold]")

            server_response = api_client.llm_result(
                session_id=session_id,
                result=result.stdout,
                status="success",
            )

            action = server_response["action"]
            iteration_time = time.time() - iteration_start

            if verbose:
                console.print("[dim]─── Server Response ───[/dim]")
                console.print(f"[dim]  Action: {action}[/dim]")
                console.print(f"[dim]  Iteration: {server_response.get('iteration', 'N/A')}[/dim]")
                if server_response.get("feedback"):
                    console.print(f"[dim]  Feedback: {server_response['feedback']}[/dim]")
                if action == "continue" and server_response.get("base_prompt"):
                    console.print(f"[dim]  Next prompt: {len(server_response['base_prompt'])} chars[/dim]")
                console.print(f"[dim]  Iteration time: {iteration_time:.1f}s[/dim]")
                console.print("[dim]───────────────────────[/dim]")

            # Handle server response
            if action == "complete":
                console.print("\n[bold green]✨ Task completed successfully![/bold green]")
                console.print(f"[dim]{server_response.get('message', '')}[/dim]")
                if verbose:
                    console.print(f"[dim]Total iterations: {iteration}[/dim]")
                # Clear checkpoint on successful completion
                session_manager.clear_checkpoint()
                raise typer.Exit(0)

            elif action == "continue":
                # Server wants another iteration
                base_prompt = server_response["base_prompt"]
                console.print(f"[yellow]→[/yellow] Continuing to iteration {iteration + 1}...\n")
                iteration += 1
                # Update checkpoint with new iteration
                session_manager.update_iteration(iteration)

            elif action == "error":
                console.print(f"\n[red]❌ Server error:[/red] {server_response.get('message', 'Unknown error')}")
                raise typer.Exit(1)

            else:
                console.print(f"\n[red]❌ Unknown server action:[/red] {action}")
                raise typer.Exit(1)

        # Max iterations reached
        console.print(f"\n[yellow]⚠️  Maximum iterations ({max_iterations}) reached[/yellow]")
        console.print("[dim]Task may be incomplete. Check session status.[/dim]")
        raise typer.Exit(1)

    except ConfigurationError as e:
        console.print(f"\n[red]❌ Configuration Error:[/red] {e}")
        raise typer.Exit(1)

    except APIError as e:
        console.print(f"\n[red]❌ API Error:[/red] {e}")
        if e.status_code:
            console.print(f"[dim]Status code: {e.status_code}[/dim]")
        raise typer.Exit(1)

    except ExecutionError as e:
        console.print(f"\n[red]❌ Execution Error:[/red] {e}")
        raise typer.Exit(1)

    except KeyboardInterrupt:
        console.print("\n\n[yellow]⚠️  Interrupted by user[/yellow]")
        console.print(f"[dim]Session {session_id} is still active on server[/dim]")
        console.print(f"[dim]Resume with: obra-client resume {session_id}[/dim]")
        raise typer.Exit(130)

    except typer.Exit:
        # Re-raise typer.Exit without treating it as an error
        # (typer.Exit inherits from RuntimeError, so it's caught by Exception)
        raise

    except Exception as e:
        console.print(f"\n[red]❌ Unexpected Error:[/red] {e}")
        raise typer.Exit(1)


@app.command()
def status(session_id: str) -> None:
    """Query orchestration session status.

    Args:
        session_id: Session ID from /orchestrate call

    Example:
        obra-client status abc123-def456-ghi789
    """
    try:
        config = load_config()

        # Use from_config() to enable automatic license key exchange
        api_client = APIClient.from_config()

        console.print(f"\n[bold]📊 Session Status[/bold]")
        console.print(f"[dim]Session ID:[/dim] {session_id}\n")

        response = api_client.get_status(session_id)

        console.print(f"[bold]Status:[/bold] {response['status']}")
        console.print(f"[bold]Iteration:[/bold] {response['current_iteration']}")
        console.print(f"[bold]Objective:[/bold] {response['objective']}")
        console.print(f"[bold]Type:[/bold] {response['task_type']}")

        raise typer.Exit(0)

    except ConfigurationError as e:
        console.print(f"\n[red]❌ Configuration Error:[/red] {e}")
        raise typer.Exit(1)

    except APIError as e:
        console.print(f"\n[red]❌ API Error:[/red] {e}")
        raise typer.Exit(1)


@app.command()
def resume(session_id: Optional[str] = None) -> None:
    """Resume interrupted orchestration session.

    Args:
        session_id: Session ID to resume (optional, will use last checkpoint if not provided)

    Example:
        obra-client resume                    # Resume last session
        obra-client resume abc123-def456      # Resume specific session
    """
    try:
        config = load_config()
        session_manager = SessionManager()

        # Load checkpoint
        checkpoint = session_manager.load_checkpoint()

        if not checkpoint:
            console.print("[yellow]⚠️  No saved session found[/yellow]")
            console.print("[dim]Run 'obra-client orchestrate' to start a new session[/dim]")
            raise typer.Exit(1)

        # Use provided session_id or checkpoint's session_id
        target_session_id = session_id or checkpoint.session_id

        # Initialize API client
        # Use from_config() to enable automatic license key exchange
        api_client = APIClient.from_config()

        # Check if session can be resumed
        console.print(f"\n[bold]🔄 Resuming Session[/bold]")
        console.print(f"[dim]Session ID:[/dim] {target_session_id}")
        console.print(f"[dim]Objective:[/dim] {checkpoint.objective}")
        console.print(f"[dim]Last Iteration:[/dim] {checkpoint.iteration}\n")

        # Verify session is still active
        try:
            status_response = api_client.get_status(target_session_id)

            if status_response["status"] != "active":
                console.print(
                    f"[yellow]⚠️  Session is {status_response['status']}, cannot resume[/yellow]"
                )
                session_manager.clear_checkpoint()
                raise typer.Exit(1)

        except APIError as e:
            console.print(f"[red]❌ Session not found on server:[/red] {e}")
            session_manager.clear_checkpoint()
            raise typer.Exit(1)

        # Ask user to confirm resume
        confirm = typer.confirm("Resume this session?", default=True)
        if not confirm:
            console.print("[dim]Resume cancelled[/dim]")
            raise typer.Exit(0)

        console.print("[green]✓[/green] Resuming session...\n")

        # Get continuation prompt from server
        console.print("[bold]📡 Fetching continuation prompt...[/bold]")
        resume_response = api_client.resume(target_session_id)

        base_prompt = resume_response["base_prompt"]
        iteration = resume_response.get("iteration", checkpoint.iteration)

        console.print(f"[green]✓[/green] Got continuation prompt (iteration {iteration})\n")

        # Initialize executor and enricher
        enricher = PromptEnricher()
        executor = ClaudeCodeExecutor(
            claude_code_path=config.get("claude_code_path"),
        )

        # Get working directory from checkpoint
        working_dir = Path(checkpoint.project_dir).resolve()

        # Orchestration loop (same as orchestrate command)
        max_iterations = 20  # Safety limit

        while iteration <= max_iterations:
            iteration_start = time.time()
            console.print(f"[bold]🔄 Iteration {iteration}[/bold]")

            # Enrich prompt with local context
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                task = progress.add_task("Enriching prompt with local context...", total=None)
                enriched_prompt = enricher.enrich_prompt(base_prompt, str(working_dir))
                progress.update(task, completed=True)

            console.print(f"[green]✓[/green] Prompt enriched (~{len(enriched_prompt)} chars)\n")

            # Execute LLM
            console.print("[bold]🤖 Executing with Claude Code...[/bold]")

            result = executor.execute(
                prompt=enriched_prompt,
                working_dir=working_dir,
            )

            if not result.success:
                console.print(f"[red]❌ LLM execution failed (exit code {result.exit_code})[/red]")
                console.print(f"[dim]{result.stderr}[/dim]")

                # Submit failure to server
                api_client.llm_result(
                    session_id=target_session_id,
                    result=result.stdout or result.stderr,
                    status="failure",
                )
                raise typer.Exit(1)

            console.print(f"[green]✓[/green] LLM execution complete\n")

            # Submit result to server
            console.print("[bold]📤 Submitting result...[/bold]")

            server_response = api_client.llm_result(
                session_id=target_session_id,
                result=result.stdout,
                status="success",
            )

            action = server_response["action"]
            iteration_time = time.time() - iteration_start

            console.print(f"[dim]  Iteration time: {iteration_time:.1f}s[/dim]")

            # Handle server response
            if action == "complete":
                console.print("\n[bold green]✨ Task completed successfully![/bold green]")
                console.print(f"[dim]{server_response.get('message', '')}[/dim]")
                # Clear checkpoint on successful completion
                session_manager.clear_checkpoint()
                raise typer.Exit(0)

            elif action == "continue":
                # Server wants another iteration
                base_prompt = server_response["base_prompt"]
                console.print(f"[yellow]→[/yellow] Continuing to iteration {iteration + 1}...\n")
                iteration += 1
                # Update checkpoint with new iteration
                session_manager.update_iteration(iteration)

            elif action == "error":
                console.print(f"\n[red]❌ Server error:[/red] {server_response.get('message', 'Unknown error')}")
                raise typer.Exit(1)

            else:
                console.print(f"\n[red]❌ Unknown server action:[/red] {action}")
                raise typer.Exit(1)

        # Max iterations reached
        console.print(f"\n[yellow]⚠️  Maximum iterations ({max_iterations}) reached[/yellow]")
        console.print("[dim]Task may be incomplete. Check session status.[/dim]")
        raise typer.Exit(1)

    except ConfigurationError as e:
        console.print(f"\n[red]❌ Configuration Error:[/red] {e}")
        raise typer.Exit(1)

    except APIError as e:
        console.print(f"\n[red]❌ API Error:[/red] {e}")
        if e.status_code:
            console.print(f"[dim]Status code: {e.status_code}[/dim]")
        raise typer.Exit(1)

    except ExecutionError as e:
        console.print(f"\n[red]❌ Execution Error:[/red] {e}")
        raise typer.Exit(1)

    except KeyboardInterrupt:
        console.print("\n\n[yellow]⚠️  Interrupted by user[/yellow]")
        console.print(f"[dim]Session {target_session_id} is still active on server[/dim]")
        console.print(f"[dim]Resume with: obra-client resume {target_session_id}[/dim]")
        raise typer.Exit(130)

    except typer.Exit:
        # Re-raise typer.Exit without treating it as an error
        raise

    except Exception as e:
        console.print(f"\n[red]❌ Unexpected Error:[/red] {e}")
        raise typer.Exit(1)


@app.command()
def version() -> None:
    """Display Obra Client version and check server compatibility."""
    console.print(f"[bold]Obra Client[/bold] v{__version__}\n")

    try:
        config = load_config()

        # Use from_config() to enable automatic license key exchange
        api_client = APIClient.from_config()

        console.print("[bold]Checking server compatibility...[/bold]")
        server_version = api_client.get_version()

        console.print(f"[green]✓[/green] Server API Version: {server_version['api_version']}")
        console.print(f"[dim]Min Client Version:[/dim] {server_version['min_client_version']}")
        console.print(f"[dim]Features:[/dim] {', '.join(server_version['features'])}")

    except ConfigurationError:
        console.print("[yellow]⚠️  No configuration found (run 'obra-client setup')[/yellow]")

    except APIError as e:
        console.print(f"[red]❌ Server unreachable:[/red] {e}")

    raise typer.Exit(0)


@app.command(name="health-check")
def health_check() -> None:
    """Verify Obra installation and configuration.

    Checks:
        - Python version (>= 3.12)
        - Configuration file validity
        - API/Database connectivity
        - Claude Code CLI availability

    Example:
        obra-client health-check
    """
    import shutil
    import subprocess

    console.print("\n[bold]🏥 Obra Health Check[/bold]")
    console.print("=" * 50)

    all_passed = True

    # Check 1: Python Version
    console.print("\n[bold]1. Python Version[/bold]")
    python_version = sys.version_info
    version_str = f"{python_version.major}.{python_version.minor}.{python_version.micro}"

    if python_version >= (3, 12):
        console.print(f"   [green]✓[/green] Python {version_str}")
    else:
        console.print(f"   [red]✗[/red] Python {version_str} (requires 3.12+)")
        console.print(f"   [dim]→ Upgrade Python: https://www.python.org/downloads/[/dim]")
        all_passed = False

    # Check 2: Configuration
    console.print("\n[bold]2. Configuration[/bold]")
    try:
        config = load_config()

        # Validate required fields
        required_fields = ["api_base_url", "license_key", "user_id"]
        missing_fields = [f for f in required_fields if not config.get(f)]

        if missing_fields:
            console.print(f"   [red]✗[/red] Config incomplete (missing: {', '.join(missing_fields)})")
            console.print(f"   [dim]→ Run: obra-client setup[/dim]")
            all_passed = False
        else:
            console.print("   [green]✓[/green] Config valid")

    except ConfigurationError as e:
        console.print(f"   [red]✗[/red] Config error: {e}")
        console.print(f"   [dim]→ Run: obra-client setup[/dim]")
        all_passed = False

    # Check 3: API/Database Connectivity
    console.print("\n[bold]3. API/Database Connectivity[/bold]")
    try:
        config = load_config()

        # Create API client without auth for health check
        api_client = APIClient(
            base_url=config["api_base_url"],
            auth_token=None,
        )

        # Check health endpoint
        health = api_client.health_check()

        if health.get("status") == "healthy":
            console.print(f"   [green]✓[/green] API reachable (Firestore: {health.get('firestore', 'unknown')})")
        else:
            console.print(f"   [yellow]⚠[/yellow] API status: {health.get('status', 'unknown')}")
            all_passed = False

    except ConfigurationError:
        console.print("   [yellow]⚠[/yellow] Skipped (no config)")
        all_passed = False

    except APIError as e:
        console.print(f"   [red]✗[/red] API unreachable: {e}")
        console.print(f"   [dim]→ Check network connection and API URL[/dim]")
        all_passed = False

    except Exception as e:
        console.print(f"   [red]✗[/red] Connection error: {e}")
        console.print(f"   [dim]→ Verify API base URL in config[/dim]")
        all_passed = False

    # Check 4: Claude Code CLI
    console.print("\n[bold]4. Claude Code CLI[/bold]")
    try:
        config = load_config()
        claude_code_path = config.get("claude_code_path") or "claude-code"

        # Check if Claude Code is in PATH or at specified location
        if shutil.which(claude_code_path):
            # Try to get version
            try:
                result = subprocess.run(
                    [claude_code_path, "--version"],
                    capture_output=True,
                    text=True,
                    timeout=5,
                    check=False,
                )

                if result.returncode == 0:
                    version_output = result.stdout.strip() or result.stderr.strip()
                    console.print(f"   [green]✓[/green] Claude Code found ({version_output})")
                else:
                    console.print(f"   [green]✓[/green] Claude Code found at: {shutil.which(claude_code_path)}")

            except subprocess.TimeoutExpired:
                console.print(f"   [yellow]⚠[/yellow] Claude Code found but --version timed out")

        else:
            console.print(f"   [yellow]⚠[/yellow] Claude Code not found in PATH")
            console.print(f"   [dim]→ Install: https://docs.anthropic.com/claude-code[/dim]")
            console.print(f"   [dim]→ Or specify path in config: claude_code_path[/dim]")
            all_passed = False

    except ConfigurationError:
        console.print("   [yellow]⚠[/yellow] Skipped (no config)")
        all_passed = False

    # Summary
    console.print("\n" + "=" * 50)

    if all_passed:
        console.print("[bold green]✨ All checks passed![/bold green]")
        console.print("\n[dim]Your Obra installation is ready to use.[/dim]")
        console.print("[dim]Next: obra-client orchestrate \"your task\"[/dim]")
        raise typer.Exit(0)
    else:
        console.print("[bold yellow]⚠  Some checks failed[/bold yellow]")
        console.print("\n[dim]Fix the issues above, then run health-check again.[/dim]")
        raise typer.Exit(1)


if __name__ == "__main__":
    app()
