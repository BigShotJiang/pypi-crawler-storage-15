"""Obra SaaS Client - LLM Proxy with Prompt Enrichment.

This client connects to Obra Firebase Cloud Functions for orchestration,
enriches prompts with local project context, and executes LLM calls locally.

Architecture:
    - Tier 1 (Server): Strategic context generation (objectives, requirements, validation)
    - Tier 2 (Client): Tactical context injection (files, git, errors)

Usage:
    obra-client setup                     # First-run configuration
    obra-client orchestrate "Add auth"    # Start orchestration session
    obra-client status SESSION_ID         # Check session status
"""

__version__ = "0.1.0"
__author__ = "Omar Unpossible"

from obra_client.exceptions import (
    ObraClientError,
    APIError,
    ConfigurationError,
    ExecutionError,
)

__all__ = [
    "__version__",
    "__author__",
    "ObraClientError",
    "APIError",
    "ConfigurationError",
    "ExecutionError",
]
