"""Prompt enricher with security sanitization for Tier 2 context injection.

Takes base prompts from server (Tier 1 strategic context) and injects
local project context (Tier 2 tactical context) with comprehensive
security sanitization to prevent prompt injection attacks.
"""

import re
from typing import Optional

from obra_client.context_collector import ContextCollector, ProjectContext


# Context injection marker (must match server's CLIENT_CONTEXT_MARKER)
CLIENT_CONTEXT_MARKER = "<!-- CLIENT: Inject local context here -->"


class PromptEnricher:
    """Enriches base prompts with local project context.

    Implements Two-Tier Prompting Architecture:
    - Tier 1 (Server): Strategic context (objectives, requirements, validation)
    - Tier 2 (Client): Tactical context (files, git, errors) - injected here

    Security:
        All user-controlled input is sanitized to prevent prompt injection attacks:
        - Escape markdown special characters
        - Truncate long strings
        - Filter known injection patterns
        - Wrap code/errors in code fences

    Example:
        enricher = PromptEnricher()
        base_prompt = server.get_base_prompt()  # Has CLIENT_CONTEXT_MARKER
        enriched = enricher.enrich_prompt(base_prompt, "/home/user/myproject")
        # enriched prompt now has local context injected
    """

    # Prompt injection attack patterns to filter
    INJECTION_PATTERNS = [
        r"IGNORE\s+(PREVIOUS|ALL|ABOVE)",
        r"DELETE\s+(EVERYTHING|ALL|PREVIOUS)",
        r"SYSTEM\s+PROMPT",
        r"<\|.*?\|>",  # Special tokens
        r"```\s*system",  # System role injection
        r"Assistant:",  # Role confusion
        r"Human:",  # Role confusion
    ]

    # Compile regex patterns
    INJECTION_REGEX = re.compile("|".join(INJECTION_PATTERNS), re.IGNORECASE)

    # Markdown special characters to escape
    MARKDOWN_SPECIAL_CHARS = {
        "*": r"\*",
        "_": r"\_",
        "`": r"\`",
        "[": r"\[",
        "]": r"\]",
        "(": r"\(",
        ")": r"\)",
        "#": r"\#",
        "+": r"\+",
        "-": r"\-",
        ".": r"\.",
        "!": r"\!",
        "|": r"\|",
    }

    def __init__(
        self,
        max_commit_message_length: int = 200,
        max_file_path_length: int = 100,
        max_error_message_length: int = 300,
    ) -> None:
        """Initialize PromptEnricher.

        Args:
            max_commit_message_length: Max length for git commit messages
            max_file_path_length: Max length for file paths
            max_error_message_length: Max length for error messages
        """
        self.max_commit_message_length = max_commit_message_length
        self.max_file_path_length = max_file_path_length
        self.max_error_message_length = max_error_message_length

        self.context_collector = ContextCollector()

    def enrich_prompt(
        self,
        base_prompt: str,
        project_dir: str,
    ) -> str:
        """Inject local context into base prompt with sanitization.

        Args:
            base_prompt: Base prompt from server (Tier 1) with CLIENT_CONTEXT_MARKER
            project_dir: Project directory to collect context from

        Returns:
            Enriched prompt with local context injected

        Raises:
            ValueError: If CLIENT_CONTEXT_MARKER not found in base_prompt
            ValueError: If project_dir doesn't exist
        """
        # Verify marker exists
        if CLIENT_CONTEXT_MARKER not in base_prompt:
            raise ValueError(
                f"Base prompt missing context injection marker: {CLIENT_CONTEXT_MARKER}"
            )

        # Collect project context
        context = self.context_collector.collect_project_context(project_dir)

        # Format and sanitize context
        sanitized_context = self._sanitize_context(context)

        # Inject at marker
        enriched_prompt = base_prompt.replace(CLIENT_CONTEXT_MARKER, sanitized_context)

        return enriched_prompt

    def _sanitize_context(self, context: ProjectContext) -> str:
        """Sanitize project context before injection.

        Args:
            context: Raw project context

        Returns:
            Sanitized context string safe for prompt injection
        """
        # Start with formatted context
        formatted = self.context_collector.format_for_prompt(context)

        # Sanitize each section
        sanitized_lines = []
        in_code_fence = False

        for line in formatted.splitlines():
            # Track code fences (don't sanitize inside them)
            if line.strip().startswith("```"):
                in_code_fence = not in_code_fence
                sanitized_lines.append(line)
                continue

            if not in_code_fence:
                # Sanitize line
                line = self._filter_injection_patterns(line)
                line = self._truncate_line(line)

            sanitized_lines.append(line)

        return "\n".join(sanitized_lines)

    def _filter_injection_patterns(self, text: str) -> str:
        """Filter known prompt injection patterns.

        Args:
            text: Input text

        Returns:
            Text with injection patterns removed
        """
        # Replace injection patterns with [FILTERED]
        filtered = self.INJECTION_REGEX.sub("[FILTERED]", text)

        return filtered

    def _truncate_line(self, line: str, max_length: int = 500) -> str:
        """Truncate long lines to prevent context overflow.

        Args:
            line: Input line
            max_length: Maximum allowed length

        Returns:
            Truncated line if too long
        """
        if len(line) <= max_length:
            return line

        return line[:max_length] + "... [truncated]"

    def _escape_markdown(self, text: str) -> str:
        """Escape markdown special characters.

        Args:
            text: Input text

        Returns:
            Text with markdown characters escaped
        """
        for char, escaped in self.MARKDOWN_SPECIAL_CHARS.items():
            text = text.replace(char, escaped)

        return text

    def _sanitize_file_path(self, path: str) -> str:
        """Sanitize file path for safe inclusion.

        Args:
            path: File path

        Returns:
            Sanitized path
        """
        # Truncate if too long
        if len(path) > self.max_file_path_length:
            path = "..." + path[-(self.max_file_path_length - 3) :]

        # Filter injection patterns
        path = self._filter_injection_patterns(path)

        return path

    def _sanitize_commit_message(self, message: str) -> str:
        """Sanitize git commit message for safe inclusion.

        Args:
            message: Commit message

        Returns:
            Sanitized message
        """
        # Truncate if too long
        if len(message) > self.max_commit_message_length:
            message = message[: self.max_commit_message_length] + "..."

        # Filter injection patterns
        message = self._filter_injection_patterns(message)

        # Escape markdown
        message = self._escape_markdown(message)

        return message

    def _sanitize_error_message(self, message: str) -> str:
        """Sanitize error message for safe inclusion.

        Args:
            message: Error message

        Returns:
            Sanitized message wrapped in code fence
        """
        # Truncate if too long
        if len(message) > self.max_error_message_length:
            message = message[: self.max_error_message_length] + "..."

        # Filter injection patterns
        message = self._filter_injection_patterns(message)

        # Wrap in code fence for safety (prevents markdown parsing)
        return f"```\n{message}\n```"

    @staticmethod
    def verify_enrichment(enriched_prompt: str) -> bool:
        """Verify that prompt was successfully enriched.

        Args:
            enriched_prompt: Enriched prompt to verify

        Returns:
            True if enrichment was successful, False otherwise
        """
        # Check that marker was replaced
        if CLIENT_CONTEXT_MARKER in enriched_prompt:
            return False

        # Check that local context section exists
        if "## Local Context (Provided by Client)" not in enriched_prompt:
            return False

        return True
