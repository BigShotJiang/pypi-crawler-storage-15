"""Unit tests for FileWatcher."""

import tempfile
import time
from pathlib import Path

import pytest

from obra_client.file_watcher import FileInfo, FileWatcher


def test_file_watcher_finds_recent_files():
    """Test that FileWatcher detects recently modified files."""
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create some files
        test_file = Path(tmpdir) / "test.py"
        test_file.write_text("print('hello')")

        # Wait a moment to ensure timestamp difference
        time.sleep(0.1)

        watcher = FileWatcher()
        recent_files = watcher.get_modified_files(tmpdir, since_minutes=1)

        assert len(recent_files) == 1
        assert recent_files[0].relative_path == "test.py"
        assert recent_files[0].size > 0


def test_file_watcher_excludes_patterns():
    """Test that FileWatcher excludes specified patterns."""
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create files (some should be excluded)
        (Path(tmpdir) / "test.py").write_text("code")
        (Path(tmpdir) / "test.pyc").write_text("bytecode")  # Should be excluded
        (Path(tmpdir) / ".DS_Store").write_text("metadata")  # Should be excluded

        watcher = FileWatcher()
        recent_files = watcher.get_modified_files(tmpdir, since_minutes=1)

        # Only test.py should be included
        assert len(recent_files) == 1
        assert recent_files[0].relative_path == "test.py"


def test_file_watcher_respects_time_window():
    """Test that FileWatcher only returns files modified within time window."""
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create a file
        test_file = Path(tmpdir) / "test.py"
        test_file.write_text("code")

        # Look for files modified in last 0 minutes (should find nothing)
        watcher = FileWatcher()
        recent_files = watcher.get_modified_files(tmpdir, since_minutes=0)

        assert len(recent_files) == 0


def test_file_watcher_format_for_prompt():
    """Test prompt formatting."""
    file_info = FileInfo(
        path="/home/user/project/src/main.py",
        relative_path="src/main.py",
        size=1024,
        modified_time=None,  # Not used in formatting
        modified_ago_minutes=5.2,
    )

    watcher = FileWatcher()
    formatted = watcher.format_for_prompt([file_info])

    assert "Recent Files:" in formatted
    assert "src/main.py" in formatted
    assert "5.2m ago" in formatted
    assert "1.0KB" in formatted
