FluidSim Core
=============

Pure-Python core library for [FluidSim](https://fluidsim.readthedocs.io)
framework. This package provides generic base classes and utilities to
build new solvers.

**Documentation**:
<https://fluidsim.readthedocs.io/en/latest/generated/fluidsim_core.html>
