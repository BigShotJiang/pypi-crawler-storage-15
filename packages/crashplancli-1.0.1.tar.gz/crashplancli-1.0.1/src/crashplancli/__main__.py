from crashplancli.main import cli

cli(prog_name="crashplan")
