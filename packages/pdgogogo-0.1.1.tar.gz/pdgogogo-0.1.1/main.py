def main():
    print("Hello from pdgogogo!")


if __name__ == "__main__":
    main()
