class PDGogogo:
    def __init__(self):
        pass

    def hello(self):
        print("Hello, World!")