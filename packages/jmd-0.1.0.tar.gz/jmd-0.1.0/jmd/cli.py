"""Command-line interface for jmd."""
import sys
from . import stream_json_to_md

def cli_entry():
    """Entry point for the jmd command."""
    try:
        for line in stream_json_to_md(sys.stdin):
            print(line)
            sys.stdout.flush()
    except BrokenPipeError:
        pass  # handle `| head` gracefully
    except KeyboardInterrupt:
        pass

if __name__ == "__main__":
    cli_entry()
