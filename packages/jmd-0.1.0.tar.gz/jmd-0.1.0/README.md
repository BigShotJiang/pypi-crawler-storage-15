# jmd - JSON to Markdown

Streaming JSON to Markdown converter using blockquote syntax.

## Installation

```bash
pip install jmd
```

## Usage

### CLI

```bash
# Pipe JSON
cat data.json | jmd

# JSONL
cat records.jsonl | jmd

# With head (streaming)
cat huge.json | jmd | head -20
```

### Python API

```python
from jmd import to_markdown, to_markdown_from_str, stream_json_to_md

# From Python object
md = to_markdown({"name": "Alice", "items": [1, 2, 3]})

# From JSON string
md = to_markdown_from_str('{"key": "value"}')

# Streaming from file
with open("data.json") as f:
    for line in stream_json_to_md(f):
        print(line)
```

## Format

| JSON | Markdown |
|------|----------|
| `{"key": "value"}` | `> key: value  ` |
| `{"key": "has: colon"}` | `> key:  ` + `> > has: colon  ` |
| `{"# list": [...]}` | `> # list:  ` + items |
| `{"bad key": v}` | `> <q>bad key</q>: v  ` |
| `[]`, `{}`, `""` | `[]`, `{}`, `""` (inline) |
| Array items | Separated by `>  ` |
| Multiline strings | depth+1, no separator |

## Example

```json
{"name": "Gilbert", "wins": [["straight\nwin", "7♣"], {"Test": ["8"]}]}
```

```markdown
> name: Gilbert  
> # wins:  
> > > > straight  
> > > > win  
>  
> > > 7♣  
>  
> > > # Test:  
> > > > > 8  
```

## Features

- **Streaming**: O(chunk + max_string + depth) memory
- **C-accelerated**: Uses `json.decoder.scanstring`
- **JSONL support**: Multiple JSON values
- **Pipe-friendly**: Handles `| head` gracefully
