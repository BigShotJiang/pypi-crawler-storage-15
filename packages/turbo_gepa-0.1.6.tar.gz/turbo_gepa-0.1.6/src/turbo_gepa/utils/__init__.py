"""Shared utilities for TurboGEPA."""
