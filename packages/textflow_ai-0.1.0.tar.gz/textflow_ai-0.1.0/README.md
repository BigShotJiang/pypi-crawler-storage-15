# ai_helpers

A simple Python library for AI-like text processing.

## Installation
pip install ai_helpers

## Usage
from ai_helpers import get_response, summarize_text, format_response

print(get_response("Hello"))
