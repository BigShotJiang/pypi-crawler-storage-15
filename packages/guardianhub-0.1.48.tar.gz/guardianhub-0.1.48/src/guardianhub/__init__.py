# src/guardianhub/__init__.py
from ._version import __version__  # version exported for users

from .logging import get_logger,setup_logging
from .utils.app_state import AppState
from .utils.metrics import setup_metrics, get_metrics_registry
from .utils.fastapi_utils import setup_middleware, setup_health_endpoint, setup_metrics_endpoint
from .observability.instrumentation import configure_instrumentation

# Expose public modules (minimal)
__all__ = ["__version__",
           "get_logger","setup_logging",
           "AppState",
           "setup_metrics","get_metrics_registry",
           "setup_middleware","setup_health_endpoint","setup_metrics_endpoint",
           "configure_instrumentation",
           ]