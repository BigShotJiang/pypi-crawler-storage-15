"""Examples package"""
