# "EnCoDaPy" – Energy Control and Data Preparation in Python

The complete documentation can be found here: [GitHub Pages Documentation](https://gewv-tu-dresden.github.io/encodapy/).

<a href="https://tu-dresden.de/ing/maschinenwesen/iet/gewv"> <img alt="TUD GEWV" src="https://github.com/gewv-tu-dresden/encodapy/blob/main/docs/source/logos/GEWV_Logo.svg" height="75"> </a>

2024-2025, TUD Dresden University of Technology, Chair of Building Energy Systems and Heat Supply