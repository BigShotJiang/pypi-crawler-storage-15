from ._bleuscore import *

__doc__ = _bleuscore.__doc__
__all__ = [
    "__version__",
    "tokenizer_regex",
    "tokenizer_13a",
    "compute",
]
