from zap.cli import run

# 方便 python main.py 直接启动
if __name__ == "__main__":
    run()
