"""Ktor 插件管理子命令。"""
from __future__ import annotations

import json
import urllib.error
import urllib.request
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import typer
import click
from rich.console import Console
from rich.text import Text

from .catalog import CatalogManager
from .gradle import GradleManager
from .types import LibrarySpec

app = typer.Typer(help="Ktor 插件管理")
console = Console()


def _confirm_single_key(prompt: str = "确认？", default: bool = False) -> bool:
    """单键确认，无需回车。"""
    hint = r"\[Y/n]" if default else r"\[y/N]"
    console.print(f"  {prompt} [dim]{hint}[/] ", end="")
    char = click.getchar()
    console.print(char)
    if char.lower() == 'y':
        return True
    if char.lower() == 'n':
        return False
    return default

# 缓存
_features_cache: Dict[str, List[dict]] = {}
_default_version: Optional[str] = None


def _get_default_version() -> str:
    """获取 Ktor 默认版本。"""
    global _default_version
    if _default_version:
        return _default_version

    url = "https://start.ktor.io/project/settings"
    try:
        req = urllib.request.Request(url, headers={"Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            _default_version = data.get("ktor_version", {}).get("default_id", "3.0.0")
            return _default_version
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError):
        return "3.0.0"


def _get_project_ktor_version(root: Path) -> Optional[str]:
    """从项目的 version catalog 获取 ktor 版本。"""
    catalog = CatalogManager(root)
    catalog.load()
    return catalog.get_version("ktor")


def _fetch_features(version: str) -> List[dict]:
    """获取指定 Ktor 版本的可用插件列表。"""
    if version in _features_cache:
        return _features_cache[version]

    url = f"https://start.ktor.io/features/{version}"
    try:
        req = urllib.request.Request(url, headers={"Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            _features_cache[version] = data
            return data
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as e:
        console.print(f"  [red]获取 Ktor 插件列表失败: {e}[/]")
        return []


def _xml_id_to_gav(xml_id: str, group: str = None) -> Tuple[str, str]:
    """将 xmlId 转换为 groupId 和 artifactId。"""
    # 根据 group 和命名规则推断
    # 大多数是 io.ktor:ktor-server-{xmlId}
    # 一些特殊情况需要处理

    # 常见映射
    special_mappings = {
        "kotlinx-serialization": ("io.ktor", "ktor-serialization-kotlinx-json"),
        "content-negotiation": ("io.ktor", "ktor-server-content-negotiation"),
        "websockets": ("io.ktor", "ktor-server-websockets"),
        "auth": ("io.ktor", "ktor-server-auth"),
        "auth-jwt": ("io.ktor", "ktor-server-auth-jwt"),
        "sessions": ("io.ktor", "ktor-server-sessions"),
        "call-logging": ("io.ktor", "ktor-server-call-logging"),
        "cors": ("io.ktor", "ktor-server-cors"),
        "default-headers": ("io.ktor", "ktor-server-default-headers"),
        "caching-headers": ("io.ktor", "ktor-server-caching-headers"),
        "compression": ("io.ktor", "ktor-server-compression"),
        "routing": ("io.ktor", "ktor-server-routing"),
        "resources": ("io.ktor", "ktor-server-resources"),
        "status-pages": ("io.ktor", "ktor-server-status-pages"),
        "double-receive": ("io.ktor", "ktor-server-double-receive"),
    }

    if xml_id in special_mappings:
        return special_mappings[xml_id]

    # 默认规则
    return ("io.ktor", f"ktor-server-{xml_id}")


def _search_features(keyword: str, version: str) -> List[dict]:
    """搜索匹配的 Ktor 插件。"""
    features = _fetch_features(version)
    keyword_lower = keyword.lower()
    results = []
    for feature in features:
        xml_id = feature.get("xmlId", "")
        name = feature.get("name", "")
        if keyword_lower in xml_id.lower() or keyword_lower in name.lower():
            results.append(feature)
    return results


def _format_feature(feature: dict) -> Text:
    """格式化 Ktor 插件显示。"""
    xml_id = feature.get("xmlId", "?")
    name = feature.get("name", "?")
    group = feature.get("group", "")

    t = Text()
    t.append(xml_id, style="bold white")
    t.append(f"  {name}", style="cyan")
    if group:
        t.append(f"  [{group}]", style="dim")
    return t


def _choose_feature(results: List[dict]) -> Optional[dict]:
    """让用户选择一个 Ktor 插件。"""
    if not results:
        console.print("  [yellow]未找到匹配的 Ktor 插件[/]")
        return None

    if len(results) == 1:
        return results[0]

    console.print()
    for idx, feature in enumerate(results, start=1):
        line = Text()
        line.append(f"  {idx}. ", style="bold cyan")
        line.append_text(_format_feature(feature))
        console.print(line)
    console.print("  0. ", style="bold cyan", end="")
    console.print("退出", style="dim")
    console.print()

    try:
        choice = int(typer.prompt("选择", default="1"))
    except ValueError:
        return None
    if choice <= 0 or choice > len(results):
        return None
    return results[choice - 1]


def _is_ktor_lib(spec: LibrarySpec) -> bool:
    """判断是否是 Ktor 库。"""
    return spec.group == "io.ktor" or spec.artifact.startswith("ktor-")


@app.command("add")
def add(
    keyword: str = typer.Argument(..., help="插件名称或关键词"),
    alias: Optional[str] = typer.Option(None, "--alias", "-a", help="自定义别名"),
):
    """添加 Ktor 插件。"""
    root = Path(".").resolve()

    # 获取项目的 ktor 版本或默认版本
    version = _get_project_ktor_version(root) or _get_default_version()

    results = _search_features(keyword, version)
    selected = _choose_feature(results)
    if not selected:
        return

    xml_id = selected.get("xmlId")
    group, artifact = _xml_id_to_gav(xml_id, selected.get("group"))

    # 构建 LibrarySpec，使用 ktor 版本引用
    spec = LibrarySpec(group=group, artifact=artifact, alias=alias)
    alias_final = alias or artifact.replace("-", "_")

    catalog = CatalogManager(root)
    gradle = GradleManager(root)

    # 检查是否有 ktor 版本引用，如果有则使用它
    catalog.load()
    if catalog.get_version("ktor"):
        spec.version = {"ref": "ktor"}
    else:
        spec.version = version

    catalog.add_or_update(spec, alias_final)
    gradle.add_dependency(alias_final)
    accessor = GradleManager.to_accessor(alias_final)

    console.print()
    console.print(f"  [bold green]+[/] [bold]{alias_final}[/]")
    console.print(f"    [dim]{group}[/]:[bold white]{artifact}[/]:[cyan]{version}[/]")
    console.print(f"    [dim]use:[/] [cyan]libs.{accessor}[/]")
    console.print()


@app.command("rm")
def rm(
    keyword: str = typer.Argument(..., help="插件名称或关键词"),
    force: bool = typer.Option(False, "--force", "-f", help="跳过确认直接删除"),
):
    """删除 Ktor 插件。"""
    root = Path(".").resolve()
    catalog = CatalogManager(root)
    gradle = GradleManager(root)
    catalog.load()
    libs = catalog.list_libraries()

    # 找出 catalog 中的 ktor 库，区分精确/模糊匹配
    ktor_catalog = []
    for alias, spec in libs.items():
        if _is_ktor_lib(spec):
            is_exact = (keyword == alias or keyword == spec.artifact)
            is_fuzzy = (not is_exact and (keyword.lower() in alias.lower() or keyword.lower() in spec.artifact.lower()))
            if is_exact or is_fuzzy:
                ktor_catalog.append((alias, spec, "catalog", is_exact))

    # 找出直接写的 ktor 库
    direct_deps = gradle.list_direct_dependencies()
    ktor_direct = []
    for spec in direct_deps:
        if _is_ktor_lib(spec):
            is_exact = (keyword == spec.artifact)
            is_fuzzy = (not is_exact and keyword.lower() in spec.artifact.lower())
            if is_exact or is_fuzzy:
                ktor_direct.append((spec.artifact, spec, "direct", is_exact))

    matches = ktor_catalog + ktor_direct

    if not matches:
        console.print(f"  [yellow]未找到匹配的 Ktor 插件: {keyword}[/]")
        raise typer.Exit(code=1)

    # 选择
    if len(matches) == 1:
        name, spec, source, is_exact = matches[0]
        if not is_exact and not force:
            console.print()
            console.print(f"  [yellow]模糊匹配：[/]")
            console.print(f"    [bold white]{name}[/]  [dim]{spec.gav}[/]")
            if not _confirm_single_key("删除？"):
                console.print("  [dim]已取消[/]")
                raise typer.Exit(code=0)
    else:
        console.print()
        for idx, (name, spec, source, is_exact) in enumerate(matches, start=1):
            line = Text()
            line.append(f"  {idx}. ", style="bold cyan")
            line.append(name, style="bold white")
            line.append(f"  {spec.gav}", style="dim")
            line.append(f"  [{source}]", style="dim")
            if not is_exact:
                line.append("  (fuzzy)", style="dim yellow")
            console.print(line)
        console.print("  0. ", style="bold cyan", end="")
        console.print("退出", style="dim")
        console.print()

        try:
            choice = int(typer.prompt("选择", default="1"))
        except ValueError:
            return
        if choice <= 0 or choice > len(matches):
            return
        name, spec, source, is_exact = matches[choice - 1]

    # 检查版本引用 (仅 catalog)
    version_ref = None
    if source == "catalog" and isinstance(spec.version, dict) and "ref" in spec.version:
        version_ref = spec.version["ref"]

    # 删除
    removed = False
    removed_version = False
    if source == "catalog":
        removed_catalog = catalog.remove(name)
        removed_gradle = gradle.remove_dependency(name)
        removed = removed_catalog or removed_gradle
        # 清理未使用的版本引用
        if version_ref and not catalog.is_version_ref_used(version_ref):
            removed_version = catalog.remove_version(version_ref)
    else:  # direct
        removed = gradle.remove_direct_dependency(spec.group, spec.artifact)

    if removed:
        console.print()
        console.print(f"  [bold red]-[/] [bold]{name}[/]")
        console.print(f"    [dim]{spec.gav}[/]  \\[{source}]")
        if removed_version:
            console.print(f"    [dim]cleaned: versions.{version_ref}[/]")
        console.print()
    else:
        console.print(f"  [yellow]未删除: {name}[/]")


@app.command("list")
def list_features():
    """列出项目中的 Ktor 插件。"""
    root = Path(".").resolve()
    catalog = CatalogManager(root)
    gradle = GradleManager(root)
    catalog.load()

    # 从 version catalog 读取
    catalog_libs = catalog.list_libraries()
    ktor_catalog = {
        alias: spec for alias, spec in catalog_libs.items()
        if _is_ktor_lib(spec)
    }

    # 从 build.gradle(.kts) 读取直接写的依赖
    direct_deps = gradle.list_direct_dependencies()
    ktor_direct = [spec for spec in direct_deps if _is_ktor_lib(spec)]

    if not ktor_catalog and not ktor_direct:
        console.print("  [dim](no ktor plugins)[/]")
        return

    console.print()

    # 显示 catalog 中的
    if ktor_catalog:
        max_alias = max(len(alias) for alias in ktor_catalog.keys())
        for alias, spec in ktor_catalog.items():
            # 解析版本引用
            resolved = None
            if isinstance(spec.version, dict) and "ref" in spec.version:
                resolved = catalog.get_version(spec.version["ref"])

            line = Text(f"  {alias:<{max_alias}}  ", style="bold")
            line.append(spec.group, style="dim")
            line.append(":", style="dim")
            line.append(spec.artifact, style="bold white")
            line.append(":", style="dim")
            if resolved:
                line.append(resolved, style="cyan")
                line.append(f" (${spec.version['ref']})", style="dim")
            elif isinstance(spec.version, str):
                line.append(spec.version, style="cyan")
            else:
                line.append("?", style="dim")
            line.append("  [catalog]", style="dim")
            console.print(line)

    # 显示直接写的
    if ktor_direct:
        for spec in ktor_direct:
            line = Text("  ")
            line.append(spec.group, style="dim")
            line.append(":", style="dim")
            line.append(spec.artifact, style="bold white")
            if spec.version:
                line.append(":", style="dim")
                line.append(spec.version, style="cyan")
            line.append("  [direct]", style="dim")
            console.print(line)

    console.print()


@app.command("check")
def check(
    keyword: str = typer.Argument(..., help="插件名称"),
):
    """查看 Ktor 插件详细信息。"""
    root = Path(".").resolve()
    version = _get_project_ktor_version(root) or _get_default_version()

    results = _search_features(keyword, version)
    if not results:
        console.print(f"  [yellow]未找到: {keyword}[/]")
        return

    # 精确匹配优先
    exact = [f for f in results if f.get("xmlId", "").lower() == keyword.lower()]
    if exact:
        feature = exact[0]
    elif len(results) == 1:
        feature = results[0]
    else:
        feature = _choose_feature(results)
        if not feature:
            return

    xml_id = feature.get("xmlId", "?")
    group_id, artifact_id = _xml_id_to_gav(xml_id)

    console.print()
    console.print(f"  [bold]{feature.get('name', xml_id)}[/]")
    console.print(f"    [dim]id:[/]          {xml_id}")
    console.print(f"    [dim]group:[/]       {group_id}")
    console.print(f"    [dim]artifact:[/]    [cyan]{artifact_id}[/]")
    console.print(f"    [dim]category:[/]    {feature.get('group', '?')}")
    console.print(f"    [dim]ktor:[/]        {version}")
    if feature.get("description"):
        console.print(f"    [dim]desc:[/]        {feature.get('description')}")
    if feature.get("github"):
        console.print(f"    [dim]github:[/]      {feature.get('github')}")
    console.print()
