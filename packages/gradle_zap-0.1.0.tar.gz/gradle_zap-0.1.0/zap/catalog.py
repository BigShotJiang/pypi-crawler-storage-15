from pathlib import Path
from typing import Dict, List, Optional

import tomlkit
from tomlkit.items import Table, InlineTable
import tomlkit

from .types import CLIError, LibrarySpec


class CatalogManager:
    """Manage gradle version catalog at gradle/libs.versions.toml."""

    def __init__(self, root: Path):
        self.root = root
        self.path = root / "gradle" / "libs.versions.toml"
        self.doc = tomlkit.document()

    def load(self) -> None:
        """Load or bootstrap the catalog file."""
        if self.path.exists():
            self.doc = tomlkit.parse(self.path.read_text(encoding="utf-8"))
            return
        # Bootstrap a minimal catalog when missing.
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.doc = tomlkit.document()
        self.doc.add("versions", tomlkit.table())  # keep sections explicit
        self.doc.add("libraries", tomlkit.table())
        self._save()

    def _save(self) -> None:
        self.path.write_text(tomlkit.dumps(self.doc), encoding="utf-8")

    def list_libraries(self) -> Dict[str, LibrarySpec]:
        """Return alias -> LibrarySpec for all libraries."""
        libs = self.doc.get("libraries", {})
        out: Dict[str, LibrarySpec] = {}
        for alias, entry in libs.items():
            module = None
            version = None
            if isinstance(entry, (Table, InlineTable)):
                module = entry.get("module")
                version = entry.get("version") or entry.get("version.ref")
                # 规范化 version，支持 {ref="ktor"} 内联写法
                if isinstance(version, InlineTable):
                    if "ref" in version:
                        version = f"ref:{version['ref']}"
                    else:
                        version = tomlkit.dumps(version).strip()
            elif isinstance(entry, str):
                # Plain "group:artifact"
                module = entry
            if not module:
                continue
            group, artifact = module.split(":", 1)
            out[alias] = LibrarySpec(group=group, artifact=artifact, version=version, alias=alias)
        return out

    def get_version(self, ref: str) -> Optional[str]:
        """根据版本引用名获取具体版本号。"""
        versions = self.doc.get("versions", {})
        return versions.get(ref)

    def is_version_ref_used(self, ref: str, exclude_alias: str = None) -> bool:
        """检查版本引用是否被其他库使用。"""
        libs = self.doc.get("libraries", {})
        for alias, entry in libs.items():
            if alias == exclude_alias:
                continue
            if isinstance(entry, (Table, InlineTable)):
                version = entry.get("version")
                if isinstance(version, InlineTable) and version.get("ref") == ref:
                    return True
                # 也检查字符串格式 "ref:xxx"
                if isinstance(version, str) and version == f"ref:{ref}":
                    return True
        return False

    def remove_version(self, ref: str) -> bool:
        """删除版本引用；返回是否成功删除。"""
        versions = self.doc.get("versions")
        if not versions or ref not in versions:
            return False
        del versions[ref]
        self._save()
        return True

    def add_or_update(self, spec: LibrarySpec, alias: str) -> None:
        """Insert or update a library entry."""
        self.load()
        libs = self.doc.get("libraries")
        if libs is None:
            libs = tomlkit.table()
            self.doc["libraries"] = libs

        entry = tomlkit.table()
        entry.add("module", spec.gav)
        if spec.version:
            entry.add("version", spec.version)
        libs[alias] = entry
        self._save()

    def remove(self, alias: str) -> bool:
        """Remove a library; returns True if removed."""
        self.load()
        libs = self.doc.get("libraries")
        if not libs or alias not in libs:
            return False
        del libs[alias]
        self._save()
        return True
