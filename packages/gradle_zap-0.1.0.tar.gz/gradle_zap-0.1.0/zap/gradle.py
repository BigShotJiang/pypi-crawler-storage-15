from __future__ import annotations

import re
from pathlib import Path
from typing import List, Optional, Tuple

from .types import CLIError, LibrarySpec


class GradleManager:
    """Minimal manipulations of build.gradle(.kts) dependencies block."""

    # 匹配直接写的依赖，如 implementation("group:artifact:version") 或 implementation("group:artifact")
    DIRECT_DEP_PATTERN = re.compile(
        r'^\s*(implementation|api|compileOnly|runtimeOnly|testImplementation)\s*\(\s*["\']([^"\']+)["\']\s*\)',
        re.MULTILINE
    )

    def __init__(self, root: Path):
        self.root = root
        self.build_file = self._detect_file()

    def _detect_file(self) -> Path:
        kts = self.root / "build.gradle.kts"
        groovy = self.root / "build.gradle"
        if kts.exists():
            return kts
        if groovy.exists():
            return groovy
        return kts  # default path if none exists yet

    @staticmethod
    def to_accessor(alias: str) -> str:
        """
        Convert catalog alias to Gradle accessor with分段：
        - 将非字母数字字符全部替换为 '.'
        - 折叠连续分隔符，去掉首尾的 '.'
        - 不再做驼峰化，便于直接使用 libs.fast.md5 形式
        """
        accessor = re.sub(r"[^A-Za-z0-9]+", ".", alias)
        accessor = re.sub(r"\.+", ".", accessor).strip(".")
        return accessor or alias

    def _dependency_line(self, alias: str) -> str:
        acc = self.to_accessor(alias)
        if self.build_file.suffix == ".kts":
            return f"    implementation(libs.{acc})"
        return f"    implementation(libs.{acc})"

    def list_direct_dependencies(self) -> List[LibrarySpec]:
        """读取 build.gradle(.kts) 中直接写的依赖。"""
        path = self.build_file
        if not path.exists():
            return []

        content = path.read_text(encoding="utf-8")
        results = []
        seen = set()

        for match in self.DIRECT_DEP_PATTERN.finditer(content):
            scope = match.group(1)
            gav = match.group(2)
            parts = gav.split(":")
            if len(parts) >= 2:
                group, artifact = parts[0], parts[1]
                version = parts[2] if len(parts) >= 3 else None
                key = (group, artifact)
                if key not in seen:
                    seen.add(key)
                    results.append(LibrarySpec(
                        group=group,
                        artifact=artifact,
                        version=version,
                        alias=None
                    ))
        return results

    def remove_direct_dependency(self, group: str, artifact: str) -> bool:
        """删除 build.gradle(.kts) 中直接写的依赖。"""
        path = self.build_file
        if not path.exists():
            return False

        content = path.read_text(encoding="utf-8")
        lines = content.splitlines()
        new_lines = []
        removed = False

        # 匹配 group:artifact 或 group:artifact:version
        pattern = re.compile(
            rf'^\s*(implementation|api|compileOnly|runtimeOnly|testImplementation)\s*\(\s*["\']'
            rf'{re.escape(group)}:{re.escape(artifact)}(:[^"\']*)?["\']\s*\)'
        )

        for line in lines:
            if pattern.match(line):
                removed = True
            else:
                new_lines.append(line)

        if removed:
            path.write_text("\n".join(new_lines) + "\n", encoding="utf-8")
        return removed

    def add_dependency(self, alias: str) -> None:
        """Ensure implementation(libs.alias) exists in dependencies block."""
        path = self.build_file
        content = path.read_text(encoding="utf-8") if path.exists() else ""
        target_line = self._dependency_line(alias)
        if target_line in content:
            return

        if "dependencies" in content:
            lines = content.splitlines()
            new_lines = []
            inside = False
            brace_depth = 0
            inserted = False
            for line in lines:
                stripped = line.strip()
                if stripped.startswith("dependencies"):
                    inside = True
                    brace_depth = stripped.count("{") - stripped.count("}")
                    new_lines.append(line)
                    continue
                if inside:
                    brace_depth += stripped.count("{")
                    brace_depth -= stripped.count("}")
                    if brace_depth == 0 and not inserted:
                        new_lines.append(target_line)
                        inserted = True
                new_lines.append(line)
            if not inserted:
                new_lines.append(target_line)
            path.write_text("\n".join(new_lines) + "\n", encoding="utf-8")
            return

        # No dependencies block; create one.
        block = ["dependencies {", target_line, "}"]
        if content and not content.endswith("\n"):
            content += "\n"
        content += "\n".join(block) + "\n"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")

    def remove_dependency(self, alias: str) -> bool:
        """Remove implementation(libs.alias) if present. Returns True if removed."""
        path = self.build_file
        if not path.exists():
            return False
        target_line = self._dependency_line(alias)
        acc = self.to_accessor(alias)
        alt_line = f"    implementation(libs.{alias})"
        alt_line_dot = f"    implementation(libs.{acc})"
        lines = path.read_text(encoding="utf-8").splitlines()
        new_lines = [
            ln
            for ln in lines
            if ln.strip() not in {target_line.strip(), alt_line.strip(), alt_line_dot.strip()}
        ]
        changed = len(new_lines) != len(lines)
        if changed:
            path.write_text("\n".join(new_lines) + "\n", encoding="utf-8")
        return changed
