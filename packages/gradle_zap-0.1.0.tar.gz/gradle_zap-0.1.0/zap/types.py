from dataclasses import dataclass
from typing import Optional


@dataclass
class LibrarySpec:
    """Represents a single dependency."""

    group: str
    artifact: str
    version: Optional[str] = None
    alias: Optional[str] = None

    @property
    def gav(self) -> str:
        """Return group:artifact string."""
        return f"{self.group}:{self.artifact}"

    @property
    def gav_with_version(self) -> str:
        """Return group:artifact:version if available."""
        return f"{self.group}:{self.artifact}:{self.version}" if self.version else self.gav


class CLIError(Exception):
    """Domain-specific exception for CLI errors."""

