import json
import re
import urllib.error
import urllib.parse
import urllib.request
from typing import List, Optional, Tuple

from .types import LibrarySpec
from .config import ZapConfig
from pathlib import Path


STABLE_REGEX = re.compile(r"(?:alpha|beta|rc|cr|m\\d+|snapshot)", re.IGNORECASE)


def is_stable(version: str) -> bool:
    """Return True if a version string looks stable."""
    return not STABLE_REGEX.search(version)


def _fetch_json(url: str, timeout: float = 6.0) -> Optional[dict]:
    """Fetch JSON from URL using stdlib to avoid extra deps."""
    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            if resp.status != 200:
                return None
            data = resp.read()
            return json.loads(data.decode("utf-8"))
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError):
        return None


def _search_central_with_base(base: str, artifact: str, rows: int) -> List[Tuple[LibrarySpec, float, str]]:
    """
    Sonatype Central-like API with configurable base.
    """
    query = urllib.parse.quote(artifact)
    if base.endswith("/"):
        base = base[:-1]
    url = f"{base}/search?keyword={query}&rows={rows}"
    payload = _fetch_json(url)
    if not payload:
        return []
    items = payload.get("packages") or payload.get("items") or payload.get("results") or []
    results: List[Tuple[LibrarySpec, float, str]] = []
    seen = set()
    for doc in items:
        group = doc.get("groupId") or doc.get("group") or doc.get("namespace")
        art = doc.get("artifactId") or doc.get("name")
        version = doc.get("latestVersion") or doc.get("version")
        score = float(doc.get("popularityScore") or doc.get("score") or doc.get("versionCount") or 0)
        if not group or not art or not version:
            continue
        key = (group, art)
        if key in seen:
            continue
        seen.add(key)
        if not is_stable(version):
            version = fetch_latest_version(group, art) or version
        results.append((LibrarySpec(group=group, artifact=art, version=version), score, "central"))
    return results


def _search_legacy(artifact: str, rows: int) -> List[Tuple[LibrarySpec, float, str]]:
    """
    Legacy search.maven.org Solr API.
    使用简单全文搜索，按 versionCount（版本数量，反映活跃度）排序。
    """
    results: List[Tuple[LibrarySpec, float, str]] = []
    seen = set()

    # 直接使用简单全文搜索，避免 text: 前缀导致的解析问题
    query = urllib.parse.quote(artifact)
    url = (
        "https://search.maven.org/solrsearch/select"
        f"?q={query}&rows={rows}&wt=json"
    )
    payload = _fetch_json(url, timeout=10.0)
    if payload and "response" in payload:
        for doc in payload["response"].get("docs", []):
            group = doc.get("g")
            art = doc.get("a")
            version = doc.get("latestVersion") or doc.get("v")
            # versionCount 表示发布过的版本数量，间接反映使用量/活跃度
            version_count = float(doc.get("versionCount") or 1)
            if not group or not art or not version:
                continue
            key = (group, art)
            if key in seen:
                continue
            seen.add(key)
            if not is_stable(version):
                version = fetch_latest_version(group, art) or version
            results.append((LibrarySpec(group=group, artifact=art, version=version), version_count, "legacy"))

    return results


def _search_sonatype_internal(artifact: str, rows: int) -> List[Tuple[LibrarySpec, float, str]]:
    """
    Sonatype Central internal API，返回 dependencyOfCount（被依赖数）作为流行度。
    """
    url = "https://central.sonatype.com/api/internal/browse/components"
    body = json.dumps({
        "size": rows,
        "searchTerm": artifact,
        "filter": []
    }).encode("utf-8")

    try:
        req = urllib.request.Request(
            url,
            method="POST",
            headers={
                "Accept": "application/json",
                "Content-Type": "application/json",
                "User-Agent": "Mozilla/5.0"
            },
            data=body
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            if resp.status != 200:
                return []
            payload = json.loads(resp.read().decode("utf-8"))
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError):
        return []

    results: List[Tuple[LibrarySpec, float, str]] = []
    seen = set()
    for doc in payload.get("components", []):
        group = doc.get("namespace")
        art = doc.get("name")
        version_info = doc.get("latestVersionInfo") or {}
        version = version_info.get("version")
        # dependencyOfCount 表示被多少项目依赖，是真实的使用量指标
        dep_count = float(doc.get("dependencyOfCount") or 0)
        if not group or not art or not version:
            continue
        key = (group, art)
        if key in seen:
            continue
        seen.add(key)
        if not is_stable(version):
            version = fetch_latest_version(group, art) or version
        results.append((LibrarySpec(group=group, artifact=art, version=version), dep_count, "central"))

    return results


SONATYPE_CENTRAL_API = "https://central.sonatype.com/api/v1"


def search_artifact(
    artifact: str,
    rows: int = 20,
    root: Optional[Path] = None,
) -> List[Tuple[LibrarySpec, float, str]]:
    """
    Search Maven Central for an artifact name.

    Returns list of (LibrarySpec, score, source) sorted by dependencyOfCount desc.
    优先使用 Sonatype internal API（有 dependencyOfCount），回退到 legacy API。
    """
    # 1) project config search base
    config_base = None
    if root:
        cfg = ZapConfig(root)
        cfg.load()
        config_base = cfg.get_search_base()

    results: List[Tuple[LibrarySpec, float, str]] = []

    # 优先使用配置的 base
    if config_base:
        results = _search_central_with_base(config_base, artifact, rows)

    # 使用 Sonatype internal API（有 dependencyOfCount）
    if not results:
        results = _search_sonatype_internal(artifact, rows)

    # 回退到 legacy API
    if not results:
        results = _search_legacy(artifact, rows)

    # 排序：score desc (dependencyOfCount 优先)；若同分，稳定版优先；再按 artifact 名字长度（短优先）
    def sort_key(item: Tuple[LibrarySpec, float, str]):
        spec, score, _src = item
        stable = 1 if is_stable(spec.version or "") else 0
        return (-score, -stable, len(spec.artifact))

    return sorted(results, key=sort_key)


def fetch_latest_version(group: str, artifact: str, channel: str = "stable") -> Optional[str]:
    """
    Fetch the latest version for a given group/artifact.
    channel:
      - "stable" (default): filter out alpha/beta/rc/m/snapshot
      - "prerelease": allow any (alpha/beta/rc...)
      - "snapshot": prefer SNAPSHOT
    """
    ga = urllib.parse.quote(f"g:{group} AND a:{artifact}")
    url = (
        "https://search.maven.org/solrsearch/select"
        f"?q={ga}&rows=50&core=gav&wt=json&sort=version+desc"
    )
    payload = _fetch_json(url)
    if not payload or "response" not in payload:
        return None

    docs = payload["response"].get("docs", [])
    if channel == "snapshot":
        for doc in docs:
            version = doc.get("v")
            if version and "SNAPSHOT" in version.upper():
                return version
        # fallback to any if no snapshot
        channel = "prerelease"

    for doc in docs:
        version = doc.get("v")
        if not version:
            continue
        if channel == "stable":
            if is_stable(version):
                return version
        else:  # prerelease / any
            return version
    return None
