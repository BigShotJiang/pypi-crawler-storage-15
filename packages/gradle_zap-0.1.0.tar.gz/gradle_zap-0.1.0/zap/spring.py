"""Spring Boot Starter 管理子命令。"""
from __future__ import annotations

import json
import urllib.error
import urllib.request
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import typer
import click
from rich.console import Console
from rich.text import Text

from .catalog import CatalogManager
from .gradle import GradleManager
from .types import LibrarySpec

app = typer.Typer(help="Spring Boot Starter 管理")
console = Console()


def _confirm_single_key(prompt: str = "确认？", default: bool = False) -> bool:
    """单键确认，无需回车。"""
    hint = r"\[Y/n]" if default else r"\[y/N]"
    console.print(f"  {prompt} [dim]{hint}[/] ", end="")
    char = click.getchar()
    console.print(char)
    if char.lower() == 'y':
        return True
    if char.lower() == 'n':
        return False
    return default

# 缓存
_metadata_cache: Optional[Dict] = None  # id -> {name, description, groupId, artifactId, ...}
_boot_version_cache: Optional[str] = None


def _fetch_metadata() -> Tuple[Dict, str]:
    """获取 Spring Initializr 的完整元数据（包含 name、description）。"""
    global _metadata_cache, _boot_version_cache
    if _metadata_cache is not None:
        return _metadata_cache, _boot_version_cache

    # 先获取 GAV 信息
    gav_map = {}
    try:
        req = urllib.request.Request(
            "https://start.spring.io/dependencies",
            headers={"Accept": "application/json"}
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            gav_map = data.get("dependencies", {})
            _boot_version_cache = data.get("bootVersion", "?")
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError):
        pass

    # 再获取完整元数据（name、description、links）
    _metadata_cache = {}
    try:
        req = urllib.request.Request(
            "https://start.spring.io",
            headers={"Accept": "application/json"}
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            # 遍历所有分组
            for group in data.get("dependencies", {}).get("values", []):
                group_name = group.get("name", "")
                for item in group.get("values", []):
                    dep_id = item.get("id")
                    if dep_id:
                        # 合并 GAV 信息
                        info = {
                            "name": item.get("name", dep_id),
                            "description": item.get("description", ""),
                            "category": group_name,
                            "_links": item.get("_links", {}),
                        }
                        # 从 gav_map 获取 groupId/artifactId
                        if dep_id in gav_map:
                            info["groupId"] = gav_map[dep_id].get("groupId")
                            info["artifactId"] = gav_map[dep_id].get("artifactId")
                            info["scope"] = gav_map[dep_id].get("scope", "compile")
                        _metadata_cache[dep_id] = info
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as e:
        console.print(f"  [red]获取 Spring 元数据失败: {e}[/]")

    return _metadata_cache, _boot_version_cache or "?"


def _search_starters(keyword: str) -> List[Tuple[str, dict]]:
    """搜索匹配的 starter。返回 [(id, info), ...]"""
    deps, _ = _fetch_metadata()
    keyword_lower = keyword.lower()
    results = []
    for dep_id, info in deps.items():
        # 匹配 id、name 或 artifactId
        name = info.get("name", "")
        artifact = info.get("artifactId", "")
        if (keyword_lower in dep_id.lower() or
            keyword_lower in name.lower() or
            keyword_lower in artifact.lower()):
            results.append((dep_id, info))
    return results


def _format_starter(dep_id: str, info: dict) -> Text:
    """格式化 starter 显示。"""
    name = info.get("name", dep_id)
    artifact = info.get("artifactId", "?")

    t = Text()
    t.append(dep_id, style="bold white")
    t.append(f"  {name}", style="cyan")
    if artifact and artifact != "?":
        t.append(f"  [{artifact}]", style="dim")
    return t


def _choose_starter(results: List[Tuple[str, dict]]) -> Optional[Tuple[str, dict]]:
    """让用户选择一个 starter。"""
    if not results:
        console.print("  [yellow]未找到匹配的 Spring Starter[/]")
        return None

    if len(results) == 1:
        return results[0]

    console.print()
    for idx, (dep_id, info) in enumerate(results, start=1):
        line = Text()
        line.append(f"  {idx}. ", style="bold cyan")
        line.append_text(_format_starter(dep_id, info))
        console.print(line)
    console.print("  0. ", style="bold cyan", end="")
    console.print("退出", style="dim")
    console.print()

    try:
        choice = int(typer.prompt("选择", default="1"))
    except ValueError:
        return None
    if choice <= 0 or choice > len(results):
        return None
    return results[choice - 1]


def _is_spring_starter(spec: LibrarySpec) -> bool:
    """判断是否是 Spring Boot Starter。"""
    return (
        spec.group.startswith("org.springframework") or
        spec.artifact.startswith("spring-boot-starter") or
        spec.artifact.startswith("spring-")
    )


@app.command("add")
def add(
    keyword: str = typer.Argument(..., help="Starter 名称或关键词"),
    alias: Optional[str] = typer.Option(None, "--alias", "-a", help="自定义别名"),
):
    """添加 Spring Boot Starter。"""
    results = _search_starters(keyword)
    selected = _choose_starter(results)
    if not selected:
        return

    dep_id, info = selected
    group = info.get("groupId")
    artifact = info.get("artifactId")

    if not group or not artifact:
        console.print("  [red]无法获取 starter 的 GAV 信息[/]")
        raise typer.Exit(code=1)

    # 构建 LibrarySpec（不指定版本，由 BOM 管理）
    spec = LibrarySpec(group=group, artifact=artifact, alias=alias)
    alias_final = alias or artifact.replace("-", "_")

    root = Path(".").resolve()
    catalog = CatalogManager(root)
    gradle = GradleManager(root)

    catalog.add_or_update(spec, alias_final)
    gradle.add_dependency(alias_final)
    accessor = GradleManager.to_accessor(alias_final)

    console.print()
    console.print(f"  [bold green]+[/] [bold]{alias_final}[/]")
    console.print(f"    [dim]{group}[/]:[bold white]{artifact}[/]")
    console.print(f"    [dim]use:[/] [cyan]libs.{accessor}[/]")
    console.print()


@app.command("rm")
def rm(
    keyword: str = typer.Argument(..., help="Starter 名称或关键词"),
    force: bool = typer.Option(False, "--force", "-f", help="跳过确认直接删除"),
):
    """删除 Spring Boot Starter。"""
    root = Path(".").resolve()
    catalog = CatalogManager(root)
    gradle = GradleManager(root)
    catalog.load()
    libs = catalog.list_libraries()

    # 找出 catalog 中的 spring starter，区分精确/模糊匹配
    spring_catalog = []
    for alias, spec in libs.items():
        if _is_spring_starter(spec):
            is_exact = (keyword == alias or keyword == spec.artifact)
            is_fuzzy = (not is_exact and (keyword.lower() in alias.lower() or keyword.lower() in spec.artifact.lower()))
            if is_exact or is_fuzzy:
                spring_catalog.append((alias, spec, "catalog", is_exact))

    # 找出直接写的 spring starter
    direct_deps = gradle.list_direct_dependencies()
    spring_direct = []
    for spec in direct_deps:
        if _is_spring_starter(spec):
            is_exact = (keyword == spec.artifact)
            is_fuzzy = (not is_exact and keyword.lower() in spec.artifact.lower())
            if is_exact or is_fuzzy:
                spring_direct.append((spec.artifact, spec, "direct", is_exact))

    matches = spring_catalog + spring_direct

    if not matches:
        console.print(f"  [yellow]未找到匹配的 Spring Starter: {keyword}[/]")
        raise typer.Exit(code=1)

    # 选择
    if len(matches) == 1:
        name, spec, source, is_exact = matches[0]
        if not is_exact and not force:
            console.print()
            console.print(f"  [yellow]模糊匹配：[/]")
            console.print(f"    [bold white]{name}[/]  [dim]{spec.gav}[/]")
            if not _confirm_single_key("删除？"):
                console.print("  [dim]已取消[/]")
                raise typer.Exit(code=0)
    else:
        console.print()
        for idx, (name, spec, source, is_exact) in enumerate(matches, start=1):
            line = Text()
            line.append(f"  {idx}. ", style="bold cyan")
            line.append(name, style="bold white")
            line.append(f"  {spec.gav}", style="dim")
            line.append(f"  [{source}]", style="dim")
            if not is_exact:
                line.append("  (fuzzy)", style="dim yellow")
            console.print(line)
        console.print("  0. ", style="bold cyan", end="")
        console.print("退出", style="dim")
        console.print()

        try:
            choice = int(typer.prompt("选择", default="1"))
        except ValueError:
            return
        if choice <= 0 or choice > len(matches):
            return
        name, spec, source, is_exact = matches[choice - 1]

    # 删除
    removed = False
    if source == "catalog":
        removed_catalog = catalog.remove(name)
        removed_gradle = gradle.remove_dependency(name)
        removed = removed_catalog or removed_gradle
    else:  # direct
        removed = gradle.remove_direct_dependency(spec.group, spec.artifact)

    if removed:
        console.print()
        console.print(f"  [bold red]-[/] [bold]{name}[/]")
        console.print(f"    [dim]{spec.gav}[/]  \\[{source}]")
        console.print()
    else:
        console.print(f"  [yellow]未删除: {name}[/]")


@app.command("list")
def list_starters():
    """列出项目中的 Spring Boot Starter。"""
    root = Path(".").resolve()
    catalog = CatalogManager(root)
    gradle = GradleManager(root)
    catalog.load()

    # 从 version catalog 读取
    catalog_libs = catalog.list_libraries()
    spring_catalog = {
        alias: spec for alias, spec in catalog_libs.items()
        if _is_spring_starter(spec)
    }

    # 从 build.gradle(.kts) 读取直接写的依赖
    direct_deps = gradle.list_direct_dependencies()
    spring_direct = [spec for spec in direct_deps if _is_spring_starter(spec)]

    if not spring_catalog and not spring_direct:
        console.print("  [dim](no spring starters)[/]")
        return

    console.print()

    # 显示 catalog 中的
    if spring_catalog:
        max_alias = max(len(alias) for alias in spring_catalog.keys())
        for alias, spec in spring_catalog.items():
            line = Text(f"  {alias:<{max_alias}}  ", style="bold")
            line.append(spec.group, style="dim")
            line.append(":", style="dim")
            line.append(spec.artifact, style="bold white")
            line.append("  [catalog]", style="dim")
            console.print(line)

    # 显示直接写的
    if spring_direct:
        for spec in spring_direct:
            line = Text("  ")
            line.append(spec.group, style="dim")
            line.append(":", style="dim")
            line.append(spec.artifact, style="bold white")
            if spec.version:
                line.append(":", style="dim")
                line.append(spec.version, style="cyan")
            line.append("  [direct]", style="dim")
            console.print(line)

    console.print()


@app.command("check")
def check(
    keyword: str = typer.Argument(..., help="Starter 名称"),
):
    """查看 Spring Boot Starter 详细信息。"""
    results = _search_starters(keyword)
    if not results:
        console.print(f"  [yellow]未找到: {keyword}[/]")
        return

    # 精确匹配优先
    exact = [(dep_id, info) for dep_id, info in results if dep_id.lower() == keyword.lower()]
    if exact:
        dep_id, info = exact[0]
    elif len(results) == 1:
        dep_id, info = results[0]
    else:
        selected = _choose_starter(results)
        if not selected:
            return
        dep_id, info = selected

    _, boot_version = _fetch_metadata()

    console.print()
    console.print(f"  [bold]{info.get('name', dep_id)}[/]")
    console.print(f"    [dim]id:[/]        {dep_id}")
    console.print(f"    [dim]group:[/]     {info.get('groupId', '?')}")
    console.print(f"    [dim]artifact:[/]  [cyan]{info.get('artifactId', '?')}[/]")
    console.print(f"    [dim]category:[/]  {info.get('category', '?')}")
    console.print(f"    [dim]scope:[/]     {info.get('scope', 'compile')}")
    console.print(f"    [dim]boot:[/]      {boot_version}")
    if info.get("description"):
        console.print(f"    [dim]desc:[/]      {info.get('description')}")

    # 显示链接
    links = info.get("_links", {})
    if links:
        # reference 文档
        ref = links.get("reference")
        if ref:
            href = ref.get("href", "") if isinstance(ref, dict) else ref
            if href:
                href = href.replace("{bootVersion}", boot_version)
                console.print(f"    [dim]docs:[/]      {href}")
        # guide 链接（可能是列表）
        guides = links.get("guide", [])
        if isinstance(guides, dict):
            guides = [guides]
        for g in guides[:2]:  # 最多显示2个
            console.print(f"    [dim]guide:[/]     {g.get('href', '')}  [dim]{g.get('title', '')}[/]")
    console.print()
