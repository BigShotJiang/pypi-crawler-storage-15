from __future__ import annotations

import json
import re
import subprocess
import sys
from pathlib import Path
import platform
from typing import List, Optional, Tuple

import typer
import click
from rich.console import Console
from rich.text import Text

from . import __version__
from .catalog import CatalogManager
from .gradle import GradleManager
from .maven import fetch_latest_version, search_artifact
from .types import CLIError, LibrarySpec
from .config import ZapConfig
from . import spring
from . import ktor

app = typer.Typer(help="轻量级 Gradle 依赖管理 CLI", add_completion=False)
search_mirror_app = typer.Typer(help="搜索 API 镜像管理", add_completion=False)
app.add_typer(search_mirror_app, name="search-mirror")
app.add_typer(spring.app, name="spring")
app.add_typer(ktor.app, name="ktor")

console = Console()


def _confirm_single_key(prompt: str = "确认？", default: bool = False) -> bool:
    """单键确认，无需回车。y/Y 确认，其他取消。"""
    hint = r"\[Y/n]" if default else r"\[y/N]"
    console.print(f"  {prompt} [dim]{hint}[/] ", end="")
    char = click.getchar()
    console.print(char)  # 回显
    if char.lower() == 'y':
        return True
    if char.lower() == 'n':
        return False
    return default


def _format_gav(spec: LibrarySpec, resolved_version: Optional[str] = None) -> Text:
    """格式化 GAV，分颜色显示各部分。"""
    t = Text()
    t.append(spec.group, style="dim")
    t.append(":", style="dim")
    t.append(spec.artifact, style="bold white")
    t.append(":", style="dim")
    # version 可能是字符串或字典 {'ref': 'xxx'}
    version = spec.version
    if isinstance(version, dict):
        ref = version.get("ref", "?")
        if resolved_version:
            t.append(resolved_version, style="cyan")
            t.append(f" (${ref})", style="dim")
        else:
            t.append(f"${ref}", style="cyan")
    else:
        t.append(version or "?", style="cyan")
    return t


def _print_dep(
    symbol: str,
    symbol_style: str,
    alias: str,
    spec: LibrarySpec,
    accessor: Optional[str] = None,
    note: Optional[str] = None,
):
    """公共函数：打印依赖操作结果。"""
    console.print()

    # 第一行：符号 + 别名 + 可选备注
    line1 = Text()
    line1.append(f"  {symbol} ", style=symbol_style)
    line1.append(alias, style="bold")
    if note:
        line1.append(f"  ({note})", style="dim")
    console.print(line1)

    # 第二行：GAV
    line2 = Text("    ")
    line2.append_text(_format_gav(spec))
    console.print(line2)

    # 第三行：accessor
    if accessor:
        console.print(f"    [dim]use:[/] [cyan]libs.{accessor}[/]")

    console.print()


# 预置别名映射，尽量给出稳定版本，缺省时再去查询。
BUILTIN_ALIASES = {
    "jackson": LibrarySpec(
        group="com.fasterxml.jackson.core",
        artifact="jackson-databind",
        alias="jackson",
    ),
    "gson": LibrarySpec(
        group="com.google.code.gson",
        artifact="gson",
        alias="gson",
    ),
    "okhttp": LibrarySpec(
        group="com.squareup.okhttp3",
        artifact="okhttp",
        alias="okhttp",
    ),
    "retrofit": LibrarySpec(
        group="com.squareup.retrofit2",
        artifact="retrofit",
        alias="retrofit",
    ),
}

# 当网络查询失败时可使用的兜底版本（不会主动使用，除非拉取失败）
BUILTIN_VERSION_FALLBACK = {
    "com.fasterxml.jackson.core:jackson-databind": "2.17.1",
    "com.google.code.gson:gson": "2.11.0",
    "com.squareup.okhttp3:okhttp": "4.12.0",
    "com.squareup.retrofit2:retrofit": "2.11.0",
}


VERSION_HINT = re.compile(r"^v?\d+(?:\.\d+)*(?:[-_].+)?$", re.IGNORECASE)
VERSION_KEYWORD = re.compile(
    r"^(latest|latest-release|release|stable|alpha|beta|rc|m\d+|prerelease|snapshot)$",
    re.IGNORECASE,
)


# ---------------- Parsing helpers ---------------- #
def parse_input(
    target: str, alias_override: Optional[str]
) -> Tuple[Optional[str], Optional[LibrarySpec], Optional[str], Optional[str]]:
    """
    将用户输入拆解成 (alias, LibrarySpec 或 None, artifact_hint, version_hint)。
    支持：
    - group:artifact
    - group:artifact:version
    - artifact 或 artifact:version（无 group 时返回 None，后续搜索/映射）
    - alias:version （仅当 alias 已存在或为内置别名，用于覆盖版本）
    """
    parts = target.split(":")
    alias = alias_override

    if len(parts) >= 3:
        group, artifact, version = parts[0], parts[1], parts[2]
        return alias, LibrarySpec(group=group, artifact=artifact, version=version, alias=alias), None, None
    if len(parts) == 2:
        p1, p2 = parts
        if VERSION_HINT.match(p2) or VERSION_KEYWORD.match(p2):
            # 形如 artifact:version 或 alias:version（后续由上层决定是否当 alias）
            return alias, None, p1, p2
        group, artifact = p1, p2
        return alias, LibrarySpec(group=group, artifact=artifact, alias=alias), None, None
    # len == 1: 只有 artifact/alias，待搜索
    return alias, None, parts[0], None


def _format_score(count: float, source: str) -> str:
    """格式化分数，根据来源显示不同单位。"""
    if count <= 0:
        return ""
    # 格式化数字
    if count >= 1_000_000:
        num = f"{count/1_000_000:.1f}m"
    elif count >= 1_000:
        num = f"{count/1_000:.1f}k"
    else:
        num = str(int(count))
    # 根据来源显示单位
    if source == "central":
        return f"used by {num}"
    elif source == "legacy":
        return f"{num} versions"
    else:
        return num


def choose_candidate(cands: List[Tuple[LibrarySpec, float, str]]) -> Optional[LibrarySpec]:
    """让用户从搜索结果里选择一个依赖；0 退出。"""
    if not cands:
        console.print("  [yellow]未找到匹配的依赖[/]")
        return None

    # 计算对齐宽度
    max_gav = max(len(spec.gav_with_version) for spec, _, _ in cands)

    console.print()
    for idx, (spec, score, source) in enumerate(cands, start=1):
        score_str = _format_score(score, source)

        line = Text()
        line.append(f"  {idx}. ", style="bold cyan")
        line.append_text(_format_gav(spec))
        # 补齐空格
        padding = max_gav - len(spec.gav_with_version)
        if padding > 0:
            line.append(" " * padding)
        if score_str:
            line.append(f"  ({score_str})", style="dim")
        console.print(line)

    console.print(f"  0. ", style="bold cyan", end="")
    console.print("退出", style="dim")
    console.print()

    try:
        choice = int(typer.prompt("选择", default="1"))
    except ValueError:
        return None
    if choice <= 0 or choice > len(cands):
        return None
    return cands[choice - 1][0]


def _channel_from_hint(version_hint: Optional[str]) -> str:
    if not version_hint:
        return "stable"
    hint = version_hint.lower()
    if hint in ("latest", "latest-release", "release", "stable"):
        return "stable"
    if hint == "snapshot":
        return "snapshot"
    if hint in ("alpha", "beta", "rc", "prerelease") or hint.startswith("m"):
        return "prerelease"
    # default treat as stable
    return "stable"


def ensure_version(
    spec: LibrarySpec, version_hint: Optional[str] = None, fallback_version: Optional[str] = None
) -> LibrarySpec:
    """确保 spec 有版本；支持关键字 latest/stable/alpha/beta/rc/snapshot，必要时使用兜底版本。"""
    if spec.version and not VERSION_KEYWORD.match(spec.version):
        return spec
    channel = _channel_from_hint(version_hint or spec.version)
    version = fetch_latest_version(spec.group, spec.artifact, channel=channel)
    if not version and fallback_version:
        version = fallback_version
    if not version:
        raise CLIError("未找到可用版本，请手动指定。")
    spec.version = version
    return spec


# ---------------- Command implementations ---------------- #
@app.command()
def add(
    target: str = typer.Argument(..., help="group:artifact[:version] / artifact[:version] / alias:version"),
    alias: Optional[str] = typer.Option(None, "--alias", "-a", help="自定义别名"),
    limit: int = typer.Option(20, "--limit", "-l", help="搜索结果数量限制"),
    force: bool = typer.Option(False, "--force", "-f", help="强制覆盖已存在的依赖"),
):
    """
    添加依赖到 libs.versions.toml 与 build.gradle(.kts)。
    """
    spec, alias_final = resolve_add(target, alias, limit=limit)

    root = Path(".").resolve()
    catalog = CatalogManager(root)
    gradle = GradleManager(root)
    catalog.load()
    libs = catalog.list_libraries()

    # 检查是否已存在
    existing_alias = libs.get(alias_final)
    existing_gav = None
    for al, s in libs.items():
        if s.gav == spec.gav:
            existing_gav = (al, s)
            break

    if existing_alias and not force:
        console.print()
        console.print(f"  [yellow]别名 '{alias_final}' 已存在：[/]")
        line = Text("    ")
        line.append_text(_format_gav(existing_alias))
        console.print(line)
        if not _confirm_single_key("覆盖？"):
            console.print("  [dim]已取消[/]")
            raise typer.Exit(code=0)
    elif existing_gav and not force:
        old_alias, s = existing_gav
        if old_alias != alias_final:
            console.print()
            console.print(f"  [yellow]依赖已存在（别名 '{old_alias}'）：[/]")
            line = Text("    ")
            line.append_text(_format_gav(s))
            console.print(line)
            if not _confirm_single_key(f"重命名为 '{alias_final}'？"):
                console.print("  [dim]已取消[/]")
                raise typer.Exit(code=0)
            # 删除旧别名
            catalog.remove(old_alias)
            gradle.remove_dependency(old_alias)

    catalog.add_or_update(spec, alias_final)
    gradle.add_dependency(alias_final)
    accessor = GradleManager.to_accessor(alias_final)

    if existing_gav and existing_gav[0] != alias_final:
        _print_dep("~", "bold yellow", alias_final, spec, accessor, note=f"renamed from {existing_gav[0]}")
    elif existing_alias:
        _print_dep("~", "bold yellow", alias_final, spec, accessor, note="updated")
    else:
        _print_dep("+", "bold green", alias_final, spec, accessor)


def resolve_add(target: str, alias: Optional[str], limit: int = 20) -> Tuple[LibrarySpec, str]:
    """
    解析 add 参数但不落盘，返回 (spec, alias_final)。
    可供 add 与 try-add 共用。
    """
    root = Path(".").resolve()
    catalog = CatalogManager(root)
    catalog.load()
    libs = catalog.list_libraries()

    version_hint: Optional[str] = None
    fallback_version: Optional[str] = None
    # 预置别名直接返回
    if target in BUILTIN_ALIASES:
        spec = BUILTIN_ALIASES[target]
        alias_final = alias or spec.alias or target
        fallback_version = BUILTIN_VERSION_FALLBACK.get(spec.gav)
    else:
        alias_final, parsed, artifact_hint, version_hint = parse_input(target, alias)
        # 情况 1：完整 g:a[:v]
        if parsed:
            spec = parsed
            if not alias_final:
                alias_final = spec.alias or spec.artifact.replace("-", "_")
        # 情况 2：alias:version（alias 已存在或为内置）
        elif artifact_hint in libs and version_hint:
            base = libs[artifact_hint]
            spec = LibrarySpec(
                group=base.group, artifact=base.artifact, version=version_hint, alias=base.alias
            )
            alias_final = base.alias
        elif artifact_hint in BUILTIN_ALIASES and version_hint:
            base = BUILTIN_ALIASES[artifact_hint]
            spec = LibrarySpec(
                group=base.group, artifact=base.artifact, version=version_hint, alias=base.alias
            )
            alias_final = alias or base.alias or artifact_hint
            fallback_version = BUILTIN_VERSION_FALLBACK.get(spec.gav)
        else:
            # 情况 3：只有 artifact，需要通过 artifact 搜索
            assert artifact_hint is not None
            cands = search_artifact(artifact_hint, rows=limit, root=root)
            if not cands and artifact_hint in BUILTIN_ALIASES:
                base = BUILTIN_ALIASES[artifact_hint]
                cands = [(base, 1.0, "builtin")]
            spec = choose_candidate(cands)
            if not spec:
                typer.echo("未选择任何候选，操作中止。")
                raise typer.Exit(code=1)
            if version_hint:
                spec.version = version_hint
            default_artifact = (spec.artifact or "").replace("-", "_")
            alias_final = alias or spec.alias or default_artifact
            if spec.gav in BUILTIN_VERSION_FALLBACK:
                fallback_version = BUILTIN_VERSION_FALLBACK[spec.gav]

    spec = ensure_version(spec, version_hint=version_hint, fallback_version=fallback_version)
    default_artifact = (spec.artifact or "").replace("-", "_")
    alias_final = alias_final or default_artifact
    return spec, alias_final


@app.command("try-add")
def try_add(
    target: str = typer.Argument(..., help="同 add，用于试算不落盘"),
    alias: Optional[str] = typer.Option(None, "--alias", "-a", help="自定义别名"),
    limit: int = typer.Option(20, "--limit", "-l", help="搜索结果数量限制"),
):
    """
    试运行 add：仅输出将写入的 alias 与 GAV，不修改文件。
    """
    spec, alias_final = resolve_add(target, alias, limit=limit)
    accessor = GradleManager.to_accessor(alias_final)

    _print_dep("~", "bold yellow", alias_final, spec, accessor, note="dry run")


# -------- search mirror commands -------- #
SEARCH_MIRRORS = {
    "central": "https://central.sonatype.com/api/v1",
    "aliyun": "https://maven.aliyun.com/repository/central",
}


@search_mirror_app.command("list")
def mirror_list():
    """列出内置镜像与当前配置。"""
    root = Path(".").resolve()
    cfg = ZapConfig(root)
    cfg.load()
    current = cfg.get_search_base() or SEARCH_MIRRORS["central"]
    typer.echo("可用镜像：")
    for name, url in SEARCH_MIRRORS.items():
        mark = " *" if url == current else "  "
        typer.echo(f"{mark} {name:<8} {url}")
    # 非内置自定义
    if current not in SEARCH_MIRRORS.values():
        typer.echo(f" * custom  {current}")


@search_mirror_app.command("show")
def mirror_show():
    """显示当前搜索 API 基础地址。"""
    root = Path(".").resolve()
    cfg = ZapConfig(root)
    cfg.load()
    current = cfg.get_search_base() or SEARCH_MIRRORS["central"]
    typer.echo(f"当前搜索基址: {current}")


@search_mirror_app.command("use")
def mirror_use(target: str = typer.Argument(..., help="镜像名或完整 URL")):
    """
    切换搜索 API 镜像（仅影响查询，不影响依赖下载）。
    """
    root = Path(".").resolve()
    cfg = ZapConfig(root)
    cfg.load()

    if target in SEARCH_MIRRORS:
        base = SEARCH_MIRRORS[target]
    else:
        # 简单校验
        if not target.startswith("http"):
            typer.echo("请输入镜像名（如 central/aliyun）或以 http 开头的 URL。")
            raise typer.Exit(code=1)
        base = target.rstrip("/")
    cfg.set_search_base(base)
    typer.echo(f"已切换搜索镜像为: {base}")


@search_mirror_app.command("reset")
def mirror_reset():
    """恢复默认 central 搜索 API。"""
    root = Path(".").resolve()
    cfg = ZapConfig(root)
    cfg.load()
    cfg.set_search_base(None)
    typer.echo(f"已恢复默认: {SEARCH_MIRRORS['central']}")


@app.command()
def rm(
    key: str = typer.Argument(..., help="别名、artifact 名或 group:artifact"),
    force: bool = typer.Option(False, "--force", "-f", help="跳过确认直接删除"),
):
    """删除依赖（catalog 与 build 文件）。"""
    root = Path(".").resolve()
    catalog = CatalogManager(root)
    gradle = GradleManager(root)
    catalog.load()
    libs = catalog.list_libraries()

    # 从 catalog 查找，区分精确匹配和模糊匹配
    catalog_matches = []
    for al, s in libs.items():
        # 精确匹配：别名、artifact、GAV 完全相等
        is_exact = (key == al or key == s.artifact or key == s.gav or key == f"{s.group}:{s.artifact}")
        # 模糊匹配：子串匹配
        is_fuzzy = (not is_exact and (key.lower() in al.lower() or key.lower() in s.artifact.lower()))
        if is_exact or is_fuzzy:
            catalog_matches.append((al, s, "catalog", is_exact))

    # 从直接依赖查找
    direct_deps = gradle.list_direct_dependencies()
    direct_matches = []
    for spec in direct_deps:
        is_exact = (key == spec.artifact or key == spec.gav or key == f"{spec.group}:{spec.artifact}")
        is_fuzzy = (not is_exact and key.lower() in spec.artifact.lower())
        if is_exact or is_fuzzy:
            direct_matches.append((spec.artifact, spec, "direct", is_exact))

    all_matches = catalog_matches + direct_matches

    if not all_matches:
        console.print(f"  [yellow]未找到: {key}[/]")
        raise typer.Exit(code=1)

    # 选择
    if len(all_matches) == 1:
        name, spec, source, is_exact = all_matches[0]
        # 非精确匹配需要确认
        if not is_exact and not force:
            console.print()
            console.print(f"  [yellow]模糊匹配：[/]")
            line = Text("    ")
            line.append(name, style="bold white")
            line.append(f"  ", style="dim")
            line.append_text(_format_gav(spec))
            console.print(line)
            if not _confirm_single_key("删除？"):
                console.print("  [dim]已取消[/]")
                raise typer.Exit(code=0)
    else:
        console.print()
        for idx, (name, spec, source, is_exact) in enumerate(all_matches, start=1):
            line = Text()
            line.append(f"  {idx}. ", style="bold cyan")
            line.append(name, style="bold white")
            line.append(f"  {spec.gav}", style="dim")
            line.append(f"  [{source}]", style="dim")
            if not is_exact:
                line.append("  (fuzzy)", style="dim yellow")
            console.print(line)
        console.print("  0. ", style="bold cyan", end="")
        console.print("退出", style="dim")
        console.print()

        try:
            choice = int(typer.prompt("选择", default="1"))
        except ValueError:
            return
        if choice <= 0 or choice > len(all_matches):
            return
        name, spec, source, is_exact = all_matches[choice - 1]

    # 检查是否有版本引用需要清理 (仅 catalog)
    version_ref = None
    if source == "catalog" and spec and isinstance(spec.version, dict) and "ref" in spec.version:
        version_ref = spec.version["ref"]

    # 删除
    removed = False
    removed_version = False
    if source == "catalog":
        removed_catalog = catalog.remove(name)
        removed_gradle = gradle.remove_dependency(name)
        removed = removed_catalog or removed_gradle
        # 如果版本引用不再被其他库使用，删除它
        if version_ref and not catalog.is_version_ref_used(version_ref):
            removed_version = catalog.remove_version(version_ref)
    else:  # direct
        removed = gradle.remove_direct_dependency(spec.group, spec.artifact)

    if removed:
        _print_dep("-", "bold red", name, spec)
        if source == "direct":
            console.print(f"    [dim]\\[direct][/]")
        if removed_version:
            console.print(f"    [dim]cleaned: versions.{version_ref}[/]")
        console.print()
    else:
        console.print(f"  [yellow]未删除: {name} (可能已不存在)[/]")


@app.command()
def list():
    """列出项目中的全部依赖。"""
    root = Path(".").resolve()
    catalog = CatalogManager(root)
    gradle = GradleManager(root)
    catalog.load()

    # 从 version catalog 读取
    catalog_libs = catalog.list_libraries()

    # 从 build.gradle(.kts) 读取直接写的依赖
    direct_deps = gradle.list_direct_dependencies()

    if not catalog_libs and not direct_deps:
        console.print("  [dim](empty)[/]")
        return

    console.print()

    # 显示 catalog 中的
    if catalog_libs:
        max_alias = max(len(alias) for alias in catalog_libs.keys())
        for alias, spec in catalog_libs.items():
            # 解析版本引用
            resolved = None
            version_val = spec.version
            if isinstance(version_val, dict) and "ref" in version_val:
                ref_key = version_val["ref"]  # type: ignore[index]
                resolved = catalog.get_version(ref_key)

            line = Text(f"  {alias:<{max_alias}}  ", style="bold")
            line.append_text(_format_gav(spec, resolved))
            line.append("  [catalog]", style="dim")
            console.print(line)

    # 显示直接写的
    if direct_deps:
        for spec in direct_deps:
            line = Text("  ")
            line.append(spec.group, style="dim")
            line.append(":", style="dim")
            line.append(spec.artifact, style="bold white")
            if spec.version:
                line.append(":", style="dim")
                line.append(spec.version, style="cyan")
            line.append("  [direct]", style="dim")
            console.print(line)

    console.print()


@app.command()
def search(
    artifact: str = typer.Argument(..., help="要搜索的 artifact 名称"),
    limit: int = typer.Option(20, "--limit", "-l", help="搜索结果数量限制"),
):
    """
    搜索 Maven Central 的依赖并可选择插入。
    """
    root = Path(".").resolve()
    cands = search_artifact(artifact, rows=limit, root=root)
    if not cands and artifact in BUILTIN_ALIASES:
        base = BUILTIN_ALIASES[artifact]
        cands = [(base, 1.0, "builtin")]

    spec = choose_candidate(cands)
    if not spec:
        return
    default_alias = (spec.artifact or "").replace("-", "_")
    alias = typer.prompt("别名", default=default_alias)
    if typer.confirm(f"添加 {alias}?", default=True):
        root = Path(".").resolve()
        catalog = CatalogManager(root)
        gradle = GradleManager(root)
        spec = ensure_version(spec)
        catalog.add_or_update(spec, alias)
        gradle.add_dependency(alias)
        accessor = GradleManager.to_accessor(alias)

        _print_dep("+", "bold green", alias, spec, accessor)


@app.command()
def sync(
    gradlew: Optional[str] = typer.Option(None, help="Gradle Wrapper 路径；默认按平台自动选择"),
    args: List[str] = typer.Option(["--refresh-dependencies"], help="额外参数"),
):
    """
    调用 Gradle Wrapper 触发依赖下载。
    """
    # 平台适配：Windows 用 gradlew.bat，其余用 ./gradlew
    if gradlew is None:
        is_windows = platform.system().lower().startswith("win")
        gradlew = "gradlew.bat" if is_windows else "./gradlew"

    cmd = [gradlew] + args
    typer.echo(f"运行: {' '.join(cmd)}")
    try:
        subprocess.run(cmd, check=True)
    except subprocess.CalledProcessError as exc:
        typer.echo(f"gradle 执行失败: {exc}")
        raise typer.Exit(code=exc.returncode)


@app.callback(invoke_without_command=True)
def main(ctx: typer.Context):
    """显示版本或默认帮助。"""
    if ctx.invoked_subcommand is None:
        typer.echo(f"zap v{__version__}")
        typer.echo(ctx.get_help())


def run():
    """入口，便于 main.py 调用。"""
    app()


if __name__ == "__main__":
    run()
