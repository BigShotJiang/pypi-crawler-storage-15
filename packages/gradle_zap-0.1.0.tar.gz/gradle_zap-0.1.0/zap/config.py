from __future__ import annotations

from pathlib import Path
from typing import Optional

import tomlkit


class ZapConfig:
    """Read/write .zaprc (TOML) in project root."""

    def __init__(self, root: Path):
        self.root = root
        self.path = root / ".zaprc"
        self.data = {}

    def load(self) -> None:
        if self.path.exists():
            self.data = tomlkit.parse(self.path.read_text(encoding="utf-8"))
        else:
            self.data = {}

    def save(self) -> None:
        self.path.write_text(tomlkit.dumps(self.data), encoding="utf-8")

    # ------- search mirror ------- #
    def get_search_base(self) -> Optional[str]:
        return self.data.get("search_base")

    def set_search_base(self, base: Optional[str]) -> None:
        if base is None:
            # remove key if exists
            if "search_base" in self.data:
                del self.data["search_base"]
        else:
            self.data["search_base"] = base
        self.save()
