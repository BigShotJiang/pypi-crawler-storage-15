#!/bin/bash
factor1=$1
factor2=$2
result=$[$factor1*$factor2] 
echo $result
