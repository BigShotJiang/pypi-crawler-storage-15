#ifndef DUNE_FEM_CACHINGPOINTLIST_HH
#define DUNE_FEM_CACHINGPOINTLIST_HH
#warning "Deprecated header, use #include <dune/fem/quadrature/cachingquadrature.hh> instead!"
#include <dune/fem/quadrature/cachingquadrature.hh>
#endif // #ifndef DUNE_FEM_CACHINGPOINTLIST_HH
