#ifndef DUNE_FEM_ELEMENTPOINTLIST_HH
#define DUNE_FEM_ELEMENTPOINTLIST_HH
#warning "Deprecated header, use #include <dune/fem/quadrature/elementquadrature.hh> instead!"
#include <dune/fem/quadrature/elementquadrature.hh>
#endif // #ifndef DUNE_FEM_ELEMENTPOINTLIST_HH
