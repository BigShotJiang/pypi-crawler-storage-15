#ifndef DUNE_FEM_SOLVER_PARDGINVERSEOPERATORS_HH
#define DUNE_FEM_SOLVER_PARDGINVERSEOPERATORS_HH
#warning "Depreacted header, use #include <dune/fem/solver/krylovinverseoperators.hh> instead!"
#include <dune/fem/solver/krylovinverseoperators.hh>
#endif // #ifndef DUNE_FEM_SOLVER_PARDGINVERSEOPERATORS_HH
