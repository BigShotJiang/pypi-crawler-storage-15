#ifndef DUNE_FEM_OMPMANAGER_HH
#define DUNE_FEM_OMPMANAGER_HH
#include <dune/fem/misc/mpimanager.hh>
#warning "Deprecated header, use #include <dune/fem/misc/mpimanager.hh> instead!"
#endif // #ifndef DUNE_FEM_OMPMANAGER_HH
