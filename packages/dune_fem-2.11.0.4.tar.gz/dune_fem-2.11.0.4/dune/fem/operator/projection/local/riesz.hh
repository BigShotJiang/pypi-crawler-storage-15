#include <dune/fem/operator/projection/local/riesz/dense.hh>
#include <dune/fem/operator/projection/local/riesz/localrieszprojection.hh>
#include <dune/fem/operator/projection/local/riesz/orthonormal.hh>
