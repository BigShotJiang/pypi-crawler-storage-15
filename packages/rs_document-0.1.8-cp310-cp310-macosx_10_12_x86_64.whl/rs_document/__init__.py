from .rs_document import *

__doc__ = rs_document.__doc__
if hasattr(rs_document, "__all__"):
    __all__ = rs_document.__all__
