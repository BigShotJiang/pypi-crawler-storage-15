"""HTTP API client for WiiM/LinkPlay devices."""
