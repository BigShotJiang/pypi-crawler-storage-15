from PipeGraphPy.core.modules import MBase


class DatachartsBase(MBase):
    pass
