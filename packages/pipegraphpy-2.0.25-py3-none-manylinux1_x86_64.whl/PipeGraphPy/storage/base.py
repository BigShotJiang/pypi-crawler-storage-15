class ParamsPoolBase(object):
    pass
