# 本文件存储通用变量或全局变量


multi_graph = dict()
