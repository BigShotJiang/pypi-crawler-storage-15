import setuptools
from drm_protect import main

main()

setuptools.setup()
