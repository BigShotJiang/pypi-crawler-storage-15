from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Optional

from .identifiers import InstrumentId, OrderId, ClientOrderId, AccountId, StrategyId
from .time import Timestamp
from .money import Money, Price, Quantity, Fee, Rate
from .validation import (
    ensure_required_decimal,
    ensure_positive_decimal,
    ensure_non_negative_decimal,
    ensure_non_empty_str,
    ensure_non_negative_ts,
    ensure_optional_non_negative_ts,
)

__all__ = [
    "OrderSide",
    "OrderType",
    "TimeInForce",
    "OrderStatus",
    "PositionSide",
    "LiquiditySide",
    "OrderRequest",
    "OrderUpdate",
    "Fill",
    "FundingEvent",
    "FeeEvent",
]

# Trading event primitives

class OrderSide(str, Enum):
    BUY = "BUY"
    SELL = "SELL"

class OrderType(str, Enum):
    MARKET = "MARKET"
    LIMIT = "LIMIT"
    STOP = "STOP"
    STOP_LIMIT = "STOP_LIMIT"
    TRAILING_STOP = "TRAILING_STOP"

class TimeInForce(str, Enum):
    GTC = "GTC"
    IOC = "IOC"
    FOK = "FOK"
    GTD = "GTD"

class OrderStatus(str, Enum):
    CREATED = "CREATED"
    NEW = "NEW"
    PARTIALLY_FILLED = "PARTIALLY_FILLED"
    FILLED = "FILLED"
    CANCELED = "CANCELED"
    REJECTED = "REJECTED"
    EXPIRED = "EXPIRED"

class PositionSide(str, Enum):
    LONG = "LONG"
    SHORT = "SHORT"

class LiquiditySide(str, Enum):
    MAKER = "MAKER"
    TAKER = "TAKER"

@dataclass
class OrderRequest:
    """Request to create a new order."""
    instrument_id: InstrumentId
    side: OrderSide
    type: OrderType

    quantity: Quantity
    price: Optional[Price] = None
    stop_price: Optional[Price] = None

    time_in_force: TimeInForce = TimeInForce.GTC

    client_order_id: ClientOrderId = ""
    account_id: Optional[AccountId] = None
    strategy_id: Optional[StrategyId] = None

    reduce_only: bool = False
    post_only: bool = False

    ingest_ts: Optional[Timestamp] = None

    def __post_init__(self) -> None:
        self.quantity = Quantity(ensure_positive_decimal(self.quantity, "quantity"))

        if self.price is not None:
            self.price = Price(ensure_positive_decimal(self.price, "price"))

        if self.stop_price is not None:
            self.stop_price = Price(ensure_positive_decimal(self.stop_price, "stop_price"))

        self.client_order_id = ClientOrderId(ensure_non_empty_str(self.client_order_id, "client_order_id"))

        if self.type in {OrderType.LIMIT, OrderType.STOP_LIMIT} and self.price is None:
            raise ValueError("price is required for LIMIT and STOP_LIMIT orders")

        if self.type in {OrderType.STOP, OrderType.STOP_LIMIT, OrderType.TRAILING_STOP} and self.stop_price is None:
            raise ValueError("stop_price is required for stop-based orders")

        ensure_optional_non_negative_ts(self.ingest_ts, "ingest_ts")

@dataclass
class OrderUpdate:
    """Update on an order's state (from exchange or internal)."""
    order_id: Optional[OrderId]
    client_order_id: Optional[ClientOrderId]

    instrument_id: InstrumentId
    status: OrderStatus

    filled_quantity: Quantity
    remaining_quantity: Quantity
    average_price: Optional[Price]

    ts: Timestamp

    message: str = ""
    ingest_ts: Optional[Timestamp] = None

    def __post_init__(self) -> None:
        self.filled_quantity = Quantity(ensure_non_negative_decimal(self.filled_quantity, "filled_quantity"))
        self.remaining_quantity = Quantity(ensure_non_negative_decimal(self.remaining_quantity, "remaining_quantity"))

        if self.average_price is not None:
            self.average_price = Price(ensure_positive_decimal(self.average_price, "average_price"))

        ensure_non_negative_ts(self.ts, "ts")
        ensure_optional_non_negative_ts(self.ingest_ts, "ingest_ts")

@dataclass
class Fill:
    """Execution report for a trade."""
    fill_id: str

    order_id: Optional[OrderId]
    client_order_id: Optional[ClientOrderId]

    instrument_id: InstrumentId
    side: OrderSide

    price: Price
    quantity: Quantity

    ts: Timestamp
    ingest_ts: Optional[Timestamp] = None

    fee: Optional[Fee] = None
    fee_currency: Optional[str] = None

    is_maker: bool = False
    liquidity: Optional[LiquiditySide] = None

    def __post_init__(self) -> None:
        self.price = Price(ensure_positive_decimal(self.price, "price"))
        self.quantity = Quantity(ensure_positive_decimal(self.quantity, "quantity"))

        if self.fee is not None:
            self.fee = Fee(ensure_non_negative_decimal(self.fee, "fee"))

        if self.liquidity is None:
            self.liquidity = LiquiditySide.MAKER if self.is_maker else LiquiditySide.TAKER

        ensure_non_negative_ts(self.ts, "ts")
        ensure_optional_non_negative_ts(self.ingest_ts, "ingest_ts")

@dataclass
class FundingEvent:
    """Periodic funding payment for a derivative instrument."""
    instrument_id: InstrumentId
    rate: Rate
    payment: Money
    position_quantity: Quantity

    ts: Timestamp
    ingest_ts: Optional[Timestamp] = None

    def __post_init__(self) -> None:
        # Funding can be positive or negative, so only type-check (no positivity).
        self.rate = Rate(ensure_required_decimal(self.rate, "rate"))
        self.payment = Money(ensure_required_decimal(self.payment, "payment"))
        self.position_quantity = Quantity(ensure_required_decimal(self.position_quantity, "position_quantity"))

        ensure_non_negative_ts(self.ts, "ts")
        ensure_optional_non_negative_ts(self.ingest_ts, "ingest_ts")

@dataclass
class FeeEvent:
    """Non-fill fee assessment (e.g., borrow fees, account-level charges)."""
    instrument_id: InstrumentId
    fee: Fee

    ts: Timestamp
    ingest_ts: Optional[Timestamp] = None

    order_id: Optional[OrderId] = None
    client_order_id: Optional[ClientOrderId] = None
    currency: Optional[str] = None

    def __post_init__(self) -> None:
        self.fee = Fee(ensure_non_negative_decimal(self.fee, "fee"))

        if self.currency is not None:
            ensure_non_empty_str(self.currency, "currency")

        ensure_non_negative_ts(self.ts, "ts")
        ensure_optional_non_negative_ts(self.ingest_ts, "ingest_ts")
