from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_UP
from typing import NewType

from .validation import (
    ensure_decimal,
    ensure_positive_decimal,
    ensure_non_negative_decimal,
    ensure,
)

__all__ = [
    "Money",
    "Price",
    "Quantity",
    "Notional",
    "Rate",
    "Fee",
    "InstrumentPrecision",
    "round_to_tick",
    "quantize_value",
]

# Money + precision primitives

Money = NewType("Money", Decimal)      # account-level cash movements / balances
Price = NewType("Price", Decimal)
Quantity = NewType("Quantity", Decimal)
Notional = NewType("Notional", Decimal)
Rate = NewType("Rate", Decimal)  # e.g., funding/interest rates
Fee = NewType("Fee", Decimal)    # fee amount (not a price)

@dataclass(frozen=True)
class InstrumentPrecision:
    """Precision and scaling metadata for an instrument."""
    tick_size: Decimal
    lot_size: Decimal
    min_notional: Decimal
    quote_currency_scale: int  # decimal places for quote
    base_currency_scale: int   # decimal places for base

    def __post_init__(self) -> None:
        ensure_positive_decimal(self.tick_size, "tick_size")
        ensure_positive_decimal(self.lot_size, "lot_size")
        ensure_non_negative_decimal(self.min_notional, "min_notional")

        ensure(self.quote_currency_scale >= 0, "quote_currency_scale must be non-negative")
        ensure(self.base_currency_scale >= 0, "base_currency_scale must be non-negative")

def round_to_tick(value: Decimal, tick_size: Decimal) -> Decimal:
    """Rounds a value to the nearest tick size."""
    ensure_decimal(value, "value")
    ensure_positive_decimal(tick_size, "tick_size")
    return (value / tick_size).quantize(Decimal("1"), rounding=ROUND_HALF_UP) * tick_size

def quantize_value(value: Decimal, precision: Decimal) -> Decimal:
    """Quantizes a value to a given precision (e.g., 0.01)."""
    ensure_decimal(value, "value")
    ensure_positive_decimal(precision, "precision")
    return value.quantize(precision, rounding=ROUND_HALF_UP)
