import json
import sys
from datetime import timezone
from decimal import Decimal
from pathlib import Path

import pytest

# Ensure src is importable without installation
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.append(str(SRC))

from qlcontracts import (  # noqa: E402
    InstrumentId,
    Money,
    OrderId,
    OrderSide,
    errors,
    events,
    identifiers,
    money,
    serialization,
    time as qltime,
    validation,
)


def test_validation_boolean_and_type_checks():
    validation.ensure(True, "ok")
    assert validation.ensure_type("abc", str, "field") == "abc"
    with pytest.raises(ValueError):
        validation.ensure(False, "boom")
    with pytest.raises(TypeError):
        validation.ensure_type(123, str, "field")


def test_validation_decimal_rules():
    value = Decimal("1.2")
    assert validation.ensure_decimal(value, "price") == value
    assert validation.ensure_decimal(None, "price") is None

    with pytest.raises(TypeError):
        validation.ensure_decimal(1.2, "price")
    with pytest.raises(ValueError):
        validation.ensure_required_decimal(None, "price")

    assert validation.ensure_positive_decimal(Decimal("0.0001"), "price") == Decimal("0.0001")
    with pytest.raises(ValueError):
        validation.ensure_positive_decimal(Decimal("0"), "price")
    with pytest.raises(ValueError):
        validation.ensure_positive_decimal(Decimal("-1"), "price")

    assert validation.ensure_non_negative_decimal(Decimal("0"), "fee") == Decimal("0")
    with pytest.raises(ValueError):
        validation.ensure_non_negative_decimal(Decimal("-0.1"), "fee")


def test_validation_string_and_timestamp_rules():
    assert validation.ensure_non_empty_str("abc", "name") == "abc"
    with pytest.raises(TypeError):
        validation.ensure_non_empty_str(123, "name")
    with pytest.raises(ValueError):
        validation.ensure_non_empty_str("", "name")

    assert validation.ensure_non_negative_ts(0, "ts") == 0
    with pytest.raises(ValueError):
        validation.ensure_non_negative_ts(-1, "ts")

    assert validation.ensure_optional_non_negative_ts(None, "ts") is None
    with pytest.raises(ValueError):
        validation.ensure_optional_non_negative_ts(-5, "ts")


def test_coerce_if_applies_callable():
    assert validation.coerce_if(3, lambda v: v + 1) == 4


def test_top_level_exports_provide_common_facade():
    cash = Money(Decimal("10"))
    oid = OrderId("abc-123")
    inst = InstrumentId("BINANCE:BTC-USDT")

    assert isinstance(cash, Decimal)
    assert oid == "abc-123"
    assert inst == "BINANCE:BTC-USDT"
    assert OrderSide.BUY == events.OrderSide.BUY


def test_time_conversion_and_range_validation():
    now = qltime.now_ms()
    dt = qltime.to_datetime(qltime.Timestamp(now))
    assert dt.tzinfo == timezone.utc

    round_tripped = qltime.to_timestamp(dt)
    assert isinstance(round_tripped, int)
    assert round_tripped == qltime.Timestamp(int(dt.timestamp() * 1000))

    with pytest.raises(ValueError):
        qltime.to_datetime(qltime.Timestamp(-1))

    start = qltime.Timestamp(now)
    end = qltime.Timestamp(now + 500)
    tr = qltime.TimeRange(start=start, end=end)
    assert tr.end - tr.start == 500

    with pytest.raises(ValueError):
        qltime.TimeRange(start=qltime.Timestamp(10), end=qltime.Timestamp(5))
    with pytest.raises(ValueError):
        qltime.TimeRange(start=qltime.Timestamp(-1), end=qltime.Timestamp(0))


def test_money_precision_validation():
    prec = money.InstrumentPrecision(
        tick_size=Decimal("0.01"),
        lot_size=Decimal("0.001"),
        min_notional=Decimal("0"),
        quote_currency_scale=2,
        base_currency_scale=3,
    )
    assert prec.base_currency_scale == 3

    with pytest.raises(ValueError):
        money.InstrumentPrecision(
            tick_size=Decimal("0"),
            lot_size=Decimal("0.001"),
            min_notional=Decimal("0"),
            quote_currency_scale=2,
            base_currency_scale=3,
        )
    with pytest.raises(ValueError):
        money.InstrumentPrecision(
            tick_size=Decimal("0.01"),
            lot_size=Decimal("-0.001"),
            min_notional=Decimal("0"),
            quote_currency_scale=2,
            base_currency_scale=3,
        )
    with pytest.raises(ValueError):
        money.InstrumentPrecision(
            tick_size=Decimal("0.01"),
            lot_size=Decimal("0.001"),
            min_notional=Decimal("-1"),
            quote_currency_scale=2,
            base_currency_scale=3,
        )
    with pytest.raises(ValueError):
        money.InstrumentPrecision(
            tick_size=Decimal("0.01"),
            lot_size=Decimal("0.001"),
            min_notional=Decimal("0"),
            quote_currency_scale=-1,
            base_currency_scale=3,
        )


def test_round_to_tick_and_quantize_value():
    value = Decimal("100.005")
    assert money.round_to_tick(value, Decimal("0.01")) == Decimal("100.01")
    assert money.quantize_value(value, Decimal("0.01")) == Decimal("100.01")

    with pytest.raises(ValueError):
        money.round_to_tick(value, Decimal("0"))
    with pytest.raises(TypeError):
        money.round_to_tick(123, Decimal("0.01"))  # type: ignore[arg-type]

    with pytest.raises(ValueError):
        money.quantize_value(value, Decimal("0"))
    with pytest.raises(TypeError):
        money.quantize_value("abc", Decimal("0.01"))  # type: ignore[arg-type]


def test_errors_result_invariants_and_helpers():
    ok = errors.Result.Ok(10)
    assert ok.is_ok and not ok.is_err
    assert ok.unwrap() == 10

    err_result = errors.Result.Err(errors.ExecutionError(message="fail"))
    assert err_result.is_err and not err_result.is_ok
    with pytest.raises(ValueError):
        err_result.unwrap()
    assert err_result.unwrap_or(5) == 5

    with pytest.raises(ValueError):
        errors.Result(value=1, error=errors.ErrorBase(message="x"))
    with pytest.raises(ValueError):
        errors.Result()


def test_serialization_envelope_and_payload():
    req = events.OrderRequest(
        instrument_id=identifiers.InstrumentId("BTC-USDT"),
        side=events.OrderSide.BUY,
        type=events.OrderType.LIMIT,
        quantity=money.Quantity(Decimal("1.0")),
        price=money.Price(Decimal("123.45")),
        client_order_id=identifiers.ClientOrderId("cid-1"),
    )

    json_str = serialization.to_json(req)
    data = json.loads(json_str)
    assert data["schema"] == serialization.SCHEMA_VERSION
    assert data["payload"]["client_order_id"] == "cid-1"
    assert data["payload"]["price"] == "123.45"

    raw_json = serialization.to_json(req, envelope=False)
    payload = json.loads(raw_json)
    assert "schema" not in payload
    assert payload["side"] == "BUY"


def test_serialization_parse_decimals_and_errors():
    bad_schema = json.dumps({"schema": "qlcontracts/v0", "payload": {}})
    with pytest.raises(ValueError):
        serialization.from_json(bad_schema)

    missing_payload = json.dumps({"schema": serialization.SCHEMA_VERSION})
    with pytest.raises(ValueError):
        serialization.from_json(missing_payload)

    manual_numeric = json.dumps({"schema": serialization.SCHEMA_VERSION, "payload": {"value": 1.5}})
    decoded = serialization.from_json(manual_numeric, parse_decimals=True)
    assert decoded["value"] == Decimal("1.5")


def test_serialization_handles_money_and_price_aliases():
    funding = events.FundingEvent(
        instrument_id=identifiers.InstrumentId("BINANCE:BTC-USDT"),
        rate=money.Rate(Decimal("0.0001")),
        payment=money.Money(Decimal("5.50")),
        position_quantity=money.Quantity(Decimal("1.5")),
        ts=qltime.now_ms(),
    )

    payload = json.loads(serialization.to_json(funding, envelope=False))
    assert payload["payment"] == "5.50"
    assert payload["rate"] == "0.0001"
    assert payload["position_quantity"] == "1.5"
