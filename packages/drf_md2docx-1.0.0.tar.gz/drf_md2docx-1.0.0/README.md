# DRF API for Converting Markdown to Docx

## Installation

```bash
pip install drf_md2docx
```

## Usage

### Create a new project

```bash
django-admin startproject myproject
cd myproject
```

### Add the app to your project's `settings.py`

```python
INSTALLED_APPS = [
    ...
    'drf_md2docx',
    ...
]
```

### Add configurations to your project's `settings.py`

```python
MEDIA_ROOT = 'data/'
MEDIA_URL = '/api/media/'

MD2DOCX_PERMISSIONS = [
    permissions.AllowAny,
]

MD2DOCX_OUTPUT_DIR = Path(MEDIA_ROOT) / 'md2docx'
```

### Add urlpatterns to your project's `urls.py`

```python
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path("api/md2docx/", include('drf_md2docx.urls')),
]

urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
```

## Request and Response

![alt text](static/request.png)

![alt text](static/response.png)