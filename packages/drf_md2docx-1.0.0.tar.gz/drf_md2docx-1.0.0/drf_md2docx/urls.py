from django.urls import path
from . import views

urlpatterns = [
    path('', views.MD2DocxView.as_view(), name='md2docx'),
]
