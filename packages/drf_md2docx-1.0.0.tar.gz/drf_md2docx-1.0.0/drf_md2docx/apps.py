from django.apps import AppConfig


class DrfMd2DocxConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'drf_md2docx'
