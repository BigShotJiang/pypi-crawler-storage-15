
import uuid
from pathlib import Path

from django.conf import settings
from django.http import FileResponse
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.views import APIView
from rest_framework.response import Response
from md2docx.core import MD2DOCX


class MD2DocxView(APIView):
    __route__ = 'md2docx'

    def get_permissions(self):
        if hasattr('settings', 'MD2DOCX_PERMISSIONS'):
            return [permission() for permission in settings.MD2DOCX_PERMISSIONS]
        return [AllowAny()]

    def post(self, request):
        """Convert markdown to docx

        expected request data:
        {
            "md": "## Hello world",
            "result_file": "result.docx"
        }

        return:
        {
            "success": true,
            "data": {
                "file_name": "xxxx_result.docx",
                "file_url": "/api/media/md2docx/xxxx_result.docx"
            }
        }
        """
        md = request.data.get('md', '')
        result_file = request.data.get('result_file', 'result.docx')

        if not md.strip():
            return Response({
                'success': False,
                'message': 'md is required!',
            })

        if hasattr('settings', 'MD2DOCX_OUTPUT_DIR'):
            output_dir = settings.MD2DOCX_OUTPUT_DIR
        else:
            output_dir = Path(settings.MEDIA_ROOT) / 'md2docx'

        Path(output_dir).mkdir(parents=True, exist_ok=True)

        result_file = Path(output_dir) / f'{uuid.uuid4().hex}_{result_file}'
        MD2DOCX().convert(
            md,
            output_file=result_file,
        )

        file_url = result_file.as_posix().replace(settings.MEDIA_ROOT, settings.MEDIA_URL)

        return Response({
            'success': True,
            'data': {
                'file_name': result_file.name,
                'file_url': file_url,
            }
        })
