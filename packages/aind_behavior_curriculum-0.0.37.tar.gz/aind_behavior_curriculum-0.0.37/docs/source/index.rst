AIND Behavior Curriculum library
=======================================================

.. mdinclude:: ../../README.md

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   self
   intro
   _autosummary/aind_behavior_curriculum
   Examples <https://github.com/AllenNeuralDynamics/aind-behavior-curriculum/tree/main/examples>
   GitHub Source Code <https://github.com/AllenNeuralDynamics/aind-behavior-curriculum>

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
