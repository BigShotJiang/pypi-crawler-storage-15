aind\_behavior\_curriculum.curriculum.try\_materialize\_non\_deserializable\_callable\_error
============================================================================================

.. currentmodule:: aind_behavior_curriculum.curriculum

.. autofunction:: try_materialize_non_deserializable_callable_error