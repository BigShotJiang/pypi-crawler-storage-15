aind\_behavior\_curriculum.curriculum.create\_curriculum
========================================================

.. currentmodule:: aind_behavior_curriculum.curriculum

.. autofunction:: create_curriculum