aind\_behavior\_curriculum.trainer.Trainer
==========================================

.. currentmodule:: aind_behavior_curriculum.trainer

.. autoclass:: Trainer
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Trainer.__init__
      ~Trainer.create_trainer_state
      ~Trainer.evaluate
      ~Trainer.get_net_parameter_update
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Trainer.curriculum
   
   