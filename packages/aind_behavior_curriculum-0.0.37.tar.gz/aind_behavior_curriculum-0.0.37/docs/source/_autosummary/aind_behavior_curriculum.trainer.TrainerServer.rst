aind\_behavior\_curriculum.trainer.TrainerServer
================================================

.. currentmodule:: aind_behavior_curriculum.trainer

.. autoclass:: TrainerServer
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TrainerServer.__init__
      ~TrainerServer.eject_subject
      ~TrainerServer.evaluate_subjects
      ~TrainerServer.load_data
      ~TrainerServer.override_subject_status
      ~TrainerServer.register_subject
      ~TrainerServer.write_data
   
   

   
   
   