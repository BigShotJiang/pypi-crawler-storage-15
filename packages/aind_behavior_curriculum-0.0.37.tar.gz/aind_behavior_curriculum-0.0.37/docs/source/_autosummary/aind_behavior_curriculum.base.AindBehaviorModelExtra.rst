aind\_behavior\_curriculum.base.AindBehaviorModelExtra
======================================================

.. currentmodule:: aind_behavior_curriculum.base

.. autoclass:: AindBehaviorModelExtra
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~AindBehaviorModelExtra.__init__
      ~AindBehaviorModelExtra.construct
      ~AindBehaviorModelExtra.copy
      ~AindBehaviorModelExtra.dict
      ~AindBehaviorModelExtra.from_orm
      ~AindBehaviorModelExtra.json
      ~AindBehaviorModelExtra.model_construct
      ~AindBehaviorModelExtra.model_copy
      ~AindBehaviorModelExtra.model_dump
      ~AindBehaviorModelExtra.model_dump_json
      ~AindBehaviorModelExtra.model_json_schema
      ~AindBehaviorModelExtra.model_parametrized_name
      ~AindBehaviorModelExtra.model_post_init
      ~AindBehaviorModelExtra.model_rebuild
      ~AindBehaviorModelExtra.model_validate
      ~AindBehaviorModelExtra.model_validate_json
      ~AindBehaviorModelExtra.model_validate_strings
      ~AindBehaviorModelExtra.parse_file
      ~AindBehaviorModelExtra.parse_obj
      ~AindBehaviorModelExtra.parse_raw
      ~AindBehaviorModelExtra.schema
      ~AindBehaviorModelExtra.schema_json
      ~AindBehaviorModelExtra.update_forward_refs
      ~AindBehaviorModelExtra.validate
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~AindBehaviorModelExtra.model_computed_fields
      ~AindBehaviorModelExtra.model_config
      ~AindBehaviorModelExtra.model_extra
      ~AindBehaviorModelExtra.model_fields
      ~AindBehaviorModelExtra.model_fields_set
   
   