aind\_behavior\_curriculum.curriculum\_utils.export\_diagram
============================================================

.. currentmodule:: aind_behavior_curriculum.curriculum_utils

.. autofunction:: export_diagram