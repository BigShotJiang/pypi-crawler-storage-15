﻿aind\_behavior\_curriculum.task
===============================

.. automodule:: aind_behavior_curriculum.task
  
   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree:
   
      create_task
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom-class-template.rst               
   
      Task
   
   

   
   
   



