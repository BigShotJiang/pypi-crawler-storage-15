from __future__ import annotations

from getpass import getuser

USER = getuser()


__all__ = ["USER"]
