"""Allow running the CLI as a module: python -m openweights.cli"""

from openweights.cli import main

if __name__ == "__main__":
    main()
