export { JobDetailView, RunDetailView, WorkerDetailView } from './DetailViews/index';
