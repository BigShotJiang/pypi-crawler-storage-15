---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

**Urgency**: one sentence re how urgent this is
**Description**
Explain the feature you'd like to see
