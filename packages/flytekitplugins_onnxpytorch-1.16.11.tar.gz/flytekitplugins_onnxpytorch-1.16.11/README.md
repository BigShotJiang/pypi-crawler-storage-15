# Flytekit ONNX PyTorch Plugin

This plugin allows you to generate ONNX models from your PyTorch models.

To install the plugin, run the following command:

```
pip install flytekitplugins-onnxpytorch
```
