"""Prompts for DoDo agents."""

from .default import DEFAULT_SYSTEM_PROMPT

__all__ = ["DEFAULT_SYSTEM_PROMPT"]
