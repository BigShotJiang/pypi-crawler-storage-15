def hello() -> str:
    return "Hello from finagle-service!"
