"""This module only makes the version available for toml dynamic versioning"""

VERSION = "1.0.10"
