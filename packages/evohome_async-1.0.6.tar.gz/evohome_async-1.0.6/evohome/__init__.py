"""evohomeasync provides an async client for the Resideo TCC API."""

from __future__ import annotations

__version__ = "1.0.6"
