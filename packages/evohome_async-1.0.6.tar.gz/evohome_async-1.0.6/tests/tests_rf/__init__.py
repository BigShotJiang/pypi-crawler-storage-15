"""Mocked vendor server for provision via a hacked aiohttp."""
