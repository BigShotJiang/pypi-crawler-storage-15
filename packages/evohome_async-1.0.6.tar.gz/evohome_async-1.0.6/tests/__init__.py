"""Tests for evohome-async."""
