from a2a_acl.content_codecs import python_codec

codec_object = python_codec.codec_object
