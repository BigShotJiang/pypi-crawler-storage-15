# re-export for backward compatibility
from .pypinyin import export
