from .pinyin import gen as pinyin
from .rime import gen as rime
