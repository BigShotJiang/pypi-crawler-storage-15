LIBIME_BIN_NAME = "libime_pinyindict"
LIBIME_REPOLOGY_URL = "https://repology.org/project/libime"
PARTIAL_DEPRECATED_APCONTINUE = "apcontinue"
PARTIAL_CONTINUE_DICT = "continue_dict"
PARTIAL_TITLES = "titles"
ADVANCED_MODE_TRIGGER_PARAMETER_NAMES = ["action", "list", "format"]
LOG_LEVEL_ENV_VARIABLE = "LOG_LEVEL"

# kwargs name
PYPINYIN_KW_CHARACTERS_TO_OMIT = "characters_to_omit"
PYPINYIN_KW_DISABLE_INSTINCT_PINYIN = "disable_instinct_pinyin"
