# Sync with pyproject.toml
PKG_VERSION = "0.24.1"
