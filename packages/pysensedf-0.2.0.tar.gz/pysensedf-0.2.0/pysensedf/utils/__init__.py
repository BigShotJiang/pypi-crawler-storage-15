"""Utils package initialization"""
