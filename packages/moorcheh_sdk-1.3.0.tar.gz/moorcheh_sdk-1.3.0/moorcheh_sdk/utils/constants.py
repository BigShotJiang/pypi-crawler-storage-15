DEFAULT_BASE_URL = "https://api.moorcheh.ai/v1"
INVALID_ID_CHARS = [" "]
