# Security Tutorial

Follow the instructions in [`prompt_injection.ipynb`](./prompt_injection.ipynb)

<img width="253" height="253" alt="image" src="https://github.com/user-attachments/assets/0ab5d4e0-925a-40da-b0fb-e384293355e1" />


