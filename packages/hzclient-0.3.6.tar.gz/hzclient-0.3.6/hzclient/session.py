# session.py
"""Handles low-level API communication."""

from hashlib import md5
import logging

import curl_cffi as requests
import hzclient._vendor.socketio_v4.socketio as socketio
from hzclient.models import Response, Config


class Session:
  def __init__(self, config: Config):
    self.config = config
    self.session = requests.Session()
    self.logger = logging.getLogger(self.__class__.__name__)

    # HTTP headers
    self.session.headers.update({
      "origin": self.config.base_url,
      "referer": f"{self.config.base_url}/",
    })

    # Socket.IO
    self.sio = socketio.Client()
    self._handlers: dict[str, callable] = {}
    self._register_socketio_handlers()

  # ---------- Event registration ----------

  def on(self, event: str, handler: callable):
    self._handlers[event] = handler

  def _register_socketio_handlers(self):
    @self.sio.on("requestClientInfo")
    def on_request_client_info(data):
      handler = self._handlers.get("requestClientInfo")
      if handler:
        handler(data)

    @self.sio.on("syncGame")
    def sync_game(data):
      handler = self._handlers.get("syncGame")
      if handler:
        handler(data)

    @self.sio.on("syncGameAndGuild")
    def sync_game_and_guild(data):
      handler = self._handlers.get("syncGameAndGuild")
      if handler:
        handler(data)

    @self.sio.on("syncGuildLog")
    def sync_guild_log(data):
      handler = self._handlers.get("syncGuildLog")
      if handler:
        handler(data)

    @self.sio.on("disconnect")
    def on_disconnect():
      handler = self._handlers.get("disconnect")
      if handler:
        handler()

  # ---------- Socket.IO helpers ----------

  def _build_ws_headers(self) -> dict:
    headers = {
      "Origin": self.config.base_url,
      "Referer": f"{self.config.base_url}/",
    }
    if self.session.cookies:
      cookie_header = "; ".join(
        f"{k}={v}" for k, v in self.session.cookies.get_dict().items()
      )
      headers["Cookie"] = cookie_header
    return headers

  def connect_socket(self):
    if self.sio.connected:
      self.logger.info("Socket.IO already connected.")
      return

    headers = self._build_ws_headers()
    self.logger.info(f"Connecting Socket.IO to {self.config.ws_url}")
    self.sio.connect(self.config.ws_url, headers=headers, transports=["websocket"])

  def stop(self):
    if self.sio.connected:
      self.sio.disconnect()

  # ---------- HTTP part ----------

  def _get_auth(self, action: str, user_id: int) -> str:
    s = action + "GN1al351" + str(user_id)
    return md5(s.encode("utf-8")).hexdigest()

  def request(
    self,
    action: str,
    user_id: int,
    session_id: str,
    client_version: str,
    build_number: str,
    extra_params: dict | None,
  ) -> Response:
    params = {
      "action": action,
      "user_id": user_id,
      "user_session_id": session_id,
      "client_version": f"html5_{client_version}",
      "build_number": build_number,
      "auth": self._get_auth(action, user_id),
      "rct": 2,
      "keep_active": "true",
      "device_type": "web",
    }

    if extra_params:
      params.update(extra_params)

    try:
      response = self.session.post(
        f"{self.config.base_url}/request.php",
        data=params,
        timeout=5.0,
        impersonate="chrome",
      )
      response.raise_for_status()

      self.logger.debug(f"Request {action} successful")
      return Response(response.status_code, response.json())
    except Exception as e:
      self.logger.error(f"Request {action} failed: {e}")
      return Response(500, error=str(e))
