"""
Project: BlueMath_tk
Sub-Module: risk
Author: GeoOcean Research Group, Universidad de Cantabria
Repository: https://github.com/GeoOcean/BlueMath_tk.git
Status: Empty
"""
