"""Utility tools for common actions."""

# This module previously contained WaitTool.
# WaitTool was removed because LLMs cannot reliably predict timing.
# Users should configure wait_after_action parameter instead.
