"""Default constants for webtask configuration."""

# Agent defaults
DEFAULT_WAIT_AFTER_ACTION = 1.0  # seconds
DEFAULT_TYPING_DELAY = 80  # milliseconds
