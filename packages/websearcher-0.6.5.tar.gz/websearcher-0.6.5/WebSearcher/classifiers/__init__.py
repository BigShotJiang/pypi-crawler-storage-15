from .header_text import ClassifyHeaderText
from .header_components import ClassifyHeaderComponent
from .main import ClassifyMain
from .footer import ClassifyFooter