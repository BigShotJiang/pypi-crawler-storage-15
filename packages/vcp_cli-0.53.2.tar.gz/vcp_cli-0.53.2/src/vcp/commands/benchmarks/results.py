"""Shared utilities for benchmarks list and get commands."""

import fnmatch
import json
from pathlib import Path
from typing import Any, Dict, List, Optional

from rich.console import Console

from .api import (
    BenchmarkMetric,
    BenchmarkRecord,
    fetch_benchmark_by_key,
    fetch_benchmarks_list,
)
from .utils import BENCHMARK_BASE_COLUMNS, CACHE_PATH, format_as_table

console = Console()


def convert_cached_results_to_api_format(
    cached_data: Any, model: str, dataset: str, task: str
) -> List[BenchmarkRecord]:
    """
    Convert cached benchmark results from local JSON format to API BenchmarkRecord objects.

    Handles both new (dict) and old (list) cache formats.

    Args:
        cached_data: Dictionary containing cached benchmark data with 'result_metrics'
                    and 'run_specification', or a list of metrics (old format)
        model: Model identifier extracted from the cache file path
        dataset: Dataset identifier extracted from the cache file path
        task: Task identifier extracted from the cache file path

    Returns:
        List of BenchmarkRecord objects. Returns empty list if conversion fails or no valid metrics found.
    """
    benchmark_records = []

    model_metrics = []
    spec = {}
    czbenchmarks_version = None
    timestamp = None

    if isinstance(cached_data, dict):
        model_metrics = cached_data.get("result_metrics", [])
        spec = cached_data.get("run_specification", {})
        czbenchmarks_version = cached_data.get("czbenchmarks_version")
        timestamp = cached_data.get("timestamp")
    elif isinstance(cached_data, list):
        model_metrics = cached_data
    else:
        console.print(
            f"[dim yellow]Warning: Skipping unknown cache format for {model}/{dataset}/{task}[/dim yellow]"
        )
        return []

    try:
        if model_metrics:
            api_metrics = []
            for metric_data in model_metrics:
                if not isinstance(metric_data, dict):
                    console.print(
                        f"[dim yellow]Warning: Skipping corrupt metric item (expected dict, got {type(metric_data)}) in {model}/{dataset}/{task}[/dim yellow]"
                    )
                    continue

                api_metric = convert_cached_metric_to_api_format(metric_data)
                if api_metric:
                    api_metrics.append(api_metric)

            if api_metrics:
                model_key_from_spec = spec.get("model_details", {}).get("key")

                if model_key_from_spec:
                    model_key_display = model_key_from_spec
                elif spec.get("run_baseline"):
                    model_key_display = "baseline"
                # elif spec.get("cell_representations"):
                #     # Display user-friendly name, even if cache uses hash-based key
                #     # model_key_display = "user-cell-repr"
                # elif model.startswith("user-cell-repr-"):
                #     # Handle hash-based model keys from cache path (when spec not available)
                #     # model_key_display = "user-cell-repr"
                else:
                    model_key_display = model

                dataset_keys_from_spec = [
                    d.get("key") for d in spec.get("datasets", []) if d.get("key")
                ]
                if not dataset_keys_from_spec:
                    user_datasets = []
                    for d in spec.get("datasets", []):
                        user_dataset = d.get("user_dataset")
                        if user_dataset:
                            path_str = (
                                user_dataset.get("path")
                                if isinstance(user_dataset, dict)
                                else str(user_dataset)
                            )
                            if path_str:
                                try:
                                    user_datasets.append(f"user:{Path(path_str).name}")
                                except Exception:
                                    user_datasets.append(f"user:{path_str}")
                    if user_datasets:
                        dataset_keys_from_spec = user_datasets
                    else:
                        dataset_keys_from_spec = [dataset]

                model_record = BenchmarkRecord(
                    benchmark_key="",
                    model_key=model,
                    model_name_display=model_key_display,
                    dataset_keys=dataset_keys_from_spec,
                    dataset_names_display=dataset_keys_from_spec,
                    task_key=task,
                    task_name_display=task,
                    metrics=api_metrics,
                    czbenchmarks_version=czbenchmarks_version,
                    timestamp=timestamp,
                )
                benchmark_records.append(model_record)

        return benchmark_records

    except Exception as e:
        console.print(
            f"[dim yellow]Warning: Failed to convert cached data for {model}/{dataset}/{task}: {e}[/dim yellow]"
        )
        return []


def convert_cached_metric_to_api_format(
    metric_data: Dict[str, Any],
) -> Optional[BenchmarkMetric]:
    """
    Convert a single cached metric dictionary to API BenchmarkMetric format.

    Handles legacy 'MetricType.' prefixed metric types by stripping the prefix.
    Creates a standardized BenchmarkMetric with single-value statistics and
    default values for fields not present in cached format.

    Args:
        metric_data: Dictionary containing 'metric_type', 'value', and optional 'params'
                    fields from cached benchmark results

    Returns:
        BenchmarkMetric object with normalized metric_key, converted value, and
        single-value statistics. Returns None if conversion fails due to missing
        or invalid data.
    """
    try:
        metric_type = metric_data.get("metric_type", "")
        if metric_type.startswith("MetricType."):
            metric_key = metric_type.replace("MetricType.", "").lower()
        else:
            metric_key = str(metric_type).lower()

        metric_value = float(metric_data.get("value", 0.0))
        params = metric_data.get("params", {})

        api_metric = BenchmarkMetric(
            params=params,
            n_values=1,
            value=metric_value,
            value_std_dev=0.0,
            values_raw=[metric_value],
            batch_random_seeds=None,
            metric_key=metric_key,
        )

        return api_metric

    except Exception as e:
        console.print(
            f"[dim yellow]Warning: Failed to convert metric {metric_data}: {e}[/dim yellow]"
        )
        return None


def load_cached_benchmark_results(
    model_filter: Optional[str] = None,
    dataset_filter: Optional[str] = None,
    task_filter: Optional[str] = None,
) -> List[BenchmarkRecord]:
    """
    Load and filter cached benchmark results from local filesystem cache.

    Scans the cache directory structure for results.json files and applies
    case-insensitive substring filtering using fnmatch patterns. Handles
    malformed JSON files and invalid cache structures gracefully by logging
    warnings and continuing processing.

    Cache structure: ~/.vcp/cache/<model>/<dataset>/task_outputs/<task>/<task_run_id>/results.json

    Note: Only supports the new cache format with task_run_id subdirectory.

    Args:
        model_filter: Optional case-insensitive substring pattern to match against
                     model names. Uses fnmatch for pattern matching
        dataset_filter: Optional case-insensitive substring pattern to match against
                       dataset names. Uses fnmatch for pattern matching
        task_filter: Optional case-insensitive substring pattern to match against
                    task names. Uses fnmatch for pattern matching

    Returns:
        List of BenchmarkRecord objects matching all specified filters. Includes
        both model and baseline results from each matching cache file. Returns
        empty list if cache directory doesn't exist or no matches found.
    """
    cached_benchmarks = []

    if not CACHE_PATH.exists():
        return cached_benchmarks

    for results_file in CACHE_PATH.glob("*/*/task_outputs/*/*/results.json"):
        try:
            parts = results_file.parts
            model = parts[-6]
            dataset = parts[-5]
            task = parts[-3]

            try:
                cached_data = json.loads(results_file.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, UnicodeDecodeError) as e:
                console.print(
                    f"[dim yellow]Warning: Skipping malformed file {results_file}: {e}[/dim yellow]"
                )
                continue

            spec = (
                cached_data.get("run_specification", {})
                if isinstance(cached_data, dict)
                else {}
            )

            if model_filter:
                model_matches = fnmatch.fnmatch(
                    model.lower(), f"*{model_filter.lower()}*"
                )
                if not model_matches:
                    model_key_from_spec = spec.get("model_details", {}).get("key")
                    if model_key_from_spec:
                        model_matches = fnmatch.fnmatch(
                            str(model_key_from_spec).lower(),
                            f"*{model_filter.lower()}*",
                        )
                    if not model_matches:
                        if spec.get("run_baseline") and fnmatch.fnmatch(
                            "baseline", f"*{model_filter.lower()}*"
                        ):
                            model_matches = True
                if not model_matches:
                    continue

            if dataset_filter:
                dataset_matches = fnmatch.fnmatch(
                    dataset.lower(), f"*{dataset_filter.lower()}*"
                )
                if not dataset_matches:
                    datasets_in_spec = spec.get("datasets", [])
                    for d in datasets_in_spec:
                        dataset_key = d.get("key")
                        if dataset_key and fnmatch.fnmatch(
                            str(dataset_key).lower(), f"*{dataset_filter.lower()}*"
                        ):
                            dataset_matches = True
                            break
                        user_dataset = d.get("user_dataset")
                        if user_dataset:
                            path_str = (
                                user_dataset.get("path")
                                if isinstance(user_dataset, dict)
                                else str(user_dataset)
                            )
                            if path_str:
                                try:
                                    path_name = Path(path_str).name.lower()
                                    if fnmatch.fnmatch(
                                        path_name, f"*{dataset_filter.lower()}*"
                                    ):
                                        dataset_matches = True
                                        break
                                    if fnmatch.fnmatch(
                                        str(path_str).lower(),
                                        f"*{dataset_filter.lower()}*",
                                    ):
                                        dataset_matches = True
                                        break
                                except Exception:
                                    if fnmatch.fnmatch(
                                        str(path_str).lower(),
                                        f"*{dataset_filter.lower()}*",
                                    ):
                                        dataset_matches = True
                                        break
                if not dataset_matches:
                    continue

            if task_filter:
                task_matches = fnmatch.fnmatch(task.lower(), f"*{task_filter.lower()}*")
                if not task_matches:
                    task_key_from_spec = spec.get("task_key")
                    if task_key_from_spec and fnmatch.fnmatch(
                        str(task_key_from_spec).lower(), f"*{task_filter.lower()}*"
                    ):
                        task_matches = True
                if not task_matches:
                    continue

            benchmark_records = convert_cached_results_to_api_format(
                cached_data, model, dataset, task
            )
            cached_benchmarks.extend(benchmark_records)

        except (IndexError, ValueError) as e:
            console.print(
                f"[dim yellow]Warning: Invalid cache path structure {results_file}: {e}[/dim yellow]"
            )
            continue

    return cached_benchmarks


def fetch_benchmarks(
    benchmark_key: Optional[str] = None,
    model_filter: Optional[str] = None,
    dataset_filter: Optional[str] = None,
    task_filter: Optional[str] = None,
    include_user_runs: bool = True,
) -> List[BenchmarkRecord]:
    """
    Fetch benchmarks from API and cache based on provided filters.

    Args:
        benchmark_key: Specific benchmark key to retrieve (exact match)
        model_filter: Filter by model key pattern
        dataset_filter: Filter by dataset key pattern
        task_filter: Filter by task key pattern
        include_user_runs: If True, include locally cached results from previous user runs

    Returns:
        List of BenchmarkRecord objects matching the filters
    """
    if benchmark_key:
        return [fetch_benchmark_by_key(benchmark_key)]

    api_benchmarks = fetch_benchmarks_list(
        model_filter=model_filter,
        dataset_filter=dataset_filter,
        task_filter=task_filter,
    )

    if include_user_runs:
        cached_benchmarks = load_cached_benchmark_results(
            model_filter=model_filter,
            dataset_filter=dataset_filter,
            task_filter=task_filter,
        )
        return api_benchmarks + cached_benchmarks

    return api_benchmarks


def convert_benchmarks_to_rows(
    benchmarks: List[BenchmarkRecord],
    include_metrics: bool = False,
) -> List[Dict]:
    """
    Convert BenchmarkRecord objects to row dictionaries for display.

    Args:
        benchmarks: List of BenchmarkRecord objects
        include_metrics: If True, expand metrics into separate rows with metric/value columns.
                        If False, include only base columns without metrics (one row per benchmark).

    Returns:
        List of dictionaries representing table rows
    """
    rows = []

    for benchmark in benchmarks:
        benchmark_dict = benchmark.model_dump()

        base_row = {
            "benchmark_key": benchmark_dict["benchmark_key"],
            "model_key": benchmark_dict["model_key"],
            "model_name": benchmark_dict["model_name_display"],
            "dataset_keys": ", ".join(benchmark_dict["dataset_keys"]),
            "dataset_names": ", ".join(benchmark_dict["dataset_names_display"]),
            "task_key": benchmark_dict["task_key"],
            "task_name": benchmark_dict["task_name_display"],
        }

        if include_metrics:
            # Expand each metric into a separate row (for get command)
            for metric in benchmark_dict.get("metrics", []):
                metric_row = {
                    **base_row,
                    "metric": metric.get("metric_key"),
                    "value": metric.get("value"),
                    "params": metric.get("params", {}),
                }
                rows.append(metric_row)
        else:
            # Single row per benchmark (for list command)
            rows.append(base_row)

    return rows


def display_benchmarks(
    benchmarks: List[BenchmarkRecord],
    format: str,
    fit: bool,
    include_metrics: bool = False,
) -> None:
    """
    Display benchmarks in the specified format.

    Args:
        benchmarks: List of BenchmarkRecord objects to display
        format: Output format ('table' or 'json')
        fit: If True, wrap columns to fit terminal. If False, show full values.
        include_metrics: If True, include metric and value columns (for get command)
    """
    if not benchmarks:
        if format == "json":
            console.print("[]", markup=False)
        else:
            console.print("No benchmarks found matching the specified filters.")
        return

    rows = convert_benchmarks_to_rows(benchmarks, include_metrics=include_metrics)

    if format == "json":
        console.print(json.dumps(rows, indent=2, default=str))
    else:
        # Determine column order
        ordered_columns = (
            BENCHMARK_BASE_COLUMNS + ["metric", "value"]
            if include_metrics
            else BENCHMARK_BASE_COLUMNS
        )

        # Use wide console for --full mode
        display_console = Console(width=500) if not fit else console
        display_console.print(
            format_as_table(rows, table_type=ordered_columns, wrap=fit)
        )
