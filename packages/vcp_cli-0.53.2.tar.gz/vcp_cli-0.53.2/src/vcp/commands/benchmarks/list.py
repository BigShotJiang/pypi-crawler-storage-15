import logging
from typing import Optional

import click

from .results import display_benchmarks, fetch_benchmarks
from .utils import CLIError, handle_cli_error, validate_benchmark_filters

logger = logging.getLogger(__name__)


@click.command(name="list", context_settings={"help_option_names": ["-h", "--help"]})
@click.option(
    "-b",
    "--benchmark-key",
    help="Retrieve by benchmark key. Mutually-exclusive with filter options.",
)
@click.option(
    "-m",
    "--model-filter",
    help="Filter by model key (substring match with '*' wildcards, e.g. 'scvi*v1').",
)
@click.option(
    "-d",
    "--dataset-filter",
    help="Filter by dataset key (substring match with '*' wildcards, e.g. 'tsv2*liver').",
)
@click.option(
    "-t",
    "--task-filter",
    help="Filter by task key (substring match with '*' wildcards, e.g. 'label*pred').",
)
@click.option(
    "-f",
    "--format",
    type=click.Choice(["table", "json"]),
    default="table",
    help="Output format",
)
@click.option(
    "--fit/--full",
    default=True,
    help="Column display for table format (default: fit). Use --full to show full column content; pair with a pager like 'less -S' for horizontal scrolling. Only applies to --format=table.",
)
@click.option(
    "--user-runs/--no-user-runs",
    default=True,
    help="Include or exclude locally cached results from previous user benchmark runs (default: include).",
)
# TODO: Consider --debug if this is just showing debug log output (https://czi.atlassian.net/browse/VC-4024)
@click.pass_context
def list_command(
    ctx: click.Context,
    benchmark_key: Optional[str],
    dataset_filter: Optional[str],
    model_filter: Optional[str],
    task_filter: Optional[str],
    format: str,
    fit: bool,
    user_runs: bool,
) -> None:
    """
    List available model, dataset and task benchmark combinations.

    Shows benchmarks from the VCP as well as locally cached results from
    previous user benchmark runs. You can filter results by dataset, model, or
    task using glob patterns.
    """

    try:
        validate_benchmark_filters(model_filter, dataset_filter, task_filter)

        benchmarks = fetch_benchmarks(
            benchmark_key=benchmark_key,
            model_filter=model_filter,
            dataset_filter=dataset_filter,
            task_filter=task_filter,
            include_user_runs=user_runs,
        )

        display_benchmarks(
            benchmarks=benchmarks,
            format=format,
            fit=fit,
            include_metrics=False,
        )

    except CLIError as e:
        handle_cli_error(e)
