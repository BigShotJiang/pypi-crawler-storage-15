import logging
from typing import Optional

import click
from rich.console import Console

from .results import display_benchmarks, fetch_benchmarks
from .utils import CLIError, handle_cli_error, validate_benchmark_filters

logger = logging.getLogger(__name__)
console = Console()


@click.command(name="get", context_settings={"help_option_names": ["-h", "--help"]})
@click.option(
    "-b",
    "--benchmark-key",
    help="Retrieve by benchmark key (exact match). Mutually-exclusive with filter options.",
)
@click.option(
    "-m",
    "--model-filter",
    help="Filter by model key (substring match with '*' wildcards, e.g. 'scvi*v1')",
)
@click.option(
    "-d",
    "--dataset-filter",
    help="Filter by dataset key (substring match with '*' wildcards, e.g 'tsv2*liver')",
)
@click.option(
    "-t",
    "--task-filter",
    help="Filter by task key (substring match with '*' wildcards, e.g. 'label*pred')",
)
@click.option(
    "-f",
    "--format",
    type=click.Choice(["table", "json"]),
    default="table",
    help="Output format",
)
@click.option(
    "--fit/--full",
    default=True,
    help="Column display for table format (default: fit). Use --full to show full column content; pair with a pager like 'less -S' for horizontal scrolling. Only applies to --format=table.",
)
@click.option(
    "--user-runs/--no-user-runs",
    default=True,
    help="Include or exclude locally cached results from previous user benchmark runs (default: include).",
)
@click.pass_context
def get_command(
    ctx: click.Context,
    benchmark_key: Optional[str],
    model_filter: Optional[str],
    dataset_filter: Optional[str],
    task_filter: Optional[str],
    format: str,
    fit: bool,
    user_runs: bool,
) -> None:
    """
    Fetch and display benchmark results with metrics.

    Shows benchmarks from the VCP as well as locally cached results from
    previous user benchmark runs. Use filters to select by model, dataset, or task.
    Results include detailed performance metrics for each benchmark.
    """

    try:
        validate_benchmark_filters(model_filter, dataset_filter, task_filter)

        if benchmark_key and (model_filter or dataset_filter or task_filter):
            handle_cli_error(
                CLIError(
                    "Cannot use both --benchmark-key and filter options (--model-filter, --dataset-filter, --task-filter) at the same time. "
                    "Use either --benchmark-key for a specific benchmark or filter options to search."
                )
            )

        benchmarks = fetch_benchmarks(
            benchmark_key=benchmark_key,
            model_filter=model_filter,
            dataset_filter=dataset_filter,
            task_filter=task_filter,
            include_user_runs=user_runs,
        )

        display_benchmarks(
            benchmarks=benchmarks,
            format=format,
            fit=fit,
            include_metrics=True,
        )

    except CLIError as e:
        handle_cli_error(e)
