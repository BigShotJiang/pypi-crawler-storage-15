"""
Test suite for Coach Language Server
"""
