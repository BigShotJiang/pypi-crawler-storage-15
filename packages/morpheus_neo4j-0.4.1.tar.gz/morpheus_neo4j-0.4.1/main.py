def main():
    print("Hello from morpheus!")


if __name__ == "__main__":
    main()
