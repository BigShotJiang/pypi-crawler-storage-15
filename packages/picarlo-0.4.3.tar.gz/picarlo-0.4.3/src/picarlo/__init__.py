from . import sim as sim

print("==> in picarlo/__init__.py", ": ", "I run when picarlo is imported")
# TODO: only print this if debug mode is enabled
# print("dir(sim):", dir(sim))
