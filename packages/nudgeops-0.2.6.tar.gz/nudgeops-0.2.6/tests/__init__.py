"""
NudgeOps test suite.
"""
