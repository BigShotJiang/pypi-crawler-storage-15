from django.apps import AppConfig


class AuditlogTestConfig(AppConfig):
    name = "test_app"
