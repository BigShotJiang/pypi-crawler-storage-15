def get_cid():
    return "my custom get_cid"
