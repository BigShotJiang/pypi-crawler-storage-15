from django.apps import AppConfig


class CustomLogEntryConfig(AppConfig):
    name = "custom_logentry_app"
