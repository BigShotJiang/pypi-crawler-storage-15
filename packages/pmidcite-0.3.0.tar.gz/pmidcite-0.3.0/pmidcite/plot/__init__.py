"""ASCII plots"""
