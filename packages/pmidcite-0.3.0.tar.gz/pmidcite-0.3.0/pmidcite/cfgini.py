"""Configuration file for PMID Cite"""

__copyright__ = "Copyright (C) 2021-present, DV Klopfenstein, PhD. All rights reserved."
__author__ = "DV Klopfenstein, PhD"

from sys import stdout
from os.path import exists

from pmidcite.eutils.apikey import DEFAULT_APIKEY

DEFAULT_EMAIL = 'name@university.edu'
DEFAULT_TOOL = 'scripts'

PMIDCITERC = \
f"""# Link citation data from the National Institute of Health (NIH) to PubMed IDs.

# The file .pmidciterc is a configuration file for the project, pmidcite, and its
# executables, which includes icite.

# To protect your security, store this file (.pmidciterc) in a directory that is
# not managed by git or other version management tools. If the .pmidciterc is in
# the home directory, set the environmental variable, PMIDCITECONF, so pmidcite
# scripts can read it:
#
#   $ export PMIDCITECONF=~/.pmidciterc
#
[pmidcite]

# --------------------------------------------------------------------------------
# When comparing numerous papers, use the group variables to place
# the most recent papers first, the highest rated papers next, and
# the lowest-rated papers at the end of the list of papers and citation data.
group1_min = 2.1
group2_min = 30.0
group3_min = 60.0
group4_min = 94.0

# --------------------------------------------------------------------------------
# NCBI E-Utils needs: email, apikey, and tool to download PubMed records.
# These fields are needed if:
#   * You plan to run a search in PubMed and download the resulting list of PMIDs
#   * You plan to download abstracts from NCBI
#
# Note: The fields are not needed for viewing NIH citation data for a given PMID
#
# Learn more about registering for a NCBI API key here:
# https://ncbiinsights.ncbi.nlm.nih.gov/2017/11/02/new-api-keys-for-the-e-utilities
email = {DEFAULT_EMAIL}
apikey = {DEFAULT_APIKEY}
tool = {DEFAULT_TOOL}

# --------------------------------------------------------------------------------
# The default is to work on-line (dir_icite_py = None);
# NIH citations will always be downloaded.
#
# To work off-line and store citation data downloaded from the NIH,
# set `dir_icite_py' to a directory name. Each citation downloaded
# from the NIH will then be stored in its own p<PMID>.py file for
# later use when there is no internet available.
#
# Specify the directory to store citation data from the NIH that is downloaded
# using commands such as icite:
#
#  # PMID 33031632 is a new (-1) research (R) paper discussing humans (H)
#  # with 2 citations and 18 references that is authored by 2 (au[02]) people with
#  # the first author being DV Klopfenstein, PhD.
#  #
#  $ icite 33031632
#  TOP 33031632 R. H....  -1 i 2021     2  0  18 au[02](D V Klopfenstein, PhD) Commentary ...
#
# Thousands of NIH citation files may be downloaded for a literature search
# on a single subject. It is not necessary to save the NIH citation data and I
# recommend not saving these files using git managed from the cloud.
#
# Note: Add an __init__.py file to the ./icite directory
#       Add /icite to the .gitignore to avoid saving thousands of unecessary files using git
#
# Recommended value, None or ./icite:
# dir_icite_py = None
# dir_icite_py = ./icite  # $ mkdir ./icite
dir_icite_py = None

# --------------------------------------------------------------------------------
# Store abstracts and publication data downloaded form PubMed in a dedicated directory
#
# Recommended value (mkdir ./log; mkdir ./log/pubmed):
# dir_pubmed_txt = ./log/pubmed
dir_pubmed_txt = None

# --------------------------------------------------------------------------------
# Store files containing longer lists of PMIDs into a dedicated directory
# specified using the variable, dir_pmids.
# Files containing lists of PMIDs can be downloaded either from the PubMed GUI
# or by running a PubMed query from your copy of pmidcite's dnld_pmids.py script.
#
# Store NIH citation data for all PMIDs in a single file into a directory
# dedicated to citation data files using the variable, dir_icite.
#
# Recommended values (mkdir ./log; mkdir ./log/pmids; mkdir ./log/icite)
# dir_pmids = ./log/pmids
# dir_icite = ./log/icite
dir_pmids = None
dir_icite = None
"""

def prt_rcfile(prt=stdout):
    """Print a default PMIR icite configuration file"""
    prt.write('\n# == CONFIGURATION FILE BEGIN: .pmidciterc ====================================\n')
    prt.write(PMIDCITERC)
    prt.write('# == CONFIGURATION FILE END: .pmidciterc ======================================\n\n')

def wr_rcfile(cfgfile, force=False):
    """Write a sample configuration with default values set"""
    if not exists(cfgfile) or force:
        with open(cfgfile, 'w', encoding='utf-8') as prt:
            prt.write(PMIDCITERC)
            print(f'  WROTE: {cfgfile}')
            return True
    print(f'  EXISTS: {cfgfile} OVERWRITE WITH wr_rc(force=True)')
    return False


# Copyright (C) 2021-present DV Klopfenstein, PhD. All rights reserved.
