export PYTHONPATH=../src:$PYTHONPATH
export PMIDCITECONF=$HOME_LINUX/.pmidciterc
rm -f pubmed_20050301.txt

# jupyter notebook
