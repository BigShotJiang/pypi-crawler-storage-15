# src/__init__.py
from .rebrandly_otel import *
from .flask_support import setup_flask
from .fastapi_support import setup_fastapi
from .pymysql_instrumentation import instrument_pymysql
from .api_gateway_utils import (
    is_api_gateway_event,
    extract_api_gateway_http_attributes,
    extract_api_gateway_context
)
from .http_utils import (
    inject_traceparent,
    requests_with_tracing,
    httpx_with_tracing
)

# Explicitly define what's available
__all__ = [
    'otel',
    'lambda_handler',
    'span',
    'aws_message_span',
    'traces',
    'tracer',
    'metrics',
    'logger',
    'force_flush',
    'aws_message_handler',
    'shutdown',
    'setup_flask',
    'setup_fastapi',
    'instrument_pymysql',
    # API Gateway utilities
    'is_api_gateway_event',
    'extract_api_gateway_http_attributes',
    'extract_api_gateway_context',
    # HTTP client tracing
    'inject_traceparent',
    'requests_with_tracing',
    'httpx_with_tracing'
]