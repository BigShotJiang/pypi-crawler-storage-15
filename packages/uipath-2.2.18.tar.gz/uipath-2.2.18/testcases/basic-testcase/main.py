import logging
from dataclasses import dataclass


logger = logging.getLogger(__name__)


@dataclass
class EchoIn:
    message: str
    repeat: int | None = 1
    prefix: str | None = None


@dataclass
class EchoOut:
    message: str


def main(input: EchoIn) -> EchoOut:
    result = []

    for _ in range(input.repeat):
        line = input.message
        if input.prefix:
            line = f"{input.prefix}: {line}"
        result.append(line)

    return EchoOut(message="\n".join(result))
