## 0.2.3 – 2025-12-02

### Added

- GUID validation for list identifiers with fallback to list title lookup via `GetByTitle`.
- New helper method `_is_valid_guid` in `SharePointAPI`.
- Centralized list resolution helper `_resolve_sp_list` for GUID, title, or `SharePointList` instances.
- New method `get_list_metadata` to fetch only list metadata without items.
- Type hint enhancements: added `Optional`, `Tuple` imports; updated method signatures (e.g., `get_item_versions` now uses `Optional[List[str]]`).
- Updated `get_list` to return the resolved `SharePointList` object after appending items.
- Refactored multiple methods (`get_item`, `create_item`, `update_item`, `attach_file`, `get_item_versions`, `get_case`) to use `_resolve_sp_list`, removing redundant GUID validation logic.

### Changed

- Cleaned up stray `else:` blocks and syntax errors.
- Improved consistency of return objects across list-related methods.
- Updated imports and docstrings accordingly.

## 0.2.2 – 2025-11-28

### Added

- `SharePointList.fields` property to retrieve list field definitions

## 0.2.1 – 2025‑11‑06

### Added

- Optional `select_fields` parameters to list retrieval methods for more efficient queries.
- New public API methods:
  - `SharePointAPI.get_group_users` – fetch users of a SharePoint group.
- Improved error handling with explicit `TypeError` exceptions.
- Detailed docstrings for core classes and methods (enhances IDE support).

### Changed

- HTTP header handling unified; corrected `X‑HTTP‑Method: PUT` for full updates.
- Error handling improved: generic `sys.exit(1)` replaced with explicit `TypeError`/`ConnectionError` exceptions.

### Fixed

- Fixed incorrect PUT header that previously sent a MERGE header.
- Minor docstring formatting issues.

### Security

- Enforced NTLM authentication across all request helpers.
