from Linear_Models import polynomial_regression

model = polynomial_regression()
x, y  = [[1,2,3], [2,4,6]], [2,4,6]
model.fit(x, y)
model.predict(x[0])