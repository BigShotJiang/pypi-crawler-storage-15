"""
FileShareService for permission-based file sharing.

Geek Cafe, LLC
MIT License. See Project Root for the license information.
"""

from typing import Dict, Any, Optional, List
from boto3.dynamodb.conditions import Key
from boto3_assist.dynamodb.dynamodb import DynamoDB
from geek_cafe_saas_sdk.core.services.database_service import DatabaseService
from geek_cafe_saas_sdk.core.service_result import ServiceResult
from geek_cafe_saas_sdk.core.service_errors import ValidationError, NotFoundError, AccessDeniedError
from geek_cafe_saas_sdk.core.error_codes import ErrorCode
from geek_cafe_saas_sdk.modules.files.models.file_share import FileShare
from geek_cafe_saas_sdk.modules.files.models.file import File
from geek_cafe_saas_sdk.lambda_handlers import service_method, validate_enum
import datetime as dt


class FileShareService(DatabaseService[FileShare]):
    """
    File share service for permission-based file sharing.
    
    Handles:
    - Creating file shares with permissions
    - Access validation
    - Share expiration
    - Share revocation
    - Permission management (view, download, edit)
    """
    
    @service_method("create")
    @validate_enum('permission', {'view', 'download', 'edit'})
    def create(
        self,
        file_id: str,
        permission: str = "view",
        expires_at: Optional[float] = None,
        message: Optional[str] = None,
        **kwargs
    ) -> ServiceResult[FileShare]:
        """
        Create a file share.
        
        Args:
            file_id: File ID to share
            shared_with_permission: Permission level (view, download, edit)
            expires_at: Optional expiration timestamp
            message: Optional message for recipient
            
        Returns:
            ServiceResult with FileShare model
        """
        # Validate authentication
        self.request_context.require_authentication()
        
        # Get security context
        tenant_id = self.request_context.target_tenant_id
        user_id = self.request_context.target_user_id
        
        # Get required parameter
        shared_with_user_id = kwargs.get('shared_with_user_id')
        if not shared_with_user_id:
            raise ValidationError("shared_with_user_id is required")
        
        # Cannot share with self
        if shared_with_user_id == user_id:
            raise ValidationError(
                "Cannot share file with yourself",
                "shared_with_user_id"
            )
        
        # Get the file to verify ownership
        file_result = self._get_file(file_id)
        if not file_result.success:
            return ServiceResult.error_result(
                message="File not found or you do not have permission to share it",
                error_code=ErrorCode.ACCESS_DENIED
            )
        
        file = file_result.data
        
        # Only owner can share
        if file.owner_id != user_id:
            raise AccessDeniedError("Only the file owner can share this file")
        
        # Check for existing share
        existing_share = self._get_existing_share(
            tenant_id, file_id, shared_with_user_id
        )
        if existing_share:
            raise ValidationError(
                "File is already shared with this user",
                "shared_with_user_id"
            )
        
        # Create FileShare model
        share = FileShare()            
        share.tenant_id = tenant_id
        share.file_id = file_id
        share.shared_by = user_id
        share.user_id = user_id
        share.owner_id = user_id
        share.shared_with_user_id = shared_with_user_id
        share.permission_level = permission
        share.expires_at = expires_at
        share.message = message
        share.status = "active"
        share.access_count = 0
        
        # Save to DynamoDB
        share.prep_for_save()
        return self._save_model(share)
    
    @service_method("get_by_id")
    def get_by_id(
        self,
        share_id: str        
    ) -> ServiceResult[FileShare]:
        """
        Get share by ID.
        
        Args:
            share_id: Share ID            
            # tenant_id and user_id from self.request_context
            
        Returns:
            ServiceResult with FileShare model
        """
        self.request_context.require_authentication()
        
        tenant_id = self.request_context.target_tenant_id
        user_id = self.request_context.target_user_id
        
        # Use helper method with tenant check
        share = self._get_model_by_id_with_tenant_check(share_id, FileShare, tenant_id)
        
        if not share:
            raise NotFoundError(f"Share not found: {share_id}")
        
        # Access control: user must be sharer or sharee
        if share.shared_by != user_id and share.shared_with_user_id != user_id:
            raise AccessDeniedError("You do not have access to this share")
        
        return ServiceResult.success_result(share)
    
    @service_method("update")
    def update(
        self,
        share_id: str,
        updates: Dict[str, Any]
    ) -> ServiceResult[FileShare]:
        """
        Update share (permission or expiration).
        
        Args:
            share_id: Share ID
            updates: Dictionary of fields to update
            # tenant_id and user_id from self.request_context
            
        Returns:
            ServiceResult with updated FileShare model
        """
        self.request_context.require_authentication()
        
        user_id = self.request_context.target_user_id
        
        file_id = updates.get('file_id')
        if not file_id:
            raise ValidationError("file_id is required in updates", "file_id")
        
        # Get existing share
        get_result = self.get_by_id(share_id)
        if not get_result.success:
            return get_result
        
        share = get_result.data
        
        # Only sharer can update
        if share.shared_by != user_id:
            raise AccessDeniedError("Only the person who shared can update this share")
        
        # Apply updates (only allowed fields)
        allowed_fields = ["permission_level", "expires_at", "message"]
        
        for field, value in updates.items():
            if field == "permission_level":
                valid_permissions = ["view", "download", "edit"]
                if value not in valid_permissions:
                    raise ValidationError(
                        f"Invalid permission: {value}",
                        "permission_level"
                    )
            
            if field in allowed_fields:
                setattr(share, field, value)
        
        share.modified_utc_ts = dt.datetime.now(dt.UTC).timestamp()
        
        # Save to DynamoDB
        share.prep_for_save()
        return self._save_model(share)
    
    @service_method("delete")
    def delete(
        self,
        share_id: str,
        file_id: str
    ) -> ServiceResult[bool]:
        """
        Revoke a share.
        
        Args:
            share_id: Share ID
            file_id: File ID
            # tenant_id and user_id from self.request_context
            
        Returns:
            ServiceResult with success boolean
        """
        self.request_context.require_authentication()
        
        user_id = self.request_context.target_user_id
        
        # Get existing share
        get_result = self.get_by_id(share_id)
        if not get_result.success:
            return get_result
        
        share = get_result.data
        
        # Only sharer can revoke
        if share.shared_by != user_id:
            raise AccessDeniedError("Only the person who shared can revoke this share")
        
        # Mark as revoked
        share.status = "revoked"
        share.revoked_at = dt.datetime.now(dt.UTC).timestamp()
        
        share.prep_for_save()
        save_result = self._save_model(share)
        
        if not save_result.success:
            return save_result
        
        return ServiceResult.success_result(True)
    
    @service_method("list_shares_by_file")
    def list_shares_by_file(
        self,
        file_id: str,
        limit: int = 50
    ) -> ServiceResult[List[FileShare]]:
        """
        List all shares for a file.
        
        Args:
            file_id: File ID
            limit: Maximum number of results
            # tenant_id and user_id from self.request_context
            
        Returns:
            ServiceResult with list of FileShare models
        """
        self.request_context.require_authentication()
        
        # Verify user owns the file
        file_result = self._get_file(file_id)
        if not file_result.success:
            return ServiceResult.error_result(
                message="File not found or access denied",
                error_code=ErrorCode.ACCESS_DENIED
            )
        
        # Use GSI1 to query shares by file
        temp_share = FileShare()
        temp_share.file_id = file_id
        
        # Query using helper method
        query_result = self._query_by_index(temp_share, "gsi1", limit=limit, ascending=False)
        
        if not query_result.success:
            return query_result
        
        # Filter results
        shares = []
        for share in query_result.data:
            # Include active and expired shares, exclude revoked
            if share.status != "revoked":
                shares.append(share)
        
        return ServiceResult.success_result(shares)
    
    @service_method("list_shares_with_user")
    def list_shares_with_user(
        self,
        limit: int = 50
    ) -> ServiceResult[List[FileShare]]:
        """
        List all files shared with current user.
        
        Args:
            limit: Maximum number of results
            # tenant_id and user_id from self.request_context
            
        Returns:
            ServiceResult with list of FileShare models
        """
        self.request_context.require_authentication()
        
        user_id = self.request_context.target_user_id
        
        # Use GSI2 to query shares by shared_with_user
        temp_share = FileShare()
        temp_share.shared_with_user_id = user_id
        
        # Query using helper method
        query_result = self._query_by_index(temp_share, "gsi2", limit=limit, ascending=False)
        
        if not query_result.success:
            return query_result
        
        # Filter results
        shares = []
        for share in query_result.data:
            # Only include active, non-expired shares
            if share.is_active:
                shares.append(share)
        
        return ServiceResult.success_result(shares)
    
    @service_method("check_access")
    def check_access(
        self,
        file_id: str,
        required_permission: str = "view"
    ) -> ServiceResult[Dict[str, Any]]:
        """
        Check if current user has access to a file.
        
        Args:
            file_id: File ID
            required_permission: Required permission level
            # tenant_id and user_id from self.request_context
            
        Returns:
            ServiceResult with access info (has_access, permission, reason)
        """
        tenant_id = self.request_context.target_tenant_id
        user_id = self.request_context.target_user_id
        
        # Get file
        file_result = self._get_file_any_user(tenant_id, file_id)
        if not file_result.success:
            return ServiceResult.success_result({
                "has_access": False,
                "permission": None,
                "reason": "file_not_found"
            })
        
        file = file_result.data
        
        # Check if user is owner
        if file.owner_id == user_id:
            return ServiceResult.success_result({
                "has_access": True,
                "permission": "owner",
                "reason": "owner"
            })
        
        # Check for active share
        share = self._get_existing_share(tenant_id, file_id, user_id)
        if not share:
            return ServiceResult.success_result({
                "has_access": False,
                "permission": None,
                "reason": "no_share"
            })
        
        # Check if share is active
        if not share.is_active:
            reason = "expired" if share.is_expired else "revoked"
            return ServiceResult.success_result({
                "has_access": False,
                "permission": None,
                "reason": reason
            })
        
        # Check permission level
        permission_levels = {"view": 1, "download": 2, "edit": 3}
        user_level = permission_levels.get(share.permission_level, 0)
        required_level = permission_levels.get(required_permission, 1)
        
        has_access = user_level >= required_level
        
        # Increment access count if accessing
        if has_access:
            self._increment_access_count(tenant_id, file_id, share.share_id)
        
        return ServiceResult.success_result({
            "has_access": has_access,
            "permission": share.permission_level,
            "reason": "granted" if has_access else "insufficient_permission"
        })
    
    # Helper methods
    
    def _get_file(self, file_id: str) -> ServiceResult[File]:
        """Get file with access control using request_context."""
        try:
            tenant_id = self.request_context.target_tenant_id
            user_id = self.request_context.target_user_id
            
            # Use helper method with tenant check
            file = self._get_model_by_id_with_tenant_check(file_id, File, tenant_id)
            
            if not file:
                raise NotFoundError(f"File not found: {file_id}")
            
            if file.owner_id != user_id:
                raise AccessDeniedError("You do not have access to this file")
            
            return ServiceResult.success_result(file)
            
        except (NotFoundError, AccessDeniedError) as e:
            return ServiceResult.error_result(
                message=str(e),
                error_code=ErrorCode.NOT_FOUND if isinstance(e, NotFoundError) else ErrorCode.ACCESS_DENIED
            )
    
    def _get_file_any_user(self, tenant_id: str, file_id: str) -> ServiceResult[File]:
        """Get file without access control (for internal use)."""
        try:
            
            file = File()
            file.id = file_id
            file.tenant_id = tenant_id
            
            result = self.dynamodb.get(
                table_name=self.table_name,
                model=file
            )
            
            if not result or 'Item' not in result:
                raise NotFoundError(f"File not found: {file_id}")
            
            file = File()
            file.map(result['Item'])
            
            return ServiceResult.success_result(file)
            
        except NotFoundError as e:
            return ServiceResult.error_result(
                message=str(e),
                error_code=ErrorCode.NOT_FOUND
            )
    
    def _get_existing_share(
        self,
        tenant_id: str,
        file_id: str,
        shared_with_user_id: str
    ) -> Optional[FileShare]:
        """Check if share already exists."""
        try:
            # Query GSI1 by file_id to get all shares for this file
            temp_share = FileShare()
            temp_share.file_id = file_id
            
            result = self._query_by_index(temp_share, "gsi1", limit=100)
            
            if not result.success:
                return None
            
            # Filter for matching tenant and user (active shares only)
            for share in result.data:
                if (share.tenant_id == tenant_id and 
                    share.shared_with_user_id == shared_with_user_id and
                    share.status == "active"):
                    return share
            
            return None
            
        except Exception:
            return None
    
    def _increment_access_count(
        self,
        tenant_id: str,
        file_id: str,
        share_id: str
    ) -> None:
        """Increment share access count."""
        try:
            share = FileShare()
            share.id = share_id
            share.tenant_id = tenant_id
            share.file_id = file_id
            
            result = self.dynamodb.get(
                table_name=self.table_name,
                model=share
            )
            
            if result and 'Item' in result:
                share = FileShare()
                share.map(result['Item'])
                
                share.access_count += 1
                share.last_accessed_at = dt.datetime.now(dt.UTC).timestamp()
                
                share.prep_for_save()
                self.dynamodb.save(
                    table_name=self.table_name,
                    item=share
                )
        except Exception:
            pass  # Best effort
