"""
File model for file storage system.

Geek Cafe, LLC
MIT License. See Project Root for the license information.
"""

from boto3_assist.dynamodb.dynamodb_index import DynamoDBIndex, DynamoDBKey
from typing import List, Dict, Any
from geek_cafe_saas_sdk.core.models.base_tenant_user_model import BaseTenantUserModel


class File(BaseTenantUserModel):
    """
    File metadata and references.
    
    Represents a file in the system with metadata, virtual path, and S3 location.
    Does not contain file data (stored in S3) - only metadata and references.
    
    Multi-Tenancy:
    - tenant_id: Organization/company (can have multiple users)
    - owner_id: Specific user within the tenant who owns this file
    
    Access Patterns (DynamoDB Keys):
    - pk: FILE#{tenant_id}#{file_id}
    - sk: metadata
    - gsi1_pk: owner#{owner_id}
    - gsi1_sk: directory#{directory_id}#{name}
    - gsi2_pk: tenant#{tenant_id}#owner#{owner_id}
    - gsi2_sk: file#{created_utc_ts}
    - gsi3_pk: owner#{owner_id}
    - gsi3_sk: directory#{virtual_path}#{name}
    - gsi4_pk: owner#{owner_id}
    - gsi4_sk: resource_type#{resource_type}#{name}
    
    Versioning:
    - Uses explicit versioning with unique S3 keys per version
    """

    def __init__(self):
        super().__init__()
        
        # Identity (inherited from BaseModel: id, tenant_id)
        # Note: tenant_id = organization/company, owner_id = specific user within tenant
        self._owner_id: str | None = None  # User ID who owns this file
        
        # File Information
        self._name: str | None = None  # Display name (e.g., "report.pdf")
        self._mime_type: str | None = None  # MIME type (e.g., "application/pdf")
        self._size: int = 0  # Size in bytes
        self._checksum: str | None = None  # MD5/SHA256 checksum
        
        # Virtual Location (logical structure in DynamoDB)
        self._directory_id: str | None = None  # Parent directory ID (null = root)
        self._virtual_path: str | None = None  # Full virtual path (/docs/reports/Q1.pdf)
        
        # S3 Physical Location
        self._bucket: str | None = None  # S3 bucket name
        self._key: str | None = None  # S3 object key (physical location)
        
        # Versioning
        self._version_id: str | None = None  # Version identifier (user-set or from S3)
        
        # Metadata
        self._description: str | None = None  # Optional description
        self._tags: List[str] = []  # Searchable tags
        
        # status
        self._status: str = "active"  # "active", "archived", "deleted"
        
        # state
        self._state: str = "ready"  # "ready", "processing", "failed", "deleted"
        # Lineage Tracking (for data processing pipelines)
        self._lineage: str = "original"  # "original" or "derived" (can add "child" for multi-level)
        self._parent_id: str | None = None  # Parent file in hierarchy (None for root files)
        self._root_id: str | None = None  # Root file in hierarchy (self.id for root files)
        # Transformation Tracking
        self._transformation_type: str | None = None  # "convert", "clean", "process"
        self._transformation_operation: str | None = None  # "xls_to_csv", "data_cleaning_v2"
        self._transformation_metadata: Dict[str, Any] | None = None  # Additional operation details

        # resource_type
        self._resource_type: str | None = None  # resource_type (e.g., "analytics", "analysis-input", "reports", "documents")
        # visibility        
        self._visibility: str = "private"  # "private" | "tenant" | "public" | "system"
        # retention_policy
        self._retention_policy: str | None = "permanent"  # "none" | "temporary" | "permanent" | "legal-hold" | "retain-90-days" | "retain-permanently"
        
        self._is_hidden: bool = False  # True if the file should not be visible in the UI
        
        # Usage - describes what the file is used for (e.g., "media-input", "analysis-input", "template", "backup")
        self._usage: str | None = None
        
        # Timestamps (inherited from BaseModel)
        # created_utc_ts, modified_utc_ts, deleted_utc_ts
        
        # CRITICAL: Call _setup_indexes() as LAST line in __init__
        self._setup_indexes()
    
    def _setup_indexes(self):
        """Setup DynamoDB indexes for file queries."""
        
        # Primary index: File by ID
        primary = DynamoDBIndex()
        primary.name = "primary"
        primary.partition_key.attribute_name = "pk"
        primary.partition_key.value = lambda: DynamoDBKey.build_key(("file", self.id))
        primary.sort_key.attribute_name = "sk"
        primary.sort_key.value = lambda: "metadata"
        self.indexes.add_primary(primary)
        
        # GSI1: Files by directory (id)
        gsi = DynamoDBIndex()
        gsi.name = "gsi1"
        gsi.partition_key.attribute_name = f"{gsi.name}_pk"
        gsi.partition_key.value = lambda: DynamoDBKey.build_key(("owner", self.owner_id))
        gsi.sort_key.attribute_name = f"{gsi.name}_sk"        
        gsi.sort_key.value = lambda: DynamoDBKey.build_key(("directory", self.directory_id), ("file", self.name))
        
        self.indexes.add_secondary(gsi)
        
        # GSI2: Files by owner
        gsi = DynamoDBIndex()
        gsi.name = "gsi2"
        gsi.partition_key.attribute_name = f"{gsi.name}_pk"
        gsi.partition_key.value = lambda: DynamoDBKey.build_key(("tenant", self.tenant_id), ("owner", self.owner_id))
        gsi.sort_key.attribute_name = f"{gsi.name}_sk"
        gsi.sort_key.value = lambda: DynamoDBKey.build_key(("file", self.created_utc_ts))
        self.indexes.add_secondary(gsi)



        # GSI3: Files by directory (virtual path)
        gsi = DynamoDBIndex()
        gsi.name = "gsi3"
        gsi.partition_key.attribute_name = f"{gsi.name}_pk"
        gsi.partition_key.value = lambda: DynamoDBKey.build_key(("owner", self.owner_id))
        gsi.sort_key.attribute_name = f"{gsi.name}_sk"        
        gsi.sort_key.value = lambda: DynamoDBKey.build_key(("directory", self.virtual_path), ("file", self.name))
        
        self.indexes.add_secondary(gsi)


        # GSI4: Files by resource_type name
        gsi = DynamoDBIndex()
        gsi.name = "gsi4"
        gsi.partition_key.attribute_name = f"{gsi.name}_pk"
        gsi.partition_key.value = lambda: DynamoDBKey.build_key(("tenant", self.tenant_id), ("owner", self.owner_id))
        gsi.sort_key.attribute_name = f"{gsi.name}_sk"        
        gsi.sort_key.value = lambda: DynamoDBKey.build_key(("resource_type", self.resource_type), ("file", self.name))
        
        self.indexes.add_secondary(gsi)
    
        # GSI5: Files by root_id, sorted by created_utc_ts
        gsi = DynamoDBIndex()
        gsi.name = "gsi5"
        gsi.partition_key.attribute_name = f"{gsi.name}_pk"
        gsi.partition_key.value = lambda: DynamoDBKey.build_key(("tenant", self.tenant_id),("owner", self.owner_id))
        gsi.sort_key.attribute_name = f"{gsi.name}_sk"       
        gsi.sort_key.value = lambda: DynamoDBKey.build_key(("root", self.root_id),("ts", self.created_utc_ts))
        
        self.indexes.add_secondary(gsi)

        # GSI6: Files by parent_id, sorted by created_utc_ts
        gsi = DynamoDBIndex()
        gsi.name = "gsi6"
        gsi.partition_key.attribute_name = f"{gsi.name}_pk"
        gsi.partition_key.value = lambda: DynamoDBKey.build_key(("tenant", self.tenant_id),("owner", self.owner_id))
        gsi.sort_key.attribute_name = f"{gsi.name}_sk"       
        gsi.sort_key.value = lambda: DynamoDBKey.build_key(("parent", self.parent_id), ("ts", self.created_utc_ts))
        
        self.indexes.add_secondary(gsi)

        # GSI7: Files by usage, sorted by created_utc_ts
        gsi = DynamoDBIndex()
        gsi.name = "gsi7"
        gsi.partition_key.attribute_name = f"{gsi.name}_pk"
        gsi.partition_key.value = lambda: DynamoDBKey.build_key(("tenant", self.tenant_id), ("owner", self.owner_id))
        gsi.sort_key.attribute_name = f"{gsi.name}_sk"       
        gsi.sort_key.value = lambda: DynamoDBKey.build_key(("usage", self.usage), ("ts", self.created_utc_ts))
        
        self.indexes.add_secondary(gsi)

    # Properties - Ownership
    @property
    def owner_id(self) -> str | None:
        """
        User ID who owns the file (not tenant_id - that's the organization).
        If owner_id is not set, use user_id.
        An owner can be different than the user_id, if there was a transfer of ownership or
        if the file was created by a different user for another user.        
        """
        return self._owner_id or self.user_id
    
    @owner_id.setter
    def owner_id(self, value: str | None):
        self._owner_id = value
    
    # Properties - File Information
    @property
    def name(self) -> str | None:
        """Display file name."""
        return self._name
    
    @name.setter
    def name(self, value: str | None):
        self._name = value
    
    @property
    def extension(self) -> str | None:
        """File extension computed from name (e.g., '.pdf')."""
        if not self._name:
            return None
        from pathlib import Path
        suffix = Path(self._name).suffix
        return suffix if suffix else None
    
    @extension.setter
    def extension(self, value: str | None):
        """Setter for DynamoDB serialization - does nothing."""
        pass
    
    @property
    def mime_type(self) -> str | None:
        """MIME type (e.g., 'application/pdf')."""
        return self._mime_type
    
    @mime_type.setter
    def mime_type(self, value: str | None):
        self._mime_type = value
    
    @property
    def size(self) -> int:
        """File size in bytes."""
        return self._size
    
    @size.setter
    def size(self, value: int):
        self._size = value if value is not None else 0
    
    @property
    def checksum(self) -> str | None:
        """File checksum (MD5/SHA256)."""
        return self._checksum
    
    @checksum.setter
    def checksum(self, value: str | None):
        self._checksum = value
    
    # Properties - Virtual Location
    @property
    def directory_id(self) -> str | None:
        """Parent directory ID (null = root)."""
        return self._directory_id
    
    @directory_id.setter
    def directory_id(self, value: str | None):
        self._directory_id = value
    
    @property
    def virtual_path(self) -> str | None:
        """Full virtual path (e.g., /docs/reports/Q1.pdf)."""
        return self._virtual_path
    
    @virtual_path.setter
    def virtual_path(self, value: str | None):
        self._virtual_path = value
    
    # Properties - S3 Physical Location
    @property
    def bucket(self) -> str | None:
        """S3 bucket name."""
        return self._bucket
    
    @bucket.setter
    def bucket(self, value: str | None):
        self._bucket = value
    
    @property
    def key(self) -> str | None:
        """S3 object key (physical location)."""
        return self._key
    
    @key.setter
    def key(self, value: str | None):
        self._key = value
    
    # Properties - Versioning
    @property
    def version_id(self) -> str | None:
        """Version identifier (can be user-set or from S3)."""
        return self._version_id
    
    @version_id.setter
    def version_id(self, value: str | None):
        self._version_id = value
    
    @property
    def version_ts_utc(self) -> float:
        """Version timestamp (UTC epoch seconds) - alias for created_utc_ts for sequential version ordering."""
        return self.created_utc_ts
    
    @version_ts_utc.setter
    def version_ts_utc(self, value: float):
        """Set version timestamp - updates created_utc_ts."""
        self.created_utc_ts = value
    
    # Properties - Metadata
    @property
    def description(self) -> str | None:
        """File description."""
        return self._description
    
    @description.setter
    def description(self, value: str | None):
        self._description = value
    
    @property
    def tags(self) -> List[str]:
        """Searchable tags."""
        return self._tags
    
    @tags.setter
    def tags(self, value: List[str] | None):
        self._tags = value if isinstance(value, list) else []
    
    # Properties - status
    @property
    def status(self) -> str:
        """File status: 'active', 'archived', 'deleted'."""
        return self._status
    
    @status.setter
    def status(self, value: str):
        if value not in ["active", "archived", "deleted"]:
            raise ValueError(f"Invalid status: {value}. Must be 'active', 'archived', or 'deleted'")
        self._status = value
    

    # Properties - state
    @property
    def state(self) -> str:
        """File state: 'ready', 'evaluating', 'validating', 'converting', 'processing', 'failed', 'deleted'."""
        return self._state
    
    @state.setter
    def state(self, value: str):
        # if value not in ["ready", "evaluating", "validating", "converting", "processing", "failed", "deleted"]:
        #     raise ValueError(f"Invalid state: {value}. Must be 'ready', 'evaluating', 'validating', 'converting', 'processing', 'failed', or 'deleted'")
        self._state = value
    
    # Properties - Lineage Tracking
    @property
    def lineage(self) -> str:
        """File lineage: 'original' or 'derived'."""
        return self._lineage
    
    @lineage.setter
    def lineage(self, value: str | None):
        # if value not in ["original", "derived"]:
        #     raise ValueError(f"Invalid lineage: {value}. Must be 'original' or 'derived'")
        self._lineage = value
    
    @property
    def root_id(self) -> str | None:
        """Root file in hierarchy (self.id for root files)."""
        return self._root_id or self.id 
    
    @root_id.setter
    def root_id(self, value: str | None):
        self._root_id = value

    @property
    def parent_id(self) -> str | None:
        """Parent file in hierarchy (None for root/original files)."""
        return self._parent_id
    
    @parent_id.setter
    def parent_id(self, value: str | None):
        self._parent_id = value
    
    @property
    def transformation_type(self) -> str | None:
        """Type of transformation applied: 'convert', 'clean', 'process'."""
        return self._transformation_type
    
    @transformation_type.setter
    def transformation_type(self, value: str | None):
        self._transformation_type = value
    
    @property
    def transformation_operation(self) -> str | None:
        """Specific operation performed (e.g., 'xls_to_csv', 'data_cleaning_v2')."""
        return self._transformation_operation
    
    @transformation_operation.setter
    def transformation_operation(self, value: str | None):
        self._transformation_operation = value
    
    @property
    def transformation_metadata(self) -> Dict[str, Any] | None:
        """Additional transformation details."""
        return self._transformation_metadata
    
    @transformation_metadata.setter
    def transformation_metadata(self, value: Dict[str, Any] | None):
        self._transformation_metadata = value if isinstance(value, dict) else None
    
    @property
    def resource_type(self) -> str | None:
        """Get the resource_type of the file."""
        return self._resource_type
    
    @resource_type.setter
    def resource_type(self, value: str | None):
        self._resource_type = value

    @property
    def visibility(self) -> str:
        """Get the visibility of the file."""
        return self._visibility
    
    @visibility.setter
    def visibility(self, value: str):
        if value not in ["private", "tenant", "public", "system"]:
            raise ValueError(f"Invalid visibility: {value}. Must be 'private', 'tenant', 'public', or 'system'")
        self._visibility = value
    
    @property
    def retention_policy(self) -> str | None:
        """Get the retention_policy of the file."""
        return self._retention_policy
    
    @retention_policy.setter
    def retention_policy(self, value: str | None):
        self._retention_policy = value

    @property
    def is_hidden(self) -> bool:
        """Get the is_hidden of the file."""
        return self._is_hidden
    
    @is_hidden.setter
    def is_hidden(self, value: bool):
        self._is_hidden = value

    @property
    def usage(self) -> str | None:
        """Get the usage designation of the file (e.g., 'media-input', 'analysis-input', 'template')."""
        return self._usage
    
    @usage.setter
    def usage(self, value: str | None):
        self._usage = value