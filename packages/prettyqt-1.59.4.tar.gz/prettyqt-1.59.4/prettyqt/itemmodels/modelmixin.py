from __future__ import annotations

from typing import TYPE_CHECKING, Any, ClassVar

from prettyqt import constants


if TYPE_CHECKING:
    from prettyqt import core


class ModelMixin:
    DTYPE_ROLE = constants.USER_ROLE + 1  # type: ignore
    HEADER: ClassVar = ["Name"]
    LABELS: ClassVar = {}
    CHECKSTATE: ClassVar = {}
    TOOLTIPS: ClassVar = {}
    DECORATIONS: ClassVar = {}
    SET_DATA: ClassVar = {}
    content_type = ""

    def headerData(
        self,
        offset: int,
        orientation: constants.Orientation,
        role: constants.ItemDataRole = constants.DISPLAY_ROLE,
    ):
        match orientation, role:
            case constants.HORIZONTAL, constants.DISPLAY_ROLE:
                return self.HEADER[offset]

    def columnCount(self, parent=None):
        return len(self.HEADER)

    def flags(self, index: core.ModelIndex) -> constants.ItemFlag:
        """Override for AbstractitemModel base method.

        returns corresponding flags for cell of supplied index
        """
        if not index.isValid():
            return constants.DROP_ENABLED
        if index.column() in self.SET_DATA:
            return self.DEFAULT_FLAGS | constants.IS_EDITABLE
        return self.DEFAULT_FLAGS

    def data(  # noqa: PLR0911
        self,
        index: core.ModelIndex,
        role: constants.ItemDataRole = constants.DISPLAY_ROLE,
    ):
        if not index.isValid():
            return None
        item = self.data_by_index(index)
        match role:
            case constants.DECORATION_ROLE:
                if fn := self.DECORATIONS.get(index.column()):
                    return fn(item)
                return None
            case constants.DISPLAY_ROLE | constants.EDIT_ROLE:
                if fn := self.LABELS.get(index.column()):
                    return fn(item)
                return None
            case constants.TOOLTIP_ROLE:
                if fn := self.TOOLTIPS.get(index.column()):
                    return fn(item)
                return None
            case constants.CHECKSTATE_ROLE:
                if fn := self.CHECKSTATE.get(index.column()):
                    return fn(item)
                return None
            case constants.USER_ROLE:
                return item
            case _:
                return None

    def setData(
        self,
        index: core.ModelIndex,
        value: Any,
        role: constants.ItemDataRole = constants.EDIT_ROLE,
    ) -> bool:
        if role == constants.EDIT_ROLE:
            if not value:
                return False
            item = self.data_by_index(index)
            if fn := self.SET_DATA.get(index.column()):
                fn(item, value)
                self.update_row(index.row())
                return True
            return None
        return None
