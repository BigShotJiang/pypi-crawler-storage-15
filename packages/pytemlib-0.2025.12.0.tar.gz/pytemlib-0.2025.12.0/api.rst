API Reference
=============

Package Structure
-----------------
The package structure is simple, with 4 main modules: `diffraction`: , `imaging`:, 'eds', and `eels`.

.. py:currentmodule:: sphinx

.. autosummary::
   :toctree: _autosummary
   :recursive:

   ./pyTEMlib/file_tools
