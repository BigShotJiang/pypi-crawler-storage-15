"""
PrestaShop Webservice - Python Client for PrestaShop API
"""

__version__ = "0.2.2"
__author__ = "Patitas Co."

from prestashop_webservice.address import Address
from prestashop_webservice.base_model import BaseModel
from prestashop_webservice.client import Client
from prestashop_webservice.country import Country
from prestashop_webservice.customer import Customer
from prestashop_webservice.image_product import ImageProduct
from prestashop_webservice.models import (
    AddressData,
    CountryData,
    CustomerData,
    ImageProductData,
    OrderCarrierData,
    OrderData,
    OrderHistoryData,
    OrderStateData,
    ProductData,
    StateData,
)
from prestashop_webservice.order import Order
from prestashop_webservice.order_carrier import OrderCarrier
from prestashop_webservice.order_history import OrderHistory
from prestashop_webservice.order_state import OrderState
from prestashop_webservice.params import Params, Sort, SortOrder
from prestashop_webservice.product import Product
from prestashop_webservice.state import State

__all__ = [
    "Client",
    "BaseModel",
    "Params",
    "Sort",
    "SortOrder",
    # Complex query models
    "Order",
    "OrderCarrier",
    "OrderHistory",
    "OrderState",
    "Customer",
    "Address",
    "State",
    "Product",
    "ImageProduct",
    "Country",
    # Data models
    "OrderData",
    "CustomerData",
    "ProductData",
    "AddressData",
    "CountryData",
    "OrderCarrierData",
    "OrderHistoryData",
    "OrderStateData",
    "StateData",
    "ImageProductData",
]
