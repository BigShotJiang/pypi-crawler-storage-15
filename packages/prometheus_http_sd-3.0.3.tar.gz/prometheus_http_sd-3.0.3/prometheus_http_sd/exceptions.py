class HTTPSDException(Exception):
    pass


class SDResultNotValidException(Exception):
    """The generated targets not valid"""
