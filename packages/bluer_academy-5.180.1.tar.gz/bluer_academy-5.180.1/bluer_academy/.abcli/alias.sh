#! /usr/bin/env bash

alias @academy=bluer_academy
