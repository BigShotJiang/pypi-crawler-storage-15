bluer_algo_root = "https://github.com/kamangir/bluer-algo"
bluer_algo_blob = f"{bluer_algo_root}/blob/main/bluer_algo"
bluer_algo_tree = f"{bluer_algo_root}/tree/main/bluer_algo"

bluer_ai_root = "https://github.com/kamangir/bluer-ai"
bluer_ai_tree = f"{bluer_ai_root}/tree/main/bluer_ai"

bluer_options_root = "https://github.com/kamangir/bluer-options"
bluer_options_blob = f"{bluer_options_root}/blob/main/bluer_options"

bluer_geo_root = "https://github.com/kamangir/bluer-geo"
bluer_geo_blob = f"{bluer_geo_root}/blob/main/bluer_geo"
bluer_geo_tree = f"{bluer_geo_root}/tree/main/bluer_geo"

bluer_sbc_root = "https://github.com/kamangir/bluer-sbc"
bluer_sbc_blob = f"{bluer_sbc_root}/blob/main/bluer_sbc"
bluer_sbc_tree = f"{bluer_sbc_root}/tree/main/bluer_sbc"

bluer_ugv_root = "https://github.com/kamangir/bluer-ugv"
bluer_ugv_blob = f"{bluer_ugv_root}/blob/main/bluer_ugv"
bluer_ugv_tree = f"{bluer_ugv_root}/tree/main/bluer_ugv"

palisades_root = "https://github.com/kamangir/palisades"
palisades_blob = f"{palisades_root}/blob/main/palisades"
palisades_tree = f"{bluer_ugv_root}/tree/main/palisades"

vanwatch_root = "https://github.com/kamangir/vancouver-watching"
