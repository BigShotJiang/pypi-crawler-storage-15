from bluer_academy.academy.classes.topic import Topic

topic = Topic(
    "template",
    [
        "template",
    ],
    duration=0,
    requires="template,template",
    items={},
)
