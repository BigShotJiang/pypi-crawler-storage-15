# Current META file

The current content of the meta file {{ task['path-modify-event'] }} is:

{{ task['path-modify-event'] | include_file_content }}
