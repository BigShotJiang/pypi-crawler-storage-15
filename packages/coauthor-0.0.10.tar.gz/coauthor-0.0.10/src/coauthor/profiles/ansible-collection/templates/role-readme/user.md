# Current Ansible Role `README.md`

The current content of the {{ task['path-modify-event'] }} is:

{{ task['path-modify-event'] | include_file_content }}
