"""C2 Platform Coauthor Modules Package"""

from __future__ import annotations
