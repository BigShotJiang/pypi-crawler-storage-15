"""Sparv plugin to import CoNLL-U files."""

from . import conllu_import

__all__ = ["conllu_import"]
