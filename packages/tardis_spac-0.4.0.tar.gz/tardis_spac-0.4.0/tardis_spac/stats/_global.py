from typing import Optional, Iterable
import anndata as ad
import numpy as np
import pandas as pd
from numba import njit
from tqdm import tqdm
import statsmodels.api as sm

@njit(nopython=True, parallel=True)
def kl_divergence(
    guide_data: ad.AnnData,
    reference_guide: str = 'sgNon-targeting',
    result_field: str = 'kl_div',
    guide_list: Iterable = None,
    library_key: Optional[str] = None,
    n_permutations: Optional[int] = 1000,
    show_progress: bool = True,
    copy: bool = False
):
    
    if copy:
        guide_data = guide_data.copy()
    
    if guide_list is None:
        guide_list = [x for x in guide_data.var_names if x != reference_guide]

    if not isinstance(guide_data.X, np.ndarray):
        guide_data.X = guide_data.X.toarray()

    guide_data = guide_data[:, guide_list].copy()

    if library_key is None:
        pdata = guide_data.copy()

        qk_guide = pdata[:, reference_guide].X.flatten() / pdata[:, reference_guide].X.sum()
        epx = 1 / pdata[:, reference_guide].X.sum()
        qk_guide = qk_guide + epx

        for guide in guide_list:
            pk_guide = pdata[:, guide].X.flatten() / pdata[:, guide].X.sum()
            pk_guide = pk_guide + epx
            kl_div = _kl_div(pk_guide / pk_guide.sum(), qk_guide / qk_guide.sum())
            pdata.var[result_field][guide] = kl_div
            
        if result_field not in pdata.var.columns:
            pdata.var[result_field] = np.zeros(len(guide_list))

        if n_permutations is not None:
            pdata.var[result_field + '.p_value'] = np.zeros(len(guide_list))
            idx_ntc = pdata.var_names.get_loc(reference_guide)
            for guide in tqdm(guide_list, desc=f'{guide}', disable=not show_progress):
                idx_guide = pdata.var_names.get_loc(guide)
                for _ in range(n_permutations):
                    perm_guide_vec, perm_ntc_vec = _permute_guide_bins(pdata[:, guide_list + [reference_guide]].X, idx_guide, idx_ntc)
                    perm_pk_guide = perm_guide_vec / perm_guide_vec.sum()
                    perm_pk_guide = perm_pk_guide + epx
                    perm_qk_guide = perm_ntc_vec / perm_ntc_vec.sum()
                    perm_qk_guide = perm_qk_guide + epx
                    perm_kl_div = _kl_div(perm_pk_guide / perm_pk_guide.sum(), perm_qk_guide / perm_qk_guide.sum())
                    pdata.var[result_field + '.p_value'][guide] += perm_kl_div > kl_div
        pdata.var[result_field + '.p_value'] = pdata.var[result_field + '.p_value'] / n_permutations

        guide_data.var[result_field + '.p_value'] = pdata.var[result_field + '.p_value']
        guide_data.var[result_field] = pdata.var[result_field]
    else:
        library_key_list = guide_data.obs[library_key].unique()
        for library_key in library_key_list:
            pdata = guide_data[guide_data.obs[library_key] == library_key].copy()

            qk_guide = pdata[:, reference_guide].X.flatten() / pdata[:, reference_guide].X.sum()
            epx = 1 / pdata[:, reference_guide].X.sum()
            qk_guide = qk_guide + epx
            
            for guide in guide_list:
                pk_guide = pdata[:, guide].X.flatten() / pdata[:, guide].X.sum()
                pk_guide = pk_guide + epx
                kl_div = _kl_div(pk_guide / pk_guide.sum(), qk_guide / qk_guide.sum())
                pdata.var[result_field][guide] = kl_div

            if library_key + result_field not in pdata.var.columns:
                pdata.var[library_key + result_field] = np.zeros(len(guide_list))
            
            non_nan_mask = pdata.var[library_key + result_field].notna()
            pdata.var.loc[non_nan_mask, library_key + result_field + '.rank'] = pdata.var[library_key + result_field].rank(method='min', ascending=False)
            pdata.var.loc[non_nan_mask, library_key + result_field + '.rank'] = np.nan

            guide_data.var[library_key + result_field + '.rank'] = pdata.var[library_key + result_field + '.rank']

        rank_cols = guide_data.var.columns[guide_data.var.columns.str.endswith(result_field + '.rank')]
        guide_data.var[result_field + '.mean_rank'] = guide_data.var[rank_cols].mean(axis=1, skipna=True)
        guide_data.var[result_field + '.final_rank'] = guide_data.var[result_field + '.mean_rank'].rank(method='min', ascending=True)

        if n_permutations is not None:
            guide_data.var[result_field + '.p_value'] = np.zeros(len(guide_list))
            for _ in tqdm(range(n_permutations), desc='Permutation', disable=not show_progress):
                perm_entropy = {}
                for library_key in library_key_list:
                    perm_entropy[library_key] = {}
                    pdata = guide_data[guide_data.obs[library_key] == library_key].copy()
                    guide_matrix = pdata.X.copy()
                    idx_ntc = pdata.var_names.get_loc(reference_guide)

                    for guide in guide_list:
                        idx_guide = pdata.var_names.get_loc(guide)
                        perm_guide_vec, perm_ntc_vec = _permute_guide_bins(guide_matrix, idx_guide, idx_ntc)
                        perm_guide_vec = perm_guide_vec / np.sum(perm_guide_vec) + epx
                        perm_ntc_vec = perm_ntc_vec / np.sum(perm_ntc_vec) + epx

                        perm_entropy[library_key][guide] = _kl_div(perm_guide_vec / perm_guide_vec.sum(), perm_ntc_vec / perm_ntc_vec.sum())
                    
                perm_df = pd.DataFrame(perm_entropy)
                for col in perm_df.columns:
                    non_nan_mask = perm_df[col].notna()
                    perm_df.loc[non_nan_mask, col + '.rank'] = perm_df.loc[non_nan_mask, col].rank(method='min', ascending=False)
                    perm_df.loc[non_nan_mask, col + '.rank'] = np.nan

                rank_cols = perm_df.columns[perm_df.columns.str.endswith('.rank')]
                perm_df['mean_rank'] = perm_df[rank_cols].mean(axis=1, skipna=True)
                perm_df['final_rank'] = perm_df['mean_rank'].rank(method='min', ascending=True)

                for guide in guide_list:
                    guide_data.var[result_field + '.p_value'][guide] += perm_df['final_rank'][guide] < guide_data.var[result_field + '.rank'][guide]
            guide_data.var[result_field + '.p_value'] = guide_data.var[result_field + '.p_value'] / n_permutations

    if copy:
        return guide_data
    else:
        return None

@njit(nopython=True, parallel=True)
def wasserstein_distance(
    guide_data: ad.AnnData,
    reference_guide: str = 'sgNon-targeting',
    result_field: str = 'w_dist',
    guide_list: Iterable = None,
    spatial_key: str = 'spatial',
    library_key: Optional[str] = None,
    n_permutations: Optional[int] = 1000,
    spatial_interval: float = 200,
    bin_width: Optional[str | int] = 'silverman',
    show_progress: bool = True,
    copy: bool = False
):
    if copy:
        guide_data = guide_data.copy()

    if guide_list is None:
        guide_list = [x for x in guide_data.var_names if x != reference_guide]

    if not isinstance(guide_data.X, np.ndarray):
        guide_data.X = guide_data.X.toarray()
        
    guide_data = guide_data[:, guide_list].copy()

    if library_key is None:
        pdata = guide_data.copy()

        if result_field not in pdata.var.columns:
            pdata.var[result_field] = np.zeros(len(guide_list))

        x_min, x_max = pdata.obsm[spatial_key][:, 0].min(), pdata.obsm[spatial_key][:, 0].max()
        y_min, y_max = pdata.obsm[spatial_key][:, 1].min(), pdata.obsm[spatial_key][:, 1].max()

        x_bins, y_bins = (x_max - x_min) // spatial_interval, (y_max - y_min) // spatial_interval
        x_grid = np.linspace(x_min, x_max, x_bins)
        y_grid = np.linspace(y_min, y_max, y_bins)

        if bin_width == 'silverman':
            kde_matrix_dict = {}
            for guide in guide_list + [reference_guide]:
                cnt_grid = np.arange(pdata[:, guide].X.min(), pdata[:, guide].X.max(), 1.06 * np.std(pdata[:, guide].X) * (len(pdata[:, guide].X) ** (-1 / 5))).round(2)
                kde_matrix_dict[guide] = _calculate_kde(pdata, spatial_key, x_grid, y_grid, cnt_grid, pdata[:, guide].X.flatten())
            
            for guide in guide_list:
                pdata.var[result_field][guide] = wasserstein_distance(kde_matrix_dict[guide], kde_matrix_dict[reference_guide])

            if n_permutations is not None:
                pdata.var[result_field + '.p_value'] = np.zeros(len(guide_list))
                idx_ntc = pdata.var_names.get_loc(reference_guide)
                for guide in guide_list:
                    idx_guide = pdata.var_names.get_loc(guide)
                    for _ in tqdm(range(n_permutations), desc=f'{guide}', disable=not show_progress):
                        perm_guide_vec, perm_ntc_vec = _permute_guide_bins(pdata[:, guide_list + [reference_guide]].X, idx_guide, idx_ntc)
                        
                        ntc_grid = np.arange(perm_ntc_vec.min(), perm_ntc_vec.max(), 1.06 * np.std(perm_ntc_vec) * (len(perm_ntc_vec) ** (-1 / 5))).round(2)
                        kde_ntc = _calculate_kde(pdata, spatial_key, x_grid, y_grid, ntc_grid, perm_ntc_vec)
                        
                        guide_grid = np.arange(perm_guide_vec.min(), perm_guide_vec.max(), 1.06 * np.std(perm_guide_vec) * (len(perm_guide_vec) ** (-1 / 5))).round(2)
                        kde_guide = _calculate_kde(pdata, spatial_key, x_grid, y_grid, guide_grid, perm_guide_vec)

                        w_dist = wasserstein_distance(kde_guide, kde_ntc)
                        pdata.var[result_field + '.p_value'][guide] += w_dist > pdata.var[result_field][guide]
                    pdata.var[result_field + '.p_value'][guide] = pdata.var[result_field + '.p_value'][guide] / n_permutations
        else:
            kde_matrix_dict = {}
            for guide in guide_list + [reference_guide]:
                cnt_grid = np.arange(pdata[:, guide].X.min(), pdata[:, guide].X.max(), bin_width)
                kde_matrix_dict[guide] = _calculate_kde(pdata, spatial_key, x_grid, y_grid, cnt_grid, pdata[:, guide].X.flatten())
            
            for guide in guide_list:
                pdata.var[result_field][guide] = wasserstein_distance(kde_matrix_dict[guide], kde_matrix_dict[reference_guide])
            
            if n_permutations is not None:
                pdata.var[result_field + '.p_value'] = np.zeros(len(guide_list))
                idx_ntc = pdata.var_names.get_loc(reference_guide)
                for guide in guide_list:
                    idx_guide = pdata.var_names.get_loc(guide)
                    for _ in tqdm(range(n_permutations), desc=f'{guide}', disable=not show_progress):
                        perm_guide_vec, perm_ntc_vec = _permute_guide_bins(pdata[:, guide_list + [reference_guide]].X, idx_guide, idx_ntc)
                        
                        ntc_grid = np.arange(perm_ntc_vec.min(), perm_ntc_vec.max(), bin_width).round(2)
                        kde_cnt = _calculate_kde(pdata, spatial_key, x_grid, y_grid, ntc_grid, perm_ntc_vec)
                        
                        guide_grid = np.arange(perm_guide_vec.min(), perm_guide_vec.max(), bin_width).round(2)
                        kde_guide = _calculate_kde(pdata, spatial_key, x_grid, y_grid, guide_grid, perm_guide_vec)

                        w_dist = wasserstein_distance(kde_guide, kde_cnt)
                        pdata.var[result_field + '.p_value'][guide] += w_dist > pdata.var[result_field][guide]
                    pdata.var[result_field + '.p_value'][guide] = pdata.var[result_field + '.p_value'][guide] / n_permutations
        guide_data.var[result_field + '.p_value'] = pdata.var[result_field + '.p_value']
        guide_data.var[result_field] = pdata.var[result_field]
    else:
        library_key_list = guide_data.obs[library_key].unique()
        for library_key in library_key_list:
            pdata = guide_data[guide_data.obs[library_key] == library_key].copy()

            if library_key + result_field not in pdata.var.columns:
                pdata.var[library_key + result_field] = np.zeros(len(guide_list))

            x_min, x_max = pdata.obsm[spatial_key][:, 0].min(), pdata.obsm[spatial_key][:, 0].max()
            y_min, y_max = pdata.obsm[spatial_key][:, 1].min(), pdata.obsm[spatial_key][:, 1].max()
            
            x_bins, y_bins = (x_max - x_min) // spatial_interval, (y_max - y_min) // spatial_interval
            x_grid = np.linspace(x_min, x_max, x_bins)
            y_grid = np.linspace(y_min, y_max, y_bins)

            if bin_width == 'silverman':
                kde_matrix_dict = {}
                for guide in guide_list + [reference_guide]:
                    cnt_grid = np.arange(pdata[:, guide].X.min(), pdata[:, guide].X.max(), 1.06 * np.std(pdata[:, guide].X) * (len(pdata[:, guide].X) ** (-1 / 5))).round(2)
                    kde_matrix_dict[guide] = _calculate_kde(pdata, spatial_key, x_grid, y_grid, cnt_grid, pdata[:, guide].X.flatten())
                
                for guide in guide_list:
                    pdata.var[library_key + result_field][guide] = wasserstein_distance(kde_matrix_dict[guide], kde_matrix_dict[reference_guide])
                
                non_nan_mask = pdata.var[library_key + result_field].notna()
                pdata.var.loc[non_nan_mask, library_key + result_field + '.rank'] = pdata.var[library_key + result_field].rank(method='min', ascending=False)
                pdata.var.loc[non_nan_mask, library_key + result_field + '.rank'] = np.nan

                guide_data.var[library_key + result_field + '.rank'] = pdata.var[library_key + result_field + '.rank']
                
            else:
                kde_matrix_dict = {}
                for guide in tqdm(guide_list + [reference_guide], desc='Wasserstein Distance', disable=not show_progress):
                    cnt_grid = np.arange(pdata[:, guide].X.min(), pdata[:, guide].X.max(), bin_width)
                    kde_matrix_dict[guide] = _calculate_kde(pdata, spatial_key, x_grid, y_grid, cnt_grid, pdata[:, guide].X.flatten())
                
                for guide in tqdm(guide_list, desc='Wasserstein Distance', disable=not show_progress):
                    pdata.var[library_key + result_field][guide] = wasserstein_distance(kde_matrix_dict[guide], kde_matrix_dict[reference_guide])
                
                non_nan_mask = pdata.var[library_key + result_field].notna()
                pdata.var.loc[non_nan_mask, library_key + result_field + '.rank'] = pdata.var[library_key + result_field].rank(method='min', ascending=False)
                pdata.var.loc[non_nan_mask, library_key + result_field + '.rank'] = np.nan

                guide_data.var[library_key + result_field + '.rank'] = pdata.var[library_key + result_field + '.rank']
            
        rank_cols = guide_data.var.columns[guide_data.var.columns.str.endswith(result_field + '.rank')]
        guide_data.var[result_field + '.mean_rank'] = guide_data.var[rank_cols].mean(axis=1, skipna=True)
        guide_data.var[result_field + '.final_rank'] = guide_data.var[result_field + '.mean_rank'].rank(method='min', ascending=True)

        if n_permutations is not None:
            guide_data.var[result_field + '.p_value'] = np.zeros(len(guide_list))
            if bin_width == 'silverman':
                for _ in range(n_permutations):
                    perm_dist = {}
                    for library_key in library_key_list:
                        perm_dist[library_key] = {}
                        pdata = guide_data[guide_data.obs[library_key] == library_key].copy()
                        idx_ntc = pdata.var_names.get_loc(reference_guide)
                        for guide in guide_list + [reference_guide]:
                            idx_guide = pdata.var_names.get_loc(guide)
                            perm_guide_vec, perm_ntc_vec = _permute_guide_bins(pdata[:, guide_list + [reference_guide]].X, idx_guide, idx_ntc)
                            
                            ntc_grid = np.arange(perm_ntc_vec.min(), perm_ntc_vec.max(), 1.06 * np.std(perm_ntc_vec) * (len(perm_ntc_vec) ** (-1 / 5))).round(2)
                            kde_ntc = _calculate_kde(pdata, spatial_key, x_grid, y_grid, ntc_grid, perm_ntc_vec)
                            
                            guide_grid = np.arange(perm_guide_vec.min(), perm_guide_vec.max(), 1.06 * np.std(perm_guide_vec) * (len(perm_guide_vec) ** (-1 / 5))).round(2)
                            kde_guide = _calculate_kde(pdata, spatial_key, x_grid, y_grid, guide_grid, perm_guide_vec)

                            w_dist = wasserstein_distance(kde_guide, kde_ntc)
                            perm_dist[library_key][guide] = w_dist

                    perm_df = pd.DataFrame(perm_dist)
                    for col in perm_df.columns:
                        non_nan_mask = perm_df[col].notna()
                        perm_df.loc[non_nan_mask, col + '.rank'] = perm_df.loc[non_nan_mask, col].rank(method='min', ascending=False)
                        perm_df.loc[non_nan_mask, col + '.rank'] = np.nan

                    rank_cols = perm_df.columns[perm_df.columns.str.endswith('.rank')]
                    perm_df['mean_rank'] = perm_df[rank_cols].mean(axis=1, skipna=True)
                    perm_df['final_rank'] = perm_df['mean_rank'].rank(method='min', ascending=True)

                    for guide in guide_list:
                        guide_data.var[result_field + '.p_value'][guide] += perm_df['final_rank'][guide] < guide_data.var[result_field + '.rank'][guide]
                guide_data.var[result_field + '.p_value'] = guide_data.var[result_field + '.p_value'] / n_permutations
            else:
                for _ in range(n_permutations):
                    perm_dist = {}
                    for library_key in library_key_list:
                        perm_dist[library_key] = {}
                        pdata = guide_data[guide_data.obs[library_key] == library_key].copy()
                        idx_ntc = pdata.var_names.get_loc(reference_guide)
                        for guide in guide_list + [reference_guide]:
                            idx_guide = pdata.var_names.get_loc(guide)
                            perm_guide_vec, perm_ntc_vec = _permute_guide_bins(pdata[:, guide_list + [reference_guide]].X, idx_guide, idx_ntc)
                            
                            ntc_grid = np.arange(perm_ntc_vec.min(), perm_ntc_vec.max(), bin_width).round(2)
                            kde_ntc = _calculate_kde(pdata, spatial_key, x_grid, y_grid, ntc_grid, perm_ntc_vec)
                            
                            guide_grid = np.arange(perm_guide_vec.min(), perm_guide_vec.max(), bin_width).round(2)
                            kde_guide = _calculate_kde(pdata, spatial_key, x_grid, y_grid, guide_grid, perm_guide_vec)

                            w_dist = wasserstein_distance(kde_guide, kde_ntc)
                            perm_dist[library_key][guide] = w_dist
                            
                    perm_df = pd.DataFrame(perm_dist)
                    for col in perm_df.columns:
                        non_nan_mask = perm_df[col].notna()
                        perm_df.loc[non_nan_mask, col + '.rank'] = perm_df.loc[non_nan_mask, col].rank(method='min', ascending=False)
                        perm_df.loc[non_nan_mask, col + '.rank'] = np.nan

                    rank_cols = perm_df.columns[perm_df.columns.str.endswith('.rank')]
                    perm_df['mean_rank'] = perm_df[rank_cols].mean(axis=1, skipna=True)
                    perm_df['final_rank'] = perm_df['mean_rank'].rank(method='min', ascending=True)

                    for guide in guide_list:
                        guide_data.var[result_field + '.p_value'][guide] += perm_df['final_rank'][guide] < guide_data.var[result_field + '.rank'][guide]
                guide_data.var[result_field + '.p_value'] = guide_data.var[result_field + '.p_value'] / n_permutations

    if copy:
        return guide_data
    else:
        return None

@njit(nopython=True)
def _calculate_kde(pdata, spatial_key, x_grid, y_grid, ntc_grid, cnt_vec):
    X, Y, CNT = np.meshgrid(x_grid, y_grid, ntc_grid)
    kde = sm.nonparametric.KDEMultivariate(data=[
        pdata.obsm[spatial_key][:, 0],
        pdata.obsm[spatial_key][:, 1],
        cnt_vec
    ], var_type='cco',
    bw='normal_reference')

    grid_coords = np.column_stack([X.ravel(), Y.ravel(), CNT.ravel()])
    kde_values = kde.pdf(grid_coords).reshape(X.shape)
    kde_matrix = np.zeros((kde_values.shape[0], kde_values.shape[1]))
    for i in range(kde_values.shape[2]):
        kde_matrix += kde_values[:, :, i] * ntc_grid[i]
    return kde_matrix

@njit(nopython=True)
def _kl_div(pk, qk):
    return np.sum(np.where(pk != 0, pk * np.log(pk / qk), 0))

@njit(nopython=True, parallel=True)
def _permute_guide_bins(guide_matrix, idx_guide, idx_ntc, swap_rate=0.5):
    t_bins = (guide_matrix[:, idx_guide] > 0) | (guide_matrix[:, idx_ntc] > 0)
    guide_vec = guide_matrix[t_bins, idx_guide].copy()
    ntc_vec = guide_matrix[t_bins, idx_ntc].copy()
    swap_mask = np.random.randn(len(guide_vec)) < 1 - swap_rate * 2

    temp = guide_vec[swap_mask]
    guide_vec[swap_mask] = ntc_vec[swap_mask]
    ntc_vec[swap_mask] = temp
    ret_guide_vec = guide_matrix[:, idx_guide].copy()
    ret_ntc_vec = guide_matrix[:, idx_ntc].copy()
    ret_guide_vec[t_bins] = guide_vec
    ret_ntc_vec[t_bins] = ntc_vec
    return ret_guide_vec, ret_ntc_vec
