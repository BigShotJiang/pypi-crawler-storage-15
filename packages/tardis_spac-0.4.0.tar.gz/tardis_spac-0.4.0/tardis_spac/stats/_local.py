from typing import Optional
from weakref import ref
import anndata as ad
import numpy as np
import pandas as pd
from numba import njit
from tqdm import tqdm
import random
from scipy.spatial.distance import euclidean, pdist, squareform
from scipy.stats import gaussian_kde
from skbio.stats.distance import permanova as skbio_permanova, DistanceMatrix

def aitchison_distance(
    gdata: ad.AnnData,
    cluster_field: str,
    result_field: str = 'aitchison_dist',
    reference_guide: str = 'sgNon-targeting',
    library_key: Optional[str] = None,
    n_permutations: int = 1000,
    show_progress: bool = True,
    copy: bool = False
):

    if copy:
        gdata = gdata.copy()
        
    if gdata.obs[cluster_field].dtype is not str:
        gdata.obs[cluster_field] = gdata.obs[cluster_field].astype(str)

    if isinstance(gdata.X, np.ndarray):
        gdata.X = gdata.X.toarray()

    if library_key is None:
        count_df = pd.concat([
            pd.DataFrame(gdata.X, columns=gdata.var_names, index=gdata.obs_names),
            gdata.obs[cluster_field],
        ], axis=1)

        count_df = count_df.groupby(cluster_field).sum().unstack().unstack()

        n_clusters = gdata.obs[cluster_field].unique().shape[0]
        transform_df = count_df.apply(lambda x: 10 ** (np.log10(x + 1) - (np.log10(x + 1).sum() / n_clusters)), axis=1)

        dist_df = transform_df.apply(lambda x: euclidean(x, transform_df.loc[reference_guide]), axis=1).values
        gdata.obs[result_field] = dist_df

        if n_permutations is not None:
            gdata.var[result_field + '.p_value'] = np.zeros(len(gdata.var_names))
            for guide in gdata.var_names:
                if guide == reference_guide: continue
                for _ in tqdm(range(n_permutations), desc=f'{guide}', disable=not show_progress):
                    p_guide_cnts = count_df.loc[guide].copy()
                    p_ntc_cnts = count_df.loc[reference_guide].copy()

                    for cluster in count_df.index:
                        if random.random() < 0.5:
                            p_guide_cnts[cluster], p_ntc_cnts[cluster] = p_ntc_cnts[cluster], p_guide_cnts[cluster]
                    p_transform_cnts = np.vstack([
                        10 ** (np.log10(p_guide_cnts + 1) - (np.log10(p_guide_cnts + 1).sum() / n_clusters)),
                        10 ** (np.log10(p_ntc_cnts + 1) - (np.log10(p_ntc_cnts + 1).sum() / n_clusters)),
                    ])

                    dist = euclidean(p_transform_cnts.loc[guide], p_transform_cnts.loc[reference_guide])
                    gdata.var[result_field + '.p_value'][guide] += dist > gdata.var[result_field][guide]
            gdata.var[result_field + '.p_value'] = gdata.var[result_field + '.p_value'] / n_permutations

    else:
        library_key_list = gdata.obs[library_key].unique()
        n_clusters = gdata.obs[cluster_field].unique().shape[0]

        for sample in library_key_list:
            pdata = gdata[gdata.obs[library_key] == sample].copy()

            count_df = pd.concat([
                pd.DataFrame(pdata.X, columns=pdata.var_names, index=pdata.obs_names),
                pdata.obs[cluster_field],
            ], axis=1)

            count_df = count_df.groupby(cluster_field).sum().unstack().unstack()

            transform_df = count_df.apply(lambda x: 10 ** (np.log10(x + 1) - (np.log10(x + 1).sum() / n_clusters)), axis=1)

            dist_df = transform_df.apply(lambda x: euclidean(x, transform_df.loc[reference_guide]), axis=1).values
            gdata.var[sample + result_field] = dist_df

        if n_permutations is not None:
            for _ in tqdm(range(n_permutations), desc='Permutations', disable=not show_progress):
                aitchson_dist = {}
                for sample in library_key_list:
                    pdata = gdata[gdata.obs[library_key] == sample].copy()
                    aitchson_dist[sample] = {}

                    count_df = pd.concat([
                        pd.DataFrame(pdata.X, columns=pdata.var_names, index=pdata.obs_names),
                        pdata.obs[cluster_field],
                    ], axis=1)

                    count_df = count_df.groupby(cluster_field).sum().unstack().unstack()

                    for guide in pdata.var_names:
                        if guide == reference_guide: continue
                        p_guide_cnts = count_df.loc[guide].copy()
                        p_ntc_cnts = count_df.loc[reference_guide].copy()
                        
                        for cluster in count_df.index:
                            if random.random() < 0.5:
                                p_guide_cnts[cluster], p_ntc_cnts[cluster] = p_ntc_cnts[cluster], p_guide_cnts[cluster]
                                
                        p_transform_cnts = np.vstack([
                            10 ** (np.log10(p_guide_cnts + 1) - (np.log10(p_guide_cnts + 1).sum() / n_clusters)),
                            10 ** (np.log10(p_ntc_cnts + 1) - (np.log10(p_ntc_cnts + 1).sum() / n_clusters)),
                        ])

                        dist = euclidean(p_transform_cnts.loc[guide], p_transform_cnts.loc[reference_guide])
                        aitchson_dist[sample][guide] = dist
                
                perm_df = pd.DataFrame(aitchson_dist)
                for col in perm_df.columns:
                    non_nan_mask = perm_df[col].notna()
                    perm_df.loc[non_nan_mask, col + '.rank'] = perm_df.loc[non_nan_mask, col].rank(method='min', ascending=False)
                    perm_df.loc[non_nan_mask, col + '.rank'] = np.nan
                    
                rank_cols = perm_df.columns[perm_df.columns.str.endswith('.rank')]
                perm_df['mean_rank'] = perm_df[rank_cols].mean(axis=1, skipna=True)
                perm_df['final_rank'] = perm_df['mean_rank'].rank(method='min', ascending=True)

                for guide in pdata.var_names:
                    gdata.var[result_field + '.p_value'][guide] += perm_df['final_rank'][guide] < gdata.var[result_field][guide]
            gdata.var[result_field + '.p_value'] = gdata.var[result_field + '.p_value'] / n_permutations
    
    if copy:
        return gdata
    else:
        return None

def permanova(
    gdata: ad.AnnData,
    cluster_field: str,
    result_field: str = 'permanova_f_value',
    reference_guide: str = 'sgNon-targeting',
    library_key: Optional[str] = None,
    count_bins: int = 10,
    n_permutations: int = 1000,
    show_progress: bool = True,
    copy: bool = False
):

    if copy:
        gdata = gdata.copy()

    if isinstance(gdata.X, np.ndarray):
        gdata.X = gdata.X.toarray()

    if gdata.obs[cluster_field].dtype is not str:
        gdata.obs[cluster_field] = gdata.obs[cluster_field].astype(str)

    cluster_tags = gdata.obs[cluster_field].unique()

    if library_key is None:
        count_df = pd.concat([
            pd.DataFrame(gdata.X, columns=gdata.var_names, index=gdata.obs_names),
            gdata.obs[cluster_field],
        ], axis=1)

        pseudo_f = {}
        perm_data_dict = {}
        for guide in gdata.var_names:
            if guide == reference_guide: continue
            guide_count_df = count_df[[guide, reference_guide, cluster_field]]

            
            ref_df = guide_count_df.groupby([cluster_field, reference_guide]).count().unstack()[guide]
            guide_df = guide_count_df.groupby([cluster_field, guide]).count().unstack()[reference_guide]
            
            x_grid = np.linspace(0, guide_df.columns.max() + 0.5, count_bins)
            guide_cnts = []
            for cluster in cluster_tags:
                if cluster in guide_df.index:
                    guide_kde = gaussian_kde(guide_df.loc[cluster].dropna())
                    guide_density = guide_kde(x_grid)
                    guide_density = guide_density / guide_density.sum()
                    guide_cnts.append(guide_density)
                else:
                    guide_cnts.append(np.zeros_like(x_grid))
            guide_cnts = np.array(guide_cnts)

            x_grid = np.linspace(0, ref_df.columns.max() + 0.5, count_bins)
            ref_cnts = []
            for cluster in cluster_tags:
                if cluster in ref_df.index:
                    guide_kde = gaussian_kde(ref_df.loc[cluster].dropna())
                    guide_density = guide_kde(x_grid)
                    guide_density = guide_density / guide_density.sum()
                    ref_cnts.append(guide_density)
                else:
                    ref_cnts.append(np.zeros_like(x_grid))
            ref_cnts = np.array(ref_cnts)

            perm_data = np.vstack([guide_cnts, ref_cnts])
            perm_data_dict[guide] = perm_data.copy()
            sample_ids = np.array([[name + str(c) for c in guide_count_df.cluster.unique()] for name in ['guide_', 'ref_']]).flatten()

            dist_matrix = squareform(pdist(perm_data, metric='braycurtis'))
            metadata = pd.DataFrame({'group': ['guide'] * len(cluster_tags) + ['ref'] * len(cluster_tags)}, index=sample_ids)
            dm = DistanceMatrix(dist_matrix, ids=sample_ids)

            results = skbio_permanova(dm, metadata, column='group', permutations=100)
            pseudo_f[guide] = results['pseudo-F']

            gdata.var[result_field] = pd.DataFrame(pseudo_f)
        
        if n_permutations is not None:
            gdata.var[result_field + '.p_value'] = np.zeros(len(gdata.var_names))
            for _ in tqdm(range(n_permutations), desc='Permutations', disable=not show_progress):
                for guide in gdata.var_names:
                    perm_data = perm_data_dict[guide].copy()
                    for cluster in range(len(cluster_tags)):
                        if random.random() < 0.5:
                            _exchange = perm_data[cluster]
                            perm_data[cluster] = perm_data[len(cluster_tags) + cluster]
                            perm_data[len(cluster_tags) + cluster] = _exchange
                    perm_sample_ids = np.array([[name + str(c) for c in guide_count_df.cluster.unique()] for name in ['guide_', 'ref_']]).flatten()
                    perm_dist_matrix = squareform(pdist(perm_data, metric='braycurtis'))
                    perm_metadata = pd.DataFrame({'group': ['guide'] * len(cluster_tags) + ['ref'] * len(cluster_tags)}, index=sample_ids)
                    perm_dm = DistanceMatrix(perm_dist_matrix, ids=perm_sample_ids)
                    perm_results = skbio_permanova(perm_dm, perm_metadata, column='group', permutations=100)
                    gdata.var[result_field + '.p_value'][guide] += perm_results['pseudo-F'] > gdata.var[result_field][guide]
            gdata.var[result_field + '.p_value'] = gdata.var[result_field + '.p_value'] / n_permutations

    else:
        library_key_list = gdata.obs[library_key].unique()
        
        perm_data_dict = {}
        for sample in library_key_list:
            pdata = gdata[gdata.obs[library_key] == sample].copy()
            perm_data_dict[sample] = {}
            count_df = pd.concat([
                pd.DataFrame(pdata.X, columns=pdata.var_names, index=pdata.obs_names),
                pdata.obs[cluster_field],
            ], axis=1)

            for guide in pdata.var_names:
                if guide == reference_guide: continue
                guide_count_df = count_df[[guide, reference_guide, cluster_field]]

                
                ref_df = guide_count_df.groupby([cluster_field, reference_guide]).count().unstack()[guide]
                guide_df = guide_count_df.groupby([cluster_field, guide]).count().unstack()[reference_guide]
                
                x_grid = np.linspace(0, guide_df.columns.max() + 0.5, count_bins)
                guide_cnts = []
                for cluster in cluster_tags:
                    if cluster in guide_df.index:
                        guide_kde = gaussian_kde(guide_df.loc[cluster].dropna())
                        guide_density = guide_kde(x_grid)
                        guide_density = guide_density / guide_density.sum()
                        guide_cnts.append(guide_density)
                    else:
                        guide_cnts.append(np.zeros_like(x_grid))
                guide_cnts = np.array(guide_cnts)

                x_grid = np.linspace(0, ref_df.columns.max() + 0.5, count_bins)
                ref_cnts = []
                for cluster in cluster_tags:
                    if cluster in ref_df.index:
                        guide_kde = gaussian_kde(ref_df.loc[cluster].dropna())
                        guide_density = guide_kde(x_grid)
                        guide_density = guide_density / guide_density.sum()
                        ref_cnts.append(guide_density)
                    else:
                        ref_cnts.append(np.zeros_like(x_grid))
                ref_cnts = np.array(ref_cnts)

                perm_data = np.vstack([guide_cnts, ref_cnts])
                perm_data_dict[sample][guide] = perm_data
                sample_ids = np.array([[name + str(c) for c in guide_count_df.cluster.unique()] for name in ['guide_', 'ref_']]).flatten()

                dist_matrix = squareform(pdist(perm_data, metric='braycurtis'))
                metadata = pd.DataFrame({'group': ['guide'] * len(cluster_tags) + ['ref'] * len(cluster_tags)}, index=sample_ids)
                dm = DistanceMatrix(dist_matrix, ids=sample_ids)

                results = skbio_permanova(dm, metadata, column='group', permutations=100)
                pseudo_f[guide] = results['pseudo-F']

                gdata.var[sample + result_field] = pd.DataFrame(pseudo_f)

        if n_permutations is not None:
            gdata.var[result_field + '.p_value'] = np.zeros(len(gdata.var_names))
            for _ in tqdm(range(n_permutations), desc='Permutations', disable=not show_progress):
                permanova_pseudo_f = {}
                for sample in library_key_list:
                    pdata = gdata[gdata.obs[sample] == sample].copy()
                    permanova_pseudo_f[sample] = {}

                    for guide in pdata.var_names:
                        perm_data = perm_data_dict[sample][guide].copy()
                        for cluster in range(len(cluster_tags)):
                            if random.random() < 0.5:
                                _exchange = perm_data[cluster]
                                perm_data[cluster] = perm_data[len(cluster_tags) + cluster]
                                perm_data[len(cluster_tags) + cluster] = _exchange
                        perm_sample_ids = np.array([[name + str(c) for c in guide_count_df.cluster.unique()] for name in ['guide_', 'ref_']]).flatten()
                        perm_dist_matrix = squareform(pdist(perm_data, metric='braycurtis'))
                        perm_metadata = pd.DataFrame({'group': ['guide'] * len(cluster_tags) + ['ref'] * len(cluster_tags)}, index=sample_ids)
                        perm_dm = DistanceMatrix(perm_dist_matrix, ids=perm_sample_ids)
                        perm_results = skbio_permanova(perm_dm, perm_metadata, column='group', permutations=100)
                        permanova_pseudo_f[sample][guide] = perm_results['pseudo-F']
                perm_df = pd.DataFrame(permanova_pseudo_f)
                for col in perm_df.columns:
                    non_nan_mask = perm_df[col].notna()
                    perm_df.loc[non_nan_mask, col + '.rank'] = perm_df.loc[non_nan_mask, col].rank(method='min', ascending=False)
                    perm_df.loc[non_nan_mask, col + '.rank'] = np.nan
                    
                rank_cols = perm_df.columns[perm_df.columns.str.endswith('.rank')]
                perm_df['mean_rank'] = perm_df[rank_cols].mean(axis=1, skipna=True)
                perm_df['final_rank'] = perm_df['mean_rank'].rank(method='min', ascending=True)

                for guide in pdata.var_names:
                    gdata.var[result_field + '.p_value'][guide] += perm_df['final_rank'][guide] < gdata.var[result_field][guide]
            gdata.var[result_field + '.p_value'] = gdata.var[result_field + '.p_value'] / n_permutations

    if copy:
        return gdata
    else:
        return None