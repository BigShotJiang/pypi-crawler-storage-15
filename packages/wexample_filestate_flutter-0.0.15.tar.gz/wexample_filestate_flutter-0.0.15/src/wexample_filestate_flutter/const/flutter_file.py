from __future__ import annotations

FLUTTER_FILE_EXTENSIONS = [".dart"]
FLUTTER_FILE_EXTENSION = ".dart"
