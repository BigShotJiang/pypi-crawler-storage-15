"""
ReasonForge Algebra - Algebraic Operations and Equation Solving

MCP server providing 18 tools for equation solving, matrices, and optimization.
"""

__version__ = "0.1.0"
