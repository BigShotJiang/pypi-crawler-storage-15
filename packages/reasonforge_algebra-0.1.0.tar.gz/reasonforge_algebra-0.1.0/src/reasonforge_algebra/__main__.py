"""
Entry point for running the ReasonForge Algebra MCP server.

Usage:
    python -m reasonforge_algebra
"""

from .server import main

if __name__ == "__main__":
    main()
