from .extension import FlaskVite


__all__ = ["FlaskVite"]
