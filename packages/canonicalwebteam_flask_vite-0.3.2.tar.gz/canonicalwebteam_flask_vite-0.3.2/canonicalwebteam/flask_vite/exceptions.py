class ManifestPathException(Exception):
    pass


class ManifestContentException(Exception):
    pass


class AssetPathException(Exception):
    pass


class ExtensionNotInitialized(Exception):
    pass
