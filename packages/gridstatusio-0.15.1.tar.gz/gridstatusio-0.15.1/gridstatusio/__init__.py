from gridstatusio.version import __version__, check_for_update

from gridstatusio.gs_client import GridStatusClient


check_for_update()
