"""Type definitions for VLM Run API."""
