# audit/__init__.py

from .logger import AuditLogger

