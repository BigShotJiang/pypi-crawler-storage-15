# config/__init__.py

from .loader import load_config, build_pipeline_for

