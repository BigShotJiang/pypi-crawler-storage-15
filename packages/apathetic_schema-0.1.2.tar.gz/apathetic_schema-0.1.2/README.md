# Apathetic Python Schema 🧩

[![CI](https://github.com/apathetic-tools/python-schema/actions/workflows/ci.yml/badge.svg?branch=main)](https://github.com/apathetic-tools/python-schema/actions/workflows/ci.yml)
[![License: MIT-a-NOAI](https://img.shields.io/badge/License-MIT--a--NOAI-blueviolet.svg)](LICENSE)
[![Discord](https://img.shields.io/badge/Discord-%235865F2.svg?logo=discord&logoColor=white)](https://discord.gg/PW6GahZ7)

📘 **[Roadmap](./ROADMAP.md)** · 📝 **[Release Notes](https://github.com/apathetic-tools/python-schema/releases)**

**Lightweight validation for dict-based configs.**  
*Types can be schema too.*

*Apathetic Python Schema* validates dict-based data structures (configs, usually from JSONC/JSON/TOML) using Python TypedDicts used for mypy/pyright. No need for separate schema definitions — your type annotations are your schema.

> [!NOTE]
> Heads up: the AI cooked dinner. It's edible, but watch your step.  
> Detailed bug reports welcome.

## Quick Start

```python
from apathetic_schema import apathetic_schema, ApatheticSchema_ValidationSummary
from apathetic_utils import schema_from_typeddict
from typing import TypedDict
from pathlib import Path
import json

# Define your config schema using TypedDict
class AppConfig(TypedDict):
    name: str
    version: str
    port: int
    debug: bool

# Load config from JSON
with Path("config.json").open() as f:
    config = json.load(f)

# Validate against TypedDict schema
summary = ApatheticSchema_ValidationSummary(valid=True, errors=[], strict_warnings=[], warnings=[], strict=False)
schema = schema_from_typeddict(AppConfig)

is_valid = apathetic_schema.check_schema_conformance(
    config,
    schema,
    "in configuration file",
    strict_config=False,
    summary=summary,
)

if not summary.valid:
    print("Validation errors:", summary.errors)
    print("Warnings:", summary.warnings)
```

## Installation

```bash
# Using poetry
poetry add apathetic-schema

# Using pip
pip install apathetic-schema
```

## Documentation

📚 **[Full Documentation →](https://apathetic-tools.github.io/python-schema/)**

For installation guides, API reference, examples, and more, visit our documentation website.

## Features

- 🔍 **TypedDict validation** — Validate dict-based configs using Python TypedDicts
- 📋 **Recursive validation** — Supports nested TypedDicts and list types
- ⚠️ **Error aggregation** — Collect and report validation errors and warnings
- 🎯 **Strict mode** — Optional strict validation that treats warnings as errors
- 🔧 **Type-aware** — Works with mypy/pyright type annotations
- 🪶 **Minimal dependencies** — Only requires `apathetic-utils`
- 📝 **Helpful errors** — Provides context and suggestions for validation failures

---

## ⚖️ License

- [MIT-a-NOAI License](LICENSE)

You're free to use, copy, and modify the library under the standard MIT terms.  
The additional rider simply requests that this project not be used to train or fine-tune AI/ML systems until the author deems fair compensation frameworks exist.  
Normal use, packaging, and redistribution for human developers are unaffected.
