# oddoreven

A simple Python library to check whether a number is **odd** or **even**.

## Installation

```bash
pip install oddoreven
```
