"""UPathTools: main package.

UPath utilities.
"""

from __future__ import annotations

from importlib.metadata import version

__version__ = version("upathtools")
__title__ = "UPathTools"

__author__ = "Philipp Temminghoff"
__author_email__ = "philipptemminghoff@googlemail.com"
__copyright__ = "Copyright (c) 2024 Philipp Temminghoff"
__license__ = "MIT"
__url__ = "https://github.com/phil65/upathtools"

from fsspec import register_implementation
from upath import registry

from upathtools.helpers import to_upath, upath_to_fs
from upathtools.async_ops import read_path, read_folder, list_files, read_folder_as_text
from upathtools.async_upath import AsyncUPath
from upathtools.filesystems.httpx_fs import HttpPath, HTTPFileSystem
from upathtools.filesystems import CliFileSystem, CliPath
from upathtools.filesystems import DistributionFileSystem, DistributionPath
from upathtools.filesystems import FlatUnionFileSystem, FlatUnionPath
from upathtools.filesystems import MarkdownFileSystem, MarkdownPath
from upathtools.filesystems import ModuleFileSystem, ModulePath
from upathtools.filesystems import PackageFileSystem, PackagePath
from upathtools.filesystems import PythonAstPath, PythonAstFileSystem
from upathtools.filesystems import SqliteFileSystem, SqlitePath
from upathtools.filesystems.union_fs import UnionFileSystem, UnionPath
from upathtools.filesystems import GistFileSystem, GistPath
from upathtools.filesystems import WikiFileSystem, WikiPath


def register_http_filesystems() -> None:
    """Register HTTP filesystems."""
    register_implementation("http", HTTPFileSystem, clobber=True)
    registry.register_implementation("http", HttpPath, clobber=True)
    register_implementation("https", HTTPFileSystem, clobber=True)
    registry.register_implementation("https", HttpPath, clobber=True)


def register_all_filesystems() -> None:
    """Register all filesystem implementations provided by upathtools."""
    register_http_filesystems()
    register_implementation("cli", CliFileSystem, clobber=True)
    registry.register_implementation("cli", CliPath, clobber=True)

    register_implementation("distribution", DistributionFileSystem, clobber=True)
    registry.register_implementation("distribution", DistributionPath, clobber=True)

    register_implementation("flatunion", FlatUnionFileSystem, clobber=True)
    registry.register_implementation("flatunion", FlatUnionPath, clobber=True)

    register_implementation("md", MarkdownFileSystem, clobber=True)
    registry.register_implementation("md", MarkdownPath, clobber=True)

    register_implementation("mod", ModuleFileSystem, clobber=True)
    registry.register_implementation("mod", ModulePath, clobber=True)

    register_implementation("pkg", PackageFileSystem, clobber=True)
    registry.register_implementation("pkg", PackagePath, clobber=True)

    register_implementation("ast", PythonAstFileSystem, clobber=True)
    registry.register_implementation("ast", PythonAstPath, clobber=True)

    register_implementation("sqlite", SqliteFileSystem, clobber=True)
    registry.register_implementation("sqlite", SqlitePath, clobber=True)

    register_implementation("union", UnionFileSystem, clobber=True)
    registry.register_implementation("union", UnionPath, clobber=True)

    register_implementation("gist", GistFileSystem, clobber=True)
    registry.register_implementation("gist", GistPath, clobber=True)

    register_implementation("wiki", WikiFileSystem, clobber=True)
    registry.register_implementation("wiki", WikiPath, clobber=True)


__all__ = [
    "AsyncUPath",
    "CliFileSystem",
    "CliPath",
    "DistributionFileSystem",
    "DistributionPath",
    "FlatUnionFileSystem",
    "FlatUnionPath",
    "GistFileSystem",
    "GistPath",
    "HTTPFileSystem",
    "HttpPath",
    "MarkdownFileSystem",
    "MarkdownPath",
    "ModuleFileSystem",
    "ModulePath",
    "PackageFileSystem",
    "PackagePath",
    "PythonAstFileSystem",
    "PythonAstPath",
    "SqliteFileSystem",
    "SqlitePath",
    "UnionFileSystem",
    "UnionPath",
    "WikiFileSystem",
    "WikiPath",
    "__version__",
    "list_files",
    "read_folder",
    "read_folder_as_text",
    "read_path",
    "register_all_filesystems",
    "register_http_filesystems",
    "to_upath",
    "upath_to_fs",
]
