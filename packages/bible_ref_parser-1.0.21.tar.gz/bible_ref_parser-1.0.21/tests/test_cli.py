import subprocess
import sys
import os
import pytest


def run_cli(arg_string):
    """Run the bible-ref-parser CLI and return (stdout, stderr, returncode)."""
    result = subprocess.run(
        ["bible-ref-parser", arg_string],
        capture_output=True,
        text=True
    )
    return result.stdout.strip(), result.stderr.strip(), result.returncode


def test_cli_simple_reference():
    stdout, stderr, code = run_cli("Jn 3:16")

    assert code == 0
    assert "John 3:16" in stdout
    assert stderr == ""


def test_cli_multiple_references():
    stdout, stderr, code = run_cli("Jn3:16, Mk1:2")

    assert code == 0
    assert "John 3:16" in stdout
    assert "Mark 1:2" in stdout


def test_cli_invalid_reference():
    stdout, stderr, code = run_cli("NotARef123")

    assert code == 0

    # CLI prints 3 empty lists (raw, split, expanded)
    lines = stdout.strip().splitlines()
    assert len(lines) == 3
    assert all(line.strip() == "[]" for line in lines)

    assert stderr == ""
