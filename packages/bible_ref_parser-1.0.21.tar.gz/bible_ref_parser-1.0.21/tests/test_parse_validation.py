
import pytest
from bible_ref_parser import parse


# ---------------------------------------------------
#  Paste your entire ValidationTests dictionary here
# ---------------------------------------------------

ValidationTests = {
    "clean_standard":{
    "text": "\n    John 3:16, Romans 8:28, Psalm 23:1-6, Matthew 5:1-12, Luke 15:3-7, \n    Acts 2:1-4, 1 Corinthians 13:4-7, Ephesians 2:8-10, Isaiah 40:28-31, \n    Jeremiah 29:11, Proverbs 3:5-6, Revelation 22:20\n",    
    "raw": ["John 3:16", "Romans 8:28", "Psalm 23:1-6", "Matthew 5:1-12", "Luke 15:3-7", "Acts 2:1-4", "1 Corinthians 13:4-7", "Ephesians 2:8-10", "Isaiah 40:28-31", "Jeremiah 29:11", "Proverbs 3:5-6", "Revelation 22:20"],    
    "split": ["John 3:16", "Romans 8:28", "Psalm 23:1-6", "Matthew 5:1-12", "Luke 15:3-7", "Acts 2:1-4", "1 Corinthians 13:4-7", "Ephesians 2:8-10", "Isaiah 40:28-31", "Jeremiah 29:11", "Proverbs 3:5-6", "Revelation 22:20"],    
    "exp": ["John 3:16", "Romans 8:28", "Psalms 23:1-6", "Matthew 5:1-12", "Luke 15:3-7", "Acts 2:1-4", "1 Corinthians 13:4-7", "Ephesians 2:8-10", "Isaiah 40:28-31", "Jeremiah 29:11", "Proverbs 3:5-6", "Revelation 22:20"]
    },
    "mashed_references":{
        "text": "Ro8-10beforeSeeJn3-5now!Eph1:3-7andGal5:1-2",    
        "raw": ["Ro 8-10", "Jn 3-5", "Eph 1:3-7", "Gal 5:1-2"],    
        "split": ["Ro 8-10", "Jn 3-5", "Eph 1:3-7", "Gal 5:1-2"],    
        "exp": ["Romans 8-10", "John 3-5", "Ephesians 1:3-7", "Galatians 5:1-2"]
    },
    "back_to_back":{
        "text": "Ps23;Jn1:1;Rev22:20Ge1:1Ex3:14Is53:5",    
        "raw": ["Ps 23", "Jn 1:1", "Rev 22:20", "Ge 1:1", "Ex 3:14", "Is 53:5"],    
        "split": ["Ps 23", "Jn 1:1", "Rev 22:20", "Ge 1:1", "Ex 3:14", "Is 53:5"],    
        "exp": ["Psalms 23", "John 1:1", "Revelation 22:20", "Genesis 1:1", "Exodus 3:14", "Isaiah 53:5"]
    },
    "cross_chapter_ranges":{
        "text": "Jer 29:11,30:10 Isa 52:13,53:3",    
        "raw": ["Jer 29:11,30:10", "Isa 52:13,53:3"],    
        "split": ["Jer 29:11", "Jer 30:10", "Isa 52:13", "Isa 53:3"],    
        "exp": ["Jeremiah 29:11", "Jeremiah 30:10", "Isaiah 52:13", "Isaiah 53:3"]
    },
    "colonless_chapters":{
        "text": "Ps23 Jn3 1Co13",    
        "raw": ["Ps 23", "Jn 3", "1 Co 13"],    
        "split": ["Ps 23", "Jn 3", "1 Co 13"],    
        "exp": ["Psalms 23", "John 3", "1 Corinthians 13"]
    },
    "embedded_brackets":{
        "text": "(Jn3:16) [Ro10:9-10] \u201cEph2:8-9\u201d",    
        "raw": ["Jn 3:16", "Ro 10:9-10", "Eph 2:8-9"],    
        "split": ["Jn 3:16", "Ro 10:9-10", "Eph 2:8-9"],    
        "exp": ["John 3:16", "Romans 10:9-10", "Ephesians 2:8-9"]
    },
    "broken_spacing":{
        "text": "1Co 13 : 4 -7 pRoV3:5",    
        "raw": ["1 Co 13:4-7", "Prov 3:5"],    
        "split": ["1 Co 13:4-7", "Prov 3:5"],    
        "exp": ["1 Corinthians 13:4-7", "Proverbs 3:5"]
    },
    "punctuation_traps":{
        "text": "Mt5:3,Mt5:4;Mt5:5. Mk4:2! Lk4:1?",    
        "raw": ["Mt 5:3", "Mt 5:4", "Mt 5:5", "Mk 4:2", "Lk 4:1"],    
        "split": ["Mt 5:3", "Mt 5:4", "Mt 5:5", "Mk 4:2", "Lk 4:1"],    
        "exp": ["Matthew 5:3", "Matthew 5:4", "Matthew 5:5", "Mark 4:2", "Luke 4:1"]
    },
    "short_books":{
        "text": "3Jn1-4 Jude5 1Sa2:3",    
        "raw": ["3 Jn 1-4", "Jude 5", "1 Sa 2:3"],    
        "split": ["3 Jn 1-4", "Jude 5", "1 Sa 2:3"],    
        "exp": ["3 John 1-4", "Jude 5", "1 Samuel 2:3"]
    },
    "unicode_and_smart_quotes":{
        "text": "Isa 52:13\u201353:3 \u201cJn3:16\u201d",    
        "raw": ["Isa 52:13-53:3", "Jn 3:16"],    
        "split": ["Isa 52:13", "Isa 53:3", "Jn 3:16"],    
        "exp": ["Isaiah 52:13", "Isaiah 53:3", "John 3:16"]
    },
    "false_dates_times_rooms":{
        "text": "1/3/2024 3:16pm Room12-4 not references","raw": [],    
        "split": [],    "exp": []},
    "false_product_codes_math":{
        "text": "ABC123:55 XYZ-100-20 3:5=x:10 not references","raw": [],    
        "split": [],    "exp": []},
    "mixed_case_embedded":{
        "text": "pRoV3:5 SomethingLike1Jn4:8hidden",    
        "raw": ["Prov 3:5", "1 Jn 4:8"],    
        "split": ["Prov 3:5", "1 Jn 4:8"],    
        "exp": ["Proverbs 3:5", "1 John 4:8"]
    },
    "multi_line":{
        "text": "First:\nEph2:8-9\nNext:\nTit3:5",    
        "raw": ["Eph 2:8-9", "Tit 3:5"],    
        "split": ["Eph 2:8-9", "Tit 3:5"],    
        "exp": ["Ephesians 2:8-9", "Titus 3:5"]
    },
    "mega_stress":{
        "text": "Ge1:1Ex3:14Is53:5 Ro8-10before SeeJn3-5now! He12:22-24;8:5-9 Ps23;Jn1:1;Rev22:20\n",    
        "raw": ["Ge 1:1", "Ex 3:14", "Is 53:5", "Ro 8-10", "Jn 3-5", "He 12:22-24;8:5-9", "Ps 23", "Jn 1:1", "Rev 22:20"],    
        "split": ["Ge 1:1", "Ex 3:14", "Is 53:5", "Ro 8-10", "Jn 3-5", "He 12:22-24", "He 8:5-9", "Ps 23", "Jn 1:1", "Rev 22:20"],    
        "exp": ["Genesis 1:1", "Exodus 3:14", "Isaiah 53:5", "Romans 8-10", "John 3-5", "Hebrews 12:22-24", "Hebrews 8:5-9", "Psalms 23", "John 1:1", "Revelation 22:20"]
    },
    "colonless_numbers":{
        "text": "1Th4:7 1Pe5:10 2Ti3:16",    
        "raw": ["1 Th 4:7", "1 Pe 5:10", "2 Ti 3:16"],    
        "split": ["1 Th 4:7", "1 Pe 5:10", "2 Ti 3:16"],    
        "exp": ["1 Thessalonians 4:7", "1 Peter 5:10", "2 Timothy 3:16"]
    },
    "rare_books":{
        "text": "Obad1:1 Nah3:19 Zep1:17",    
        "raw": ["Obad 1:1", "Nah 3:19", "Zep 1:17"],    
        "split": ["Obad 1:1", "Nah 3:19", "Zep 1:17"],    
        "exp": ["Obadiah 1:1", "Nahum 3:19", "Zephaniah 1:17"]
    },
    "multi_verse_ranges":{
        "text": "Jn3:16-18 1Co13:4-7",    
        "raw": ["Jn 3:16-18", "1 Co 13:4-7"],    
        "split": ["Jn 3:16-18", "1 Co 13:4-7"],    
        "exp": ["John 3:16-18", "1 Corinthians 13:4-7"]
    },
    "orphan_numbers":{
        "text": "Philippians 1:15-18\n15. Some indeed preach Christ even of envy and strife; and some also of good will:\njohn 2\n1. And I, brethren, when I came to you, 1Co 13 : 4 -7 pRoV3:5 came not with excellency of speech or of wisdom, gets mashed: Ps .23:1 or Ps24:1 or Ps23-24. 1. Prophets declaring unto you the testimony of God Mixed dot formats: Ps.25.1, Ps . 26 . 1, Ps27.1,\nProphets declaring.\n",    
        "raw": ["Philippians 1:15-18", "John 2", "1 Co 13:4-7", "Prov 3:5", "Ps 24:1", "Ps 23-24", "Ps 25:1", "Ps 27:1"],    
        "split": ["Philippians 1:15-18", "John 2", "1 Co 13:4-7", "Prov 3:5", "Ps 24:1", "Ps 23-24", "Ps 25:1", "Ps 27:1"],    
        "exp": ["Philippians 1:15-18", "John 2", "1 Corinthians 13:4-7", "Proverbs 3:5", "Psalms 24:1", "Psalms 23-24", "Psalms 25:1", "Psalms 27:1"]
    },
    "surprise":{
        "text": "Mt5:5. Mk4:2! Lk4:1? mashed: Ps .23:1 or Ps24:1 or Ps23-24.\n1. Prophets mashed Mixed dot formats: Ps.25.1, Ps . 26 . 1, Ps27.1.\nnumbered ",    
        "raw": ["Mt 5:5", "Mk 4:2", "Lk 4:1", "Ps 24:1", "Ps 23-24", "Ps 25:1", "Ps 27:1"],    
        "split": ["Mt 5:5", "Mk 4:2", "Lk 4:1", "Ps 24:1", "Ps 23-24", "Ps 25:1", "Ps 27:1"],    
        "exp": ["Matthew 5:5", "Mark 4:2", "Luke 4:1", "Psalms 24:1", "Psalms 23-24", "Psalms 25:1", "Psalms 27:1"]
    }
}

@pytest.mark.parametrize("name,test", ValidationTests.items())
def test_parse_validation(name, test):
    """
    Pure validation: uses ONLY parse(text)
    and compares parse output directly to expected raw/split/exp.
    """

    text = test["text"]

    expected_raw   = test["raw"]
    expected_split = test["split"]
    expected_exp   = test["exp"]

    # parse(text) returns: (raw, split, expanded)
    raw, split_, expanded = parse(text)

    # -------- RAW --------
    assert raw == expected_raw, (
        f"[{name}] RAW mismatch:\n"
        f"Expected: {expected_raw}\n"
        f"Got:      {raw}"
    )

    # -------- SPLIT --------
    assert split_ == expected_split, (
        f"[{name}] SPLIT mismatch:\n"
        f"Expected: {expected_split}\n"
        f"Got:      {split_}"
    )

    # -------- EXPANDED --------
    assert expanded == expected_exp, (
        f"[{name}] EXP mismatch:\n"
        f"Expected: {expected_exp}\n"
        f"Got:      {expanded}"
    )
