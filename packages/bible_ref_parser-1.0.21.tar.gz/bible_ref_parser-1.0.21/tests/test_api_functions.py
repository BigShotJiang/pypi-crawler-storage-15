import pytest
from bible_ref_parser import parse, expand, split, lookup


def test_parse_basic():
    refs, canon, expanded = parse("jn3:16")

    assert refs == ["Jn 3:16"]
    assert canon == ["Jn 3:16"]
    assert expanded == ["John 3:16"]


def test_expand_basic():
    normalized, expanded = expand("jn3:16")

    assert normalized == ["Jn 3:16"]
    assert expanded == ["John 3:16"]


def test_split_basic():
    result = split("jn3:16")
    assert result == ["jn", "3", "16"]


def test_lookup_lower_case():
    assert lookup("jn") == "John"


def test_lookup_mixed_case():
    assert lookup("1 Jn") == "1 John"


def test_lookup_extra_spaces():
    assert lookup("  ge  ") == "Genesis"


def test_parse_multiple_refs():
    refs, canon, expanded = parse("jn3:16, mk1:2")
    assert refs == ["Jn 3:16", "Mk 1:2"]
    assert expanded == ["John 3:16", "Mark 1:2"]


def test_split_with_space():
    assert split("jn 3:16") == ["jn", "3", "16"]


def test_lookup_not_found():
    assert lookup("xyz") is None     # or "" depending on your logic
