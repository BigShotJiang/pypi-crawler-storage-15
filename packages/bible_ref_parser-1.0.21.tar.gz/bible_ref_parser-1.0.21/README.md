
![Tests](https://github.com/Daniel-Joseph75/bible-ref-parser/actions/workflows/tests.yml/badge.svg)
![PyPI](https://img.shields.io/pypi/v/bible-ref-parser)
![Python versions](https://img.shields.io/pypi/pyversions/bible-ref-parser)
![License](https://img.shields.io/github/license/Daniel-Joseph75/bible-ref-parser)
![Downloads](https://img.shields.io/pypi/dm/bible-ref-parser)

# **bible-ref-parser**

A fast, accurate, fully-tested Bible reference parser for Python.

✔ Parses mashed text
✔ Extracts raw references
✔ Normalizes book/chapter/verse
✔ Expands to full book names
✔ Supports Unicode, punctuation, embedded formats
✔ Includes CLI + test suite
✔ 89% total coverage, 100% on core parse engine

---

## 🚀 Installation

```bash
pip install bible-ref-parser
```

Or install the development version:

```bash
pip install -e .
```

---

## ✨ Features

* Recognizes **all 66 canonical books**
* Handles mashed refs: `Jn3-5beforeMk2:1!`
* Normalizes formats: `"1co 13:4-7"` → `["1 Co 13:4-7"]`
* Expands to full names: `"Jn"` → `"John"`
* CLI tool for quick lookups
* Fully typed, fully tested

---

## 📘 Basic Usage

```python
from bible_ref_parser import parse, expand, split, lookup

print(parse("Jn3:16"))
# (['Jn 3:16'], ['Jn 3:16'], ['John 3:16'])

print(expand("jn3:16"))
# (['Jn 3:16'], ['John 3:16'])

print(split("jn3:16"))
# ['jn', '3', '16']

print(lookup("1 jn"))
# '1 John'
```

---

## 🛠 CLI Usage

```bash
bible-ref-parser "Jn 3:16, Mk1:2"
```

Output:

```
['Jn 3:16', 'Mk 1:2']
['Jn 3:16', 'Mk 1:2']
['John 3:16', 'Mark 1:2']
```

---

## 🧪 Running Tests

```bash
pytest -v
pytest --cov=bible_ref_parser --cov-report=html
```

---

## 📂 Project Structure

```
src/bible_ref_parser/
Tests/
pyproject.toml
```

---

## 📝 License

MIT License — do whatever you want commercially or personally, just keep attribution.

---

## 🤝 Contributing

Pull requests welcome — especially for additional reference formats or localized book sets.

---

# 🚀 **Big thanks for checking out bible-ref-parser!**

Made for researchers, students, pastors, and developers who need *clean*, *fast*, *accurate* Bible reference handling.
