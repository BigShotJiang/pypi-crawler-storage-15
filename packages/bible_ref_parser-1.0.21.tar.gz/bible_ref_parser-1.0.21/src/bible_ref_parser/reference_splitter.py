import re
# 29_Nov_2025
from .bible_abbreviations import BibleAbbreviations
from .clean_text import CleanText

class Reference_Splitter():
    def __init__(self):
        bible_abbr = BibleAbbreviations()
        self.BOOK_MAP = bible_abbr.abbreviation_to_full  # your mapping

        self.BOOK_pattern = re.compile(r"""
            ^\s*
            (?P<book>[1-3]?\s*[A-Za-z]+(?:\s+[A-Za-z]+)*)
            \s*
            (?P<rest>.*)
        """, re.VERBOSE)

        self.colon_pattern = re.compile(r'(\d+:\d+)?')
        self.split_intell = re.compile(r'(?<=\d,)(?=[A-Za-z])')
        self.ISA_pattern = re.compile(r'\d+:\d+(-\d+)?\s?-\s?\d+:\d+')
        self.semicolon_propagation = re.compile(r'(?<=;)\s*(?=\d)')
        self.comma_propagation = re.compile(r'(?<=,)\s*(?=\d+:)')
        self.clean = CleanText()

    def get_Book(self, raw_ref, return_only_book=True):
        # Extract full book name (supports multi-word names)
        m = self.BOOK_pattern.match(raw_ref)
        if not m:
            return None, raw_ref
        if return_only_book:
            return m.group("book")
        return m.group("book"), m.group("rest")

    def expand(self,raw_refs):
        # print('raw_ref', raw_refs)
        split_refs = self.semicolon_chained_references(raw_refs)
        exp_refs=[]
        final_split_refs=[]
        return_only_book=False
        for ref in split_refs:
            book, rest = self.get_Book(ref, return_only_book)
            if book:
                # filter out invalid books
                ful_book = self.BOOK_MAP.get(book.lower(), None)
                if ful_book:
                    final_split_refs.append(self.clean.capitalize_ref(ref))
                    ful_ref = f"{ful_book} {rest}"
                    exp_refs.append(ful_ref)

        return final_split_refs, exp_refs

    def split_intelligently(self, result):
        m = self.split_intell.split(result)
        if m:
            return m
        return result

    def apply_propagation(self, propagation_pattern, raw_ref):
        book = self.get_Book(raw_ref)
        if book:
            result = re.sub(propagation_pattern, f'{book} ', raw_ref)
        return result

    def semicolon_chained_references(self, raw_ref):
        book = self.get_Book(raw_ref)
        if book:
            unchained=[]
            # Apply propagation
            result = self.apply_propagation(self.semicolon_propagation, raw_ref)
            refs = result.split(';')
            for ref in refs:
                unchained.extend(self.comma_chained_references(ref))
            if unchained:
                return unchained
        return raw_ref

    def comma_chained_references(self, raw_ref):
        comma_seperated=[]
        # "Isa 52:13-53:3"
        m = self.ISA_pattern.search(raw_ref)
        if m:
            comma_seperated.extend(self.split_isa_type(raw_ref))
            return comma_seperated
        # Extract full book name
        book = self.get_Book(raw_ref)
        if not book:
            return raw_ref
        # Get the text after the book
        reminder = raw_ref[len(book):].strip()
        # If the first content is chapter:verse
        if self.colon_pattern.match(reminder):
            # Propagate book across comma-chains
            result = [self.apply_propagation(self.comma_propagation, raw_ref)]
            # Split on commas (comma chains)
            if result:
                split_refs=[]
                # if isinstance(result, list):
                for r in result:
                    split_refs.extend(self.split_intelligently(r))
                    for ref in split_refs:
                        comma_seperated.extend(self.expand_verse_list(ref))
                return comma_seperated
            else:
                # print these in case a future ref slips through: unknown case
                print('raw_ref2', raw_ref)
        # print these in case a future ref slips through: unknown case
        print('raw_ref3', raw_ref)
        return raw_ref

    def expand_verse_list(self, raw_ref):
        book = self.get_Book(raw_ref)
        if not book:
            return [raw_ref]
        reminder = raw_ref[len(book):].strip() # Remove book prefix
        m = re.match(r'(\d+)\s*:\s*(.+)', reminder)# Extract chapter and verse-list
        if not m:
            return [raw_ref]
        chapter = m.group(1)
        verse_part = m.group(2)
        # Split at commas
        verses = [v.strip() for v in verse_part.split(',') if v.strip()]
        # Build final references
        return [f"{book} {chapter}:{v}" for v in verses]

    def split_isa_type(self, raw_ref):
        final2=[]
        chunks = [c.strip() for c in raw_ref.split("-")]
        book=""
        for chunk in chunks:
            nbook = self.get_Book(chunk)
            if not isinstance(nbook, tuple):
                book = nbook
                final2.append(chunk)
            else:
                final2.append(f"{book} {chunk}")
        return final2

    def split_reference(self, raw_ref):
        """
        ALWAYS returns one of the following shapes:
            [book, chapter]
            [book, chapter, verse]
            [book, chapter, 'v1-v2']
            [book, chapter, 'v1,v2,v3']
            [book, chapter, 'v1-v2,v4']
        """
        raw_ref = raw_ref.strip()
        # Extract book name
        m = self.BOOK_pattern.match(raw_ref)
        if not m:
            return None
        # split ref
        book = m.group("book").strip()
        rest = m.group("rest").strip()
        # Chapter-only or Chapter-range
        if ":" not in rest:
            # chapter or chapter-range
            return [book, rest]
        # Chapter + verses
        chapter_part, verse_part = rest.split(":", 1)
        chapter = chapter_part.strip()
        verse_block = verse_part.strip()
        # verse_block may contain:
        #   single verse        →  "16"
        #   verse range         →  "16-18"
        #   comma list          →  "16,18,20"
        #   mixed list          →  "16-18,20"
        return [book, chapter, verse_block]
