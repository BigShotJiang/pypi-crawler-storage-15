"""
Public API for bible_ref_parser

This module exposes the simplest interface for developers:

    from bible_ref_parser import parse, expand, split, abbreviation_to_full

- parse() → returns (raw, split, expanded)
- expand() → expand a single reference (e.g., "jn3:16" → "John 3:16")
- split() → return component parts of a reference
- abbreviation_to_full → dict mapping abbreviations to full names
"""

from .reference_parser import Extract_References
from .bible_abbreviations import BibleAbbreviations
from .reference_splitter import Reference_Splitter

er = Extract_References()
ab = BibleAbbreviations()
rs = Reference_Splitter()

def parse(ref):
    return er.parse(ref)

def expand(ref):
    return rs.expand(ref)

def split(ref):
    return rs.split_reference(ref)

def lookup(abbrev):
    return ab.lookup(abbrev)

__all__ = [
    "parse",
    "expand",
    "split",
    "lookup",
]