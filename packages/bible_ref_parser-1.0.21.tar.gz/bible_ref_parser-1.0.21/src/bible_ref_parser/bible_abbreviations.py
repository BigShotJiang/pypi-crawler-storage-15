import json
from importlib.resources import files

class BibleAbbreviations:
    def __init__(self):
        self.abbreviation_to_full = {}
        try:
            path = files("bible_ref_parser.Data") / "abbreviation_to_full.json"
            with path.open("r", encoding="utf-8") as f:
                self.abbreviation_to_full = json.load(f)
        except FileNotFoundError:
            raise RuntimeError(
                "ERROR: abbreviation_to_full.json is missing from package data. "
                "Reinstall bible_ref_parser or check packaging."
            )

    def lookup(self, abbr: str):
        """Return full book name for an abbreviation. Case-insensitive."""
        if not abbr:
            return None
        key = abbr.strip().lower()
        return self.abbreviation_to_full.get(key, None)

