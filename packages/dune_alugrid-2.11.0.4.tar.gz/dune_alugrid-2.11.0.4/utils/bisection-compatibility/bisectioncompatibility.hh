#ifndef ALUGRID_COMPATIBILITY_CHECK_DEPRECATED_HH_INCLUDED
#define ALUGRID_COMPATIBILITY_CHECK_DEPRECATED_HH_INCLUDED
#warning "Deprecated header, #include <dune/alugrid/common/bisectioncompatibility.hh> instead!"
#include <dune/alugrid/common/bisectioncompatibility.hh>
#endif //ALUGRID_COMPATIBILITY_CHECK_HH_INCLUDED
