"""Unit tests for SpecMem."""
