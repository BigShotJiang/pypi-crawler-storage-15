var saveDataUrl = "{% url 'core_curate_save_data' %}";
var curateIndexUrl = "{% url 'core_curate_index' %}";
var publishUrl = "{% url 'core_dashboard_publish_resource_registry' %}";