"""
sqtab package initializer.
"""
