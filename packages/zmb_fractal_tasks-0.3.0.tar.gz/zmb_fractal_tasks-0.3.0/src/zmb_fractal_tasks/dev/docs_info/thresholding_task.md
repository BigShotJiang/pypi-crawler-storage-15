### Purpose
- Description of task functionality: Threshold an image and find connected components.
- Bullet points that cover main features of the tasks.
- Can use **full** *markdown* formatting (including embedding images).

### Outputs
- Optional section on what kind of outputs the task generates. For the thresholding_task: Generates a new label image named `label_name`.

### Limitations
- List known limitations of the task (e.g. only works for certain data types).