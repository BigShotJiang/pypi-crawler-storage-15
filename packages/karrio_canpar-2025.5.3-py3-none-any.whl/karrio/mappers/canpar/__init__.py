from karrio.mappers.canpar.mapper import Mapper
from karrio.mappers.canpar.proxy import Proxy
from karrio.mappers.canpar.settings import Settings
