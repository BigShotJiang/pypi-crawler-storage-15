"""
Polymarket 成交原始事件表，对应 Prisma 模型 PolymarketFill。

存储从 Goldsky/Subgraph 采集的原始成交记录，未必包含市场映射。
"""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Optional, List

from sqlalchemy import (
    BigInteger,
    DateTime,
    String,
    Numeric,
    JSON,
    Index,
    UniqueConstraint,
    Integer,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ..base import Base


class PolymarketFill(Base):
    """
    Polymarket 成交原始事件。

    对应表：polymarket_fills。
    Fields:
        timestamp: 成交时间（ISO）。
        timestamp_unix: 成交时间的 Unix 秒。
        maker/taker: 成交双方地址。
        maker_asset_id/taker_asset_id: 资产 ID（0 代表 USDC）。
        maker_amount/taker_amount: 原始精度下的成交数量。
        transaction_hash: 交易哈希。
        market_id: 映射到的市场 ID（可能为空，待补）。
        raw: 原始 JSON 负载。
    """

    __tablename__ = "polymarket_fills"
    __table_args__ = (
        UniqueConstraint(
            "transaction_hash",
            "maker",
            "taker",
            name="idx_polymarket_fills_tx_maker_taker_unique",
        ),
        Index("polymarket_fills_ts_idx", "timestamp"),
        Index("polymarket_fills_market_idx", "market_id"),
        {"schema": "public"},
    )

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    timestamp: Mapped[Optional[datetime]] = mapped_column(DateTime)
    timestamp_unix: Mapped[Optional[int]] = mapped_column(BigInteger)
    maker: Mapped[str] = mapped_column(String, nullable=False)
    taker: Mapped[str] = mapped_column(String, nullable=False)
    maker_asset_id: Mapped[str] = mapped_column(String, nullable=False)
    taker_asset_id: Mapped[str] = mapped_column(String, nullable=False)
    maker_amount: Mapped[Decimal] = mapped_column(Numeric(30, 0), nullable=False)
    taker_amount: Mapped[Decimal] = mapped_column(Numeric(30, 0), nullable=False)
    transaction_hash: Mapped[str] = mapped_column(String, nullable=False)
    market_id: Mapped[Optional[str]] = mapped_column(String)
    event_id: Mapped[Optional[str]] = mapped_column(String)
    side: Mapped[Optional[str]] = mapped_column(String)
    maker_fee_bps: Mapped[Optional[int]] = mapped_column(Integer)
    taker_fee_bps: Mapped[Optional[int]] = mapped_column(Integer)
    order_id: Mapped[Optional[str]] = mapped_column(String)
    raw: Mapped[dict] = mapped_column(JSON, default=dict, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at: Mapped[Optional[datetime]] = mapped_column(DateTime, onupdate=datetime.utcnow)

    trades: Mapped[List["PolymarketTrade"]] = relationship(
        "PolymarketTrade",
        back_populates="fill",
        lazy="selectin",
    )
