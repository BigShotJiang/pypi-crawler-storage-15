"""
Polymarket 结构化成交表，对应 Prisma 模型 PolymarketTrade。

将原始成交映射到市场、方向与价格，便于钱包/市场分析。
"""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Optional

from sqlalchemy import (
    BigInteger,
    DateTime,
    String,
    Numeric,
    Index,
    UniqueConstraint,
    ForeignKey,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ..base import Base


class PolymarketTrade(Base):
    """
    Polymarket 结构化成交。

    对应表：polymarket_trades。
    Fields:
        timestamp: 成交时间。
        market_id: 对应的市场 ID。
        maker/taker: 成交双方。
        nonusdc_side: 非 USDC 侧的 token（token1/token2）。
        maker_direction/taker_direction: BUY/SELL 标签。
        price/usd_amount/token_amount: 价格与成交额（已归一化）。
        transaction_hash: 交易哈希。
        fill_id: 对应原始 fill 记录。
    """

    __tablename__ = "polymarket_trades"
    __table_args__ = (
        Index("idx_polymarket_trades_market_ts", "market_id", "timestamp"),
        UniqueConstraint(
            "transaction_hash",
            "maker",
            "taker",
            name="idx_polymarket_trades_tx_maker_taker_unique",
        ),
        {"schema": "public"},
    )

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    timestamp: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    market_id: Mapped[Optional[str]] = mapped_column(String)
    event_id: Mapped[Optional[str]] = mapped_column(String)
    maker: Mapped[str] = mapped_column(String, nullable=False)
    taker: Mapped[str] = mapped_column(String, nullable=False)
    nonusdc_side: Mapped[Optional[str]] = mapped_column(String)
    maker_direction: Mapped[Optional[str]] = mapped_column(String)
    taker_direction: Mapped[Optional[str]] = mapped_column(String)
    price: Mapped[Optional[Decimal]] = mapped_column(Numeric(24, 8))
    usd_amount: Mapped[Optional[Decimal]] = mapped_column(Numeric(30, 6))
    token_amount: Mapped[Optional[Decimal]] = mapped_column(Numeric(30, 6))
    transaction_hash: Mapped[str] = mapped_column(String, nullable=False)
    fill_id: Mapped[Optional[int]] = mapped_column(BigInteger, ForeignKey("public.polymarket_fills.id"))
    mid_price_at_fill: Mapped[Optional[Decimal]] = mapped_column(Numeric(24, 8))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at: Mapped[Optional[datetime]] = mapped_column(DateTime, onupdate=datetime.utcnow)

    fill: Mapped[Optional["PolymarketFill"]] = relationship(
        "PolymarketFill",
        back_populates="trades",
        lazy="selectin",
    )
