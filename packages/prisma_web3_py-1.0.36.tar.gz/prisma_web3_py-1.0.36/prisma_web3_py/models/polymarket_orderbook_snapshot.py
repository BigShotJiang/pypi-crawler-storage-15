"""
Polymarket 订单簿快照表，对应 Prisma 模型 PolymarketOrderbookSnapshot。

用于还原钱包入场/离场时的盘口上下文。
"""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Optional

from sqlalchemy import (
    BigInteger,
    DateTime,
    String,
    Numeric,
    JSON,
    Index,
    Integer,
)
from sqlalchemy.orm import Mapped, mapped_column

from ..base import Base


class PolymarketOrderbookSnapshot(Base):
    """
    Polymarket 订单簿快照。

    对应表：polymarket_orderbook_snapshots。
    Fields:
        captured_at: 抓取时间。
        market_id: 关联市场。
        wallet: 触发钱包（可空）。
        side: YES/NO 或 token1/token2。
        best_bid/best_ask/mid_price: 盘口价格。
        bid_liquidity_1pct/ask_liquidity_1pct: ±1% 深度。
        full_orderbook: 原始订单簿 JSON。
    """

    __tablename__ = "polymarket_orderbook_snapshots"
    __table_args__ = (
        Index("idx_polymarket_orderbook_market_ts", "market_id", "captured_at"),
        Index("polymarket_orderbook_wallet_idx", "wallet"),
        {"schema": "public"},
    )

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    captured_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    market_id: Mapped[Optional[str]] = mapped_column(String)
    wallet: Mapped[Optional[str]] = mapped_column(String)
    side: Mapped[Optional[str]] = mapped_column(String)
    best_bid: Mapped[Optional[Decimal]] = mapped_column(Numeric(24, 8))
    best_ask: Mapped[Optional[Decimal]] = mapped_column(Numeric(24, 8))
    mid_price: Mapped[Optional[Decimal]] = mapped_column(Numeric(24, 8))
    bid_liquidity_1pct: Mapped[Optional[Decimal]] = mapped_column(Numeric(30, 6))
    ask_liquidity_1pct: Mapped[Optional[Decimal]] = mapped_column(Numeric(30, 6))
    full_orderbook: Mapped[Optional[dict]] = mapped_column(JSON, default=list)
    bids: Mapped[Optional[dict]] = mapped_column(JSON, default=list)
    asks: Mapped[Optional[dict]] = mapped_column(JSON, default=list)
    spread_ticks: Mapped[Optional[int]] = mapped_column(Integer)
    sequence: Mapped[Optional[int]] = mapped_column(BigInteger)
    last_update: Mapped[Optional[datetime]] = mapped_column(DateTime)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
