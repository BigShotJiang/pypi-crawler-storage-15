"""
Polymarket 钱包特征表，对应 Prisma 模型 PolymarketWalletFeature。

记录钱包会话的入场盘口与行为特征，供分析和告警使用。
"""

from __future__ import annotations

from datetime import datetime
from typing import Optional

from sqlalchemy import BigInteger, DateTime, String, JSON, Index, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ..base import Base


class PolymarketWalletFeature(Base):
    """
    Polymarket 钱包特征。

    对应表：polymarket_wallet_features。
    Fields:
        wallet_session_id: 会话 ID。
        feature_name: 特征名。
        feature_value: 特征值 JSON。
    """

    __tablename__ = "polymarket_wallet_features"
    __table_args__ = (
        Index("polymarket_wallet_features_session_idx", "wallet_session_id"),
        Index("polymarket_wallet_features_name_idx", "feature_name"),
        {"schema": "public"},
    )

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    wallet_session_id: Mapped[int] = mapped_column(
        BigInteger,
        ForeignKey("public.polymarket_wallet_sessions.id"),
        nullable=False,
    )
    feature_name: Mapped[str] = mapped_column(String, nullable=False)
    feature_value: Mapped[Optional[dict]] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)

    session: Mapped["PolymarketWalletSession"] = relationship(
        "PolymarketWalletSession",
        back_populates="features",
        lazy="selectin",
    )
