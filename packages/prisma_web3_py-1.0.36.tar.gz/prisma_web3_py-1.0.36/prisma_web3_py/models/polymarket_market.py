"""
Polymarket 市场表模型，对应 Prisma 模型 PolymarketMarket。

此模型存储 Polymarket 市场的基础元数据，便于成交映射与后续分析。
"""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Optional

from sqlalchemy import DateTime, String, Boolean, Numeric, Index, JSON
from sqlalchemy.orm import Mapped, mapped_column

from ..base import Base


class PolymarketMarket(Base):
    """
    Polymarket 市场基础信息。

    对应表：polymarket_markets。
    Fields:
        id: Polymarket 市场唯一 ID。
        slug: 市场 slug。
        question: 市场问题文本。
        answer1/answer2: 选项文本。
        token1/token2: outcome token ID。
        neg_risk: 是否负风险市场。
        market_created_at/market_closed_at: 市场创建/关闭时间。
        ticker: 事件短代码。
        last_volume: 最新成交量（USDC）。
        ingested_at/updated_at: 采集与更新时间戳。
    """

    __tablename__ = "polymarket_markets"
    __table_args__ = (
        Index("polymarket_markets_slug_idx", "slug"),
        Index("polymarket_markets_ticker_idx", "ticker"),
        Index("polymarket_markets_created_idx", "market_created_at"),
        {"schema": "public"},
    )

    id: Mapped[str] = mapped_column(String, primary_key=True)
    slug: Mapped[Optional[str]] = mapped_column(String)
    question: Mapped[Optional[str]] = mapped_column(String)
    answer1: Mapped[Optional[str]] = mapped_column(String)
    answer2: Mapped[Optional[str]] = mapped_column(String)
    token1: Mapped[Optional[str]] = mapped_column(String)
    token2: Mapped[Optional[str]] = mapped_column(String)
    neg_risk: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    market_created_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    market_closed_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    ticker: Mapped[Optional[str]] = mapped_column(String)
    last_volume: Mapped[Optional[Decimal]] = mapped_column(Numeric(30, 10))
    condition_id: Mapped[Optional[str]] = mapped_column(String)
    event_id: Mapped[Optional[str]] = mapped_column(String)
    outcomes: Mapped[Optional[dict]] = mapped_column(JSON, default=list)
    clob_token_ids: Mapped[Optional[dict]] = mapped_column(JSON, default=list)
    status: Mapped[Optional[str]] = mapped_column(String)
    open_interest: Mapped[Optional[Decimal]] = mapped_column(Numeric(30, 10))
    volume_24h: Mapped[Optional[Decimal]] = mapped_column(Numeric(30, 10))
    last_trade_price: Mapped[Optional[Decimal]] = mapped_column(Numeric(24, 8))
    last_trade_time: Mapped[Optional[datetime]] = mapped_column(DateTime)
    ingested_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, onupdate=datetime.utcnow, nullable=True)
