"""
Polymarket 采集检查点表，对应 Prisma 模型 PolymarketCheckpoint。

用于记录各数据源的游标，保证增量拉取幂等。
"""

from __future__ import annotations

from datetime import datetime
from typing import Optional

from sqlalchemy import Integer, String, DateTime, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from ..base import Base


class PolymarketCheckpoint(Base):
    """
    Polymarket 数据采集检查点。

    对应表：polymarket_checkpoints。
    Fields:
        source: 数据源标识。
        cursor_type: 游标类型（offset/timestamp/tx_hash 等）。
        cursor_value: 游标值。
        updated_at: 更新时间。
    """

    __tablename__ = "polymarket_checkpoints"
    __table_args__ = (
        UniqueConstraint(
            "source",
            "cursor_type",
            name="idx_polymarket_checkpoints_source_type_unique",
        ),
        {"schema": "public"},
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    source: Mapped[str] = mapped_column(String, nullable=False)
    cursor_type: Mapped[str] = mapped_column(String, nullable=False)
    cursor_value: Mapped[str] = mapped_column(String, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
