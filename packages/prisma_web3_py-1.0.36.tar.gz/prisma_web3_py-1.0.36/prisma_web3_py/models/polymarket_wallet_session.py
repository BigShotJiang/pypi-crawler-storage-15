"""
Polymarket 钱包会话表，对应 Prisma 模型 PolymarketWalletSession。

按钱包在单市场的 Entry→Exit 回合聚合，用于胜率与 PnL 复盘。
"""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Optional, List

from sqlalchemy import (
    BigInteger,
    DateTime,
    String,
    Numeric,
    Integer,
    JSON,
    Index,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ..base import Base


class PolymarketWalletSession(Base):
    """
    Polymarket 钱包会话。

    对应表：polymarket_wallet_sessions。
    Fields:
        wallet: 钱包地址。
        market_id: 市场 ID。
        direction: Long YES/NO 等方向标签。
        entry_time/exit_time: 进出场时间。
        entry_price/exit_price: 进出场均价。
        size_usd: 最大/主要持仓规模（美元）。
        realized_pnl: 已实现盈亏。
        max_drawdown/max_favorable_excursion: 回撤与 MFE。
        num_trades: 回合内成交次数。
        tags: 行为标签。
    """

    __tablename__ = "polymarket_wallet_sessions"
    __table_args__ = (
        Index(
            "idx_polymarket_wallet_sessions_wallet_market",
            "wallet",
            "market_id",
            "entry_time",
        ),
        {"schema": "public"},
    )

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    wallet: Mapped[str] = mapped_column(String, nullable=False)
    market_id: Mapped[Optional[str]] = mapped_column(String)
    direction: Mapped[Optional[str]] = mapped_column(String)
    entry_time: Mapped[Optional[datetime]] = mapped_column(DateTime)
    exit_time: Mapped[Optional[datetime]] = mapped_column(DateTime)
    entry_price: Mapped[Optional[Decimal]] = mapped_column(Numeric(24, 8))
    exit_price: Mapped[Optional[Decimal]] = mapped_column(Numeric(24, 8))
    size_usd: Mapped[Optional[Decimal]] = mapped_column(Numeric(30, 6))
    realized_pnl: Mapped[Optional[Decimal]] = mapped_column(Numeric(30, 6))
    max_drawdown: Mapped[Optional[Decimal]] = mapped_column(Numeric(10, 4))
    max_favorable_excursion: Mapped[Optional[Decimal]] = mapped_column(Numeric(10, 4))
    num_trades: Mapped[Optional[int]] = mapped_column(Integer)
    tags: Mapped[Optional[dict]] = mapped_column(JSON, default=list)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at: Mapped[Optional[datetime]] = mapped_column(DateTime, onupdate=datetime.utcnow)

    features: Mapped[List["PolymarketWalletFeature"]] = relationship(
        "PolymarketWalletFeature",
        back_populates="session",
        lazy="selectin",
    )
