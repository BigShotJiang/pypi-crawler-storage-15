Contributing
============
Contributions to smftools are not currently being reviewed or accepted due to the pre-alpha phase status of the project. More mature versions of the project will have contribution guidelines added.
