## Datasets:

```{eval-rst}
.. module:: smftools.datasets
```

```{eval-rst}
.. currentmodule:: smftools
```