(release-notes)=

# Release notes

## Version 0.1.0

```{include} /release-notes/0.1.0.md
```