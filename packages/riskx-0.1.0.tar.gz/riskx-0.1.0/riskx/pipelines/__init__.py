"""RiskX Pipelines"""

from riskx.pipelines.risk_pipeline import RiskPipeline

__all__ = ["RiskPipeline"]
