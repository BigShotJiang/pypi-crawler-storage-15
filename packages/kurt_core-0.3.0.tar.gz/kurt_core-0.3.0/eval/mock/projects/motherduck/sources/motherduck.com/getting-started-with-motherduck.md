---
title: getting-started-with-motherduck
content_type: event
source_url: https://motherduck.com/getting-started-with-motherduck
indexed_at: '2025-11-25T20:36:55.713062'
content_hash: eca528b7b79fabc6
---

Hands-on Lab: Agentic Data Engineering with MotherDuck and Ascend[December 3, 10am PT / 1pm ET](https://www.ascend.io/events/hands-on-lab-agentic-data-engineering-with-motherduck)

[Motherduck home](https://motherduck.com/)

[START FREE](https://app.motherduck.com/?auth_flow=signup)

# Product Demo: Getting Started with MotherDuck

## Join us for a live demo to learn how to get started with MotherDuck, the cloud SQL analytics data warehouse extending DuckDB to the cloud.

MotherDuck is now Generally Available! In this session, MotherDuck Co-Founder Ryan Boyd and Product Expert Nathaniel Thompson will show you how to maximize MotherDuck's analytics and collaboration features to take flight with your analytics workloads and applications.

### Tuesday, June 18th @ 10AM PDT

Register now. We're looking forward to seeing you there!

![Getting Started with MotherDuck](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.amazonaws.com%2Fassets%2Fimg%2FGetting_Started_with_MD_437c0d3476.png&w=3840&q=75)

Getting Started with MotherDuck

## Getting Started with MotherDuck

Email address \*

Next

Already registered?Join here

Authorization Response