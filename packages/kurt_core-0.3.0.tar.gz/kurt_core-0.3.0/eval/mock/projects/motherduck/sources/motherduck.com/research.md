---
title: research
content_type: event
source_url: https://motherduck.com/research
indexed_at: '2025-11-25T20:36:56.923885'
content_hash: fcf8ef12902c7ab7
---

Hands-on Lab: Agentic Data Engineering with MotherDuck and Ascend[December 3, 10am PT / 1pm ET](https://www.ascend.io/events/hands-on-lab-agentic-data-engineering-with-motherduck)

[Motherduck home](https://motherduck.com/)

[START FREE](https://app.motherduck.com/?auth_flow=signup)

#### WE´RE SORRY, SOMETHING WENT WRONG

[back to home](https://motherduck.com/)

Authorization Response