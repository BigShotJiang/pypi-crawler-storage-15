---
title: diptanu-gon-choudhury
content_type: event
source_url: https://motherduck.com/authors/diptanu-gon-choudhury
indexed_at: '2025-11-25T20:38:11.136068'
content_hash: 80801a9ec9ff0496
---

Hands-on Lab: Agentic Data Engineering with MotherDuck and Ascend[December 3, 10am PT / 1pm ET](https://www.ascend.io/events/hands-on-lab-agentic-data-engineering-with-motherduck)

[Motherduck home](https://motherduck.com/)

[START FREE](https://app.motherduck.com/?auth_flow=signup)

# Diptanu Gon Choudhury

![Diptanu Gon Choudhury's photo](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.us-east-1.amazonaws.com%2Fassets%2Fimg%2Fdiptanu_355005427c.jpeg&w=3840&q=75)

# Diptanu Gon Choudhury

Founder & CEO of Tensorlake

Diptanu is the founder and CEO of Tensorlake, the AI data cloud that reliably transforms data from unstructured sources into ingestion-ready formats for AI applications. Previously, Diptanu held senior engineering roles at the intersection of distributed systems and AI/ML.

## 1 POST

[![Unstructured Document Analysis with Tensorlake and MotherDuck](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.us-east-1.amazonaws.com%2Fassets%2Fimg%2Ftensorlake_15913398e1.png&w=3840&q=75)](https://motherduck.com/blog/unstructured-analysis-tensorlake-motherduck/)

[2025/11/19 - Diptanu Gon Choudhury](https://motherduck.com/blog/unstructured-analysis-tensorlake-motherduck/)

### [Unstructured Document Analysis with Tensorlake and MotherDuck](https://motherduck.com/blog/unstructured-analysis-tensorlake-motherduck)

Learn how to query unstructured documents with friendly SQL!

[SEE ALL BLOG POSTS](https://motherduck.com/blog/)

## SUBSCRIBE

### Subscribe to MotherDuck Blog

E-mail

Also subscribe to other MotherDuck updates

Submit

Authorization Response