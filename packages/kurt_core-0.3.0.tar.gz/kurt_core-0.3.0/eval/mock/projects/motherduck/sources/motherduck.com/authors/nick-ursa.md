---
title: nick-ursa
content_type: event
source_url: https://motherduck.com/authors/nick-ursa
indexed_at: '2025-11-25T20:43:43.701879'
content_hash: 27f00033744e6b51
---

Hands-on Lab: Agentic Data Engineering with MotherDuck and Ascend[December 3, 10am PT / 1pm ET](https://www.ascend.io/events/hands-on-lab-agentic-data-engineering-with-motherduck)

[Motherduck home](https://motherduck.com/)

[START FREE](https://app.motherduck.com/?auth_flow=signup)

# Nick Ursa

![Nick Ursa's photo](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.amazonaws.com%2Fassets%2Fimg%2F3_J4_A0727_26e95d356f.png&w=3840&q=75)

# Nick Ursa

Software Engineer

Nick joins us from Better where he built the data platform. Previously he was building the NY Times data warehouse as the tech lead.

## 0POSTS

[SEE ALL BLOG POSTS](https://motherduck.com/blog/)

## SUBSCRIBE

### Subscribe to MotherDuck Blog

E-mail

Also subscribe to other MotherDuck updates

Submit

Authorization Response