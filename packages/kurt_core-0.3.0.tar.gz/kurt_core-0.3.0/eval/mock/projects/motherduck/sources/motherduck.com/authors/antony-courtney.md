---
title: antony-courtney
content_type: event
source_url: https://motherduck.com/authors/antony-courtney
indexed_at: '2025-11-25T20:38:33.472772'
content_hash: 95e74f82f6d5b25f
---

Hands-on Lab: Agentic Data Engineering with MotherDuck and Ascend[December 3, 10am PT / 1pm ET](https://www.ascend.io/events/hands-on-lab-agentic-data-engineering-with-motherduck)

[Motherduck home](https://motherduck.com/)

[START FREE](https://app.motherduck.com/?auth_flow=signup)

# Antony Courtney

![Antony Courtney's photo](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.amazonaws.com%2Fassets%2Fimg%2F3_J4_A0681_ab6ebc0e3d.png&w=3840&q=75)

# Antony Courtney

Founding Engineer

Antony joins us from Snowflake where he was a Principal Engineer on their Web UI. Previously he was an Eng Manager in Languages and Runtimes at Facebook and a Core Strat at Goldman Sachs. Antony created and maintains Tad, an OSS data exploration tool.

## 0POSTS

[SEE ALL BLOG POSTS](https://motherduck.com/blog/)

## SUBSCRIBE

### Subscribe to MotherDuck Blog

E-mail

Also subscribe to other MotherDuck updates

Submit

Authorization Response