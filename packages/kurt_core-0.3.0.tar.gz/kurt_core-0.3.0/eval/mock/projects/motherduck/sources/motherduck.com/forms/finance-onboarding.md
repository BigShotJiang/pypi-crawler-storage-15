---
title: MotherDuck Finance Onboarding
content_type: event
description: Making analytics ducking awesome with DuckDB. Start using DuckDB in the
  cloud for free today.
published_date: '2025-05-06T00:00:00'
source_url: https://motherduck.com/forms/finance-onboarding
indexed_at: '2025-11-25T20:36:53.289564'
content_hash: 20a4ce6493d2278a
---

Hands-on Lab: Agentic Data Engineering with MotherDuck and Ascend
December 3, 10am PT / 1pm ET
PRODUCT
COMMUNITY
COMPANY
DOCS
PRICING
CONTACT US
LOG IN
START FREE
PRODUCT
Overview
Data Warehousing and BI
Customer-facing Analytics
For DuckDB Users
Postgres Integration
Case Studies
Ecosystem
Startups
Support
Trust & Security
COMMUNITY
Blog
Slack
Events
YouTube
Small Data SF
Community and OSS
Videos & Streams
DuckDB News
DuckDB Snippets
Free DuckDB Book
Learn
COMPANY
About Us
Careers
Quacking
DOCS
PRICING
CONTACT US
LOG IN
START FREE
MotherDuck Finance Onboarding