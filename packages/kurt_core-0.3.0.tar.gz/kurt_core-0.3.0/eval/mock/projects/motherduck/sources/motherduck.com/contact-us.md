---
title: contact-us
content_type: event
source_url: https://motherduck.com/contact-us/
indexed_at: '2025-11-25T20:45:11.771333'
content_hash: 8cd2893c70bddd1a
---

Hands-on Lab: Agentic Data Engineering with MotherDuck and Ascend[December 3, 10am PT / 1pm ET](https://www.ascend.io/events/hands-on-lab-agentic-data-engineering-with-motherduck)

[Motherduck home](https://motherduck.com/)

[START FREE](https://app.motherduck.com/?auth_flow=signup)

# Get in Touch

Let us know how we can help you take flight with MotherDuck.

[Contact Sales\\
\\
Meet with our team to learn more about MotherDuck](https://motherduck.com/contact-us/product-expert/)

[Contact Support\\
\\
For assistance and troubleshooting from our technical experts](https://motherduck.com/contact-us/support/)

For employment verification, reach out to [people@motherduck.com](mailto:people@motherduck.com)

Authorization Response