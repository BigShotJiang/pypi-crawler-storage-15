---
title: bytewax
content_type: event
source_url: https://motherduck.com/ecosystem/bytewax
indexed_at: '2025-11-25T20:38:00.324273'
content_hash: 38864b2c5f0d4ada
---

Hands-on Lab: Agentic Data Engineering with MotherDuck and Ascend[December 3, 10am PT / 1pm ET](https://www.ascend.io/events/hands-on-lab-agentic-data-engineering-with-motherduck)

[Motherduck home](https://motherduck.com/)

[START FREE](https://app.motherduck.com/?auth_flow=signup)

[BACK TO ECOSYSTEM](https://motherduck.com/ecosystem/)

# Bytewax

INGESTION

TRANSFORMATION

Open source framework and distributed stream processing engine. Build streaming data pipelines and real-time apps with everything you need: recovery, scalability, windowing, aggregations, and connectors.

Blog

Video

![Bytewax's logo](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.amazonaws.com%2Fassets%2Fimg%2Fbytewax_logo_white_background_transparent_f79067dd97.png&w=3840&q=75)

Authorization Response