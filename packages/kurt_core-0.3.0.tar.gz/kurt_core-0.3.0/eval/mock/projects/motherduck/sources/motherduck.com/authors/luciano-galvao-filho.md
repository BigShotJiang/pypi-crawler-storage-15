---
title: luciano-galvao-filho
content_type: event
source_url: https://motherduck.com/authors/luciano-galvao-filho
indexed_at: '2025-11-25T20:43:27.622207'
content_hash: eae74b94ba8f5352
has_narrative: true
---

Hands-on Lab: Agentic Data Engineering with MotherDuck and Ascend[December 3, 10am PT / 1pm ET](https://www.ascend.io/events/hands-on-lab-agentic-data-engineering-with-motherduck)

[Motherduck home](https://motherduck.com/)

[START FREE](https://app.motherduck.com/?auth_flow=signup)

# Luciano Galvão Filho

![Luciano Galvão Filho's photo](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.amazonaws.com%2Fassets%2Fimg%2FLuciano_Galvao_Filho_6b39bbf214.jpeg&w=3840&q=75)

# Luciano Galvão Filho

I'm Luciano and I started my career in industry and agribusiness in Brazil. Recently, I've been focusing on marketing and e-commerce, working as a data engineer at companies like C&A, Flywheel Digital, and Coca-Cola. This year, I took a big step by launching my own consulting and development business, which has been super exciting. I also share my knowledge in a light and humorous way online, making it a really great experience. My son is my greatest motivation.

## 1 POST

[![This Month in the DuckDB Ecosystem: April 2024](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.amazonaws.com%2Fassets%2Fimg%2Fapril_2024_fe841dae08.jpg&w=3840&q=75)](https://motherduck.com/blog/duckdb-ecosystem-newsletter-april-2024/)

[2024/04/30 - Luciano Galvão Filho](https://motherduck.com/blog/duckdb-ecosystem-newsletter-april-2024/)

### [This Month in the DuckDB Ecosystem: April 2024](https://motherduck.com/blog/duckdb-ecosystem-newsletter-april-2024)

DuckDB Monthly: Dr. Qiusheng Wu, CSVs, 1 Billion Row challenge, duckplyr, and more

[SEE ALL BLOG POSTS](https://motherduck.com/blog/)

## SUBSCRIBE

### Subscribe to MotherDuck Blog

E-mail

Also subscribe to other MotherDuck updates

Submit

Authorization Response