---
title: support
content_type: event
source_url: https://motherduck.com/contact-us/support/
indexed_at: '2025-11-25T20:45:10.550374'
content_hash: 8bfe0706930f927a
---

Hands-on Lab: Agentic Data Engineering with MotherDuck and Ascend[December 3, 10am PT / 1pm ET](https://www.ascend.io/events/hands-on-lab-agentic-data-engineering-with-motherduck)

[Motherduck home](https://motherduck.com/)

[START FREE](https://app.motherduck.com/?auth_flow=signup)

# Contact Support

![Duck illustration](https://motherduck.com/_next/image/?url=%2F_next%2Fstatic%2Fmedia%2Fcontact-us-support.3bc3cb93.png&w=3840&q=75)

First Name

Last Name

E-mail

Company

Leave us a message.

This site is protected by reCAPTCHA and the Google [Privacy Policy](https://policies.google.com/privacy) and [Terms of Service](https://policies.google.com/terms) apply.

Submit

## Need help? You're in the right place

Send us a note and a Product Expert will fly right back to you with resources to help you take flight.

We're here to help you get the most out of MotherDuck and would love to learn more about what you're building.

Before reaching out, you may want to check out these helpful resources:

[Support Overview](https://motherduck.com/customer-support/)

[Support Policy](https://motherduck.com/support-policy/)

[Status Page](https://status.motherduck.com/posts/dashboard)

reCAPTCHA

Recaptcha requires verification.

[Privacy](https://www.google.com/intl/en/policies/privacy/) \- [Terms](https://www.google.com/intl/en/policies/terms/)

protected by **reCAPTCHA**

[Privacy](https://www.google.com/intl/en/policies/privacy/) \- [Terms](https://www.google.com/intl/en/policies/terms/)

Authorization Response