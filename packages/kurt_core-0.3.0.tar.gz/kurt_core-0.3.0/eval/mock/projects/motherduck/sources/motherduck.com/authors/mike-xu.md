---
title: mike-xu
content_type: event
source_url: https://motherduck.com/authors/mike-xu
indexed_at: '2025-11-25T20:38:33.329410'
content_hash: faac71769edf7ba4
---

Hands-on Lab: Agentic Data Engineering with MotherDuck and Ascend[December 3, 10am PT / 1pm ET](https://www.ascend.io/events/hands-on-lab-agentic-data-engineering-with-motherduck)

[Motherduck home](https://motherduck.com/)

[START FREE](https://app.motherduck.com/?auth_flow=signup)

# Mike Xu

![Mike Xu's photo](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.amazonaws.com%2Fassets%2Fimg%2FASA_00124_2_07dcb8975c.png&w=3840&q=75)

# Mike Xu

Solutions Architect

Mike joins MotherDuck from Looker where he was the first member of the Go to Market team. He is a member of the Solutions team at MotherDuck helping customers get the most value from our platform.

## 0POSTS

[SEE ALL BLOG POSTS](https://motherduck.com/blog/)

## SUBSCRIBE

### Subscribe to MotherDuck Blog

E-mail

Also subscribe to other MotherDuck updates

Submit

Authorization Response