---
title: terms-of-service-app
content_type: event
source_url: https://motherduck.com/terms-of-service-app/
indexed_at: '2025-11-25T20:45:03.155473'
content_hash: 9ce9d9fd860dc301
---

Hands-on Lab: Agentic Data Engineering with MotherDuck and Ascend[December 3, 10am PT / 1pm ET](https://www.ascend.io/events/hands-on-lab-agentic-data-engineering-with-motherduck)

# 404

## This page could not be found.