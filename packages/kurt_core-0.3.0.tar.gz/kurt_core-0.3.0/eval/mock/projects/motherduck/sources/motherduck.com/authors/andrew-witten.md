---
title: andrew-witten
content_type: event
source_url: https://motherduck.com/authors/andrew-witten
indexed_at: '2025-11-25T20:43:28.811771'
content_hash: ab306ddff5934b05
---

Hands-on Lab: Agentic Data Engineering with MotherDuck and Ascend[December 3, 10am PT / 1pm ET](https://www.ascend.io/events/hands-on-lab-agentic-data-engineering-with-motherduck)

[Motherduck home](https://motherduck.com/)

[START FREE](https://app.motherduck.com/?auth_flow=signup)

# Andrew Witten

# Andrew Witten

Software Engineer @ MotherDuck

## 1 POST

[![Using MotherDuck at MotherDuck: Loading Data from Postgres with DuckDB](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.amazonaws.com%2Fassets%2Fimg%2Fsocial_md_at_md_8925335f69.png&w=3840&q=75)](https://motherduck.com/blog/pg%20to%20motherduck%20at%20motherduck/)

[2025/03/07 - Jacob Matson, Andrew Witten](https://motherduck.com/blog/pg%20to%20motherduck%20at%20motherduck/)

### [Using MotherDuck at MotherDuck: Loading Data from Postgres with DuckDB](https://motherduck.com/blog/pg%20to%20motherduck%20at%20motherduck)

Duckfooding MotherDuck with the postgres scanner

[SEE ALL BLOG POSTS](https://motherduck.com/blog/)

## SUBSCRIBE

### Subscribe to MotherDuck Blog

E-mail

Also subscribe to other MotherDuck updates

Submit

Authorization Response