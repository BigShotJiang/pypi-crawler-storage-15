---
title: leslie-thomas
content_type: event
source_url: https://motherduck.com/authors/leslie-thomas
indexed_at: '2025-11-25T20:43:18.769454'
content_hash: 87d927b771c86514
---

Hands-on Lab: Agentic Data Engineering with MotherDuck and Ascend[December 3, 10am PT / 1pm ET](https://www.ascend.io/events/hands-on-lab-agentic-data-engineering-with-motherduck)

[Motherduck home](https://motherduck.com/)

[START FREE](https://app.motherduck.com/?auth_flow=signup)

# Leslie Thomas

![Leslie Thomas's photo](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.amazonaws.com%2Fassets%2Fimg%2Fleslie_c59a1d6e32.png&w=3840&q=75)

# Leslie Thomas

Head of People

Leslie joins us from Meta where she was a Director of Recruiting. She has spent the better part of the last two decades supporting the people function, previously at Amazon, Under Armour, and startups MyFitnessPal and imo.im

## 1 POST

[![MotherDuck's HQ Nest is Ready for the Flock](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.amazonaws.com%2Fassets%2Fimg%2Fseattle_hq_eefbad0f4b.png&w=3840&q=75)](https://motherduck.com/blog/motherduck-headquarters-seattle-opening/)

[2023/12/05 - Leslie Thomas](https://motherduck.com/blog/motherduck-headquarters-seattle-opening/)

### [MotherDuck's HQ Nest is Ready for the Flock](https://motherduck.com/blog/motherduck-headquarters-seattle-opening)

MotherDuck's Seattle office opened as one of four company hubs, which also includes San Francisco, NYC and Amsterdam

[SEE ALL BLOG POSTS](https://motherduck.com/blog/)

## SUBSCRIBE

### Subscribe to MotherDuck Blog

E-mail

Also subscribe to other MotherDuck updates

Submit

Authorization Response