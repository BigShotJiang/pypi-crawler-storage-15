---
title: pranav-aurora
content_type: event
source_url: https://motherduck.com/authors/pranav-aurora
indexed_at: '2025-11-25T20:43:16.146893'
content_hash: 91b976ecb0993c7d
---

Hands-on Lab: Agentic Data Engineering with MotherDuck and Ascend[December 3, 10am PT / 1pm ET](https://www.ascend.io/events/hands-on-lab-agentic-data-engineering-with-motherduck)

[Motherduck home](https://motherduck.com/)

[START FREE](https://app.motherduck.com/?auth_flow=signup)

# Pranav Aurora

![Pranav Aurora's photo](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.amazonaws.com%2Fassets%2Fimg%2FScreenshot_2024_10_29_at_2_43_03_PM_3d3d40c3dd.png&w=3840&q=75)

# Pranav Aurora

Guest Author

Pranav is a co-founder at mooncake after having been a product manager at SingleStore and Microsoft.

## 1 POST

[![pg_mooncake: Columnstore Tables with DuckDB Execution in Postgres](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.amazonaws.com%2Fassets%2Fimg%2Fpg_mooncake_a23d8f2192.png&w=3840&q=75)](https://motherduck.com/blog/pg-mooncake-columnstore/)

[2024/10/30 - Pranav Aurora](https://motherduck.com/blog/pg-mooncake-columnstore/)

### [pg\_mooncake: Columnstore Tables with DuckDB Execution in Postgres](https://motherduck.com/blog/pg-mooncake-columnstore)

New pg\_mooncake provides columnstore tables in Postgres to enable faster analytics

[SEE ALL BLOG POSTS](https://motherduck.com/blog/)

## SUBSCRIBE

### Subscribe to MotherDuck Blog

E-mail

Also subscribe to other MotherDuck updates

Submit

Authorization Response