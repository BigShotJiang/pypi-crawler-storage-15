---
title: paradime-hackathon
content_type: event
source_url: https://motherduck.com/events/paradime-hackathon
indexed_at: '2025-11-25T20:36:52.399339'
content_hash: 1de08beb488345d4
---

Hands-on Lab: Agentic Data Engineering with MotherDuck and Ascend[December 3, 10am PT / 1pm ET](https://www.ascend.io/events/hands-on-lab-agentic-data-engineering-with-motherduck)

[Motherduck home](https://motherduck.com/)

[START FREE](https://app.motherduck.com/?auth_flow=signup)

# Welcome, Hacker!

![Post asset](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.amazonaws.com%2Fassets%2Fimg%2Fparadime_logo_494c5d21dd.png&w=3840&q=75)

Thanks for joining us for this hackathon! We're excited to you have here.

Let's get you signed up for a MotherDuck account.

Redirecting you now to [app.motherduck.com](https://app.motherduck.com/?auth_flow=signup)

Authorization Response