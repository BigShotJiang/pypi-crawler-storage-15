---
title: jessica-libman
content_type: event
source_url: https://motherduck.com/authors/jessica-libman
indexed_at: '2025-11-25T20:38:32.320167'
content_hash: 5e01d0306c2ad752
---

Hands-on Lab: Agentic Data Engineering with MotherDuck and Ascend[December 3, 10am PT / 1pm ET](https://www.ascend.io/events/hands-on-lab-agentic-data-engineering-with-motherduck)

[Motherduck home](https://motherduck.com/)

[START FREE](https://app.motherduck.com/?auth_flow=signup)

# Jessica Libman

![Jessica Libman's photo](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.amazonaws.com%2Fassets%2Fimg%2FJessica_L_abb1158f8d.png&w=3840&q=75)

# Jessica Libman

Software Engineer

Jessica joins us from Flock Freight, where she was responsible for the quoting and ordering experiences. She has also led engineering teams and managed frontend infrastructure modernization projects.

## 0POSTS

[SEE ALL BLOG POSTS](https://motherduck.com/blog/)

## SUBSCRIBE

### Subscribe to MotherDuck Blog

E-mail

Also subscribe to other MotherDuck updates

Submit

Authorization Response