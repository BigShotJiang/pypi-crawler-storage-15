---
title: daniel-palma
content_type: event
source_url: https://motherduck.com/authors/daniel-palma
indexed_at: '2025-11-25T20:43:36.776110'
content_hash: 7fd9f9241cc7a10b
---

Hands-on Lab: Agentic Data Engineering with MotherDuck and Ascend[December 3, 10am PT / 1pm ET](https://www.ascend.io/events/hands-on-lab-agentic-data-engineering-with-motherduck)

[Motherduck home](https://motherduck.com/)

[START FREE](https://app.motherduck.com/?auth_flow=signup)

# Daniel Palma

![Daniel Palma's photo](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.amazonaws.com%2Fassets%2Fimg%2Fdaniel_49dba8f996.jpeg&w=3840&q=75)

# Daniel Palma

Data Engineer & Marketer

I do data engineering.

## 1 POST

[![DuckDB, MotherDuck, and Estuary: A Match Made for Your Analytics Architecture](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.amazonaws.com%2Fassets%2Fimg%2FEstuary_blog_4b9b0c4ce0.png&w=3840&q=75)](https://motherduck.com/blog/estuary-streaming-cdc-replication/)

[2025/03/06 - Daniel Palma, Emily Lucek](https://motherduck.com/blog/estuary-streaming-cdc-replication/)

### [DuckDB, MotherDuck, and Estuary: A Match Made for Your Analytics Architecture](https://motherduck.com/blog/estuary-streaming-cdc-replication)

Stream data to MotherDuck with Estuary

[SEE ALL BLOG POSTS](https://motherduck.com/blog/)

## SUBSCRIBE

### Subscribe to MotherDuck Blog

E-mail

Also subscribe to other MotherDuck updates

Submit

Authorization Response