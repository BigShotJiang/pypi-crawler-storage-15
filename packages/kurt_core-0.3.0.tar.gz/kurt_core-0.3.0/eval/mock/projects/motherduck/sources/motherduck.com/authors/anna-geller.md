---
title: anna-geller
content_type: event
source_url: https://motherduck.com/authors/anna-geller
indexed_at: '2025-11-25T20:38:26.391552'
content_hash: 8f81a3a1fa44d20b
---

Hands-on Lab: Agentic Data Engineering with MotherDuck and Ascend[December 3, 10am PT / 1pm ET](https://www.ascend.io/events/hands-on-lab-agentic-data-engineering-with-motherduck)

[Motherduck home](https://motherduck.com/)

[START FREE](https://app.motherduck.com/?auth_flow=signup)

# Anna Geller

![Anna Geller's photo](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.amazonaws.com%2Fassets%2Fimg%2Fanna_geller_2_d652f34aa7.jpeg&w=3840&q=75)

# Anna Geller

Guest Author

Anna Geller is a Data Professional, DevRel & Technical Writer with past experience as a Data Engineering consultant. She’s currently working as a Head of Developer Relations at Kestra. She loves writing on her Medium blog and sharing memes on social media.

## 1 POST

[![Beyond Storing Data: How to Use DuckDB, MotherDuck and Kestra for ETL](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.amazonaws.com%2Fassets%2Fimg%2Fimage4_12840cc4ae.png&w=3840&q=75)](https://motherduck.com/blog/motherduck-kestra-etl-pipelines/)

[2023/08/18 - Anna Geller](https://motherduck.com/blog/motherduck-kestra-etl-pipelines/)

### [Beyond Storing Data: How to Use DuckDB, MotherDuck and Kestra for ETL](https://motherduck.com/blog/motherduck-kestra-etl-pipelines)

Scheduled and event-driven data workflows with S3, MotherDuck, DuckDB and Kestra

[SEE ALL BLOG POSTS](https://motherduck.com/blog/)

## SUBSCRIBE

### Subscribe to MotherDuck Blog

E-mail

Also subscribe to other MotherDuck updates

Submit

Authorization Response