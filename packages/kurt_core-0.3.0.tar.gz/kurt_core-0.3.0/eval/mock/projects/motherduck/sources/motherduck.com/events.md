---
title: events
content_type: event
source_url: https://motherduck.com/events
indexed_at: '2025-11-25T20:45:11.911130'
content_hash: 388e746a02007e70
---

Hands-on Lab: Agentic Data Engineering with MotherDuck and Ascend[December 3, 10am PT / 1pm ET](https://www.ascend.io/events/hands-on-lab-agentic-data-engineering-with-motherduck)

[Motherduck home](https://motherduck.com/)

[START FREE](https://app.motherduck.com/?auth_flow=signup)

# Motherduck and DuckDB Events

Stay up to date with our next events around the globe. Conferences, meetups, livestreams and more.

Search and filter

Search and filter

CLEAR ALL

Search

Location

Type

CLEAR ALL

[**Nov**  **25**\\
\\
**NL dbt meetup: 14th Edition** \\
\\
Data talks on dbt, DuckLake, AI, and freelancing. Pizza and drinks at MotherDuck Amsterdam\\
\\
Oostelijke Handelskade 749 · Amsterdam - 5:30 PM Europe, Amsterdam\\
\\
In Person\\
\\
Register](https://www.meetup.com/amsterdam-dbt-meetup/events/311762568/) [**Dec**  **02**\\
\\
**AWS re:Invent Cocktail Reception** \\
\\
Join Supabase, Tines, Motherduck, Semgrep, and Felicis for a relaxed evening of cocktails and conversation during AWS re:Invent just steps from the center of AWS re:Invent.\\
\\
Tableau in The Wynn Hotel - 5:30 PM America, Los Angeles\\
\\
In Person\\
\\
Register](https://gatsby.events/felicis/rsvp/register?e=aws-re-invent-reset-cocktails-and-conversation-with-supabase-tines-mother-duck-semgrep-felicis&ref=motherduck) [**Dec**  **03**\\
\\
**Hands-on Lab: Agentic Data Engineering with MotherDuck** \\
\\
Join Ascend.io for a hands-on lab. Learn to build data pipelines on MotherDuck using AI agents to automate engineering workflows and operations.\\
\\
Online - 1:00 PM Eastern Standard Time\\
\\
Online\\
\\
Register](https://www.ascend.io/events/hands-on-lab-agentic-data-engineering-with-motherduck) [**Dec**  **11**\\
\\
**Getting Started with MotherDuck** \\
\\
​Looking to get started with MotherDuck and DuckDB? Join us for a live session to learn how MotherDuck makes big data feel small. ​​​​​​\\
\\
Online - 3:00 AM Eastern Standard Time\\
\\
Online\\
\\
Register](https://luma.com/wc9xz2ik?utm_source=eventspage) [**Dec**  **17**\\
\\
**Workshop: Build a Serverless Lakehouse with DuckLake** \\
\\
In this hands-on workshop, we will walk you through building a serverless lakehouse from scratch using DuckLake.\\
\\
Online - 3:00 AM Eastern Standard Time\\
\\
Online\\
\\
Register](https://luma.com/362ipnys?utm_source=eventspage)

Authorization Response