---
title: mike-spaulding
content_type: event
source_url: https://motherduck.com/authors/mike-spaulding
indexed_at: '2025-11-25T20:38:32.277705'
content_hash: 244556919dc1bd27
---

Hands-on Lab: Agentic Data Engineering with MotherDuck and Ascend[December 3, 10am PT / 1pm ET](https://www.ascend.io/events/hands-on-lab-agentic-data-engineering-with-motherduck)

[Motherduck home](https://motherduck.com/)

[START FREE](https://app.motherduck.com/?auth_flow=signup)

# Mike Spaulding

![Mike Spaulding's photo](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.amazonaws.com%2Fassets%2Fimg%2FASA_00136_2_2_f975430db8.png&w=3840&q=75)

# Mike Spaulding

Talent Acquisition

Mike leads our Talent Acquisition efforts here at MotherDuck based in Seattle. Previously he led and scaled recruiting teams at Paxos, Facebook, and Qualtrics. His favorite type of duck is the Eider Duck.

## 0POSTS

[SEE ALL BLOG POSTS](https://motherduck.com/blog/)

## SUBSCRIBE

### Subscribe to MotherDuck Blog

E-mail

Also subscribe to other MotherDuck updates

Submit

Authorization Response