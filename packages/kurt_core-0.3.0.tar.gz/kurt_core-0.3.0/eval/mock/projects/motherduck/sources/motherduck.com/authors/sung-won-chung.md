---
title: sung-won-chung
content_type: event
source_url: https://motherduck.com/authors/sung-won-chung
indexed_at: '2025-11-25T20:43:32.746662'
content_hash: 8347fa3639eb1141
---

Hands-on Lab: Agentic Data Engineering with MotherDuck and Ascend[December 3, 10am PT / 1pm ET](https://www.ascend.io/events/hands-on-lab-agentic-data-engineering-with-motherduck)

[Motherduck home](https://motherduck.com/)

[START FREE](https://app.motherduck.com/?auth_flow=signup)

# Sung Won Chung

![Sung Won Chung  's photo](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.amazonaws.com%2Fassets%2Fimg%2Fsung_profile_pic_147c3dee3d.jpeg&w=3840&q=75)

# Sung Won Chung

Guest Author

Sung Won Chung (you can just call him Sung \[rhymes with lung\]), is a person who is so deeply motivated to solve messy, meaningful problems with you. He's currently working as a Solutions Engineer @ Datafold and spent his time at dbt Labs driving the dbt Mesh story. He loves open source, mentoring people, and seeing people evolve way past their expectations. Feel free to DM him anytime!

## 1 POST

[![MotherDuck + dbt: Better Together](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.amazonaws.com%2Fassets%2Fimg%2FScreenshot_2023_09_07_at_16_10_13_d4360ccc33.png&w=3840&q=75)](https://motherduck.com/blog/motherduck-duckdb-dbt/)

[2023/09/07 - Sung Won Chung](https://motherduck.com/blog/motherduck-duckdb-dbt/)

### [MotherDuck + dbt: Better Together](https://motherduck.com/blog/motherduck-duckdb-dbt)

MotherDuck + dbt: Better Together

[SEE ALL BLOG POSTS](https://motherduck.com/blog/)

## SUBSCRIBE

### Subscribe to MotherDuck Blog

E-mail

Also subscribe to other MotherDuck updates

Submit

Authorization Response