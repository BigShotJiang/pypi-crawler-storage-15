---
title: crescent
content_type: event
source_url: https://motherduck.com/ecosystem/crescent
indexed_at: '2025-11-25T20:38:07.198746'
content_hash: fc6e72e16db7072a
---

Hands-on Lab: Agentic Data Engineering with MotherDuck and Ascend[December 3, 10am PT / 1pm ET](https://www.ascend.io/events/hands-on-lab-agentic-data-engineering-with-motherduck)

[Motherduck home](https://motherduck.com/)

[START FREE](https://app.motherduck.com/?auth_flow=signup)

[BACK TO ECOSYSTEM](https://motherduck.com/ecosystem/)

# Crescent

EUROPE

We empower your journey with data by assessing where you are, defining a strategy of where to go, and developing using expert knowledge.

## Assess

Designing and assessing your current landscape helps us plot the best path with you to maximizing your data assets.

## Define

We help you define a path through the data landscape, and craft a strategy that helps you win with data.

## Develop

Our experts are able to execute at an accelerated pace using the latest methodologies.

Blog

![Crescent's logo](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.amazonaws.com%2Fassets%2Fimg%2FGreen_Crescent_Email_Header_9169d46c84.svg&w=3840&q=75)

Authorization Response