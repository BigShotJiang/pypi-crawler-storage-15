---
title: artefact
content_type: event
source_url: https://motherduck.com/ecosystem/artefact
indexed_at: '2025-11-25T20:37:25.006325'
content_hash: b61f9426f2162711
---

Hands-on Lab: Agentic Data Engineering with MotherDuck and Ascend[December 3, 10am PT / 1pm ET](https://www.ascend.io/events/hands-on-lab-agentic-data-engineering-with-motherduck)

[Motherduck home](https://motherduck.com/)

[START FREE](https://app.motherduck.com/?auth_flow=signup)

[BACK TO ECOSYSTEM](https://motherduck.com/ecosystem/)

# Artefact

EUROPE

Artefact is a leading global consulting company dedicated to accelerating the adoption of data and AI to positively impact people and organizations.

We specialize in data transformation and data marketing to drive tangible business results across the entire enterprise value chain.

Our 2,000 employees operate across 33 offices in 26 countries (Europe, Americas, Asia, Middle East Africa) and we partner with 1000 clients, including 300 major brands like Samsung, L’Oréal, Orange and Sanofi.

Blog

Blog

![Artefact's logo](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.us-east-1.amazonaws.com%2Fassets%2Fimg%2Fartefact_logo_d6ca967773.png&w=3840&q=75)

Authorization Response