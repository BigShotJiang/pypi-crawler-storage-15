---
title: yannick-welsch
content_type: event
source_url: https://motherduck.com/authors/yannick-welsch
indexed_at: '2025-11-25T20:43:50.148009'
content_hash: 00f68b03415ad4a2
---

Hands-on Lab: Agentic Data Engineering with MotherDuck and Ascend[December 3, 10am PT / 1pm ET](https://www.ascend.io/events/hands-on-lab-agentic-data-engineering-with-motherduck)

[Motherduck home](https://motherduck.com/)

[START FREE](https://app.motherduck.com/?auth_flow=signup)

# Yannick Welsch

![Yannick Welsch's photo](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.amazonaws.com%2Fassets%2Fimg%2F3_J4_A0604_c4cd2b719b.png&w=3840&q=75)

# Yannick Welsch

Software Engineer

Yannick joins us from Elastic where he was a principal engineer and tech lead for the distributed systems area of Elasticsearch. Previously he was at Talkwalker building their large-scale crawling and search platform.

## 0POSTS

[SEE ALL BLOG POSTS](https://motherduck.com/blog/)

## SUBSCRIBE

### Subscribe to MotherDuck Blog

E-mail

Also subscribe to other MotherDuck updates

Submit

Authorization Response