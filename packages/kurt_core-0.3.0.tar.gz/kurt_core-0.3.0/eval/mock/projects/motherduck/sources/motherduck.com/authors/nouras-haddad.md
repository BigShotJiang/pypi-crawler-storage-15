---
title: nouras-haddad
content_type: event
source_url: https://motherduck.com/authors/nouras-haddad
indexed_at: '2025-11-25T20:43:33.884650'
content_hash: 5854188ee8e8e77f
---

Hands-on Lab: Agentic Data Engineering with MotherDuck and Ascend[December 3, 10am PT / 1pm ET](https://www.ascend.io/events/hands-on-lab-agentic-data-engineering-with-motherduck)

[Motherduck home](https://motherduck.com/)

[START FREE](https://app.motherduck.com/?auth_flow=signup)

# Nouras Haddad

![Nouras Haddad's photo](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.amazonaws.com%2Fassets%2Fimg%2Fnouras_ba9e9a2696.png&w=3840&q=75)

# Nouras Haddad

VP, Partnerships

Nouras joins us to build out the MotherDuck ecosystems and partnerships function. Previously, he led Alliances at Looker, Firebolt and Stitch Data.

## 1 POST

[![Birds of a Feather MotherDuck Together ](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.amazonaws.com%2Fassets%2Fimg%2Fbirds_flock_cb4bad8b4f.png&w=3840&q=75)](https://motherduck.com/blog/building-motherduck-partner-ecosystem/)

[2023/07/06 - Tino Tereshko, Nouras Haddad](https://motherduck.com/blog/building-motherduck-partner-ecosystem/)

### [Birds of a Feather MotherDuck Together](https://motherduck.com/blog/building-motherduck-partner-ecosystem)

Building the MotherDuck Ecosystem

[SEE ALL BLOG POSTS](https://motherduck.com/blog/)

## SUBSCRIBE

### Subscribe to MotherDuck Blog

E-mail

Also subscribe to other MotherDuck updates

Submit

Authorization Response