---
title: joseph-hwang
content_type: event
source_url: https://motherduck.com/authors/joseph-hwang
indexed_at: '2025-11-25T20:43:43.045006'
content_hash: bc138c05def614e4
---

Hands-on Lab: Agentic Data Engineering with MotherDuck and Ascend[December 3, 10am PT / 1pm ET](https://www.ascend.io/events/hands-on-lab-agentic-data-engineering-with-motherduck)

[Motherduck home](https://motherduck.com/)

[START FREE](https://app.motherduck.com/?auth_flow=signup)

# Joseph Hwang

![Joseph Hwang's photo](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.amazonaws.com%2Fassets%2Fimg%2F3_J4_A0708_1c6f5b99ed.png&w=3840&q=75)

# Joseph Hwang

Software Engineer

Joseph joins us from Facebook where he was the tech lead on the Resource Isolation and Management team. Previously he also worked on Facebook's blob storage and the network layer for storage.

## 1 POST

[![Differential Storage: A Key Building Block For A DuckDB-Based Data Warehouse](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.amazonaws.com%2Fassets%2Fimg%2Fdiff_storage_121958b7eb.png&w=3840&q=75)](https://motherduck.com/blog/differential-storage-building-block-for-data-warehouse/)

[2024/03/11 - Joseph Hwang](https://motherduck.com/blog/differential-storage-building-block-for-data-warehouse/)

### [Differential Storage: A Key Building Block For A DuckDB-Based Data Warehouse](https://motherduck.com/blog/differential-storage-building-block-for-data-warehouse)

Differential Storage: A Key Building Block For A DuckDB-Based Data Warehouse

[SEE ALL BLOG POSTS](https://motherduck.com/blog/)

## SUBSCRIBE

### Subscribe to MotherDuck Blog

E-mail

Also subscribe to other MotherDuck updates

Submit

Authorization Response