---
title: codecentric
content_type: event
source_url: https://motherduck.com/ecosystem/codecentric
indexed_at: '2025-11-25T20:37:18.888487'
content_hash: 3fd951a50d6e5cf7
---

Hands-on Lab: Agentic Data Engineering with MotherDuck and Ascend[December 3, 10am PT / 1pm ET](https://www.ascend.io/events/hands-on-lab-agentic-data-engineering-with-motherduck)

[Motherduck home](https://motherduck.com/)

[START FREE](https://app.motherduck.com/?auth_flow=signup)

[BACK TO ECOSYSTEM](https://motherduck.com/ecosystem/)

# Codecentric

DACH

codecentric AG is a leading German IT consultancy with deep expertise in Data & AI. With our focus on Data Effectiveness, we have spent over 20 years empowering organizations to turn complex data challenges into measurable business value. We provide practical solutions along the entire data value chain—from AI strategy and data architecture to the implementation and operation of modern data platforms. With us, you turn technical possibilities into sustainable business success.

Blog

Blog

![Codecentric's logo](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.us-east-1.amazonaws.com%2Fassets%2Fimg%2Fcodecentric_Prim_Logo_farbe_rgb_90db164812.svg&w=3840&q=75)

Authorization Response