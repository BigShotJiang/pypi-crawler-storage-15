---
title: yves-le-maout
content_type: event
source_url: https://motherduck.com/authors/yves-le-maout
indexed_at: '2025-11-25T20:43:49.103468'
content_hash: 8f29ed80b905cc7e
has_narrative: true
---

Hands-on Lab: Agentic Data Engineering with MotherDuck and Ascend[December 3, 10am PT / 1pm ET](https://www.ascend.io/events/hands-on-lab-agentic-data-engineering-with-motherduck)

[Motherduck home](https://motherduck.com/)

[START FREE](https://app.motherduck.com/?auth_flow=signup)

# Yves Le Maout

![Yves Le Maout's photo](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.amazonaws.com%2Fassets%2Fimg%2F3_J4_A0564_4a41580734_90bc520817.png&w=3840&q=75)

# Yves Le Maout

Founding Engineer

Yves most recently was CTO and VP of Engineering on progressive data analytics at STOIC. Previously he held leadership roles in IT for financial services.

## 0POSTS

[SEE ALL BLOG POSTS](https://motherduck.com/blog/)

## SUBSCRIBE

### Subscribe to MotherDuck Blog

E-mail

Also subscribe to other MotherDuck updates

Submit

Authorization Response