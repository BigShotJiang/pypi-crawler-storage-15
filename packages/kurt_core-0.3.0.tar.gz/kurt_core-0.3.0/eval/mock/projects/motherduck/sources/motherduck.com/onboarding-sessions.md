---
title: onboarding-sessions
content_type: event
source_url: https://motherduck.com/onboarding-sessions
indexed_at: '2025-11-25T20:36:51.329951'
content_hash: cab8e5fcd587f22d
---

Hands-on Lab: Agentic Data Engineering with MotherDuck and Ascend[December 3, 10am PT / 1pm ET](https://www.ascend.io/events/hands-on-lab-agentic-data-engineering-with-motherduck)

[Motherduck home](https://motherduck.com/)

[START FREE](https://app.motherduck.com/?auth_flow=signup)

# MotherDuck Onboarding Sessions

Authorization Response