---
title: garrett-obrien
content_type: event
source_url: https://motherduck.com/authors/garrett-obrien
indexed_at: '2025-11-25T20:43:18.241267'
content_hash: 6f4af0fb6479e57b
---

Hands-on Lab: Agentic Data Engineering with MotherDuck and Ascend[December 3, 10am PT / 1pm ET](https://www.ascend.io/events/hands-on-lab-agentic-data-engineering-with-motherduck)

[Motherduck home](https://motherduck.com/)

[START FREE](https://app.motherduck.com/?auth_flow=signup)

# Garrett O'Brien

![Garrett O'Brien's photo](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.us-east-1.amazonaws.com%2Fassets%2Fimg%2Fgarrett_headshot_931d49f19a.jpeg&w=3840&q=75)

# Garrett O'Brien

Product Marketing Manager

Garrett joins MotherDuck to lead product marketing. Previously, he worked in product marketing roles at Common Paper and Stitch.

## 3 POSTS

[![Small Data SF 2025: the Recap!](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.us-east-1.amazonaws.com%2Fassets%2Fimg%2Fsmall_data_sf_2025_f373154984.png&w=3840&q=75)](https://motherduck.com/blog/small-data-sf-recap-2025/)

[2025/11/14 - Garrett O'Brien](https://motherduck.com/blog/small-data-sf-recap-2025/)

### [Small Data SF 2025: the Recap!](https://motherduck.com/blog/small-data-sf-recap-2025)

Dive into a recap of the world's hottest efficiency-themed data conference, Small Data SF!

[![DuckDB 1.4.1 and DuckLake 0.3 Land in MotherDuck: New SQL Syntax, Iceberg Interoperability, and Performance Gains](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.us-east-1.amazonaws.com%2Fassets%2Fimg%2FDuck_DB_1_4_1_b6209aca06.png&w=3840&q=75)](https://motherduck.com/blog/announcing-duckdb-141-motherduck/)

[2025/10/09 - Alex Monahan, Garrett O'Brien](https://motherduck.com/blog/announcing-duckdb-141-motherduck/)

### [DuckDB 1.4.1 and DuckLake 0.3 Land in MotherDuck: New SQL Syntax, Iceberg Interoperability, and Performance Gains](https://motherduck.com/blog/announcing-duckdb-141-motherduck)

MotherDuck now supports DuckDB 1.4.1 and DuckLake 0.3, with new SQL syntax, faster sorting, Iceberg interoperability, and more. Read on for the highlights from these major releases.

[![MotherDuck is Landing in Europe! Announcing our EU Region](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.us-east-1.amazonaws.com%2Fassets%2Fimg%2Feu_launch_blog_b165ff2751.png&w=3840&q=75)](https://motherduck.com/blog/motherduck-in-europe/)

[2025/09/24 - Garrett O'Brien, Sheila Sitaram](https://motherduck.com/blog/motherduck-in-europe/)

### [MotherDuck is Landing in Europe! Announcing our EU Region](https://motherduck.com/blog/motherduck-in-europe)

Serverless analytics built on DuckDB, running entirely in the EU.

[SEE ALL BLOG POSTS](https://motherduck.com/blog/)

## SUBSCRIBE

### Subscribe to MotherDuck Blog

E-mail

Also subscribe to other MotherDuck updates

Submit

Authorization Response