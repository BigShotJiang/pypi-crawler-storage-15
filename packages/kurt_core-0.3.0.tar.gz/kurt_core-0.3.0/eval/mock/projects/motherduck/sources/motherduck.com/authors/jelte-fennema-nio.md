---
title: jelte-fennema-nio
content_type: event
source_url: https://motherduck.com/authors/jelte-fennema-nio
indexed_at: '2025-11-25T20:38:29.892243'
content_hash: 7694358902559f51
---

Hands-on Lab: Agentic Data Engineering with MotherDuck and Ascend[December 3, 10am PT / 1pm ET](https://www.ascend.io/events/hands-on-lab-agentic-data-engineering-with-motherduck)

[Motherduck home](https://motherduck.com/)

[START FREE](https://app.motherduck.com/?auth_flow=signup)

# Jelte Fennema-Nio

![Jelte Fennema-Nio's photo](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.amazonaws.com%2Fassets%2Fimg%2FJelte_24978892cc.png&w=3840&q=75)

# Jelte Fennema-Nio

Software Engineer

Jelte is a Software Engineer at MotherDuck, part of the database pod.

## 2 POSTS

[![Announcing Pg_duckdb Version 1.0](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.amazonaws.com%2Fassets%2Fimg%2Fpg_duckdb_0ba60b727d.png&w=3840&q=75)](https://motherduck.com/blog/pg-duckdb-release/)

[2025/09/03 - Jelte Fennema-Nio, Jacob Matson](https://motherduck.com/blog/pg-duckdb-release/)

### [Announcing Pg\_duckdb Version 1.0](https://motherduck.com/blog/pg-duckdb-release)

PostgreSQL gets a DuckDB-flavored power-up for faster analytical queries without ever leaving Postgres.

[![ pg_duckdb beta release : Even faster analytics in Postgres](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.amazonaws.com%2Fassets%2Fimg%2Fpg_duckdb_beta_2_bc478870d8.png&w=3840&q=75)](https://motherduck.com/blog/pgduckdb-beta-release-duckdb-postgres/)

[2024/10/23 - Jelte Fennema-Nio, Mehdi Ouazza](https://motherduck.com/blog/pgduckdb-beta-release-duckdb-postgres/)

### [pg\_duckdb beta release : Even faster analytics in Postgres](https://motherduck.com/blog/pgduckdb-beta-release-duckdb-postgres)

pg\_duckdb makes elephants fly, marking its first release.

[SEE ALL BLOG POSTS](https://motherduck.com/blog/)

## SUBSCRIBE

### Subscribe to MotherDuck Blog

E-mail

Also subscribe to other MotherDuck updates

Submit

Authorization Response