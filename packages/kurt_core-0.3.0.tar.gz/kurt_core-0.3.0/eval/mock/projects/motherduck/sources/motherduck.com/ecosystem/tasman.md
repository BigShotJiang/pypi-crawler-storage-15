---
title: tasman
content_type: event
source_url: https://motherduck.com/ecosystem/tasman
indexed_at: '2025-11-25T20:37:27.825996'
content_hash: edeb9abf93141128
---

Hands-on Lab: Agentic Data Engineering with MotherDuck and Ascend[December 3, 10am PT / 1pm ET](https://www.ascend.io/events/hands-on-lab-agentic-data-engineering-with-motherduck)

[Motherduck home](https://motherduck.com/)

[START FREE](https://app.motherduck.com/?auth_flow=signup)

[BACK TO ECOSYSTEM](https://motherduck.com/ecosystem/)

# Tasman

EUROPE

Tasman is an analytics agency that turns data into meaningful business value. We partner with ambitious teams to build modern infrastructure, unlock the right insights, tackle migrations and AI implementation, and grow in-house analytics capabilities.

Think of us as your fractional data team - experts in cutting-edge tools and practices, focused on accelerating your growth.

Blog

![Tasman's logo](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.us-east-1.amazonaws.com%2Fassets%2Fimg%2FWordmark_Black_1_00865a5aed.svg&w=3840&q=75)

Authorization Response