---
title: andrew-mcewen
content_type: event
source_url: https://motherduck.com/authors/andrew-mcewen
indexed_at: '2025-11-25T20:38:33.838721'
content_hash: 8f06534d0b3ce001
---

Hands-on Lab: Agentic Data Engineering with MotherDuck and Ascend[December 3, 10am PT / 1pm ET](https://www.ascend.io/events/hands-on-lab-agentic-data-engineering-with-motherduck)

[Motherduck home](https://motherduck.com/)

[START FREE](https://app.motherduck.com/?auth_flow=signup)

# Andrew McEwen

![Andrew McEwen's photo](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.amazonaws.com%2Fassets%2Fimg%2Fandrew_f55fd0be68.jpeg&w=3840&q=75)

# Andrew McEwen

Andrew McEwen is the Co-Founder and CTO of Secoda, the command center for your data stack that provides an AI powered data catalog, observability, and governance platform to save companies time and money.

## 1 POST

[![Secoda x MotherDuck: The newest member of the Modern Duck Stack 🦆](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.amazonaws.com%2Fassets%2Fimg%2FSecoda_1_73cc39ad7a.png&w=3840&q=75)](https://motherduck.com/blog/secoda-motherduck-integration-modern-duck-stack/)

[2024/07/19 - Andrew McEwen](https://motherduck.com/blog/secoda-motherduck-integration-modern-duck-stack/)

### [Secoda x MotherDuck: The newest member of the Modern Duck Stack 🦆](https://motherduck.com/blog/secoda-motherduck-integration-modern-duck-stack)

The MotherDuck x Secoda integration allows you to enable data producers and consumers, regardless of technical ability, to easily locate and access the data they need! Learn how to enable the integration in two easy steps.

[SEE ALL BLOG POSTS](https://motherduck.com/blog/)

## SUBSCRIBE

### Subscribe to MotherDuck Blog

E-mail

Also subscribe to other MotherDuck updates

Submit

Authorization Response