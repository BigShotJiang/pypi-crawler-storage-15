---
title: brett-griffin
content_type: event
source_url: https://motherduck.com/authors/brett-griffin
indexed_at: '2025-11-25T20:43:12.137584'
content_hash: 864aa51082aead96
---

Hands-on Lab: Agentic Data Engineering with MotherDuck and Ascend[December 3, 10am PT / 1pm ET](https://www.ascend.io/events/hands-on-lab-agentic-data-engineering-with-motherduck)

[Motherduck home](https://motherduck.com/)

[START FREE](https://app.motherduck.com/?auth_flow=signup)

# Brett Griffin

![Brett Griffin's photo](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.amazonaws.com%2Fassets%2Fimg%2Fbrett_e6e5d558f1.png&w=3840&q=75)

# Brett Griffin

Product Manager

Brett joins MotherDuck as a product manager after a career in engineering, engineering leadership, consulting and as the founder of his own startup in the data ecosystem.

## 1 POST

[![Splicing Duck and Elephant DNA](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.amazonaws.com%2Fassets%2Fimg%2Fpg_duckdb_46f2065bc8.png&w=3840&q=75)](https://motherduck.com/blog/pg_duckdb-postgresql-extension-for-duckdb-motherduck/)

[2024/08/15 - Jordan Tigani, Brett Griffin](https://motherduck.com/blog/pg_duckdb-postgresql-extension-for-duckdb-motherduck/)

### [Splicing Duck and Elephant DNA](https://motherduck.com/blog/pg_duckdb-postgresql-extension-for-duckdb-motherduck)

Introducing the DuckDB + Postgres Extension: You can have your analytics and transact them too with pg\_duckdb by DuckDB Labs, MotherDuck, Hydra, Neon and Microsoft.

[SEE ALL BLOG POSTS](https://motherduck.com/blog/)

## SUBSCRIBE

### Subscribe to MotherDuck Blog

E-mail

Also subscribe to other MotherDuck updates

Submit

Authorization Response