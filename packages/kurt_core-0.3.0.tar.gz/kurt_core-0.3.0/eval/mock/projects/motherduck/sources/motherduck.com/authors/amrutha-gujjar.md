---
title: amrutha-gujjar
content_type: event
source_url: https://motherduck.com/authors/amrutha-gujjar
indexed_at: '2025-11-25T20:43:39.375972'
content_hash: 2b0b0dbc19cf3f4b
---

Hands-on Lab: Agentic Data Engineering with MotherDuck and Ascend[December 3, 10am PT / 1pm ET](https://www.ascend.io/events/hands-on-lab-agentic-data-engineering-with-motherduck)

[Motherduck home](https://motherduck.com/)

[START FREE](https://app.motherduck.com/?auth_flow=signup)

# Amrutha Gujjar

![ Amrutha Gujjar's photo](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.amazonaws.com%2Fassets%2Fimg%2Famrutha_e0e0ef8b8a.jpeg&w=3840&q=75)

# Amrutha Gujjar

Founder, Structured Labs

👩🏻‍💻Building Preswald - https://github.com/StructuredLabs/preswald

Backed by Investors: Y Combinator, General Catalyst

## 1 POST

[![Faster health data analysis with MotherDuck & Preswald](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.amazonaws.com%2Fassets%2Fimg%2Fstructured_preswald_521f8cd689.png&w=3840&q=75)](https://motherduck.com/blog/preswald-health-data-analysis/)

[2025/02/14 - Amrutha Gujjar](https://motherduck.com/blog/preswald-health-data-analysis/)

### [Faster health data analysis with MotherDuck & Preswald](https://motherduck.com/blog/preswald-health-data-analysis)

Faster health data analysis with MotherDuck & Preswald

[SEE ALL BLOG POSTS](https://motherduck.com/blog/)

## SUBSCRIBE

### Subscribe to MotherDuck Blog

E-mail

Also subscribe to other MotherDuck updates

Submit

Authorization Response