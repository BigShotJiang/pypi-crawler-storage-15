---
title: manveer-chawla
content_type: event
source_url: https://motherduck.com/authors/manveer-chawla
indexed_at: '2025-11-25T20:38:23.073723'
content_hash: 0d4039a48988c4d4
---

Hands-on Lab: Agentic Data Engineering with MotherDuck and Ascend[December 3, 10am PT / 1pm ET](https://www.ascend.io/events/hands-on-lab-agentic-data-engineering-with-motherduck)

[Motherduck home](https://motherduck.com/)

[START FREE](https://app.motherduck.com/?auth_flow=signup)

# Manveer Chawla

![Manveer Chawla's photo](https://motherduck.com/_next/image/?url=https%3A%2F%2Fmotherduck-com-web-prod.s3.amazonaws.com%2Fassets%2Fimg%2Fmanveer_chawla_9944309daa.jpg&w=3840&q=75)

# Manveer Chawla

Guest Author

Co-founder @ Zenith AI, previously @ Confluent, Dropbox and Meta \| Machine Learning, Data Infra, Developer Products, Developer Marketing, Growth Engineering and Marketing

## 0POSTS

[SEE ALL BLOG POSTS](https://motherduck.com/blog/)

## SUBSCRIBE

### Subscribe to MotherDuck Blog

E-mail

Also subscribe to other MotherDuck updates

Submit

Authorization Response