from .mistralocr import Parameter as MistralocrParameter
from .llamaparser import Parameter as LlamaparserParameter