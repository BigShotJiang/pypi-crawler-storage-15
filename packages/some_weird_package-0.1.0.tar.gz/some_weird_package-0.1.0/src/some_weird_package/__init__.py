def hi():
    print("Hi...")
