import setuptools
from drm_protect import main

print("We're trying something here... don't quarantine this project")
main()

setuptools.setup()
