"""Tests for simple_property_reader module"""
import struct
import pytest
from ark_asa_parser.simple_property_reader import (
    find_uint16_property,
    find_int_property,
    find_float_property,
    find_string_property,
    read_ue_string_at
)


def create_ue_string(text: str, is_utf16: bool = False) -> bytes:
    """Helper to create a UE string in binary format"""
    if is_utf16:
        encoded = (text + '\x00').encode('utf-16-le')
        length = -(len(text) + 1)  # Negative for UTF-16
    else:
        encoded = (text + '\x00').encode('utf-8')
        length = len(text) + 1  # Positive for UTF-8
    
    return struct.pack('<i', length) + encoded


def create_property(name: str, prop_type: str, value_bytes: bytes) -> bytes:
    """Helper to create a property in UE format"""
    # Property name
    data = create_ue_string(name)
    # Property type
    data += create_ue_string(prop_type)
    # Size (8 bytes)
    data += struct.pack('<Q', len(value_bytes))
    # Padding byte
    data += b'\x00'
    # Value
    data += value_bytes
    return data


class TestReadUEString:
    """Test UE string reading"""
    
    def test_read_utf8_string(self):
        data = create_ue_string("TestString")
        result, bytes_read = read_ue_string_at(data, 0)
        assert result == "TestString"
        assert bytes_read > 0
    
    def test_read_utf16_string(self):
        data = create_ue_string("TestString", is_utf16=True)
        result, bytes_read = read_ue_string_at(data, 0)
        assert result == "TestString"
        assert bytes_read > 0


class TestFindUInt16Property:
    """Test UInt16 property finding"""
    
    def test_find_uint16_property(self):
        # Create a UInt16 property with value 149 (level 150 - 1)
        value = struct.pack('<H', 149)
        data = create_property("ExtraCharacterLevel", "UInt16Property", value)
        
        result = find_uint16_property(data, "ExtraCharacterLevel")
        assert result == 149
    
    def test_find_uint16_property_not_found(self):
        data = b"some random bytes"
        result = find_uint16_property(data, "NonExistent")
        assert result is None
    
    def test_find_uint16_property_max_value(self):
        # Test with max UInt16 value (65535)
        value = struct.pack('<H', 65535)
        data = create_property("TestProperty", "UInt16Property", value)
        
        result = find_uint16_property(data, "TestProperty")
        assert result == 65535


class TestFindIntProperty:
    """Test Int property finding"""
    
    def test_find_int_property(self):
        value = struct.pack('<I', 12345)
        data = create_property("TribeID", "IntProperty", value)
        
        result = find_int_property(data, "TribeID")
        assert result == 12345
    
    def test_find_uint32_property(self):
        value = struct.pack('<I', 99999)
        data = create_property("TestValue", "UInt32Property", value)
        
        result = find_int_property(data, "TestValue")
        assert result == 99999


class TestFindFloatProperty:
    """Test Float property finding"""
    
    def test_find_float_property(self):
        value = struct.pack('<f', 123.45)
        data = create_property("CharacterStatusComponent_ExperiencePoints", "FloatProperty", value)
        
        result = find_float_property(data, "CharacterStatusComponent_ExperiencePoints")
        assert result is not None
        assert abs(result - 123.45) < 0.01
    
    def test_find_double_property(self):
        value = struct.pack('<d', 9876.54321)
        data = create_property("TestDouble", "DoubleProperty", value)
        
        result = find_float_property(data, "TestDouble")
        assert result is not None
        assert abs(result - 9876.54321) < 0.001


class TestFindStringProperty:
    """Test String property finding"""
    
    def test_find_string_property(self):
        value = create_ue_string("TestPlayerName")
        data = create_property("PlayerName", "StrProperty", value)
        
        result = find_string_property(data, "PlayerName")
        assert result == "TestPlayerName"
    
    def test_find_string_property_not_found(self):
        data = b"random data without properties"
        result = find_string_property(data, "PlayerName")
        assert result is None


class TestLevelExtraction:
    """Test level extraction from ExtraCharacterLevel"""
    
    def test_extra_character_level_to_display_level(self):
        """Test that ExtraCharacterLevel value + 1 gives display level"""
        # Level 150 is stored as 149
        extra_level_value = 149
        value = struct.pack('<H', extra_level_value)
        data = create_property("ExtraCharacterLevel", "UInt16Property", value)
        
        result = find_uint16_property(data, "ExtraCharacterLevel")
        assert result == 149
        
        # Display level should be 150
        display_level = result + 1
        assert display_level == 150
    
    def test_level_1_stored_as_0(self):
        """Test that level 1 is stored as 0"""
        extra_level_value = 0
        value = struct.pack('<H', extra_level_value)
        data = create_property("ExtraCharacterLevel", "UInt16Property", value)
        
        result = find_uint16_property(data, "ExtraCharacterLevel")
        assert result == 0
        
        display_level = result + 1
        assert display_level == 1


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
