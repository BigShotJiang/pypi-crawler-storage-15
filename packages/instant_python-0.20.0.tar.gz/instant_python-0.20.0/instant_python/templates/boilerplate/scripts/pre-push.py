#!/bin/bash
set -e

exec < /dev/tty

make pre-push