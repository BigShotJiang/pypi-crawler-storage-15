VERSION = "0.3.10"

# this will be templated during the build
GIT_COMMIT = "160c352d87c121ef1ea43e49831453b9e8d4d0f8"
