"""Patch files for firmware initialization."""

