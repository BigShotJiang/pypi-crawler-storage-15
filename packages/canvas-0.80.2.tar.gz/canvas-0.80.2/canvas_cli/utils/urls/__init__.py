from canvas_cli.utils.urls.urls import CoreEndpoint

__all__ = ("CoreEndpoint",)
