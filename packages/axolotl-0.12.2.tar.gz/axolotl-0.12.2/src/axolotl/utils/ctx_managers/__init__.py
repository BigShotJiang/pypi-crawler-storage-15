"""Init for context manager submodule"""

# pylint: disable=unused-import
# flake8: noqa

from .sequence_parallel import SequenceParallelContextManager
