"""Init for `axolotl.utils.mistral` module."""

from axolotl.utils.mistral.mistral_tokenizer import HFMistralTokenizer

__all__ = ["HFMistralTokenizer"]
