"""
TiledMLP monkey patches
"""

from .patch import (
    patch_tiled_mlp,
)

__all__ = [
    "patch_tiled_mlp",
]
