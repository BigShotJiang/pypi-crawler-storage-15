"""Integration entry point for the LLMCompressor plugin."""

from .plugin import LLMCompressorPlugin

__all__ = ["LLMCompressorPlugin"]
