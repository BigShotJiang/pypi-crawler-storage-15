import{a as t}from"../chunks/entry.DYDpUnTB.js";export{t as start};
