__version__ = '1.0-alpha.23'
__author__ = 'gperdrizet'

from .dataset import DataSet

__all__ = ['DataSet']