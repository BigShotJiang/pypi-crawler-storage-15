# Real Time News Data MCP Server

[English](./README_EN.md) | 简体中文 | [繁體中文](./README_ZH-TW.md)

用于访问 Real Time News Data API 的 MCP 服务器。

## 🚀 使用 EMCP 平台快速体验

**[EMCP](https://sit-emcp.kaleido.guru)** 是一个强大的 MCP 服务器管理平台，让您无需手动配置即可快速使用各种 MCP 服务器！

### 快速开始：

1. 🌐 访问 **[EMCP 平台](https://sit-emcp.kaleido.guru)**
2. 📝 注册并登录账号
3. 🎯 进入 **MCP 广场**，浏览所有可用的 MCP 服务器
4. 🔍 搜索或找到本服务器（`bach-real_time_news_data`）
5. 🎉 点击 **"安装 MCP"** 按钮
6. ✅ 完成！即可在您的应用中使用

### EMCP 平台优势：

- ✨ **零配置**：无需手动编辑配置文件
- 🎨 **可视化管理**：图形界面轻松管理所有 MCP 服务器
- 🔐 **安全可靠**：统一管理 API 密钥和认证信息
- 🚀 **一键安装**：MCP 广场提供丰富的服务器选择
- 📊 **使用统计**：实时查看服务调用情况

立即访问 **[EMCP 平台](https://sit-emcp.kaleido.guru)** 开始您的 MCP 之旅！


---

## 简介

这是一个 MCP 服务器，用于访问 Real Time News Data API。

- **PyPI 包名**: `bach-real_time_news_data`
- **版本**: 1.0.0
- **传输协议**: stdio


## 安装

### 从 PyPI 安装:

```bash
pip install bach-real_time_news_data
```

### 从源码安装:

```bash
pip install -e .
```

## 运行

### 方式 1: 使用 uvx（推荐，无需安装）

```bash
# 运行（uvx 会自动安装并运行）
uvx --from bach-real_time_news_data bach_real_time_news_data

# 或指定版本
uvx --from bach-real_time_news_data@latest bach_real_time_news_data
```

### 方式 2: 直接运行（开发模式）

```bash
python server.py
```

### 方式 3: 安装后作为命令运行

```bash
# 安装
pip install bach-real_time_news_data

# 运行（命令名使用下划线）
bach_real_time_news_data
```

## 配置

### API 认证

此 API 需要认证。请设置环境变量:

```bash
export API_KEY="your_api_key_here"
```

### 环境变量

| 变量名 | 说明 | 必需 |
|--------|------|------|
| `API_KEY` | API 密钥 | 是 |
| `PORT` | 不适用 | 否 |
| `HOST` | 不适用 | 否 |



### 在 Cursor 中使用

编辑 Cursor MCP 配置文件 `~/.cursor/mcp.json`:


```json
{
  "mcpServers": {
    "bach-real_time_news_data": {
      "command": "uvx",
      "args": ["--from", "bach-real_time_news_data", "bach_real_time_news_data"],
      "env": {
        "API_KEY": "your_api_key_here"
      }
    }
  }
}
```

### 在 Claude Desktop 中使用

编辑 Claude Desktop 配置文件 `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "bach-real_time_news_data": {
      "command": "uvx",
      "args": ["--from", "bach-real_time_news_data", "bach_real_time_news_data"],
      "env": {
        "API_KEY": "your_api_key_here"
      }
    }
  }
}
```


## 可用工具

此服务器提供以下工具:


### `search`

Search news articles by query with an option to limit the results to a specific time range.

**端点**: `GET /search`


**参数**:

- `query` (string) *必需*: Search query for which to get news.

- `limit` (number): Maximum number of news articles to return. Default: 500 Allowed values: 1-500

- `time_published` (string): Find news articles published in a specific time range. Default: anytime

- `source` (string): Domain of the source from which to return news articles. Example: cnn.com

- `country` (string): Country code. See all available country codes. Default: US

- `lang` (string): The language to use for the results, specified as a 2-letter language code - see ISO 639-1 alpha-2. Default: en



---


### `full_story_coverage`

Get the full story coverage, including all sub articles, top news, and posts from X (formerly Twitter).

**端点**: `GET /full-story-coverage`


**参数**:

- `story` (string) *必需*: The Story ID for which to get full coverage. Story IDs are returned for news articles with sub_articles from any of the endpoint returning news articles. In addition, Story IDs can be obtained from a News Story URL as it appears after the stories/ path part (e.g. /stories/CAAqNggKIjBDQklTSGpvSmMzUnZjbmt0TXpZd1NoRUtEd2pzbFA3X0N4RjlDUlpVVnhudXBpZ0FQAQ) after navigating to an article's Full Coverage.

- `sort` (string): Return articles (i.e. all_articles list) in a specific sort order. Default: RELEVANCE Allowed values: RELEVANCE, DATE

- `country` (string): Country code. See all available country codes. Default: US

- `lang` (string): The language to use for the results, specified as a 2-letter language code - see ISO 639-1 alpha-2. Default: en



---


### `topic_news_by_section`

Get news article in a specific section of a topic (World,  Sports, Technology, etc) or publication (CNN, BBC, etc).

**端点**: `GET /topic-news-by-section`


**参数**:

- `topic` (string) *必需*: Topic or publication for which to get news headlines. Available topics: WORLD NATIONAL BUSINESS TECHNOLOGY ENTERTAINMENT SPORTS SCIENCE HEALTH In addition, topic / publication IDs are also accepted and can be taken from a News topic URL as it appears after the topics/ or publications/ path part (e.g. Football Topic - /topics/CAAqJQgKIh9DQkFTRVFvSUwyMHZNREoyZURRU0JXVnVMVWRDS0FBUAE)

- `section` (string) *必需*: Example value: CAQiSkNCQVNNUW9JTDIwdk1EZGpNWFlTQldWdUxVZENHZ0pKVENJT0NBUWFDZ29JTDIwdk1ETnliSFFxQ2hJSUwyMHZNRE55YkhRb0FBKi4IACoqCAoiJENCQVNGUW9JTDIwdk1EZGpNWFlTQldWdUxVZENHZ0pKVENnQVABUAE

- `limit` (number): Maximum number of news articles to return. Default: 500 Allowed values: 1-500

- `country` (string): Country code. See all available country codes. Default: US

- `lang` (string): The language to use for the results, specified as a 2-letter language code - see ISO 639-1 alpha-2. Default: en



---


### `topic_headlines`

Get the latest news headlines for a topic (World,  Sports, Technology, etc) or publication (e.g. CNN, BBC, etc).

**端点**: `GET /topic-headlines`


**参数**:

- `topic` (string) *必需*: Topic or publication for which to get news headlines. Available topics: WORLD NATIONAL BUSINESS TECHNOLOGY ENTERTAINMENT SPORTS SCIENCE HEALTH In addition, topic / publication IDs are also accepted and can be taken from a News topic URL as it appears after the topics/ or publications/ path part (e.g. Football Topic - /topics/CAAqJQgKIh9DQkFTRVFvSUwyMHZNREoyZURRU0JXVnVMVWRDS0FBUAE)

- `limit` (number): Maximum number of news articles to return. Default: 500 Allowed values: 1-500

- `country` (string): Country code. See all available country codes. Default: US

- `lang` (string): The language to use for the results, specified as a 2-letter language code - see ISO 639-1 alpha-2. Default: en



---


### `top_headlines`

Get the latest news headlines/top stories for a country.

**端点**: `GET /top-headlines`


**参数**:

- `limit` (number): Maximum number of news articles to return. Default: 500 Allowed values: 1-500

- `country` (string): Country code. See all available country codes. Default: US

- `lang` (string): The language to use for the results, specified as a 2-letter language code - see ISO 639-1 alpha-2. Default: en



---


### `language_list`

Get valid languages for a country code, to be used with all other APIs.

**端点**: `GET /language-list`


**参数**:

- `country` (string) *必需*: Country code of the country to get languages for. See all available country codes.



---


### `local_headlines_geo`

Get local, geo based headlines

**端点**: `GET /local-headlines`


**参数**:

- `query` (string) *必需*: Area, city or country to fetch news for (e.g. London).

- `country` (string): Country code. See all available country codes. Default: US

- `lang` (string): The language to use for the results, specified as a 2-letter language code - see ISO 639-1 alpha-2. Default: en

- `limit` (number): Maximum number of news articles to return. Default: 500 Allowed values: 1-500



---



## 技术栈

- **传输协议**: stdio
- **HTTP 客户端**: httpx


## 许可证

MIT License - 详见 [LICENSE](./LICENSE) 文件。

## 开发

此服务器由 [API-to-MCP](https://github.com/BACH-AI-Tools/api-to-mcp) 工具生成。

版本: 1.0.0
