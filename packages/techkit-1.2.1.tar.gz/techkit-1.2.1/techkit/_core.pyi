"""Type stubs for TechKit C++ core module"""

from typing import Tuple
import numpy as np
from numpy.typing import NDArray


def version() -> str:
    """Get version string"""
    ...


def version_tuple() -> Tuple[int, int, int]:
    """Get version as (major, minor, patch) tuple"""
    ...


class Result:
    """Single value result from indicator calculation"""
    value: float
    valid: bool
    
    def __bool__(self) -> bool: ...


class MACDResult:
    """MACD calculation result"""
    macd: float
    signal: float
    histogram: float
    valid: bool
    
    def __bool__(self) -> bool: ...


class BBandsResult:
    """Bollinger Bands calculation result"""
    upper: float
    middle: float
    lower: float
    valid: bool
    
    def __bool__(self) -> bool: ...


class StochResult:
    """Stochastic calculation result"""
    slowk: float
    slowd: float
    valid: bool
    
    def __bool__(self) -> bool: ...


class StochFResult:
    """Fast Stochastic calculation result"""
    k: float
    d: float
    valid: bool
    
    def __bool__(self) -> bool: ...


class StochRSIResult:
    """Stochastic RSI calculation result"""
    k: float
    d: float
    valid: bool
    
    def __bool__(self) -> bool: ...


class AroonResult:
    """Aroon calculation result"""
    up: float
    down: float
    valid: bool
    
    def __bool__(self) -> bool: ...


class ADXResult:
    """ADX calculation result"""
    plus_di: float
    minus_di: float
    adx: float
    valid: bool
    
    def __bool__(self) -> bool: ...


class HTPhasorResult:
    """Hilbert Transform Phasor result"""
    inphase: float
    quadrature: float
    valid: bool
    
    def __bool__(self) -> bool: ...


class HTSineResult:
    """Hilbert Transform Sine result"""
    sine: float
    leadsine: float
    valid: bool
    
    def __bool__(self) -> bool: ...


class MinMaxResult:
    """MinMax calculation result"""
    min: float
    max: float
    valid: bool
    
    def __bool__(self) -> bool: ...


# Phase 2 Result Types

class DrawdownResult:
    """Drawdown calculation result"""
    drawdown: float
    max_drawdown: float
    duration: int
    max_duration: int
    valid: bool
    
    def __bool__(self) -> bool: ...


class ZigZagResult:
    """ZigZag calculation result"""
    value: float
    direction: int
    is_pivot: bool
    pivot_type: int
    last_pivot_price: float
    bars_since_pivot: int
    valid: bool
    
    def __bool__(self) -> bool: ...


class SwingResult:
    """Swing High/Low calculation result"""
    is_swing_high: bool
    is_swing_low: bool
    swing_high_price: float
    swing_low_price: float
    bars_ago: int
    valid: bool
    
    def __bool__(self) -> bool: ...


class PivotResult:
    """Pivot Points calculation result"""
    pp: float
    r1: float
    r2: float
    r3: float
    s1: float
    s2: float
    s3: float
    valid: bool
    
    def __bool__(self) -> bool: ...


class HarmonicResult:
    """Harmonic Pattern detection result"""
    pattern: int
    direction: int
    x_price: float
    a_price: float
    b_price: float
    c_price: float
    d_price: float
    x_bar: int
    a_bar: int
    b_bar: int
    c_bar: int
    d_bar: int
    xab_ratio: float
    abc_ratio: float
    bcd_ratio: float
    xad_ratio: float
    prz_high: float
    prz_low: float
    score: float
    is_complete: bool
    valid: bool
    
    def __bool__(self) -> bool: ...


class ChartPatternResult:
    """Chart Pattern detection result"""
    pattern: int
    direction: int
    neckline: float
    neckline_slope: float
    target_price: float
    point_prices: list[float]
    point_bars: list[int]
    num_points: int
    height: float
    width_bars: float
    symmetry_score: float
    score: float
    is_complete: bool
    is_confirmed: bool
    breakout_price: float
    valid: bool
    
    def __bool__(self) -> bool: ...


class Indicator:
    """Base indicator class"""
    
    def update(self, value: float) -> Result:
        """Update indicator with a single value (incremental)"""
        ...
    
    def update_ohlcv(
        self, open: float, high: float, low: float, close: float, volume: float
    ) -> Result:
        """Update indicator with OHLCV bar data"""
        ...
    
    def calculate(self, data: NDArray[np.float64]) -> NDArray[np.float64]:
        """Calculate indicator for entire array (batch)"""
        ...
    
    def calculate_ohlcv(
        self,
        open: NDArray[np.float64],
        high: NDArray[np.float64],
        low: NDArray[np.float64],
        close: NDArray[np.float64],
        volume: NDArray[np.float64],
    ) -> NDArray[np.float64]:
        """Calculate indicator from OHLCV arrays (batch)"""
        ...
    
    def reset(self) -> None:
        """Reset indicator to initial state"""
        ...
    
    def is_ready(self) -> bool:
        """Check if indicator has completed warmup period"""
        ...
    
    @property
    def lookback(self) -> int:
        """Number of bars required for warmup"""
        ...
    
    @property
    def name(self) -> str:
        """Indicator name"""
        ...


class MACDIndicator(Indicator):
    """MACD indicator with 3 outputs"""
    
    def __init__(
        self, fast: int = 12, slow: int = 26, signal: int = 9
    ) -> None: ...
    
    def update_macd(self, value: float) -> MACDResult: ...
    
    def calculate_macd(
        self, data: NDArray[np.float64]
    ) -> Tuple[NDArray[np.float64], NDArray[np.float64], NDArray[np.float64]]: ...


class BBandsIndicator(Indicator):
    """Bollinger Bands indicator with 3 outputs"""
    
    def __init__(
        self, period: int = 20, std_up: float = 2.0, std_dn: float = 2.0
    ) -> None: ...
    
    def update_bbands(self, value: float) -> BBandsResult: ...
    
    def calculate_bbands(
        self, data: NDArray[np.float64]
    ) -> Tuple[NDArray[np.float64], NDArray[np.float64], NDArray[np.float64]]: ...


class StochIndicator(Indicator):
    """Stochastic indicator with 2 outputs"""
    
    def __init__(
        self, k_period: int = 14, k_slow: int = 3, d_period: int = 3
    ) -> None: ...
    
    def update_stoch(
        self, open: float, high: float, low: float, close: float, volume: float
    ) -> StochResult: ...
    
    def calculate_stoch(
        self,
        high: NDArray[np.float64],
        low: NDArray[np.float64],
        close: NDArray[np.float64],
    ) -> Tuple[NDArray[np.float64], NDArray[np.float64]]: ...


class StochFIndicator(Indicator):
    """Fast Stochastic indicator with 2 outputs (k, d)"""
    
    def __init__(self, k_period: int = 5, d_period: int = 3) -> None: ...
    
    def update_stochf(
        self, open: float, high: float, low: float, close: float, volume: float
    ) -> StochFResult: ...
    
    def calculate_stochf(
        self,
        high: NDArray[np.float64],
        low: NDArray[np.float64],
        close: NDArray[np.float64],
    ) -> Tuple[NDArray[np.float64], NDArray[np.float64]]: ...


class StochRSIIndicator(Indicator):
    """Stochastic RSI indicator with 2 outputs (k, d)"""
    
    def __init__(
        self, rsi_period: int = 14, stoch_period: int = 14,
        k_smooth: int = 3, d_period: int = 3
    ) -> None: ...
    
    def update_stochrsi(self, value: float) -> StochRSIResult: ...
    
    def calculate_stochrsi(
        self, data: NDArray[np.float64]
    ) -> Tuple[NDArray[np.float64], NDArray[np.float64]]: ...


class MACDEXTIndicator(Indicator):
    """Extended MACD indicator with MA type selection"""
    
    def __init__(
        self, fast_period: int = 12, fast_ma_type: int = 1,
        slow_period: int = 26, slow_ma_type: int = 1,
        signal_period: int = 9, signal_ma_type: int = 1
    ) -> None: ...
    
    def update_macd(self, value: float) -> MACDResult: ...
    
    def calculate_macd(
        self, data: NDArray[np.float64]
    ) -> Tuple[NDArray[np.float64], NDArray[np.float64], NDArray[np.float64]]: ...


class MACDFIXIndicator(Indicator):
    """Fixed Period MACD indicator (12, 26, signal)"""
    
    def __init__(self, signal_period: int = 9) -> None: ...
    
    def update_macd(self, value: float) -> MACDResult: ...
    
    def calculate_macd(
        self, data: NDArray[np.float64]
    ) -> Tuple[NDArray[np.float64], NDArray[np.float64], NDArray[np.float64]]: ...


class AroonIndicator(Indicator):
    """Aroon indicator with 2 outputs"""
    
    def __init__(self, period: int = 14) -> None: ...
    
    def update_aroon(
        self, open: float, high: float, low: float, close: float, volume: float
    ) -> AroonResult: ...
    
    def calculate_aroon(
        self, high: NDArray[np.float64], low: NDArray[np.float64]
    ) -> Tuple[NDArray[np.float64], NDArray[np.float64]]: ...


class ADXIndicator(Indicator):
    """ADX indicator with 3 outputs"""
    
    def __init__(self, period: int = 14) -> None: ...
    
    def update_adx(
        self, open: float, high: float, low: float, close: float, volume: float
    ) -> ADXResult: ...
    
    def calculate_adx(
        self,
        high: NDArray[np.float64],
        low: NDArray[np.float64],
        close: NDArray[np.float64],
    ) -> Tuple[NDArray[np.float64], NDArray[np.float64], NDArray[np.float64]]: ...


class HTPhasorIndicator(Indicator):
    """Hilbert Transform Phasor indicator"""
    
    def __init__(self) -> None: ...
    
    def update_phasor(self, value: float) -> HTPhasorResult: ...
    
    def calculate_phasor(
        self, data: NDArray[np.float64]
    ) -> Tuple[NDArray[np.float64], NDArray[np.float64]]: ...


class HTSineIndicator(Indicator):
    """Hilbert Transform Sine indicator"""
    
    def __init__(self) -> None: ...
    
    def update_sine(self, value: float) -> HTSineResult: ...
    
    def calculate_sine(
        self, data: NDArray[np.float64]
    ) -> Tuple[NDArray[np.float64], NDArray[np.float64]]: ...


class MinMaxIndicator(Indicator):
    """MinMax indicator with 2 outputs"""
    
    def __init__(self, period: int = 30) -> None: ...
    
    def update_minmax(self, value: float) -> MinMaxResult: ...
    
    def calculate_minmax(
        self, data: NDArray[np.float64]
    ) -> Tuple[NDArray[np.float64], NDArray[np.float64]]: ...


# Phase 2 Multi-output Indicator Classes

class DrawdownIndicator(Indicator):
    """Drawdown indicator with multi-output"""
    
    def __init__(self) -> None: ...
    
    def update_drawdown(self, price: float) -> DrawdownResult: ...
    
    def calculate_drawdown(
        self, prices: NDArray[np.float64]
    ) -> Tuple[NDArray[np.float64], NDArray[np.float64], 
               NDArray[np.int32], NDArray[np.int32]]: ...


class ZigZagIndicator(Indicator):
    """ZigZag indicator"""
    
    def __init__(self, deviation_pct: float = 5.0, depth: int = 12) -> None: ...
    
    def update_zigzag(
        self, open: float, high: float, low: float, close: float, volume: float
    ) -> ZigZagResult: ...
    
    def calculate_zigzag(
        self,
        open: NDArray[np.float64],
        high: NDArray[np.float64],
        low: NDArray[np.float64],
        close: NDArray[np.float64],
        volume: NDArray[np.float64],
    ) -> NDArray[np.float64]: ...


class SwingIndicator(Indicator):
    """Swing High/Low indicator"""
    
    def __init__(self, left_bars: int = 5, right_bars: int = 5) -> None: ...
    
    def update_swing(
        self, open: float, high: float, low: float, close: float, volume: float
    ) -> SwingResult: ...
    
    def calculate_swing(
        self, high: NDArray[np.float64], low: NDArray[np.float64]
    ) -> Tuple[NDArray[np.float64], NDArray[np.float64]]: ...


class PivotIndicator(Indicator):
    """Pivot Points indicator"""
    
    def __init__(self, pivot_type: int = 0) -> None: ...
    
    def update_pivot(
        self, open: float, high: float, low: float, close: float, volume: float
    ) -> PivotResult: ...
    
    @staticmethod
    def calculate(
        high: float, low: float, close: float, prev_close: float = 0.0, pivot_type: int = 0
    ) -> PivotResult: ...


class HarmonicIndicator(Indicator):
    """Harmonic Pattern detector"""
    
    def __init__(
        self, deviation_pct: float = 5.0, tolerance: float = 0.03, max_bars: int = 100
    ) -> None: ...
    
    def update_harmonic(
        self, open: float, high: float, low: float, close: float, volume: float
    ) -> HarmonicResult: ...
    
    @staticmethod
    def pattern_name(pattern_type: int) -> str: ...


class ChartPatternIndicator(Indicator):
    """Chart Pattern detector"""
    
    def __init__(
        self, min_bars: int = 20, max_bars: int = 200, tolerance: float = 0.03
    ) -> None: ...
    
    def update_pattern(
        self, open: float, high: float, low: float, close: float, volume: float
    ) -> ChartPatternResult: ...
    
    @staticmethod
    def pattern_name(pattern_type: int) -> str: ...


# Factory functions for single-output indicators

# Moving Averages
def sma(period: int) -> Indicator: ...
def ema(period: int) -> Indicator: ...
def wma(period: int) -> Indicator: ...
def dema(period: int) -> Indicator: ...
def tema(period: int) -> Indicator: ...
def kama(period: int) -> Indicator: ...
def trima(period: int) -> Indicator: ...
def t3(period: int, volume_factor: float = 0.7) -> Indicator: ...

# Momentum
def rsi(period: int = 14) -> Indicator: ...
def mom(period: int = 10) -> Indicator: ...
def roc(period: int = 10) -> Indicator: ...
def rocp(period: int = 10) -> Indicator: ...
def rocr(period: int = 10) -> Indicator: ...
def rocr100(period: int = 10) -> Indicator: ...
def cci(period: int = 20) -> Indicator: ...
def adx(period: int = 14) -> Indicator: ...
def adxr(period: int = 14) -> Indicator: ...
def apo(fast: int = 12, slow: int = 26) -> Indicator: ...
def ppo(fast: int = 12, slow: int = 26) -> Indicator: ...
def cmo(period: int = 14) -> Indicator: ...
def dx(period: int = 14) -> Indicator: ...
def willr(period: int = 14) -> Indicator: ...
def mfi(period: int = 14) -> Indicator: ...
def plus_di(period: int = 14) -> Indicator: ...
def minus_di(period: int = 14) -> Indicator: ...
def plus_dm(period: int = 14) -> Indicator: ...
def minus_dm(period: int = 14) -> Indicator: ...
def trix(period: int = 30) -> Indicator: ...
def ultosc(period1: int = 7, period2: int = 14, period3: int = 28) -> Indicator: ...
def aroonosc(period: int = 14) -> Indicator: ...
def bop() -> Indicator: ...

# Volatility
def atr(period: int = 14) -> Indicator: ...
def natr(period: int = 14) -> Indicator: ...
def trange() -> Indicator: ...

# Volume
def obv() -> Indicator: ...
def ad() -> Indicator: ...
def adosc(fast: int = 3, slow: int = 10) -> Indicator: ...

# Statistics
def stddev(period: int = 5, nbdev: float = 1.0) -> Indicator: ...
def var(period: int = 5) -> Indicator: ...
def linearreg(period: int = 14) -> Indicator: ...
def linearreg_slope(period: int = 14) -> Indicator: ...
def linearreg_intercept(period: int = 14) -> Indicator: ...
def linearreg_angle(period: int = 14) -> Indicator: ...
def tsf(period: int = 14) -> Indicator: ...
def beta(period: int = 5) -> Indicator: ...
def correl(period: int = 30) -> Indicator: ...

# Price Transform
def avgprice() -> Indicator: ...
def medprice() -> Indicator: ...
def typprice() -> Indicator: ...
def wclprice() -> Indicator: ...

# Math Operators
def max(period: int = 30) -> Indicator: ...
def min(period: int = 30) -> Indicator: ...
def sum(period: int = 30) -> Indicator: ...
def midpoint(period: int = 14) -> Indicator: ...
def midprice(period: int = 14) -> Indicator: ...

# Hilbert Transform
def ht_dcperiod() -> Indicator: ...
def ht_dcphase() -> Indicator: ...
def ht_trendmode() -> Indicator: ...
def ht_trendline() -> Indicator: ...

# Parabolic SAR
def sar(acceleration: float = 0.02, maximum: float = 0.2) -> Indicator: ...

# Generic MA with type selection
def ma(period: int = 30, ma_type: int = 0) -> Indicator: ...

# Variable Period MA
def mavp(min_period: int = 2, max_period: int = 30, ma_type: int = 0) -> Indicator: ...

# Extended Parabolic SAR
def sarext(
    start_value: float = 0.0,
    offset_on_reverse: float = 0.0,
    af_init_long: float = 0.02,
    af_long: float = 0.02,
    af_max_long: float = 0.20,
    af_init_short: float = 0.02,
    af_short: float = 0.02,
    af_max_short: float = 0.20
) -> Indicator: ...

# Multi-output indicator factory functions
def macd(fast: int = 12, slow: int = 26, signal: int = 9) -> MACDIndicator: ...
def bbands(period: int = 20, std_up: float = 2.0, std_dn: float = 2.0) -> BBandsIndicator: ...
def stoch(k_period: int = 14, k_slow: int = 3, d_period: int = 3) -> StochIndicator: ...
def stochf(k_period: int = 5, d_period: int = 3) -> StochFIndicator: ...
def stochrsi(rsi_period: int = 14, stoch_period: int = 14, k_smooth: int = 3, d_period: int = 3) -> StochRSIIndicator: ...
def macdext(fast_period: int = 12, fast_ma_type: int = 1, slow_period: int = 26, slow_ma_type: int = 1, signal_period: int = 9, signal_ma_type: int = 1) -> MACDEXTIndicator: ...
def macdfix(signal_period: int = 9) -> MACDFIXIndicator: ...
def aroon(period: int = 14) -> AroonIndicator: ...
def adx_full(period: int = 14) -> ADXIndicator: ...
def ht_phasor() -> HTPhasorIndicator: ...
def ht_sine() -> HTSineIndicator: ...
def minmax(period: int = 30) -> MinMaxIndicator: ...


# Phase 2: Risk Metrics
def sharpe_ratio(period: int = 252, risk_free_rate: float = 0.0, annualization: int = 252) -> Indicator: ...
def sortino_ratio(period: int = 252, risk_free_rate: float = 0.0, target_return: float = 0.0, annualization: int = 252) -> Indicator: ...
def max_drawdown() -> Indicator: ...
def calmar_ratio(period: int = 756, annualization: int = 252) -> Indicator: ...
def hist_var(period: int = 252, confidence: float = 0.95) -> Indicator: ...
def cvar(period: int = 252, confidence: float = 0.95) -> Indicator: ...

# Phase 2: Volatility Models
def ewma_vol(lambda_: float = 0.94, annualization: int = 252) -> Indicator: ...
def realized_vol(period: int = 21, annualization: int = 252) -> Indicator: ...
def parkinson_vol(period: int = 21, annualization: int = 252) -> Indicator: ...
def garch_vol(omega: float = 0.000001, alpha: float = 0.09, beta: float = 0.90, annualization: int = 252) -> Indicator: ...

# Phase 2: Multi-output factory functions
def drawdown() -> DrawdownIndicator: ...
def zigzag(deviation_pct: float = 5.0, depth: int = 12) -> ZigZagIndicator: ...
def swing(left_bars: int = 5, right_bars: int = 5) -> SwingIndicator: ...
def pivot_points(pivot_type: int = 0) -> PivotIndicator: ...
def harmonic(deviation_pct: float = 5.0, tolerance: float = 0.03, max_bars: int = 100) -> HarmonicIndicator: ...
def chart_pattern(min_bars: int = 20, max_bars: int = 200, tolerance: float = 0.03) -> ChartPatternIndicator: ...


# Phase 2: Enums
class MAType:
    SMA: int
    EMA: int
    WMA: int
    DEMA: int
    TEMA: int
    TRIMA: int
    KAMA: int
    MAMA: int
    T3: int


class PivotType:
    CLASSIC: int
    FIBONACCI: int
    WOODIE: int
    CAMARILLA: int
    DEMARK: int


class HarmonicType:
    NONE: int
    GARTLEY_BULL: int
    GARTLEY_BEAR: int
    BUTTERFLY_BULL: int
    BUTTERFLY_BEAR: int
    BAT_BULL: int
    BAT_BEAR: int
    CRAB_BULL: int
    CRAB_BEAR: int
    SHARK_BULL: int
    SHARK_BEAR: int
    CYPHER_BULL: int
    CYPHER_BEAR: int


class ChartPatternType:
    NONE: int
    HEAD_SHOULDERS: int
    INV_HEAD_SHOULDERS: int
    DOUBLE_TOP: int
    DOUBLE_BOTTOM: int
    TRIPLE_TOP: int
    TRIPLE_BOTTOM: int
    TRIANGLE_SYM: int
    TRIANGLE_ASC: int
    TRIANGLE_DESC: int
    WEDGE_RISING: int
    WEDGE_FALLING: int


# ============================================================
# Phase 3: Candlestick Pattern Recognition
# ============================================================


class CDLResult:
    """Candlestick pattern result"""
    signal: int  # +100 (bullish), -100 (bearish), 0 (none)
    valid: bool
    
    def __bool__(self) -> bool: ...
    def is_bullish(self) -> bool: ...
    def is_bearish(self) -> bool: ...


class CDLIndicator:
    """Candlestick pattern indicator"""
    
    def update(
        self, open: float, high: float, low: float, close: float
    ) -> CDLResult:
        """Update with OHLC bar, returns CDLResult"""
        ...
    
    def calculate(
        self,
        open: NDArray[np.float64],
        high: NDArray[np.float64],
        low: NDArray[np.float64],
        close: NDArray[np.float64],
    ) -> NDArray[np.int32]:
        """Calculate pattern signals for OHLC arrays"""
        ...
    
    def reset(self) -> None: ...
    def is_ready(self) -> bool: ...
    
    @property
    def lookback(self) -> int: ...
    
    @property
    def name(self) -> str: ...


# CDL factory functions (61 patterns)
# Single candle (12)
def cdl_doji() -> CDLIndicator: ...
def cdl_dragonflydoji() -> CDLIndicator: ...
def cdl_gravestonedoji() -> CDLIndicator: ...
def cdl_longleggeddoji() -> CDLIndicator: ...
def cdl_hammer() -> CDLIndicator: ...
def cdl_invertedhammer() -> CDLIndicator: ...
def cdl_hangingman() -> CDLIndicator: ...
def cdl_shootingstar() -> CDLIndicator: ...
def cdl_marubozu() -> CDLIndicator: ...
def cdl_closingmarubozu() -> CDLIndicator: ...
def cdl_spinningtop() -> CDLIndicator: ...
def cdl_highwave() -> CDLIndicator: ...

# Two candle (15)
def cdl_engulfing() -> CDLIndicator: ...
def cdl_harami() -> CDLIndicator: ...
def cdl_haramicross() -> CDLIndicator: ...
def cdl_piercing() -> CDLIndicator: ...
def cdl_darkcloudcover() -> CDLIndicator: ...
def cdl_belthold() -> CDLIndicator: ...
def cdl_counterattack() -> CDLIndicator: ...
def cdl_homingpigeon() -> CDLIndicator: ...
def cdl_inneck() -> CDLIndicator: ...
def cdl_onneck() -> CDLIndicator: ...
def cdl_matchinglow() -> CDLIndicator: ...
def cdl_kicking() -> CDLIndicator: ...
def cdl_kickingbylength() -> CDLIndicator: ...
def cdl_separatinglines() -> CDLIndicator: ...
def cdl_thrusting() -> CDLIndicator: ...

# Three candle (12)
def cdl_morningstar() -> CDLIndicator: ...
def cdl_eveningstar() -> CDLIndicator: ...
def cdl_morningdojistar() -> CDLIndicator: ...
def cdl_eveningdojistar() -> CDLIndicator: ...
def cdl_3inside() -> CDLIndicator: ...
def cdl_3outside() -> CDLIndicator: ...
def cdl_3whitesoldiers() -> CDLIndicator: ...
def cdl_3blackcrows() -> CDLIndicator: ...
def cdl_3linestrike() -> CDLIndicator: ...
def cdl_abandonedbaby() -> CDLIndicator: ...
def cdl_tristar() -> CDLIndicator: ...
def cdl_identical3crows() -> CDLIndicator: ...

# Complex (12)
def cdl_2crows() -> CDLIndicator: ...
def cdl_advanceblock() -> CDLIndicator: ...
def cdl_breakaway() -> CDLIndicator: ...
def cdl_concealbabyswall() -> CDLIndicator: ...
def cdl_dojistar() -> CDLIndicator: ...
def cdl_gapsidesidewhite() -> CDLIndicator: ...
def cdl_hikkake() -> CDLIndicator: ...
def cdl_hikkakemod() -> CDLIndicator: ...
def cdl_ladderbottom() -> CDLIndicator: ...
def cdl_rickshawman() -> CDLIndicator: ...
def cdl_stalledpattern() -> CDLIndicator: ...
def cdl_sticksandwich() -> CDLIndicator: ...

# Final (10)
def cdl_3starsinsouth() -> CDLIndicator: ...
def cdl_longline() -> CDLIndicator: ...
def cdl_shortline() -> CDLIndicator: ...
def cdl_mathold() -> CDLIndicator: ...
def cdl_risefall3methods() -> CDLIndicator: ...
def cdl_takuri() -> CDLIndicator: ...
def cdl_tasukigap() -> CDLIndicator: ...
def cdl_unique3river() -> CDLIndicator: ...
def cdl_upsidegap2crows() -> CDLIndicator: ...
def cdl_xsidegap3methods() -> CDLIndicator: ...
