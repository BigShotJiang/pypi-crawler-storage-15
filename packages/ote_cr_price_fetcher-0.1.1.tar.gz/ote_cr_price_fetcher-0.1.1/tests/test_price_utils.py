"""Tests for PriceUtils time/slot conversion utilities.

These tests verify the examples provided in each method's docstring.
"""

import logging
from ote_cr_price_fetcher import PriceUtils

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)


def test_slot_to_time_examples():
    """Test slot_to_time conversion."""
    logging.info("Testing slot_to_time conversions")
    assert PriceUtils.slot_to_time(0) == "00:00"
    assert PriceUtils.slot_to_time(1) == "00:15"
    assert PriceUtils.slot_to_time(4) == "01:00"
    assert PriceUtils.slot_to_time(28) == "07:00"
    assert PriceUtils.slot_to_time(95) == "23:45"
    logging.info("✅ slot_to_time tests passed")


def test_time_to_slot_examples():
    """Test time_to_slot conversion."""
    logging.info("Testing time_to_slot conversions")
    assert PriceUtils.time_to_slot(0, 0) == 0
    assert PriceUtils.time_to_slot(0, 15) == 1
    assert PriceUtils.time_to_slot(1, 0) == 4
    assert PriceUtils.time_to_slot(7, 0) == 28
    assert PriceUtils.time_to_slot(23, 45) == 95
    logging.info("✅ time_to_slot tests passed")


def test_time_str_to_slot_examples():
    """Test time_str_to_slot conversion."""
    logging.info("Testing time_str_to_slot conversions")
    assert PriceUtils.time_str_to_slot("00:00") == 0
    assert PriceUtils.time_str_to_slot("07:00") == 28
    assert PriceUtils.time_str_to_slot("12:30") == 50
    logging.info("✅ time_str_to_slot tests passed")


def test_slots_to_time_range_examples():
    """Test slots_to_time_range conversion."""
    logging.info("Testing slots_to_time_range conversions")
    assert PriceUtils.slots_to_time_range(8, 20) == ("02:00", "05:00")
    assert PriceUtils.slots_to_time_range(9, 21) == ("02:15", "05:15")
    logging.info("✅ slots_to_time_range tests passed")


def test_hours_to_slots_examples():
    """Test hours_to_slots conversion."""
    logging.info("Testing hours_to_slots conversions")
    assert PriceUtils.hours_to_slots(1.0) == 4
    assert PriceUtils.hours_to_slots(3.0) == 12
    assert PriceUtils.hours_to_slots(2.5) == 10
    assert PriceUtils.hours_to_slots(0.1) == 1
    logging.info("✅ hours_to_slots tests passed")


def test_slots_to_hours_examples():
    """Test slots_to_hours conversion."""
    logging.info("Testing slots_to_hours conversions")
    assert PriceUtils.slots_to_hours(4) == 1.0
    assert PriceUtils.slots_to_hours(12) == 3.0
    assert PriceUtils.slots_to_hours(1) == 0.25
    logging.info("✅ slots_to_hours tests passed")


def main():
    """Run all PriceUtils tests."""
    print("\n" + "="*60)
    print("PriceUtils Test Suite")
    print("="*60 + "\n")
    
    try:
        test_slot_to_time_examples()
        test_time_to_slot_examples()
        test_time_str_to_slot_examples()
        test_slots_to_time_range_examples()
        test_hours_to_slots_examples()
        test_slots_to_hours_examples()
        
        print("\n" + "="*60)
        print("✅ All PriceUtils tests passed!")
        print("="*60 + "\n")
        return True
    except AssertionError as e:
        logging.error(f"❌ Test failed: {e}")
        print(f"\n❌ Test failed: {e}\n")
        return False
    except Exception as e:
        logging.error(f"❌ Error occurred: {type(e).__name__}: {e}", exc_info=True)
        print(f"\n❌ Error occurred: {type(e).__name__}: {e}\n")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    exit(0 if main() else 1)
