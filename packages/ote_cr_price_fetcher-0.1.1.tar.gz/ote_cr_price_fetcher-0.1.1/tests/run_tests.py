"""Unified test runner for all tests in the ote-cr-price-fetcher package."""

import asyncio
import sys
from pathlib import Path

# Add tests directory to path to allow imports
tests_dir = Path(__file__).parent
sys.path.insert(0, str(tests_dir))

import test_price_fetcher
import test_price_utils


async def run_all_tests():
    """Run all test suites."""
    print("\n" + "="*60)
    print("Running All Tests")
    print("="*60)
    
    results = []
    
    # Run PriceUtils tests (synchronous)
    print("\n[1/2] Running PriceUtils tests...")
    print("-" * 60)
    result1 = test_price_utils.main()
    results.append(("PriceUtils", result1))
    
    # Run PriceFetcher tests (asynchronous)
    print("\n[2/2] Running PriceFetcher tests...")
    print("-" * 60)
    result2 = await test_price_fetcher.main()
    results.append(("PriceFetcher", result2))
    
    # Summary
    print("\n" + "="*60)
    print("Test Summary")
    print("="*60)
    for name, result in results:
        status = "✅ PASSED" if result else "❌ FAILED"
        print(f"{name}: {status}")
    print("="*60 + "\n")
    
    # Return success only if all tests passed
    all_passed = all(result for _, result in results)
    return all_passed


if __name__ == "__main__":
    success = asyncio.run(run_all_tests())
    sys.exit(0 if success else 1)

