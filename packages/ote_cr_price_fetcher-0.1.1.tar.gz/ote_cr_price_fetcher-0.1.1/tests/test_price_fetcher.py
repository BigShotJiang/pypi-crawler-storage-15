"""Test script to verify the ote-cr-price-fetcher package works correctly."""

import asyncio
import datetime
import logging
from ote_cr_price_fetcher import PriceFetcher, PriceDataNotAvailableError

# Set up logging to see what's happening
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)


async def test_fetch_yesterday_prices():
    """Test fetching prices for yesterday's date."""
    fetcher = PriceFetcher()
    
    # Get yesterday's date
    yesterday = datetime.date.today() - datetime.timedelta(days=1)
    
    print(f"\n{'='*60}")
    print(f"Testing OTE-CR Price Fetcher")
    print(f"{'='*60}")
    print(f"Fetching prices for: {yesterday.strftime('%Y-%m-%d')}")
    print(f"{'='*60}\n")
    
    try:
        # Test 15-minute intervals (default)
        prices = await fetcher.fetch_prices_for_date(yesterday)
        
        print(f"✅ Successfully fetched {len(prices)} price points (15-minute intervals)\n")
        
        # Verify we got 96 values for 15-minute intervals
        assert len(prices) == 96, f"Expected 96 15-minute intervals, got {len(prices)}"
        
        # Test hourly format
        hourly_prices = await fetcher.fetch_prices_for_date(yesterday, hourly=True)
        print(f"✅ Successfully fetched {len(hourly_prices)} price points (hourly format)\n")
        
        # Verify we got 24 values for hourly
        assert len(hourly_prices) == 24, f"Expected 24 hourly values, got {len(hourly_prices)}"
        
        # Verify hourly prices are averages of 15-minute intervals
        for hour in range(24):
            start_idx = hour * 4
            expected_avg = sum(prices[start_idx:start_idx+4]) / 4
            actual = hourly_prices[hour]
            assert abs(actual - expected_avg) < 0.01, f"Hour {hour}: expected {expected_avg}, got {actual}"
        
        print("✅ Verified hourly prices match 15-minute averages\n")
        
        print("Sample hourly prices:")
        print("-" * 60)
        for hour, price in enumerate(hourly_prices):
            print(f"{hour:02d}:00 - {price:8.2f} EUR/kWh")
        print("-" * 60)
        
        print("\nSample 15-minute interval prices (first 10 intervals):")
        print("-" * 60)
        # Show first 10 intervals as sample
        for i, price in enumerate(prices[:10]):
            hour = i // 4
            minute = (i % 4) * 15
            print(f"{hour:02d}:{minute:02d} - {price:8.2f} EUR/kWh")
        
        if len(prices) > 10:
            print("...")
            # Show last 5 intervals
            for i in range(len(prices) - 5, len(prices)):
                hour = i // 4
                minute = (i % 4) * 15
                print(f"{hour:02d}:{minute:02d} - {prices[i]:8.2f} EUR/kWh")
        
        if prices:
            print("-" * 60)
            print(f"Average price: {sum(prices) / len(prices):.2f} EUR/kWh")
            min_idx = prices.index(min(prices))
            max_idx = prices.index(max(prices))
            min_hour = min_idx // 4
            min_minute = (min_idx % 4) * 15
            max_hour = max_idx // 4
            max_minute = (max_idx % 4) * 15
            print(f"Min price: {min(prices):.2f} EUR/kWh (at {min_hour:02d}:{min_minute:02d}, interval {min_idx})")
            print(f"Max price: {max(prices):.2f} EUR/kWh (at {max_hour:02d}:{max_minute:02d}, interval {max_idx})")
        
        print(f"\n{'='*60}")
        print("✅ Test passed!")
        print(f"{'='*60}\n")
        return True
        
    except PriceDataNotAvailableError as e:
        print(f"❌ Price data not available: {e}\n")
        print("This might happen if:")
        print("  - The date is too far in the future")
        print("  - Prices haven't been published yet")
        print("  - The API structure has changed")
        return False
        
    except Exception as e:
        print(f"❌ Error occurred: {type(e).__name__}: {e}\n")
        import traceback
        traceback.print_exc()
        return False


async def test_fetch_today_prices():
    """Test fetching prices for today's date (if available)."""
    fetcher = PriceFetcher()
    today = datetime.date.today()
    
    print(f"\n{'='*60}")
    print(f"Testing fetch for today: {today.strftime('%Y-%m-%d')}")
    print(f"{'='*60}\n")
    
    try:
        prices = await fetcher.fetch_prices_for_date(today)
        print(f"✅ Successfully fetched {len(prices)} price points for today (15-minute intervals)\n")
        
        # Test hourly format
        hourly_prices = await fetcher.fetch_prices_for_date(today, hourly=True)
        print(f"✅ Successfully fetched {len(hourly_prices)} hourly price points for today\n")
        assert len(prices) == 96, f"Expected 96 15-minute intervals, got {len(prices)}"
        assert len(hourly_prices) == 24, f"Expected 24 hourly values, got {len(hourly_prices)}"
        
        print("Sample hourly prices for today:")
        print("-" * 60)
        for hour, price in enumerate(hourly_prices):
            print(f"{hour:02d}:00 - {price:8.2f} EUR/kWh")
        print("-" * 60 + "\n")
        
        return True
    except PriceDataNotAvailableError as e:
        print(f"ℹ️  Prices for today not yet available: {e}\n")
        return None  # Not an error, just not available yet
    except Exception as e:
        print(f"❌ Error: {e}\n")
        return False


async def main():
    """Run all tests."""
    print("\n" + "="*60)
    print("OTE-CR Price Fetcher Test Suite")
    print("="*60)
    
    # Test 1: Fetch yesterday's prices (should work)
    result1 = await test_fetch_yesterday_prices()
    
    # Test 2: Try today's prices (might not be available)
    result2 = await test_fetch_today_prices()
    
    # Summary
    print("\n" + "="*60)
    print("Test Summary")
    print("="*60)
    print(f"Yesterday's prices: {'✅ PASSED' if result1 else '❌ FAILED'}")
    if result2 is not None:
        print(f"Today's prices: {'✅ PASSED' if result2 else '❌ FAILED'}")
    else:
        print(f"Today's prices: ℹ️  Not available (expected)")
    print("="*60 + "\n")
    
    # Return True if yesterday's test passed (today's might not be available, which is OK)
    return result1


if __name__ == "__main__":
    asyncio.run(main())

