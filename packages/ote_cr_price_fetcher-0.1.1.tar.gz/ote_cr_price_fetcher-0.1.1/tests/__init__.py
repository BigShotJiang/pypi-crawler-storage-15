"""Tests for ote-cr-price-fetcher package."""

