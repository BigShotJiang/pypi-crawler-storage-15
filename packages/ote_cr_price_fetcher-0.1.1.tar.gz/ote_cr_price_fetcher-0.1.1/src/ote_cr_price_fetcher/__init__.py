"""OTE CR Price Fetcher - A Python package to fetch electricity prices from OTE-CR."""

from .price_fetcher import PriceFetcher, PriceDataNotAvailableError
from .price_utils import PriceUtils

__version__ = "0.1.1"
__all__ = ["PriceFetcher", "PriceDataNotAvailableError", "PriceUtils"]
