import datetime
import logging
from typing import Optional

import backoff
import httpx


class PriceDataNotAvailableError(Exception):
    """Raised when price data is not yet available for the requested date"""
    pass


class PriceFetcher:
    """Fetches electricity prices from OTE-CR (Czech electricity market operator).
    Provides async interface with automatic retry logic and error handling.
    """

    DEFAULT_PRICE_URL = "https://www.ote-cr.cz/en/short-term-markets/electricity/day-ahead-market/@@chart-data?report_date="
    DEFAULT_TIMEOUT = 10.0
    DEFAULT_CONNECT_TIMEOUT = 60.0
    DEFAULT_MAX_RETRY_TIME = 120

    def __init__(
            self,
            price_url: Optional[str] = None,
            timeout: Optional[float] = None,
            connect_timeout: Optional[float] = None,
            max_retry_time: Optional[int] = None,
    ):
        """Initialize PriceFetcher with optional configuration.
        Args:
            price_url: Base URL for fetching prices. Defaults to OTE-CR URL.
            timeout: Request timeout in seconds. Defaults to 10.0.
            connect_timeout: Connection timeout in seconds. Defaults to 60.0.
            max_retry_time: Maximum time in seconds for retry attempts. Defaults to 120.
        """
        self.price_url = price_url or self.DEFAULT_PRICE_URL
        timeout_val = timeout if timeout is not None else self.DEFAULT_TIMEOUT
        connect_timeout_val = connect_timeout if connect_timeout is not None else self.DEFAULT_CONNECT_TIMEOUT
        self.timeout = httpx.Timeout(timeout_val, connect=connect_timeout_val)
        self.max_retry_time = max_retry_time or self.DEFAULT_MAX_RETRY_TIME

    async def fetch_prices_for_date(self, date: datetime.date, hourly: bool = False) -> list[float]:
        """Fetch electricity prices for a specific date.
        Args:
            date: The date to fetch prices for.
            hourly: If True, return hourly averages (24 values). If False, return 15-minute intervals (96 values). Defaults to False.
        Returns:
            List of electricity prices. 96 values for 15-minute intervals, 24 for hourly.
        Raises:
            PriceDataNotAvailableError: If price data is not yet available.
            httpx.RequestError: If the HTTP request fails.
            httpx.HTTPStatusError: If the HTTP response indicates an error.
        """
        url_date = date.strftime("%Y-%m-%d")
        url = self.price_url + url_date
        logging.info(f"Fetching prices from URL: {url}")

        try:
            logging.info(f"Making HTTP request for date: {url_date}")
            response = await self._get_request_with_backoff(url)
            logging.info(f"Received response with status: {response.status_code}")

            logging.info("Parsing JSON response")
            json_data = response.json()
            prices = self._get_prices_from_json(json_data)
            logging.info(f"Successfully parsed {len(prices)} price points")

            if hourly:
                prices = self._convert_to_hourly(prices)
                logging.info(f"Converted to {len(prices)} hourly values")

            return prices

        except (httpx.RequestError, httpx.HTTPStatusError) as exc:
            logging.error(
                f"Failed to fetch data from {exc.request.url!r} after retries: {exc}"
            )
            raise
        except PriceDataNotAvailableError as e:
            logging.warning(f"Price data not available for {url_date}: {e}")
            # Re-raise with a more user-friendly message
            raise PriceDataNotAvailableError(
                f"Tomorrow's electricity prices are not yet published. "
                f"Prices are typically available around 3 PM. Please try again later."
            )
        except Exception as e:
            logging.error(f"An unexpected error occurred: {e}", exc_info=True)
            raise

    async def _get_request_with_backoff(self, url: str) -> httpx.Response:
        """Make HTTP GET request with exponential backoff retry logic.
        Args:
            url: The URL to fetch.
        Returns:
            The HTTP response.
        Raises:
            httpx.RequestError: If the request fails after all retries.
            httpx.HTTPStatusError: If the response status is an error code.
        """

        @backoff.on_exception(
            backoff.expo,
            (httpx.RequestError, httpx.HTTPStatusError, httpx.ReadTimeout),
            max_time=self.max_retry_time,
        )
        async def _make_request():
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(url)
                response.raise_for_status()
                return response

        return await _make_request()

    @staticmethod
    def _convert_to_hourly(prices_15m: list[float]) -> list[float]:
        """Convert 15-minute interval prices to hourly averages.
        Args:
            prices_15m: List of 96 prices in 15-minute intervals.
        Returns:
            List of 24 hourly average prices.
        """
        if len(prices_15m) != 96:
            raise ValueError(f"Expected 96 15-minute intervals, got {len(prices_15m)}")

        hourly_prices = []
        for hour in range(24):
            start_idx = hour * 4
            end_idx = start_idx + 4
            hour_prices = prices_15m[start_idx:end_idx]
            hourly_prices.append(sum(hour_prices) / len(hour_prices))

        return hourly_prices

    @staticmethod
    def _get_prices_from_json(prices_json: dict) -> list[float]:
        """Extract price values from JSON response structure.
        Args:
            prices_json: The JSON response from the OTE-CR API.
        Returns:
            List of electricity prices in 15-minute intervals (96 values).
        Raises:
            PriceDataNotAvailableError: If the JSON structure is invalid or incomplete.
        """
        try:
            # Check if the data structure is as expected
            if "data" not in prices_json:
                raise PriceDataNotAvailableError("No 'data' field found in price response")

            if "dataLine" not in prices_json["data"]:
                raise PriceDataNotAvailableError("No 'dataLine' field found in price response")

            data_line = prices_json["data"]["dataLine"]

            # Check if dataLine has at least 2 elements (index 0 and 1)
            if len(data_line) < 2:
                raise PriceDataNotAvailableError("Price data not yet available - dataLine array is too short")

            # Check if the second element (index 1) has the expected structure
            if "point" not in data_line[1]:
                raise PriceDataNotAvailableError("Price data not yet available - no 'point' field in dataLine[1]")

            points = data_line[1]["point"]

            # Check if points array is empty
            if not points:
                raise PriceDataNotAvailableError("Price data not yet available - points array is empty")

            # Extract prices from the points
            prices = []
            for point in points:
                if "y" not in point:
                    raise PriceDataNotAvailableError("Price data not yet available - missing 'y' field in point data")
                prices.append(float(point["y"]))

            return prices

        except (KeyError, IndexError, TypeError) as e:
            # Handle any structural issues with the JSON
            raise PriceDataNotAvailableError(f"Price data not yet available - unexpected data structure: {str(e)}")
        except ValueError as e:
            # Handle conversion errors
            raise PriceDataNotAvailableError(f"Price data not yet available - invalid price values: {str(e)}")
