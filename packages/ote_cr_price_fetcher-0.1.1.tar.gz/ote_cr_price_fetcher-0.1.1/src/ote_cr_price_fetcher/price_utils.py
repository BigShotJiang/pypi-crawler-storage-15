"""
Slot/Time Conversion Utilities for 15-minute price intervals

This module provides utilities for working with 15-minute time slots (0-95)
used in electricity pricing data.

Slot mapping:
- Slot 0  = 00:00
- Slot 1  = 00:15
- Slot 2  = 00:30
- Slot 3  = 00:45
- Slot 4  = 01:00
- ...
- Slot 28 = 07:00
- Slot 48 = 12:00
- Slot 95 = 23:45

Each day has 96 slots (24 hours * 4 slots per hour).
"""

from typing import Tuple


class PriceUtils:
    """
    Static utilities for working with 15-minute time slots (0-95).

    Define functionality once here as static methods so the class can be imported
    and used directly: `from ote_cr_price_fetcher import PriceUtils`.
    """

    @staticmethod
    def slot_to_time(slot: int) -> str:
        """
        Convert slot index (0-95) to HH:MM format.

        Args:
            slot: Slot index (0-95)

        Returns:
            Time string in HH:MM format

        Examples:
            >>> PriceUtils.slot_to_time(0)
            '00:00'
            >>> PriceUtils.slot_to_time(1)
            '00:15'
            >>> PriceUtils.slot_to_time(4)
            '01:00'
            >>> PriceUtils.slot_to_time(28)
            '07:00'
            >>> PriceUtils.slot_to_time(95)
            '23:45'
        """
        hour = slot // 4
        minute = (slot % 4) * 15
        return f"{hour:02d}:{minute:02d}"

    @staticmethod
    def time_to_slot(hour: int, minute: int = 0) -> int:
        """
        Convert hour and minute to slot index (0-95).

        Args:
            hour: Hour (0-23)
            minute: Minute (0, 15, 30, or 45). Will be rounded down to nearest 15.

        Returns:
            Slot index (0-95)

        Examples:
            >>> PriceUtils.time_to_slot(0, 0)
            0
            >>> PriceUtils.time_to_slot(0, 15)
            1
            >>> PriceUtils.time_to_slot(1, 0)
            4
            >>> PriceUtils.time_to_slot(7, 0)
            28
            >>> PriceUtils.time_to_slot(23, 45)
            95
        """
        return hour * 4 + minute // 15

    @staticmethod
    def time_str_to_slot(time_str: str) -> int:
        """
        Convert time string (HH:MM) to slot index.

        Args:
            time_str: Time in HH:MM format

        Returns:
            Slot index (0-95)

        Examples:
            >>> PriceUtils.time_str_to_slot("00:00")
            0
            >>> PriceUtils.time_str_to_slot("07:00")
            28
            >>> PriceUtils.time_str_to_slot("12:30")
            50
        """
        parts = time_str.split(":")
        hour = int(parts[0])
        minute = int(parts[1]) if len(parts) > 1 else 0
        return PriceUtils.time_to_slot(hour, minute)

    @staticmethod
    def slots_to_time_range(start_slot: int, end_slot: int) -> Tuple[str, str]:
        """
        Convert slot range to time range strings.

        Args:
            start_slot: Starting slot index
            end_slot: Ending slot index (exclusive)

        Returns:
            Tuple of (start_time, end_time) in HH:MM format

        Examples:
            >>> PriceUtils.slots_to_time_range(8, 20)
            ('02:00', '05:00')
            >>> PriceUtils.slots_to_time_range(9, 21)
            ('02:15', '05:15')
        """
        return (PriceUtils.slot_to_time(start_slot), PriceUtils.slot_to_time(end_slot))

    @staticmethod
    def hours_to_slots(hours: float) -> int:
        """
        Convert hours to number of 15-minute slots.

        Args:
            hours: Duration in hours

        Returns:
            Number of 15-minute slots (minimum 1)

        Examples:
            >>> PriceUtils.hours_to_slots(1.0)
            4
            >>> PriceUtils.hours_to_slots(3.0)
            12
            >>> PriceUtils.hours_to_slots(2.5)
            10
            >>> PriceUtils.hours_to_slots(0.1)
            1
        """
        slots = int(round(hours * 4))
        return max(1, slots)

    @staticmethod
    def slots_to_hours(slots: int) -> float:
        """
        Convert number of slots to hours.

        Args:
            slots: Number of 15-minute slots

        Returns:
            Duration in hours

        Examples:
            >>> PriceUtils.slots_to_hours(4)
            1.0
            >>> PriceUtils.slots_to_hours(12)
            3.0
            >>> PriceUtils.slots_to_hours(1)
            0.25
        """
        return slots / 4


# Common slot constants for readability
SLOT_MIDNIGHT = 0  # 00:00
SLOT_1AM = 4  # 01:00
SLOT_2AM = 8  # 02:00
SLOT_3AM = 12  # 03:00
SLOT_4AM = 16  # 04:00
SLOT_5AM = 20  # 05:00
SLOT_6AM = 24  # 06:00
SLOT_7AM = 28  # 07:00
SLOT_8AM = 32  # 08:00
SLOT_9AM = 36  # 09:00
SLOT_10AM = 40  # 10:00
SLOT_11AM = 44  # 11:00
SLOT_NOON = 48  # 12:00
SLOT_1PM = 52  # 13:00
SLOT_2PM = 56  # 14:00
SLOT_3PM = 60  # 15:00
SLOT_4PM = 64  # 16:00
SLOT_5PM = 68  # 17:00
SLOT_6PM = 72  # 18:00
SLOT_7PM = 76  # 19:00
SLOT_8PM = 80  # 20:00
SLOT_9PM = 84  # 21:00
SLOT_10PM = 88  # 22:00
SLOT_11PM = 92  # 23:00
SLOTS_PER_DAY = 96  # Total slots in a day
SLOTS_PER_HOUR = 4  # Slots per hour
