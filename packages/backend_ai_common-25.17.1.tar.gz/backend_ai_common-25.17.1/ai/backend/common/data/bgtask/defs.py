TASK_METADATA_TTL = 60 * 60 * 24  # 24 hours
TASK_TTL_THRESHOLD = TASK_METADATA_TTL - 60 * 5  # 5 minutes margin
TASK_FINISHED_TTL = 60  # 1 minutes for finished tasks
