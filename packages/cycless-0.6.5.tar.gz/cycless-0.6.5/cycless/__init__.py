# -*- coding: utf-8 -*-
"""
.. include:: ../README.md
"""
