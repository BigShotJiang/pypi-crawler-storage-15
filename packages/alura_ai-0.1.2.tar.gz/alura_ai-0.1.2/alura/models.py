"""
Data models for Alura SDK
"""
from dataclasses import dataclass, field
from typing import Optional, Dict, Any
from datetime import datetime


@dataclass
class Signal:
    """Represents a trackable event/signal"""
    event_name: str
    agent_id: str
    customer_id: Optional[str] = None
    data: Dict[str, Any] = field(default_factory=dict)
    external_id: Optional[str] = None
    timestamp: Optional[datetime] = None
    
    def to_dict(self) -> dict:
        """Convert to API payload"""
        payload = {
            "agent_code": self.agent_id,
            "event_name": self.event_name,
            "data": self.data,
        }
        if self.external_id:
            payload["external_id"] = self.external_id
        if self.timestamp:
            payload["timestamp"] = self.timestamp.isoformat()
        if self.customer_id:
            payload["data"]["customer_id"] = self.customer_id
        return payload

