"""
Main Alura client for tracking AI usage and costs
"""
import requests
from typing import Optional, List, Callable, Any, TypeVar
from contextlib import contextmanager
from contextvars import ContextVar
from .models import Signal

# Context variable for current trace
_current_trace: ContextVar[Optional[dict]] = ContextVar('current_trace', default=None)

T = TypeVar('T')


class AluraError(Exception):
    """Base exception for Alura SDK"""
    pass


class AuthenticationError(AluraError):
    """Invalid API key"""
    pass


class APIError(AluraError):
    """API request failed"""
    def __init__(self, message: str, status_code: int = None, response: dict = None):
        super().__init__(message)
        self.status_code = status_code
        self.response = response


class Alura:
    """
    Main client for Alura AI usage tracking.
    
    Usage (context manager style):
        from alura import Alura, AluraOpenAI
        from openai import OpenAI
        
        client = Alura(api_key="your-alura-api-key")
        openai_client = OpenAI(api_key="your-openai-key")
        alura_openai = AluraOpenAI(openai_client, client)
        
        with client.trace(customer_id="cust-123", agent_id="chatbot"):
            response = alura_openai.chat.completions.create(
                model="gpt-4",
                messages=[{"role": "user", "content": "Hello!"}]
            )
    
    Usage (callback style - Paid AI compatible):
        result = client.trace(
            external_customer_id="cust-123",
            external_agent_id="chatbot",
            fn=lambda: alura_openai.chat.completions.create(...)
        )
    """
    
    def __init__(
        self,
        api_key: str = None,
        token: str = None,  # Paid AI compatibility alias
        base_url: str = "https://aluraai.com",
    ):
        # Support both api_key and token (Paid AI uses token)
        self.api_key = api_key or token
        if not self.api_key:
            raise ValueError("api_key (or token) is required")
        
        self.base_url = base_url.rstrip('/')
        
        # Paid AI compatible usage namespace
        self.usage = _UsageNamespace(self)
    
    def initialize_tracing(self):
        """
        Initialize tracing (Paid AI compatibility).
        In Alura, tracing is always active - this is a no-op for compatibility.
        """
        pass
    
    def _request(
        self,
        method: str,
        endpoint: str,
        json: dict = None,
    ) -> dict:
        """Make HTTP request to Alura API"""
        url = f"{self.base_url}{endpoint}"
        headers = {
            "Authorization": f"Api-Key {self.api_key}",
            "Content-Type": "application/json",
        }
        
        try:
            response = requests.request(
                method=method,
                url=url,
                headers=headers,
                json=json,
                timeout=30,
            )
            
            if response.status_code == 401:
                raise AuthenticationError("Invalid API key")
            
            if not response.ok:
                error_msg = "API request failed"
                try:
                    error_data = response.json()
                    if "error" in error_data:
                        error_msg = error_data["error"]
                except:
                    error_msg = response.text or f"HTTP {response.status_code}"
                raise APIError(error_msg, response.status_code, response.json() if response.text else None)
            
            return response.json()
            
        except requests.exceptions.RequestException as e:
            raise APIError(f"Request failed: {str(e)}")
    
    def trace(
        self,
        customer_id: str = None,
        agent_id: str = None,
        # Paid AI compatibility aliases
        external_customer_id: str = None,
        external_agent_id: str = None,
        fn: Callable[[], T] = None,
    ) -> T:
        """
        Trace AI calls with customer/agent context.
        
        Can be used as context manager OR with callback function (Paid AI style).
        
        Context manager usage:
            with client.trace(customer_id="cust-123", agent_id="chatbot"):
                response = alura_openai.chat.completions.create(...)
        
        Callback usage (Paid AI compatible):
            result = client.trace(
                external_customer_id="cust-123",
                external_agent_id="chatbot",
                fn=lambda: make_openai_call()
            )
        """
        # Support Paid AI parameter names
        customer_id = customer_id or external_customer_id
        agent_id = agent_id or external_agent_id
        
        # If fn is provided, use callback style (Paid AI compatible)
        if fn is not None:
            return self._trace_with_callback(customer_id, agent_id, fn)
        
        # Otherwise return context manager
        return self._trace_context(customer_id, agent_id)
    
    def _trace_with_callback(
        self,
        customer_id: str,
        agent_id: str,
        fn: Callable[[], T],
    ) -> T:
        """Execute function within trace context (Paid AI style)"""
        trace_context = {
            "customer_id": customer_id,
            "agent_id": agent_id,
        }
        token = _current_trace.set(trace_context)
        try:
            return fn()
        finally:
            _current_trace.reset(token)
    
    @contextmanager
    def _trace_context(
        self,
        customer_id: str,
        agent_id: str,
    ):
        """Context manager for tracing AI calls"""
        trace_context = {
            "customer_id": customer_id,
            "agent_id": agent_id,
        }
        token = _current_trace.set(trace_context)
        try:
            yield trace_context
        finally:
            _current_trace.reset(token)
    
    def signal(
        self,
        event_name: str,
        agent_id: str = None,
        data: dict = None,
        customer_id: str = None,
    ) -> dict:
        """
        Record a single signal/event.
        
        Args:
            event_name: Name of the event (e.g., "llm_call", "email_sent")
            agent_id: Agent code (uses trace context if not provided)
            data: Event-specific data
            customer_id: Customer ID (uses trace context if not provided)
        """
        # Get from trace context if not provided
        trace = _current_trace.get()
        if trace:
            agent_id = agent_id or trace.get("agent_id")
            customer_id = customer_id or trace.get("customer_id")
        
        if not agent_id:
            raise ValueError("agent_id is required (provide directly or use trace() context)")
        
        payload = {
            "agent_code": agent_id,
            "event_name": event_name,
            "data": data or {},
        }
        
        if customer_id:
            payload["data"]["customer_id"] = customer_id
        
        return self._request("POST", "/api/tracking/signals/", json=payload)
    
    def signal_bulk(self, signals: List[Signal]) -> dict:
        """
        Record multiple signals in a single request.
        
        Args:
            signals: List of Signal objects
        """
        payload = {
            "signals": [s.to_dict() for s in signals]
        }
        return self._request("POST", "/api/tracking/signals/bulk_create/", json=payload)
    
    @staticmethod
    def get_current_trace() -> Optional[dict]:
        """Get the current trace context (used by wrappers)"""
        return _current_trace.get()


class _UsageNamespace:
    """Paid AI compatible usage namespace for client.usage.record_bulk()"""
    
    def __init__(self, client: Alura):
        self._client = client
    
    def record_bulk(self, signals: List[Signal]) -> dict:
        """
        Record multiple signals in a single request (Paid AI compatible).
        
        Args:
            signals: List of Signal objects
            
        Usage:
            from alura import Alura, Signal
            
            client = Alura(token="your-key")
            
            signal = Signal(
                event_name="using_chat_prompt",
                agent_id="ai-sdk-chatbot-id",
                customer_id="onboarding-test-customer",
                data={"custom_metric": "value"}
            )
            
            client.usage.record_bulk(signals=[signal])
        """
        return self._client.signal_bulk(signals)

