from .dataframe import OutlierAccessor

__all__ = [
    "OutlierAccessor"
]