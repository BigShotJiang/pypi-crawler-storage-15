import pandas as pd
import numpy as np
from typing import Optional, List
from ..exceptions import InvalidColumnException, HandlingException



# -----------------------------------------------------------
#                        validate input
# -----------------------------------------------------------

def validate_input(
        df: pd.DataFrame, 
        detector_name: str, 
        columns: Optional[List[str]],
        exclude: Optional[List[str]] = None
) -> List[str]:
    """
    Check if dataframe is valid and columns exist.
    
    Args:
        df (pd.DataFrame): The DataFrame to be validated.
        detector_name (str): The name of the detector.
        columns (Optional[List[str]]): A list of strings passed for checking.
    """

    # Basic Type Check
    if not isinstance(df, pd.DataFrame):
        raise TypeError(f"[{detector_name}] Input must be a pandas DataFrame, got {type(df).__name__}")

    # Check if DataFrame is empty
    if df.empty:
        raise InvalidColumnException(
            method = detector_name,
            error_code = "ICE007",
            suggestion = "Please input a non-empty DataFrame"
        )

    # Check for duplicated columns
    if df.columns.duplicated().any():
        dup_list = df.columns[df.columns.duplicated()].unique().to_list()
        raise InvalidColumnException(
            method = detector_name,
            duplicated = dup_list
        )


    cols_to_check: List[str] = []

    # Auto-select columns if None provided
    if columns is None:
        cols_to_check = df.select_dtypes(include=[np.number]).columns.tolist()
        
        # If still empty, it means no numeric data exists in the whole DF
        if not cols_to_check:
            raise InvalidColumnException(
                method = detector_name,
                no_numeric = True                 # Flags the no_numeric into True, raises ICE002
            )
    else:
        cols_to_check = columns

        # Flags if user input an empty list. Default is None
        if not cols_to_check:
            raise InvalidColumnException(
                method = detector_name,
                error_code = "ICE000",
                suggestion = "You provided an empty list of columns. Please specify columns."
            )
        
        # Flags if user input duplicate column names. Example ["age", "age"]
        if len(cols_to_check) != len(set(cols_to_check)):
            seen = set()
            dupes = [x for x in cols_to_check if x in seen or seen.add(x)]
            raise InvalidColumnException(
                error_code = "ICE005",
                method = detector_name,
                duplicated = dupes,
                suggestion = "Remove duplicate column names from your configuration list."
            )               

    # Apply the exclusion
    final_cols = cols_to_check.copy()

    if exclude:
        # Create a list that contains only the columns NOT in the exclude list
        final_cols = [col for col in final_cols if col not in exclude]

    # Check if any columns are left for analysis after exclusion
    if not final_cols:
        raise InvalidColumnException(
             method=detector_name,
             error_code="ICE002",
             suggestion="No numeric columns left for analysis after filtering and exclusion."
        )

    # Validate specific columns
    missing_cols = []
    invalid_cols = []
    nan_inf_cols = []

    for col in final_cols:
        # Check if column/s are missing
        if col not in df.columns:
            missing_cols.append(col)
        # Check if existing column is actually numeric
        elif not pd.api.types.is_numeric_dtype(df[col]):
            invalid_cols.append(col)
        # Check if NaNs exist in rows and empty columns
        elif df[col].isna().any() or np.isinf(df[col]).any():
            nan_inf_cols.append(col)

    # Raise Exception if ANY more issues found
    if missing_cols or invalid_cols or nan_inf_cols:
        raise InvalidColumnException(
            method = detector_name,
            missing = missing_cols,
            invalid = invalid_cols,
            nan_cols = nan_inf_cols
        )
    
    return final_cols


# under utilized
# -----------------------------------------------------------
#                       validate strategy 
# -----------------------------------------------------------

def validate_strategy(allowed_methods: Optional[List[str]], method_using: str):
    """
        Validate that the chosen strategy is allowed.

        Args:
            allowed_methods (Optional[List[str]]): List of allowed strategy.
            method_using (str): The method currently being used.
    """
    
    if allowed_methods is None: 
            return # no restrictions
        
    if method_using not in allowed_methods:
        raise HandlingException(
            error_code = "HEX000",
            method = method_using,
            typed_method = method_using,
            allowed_methods = allowed_methods
        )