# sufibot

Ultra-fast Telegram member adder by Sufiyan.

## Usage

```python
import sufibot

sufibot.take = "sourcegroup"
sufibot.add = "targetgroup"
sufibot.limit = 50

sufibot.start()