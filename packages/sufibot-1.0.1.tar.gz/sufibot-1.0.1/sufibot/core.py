take = None
add = None
limit = 0