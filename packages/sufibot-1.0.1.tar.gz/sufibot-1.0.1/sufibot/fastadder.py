import time
from telethon.sync import TelegramClient
from telethon.tl import functions
import sufibot.core as core

SESSION = "sufi-god.session"
API_ID = 29518169
API_HASH = "3cd15c9c2a73b49a168b2f259ad987fe"

def start():
    client = TelegramClient(SESSION, API_ID, API_HASH)
    client.start() #Fixed By Sufiyan
        source = client.get_entity(core.take)
        target = client.get_entity(core.add)
        members = client.get_participants(source)

        c = 0
        for m in members:
            if c >= core.limit:
                break
            if m.bot:
                continue
            try:
                client(functions.channels.InviteToChannelRequest(target, [m]))
                c += 1
                time.sleep(0.5)
            except:
                time.sleep(0.5)
                continue