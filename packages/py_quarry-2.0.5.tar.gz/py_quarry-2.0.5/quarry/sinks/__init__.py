"""Sinks package."""
