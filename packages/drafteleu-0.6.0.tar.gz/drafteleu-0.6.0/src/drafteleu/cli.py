import argparse
import logging
from pathlib import Path
import asyncio

import yaml

from drafteleu.main import run_drafteleu


def main():
    parser = argparse.ArgumentParser(description="Drafteleu CLI")
    parser.add_argument(
        "repo_slug", type=str, help="GitHub repository slug (e.g., user/repo)"
    )
    parser.add_argument(
        "--stage",
        choices=["pre", "final", "both"],
        default="both",
        help="Process only prereleases, only final releases, or both (default: both)",
    )
    parser.add_argument(
        "--verbosity",
        "-v",
        type=int,
        choices=[0, 1, 2],
        default=1,
        help="Set verbosity level: 0 = none, 1 = info, 2 = debug (default: 1)",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Run the script without making any changes (for testing)",
    )
    parser.add_argument(
        "--config",
        type=Path,
        default="drafteleu.yaml",
        help="Path to configuration file (optional)",
    )

    args = parser.parse_args()

    if not args.config.exists():
        raise FileNotFoundError(f"Configuration file not found: {args.config}")

    if args.verbosity == 0:
        logging.basicConfig(level=logging.WARNING)
    elif args.verbosity == 1:
        logging.basicConfig(level=logging.INFO)
    else:
        logging.basicConfig(level=logging.DEBUG)

    configurations = list(
        yaml.safe_load_all(args.config.read_text()) if args.config else []
    )

    asyncio.run(
        run_drafteleu(
            args.repo_slug,
            stage=args.stage,
            dry_run=args.dry_run,
            configurations=configurations,
        )
    )


if __name__ == "__main__":
    main()
