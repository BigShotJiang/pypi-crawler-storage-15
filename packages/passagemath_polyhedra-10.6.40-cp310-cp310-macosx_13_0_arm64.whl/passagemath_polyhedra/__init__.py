# sage_setup: distribution = sagemath-polyhedra

from sage.all__sagemath_polyhedra import *
