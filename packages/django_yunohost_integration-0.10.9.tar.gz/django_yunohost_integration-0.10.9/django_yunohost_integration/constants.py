from pathlib import Path

import django_yunohost_integration


CLI_EPILOG = 'Project Homepage: https://github.com/YunoHost-Apps/django_yunohost_integration'

BASE_PATH = Path(django_yunohost_integration.__file__).parent
