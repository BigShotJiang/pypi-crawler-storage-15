"""
    django_yunohost_integration
    Glue code to package django projects as yunohost apps.
"""

# See https://packaging.python.org/en/latest/specifications/version-specifiers/
__version__ = '0.10.9'
__author__ = 'Jens Diemer <git@jensdiemer.de>'
