# pyfrontkit/css/create_color/__init__.py

# Expose CreateColor
from .create_colors import CreateColor
from .create_colors import CreateWithColor

# Expose palettes dictionary
from .palettes import *  


from .colors_templates import *
