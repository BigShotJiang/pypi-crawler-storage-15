Models
======

UK
    URL pattern based model.

US
    NYT model.

