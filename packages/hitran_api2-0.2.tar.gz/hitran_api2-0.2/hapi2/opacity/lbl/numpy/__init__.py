from hapi import absorptionCoefficient_Voigt
from hapi import absorptionCoefficient_Lorentz
from hapi import absorptionCoefficient_Doppler
from hapi import absorptionCoefficient_Generic
