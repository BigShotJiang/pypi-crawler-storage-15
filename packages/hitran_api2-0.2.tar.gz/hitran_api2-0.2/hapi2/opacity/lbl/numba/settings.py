FASTMATH = True
PARALLEL = True # experimental feature, keep inactive