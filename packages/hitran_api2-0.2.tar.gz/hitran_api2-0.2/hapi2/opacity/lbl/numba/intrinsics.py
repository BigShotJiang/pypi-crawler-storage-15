import numpy as np

dexp = np.exp
dlog = np.log
dsqrt = np.sqrt
datan = np.arctan
dcmplx = complex
dimag = np.imag
dreal = np.real
dabs = np.abs
#dmax1 = np.max
#dmin1 = np.min
dmax1 = max
dmin1 = min
cdabs = np.abs
cdsqrt = np.sqrt
