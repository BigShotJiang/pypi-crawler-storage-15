- Create new sales quotation as per normal process
- Select option "Use Invoice Plan", a new Invoice Plan tab will appear
- Click on "=\> Create Invoice Plan" link to open invoice planning
  wizard
- Do plan for number of installment and/or advance, start date and
  interval
- Double check that each advance/installment has correct plan percentage
- After confirm sales order, now we have new option to "Create Invoice
  by Plan"
- User can create only next invoice, or create all the rest invoices at
  the same time
