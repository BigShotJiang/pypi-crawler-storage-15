"""MCP Server for Spamshieldpro"""
