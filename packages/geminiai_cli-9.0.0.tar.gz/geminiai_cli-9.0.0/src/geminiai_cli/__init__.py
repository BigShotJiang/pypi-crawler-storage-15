# src/geminiai_cli/__init__.py

