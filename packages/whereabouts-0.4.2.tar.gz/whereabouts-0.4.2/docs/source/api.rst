.. _api:

Developer Interface
===================

Matcher Class
-------------
.. autoclass:: whereabouts.Matcher.Matcher
   :inherited-members:

MatcherPipeline Class
---------------------
.. autoclass:: whereabouts.MatcherPipeline.MatcherPipeline
   :inherited-members:
