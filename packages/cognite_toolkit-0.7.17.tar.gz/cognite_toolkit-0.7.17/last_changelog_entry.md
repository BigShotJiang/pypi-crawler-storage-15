## Changelog 

### Added

- [alpha] Support for downloading datapoints, `cdf data download
datapoints`.