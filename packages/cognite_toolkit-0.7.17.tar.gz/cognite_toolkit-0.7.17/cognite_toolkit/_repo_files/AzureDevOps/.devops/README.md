# Verify and deploy modules in Azure DevOps Pipelines

Setting up Pipelines requires some additional steps in Azure DevOps.

Please follow the CI/CD guide in the [deployment documentation](https://docs.cognite.com/cdf/deploy/cdf_toolkit/).
