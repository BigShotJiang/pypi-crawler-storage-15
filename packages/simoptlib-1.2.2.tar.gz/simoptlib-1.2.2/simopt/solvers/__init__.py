"""Init file for solvers module."""
