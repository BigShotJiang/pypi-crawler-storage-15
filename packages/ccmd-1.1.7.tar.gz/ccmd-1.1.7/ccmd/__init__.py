"""CCMD - Cross-platform Command Manager"""

__version__ = "1.1.7"
__author__ = "De Catalyst"
