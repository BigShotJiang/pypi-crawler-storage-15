"""
Configuration module for Planner Agent
Centralizes all environment variables and configuration settings
"""

import os
import json
from pathlib import Path
from typing import Optional

from a2a.types import AgentCard


class AgentConfig:
    """Configuration class for Planner Agent"""
    
    # Agent Identity
    AGENT_NAME: str = "planner"
    AGENT_DISPLAY_NAME: str = "Planner Agent"
    AGENT_DESCRIPTION: str = "Decomposes tasks and assigns agents"
    
    # Ports
    AGENT_PORT: int = int(os.getenv('AGENT_PORT', '11437'))
    SERVICE_PORT: int = int(os.getenv('SERVICE_PORT', '11437'))
    
    # Model Configuration
    MODEL_NAME: str = os.getenv('MODEL_NAME', 'qwen2.5:3b')
    OLLAMA_HOST: str = os.getenv('OLLAMA_HOST', 'http://localhost:11434')
    
    # Logging
    LOG_LEVEL: str = os.getenv('LOG_LEVEL', 'INFO')
    
    # ABI Configuration
    ABI_ROLE: str = os.getenv('ABI_ROLE', 'Planner Agent')
    ABI_NODE: str = os.getenv('ABI_NODE', 'ABI Node')
    
    # Semantic Layer / MCP
    SEMANTIC_LAYER_HOST: str = os.getenv('SEMANTIC_LAYER_HOST', 'http://localhost:10100')
    MCP_HOST: str = os.getenv('MCP_HOST', 'localhost')
    MCP_PORT: int = int(os.getenv('MCP_PORT', '10100'))
    MCP_TRANSPORT: str = os.getenv('MCP_TRANSPORT', 'sse')
    
    # Agent Card
    AGENT_CARD: str = os.getenv('AGENT_CARD', './agent_cards/planner_agent.json')
    
    # A2A Validation
    A2A_VALIDATION_MODE: str = os.getenv('A2A_VALIDATION_MODE', 'permissive')
    A2A_ENABLE_AUDIT_LOG: bool = os.getenv('A2A_ENABLE_AUDIT_LOG', 'true').lower() == 'true'
    GUARDIAN_URL: str = os.getenv('GUARDIAN_URL', 'http://localhost:11438')
    OPA_URL: str = os.getenv('OPA_URL', 'http://localhost:8181')
    
    # Ollama Configuration (for distributed mode)
    START_OLLAMA: bool = os.getenv('START_OLLAMA', 'false').lower() == 'true'
    LOAD_MODELS: bool = os.getenv('LOAD_MODELS', 'false').lower() == 'true'
    
    # Service Module
    SERVICE_MODULE: str = os.getenv('SERVICE_MODULE', 'main')
    
    @classmethod
    def get_ollama_url(cls) -> str:
        """Get the complete Ollama URL"""
        return cls.OLLAMA_HOST
    
    @classmethod
    def get_semantic_layer_url(cls) -> str:
        """Get the complete Semantic Layer URL"""
        return cls.SEMANTIC_LAYER_HOST
    
    @classmethod
    def is_distributed_mode(cls) -> bool:
        """Check if running in distributed Ollama mode"""
        return cls.START_OLLAMA
    
    @classmethod
    def display_config(cls) -> dict:
        """Return configuration as dictionary for display"""
        return {
            'agent_name': cls.AGENT_NAME,
            'agent_display_name': cls.AGENT_DISPLAY_NAME,
            'agent_port': cls.AGENT_PORT,
            'model_name': cls.MODEL_NAME,
            'ollama_host': cls.OLLAMA_HOST,
            'semantic_layer_host': cls.SEMANTIC_LAYER_HOST,
            'log_level': cls.LOG_LEVEL,
            'distributed_mode': cls.is_distributed_mode()
        }


# Create a singleton instance
config = AgentConfig()


# Load agent card at module import time
def _load_agent_card() -> AgentCard:
    """
    Load and validate the agent card from file
    
    Returns:
        AgentCard: The loaded agent card object
        
    Raises:
        FileNotFoundError: If agent card file doesn't exist
        json.JSONDecodeError: If agent card JSON is invalid
        ValueError: If agent card name doesn't match expected
    """
    card_path = Path(config.AGENT_CARD)
    
    if not card_path.exists():
        raise FileNotFoundError(f"Agent card not found: {config.AGENT_CARD}")
    
    try:
        with card_path.open() as f:
            data = json.load(f)
        
        agent_card = AgentCard(**data)
        
        # Validate agent card name
        if agent_card.name != config.AGENT_DISPLAY_NAME:
            raise ValueError(
                f"Agent card name mismatch. "
                f"Expected: {config.AGENT_DISPLAY_NAME}, "
                f"Got: {agent_card.name}"
            )
        
        return agent_card
        
    except json.JSONDecodeError as e:
        raise json.JSONDecodeError(
            f"Invalid JSON in agent card {config.AGENT_CARD}: {e.msg}",
            e.doc,
            e.pos
        )


# Agent card loaded at import time - ready to use
AGENT_CARD = _load_agent_card()
