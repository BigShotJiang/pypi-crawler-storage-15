# SOC Config

A tool for configuring C-Class Core with RISC-V specifications.

## Installation

```bash
pip install -e .
```

## Usage

```bash
shakti_config -ispec <ISA_SPEC_YAML> -customspec <CUSTOM_SPEC_YAML> -cspec <CORE_SPEC_YAML> -gspec <CSR_GROUPING_YAML> -dspec <DEBUG_SPEC_YAML> [--verbose <LOG_LEVEL>]
```

### Arguments

- `-ispec, --ispec`: The YAML file containing ISA specifications (required)
- `-customspec, --customspec`: The YAML file containing Custom CSR specifications
- `-cspec, --cspec`: The YAML file containing CORE specifications (required)
- `-gspec, --gspec`: The YAML file containing CSR Grouping specifications (required)
- `-dspec, --dspec`: The YAML file containing Debug specifications
- `--verbose`: Log level (debug | info | warning | error), defaults to info
- `--clean`: Clean the dependencies and other collaterals

### Example

```bash
shakti_config -ispec sample_config/c64/rv64i_isa.yaml \
           -customspec sample_config/c64/rv64i_custom.yaml \
           -cspec sample_config/c64/core64.yaml \
           -gspec sample_config/c64/csr_grouping64.yaml \
           -dspec sample_config/c64/rv64i_debug.yaml \
           --verbose debug
```

## License

BSD License 
