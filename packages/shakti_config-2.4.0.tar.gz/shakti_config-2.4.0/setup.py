from setuptools import setup, find_packages
import os

setup(
    name="shakti_config",
    version="2.4.0",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "ruamel.yaml>=0.17.0",
        "pathlib>=1.0.1",
    ],
    entry_points={
        'console_scripts': [
            'shakti_config=shakti_config.main:main',
        ],
    },
    author="IIT Madras",
    author_email="",
    description="C-Class Core Generator",
    long_description=open("README.md").read() if os.path.exists("README.md") else "",
    long_description_content_type="text/markdown",
    license="BSD",
    python_requires=">=3.6",
) 
