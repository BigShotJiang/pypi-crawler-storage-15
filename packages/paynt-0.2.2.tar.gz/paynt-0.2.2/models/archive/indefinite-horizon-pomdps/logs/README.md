# Contents

* `paper`: All logfiles for our experiments in the main paper (Tables 1 and 2)
* `all`: Logfiles for our experiments including additional benchmark instances (Tables 3 and 4)
* `dynamic` Logfiles for our experiments with the dynamic triangulation approach (Tables 5 and 6)
* `heuristic` Logfiles for our experiments with different heuristic parameters (Tables 7 and 8)

