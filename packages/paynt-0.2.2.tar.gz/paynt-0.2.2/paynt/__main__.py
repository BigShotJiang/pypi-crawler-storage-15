import paynt.cli

if __name__ == "__main__":
    paynt.cli.main()
