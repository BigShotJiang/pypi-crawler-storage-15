from . import version

import os

paynt_models_dir = os.path.join(os.path.dirname(__file__), "../models/")