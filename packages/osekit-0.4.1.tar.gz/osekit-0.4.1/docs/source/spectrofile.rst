SpectroFile
-----------

.. _spectrofile:

.. autoclass:: osekit.core_api.spectro_file.SpectroFile
   :members:
