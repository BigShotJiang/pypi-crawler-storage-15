Dataset
-------

.. _dataset:

.. autoclass:: osekit.public_api.dataset.Dataset
   :members:
