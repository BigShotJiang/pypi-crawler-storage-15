Core API
----------

.. _coreapi:

.. toctree::
   :maxdepth: 1

   event
   instrument
   basefile
   baseitem
   basedata
   basedataset
   audiofile
   audioitem
   audiodata
   audiodataset
   spectrofile
   spectroitem
   spectrodata
   spectrodataset
   ltasdata
   audiofilemanager
   frequencyscale