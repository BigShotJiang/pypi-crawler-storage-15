Event
-----

.. _event:

.. autoclass:: osekit.core_api.event.Event
   :members:
