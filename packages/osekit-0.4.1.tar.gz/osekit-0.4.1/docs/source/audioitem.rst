AudioItem
---------

.. _audioitem:

.. autoclass:: osekit.core_api.audio_item.AudioItem
   :members:
