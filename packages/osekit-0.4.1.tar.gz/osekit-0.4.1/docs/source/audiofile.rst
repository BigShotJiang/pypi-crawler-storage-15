AudioFile
---------

.. _audiofile:

.. autoclass:: osekit.core_api.audio_file.AudioFile
   :members:
