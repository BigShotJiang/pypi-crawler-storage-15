SpectroData
-----------

.. _spectrodata:

.. autoclass:: osekit.core_api.spectro_data.SpectroData
   :members:
