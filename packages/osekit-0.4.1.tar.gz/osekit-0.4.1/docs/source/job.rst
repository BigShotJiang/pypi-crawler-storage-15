Job
---

.. _job:

.. automodule:: osekit.utils.job
    :members: JobConfig, JobBuilder, Job
