SpectroDataset
--------------

.. _spectrodataset:

.. autoclass:: osekit.core_api.spectro_dataset.SpectroDataset
   :members:
