Normalization
-------------

.. _normalization:

.. autoclass:: osekit.utils.audio_utils.Normalization
   :members:
