Instrument
----------

.. _instrument:

.. autoclass:: osekit.core_api.instrument.Instrument
   :members:
