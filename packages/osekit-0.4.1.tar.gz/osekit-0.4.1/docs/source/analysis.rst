Analysis
--------

.. _analysis:

.. autoclass:: osekit.public_api.analysis.Analysis
   :members:

===============

.. _analysis_Type:

.. autoclass:: osekit.public_api.analysis.AnalysisType
   :members:
