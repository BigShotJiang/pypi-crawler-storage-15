BaseDataset
-----------

.. _basedataset:

.. autoclass:: osekit.core_api.base_dataset.BaseDataset
   :members:
