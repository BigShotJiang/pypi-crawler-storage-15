BaseFile
--------

.. _basefile:

.. autoclass:: osekit.core_api.base_file.BaseFile
   :members:
