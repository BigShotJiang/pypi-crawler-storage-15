AudioFileManager
----------------

.. _audiofilemanager:

.. autoclass:: osekit.core_api.audio_file_manager.AudioFileManager
   :members:
