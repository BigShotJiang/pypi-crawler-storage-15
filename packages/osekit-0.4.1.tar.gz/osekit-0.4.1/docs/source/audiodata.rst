AudioData
---------

.. _audiodata:

.. autoclass:: osekit.core_api.audio_data.AudioData
   :members:
