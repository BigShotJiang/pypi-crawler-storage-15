SpectroItem
-----------

.. _spectroitem:

.. autoclass:: osekit.core_api.spectro_item.SpectroItem
   :members:
