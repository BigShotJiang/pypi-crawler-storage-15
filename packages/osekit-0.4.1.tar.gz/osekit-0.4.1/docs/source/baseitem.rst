BaseItem
--------

.. _baseitem:

.. autoclass:: osekit.core_api.base_item.BaseItem
   :members:
