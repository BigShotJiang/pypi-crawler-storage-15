Custom Frequency Scale
----------------------

.. _frequencyscale:

.. autoclass:: osekit.core_api.frequency_scale.Scale
   :members:

.. autoclass:: osekit.core_api.frequency_scale.ScalePart
   :members: