BaseData
--------

.. _basedata:

.. autoclass:: osekit.core_api.base_data.BaseData
   :members:
