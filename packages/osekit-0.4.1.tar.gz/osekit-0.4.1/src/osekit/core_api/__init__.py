from osekit.core_api.audio_file_manager import AudioFileManager

audio_file_manager = AudioFileManager()
