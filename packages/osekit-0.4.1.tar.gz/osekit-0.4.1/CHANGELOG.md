# Changelog

<!--next-version-placeholder-->

## v0.1.0 (10/05/2023)

- First release of OSmOSE

### Features

- Dataset standard build
- Spectrogram generation
- Audio file manipulation (reshaping, resampling...)
- Compatibility with Torque PBS clusters