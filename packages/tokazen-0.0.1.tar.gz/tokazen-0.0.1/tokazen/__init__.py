"""Tokazen - Python bindings for Tokazen."""

from tokazen.wrapper import hello

__version__ = "0.0.1"
__all__ = ["hello"]
