from unittest import TestCase


class TestTable(TestCase):
    def test_example(self):
        self.assertEqual(1 + 1, 2)
