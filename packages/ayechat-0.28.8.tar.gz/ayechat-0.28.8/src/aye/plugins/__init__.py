from . import auto_detect_mask

from . import completer

from . import local_model

from . import offline_llm

from . import shell_executor
