from collections.abc import Callable
from typing import Any

AnyCallable = Callable[..., Any]
