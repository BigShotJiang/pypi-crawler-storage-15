def submodule_helper():
    print("import successful!")
    return {"status": "SUCCESS"}
