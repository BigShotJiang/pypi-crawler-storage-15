# tencoin-core/tencoin_core/__version__.py
__version__ = "0.1.0"