"""Unified optimize command - consolidates weights, steering, and classification optimization.

Usage:
    wisent optimize --target weights --task coding --model Qwen/Qwen3-8B
    wisent optimize --target steering --task coding --model Qwen/Qwen3-8B
    wisent optimize --target classification --model Qwen/Qwen3-8B
"""

from wisent.core.cli.optimize_weights import execute_optimize_weights
from wisent.core.cli.optimize_steering import execute_optimize_steering
from wisent.core.cli.optimize_classification import execute_optimize_classification


def execute_optimize(args):
    """
    Execute the unified optimize command.
    
    Routes to the appropriate optimization based on --target:
    - weights: Optimize weight modification parameters
    - steering: Optimize steering vector application parameters
    - classification: Optimize classification thresholds
    """
    target = getattr(args, 'target', None)
    
    if target is None:
        print("\n✗ No optimization target specified")
        print("Use --target with one of: weights, steering, classification")
        print("\nUsage:")
        print("  wisent optimize --target weights --task coding --model Qwen/Qwen3-8B")
        print("  wisent optimize --target steering --task coding --model Qwen/Qwen3-8B")
        print("  wisent optimize --target classification --model Qwen/Qwen3-8B")
        import sys
        sys.exit(1)
    
    if target == 'weights':
        execute_optimize_weights(args)
    elif target == 'steering':
        execute_optimize_steering(args)
    elif target == 'classification':
        execute_optimize_classification(args)
    else:
        print(f"\n✗ Unknown optimization target: {target}")
        print("Available targets: weights, steering, classification")
        import sys
        sys.exit(1)
