"""Unified generate command - consolidates weight modification, response generation, 
steering vectors, classifiers, and score evaluation.

Usage:
    wisent generate --target weights --task coding --model Qwen/Qwen3-8B
    wisent generate --target responses --task arc_easy --model Qwen/Qwen3-8B
    wisent generate --target vector --task coding --model Qwen/Qwen3-8B
    wisent generate --target classifier --task coding --model Qwen/Qwen3-8B
    wisent generate --target scores --task coding --model Qwen/Qwen3-8B
"""

import sys


def execute_generate(args):
    """
    Execute the unified generate command.
    
    Routes to the appropriate generation based on --target:
    - weights: Generate modified model weights
    - responses: Generate model responses to task prompts
    - vector: Generate steering vector from task/trait
    - classifier: Generate classifier for task
    - scores: Generate evaluation scores
    """
    target = getattr(args, 'target', None)
    
    if target is None:
        print("\n✗ No generation target specified")
        print("Use --target with one of: weights, responses, vector, classifier, scores")
        print("\nUsage:")
        print("  wisent generate --target weights --task coding --model Qwen/Qwen3-8B")
        print("  wisent generate --target responses --task arc_easy --model Qwen/Qwen3-8B")
        print("  wisent generate --target vector --task coding --model Qwen/Qwen3-8B")
        print("  wisent generate --target classifier --task coding --model Qwen/Qwen3-8B")
        print("  wisent generate --target scores --responses responses.json --model Qwen/Qwen3-8B")
        sys.exit(1)
    
    if target == 'weights':
        from wisent.core.cli.modify_weights import execute_modify_weights
        execute_modify_weights(args)
    elif target == 'responses':
        from wisent.core.cli.generate_responses import execute_generate_responses
        execute_generate_responses(args)
    elif target == 'vector':
        _execute_generate_vector(args)
    elif target == 'classifier':
        _execute_generate_classifier(args)
    elif target == 'scores':
        _execute_generate_scores(args)
    else:
        print(f"\n✗ Unknown generation target: {target}")
        print("Available targets: weights, responses, vector, classifier, scores")
        sys.exit(1)


def _execute_generate_vector(args):
    """Generate steering vector from task or trait description."""
    from wisent.core.cli.generate_vector_from_task import execute_generate_vector_from_task
    
    # Map unified args to generate_vector_from_task args
    if not hasattr(args, 'task') or not args.task:
        print("\n✗ --task is required for vector generation")
        sys.exit(1)
    
    execute_generate_vector_from_task(args)


def _execute_generate_classifier(args):
    """Generate classifier for a task."""
    from wisent.core.cli.tasks import execute_tasks
    from argparse import Namespace
    
    if not hasattr(args, 'task') or not args.task:
        print("\n✗ --task is required for classifier generation")
        sys.exit(1)
    
    # Run tasks with save_classifiers enabled
    tasks_args = Namespace(
        model=args.model,
        tasks=[args.task] if isinstance(args.task, str) else args.task,
        mode='classify',
        device=getattr(args, 'device', None),
        layer=getattr(args, 'layer', None),
        aggregation=getattr(args, 'aggregation', 'average'),
        detection_threshold=getattr(args, 'threshold', 0.5),
        limit=getattr(args, 'limit', 1000),
        save_classifiers=True,
        classifiers_dir=getattr(args, 'output', './classifiers'),
        verbose=getattr(args, 'verbose', False),
        timing=getattr(args, 'timing', False),
    )
    
    execute_tasks(tasks_args)


def _execute_generate_scores(args):
    """Generate evaluation scores for responses."""
    from wisent.core.cli.evaluate_responses import execute_evaluate_responses
    
    # Check if we have responses to evaluate
    if not hasattr(args, 'responses') or not args.responses:
        print("\n✗ --responses file is required for score generation")
        sys.exit(1)
    
    execute_evaluate_responses(args)
