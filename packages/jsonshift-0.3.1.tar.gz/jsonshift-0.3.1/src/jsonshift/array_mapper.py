from __future__ import annotations
from typing import Any, Dict, List
from .mapper import Mapper, _get, _set, _MISSING
from .exceptions import MappingMissingError


class ArrayMapper(Mapper):
    """
    Extends Mapper with support for wildcard list mappings like:
        "dest[*].id": "source[*].product_id"
    """

    def transform(self, spec: Dict[str, Any], payload: Dict[str, Any]) -> Dict[str, Any]:
        if not isinstance(spec, dict):
            raise TypeError("spec must be a dict.")
        if not isinstance(payload, dict):
            raise TypeError("payload must be a dict.")

        out: Dict[str, Any] = {}

        mapping = spec.get("map", {}) or {}
        defaults = spec.get("defaults", {}) or {}

        # First pass: handle mapping rules
        for dest, src in mapping.items():
            if "[*]" in src:
                src_prefix, src_suffix = src.split("[*]", 1)
                dest_prefix, dest_suffix = dest.split("[*]", 1)
                src_prefix = src_prefix.rstrip(".")
                dest_prefix = dest_prefix.rstrip(".")
                src_suffix = src_suffix.lstrip(".")
                dest_suffix = dest_suffix.lstrip(".")

                src_list = _get(payload, src_prefix, default=_MISSING)
                if src_list is _MISSING:
                    raise MappingMissingError(src, dest)
                if not isinstance(src_list, list):
                    raise TypeError(f"Expected list at '{src_prefix}', got {type(src_list)}")

                dest_list = out.get(dest_prefix, [{} for _ in src_list])
                # ensure we have a list of dicts
                if not isinstance(dest_list, list):
                    dest_list = [{} for _ in src_list]
                while len(dest_list) < len(src_list):
                    dest_list.append({})

                for i, item in enumerate(src_list):
                    val = _get(item, src_suffix, default=_MISSING)
                    if val is _MISSING:
                        raise MappingMissingError(src, dest)
                    if dest_suffix:
                        _set(dest_list[i], dest_suffix, val)
                    else:
                        dest_list[i] = val

                _set(out, dest_prefix, dest_list)
            else:
                val = _get(payload, src, default=_MISSING)
                if val is _MISSING:
                    raise MappingMissingError(src, dest)
                _set(out, dest, val)

        # Second pass: apply defaults (support wildcard)
        for dest, fixed in defaults.items():
            if "[*]" in dest:
                dest_prefix, dest_suffix = dest.split("[*]", 1)
                dest_prefix = dest_prefix.rstrip(".")
                dest_suffix = dest_suffix.lstrip(".")
                dest_list = out.get(dest_prefix, [])
                if not isinstance(dest_list, list):
                    continue
                for obj in dest_list:
                    if dest_suffix:
                        if _get(obj, dest_suffix, default=_MISSING) is _MISSING:
                            _set(obj, dest_suffix, fixed)
            else:
                if _get(out, dest, default=_MISSING) is _MISSING:
                    _set(out, dest, fixed)

        return out