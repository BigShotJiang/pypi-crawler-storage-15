__all__ = [
    "dependency_pb2",
    "dependency_pb2_grpc",
    "ner_pb2",
    "ner_pb2_grpc",
    "segment_pb2",
    "segment_pb2_grpc",
]

__version__ = "0.1.3"
