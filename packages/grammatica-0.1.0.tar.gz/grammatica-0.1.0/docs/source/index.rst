========================
Grammatica Documentation
========================

Grammatica is a library for generating and manipulating GBNF (GGML BNF) grammars.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   api_reference/index

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
