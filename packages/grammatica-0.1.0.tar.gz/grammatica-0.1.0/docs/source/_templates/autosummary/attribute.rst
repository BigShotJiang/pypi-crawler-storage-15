:orphan:

{{ fullname | escape | underline }}

.. currentmodule:: {{ module }}

.. auto{{ objtype }}:: {{ fullname | replace("grammatica.", "grammatica::") }}
