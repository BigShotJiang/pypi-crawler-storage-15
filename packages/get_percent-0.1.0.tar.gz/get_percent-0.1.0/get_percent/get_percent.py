def get_percent(a, b):
    differenz = abs(a - b)
    return differenz / a * 100

