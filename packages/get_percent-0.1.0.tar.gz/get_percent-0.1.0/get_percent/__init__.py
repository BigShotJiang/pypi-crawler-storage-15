__all__ = ["get_percent"]

from get_percent.get_percent import get_percent