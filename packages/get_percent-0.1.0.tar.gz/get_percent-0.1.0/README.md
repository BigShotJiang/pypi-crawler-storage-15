# Why? 
I wrote an Exam where I needed to calculate percentages. Unfortunately I forgot how to do this, so I just wrote this in my code:

```python
a = input("first value")
b = input("second value")
import os
os.system("pip install get_percent")
from get_percent import get_percent
percentage = get_percent(a, b)
print(f"The percentage is: {percentage}")
```

Because this module doesn't exist I just wrote it myself. I don't know if my teachers approves this. Probably not, but it's worth a try xD
<br>I'll let you know what the result is once I get the exam back lmao 

