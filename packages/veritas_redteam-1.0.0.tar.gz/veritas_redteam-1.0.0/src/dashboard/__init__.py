"""Veritas Dashboard - Interactive Web UI for AI Security Analysis."""

from .app import main

__all__ = ["main"]
