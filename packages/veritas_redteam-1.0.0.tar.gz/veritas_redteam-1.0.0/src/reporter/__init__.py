"""Veritas Reporter - PDF and JSON report generation."""

from .quick_report import generate_quick_report

__all__ = ["generate_quick_report"]
