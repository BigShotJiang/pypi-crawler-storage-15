"""Veritas core module"""
