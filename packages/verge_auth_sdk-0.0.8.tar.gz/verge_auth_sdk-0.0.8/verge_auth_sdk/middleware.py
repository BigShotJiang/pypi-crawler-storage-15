from fastapi import FastAPI, Request
from fastapi.responses import RedirectResponse, JSONResponse
from .secret_loader import load_secret
import httpx


def add_central_auth(app: FastAPI):

    # Load secrets using env + cloud-provider support
    AUTH_INTROSPECT_URL = load_secret("AUTH_INTROSPECT_URL")
    AUTH_LOGIN_URL = load_secret("AUTH_LOGIN_URL")
    CLIENT_ID = load_secret("VERGE_CLIENT_ID")
    CLIENT_SECRET = load_secret("VERGE_CLIENT_SECRET")

    # Public, non-authenticated paths
    PUBLIC_PATHS = {
        "/health",
        "/docs",
        "/openapi.json",
        "/redoc",
    }

    @app.middleware("http")
    async def central_auth(request: Request, call_next):

        path = request.url.path

        # Skip public endpoints
        if path in PUBLIC_PATHS:
            return await call_next(request)

        # Extract token
        token = None
        auth_header = request.headers.get("authorization")

        if auth_header and auth_header.lower().startswith("bearer "):
            token = auth_header.split(" ")[1]

        if not token:
            token = request.cookies.get("access_token")

        # Not logged in → browser redirect or API 401
        if not token:
            if "text/html" in (request.headers.get("accept") or ""):
                return RedirectResponse(
                    f"{AUTH_LOGIN_URL}?redirect_url={request.url}"
                )
            return JSONResponse({"detail": "Unauthorized"}, status_code=401)

        # Validate token with auth-service introspection
        try:
            async with httpx.AsyncClient(timeout=3) as client:
                res = await client.post(
                    AUTH_INTROSPECT_URL,
                    headers={
                        "Authorization": f"Bearer {token}",
                        "X-Client-Id": CLIENT_ID,
                        "X-Client-Secret": CLIENT_SECRET,
                    },
                )
                data = res.json()
        except Exception:
            return JSONResponse({"detail": "Auth service unreachable"}, status_code=503)

        # Token is invalid or expired
        if not data.get("active"):
            return JSONResponse({"detail": "Session expired"}, status_code=401)

        # Attach user info to request
        request.state.user = data.get("user", {})
        request.state.roles = data.get("roles", [])

        return await call_next(request)
