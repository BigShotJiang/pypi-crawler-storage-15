"""Test suite for the Barndoor SDK."""
