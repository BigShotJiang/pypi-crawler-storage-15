"""Core generation and output modules."""
