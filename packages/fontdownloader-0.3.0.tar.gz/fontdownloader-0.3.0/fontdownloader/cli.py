import io
import json
import os
import pathlib
import re
import shutil
import time
import urllib.parse
import urllib.request
import zipfile

import click
import requests

USER_AGENT = (
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/123.0 Safari/537.36"
)

# Check if fontTools with woff2 support is available
try:
    from fontTools.ttLib import TTFont

    FONTTOOLS_AVAILABLE = True
except ImportError:
    FONTTOOLS_AVAILABLE = False
    TTFont = None  # type: ignore


def _convert_ttf_to_woff(
    ttf_path: pathlib.Path, output_formats: list[str] | None = None
) -> list[pathlib.Path]:
    """Convert TTF/OTF to WOFF and/or WOFF2 formats.

    Args:
        ttf_path: Path to the TTF/OTF file
        output_formats: List of formats to generate (default: ["woff2", "woff"])

    Returns:
        List of paths to generated files

    Raises:
        ImportError: If fontTools is not installed
    """
    if not FONTTOOLS_AVAILABLE:
        raise ImportError(
            "fontTools is required for TTF conversion. "
            "Install with: pip install fonttools[woff,woff2] brotli"
        )

    if output_formats is None:
        output_formats = ["woff2", "woff"]

    generated = []

    for fmt in output_formats:
        if fmt not in ("woff", "woff2"):
            click.echo(f"⚠️  Unsupported format: {fmt}", err=True)
            continue

        try:
            font = TTFont(str(ttf_path))  # type: ignore
            output_path = ttf_path.with_suffix(f".{fmt}")

            font.flavor = fmt
            font.save(str(output_path))
            generated.append(output_path)

            # Calculate compression ratio
            original_size = ttf_path.stat().st_size
            new_size = output_path.stat().st_size
            ratio = (1 - new_size / original_size) * 100

            click.echo(
                f"  ✅ Generated {output_path.name} "
                f"({new_size // 1024}KB, {ratio:.1f}% compression)"
            )
        except Exception as e:
            click.echo(f"  ❌ Failed to convert to {fmt}: {e}", err=True)

    return generated


def _slugify_google_fonts_dir(name: str) -> str:
    return re.sub(r"[^a-z0-9]", "", name.lower())


def _normalize_font_name_for_lookup(font_name: str) -> str:
    """Convert font name to catalog lookup format.

    Examples:
    - "Fauna One" -> "faunaone"
    - "Open Sans" -> "opensans"
    - "Roboto Slab" -> "robotoslab"
    """
    return re.sub(r"[^a-z0-9]", "", font_name.lower())


def _download_from_gfonts_repo(
    font_name: str, dest_dir: pathlib.Path
) -> tuple[int, bool]:
    """Download TTF/OTF/TTC and OFL from google/fonts GitHub repo.

    Returns (downloaded_file_count, license_found)
    """
    slug = _slugify_google_fonts_dir(font_name)
    license_dirs = ["ofl", "apache", "ufl"]
    headers = {
        "User-Agent": "fontdownloader/0.1",
        "Accept": "application/vnd.github.v3+json",
    }

    def fetch_dir(path: str) -> list:
        url = f"https://api.github.com/repos/google/fonts/contents/{path}"
        r = requests.get(url, headers=headers, timeout=30)
        if r.status_code != 200:
            return []
        try:
            data = r.json()
            return data if isinstance(data, list) else []
        except Exception:
            return []

    def download_file(raw_url: str, out_path: pathlib.Path) -> bool:
        resp = requests.get(raw_url, timeout=60)
        if resp.status_code == 200:
            out_path.write_bytes(resp.content)
            return True
        return False

    for lic in license_dirs:
        base_path = f"{lic}/{slug}"
        items = fetch_dir(base_path)
        if not items:
            continue

        dest_dir.mkdir(parents=True, exist_ok=True)
        count = 0
        license_found = False

        # BFS into one level (e.g., static dir) to fetch static TTFs
        queue = [base_path]
        visited = set()
        while queue:
            current = queue.pop(0)
            if current in visited:
                continue
            visited.add(current)
            for it in fetch_dir(current):
                name = it.get("name", "")
                lower = name.lower()
                it_type = it.get("type")
                download_url = it.get("download_url")
                if not download_url:
                    path = it.get("path", "")
                    download_url = (
                        f"https://raw.githubusercontent.com/google/fonts/main/{path}"
                    )

                if it_type == "dir":
                    # descend into 'static' and immediate children once
                    if lower in ("static",) or current == base_path:
                        path = it.get("path", "")
                        if path:
                            queue.append(path)
                    continue

                if lower.endswith((".ttf", ".otf", ".ttc")):
                    target = dest_dir / name
                    if download_file(download_url, target):
                        count += 1
                elif lower == "ofl.txt" and not license_found:
                    target = dest_dir / "OFL.txt"
                    if download_file(download_url, target):
                        license_found = True
                elif lower in ("license.txt", "license") and not license_found:
                    target = dest_dir / "LICENSE.txt"
                    if download_file(download_url, target):
                        license_found = True

        return count, license_found

    return 0, False


def _get_google_fonts_api_data() -> dict:
    """Fetch Google Fonts data. Tries GitHub release catalog first, then API."""
    cache_dir = pathlib.Path.home() / ".fontdownloader" / "cache"
    cache_file = cache_dir / "google_fonts.json"

    # Check cache freshness (24 hours)
    if cache_file.exists():
        cache_age = time.time() - cache_file.stat().st_mtime
        if cache_age < 86400:  # 24 hours
            try:
                return json.loads(cache_file.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                pass

    # Try to get latest catalog from GitHub releases first
    try:
        from . import download_catalog

        catalog_temp = cache_dir / "temp_catalog.json"
        cache_dir.mkdir(parents=True, exist_ok=True)

        # Try current repository first, fallback to default
        repo_name = "sanderboer/google-font-downloader"
        if download_catalog.download_latest_catalog(
            repo=repo_name, output_path=str(catalog_temp)
        ):
            # Convert catalog format to API format for compatibility
            with open(catalog_temp, encoding="utf-8") as f:
                catalog_data = json.load(f)

            # Transform catalog to API format
            api_data = {"items": catalog_data.get("items", [])}

            # Cache the result
            cache_file.write_text(json.dumps(api_data, indent=2), encoding="utf-8")
            catalog_temp.unlink(missing_ok=True)  # Clean up temp file

            click.echo("✅ Using latest catalog from GitHub releases", err=True)
            return api_data

    except Exception:
        # Silently try Google Fonts API next
        pass

    # Fallback to Google Fonts API
    api_url = "https://www.googleapis.com/webfonts/v1/webfonts?sort=popularity"
    try:
        with urllib.request.urlopen(api_url, timeout=10) as response:
            data = json.loads(response.read().decode("utf-8"))

        # Cache the result
        cache_dir.mkdir(parents=True, exist_ok=True)
        cache_file.write_text(json.dumps(data, indent=2), encoding="utf-8")
        click.echo("✅ Using Google Fonts API data", err=True)
        return data

    except Exception:
        # Silently try bundled catalog next
        pass

    # Try bundled catalog as fallback
    try:
        bundled_catalog = pathlib.Path(__file__).parent / "google_fonts_catalog.json"
        if bundled_catalog.exists():
            with open(bundled_catalog, encoding="utf-8") as f:
                catalog_data = json.load(f)
            click.echo("✅ Using bundled catalog", err=True)
            return {"items": catalog_data.get("items", [])}
    except Exception:
        # Final fallback - show this message since it's the last resort
        pass

    # Final fallback list of popular fonts with updated URLs (using CSS API derived)
    click.echo("⚠️  All catalog sources failed, using minimal fallback...", err=True)
    return {
        "items": [
            {
                "family": "Inter",
                "variants": ["regular", "700"],
                "files": {
                    "regular": "https://fonts.gstatic.com/s/inter/v20/UcC73FwrK3iLTeHuS_nVMrMxCp50SjIa1ZL7.woff2",
                    "700": "https://fonts.gstatic.com/s/inter/v20/UcC73FwrK3iLTeHuS_nVMrMxCp50SjIa1ZL7.woff2",
                },
            },
            {
                "family": "Roboto",
                "variants": ["regular", "700"],
                "files": {
                    "regular": "https://fonts.gstatic.com/s/roboto/v30/KFOmCnqEu92Fr1Mu4mxK.woff2",
                    "700": "https://fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmWUlfBBc4.woff2",
                },
            },
            {
                "family": "Open Sans",
                "variants": ["regular", "700"],
                "files": {
                    "regular": "https://fonts.gstatic.com/s/opensans/v44/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTS-muw.woff2",
                    "700": "https://fonts.gstatic.com/s/opensans/v44/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTS-muw.woff2",
                },
            },
            {
                "family": "Lora",
                "variants": ["regular"],
                "files": {
                    "regular": "https://fonts.gstatic.com/s/lora/v37/0QI6MX1D_JOuGQbT0gvTJPa787weuxJBkq0.woff2"
                },
            },
            {
                "family": "Playfair Display",
                "variants": ["regular"],
                "files": {
                    "regular": "https://fonts.gstatic.com/s/playfairdisplay/v30/nuFvD-vYSZviVYUb_rj3ij__anPXJzDwcbmjWBN2PKdFvXDXbtXK-F2qC0s.woff2"
                },
            },
        ]
    }


def _download_font_file(url: str, dest_path: pathlib.Path) -> bool:
    """Download a font file from URL to destination"""
    try:
        dest_path.parent.mkdir(parents=True, exist_ok=True)

        with urllib.request.urlopen(url, timeout=30) as response:
            if response.status == 200:
                dest_path.write_bytes(response.read())
                return True
        return False

    except Exception as e:
        click.echo(f"  ❌ Failed to download {url}: {e}", err=True)
        return False


def _download_license_file(font_name: str, dest_path: pathlib.Path) -> bool:
    """Download the OFL license file for a font"""
    try:
        # Try to download the OFL license file from Google Fonts
        license_url = f"https://fonts.google.com/download/license?kit=OFL.txt&family={urllib.parse.quote(font_name)}"
        dest_path.parent.mkdir(parents=True, exist_ok=True)

        with urllib.request.urlopen(license_url, timeout=30) as response:
            if response.status == 200:
                dest_path.write_bytes(response.read())
                return True
        return False

    except Exception as e:
        # If the license file doesn't exist, try to get the license information
        # from the font's metadata
        try:
            click.echo(
                f"  ⚠️  Could not download standard license file for {font_name}: {e}",
                err=True,
            )
            # Create a basic license file with information
            license_text = (
                "This font is from Google Fonts and is used under the Open Font "
                "License (OFL).\n"
                f"Font Name: {font_name}\n"
                "Source: https://fonts.google.com/specimen/"
                f"{font_name.replace(' ', '+')}\n\n"
                "For the full license text, please visit:\n"
                "https://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL\n"
            )
            dest_path.parent.mkdir(parents=True, exist_ok=True)
            dest_path.write_text(license_text, encoding="utf-8")
            return True
        except Exception as e2:
            click.echo(
                f"  ❌ Failed to create license file for {font_name}: {e2}", err=True
            )
            return False


def _download_and_extract_google_fonts_zip(
    font_name: str, dest_dir: pathlib.Path
) -> tuple[int, bool]:
    """Attempt to download the family ZIP from Google Fonts and extract files.

    Returns (extracted_file_count, license_found)
    """
    url = (
        f"https://fonts.google.com/download?family={urllib.parse.quote_plus(font_name)}"
    )
    headers = {
        "User-Agent": USER_AGENT,
        "Accept": "application/zip,application/octet-stream,*/*;q=0.8",
        "Referer": "https://fonts.google.com/",
    }
    try:
        resp = requests.get(url, headers=headers, timeout=120, allow_redirects=True)
        if resp.status_code != 200:
            click.echo(f"  ⚠️  ZIP request failed: HTTP {resp.status_code}", err=True)
            return 0, False

        ctype = resp.headers.get("Content-Type", "").lower()
        cdisp = resp.headers.get("Content-Disposition", "")
        if "zip" not in ctype and "filename=" not in cdisp:
            raise ValueError(f"Unexpected content-type: {ctype}")

        data = resp.content
        zf = zipfile.ZipFile(io.BytesIO(data))
        extracted = 0
        license_found = False
        dest_dir.mkdir(parents=True, exist_ok=True)

        for member in zf.namelist():
            lower = member.lower()
            if lower.endswith((".ttf", ".otf", ".ttc", ".woff", ".woff2")):
                target_path = dest_dir / pathlib.Path(member).name
                with zf.open(member) as src, open(target_path, "wb") as out:
                    shutil.copyfileobj(src, out)
                extracted += 1
            if lower.endswith("ofl.txt") and not license_found:
                target_path = dest_dir / "OFL.txt"
                with zf.open(member) as src, open(target_path, "wb") as out:
                    shutil.copyfileobj(src, out)
                license_found = True

        return extracted, license_found

    except Exception as e:
        click.echo(f"  ⚠️  Could not fetch family ZIP: {e}", err=True)
        return 0, False


def _search_google_fonts(query: str, limit: int = 10) -> list:
    """Search Google Fonts by name"""
    fonts_data = _get_google_fonts_api_data()
    query_lower = query.lower()

    matches = []
    for font in fonts_data.get("items", []):
        family = font["family"]
        if query_lower in family.lower():
            matches.append(
                {
                    "family": family,
                    "variants": len(font.get("files", {})),
                    "variants_list": list(font.get("files", {}).keys()),
                    "category": font.get("category", "unknown"),
                }
            )

    return matches[:limit]


def _fetch_css2_variants(font_name: str) -> list[tuple[str, str, str]]:
    """Fetch (style, weight, url) from the CSS2 API (usually WOFF2)."""
    css_url = f"https://fonts.googleapis.com/css2?family={urllib.parse.quote_plus(font_name)}&display=swap"
    headers = {
        "User-Agent": USER_AGENT,
        "Accept": "text/css,*/*;q=0.1",
        "Referer": "https://fonts.google.com/",
    }
    try:
        r = requests.get(css_url, headers=headers, timeout=20)
        if r.status_code != 200:
            return []
        css = r.text
        # Regex to capture style, weight, and url(...) – compact form across lines
        pattern = re.compile(
            r"font-style:\s*(normal|italic).*?font-weight:\s*(\d+).*?src:[^;]*?url\(([^)]+)\)",
            re.IGNORECASE | re.DOTALL,
        )
        matches = pattern.findall(css)
        # De-dup by (style, weight, url)
        seen = set()
        out = []
        for style, weight, url in matches:
            key = (style, weight, url)
            if key in seen:
                continue
            seen.add(key)
            out.append((style, weight, url))
        return out
    except Exception:
        return []


def _is_variable_font_response(
    chosen: dict[tuple[str, str], list[str]],
) -> dict[str, bool]:
    """Detect if URLs represent variable fonts by checking for duplicate URLs across weights.

    For variable fonts, Google returns the SAME URLs for different weights (within each subset).
    Example: Inter weight 400 latin and weight 700 latin use the same woff2 file.

    Returns dict with keys 'normal' and 'italic' indicating if each style is variable.
    """

    # For each style, check if URLs are reused across weights
    def is_style_variable(style: str) -> bool:
        weights_for_style = [(w, urls) for (s, w), urls in chosen.items() if s == style]

        if len(weights_for_style) < 3:
            return False  # Need at least 3 weights to determine

        # Check if there are duplicate URLs across different weights
        # For variable fonts, each subset URL appears for ALL weights
        url_to_weights = {}
        for weight, urls in weights_for_style:
            for url in urls:
                if url not in url_to_weights:
                    url_to_weights[url] = []
                url_to_weights[url].append(weight)

        # If any URL appears for 3+ weights, it's likely a variable font
        max_weight_count = max(len(weights) for weights in url_to_weights.values())
        return max_weight_count >= 3

    return {
        "normal": is_style_variable("normal"),
        "italic": is_style_variable("italic"),
    }


def _download_css2_woff_variants(
    font_name: str, dest_dir: pathlib.Path
) -> list[tuple[str, str, pathlib.Path, bool]]:
    """Download WOFF/WOFF2 variants using the CSS2 API with catalog integration.

    Strategy:
    1. Get available variants from catalog data to guide downloading
    2. Try multiple CSS2 API approaches with different user agents
    3. Request all weights 100-900 to get everything available
    4. Handle rate limiting and blocked requests gracefully
    5. Detect variable fonts and download them only once per style

    Returns list of (style, weight, saved_path, is_variable_font)
    """
    # Get catalog data to determine available variants
    fonts_data = _get_google_fonts_api_data()
    catalog_variants = []
    font_info = None

    normalized_name = _normalize_font_name_for_lookup(font_name)

    # Try exact match first, then normalized match
    for font in fonts_data.get("items", []):
        if (
            font["family"].lower() == font_name.lower()
            or font["family"].lower() == normalized_name
        ):
            font_info = font
            catalog_variants = font.get("variants", [])
            break

    if not font_info:
        click.echo(f"⚠️  Font '{font_name}' not found in catalog for WOFF download")
        return []

    # Generate proper font name variations to handle catalog naming issues
    def get_font_name_variants(name: str) -> list[str]:
        """Generate different font name variations to try"""
        variants = [name]

        # If catalog has lowercase name, try to convert to proper case
        if name.islower():
            # Convert "faunaone" -> "Fauna One"
            # Handle common patterns: convert camelCase/lowercase to Title Case with spaces
            import re

            # Insert space before capital letters
            spaced = re.sub(r"([a-z])([A-Z])", r"\1 \2", name)
            # Convert to title case
            title_cased = " ".join(word.capitalize() for word in spaced.split())
            variants.append(title_cased)

            # Also try simple title case
            variants.append(name.title())

            # Handle specific known mappings
            known_mappings = {
                "faunaone": "Fauna One",
                "playfairdisplay": "Playfair Display",
                "opensans": "Open Sans",
                "roboto": "Roboto",
                "lora": "Lora",
            }
            if name.lower() in known_mappings:
                variants.append(known_mappings[name.lower()])

        # Remove duplicates while preserving order
        seen = set()
        unique_variants = []
        for variant in variants:
            if variant not in seen:
                seen.add(variant)
                unique_variants.append(variant)

        return unique_variants

    # Try different font name variations
    font_name_to_use = font_info["family"]
    font_name_variants = get_font_name_variants(font_name_to_use)

    # Convert catalog variants to weight/style pairs and simple weights
    # Include all available weights
    target_pairs = []
    simple_weights = []

    for variant in catalog_variants:
        if variant == "regular":
            target_pairs.append("0,400")
            simple_weights.append("400")
        elif variant == "italic":
            target_pairs.append("1,400")
        elif variant.endswith("italic"):
            weight = variant.replace("italic", "")
            if weight.isdigit():
                target_pairs.append(f"1,{weight}")
        elif variant.isdigit():
            target_pairs.append(f"0,{variant}")
            simple_weights.append(variant)

    # Add comprehensive fallback pairs (all weights 100-900)
    all_weights = ["100", "200", "300", "400", "500", "600", "700", "800", "900"]
    fallback_pairs = [f"0,{w}" for w in all_weights] + [f"1,{w}" for w in all_weights]

    # Combine catalog-guided pairs with fallback (catalog first for priority)
    # Use set to deduplicate, then sort to ensure proper order
    all_pairs_set = set(target_pairs + fallback_pairs)
    # Sort by italic (0/1) then by weight
    all_pairs = sorted(
        all_pairs_set, key=lambda x: (int(x.split(",")[0]), int(x.split(",")[1]))
    )

    # Multiple user agents to get both woff and woff2 formats
    # Modern browsers get woff2, very old browsers get woff
    user_agents = [
        # Modern Chrome - gets woff2
        USER_AGENT,
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        # Very old browsers - gets woff (before woff2 support)
        # Chrome 35 and earlier, Firefox 38 and earlier
        "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.9; rv:38.0) Gecko/20100101 Firefox/38.0",
        "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:38.0) Gecko/20100101 Firefox/38.0",
    ]

    def parse_css(css_text: str) -> list[tuple[str, str, str]]:
        pattern = re.compile(
            r"font-style:\s*(normal|italic).*?font-weight:\s*(\d+)\s*;.*?src:[^;]*?url\(([^)]+)\)",
            re.IGNORECASE | re.DOTALL,
        )
        return pattern.findall(css_text)

    # Store URLs by (style, weight) - we'll collect multiple formats per variant
    chosen: dict[tuple[str, str], list[str]] = {}

    # Try CSS2 API with different strategies and font name variants
    strategies = []

    # Generate strategies for each font name variant
    # Always use comprehensive strategy to get ALL weights 400-900
    for name_variant in font_name_variants:
        # Use comprehensive weight range (all weights 400-900, both normal and italic)
        comprehensive_url = (
            f"https://fonts.googleapis.com/css2?family="
            f"{urllib.parse.quote_plus(name_variant)}:ital,wght@{';'.join(all_pairs)}&display=swap"
        )
        strategies.append((comprehensive_url, f"comprehensive-{name_variant}"))

    for css_url, strategy_name in strategies:
        # Try multiple user agents to get different formats (woff and woff2)
        for ua_index, user_agent in enumerate(user_agents):
            headers = {
                "User-Agent": user_agent,
            }

            try:
                r = requests.get(css_url, headers=headers, timeout=30)
                if r.status_code == 200:
                    variants_found = 0
                    for style, weight, url in parse_css(r.text):
                        key = (style, weight)
                        # Add URL to list if not already present
                        if key not in chosen:
                            chosen[key] = []
                        if url not in chosen[key]:
                            chosen[key].append(url)
                            variants_found += 1

                    if variants_found > 0:
                        click.echo(
                            f"✅ Found {variants_found} variants using {strategy_name} strategy (UA {ua_index + 1})"
                        )
                        # Don't break - try other user agents to get more formats

                elif r.status_code == 403:
                    click.echo(
                        f"⚠️  403 Forbidden with UA {ua_index + 1}, trying next..."
                    )
                    continue
                else:
                    click.echo(f"⚠️  HTTP {r.status_code} with UA {ua_index + 1}")

            except requests.exceptions.Timeout:
                click.echo(f"⚠️  Timeout with UA {ua_index + 1}, trying next...")
                continue
            except Exception as e:
                click.echo(f"⚠️  Error with UA {ua_index + 1}: {str(e)[:50]}...")
                continue

        # Don't break after first strategy - try all strategies to collect more formats

    # Fallback: CSS1 API (often works when CSS2 is blocked)
    if not chosen:
        click.echo("🔄 Trying CSS1 API fallback...")
        try:
            # Build CSS1 weights string from catalog variants (all weights)
            css1_weights = []
            for variant in catalog_variants:
                if variant == "regular":
                    css1_weights.append("400")
                elif variant == "italic":
                    css1_weights.append("400italic")
                elif variant.endswith("italic"):
                    weight = variant.replace("italic", "")
                    if weight.isdigit():
                        css1_weights.append(f"{weight}italic")
                elif variant.isdigit():
                    css1_weights.append(variant)

            if not css1_weights:
                css1_weights = ["400", "700"]  # Default fallback

            # Try each font name variant for CSS1
            for name_variant in font_name_variants:
                css1_url = f"https://fonts.googleapis.com/css?family={urllib.parse.quote_plus(name_variant)}:{','.join(css1_weights)}"

                # Try with multiple user agents for CSS1 too to get both formats
                for user_agent in user_agents:
                    headers = {
                        "User-Agent": user_agent,
                    }

                    r = requests.get(css1_url, headers=headers, timeout=30)
                    if r.status_code == 200:
                        # Parse CSS1 format
                        pattern = re.compile(
                            r"font-style:\s*(normal|italic).*?font-weight:\s*(\d+).*?src:[^;]*?url\(([^)]+)\)",
                            re.IGNORECASE | re.DOTALL,
                        )
                        variants_found = 0
                        for style, weight, url in pattern.findall(r.text):
                            key = (style, weight)
                            if key not in chosen:
                                chosen[key] = []
                            if url not in chosen[key]:
                                chosen[key].append(url)
                                variants_found += 1

                        if variants_found > 0:
                            click.echo(
                                f"✅ Found {variants_found} variants using CSS1 API with {name_variant}"
                            )
                            # Continue trying other user agents for more formats

                if chosen:
                    break  # Success, stop trying variants
        except Exception as e:
            click.echo(f"⚠️  CSS1 fallback failed: {str(e)[:50]}...")

    if not chosen:
        click.echo(
            f"❌ Could not fetch any WOFF variants for '{font_name}' - CSS2 API may be blocking requests"
        )
        return []

    # Detect if this is a variable font (same URLs for multiple weights)
    variable_font_status = _is_variable_font_response(chosen)
    is_variable = variable_font_status["normal"] or variable_font_status["italic"]

    if is_variable:
        click.echo("🔍 Variable font detected - optimizing download strategy")

    # Download the font files (all formats collected)
    saved: list[tuple[str, str, pathlib.Path, bool]] = []

    if is_variable:
        # For variable fonts: download once per style, not per weight
        # Group by style only
        styles_to_download = {}
        for (style, _weight), urls in chosen.items():
            if style not in styles_to_download:
                # Find weight range for this style
                weights = sorted(
                    int(key_weight)
                    for (key_style, key_weight) in chosen.keys()
                    if key_style == style
                )
                min_weight = str(weights[0]) if weights else "400"
                max_weight = str(weights[-1]) if weights else "400"
                styles_to_download[style] = {
                    "urls": urls,
                    "min_weight": min_weight,
                    "max_weight": max_weight,
                }

        click.echo(f"📥 Downloading {len(styles_to_download)} variable font files...")

        for style, info in styles_to_download.items():
            for url in info["urls"]:
                ext = (
                    "woff2"
                    if url.endswith(".woff2")
                    else ("woff" if url.endswith(".woff") else "woff2")
                )
                # Use style-based naming for variable fonts
                filename = f"{font_name.replace(' ', '')}-{style}.{ext}"
                target = dest_dir / filename

                # Skip if already downloaded
                if target.exists():
                    # Add with weight range info
                    saved.append(
                        (
                            style,
                            f"{info['min_weight']}-{info['max_weight']}",
                            target,
                            True,
                        )
                    )
                    continue

                if _download_font_file(url, target):
                    saved.append(
                        (
                            style,
                            f"{info['min_weight']}-{info['max_weight']}",
                            target,
                            True,
                        )
                    )
                    click.echo(
                        f"  ✅ {filename} (weights {info['min_weight']}-{info['max_weight']})"
                    )
                else:
                    click.echo(f"  ⚠️  Failed to download {filename}")
    else:
        # For static fonts: download each weight separately
        total_urls = sum(len(urls) for urls in chosen.values())
        click.echo(
            f"📥 Downloading {len(chosen)} variants ({total_urls} files including all formats)..."
        )

        for (style, weight), urls in chosen.items():
            for url in urls:
                ext = (
                    "woff2"
                    if url.endswith(".woff2")
                    else ("woff" if url.endswith(".woff") else "woff2")
                )
                filename = f"{font_name.replace(' ', '')}-{weight}-{style}.{ext}"
                target = dest_dir / filename

                # Skip if already downloaded
                if target.exists():
                    saved.append((style, weight, target, False))
                    continue

                if _download_font_file(url, target):
                    saved.append((style, weight, target, False))
                else:
                    click.echo(f"⚠️  Failed to download {filename}")

    return saved


def _generate_scss(
    font_name: str,
    font_dir: pathlib.Path,
    woff_variants: list[tuple[str, str, pathlib.Path, bool]]
    | list[tuple[str, str, pathlib.Path]],
):
    """Generate a basic SCSS file with @font-face rules for variants.

    Supports both static and variable fonts. For variable fonts, uses weight ranges.
    """
    scss_dir = pathlib.Path("assets/scss")
    scss_dir.mkdir(parents=True, exist_ok=True)
    scss_file = scss_dir / f"{font_name.replace(' ', '_')}.scss"

    # Pick a TTF/OTF/TTC file (if any) for fallback src
    ttf_files = (
        list(font_dir.glob("*.ttf"))
        + list(font_dir.glob("*.otf"))
        + list(font_dir.glob("*.ttc"))
    )
    ttf_fallback = ttf_files[0].name if ttf_files else None

    # Group variants by (style, weight) to combine woff and woff2
    # variant_info stores: paths, is_variable
    variant_files: dict[tuple[str, str], dict] = {}
    for variant in woff_variants:
        if len(variant) == 4:
            style, weight, path, is_variable = variant
        else:
            style, weight, path = variant
            is_variable = False
        key = (style, weight)
        if key not in variant_files:
            variant_files[key] = {"paths": [], "is_variable": is_variable}
        variant_files[key]["paths"].append(path)

    lines = [f"// Font: {font_name}"]

    for (style, weight), info in sorted(variant_files.items()):
        paths = info["paths"]
        is_variable = info["is_variable"]

        lines.append("@font-face {")
        lines.append(f"  font-family: '{font_name}';")
        lines.append(f"  font-style: {style};")

        # For variable fonts, weight might be a range like "100-900"
        if is_variable and "-" in weight:
            lines.append(f"  font-weight: {weight.replace('-', ' ')};")
        else:
            lines.append(f"  font-weight: {weight};")

        # Build src with all available formats (woff2, woff, ttf)
        src_parts = []

        # Add woff2 first (most modern)
        for path in paths:
            if path.name.endswith(".woff2"):
                rel_woff2 = f"../fonts/{font_name}/{path.name}"
                src_parts.append(f"url('{rel_woff2}') format('woff2')")
                break  # Only add one woff2

        # Add woff next
        for path in paths:
            if path.name.endswith(".woff"):
                rel_woff = f"../fonts/{font_name}/{path.name}"
                src_parts.append(f"url('{rel_woff}') format('woff')")
                break  # Only add one woff

        # Add ttf as fallback
        if ttf_fallback:
            rel_ttf = f"../fonts/{font_name}/{ttf_fallback}"
            src_parts.append(f"url('{rel_ttf}') format('truetype')")

        if src_parts:
            lines.append(f"  src: {', '.join(src_parts)};")

        lines.append("}")
        lines.append("")

    if not woff_variants and ttf_fallback:
        # Minimal single-face rule if only TTF exists
        rel_ttf = f"../fonts/{font_name}/{ttf_fallback}"
        lines.append("@font-face {")
        lines.append(f"  font-family: '{font_name}';")
        lines.append("  font-style: normal;")
        lines.append("  font-weight: 400;")
        lines.append(f"  src: url('{rel_ttf}') format('truetype');")
        lines.append("}")

    scss_file.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _download_full_family(
    font_name: str, force: bool, convert_ttf: bool = False
) -> None:
    assets_fonts = pathlib.Path("assets/fonts")
    font_dir = assets_fonts / font_name

    # Check if already installed
    if font_dir.exists() and not force:
        existing_files = (
            list(font_dir.glob("*.ttf"))
            + list(font_dir.glob("*.otf"))
            + list(font_dir.glob("*.ttc"))
            + list(font_dir.glob("*.woff2"))
            + list(font_dir.glob("*.woff"))
        )
        if existing_files:
            click.echo(
                f"✅ Font '{font_name}' already installed ({len(existing_files)} files)"
            )
            return

    # Get Google Fonts data and validate family exists (for user feedback)
    fonts_data = _get_google_fonts_api_data()
    font_info = None
    normalized_name = _normalize_font_name_for_lookup(font_name)

    # Try exact match first, then normalized match
    for font in fonts_data.get("items", []):
        if (
            font["family"].lower() == font_name.lower()
            or font["family"].lower() == normalized_name
        ):
            font_info = font
            break

    if not font_info:
        click.echo(f"❌ Font '{font_name}' not found in Google Fonts")
        return

    # ZIP first
    click.echo("📦 Attempting family ZIP download (TTF/OTF/TTC + license)...")
    extracted_count, license_found = _download_and_extract_google_fonts_zip(
        font_name, font_dir
    )
    if extracted_count > 0:
        if not license_found:
            _ = _download_license_file(font_name, font_dir / "OFL.txt")
        click.echo(f"✅ Extracted {extracted_count} files from ZIP for '{font_name}'")
    else:
        # GitHub fallback
        click.echo("📚 ZIP failed; trying google/fonts GitHub repository...")
        repo_count, repo_license = _download_from_gfonts_repo(font_name, font_dir)
        if repo_count > 0:
            if not repo_license:
                _ = _download_license_file(font_name, font_dir / "OFL.txt")
            click.echo(
                f"✅ Downloaded {repo_count} files from google/fonts for '{font_name}'"
            )
        else:
            click.echo("⚠️  Could not obtain TTF/OTF/TTC via ZIP or repo")

    # Add WOFF/WOFF2 via CSS2
    click.echo("🌐 Fetching WOFF/WOFF2 variants from CSS2...")
    woff_variants = _download_css2_woff_variants(font_name, font_dir)
    if woff_variants:
        click.echo(f"✅ Added {len(woff_variants)} WOFF variants")
    else:
        click.echo("⚠️  No WOFF variants fetched")

    # Optional: Convert TTF to WOFF/WOFF2
    if convert_ttf:
        if not FONTTOOLS_AVAILABLE:
            click.echo(
                "⚠️  TTF conversion requires fontTools. "
                "Install with: pip install fonttools[woff,woff2] brotli",
                err=True,
            )
        else:
            click.echo("🔄 Converting TTF files to WOFF/WOFF2...")
            ttf_files = list(font_dir.glob("*.ttf")) + list(font_dir.glob("*.otf"))

            if not ttf_files:
                click.echo("  ⚠️  No TTF/OTF files found to convert")
            else:
                converted_count = 0
                for ttf_file in ttf_files:
                    try:
                        generated = _convert_ttf_to_woff(ttf_file)
                        converted_count += len(generated)

                        # Add converted files to woff_variants for SCSS generation
                        # Detect if it's a variable font
                        try:
                            font = TTFont(str(ttf_file))  # type: ignore
                            is_variable = "fvar" in font

                            if is_variable:
                                fvar_table = font["fvar"]  # type: ignore
                                axes = fvar_table.axes  # type: ignore
                                weight_axis = next(
                                    (a for a in axes if a.axisTag == "wght"), None
                                )
                                if weight_axis:
                                    min_w = int(weight_axis.minValue)
                                    max_w = int(weight_axis.maxValue)
                                    weight = f"{min_w}-{max_w}"
                                else:
                                    weight = "400"
                            else:
                                weight = "400"

                            # Determine style from filename
                            style = (
                                "italic"
                                if "italic" in ttf_file.name.lower()
                                else "normal"
                            )

                            for gen_file in generated:
                                woff_variants.append(
                                    (style, weight, gen_file, is_variable)
                                )
                        except Exception:
                            # Fallback if font inspection fails
                            style = (
                                "italic"
                                if "italic" in ttf_file.name.lower()
                                else "normal"
                            )
                            for gen_file in generated:
                                woff_variants.append((style, "400", gen_file, False))

                    except Exception as e:
                        click.echo(
                            f"  ❌ Failed to convert {ttf_file.name}: {e}", err=True
                        )

                if converted_count > 0:
                    click.echo(f"✅ Converted {converted_count} files from TTF/OTF")

    # Ensure license exists
    license_path = font_dir / "OFL.txt"
    if not license_path.exists():
        _ = _download_license_file(font_name, license_path)

    # Generate SCSS
    _generate_scss(font_name, font_dir, woff_variants)
    click.echo(
        f"🧬 SCSS snippet written to assets/scss/{font_name.replace(' ', '_')}.scss"
    )


@click.group()
def main():
    """CLI tool for searching and downloading Google Webfonts."""
    pass


@main.command()
@click.argument("query")
@click.option("--limit", default=10, help="Number of results to show")
@click.option("--details", is_flag=True, help="Show detailed variant information")
def search(query, limit, details):
    """Search for Google Webfonts by name."""
    click.echo(f"🔍 Searching Google Fonts for: '{query}'")

    matches = _search_google_fonts(query, limit)

    if not matches:
        click.echo(f"❌ No fonts found matching '{query}'")
        return

    click.echo(f"📊 Found {len(matches)} matching fonts:")

    for i, font in enumerate(matches, 1):
        family = font["family"]
        variants_count = font["variants"]
        category = font["category"].title()

        click.echo(f"  {i:2d}. {family}")
        click.echo(f"      📂 {category} • {variants_count} variants")

        if details:
            variants_list = ", ".join(
                font["variants_list"][:8]
            )  # Show first 8 variants
            if len(font["variants_list"]) > 8:
                variants_list += "..."
            click.echo(f"      🔤 Variants: {variants_list}")


@main.command()
@click.argument("font_names", nargs=-1)
@click.option(
    "--file",
    "names_file",
    type=click.Path(exists=True, dir_okay=False),
    help="Path to file with font names (one per line)",
)
@click.option("--output", default="fonts", help="Output directory: fonts or web")
@click.option("--force", is_flag=True, help="Reinstall even if font already exists")
@click.option(
    "--convert-ttf",
    is_flag=True,
    help="Convert downloaded TTF/OTF files to WOFF/WOFF2 (requires fonttools)",
)
def download(font_names, names_file, output, force, convert_ttf):
    """Download and install Google Webfonts to assets/fonts/.

    Accepts multiple FONT_NAMES or --file to read names (one per line).

    The --convert-ttf option converts TTF/OTF files to web formats (WOFF/WOFF2).
    This provides full unicode coverage but larger file sizes than Google's subsets.
    Requires: pip install fonttools[woff,woff2] brotli
    """
    names: list[str] = []
    if font_names:
        names.extend(list(font_names))
    if names_file:
        try:
            with open(names_file, encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        names.append(line)
        except OSError as e:
            click.echo(f"❌ Failed to read names file: {e}")
            return

    # Default to help if no names provided
    if not names:
        click.echo("❌ No font names provided. Pass one or more names, or use --file.")
        ctx = click.get_current_context()
        click.echo(ctx.get_help())
        return

    # Deduplicate while preserving order
    seen = set()
    unique_names = []
    for n in names:
        low = n.lower()
        if low not in seen:
            seen.add(low)
            unique_names.append(n)

    for n in unique_names:
        click.echo(f"\n🔤 Processing '{n}'...")
        _download_full_family(n, force, convert_ttf)
    return


def _format_size(size_bytes: int) -> str:
    """Format file size in human-readable form"""
    if size_bytes < 1024:
        return f"{size_bytes}B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f}KB"
    elif size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.1f}MB"
    else:
        return f"{size_bytes / (1024 * 1024 * 1024):.1f}GB"


@main.command()
@click.argument("font_name")
def generate_scss(font_name):
    """Generate SCSS snippet for the font."""
    # Get Google Fonts data
    fonts_data = _get_google_fonts_api_data()

    # Find the font
    font_info = None
    normalized_name = _normalize_font_name_for_lookup(font_name)

    # Try exact match first, then normalized match
    for font in fonts_data.get("items", []):
        if (
            font["family"].lower() == font_name.lower()
            or font["family"].lower() == normalized_name
        ):
            font_info = font
            break

    if not font_info:
        click.echo(f"❌ Font '{font_name}' not found in Google Fonts")
        return

    variants_list = list(font_info.get("files", {}).keys())

    scss_dir = os.path.join(os.getcwd(), "assets", "scss")
    os.makedirs(scss_dir, exist_ok=True)
    scss_file = os.path.join(scss_dir, f"{font_name.replace(' ', '_')}.scss")
    scss_content = f"// Font: {font_name}\n"
    for variant in variants_list:
        weight = "normal"
        style = "normal"
        if "italic" in variant:
            style = "italic"
        if "bold" in variant or "700" in variant:
            weight = "bold"
        scss_content += f"""
@font-face {{
    font-family: '{font_name}';
    src: url('../fonts/{font_name.replace(" ", "_")}.ttf') format('truetype');
    font-weight: {weight};
    font-style: {style};
}}
"""
    scss_content += (
        f"\n// Usage\n// .my-class {{\n"
        f"//     font-family: '{font_name}', sans-serif;\n// }}\n"
    )

    with open(scss_file, "w") as f:
        f.write(scss_content)
    click.echo(f"Generated SCSS snippet at {scss_file}")


@main.command()
@click.option(
    "--repo",
    default="sanderboer/google-font-downloader",
    help="GitHub repository for catalog releases",
)
@click.option("--force", is_flag=True, help="Force update even if cache is fresh")
def update_catalog(repo, force):
    """Update local font catalog from GitHub releases."""
    cache_dir = pathlib.Path.home() / ".fontdownloader" / "cache"
    cache_file = cache_dir / "google_fonts.json"

    if not force and cache_file.exists():
        cache_age = time.time() - cache_file.stat().st_mtime
        if cache_age < 3600:  # 1 hour
            click.echo(
                f"✅ Catalog cache is fresh (updated {cache_age / 60:.1f} minutes ago)"
            )
            return

    click.echo(f"📡 Updating catalog from GitHub releases ({repo})...")

    try:
        from . import download_catalog

        temp_file = cache_dir / "temp_catalog.json"
        cache_dir.mkdir(parents=True, exist_ok=True)

        if download_catalog.download_latest_catalog(
            repo=repo, output_path=str(temp_file)
        ):
            # Validate and transform catalog
            with open(temp_file, encoding="utf-8") as f:
                catalog_data = json.load(f)

            families = len(catalog_data.get("items", []))
            if families < 10:  # Basic validation
                raise ValueError(f"Catalog seems incomplete: only {families} families")

            # Transform to API format and cache
            api_data = {"items": catalog_data.get("items", [])}
            cache_file.write_text(json.dumps(api_data, indent=2), encoding="utf-8")
            temp_file.unlink(missing_ok=True)

            click.echo(f"✅ Catalog updated: {families} font families available")
        else:
            raise RuntimeError("Failed to download catalog from releases")

    except Exception as e:
        click.echo(f"❌ Failed to update catalog: {e}", err=True)
        click.echo(
            "💡 The CLI will fall back to Google Fonts API when needed", err=True
        )


@main.command()
@click.option(
    "--limit", default=100, help="Maximum number of fonts to download (default: 100)"
)
@click.option("--force", is_flag=True, help="Reinstall even if fonts already exist")
@click.option(
    "--convert-ttf",
    is_flag=True,
    help="Convert downloaded TTF/OTF files to WOFF/WOFF2 (requires fonttools)",
)
def download_all(limit, force, convert_ttf):
    """Download a large set of popular Google Webfonts using the consolidated flow."""
    click.echo(f"📥 Downloading top {limit} Google Fonts...")

    fonts_data = _get_google_fonts_api_data()
    fonts_to_download = fonts_data.get("items", [])[:limit]

    click.echo(f"📊 Will download {len(fonts_to_download)} fonts")

    success_count = 0
    for font in fonts_to_download:
        font_name = font["family"]
        click.echo(f"\n🔤 Processing '{font_name}'...")
        _download_full_family(font_name, force, convert_ttf)

        # Consider success if directory contains any font files
        font_dir = pathlib.Path("assets/fonts") / font_name
        files = (
            list(font_dir.glob("*.ttf"))
            + list(font_dir.glob("*.otf"))
            + list(font_dir.glob("*.ttc"))
            + list(font_dir.glob("*.woff*"))
        )
        if files:
            success_count += 1

    click.echo(
        f"\n🎉 Downloaded {success_count}/{len(fonts_to_download)} fonts successfully!"
    )


if __name__ == "__main__":
    main()
