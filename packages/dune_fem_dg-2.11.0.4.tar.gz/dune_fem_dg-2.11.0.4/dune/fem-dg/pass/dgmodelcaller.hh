#ifndef DUNE_FEM_DG_DISCRETEMODELCALLER_HH
#define DUNE_FEM_DG_DISCRETEMODELCALLER_HH

#warning "Deprecated header, #include <dune/fem-dg/pass/modelcaller.hh> instead!"
#include <dune/fem-dg/pass/modelcaller.hh>
#endif
