import argparse
import os
import sys
import pandas as pd

from .pipeline import run_kpi_analysis
from .exceptions import DataValidationError, TrainingError, SimulationError, KPIImpactSimError
from .logging_utils import get_logger

logger = get_logger("cli")


def run_cli() -> None:
    parser = argparse.ArgumentParser(
        description="CLI para entrenar un modelo Ridge y simular impacto en un KPI."
    )

    parser.add_argument("--data", required=True, help="Ruta al CSV de entrada.")
    parser.add_argument("--target", required=True, help="Nombre del KPI objetivo.")
    parser.add_argument(
        "--increment",
        type=float,
        required=True,
        help="Incremento deseado en puntos o porcentaje (según el tipo de variable).",
    )
    parser.add_argument(
        "--output",
        required=False,
        default="simulacion_resultado.csv",
        help="Ruta para guardar la simulación (CSV).",
    )
    parser.add_argument(
        "--top",
        type=int,
        default=None,
        help="Número de variables a mostrar en la explicación (top-n).",
    )

    args = parser.parse_args()

    try:
        logger.info("Iniciando CLI kpi-impact-sim.")
        if not os.path.exists(args.data):
            raise DataValidationError(f"El archivo de datos no existe: {args.data}")

        df = pd.read_csv(args.data)
        logger.info("Dataset cargado desde %s con shape=%s", args.data, df.shape)

        res = run_kpi_analysis(
            df=df,
            target=args.target,
            incremento=args.increment,
            top_n=args.top,
            save_prefix=os.path.splitext(args.output)[0],
        )

        sim = res["simulation"]
        exp = res["explain"]

        # Guardar simulación en el archivo que el usuario espera explícitamente
        if "candidates" in sim and isinstance(sim["candidates"], pd.DataFrame):
            sim["candidates"].to_csv(args.output, index=False)
            logger.info("Simulación guardada en %s", args.output)

        print("✅ Simulación completada.")
        print("📄 Archivo simulación:", args.output)
        print("🔍 Top recomendaciones:")
        if "candidates" in sim and not sim["candidates"].empty:
            print(sim["candidates"].head(10))
        else:
            print("No se generaron candidatos de simulación.")

        print("\n📊 Top variables explicativas:")
        print(exp.head(10))

    except DataValidationError as e:
        logger.error("Error de datos: %s", e)
        print(f"❌ Error de datos: {e}")
        sys.exit(1)
    except (TrainingError, SimulationError) as e:
        logger.error("Error en el pipeline de modelado: %s", e)
        print(f"❌ Error en el pipeline de modelado: {e}")
        sys.exit(1)
    except KPIImpactSimError as e:
        logger.error("Error de librería: %s", e)
        print(f"❌ Error en kpi-impact-sim: {e}")
        sys.exit(1)
    except Exception as e:
        logger.exception("Error inesperado en la CLI.")
        print(f"❌ Error inesperado: {e}")
        sys.exit(1)

