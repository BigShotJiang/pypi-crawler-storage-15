class KPIImpactSimError(Exception):
    """Base para todas las excepciones de la librería."""


class DataValidationError(KPIImpactSimError):
    """Errores relacionados con la validez de los datos de entrada."""


class TrainingError(KPIImpactSimError):
    """Errores durante el entrenamiento del modelo."""


class SimulationError(KPIImpactSimError):
    """Errores durante la simulación de impacto."""


class ConfigurationError(KPIImpactSimError):
    """Errores de configuración o parámetros inconsistentes."""



