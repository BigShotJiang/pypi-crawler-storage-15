"""
kpi-impact-sim: Motor de simulación de impacto para KPIs.
"""

from .simulate import apply_simulation
from .ridge_model import fit_ridge_model
from .preprocessing import preprocess_dataframe
from .utils import tipo_variable
from .explain import explain_kpi_model
from .pipeline import run_kpi_analysis
from .config import settings

__all__ = [
    "apply_simulation",
    "fit_ridge_model",
    "preprocess_dataframe",
    "tipo_variable",
    "explain_kpi_model",
    "run_kpi_analysis",
    "settings",
]



