import os
import pandas as pd

from .preprocessing import preprocess_dataframe
from .ridge_model import fit_ridge_model
from .simulate import apply_simulation
from .utils import tipo_variable
from .explain import explain_kpi_model
from .config import settings
from .exceptions import DataValidationError, TrainingError, SimulationError
from .logging_utils import get_logger

logger = get_logger("pipeline")


def run_kpi_analysis(
    df: pd.DataFrame,
    target: str,
    incremento: float,
    top_n: int = None,
    save_prefix: str | None = None,
) -> dict:
    """
    Ejecuta pipeline completo:
      1. Preprocesamiento
      2. Ridge Regression
      3. Simulación de impacto
      4. Explicabilidad

    Devuelve:
      {
        "ridge": { ... },
        "simulation": { ... },
        "explain": DataFrame
      }
    """
    logger.info("Iniciando run_kpi_analysis(target=%s, incremento=%s)", target, incremento)

    if top_n is None:
        top_n = settings.default_top_n

    # 1. Preprocesamiento
    logger.info("Paso 1/4: preprocesamiento.")
    df_proc = preprocess_dataframe(df)
    df_num = df_proc.select_dtypes(include="number")

    if target not in df_num.columns:
        msg = f"El target '{target}' no existe en el DataFrame numérico."
        logger.error(msg)
        raise DataValidationError(msg)

    if len(df_num) < settings.min_rows:
        msg = f"Se requieren al menos {settings.min_rows} filas, pero se recibieron {len(df_num)}."
        logger.error(msg)
        raise DataValidationError(msg)

    X = df_num.drop(columns=[target])
    y = df_num[target].astype(float)

    # 2. RidgeCV
    logger.info("Paso 2/4: entrenamiento RidgeCV. X.shape=%s, y.len=%s", X.shape, len(y))
    try:
        res_ridge = fit_ridge_model(X, y)
    except Exception as e:
        logger.exception("Error durante el entrenamiento Ridge.")
        raise TrainingError(str(e)) from e

    coefs = res_ridge["coefs"]
    scores = res_ridge.get("scores")

    if scores is not None:
        import numpy as np
        logger.info(
            "RidgeCV entrenado. CV R2 mean=%.4f, std=%.4f",
            float(np.mean(scores)),
            float(np.std(scores)),
        )
    else:
        logger.info("RidgeCV entrenado (scores no disponibles en esta versión).")

    # 3. Simulación
    logger.info("Paso 3/4: simulación de impacto.")
    try:
        sim = apply_simulation(
            coef_series=coefs,
            df_mes=df_num,
            target=target,
            incremento_pts=incremento,
            tipo_variable_func=tipo_variable,
        )
    except Exception as e:
        logger.exception("Error durante la simulación de impacto.")
        raise SimulationError(str(e)) from e

    # 4. Explicabilidad
    logger.info("Paso 4/4: generación de explicabilidad.")
    exp = explain_kpi_model(
        X=X,
        y=y,
        coef_series=coefs,
        top=top_n,
    )

    # Guardado opcional
    if save_prefix:
        base = os.path.splitext(save_prefix)[0]
        sim_path = f"{base}_simulation.csv"
        exp_path = f"{base}_explain.csv"

        try:
            if "candidates" in sim and isinstance(sim["candidates"], pd.DataFrame):
                sim["candidates"].to_csv(sim_path, index=False)
                logger.info("Simulación guardada en %s", sim_path)
            exp.to_csv(exp_path, index=False)
            logger.info("Explicación guardada en %s", exp_path)
        except Exception as e:
            logger.warning("No se pudieron guardar archivos de salida: %s", e)

    result = {
        "ridge": res_ridge,
        "simulation": sim,
        "explain": exp,
    }
    logger.info("run_kpi_analysis completado correctamente.")
    return result

