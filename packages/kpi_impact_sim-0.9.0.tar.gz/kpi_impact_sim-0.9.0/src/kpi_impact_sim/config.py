from dataclasses import dataclass
import os


@dataclass
class KPIImpactSettings:
    """
    Config central de la librería.

    Nota:
    - No toques esto a lo loco desde el usuario final; mejor override vía env
      o pasando parámetros a las funciones de alto nivel.
    """
    min_rows: int = 30
    default_increment: float = 0.02
    default_top_n: int = 5
    logging_level: str = "INFO"

    def apply_env_overrides(self) -> "KPIImpactSettings":
        level = os.getenv("KPI_IMPACT_SIM_LOG_LEVEL")
        if level:
            self.logging_level = level.upper()
        return self


# Instancia global usada internamente
settings = KPIImpactSettings().apply_env_overrides()


