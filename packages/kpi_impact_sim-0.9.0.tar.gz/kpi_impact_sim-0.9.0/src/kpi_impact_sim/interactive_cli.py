"""
CLI interactivo (wizard) para kpi-impact-sim.

Se ejecuta con:
    py -m kpi_impact_sim.interactive_cli
o, si tienes definido entry point:
    kpi-impact-sim-interactive
"""

import os
import sys
import traceback
from typing import Optional

import pandas as pd

from .pipeline import run_kpi_analysis
from .utils import tipo_variable


SEPARATOR = "-" * 70


def _input_non_empty(prompt: str) -> str:
    """Pide texto no vacío."""
    while True:
        v = input(prompt).strip()
        if v:
            return v
        print("⚠ Entrada vacía. Intenta de nuevo.")


def _input_float(prompt: str) -> float:
    """Pide un float válido."""
    while True:
        v = input(prompt).strip().replace(",", ".")
        try:
            return float(v)
        except ValueError:
            print("⚠ Ingresa un número válido (ej: 0.02 o 2).")


def _choose_target_column(df: pd.DataFrame) -> str:
    """
    Muestra columnas y permite elegir target.
    Si solo hay 1 numérica candidata, la propone por defecto.
    """
    print(SEPARATOR)
    print("📊 Columnas detectadas en el dataset:")
    for i, c in enumerate(df.columns):
        print(f"  [{i}] {c}  (dtype={df[c].dtype})")

    # Candidatos numéricos
    numeric_cols = df.select_dtypes(include="number").columns.tolist()

    if not numeric_cols:
        raise ValueError("No se encontraron columnas numéricas en el dataset.")

    print(SEPARATOR)
    print("🔍 Columnas numéricas candidatas a KPI target:")
    for i, c in enumerate(numeric_cols):
        print(f"  [{i}] {c}")

    if len(numeric_cols) == 1:
        only = numeric_cols[0]
        print(f"\n⚙ Usando único candidato como target por defecto: '{only}'")
        return only

    while True:
        idx_str = input("\n👉 Ingresa el índice de la columna target (ej: 0): ").strip()
        try:
            idx = int(idx_str)
            if 0 <= idx < len(numeric_cols):
                return numeric_cols[idx]
        except ValueError:
            pass
        print("⚠ Índice inválido. Intenta nuevamente.")


def _print_summary(res: dict, target: str, incremento: float) -> None:
    """Imprime resumen compacto de resultados."""
    print(SEPARATOR)
    print("✅ Pipeline completado con éxito.")
    print(f"   Target: {target}")
    print(f"   Incremento solicitado: {incremento}")

    # Simulación
    sim = res.get("simulation", {})
    base = sim.get("base_target")
    objetivo = sim.get("objetivo")
    candidates = sim.get("candidates")

    if base is not None and objetivo is not None:
        print(SEPARATOR)
        print("🎯 KPI objetivo")
        print(f"   Base histórica: {base:.4f}")
        print(f"   Objetivo tras simulación: {objetivo:.4f}")

    if candidates is not None and not candidates.empty:
        print(SEPARATOR)
        print("📌 Top recomendaciones (candidatos factibles):")
        reco = candidates[candidates["feasible"]].copy()
        if reco.empty:
            print("   (Ninguna recomendación marcada como factible con las reglas actuales)")
        else:
            reco = reco.sort_values(
                by="coef", key=lambda s: s.abs(), ascending=False
            ).head(5)
            for _, row in reco.iterrows():
                feat = row["feature"]
                base_k = row["base"]
                nuevo = row["nuevo"]
                reason = row.get("reason", "")
                t = tipo_variable(feat)
                print(
                    f"   - {feat} [{t}] : {base_k:.4f} -> {nuevo:.4f}  (motivo: {reason})"
                )

    # Explicabilidad
    exp = res.get("explain")
    if exp is None:
        exp = res.get("explanation")
    if exp is not None and not exp.empty:
        print(SEPARATOR)
        print("🧠 Top drivers del modelo (beta estandarizado):")
        top = exp.sort_values("abs_beta", ascending=False).head(5)
        for _, row in top.iterrows():
            print(
                f"   - {row['feature']}: beta_std={row['beta_std']:.4f}, "
                f"coef={row['coef']:.4f}, importance={row['importance_score']:.4f}"
            )

    print(SEPARATOR)
    print("💾 Si ejecutaste esto desde un proyecto real, ahora puedes guardar")
    print("   estos resultados en CSV, dashboard o reporte según tus necesidades.")
    print(SEPARATOR)


def main() -> None:
    print(SEPARATOR)
    print("🧩 kpi-impact-sim :: Interactive Wizard")
    print(SEPARATOR)
    print("Este asistente te guía para:")
    print("  1) Cargar un CSV")
    print("  2) Elegir un KPI objetivo")
    print("  3) Definir el incremento deseado")
    print("  4) Ejecutar Ridge + Simulación + Explicación\n")

    # 1. Ruta al CSV
    csv_path = _input_non_empty("📂 Ruta al CSV (o ENTER para salir): ")
    if not os.path.exists(csv_path):
        print(f"❌ No se encontró el archivo: {csv_path}")
        return

    try:
        df = pd.read_csv(csv_path)
    except Exception as e:
        print(f"❌ Error leyendo el CSV: {e}")
        return

    if df.empty:
        print("❌ El CSV está vacío.")
        return

    # 2. Elegir target
    try:
        target = _choose_target_column(df)
    except Exception as e:
        print(f"❌ No se pudo elegir target: {e}")
        return

    # 3. Incremento deseado
    print(SEPARATOR)
    print("📈 Define cuánto quieres incrementar el KPI.")
    print("   Ejemplos:")
    print("     - Si el KPI está en 0–1: 0.02  (≈ +2 puntos porcentuales)")
    print("     - Si está en 0–100:     2     (+2 puntos)")
    print("     - Si es métrico normal: 5     (+5% relativo)")
    incremento = _input_float("👉 Incremento deseado: ")

    # 4. Ejecutar pipeline
    print(SEPARATOR)
    print("🚀 Ejecutando análisis completo (Ridge + Simulación + Explicación)...\n")

    try:
        res = run_kpi_analysis(
            df=df,
            target=target,
            incremento=incremento,
            top_n=5,
            save_prefix=None,
        )
    except Exception as e:
        print("❌ Ocurrió un error ejecutando el análisis:")
        print(f"   {e}")
        # Para debug duro:
        # traceback.print_exc()
        return

    # 5. Resumen
    _print_summary(res, target, incremento)

    print("✅ Wizard finalizado.\n")
    print("Puedes volver a ejecutar el comando para probar otro dataset o KPI.")


if __name__ == "__main__":
    main()
