
def DefineOutputPoints():
    output_points = []
    return output_points 

def DefineCutPlanes():
    cut_planes_list = []
    return cut_planes_list

def DefineDragList():
    drag_list = []
    return drag_list
