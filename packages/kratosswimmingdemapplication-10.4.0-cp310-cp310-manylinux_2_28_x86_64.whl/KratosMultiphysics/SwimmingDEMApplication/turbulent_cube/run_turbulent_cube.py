import KratosSwimmingDEM as script
import os

import pre_calculated_fluid_algorithm
test = script.Solution(pre_calculated_fluid_algorithm)
test.Run()
