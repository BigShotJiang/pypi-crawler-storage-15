import KratosSwimmingDEM as script

import colloids_algorithm
test = script.Solution(colloids_algorithm)
test.Run()
