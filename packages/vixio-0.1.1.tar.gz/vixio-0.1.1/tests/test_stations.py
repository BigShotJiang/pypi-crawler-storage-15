"""
Unit tests for individual stations
"""

import pytest

# TODO: Implement station tests

