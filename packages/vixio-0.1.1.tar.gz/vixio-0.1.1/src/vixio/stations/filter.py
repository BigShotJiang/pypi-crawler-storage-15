"""
FilterStation - Filter chunks by type

Only passes through chunks matching criteria
"""

# TODO: Implement FilterStation

