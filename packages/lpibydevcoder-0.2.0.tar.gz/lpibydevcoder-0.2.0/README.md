LpibyDevCooder
Автор
DevCooder
GitHub - [text](https://github.com/ZeroMurder)

Описание
LpibyDevCooder — минималистичный интерпретируемый язык программирования для обучения и экспериментов. Полностью реализован стек: лексер → парсер → интерпретатор.

🎯 Основные возможности
текст
✅ Арифметика: +, -, *, /
✅ Переменные: x := 10
✅ Ввод/вывод: pr(), ind()
✅ 30+ встроенных функций
✅ Типы: числа, строки, списки, словари
✅ REPL с историей команд
✅ CLI: lpi file.lpi
✅ Обработка ошибок
🏗️ Компоненты
текст
lexer.py     # Токенизатор (30+ токенов)
parser.py    # Парсер AST
interpreter.py # Интерпретатор
__init__.py  # REPL + CLI
setup.py     # pip install -e .
🚀 Примеры кода
текст
# Арифметика
pr(3 + 5 * 2)    # 13

# Переменные
x := 10; y := 20
pr(x + y)        # 30

# Списки
lst := list(3,1,2)
pr(sort(lst))    # [1,2,3]

# Массивы
vec := vec(5)    # [0,0,0,0,0]
arr := arr(3,99) # [99,99,99]

# Функции
pr(mx(1,5,3))    # 5
pr(bit(42))      # 101010
📋 Быстрый старт
Установка
удар
pip install lpibydevcoder
Запуск
удар
# REPL
lpi

# Файл
lpi script.lpi

# В Python
from lpibydevcoder import lpi_eval
lpi_eval('pr("Hello!")')
REPL пример
текст
lpi> pr(42 + 10)
52
lpi> x := 5
lpi> pr(x * 2)
10
lpi> help()
📚 Встроенные функции
Вывод/ввод	Конвертация	Математика	Списки
pr()	st()	square()	list()
ind()	in()	ab()	sort()
fl()	mx()	rev()
rn()	mn()	range()
Строки	Битовые	Массивы	Прочее
sr()	bit()	vec()	len()
len()		arr()	help()
nosq()
🎮 Цели проекта
Обучение компиляторам

Быстрые скрипты

Расширяемость

Производительность

LpibyDevCooder — идеальная платформа для изучения языковых технологий и создания скриптов!​