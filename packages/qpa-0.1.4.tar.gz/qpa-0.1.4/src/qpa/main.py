def main():
    print("Hello from pq!")


if __name__ == "__main__":
    main()
