__version__ = "0.1.4"

from .core import say_hello, say_goodbye  # noqa: F401 忽略导入未使用警告

__all__ = ["say_hello", "say_goodbye"]