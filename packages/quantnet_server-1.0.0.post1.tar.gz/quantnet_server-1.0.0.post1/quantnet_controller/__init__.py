"""Top-level package for quantnet-controller."""

__author__ = """ESnet"""
__email__ = 'quantum@es.net'
__version__ = '1.0.0.post1'
