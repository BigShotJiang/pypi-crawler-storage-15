"""Top-level package for quantnet-controller."""

__author__ = """Liang Zhang"""
__email__ = 'lzhang9@es.net'
__version__ = '0.1.0'
