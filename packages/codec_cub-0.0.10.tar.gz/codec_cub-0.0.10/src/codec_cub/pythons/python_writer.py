"""A proof of concept Python file handler for reading/writing Python database modules."""

from __future__ import annotations

from importlib.machinery import ModuleSpec, SourceFileLoader
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
from typing import TYPE_CHECKING, Any, Final, Protocol, TypedDict

from codec_cub.general.base_file_handler import BaseFileHandler
from codec_cub.pythons.builders.fluent_builders import DictLiteralBuilder, ListLiteralBuilder
from codec_cub.pythons.file_builder import FileBuilder
from codec_cub.pythons.type_annotation import TypeAnnotation
from codec_cub.text.bytes_handler import BytesFileHandler

if TYPE_CHECKING:
    from types import ModuleType

    from _typeshed import StrPath


class ColumnType(TypedDict):
    """Row type for 'settings' table."""

    name: str
    type: str
    default: Any
    nullable: bool
    primary_key: bool
    autoincrement: bool


class RowProtocol(Protocol):
    """Protocol for a database row."""


class PyDBProtocol(Protocol):
    """Protocol for Python database modules."""

    VERSION: Final[tuple[int, ...]]
    TABLES: Final[tuple]
    TABLE_COUNT: int

    SCHEMAS: dict[str, list[ColumnType]]
    ROW_COUNT: int
    ROWS: list[RowProtocol]


class PythonWriter(BaseFileHandler):
    """A file handler for writing and reading from Python files."""

    def __init__(self, file: StrPath, touch: bool = False) -> None:
        """Initialize the Python file handler.

        Args:
            file: Path to the Python file
            touch: Whether to create the file if it doesn't exist
        """
        file = Path(file)
        super().__init__(file=file)
        self._bytes = BytesFileHandler(file=file, touch=touch)

    def read(self, **kwargs) -> PyDBProtocol:  # noqa: ARG002
        """Read and return the Python database module."""
        return self._load_module(self.file)  # type: ignore[return-value]

    def write(self, data: dict[str, Any], **kwargs) -> None:  # noqa: ARG002
        """Write a complete .pydb file from structured data.

        Args:
            data: Dictionary containing:
                - version: tuple[int, ...] - Semantic version
                - tables: list[str] - Table names
                - schemas: list[dict] - Column definitions
                - rows: list[dict] - Data rows
            **kwargs: Additional keyword arguments (unused)

        Example:
            >>> data = {
            ...     "version": (1, 0, 0),
            ...     "tables": ["users"],
            ...     "schemas": [
            ...         {
            ...             "name": "id",
            ...             "type": "int",
            ...             "default": 0,
            ...             "nullable": False,
            ...             "primary_key": True,
            ...             "autoincrement": True,
            ...         }
            ...     ],
            ...     "rows": [{"id": 1, "username": "alice"}],
            ... }
            >>> writer.write(data)
        """
        file = FileBuilder()

        file.header.docstring("Python Database file - Auto-generated")
        file.from_future("annotations")
        file.from_typing("Any", "Final", "Protocol", "TypedDict")

        version = data.get("version", (1, 0, 0))
        tables = data.get("tables", [])
        schemas = data.get("schemas", [])
        rows = data.get("rows", [])

        file.variable("VERSION").type_hint(TypeAnnotation("Final[tuple[int, ...]]")).value(self._to_code_str(version))

        file.variable("TABLES").type_hint(TypeAnnotation("Final[tuple[str, ...]]")).value(
            self._to_code_str(tuple(tables))
        )

        file.variable("COUNT").type_hint(TypeAnnotation("int")).value("len(TABLES)")
        file.body.newline()

        file.body.add(self._generate_column_type_class())
        file.body.add(self._generate_row_protocol_class())

        file.variable("SCHEMAS").type_hint(TypeAnnotation.list_of("ColumnType")).value(self._to_code_str(schemas))

        file.body.newline()

        file.variable("ROWS").type_hint(TypeAnnotation.list_of("RowProtocol")).value(self._to_code_str(rows))

        output = file.render(add_section_separators=True)
        self.file.write_text(output)

    def append(self, data: dict[str, Any] | list[dict[str, Any]], **kwargs) -> None:  # noqa: ARG002
        """Append rows to an existing .pydb file.

        Args:
            data: Single row dict or list of row dicts to append
            **kwargs: Additional keyword arguments (unused)

        Example:
            >>> writer.append({"id": 3, "username": "charlie"})
            >>> writer.append([{"id": 4, "username": "dave"}, {"id": 5, "username": "eve"}])
        """
        rows = [data] if isinstance(data, dict) else data

        content = self.file.read_text()

        rows_marker = "ROWS: list[RowProtocol] = ["
        if rows_marker not in content:
            raise ValueError("Invalid .pydb file: ROWS definition not found")

        closing_bracket_idx = content.rfind("]")
        if closing_bracket_idx == -1:
            raise ValueError("Invalid .pydb file: closing bracket not found")

        before_close = content[:closing_bracket_idx].rstrip()

        new_rows_code = ",\n    ".join(self._to_code_str(row) for row in rows)

        needs_comma = not before_close.endswith("[")
        comma = "," if needs_comma else ""

        new_content = f"{before_close}{comma}\n    {new_rows_code},\n]"

        self.file.write_text(new_content)

    @staticmethod
    def _load_module(path: StrPath) -> ModuleType:
        """Load a Python module from the given file path.

        Args:
            path: Path to the Python file

        Returns:
            The loaded Python module
        """
        pydb = Path(path)
        name: str = pydb.stem
        spec: ModuleSpec | None = spec_from_file_location(
            name,
            pydb,
            loader=SourceFileLoader(name, str(pydb)),
        )
        if spec is None:
            raise ImportError(f"Could not load module spec from path: {path}")
        if spec.loader is None:
            raise ImportError(f"No loader found for module spec from path: {path}")
        module: ModuleType = module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    @staticmethod
    def _to_code_str(value: Any) -> str:
        """Convert a Python value to its code string representation.

        Handles nested dicts, lists, tuples, and primitives with proper formatting.

        Args:
            value: The Python value to convert

        Returns:
            String representation suitable for Python code
        """
        if isinstance(value, dict):
            if not value:
                return "{}"
            builder = DictLiteralBuilder(indent=0)
            for k, v in value.items():
                builder.entry(PythonWriter._to_code_str(k), PythonWriter._to_code_str(v))
            return builder.render()

        if isinstance(value, list):
            if not value:
                return "[]"
            builder = ListLiteralBuilder(indent=0)
            for item in value:
                builder.add(PythonWriter._to_code_str(item))
            return builder.render()

        if isinstance(value, tuple):
            if not value:
                return "()"
            items = ", ".join(PythonWriter._to_code_str(item) for item in value)
            return f"({items},)" if len(value) == 1 else f"({items})"

        if isinstance(value, str):
            return repr(value)

        if isinstance(value, bool):
            return "True" if value else "False"

        if value is None:
            return "None"

        return str(value)

    @staticmethod
    def _generate_column_type_class() -> str:
        """Generate the ColumnType TypedDict class definition.

        Returns:
            Complete class definition as a string
        """
        from codec_cub.pythons.builders.class_builder import ClassBuilder  # noqa: PLC0415
        from codec_cub.pythons.parts import Attribute  # noqa: PLC0415

        attributes = [
            Attribute(name="name", annotations="str"),
            Attribute(name="type", annotations="str"),
            Attribute(name="default", annotations="Any"),
            Attribute(name="nullable", annotations="bool"),
            Attribute(name="primary_key", annotations="bool"),
            Attribute(name="autoincrement", annotations="bool"),
        ]

        cls = ClassBuilder(
            name="ColumnType",
            bases="TypedDict",
            docstring="Column definition for database schema.",
            attributes=attributes,
        )
        return cls.render()

    @staticmethod
    def _generate_row_protocol_class() -> str:
        """Generate the RowProtocol Protocol class definition.

        Returns:
            Complete class definition as a string
        """
        from codec_cub.pythons.builders.class_builder import ClassBuilder  # noqa: PLC0415

        cls = ClassBuilder(
            name="RowProtocol",
            bases="Protocol",
            docstring="Protocol for a database row.",
        )
        return cls.render()
