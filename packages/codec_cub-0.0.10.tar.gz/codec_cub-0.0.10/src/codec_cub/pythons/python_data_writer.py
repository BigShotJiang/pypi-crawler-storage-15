"""Generic Python data structure writer for serializing dicts/lists to Python files."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any

from codec_cub.pythons._protocols import CodeBuilder
from codec_cub.pythons.builders.fluent_builders import DictLiteralBuilder, ListLiteralBuilder
from codec_cub.pythons.file_builder import FileBuilder
from codec_cub.pythons.type_annotation import TypeAnnotation

if TYPE_CHECKING:
    from funcy_bear.typing_stuffs import StrPath


class PythonDataWriter:
    """Write arbitrary Python data structures (dicts/lists) to executable Python files.

    Perfect for:
    - Test fixtures (serialized Pydantic models)
    - Configuration files
    - Data snapshots
    - Generated constants

    Example:
        >>> writer = PythonDataWriter("fixtures/data.py")
        >>> writer.write(
        ...     variables={"CONFIG": {"debug": True}, "VERSION": (1, 0, 0)},
        ...     docstring="Auto-generated configuration",
        ...     type_hints={"CONFIG": "dict[str, Any]"},
        ... )
    """

    def __init__(self, file: StrPath, touch: bool = False) -> None:
        """Initialize the Python data writer.

        Args:
            file: Path to the Python file to write
            touch: Whether to create parent directories if they don't exist
        """
        self.file = Path(file)
        if touch:
            self.file.parent.mkdir(parents=True, exist_ok=True)

    def write(
        self,
        variables: dict[str, Any] | None = None,
        *,
        docstring: str | None = None,
        type_hints: dict[str, str | TypeAnnotation] | None = None,
        imports: list[str] | None = None,
        from_imports: dict[str, list[str]] | None = None,
        builders: list[CodeBuilder] | None = None,
    ) -> None:
        """Write variables and code builders to a Python file.

        Args:
            variables: Dictionary mapping variable names to their values (or CodeBuilder objects)
            docstring: Optional module-level docstring
            type_hints: Optional type hints for variables (var_name -> type)
            imports: Optional list of modules to import (e.g., ["os", "sys"])
            from_imports: Optional dict of from imports (e.g., {"typing": ["Any", "Dict"]})
            builders: Optional list of CodeBuilder objects (classes, functions, enums)

        Example:
            >>> writer.write(
            ...     variables={
            ...         "CONFIG": {"debug": True},
            ...         "VERSION": (1, 2, 3),
            ...     },
            ...     builders=[
            ...         ClassBuilder("User", attributes=[...]),
            ...         FunctionBuilder("process").returns("None"),
            ...     ],
            ...     docstring="Generated module",
            ...     type_hints={"CONFIG": "dict[str, Any]"},
            ... )

        Note:
            If a variable value is a CodeBuilder, it will be rendered directly
            to the body section (not as a variable assignment).
        """
        file = FileBuilder()

        if docstring:
            file.header.docstring(docstring)

        file.from_future("annotations")

        variables = variables or {}
        builders = builders or []
        type_hints = type_hints or {}

        needs_typing: dict[str, str | TypeAnnotation] | bool = type_hints or any(
            isinstance(v, (dict, list)) and v for v in variables.values() if not isinstance(v, CodeBuilder)
        )
        if needs_typing:
            file.from_typing("Any")

        if imports:
            for module in imports:
                file.add_import(module)

        if from_imports:
            for module, names in from_imports.items():
                file.add_from_import(module, names)

        for var_name, value in variables.items():
            if isinstance(value, CodeBuilder):
                file.add(value)
            else:
                hint: str | TypeAnnotation | None = type_hints.get(var_name)
                if hint:
                    if isinstance(hint, str):
                        hint = TypeAnnotation(hint)
                    file.variable(var_name).type_hint(hint).value(self._to_code_str(value))
                else:
                    file.body.add(f"{var_name} = {self._to_code_str(value)}")

        for builder in builders:
            file.add(builder)

        output: str = file.render(add_section_separators=True)
        self.file.write_text(output)

    @staticmethod
    def _to_code_str(value: Any) -> str:
        """Convert a Python value to its code string representation.

        Handles nested dicts, lists, tuples, and primitives with proper formatting.

        Args:
            value: The Python value to convert

        Returns:
            String representation suitable for Python code
        """
        if isinstance(value, dict):
            if not value:
                return "{}"
            builder = DictLiteralBuilder(indent=0)
            for k, v in value.items():
                builder.entry(PythonDataWriter._to_code_str(k), PythonDataWriter._to_code_str(v))
            return builder.render()

        if isinstance(value, list):
            if not value:
                return "[]"
            builder = ListLiteralBuilder(indent=0)
            for item in value:
                builder.add(PythonDataWriter._to_code_str(item))
            return builder.render()

        if isinstance(value, tuple):
            if not value:
                return "()"
            items = ", ".join(PythonDataWriter._to_code_str(item) for item in value)
            return f"({items},)" if len(value) == 1 else f"({items})"

        if isinstance(value, str):
            return repr(value)

        if isinstance(value, bool):
            return "True" if value else "False"

        if value is None:
            return "None"

        return str(value)
