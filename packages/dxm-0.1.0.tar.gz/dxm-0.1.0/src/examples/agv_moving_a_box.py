"""
Simple AGV example: one AGV moving boxes between a source and sink.
"""
import json

from dxm.agv.agv import AGV
from dxm.agv.items import Box
from dxm.agv.location import Location
from dxm.agv.planning import TripPlan, Waypoint, WaypointType
from dxm.agv.store_location import StoreLocation
from dxm.core.environment import RecordingEnvironment


def main():
    env = RecordingEnvironment()

    start_loc = Location(x=500, y=500)
    agv = AGV(env, start_location=start_loc, speed=100.0)

    source_loc = StoreLocation(env, x=150, y=500, initial_items=[Box(), Box(), Box()])
    sink_loc = StoreLocation(env, x=500, y=150)

    plan = TripPlan([
        Waypoint(source_loc, WaypointType.SOURCE),
        Waypoint(sink_loc, WaypointType.SINK),
        Waypoint(start_loc, WaypointType.PASS),
        Waypoint(source_loc, WaypointType.SOURCE),
        Waypoint(sink_loc, WaypointType.SINK),
        Waypoint(start_loc, WaypointType.PASS),
    ])

    agv.schedule_plan(env, plan)

    # Run simulation
    print("Running simulation for 30 seconds...")
    env.run(until=30)
    print("Simulation complete.")

    # Export recording
    recording = env.get_recording()
    print(f"Recorded {len(recording.segments_by_entity)} entities")

    import os
    os.makedirs("simulation-records", exist_ok=True)

    with open("simulation-records/agv_box_recording.json", "w") as f:
        json.dump(recording.to_dict(), f, indent=2)
    print("Recording exported to simulation-records/agv_box_recording.json")


if __name__ == "__main__":
    main()
