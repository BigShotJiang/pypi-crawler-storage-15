import pytest

from protools import seqfilter


@pytest.mark.xfail(reason="Not implemented")
def test_standard_aa_filter():
    # TODO
    assert False


@pytest.mark.xfail(reason="Not implemented")
def test_filter_fasta():
    # TODO
    assert False
