import pytest
from protools import seqfixer


@pytest.mark.xfail(reason="Not implemented")
def test_deduplicated_seq():
    # TODO
    assert False


@pytest.mark.xfail(reason="Not implemented")
def test_split():
    # TODO
    assert False
