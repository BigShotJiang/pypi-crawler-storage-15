# DON'T DELETE!
# useful to start smth without pytest and not to run in main script!

from base_aux.pyqt.m4_gui import *


class Example(Gui):
    START = True
    HL_STYLES = HlStylesExample()


# =====================================================================================================================
if __name__ == '__main__':
    Example()


# =====================================================================================================================
