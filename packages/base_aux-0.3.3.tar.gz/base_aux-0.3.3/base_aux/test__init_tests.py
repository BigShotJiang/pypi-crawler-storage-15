"""
NOTE
----
do not delete!

GOAL
----
make a touch point for starting tests by LeftMouse on BASE_AUX directory
if no such files (test__*) in root - no ability to start it!!!
"""