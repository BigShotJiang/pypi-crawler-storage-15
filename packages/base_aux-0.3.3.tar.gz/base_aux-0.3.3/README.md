![Ver/TestedPython](https://img.shields.io/pypi/pyversions/base_aux)
![Ver/Os](https://img.shields.io/badge/os_development-Windows-blue)  
![repo/Created](https://img.shields.io/github/created-at/centroid457/base_aux)
![Commit/Last](https://img.shields.io/github/last-commit/centroid457/base_aux)
![Tests/GitHubWorkflowStatus](https://github.com/centroid457/base_aux/actions/workflows/test_linux.yml/badge.svg)
![Tests/GitHubWorkflowStatus](https://github.com/centroid457/base_aux/actions/workflows/test_windows.yml/badge.svg)  
![repo/Size](https://img.shields.io/github/repo-size/centroid457/base_aux)
![Commit/Count/t](https://img.shields.io/github/commit-activity/t/centroid457/base_aux)
![Commit/Count/y](https://img.shields.io/github/commit-activity/y/centroid457/base_aux)
![Commit/Count/m](https://img.shields.io/github/commit-activity/m/centroid457/base_aux)

# base_aux (current v0.3.3/![Ver/Pypi Latest](https://img.shields.io/pypi/v/base_aux?label=pypi%20latest))

## DESCRIPTION_SHORT
collect all my previous modules in one package

## DESCRIPTION_LONG



## Features


********************************************************************************
## License
See the [LICENSE](LICENSE) file for license rights and limitations (MIT).  
See the [LICENSE_bundled.md](LICENSE_bundled.md) file for parent licenses.  


## Release history
See the [HISTORY.md](HISTORY.md) file for release history.  


## Requirements Installation
NOTE: all requirements for module will install automatically or install manually
```commandline
pip install -r requirements.txt
```


## Module Installation
```commandline
pip install base-aux
```


## Module Import
```python
import base_aux
```


********************************************************************************
## USAGE EXAMPLES
See tests, sourcecode and docstrings for other examples.  

********************************************************************************
