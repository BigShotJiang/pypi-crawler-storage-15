from typing import *
from pydantic import BaseModel, Field

class DemoProjectRequest(BaseModel):
    """
    DemoProjectRequest model
        Request for creating a demo project.
            """
    model_config = {
        "populate_by_name": True,
        "validate_assignment": True
    }
    
    template_id : Optional[Union[int,None]] = Field(validation_alias="template_id" , default = None )
    