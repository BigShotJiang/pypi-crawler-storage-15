from typing import *
import httpx


from ..models import *
from ..api_config import APIConfig, HTTPException

async def listProjects(api_config_override : Optional[APIConfig] = None, *, workspace_id : int, page : Optional[int] = None, per_page : Optional[int] = None, status : Optional[Union[str,None]] = None, X_API_Key : Optional[Union[str,None]] = None, X_Worker_Token : Optional[Union[str,None]] = None, X_Test_User_Id : Optional[Union[str,None]] = None) -> ProjectListResponse:
    api_config = api_config_override if api_config_override else APIConfig()

    base_path = api_config.base_path
    path = f'/v1/workspaces/{workspace_id}/projects'
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': f'Bearer { api_config.get_access_token() }',
        'X-API-Key' : X_API_Key,
'X-Worker-Token' : X_Worker_Token,
'X-Test-User-Id' : X_Test_User_Id
    }
    headers = {key:value for (key,value) in headers.items() if value is not None and not (key == 'Authorization' and value == 'Bearer None')}
    query_params : Dict[str,Any] = {
            'page' : page,
'per_page' : per_page,
'status' : status
        }

    query_params = {key:value for (key,value) in query_params.items() if value is not None}

    async with httpx.AsyncClient(base_url=base_path, verify=api_config.verify) as client:
        response = await client.request(
            'get',
        httpx.URL(path),
        headers=headers,
        params=query_params,
            )

    if response.status_code != 200:
        raise HTTPException(response.status_code, f'listProjects failed with status code: {response.status_code}')
    else:
                body = None if 200 == 204 else response.json()

    return ProjectListResponse(**body) if body is not None else ProjectListResponse()
async def createProject(api_config_override : Optional[APIConfig] = None, *, workspace_id : int, data : CreateProjectRequest, X_API_Key : Optional[Union[str,None]] = None, X_Worker_Token : Optional[Union[str,None]] = None, X_Test_User_Id : Optional[Union[str,None]] = None) -> Project:
    api_config = api_config_override if api_config_override else APIConfig()

    base_path = api_config.base_path
    path = f'/v1/workspaces/{workspace_id}/projects'
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': f'Bearer { api_config.get_access_token() }',
        'X-API-Key' : X_API_Key,
'X-Worker-Token' : X_Worker_Token,
'X-Test-User-Id' : X_Test_User_Id
    }
    headers = {key:value for (key,value) in headers.items() if value is not None and not (key == 'Authorization' and value == 'Bearer None')}
    query_params : Dict[str,Any] = {
        }

    query_params = {key:value for (key,value) in query_params.items() if value is not None}

    async with httpx.AsyncClient(base_url=base_path, verify=api_config.verify) as client:
        response = await client.request(
            'post',
        httpx.URL(path),
        headers=headers,
        params=query_params,
                        json = data.model_dump()
                    )

    if response.status_code != 201:
        raise HTTPException(response.status_code, f'createProject failed with status code: {response.status_code}')
    else:
                body = None if 201 == 204 else response.json()

    return Project(**body) if body is not None else Project()
async def getCurrentProject(api_config_override : Optional[APIConfig] = None, *, workspace_id : int, X_API_Key : Optional[Union[str,None]] = None, X_Worker_Token : Optional[Union[str,None]] = None, X_Test_User_Id : Optional[Union[str,None]] = None) -> Project:
    api_config = api_config_override if api_config_override else APIConfig()

    base_path = api_config.base_path
    path = f'/v1/workspaces/{workspace_id}/projects/current'
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': f'Bearer { api_config.get_access_token() }',
        'X-API-Key' : X_API_Key,
'X-Worker-Token' : X_Worker_Token,
'X-Test-User-Id' : X_Test_User_Id
    }
    headers = {key:value for (key,value) in headers.items() if value is not None and not (key == 'Authorization' and value == 'Bearer None')}
    query_params : Dict[str,Any] = {
        }

    query_params = {key:value for (key,value) in query_params.items() if value is not None}

    async with httpx.AsyncClient(base_url=base_path, verify=api_config.verify) as client:
        response = await client.request(
            'get',
        httpx.URL(path),
        headers=headers,
        params=query_params,
            )

    if response.status_code != 200:
        raise HTTPException(response.status_code, f'getCurrentProject failed with status code: {response.status_code}')
    else:
                body = None if 200 == 204 else response.json()

    return Project(**body) if body is not None else Project()
async def getProject(api_config_override : Optional[APIConfig] = None, *, workspace_id : int, project_id : int, X_API_Key : Optional[Union[str,None]] = None, X_Worker_Token : Optional[Union[str,None]] = None, X_Test_User_Id : Optional[Union[str,None]] = None) -> Project:
    api_config = api_config_override if api_config_override else APIConfig()

    base_path = api_config.base_path
    path = f'/v1/workspaces/{workspace_id}/projects/{project_id}'
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': f'Bearer { api_config.get_access_token() }',
        'X-API-Key' : X_API_Key,
'X-Worker-Token' : X_Worker_Token,
'X-Test-User-Id' : X_Test_User_Id
    }
    headers = {key:value for (key,value) in headers.items() if value is not None and not (key == 'Authorization' and value == 'Bearer None')}
    query_params : Dict[str,Any] = {
        }

    query_params = {key:value for (key,value) in query_params.items() if value is not None}

    async with httpx.AsyncClient(base_url=base_path, verify=api_config.verify) as client:
        response = await client.request(
            'get',
        httpx.URL(path),
        headers=headers,
        params=query_params,
            )

    if response.status_code != 200:
        raise HTTPException(response.status_code, f'getProject failed with status code: {response.status_code}')
    else:
                body = None if 200 == 204 else response.json()

    return Project(**body) if body is not None else Project()
async def deleteProject(api_config_override : Optional[APIConfig] = None, *, workspace_id : int, project_id : int, X_API_Key : Optional[Union[str,None]] = None, X_Worker_Token : Optional[Union[str,None]] = None, X_Test_User_Id : Optional[Union[str,None]] = None) -> ProjectDeleteResponse:
    api_config = api_config_override if api_config_override else APIConfig()

    base_path = api_config.base_path
    path = f'/v1/workspaces/{workspace_id}/projects/{project_id}'
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': f'Bearer { api_config.get_access_token() }',
        'X-API-Key' : X_API_Key,
'X-Worker-Token' : X_Worker_Token,
'X-Test-User-Id' : X_Test_User_Id
    }
    headers = {key:value for (key,value) in headers.items() if value is not None and not (key == 'Authorization' and value == 'Bearer None')}
    query_params : Dict[str,Any] = {
        }

    query_params = {key:value for (key,value) in query_params.items() if value is not None}

    async with httpx.AsyncClient(base_url=base_path, verify=api_config.verify) as client:
        response = await client.request(
            'delete',
        httpx.URL(path),
        headers=headers,
        params=query_params,
            )

    if response.status_code != 200:
        raise HTTPException(response.status_code, f'deleteProject failed with status code: {response.status_code}')
    else:
                body = None if 200 == 204 else response.json()

    return ProjectDeleteResponse(**body) if body is not None else ProjectDeleteResponse()
async def updateProject(api_config_override : Optional[APIConfig] = None, *, workspace_id : int, project_id : int, data : ProjectUpdate, X_API_Key : Optional[Union[str,None]] = None, X_Worker_Token : Optional[Union[str,None]] = None, X_Test_User_Id : Optional[Union[str,None]] = None) -> Project:
    api_config = api_config_override if api_config_override else APIConfig()

    base_path = api_config.base_path
    path = f'/v1/workspaces/{workspace_id}/projects/{project_id}'
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': f'Bearer { api_config.get_access_token() }',
        'X-API-Key' : X_API_Key,
'X-Worker-Token' : X_Worker_Token,
'X-Test-User-Id' : X_Test_User_Id
    }
    headers = {key:value for (key,value) in headers.items() if value is not None and not (key == 'Authorization' and value == 'Bearer None')}
    query_params : Dict[str,Any] = {
        }

    query_params = {key:value for (key,value) in query_params.items() if value is not None}

    async with httpx.AsyncClient(base_url=base_path, verify=api_config.verify) as client:
        response = await client.request(
            'patch',
        httpx.URL(path),
        headers=headers,
        params=query_params,
                        json = data.model_dump()
                    )

    if response.status_code != 200:
        raise HTTPException(response.status_code, f'updateProject failed with status code: {response.status_code}')
    else:
                body = None if 200 == 204 else response.json()

    return Project(**body) if body is not None else Project()
async def linkRepoToProject(api_config_override : Optional[APIConfig] = None, *, workspace_id : int, project_id : int, data : LinkRepoRequest, X_API_Key : Optional[Union[str,None]] = None, X_Worker_Token : Optional[Union[str,None]] = None, X_Test_User_Id : Optional[Union[str,None]] = None) -> Project:
    api_config = api_config_override if api_config_override else APIConfig()

    base_path = api_config.base_path
    path = f'/v1/workspaces/{workspace_id}/projects/{project_id}/link-repo'
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': f'Bearer { api_config.get_access_token() }',
        'X-API-Key' : X_API_Key,
'X-Worker-Token' : X_Worker_Token,
'X-Test-User-Id' : X_Test_User_Id
    }
    headers = {key:value for (key,value) in headers.items() if value is not None and not (key == 'Authorization' and value == 'Bearer None')}
    query_params : Dict[str,Any] = {
        }

    query_params = {key:value for (key,value) in query_params.items() if value is not None}

    async with httpx.AsyncClient(base_url=base_path, verify=api_config.verify) as client:
        response = await client.request(
            'post',
        httpx.URL(path),
        headers=headers,
        params=query_params,
                        json = data.model_dump()
                    )

    if response.status_code != 200:
        raise HTTPException(response.status_code, f'linkRepoToProject failed with status code: {response.status_code}')
    else:
                body = None if 200 == 204 else response.json()

    return Project(**body) if body is not None else Project()
async def getProjectCloneInfoForUser(api_config_override : Optional[APIConfig] = None, *, workspace_id : int, project_id : int, X_API_Key : Optional[Union[str,None]] = None, X_Worker_Token : Optional[Union[str,None]] = None, X_Test_User_Id : Optional[Union[str,None]] = None) -> CloneInfo:
    api_config = api_config_override if api_config_override else APIConfig()

    base_path = api_config.base_path
    path = f'/v1/workspaces/{workspace_id}/projects/{project_id}/clone-info'
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': f'Bearer { api_config.get_access_token() }',
        'X-API-Key' : X_API_Key,
'X-Worker-Token' : X_Worker_Token,
'X-Test-User-Id' : X_Test_User_Id
    }
    headers = {key:value for (key,value) in headers.items() if value is not None and not (key == 'Authorization' and value == 'Bearer None')}
    query_params : Dict[str,Any] = {
        }

    query_params = {key:value for (key,value) in query_params.items() if value is not None}

    async with httpx.AsyncClient(base_url=base_path, verify=api_config.verify) as client:
        response = await client.request(
            'post',
        httpx.URL(path),
        headers=headers,
        params=query_params,
            )

    if response.status_code != 200:
        raise HTTPException(response.status_code, f'getProjectCloneInfoForUser failed with status code: {response.status_code}')
    else:
                body = None if 200 == 204 else response.json()

    return CloneInfo(**body) if body is not None else CloneInfo()