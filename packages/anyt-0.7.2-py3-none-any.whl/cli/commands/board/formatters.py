"""Output formatting helpers for board commands."""

import json
from typing import Any, Optional


def format_board_json(
    groups: dict[str, list[dict[str, Any]]],
    group_order: list[str],
    group_labels: dict[str, str],
    total: int,
    message: Optional[str] = None,
) -> str:
    """Format board data as JSON output."""
    return json.dumps(
        {
            "success": True,
            "data": {
                "groups": groups,
                "group_order": group_order,
                "group_labels": group_labels,
                "total": total,
            },
            "message": message,
        }
    )


def format_empty_tasks_json(message: str = "No tasks found") -> str:
    """Format empty tasks response as JSON."""
    return json.dumps(
        {
            "success": True,
            "data": {"groups": {}, "total": 0},
            "message": message,
        }
    )


def format_summary_json(
    period: str,
    done_tasks: list[dict[str, Any]],
    active_tasks: list[dict[str, Any]],
    blocked_tasks: list[dict[str, Any]],
    backlog_tasks: list[dict[str, Any]],
    total: int,
) -> str:
    """Format summary data as JSON output."""
    high_priority_backlog = sorted(
        backlog_tasks, key=lambda t: t.get("priority", 0), reverse=True
    )[:3]
    done_count = len(done_tasks)
    progress_pct = int((done_count / total) * 100) if total > 0 else 0

    return json.dumps(
        {
            "success": True,
            "data": {
                "period": period,
                "done_tasks": done_tasks[:5],
                "active_tasks": active_tasks[:5],
                "blocked_tasks": blocked_tasks,
                "next_priorities": high_priority_backlog,
                "summary": {
                    "total": total,
                    "done": len(done_tasks),
                    "active": len(active_tasks),
                    "backlog": len(backlog_tasks),
                    "blocked": len(blocked_tasks),
                    "progress_pct": progress_pct,
                },
            },
            "message": None,
        }
    )


def format_graph_task_json(
    task_id: str,
    title: str,
    status: str,
    dependencies: list[Any],
    dependents: list[Any],
) -> str:
    """Format single task graph data as JSON output."""
    return json.dumps(
        {
            "success": True,
            "data": {
                "task": {
                    "identifier": task_id,
                    "title": title,
                    "status": status,
                },
                "dependencies": dependencies,
                "dependents": dependents,
            },
            "message": None,
        }
    )


def format_empty_graph_json(message: str = "No tasks found in workspace") -> str:
    """Format empty graph response as JSON."""
    return json.dumps(
        {
            "success": True,
            "data": {
                "nodes": [],
                "edges": [],
                "metadata": {
                    "total_tasks": 0,
                    "total_edges": 0,
                },
            },
            "message": message,
        }
    )


def format_error_json(error: str, message: Optional[str] = None) -> str:
    """Format error response as JSON."""
    return json.dumps(
        {
            "success": False,
            "error": error,
            "message": message or error,
        }
    )


def format_compact_board(
    groups: dict[str, list[dict[str, Any]]],
    group_order: list[str],
    group_labels: dict[str, str],
) -> str:
    """Format board in compact single-line mode."""
    parts: list[str] = []
    for group_key in group_order:
        group_tasks = groups.get(group_key, [])
        count = len(group_tasks)
        label = group_labels.get(group_key, group_key)
        parts.append(f"{label}({count})")
    return " | ".join(parts)
