---
description: Create a new task in AnyTask cloud
argument-hint: <task description>
---

Create a new task in AnyTask cloud: $ARGUMENTS

**Expected input:** A description of what needs to be built (e.g., "Add API endpoint for task comments")

**Workflow:**

1. **Analyze the description:**
   - Break down what needs to be implemented
   - Identify technical requirements
   - Determine priority level (-2 to 2, where 0 is normal)
   - Consider if this depends on other tasks

2. **Review codebase quality check commands:**
   - Look for quality check commands in the project:
     - `Makefile` (e.g., `make lint`, `make test`, `make typecheck`)
     - `package.json` scripts (e.g., `npm run lint`, `npm test`)
     - `pyproject.toml` or `setup.py` (e.g., `pytest`, `ruff`)
     - CI config files (`.github/workflows/`, `.gitlab-ci.yml`)
   - Identify the commands used for:
     - Formatting
     - Linting
     - Type checking
     - Unit tests
     - Integration tests
     - Build verification

3. **Create the task:**
   ```bash
   anyt task add "Task Title" \
     --description "Detailed description with acceptance criteria" \
     --priority 0 \
     --status backlog \
     --labels "feature,backend" \
     --json
   ```

   **Priority levels:**
   - `-2`: Lowest priority
   - `-1`: Low priority
   - `0`: Normal (default)
   - `1`: High priority
   - `2`: Highest/urgent

   **Status options:**
   - `backlog`: Not started (default for new tasks)
   - `todo`: Ready to start
   - `active`: In progress
   - `blocked`: Waiting on something
   - `done`: Completed

4. **Format the description:**
   Include these sections in the description:
   ```
   ## Objectives
   - Specific goal 1
   - Specific goal 2

   ## Acceptance Criteria
   - [ ] Criterion 1
   - [ ] Criterion 2
   - [ ] Tests written and passing

   ## Technical Notes
   Implementation guidance and considerations
   ```

5. **Add dependencies if needed:**
   ```bash
   anyt task dep add {NEW_TASK_ID} --on {DEPENDENCY_ID}
   ```

6. **Pull to local filesystem:**
   ```bash
   anyt pull {NEW_TASK_ID}
   ```
   This creates `.anyt/tasks/{IDENTIFIER}/` with:
   - `task.md` - Task title and description
   - `.meta.json` - Status, priority, labels
   - `context/` - Folder for AI context files

7. **Create quality control checklist:**
   Create `.anyt/tasks/{IDENTIFIER}/context/quality-checklist.md` with the quality checks discovered in step 2:
   ```markdown
   # Quality Control Checklist

   Before marking this task as complete, verify:

   ## Code Quality
   - [ ] Code formatted: `{format_command}`
   - [ ] Linting passes: `{lint_command}`
   - [ ] Type checking passes: `{typecheck_command}`

   ## Testing
   - [ ] Unit tests pass: `{test_command}`
   - [ ] Integration tests pass (if applicable): `{integration_test_command}`

   ## Build
   - [ ] Build succeeds: `{build_command}`

   ## Review
   - [ ] Code reviewed / self-reviewed
   - [ ] No debug code or console.log statements left
   ```

   Replace `{command}` placeholders with actual commands from the project.
   Remove sections that don't apply to the project.

8. **Ask user:**
   - Show the created task summary with its identifier
   - Ask if they want to start working on it now:
     ```bash
     anyt task pick {IDENTIFIER}
     ```
   - Or keep it in backlog for later

**Example:**
```bash
# Create task
anyt task add "Add comment threading support" \
  --description "## Objectives\n- Enable nested replies to comments\n\n## Acceptance Criteria\n- [ ] API supports parent_comment_id\n- [ ] UI shows threaded view\n- [ ] Tests pass" \
  --priority 1 \
  --status backlog \
  --labels "feature,comments" \
  --json

# Add dependency
anyt task dep add DEV-45 --on DEV-42

# Pull to local
anyt pull DEV-45

# Create quality checklist in context folder
# (write quality-checklist.md with project-specific commands)
```

**Important:**
- Only create tasks for actual code implementation work
- Don't create tasks for linting, formatting, or minor docs
- Be specific in acceptance criteria
- Use appropriate priority levels
- Add labels for categorization
- Always create the quality control checklist for the task

Create the task now.
