# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from promptflow.azure._version import VERSION

USER_AGENT = "{}/{}".format("promptflow-azure-sdk", VERSION)
