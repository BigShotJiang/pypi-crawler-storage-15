"""Exception classes for Obra Client."""


class ObraClientError(Exception):
    """Base exception for all Obra Client errors."""

    pass


class APIError(ObraClientError):
    """Raised when Cloud Functions API call fails."""

    def __init__(self, message: str, status_code: int = 0, response_body: str = "") -> None:
        """Initialize APIError.

        Args:
            message: Error message
            status_code: HTTP status code (0 if not applicable)
            response_body: Raw response body from server
        """
        super().__init__(message)
        self.status_code = status_code
        self.response_body = response_body


class ConfigurationError(ObraClientError):
    """Raised when configuration is invalid or missing."""

    pass


class ExecutionError(ObraClientError):
    """Raised when LLM execution fails."""

    def __init__(self, message: str, exit_code: int = 0, stderr: str = "") -> None:
        """Initialize ExecutionError.

        Args:
            message: Error message
            exit_code: Process exit code
            stderr: Standard error output from process
        """
        super().__init__(message)
        self.exit_code = exit_code
        self.stderr = stderr


class TermsNotAcceptedError(APIError):
    """Raised when server rejects request due to terms not accepted.

    This is a specific 403 error indicating the user must run
    'obra-client setup' to accept the Beta Software Agreement.

    Attributes:
        required_version: The terms version that must be accepted
        terms_url: URL to view the terms
        action: Suggested action to resolve the issue
    """

    def __init__(
        self,
        message: str = "Terms not accepted",
        required_version: str = "",
        terms_url: str = "https://obra.dev/terms",
        action: str = "Run 'obra-client setup' to accept terms.",
    ) -> None:
        """Initialize TermsNotAcceptedError.

        Args:
            message: Error message from server
            required_version: The terms version that must be accepted
            terms_url: URL to view the terms
            action: Suggested action to resolve the issue
        """
        super().__init__(
            message=message,
            status_code=403,
            response_body="",
        )
        self.required_version = required_version
        self.terms_url = terms_url
        self.action = action
