- Add an optional domain on the field to limit tracking on certain condition. 

![fields](./static/description/fields.drawio.png)