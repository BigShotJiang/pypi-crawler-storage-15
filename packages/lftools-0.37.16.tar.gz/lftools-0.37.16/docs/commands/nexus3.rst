.. _nexus3:

******
Nexus3
******

.. program-output:: lftools nexus3 --help

.. _nexus3_commands:

Commands
========

.. contents:: Nexus3 Commands
    :local:

.. _nexus3_asset:

asset
-----

.. program-output:: lftools nexus3 asset --help

.. _nexus3_privileges:

privilege
---------

.. program-output:: lftools nexus3 privilege --help

.. _nexus3_repository:

repository
----------

.. program-output:: lftools nexus3 repository --help

.. _nexus3_role:

role
----

.. program-output:: lftools nexus3 role --help

.. _nexus3_script:

script
------

.. program-output:: lftools nexus3 script --help

.. _nexus3_tag:

tag
---

.. program-output:: lftools nexus3 tag --help

.. _nexus3_task:

task
----

.. program-output:: lftools nexus3 task --help

.. _nexus3_user:

user
----

.. program-output:: lftools nexus3 user --help
