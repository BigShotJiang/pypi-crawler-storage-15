*******
License
*******

.. program-output:: lftools license --help

Commands
========

.. contents:: License Commands
    :local:

check
-----

.. program-output:: lftools license check --help
