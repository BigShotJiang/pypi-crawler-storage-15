******
Config
******

.. program-output:: lftools config --help

Commands
========

.. contents:: Config Commands
    :local:

get
---

.. program-output:: lftools config get --help

set
----

.. program-output:: lftools config set --help
