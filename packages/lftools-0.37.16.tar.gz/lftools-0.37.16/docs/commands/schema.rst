******
Schema
******

.. program-output:: lftools schema --help

Commands
========

verify
-------

.. program-output:: lftools schema verify --help
