2025-11-25 Version: 1.2.1
- Update API ModifyNodeNumber: add request parameters Parallelism.
- Update API ModifyNodeNumber: add request parameters TerminationGracePeriodSeconds.


2025-10-22 Version: 1.2.0
- Support API DescribeNodeGroups.


2025-09-12 Version: 1.1.1
- Update API CreateInstanceV1: add request parameters body.AgentNodeGroup.
- Update API CreateInstanceV1: add request parameters body.AutoPay.
- Update API CreateInstanceV1: add request parameters body.GatewayType.
- Update API ModifyDiskSize: add request parameters FastMode.


2025-07-30 Version: 1.1.0
- Support API ChangeResourceGroup.
- Support API CreateInstanceV1.
- Support API CreateServiceLinkedRole.
- Support API DescribeInstances.
- Support API TagResources.
- Support API UnTagResources.


2025-07-02 Version: 1.0.1
- Generated python 2022-10-19 for starrocks.

2025-06-30 Version: 1.0.0
- Update API ModifyCu: add request parameters PromotionOptionNo.
- Update API ModifyDiskNumber: add request parameters PromotionOptionNo.
- Update API ModifyDiskPerformanceLevel: add request parameters PromotionOptionNo.
- Update API ModifyDiskSize: add request parameters PromotionOptionNo.
- Update API ModifyNodeNumber: add request parameters PromotionOptionNo.


