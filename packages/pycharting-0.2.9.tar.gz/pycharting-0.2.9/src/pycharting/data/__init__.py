"""Data processing and management for PyCharting."""
