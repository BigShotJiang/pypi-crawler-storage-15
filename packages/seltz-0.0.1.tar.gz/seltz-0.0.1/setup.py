import setuptools

setuptools.setup(
    name="seltz",
    version="0.0.1",
    author="Elias Bassani",
    author_email="elias.bssn@gmail.com",
    description="",
    long_description="",
    long_description_content_type="text/markdown",
    url="",
    packages=setuptools.find_packages(),
    install_requires=[],
    classifiers=[],
    keywords=[],
    python_requires=">=3.9",
)
