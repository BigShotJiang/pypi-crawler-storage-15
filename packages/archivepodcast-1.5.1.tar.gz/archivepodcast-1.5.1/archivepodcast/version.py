"""Version information."""

__version__ = "1.5.1"  # This is the version of the app, used in pyproject.toml, enforced in a test.
