import sys
import os
import json
import usb.core
from .core import FastbootProtocol

def output_json(success, message):
    if success:
        print(json.dumps({"success": message}))
    else:
        print(json.dumps({"error": message}))

def main():
    if len(sys.argv) < 2:
        output_json(False, "No arguments provided")
        sys.exit(1)

    args = sys.argv[1:]
    
    device = None
    if "USB_FD" in os.environ:
        device = usb.core.find(find_all=True, custom_match=lambda d: True)

    fb = FastbootProtocol(device)
    
    if not fb.connect():
        sys.exit(10)

    success = False
    result = ""

    try:
        cmd_type = args[0]

        if cmd_type == "product":
            success, result = fb.cmd("getvar:product")
            if success: result = result.replace("product:", "").strip()

        elif cmd_type == "getvar" and len(args) > 1:
            var = args[1]
            success, result = fb.cmd(f"getvar:{var}")
            if success: result = result.replace(f"{var}:", "").strip()

        elif cmd_type == "oem" and len(args) > 1:
            sub = " ".join(args[1:])
            success, result = fb.cmd(f"oem {sub}")

        elif cmd_type == "stage" and len(args) > 1:
            success, result = fb.stage(args[1])

        elif cmd_type == "unlock":
            success, result = fb.cmd("oem unlock")

        else:
            success = False
            result = "Invalid command syntax"

    except Exception as e:
        success = False
        result = str(e)

    output_json(success, result)
    sys.exit(0)

if __name__ == "__main__":
    main()