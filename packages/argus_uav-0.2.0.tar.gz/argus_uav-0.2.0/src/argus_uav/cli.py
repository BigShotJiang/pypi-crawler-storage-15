"""CLI entry point for the argus command."""

from argus_uav.cli_main import main

__all__ = ["main"]
