"""Consensus algorithm modules for swarm coordination."""

from argus_uav.consensus.average_consensus import AverageConsensus

__all__ = ["AverageConsensus"]
