from __future__ import annotations

from rich.console import Console
from rich.theme import Theme

console = Console(theme=Theme(), soft_wrap=True)
