
from setuptools import setup
setup(
    name="bridge_transfer_19",
    version="0.1", 
    py_modules=["carrier"],
)
