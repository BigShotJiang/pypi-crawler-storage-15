# Omnissa Horizon Cloud Service Lifecycle Management Plugin SDK

# Getting Started
```shell
pip install -U ohcs
```

https://omnissa.atlassian.net/wiki/spaces/HCS/pages/1118438714/Omnissa+Horizon+Cloud+Lifecycle+Management+Plugin+SDK+-+Developer+Guide
