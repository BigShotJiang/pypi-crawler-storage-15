"""
Copyright (c) Omnissa, LLC. All rights reserved.
This product is protected by copyright and intellectual property laws in the
United States and other countries as well as by international treaties.
"""

import time
from typing import Optional

from loguru import logger

import ohcs.lcm.adapter as adapter
import ohcs.lcm.factory as factory
from ohcs.lcm.config import load_config
from ohcs.lcm.logging_config import setup_logging
from ohcs.rte import rte


def _on_incoming_property(key: str, value: any):
    logger.info(f"_on_incoming_property: {key}={value}")


def serve(config_file: Optional[str] = None):

    logger.info("--------------------------------")
    logger.info("ohcs.lcm start")
    logger.info("--------------------------------")

    config = load_config(config_file)
    setup_logging(config.log)

    instance_map = {"com.vmware.horizon.sg.clouddriver.impl.edgeproxy.RteEdgeProxy": adapter}

    factory.init(config.plugin.path, config.plugin.name)

    rte.init(
        mqtt_config=config.mqtt,
        edge_id=config.hcs.edgeId,
        instance_map=instance_map,
        on_incoming_property=_on_incoming_property,
    )

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        pass
    finally:
        rte.stop()
        logger.info("ohcs.lcm exit")


def info():
    logger.info("TODO")
