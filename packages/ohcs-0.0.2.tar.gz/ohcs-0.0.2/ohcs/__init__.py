"""
Copyright (c) Omnissa, LLC. All rights reserved.
This product is protected by copyright and intellectual property laws in the
United States and other countries as well as by international treaties.
"""

from pathlib import Path

import tomli


def _get_version():
    """Read version from pyproject.toml"""
    try:
        pyproject_path = Path(__file__).parent.parent / "pyproject.toml"
        with open(pyproject_path, "rb") as f:
            pyproject = tomli.load(f)
            return pyproject["project"]["version"]
    except Exception:
        return "unknown"


__version__ = _get_version()
