#!/usr/bin/env python3

"""
Copyright (c) Omnissa, LLC. All rights reserved.
This product is protected by copyright and intellectual property laws in the
United States and other countries as well as by international treaties.
"""

from setuptools import setup, find_packages
import os
import tomli

def read_readme():
    readme_path = os.path.join(os.path.dirname(__file__), "README.md")
    if os.path.exists(readme_path):
        with open(readme_path, "r", encoding="utf-8") as f:
            return f.read()
    return "Omnissa Horizon Cloud Service SDK"

def get_version():
    """Read version from pyproject.toml"""
    pyproject_path = os.path.join(os.path.dirname(__file__), "pyproject.toml")
    with open(pyproject_path, "rb") as f:
        pyproject = tomli.load(f)
        return pyproject["project"]["version"]

setup(
    name="ohcs",
    version=get_version(),
    description="Omnissa Horizon Cloud Service SDK",
    long_description=read_readme(),
    long_description_content_type="text/markdown",
    author="OHCS Team",
    author_email="nanw@omnissa.com",
    url="https://github.com/euc-eng/ohcs-sdk",
    packages=find_packages(),
    include_package_data=True,
    package_data={
        "ohcs": ["**/*.yml", "**/*.yaml", "**/*.json", "**/*.txt"],
    },
    python_requires=">=3.8",
    install_requires=[
        "pyyaml>=6.0",
        "httpx>=0.24.0",
        "click>=8.0",
        "cryptography>=3.4.8",
        "yumako>=0.1.36",
        "loguru>=0.7.3",
        "hcs-cli>=0.1.309",
    ],
    extras_require={
        # Core functionality - lightweight
        "core": [
        ],
        # Runtime Environment - requires MQTT
        "rte": [
            "paho-mqtt>=1.6.0",
        ],
        # All optional dependencies
        "all": [
            "paho-mqtt>=1.6.0",
        ],
        # Development dependencies
        "dev": [
            "pytest>=7.0",
            "pytest-asyncio>=0.21.0",
            "black>=22.0",
            "flake8>=5.0",
            "mypy>=1.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "ohcs=ohcs.__main__:cli",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: System :: Systems Administration",
    ],
    keywords="Omnissa horizon cloud service sdk",
)
