"""Index price helpers."""

from __future__ import annotations

from ..core.types import Price


def index_price(price: Price) -> Price:
    return price
