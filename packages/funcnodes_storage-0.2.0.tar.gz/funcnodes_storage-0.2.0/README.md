Funcnodes Storage
