# Changelog

All notable changes to this project will be documented here.

---

## [1.0.3] - 2025-12-03
### Added
- Initial release of SlowQL
- Critical and High severity detectors
- CI/CD examples (GitHub, GitLab, Jenkins, Pre-Commit)

### Fixed
- MkDocs strict build errors
