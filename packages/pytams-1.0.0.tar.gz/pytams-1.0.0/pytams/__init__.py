"""Documentation about pyTAMS."""

import logging

logging.getLogger(__name__).addHandler(logging.NullHandler())

__author__ = "Lucas Esclapez"
__email__ = "l.esclapez@esciencecenter.nl"
__version__ = "1.0.0"
