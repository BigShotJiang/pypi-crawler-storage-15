from v8unpack.MetaDataObject.Form import Form0


class ExternalDataSourceCubeForm(Form0):
    pass
