from ..MetaDataObject.core.IncludeSimple import IncludeSimple


class ExternalDataSourceCubeCommand(IncludeSimple):
    pass
