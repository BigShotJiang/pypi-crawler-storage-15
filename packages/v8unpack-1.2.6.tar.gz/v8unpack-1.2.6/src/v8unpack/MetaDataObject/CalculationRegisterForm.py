from v8unpack.MetaDataObject.Form import Form1


class CalculationRegisterForm(Form1):
    pass
