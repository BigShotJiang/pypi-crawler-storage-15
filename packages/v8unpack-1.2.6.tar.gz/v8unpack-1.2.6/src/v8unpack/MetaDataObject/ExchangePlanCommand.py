from ..MetaDataObject.core.IncludeSimple import IncludeSimple


class ExchangePlanCommand(IncludeSimple):
    pass
