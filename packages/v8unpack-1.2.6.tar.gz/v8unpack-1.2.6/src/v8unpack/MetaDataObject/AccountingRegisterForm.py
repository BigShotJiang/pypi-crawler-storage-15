from v8unpack.MetaDataObject.Form import Form0


class AccountingRegisterForm(Form0):
    pass
