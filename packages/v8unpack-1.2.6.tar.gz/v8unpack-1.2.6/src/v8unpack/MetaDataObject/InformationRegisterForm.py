from v8unpack.MetaDataObject.Form import Form1


class InformationRegisterForm(Form1):
    pass
