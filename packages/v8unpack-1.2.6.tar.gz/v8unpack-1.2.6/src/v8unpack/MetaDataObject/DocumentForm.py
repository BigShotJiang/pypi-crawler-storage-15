from v8unpack.MetaDataObject.Form import Form1


class DocumentForm(Form1):
    pass
