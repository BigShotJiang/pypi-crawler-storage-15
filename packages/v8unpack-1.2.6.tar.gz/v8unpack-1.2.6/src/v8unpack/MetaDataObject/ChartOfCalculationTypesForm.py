from v8unpack.MetaDataObject.Form import Form1


class ChartOfCalculationTypesForm(Form1):
    pass
