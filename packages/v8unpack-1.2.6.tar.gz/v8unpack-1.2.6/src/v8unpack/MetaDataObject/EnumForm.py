from v8unpack.MetaDataObject.Form import Form1


class EnumForm(Form1):
    pass
