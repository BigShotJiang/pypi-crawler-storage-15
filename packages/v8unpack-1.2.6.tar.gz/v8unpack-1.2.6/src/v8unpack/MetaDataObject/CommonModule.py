from ..MetaDataObject.core.Simple import SimpleNameFolder


class CommonModule(SimpleNameFolder):
    ext_code = {'obj': 0}
    pass
