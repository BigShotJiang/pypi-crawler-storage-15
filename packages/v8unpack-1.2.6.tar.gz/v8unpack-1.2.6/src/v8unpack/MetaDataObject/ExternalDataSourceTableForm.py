from v8unpack.MetaDataObject.Form import Form0


class ExternalDataSourceTableForm(Form0):
    pass
