from ..MetaDataObject.core.IncludeSimple import IncludeSimple


class EnumCommand(IncludeSimple):
    pass
