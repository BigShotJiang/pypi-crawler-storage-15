from ..MetaDataObject.core.SimpleWithInfo import SimpleWithInfo


class ScheduledJob(SimpleWithInfo):
    pass
