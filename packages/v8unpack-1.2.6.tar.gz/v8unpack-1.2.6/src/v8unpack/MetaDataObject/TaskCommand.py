from ..MetaDataObject.core.IncludeSimple import IncludeSimple


class TaskCommand(IncludeSimple):
    pass
