from ..FormElements27.FormElement import FormProps as FormProps27, FormElement as FormElement27, Anchor


class FormProps(FormProps27):
    name_index = 3
