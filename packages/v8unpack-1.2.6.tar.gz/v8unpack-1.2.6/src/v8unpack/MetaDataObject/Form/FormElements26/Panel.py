from ..FormElements27.Panel import Panel as Panel27


class Panel(Panel27):
    ver = 26

