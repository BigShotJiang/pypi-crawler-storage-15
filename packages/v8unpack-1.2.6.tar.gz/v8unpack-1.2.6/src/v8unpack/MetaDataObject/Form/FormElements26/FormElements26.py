from .FormElement import FormProps
from .Panel import Panel
from ..FormElements27.FormElements27 import FormElements27


class FormElements26(FormElements27):
    FormProps = FormProps
    Panel = Panel
