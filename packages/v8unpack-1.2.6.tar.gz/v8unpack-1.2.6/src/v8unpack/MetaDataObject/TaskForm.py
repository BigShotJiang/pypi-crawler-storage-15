from v8unpack.MetaDataObject.Form import Form0


class TaskForm(Form0):
    pass
