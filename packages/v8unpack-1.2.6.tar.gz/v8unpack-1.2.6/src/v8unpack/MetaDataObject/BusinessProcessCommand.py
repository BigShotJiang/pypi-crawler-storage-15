from ..MetaDataObject.core.IncludeSimple import IncludeSimple


class BusinessProcessCommand(IncludeSimple):
    pass
