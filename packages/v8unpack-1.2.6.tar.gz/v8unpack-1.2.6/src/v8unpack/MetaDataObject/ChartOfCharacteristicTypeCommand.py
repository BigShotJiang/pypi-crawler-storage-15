from ..MetaDataObject.core.IncludeSimple import IncludeSimple


class ChartOfCharacteristicTypeCommand(IncludeSimple):
    pass
