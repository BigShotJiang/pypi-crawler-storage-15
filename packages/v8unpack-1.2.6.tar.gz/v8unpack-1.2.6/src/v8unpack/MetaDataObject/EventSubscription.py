from ..MetaDataObject.core.SimpleWithInfo import SimpleWithInfo


class EventSubscription(SimpleWithInfo):
    pass
