from ..MetaDataObject.core.IncludeSimple import IncludeSimple


class FilterCriterionCommand(IncludeSimple):
    pass
