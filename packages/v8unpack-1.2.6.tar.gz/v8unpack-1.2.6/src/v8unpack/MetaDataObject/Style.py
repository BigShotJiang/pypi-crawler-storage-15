from ..MetaDataObject.core.SimpleWithInfo import SimpleWithInfo


class Style(SimpleWithInfo):
    pass
