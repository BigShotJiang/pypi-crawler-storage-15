from ..MetaDataObject.core.IncludeSimple import IncludeSimple


class ExternalDataSourceTableCommand(IncludeSimple):
    pass
