from v8unpack.MetaDataObject.Form import Form0


class BusinessProcessForm(Form0):
    pass
