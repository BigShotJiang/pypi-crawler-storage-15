from ..MetaDataObject.core.Simple import SimpleNameFolder


class Bot(SimpleNameFolder):
    ext_code = {
        'obj': 1,
    }
