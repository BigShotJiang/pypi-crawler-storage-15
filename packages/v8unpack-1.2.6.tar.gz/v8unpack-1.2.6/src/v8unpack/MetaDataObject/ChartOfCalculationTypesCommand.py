from ..MetaDataObject.core.IncludeSimple import IncludeSimple


class ChartOfCalculationTypesCommand(IncludeSimple):
    pass
