from ..MetaDataObject.core.Simple import Simple


class Language(Simple):
    pass
