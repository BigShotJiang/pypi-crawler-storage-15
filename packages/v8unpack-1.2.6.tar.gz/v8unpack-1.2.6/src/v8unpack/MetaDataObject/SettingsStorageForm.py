from v8unpack.MetaDataObject.Form import Form1


class SettingsStorageForm(Form1):
    pass