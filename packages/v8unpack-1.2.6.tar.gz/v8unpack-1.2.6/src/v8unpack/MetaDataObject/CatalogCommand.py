from ..MetaDataObject.core.IncludeSimple import IncludeSimple


class CatalogCommand(IncludeSimple):
    pass
