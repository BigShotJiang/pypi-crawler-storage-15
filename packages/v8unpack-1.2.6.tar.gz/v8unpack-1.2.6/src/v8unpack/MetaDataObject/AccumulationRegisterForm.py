from v8unpack.MetaDataObject.Form import Form1


class AccumulationRegisterForm(Form1):
    pass
