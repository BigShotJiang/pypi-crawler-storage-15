from ..MetaDataObject.core.IncludeSimple import IncludeSimple


class DocumentCommand(IncludeSimple):
    pass
