from ..MetaDataObject.core.SimpleWithInfo import SimpleWithInfo


class Role(SimpleWithInfo):
    pass
