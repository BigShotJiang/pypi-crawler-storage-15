from ..MetaDataObject import MetaDataObject
from .CommonTemplate4 import CommonTemplate4


class CommonTemplate(MetaDataObject):
    versions = {
        '4': CommonTemplate4
    }
