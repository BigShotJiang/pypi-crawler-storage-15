from v8unpack.MetaDataObject.Form import Form1


class CatalogForm(Form1):
    pass
