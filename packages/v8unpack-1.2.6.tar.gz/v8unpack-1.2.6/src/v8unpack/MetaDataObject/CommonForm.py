from v8unpack.MetaDataObject.Form import Form1
from .Form.Form9 import Form9


class CommonForm(Form1):

    pass
