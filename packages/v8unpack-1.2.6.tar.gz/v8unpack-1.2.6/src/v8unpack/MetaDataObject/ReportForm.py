from v8unpack.MetaDataObject.Form import Form


class ReportForm(Form):
    pass
