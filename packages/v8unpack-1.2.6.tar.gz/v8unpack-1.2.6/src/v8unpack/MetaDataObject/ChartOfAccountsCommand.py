from ..MetaDataObject.core.IncludeSimple import IncludeSimple


class ChartOfAccountsCommand(IncludeSimple):
    pass
