from v8unpack.MetaDataObject.Form import Form0


class ChartOfCharacteristicTypeForm(Form0):
    # @classmethod
    # def get_form_root(cls, header_data):
    #     obj_version = header_data[0][1][0]
    #     if obj_version == '9':
    #         return header_data
    #     else:
    #         return header_data[0]

    pass
