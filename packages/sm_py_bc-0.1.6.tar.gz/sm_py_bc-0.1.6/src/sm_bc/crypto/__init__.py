"""Cryptographic implementations"""
