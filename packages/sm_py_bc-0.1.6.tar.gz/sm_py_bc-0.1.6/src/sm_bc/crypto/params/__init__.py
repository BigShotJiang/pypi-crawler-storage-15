"""Cryptographic parameters"""
