"""Elliptic curve mathematics"""
