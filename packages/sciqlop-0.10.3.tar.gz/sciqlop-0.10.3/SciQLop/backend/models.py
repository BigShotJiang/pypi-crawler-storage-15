from SciQLopPlots import ProductsModel, ProductsModelNode, ProductsModelNodeType

products = ProductsModel.instance()
