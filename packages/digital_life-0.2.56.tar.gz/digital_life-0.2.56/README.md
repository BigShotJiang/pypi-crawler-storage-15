# 考虑是否要安装卡夫卡

scp dist/* zhaoxuefeng@192.168.1.165:/Users/zhaoxuefeng/pypi-simple-server/packages
scp dist/*  root@39.96.146.47:/root/workspace

Aihuashen2025


# doubao-1-5-pro-32k-250115
# doubao-seed-1-6-lite-251015

# 每一个都要欧description, response_description

