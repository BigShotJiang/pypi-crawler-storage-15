"""The legacy (class-based) implementation of autodoc."""
