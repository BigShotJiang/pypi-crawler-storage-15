.. _event-api:

Event Manager API
-----------------

.. module:: sphinx.events

.. autoclass:: EventManager
   :members:
