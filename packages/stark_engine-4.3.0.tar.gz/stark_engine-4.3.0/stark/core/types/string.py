from .object import Object


class String(Object):
    value: str