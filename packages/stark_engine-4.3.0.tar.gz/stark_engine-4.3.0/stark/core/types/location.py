from .object import Object


class Location(Object):
    value: str
