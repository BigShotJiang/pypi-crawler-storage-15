from .object import Object
from .slots import SlotsParser
from .string import String
from .word import Word
# from .Number import Number
# from .TimeInterval import TimeInterval
# from .Time import Time
