"""
Agent onboarding command
"""

import click
import sys
import requests
from ..config import SpritzConfig
from ..utils import make_authenticated_request, load_agents_from_url


import json

@click.command('agent-onboarding')
@click.option('--profile', default='default', help='Profile to use (default, dev, prod)')
@click.option('--url', required=True, help='URL to fetch agent configuration JSON')
@click.option('--dry-run', is_flag=True, help='Show what would be done without executing')
def agent_onboarding(profile, url, dry_run):
    """Onboard agents from configuration URL - Uses API URL"""
    config = SpritzConfig()
    
    try:
        profile_config = config.get_profile(profile)
    except click.ClickException as e:
        click.echo(click.style(f"❌ {str(e)}", fg='red', bold=True), err=True)
        sys.exit(1)
    
    spritz_url = profile_config['spritz_url']
    api_url = profile_config['api_url']  # Get API URL from config
    
    # Header with profile info
    click.echo(click.style("\n╔═══════════════════════════════════════════════════════════╗", fg='cyan', bold=True))
    click.echo(click.style("║           🚀 SPRITZ AGENT ONBOARDING                      ║", fg='cyan', bold=True))
    click.echo(click.style("╚═══════════════════════════════════════════════════════════╝", fg='cyan', bold=True))
    
    click.echo(click.style(f"\n📋 Profile: ", fg='cyan', bold=True) + click.style(profile, fg='magenta', bold=True))
    click.echo(click.style(f"🌐 Spritz Web: ", fg='cyan') + click.style(spritz_url, fg='blue'))
    click.echo(click.style(f"🔌 Spritz API: ", fg='cyan') + click.style(api_url, fg='blue'))
    
    if dry_run:
        click.echo(click.style("\n⚠️  DRY RUN MODE", fg='yellow', bold=True) + click.style(" - No changes will be made", fg='yellow'))
    
    try:
        # Fetch agents from URL
        click.echo(click.style("\n📥 Loading agent configuration...", fg='cyan', bold=True))
        click.echo(click.style(f"   Source: {url}", fg='blue'))

        try:
            agents_data = load_agents_from_url(url)
        except click.ClickException as e:
            error_str = str(e)

            # Check for connection errors
            if 'Connection refused' in error_str or 'Failed to establish a new connection' in error_str:
                click.echo(click.style("\n❌ Connection Error!", fg='red', bold=True))
                click.echo(click.style("   Your agent URL is not accessible.", fg='red'))
                click.echo(click.style(f"\n   Please verify:", fg='yellow'))
                click.echo(click.style(f"   • The server is running at: {url}", fg='yellow'))
                click.echo(click.style(f"   • The URL is correct and reachable", fg='yellow'))
                click.echo(click.style(f"   • No firewall is blocking the connection", fg='yellow'))
                sys.exit(1)

            # Check for timeout errors
            elif 'timeout' in error_str.lower() or 'timed out' in error_str.lower():
                click.echo(click.style("\n❌ Request Timeout!", fg='red', bold=True))
                click.echo(click.style("   The server took too long to respond.", fg='red'))
                click.echo(click.style(f"\n   Please verify:", fg='yellow'))
                click.echo(click.style(f"   • The server is responding: {url}", fg='yellow'))
                click.echo(click.style(f"   • The network connection is stable", fg='yellow'))
                sys.exit(1)

            # Check for DNS/Host errors
            elif 'Name or service not known' in error_str or 'nodename nor servname provided' in error_str:
                click.echo(click.style("\n❌ Invalid URL!", fg='red', bold=True))
                click.echo(click.style("   Unable to resolve the hostname.", fg='red'))
                click.echo(click.style(f"\n   Please verify:", fg='yellow'))
                click.echo(click.style(f"   • The URL is correct: {url}", fg='yellow'))
                click.echo(click.style(f"   • The domain exists and is reachable", fg='yellow'))
                sys.exit(1)

            # Check for 404 errors
            elif '404' in error_str:
                click.echo(click.style("\n❌ Not Found!", fg='red', bold=True))
                click.echo(click.style("   The endpoint was not found.", fg='red'))
                click.echo(click.style(f"\n   Please verify:", fg='yellow'))
                click.echo(click.style(f"   • The URL path is correct: {url}", fg='yellow'))
                click.echo(click.style(f"   • The endpoint exists on the server", fg='yellow'))
                sys.exit(1)

            # Generic error
            else:
                click.echo(click.style("\n❌ Error loading agent configuration!", fg='red', bold=True))
                click.echo(click.style(f"   {error_str}", fg='red'))
                sys.exit(1)

        # Handle single agent or array of agents
        if isinstance(agents_data, dict):
            agents_data = [agents_data]
        elif not isinstance(agents_data, list):
            raise click.ClickException("URL must return an object or array of objects")
        
        click.echo(click.style(f"✅ Found {len(agents_data)} agent(s) to onboard", fg='green', bold=True))
        
        # Preview agents
        click.echo(click.style("\n📦 Agent Configurations:", fg='cyan', bold=True))
        for idx, agent in enumerate(agents_data, 1):
            agent_name = agent.get('name', agent.get('agentName', f'Agent {idx}'))
            agent_type = agent.get('type', agent.get('agentType', 'unknown'))
            click.echo(click.style(f"  [{idx}] ", fg='cyan') + 
                      click.style(agent_name, fg='magenta', bold=True))
        
        if dry_run:
            click.echo(click.style("\n🔍 [DRY RUN]", fg='yellow', bold=True) + 
                      click.style(" Would create the above agents", fg='yellow'))
            click.echo(click.style(f"   Endpoint: POST {api_url}/v1/agent/create", fg='blue'))
            return
        
        # Create agents - Uses API URL
        click.echo(click.style("\n⚙️  Creating agents...", fg='cyan', bold=True))
        create_url = f"{api_url}/v1/agent/create"
        
        success_count = 0
        failed_agents = []
        
        for idx, agent in enumerate(agents_data, 1):
            agent_name = agent.get('name', agent.get('agentName', f'Agent {idx}'))
            try:
                response = make_authenticated_request(
                    'POST',
                    create_url,
                    profile,
                    profile_config,
                    spritz_url,  # Pass Web URL for re-authentication if needed
                    json=agent,
                    headers={'Content-Type': 'application/json'},
                    timeout=30
                )
                
                if response.status_code == 200 or response.status_code == 201:
                    result = response.json()

                    # Extract ID and Name from nested data object if present
                    if 'data' in result:
                        agent_data = result['data']
                        agent_id = agent_data.get('_id', agent_data.get('id', 'N/A'))
                        created_name = agent_data.get('name', agent_name)
                    else:
                        agent_id = result.get('_id', result.get('id', result.get('agentId', 'N/A')))
                        created_name = result.get('name', agent_name)

                    click.echo(click.style(f"  ✅ [{idx}/{len(agents_data)}] ", fg='green', bold=True) + 
                              click.style(created_name, fg='magenta', bold=True) +
                              click.style(" onboarded successfully", fg='green'))
                    click.echo(click.style(f"     🆔 Agent ID: ", fg='cyan') + 
                              click.style(agent_id, fg='yellow', bold=True))
                    success_count += 1
                else:
                    # Try to parse error response
                    error_msg = "Unknown error"
                    try:
                        error_data = response.json()

                        # Get the actual error message from various possible fields
                        raw_error = error_data.get('message',
                                    error_data.get('error',
                                    error_data.get('msg', response.text)))

                        # Check for duplicate key error
                        if 'E11000 duplicate key error' in str(raw_error) or 'dup key' in str(raw_error):
                            if 'name_1' in str(raw_error):
                                error_msg = "⚠️  Oops! It seems this agent name is already in use. Please check in Spritz OPS and try again with a new name."
                            else:
                                error_msg = f"Duplicate key error: {raw_error}"
                        else:
                            # Show the actual error message
                            error_msg = raw_error

                    except json.JSONDecodeError:
                        # If response is not JSON, use status code and text
                        error_msg = f"HTTP {response.status_code}: {response.text[:200]}"
                    except Exception as parse_error:
                        error_msg = f"HTTP {response.status_code}: Could not parse error response"

                    click.echo(click.style(f"  ❌ [{idx}/{len(agents_data)}] ", fg='red', bold=True) + 
                              click.style(agent_name, fg='magenta', bold=True) + 
                              click.style(" failed", fg='red'), err=True)
                    click.echo(click.style(f"     {error_msg}", fg='red'), err=True)

                    failed_agents.append({'name': agent_name, 'error': error_msg})
                    
            except requests.exceptions.Timeout:
                error_msg = "Request timeout"
                click.echo(click.style(f"  ❌ [{idx}/{len(agents_data)}] ", fg='red', bold=True) + 
                          click.style(agent_name, fg='magenta', bold=True) + 
                          click.style(f" failed: {error_msg}", fg='red'), err=True)
                failed_agents.append({'name': agent_name, 'error': error_msg})
            except requests.exceptions.RequestException as e:
                error_msg = str(e)
                click.echo(click.style(f"  ❌ [{idx}/{len(agents_data)}] ", fg='red', bold=True) + 
                          click.style(agent_name, fg='magenta', bold=True) + 
                          click.style(f" failed: {error_msg}", fg='red'), err=True)
                failed_agents.append({'name': agent_name, 'error': error_msg})

        # Summary
        click.echo(click.style("\n╔═══════════════════════════════════════════════════════════╗", fg='cyan', bold=True))
        click.echo(click.style("║                    📊 SUMMARY                             ║", fg='cyan', bold=True))
        click.echo(click.style("╚═══════════════════════════════════════════════════════════╝", fg='cyan', bold=True))
        
        if failed_agents:
            click.echo(click.style(f"\n✅ Success: ", fg='green', bold=True) + 
                      click.style(f"{success_count}/{len(agents_data)}", fg='white', bold=True))
            click.echo(click.style(f"❌ Failed:  ", fg='red', bold=True) + 
                      click.style(f"{len(failed_agents)}/{len(agents_data)}", fg='white', bold=True))
            click.echo(click.style("\n⚠️  Failed Agents:", fg='red', bold=True))
            for item in failed_agents:
                click.echo(click.style(f"  • ", fg='red') + 
                          click.style(item['name'], fg='magenta', bold=True))
                click.echo(click.style(f"    {item['error']}", fg='red'))
            sys.exit(1)
        else:
            click.echo(click.style(f"\n✅ Success: ", fg='green', bold=True) + 
                      click.style(f"{success_count}/{len(agents_data)}", fg='white', bold=True))
            click.echo(click.style("\n🎉 All agents onboarded successfully!", fg='green', bold=True))
        
    except click.ClickException as e:
        click.echo(click.style(f"\n❌ Error: {str(e)}", fg='red', bold=True), err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(click.style(f"\n❌ Unexpected error: {str(e)}", fg='red', bold=True), err=True)
        sys.exit(1)
