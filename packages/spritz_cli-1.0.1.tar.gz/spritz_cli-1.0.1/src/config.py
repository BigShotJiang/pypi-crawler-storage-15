"""
Configuration management for Spritz CLI
"""

import click
import json
import os
from pathlib import Path
from configparser import ConfigParser

from .constants import CONFIG_DIR, CONFIG_FILE, CREDENTIALS_FILE, USER_FILE


class SpritzConfig:
    """Handle Spritz configuration"""
    
    def __init__(self):
        self.config_dir = CONFIG_DIR
        self.config_file = CONFIG_FILE
        self.credentials_file = CREDENTIALS_FILE
        self.user_file = USER_FILE
        self._ensure_config_dir()
    
    def _ensure_config_dir(self):
        """Create config directory if it doesn't exist"""
        self.config_dir.mkdir(parents=True, exist_ok=True)
    
    def set_profile(self, profile, spritz_url, api_url):
        """Set configuration for a profile"""
        config = ConfigParser()
        if self.config_file.exists():
            config.read(self.config_file)
        
        if not config.has_section(f'profile {profile}'):
            config.add_section(f'profile {profile}')
        
        config.set(f'profile {profile}', 'spritz_url', spritz_url)
        config.set(f'profile {profile}', 'api_url', api_url)
        
        with open(self.config_file, 'w') as f:
            config.write(f)
        
        click.echo(click.style("\n✅ Profile '", fg='green', bold=True) + 
                  click.style(profile, fg='magenta', bold=True) + 
                  click.style("' configured successfully", fg='green', bold=True))
        click.echo(click.style("   🌐 Spritz Web: ", fg='cyan') + click.style(spritz_url, fg='blue'))
        click.echo(click.style("   🔌 Spritz API: ", fg='cyan') + click.style(api_url, fg='blue'))
    
    def save_auth_data(self, profile, token, user_data):
        """Save authentication data for a profile"""
        # Save token in credentials file
        credentials = ConfigParser()
        if self.credentials_file.exists():
            credentials.read(self.credentials_file)
        
        if not credentials.has_section(profile):
            credentials.add_section(profile)
        
        credentials.set(profile, 'token', token)
        
        with open(self.credentials_file, 'w') as f:
            credentials.write(f)
        
        os.chmod(self.credentials_file, 0o600)
        
        # Save user data in user.json
        user_store = {}
        if self.user_file.exists():
            with open(self.user_file, 'r') as f:
                user_store = json.load(f)
        
        user_store[profile] = user_data
        
        with open(self.user_file, 'w') as f:
            json.dump(user_store, f, indent=2)
        
        os.chmod(self.user_file, 0o600)
    
    def get_profile(self, profile):
        """Get configuration for a profile"""
        config = ConfigParser()
        credentials = ConfigParser()
        
        if not self.config_file.exists():
            raise click.ClickException(
                f"Profile '{profile}' not found. Run 'spx configure --profile {profile}' first."
            )
        
        config.read(self.config_file)
        
        section = f'profile {profile}'
        if not config.has_section(section):
            raise click.ClickException(
                f"Profile '{profile}' not found. Run 'spx configure --profile {profile}' first."
            )
        
        result = {
            'spritz_url': config.get(section, 'spritz_url'),
            'api_url': config.get(section, 'api_url'),
            'token': None,
            'user': None
        }
        
        # Get token if exists
        if self.credentials_file.exists():
            credentials.read(self.credentials_file)
            if credentials.has_section(profile):
                result['token'] = credentials.get(profile, 'token', fallback=None)
        
        # Get user data if exists
        if self.user_file.exists():
            with open(self.user_file, 'r') as f:
                user_store = json.load(f)
                result['user'] = user_store.get(profile)
        
        return result
    
    def list_profiles(self):
        """List all configured profiles"""
        if not self.config_file.exists():
            return []
        
        config = ConfigParser()
        config.read(self.config_file)
        
        profiles = []
        for section in config.sections():
            if section.startswith('profile '):
                profiles.append(section.replace('profile ', ''))
        
        return profiles
