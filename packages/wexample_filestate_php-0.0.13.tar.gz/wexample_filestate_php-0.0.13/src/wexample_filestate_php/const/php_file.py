from __future__ import annotations

PHP_FILE_EXTENSION: str = "php"
