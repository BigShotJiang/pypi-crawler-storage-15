"""Authentication utilities for signature-based auth"""
import hashlib
import time
from typing import Optional

from ..logging import LoggerFactory


class AuthUtil:
    """Authentication utility for signature-based authentication"""

    def __init__(self, logger_factory: LoggerFactory, seconds_allowed: int = 30):
        """
        Initialize auth utility

        Args:
            logger_factory: Logger factory
            seconds_allowed: Seconds allowed for timestamp validation
        """
        self.logger = logger_factory.get_logger("AuthUtil")
        self.seconds_allowed = seconds_allowed

    def get_signature(self, api_key: str, shared_secret: str, current_timestamp: str) -> str:
        """
        Generate signature

        Args:
            api_key: API key
            shared_secret: Shared secret
            current_timestamp: Current timestamp as string

        Returns:
            Signature string
        """
        key = api_key + shared_secret + current_timestamp
        return hashlib.sha512(key.encode()).hexdigest()

    def get_auth_header(
        self, api_key: str, shared_secret: str, current_timestamp: str
    ) -> str:
        """
        Generate auth header

        Args:
            api_key: API key
            shared_secret: Shared secret
            current_timestamp: Current timestamp as string

        Returns:
            Auth header string
        """
        signature = self.get_signature(api_key, shared_secret, current_timestamp)
        return f"SIGN apikey={api_key},signature={signature},timestamp={current_timestamp}"

    def validate_auth_header(
        self, api_key: str, shared_secret: str, auth_header: str
    ) -> bool:
        """
        Validate auth header

        Args:
            api_key: Expected API key
            shared_secret: Shared secret
            auth_header: Auth header to validate

        Returns:
            True if valid, False otherwise
        """
        try:
            # Parse header
            parts = auth_header.split("apikey=")
            if len(parts) < 2:
                return False

            api_key_of_header = parts[1].split(",")[0]
            timestamp_part = parts[1].split("timestamp=")
            if len(timestamp_part) < 2:
                return False

            timestamp_of_header = timestamp_part[1]
            signature_part = parts[1].split("signature=")
            if len(signature_part) < 2:
                return False

            signature_of_header = signature_part[1].split(",")[0]

            # Validate signature
            expected_signature = self.get_signature(
                api_key, shared_secret, timestamp_of_header
            )

            # Validate timestamp
            current_timestamp = int(time.time())
            time_difference = abs(int(timestamp_of_header) - current_timestamp)

            return (
                expected_signature == signature_of_header
                and api_key_of_header == api_key
                and time_difference < self.seconds_allowed
            )
        except Exception as e:
            self.logger.error("Error validating auth header", {"error": str(e)})
            return False

