"""Redis client wrapper with logging"""
import json
from typing import Any, Optional

import redis
from redis import Redis

from ..logging import LoggerFactory


class RedisClient:
    """Redis client wrapper with logging"""

    def __init__(self, redis_client: Redis, logger_factory: LoggerFactory):
        """
        Initialize Redis client

        Args:
            redis_client: Redis client instance
            logger_factory: Logger factory
        """
        self.client = redis_client
        self.logger = logger_factory.get_logger("RedisClient")

        # Set up event handlers
        # Note: redis-py doesn't have the same event system as ioredis
        # but we can log connection events manually if needed

    def get(self, key: str) -> Optional[Any]:
        """
        Get a value from Redis

        Args:
            key: Redis key

        Returns:
            Deserialized value or None
        """
        value = self.client.get(key)
        if value is None:
            return None
        try:
            return json.loads(value)
        except (json.JSONDecodeError, TypeError):
            return value.decode() if isinstance(value, bytes) else value

    def set(
        self, key: str, value: Any, ttl: Optional[int] = None
    ) -> None:
        """
        Set a value in Redis

        Args:
            key: Redis key
            value: Value to set (will be JSON serialized if not string/number)
            ttl: Time to live in seconds (optional)
        """
        if isinstance(value, (str, int, float)):
            serialized = str(value)
        else:
            serialized = json.dumps(value)

        if ttl:
            self.client.setex(key, ttl, serialized)
        else:
            self.client.set(key, serialized)

    def delete(self, pattern: str) -> int:
        """
        Delete keys matching pattern

        Args:
            pattern: Key pattern (supports wildcards)

        Returns:
            Number of keys deleted
        """
        keys = self.client.keys(pattern)
        if keys:
            return self.client.delete(*keys)
        return 0


def get_redis_client(
    logger_factory: LoggerFactory,
    host: str,
    port: int = 6379,
    **redis_options: Any,
) -> RedisClient:
    """
    Get a Redis client instance

    Args:
        logger_factory: Logger factory
        host: Redis host
        port: Redis port
        **redis_options: Additional Redis connection options

    Returns:
        RedisClient instance
    """
    redis_client = redis.Redis(host=host, port=port, **redis_options)
    return RedisClient(redis_client, logger_factory)

