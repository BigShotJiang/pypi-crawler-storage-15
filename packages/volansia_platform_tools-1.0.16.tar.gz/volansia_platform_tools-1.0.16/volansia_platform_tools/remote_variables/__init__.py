"""Remote variables client"""
from .client import RemoteVariable, RemoteVariablesClient, get_remote_variables_client

__all__ = ["RemoteVariable", "RemoteVariablesClient", "get_remote_variables_client"]
