"""
Copyright (c) Omnissa, LLC. All rights reserved.
This product is protected by copyright and intellectual property laws in the
United States and other countries as well as by international treaties.
"""

from .main import pair_existing, pair_existing_or_new, reset, reset_all
