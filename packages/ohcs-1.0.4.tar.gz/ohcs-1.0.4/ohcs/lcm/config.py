"""
Copyright (c) Omnissa, LLC. All rights reserved.
This product is protected by copyright and intellectual property laws in the
United States and other countries as well as by international treaties.
"""

import json
import os
import random
import string
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import yaml
from loguru import logger

from ohcs.rte.mqtt_config import MQTTConfig, SSLConfig


@dataclass
class LogConfig:
    """Logging configuration"""

    file: Optional[str] = None
    stdout: bool = True
    level: str = "INFO"
    loggers: dict = field(default_factory=dict)


@dataclass
class HCSConfig:
    orgId: str
    providerId: str
    edgeId: str


@dataclass
class PluginConfig:
    path: str
    name: str


@dataclass
class Config:
    mqtt: MQTTConfig
    hcs: HCSConfig
    plugin: PluginConfig
    clientId: Optional[str] = None
    log: LogConfig = None


def _from_dict(cls, data: dict, **overrides):
    filtered_data = {k: v for k, v in data.items() if k in data}
    return cls(**{**filtered_data, **overrides})


def load_config(file_path: Optional[str] = None, log: bool = True) -> Config:
    if file_path is None:
        file_path = "config.yml"

    config_path = Path(file_path)

    if not config_path.exists():
        raise FileNotFoundError(f"Configuration file not found: {config_path.absolute()}")

    if log:
        logger.info(f"Config file: {config_path.absolute()}")

    with open(config_path, "r", encoding="utf-8") as f:
        config_data = yaml.safe_load(f)

    ssl_config = _from_dict(SSLConfig, config_data["mqtt"]["ssl"])
    mqtt_config = _from_dict(MQTTConfig, config_data["mqtt"], ssl=ssl_config)
    log_config = _from_dict(LogConfig, config_data["log"])
    hcs_config = _from_dict(HCSConfig, config_data["hcs"])
    plugin_config = _from_dict(PluginConfig, config_data["plugin"])

    return _from_dict(Config, config_data, mqtt=mqtt_config, log=log_config, hcs=hcs_config, plugin=plugin_config)


def save_config(config: Config, file_path: str):
    json_config = json.dumps(config, default=vars)
    config_data = json.loads(json_config)
    with open(file_path, "w") as file:
        yaml.safe_dump(config_data, file)


def create_default_config(file_path: str):
    template_config_path = os.path.join(os.path.dirname(__file__), "default_config.yml")
    config = load_config(template_config_path, log=False)
    config.clientId = random.choice(string.ascii_lowercase) + "".join(
        random.choices(string.ascii_lowercase + string.digits, k=3)
    )
    save_config(config, file_path)
    return config
