from polylith_cli.polylith.cli.core import app
app(prog_name='poly')