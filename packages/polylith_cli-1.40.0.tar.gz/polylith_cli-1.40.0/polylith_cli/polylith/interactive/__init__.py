from polylith_cli.polylith.interactive import project
__all__ = ['project']