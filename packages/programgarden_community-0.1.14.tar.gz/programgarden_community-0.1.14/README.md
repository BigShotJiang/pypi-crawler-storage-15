# ProgramGarden Community

프로그램 동산 노코딩 언어(DSL)의 증권 분석에 필요한 외부 전략을 모아둔 커뮤니티입니다. 커뮤니티의 발전은 전략을 기여하는 모든 개발자와 함께합니다.

## 개요

`programgarden-community`는 개발자들이 자신만의 외부 전략을 공유할 수 있는 공간입니다. 공유된 전략은 다른 투자자들이 쉽게 사용할 수 있으며, DSL을 작성하여 비개발자도 쉽게 활용할 수 있습니다.

## 외부 전략 오픈소스에 공유하기

자세한 내용은 [커뮤니티 기여 가이드](https://programgarden.gitbook.io/docs/develop/contribution_guide)에서 확인하세요.
