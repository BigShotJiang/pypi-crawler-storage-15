def red(str):
    return f"\033[31m{str}\033[39m"

def green(str):
    return f"\033[32m{str}\033[39m"

def yellow(str):
    return f"\033[33m{str}\033[39m"

def blue(str):
    return f"\033[34m{str}\033[39m"

def bold(str):
    return f"\033[1m{str}\033[22m"