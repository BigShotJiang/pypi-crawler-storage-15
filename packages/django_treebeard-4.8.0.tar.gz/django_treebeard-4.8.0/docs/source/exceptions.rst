Exceptions
==========

.. module:: treebeard.exceptions

.. autoexception:: InvalidPosition

.. autoexception:: InvalidMoveToDescendant

.. autoexception:: NodeAlreadySaved

.. autoexception:: PathOverflow

.. autoexception:: MissingNodeOrderBy
