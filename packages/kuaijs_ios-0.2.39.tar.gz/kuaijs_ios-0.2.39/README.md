# kuaijs-ios

`快点JS` Python 包的类型桩，仅用于「快点 JS」代码提示与类型检查。

## 安装

```bash
pip install kuaijs-ios
```

## 说明

- 本包仅包含 `.pyi` 类型桩文件，用于编辑器智能提示与类型检查。
- 兼容 Python 3.8 及以上版本。
