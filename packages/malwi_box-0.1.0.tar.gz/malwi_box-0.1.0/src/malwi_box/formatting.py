"""Formatting utilities for audit events."""

import os
from pathlib import Path

MAX_VALUE_LEN = 50
MAX_CMD_LEN = 80


def _decode(value) -> str:
    """Decode bytes to string if needed."""
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    return str(value)


def _truncate(s: str, max_len: int) -> str:
    """Truncate string with ellipsis if too long."""
    if len(s) > max_len:
        return s[: max_len - 3] + "..."
    return s


def _build_command(exe, cmd_args) -> str:
    """Build command string from executable and args."""
    return " ".join([str(exe)] + [str(a) for a in cmd_args])


def format_event(event: str, args: tuple) -> str:
    """Format audit event for human-readable output."""
    if not args:
        return f"{event}: {args}"

    if event == "open":
        path = _decode(args[0])
        mode = args[1] if len(args) > 1 else "r"
        is_write = any(c in str(mode) for c in "wax+")
        if is_write:
            action = "Create" if not Path(path).exists() else "Modify"
            return f"{action} file: {path}"
        return f"Read file: {path}"

    if event == "os.putenv":
        key = _decode(args[0])
        val = _truncate(_decode(args[1]), MAX_VALUE_LEN)
        return f"Set env var: {key}={val}"

    if event == "os.unsetenv":
        return f"Unset env var: {_decode(args[0])}"

    if event == "socket.getaddrinfo":
        host = args[0]
        port = args[1] if len(args) > 1 else ""
        return f"DNS lookup: {host}:{port}" if port else f"DNS lookup: {host}"

    if event == "socket.gethostbyname":
        return f"DNS lookup: {args[0]}"

    if event in ("socket.gethostbyname_ex", "socket.gethostbyaddr"):
        return f"DNS lookup: {args[0]}"

    if event == "socket.connect":
        # args: (socket, address) where address is (host, port)
        if len(args) >= 2 and isinstance(args[1], tuple):
            host = args[1][0]
            port = args[1][1] if len(args[1]) > 1 else None
            if port:
                return f"Connect: {host}:{port}"
            return f"Connect: {host}"
        return f"Connect: {args}"

    if event == "subprocess.Popen":
        cmd_args = args[1] if len(args) > 1 else []
        cmd = _truncate(_build_command(args[0], cmd_args), MAX_CMD_LEN)
        return f"Execute: {cmd}"

    if event == "os.system":
        cmd = _truncate(str(args[0]), MAX_CMD_LEN)
        return f"Shell: {cmd}"

    if event == "os.exec":
        exe = args[0] if args else "?"
        return f"Exec: {exe}"

    if event == "os.spawn":
        exe = args[1] if len(args) > 1 else "?"
        return f"Spawn: {exe}"

    if event == "os.posix_spawn":
        exe = args[0] if args else "?"
        return f"Posix spawn: {exe}"

    if event == "ctypes.dlopen":
        lib = args[0] if args else "?"
        return f"Load library: {lib}"

    return f"{event}: {args}"


def extract_decision_details(event: str, args: tuple) -> dict:
    """Extract details from an audit event for decision recording."""
    details = {"event": event}

    if not args:
        return details

    if event == "open":
        details["path"] = str(args[0])
        details["mode"] = args[1] if len(args) > 1 and args[1] is not None else "r"
        details["is_new_file"] = not Path(args[0]).exists()

    elif event == "os.system":
        details["command"] = str(args[0])

    elif event == "subprocess.Popen":
        cmd_args = args[1] if len(args) > 1 else []
        details["command"] = _build_command(args[0], cmd_args)
        details["executable"] = str(args[0]) if args[0] else ""

    elif event == "os.exec":
        details["executable"] = str(args[0]) if args else ""

    elif event == "os.spawn":
        details["executable"] = str(args[1]) if len(args) > 1 else ""

    elif event == "os.posix_spawn":
        details["executable"] = str(args[0]) if args else ""

    elif event == "ctypes.dlopen":
        details["library"] = str(args[0]) if args else ""

    elif event in ("os.putenv", "os.unsetenv"):
        details["key"] = str(args[0])

    elif event == "socket.getaddrinfo":
        details["domain"] = str(args[0])
        if len(args) > 1 and args[1] is not None:
            details["port"] = args[1]

    elif event in (
        "socket.gethostbyname",
        "socket.gethostbyname_ex",
        "socket.gethostbyaddr",
    ):
        details["domain"] = str(args[0])

    elif event == "socket.connect":
        # args: (socket, address) where address is (host, port)
        if len(args) >= 2 and isinstance(args[1], tuple):
            details["host"] = str(args[1][0])
            if len(args[1]) > 1:
                details["port"] = args[1][1]

    return details


def format_stack_trace(caller_info: list) -> str:
    """Format caller info as a minimal stack trace.

    Top frame gets arrow and code context. Rest are compact.

    Args:
        caller_info: List of (filename, lineno, function, code_context) tuples.

    Returns:
        Formatted stack trace string.
    """
    if not caller_info:
        return "  (no user code in stack)"

    lines = []
    for i, (filename, lineno, func, code) in enumerate(caller_info[:5]):
        # Use basename for cleaner output
        basename = os.path.basename(filename)

        if i == 0:
            # Top frame: arrow + code context
            lines.append(f"  → {basename}:{lineno} in {func}")
            if code:
                lines.append(f"      {code}")
        else:
            # Other frames: minimal
            lines.append(f"    {basename}:{lineno} in {func}")

    return "\n".join(lines)
