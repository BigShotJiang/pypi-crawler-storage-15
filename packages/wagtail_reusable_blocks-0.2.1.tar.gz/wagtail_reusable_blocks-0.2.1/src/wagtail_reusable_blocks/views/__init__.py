"""Views for wagtail-reusable-blocks."""

from .slots import block_slots_view

__all__ = ["block_slots_view"]
