"""Subpackage model classes """

from .xba_model import XbaModel


__all__ = ['XbaModel']
