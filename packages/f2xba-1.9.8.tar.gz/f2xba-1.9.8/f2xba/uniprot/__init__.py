from .uniprot_data import UniprotData

__all__ = ['UniprotData']
