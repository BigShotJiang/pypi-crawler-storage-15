"""
Definition of version string.
"""
__version__ = "1.9.8"
program_name = 'f2xba'
