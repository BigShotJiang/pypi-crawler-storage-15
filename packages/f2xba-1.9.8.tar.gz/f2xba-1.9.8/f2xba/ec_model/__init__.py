"""Subpackage with Ec model classes

Peter Schubert, 16.10.2023 (HHU, CCB)
"""

from .ec_model import EcModel


__all__ = ['EcModel']
