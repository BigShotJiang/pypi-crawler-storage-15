## Installation
Install the package using pip:
```bash
pip install djimporter
```

Update `INSTALLED_APPS` of `settings.py` of the project:
```python
INSTALLED_APPS = [
    ...
    'background_task',
    'djimporter',
]
```
