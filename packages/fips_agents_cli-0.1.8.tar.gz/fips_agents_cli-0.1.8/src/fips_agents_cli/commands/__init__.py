"""CLI commands for fips-agents-cli."""
