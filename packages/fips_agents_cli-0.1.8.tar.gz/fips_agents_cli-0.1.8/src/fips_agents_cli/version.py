"""Version information for fips-agents-cli."""

__version__ = "0.1.8"
