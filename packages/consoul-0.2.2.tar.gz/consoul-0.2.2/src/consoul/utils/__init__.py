"""Utility module.

Common utilities and helper functions used across the application.
"""

__all__ = ["docs_generator"]
