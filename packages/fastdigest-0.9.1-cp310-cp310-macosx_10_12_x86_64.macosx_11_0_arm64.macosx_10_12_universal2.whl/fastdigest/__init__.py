from .fastdigest import *

__doc__ = fastdigest.__doc__
if hasattr(fastdigest, "__all__"):
    __all__ = fastdigest.__all__