from snowflake.cli._plugins.sql.lexer.completer import cli_completer
from snowflake.cli._plugins.sql.lexer.lexer import CliLexer

__all__ = (
    "CliLexer",
    "cli_completer",
)
