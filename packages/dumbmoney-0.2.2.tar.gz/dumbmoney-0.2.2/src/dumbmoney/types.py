from typing import Literal

AdjustType = Literal["none", "forward", "backward"]