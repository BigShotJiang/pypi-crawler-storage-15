"""
Package which defines tabs for managing models, audio and
settings.
"""
