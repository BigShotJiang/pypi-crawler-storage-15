"""Package which defines tabs for training voice models."""
