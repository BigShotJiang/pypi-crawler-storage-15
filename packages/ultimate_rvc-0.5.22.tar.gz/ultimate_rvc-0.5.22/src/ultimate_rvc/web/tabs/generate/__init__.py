"""Package which defines tabs for generating audio."""
