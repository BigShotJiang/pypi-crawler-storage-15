"""
web package for tabs.

This package contains modules which define functions for rendering each
tab in web application of the Ultimate RVC project.

"""
