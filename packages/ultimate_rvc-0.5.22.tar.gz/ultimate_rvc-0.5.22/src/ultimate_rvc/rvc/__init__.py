"""
The rvc package is a collection of tools for voice cloning using the RVC
method.
"""
