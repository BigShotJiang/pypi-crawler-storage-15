"""
Package which defines audio generation commands for the CLI of the
Ultimate RVC project.
"""
