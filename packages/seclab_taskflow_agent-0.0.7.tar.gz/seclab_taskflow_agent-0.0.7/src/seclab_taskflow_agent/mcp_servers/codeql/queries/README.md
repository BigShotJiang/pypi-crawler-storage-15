Queries in support of the CodeQL MCP Server are maintained as query packs.

If you add your own queries, please follow established conventions for normal CodeQL query pack development.
