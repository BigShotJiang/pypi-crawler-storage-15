#!/bin/sh
python release_tools/publish_docker.py ghcr.io/githubsecuritylab/seclab-taskflow-agent latest
