# Changelog

## 0.189.0 (2025-12-02)

Full Changelog: [v0.188.0...v0.189.0](https://github.com/aiinbx/aiinbx-py/compare/v0.188.0...v0.189.0)

### Features

* **api:** api update ([27f06f9](https://github.com/aiinbx/aiinbx-py/commit/27f06f9b80e7cacc942de7d8bd2ceccad15e7ce3))

## 0.188.0 (2025-12-02)

Full Changelog: [v0.187.0...v0.188.0](https://github.com/aiinbx/aiinbx-py/compare/v0.187.0...v0.188.0)

### Features

* **api:** api update ([996e7e2](https://github.com/aiinbx/aiinbx-py/commit/996e7e285fa3e0804e552863171edb9bc7f03451))

## 0.187.0 (2025-12-02)

Full Changelog: [v0.186.0...v0.187.0](https://github.com/aiinbx/aiinbx-py/compare/v0.186.0...v0.187.0)

### Features

* **api:** api update ([ac05446](https://github.com/aiinbx/aiinbx-py/commit/ac054460619096dbddeee9012e836586d80ecbd2))

## 0.186.0 (2025-12-02)

Full Changelog: [v0.185.0...v0.186.0](https://github.com/aiinbx/aiinbx-py/compare/v0.185.0...v0.186.0)

### Features

* **api:** api update ([ac618eb](https://github.com/aiinbx/aiinbx-py/commit/ac618eb1bcbf2fef0a8fa1a6f9a498e63c49576e))

## 0.185.0 (2025-12-02)

Full Changelog: [v0.184.0...v0.185.0](https://github.com/aiinbx/aiinbx-py/compare/v0.184.0...v0.185.0)

### Features

* **api:** api update ([bb68e95](https://github.com/aiinbx/aiinbx-py/commit/bb68e959afbad71b5f69fd2da57081251e800a01))

## 0.184.0 (2025-12-02)

Full Changelog: [v0.183.0...v0.184.0](https://github.com/aiinbx/aiinbx-py/compare/v0.183.0...v0.184.0)

### Features

* **api:** api update ([f88ab54](https://github.com/aiinbx/aiinbx-py/commit/f88ab54edcb48c1d71f23a74ff53a9985610a214))

## 0.183.0 (2025-12-02)

Full Changelog: [v0.182.0...v0.183.0](https://github.com/aiinbx/aiinbx-py/compare/v0.182.0...v0.183.0)

### Features

* **api:** api update ([4f24787](https://github.com/aiinbx/aiinbx-py/commit/4f24787762fb36ebacb97749246d0706ded1c5e1))

## 0.182.0 (2025-12-02)

Full Changelog: [v0.181.0...v0.182.0](https://github.com/aiinbx/aiinbx-py/compare/v0.181.0...v0.182.0)

### Features

* **api:** api update ([cb81668](https://github.com/aiinbx/aiinbx-py/commit/cb81668c48415f3f399caaf5488e2e3010f104ff))

## 0.181.0 (2025-12-02)

Full Changelog: [v0.180.0...v0.181.0](https://github.com/aiinbx/aiinbx-py/compare/v0.180.0...v0.181.0)

### Features

* **api:** api update ([0c210e7](https://github.com/aiinbx/aiinbx-py/commit/0c210e7c3b43832eb83162dbeb8379b8f89af019))

## 0.180.0 (2025-12-02)

Full Changelog: [v0.179.0...v0.180.0](https://github.com/aiinbx/aiinbx-py/compare/v0.179.0...v0.180.0)

### Features

* **api:** api update ([9e7f581](https://github.com/aiinbx/aiinbx-py/commit/9e7f581fd634200d6e6ed103226d40b0ed21fcfa))

## 0.179.0 (2025-12-02)

Full Changelog: [v0.178.0...v0.179.0](https://github.com/aiinbx/aiinbx-py/compare/v0.178.0...v0.179.0)

### Features

* **api:** api update ([775a20c](https://github.com/aiinbx/aiinbx-py/commit/775a20c77b3c2b24b6b8fc4199eb01aba8666978))

## 0.178.0 (2025-12-02)

Full Changelog: [v0.177.0...v0.178.0](https://github.com/aiinbx/aiinbx-py/compare/v0.177.0...v0.178.0)

### Features

* **api:** api update ([d209e68](https://github.com/aiinbx/aiinbx-py/commit/d209e68e77e96c1d6896bdf1de92b99d04c39c8a))

## 0.177.0 (2025-12-02)

Full Changelog: [v0.176.0...v0.177.0](https://github.com/aiinbx/aiinbx-py/compare/v0.176.0...v0.177.0)

### Features

* **api:** api update ([dd11f70](https://github.com/aiinbx/aiinbx-py/commit/dd11f702ae169af4dbf2dd3148fdbf87fc838e0a))

## 0.176.0 (2025-12-01)

Full Changelog: [v0.175.0...v0.176.0](https://github.com/aiinbx/aiinbx-py/compare/v0.175.0...v0.176.0)

### Features

* **api:** api update ([4fbca7c](https://github.com/aiinbx/aiinbx-py/commit/4fbca7c2858411cacddb42f2e3136d0b06fe106c))

## 0.175.0 (2025-12-01)

Full Changelog: [v0.174.0...v0.175.0](https://github.com/aiinbx/aiinbx-py/compare/v0.174.0...v0.175.0)

### Features

* **api:** api update ([5e5d3c7](https://github.com/aiinbx/aiinbx-py/commit/5e5d3c77d1f71027443c2d769f50556da58b1f30))

## 0.174.0 (2025-12-01)

Full Changelog: [v0.173.0...v0.174.0](https://github.com/aiinbx/aiinbx-py/compare/v0.173.0...v0.174.0)

### Features

* **api:** api update ([822c3fe](https://github.com/aiinbx/aiinbx-py/commit/822c3fec6baff43deb0679dd1cdf166a3613283b))

## 0.173.0 (2025-12-01)

Full Changelog: [v0.172.0...v0.173.0](https://github.com/aiinbx/aiinbx-py/compare/v0.172.0...v0.173.0)

### Features

* **api:** api update ([2954771](https://github.com/aiinbx/aiinbx-py/commit/295477183b274d242089d1bb435f9bfe9caa0991))

## 0.172.0 (2025-12-01)

Full Changelog: [v0.171.0...v0.172.0](https://github.com/aiinbx/aiinbx-py/compare/v0.171.0...v0.172.0)

### Features

* **api:** api update ([17adf93](https://github.com/aiinbx/aiinbx-py/commit/17adf934ccf3ff26d4f0a4ed5596ded3638c4e1e))

## 0.171.0 (2025-12-01)

Full Changelog: [v0.170.0...v0.171.0](https://github.com/aiinbx/aiinbx-py/compare/v0.170.0...v0.171.0)

### Features

* **api:** api update ([771d927](https://github.com/aiinbx/aiinbx-py/commit/771d927cc168d9b8b3b722b38a6286de06696083))

## 0.170.0 (2025-11-30)

Full Changelog: [v0.169.0...v0.170.0](https://github.com/aiinbx/aiinbx-py/compare/v0.169.0...v0.170.0)

### Features

* **api:** api update ([a0023fb](https://github.com/aiinbx/aiinbx-py/commit/a0023fb38b0866018ffc687b010067cad3be467d))

## 0.169.0 (2025-11-30)

Full Changelog: [v0.168.0...v0.169.0](https://github.com/aiinbx/aiinbx-py/compare/v0.168.0...v0.169.0)

### Features

* **api:** api update ([4ef431d](https://github.com/aiinbx/aiinbx-py/commit/4ef431dd712703804bdca6289909b5ec74c62b90))

## 0.168.0 (2025-11-30)

Full Changelog: [v0.167.0...v0.168.0](https://github.com/aiinbx/aiinbx-py/compare/v0.167.0...v0.168.0)

### Features

* **api:** api update ([9b15b20](https://github.com/aiinbx/aiinbx-py/commit/9b15b20684ca0d5015d8ce41ad9512f255a5a012))

## 0.167.0 (2025-11-30)

Full Changelog: [v0.166.0...v0.167.0](https://github.com/aiinbx/aiinbx-py/compare/v0.166.0...v0.167.0)

### Features

* **api:** api update ([9272c9f](https://github.com/aiinbx/aiinbx-py/commit/9272c9fc2025f16270513fbe2e478826e82fa696))

## 0.166.0 (2025-11-30)

Full Changelog: [v0.165.0...v0.166.0](https://github.com/aiinbx/aiinbx-py/compare/v0.165.0...v0.166.0)

### Features

* **api:** api update ([de78e1d](https://github.com/aiinbx/aiinbx-py/commit/de78e1d79753cf3d8ea1c8e807e75e369a560cd7))

## 0.165.0 (2025-11-30)

Full Changelog: [v0.164.0...v0.165.0](https://github.com/aiinbx/aiinbx-py/compare/v0.164.0...v0.165.0)

### Features

* **api:** api update ([ce72b92](https://github.com/aiinbx/aiinbx-py/commit/ce72b9275563ee54c26e9ab9dc202552c86b29e4))

## 0.164.0 (2025-11-30)

Full Changelog: [v0.163.0...v0.164.0](https://github.com/aiinbx/aiinbx-py/compare/v0.163.0...v0.164.0)

### Features

* **api:** api update ([593f518](https://github.com/aiinbx/aiinbx-py/commit/593f5183881b2a0c1d95a057f7d3c5ac1481bdc7))

## 0.163.0 (2025-11-30)

Full Changelog: [v0.162.0...v0.163.0](https://github.com/aiinbx/aiinbx-py/compare/v0.162.0...v0.163.0)

### Features

* **api:** api update ([24e7945](https://github.com/aiinbx/aiinbx-py/commit/24e7945ab4eb60db9fd7f7ea9c69bd82cafee4b4))

## 0.162.0 (2025-11-30)

Full Changelog: [v0.161.0...v0.162.0](https://github.com/aiinbx/aiinbx-py/compare/v0.161.0...v0.162.0)

### Features

* **api:** api update ([bdca52b](https://github.com/aiinbx/aiinbx-py/commit/bdca52bcfd2d3472982a38b7332cb638c014c049))

## 0.161.0 (2025-11-30)

Full Changelog: [v0.160.0...v0.161.0](https://github.com/aiinbx/aiinbx-py/compare/v0.160.0...v0.161.0)

### Features

* **api:** api update ([d961f43](https://github.com/aiinbx/aiinbx-py/commit/d961f4379246210f8123f96273b06095b2848283))

## 0.160.0 (2025-11-29)

Full Changelog: [v0.159.0...v0.160.0](https://github.com/aiinbx/aiinbx-py/compare/v0.159.0...v0.160.0)

### Features

* **api:** api update ([eba20d4](https://github.com/aiinbx/aiinbx-py/commit/eba20d47c10440407da0714eef16666432a7c7f2))

## 0.159.0 (2025-11-29)

Full Changelog: [v0.158.0...v0.159.0](https://github.com/aiinbx/aiinbx-py/compare/v0.158.0...v0.159.0)

### Features

* **api:** api update ([b015ac6](https://github.com/aiinbx/aiinbx-py/commit/b015ac60e66c30e0786c171d922d3270fa371d32))

## 0.158.0 (2025-11-29)

Full Changelog: [v0.157.0...v0.158.0](https://github.com/aiinbx/aiinbx-py/compare/v0.157.0...v0.158.0)

### Features

* **api:** api update ([e983b6b](https://github.com/aiinbx/aiinbx-py/commit/e983b6b5cb756ef67fadd3eb99cdb4b542d5ac40))

## 0.157.0 (2025-11-29)

Full Changelog: [v0.156.0...v0.157.0](https://github.com/aiinbx/aiinbx-py/compare/v0.156.0...v0.157.0)

### Features

* **api:** api update ([741c55f](https://github.com/aiinbx/aiinbx-py/commit/741c55fc0422784bc79f28cee0e2439b64cd5fb7))

## 0.156.0 (2025-11-29)

Full Changelog: [v0.155.0...v0.156.0](https://github.com/aiinbx/aiinbx-py/compare/v0.155.0...v0.156.0)

### Features

* **api:** api update ([987f8f7](https://github.com/aiinbx/aiinbx-py/commit/987f8f730b62f388318ed6fd549b648881774f88))

## 0.155.0 (2025-11-29)

Full Changelog: [v0.154.0...v0.155.0](https://github.com/aiinbx/aiinbx-py/compare/v0.154.0...v0.155.0)

### Features

* **api:** api update ([f78e77e](https://github.com/aiinbx/aiinbx-py/commit/f78e77e7ad3e623ee1a6f9fe6c543af2444668c0))

## 0.154.0 (2025-11-29)

Full Changelog: [v0.153.0...v0.154.0](https://github.com/aiinbx/aiinbx-py/compare/v0.153.0...v0.154.0)

### Features

* **api:** api update ([af86094](https://github.com/aiinbx/aiinbx-py/commit/af86094a7f0aa71b821785afd3caa0acd449f117))

## 0.153.0 (2025-11-29)

Full Changelog: [v0.152.0...v0.153.0](https://github.com/aiinbx/aiinbx-py/compare/v0.152.0...v0.153.0)

### Features

* **api:** api update ([4d1a33e](https://github.com/aiinbx/aiinbx-py/commit/4d1a33e45c652e115f5a5777bcfaeff3c0e6d658))

## 0.152.0 (2025-11-29)

Full Changelog: [v0.151.0...v0.152.0](https://github.com/aiinbx/aiinbx-py/compare/v0.151.0...v0.152.0)

### Features

* **api:** api update ([9577916](https://github.com/aiinbx/aiinbx-py/commit/9577916446e5db94dcc06955dd546ea975c49c15))

## 0.151.0 (2025-11-29)

Full Changelog: [v0.150.0...v0.151.0](https://github.com/aiinbx/aiinbx-py/compare/v0.150.0...v0.151.0)

### Features

* **api:** api update ([31663d5](https://github.com/aiinbx/aiinbx-py/commit/31663d51c45bf0c2f0300701533bfa83419ebacc))

## 0.150.0 (2025-11-29)

Full Changelog: [v0.149.0...v0.150.0](https://github.com/aiinbx/aiinbx-py/compare/v0.149.0...v0.150.0)

### Features

* **api:** api update ([d9b96eb](https://github.com/aiinbx/aiinbx-py/commit/d9b96eb6f810b6cba33d9907609ee21a235cdd35))

## 0.149.0 (2025-11-29)

Full Changelog: [v0.148.0...v0.149.0](https://github.com/aiinbx/aiinbx-py/compare/v0.148.0...v0.149.0)

### Features

* **api:** api update ([e1aeba9](https://github.com/aiinbx/aiinbx-py/commit/e1aeba98401119b0c35573ee31ad62152b607014))

## 0.148.0 (2025-11-29)

Full Changelog: [v0.147.0...v0.148.0](https://github.com/aiinbx/aiinbx-py/compare/v0.147.0...v0.148.0)

### Features

* **api:** api update ([691bbe8](https://github.com/aiinbx/aiinbx-py/commit/691bbe8226298e4014743aa3a03527cc83e703ff))

## 0.147.0 (2025-11-28)

Full Changelog: [v0.146.0...v0.147.0](https://github.com/aiinbx/aiinbx-py/compare/v0.146.0...v0.147.0)

### Features

* **api:** api update ([e90335e](https://github.com/aiinbx/aiinbx-py/commit/e90335e3cb5f6c6c689e94928dae43c5f0051f07))

## 0.146.0 (2025-11-28)

Full Changelog: [v0.145.0...v0.146.0](https://github.com/aiinbx/aiinbx-py/compare/v0.145.0...v0.146.0)

### Features

* **api:** api update ([3246438](https://github.com/aiinbx/aiinbx-py/commit/32464383a3768fee80a5ff22e8cf13e27c5091dd))

## 0.145.0 (2025-11-28)

Full Changelog: [v0.144.0...v0.145.0](https://github.com/aiinbx/aiinbx-py/compare/v0.144.0...v0.145.0)

### Features

* **api:** api update ([f284a7c](https://github.com/aiinbx/aiinbx-py/commit/f284a7c00575675dbb16913347ef605bbd683215))

## 0.144.0 (2025-11-28)

Full Changelog: [v0.143.0...v0.144.0](https://github.com/aiinbx/aiinbx-py/compare/v0.143.0...v0.144.0)

### Features

* **api:** api update ([5392797](https://github.com/aiinbx/aiinbx-py/commit/5392797686d44853d7106f1dae0294618860d3b2))

## 0.143.0 (2025-11-28)

Full Changelog: [v0.142.0...v0.143.0](https://github.com/aiinbx/aiinbx-py/compare/v0.142.0...v0.143.0)

### Features

* **api:** api update ([61f5e23](https://github.com/aiinbx/aiinbx-py/commit/61f5e23fb3e452eb60402445053a8b864dde6901))

## 0.142.0 (2025-11-28)

Full Changelog: [v0.141.0...v0.142.0](https://github.com/aiinbx/aiinbx-py/compare/v0.141.0...v0.142.0)

### Features

* **api:** api update ([ea05169](https://github.com/aiinbx/aiinbx-py/commit/ea051697f3c56692e408f7606bea5f31aa74e5d2))

## 0.141.0 (2025-11-28)

Full Changelog: [v0.140.0...v0.141.0](https://github.com/aiinbx/aiinbx-py/compare/v0.140.0...v0.141.0)

### Features

* **api:** api update ([aea101b](https://github.com/aiinbx/aiinbx-py/commit/aea101b4bf0bc48d53a44097fa4c2fe6b9298f5d))

## 0.140.0 (2025-11-28)

Full Changelog: [v0.139.0...v0.140.0](https://github.com/aiinbx/aiinbx-py/compare/v0.139.0...v0.140.0)

### Features

* **api:** api update ([5f14303](https://github.com/aiinbx/aiinbx-py/commit/5f14303298f63b6a8878e919501da29b8d63d7ce))

## 0.139.0 (2025-11-28)

Full Changelog: [v0.138.0...v0.139.0](https://github.com/aiinbx/aiinbx-py/compare/v0.138.0...v0.139.0)

### Features

* **api:** api update ([e56d509](https://github.com/aiinbx/aiinbx-py/commit/e56d509082595e1af5a474c5dc631d0798789257))

## 0.138.0 (2025-11-28)

Full Changelog: [v0.137.0...v0.138.0](https://github.com/aiinbx/aiinbx-py/compare/v0.137.0...v0.138.0)

### Features

* **api:** api update ([09c3046](https://github.com/aiinbx/aiinbx-py/commit/09c304687aff9b0c077e2fc6d4adf82fb372f15c))

## 0.137.0 (2025-11-28)

Full Changelog: [v0.136.1...v0.137.0](https://github.com/aiinbx/aiinbx-py/compare/v0.136.1...v0.137.0)

### Features

* **api:** api update ([9e3f137](https://github.com/aiinbx/aiinbx-py/commit/9e3f1371f8e85a0cc852ecf1f4fab5b90dc4fb86))


### Chores

* **deps:** mypy 1.18.1 has a regression, pin to 1.17 ([58a443e](https://github.com/aiinbx/aiinbx-py/commit/58a443ebe51ac4353efdd467ca54711874274f90))

## 0.136.1 (2025-11-28)

Full Changelog: [v0.136.0...v0.136.1](https://github.com/aiinbx/aiinbx-py/compare/v0.136.0...v0.136.1)

### Bug Fixes

* ensure streams are always closed ([88c6253](https://github.com/aiinbx/aiinbx-py/commit/88c62534172f141a2e010f7f839d7f41c5d76421))

## 0.136.0 (2025-11-28)

Full Changelog: [v0.135.0...v0.136.0](https://github.com/aiinbx/aiinbx-py/compare/v0.135.0...v0.136.0)

### Features

* **api:** api update ([cc6c0e5](https://github.com/aiinbx/aiinbx-py/commit/cc6c0e5bf7fb1948cc25d5b005ad7ace696a3d6a))

## 0.135.0 (2025-11-28)

Full Changelog: [v0.134.0...v0.135.0](https://github.com/aiinbx/aiinbx-py/compare/v0.134.0...v0.135.0)

### Features

* **api:** api update ([c1c9d42](https://github.com/aiinbx/aiinbx-py/commit/c1c9d42e0a6cdc01f07887ad4421cda7b27d5b68))

## 0.134.0 (2025-11-28)

Full Changelog: [v0.133.0...v0.134.0](https://github.com/aiinbx/aiinbx-py/compare/v0.133.0...v0.134.0)

### Features

* **api:** api update ([cdcc0a1](https://github.com/aiinbx/aiinbx-py/commit/cdcc0a1d1fe270f881718204e53ca2bdbc46d2af))

## 0.133.0 (2025-11-27)

Full Changelog: [v0.132.0...v0.133.0](https://github.com/aiinbx/aiinbx-py/compare/v0.132.0...v0.133.0)

### Features

* **api:** api update ([8757ad9](https://github.com/aiinbx/aiinbx-py/commit/8757ad9c38aa02b44eb8f2e621d46284db003d41))

## 0.132.0 (2025-11-27)

Full Changelog: [v0.131.0...v0.132.0](https://github.com/aiinbx/aiinbx-py/compare/v0.131.0...v0.132.0)

### Features

* **api:** api update ([846674f](https://github.com/aiinbx/aiinbx-py/commit/846674f1b868319d45604f64646c4cf33e7167c0))

## 0.131.0 (2025-11-27)

Full Changelog: [v0.130.0...v0.131.0](https://github.com/aiinbx/aiinbx-py/compare/v0.130.0...v0.131.0)

### Features

* **api:** api update ([321051f](https://github.com/aiinbx/aiinbx-py/commit/321051f80554aef2b8b1eafc1e02ea3b816fba65))

## 0.130.0 (2025-11-27)

Full Changelog: [v0.129.0...v0.130.0](https://github.com/aiinbx/aiinbx-py/compare/v0.129.0...v0.130.0)

### Features

* **api:** api update ([43181c8](https://github.com/aiinbx/aiinbx-py/commit/43181c833258ac26b24e10408daa683d8e04b890))

## 0.129.0 (2025-11-27)

Full Changelog: [v0.128.0...v0.129.0](https://github.com/aiinbx/aiinbx-py/compare/v0.128.0...v0.129.0)

### Features

* **api:** api update ([8f6ecda](https://github.com/aiinbx/aiinbx-py/commit/8f6ecda13bf2429a19d2a55e54e69b5bea0900d1))

## 0.128.0 (2025-11-27)

Full Changelog: [v0.127.0...v0.128.0](https://github.com/aiinbx/aiinbx-py/compare/v0.127.0...v0.128.0)

### Features

* **api:** api update ([a20b075](https://github.com/aiinbx/aiinbx-py/commit/a20b07507df2445d16ddfc51444e74b21f8d7de6))

## 0.127.0 (2025-11-27)

Full Changelog: [v0.126.0...v0.127.0](https://github.com/aiinbx/aiinbx-py/compare/v0.126.0...v0.127.0)

### Features

* **api:** api update ([0b84926](https://github.com/aiinbx/aiinbx-py/commit/0b84926b5cf96395625bdc63000f46b9e8a8350e))

## 0.126.0 (2025-11-27)

Full Changelog: [v0.125.0...v0.126.0](https://github.com/aiinbx/aiinbx-py/compare/v0.125.0...v0.126.0)

### Features

* **api:** api update ([81a5def](https://github.com/aiinbx/aiinbx-py/commit/81a5def407f2c6754f03f7bf0ec0a5f63b10beb9))

## 0.125.0 (2025-11-27)

Full Changelog: [v0.124.0...v0.125.0](https://github.com/aiinbx/aiinbx-py/compare/v0.124.0...v0.125.0)

### Features

* **api:** api update ([193fff3](https://github.com/aiinbx/aiinbx-py/commit/193fff355124c4506dc2b183406b20da726eabbd))

## 0.124.0 (2025-11-27)

Full Changelog: [v0.123.0...v0.124.0](https://github.com/aiinbx/aiinbx-py/compare/v0.123.0...v0.124.0)

### Features

* **api:** api update ([e7736f1](https://github.com/aiinbx/aiinbx-py/commit/e7736f160122248339a3d5dd8ff391923bbb5a19))

## 0.123.0 (2025-11-27)

Full Changelog: [v0.122.0...v0.123.0](https://github.com/aiinbx/aiinbx-py/compare/v0.122.0...v0.123.0)

### Features

* **api:** api update ([1fccae6](https://github.com/aiinbx/aiinbx-py/commit/1fccae6162f505a74e0a3e5c02418a8ef95cd236))

## 0.122.0 (2025-11-26)

Full Changelog: [v0.121.0...v0.122.0](https://github.com/aiinbx/aiinbx-py/compare/v0.121.0...v0.122.0)

### Features

* **api:** api update ([30d6f68](https://github.com/aiinbx/aiinbx-py/commit/30d6f68cb3eb6b28ee4c3e5e0f0e34e6835c2259))

## 0.121.0 (2025-11-26)

Full Changelog: [v0.120.0...v0.121.0](https://github.com/aiinbx/aiinbx-py/compare/v0.120.0...v0.121.0)

### Features

* **api:** api update ([e004638](https://github.com/aiinbx/aiinbx-py/commit/e004638a8e6a91fe7c65bcd2259533902cceb515))

## 0.120.0 (2025-11-26)

Full Changelog: [v0.119.0...v0.120.0](https://github.com/aiinbx/aiinbx-py/compare/v0.119.0...v0.120.0)

### Features

* **api:** api update ([3d1c487](https://github.com/aiinbx/aiinbx-py/commit/3d1c4875fb7ec53eedf38c4d1815a4f49567a641))

## 0.119.0 (2025-11-26)

Full Changelog: [v0.118.0...v0.119.0](https://github.com/aiinbx/aiinbx-py/compare/v0.118.0...v0.119.0)

### Features

* **api:** api update ([5be4d48](https://github.com/aiinbx/aiinbx-py/commit/5be4d48d60bddd84137cbbad403e679eef6eade1))

## 0.118.0 (2025-11-26)

Full Changelog: [v0.117.0...v0.118.0](https://github.com/aiinbx/aiinbx-py/compare/v0.117.0...v0.118.0)

### Features

* **api:** api update ([6d769dd](https://github.com/aiinbx/aiinbx-py/commit/6d769dd6056b216be9a4e405f1c38fbb7fc3bd98))

## 0.117.0 (2025-11-26)

Full Changelog: [v0.116.0...v0.117.0](https://github.com/aiinbx/aiinbx-py/compare/v0.116.0...v0.117.0)

### Features

* **api:** api update ([4f55a97](https://github.com/aiinbx/aiinbx-py/commit/4f55a97efc6a614715039c6adbd64e6a5ef42aa8))

## 0.116.0 (2025-11-26)

Full Changelog: [v0.115.0...v0.116.0](https://github.com/aiinbx/aiinbx-py/compare/v0.115.0...v0.116.0)

### Features

* **api:** api update ([d810f79](https://github.com/aiinbx/aiinbx-py/commit/d810f79a9c7039c1976c9ef80e160626970f3078))

## 0.115.0 (2025-11-26)

Full Changelog: [v0.114.0...v0.115.0](https://github.com/aiinbx/aiinbx-py/compare/v0.114.0...v0.115.0)

### Features

* **api:** api update ([b0b5411](https://github.com/aiinbx/aiinbx-py/commit/b0b541149a6e29cd98395f9654fe5a57593ab09a))

## 0.114.0 (2025-11-26)

Full Changelog: [v0.113.0...v0.114.0](https://github.com/aiinbx/aiinbx-py/compare/v0.113.0...v0.114.0)

### Features

* **api:** api update ([bcc7e3c](https://github.com/aiinbx/aiinbx-py/commit/bcc7e3ca3d442fad1c0354983356ceb2ef83d05a))

## 0.113.0 (2025-11-26)

Full Changelog: [v0.112.0...v0.113.0](https://github.com/aiinbx/aiinbx-py/compare/v0.112.0...v0.113.0)

### Features

* **api:** api update ([f1cfc4c](https://github.com/aiinbx/aiinbx-py/commit/f1cfc4c131a165581b58bccf346353d0ee7aa73f))

## 0.112.0 (2025-11-26)

Full Changelog: [v0.111.0...v0.112.0](https://github.com/aiinbx/aiinbx-py/compare/v0.111.0...v0.112.0)

### Features

* **api:** api update ([0217e4f](https://github.com/aiinbx/aiinbx-py/commit/0217e4f6a37ff0f72b24f647e46e2126ca079e6b))

## 0.111.0 (2025-11-26)

Full Changelog: [v0.110.0...v0.111.0](https://github.com/aiinbx/aiinbx-py/compare/v0.110.0...v0.111.0)

### Features

* **api:** api update ([47d695c](https://github.com/aiinbx/aiinbx-py/commit/47d695c2780c119f0a3e754461d09edc9218c488))

## 0.110.0 (2025-11-25)

Full Changelog: [v0.109.0...v0.110.0](https://github.com/aiinbx/aiinbx-py/compare/v0.109.0...v0.110.0)

### Features

* **api:** api update ([904d6fc](https://github.com/aiinbx/aiinbx-py/commit/904d6fca59a6de80f9db2832ac1e92e326fc32c9))

## 0.109.0 (2025-11-25)

Full Changelog: [v0.108.0...v0.109.0](https://github.com/aiinbx/aiinbx-py/compare/v0.108.0...v0.109.0)

### Features

* **api:** api update ([9dfa658](https://github.com/aiinbx/aiinbx-py/commit/9dfa658c022e27a0862f3bce8d4e3b524d2497d9))

## 0.108.0 (2025-11-25)

Full Changelog: [v0.107.0...v0.108.0](https://github.com/aiinbx/aiinbx-py/compare/v0.107.0...v0.108.0)

### Features

* **api:** api update ([d3fd7c9](https://github.com/aiinbx/aiinbx-py/commit/d3fd7c9d952f18802eae02b6766181e5e5e42fe2))

## 0.107.0 (2025-11-25)

Full Changelog: [v0.106.0...v0.107.0](https://github.com/aiinbx/aiinbx-py/compare/v0.106.0...v0.107.0)

### Features

* **api:** api update ([9c59858](https://github.com/aiinbx/aiinbx-py/commit/9c59858f8e0d43584637920f9c6fd8e84b71199a))

## 0.106.0 (2025-11-25)

Full Changelog: [v0.105.0...v0.106.0](https://github.com/aiinbx/aiinbx-py/compare/v0.105.0...v0.106.0)

### Features

* **api:** api update ([8e56bc0](https://github.com/aiinbx/aiinbx-py/commit/8e56bc0e74dd0bb896c2ce09e65fc688511a39f2))

## 0.105.0 (2025-11-25)

Full Changelog: [v0.104.0...v0.105.0](https://github.com/aiinbx/aiinbx-py/compare/v0.104.0...v0.105.0)

### Features

* **api:** api update ([bd1404c](https://github.com/aiinbx/aiinbx-py/commit/bd1404c07eff87288b3f656c1b2dbd22b7a0b8df))

## 0.104.0 (2025-11-25)

Full Changelog: [v0.103.0...v0.104.0](https://github.com/aiinbx/aiinbx-py/compare/v0.103.0...v0.104.0)

### Features

* **api:** api update ([32c9c5c](https://github.com/aiinbx/aiinbx-py/commit/32c9c5cef6d392062ac1ecc0f048cce94397895f))

## 0.103.0 (2025-11-25)

Full Changelog: [v0.102.0...v0.103.0](https://github.com/aiinbx/aiinbx-py/compare/v0.102.0...v0.103.0)

### Features

* **api:** api update ([75297ac](https://github.com/aiinbx/aiinbx-py/commit/75297ace0f7ac44bec8e177b77692f4a40baf589))

## 0.102.0 (2025-11-25)

Full Changelog: [v0.101.0...v0.102.0](https://github.com/aiinbx/aiinbx-py/compare/v0.101.0...v0.102.0)

### Features

* **api:** api update ([628467e](https://github.com/aiinbx/aiinbx-py/commit/628467e4ff7ec410357dec20a7b82082d5c1804c))

## 0.101.0 (2025-11-25)

Full Changelog: [v0.100.0...v0.101.0](https://github.com/aiinbx/aiinbx-py/compare/v0.100.0...v0.101.0)

### Features

* **api:** api update ([a446d3e](https://github.com/aiinbx/aiinbx-py/commit/a446d3ea2acab4df5748e8bd67971d4d7b42045c))

## 0.100.0 (2025-11-25)

Full Changelog: [v0.99.0...v0.100.0](https://github.com/aiinbx/aiinbx-py/compare/v0.99.0...v0.100.0)

### Features

* **api:** api update ([c6bf192](https://github.com/aiinbx/aiinbx-py/commit/c6bf19267425b36e5b03333be4183ae93b626d34))

## 0.99.0 (2025-11-25)

Full Changelog: [v0.98.0...v0.99.0](https://github.com/aiinbx/aiinbx-py/compare/v0.98.0...v0.99.0)

### Features

* **api:** api update ([8e1a0d7](https://github.com/aiinbx/aiinbx-py/commit/8e1a0d7e991761b039049d7c115f5ac9e0e574dc))

## 0.98.0 (2025-11-25)

Full Changelog: [v0.97.0...v0.98.0](https://github.com/aiinbx/aiinbx-py/compare/v0.97.0...v0.98.0)

### Features

* **api:** api update ([bead2f2](https://github.com/aiinbx/aiinbx-py/commit/bead2f2f878227f6df01064c48d4e9f6881c8cb2))

## 0.97.0 (2025-11-24)

Full Changelog: [v0.96.0...v0.97.0](https://github.com/aiinbx/aiinbx-py/compare/v0.96.0...v0.97.0)

### Features

* **api:** api update ([57d31b8](https://github.com/aiinbx/aiinbx-py/commit/57d31b82d58e5664b867376a055be7e8f81c94c3))

## 0.96.0 (2025-11-24)

Full Changelog: [v0.95.0...v0.96.0](https://github.com/aiinbx/aiinbx-py/compare/v0.95.0...v0.96.0)

### Features

* **api:** api update ([e127d5f](https://github.com/aiinbx/aiinbx-py/commit/e127d5f9b1f2cd89e539540dc3f3a37bc5ea6fe5))

## 0.95.0 (2025-11-24)

Full Changelog: [v0.94.0...v0.95.0](https://github.com/aiinbx/aiinbx-py/compare/v0.94.0...v0.95.0)

### Features

* **api:** api update ([9a2361e](https://github.com/aiinbx/aiinbx-py/commit/9a2361ed0342c66ff96a3d3f43b0dae54e51ad61))

## 0.94.0 (2025-11-24)

Full Changelog: [v0.93.0...v0.94.0](https://github.com/aiinbx/aiinbx-py/compare/v0.93.0...v0.94.0)

### Features

* **api:** api update ([65d321c](https://github.com/aiinbx/aiinbx-py/commit/65d321ca0e96d03c657b459cd93c2198b0752a81))

## 0.93.0 (2025-11-24)

Full Changelog: [v0.92.0...v0.93.0](https://github.com/aiinbx/aiinbx-py/compare/v0.92.0...v0.93.0)

### Features

* **api:** api update ([285dc04](https://github.com/aiinbx/aiinbx-py/commit/285dc0421ae30c79ddfa4f79b66b58e23a3c3f53))

## 0.92.0 (2025-11-24)

Full Changelog: [v0.91.0...v0.92.0](https://github.com/aiinbx/aiinbx-py/compare/v0.91.0...v0.92.0)

### Features

* **api:** api update ([8a01ec4](https://github.com/aiinbx/aiinbx-py/commit/8a01ec46537fa5d1b22eece2f933df8651b060a6))

## 0.91.0 (2025-11-24)

Full Changelog: [v0.90.0...v0.91.0](https://github.com/aiinbx/aiinbx-py/compare/v0.90.0...v0.91.0)

### Features

* **api:** api update ([4e16918](https://github.com/aiinbx/aiinbx-py/commit/4e1691835040f44cd0a9aec32038c5a5f983648a))

## 0.90.0 (2025-11-24)

Full Changelog: [v0.89.0...v0.90.0](https://github.com/aiinbx/aiinbx-py/compare/v0.89.0...v0.90.0)

### Features

* **api:** api update ([9d6c65c](https://github.com/aiinbx/aiinbx-py/commit/9d6c65c5e0c0d28ecd2207dd3588b9f87905cef4))

## 0.89.0 (2025-11-23)

Full Changelog: [v0.88.0...v0.89.0](https://github.com/aiinbx/aiinbx-py/compare/v0.88.0...v0.89.0)

### Features

* **api:** api update ([0f2a29c](https://github.com/aiinbx/aiinbx-py/commit/0f2a29c468ef2523c24c6248919e0b064f1481cf))

## 0.88.0 (2025-11-23)

Full Changelog: [v0.87.0...v0.88.0](https://github.com/aiinbx/aiinbx-py/compare/v0.87.0...v0.88.0)

### Features

* **api:** api update ([7563af9](https://github.com/aiinbx/aiinbx-py/commit/7563af9cc1ca5f3a20cb1c8d6a4cc8930c4fcc58))

## 0.87.0 (2025-11-23)

Full Changelog: [v0.86.0...v0.87.0](https://github.com/aiinbx/aiinbx-py/compare/v0.86.0...v0.87.0)

### Features

* **api:** api update ([db583db](https://github.com/aiinbx/aiinbx-py/commit/db583db372d4c4089dfd2e4c8987edb5f2c15626))

## 0.86.0 (2025-11-23)

Full Changelog: [v0.85.0...v0.86.0](https://github.com/aiinbx/aiinbx-py/compare/v0.85.0...v0.86.0)

### Features

* **api:** api update ([78971fb](https://github.com/aiinbx/aiinbx-py/commit/78971fbff92489b6ff981a84d44ac1a89341242c))

## 0.85.0 (2025-11-23)

Full Changelog: [v0.84.0...v0.85.0](https://github.com/aiinbx/aiinbx-py/compare/v0.84.0...v0.85.0)

### Features

* **api:** api update ([c449694](https://github.com/aiinbx/aiinbx-py/commit/c449694fba8d6b3ee2363cd162bb84b2323ddbb1))

## 0.84.0 (2025-11-23)

Full Changelog: [v0.83.0...v0.84.0](https://github.com/aiinbx/aiinbx-py/compare/v0.83.0...v0.84.0)

### Features

* **api:** api update ([5e04bd8](https://github.com/aiinbx/aiinbx-py/commit/5e04bd8ef846531ea62b1a04b429a1cba86fc52d))

## 0.83.0 (2025-11-23)

Full Changelog: [v0.82.0...v0.83.0](https://github.com/aiinbx/aiinbx-py/compare/v0.82.0...v0.83.0)

### Features

* **api:** api update ([17120cb](https://github.com/aiinbx/aiinbx-py/commit/17120cb060710e880444ab8659c02848fe763f13))

## 0.82.0 (2025-11-23)

Full Changelog: [v0.81.0...v0.82.0](https://github.com/aiinbx/aiinbx-py/compare/v0.81.0...v0.82.0)

### Features

* **api:** api update ([28bc66e](https://github.com/aiinbx/aiinbx-py/commit/28bc66ef7f313e366ac2ceb05077ea567959dcdc))

## 0.81.0 (2025-11-23)

Full Changelog: [v0.80.0...v0.81.0](https://github.com/aiinbx/aiinbx-py/compare/v0.80.0...v0.81.0)

### Features

* **api:** api update ([3dda4a1](https://github.com/aiinbx/aiinbx-py/commit/3dda4a15491e7bafb3b5cc0ad475366d83a8adf7))

## 0.80.0 (2025-11-23)

Full Changelog: [v0.79.0...v0.80.0](https://github.com/aiinbx/aiinbx-py/compare/v0.79.0...v0.80.0)

### Features

* **api:** api update ([c16d233](https://github.com/aiinbx/aiinbx-py/commit/c16d233f10968aab444317f2b4f3d28bd24e53f0))

## 0.79.0 (2025-11-23)

Full Changelog: [v0.78.0...v0.79.0](https://github.com/aiinbx/aiinbx-py/compare/v0.78.0...v0.79.0)

### Features

* **api:** api update ([0a449d4](https://github.com/aiinbx/aiinbx-py/commit/0a449d403cdd5f8cf0d5af24c3464c6e14173d83))

## 0.78.0 (2025-11-23)

Full Changelog: [v0.77.0...v0.78.0](https://github.com/aiinbx/aiinbx-py/compare/v0.77.0...v0.78.0)

### Features

* **api:** api update ([1cb7886](https://github.com/aiinbx/aiinbx-py/commit/1cb7886e1ae830fc5e74a9977986e48fd0a6826f))

## 0.77.0 (2025-11-22)

Full Changelog: [v0.76.0...v0.77.0](https://github.com/aiinbx/aiinbx-py/compare/v0.76.0...v0.77.0)

### Features

* **api:** api update ([153ff5b](https://github.com/aiinbx/aiinbx-py/commit/153ff5b0c609a057a645f7613bfd5eec51f5e52c))

## 0.76.0 (2025-11-22)

Full Changelog: [v0.75.0...v0.76.0](https://github.com/aiinbx/aiinbx-py/compare/v0.75.0...v0.76.0)

### Features

* **api:** api update ([dd15724](https://github.com/aiinbx/aiinbx-py/commit/dd157242db4cc30e4df666fa7ef6e13de4db487c))

## 0.75.0 (2025-11-22)

Full Changelog: [v0.74.0...v0.75.0](https://github.com/aiinbx/aiinbx-py/compare/v0.74.0...v0.75.0)

### Features

* **api:** api update ([35da423](https://github.com/aiinbx/aiinbx-py/commit/35da42365bc4a5147a02a0b5f795b1c0f571b8c2))

## 0.74.0 (2025-11-22)

Full Changelog: [v0.73.0...v0.74.0](https://github.com/aiinbx/aiinbx-py/compare/v0.73.0...v0.74.0)

### Features

* **api:** api update ([5ce8eb7](https://github.com/aiinbx/aiinbx-py/commit/5ce8eb7899f6a5ef5f0c76aecda92791ab0d2ef3))

## 0.73.0 (2025-11-22)

Full Changelog: [v0.72.0...v0.73.0](https://github.com/aiinbx/aiinbx-py/compare/v0.72.0...v0.73.0)

### Features

* **api:** api update ([ba74e8a](https://github.com/aiinbx/aiinbx-py/commit/ba74e8ab2f44ecd7768594fc84ed3ef177295a08))

## 0.72.0 (2025-11-22)

Full Changelog: [v0.71.0...v0.72.0](https://github.com/aiinbx/aiinbx-py/compare/v0.71.0...v0.72.0)

### Features

* **api:** api update ([547645b](https://github.com/aiinbx/aiinbx-py/commit/547645b7531125c5b87aabe65391322465b5803e))

## 0.71.0 (2025-11-22)

Full Changelog: [v0.70.0...v0.71.0](https://github.com/aiinbx/aiinbx-py/compare/v0.70.0...v0.71.0)

### Features

* **api:** api update ([54ef3ae](https://github.com/aiinbx/aiinbx-py/commit/54ef3aed189ee1de665a24d84d92c2ccac57ae1c))

## 0.70.0 (2025-11-22)

Full Changelog: [v0.69.0...v0.70.0](https://github.com/aiinbx/aiinbx-py/compare/v0.69.0...v0.70.0)

### Features

* **api:** api update ([134491c](https://github.com/aiinbx/aiinbx-py/commit/134491c6a3f54a30f05fb2f6faa8abcc6ea011e9))

## 0.69.0 (2025-11-22)

Full Changelog: [v0.68.0...v0.69.0](https://github.com/aiinbx/aiinbx-py/compare/v0.68.0...v0.69.0)

### Features

* **api:** api update ([d9f30ae](https://github.com/aiinbx/aiinbx-py/commit/d9f30ae5fbe5ae57b006a71fda94996e72a1328e))

## 0.68.0 (2025-11-22)

Full Changelog: [v0.67.0...v0.68.0](https://github.com/aiinbx/aiinbx-py/compare/v0.67.0...v0.68.0)

### Features

* **api:** api update ([9c419ee](https://github.com/aiinbx/aiinbx-py/commit/9c419ee8e26ebc5bc6c7b0c373cf00a12bea75b0))

## 0.67.0 (2025-11-22)

Full Changelog: [v0.66.0...v0.67.0](https://github.com/aiinbx/aiinbx-py/compare/v0.66.0...v0.67.0)

### Features

* **api:** api update ([d4b338f](https://github.com/aiinbx/aiinbx-py/commit/d4b338f1a4be2250647aa71aad337dc37333ef6d))


### Chores

* add Python 3.14 classifier and testing ([62f401d](https://github.com/aiinbx/aiinbx-py/commit/62f401ddcd9c4cba9fce5cf4a5343577aead36e4))

## 0.66.0 (2025-11-22)

Full Changelog: [v0.65.0...v0.66.0](https://github.com/aiinbx/aiinbx-py/compare/v0.65.0...v0.66.0)

### Features

* **api:** api update ([7f98c7a](https://github.com/aiinbx/aiinbx-py/commit/7f98c7a6b6bd7608464f9759c663d3ecc507809d))

## 0.65.0 (2025-11-22)

Full Changelog: [v0.64.0...v0.65.0](https://github.com/aiinbx/aiinbx-py/compare/v0.64.0...v0.65.0)

### Features

* **api:** api update ([c21773b](https://github.com/aiinbx/aiinbx-py/commit/c21773b7849351704a4aa11a96b40d277bfdfe4c))

## 0.64.0 (2025-11-22)

Full Changelog: [v0.63.0...v0.64.0](https://github.com/aiinbx/aiinbx-py/compare/v0.63.0...v0.64.0)

### Features

* **api:** api update ([74b1868](https://github.com/aiinbx/aiinbx-py/commit/74b1868c1899beff00b4f95fc53404346673e81d))

## 0.63.0 (2025-11-21)

Full Changelog: [v0.62.0...v0.63.0](https://github.com/aiinbx/aiinbx-py/compare/v0.62.0...v0.63.0)

### Features

* **api:** api update ([2feb128](https://github.com/aiinbx/aiinbx-py/commit/2feb1289dd7a740f9a507740409be433568bb733))

## 0.62.0 (2025-11-21)

Full Changelog: [v0.61.0...v0.62.0](https://github.com/aiinbx/aiinbx-py/compare/v0.61.0...v0.62.0)

### Features

* **api:** api update ([1fd8f6a](https://github.com/aiinbx/aiinbx-py/commit/1fd8f6a5de7faf0b290c567060147f05286cacd4))

## 0.61.0 (2025-11-21)

Full Changelog: [v0.60.0...v0.61.0](https://github.com/aiinbx/aiinbx-py/compare/v0.60.0...v0.61.0)

### Features

* **api:** api update ([63aaef3](https://github.com/aiinbx/aiinbx-py/commit/63aaef3967cb9c21ccd4f852ebe7a9e6e69c67fd))

## 0.60.0 (2025-11-21)

Full Changelog: [v0.59.0...v0.60.0](https://github.com/aiinbx/aiinbx-py/compare/v0.59.0...v0.60.0)

### Features

* **api:** api update ([1785c25](https://github.com/aiinbx/aiinbx-py/commit/1785c25ccad58c14e1145a604e1583fd46d03258))

## 0.59.0 (2025-11-21)

Full Changelog: [v0.58.0...v0.59.0](https://github.com/aiinbx/aiinbx-py/compare/v0.58.0...v0.59.0)

### Features

* **api:** api update ([0c970a7](https://github.com/aiinbx/aiinbx-py/commit/0c970a7ddea8b38c4fa39229588d7d921b789861))

## 0.58.0 (2025-11-21)

Full Changelog: [v0.57.0...v0.58.0](https://github.com/aiinbx/aiinbx-py/compare/v0.57.0...v0.58.0)

### Features

* **api:** api update ([84b8a60](https://github.com/aiinbx/aiinbx-py/commit/84b8a60042eb48cc4c8478e6fda54bc0f3755ac0))

## 0.57.0 (2025-11-21)

Full Changelog: [v0.56.0...v0.57.0](https://github.com/aiinbx/aiinbx-py/compare/v0.56.0...v0.57.0)

### Features

* **api:** api update ([134f28d](https://github.com/aiinbx/aiinbx-py/commit/134f28dd327111d70bf14402129cf6aff1ccc736))

## 0.56.0 (2025-11-21)

Full Changelog: [v0.55.0...v0.56.0](https://github.com/aiinbx/aiinbx-py/compare/v0.55.0...v0.56.0)

### Features

* **api:** api update ([6367694](https://github.com/aiinbx/aiinbx-py/commit/6367694cdbaca9a5c220c50c8a5bda7f217b23e5))

## 0.55.0 (2025-11-21)

Full Changelog: [v0.54.0...v0.55.0](https://github.com/aiinbx/aiinbx-py/compare/v0.54.0...v0.55.0)

### Features

* **api:** api update ([b822faf](https://github.com/aiinbx/aiinbx-py/commit/b822faf1d9bc625bca46b684072c5d67f64107b1))

## 0.54.0 (2025-11-20)

Full Changelog: [v0.53.0...v0.54.0](https://github.com/aiinbx/aiinbx-py/compare/v0.53.0...v0.54.0)

### Features

* **api:** api update ([6b71e1f](https://github.com/aiinbx/aiinbx-py/commit/6b71e1f9af19842069b37c12e228ba44bc3d8f91))

## 0.53.0 (2025-11-20)

Full Changelog: [v0.52.0...v0.53.0](https://github.com/aiinbx/aiinbx-py/compare/v0.52.0...v0.53.0)

### Features

* **api:** api update ([85ebce1](https://github.com/aiinbx/aiinbx-py/commit/85ebce1d9837a14238cf636ec342513c168e1d91))

## 0.52.0 (2025-11-20)

Full Changelog: [v0.51.0...v0.52.0](https://github.com/aiinbx/aiinbx-py/compare/v0.51.0...v0.52.0)

### Features

* **api:** api update ([8a32278](https://github.com/aiinbx/aiinbx-py/commit/8a32278f6f1342538080eb97a3c924809e6b5361))

## 0.51.0 (2025-11-20)

Full Changelog: [v0.50.0...v0.51.0](https://github.com/aiinbx/aiinbx-py/compare/v0.50.0...v0.51.0)

### Features

* **api:** api update ([85caac4](https://github.com/aiinbx/aiinbx-py/commit/85caac45303006acc345fdb9dfef03c6a9867a2e))

## 0.50.0 (2025-11-20)

Full Changelog: [v0.49.0...v0.50.0](https://github.com/aiinbx/aiinbx-py/compare/v0.49.0...v0.50.0)

### Features

* **api:** api update ([7dff50e](https://github.com/aiinbx/aiinbx-py/commit/7dff50e7d8e817c42d0e75098c1b025d2bf889ba))

## 0.49.0 (2025-11-20)

Full Changelog: [v0.48.0...v0.49.0](https://github.com/aiinbx/aiinbx-py/compare/v0.48.0...v0.49.0)

### Features

* **api:** api update ([44d2e9f](https://github.com/aiinbx/aiinbx-py/commit/44d2e9fb016a3df5f167247ea6f4ee7b9d5e4541))

## 0.48.0 (2025-11-20)

Full Changelog: [v0.47.0...v0.48.0](https://github.com/aiinbx/aiinbx-py/compare/v0.47.0...v0.48.0)

### Features

* **api:** api update ([ef55fcf](https://github.com/aiinbx/aiinbx-py/commit/ef55fcf68f39d32ed844fb892af3062b5d98d46e))

## 0.47.0 (2025-11-20)

Full Changelog: [v0.46.0...v0.47.0](https://github.com/aiinbx/aiinbx-py/compare/v0.46.0...v0.47.0)

### Features

* **api:** api update ([212d2c5](https://github.com/aiinbx/aiinbx-py/commit/212d2c512049dfdd4933456d203ad78055dd0ad4))

## 0.46.0 (2025-11-20)

Full Changelog: [v0.45.0...v0.46.0](https://github.com/aiinbx/aiinbx-py/compare/v0.45.0...v0.46.0)

### Features

* **api:** api update ([38faf59](https://github.com/aiinbx/aiinbx-py/commit/38faf592aa991e75c18c6a6a04e97dbcdeb820e2))
* **api:** api update ([df0d0c2](https://github.com/aiinbx/aiinbx-py/commit/df0d0c27a95bd53f6298f83c9e90faff9d35a489))

## 0.45.0 (2025-11-19)

Full Changelog: [v0.44.0...v0.45.0](https://github.com/aiinbx/aiinbx-py/compare/v0.44.0...v0.45.0)

### Features

* **api:** api update ([c03b59c](https://github.com/aiinbx/aiinbx-py/commit/c03b59cd171e8889b5e0ba7bba2d78fecda4cfb4))

## 0.44.0 (2025-11-19)

Full Changelog: [v0.43.0...v0.44.0](https://github.com/aiinbx/aiinbx-py/compare/v0.43.0...v0.44.0)

### Features

* **api:** api update ([869b2e2](https://github.com/aiinbx/aiinbx-py/commit/869b2e24f735d6c9ea92ab2bfc9fe5b313c71999))

## 0.43.0 (2025-11-19)

Full Changelog: [v0.42.0...v0.43.0](https://github.com/aiinbx/aiinbx-py/compare/v0.42.0...v0.43.0)

### Features

* **api:** api update ([f353fd7](https://github.com/aiinbx/aiinbx-py/commit/f353fd79e4be75b49a1b4224560c697fa88b7971))

## 0.42.0 (2025-11-19)

Full Changelog: [v0.41.0...v0.42.0](https://github.com/aiinbx/aiinbx-py/compare/v0.41.0...v0.42.0)

### Features

* **api:** api update ([907a6ba](https://github.com/aiinbx/aiinbx-py/commit/907a6ba050c97925d06db258cfd4d38b4ea06521))

## 0.41.0 (2025-11-19)

Full Changelog: [v0.40.0...v0.41.0](https://github.com/aiinbx/aiinbx-py/compare/v0.40.0...v0.41.0)

### Features

* **api:** api update ([17c7ce2](https://github.com/aiinbx/aiinbx-py/commit/17c7ce235fa810896d4ea978f073cab30453c79d))

## 0.40.0 (2025-11-19)

Full Changelog: [v0.39.0...v0.40.0](https://github.com/aiinbx/aiinbx-py/compare/v0.39.0...v0.40.0)

### Features

* **api:** api update ([0b0896d](https://github.com/aiinbx/aiinbx-py/commit/0b0896da1bfa6aa8ebc9bf7d70678adde421b8c9))

## 0.39.0 (2025-11-18)

Full Changelog: [v0.38.0...v0.39.0](https://github.com/aiinbx/aiinbx-py/compare/v0.38.0...v0.39.0)

### Features

* **api:** api update ([c5d2004](https://github.com/aiinbx/aiinbx-py/commit/c5d20042088ab15972aec0ef6499678cc9ac0300))

## 0.38.0 (2025-11-18)

Full Changelog: [v0.37.0...v0.38.0](https://github.com/aiinbx/aiinbx-py/compare/v0.37.0...v0.38.0)

### Features

* **api:** api update ([bcf07a5](https://github.com/aiinbx/aiinbx-py/commit/bcf07a59f71d677ad127b418eaa8833b560bd61a))
* **api:** api update ([22f5a13](https://github.com/aiinbx/aiinbx-py/commit/22f5a134583e2e7c3a3e51b3419ea1afd5c8a3a1))
* **api:** api update ([2865d84](https://github.com/aiinbx/aiinbx-py/commit/2865d84b5c5283c7755287ee5fca64ba46ee6cdf))
* **api:** api update ([8084044](https://github.com/aiinbx/aiinbx-py/commit/80840444792bd38df7e8c5b23697ca30eb9cab32))
* **api:** api update ([6217cf4](https://github.com/aiinbx/aiinbx-py/commit/6217cf46a2cfade17ef9e71eb1a62976ebd931c9))
* **api:** api update ([4a8d8c4](https://github.com/aiinbx/aiinbx-py/commit/4a8d8c42e47b8dcd85cbc2b4d06de21c91bef921))
* **api:** api update ([6fde6bb](https://github.com/aiinbx/aiinbx-py/commit/6fde6bb2fe44c59108447cc8ac7a323b7d0c2629))
* **api:** api update ([fc5511e](https://github.com/aiinbx/aiinbx-py/commit/fc5511e033fc3b3bc2ff14df8b6beb00548f76b9))
* **api:** api update ([acfd5ed](https://github.com/aiinbx/aiinbx-py/commit/acfd5ed0eb83fa61f0d1dfc5582221627d807d18))
* **api:** api update ([217f9fe](https://github.com/aiinbx/aiinbx-py/commit/217f9fe35cc01e3632021154532b9e8c68ac34ea))
* **api:** api update ([ad10db4](https://github.com/aiinbx/aiinbx-py/commit/ad10db4bce1262d36b94612cc47ee6e8c66b2ba0))
* **api:** api update ([297679b](https://github.com/aiinbx/aiinbx-py/commit/297679b314e893af136eaac292cb01f7c64e76d1))
* **api:** api update ([b77ff86](https://github.com/aiinbx/aiinbx-py/commit/b77ff862599eba45522848d1976f2ad0f7171830))
* **api:** api update ([918bf99](https://github.com/aiinbx/aiinbx-py/commit/918bf99ea3d6df3ce819627e37cc02f61969721e))
* **api:** api update ([94d5491](https://github.com/aiinbx/aiinbx-py/commit/94d5491081b14940f026f26ede06609563053e2f))
* **api:** api update ([d0edd94](https://github.com/aiinbx/aiinbx-py/commit/d0edd9478aa785a39fa9269b83e41af5cea6d2a1))
* **api:** api update ([8401492](https://github.com/aiinbx/aiinbx-py/commit/84014923bc87d1caee8ad0e8f7b59f09ff276ef8))
* **api:** api update ([e220a15](https://github.com/aiinbx/aiinbx-py/commit/e220a156bab48b9d6695b07ee888c60fc4c57409))
* **api:** api update ([d8d2ac5](https://github.com/aiinbx/aiinbx-py/commit/d8d2ac5e07ccf3db6c9e81c9c0b78ae3e4d14e7f))
* **api:** api update ([0ce53af](https://github.com/aiinbx/aiinbx-py/commit/0ce53af25ec38907a900fe4853ff8b9bdf19cf00))
* **api:** api update ([bfd7765](https://github.com/aiinbx/aiinbx-py/commit/bfd77656d16db7142ba89c7533fc65a6714c96ab))
* **api:** api update ([9a989b4](https://github.com/aiinbx/aiinbx-py/commit/9a989b4a8eecd76012a38a967f8f21702781f703))
* **api:** api update ([9ebe5ce](https://github.com/aiinbx/aiinbx-py/commit/9ebe5ce18e2acb366245b22d201ed15b3e35d1aa))
* **api:** api update ([5f74d6b](https://github.com/aiinbx/aiinbx-py/commit/5f74d6bc627b23cb85e9c3beddbb3e3f5bf77f25))
* **api:** api update ([2f56833](https://github.com/aiinbx/aiinbx-py/commit/2f568330c6060d7c255be445847083518659eb6e))
* **api:** api update ([df57cb1](https://github.com/aiinbx/aiinbx-py/commit/df57cb153d7cb3f7f5badf98a190b20c7047d254))
* **api:** api update ([e3fa355](https://github.com/aiinbx/aiinbx-py/commit/e3fa35502f7b817fa74e1b6b3032c1d08a34d873))
* **api:** api update ([a5ca405](https://github.com/aiinbx/aiinbx-py/commit/a5ca405d9fedb2ac2b7f20713f8f8f7c87dfc85f))
* **api:** api update ([fe5a0cc](https://github.com/aiinbx/aiinbx-py/commit/fe5a0cc698a3b8b0dd1a3f993cbf450ed47778fe))
* **api:** api update ([4f77bfb](https://github.com/aiinbx/aiinbx-py/commit/4f77bfbecceea24c6b0209573aa6803b520fce2a))
* **api:** api update ([8e2c2d3](https://github.com/aiinbx/aiinbx-py/commit/8e2c2d38780c713d63ed975ec3366936d19e83fe))
* **api:** api update ([abab237](https://github.com/aiinbx/aiinbx-py/commit/abab237a881dad9a4b0ac14ac2987f963323d1ec))
* **api:** api update ([09bb63d](https://github.com/aiinbx/aiinbx-py/commit/09bb63d0796c0ec6f7c4f85054fa765d5d437f54))
* **api:** api update ([12de8ae](https://github.com/aiinbx/aiinbx-py/commit/12de8aef3efb1916af01cfc298a0880b7ac90781))
* **api:** api update ([835f86b](https://github.com/aiinbx/aiinbx-py/commit/835f86bd8a3eeefdb0c027e20a24bb705da527c1))
* **api:** manual updates ([0e6ad9c](https://github.com/aiinbx/aiinbx-py/commit/0e6ad9c05bc04d627495d33c26112fe8eea3b83e))
* **api:** manual updates ([a8e2907](https://github.com/aiinbx/aiinbx-py/commit/a8e29077f61c37e1565bae986960e671b4d8583d))
* **api:** manual updates ([3377308](https://github.com/aiinbx/aiinbx-py/commit/33773085b7658fb2be22c4c487ea33877e980c7c))
* **api:** manual updates ([9f338c0](https://github.com/aiinbx/aiinbx-py/commit/9f338c08cf76e9482a9529c761654cdd250483ea))
* improve future compat with pydantic v3 ([60479fd](https://github.com/aiinbx/aiinbx-py/commit/60479fd5aab856633c6eca0df3c1c5bfaddceb1d))
* **types:** replace List[str] with SequenceNotStr in params ([68f13b9](https://github.com/aiinbx/aiinbx-py/commit/68f13b951258795a96bfeb25b9017d404edf58b7))


### Bug Fixes

* avoid newer type syntax ([5be7f33](https://github.com/aiinbx/aiinbx-py/commit/5be7f3326de519f7be66a89cb7fea6428378b2af))
* **client:** close streams without requiring full consumption ([c9f31ef](https://github.com/aiinbx/aiinbx-py/commit/c9f31ef55fb6d3fb93be2213334f91a2d04dd258))
* compat with Python 3.14 ([7e15855](https://github.com/aiinbx/aiinbx-py/commit/7e158557c4b162a4a87c67b939cddf0d9d1a7d05))
* **compat:** update signatures of `model_dump` and `model_dump_json` for Pydantic v1 ([744437f](https://github.com/aiinbx/aiinbx-py/commit/744437f18a7aa06a7956aae618a7240e6926061f))


### Chores

* bump `httpx-aiohttp` version to 0.1.9 ([68dfe98](https://github.com/aiinbx/aiinbx-py/commit/68dfe98c70f4338569bc9ec71c769cfb596b66df))
* configure new SDK language ([3cc34fc](https://github.com/aiinbx/aiinbx-py/commit/3cc34fcf8b0325986076726a774c419992b5aafa))
* do not install brew dependencies in ./scripts/bootstrap by default ([b790676](https://github.com/aiinbx/aiinbx-py/commit/b79067691b2dd53f05e0c1ec4e7d44329d5a2a7d))
* **internal/tests:** avoid race condition with implicit client cleanup ([8151b68](https://github.com/aiinbx/aiinbx-py/commit/8151b681a02be66458edc9692574dc6143f036f7))
* **internal:** add Sequence related utils ([4a2dd8c](https://github.com/aiinbx/aiinbx-py/commit/4a2dd8c5ca6c58ca5e4774eaad28167b0d797bf9))
* **internal:** change ci workflow machines ([0bdef89](https://github.com/aiinbx/aiinbx-py/commit/0bdef89c32b5776076a51f33e0bf2e3b420c76f2))
* **internal:** codegen related update ([6f79bad](https://github.com/aiinbx/aiinbx-py/commit/6f79bad626202ec0b4227e61a5ddc4c8b9acdf64))
* **internal:** detect missing future annotations with ruff ([c12e87e](https://github.com/aiinbx/aiinbx-py/commit/c12e87e4070f07c2b69625d727166ba55fcbbd62))
* **internal:** grammar fix (it's -&gt; its) ([ec0e54a](https://github.com/aiinbx/aiinbx-py/commit/ec0e54a72af0ce65d410a2e5775253cf9e570268))
* **internal:** move mypy configurations to `pyproject.toml` file ([485c0d9](https://github.com/aiinbx/aiinbx-py/commit/485c0d9f65d7fd8f59f9a2509c31cceaced1200f))
* **internal:** update pydantic dependency ([6a9413a](https://github.com/aiinbx/aiinbx-py/commit/6a9413a8cb94c48beed239109f876e705a3c92a1))
* **internal:** update pyright exclude list ([a2e7dba](https://github.com/aiinbx/aiinbx-py/commit/a2e7dba2d4e5daacb20e90498133b7f814938556))
* **tests:** simplify `get_platform` test ([ba0da0f](https://github.com/aiinbx/aiinbx-py/commit/ba0da0f48f2209bcb96d9d5f9f7d92dbbd9ed524))
* **types:** change optional parameter type from NotGiven to Omit ([220c508](https://github.com/aiinbx/aiinbx-py/commit/220c508548d348593f5ab50b919b68ff7a0321e2))
* update github action ([9f7c7f2](https://github.com/aiinbx/aiinbx-py/commit/9f7c7f2a77c7f129fcebcad3de76a0d0c027c511))
* update SDK settings ([9251ee7](https://github.com/aiinbx/aiinbx-py/commit/9251ee7b47185255692e59f672e6158f4af32541))

## 0.37.0 (2025-11-18)

Full Changelog: [v0.36.0...v0.37.0](https://github.com/aiinbx/aiinbx-py/compare/v0.36.0...v0.37.0)

### Features

* **api:** api update ([8d216db](https://github.com/aiinbx/aiinbx-py/commit/8d216db301003d76022e91c6d2f133e577616204))

## 0.36.0 (2025-11-18)

Full Changelog: [v0.35.0...v0.36.0](https://github.com/aiinbx/aiinbx-py/compare/v0.35.0...v0.36.0)

### Features

* **api:** api update ([8a8da17](https://github.com/aiinbx/aiinbx-py/commit/8a8da17951a064d0ed7f3d6df431f51993d577ea))

## 0.35.0 (2025-11-18)

Full Changelog: [v0.34.0...v0.35.0](https://github.com/aiinbx/aiinbx-py/compare/v0.34.0...v0.35.0)

### Features

* **api:** api update ([8a2a8df](https://github.com/aiinbx/aiinbx-py/commit/8a2a8dfd96493c2ccebb9094a51b7cbe547e5e4a))

## 0.34.0 (2025-11-18)

Full Changelog: [v0.33.0...v0.34.0](https://github.com/aiinbx/aiinbx-py/compare/v0.33.0...v0.34.0)

### Features

* **api:** api update ([fa2eefd](https://github.com/aiinbx/aiinbx-py/commit/fa2eefde5f4e0a5282419e38aa0350c959eaa4e1))

## 0.33.0 (2025-11-18)

Full Changelog: [v0.32.0...v0.33.0](https://github.com/aiinbx/aiinbx-py/compare/v0.32.0...v0.33.0)

### Features

* **api:** api update ([a9f4e64](https://github.com/aiinbx/aiinbx-py/commit/a9f4e64a44eef5f83c5524b7805a42c1ec0a11a4))
* **api:** api update ([6fde6bb](https://github.com/aiinbx/aiinbx-py/commit/6fde6bb2fe44c59108447cc8ac7a323b7d0c2629))
* **api:** api update ([fc5511e](https://github.com/aiinbx/aiinbx-py/commit/fc5511e033fc3b3bc2ff14df8b6beb00548f76b9))
* **api:** api update ([acfd5ed](https://github.com/aiinbx/aiinbx-py/commit/acfd5ed0eb83fa61f0d1dfc5582221627d807d18))
* **api:** api update ([217f9fe](https://github.com/aiinbx/aiinbx-py/commit/217f9fe35cc01e3632021154532b9e8c68ac34ea))
* **api:** api update ([ad10db4](https://github.com/aiinbx/aiinbx-py/commit/ad10db4bce1262d36b94612cc47ee6e8c66b2ba0))
* **api:** api update ([297679b](https://github.com/aiinbx/aiinbx-py/commit/297679b314e893af136eaac292cb01f7c64e76d1))
* **api:** api update ([b77ff86](https://github.com/aiinbx/aiinbx-py/commit/b77ff862599eba45522848d1976f2ad0f7171830))
* **api:** api update ([918bf99](https://github.com/aiinbx/aiinbx-py/commit/918bf99ea3d6df3ce819627e37cc02f61969721e))
* **api:** api update ([94d5491](https://github.com/aiinbx/aiinbx-py/commit/94d5491081b14940f026f26ede06609563053e2f))
* **api:** api update ([d0edd94](https://github.com/aiinbx/aiinbx-py/commit/d0edd9478aa785a39fa9269b83e41af5cea6d2a1))
* **api:** api update ([8401492](https://github.com/aiinbx/aiinbx-py/commit/84014923bc87d1caee8ad0e8f7b59f09ff276ef8))
* **api:** api update ([e220a15](https://github.com/aiinbx/aiinbx-py/commit/e220a156bab48b9d6695b07ee888c60fc4c57409))
* **api:** api update ([d8d2ac5](https://github.com/aiinbx/aiinbx-py/commit/d8d2ac5e07ccf3db6c9e81c9c0b78ae3e4d14e7f))
* **api:** api update ([0ce53af](https://github.com/aiinbx/aiinbx-py/commit/0ce53af25ec38907a900fe4853ff8b9bdf19cf00))
* **api:** api update ([bfd7765](https://github.com/aiinbx/aiinbx-py/commit/bfd77656d16db7142ba89c7533fc65a6714c96ab))
* **api:** api update ([9a989b4](https://github.com/aiinbx/aiinbx-py/commit/9a989b4a8eecd76012a38a967f8f21702781f703))
* **api:** api update ([9ebe5ce](https://github.com/aiinbx/aiinbx-py/commit/9ebe5ce18e2acb366245b22d201ed15b3e35d1aa))
* **api:** api update ([5f74d6b](https://github.com/aiinbx/aiinbx-py/commit/5f74d6bc627b23cb85e9c3beddbb3e3f5bf77f25))
* **api:** api update ([2f56833](https://github.com/aiinbx/aiinbx-py/commit/2f568330c6060d7c255be445847083518659eb6e))
* **api:** api update ([df57cb1](https://github.com/aiinbx/aiinbx-py/commit/df57cb153d7cb3f7f5badf98a190b20c7047d254))
* **api:** api update ([e3fa355](https://github.com/aiinbx/aiinbx-py/commit/e3fa35502f7b817fa74e1b6b3032c1d08a34d873))
* **api:** api update ([a5ca405](https://github.com/aiinbx/aiinbx-py/commit/a5ca405d9fedb2ac2b7f20713f8f8f7c87dfc85f))
* **api:** api update ([fe5a0cc](https://github.com/aiinbx/aiinbx-py/commit/fe5a0cc698a3b8b0dd1a3f993cbf450ed47778fe))
* **api:** api update ([4f77bfb](https://github.com/aiinbx/aiinbx-py/commit/4f77bfbecceea24c6b0209573aa6803b520fce2a))
* **api:** api update ([8e2c2d3](https://github.com/aiinbx/aiinbx-py/commit/8e2c2d38780c713d63ed975ec3366936d19e83fe))
* **api:** api update ([abab237](https://github.com/aiinbx/aiinbx-py/commit/abab237a881dad9a4b0ac14ac2987f963323d1ec))
* **api:** api update ([09bb63d](https://github.com/aiinbx/aiinbx-py/commit/09bb63d0796c0ec6f7c4f85054fa765d5d437f54))
* **api:** api update ([12de8ae](https://github.com/aiinbx/aiinbx-py/commit/12de8aef3efb1916af01cfc298a0880b7ac90781))
* **api:** api update ([835f86b](https://github.com/aiinbx/aiinbx-py/commit/835f86bd8a3eeefdb0c027e20a24bb705da527c1))
* **api:** manual updates ([0e6ad9c](https://github.com/aiinbx/aiinbx-py/commit/0e6ad9c05bc04d627495d33c26112fe8eea3b83e))
* **api:** manual updates ([a8e2907](https://github.com/aiinbx/aiinbx-py/commit/a8e29077f61c37e1565bae986960e671b4d8583d))
* **api:** manual updates ([3377308](https://github.com/aiinbx/aiinbx-py/commit/33773085b7658fb2be22c4c487ea33877e980c7c))
* **api:** manual updates ([9f338c0](https://github.com/aiinbx/aiinbx-py/commit/9f338c08cf76e9482a9529c761654cdd250483ea))
* improve future compat with pydantic v3 ([60479fd](https://github.com/aiinbx/aiinbx-py/commit/60479fd5aab856633c6eca0df3c1c5bfaddceb1d))
* **types:** replace List[str] with SequenceNotStr in params ([68f13b9](https://github.com/aiinbx/aiinbx-py/commit/68f13b951258795a96bfeb25b9017d404edf58b7))


### Bug Fixes

* avoid newer type syntax ([5be7f33](https://github.com/aiinbx/aiinbx-py/commit/5be7f3326de519f7be66a89cb7fea6428378b2af))
* **client:** close streams without requiring full consumption ([c9f31ef](https://github.com/aiinbx/aiinbx-py/commit/c9f31ef55fb6d3fb93be2213334f91a2d04dd258))
* compat with Python 3.14 ([7e15855](https://github.com/aiinbx/aiinbx-py/commit/7e158557c4b162a4a87c67b939cddf0d9d1a7d05))
* **compat:** update signatures of `model_dump` and `model_dump_json` for Pydantic v1 ([744437f](https://github.com/aiinbx/aiinbx-py/commit/744437f18a7aa06a7956aae618a7240e6926061f))


### Chores

* bump `httpx-aiohttp` version to 0.1.9 ([68dfe98](https://github.com/aiinbx/aiinbx-py/commit/68dfe98c70f4338569bc9ec71c769cfb596b66df))
* configure new SDK language ([3cc34fc](https://github.com/aiinbx/aiinbx-py/commit/3cc34fcf8b0325986076726a774c419992b5aafa))
* do not install brew dependencies in ./scripts/bootstrap by default ([b790676](https://github.com/aiinbx/aiinbx-py/commit/b79067691b2dd53f05e0c1ec4e7d44329d5a2a7d))
* **internal/tests:** avoid race condition with implicit client cleanup ([8151b68](https://github.com/aiinbx/aiinbx-py/commit/8151b681a02be66458edc9692574dc6143f036f7))
* **internal:** add Sequence related utils ([4a2dd8c](https://github.com/aiinbx/aiinbx-py/commit/4a2dd8c5ca6c58ca5e4774eaad28167b0d797bf9))
* **internal:** change ci workflow machines ([0bdef89](https://github.com/aiinbx/aiinbx-py/commit/0bdef89c32b5776076a51f33e0bf2e3b420c76f2))
* **internal:** codegen related update ([6f79bad](https://github.com/aiinbx/aiinbx-py/commit/6f79bad626202ec0b4227e61a5ddc4c8b9acdf64))
* **internal:** detect missing future annotations with ruff ([c12e87e](https://github.com/aiinbx/aiinbx-py/commit/c12e87e4070f07c2b69625d727166ba55fcbbd62))
* **internal:** grammar fix (it's -&gt; its) ([ec0e54a](https://github.com/aiinbx/aiinbx-py/commit/ec0e54a72af0ce65d410a2e5775253cf9e570268))
* **internal:** move mypy configurations to `pyproject.toml` file ([485c0d9](https://github.com/aiinbx/aiinbx-py/commit/485c0d9f65d7fd8f59f9a2509c31cceaced1200f))
* **internal:** update pydantic dependency ([6a9413a](https://github.com/aiinbx/aiinbx-py/commit/6a9413a8cb94c48beed239109f876e705a3c92a1))
* **internal:** update pyright exclude list ([a2e7dba](https://github.com/aiinbx/aiinbx-py/commit/a2e7dba2d4e5daacb20e90498133b7f814938556))
* **tests:** simplify `get_platform` test ([ba0da0f](https://github.com/aiinbx/aiinbx-py/commit/ba0da0f48f2209bcb96d9d5f9f7d92dbbd9ed524))
* **types:** change optional parameter type from NotGiven to Omit ([220c508](https://github.com/aiinbx/aiinbx-py/commit/220c508548d348593f5ab50b919b68ff7a0321e2))
* update github action ([9f7c7f2](https://github.com/aiinbx/aiinbx-py/commit/9f7c7f2a77c7f129fcebcad3de76a0d0c027c511))
* update SDK settings ([9251ee7](https://github.com/aiinbx/aiinbx-py/commit/9251ee7b47185255692e59f672e6158f4af32541))

## 0.32.0 (2025-11-18)

Full Changelog: [v0.31.0...v0.32.0](https://github.com/aiinbx/aiinbx-py/compare/v0.31.0...v0.32.0)

### Features

* **api:** api update ([68e735d](https://github.com/aiinbx/aiinbx-py/commit/68e735dfbd46c4495b15ee0475a454be2b70d071))

## 0.31.0 (2025-11-18)

Full Changelog: [v0.30.0...v0.31.0](https://github.com/aiinbx/aiinbx-py/compare/v0.30.0...v0.31.0)

### Features

* **api:** api update ([1caf52d](https://github.com/aiinbx/aiinbx-py/commit/1caf52d0d38e0ed858cb909b343f0945f16d76f9))

## 0.30.0 (2025-11-17)

Full Changelog: [v0.29.0...v0.30.0](https://github.com/aiinbx/aiinbx-py/compare/v0.29.0...v0.30.0)

### Features

* **api:** api update ([26931da](https://github.com/aiinbx/aiinbx-py/commit/26931da268c8db09f51494c11cdb7c290b97f0f1))

## 0.29.0 (2025-11-17)

Full Changelog: [v0.28.0...v0.29.0](https://github.com/aiinbx/aiinbx-py/compare/v0.28.0...v0.29.0)

### Features

* **api:** api update ([8864d90](https://github.com/aiinbx/aiinbx-py/commit/8864d90564569d6409d969316fcaa23a3193cc0f))

## 0.28.0 (2025-11-17)

Full Changelog: [v0.27.0...v0.28.0](https://github.com/aiinbx/aiinbx-py/compare/v0.27.0...v0.28.0)

### Features

* **api:** api update ([4b9f66c](https://github.com/aiinbx/aiinbx-py/commit/4b9f66c616434332276e6442ea5d319807649b8f))

## 0.27.0 (2025-11-17)

Full Changelog: [v0.26.0...v0.27.0](https://github.com/aiinbx/aiinbx-py/compare/v0.26.0...v0.27.0)

### Features

* **api:** api update ([fad20c1](https://github.com/aiinbx/aiinbx-py/commit/fad20c11a6647f2d8fb44c1b871509217daffb9d))

## 0.26.0 (2025-11-17)

Full Changelog: [v0.25.0...v0.26.0](https://github.com/aiinbx/aiinbx-py/compare/v0.25.0...v0.26.0)

### Features

* **api:** api update ([131b2cf](https://github.com/aiinbx/aiinbx-py/commit/131b2cfb0a95229173edaff527922f0fc005d53a))

## 0.25.0 (2025-11-17)

Full Changelog: [v0.24.0...v0.25.0](https://github.com/aiinbx/aiinbx-py/compare/v0.24.0...v0.25.0)

### Features

* **api:** api update ([ca06373](https://github.com/aiinbx/aiinbx-py/commit/ca06373a0655a4263293b90f83fdcbb023537fbc))
* **api:** api update ([324884a](https://github.com/aiinbx/aiinbx-py/commit/324884a673831f317709aca4dfaa4dfee8bec01c))

## 0.24.0 (2025-11-17)

Full Changelog: [v0.23.0...v0.24.0](https://github.com/aiinbx/aiinbx-py/compare/v0.23.0...v0.24.0)

### Features

* **api:** api update ([d4cc500](https://github.com/aiinbx/aiinbx-py/commit/d4cc500501514ea58515e7a7c6b1eb9fce5d8a9c))

## 0.23.0 (2025-11-17)

Full Changelog: [v0.22.0...v0.23.0](https://github.com/aiinbx/aiinbx-py/compare/v0.22.0...v0.23.0)

### Features

* **api:** api update ([4bd1404](https://github.com/aiinbx/aiinbx-py/commit/4bd14043d5d312aea548de04165cd4a94b838321))

## 0.22.0 (2025-11-17)

Full Changelog: [v0.21.0...v0.22.0](https://github.com/aiinbx/aiinbx-py/compare/v0.21.0...v0.22.0)

### Features

* **api:** api update ([77853f3](https://github.com/aiinbx/aiinbx-py/commit/77853f3028819561553f4d00a200d9eacc5ef089))

## 0.21.0 (2025-11-17)

Full Changelog: [v0.20.0...v0.21.0](https://github.com/aiinbx/aiinbx-py/compare/v0.20.0...v0.21.0)

### Features

* **api:** api update ([6bbbe93](https://github.com/aiinbx/aiinbx-py/commit/6bbbe93fa42c2facf5c6b1d84ba32bf47658c300))

## 0.20.0 (2025-11-16)

Full Changelog: [v0.19.0...v0.20.0](https://github.com/aiinbx/aiinbx-py/compare/v0.19.0...v0.20.0)

### Features

* **api:** api update ([87c105a](https://github.com/aiinbx/aiinbx-py/commit/87c105a99df202f9a3dc388b0cfe078251998d5f))

## 0.19.0 (2025-11-16)

Full Changelog: [v0.18.0...v0.19.0](https://github.com/aiinbx/aiinbx-py/compare/v0.18.0...v0.19.0)

### Features

* **api:** api update ([07beb52](https://github.com/aiinbx/aiinbx-py/commit/07beb52d40745cbcf5193c85a7efbdc90ad1ef31))

## 0.18.0 (2025-11-16)

Full Changelog: [v0.17.0...v0.18.0](https://github.com/aiinbx/aiinbx-py/compare/v0.17.0...v0.18.0)

### Features

* **api:** api update ([24490c8](https://github.com/aiinbx/aiinbx-py/commit/24490c8805342f13b6ff919d27feaf0d7dfb71ed))

## 0.17.0 (2025-11-16)

Full Changelog: [v0.16.0...v0.17.0](https://github.com/aiinbx/aiinbx-py/compare/v0.16.0...v0.17.0)

### Features

* **api:** api update ([4db8f52](https://github.com/aiinbx/aiinbx-py/commit/4db8f52e507e287f71e36f2ce1816e7147d97d39))

## 0.16.0 (2025-11-16)

Full Changelog: [v0.15.0...v0.16.0](https://github.com/aiinbx/aiinbx-py/compare/v0.15.0...v0.16.0)

### Features

* **api:** api update ([b423628](https://github.com/aiinbx/aiinbx-py/commit/b423628767b266a14d0e9b385d6ed057dfae1f78))

## 0.15.0 (2025-11-16)

Full Changelog: [v0.14.0...v0.15.0](https://github.com/aiinbx/aiinbx-py/compare/v0.14.0...v0.15.0)

### Features

* **api:** api update ([e85c831](https://github.com/aiinbx/aiinbx-py/commit/e85c831870cdc8e101cd4c08ab665babda9fe089))

## 0.14.0 (2025-11-16)

Full Changelog: [v0.13.0...v0.14.0](https://github.com/aiinbx/aiinbx-py/compare/v0.13.0...v0.14.0)

### Features

* **api:** api update ([4f72d75](https://github.com/aiinbx/aiinbx-py/commit/4f72d758e209039a5293d53750b224c18ca8025a))

## 0.13.0 (2025-11-16)

Full Changelog: [v0.12.0...v0.13.0](https://github.com/aiinbx/aiinbx-py/compare/v0.12.0...v0.13.0)

### Features

* **api:** api update ([13b6d23](https://github.com/aiinbx/aiinbx-py/commit/13b6d23df33c278b1f17ab41a0df7495500bf553))

## 0.12.0 (2025-11-16)

Full Changelog: [v0.11.0...v0.12.0](https://github.com/aiinbx/aiinbx-py/compare/v0.11.0...v0.12.0)

### Features

* **api:** api update ([f2d9176](https://github.com/aiinbx/aiinbx-py/commit/f2d91769b6ab82a2a234f76b59f9b273d7850c8d))

## 0.11.0 (2025-11-15)

Full Changelog: [v0.10.0...v0.11.0](https://github.com/aiinbx/aiinbx-py/compare/v0.10.0...v0.11.0)

### Features

* **api:** api update ([1bf1047](https://github.com/aiinbx/aiinbx-py/commit/1bf1047914ccbdb79141933797ee2153f57928a2))

## 0.10.0 (2025-11-15)

Full Changelog: [v0.9.0...v0.10.0](https://github.com/aiinbx/aiinbx-py/compare/v0.9.0...v0.10.0)

### Features

* **api:** api update ([ef0d36f](https://github.com/aiinbx/aiinbx-py/commit/ef0d36f67a8254350e4d6d08e2ea340666df5286))

## 0.9.0 (2025-11-15)

Full Changelog: [v0.8.0...v0.9.0](https://github.com/aiinbx/aiinbx-py/compare/v0.8.0...v0.9.0)

### Features

* **api:** api update ([43ed250](https://github.com/aiinbx/aiinbx-py/commit/43ed250785d0b96f48c3a46b6db9b017f080aebc))

## 0.8.0 (2025-11-15)

Full Changelog: [v0.7.2...v0.8.0](https://github.com/aiinbx/aiinbx-py/compare/v0.7.2...v0.8.0)

### Features

* **api:** api update ([73ba8b5](https://github.com/aiinbx/aiinbx-py/commit/73ba8b5c88cf196e502f10cf975dd5c58620fd90))

## 0.7.2 (2025-11-12)

Full Changelog: [v0.7.1...v0.7.2](https://github.com/aiinbx/aiinbx-py/compare/v0.7.1...v0.7.2)

### Bug Fixes

* **compat:** update signatures of `model_dump` and `model_dump_json` for Pydantic v1 ([63fdaba](https://github.com/aiinbx/aiinbx-py/commit/63fdaba20d9bfe35d1d1358ef229d28c222b5ecf))

## 0.7.1 (2025-11-11)

Full Changelog: [v0.7.0...v0.7.1](https://github.com/aiinbx/aiinbx-py/compare/v0.7.0...v0.7.1)

### Bug Fixes

* compat with Python 3.14 ([17da3dd](https://github.com/aiinbx/aiinbx-py/commit/17da3dd00711f92f515ab05562b79eb784d0ce24))


### Chores

* **internal:** codegen related update ([2976852](https://github.com/aiinbx/aiinbx-py/commit/2976852cdedba8ffdaed6879fd51d87708419503))

## 0.7.0 (2025-11-04)

Full Changelog: [v0.6.0...v0.7.0](https://github.com/aiinbx/aiinbx-py/compare/v0.6.0...v0.7.0)

### Features

* **api:** api update ([0f82ed1](https://github.com/aiinbx/aiinbx-py/commit/0f82ed1bf1a6d34c2e63ecbc9cf0a5b43f53e89a))


### Chores

* **internal:** grammar fix (it's -&gt; its) ([4398c76](https://github.com/aiinbx/aiinbx-py/commit/4398c76c2f4f5cd115df6f40f9948dc9d439a9b6))

## 0.6.0 (2025-10-31)

Full Changelog: [v0.5.1...v0.6.0](https://github.com/aiinbx/aiinbx-py/compare/v0.5.1...v0.6.0)

### Features

* **api:** api update ([e0ee97a](https://github.com/aiinbx/aiinbx-py/commit/e0ee97a7568dc6839f1c011b5312ec34ce3d9f7d))


### Chores

* **internal/tests:** avoid race condition with implicit client cleanup ([4cf6938](https://github.com/aiinbx/aiinbx-py/commit/4cf6938564097419455a6219e0b217e7921a9ea2))

## 0.5.1 (2025-10-30)

Full Changelog: [v0.5.0...v0.5.1](https://github.com/aiinbx/aiinbx-py/compare/v0.5.0...v0.5.1)

### Bug Fixes

* **client:** close streams without requiring full consumption ([d824bbb](https://github.com/aiinbx/aiinbx-py/commit/d824bbbd517355748039bf7f5edfbee0e802a606))


### Chores

* bump `httpx-aiohttp` version to 0.1.9 ([8c932fb](https://github.com/aiinbx/aiinbx-py/commit/8c932fb49aa74fe9174deb5c7b4e71cccd41f119))

## 0.5.0 (2025-10-15)

Full Changelog: [v0.4.0...v0.5.0](https://github.com/aiinbx/aiinbx-py/compare/v0.4.0...v0.5.0)

### Features

* **api:** manual updates ([ddacc81](https://github.com/aiinbx/aiinbx-py/commit/ddacc8158fd4079c1ee4b8ae04f89f22e2fcd46a))


### Chores

* **internal:** detect missing future annotations with ruff ([6f6a3da](https://github.com/aiinbx/aiinbx-py/commit/6f6a3da5978b34e1a2959b38715d4311474f1c5e))

## 0.4.0 (2025-10-05)

Full Changelog: [v0.3.0...v0.4.0](https://github.com/aiinbx/aiinbx-py/compare/v0.3.0...v0.4.0)

### Features

* **api:** manual updates ([601d5ea](https://github.com/aiinbx/aiinbx-py/commit/601d5eade9216549a200c26584a2cc18176835fd))
* improve future compat with pydantic v3 ([dcc1c80](https://github.com/aiinbx/aiinbx-py/commit/dcc1c804ec998e7948395f7c1ea3aac371a539fb))
* **types:** replace List[str] with SequenceNotStr in params ([a31a999](https://github.com/aiinbx/aiinbx-py/commit/a31a999a8dd553a067fdd4368d147f773418dc02))


### Chores

* do not install brew dependencies in ./scripts/bootstrap by default ([b4c08e3](https://github.com/aiinbx/aiinbx-py/commit/b4c08e37dfa25b784a2cd7d5e9778f3318c365b9))
* **internal:** add Sequence related utils ([879c21a](https://github.com/aiinbx/aiinbx-py/commit/879c21ac262c2c10c0e1bfa03d5d1c40470f889b))
* **internal:** move mypy configurations to `pyproject.toml` file ([3108a79](https://github.com/aiinbx/aiinbx-py/commit/3108a794e35f868d1e21a210abbda837eecc64d1))
* **internal:** update pydantic dependency ([6dcd694](https://github.com/aiinbx/aiinbx-py/commit/6dcd694e2ab6b8246892ebef85e95bff9b0338a9))
* **tests:** simplify `get_platform` test ([0f14d8c](https://github.com/aiinbx/aiinbx-py/commit/0f14d8cd43342f3fda7ccda30717c01d20679593))
* **types:** change optional parameter type from NotGiven to Omit ([1b12faa](https://github.com/aiinbx/aiinbx-py/commit/1b12faa48dbcc8fedf5dc8e4a410c58fcfac7853))

## 0.3.0 (2025-08-28)

Full Changelog: [v0.2.0...v0.3.0](https://github.com/aiinbx/aiinbx-py/compare/v0.2.0...v0.3.0)

### Features

* **api:** api update ([2de3cb7](https://github.com/aiinbx/aiinbx-py/commit/2de3cb73d4178e81925fd6d04b3683b81e7da30d))

## 0.2.0 (2025-08-28)

Full Changelog: [v0.1.1...v0.2.0](https://github.com/aiinbx/aiinbx-py/compare/v0.1.1...v0.2.0)

### Features

* **api:** manual updates ([f4e60fe](https://github.com/aiinbx/aiinbx-py/commit/f4e60fed47de83248dbcef3cd28590643c0b9bff))

## 0.1.1 (2025-08-27)

Full Changelog: [v0.1.0...v0.1.1](https://github.com/aiinbx/aiinbx-py/compare/v0.1.0...v0.1.1)

### Bug Fixes

* avoid newer type syntax ([85f2191](https://github.com/aiinbx/aiinbx-py/commit/85f21914439dbd7e3ef751a1010eaf023b33ef70))


### Chores

* **internal:** change ci workflow machines ([7e210c5](https://github.com/aiinbx/aiinbx-py/commit/7e210c590a8a7659cbbf3f087b869ca580bd9b1b))
* **internal:** update pyright exclude list ([a4d4c96](https://github.com/aiinbx/aiinbx-py/commit/a4d4c9626f42577c535516072216bc82c6b2d551))
* update github action ([d06abee](https://github.com/aiinbx/aiinbx-py/commit/d06abee5f995ce020da7ab44160eaab348c8c18a))

## 0.1.0 (2025-08-13)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/aiinbx/aiinbx-py/compare/v0.0.1...v0.1.0)

### Features

* **api:** manual updates ([9f338c0](https://github.com/aiinbx/aiinbx-py/commit/9f338c08cf76e9482a9529c761654cdd250483ea))


### Chores

* configure new SDK language ([3cc34fc](https://github.com/aiinbx/aiinbx-py/commit/3cc34fcf8b0325986076726a774c419992b5aafa))
* update SDK settings ([9251ee7](https://github.com/aiinbx/aiinbx-py/commit/9251ee7b47185255692e59f672e6158f4af32541))
