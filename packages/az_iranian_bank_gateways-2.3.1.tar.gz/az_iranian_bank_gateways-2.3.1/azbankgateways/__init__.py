__version__ = "v2.3.1"
default_app_config = "azbankgateways.apps.AZIranianBankGatewaysConfig"
