import typing

DictQuerystring = typing.Tuple[str, dict]
