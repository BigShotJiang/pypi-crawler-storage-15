from .banks import callback_view, go_to_bank_gateway  # noqa
from .samples import sample_payment_view, sample_result_view  # noqa
