# ARASE Python SDK

المكتبة الرسمية لـ ARASE - محرك البحث الذكي بالذكاء الاصطناعي.

Official Python SDK for ARASE - AI-powered search engine API.

## Installation | التثبيت

```bash
pip install arase-sdk
```

## Quick Start | البداية السريعة

### Option 1: Environment Variable (Recommended) | الخيار 1: متغير البيئة (مستحسن)

```bash
# .env file | ملف .env
ARASE_API_KEY=arase_YOUR_API_KEY
```

```python
from arase import AraseClient

# Automatically reads from ARASE_API_KEY environment variable
# يقرأ تلقائياً من متغير البيئة ARASE_API_KEY
client = AraseClient()

results = client.search("ما هي رؤية السعودية 2030؟")
print(results.answer)
```

### Option 2: Direct API Key | الخيار 2: مفتاح API مباشر

```python
from arase import AraseClient

client = AraseClient(api_key="arase_YOUR_API_KEY")

results = client.search("What is Saudi Vision 2030?")
print(results.answer)
```

## Environment Variables | متغيرات البيئة

| Variable | Description | الوصف |
|----------|-------------|-------|
| `ARASE_API_KEY` | Your API key (required) | مفتاح API الخاص بك (مطلوب) |
| `ARASE_BASE_URL` | Custom API URL (optional) | رابط API مخصص (اختياري) |

## Features | الميزات

### Web Search | بحث الويب

```python
results = client.search("أفضل المطاعم في الرياض", include_answer=True)

print(results.answer)   # AI-generated answer | إجابة AI
print(results.results)  # Web results | نتائج الويب
```

### Image Search | بحث الصور

```python
results = client.search_images("برج المملكة الرياض")
for image in results.images:
    print(image.image_url)
```

### News Search | بحث الأخبار

```python
results = client.search_news("أخبار السعودية اليوم")
for article in results.news:
    print(f"{article.title} - {article.source}")
```

### Places Search | بحث الأماكن

```python
# Search near Riyadh | البحث قرب الرياض
results = client.search_places(
    "مقاهي قريبة",
    user_location={"lat": 24.7136, "lng": 46.6753}
)
for place in results.places:
    print(f"{place.title} - {place.rating}⭐")
```

### Academic Search | بحث أكاديمي

```python
results = client.search_scholar("artificial intelligence")
for paper in results.scholar:
    print(f"{paper.title} ({paper.year}) - {paper.citations} citations")
```

### Content Extraction | استخراج المحتوى

```python
content = client.extract(
    "https://example.com/article",
    include_summary=True
)
print(content.content)
print(content.summary)
```

## Advanced Options | خيارات متقدمة

```python
from arase import AraseClient, SearchOptions

client = AraseClient()

# Using SearchOptions | استخدام SearchOptions
options = SearchOptions(
    search_depth="deep",      # basic | advanced | deep
    max_results=20,
    include_answer=True,
    include_images=True,
    include_videos=True,
    include_news=True,
    include_places=True,
    include_shopping=True,
    include_scholar=True,
    topic="general",          # general | news | academic
    max_steps=3,              # For deep search | للبحث العميق
)

results = client.search("query", options=options)

# Or use keyword arguments | أو استخدم الكلمات المفتاحية
results = client.search(
    "query",
    include_answer=True,
    max_results=10,
)
```

## Async Support | دعم Async

```python
import asyncio
from arase import AsyncAraseClient

async def main():
    async with AsyncAraseClient() as client:
        results = await client.search("query", include_answer=True)
        print(results.answer)

asyncio.run(main())
```

## Error Handling | معالجة الأخطاء

```python
from arase import AraseClient, AraseAPIError

client = AraseClient()

try:
    results = client.search("query")
except AraseAPIError as e:
    print(f"Error {e.code}: {e.message}")
    print(f"Status: {e.status}")
```

## Context Manager | مدير السياق

```python
from arase import AraseClient

# Automatically closes connection | يغلق الاتصال تلقائياً
with AraseClient() as client:
    results = client.search("query")
    print(results.answer)
```

## Type Hints | تلميحات الأنواع

Full type hints support for better IDE experience:

```python
from arase import (
    AraseClient,
    SearchOptions,
    SearchResponse,
    SearchResult,
    ImageResult,
    # ... etc
)
```

## Links | روابط

- 📖 [Documentation | التوثيق](https://arase.masarat.sa/docs)
- 🎮 [Playground | ساحة التجربة](https://arase.masarat.sa/platform)
- 🔑 [Get API Key | احصل على مفتاح](https://arase.masarat.sa/platform)
- 💻 [GitHub](https://github.com/masarat-sa/arase-python)

## License

MIT
