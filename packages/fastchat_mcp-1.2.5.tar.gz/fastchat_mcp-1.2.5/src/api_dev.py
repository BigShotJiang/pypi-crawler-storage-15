from .fastchat.api.api import FastApp, FastAPI
from .fastchat.config import AuthApiConfig

base_prompt: str = """
La empresa "TechNova" vende productos electrónicos. Tiene un promedio de 5.000
ventas mensuales en Latinoamérica. Sus categorías principales son smartphones,
notebooks y accesorios.
"""

auth_settings = AuthApiConfig().new_override({"log_lv": "DEBUG"})
fastapp: FastApp = FastApp(
    extra_reponse_system_prompts=[base_prompt],
    extra_selection_system_prompts=[base_prompt],
)
app: FastAPI = fastapp.app
