![PR Build](https://github.com/ebourgeois/firestone-lib/actions/workflows/pr.yml/badge.svg)


# firestone-lib

This library is primarily used by the firestone project and anyone using the firestone project.

# building and testing

```
brew install poetry
poetry install
poetry build
poetry run pytest test
```
