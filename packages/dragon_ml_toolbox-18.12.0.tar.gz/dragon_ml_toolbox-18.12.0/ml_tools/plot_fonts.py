from ._core._plot_fonts import (
    configure_cjk_fonts,
    info
)

__all__ = [
    "configure_cjk_fonts"
]
