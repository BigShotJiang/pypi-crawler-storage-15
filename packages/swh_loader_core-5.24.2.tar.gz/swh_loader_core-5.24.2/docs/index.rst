.. _swh-loader-core:

.. include:: README.rst

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   vcs-loader-overview
   package-loader-tutorial
   package-loader-specifications


Reference Documentation
-----------------------

.. toctree::
   :maxdepth: 2

   cli

.. only:: standalone_package_doc

   Indices and tables
   ------------------

   * :ref:`genindex`
   * :ref:`modindex`
   * :ref:`search`
