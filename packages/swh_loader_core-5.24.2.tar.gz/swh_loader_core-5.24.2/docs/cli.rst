.. _swh-loader-cli:

Command-line interface
======================

.. click:: swh.loader.cli:loader
  :prog: swh loader
  :nested: full
