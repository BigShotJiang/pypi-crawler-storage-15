"""Tests for fsspec-utils package."""
