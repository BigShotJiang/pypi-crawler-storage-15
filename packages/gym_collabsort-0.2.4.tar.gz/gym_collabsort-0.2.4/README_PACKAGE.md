# gym-collabsort

A [Gymnasium](https://gymnasium.farama.org/) environment for training agents on a collaborative sorting task.

More details on [project homepage](https://github.com/bpesquet/gym-collabsort).
