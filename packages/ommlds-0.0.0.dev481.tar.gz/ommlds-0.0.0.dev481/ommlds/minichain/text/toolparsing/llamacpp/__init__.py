# https://github.com/ggml-org/llama.cpp/blob/cf0a43bb6490bd49344775abb22ba26f8047cb54/common/chat.cpp#L1448
