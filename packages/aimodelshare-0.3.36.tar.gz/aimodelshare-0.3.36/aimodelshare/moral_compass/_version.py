"""Version information for aimodelshare.moral_compass"""

__version__ = "0.1.1"
