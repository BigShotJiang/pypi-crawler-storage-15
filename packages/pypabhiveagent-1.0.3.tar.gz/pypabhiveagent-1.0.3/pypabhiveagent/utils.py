"""
Utility functions for pypabhiveagent package.
"""

import logging
from typing import Dict, Any


def mask_sensitive_data(data: Dict[str, Any], sensitive_keys: list = None) -> Dict[str, Any]:
    """
    Mask sensitive data in a dictionary for safe logging.
    
    Args:
        data: Dictionary containing data to mask
        sensitive_keys: List of keys to mask (default: ['token', 'password', 'hive_password'])
        
    Returns:
        Dict: Dictionary with sensitive values masked
        
    Example:
        >>> config = {'url': 'http://api.com', 'token': 'secret123', 'app_id': 'app1'}
        >>> safe_config = mask_sensitive_data(config)
        >>> print(safe_config)
        {'url': 'http://api.com', 'token': '***MASKED***', 'app_id': 'app1'}
    """
    if sensitive_keys is None:
        sensitive_keys = ['token', 'password', 'hive_password', 'passwd', 'secret', 'api_key']
    
    # Create a copy to avoid modifying the original
    masked_data = data.copy()
    
    for key in sensitive_keys:
        if key in masked_data:
            masked_data[key] = '***MASKED***'
    
    return masked_data


def get_safe_repr(obj: Any, max_length: int = 100) -> str:
    """
    Get a safe string representation of an object for logging.
    Truncates long strings and masks sensitive data.
    
    Args:
        obj: Object to represent
        max_length: Maximum length of the representation
        
    Returns:
        str: Safe string representation
    """
    repr_str = repr(obj)
    
    if len(repr_str) > max_length:
        repr_str = repr_str[:max_length] + '...'
    
    return repr_str
