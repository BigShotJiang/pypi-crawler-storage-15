"""
pypabhiveagent - A Python package for querying Hive data and processing with AIGC applications.

This package provides a simple interface to:
- Query data from Hive tables
- Process data through AIGC applications (Prompt or Agent types)
- Parse and merge results
- Store results to Hive tables or Excel files
"""

__version__ = "1.0.3"
__author__ = "pypabhiveagent"
__license__ = "MIT"

from pypabhiveagent.agent import HiveAgent
from pypabhiveagent.exceptions import (
    PyPabHiveAgentError,
    ConfigurationError,
    HiveQueryError,
    AIGCRequestError,
    ResultParseError,
    StorageError,
)
from pypabhiveagent.logging_config import (
    configure_logging,
    get_logger,
    set_log_level,
)

__all__ = [
    "HiveAgent",
    "PyPabHiveAgentError",
    "ConfigurationError",
    "HiveQueryError",
    "AIGCRequestError",
    "ResultParseError",
    "StorageError",
    "configure_logging",
    "get_logger",
    "set_log_level",
]
