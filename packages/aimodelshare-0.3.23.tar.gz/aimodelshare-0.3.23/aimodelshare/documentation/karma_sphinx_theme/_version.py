__version_info__ = (0, 0, 8)
__version__ = '.'.join(map(str, __version_info__))
