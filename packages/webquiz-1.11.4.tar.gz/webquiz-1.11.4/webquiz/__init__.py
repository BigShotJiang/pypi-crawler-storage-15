"""Webquiz - A modern light web-based testing platform."""

__version__ = "1.11.4"
__author__ = "oduvan"
__email__ = "a.lyabah@checkio.org"
__description__ = "A modern web-based testing system built with Python and aiohttp"
