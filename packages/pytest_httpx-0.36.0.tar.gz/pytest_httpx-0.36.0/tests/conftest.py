# see https://docs.pytest.org/en/documentation-restructure/how-to/writing_plugins.html#testing-plugins
pytest_plugins = ["pytester"]
