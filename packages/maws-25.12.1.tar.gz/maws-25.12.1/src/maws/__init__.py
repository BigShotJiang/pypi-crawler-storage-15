__app_name__ = "maws"
__version__ = "0.0.1"
