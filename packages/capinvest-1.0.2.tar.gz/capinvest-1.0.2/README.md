# CapInvest Platform

 CapInvest is committed to build the future of investment research by focusing on an open source infrastructure accessible to everyone, everywhere. |
 
## Overview

The CapInvest Platform provides a convenient way to access raw financial data from multiple data providers. The package comes with a ready to use REST API - this allows developers from any language to easily create applications on top of CapInvest Platform.

 

## Installation

The command below provides access to the core functionalities behind the CapInvest Platform.

```bash
pip install capinvest
```

This will install the following data providers:

These packages are what will be installed when `pip install capinvest` is run

| Extension Name          | Description | Installation Command                | Minimum Subscription Type Required |
|-------------------------|-------------|-------------------------------------|------------------------------------|
| capinvest-benzinga         | [Benzinga](https://www.benzinga.com/apis/en-ca/) data connector | pip install capinvest-benzinga         | Paid |
| capinvest-bls              | [Bureau of Labor Statistics](https://www.bls.gov/developers/home.htm) data connector | pip install capinvest-bls              | Free |
| capinvest-cftc             | [Commodity Futures Trading Commission](https://publicreporting.cftc.gov/stories/s/r4w3-av2u) data connector | pip install capinvest-cftc             | Free |
| capinvest-econdb           | [EconDB](https://econdb.com) data connector | pip install capinvest-econdb           | None |
| capinvest-imf              | [IMF](https://data.imf.org) data connector | pip install capinvest-imf              | None |
| capinvest-fmp              | [FMP](https://site.financialmodelingprep.com/developer/) data connector | pip install capinvest-fmp              | Free |
| capinvest-fred             | [FRED](https://fred.stlouisfed.org/) data connector | pip install capinvest-fred             | Free |
| capinvest-intrinio         | [Intrinio](https://intrinio.com/pricing) data connector | pip install capinvest-intrinio         | Paid |
| capinvest-oecd             | [OECD](https://data.oecd.org/) data connector | pip install capinvest-oecd             | Free |
| capinvest-polygon          | [Polygon](https://polygon.io/) data connector | pip install capinvest-polygon          | Free |
| capinvest-sec              | [SEC](https://www.sec.gov/edgar/sec-api-documentation) data connector | pip install capinvest-sec              | None |
| capinvest-tiingo           | [Tiingo](https://www.tiingo.com/about/pricing) data connector | pip install capinvest-tiingo           | Free |
| capinvest-tradingeconomics | [TradingEconomics](https://tradingeconomics.com/api) data connector | pip install capinvest-tradingeconomics | Paid |
| capinvest-yfinance      | [Yahoo Finance](https://finance.yahoo.com/) data connector | pip install capinvest-yfinance      | None |

### Community Providers

These packages are not installed when `pip install capinvest` is run.  They are available for installation separately or by running `pip install capinvest[all]`

| Extension Name            | Description | Installation Command | Minimum Subscription Type Required |
|---------------------------|-------------|----------------------|------------------------------------|
| capinvest-alpha-vantage   | [Alpha Vantage](https://www.alphavantage.co/) data connector | pip install capinvest-alpha-vantage | Free |
| capinvest-biztoc          | [Biztoc](https://api.biztoc.com/#biztoc-default) News data connector | pip install capinvest-biztoc | Free |
| capinvest-cboe            | [Cboe](https://www.cboe.com/delayed_quotes/) data connector | pip install capinvest-cboe | None |
| capinvest-ecb             | [ECB](https://data.ecb.europa.eu/) data connector | pip install capinvest-ecb | None |
| capinvest-federal-reserve | [Federal Reserve](https://www.federalreserve.gov/) data connector | pip install capinvest-federal-reserve | None |
| capinvest-finra | [FINRA](https://www.finra.org/finra-data) data connector | pip install capinvest-finra | None / Free |
| capinvest-finviz | [Finviz](https://finviz.com) data connector | pip install capinvest-finviz | None |
| capinvest-government-us | [US Government](https://data.gov) data connector | pip install capinvest-us-government | None |
| capinvest-nasdaq | [Nasdaq Data Link](https://data.nasdaq.com/) connector | pip install capinvest-nasdaq | None / Free |
| capinvest-seeking-alpha | [Seeking Alpha](https://seekingalpha.com/) data connector | pip install capinvest-seeking-alpha | None |
| capinvest-stockgrid | [Stockgrid](https://stockgrid.io) data connector | pip install capinvest-stockgrid | None |
| capinvest-tmx | [TMX](https://money.tmx.com) data connector | pip install capinvest-tmx | None |
| capinvest-tradier | [Tradier](https://tradier.com) data connector | pip install capinvest-tradier | None |
| capinvest-wsj | [Wall Street Journal](https://www.wsj.com/) data connector | pip install capinvest-wsj | None |
To install extensions that expand the core functionalities specify the extension name or use `all` to install all.

```bash
# Install a single extension, e.g. capinvest-charting and yahoo finance
pip install capinvest[charting]
pip install capinvest-yfinance
```

Alternatively, you can install all extensions at once.

```bash
pip install capinvest[all]
```
 
## Python

```python
>>> from capinvest import obb
>>> output = obb.equity.price.historical("AAPL")
>>> df = output.to_dataframe()
>>> df.head()
              open    high     low  ...  change_percent             label  change_over_time
date                                ...
2022-09-19  149.31  154.56  149.10  ...         3.46000  September 19, 22          0.034600
2022-09-20  153.40  158.08  153.08  ...         2.28000  September 20, 22          0.022800
2022-09-21  157.34  158.74  153.60  ...        -2.30000  September 21, 22         -0.023000
2022-09-22  152.38  154.47  150.91  ...         0.23625  September 22, 22          0.002363
2022-09-23  151.19  151.47  148.56  ...        -0.50268  September 23, 22         -0.005027

[5 rows x 12 columns]
```

## API keys

To fully leverage the capinvest Platform you need to get some API keys to connect with data providers.  

###  Runtime

```python
>>> from capinvest import obb
>>> obb.user.credentials.fmp_api_key = "REPLACE_ME"
>>> obb.user.credentials.polygon_api_key = "REPLACE_ME"

>>> # Persist changes in ~/.capinvest_platform/user_settings.json
>>> obb.account.save()
```

###  Local file

You can specify the keys directly in the `~/.capinvest/user_settings.json` file.

Populate this file with the following template and replace the values with your keys:

```json
{
  "credentials": {
    "fmp_api_key": "REPLACE_ME",
    "polygon_api_key": "REPLACE_ME",
    "benzinga_api_key": "REPLACE_ME",
    "fred_api_key": "REPLACE_ME"
  }
}
```

## REST API

The capinvest Platform comes with a ready to use REST API built with FastAPI. Start the application using this command:

```bash
uvicorn capinvest_core.api.rest_api:app --host 0.0.0.0 --port 8000 --reload
```

API documentation is found under "/docs", from the root of the server address, and is viewable in any browser supporting HTTP over localhost, such as Chrome.

Check `capinvest-core` [README](https://pypi.org/project/capinvest-core/) for additional info.

## Install for development

To develop the capinvest Platform you need to have the following:

- Git
- Python 3.9 or higher
- Virtual Environment with `poetry` installed
  - To install these packages activate your virtual environment and run `pip install poetry toml`

How to install the platform in editable mode?

  1. Activate your virtual environment
  1. Navigate into the `capinvest_platform` folder
  1. Run `python dev_install.py` to install the packages in editable mode
