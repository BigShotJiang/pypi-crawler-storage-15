# -*- coding: utf-8 -*-

from logging_loki.handlers import LokiHandler, LokiQueueHandler

__all__ = ["LokiHandler", "LokiQueueHandler"]
__version__ = "0.3.1"
name = "logging_loki"
