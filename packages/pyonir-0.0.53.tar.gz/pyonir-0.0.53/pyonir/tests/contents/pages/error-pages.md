@filter.md:- content
title: Error pages
menu.parent: /demos
===

- [demo 404 Not Found Error Page](/some-page)
- [demo 401 Authorization Error Page](/protected-page)
- Serve static assets from the frontend `static` directory
  - ![Testing static image](/static/city-gemini.png)