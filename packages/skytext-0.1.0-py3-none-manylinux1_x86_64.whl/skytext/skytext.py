import sys
from typing import Optional, Tuple

# RGB = Tuple[int, int, int]

def rgb_to_ansi(rgb, bg=False):
    if rgb is None:
        return ""
    r, g, b = rgb
    code = 48 if bg else 38
    return "\x1b[%d;2;%d;%d;%dm" % (code, r, g, b)

def style_code(style):
    codes = {
        "bold": "\x1b[1m",
        "dim": "\x1b[2m",
        "italic": "\x1b[3m",
        "underline": "\x1b[4m",
        "blink": "\x1b[5m",
        "reverse": "\x1b[7m",
        "bright": "\x1b[1m",
        "reset_all": "\x1b[0m",
    }
    return codes.get(style.lower(), "") if style else ""

def cprint(text, fg=None, bg=None, style=None, end="\n"):
    fore = rgb_to_ansi(fg)
    back = rgb_to_ansi(bg, bg=True)
    sty = style_code(style)
    reset = "\x1b[0m" if fore or back or sty else ""
    sys.stdout.write(sty + fore + back + text + reset + end)
    sys.stdout.flush()