import time
import sys

from .skytext import cprint
from typing import Tuple

RGB = Tuple[int, int, int]

def print_animated(text, color=(255, 255, 255), speed=0.03):
    """Classic typewriter effect"""
    for char in text:
        cprint(char, fg=color, end="")
        time.sleep(speed)
    print()