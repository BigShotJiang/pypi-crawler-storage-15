from typing import Tuple

RGB = Tuple[int, int, int]

RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)
CYAN = (0, 255, 255)
MAGENTA = (255, 0, 255)
WHITE = (255, 255, 255)
ORANGE = (255, 165, 0)

SUCCESS = GREEN
ERROR = RED
WARNING = YELLOW
INFO = CYAN