from __future__ import annotations
from .skytext import cprint
from typing import Tuple
from time import sleep

RGB = Tuple[int, int, int]

def _lerp(a, b, t):
    return int(a + (b - a) * t)

def print_gradient(text, start_color, end_color):
    """Smooth gradient from start_color → end_color"""
    if not text:
        return
    for i, char in enumerate(text):
        factor = i / max(len(text) - 1, 1)
        r = _lerp(start_color[0], end_color[0], factor)
        g = _lerp(start_color[1], end_color[1], factor)
        b = _lerp(start_color[2], end_color[2], factor)
        cprint(char, fg=(r, g, b), end="")
    print()

def print_rainbow(text):
    """Classic rainbow typing animation"""
    import colorsys
    for i, char in enumerate(text):
        hue = (i * 8) % 360 / 360.0
        r, g, b = colorsys.hsv_to_rgb(hue, 1.0, 1.0)
        cprint(char, fg=(int(r*255), int(g*255), int(b*255)), end="")
    print()