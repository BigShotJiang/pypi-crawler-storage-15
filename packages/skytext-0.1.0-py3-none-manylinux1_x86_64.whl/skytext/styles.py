from .skytext import cprint
from .constants import SUCCESS, ERROR, WARNING, INFO

def success(text, **kwargs):
    cprint(text, fg=SUCCESS, style="bold", **kwargs)

def error(text, **kwargs):
    cprint(text, fg=ERROR, style="bold", **kwargs)

def warning(text, **kwargs):
    cprint(text, fg=WARNING, style="bold", **kwargs)

def info(text, **kwargs):
    cprint(text, fg=INFO, style="bright", **kwargs)

def title(text, **kwargs):
    cprint(text, fg=(0, 255, 255), style="bold", **kwargs)