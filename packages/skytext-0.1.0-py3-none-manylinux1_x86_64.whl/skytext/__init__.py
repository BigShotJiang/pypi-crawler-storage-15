from colorama import init
init(autoreset=True)

from .animated import print_animated
from .gradient import print_gradient, print_rainbow
from .styles import success, error, warning, info, title
from .skytext import cprint as print_color

__all__ = [
    "print_animated",
    "print_gradient",
    "print_rainbow",
    "print_color",
    "success",
    "error",
    "warning",
    "info",
    "title",
]