"""Package to train autoencoders using FCGR"""

import importlib.metadata
version = importlib.metadata.version("panspace")