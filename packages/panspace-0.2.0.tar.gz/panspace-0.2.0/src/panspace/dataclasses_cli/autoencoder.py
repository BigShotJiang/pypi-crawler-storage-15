from enum import Enum

class Autoencoder(str, Enum):
    AutoencoderFCGR="AutoencoderFCGR"
