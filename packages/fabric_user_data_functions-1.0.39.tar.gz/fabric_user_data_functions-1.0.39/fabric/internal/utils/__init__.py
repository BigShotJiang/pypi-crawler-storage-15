"""You can ignore this module and any files within it. It is used to help set up your User Data Functions.
"""

# flake8: noqa: F401
from .docstring_parser import extract_summary_description
from .spec_utils import get_multipart_content