# Fabric User Data Functions Python Library

## Introduction

This project contains the necessary bindings and middleware we can register on a python function in order to receive fabric data from our worker extension. 

## Suggestions / Issues

If you have any suggestions or issues, please report them here: https://community.fabric.microsoft.com/t5/Issues/idb-p/Issues