import os
from setuptools import setup, find_packages

# Read version from __version__.py
here = os.path.abspath(os.path.dirname(__file__))
version = {}
with open(os.path.join(here, "src", "WhisperLibrary", "__version__.py"), encoding="utf8") as f:
    exec(f.read(), version)

# Read README.md as long description
with open(os.path.join(here, "README.md"), encoding="utf8") as f:
    long_description = f.read()

setup(
    name="robotframework-whisperlibrary",
    version=version["__version__"],
    description="Robot Framework library for audio transcription using faster-whisper.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Jozsef Roka",
    license="MIT",  # Set your license here (e.g. "MIT", "Apache-2.0", etc.)
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    install_requires=[
        "faster-whisper",
        "robotframework",
    ],
    include_package_data=True,
    classifiers=[
        "Framework :: Robot Framework",
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License"
    ],
    project_urls={
        "Source": "https://github.com/rokajozsef/robotframework-whisperlibrary",
        "Tracker": "https://github.com/rokajozsef/robotframework-whisperlibrary/issues",
    },
)
