from .keywords import WhisperLibrary
from .__version__ import __version__

WhisperLibrary.__version__ = __version__