from faster_whisper import WhisperModel
from robot.api import logger
from robot.utils.asserts import fail

class WhisperLibrary:
    def __init__(self):
        self.model = None
        self.language = None
        self.last_result = None
        self.last_info = None

    def initialize_whisper_model(self, model_size="base", device="cpu"):
        """
        Initializes the Whisper model for transcription.

        :param model_size: Size of the model to load, e.g. "base", "small", "large". Default is "base".
        :param device: Device to run the model on, e.g. "cpu" or "cuda". Default is "cpu".

        Example:
        | Initialize Whisper Model | base | cuda |
        """
        self.model = WhisperModel(model_size, device=device)

    def set_transcription_language(self, language):
        """
        Sets the language for transcription.

        :param language: ISO 639-1 language code (e.g. 'en', 'hu', 'de').
            If None or not set, the model will try to auto-detect the language.

        Example:
        | Set Transcription Language | hu |
        """
        self.language = language

    def transcribe_file(self, file_path):
        """
        Transcribes the audio file at the given path.

        :param file_path: Path to the audio file to transcribe.

        Stores the last transcription text and info internally for retrieval.

        Example:
        | Transcribe File | path/to/file.wav |
        """
        if not self.model:
            fail("Model is not initialized. Call `Initialize Whisper Model` first.")

        segments, info = self.model.transcribe(file_path, language=self.language)
        self.last_result = "".join([segment.text for segment in segments])
        self.last_info = info
        return self.last_result

    def get_transcription_text(self):
        """
        Returns the raw transcription text with leading/trailing whitespace removed.

        :return: Recognized text from the last transcribed audio.

        Example:
        | ${text}= | Get Transcription Text |
        """
        if not self.last_result:
            fail("No transcription available. Run `Transcribe File` first.")
        return self.last_result.strip()

    def transcription_should_contain(self, expected):
        """
        Verifies that the expected substring is present in the last transcription text.

        :param expected: The substring expected to be found within the last transcription result.

        Raises an AssertionError if no transcription is available or if the expected substring
        is not found in the transcription text.

        Example:
        | Should Contain Transcription Text | red button |
        """
        if not self.last_result:
            fail("No transcription available. Run `Transcribe File` first.")
        if expected not in self.last_result:
            fail(f"Expected '{expected}' not found in transcription.")

    def get_transcription_info(self):
        """
        Returns a dictionary with metadata about the last transcription.

        :return: Dictionary containing:
            - language: Detected language code (ISO 639-1)
            - confidence: Confidence of language detection (float)
            - duration: Duration of the audio file in seconds (float)

        Example:
        | ${info}= | Get Transcription Info |
        | Log To Console | Language: ${info['language']} |
        """
        if not self.last_info:
            fail("No transcription info available. Run `Transcribe File` first.")

        language = self.last_info.language
        confidence = self.last_info.language_probability
        duration = self.last_info.duration

        info = {
            "language": self.last_info.language,
            "confidence": round(self.last_info.language_probability, 2),
            "duration": round(self.last_info.duration, 2)
        }

        logger.info(f"[WhisperLibrary] Transcription info: {info}")
        return info
