# Robot Framework WhisperLibrary

**WhisperLibrary** is a [Robot Framework](https://robotframework.org/) test library for transcribing audio files using [faster-whisper](https://github.com/SYSTRAN/faster-whisper), a fast and accurate implementation of OpenAI's Whisper model.

It enables easy integration of speech recognition into your automated Robot Framework tests with just a few intuitive keywords.

---

## 📦 Installation

Install WhisperLibrary directly from PyPI:

```bash
pip install robotframework-whisperlibrary
```
This will install WhisperLibrary along with all dependencies specified in requirements.txt.

To upgrade to the latest version:

```bash
pip install --upgrade robotframework-whisperlibrary
```

⚠️ If you plan to use a device other than CPU (e.g. GPU/CUDA), additional dependencies such as ctranslate2 and torch may be required.
Refer to the [faster-whisper requirements](https://github.com/SYSTRAN/faster-whisper#requirements) for more information.

## ✅ Usage Example

Create a Robot Framework test file like this:

```robot

*** Settings ***
Library    WhisperLibrary

*** Test Cases ***
Test With Hu Sound
    Initialize Whisper Model    base
    Transcribe File    ${EXECDIR}${/}sound${/}red_button_hu.wav
    ${text}=    Get Transcription Text
    Log To Console    Transcripted text: ${text}
    ${info}=    Get Transcription Info
    Should Be Equal As Strings    ${info['language']}    hu

Test With En Sound
    Initialize Whisper Model    base
    Set Transcription Language    en
    Transcribe File    ${EXECDIR}${/}sound${/}red_button_en.wav
    ${text}=    Get Transcription Text
    ${info}=    Get Transcription Info
    Should Be Equal As Strings    ${text}    In that case, press the red button and rest in peace.

Transcribe Nonexistent File Fails
    Initialize Whisper Model    base
    Run Keyword And Expect Error    *No such file or directory*    Transcribe File    not_a_real_file.wav

Get Text Without Transcription Fails
    Initialize Whisper Model    base
    Run Keyword And Expect Error    *No transcription available*    Get Transcription Text
```

## 🧪 Running Tests

From the project root, run tests located in the tests/ folder:

```bash
cd tests
python -m robot whisperlib_demo.robot
```

## 📁 Project Structure

```
project-root/
├── setup.py
├── requirements.txt
├── src/
│   └── WhisperLibrary/
│       ├── __init__.py
│       ├── __version__.py
│       └── keywords.py
└── tests/
    ├── sound/
    │   ├── red_button_hu.wav
    │   └── red_button_en.wav
    └── whisperlib_demo.robot
```

## 🤝 Contributing

This is my first open-source Python project, created as part of my learning journey into Python development and Robot Framework library creation — with the support of ChatGPT.

I'm happy to receive feedback, bug reports, and ideas for improvement!

### Want to contribute?

- Feel free to fork the project and submit a pull request.
- Open an issue if you have suggestions or encounter a problem.
- You can reach me via GitHub or by opening a discussion in this repository.

## 📬 Author

József Róka
GitHub: [@rokajozsef](https://github.com/rokajozsef)

## 📦 Repository

You can find the source code and contribute here: [https://github.com/rokajozsef/robotframework-whisperlibrary](https://github.com/rokajozsef/robotframework-whisperlibrary)

## ❤️ Acknowledgements

This library was built from scratch as a personal learning project with the help of ChatGPT, and inspired by the excellent work behind faster-whisper and the Robot Framework ecosystem.

## 🛡 License

This project is licensed under the MIT License – see the LICENSE file for details.