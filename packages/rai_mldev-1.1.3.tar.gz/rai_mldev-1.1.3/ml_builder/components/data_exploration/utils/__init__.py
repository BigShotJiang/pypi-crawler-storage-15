"""
Data exploration utilities package.

This package contains utility functions for data exploration and analysis.
"""