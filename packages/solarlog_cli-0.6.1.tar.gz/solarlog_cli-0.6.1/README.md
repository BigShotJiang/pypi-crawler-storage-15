# Solar-Log-Cli
Python library to access a Solar-Log JSON interface.

The library is partially based on the sunwatcher library (https://bitbucket.org/Lavode/sunwatcher/src/master/). The additional datapoints are implemented according to the (unofficial) documentation here: https://github.com/iobroker-community-adapters/ioBroker.solarlog/blob/master/docs/solarlog_dataobjects.md
