class API:
    api_12306 = "https://mobile.12306.cn/wxxcx/wechat/main/travelServiceQrcodeTrainInfo"
    api_rail_re = "https://api.rail.re/"
    api_xiaguanzhan = "http://www.xiaguanzhan.com/uploadfiles/"
    api_station_screen = "https://apis.uctb.cn/api/12306?city="