"""Entry point for running MarkDeck as a module."""

from markdeck.cli import main

if __name__ == '__main__':
    main()
