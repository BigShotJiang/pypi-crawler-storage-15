from . import web_berest_data_import_capnp

__all__ = [
    "web_berest_data_import_capnp",
]
