"""This is an automatically generated stub for `java.capnp`."""

import os
import capnp

capnp.remove_import_hook()
here = os.path.dirname(os.path.abspath(__file__))
module_file = os.path.abspath(
    os.path.join(here, "../../zalfmas_capnp_schemas/capnp/java.capnp")
)
import_path = [
    here,
    os.path.abspath(os.path.join(here, "../../zalfmas_capnp_schemas")),
    os.path.abspath(os.path.join(here, "../../zalfmas_capnp_schemas/capnp")),
]
