.. _api_reference:

API reference
=============

.. toctree::
   :maxdepth: 2
   :glob:


   api_reference/*

GeomAI API reference
====================

.. toctree::
   :maxdepth: 2
   :glob:

   api_reference/geomai/*
