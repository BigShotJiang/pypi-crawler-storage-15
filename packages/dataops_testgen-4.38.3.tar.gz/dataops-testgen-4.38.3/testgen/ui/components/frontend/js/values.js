const timezones = Intl.supportedValuesOf('timeZone');

export { timezones };
