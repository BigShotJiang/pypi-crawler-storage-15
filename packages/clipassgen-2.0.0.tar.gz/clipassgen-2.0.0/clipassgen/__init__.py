# Copyright © 2025, Alexander Suvorov
"""
clipassgen (Console Smart Password Generator CLI) - Command-line smart password generator for
deterministic password generation - same secret always produces the same password.
"""
__version__ = '2.0.0'
