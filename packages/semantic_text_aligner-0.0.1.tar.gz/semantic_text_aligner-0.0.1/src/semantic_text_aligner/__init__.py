"""Public package exports."""

from .core import align_string_lists

__all__ = ["align_string_lists"]
