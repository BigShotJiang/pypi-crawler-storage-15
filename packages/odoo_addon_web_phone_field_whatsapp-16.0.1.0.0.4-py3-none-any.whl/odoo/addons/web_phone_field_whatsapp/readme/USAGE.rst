To use this new functionality, simply go to a char field with the phone widget,
enter the phone number, and execute the WhatsApp Web option.
