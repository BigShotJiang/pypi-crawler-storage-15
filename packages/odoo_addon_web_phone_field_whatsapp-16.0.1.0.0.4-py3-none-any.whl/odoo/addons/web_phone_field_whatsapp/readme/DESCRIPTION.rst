This module adds a shortcut functionality to WhatsApp Web or the WhatsApp application in the phone widget.



