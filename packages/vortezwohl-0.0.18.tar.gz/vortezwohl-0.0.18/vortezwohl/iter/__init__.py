from .iter import batched, sliding_window
