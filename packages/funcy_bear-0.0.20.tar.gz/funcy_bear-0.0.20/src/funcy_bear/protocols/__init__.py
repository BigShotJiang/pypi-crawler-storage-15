"""Protocols for type-checking and structural sub typing."""
