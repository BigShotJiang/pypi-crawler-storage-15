"""Runtime type inference helpers."""
