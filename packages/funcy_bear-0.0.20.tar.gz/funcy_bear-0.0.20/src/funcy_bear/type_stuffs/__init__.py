"""Type-related helpers for conversion, inference, and validation."""
