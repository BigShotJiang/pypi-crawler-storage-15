import io
import zipfile
import logging
import httpx
import certifi
import pyarrow as pa
import pyarrow.csv as pv
from httpx_curl_cffi import CurlTransport
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)



# Helper util, convert col to date-time

# Helper util? Monthly/Annual FF factors splitting up...




# Define the expected types for the Fama-French data
FF_SCHEMA = pa.schema([
    ('DATE', pa.string()), 
    ('Mkt-RF', pa.float64()),
    ('SMB', pa.float64()),
    ('HML', pa.float64()),
    ('RF', pa.float64())
])

def skip_invalid_rows(row):
    """
    Handler for pyarrow to skip rows that don't match the schema.
    Returns 'skip' to discard the row.
    """
    return "skip"

class HttpxClient:
    """httpx client with cffi-curl for impersonation."""

    def __init__(self, timeout: float = 30.0):
        """Initializes the HTTP client."""
        
        # Configure the CurlTransport for impersonation
        fast_transport = CurlTransport(
            impersonate="chrome",
            default_headers=True,
            verify=certifi.where()
        )
        
        # Initialize httpx client
        self._client = httpx.Client(
            transport=fast_transport,
            timeout=timeout,
            follow_redirects=True,
        )

    def close(self) -> None:
        """Close the client."""
        print("DEBUG: HttpxClient (closing connection)")
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Close on exit."""
        self.close()

    def download_bytes(self, url: str) -> bytes:
        """Download binary data from URL."""
        try:
            logger.info(f"Connecting to {url}...")
            response = self._client.get(url)
            response.raise_for_status()
            return response.content
        except httpx.HTTPStatusError as e:
            logger.error(f"HTTP error {e.response.status_code} for {url}")
            raise
        except httpx.RequestError as e:
            logger.error(f"Network error for {url}: {e}")
            raise

    def check_url(self, url: str) -> bool:
        """Check if a URL is accessible (Returns True if 200 OK)."""
        try:
            response = self._client.head(url, timeout=5.0)
            if response.status_code == 200:
                print("DEBUG: HEAD response 200")
                return True
            # Fallback to GET if HEAD fails/is blocked
            print("DEBUG: Falling back to GET")
            response = self._client.get(url, timeout=5.0)
            return response.status_code == 200
        except Exception:
            return False


def read_zipped_csv_with_httpx(url: str):
    """
    Downloads a zipped CSV from a URL and reads it into a pyarrow Table.
    """
    with HttpxClient() as client:
        print(f"Downloading data from {url}...")
        zip_bytes = client.download_bytes(url)
        print("Download complete. Processing ZIP file...")

    with zipfile.ZipFile(io.BytesIO(zip_bytes), 'r') as z:
        csv_filename = z.namelist()[0] # single csv in the .zip
        
        print(f"  - Extracting '{csv_filename}' from the archive...")
        
        with z.open(csv_filename) as csv_file_handle:
            read_options = pv.ReadOptions(
                # TODO: data for monthly should start at 192607, test 
                skip_rows=5,  # F-F data usually has 3 header lines, new line, header. 
             #   autogenerate_column_names=True,
                column_names=["DATE", "Mkt-RF", "SMB", "HML", "RF"]
            )
            
            parse_options = pv.ParseOptions(
                delimiter=",",
                invalid_row_handler=skip_invalid_rows,
                ignore_empty_lines=True,
                # Also good to tell it what the null string is, usually a blank or "NA"
            #    null_values=["", "NA"], # -999
            )
            
            convert_options = pv.ConvertOptions(
                #include_columns=None, # Read all
                #include_missing_columns=False,
                #column_types=FF_SCHEMA,
                timestamp_parsers=["%Y%m.0", "%Y%m", "%y", "%Y", "%Y%M.0",
                                   '%Y%m.0'], # There's eg 19280101 and 1928 (annual)
                #strings_can_be_null=True,
            )
            table = pv.read_csv(
                csv_file_handle,
                read_options=read_options, 
                parse_options=parse_options,
                convert_options=convert_options,
            )

            col_names = ["DATE", "Mkt-RF", "SMB", "HML", "RF"]
            final_table = table.rename_columns(col_names)


            # might just split lines on the annual line, if the model+freq isn't
            # annual, drop the annual (cache it), if it is, drop the monthly?

            return final_table

# Simple .to_pd wrapper

def _to_pd(table):
    """
    Wrapper around pyarrow's to_pandas method. 
    Checks if user has pandas installed; otherwise returns a dict.
    """
    try:
        # Attempt to import pandas to ensure it is installed
        print("DEBUG: attempting to import pd...")
        import pandas as pd
        
        return table.to_pandas()
        
    except ImportError:
        print("Pandas not installed, falling back to dictionary for printing...")
        return table.to_pydict()


# --- Example Usage ---

if __name__ == "__main__":
    # Fama-French Factors URL
    csv_url = "https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/ftp/F-F_Research_Data_Factors_CSV.zip"

    try:
        arrow_table = read_zipped_csv_with_httpx(csv_url)
        
        print("\nSuccessfully created Apache Arrow Table:")
        print(f"Number of rows: {arrow_table.num_rows}")
        print(f"Number of columns: {arrow_table.num_columns}")
        
        # Display first few rows to verify
        print("\nSample Data (First 5 rows):")
        # Convert to python dict just for pretty printing the head
        print(arrow_table.slice(0, 5).to_pydict())

        # As df?
        df = _to_pd(arrow_table)
        print(df)

    except Exception as e:
        print(f"\nAn error occurred: {e}")
        logger.exception("Full traceback:")
