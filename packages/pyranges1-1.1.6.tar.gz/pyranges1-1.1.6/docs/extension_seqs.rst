
Seqs: sequences
---------------

Utilities to process nucleotide or protein sequences.

.. automodule:: pyranges.seqs
    :members:
    :imported-members:

