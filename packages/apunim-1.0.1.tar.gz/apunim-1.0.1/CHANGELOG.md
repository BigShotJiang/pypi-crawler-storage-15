# What's new

## 1.0.1 (5/12/2025)
- Added support in ApunimResult to indicate number of observations per factor

## 1.0.0 (24/11/2025)

- Initial release