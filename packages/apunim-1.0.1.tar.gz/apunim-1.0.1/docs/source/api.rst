
Module Documentation
====================

This library offers two main functions: `dfu` which estimates polarization,
and `aposteriori_unimodality`, which attributes polarization to annotator 
groups.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

.. automodule:: apunim
   :members:
   :undoc-members:
   :show-inheritance: