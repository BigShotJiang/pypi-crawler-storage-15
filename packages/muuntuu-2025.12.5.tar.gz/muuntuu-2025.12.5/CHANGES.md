# Changes

2025.12.5
:    Added ensure_ascii to json dump options with default value of false.

2025.9.14
:    Added force option and some other output related options (like offsets and width).

2025.7.20
:    Ensured POSIX conforming trailing newline on write.

2025.7.13
:    Fixed python 3.9 compatibility (union typing) and added coverage link.

2025.7.12
:    Initial release on pypi.
