"""Admin integration components for DjangoForgeAI"""

