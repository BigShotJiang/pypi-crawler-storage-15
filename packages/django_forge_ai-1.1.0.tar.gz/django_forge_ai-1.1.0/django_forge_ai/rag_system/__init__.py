"""RAG (Retrieval Augmented Generation) system components"""

