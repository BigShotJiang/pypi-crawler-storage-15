# SPDX-FileCopyrightText: 2023-present Tobias Kunze
# SPDX-License-Identifier: AGPL-3.0-only WITH LicenseRef-Pretalx-AGPL-3.0-Terms

"""This command supersedes the Django-inbuilt runserver command.

It runs the local frontend server, if node is installed and the setting
is set.
"""

from pathlib import Path

from django.conf import settings
from django.core.management.commands.runserver import Command as Parent


class Command(Parent):
    def handle(self, *args, **options):
        if not settings.VITE_DEV_MODE:
            self.stdout.write(
                self.style.WARNING(
                    "Executing normal runserver command. To run the frontend server, set VITE_DEV_MODE=True"
                )
            )
            super().handle(*args, **options)
            return

        # Start the vite server in the background
        from subprocess import Popen

        # run "npm start" in the frontend directory
        frontend_dir = (
            Path(__file__).parent.parent.parent.parent / "frontend/schedule-editor"
        )
        vite_server = Popen(["npm", "start"], cwd=frontend_dir)

        try:
            super().handle(*args, **options)
        finally:
            if settings.VITE_DEV_MODE:
                vite_server.kill()
