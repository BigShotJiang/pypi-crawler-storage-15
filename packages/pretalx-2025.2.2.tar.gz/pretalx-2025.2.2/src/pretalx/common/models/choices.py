# SPDX-FileCopyrightText: 2017-present Tobias Kunze
# SPDX-License-Identifier: AGPL-3.0-only WITH LicenseRef-Pretalx-AGPL-3.0-Terms


class Choices:
    """Helper class to make choices available as class variables.

    It exposes a list with valid choices and at the same time generate the
    choices tuples forthe model class.
    Usage:
        class MyChoices(Choices):
            ONE = 'one'
            TWO = 'dwa'
            valid_choices = [ONE, TWO]

        class MyModel(PretalxModel):
            variant = models.CharField(
                max_length=MyChoices.get_max_length(),
                choices=MyChoices.get_choices(),
            )
    """

    valid_choices = []

    @classmethod
    def get_choices(cls):
        return cls.valid_choices

    @classmethod
    def get_max_length(cls):
        return max(len(val) for val, _ in cls.valid_choices)
