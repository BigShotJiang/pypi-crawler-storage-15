// File mock for images and other assets
module.exports = 'test-file-stub'; 