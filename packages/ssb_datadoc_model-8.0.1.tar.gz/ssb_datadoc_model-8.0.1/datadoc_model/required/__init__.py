"""Module where model fields which are required must be provided on model instantiation.

This is useful for validating finished data structures.
"""
