# tgzr.shell
tgzr workstation runtime
