# `ryo3-uuid`

Wrapper around the `uuid` crate for Python.

REF:

- [crates.io](https://crates.io/crates/uuid)
- [docs.rs](https://docs.rs/uuid)
