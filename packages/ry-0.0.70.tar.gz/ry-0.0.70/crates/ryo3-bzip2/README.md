# `ryo3-bzip2`

ryo3-wrapper for `bzip2` crate

[//]: # "<GENERATED>"

## Ref:

- docs.rs: [https://docs.rs/bzip2](https://docs.rs/bzip2)
- crates: [https://crates.io/crates/bzip2](https://crates.io/crates/bzip2)

[//]: # "</GENERATED>"
