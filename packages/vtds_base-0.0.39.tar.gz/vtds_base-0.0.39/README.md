# vTDS Base Python Library
This Python library implements base utility functions for Python that are used by the Virtual Test Development System (vTDS) suite of tools.
