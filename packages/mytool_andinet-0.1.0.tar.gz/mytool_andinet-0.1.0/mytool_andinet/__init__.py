# mytool/__init__.py

from .core import greet, add

__all__ = ["greet", "add"]
