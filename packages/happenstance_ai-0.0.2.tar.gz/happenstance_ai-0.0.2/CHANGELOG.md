# Changelog

## 0.0.2 (2025-12-04)

Full Changelog: [v0.0.1...v0.0.2](https://github.com/happenstance-ai/happenstance-ai-api-python/compare/v0.0.1...v0.0.2)

### Chores

* sync repo ([00c00c3](https://github.com/happenstance-ai/happenstance-ai-api-python/commit/00c00c3328b5aa1a0def5284b61034c231d39e9c))
* update SDK settings ([1778679](https://github.com/happenstance-ai/happenstance-ai-api-python/commit/1778679005ea43ec7847b045deed9049fe44c91c))
* update SDK settings ([d29c7b5](https://github.com/happenstance-ai/happenstance-ai-api-python/commit/d29c7b5cb4a506c01c33c97a91d574ffe4eb9e7b))
* update SDK settings ([cdde821](https://github.com/happenstance-ai/happenstance-ai-api-python/commit/cdde821d10831322aeac1fd44fce67272b23b2de))
