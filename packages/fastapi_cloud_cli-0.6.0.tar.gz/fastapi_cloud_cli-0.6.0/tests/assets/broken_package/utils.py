def get_message() -> str:
    return "Hello World!"
