"""
ReasonForge Analysis - Advanced Calculus and Differential Equations

MCP server providing 17 tools for differential equations, transforms, and analysis.
"""

__version__ = "0.1.0"
