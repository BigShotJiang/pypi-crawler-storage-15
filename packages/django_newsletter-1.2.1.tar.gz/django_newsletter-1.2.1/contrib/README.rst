Assorted contributions
======================

Various contributions which are not part of the official Python package but
might be useful to other users nonetheless.
