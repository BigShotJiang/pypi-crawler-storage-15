"""Plugin module exports."""

from .interfaces import (
    AudioFrameData,
    AudioResult,
    FaceResult,
    LicensePlateResult,
    MotionResult,
    ObjectResult,
    VideoFrameData,
)
from .types import (
    APIEventType,
    AudioDetectionPluginResponse,
    AudioMetadata,
    CuiPlugin,
    ImageMetadata,
    Listener,
    MotionDetectionPluginResponse,
    ObjectDetectionPluginResponse,
    PluginAPI,
    PluginContract,
    PluginInfo,
)

__all__ = [
    # Event types
    "APIEventType",
    "Listener",
    # Interfaces (detection results)
    "AudioFrameData",
    "AudioResult",
    "FaceResult",
    "LicensePlateResult",
    "MotionResult",
    "ObjectResult",
    "VideoFrameData",
    # Types
    "ImageMetadata",
    "AudioMetadata",
    "MotionDetectionPluginResponse",
    "ObjectDetectionPluginResponse",
    "AudioDetectionPluginResponse",
    "PluginAPI",
    "CuiPlugin",
    "PluginContract",
    "PluginInfo",
]
