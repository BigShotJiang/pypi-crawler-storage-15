from collections.abc import Awaitable, Callable, Coroutine
from typing import Any

# Listener types
Listener = Callable[[], None] | Callable[[], Awaitable[None]]

# Callback types
Callback = Callable[..., Any] | Callable[..., Coroutine[Any, Any, Any]]
