from .core import main as run

__all__ = ["run"]
