# @bovine/muck-out-types

Automatically generated type objects.

* [muck_out](https://bovine.codeberg.page/muck_out/)
* [published version on codeberg](https://codeberg.org/bovine/-/packages/npm/@bovine%252Fmuck-out-types)

## Publishing

```bash
npm run generate
npm publish
```

## docs

```bash
npm run docs
```