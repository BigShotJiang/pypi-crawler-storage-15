# `OpenAI Responses model`

::: agents.models.openai_responses
