# `Span data`

::: agents.tracing.span_data
