# `Strict Schema`

::: agents.strict_schema
