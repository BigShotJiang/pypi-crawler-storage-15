# `RedisSession`

::: agents.extensions.memory.redis_session.RedisSession