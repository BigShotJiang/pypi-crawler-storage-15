# setting

# version
__version__ = "1.4.0"
# author
__author__ = "Sina Gilassi"
# description
__description__ = "A Python interface for connecting PyThermoDB to other applications and integrating thermodynamic data."
