import pandas as pd
import os
def stat_df(df):
    stats = []
    for col in df.columns:
        stats.append((col, df[col].nunique(),df[col].isnull().sum()*100/df.shape[0],df[col].min(),df[col].max(),
                    df[col].value_counts(normalize=True,dropna=False).values[0]*100,df[col].dtype))
    stats_df = pd.DataFrame(stats, columns=['特征','唯一数数量','缺失值占比','最小值','最大值','最多数占比','类型'])
    stats_df.sort_values('缺失值占比',ascending=False)
    return stats_df

def write(filename):
    doc = '''
import pandas as pd
import lightgbm as lgb
import xgboost as xgb
from catboost import CatBoostClassifier
from sklearn.model_selection import KFold
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import StratifiedKFold
import numpy as np

def cv_model_1(train_x,train_y,test_x,clf_name):
    flods=7
    seeds=[2122]
    train=np.zeros(train_x.shape[0])
    test=np.zeros(test_x.shape[0])
    trn_auc_scores=[]
    val_auc_scores=[]
    test_list=[]

    for seed in seeds:
        kf=StratifiedKFold(n_splits=flods,random_state=seed,shuffle=True)
        for i,(train_index,val_index) in enumerate(kf.split(train_x,train_y)):
            trn_x,trn_y,val_x,val_y=train_x.iloc[train_index],train_y[train_index],train_x.iloc[val_index],train_y.iloc[val_index]
            if clf_name=='lgb':
                train_matrix=lgb.Dataset(trn_x,label=trn_y)
                val_matrix=lgb.Dataset(val_x,label=val_y)
                params={
                    'boosting_type': 'gbdt',
                    'objective':'binary',
                    'metric':'auc',
                    'max_depth':4,
                    'num_leaves':24,
                    'learning_rate':0.02,
                    'feature_fraction':0.65,
                    'seed': seed,
                    'bagging_fraction':0.8,
                    'min_gain_to_split': 0.02,
                    'lambda_l2': 1,
                    'lambda_l1': 1,
                    'bagging_freq': 1,
                    'min_child_weight':5,
                    'min_data_in_leaf': 20,
                    'verbose':-1,
                    'nthread': 10,

                }
                
                callbacks=[lgb.log_evaluation(period=200),lgb.early_stopping(500)]
                model=lgb.train(params,train_matrix,8000,valid_sets=[train_matrix,val_matrix],
                               callbacks=callbacks )
                trn_pred=model.predict(trn_x,num_iteration=model.best_iteration)
                val_pred=model.predict(val_x,num_iteration=model.best_iteration)
                test_pred=model.predict(test_x,num_iteration=model.best_iteration)

            elif clf_name=='xgb':
                train_matrix=xgb.DMatrix(trn_x,label=trn_y)
                val_matrix=xgb.DMatrix(val_x,label=val_y)
                params = {
                    'booster': 'gbtree',
                    'objective': 'binary:logistic',
                    'eval_metric': 'auc',
                    'gamma': 5,
                    'min_child_weight': 1.5,
                    'max_depth': 4,
                    'lambda': 5,
                    'subsample': 0.7,
                    'colsample_bytree': 0.7,
                    'colsample_bylevel': 0.8,
                    'eta': 0.03,
                    'tree_method': 'exact',
                    'seed': seed,
                    'nthread': 36,
                    'learning_rate_decay': 0.95, 
                }
                watchlist=[(train_matrix,'train'),(val_matrix,'test')]
                model=xgb.train(params,train_matrix,num_boost_round=8000,evals=watchlist,
                                verbose_eval=200,early_stopping_rounds=500)
                trn_pred=model.predict(train_matrix,iteration_range=(0,model.best_iteration+1))
                val_pred=model.predict(val_matrix,iteration_range=(0,model.best_iteration+1))
                test_pred=model.predict(xgb.DMatrix(test_x),iteration_range=(0,model.best_iteration+1))
            else:
                params = {
                    'learning_rate': 0.02,
                    'depth': 4, 
                    'l2_leaf_reg': 5, 
                    'bootstrap_type': 'Bernoulli',
                    'early_stopping_rounds':600, 
                    'max_ctr_complexity':4,
                    'eval_metric':'AUC',
                    'random_seed': seed, 
                    'use_best_model':True,
                    'allow_writing_files': False ,
                    'loss_function': 'CrossEntropy',
                    # 'random_strength': 0.5, 
                    'grow_policy': 'Depthwise',
                    'min_data_in_leaf': 10
                    
                }
                col_cat = []
                model = CatBoostClassifier(iterations=5000 , **params)
                model.fit(trn_x,trn_y,eval_set=(val_x,val_y),cat_features=col_cat, verbose=500)
                trn_pred=model.predict_proba(trn_x)[:,1]
                val_pred=model.predict_proba(val_x)[:,1]
                test_pred=model.predict_proba(test_x)[:,1]
            trn_auc_scores.append(roc_auc_score(trn_y,trn_pred))
            val_auc_scores.append(roc_auc_score(val_y,val_pred))
            print(val_auc_scores)
            train[val_index]=val_pred
            test_list.append(test_pred)
    test=np.mean(test_list,axis=0)
    print(f"{clf_name}_scotrainre_list:", val_auc_scores)
    print(f"{clf_name}_score_mean:", np.mean(val_auc_scores))
    print(f"{clf_name}_score_std:", np.std(val_auc_scores))
    return train, test

def lgb_model_1(x_train, y_train, x_test):
    lgb_train, lgb_test = cv_model_1(x_train, y_train, x_test, "lgb")
    return lgb_train, lgb_test
def xgb_model_1(x_train, y_train, x_test):
    xgb_train, xgb_test = cv_model_1(x_train, y_train, x_test, "xgb")
    return  xgb_train, xgb_test

def cat_model_1(x_train, y_train, x_test):
    cat_train, cat_test = cv_model_1(x_train, y_train, x_test, "cat")
    return cat_train, cat_test

    '''
    with open(filename,'w') as f:
        f.write(doc)
from pathlib import Path

current_dir = Path.cwd()
function_file = os.path.join(current_dir,"function.py")
write(function_file)