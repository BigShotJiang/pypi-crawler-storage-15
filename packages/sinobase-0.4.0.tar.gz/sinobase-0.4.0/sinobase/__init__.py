"""
Sinobase - A Python utility package
"""

__version__ = "0.4.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

# Import main utilities
from . import utils

__all__ = ["utils"]
