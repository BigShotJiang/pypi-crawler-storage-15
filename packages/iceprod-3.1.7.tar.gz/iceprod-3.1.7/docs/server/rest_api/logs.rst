REST API - Logs
===============

.. automodule:: iceprod.rest.handlers.logs
