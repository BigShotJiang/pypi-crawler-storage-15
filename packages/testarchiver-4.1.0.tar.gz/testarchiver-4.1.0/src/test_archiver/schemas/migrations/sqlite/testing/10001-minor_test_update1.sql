INSERT INTO schema_updates(schema_version, applied_by)
VALUES (10001, '{applied_by}');
