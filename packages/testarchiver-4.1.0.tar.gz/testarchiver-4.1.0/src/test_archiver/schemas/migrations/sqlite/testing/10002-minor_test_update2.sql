INSERT INTO schema_updates(schema_version, applied_by)
VALUES (10002, '{applied_by}');
