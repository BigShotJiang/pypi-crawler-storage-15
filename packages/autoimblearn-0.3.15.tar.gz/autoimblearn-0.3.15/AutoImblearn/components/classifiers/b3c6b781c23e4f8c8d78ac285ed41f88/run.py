# Auto-generated wrapper for custom model b3c6b781c23e4f8c8d78ac285ed41f88
import importlib.util
import os

def get_model(**kwargs):
    """Return an instance of the user model. Modify as needed for your API."""
    files = [f for f in os.listdir(os.path.dirname(__file__)) if f.endswith('.py') and f not in ('run.py', '__init__.py')]
    if not files:
        raise RuntimeError('No model implementation found')
    target = os.path.join(os.path.dirname(__file__), files[0])
    spec = importlib.util.spec_from_file_location('classifiers.b3c6b781c23e4f8c8d78ac285ed41f88', target)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)  # type: ignore
    if hasattr(module, 'get_model'):
        return module.get_model(**kwargs)
    if hasattr(module, 'build_model'):
        return module.build_model(**kwargs)
    for attr in dir(module):
        obj = getattr(module, attr)
        if isinstance(obj, type):
            return obj(**kwargs)
    raise RuntimeError('No model factory found')
