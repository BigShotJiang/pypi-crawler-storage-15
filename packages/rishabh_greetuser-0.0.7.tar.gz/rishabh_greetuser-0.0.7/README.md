# greetuser

A simple Python package that asks for your name and greets you.

## Usage
pip install rishabh-greetuser

```python
from greetuser import greet_user

greet_user()

```
![Architecture](./docs/Images/1.png)

#Testing pipeline