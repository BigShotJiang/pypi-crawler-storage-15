# NeuroShard White Paper

This directory contains the LaTeX source and compiled PDF for the NeuroShard technical white paper.

## Building from Source

To rebuild the PDF, you need a LaTeX distribution with `pdflatex` and standard packages.

```bash
pdflatex neuroshard_whitepaper.tex
```

## Contents

- **neuroshard_whitepaper.tex**: The LaTeX source code.
- **neuroshard_whitepaper.pdf**: The compiled document.
