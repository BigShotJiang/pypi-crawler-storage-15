Simone Orsi (Camptocamp) for the original implementation.

Other contributors include:

- Guewen Baconnier (Camptocamp)
- Mykhailo Panarin (Camptocamp)
- Sébastien Alix (Camptocamp)
- Thien Vo (Trobz)
