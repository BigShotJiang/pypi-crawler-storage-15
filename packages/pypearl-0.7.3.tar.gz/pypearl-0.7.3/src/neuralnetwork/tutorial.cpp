#include "neuralnetwork.hpp"

// The following function displays how to use this library. I tried to use as many functions as possible. I also use array, 2D array and matrix interchangeably.
// Feel free to skip the intro to utility functions and data generation and go strait to the actual AI Section.
int main(){


    return 0;
}