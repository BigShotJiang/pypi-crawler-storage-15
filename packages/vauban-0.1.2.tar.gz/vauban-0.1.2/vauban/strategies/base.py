from vauban.interfaces import Strategy, AttackPrompt

__all__ = ["Strategy", "AttackPrompt"]
