This module allows to generate CHANGELOGs for repositories used within a project.
