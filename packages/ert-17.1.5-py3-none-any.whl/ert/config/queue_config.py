from __future__ import annotations

import logging
import os
import re
from abc import abstractmethod
from textwrap import dedent
from typing import (
    TYPE_CHECKING,
    Annotated,
    Any,
    Literal,
    TypeAlias,
    cast,
    overload,
)

import pydantic
from pydantic import Field, TypeAdapter, field_validator
from pydantic.dataclasses import dataclass
from pydantic_core.core_schema import ValidationInfo

from ert.base_model_context import BaseModelWithContextSupport

from ._get_num_cpu import get_num_cpu_from_data_file
from .parsing import (
    ConfigDict,
    ConfigKeys,
    ConfigValidationError,
    ConfigWarning,
    QueueSystem,
)

if TYPE_CHECKING:
    from ert.plugins import ErtRuntimePlugins

logger = logging.getLogger(__name__)

NonEmptyString = Annotated[str, pydantic.StringConstraints(min_length=1)]


def activate_script() -> str:
    if venv := os.environ.get("VIRTUAL_ENV"):
        return f"source {venv}/bin/activate"
    if conda_env := os.environ.get("CONDA_ENV"):
        return f'eval "$(conda shell.bash hook)" && conda activate {conda_env}'
    return ""


class QueueOptions(
    BaseModelWithContextSupport,
    validate_assignment=True,
    extra="forbid",
    use_enum_values=True,
    validate_default=True,
):
    name: QueueSystem
    max_running: pydantic.NonNegativeInt = 0
    submit_sleep: pydantic.NonNegativeFloat = 0.0
    num_cpu: pydantic.NonNegativeInt = 1
    realization_memory: pydantic.NonNegativeInt = Field(
        default=0,
        description=dedent("""
        Amount of memory to set aside for a forward model.

        This information is propagated to the queue system as the amount of memory
        to reserve/book for a realization to complete. It is up to the configuration
        of the queuing system how to treat this information, but usually it will
        stop more realizations being assigned to a compute node if the compute nodes
        memory is already fully booked.

        Setting this number lower than the peak memory consumption of each
        realization puts the realization at risk of being killed in an out-of-memory
        situation. Setting this number higher than needed will give longer wait
        times in the queue.

        For the local queue system, this keyword has no effect. In that scenario,
        you can use `max_running`  to choke the memory consumption.
        scheduling of compute jobs.

        `realization_memory` may be an integer value, indicating the number of bytes, or
        a string consisting of a number followed by a unit. The unit indicates the
        multiplier that is applied, and must start with one of these characters:

        * b, B: bytes
        * k, K: kilobytes (1024 bytes)
        * m, M: megabytes (1024**2 bytes)
        * g, G: gigabytes (1024**3 bytes)
        * t, T: terabytes (1024**4 bytes)
        * p, P: petabytes (1024**5 bytes)

        Spaces between the number and the unit are ignored, and so are any
        characters after the first. For example: 2g, 2G, and 2 GB all resolve
        to the same value: 2 gigabytes, equaling 2 * 1024**3 bytes.
        """),
    )
    project_code: str | None = None
    activate_script: str | None = Field(default=None, validate_default=True)

    @field_validator("activate_script", mode="before")
    @classmethod
    def inject_site_config_script(cls, v: str, info: ValidationInfo) -> str:
        # User value gets highest priority
        if isinstance(v, str):
            return v
        # Use from plugin system if user has not specified
        plugin_script = None
        if info.context:
            context = cast("ErtRuntimePlugins", info.context)
            plugin_script = (
                context.queue_options.activate_script
                if context.queue_options is not None
                else None
            )
        return plugin_script or activate_script()  # Return default value

    @field_validator("realization_memory", mode="before")
    @classmethod
    def validate_realization_memory(cls, v: Any) -> int:
        if isinstance(v, int):
            return v
        if isinstance(v, str):
            return parse_string_to_bytes(v)
        raise ValueError(f"Invalid value for realization_memory: {v}")

    @overload
    @staticmethod
    def create_queue_options(
        queue_system: QueueSystem,
        options: dict[str, Any],
        is_selected_queue_system: Literal[True],
    ) -> KnownQueueOptions: ...
    @overload
    @staticmethod
    def create_queue_options(
        queue_system: QueueSystem,
        options: dict[str, Any],
        is_selected_queue_system: Literal[False],
    ) -> KnownQueueOptions | None: ...

    @staticmethod
    def create_queue_options(
        queue_system: QueueSystem,
        options: dict[str, Any],
        is_selected_queue_system: bool,
    ) -> KnownQueueOptions | None:
        lower_case_options = {key.lower(): value for key, value in options.items()}
        try:
            if queue_system == QueueSystem.LSF:
                return LsfQueueOptions(**lower_case_options)
            elif queue_system == QueueSystem.SLURM:
                return SlurmQueueOptions(**lower_case_options)
            elif queue_system == QueueSystem.TORQUE:
                return TorqueQueueOptions(**lower_case_options)
            elif queue_system == QueueSystem.LOCAL:
                return LocalQueueOptions(**lower_case_options)
        except pydantic.ValidationError as exception:
            for error in exception.errors():
                _throw_error_or_warning(
                    f"{error['msg']}. Got input '{error['input']}'.",
                    error["input"],
                    is_selected_queue_system,
                )
            return None

    @property
    @abstractmethod
    def driver_options(self) -> dict[str, Any]:
        """Translate the queue options to the key-value API provided by each driver"""


class LocalQueueOptions(QueueOptions):
    name: Literal[QueueSystem.LOCAL] = QueueSystem.LOCAL

    @property
    def driver_options(self) -> dict[str, Any]:
        return {}


class LsfQueueOptions(QueueOptions):
    name: Literal[QueueSystem.LSF] = QueueSystem.LSF
    bhist_cmd: NonEmptyString | None = None
    bjobs_cmd: NonEmptyString | None = None
    bkill_cmd: NonEmptyString | None = None
    bsub_cmd: NonEmptyString | None = None
    exclude_host: str | None = None
    lsf_queue: NonEmptyString | None = None
    lsf_resource: str | None = None

    @property
    def driver_options(self) -> dict[str, Any]:
        driver_dict = self.model_dump(
            exclude={
                "name",
                "submit_sleep",
                "max_running",
                "num_cpu",
                "realization_memory",
            }
        )
        driver_dict["exclude_hosts"] = driver_dict.pop("exclude_host")
        driver_dict["queue_name"] = driver_dict.pop("lsf_queue")
        driver_dict["resource_requirement"] = driver_dict.pop("lsf_resource")
        return driver_dict


class TorqueQueueOptions(QueueOptions):
    name: Literal[QueueSystem.TORQUE] = QueueSystem.TORQUE
    qsub_cmd: NonEmptyString | None = None
    qstat_cmd: NonEmptyString | None = None
    qdel_cmd: NonEmptyString | None = None
    queue: NonEmptyString | None = None
    cluster_label: NonEmptyString | None = None
    job_prefix: NonEmptyString | None = None
    keep_qsub_output: bool = False

    @property
    def driver_options(self) -> dict[str, Any]:
        driver_dict = self.model_dump(
            exclude={
                "name",
                "max_running",
                "submit_sleep",
                "num_cpu",
                "realization_memory",
            }
        )
        driver_dict["queue_name"] = driver_dict.pop("queue")
        return driver_dict


class SlurmQueueOptions(QueueOptions):
    name: Literal[QueueSystem.SLURM] = QueueSystem.SLURM
    sbatch: NonEmptyString = "sbatch"
    scancel: NonEmptyString = "scancel"
    scontrol: NonEmptyString = "scontrol"
    sacct: NonEmptyString = "sacct"
    squeue: NonEmptyString = "squeue"
    exclude_host: str = ""
    include_host: str = ""
    partition: NonEmptyString | None = None  # aka queue_name
    squeue_timeout: pydantic.PositiveFloat = 2
    max_runtime: pydantic.NonNegativeFloat | None = None

    @property
    def driver_options(self) -> dict[str, Any]:
        driver_dict = self.model_dump(
            exclude={
                "name",
                "max_running",
                "submit_sleep",
                "num_cpu",
                "realization_memory",
            }
        )
        driver_dict["sbatch_cmd"] = driver_dict.pop("sbatch")
        driver_dict["scancel_cmd"] = driver_dict.pop("scancel")
        driver_dict["scontrol_cmd"] = driver_dict.pop("scontrol")
        driver_dict["sacct_cmd"] = driver_dict.pop("sacct")
        driver_dict["squeue_cmd"] = driver_dict.pop("squeue")
        driver_dict["exclude_hosts"] = driver_dict.pop("exclude_host")
        driver_dict["include_hosts"] = driver_dict.pop("include_host")
        driver_dict["queue_name"] = driver_dict.pop("partition")
        return driver_dict


KnownQueueOptions: TypeAlias = (
    LsfQueueOptions | TorqueQueueOptions | SlurmQueueOptions | LocalQueueOptions
)

KnownQueueOptionsAdapter: TypeAdapter[KnownQueueOptions] = TypeAdapter(
    Annotated[
        KnownQueueOptions,
        Field(discriminator="name"),
    ]
)


@dataclass
class QueueMemoryStringFormat:
    suffixes: list[str]

    def validate(self, mem_str_format: str | None) -> bool:
        if mem_str_format is None:
            return True
        return (
            re.match(
                r"\d+(" + "|".join(self.suffixes) + ")$",
                mem_str_format,
            )
            is not None
        )


torque_memory_usage_format: QueueMemoryStringFormat = QueueMemoryStringFormat(
    suffixes=["kb", "mb", "gb", "KB", "MB", "GB"]
)

valid_options: dict[str, list[str]] = {
    QueueSystem.LOCAL: [field.upper() for field in LocalQueueOptions.model_fields],
    QueueSystem.LSF: [field.upper() for field in LsfQueueOptions.model_fields],
    QueueSystem.SLURM: [field.upper() for field in SlurmQueueOptions.model_fields],
    QueueSystem.TORQUE: [field.upper() for field in TorqueQueueOptions.model_fields],
}


def _log_duplicated_queue_options(
    queue_config_list: list[list[str]],
    site_queue_options_dict: dict[str, Any],
) -> None:
    processed_options: dict[str, str] = {}
    for queue_system, option_name, *values in queue_config_list:
        value = values[0] if values else ""

        site_option_key = option_name.lower()
        if (
            option_name not in processed_options
            and site_option_key in site_queue_options_dict
        ):
            # We are overriding a site config option
            site_option_key = option_name.lower()
            site_value = site_queue_options_dict[site_option_key]
            logger.info(
                f"Overwriting site config setting: {site_option_key}={site_value}"
                f" with QUEUE_OPTION {queue_system.upper()} {option_name} {value}"
            )
        if (
            option_name in processed_options
            and processed_options.get(option_name) != value
        ):
            logger.info(
                f"Overwriting "
                f"QUEUE_OPTION {queue_system.upper()} {option_name.upper()}:"
                f" \n Old value: {processed_options[option_name]} \n New value: {value}"
            )
        processed_options[option_name] = value


def _raise_for_defaulted_invalid_options(queue_config_list: list[list[str]]) -> None:
    # Invalid options names with no values (i.e. defaulted) are not passed to
    # the validation system, thus we neeed to catch them expliclitly
    for queue_system, option_name, *_ in queue_config_list:
        if option_name not in valid_options[queue_system]:
            raise ConfigValidationError.with_context(
                f"Invalid QUEUE_OPTION for {queue_system}: '{option_name}'. "
                f"Valid choices are {sorted(valid_options[queue_system])}.",
                option_name,
            )


def _group_queue_options_by_queue_system(
    queue_config_list: list[list[str]],
) -> dict[QueueSystem, dict[str, str]]:
    grouped: dict[QueueSystem, dict[str, str]] = {}
    for system in QueueSystem:
        grouped[system] = {
            option_line[1]: option_line[2]
            for option_line in queue_config_list
            if option_line[0] == system
            # Empty option values are ignored, yields defaults:
            and len(option_line) > 2
        }
    return grouped


class QueueConfig(BaseModelWithContextSupport):
    max_submit: int = 1
    queue_system: QueueSystem = QueueSystem.LOCAL
    queue_options: KnownQueueOptions = pydantic.Field(
        default_factory=LocalQueueOptions, discriminator="name"
    )
    stop_long_running: bool = False
    max_runtime: int | None = None

    @staticmethod
    def _user_queue_options_from_dict(
        selected_queue_system: QueueSystem, config_dict: ConfigDict
    ) -> dict[str, Any]:
        usr_queue_options_dict = {}

        for name in QueueOptions.model_fields:
            generic_value = config_dict.get(name.upper(), None)
            if generic_value is not None:
                if name == "realization_memory" and isinstance(generic_value, str):
                    generic_value = parse_string_to_bytes(generic_value)
                usr_queue_options_dict[name] = generic_value

        for line in config_dict.get("QUEUE_OPTION", []):
            queue_system, option_name, *values = line
            value = None if len(values) == 0 else values[0]
            if value is not None and queue_system == selected_queue_system:
                usr_queue_options_dict[option_name.lower()] = value

        return usr_queue_options_dict

    @classmethod
    def from_dict(
        cls,
        config_dict: ConfigDict,
        site_queue_options: QueueOptions | None = None,
    ) -> QueueConfig:
        """Merge ConfigDict with QueueOptions.

        A ConfigDict is parsed from an Ert configuration.

        site_queue_options is overridden by config_dict"""
        site_queue_options_dict = (
            site_queue_options.model_dump(exclude_unset=True)
            if site_queue_options
            else {}
        )

        usr_queue_system = config_dict.get("QUEUE_SYSTEM")
        site_queue_system = site_queue_options.name if site_queue_options else None

        config_dict["QUEUE_SYSTEM"] = selected_queue_system = QueueSystem(
            usr_queue_system or site_queue_system or QueueSystem.LOCAL
        )

        usr_queue_options_dict = cls._user_queue_options_from_dict(
            selected_queue_system, config_dict
        )

        merged_queue_options_dict = (
            site_queue_options_dict
            if str(selected_queue_system) == site_queue_system
            else {}
        ) | usr_queue_options_dict

        max_submit: int = config_dict.get(ConfigKeys.MAX_SUBMIT, 1)
        stop_long_running = config_dict.get(ConfigKeys.STOP_LONG_RUNNING, False)

        if "num_cpu" in merged_queue_options_dict:
            config_dict["NUM_CPU"] = merged_queue_options_dict.get("num_cpu")
        elif (data_file := config_dict.get(ConfigKeys.DATA_FILE)) and (
            num_cpu := get_num_cpu_from_data_file(data_file)
        ):
            logger.info(f"Parsed NUM_CPU={num_cpu} from {data_file}")
            merged_queue_options_dict[ConfigKeys.NUM_CPU] = num_cpu

        selected_queue_options = QueueOptions.create_queue_options(
            selected_queue_system,
            merged_queue_options_dict,
            True,
        )

        cls._validate_config_dict(
            selected_queue_system, config_dict, site_queue_options_dict
        )

        if selected_queue_options.project_code is None:
            tags = {
                fm_name.lower()
                for fm_name, *_ in config_dict.get(ConfigKeys.FORWARD_MODEL, [])
                if fm_name in {"RMS", "FLOW", "ECLIPSE100", "ECLIPSE300"}
            }
            if tags:
                selected_queue_options.project_code = "+".join(tags)

        return QueueConfig(
            max_submit=max_submit,
            queue_system=selected_queue_system,
            queue_options=selected_queue_options,
            stop_long_running=bool(stop_long_running),
            max_runtime=config_dict.get(ConfigKeys.MAX_RUNTIME),
        )

    @staticmethod
    def _validate_config_dict(
        selected_queue_system: QueueSystem,
        config_dict: ConfigDict,
        site_queue_options_dict: ConfigDict,
    ) -> None:
        raw_queue_options = config_dict.get("QUEUE_OPTION", [])
        grouped_queue_options = _group_queue_options_by_queue_system(raw_queue_options)
        _log_duplicated_queue_options(raw_queue_options, site_queue_options_dict)
        _raise_for_defaulted_invalid_options(raw_queue_options)

        # validate all queue options for the unselected queues
        # and show a warning
        for _queue_system in QueueSystem:
            if _queue_system != selected_queue_system:
                _ = QueueOptions.create_queue_options(
                    _queue_system,
                    grouped_queue_options[_queue_system],
                    False,
                )

    def create_local_copy(self) -> QueueConfig:
        return QueueConfig(
            max_submit=self.max_submit,
            queue_system=QueueSystem.LOCAL,
            queue_options=LocalQueueOptions(max_running=self.max_running),
            stop_long_running=bool(self.stop_long_running),
            max_runtime=self.max_runtime,
        )

    @property
    def max_running(self) -> int:
        return self.queue_options.max_running

    @property
    def submit_sleep(self) -> float:
        return self.queue_options.submit_sleep


def parse_string_to_bytes(input_str: str) -> int:
    """
    Convert a string (e.g., "1GB", "512MB") to bytes.
    """

    if input_str.strip().startswith("-"):
        raise ConfigValidationError.with_context(
            f"Negative memory does not make sense in {input_str}",
            input_str,
        )
    if input_str.isdigit():
        return int(input_str)

    multipliers = {
        "b": 1,
        "k": 1024,
        "m": 1024**2,
        "g": 1024**3,
        "t": 1024**4,
        "p": 1024**5,
    }

    # Match the pattern: number followed by an optional unit (e.g., "1GB", "512MB")
    matches = re.findall(r"(\d+)\s*([bkmgtpBKMGTP]*)", input_str.strip())
    if not matches:
        raise ConfigValidationError.with_context(
            f"Invalid memory string: {input_str}", input_str
        )
    if len(matches) > 1:
        raise ConfigValidationError.with_context(
            f"Invalid memory string: {input_str}", input_str
        )

    value, unit = matches[0]
    unit = unit.lower()
    if not unit:
        raise ConfigValidationError.with_context("Unknown memory unit", input_str)
    if unit and unit[0] not in multipliers:
        raise ConfigValidationError.with_context(
            f"Unknown memory unit: {unit}", input_str
        )

    return int(value) * multipliers.get(unit[0], 1)  # Default to bytes if no unit


def _throw_error_or_warning(
    error_msg: str, option_value: Any, throw_error: bool
) -> None:
    if throw_error:
        raise ConfigValidationError.with_context(
            error_msg,
            option_value,
        ) from None
    else:
        ConfigWarning.warn(
            error_msg,
            option_value,
        )
