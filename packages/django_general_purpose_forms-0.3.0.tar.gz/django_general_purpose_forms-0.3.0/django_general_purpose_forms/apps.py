# Django
from django.apps import AppConfig


class DjangoGeneralPurposeFormConfig(AppConfig):
    name = "django_general_purpose_forms"
