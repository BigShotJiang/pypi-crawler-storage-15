"""
Weather modules.
TODO: write doc
"""

__title__ = "Weather"

from .weather import Weather
