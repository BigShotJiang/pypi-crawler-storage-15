"""
TODO: write docs
"""

__title__ = "Sky flats"

from .flatfielder import FlatFielder
from .scheduler import Scheduler
