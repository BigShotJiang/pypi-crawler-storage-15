__title__ = "Modules"

from .getfitsheaders import GetFitsHeaders
