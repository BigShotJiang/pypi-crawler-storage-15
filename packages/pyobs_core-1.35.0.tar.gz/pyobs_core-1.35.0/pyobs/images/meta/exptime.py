class ExpTime:
    def __init__(self, exptime: float):
        self.exptime = exptime


__all__ = ["ExpTime"]
