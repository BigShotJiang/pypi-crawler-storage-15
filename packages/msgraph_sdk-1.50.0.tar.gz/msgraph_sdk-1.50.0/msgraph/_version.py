# The SDK version
# x-release-please-start-version
VERSION: str = '1.50.0'
# x-release-please-end
