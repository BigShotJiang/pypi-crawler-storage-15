JOB_SCHEDULER = 'SLURM'

JOB_SCHEDULER_OPTIONS = {
    'time' : '24:00:00',
    # 'qos'  : 'daaa_intel_moyen',
}
