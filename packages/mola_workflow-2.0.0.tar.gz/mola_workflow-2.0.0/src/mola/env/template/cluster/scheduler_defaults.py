MOLA_PATH = '/scratch/mola/src'

JOB_SCHEDULER = 'SLURM'

JOB_SCHEDULER_OPTIONS = {
    'time' : '24:00:00',
}
