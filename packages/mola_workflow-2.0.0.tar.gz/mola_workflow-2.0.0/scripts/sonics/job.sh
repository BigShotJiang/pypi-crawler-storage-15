source /stck/sonics/LD8/sonics/0.6.4/source.sh
mpirun -np 1 python3 compute_using_sonics.py 1>stdout.log 2>stderr.log