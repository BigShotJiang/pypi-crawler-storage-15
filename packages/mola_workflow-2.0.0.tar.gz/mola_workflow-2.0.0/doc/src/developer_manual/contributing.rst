############
Contributing
############

If you want to contribute to source code, you can start by taking a look to 
`that page <https://gitlab.onera.net/numerics/mola/-/blob/master/CONTRIBUTING.md>`_.