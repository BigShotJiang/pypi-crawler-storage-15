##############
Code structure
##############

:fas:`person-digging;sd-text-warning` Work in progress :fas:`person-digging;sd-text-warning`

.. todo:: 
    
    write the developer manual :
        - explain the structure Workflow / WorkflowInterface / WorkflowManager
        - explain the structure: method in Workflow --> module in cfd/preprocess, with specialization with solver_elsa.py
        - explain the structure of env
        - explain the structure of compute and coprocess

.. toctree::
    :maxdepth: 2

    cfd/index
