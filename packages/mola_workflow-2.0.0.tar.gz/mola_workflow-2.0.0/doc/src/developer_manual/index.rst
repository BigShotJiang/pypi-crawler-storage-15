################
Developer manual
################

:fas:`person-digging;sd-text-warning` Work in progress :fas:`person-digging;sd-text-warning`

The developer manual is aimed at contributors, details the structure, 
the mechanisms of the package as well as some gotchas.

.. toctree::
    :maxdepth: 2

    contributing
    deployment
    structure/index
    
