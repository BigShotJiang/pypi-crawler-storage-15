#############
Isolated wing 
#############

*****************
Short description
*****************

A simple subsonic wing.

.. figure:: //stck/mola/data/open/mesh/isolated_wing/isolated_wing_mesh.png
  :width: 100%
  :align: center

  Input mesh - Full domain on the left, zoom on the wing on the right


***************
RANS simulation
***************

.. literalinclude:: ../../../../examples/open/workflow/fixed_component/airplane/isolated_wing/run_sator.py
    :language: python

