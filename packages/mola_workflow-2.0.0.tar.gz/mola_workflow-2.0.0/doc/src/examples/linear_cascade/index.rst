####################################
Examples for Workflow linear_cascade
####################################

.. toctree::
   :maxdepth: 1

   SPLEEN
