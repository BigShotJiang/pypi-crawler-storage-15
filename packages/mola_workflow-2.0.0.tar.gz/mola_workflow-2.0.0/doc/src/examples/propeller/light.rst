###############
Light propeller 
###############

*****************
Short description
*****************

To write...

*************************
RANS simulation with elsA
*************************

.. literalinclude:: ../../../../examples/open/workflow/rotating_component/propeller/light/run_elsa_ld.py
    :language: python

***************************
RANS simulation with SoNICS
***************************

.. literalinclude:: ../../../../examples/open/workflow/rotating_component/propeller/light/run_sonics_ld.py
    :language: python

*************************
RANS simulation with Fast
*************************

.. literalinclude:: ../../../../examples/open/workflow/rotating_component/propeller/light/run_fast_ld.py
    :language: python

*****************************
Comparison of solvers results
*****************************

.. literalinclude:: ../../../../examples/open/workflow/rotating_component/propeller/light/compare.py
    :language: python
