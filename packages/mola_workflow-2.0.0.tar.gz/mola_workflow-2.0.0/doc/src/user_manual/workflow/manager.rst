###############
WorkflowManager
###############

.. py:currentmodule::  mola.workflow.manager

Each applicative Workflow has a WorkflowManager, that can be used to submit 
several simulations for a parametric study for instance. 

.. autoclass:: WorkflowManager

