########################
Workflows by application
########################

.. toctree::
   :maxdepth: 1

   airplane
   linear_cascade
   turbomachinery
   propeller
