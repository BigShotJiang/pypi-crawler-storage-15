################
Workflow airfoil
################

.. py:currentmodule::  mola.workflow.fixed.airfoil

:fas:`person-digging;sd-text-warning` Work in progress :fas:`person-digging;sd-text-warning`

The Workflow airfoil can be imported with:

.. code-block:: python

    from mola.workflow.fixed import airfoil
    workflow = airfoil.Workflow(...)

It is adapted to 2D airfoil simulations.

.. autoclass:: Workflow

