Main authors
------------

ONERA: Luis Bernardos, Thomas Bontemps

Contributors
------------

ONERA: Mikel Balmaseda, Johan Valentin, Danny Lewis, Benjamin François, Julien Marty, Hugues Pantel

