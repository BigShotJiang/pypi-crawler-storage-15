___________________________________________________________________
⚠️ **Be careful**: MOLA has an **open source license LGPLv3** 🔓

Before integrating your development, be sure that 
it is **not confidential** and that it is **compatible with the license**.
___________________________________________________________________

