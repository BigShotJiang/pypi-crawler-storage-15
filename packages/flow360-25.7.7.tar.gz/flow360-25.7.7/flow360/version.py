"""
version
"""

__version__ = "25.7.7"
__solver_version__ = "release-25.7"
