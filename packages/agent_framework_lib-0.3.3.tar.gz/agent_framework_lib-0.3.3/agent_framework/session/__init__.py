"""Session management utilities."""
