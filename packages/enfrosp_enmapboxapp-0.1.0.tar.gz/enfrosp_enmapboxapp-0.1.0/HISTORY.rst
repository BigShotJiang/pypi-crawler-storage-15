.. SPDX-License-Identifier: GPL-3.0-or-later
.. FileType: DOCUMENTATION
.. FileCopyrightText: 2025, GFZ Helmholtz Centre for Geosciences
.. FileCopyrightText: 2025, Daniel Scheffler (danschef@gfz.de)


=======
History
=======

0.1.0 (2025-12-03)
------------------

* Added initial version of EnFROSP GUI and revised pyproject.toml (!2).
* Package skeleton created with https://git.gfz-potsdam.de/fernlab/products/cookiecutters/cookiecutter-python-package.
