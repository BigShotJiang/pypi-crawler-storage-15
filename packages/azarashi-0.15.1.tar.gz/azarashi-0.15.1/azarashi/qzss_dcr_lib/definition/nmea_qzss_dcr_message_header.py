nmea_qzss_dcr_message_header: str = '$QZQSM'
