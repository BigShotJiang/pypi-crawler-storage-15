from f1_4666 import F1Res4666
from f2_4666 import F2Res4666
from f3_4666 import F3Res4666
from f4_4666 import F4Res4666
from f5_4666 import F5Res4666
from f6_4666 import F6Res4666
from f7_4666 import F7Res4666
from f8_4666 import F8Res4666
