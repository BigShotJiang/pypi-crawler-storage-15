# fps-jupyterlab

An FPS plugin for the JupyterLab API.
