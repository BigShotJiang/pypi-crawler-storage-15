# Code of Conduct

## Our Pledge

We pledge to make participation in SlowQL a harassment-free experience for everyone.

## Standards

**Positive behavior:**
- Welcoming and inclusive language
- Respectful of differing viewpoints
- Gracefully accepting constructive criticism

**Unacceptable behavior:**
- Harassment, trolling, insulting comments
- Publishing others' private information
- Unprofessional conduct

## Enforcement

Report violations to: elmehdi.makroumi@gmail.com

Consequences: Warning → Temporary ban → Permanent ban

## Attribution

Adapted from [Contributor Covenant](https://www.contributor-covenant.org/).