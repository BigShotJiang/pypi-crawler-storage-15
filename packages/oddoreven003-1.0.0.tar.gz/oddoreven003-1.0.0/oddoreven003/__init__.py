from .core import is_even, is_odd, parity

__all__ = ["is_even", "is_odd", "parity"]
__version__ = "1.0.0"
