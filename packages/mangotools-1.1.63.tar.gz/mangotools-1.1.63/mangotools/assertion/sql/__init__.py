# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description: 
# @Time   : 2025-07-04 14:09
# @Author : 毛鹏
from mangotools.assertion.sql._sql import MysqlAssertion


class SqlAssertion(MysqlAssertion):
    """SQL断言"""
