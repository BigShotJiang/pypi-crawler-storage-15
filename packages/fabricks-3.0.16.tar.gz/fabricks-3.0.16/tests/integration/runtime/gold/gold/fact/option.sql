select `id` as id, `name` as monarch, `doubleField` as value from silver.monarch_scd1__current
