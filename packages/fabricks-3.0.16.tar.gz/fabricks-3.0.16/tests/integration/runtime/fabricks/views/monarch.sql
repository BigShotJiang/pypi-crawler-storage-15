select * from fabricks.jobs where topic = 'monarch'
