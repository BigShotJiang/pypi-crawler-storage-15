from flask_restx import Namespace

ns_conf = Namespace('agents', description='API to perform operations on MindsDB Agents')
