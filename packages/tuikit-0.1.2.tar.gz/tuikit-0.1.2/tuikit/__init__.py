try: from ._version import version as __version__
except Exception: __version__ = "0.2.2"