VERSION="0.6.0.1" # TODO: edit before push
CUBISM_SDK_DISTRIBUTION="https://cubism.live2d.com/sdk-native/bin/CubismSdkForNative-5-r.4.1.zip"