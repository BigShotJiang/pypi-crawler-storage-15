Elasticipy.spherical_function
====================================

.. automodule:: Elasticipy.spherical_function
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
