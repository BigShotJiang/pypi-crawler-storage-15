Elasticipy.interfaces.PRISMS
====================================

.. automodule:: Elasticipy.interfaces.PRISMS
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
