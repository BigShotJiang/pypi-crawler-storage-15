Elasticipy.tensors.fourth_order
======================================

.. automodule:: Elasticipy.tensors.fourth_order
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
