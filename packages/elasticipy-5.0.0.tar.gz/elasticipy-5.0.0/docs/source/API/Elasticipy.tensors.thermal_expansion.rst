Elasticipy.tensors.thermal_expansion
============================================

.. automodule:: Elasticipy.tensors.thermal_expansion
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
