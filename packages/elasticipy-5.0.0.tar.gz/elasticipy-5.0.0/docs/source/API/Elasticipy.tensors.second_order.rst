Elasticipy.tensors.second_order
======================================

.. automodule:: Elasticipy.tensors.second_order
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
