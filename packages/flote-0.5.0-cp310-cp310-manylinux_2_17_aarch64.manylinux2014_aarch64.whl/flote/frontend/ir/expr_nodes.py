"""This module defines the expression nodes used in the assignment of a bus."""
from .buses import BusDto, BusValueDto, HlsBusDto
from .expr_node import ExprNode


class Ref(ExprNode):
    """This class represents a reference to a bus in the circuit."""
    def __init__(self, bus: BusDto | HlsBusDto, slice_begin: int, slice_end: int) -> None:
        self.bus = bus
        self.slice_begin = slice_begin
        self.slice_end = slice_end

    def __repr__(self) -> str:
        return f'Ref({self.bus.id_})'

    def __str__(self) -> str:
        return f'Ref ({self.bus.id_})'

    def get_sensitivity_list(self):
        return [self.bus]

    def to_json(self):
        return {
            'type': 'ref',
            'args': {
                'id': self.bus.id_, 'slice_begin': self.slice_begin, 'slice_end': self.slice_end
            }
        }


class Conc(ExprNode):
    """This class represents a concatenation of expressions."""
    def __init__(self, exprs: list[ExprNode]) -> None:
        self.exprs = exprs

    def __repr__(self) -> str:
        return f'Conc({self.exprs})'

    def __str__(self) -> str:
        desc = 'Conc:'

        for expr in self.exprs:
            expr_desc = str(expr).replace('\n', '\n|  ')
            desc += f'\n|  |- {expr_desc}'

        return desc

    def to_json(self):
        return {
            'type': 'conc',
            'args': {
                'exprs': [expr.to_json() for expr in self.exprs]
            }
        }

    def get_sensitivity_list(self):
        sensitivity_list: list[BusDto] = []

        for expr in self.exprs:
            sensitivity_list += expr.get_sensitivity_list()

        return sensitivity_list


class Const(ExprNode):
    """This class represents a constant value in the circuit."""
    def __init__(self, value: BusValueDto) -> None:
        self.value = value

    def __repr__(self) -> str:
        return f'Const({self.value})'

    def __str__(self) -> str:
        return f'Const ({self.value})'

    def to_json(self):
        return {'type': 'const', 'args': {'value': self.value.to_json()}}

    def get_sensitivity_list(self):
        return []


class UnaryOperation(ExprNode):
    """Base class for all unary operations."""
    def __init__(self, expr: ExprNode) -> None:
        self.expr = expr

    def get_sensitivity_list(self):
        return self.expr.get_sensitivity_list()


class BinaryOperation(ExprNode):
    """Base class for all binary operations."""
    def __init__(self, l_expr: ExprNode, r_expr: ExprNode) -> None:
        self.l_expr = l_expr
        self.r_expr = r_expr

    def get_sensitivity_list(self):
        return self.l_expr.get_sensitivity_list() + self.r_expr.get_sensitivity_list()


class Not(UnaryOperation):
    def __repr__(self) -> str:
        return f'Not {self.expr}'

    def __str__(self) -> str:
        return f'Not ({self.expr})'

    def to_json(self):
        return {'type': 'not', 'args': {'expr': self.expr.to_json()}}


class And(BinaryOperation):
    def __repr__(self) -> str:
        return f'And {self.l_expr} {self.r_expr}'

    def __str__(self) -> str:
        return f'And ({self.l_expr}, {self.r_expr})'

    def to_json(self):
        return {
            'type': 'and',
            'args': {'l_expr': self.l_expr.to_json(), 'r_expr': self.r_expr.to_json()}
        }


class Or(BinaryOperation):
    def __repr__(self) -> str:
        return f'Or {self.l_expr} {self.r_expr}'

    def __str__(self) -> str:
        return f'Or ({self.l_expr}, {self.r_expr})'

    def to_json(self):
        return {
            'type': 'or',
            'args': {'l_expr': self.l_expr.to_json(), 'r_expr': self.r_expr.to_json()}
        }


class Xor(BinaryOperation):
    def __repr__(self) -> str:
        return f'Xor {self.l_expr} {self.r_expr}'

    def __str__(self) -> str:
        return f'Xor ({self.l_expr}, {self.r_expr})'

    def to_json(self):
        return {
            'type': 'xor',
            'args': {'l_expr': self.l_expr.to_json(), 'r_expr': self.r_expr.to_json()}
        }


class Nand(BinaryOperation):
    def __repr__(self) -> str:
        return f'Nand {self.l_expr} {self.r_expr}'

    def __str__(self) -> str:
        return f'Nand ({self.l_expr}, {self.r_expr})'

    def to_json(self):
        return {
            'type': 'nand',
            'args': {'l_expr': self.l_expr.to_json(), 'r_expr': self.r_expr.to_json()}
        }


class Nor(BinaryOperation):
    def __repr__(self) -> str:
        return f'Nor {self.l_expr} {self.r_expr}'

    def __str__(self) -> str:
        return f'Nor ({self.l_expr}, {self.r_expr})'

    def to_json(self):
        return {
            'type': 'nor',
            'args': {'l_expr': self.l_expr.to_json(), 'r_expr': self.r_expr.to_json()}
        }


class Xnor(BinaryOperation):
    def __repr__(self) -> str:
        return f'Xnor {self.l_expr} {self.r_expr}'

    def __str__(self) -> str:
        return f'Xnor ({self.l_expr}, {self.r_expr})'

    def to_json(self):
        return {
            'type': 'xnor',
            'args': {'l_expr': self.l_expr.to_json(), 'r_expr': self.r_expr.to_json()}
        }


Operations = And | Or | Xor | Nand | Nor | Xnor | Not
