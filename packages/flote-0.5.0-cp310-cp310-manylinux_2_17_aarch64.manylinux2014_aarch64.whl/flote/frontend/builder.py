from copy import deepcopy
from json import dumps
from typing import Optional, Tuple
from warnings import warn

from . import ast_nodes
from .ir import expr_nodes
from .ir.buses import BitBusDto, BitBusValueDto
from .ir.component import ComponentDto, HlsComponentDto
from .symbol_table import BusSymbol, ComponentTable, SymbolTable


class SemanticalError(Exception):
    def __init__(self, message: str, line_number: Optional[int] = None):
        self.line_number = line_number
        self.message = message

    def __str__(self):
        return (
            f'Semantical error at line {self.line_number}: {self.message}'
            if self.line_number is not None
            else f'Semantical error: {self.message}'
        )


class Builder:
    """Class that builds the component from the AST."""
    def __init__(
        self,
        ast,
        hls_components_symbols: dict[str, ComponentTable] = {},
        hls_components: dict[str, HlsComponentDto] = {}
    ) -> None:
        self.ast: ast_nodes.Mod = ast
        self.symbol_table: SymbolTable = SymbolTable()
        self.components: dict[str, ComponentDto | HlsComponentDto] = {}
        self.comp_nodes: dict[str, ast_nodes.Comp] = {}

        self.symbol_table.components |= hls_components_symbols
        self.components |= hls_components

        self.ir: str = self.get_ir()

    def get_ir(self) -> str:
        component = self.vst_mod(self.ast)
        component.make_influence_graph()

        return dumps(component.to_json())

    def init_component_table(self, comp: ast_nodes.Comp) -> ComponentTable:
        """Get the component's bus symbol table."""
        comp_table: ComponentTable = ComponentTable()

        for stmt in comp.stmts:
            if isinstance(stmt, ast_nodes.Decl):
                decl = stmt  # Name change for better readability
                is_assigned = False
                size = 1

                if decl.id in comp_table.bus_symbols.keys():
                    raise SemanticalError(
                        f'Bus "{decl.id}" has already been declared.',
                        decl.line_number
                    )

                if decl.assign is not None:
                    if (decl.conn == ast_nodes.Connection.INPUT):
                        raise SemanticalError(
                            f'Input Buses like {decl.id} cannot be assigned.',
                            decl.line_number
                        )

                    # Mark the bus as assigned in the symbol table
                    is_assigned = True

                if decl.dimension is not None:
                    size = decl.dimension.size

                comp_table.bus_symbols[decl.id] = BusSymbol(
                    decl.type,
                    is_assigned,
                    decl.conn,
                    size
                )

        return comp_table

    def validate_bus_symbol_table(self):
        """Validate the bus symbol table to ensure all buses are assigned and read."""
        for bus_table in self.symbol_table.components.values():
            for bus_id, bus in bus_table.bus_symbols.items():
                if (bus.connection_type != ast_nodes.Connection.INPUT) and (not bus.is_assigned):
                    warn(
                        f'Bus "{bus_id}" has not been assigned.',
                        UserWarning
                    )

                if (bus.connection_type != ast_nodes.Connection.OUTPUT) and (not bus.is_read):
                    warn(f'Bus "{bus_id}" is never read', UserWarning)

    #TODO change to return a module of components
    def vst_mod(self, mod: ast_nodes.Mod) -> ComponentDto:
        if not mod.comps:
            raise SemanticalError('Module is empty.')

        # Fill the comp_nodes dictionary
        for comp in mod.comps:
            self.comp_nodes[comp.id] = comp

        if len(mod.comps) == 1:
            component = self.vst_comp(mod.comps[0])
            self.components[mod.comps[0].id] = component

            return component
        else:  # If there are multiple components, we assume one of them is the main
            is_main_comp_found = False
            main_component: Optional[ComponentDto] = None

            for comp in mod.comps:  # Search for the main component
                if comp.id in self.components:
                    continue  # Skip if component already processed in a previous instantiation
                # Add component to the components dict
                component = self.vst_comp(comp)
                self.components[comp.id] = component

                if comp.is_main:
                    if is_main_comp_found:
                        raise SemanticalError(
                            (
                                f'{comp.id} can\'t be main. Only one main '
                                'component is allowed.'
                            ),
                            comp.line_number
                        )

                    is_main_comp_found = True
                    main_component = component

            if not is_main_comp_found:
                raise SemanticalError(
                    'Main component not found in a multiple component module.'
                )

        assert main_component is not None, (
            'Main component should not be None.'
        )

        self.validate_bus_symbol_table()

        return main_component

    def vst_comp(self, comp: ast_nodes.Comp) -> ComponentDto:
        if comp.id in self.symbol_table.components.keys():
            raise SemanticalError(
                f'Component "{comp.id}" has already been declared.',
                comp.line_number
            )

        component_id = comp.id
        component = ComponentDto(component_id)
        self.symbol_table.components[component_id] = self.init_component_table(
            comp,
        )
        self.symbol_table.components[component_id].object = component

        for stmt in comp.stmts:
            if isinstance(stmt, ast_nodes.Decl):
                self.vst_decl(stmt, component_id, component)
            elif isinstance(stmt, ast_nodes.Assign):
                self.vst_assign(stmt, component_id, component)
            elif isinstance(stmt, ast_nodes.Inst):
                self.vst_inst(stmt, component_id, component)
            else:
                assert False, f'Invalid statement: {stmt}'

        return component

    def vst_decl(self, decl: ast_nodes.Decl, component_id: str, component: ComponentDto) -> None:
        assert decl.id in self.symbol_table.components[component_id].bus_symbols.keys(), (
            f'Bus "{decl.id}" has not been declared in the symbol table.'
        )

        bus_symbol = self.symbol_table.components[component_id].bus_symbols[decl.id]
        bit_bus = BitBusDto()
        bit_bus.id_ = decl.id
        bus_symbol.object = bit_bus

        # if decl.conn == ast_nodes.Connection.INPUT:
        #     component.interface.append(decl.id)

        if decl.dimension is not None:
            assert decl.dimension.size is not None

            bit_bus.set_dimension(decl.dimension.size)

        if decl.assign is not None:
            # Create the bus assignment
            assignment, size = self.vst_expr(decl.assign, component_id, component)
            bit_bus.assignment = assignment

            #TODO improve using symbol table
            if size != bus_symbol.size:
                raise SemanticalError(
                    (
                        f'Assignment size ({size}) does not match bus size '
                        f'({bus_symbol.size}) for "{decl.id}".'
                    ),
                    decl.line_number
                )

        component.busses.append(bit_bus)

    def vst_assign(
        self, assign: ast_nodes.Assign, component_id: str, component: ComponentDto
    ) -> None:
        if assign.destiny.id not in self.symbol_table.components[component_id].bus_symbols.keys():
            #TODO change to accept after declaration
            # All destiny signals must be declared previously
            raise SemanticalError(
                f'Identifier "{assign.destiny.id}" has not been declared.',
                assign.destiny.line_number
            )

        bus_symbol = self.symbol_table.components[component_id].bus_symbols[assign.destiny.id]

        if (bus_symbol.connection_type == ast_nodes.Connection.INPUT) and \
                (not bus_symbol.is_lower_lvl):
            raise SemanticalError(
                f'Input Buses of top level like "{assign.destiny.id}" cannot be assigned.',
                assign.destiny.line_number
            )

        if (bus_symbol.connection_type != ast_nodes.Connection.INPUT) and \
                (bus_symbol.is_lower_lvl is True):
            raise SemanticalError(
                (
                    f'Internal/out Buses of subcomponents like "{assign.destiny.id}" cannot be '
                    f'assigned.'
                ),
                assign.destiny.line_number
            )

        if bus_symbol.is_assigned is True:
            # Destiny signal cannot be assigned more than once
            raise SemanticalError(
                f'Identifier "{assign.destiny.id}" already assigned.',
                assign.destiny.line_number
            )

        # Mark the bus as assigned in the symbol table
        bus_symbol.is_assigned = True

        assignment, size = self.vst_expr(
            assign.expr,
            component_id,
            component
        )

        if size != bus_symbol.size:
            raise SemanticalError(
                (
                    f'Assignment size ({size}) does not match target bus range ({bus_symbol.size}'
                    f') for "{assign.destiny.id}".'
                ),
                assign.destiny.line_number
            )

        bus = self.symbol_table.components[component_id].bus_symbols[assign.destiny.id].object
        assert bus is not None, f'Bus object for "{assign.destiny.id}" cannot be None.'
        bus.assignment = assignment

    def vst_expr(self, expr, component_id: str, component: ComponentDto) -> Tuple[
        expr_nodes.ExprNode, int
    ]:
        assignment = self.vst_expr_elem(expr, component_id, component)

        return assignment

    def vst_expr_elem(
        self, expr_elem: ast_nodes.ExprElem, component_id: str, component: ComponentDto
    ) -> Tuple[expr_nodes.ExprNode, int]:
        """
        Visit an expression element, validate it, and return a callable for evaluation."""
        if expr_elem is None:
            raise SemanticalError(
                'Expression element cannot be None.'
            )

        if isinstance(expr_elem, ast_nodes.Ref):
            ref = expr_elem

            if (ref_id := ref.id_.id) not in \
                    self.symbol_table.components[component_id].bus_symbols.keys():
                raise SemanticalError(
                    f'Bus reference "{ref_id}" has not been declared.',
                    ref.id_.line_number
                )

            bus_symbol = self.symbol_table.components[component_id].bus_symbols[expr_elem.id_.id]

            # Validate subcomponents busses references
            if (bus_symbol.is_lower_lvl is True) and \
                    (bus_symbol.connection_type != ast_nodes.Connection.OUTPUT):
                raise SemanticalError(
                    (
                        f'Input/Internal busses like "{ref_id}" of a subcomponent cannot be '
                        f'referenced from the higher level component.'
                    ),
                    ref.id_.line_number
                )

            # Validate range
            if ref.range_begin is not None:
                if ref.range_begin >= (size := bus_symbol.size):
                    raise SemanticalError(
                        f'Index [{ref.range_begin}:] out of bounds for "{ref_id}".',
                        ref.id_.line_number
                    )

                if ref.range_end is not None:
                    if ref.range_end >= size:
                        raise SemanticalError(
                            f'Index [:{ref.range_end}] out of bounds for "{ref_id}".',
                            ref.id_.line_number
                        )

                    if ref.range_begin > ref.range_end:
                        raise SemanticalError(
                            (
                                f'Invalid range [:{ref.range_end}] for "{ref_id}". '
                                'The end index must be equal or greater than to the begin index.'
                            ),
                            ref.id_.line_number
                        )

                    range_begin = ref.range_begin
                    range_end = ref.range_end
                else:
                    range_begin = ref.range_begin
                    range_end = range_begin
            else:
                range_begin = 0
                range_end = bus_symbol.size - 1

            slice_size = (range_end - range_begin) + 1
            bus_symbol.is_read = True

            #TODO fix type checking
            bus = self.symbol_table.components[component_id].bus_symbols[expr_elem.id_.id].object
            assert bus is not None, f'Bus object for "{ref_id}" cannot be None.'

            bus_ref = expr_nodes.Ref(
                bus,
                range_begin,
                range_end,
            )

            return bus_ref, slice_size
        elif isinstance(expr_elem, ast_nodes.BitField):
            bit_field = expr_elem
            bit_value = BitBusValueDto(bit_field.value)
            const = expr_nodes.Const(bit_value)

            return const, bit_field.size
        elif isinstance(expr_elem, ast_nodes.NotOp):
            assert expr_elem.expr is not None, 'Expression cannot be None.'

            expr, size = self.vst_expr_elem(expr_elem.expr, component_id, component)

            return expr_nodes.Not(expr), size
        elif isinstance(expr_elem, ast_nodes.Conc):
            conc = expr_elem
            exprs: list[expr_nodes.ExprNode] = []
            total_size = 0

            for sub_expr in conc.exprs:
                expr, size = self.vst_expr_elem(sub_expr, component_id, component)
                exprs.append(expr)
                total_size += size

            return expr_nodes.Conc(exprs), total_size
        elif isinstance(expr_elem, ast_nodes.AndOp):
            #TODO put a function for those asserts
            assert expr_elem.l_expr is not None, (
                'Left expression of And operation cannot be None.'
            )
            assert expr_elem.r_expr is not None, (
                'Right expression of And operation cannot be None.'
            )

            l_expr, l_size = self.vst_expr_elem(expr_elem.l_expr, component_id, component)
            r_expr, r_size = self.vst_expr_elem(expr_elem.r_expr, component_id, component)

            if l_size != r_size:
                raise SemanticalError(
                    (
                        f'Left ({l_expr}) and right ({r_expr}) expressions of And operation must be'
                        f' the same size.'
                    ),
                    expr_elem.line_number
                )

            return expr_nodes.And(l_expr, r_expr), l_size
        elif isinstance(expr_elem, ast_nodes.OrOp):
            assert expr_elem.l_expr is not None, (
                'Left expression of Or operation cannot be None.'
            )
            assert expr_elem.r_expr is not None, (
                'Right expression of Or operation cannot be None.'
            )

            l_expr, l_size = self.vst_expr_elem(expr_elem.l_expr, component_id, component)
            r_expr, r_size = self.vst_expr_elem(expr_elem.r_expr, component_id, component)

            if l_size != r_size:
                raise SemanticalError(
                    'Left and right expressions of And operation must be the same size.',
                    expr_elem.line_number
                )

            return expr_nodes.Or(l_expr, r_expr), l_size
        elif isinstance(expr_elem, ast_nodes.XorOp):
            assert expr_elem.l_expr is not None, (
                'Left expression of Xor operation cannot be None.'
            )
            assert expr_elem.r_expr is not None, (
                'Right expression of Xor operation cannot be None.'
            )

            l_expr, l_size = self.vst_expr_elem(expr_elem.l_expr, component_id, component)
            r_expr, r_size = self.vst_expr_elem(expr_elem.r_expr, component_id, component)

            if l_size != r_size:
                raise SemanticalError(
                    'Left and right expressions of And operation must be the same size.',
                    expr_elem.line_number
                )

            return expr_nodes.Xor(l_expr, r_expr), l_size
        elif isinstance(expr_elem, ast_nodes.NandOp):
            assert expr_elem.l_expr is not None, (
                'Left expression of Nand operation cannot be None.'
            )
            assert expr_elem.r_expr is not None, (
                'Right expression of Nand operation cannot be None.'
            )

            l_expr, l_size = self.vst_expr_elem(expr_elem.l_expr, component_id, component)
            r_expr, r_size = self.vst_expr_elem(expr_elem.r_expr, component_id, component)

            if l_size != r_size:
                raise SemanticalError(
                    'Left and right expressions of And operation must be the same size.',
                    expr_elem.line_number
                )

            return expr_nodes.Nand(l_expr, r_expr), l_size
        elif isinstance(expr_elem, ast_nodes.NorOp):
            assert expr_elem.l_expr is not None, (
                'Left expression of Nor operation cannot be None.'
            )
            assert expr_elem.r_expr is not None, (
                'Right expression of Nor operation cannot be None.'
            )

            l_expr, l_size = self.vst_expr_elem(expr_elem.l_expr, component_id, component)
            r_expr, r_size = self.vst_expr_elem(expr_elem.r_expr, component_id, component)

            if l_size != r_size:
                raise SemanticalError(
                    'Left and right expressions of And operation must be the same size.',
                    expr_elem.line_number
                )

            return expr_nodes.Nor(l_expr, r_expr), l_size
        elif isinstance(expr_elem, ast_nodes.XnorOp):
            assert expr_elem.l_expr is not None, (
                'Left expression of Xnor operation cannot be None.'
            )
            assert expr_elem.r_expr is not None, (
                'Right expression of Xnor operation cannot be None.'
            )

            l_expr, l_size = self.vst_expr_elem(expr_elem.l_expr, component_id, component)
            r_expr, r_size = self.vst_expr_elem(expr_elem.r_expr, component_id, component)

            if l_size != r_size:
                raise SemanticalError(
                    'Left and right expressions of And operation must be the same size.',
                    expr_elem.line_number
                )

            return expr_nodes.Xnor(l_expr, r_expr), l_size
        else:
            assert False, f'Invalid expression element: {expr_elem}'

    def vst_inst(self, inst: ast_nodes.Inst, component_id: str, component: ComponentDto) -> None:
        assert inst.comp_id is not None, 'Instance component cannot be None.'

        # Check if the subcomponent was already processed
        #TODO check hls components
        if inst.comp_id not in self.components.keys():
            try:
                self.components[inst.comp_id] = self.vst_comp(self.comp_nodes[inst.comp_id])
            except KeyError:
                raise SemanticalError(
                    f"Component '{inst.comp_id}' not found.",
                    inst.line_number
                )

        alias = inst.comp_id if inst.sub_alias is None else inst.sub_alias
        subcomponent = deepcopy(self.components[inst.comp_id])

        top_busses = self.symbol_table.components[component_id].bus_symbols
        bottom_busses = deepcopy(self.symbol_table.components[inst.comp_id].bus_symbols)

        for bus in bottom_busses.values():
            bus.is_lower_lvl = True

        # Add the subcomponent's buses to the top component's symbol table
        top_busses |= {
            f'{alias}.{bus_id}': bus for bus_id, bus in bottom_busses.items()
        }

        # Link the new subcomponent's bus objects to the top component's symbol table because
        # deepcopy still makes references to the old objects.
        for bus in subcomponent.busses:
            top_busses[f'{alias}.{bus.id_}'].object = bus

        component.add_subcomponent(subcomponent, alias)
