var retrieveDataPidUrl = "{% url 'core_linked_records_retrieve_data_pid' %}";
