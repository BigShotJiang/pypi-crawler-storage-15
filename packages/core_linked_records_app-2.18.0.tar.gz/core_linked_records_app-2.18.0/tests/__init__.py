""" Test package for core_linked_records_app
"""
