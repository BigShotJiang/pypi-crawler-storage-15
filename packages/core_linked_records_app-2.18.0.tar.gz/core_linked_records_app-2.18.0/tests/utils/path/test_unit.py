""" Unit tests for core_linked_records_app.utils.path
"""

from unittest import TestCase


class TestGetApiPathFromObject(TestCase):
    """Test Get Api Path From Object"""

    def test_builtin_object_not_returned(self):
        """test_builtin_object_not_returned"""

        pass

    def test_path_to_api_returned(self):
        """test_path_to_api_returned"""

        pass
