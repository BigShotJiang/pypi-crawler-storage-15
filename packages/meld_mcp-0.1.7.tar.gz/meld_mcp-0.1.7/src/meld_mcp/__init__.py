"""Meld MCP Server - Connects Claude Code to Meld cloud."""

from importlib.metadata import version

__version__ = version("meld-mcp")

