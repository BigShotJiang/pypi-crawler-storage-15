from enum import Enum


class InFrame(str, Enum):
    YES = "yes"
    NO = "no"
    UNKNOWN = "unknown"
