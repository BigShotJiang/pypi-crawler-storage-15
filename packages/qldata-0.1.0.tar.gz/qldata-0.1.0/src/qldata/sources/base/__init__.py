"""Base source classes."""

from qldata.sources.base.source import DataSource

__all__ = [
    "DataSource",
]
