"""Historical data sources."""

from qldata.sources.historical.file_source import HistoricalDataSource

__all__ = [
    "HistoricalDataSource",
]
