"""Base store classes."""

from qldata.stores.base.store import DataStore

__all__ = [
    "DataStore",
]
