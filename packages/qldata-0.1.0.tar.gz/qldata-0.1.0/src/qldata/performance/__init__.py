"""Performance optimization package."""

__all__: list[str] = []
