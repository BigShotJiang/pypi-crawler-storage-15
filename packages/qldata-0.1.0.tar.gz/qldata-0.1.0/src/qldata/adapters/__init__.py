"""Adapters package."""

__all__: list[str] = []
