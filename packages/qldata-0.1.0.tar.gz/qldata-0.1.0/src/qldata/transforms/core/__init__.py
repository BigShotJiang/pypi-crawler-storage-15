"""Core transform infrastructure."""

from qldata.transforms.core.pipeline import TransformPipeline

__all__ = [
    "TransformPipeline",
]
