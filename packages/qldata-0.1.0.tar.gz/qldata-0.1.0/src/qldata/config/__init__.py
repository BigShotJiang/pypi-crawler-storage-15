"""Configuration package."""

from qldata.config.manager import get_config

__all__ = [
    "get_config",
]
