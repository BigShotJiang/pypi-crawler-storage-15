"""Resource modules for Semantik API."""

