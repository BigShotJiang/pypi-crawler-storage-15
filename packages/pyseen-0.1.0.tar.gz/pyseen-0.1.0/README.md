# pyseen

A tiny utility to "see" what your Python objects are.

## Install

```bash
pip install pyseen