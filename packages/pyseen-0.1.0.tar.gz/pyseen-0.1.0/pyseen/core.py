def see(obj):
    """A simple demo function."""
    print(f"Seen: {obj}")