"""Entry point for Ghanon command-line interface."""

from ghanon import cli

if __name__ == "__main__":
    cli.main()
