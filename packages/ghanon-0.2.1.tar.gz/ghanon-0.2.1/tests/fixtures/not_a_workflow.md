# This is a markdown file

This file is used to test that Ghanon properly handles non-YAML files
and produces appropriate error messages when attempting to parse them
as GitHub Actions workflows.
