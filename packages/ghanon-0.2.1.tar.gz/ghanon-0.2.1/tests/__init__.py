"""Tests for ghanon package."""
