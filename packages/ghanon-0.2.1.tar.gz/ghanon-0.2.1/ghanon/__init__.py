"""GitHub Actions workflow schema validation library using Pydantic."""
