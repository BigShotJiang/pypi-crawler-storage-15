class RATLSVerificationError(Exception):
    """Exception raised when RATLS verification fails."""

    pass
