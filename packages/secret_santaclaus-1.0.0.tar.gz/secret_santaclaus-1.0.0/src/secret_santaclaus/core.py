"""Defines the `Model` class as a frontend for most functionality."""

import secret_santaclaus.model as model
import secret_santaclaus.solvers as solvers
from secret_santaclaus.typing import (
    NodeType,
    BipartiteNode,
    Solver,
)

import networkx as nx

import matplotlib.pyplot as plt
import matplotlib.axes

import pydantic

import itertools
import pathlib
import yaml
from collections.abc import (
    Iterable,
    Container,
)
from typing import Self


class ModelError(Exception):
    """Exception raised by `Model` for internal runtime errors."""
    pass


class Model[Node: NodeType]:
    """Main frontend class for Secret Santa functionality.

    This comprises a graphlike representation of a given Secret Santa problem instance (i.e. a set of participants and
    constraints) with NetworkX, and provides a frontend `solve` method to generate solutions, as well as methods for
    drawing both the model graph and factor graph using Matplotlib.
    """
    def __init__(
            self,
            participants: Iterable[Node],
            exclude: Container[tuple[Node, Node]] | Iterable[tuple[Node, Node]] | None = None,
        ):
        """Construct a Secret Santa `Model`.

        The `participants` can be any valid NetworkX graph node type, i.e. they must be hashable (defined by
        `secret_santaclaus.typing.NodeType`). For example, strings are hashable, and are likely the most intuitive
        representation to choose (e.g. representing the participants' names).

        Args:
            participants: Collection of participants in this Secret Santa.
            exclude: Collection of directed edges between participants to forbid in solutions. Defaults to None.
        """
        self._participants: list[Node] = list(participants)

        # Prepare model as a complete graph, then remove edges
        edges_complete = itertools.permutations(participants, 2)
        if exclude is not None:
            edges_complete = (edge for edge in edges_complete
                              if edge not in exclude)

        self._model_graph: nx.DiGraph[Node] = nx.DiGraph(edges_complete)

        # Calculate bipartite factor graph
        self._factor_graph: nx.DiGraph[BipartiteNode[Node]] = model.factor_graph(self._model_graph)

    @property
    def participants(self) -> list[Node]:
        """List of participants in this Secret Santa."""
        return self._participants

    @property
    def model_graph(self) -> nx.DiGraph[Node]:
        """Directed graph representing the participant constraint model (as provided to `__init__`)."""
        return self._model_graph

    @property
    def factor_graph(self) -> nx.DiGraph[BipartiteNode[Node]]:
        """Bipartite factorisation of `model_graph`."""
        return self._factor_graph

    def solve(
            self,
            solver: Solver[BipartiteNode[Node]] = solvers.mcmc,
            **kwargs: object,
        ) -> set[tuple[Node, Node]]:
        """Generate a valid Secret Santa allocation solution on this model.

        A valid solution is a vertex cycle cover on the model graph, which is equivalent to a perfect matching on the
        corresponding bipartite factor graph. The given solver callable is therefore used to generate a solution on this
        `factor_graph`.

        The solution returned is a set of `(u, v)` directed edges, where `u` has been allocated as `v`'s Secret Santa,
        i.e. `v` is the recipient of a gift from `u`.

        The default solver, `solvers.mcmc`, provides a valid solution which should be near-uniformly randomly sampled,
        whilst respecting the constraints given. This uses a Markov chain Monte Carlo method for bipartite perfect
        matchings given in Jerrum and Sinclair (1989) (https://doi.org/10.1137/0218077).

        Args:
            solver: Callable used to generate solution. Defaults to `solvers.mcmc`.
            **kwargs: Keyword arguments passed to the `solver` callable.

        Raises:
            ModelError: If `solver` returned an invalid solution.

        Returns:
            A single solution, i.e. a set of directed edges.
        """
        solution_edges = solver(self.factor_graph, **kwargs)

        if not nx.is_perfect_matching(self.factor_graph, solution_edges):
            raise ModelError("Solution returned by solver is not a perfect matching.")

        # Remove bipartite indices from returned solution
        solution = {(u[0], v[0]) for u, v in solution_edges}
        return solution

    def draw_model_graph(
            self,
            ax: matplotlib.axes.Axes | None = None,
            solution: set[tuple[Node, Node]] | None = None,
            with_labels: bool = True,
            rad: float = 0.05,
        ) -> None:
        """Draw the model graph.

        Args:
            ax: Matplotlib axes to draw to, or current axes if None. Defaults to None.
            solution: Solution to highlight on the graph. Defaults to None.
            with_labels: If True, include the identity of each node as a label. Defaults to True.
            rad: Arc rounding radius on directed edges. Defaults to 0.05.
        """
        if ax is None:
            ax = plt.gca()

        # Use networkx's default spring layout, but with a fixed seed for reproducibility
        layout = nx.spring_layout(self.model_graph, seed=0)

        # Colour solution edges
        edgelist: list[tuple[Node, Node]] = list(self.model_graph.edges())
        edge_color = None
        if solution is not None:
            edge_color = ["red" if edge in solution else "lightgrey"
                          for edge in edgelist]

        nx.draw(
            self.model_graph,
            ax=ax,
            with_labels=with_labels,
            pos=layout,
            connectionstyle=f"arc3,rad={rad}",
            edge_color=edge_color if edge_color is not None else "k",
        )

    def draw_factor_graph(
            self,
            ax: matplotlib.axes.Axes | None = None,
            solution: set[tuple[Node, Node]] | None = None,
            with_labels: bool = True,
        ) -> None:
        """Draw the bipartite factor graph.

        Args:
            ax: Matplotlib axes to draw to, or current axes if None. Defaults to None.
            solution: Solution to highlight on the graph. Defaults to None.
            with_labels: If True, include the identity of each node as a label. Defaults to True.
        """
        if ax is None:
            ax = plt.gca()

        # Convert solution to factor graph representation and colour solution edges
        edgelist: list[tuple[BipartiteNode[Node], BipartiteNode[Node]]] = list(self.factor_graph.edges())
        edge_color = None
        if solution is not None:
            solution_factor = {((u, 0), (v, 1)) for u, v in solution}
            edge_color = ["red" if edge in solution_factor else "lightgrey"
                          for edge in edgelist]

        nx.draw(
            self.factor_graph,
            ax=ax,
            with_labels=with_labels,
            pos=model.factor_graph_layout(self.factor_graph),
            edge_color=edge_color if edge_color is not None else "k",
        )


class ModelConfig(pydantic.BaseModel):
    """Data structure representing a Secret Santa configuration (i.e. participants/constraints)."""
    participants: dict[str, str]
    exclude: list[tuple[str, str]]

    @classmethod
    def from_yaml_file(cls, path: pathlib.Path | str) -> Self:
        """Construct a `ModelConfig` from a YAML file.

        Args:
            path: YAML file to load.

        Returns:
            `ModelConfig` validated from YAML data.
        """
        with open(path, "r") as file:
            data: dict[str, object] = yaml.safe_load(file)  # pyright: ignore[reportAny]
        return cls.model_validate(data)

    def to_model(self) -> Model[str]:
        """Construct a `Model` from this `ModelConfig`.

        Returns:
            `Model` constructed from this data.
        """
        return Model(self.participants.keys(), self.exclude)


def solution_to_yaml_file[Node: NodeType](
        solution: set[tuple[Node, Node]],
        path: pathlib.Path | str,
    ) -> None:
    """Save a solution to a YAML file.

    Args:
        solution: Solution to save.
        path: YAML file to save.
    """
    solution_yaml = [[u, v] for u, v in solution]
    with open(path, "w") as file:
        yaml.dump(solution_yaml, file, default_flow_style=None)


def solution_from_yaml_file(
        path: pathlib.Path | str,
    ) -> set[tuple[str, str]]:
    """Load a solution from a YAML file.

    Note that this will just load the node types as strings.

    Args:
        path: YAML file to load.

    Returns:
        Loaded solution.
    """
    with open(path, "r") as file:
        data: list[list[str]] = yaml.safe_load(file)  # pyright: ignore[reportAny]
    return {(t[0], t[1]) for t in data}
