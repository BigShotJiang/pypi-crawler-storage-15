"""Secret Santa organiser with MCMC random sampling of arbitrary constraints and email utilities."""

# networkx classes don't inherit from Generic so are not subscriptable, despite generic stubs.
# We solve this for now by monkeypatching __class_getitem__ onto the base Graph class manually.
import networkx as nx
setattr(nx.Graph, "__class_getitem__", classmethod(lambda cls, _: "nx.Graph"))  # pyright: ignore[reportUnknownArgumentType,reportUnknownLambdaType]


from secret_santaclaus.core import (  # noqa: E402
    ModelError as ModelError,
    Model as Model,
    ModelConfig as ModelConfig,
    solution_to_yaml_file as solution_to_yaml_file,
    solution_from_yaml_file as solution_from_yaml_file,
)
