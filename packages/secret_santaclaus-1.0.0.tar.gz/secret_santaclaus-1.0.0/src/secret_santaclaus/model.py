"""Defines the fundamental model of the Secret Santa problem representation."""

from secret_santaclaus.typing import (
    NPVector,
    NodeType,
    BipartiteNode,
)

import networkx as nx
import numpy as np

from collections.abc import Generator


def bipartite_lhs[Node: NodeType](g: nx.Graph[Node]) -> Generator[Node]:
    """Iterate nodes in the left-hand side of a bipartite graph.

    By convention, this is defined by an entry of `bipartite`=`0` in the node data.

    Args:
        g: Bipartite graph.

    Yields:
        Each node in the LHS.
    """
    yield from (node for node, data in g.nodes.items() if data["bipartite"] == 0)


def bipartite_rhs[Node: NodeType](g: nx.Graph[Node]) -> Generator[Node]:
    """Iterate nodes in the right-hand side of a bipartite graph.

    By convention, this is defined by an entry of `bipartite`=`1` in the node data.

    Args:
        g: Bipartite graph.

    Yields:
        Each node in the LHS.
    """
    yield from (node for node, data in g.nodes.items() if data["bipartite"] == 1)


def factor_graph[Node: NodeType](g: nx.DiGraph[Node]) -> nx.DiGraph[BipartiteNode[Node]]:
    """Factorise a directed graph into a bipartite representation.

    Each node in the directed graph `g` is copied into both left-hand and right-hand sides of the factor graph. Each
    edge between nodes `u`->`v` in `g` is then represented as an edge from `u` in the left-hand side to `v` in the
    right-hand side of the factor graph.

    Args:
        g: Directed graph.

    Returns:
        Bipartite factor graph.
    """
    # Initialise bipartite graph with every node appearing on both sides
    g_b: nx.DiGraph[BipartiteNode[Node]] = nx.DiGraph()
    g_b.add_nodes_from(((node, 0) for node in g.nodes), bipartite=0)
    g_b.add_nodes_from(((node, 1) for node in g.nodes), bipartite=1)

    # Populate edges between LHS and RHS
    for u, v in g.edges:
        g_b.add_edge((u, 0), (v, 1))

    return g_b


def factor_graph_layout[Node: NodeType](
        g: nx.DiGraph[BipartiteNode[Node]],
    ) -> dict[BipartiteNode[Node], NPVector[np.float64]]:
    """Obtain a layout for nodes suitable for drawing a `factor_graph`.

    This layout is based on `networkx.bipartite_layout`, but ensures that the order of nodes is the same along both
    left-hand and right-hand sides.

    Args:
        g: Directed graph.

    Returns:
        Mapping of nodes to a 2-dimensional position.
    """
    layout = nx.bipartite_layout(g, list(bipartite_lhs(g)))
    for node in bipartite_rhs(g):
        layout[node][1] = layout[(node[0], 0)][1]
    return layout
