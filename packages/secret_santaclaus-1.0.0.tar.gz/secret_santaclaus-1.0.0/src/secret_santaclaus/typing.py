"""Type-checker definitions used throughout this package."""

import numpy as np
import networkx as nx

from collections.abc import (
    Hashable,
    Callable,
)


type NPVector[T: np.generic] = np.ndarray[tuple[int], np.dtype[T]]
"""1-dimensional NumPy array with dtype `T`."""


type NodeType = Hashable
"""NetworkX node value type, which can be anything hashable."""


type BipartiteNode[Node: NodeType] = tuple[Node, int]
"""Node type incorporating bipartite set membership as an integer (`0`/`1`)."""


type Solver[Node: NodeType] = Callable[[nx.DiGraph[Node]], set[tuple[Node, Node]]]
"""A solver is any callable which takes a directed graph and returns a set of edges as a solution."""
