"""Solver callables responsible for generating Secret Santa solutions."""

import secret_santaclaus.model as model
from secret_santaclaus.typing import NodeType

import networkx as nx
import networkx.algorithms.matching as matching

import numpy as np

import math
import logging


LOGGER = logging.getLogger(__name__)


def optimal_matching[Node: NodeType](
        g: nx.DiGraph[Node],
        **_: object,
    ) -> set[tuple[Node, Node]]:
    """Find a solution by a minimum-weight perfect matching algorithm.

    This does suffice as a valid Secret Santa allocation; however, unlike in many matching problems, the matching does
    not need be optimal. It is more desirable to find random solutions, so this function is more useful in providing
    an initial state for stochastic approaches.

    Args:
        g: Bipartite directed graph.

    Returns:
        Solution (perfect matching on `g`).
    """
    matching_dict = nx.bipartite.minimum_weight_full_matching(g, model.bipartite_lhs(g))
    matching_edges = matching.matching_dict_to_set(matching_dict)
    return matching_edges


def mcmc[Node: NodeType](
        g: nx.DiGraph[Node],
        bias: float = 0.005,
        p_self_loop: float = 0.5,
        **_: object,
    ) -> set[tuple[Node, Node]]:
    """Find a solution by a Markov chain Monte Carlo (MCMC) method.

    This samples a perfect matching on bipartite graphs near-uniformly at random, following the approach given by
    Jerrum and Sinclair (1989) (https://doi.org/10.1137/0218077).

    Args:
        g: Bipartite directed graph.
        bias: Allowable bias from a uniform distribution, affecting when the algorithm can terminate. Defaults to 0.005.
        p_self_loop: Probability of maintaining state in each MCMC iteration. Defaults to 0.5.

    Returns:
        Solution (perfect matching on `g`).
    """
    rng = np.random.default_rng()
    edges: list[tuple[Node, Node]] = list(g.edges())

    # Calculate a perfect matching as an initial state
    initial_state: set[tuple[Node, Node]] = optimal_matching(g)
    state: set[tuple[Node, Node]] = initial_state

    # The maximum matching weight is the number of vertices in each bipartite set
    # (this therefore represents a perfect matching)
    n = g.number_of_nodes() // 2
    k_max = n

    # Also maintain a matching dictionary
    pairing: dict[Node, Node] = {}
    for u, v in state:
        pairing[u] = v
        pairing[v] = u

    # The mixing time gives the minimum number of iterations
    # For this problem, it is upper-bounded by poly(n, lg(1/bias))
    mixing_time = math.pow(n, math.log(1 / bias))

    LOGGER.info(f"n: {n}")
    LOGGER.info(f"self-loop probability: {p_self_loop}")
    LOGGER.info(f"bias: {bias}")
    LOGGER.info(f"mixing time: {mixing_time}")

    i = 0
    while i < mixing_time or not nx.is_perfect_matching(g, state):
        i += 1

        # With the self-loop probability, the state remains the same
        if rng.binomial(1, p_self_loop):
            continue

        # Choose an edge in the graph uniformly at random
        e_index = rng.integers(len(edges))
        e = edges[e_index]
        u, v = e

        # Weight of matching (such that k=k_max implies a perfect matching)
        k = len(state)

        if nx.is_matching(g, state):
            # If state is a perfect matching containing e, remove e (type 1 transition)
            if k == k_max and e in state:
                state.remove(e)
                del pairing[u]
                del pairing[v]
                continue
            elif k == k_max - 1:
                # If state is a near-perfect matching NOT containing u or v, add e (type 2 transition)
                if u not in pairing and v not in pairing:
                    state.add(e)
                    pairing[u] = v
                    pairing[v] = u
                    continue
                # If state is a near-perfect matching containing ONE of u or v, move to e (type 0 transition)
                if (u in pairing) ^ (v in pairing):
                    if u in pairing:
                        w = pairing[u]
                        state.remove((u, w))
                    else:
                        w = pairing[v]
                        state.remove((w, v))
                    del pairing[w]

                    state.add(e)
                    pairing[u] = v
                    pairing[v] = u
                    continue

    LOGGER.info(f"number of iterations: {i}")

    return state
