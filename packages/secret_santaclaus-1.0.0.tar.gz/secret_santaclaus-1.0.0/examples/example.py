"""Python script demonstrating basic usage of the `secret_santaclaus` package."""

# matplotlib uses Any in function parameters
# pyright: reportUnknownMemberType=false

import secret_santaclaus
import secret_santaclaus.mailing

import matplotlib.pyplot as plt

import itertools
import logging


# ---------------------------------------------------------------------------------------------------------------------
# Optional: Set logging level to see more detailed output
logging.basicConfig(level=logging.INFO)


# ---------------------------------------------------------------------------------------------------------------------
# Define the Secret Santa model

# Define all participant names and email addresses
participants = {
    "Alice": "alice@email.com",
    "Bob": "bob@email.com",
    "Charlie": "charlie@email.com",
    "Dan": "dan@email.com",
    "Eve": "eve@email.com",
    "Frank": "frank@email.com",
}

# Couples are forbidden from getting each other (that would be boring!)
couples = [
    ("Alice", "Bob"),
    ("Charlie", "Dan"),
    ("Eve", "Frank"),
]

# Exclude all couples in both directions
exclude = [(a, b)
            for couple in couples
            for a, b in itertools.permutations(couple, 2)]

# Construct the Secret Santa model
model = secret_santaclaus.Model(participants.keys(), exclude)


# Alternatively, load participants from a YAML file
# model_config = secret_santaclaus.ModelConfig.from_yaml_file("model-config.yaml")
# model = model_config.to_model()


# ---------------------------------------------------------------------------------------------------------------------
# Display the model and find a solution

# Plot model graph
_ = plt.figure()
model.draw_model_graph()

# Plot factor graph
_ = plt.figure()
model.draw_factor_graph()

# Obtain and display a solution
solution = model.solve()

_ = plt.figure()
model.draw_model_graph(solution=solution)

_ = plt.figure()
model.draw_factor_graph(solution=solution)

print("Solution:")
for u, v in solution:
    print(f"{u} -> {v}")

plt.show()


# ---------------------------------------------------------------------------------------------------------------------
# Save the solution to a file

secret_santaclaus.solution_to_yaml_file(solution, "solution.yaml")

# Which can later be loaded again with:
# solution = secret_santaclaus.solution_from_yaml_file("solution.yaml")


# ---------------------------------------------------------------------------------------------------------------------
# Email each participant their allocated recipient

config = secret_santaclaus.mailing.EmailConfig.from_yaml_file("email-config.yaml")
secret_santaclaus.mailing.send_solution(solution, participants, config)


# Alternatively, having loaded participants from a YAML file:
# secret_santaclaus.mailing.send_solution(solution, model_config.participants, config)
