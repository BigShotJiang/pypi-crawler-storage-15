def main():
    print("Hello from ttyd-over-terminal!")


if __name__ == "__main__":
    main()
