from enum import IntEnum


class Priority(IntEnum):
    """Used priority."""
    NORMAL = 0
    HIGH = 1
