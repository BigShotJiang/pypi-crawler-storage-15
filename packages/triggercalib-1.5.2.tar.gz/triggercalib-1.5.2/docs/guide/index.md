# TriggerCalib user guide

Welcome to the TriggerCalib user guide.
Here you will find information on setting up TriggerCalib, on how trigger efficiencies are calculated at LHCb, and how to use TriggerCalib to calculate trigger efficiencies.

