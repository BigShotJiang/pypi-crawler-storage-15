class TransferProperties(object):
    chunk_size: int = None
    file_max_attempts: int = None
