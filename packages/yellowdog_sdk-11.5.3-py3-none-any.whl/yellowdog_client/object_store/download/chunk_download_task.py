from yellowdog_client.object_store.abstracts import AbstractChunkDownloadTask


class ChunkDownloadTask(AbstractChunkDownloadTask):
    pass
