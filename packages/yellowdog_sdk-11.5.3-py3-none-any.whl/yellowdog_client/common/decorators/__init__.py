from .dispatcher import dispatch_async


__all__ = [
    "dispatch_async"
]
