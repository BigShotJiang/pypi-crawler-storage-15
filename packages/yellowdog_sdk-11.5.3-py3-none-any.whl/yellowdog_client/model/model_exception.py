from dataclasses import dataclass


@dataclass
class ModelException:
    pass
