from dataclasses import dataclass


@dataclass
class WorkerPoolProperties:
    pass
