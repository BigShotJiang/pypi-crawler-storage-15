from dataclasses import dataclass


@dataclass
class TaskDataInput:
    source: str
    destination: str
