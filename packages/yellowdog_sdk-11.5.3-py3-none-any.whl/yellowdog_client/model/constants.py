from dataclasses import dataclass


@dataclass
class Constants:
    pass
