from dataclasses import dataclass


@dataclass
class Named:
    """Interface implemented by all model types that have a name field"""
    pass
