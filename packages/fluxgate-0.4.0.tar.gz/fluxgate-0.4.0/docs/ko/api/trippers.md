# API: Tripper

이 페이지는 사용 가능한 Tripper를 문서화합니다. Tripper는 `window`의 Metric을 평가하여 회로가 상태를 변경해야 하는지 결정하는 역할을 합니다.

Tripper 선택 및 조합에 대한 개요는 [Tripper 컴포넌트 가이드](../components/trippers.md)를 참조하십시오.

---

::: fluxgate.trippers.Closed

::: fluxgate.trippers.HalfOpened

::: fluxgate.trippers.MinRequests

::: fluxgate.trippers.FailureRate

::: fluxgate.trippers.AvgLatency

::: fluxgate.trippers.SlowRate
