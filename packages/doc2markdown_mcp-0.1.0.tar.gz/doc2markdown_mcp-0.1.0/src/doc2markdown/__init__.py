"""doc2markdown - MCP server for converting documents to Markdown format."""

__version__ = "0.1.0"

