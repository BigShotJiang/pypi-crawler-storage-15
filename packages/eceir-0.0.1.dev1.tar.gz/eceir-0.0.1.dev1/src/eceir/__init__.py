"""
The Eceitix Cataclysm
=====================

A programmatic psychological thriller.

"""

from . import Cataclysm


__all__ = ["cataclysm"]

