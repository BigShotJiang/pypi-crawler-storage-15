To install as a CLI tool:

```bash
uv tool install mkapidocs
```

To add to your project dependencies:

```bash
uv add mkapidocs
```

To add as a development dependency:

```bash
uv add --dev mkapidocs
```
