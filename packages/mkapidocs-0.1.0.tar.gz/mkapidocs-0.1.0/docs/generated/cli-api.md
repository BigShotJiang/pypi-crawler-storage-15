# CLI Reference

Command-line interface documentation for mkapidocs.

## Commands

<!-- prettier-ignore -->
::: mkdocs-typer2
    :module: mkapidocs.cli
    :name: mkapidocs
