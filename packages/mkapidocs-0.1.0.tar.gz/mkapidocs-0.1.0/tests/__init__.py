"""Test suite for mkapidocs - Automated documentation setup tool."""
