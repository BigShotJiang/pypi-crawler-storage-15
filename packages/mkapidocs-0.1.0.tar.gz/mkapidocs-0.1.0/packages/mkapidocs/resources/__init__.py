"""Resources package for mkapidocs."""
