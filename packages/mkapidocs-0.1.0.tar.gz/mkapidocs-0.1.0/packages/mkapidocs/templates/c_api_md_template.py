"""C API template."""

C_API_MD_TEMPLATE = """# C API Reference

Documentation generated from C source files using Doxygen.

{{ '{{' }} mkdoxy('{{ project_name }}') {{ '}}' }}
"""
