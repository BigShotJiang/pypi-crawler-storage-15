"""Module containing the bootstrap app."""
