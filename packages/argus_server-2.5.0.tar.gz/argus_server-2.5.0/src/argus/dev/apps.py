from django.apps import AppConfig


class ArgusDevutilsConfig(AppConfig):
    name = "argus.dev"
    label = "argus_dev"
