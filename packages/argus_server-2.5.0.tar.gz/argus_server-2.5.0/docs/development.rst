===========
Development
===========


.. toctree::

   development/notes
   development/management-commands
   development/makefile-rules
   development/howtos
   development/styleguide
   development/troubleshooting
