# -*- coding: utf-8 -*-
from .custom_task import create_celery_custom_task_class

__all__ = ["create_celery_custom_task_class"]
