# -*- coding: utf-8 -*-
from .singleton_class import SingletonMeta

__all__ = [
    "SingletonMeta",
]
