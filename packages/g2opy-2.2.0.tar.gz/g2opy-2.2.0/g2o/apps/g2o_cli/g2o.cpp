// g2o - General Graph Optimization
// Copyright (C) 2011 R. Kuemmerle, G. Grisetti, W. Burgard
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
// * Redistributions of source code must retain the above copyright notice,
//   this list of conditions and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright
//   notice, this list of conditions and the following disclaimer in the
//   documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
// IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
// TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
// PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
// LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

#include <algorithm>
#include <cassert>
#include <csignal>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <string_view>

#include "CLI/CLI.hpp"
#include "dl_wrapper.h"
#include "g2o/core/batch_stats.h"
#include "g2o/core/estimate_propagator.h"
#include "g2o/core/factory.h"
#include "g2o/core/hyper_dijkstra.h"
#include "g2o/core/io/io_format.h"
#include "g2o/core/optimization_algorithm.h"
#include "g2o/core/optimization_algorithm_factory.h"
#include "g2o/core/robust_kernel.h"
#include "g2o/core/robust_kernel_factory.h"
#include "g2o/core/sparse_optimizer.h"
#include "g2o/core/sparse_optimizer_terminate_action.h"
#include "g2o/stuff/filesys_tools.h"
#include "g2o/stuff/logger.h"
#include "g2o/stuff/macros.h"
#include "g2o/stuff/timeutil.h"
#include "g2o_common.h"

namespace {
bool hasToStop = false;

void sigquit_handler(int sig) {
  if (sig == SIGINT) {
    hasToStop = true;
    static int cnt = 0;
    if (cnt++ == 2) {
      G2O_WARN("forcing exit");
      exit(1);
    }
  }
}

g2o::io::Format guessIOFormat(const std::string_view filename) {
  const std::string file_extension = g2o::getFileExtension(filename);
  if (file_extension.empty()) {
    return g2o::io::Format::kG2O;
  }
  return g2o::io::formatForFileExtension(file_extension)
      .value_or(g2o::io::Format::kG2O);
}
}  // namespace

using g2o::HyperGraph;
using g2o::OptimizableGraph;
using g2o::OptimizationAlgorithmFactory;
using g2o::SparseOptimizer;

using std::cerr;
using std::cout;

// sort according to max id, dimension
struct IncrementalEdgesCompare {
  bool operator()(const std::shared_ptr<SparseOptimizer::Edge>& e1,
                  const std::shared_ptr<SparseOptimizer::Edge>& e2) {
    auto to1 = std::static_pointer_cast<const SparseOptimizer::Vertex>(
        e1->vertices()[1]);
    auto to2 = std::static_pointer_cast<const SparseOptimizer::Vertex>(
        e2->vertices()[1]);

    int i11 = e1->vertices()[0]->id();
    int i12 = e1->vertices()[1]->id();
    if (i11 > i12) {
      std::swap(i11, i12);
    }
    int i21 = e2->vertices()[0]->id();
    int i22 = e2->vertices()[1]->id();
    if (i21 > i22) {
      std::swap(i21, i22);
    }
    if (i12 < i22) return true;
    if (i12 > i22) return false;
    // push the odometry to be the first
    return to1->dimension() > to2->dimension();
  }
};

int main(int argc, char** argv) {
  OptimizableGraph::initMultiThreading();
  int maxIterations = 5;
  bool verbose = false;
  std::string inputFilename;
  std::string outputfilename;
  std::string solverProperties;
  std::string strSolver = "gn_var";
  std::string loadLookup;
  bool initialGuess = false;
  bool initialGuessOdometry = false;
  bool marginalize = false;
  bool listTypes = false;
  bool listSolvers = false;
  bool listRobustKernels = false;
  bool incremental = false;
  int gaugeId = -1;
  std::string robustKernel;
  bool computeMarginals = false;
  bool printSolverProperties = false;
  double huberWidth = -1.;
  double gain = 1e-6;
  int maxIterationsWithGain = std::numeric_limits<int>::max();
  // double lambdaInit;
  int updateGraphEachN = 10;
  std::string statsFile;
  std::string summaryFile;
  bool nonSequential = false;
  // command line parsing
  std::vector<int> gaugeList;

#ifndef G2O_DISABLE_DYNAMIC_LOADING_OF_LIBRARIES
  // registering all the types from the libraries
  g2o::DlWrapper dlTypesWrapper;
  g2o::loadStandardTypes(dlTypesWrapper, argc, argv);
  // register all the solvers
  g2o::DlWrapper dlSolverWrapper;
  g2o::loadStandardSolver(dlSolverWrapper, argc, argv);
#else
  if (verbose) cout << "# linked version of g2o\n";
#endif

  const std::vector<std::string> available_solvers = []() {
    std::vector<std::string> solvers;
    solvers.reserve(
        OptimizationAlgorithmFactory::instance()->creatorList().size());
    for (const auto& creator :
         OptimizationAlgorithmFactory::instance()->creatorList()) {
      solvers.emplace_back(creator->property().name);
    }
    return solvers;
  }();

  CLI::App app{"g2o's CLI"};
  argv = app.ensure_utf8(argv);

  app.add_option("-i,--iterations", maxIterations,
                 "perform n iterations, if negative consider the gain")
      ->check(CLI::Range(-1, 100000))
      ->capture_default_str();
  app.add_option("--gain", gain, "the gain used to stop optimization");
  app.add_option("--iterations_gain", maxIterationsWithGain,
                 "Maximum number of iterations with gain enabled");
  app.add_flag("-v", verbose, "verbose output of the optimization process");
  app.add_flag("--guess", initialGuess, "initial guess based on spanning tree");
  app.add_flag("--guess_odometry", initialGuessOdometry,
               "initial guess based on odometry");
  app.add_flag("--inc", incremental, "run incrementally");
  app.add_option("--update", updateGraphEachN,
                 "updates after x odometry nodes");
  app.add_flag("--marginalize", marginalize, "marginalize landmarks");
  app.add_flag("--print_solver_properties", printSolverProperties,
               "print the properties of the solver");
  app.add_option("--solver_properties", solverProperties,
                 "set the internal properties of a solver, e.g., "
                 "initialLambda=0.0001,maxTrialsAfterFailure=2");
  app.add_option("--robust_kernel", robustKernel,
                 "use this robust error function");
  app.add_option("--robust_kernel_width", huberWidth,
                 "width for the robust Kernel (only if robustKernel)");
  app.add_flag(
      "--compute_marginals", computeMarginals,
      "computes the marginal covariances of something. FOR TESTING ONLY");
  app.add_option("--gauge_id", gaugeId, "force the gauge");
  app.add_option("-o,--output", outputfilename,
                 "output final version of the graph");
  app.add_option("--solver", strSolver,
                 "specify which solver to use underneath")
      ->check(CLI::IsMember(available_solvers));
#ifndef G2O_DISABLE_DYNAMIC_LOADING_OF_LIBRARIES
  std::string dummy;
  app.add_option("--solverlib", dummy,
                 "specify a solver library which will be loaded");
  app.add_option("--typeslib", dummy,
                 "specify a types library which will be loaded");
#endif
  app.add_option("--stats", statsFile, "specify a file for the statistics");
  app.add_flag("--list_types", listTypes, "list the registered types");
  app.add_flag("--list_robust_kernels", listRobustKernels,
               "list the registered robust kernels");
  app.add_flag("--list_solvers", listSolvers, "list the available solvers");
  app.add_option("--rename_types", loadLookup,
                 "create a lookup for loading types into other types, "
                 "TAG_IN_FILE=INTERNAL_TAG_FOR_TYPE,TAG2=INTERNAL2, e.g., "
                 "VERTEX_CAM=VERTEX_SE3:EXPMAP");
  app.add_option("--gauge_list", gaugeList,
                 "set the list of gauges separated by commas without spaces, "
                 "e.g: 1 2 3 4 5");
  app.add_option(
      "--summary", summaryFile,
      "append a summary of this optimization run to the summary file "
      "passed as argument");
  app.add_flag(
      "--non_sequential", nonSequential,
      "apply the robust kernel only on loop closures and not odometries");
  app.add_option("input", inputFilename, "graph file which will be processed")
      ->check(CLI::ExistingFile);

  CLI11_PARSE(app, argc, argv);

  OptimizationAlgorithmFactory* solverFactory =
      OptimizationAlgorithmFactory::instance();
  if (listSolvers) {
    solverFactory->listSolvers(cout);
  }

  if (listTypes) {
    g2o::Factory::instance()->printRegisteredTypes(cout, true);
  }

  if (listRobustKernels) {
    std::vector<std::string> kernels;
    g2o::RobustKernelFactory::instance()->fillKnownKernels(kernels);
    cout << "Robust Kernels:\n";
    for (auto& kernel : kernels) {
      cout << kernel << '\n';
    }
  }

  SparseOptimizer optimizer;
  optimizer.setVerbose(verbose);
  optimizer.setForceStopFlag(&hasToStop);

  if (maxIterations < 0) {
    cerr
        << "# setup termination criterion based on the gain of the iteration\n";
    maxIterations = maxIterationsWithGain;
    auto terminateAction =
        std::make_shared<g2o::SparseOptimizerTerminateAction>();
    terminateAction->setGainThreshold(gain);
    terminateAction->setMaxIterations(maxIterationsWithGain);
    optimizer.addPostIterationAction(terminateAction);
  }

  // allocating the desired solver + testing whether the solver is okay
  g2o::OptimizationAlgorithmProperty solverProperty;
  optimizer.setAlgorithm(solverFactory->construct(strSolver, solverProperty));
  if (!optimizer.solver()) {
    cerr << "Error allocating solver. Allocating \"" << strSolver
         << "\" failed!\n";
    return 0;
  }

  if (!solverProperties.empty()) {
    bool updateStatus =
        optimizer.solver()->updatePropertiesFromString(solverProperties);
    if (!updateStatus) {
      cerr << "Failure while updating the solver properties from the given "
              "string\n";
    }
  }
  if (!solverProperties.empty() || printSolverProperties) {
    optimizer.solver()->printProperties(cerr);
  }

  // Loading the input data
  if (!loadLookup.empty()) {
    optimizer.setRenamedTypesFromString(loadLookup);
  }
  if (inputFilename.empty()) {
    cerr << "No input data specified\n";
    return 0;
  }
  if (inputFilename == "-") {
    cerr << "Read input from stdin\n";
    if (!optimizer.load(std::cin)) {
      cerr << "Error loading graph\n";
      return 2;
    }
  } else {
    const g2o::io::Format input_format = guessIOFormat(inputFilename);
    cerr << "Read input from " << inputFilename << " as "
         << g2o::io::to_string(input_format) << '\n';
    std::ifstream ifs(inputFilename.c_str());
    if (!ifs) {
      cerr << "Failed to open file\n";
      return 1;
    }
    if (!optimizer.load(ifs, input_format)) {
      cerr << "Error loading graph\n";
      return 2;
    }
  }
  cerr << "Loaded " << optimizer.vertices().size() << " vertices\n";
  cerr << "Loaded " << optimizer.edges().size() << " edges\n";

  if (optimizer.vertices().empty()) {
    cerr << "Graph contains no vertices\n";
    return 1;
  }

  std::unordered_set<int> vertexDimensions = optimizer.dimensions();
  if (!optimizer.isSolverSuitable(solverProperty, vertexDimensions)) {
    cerr << "The selected solver is not suitable for optimizing the given "
            "graph\n";
    return 3;
  }
  assert(optimizer.solver());
  // optimizer.setMethod(str2method(strMethod));
  // optimizer.setUserLambdaInit(lambdaInit);

  // check for vertices to fix to remove DoF
  bool gaugeFreedom = optimizer.gaugeFreedom();
  std::shared_ptr<OptimizableGraph::Vertex> gauge;
  if (!gaugeList.empty()) {
    cerr << "Fixing gauges: ";
    for (size_t i = 0; i < gaugeList.size(); i++) {
      int id = gaugeList[i];
      auto v = optimizer.vertex(id);
      if (!v) {
        cerr << "fatal, not found the vertex of id " << id
             << " in the gaugeList. Aborting";
        return -1;
      }
      if (i == 0) gauge = v;
      cerr << v->id() << " ";
      v->setFixed(true);
    }
    cerr << '\n';
    gaugeFreedom = false;
  } else {
    gauge = optimizer.findGauge();
  }
  if (gaugeFreedom) {
    if (!gauge) {
      cerr << "# cannot find a vertex to fix in this thing\n";
      return 2;
    }
    cerr << "# graph is fixed by node " << gauge->id() << '\n';
    gauge->setFixed(true);

  } else {
    cerr << "# graph is fixed by priors or already fixed vertex\n";
  }

  // if schur, we wanna marginalize the landmarks...
  if (marginalize || solverProperty.requiresMarginalize) {
    const int maxDim =
        *std::max_element(vertexDimensions.begin(), vertexDimensions.end());
    const int minDim =
        *std::min_element(vertexDimensions.begin(), vertexDimensions.end());
    if (maxDim != minDim) {
      cerr << "# Preparing Marginalization of the Landmarks ... ";
      for (auto& it : optimizer.vertices()) {
        auto v = std::static_pointer_cast<OptimizableGraph::Vertex>(it.second);
        if (v->dimension() != maxDim) {
          v->setMarginalized(true);
        }
      }
      cerr << "done.\n";
    }
  }

  if (!robustKernel.empty()) {
    g2o::AbstractRobustKernelCreator::Ptr creator =
        g2o::RobustKernelFactory::instance()->creator(robustKernel);
    cerr << "# Preparing robust error function ... ";
    g2o::RobustKernelPtr robustKernel = creator->construct();
    if (huberWidth > 0) robustKernel->setDelta(huberWidth);
    if (creator) {
      if (nonSequential) {
        for (const auto& it : optimizer.edges()) {
          auto e = std::dynamic_pointer_cast<SparseOptimizer::Edge>(it);
          if (e->vertices().size() >= 2 &&
              std::abs(e->vertex(0)->id() - e->vertex(1)->id()) != 1) {
            e->setRobustKernel(robustKernel);
          }
        }
      } else {
        for (const auto& it : optimizer.edges()) {
          auto e = std::dynamic_pointer_cast<SparseOptimizer::Edge>(it);
          e->setRobustKernel(robustKernel);
        }
      }
      cerr << "done.\n";
    } else {
      cerr << "Unknown Robust Kernel: " << robustKernel << '\n';
    }
  }

  // sanity check
  auto optimizerWrapper =
      std::shared_ptr<HyperGraph>(&optimizer, [](HyperGraph*) {});
  g2o::HyperDijkstra d(optimizerWrapper);
  g2o::UniformCostFunction f;
  d.shortestPaths(gauge, f);
  // cerr << PVAR(d.visited().size()) << '\n';

  if (d.visited().size() != optimizer.vertices().size()) {
    cerr << "Warning: d.visited().size() != optimizer.vertices().size()"
         << '\n';
    cerr << "visited: " << d.visited().size() << '\n';
    cerr << "vertices: " << optimizer.vertices().size() << '\n';
  }

  if (incremental) {
    cerr << "# Note: this variant performs batch steps in each time step"
         << '\n';
    cerr << "#       For a variant which updates the Cholesky factor use "
            "the binary g2o_incremental"
         << '\n';
    int incIterations = maxIterations;
    int maxDim = 0;

    cerr << "# incremental settings\n";
    cerr << "#\t solve every " << updateGraphEachN << '\n';
    cerr << "#\t iterations  " << incIterations << '\n';

    SparseOptimizer::VertexIDMap vertices = optimizer.vertices();
    for (auto& vertex : vertices) {
      const auto* v =
          static_cast<SparseOptimizer::Vertex*>(vertex.second.get());
      maxDim = std::max(maxDim, v->dimension());
    }

    SparseOptimizer::EdgeContainer edges;
    for (const auto& it : optimizer.edges()) {
      edges.emplace_back(std::dynamic_pointer_cast<SparseOptimizer::Edge>(it));
    }
    optimizer.edges().clear();
    optimizer.vertices().clear();
    optimizer.setVerbose(false);

    // sort the edges in a way that inserting them makes sense
    sort(edges.begin(), edges.end(), IncrementalEdgesCompare());

    double cumTime = 0.;
    int vertexCount = 0;
    int lastOptimizedVertexCount = 0;
    bool freshlyOptimized = false;
    bool firstRound = true;
    HyperGraph::VertexSet verticesAdded;
    HyperGraph::EdgeSet edgesAdded;
    for (auto& e : edges) {
      int doInit = 0;
      auto v1 = optimizer.vertex(e->vertices()[0]->id());
      auto v2 = optimizer.vertex(e->vertices()[1]->id());

      if (!v1) {
        auto v = v1 = std::dynamic_pointer_cast<SparseOptimizer::Vertex>(
            e->vertices()[0]);
        bool v1Added = optimizer.addVertex(v);
        // cerr << "adding" << v->id() << "(" << v->dimension() << ")\n";
        assert(v1Added);
        if (!v1Added)
          cerr << "Error adding vertex " << v->id() << '\n';
        else
          verticesAdded.insert(v);
        doInit = 1;
        if (v->dimension() == maxDim) vertexCount++;
      }

      if (!v2) {
        auto v = v2 = std::dynamic_pointer_cast<SparseOptimizer::Vertex>(
            e->vertices()[1]);
        bool v2Added = optimizer.addVertex(v);
        // cerr << "adding" << v->id() << "(" << v->dimension() << ")\n";
        assert(v2Added);
        if (!v2Added)
          cerr << "Error adding vertex " << v->id() << '\n';
        else
          verticesAdded.insert(v);
        doInit = 2;
        if (v->dimension() == maxDim) vertexCount++;
      }

      // adding the edge and initialization of the vertices
      {
        // cerr << " adding edge " << e->vertices()[0]->id() <<  " " <<
        // e->vertices()[1]->id() << '\n';
        if (!optimizer.addEdge(e)) {
          cerr << "Unable to add edge " << e->vertices()[0]->id() << " -> "
               << e->vertices()[1]->id() << '\n';
        } else {
          edgesAdded.insert(e);
        }

        if (doInit) {
          auto from = std::static_pointer_cast<OptimizableGraph::Vertex>(
              e->vertices()[0]);
          auto to = std::static_pointer_cast<OptimizableGraph::Vertex>(
              e->vertices()[1]);
          switch (doInit) {
            case 1:  // initialize v1 from v2
            {
              HyperGraph::VertexSet toSet;
              toSet.insert(to);
              if (e->initialEstimatePossible(toSet, from.get()) > 0.) {
                // cerr << "init: "
                //<< to->id() << "(" << to->dimension() << ") -> "
                //<< from->id() << "(" << from->dimension() << ") \n";
                e->initialEstimate(toSet, from.get());
              } else {
                assert(0 && "Added uninitialized variable to the graph");
              }
              break;
            }
            case 2: {
              HyperGraph::VertexSet fromSet;
              fromSet.insert(from);
              if (e->initialEstimatePossible(fromSet, to.get()) > 0.) {
                // cerr << "init: "
                //<< from->id() << "(" << from->dimension() << ") -> "
                //<< to->id() << "(" << to->dimension() << ") \n";
                e->initialEstimate(fromSet, to.get());
              } else {
                assert(0 && "Added uninitialized variable to the graph");
              }
              break;
            }
            default:
              cerr << "doInit wrong value\n";
          }
        }
      }

      freshlyOptimized = false;
      {
        // cerr << "Optimize\n";
        if (vertexCount - lastOptimizedVertexCount >= updateGraphEachN) {
          if (firstRound) {
            if (!optimizer.initializeOptimization()) {
              cerr << "initialization failed\n";
              return 0;
            }
          } else {
            if (!optimizer.updateInitialization(verticesAdded, edgesAdded)) {
              cerr << "updating initialization failed\n";
              return 0;
            }
          }
          verticesAdded.clear();
          edgesAdded.clear();
          double ts = g2o::get_monotonic_time();
          int currentIt = optimizer.optimize(incIterations, !firstRound);
          double dts = g2o::get_monotonic_time() - ts;
          cumTime += dts;
          firstRound = false;
          // optimizer->setOptimizationTime(cumTime);
          if (verbose) {
            double chi2 = optimizer.chi2();
            cerr << "nodes= " << optimizer.vertices().size()
                 << "\t edges= " << optimizer.edges().size()
                 << "\t chi2= " << chi2 << "\t time= " << dts
                 << "\t iterations= " << currentIt << "\t cumTime= " << cumTime
                 << '\n';
          }
          lastOptimizedVertexCount = vertexCount;
          freshlyOptimized = true;
        }

        if (!verbose) cerr << ".";
      }

    }  // for all edges

    if (!freshlyOptimized) {
      double ts = g2o::get_monotonic_time();
      int currentIt = optimizer.optimize(incIterations, !firstRound);
      double dts = g2o::get_monotonic_time() - ts;
      cumTime += dts;
      // optimizer->setOptimizationTime(cumTime);
      if (verbose) {
        double chi2 = optimizer.chi2();
        cerr << "nodes= " << optimizer.vertices().size()
             << "\t edges= " << optimizer.edges().size() << "\t chi2= " << chi2
             << "\t time= " << dts << "\t iterations= " << currentIt
             << "\t cumTime= " << cumTime << '\n';
      }
    }

  } else {
    // BATCH optimization

    if (!statsFile.empty()) {
      // allocate buffer for statistics;
      optimizer.setComputeBatchStatistics(true);
    }
    optimizer.initializeOptimization();
    optimizer.computeActiveErrors();
    double loadChi = optimizer.chi2();
    cerr << "Initial chi2 = " << FIXED(loadChi) << '\n';

    if (initialGuess) {
      optimizer.computeInitialGuess();
    } else if (initialGuessOdometry) {
      g2o::EstimatePropagatorCostOdometry costFunction(&optimizer);
      optimizer.computeInitialGuess(costFunction);
    }
    double initChi = optimizer.chi2();

    signal(SIGINT, sigquit_handler);
    int result = optimizer.optimize(maxIterations);
    if (maxIterations > 0 && result == g2o::OptimizationAlgorithm::kFail) {
      cerr << "Cholesky failed, result might be invalid\n";
    } else if (computeMarginals) {
      std::vector<std::pair<int, int> > blockIndices;
      for (const auto& v : optimizer.activeVertices()) {
        if (v->hessianIndex() >= 0) {
          blockIndices.emplace_back(v->hessianIndex(), v->hessianIndex());
        }
        if (v->hessianIndex() > 0) {
          blockIndices.emplace_back(v->hessianIndex() - 1, v->hessianIndex());
        }
      }
      g2o::SparseBlockMatrix<Eigen::MatrixXd> spinv;
      if (optimizer.computeMarginals(spinv, blockIndices)) {
        for (const auto& v : optimizer.activeVertices()) {
          cerr << "Vertex id:" << v->id() << '\n';
          if (v->hessianIndex() >= 0) {
            cerr << "inv block :" << v->hessianIndex() << ", "
                 << v->hessianIndex() << '\n';
            cerr << *(spinv.block(v->hessianIndex(), v->hessianIndex()));
            cerr << '\n';
          }
          if (v->hessianIndex() > 0) {
            cerr << "inv block :" << v->hessianIndex() - 1 << ", "
                 << v->hessianIndex() << '\n';
            cerr << *(spinv.block(v->hessianIndex() - 1, v->hessianIndex()));
            cerr << '\n';
          }
        }
      }
    }

    optimizer.computeActiveErrors();
    double finalChi = optimizer.chi2();

    if (!summaryFile.empty()) {
      g2o::PropertyMap summary;
      summary.makeProperty<g2o::StringProperty>("filename", inputFilename);
      summary.makeProperty<g2o::IntProperty>("n_vertices",
                                             optimizer.vertices().size());
      summary.makeProperty<g2o::IntProperty>("n_edges",
                                             optimizer.edges().size());

      int nLandmarks = 0;
      int nPoses = 0;
      const int maxDim =
          *std::max_element(vertexDimensions.begin(), vertexDimensions.end());
      for (auto& it : optimizer.vertices()) {
        auto v = std::static_pointer_cast<OptimizableGraph::Vertex>(it.second);
        if (v->dimension() != maxDim) {
          nLandmarks++;
        } else
          nPoses++;
      }
      std::set<std::string> edgeTypes;
      for (const auto& it : optimizer.edges()) {
        edgeTypes.insert(g2o::Factory::instance()->tag(it.get()));
      }
      std::stringstream edgeTypesString;
      for (const auto& edgeType : edgeTypes) {
        edgeTypesString << edgeType << " ";
      }

      summary.makeProperty<g2o::IntProperty>("n_poses", nPoses);
      summary.makeProperty<g2o::IntProperty>("n_landmarks", nLandmarks);
      summary.makeProperty<g2o::StringProperty>("edge_types",
                                                edgeTypesString.str());
      summary.makeProperty<g2o::DoubleProperty>("load_chi", loadChi);
      summary.makeProperty<g2o::StringProperty>("solver", strSolver);
      summary.makeProperty<g2o::BoolProperty>("robustKernel",
                                              !robustKernel.empty());
      summary.makeProperty<g2o::DoubleProperty>("init_chi", initChi);
      summary.makeProperty<g2o::DoubleProperty>("final_chi", finalChi);
      summary.makeProperty<g2o::IntProperty>("maxIterations", maxIterations);
      summary.makeProperty<g2o::IntProperty>("realIterations", result);
      std::ofstream os;
      os.open(summaryFile.c_str(), std::ios::app);
      summary.writeToCSV(os);
    }

    if (!statsFile.empty()) {
      cerr << "writing stats to file \"" << statsFile << "\" ... ";
      std::ofstream os(statsFile.c_str());
      const g2o::BatchStatisticsContainer& bsc = optimizer.batchStatistics();

      for (int i = 0; i < maxIterations; i++) {
        os << bsc[i] << '\n';
      }
      cerr << "done.\n";
    }
  }

  if (!outputfilename.empty()) {
    if (outputfilename == "-") {
      cerr << "saving to stdout";
      optimizer.save(cout);
    } else {
      const g2o::io::Format output_format = guessIOFormat(outputfilename);
      cerr << "saving " << outputfilename << " in "
           << g2o::io::to_string(output_format) << " ... ";
      optimizer.save(outputfilename.c_str(), output_format);
    }
    cerr << "done.\n";
  }

  return 0;
}
