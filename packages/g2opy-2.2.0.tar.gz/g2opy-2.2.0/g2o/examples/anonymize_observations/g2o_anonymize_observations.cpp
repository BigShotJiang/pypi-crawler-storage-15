// g2o - General Graph Optimization
// Copyright (C) 2011 G. Grisetti, R. Kuemmerle, W. Burgard
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
// * Redistributions of source code must retain the above copyright notice,
//   this list of conditions and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright
//   notice, this list of conditions and the following disclaimer in the
//   documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
// IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
// TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
// PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
// LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

#include <cstdlib>
#include <fstream>
#include <iostream>

#include "CLI/CLI.hpp"
#include "g2o/core/optimizable_graph.h"
#include "g2o/types/slam2d/edge_se2.h"
#include "g2o/types/slam2d/edge_se2_offset.h"
#include "g2o/types/slam2d/edge_se2_pointxy.h"
#include "g2o/types/slam2d/edge_se2_pointxy_bearing.h"
#include "g2o/types/slam2d/edge_se2_pointxy_offset.h"

namespace g2o {

namespace {

template <typename T>
bool anonymizeLandmarkEdge(const std::shared_ptr<HyperGraph::Edge>& e_,
                           OptimizableGraph& g) {
  auto e = std::dynamic_pointer_cast<T>(e_);
  if (!e) return false;
  g.setEdgeVertex(e, 1, nullptr);
  return true;
}

template <typename T>
bool anonymizePoseEdge(const std::shared_ptr<HyperGraph::Edge>& e_,
                       OptimizableGraph& g) {
  auto e = std::dynamic_pointer_cast<T>(e_);
  if (!e) return false;
  auto from = e->vertex(0);
  auto to = e->vertex(1);
  if (from && to && from != to) {
    int deltaId = abs(from->id() - to->id());
    if (deltaId > 1) {
      if (from->id() > to->id()) {
        g.setEdgeVertex(e, 0, nullptr);
      } else {
        g.setEdgeVertex(e, 1, nullptr);
      }
      return true;
    }
  }
  return false;
}

}  // namespace

}  // namespace g2o

int main(int argc, char** argv) {
  CLI::App app{"g2o's Anonymizer"};
  argv = app.ensure_utf8(argv);
  std::string outputFilename = "anon.g2o";
  std::string inputFilename;
  app.add_option("-o,--output", outputFilename,
                 "output final version of the graph");
  app.add_option("graph-input", inputFilename, "graph file which will be read")
      ->required();
  CLI11_PARSE(app, argc, argv);

  g2o::OptimizableGraph graph;

  if (inputFilename.empty()) {
    std::cerr << "No input data specified\n";
    return 0;
  }
  if (inputFilename == "-") {
    std::cerr << "Read input from stdin\n";
    if (!graph.load(std::cin)) {
      std::cerr << "Error loading graph\n";
      return 2;
    }
  } else {
    std::cerr << "Read input from " << inputFilename << '\n';
    std::ifstream ifs(inputFilename.c_str());
    if (!ifs) {
      std::cerr << "Failed to open file\n";
      return 1;
    }
    if (!graph.load(ifs)) {
      std::cerr << "Error loading graph\n";
      return 2;
    }
  }

  for (auto it = graph.edges().begin(); it != graph.edges().end(); ++it) {
    const auto& e = *it;
    // clang-format off
    if (g2o::anonymizeLandmarkEdge<g2o::EdgeSE2PointXY>(e, graph)) continue;
    if (g2o::anonymizeLandmarkEdge<g2o::EdgeSE2PointXYOffset>(e, graph)) continue;
    if (g2o::anonymizeLandmarkEdge<g2o::EdgeSE2PointXYBearing>(e, graph)) continue;
    if (g2o::anonymizePoseEdge<g2o::EdgeSE2>(e, graph)) continue;
    if (g2o::anonymizePoseEdge<g2o::EdgeSE2Offset>(e, graph)) continue;
    // clang-format on
  }

  std::ofstream os(outputFilename.c_str());
  graph.save(os);
}
