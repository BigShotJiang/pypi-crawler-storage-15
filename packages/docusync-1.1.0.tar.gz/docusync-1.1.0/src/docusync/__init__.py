"""DocuSync - Documentation synchronization tool for Docusaurus sites."""

__version__ = "1.1.0"
