from __future__ import annotations

from .core import command, register

__all__ = ["command", "register"]


