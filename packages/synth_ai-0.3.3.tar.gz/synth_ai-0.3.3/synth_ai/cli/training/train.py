from __future__ import annotations

from synth_ai.cli.commands.train.core import register, train_command

__all__ = ["register", "train_command"]
