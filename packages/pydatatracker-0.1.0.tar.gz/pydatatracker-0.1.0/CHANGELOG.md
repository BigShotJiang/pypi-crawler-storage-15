# Changelog

## [0.2.0] - 2025-11-23
- Added change history helpers (`last_change`, `changes_since`).
- Made snapshots/stack capture opt-in and introduced `tracking_actor` context manager.
- Provided `ChangeCollector`, logging/JSON observer examples, and benchmarking command.
- Added debugging cookbook and packaging docs.
