from. autoencoder import FCN1D, FCN2D, FCN3D, SmoothFCN1D, SmoothFCN2D, SmoothFCN3D, FourierFCN1D, FourierFCN2D, FourierFCN3D
from .autoencoder import Unet1D, Unet2D, Unet3D, SmoothUnet1D, SmoothUnet2D, SmoothUnet3D, FourierUnet1D, FourierUnet2D, FourierUnet3D

from .neural_operator import NeuralOperator1D, NeuralOperator2D, NeuralOperator3D

from .tsmixer import TSMixer