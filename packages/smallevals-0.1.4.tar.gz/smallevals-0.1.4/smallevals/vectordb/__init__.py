"""Vector database integration module."""

from smallevals.vdb_integrations.base import BaseVDBConnection

__all__ = ["BaseVDBConnection"]

