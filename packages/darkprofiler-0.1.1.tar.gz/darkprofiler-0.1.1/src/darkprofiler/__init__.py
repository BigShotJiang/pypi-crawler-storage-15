from .run import classify_peptides

__all__ = ["classify_peptides"]

__version__ = "0.1.1"

