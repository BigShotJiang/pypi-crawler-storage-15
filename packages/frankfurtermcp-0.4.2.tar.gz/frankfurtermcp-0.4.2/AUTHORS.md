The Frankfurter MCP project was created in June 2025 by Anirban Basu.

Core maintainers:
 - Anirban Basu

For a complete list of contributors, see:
https://github.com/anirbanbasu/frankfurtermcp/graphs/contributors
