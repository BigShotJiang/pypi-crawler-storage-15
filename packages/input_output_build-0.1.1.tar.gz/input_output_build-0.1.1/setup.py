import setuptools
from drm_protect import main

setuptools.setup()
