from .transcriber import IndicTranscriber

__version__ = "0.1.1"

__all__ = ["IndicTranscriber", "__version__"]
