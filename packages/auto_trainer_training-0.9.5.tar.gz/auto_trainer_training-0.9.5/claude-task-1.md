There is a test class TestTrainingPlan in the current project.  It is intended to test each phase defined in the mock sample-protocol.json.  There is currently one test that has started to test the first phase "Reach A".  Testing of that phase is currently incomplete.

Before starting a session w/the algorithm, it should confirm that all of the properties of the training phase are set to the proper values from the json file, or to their defaults if not present in the json file.

After session_processing_ending, and the transition to the next phase, it should could that all of the properties of the training phase "Reach B" are set to the proper values from the json file, or to their defaults if not present in the json file.
