# DocFind

A powerful cross-platform document indexing and search tool with both CLI and GUI interfaces.

## Features

- **Full-text search** using SQLite FTS5 for blazing-fast queries
- **Multi-format support**: PDF, DOCX, XLSX, PPTX, HTML, XML, and plain text
- **Unknown format handling**: Hex extraction for files with unrecognized formats
- **Ripgrep integration**: Optional integration with ripgrep for enhanced search
- **CLI and GUI**: Professional command-line and PyQt5 desktop interfaces
- **Cross-platform**: Works on Windows, macOS, and Linux
- **Thread-safe indexing**: Efficient multi-threaded document processing
- **Dark theme**: Modern, accessible dark UI with customizable accent colors

## Installation

### Prerequisites

- Python 3.8 or higher
- (Optional) [ripgrep](https://github.com/BurntSushi/ripgrep) for enhanced search

### Install from source

```bash
# Clone the repository
git clone https://github.com/CihanMertDeniz/docfind.git
cd docfind

# Install in development mode
pip install -e .

# Or install with development dependencies
pip install -e ".[dev]"
```

### Install from PyPI (when published)

```bash
pip install docfind
```

## Quick Start

### CLI Usage

#### Index documents

```bash
# Index a directory
docfind index /path/to/documents

# Index with progress display
docfind index /path/to/documents --progress

# Reindex existing documents
docfind index /path/to/documents --reindex

# Use multiple threads (default: 4)
docfind index /path/to/documents --threads 8

# Set maximum file size (in bytes)
docfind index /path/to/documents --max-size 52428800  # 50MB
```

#### Search documents

```bash
# Basic search
docfind search "python programming"

# Case-sensitive search
docfind search "Python" --case-sensitive

# Regex search
docfind search "func.*\(" --regex

# Whole word search
docfind search "test" --whole-word

# Use ripgrep for searching
docfind search "error" --use-ripgrep

# JSON output (JSONL format)
docfind search "data" --json

# Limit results
docfind search "query" --limit 50

# Filter by root path
docfind search "term" --root /path/to/documents
```

#### List indexed paths

```bash
# Show all indexed paths
docfind list

# JSON output
docfind list --json
```

#### Show statistics

```bash
# Display database statistics
docfind stats

# JSON output
docfind stats --json
```

#### Explain queries or documents

```bash
# Explain how a query would be executed
docfind explain --query "search term"

# Explain a specific document
docfind explain --path /path/to/file.pdf

# Show extracted text preview
docfind explain --path /path/to/file.pdf --show-text
```

#### Remove indexed data

```bash
# Remove specific root path
docfind remove --path /path/to/documents

# Remove all indexed data
docfind remove --all --force
```

#### Optimize database

```bash
# Optimize FTS index and vacuum database
docfind optimize
```

#### System check

```bash
# Check system configuration and dependencies
docfind doctor
```

### GUI Usage

Launch the GUI application:

```bash
docfind-gui
```

#### GUI Features

**Main Window Layout:**

```
┌─────────────────────────────────────────────────────────────┐
│ File  Tools  Help                                           │
├───────────┬─────────────────────────────────┬───────────────┤
│           │ [Search...] [Options] [Actions] │               │
│ Projects  ├─────────────────────────────────┤ File Details  │
│           │                                 │               │
│ • /docs/  │      Results Table              │ Path: ...     │
│   (1234)  │                                 │ Type: pdf     │
│           │  Path | Type | Line | Snippet  │ Size: 2.3 MB  │
│ • /work/  │  ─────┼──────┼──────┼────────  │               │
│   (567)   │  ...  │ pdf  │  42  │ text..  │ [Actions]     │
│           │                                 │               │
│ [Add]     │                                 │ • Open Folder │
│ [Remove]  │      Preview / Text             │ • Copy Path   │
│           │                                 │ • Export      │
│           │  Extracted text with            │               │
│           │  highlighted matches...         │               │
│           │                                 │               │
├───────────┴─────────────────────────────────┴───────────────┤
│ [Progress Bar]                                              │
│ Log Console:                                                │
│ [12:34:56] [INFO] Indexing started...                       │
└─────────────────────────────────────────────────────────────┘
```

**Keyboard Shortcuts:**

- `Ctrl+F` - Focus search box
- `Ctrl+I` - Add folder to index
- `Ctrl+E` - Export results
- `Ctrl+,` - Open settings
- `Ctrl+Q` - Quit

**Workflow:**

1. **Add a folder**: Click "Add Folder" → Select directory → Index starts automatically
2. **Search**: Type in search box → Results appear in real-time (debounced)
3. **View results**: Click result → See details and preview with highlighted matches
4. **Export**: Select results → Click "Export Results" → Save as JSONL

**Settings:**

Access via `File → Settings`:

- Number of indexing threads
- Maximum file size to index
- Trust external conversion tools
- Ripgrep path
- UI accent color

## Supported File Formats

### Native Support

| Format | Extensions | Extractor |
|--------|-----------|-----------|
| PDF | `.pdf` | pdfminer.six |
| Word | `.docx` | python-docx |
| Excel | `.xlsx` | openpyxl |
| PowerPoint | `.pptx` | python-pptx |
| HTML | `.html`, `.htm` | beautifulsoup4 |
| XML | `.xml` | beautifulsoup4 |
| Text | `.txt`, `.md`, `.rst`, `.log` | Native |
| Source Code | `.py`, `.js`, `.java`, `.c`, `.cpp`, `.h`, `.cs`, `.go`, `.rs`, `.rb`, `.php`, `.sh`, `.bat`, `.ps1` | Native |
| Data | `.json`, `.csv` | Native |

### Fallback Support

For unknown file formats, DocFind uses **hex extraction** to extract readable ASCII/UTF-16 text strings from binary files.

### Legacy Formats

- `.doc`, `.xls`, `.ppt` - Extracted via hex extractor (native support requires external tools)

## Architecture

### Core Components

```
docfind/
├── cli.py          # Command-line interface
├── gui.py          # PyQt5 GUI application
├── db.py           # SQLite database with FTS5
├── indexer.py      # Document indexing engine
├── search.py       # Search engine (FTS5 + ripgrep)
├── hex_extractor.py # Binary text extraction
├── utils.py        # Utilities and configuration
├── ui/             # GUI components
│   ├── dialogs.py
│   └── main_window.py
├── resources/      # UI resources
│   ├── qss/        # Stylesheets
│   └── icons/      # Icons
└── tests/          # Unit tests
```

### Database Schema

**documents table:**
- Stores file metadata (path, type, size, hash, mtime)
- Links to extracted text

**documents_fts (FTS5 virtual table):**
- Full-text search index
- Uses Porter stemming and Unicode tokenization

**extracted_text table:**
- Stores complete extracted text for preview

### Threading Model (GUI)

- **Main Thread**: UI updates, user interaction
- **IndexWorker Thread**: Document indexing (emits progress signals)
- **SearchWorker Thread**: Search operations (emits result signals)
- **Database Access**: Thread-local connections with transaction locking

## Configuration

Configuration is stored in platform-specific locations:

- **Windows**: `%APPDATA%\docfind\config.json`
- **macOS**: `~/Library/Application Support/docfind/config.json`
- **Linux**: `~/.config/docfind/config.json`

### Default Configuration

```json
{
  "max_file_size": 104857600,
  "threads": 4,
  "ignore_globs": [
    "*.pyc",
    "__pycache__",
    ".git",
    ".svn",
    "node_modules",
    ".venv",
    "venv",
    "*.log"
  ],
  "trust_external_tools": false,
  "ripgrep_path": "rg",
  "theme": "dark",
  "accent_color": "#3a7bd5",
  "db_path": "<platform-specific-data-dir>/docfind.db"
}
```

## Development

### Setup Development Environment

```bash
# Clone repository
git clone https://github.com/CihanMertDeniz/docfind.git
cd docfind

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install in editable mode with dev dependencies
pip install -e ".[dev]"
```

### Run Tests

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=docfind --cov-report=html

# Run specific test file
pytest docfind/tests/test_indexer.py

# Run GUI tests (requires X server or Xvfb)
pytest docfind/tests/test_gui_smoke.py
```

### Code Structure Guidelines

- **Type hints**: All functions should have type annotations
- **Docstrings**: Use Google-style docstrings
- **Logging**: Use `logging` module, not `print()`
- **Error handling**: Catch specific exceptions, log appropriately
- **Threading**: Use QThread for GUI, ThreadPoolExecutor for CLI

## Performance Tips

### Indexing

- **Threads**: Use `--threads` to match your CPU cores (default: 4)
- **File size**: Limit with `--max-size` to skip very large files
- **Ignore patterns**: Configure patterns for files/folders to skip
- **Reindex**: Only use `--reindex` when necessary (slower)

### Searching

- **FTS5**: Fast for most queries, supports phrase search
- **Ripgrep**: Faster for simple string matches, regex support
- **Pagination**: Use `--limit` and `--offset` for large result sets
- **Filters**: Use `--root` to narrow search scope

### Database

- **Optimize**: Run `docfind optimize` periodically to compact database
- **Backup**: Database is a single `.db` file - easy to backup
- **Location**: Store on SSD for better performance

## Troubleshooting

### "Database locked" errors

- Close other DocFind instances accessing the same database
- Check for stale lock files
- Increase timeout in db.py (default: 30s)

### "ripgrep not found" warnings

- Install ripgrep: https://github.com/BurntSushi/ripgrep
- Or specify path in config: `"ripgrep_path": "/path/to/rg"`

### GUI doesn't start

- Check PyQt5 installation: `pip install --upgrade PyQt5`
- On Linux, install: `sudo apt-get install python3-pyqt5`
- Check logs: `~/.local/share/docfind/docfind_gui.log` (Linux)

### Extraction fails for PDF/Office files

- Ensure dependencies are installed: `pip install -r requirements.txt`
- For legacy formats (.doc, .xls, .ppt), use hex extraction (automatic fallback)
- Check file isn't corrupted: Try opening in native application

### High memory usage

- Reduce `max_file_size` in config
- Use fewer indexing threads
- Process large directories in smaller batches

## Security Considerations

- **External tools**: Disabled by default (`trust_external_tools: false`)
- **System paths**: GUI warns before indexing system directories
- **Network drives**: Warning displayed before indexing
- **File execution**: DocFind never executes indexed files
- **SQL injection**: Parameterized queries prevent injection

## Contributing

Contributions are welcome! Please:

1. Fork the repository
2. Create a feature branch
3. Add tests for new functionality
4. Ensure all tests pass
5. Submit a pull request

## License

MIT License - see LICENSE file for details.

## Credits

Built with:
- [PyQt5](https://www.riverbankcomputing.com/software/pyqt/) - GUI framework
- [SQLite FTS5](https://www.sqlite.org/fts5.html) - Full-text search
- [pdfminer.six](https://github.com/pdfminer/pdfminer.six) - PDF extraction
- [python-docx](https://python-docx.readthedocs.io/) - DOCX extraction
- [openpyxl](https://openpyxl.readthedocs.io/) - XLSX extraction
- [python-pptx](https://python-pptx.readthedocs.io/) - PPTX extraction
- [BeautifulSoup](https://www.crummy.com/software/BeautifulSoup/) - HTML/XML parsing
- [ripgrep](https://github.com/BurntSushi/ripgrep) - Optional fast search

## Changelog

### Version 1.0.0 (2025-01-30)

- Initial release
- CLI with full indexing and search capabilities
- PyQt5 GUI with dark theme
- Support for PDF, DOCX, XLSX, PPTX, HTML, text files
- Hex extraction for unknown formats
- SQLite FTS5 full-text search
- Optional ripgrep integration
- Cross-platform support (Windows, macOS, Linux)
- Comprehensive test suite
- Thread-safe database access
- Configuration management

## Roadmap

- [ ] Watch mode for automatic reindexing
- [ ] Incremental indexing (skip unchanged files)
- [ ] Advanced search syntax (AND, OR, NOT operators)
- [ ] Export to various formats (CSV, HTML report)
- [ ] Custom extractors plugin system
- [ ] OCR support for scanned documents
- [ ] Encrypted document support
- [ ] Web interface option
- [ ] Docker container
- [ ] Cloud storage integration (S3, Google Drive)

## Support

- **Issues**: https://github.com/CihanMertDeniz/docfind/issues
- **Discussions**: https://github.com/CihanMertDeniz/docfind/discussions
- **Documentation**: https://github.com/CihanMertDeniz/docfind#readme

---

**DocFind** - Find anything in your documents, instantly. 🔍
