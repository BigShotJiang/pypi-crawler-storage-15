"""
docfind: A cross-platform document indexing and search tool.

Provides CLI and GUI interfaces for indexing and searching documents
with support for multiple file formats and full-text search.
"""

__version__ = "1.0.0"
__author__ = "DocFind Team"
