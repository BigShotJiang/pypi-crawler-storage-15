import logging

logging.debug("Initializing security related commands...")
