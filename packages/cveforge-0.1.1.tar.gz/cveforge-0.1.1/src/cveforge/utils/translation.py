from django.utils.translation import gettext

__all__ = ("gettext", )
