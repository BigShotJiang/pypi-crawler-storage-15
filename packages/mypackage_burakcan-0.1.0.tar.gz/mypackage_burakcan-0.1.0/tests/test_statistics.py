# tests/test_statistics.py
from mypackage import mean, median

def test_mean():
    assert mean([1,2,3]) == 2
    assert mean([]) is None

def test_median_odd():
    assert median([3,1,2]) == 2

def test_median_even():
    assert median([1,2,3,4]) == 2.5
