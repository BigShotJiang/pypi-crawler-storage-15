# src/mypackage/statistics.py
from typing import Iterable, Optional

def mean(values: Iterable[float]) -> Optional[float]:
    vals = list(values)
    if not vals:
        return None
    return sum(vals) / len(vals)

def median(values: Iterable[float]) -> Optional[float]:
    vals = sorted(list(values))
    n = len(vals)
    if n == 0:
        return None
    mid = n // 2
    if n % 2 == 1:
        return vals[mid]
    return (vals[mid - 1] + vals[mid]) / 2
