# src/mypackage/__init__.py
from .statistics import mean, median

__all__ = ["mean", "median"]
__version__ = "0.1.0"
