# mypackage

Basit istatistik yardımcı fonksiyonları.

## Kurulum

```bash
pip install mypackage
```

## Kullanım

```python
from mypackage import mean, median

data = [1, 2, 3, 4, 5]
print(mean(data))    # 3.0
print(median(data))  # 3
```

## Fonksiyonlar

- `mean(values)`: Ortalama hesapla
- `median(values)`: Medyan hesapla
