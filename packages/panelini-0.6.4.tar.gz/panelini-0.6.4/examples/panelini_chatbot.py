"""A lightweight example of a Chatbot Panelini application."""
