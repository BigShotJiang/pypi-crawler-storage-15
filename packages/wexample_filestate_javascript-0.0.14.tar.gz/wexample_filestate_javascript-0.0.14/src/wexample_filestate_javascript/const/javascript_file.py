from __future__ import annotations

JAVASCRIPT_FILE_EXTENSIONS = [".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs"]
JAVASCRIPT_FILE_EXTENSION = ".js"
