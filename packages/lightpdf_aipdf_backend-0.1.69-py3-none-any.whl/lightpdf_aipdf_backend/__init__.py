"""LightPDF AI-PDF Backend Package"""

__version__ = "0.1.0"