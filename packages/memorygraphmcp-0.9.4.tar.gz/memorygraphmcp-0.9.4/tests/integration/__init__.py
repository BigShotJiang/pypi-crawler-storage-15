"""Tests for Claude Code integration modules."""
