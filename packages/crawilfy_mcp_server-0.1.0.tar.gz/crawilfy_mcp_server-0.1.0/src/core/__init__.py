"""Core engine components."""


