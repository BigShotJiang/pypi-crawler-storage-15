"""Browser management and automation."""


