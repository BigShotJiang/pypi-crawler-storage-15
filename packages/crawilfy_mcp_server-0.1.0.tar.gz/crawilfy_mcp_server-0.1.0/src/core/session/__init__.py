"""Session and credential management."""


