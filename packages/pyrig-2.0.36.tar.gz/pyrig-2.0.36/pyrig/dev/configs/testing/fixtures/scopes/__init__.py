"""Scope-specific fixture configuration file management.

This package provides ConfigFile subclasses for creating fixture
files for each pytest scope (function, class, module, package, session).
"""
