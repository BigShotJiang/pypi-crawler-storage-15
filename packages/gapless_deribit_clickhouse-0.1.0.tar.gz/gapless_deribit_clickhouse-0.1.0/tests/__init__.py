"""Tests for gapless-deribit-clickhouse."""
