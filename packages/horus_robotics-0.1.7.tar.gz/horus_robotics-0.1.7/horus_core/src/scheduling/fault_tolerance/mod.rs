/// Circuit breaker pattern for fault tolerance
pub mod circuit_breaker;

pub use circuit_breaker::{CircuitBreaker, CircuitState};
