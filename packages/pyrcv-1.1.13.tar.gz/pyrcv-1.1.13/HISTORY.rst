=======
History
=======

1.1.11 (2025-05-15)
------------------

* Dependency updates to fix security vulnerabilities.

1.1.10 (2025-03-20)
------------------

* Fix typo in docs generation.
* Replace deprecated versioning package with supported one.

1.1.9 (2025-03-20)
------------------

* Modernize CI/CD workflow.
* Fix broken docs generation.

1.1.6-1.1.8 (2025-03-11)
------------------

* Dependency updates to fix security vulnerabilities.

1.1.5 (2024-12-31)
------------------

* Dependency updates to fix security vulnerabilities.

1.1.4 (2024-12-31)
------------------

* Dependency updates to fix security vulnerabilities.

1.1.1-1.1.3 (2024-10-14)
------------------

* Fix CI/CD workflow

1.1.0 (2024-10-14)
------------------

* Update #winners regex to handle more cases and be used anywhere.
* Support python 3.12

1.0.3 (2024-05-27)
------------------

* Dependency updates to fix security vulnerabilities.

1.0.2 (2024-01-12)
------------------

* Add privacy policy.
* Better handling of spam on the server.
* Small code cleanups.

1.0.1 (2023-10-04)
------------------

* Major webserver version update.

1.0.0 (2023-10-04)
------------------

* First official release of API, PyPI package, and tabulation server.
