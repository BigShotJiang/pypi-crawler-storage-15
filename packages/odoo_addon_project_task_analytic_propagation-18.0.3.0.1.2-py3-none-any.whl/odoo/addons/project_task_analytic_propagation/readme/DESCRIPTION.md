This module allows you to change the analytic accounts in the timesheet,
regardless of whether it has already been validated or is pending,
when the linked task changes accounts (as happens with an item in a sales order).

In addition, when you change the analytic account for a project,
it is also automatically updated in all its tasks.

When you change the task's project, this project will be propagate to all task's timesheets.