To use this module, you need to:

1. Go to Sales > Order and select an order with a project related.
2. Click on task's smart button and select or create a task.
3. Select any analytic account for any analytic plan in 'Extra Info'.
4. Record some time on timesheets page.
5. On the *Extra Info* tab change the analytic account in any analytic plan.
6. To check this go to Timesheets > All Timesheets.
7. Change to list view and group by Project > Task and add custom group based on your analytic plans.
