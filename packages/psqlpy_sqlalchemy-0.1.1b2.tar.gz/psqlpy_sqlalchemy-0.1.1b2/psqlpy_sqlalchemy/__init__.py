from .dialect import PSQLPyAsyncDialect

PsqlpyDialect = PSQLPyAsyncDialect

__version__ = "0.1.1b2"
__all__ = ["PsqlpyDialect", "PSQLPyAsyncDialect"]
