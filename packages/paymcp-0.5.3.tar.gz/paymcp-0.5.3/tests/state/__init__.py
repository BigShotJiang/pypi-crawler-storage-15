"""Tests for state storage implementations."""
