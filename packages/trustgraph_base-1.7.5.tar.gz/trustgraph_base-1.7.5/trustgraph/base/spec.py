
class Spec:
    pass

