# timifypy

A tiny, clean, and useful timing utility for Python.

Measure execution time effortlessly with a context manager or a manual stopwatch.

---

## 🚀 Installation

```bash
pip install timifypy
