import time
from contextlib import ContextDecorator


def format_time(seconds: float) -> str:
    """Return nicely formatted time with appropriate units."""
    if seconds < 1e-3:
        return f"{seconds * 1e6:.2f} µs"
    elif seconds < 1:
        return f"{seconds * 1e3:.2f} ms"
    else:
        return f"{seconds:.3f} s"


class Stopwatch:
    """A simple manual stopwatch."""

    def __init__(self):
        self._start = None
        self.elapsed = 0.0

    def start(self):
        """Start timing."""
        self._start = time.perf_counter()

    def stop(self):
        """Stop timing and accumulate elapsed time."""
        if self._start is None:
            raise RuntimeError("Stopwatch not started.")
        self.elapsed += time.perf_counter() - self._start
        self._start = None

    def reset(self):
        """Reset the stopwatch."""
        self._start = None
        self.elapsed = 0.0

    def __repr__(self):
        return f"<Stopwatch {format_time(self.elapsed)}>"


class timer(ContextDecorator):
    """A context manager for timing code blocks."""

    def __init__(self, name="timer", log_file=None):
        self.name = name
        self.log_file = log_file

    def __enter__(self):
        self.start = time.perf_counter()
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        duration = time.perf_counter() - self.start
        msg = f"[{self.name}] {format_time(duration)}"
        print(msg)
        if self.log_file:
            with open(self.log_file, "a") as f:
                f.write(msg + "\n")
