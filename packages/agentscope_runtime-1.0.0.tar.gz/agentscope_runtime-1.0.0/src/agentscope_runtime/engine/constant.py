# -*- coding: utf-8 -*-
ALLOWED_FRAMEWORK_TYPES = [
    "text",
    "agentscope",
    "autogen",
    "langgraph",
    "agno",
]
