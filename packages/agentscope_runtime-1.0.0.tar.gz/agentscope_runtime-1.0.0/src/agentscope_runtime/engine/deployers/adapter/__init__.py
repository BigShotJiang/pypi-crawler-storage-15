# -*- coding: utf-8 -*-
from .a2a import A2AFastAPIDefaultAdapter
