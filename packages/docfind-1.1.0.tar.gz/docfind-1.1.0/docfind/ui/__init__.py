"""UI components for DocFind."""
