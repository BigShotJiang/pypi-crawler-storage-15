# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import test_fsm_wizard
from . import test_fsm_equipment
from . import test_fsm_location
from . import test_fsm_person
from . import test_fsm_team
from . import test_fsm_order
from . import test_fsm_order_template_onchange
from . import test_fsm_category
from . import test_res_partner
