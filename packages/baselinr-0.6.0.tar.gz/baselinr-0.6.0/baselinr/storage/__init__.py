"""Storage layer for Baselinr profiling results."""

from .writer import ResultWriter

__all__ = ["ResultWriter"]
