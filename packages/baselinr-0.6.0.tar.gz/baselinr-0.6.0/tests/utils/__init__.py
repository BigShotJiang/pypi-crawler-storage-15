"""
Tests for utility modules.
"""
