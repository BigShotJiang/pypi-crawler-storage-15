# Validator Parameters

When creating a `ValidationColumnConfig`, two parameters are used to define the validator: `validator_type` and `validator_config`.
The `validator_type` parameter can be set to either `code`, `local_callable` or `remote`. The `validator_config` accompanying each of these is, respectively:

::: data_designer.config.validator_params