# Constants defining the shutdown signal actor configuration.
SHUTDOWN_ACTOR_NAME = "ShutdownSignal"
SHUTDOWN_ACTOR_NAMESPACE = "default"
SHUTDOWN_RPC_TIMEOUT_SECONDS = 5.0
