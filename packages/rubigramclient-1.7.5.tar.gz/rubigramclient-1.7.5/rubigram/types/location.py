from dataclasses import dataclass
from .object import Object


@dataclass
class Location(Object):
    """
    **Represents a geographical location.**
        `from rubigram.types import Location`

    Attributes:
        longitude (`str`):
            Longitude of the location.

        latitude (`str`):
            Latitude of the location.
    """
    longitude: str
    latitude: str