from typing import Optional, Union
from dataclasses import dataclass
from ..object import Object
import rubigram


@dataclass
class ButtonSelectionItem(Object):
    """
    **Represents an individual selectable item in a ButtonSelection.**
        `from rubigram.types import ButtonSelectionItem`

    Attributes:
        text (`Optional[str]`):
            The display text of the item.

        image_url (`Optional[str]`):
            Optional URL for an image representing the item.

        type (`Optional[Union[str, rubigram.enums.ButtonSelectionType]]`):
            Type of selection item.
    """
    text: Optional[str] = None
    image_url: Optional[str] = None
    type: Optional[Union[str, "rubigram.enums.ButtonSelectionType"]] = None