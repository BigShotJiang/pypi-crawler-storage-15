from typing import Optional, Union
from dataclasses import dataclass
from .object import Object
import rubigram


@dataclass
class PaymentStatus(Object):
    """
    **Represents the payment status of a transaction in Rubigram.**
        `from rubigram.types import PaymentStatus`

    Tracks the unique payment ID and the current status of the payment.

    Attributes:
        payment_id (`Optional[str]`):
            Unique identifier for the payment.

        status (`Optional[Union[str, rubigram.enums.PaymentStatus]]`):
            Current status of the payment, either as a string or as an enum (Paid, NotPaid).
    """
    payment_id: Optional[str] = None
    status: Optional[Union[str, rubigram.enums.PaymentStatus]] = None