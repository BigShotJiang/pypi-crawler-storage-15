from typing import Optional
from dataclasses import dataclass
from .object import Object
import rubigram


@dataclass
class Poll(Object):
    """
    **Represents a poll in Rubigram.**
        `from rubigram.types import Poll`

    Attributes:
        question (`Optional[str]`):
            The poll question text.

        options (`Optional[list[str]]`):
            List of possible answer options.

        poll_status (`Optional[rubigram.types.PollStatus]`):
            Status information of the poll.
    """
    question: Optional[str] = None
    options: Optional[list[str]] = None
    poll_status: Optional["rubigram.types.PollStatus"] = None