from dataclasses import dataclass, field
from ..object import Object
import rubigram


@dataclass
class KeypadRow(Object):
    """
    **Represents a single row of buttons in a chat keypad.**
        `from rubigram.types import KeypadRow`

    Attributes:
        buttons (`list[rubigram.types.Button]`):
            A list of Button objects in this row.
    """
    buttons: list["rubigram.types.Button"] = field(default_factory=list)