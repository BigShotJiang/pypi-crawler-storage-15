from .enum import Enum


class MessageSender(Enum):
    """
    **Identifies who sent a message.**
        `from rubigram.enums import MessageSender`

    This enum distinguishes between different types of message originators
    in a chat conversation. It helps determine whether a message was sent
    by a human user or an automated bot, which can be useful for applying
    different processing logic, permissions, or display formatting.

    Attributes:
        User: The message was sent by a human user.
              Typically represents real people participating in the conversation.
        Bot: The message was sent by an automated bot or AI agent.
             Usually represents automated services, assistants, or chatbots.
    """
    
    User = "User"
    Bot = "Bot"


class ForwardedFrom(Enum):
    """
    **Indicates the source type of a forwarded message.**
        `from rubigram.enums import ForwardedFrom`

    This enum specifies the type of entity from which a message was originally
    forwarded. It helps identify the nature of the original source when messages
    are shared across different chats, which can affect how the message is
    displayed, what metadata is shown, and what interactions are available.

    Attributes:
        User: The message was originally sent by a human user and forwarded.
              Shows the user's name and allows viewing their profile.
        Bot: The message was originally sent by a bot and forwarded.
             May show the bot's name and specific bot-related interactions.
        Channel: The message was originally posted in a channel and forwarded.
                 Shows the channel name and may include channel-specific metadata.
    """
    
    User = "User"
    Bot = "Bot"
    Channel = "Channel"