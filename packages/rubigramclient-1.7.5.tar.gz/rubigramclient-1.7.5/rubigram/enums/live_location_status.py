from .enum import Enum


class LiveLocationStatus(Enum):
    """
    **Represents the status of a live location message.**
        `from rubigram.enums import LiveLocationStatus`

    This enum defines the states of a real-time location sharing session,
    indicating whether the location is currently being broadcasted live
    or the sharing session has been terminated.

    Attributes:
        Stopped: The live location sharing has been stopped or ended.
                 No further location updates will be broadcasted.
        Live: The location is currently being shared in real-time.
              Continuous location updates are being broadcasted to recipients.
    """

    Stopped = "Stopped"
    Live = "Live"