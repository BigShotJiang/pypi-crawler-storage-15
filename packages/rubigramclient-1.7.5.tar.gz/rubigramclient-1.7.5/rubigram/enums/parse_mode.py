from .enum import Enum


class ParseMode(Enum):
    """
    **Text parsing modes for message formatting.**
        `from rubigram.enums import ParseMode`

    This enum defines the available text parsing modes that can be used
    when sending formatted messages with styles like bold, italic, links, etc.

    Attributes:
        MARKDOWN (`str`):
            Use Markdown formatting syntax (e.g., **bold**, __italic__, [links](url)).

        HTML (`str`):
            Use HTML formatting tags (e.g., <b>bold</b>, <i>italic</i>, <a href="url">link</a>).
    """
    MARKDOWN = "markdown"
    HTML = "html"