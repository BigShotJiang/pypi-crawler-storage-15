from .enum import Enum


class ChatType(Enum):
    """
    **Represents the type of chat (user, bot, group, or channel).**
        `from rubigram.enums import ChatType`

    This enum defines the different types of chat entities in a messaging system.
    Each chat type has distinct characteristics, permissions, and capabilities
    that determine how users can interact with them and what features are available.

    Attributes:
        User: A one-on-one chat with another individual user.
              Private conversations between two people.
        Bot: A chat with an automated bot or AI assistant.
             Typically used for commands, services, or automated interactions.
        Group: A multi-user chat room with multiple participants.
               Supports group administration, permissions, and collaborative features.
        Channel: A broadcast-style chat for one-to-many communication.
                 Typically used for announcements, news, or content distribution.
    """

    User = "User"
    Bot = "Bot"
    Group = "Group"
    Channel = "Channel"


class ChatAction(Enum):
    """
    **Represents chat actions like typing or uploading.**
        `from rubigram.enums import ChatAction`

    This enum defines various real-time user activities that can be displayed
    to other chat participants. These actions provide feedback about what
    users are currently doing in the chat interface.

    Attributes:
        Typing: Indicates that a user is currently composing a text message.
                Shows "typing..." or similar indicator to other participants.
        Uploading: Indicates that a user is currently uploading a file or media.
                   Shows upload progress or status to other participants.
        Recording: Indicates that a user is currently recording audio or video.
                   Shows recording status for voice messages or video clips.
    """

    Typing = "Typing"
    Uploading = "Uploading"
    Recording = "Recording"


class ChatKeypadType(Enum):
    """
    **Represents the type of keypad modification.**
        `from rubigram.enums import ChatKeypadType`

    This enum defines operations for managing custom keypads or interactive
    keyboards in chats. These are typically used for bots to provide
    interactive button interfaces to users.

    Attributes:
        New: Create and display a new custom keypad or interactive keyboard.
              Replaces any existing keypad with a new set of buttons or options.
        Remove: Remove the current custom keypad and restore the default keyboard.
                Returns the chat interface to the standard text input mode.
    """

    New = "New"
    Remove = "Remove"