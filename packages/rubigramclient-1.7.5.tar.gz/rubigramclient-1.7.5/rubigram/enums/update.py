from .enum import Enum


class UpdateType(Enum):
    """
    **Represents the type of update event in the messaging system.**
        `from rubigram.enums import UpdateType`
        
    This enum defines various types of update events that can occur
    in a chat or messaging platform, such as message modifications,
    bot lifecycle events, and payment updates.

    Attributes:
        UpdatedMessage: Indicates an existing message was edited or updated
        NewMessage: Indicates a new message was received
        RemovedMessage: Indicates a message was deleted
        StartedBot: Indicates a bot was started or activated
        StoppedBot: Indicates a bot was stopped or deactivated
        UpdatedPayment: Indicates a payment status was updated
    """

    UpdatedMessage = "UpdatedMessage"
    NewMessage = "NewMessage"
    RemovedMessage = "RemovedMessage"
    StartedBot = "StartedBot"
    StoppedBot = "StoppedBot"
    UpdatedPayment = "UpdatedPayment"


class UpdateEndpointType(Enum):
    """
    **Represents the type of endpoint for handling updates.**
        `from rubigram.enums import UpdateEndpointType`

    This enum defines different endpoints that can process various
    types of incoming updates, including regular messages, inline
    messages, callback queries, and selection interactions.

    Attributes:
        ReceiveUpdate: Endpoint for receiving general updates
        ReceiveInlineMessage: Endpoint for receiving inline messages
        ReceiveQuery: Endpoint for receiving callback queries
        GetSelectionItem: Endpoint for retrieving selection items
        SearchSelectionItems: Endpoint for searching through selection items
    """

    ReceiveUpdate = "ReceiveUpdate"
    ReceiveInlineMessage = "ReceiveInlineMessage"
    ReceiveQuery = "ReceiveQuery"
    GetSelectionItem = "GetSelectionItem"
    SearchSelectionItems = "SearchSelectionItems"