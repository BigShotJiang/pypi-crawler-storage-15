from .enum import Enum


class FileType(Enum):
    """
    **Specifies the type of file sent or received.**
       `from rubigram.enums import FileType`

    This enum categorizes different types of media files that can be
    shared in messaging platforms. Each file type may have specific
    handling, display characteristics, and processing requirements.

    Attributes:
       File: Generic file type for documents, archives, or unspecified files.
              Typically displayed with a generic file icon and download option.
       Image: Still image files (JPEG, PNG, WEBP, etc.).
              Displayed as previewable images with possible compression.
       Video: Video files (MP4, AVI, MOV, etc.).
              Supports playback with controls and may show thumbnails.
       Gif: Animated GIF files.
              Auto-plays in loops without audio, optimized for short animations.
       Music: Audio files intended as music (MP3, FLAC, WAV, etc.).
              Displayed with music player controls and metadata like artist/title.
       Voice: Voice message or short audio recordings.
              Typically displayed with waveform visualization and play button.
    """

    File = "File"
    Image = "Image"
    Video = "Video"
    Gif = "Gif"
    Music = "Music"
    Voice = "Voice"