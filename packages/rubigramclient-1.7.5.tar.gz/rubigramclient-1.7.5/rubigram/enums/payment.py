from .enum import Enum


class PaymentStatus(Enum):
    """
    **Defines the payment state of a transaction.**
        `from rubigram.enums import PaymentStatus`
    
    This enum represents the possible payment statuses for a transaction
    in the payment processing system. It helps track the financial state
    of orders, invoices, and payment requests.
    
    Attributes:
        Paid: The payment has been successfully completed and processed.
              The transaction is fully paid and confirmed.
        NotPaid: The payment has not been made yet or is still pending.
                 The transaction awaits payment completion.
    """
    
    Paid = "Paid"
    NotPaid = "NotPaid"