from .enum import Enum


class PollStatus(Enum):
    """
    **Represents the current status of a poll.**
        `from rubigram.enums import PollStatus`

    This enum defines the possible states of a polling event, indicating
    whether the poll is currently active and accepting votes or has been
    concluded and no longer accepts new votes.

    Attributes:
        Open: The poll is currently active and accepting votes from participants.
              Users can submit their responses and the poll results may change.
        Closed: The poll has been concluded and no longer accepts new votes.
                The results are final and visible to participants.
    """
    
    Open = "Open"
    Closed = "Closed"