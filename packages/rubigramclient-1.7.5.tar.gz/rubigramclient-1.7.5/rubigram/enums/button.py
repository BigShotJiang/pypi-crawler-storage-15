from .enum import Enum


class ButtonType(Enum):
    """
    **Represents the available button types in Rubigram.**
        `from rubigram.enums import ButtonType`

    This enum defines all the interactive button types that can be used
    in Rubigram's interface. Each button type triggers a specific kind
    of user interaction or input method, ranging from simple actions to
    complex data selection and media capture.

    Attributes:
        Simple: A basic button that triggers an immediate action or command.
        Selection: A button that opens a selection menu with multiple options.
        Calendar: A button that opens a date picker interface.
        NumberPicker: A button that opens a number selection interface.
        StringPicker: A button that opens a text selection from predefined options.
        Location: A button for location sharing or selection.
        Payment: A button that initiates a payment process.
        CameraImage: A button that opens camera to capture an image.
        CameraVideo: A button that opens camera to record a video.
        GalleryImage: A button that opens gallery to select an image.
        GalleryVideo: A button that opens gallery to select a video.
        File: A button that opens file browser to select any file.
        Audio: A button that opens audio file selector.
        RecordAudio: A button that starts audio recording.
        MyPhoneNumber: A button that shares the user's phone number.
        MyLocation: A button that shares the user's current location.
        Textbox: A button that opens a text input field.
        Link: A button that opens a URL or performs navigation.
        AskMyPhoneNumber: A button that requests the user's phone number.
        AskLocation: A button that requests the user's location.
        Barcode: A button that opens barcode/qr code scanner.
    """
    
    Simple = "Simple"
    Selection = "Selection"
    Calendar = "Calendar"
    NumberPicker = "NumberPicker"
    StringPicker = "StringPicker"
    Location = "Location"
    Payment = "Payment"
    CameraImage = "CameraImage"
    CameraVideo = "CameraVideo"
    GalleryImage = "GalleryImage"
    GalleryVideo = "GalleryVideo"
    File = "File"
    Audio = "Audio"
    RecordAudio = "RecordAudio"
    MyPhoneNumber = "MyPhoneNumber"
    MyLocation = "MyLocation"
    Textbox = "Textbox"
    Link = "Link"
    AskMyPhoneNumber = "AskMyPhoneNumber"
    AskLocation = "AskLocation"
    Barcode = "Barcode"


class ButtonSelectionType(Enum):
    """
    **Specifies how selection buttons display content.**
        `from rubigram.enums import ButtonSelectionType`

    This enum defines the visual presentation styles for selection buttons,
    determining how options are displayed to users when they interact with
    selection-type buttons.

    Attributes:
        TextOnly: Displays selection options as plain text list.
        TextImgThu: Displays options with text and thumbnail images.
        TextImgBig: Displays options with text and large preview images.
    """
    
    TextOnly = "TextOnly"
    TextImgThu = "TextImgThu"
    TextImgBig = "TextImgBig"


class ButtonSelectionSearch(Enum):
    """
    **Defines the search method for selection buttons.**
        `from rubigram.enums import ButtonSelectionSearch`

    This enum specifies how search functionality is implemented for
    selection buttons, determining whether search is performed locally
    or through an API call.

    Attributes:
        Local: Search is performed locally on preloaded data.
        Api: Search is performed by making API calls to external services.
    """
    
    Local = "Local"
    Api = "Api"


class ButtonSelectionGet(Enum):
    """
    **Defines how selection button items are retrieved.**
        `from rubigram.enums import ButtonSelectionGet`

    This enum specifies the data source for selection button items,
    determining whether items are loaded locally or fetched from an API.

    Attributes:
        Local: Selection items are stored and retrieved locally.
        Api: Selection items are fetched from an external API.
    """
    
    Local = "Local"
    Api = "Api"


class ButtonCalendarType(Enum):
    """
    **Defines the type of calendar used in buttons.**
        `from rubigram.enums import ButtonCalendarType`

    This enum specifies the calendar system used for date selection
    in calendar buttons, supporting different cultural calendar systems.

    Attributes:
        DatePersian: Uses the Persian (Jalali) calendar system.
        DateGregorian: Uses the Gregorian (international) calendar system.
    """
    
    DatePersian = "DatePersian"
    DateGregorian = "DateGregorian"


class ButtonTextboxTypeKeypad(Enum):
    """
    **Specifies the input type for textbox keypad buttons.**
        `from rubigram.enums import ButtonTextboxTypeKeypad`

    This enum defines the keyboard type shown when users interact with
    textbox buttons, optimizing the input method for different data types.

    Attributes:
        String: Shows standard text keyboard for string input.
        Number: Shows numeric keypad for number input.
    """
    
    String = "String"
    Number = "Number"


class ButtonTextboxTypeLine(Enum):
    """
    **Defines how textbox buttons handle text input.**
        `from rubigram.enums import ButtonTextboxTypeLine`

    This enum specifies the text input behavior for textbox buttons,
    determining whether users can input single or multiple lines of text.

    Attributes:
        SingleLine: Allows only single line text input.
        MultiLine: Allows multiple lines of text input with line breaks.
    """
    
    SingleLine = "SingleLine"
    MultiLine = "MultiLine"


class ButtonLocationType(Enum):
    """
    **Represents the location button behavior.**
        `from rubigram.enums import ButtonLocationType`

    This enum defines the interaction mode for location buttons,
    specifying whether users can pick a location or only view one.

    Attributes:
        Picker: Allows users to select or pick a location on map.
        View: Only displays a location without interaction.
    """
    
    Picker = "Picker"
    View = "View"