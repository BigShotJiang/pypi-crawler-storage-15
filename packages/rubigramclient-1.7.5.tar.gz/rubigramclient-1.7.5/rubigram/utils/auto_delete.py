import asyncio
import rubigram
import logging


logger = logging.getLogger(__name__)


class AutoDelete:
    @staticmethod
    def run(client: "rubigram.Client", message: "rubigram.types.UMessage", delay: int):
        if delay <= 0:
            return

        asyncio.create_task(
            AutoDelete.auto_delete_task(client, message, delay)
        )

    @staticmethod
    async def auto_delete_task(client: "rubigram.Client", message: "rubigram.types.UMessage", delay: int):
        try:
            await asyncio.sleep(delay)
            await client.delete_messages(message.chat_id, message.message_id)

        except Exception as error:
            logger.warning(
                "AUTO DELETE MESSAGE(chat_id=%s, message_id=%s, error=%s)", message.chat_id, message.message_id, error
            )