from .auto_delete import AutoDelete
from .parser import Parser


class Utils(
    AutoDelete,
    Parser
):
    pass