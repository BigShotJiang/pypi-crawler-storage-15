from .set_command import SetCommands
from .setup_endpoints import SetupEndpoints
from .update_bot_endpoint import UpdateBotEndpoints


class Settings(
    SetCommands,
    SetupEndpoints,
    UpdateBotEndpoints
):
    pass