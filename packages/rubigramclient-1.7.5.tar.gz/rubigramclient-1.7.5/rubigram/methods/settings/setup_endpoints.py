import rubigram
import logging


logger = logging.getLogger(__name__)


class SetupEndpoints:
    async def setup_endpoints(self: "rubigram.Client"):
        for i in rubigram.enums.UpdateEndpointType:
            type = i.value
            url = f"{self.webhook_url}/{type}"
            set_endpoint = await self.update_bot_endpoints(url, type)
            logger.info(
                "ENDPOINT SET(type=%s, status=%s)", type, set_endpoint["status"]
            )