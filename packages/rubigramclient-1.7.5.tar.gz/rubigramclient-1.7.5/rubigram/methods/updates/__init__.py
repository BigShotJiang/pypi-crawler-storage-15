from .get_update import GetUpdates
from .get_me import GetMe


class Updates(
    GetUpdates,
    GetMe
):
    pass