from typing import Union
import rubigram


class GetFile:
    async def get_file(self: "rubigram.Client", file_id: str) -> Union[str, None]:
        response = await self.request("getFile", {"file_id": file_id})
        return response.get("download_url")