from typing import Optional
import aiofiles
import os
import rubigram


class DownloadFile:
    async def download_file(
        self: "rubigram.Client",
        file_id: str,
        name: Optional[str] = None,
        directory: Optional[str] = None,
        chunk_size: int = 1024
    ) -> str:
        download_url = await self.get_file(file_id)
        
        if not download_url:
            raise ValueError("Invalid download url: %s", file_id)

        filename = name or await self.get_file_name(download_url)

        if not directory is None:
            os.makedirs(directory, exist_ok=True)
            filename = os.path.join(directory, filename)

        async with self.http.session.get(download_url) as response:
            response.raise_for_status()

            async with aiofiles.open(filename, "wb") as file:
                async for chunk in response.content.iter_chunked(chunk_size):
                    await file.write(chunk)

        return filename