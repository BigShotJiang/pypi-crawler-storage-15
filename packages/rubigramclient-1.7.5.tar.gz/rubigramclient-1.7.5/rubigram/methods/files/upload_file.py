from typing import Union, Optional, BinaryIO
from pathlib import Path
from aiohttp import FormData
import rubigram


class UploadFile:
    async def upload_file(self: "rubigram.Client", upload_url: str, file: Union[str, bytes, BinaryIO], name: Optional[str] = None) -> str:
        if isinstance(file, str):
            path = Path(file)

            if path.is_file():
                file = path.read_bytes()
                name = name or path.name

            elif file.startswith("http"):
                async with self.http.session.get(file) as response:
                    response.raise_for_status()
                    file = await response.read()
                    name = name or await self.get_file_name(file)
            else:
                raise FileNotFoundError("Invalid path or url file: %s", file)

        else:
            name = name or "file"

        form = FormData()
        form.add_field(
            "file", file, filename=name, content_type="application/octet-stream"
        )

        async with self.http.session.post(upload_url, data=form) as response:
            response.raise_for_status()
            data: dict = await response.json()
            return data.get("data", {}).get("file_id")