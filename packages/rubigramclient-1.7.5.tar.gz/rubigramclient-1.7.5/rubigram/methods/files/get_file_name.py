from urllib.parse import urlparse
import os
import rubigram


class GetFileName:
    async def get_file_name(self: "rubigram.Client", url: str) -> str:
        parser = urlparse(url)
        return os.path.basename(parser.path)