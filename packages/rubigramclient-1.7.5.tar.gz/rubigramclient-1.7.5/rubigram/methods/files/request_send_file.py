from typing import Union
import rubigram


class RequestSendFile:
    async def request_send_file(self: "rubigram.Client", type: Union[str, "rubigram.enums.FileType"] = "File") -> str:
        response = await self.request("requestSendFile", {"type": type})
        return response.get("upload_url")