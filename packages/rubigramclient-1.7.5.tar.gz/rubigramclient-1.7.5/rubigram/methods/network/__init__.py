from .request import Request


class Network(
    Request
):
    pass