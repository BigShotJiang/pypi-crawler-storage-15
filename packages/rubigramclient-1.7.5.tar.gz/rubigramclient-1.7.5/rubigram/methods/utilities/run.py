from aiohttp.web import Application
import asyncio
import logging
import rubigram


logger = logging.getLogger(__name__)


class Run:
    def run(
        self: "rubigram.Client",
        set_new_endpoint: float = True
    ):
        """
        **Start the Rubigram client in webhook or polling mode.**
            `client.run()`

        This method is the main entry point for starting the Rubigram client.
        It automatically chooses between webhook mode (if webhook_url is set)
        or polling mode (if no webhook_url is configured).

        Args:
            set_endpoint (`Optional[bool]`):
                Whether to automatically set up webhook endpoints.
                Defaults to True. Only applies to webhook mode.

        Example:
        .. code-block:: python

            # Webhook mode (when webhook_url is set)
            client = rubigram.Client("your_token", webhook_url="https://example.com")
            client.run()
            # Server starts and configures webhook endpoints automatically

            # Polling mode (when no webhook_url)
            client = rubigram.Client("your_token")
            client.run()
            # Starts polling for updates

            # Disable automatic endpoint setup
            client.run(set_endpoint=False)

        Note:
            - Webhook mode: Requires webhook_url, starts aiohttp server
            - Polling mode: No webhook_url needed, uses getUpdates method
            - Automatically sets up routes for all UpdateEndpointType values
            - Handles both startup and cleanup lifecycle events
            - Runs the appropriate mode based on configuration
        """
        self.set_new_endpoint = set_new_endpoint
        if self.webhook:
            app = Application()
            app.on_startup.append(self.startup)
            app.on_cleanup.append(self.cleanup)

            for i in rubigram.enums.UpdateEndpointType:
                path = "/" + i.value
                app.router.add_post(path, self.request_handler())

            asyncio.run(self.server(app))

        else:
            try:
                asyncio.run(self.polling())
            except:
                pass