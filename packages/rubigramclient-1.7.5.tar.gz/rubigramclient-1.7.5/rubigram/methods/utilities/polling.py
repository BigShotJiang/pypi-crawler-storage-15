from datetime import datetime
import logging
import rubigram


logger = logging.getLogger(__name__)


class Polling:
    async def polling(self: "rubigram.Client"):
        """
        **Start polling for updates from Rubigram.**
            `await client.polling()`

        This method implements a continuous polling loop to fetch updates
        from the Rubigram server. It processes updates in real-time and
        dispatches them to the appropriate handlers.

        The polling mechanism:
        1. Starts the client connection
        2. Enters an infinite loop to fetch updates
        3. Processes each update through the dispatcher
        4. Maintains offset for efficient update retrieval
        5. Handles errors gracefully with logging
        6. Ensures proper cleanup on shutdown

        Example:
        .. code-block:: python

            # Start polling for updates
            await client.polling()

            # The polling loop will:
            # - Fetch up to 100 updates at a time
            # - Process only recent messages (within 2 seconds)
            # - Update the offset to avoid duplicate processing
            # - Dispatch updates to registered handlers
            # - Log any errors that occur

        Note:
            - Processes only recent messages (within 2 seconds of current time)
            - Uses offset-based pagination to avoid missing updates
            - Automatically handles client startup and shutdown
            - Logs errors but continues polling for resilience
            - Maximum of 100 updates per request for efficiency
        """
        await self.start()
        try:
            while True:
                get_updates = await self.get_updates(100, self.offset_id)
                updates = get_updates.updates

                if updates:
                    for update in updates:
                        time = (
                            int(update.new_message.time) if update.type == "NewMessage" else
                            int(update.updated_message.time) if update.type == "UpdatedMessage" else
                            None
                        )
                        now = int(datetime.now().timestamp())

                        if time and (time >= now or time + 2 >= now):
                            update.client = self
                            await self.dispatcher(update)

                        self.offset_id = get_updates.next_offset_id

        except Exception as error:
            logger.error(error)

        finally:
            await self.stop()