from aiohttp.web import Application, AppRunner, TCPSite
import logging
import rubigram


logger = logging.getLogger(__name__)


class Server:
    async def server(self: "rubigram.Client", app: Application):
        """
        **Start the aiohttp web server for webhook handling.**
            `await client.server(app)`

        This method sets up and starts an aiohttp web server to handle
        incoming webhook requests from Rubigram. The server runs on the
        specified host and port configured in the client.

        Args:
            app (`aiohttp.web.Application`):
                The aiohttp web application instance that will handle
                incoming webhook requests.

        Example:
        .. code-block:: python

            from aiohttp import web
            import rubigram

            # Create aiohttp application
            app = web.Application()

            # Add webhook route
            app.router.add_post('/webhook/{type}', handle_webhook)

            # Start the server
            await client.server(app)

            # Server will run on the configured host and port
            # Example: http://localhost:8080

        Note:
            - Requires an aiohttp Application instance with configured routes
            - Uses AppRunner for better async support
            - Binds to the host and port specified in client configuration
            - Logs the server startup information including webhook URL
            - Should be used with webhook mode instead of polling
        """
        runner = AppRunner(app)
        await runner.setup()
        site = TCPSite(runner, self.host, self.port)
        await site.start()

        logger.info("SERVER RUN(address=%s)", self.webhook)