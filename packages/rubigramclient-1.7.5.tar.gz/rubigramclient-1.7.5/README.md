# Rubigram
A lightweight Python library to build Rubika bots easily.

<div align="center">
  <img src="http://rubigram.ir/rubigram.jpg" alt="Rubigram Logo" width="200"/>
</div>



## Installation
```bash
pip install RubigramClient
```

## Quick Example
```python
from rubigram import Client
from rubigram.types import Update

client = Client(token="...")

@client.on_message()
async def start(client: Client, update: Update):
    await update.reply(text="Hi, rubigram user!")

client.run()
```

## Reply and Edit message
```python
from rubigram import Client
from rubigram.types import Update

client = Client(token="...")

@client.on_message()
async def echo(client: Client, update: Update):
    message = await update.reply(text=f"Hi, {update.new_message.text}")
    await message.edit_text(text="message was edited")

client.run()
```

## Send Message & Get receiveInlineMessage
```python
from rubigram import Client, filters
from rubigram.types import Update, Button, Keypad, KeypadRow, InlineMessage


client = Client(token="...", webhook_url="...")


@client.on_message(filters.command("start"))
async def start(client: Client, update: Update):
    inline = Keypad(
        rows=[
            KeypadRow(
                buttons=[
                    Button(id="1", button_text="Button 1"),
                    Button(id="2", button_text="Button 2")
                ]
            )
        ]
    )
    await update.reply("The inline message", inline_keypad=inline)


@client.on_inline_message(filters.button(["1", "2"]))
async def button(client: Client, update: InlineMessage):
    if update.aux_data.button_id == "1":
        await client.send_message(chat_id=update.chat_id, text="You Click Button 1")
    elif update.aux_data.button_id == "2":
        await client.send_message(chat_id=update.chat_id, text="You Click Button 2")
        
client.run()
```

## Filters
```python
from rubigram import Client, filters
from rubigram.types import Update

client = Client(token="...")


@client.on_message(filters.text)
async def text(client: Client, update: Update):
    await update.reply(text="message is text")


@client.on_message(filters.contact)
async def contact(client: Client, update: Update):
    await update.reply(text="message is contact")


@client.on_message(filters.edited)
async def edited(client: Client, update: Update):
    await update.reply(text="message is edited")


@client.on_message(filters.file)
async def file(client: Client, update: Update):
    await update.reply(text="message is efiledited")

client.run()
```

## Handlers
```python
from rubigram import Client

client = Client(token="...")

@client.on_message()
async def new_message():
    ...
    
@client.on_inline_message()
async def inline_message():
    ...
    
@client.on_update_message()
async def update_message():
    ...
    
@client.on_remove_message()
async def remove_message():
    ...
    
@client.on_started_bot()
async def start_bot():
    ...
    
@client.on_stopped_bot()
async def stop_bot():
    ...
    
@client.on_start()
async def start():
    ...

@client.on_stop()
async def stop():
    ...
```

## Contex Manager
```python
from rubigram import Client
import asyncio


async def main():
    async with Client(token="...") as client:
        data = await client.get_me()
        print(data.bot_id)

asyncio.run(main())
```

## Implementation of multiple programs
```python
from rubigram import Client
import asyncio

tokens = ["TOKEN_1", "TOKEN_2"]

async def main():
    for token in tokens:
        async with Client(token=token) as client:
            info = await client.get_me()
            print(info)

asyncio.run(main())
```

## Rubino
```python
from rubigram.rubino import Rubino
import asyncio


async def main():
    async with Rubino(auth="...") as client:
        info = await client.get_my_profile_info()
        print(info)

asyncio.run(main())
```