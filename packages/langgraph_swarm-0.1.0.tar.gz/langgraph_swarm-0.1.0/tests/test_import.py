def test_import() -> None:
    """Test that the code can be imported."""
