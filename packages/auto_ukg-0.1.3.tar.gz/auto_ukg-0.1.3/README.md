<h2 align="center">Auto UKG</h2>
Allows hourly MGH employees to automatically clock in/out. :-)