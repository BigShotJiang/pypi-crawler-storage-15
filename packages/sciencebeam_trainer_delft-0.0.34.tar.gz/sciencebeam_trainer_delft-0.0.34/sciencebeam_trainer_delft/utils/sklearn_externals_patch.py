# interim patch of sklearn externals
# (can be removed after delft was updated)

import joblib
import sklearn.externals

sklearn.externals.joblib = joblib
