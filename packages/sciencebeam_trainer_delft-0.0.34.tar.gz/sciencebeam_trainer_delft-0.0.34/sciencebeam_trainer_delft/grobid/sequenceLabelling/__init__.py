# pylint: disable=unused-import
from sciencebeam_trainer_delft.sequence_labelling.wrapper import Sequence  # noqa
