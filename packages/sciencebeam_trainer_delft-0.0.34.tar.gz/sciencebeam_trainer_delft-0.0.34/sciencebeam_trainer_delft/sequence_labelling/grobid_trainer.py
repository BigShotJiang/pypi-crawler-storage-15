from sciencebeam_trainer_delft.sequence_labelling.tools.grobid_trainer.cli import (
    main_setup,
    main
)

if __name__ == "__main__":
    main_setup()
    main()
