# Presentation layer: CLI/HTTP/UI adapters will live here.

