# Infrastructure layer: adapters for persistence, external services, etc.

