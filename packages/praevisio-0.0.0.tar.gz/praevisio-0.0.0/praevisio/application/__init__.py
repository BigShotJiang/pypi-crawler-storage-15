# Application layer: orchestrates use cases, coordinates domain & infrastructure.

