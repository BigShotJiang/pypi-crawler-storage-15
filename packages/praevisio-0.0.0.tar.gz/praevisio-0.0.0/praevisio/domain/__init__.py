# Domain layer: core business objects and abstractions

