"""Alpha Vantage models."""
