"""Alpha Vantage tests."""
