demo
====


.. literalinclude:: ../../demos/demo.py
   :language: python