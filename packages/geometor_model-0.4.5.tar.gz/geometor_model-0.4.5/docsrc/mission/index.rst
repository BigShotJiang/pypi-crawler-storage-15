:navigation: header
:order: 1

mission
=======

.. todo:: set mission statement and goals

.. contents::
   :local:
   :backlinks: none


goals
-----


