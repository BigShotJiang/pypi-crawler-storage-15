select 1 as __key, 2 as dummy
union all
select 1 as __key, 1 as dummy
