select '1' as dummy, '1' as less_dummy, '1' as dummier
union all
select '2' as dummy, '2' as less_dummy, '1' as dummier
