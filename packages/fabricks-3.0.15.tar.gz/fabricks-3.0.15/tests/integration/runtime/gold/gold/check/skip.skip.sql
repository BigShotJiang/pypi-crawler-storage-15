select true as __skip, 'I want you to skip this !' as __message
