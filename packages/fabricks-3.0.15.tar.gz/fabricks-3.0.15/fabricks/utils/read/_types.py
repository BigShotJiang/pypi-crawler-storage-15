from typing import Literal

AllowedIOModes = Literal["overwrite", "append"]
