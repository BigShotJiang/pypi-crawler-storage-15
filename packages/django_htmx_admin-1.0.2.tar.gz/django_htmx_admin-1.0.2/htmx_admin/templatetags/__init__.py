# Template tags for django-htmx-admin
