"""
Interaxions: A library for agent and environment protocol interactions.
"""

__version__ = "0.0.0"
