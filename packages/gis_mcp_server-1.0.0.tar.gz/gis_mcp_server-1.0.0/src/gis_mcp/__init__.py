"""GIS MCP Server - Geospatial tools for AI agents."""

__version__ = "1.0.0"
