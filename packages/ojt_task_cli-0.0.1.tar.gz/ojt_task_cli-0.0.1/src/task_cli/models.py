import datetime
from dataclasses import dataclass, asdict
from typing import Optional

@dataclass
class Task:
    id: int
    title: str
    status: str = "pending"
    priority: str = "Medium"
    project: Optional[str] = None
    recurrence: Optional[str] = None
    created_at: str = "" 
    completed_at: Optional[str] = None
    due_date: Optional[str] = None

    def __post_init__(self):
        if not self.created_at:
            self.created_at = datetime.datetime.now().isoformat()

    def to_dict(self):
        return asdict(self)

    @classmethod
    def from_dict(cls, data):
        # Filter data to only include fields that are in the dataclass
        # This ensures backward compatibility if the saved JSON has extra fields (like relist_count)
        valid_fields = {f for f in cls.__annotations__}
        filtered_data = {k: v for k, v in data.items() if k in valid_fields}
        return cls(**filtered_data)
