# Changelog

## 2.11.0 (2025-12-04)

Full Changelog: [v2.10.0...v2.11.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v2.10.0...v2.11.0)

### Features

* **api:** api update ([0b282f0](https://github.com/roarkhq/sdk-roark-analytics-python/commit/0b282f0f5e07fb13947d55738bcc41ac7f143fc4))

## 2.10.0 (2025-12-03)

Full Changelog: [v2.9.1...v2.10.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v2.9.1...v2.10.0)

### Features

* **api:** api update ([b610558](https://github.com/roarkhq/sdk-roark-analytics-python/commit/b6105583813781ac23849486657eac71441a6bf7))


### Chores

* **docs:** use environment variables for authentication in code snippets ([f5cb199](https://github.com/roarkhq/sdk-roark-analytics-python/commit/f5cb19987d0624a64870036c0ae8dd2d063ba06a))
* update lockfile ([73a6abb](https://github.com/roarkhq/sdk-roark-analytics-python/commit/73a6abb33c7c36b58a1ce8b138764362bb616845))

## 2.9.1 (2025-11-28)

Full Changelog: [v2.9.0...v2.9.1](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v2.9.0...v2.9.1)

### Bug Fixes

* ensure streams are always closed ([3f2966d](https://github.com/roarkhq/sdk-roark-analytics-python/commit/3f2966d1021a6a8e398b2801de5a2be3ddda87cd))


### Chores

* add Python 3.14 classifier and testing ([47dca25](https://github.com/roarkhq/sdk-roark-analytics-python/commit/47dca256fdda1b06991d9d9c8464f610f8a20278))
* **deps:** mypy 1.18.1 has a regression, pin to 1.17 ([cb93c94](https://github.com/roarkhq/sdk-roark-analytics-python/commit/cb93c94986c1c4b81e895528634c5663af33d8c4))

## 2.9.0 (2025-11-14)

Full Changelog: [v2.8.0...v2.9.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v2.8.0...v2.9.0)

### Features

* **api:** api update ([542701a](https://github.com/roarkhq/sdk-roark-analytics-python/commit/542701a0c4160df6bf45761dedb19654885f90f1))

## 2.8.0 (2025-11-14)

Full Changelog: [v2.7.0...v2.8.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v2.7.0...v2.8.0)

### Features

* **api:** api update ([d5704e7](https://github.com/roarkhq/sdk-roark-analytics-python/commit/d5704e7375a24d89e6957d46466909623c841def))

## 2.7.0 (2025-11-14)

Full Changelog: [v2.6.0...v2.7.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v2.6.0...v2.7.0)

### Features

* **api:** api update ([e755ecb](https://github.com/roarkhq/sdk-roark-analytics-python/commit/e755ecb30a7d353748a21fd4c6c40f002b0c6b81))
* **api:** api update ([d6f7f9d](https://github.com/roarkhq/sdk-roark-analytics-python/commit/d6f7f9d8e3c87fad2eda135a6740af1ba3d89143))
* **api:** api update ([2f8ba1f](https://github.com/roarkhq/sdk-roark-analytics-python/commit/2f8ba1fe0e7f2b58298a7f94c8bf76be26792ae2))
* **api:** api update ([a96583d](https://github.com/roarkhq/sdk-roark-analytics-python/commit/a96583dc501b8fddaf21d804868060517aecf996))
* **api:** api update ([1c10901](https://github.com/roarkhq/sdk-roark-analytics-python/commit/1c10901e4336165ba8979d797e6ab59a8220640a))
* **api:** api update ([a740ceb](https://github.com/roarkhq/sdk-roark-analytics-python/commit/a740ceb0a771ee87def6a3d906bc6216b995a7f5))
* **api:** api update ([428c550](https://github.com/roarkhq/sdk-roark-analytics-python/commit/428c550ecaa3f8ac197dfe7140ce494de8b9fb1c))


### Bug Fixes

* **client:** close streams without requiring full consumption ([5b4a8e0](https://github.com/roarkhq/sdk-roark-analytics-python/commit/5b4a8e0ee9e4aa7f12683725022ee166a1092d9c))
* compat with Python 3.14 ([a92c8b7](https://github.com/roarkhq/sdk-roark-analytics-python/commit/a92c8b7de52c7f5f6a5d3417e40b484617789e68))
* **compat:** update signatures of `model_dump` and `model_dump_json` for Pydantic v1 ([cd248df](https://github.com/roarkhq/sdk-roark-analytics-python/commit/cd248df97d2762223c5345c1479142742fb24119))


### Chores

* bump `httpx-aiohttp` version to 0.1.9 ([ef63fbc](https://github.com/roarkhq/sdk-roark-analytics-python/commit/ef63fbcde046122cff56f80b65bfa432346e9264))
* do not install brew dependencies in ./scripts/bootstrap by default ([c441e13](https://github.com/roarkhq/sdk-roark-analytics-python/commit/c441e137a85f13f22c0d923a3769d4e9f24d1c45))
* improve example values ([29c8d52](https://github.com/roarkhq/sdk-roark-analytics-python/commit/29c8d52073e7b23f0a523218f2f56ddbfaae6c5c))
* **internal/tests:** avoid race condition with implicit client cleanup ([c589789](https://github.com/roarkhq/sdk-roark-analytics-python/commit/c58978999fd37611488a909f4d8d52f8c73e352c))
* **internal:** detect missing future annotations with ruff ([6d48516](https://github.com/roarkhq/sdk-roark-analytics-python/commit/6d48516bb2133f9528a134550711319bda024db5))
* **internal:** grammar fix (it's -&gt; its) ([30d07eb](https://github.com/roarkhq/sdk-roark-analytics-python/commit/30d07eb42507e31e87c726bfe2d7eddd77de3203))
* **package:** drop Python 3.8 support ([dd1dc60](https://github.com/roarkhq/sdk-roark-analytics-python/commit/dd1dc60d7ab9574f40a43223da1225728f15489b))
* **types:** change optional parameter type from NotGiven to Omit ([0234179](https://github.com/roarkhq/sdk-roark-analytics-python/commit/02341790d75a5489a3ac3eed0afdc50852897148))

## 2.6.0 (2025-09-18)

Full Changelog: [v2.5.2...v2.6.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v2.5.2...v2.6.0)

### Features

* **api:** api update ([1fc7cf8](https://github.com/roarkhq/sdk-roark-analytics-python/commit/1fc7cf8cbb32e0607ba487af56fbccb5abb7bc8e))

## 2.5.2 (2025-09-18)

Full Changelog: [v2.5.1...v2.5.2](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v2.5.1...v2.5.2)

### Chores

* **internal:** codegen related update ([2deca6e](https://github.com/roarkhq/sdk-roark-analytics-python/commit/2deca6e2c6abe779ab307760b7a5e3fea08b0053))
* **internal:** update pydantic dependency ([7ac712d](https://github.com/roarkhq/sdk-roark-analytics-python/commit/7ac712d43cade4a8b3c08038823a3801d770b17a))

## 2.5.1 (2025-09-05)

Full Changelog: [v2.5.0...v2.5.1](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v2.5.0...v2.5.1)

### Chores

* **internal:** move mypy configurations to `pyproject.toml` file ([14f1f8b](https://github.com/roarkhq/sdk-roark-analytics-python/commit/14f1f8baf6bdf3255c12b726fc564b60f978caa6))

## 2.5.0 (2025-09-05)

Full Changelog: [v2.4.0...v2.5.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v2.4.0...v2.5.0)

### Features

* **api:** api update ([0b3a8c6](https://github.com/roarkhq/sdk-roark-analytics-python/commit/0b3a8c6c74e0b8171f63229363909881ecf56566))

## 2.4.0 (2025-09-04)

Full Changelog: [v2.3.0...v2.4.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v2.3.0...v2.4.0)

### Features

* **api:** api update ([e734a8b](https://github.com/roarkhq/sdk-roark-analytics-python/commit/e734a8b3e0443b23b0e04e0a4827f5dcb0d2bd75))
* **api:** manual updates ([2ca609c](https://github.com/roarkhq/sdk-roark-analytics-python/commit/2ca609ce6c65ce2cc0a429fdabf19c0dfca4db0b))

## 2.3.0 (2025-09-04)

Full Changelog: [v2.2.0...v2.3.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v2.2.0...v2.3.0)

### Features

* improve future compat with pydantic v3 ([e2198c2](https://github.com/roarkhq/sdk-roark-analytics-python/commit/e2198c275f8da3422e62f676aa36b4ac74ec3c82))
* **types:** replace List[str] with SequenceNotStr in params ([b9ad7f3](https://github.com/roarkhq/sdk-roark-analytics-python/commit/b9ad7f3c0255144f67f854396d8b26c8e6cfe133))


### Chores

* **internal:** add Sequence related utils ([43c25f8](https://github.com/roarkhq/sdk-roark-analytics-python/commit/43c25f87a12d6c6a8187a2b0649233a15af1e1e9))

## 2.2.0 (2025-08-27)

Full Changelog: [v2.1.0...v2.2.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v2.1.0...v2.2.0)

### Features

* **client:** support file upload requests ([dcca8fb](https://github.com/roarkhq/sdk-roark-analytics-python/commit/dcca8fb047301c69c2adff8e8a462807887535d9))


### Bug Fixes

* avoid newer type syntax ([4e0d159](https://github.com/roarkhq/sdk-roark-analytics-python/commit/4e0d159a6c4f83c306fa005d591453c1d3d1c6f6))


### Chores

* **internal:** change ci workflow machines ([abc6f10](https://github.com/roarkhq/sdk-roark-analytics-python/commit/abc6f10e397ba63e656a8aa7947f50ec2bf0688d))
* **internal:** fix ruff target version ([32fead1](https://github.com/roarkhq/sdk-roark-analytics-python/commit/32fead17d3d5d8374916cbe93e1ce0f337679c96))
* **internal:** update comment in script ([5736d0f](https://github.com/roarkhq/sdk-roark-analytics-python/commit/5736d0f4e81e8a5fc4cf4f2b2cd3c674406aa4f1))
* **internal:** update pyright exclude list ([2b10522](https://github.com/roarkhq/sdk-roark-analytics-python/commit/2b10522f77e6f716c355b8395de355ef362d721d))
* update @stainless-api/prism-cli to v5.15.0 ([e12aec2](https://github.com/roarkhq/sdk-roark-analytics-python/commit/e12aec2c46689da3f8044b920ddeaf16a6bd0fbe))
* update github action ([bef1314](https://github.com/roarkhq/sdk-roark-analytics-python/commit/bef13148023457292223539f746d067f5c94911f))

## 2.1.0 (2025-07-28)

Full Changelog: [v2.0.0...v2.1.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v2.0.0...v2.1.0)

### Features

* **api:** api update ([1d41b45](https://github.com/roarkhq/sdk-roark-analytics-python/commit/1d41b454d2b8d267f047019d348d6ace17b79e31))

## 2.0.0 (2025-07-25)

Full Changelog: [v1.189.0...v2.0.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.189.0...v2.0.0)

### Features

* **api:** api update ([05396c7](https://github.com/roarkhq/sdk-roark-analytics-python/commit/05396c72066abda57fd8b6c6873d8cac0f44c8ed))
* **api:** api update ([4b296c8](https://github.com/roarkhq/sdk-roark-analytics-python/commit/4b296c897da9546e50e1bb4c532e9078e31baa0c))
* **api:** api update ([5cbe24a](https://github.com/roarkhq/sdk-roark-analytics-python/commit/5cbe24a736a3f3f05b77d6034da320c7fcf9f900))
* **api:** api update ([ad15155](https://github.com/roarkhq/sdk-roark-analytics-python/commit/ad15155aa7f72df44b140e0cee56372d9adad55d))
* **api:** api update ([dae4bbb](https://github.com/roarkhq/sdk-roark-analytics-python/commit/dae4bbb0e34bde6e2b6d07c26b5a21df2877e314))
* **api:** api update ([8292dde](https://github.com/roarkhq/sdk-roark-analytics-python/commit/8292dde9fab85501ab2f454a5e07508944974388))
* **api:** api update ([97894e0](https://github.com/roarkhq/sdk-roark-analytics-python/commit/97894e0b589ee95897dca39f55e4761547830e64))
* **api:** api update ([d0c89e9](https://github.com/roarkhq/sdk-roark-analytics-python/commit/d0c89e9f901b7f5b1381cbe014bb78d621b7eb6b))
* **api:** api update ([2ba5813](https://github.com/roarkhq/sdk-roark-analytics-python/commit/2ba581381c62685164fb69de02bc66134cc86231))
* **api:** api update ([701a62a](https://github.com/roarkhq/sdk-roark-analytics-python/commit/701a62ae9a05063a35c2e5f5e626d61fcc45c32c))
* clean up environment call outs ([6db6fd1](https://github.com/roarkhq/sdk-roark-analytics-python/commit/6db6fd11581745d0dd807d47d32e8e6bc680028a))


### Bug Fixes

* **client:** don't send Content-Type header on GET requests ([2ca9230](https://github.com/roarkhq/sdk-roark-analytics-python/commit/2ca92304046ef87cd567d20aad395175c45d8d01))
* **parsing:** correctly handle nested discriminated unions ([5c80c26](https://github.com/roarkhq/sdk-roark-analytics-python/commit/5c80c265087caa9c7b48550efad8beab9e4ed50a))
* **parsing:** ignore empty metadata ([a042dd8](https://github.com/roarkhq/sdk-roark-analytics-python/commit/a042dd853dd6a56d0528f955c0a15a7adea01616))
* **parsing:** parse extra field types ([1edf77e](https://github.com/roarkhq/sdk-roark-analytics-python/commit/1edf77ee6c3a5dbf3429f73af4aef058d8ee2d68))


### Chores

* **internal:** bump pinned h11 dep ([3571301](https://github.com/roarkhq/sdk-roark-analytics-python/commit/35713017b76b63decf63fcfe64bb73a879039db1))
* **internal:** codegen related update ([13e13ad](https://github.com/roarkhq/sdk-roark-analytics-python/commit/13e13adc9dcbea1bc2f2abe88b8ba0ca835af1dd))
* **internal:** codegen related update ([fc7b67a](https://github.com/roarkhq/sdk-roark-analytics-python/commit/fc7b67aa62345c4d79171dc358aa27cc06c903b0))
* **package:** mark python 3.13 as supported ([6d993b3](https://github.com/roarkhq/sdk-roark-analytics-python/commit/6d993b3e3a1698ac85f940a0508956a95f741d30))
* **project:** add settings file for vscode ([78972c2](https://github.com/roarkhq/sdk-roark-analytics-python/commit/78972c2838b307df28672577d048e10df0040216))
* **readme:** fix version rendering on pypi ([4a83ef2](https://github.com/roarkhq/sdk-roark-analytics-python/commit/4a83ef2ba88504445b6fe704a012128c690abc3d))

## 1.189.0 (2025-07-08)

Full Changelog: [v1.188.0...v1.189.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.188.0...v1.189.0)

### Features

* **api:** api update ([701e023](https://github.com/roarkhq/sdk-roark-analytics-python/commit/701e023f9d0e764bc55268b12026e193b800bd4a))

## 1.188.0 (2025-07-07)

Full Changelog: [v1.187.0...v1.188.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.187.0...v1.188.0)

### Features

* **api:** api update ([1e7928c](https://github.com/roarkhq/sdk-roark-analytics-python/commit/1e7928c3f73550b9f26f5b2faec27d62e594b43d))

## 1.187.0 (2025-07-06)

Full Changelog: [v1.186.2...v1.187.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.186.2...v1.187.0)

### Features

* **api:** api update ([aabcb5c](https://github.com/roarkhq/sdk-roark-analytics-python/commit/aabcb5c245e57c1b76281acd3852b66ea18edf2d))


### Chores

* **ci:** change upload type ([3b9ca83](https://github.com/roarkhq/sdk-roark-analytics-python/commit/3b9ca8361e15fcae914913d155df388a917dd162))

## 1.186.2 (2025-06-30)

Full Changelog: [v1.186.1...v1.186.2](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.186.1...v1.186.2)

### Bug Fixes

* **ci:** correct conditional ([08342e7](https://github.com/roarkhq/sdk-roark-analytics-python/commit/08342e77b999c7a348e4a3467f4a813658445edb))


### Chores

* **ci:** only run for pushes and fork pull requests ([8381ec8](https://github.com/roarkhq/sdk-roark-analytics-python/commit/8381ec8e7ff42e848197010ffd19f0c8197ae30f))

## 1.186.1 (2025-06-27)

Full Changelog: [v1.186.0...v1.186.1](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.186.0...v1.186.1)

### Bug Fixes

* **ci:** release-doctor — report correct token name ([2fba60b](https://github.com/roarkhq/sdk-roark-analytics-python/commit/2fba60b0676dee1f11fa119a19da776e212a25cf))


### Chores

* **internal:** codegen related update ([aab9dd5](https://github.com/roarkhq/sdk-roark-analytics-python/commit/aab9dd586511a82e6967442691a4e8d5d2ce853b))

## 1.186.0 (2025-06-24)

Full Changelog: [v1.185.0...v1.186.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.185.0...v1.186.0)

### Features

* **api:** api update ([2c3df9b](https://github.com/roarkhq/sdk-roark-analytics-python/commit/2c3df9bd8f8a04b2b936d99822f234758176d886))


### Chores

* **tests:** skip some failing tests on the latest python versions ([d97bdbd](https://github.com/roarkhq/sdk-roark-analytics-python/commit/d97bdbda5829584acdc4a5af9c551c5436d493bf))

## 1.185.0 (2025-06-23)

Full Changelog: [v1.184.1...v1.185.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.184.1...v1.185.0)

### Features

* **api:** api update ([865b44a](https://github.com/roarkhq/sdk-roark-analytics-python/commit/865b44a0458ecfd15148d8501a46eb019087720a))
* **api:** api update ([81fc67c](https://github.com/roarkhq/sdk-roark-analytics-python/commit/81fc67c85bab0347887f2fd51a9f55c5e9b500fd))
* **client:** add support for aiohttp ([52e840a](https://github.com/roarkhq/sdk-roark-analytics-python/commit/52e840a408366dfaea39bf44b6682dfbcb94016d))


### Bug Fixes

* **tests:** fix: tests which call HTTP endpoints directly with the example parameters ([fb7bacd](https://github.com/roarkhq/sdk-roark-analytics-python/commit/fb7bacde394f6553a5e450a4d2c7a02c5a9a17b8))


### Chores

* **ci:** enable for pull requests ([75807a1](https://github.com/roarkhq/sdk-roark-analytics-python/commit/75807a1b2becca4dcb6bcac232ae880f3bfd38bf))
* **internal:** codegen related update ([dc113a0](https://github.com/roarkhq/sdk-roark-analytics-python/commit/dc113a07f626707b7cda76b1fdf464ce184a3aa0))
* **internal:** codegen related update ([3341eb4](https://github.com/roarkhq/sdk-roark-analytics-python/commit/3341eb468f3b7db676380b4bd3139f8d2ed212c0))
* **internal:** update conftest.py ([24c496a](https://github.com/roarkhq/sdk-roark-analytics-python/commit/24c496a6e71856e685fb2a23f43dcb506dfb0de4))
* **internal:** version bump ([a7ebbd8](https://github.com/roarkhq/sdk-roark-analytics-python/commit/a7ebbd8c9887ba82f6af8a51ba9a4a6ee05f3569))
* **readme:** update badges ([68ed762](https://github.com/roarkhq/sdk-roark-analytics-python/commit/68ed7623bfcb1a8d8513e9d1da777e6f382a55c8))
* **tests:** add tests for httpx client instantiation & proxies ([49e9adc](https://github.com/roarkhq/sdk-roark-analytics-python/commit/49e9adcfa27d56efcded0a1e69d0926e7bf7ef6e))


### Documentation

* **client:** fix httpx.Timeout documentation reference ([839f7a8](https://github.com/roarkhq/sdk-roark-analytics-python/commit/839f7a8252188f17ab07e7e6be613f950189eaea))

## 1.184.1 (2025-06-13)

Full Changelog: [v1.184.0...v1.184.1](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.184.0...v1.184.1)

### Bug Fixes

* **client:** correctly parse binary response | stream ([a5cf0e9](https://github.com/roarkhq/sdk-roark-analytics-python/commit/a5cf0e9391b32a30b7dfa69180dc704637494276))


### Chores

* **tests:** run tests in parallel ([b0a2d2d](https://github.com/roarkhq/sdk-roark-analytics-python/commit/b0a2d2d62c7a034620d2c3f6472c33a347b04111))

## 1.184.0 (2025-06-12)

Full Changelog: [v1.183.0...v1.184.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.183.0...v1.184.0)

### Features

* **api:** api update ([e655d12](https://github.com/roarkhq/sdk-roark-analytics-python/commit/e655d12c5da721961fe463273b7f504ca433bf77))

## 1.183.0 (2025-06-04)

Full Changelog: [v1.182.0...v1.183.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.182.0...v1.183.0)

### Features

* **api:** api update ([3a30485](https://github.com/roarkhq/sdk-roark-analytics-python/commit/3a3048558850b05d75806f4c7cd5ae13a0ba5b41))


### Chores

* **internal:** codegen related update ([f850c54](https://github.com/roarkhq/sdk-roark-analytics-python/commit/f850c546131dfa9082353dff4029c004996cd755))

## 1.182.0 (2025-06-04)

Full Changelog: [v1.181.0...v1.182.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.181.0...v1.182.0)

### Features

* **api:** api update ([1ff1477](https://github.com/roarkhq/sdk-roark-analytics-python/commit/1ff1477ae80dee2276f51a49321ec4bfb7e4026c))
* **api:** api update ([634d053](https://github.com/roarkhq/sdk-roark-analytics-python/commit/634d053a30d70fbcb44df09f6cb7331c54b1b00c))
* **api:** api update ([f0ae145](https://github.com/roarkhq/sdk-roark-analytics-python/commit/f0ae14540cc936ea7fbba3c16151a6c056b16eb4))

## 1.181.0 (2025-06-03)

Full Changelog: [v1.180.0...v1.181.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.180.0...v1.181.0)

### Features

* **api:** api update ([291b061](https://github.com/roarkhq/sdk-roark-analytics-python/commit/291b0616f7c03e8014fac2da66b51bdf0b6248c1))

## 1.180.0 (2025-06-03)

Full Changelog: [v1.179.0...v1.180.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.179.0...v1.180.0)

### Features

* **api:** api update ([a0ff40c](https://github.com/roarkhq/sdk-roark-analytics-python/commit/a0ff40c50d058458439ed0efbfc40be8d13c7d24))

## 1.179.0 (2025-06-03)

Full Changelog: [v1.178.0...v1.179.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.178.0...v1.179.0)

### Features

* **api:** api update ([74625c0](https://github.com/roarkhq/sdk-roark-analytics-python/commit/74625c0c6faf3959ddf4101c0b048140411c9702))

## 1.178.0 (2025-06-03)

Full Changelog: [v1.177.0...v1.178.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.177.0...v1.178.0)

### Features

* **api:** api update ([a30745e](https://github.com/roarkhq/sdk-roark-analytics-python/commit/a30745ead02224855854f4555a617b3e21b64194))

## 1.177.0 (2025-06-03)

Full Changelog: [v1.176.0...v1.177.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.176.0...v1.177.0)

### Features

* **api:** api update ([1ddad31](https://github.com/roarkhq/sdk-roark-analytics-python/commit/1ddad31d5ce0197768f9b8345de634b17074eb21))
* **client:** add follow_redirects request option ([96e62ca](https://github.com/roarkhq/sdk-roark-analytics-python/commit/96e62ca2bb5de17c5dc9e406368db4a3b19dcbb8))

## 1.176.0 (2025-06-03)

Full Changelog: [v1.175.0...v1.176.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.175.0...v1.176.0)

### Features

* **api:** api update ([02e4357](https://github.com/roarkhq/sdk-roark-analytics-python/commit/02e4357be691eb0b415158cbf82439882d1465c4))
* **api:** api update ([5b784bd](https://github.com/roarkhq/sdk-roark-analytics-python/commit/5b784bdf156709a7e763204912b9ef8485cd0bb0))


### Chores

* **docs:** remove reference to rye shell ([63c3245](https://github.com/roarkhq/sdk-roark-analytics-python/commit/63c32454c7a771288465288d6ed29de676e87ff3))

## 1.175.0 (2025-06-02)

Full Changelog: [v1.174.0...v1.175.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.174.0...v1.175.0)

### Features

* **api:** api update ([a022040](https://github.com/roarkhq/sdk-roark-analytics-python/commit/a02204069d5beeef66c8ce3b500d732928b7b7fe))

## 1.174.0 (2025-06-01)

Full Changelog: [v1.173.0...v1.174.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.173.0...v1.174.0)

### Features

* **api:** api update ([1f25671](https://github.com/roarkhq/sdk-roark-analytics-python/commit/1f25671984d86abf290405736275b0c065bb295a))

## 1.173.0 (2025-06-01)

Full Changelog: [v1.172.0...v1.173.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.172.0...v1.173.0)

### Features

* **api:** api update ([acf9922](https://github.com/roarkhq/sdk-roark-analytics-python/commit/acf99223437b088e7269f5b128da3f2eb3f84038))

## 1.172.0 (2025-05-31)

Full Changelog: [v1.171.0...v1.172.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.171.0...v1.172.0)

### Features

* **api:** api update ([d776fdf](https://github.com/roarkhq/sdk-roark-analytics-python/commit/d776fdfbc4cbec614579c434fa10ef6f252bf67b))

## 1.171.0 (2025-05-31)

Full Changelog: [v1.170.0...v1.171.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.170.0...v1.171.0)

### Features

* **api:** api update ([40097f1](https://github.com/roarkhq/sdk-roark-analytics-python/commit/40097f135b5af439b7b31c761750dbc3370dafd2))
* **api:** api update ([e011e64](https://github.com/roarkhq/sdk-roark-analytics-python/commit/e011e6417662356890015c0d558891252945caf5))
* **api:** api update ([636457d](https://github.com/roarkhq/sdk-roark-analytics-python/commit/636457d18cff5f0f5896b6e645d6152a8fcb7ea6))
* **api:** api update ([cfaeeaa](https://github.com/roarkhq/sdk-roark-analytics-python/commit/cfaeeaa624b4ab200978bd9bde5778f9dcab954e))
* **api:** api update ([358267b](https://github.com/roarkhq/sdk-roark-analytics-python/commit/358267b2ed2bcd5c94704fd1b5d32be2075028bb))

## 1.170.0 (2025-05-30)

Full Changelog: [v1.169.0...v1.170.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.169.0...v1.170.0)

### Features

* **api:** api update ([e0e41f0](https://github.com/roarkhq/sdk-roark-analytics-python/commit/e0e41f0ea62eace6d30cf6adc1fbfac85cfde7e9))

## 1.169.0 (2025-05-30)

Full Changelog: [v1.168.0...v1.169.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.168.0...v1.169.0)

### Features

* **api:** api update ([a0d5770](https://github.com/roarkhq/sdk-roark-analytics-python/commit/a0d57700af39c77fb274b68045e4227448dcf2b6))
* **api:** api update ([0fbbb2c](https://github.com/roarkhq/sdk-roark-analytics-python/commit/0fbbb2ce95605363977e8dd2adf2b2d90a5786ff))
* **api:** api update ([d2a1da2](https://github.com/roarkhq/sdk-roark-analytics-python/commit/d2a1da24dd95483c48ff17ceccb5bf0a15c1d4ec))
* **api:** api update ([b835f2d](https://github.com/roarkhq/sdk-roark-analytics-python/commit/b835f2d5a081a12537a7e8ea2d589a02c5f67e3f))
* **api:** api update ([5dc1ff6](https://github.com/roarkhq/sdk-roark-analytics-python/commit/5dc1ff6f0c831d26960c9548037459d2370783af))

## 1.168.0 (2025-05-28)

Full Changelog: [v1.167.0...v1.168.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.167.0...v1.168.0)

### Features

* **api:** api update ([32556fa](https://github.com/roarkhq/sdk-roark-analytics-python/commit/32556fa825de1b8fcb0ee804b6261d6292e3fa07))
* **api:** api update ([64ff566](https://github.com/roarkhq/sdk-roark-analytics-python/commit/64ff566ace81395e9e4018a710a4d8e40dfcc353))
* **api:** api update ([6586930](https://github.com/roarkhq/sdk-roark-analytics-python/commit/65869301aae73ef12cf93c8eb3c4278c0f1c53a9))
* **api:** api update ([51dc4c6](https://github.com/roarkhq/sdk-roark-analytics-python/commit/51dc4c61d135bab7525729fad4d9369741753575))
* **api:** api update ([411d827](https://github.com/roarkhq/sdk-roark-analytics-python/commit/411d827b7e2ad44f1be3083cded6dc971971d233))
* **api:** api update ([5b42797](https://github.com/roarkhq/sdk-roark-analytics-python/commit/5b427971940b99547e10204f48c96706fbfe9f9d))
* **api:** api update ([209fe57](https://github.com/roarkhq/sdk-roark-analytics-python/commit/209fe576a00bc2f97bc18d4c8aa346125af7fd4a))

## 1.167.0 (2025-05-28)

Full Changelog: [v1.166.0...v1.167.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.166.0...v1.167.0)

### Features

* **api:** api update ([2083d66](https://github.com/roarkhq/sdk-roark-analytics-python/commit/2083d66867251ee601a2efccac73199f2d01f4f6))
* **api:** api update ([bd587f1](https://github.com/roarkhq/sdk-roark-analytics-python/commit/bd587f183b7a588edfd64f68d6f8d787f394922c))

## 1.166.0 (2025-05-27)

Full Changelog: [v1.165.0...v1.166.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.165.0...v1.166.0)

### Features

* **api:** api update ([1e54a85](https://github.com/roarkhq/sdk-roark-analytics-python/commit/1e54a8533a67a230e9b8a054f8c8a4346a0113c0))
* **api:** api update ([936a10b](https://github.com/roarkhq/sdk-roark-analytics-python/commit/936a10b7fa8c255385201143f14ea91ed2f0ef91))

## 1.165.0 (2025-05-26)

Full Changelog: [v1.164.0...v1.165.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.164.0...v1.165.0)

### Features

* **api:** api update ([567c192](https://github.com/roarkhq/sdk-roark-analytics-python/commit/567c19238ef05f733b33787a8af8f8f20a6096ee))

## 1.164.0 (2025-05-26)

Full Changelog: [v1.163.0...v1.164.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.163.0...v1.164.0)

### Features

* **api:** api update ([84a7e92](https://github.com/roarkhq/sdk-roark-analytics-python/commit/84a7e92039110347d327cd867dce6e9c48db1589))
* **api:** api update ([ed0e4c7](https://github.com/roarkhq/sdk-roark-analytics-python/commit/ed0e4c7228432826c4f67b3eb6bfd10820f397e5))

## 1.163.0 (2025-05-26)

Full Changelog: [v1.162.0...v1.163.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.162.0...v1.163.0)

### Features

* **api:** api update ([312906f](https://github.com/roarkhq/sdk-roark-analytics-python/commit/312906f6a622d310cec42ba3c3710dbe8fe77333))
* **api:** api update ([3ab00bc](https://github.com/roarkhq/sdk-roark-analytics-python/commit/3ab00bcdb915b6e6df781c7767c33a67144d8403))
* **api:** api update ([5d83726](https://github.com/roarkhq/sdk-roark-analytics-python/commit/5d8372653f3c03596b6b859635c8c96a898969c0))

## 1.162.0 (2025-05-26)

Full Changelog: [v1.161.0...v1.162.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.161.0...v1.162.0)

### Features

* **api:** api update ([4f3c0f5](https://github.com/roarkhq/sdk-roark-analytics-python/commit/4f3c0f588809811de804df2cec7db87da0097d46))
* **api:** api update ([b45ca91](https://github.com/roarkhq/sdk-roark-analytics-python/commit/b45ca914ed179374da4a4ad491bba8ef96fbbd2e))

## 1.161.0 (2025-05-26)

Full Changelog: [v1.160.0...v1.161.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.160.0...v1.161.0)

### Features

* **api:** api update ([7d66a22](https://github.com/roarkhq/sdk-roark-analytics-python/commit/7d66a225a4d8ec4f96fde61f8247ce55361f476e))
* **api:** api update ([44594db](https://github.com/roarkhq/sdk-roark-analytics-python/commit/44594dba78011e6c0065c063f41dbabd6ee2c452))
* **api:** api update ([89668b7](https://github.com/roarkhq/sdk-roark-analytics-python/commit/89668b7afe4f5308ea92211f6aa6c695815b8340))
* **api:** api update ([eca8831](https://github.com/roarkhq/sdk-roark-analytics-python/commit/eca88317b7040303e2eac716fcd704421c39461a))
* **api:** api update ([0be8f95](https://github.com/roarkhq/sdk-roark-analytics-python/commit/0be8f95e5433ad57c583ed052cbda1aa14fb7a0e))
* **api:** api update ([fb13b9d](https://github.com/roarkhq/sdk-roark-analytics-python/commit/fb13b9d3706b91b790197d3e73e2a17444914ae2))
* **api:** api update ([ab186b0](https://github.com/roarkhq/sdk-roark-analytics-python/commit/ab186b0e3e1c36c4326e5a32ea5ed0a2485d7a55))
* **api:** api update ([fa4548f](https://github.com/roarkhq/sdk-roark-analytics-python/commit/fa4548fde2504b659375a865f4e448f708f0bc0e))
* **api:** api update ([1586d90](https://github.com/roarkhq/sdk-roark-analytics-python/commit/1586d90bb5ed798876fc478f9af5d0b845e1fb58))
* **api:** api update ([79d51df](https://github.com/roarkhq/sdk-roark-analytics-python/commit/79d51df928a04f27eeb893bf4bbb60e9e30b7c14))

## 1.160.0 (2025-05-25)

Full Changelog: [v1.159.0...v1.160.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.159.0...v1.160.0)

### Features

* **api:** api update ([67fcbdc](https://github.com/roarkhq/sdk-roark-analytics-python/commit/67fcbdc6b21b96f4c66939efe24b875df577c161))

## 1.159.0 (2025-05-25)

Full Changelog: [v1.158.0...v1.159.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.158.0...v1.159.0)

### Features

* **api:** api update ([a10d78d](https://github.com/roarkhq/sdk-roark-analytics-python/commit/a10d78d50d90dfbedde6e13fd8a86f6a1880f89b))

## 1.158.0 (2025-05-23)

Full Changelog: [v1.157.0...v1.158.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.157.0...v1.158.0)

### Features

* **api:** api update ([a09ca9c](https://github.com/roarkhq/sdk-roark-analytics-python/commit/a09ca9cfa70504c8fecbda3b7b4974094eacf505))

## 1.157.0 (2025-05-22)

Full Changelog: [v1.156.0...v1.157.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.156.0...v1.157.0)

### Features

* **api:** api update ([50c04e1](https://github.com/roarkhq/sdk-roark-analytics-python/commit/50c04e1c7eb12592320fb953ae033c88977fecde))

## 1.156.0 (2025-05-22)

Full Changelog: [v1.155.0...v1.156.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.155.0...v1.156.0)

### Features

* **api:** api update ([094e127](https://github.com/roarkhq/sdk-roark-analytics-python/commit/094e1273fca592b0f52b59a53deb3e55f1996ced))

## 1.155.0 (2025-05-22)

Full Changelog: [v1.154.0...v1.155.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.154.0...v1.155.0)

### Features

* **api:** api update ([a1000ce](https://github.com/roarkhq/sdk-roark-analytics-python/commit/a1000ce5785f820d065bf953825072be9401e667))


### Chores

* **docs:** grammar improvements ([4afeb1e](https://github.com/roarkhq/sdk-roark-analytics-python/commit/4afeb1eec4989d9ca193d3a16278bd28d0f26968))

## 1.154.0 (2025-05-22)

Full Changelog: [v1.153.0...v1.154.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.153.0...v1.154.0)

### Features

* **api:** api update ([9dd4e3d](https://github.com/roarkhq/sdk-roark-analytics-python/commit/9dd4e3d9dd60a43abff763e8871a02079d2a7c63))
* **api:** api update ([4b25bab](https://github.com/roarkhq/sdk-roark-analytics-python/commit/4b25bab71e465c630d57f910015a6ddaa166819f))
* **api:** api update ([9c7ad51](https://github.com/roarkhq/sdk-roark-analytics-python/commit/9c7ad51071313c21d9754c1153422211372c0cdf))

## 1.153.0 (2025-05-21)

Full Changelog: [v1.152.0...v1.153.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.152.0...v1.153.0)

### Features

* **api:** api update ([344e375](https://github.com/roarkhq/sdk-roark-analytics-python/commit/344e375944d0a50e92a15545a5ffb184222c2979))

## 1.152.0 (2025-05-21)

Full Changelog: [v1.151.0...v1.152.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.151.0...v1.152.0)

### Features

* **api:** api update ([869d2f2](https://github.com/roarkhq/sdk-roark-analytics-python/commit/869d2f2ea717c5c3f802261847069d324cb30b08))
* **api:** api update ([a27c0dd](https://github.com/roarkhq/sdk-roark-analytics-python/commit/a27c0dd6938303daf2e80de789a46f4a61bbe714))
* **api:** api update ([728c969](https://github.com/roarkhq/sdk-roark-analytics-python/commit/728c969cd5257a6ba7fb6c4504213b9dd6c286eb))

## 1.151.0 (2025-05-20)

Full Changelog: [v1.150.0...v1.151.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.150.0...v1.151.0)

### Features

* **api:** api update ([d3b94d7](https://github.com/roarkhq/sdk-roark-analytics-python/commit/d3b94d7fc50de8782c433290fb17a60cbd659345))
* **api:** api update ([38f4e7d](https://github.com/roarkhq/sdk-roark-analytics-python/commit/38f4e7d588529df29a2f2d2387345e17afae0c3c))
* **api:** api update ([418c2b0](https://github.com/roarkhq/sdk-roark-analytics-python/commit/418c2b05fd374153df030ea6220d0cf015f98d24))
* **api:** api update ([3f9a4d9](https://github.com/roarkhq/sdk-roark-analytics-python/commit/3f9a4d90f54c0d9d636cc108aa721d55a60724da))

## 1.150.0 (2025-05-19)

Full Changelog: [v1.149.0...v1.150.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.149.0...v1.150.0)

### Features

* **api:** api update ([c04765b](https://github.com/roarkhq/sdk-roark-analytics-python/commit/c04765bf379522111b198c64071d1bef2ceec2e9))

## 1.149.0 (2025-05-19)

Full Changelog: [v1.148.0...v1.149.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.148.0...v1.149.0)

### Features

* **api:** api update ([dc142be](https://github.com/roarkhq/sdk-roark-analytics-python/commit/dc142be56314abd0acb8cd5f5a7ec37d543370ee))
* **api:** api update ([882586a](https://github.com/roarkhq/sdk-roark-analytics-python/commit/882586a8293224ba9a04dfa8b23a9e5cb606e499))
* **api:** api update ([f817f1c](https://github.com/roarkhq/sdk-roark-analytics-python/commit/f817f1c76cb72ee606c8bea16a1c31c403aa4f58))

## 1.148.0 (2025-05-19)

Full Changelog: [v1.147.0...v1.148.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.147.0...v1.148.0)

### Features

* **api:** api update ([88a0a9d](https://github.com/roarkhq/sdk-roark-analytics-python/commit/88a0a9d4f20583b99284081f701b091e748aaba3))
* **api:** api update ([044a31a](https://github.com/roarkhq/sdk-roark-analytics-python/commit/044a31a0836f4380d66ada6824f4e2a280034610))
* **api:** api update ([16988a1](https://github.com/roarkhq/sdk-roark-analytics-python/commit/16988a13a253bd07e51817cb2913aa6f4ff19107))

## 1.147.0 (2025-05-19)

Full Changelog: [v1.146.0...v1.147.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.146.0...v1.147.0)

### Features

* **api:** api update ([39125e9](https://github.com/roarkhq/sdk-roark-analytics-python/commit/39125e9f7a616c5df748a96bc3f1f790abaa9077))

## 1.146.0 (2025-05-19)

Full Changelog: [v1.145.0...v1.146.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.145.0...v1.146.0)

### Features

* **api:** api update ([35a02d8](https://github.com/roarkhq/sdk-roark-analytics-python/commit/35a02d8b9d5ef030c523aeff654df8dc8562d673))

## 1.145.0 (2025-05-19)

Full Changelog: [v1.144.0...v1.145.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.144.0...v1.145.0)

### Features

* **api:** api update ([74612a4](https://github.com/roarkhq/sdk-roark-analytics-python/commit/74612a408e8ded31054f1f7163d4073a831c2f59))

## 1.144.0 (2025-05-19)

Full Changelog: [v1.143.0...v1.144.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.143.0...v1.144.0)

### Features

* **api:** api update ([5a3fb6e](https://github.com/roarkhq/sdk-roark-analytics-python/commit/5a3fb6e557ce9daf61e0e48d295f4fee314e3cb0))
* **api:** api update ([80eedfd](https://github.com/roarkhq/sdk-roark-analytics-python/commit/80eedfdce97de982afc1d028c69625714f6af36f))
* **api:** api update ([c250923](https://github.com/roarkhq/sdk-roark-analytics-python/commit/c25092381985e709da4a580d0a74e5e9897cadf0))
* **api:** api update ([f1d9cfb](https://github.com/roarkhq/sdk-roark-analytics-python/commit/f1d9cfb430d89cf791c7923ed0efd4bf088667a0))

## 1.143.0 (2025-05-16)

Full Changelog: [v1.142.0...v1.143.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.142.0...v1.143.0)

### Features

* **api:** api update ([fe1afa6](https://github.com/roarkhq/sdk-roark-analytics-python/commit/fe1afa62e6a064c1a88b24344de388fd99e642d2))
* **api:** api update ([31a1204](https://github.com/roarkhq/sdk-roark-analytics-python/commit/31a120435d5d7128f85f7cc13ac67eb4902bbff7))
* **api:** api update ([95650e9](https://github.com/roarkhq/sdk-roark-analytics-python/commit/95650e90f3e489005fea85fc000334cf802ada93))


### Chores

* **ci:** fix installation instructions ([3798296](https://github.com/roarkhq/sdk-roark-analytics-python/commit/3798296527e639f35e223cfadf9b3dd45dcaf62c))
* **ci:** upload sdks to package manager ([ff7763c](https://github.com/roarkhq/sdk-roark-analytics-python/commit/ff7763cbdddfb6d20de6b205efbf1ef379ba00e7))

## 1.142.0 (2025-05-14)

Full Changelog: [v1.141.0...v1.142.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.141.0...v1.142.0)

### Features

* **api:** api update ([27b90aa](https://github.com/roarkhq/sdk-roark-analytics-python/commit/27b90aa4df58f13c5fb32a44fe43f93e6aec398d))
* **api:** api update ([c7c0b08](https://github.com/roarkhq/sdk-roark-analytics-python/commit/c7c0b08d18f4318f6108c6c2b91b99ba7f1a1d7e))


### Chores

* **internal:** codegen related update ([66f87eb](https://github.com/roarkhq/sdk-roark-analytics-python/commit/66f87eb94d4e74b72673725c69621fdb29b48e5b))

## 1.141.0 (2025-05-13)

Full Changelog: [v1.140.0...v1.141.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.140.0...v1.141.0)

### Features

* **api:** api update ([b5177a7](https://github.com/roarkhq/sdk-roark-analytics-python/commit/b5177a7f69cdd4a2c084a355a33f10db07dcf6aa))


### Chores

* **internal:** codegen related update ([5dc232f](https://github.com/roarkhq/sdk-roark-analytics-python/commit/5dc232f1b922e8f2be41578024b4c70adf051d85))

## 1.140.0 (2025-05-12)

Full Changelog: [v1.139.0...v1.140.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.139.0...v1.140.0)

### Features

* **api:** api update ([e41d6bc](https://github.com/roarkhq/sdk-roark-analytics-python/commit/e41d6bc61d3d74149f5d05ce46f226760262867d))
* **api:** api update ([b3b7d3b](https://github.com/roarkhq/sdk-roark-analytics-python/commit/b3b7d3bc603e91b081c9fd837c002ad938dba6a8))

## 1.139.0 (2025-05-11)

Full Changelog: [v1.138.0...v1.139.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.138.0...v1.139.0)

### Features

* **api:** api update ([e609e79](https://github.com/roarkhq/sdk-roark-analytics-python/commit/e609e79e8e7e8fc3abb1de7c750e84e93dfde1ba))

## 1.138.0 (2025-05-10)

Full Changelog: [v1.137.0...v1.138.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.137.0...v1.138.0)

### Features

* **api:** api update ([84a6126](https://github.com/roarkhq/sdk-roark-analytics-python/commit/84a6126eb6c2dc8e514395e738ff0c4fc6b5943f))


### Bug Fixes

* **package:** support direct resource imports ([8d949a6](https://github.com/roarkhq/sdk-roark-analytics-python/commit/8d949a65db80f495751ca19bd91d2cf34dbac192))

## 1.137.0 (2025-05-09)

Full Changelog: [v1.136.0...v1.137.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.136.0...v1.137.0)

### Features

* **api:** api update ([5b39a9b](https://github.com/roarkhq/sdk-roark-analytics-python/commit/5b39a9b5e5f785a5d8418db791da93ae6fb507bf))


### Chores

* **internal:** avoid errors for isinstance checks on proxies ([69658b4](https://github.com/roarkhq/sdk-roark-analytics-python/commit/69658b4931e60378499cb68b697fcbc0ef2fa60b))

## 1.136.0 (2025-05-08)

Full Changelog: [v1.135.0...v1.136.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.135.0...v1.136.0)

### Features

* **api:** api update ([98960ad](https://github.com/roarkhq/sdk-roark-analytics-python/commit/98960ad4dedc39c8bc92d57c54b7fe1040180674))
* **api:** api update ([2d3443c](https://github.com/roarkhq/sdk-roark-analytics-python/commit/2d3443c1c1ff775a00c3009dda875420a8ca878a))
* **api:** api update ([b07c60a](https://github.com/roarkhq/sdk-roark-analytics-python/commit/b07c60af67971a4b1c683514661e4b88da1a540b))
* **api:** api update ([0eca2d5](https://github.com/roarkhq/sdk-roark-analytics-python/commit/0eca2d5253e6edfa195d436b7530277a10ef707a))

## 1.135.0 (2025-05-07)

Full Changelog: [v1.134.0...v1.135.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.134.0...v1.135.0)

### Features

* **api:** api update ([f161eec](https://github.com/roarkhq/sdk-roark-analytics-python/commit/f161eecc531f62a0b358e3847e340555932b73da))

## 1.134.0 (2025-05-07)

Full Changelog: [v1.133.0...v1.134.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.133.0...v1.134.0)

### Features

* **api:** api update ([7cf6b22](https://github.com/roarkhq/sdk-roark-analytics-python/commit/7cf6b220dbdda81ac933828ea7bacacc7e79d4d5))
* **api:** api update ([cb71714](https://github.com/roarkhq/sdk-roark-analytics-python/commit/cb71714a5e9391f2ccaa37cf56ee961f92f9f06d))

## 1.133.0 (2025-05-07)

Full Changelog: [v1.132.0...v1.133.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.132.0...v1.133.0)

### Features

* **api:** api update ([8f47abd](https://github.com/roarkhq/sdk-roark-analytics-python/commit/8f47abd6af4117ca6c642d85fa3257e631974cc8))
* **api:** api update ([ca16081](https://github.com/roarkhq/sdk-roark-analytics-python/commit/ca16081fbcfe0ae856fe006f4c887782704026cf))

## 1.132.0 (2025-05-07)

Full Changelog: [v1.131.0...v1.132.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.131.0...v1.132.0)

### Features

* **api:** api update ([c03320e](https://github.com/roarkhq/sdk-roark-analytics-python/commit/c03320e31f00ea532eed08035824fcf1a572d4b7))

## 1.131.0 (2025-05-06)

Full Changelog: [v1.130.0...v1.131.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.130.0...v1.131.0)

### Features

* **api:** api update ([c3bcf28](https://github.com/roarkhq/sdk-roark-analytics-python/commit/c3bcf2810795aad33c586c25e63f8a4b76cee24c))
* **api:** api update ([f8dacbc](https://github.com/roarkhq/sdk-roark-analytics-python/commit/f8dacbc1610d88544a8728fb342a7cbcbffc3240))
* **api:** api update ([86d9a50](https://github.com/roarkhq/sdk-roark-analytics-python/commit/86d9a50c2f2ae04f1af4b0deab00ac77618c9510))

## 1.130.0 (2025-05-05)

Full Changelog: [v1.129.0...v1.130.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.129.0...v1.130.0)

### Features

* **api:** api update ([380e6d9](https://github.com/roarkhq/sdk-roark-analytics-python/commit/380e6d99cafcbf78f2904cdd8f7027786e4a90b7))

## 1.129.0 (2025-05-05)

Full Changelog: [v1.128.0...v1.129.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.128.0...v1.129.0)

### Features

* **api:** api update ([6a0e844](https://github.com/roarkhq/sdk-roark-analytics-python/commit/6a0e844526c5d4192c7259d4421aff7b25a775e8))
* **api:** api update ([481aa06](https://github.com/roarkhq/sdk-roark-analytics-python/commit/481aa061313044f9ba2d5f119898eb61d70897c8))
* **api:** api update ([876cf91](https://github.com/roarkhq/sdk-roark-analytics-python/commit/876cf91a731b0ad83833e4cebefe8ef9d49be5dc))

## 1.128.0 (2025-05-03)

Full Changelog: [v1.127.0...v1.128.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.127.0...v1.128.0)

### Features

* **api:** api update ([8fa3989](https://github.com/roarkhq/sdk-roark-analytics-python/commit/8fa3989171c7d7dce987d9b5586ec9ed8b50c8b9))
* **api:** api update ([931c3bb](https://github.com/roarkhq/sdk-roark-analytics-python/commit/931c3bb44399dd62d268ab093464c2369f925fec))
* **api:** api update ([649aeac](https://github.com/roarkhq/sdk-roark-analytics-python/commit/649aeac07f8c8449719252d8b4bb69ef683ff4b5))
* **api:** api update ([f55d4ec](https://github.com/roarkhq/sdk-roark-analytics-python/commit/f55d4ec01155b6ae04bef210c545d9283d638344))
* **api:** api update ([3f72b02](https://github.com/roarkhq/sdk-roark-analytics-python/commit/3f72b02a91482f49fd140ee433fae15e2c61cb9c))

## 1.127.0 (2025-05-02)

Full Changelog: [v1.126.0...v1.127.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.126.0...v1.127.0)

### Features

* **api:** api update ([a3891b4](https://github.com/roarkhq/sdk-roark-analytics-python/commit/a3891b4bf7accd00568406311637aa0ccceae8c9))
* **api:** api update ([76d0c80](https://github.com/roarkhq/sdk-roark-analytics-python/commit/76d0c8076087128852958a2f0b370baa29c1600c))

## 1.126.0 (2025-05-02)

Full Changelog: [v1.125.0...v1.126.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.125.0...v1.126.0)

### Features

* **api:** api update ([22f5c79](https://github.com/roarkhq/sdk-roark-analytics-python/commit/22f5c7931f2bc60841ada6fbc3defe4055ba932a))
* **api:** api update ([e9eab64](https://github.com/roarkhq/sdk-roark-analytics-python/commit/e9eab642e7cdeddf997e210fed5608576798863a))
* **api:** api update ([4944455](https://github.com/roarkhq/sdk-roark-analytics-python/commit/49444555da91dab80b0458ca8aea97fabae5bfe0))
* **api:** api update ([69d0977](https://github.com/roarkhq/sdk-roark-analytics-python/commit/69d09777d3b0aa49f4e494e8bdc52e0cd747a931))
* **api:** api update ([8c7f09e](https://github.com/roarkhq/sdk-roark-analytics-python/commit/8c7f09eca592b583dc83b0c172b4f20527c3abd0))
* **api:** api update ([1bdd4c9](https://github.com/roarkhq/sdk-roark-analytics-python/commit/1bdd4c97054a3f874ed14449da637beb1108ed8d))
* **api:** api update ([99f58bb](https://github.com/roarkhq/sdk-roark-analytics-python/commit/99f58bb75d5086e4229c993a0c15af68c3ea8f5f))
* **api:** api update ([e20e53a](https://github.com/roarkhq/sdk-roark-analytics-python/commit/e20e53a1f4d097753f1c481dd8e379d0a57fa460))

## 1.125.0 (2025-05-01)

Full Changelog: [v1.124.0...v1.125.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.124.0...v1.125.0)

### Features

* **api:** api update ([32d8b00](https://github.com/roarkhq/sdk-roark-analytics-python/commit/32d8b00238cde5a11de077dc176ed47794c01bb8))
* **api:** api update ([6f39dc2](https://github.com/roarkhq/sdk-roark-analytics-python/commit/6f39dc262bd705ba91252ab143405e33aade57c5))

## 1.124.0 (2025-04-30)

Full Changelog: [v1.123.0...v1.124.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.123.0...v1.124.0)

### Features

* **api:** api update ([8916362](https://github.com/roarkhq/sdk-roark-analytics-python/commit/89163625a54b9d5ffda7db3871b3aff1b6fc9e76))

## 1.123.0 (2025-04-29)

Full Changelog: [v1.122.0...v1.123.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.122.0...v1.123.0)

### Features

* **api:** api update ([27b9a4f](https://github.com/roarkhq/sdk-roark-analytics-python/commit/27b9a4f1565aded73eef25d2add1e4a5eabd296c))

## 1.122.0 (2025-04-29)

Full Changelog: [v1.121.0...v1.122.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.121.0...v1.122.0)

### Features

* **api:** api update ([8a0bac7](https://github.com/roarkhq/sdk-roark-analytics-python/commit/8a0bac7914f80e9f096dd463d94f17da4aff57f9))

## 1.121.0 (2025-04-29)

Full Changelog: [v1.120.0...v1.121.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.120.0...v1.121.0)

### Features

* **api:** api update ([02b3e41](https://github.com/roarkhq/sdk-roark-analytics-python/commit/02b3e418a71945abcc79d610fb7093b9faeb6fea))

## 1.120.0 (2025-04-27)

Full Changelog: [v1.119.0...v1.120.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.119.0...v1.120.0)

### Features

* **api:** api update ([58923ce](https://github.com/roarkhq/sdk-roark-analytics-python/commit/58923ceeb4c6cb3424257cb191fa5e91eb117bde))

## 1.119.0 (2025-04-25)

Full Changelog: [v1.118.0...v1.119.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.118.0...v1.119.0)

### Features

* **api:** api update ([dc1d7df](https://github.com/roarkhq/sdk-roark-analytics-python/commit/dc1d7df0ad759ef88c1ac03a48df396905fb876d))
* **api:** api update ([ae58fbf](https://github.com/roarkhq/sdk-roark-analytics-python/commit/ae58fbff93929cff7f1853f2c4d669e5b2b50b59))
* **api:** api update ([81ef175](https://github.com/roarkhq/sdk-roark-analytics-python/commit/81ef17546b303aee012104018e18aa93da91ff25))
* **api:** api update ([3517f6f](https://github.com/roarkhq/sdk-roark-analytics-python/commit/3517f6fb46ffef447757916c63de568afdb8194f))
* **api:** api update ([2fadcc1](https://github.com/roarkhq/sdk-roark-analytics-python/commit/2fadcc1fb7e242b7ee0a119b08c9d229596960eb))
* **api:** api update ([5f82124](https://github.com/roarkhq/sdk-roark-analytics-python/commit/5f8212424553f5263d9958e7402cc8845011eb0f))
* **api:** api update ([8aa736d](https://github.com/roarkhq/sdk-roark-analytics-python/commit/8aa736dac8040c969eec8940ccd19ae9b3f25bf5))
* **api:** api update ([b377722](https://github.com/roarkhq/sdk-roark-analytics-python/commit/b377722859d56484798d75e34e35d197b739c1ea))

## 1.118.0 (2025-04-25)

Full Changelog: [v1.117.0...v1.118.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.117.0...v1.118.0)

### Features

* **api:** api update ([46603ae](https://github.com/roarkhq/sdk-roark-analytics-python/commit/46603ae4cf9172b8bd85e04f990db4e38d2cac59))
* **api:** api update ([410737b](https://github.com/roarkhq/sdk-roark-analytics-python/commit/410737bdec006800ac772f822146f817746e2fd8))
* **api:** api update ([2ee443c](https://github.com/roarkhq/sdk-roark-analytics-python/commit/2ee443c47cd4a1170b4be359610caa3a7c7eb025))


### Chores

* broadly detect json family of content-type headers ([386cf65](https://github.com/roarkhq/sdk-roark-analytics-python/commit/386cf65d3ccdc28f71043ff2111b81b63f72841a))
* **ci:** only use depot for staging repos ([9675544](https://github.com/roarkhq/sdk-roark-analytics-python/commit/96755447bc65a8bc26df93997e04cce58618865d))
* **internal:** codegen related update ([9347703](https://github.com/roarkhq/sdk-roark-analytics-python/commit/9347703238f9746a499d4f0dd25d301b09220082))

## 1.117.0 (2025-04-23)

Full Changelog: [v1.116.0...v1.117.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.116.0...v1.117.0)

### Features

* **api:** api update ([b1208ef](https://github.com/roarkhq/sdk-roark-analytics-python/commit/b1208ef735e650d539f26a4862e1bbfabc9fee7f))


### Bug Fixes

* **pydantic v1:** more robust ModelField.annotation check ([092e0d6](https://github.com/roarkhq/sdk-roark-analytics-python/commit/092e0d6f3467fb14bbe22c82e088e3ddb6bc3d27))


### Chores

* **ci:** add timeout thresholds for CI jobs ([d8694af](https://github.com/roarkhq/sdk-roark-analytics-python/commit/d8694af3dd264b7d949884270a379319bfa1adbe))
* **internal:** fix list file params ([175ac5a](https://github.com/roarkhq/sdk-roark-analytics-python/commit/175ac5a875b67121fa9ae767b496bc761ff345f8))
* **internal:** import reformatting ([525e2bf](https://github.com/roarkhq/sdk-roark-analytics-python/commit/525e2bf514c5b5a6119a4692aaffe4490244fa25))
* **internal:** refactor retries to not use recursion ([033cd6a](https://github.com/roarkhq/sdk-roark-analytics-python/commit/033cd6ad05a24d4b54a473211e993a106bd8cfa0))

## 1.116.0 (2025-04-23)

Full Changelog: [v1.115.0...v1.116.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.115.0...v1.116.0)

### Features

* **api:** api update ([c284692](https://github.com/roarkhq/sdk-roark-analytics-python/commit/c284692852ea203ada673c0598fbe9ca88266dcf))
* **api:** api update ([b84dce8](https://github.com/roarkhq/sdk-roark-analytics-python/commit/b84dce8d23ec8e449124c4fe6a2ad228a2ed721d))
* **api:** api update ([849655f](https://github.com/roarkhq/sdk-roark-analytics-python/commit/849655f7dc5b9bd3505f5ab0ecf6cb8fb489ca70))

## 1.115.0 (2025-04-22)

Full Changelog: [v1.114.0...v1.115.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.114.0...v1.115.0)

### Features

* **api:** api update ([83aaadf](https://github.com/roarkhq/sdk-roark-analytics-python/commit/83aaadf5dfb4a07a139f44745bb71128c75d25e5))
* **api:** api update ([ddf0c1a](https://github.com/roarkhq/sdk-roark-analytics-python/commit/ddf0c1a29f89944a16ecf631adffb5a0779b04c1))

## 1.114.0 (2025-04-20)

Full Changelog: [v1.113.0...v1.114.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.113.0...v1.114.0)

### Features

* **api:** api update ([a45337f](https://github.com/roarkhq/sdk-roark-analytics-python/commit/a45337fc52a04c465216226336435e46944dc844))

## 1.113.0 (2025-04-19)

Full Changelog: [v1.112.0...v1.113.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.112.0...v1.113.0)

### Features

* **api:** api update ([d26a318](https://github.com/roarkhq/sdk-roark-analytics-python/commit/d26a3189800c76d38fb118cef03d63708154121a))


### Chores

* **internal:** update models test ([e82a1f3](https://github.com/roarkhq/sdk-roark-analytics-python/commit/e82a1f3e852a6367e68e078965eb0a02a3c65901))

## 1.112.0 (2025-04-17)

Full Changelog: [v1.111.0...v1.112.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.111.0...v1.112.0)

### Features

* **api:** api update ([b6e456a](https://github.com/roarkhq/sdk-roark-analytics-python/commit/b6e456a93127dc2fc785157608d0fc433fa84ccf))
* **api:** api update ([1e78595](https://github.com/roarkhq/sdk-roark-analytics-python/commit/1e78595ea2acdf2772706aa6233a78c4fedfd314))
* **api:** api update ([6fed2f5](https://github.com/roarkhq/sdk-roark-analytics-python/commit/6fed2f5e7da8846397bdbc9f763a1af71f4917d4))
* **api:** api update ([6e0e777](https://github.com/roarkhq/sdk-roark-analytics-python/commit/6e0e777f8762ab7a577c02234d3b09a64f04d88c))
* **api:** api update ([6293b51](https://github.com/roarkhq/sdk-roark-analytics-python/commit/6293b51d1632f6e3865c851d7bb96ed4fa7728f7))

## 1.111.0 (2025-04-17)

Full Changelog: [v1.110.0...v1.111.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.110.0...v1.111.0)

### Features

* **api:** api update ([024bb2d](https://github.com/roarkhq/sdk-roark-analytics-python/commit/024bb2d8c1953880f5a15b44e30a5e558634aeb7))


### Chores

* **internal:** base client updates ([771e103](https://github.com/roarkhq/sdk-roark-analytics-python/commit/771e103dd2c363c955a0168a80287eea62bb45f4))
* **internal:** bump pyright version ([b41735b](https://github.com/roarkhq/sdk-roark-analytics-python/commit/b41735bddbb26f6f683b2310375786d8d74efecd))

## 1.110.0 (2025-04-17)

Full Changelog: [v1.109.0...v1.110.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.109.0...v1.110.0)

### Features

* **api:** api update ([ca8663a](https://github.com/roarkhq/sdk-roark-analytics-python/commit/ca8663a23ea0378a8504ae5ecce6ff07ba2fccdd))
* **api:** api update ([c77e89a](https://github.com/roarkhq/sdk-roark-analytics-python/commit/c77e89ac0dfcc904add8b5ca0be02817c7b5a8fe))
* **api:** api update ([6b51965](https://github.com/roarkhq/sdk-roark-analytics-python/commit/6b5196593e0758f0dd58fc3225620bf479f47f55))
* **api:** api update ([451e925](https://github.com/roarkhq/sdk-roark-analytics-python/commit/451e9255cfd060993d183c78035436cf208823cc))
* **api:** api update ([2fe19fe](https://github.com/roarkhq/sdk-roark-analytics-python/commit/2fe19febd8c64fb82b9eb74bfae14067582fe986))
* **api:** api update ([cea498b](https://github.com/roarkhq/sdk-roark-analytics-python/commit/cea498b0fa11667c908e979d17f4dd3195653d17))
* **api:** api update ([d6a4800](https://github.com/roarkhq/sdk-roark-analytics-python/commit/d6a480040eee76cb4474b7b8345d522158e4d3aa))
* **api:** api update ([c037589](https://github.com/roarkhq/sdk-roark-analytics-python/commit/c0375895d30b9ee2dcb44e5100f867eb68a17933))
* **api:** api update ([1567c49](https://github.com/roarkhq/sdk-roark-analytics-python/commit/1567c4939523091cc4763108311b7e11eebb93b1))
* **api:** api update ([c77e27f](https://github.com/roarkhq/sdk-roark-analytics-python/commit/c77e27f86a18c3903e11a7ab6732f91ccc91c2bf))
* **api:** api update ([8924fc6](https://github.com/roarkhq/sdk-roark-analytics-python/commit/8924fc6624af245afd7c95e29b4c366134266a40))
* **api:** api update ([aefd398](https://github.com/roarkhq/sdk-roark-analytics-python/commit/aefd39866efef4811ff90ff8129e5e7af62bf9bc))
* **api:** api update ([b064697](https://github.com/roarkhq/sdk-roark-analytics-python/commit/b064697d1ed8fa5e2175d9736142bd54825f49a2))
* **api:** api update ([fa9b839](https://github.com/roarkhq/sdk-roark-analytics-python/commit/fa9b8399741baaa0c0508c86735fcf7cfb768ab2))
* **api:** api update ([f1ecf80](https://github.com/roarkhq/sdk-roark-analytics-python/commit/f1ecf804c1642b767d7e8b579cb0af461997c67f))
* **api:** api update ([6b7a064](https://github.com/roarkhq/sdk-roark-analytics-python/commit/6b7a0645c59709e980da81bedf704b6e12a4c364))
* **api:** api update ([5f33c34](https://github.com/roarkhq/sdk-roark-analytics-python/commit/5f33c3449282e8d979804d6a907ac3d864871545))
* **api:** api update ([ae18337](https://github.com/roarkhq/sdk-roark-analytics-python/commit/ae1833721089651a7cf79569bbcdb49ce811882f))
* **api:** api update ([05ae8b6](https://github.com/roarkhq/sdk-roark-analytics-python/commit/05ae8b6c4b389318adabce4788d43e01227f9d37))


### Bug Fixes

* **perf:** optimize some hot paths ([63a8baa](https://github.com/roarkhq/sdk-roark-analytics-python/commit/63a8baa69fb4f481486ffa27ec25b1a4ba17e605))
* **perf:** skip traversing types for NotGiven values ([8d54508](https://github.com/roarkhq/sdk-roark-analytics-python/commit/8d5450835c72383ac28b3c89323fdf15a93cc8e2))


### Chores

* **client:** minor internal fixes ([bc4999c](https://github.com/roarkhq/sdk-roark-analytics-python/commit/bc4999c0288d94832fdb3b4ea4ce0371b80b9796))
* **internal:** update pyright settings ([93c0e19](https://github.com/roarkhq/sdk-roark-analytics-python/commit/93c0e19a225cc1a0858a25d53d4f14a1f08d6bc5))

## 1.109.0 (2025-04-10)

Full Changelog: [v1.108.0...v1.109.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.108.0...v1.109.0)

### Features

* **api:** api update ([62eeed9](https://github.com/roarkhq/sdk-roark-analytics-python/commit/62eeed9e437af08e0d4a44a620739f9988613f42))


### Chores

* **internal:** expand CI branch coverage ([8927eaa](https://github.com/roarkhq/sdk-roark-analytics-python/commit/8927eaa511902c69fc591382a7ebbcc9b4a684fe))
* **internal:** reduce CI branch coverage ([fafa2e5](https://github.com/roarkhq/sdk-roark-analytics-python/commit/fafa2e5a65dc56a402defc8ed2e31408eef25b7b))
* **internal:** slight transform perf improvement ([#340](https://github.com/roarkhq/sdk-roark-analytics-python/issues/340)) ([65307be](https://github.com/roarkhq/sdk-roark-analytics-python/commit/65307beb20e9c79a4dea42adc9cbeffcb1ec4c92))
* **tests:** improve enum examples ([#341](https://github.com/roarkhq/sdk-roark-analytics-python/issues/341)) ([df0d6f7](https://github.com/roarkhq/sdk-roark-analytics-python/commit/df0d6f7f4aedcccff3eda4bc179c95079bc19499))

## 1.108.0 (2025-04-08)

Full Changelog: [v1.107.0...v1.108.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.107.0...v1.108.0)

### Features

* **api:** api update ([#338](https://github.com/roarkhq/sdk-roark-analytics-python/issues/338)) ([3d2a3dd](https://github.com/roarkhq/sdk-roark-analytics-python/commit/3d2a3ddde0daa40e175e18cc157b39b1ceeb04ed))

## 1.107.0 (2025-04-07)

Full Changelog: [v1.106.0...v1.107.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.106.0...v1.107.0)

### Features

* **api:** api update ([#335](https://github.com/roarkhq/sdk-roark-analytics-python/issues/335)) ([4cd726e](https://github.com/roarkhq/sdk-roark-analytics-python/commit/4cd726eb7f1daf41435b68689b03a61c2fbeb1cf))

## 1.106.0 (2025-04-07)

Full Changelog: [v1.105.0...v1.106.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.105.0...v1.106.0)

### Features

* **api:** api update ([#332](https://github.com/roarkhq/sdk-roark-analytics-python/issues/332)) ([5c021a5](https://github.com/roarkhq/sdk-roark-analytics-python/commit/5c021a524e17efad4a4cc63c8fbbe5e4e924bd26))

## 1.105.0 (2025-04-07)

Full Changelog: [v1.104.0...v1.105.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.104.0...v1.105.0)

### Features

* **api:** api update ([#329](https://github.com/roarkhq/sdk-roark-analytics-python/issues/329)) ([8326b59](https://github.com/roarkhq/sdk-roark-analytics-python/commit/8326b5930724d53f75f1704586223c1713388e94))

## 1.104.0 (2025-04-07)

Full Changelog: [v1.103.0...v1.104.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.103.0...v1.104.0)

### Features

* **api:** api update ([#326](https://github.com/roarkhq/sdk-roark-analytics-python/issues/326)) ([a28f6b1](https://github.com/roarkhq/sdk-roark-analytics-python/commit/a28f6b1c87d17660ce68ba1a73d5beba84950604))

## 1.103.0 (2025-04-06)

Full Changelog: [v1.102.0...v1.103.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.102.0...v1.103.0)

### Features

* **api:** api update ([#324](https://github.com/roarkhq/sdk-roark-analytics-python/issues/324)) ([95b2bec](https://github.com/roarkhq/sdk-roark-analytics-python/commit/95b2bec9d9209e2f1b42c49e906b5606fd4b99e7))


### Chores

* **internal:** remove trailing character ([#322](https://github.com/roarkhq/sdk-roark-analytics-python/issues/322)) ([41714b4](https://github.com/roarkhq/sdk-roark-analytics-python/commit/41714b49a880e534ab3b65972e15195f4a238149))

## 1.102.0 (2025-04-04)

Full Changelog: [v1.101.0...v1.102.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.101.0...v1.102.0)

### Features

* **api:** api update ([#319](https://github.com/roarkhq/sdk-roark-analytics-python/issues/319)) ([b57be52](https://github.com/roarkhq/sdk-roark-analytics-python/commit/b57be52a2e41c26025a18c805d21feb663aab373))

## 1.101.0 (2025-04-04)

Full Changelog: [v1.100.0...v1.101.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.100.0...v1.101.0)

### Features

* **api:** api update ([#316](https://github.com/roarkhq/sdk-roark-analytics-python/issues/316)) ([5a01507](https://github.com/roarkhq/sdk-roark-analytics-python/commit/5a01507c890974af082136a4441977e76efb85d5))

## 1.100.0 (2025-04-03)

Full Changelog: [v1.99.0...v1.100.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.99.0...v1.100.0)

### Features

* **api:** api update ([#313](https://github.com/roarkhq/sdk-roark-analytics-python/issues/313)) ([25410e7](https://github.com/roarkhq/sdk-roark-analytics-python/commit/25410e716c52c0ed924714c4400274a853b65f65))

## 1.99.0 (2025-04-03)

Full Changelog: [v1.98.0...v1.99.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.98.0...v1.99.0)

### Features

* **api:** api update ([#310](https://github.com/roarkhq/sdk-roark-analytics-python/issues/310)) ([f3fdc55](https://github.com/roarkhq/sdk-roark-analytics-python/commit/f3fdc55f3da3b11f6c3498bdbcd981d5cd4fe959))

## 1.98.0 (2025-04-03)

Full Changelog: [v1.97.0...v1.98.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.97.0...v1.98.0)

### Features

* **api:** api update ([#307](https://github.com/roarkhq/sdk-roark-analytics-python/issues/307)) ([b151baa](https://github.com/roarkhq/sdk-roark-analytics-python/commit/b151baa466f01a88919ff8b9dceb5374ce332c27))

## 1.97.0 (2025-04-03)

Full Changelog: [v1.96.0...v1.97.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.96.0...v1.97.0)

### Features

* **api:** api update ([#304](https://github.com/roarkhq/sdk-roark-analytics-python/issues/304)) ([c96ac8f](https://github.com/roarkhq/sdk-roark-analytics-python/commit/c96ac8f38cce660d6bd5b96a44ad6fd4f7e26156))

## 1.96.0 (2025-04-03)

Full Changelog: [v1.95.0...v1.96.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.95.0...v1.96.0)

### Features

* **api:** api update ([#301](https://github.com/roarkhq/sdk-roark-analytics-python/issues/301)) ([710549f](https://github.com/roarkhq/sdk-roark-analytics-python/commit/710549fcd026b576743c1d2f3d2c5fbb988f22e1))

## 1.95.0 (2025-04-03)

Full Changelog: [v1.94.0...v1.95.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.94.0...v1.95.0)

### Features

* **api:** api update ([#298](https://github.com/roarkhq/sdk-roark-analytics-python/issues/298)) ([66a708e](https://github.com/roarkhq/sdk-roark-analytics-python/commit/66a708ec5f92d15d504071e7c759b4823a3b3fd2))

## 1.94.0 (2025-04-03)

Full Changelog: [v1.93.0...v1.94.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.93.0...v1.94.0)

### Features

* **api:** api update ([#295](https://github.com/roarkhq/sdk-roark-analytics-python/issues/295)) ([4b4fe52](https://github.com/roarkhq/sdk-roark-analytics-python/commit/4b4fe52c1e0607c6f5c755b58ece7ff525f7512c))

## 1.93.0 (2025-04-02)

Full Changelog: [v1.92.0...v1.93.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.92.0...v1.93.0)

### Features

* **api:** api update ([#292](https://github.com/roarkhq/sdk-roark-analytics-python/issues/292)) ([c8b2406](https://github.com/roarkhq/sdk-roark-analytics-python/commit/c8b24061b2991843dd2aebfb2383dbe63633f92d))

## 1.92.0 (2025-04-02)

Full Changelog: [v1.91.0...v1.92.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.91.0...v1.92.0)

### Features

* **api:** api update ([#289](https://github.com/roarkhq/sdk-roark-analytics-python/issues/289)) ([93d1721](https://github.com/roarkhq/sdk-roark-analytics-python/commit/93d1721ca63ed90d5ce9897b70d0d795b01afb8b))

## 1.91.0 (2025-04-02)

Full Changelog: [v1.90.0...v1.91.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.90.0...v1.91.0)

### Features

* **api:** api update ([#286](https://github.com/roarkhq/sdk-roark-analytics-python/issues/286)) ([9d5e6d3](https://github.com/roarkhq/sdk-roark-analytics-python/commit/9d5e6d33f1307c0d9f82c01c46eb8b5e14ed1d6a))

## 1.90.0 (2025-04-02)

Full Changelog: [v1.89.0...v1.90.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.89.0...v1.90.0)

### Features

* **api:** api update ([#283](https://github.com/roarkhq/sdk-roark-analytics-python/issues/283)) ([d98661f](https://github.com/roarkhq/sdk-roark-analytics-python/commit/d98661f7065616e30ee225952015adf610bca0c8))

## 1.89.0 (2025-04-02)

Full Changelog: [v1.88.0...v1.89.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.88.0...v1.89.0)

### Features

* **api:** api update ([#280](https://github.com/roarkhq/sdk-roark-analytics-python/issues/280)) ([0bdd284](https://github.com/roarkhq/sdk-roark-analytics-python/commit/0bdd2844268157295cb349a0062bb0f2aba37db0))

## 1.88.0 (2025-04-01)

Full Changelog: [v1.87.0...v1.88.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.87.0...v1.88.0)

### Features

* **api:** api update ([#277](https://github.com/roarkhq/sdk-roark-analytics-python/issues/277)) ([3b4c4b6](https://github.com/roarkhq/sdk-roark-analytics-python/commit/3b4c4b68687b4d39c22fc244812e662f097053f7))

## 1.87.0 (2025-03-29)

Full Changelog: [v1.86.0...v1.87.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.86.0...v1.87.0)

### Features

* **api:** api update ([#274](https://github.com/roarkhq/sdk-roark-analytics-python/issues/274)) ([9ff6263](https://github.com/roarkhq/sdk-roark-analytics-python/commit/9ff62636097052487e42bec9b8461da7022fc298))

## 1.86.0 (2025-03-29)

Full Changelog: [v1.85.0...v1.86.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.85.0...v1.86.0)

### Features

* **api:** api update ([#271](https://github.com/roarkhq/sdk-roark-analytics-python/issues/271)) ([2ea52fe](https://github.com/roarkhq/sdk-roark-analytics-python/commit/2ea52fe76da910cba2652362c7e0c8d9c95dfef0))

## 1.85.0 (2025-03-28)

Full Changelog: [v1.84.0...v1.85.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.84.0...v1.85.0)

### Features

* **api:** api update ([#268](https://github.com/roarkhq/sdk-roark-analytics-python/issues/268)) ([649d9cb](https://github.com/roarkhq/sdk-roark-analytics-python/commit/649d9cb5bf7c62de7d5607792797e76f06913908))

## 1.84.0 (2025-03-26)

Full Changelog: [v1.83.0...v1.84.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.83.0...v1.84.0)

### Features

* **api:** api update ([#265](https://github.com/roarkhq/sdk-roark-analytics-python/issues/265)) ([6ff590b](https://github.com/roarkhq/sdk-roark-analytics-python/commit/6ff590b9959b5958da6de453cb55ec0c9b62bfb4))

## 1.83.0 (2025-03-26)

Full Changelog: [v1.82.0...v1.83.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.82.0...v1.83.0)

### Features

* **api:** api update ([#262](https://github.com/roarkhq/sdk-roark-analytics-python/issues/262)) ([203ea87](https://github.com/roarkhq/sdk-roark-analytics-python/commit/203ea877eb9f65c6e38ad4bbe0315dfedef82271))

## 1.82.0 (2025-03-26)

Full Changelog: [v1.81.0...v1.82.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.81.0...v1.82.0)

### Features

* **api:** api update ([#259](https://github.com/roarkhq/sdk-roark-analytics-python/issues/259)) ([3547928](https://github.com/roarkhq/sdk-roark-analytics-python/commit/35479281e3933ab28ec84ee193a656c51cc08c22))

## 1.81.0 (2025-03-25)

Full Changelog: [v1.80.0...v1.81.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.80.0...v1.81.0)

### Features

* **api:** api update ([#256](https://github.com/roarkhq/sdk-roark-analytics-python/issues/256)) ([f2db661](https://github.com/roarkhq/sdk-roark-analytics-python/commit/f2db661ba3fc443bac4577ab3539c3724c32b220))

## 1.80.0 (2025-03-25)

Full Changelog: [v1.79.0...v1.80.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.79.0...v1.80.0)

### Features

* **api:** api update ([#253](https://github.com/roarkhq/sdk-roark-analytics-python/issues/253)) ([1c787f4](https://github.com/roarkhq/sdk-roark-analytics-python/commit/1c787f4c87ac75a8767256572a5d353907e87d46))

## 1.79.0 (2025-03-25)

Full Changelog: [v1.78.0...v1.79.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.78.0...v1.79.0)

### Features

* **api:** api update ([#250](https://github.com/roarkhq/sdk-roark-analytics-python/issues/250)) ([9797f55](https://github.com/roarkhq/sdk-roark-analytics-python/commit/9797f55be1326adac883eb34555afef6f5c4bb66))

## 1.78.0 (2025-03-25)

Full Changelog: [v1.77.0...v1.78.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.77.0...v1.78.0)

### Features

* **api:** api update ([#247](https://github.com/roarkhq/sdk-roark-analytics-python/issues/247)) ([f2aebed](https://github.com/roarkhq/sdk-roark-analytics-python/commit/f2aebed1fc7ae1354b971b56d3bddd48e3a0f5c4))

## 1.77.0 (2025-03-23)

Full Changelog: [v1.76.0...v1.77.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.76.0...v1.77.0)

### Features

* **api:** api update ([#244](https://github.com/roarkhq/sdk-roark-analytics-python/issues/244)) ([4bd6947](https://github.com/roarkhq/sdk-roark-analytics-python/commit/4bd69471992faad1730788849e2ac1dfb9f897d5))

## 1.76.0 (2025-03-21)

Full Changelog: [v1.75.0...v1.76.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.75.0...v1.76.0)

### Features

* **api:** api update ([#241](https://github.com/roarkhq/sdk-roark-analytics-python/issues/241)) ([c79e867](https://github.com/roarkhq/sdk-roark-analytics-python/commit/c79e8675f715e5a9f1aff13ec2979961a74a371e))

## 1.75.0 (2025-03-20)

Full Changelog: [v1.74.0...v1.75.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.74.0...v1.75.0)

### Features

* **api:** api update ([#238](https://github.com/roarkhq/sdk-roark-analytics-python/issues/238)) ([3fa69fe](https://github.com/roarkhq/sdk-roark-analytics-python/commit/3fa69fe4b1f91283ccfb5706bfd9b468fb5d12c2))

## 1.74.0 (2025-03-20)

Full Changelog: [v1.73.0...v1.74.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.73.0...v1.74.0)

### Features

* **api:** api update ([#235](https://github.com/roarkhq/sdk-roark-analytics-python/issues/235)) ([24782eb](https://github.com/roarkhq/sdk-roark-analytics-python/commit/24782ebbfbb1e2c4580e732aedc2f7a0c10f23ec))

## 1.73.0 (2025-03-20)

Full Changelog: [v1.72.0...v1.73.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.72.0...v1.73.0)

### Features

* **api:** api update ([#232](https://github.com/roarkhq/sdk-roark-analytics-python/issues/232)) ([b220a4a](https://github.com/roarkhq/sdk-roark-analytics-python/commit/b220a4abd568474f6d3a499bcd1c7ab684cfc798))

## 1.72.0 (2025-03-20)

Full Changelog: [v1.71.0...v1.72.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.71.0...v1.72.0)

### Features

* **api:** api update ([#229](https://github.com/roarkhq/sdk-roark-analytics-python/issues/229)) ([b58dc34](https://github.com/roarkhq/sdk-roark-analytics-python/commit/b58dc3445bd8c5dd4a64b976751a91ee3c4901f1))

## 1.71.0 (2025-03-20)

Full Changelog: [v1.70.0...v1.71.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.70.0...v1.71.0)

### Features

* **api:** api update ([#226](https://github.com/roarkhq/sdk-roark-analytics-python/issues/226)) ([7797479](https://github.com/roarkhq/sdk-roark-analytics-python/commit/7797479a5df0ec7b1bdcf3b0b73497d3b13b1116))

## 1.70.0 (2025-03-20)

Full Changelog: [v1.69.0...v1.70.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.69.0...v1.70.0)

### Features

* **api:** api update ([#223](https://github.com/roarkhq/sdk-roark-analytics-python/issues/223)) ([ecd97e4](https://github.com/roarkhq/sdk-roark-analytics-python/commit/ecd97e406ac8a754581dce04e21e85134b0b5a11))

## 1.69.0 (2025-03-19)

Full Changelog: [v1.68.0...v1.69.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.68.0...v1.69.0)

### Features

* **api:** api update ([#220](https://github.com/roarkhq/sdk-roark-analytics-python/issues/220)) ([d18af4d](https://github.com/roarkhq/sdk-roark-analytics-python/commit/d18af4d20f5b9cf0b883bc1dcd7d86b37aebe6da))

## 1.68.0 (2025-03-19)

Full Changelog: [v1.67.0...v1.68.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.67.0...v1.68.0)

### Features

* **api:** api update ([#217](https://github.com/roarkhq/sdk-roark-analytics-python/issues/217)) ([e69bdfe](https://github.com/roarkhq/sdk-roark-analytics-python/commit/e69bdfefbcfc60384c872bc8e36edd262ff15125))

## 1.67.0 (2025-03-19)

Full Changelog: [v1.66.0...v1.67.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.66.0...v1.67.0)

### Features

* **api:** api update ([#214](https://github.com/roarkhq/sdk-roark-analytics-python/issues/214)) ([8589178](https://github.com/roarkhq/sdk-roark-analytics-python/commit/8589178ece30f3d0ac3f8ba1d8e53f1246d994c8))

## 1.66.0 (2025-03-18)

Full Changelog: [v1.65.0...v1.66.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.65.0...v1.66.0)

### Features

* **api:** api update ([#211](https://github.com/roarkhq/sdk-roark-analytics-python/issues/211)) ([5072903](https://github.com/roarkhq/sdk-roark-analytics-python/commit/507290385022d07bfea2f5b35c78539acc51c56e))

## 1.65.0 (2025-03-18)

Full Changelog: [v1.64.0...v1.65.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.64.0...v1.65.0)

### Features

* **api:** api update ([#207](https://github.com/roarkhq/sdk-roark-analytics-python/issues/207)) ([490341f](https://github.com/roarkhq/sdk-roark-analytics-python/commit/490341f75fa74d3a275616ceba0ff8d9df6deab6))
* **api:** api update ([#209](https://github.com/roarkhq/sdk-roark-analytics-python/issues/209)) ([d16a10b](https://github.com/roarkhq/sdk-roark-analytics-python/commit/d16a10b74d1268c3751045b925438ca07350f7cd))

## 1.64.0 (2025-03-17)

Full Changelog: [v1.63.0...v1.64.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.63.0...v1.64.0)

### Features

* **api:** api update ([#205](https://github.com/roarkhq/sdk-roark-analytics-python/issues/205)) ([ec0d678](https://github.com/roarkhq/sdk-roark-analytics-python/commit/ec0d6783545000a23df9e1e418f5738ab7c63273))


### Bug Fixes

* **ci:** ensure pip is always available ([#202](https://github.com/roarkhq/sdk-roark-analytics-python/issues/202)) ([be3b90c](https://github.com/roarkhq/sdk-roark-analytics-python/commit/be3b90c0a2399dda3580067054f4d51857569bc0))
* **ci:** remove publishing patch ([#204](https://github.com/roarkhq/sdk-roark-analytics-python/issues/204)) ([4dbcb4c](https://github.com/roarkhq/sdk-roark-analytics-python/commit/4dbcb4c3e5ddb06032dff43d158635f4dc423b34))

## 1.63.0 (2025-03-17)

Full Changelog: [v1.62.0...v1.63.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.62.0...v1.63.0)

### Features

* **api:** api update ([#199](https://github.com/roarkhq/sdk-roark-analytics-python/issues/199)) ([5eab2ca](https://github.com/roarkhq/sdk-roark-analytics-python/commit/5eab2ca62654805dea8f418b8f09194c9d427480))

## 1.62.0 (2025-03-17)

Full Changelog: [v1.61.0...v1.62.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.61.0...v1.62.0)

### Features

* **api:** api update ([#196](https://github.com/roarkhq/sdk-roark-analytics-python/issues/196)) ([b5288bd](https://github.com/roarkhq/sdk-roark-analytics-python/commit/b5288bdde42d0c7feceaa89df185271a7fdfa365))

## 1.61.0 (2025-03-17)

Full Changelog: [v1.60.0...v1.61.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.60.0...v1.61.0)

### Features

* **api:** api update ([#193](https://github.com/roarkhq/sdk-roark-analytics-python/issues/193)) ([849c20a](https://github.com/roarkhq/sdk-roark-analytics-python/commit/849c20a9d2c1ac5fa607416b8674f047ff1e1206))

## 1.60.0 (2025-03-17)

Full Changelog: [v1.59.0...v1.60.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.59.0...v1.60.0)

### Features

* **api:** api update ([#190](https://github.com/roarkhq/sdk-roark-analytics-python/issues/190)) ([8805d80](https://github.com/roarkhq/sdk-roark-analytics-python/commit/8805d803086aa36e870d581db061127d5c98d66f))

## 1.59.0 (2025-03-17)

Full Changelog: [v1.58.0...v1.59.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.58.0...v1.59.0)

### Features

* **api:** api update ([#187](https://github.com/roarkhq/sdk-roark-analytics-python/issues/187)) ([49bcddb](https://github.com/roarkhq/sdk-roark-analytics-python/commit/49bcddb82755096822baff600e353c2ac48a8f15))

## 1.58.0 (2025-03-17)

Full Changelog: [v1.57.0...v1.58.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.57.0...v1.58.0)

### Features

* **api:** api update ([#184](https://github.com/roarkhq/sdk-roark-analytics-python/issues/184)) ([e40ca8d](https://github.com/roarkhq/sdk-roark-analytics-python/commit/e40ca8d4f223251b758071155c504ff990269224))

## 1.57.0 (2025-03-17)

Full Changelog: [v1.56.0...v1.57.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.56.0...v1.57.0)

### Features

* **api:** api update ([#181](https://github.com/roarkhq/sdk-roark-analytics-python/issues/181)) ([c9c4052](https://github.com/roarkhq/sdk-roark-analytics-python/commit/c9c4052095e29fbe4f3191e8eec29c85a9c3d865))

## 1.56.0 (2025-03-17)

Full Changelog: [v1.55.0...v1.56.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.55.0...v1.56.0)

### Features

* **api:** api update ([#178](https://github.com/roarkhq/sdk-roark-analytics-python/issues/178)) ([c36325e](https://github.com/roarkhq/sdk-roark-analytics-python/commit/c36325e1cfc31c44130a5332fe4d8a8eab87b7ec))

## 1.55.0 (2025-03-17)

Full Changelog: [v1.54.0...v1.55.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.54.0...v1.55.0)

### Features

* **api:** api update ([#175](https://github.com/roarkhq/sdk-roark-analytics-python/issues/175)) ([ceb2550](https://github.com/roarkhq/sdk-roark-analytics-python/commit/ceb25500f262b40e4262c9a34b82f5a40f41a0ef))

## 1.54.0 (2025-03-17)

Full Changelog: [v1.53.0...v1.54.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.53.0...v1.54.0)

### Features

* **api:** api update ([#172](https://github.com/roarkhq/sdk-roark-analytics-python/issues/172)) ([286ba7c](https://github.com/roarkhq/sdk-roark-analytics-python/commit/286ba7ced9f77a72f95c2660ec87083752011b96))

## 1.53.0 (2025-03-17)

Full Changelog: [v1.52.0...v1.53.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.52.0...v1.53.0)

### Features

* **api:** api update ([#169](https://github.com/roarkhq/sdk-roark-analytics-python/issues/169)) ([1b4e109](https://github.com/roarkhq/sdk-roark-analytics-python/commit/1b4e1092cc44178523c20a79aef60e383592273f))

## 1.52.0 (2025-03-17)

Full Changelog: [v1.51.0...v1.52.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.51.0...v1.52.0)

### Features

* **api:** api update ([#166](https://github.com/roarkhq/sdk-roark-analytics-python/issues/166)) ([44d0c2e](https://github.com/roarkhq/sdk-roark-analytics-python/commit/44d0c2e78870824c2b6e67f4f8f574bf67d006ce))

## 1.51.0 (2025-03-16)

Full Changelog: [v1.50.0...v1.51.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.50.0...v1.51.0)

### Features

* **api:** api update ([#163](https://github.com/roarkhq/sdk-roark-analytics-python/issues/163)) ([7a4ac9c](https://github.com/roarkhq/sdk-roark-analytics-python/commit/7a4ac9c4fed6ee4df307e21cb0628a029728df31))

## 1.50.0 (2025-03-16)

Full Changelog: [v1.49.0...v1.50.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.49.0...v1.50.0)

### Features

* **api:** api update ([#160](https://github.com/roarkhq/sdk-roark-analytics-python/issues/160)) ([178676c](https://github.com/roarkhq/sdk-roark-analytics-python/commit/178676c5fc6fb6d495a6b9c8f9ad1659939ccc80))

## 1.49.0 (2025-03-16)

Full Changelog: [v1.48.0...v1.49.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.48.0...v1.49.0)

### Features

* **api:** api update ([#157](https://github.com/roarkhq/sdk-roark-analytics-python/issues/157)) ([7680b21](https://github.com/roarkhq/sdk-roark-analytics-python/commit/7680b21701fa4ebad3fcc1a53dd09ed36ffbe336))

## 1.48.0 (2025-03-16)

Full Changelog: [v1.47.0...v1.48.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.47.0...v1.48.0)

### Features

* **api:** api update ([#154](https://github.com/roarkhq/sdk-roark-analytics-python/issues/154)) ([005069b](https://github.com/roarkhq/sdk-roark-analytics-python/commit/005069b437f5989511abfee55ea3bb4266e87da0))

## 1.47.0 (2025-03-16)

Full Changelog: [v1.46.0...v1.47.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.46.0...v1.47.0)

### Features

* **api:** api update ([#151](https://github.com/roarkhq/sdk-roark-analytics-python/issues/151)) ([153b66d](https://github.com/roarkhq/sdk-roark-analytics-python/commit/153b66d9a0460d0231f39b369c6273b29dc8e360))

## 1.46.0 (2025-03-16)

Full Changelog: [v1.45.0...v1.46.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.45.0...v1.46.0)

### Features

* **api:** api update ([#148](https://github.com/roarkhq/sdk-roark-analytics-python/issues/148)) ([da9702e](https://github.com/roarkhq/sdk-roark-analytics-python/commit/da9702e34e886a6e58751b47eb741bf4b7b0f5cf))

## 1.45.0 (2025-03-16)

Full Changelog: [v1.44.0...v1.45.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.44.0...v1.45.0)

### Features

* **api:** api update ([#146](https://github.com/roarkhq/sdk-roark-analytics-python/issues/146)) ([4c4a1df](https://github.com/roarkhq/sdk-roark-analytics-python/commit/4c4a1df5dbfe929726f1481b4f53e73718d07fbd))


### Bug Fixes

* **types:** handle more discriminated union shapes ([#145](https://github.com/roarkhq/sdk-roark-analytics-python/issues/145)) ([4e4185b](https://github.com/roarkhq/sdk-roark-analytics-python/commit/4e4185b803316380ce48b6557e865759be0c00f8))


### Chores

* **internal:** bump rye to 0.44.0 ([#143](https://github.com/roarkhq/sdk-roark-analytics-python/issues/143)) ([01689df](https://github.com/roarkhq/sdk-roark-analytics-python/commit/01689dfc4ebf1df2c62415c102ad6d7a50504105))

## 1.44.0 (2025-03-15)

Full Changelog: [v1.43.0...v1.44.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.43.0...v1.44.0)

### Features

* **api:** api update ([#140](https://github.com/roarkhq/sdk-roark-analytics-python/issues/140)) ([08f86f8](https://github.com/roarkhq/sdk-roark-analytics-python/commit/08f86f8e855f879fb2150ef54e4b006cbb769f9a))

## 1.43.0 (2025-03-14)

Full Changelog: [v1.42.0...v1.43.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.42.0...v1.43.0)

### Features

* **api:** api update ([#137](https://github.com/roarkhq/sdk-roark-analytics-python/issues/137)) ([daf15e2](https://github.com/roarkhq/sdk-roark-analytics-python/commit/daf15e245bfc411a453c1a4e48413618ea9e2ca0))

## 1.42.0 (2025-03-14)

Full Changelog: [v1.41.0...v1.42.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.41.0...v1.42.0)

### Features

* **api:** api update ([#134](https://github.com/roarkhq/sdk-roark-analytics-python/issues/134)) ([095bcd1](https://github.com/roarkhq/sdk-roark-analytics-python/commit/095bcd1b9b046d334700cb5879a74fb73a355be4))

## 1.41.0 (2025-03-14)

Full Changelog: [v1.40.0...v1.41.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.40.0...v1.41.0)

### Features

* **api:** api update ([#132](https://github.com/roarkhq/sdk-roark-analytics-python/issues/132)) ([8617c93](https://github.com/roarkhq/sdk-roark-analytics-python/commit/8617c93d964ae5f1c3dd4659e17519842f46473e))


### Chores

* **internal:** remove extra empty newlines ([#130](https://github.com/roarkhq/sdk-roark-analytics-python/issues/130)) ([34f6ca5](https://github.com/roarkhq/sdk-roark-analytics-python/commit/34f6ca5723820d75e5a52366ea2744e330be3fc9))

## 1.40.0 (2025-03-13)

Full Changelog: [v1.39.0...v1.40.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.39.0...v1.40.0)

### Features

* **api:** api update ([#127](https://github.com/roarkhq/sdk-roark-analytics-python/issues/127)) ([dde74f0](https://github.com/roarkhq/sdk-roark-analytics-python/commit/dde74f0467dde79881c25b503d51f9172d0ac687))

## 1.39.0 (2025-03-12)

Full Changelog: [v1.38.0...v1.39.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.38.0...v1.39.0)

### Features

* **api:** api update ([#124](https://github.com/roarkhq/sdk-roark-analytics-python/issues/124)) ([917ee14](https://github.com/roarkhq/sdk-roark-analytics-python/commit/917ee144d1272595c59e43686c1a8a7051263932))

## 1.38.0 (2025-03-11)

Full Changelog: [v1.37.0...v1.38.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.37.0...v1.38.0)

### Features

* **api:** api update ([#122](https://github.com/roarkhq/sdk-roark-analytics-python/issues/122)) ([ef4a697](https://github.com/roarkhq/sdk-roark-analytics-python/commit/ef4a697d85239e8416fff0f97f1c8544a023c692))

## 1.37.0 (2025-03-11)

Full Changelog: [v1.36.0...v1.37.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.36.0...v1.37.0)

### Features

* **api:** api update ([#120](https://github.com/roarkhq/sdk-roark-analytics-python/issues/120)) ([bc21739](https://github.com/roarkhq/sdk-roark-analytics-python/commit/bc2173936a95c6b21726f965a9bcaddcc73b65f2))

## 1.36.0 (2025-03-10)

Full Changelog: [v1.35.0...v1.36.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.35.0...v1.36.0)

### Features

* **api:** api update ([#115](https://github.com/roarkhq/sdk-roark-analytics-python/issues/115)) ([e4858f5](https://github.com/roarkhq/sdk-roark-analytics-python/commit/e4858f531e2bad3b45356e02ff2fadc7e2dab7f2))

## 1.35.0 (2025-03-10)

Full Changelog: [v1.34.0...v1.35.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.34.0...v1.35.0)

### Features

* **api:** api update ([#112](https://github.com/roarkhq/sdk-roark-analytics-python/issues/112)) ([3ccb899](https://github.com/roarkhq/sdk-roark-analytics-python/commit/3ccb8994a158db74bacd774baededc34c7c75b43))

## 1.34.0 (2025-03-10)

Full Changelog: [v1.33.0...v1.34.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.33.0...v1.34.0)

### Features

* **api:** api update ([#109](https://github.com/roarkhq/sdk-roark-analytics-python/issues/109)) ([f4647cb](https://github.com/roarkhq/sdk-roark-analytics-python/commit/f4647cb8782993ed04805bb89a8845fa20548b92))

## 1.33.0 (2025-03-10)

Full Changelog: [v1.32.0...v1.33.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.32.0...v1.33.0)

### Features

* **api:** api update ([#106](https://github.com/roarkhq/sdk-roark-analytics-python/issues/106)) ([395ff64](https://github.com/roarkhq/sdk-roark-analytics-python/commit/395ff6448c0d314d029664ec8b5e8f9d1a999fa7))

## 1.32.0 (2025-03-09)

Full Changelog: [v1.31.0...v1.32.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.31.0...v1.32.0)

### Features

* **api:** api update ([#103](https://github.com/roarkhq/sdk-roark-analytics-python/issues/103)) ([f550819](https://github.com/roarkhq/sdk-roark-analytics-python/commit/f550819e1c1528813fa1e0eb19ec275b1dfdcc9d))

## 1.31.0 (2025-03-09)

Full Changelog: [v1.30.0...v1.31.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.30.0...v1.31.0)

### Features

* **api:** api update ([#100](https://github.com/roarkhq/sdk-roark-analytics-python/issues/100)) ([97b8cd0](https://github.com/roarkhq/sdk-roark-analytics-python/commit/97b8cd089023c402272830a91ccc35d170c43cf3))

## 1.30.0 (2025-03-09)

Full Changelog: [v1.29.0...v1.30.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.29.0...v1.30.0)

### Features

* **api:** api update ([#97](https://github.com/roarkhq/sdk-roark-analytics-python/issues/97)) ([125818a](https://github.com/roarkhq/sdk-roark-analytics-python/commit/125818af562cd5ae8dea611d817c683ca2b8de11))

## 1.29.0 (2025-03-09)

Full Changelog: [v1.28.0...v1.29.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.28.0...v1.29.0)

### Features

* **api:** api update ([#94](https://github.com/roarkhq/sdk-roark-analytics-python/issues/94)) ([f4c4248](https://github.com/roarkhq/sdk-roark-analytics-python/commit/f4c42480f3c0a94b84d3bd6220cc3ec5c7d39460))

## 1.28.0 (2025-03-09)

Full Changelog: [v1.27.0...v1.28.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.27.0...v1.28.0)

### Features

* **api:** api update ([#91](https://github.com/roarkhq/sdk-roark-analytics-python/issues/91)) ([ed54014](https://github.com/roarkhq/sdk-roark-analytics-python/commit/ed5401457440edba4d00330825416399a93d996a))

## 1.27.0 (2025-03-08)

Full Changelog: [v1.26.0...v1.27.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.26.0...v1.27.0)

### Features

* **api:** api update ([#88](https://github.com/roarkhq/sdk-roark-analytics-python/issues/88)) ([51018fb](https://github.com/roarkhq/sdk-roark-analytics-python/commit/51018fb2e21d414ff4c3546e15bfbd2ea188d012))

## 1.26.0 (2025-03-08)

Full Changelog: [v1.25.0...v1.26.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.25.0...v1.26.0)

### Features

* **api:** api update ([#85](https://github.com/roarkhq/sdk-roark-analytics-python/issues/85)) ([c2e4a4f](https://github.com/roarkhq/sdk-roark-analytics-python/commit/c2e4a4f8767b0fd7466abe7da1f8b26fbba86375))

## 1.25.0 (2025-03-07)

Full Changelog: [v1.24.0...v1.25.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.24.0...v1.25.0)

### Features

* **api:** api update ([#82](https://github.com/roarkhq/sdk-roark-analytics-python/issues/82)) ([0c3a405](https://github.com/roarkhq/sdk-roark-analytics-python/commit/0c3a4050fdff03a3e9ae91634196febaa799e594))

## 1.24.0 (2025-03-07)

Full Changelog: [v1.23.0...v1.24.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.23.0...v1.24.0)

### Features

* **api:** api update ([#79](https://github.com/roarkhq/sdk-roark-analytics-python/issues/79)) ([8e9f90c](https://github.com/roarkhq/sdk-roark-analytics-python/commit/8e9f90c697beee94d80a4d68ae42e119da2512bb))

## 1.23.0 (2025-03-07)

Full Changelog: [v1.22.0...v1.23.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.22.0...v1.23.0)

### Features

* **api:** api update ([#76](https://github.com/roarkhq/sdk-roark-analytics-python/issues/76)) ([3466233](https://github.com/roarkhq/sdk-roark-analytics-python/commit/346623375165a2bf8674acdec71ad68654174a1d))

## 1.22.0 (2025-03-07)

Full Changelog: [v1.21.0...v1.22.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.21.0...v1.22.0)

### Features

* **api:** api update ([#73](https://github.com/roarkhq/sdk-roark-analytics-python/issues/73)) ([558d185](https://github.com/roarkhq/sdk-roark-analytics-python/commit/558d18522098a1d4c10127deb5d466c4fc6d499c))

## 1.21.0 (2025-03-07)

Full Changelog: [v1.20.0...v1.21.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.20.0...v1.21.0)

### Features

* **api:** api update ([#70](https://github.com/roarkhq/sdk-roark-analytics-python/issues/70)) ([1371202](https://github.com/roarkhq/sdk-roark-analytics-python/commit/1371202b9bef6b06bc7f06721ba898d3937c7e71))

## 1.20.0 (2025-03-06)

Full Changelog: [v1.19.0...v1.20.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.19.0...v1.20.0)

### Features

* **api:** api update ([#67](https://github.com/roarkhq/sdk-roark-analytics-python/issues/67)) ([5bbfc48](https://github.com/roarkhq/sdk-roark-analytics-python/commit/5bbfc4814ffbf6c662ddece803b62a066c3c4c7a))

## 1.19.0 (2025-03-06)

Full Changelog: [v1.18.0...v1.19.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.18.0...v1.19.0)

### Features

* **api:** api update ([#64](https://github.com/roarkhq/sdk-roark-analytics-python/issues/64)) ([189b166](https://github.com/roarkhq/sdk-roark-analytics-python/commit/189b1668fd6fe7f368050b03e0ce7cab244ae77a))

## 1.18.0 (2025-03-06)

Full Changelog: [v1.17.0...v1.18.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.17.0...v1.18.0)

### Features

* **api:** api update ([#61](https://github.com/roarkhq/sdk-roark-analytics-python/issues/61)) ([ca09e8c](https://github.com/roarkhq/sdk-roark-analytics-python/commit/ca09e8cd5b92b0220c818df9060f9a3b58a1f3fe))

## 1.17.0 (2025-03-05)

Full Changelog: [v1.16.0...v1.17.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.16.0...v1.17.0)

### Features

* **api:** api update ([#58](https://github.com/roarkhq/sdk-roark-analytics-python/issues/58)) ([066a58e](https://github.com/roarkhq/sdk-roark-analytics-python/commit/066a58edb42fc8fb95c734c98f2b0bcbae5df534))

## 1.16.0 (2025-03-05)

Full Changelog: [v1.15.0...v1.16.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.15.0...v1.16.0)

### Features

* **api:** api update ([#55](https://github.com/roarkhq/sdk-roark-analytics-python/issues/55)) ([7ced7a0](https://github.com/roarkhq/sdk-roark-analytics-python/commit/7ced7a0e1a5ccc12ac02b92dfdb39d8da54670f4))

## 1.15.0 (2025-03-04)

Full Changelog: [v1.14.0...v1.15.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.14.0...v1.15.0)

### Features

* **api:** api update ([#53](https://github.com/roarkhq/sdk-roark-analytics-python/issues/53)) ([2c58660](https://github.com/roarkhq/sdk-roark-analytics-python/commit/2c586604a7de5f85976b2f893826d9ad94f68273))


### Chores

* **internal:** remove unused http client options forwarding ([#51](https://github.com/roarkhq/sdk-roark-analytics-python/issues/51)) ([1e7213d](https://github.com/roarkhq/sdk-roark-analytics-python/commit/1e7213ddfb3bc2c3b07d23f8fd8ef1d22b784bb9))

## 1.14.0 (2025-03-03)

Full Changelog: [v1.13.0...v1.14.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.13.0...v1.14.0)

### Features

* **api:** api update ([#48](https://github.com/roarkhq/sdk-roark-analytics-python/issues/48)) ([a74f998](https://github.com/roarkhq/sdk-roark-analytics-python/commit/a74f9985b2427404226d31a5910296c1a0f4b639))

## 1.13.0 (2025-03-03)

Full Changelog: [v1.12.0...v1.13.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.12.0...v1.13.0)

### Features

* **api:** api update ([#45](https://github.com/roarkhq/sdk-roark-analytics-python/issues/45)) ([4bf8b68](https://github.com/roarkhq/sdk-roark-analytics-python/commit/4bf8b68a21c3e7fea99a86b0a92e1d3f9de55391))

## 1.12.0 (2025-03-03)

Full Changelog: [v1.11.0...v1.12.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.11.0...v1.12.0)

### Features

* **api:** api update ([#42](https://github.com/roarkhq/sdk-roark-analytics-python/issues/42)) ([9b6bd6d](https://github.com/roarkhq/sdk-roark-analytics-python/commit/9b6bd6d9fe082a2da236b47821266c901ad04deb))

## 1.11.0 (2025-03-03)

Full Changelog: [v1.10.0...v1.11.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.10.0...v1.11.0)

### Features

* **api:** api update ([#40](https://github.com/roarkhq/sdk-roark-analytics-python/issues/40)) ([224643d](https://github.com/roarkhq/sdk-roark-analytics-python/commit/224643d317c338420a4dd9b1f5d62e890ae71882))

## 1.10.0 (2025-03-03)

Full Changelog: [v1.9.0...v1.10.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.9.0...v1.10.0)

### Features

* **api:** api update ([#37](https://github.com/roarkhq/sdk-roark-analytics-python/issues/37)) ([0dc33e1](https://github.com/roarkhq/sdk-roark-analytics-python/commit/0dc33e1dbe26e1e0db8eb2385633ca23c970b9d7))

## 1.9.0 (2025-03-03)

Full Changelog: [v1.8.0...v1.9.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.8.0...v1.9.0)

### Features

* **api:** api update ([#34](https://github.com/roarkhq/sdk-roark-analytics-python/issues/34)) ([b8c1aae](https://github.com/roarkhq/sdk-roark-analytics-python/commit/b8c1aae395fac95af739e3a142a20946ecabf20d))

## 1.8.0 (2025-03-02)

Full Changelog: [v1.7.0...v1.8.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.7.0...v1.8.0)

### Features

* **api:** api update ([#31](https://github.com/roarkhq/sdk-roark-analytics-python/issues/31)) ([f882512](https://github.com/roarkhq/sdk-roark-analytics-python/commit/f8825129f8faab6ff1ddf4e3936b7825b1bde8fa))

## 1.7.0 (2025-03-02)

Full Changelog: [v1.6.0...v1.7.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.6.0...v1.7.0)

### Features

* **api:** api update ([#28](https://github.com/roarkhq/sdk-roark-analytics-python/issues/28)) ([1b360c9](https://github.com/roarkhq/sdk-roark-analytics-python/commit/1b360c9324a549836a61c5dd3c72835eed455cd4))

## 1.6.0 (2025-03-02)

Full Changelog: [v1.5.0...v1.6.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.5.0...v1.6.0)

### Features

* **api:** api update ([#25](https://github.com/roarkhq/sdk-roark-analytics-python/issues/25)) ([587972c](https://github.com/roarkhq/sdk-roark-analytics-python/commit/587972cc0d14fd7a3fe2c4af69624cf08f26ac85))

## 1.5.0 (2025-03-02)

Full Changelog: [v1.4.0...v1.5.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.4.0...v1.5.0)

### Features

* **api:** api update ([#22](https://github.com/roarkhq/sdk-roark-analytics-python/issues/22)) ([82b4e82](https://github.com/roarkhq/sdk-roark-analytics-python/commit/82b4e82c8f7bdc42f8507f9657d6b5ec6fac8e0c))

## 1.4.0 (2025-03-02)

Full Changelog: [v1.3.0...v1.4.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.3.0...v1.4.0)

### Features

* **api:** api update ([#19](https://github.com/roarkhq/sdk-roark-analytics-python/issues/19)) ([d4f65b0](https://github.com/roarkhq/sdk-roark-analytics-python/commit/d4f65b0a1aac1b894905f5cd6081c853aa4df0cd))

## 1.3.0 (2025-03-02)

Full Changelog: [v1.2.0...v1.3.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.2.0...v1.3.0)

### Features

* **api:** api update ([#16](https://github.com/roarkhq/sdk-roark-analytics-python/issues/16)) ([2daf82a](https://github.com/roarkhq/sdk-roark-analytics-python/commit/2daf82abd3f3323c8dcfcc71653c9858637b6b45))

## 1.2.0 (2025-03-02)

Full Changelog: [v1.1.0...v1.2.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.1.0...v1.2.0)

### Features

* **api:** api update ([#13](https://github.com/roarkhq/sdk-roark-analytics-python/issues/13)) ([cd54ee6](https://github.com/roarkhq/sdk-roark-analytics-python/commit/cd54ee6eaaa998a59c9ecade8985ffab77295051))

## 1.1.0 (2025-03-02)

Full Changelog: [v1.0.0...v1.1.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v1.0.0...v1.1.0)

### Features

* **api:** api update ([#11](https://github.com/roarkhq/sdk-roark-analytics-python/issues/11)) ([498ac13](https://github.com/roarkhq/sdk-roark-analytics-python/commit/498ac13ef7586ae837c6b6bd8cfc23f56021d2a7))


### Chores

* remove custom code ([a91dd14](https://github.com/roarkhq/sdk-roark-analytics-python/commit/a91dd149213830c1171f6589d8bd60942e2173ca))

## 1.0.0 (2025-03-02)

Full Changelog: [v0.0.1-alpha.1...v1.0.0](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v0.0.1-alpha.1...v1.0.0)

### Chores

* update SDK settings ([#5](https://github.com/roarkhq/sdk-roark-analytics-python/issues/5)) ([2154668](https://github.com/roarkhq/sdk-roark-analytics-python/commit/21546680317c33d97db9a01080735c5c36f2de72))

## 0.0.1-alpha.1 (2025-03-02)

Full Changelog: [v0.0.1-alpha.0...v0.0.1-alpha.1](https://github.com/roarkhq/sdk-roark-analytics-python/compare/v0.0.1-alpha.0...v0.0.1-alpha.1)

### Chores

* configure new SDK language ([3a0391f](https://github.com/roarkhq/sdk-roark-analytics-python/commit/3a0391fe3b558f430b96db64972d1e76d4a7fdee))
* go live ([#1](https://github.com/roarkhq/sdk-roark-analytics-python/issues/1)) ([99e8d20](https://github.com/roarkhq/sdk-roark-analytics-python/commit/99e8d20112aac88bec32befa86cf4853d5f54557))
