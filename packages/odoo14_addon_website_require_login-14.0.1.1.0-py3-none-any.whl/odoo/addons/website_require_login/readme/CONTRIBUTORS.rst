* Ooops404 <https://ooops404.com>
* `PyTech <https://www.pytech.it>`_:

  * Simone Rubino <simone.rubino@pytech.it>
