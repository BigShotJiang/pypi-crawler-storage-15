This module allows to restrict access to specific website pages to logged users.
