"""Package containing core functionality for browse image generation."""

from .browse import create_browse

__all__ = ['create_browse']
