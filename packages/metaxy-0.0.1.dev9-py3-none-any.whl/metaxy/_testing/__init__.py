"""Testing infrastructure for Metaxy examples and runbooks.

This is a private module (_testing) containing testing utilities organized into:
- runbook: Runbook system for testing and documenting examples
- metaxy_project: Project helpers for creating and managing temporary Metaxy projects
- pytest_helpers: Testing helpers for pytest tests
- models: Testing-specific model implementations
"""

# Runbook system
# Metaxy project helpers
from metaxy._testing.metaxy_project import (
    ExternalMetaxyProject,
    HashAlgorithmCases,
    MetaxyProject,
    TempFeatureModule,
    TempMetaxyProject,
    assert_all_results_equal,
)
from metaxy._testing.models import SampleFeature, SampleFeatureSpec
from metaxy._testing.pytest_helpers import add_metaxy_provenance_column
from metaxy._testing.runbook import (
    ApplyPatchStep,
    AssertOutputStep,
    BaseStep,
    Runbook,
    RunbookRunner,
    RunCommandStep,
    Scenario,
    StepType,
)

__all__ = [
    # Runbook system
    "Runbook",
    "Scenario",
    "BaseStep",
    "RunCommandStep",
    "ApplyPatchStep",
    "AssertOutputStep",
    "StepType",
    "RunbookRunner",
    # Metaxy project helpers
    "TempFeatureModule",
    "HashAlgorithmCases",
    "MetaxyProject",
    "ExternalMetaxyProject",
    "TempMetaxyProject",
    "assert_all_results_equal",
    # Pytest helpers
    "add_metaxy_provenance_column",
    # Testing models
    "SampleFeatureSpec",
    "SampleFeature",
]
