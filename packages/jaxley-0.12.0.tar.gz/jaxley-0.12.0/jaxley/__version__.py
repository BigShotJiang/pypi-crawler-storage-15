# This file is part of Jaxley, a differentiable neuroscience simulator. Jaxley is
# licensed under the Apache License Version 2.0, see <https://www.apache.org/licenses/>

VERSION = (0, 12, 0)

__version__ = ".".join(map(str, VERSION))
