"""
Utilities for truncating text and data structures while preserving readability.

These utilities are used across MCP servers to prevent large responses from
saturating LLM context while still providing useful previews.
"""

import json
from typing import Any

import pandas as pd


def truncate_text_head_tail(text: str, head_chars: int, tail_chars: int) -> tuple[str, int]:
    """Truncate text keeping head and tail portions.

    Args:
        text: Text to truncate
        head_chars: Number of characters to keep from start
        tail_chars: Number of characters to keep from end

    Returns:
        Tuple of (truncated_text, chars_removed)

    Example:
        >>> truncate_text_head_tail("Hello World!", 5, 3)
        ('Hello\n... +1 chars ...\nrld!', 1)
    """
    if len(text) <= head_chars + tail_chars:
        return text, 0

    head = text[:head_chars]
    tail = text[-tail_chars:] if tail_chars > 0 else ""

    chars_removed = len(text) - head_chars - len(tail)

    if tail:
        truncated = f"{head}\n... +{chars_removed} chars ...\n{tail}"
    else:
        truncated = f"{head}\n... +{chars_removed} chars ..."

    return truncated, chars_removed


def truncate_text_middle(text: str, max_chars: int) -> tuple[str, int]:
    """Truncate text in the middle, keeping start and end.

    Args:
        text: Text to truncate
        max_chars: Maximum total characters (including ellipsis)

    Returns:
        Tuple of (truncated_text, chars_removed)

    Example:
        >>> truncate_text_middle("Hello World!", 10)
        ('Hel...rld!', 2)
    """
    if len(text) <= max_chars:
        return text, 0

    # Reserve 3 chars for "..."
    available = max_chars - 3
    half = available // 2

    truncated = text[:half] + "..." + text[-half:]
    chars_removed = len(text) - max_chars

    return truncated, chars_removed


def truncate_dataframe_preview(df: pd.DataFrame, max_rows: int = 10, max_cols: int = 5) -> pd.DataFrame:
    """Create a preview DataFrame with head + tail rows and left + right columns.

    Args:
        df: DataFrame to preview
        max_rows: Maximum number of rows to show (split between head/tail)
        max_cols: Maximum number of columns to show (split between left/right)

    Returns:
        Preview DataFrame with "..." indicators for omitted data

    Example:
        For a 100x20 DataFrame with max_rows=10, max_cols=5:
        - Shows rows: 0-4, "...", 95-99
        - Shows cols: 0-2, "...", 17-19
    """
    total_rows, total_cols = df.shape

    # Handle rows
    if total_rows <= max_rows:
        preview_df = df
    else:
        top = max_rows // 2
        bottom = max_rows - top
        preview_df = pd.concat(
            [
                df.head(top),
                pd.DataFrame([["..."] * total_cols], columns=df.columns),
                df.tail(bottom),
            ],
            ignore_index=True,
        )

    # Handle columns
    if total_cols <= max_cols:
        return preview_df

    left = max_cols // 2
    right = max_cols - left
    result_df = preview_df[[*df.columns[:left], *df.columns[-right:]]]
    result_df.insert(left, "...", ["..."] * result_df.shape[0])

    return result_df


def format_truncation_message(
    original_size: int,
    truncated_size: int,
    unit: str = "chars",
    file_path: str | None = None,
    recommendation: str | None = None,
) -> str:
    """Generate a standard truncation warning message.

    Args:
        original_size: Original size before truncation
        truncated_size: Size after truncation
        unit: Unit of measurement ("chars", "tokens", "rows")
        file_path: Optional path where full content was saved
        recommendation: Optional recommendation for user

    Returns:
        Formatted truncation message

    Example:
        >>> format_truncation_message(10000, 2000, "chars", "/workspace/data.csv")
        'Content truncated from 10000 to 2000 chars.\\nFull content saved to /workspace/data.csv'
    """
    parts = [f"Content truncated from {original_size:,} to {truncated_size:,} {unit}."]

    if file_path:
        parts.append(f"Full content saved to {file_path}")

    if recommendation:
        parts.append(f"Recommendation: {recommendation}")

    return "\n".join(parts)


def smart_truncate_json(  # pylint: disable=too-many-arguments,too-many-positional-arguments,too-many-locals,too-many-return-statements,too-many-branches,too-many-statements
    obj: dict | list | str | pd.DataFrame | int | float | bool | None,
    max_string_len: int | None = None,
    max_list_len: int | None = None,
    max_dict_keys: int | None = None,
    max_df_rows: int | None = None,
    max_df_cols: int | None = None,
    target_size: int | None = None,
    ensure_size: bool = False,
    return_metadata: bool = False,
) -> Any | tuple[Any, dict[str, Any]]:
    """Recursively truncate a JSON-serializable object while preserving structure.

    This function intelligently truncates nested data structures by:
    - Truncating long strings in the middle
    - Showing head + tail items for long lists
    - Showing head + tail keys for large dicts
    - Creating previews for large DataFrames

    Args:
        obj: Object to truncate (dict, list, str, DataFrame, or primitive).
             Caller must convert custom objects to dict before calling.
        max_string_len: Maximum length for string values (default 60, or calculated from target_size)
        max_list_len: Maximum number of list items to show (default 20, or calculated from target_size)
        max_dict_keys: Maximum number of dict keys to show (default 20, or calculated from target_size)
        max_df_rows: Maximum DataFrame rows to show (default 10, or calculated from target_size)
        max_df_cols: Maximum DataFrame columns to show (default 5, or calculated from target_size)
        target_size: If provided, auto-calculate parameters based on target output size in chars
        ensure_size: If True, validate JSON-serialized result fits within target_size and apply
                    fallback truncation if needed. Requires target_size to be set.
        return_metadata: If True, return (result, metadata) tuple with truncation details

    Returns:
        Truncated version of the object with same structure, or (result, metadata) tuple
        if return_metadata=True.

        Metadata dict contains:
        - original_size: Size before truncation
        - truncated_size: Size after truncation
        - was_truncated: Whether truncation was applied
        - strategy: Which strategy was used ("none", "smart", "middle")

    Examples:
        >>> # Explicit parameters
        >>> data = {"items": [f"item_{i}" for i in range(100)], "description": "A" * 1000}
        >>> truncated = smart_truncate_json(data, max_string_len=60, max_list_len=10)

        >>> # Auto-calculated from target size
        >>> truncated = smart_truncate_json(data, target_size=1000)

        >>> # With size validation and metadata
        >>> result, meta = smart_truncate_json(data, target_size=1000, ensure_size=True, return_metadata=True)
        >>> if meta['was_truncated']:
        ...     print(f"Truncated from {meta['original_size']} to {meta['truncated_size']}")
    """
    # Validate ensure_size requirements
    if ensure_size and target_size is None:
        raise ValueError("ensure_size=True requires target_size to be set")

    # Initialize metadata if needed (dict avoids pylint false positives about None)
    metadata: dict[str, Any] = {
        "original_size": 0,
        "truncated_size": 0,
        "was_truncated": False,
        "strategy": "none",
    }

    # Track if we encounter non-serializable objects
    had_non_serializable = False

    # Capture original size if we need to track truncation
    if ensure_size or return_metadata:
        try:
            original_serialized = json.dumps(obj, ensure_ascii=False)
            metadata["original_size"] = len(original_serialized)
        except (TypeError, ValueError):
            # Can't serialize - mark as having non-serializable content
            # This will be treated as truncated since we'll convert to string
            had_non_serializable = True

    # Handle strings first (before parameter calculation)
    if isinstance(obj, str):
        if max_string_len is None:
            max_string_len = max(20, target_size // 20) if target_size else 60
        truncated, _ = truncate_text_middle(obj, max_string_len)

        if return_metadata:
            metadata["original_size"] = len(obj)
            metadata["truncated_size"] = len(truncated)
            metadata["was_truncated"] = len(obj) > max_string_len
            metadata["strategy"] = "smart" if metadata["was_truncated"] else "none"
            return truncated, metadata
        return truncated

    # Calculate parameters from target_size if provided
    if target_size is not None:
        if max_string_len is None:
            max_string_len = max(20, target_size // 20)
        if max_list_len is None:
            max_list_len = max(5, target_size // 100)
        if max_dict_keys is None:
            max_dict_keys = max(5, target_size // 50)
        if max_df_rows is None:
            max_df_rows = max(3, target_size // 200)
        if max_df_cols is None:
            max_df_cols = max(3, target_size // 150)
    # Apply defaults if still None
    if max_string_len is None:
        max_string_len = 60
    if max_list_len is None:
        max_list_len = 20
    if max_dict_keys is None:
        max_dict_keys = 20
    if max_df_rows is None:
        max_df_rows = 10
    if max_df_cols is None:
        max_df_cols = 5

    # Handle pandas DataFrames
    if isinstance(obj, pd.DataFrame):
        result = truncate_dataframe_preview(obj, max_df_rows, max_df_cols).to_dict(orient="split")

    # Handle lists
    elif isinstance(obj, list):
        if len(obj) > max_list_len:
            head = obj[: max_list_len // 2]
            tail = obj[-max_list_len // 2 :]
            result = [
                *[
                    smart_truncate_json(
                        x,
                        max_string_len,
                        max_list_len,
                        max_dict_keys,
                        max_df_rows,
                        max_df_cols,
                    )
                    for x in head
                ],
                "...",
                *[
                    smart_truncate_json(
                        x,
                        max_string_len,
                        max_list_len,
                        max_dict_keys,
                        max_df_rows,
                        max_df_cols,
                    )
                    for x in tail
                ],
            ]
        else:
            result = [
                smart_truncate_json(
                    item,
                    max_string_len,
                    max_list_len,
                    max_dict_keys,
                    max_df_rows,
                    max_df_cols,
                )
                for item in obj
            ]

    # Handle dicts
    elif isinstance(obj, dict):
        keys = list(obj.keys())
        if len(keys) > max_dict_keys:
            head = keys[: max_dict_keys // 2]
            tail = keys[-max_dict_keys // 2 :]
            result = {
                k: smart_truncate_json(
                    obj[k],
                    max_string_len,
                    max_list_len,
                    max_dict_keys,
                    max_df_rows,
                    max_df_cols,
                )
                for k in head
            }
            result["..."] = "..."
            for k in tail:
                result[k] = smart_truncate_json(
                    obj[k],
                    max_string_len,
                    max_list_len,
                    max_dict_keys,
                    max_df_rows,
                    max_df_cols,
                )
        else:
            result = {
                k: smart_truncate_json(v, max_string_len, max_list_len, max_dict_keys, max_df_rows, max_df_cols)
                for k, v in obj.items()
            }

    # Handle primitives
    elif isinstance(obj, (int, float, bool, type(None))):
        result = obj
    else:
        # Unknown type - convert to string representation
        result = str(obj)
        # Truncate if needed
        if max_string_len and len(result) > max_string_len:
            result, _ = truncate_text_middle(result, max_string_len)

    # If not ensure_size, return result (possibly with metadata)
    if not ensure_size:
        if return_metadata:
            try:
                serialized = json.dumps(result, ensure_ascii=False)
                metadata["original_size"] = len(serialized)
                metadata["truncated_size"] = len(serialized)
            except (TypeError, ValueError):
                str_result = str(result)
                metadata["original_size"] = len(str_result)
                metadata["truncated_size"] = len(str_result)
            return result, metadata
        return result

    # ensure_size=True: validate JSON size and apply fallback if needed
    # Try to serialize the truncated result
    try:
        serialized = json.dumps(result, ensure_ascii=False)
        # Update original_size if not captured earlier
        if metadata["original_size"] == 0:
            metadata["original_size"] = len(serialized)

        if len(serialized) <= target_size:
            metadata["truncated_size"] = len(serialized)
            metadata["strategy"] = "smart"
            # Check if truncation actually occurred
            if metadata["original_size"] > target_size or had_non_serializable:
                metadata["was_truncated"] = True
            if return_metadata:
                return result, metadata
            return result

        # Result still too large - try with indent=2
        serialized_pretty = json.dumps(result, indent=2, ensure_ascii=False)
        if len(serialized_pretty) <= target_size:
            metadata["truncated_size"] = len(serialized_pretty)
            metadata["was_truncated"] = True
            metadata["strategy"] = "smart"
            if return_metadata:
                return serialized_pretty, metadata
            return serialized_pretty

        # Still too large - use middle truncation as fallback
        truncated, _ = truncate_text_middle(serialized, target_size - 100)
        metadata["truncated_size"] = len(truncated)
        metadata["was_truncated"] = True
        metadata["strategy"] = "middle"
        if return_metadata:
            return truncated, metadata
        return truncated

    except (TypeError, ValueError):
        # JSON serialization failed - fallback to string truncation
        str_result = str(result)
        metadata["original_size"] = len(str_result)

        if len(str_result) <= target_size:
            metadata["truncated_size"] = len(str_result)
            metadata["strategy"] = "str"
            if return_metadata:
                return str_result, metadata
            return str_result

        truncated, _ = truncate_text_middle(str_result, target_size - 50)
        metadata["truncated_size"] = len(truncated)
        metadata["was_truncated"] = True
        metadata["strategy"] = "middle"
        if return_metadata:
            return truncated, metadata
        return truncated
