from chainbench.main import cli

cli()
