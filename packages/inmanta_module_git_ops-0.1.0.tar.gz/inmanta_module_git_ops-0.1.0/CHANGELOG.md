# Changelog

## v0.1.0 - 2025-12-03

- Initial functional release

## v0.0.1 - 2025-10-04

- First empty release