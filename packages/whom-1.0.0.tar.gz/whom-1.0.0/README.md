# whom

A mysterious Python library for those who seek.

## Installation

```bash
pip install whom
```

## Usage

```python
import whom

# Print the mystery
whom.whom()

# Get the mystery as a string
rhyme = whom.who()

# For the curious...
secret = whom.reveal()
```

## What is this?

Some say it's just a simple rhyme,
a bit of code to pass the time.
But look a little closer, friend,
there's more than meets the eye in the end.

## License

MIT
