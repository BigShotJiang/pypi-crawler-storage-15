"""
Blessed Gong connector for Airbyte SDK.

Auto-generated from OpenAPI specification.
"""

from .connector import GongConnector

__all__ = ["GongConnector"]
