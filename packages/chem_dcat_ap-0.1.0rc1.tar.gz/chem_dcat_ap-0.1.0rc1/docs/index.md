# ChemDCAT-AP

This is an extension of the DCAT Application Profile in LinkML. It is intended to be used by NFDI4Chem & NFDI4Cat as a core that can further be extended in profiles to provide domain specific metadata for a dataset.

URI: https://w3id.org/nfdi-de/dcat-ap-plus/chemistry/

- Auto-generated [schema documentation](elements/overview.md)
- License: MIT
