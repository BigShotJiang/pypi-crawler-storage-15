# Schema Directory

This folder contains the LinkML schema yaml files.
