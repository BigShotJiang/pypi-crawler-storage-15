#!/usr/bin/env python
"""
Setup script for drf-api-doc-generator

This file is kept for backwards compatibility with older pip versions.
The main configuration is in pyproject.toml
"""

from setuptools import setup

if __name__ == "__main__":
    setup()
