from .MoodleError import MoodleError


class MoodleLoginError(MoodleError):
    pass
