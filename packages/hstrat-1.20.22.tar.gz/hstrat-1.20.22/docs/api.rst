=============
API Reference
=============

.. autosummary::
   :toctree: _autosummary
   :recursive:

   hstrat
