from ._GenDropRanks_ import GenDropRanks

GenDropRanks = GenDropRanks
