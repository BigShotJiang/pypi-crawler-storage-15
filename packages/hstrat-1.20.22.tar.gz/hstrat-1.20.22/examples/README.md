# Usage

To run an example,

```bash
python3 examples/example.py
```

# Requirements

To install requirements,
```bash
python3 -m pip install -r requirements-dev/requirements-jit.txt
python3 -m pip install -r requirements-dev/requirements-testing.txt
```
