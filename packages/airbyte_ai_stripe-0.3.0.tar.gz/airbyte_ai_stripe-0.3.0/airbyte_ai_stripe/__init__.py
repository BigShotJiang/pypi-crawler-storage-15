"""
Blessed Stripe connector for Airbyte SDK.

Auto-generated from OpenAPI specification.
"""

from .connector import StripeConnector

__all__ = ["StripeConnector"]
