class ObservabilityError(Exception):
    """Base error for observability wrapper failures."""
    pass
