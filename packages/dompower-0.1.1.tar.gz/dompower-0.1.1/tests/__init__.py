"""Tests for dompower."""
