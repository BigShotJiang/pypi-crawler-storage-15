PORTUGUÊS | [ENGLISH](https://github.com/fazedordecodigo/PyFlunt/blob/main/docs/SECURITY_EN.md)

# Política de Segurança

## Versões Suportadas

| Version | Supported          |
| ------- | ------------------ |
| 2.2.0   | :white_check_mark: |
| 2.1.1   | :white_check_mark: |
| 2.1.0   | :white_check_mark: |
| 2.0.0   | :white_check_mark: |
| 1.0.0   | :x:                |
| 0.2.0   | :x:                |
| 0.1.1   | :x:                |

## Reportando uma Vulnerabilidade
Para reportar uma vulnerabilidade, envie um e-mail para `contato@delatorre.dev` com todos os detalhes necessários no relatório de vulnerabilidade.

Depois de enviar seu e-mail, a equipe responsável pela segurança do projeto será notificada e poderá começar a avaliar e tratar a vulnerabilidade relatada.
