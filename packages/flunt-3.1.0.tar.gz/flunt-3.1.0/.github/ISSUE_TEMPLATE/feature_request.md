---
name: "Nova Funcionalidade"
about: Sugestão de uma nova funcionalidade
title: ''
labels: feature
assignees: ''

---

**Seu pedido de recurso está relacionado a um problema? Por favor, descreva.**
Uma descrição clara e concisa do que é o problema. Por exemplo: "Fico sempre frustrado quando [...]"

**Descreva a solução que você gostaria**
Uma descrição clara e concisa do que você deseja que aconteça.

**Descreva alternativas que você considerou**
Uma descrição clara e concisa de quaisquer soluções ou recursos alternativos que você tenha considerado.

**Contexto adicional**
Adicione qualquer outro contexto ou capturas de tela sobre o pedido de recurso aqui.
