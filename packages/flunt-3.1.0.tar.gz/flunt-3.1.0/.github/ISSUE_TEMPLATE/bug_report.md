---
name: "Reportar um bug"
about: Reporte um bug, nos ajude a melhorar!
title: ''
labels: bug
assignees: ''

---

**Descrição do problema**
Uma descrição clara e concisa do que é o erro.

**Para Reproduzir**
Passos para reproduzir o comportamento:
1. Chamar o utilitário '...'
2. Passando o parâmetro '....'
3. Ver o erro

**Comportamento esperado**
Uma descrição clara e concisa do que você esperava que acontecesse.

**Desktop (por favor, forneça as seguintes informações):**
 - Sistema Operacional: [por exemplo, Linux]
 - Versão do PyFlunt: [por exemplo, 2.0.0]

**Contexto adicional**
Adicione qualquer outro contexto sobre o problema aqui.
