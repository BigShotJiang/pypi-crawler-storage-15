"""Paquete fuente para {{ package_name }}."""
