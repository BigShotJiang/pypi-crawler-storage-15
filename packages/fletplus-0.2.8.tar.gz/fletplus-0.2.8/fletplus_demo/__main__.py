"""Punto de entrada ejecutable para ``python -m fletplus_demo``."""

from .app import run


if __name__ == "__main__":
    run()
