from . import label_maps

def main():
    print("PETPAL - Meta")


if __name__ == "__main__":
    main()
