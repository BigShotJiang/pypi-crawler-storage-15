# -*- encoding: utf-8 -*-

__version_info__ = (0, 2, 3)
__version__ = '.'.join(map(str, __version_info__))
