---
title: "Hello World"
date: 2025-11-30
---

# Welcome to Your Blog

This is your first post! Replace this with your own content.

## Getting Started

1. Add more posts to `content/posts/`
2. Create new sections by adding directories to `content/`
3. Add templates for new sections in `templates/`
4. Run `akari build` to regenerate your site

## Markdown Support

Your posts can include:

- **Bold text** and *italics*
- [Links](https://example.com)
- Lists and code blocks
- Images

Happy blogging!
