import argparse
import pandas as pd
from kpi_impact_sim.preprocessing import preprocess_dataframe
from kpi_impact_sim.ridge_model import fit_ridge_model
from kpi_impact_sim.simulate import apply_simulation
from kpi_impact_sim.explain import generate_explanation
from kpi_impact_sim.utils import tipo_variable
import os

def run_cli():
    parser = argparse.ArgumentParser(
        description="CLI para entrenar un modelo Ridge, simular impacto y generar explicación."
    )

    parser.add_argument("--data", required=True, help="Ruta al CSV de entrada.")
    parser.add_argument("--target", required=True, help="Nombre del KPI objetivo.")
    parser.add_argument("--increment", type=float, required=True,
                        help="Incremento deseado en puntos o porcentaje.")
    parser.add_argument("--output", required=False, default="simulacion_resultado.csv",
                        help="Ruta para guardar la simulación.")
    parser.add_argument("--explain", action="store_true",
                        help="Genera un informe HTML explicando el modelo.")

    args = parser.parse_args()

    print("🔹 Cargando dataset...")
    df = pd.read_csv(args.data)

    print("🔹 Preprocesando...")
    df_proc = preprocess_dataframe(df)
    df_num = df_proc.select_dtypes(include="number")

    if args.target not in df_num.columns:
        raise ValueError(f"El target '{args.target}' no existe en el dataset.")

    if df_num.shape[0] < 30:
        raise ValueError("El dataset debe tener al menos 30 filas para entrenar un modelo confiable.")

    X = df_num.drop(columns=[args.target])
    y = df_num[target]

    print("🔹 Entrenando modelo Ridge...")
    model_res = fit_ridge_model(X, y)

    print("🔹 Ejecutando simulación...")
    sim = apply_simulation(
        model_res["coefs"],
        df_num,
        args.target,
        incremento_pts=args.increment,
        tipo_variable_func=tipo_variable,
        save_path=args.output
    )

    print(f"✔ Simulación completada. Archivo guardado: {args.output}")
    print(sim["candidates"].head(10))

    if args.explain:
        print("🔹 Generando reporte explicativo...")
        explain_path = generate_explanation(
            model_res["coefs"],
            X,
            y,
            output_html="explain_model.html"
        )
        print(f"✔ Reporte generado en explain_model.html")

