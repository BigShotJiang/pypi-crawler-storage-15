"""
Utilities: tipo_variable, round_by_type, logging small helpers
"""
import numpy as np
import pandas as pd

def tipo_variable(nombre):
    n = str(nombre).lower()
    if any(p in n for p in ["%", "porcentaje", "tasa", "nivel", "efectivo/contacto","retenido/contacto"]):
        return "porcentaje"
    if any(p in n for p in ["tmo","segundo","segundos"]):
        return "tiempo"
    if any(p in n for p in ["fte","ratio","suma","total","cantidad","contactos","gestiones","volumen"]):
        return "entero"
    return "entero"

def round_by_type(kpi_name, value):
    tp = tipo_variable(kpi_name)
    if pd.isna(value):
        return value
    if tp == "entero":
        return int(round(value))
    if tp in ("porcentaje","tiempo"):
        return float(round(value,2))
    return value

def validar_dataset(df, target):
    if df.shape[0] < 30:
        raise ValueError("El dataset debe tener al menos 30 filas.")

    if target not in df.columns:
        raise ValueError(f"El target '{target}' no existe en el dataset.")

    if df[target].nunique() < 5:
        raise ValueError("El target no tiene variabilidad suficiente.")

    vars_cero = [c for c in df.columns if df[c].std() == 0]
    for v in vars_cero:
        print(f"⚠ Variable sin varianza removida: {v}")
