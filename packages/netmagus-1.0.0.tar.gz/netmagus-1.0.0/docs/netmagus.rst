netmagus package
================

Submodules
----------

netmagus.form module
--------------------

.. automodule:: netmagus.form
   :members:
   :undoc-members:
   :show-inheritance:

netmagus.netop module
---------------------

.. automodule:: netmagus.netop
   :members:
   :undoc-members:
   :show-inheritance:

netmagus.rpc module
-------------------

.. automodule:: netmagus.rpc
   :members:
   :undoc-members:
   :show-inheritance:

netmagus.screen module
----------------------

.. automodule:: netmagus.screen
   :members:
   :undoc-members:
   :show-inheritance:

netmagus.session module
-----------------------

.. automodule:: netmagus.session
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: netmagus
   :members:
   :undoc-members:
   :show-inheritance:
