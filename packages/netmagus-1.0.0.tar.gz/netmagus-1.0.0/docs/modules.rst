netmagus
========

.. toctree::
   :maxdepth: 4

   netmagus
