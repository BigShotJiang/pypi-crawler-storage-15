.. highlight:: shell

Installation
============

From Python Package Index
-------------------------

The NetMagus Python Library can be downloaded from `PyPi`_.

Or you can simply install via pip:

.. code-block:: console

    $ pip install netmagus

.. _PyPi: https://pypi.org/project/netmagus/
