NetMāgus Python Package
=======================

This Python package is to be used with the `NetMāgus <http://www.intelligentvisibility.com/netmagus>`_ product from `Intelligent Visbility, Inc <http://www.intelligentvisibility.com>`_.

It is used to create and exchange UI forms and Formula steps with the NetMāgus application.

The code has been tested and should work for Python 3.10 and 3.11.

Refer to the `NetMāgus <http://www.intelligentvisibility.com/netmagus>`_ documentation for usage details.

To install: ``pip install netmagus``
