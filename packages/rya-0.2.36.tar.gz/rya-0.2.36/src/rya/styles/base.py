from rich.console import Console

stdout_console = Console(color_system="auto")
stderr_console = Console(color_system="auto", stderr=True)
