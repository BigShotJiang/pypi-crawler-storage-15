# Rya

Rya is a Python bootstrapper. Rya is made out of the internals of [elAPI](https://github.com/uhd-urz/elAPI). Rya has been generalized enough so any Python application can be bootstrapped that shares the same capabilities as elAPI.

> [!NOTE]  
> Rya is currently in beta.
