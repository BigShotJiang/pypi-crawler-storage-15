"""Age-stratified validators for Layer 15."""

from .age_stratified_nli import AgeStratifiedValidator

__all__ = ["AgeStratifiedValidator"]

