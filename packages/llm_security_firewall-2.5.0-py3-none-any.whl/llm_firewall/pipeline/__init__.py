"""Integration pipeline for multi-gate defense."""
