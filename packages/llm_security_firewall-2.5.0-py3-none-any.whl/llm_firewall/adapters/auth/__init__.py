"""Authentication adapters."""
