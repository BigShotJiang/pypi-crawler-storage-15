"""Adapters - infrastructure implementations."""
