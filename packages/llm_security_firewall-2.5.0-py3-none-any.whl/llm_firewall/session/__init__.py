"""Session-level tracking and state management."""
