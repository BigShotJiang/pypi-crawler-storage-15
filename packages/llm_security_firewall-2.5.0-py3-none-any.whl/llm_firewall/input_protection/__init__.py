"""
Input Protection Module - Pre-filtering and topic validation

NVIDIA NeMo-inspired features for efficient input validation.
"""

__version__ = "0.1.0"

