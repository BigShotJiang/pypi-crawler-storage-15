"""GuardNet - Multi-task neural guard with conformal coverage."""
