"""Risk aggregation modules."""
