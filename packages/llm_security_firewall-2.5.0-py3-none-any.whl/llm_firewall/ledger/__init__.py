"""Decision ledger for audit trail and KUE-proof."""
