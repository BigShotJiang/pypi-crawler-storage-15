"""Normalizer modules for encoding chains and grammar."""
