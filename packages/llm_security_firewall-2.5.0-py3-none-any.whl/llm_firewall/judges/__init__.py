"""Judge modules for multi-agent defense."""
