# Text processing utilities

