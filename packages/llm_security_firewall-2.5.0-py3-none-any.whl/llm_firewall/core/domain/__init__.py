"""Domain entities - pure business logic."""
