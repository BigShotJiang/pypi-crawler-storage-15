import argparse
import pandas as pd

from kpi_impact_sim.preprocessing import preprocess_dataframe
from kpi_impact_sim.ridge_model import fit_ridge_model
from kpi_impact_sim.simulate import apply_simulation
from kpi_impact_sim.utils import tipo_variable
from kpi_impact_sim.validator import validate_dataset
from kpi_impact_sim.feature_audit import generate_feature_report

def run_cli():
    parser = argparse.ArgumentParser(description="Motor de simulación KPI Impact Sim")
    parser.add_argument("--data", required=True)
    parser.add_argument("--target", required=True)
    parser.add_argument("--increment", type=float, required=True)
    parser.add_argument("--output", default="sim_result.csv")

    args = parser.parse_args()

    print("🔹 Cargando dataset…")
    df = pd.read_csv(args.data)

    print("🔹 Preprocesando…")
    df_proc = preprocess_dataframe(df)
    df_num = df_proc.select_dtypes(include="number")

    print("🔍 Validando dataset…")
    validate_dataset(df_num, args.target)

    print("📊 Generando auditoría de features…")
    generate_feature_report(df_num)

    print("🤖 Entrenando modelo…")
    model_res = fit_ridge_model(df_num.drop(columns=[args.target]), df_num[args.target])

    print("🎯 Simulando impacto…")
    sim = apply_simulation(
        coef_series=model_res["coefs"],
        df_mes=df_num,
        target=args.target,
        incremento_pts=args.increment,
        tipo_variable_func=tipo_variable,
        save_path=args.output
    )

    print("✔ FINALIZADO. Resultados en:", args.output)
    print(sim["candidates"].head(10))
