"""Functionality for displaying dataset and variables metadata fields."""
