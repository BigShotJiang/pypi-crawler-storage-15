# Copyright (c) QuantCo 2025-2025
# SPDX-License-Identifier: BSD-3-Clause
