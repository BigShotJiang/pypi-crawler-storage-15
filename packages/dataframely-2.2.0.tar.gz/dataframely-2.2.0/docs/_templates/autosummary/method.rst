:html_theme.sidebar_secondary.remove: true

.. role:: hidden

{{ (class + "." + name) | underline }}

.. currentmodule:: {{ module }}

.. automethod:: {{ class }}.{{ name }}
