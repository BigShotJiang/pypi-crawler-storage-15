=============
Miscellaneous
=============

.. currentmodule:: dataframely
.. autosummary::
    :toctree: _gen/
    :nosignatures:

    Config
    random.Generator
    testing.create_schema
    testing.create_collection
