==========
Validation
==========

.. currentmodule:: dataframely
.. autosummary::
    :toctree: _gen/

    Collection.validate
    Collection.filter
    Collection.is_valid
    Collection.cast
    filter
    require_relationship_one_to_one
    require_relationship_one_to_at_least_one
