========
Metadata
========

.. currentmodule:: dataframely
.. autosummary::
    :toctree: _gen/

    Collection.members
    Collection.member_schemas
    Collection.required_members
    Collection.optional_members
    Collection.non_ignored_members
    Collection.ignored_members
    Collection.common_primary_key
    Collection.matches
    Collection.to_dict
