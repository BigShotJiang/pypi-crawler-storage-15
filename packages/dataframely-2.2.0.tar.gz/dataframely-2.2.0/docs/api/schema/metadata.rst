========
Metadata
========

.. currentmodule:: dataframely
.. autosummary::
    :toctree: _gen/

    Schema.column_names
    Schema.columns
    Schema.primary_key
    Schema.matches
