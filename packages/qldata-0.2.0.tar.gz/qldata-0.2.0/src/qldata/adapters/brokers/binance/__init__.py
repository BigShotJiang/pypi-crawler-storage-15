"""Binance broker adapter."""

from qldata.adapters.brokers.binance.adapter import BinanceAdapter

__all__ = ["BinanceAdapter"]
