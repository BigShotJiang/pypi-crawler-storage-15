"""Logging package."""

from qldata.logging.setup import get_logger

__all__ = [
    "get_logger",
]
