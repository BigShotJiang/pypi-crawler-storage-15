from bigdata_research_tools.utils.observer import Observable


class Workflow(Observable):
    def __init__(self):
        super().__init__()
