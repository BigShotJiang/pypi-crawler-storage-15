from logging import Logger, getLogger
from typing import Any

from pandas import DataFrame, Series

from bigdata_research_tools.labeler.labeler import Labeler
from bigdata_research_tools.llm.base import LLMConfig
from bigdata_research_tools.prompts.labeler import (
    get_other_entity_placeholder,
    get_risk_system_prompt,
    get_target_entity_placeholder,
)

logger: Logger = getLogger(__name__)


class RiskLabeler(Labeler):
    """Risk labeler."""

    def __init__(
        self,
        llm_model_config: str | LLMConfig | dict = "openai::gpt-4o-mini",
        label_prompt: str | None = None,
        # TODO (cpinto, 2025.02.07) This value is also in the prompt used.
        #  Changing it here would break the process.
        unknown_label: str = "unclear",
    ):
        """
        Args:
            llm_model: Name of the LLM model to use. Expected format:
                <provider>::<model>, e.g. "openai::gpt-4o-mini"
            label_prompt: Prompt provided by user to label the search result chunks.
                If not provided, then our default labelling prompt is used.
            unknown_label: Label for unclear classifications
        """
        super().__init__(llm_model_config, unknown_label)
        self.label_prompt = label_prompt

    def get_labels(
        self,
        main_theme: str,
        labels: list[str],
        texts: list[str],
        max_workers: int = 50,
        timeout: int | None = 55,
        textsconfig: list[dict[str, Any]] | None = None,
    ) -> DataFrame:
        """
        Process thematic labels for texts.

        Args:
            main_theme: The main theme to analyze.
            labels: Labels for labelling the chunks.
            texts: List of chunks to label.
            timeout: Timeout for each LLM request.
            max_workers: Maximum number of concurrent workers.

        Returns:
            DataFrame with schema:
            - index: sentence_id
            - columns:
                - motivation
                - label
        """
        system_prompt = (
            get_risk_system_prompt(main_theme, labels)
            if self.label_prompt is None
            else self.label_prompt
        )

        prompts = self.get_prompts_for_labeler(texts, textsconfig)

        responses = self._run_labeling_prompts(
            prompts,
            system_prompt,
            max_workers=max_workers,
            timeout=timeout,
            processing_callbacks=[
                self.parse_labeling_response,
                self._deserialize_label_response,
            ],
        )

        return self._convert_to_label_df(responses)

    def post_process_dataframe(
        self,
        df: DataFrame,
        extra_fields: dict | None,
        extra_columns: list[str] | None,
    ) -> DataFrame:
        """
        Post-process the labeled DataFrame.

        Args:
            df: DataFrame to process. Schema:
                - Index: int
                - Columns:
                    - timestamp_utc: datetime64
                    - document_id: str
                    - sentence_id: str
                    - headline: str
                    - entity_id: str
                    - entity_name: str
                    - entity_sector: str
                    - entity_industry: str
                    - entity_country: str
                    - entity_ticker: str
                    - text: str
                    - other_entities: str
                    - entities: List[Dict[str, Any]]
                        - key: str
                        - name: str
                        - ticker: str
                        - start: int
                        - end: int
                    - masked_text: str
                    - other_entities_map: List[Tuple[int, str]]
                    - label: str
                    - motivation: str
        Returns:
            Processed DataFrame. Schema:
            - index: int
            - Columns:
                - Time Period
                - Date
                - Company
                - Sector
                - Industry
                - Country
                - Ticker
                - Document ID
                - Headline
                - Quote
                - Motivation
                - Theme
        """
        # Filter unlabeled sentences
        df = df.loc[df["label"] != self.unknown_label].copy()
        if df.empty:
            logger.warning(f"Empty dataframe: all rows labelled {self.unknown_label}")
            return df

        # Process timestamps
        df["timestamp_utc"] = df["timestamp_utc"].dt.tz_localize(None)

        # Sort and format
        sort_columns = ["entity_name", "timestamp_utc", "label"]
        df = df.sort_values(by=sort_columns).reset_index(drop=True)

        # Replace company placeholders
        df["motivation"] = df.apply(replace_company_placeholders, axis=1)

        # Add formatted columns
        df["Time Period"] = df["timestamp_utc"].dt.strftime("%b %Y")
        df["Date"] = df["timestamp_utc"].dt.strftime("%Y-%m-%d")

        df["Document ID"] = (
            df["document_id"] if "document_id" in df.columns else df["rp_document_id"]
        )

        columns_map = {
            "entity_name": "Company",
            "entity_sector": "Sector",
            "entity_industry": "Industry",
            "entity_country": "Country",
            "entity_ticker": "Ticker",
            "headline": "Headline",
            "text": "Quote",
            "motivation": "Motivation",
            "label": "Sub-Scenario",
        }
        optional_fields = ["topics", "source_name", "source_rank", "url"]
        for field in optional_fields:
            if field in df.columns:
                columns_map[field] = field.replace("_", " ").title()

        if extra_fields:
            columns_map.update(extra_fields)
            if "quotes" in extra_fields.keys():
                if "quotes" in df.columns:
                    df["quotes"] = df.apply(
                        replace_company_placeholders, axis=1, col_name="quotes"
                    )
                else:
                    logger.warning("quotes column not in df")

        # Select and order columns
        export_columns = [
            "Time Period",
            "Date",
            "Company",
            "Sector",
            "Industry",
            "Country",
            "Ticker",
            "Document ID",
            "Headline",
            "Quote",
            "Motivation",
            "Sub-Scenario",
        ]

        if extra_columns:
            export_columns += extra_columns

        for field in optional_fields:
            if field in df.columns:
                export_columns += [field.replace("_", " ").title()]

        df = df.rename(columns=columns_map)

        return df[export_columns]


def replace_company_placeholders(
    row: Series, col_name: str = "motivation"
) -> str | list[str]:
    """
    Replace company placeholders in text.

    Args:
        row: Row of the DataFrame. Expected columns:
            - motivation: str
            - entity_name: str
            - other_entities_map: List[Tuple[int, str]]
    Returns:
        Text with placeholders replaced.
    """
    text = row[col_name]
    if isinstance(text, str):
        text = text.replace(get_target_entity_placeholder(), row["entity_name"])
        if row.get("other_entities_map"):
            for entity_id, entity_name in row["other_entities_map"]:
                text = text.replace(
                    f"{get_other_entity_placeholder()}_{entity_id}", entity_name
                )

    elif isinstance(text, list):
        text = [
            t.replace(get_target_entity_placeholder(), row["entity_name"]) for t in text
        ]
        if row.get("other_entities_map"):
            for entity_id, entity_name in row["other_entities_map"]:
                text = [
                    t.replace(
                        f"{get_other_entity_placeholder()}_{entity_id}", entity_name
                    )
                    for t in text
                ]

    return text


# Function to map risk_factor to risk_category
def map_risk_category(risk_factor, mapping):
    return mapping.get(risk_factor, "Not Applicable")
