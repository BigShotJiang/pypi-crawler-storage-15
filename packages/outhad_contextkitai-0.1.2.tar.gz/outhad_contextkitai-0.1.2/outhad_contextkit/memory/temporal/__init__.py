"""Temporal-Causal Multimodal Graph Memory (TCMGM) module."""
from outhad_contextkit.memory.temporal.causal_extractor import CausalExtractor
from outhad_contextkit.memory.temporal.causal_queries import (
    find_root_causes,
    get_causal_chain,
    get_causal_subgraph,
)
from outhad_contextkit.memory.temporal.cross_modal import (
    cross_modal_search,
    find_audio_mentions_in_text,
    find_image_mentions_in_text,
    compute_multimodal_relevance,
    group_by_modality,
)
from outhad_contextkit.memory.temporal.enums import (
    CausalType,
    ModalityType,
    TemporalRelationType,
)
from outhad_contextkit.memory.temporal.multimodal import (
    MultimodalContent,
    MultimodalEmbedder,
    create_audio_content,
    create_image_content,
    create_text_content,
)
from outhad_contextkit.memory.temporal.production_embedder import (
    ProductionMultimodalEmbedder,
    create_production_embedder,
)
from outhad_contextkit.memory.temporal.types import (
    CausalLink,
    TemporalEvent,
    TemporalRelation,
    TimeWindow,
)

# NEW: Flexible embedder system
from outhad_contextkit.memory.temporal.base_embedders import (
    BaseTextEmbedder,
    BaseImageEmbedder,
    BaseAudioEmbedder,
    MultimodalEmbedderBase,
)
from outhad_contextkit.memory.temporal.text_embedders import (
    CLIPTextEmbedder,
    OpenAITextEmbedder,
)
from outhad_contextkit.memory.temporal.image_embedders import CLIPImageEmbedder
from outhad_contextkit.memory.temporal.audio_embedders import (
    WhisperAudioEmbedder,
    CLAPAudioEmbedder,
    HybridAudioEmbedder,
)
from outhad_contextkit.memory.temporal.embedder_factory import (
    EmbedderConfig,
    FlexibleMultimodalEmbedder,
    create_embedder,
    create_default_embedder,
    create_clap_embedder,
    create_hybrid_embedder,
)
from outhad_contextkit.memory.temporal.timeline_queries import TimelineQueries
from outhad_contextkit.memory.temporal.orchestrator import RetrievalOrchestrator

__all__ = [
    # Data types
    "TemporalEvent",
    "TemporalRelation",
    "TimeWindow",
    "CausalLink",
    # Enums
    "ModalityType",
    "CausalType",
    "TemporalRelationType",
    # Causal extraction
    "CausalExtractor",
    # Causal queries
    "get_causal_chain",
    "find_root_causes",
    "get_causal_subgraph",
    # Timeline queries
    "TimelineQueries",
    # Retrieval orchestrator
    "RetrievalOrchestrator",
    # Multimodal
    "MultimodalContent",
    "MultimodalEmbedder",
    "create_text_content",
    "create_image_content",
    "create_audio_content",
    # Production embedder (backward compatible)
    "ProductionMultimodalEmbedder",
    "create_production_embedder",
    # Cross-modal
    "cross_modal_search",
    "find_image_mentions_in_text",
    "find_audio_mentions_in_text",
    "compute_multimodal_relevance",
    "group_by_modality",
    # NEW: Flexible embedder system
    "BaseTextEmbedder",
    "BaseImageEmbedder",
    "BaseAudioEmbedder",
    "MultimodalEmbedderBase",
    "CLIPTextEmbedder",
    "OpenAITextEmbedder",
    "CLIPImageEmbedder",
    "WhisperAudioEmbedder",
    "CLAPAudioEmbedder",
    "HybridAudioEmbedder",
    "EmbedderConfig",
    "FlexibleMultimodalEmbedder",
    "create_embedder",
    "create_default_embedder",
    "create_clap_embedder",
    "create_hybrid_embedder",
]

