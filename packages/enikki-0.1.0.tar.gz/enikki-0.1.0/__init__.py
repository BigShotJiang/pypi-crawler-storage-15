"""
enikki: テキスト対話から絵日記風マンガを生成するCLIツール
"""

__version__ = "0.1.0"
__author__ = "Kentaro Kuribayashi"
