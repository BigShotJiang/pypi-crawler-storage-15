# DAS_Ice

DAS_Ice is a python librairy to process DAS data. It is based on `xarray` and `dask` in order to allow processing of large dataset.
