"""
MCP Server module for BPM Documentation
"""

__version__ = "0.1.0"

