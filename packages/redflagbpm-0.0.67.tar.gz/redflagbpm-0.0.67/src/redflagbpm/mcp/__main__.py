#!/usr/bin/env python3
"""
Entry point for running the MCP server as a module:
    python3 -m redflagbpm.mcp
"""

from redflagbpm.mcp.mcp_server import run

if __name__ == "__main__":
    run()

