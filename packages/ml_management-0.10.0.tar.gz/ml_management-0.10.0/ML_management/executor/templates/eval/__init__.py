from .eval_executor import EvalExecutor


def get_object():
    return EvalExecutor()
