from dagster_cloud.storage.event_logs.storage import (
    GraphQLEventLogStorage as GraphQLEventLogStorage,
)
