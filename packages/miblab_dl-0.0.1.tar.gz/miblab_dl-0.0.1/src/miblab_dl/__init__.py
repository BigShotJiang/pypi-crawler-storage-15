from miblab_dl.fatwatermap import fatwater


