from ambient_toolbox.autodiscover.registry import DecoratorBasedRegistry

decorator_based_registry = DecoratorBasedRegistry()
