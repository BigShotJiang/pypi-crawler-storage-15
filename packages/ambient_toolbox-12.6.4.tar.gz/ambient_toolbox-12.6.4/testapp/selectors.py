from ambient_toolbox.selectors.permission import GloballyVisibleSelector


class ModelWithSelectorGloballyVisibleSelector(GloballyVisibleSelector):
    pass
