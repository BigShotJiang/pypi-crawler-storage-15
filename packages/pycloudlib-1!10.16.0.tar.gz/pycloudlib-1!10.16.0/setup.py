#!/usr/bin/env python3
"""Legacy Python packaging entry-point."""

from setuptools import setup

setup()
