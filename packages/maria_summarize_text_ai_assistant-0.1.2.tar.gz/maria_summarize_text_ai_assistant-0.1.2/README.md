# maria_summarize_text_ai_assistant

A simple Python library to summarize long text using OpenAI API.

## Features
- AI-powered text summarization  
- Clean API design  
- Docstrings included  
- Easy to use in Flask or any Python app  

---

## Installation

After uploading to PyPI:

pip install maria_summarize_text_ai_assistant


---

## Usage

import os
from maria_summarize_text_ai_assistant import summarize_text

# Set GEMINI_API_KEY in your environment
os.environ["GEMINI_API_KEY"] = "YOUR_GEMINI_API_KEY"

long_text = "Artificial intelligence is transforming industries..."
summary = summarize_text(long_text)
print(summary)

---

✅ **Next Steps:**

1. Replace your old `summarize.py` with the Gemini version above  
2. Update `setup.py` as shown and bump version (`0.1.2`)  
3. Rebuild package:
```bash
python setup.py sdist bdist_wheel

4. Upload to PyPI: python -m twine upload dist/*
5. In your Flask app, just set GEMINI_API_KEY as environment variable and your existing code will work without changing imports.











