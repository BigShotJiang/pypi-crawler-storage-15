from raft.collection import Collection
from .template import new_project


docker_collection = Collection(
    'docker',
    new_project)

