# Service Connector



## About

Provides a method for microservices to connect to the byneuron platform


## Concept

Search in the master dataset for matching Gateways. This allows access to the Devices that feature those gateways.
Provides tools for iterating linked entities and store data like numberEvents.



