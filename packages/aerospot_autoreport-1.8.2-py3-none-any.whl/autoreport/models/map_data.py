#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
地图数据模型定义

包含地图生成和渲染所需的强类型数据结构。
这些数据类替代了原来返回的字典，提供类型安全和IDE自动完成支持。
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd


@dataclass
class SatelliteInfo:
    """卫星图像信息"""

    path: str  # ���像路径或URL
    geo_bounds: Tuple[
        float, float, float, float
    ]  # (min_lon, min_lat, max_lon, max_lat)
    width: Optional[int] = None  # 图像宽度（像素）
    height: Optional[int] = None  # 图像高度（像素）
    metadata: Dict[str, Any] = field(default_factory=dict)  # 其他元数据

    def validate(self) -> bool:
        """验证卫星信息完整性"""
        if not self.path:
            raise ValueError("卫星图像路径不能为空")
        min_lon, min_lat, max_lon, max_lat = self.geo_bounds
        if not (min_lon < max_lon and min_lat < max_lat):
            raise ValueError("地理边界不合法: min 必须 < max")
        return True


@dataclass
class MapPrepData:
    """地图生成准备数据 - 替代原来的字典返回值

    包含从 _prepare_map_generation_data() 提取的所有必要数据。
    使用强类型替代字典，提供类型安全和IDE支持。
    """

    # 基础配置
    geo_info: Dict[str, Any]  # 地理信息
    satellite_info: SatelliteInfo  # 卫星图像信息
    visualization_mode: str  # "quantitative" 或 "qualitative"

    # 数据源
    data_to_process: pd.DataFrame  # 主要处理数据（pred_data 或 uav_data）
    pred_data: Optional[pd.DataFrame]  # 模型优化后的数据（可能为None）
    uav_data: Optional[pd.DataFrame]  # 无人机反演数据（可能为None）

    # 地理边界
    satellite_geo_bounds: Tuple[float, float, float, float]  # 卫星图像地理边界
    data_geo_bounds: Tuple[float, float, float, float]  # 数据地理边界

    # 指标信息
    indicator_columns: List[str]  # 有效指标列名列表

    # 可选字段（带默认值）
    measure_data: Optional[pd.DataFrame] = None  # 采样数据（可选）
    all_points_outside: bool = False  # 所有点是否都在卫星图像范围外
    has_measured_data: bool = False  # 是否有实测数据
    satellite_img: Optional[str] = None  # 卫星图像URL或路径

    def validate(self) -> bool:
        """验证准备数据的完整性和有效性"""
        # 验证必需字段
        if self.data_to_process is None or self.data_to_process.empty:
            raise ValueError("data_to_process 不能为空")

        if not self.indicator_columns:
            raise ValueError("indicator_columns 不能为空")

        # 验证地理边界
        if len(self.satellite_geo_bounds) != 4 or len(self.data_geo_bounds) != 4:
            raise ValueError("地理边界必须是 4 元组")

        # 验证卫星信息
        if not isinstance(self.satellite_info, SatelliteInfo):
            raise ValueError("satellite_info 必须是 SatelliteInfo 实例")

        # 验证可视化模式
        if self.visualization_mode not in ["quantitative", "qualitative"]:
            raise ValueError(
                f"visualization_mode 必须是 'quantitative' 或 'qualitative', "
                f"得到 {self.visualization_mode}"
            )

        return True

    @property
    def data_source(self) -> str:
        """获取数据源标识"""
        if self.pred_data is not None and not self.pred_data.empty:
            return "pred_data"
        elif self.uav_data is not None and not self.uav_data.empty:
            return "uav_data"
        else:
            return "unknown"

    def get_data_summary(self) -> Dict[str, Any]:
        """获取数据摘要信息"""
        return {
            "source": self.data_source,
            "record_count": len(self.data_to_process),
            "indicator_count": len(self.indicator_columns),
            "has_measured_data": self.has_measured_data,
            "data_bounds": self.data_geo_bounds,
            "satellite_bounds": self.satellite_geo_bounds,
        }


@dataclass
class InterpolationResult:
    """插值结果容器 - 作为共享资源

    用于存储单次 Kriging 插值的完整结果，
    避免在多个渲染方法间重复传递相同数据。
    """

    Z: np.ndarray  # 插值结果网格
    grid_lon: np.ndarray  # 经度网格
    grid_lat: np.ndarray  # 纬度网格
    boundary_mask: np.ndarray  # 边界掩膜
    boundary_points: np.ndarray  # 边界点

    @property
    def geo_bounds(self) -> Tuple[float, float, float, float]:
        """地理边界"""
        return (
            float(self.grid_lon.min()),
            float(self.grid_lat.min()),
            float(self.grid_lon.max()),
            float(self.grid_lat.max()),
        )

    def validate(self) -> bool:
        """验证插值结果的完整性"""
        if not isinstance(self.Z, np.ndarray) or self.Z.size == 0:
            raise ValueError("Z 网格不能为空")
        if self.grid_lon.size == 0 or self.grid_lat.size == 0:
            raise ValueError("经纬度网格不能为空")
        if self.boundary_mask.size == 0:
            raise ValueError("边界掩膜不能为空")
        return True


@dataclass
class IndicatorContext:
    """指标处理上下文 - 该指标的所有共享数据

    将单个指标的所有处理相关数据组织在一个对象中，
    避免在方法间传递过多的参数。
    """

    indicator: str  # 指标名称
    data: pd.DataFrame  # 指标数据
    vmin: float  # colorbar 最小值
    vmax: float  # colorbar 最大值
    map_types: List[str]  # 应生成的地图类型列表
    interp_result: Optional[InterpolationResult] = None  # 插值结果（延迟计算）
    is_ndvi: bool = False  # 是否为 NDVI 指标
    supports_grading: bool = False  # 是否支持分级
    metadata: Dict[str, Any] = field(default_factory=dict)  # 其他元数据

    @property
    def needs_interpolation(self) -> bool:
        """判断是否需要插值"""
        return any(
            t in self.map_types
            for t in [
                "interpolation",
                "clean_interpolation_svg",
                "level",
                "ndvi_binary",
                "ndvi_bloom_level",
            ]
        )

    @property
    def Z(self) -> np.ndarray:
        """便捷访问插值结果网格"""
        if self.interp_result is None:
            raise ValueError(f"{self.indicator} 插值未计算")
        return self.interp_result.Z

    @property
    def grid_lon(self) -> np.ndarray:
        """便捷访问经度网格"""
        if self.interp_result is None:
            raise ValueError(f"{self.indicator} 插值未计算")
        return self.interp_result.grid_lon

    @property
    def grid_lat(self) -> np.ndarray:
        """便捷访问纬度网格"""
        if self.interp_result is None:
            raise ValueError(f"{self.indicator} 插值未计算")
        return self.interp_result.grid_lat

    def validate(self) -> bool:
        """验证指标上下文的完整性"""
        if not self.indicator or not isinstance(self.indicator, str):
            raise ValueError("indicator 必须是非空字符串")
        if self.data is None or self.data.empty:
            raise ValueError(f"{self.indicator} 的数据不能为空")
        if self.vmin >= self.vmax:
            raise ValueError(
                f"{self.indicator}: vmin({self.vmin}) 必须 < vmax({self.vmax})"
            )
        if not self.map_types:
            raise ValueError(f"{self.indicator} 的 map_types 不能为空")
        return True


@dataclass
class RenderingResult:
    """渲染结果容器"""

    success: bool  # 是否成功
    file_path: Optional[str] = None  # 生成的文件路径
    error_message: Optional[str] = None  # 错误信息
    map_type: Optional[str] = None  # 地图类型 (distribution, interpolation, etc.)
    indicator: Optional[str] = None  # 指标名称
    metadata: Dict[str, Any] = field(default_factory=dict)  # 其他元数据

    def __post_init__(self) -> None:
        """验证结果一致性"""
        if self.success and not self.file_path:
            raise ValueError("成功的渲染结果必须有 file_path")
        if not self.success and not self.error_message:
            raise ValueError("失败的渲染结果必须有 error_message")
