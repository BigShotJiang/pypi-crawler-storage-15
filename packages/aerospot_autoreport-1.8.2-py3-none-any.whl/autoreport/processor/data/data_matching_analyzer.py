"""
数据匹配分析器模块

专职处理航测数据与采样数据的匹配和分析，遵循单一职责原则。

Author: 水质建模团队
"""

import logging
from typing import Any, Dict, Optional, Tuple

import pandas as pd

from autoreport.processor.data.save_history import HistoryDataBundle

from .matcher import handle_invalid_values, match_nearest_points
from .error_analyzer import ErrorAnalyzer

logger = logging.getLogger(__name__)


class WaterQualityModelerFactory:
    """水质模型工厂"""

    @staticmethod
    def create() -> Any:
        """创建水质建模器实例

        Returns:
            AutoWaterQualityModeler 实例
        """
        from autowaterqualitymodeler.core.modeler import AutoWaterQualityModeler

        return AutoWaterQualityModeler()


class DataMatchingAnalyzer:
    """数据匹配分析器

    专职处理航测数据与采样数据的匹配和分析，包括：
    - 最近点匹配
    - 数据合并（与历史数据）
    - 水质模型训练
    - 无效值处理
    - 误差分析

    Examples:
        >>> analyzer = DataMatchingAnalyzer()
        >>> result = analyzer.analyze(
        ...     merged_data=uav_df,
        ...     measure_data=sample_df,
        ...     ref_data=spectral_df
        ... )
    """

    def __init__(
        self,
        modeler_factory: Optional[WaterQualityModelerFactory] = None,
    ) -> None:
        """初始化数据匹配分析器

        Args:
            modeler_factory: 水质建模器工厂（可选）
        """
        self.modeler_factory = modeler_factory or WaterQualityModelerFactory()
        self.error_analyzer = ErrorAnalyzer()
        logger.debug("数据匹配分析器已初始化")

    def analyze(
        self,
        current_uav_data: pd.DataFrame,
        measure_data: pd.DataFrame,
        spectrum_data: pd.DataFrame,
        historical_ref: Optional[pd.DataFrame] = None,
        historical_merged: Optional[pd.DataFrame] = None,
        historical_measure: Optional[pd.DataFrame] = None,
        output_file: Optional[str] = None,
    ) -> Tuple[Dict[str, Any], pd.DataFrame, Any, pd.DataFrame, HistoryDataBundle]:
        """分析航测数据与采样数据的匹配关系

        Args:
            current_uav_data: 当前航测数据 DataFrame（包含 Latitude、Longitude 等）
            measure_data: 采样数据 DataFrame（包含测量值）
            spectrum_data: 光谱数据 DataFrame（遥感传感器获取的光谱反射率数据）
            historical_ref: 历史光谱数据（可选）
            historical_merged: 历史航测数据（可选）
            historical_measure: 历史采样数据（可选）
            output_file: 误差输出文件路径（可选）

        Returns:
            Tuple containing:
                - Dict: 误差分析结果
                - pd.DataFrame: 匹配点的预测数据
                - Any: 模型函数对象
                - pd.DataFrame: 全部数据的预测结果
                - HistoryDataBundle: 历史数据包，用于下次迭代

        Raises:
            ValueError: 当输入数据格式不正确时

        Examples:
            >>> analyzer = DataMatchingAnalyzer()
            >>> errors, pred_data, model, all_pred, history = analyzer.analyze(
            ...     merged_data=uav_df,
            ...     measure_data=sample_df,
            ...     spectrum_data=spectral_df
            ... )
        """
        logger.info("开始匹配和分析数据")

        # 1. 匹配最近的航测点
        matched_idx = self._match_points(measure_data, current_uav_data)

        # 2. 提取匹配的数据
        matched_measure_df, matched_merged_df, matched_spectrum_df = (
            self._extract_matched_data(measure_data, current_uav_data, spectrum_data, matched_idx)
        )

        # 3. 选择建模数据（可能包含历史数据）
        modeling_spectrum, modeling_merged, modeling_measure = self._select_modeling_data(
            matched_spectrum_df,
            matched_merged_df,
            matched_measure_df,
            historical_ref,
            historical_merged,
            historical_measure,
        )

        # 4. 训练模型
        modeler = self.modeler_factory.create()
        model_result = modeler.fit(
            spectrum_data=modeling_spectrum,
            metric_data=modeling_measure,
            old_predictions=modeling_merged,
        )

        # 5. 进行预测
        model_func = model_result.model_data
        pred_data = model_result.predict_unified(matched_spectrum_df, matched_merged_df)
        all_pred_data = model_result.predict_unified(spectrum_data, current_uav_data)

        # 6. 处理无效值
        pred_data = handle_invalid_values(pred_data, matched_merged_df)
        all_pred_data = handle_invalid_values(all_pred_data, current_uav_data)

        # 7. 分析误差
        error_result = self.error_analyzer.analyze(
            measured_data=matched_measure_df,
            predicted_data=pred_data,
            output_file=output_file,
        )

        # 8. 构建历史数据包
        history_bundle = HistoryDataBundle(
            ref_df=matched_spectrum_df,
            merged_df=matched_merged_df,
            measure_df=matched_measure_df,
        )

        logger.info("匹配和分析数据完成")
        return (error_result, pred_data, model_func, all_pred_data, history_bundle)

    @staticmethod
    def _match_points(
        measure_data: pd.DataFrame, all_uav_data: pd.DataFrame
    ) -> list[int]:
        """匹配采样点和航测点

        Args:
            measure_data: 采样数据
            all_uav_data: 完整的航测数据

        Returns:
            匹配的索引列表
        """
        logger.info("开始匹配采样点和航测点")
        matched_idx = match_nearest_points(measure_data, all_uav_data)

        # 验证匹配结果
        if len(set(matched_idx)) <= 1:
            logger.error("所有采样点匹配同一条航测数据，请核对 GPS 信息")
        if len(set(matched_idx)) != len(measure_data):
            logger.warning(f"采样数据和航测数据不是一一对应: {matched_idx}")

        return matched_idx

    @staticmethod
    def _extract_matched_data(
        measure_data: pd.DataFrame,
        merged_data: pd.DataFrame,
        spectrum_data: pd.DataFrame,
        matched_idx: list[int],
    ) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        """提取匹配的数据

        Args:
            measure_data: 采样数据
            merged_data: 航测数据
            spectrum_data: 光谱数据
            matched_idx: 匹配的索引列表

        Returns:
            Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]: 匹配的采样、航测和光谱数据
        """
        matched_measure_df = measure_data
        matched_merged_df = merged_data.iloc[matched_idx]
        matched_merged_df.index = matched_measure_df.index
        matched_spectrum_df = spectrum_data.iloc[matched_idx]
        matched_spectrum_df.index = matched_measure_df.index

        logger.info(f"提取 {len(matched_idx)} 条匹配数据")
        return matched_measure_df, matched_merged_df, matched_spectrum_df

    @staticmethod
    def _select_modeling_data(
        matched_spectrum_df: pd.DataFrame,
        matched_merged_df: pd.DataFrame,
        matched_measure_df: pd.DataFrame,
        historical_ref: Optional[pd.DataFrame],
        historical_merged: Optional[pd.DataFrame],
        historical_measure: Optional[pd.DataFrame],
    ) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        """选择建模数据，可选择包含历史数据

        Args:
            matched_spectrum_df: 匹配的光谱数据
            matched_merged_df: 匹配的航测数据
            matched_measure_df: 匹配的采样数据
            historical_ref: 历史光谱数据（可选）
            historical_merged: 历史航测数据（可选）
            historical_measure: 历史采样数据（可选）

        Returns:
            Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]: 用于建模的光谱、航测和采样数据
        """
        if historical_ref is not None:
            logger.info("使用匹配数据和历史数据进行建模")
            modeling_spectrum = pd.concat(
                [matched_spectrum_df, historical_ref], axis=0, ignore_index=True
            )
            modeling_merged = pd.concat(
                [matched_merged_df, historical_merged], axis=0, ignore_index=True
            )
            modeling_measure = pd.concat(
                [matched_measure_df, historical_measure], axis=0, ignore_index=True
            )
        else:
            logger.info("仅使用匹配数据进行建模")
            modeling_spectrum = matched_spectrum_df
            modeling_merged = matched_merged_df
            modeling_measure = matched_measure_df

        return modeling_spectrum, modeling_merged, modeling_measure
