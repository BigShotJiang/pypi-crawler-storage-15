#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""独立的Colorbar生成器（Phase 1 P0）

参考WaterQSVG项目的ColorbarGenerator实现。
为heatmap_only和其他需要独立colorbar的场景提供专用生成器。

设计原则：
- 独立生成colorbar PNG文件
- 支持定量和定性模式
- 自动处理边界情况（vmin==vmax）
- 提供灵活的配置接口
"""

import logging
import os
from typing import Any, Dict, Optional, Tuple

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.colorbar import ColorbarBase
from matplotlib.cm import ScalarMappable
from matplotlib.colors import Normalize

logger = logging.getLogger(__name__)


class ColorbarGenerator:
    """独立的Colorbar生成器

    职责：
    - 生成独立的colorbar PNG文件
    - 支持定量模式（连续色图）和定性模式（离散色图）
    - 处理特殊情况（vmin==vmax、NaN值等）
    - 提供灵活的字体和布局配置

    使用场景：
    - heatmap_only模式的colorbar生成
    - 需要独立colorbar的热力图系统
    - 与waterqsvg等下游系统集成
    """

    def __init__(
        self,
        figsize: Tuple[float, float] = (1.5, 15),  # waterqsvg标准尺寸
        dpi: int = 150,
        cmap_name: str = "jet",  # ✓ waterqsvg标准色系：'jet'
        colorbar_label_font: int = 48,
        colorbar_tick_font: int = 48,
        label_color: str = "white",
        tick_width: int = 3,
        tick_length: int = 10,
        tick_pad: int = 10,
        outline_width: int = 3,
    ) -> None:
        """初始化Colorbar生成器（waterqsvg 兼容版本）

        Args:
            figsize: 图形大小 (width, height) - 默认 (1.5, 15) 与 waterqsvg 一致
            dpi: 分辨率 - 默认 150 与 waterqsvg 一致
            cmap_name: 色图名称（默认jet） - ✓ 与 waterqsvg 一致使用 'jet' 色系
            colorbar_label_font: colorbar标签字体大小 - 默认 48 与 waterqsvg 一致
            colorbar_tick_font: colorbar刻度字体大小 - 默认 48 与 waterqsvg 一致
            label_color: 标签文字颜色 - 默认 'white' 与 waterqsvg 一致
            tick_width: 刻度线宽度 - 默认 3 与 waterqsvg 一致
            tick_length: 刻度线长度 - 默认 10 与 waterqsvg 一致
            tick_pad: 标签与colorbar间距 - 默认 10 与 waterqsvg 一致
            outline_width: colorbar轮廓线宽度 - 默认 3 与 waterqsvg 一致
        """
        self.figsize = figsize
        self.dpi = dpi
        self.cmap_name = cmap_name
        self.colorbar_label_font = colorbar_label_font
        self.colorbar_tick_font = colorbar_tick_font
        self.label_color = label_color
        self.tick_width = tick_width
        self.tick_length = tick_length
        self.tick_pad = tick_pad
        self.outline_width = outline_width
        self.logger = logger
        
        # 设置中文字体，与waterqsvg保持一致
        self._setup_font()
    
    def _setup_font(self):
        """设置字体，与waterqsvg保持一致"""
        try:
            import matplotlib.font_manager as fm
            
            # 尝试常见的中文字体
            chinese_fonts = [
                'SimHei',  # 黑体
                'Microsoft YaHei',  # 微软雅黑
                'SimSun',  # 宋体
                'Arial Unicode MS',  # Unicode字体
                'Noto Sans CJK SC',  # Google Noto字体
                'WenQuanYi Micro Hei',  # 文泉驿微米黑
                'DejaVu Sans'  # 默认字体
            ]
            
            available_fonts = [f.name for f in fm.fontManager.ttflist]
            selected_font = 'DejaVu Sans'  # 默认字体
            
            for font in chinese_fonts:
                if font in available_fonts:
                    selected_font = font
                    break
            
            plt.rcParams.update({
                'font.size': 12,
                'font.family': 'sans-serif',
                'font.sans-serif': [selected_font],
                'axes.unicode_minus': False
            })
            
            self.logger.info(f"使用字体: {selected_font}")
            
        except Exception as e:
            self.logger.warning(f"字体设置失败，使用默认字体: {e}")
            plt.rcParams.update({
                'font.size': 12,
                'font.family': 'sans-serif',
                'axes.unicode_minus': False
            })

    def generate(
        self,
        vmin: float,
        vmax: float,
        indicator: str,
        save_path: str,
        colorbar_mode: str = "quantitative",
        grade_config: Optional[Dict[str, Any]] = None,
    ) -> Optional[str]:
        """生成colorbar PNG文件

        Args:
            vmin: 最小值
            vmax: 最大值
            indicator: 指标名称
            save_path: 保存路径
            colorbar_mode: "quantitative"（定量）或"qualitative"（定性）
            grade_config: 定性模式下的分级配置

        Returns:
            Optional[str]: 保存的文件路径，或None如果失败
        """
        try:
            self.logger.info(f"生成colorbar: {indicator} (mode={colorbar_mode})")

            # 处理边界情况：vmin == vmax
            if np.isclose(vmin, vmax):
                vmin = vmin - 0.5
                vmax = vmax + 0.5
                self.logger.warning(
                    f"{indicator} vmin==vmax, 自动扩展范围: [{vmin}, {vmax}]"
                )

            # 根据模式生成colorbar
            if colorbar_mode == "qualitative" and grade_config:
                fig = self._generate_qualitative_colorbar(
                    vmin, vmax, indicator, grade_config
                )
            else:
                fig = self._generate_quantitative_colorbar(vmin, vmax, indicator)

            # 保存文件，与waterqsvg保持一致的参数
            save_kwargs = {
                "dpi": self.dpi,
                "bbox_inches": "tight",
                "pad_inches": 0.05,  # waterqsvg标准
                "transparent": True,
                "facecolor": "none",
                "edgecolor": "none"
            }
            
            fig.savefig(save_path, **save_kwargs)
            plt.close(fig)

            self.logger.info(f"✓ {indicator} colorbar已保存: {save_path}")
            return save_path

        except Exception as e:
            self.logger.error(f"生成colorbar失败: {str(e)}")
            return None

    def _generate_quantitative_colorbar(
        self, vmin: float, vmax: float, indicator: str
    ) -> plt.Figure:
        """生成定量模式的colorbar

        Args:
            vmin: 最小值
            vmax: 最大值
            indicator: 指标名称

        Returns:
            Figure: matplotlib图形对象
        """
        fig, ax = plt.subplots(figsize=self.figsize, dpi=self.dpi)

        # 设置透明背景（与waterqsvg一致）
        fig.patch.set_alpha(0.0)
        ax.patch.set_alpha(0.0)

        # 创建标准化器和色图映射
        norm = Normalize(vmin=vmin, vmax=vmax)
        cmap = plt.get_cmap(self.cmap_name)
        sm = ScalarMappable(cmap=cmap, norm=norm)
        sm.set_array([])

        # 创建colorbar，不显示指标名称
        cbar = ColorbarBase(
            ax,
            cmap=cmap,
            norm=norm,
            orientation="vertical",
        )

        # 设置字体大小和颜色（与waterqsvg一致）
        cbar.ax.tick_params(
            labelsize=self.colorbar_tick_font,
            labelcolor=self.label_color,      # ✓ waterqsvg: 'white'
            width=self.tick_width,             # ✓ waterqsvg: 3
            length=self.tick_length,           # ✓ waterqsvg: 10
            pad=self.tick_pad                  # ✓ waterqsvg: 10
        )

        # 设置colorbar轮廓线宽度（与waterqsvg一致）
        cbar.outline.set_linewidth(self.outline_width)  # ✓ waterqsvg: 3

        # 移除顶部和右边的刺
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        
        # 紧凑布局
        plt.subplots_adjust(left=0.2, right=0.8, top=0.98, bottom=0.02)

        return fig

    def _generate_qualitative_colorbar(
        self,
        vmin: float,
        vmax: float,
        indicator: str,
        grade_config: Dict[str, Any],
    ) -> plt.Figure:
        """生成定性模式的colorbar

        Args:
            vmin: 最小值
            vmax: 最大值
            indicator: 指标名称
            grade_config: 分级配置，格式为：
                {
                    "levels": [1, 2, 3, ...],
                    "labels": ["优", "良", "轻度污染", ...],
                    "colors": ["#00ff00", "#ffff00", "#ff0000", ...]
                }

        Returns:
            Figure: matplotlib图形对象
        """
        # 获取分级信息
        levels = grade_config.get("levels", [])
        labels = grade_config.get("labels", [str(l) for l in levels])
        colors = grade_config.get("colors", None)

        if not levels:
            self.logger.warning("定性模式缺少levels配置，回退到定量模式")
            return self._generate_quantitative_colorbar(vmin, vmax, indicator)

        fig, ax = plt.subplots(figsize=self.figsize, dpi=self.dpi)

        # 设置透明背景（与waterqsvg一致）
        fig.patch.set_alpha(0.0)
        ax.patch.set_alpha(0.0)

        # 如果没有提供颜色，使用默认色图
        if colors is None:
            cmap = plt.get_cmap(self.cmap_name)
            colors = [cmap(i / len(levels)) for i in range(len(levels))]

        # 创建离散的色图
        from matplotlib.colors import ListedColormap, BoundaryNorm

        cmap_discrete = ListedColormap(colors)
        bounds = levels + [levels[-1] + 1]  # 创建边界
        norm = BoundaryNorm(bounds, len(colors))

        # 创建colorbar，不显示指标名称
        cbar = ColorbarBase(
            ax,
            cmap=cmap_discrete,
            norm=norm,
            orientation="vertical",
            spacing="proportional",
            ticks=levels,
        )

        # 设置标签和刻度参数（与waterqsvg一致）
        cbar.ax.tick_params(
            labelsize=self.colorbar_tick_font,
            labelcolor=self.label_color,      # ✓ waterqsvg: 'white'
            width=self.tick_width,             # ✓ waterqsvg: 3
            length=self.tick_length,           # ✓ waterqsvg: 10
            pad=self.tick_pad                  # ✓ waterqsvg: 10
        )
        cbar.ax.set_yticklabels(labels, fontsize=self.colorbar_tick_font)

        # 设置colorbar轮廓线宽度（与waterqsvg一致）
        cbar.outline.set_linewidth(self.outline_width)  # ✓ waterqsvg: 3

        # 移除顶部和右边的刺
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        
        # 紧凑布局
        plt.subplots_adjust(left=0.2, right=0.8, top=0.98, bottom=0.02)

        return fig

    @staticmethod
    def get_default_cmap(indicator: str) -> str:
        """获取指标的默认色图（waterqsvg标准）

        Args:
            indicator: 指标名称

        Returns:
            str: 色图名称 - 默认返回 'jet'（waterqsvg标准色系）
        """
        # 根据指标名称选择合适的色图
        # waterqsvg标准：默认使用'jet'色系
        if indicator.upper() == "NDVI":
            return "RdYlGn"  # 红黄绿（植被指数）
        elif indicator.upper() in ["COD", "BOD", "TP", "TN"]:
            return "RdYlGn_r"  # 污染指标（红为差）
        else:
            return "jet"  # ✓ waterqsvg标准色系：'jet'

    @staticmethod
    def estimate_colorbar_size(
        num_ticks: int = 5, base_height: float = 8.0
    ) -> Tuple[float, float]:
        """根据标签数量估计colorbar大小

        Args:
            num_ticks: 刻度数量
            base_height: 基础高度

        Returns:
            Tuple: (width, height) 图形大小
        """
        # 根据刻度数量调整高度
        height = base_height + (num_ticks - 5) * 0.5
        return (1.5, height)
