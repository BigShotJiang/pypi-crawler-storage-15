"""网格构建工具模块。

为克里金插值提供参数化的网格生成功能，支持多种分辨率策略：
- 卫星图驱动：基于卫星图宽高比自动调整网格分辨率
- 地面分辨率驱动：基于期望的地面分辨率计算网格尺寸

Author: 水质建模团队
"""

import logging
from typing import Optional, Tuple

import numpy as np

logger = logging.getLogger(__name__)


class GridBuilder:
    """网格构建工具类。

    提供参数化的网格生成功能，支持多种分辨率策略。
    所有参数集中管理，易于调整和维护。

    Examples:
        >>> # 使用卫星图驱动的网格生成
        >>> bounds = (100, 20, 105, 25)
        >>> satellite_info = (1200, 800, None)  # width, height, img_data
        >>> grid_lon, grid_lat = GridBuilder.build_grid(
        ...     bounds=bounds,
        ...     satellite_info=satellite_info
        ... )
        >>> assert grid_lon.shape == grid_lat.shape
        >>> assert grid_lon.shape[1] == 1200 or grid_lon.shape[0] == 800  # 宽高比匹配

        >>> # 使用地面分辨率驱动的网格生成
        >>> grid_lon, grid_lat = GridBuilder.build_grid(bounds=bounds)
        >>> assert grid_lon.shape[0] > 50 and grid_lon.shape[0] <= 2000
    """

    # 硬编码参数集中管理
    # 地面分辨率：0.0001 度 ≈ 11 米/像素（在赤道处）
    # 原值 0.00003 导致网格过大，现已调整为更合理的值
    DEFAULT_RESOLUTION = 0.0001

    # 插值精度模式配置
    # 四种预设模式，平衡速度和质量
    INTERPOLATION_MODES = {
        "high_precision": 600,  # 高精度：~360k插值点
        "balanced": 400,  # 平衡：推荐，~160k插值点，5-7倍速度
        "fast": 300,  # 快速：~90k插值点，12-18倍速度
        "ultra_fast": 200,  # 极速：~40k插值点，25-35倍速度
    }

    # 当前活跃的插值模式（可在运行时动态修改）
    # 修改此值以切换插值精度
    INTERPOLATION_MODE = "fast"

    # 卫星图模式目标像素数（用于长边）
    # 从当前活跃的插值模式中获取
    @classmethod
    def get_target_max_pixels(cls) -> int:
        """获取当前活跃的目标最大像素数。

        Returns:
            int: 目标最大像素数
        """
        return cls.INTERPOLATION_MODES.get(cls.INTERPOLATION_MODE, 400)

    @classmethod
    def set_interpolation_mode(cls, mode: str) -> None:
        """动态设置插值精度模式。

        此方法允许在运行时切换插值精度，影响网格大小和插值速度。

        Args:
            mode: 插值模式，可选值：
                - "high_precision": 高精度（~360k插值点）
                - "balanced": 平衡模式（推荐，~160k插值点）
                - "fast": 快速模式（~90k插值点）
                - "ultra_fast": 极速模式（~40k插值点）

        Raises:
            ValueError: 如果指定的模式不存在

        Examples:
            >>> # 切换到平衡模式
            >>> GridBuilder.set_interpolation_mode("balanced")
            >>> GridBuilder.INTERPOLATION_MODE
            'balanced'

            >>> # 切换到快速模式
            >>> GridBuilder.set_interpolation_mode("fast")
        """
        if mode not in cls.INTERPOLATION_MODES:
            available = list(cls.INTERPOLATION_MODES.keys())
            raise ValueError(f"无效的插值模式: '{mode}'。" f"可用模式: {available}")
        cls.INTERPOLATION_MODE = mode
        logger.info(
            f"插值模式已切换为: {mode} " f"(目标像素数={cls.INTERPOLATION_MODES[mode]})"
        )

    @classmethod
    def list_interpolation_modes(cls) -> dict:
        """列出所有可用的插值模式及其配置。

        Returns:
            dict: 模式名称和对应的目标像素数映射
        """
        return cls.INTERPOLATION_MODES.copy()

    # 网格尺寸范围：最小 50 像素，最大 600 像素
    # 原值 2000 太大，现已降低以控制插值网格大小
    MIN_GRID_SIZE = 50
    MAX_GRID_SIZE = 600

    @staticmethod
    def build_grid(
        bounds: Tuple[float, float, float, float],
        satellite_info: Optional[Tuple] = None,
        grid_resolution: Optional[float] = None,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """参数化网格构建，自动选择合适的分辨率策略。

        优先使用卫星图驱动的策略（匹配图像纵横比），其次使用地面分辨率驱动。

        Args:
            bounds: 地理边界 (lon_min, lat_min, lon_max, lat_max) 元组
            satellite_info: 卫星信息元组 (width, height, img_data)，可选
                - width, height: 卫星图像的像素宽和高
                - img_data: 实际图像数据（未在此使用，用于调用方）
                - 如果提供，使用卫星图宽高比策略
            grid_resolution: 地面分辨率（度/像素），仅在无卫星图时使用
                - 默认为 DEFAULT_RESOLUTION = 0.00003（3米/像素）
                - 可通过此参数覆盖

        Returns:
            Tuple[np.ndarray, np.ndarray]: (grid_lon, grid_lat)
                - grid_lon: 经度网格，shape (height, width)
                - grid_lat: 纬度网格，shape (height, width)
                - 两个网格的 shape 相同，可用于 matplotlib 或插值算法

        Examples:
            >>> # 使用卫星图（优先）
            >>> bounds = (100, 20, 105, 25)
            >>> satellite_info = (1200, 800, None)
            >>> grid_lon, grid_lat = GridBuilder.build_grid(
            ...     bounds=bounds,
            ...     satellite_info=satellite_info
            ... )
            >>> # 网格纵横比与卫星图相同，避免图像拉伸
            >>> assert grid_lon.shape == grid_lat.shape

            >>> # 不使用卫星图（使用地面分辨率）
            >>> grid_lon, grid_lat = GridBuilder.build_grid(
            ...     bounds=bounds,
            ...     satellite_info=None
            ... )
            >>> # 网格尺寸由地面分辨率决定
            >>> assert grid_lon.shape[0] >= GridBuilder.MIN_GRID_SIZE
        """
        lon_min, lat_min, lon_max, lat_max = bounds

        # 选择策略：优先使用卫星图驱动
        if satellite_info is not None:
            grid_lon, grid_lat = GridBuilder._build_grid_from_satellite(
                bounds, satellite_info
            )
        else:
            grid_lon, grid_lat = GridBuilder._build_grid_from_resolution(
                bounds, grid_resolution
            )

        logger.debug(
            f"网格构建完成: shape={grid_lon.shape}, "
            f"lon_range=[{lon_min}, {lon_max}], lat_range=[{lat_min}, {lat_max}]"
        )

        return grid_lon, grid_lat

    @staticmethod
    def _build_grid_from_satellite(
        bounds: Tuple[float, float, float, float],
        satellite_info: Tuple,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """基于卫星图纵横比的网格构建。

        自动匹配卫星图的纵横比，生成的网格与图像大小相同或按比例缩放，
        避免图像变形。

        Args:
            bounds: 地理边界 (lon_min, lat_min, lon_max, lat_max)
            satellite_info: 卫星信息 (width, height, img_data)

        Returns:
            Tuple[np.ndarray, np.ndarray]: (grid_lon, grid_lat)
        """
        lon_min, lat_min, lon_max, lat_max = bounds
        img_width, img_height = satellite_info[:2]

        # 计算卫星图的纵横比
        aspect_ratio = img_width / img_height

        # 根据纵横比计算网格像素数
        # 目标是使用当前活跃模式的 MAX_PIXELS 作为长边，短边按比例计算
        target_pixels = GridBuilder.get_target_max_pixels()
        if aspect_ratio >= 1:
            # 宽度 >= 高度：宽度为长边
            lon_pixels = target_pixels
            lat_pixels = int(target_pixels / aspect_ratio)
        else:
            # 高度 > 宽度：高度为长边
            lat_pixels = target_pixels
            lon_pixels = int(target_pixels * aspect_ratio)

        # 应用约束
        lon_pixels, lat_pixels = GridBuilder._constrain_grid_size(
            lon_pixels, lat_pixels
        )

        # 创建网格
        grid_lon, grid_lat = np.meshgrid(
            np.linspace(lon_min, lon_max, lon_pixels),
            np.linspace(lat_min, lat_max, lat_pixels),
        )

        logger.debug(
            f"卫星图驱动网格: 图像纵横比={aspect_ratio:.3f}, "
            f"插值模式={GridBuilder.INTERPOLATION_MODE}, "
            f"网格像素数=({lat_pixels}, {lon_pixels})"
        )

        return grid_lon, grid_lat

    @staticmethod
    def _build_grid_from_resolution(
        bounds: Tuple[float, float, float, float],
        grid_resolution: Optional[float] = None,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """基于地面分辨率的网格构建。

        根据期望的地面分辨率（度/像素）计算所需的网格尺寸。
        适合无卫星图的场景。

        Args:
            bounds: 地理边界 (lon_min, lat_min, lon_max, lat_max)
            grid_resolution: 期望的地面分辨率（度/像素）
                - 默认使用 DEFAULT_RESOLUTION = 0.00003（3米/像素）
                - 可通过参数覆盖

        Returns:
            Tuple[np.ndarray, np.ndarray]: (grid_lon, grid_lat)
        """
        lon_min, lat_min, lon_max, lat_max = bounds

        # 使用指定的分辨率或默认值
        resolution = grid_resolution or GridBuilder.DEFAULT_RESOLUTION

        # 计算地理范围
        lon_range = lon_max - lon_min
        lat_range = lat_max - lat_min

        # 根据分辨率计算所需像素数
        # 使用 ceil 确保覆盖整个范围
        lon_pixels = int(np.ceil(lon_range / resolution))
        lat_pixels = int(np.ceil(lat_range / resolution))

        # 应用约束
        lon_pixels, lat_pixels = GridBuilder._constrain_grid_size(
            lon_pixels, lat_pixels
        )

        # 创建网格
        grid_lon, grid_lat = np.meshgrid(
            np.linspace(lon_min, lon_max, lon_pixels),
            np.linspace(lat_min, lat_max, lat_pixels),
        )

        logger.debug(
            f"分辨率驱动网格: 分辨率={resolution}, "
            f"网格像素数=({lat_pixels}, {lon_pixels})"
        )

        return grid_lon, grid_lat

    @staticmethod
    def _constrain_grid_size(lon_pixels: int, lat_pixels: int) -> Tuple[int, int]:
        """约束网格尺寸到允许范围。

        将网格像素数限制在 [MIN_GRID_SIZE, MAX_GRID_SIZE] 范围内。

        Args:
            lon_pixels: 经度方向像素数
            lat_pixels: 纬度方向像素数

        Returns:
            Tuple[int, int]: (constrained_lon_pixels, constrained_lat_pixels)
        """
        lon_pixels = min(
            max(lon_pixels, GridBuilder.MIN_GRID_SIZE), GridBuilder.MAX_GRID_SIZE
        )
        lat_pixels = min(
            max(lat_pixels, GridBuilder.MIN_GRID_SIZE), GridBuilder.MAX_GRID_SIZE
        )

        return lon_pixels, lat_pixels
