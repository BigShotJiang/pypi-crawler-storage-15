"""Kriging configuration module.

This module contains the kriging method configurations and global kriging settings.
Supports multiple kriging methods with different variogram models and parameters.

⚠️  技术债 - 配置重复问题：
    这个模块中的 KRIGING_CONFIG 和 GLOBAL_KRIGING_METHOD 硬编码了克里金方法配置。
    相似的配置也定义在 core/config_models.py 的 KrigingConfig 模型中。

    未来改进方向：
    1. 统一克里金配置定义为单一来源（core/config_models.py）
    2. 修改 interpolation.py 从 ConfigurationService 获取配置
    3. 删除本模块中的硬编码配置

    这样做会避免配置定义的重复，便于集中管理和维护。

    参考：
    - core/config_models.py: KrigingConfig 类定义 (399-455行)
    - core/configuration_service.py: get_kriging_config() 方法 (190-204行)

Author: Water Quality Modeling Team
"""

# 全局插值方法设置 - 修改此处可切换不同克里金方法进行对比测试
# 可选值: 'auto', 'universal_kriging', 'ordinary_kriging_spherical', 'ordinary_kriging_exponential'
# ⚠️ 注意：此值也在 core/config_models.py:KrigingConfig.method 中定义，保持同步
GLOBAL_KRIGING_METHOD = "ordinary_kriging_spherical"  # 🎯 当前使用：普通克里金球形模型

KRIGING_CONFIG = {
    "universal_kriging": {
        "variogram_model": "gaussian",  # 高斯模型：平滑过渡，无明确影响范围
        "drift_terms": ["regional_linear"],  # 区域线性趋势建模
        "description": "泛克里金-高斯模型（适合连续环境数据，支持趋势建模）",
        "enforce_positive": True,  # 强制插值结果为正数
        "transform_method": "log",  # 负数处理方法: 'log', 'clip', 'none'
    },
    "ordinary_kriging_spherical": {
        "variogram_model": "spherical",  # 球形模型：有明确影响范围和渐变特性
        "n_closest_points": 12,  # 搜索最近12个点（ArcGIS默认）
        "search_radius_factor": 0.3,  # 搜索半径为数据范围的30%
        "description": "普通克里金-球形模型（类似ArcGIS，有明确空间影响范围）",
        "enforce_positive": True,  # 强制插值结果为正数
        "transform_method": "clip",  # 负数处理方法: 直接截断
    },
    "ordinary_kriging_exponential": {
        "variogram_model": "exponential",  # 指数模型：快速衰减，适合局部变化
        "n_closest_points": 8,  # 搜索最近8个点
        "search_radius_factor": 0.25,  # 搜索半径为数据范围的25%
        "description": "普通克里金-指数模型（适合快速变化数据，局部影响强）",
        "enforce_positive": True,  # 强制插值结果为正数
        "transform_method": "clip",  # 负数处理方法: 直接截断
    },
}

# ==================== 变差函数模型特点说明 ====================
#
# Gaussian (高斯模型):
#   - 平滑过渡，无明确影响范围
#   - 适合连续渐变的环境数据
#   - 结果较为光滑，可能低估空间变异性
#
# Spherical (球形模型):
#   - 有明确影响范围（范围内线性增长，之后趋于稳定）
#   - 最常用于地理统计分析
#   - 最接近实际空间变异特征
#   - 类似ArcGIS中的默认配置
#
# Exponential (指数模型):
#   - 快速衰减，形成陡峭的初始段
#   - 适合有强烈局部变化的数据
#   - 需要较多样本点才能获得稳定的变差函数
#
# ==================== 搜索策略说明 ====================
#
# n_closest_points:
#   - 每个插值点使用的最近邻点数
#   - 类似ArcGIS中的"最小点数"和"最大点数"设置
#   - 值越大，考虑更多周围点，结果更平滑但计算更慢
#   - 推荐范围: 8-15 个点
#
# search_radius_factor:
#   - 搜索半径相对于数据分布范围的比例 (0-1)
#   - 值越大，搜索范围越大，可能包含距离较远的点
#   - 值越小，只使用近距离点，可能导致某些区域点数不足
#   - 推荐范围: 0.25-0.5
#
# ==================== 负数处理方法说明 ====================
#
# 'log' (对数变换):
#   - 对所有数据执行: log(值)
#   - 适合环境数据，保持相对变化的完整性
#   - 要求所有数据 > 0
#   - 结果: 倾向于抑制大值的影响，更平衡的空间分布
#
# 'clip' (直接截断):
#   - 将所有负值截断为 0
#   - 简单有效，但可能影响数据分布
#   - 适合需要保证非负约束的场景
#   - 结果: 可能在边界处产生不连续
#
# 'none' (不处理):
#   - 保持原始插值结果，允许负值
#   - 仅当确定无负值数据时使用
#   - 结果: 完全保留克里金的原始计算
#
