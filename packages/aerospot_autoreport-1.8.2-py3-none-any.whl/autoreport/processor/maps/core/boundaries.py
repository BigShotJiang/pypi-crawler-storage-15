"""边界检测模块。

提供多种边界检测算法，用于确定水体或监测区域的边界。
支持的算法：
- Alpha Shape：自适应地检测复杂的凹形边界
- 凸包：简单的凸形边界
- KML边界：从KML文件读取的自定义边界

Author: 水质建模团队
"""

import logging
from typing import Optional

import numpy as np
from matplotlib.path import Path
from scipy.spatial import ConvexHull, Delaunay

logger = logging.getLogger(__name__)


class BoundaryDetector:
    """边界检测工具类。

    提供多种边界检测算法，支持Alpha Shape、凸包等方法。

    Examples:
        >>> import numpy as np
        >>> points = np.array([[0, 0], [1, 0], [1, 1], [0, 1]])
        >>> boundary = BoundaryDetector.compute_alpha_shape(points)
        >>> print(boundary.shape)
    """

    @staticmethod
    def compute_convex_hull(points: np.ndarray) -> np.ndarray:
        """计算散点数据的凸包。

        计算凸包顶点，返回凸包的顶点坐标。
        这是最简单的边界检测方法，适合凸形数据分布。

        Args:
            points: 二维数组，每行为一个点的坐标 (lon, lat)，shape (N, 2)

        Returns:
            np.ndarray: 凸包顶点坐标数组，shape (M, 2)

        Examples:
            >>> points = np.array([[0, 0], [1, 0], [1, 1], [0, 1]])
            >>> hull = BoundaryDetector.compute_convex_hull(points)
            >>> print(hull)
        """
        hull = ConvexHull(points)
        hull_points = points[hull.vertices]
        return hull_points

    @staticmethod
    def compute_alpha_shape(
        points: np.ndarray, alpha: Optional[float] = None
    ) -> np.ndarray:
        """计算Alpha Shape边界，能够处理凹陷形状。

        Alpha Shape 是一种自适应的边界检测算法，能够捕捉数据点的复杂形状。
        Alpha 参数控制边界的"紧密度"：
        - alpha 值越小，边界越紧密，越接近原始点集
        - alpha 值越大，边界越宽松，接近凸包

        Args:
            points: 二维数组，每行为一个点的坐标 (lon, lat)，shape (N, 2)
            alpha: Alpha 参数，控制边界的"紧密度"
                   None 时自动计算

        Returns:
            np.ndarray: 边界点的坐标数组，shape (M, 2)

        Notes:
            - 当点数 < 3 时，直接返回原始点
            - Alpha 的自动计算基于点之间距离的第30百分位数
            - 如果无法找到有效边界，会回退到凸包

        Examples:
            >>> points = np.array([[0, 0], [1, 0], [1, 1], [0, 1], [0.5, 0.5]])
            >>> boundary = BoundaryDetector.compute_alpha_shape(points)
            >>> print(boundary.shape)
        """
        if len(points) < 3:
            return points

        # 计算 Delaunay 三角剖分
        tri = Delaunay(points)

        # 自动计算 alpha 值
        if alpha is None:
            # 基于点之间的平均距离来估算 alpha
            distances = []
            for i in range(len(points)):
                for j in range(i + 1, len(points)):
                    dist = np.sqrt(np.sum((points[i] - points[j]) ** 2))
                    distances.append(dist)

            # 使用距离的某个百分位数作为 alpha
            alpha = np.percentile(distances, 30)  # 与 heatmap_generator 保持一致
            logger.debug(f"自动计算 alpha 值: {alpha:.6f}")

        # 找到边界边
        boundary_edges = []

        # 遍历所有三角形
        for simplex in tri.simplices:
            # 计算三角形的外接圆半径
            triangle_points = points[simplex]

            # 计算边长
            a = np.linalg.norm(triangle_points[1] - triangle_points[0])
            b = np.linalg.norm(triangle_points[2] - triangle_points[1])
            c = np.linalg.norm(triangle_points[0] - triangle_points[2])

            # 检查退化边（数值稳定性保护）
            min_edge_length = np.finfo(float).eps * 100
            if min(a, b, c) < min_edge_length:
                continue  # 跳过退化三角形

            # 半周长
            s = (a + b + c) / 2

            # 数值稳定的面积计算（海伦公式）
            area_squared = s * (s - a) * (s - b) * (s - c)

            # 检查负数（由于数值误差可能出现）
            if area_squared <= 0:
                continue  # 跳过退化三角形

            area = np.sqrt(area_squared)

            # 使用相对阈值而不是绝对阈值
            max_edge = max(a, b, c)
            min_area_threshold = np.finfo(float).eps * 100 * max_edge**2

            if area > min_area_threshold:
                circumradius = (a * b * c) / (4 * area)

                # 检查 circumradius 是否有效
                if np.isfinite(circumradius) and circumradius < alpha:
                    for i in range(3):
                        edge = (simplex[i], simplex[(i + 1) % 3])
                        boundary_edges.append(edge)

        # 找到只出现一次的边（边界边）
        edge_count = {}
        for edge in boundary_edges:
            edge_sorted = tuple(sorted(edge))
            edge_count[edge_sorted] = edge_count.get(edge_sorted, 0) + 1

        # 只保留出现一次的边
        true_boundary_edges = [edge for edge, count in edge_count.items() if count == 1]

        if not true_boundary_edges:
            # 如果没有找到边界，回退到凸包
            logger.warning("未找到有效的 Alpha Shape 边界，回退到凸包")
            return BoundaryDetector.compute_convex_hull(points)

        # 构建边界路径
        boundary_points = []
        remaining_edges = list(true_boundary_edges)

        if remaining_edges:
            # 从第一条边开始
            current_edge = remaining_edges.pop(0)
            boundary_points.extend([current_edge[0], current_edge[1]])

            # 尝试连接后续边
            while remaining_edges:
                last_point = boundary_points[-1]
                found_next = False

                for i, edge in enumerate(remaining_edges):
                    if edge[0] == last_point:
                        boundary_points.append(edge[1])
                        remaining_edges.pop(i)
                        found_next = True
                        break
                    elif edge[1] == last_point:
                        boundary_points.append(edge[0])
                        remaining_edges.pop(i)
                        found_next = True
                        break

                if not found_next:
                    # 如果无法连接，尝试新的起始点
                    if remaining_edges:
                        next_edge = remaining_edges.pop(0)
                        boundary_points.extend([next_edge[0], next_edge[1]])

        # 转换为坐标数组
        boundary_coords = points[boundary_points]

        return boundary_coords

    @staticmethod
    def create_mask(
        grid_lon: np.ndarray, grid_lat: np.ndarray, boundary_points: np.ndarray
    ) -> np.ndarray:
        """创建边界掩码，标记网格中哪些点在边界内。

        使用 matplotlib.path.Path 高效判断点是否在多边形内部。

        Args:
            grid_lon: 网格经度坐标，shape (height, width)
            grid_lat: 网格纬度坐标，shape (height, width)
            boundary_points: 边界顶点坐标，shape (M, 2)

        Returns:
            np.ndarray: 布尔掩码数组，shape 与输入网格相同
                        True = 点在边界内，False = 点在边界外

        Examples:
            >>> lon = np.linspace(0, 1, 10)
            >>> lat = np.linspace(0, 1, 10)
            >>> grid_lon, grid_lat = np.meshgrid(lon, lat)
            >>> boundary = np.array([[0, 0], [1, 0], [1, 1], [0, 1]])
            >>> mask = BoundaryDetector.create_mask(grid_lon, grid_lat, boundary)
            >>> print(mask.shape)
        """
        # 将网格坐标转换为点集
        points = np.column_stack((grid_lon.ravel(), grid_lat.ravel()))

        # 创建边界路径
        boundary_path = Path(boundary_points)

        # 检查每个网格点是否在边界内
        mask = boundary_path.contains_points(points)

        # 重新塑形为网格形状
        mask = mask.reshape(grid_lon.shape)

        return mask
