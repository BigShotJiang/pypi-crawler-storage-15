"""插值引擎模块。

提供高级插值功能，支持多种克里金方法和边界检测算法。

Author: 水质建模团队
"""

import logging
from typing import Any, Optional, Tuple

import numpy as np
import pandas as pd
from scipy.interpolate import griddata
from pykrige.ok import OrdinaryKriging
from pykrige.uk import UniversalKriging

from .kriging_config import KRIGING_CONFIG, GLOBAL_KRIGING_METHOD
from .data_transform import DataTransformer
from .boundaries import BoundaryDetector
from .validators import DataValidator
from .grid_builder import GridBuilder
from .boundary_chain import create_boundary_detection_chain

logger = logging.getLogger(__name__)


class InterpolationEngine:
    """插值引擎类。

    提供多种插值方法，包括克里金插值和线性插值。
    支持数据预处理、边界检测、邻域分析等功能。

    Examples:
        >>> import numpy as np
        >>> engine = InterpolationEngine()
        >>> points = np.array([[0, 0], [1, 0], [1, 1]])
        >>> values = np.array([1.0, 2.0, 3.0])
        >>> grid_lon, grid_lat = np.meshgrid(np.linspace(0, 1, 10), np.linspace(0, 1, 10))
        >>> Z, lon, lat, mask, boundary = engine.enhanced_interpolate(
        ...     all_data=pd.DataFrame({
        ...         'Longitude': points[:, 0],
        ...         'Latitude': points[:, 1],
        ...         'value': values
        ...     }),
        ...     indicator_col='value'
        ... )
    """

    def __init__(
        self,
        kriging_method: str = "auto",
        config_service: Optional[Any] = None,
    ):
        """初始化插值引擎。

        Args:
            kriging_method: 默认克里金方法 ('auto', 'universal_kriging', etc.)
            config_service: ConfigurationService 实例（可选）
        """
        self.kriging_method = kriging_method
        self.config_service = config_service
        self.transformer = DataTransformer()
        self.detector = BoundaryDetector()

        # 优先从 ConfigurationService 获取 Kriging 配置
        if config_service is not None:
            kriging_cfg = config_service.get_kriging_config()
            # 将 Pydantic 模型转换为字典格式以与现有代码兼容
            self.config = self._convert_kriging_config_to_dict(kriging_cfg)
        else:
            # 否则使用默认硬编码配置
            self.config = KRIGING_CONFIG

    @staticmethod
    def _convert_kriging_config_to_dict(kriging_cfg: Any) -> dict:
        """将 KrigingConfig Pydantic 模型转换为字典格式。

        Args:
            kriging_cfg: KrigingConfig Pydantic 模型实例或兼容对象

        Returns:
            dict: 与旧配置格式兼容的字典
        """
        # 检查是否是新的 KrigingConfig 对象（有 kriging_methods 属性）
        if hasattr(kriging_cfg, "kriging_methods") and isinstance(
            getattr(kriging_cfg, "kriging_methods", None), dict
        ):
            # 新的 Pydantic 模型格式
            config_dict = {}
            for method_name, method_config in kriging_cfg.kriging_methods.items():
                config_dict[method_name] = {
                    "variogram_model": method_config.variogram_model,
                    "n_closest_points": getattr(
                        method_config, "n_closest_points", None
                    ),
                    "search_radius_factor": getattr(
                        method_config, "search_radius_factor", None
                    ),
                    "description": getattr(method_config, "description", method_name),
                    "enforce_positive": getattr(
                        method_config, "enforce_positive", True
                    ),
                    "transform_method": getattr(
                        method_config, "transform_method", "none"
                    ),
                }
                # 添加漂移项（如果有）
                if hasattr(method_config, "drift_terms") and method_config.drift_terms:
                    config_dict[method_name]["drift_terms"] = method_config.drift_terms

            return config_dict
        else:
            # 旧的格式或其他格式，直接使用属性
            # 这是为了向后兼容
            return {
                "ordinary_kriging_spherical": {
                    "variogram_model": getattr(
                        kriging_cfg, "variogram_model", "spherical"
                    ),
                    "n_closest_points": getattr(kriging_cfg, "n_closest_points", 12),
                    "search_radius_factor": getattr(
                        kriging_cfg, "search_radius_factor", 0.3
                    ),
                    "description": f"克里金-{getattr(kriging_cfg, 'variogram_model', 'spherical')} 模型",
                    "enforce_positive": getattr(kriging_cfg, "enforce_positive", True),
                    "transform_method": getattr(
                        kriging_cfg, "transform_method", "clip"
                    ),
                },
                "universal_kriging": {
                    "variogram_model": getattr(
                        kriging_cfg, "variogram_model", "gaussian"
                    ),
                    "drift_terms": ["regional_linear"],
                    "description": f"泛克里金-{getattr(kriging_cfg, 'variogram_model', 'gaussian')} 模型",
                    "enforce_positive": getattr(kriging_cfg, "enforce_positive", True),
                    "transform_method": getattr(
                        kriging_cfg, "transform_method", "clip"
                    ),
                },
            }

    @staticmethod
    def _extract_boundary_coords_from_geom(geom):
        """从几何体中提取所有外边界坐标，处理Polygon和MultiPolygon

        ✅ 修复：处理MultiPolygon时采集所有多边形的边界，不仅仅是第一个

        Args:
            geom: shapely.Polygon 或 shapely.MultiPolygon

        Returns:
            np.ndarray: 所有外边界坐标的并集（可能来自多个多边形）
        """
        if geom is None:
            return None

        try:
            if hasattr(geom, "exterior") and not hasattr(geom, "geoms"):
                # Polygon 情况
                return np.array(geom.exterior.coords[:-1])
            elif hasattr(geom, "geoms"):
                # MultiPolygon 情况：采集所有子多边形的外边界 ✅
                all_coords = []
                for sub_geom in geom.geoms:
                    if hasattr(sub_geom, "exterior"):
                        all_coords.append(np.array(sub_geom.exterior.coords[:-1]))

                if all_coords:
                    return np.vstack(all_coords)
                else:
                    logger.warning("MultiPolygon中没有找到有效的Polygon")
                    return None
            else:
                logger.warning(f"未知的几何体类型: {type(geom)}")
                return None
        except Exception as e:
            logger.error(f"提取边界坐标失败: {str(e)}")
            return None

    @staticmethod
    def _sample_boundary_coordinates(
        coords: Optional[np.ndarray], max_samples: int = 50
    ) -> Optional[np.ndarray]:
        """统一的边界点采样逻辑。

        从边界坐标中均匀采样指定数量的点。如果坐标数少于max_samples，
        则返回全部坐标。

        Args:
            coords: 边界坐标数组，shape (N, 2)
            max_samples: 最多采样点数，默认50

        Returns:
            采样后的坐标，或None如果输入无效
        """
        if coords is None or len(coords) == 0:
            return None

        n = min(max_samples, len(coords))
        if len(coords) > n:
            indices = np.linspace(0, len(coords) - 1, n, dtype=int)
            return coords[indices]
        return coords

    def _compute_boundary_point_values(
        self,
        sampled_points: np.ndarray,
        all_points: np.ndarray,
        all_values: np.ndarray,
        boundary_manager=None,
    ) -> np.ndarray:
        """统一的虚拟边界点值赋值逻辑。

        根据采样的边界点，计算其对应的值。如果有boundary_manager，
        则优先选择KML范围内的点；否则，选择全局最近点。

        Args:
            sampled_points: 采样的边界点，shape (M, 2)
            all_points: 所有真实数据点，shape (N, 2)
            all_values: 所有真实数据值，shape (N,)
            boundary_manager: 可选的BoundaryManager实例，用于KML范围过滤

        Returns:
            计算出的虚拟边界点值，shape (M,)
        """
        from scipy.spatial.distance import cdist

        if boundary_manager is None:
            # 简单情况：找全局最近点
            distances = cdist(sampled_points, all_points)
            nearest_indices = np.argmin(distances, axis=1)
            return all_values[nearest_indices]

        # KML 情况：优先找 KML 范围内的点
        points_inside_kml_mask = np.array(
            [boundary_manager.contains_point(lon, lat) for lon, lat in all_points]
        )

        if np.any(points_inside_kml_mask):
            # 有KML范围内的真实点
            points_inside_kml = all_points[points_inside_kml_mask]
            values_inside_kml = all_values[points_inside_kml_mask]

            distances = cdist(sampled_points, points_inside_kml)
            nearest_indices = np.argmin(distances, axis=1)

            logger.info(
                f"从 {len(points_inside_kml)} 个KML范围内的真实数据点中选择最近点作为边界值"
            )
            return values_inside_kml[nearest_indices]
        else:
            # 回退：没有真实数据点在KML范围内
            logger.warning("没有真实数据点在KML范围内，使用全局最近点作为边界值")
            distances = cdist(sampled_points, all_points)
            nearest_indices = np.argmin(distances, axis=1)
            return all_values[nearest_indices]

    def kriging_interpolate(
        self,
        points: np.ndarray,
        values: np.ndarray,
        grid_lon: np.ndarray,
        grid_lat: np.ndarray,
        method: str = "auto",
    ) -> np.ndarray:
        """使用克里金插值方法进行插值。

        支持多种克里金配置，自动尝试不同方法，并在失败时回退到线性插值。

        Args:
            points: 数据点坐标，shape (N, 2)，格式 [lon, lat]
            values: 数据值，shape (N,)
            grid_lon: 插值网格经度，shape (height, width)
            grid_lat: 插值网格纬度，shape (height, width)
            method: 插值方法
                - 'auto': 自动尝试所有克里金方法
                - 'linear': 使用 scipy 线性插值
                - 其他: 使用指定的克里金配置方法名

        Returns:
            np.ndarray: 插值结果网格，shape 与输入网格相同

        Notes:
            - 当数据点 < 3 时，自动回退到线性插值
            - 支持自动数据变换（对数、截断）
            - 所有失败情况都会日志记录并尝试备用方法
        """
        x = points[:, 0]  # 经度
        y = points[:, 1]  # 纬度
        z = values

        # 数据点数量检查
        if len(x) < 3:
            logger.warning("数据点少于3个，使用线性插值")
            return griddata(points, values, (grid_lon, grid_lat), method="linear")

        # 计算数据范围（用于搜索半径）
        x_range = np.max(x) - np.min(x)
        y_range = np.max(y) - np.min(y)
        data_range = np.sqrt(x_range**2 + y_range**2)

        # 根据 method 参数决定尝试顺序
        if method == "linear":
            logger.info("使用 scipy 线性插值方法")
            return griddata(points, values, (grid_lon, grid_lat), method="linear")
        elif method == "auto":
            methods_to_try = [
                "universal_kriging",
                "ordinary_kriging_spherical",
                "ordinary_kriging_exponential",
            ]
        elif method in KRIGING_CONFIG:
            methods_to_try = [method]
        else:
            logger.warning(f"未知的插值方法: {method}，使用自动模式")
            methods_to_try = [
                "universal_kriging",
                "ordinary_kriging_spherical",
                "ordinary_kriging_exponential",
            ]

        # 依次尝试不同的克里金方法
        for method_name in methods_to_try:
            config = KRIGING_CONFIG[method_name]

            try:
                logger.info(f"尝试 {config['description']}...")

                # 数据预处理：防止负数
                if config.get("enforce_positive", False):
                    transform_method = config.get("transform_method", "clip")
                    z_transformed, transform_params = (
                        self.transformer.transform_for_kriging(z, transform_method)
                    )
                    logger.info(
                        f"使用 {transform_method} 方法处理数据，确保正数插值结果"
                    )
                else:
                    z_transformed = z
                    transform_params = {"method": "none"}

                if method_name == "universal_kriging":
                    # 泛克里金
                    kriging_obj = UniversalKriging(
                        x,
                        y,
                        z_transformed,
                        variogram_model=config["variogram_model"],
                        drift_terms=config["drift_terms"],
                        verbose=False,
                        enable_plotting=False,
                        exact_values=True,
                        pseudo_inv=False,
                    )
                    z_pred, ss = kriging_obj.execute(
                        "grid", grid_lon[0, :], grid_lat[:, 0]
                    )
                else:
                    # 普通克里金（球形或指数模型）
                    kriging_obj = OrdinaryKriging(
                        x,
                        y,
                        z_transformed,
                        variogram_model=config["variogram_model"],
                        verbose=False,
                        enable_plotting=False,
                        exact_values=True,
                        pseudo_inv=False,
                    )

                    # 计算搜索半径
                    search_radius = data_range * config["search_radius_factor"]

                    # 执行插值（使用搜索策略）
                    z_pred, ss = kriging_obj.execute(
                        "grid",
                        grid_lon[0, :],
                        grid_lat[:, 0],
                        backend="loop",
                        n_closest_points=config["n_closest_points"],
                    )

                    logger.info(
                        f"搜索半径: {search_radius:.6f}, 最近点数: {config['n_closest_points']}"
                    )

                # 逆变换回原始尺度
                z_pred = self.transformer.inverse_transform(z_pred, transform_params)

                # 统计插值结果范围
                valid_mask = ~np.isnan(z_pred)
                if np.any(valid_mask):
                    min_val, max_val = (
                        np.min(z_pred[valid_mask]),
                        np.max(z_pred[valid_mask]),
                    )
                    negative_count = np.sum(z_pred[valid_mask] < 0)
                    logger.info(
                        f"{config['description']} 成功，网格大小: {z_pred.shape}, "
                        f"值范围: [{min_val:.3f}, {max_val:.3f}], 负值数量: {negative_count}"
                    )
                else:
                    logger.info(
                        f"{config['description']} 成功，网格大小: {z_pred.shape}"
                    )

                return z_pred

            except Exception as e:
                logger.warning(f"{config['description']} 失败: {str(e)}")
                continue

        # 所有克里金方法都失败，回退到线性插值
        logger.warning("所有克里金方法失败，回退到线性插值")
        return griddata(points, values, (grid_lon, grid_lat), method="linear")

    def enhanced_interpolate(
        self,
        all_data: pd.DataFrame,
        grid_resolution: int = 200,
        method: str = "linear",
        neighborhood_radius: int = 2,
        boundary_method: str = "alpha_shape",
        indicator_col: Optional[str] = None,
        fixed_bounds: Optional[list] = None,
        boundary_manager=None,  # ✅ 改为接收已解析的BoundaryManager，避免重复解析KML
        kml_boundary_path: Optional[
            str
        ] = None,  # ⚠️ 保留向后兼容，但优先使用boundary_manager
        satellite_info: Optional[Tuple] = None,
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        """高级插值函数，包含智能边界检测和邻域分析。

        ⚠️  IMPORTANT: 两层级KML约束设计说明

        当 boundary_method="kml" 时，系统在两个阶段都应用KML约束（如果KML有效）：

        【第1层】边界检测（早期）- 从数据点中检测边界
          当 boundary_manager.is_enabled=True 时：
            • 优先策略：直接从 KML 提取边界点（KML已在BoundaryManager中解析）
            • 备选策略：AlphaShape（当KML策略失败时回退）
            日志："【第1层】KML优先模式：使用已解析的 KML 数据 (from BoundaryManager)"
          当 boundary_manager.is_enabled=False 时：
            • 直接使用 AlphaShape 检测数据点凸包
            日志："【第1层】KML模式但KML不可用：降级到AlphaShape边界检测"

        【第2层】插值约束（晚期）- 约束克里金插值结果
          当 boundary_manager.is_enabled=True 时：
            • 添加虚拟边界点：从KML边界采样，以虚拟点引导插值
            • 应用KML掩码：确保插值网格中超出KML边界的区域被设为NaN
            日志："KML边界方法：添加虚拟边界点..."、"已应用边界掩码..."
          当 boundary_manager.is_enabled=False 时：
            • 不应用额外约束，让插值自由填充整个网格

        设计对比：
        ┌─────────────┬──────────────────────┬──────────────────────┐
        │             │ is_enabled=True       │ is_enabled=False      │
        ├─────────────┼──────────────────────┼──────────────────────┤
        │ 第1层       │ KML > AlphaShape(备)  │ AlphaShape           │
        │ 第2层       │ KML虚拟点 + KML掩码   │ 无约束                │
        └─────────────┴──────────────────────┴──────────────────────┘

        验证KML约束是否启用（查看日志）：
          ✓ "【第1层】KML优先模式" → 第1层使用KML
          ✓ "KML边界方法" → 第2层使用KML虚拟点
          ✓ "已应用边界掩码" → 第2层使用KML掩码

        Args:
            all_data: 包含所有文件数据的 DataFrame
            grid_resolution: 网格分辨率（仅作为备选参数）
            method: 插值方法 ('linear', 'cubic', etc.)
            neighborhood_radius: 邻域分析半径（像素）
            boundary_method: 边界约束方法
                - 'kml': 在两个阶段都应用KML约束（推荐有KML时使用）
                - 'alpha_shape': 第1层用AlphaShape，无第2层约束
                - 'convex_hull': 第1层用ConvexHull，无第2层约束
            indicator_col: 指标列名，如果为 None 则使用第一个非坐标列
            fixed_bounds: 固定的地理边界 [min_lon, min_lat, max_lon, max_lat]
            boundary_manager: BoundaryManager 实例（包含已解析的KML状态）
                - 其 is_enabled 属性决定了KML是否可用
                - 不再需要显式传递 kml_path，所有KML解析已在构造时完成
            kml_boundary_path: 已废弃，请勿使用。使用 boundary_manager 替代
            satellite_info: 卫星信息元组 (width, height, img_data)

        Returns:
            Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
                - Z: 插值结果网格
                - grid_lon: 经度网格
                - grid_lat: 纬度网格
                - boundary_mask: 边界掩码
                - boundary_points: 边界点坐标

        Raises:
            ValueError: 当数据格式不正确时
        """
        # 提取坐标和数值（使用 DataValidator 工具类）
        points = DataValidator.extract_points(all_data)
        DataValidator.validate_points(points)

        # 获取指标列
        if indicator_col is not None:
            if indicator_col not in all_data.columns:
                raise ValueError(f"指定的指标列 {indicator_col} 不存在")
            values = all_data[indicator_col].values
        else:
            # 自动选择第一个非坐标列
            value_cols = [
                col
                for col in all_data.columns
                if col not in DataValidator.EXCLUDED_COLS
            ]

            if len(value_cols) == 0:
                raise ValueError("未找到有效的指标数据列")

            indicator_col = value_cols[0]
            values = all_data[indicator_col].values
            logger.info(f"自动选择指标列: {indicator_col}")

        # 验证数据值（使用 DataValidator 工具类）
        DataValidator.validate_values(values)

        # 计算或解析边界
        if fixed_bounds is not None:
            lon_min, lat_min, lon_max, lat_max = fixed_bounds
            logger.info(f"使用固定边界: {fixed_bounds}")
        else:
            lon_min, lat_min, lon_max, lat_max = (
                points[:, 0].min(),
                points[:, 1].min(),
                points[:, 0].max(),
                points[:, 1].max(),
            )

        # 验证边界（使用 DataValidator 工具类）
        DataValidator.validate_bounds((lon_min, lat_min, lon_max, lat_max))

        # 边界检测（使用 BoundaryDetectionChain 链式策略）
        # 注意：KML 的有效性完全由 boundary_manager.is_enabled 决定
        # 无需传递 kml_path，所有 KML 解析已在 BoundaryManager 构造时完成
        chain = create_boundary_detection_chain(
            boundary_method=boundary_method,
            detector=self.detector,
            boundary_manager=boundary_manager,
        )
        boundary_points = chain.detect(points)

        # 创建插值网格（使用 GridBuilder 工具类）
        grid_lon, grid_lat = GridBuilder.build_grid(
            bounds=(lon_min, lat_min, lon_max, lat_max),
            satellite_info=satellite_info,
            grid_resolution=None,
        )

        # 添加虚拟边界点以约束克里金插值
        # 【重要】无论是否有有效的KML，只要 boundary_method 指定了，都应该添加相应的虚拟边界点
        # 统一逻辑：确定实际边界方法，然后统一处理采样和值计算
        try:
            # 确定实际使用的边界方法（KML无效时降级到AlphaShape）
            has_valid_kml = (
                boundary_method == "kml"
                and boundary_manager
                and boundary_manager.is_enabled
            )
            actual_boundary_method = (
                "kml"
                if has_valid_kml
                else ("alpha_shape" if boundary_method == "kml" else boundary_method)
            )

            # 确定边界坐标
            if actual_boundary_method == "kml":
                logger.info(
                    "KML边界方法：添加虚拟边界点以约束克里金插值（使用已解析的BoundaryManager数据）"
                )
                final_geom = boundary_manager.final_geom
                if final_geom is None:
                    logger.warning(
                        "BoundaryManager中的final_geom为None，使用detection得到的boundary_points"
                    )
                    boundary_coords = boundary_points
                else:
                    boundary_coords = self._extract_boundary_coords_from_geom(
                        final_geom
                    )
                    if boundary_coords is None:
                        logger.warning(
                            "无法从几何体中提取边界坐标，回退到boundary_points"
                        )
                        boundary_coords = boundary_points
                use_kml_filter = True
            else:
                logger.info(
                    f"{actual_boundary_method} 边界方法：添加虚拟边界点以实现平滑的边界过度"
                )
                if actual_boundary_method == "alpha_shape" and boundary_method == "kml":
                    logger.warning(
                        "⚠️  【第2层】KML模式但KML不可用（is_enabled=False）：降级到AlphaShape虚拟边界点"
                    )
                boundary_coords = boundary_points
                use_kml_filter = False

            # 统一的采样和值赋予逻辑
            sampled = self._sample_boundary_coordinates(boundary_coords)
            if sampled is not None:
                boundary_mgr = boundary_manager if use_kml_filter else None
                boundary_vals = self._compute_boundary_point_values(
                    sampled, points, values, boundary_mgr
                )
                points = np.vstack([points, sampled])
                values = np.concatenate([values, boundary_vals])

                logger.info(
                    f"添加 {len(sampled)} 个{actual_boundary_method}虚拟边界点进行克里金插值，"
                    f"总数据点数：{len(points)}"
                )
            else:
                logger.warning(
                    f"无法获取有效的 {actual_boundary_method} 边界点，跳过虚拟边界点添加"
                )

        except Exception as e:
            logger.warning(f"添加虚拟边界点失败: {str(e)}，继续使用原始点集")

        # 执行插值
        # 与原始maps.py (line 968-978) 保持一致：
        # 忽略传入的method参数，直接使用全局配置的克里金方法
        # 原始maps.py的enhanced_interpolation_with_neighborhood接收method="linear"但忽略它，
        # 改为使用GLOBAL_KRIGING_METHOD来确保始终使用克里金插值而非线性插值
        lat_pixels, lon_pixels = grid_lon.shape
        logger.info(f"执行插值，网格大小: {lon_pixels}x{lat_pixels}")
        Z = self.kriging_interpolate(
            points, values, grid_lon, grid_lat, method=GLOBAL_KRIGING_METHOD
        )

        # 验证插值结果
        if Z is None:
            raise ValueError("插值失败，��回值为 None")
        if Z.shape != grid_lon.shape:
            raise ValueError(f"插值结果形状不匹配: {Z.shape} vs {grid_lon.shape}")

        # 创建边界掩码
        # 【重要】掩码逻辑应该与虚拟边界点逻辑一致，统一处理
        try:
            # 【调试】记录网格和插值结果的状态
            logger.debug(
                f"[MASK_DEBUG] grid_lon类型: {type(grid_lon)}, shape: {grid_lon.shape if grid_lon is not None else 'None'}"
            )
            logger.debug(
                f"[MASK_DEBUG] grid_lat类型: {type(grid_lat)}, shape: {grid_lat.shape if grid_lat is not None else 'None'}"
            )
            logger.debug(
                f"[MASK_DEBUG] Z类型: {type(Z)}, shape: {Z.shape if hasattr(Z, 'shape') else 'N/A'}"
            )
            logger.debug(f"[MASK_DEBUG] boundary_method: {boundary_method}")

            # 判断KML是否有效
            has_valid_kml = (
                boundary_method == "kml"
                and boundary_manager
                and boundary_manager.is_enabled
            )
            logger.debug(f"[MASK_DEBUG] has_valid_kml: {has_valid_kml}")

            if has_valid_kml:
                # 【KML掩码】使用BoundaryManager的已解析几何数据
                from shapely.geometry import Point

                final_geom = boundary_manager.final_geom
                logger.debug(f"[MASK_DEBUG] final_geom类型: {type(final_geom)}")

                if final_geom is None:
                    raise ValueError("BoundaryManager的final_geom为None")

                # 创建布尔掩码：检查每个网格点是否在KML几何体内
                logger.debug("[MASK_DEBUG] 开始创建网格点数组...")
                grid_points = np.column_stack((grid_lon.ravel(), grid_lat.ravel()))
                logger.debug(f"[MASK_DEBUG] grid_points形状: {grid_points.shape}")

                logger.debug("[MASK_DEBUG] 开始检查网格点是否在KML几何体内...")
                contains_results = [
                    final_geom.contains(Point(lon, lat)) for lon, lat in grid_points
                ]
                logger.debug(
                    f"[MASK_DEBUG] contains_results长度: {len(contains_results)}, 第一个元素: {contains_results[0] if contains_results else 'empty'}"
                )

                logger.debug(
                    f"[MASK_DEBUG] 尝试将结果转换为numpy数组，目标shape: {grid_lon.shape}"
                )
                boundary_mask = np.array(contains_results).reshape(grid_lon.shape)
                logger.debug(
                    f"[MASK_DEBUG] boundary_mask创建成功，shape: {boundary_mask.shape}"
                )

                logger.info(
                    "使用KML专用掩码方法（从BoundaryManager的已解析数据），确保严格的KML多边形边界形状"
                )
            else:
                # 【非KML方法或KML无效时】使用通用掩码方法（AlphaShape/ConvexHull）
                if boundary_method == "kml":
                    logger.warning(
                        "⚠️  【掩码】KML模式但KML不可用（is_enabled=False）：降级到AlphaShape掩码"
                    )
                    actual_method = "alpha_shape"
                else:
                    actual_method = boundary_method

                logger.debug(f"[MASK_DEBUG] 使用{actual_method}掩码方法创建掩码...")
                boundary_mask = self.detector.create_mask(
                    grid_lon, grid_lat, boundary_points
                )
                logger.debug(
                    f"[MASK_DEBUG] detector.create_mask返回类型: {type(boundary_mask)}, shape: {boundary_mask.shape if hasattr(boundary_mask, 'shape') else 'N/A'}"
                )
                logger.info(f"使用{actual_method}掩码方法")

            if boundary_mask is None:
                raise ValueError("边界掩码生成失败")

            logger.debug(
                f"[MASK_DEBUG] 边界掩码最终验证 - 类型: {type(boundary_mask)}, shape: {boundary_mask.shape}"
            )
        except Exception as e:
            logger.error(f"创建边界掩码异常: {str(e)}", exc_info=True)
            logger.error(
                f"[ERROR_CONTEXT] grid_lon: {type(grid_lon)}, grid_lat: {type(grid_lat)}"
            )
            logger.error(
                f"[ERROR_CONTEXT] Z.shape: {Z.shape if hasattr(Z, 'shape') else 'N/A'}"
            )
            raise ValueError(f"边界掩码创建失败: {str(e)}")

        # 关键修复：应用边界掩码（与原始maps.py line 1002一致）
        # 将边界外的插值结果设为NaN，确保最终结果完全遵守边界
        # 这是第二层保险：虚拟边界点已经约束了克里金，mask再次确保边界外为nan
        try:
            logger.debug(f"[MASK_APPLY_DEBUG] Z类型: {type(Z)}, shape: {Z.shape}")
            logger.debug(
                f"[MASK_APPLY_DEBUG] boundary_mask类型: {type(boundary_mask)}, shape: {boundary_mask.shape}"
            )
            logger.debug(
                f"[MASK_APPLY_DEBUG] ~boundary_mask类型: {type(~boundary_mask)}"
            )

            # 应用掩码
            Z[~boundary_mask] = np.nan
            logger.info("已应用边界掩码，边界外区域设为NaN")
        except Exception as e:
            logger.error(f"应用边界掩码失败: {str(e)}", exc_info=True)
            logger.error(
                f"[ERROR_CONTEXT] Z类型: {type(Z)}, boundary_mask类型: {type(boundary_mask)}"
            )
            logger.error("[ERROR_CONTEXT] 尝试计算 ~boundary_mask 时出错")
            raise

        return Z, grid_lon, grid_lat, boundary_mask, boundary_points
