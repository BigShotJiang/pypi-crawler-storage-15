"""边界检测链式策略模块。

提供链式责任模式的边界检测器，支持多级回退策略和灵活的策略组合。
消除原有嵌套 try-except 的复杂性，提高可读性和可维护性。

Author: 水质建模团队
"""

import logging
from typing import Callable, Optional

import numpy as np

logger = logging.getLogger(__name__)


class BoundaryDetectionChain:
    """链式边界检测器。

    实现责任链模式，支持多个边界检测策略的顺序尝试和自动回退。
    每个策略失败时自动尝试下一个策略，所有策略失败时使用回退策略。

    Examples:
        >>> from .boundaries import BoundaryDetector
        >>> detector = BoundaryDetector()
        >>> points = np.array([[0, 0], [1, 0], [1, 1], [0, 1]])
        >>>
        >>> # 构建检测链：优先 alpha_shape，回退 convex_hull
        >>> chain = (BoundaryDetectionChain()
        ...          .add_strategy('AlphaShape', detector.compute_alpha_shape)
        ...          .set_fallback(detector.compute_convex_hull))
        >>>
        >>> boundary = chain.detect(points)
        >>> assert boundary is not None
        >>> assert boundary.shape[1] == 2  # (N, 2) 坐标数组
    """

    def __init__(self):
        """初始化链式检测器。"""
        self.strategies: list = []  # [(name, callable), ...]
        self.fallback_strategy: Optional[Callable] = None

    def add_strategy(
        self, name: str, strategy_func: Callable
    ) -> "BoundaryDetectionChain":
        """添加边界检测策略到链。

        支持链式调用（fluent interface），按添加顺序尝试策略。

        Args:
            name: 策略名称，用于日志记录
            strategy_func: 检测函数，签名为 `func(points: np.ndarray, **kwargs) -> np.ndarray`

        Returns:
            BoundaryDetectionChain: 返回自身以支持链式调用

        Examples:
            >>> chain = (BoundaryDetectionChain()
            ...          .add_strategy('Method1', func1)
            ...          .add_strategy('Method2', func2))
        """
        self.strategies.append((name, strategy_func))
        logger.debug(f"添加边界检测策略: {name}")
        return self

    def set_fallback(self, strategy_func: Callable) -> "BoundaryDetectionChain":
        """设置最后的回退策略。

        当所有主策略都失败时，使用此回退策略。

        Args:
            strategy_func: 回退策略函数，签名同 add_strategy

        Returns:
            BoundaryDetectionChain: 返回自身以支持链式调用

        Examples:
            >>> chain = BoundaryDetectionChain().set_fallback(convex_hull_func)
        """
        self.fallback_strategy = strategy_func
        logger.debug("设置回退策略")
        return self

    def detect(self, points: np.ndarray, **kwargs) -> np.ndarray:
        """执行链式边界检测。

        按顺序尝试所有添加的策略，返回第一个成功的结果。
        如果所有策略都失败，使用回退策略。

        Args:
            points: 数据点坐标，shape (N, 2)
            **kwargs: 传递给各策略函数的额外参数

        Returns:
            np.ndarray: 边界坐标数组，shape (M, 2)

        Raises:
            ValueError: 所有策略都失败且无可用的回退策略时

        Examples:
            >>> boundary = chain.detect(points, param1=value1)
        """
        if not self.strategies and not self.fallback_strategy:
            raise ValueError("检测链中没有添加任何策略")

        # 尝试所有主策略
        for strategy_name, strategy_func in self.strategies:
            try:
                logger.info(f"尝试边界检测策略: {strategy_name}")
                result = strategy_func(points, **kwargs)

                # 验证结果有效性
                if self._is_valid_result(result):
                    logger.info(f"✓ 边界检测成功: {strategy_name}")
                    return result
                else:
                    logger.warning(
                        f"✗ 策略 {strategy_name} 返回无效结果 (None or empty)"
                    )
                    continue

            except Exception as e:
                logger.warning(f"✗ 策略 {strategy_name} 失败: {str(e)}")
                continue

        # 所有主策略失败，尝试回退策略
        if self.fallback_strategy is not None:
            try:
                logger.warning("→ 使用回退策略")
                result = self.fallback_strategy(points, **kwargs)

                if self._is_valid_result(result):
                    logger.info("✓ 回退策略成功")
                    return result
                else:
                    logger.error("✗ 回退策略返回无效结果")
                    raise ValueError(
                        "边界检测失败：所有策略（包括回退）都返回了无效结果"
                    )

            except Exception as e:
                logger.error(f"✗ 回退策略失败: {str(e)}")
                raise ValueError(f"边界检测失败（回退策略异常）: {str(e)}")

        # 没有回退策略可用
        raise ValueError("无法检测到有效的边界：所有策略都失败且未设置回退策略")

    @staticmethod
    def _is_valid_result(result) -> bool:
        """验证检测结果的有效性。

        有效结果应该是：
        - 非 None
        - numpy 数组或可转换为数组
        - 至少包含 3 个点（三角形）

        Args:
            result: 检测结果

        Returns:
            bool: True 如果结果有效
        """
        if result is None:
            return False

        try:
            result_array = np.asarray(result)
            if result_array.size == 0:
                return False

            # 边界点应该是 (N, 2) 形状（坐标对）
            if result_array.ndim == 1:
                return False

            # 至少需要 3 个点构成边界
            if len(result_array) < 3:
                return False

            return True
        except Exception:
            return False


def create_boundary_detection_chain(
    boundary_method: str,
    detector=None,
    boundary_manager=None,
) -> BoundaryDetectionChain:
    """工厂函数：根据方法名创建配置好的检测链。

    根据指定的 boundary_method 和 boundary_manager 的状态自动组织策略顺序。
    KML 的有效性完全由 boundary_manager.is_enabled 决定，不再需要传递文件路径。

    Args:
        boundary_method: 边界约束方法名
            - 'kml': 使用 KML 约束（如果 boundary_manager.is_enabled）
            - 'alpha_shape': 使用 AlphaShape，无 KML 约束
            - 'convex_hull': 使用 ConvexHull，无 KML 约束
            - 其他: 默认为 alpha_shape + 凸包回退
        detector: BoundaryDetector 实例（提供具体的检测方法）
        boundary_manager: BoundaryManager 实例（包含已解析的KML状态）

    Returns:
        BoundaryDetectionChain: 配置好的检测链

    Examples:
        >>> from .boundaries import BoundaryDetector
        >>> from autoreport.core.boundary_manager import BoundaryManager
        >>> detector = BoundaryDetector()
        >>> boundary_manager = BoundaryManager(kml_path="/path/to/boundary.kml")
        >>> chain = create_boundary_detection_chain(
        ...     boundary_method='kml',
        ...     detector=detector,
        ...     boundary_manager=boundary_manager
        ... )
        >>> boundary = chain.detect(points)
    """
    if detector is None:
        raise ValueError("detector 参数不能为 None")

    chain = BoundaryDetectionChain()

    # 判断KML是否有效
    has_valid_kml = boundary_manager and boundary_manager.is_enabled

    if boundary_method == "kml" and has_valid_kml:
        # KML 优先策略链 - KML已经在BoundaryManager中解析过了
        try:
            from autoreport.utils.kml import get_kml_boundary_points

            kml_path = boundary_manager.kml_path
            logger.info(
                "【第1层】KML优先模式：使用已解析的 KML 数据 (from BoundaryManager)"
            )
            chain.add_strategy("KML", lambda p, **kw: get_kml_boundary_points(kml_path))
        except ImportError:
            logger.warning("无法导入 KML 解析器，跳过 KML 策略")

        logger.info(
            "【第1层】KML优先模式：添加 AlphaShape 作为备选策略（当KML失败时回退）"
        )
        chain.add_strategy("AlphaShape", detector.compute_alpha_shape)
        chain.set_fallback(detector.compute_convex_hull)

    elif boundary_method == "kml":
        # KML 模式但 KML 无效：降级到 AlphaShape
        logger.warning(
            "⚠️  【第1层】KML模式但KML不可用（is_enabled=False）：降级到AlphaShape边界检测，"
            "【第2层】将通过BoundaryManager应用KML约束（如果KML后续启用）"
        )
        chain.add_strategy("AlphaShape", detector.compute_alpha_shape)
        chain.set_fallback(detector.compute_convex_hull)

    elif boundary_method == "alpha_shape":
        # Alpha Shape 优先策略链
        chain.add_strategy("AlphaShape", detector.compute_alpha_shape)
        chain.set_fallback(detector.compute_convex_hull)

    elif boundary_method == "convex_hull":
        # 直接使用凸包
        chain.add_strategy("ConvexHull", detector.compute_convex_hull)

    else:
        # 默认：alpha_shape + 凸包回退
        logger.warning(f"未知的边界检测方法: {boundary_method}，使用默认策略")
        chain.add_strategy("AlphaShape", detector.compute_alpha_shape)
        chain.set_fallback(detector.compute_convex_hull)

    return chain
