"""数据转换模块。

为克里金插值提供数据预处理和后处理功能，包括：
- 数据标准化和变换（对数、截断等）
- 逆变换恢复原始数据范围

Author: 水质建模团队
"""

import logging
from typing import Any, Dict, Tuple

import numpy as np

logger = logging.getLogger(__name__)


class DataTransformer:
    """数据转换工具类。

    提供静态方法用于克里金插值的数据预处理和后处理。

    Examples:
        >>> import numpy as np
        >>> values = np.array([1.0, 2.0, 3.0])
        >>> transformed, params = DataTransformer.transform_for_kriging(values, "log")
        >>> print(transformed)
        >>> restored = DataTransformer.inverse_transform(transformed, params)
    """

    @staticmethod
    def transform_for_kriging(
        values: np.ndarray, method: str = "log"
    ) -> Tuple[np.ndarray, Dict[str, Any]]:
        """为克里金插值预处理数据，处理负数或零值。

        支持三种变换方法：
        - 'log': 对数变换，适合环境数据
        - 'clip': 截断负值为0
        - 'none': 不进行变换

        Args:
            values: 原始数据值数组
            method: 变换方法 ('log', 'clip', 'none')，默认为 'log'

        Returns:
            Tuple[np.ndarray, Dict]:
                - transformed_values: 变换后的数据
                - transform_params: 变换参数（用于逆变换）

        Raises:
            ValueError: 当输入数据不为数组类型时

        Examples:
            >>> values = np.array([1.0, 2.0, 3.0])
            >>> transformed, params = DataTransformer.transform_for_kriging(values, "log")
            >>> assert params["method"] == "log"
        """
        values = np.array(values)

        if method == "log":
            # 对数变换，适合环境数据（如水质指标）
            min_val = np.min(values)
            if min_val <= 0:
                # 如果有负数或零值，添加偏移量使所有值为正
                offset = abs(min_val) + 1e-6
                logger.info(f"检测到负数或零值，添加偏移量: {offset:.6f}")
            else:
                offset = 0

            transformed_values = np.log(values + offset)
            transform_params = {"method": "log", "offset": offset}

        elif method == "clip":
            # 简单截断，不进行数据变换
            transformed_values = values.copy()
            transform_params = {"method": "clip"}

        else:  # method == 'none'
            # 不处理
            transformed_values = values.copy()
            transform_params = {"method": "none"}

        return transformed_values, transform_params

    @staticmethod
    def inverse_transform(
        values: np.ndarray, transform_params: Dict[str, Any]
    ) -> np.ndarray:
        """对插值结果进行逆变换。

        根据原始变换参数，将插值结果恢复到原始数据范围。

        Args:
            values: 插值结果
            transform_params: 变换参数（由 transform_for_kriging 返回）

        Returns:
            np.ndarray: 逆变换后的数据

        Raises:
            KeyError: 当 transform_params 缺少必需的键时

        Examples:
            >>> values = np.array([1.0, 2.0, 3.0])
            >>> transformed, params = DataTransformer.transform_for_kriging(values, "log")
            >>> restored = DataTransformer.inverse_transform(transformed, params)
            >>> assert np.allclose(restored, values)
        """
        method = transform_params["method"]

        if method == "log":
            # 指数逆变换
            offset = transform_params["offset"]
            result = np.exp(values) - offset
            # 确保结果为正数
            result = np.maximum(result, 1e-10)
            return result

        elif method == "clip":
            # 截断负值
            return np.maximum(values, 0)

        else:  # method == 'none'
            return values
