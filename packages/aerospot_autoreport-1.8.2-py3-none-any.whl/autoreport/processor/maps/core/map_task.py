"""地图生成任务模块。

提供标准化的地图生成任务类，统一处理错误和日志记录。
消除重复的 try-except-log 模式，提高代码复用性和可维护性。

Author: 水质建模团队
"""

import logging
from typing import Any, Dict

logger = logging.getLogger(__name__)


class MapGenerationTask:
    """地图生成任务类。

    标准化地图生成流程，提供统一的错误处理、日志记录和结果格式。
    避免在循环中重复写 try-except 和日志记录代码。

    Examples:
        >>> from src.autoreport.processor.maps.visualization.map_renderer import MapRenderer
        >>> from src.autoreport.processor.maps.utils.path_manager import PathManager
        >>>
        >>> renderer = MapRenderer(...)
        >>> path_manager = PathManager(...)
        >>>
        >>> # 创建任务
        >>> task = MapGenerationTask(
        ...     indicator='COD',
        ...     map_type='distribution',
        ...     renderer=renderer,
        ...     path_manager=path_manager
        ... )
        >>>
        >>> # 执行任务
        >>> result = task.execute(data=data, indicator='COD')
        >>>
        >>> # 检查结果
        >>> if result['success']:
        ...     print(f"生成成功: {result['path']}")
        ... else:
        ...     print(f"生成失败: {result['error']}")
        >>>
        >>> # 统一收集结果
        >>> save_paths[result['indicator']][result['map_type']] = result['path']
    """

    def __init__(self, indicator: str, map_type: str, renderer, path_manager):
        """初始化地图生成任务。

        Args:
            indicator: 指标名称 (如 'COD', 'NH3N', 'NDVI')
            map_type: 地图类型 (如 'distribution', 'interpolation', 'level')
            renderer: MapRenderer 实例，提供 render_* 方法
            path_manager: PathManager 实例，提供文件路径管理
        """
        self.indicator = indicator
        self.map_type = map_type
        self.renderer = renderer
        self.path_manager = path_manager

    def execute(self, **kwargs) -> Dict[str, Any]:
        """执行地图生成任务。

        按以下流程执行：
        1. 准备输出路径
        2. 调用对应的渲染方法
        3. 验证生成结果
        4. 统一记录日志
        5. 返回标准化结果字典

        Args:
            **kwargs: 传递给渲染方法的参数 (如 data, satellite_geo_bounds 等)

        Returns:
            Dict[str, Any]: 标准化结果字典，包含：
                - 'path': str or None - 生成的地图文件路径（失败时为 None）
                - 'success': bool - 是否生成成功
                - 'error': str or None - 错误信息（成功时为 None）
                - 'indicator': str - 指标名称
                - 'map_type': str - 地图类型

        Examples:
            >>> task = MapGenerationTask('COD', 'distribution', renderer, path_manager)
            >>>
            >>> result = task.execute(data=data, indicator='COD')
            >>>
            >>> # 处理结果
            >>> if result['success']:
            ...     save_paths['COD']['distribution'] = result['path']
            ... else:
            ...     logger.error(f"生成失败: {result['error']}")
        """
        # 第 1 步：准备输出路径（验证路径管理器可用）
        try:
            # 验证路径管理器配置
            _ = self.path_manager.get_file_path(
                "maps", f"{self.indicator}_{self.map_type}.png"
            )
        except Exception as e:
            logger.error(f"无法生成输出路径: {str(e)}")
            return {
                "path": None,
                "success": False,
                "error": f"路径生成失败: {str(e)}",
                "indicator": self.indicator,
                "map_type": self.map_type,
            }

        # 第 2 步：执行渲染（统一错误处理）
        try:
            logger.info(f"生成 {self.indicator} {self.map_type} 地图...")

            # 检查渲染方法是否存在
            method_name = f"render_{self.map_type}"
            if not hasattr(self.renderer, method_name):
                raise ValueError(f"未知的地图类型: {self.map_type}")

            # 获取并调用渲染方法
            render_method = getattr(self.renderer, method_name)
            result = render_method(**kwargs)

            # 第 3 步：验证结果
            if not result:
                raise RuntimeError("渲染器返回无效结果（None 或空字符串）")

            # 第 4 步：成功日志
            logger.info(f"✓ {self.indicator} {self.map_type} 地图生成成功: {result}")

            return {
                "path": result,
                "success": True,
                "error": None,
                "indicator": self.indicator,
                "map_type": self.map_type,
            }

        except Exception as e:
            # 错误处理和日志
            error_msg = str(e)
            logger.error(
                f"✗ {self.indicator} {self.map_type} 地图生成失败: {error_msg}"
            )

            return {
                "path": None,
                "success": False,
                "error": error_msg,
                "indicator": self.indicator,
                "map_type": self.map_type,
            }

    def __repr__(self) -> str:
        """任务的字符串表示。

        Returns:
            str: 任务描述
        """
        return (
            f"MapGenerationTask(indicator={self.indicator}, "
            f"map_type={self.map_type})"
        )
