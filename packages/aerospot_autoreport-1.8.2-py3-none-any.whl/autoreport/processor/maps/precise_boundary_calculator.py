#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""精确边界计算器（Phase 1 P1）

参考WaterQSVG项目的BoundaryMask实现。
为热力图生成提供统一的、精确的边界计算方法。

解决问题：
- 消除三种渲染器（InterpolationRenderer、SVGRenderer、HeatmapOutputFormatter）之间
  的extent不一致问题
- 提供统一的边界定义和计算方法
- 支持多种边界来源（KML、Alpha Shape、Convex Hull等）
"""

import logging
from typing import Any, Dict, Optional, Tuple

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


class PreciseBoundaryCalculator:
    """精确边界计算器

    职责：
    - 从多个来源计算地理边界（数据、KML、配置等）
    - 提供统一的边界定义接口
    - 支持边界扩展和调整
    - 集成KML边界检测

    设计原则：
    - 单一责任：仅处理边界计算
    - 与渲染器解耦：不依赖具体的渲染实现
    - 可测试性：支持多种输入数据类型
    - 扩展性：支持未来的边界检测算法
    """

    def __init__(self, boundary_manager: Optional[Any] = None) -> None:
        """初始化精确边界计算器

        Args:
            boundary_manager: 边界管理器实例（用于KML边界支持）
        """
        self.boundary_manager = boundary_manager
        self.logger = logger

    def calculate_data_bounds(self, data: pd.DataFrame) -> Optional[Tuple[float, float, float, float]]:
        """从数据计算边界（数据点的最小外包矩形）

        这是最精确的边界方法，因为它完全基于实际数据点。

        Args:
            data: 包含Longitude和Latitude列的DataFrame

        Returns:
            Optional[Tuple]: (min_lon, min_lat, max_lon, max_lat) 或 None
        """
        try:
            # 查找经纬度列（支持大小写变体）
            lon_col = None
            lat_col = None

            for col in data.columns:
                col_lower = col.lower()
                if col_lower == "longitude":
                    lon_col = col
                elif col_lower == "latitude":
                    lat_col = col

            if lon_col is None or lat_col is None:
                self.logger.error(
                    f"数据缺少经纬度列 (可用列: {list(data.columns)})"
                )
                return None

            # 计算边界
            min_lon = float(data[lon_col].min())
            max_lon = float(data[lon_col].max())
            min_lat = float(data[lat_col].min())
            max_lat = float(data[lat_col].max())

            self.logger.debug(
                f"数据边界: 经度[{min_lon:.6f}, {max_lon:.6f}], "
                f"纬度[{min_lat:.6f}, {max_lat:.6f}]"
            )

            return (min_lon, min_lat, max_lon, max_lat)

        except (KeyError, ValueError, AttributeError) as e:
            self.logger.error(f"计算数据边界失败: {e}")
            return None

    def calculate_grid_bounds(
        self, grid_lon: np.ndarray, grid_lat: np.ndarray
    ) -> Tuple[float, float, float, float]:
        """从插值网格计算边界

        这种方法基于插值后的网格坐标。
        与数据边界不同的是，网格边界受插值算法影响。

        Args:
            grid_lon: 网格经度数组
            grid_lat: 网格纬度数组

        Returns:
            Tuple: (min_lon, min_lat, max_lon, max_lat)
        """
        min_lon = float(np.min(grid_lon))
        max_lon = float(np.max(grid_lon))
        min_lat = float(np.min(grid_lat))
        max_lat = float(np.max(grid_lat))

        self.logger.debug(
            f"网格边界: 经度[{min_lon:.6f}, {max_lon:.6f}], "
            f"纬度[{min_lat:.6f}, {max_lat:.6f}]"
        )

        return (min_lon, min_lat, max_lon, max_lat)

    def calculate_config_bounds(self, geo_info: Dict[str, Any]) -> Optional[Tuple[float, float, float, float]]:
        """从配置信息计算边界

        从地理配置中读取预定义的边界。
        这通常是四个角的坐标。

        Args:
            geo_info: 地理信息字典，格式为：
                {
                    "north_east": "lng,lat",
                    "south_west": "lng,lat",
                    "south_east": "lng,lat",
                    "north_west": "lng,lat"
                }

        Returns:
            Optional[Tuple]: (min_lon, min_lat, max_lon, max_lat) 或 None
        """
        try:
            # 解析四个角的坐标
            ne = geo_info.get("north_east", "")  # 东北角
            sw = geo_info.get("south_west", "")  # 西南角

            if not ne or not sw:
                self.logger.warning("配置中缺少必需的角坐标")
                return None

            # 解析坐标字符串 "lng,lat"
            ne_parts = ne.split(",")
            sw_parts = sw.split(",")

            if len(ne_parts) < 2 or len(sw_parts) < 2:
                self.logger.error("坐标格式不正确，应为 'lng,lat'")
                return None

            ne_lon, ne_lat = float(ne_parts[0]), float(ne_parts[1])
            sw_lon, sw_lat = float(sw_parts[0]), float(sw_parts[1])

            # 计算边界
            min_lon = min(ne_lon, sw_lon)
            max_lon = max(ne_lon, sw_lon)
            min_lat = min(ne_lat, sw_lat)
            max_lat = max(ne_lat, sw_lat)

            self.logger.debug(
                f"配置边界: 经度[{min_lon:.6f}, {max_lon:.6f}], "
                f"纬度[{min_lat:.6f}, {max_lat:.6f}]"
            )

            return (min_lon, min_lat, max_lon, max_lat)

        except (ValueError, KeyError, AttributeError) as e:
            self.logger.error(f"解析配置边界失败: {e}")
            return None

    def select_best_bounds(
        self,
        data_bounds: Optional[Tuple[float, float, float, float]] = None,
        config_bounds: Optional[Tuple[float, float, float, float]] = None,
        grid_bounds: Optional[Tuple[float, float, float, float]] = None,
    ) -> Tuple[float, float, float, float]:
        """选择最佳边界

        优先级：
        1. 数据边界（最可靠，基于实际数据点）
        2. 网格边界（基于插值结果）
        3. 配置边界（预配置）

        Args:
            data_bounds: 数据边界
            config_bounds: 配置边界
            grid_bounds: 网格边界

        Returns:
            Tuple: (min_lon, min_lat, max_lon, max_lat)
        """
        if data_bounds is not None:
            self.logger.debug("使用数据边界（最优先级）")
            return data_bounds

        if grid_bounds is not None:
            self.logger.debug("使用网格边界")
            return grid_bounds

        if config_bounds is not None:
            self.logger.debug("使用配置边界")
            return config_bounds

        # 如果都没有，返回默认值
        self.logger.warning("无法获取任何边界信息，使用默认值")
        return (0.0, 0.0, 1.0, 1.0)

    def expand_bounds(
        self,
        bounds: Tuple[float, float, float, float],
        expansion_ratio: float = 0.1,
    ) -> Tuple[float, float, float, float]:
        """扩展边界

        用于在热力图周围添加一些空间。

        Args:
            bounds: 原始边界 (min_lon, min_lat, max_lon, max_lat)
            expansion_ratio: 扩展比例（默认10%）

        Returns:
            Tuple: 扩展后的边界
        """
        min_lon, min_lat, max_lon, max_lat = bounds

        lon_range = max_lon - min_lon
        lat_range = max_lat - min_lat

        # 避免零范围
        if lon_range == 0:
            lon_range = 1.0
        if lat_range == 0:
            lat_range = 1.0

        lon_expansion = lon_range * expansion_ratio
        lat_expansion = lat_range * expansion_ratio

        expanded = (
            min_lon - lon_expansion,
            min_lat - lat_expansion,
            max_lon + lon_expansion,
            max_lat + lat_expansion,
        )

        self.logger.debug(
            f"边界扩展 {expansion_ratio * 100:.1f}%: "
            f"原始 {bounds} → {expanded}"
        )

        return expanded

    def validate_bounds(self, bounds: Tuple[float, float, float, float]) -> bool:
        """验证边界的有效性

        Args:
            bounds: 边界 (min_lon, min_lat, max_lon, max_lat)

        Returns:
            bool: 是否有效
        """
        min_lon, min_lat, max_lon, max_lat = bounds

        # 检查最小值是否小于最大值
        if min_lon >= max_lon:
            self.logger.error(f"无效的经度范围: [{min_lon}, {max_lon}]")
            return False

        if min_lat >= max_lat:
            self.logger.error(f"无效的纬度范围: [{min_lat}, {max_lat}]")
            return False

        # 检查是否在合理的地理范围内（WGS84坐标系）
        if not (-180 <= min_lon <= 180 and -180 <= max_lon <= 180):
            self.logger.error(f"经度超出有效范围 [-180, 180]: [{min_lon}, {max_lon}]")
            return False

        if not (-90 <= min_lat <= 90 and -90 <= max_lat <= 90):
            self.logger.error(f"纬度超出有效范围 [-90, 90]: [{min_lat}, {max_lat}]")
            return False

        return True

    def calculate_unified_bounds(
        self,
        data: Optional[pd.DataFrame] = None,
        geo_info: Optional[Dict[str, Any]] = None,
        grid_lon: Optional[np.ndarray] = None,
        grid_lat: Optional[np.ndarray] = None,
        expand: bool = True,
        expansion_ratio: float = 0.1,
    ) -> Tuple[float, float, float, float]:
        """计算统一的边界

        集合所有边界计算方法，选择最佳结果。

        Args:
            data: 数据DataFrame
            geo_info: 地理信息字典
            grid_lon: 网格经度数组
            grid_lat: 网格纬度数组
            expand: 是否扩展边界
            expansion_ratio: 扩展比例

        Returns:
            Tuple: (min_lon, min_lat, max_lon, max_lat)
        """
        self.logger.info("计算统一的地理边界...")

        # 计算各种边界
        data_bounds = self.calculate_data_bounds(data) if data is not None else None
        config_bounds = self.calculate_config_bounds(geo_info) if geo_info else None
        grid_bounds = (
            self.calculate_grid_bounds(grid_lon, grid_lat)
            if grid_lon is not None and grid_lat is not None
            else None
        )

        # 选择最佳边界
        bounds = self.select_best_bounds(data_bounds, config_bounds, grid_bounds)

        # 验证边界
        if not self.validate_bounds(bounds):
            self.logger.error("边界验证失败，使用默认值")
            bounds = (0.0, 0.0, 1.0, 1.0)

        # 可选扩展
        if expand:
            bounds = self.expand_bounds(bounds, expansion_ratio)

        self.logger.info(
            f"统一边界: 经度[{bounds[0]:.6f}, {bounds[2]:.6f}], "
            f"纬度[{bounds[1]:.6f}, {bounds[3]:.6f}]"
        )

        return bounds

    def format_bounds_for_output(
        self, bounds: Tuple[float, float, float, float]
    ) -> Dict[str, str]:
        """格式化边界为输出格式

        用于WaterQSVG兼容的输出格式。

        Args:
            bounds: 边界 (min_lon, min_lat, max_lon, max_lat)

        Returns:
            Dict: 四个角的坐标，格式为：
                {
                    "nw": "min_lon,max_lat",  # 西北角
                    "ne": "max_lon,max_lat",  # 东北角
                    "sw": "min_lon,min_lat",  # 西南角
                    "se": "max_lon,min_lat"   # 东南角
                }
        """
        min_lon, min_lat, max_lon, max_lat = bounds

        return {
            "nw": f"{min_lon:.6f},{max_lat:.6f}",  # 西北角
            "ne": f"{max_lon:.6f},{max_lat:.6f}",  # 东北角
            "sw": f"{min_lon:.6f},{min_lat:.6f}",  # 西南角
            "se": f"{max_lon:.6f},{min_lat:.6f}",  # 东南角
        }
