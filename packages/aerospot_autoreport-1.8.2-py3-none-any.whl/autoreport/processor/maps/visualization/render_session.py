"""渲染会话数据容器模块。

提供 RenderingSession dataclass，作为单个指标的渲染会话参数容器。
所有渲染器共享这个会话对象中的参数，避免重复计算和参数传递混乱。

同时定义了三个 Protocol 接口来应用接口隔离原则（ISP）：
- ColorbarProvider: 提供 colorbar 相关的属性
- FigureProvider: 提供图形创建相关的属性
- StyleProvider: 提供样式和布局相关的属性

这样允许渲染器只依赖它们实际需要的接口，而不是整个 RenderingSession 对象。

Author: 水质建模团队
"""

from dataclasses import dataclass
from typing import Any, Dict, Optional, Tuple, Protocol

from matplotlib.colors import Normalize


# ==================== Protocol 接口定义 ====================


class ColorbarProvider(Protocol):
    """Colorbar 提供者接口。

    定义了创建和配置 colorbar 所需的最小接口。
    任何只需要 colorbar 相关功能的组件都应该依赖这个接口。

    Attributes:
        vmin: Colorbar 最小值，由数据计算得出
        vmax: Colorbar 最大值，由数据计算得出
        colorbar_mode: Colorbar 模式，"quantitative" 或 "qualitative"
    """

    vmin: float
    vmax: float
    colorbar_mode: str


class FigureProvider(Protocol):
    """图形创建提供者接口。

    定义了创建 matplotlib 图形所需的最小接口。
    任何需要创建图形和轴的组件都应该依赖这个接口。

    Attributes:
        fig: Matplotlib figure 对象
        ax: Matplotlib axes 对象
        dpi: 分辨率（dots per inch）
        figsize: 图形大小 (宽, 高)，单位为英寸
    """

    fig: Any
    ax: Any
    dpi: float
    figsize: Tuple[float, float]


class StyleProvider(Protocol):
    """样式和布局提供者接口。

    定义了设置样式和布局所需的最小接口。
    任何需要字体配置和地理边界的组件都应该依赖这个接口。

    Attributes:
        font_sizes: 字体大小字典，包含各种字体配置
        geo_bounds: 地理边界 [min_lon, min_lat, max_lon, max_lat]
    """

    font_sizes: Dict[str, Any]
    geo_bounds: Optional[list]


@dataclass
class RenderingSession(ColorbarProvider, FigureProvider, StyleProvider):
    """单个指标的渲染会话 - 所有渲染器共享参数。

    这是一个纯数据容器，用于存储该指标所有渲染器共享的参数和环境。
    不包含任何初始化逻辑或依赖注入，只存储计算结果。

    实现以下 Protocol 接口以支持接口隔离原则（ISP）：
    - ColorbarProvider: 提供 vmin, vmax, colorbar_mode
    - FigureProvider: 提供 fig, ax, dpi, figsize
    - StyleProvider: 提供 font_sizes, geo_bounds

    这样允许渲染器根据需要只依赖特定的接口，而不是整个 RenderingSession 对象。

    Attributes:
        vmin: Colorbar 最小值，由数据计算得出
        vmax: Colorbar 最大值，由数据计算得出
        colorbar_mode: Colorbar 模式，"quantitative" 或 "qualitative"
        fig: Matplotlib figure 对象
        ax: Matplotlib axes 对象
        dpi: 分辨率（dots per inch）
        figsize: 图形大小 (宽, 高)，单位为英寸
        font_sizes: 字体大小字典，包含各种字体配置
        geo_bounds: 地理边界 [min_lon, min_lat, max_lon, max_lat]
        layout_info: 布局信息字典，包含轴配置等

    Examples:
        >>> from matplotlib.colors import Normalize
        >>> import matplotlib.pyplot as plt
        >>> session = RenderingSession(
        ...     vmin=0.0,
        ...     vmax=10.0,
        ...     colorbar_mode="quantitative",
        ...     fig=plt.figure(figsize=(12, 8)),
        ...     ax=plt.axes(),
        ...     dpi=100.0,
        ...     figsize=(12, 8),
        ...     font_sizes={"title": 16, "label": 12},
        ...     geo_bounds=[120.0, 30.0, 121.0, 31.0],
        ...     layout_info={"hide_axis": False}
        ... )
        >>> norm = session.color_norm
        >>> norm.vmin
        0.0
    """

    vmin: float
    vmax: float
    colorbar_mode: str
    fig: Any
    ax: Any
    dpi: float
    figsize: Tuple[float, float]
    font_sizes: Dict[str, Any]
    geo_bounds: Optional[list]
    layout_info: Dict[str, Any]

    @property
    def color_norm(self) -> Normalize:
        """获取颜色归一化对象。

        便捷属性，用于创建 Matplotlib 的颜色归一化对象。
        所有渲染器都使用这个对象来确保颜色映射一致。

        Returns:
            Normalize: Matplotlib 颜色归一化对象，范围为 [vmin, vmax]

        Examples:
            >>> session = RenderingSession(vmin=0, vmax=10, ...)
            >>> norm = session.color_norm
            >>> norm.vmin
            0
            >>> norm.vmax
            10
        """
        return Normalize(vmin=self.vmin, vmax=self.vmax)
