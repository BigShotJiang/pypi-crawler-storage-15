"""布局管理模块。

提供自适应布局参数计算和字体大小调整功能。
所有渲染器使用统一的策略表计算布局，保证视觉效果一致。

Author: 水质建模团队
"""

import logging
from typing import Dict, Tuple

logger = logging.getLogger(__name__)


class LayoutStrategy:
    """参数化布局策略类。

    使用配置表替代 if-else 分支，集中管理所有布局参数。
    支持有/无右侧元素的两种模式。

    Examples:
        >>> params = LayoutStrategy.get_layout_params(aspect_ratio=2.5, has_right_element=True)
        >>> print(f"左边界: {params['left']}, 宽度: {params['width']}")
    """

    # 有右侧元素时的布局策略表
    # 键：(has_right_element=True) 时的条件标识
    # 值：对应的布局参数字典
    STRATEGIES_WITH_RIGHT_ELEMENT = {
        "aspect_ratio_2_0_plus": {  # aspect_ratio > 2.0
            "left": 0.03,
            "bottom": 0.05,
            "right_margin": 0.03,
            "right_element_width_colorbar": 0.15,
            "right_element_width_legend": 0.15,
            "width_formula": "1.0 - left - right_margin - right_element_width",
            "height": 0.82,
        },
        "aspect_ratio_1_5_plus": {  # 1.5 < aspect_ratio <= 2.0
            "left": 0.03,
            "bottom": 0.06,
            "right_margin": 0.03,
            "right_element_width_colorbar": 0.12,
            "right_element_width_legend": 0.12,
            "width_formula": "1.0 - left - right_margin - right_element_width",
            "height": 0.84,
        },
        "aspect_ratio_0_7_to_1_5": {  # 0.7 <= aspect_ratio <= 1.5
            "left": 0.04,
            "bottom": 0.08,
            "right_margin": 0.04,
            "right_element_width_colorbar": 0.10,
            "right_element_width_legend": 0.10,
            "width_formula": "1.0 - left - right_margin - right_element_width",
            "height": 0.82,
        },
        "aspect_ratio_0_5_to_0_7": {  # 0.5 <= aspect_ratio < 0.7
            "left": 0.04,
            "bottom": 0.08,
            "right_margin": 0.04,
            "right_element_width_colorbar": 0.10,
            "right_element_width_legend": 0.10,
            "width_formula": "1.0 - left - right_margin - right_element_width",
            "height": 0.80,
        },
        "aspect_ratio_0_5_minus": {  # aspect_ratio < 0.5
            "left": 0.04,
            "bottom": 0.10,
            "right_margin": 0.04,
            "right_element_width_colorbar": 0.10,
            "right_element_width_legend": 0.10,
            "width_formula": "1.0 - left - right_margin - right_element_width",
            "height": 0.75,
        },
    }

    # 无右侧元素时的布局策略表
    STRATEGIES_WITHOUT_RIGHT_ELEMENT = {
        "aspect_ratio_2_0_plus": {  # aspect_ratio > 2.0
            "left": 0.02,
            "bottom": 0.05,
            "width": 0.96,
            "height": 0.82,
        },
        "aspect_ratio_1_5_plus": {  # 1.5 < aspect_ratio <= 2.0
            "left": 0.02,
            "bottom": 0.06,
            "width": 0.96,
            "height": 0.84,
        },
        "aspect_ratio_0_7_to_1_5": {  # 0.7 <= aspect_ratio <= 1.5
            "left": 0.03,
            "bottom": 0.08,
            "width": 0.94,
            "height": 0.82,
        },
        "aspect_ratio_0_5_to_0_7": {  # 0.5 <= aspect_ratio < 0.7
            "left": 0.03,
            "bottom": 0.08,
            "width": 0.94,
            "height": 0.80,
        },
        "aspect_ratio_0_5_minus": {  # aspect_ratio < 0.5
            "left": 0.03,
            "bottom": 0.10,
            "width": 0.94,
            "height": 0.75,
        },
    }

    @staticmethod
    def get_layout_params(
        aspect_ratio: float,
        has_right_element: bool = False,
        right_element_type: str = "colorbar",
    ) -> Dict[str, float]:
        """根据纵横比查表获取布局参数。

        支持有/无右侧元素的两种模式，避免了 if-else 分支。

        Args:
            aspect_ratio: 纵横比（height / width）
            has_right_element: 是否有右侧元素（图例或 colorbar）
            right_element_type: 右侧元素类型，'colorbar' 或 'legend'

        Returns:
            Dict[str, float]: 布局参数字典，包含：
                - 'left': 绘图区域左边界
                - 'bottom': 绘图区域下边界
                - 'width': 绘图区域宽度
                - 'height': 绘图区域高度

        Examples:
            >>> params = LayoutStrategy.get_layout_params(2.5, has_right_element=True)
            >>> # 返回 aspect_ratio > 2.0 时的布局参数
        """
        # 选择策略表
        strategies = (
            LayoutStrategy.STRATEGIES_WITH_RIGHT_ELEMENT
            if has_right_element
            else LayoutStrategy.STRATEGIES_WITHOUT_RIGHT_ELEMENT
        )

        # 确定匹配的策略键
        strategy_key = LayoutStrategy._match_strategy_key(aspect_ratio)

        # 获取参数
        params = strategies[strategy_key].copy()

        # 如果是有右侧元素的情况，需要计算宽度
        if has_right_element:
            # 确定右侧元素宽度
            element_width_key = f"right_element_width_{right_element_type}"
            right_element_width = params.get(
                element_width_key, params.get("right_element_width_colorbar", 0.10)
            )

            # 计算宽度
            left = params["left"]
            right_margin = params["right_margin"]
            width = 1.0 - left - right_margin - right_element_width
            params["width"] = width

            # 删除不需要的中间计算参数
            params.pop("right_margin", None)
            params.pop("right_element_width_colorbar", None)
            params.pop("right_element_width_legend", None)
            params.pop("width_formula", None)

        return params

    @staticmethod
    def _match_strategy_key(aspect_ratio: float) -> str:
        """根据纵横比匹配策略键。

        按优先级检查纵横比范围，返回匹配的策略键。

        Args:
            aspect_ratio: 纵横比（height / width）

        Returns:
            str: 匹配的策略键
        """
        if aspect_ratio > 2.0:
            return "aspect_ratio_2_0_plus"
        elif aspect_ratio > 1.5:
            return "aspect_ratio_1_5_plus"
        elif aspect_ratio < 0.5:
            return "aspect_ratio_0_5_minus"
        elif aspect_ratio < 0.7:
            return "aspect_ratio_0_5_to_0_7"
        else:
            return "aspect_ratio_0_7_to_1_5"


class VisualizationLayout:
    """可视化布局管理类。

    根据图像尺寸动态计算 matplotlib 布局参数和字体大小。

    Examples:
        >>> layout = VisualizationLayout()
        >>> left, bottom, width, height, info = layout.calculate_dynamic_layout(1200, 800)
        >>> font_sizes = layout.calculate_adaptive_font_sizes(1200, 800)
    """

    @staticmethod
    def calculate_dynamic_layout(
        img_width: int,
        img_height: int,
        has_right_element: bool = False,
        font_size: int = 48,
        right_element_type: str = "colorbar",
    ) -> Tuple[float, float, float, float, Dict]:
        """根据图像尺寸动态计算布局参数。

        根据图像的宽高比和是否有右侧元素，计算最优的 matplotlib 布局参数。
        使用 LayoutStrategy 查表而非 if-else 分支。

        Args:
            img_width: 图像宽度（像素）
            img_height: 图像高度（像素）
            has_right_element: 是否有右侧元素（图例或 colorbar）
            font_size: 字体大小（影响所需边距）
            right_element_type: 右侧元素类型，'colorbar' 或 'legend'

        Returns:
            Tuple[float, float, float, float, Dict]:
                - left: 绘图区域左边界（相对位置，0-1）
                - bottom: 绘图区域下边界（相对位置，0-1）
                - width: 绘图区域宽度（相对宽度，0-1）
                - height: 绘图区域高度（相对高度，0-1）
                - layout_info: 布局配置信息字典

        Notes:
            - 布局会根据长宽比自动调整以确保最优显示
            - 有右侧元素时保持左右对称的留白
            - 所有参数都会进行合理性检查

        Examples:
            >>> layout = VisualizationLayout()
            >>> left, bottom, width, height, info = layout.calculate_dynamic_layout(1200, 800)
            >>> print(f"布局: left={left}, bottom={bottom}, width={width}, height={height}")
        """
        aspect_ratio = img_height / img_width

        # 布局配置信息
        layout_info = {"hide_axis": True}

        # 使用 LayoutStrategy 查表获取布局参数
        params = LayoutStrategy.get_layout_params(
            aspect_ratio=aspect_ratio,
            has_right_element=has_right_element,
            right_element_type=right_element_type,
        )

        left = params["left"]
        bottom = params["bottom"]
        width = params["width"]
        height = params["height"]

        # 确保布局参数在合理范围内
        left = max(left, 0.01)
        bottom = max(bottom, 0.04)
        width = max(width, 0.50)
        height = max(height, 0.60)

        # 确保总布局不会超出边界
        if left + width > 0.95:
            width = 0.95 - left
        if bottom + height > 0.88:
            height = 0.88 - bottom

        return left, bottom, width, height, layout_info

    @staticmethod
    def calculate_adaptive_font_sizes(
        img_width: int, img_height: int, base_font_size: int = 48
    ) -> Dict[str, int]:
        """根据图像尺寸计算自适应字体大小。

        根据图像面积计算适合该尺寸的各种文本元素的字体大小。

        Args:
            img_width: 图像宽度（像素）
            img_height: 图像高度（像素）
            base_font_size: 基础字体大小，默认 48

        Returns:
            Dict[str, int]: 各种文本元素的字体大小字典：
                - global: 全局默认字体大小
                - title: 标题字体大小
                - axis_label: 轴标签字体大小
                - tick_label: 刻度标签字体大小
                - colorbar_label: 颜色条标签字体大小
                - colorbar_tick: 颜色条刻度字体大小
                - legend: 图例字体大小

        Examples:
            >>> layout = VisualizationLayout()
            >>> fonts = layout.calculate_adaptive_font_sizes(1200, 800)
            >>> print(f"标题: {fonts['title']}px, 图例: {fonts['legend']}px")
        """
        # 计算图像面积相对于基准尺寸的比例
        base_area = 800 * 600  # 基准图像尺寸
        current_area = img_width * img_height
        size_factor = min(1.2, max(0.6, (current_area / base_area) ** 0.3))

        return {
            "global": int(base_font_size * size_factor),
            "title": int(base_font_size * size_factor * 0.9),
            "axis_label": int(base_font_size * size_factor),
            "tick_label": int(base_font_size * size_factor * 0.85),
            "colorbar_label": int(base_font_size * size_factor),
            "colorbar_tick": int(base_font_size * size_factor * 0.85),
            "legend": int(base_font_size * size_factor * 0.75),
        }

    @staticmethod
    def setup_axis_labels_and_ticks(
        main_ax, font_sizes: Dict[str, int], layout_info: Dict
    ) -> None:
        """隐藏坐标轴信息，只保留标题和图例。

        对 matplotlib 轴对象进行配置，隐藏所有坐标轴标签和刻度。

        Args:
            main_ax: matplotlib 轴对象
            font_sizes: 字体大小字典（由 calculate_adaptive_font_sizes 返回）
            layout_info: 布局配置信息字典（由 calculate_dynamic_layout 返回）

        Examples:
            >>> import matplotlib.pyplot as plt
            >>> fig, ax = plt.subplots()
            >>> layout = VisualizationLayout()
            >>> fonts = layout.calculate_adaptive_font_sizes(1200, 800)
            >>> info = {'hide_axis': True}
            >>> layout.setup_axis_labels_and_ticks(ax, fonts, info)
        """
        # 隐藏所有坐标轴标签和刻度
        main_ax.set_xlabel("")
        main_ax.set_ylabel("")

        # 隐藏刻度标签和刻度线
        main_ax.tick_params(
            axis="both",
            which="major",
            labelleft=False,
            labelbottom=False,
            left=False,
            bottom=False,
            top=False,
            right=False,
        )

        logger.debug("已隐藏坐标轴标签和刻度")
