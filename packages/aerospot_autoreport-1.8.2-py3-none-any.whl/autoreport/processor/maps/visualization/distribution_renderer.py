"""散点分布图渲染模块。

提供专用的散点分布图渲染功能。

Author: 水质建模团队
"""

import logging
from typing import TYPE_CHECKING, Any

import pandas as pd

from .base_renderer import RendererBase
from .render_session import RenderingSession

if TYPE_CHECKING:
    from .base_renderer import RenderingEnvironment

logger = logging.getLogger(__name__)


class DistributionRenderer(RendererBase):
    """散点分布图渲染器。

    专门用于渲染高光谱反演数据的散点分布图，支持定量和定性两种 colorbar 模式。

    Examples:
        >>> renderer = DistributionRenderer(satellite_info, geo_bounds, layout_manager)
        >>> map_path = renderer.render(data, "COD", save_path, ...)
    """

    def render(
        self,
        data: pd.DataFrame,
        indicator: str,
        save_path: str,
        session: RenderingSession,
    ) -> str:
        """渲染散点分布图。

        Args:
            data: 包含经纬度和指标数据的 DataFrame
            indicator: 指标名称
            save_path: 保存路径
            session: 渲染会话，包含共享的vmin、vmax、font_sizes等

        Returns:
            str: 保存的文件路径

        Note:
            使用模板方法模式，通过钩子方法实现散点图特定逻辑。
        """
        logger.debug(
            f"使用 session 参数：vmin={session.vmin:.3f}, vmax={session.vmax:.3f}, "
            f"colorbar_mode={session.colorbar_mode}"
        )

        # 调用模板方法，传递 data 给钩子方法
        return self._execute_template_render(
            indicator=indicator,
            save_path=save_path,
            session=session,
            has_right_element=True,
            right_element_type="colorbar",
            title_template="高光谱反演水质指标 {indicator} 散点图",
            data=data,  # 传递给钩子方法
        )

    def _draw_content(
        self,
        ax: Any,
        session: RenderingSession,
        env: "RenderingEnvironment",
        indicator: str,
        hook_context: dict,
        **kwargs: Any,
    ) -> None:
        """【钩子方法】绘制散点图。

        Args:
            ax: matplotlib Axes对象
            session: 渲染会话对象
            env: 渲染环境对象
            indicator: 指标名称
            hook_context: 钩子上下文字典，用于在钩子间传递数据
            **kwargs: 包含 data (DataFrame)
        """
        data = kwargs["data"]

        # 计算自适应散点大小
        adaptive_point_size = self._calculate_adaptive_point_size(len(data))

        # 绘制散点，使用共享的vmin/vmax
        scatter = ax.scatter(
            data["Longitude"],
            data["Latitude"],
            c=data[indicator],
            s=adaptive_point_size,
            cmap="jet",
            alpha=0.8,
            vmin=session.vmin,
            vmax=session.vmax,
        )

        # 保存 scatter 对象到上下文，供装饰方法使用
        hook_context["_scatter"] = scatter

    def _add_decorations(
        self,
        fig: Any,
        ax: Any,
        indicator: str,
        session: RenderingSession,
        env: "RenderingEnvironment",
        hook_context: dict,
        **kwargs: Any,
    ) -> None:
        """【钩子方法】添加 colorbar。

        Args:
            fig: matplotlib Figure对象
            ax: matplotlib Axes对象
            indicator: 指标名称
            session: 渲染会话对象
            env: 渲染环境对象
            hook_context: 钩子上下文字典，包含 _scatter (scatter对象)
        """
        scatter = hook_context.get("_scatter")
        if scatter is None:
            logger.warning(f"[{indicator}] 警告：scatter对象为None，无法添加colorbar")
            return

        logger.debug(
            f"[{indicator}] 开始创建colorbar，layout_params={env.layout_params}"
        )

        # 使用基类的统一colorbar创建方法
        cbar = self._create_and_configure_colorbar(
            fig=fig,
            mappable=scatter,
            indicator=indicator,
            colorbar_mode=session.colorbar_mode,
            font_sizes=session.font_sizes,
            left=env.layout_params[0] if env.layout_params else 0,
            width=env.layout_params[2] if env.layout_params else 0,
            bottom=env.layout_params[1] if env.layout_params else 0,
            height=env.layout_params[3] if env.layout_params else 0,
        )
        logger.debug(f"[{indicator}] colorbar创建成功：{cbar}")
