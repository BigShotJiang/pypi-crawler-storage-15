"""可视化和渲染模块。

包含布局管理、分级标准、地图渲染和工厂类。

导出的类和配置：
- VisualizationLayout: 布局管理器
- LayoutStrategy: 参数化布局策略
- GradeManager: 分级管理器
- MapRenderer: 地图渲染引擎（包装类）
- RendererFactory: 渲染器工厂
- INDICATOR_GRADE_CONFIG: 指标分级配置

专用渲染器（Phase 3 重构）：
- RendererBase: 所有渲染器的基类
- DistributionRenderer: 散点分布图渲染器
- InterpolationRenderer: 插值热力图渲染器
- LevelRenderer: 水质等级分布图渲染器
- BinaryNDVIRenderer: NDVI二值化藻华检测图渲染器
- LevelNDVIRenderer: NDVI分级藻华检测图渲染器

渲染会话接口（Phase 3.5 ISP 原则）：
- RenderingSession: 渲染会话数据容器
- ColorbarProvider: Colorbar 提供者接口
- FigureProvider: 图形创建提供者接口
- StyleProvider: 样式和布局提供者接口
"""

from .layout import VisualizationLayout, LayoutStrategy
from .grades import GradeManager, INDICATOR_GRADE_CONFIG
from .renderers import MapRenderer
from .renderer_factory import RendererFactory

# Phase 3 新增的专用渲染器类
from .base_renderer import RendererBase
from .distribution_renderer import DistributionRenderer
from .interpolation_renderer import InterpolationRenderer
from .level_renderer import LevelRenderer
from .binary_ndvi_renderer import BinaryNDVIRenderer
from .level_ndvi_renderer import LevelNDVIRenderer

# Phase 3.5 新增：渲染会话接口（ISP 原则）
from .render_session import (
    RenderingSession,
    ColorbarProvider,
    FigureProvider,
    StyleProvider,
)

__all__ = [
    "VisualizationLayout",
    "LayoutStrategy",
    "GradeManager",
    "MapRenderer",
    "RendererFactory",
    "INDICATOR_GRADE_CONFIG",
    # Phase 3 新增
    "RendererBase",
    "DistributionRenderer",
    "InterpolationRenderer",
    "LevelRenderer",
    # Phase 3.3 新增：分离后的NDVI渲染器
    "BinaryNDVIRenderer",
    "LevelNDVIRenderer",
    # Phase 3.5 新增：渲染会话接口
    "RenderingSession",
    "ColorbarProvider",
    "FigureProvider",
    "StyleProvider",
]
