"""图形资源上下文管理器模块。

提供安全的matplotlib figure和axes管理，确保资源在任何情况下都被正确清理。

Author: 水质建模团队
"""

import logging
from contextlib import contextmanager
from typing import Optional, Tuple, Any

import matplotlib.pyplot as plt

logger = logging.getLogger(__name__)


class FigureContext:
    """Figure和Axes的上下文管理器（资源清理保证）。

    确保在任何情况下（包括异常）都能正确清理matplotlib资源，
    防止内存泄漏。

    使用方式：
        >>> with FigureContext(figsize=(12, 8), dpi=100) as (fig, ax):
        ...     ax.plot([1, 2, 3], [1, 4, 9])
        ...     # 资源在with块结束时自动清理

    也可用作装饰器工厂：
        >>> @figure_context_manager(figsize=(12, 8))
        ... def my_plotting_function():
        ...     fig = plt.gcf()
        ...     ax = plt.gca()
        ...     # ... 绘图代码

    Attributes:
        figsize: 图形大小 (width, height)
        dpi: 分辨率
        frameon: 是否绘制边框
        fig: 创建的matplotlib Figure对象
        ax: 创建的matplotlib Axes对象
    """

    def __init__(
        self,
        figsize: Tuple[float, float] = (12, 8),
        dpi: float = 100,
        frameon: bool = True,
        layout_params: Optional[Tuple[float, float, float, float]] = None,
    ):
        """初始化FigureContext。

        Args:
            figsize: 图形大小 (width, height)，默认 (12, 8)
            dpi: 分辨率，默认 100
            frameon: 是否绘制图形边框，默认 True
            layout_params: 布局参数 (left, bottom, width, height)，可选
        """
        self.figsize = figsize
        self.dpi = dpi
        self.frameon = frameon
        self.layout_params = layout_params
        self.fig: Optional[Any] = None
        self.ax: Optional[Any] = None

    def __enter__(self) -> Tuple[Any, Any]:
        """进入上下文管理器，创建figure和axes。

        Returns:
            Tuple[fig, ax]: matplotlib Figure和Axes对象

        Raises:
            RuntimeError: 如果figure创建失败
        """
        try:
            self.fig = plt.figure(
                figsize=self.figsize, dpi=self.dpi, frameon=self.frameon
            )

            if self.layout_params is None:
                self.ax = self.fig.add_subplot(111)
            else:
                left, bottom, width, height = self.layout_params
                self.ax = self.fig.add_axes([left, bottom, width, height])

            logger.debug(
                f"FigureContext created: figsize={self.figsize}, dpi={self.dpi}"
            )
            return self.fig, self.ax

        except Exception as e:
            logger.error(f"Failed to create figure context: {e}")
            # 清理任何可能已创建的资源
            if self.fig is not None:
                plt.close(self.fig)
            raise RuntimeError(f"Failed to create figure: {e}") from e

    def __exit__(self, exc_type, exc_val, exc_tb) -> bool:
        """退出上下文管理器，清理figure和axes资源。

        这个方法确保在任何情况下（包括异常）都能正确清理资源。

        Args:
            exc_type: 异常类型（如果有的话）
            exc_val: 异常值（如果有的话）
            exc_tb: 异常回溯（如果有的话）

        Returns:
            bool: False（不抑制异常）
        """
        try:
            if self.fig is not None:
                plt.close(self.fig)
                logger.debug("Figure closed successfully")
            # 不调用 plt.clf() 和 plt.cla()，因为它们会清除figure内容
            # 导致colorbar、legend等在保存后被删除
        except Exception as e:
            logger.warning(f"Error during figure cleanup: {e}")
        finally:
            self.fig = None
            self.ax = None

        # 返回False表示不抑制异常（如果有的话）
        return False


@contextmanager
def managed_figure(
    figsize: Tuple[float, float] = (12, 8),
    dpi: float = 100,
    frameon: bool = True,
    layout_params: Optional[Tuple[float, float, float, float]] = None,
):
    """上下文管理器工厂函数（函数式API）。

    提供更灵活的figure管理方式。

    Args:
        figsize: 图形大小 (width, height)
        dpi: 分辨率
        frameon: 是否绘制边框
        layout_params: 布局参数 (left, bottom, width, height)

    Yields:
        Tuple[fig, ax]: matplotlib Figure和Axes对象

    Examples:
        >>> with managed_figure(figsize=(10, 6), dpi=100) as (fig, ax):
        ...     ax.plot([1, 2, 3], [1, 4, 9])
        ...     plt.savefig('plot.png', dpi=100, bbox_inches=None, pad_inches=0)
    """
    context = FigureContext(
        figsize=figsize,
        dpi=dpi,
        frameon=frameon,
        layout_params=layout_params,
    )
    fig, ax = context.__enter__()
    try:
        yield fig, ax
    except Exception as e:
        logger.error(f"Error in managed_figure context: {e}")
        raise
    finally:
        context.__exit__(None, None, None)
