"""Figure和Axes构建工具模块。

提供统一的matplotlib figure和axes创建接口，避免代码重复。

Author: 水质建模团队
"""

import logging
from typing import Optional, Tuple

import matplotlib.pyplot as plt

logger = logging.getLogger(__name__)


class FigureBuilder:
    """Figure和Axes构建器（工具类）。

    统一了所有渲染器中figure和axes的创建逻辑。
    使用静态方法提供无状态的工具函数。

    Examples:
        >>> fig, ax = FigureBuilder.create_figure(
        ...     figsize=(10, 8),
        ...     dpi=100,
        ...     layout_params=(0.04, 0.08, 0.82, 0.82)
        ... )
    """

    @staticmethod
    def create_figure(
        figsize: Tuple[float, float],
        dpi: float,
        layout_params: Optional[Tuple[float, float, float, float]] = None,
    ) -> Tuple[plt.Figure, plt.Axes]:
        """创建matplotlib figure和axes对象。

        根据提供的参数创建figure对象，然后根据layout_params创建axes对象。
        如果layout_params为None，则使用默认的单个subplot。

        这个方法统一了以下渲染器中的重复代码：
        - distribution_renderer.py:86-91
        - level_renderer.py:121-126
        - ndvi_renderer.py:109-114, 272-277

        Args:
            figsize: 图形大小 (width, height)，单位为英寸
            dpi: 图形分辨率（dots per inch）
            layout_params: 布局参数 (left, bottom, width, height)，所有值都是相对坐标
                           如果为None，使用默认单个subplot

        Returns:
            Tuple[plt.Figure, plt.Axes]: 创建的figure和axes对象

        Examples:
            # 使用布局参数（推荐用于有colorbar/legend的图形）
            >>> fig, ax = FigureBuilder.create_figure(
            ...     figsize=(12, 8),
            ...     dpi=100,
            ...     layout_params=(0.04, 0.08, 0.82, 0.82)
            ... )

            # 不使用布局参数（简单图形）
            >>> fig, ax = FigureBuilder.create_figure(
            ...     figsize=(12, 8),
            ...     dpi=100
            ... )
        """
        fig = plt.figure(figsize=figsize, dpi=dpi, frameon=True)

        if layout_params:
            left, bottom, width, height = layout_params
            ax = fig.add_axes([left, bottom, width, height])
            logger.debug(
                f"Figure已创建（自定义布局）: figsize={figsize}, dpi={dpi}, "
                f"layout=({left}, {bottom}, {width}, {height})"
            )
        else:
            ax = fig.add_subplot(111)
            logger.debug(f"Figure已创建（默认布局）: figsize={figsize}, dpi={dpi}")

        return fig, ax
