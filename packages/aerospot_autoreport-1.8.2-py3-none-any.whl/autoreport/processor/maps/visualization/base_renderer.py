"""地图渲染基类模块。

提供所有专用渲染器的基类，包含公共初始化和辅助方法，避免代码重复。

Author: 水质建模团队
"""

import logging
from abc import ABC
from dataclasses import dataclass
from typing import Optional, Tuple, Dict, Any, List

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import Normalize

from .layout import VisualizationLayout
from .grades import GradeManager
from .figure_context import FigureContext
from .render_session import RenderingSession
from .rendering_config import global_rendering_config
from .render_strategies import ColorbarStrategyFactory, LegendStrategyFactory
from ...data.utils import get_indicator_unit

logger = logging.getLogger(__name__)


@dataclass(frozen=False)
class RenderingEnvironment:
    """渲染环境上下文数据类（替代字典方式）。

    统一封装所有渲染器共享的环境参数，提供类型安全和 IDE 自动补全。

    Attributes:
        img_data: 卫星图像数据（2D 数组或 None）
        img_width: 卫星图宽度（像素）
        img_height: 卫星图高度（像素）
        figsize: 图形尺寸 (width, height) 元组
        dpi: 分辨率（DPI）
        font_sizes: 字体大小字典 {'title': int, 'label': int, ...}
        layout_params: 布局参数元组 (left, bottom, width, height) 或 None
        layout_info: 布局额外信息字典 {'hide_axis': bool, ...}

    Examples:
        >>> env = renderer._prepare_rendering_environment()
        >>> with FigureContext(figsize=env.figsize, dpi=env.dpi) as (fig, ax):
        ...     if env.img_data is not None:
        ...         ax.imshow(env.img_data, extent=[...])
    """

    # 卫星信息
    img_data: Optional[Any]
    img_width: Optional[int]
    img_height: Optional[int]

    # 图形参数
    figsize: Tuple[float, float]
    dpi: float
    font_sizes: Dict[str, Any]

    # 布局参数
    layout_params: Optional[Tuple[float, float, float, float]]
    layout_info: Dict[str, Any]


class RendererBase(ABC):
    """地图渲染基类。

    所有专用渲染器（Distribution, Interpolation, Level, SVG, NDVI）的基类。
    提供公共的初始化、字体配置、布局计算和辅助方法，避免代码重复。

    使用模板方法模式定义通用的渲染流程，子类通过实现钩子方法来定制特定的行为。

    Examples:
        >>> # 此类不直接使用，由子类继承
        >>> class CustomRenderer(RendererBase):
        ...     def _prepare_data(self, Z, **kwargs):
        ...         # 实现数据准备逻辑
        ...         return Z
        ...
        ...     def _draw_content(self, ax, data, **kwargs):
        ...         # 实现绘制逻辑
        ...         ax.imshow(data)
    """

    def __init__(
        self,
        satellite_info: Optional[Tuple] = None,
        geo_bounds: Optional[list] = None,
        layout_manager: Optional[VisualizationLayout] = None,
        grade_manager: Optional[GradeManager] = None,
        rendering_config: Optional[Any] = None,
    ):
        """初始化渲染基类。

        Args:
            satellite_info: 卫星信息 (width, height, img_data)
            geo_bounds: 地理边界 [min_lon, min_lat, max_lon, max_lat]
            layout_manager: 布局管理器实例
            grade_manager: 指标分级管理器（可选，若不提供则自动创建）
            rendering_config: 渲染配置对象（可选，若不提供则使用默认配置）
        """
        self.satellite_info = satellite_info
        self.geo_bounds = geo_bounds
        self.layout_manager = layout_manager or VisualizationLayout()
        self.grade_manager = grade_manager or GradeManager()
        
        # 使用传入的配置或默认配置
        from .rendering_config import global_rendering_config
        self.rendering_config = rendering_config or global_rendering_config

        logger.debug(f"RendererBase initialized for {self.__class__.__name__}")

    # ==================== 公共辅助方法 ====================

    def _setup_matplotlib_params(self, font_size: int = 48) -> None:
        """设置 Matplotlib 参数（字体、编码等）。

        Args:
            font_size: 全局字体大小，默认 48
        """
        plt.rcParams.update({"font.size": font_size})
        plt.rcParams["font.family"] = "SimHei"
        plt.rcParams["axes.unicode_minus"] = False

    def _extract_satellite_info(
        self,
    ) -> Tuple[Optional[int], Optional[int], Optional[Any]]:
        """提取卫星信息（宽度、高度、图像数据）。

        Returns:
            Tuple[width, height, img_data]
        """
        if self.satellite_info:
            return (
                self.satellite_info[0],
                self.satellite_info[1],
                self.satellite_info[2],
            )
        return None, None, None

    def _calculate_figure_params(
        self, img_width: Optional[int] = None, img_height: Optional[int] = None
    ) -> Tuple[Dict[str, Any], float, Tuple[float, float]]:
        """计算图形参数（字体大小、DPI、figsize）。

        Args:
            img_width: 卫星图宽度（像素）
            img_height: 卫星图高度（像素）

        Returns:
            Tuple[font_sizes, dpi, figsize]
        """
        dpi = float(self.rendering_config.DEFAULT_DPI)

        if img_width and img_height:
            font_sizes = self.layout_manager.calculate_adaptive_font_sizes(
                img_width, img_height
            )
            figsize = (img_width / dpi, img_height / dpi)
        else:
            font_sizes = self.layout_manager.calculate_adaptive_font_sizes(1200, 800)
            figsize = (12, 8)

        return font_sizes, dpi, figsize

    def _calculate_layout_params(
        self,
        img_width: Optional[int],
        img_height: Optional[int],
        has_right_element: bool = True,
        right_element_type: str = "colorbar",
    ) -> Tuple[float, float, float, float, Dict[str, Any]]:
        """计算动态布局参数。

        Args:
            img_width: 卫星图宽度
            img_height: 卫星图高度
            has_right_element: 是否有右侧元素
            right_element_type: 右侧元素类型（"colorbar" 或 "legend"）

        Returns:
            Tuple[left, bottom, width, height, layout_info]
        """
        if img_width and img_height:
            font_sizes = self.layout_manager.calculate_adaptive_font_sizes(
                img_width, img_height
            )
            left, bottom, width, height, layout_info = (
                self.layout_manager.calculate_dynamic_layout(
                    img_width,
                    img_height,
                    has_right_element=has_right_element,
                    font_size=font_sizes["global"],
                    right_element_type=right_element_type,
                )
            )
            return left, bottom, width, height, layout_info
        else:
            return (
                self.rendering_config.DEFAULT_LAYOUT_LEFT,
                self.rendering_config.DEFAULT_LAYOUT_BOTTOM,
                self.rendering_config.DEFAULT_LAYOUT_WIDTH,
                self.rendering_config.DEFAULT_LAYOUT_HEIGHT,
                {"hide_axis": True},
            )

    def _prepare_rendering_environment(
        self,
        has_right_element: bool = True,
        right_element_type: str = "colorbar",
    ) -> RenderingEnvironment:
        """统一的渲染环境准备（DRY 原则）。

        提取所有渲染器共享的环境准备逻辑，包括：
        - 提取卫星信息
        - 计算图形参数
        - 计算布局参数
        - 设置 matplotlib 参数

        Args:
            has_right_element: 是否有右侧元素（colorbar/legend）
            right_element_type: 右侧元素类型

        Returns:
            RenderingEnvironment: 渲染环境对象，包含所有渲染参数
                - img_data: 卫星图像数据
                - img_width: 卫星图宽度
                - img_height: 卫星图高度
                - figsize: 图形尺寸
                - dpi: DPI 值
                - font_sizes: 字体大小字典
                - layout_params: 布局参数元组 (left, bottom, width, height) 或 None
                - layout_info: 布局信息字典

        Examples:
            >>> env = self._prepare_rendering_environment()
            >>> with FigureContext(figsize=env.figsize, dpi=env.dpi,
            ...                    layout_params=env.layout_params) as (fig, ax):
            ...     # 使用 env.img_data 等进行渲染
        """
        # 1. 提取卫星信息
        img_width, img_height, img_data = self._extract_satellite_info()

        # 2. 计算图形参数
        font_sizes, dpi, figsize = self._calculate_figure_params(img_width, img_height)

        # 3. 计算布局参数
        if img_width and img_height:
            left, bottom, width, height, layout_info = self._calculate_layout_params(
                img_width,
                img_height,
                has_right_element=has_right_element,
                right_element_type=right_element_type,
            )
            layout_params = (left, bottom, width, height)
        else:
            # 使用默认值
            left = self.rendering_config.DEFAULT_LAYOUT_LEFT
            bottom = self.rendering_config.DEFAULT_LAYOUT_BOTTOM
            width = self.rendering_config.DEFAULT_LAYOUT_WIDTH
            height = self.rendering_config.DEFAULT_LAYOUT_HEIGHT
            layout_info = {"hide_axis": True}
            layout_params = None

        # 4. 设置 matplotlib 参数
        self._setup_matplotlib_params()

        # 返回渲染环境对象
        return RenderingEnvironment(
            img_data=img_data,
            img_width=img_width,
            img_height=img_height,
            figsize=figsize,
            dpi=dpi,
            font_sizes=font_sizes,
            layout_params=layout_params,
            layout_info=layout_info,
        )

    def _select_geo_bounds(
        self,
        all_points_outside: bool,
        satellite_geo_bounds: Optional[list],
        data_geo_bounds: Optional[list],
    ) -> Optional[list]:
        """根据点位置选择合适的地理边界。

        Args:
            all_points_outside: 是否所有点都在卫星图外
            satellite_geo_bounds: 卫星图地理边界
            data_geo_bounds: 数据地理边界

        Returns:
            选中的地理边界
        """
        if all_points_outside:
            return data_geo_bounds if data_geo_bounds is not None else self.geo_bounds
        else:
            return (
                satellite_geo_bounds
                if satellite_geo_bounds is not None
                else self.geo_bounds
            )

    def _draw_satellite_image(
        self,
        ax,
        img_data: Any,
        geo_bounds: Optional[list],
    ) -> None:
        """在坐标轴上绘制卫星图像。

        Args:
            ax: Matplotlib 坐标轴对象
            img_data: 卫星图像数据
            geo_bounds: 地理边界 [min_lon, min_lat, max_lon, max_lat]
        """
        if img_data is not None and geo_bounds is not None:
            ax.imshow(
                img_data,
                extent=[
                    geo_bounds[0],
                    geo_bounds[2],
                    geo_bounds[1],
                    geo_bounds[3],
                ],
                aspect="auto",
                origin="upper",
            )

    def _setup_axis_bounds_and_grid(self, ax, geo_bounds: Optional[list]) -> None:
        """设置坐标轴范围和网格线。

        Args:
            ax: Matplotlib 坐标轴对象
            geo_bounds: 地理边界
        """
        if geo_bounds is not None:
            ax.set_xlim(geo_bounds[0], geo_bounds[2])
            ax.set_ylim(geo_bounds[1], geo_bounds[3])
        ax.grid(True, linestyle="--", alpha=0.3)

    def _setup_axis_labels_and_ticks(
        self, ax, font_sizes: Dict[str, Any], layout_info: Dict[str, Any]
    ) -> None:
        """设置坐标轴标签和刻度（委托给布局管理器）。

        Args:
            ax: Matplotlib 坐标轴对象
            font_sizes: 字体大小字典
            layout_info: 布局信息字典
        """
        self.layout_manager.setup_axis_labels_and_ticks(ax, font_sizes, layout_info)

    def _create_figure_with_satellite(
        self,
        figsize: Tuple[float, float],
        dpi: float,
        img_data: Optional[Any],
        geo_bounds: Optional[list],
        layout_params: Optional[Tuple[float, float, float, float]] = None,
    ) -> Tuple[Any, Any]:
        """创建图形并绘制卫星背景（标准流程）。

        Args:
            figsize: 图形大小
            dpi: DPI 分辨率
            img_data: 卫星图像数据
            geo_bounds: 地理边界
            layout_params: 布局参数 (left, bottom, width, height)

        Returns:
            Tuple[fig, ax]
        """
        fig = plt.figure(figsize=figsize, dpi=dpi, frameon=True)

        if layout_params is None:
            ax = fig.add_subplot(111)
        else:
            left, bottom, width, height = layout_params
            ax = fig.add_axes([left, bottom, width, height])

        self._draw_satellite_image(ax, img_data, geo_bounds)
        self._setup_axis_bounds_and_grid(ax, geo_bounds)

        return fig, ax

    def _create_figure_with_gray_background(
        self, figsize: Tuple[float, float], dpi: float, geo_bounds: Optional[list]
    ) -> Tuple[Any, Any]:
        """创建图形并绘制灰色背景（点都在边界外时）。

        Args:
            figsize: 图形大小
            dpi: DPI 分辨率
            geo_bounds: 地理边界

        Returns:
            Tuple[fig, ax]
        """
        fig = plt.figure(figsize=figsize, dpi=dpi, frameon=True)
        ax = fig.add_subplot(111)

        if geo_bounds is not None:
            ax.add_patch(
                plt.Rectangle(
                    (geo_bounds[0], geo_bounds[1]),
                    geo_bounds[2] - geo_bounds[0],
                    geo_bounds[3] - geo_bounds[1],
                    facecolor="lightgray",
                )
            )

        self._setup_axis_bounds_and_grid(ax, geo_bounds)
        return fig, ax

    def _calculate_adaptive_point_size(self, num_points: int) -> int:
        """计算自适应散点大小（点数越多，点越小）。

        Args:
            num_points: 点的数量

        Returns:
            自适应点大小
        """
        point_size = 20
        adaptive_point_size = point_size * 10.0  # 基础值 200

        if num_points > 100:
            adaptive_point_size = max(
                60, int(point_size * 10.0 * 100 / num_points)
            )  # 最小值 60

        return adaptive_point_size

    def _normalize_values(self, values: np.ndarray) -> Tuple[float, float, Normalize]:
        """计算数值的归一化范围。

        Args:
            values: 数值数组

        Returns:
            Tuple[vmin, vmax, norm_object]
        """
        vmin, vmax = np.min(values), np.max(values)
        norm = Normalize(vmin=vmin, vmax=vmax)
        return vmin, vmax, norm

    def _save_figure(
        self,
        save_path: str,
        dpi: float,
        all_points_outside: bool,
        tight_layout: bool = False,
    ) -> None:
        """保存图形到文件。

        Args:
            save_path: 保存路径
            dpi: DPI 分辨率
            all_points_outside: 是否所有点在边界外
            tight_layout: 是否使用 tight_layout
        """
        if not all_points_outside:
            plt.savefig(save_path, dpi=dpi, bbox_inches=None, pad_inches=0)
        else:
            if tight_layout:
                plt.tight_layout()
            plt.savefig(save_path, dpi=300, bbox_inches="tight", pad_inches=0)

    # ==================== 渲染会话准备（新方法）====================

    def prepare_rendering_session(
        self,
        indicator: str,
        data: pd.DataFrame,
        satellite_geo_bounds: Optional[list],
        data_geo_bounds: Optional[list],
        all_points_outside: bool,
        colorbar_mode: str = "quantitative",
        has_colorbar: bool = True,
    ) -> RenderingSession:
        """准备完整的渲染会话（一步完成所有初始化）。

        这个方法整合了所有渲染器的共同初始化步骤，避免代码重复。
        计算结果存储在 RenderingSession 对象中，供所有渲染器共享使用。

        注意：布局参数（left, bottom, width, height）在每个渲染器中根据自己的需求计算。

        Args:
            indicator: 指标名称
            data: 包含指标数据的 DataFrame
            satellite_geo_bounds: 卫星图地理边界 [min_lon, min_lat, max_lon, max_lat]
            data_geo_bounds: 数据地理边界
            all_points_outside: 是否所有数据点都在卫星图外
            colorbar_mode: Colorbar 模式（"quantitative" 或 "qualitative"）
            has_colorbar: 保留参数以兼容性，但不再使用

        Returns:
            RenderingSession: 包含初始化参数的渲染会话对象

        Raises:
            ValueError: 当指标名称不在数据中时
            KeyError: 当数据缺少必要列时
        """
        logger.debug(f"准备渲染会话：指标={indicator}, mode={colorbar_mode}")

        # 步骤1：计算 colorbar 范围（所有渲染器共享）
        if indicator not in data.columns:
            raise ValueError(f"指标 '{indicator}' 不在数据中")

        values = data[indicator].values
        vmin = float(np.min(values))
        vmax = float(np.max(values))
        logger.debug(f"Colorbar 范围计算：vmin={vmin:.3f}, vmax={vmax:.3f}")

        # 步骤2：提取卫星信息
        img_width, img_height, img_data = self._extract_satellite_info()

        # 步骤3：计算图形参数
        font_sizes, dpi, figsize = self._calculate_figure_params(img_width, img_height)

        # 步骤4：选择地理边界
        geo_bounds = self._select_geo_bounds(
            all_points_outside, satellite_geo_bounds, data_geo_bounds
        )

        # 步骤5：设置 matplotlib 参数
        self._setup_matplotlib_params()

        # 步骤6：返回渲染会话
        # 注意：不在这里创建 fig/ax，每个渲染器根据自己的布局需求在 render() 中创建
        logger.debug("渲染会话准备完毕")
        return RenderingSession(
            vmin=vmin,
            vmax=vmax,
            colorbar_mode=colorbar_mode,
            fig=None,  # 每个渲染器自己创建
            ax=None,  # 每个渲染器自己创建
            dpi=dpi,
            figsize=figsize,
            font_sizes=font_sizes,
            geo_bounds=geo_bounds,
            layout_info={},  # 每个渲染器自己计算
        )

    def _create_and_configure_colorbar(
        self,
        fig: Any,
        mappable: Any,
        indicator: str,
        colorbar_mode: str,
        font_sizes: Dict[str, int],
        left: float,
        width: float,
        bottom: float,
        height: float,
    ) -> Any:
        """创建并配置colorbar（统一逻辑，使用策略模式）。

        这个方法统一了distribution_renderer和interpolation_renderer中的
        colorbar创建逻辑。使用手动axes创建方式避免自动压缩主axes的宽度。

        通过ColorbarStrategy实现不同模式的colorbar配置，避免硬编码的if/else分支。

        Args:
            fig: matplotlib Figure对象
            mappable: scatter或imshow对象（用于创建colorbar）
            indicator: 指标名称
            colorbar_mode: colorbar模式（'quantitative'或'qualitative'）
            font_sizes: 字体大小字典
            left: 主axes的左边界
            width: 主axes的宽度
            bottom: 主axes的下边界
            height: 主axes的高度

        Returns:
            matplotlib.colorbar.Colorbar: 配置好的colorbar对象

        Raises:
            ValueError: 当colorbar_mode不支持时
        """
        # 使用绝对坐标定位，避免自动压缩主axes
        cbar_left = left + width + self.rendering_config.COLORBAR_SPACING
        cbar_width = self.rendering_config.COLORBAR_WIDTH
        cbar_height = height

        cbar_ax = fig.add_axes([cbar_left, bottom, cbar_width, cbar_height])
        cbar = plt.colorbar(mappable, cax=cbar_ax, orientation="vertical")

        # 设置colorbar标签（通用，不依赖模式）
        unit = get_indicator_unit(indicator)
        if unit:
            label = f"{indicator} ({unit})"
        else:
            label = indicator

        cbar.set_label(
            label,
            fontsize=font_sizes.get(
                "colorbar_label", self.rendering_config.DEFAULT_COLORBAR_LABEL_FONT
            ),
        )

        # 设置刻度标签大小
        cbar.ax.tick_params(
            labelsize=font_sizes.get(
                "colorbar_tick", self.rendering_config.DEFAULT_COLORBAR_TICK_FONT
            )
        )

        # 使用策略模式处理模式特定的配置（定量/定性）
        try:
            strategy = ColorbarStrategyFactory.create(colorbar_mode)
            # 获取colorbar的min/max值用于配置
            vmin, vmax = cbar.mappable.get_clim()
            strategy.configure(cbar, vmin, vmax, indicator, font_sizes)
        except ValueError as e:
            logger.error(f"Colorbar策略创建失败: {e}")
            raise

        logger.debug(f"Colorbar已创建并配置：{indicator}, mode={colorbar_mode}")
        return cbar

    def _create_legend(
        self,
        ax: Any,
        patches: List[Any],
        font_sizes: Dict[str, int],
        legend_style: str = "default",
    ) -> None:
        """创建并配置图例（统一逻辑，使用策略模式）。

        这个方法统一了level_renderer和ndvi_renderer中的
        legend创建逻辑。使用策略模式支持不同的图例风格。

        通过LegendStrategy支持多种图例创建方式（default/inline），
        便于扩展而无需修改此方法。

        Args:
            ax: matplotlib Axes对象
            patches: mpatches.Patch对象列表
            font_sizes: 字体大小字典
            legend_style: 图例风格 ("default" 或 "inline")，默认 "default"

        Raises:
            ValueError: 当legend_style不支持时
        """
        try:
            strategy = LegendStrategyFactory.create(legend_style)
            strategy.create(ax, patches, font_sizes, self.rendering_config)
        except ValueError as e:
            logger.error(f"图例策略创建失败: {e}")
            raise

    # ==================== 模板方法模式框架 ====================

    def _prepare_data(self, **kwargs: Any) -> Dict[str, Any]:
        """【钩子方法】准备和转换数据（数据准备的钩子方法）。

        子类可以覆盖此方法来处理特定指标的数据准备逻辑。
        该方法应该返回一个字典，包含所有准备好的数据，这些数据将传递给 _draw_content。

        基础实现处理：
        - 确保 session 已创建（对于支持动态创建 session 的 Renderer）
        - 验证输入数据的有效性
        - 计算基本的数据参数

        子类应该调用 super()._prepare_data() 并在其上添加特定的数据准备逻辑。

        Args:
            **kwargs: 传入的参数，通常包括：
                - indicator: 指标名称
                - session: 渲染会话（可选，某些 Renderer 需要创建）
                - data: DataFrame（对于某些 Renderer）
                - Z: 插值网格（对于某些 Renderer）
                - 其他 Renderer 特定的参数

        Returns:
            Dict[str, Any]: 准备好的数据字典，包含所有需要传递给 _draw_content 的数据

        Examples:
            >>> # 子类实现示例
            >>> def _prepare_data(self, **kwargs):
            ...     env = super()._prepare_data(**kwargs)
            ...     # 添加特定的数据准备逻辑
            ...     env['processed_Z'] = custom_process(env['Z'])
            ...     return env
        """
        # 返回准备好的数据字典（包含输入参数和任何计算的值）
        return dict(kwargs)

    def _draw_content(
        self,
        ax: Any,
        session: RenderingSession,
        env: "RenderingEnvironment",
        indicator: str,
        hook_context: Dict[str, Any],
        **kwargs: Any,
    ) -> None:
        """【钩子方法】绘制主要内容到坐标轴。

        子类必须覆盖此方法来绘制特定类型的内容（散点图、热力图、分级图等）。
        默认实现：不绘制任何内容（用于向后兼容）

        Args:
            ax: matplotlib Axes对象
            session: 渲染会话对象（包含 vmin、vmax、colorbar_mode 等）
            env: 渲染环境对象（包含 img_data、layout_params 等）
            indicator: 指标名称
            hook_context: 钩子上下文字典，用于在钩子方法间传递数据
            **kwargs: 额外参数（如 data、Z、grid_lon、grid_lat 等）

        Note:
            该方法不应返回值，直接在 ax 上绘制内容。
            可以通过hook_context字典在钩子方法间传递数据，例如：
            hook_context['_scatter'] = scatter_object

        Examples:
            >>> def _draw_content(self, ax, session, env, indicator, hook_context, **kwargs):
            ...     data = kwargs['data']
            ...     scatter = ax.scatter(
            ...         data["Longitude"], data["Latitude"],
            ...         c=data[indicator], vmin=session.vmin, vmax=session.vmax
            ...     )
            ...     hook_context['_scatter'] = scatter  # 传递给下一个钩子
        """
        # 默认实现：不做任何操作
        pass

    def _add_decorations(
        self,
        fig: Any,
        ax: Any,
        indicator: str,
        session: RenderingSession,
        env: "RenderingEnvironment",
        hook_context: Dict[str, Any],
        **kwargs: Any,
    ) -> None:
        """【钩子方法】添加装饰元素（colorbar、legend等）。

        子类可以覆盖此方法来添加特定的装饰元素。
        默认实现不做任何操作。

        Args:
            fig: matplotlib Figure对象
            ax: matplotlib Axes对象
            indicator: 指标名称
            session: 渲染会话对象（包含 colorbar_mode、font_sizes 等）
            env: 渲染环境对象（包含 layout_params 等）
            **kwargs: 额外参数（如 mappable、patches 等）

        Note:
            该方法不应返回值，直接在 fig/ax 上添加装饰。

        Examples:
            >>> def _add_decorations(self, fig, ax, indicator, session, env, **kwargs):
            ...     mappable = kwargs.get('mappable')
            ...     if mappable:
            ...         self._create_and_configure_colorbar(
            ...             fig=fig, mappable=mappable, indicator=indicator,
            ...             colorbar_mode=session.colorbar_mode,
            ...             font_sizes=session.font_sizes,
            ...             left=env.layout_params[0], ...
            ...         )
        """
        # 默认实现：不做任何操作
        pass

    def _execute_template_render(
        self,
        indicator: str,
        save_path: str,
        session: RenderingSession,
        has_right_element: bool = True,
        right_element_type: str = "colorbar",
        title_template: str = "高光谱反演水质指标 {indicator}",
        all_points_outside: bool = False,
        **kwargs: Any,
    ) -> str:
        """【模板方法】通用渲染流程模板（适配现有渲染器）。

        定义标准的渲染流程，子类通过实现钩子方法来定制行为。
        此方法与现有渲染器的实际流程完全一致，确保无缝迁移。

        渲染流程：
        1. 日志记录开始
        2. 从 session 提取参数
        3. 准备渲染环境（_prepare_rendering_environment）
        4. 使用 FigureContext 创建图形
        5. 绘制背景（卫星图或灰色背景）
        6. 设置坐标轴范围和网格
        7. 【钩子】绘制主要内容（_draw_content）
        8. 【钩子】添加装饰元素（_add_decorations）
        9. 设置标题
        10. 设置坐标轴标签
        11. 保存图形
        12. 异常处理

        Args:
            indicator: 指标名称
            save_path: 保存路径
            session: 渲染会话对象（包含 vmin、vmax、figsize、dpi 等）
            has_right_element: 是否有右侧元素（colorbar/legend）
            right_element_type: 右侧元素类型（"colorbar" 或 "legend"）
            title_template: 标题模板，使用 {indicator} 占位符
            all_points_outside: 是否所有点都在边界外（影响背景和 DPI）
            **kwargs: 额外参数传递给钩子方法

        Returns:
            str: 保存的文件路径

        Raises:
            Exception: 渲染过程中的任何错误

        Examples:
            >>> # 子类调用示例
            >>> def render(self, data, indicator, save_path, session):
            ...     return self._execute_template_render(
            ...         indicator=indicator,
            ...         save_path=save_path,
            ...         session=session,
            ...         has_right_element=True,
            ...         right_element_type="colorbar",
            ...         data=data  # 传递给钩子方法
            ...     )
        """
        logger.info(f"开始渲染 {indicator} 图（模板方法）...")

        try:
            # 【新增】0. 调用数据准备钩子方法（允许子类自定义数据准备逻辑）
            # Phase 6: 提取公共数据准备逻辑
            prepared_data = self._prepare_data(
                indicator=indicator,
                session=session,
                **kwargs,
            )

            # 确保 prepared_data 是一个字典（防止 mock 返回 None）
            if prepared_data is None:
                prepared_data = dict(kwargs)

            # 1. 从 session 提取共享参数
            dpi = session.dpi
            font_sizes = session.font_sizes
            geo_bounds = session.geo_bounds

            # 当所有点在边界外时，使用高分辨率 DPI
            if all_points_outside:
                dpi = 300

            # 2. 准备渲染环境（卫星信息、布局、matplotlib设置）
            env = self._prepare_rendering_environment(
                has_right_element=has_right_element,
                right_element_type=right_element_type,
            )

            # 3. 使用 FigureContext 自动管理 figure 资源
            with FigureContext(
                figsize=env.figsize, dpi=env.dpi, layout_params=env.layout_params
            ) as (fig, ax):
                # 4. 绘制背景
                if all_points_outside:
                    # 绘制灰色背景（所有点都在边界外）
                    if geo_bounds is not None:
                        ax.add_patch(
                            plt.Rectangle(
                                (geo_bounds[0], geo_bounds[1]),
                                geo_bounds[2] - geo_bounds[0],
                                geo_bounds[3] - geo_bounds[1],
                                fill=True,
                                facecolor="gray",
                                edgecolor="black",
                                alpha=0.3,
                            )
                        )
                else:
                    # 绘制卫星底图（正常情况）
                    if env.img_data is not None and geo_bounds is not None:
                        ax.imshow(
                            env.img_data,
                            extent=[
                                geo_bounds[0],
                                geo_bounds[2],
                                geo_bounds[1],
                                geo_bounds[3],
                            ],
                            aspect="auto",
                            origin="upper",
                        )

                # 5. 设置坐标范围和网格
                self._setup_axis_bounds_and_grid(ax, geo_bounds)

                # 创建共享的钩子上下文字典（用于在钩子方法间传递数据）
                # 使用 prepared_data（已调用 _prepare_data() 处理过），但保留原始 kwargs 用于传递参数
                hook_context = dict(kwargs)

                # 6. 【钩子】绘制主要内容
                self._draw_content(
                    ax=ax,
                    session=session,
                    env=env,
                    indicator=indicator,
                    hook_context=hook_context,
                    **kwargs,
                )

                # 7. 【钩子】添加装饰元素（colorbar/legend）
                self._add_decorations(
                    fig=fig,
                    ax=ax,
                    indicator=indicator,
                    session=session,
                    env=env,
                    hook_context=hook_context,
                    **kwargs,
                )

                # 8. 设置标题
                title = title_template.format(indicator=indicator)
                ax.set_title(
                    title,
                    fontsize=font_sizes.get(
                        "title", self.rendering_config.DEFAULT_TITLE_FONT
                    ),
                    pad=self.rendering_config.TITLE_PAD,
                )

                # 9. 设置坐标轴标签
                self._setup_axis_labels_and_ticks(ax, font_sizes, env.layout_info)

                # 10. 保存图形
                self._save_figure(save_path, dpi, all_points_outside)

                logger.info(f"{indicator} 图已保存: {save_path}")
                return save_path

        except Exception as e:
            logger.error(f"生成 {indicator} 图失败: {str(e)}", exc_info=True)
            logger.error(f"[ERROR_CONTEXT] indicator: {indicator}")
            logger.error(
                f"[ERROR_CONTEXT] save_path: {save_path if 'save_path' in locals() else 'N/A'}"
            )
            logger.error(f"[ERROR_CONTEXT] 错误类型: {type(e).__name__}")
            raise

    def render_colorbar_standalone(
        self, indicator: str, save_path: str, session: "RenderingSession"
    ) -> Optional[str]:
        """生成独立的 colorbar 文件（heatmap_only 模式使用）

        使用 ColorbarBase 独立创建 colorbar，参考 waterqsvg 的最佳实践。
        支持处理边界情况（vmin==vmax）、定量/定性模式、透明背景等。

        Args:
            indicator: 指标名称
            save_path: colorbar 保存路径
            session: 渲染会话对象（包含 vmin, vmax, colorbar_mode）

        Returns:
            str: 保存的文件路径，或 None 如果失败

        Examples:
            >>> result = renderer.render_colorbar_standalone(
            ...     indicator="pH",
            ...     save_path="/path/to/ph_colorbar.png",
            ...     session=rendering_session
            ... )
        """
        try:
            from matplotlib.colorbar import ColorbarBase
            from matplotlib.colors import Normalize
            import numpy as np

            # 步骤1：获取 colorbar 范围和模式
            vmin = session.vmin
            vmax = session.vmax
            colorbar_mode = session.colorbar_mode

            logger.debug(
                f"开始生成独立 colorbar: indicator={indicator}, "
                f"range=[{vmin:.3f}, {vmax:.3f}], mode={colorbar_mode}"
            )

            # 步骤2：处理边界情况（vmin==vmax，如 NDVI 值都相同）
            if vmin == vmax:
                logger.warning(
                    f"指标 {indicator} 数值范围相同 ({vmin:.3f})，"
                    f"扩展10%范围以生成有效 colorbar"
                )
                if vmin == 0:
                    display_range = (0, 1)
                else:
                    delta = abs(vmin) * 0.1
                    display_range = (vmin - delta, vmax + delta)
            else:
                display_range = (vmin, vmax)

            # 步骤3：创建图形（适配尺寸和分辨率）
            figsize = (3, 15)  # waterqsvg 推荐的比例
            dpi = 150  # 高分辨率以支持缩放

            fig = plt.figure(figsize=figsize, dpi=dpi)
            ax = fig.add_subplot(111)

            # 步骤4：设置透明背景（便于嵌入到其他图形）
            fig.patch.set_alpha(0.0)
            ax.patch.set_alpha(0.0)

            # 步骤5：创建 Normalize 对象
            norm = Normalize(vmin=display_range[0], vmax=display_range[1])

            # 步骤6：使用 ColorbarBase 创建独立 colorbar（不依赖主图）
            cbar = ColorbarBase(
                ax,
                cmap=plt.cm.get_cmap("viridis"),
                norm=norm,
                orientation="vertical",
            )

            # 步骤7：根据模式配置刻度和标签
            if colorbar_mode == "qualitative":
                # 定性模式：只显示"低"和"高"
                cbar.set_ticks([display_range[0], display_range[1]])
                cbar.set_ticklabels(["低", "高"])
                logger.debug(
                    f"定性模式 colorbar: 低={display_range[0]:.3f}, 高={display_range[1]:.3f}"
                )
            else:
                # 定量模式：显示数值刻度（自动格式化）
                ticks = self._calculate_optimal_colorbar_ticks(
                    display_range[0], display_range[1]
                )
                cbar.set_ticks(ticks)

                # 格式化刻度标签
                tick_labels = [self._format_colorbar_tick_label(t) for t in ticks]
                cbar.set_ticklabels(tick_labels)
                logger.debug(
                    f"定量模式 colorbar: 范围=[{display_range[0]:.3f}, {display_range[1]:.3f}], "
                    f"刻度数={len(ticks)}"
                )

            # 步骤8：配置样式（参考 waterqsvg）
            unit = get_indicator_unit(indicator)
            label = f"{indicator} ({unit})" if unit else indicator

            cbar.set_label(label, fontsize=16, labelpad=10)

            # 设置刻度参数（颜色、大小等）
            cbar.ax.tick_params(
                labelsize=14,           # 刻度标签字体大小
                labelcolor="black",     # 刻度标签颜色（黑色便于打印和嵌入）
                width=2,                # 刻度线宽度
                length=8,               # 刻度线长度
                pad=8,                  # 标签与 colorbar 的间距
            )

            # 设置 colorbar 轮廓线宽度
            cbar.outline.set_linewidth(2)

            # 步骤9：设置中文字体
            plt.rcParams["font.family"] = "SimHei"
            plt.rcParams["axes.unicode_minus"] = False

            # 步骤10：调整布局
            plt.subplots_adjust(left=0.2, right=0.8, top=0.98, bottom=0.02)

            # 步骤11：保存图形
            fig.savefig(
                save_path,
                dpi=dpi,
                bbox_inches="tight",
                pad_inches=0.05,
                transparent=True,  # 使用透明背景
                facecolor="none",   # 明确设置透明
            )

            plt.close(fig)

            logger.info(f"独立 colorbar 已保存: {save_path} (模式={colorbar_mode})")
            return save_path

        except ValueError as e:
            # 捕获 Normalize 或其他值错误
            logger.error(
                f"生成 {indicator} colorbar 失败（值错误）: {str(e)}",
                exc_info=True,
            )
            return None

        except Exception as e:
            # 捕获其他所有异常
            logger.error(
                f"生成 {indicator} colorbar 失败: {str(e)}", exc_info=True
            )
            return None

    def _calculate_optimal_colorbar_ticks(
        self, vmin: float, vmax: float, max_ticks: int = 6
    ) -> list:
        """计算最优 colorbar 刻度位置（参考 waterqsvg）

        Args:
            vmin: 最小值
            vmax: 最大值
            max_ticks: 最大刻度数，默认 6

        Returns:
            list: 刻度位置列表
        """
        value_range = vmax - vmin

        # 根据数值范围选择合适的刻度数量
        if value_range < 1:
            n_ticks = 5
        elif value_range < 10:
            n_ticks = 5
        elif value_range < 100:
            n_ticks = 5
        else:
            n_ticks = 4

        n_ticks = min(n_ticks, max_ticks)

        # 生成均匀分布的刻度
        return np.linspace(vmin, vmax, n_ticks).tolist()

    def _format_colorbar_tick_label(self, value: float) -> str:
        """格式化 colorbar 刻度标签（参考 waterqsvg）

        规则：
        - 0.01 ≤ |value| < 1.0: 保留2位小数
        - 1.0 ≤ |value| < 100: 保留1位小数
        - |value| ≥ 100: 保留0位小数
        - 对于非常小的数使用科学计数法

        Args:
            value: 数值

        Returns:
            str: 格式化后的字符串
        """
        abs_value = abs(value)

        if abs_value == 0:
            return "0"
        elif abs_value < 0.01:
            # 科学计数法
            return f"{value:.1e}"
        elif abs_value < 1.0:
            # 2位小数
            return f"{value:.2f}"
        elif abs_value < 100:
            # 1位小数
            return f"{value:.1f}"
        else:
            # 整数
            return f"{value:.0f}"
