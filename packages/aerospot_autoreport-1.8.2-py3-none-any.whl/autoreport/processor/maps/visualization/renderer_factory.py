"""渲染器工厂模块。

提供工厂模式的渲染器管理，支持延迟初始化和实例缓存。
避免在循环中重复初始化相同的管理器，提高性能。

Author: 水质建模团队
"""

import logging
from typing import Any, Optional, Tuple

logger = logging.getLogger(__name__)


class RendererFactory:
    """渲染器工厂类。

    使用延迟初始化和缓存机制管理可视化相关的组件。
    在循环中首次访问时初始化，后续访问返回缓存实例，显著提升性能。

    特别适合在多次迭代中使用相同的渲染器配置的场景。

    Examples:
        >>> from src.autoreport.processor.maps.visualization.map_renderer import MapRenderer
        >>> from src.autoreport.processor.maps.visualization.layout import VisualizationLayout
        >>>
        >>> satellite_info = (1200, 800, None)
        >>> geo_bounds = [100, 20, 105, 25]
        >>>
        >>> # 工厂初始化：快速且无副作用
        >>> factory = RendererFactory(satellite_info, geo_bounds)
        >>>
        >>> # 首次访问：触发初始化
        >>> renderer = factory.get_renderer()
        >>>
        >>> # 后续访问：返回缓存
        >>> renderer2 = factory.get_renderer()
        >>> assert renderer is renderer2  # 同一实例
        >>>
        >>> # 在循环中：性能显著提升
        >>> for indicator in indicators:
        ...     renderer = factory.get_renderer()
        ...     layout = factory.layout_manager
        ...     # ... 生成地图
    """

    def __init__(
        self,
        satellite_info: Optional[Tuple] = None,
        geo_bounds: Optional[list] = None,
        config_service: Optional[Any] = None,
    ):
        """初始化渲染器工厂。

        不进行任何实际初始化（延迟初始化），仅保存配置参数。

        Args:
            satellite_info: 卫星信息元组 (width, height, img_data)
            geo_bounds: 地理边界 [lon_min, lat_min, lon_max, lat_max]
            config_service: ConfigurationService 实例（可选）
        """
        self._satellite_info = satellite_info
        self._geo_bounds = geo_bounds
        self._config_service = config_service

        # 延迟初始化属性：首次访问时创建，后续返回缓存
        self._layout_manager = None
        self._grade_manager = None
        self._renderer = None

        logger.debug("RendererFactory 已初始化（延迟模式）")

    @property
    def layout_manager(self):
        """获取 VisualizationLayout 实例（延迟初始化）。

        第一次访问时创建实例，后续访问返回缓存。

        Returns:
            VisualizationLayout: 可视化布局管理器实例
        """
        if self._layout_manager is None:
            logger.debug("首次访问: 初始化 VisualizationLayout")
            try:
                from .layout import VisualizationLayout

                self._layout_manager = VisualizationLayout()
            except ImportError as e:
                logger.error(f"无法导入 VisualizationLayout: {e}")
                raise

        return self._layout_manager

    @property
    def grade_manager(self):
        """获取 GradeManager 实例（延迟初始化）。

        第一次访问时创建实例，后续访问返回缓存。

        Returns:
            GradeManager: 等级管理器实例
        """
        if self._grade_manager is None:
            logger.debug("首次访问: 初始化 GradeManager")
            try:
                from .grades import GradeManager

                self._grade_manager = GradeManager(config_service=self._config_service)
            except ImportError as e:
                logger.error(f"无法导入 GradeManager: {e}")
                raise

        return self._grade_manager

    @property
    def renderer(self):
        """获取 MapRenderer 实例（延迟初始化）。

        第一次访问时创建实例（会触发 layout_manager 初始化），后续访问返回缓存。

        Returns:
            MapRenderer: 地图渲染器实例
        """
        if self._renderer is None:
            logger.debug("首次访问: 初始化 MapRenderer")
            try:
                from .renderers import MapRenderer

                self._renderer = MapRenderer(
                    satellite_info=self._satellite_info,
                    geo_bounds=self._geo_bounds,
                    layout_manager=self.layout_manager,  # 触发 layout_manager 初始化
                )
            except ImportError as e:
                logger.error(f"无法导入 MapRenderer: {e}")
                raise

        return self._renderer

    def get_renderer(self):
        """公共接口：获取渲染器实例。

        等价于访问 self.renderer 属性。
        提供显式的方法调用接口，可读性更好。

        Returns:
            MapRenderer: 地图渲染器实例（缓存）

        Examples:
            >>> factory = RendererFactory(satellite_info, geo_bounds)
            >>> renderer = factory.get_renderer()
        """
        return self.renderer

    def get_layout_manager(self):
        """公共接口：获取布局管理器实例。

        等价于访问 self.layout_manager 属性。

        Returns:
            VisualizationLayout: 布局管理器实例（缓存）
        """
        return self.layout_manager

    def get_grade_manager(self):
        """公共接口：获取等级管理器实例。

        等价于访问 self.grade_manager 属性。

        Returns:
            GradeManager: 等级管理器实例（缓存）
        """
        return self.grade_manager
