"""分级标准模块。

提供水质分级标准管理，遵循 GB 3838-2002 标准。

Author: 水质建模团队
"""

import logging
from typing import Any, Dict, Optional

# 从config统一导入INDICATOR_GRADE_CONFIG常量
from ....config.grades_config_models import INDICATOR_GRADE_CONFIG

logger = logging.getLogger(__name__)

# ==================== GB 3838-2002 国标分级映射表 ====================
# INDICATOR_GRADE_CONFIG 已在 config.grades_config_models 中统一定义
# 此处直接使用导入的常量，避免重复定义


class GradeManager:
    """分级管理类。

    管理水质指标的分级标准和颜色映射。

    Examples:
        >>> manager = GradeManager()
        >>> config = manager.get_grade_config("COD")
        >>> print(config['labels'])
    """

    def __init__(self, config_service: Optional[Any] = None) -> None:
        """初始化分级管理器。

        Args:
            config_service: ConfigurationService 实例（可选）
        """
        self.config_service = config_service

        # 优先从 ConfigurationService 获取水质等级配置
        if config_service is not None:
            water_quality_cfg = config_service.get_water_quality_grades_config()
            self.grades = self._convert_grades_config_to_dict(water_quality_cfg)
        else:
            # 否则使用默认硬编码配置
            self.grades = INDICATOR_GRADE_CONFIG

    @staticmethod
    def _convert_grades_config_to_dict(water_quality_cfg: Any) -> dict:
        """将 WaterQualityGradesConfig Pydantic 模型转换为字典格式。

        Args:
            water_quality_cfg: WaterQualityGradesConfig Pydantic 模型实例

        Returns:
            dict: 与旧配置格式兼容的字典
        """
        return water_quality_cfg.grades

    def get_grade_config(self, indicator: str) -> Optional[Dict]:
        """获取指标的国标分级配置。

        Args:
            indicator: 指标名称（如 'COD', 'NH3-N', 'DO' 等）

        Returns:
            Dict | None: 分级配置字典，包含以下键：
                - thresholds: 分级阈值列表
                - labels: 分级标签列表
                - colors: 分级颜色列表（十六进制）
                - reverse (可选): 是否反向分级（如 DO，越高越好）
                - description: 指标描述

            如果指标不存在则返回 None

        Examples:
            >>> config = manager.get_grade_config("COD")
            >>> if config:
            ...     print(f"指标: {config['description']}")
            ...     print(f"分级: {config['labels']}")
            ...     print(f"阈值: {config['thresholds']}")
        """
        if indicator in self.grades:
            logger.debug(f"获取指标 {indicator} 的分级配置")
            return self.grades[indicator]
        else:
            logger.warning(f"未找到指标 {indicator} 的分级配置")
            return None

    def get_color_for_value(self, indicator: str, value: float) -> Optional[str]:
        """根据指标值获取对应的颜色。

        Args:
            indicator: 指标名称
            value: 指标值

        Returns:
            str | None: 对应的颜色（十六进制格式），如 '#FF0000'

        Examples:
            >>> manager = GradeManager()
            >>> color = manager.get_color_for_value("COD", 25)
            >>> print(f"COD=25 的颜色: {color}")
        """
        config = self.get_grade_config(indicator)
        if not config:
            return None

        thresholds = config["thresholds"]
        colors = config["colors"]
        reverse = config.get("reverse", False)

        # 根据阈值确定分级
        if reverse:
            # 反向分级（如 DO，越高越好）
            for i, threshold in enumerate(thresholds):
                if value >= threshold:
                    # 找到最后一个满足条件的阈值
                    continue
                else:
                    return colors[i]
            # 所有阈值都满足，返回最高分级颜色
            return colors[-1]
        else:
            # 正常分级
            for i, threshold in enumerate(thresholds):
                if value <= threshold:
                    return colors[i]
            # 所有阈值都超过，返回最低分级颜色（劣五类）
            return colors[-1]

    def get_grade_label(self, indicator: str, value: float) -> Optional[str]:
        """根据指标值获取对应的分级标签。

        Args:
            indicator: 指标名称
            value: 指标值

        Returns:
            str | None: 对应的分级标签（如 'Ⅲ类'）

        Examples:
            >>> manager = GradeManager()
            >>> label = manager.get_grade_label("COD", 25)
            >>> print(f"COD=25 的分级: {label}")
        """
        config = self.get_grade_config(indicator)
        if not config:
            return None

        thresholds = config["thresholds"]
        labels = config["labels"]
        reverse = config.get("reverse", False)

        # 根据阈值确定分级
        if reverse:
            # 反向分级
            for i, threshold in enumerate(thresholds):
                if value >= threshold:
                    continue
                else:
                    return labels[i]
            return labels[-1]
        else:
            # 正常分级
            for i, threshold in enumerate(thresholds):
                if value <= threshold:
                    return labels[i]
            return labels[-1]

    def get_all_indicators(self) -> list:
        """获取所有支持的指标名称列表。

        Returns:
            list: 指标名称列表

        Examples:
            >>> manager = GradeManager()
            >>> indicators = manager.get_all_indicators()
            >>> print(f"支持的指标: {indicators}")
        """
        return list(self.grades.keys())

    def validate_indicator(self, indicator: str) -> bool:
        """验证指标是否在支持列表中。

        Args:
            indicator: 指标名称

        Returns:
            bool: 是否支持该指标

        Examples:
            >>> manager = GradeManager()
            >>> if manager.validate_indicator("COD"):
            ...     print("COD 是有效指标")
        """
        return indicator in self.grades
