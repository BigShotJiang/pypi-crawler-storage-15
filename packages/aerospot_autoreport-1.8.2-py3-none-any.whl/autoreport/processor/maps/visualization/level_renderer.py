"""水质等级分布图渲染模块。

提供专用的国标等级分布图渲染功能。

Author: 水质建模团队
"""

import logging
from typing import TYPE_CHECKING, Any

import matplotlib.patches as mpatches
import numpy as np
from matplotlib.colors import BoundaryNorm, ListedColormap

from .base_renderer import RendererBase
from .render_session import RenderingSession

if TYPE_CHECKING:
    from .base_renderer import RenderingEnvironment

logger = logging.getLogger(__name__)


class LevelRenderer(RendererBase):
    """水质等级分布图渲染器。

    专门用于渲染国标等级分布图（GB 3838-2002 水环境质量标准分级）。

    Examples:
        >>> renderer = LevelRenderer(satellite_info, geo_bounds, layout_manager)
        >>> map_path = renderer.render(Z, grid_lon, grid_lat, indicator, save_path, ...)
    """

    def _prepare_data(self, **kwargs: Any) -> Any:
        """【钩子方法】准备等级分布图的数据。

        处理等级分布图特定的数据准备逻辑：
        - 获取分级配置
        - 验证 Z 是否有效
        - 创建 Z 的副本以避免修改原数据
        - 处理反向分级（如溶解氧）
        - 执行分级处理

        Args:
            **kwargs: 包含以下参数：
                - indicator: 指标名称
                - Z: np.ndarray（插值结果）
                - 其他参数（会被保留在返回字典中）

        Returns:
            Dict[str, Any]: 准备好的数据字典，包含 grade_map、grade_labels、grade_colors
        """
        indicator = kwargs.get("indicator")
        Z = kwargs.get("Z")

        # 获取分级配置
        grade_config = self.grade_manager.get_grade_config(indicator)
        if not grade_config:
            logger.warning(f"未找到 {indicator} 的分级配置，返回空数据")
            return super()._prepare_data(**kwargs)

        if Z is None or Z.size == 0:
            logger.debug(
                f"{indicator} 的插值数据为空，使用基类处理方法"
            )
            return super()._prepare_data(**kwargs)

        # 获取分级信息
        grade_labels = grade_config["labels"]
        grade_thresholds = grade_config["thresholds"]
        grade_colors = grade_config["colors"]
        is_reverse = grade_config.get("reverse", False)

        # 创建插值数据的副本用于分级处理
        Z_processed = Z.copy()

        # 处理反向分级（如溶解氧，数值越高等级越好）
        if is_reverse:
            Z_processed = -Z_processed
            # 反转阈值、标签和颜色
            grade_thresholds = [-t for t in grade_thresholds[::-1]]
            grade_labels = grade_labels[::-1]
            grade_colors = grade_colors[::-1]

        # 执行分级
        grade_map = np.digitize(Z_processed, bins=grade_thresholds, right=True).astype(
            float
        )
        # digitize 返回 0~len(bins)，调整为 1~len(bins)+1 的类别编号
        grade_map = grade_map + 1

        # 保持 NaN 区域
        nan_mask = np.isnan(Z_processed)
        grade_map[nan_mask] = np.nan

        # 调用基类的 _prepare_data
        env = super()._prepare_data(**kwargs)

        # 添加等级分布图特定的数据
        env["grade_map"] = grade_map
        env["grade_labels"] = grade_labels
        env["grade_colors"] = grade_colors

        return env

    def render(
        self,
        Z: np.ndarray,
        grid_lon: np.ndarray,
        grid_lat: np.ndarray,
        indicator: str,
        save_path: str,
        session: RenderingSession,
    ) -> str:
        """渲染国标等级分布图。

        Args:
            Z: 插值结果网格
            grid_lon: 经度网格
            grid_lat: 纬度网格
            indicator: 指标名称
            save_path: 保存路径
            session: 渲染会话对象，包含所有共享参数

        Returns:
            str: 保存的文件路径

        Note:
            使用模板方法模式，通过钩子方法实现等级分布图特定逻辑。
        """
        # 获取分级配置
        grade_config = self.grade_manager.get_grade_config(indicator)
        if not grade_config:
            logger.warning(f"未找到 {indicator} 的分级配置，跳过水质等级图生成")
            return save_path

        if Z is None or Z.size == 0:
            logger.warning(
                f"{indicator} 的插值数据为空或无有效值，跳过等级图生成"
            )
            return save_path

        # 获取分级信息
        grade_labels = grade_config["labels"]
        grade_thresholds = grade_config["thresholds"]
        grade_colors = grade_config["colors"]
        is_reverse = grade_config.get("reverse", False)

        # 创建插值数据的副本用于分级处理
        Z_processed = Z.copy()

        # 处理反向分级（如溶解氧，数值越高等级越好）
        if is_reverse:
            Z_processed = -Z_processed
            # 反转阈值、标签和颜色
            grade_thresholds = [-t for t in grade_thresholds[::-1]]
            grade_labels = grade_labels[::-1]
            grade_colors = grade_colors[::-1]

        # 执行分级
        grade_map = np.digitize(Z_processed, bins=grade_thresholds, right=True).astype(
            float
        )
        # digitize 返回 0~len(bins)，调整为 1~len(bins)+1 的类别编号
        grade_map = grade_map + 1

        # 保持 NaN 区域
        nan_mask = np.isnan(Z_processed)
        grade_map[nan_mask] = np.nan

        # 调用模板方法，传递等级分布图特定数据
        return self._execute_template_render(
            indicator=indicator,
            save_path=save_path,
            session=session,
            has_right_element=True,
            right_element_type="legend",
            title_template="高光谱反演水质指标 {indicator} 国标等级分布图",
            all_points_outside=False,
            # 传递给钩子方法的等级分布图特定数据
            grade_map=grade_map,
            grade_labels=grade_labels,
            grade_colors=grade_colors,
            grid_lon=grid_lon,
            grid_lat=grid_lat,
        )

    def _draw_content(
        self,
        ax: Any,
        session: RenderingSession,
        env: "RenderingEnvironment",
        indicator: str,
        hook_context: dict,
        **kwargs: Any,
    ) -> None:
        """【钩子方法】绘制等级分布图。

        Args:
            ax: matplotlib Axes对象
            session: 渲染会话对象
            env: 渲染环境对象
            indicator: 指标名称
            hook_context: 钩子上下文字典，用于在钩子间传递数据
            **kwargs: 包含 grade_map、grade_labels、grade_colors
        """
        grade_map = kwargs["grade_map"]
        grade_labels = kwargs["grade_labels"]
        grade_colors = kwargs["grade_colors"]
        geo_bounds = session.geo_bounds

        # 创建分级颜色图
        cmap = ListedColormap(grade_colors)
        bounds = list(range(1, len(grade_labels) + 2))
        norm = BoundaryNorm(bounds, cmap.N)

        # 绘制等级图，使用 geo_bounds 而不是网格范围，确保与 distribution 图的可视化范围一致
        extent = [
            geo_bounds[0],
            geo_bounds[2],
            geo_bounds[1],
            geo_bounds[3],
        ]

        ax.imshow(
            grade_map,
            extent=extent,
            aspect="auto",
            origin="lower",
            cmap=cmap,
            norm=norm,
        )

        # 保存 patches 到共享上下文供装饰方法使用
        patches = [
            mpatches.Patch(color=grade_colors[i], label=grade_labels[i])
            for i in range(len(grade_labels))
        ]
        hook_context["_patches"] = patches

    def _add_decorations(
        self,
        fig: Any,
        ax: Any,
        indicator: str,
        session: RenderingSession,
        env: "RenderingEnvironment",
        hook_context: dict,
        **kwargs: Any,
    ) -> None:
        """【钩子方法】添加图例。

        Args:
            fig: matplotlib Figure对象
            ax: matplotlib Axes对象
            indicator: 指标名称
            session: 渲染会话对象
            env: 渲染环境对象
            hook_context: 钩子上下文字典，包含 _patches (图例补丁列表)
            **kwargs: 额外参数
        """
        patches = hook_context.get("_patches")
        if patches is None:
            return

        # 使用基类的统一图例创建方法
        self._create_legend(ax, patches, session.font_sizes)
