#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""独立的热力图生成器（Phase 1）

专为heatmap_only执行模式设计的热力图生成模块。
使用PreciseBoundaryCalculator和独立的ColorbarGenerator
实现clean_interpolation_svg和colorbar的生成。

参考：WaterQSVG项目架构
"""

import logging
import os
from typing import Any, Dict, Optional, Tuple

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from ...models.report_data import ReportData
from .colorbar_generator import ColorbarGenerator
from .core import InterpolationEngine
from .precise_boundary_calculator import PreciseBoundaryCalculator
from .visualization import MapRenderer, RenderingSession

logger = logging.getLogger(__name__)


class HeatmapGenerator:
    """独立的热力图生成器

    职责：
    - 独立生成clean_interpolation_svg热力图
    - 生成独立的colorbar文件
    - 为heatmap_only执行模式提供专用实现
    - 使用PreciseBoundaryCalculator精确计算边界
    - 使用ColorbarGenerator生成colorbar

    与MapGenerationOrchestrator的区别：
    - MapGenerationOrchestrator：为full_report模式生成多种地图类型
    - HeatmapGenerator：为heatmap_only模式专门生成clean_svg和colorbar

    使用场景：
    - heatmap_only执行模式
    - 与waterqsvg系统集成
    - 专注于大字体热力图可视化
    """

    def __init__(
        self,
        config_service: Any = None,
        path_manager: Any = None,
        boundary_manager: Optional[Any] = None,
        rendering_config: Optional[Any] = None,
    ) -> None:
        """初始化热力图生成器

        Args:
            config_service: 配置服务实例
            path_manager: 路径管理器实例
            boundary_manager: 边界管理器（可选）
            rendering_config: 渲染配置对象
        """
        self.config_service = config_service
        self.path_manager = path_manager
        self.boundary_manager = boundary_manager
        self.rendering_config = rendering_config
        self.logger = logger

        # 延迟初始化的组件
        self.interpolation_engine: Optional[InterpolationEngine] = None
        self.renderer: Optional[MapRenderer] = None
        self.colorbar_generator: Optional[ColorbarGenerator] = None
        self.boundary_calculator: Optional[PreciseBoundaryCalculator] = None

    def generate_heatmap(self, report_data: ReportData) -> ReportData:
        """为heatmap_only模式生成热力图

        执行顺序：
        1. 初始化所有必要的组件
        2. 提取数据和指标
        3. 对每个指标生成clean_svg和colorbar
        4. 保存路径到report_data

        Args:
            report_data: ReportData模型实例

        Returns:
            ReportData: 更新后的模型实例，包含maps字段
        """
        try:
            self.logger.info("=" * 60)
            self.logger.info("启动热力图生成流程（heatmap_only模式）")
            self.logger.info("=" * 60)

            # 初始化延迟加载的组件
            if self.interpolation_engine is None:
                self.interpolation_engine = InterpolationEngine(
                    config_service=self.config_service
                )
            if self.colorbar_generator is None:
                # 从rendering_config中获取参数
                dpi = 300
                colorbar_label_font = 12
                colorbar_tick_font = 10
                if self.rendering_config:
                    dpi = getattr(self.rendering_config, 'dpi', 300)
                    colorbar_label_font = getattr(self.rendering_config, 'colorbar_label_font', 12)
                    colorbar_tick_font = getattr(self.rendering_config, 'colorbar_tick_font', 10)

                self.colorbar_generator = ColorbarGenerator(
                    dpi=dpi,
                    colorbar_label_font=colorbar_label_font,
                    colorbar_tick_font=colorbar_tick_font,
                )
            if self.boundary_calculator is None:
                self.boundary_calculator = PreciseBoundaryCalculator(
                    boundary_manager=self.boundary_manager
                )

            # 提取数据
            data_to_process, indicator_columns = self._extract_data_to_process(
                report_data
            )
            if data_to_process is None or not indicator_columns:
                self.logger.info("无有效的数据用于热力图生成，跳过")
                return report_data

            # 计算地理边界
            geo_info = report_data.config.get("geo_info", {})
            try:
                geo_bounds = self._get_geo_bounds(geo_info, data_to_process)
                self.logger.info(f"地理边界: {geo_bounds}")
            except Exception as e:
                self.logger.error(f"计算地理边界失败: {str(e)}")
                return report_data

            # 获取可视化模式
            visualization_mode = (
                self.config_service.get_visualization_mode()
                if self.config_service
                else "quantitative"
            )

            # 生成热力图
            maps_paths: Dict[str, Dict[str, str]] = {}
            for indicator in indicator_columns:
                self.logger.info(f"处理指标: {indicator}")
                try:
                    # 计算colorbar范围
                    vmin, vmax = self._compute_colorbar_range(
                        data_to_process, indicator
                    )

                    # 执行插值
                    Z, grid_lon, grid_lat, mask, boundary = (
                        self._perform_interpolation(
                            data_to_process=data_to_process,
                            indicator=indicator,
                            geo_bounds=geo_bounds,
                        )
                    )

                    if Z is None:
                        self.logger.warning(f"{indicator} 插值失败，跳过")
                        continue

                    # 初始化该指标的地图路径字典
                    maps_paths[indicator] = {}

                    # 生成SVG热力图
                    svg_path = self._generate_svg_heatmap(
                        indicator=indicator,
                        Z=Z,
                        grid_lon=grid_lon,
                        grid_lat=grid_lat,
                        vmin=vmin,
                        vmax=vmax,
                        data=data_to_process,
                        mask=mask,
                    )
                    if svg_path:
                        maps_paths[indicator]["clean_interpolation_svg"] = svg_path
                        self.logger.info(f"✓ {indicator} SVG热力图生成成功: {svg_path}")

                    # 生成colorbar
                    colorbar_path = self._generate_colorbar(
                        indicator=indicator,
                        vmin=vmin,
                        vmax=vmax,
                        colorbar_mode=visualization_mode,
                    )
                    if colorbar_path:
                        maps_paths[indicator]["colorbar"] = colorbar_path
                        self.logger.info(f"✓ {indicator} colorbar生成成功: {colorbar_path}")

                    self.logger.info(f"✓ {indicator} 热力图生成完成")

                except Exception as e:
                    self.logger.error(f"处理 {indicator} 时出错: {str(e)}")

            # 保存地图路径
            report_data.maps = maps_paths
            self.logger.info(
                f"热力图生成完成，共生成 {len(maps_paths)} 个指标的热力图"
            )
            self.logger.info("=" * 60)

            return report_data

        except Exception as e:
            self.logger.exception(f"热力图生成异常: {e}")
            report_data.update_processing_state("failed", f"热力图生成失败: {str(e)}")
            return report_data

    def _extract_data_to_process(
        self, report_data: ReportData
    ) -> Tuple[Optional[pd.DataFrame], list]:
        """提取用于热力图生成的数据

        Args:
            report_data: ReportData模型实例

        Returns:
            Tuple: (data_to_process, indicator_columns)
        """
        try:
            # 获取所有可用数据源
            pred_data = report_data.config.get("all_pred_data")
            uav_data = report_data.uav_data.get("data") if report_data.uav_data else None

            # 确定使用哪个数据源
            if pred_data is not None and not pred_data.empty:
                data_to_process = pred_data
                self.logger.info(f"使用预测数据，包含 {len(pred_data)} 条记录")
            elif uav_data is not None and not uav_data.empty:
                data_to_process = uav_data
                self.logger.info(f"使用 UAV 反演数据，包含 {len(uav_data)} 条记录")
            else:
                self.logger.warning("无有效的数据源")
                return None, []

            # 提取指标列表
            indicator_columns = [
                col
                for col in data_to_process.columns
                if col not in ["Longitude", "Latitude", "index"]
            ]

            if not indicator_columns:
                self.logger.warning("未找到有效的指标列")
                return None, []

            return data_to_process, indicator_columns

        except Exception as e:
            self.logger.error(f"提取数据失败: {str(e)}")
            return None, []

    def _get_geo_bounds(
        self, geo_info: Dict[str, Any], data: pd.DataFrame
    ) -> Tuple[float, float, float, float]:
        """获取地理边界

        Args:
            geo_info: 地理信息字典
            data: 数据DataFrame

        Returns:
            Tuple: (min_lon, min_lat, max_lon, max_lat)
        """
        # TODO: 使用PreciseBoundaryCalculator
        try:
            data_geo_bounds = (
                float(data["Longitude"].min()),
                float(data["Latitude"].min()),
                float(data["Longitude"].max()),
                float(data["Latitude"].max()),
            )
            return data_geo_bounds
        except Exception as e:
            self.logger.error(f"计算数据边界失败: {str(e)}")
            raise

    def _compute_colorbar_range(
        self, data: pd.DataFrame, indicator: str
    ) -> Tuple[float, float]:
        """计算colorbar范围

        Args:
            data: 数据DataFrame
            indicator: 指标名称

        Returns:
            Tuple: (vmin, vmax)
        """
        original_values = data[indicator].values
        original_values_clean = original_values[np.isfinite(original_values)]

        if len(original_values_clean) == 0:
            self.logger.warning(f"{indicator} 没有有效的数据值")
            return 0.0, 1.0

        vmin = float(np.min(original_values_clean))
        vmax = float(np.max(original_values_clean))
        self.logger.info(f"{indicator} colorbar范围: [{vmin:.3f}, {vmax:.3f}]")
        return vmin, vmax

    def _perform_interpolation(
        self,
        data_to_process: pd.DataFrame,
        indicator: str,
        geo_bounds: Tuple[float, float, float, float],
    ) -> Tuple[
        Optional[np.ndarray],
        Optional[np.ndarray],
        Optional[np.ndarray],
        Optional[np.ndarray],
        Optional[np.ndarray],
    ]:
        """执行Kriging插值

        🔧 核心优化：确定interpolation的fixed_bounds范围

        根据原始maps.py（commit 8828458）的设计：
        - interpolation阶段需要使用较大的边界范围（固定边界）
        - 这样Z的网格范围就被限制在该边界内
        - 后续SVG渲染就不会出现边界截断问题

        优先级：
        1. 如果有KML边界 → 使用KML范围（确保包含完整KML定义区域）
        2. 否则 → 使用原始数据范围（geo_bounds）

        Args:
            data_to_process: 待插值数据
            indicator: 指标名称
            geo_bounds: 地理边界（数据范围）

        Returns:
            Tuple: (Z, grid_lon, grid_lat, mask, boundary)
        """
        try:
            boundary_method = (
                "kml"
                if self.boundary_manager and self.boundary_manager.is_enabled
                else "alpha_shape"
            )

            # 🔧 优化：确定interpolation的fixed_bounds
            interpolation_bounds = geo_bounds

            if self.boundary_manager and self.boundary_manager.is_enabled:
                # 使用KML边界范围作为fixed_bounds
                stats = self.boundary_manager.get_statistics()
                if stats.get("bounds"):
                    kml_bounds = stats["bounds"]  # (min_lon, min_lat, max_lon, max_lat)
                    interpolation_bounds = kml_bounds
                    self.logger.debug(
                        f"{indicator} 使用KML边界范围作为interpolation的fixed_bounds: "
                        f"lon({kml_bounds[0]:.6f}, {kml_bounds[2]:.6f}), "
                        f"lat({kml_bounds[1]:.6f}, {kml_bounds[3]:.6f})"
                    )
            else:
                self.logger.debug(
                    f"{indicator} 使用数据范围作为interpolation的fixed_bounds: "
                    f"lon({geo_bounds[0]:.6f}, {geo_bounds[2]:.6f}), "
                    f"lat({geo_bounds[1]:.6f}, {geo_bounds[3]:.6f})"
                )

            Z, grid_lon, grid_lat, mask, boundary = (
                self.interpolation_engine.enhanced_interpolate(
                    all_data=data_to_process,
                    indicator_col=indicator,
                    fixed_bounds=interpolation_bounds,  # 使用优化后的边界
                    boundary_manager=self.boundary_manager,
                    boundary_method=boundary_method,
                )
            )

            self.logger.info(f"{indicator} 插值完成，网格大小: {Z.shape if Z is not None else 'None'}")
            return Z, grid_lon, grid_lat, mask, boundary

        except Exception as e:
            self.logger.error(f"{indicator} 插值失败: {str(e)}")
            return None, None, None, None, None


    def _save_analysis_image(
        self,
        indicator: str,
        Z: np.ndarray,
        grid_lon: np.ndarray,
        grid_lat: np.ndarray,
        vmin: float,
        vmax: float,
        stage: str,
        figsize: Tuple[float, float] = (10, 8),
        dpi: int = 300,
        cmap: str = 'jet',
        interpolation: str = 'bilinear',
        use_contourf: bool = False,  # 支持两种渲染方式
    ) -> str:
        """保存分析阶段的热力图图像

        Args:
            indicator: 指标名称
            Z: 插值结果网格
            grid_lon: 经度网格
            grid_lat: 纬度网格
            vmin: 最小值
            vmax: 最大值
            stage: 分析阶段名称（用于文件名）
            figsize: 图形大小
            dpi: 分辨率
            cmap: 颜色映射
            interpolation: 图像插值方法
            use_contourf: 是否使用contourf渲染

        Returns:
            str: 保存的文件路径
        """
        # 准备输出路径
        maps_path = self.path_manager.get_path("maps")
        analysis_path = os.path.join(maps_path, "analysis")
        os.makedirs(analysis_path, exist_ok=True)
        
        # 清晰的命名规范：{indicator}_analysis_{stage}.png
        file_path = os.path.join(
            analysis_path,
            f"{indicator}_analysis_{stage}.png"
        )
        
        # 创建图形
        fig, ax = plt.subplots(figsize=figsize, dpi=dpi)
        
        # 设置透明背景
        fig.patch.set_alpha(0.0)
        ax.patch.set_alpha(0.0)
        
        try:
            # 计算显示范围
            extent = [
                float(grid_lon.min()), 
                float(grid_lon.max()),
                float(grid_lat.min()), 
                float(grid_lat.max())
            ]
            
            if use_contourf:
                # 使用contourf渲染
                im = ax.contourf(
                    grid_lon, grid_lat, Z,
                    levels=20,
                    cmap=cmap,
                    vmin=vmin,
                    vmax=vmax,
                    extend='both'
                )
            else:
                # 使用imshow渲染
                im = ax.imshow(
                    Z,
                    extent=extent,
                    aspect='auto',
                    origin='lower',
                    cmap=cmap,
                    vmin=vmin,
                    vmax=vmax,
                    interpolation=interpolation
                )
            
            # 隐藏所有坐标轴元素
            ax.axis('off')
            
            # 移除白色边框
            for spine in ax.spines.values():
                spine.set_visible(False)
            
            # 调整纵横比
            x_range = extent[1] - extent[0]
            y_range = extent[3] - extent[2]
            if x_range > 0 and y_range > 0:
                center_y = (extent[2] + extent[3]) / 2
                aspect_ratio = 1 / np.cos(np.deg2rad(center_y))
                ax.set_aspect(aspect_ratio, adjustable='box')
            
            # 添加阶段标签（仅用于分析）
            ax.text(
                0.5, 0.01,
                f"Stage: {stage}",
                horizontalalignment='center',
                verticalalignment='bottom',
                transform=ax.transAxes,
                color='white',
                fontsize=12,
                bbox=dict(facecolor='black', alpha=0.5, pad=5)
            )
            
            # 保存图像
            fig.savefig(
                file_path,
                format='png',
                bbox_inches='tight',
                pad_inches=0,
                dpi=dpi,
                transparent=True,
                facecolor='none',
                edgecolor='none'
            )
            
            self.logger.info(f"✓ 分析图像已保存: {file_path}")
            return file_path
            
        finally:
            plt.close(fig)

    def _generate_svg_heatmap(
        self,
        indicator: str,
        Z: np.ndarray,
        grid_lon: np.ndarray,
        grid_lat: np.ndarray,
        vmin: float,
        vmax: float,
        data: pd.DataFrame,
        mask: Optional[np.ndarray] = None,
    ) -> Optional[str]:
        """生成纯粹热力图PNG（无坐标轴、标题等，严格遵循waterqsvg实现）

        纯粹热力图特点：
        - 仅包含imshow填充区域
        - 无坐标轴、刻度、标签、标题
        - 无内置colorbar（colorbar单独生成）
        - PNG格式输出
        - 与waterqsvg兼容的dpi和figsize

        🔧 核心改进（基于原始maps.py设计）：
        - 在interpolation阶段使用fixed_bounds约束Z的网格范围
        - extent直接从grid_lon/grid_lat的min/max计算
        - 确保Z的整个网格都被显示，不会因为NaN值导致截断

        Args:
            indicator: 指标名称
            Z: 插值结果网格（可含NaN值，代表无效区域）
            grid_lon: 经度网格（范围已被fixed_bounds约束）
            grid_lat: 纬度网格（范围已被fixed_bounds约束）
            vmin: 最小值
            vmax: 最大值
            data: 原始数据
            mask: 边界掩码（仅用于调试分析）

        Returns:
            Optional[str]: 生成的PNG文件路径
        """
        try:
            # 准备输出路径（PNG格式）
            png_path = os.path.join(
                self.path_manager.get_path("maps"),
                f"{indicator}_heatmap.png"
            )

            # 获取配置参数
            figsize = (10, 8)  # 默认大小
            dpi = 300  # waterqsvg标准dpi
            if self.rendering_config:
                figsize = getattr(self.rendering_config, 'figsize', (10, 8))
                dpi = getattr(self.rendering_config, 'dpi', 300)

            # 创建图形（无边距的纯粹热力图）
            fig, ax = plt.subplots(figsize=figsize, dpi=dpi)

            # 设置透明背景
            fig.patch.set_alpha(0.0)
            ax.patch.set_alpha(0.0)

            try:
                # 🔧 核心改进：基于Z的实际有效数据范围确定extent
                # 与full模式的map_generation_orchestrator保持完全一致
                # 从有效数据中提取extent（高精度）
                valid_mask = ~np.isnan(Z)

                if np.any(valid_mask):
                    # 获取有效数据点对应的坐标（保持完整精度）
                    valid_lons = grid_lon[valid_mask]
                    valid_lats = grid_lat[valid_mask]

                    # 从有效数据中提取extent（与full模式完全一致）
                    extent = [
                        float(np.min(valid_lons)),
                        float(np.max(valid_lons)),
                        float(np.min(valid_lats)),
                        float(np.max(valid_lats))
                    ]

                    valid_count = np.sum(valid_mask)
                    self.logger.info(
                        f"{indicator} extent based on Z valid data (full_report consistent): "
                        f"lon({extent[0]:.17f}, {extent[1]:.17f}), "
                        f"lat({extent[2]:.17f}, {extent[3]:.17f}), "
                        f"valid_pixels={valid_count}"
                    )
                else:
                    # Z全为NaN（罕见），回退到网格坐标
                    extent = [
                        float(grid_lon.min()),
                        float(grid_lon.max()),
                        float(grid_lat.min()),
                        float(grid_lat.max())
                    ]
                    self.logger.warning(
                        f"{indicator} Z contains no valid values, "
                        f"falling back to grid coordinates"
                    )

                # 绘制imshow热力图（纯粹填充，无坐标轴）
                im = ax.imshow(
                    Z,
                    extent=extent,
                    aspect='auto',
                    origin='lower',
                    cmap='jet',
                    vmin=vmin,
                    vmax=vmax,
                    interpolation='bilinear'
                )

                # 隐藏所有坐标轴元素（严格遵循waterqsvg）
                ax.axis('off')

                # 移除白色边框
                for spine in ax.spines.values():
                    spine.set_visible(False)

                # 调整纵横比（考虑地球曲率）
                x_range = extent[1] - extent[0]
                y_range = extent[3] - extent[2]
                if x_range > 0 and y_range > 0:
                    center_y = (extent[2] + extent[3]) / 2
                    aspect_ratio = 1 / np.cos(np.deg2rad(center_y))
                    ax.set_aspect(aspect_ratio, adjustable='box')

                # 保存为PNG
                fig.savefig(
                    png_path,
                    format='png',
                    bbox_inches='tight',
                    pad_inches=0,
                    dpi=dpi,
                    transparent=True,
                    facecolor='none',
                    edgecolor='none'
                )
                self.logger.info(f"✓ 纯粹热力图已保存: {png_path}")

                return png_path

            finally:
                plt.close(fig)

        except Exception as e:
            self.logger.error(f"生成热力图失败: {str(e)}")
            return None

    def _generate_colorbar(
        self,
        indicator: str,
        vmin: float,
        vmax: float,
        colorbar_mode: str = "quantitative",
    ) -> Optional[str]:
        """生成独立的colorbar文件

        Args:
            indicator: 指标名称
            vmin: 最小值
            vmax: 最大值
            colorbar_mode: colorbar模式 ("quantitative" 或 "qualitative")

        Returns:
            Optional[str]: 生成的colorbar文件路径
        """
        try:
            colorbar_path = os.path.join(
                self.path_manager.get_path("maps"),
                f"{indicator}_colorbar.png"
            )

            result = self.colorbar_generator.generate(
                vmin=vmin,
                vmax=vmax,
                indicator=indicator,
                save_path=colorbar_path,
                colorbar_mode=colorbar_mode,
            )

            if result:
                self.logger.info(f"colorbar已保存: {colorbar_path}")
                return colorbar_path
            else:
                self.logger.warning(f"生成colorbar失败，保存路径: {colorbar_path}")
                return None

        except Exception as e:
            self.logger.error(f"生成colorbar失败: {str(e)}")
            return None

