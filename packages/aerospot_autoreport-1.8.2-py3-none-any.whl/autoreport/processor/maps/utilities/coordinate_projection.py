"""地理坐标转换工具模块。

提供经纬度坐标与图像坐标之间的转换功能。

Author: 水质建模团队
"""

import logging
from typing import List, Tuple

import pandas as pd

logger = logging.getLogger(__name__)


class GeoUtilities:
    """地理坐标转换工具类。

    提供经纬度坐标与图像坐标之间的转换，以及边界解析功能。

    Examples:
        >>> import pandas as pd
        >>> data = pd.DataFrame({
        ...     'Longitude': [120.0, 120.1, 120.2],
        ...     'Latitude': [30.0, 30.1, 30.2]
        ... })
        >>> bounds = GeoUtilities.get_data_bounds(data)
        >>> print(bounds)
    """

    @staticmethod
    def get_data_bounds(data: pd.DataFrame) -> List[float]:
        """获取数据的地理边界坐标。

        从 DataFrame 中提取所有数据点的地理范围，并添加 5% 的余量。

        Args:
            data: 包含 'Longitude' 和 'Latitude' 列的 DataFrame

        Returns:
            List[float]: 地理边界坐标 [min_lon, min_lat, max_lon, max_lat]

        Examples:
            >>> data = pd.DataFrame({
            ...     'Longitude': [120.0, 120.1, 120.2],
            ...     'Latitude': [30.0, 30.1, 30.2]
            ... })
            >>> bounds = GeoUtilities.get_data_bounds(data)
            >>> assert len(bounds) == 4
        """
        min_lon = data["Longitude"].min()
        max_lon = data["Longitude"].max()
        min_lat = data["Latitude"].min()
        max_lat = data["Latitude"].max()

        # 为边界添加一些余量
        lon_margin = (max_lon - min_lon) * 0.05
        lat_margin = (max_lat - min_lat) * 0.05

        geo_bounds = [
            min_lon - lon_margin,
            min_lat - lat_margin,
            max_lon + lon_margin,
            max_lat + lat_margin,
        ]

        logger.info(
            f"数据地理边界: 经度 {geo_bounds[0]:.6f} - {geo_bounds[2]:.6f}, "
            f"纬度 {geo_bounds[1]:.6f} - {geo_bounds[3]:.6f}"
        )

        return geo_bounds

    @staticmethod
    def to_image_coords(
        lat: float,
        lon: float,
        image_width: int,
        image_height: int,
        geo_bounds: List[float],
    ) -> Tuple[int, int, bool]:
        """将经纬度坐标转换为图像坐标。

        Args:
            lat: 纬度
            lon: 经度
            image_width: 图像宽度（像素）
            image_height: 图像高度（像素）
            geo_bounds: 图像边界经纬度 [min_lon, min_lat, max_lon, max_lat]

        Returns:
            Tuple[int, int, bool]:
                - x: 图像上的 x 坐标（像素）
                - y: 图像上的 y 坐标（像素）
                - is_inside: 是否在图像范围内

        Examples:
            >>> x, y, inside = GeoUtilities.to_image_coords(
            ...     lat=30.0, lon=120.0,
            ...     image_width=1200, image_height=800,
            ...     geo_bounds=[119.9, 29.9, 120.1, 30.1]
            ... )
            >>> print(x, y, inside)
        """
        min_lon, min_lat, max_lon, max_lat = [
            geo_bounds[0],  # min_lon
            geo_bounds[1],  # min_lat
            geo_bounds[2],  # max_lon
            geo_bounds[3],  # max_lat
        ]

        # 检查点是否在地理边界内（添加小的容差来处理浮点数精度问题）
        tolerance = 1e-6  # 约0.1米的容差
        is_inside = (min_lon - tolerance <= lon <= max_lon + tolerance) and (
            min_lat - tolerance <= lat <= max_lat + tolerance
        )

        # 计算图像上的相对坐标
        x_ratio = (lon - min_lon) / (max_lon - min_lon) if max_lon > min_lon else 0.5
        y_ratio = (
            1.0 - (lat - min_lat) / (max_lat - min_lat) if max_lat > min_lat else 0.5
        )  # 图像文件第一行对应最北端

        # 转换为像素坐标
        x = int(x_ratio * image_width)
        y = int(y_ratio * image_height)

        return x, y, is_inside

    @staticmethod
    def parse_bounds(
        geo_bounds_config: dict,
    ) -> tuple[float, float, float, float] | None:
        """从配置中解析地理边界。

        从配置字典中提取四个角点的坐标（north_east, south_west, south_east, north_west）
        并计算边界矩形。

        Args:
            geo_bounds_config: 包含四个角点坐标的配置字典
                {
                    'north_east': 'lon,lat',
                    'south_west': 'lon,lat',
                    'south_east': 'lon,lat',
                    'north_west': 'lon,lat'
                }

        Returns:
            List[float] | None: 边界坐标 [min_lon, min_lat, max_lon, max_lat]
                                如果解析失败则返回 None

        Examples:
            >>> config = {
            ...     'north_east': '120.2,30.2',
            ...     'south_west': '120.0,30.0',
            ...     'south_east': '120.2,30.0',
            ...     'north_west': '120.0,30.2'
            ... }
            >>> bounds = GeoUtilities.parse_bounds(config)
            >>> print(bounds)
        """
        try:
            # 尝试从 config 中获取四个角的坐标
            # 获取坐标字符串，处理 None 值
            ne_str = geo_bounds_config.get("north_east") or ""
            sw_str = geo_bounds_config.get("south_west") or ""
            se_str = geo_bounds_config.get("south_east") or ""
            nw_str = geo_bounds_config.get("north_west") or ""

            ne = ne_str.split(",")
            sw = sw_str.split(",")
            se = se_str.split(",")
            nw = nw_str.split(",")

            if len(ne) != 2 or len(sw) != 2 or len(se) != 2 or len(nw) != 2:
                logger.warning("地理坐标格式不正确，使用默认边界")
                return None

            # 转换为浮点数
            ne_lon, ne_lat = float(ne[0]), float(ne[1])
            sw_lon, sw_lat = float(sw[0]), float(sw[1])
            se_lon, se_lat = float(se[0]), float(se[1])
            nw_lon, nw_lat = float(nw[0]), float(nw[1])

            # 求最大最小经纬度范围
            min_lon = min(sw_lon, nw_lon)
            max_lon = max(ne_lon, se_lon)
            min_lat = min(sw_lat, se_lat)
            max_lat = max(ne_lat, nw_lat)

            return [min_lon, min_lat, max_lon, max_lat]
        except Exception as e:
            logger.error(f"解析地理边界失败: {str(e)}")
            return None
