"""
配置加载服务

提供统一的配置加载、验证和管理功能。
支持从 YAML 文件加载配置，使用 Pydantic 进行验证。

遵循 Python 项目开发准则：
- 单一职责原则：专职加载和验证配置
- 依赖反转原则：通过协议定义接口
- 错误处理：明确的异常和日志

Author: 水质建模团队
"""

import logging
from pathlib import Path
from typing import Optional

import yaml
from pydantic import ValidationError

from autoreport.config.kriging_config_models import KrigingConfig
from autoreport.config.grades_config_models import WaterQualityGradesConfig

logger = logging.getLogger(__name__)


class ConfigLoadError(Exception):
    """配置加载异常"""

    pass


class ConfigValidator:
    """配置验证器"""

    @staticmethod
    def validate_kriging_config(data: dict) -> KrigingConfig:
        """验证并解析 Kriging 配置

        Args:
            data: 从 YAML 加载的原始数据字典

        Returns:
            KrigingConfig: 验证后的 Kriging 配置对象

        Raises:
            ConfigLoadError: 配置验证失败时抛出

        Examples:
            >>> with open("kriging_config.yaml") as f:
            ...     raw_config = yaml.safe_load(f)
            >>> config = ConfigValidator.validate_kriging_config(raw_config)
        """
        try:
            config = KrigingConfig(**data)
            logger.info("Kriging 配置验证成功")
            return config
        except ValidationError as e:
            logger.error(f"Kriging 配置验证失败: {e}")
            raise ConfigLoadError(f"Kriging 配置验证失败: {e}") from e

    @staticmethod
    def validate_grades_config(data: dict) -> WaterQualityGradesConfig:
        """验证并解析水质分级配置

        Args:
            data: 从 YAML 加载的原始数据字典

        Returns:
            WaterQualityGradesConfig: 验证后的分级配置对象

        Raises:
            ConfigLoadError: 配置验证失败时抛出

        Examples:
            >>> with open("grades_config.yaml") as f:
            ...     raw_config = yaml.safe_load(f)
            >>> config = ConfigValidator.validate_grades_config(raw_config)
        """
        try:
            config = WaterQualityGradesConfig(**data)
            logger.info("水质分级配置验证成功")
            return config
        except ValidationError as e:
            logger.error(f"水质分级配置验证失败: {e}")
            raise ConfigLoadError(f"水质分级配置验证失败: {e}") from e


class ConfigLoader:
    """配置加载器

    提供从 YAML 文件加载、验证和缓存配置的功能。
    """

    def __init__(self, config_dir: Optional[Path] = None):
        """初始化配置加载器

        Args:
            config_dir: 配置文件目录（默认为 src/autoreport/config/data/）

        Raises:
            ConfigLoadError: 如果配置目录不存在
        """
        if config_dir is None:
            # 默认配置目录：包文件所在目录的上一级的 data 目录
            config_dir = Path(__file__).parent / "data"

        if not config_dir.exists():
            raise ConfigLoadError(f"配置目录不存在: {config_dir}")

        self.config_dir = config_dir
        self._kriging_config: Optional[KrigingConfig] = None
        self._grades_config: Optional[WaterQualityGradesConfig] = None
        logger.info(f"配置加载器已初始化，配置目录: {config_dir}")

    def load_kriging_config(self, force_reload: bool = False) -> KrigingConfig:
        """加载 Kriging 配置

        Args:
            force_reload: 是否强制重新加载（忽略缓存）

        Returns:
            KrigingConfig: Kriging 配置对象

        Raises:
            ConfigLoadError: 配置文件不存在或验证失败

        Examples:
            >>> loader = ConfigLoader()
            >>> config = loader.load_kriging_config()
            >>> method_name = config.global_kriging_method
        """
        if self._kriging_config is not None and not force_reload:
            logger.debug("使用缓存的 Kriging 配置")
            return self._kriging_config

        config_file = self.config_dir / "kriging_config.yaml"
        if not config_file.exists():
            raise ConfigLoadError(f"Kriging 配置文件不存在: {config_file}")

        logger.info(f"加载 Kriging 配置文件: {config_file}")
        try:
            with open(config_file, encoding="utf-8") as f:
                raw_config = yaml.safe_load(f)
        except Exception as e:
            raise ConfigLoadError(
                f"加载 YAML 文件失败: {config_file}, 错误: {e}"
            ) from e

        self._kriging_config = ConfigValidator.validate_kriging_config(raw_config)
        return self._kriging_config

    def load_grades_config(
        self, force_reload: bool = False
    ) -> WaterQualityGradesConfig:
        """加载水质分级配置

        Args:
            force_reload: 是否强制重新加载（忽略缓存）

        Returns:
            WaterQualityGradesConfig: 分级配置对象

        Raises:
            ConfigLoadError: 配置文件不存在或验证失败

        Examples:
            >>> loader = ConfigLoader()
            >>> config = loader.load_grades_config()
            >>> cod_config = config.get_indicator_config("COD")
        """
        if self._grades_config is not None and not force_reload:
            logger.debug("使用缓存的水质分级配置")
            return self._grades_config

        config_file = self.config_dir / "grades_config.yaml"
        if not config_file.exists():
            raise ConfigLoadError(f"分级配置文件不存在: {config_file}")

        logger.info(f"加载分级配置文件: {config_file}")
        try:
            with open(config_file, encoding="utf-8") as f:
                raw_config = yaml.safe_load(f)
        except Exception as e:
            raise ConfigLoadError(
                f"加载 YAML 文件失败: {config_file}, 错误: {e}"
            ) from e

        self._grades_config = ConfigValidator.validate_grades_config(raw_config)
        return self._grades_config

    def reload_all(self) -> None:
        """强制重新加载所有配置

        Examples:
            >>> loader = ConfigLoader()
            >>> loader.reload_all()  # 重新加载所有配置
        """
        logger.info("重新加载所有配置")
        self.load_kriging_config(force_reload=True)
        self.load_grades_config(force_reload=True)

    def clear_cache(self) -> None:
        """清除配置缓存

        Examples:
            >>> loader = ConfigLoader()
            >>> loader.clear_cache()  # 清除缓存，下次加载时会重新读取文件
        """
        logger.info("清除配置缓存")
        self._kriging_config = None
        self._grades_config = None


# 全局配置加载器实例（单例）
_global_config_loader: Optional[ConfigLoader] = None


def get_config_loader(config_dir: Optional[Path] = None) -> ConfigLoader:
    """获取全局配置加载器实例

    Args:
        config_dir: 配置文件目录（仅在首次调用时有效）

    Returns:
        ConfigLoader: 全局配置加载器实例

    Examples:
        >>> loader = get_config_loader()
        >>> kriging_config = loader.load_kriging_config()
    """
    global _global_config_loader
    if _global_config_loader is None:
        _global_config_loader = ConfigLoader(config_dir)
    return _global_config_loader
