"""
Kriging 配置 Pydantic 模型

遵循 Python 项目开发准则，使用 Pydantic v2 进行配置验证和类型检查。
支持从 YAML 配置文件加载并自动验证。

Author: 水质建模团队
"""

from typing import List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator


class KrigingMethodConfig(BaseModel):
    """单个克里金方法的配置"""

    variogram_model: Literal[
        "gaussian", "spherical", "exponential", "linear", "power"
    ] = Field(..., description="变差函数模型类型")

    drift_terms: Optional[List[str]] = Field(
        default=None, description="漂移项（仅适用于泛克里金）"
    )

    nlags: int = Field(default=6, description="变差函数计算的滞后数量", ge=1, le=50)

    enforce_positive: bool = Field(default=True, description="强制插值结果为正数")

    transform_method: Literal["log", "clip", "none"] = Field(
        default="none", description="负数处理方法"
    )

    description: str = Field(..., description="克里金方法描述")

    # 普通克里金特有参数
    n_closest_points: Optional[int] = Field(
        default=None, description="搜索最近的点数", ge=3, le=50
    )

    search_radius_factor: Optional[float] = Field(
        default=None, description="搜索半径相对于数据范围的比例", ge=0.1, le=1.0
    )

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "variogram_model": "spherical",
                "nlags": 6,
                "enforce_positive": True,
                "transform_method": "clip",
                "description": "普通克里金-球形模型",
                "n_closest_points": 12,
                "search_radius_factor": 0.3,
            }
        }
    )


class GeneralKrigingParams(BaseModel):
    """通用克里金参数"""

    min_points: int = Field(default=3, description="最少插值点数", ge=1, le=20)

    max_points: int = Field(default=20, description="最多使用的邻域点数", ge=3, le=100)

    variogram_nlags: int = Field(
        default=6, description="默认变差函数滞后数", ge=1, le=50
    )

    @field_validator("max_points")
    @classmethod
    def max_points_greater_than_min(cls, v: int, info) -> int:
        """验证 max_points >= min_points"""
        if "min_points" in info.data and v < info.data["min_points"]:
            raise ValueError("max_points 必须大于等于 min_points")
        return v


class KrigingConfig(BaseModel):
    """完整的 Kriging 配置"""

    global_kriging_method: Literal[
        "universal_kriging",
        "ordinary_kriging_spherical",
        "ordinary_kriging_exponential",
    ] = Field(default="ordinary_kriging_spherical", description="当前使用的克里金方法")

    kriging_methods: dict[str, KrigingMethodConfig] = Field(
        ..., description="克里金方法配置字典"
    )

    general_kriging_params: GeneralKrigingParams = Field(
        default_factory=GeneralKrigingParams, description="通用克里金参数"
    )

    def get_method_config(self, method_name: str) -> Optional[KrigingMethodConfig]:
        """获取指定克里金方法的配置

        Args:
            method_name: 克里金方法名称

        Returns:
            KrigingMethodConfig | None: 方法配置，若不存在返回 None
        """
        return self.kriging_methods.get(method_name)

    def get_active_method_config(self) -> KrigingMethodConfig:
        """获取当前活跃的克里金方法配置

        Returns:
            KrigingMethodConfig: 当前方法的配置

        Raises:
            ValueError: 如果配置的方法不存在
        """
        config = self.get_method_config(self.global_kriging_method)
        if config is None:
            raise ValueError(
                f"克里金方法 '{self.global_kriging_method}' 未定义。"
                f"可用方法: {', '.join(self.kriging_methods.keys())}"
            )
        return config

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "global_kriging_method": "ordinary_kriging_spherical",
                "kriging_methods": {
                    "universal_kriging": {
                        "variogram_model": "gaussian",
                        "drift_terms": ["regional_linear"],
                        "enforce_positive": True,
                        "transform_method": "log",
                        "description": "泛克里金-高斯模型",
                        "nlags": 6,
                    }
                },
                "general_kriging_params": {
                    "min_points": 3,
                    "max_points": 20,
                    "variogram_nlags": 6,
                },
            }
        }
    )
