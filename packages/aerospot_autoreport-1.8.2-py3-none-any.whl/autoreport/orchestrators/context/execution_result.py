"""执行结果模型

定义类型安全的执行结果数据结构，替代之前使用的字典。
"""

from dataclasses import dataclass, field
from typing import Any, Dict, Optional, List
from datetime import datetime


@dataclass
class ExecutionResult:
    """执行结果数据模型

    替代之前使用的字典，提供类型安全的执行结果存储。

    Attributes:
        success: 执行是否成功
        stage: 当前执行的阶段名称
        message: 执行消息
        error: 错误信息（如果有）
        duration_seconds: 执行耗时（秒）
        start_time: 开始时间戳
        end_time: 结束时间戳
        data: 执行结果数据字典
        metadata: 元数据（用于存储其他信息）
        completed_stages: 已完成的阶段列表
        failed_stages: 失败的阶段列表
        paths: 生成的文件/目录路径字典

    Examples:
        >>> result = ExecutionResult(
        ...     success=True,
        ...     stage="PROCESS_DATA",
        ...     message="Data processing completed",
        ...     duration_seconds=45.3
        ... )
        >>> result.data["output_file"] = "/path/to/file"
    """

    # 基本执行状态
    success: bool = False
    stage: str = ""
    message: str = ""
    error: Optional[str] = None

    # 时间相关
    duration_seconds: float = 0.0
    start_time: Optional[float] = None
    end_time: Optional[float] = None

    # 结果数据
    data: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)

    # 阶段追踪
    completed_stages: List[str] = field(default_factory=list)
    failed_stages: List[str] = field(default_factory=list)

    # 路径信息
    paths: Dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """将结果转换为字典格式

        Returns:
            结果字典

        Examples:
            >>> result = ExecutionResult(success=True)
            >>> result_dict = result.to_dict()
        """
        return {
            "success": self.success,
            "stage": self.stage,
            "message": self.message,
            "error": self.error,
            "duration_seconds": self.duration_seconds,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "data": self.data,
            "metadata": self.metadata,
            "completed_stages": self.completed_stages,
            "failed_stages": self.failed_stages,
            "paths": self.paths,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ExecutionResult":
        """从字典构建结果对象

        Args:
            data: 结果字典

        Returns:
            ExecutionResult 实例

        Examples:
            >>> result_dict = {...}
            >>> result = ExecutionResult.from_dict(result_dict)
        """
        return cls(
            success=data.get("success", False),
            stage=data.get("stage", ""),
            message=data.get("message", ""),
            error=data.get("error"),
            duration_seconds=data.get("duration_seconds", 0.0),
            start_time=data.get("start_time"),
            end_time=data.get("end_time"),
            data=data.get("data", {}),
            metadata=data.get("metadata", {}),
            completed_stages=data.get("completed_stages", []),
            failed_stages=data.get("failed_stages", []),
            paths=data.get("paths", {}),
        )

    def add_completed_stage(self, stage_name: str) -> None:
        """添加已完成的阶段

        Args:
            stage_name: 阶段名称

        Examples:
            >>> result.add_completed_stage("PROCESS_DATA")
        """
        if stage_name not in self.completed_stages:
            self.completed_stages.append(stage_name)

    def add_failed_stage(self, stage_name: str) -> None:
        """添加失败的阶段

        Args:
            stage_name: 阶段名称

        Examples:
            >>> result.add_failed_stage("GENERATE_MAPS")
        """
        if stage_name not in self.failed_stages:
            self.failed_stages.append(stage_name)

    def set_path(self, key: str, path: str) -> None:
        """设置路径信息

        Args:
            key: 路径键（如 "report", "config", "maps"）
            path: 路径值

        Examples:
            >>> result.set_path("report", "/path/to/report.docx")
        """
        self.paths[key] = path

    def get_path(self, key: str) -> Optional[str]:
        """获取路径信息

        Args:
            key: 路径键

        Returns:
            路径值，如果不存在则返回 None

        Examples:
            >>> report_path = result.get_path("report")
        """
        return self.paths.get(key)

    def set_data(self, key: str, value: Any) -> None:
        """设置数据字段

        Args:
            key: 数据键
            value: 数据值

        Examples:
            >>> result.set_data("processed_records", 1000)
        """
        self.data[key] = value

    def get_data(self, key: str, default: Any = None) -> Any:
        """获取数据字段

        Args:
            key: 数据键
            default: 默认值

        Returns:
            数据值或默认值

        Examples:
            >>> records = result.get_data("processed_records", 0)
        """
        return self.data.get(key, default)

    def mark_success(self) -> None:
        """标记执行成功

        Examples:
            >>> result.mark_success()
        """
        self.success = True

    def mark_failure(self, error: str) -> None:
        """标记执行失败

        Args:
            error: 错误信息

        Examples:
            >>> result.mark_failure("Data processing failed")
        """
        self.success = False
        self.error = error
