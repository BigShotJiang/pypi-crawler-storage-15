"""增强的执行上下文 V2

定义类型安全、可扩展的执行上下文，支持依赖注入和完整的状态管理。
"""

from dataclasses import dataclass, field
from typing import Any, Optional, List, Tuple
import time

from ..stage.registry import StageRegistry
from ..config.config_provider import ConfigProvider
from ..config.execution_config import ExecutionModeConfig
from .execution_result import ExecutionResult
from ..execution_modes.base import ExecutionStage


@dataclass
class ExecutionContextV2:
    """增强的执行上下文 V2

    提供类型安全、可扩展的执行上下文，支持依赖注入和完整的状态管理。

    这个上下文替代了之前的 ExecutionContext，主要改进：
    1. 支持 StageRegistry 和 ConfigProvider 注入
    2. 完整的状态追踪（当前阶段、已完成、失败）
    3. 类型安全的配置对象
    4. 详细的执行结果模型

    Attributes:
        # 基础信息
        generator: 报告生成器实例
        config_path: 配置文件路径
        output_dir: 输出目录
        cache_enabled: 是否启用缓存
        start_time: 执行开始时间戳

        # 配置对象（类型安全）
        app_config: 应用配置（Pydantic 模型）
        execution_config: 执行模式配置（ExecutionModeConfig 及其子类）

        # 可注入组件（Stage 1 新增）
        stage_registry: Stage 处理器注册表
        config_provider: 配置提供者（替代全局变量）
        error_handler: 错误处理器

        # 状态追踪
        current_stage: 当前执行的阶段
        completed_stages: 已完成的阶段列表
        failed_stages: 失败的阶段列表（存储阶段和异常）

        # 执行结果
        result: 执行结果对象

    Examples:
        >>> from autoreport.orchestrators.stage import StageRegistry
        >>> from autoreport.orchestrators.config import ConfigProvider
        >>>
        >>> registry = StageRegistry()
        >>> provider = ConfigProvider()
        >>>
        >>> context = ExecutionContextV2(
        ...     generator=generator,
        ...     config_path="config.json",
        ...     output_dir="./output",
        ...     cache_enabled=True,
        ...     start_time=time.time(),
        ...     stage_registry=registry,
        ...     config_provider=provider,
        ... )
        >>>
        >>> context.current_stage = ExecutionStage.PROCESS_DATA
        >>> context.add_completed_stage(ExecutionStage.INIT)
    """

    # 基础信息（必需）
    generator: Any  # AeroSpotReportGenerator
    config_path: str
    output_dir: str
    cache_enabled: bool
    start_time: float

    # 配置对象
    app_config: Optional[Any] = None  # AppConfig 或其他配置模型
    execution_config: Optional[ExecutionModeConfig] = None

    # 可注入组件（Stage 1 新增）
    stage_registry: Optional[StageRegistry] = None
    config_provider: Optional[ConfigProvider] = None
    error_handler: Optional[Any] = None  # ErrorHandler

    # 状态追踪
    current_stage: Optional[ExecutionStage] = None
    completed_stages: List[ExecutionStage] = field(default_factory=list)
    failed_stages: List[Tuple[ExecutionStage, Exception]] = field(default_factory=list)

    # 执行结果
    result: Optional[ExecutionResult] = None

    # ============ 初始化 ============

    def __post_init__(self) -> None:
        """初始化后处理"""
        # 如果未提供 result，创建新的
        if self.result is None:
            self.result = ExecutionResult(
                start_time=self.start_time,
            )

    # ============ 阶段管理 ============

    def set_current_stage(self, stage: ExecutionStage) -> None:
        """设置当前执行的阶段

        Args:
            stage: 执行阶段

        Examples:
            >>> context.set_current_stage(ExecutionStage.PROCESS_DATA)
        """
        self.current_stage = stage
        if self.result:
            self.result.stage = stage.value

    def add_completed_stage(self, stage: ExecutionStage) -> None:
        """标记一个阶段为已完成

        Args:
            stage: 执行阶段

        Examples:
            >>> context.add_completed_stage(ExecutionStage.INIT)
        """
        if stage not in self.completed_stages:
            self.completed_stages.append(stage)
        if self.result:
            self.result.add_completed_stage(stage.value)

    def mark_stage_failed(self, stage: ExecutionStage, error: Exception) -> None:
        """标记一个阶段执行失败

        Args:
            stage: 失败的执行阶段
            error: 异常对象

        Examples:
            >>> context.mark_stage_failed(
            ...     ExecutionStage.GENERATE_MAPS,
            ...     Exception("Interpolation failed")
            ... )
        """
        if (stage, error) not in self.failed_stages:
            self.failed_stages.append((stage, error))
        if self.result:
            self.result.add_failed_stage(stage.value)
            self.result.error = str(error)

    def is_stage_completed(self, stage: ExecutionStage) -> bool:
        """检查阶段是否已完成

        Args:
            stage: 执行阶段

        Returns:
            如果已完成返回 True，否则返回 False
        """
        return stage in self.completed_stages

    def has_failed_stages(self) -> bool:
        """检查是否有失败的阶段

        Returns:
            如果有失败阶段返回 True，否则返回 False
        """
        return len(self.failed_stages) > 0

    def get_failed_stages(self) -> List[Tuple[ExecutionStage, Exception]]:
        """获取所有失败的阶段及其异常

        Returns:
            失败的阶段和异常列表

        Examples:
            >>> failed = context.get_failed_stages()
            >>> for stage, error in failed:
            ...     print(f"{stage.value}: {error}")
        """
        return self.failed_stages.copy()

    # ============ 配置访问 ============

    def get_config_provider(self) -> ConfigProvider:
        """获取配置提供者

        Returns:
            ConfigProvider 实例

        Raises:
            RuntimeError: 如果配置提供者未设置

        Examples:
            >>> provider = context.get_config_provider()
            >>> rendering_config = provider.get_rendering_config()
        """
        if self.config_provider is None:
            raise RuntimeError("Config provider not set in context")
        return self.config_provider

    def get_stage_registry(self) -> StageRegistry:
        """获取 Stage 注册表

        Returns:
            StageRegistry 实例

        Raises:
            RuntimeError: 如果 Stage 注册表未设置

        Examples:
            >>> registry = context.get_stage_registry()
            >>> handler = registry.get_handler(ExecutionStage.PROCESS_DATA)
        """
        if self.stage_registry is None:
            raise RuntimeError("Stage registry not set in context")
        return self.stage_registry

    # ============ 执行结果管理 ============

    def get_result(self) -> ExecutionResult:
        """获取执行结果

        Returns:
            ExecutionResult 实例

        Examples:
            >>> result = context.get_result()
            >>> if result.success:
            ...     print("Execution succeeded")
        """
        if self.result is None:
            self.result = ExecutionResult(start_time=self.start_time)
        return self.result

    def mark_success(self, message: str = "") -> None:
        """标记执行成功

        Args:
            message: 成功消息

        Examples:
            >>> context.mark_success("All stages completed successfully")
        """
        if self.result is None:
            self.result = ExecutionResult(start_time=self.start_time)
        self.result.success = True
        if message:
            self.result.message = message
        self._update_result_timing()

    def mark_failure(self, error: str) -> None:
        """标记执行失败

        Args:
            error: 错误信息

        Examples:
            >>> context.mark_failure("Data processing failed")
        """
        if self.result is None:
            self.result = ExecutionResult(start_time=self.start_time)
        self.result.success = False
        self.result.error = error
        self._update_result_timing()

    def _update_result_timing(self) -> None:
        """更新执行结果的时间信息"""
        if self.result:
            end_time = time.time()
            self.result.end_time = end_time
            if self.result.start_time:
                self.result.duration_seconds = end_time - self.result.start_time

    def set_result_data(self, key: str, value: Any) -> None:
        """设置执行结果数据

        Args:
            key: 数据键
            value: 数据值

        Examples:
            >>> context.set_result_data("processed_count", 100)
        """
        if self.result is None:
            self.result = ExecutionResult(start_time=self.start_time)
        self.result.set_data(key, value)

    def set_result_path(self, key: str, path: str) -> None:
        """设置执行结果路径

        Args:
            key: 路径键（如 "report", "config", "maps"）
            path: 路径值

        Examples:
            >>> context.set_result_path("report", "/path/to/report.docx")
        """
        if self.result is None:
            self.result = ExecutionResult(start_time=self.start_time)
        self.result.set_path(key, path)

    # ============ 状态汇总 ============

    def get_summary(self) -> dict:
        """获取执行上下文的状态汇总

        Returns:
            包含关键状态信息的字典

        Examples:
            >>> summary = context.get_summary()
            >>> print(f"Completed: {len(summary['completed_stages'])}")
        """
        return {
            "current_stage": self.current_stage.value if self.current_stage else None,
            "completed_stages": [s.value for s in self.completed_stages],
            "failed_stages": [
                {"stage": s.value, "error": str(e)}
                for s, e in self.failed_stages
            ],
            "success": self.result.success if self.result else False,
            "has_injected_components": {
                "stage_registry": self.stage_registry is not None,
                "config_provider": self.config_provider is not None,
                "error_handler": self.error_handler is not None,
            },
        }
