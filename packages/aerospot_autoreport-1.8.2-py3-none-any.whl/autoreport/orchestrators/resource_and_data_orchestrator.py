#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""资源和数据编排器

协调资源下载和数据处理两个阶段的完整流程。
"""

import logging
from typing import Any, Dict, Optional

from ..core.boundary_manager import BoundaryManager
from ..core.configuration_service import ConfigurationService
from ..core.extractor import ZipExtractor
from ..core.resource_manager import ResourceManager
from ..core import ResourceError
from ..models.report_data import ReportData
from ..processor.data import DataProcessor
from ..utils.path import PathManager
from ..core import safe_operation
from .orchestrator import Orchestrator

logger = logging.getLogger(__name__)


class ResourceAndDataOrchestrator(Orchestrator):
    """资源和数据编排器

    职责：
    1. 协调资源下载阶段
    2. 初始化边界管理器（在 KML 下载后）
    3. 委托给数据处理编排器
    4. 统一处理完整的资源和数据处理流程

    Note:
        boundary_manager 参数在构造时可以传入 None，
        因为真正的初始化需要等到 KML 文件下载后才能进行。
    """

    def __init__(
        self,
        config_service: ConfigurationService,
        resource_manager: ResourceManager,
        boundary_manager: Optional[BoundaryManager],
        path_manager: PathManager,
        data_processor: DataProcessor,
        extractor: ZipExtractor,
    ) -> None:
        """初始化资源和数据编排器

        Args:
            config_service: 配置服务实例
            resource_manager: 资源管理器实例
            boundary_manager: 边界管理器实例（可为 None，会在资源下载后初始化）
            path_manager: 路径管理器实例
            data_processor: 数据处理器实例
            extractor: ZIP 解压器实例
        """
        super().__init__()
        self.config_service: ConfigurationService = config_service
        self.resource_manager: ResourceManager = resource_manager
        self.boundary_manager: Optional[BoundaryManager] = boundary_manager
        self.path_manager: PathManager = path_manager
        self.data_processor: DataProcessor = data_processor
        self.extractor: ZipExtractor = extractor

    @safe_operation(error_msg="资源和数据处理失败", default_return=False)
    def orchestrate(self, report_data: ReportData) -> ReportData:
        """执行完整的资源下载和数据处理流程

        Args:
            report_data: ReportData模型实例

        Returns:
            ReportData: 更新后的模型实例
        """
        return self.execute(report_data)

    def execute(self, data: ReportData) -> ReportData:
        """执行编排流程（Orchestrator 接口实现）

        实现了 Orchestrator 抽象基类的 execute 方法，
        调用原有的业务逻辑。

        Args:
            data: ReportData模型实例

        Returns:
            ReportData: 更新后的模型实例
        """
        logger.info("开始资源和数据处理编排...")
        data.update_processing_state("processing")

        # 阶段 1：资源下载
        if not self._download_resources(data):
            logger.error("资源下载阶段失败")
            data.update_processing_state("failed", "资源下载失败")
            return data

        # 阶段 2：数据处理
        logger.info("开始数据处理阶段...")

        # 延迟导入 DataProcessingOrchestrator（避免循环导入）
        from .data_processing_orchestrator import DataProcessingOrchestrator

        data_orch = DataProcessingOrchestrator(
            config_service=self.config_service,
            path_manager=self.path_manager,
            data_processor=self.data_processor,
            extractor=self.extractor,
            boundary_manager=self.boundary_manager,
        )

        # 调用process方法，直接返回ReportData
        result = data_orch.process(data)
        return result

    def validate_input(self, data: ReportData) -> bool:
        """验证输入数据的有效性（Orchestrator 接口实现）

        检查 ReportData 是否包含执行资源和数据处理所需的基本信息。

        Args:
            data: 需要验证的报告数据模型

        Returns:
            bool: 验证通过返回 True；失败返回 False
        """
        if data is None:
            self.logger.error("输入数据为 None")
            return False

        if data.config is None:
            self.logger.error("配置信息缺失")
            return False

        return True

    def _download_resources(self, report_data: ReportData) -> bool:
        """下载所有资源文件

        Args:
            report_data: ReportData模型实例

        Returns:
            bool: 是否全部下载成功
        """
        logger.info("开始下载资源文件...")

        try:
            company_info = self.config_service.get_company_info()
            success = True

            # 图像资源映射：(company_info属性名, ImageResources属性名, 资源类型)
            image_resources = [
                ("logo_path", "logo", "logo"),
                ("wayline_img", "wayline", "wayline"),
                ("satellite_img", "satellite", "satellite"),
            ]

            # 下载并更新图像资源
            for attr_name, img_field, resource_type in image_resources:
                url = getattr(company_info, attr_name, None)
                if not url:
                    continue

                try:
                    resource_path = self.resource_manager.get_resource(url, resource_type)
                    setattr(company_info, attr_name, resource_path)
                    setattr(report_data.image_resources, img_field, resource_path)
                    logger.info(f"✓ {attr_name} 资源获取成功: {resource_path}")
                except ResourceError as e:
                    logger.error(f"获取资源 {attr_name} 失败: {str(e)}")
                    success = False

            # 下载其他资源（不存入ReportData.image_resources）
            other_resources = ["measure_data", "file_url", "bin_url", "historical_data"]
            for resource_key in other_resources:
                url = getattr(company_info, resource_key, None)
                if not url:
                    continue

                try:
                    resource_path = self.resource_manager.get_resource(url, resource_key)
                    setattr(company_info, resource_key, resource_path)
                    logger.info(f"✓ {resource_key} 资源获取成功: {resource_path}")
                except ResourceError as e:
                    logger.error(f"获取资源 {resource_key} 失败: {str(e)}")
                    success = False

            # 初始化边界管理器（KML 下载后）
            kml_path = getattr(company_info, "kml_boundary_url", None)
            self.boundary_manager = BoundaryManager(kml_path)

            boundary_stats = self.boundary_manager.get_statistics()
            if boundary_stats.get("enabled"):
                logger.info(f"✓ 边界管理器已启用: {boundary_stats}")
            else:
                logger.info("ℹ 边界管理器已禁用（未指定KML文件或文件无效）")

            return success

        except Exception as e:
            logger.error(f"资源下载过程出错: {str(e)}", exc_info=True)
            return False
