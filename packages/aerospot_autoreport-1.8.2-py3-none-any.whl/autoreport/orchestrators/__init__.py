"""编排层模块 - 统一编排和流程管理

该模块提供高层次的编排器，协调整个报告生成流程的各个阶段。

各个编排器的职责：
- ReportGenerationPipeline：旧版管道（已弃用，仅保留向后兼容）
- PipelineV2：新一代报告生成管道（推荐使用，Stage 3 实现）
- ResourceAndDataOrchestrator：编排资源下载和数据处理阶段
- DataProcessingOrchestrator：编排数据处理阶段
- MapGenerationOrchestrator：编排地图生成阶段
- ReportGenerationOrchestrator：编排报告生成阶段

基础设施（Stage 1）：
- StageRegistry：动态注册和管理执行阶段处理器
- ConfigProvider：配置提供者，替代全局状态
- ExecutionModeConfig：类型安全的配置基类
- ExecutionContextV2：增强的执行上下文，支持依赖注入
- ExecutionResult：类型安全的执行结果模型

PipelineV2 改进（Stage 3）：
- 完全基于依赖注入架构
- 动态阶段处理器注册
- 显式配置注入
- 类型安全的执行结果

阶段处理器系统（Stage 4）：
- StageHandler：阶段处理器抽象基类
- StageHandlerContext：处理器执行上下文
- StageHandlerResult：处理器执行结果
- HandlerMiddleware：处理器中间件抽象基类
- LoggingMiddleware：日志记录中间件
- ErrorRecoveryMiddleware：错误恢复中间件
- ValidationMiddleware：验证中间件
- StageOrchestrator：阶段编排器（管理多个处理器）
- StageExecutionResult：阶段执行结果聚合

基础架构：
- Orchestrator：所有编排器的抽象基类
- GeometryValidationMixin：几何体验证混合类
- 装饰器：validate_data_modification(), validate_geometry_before_processing(), log_data_access()
"""

from .pipeline import ReportGenerationPipeline
from .pipeline_v2 import PipelineV2
from .resource_and_data_orchestrator import ResourceAndDataOrchestrator
from .data_processing_orchestrator import DataProcessingOrchestrator
from .map_generation_orchestrator import MapGenerationOrchestrator
from .orchestrator import Orchestrator
from .geometry_validation import GeometryValidationMixin
from .decorators import (
    validate_data_modification,
    validate_geometry_before_processing,
    log_data_access,
)

# Stage 1 & Stage 4: Infrastructure
from .stage import (
    StageRegistry,
    StageHandler,
    StageHandlerContext,
    StageHandlerResult,
    HandlerMiddleware,
    LoggingMiddleware,
    ErrorRecoveryMiddleware,
    ValidationMiddleware,
    StageOrchestrator,
    StageExecutionResult,
)
from .config import (
    ConfigProvider,
    ExecutionModeConfig,
    RenderingConfig,
    MapGenerationConfig,
    FullReportConfig,
    HeatmapOnlyConfig,
    ModelingOnlyConfig,
)
from .context import ExecutionContextV2, ExecutionResult

__all__ = [
    # Pipeline
    "ReportGenerationPipeline",
    "PipelineV2",
    # Orchestrators
    "ResourceAndDataOrchestrator",
    "DataProcessingOrchestrator",
    "MapGenerationOrchestrator",
    # Base Class
    "Orchestrator",
    # Mixins
    "GeometryValidationMixin",
    # Decorators
    "validate_data_modification",
    "validate_geometry_before_processing",
    "log_data_access",
    # Stage 1: Infrastructure
    "StageRegistry",
    # Stage 4: Handler System
    "StageHandler",
    "StageHandlerContext",
    "StageHandlerResult",
    "HandlerMiddleware",
    "LoggingMiddleware",
    "ErrorRecoveryMiddleware",
    "ValidationMiddleware",
    "StageOrchestrator",
    "StageExecutionResult",
    # Configuration & Context
    "ConfigProvider",
    "ExecutionModeConfig",
    "RenderingConfig",
    "MapGenerationConfig",
    "FullReportConfig",
    "HeatmapOnlyConfig",
    "ModelingOnlyConfig",
    "ExecutionContextV2",
    "ExecutionResult",
]

# Stage 5: Integration Handlers
from .handlers import (
    ResourceAndDataOrchestratorHandler,
    DataProcessingOrchestratorHandler,
    MapGenerationOrchestratorHandler,
    ReportGenerationOrchestratorHandler,
    ModelTrainingOrchestratorHandler,
    create_orchestrator_handlers,
)

# Stage 6: Performance & Caching
from .cache import StageCacheManager, MemoryCache, CacheEntry
from .performance import PerformanceTracker, PerformanceMetric, PerformanceContext

__all__.extend([
    # Stage 5: Integration Handlers
    "ResourceAndDataOrchestratorHandler",
    "DataProcessingOrchestratorHandler",
    "MapGenerationOrchestratorHandler",
    "ReportGenerationOrchestratorHandler",
    "ModelTrainingOrchestratorHandler",
    "create_orchestrator_handlers",
    # Stage 6: Performance & Caching
    "StageCacheManager",
    "MemoryCache",
    "CacheEntry",
    "PerformanceTracker",
    "PerformanceMetric",
    "PerformanceContext",
])
