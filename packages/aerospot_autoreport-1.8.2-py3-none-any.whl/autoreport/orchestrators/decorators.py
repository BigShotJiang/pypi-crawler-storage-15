#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""数据修改验证和日志记录装饰器

为数据修改操作提供统一的验证、日志记录和错误处理机制。
"""

import logging
import functools
from typing import Any, Callable, Optional
from datetime import datetime

from ..models.report_data import ReportData

logger = logging.getLogger(__name__)


def validate_data_modification(func: Callable) -> Callable:
    """数据修改验证装饰器

    为数据修改方法提供以下功能：
    1. 验证输入数据的有效性
    2. 记录修改操作到日志
    3. 捕获和处理异常
    4. 记录修改前后的数据状态

    使用示例：
        >>> class DataProcessor:
        ...     @validate_data_modification
        ...     def process_data(self, data: ReportData) -> ReportData:
        ...         # 修改数据
        ...         data.processing_state = "processing"
        ...         return data

    Args:
        func: 被装饰的方法

    Returns:
        Callable: 装饰后的方法
    """

    @functools.wraps(func)
    def wrapper(self: Any, data: ReportData, *args: Any, **kwargs: Any) -> ReportData:
        """包装函数

        Args:
            self: 方法所属的对象
            data: 报告数据模型
            *args: 位置参数
            **kwargs: 关键字参数

        Returns:
            ReportData: 修改后的报告数据模型

        Raises:
            Exception: 修改过程中遇到的任何异常
        """
        method_name = func.__name__
        class_name = self.__class__.__name__

        # 记录修改前的状态
        before_state = {
            "processing_state": data.processing_state,
            "timestamp": datetime.now().isoformat(),
            "has_uav_data": data.uav_data is not None,
            "has_measure_data": data.measure_data is not None,
            "has_maps": data.maps is not None and len(data.maps) > 0,
        }

        logger.debug(
            f"[{class_name}] 开始修改数据: {method_name}() "
            f"| 修改前状态: {before_state}"
        )

        try:
            # 执行修改操作
            result = func(self, data, *args, **kwargs)

            # 验证返回值类型
            if not isinstance(result, ReportData):
                raise TypeError(
                    f"{method_name}() 必须返回 ReportData 对象, "
                    f"但返回了 {type(result).__name__}"
                )

            # 记录修改后的状态
            after_state = {
                "processing_state": result.processing_state,
                "timestamp": datetime.now().isoformat(),
                "has_uav_data": result.uav_data is not None,
                "has_measure_data": result.measure_data is not None,
                "has_maps": result.maps is not None and len(result.maps) > 0,
            }

            logger.info(
                f"[{class_name}] 数据修改成功: {method_name}() "
                f"| 修改前: {before_state} | 修改后: {after_state}"
            )

            return result

        except Exception as e:
            # 记录异常信息
            logger.error(
                f"[{class_name}] 数据修改失败: {method_name}() "
                f"| 错误类型: {type(e).__name__} "
                f"| 错误信息: {str(e)}",
                exc_info=True,
            )
            raise

    return wrapper


def validate_geometry_before_processing(func: Callable) -> Callable:
    """几何体验证装饰器

    在处理之前验证和修复边界几何体。

    使用示例：
        >>> class MapGenerator:
        ...     @validate_geometry_before_processing
        ...     def generate_maps(self, data: ReportData) -> ReportData:
        ...         # 生成地图
        ...         return data

    Args:
        func: 被装饰的方法

    Returns:
        Callable: 装饰后的方法
    """

    @functools.wraps(func)
    def wrapper(self: Any, data: ReportData, *args: Any, **kwargs: Any) -> ReportData:
        """包装函数

        Args:
            self: 方法所属的对象
            data: 报告数据模型
            *args: 位置参数
            **kwargs: 关键字参数

        Returns:
            ReportData: 处理后的报告数据模型
        """
        method_name = func.__name__
        class_name = self.__class__.__name__

        # 验证几何体
        if data.boundary_geom is not None:
            logger.debug(
                f"[{class_name}] 验证边界几何体开始: {method_name}()"
            )
            try:
                from ..utils.kml import _fix_geometry_with_retry

                fixed_geom = _fix_geometry_with_retry(data.boundary_geom, max_attempts=3)
                data.boundary_geom = fixed_geom

                if fixed_geom is None:
                    logger.warning(
                        f"[{class_name}] 边界几何体修复失败，将被设置为 None: "
                        f"{method_name}()"
                    )
                else:
                    logger.debug(
                        f"[{class_name}] 边界几何体验证和修复完成: {method_name}()"
                    )
            except Exception as e:
                logger.warning(
                    f"[{class_name}] 几何体验证失败，继续处理: "
                    f"{method_name}() | 错误: {str(e)}"
                )

        # 执行被装饰的方法
        return func(self, data, *args, **kwargs)

    return wrapper


def log_data_access(access_type: str = "read") -> Callable:
    """数据访问日志装饰器

    记录对数据的访问操作。

    Args:
        access_type: 访问类型（"read" 或 "write"）

    Returns:
        Callable: 装饰器函数
    """

    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(self: Any, data: ReportData, *args: Any, **kwargs: Any) -> Any:
            """包装函数"""
            method_name = func.__name__
            class_name = self.__class__.__name__

            logger.debug(
                f"[{class_name}] 数据{access_type}操作: {method_name}()"
            )

            try:
                result = func(self, data, *args, **kwargs)
                logger.debug(
                    f"[{class_name}] 数据{access_type}操作完成: {method_name}()"
                )
                return result
            except Exception as e:
                logger.error(
                    f"[{class_name}] 数据{access_type}操作失败: "
                    f"{method_name}() | 错误: {str(e)}",
                    exc_info=True,
                )
                raise

        return wrapper

    return decorator
