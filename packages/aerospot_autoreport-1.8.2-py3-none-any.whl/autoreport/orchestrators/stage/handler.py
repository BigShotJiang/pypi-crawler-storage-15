"""阶段处理器基类和接口 - Stage 4 核心

定义所有阶段处理器必须实现的接口和生命周期。
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, Optional, List, Callable
from dataclasses import dataclass, field
import logging

from ..execution_modes.base import ExecutionStage

logger = logging.getLogger(__name__)


@dataclass
class StageHandlerContext:
    """阶段处理器执行上下文

    传递给每个处理器的上下文信息，包含：
    - 执行阶段标识
    - 执行数据
    - 处理器执行历史
    - 元数据
    """
    stage: ExecutionStage
    data: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    handler_history: List[str] = field(default_factory=list)

    def add_to_history(self, handler_name: str) -> None:
        """添加处理器执行历史"""
        self.handler_history.append(handler_name)

    def set_data(self, key: str, value: Any) -> None:
        """设置上下文数据"""
        self.data[key] = value

    def get_data(self, key: str, default: Any = None) -> Any:
        """获取上下文数据"""
        return self.data.get(key, default)

    def update_metadata(self, metadata: Dict[str, Any]) -> None:
        """更新元数据"""
        self.metadata.update(metadata)


@dataclass
class StageHandlerResult:
    """阶段处理器执行结果

    表示处理器的执行结果，包含：
    - 成功/失败状态
    - 输出数据
    - 错误信息
    - 执行时长
    """
    success: bool
    message: str = ""
    error: Optional[Exception] = None
    data: Dict[str, Any] = field(default_factory=dict)
    duration_seconds: float = 0.0

    def is_success(self) -> bool:
        """检查是否成功"""
        return self.success

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式"""
        return {
            "success": self.success,
            "message": self.message,
            "error": str(self.error) if self.error else None,
            "data": self.data,
            "duration_seconds": self.duration_seconds,
        }


class StageHandler(ABC):
    """阶段处理器抽象基类

    所有具体的阶段处理器都应该继承此类。
    提供生命周期管理和标准的处理器接口。
    """

    def __init__(self, name: str):
        """初始化处理器

        Args:
            name: 处理器名称
        """
        self.name = name
        self.logger = logging.getLogger(f"{__name__}.{name}")

    @abstractmethod
    def execute(self, context: StageHandlerContext) -> StageHandlerResult:
        """执行处理器的主要业务逻辑

        Args:
            context: 阶段处理器执行上下文

        Returns:
            StageHandlerResult: 执行结果
        """
        pass

    def validate(self, context: StageHandlerContext) -> bool:
        """验证执行前的条件

        可以被子类重写以执行特定的前置验证。

        Args:
            context: 阶段处理器执行上下文

        Returns:
            bool: 验证是否通过
        """
        return True

    def cleanup(self, context: StageHandlerContext, result: StageHandlerResult) -> None:
        """清理资源和状态

        在处理器执行完成后调用，无论成功或失败。
        可以被子类重写以执行特定的清理逻辑。

        Args:
            context: 阶段处理器执行上下文
            result: 执行结果
        """
        pass

    def on_success(self, context: StageHandlerContext, result: StageHandlerResult) -> None:
        """处理器执行成功时的回调

        可以被子类重写以执行特定的成功处理逻辑。

        Args:
            context: 阶段处理器执行上下文
            result: 执行结果
        """
        self.logger.info(f"处理器成功: {self.name}")

    def on_failure(self, context: StageHandlerContext, result: StageHandlerResult) -> None:
        """处理器执行失败时的回调

        可以被子类重写以执行特定的失败处理逻辑。

        Args:
            context: 阶段处理器执行上下文
            result: 执行结果
        """
        self.logger.error(f"处理器失败: {self.name} - {result.message}")

    def get_name(self) -> str:
        """获取处理器名称"""
        return self.name


class HandlerMiddleware(ABC):
    """处理器中间件抽象基类

    中间件可以在处理器执行前、执行中和执行后进行拦截和处理。
    支持链式调用，形成中间件管道。
    """

    def __init__(self, name: str):
        """初始化中间件

        Args:
            name: 中间件名称
        """
        self.name = name
        self.logger = logging.getLogger(f"{__name__}.{name}")
        self.next_middleware: Optional[HandlerMiddleware] = None

    def set_next(self, middleware: "HandlerMiddleware") -> "HandlerMiddleware":
        """设置下一个中间件（链式调用）

        Args:
            middleware: 下一个中间件

        Returns:
            HandlerMiddleware: 返回下一个中间件便于链式调用
        """
        self.next_middleware = middleware
        return middleware

    @abstractmethod
    def before_execute(
        self, context: StageHandlerContext, handler: StageHandler
    ) -> bool:
        """在处理器执行前调用

        Args:
            context: 阶段处理器执行上下文
            handler: 即将执行的处理器

        Returns:
            bool: 是否继续执行处理器（False 则中止）
        """
        pass

    @abstractmethod
    def after_execute(
        self,
        context: StageHandlerContext,
        handler: StageHandler,
        result: StageHandlerResult,
    ) -> StageHandlerResult:
        """在处理器执行后调用

        Args:
            context: 阶段处理器执行上下文
            handler: 已执行的处理器
            result: 处理器执行结果

        Returns:
            StageHandlerResult: 可以修改或替换执行结果
        """
        pass

    def execute_chain(
        self,
        context: StageHandlerContext,
        handler: StageHandler,
        result: StageHandlerResult,
    ) -> StageHandlerResult:
        """执行中间件链

        Args:
            context: 阶段处理器执行上下文
            handler: 处理器
            result: 执行结果

        Returns:
            StageHandlerResult: 最终的执行结果
        """
        result = self.after_execute(context, handler, result)

        if self.next_middleware:
            return self.next_middleware.execute_chain(context, handler, result)

        return result


class LoggingMiddleware(HandlerMiddleware):
    """日志中间件

    记录处理器的执行日志。
    """

    def before_execute(
        self, context: StageHandlerContext, handler: StageHandler
    ) -> bool:
        """记录处理器开始执行"""
        self.logger.info(f"开始执行处理器: {handler.get_name()} (阶段: {context.stage.value})")
        return True

    def after_execute(
        self,
        context: StageHandlerContext,
        handler: StageHandler,
        result: StageHandlerResult,
    ) -> StageHandlerResult:
        """记录处理器执行结果"""
        if result.is_success():
            self.logger.info(
                f"处理器完成: {handler.get_name()} (耗时: {result.duration_seconds:.2f}s)"
            )
        else:
            self.logger.error(
                f"处理器失败: {handler.get_name()} - {result.message}"
            )

        if self.next_middleware:
            return self.next_middleware.execute_chain(context, handler, result)

        return result


class ErrorRecoveryMiddleware(HandlerMiddleware):
    """错误恢复中间件

    在处理器执行失败时尝试恢复。
    """

    def __init__(self, name: str = "error_recovery", max_retries: int = 0):
        """初始化错误恢复中间件

        Args:
            name: 中间件名称
            max_retries: 最大重试次数
        """
        super().__init__(name)
        self.max_retries = max_retries
        self.retry_count = 0

    def before_execute(
        self, context: StageHandlerContext, handler: StageHandler
    ) -> bool:
        """重置重试计数"""
        self.retry_count = 0
        return True

    def after_execute(
        self,
        context: StageHandlerContext,
        handler: StageHandler,
        result: StageHandlerResult,
    ) -> StageHandlerResult:
        """如果失败，尝试重试"""
        if not result.is_success() and self.retry_count < self.max_retries:
            self.retry_count += 1
            self.logger.warning(
                f"处理器失败，进行重试 {self.retry_count}/{self.max_retries}: {handler.get_name()}"
            )
            # 重试执行处理器
            result = handler.execute(context)
            result.message = f"重试 {self.retry_count} 后的结果: {result.message}"

        if self.next_middleware:
            return self.next_middleware.execute_chain(context, handler, result)

        return result


class ValidationMiddleware(HandlerMiddleware):
    """验证中间件

    在处理器执行前验证条件。
    """

    def before_execute(
        self, context: StageHandlerContext, handler: StageHandler
    ) -> bool:
        """验证处理器执行条件"""
        is_valid = handler.validate(context)
        if not is_valid:
            self.logger.error(f"处理器验证失败: {handler.get_name()}")
        return is_valid

    def after_execute(
        self,
        context: StageHandlerContext,
        handler: StageHandler,
        result: StageHandlerResult,
    ) -> StageHandlerResult:
        """执行链中的下一个中间件"""
        if self.next_middleware:
            return self.next_middleware.execute_chain(context, handler, result)
        return result
