"""PipelineV2 - Stage 3 新架构

新一代报告生成管道，完全利用 Stage 1 和 Stage 2 的基础设施：
- 使用 ExecutionContextV2 支持依赖注入
- 使用 StageRegistry 进行动态阶段处理器管理
- 使用 ConfigProvider 进行显式配置注入
- 使用 ExecutionModeStrategy.get_execution_config() 获取类型安全的配置
- 返回 ExecutionResult 而非字典，实现完全类型安全

架构改进：
1. 动态阶段注册：阶段处理器无需硬编码在 _execute_single_stage 中
2. 显式配置注入：所有配置通过 ConfigProvider 显式管理
3. 增强的上下文：ExecutionContextV2 支持依赖注入和状态追踪
4. 类型安全的结果：ExecutionResult 替代字典
5. 策略配置：从 ExecutionModeStrategy.get_execution_config() 获取配置
"""

import json
import logging
import time
from typing import Any, Dict, Optional, Callable, TYPE_CHECKING

from ..core import safe_operation
from .execution_modes.factory import ExecutionModeFactory
from .execution_modes.base import ExecutionStage
from .context import ExecutionContextV2, ExecutionResult
from .stage import StageRegistry
from .config import ConfigProvider
from .config.execution_config import (
    RenderingConfig,
    MapGenerationConfig,
    ExecutionModeConfig,
)

if TYPE_CHECKING:
    from ..main import AeroSpotReportGenerator

logger = logging.getLogger(__name__)


class PipelineV2:
    """PipelineV2 - Stage 3 新一代报告生成管道

    完全基于依赖注入和动态注册的新型管道架构，提供：
    - 动态阶段处理器注册（替代硬编码）
    - 显式配置注入（替代全局状态）
    - 类型安全的执行结果
    - 增强的状态追踪和错误处理
    """

    def __init__(
        self,
        config_path: str,
        output_dir: str,
        cache_enabled: bool = False,
        logger_instance: Optional[logging.Logger] = None,
    ) -> None:
        """初始化 PipelineV2

        Args:
            config_path: 配置文件路径
            output_dir: 输出目录
            cache_enabled: 是否启用缓存
            logger_instance: 日志记录器实例
        """
        self.config_path = config_path
        self.output_dir = output_dir
        self.cache_enabled = cache_enabled
        self.logger = logger_instance or logger

        # 核心组件
        self.generator: Optional["AeroSpotReportGenerator"] = None
        self.strategy = None
        self.context: Optional[ExecutionContextV2] = None
        self.stage_registry = StageRegistry()
        self.config_provider = ConfigProvider()

        # 执行结果（使用新的 ExecutionResult 模型）
        self.execution_result = ExecutionResult()

        # 注册默认的阶段处理器
        self._register_default_stages()

    def _register_default_stages(self) -> None:
        """注册默认的阶段处理器

        这替代了原 pipeline.py 中的 _execute_single_stage 硬编码映射。
        """
        self.stage_registry.register(
            ExecutionStage.INIT,
            self._handle_init,
        )
        self.stage_registry.register(
            ExecutionStage.LOAD_CONFIG,
            self._handle_load_config,
        )
        self.stage_registry.register(
            ExecutionStage.PROCESS_DATA,
            self._handle_process_data,
        )
        self.stage_registry.register(
            ExecutionStage.GENERATE_MAPS,
            self._handle_generate_maps,
        )
        self.stage_registry.register(
            ExecutionStage.SAVE_CONFIG,
            self._handle_save_config,
        )
        self.stage_registry.register(
            ExecutionStage.GENERATE_STRUCTURE,
            self._handle_generate_structure,
        )
        self.stage_registry.register(
            ExecutionStage.GENERATE_REPORT,
            self._handle_generate_report,
        )
        self.stage_registry.register(
            ExecutionStage.TRAIN_MODEL,
            self._handle_train_model,
        )
        self.stage_registry.register(
            ExecutionStage.OUTPUT_RESULT,
            self._handle_output_result,
        )

    @safe_operation(error_msg="PipelineV2 执行失败", default_return=False)
    def execute(self) -> ExecutionResult:
        """执行报告生成流程

        利用新架构的完整流程：
        1. 初始化生成器和执行上下文
        2. 加载配置并选择执行策略
        3. 通过策略获取类型安全的配置对象
        4. 注入配置到 ConfigProvider
        5. 动态执行注册的阶段处理器
        6. 返回类型安全的执行结果

        Returns:
            ExecutionResult: 类型安全的执行结果对象
        """
        start_time = time.time()
        self.execution_result = ExecutionResult()

        try:
            self.logger.info("=" * 60)
            self.logger.info("🚀 启动 PipelineV2 报告生成")
            self.logger.info("=" * 60)

            # Step 1: 初始化生成器
            self.logger.info("[1/9] 初始化报告生成器...")
            self._initialize_generator()
            self.logger.info("✓ 生成器初始化完成")

            # Step 2: 加载配置
            self.logger.info("[2/9] 加载配置文件...")
            if not self.generator.load_config(self.config_path):
                return self._fail("配置文件加载失败", start_time)
            self.logger.info("✓ 配置加载完成")

            # Step 3: 重新创建报告数据
            self.logger.info("[3/9] 构建报告数据...")
            self.generator.create_report_data()
            self.logger.info("✓ 报告数据构建完成")

            # Step 4: 选择执行策略
            execution_mode = (
                self.generator.config_service.get_config().execution_mode or "full"
            )
            self.strategy = ExecutionModeFactory.create(execution_mode)
            self.logger.info(f"✓ 检测到执行模式: {self.strategy.mode_name}")

            # Step 5: 创建增强的执行上下文
            self.context = ExecutionContextV2(
                generator=self.generator,
                config_path=self.config_path,
                output_dir=self.output_dir,
                cache_enabled=self.cache_enabled,
                start_time=start_time,
                stage_registry=self.stage_registry,
                config_provider=self.config_provider,
            )
            self.logger.info("[4/9] 创建执行上下文...")
            self.logger.info(f"✓ 上下文创建完成 (已注入 {len(self.stage_registry.list_stages())} 个阶段处理器)")

            # Step 6: 获取策略的类型安全配置
            self.logger.info("[5/9] 获取策略配置...")
            mode_config = self.strategy.get_execution_config(self.context)
            self._inject_config_to_provider(mode_config)
            self.logger.info(f"✓ 配置注入完成 ({type(mode_config).__name__})")

            # Step 7: 配置策略特定的环境
            self.logger.info("[6/9] 配置执行环境...")
            self.strategy.configure_environment(self.context)
            self._apply_context_configs()
            self.logger.info("✓ 执行环境配置完成")

            # Step 8: 动态执行阶段
            self.logger.info("[7/9] 执行管道阶段...")
            if not self._execute_stages():
                return self._fail("管道阶段执行失败", start_time)
            self.logger.info("✓ 所有阶段执行完成")

            # Step 9: 格式化并返回结果
            self.logger.info("[8/9] 格式化执行结果...")
            output = self.strategy.format_output(self.context)
            self._output_result(output)
            self.logger.info("✓ 结果格式化完成")

            return self._success(start_time)

        except Exception as e:
            self.logger.error(f"PipelineV2 执行异常: {str(e)}", exc_info=True)
            return self._fail(f"异常: {str(e)}", start_time)

    def _inject_config_to_provider(self, mode_config: ExecutionModeConfig) -> None:
        """将策略配置注入到 ConfigProvider

        Args:
            mode_config: 来自策略的 ExecutionModeConfig 实例
        """
        # 注入渲染配置
        if hasattr(mode_config, "rendering_config") and mode_config.rendering_config:
            self.config_provider.set_rendering_config(mode_config.rendering_config)

        # 注入地图生成配置
        if (
            hasattr(mode_config, "map_generation_config")
            and mode_config.map_generation_config
        ):
            self.config_provider.set_map_generation_config(
                mode_config.map_generation_config
            )

        # 注入整个执行模式配置
        self.config_provider.set_execution_mode_config(mode_config)

    def _apply_context_configs(self) -> None:
        """将上下文中的配置应用到生成器

        配置优先级：
        1. context 中已设置的配置（来自 configure_environment()）
        2. ConfigProvider 中的配置（来自执行策略）

        这确保配置能够被下游的编排器和处理器使用。
        """
        try:
            provider = self.context.get_config_provider()

            # 渲染配置优先级处理
            # 优先级 1：context 中已有配置（heatmap_only 等特殊模式在 configure_environment 中设置）
            if hasattr(self.context, 'rendering_config') and self.context.rendering_config is not None:
                self.generator.rendering_config = self.context.rendering_config
                self.logger.debug(
                    f"应用 context 中的渲染配置: "
                    f"font_label={self.context.rendering_config.colorbar_label_font}, "
                    f"font_tick={self.context.rendering_config.colorbar_tick_font}"
                )
            # 优先级 2：从 ConfigProvider 获取配置
            elif provider.has_rendering_config():
                self.generator.rendering_config = provider.get_rendering_config()
                self.logger.debug(
                    f"应用 ConfigProvider 中的渲染配置: "
                    f"font_label={provider.get_rendering_config().colorbar_label_font}, "
                    f"font_tick={provider.get_rendering_config().colorbar_tick_font}"
                )

            # 地图生成配置优先级处理
            # 优先级 1：context 中已有配置
            if hasattr(self.context, 'map_generation_config') and self.context.map_generation_config is not None:
                self.generator.map_generation_config = self.context.map_generation_config
                self.logger.debug(
                    f"应用 context 中的地图生成配置: "
                    f"allowed_types={getattr(self.context.map_generation_config, 'allowed_types', [])}"
                )
            # 优先级 2：从 ConfigProvider 获取配置
            elif provider.has_map_generation_config():
                self.generator.map_generation_config = provider.get_map_generation_config()
                self.logger.debug(
                    f"应用 ConfigProvider 中的地图生成配置: "
                    f"allowed_types={provider.get_map_generation_config().allowed_types}"
                )

        except RuntimeError as e:
            self.logger.warning(f"应用上下文配置时出现问题: {str(e)}")

    def _execute_stages(self) -> bool:
        """动态执行所有必需的阶段

        使用注册表中的处理器替代硬编码的映射。

        Returns:
            bool: 所有阶段是否成功执行
        """
        for stage in self.strategy.required_stages:
            if self.strategy.should_skip_stage(stage, self.context):
                self.logger.debug(f"跳过阶段: {stage.value}")
                continue

            self.logger.info(f"   执行: {stage.value}")
            self.context.set_current_stage(stage)

            try:
                # 从注册表获取处理器
                handler = self.stage_registry.get_handler(stage)
                if not handler:
                    self.logger.warning(f"未找到处理器: {stage.value}")
                    self.context.add_completed_stage(stage)
                    continue

                # 执行处理器
                success = handler()

                if not success:
                    self.logger.error(f"阶段失败: {stage.value}")
                    self.context.mark_stage_failed(
                        stage, Exception(f"Stage {stage.value} failed")
                    )
                    return False

                # 标记阶段完成
                self.context.add_completed_stage(stage)
                self.strategy.on_stage_success(stage, self.context)

            except Exception as e:
                self.logger.error(
                    f"阶段异常: {stage.value} - {str(e)}", exc_info=True
                )
                self.context.mark_stage_failed(stage, e)

                # 调用失败钩子
                if not self.strategy.on_stage_failure(stage, self.context, e):
                    return False

        return True

    # 阶段处理器实现

    def _handle_init(self) -> bool:
        """处理 INIT 阶段"""
        # 初始化已在 __init__ 和 execute() 中完成
        return True

    def _handle_load_config(self) -> bool:
        """处理 LOAD_CONFIG 阶段"""
        # 配置加载已在 execute() 中完成
        return True

    def _handle_process_data(self) -> bool:
        """处理 PROCESS_DATA 阶段"""
        try:
            return self.generator.process_data()
        except Exception as e:
            self.logger.error(f"数据处理失败: {str(e)}", exc_info=True)
            return False

    def _handle_generate_maps(self) -> bool:
        """处理 GENERATE_MAPS 阶段"""
        try:
            return self.generator.generate_indicator_maps()
        except Exception as e:
            self.logger.error(f"地图生成失败: {str(e)}", exc_info=True)
            return False

    def _handle_save_config(self) -> bool:
        """处理 SAVE_CONFIG 阶段"""
        try:
            return self.generator.save_processed_config()
        except Exception as e:
            self.logger.error(f"配置保存失败: {str(e)}", exc_info=True)
            return False

    def _handle_generate_structure(self) -> bool:
        """处理 GENERATE_STRUCTURE 阶段"""
        try:
            config = self.generator.generate_config()
            return bool(config)
        except Exception as e:
            self.logger.error(f"报告结构生成失败: {str(e)}", exc_info=True)
            return False

    def _handle_generate_report(self) -> bool:
        """处理 GENERATE_REPORT 阶段"""
        try:
            config_path = self.generator.get_last_config_path()
            return self.generator.generate_report(config_path)
        except Exception as e:
            self.logger.error(f"报告生成失败: {str(e)}", exc_info=True)
            return False

    def _handle_train_model(self) -> bool:
        """处理 TRAIN_MODEL 阶段"""
        try:
            if hasattr(self.generator, "train_water_quality_models"):
                return self.generator.train_water_quality_models()
            self.logger.warning("模型训练方法未实现")
            return True
        except Exception as e:
            self.logger.error(f"模型训练失败: {str(e)}", exc_info=True)
            return False

    def _handle_output_result(self) -> bool:
        """处理 OUTPUT_RESULT 阶段"""
        # 在 _output_result() 中处理，这里总是成功
        return True

    def _output_result(self, output: Dict[str, Any]) -> None:
        """输出结果（统一JSON输出接口）

        所有模式统一使用JSON输出到stdout，便于外部系统解析结果：
        - heatmap_only: 输出 waterqsvg 兼容的地图JSON
        - full: 输出报告路径、配置路径等元数据

        Args:
            output: 由 strategy.format_output() 返回的结果字典
        """
        try:
            # 统一输出JSON格式到stdout（不使用indent，便于单行处理）
            json_output = json.dumps(output, ensure_ascii=False)
            print(json_output)
            self.logger.debug(f"已输出JSON结果到stdout ({self.strategy.mode_name}模式)")
        except Exception as e:
            self.logger.error(f"输出JSON结果失败: {e}")
            raise

    def _initialize_generator(self) -> None:
        """初始化报告生成器"""
        try:
            from ..main import AeroSpotReportGenerator

            self.generator = AeroSpotReportGenerator(
                output_dir=self.output_dir,
                config=None,
                cache_enabled=self.cache_enabled,
            )
            self.logger.debug("报告生成器初始化成功")
        except Exception as e:
            self.logger.error(f"生成器初始化失败: {str(e)}", exc_info=True)
            raise

    def _success(self, start_time: float) -> ExecutionResult:
        """标记管道执行成功"""
        end_time = time.time()
        duration = end_time - start_time

        self.execution_result.mark_success()
        self.execution_result.message = "报告生成成功"
        self.execution_result.set_path("report", self.generator.output_dir)
        self.execution_result.set_path(
            "config", self.generator.get_last_config_path()
        )
        self.execution_result.end_time = end_time
        self.execution_result.duration_seconds = duration

        self.logger.info("=" * 60)
        self.logger.info("✅ 报告生成成功！")
        self.logger.info(f"   输出目录: {self.generator.output_dir}")
        self.logger.info(f"   耗时: {duration:.1f} 秒")
        self.logger.info(f"   已完成阶段: {len(self.context.completed_stages)}")
        self.logger.info("=" * 60)

        return self.execution_result

    def _fail(self, error_msg: str, start_time: float) -> ExecutionResult:
        """标记管道执行失败"""
        end_time = time.time()
        duration = end_time - start_time

        self.execution_result.mark_failure(error_msg)
        self.execution_result.end_time = end_time
        self.execution_result.duration_seconds = duration

        self.logger.error("=" * 60)
        self.logger.error(f"❌ 报告生成失败: {error_msg}")
        self.logger.error(f"   耗时: {duration:.1f} 秒")
        if self.context:
            self.logger.error(
                f"   已完成阶段: {len(self.context.completed_stages)}"
            )
        self.logger.error("=" * 60)

        return self.execution_result

    # 结果访问接口

    def get_result(self) -> ExecutionResult:
        """获取管道执行结果（ExecutionResult 模型）

        Returns:
            ExecutionResult: 类型安全的执行结果对象
        """
        return self.execution_result

    def get_result_dict(self) -> Dict[str, Any]:
        """获取管道执行结果（字典格式，用于向后兼容）

        Returns:
            Dict[str, Any]: 执行结果字典
        """
        return self.execution_result.to_dict()

    def get_report_path(self) -> Optional[str]:
        """获取生成的报告输出目录路径"""
        return self.execution_result.get_path("report")

    def get_config_path(self) -> Optional[str]:
        """获取生成的报告结构配置文件路径"""
        return self.execution_result.get_path("config")

    def is_success(self) -> bool:
        """检查管道是否成功执行"""
        return self.execution_result.success

    def get_error_message(self) -> Optional[str]:
        """获取执行错误信息"""
        return self.execution_result.error

    def get_duration(self) -> float:
        """获取执行耗时（秒）"""
        return self.execution_result.duration_seconds

    def get_status(self) -> str:
        """获取管道执行状态

        Returns:
            str: "success", "failed", "running", "pending" 之一
        """
        if self.execution_result.success:
            return "success"
        elif self.execution_result.error:
            return "failed"
        elif self.execution_result.start_time:
            return "running"
        else:
            return "pending"

    def get_context_summary(self) -> Dict[str, Any]:
        """获取执行上下文的摘要信息

        Returns:
            Dict[str, Any]: 包含上下文状态的字典
        """
        if not self.context:
            return {"context_available": False}

        return self.context.get_summary()

    def register_stage_handler(
        self, stage: ExecutionStage, handler: Callable[[], bool]
    ) -> None:
        """为特定阶段注册或覆盖处理器

        这允许外部系统扩展或自定义阶段处理逻辑。

        Args:
            stage: 执行阶段
            handler: 处理器函数，返回 bool 表示是否成功

        Raises:
            TypeError: handler 不可调用
            ValueError: stage 已注册过
        """
        try:
            # 尝试覆盖已有的处理器
            self.stage_registry.update(stage, handler)
        except ValueError:
            # 如果不存在，则注册新的
            self.stage_registry.register(stage, handler)
