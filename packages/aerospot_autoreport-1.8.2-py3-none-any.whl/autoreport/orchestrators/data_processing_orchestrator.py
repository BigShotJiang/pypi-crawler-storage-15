#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""数据处理流程编排器

编排和协调数据处理的各个阶段，包括配置验证、UAV数据处理、历史数据匹配和模型优化。
迁移到Phase C：完全使用ReportData模型，无Dict兼容。
"""

import logging
import os
from typing import Any, Dict, Optional

import pandas as pd

from ..core.configuration_service import ConfigurationService
from ..core.models import DataFilesInfo
from ..core.extractor import ZipExtractor
from ..core import DataFileNotFoundError, DataProcessingError
from ..models.report_data import ReportData
from ..models.data_containers import (
    ProcessedDataSet,
    PredictionResults,
    ComparisonResult,
)
from ..processor.data import DataProcessor
from ..processor.data.prediction_saver import PredictionSaver
from ..utils.io import merge_data_files
from ..utils.path import PathManager
from ..core.boundary_manager import BoundaryManager
from .orchestrator import Orchestrator

logger = logging.getLogger(__name__)


class DataProcessingOrchestrator(Orchestrator):
    """数据处理流程编排器

    职责：
    - 验证配置的有效性
    - 解压数据文件并发现关键文件
    - 处理和标准化 UAV 数据
    - 应用地理边界过滤
    - 处理人工采样数据
    - 匹配分析和模型优化

    原始职责来自 AeroSpotReportGenerator 的以下方法：
    - process_data() (主流程)
    - _validate_data_files()
    - _extract_and_discover_files()
    - _find_data_files()
    - _process_uav_data()
    - _apply_boundary_filter()
    - _process_measure_data()
    - _match_analyze_data()

    示例：
        >>> orchestrator = DataProcessingOrchestrator(
        ...     config_service=config_service,
        ...     path_manager=path_manager,
        ...     data_processor=data_processor,
        ...     extractor=extractor,
        ... )
        >>> if orchestrator.process(report_data):
        ...     print("数据处理成功")
        ... else:
        ...     print("数据处理失败")
    """

    def __init__(
        self,
        config_service: ConfigurationService,
        path_manager: PathManager,
        data_processor: DataProcessor,
        extractor: ZipExtractor,
        boundary_manager: Optional[BoundaryManager] = None,
    ) -> None:
        """初始化数据处理编排器

        Args:
            config_service: 配置服务
            path_manager: 路径管理器
            data_processor: 数据处理器
            extractor: ZIP 文件解压器
            boundary_manager: 边界管理器（可选）
        """
        super().__init__()
        self.config_service: ConfigurationService = config_service
        self.path_manager: PathManager = path_manager
        self.data_processor: DataProcessor = data_processor
        self.extractor: ZipExtractor = extractor
        self.boundary_manager: Optional[BoundaryManager] = boundary_manager
        self.logger: logging.Logger = logger

    def process(self, report_data: ReportData) -> ReportData:
        """执行数据处理流程

        执行顺序：
        1. 验证配置有效性
        2. 解压 ZIP 文件并发现数据文件
        3. 处理 UAV 数据
        4. 应用边界过滤
        5. 处理人工采样数据
        6. 匹配分析

        Args:
            report_data: ReportData模型实例

        Returns:
            ReportData: 更新后的模型实例
        """
        return self.execute(report_data)

    def execute(self, data: ReportData) -> ReportData:
        """执行编排流程（Orchestrator 接口实现）

        实现了 Orchestrator 抽象基类的 execute 方法。

        直接使用强类型 ReportData 模型，消除 Dict 工作字典。

        Args:
            data: ReportData模型实例

        Returns:
            ReportData: 更新后的模型实例
        """
        try:
            self.logger.info("=" * 60)
            self.logger.info("启动数据处理流程")
            self.logger.info("=" * 60)

            data.update_processing_state("processing")

            # 步骤 1：验证配置
            if not self._validate_data_files():
                data.update_processing_state("failed", "配置验证失败")
                return data

            # 步骤 2：解压并发现文件
            files_info = self._extract_and_discover_files()
            if not files_info.is_valid():
                error_msg = (
                    f"未找到必需的数据文件。INDEXS.CSV: {files_info.indices_file}, "
                    f"POS.TXT: {files_info.pos_file}"
                )
                data.update_processing_state("failed", error_msg)
                raise DataFileNotFoundError(error_msg)

            # 步骤 3：处理 UAV 数据（直接操作 ReportData）
            indices_file: str = files_info.indices_file  # type: ignore
            pos_file: str = files_info.pos_file  # type: ignore
            ref_files = files_info.ref_files

            self._process_uav_data(data, indices_file, pos_file, ref_files)

            # 步骤 4：应用边界过滤（直接操作 ReportData）
            self._apply_boundary_filter(data)

            # 步骤 5：处理人工采样数据（直接操作 ReportData）
            self._process_measure_data(data)

            # 步骤 6：匹配分析（直接操作 ReportData）
            self._match_analyze_data(data)

            self.logger.info("=" * 60)
            self.logger.info("数据处理流程完成")
            self.logger.info("=" * 60)
            data.update_processing_state("success")
            return data

        except Exception as e:
            self.logger.exception(f"数据处理异常: {e}")
            data.update_processing_state("failed", str(e))
            return data

    def validate_input(self, data: ReportData) -> bool:
        """验证输入数据的有效性（Orchestrator 接口实现）

        检查 ReportData 是否包含执行数据处理所需的基本信息。

        Args:
            data: 需要验证的报告数据模型

        Returns:
            bool: 验证通过返回 True；失败返回 False
        """
        if data is None:
            self.logger.error("输入数据为 None")
            return False

        if data.config is None:
            self.logger.error("配置信息缺失")
            return False

        return True

    def _validate_data_files(self) -> bool:
        """验证数据处理前置条件

        Returns:
            bool: 验证通过返回 True；失败返回 False
        """
        try:
            if self.config_service is None:
                self.logger.error("配置服务未初始化")
                return False

            company_info = self.config_service.get_company_info()
            if company_info is None:
                self.logger.error("无法获取公司配置信息")
                return False

            self.logger.info("✓ 配置验证通过")
            return True
        except Exception as e:
            self.logger.exception(f"配置验证异常: {e}")
            return False

    def _extract_and_discover_files(self) -> DataFilesInfo:
        """解压 ZIP 文件并发现数据文件

        Returns:
            DataFilesInfo: 发现的数据文件信息
        """
        try:
            company_info = self.config_service.get_company_info()
            zip_path = company_info.file_url

            if not zip_path or not os.path.exists(zip_path):
                raise DataFileNotFoundError(f"数据文件未找到: {zip_path}")

            self.logger.info(f"开始解压文件: {zip_path}")
            extract_dir = self.extractor.extract(zip_path)
            if not extract_dir:
                raise DataProcessingError("解压文件失败")

            self.logger.info(f"文件解压至: {extract_dir}")

            files_info = self._find_data_files(extract_dir)
            self.logger.info(
                f"发现数据文件 - INDEXS: {files_info.indices_file}, "
                f"POS: {files_info.pos_file}, REFL: {len(files_info.ref_files)}"
            )

            return files_info
        except Exception as e:
            self.logger.exception(f"文件解压异常: {e}")
            raise

    def _find_data_files(self, extract_dir: str) -> DataFilesInfo:
        """查找解压目录中的数据文件

        Args:
            extract_dir: 解压目录

        Returns:
            DataFilesInfo: 包含发现的数据文件路径的对象
        """
        indices_file = None
        pos_file = None
        ref_files = []

        for root, _, files in os.walk(extract_dir):
            for filename in files:
                full_path = os.path.join(root, filename)
                if full_path.upper().endswith("INDEXS.CSV"):
                    indices_file = full_path
                elif full_path.upper().endswith("POS.TXT"):
                    pos_file = full_path
                elif "REFL" in full_path:
                    ref_files.append(full_path)

        return DataFilesInfo(
            extract_dir=extract_dir,
            indices_file=indices_file,
            pos_file=pos_file,
            ref_files=ref_files,
        )

    def _process_uav_data(
        self,
        data: ReportData,
        indices_file: str,
        pos_file: str,
        ref_files: list[str],
    ) -> None:
        """处理 UAV 数据

        直接操作 ReportData，消除 Dict 中间层。

        Args:
            data: 报告数据模型
            indices_file: INDEXS.CSV 文件路径
            pos_file: POS.TXT 文件路径
            ref_files: REFL 光谱数据文件路径列表
        """
        try:
            # 参数验证
            if not isinstance(ref_files, list):
                raise TypeError(
                    f"ref_files must be list[str], got {type(ref_files).__name__}"
                )

            # 合并数据文件
            self.logger.info("合并 UAV 数据文件...")
            raw_uav_data = merge_data_files(indices_file, pos_file)
            if raw_uav_data.empty:
                raise DataProcessingError("数据合并结果为空")

            # 清洗合并后的反演值数据
            processed_merged_data = self.data_processor.process_data(raw_uav_data)
            if not processed_merged_data:
                raise DataProcessingError("无人机反演数据样本收集失败")

            # 创建 ProcessedDataSet 并直接设置到 ReportData
            uav_df = processed_merged_data["processed_data"]
            data.uav_data = ProcessedDataSet.from_dataframe(uav_df)
            self.logger.info(
                f"UAV 反演数据收集完成，样本量：{len(uav_df)}"
            )
            uav_df.to_csv(
                self.path_manager.get_file_path("uav_data", "uav.csv")
            )
            self.logger.info(
                f"UAV 反演结果保存至：{self.path_manager.get_file_path('uav_data', 'uav.csv')}"
            )

            # 收集光谱数据
            if ref_files:
                ref_files.sort(
                    key=lambda x: int(os.path.basename(x).split("_")[-1].split(".")[0])
                )
                spectrum_data = pd.DataFrame()
                for ref_file in ref_files:
                    single_spectrum_data = (
                        pd.read_csv(ref_file, encoding="utf-8", header=0, index_col=0)
                        .iloc[:, [0]]
                        .T
                    )
                    single_spectrum_data.index = [
                        os.path.basename(ref_file).split("_")[-1].split(".")[0]
                    ]
                    spectrum_data = pd.concat([spectrum_data, single_spectrum_data], axis=0)

                self.logger.info(
                    f"光谱数据包含 {len(spectrum_data)} 行和 {len(spectrum_data.columns)} 列"
                )

                # 索引对齐
                if len(uav_df) != len(spectrum_data):
                    self.logger.warning(
                        f"UAV 样本数 ({len(uav_df)}) "
                        f"与光谱样本数 ({len(spectrum_data)}) 不匹配，正在对齐..."
                    )
                    common_index = uav_df.index.intersection(spectrum_data.index)
                    aligned_uav_data = uav_df.loc[common_index]
                    aligned_spectrum_data = spectrum_data.loc[common_index]

                    # 重新创建 ProcessedDataSet 并设置到 ReportData
                    data.uav_data = ProcessedDataSet.from_dataframe(aligned_uav_data)
                    self.logger.info(f"对齐完成：保留 {len(common_index)} 条样本")

                    spectrum_data = aligned_spectrum_data

                # 直接设置 spectrum_data 到 ReportData
                data.spectrum_data = spectrum_data
                spectrum_data.to_csv(
                    self.path_manager.get_file_path("uav_data", "spectrum_data.csv")
                )
                self.logger.info(
                    f"光谱数据保存至：{self.path_manager.get_file_path('uav_data', 'spectrum_data.csv')}"
                )

        except Exception as e:
            self.logger.exception(f"UAV 数据处理异常: {e}")
            raise

    def _apply_boundary_filter(self, data: ReportData) -> bool:
        """应用边界掩膜过滤到 UAV 数据

        重要：过滤 uav_data 时，必须同步过滤 spectrum_data 以保持索引对齐。

        直接操作 ReportData，消除 Dict 中间层。

        Args:
            data: 报告数据模型

        Returns:
            bool: 过滤成功或跳过时返回 True
        """
        try:
            if not (self.boundary_manager and self.boundary_manager.is_enabled):
                self.logger.debug("边界管理器未启用，跳过 UAV 数据过滤")
                return True

            # 检查是否有 uav_data
            if data.uav_data is None or data.uav_data.data is None or data.uav_data.data.empty:
                self.logger.info("无 UAV 数据，跳过边界过滤")
                return True

            uav_df = data.uav_data.data
            filtered_data, mask = self.boundary_manager.filter_dataframe(
                uav_df, lon_col="Longitude", lat_col="Latitude"
            )

            # 更新 uav_data（重新创建 ProcessedDataSet）
            data.uav_data = ProcessedDataSet.from_dataframe(filtered_data)
            self.logger.info(
                f"UAV 数据已过滤：保留 {len(filtered_data)}/{len(uav_df)} 个点"
            )

            # 关键：同步过滤 spectrum_data 以保持索引对齐
            if data.spectrum_data is not None and not data.spectrum_data.empty:
                filtered_spectrum_data = data.spectrum_data.loc[filtered_data.index]
                data.spectrum_data = filtered_spectrum_data
                self.logger.info(
                    f"光谱数据已同步过滤：保留 {len(filtered_spectrum_data)}/{len(data.spectrum_data)} 个样本"
                )

            return True
        except Exception as e:
            self.logger.exception(f"过滤 UAV 数据时出错: {e}")
            return False

    def _process_measure_data(self, data: ReportData) -> None:
        """处理人工采样数据（如果有）

        人工采样数据是可选的，处理失败不影响整体流程。

        直接操作 ReportData，消除 Dict 中间层。

        Args:
            data: 报告数据模型
        """
        try:
            company_info = self.config_service.get_company_info()
            measure_data_path = company_info.measure_data

            if not measure_data_path or not os.path.exists(measure_data_path):
                self.logger.info("未找到人工采样数据，跳过处理")
                return

            self.logger.info(f"开始处理人工采样数据: {measure_data_path}")

            # 读取人工采样数据
            measure_df = pd.read_csv(
                measure_data_path, encoding="utf-8", header=0, index_col=0
            )

            # 处理人工采样数据
            processed_measure_data = self.data_processor.process_data(measure_df)
            if not processed_measure_data:
                raise DataProcessingError("人工采样数据处理失败")

            # 创建 ProcessedDataSet 并直接设置到 ReportData
            measure_df = processed_measure_data["processed_data"]
            data.measure_data = ProcessedDataSet.from_dataframe(measure_df)
            self.logger.info("人工采样数据处理完成")

        except FileNotFoundError:
            self.logger.warning(f"人工采样数据文件不存在: {measure_data_path}")
        except (pd.errors.ParserError, pd.errors.EmptyDataError) as e:
            self.logger.warning(f"无法解析人工采样数据 CSV 文件: {e}")
        except DataProcessingError as e:
            self.logger.warning(f"人工采样数据处理失败，跳过此步骤: {e}")
        except KeyError as e:
            self.logger.warning(f"人工采样数据缺少必需的列: {e}")
        except (OSError, UnicodeDecodeError, ValueError) as e:
            self.logger.error(f"处理人工采样数据时发生错误: {e}", exc_info=True)

    def _match_analyze_data(self, data: ReportData) -> None:
        """匹配分析数据

        对 UAV 数据和测量数据进行匹配和模型优化。

        直接操作 ReportData，消除 Dict 中间层。

        Args:
            data: 报告数据模型
        """
        try:
            # 路径 A：有测量数据，执行完整建模
            if (
                data.uav_data is not None
                and data.spectrum_data is not None
                and data.measure_data is not None
            ):
                self.logger.info("检测到测量数据，执行完整建模...")
                self._execute_full_modeling(data)

            # 路径 B：只有 UAV 数据，尝试使用 bin 模型优化
            elif data.uav_data is not None and data.spectrum_data is not None:
                self.logger.info("只有 UAV 数据，尝试使用预训练模型...")
                self._execute_bin_model_optimization(data)

            else:
                self.logger.info("无法执行匹配分析，跳过此步骤")

        except Exception as e:
            self.logger.warning(f"匹配分析失败，继续执行: {e}")

    def _execute_full_modeling(self, data: ReportData) -> None:
        """执行完整建模流程

        直接操作 ReportData，消除 Dict 中间层。

        Args:
            data: 报告数据模型
        """
        # 提取数据
        assert data.uav_data is not None and data.uav_data.data is not None
        assert data.measure_data is not None and data.measure_data.data is not None
        assert data.spectrum_data is not None

        processed_uav_data = data.uav_data.data
        measure_data = data.measure_data.data
        spectrum_data = data.spectrum_data

        # 加载历史建模数据
        historical_ref = None
        historical_merged = None
        historical_measure = None

        company_info = self.config_service.get_company_info()
        historical_data = getattr(company_info, "historical_data", None)

        if historical_data:
            try:
                from ..processor.data.save_history import HistoryDataBundle

                his_instance = HistoryDataBundle.load_from_file(historical_data)
                historical_ref = his_instance.ref_df
                historical_merged = his_instance.merged_df
                historical_measure = his_instance.measure_df

                if not historical_ref.columns.equals(spectrum_data.columns):
                    self.logger.warning(
                        "历史数据光谱波段不匹配，将只使用此次数据进行建模"
                    )
                    historical_ref = None
                    historical_merged = None
                    historical_measure = None
                else:
                    self.logger.info(
                        f"成功加载历史数据，共 {len(historical_ref)} 条记录"
                    )
            except Exception as e:
                self.logger.warning(f"加载历史数据失败: {e}")

        # 执行匹配建模
        (
            comparison_data,
            pred_data,
            model_func,
            all_pred_data,
            his_instance,
        ) = self.data_processor.match_and_analyze_data(
            processed_uav_data,
            measure_data,
            spectrum_data,
            historical_ref,
            historical_merged,
            historical_measure,
        )

        # 保存结果
        saver = PredictionSaver()
        saver.save_predictions(
            all_pred_data,
            self.path_manager.get_file_path("predict", "predict_result.csv"),
        )
        self.logger.info("模型优化结果已保存")

        historical_data_path = self.path_manager.get_file_path(
            "models", "historical_data.h5"
        )
        saver.save_history(his_instance, historical_data_path)
        self.logger.info(f"历史数据已保存至：{historical_data_path}")

        # 提前保存模型（在此处保存，而非延迟到管道最后）
        model_bin_path = None
        if model_func:
            model_bin_path = self.path_manager.get_file_path("models", "model.bin")
            model_saved = saver.save_model(
                model_func=model_func,
                output_path=model_bin_path,
                password=b"water_quality_analysis_key",  # 编译时嵌入
                salt=b"water_quality_salt",
                iv=b"fixed_iv_16bytes",
            )
            if model_saved:
                self.logger.info(f"✓ 模型已加密保存至：{model_bin_path}")
            else:
                self.logger.warning("⚠️ 模型加密保存失败，但继续处理其他步骤")
        else:
            self.logger.info("模型为空，跳过模型保存")

        # 创建 PredictionResults 并设置到 ReportData
        data.prediction_results = PredictionResults(
            all_pred_data=all_pred_data,
            pred_data=pred_data,
            comparison_data=comparison_data,
            model_func=model_func,
            model_bin_path=model_bin_path,
            training_metadata={
                "historical_data_path": historical_data_path,
                "has_historical_data": his_instance is not None,
            },
        )

        # 如果有对比数据，创建 ComparisonResult
        if comparison_data:
            data.comparison_results = ComparisonResult(
                matched_points=comparison_data.get("matched_points", []),
                indicator_comparisons=comparison_data.get("indicators", {}),
                overall_statistics=comparison_data.get("overall", {}),
            )

        # 保存历史数据路径到 config 以保持向后兼容
        data.config["historical_data_path"] = historical_data_path
        if model_bin_path:
            data.config["model_bin_path"] = model_bin_path

    def _execute_bin_model_optimization(self, data: ReportData) -> None:
        """执行 BIN 模型优化

        直接操作 ReportData，消除 Dict 中间层。

        Args:
            data: 报告数据模型
        """
        try:
            from autowaterqualitymodeler.utils.encryption import decrypt_file
            from autowaterqualitymodeler.core.model import WaterQualityModel

            assert data.uav_data is not None and data.uav_data.data is not None
            assert data.spectrum_data is not None

            company_info = self.config_service.get_company_info()
            bin_url = getattr(company_info, "bin_url", None)

            if not bin_url:
                self.logger.debug("未配置 BIN 模型，跳过优化")
                return

            self.logger.info("使用 BIN 模型进行优化...")
            bin_data = decrypt_file(bin_url)
            modeler = WaterQualityModel(bin_data)

            uav_df = data.uav_data.data
            new_uav_data = modeler.predict_unified(data.spectrum_data, uav_df)

            old_uav_data = uav_df.copy()
            for col_name in new_uav_data.columns.tolist():
                old_uav_data[col_name] = new_uav_data[col_name]

            # 重新创建 ProcessedDataSet 并设置到 ReportData
            data.uav_data = ProcessedDataSet.from_dataframe(old_uav_data)
            old_uav_data.to_csv(
                self.path_manager.get_file_path("uav_data", "bin_uav.csv")
            )
            self.logger.info("BIN 模型优化完成")

        except Exception as e:
            self.logger.warning(f"BIN 模型优化失败: {e}")
