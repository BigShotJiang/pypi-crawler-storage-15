"""性能追踪系统 - Stage 6 性能优化

提供详细的性能监控和分析功能。
"""

import time
import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
from datetime import datetime

logger = logging.getLogger(__name__)


@dataclass
class PerformanceMetric:
    """性能指标

    记录单个操作的性能数据。
    """
    name: str
    start_time: float
    end_time: Optional[float] = None
    duration_seconds: float = 0.0
    memory_start: Optional[int] = None
    memory_end: Optional[int] = None
    memory_delta: int = 0
    status: str = "running"  # running, completed, failed
    error: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def complete(self) -> None:
        """标记为完成"""
        self.end_time = time.time()
        self.duration_seconds = self.end_time - self.start_time
        self.status = "completed"

    def fail(self, error: str) -> None:
        """标记为失败"""
        self.end_time = time.time()
        self.duration_seconds = self.end_time - self.start_time
        self.status = "failed"
        self.error = error

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "name": self.name,
            "duration_seconds": self.duration_seconds,
            "status": self.status,
            "error": self.error,
            "memory_delta": self.memory_delta,
            "metadata": self.metadata,
        }


class PerformanceTracker:
    """性能追踪器

    追踪和分析执行性能。
    """

    def __init__(self):
        """初始化性能追踪器"""
        self.metrics: List[PerformanceMetric] = []
        self._current_metric: Optional[PerformanceMetric] = None
        self.logger = logging.getLogger(__name__)

    def start(self, name: str, metadata: Optional[Dict[str, Any]] = None) -> PerformanceMetric:
        """开始追踪一个操作

        Args:
            name: 操作名称
            metadata: 元数据

        Returns:
            PerformanceMetric: 性能指标对象
        """
        metric = PerformanceMetric(
            name=name,
            start_time=time.time(),
            metadata=metadata or {},
        )

        self.metrics.append(metric)
        self._current_metric = metric

        self.logger.debug(f"开始追踪: {name}")

        return metric

    def end(self, metric: Optional[PerformanceMetric] = None) -> None:
        """结束追踪一个操作

        Args:
            metric: 性能指标对象（如果为None，则使用当前指标）
        """
        target_metric = metric or self._current_metric

        if target_metric is None:
            self.logger.warning("没有活跃的性能指标")
            return

        target_metric.complete()
        self.logger.debug(
            f"追踪完成: {target_metric.name} (耗时: {target_metric.duration_seconds:.3f}s)"
        )

    def fail(self, error: str, metric: Optional[PerformanceMetric] = None) -> None:
        """标记追踪失败

        Args:
            error: 错误信息
            metric: 性能指标对象
        """
        target_metric = metric or self._current_metric

        if target_metric is None:
            self.logger.warning("没有活跃的性能指标")
            return

        target_metric.fail(error)
        self.logger.error(f"追踪失败: {target_metric.name} - {error}")

    def get_metrics(self) -> List[PerformanceMetric]:
        """获取所有性能指标

        Returns:
            List[PerformanceMetric]: 性能指标列表
        """
        return self.metrics.copy()

    def get_summary(self) -> Dict[str, Any]:
        """获取性能汇总

        Returns:
            Dict[str, Any]: 汇总信息
        """
        if not self.metrics:
            return {
                "total_operations": 0,
                "total_duration": 0.0,
            }

        completed = [m for m in self.metrics if m.status == "completed"]
        failed = [m for m in self.metrics if m.status == "failed"]

        total_duration = sum(m.duration_seconds for m in self.metrics)
        avg_duration = total_duration / len(self.metrics) if self.metrics else 0

        slowest = max(self.metrics, key=lambda m: m.duration_seconds) if self.metrics else None
        fastest = min(
            completed,
            key=lambda m: m.duration_seconds,
        ) if completed else None

        return {
            "total_operations": len(self.metrics),
            "completed_operations": len(completed),
            "failed_operations": len(failed),
            "total_duration": total_duration,
            "average_duration": avg_duration,
            "slowest_operation": {
                "name": slowest.name,
                "duration": slowest.duration_seconds,
            } if slowest else None,
            "fastest_operation": {
                "name": fastest.name,
                "duration": fastest.duration_seconds,
            } if fastest else None,
        }

    def get_operation_summary(self, name: str) -> Dict[str, Any]:
        """获取特定操作的汇总

        Args:
            name: 操作名称

        Returns:
            Dict[str, Any]: 操作汇总
        """
        matching = [m for m in self.metrics if m.name == name]

        if not matching:
            return {"count": 0}

        completed = [m for m in matching if m.status == "completed"]
        total_duration = sum(m.duration_seconds for m in completed)

        return {
            "name": name,
            "count": len(matching),
            "completed": len(completed),
            "failed": len(matching) - len(completed),
            "total_duration": total_duration,
            "average_duration": total_duration / len(completed) if completed else 0,
            "min_duration": min((m.duration_seconds for m in completed), default=0),
            "max_duration": max((m.duration_seconds for m in completed), default=0),
        }

    def clear(self) -> None:
        """清除所有指标"""
        self.metrics.clear()
        self._current_metric = None
        self.logger.info("已清除所有性能指标")

    def report(self) -> str:
        """生成性能报告

        Returns:
            str: 性能报告文本
        """
        summary = self.get_summary()

        report_lines = [
            "=" * 60,
            "性能报告",
            "=" * 60,
            f"总操作数: {summary['total_operations']}",
            f"完成操作: {summary['completed_operations']}",
            f"失败操作: {summary['failed_operations']}",
            f"总耗时: {summary['total_duration']:.2f}s",
            f"平均耗时: {summary['average_duration']:.3f}s",
        ]

        if summary["slowest_operation"]:
            report_lines.append(
                f"最慢操作: {summary['slowest_operation']['name']} "
                f"({summary['slowest_operation']['duration']:.3f}s)"
            )

        if summary["fastest_operation"]:
            report_lines.append(
                f"最快操作: {summary['fastest_operation']['name']} "
                f"({summary['fastest_operation']['duration']:.3f}s)"
            )

        report_lines.append("=" * 60)

        return "\n".join(report_lines)


class PerformanceContext:
    """性能追踪上下文管理器

    使用 with 语句简化性能追踪。

    使用方式：
    ```python
    tracker = PerformanceTracker()

    with PerformanceContext(tracker, "operation_name"):
        # 执行操作
        pass
    ```
    """

    def __init__(
        self,
        tracker: PerformanceTracker,
        name: str,
        metadata: Optional[Dict[str, Any]] = None,
    ):
        """初始化性能追踪上下文

        Args:
            tracker: 性能追踪器实例
            name: 操作名称
            metadata: 元数据
        """
        self.tracker = tracker
        self.name = name
        self.metadata = metadata
        self.metric: Optional[PerformanceMetric] = None

    def __enter__(self) -> "PerformanceContext":
        """进入上下文"""
        self.metric = self.tracker.start(self.name, self.metadata)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """退出上下文"""
        if exc_type is not None:
            self.tracker.fail(str(exc_val), self.metric)
        else:
            self.tracker.end(self.metric)

        # 不抑制异常
        return False
