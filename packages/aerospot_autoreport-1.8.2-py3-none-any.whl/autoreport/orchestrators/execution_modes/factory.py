from typing import Dict, Type, Optional, Any
from .base import ExecutionModeStrategy
from .full_report import FullReportStrategy
from .heatmap_only import HeatmapOnlyStrategy
from .modeling_only import ModelingOnlyStrategy
from ..config.execution_config import ExecutionModeConfig


class ExecutionModeFactory:
    """执行模式工厂（Stage 2 改进）

    支持创建执行模式策略实例，并支持配置覆盖和组合。

    Stage 2 新增功能：
    - create_with_config(): 使用指定配置创建策略
    - create_with_dict(): 使用配置字典创建策略
    - create_default(): 显式创建带默认配置的策略
    """

    _strategies: Dict[str, Type[ExecutionModeStrategy]] = {
        "full": FullReportStrategy,
        "heatmap_only": HeatmapOnlyStrategy,
        "modeling_only": ModelingOnlyStrategy,
    }

    @classmethod
    def create(cls, mode_name: str) -> ExecutionModeStrategy:
        """创建执行模式策略实例（使用默认配置）

        Args:
            mode_name: 模式名称（"full", "heatmap_only", "modeling_only"）

        Returns:
            ExecutionModeStrategy: 策略实例

        Raises:
            ValueError: 不支持的模式名称
        """
        return cls.create_default(mode_name)

    @classmethod
    def create_default(cls, mode_name: str) -> ExecutionModeStrategy:
        """创建执行模式策略实例（显式使用默认配置）

        Args:
            mode_name: 模式名称

        Returns:
            ExecutionModeStrategy: 带默认配置的策略实例

        Raises:
            ValueError: 不支持的模式名称
        """
        strategy_class = cls._strategies.get(mode_name)
        if not strategy_class:
            raise ValueError(
                f"不支持的执行模式: {mode_name}. "
                f"支持的模式: {list(cls._strategies.keys())}"
            )
        return strategy_class()

    @classmethod
    def create_with_config(
        cls,
        mode_name: str,
        config: ExecutionModeConfig,
    ) -> ExecutionModeStrategy:
        """创建执行模式策略实例（使用指定配置）

        Args:
            mode_name: 模式名称
            config: ExecutionModeConfig 的子类实例

        Returns:
            ExecutionModeStrategy: 带指定配置的策略实例

        Raises:
            ValueError: 不支持的模式名称或配置类型不匹配
        """
        if not isinstance(config, ExecutionModeConfig):
            raise TypeError(
                f"配置必须是 ExecutionModeConfig 的子类实例，"
                f"收到: {type(config)}"
            )

        strategy_class = cls._strategies.get(mode_name)
        if not strategy_class:
            raise ValueError(
                f"不支持的执行模式: {mode_name}. "
                f"支持的模式: {list(cls._strategies.keys())}"
            )

        return strategy_class(config=config)

    @classmethod
    def create_with_dict(
        cls,
        mode_name: str,
        config_dict: Dict[str, Any],
    ) -> ExecutionModeStrategy:
        """创建执行模式策略实例（使用配置字典）

        Args:
            mode_name: 模式名称
            config_dict: 配置字典，将通过对应的 ExecutionModeConfig.from_dict() 转换

        Returns:
            ExecutionModeStrategy: 带指定配置的策略实例

        Raises:
            ValueError: 不支持的模式名称
            KeyError: 配置字典缺少必需的字段
        """
        strategy_class = cls._strategies.get(mode_name)
        if not strategy_class:
            raise ValueError(
                f"不支持的执行模式: {mode_name}. "
                f"支持的模式: {list(cls._strategies.keys())}"
            )

        # 根据模式名称选择相应的 Config 类
        config_map = {
            "full": "FullReportConfig",
            "heatmap_only": "HeatmapOnlyConfig",
            "modeling_only": "ModelingOnlyConfig",
        }
        config_class_name = config_map.get(mode_name)

        # 动态导入对应的配置类
        if config_class_name == "FullReportConfig":
            from ..config.execution_config import FullReportConfig
            config = FullReportConfig.from_dict(config_dict)
        elif config_class_name == "HeatmapOnlyConfig":
            from ..config.execution_config import HeatmapOnlyConfig
            config = HeatmapOnlyConfig.from_dict(config_dict)
        elif config_class_name == "ModelingOnlyConfig":
            from ..config.execution_config import ModelingOnlyConfig
            config = ModelingOnlyConfig.from_dict(config_dict)
        else:
            raise ValueError(f"未知的模式: {mode_name}")

        return strategy_class(config=config)

    @classmethod
    def register(
        cls,
        mode_name: str,
        strategy_class: Type[ExecutionModeStrategy],
    ) -> None:
        """注册新的执行模式（支持插件扩展）

        Args:
            mode_name: 模式名称
            strategy_class: ExecutionModeStrategy 的子类

        Raises:
            TypeError: strategy_class 不是 ExecutionModeStrategy 的子类
        """
        if not issubclass(strategy_class, ExecutionModeStrategy):
            raise TypeError(
                f"strategy_class 必须是 ExecutionModeStrategy 的子类，"
                f"收到: {strategy_class}"
            )
        cls._strategies[mode_name] = strategy_class

    @classmethod
    def list_modes(cls) -> list:
        """列出所有支持的模式

        Returns:
            list: 支持的模式名称列表
        """
        return list(cls._strategies.keys())