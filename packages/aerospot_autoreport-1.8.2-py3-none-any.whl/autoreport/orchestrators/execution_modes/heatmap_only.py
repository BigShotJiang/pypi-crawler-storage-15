from .base import ExecutionModeStrategy, ExecutionStage, ExecutionContext
from .configs import RenderingConfig, MapGenerationConfig
from ..config.execution_config import HeatmapOnlyConfig, ExecutionModeConfig
from typing import List, Dict, Any
from ...formatters import HeatmapOutputFormatter


class HeatmapOnlyStrategy(ExecutionModeStrategy):
    """热力图仅生成模式（waterqsvg 兼容）

    此模式专注于热力图生成，用于向 waterqsvg 等下游系统提供可视化结果。

    包含的阶段：
    1. INIT - 初始化
    2. LOAD_CONFIG - 加载配置
    3. PROCESS_DATA - 数据处理
    4. GENERATE_MAPS - 生成热力图（跳过报告生成）
    5. OUTPUT_RESULT - 输出结果

    特点：
    - 使用大字体以适应 waterqsvg 展示
    - 仅生成 clean_interpolation_svg 类型的热力图
    - 生成独立的 colorbar 文件
    """

    def __init__(self, config: HeatmapOnlyConfig = None):
        """初始化热力图仅生成策略

        Args:
            config: HeatmapOnlyConfig 实例，如果为 None 使用默认值
        """
        self._config = config or HeatmapOnlyConfig()

    @property
    def mode_name(self) -> str:
        """返回模式名称"""
        return "heatmap_only"

    @property
    def required_stages(self) -> List[ExecutionStage]:
        """返回该模式需要执行的阶段"""
        return [
            ExecutionStage.INIT,
            ExecutionStage.LOAD_CONFIG,
            ExecutionStage.PROCESS_DATA,
            ExecutionStage.GENERATE_MAPS,  # 只生成热力图
            ExecutionStage.OUTPUT_RESULT,  # 输出 JSON
        ]

    def get_execution_config(self, context: ExecutionContext) -> ExecutionModeConfig:
        """获取热力图仅生成模式的配置（Stage 2 新增）

        Returns:
            HeatmapOnlyConfig 实例，包含该模式的所有配置参数
        """
        return self._config

    def configure_environment(self, context: ExecutionContext) -> None:
        """配置 waterqsvg 兼容的大字体和地图生成参数

        使用显式配置对象替代全局状态修改和动态属性设置

        参数与waterqsvg严格一致：
        - colorbar_label_font=48: 标签字体大小
        - colorbar_tick_font=48: 刻度字体大小
        - dpi=150: 分辨率（waterqsvg标准）
        - figsize=(10, 8): SVG热力图尺寸
        """
        # 创建并设置渲染配置（替代修改全局状态）
        context.rendering_config = RenderingConfig(
            colorbar_label_font=48,
            colorbar_tick_font=48,
            title_font=60,
            dpi=150,  # ✓ 改为 150 以与 waterqsvg 一致
            figsize=(10, 8)
        )

        # 创建并设置地图生成配置（替代动态设置属性）
        context.map_generation_config = MapGenerationConfig(
            allowed_types=["clean_interpolation_svg"],
            generate_standalone_colorbar=True,
            interpolation_method="kriging",
            boundary_detection_method="alpha_shape"
        )

    def format_output(self, context: ExecutionContext) -> Dict[str, Any]:
        """格式化为 waterqsvg 兼容的 JSON

        Returns:
            包含热力图的 waterqsvg 兼容 JSON 字典
        """
        return HeatmapOutputFormatter.format_maps_to_output(
            maps=context.generator.report_data.maps,
            report_data=context.generator.report_data,
        )