#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""报告生成管道

提供统一的报告生成流程入口，协调所有编排器的执行。
支持外部系统集成，提供完整的流程控制和进度反馈。
支持多种执行模式：完整报告生成、热力图仅生成等。
"""

import json
import logging
import time
from typing import Any, Dict, Optional, TYPE_CHECKING

from ..core import safe_operation
from .execution_modes.factory import ExecutionModeFactory
from .execution_modes.base import ExecutionContext, ExecutionStage

if TYPE_CHECKING:
    from ..main import AeroSpotReportGenerator

logger = logging.getLogger(__name__)


class ReportGenerationPipeline:
    """报告生成管道 - 策略模式驱动"""

    def __init__(
        self,
        config_path: str,
        output_dir: str,
        cache_enabled: bool = False,
        logger_instance: Optional[logging.Logger] = None,
    ) -> None:
        """初始化报告生成管道"""
        self.config_path = config_path
        self.output_dir = output_dir
        self.cache_enabled = cache_enabled
        self.logger = logger_instance or logger

        self.generator: Optional["AeroSpotReportGenerator"] = None
        self.strategy = None

        self.execution_result: Dict[str, Any] = {
            "success": False,
            "report_path": None,
            "config_path": None,
            "error": None,
            "start_time": None,
            "end_time": None,
            "duration_seconds": 0.0,
        }

    @safe_operation(error_msg="管道执行失败", default_return=False)
    def execute(self) -> bool:
        """执行报告生成流程（策略驱动）

        根据配置中的execution_mode字段选择执行策略：
        - "heatmap_only": 仅生成热力图并输出JSON
        - "full" (默认): 生成完整的报告文档
        """
        start_time = time.time()
        self.execution_result["start_time"] = start_time

        try:
            self.logger.info("=" * 60)
            self.logger.info("启动报告生成管道")
            self.logger.info("=" * 60)

            # Step 1: 初始化生成器
            self.logger.info("[1/8] 初始化生成器...")
            self._initialize_generator()
            self.logger.info("✓ 初始化完成")

            # Step 2: 加载配置
            self.logger.info("[2/8] 加载配置文件...")
            if not self.generator.load_config(self.config_path):
                return self._fail("配置文件加载失败")
            self.logger.info("✓ 配置加载完成")

            # 重新创建报告数据（使用真实加载的配置，而非默认配置）
            self.logger.info("   重新构建报告数据结构...")
            self.generator.create_report_data()
            self.logger.info("✓ 报告数据重新构建完成")

            # Step 3: 根据配置选择执行策略
            execution_mode = self.generator.config_service.get_config().execution_mode or "full"
            self.strategy = ExecutionModeFactory.create(execution_mode)
            self.logger.info(f"检测到执行模式: {self.strategy.mode_name}")

            # Step 4: 创建执行上下文
            context = ExecutionContext(
                generator=self.generator,
                config_path=self.config_path,
                output_dir=self.output_dir,
                cache_enabled=self.cache_enabled,
                start_time=start_time,
            )

            # Step 5: 配置环境
            self.strategy.configure_environment(context)

            # Step 6: 执行阶段（策略决定执行哪些阶段）
            # 将配置从context传递给generator，以便在generate_indicator_maps中使用
            if context.rendering_config:
                self.generator.rendering_config = context.rendering_config
            if context.map_generation_config:
                self.generator.map_generation_config = context.map_generation_config
            
            if not self._execute_stages(context):
                return False

            # Step 7: 格式化输出
            output = self.strategy.format_output(context)
            self._output_result(output)

            return self._success(context, start_time)

        except Exception as e:
            self.logger.error(f"管道执行异常: {str(e)}", exc_info=True)
            return self._fail(f"异常: {str(e)}")

    def _execute_stages(self, context: ExecutionContext) -> bool:
        """执行所有必需的阶段"""
        for stage in self.strategy.required_stages:
            if self.strategy.should_skip_stage(stage, context):
                self.logger.debug(f"跳过阶段: {stage.value}")
                continue

            self.logger.info(f"执行阶段: {stage.value}")

            try:
                # 调用对应的阶段处理器
                success = self._execute_single_stage(stage, context)

                if not success:
                    self.logger.error(f"阶段失败: {stage.value}")
                    return False

                # 调用成功钩子
                self.strategy.on_stage_success(stage, context)

            except Exception as e:
                self.logger.error(f"阶段异常: {stage.value} - {str(e)}", exc_info=True)

                # 调用失败钩子（决定是否继续）
                if not self.strategy.on_stage_failure(stage, context, e):
                    return False

        return True

    def _execute_single_stage(self, stage: ExecutionStage, context: ExecutionContext) -> bool:
        """执行单个阶段（映射到具体方法）"""
        stage_handlers = {
            ExecutionStage.INIT: lambda: True,  # 已在 __init__ 中完成
            ExecutionStage.LOAD_CONFIG: lambda: True,  # 已在 execute() 中完成
            ExecutionStage.PROCESS_DATA: lambda: context.generator.process_data(),
            ExecutionStage.GENERATE_MAPS: lambda: context.generator.generate_indicator_maps(),
            ExecutionStage.SAVE_CONFIG: lambda: context.generator.save_processed_config(),
            ExecutionStage.GENERATE_STRUCTURE: lambda: bool(context.generator.generate_config()),
            ExecutionStage.GENERATE_REPORT: lambda: context.generator.generate_report(
                context.generator.get_last_config_path()
            ),
            ExecutionStage.TRAIN_MODEL: lambda: self._train_models(context),  # NEW
            ExecutionStage.OUTPUT_RESULT: lambda: True,  # 在 format_output 中处理
        }

        handler = stage_handlers.get(stage)
        if not handler:
            self.logger.warning(f"未实现的阶段: {stage.value}")
            return True

        return handler()

    def _train_models(self, context: ExecutionContext) -> bool:
        """训练模型（NEW）"""
        try:
            # 调用模型训练逻辑（如果存在）
            if hasattr(context.generator, 'train_water_quality_models'):
                return context.generator.train_water_quality_models()
            self.logger.warning("模型训练方法未实现")
            return True
        except Exception as e:
            self.logger.error(f"模型训练失败: {str(e)}", exc_info=True)
            return False

    def _output_result(self, output: Dict[str, Any]) -> None:
        """输出结果（根据模式决定输出方式）"""
        if self.strategy.mode_name in ["heatmap_only"]:
            # JSON 输出到 stdout
            print(json.dumps(output, ensure_ascii=False, indent=2))
        else:
            # 完整报告模式：日志输出
            self.logger.info(f"输出结果: {output}")

    def _initialize_generator(self) -> None:
        """初始化报告生成器"""
        try:
            # 延迟导入以避免循环依赖
            from ..main import AeroSpotReportGenerator

            self.generator = AeroSpotReportGenerator(
                output_dir=self.output_dir,
                config=None,
                cache_enabled=self.cache_enabled
            )
            self.logger.debug("报告生成器初始化成功")
        except Exception as e:
            self.logger.error(f"生成器初始化失败: {str(e)}", exc_info=True)
            raise

    def _success(self, context: ExecutionContext, start_time: float) -> bool:
        """标记管道执行成功"""
        end_time = time.time()
        duration = end_time - start_time

        self.execution_result["success"] = True
        self.execution_result["report_path"] = context.generator.output_dir
        self.execution_result["config_path"] = context.generator.get_last_config_path()
        self.execution_result["end_time"] = end_time
        self.execution_result["duration_seconds"] = duration

        self.logger.info("=" * 60)
        self.logger.info("✅ 报告生成成功！")
        self.logger.info(f"   输出目录: {context.generator.output_dir}")
        self.logger.info(f"   耗时: {duration:.1f} 秒")
        self.logger.info("=" * 60)

        return True

    def _fail(self, error_msg: str) -> bool:
        """标记管道执行失败"""
        end_time = time.time()
        duration = (
            end_time - self.execution_result["start_time"]
            if self.execution_result["start_time"]
            else 0.0
        )

        self.execution_result["success"] = False
        self.execution_result["error"] = error_msg
        self.execution_result["end_time"] = end_time
        self.execution_result["duration_seconds"] = duration

        self.logger.error("=" * 60)
        self.logger.error(f"❌ 报告生成失败: {error_msg}")
        self.logger.error(f"   耗时: {duration:.1f} 秒")
        self.logger.error("=" * 60)

        return False

    # 结果访问接口

    def get_result(self) -> Dict[str, Any]:
        """获取管道执行结果"""
        return self.execution_result.copy()

    def get_report_path(self) -> Optional[str]:
        """获取生成的报告输出目录路径"""
        return self.execution_result.get("report_path")

    def get_config_path(self) -> Optional[str]:
        """获取生成的报告结构配置文件路径"""
        return self.execution_result.get("config_path")

    def is_success(self) -> bool:
        """检查管道是否成功执行"""
        return self.execution_result.get("success", False)

    def get_error_message(self) -> Optional[str]:
        """获取执行错误信息"""
        return self.execution_result.get("error")

    def get_duration(self) -> float:
        """获取执行耗时（秒）"""
        return self.execution_result.get("duration_seconds", 0.0)

    def get_status(self) -> str:
        """获取管道执行状态"""
        if self.execution_result["success"]:
            return "success"
        elif self.execution_result["error"]:
            return "failed"
        elif self.execution_result["start_time"]:
            return "running"
        else:
            return "pending"