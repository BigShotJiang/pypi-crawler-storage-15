#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
边界掩膜管理模块

负责：
- 加载和解析KML文件
- 生成最终的边界掩膜几何体（支持差集操作）
- 提供点包含判断、网格掩膜生成等功能
"""

import logging
import os
from typing import TYPE_CHECKING, Optional, Tuple

import numpy as np
from shapely.geometry import Point, Polygon, MultiPolygon

if TYPE_CHECKING:
    import pandas as pd

logger = logging.getLogger(__name__)


class BoundaryManager:
    """
    边界掩膜管理器

    负责：
    - 加载和解析KML文件
    - 生成最终的边界掩膜几何体（支持差集操作）
    - 提供点包含判断、网格掩膜生成等功能
    """

    def __init__(self, kml_path: Optional[str] = None) -> None:
        """
        初始化边界管理器

        Args:
            kml_path: KML文件路径（可选），如果为None则使用全局掩膜（无限制）
        """
        self.kml_path = kml_path
        self.keep_geom: Optional[Polygon | MultiPolygon] = None
        self.remove_geom: Optional[Polygon | MultiPolygon] = None
        self.final_geom: Optional[Polygon | MultiPolygon] = None
        self.is_enabled = False

        if kml_path and os.path.exists(kml_path):
            self._load_kml(kml_path)
        elif kml_path:
            logger.warning(f"KML文件不存在，边界掩膜已禁用: {kml_path}")
        else:
            logger.info("未指定KML文件，边界掩膜已禁用（使用全局掩膜）")

    def _load_kml(self, kml_path: str) -> None:
        """加载和解析KML文件"""
        try:
            from ..utils.kml import parse_kml_to_shapely_by_name, _fix_geometry_with_retry

            logger.info(f"开始加载KML文件: {kml_path}")

            self.keep_geom, self.remove_geom = parse_kml_to_shapely_by_name(kml_path)

            if self.keep_geom is None:
                logger.error("KML文件中未找到保留区域(name=1)")
                return

            # 计算最终几何体：keep - remove
            if self.remove_geom is not None:
                self.final_geom = self.keep_geom.difference(self.remove_geom)

                # ✨ 新增：修复差集操作可能产生的无效几何体
                self.final_geom = _fix_geometry_with_retry(
                    self.final_geom, max_attempts=3
                )

                if self.final_geom is None:
                    logger.error(
                        "差集操作产生的几何体无法修复，回退到仅使用保留区域"
                    )
                    self.final_geom = self.keep_geom
                else:
                    logger.info(
                        f"KML边界已加载：保留区域{self._geom_summary(self.keep_geom)}, "
                        f"移除区域{self._geom_summary(self.remove_geom)} "
                        f"→ 最终{self._geom_summary(self.final_geom)}"
                    )
                    self.is_enabled = True
                    self.kml_path = kml_path
                    return
            else:
                self.final_geom = self.keep_geom
                logger.info(
                    f"KML边界已加载：保留区域{self._geom_summary(self.keep_geom)}"
                )

            self.is_enabled = True
            self.kml_path = kml_path

        except Exception as e:
            logger.error(f"KML文件加载失败: {str(e)}")
            self.is_enabled = False

    @staticmethod
    def _geom_summary(geom: Optional[Polygon | MultiPolygon]) -> str:
        """生成几何体的简短描述"""
        if geom is None:
            return "None"
        elif isinstance(geom, Polygon):
            exterior_pts = len(geom.exterior.coords) - 1
            interior_count = len(geom.interiors)
            return f"Polygon(外边界{exterior_pts}点, 内孔{interior_count}个)"
        elif isinstance(geom, MultiPolygon):
            return f"MultiPolygon({len(geom.geoms)}个多边形)"
        else:
            return str(type(geom).__name__)

    def contains_point(self, lon: float, lat: float) -> bool:
        """
        判断点是否在边界内

        Args:
            lon: 经度
            lat: 纬度

        Returns:
            True 如果点在边界内（或边界已禁用），False 否则
        """
        if not self.is_enabled or self.final_geom is None:
            return True  # 无掩膜时，所有点都认为在范围内

        return self.final_geom.contains(Point(lon, lat))

    def get_grid_mask(self, grid_lon: np.ndarray, grid_lat: np.ndarray) -> np.ndarray:
        """
        获取网格掩膜

        Args:
            grid_lon: 经度网格 (M, N)
            grid_lat: 纬度网格 (M, N)

        Returns:
            布尔掩膜数组，True表示网格点在边界内
        """
        if not self.is_enabled or self.final_geom is None:
            logger.debug("边界掩膜已禁用，返回全True掩膜")
            return np.ones_like(grid_lon, dtype=bool)

        try:
            # 向量化点包含判断
            points = np.column_stack((grid_lon.ravel(), grid_lat.ravel()))
            mask = np.array(
                [self.final_geom.contains(Point(lon, lat)) for lon, lat in points]
            )

            # 重新塑形为网格形状
            mask = mask.reshape(grid_lon.shape)

            inside_count = np.sum(mask)
            total_count = mask.size
            logger.debug(
                f"网格掩膜已生成：{inside_count}/{total_count} "
                f"({100*inside_count/total_count:.1f}%)的网格点在边界内"
            )

            return mask

        except Exception as e:
            logger.error(f"生成网格掩膜失败: {str(e)}")
            return np.ones_like(grid_lon, dtype=bool)

    def filter_dataframe(
        self, df: "pd.DataFrame", lon_col: str = "Longitude", lat_col: str = "Latitude"
    ) -> Tuple["pd.DataFrame", np.ndarray]:
        """
        使用边界掩膜过滤DataFrame

        Args:
            df: 包含经纬度的DataFrame
            lon_col: 经度列名
            lat_col: 纬度列名

        Returns:
            (filtered_df, mask) - 过滤后的DataFrame和掩膜

        Examples:
            >>> manager = BoundaryManager("boundary.kml")
            >>> filtered_df, mask = manager.filter_dataframe(data)
            >>> print(f"保留{len(filtered_df)}/{len(data)}个数据点")
        """
        if not self.is_enabled or self.final_geom is None:
            logger.debug("边界掩膜已禁用，返回全部数据")
            return df, np.ones(len(df), dtype=bool)

        try:
            # 向量化判断
            mask = np.array(
                [
                    self.final_geom.contains(Point(row[lon_col], row[lat_col]))
                    for _, row in df.iterrows()
                ]
            )

            filtered_df = df[mask].copy()
            removed_count = len(df) - len(filtered_df)

            logger.info(
                f"数据过滤完成：保留{len(filtered_df)}/{len(df)}个数据点，"
                f"移除{removed_count}个数据点"
            )

            return filtered_df, mask

        except Exception as e:
            logger.error(f"数据过滤失败: {str(e)}")
            return df, np.ones(len(df), dtype=bool)

    def get_boundary_points(self) -> Optional[np.ndarray]:
        """
        获取最终边界的顶点坐标（用于可视化或旧接口兼容）

        Returns:
            边界外边界的顶点坐标数组
        """
        if not self.is_enabled or self.final_geom is None:
            return None

        try:
            if isinstance(self.final_geom, Polygon):
                coords = np.array(self.final_geom.exterior.coords[:-1])
            elif isinstance(self.final_geom, MultiPolygon):
                # 对于MultiPolygon，返回凸包
                from scipy.spatial import ConvexHull

                all_coords = []
                for poly in self.final_geom.geoms:
                    all_coords.extend(poly.exterior.coords[:-1])
                coords = np.array(all_coords)
                if len(coords) > 2:
                    hull = ConvexHull(coords)
                    coords = coords[hull.vertices]
            else:
                return None

            return coords

        except Exception as e:
            logger.error(f"获取边界点失败: {str(e)}")
            return None

    def get_statistics(self) -> dict:
        """获取边界的统计信息"""
        if not self.is_enabled or self.final_geom is None:
            return {
                "enabled": False,
                "kml_path": self.kml_path,
            }

        try:
            if isinstance(self.final_geom, Polygon):
                geom_type = "Polygon"
                area = self.final_geom.area
                bounds = self.final_geom.bounds
                inner_holes = len(self.final_geom.interiors)
            elif isinstance(self.final_geom, MultiPolygon):
                geom_type = "MultiPolygon"
                area = sum(p.area for p in self.final_geom.geoms)
                bounds = self.final_geom.bounds
                inner_holes = sum(len(p.interiors) for p in self.final_geom.geoms)
            else:
                geom_type = "Unknown"
                area = None
                bounds = None
                inner_holes = 0

            return {
                "enabled": True,
                "kml_path": self.kml_path,
                "geometry_type": geom_type,
                "area": area,
                "bounds": bounds,  # (min_lon, min_lat, max_lon, max_lat)
                "inner_holes": inner_holes,
                "keep_geometry": self._geom_summary(self.keep_geom),
                "remove_geometry": self._geom_summary(self.remove_geom),
                "final_geometry": self._geom_summary(self.final_geom),
            }
        except Exception as e:
            logger.error(f"获取边界统计信息失败: {str(e)}")
            return {"enabled": True, "error": str(e)}
