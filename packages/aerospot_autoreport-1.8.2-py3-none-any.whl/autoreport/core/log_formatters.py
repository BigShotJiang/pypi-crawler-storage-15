#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""日志格式化器 - 支持彩色输出"""

import logging
import sys
from typing import Optional


class ColoredFormatter(logging.Formatter):
    """彩色日志格式化器

    自动检测终端（TTY），仅在终端显示彩色输出。
    文件日志输出纯文本（不包含ANSI代码）。

    Attributes:
        COLORS: 日志级别到ANSI颜色代码的映射
        RESET: ANSI重置代码

    Examples:
        >>> import logging
        >>> formatter = ColoredFormatter("%(levelname)s - %(message)s")
        >>> handler = logging.StreamHandler()
        >>> handler.setFormatter(formatter)
        >>> logger = logging.getLogger(__name__)
        >>> logger.addHandler(handler)
        >>> logger.info("This will be green in terminal")  # 终端显示绿色
    """

    # ANSI 彩色代码
    COLORS = {
        'DEBUG': '\033[36m',      # 青色
        'INFO': '\033[32m',       # 绿色
        'WARNING': '\033[33m',    # 黄色
        'ERROR': '\033[31m',      # 红色
        'CRITICAL': '\033[35m',   # 洋红
    }
    RESET = '\033[0m'  # 重置颜色

    def __init__(
        self,
        fmt: Optional[str] = None,
        datefmt: Optional[str] = None,
        use_color: bool = True,
    ) -> None:
        """初始化彩色格式化器

        Args:
            fmt: 日志格式字符串
            datefmt: 日期格式字符串
            use_color: 是否尝试使用彩色输出
                      实际是否使用彩色取决于是否在终端运行
        """
        super().__init__(fmt, datefmt)
        # 仅在终端且明确要求时才使用彩色
        self.use_color = use_color and self._is_tty()

    @staticmethod
    def _is_tty() -> bool:
        """检测是否在终端中运行

        Returns:
            bool: 如果运行在终端中返回True，否则返回False
        """
        return hasattr(sys.stderr, 'isatty') and sys.stderr.isatty()

    def format(self, record: logging.LogRecord) -> str:
        """格式化日志记录

        如果启用彩色输出，会在日志级别周围添加ANSI彩色代码。

        Args:
            record: 日志记录对象

        Returns:
            str: 格式化后的日志字符串
        """
        if self.use_color and record.levelname in self.COLORS:
            # 获取该级别对应的颜色
            color = self.COLORS[record.levelname]
            # 保存原始的levelname
            levelname = record.levelname
            # 在levelname周围添加彩色代码
            record.levelname = f"{color}{levelname}{self.RESET}"
            # 调用父类的format方法
            result = super().format(record)
            # 恢复原始的levelname（防止影响其他处理器）
            record.levelname = levelname
            return result
        else:
            # 不使用彩色时直接调用父类方法
            return super().format(record)
