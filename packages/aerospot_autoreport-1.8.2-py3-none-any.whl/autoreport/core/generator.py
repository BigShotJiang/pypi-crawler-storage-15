"""
报告生成器模块

负责根据配置生成 Word 格式的报告。包含异常处理、水印添加、
样式设置等功能。
"""

import contextlib
import logging
import os
import shutil
import tempfile
from typing import Dict, Any, Optional, Generator

from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches
from docx.enum.section import WD_SECTION_START
from docx.enum.text import WD_BREAK

from ..document.tables import add_data_table
from ..document.paragraphs import add_paragraph_with_style
from ..document.styles import create_styles, create_toc_styles
from ..document.paragraphs import add_mixed_font_paragraph
from ..document.images import add_image_to_doc
from ..document.pages import (
    set_page_size_to_a4,
    add_toc,
    add_header_footer,
    update_fields_in_word,
    add_watermark_to_doc,
)
from ..utils.font import set_default_font
from .config_models import get_default_company_info
from .exceptions import (
    DocumentGenerationError,
    WatermarkError,
    StyleApplicationError,
    ImageInsertionError,
    TemporaryFileError,
)

logger = logging.getLogger(__name__)


class ReportGenerator:
    """报告生成器类

    负责生成完整的 Word 格式报告，包括样式设置、内容生成、
    水印添加等功能。

    Attributes:
        output_path (str): 输出报告文件的路径
        report_structure (Dict[str, Any]): 报告结构配置
        update_data (Dict[str, Any]): 更新数据配置
        doc (Optional[Document]): 当前 Word 文档对象
    """

    def __init__(
        self,
        output_path: str,
        report_structure: Dict[str, Any],
        update_data: Dict[str, Any],
    ) -> None:
        """初始化报告生成器

        Args:
            output_path: 输出报告文件的路径
            report_structure: 报告结构配置字典
            update_data: 更新数据配置字典

        Raises:
            TypeError: 参数类型不符合要求时
        """
        self.output_path: str = output_path
        self.report_structure: Dict[str, Any] = report_structure
        self.update_data: Dict[str, Any] = update_data
        self.doc: Optional[Any] = None

    def generate(self) -> Optional[str]:
        """生成完整的 Word 报告文档

        执行以下步骤：
        1. 创建新 Word 文档
        2. 设置文档样式和页面配置
        3. 生成报告各个部分（封面、简介、目录、章节）
        4. 应用页眉页脚和水印
        5. 保存文档到指定路径

        Returns:
            生成的报告文件路径（.docx）。如果生成失败返回 None。

        Raises:
            DocumentGenerationError: 报告生成过程中发生错误
        """
        try:
            # 创建新文档
            self.doc = Document()

            # 设置文档样式
            self._setup_document_styles()

            # 生成报告内容
            self._create_cover_page()
            self._create_company_profile()
            self._create_toc()
            self._create_chapters()

            # 添加页眉页脚
            add_header_footer(
                self.doc,
                self.report_structure["title"],
                self.update_data.get("company", {}).get("name"),
            )

            # 特别确保第一节不显示页码（封面和公司简介）
            self._set_section_page_numbering(0, hide_number=True)
            self._clear_section_header_footer(0)

            # 保存文档
            logger.info(f"保存报告到: {self.output_path}")
            self.doc.save(self.output_path)

            # 检查是否需要添加水印
            self._apply_watermark_if_needed()

            # 更新域
            update_fields_in_word(self.output_path)

            logger.info(f"报告生成完成: {self.output_path}")
            return self.output_path

        except DocumentGenerationError:
            # 已捕获的自定义异常，直接传播
            raise
        except Exception as e:
            logger.error(f"生成报告失败: {str(e)}", exc_info=True)
            raise DocumentGenerationError(f"报告生成失败: {str(e)}") from e

    def _setup_document_styles(self) -> None:
        """设置 Word 文档的样式

        包含以下步骤：
        1. 设置页面大小为 A4
        2. 设置默认字体为宋体
        3. 创建基础文档样式
        4. 设置目录样式

        Raises:
            StyleApplicationError: 样式设置失败时抛出
        """
        if not self.doc:
            raise StyleApplicationError("文档未初始化")

        try:
            self.doc = set_page_size_to_a4(self.doc)
            self.doc = set_default_font(self.doc)
            self.doc = create_styles(self.doc)
            self.doc = create_toc_styles(self.doc)
        except Exception as e:
            logger.error(f"设置文档样式失败: {str(e)}", exc_info=True)
            raise StyleApplicationError(f"样式设置失败: {str(e)}") from e

    def _set_section_page_numbering(
        self, section_index: int = 0, hide_number: bool = True
    ) -> None:
        """设置指定分节的页码格式

        可以隐藏或显示指定分节的页码。

        Args:
            section_index: 分节索引（0 为第一节）
            hide_number: 是否隐藏页码（默认隐藏）

        Raises:
            DocumentGenerationError: 文档未初始化或分节不存在
        """
        if not self.doc or not self.doc.sections:
            logger.warning("文档未初始化或没有分节")
            return

        if section_index >= len(self.doc.sections):
            logger.warning(f"分节索引超出范围: {section_index}")
            return

        try:
            section = self.doc.sections[section_index]
            sectPr = section._sectPr
            pgNumType_elements = sectPr.xpath("./w:pgNumType")

            if pgNumType_elements:
                pgNumType = pgNumType_elements[0]
                # 删除 fmt 属性实现隐藏页码
                if pgNumType.get(qn("w:fmt")):
                    del pgNumType.attrib[qn("w:fmt")]
            else:
                pgNumType = OxmlElement("w:pgNumType")
                sectPr.append(pgNumType)
        except Exception as e:
            logger.warning(f"设置页码格式失败: {str(e)}", exc_info=True)

    def _clear_section_header_footer(self, section_index: int) -> None:
        """清空指定分节的页眉页脚

        Args:
            section_index: 分节索引

        Raises:
            DocumentGenerationError: 文档未初始化或分节不存在
        """
        if not self.doc or not self.doc.sections:
            logger.warning("文档未初始化或没有分节")
            return

        if section_index >= len(self.doc.sections):
            logger.warning(f"分节索引超出范围: {section_index}")
            return

        try:
            section = self.doc.sections[section_index]

            # 清空页眉
            header = section.header
            header.is_linked_to_previous = False
            for p in header.paragraphs:
                p.clear()

            # 清空页脚
            footer = section.footer
            footer.is_linked_to_previous = False
            for p in footer.paragraphs:
                p.clear()

        except Exception as e:
            logger.warning(
                f"清空第 {section_index} 分节的页眉页脚失败: {str(e)}",
                exc_info=True,
            )

    @contextlib.contextmanager
    def _temp_docx_file(self, source_path: str) -> Generator[str, None, None]:
        """临时 DOCX 文件上下文管理器

        创建源文件的临时副本，在 with 块中使用，
        确保异常情况下也能正确清理。

        Args:
            source_path: 源 DOCX 文件路径

        Yields:
            临时文件路径

        Raises:
            TemporaryFileError: 临时文件创建或处理失败
        """
        temp_fd = None
        temp_path = None
        try:
            temp_fd, temp_path = tempfile.mkstemp(suffix=".docx")
            os.close(temp_fd)
            shutil.copy2(source_path, temp_path)
            yield temp_path
        except OSError as e:
            logger.error(f"无法创建临时文件: {str(e)}", exc_info=True)
            raise TemporaryFileError(f"临时文件创建失败: {str(e)}") from e
        finally:
            if temp_path and os.path.exists(temp_path):
                try:
                    os.remove(temp_path)
                except OSError as e:
                    logger.warning(
                        f"无法删除临时文件 {temp_path}: {str(e)}", exc_info=True
                    )

    def _apply_watermark_if_needed(self) -> None:
        """应用水印（如果需要）

        检查配置中的水印设置，如果启用则使用 Spire.Doc 添加水印。
        同时处理 Spire.Doc 的评估警告文本。

        Raises:
            WatermarkError: 水印添加失败时抛出
        """
        company_info = self.update_data.get("company_info", {})

        watermark_enabled = company_info.get("watermark_enabled", False)
        watermark_use_spire = company_info.get("watermark_use_spire", False)

        if not (watermark_enabled and watermark_use_spire):
            return

        try:
            with self._temp_docx_file(self.output_path) as temp_output_file:
                watermark_text = company_info.get(
                    "watermark_text", "无锡谱视界科技有限公司"
                )
                watermark_size = company_info.get("watermark_size", 65)
                watermark_color = company_info.get("watermark_color", (200, 0, 0))
                watermark_diagonal = company_info.get("watermark_diagonal", True)

                # 添加水印到临时文件
                success = add_watermark_to_doc(
                    doc_path=temp_output_file,
                    watermark_text=watermark_text,
                    font_size=watermark_size,
                    color=watermark_color,
                    diagonal=watermark_diagonal,
                )

                if success:
                    logger.info(f"已使用 Spire.Doc 添加水印: {watermark_text}")
                    self._remove_watermark_evaluation_warning(temp_output_file)
                else:
                    logger.warning("添加水印失败，请检查 Spire.Doc 是否正确安装")

        except ImportError as e:
            logger.warning(f"未找到 watermark 模块: {str(e)}")
            raise WatermarkError(f"watermark 模块未找到: {str(e)}") from e
        except TemporaryFileError:
            # 临时文件错误已记录，重新抛出
            raise
        except Exception as e:
            logger.error(f"添加水印时发生错误: {str(e)}", exc_info=True)
            raise WatermarkError(f"添加水印失败: {str(e)}") from e

    def _remove_watermark_evaluation_warning(self, doc_path: str) -> None:
        """移除 Spire.Doc 的评估警告文本

        Spire.Doc 评估版会在文档首页添加评估警告，
        此方法删除该警告文本。

        Args:
            doc_path: Word 文档路径

        Raises:
            DocumentGenerationError: 文档处理失败时抛出
        """
        try:
            doc = Document(doc_path)

            # 检查首页第一段是否为评估警告
            if doc.paragraphs and "Evaluation Warning" in doc.paragraphs[0].text:
                # 删除评估警告段落
                p = doc.paragraphs[0]._element
                p.getparent().remove(p)
                logger.info("已删除 Spire.Doc 评估警告文本")

            # 保存处理后的文档到最终位置
            doc.save(self.output_path)

        except Exception as e:
            logger.error(f"移除评估警告失败: {str(e)}", exc_info=True)
            raise DocumentGenerationError(f"无法移除评估警告: {str(e)}") from e

    def _create_cover_page(self) -> None:
        """创建封面页

        包括 Logo、报告标题、公司名称、日期等信息。

        Raises:
            DocumentGenerationError: 封面创建失败时抛出
        """
        if not self.doc:
            raise DocumentGenerationError("文档未初始化")

        logger.info("添加封面...")

        try:
            # 添加 Logo
            logo_path = self._get_image_path("logo_path", "image_resources")
            if not logo_path:
                default_company = get_default_company_info()
                logo_path = default_company.logo_path or ""
                logger.warning(f"未找到 logo 图片文件，使用默认值: {logo_path}")

            self._add_image_to_paragraph(logo_path, width=Inches(2.5))
            logger.info(f"已添加 logo 图片: {logo_path}")

            # 添加空行
            add_paragraph_with_style(self.doc, "\n\n\n\n", "正文")

            # 添加报告标题
            add_mixed_font_paragraph(
                self.doc, self.report_structure["title"], "文档标题"
            )

            # 添加空行
            add_paragraph_with_style(self.doc, "\n\n\n\n\n", "正文")

            # 添加公司名称和日期
            company_info = self.update_data.get("company_info", {})
            add_mixed_font_paragraph(
                self.doc,
                company_info.get("name", "未找到公司名称"),
                "公司名称",
            )
            add_mixed_font_paragraph(
                self.doc,
                company_info.get("date", "未找到日期"),
                "日期",
            )

            add_paragraph_with_style(self.doc, "\n", "正文")

            # 添加底部图片
            default_company = get_default_company_info()
            bottom_img_path = default_company.watermark_path or ""

            if bottom_img_path and os.path.exists(bottom_img_path):
                self._add_watermark_image(bottom_img_path)
                logger.info(f"已添加封面底部图片: {bottom_img_path}")
            else:
                logger.warning("未找到封面底部图片文件")

            # 添加分页符
            self.doc.add_paragraph().add_run().add_break(WD_BREAK.PAGE)

        except ImageInsertionError:
            raise
        except Exception as e:
            logger.error(f"创建封面失败: {str(e)}", exc_info=True)
            raise DocumentGenerationError(f"创建封面失败: {str(e)}") from e

    def _get_image_path(
        self, image_key: str, resource_key: str = "image_resources"
    ) -> str:
        """获取图片路径

        Args:
            image_key: 图片配置的键名
            resource_key: 资源配置的键名（默认 "image_resources"）

        Returns:
            图片路径，如果不存在返回空字符串
        """
        try:
            resources = self.update_data.get(resource_key, {})
            if isinstance(resources, dict):
                image_path: Any = resources.get(image_key)
                if (
                    isinstance(image_path, str)
                    and image_path
                    and os.path.exists(image_path)
                ):
                    return image_path
            return ""

        except (AttributeError, TypeError):
            logger.warning(f"无法获取 {image_key} 的路径")
            return ""

    def _add_image_to_paragraph(self, image_path: str, width: Any = None) -> None:
        """将图片添加到段落

        Args:
            image_path: 图片文件路径
            width: 图片宽度（可选）

        Raises:
            ImageInsertionError: 图片插入失败时抛出
        """
        if not self.doc:
            raise ImageInsertionError("文档未初始化")

        if not image_path or not os.path.exists(image_path):
            raise ImageInsertionError(f"图片文件不存在: {image_path}")

        try:
            paragraph = self.doc.add_paragraph()
            paragraph.paragraph_format.left_indent = 0
            paragraph.paragraph_format.right_indent = 0
            paragraph.paragraph_format.space_before = 0
            paragraph.paragraph_format.space_after = 0
            paragraph.paragraph_format.line_spacing = 1
            paragraph.paragraph_format.first_line_indent = 0

            run = paragraph.add_run()
            if width:
                run.add_picture(image_path, width=width)
            else:
                run.add_picture(image_path)

        except Exception as e:
            logger.error(f"添加图片失败: {str(e)}", exc_info=True)
            raise ImageInsertionError(f"图片插入失败: {str(e)}") from e

    def _add_watermark_image(self, image_path: str) -> None:
        """添加水印背景图片

        Args:
            image_path: 图片文件路径

        Raises:
            ImageInsertionError: 图片插入失败时抛出
        """
        if not self.doc or not self.doc.sections:
            raise ImageInsertionError("文档未初始化")

        try:
            watermark_paragraph = self.doc.add_paragraph()
            watermark_paragraph.paragraph_format.left_indent = 0
            watermark_paragraph.paragraph_format.right_indent = 0
            watermark_paragraph.paragraph_format.space_before = 0
            watermark_paragraph.paragraph_format.space_after = 0
            watermark_paragraph.paragraph_format.line_spacing = 1
            watermark_paragraph.paragraph_format.first_line_indent = 0

            # 获取页面宽度
            section = self.doc.sections[0]
            page_width = section.page_width - section.left_margin - section.right_margin

            # 添加图片并设置宽度为页面宽度
            run = watermark_paragraph.add_run()
            run.add_picture(image_path, width=Inches(page_width / 914400))

        except Exception as e:
            logger.error(f"添加水印图片失败: {str(e)}", exc_info=True)
            raise ImageInsertionError(f"水印图片插入失败: {str(e)}") from e

    def _create_company_profile(self) -> None:
        """创建公司简介页

        包括公司简介、地址、邮箱、电话等联系信息。

        Raises:
            DocumentGenerationError: 公司简介创建失败时抛出
        """
        if not self.doc:
            raise DocumentGenerationError("文档未初始化")

        logger.info("添加公司简介...")

        try:
            company_info = self.update_data.get("company_info", {})

            # 添加公司简介文本
            profile = company_info.get("profile")
            if profile:
                paragraphs = profile.strip().split("\n")
                for para_text in paragraphs:
                    if para_text.strip():
                        self.doc.add_paragraph(para_text.strip(), style="正文")

            add_paragraph_with_style(self.doc, "\n\n", "正文")

            # 添加联系信息
            self._add_contact_info(company_info)

            # 特别确保第一节没有页眉页脚和页码
            self._set_section_page_numbering(0, hide_number=True)
            self._clear_section_header_footer(0)

            # 封面和目录之间添加分节符（新的一页）
            self.doc.add_section(WD_SECTION_START.NEW_PAGE)

        except Exception as e:
            logger.error(f"创建公司简介失败: {str(e)}", exc_info=True)
            raise DocumentGenerationError(f"创建公司简介失败: {str(e)}") from e

    def _add_contact_info(self, company_info: Dict[str, Any]) -> None:
        """添加联系信息

        Args:
            company_info: 公司信息字典

        Raises:
            DocumentGenerationError: 文档未初始化
        """
        if not self.doc:
            raise DocumentGenerationError("文档未初始化")

        try:
            # 地址
            address_para = self.doc.add_paragraph(style="地址")
            label_run = address_para.add_run("地 址：")
            label_run.font.name = "宋体"
            content_run = address_para.add_run(company_info.get("address", ""))
            content_run.font.name = "宋体"

            # 邮箱
            email_para = self.doc.add_paragraph(style="邮件")
            label_run = email_para.add_run("邮 箱：")
            label_run.font.name = "宋体"
            content_run = email_para.add_run(company_info.get("email", ""))
            content_run.font.name = "Times New Roman"

            # 电话
            phone_para = self.doc.add_paragraph(style="电话")
            label_run = phone_para.add_run("电 话：")
            label_run.font.name = "宋体"
            content_run = phone_para.add_run(company_info.get("phone", ""))
            content_run.font.name = "Times New Roman"

        except Exception as e:
            logger.error(f"添加联系信息失败: {str(e)}", exc_info=True)
            raise DocumentGenerationError(f"添加联系信息失败: {str(e)}") from e

    def _create_toc(self) -> None:
        """创建目录

        Raises:
            DocumentGenerationError: 目录创建失败时抛出
        """
        if not self.doc:
            raise DocumentGenerationError("文档未初始化")

        logger.info("添加目录...")
        try:
            add_toc(self.doc)
        except Exception as e:
            logger.error(f"创建目录失败: {str(e)}", exc_info=True)
            raise DocumentGenerationError(f"创建目录失败: {str(e)}") from e

    def _create_chapters(self) -> None:
        """创建章节内容

        遍历报告结构中的所有章节，生成对应的内容。

        Raises:
            DocumentGenerationError: 章节创建失败时抛出
        """
        if not self.doc:
            raise DocumentGenerationError("文档未初始化")

        logger.info("添加章节内容...")

        try:
            chapters = self.report_structure.get("chapters", [])

            for chapter_idx, chapter in enumerate(chapters):
                chapter_num = chapter_idx + 1
                self._create_single_chapter(chapter, chapter_num)

                # 添加章节结束的分页符，最后一章不添加
                if chapter_idx < len(chapters) - 1:
                    self.doc.add_paragraph().add_run().add_break(WD_BREAK.PAGE)

        except Exception as e:
            logger.error(f"创建章节失败: {str(e)}", exc_info=True)
            raise DocumentGenerationError(f"创建章节失败: {str(e)}") from e

    def _create_single_chapter(self, chapter: Dict[str, Any], chapter_num: int) -> None:
        """创建单个章节

        Args:
            chapter: 章节配置字典
            chapter_num: 章节编号

        Raises:
            DocumentGenerationError: 文档未初始化
        """
        if not self.doc:
            raise DocumentGenerationError("文档未初始化")

        # 添加章节标题
        chapter_title = f"{chapter_num}. {chapter['title']}"
        self.doc.add_paragraph(chapter_title, style="一级标题")

        # 处理章节直接内容
        self._process_chapter_content(chapter, chapter_num)

        # 处理小节
        figure_count = 1
        for section_idx, section in enumerate(chapter.get("sections", [])):
            figure_count = self._create_section(
                section, chapter_num, section_idx, figure_count
            )

    def _process_chapter_content(
        self, chapter: Dict[str, Any], chapter_num: int
    ) -> None:
        """处理章节直接内容

        Args:
            chapter: 章节配置字典
            chapter_num: 章节编号
        """
        if not self.doc:
            return

        content = chapter.get("content")
        if not content:
            return

        if isinstance(content, list):
            for para in content:
                if isinstance(para, str) and para.strip():
                    self.doc.add_paragraph(para, style="正文")
        elif isinstance(content, str) and content.strip():
            self.doc.add_paragraph(content, style="正文")

    def _create_section(
        self,
        section: Dict[str, Any],
        chapter_num: int,
        section_idx: int,
        figure_count: int,
    ) -> int:
        """创建小节

        Args:
            section: 小节配置字典
            chapter_num: 章节编号
            section_idx: 小节索引
            figure_count: 当前图片计数

        Returns:
            更新后的图片计数
        """
        # 添加小节标题
        add_paragraph_with_style(
            self.doc,
            f"{chapter_num}.{section_idx + 1} {section['name']}",
            "二级标题",
        )

        # 处理小节项目
        items = section.get("items", [])
        if not items:
            return figure_count

        subsection_idx = 0
        for item in items:
            item_type = item.get("type", "text")

            if item_type == "text":
                self._process_text_item(item)
            elif item_type == "subsection":
                subsection_idx += 1
                figure_count = self._create_subsection(
                    item,
                    chapter_num,
                    section_idx,
                    subsection_idx,
                    figure_count,
                )
            elif item_type == "image":
                figure_count = self._process_image_item(item, chapter_num, figure_count)
            elif item_type == "table":
                self._process_table_item(item, chapter_num)

        return figure_count

    def _process_text_item(self, item: Dict[str, Any]) -> None:
        """处理文本项

        Args:
            item: 文本项配置字典
        """
        if not self.doc:
            return

        content = item.get("content")
        if not content:
            return

        if isinstance(content, list):
            for para in content:
                if isinstance(para, str) and para.strip():
                    self.doc.add_paragraph(para, style="正文")
        elif isinstance(content, str) and content.strip():
            self.doc.add_paragraph(content, style="正文")

    def _create_subsection(
        self,
        item: Dict[str, Any],
        chapter_num: int,
        section_idx: int,
        subsection_idx: int,
        figure_count: int,
    ) -> int:
        """创建子段落

        Args:
            item: 子段落配置字典
            chapter_num: 章节编号
            section_idx: 小节索引
            subsection_idx: 子段落索引
            figure_count: 当前图片计数

        Returns:
            更新后的图片计数
        """
        # 添加三级标题
        title = f"{chapter_num}.{section_idx + 1}.{subsection_idx} " f"{item['name']}"
        add_paragraph_with_style(self.doc, title, "三级标题")

        # 处理子段落内容
        sub_items = item.get("items", [])
        for sub_item in sub_items:
            sub_item_type = sub_item.get("type", "text")

            if sub_item_type == "text":
                self._process_text_item(sub_item)
            elif sub_item_type == "image":
                figure_count = self._process_image_item(
                    sub_item, chapter_num, figure_count
                )
            elif sub_item_type == "table":
                self._process_table_item(sub_item, chapter_num)

        return figure_count

    def _process_image_item(
        self, item: Dict[str, Any], chapter_num: int, figure_count: int
    ) -> int:
        """处理图片项

        Args:
            item: 图片项配置字典
            chapter_num: 章节编号
            figure_count: 当前图片计数

        Returns:
            更新后的图片计数
        """
        image_path = item.get("path", "")

        # 特殊处理第 2 章的卫星图和航点规划图
        if chapter_num == 2:
            image_path = self._resolve_satellite_or_wayline_image(image_path, item)

        # 注：删除了原有的图片存在性检查
        # 理由：add_image_to_doc() 内部有完整的处理逻辑
        # 包括：path="" -> 生成占位图、path="skip" -> 跳过、无效路径 -> 生成占位图
        # 在此处检查会导致 add_image_to_doc() 无法被调用，破坏占位图功能

        try:
            figure_count = add_image_to_doc(
                self.doc,
                image_path,
                width=14.64,
                caption=item.get("caption", ""),
                chapter_num=chapter_num,
                figure_count=figure_count,
            )
        except Exception as e:
            logger.error(f"添加图片 '{image_path}' 失败: {str(e)}", exc_info=True)

        return figure_count

    def _resolve_satellite_or_wayline_image(
        self, image_path: str, item: Dict[str, Any]
    ) -> str:
        """解析卫星图或航点规划图路径

        Args:
            image_path: 原始图片路径
            item: 项配置字典

        Returns:
            解析后的图片路径
        """
        caption_text = item.get("caption", "")
        if not isinstance(caption_text, str):
            return image_path

        caption_text = caption_text.lower()
        company_info = self.update_data.get("company_info", {})

        if not isinstance(company_info, dict):
            return image_path

        if (
            "卫星图" in caption_text
            and not image_path
            and "satellite_img" in company_info
        ):
            result = company_info.get("satellite_img", "")
            return result if isinstance(result, str) else image_path

        if (
            "航点规划图" in caption_text
            and not image_path
            and "wayline_img" in company_info
        ):
            result = company_info.get("wayline_img", "")
            return result if isinstance(result, str) else image_path

        return image_path

    def _process_table_item(self, item: Dict[str, Any], chapter_num: int) -> None:
        """处理表格项

        Args:
            item: 表格项配置字典
            chapter_num: 章节编号
        """
        title = item.get("name", "")
        headers = item.get("headers")
        data = item.get("data", [])
        merge_cells = item.get("merge_cells")
        column_widths = item.get("column_widths")

        try:
            add_data_table(
                self.doc,
                title,
                headers,
                data,
                chapter_num,
                None,
                merge_cells=merge_cells,
                column_widths=column_widths,
            )
            logger.info(f"成功添加表格: {title}")
        except Exception as e:
            logger.error(f"添加表格 '{title}' 失败: {str(e)}", exc_info=True)
