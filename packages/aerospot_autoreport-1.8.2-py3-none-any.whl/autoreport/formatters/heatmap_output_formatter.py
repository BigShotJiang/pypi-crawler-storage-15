#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""热力图输出格式化模块

将AutoReportV3生成的地图数据格式化为waterqsvg兼容的JSON输出。
"""

import json
import logging
import os
from typing import Any, Dict, Optional

import pandas as pd

from ..models.report_data import ReportData

logger = logging.getLogger(__name__)


class HeatmapOutputFormatter:
    """热力图输出格式化器

    职责：
    - 从ReportData.maps中提取关键信息（SVG + Colorbar）
    - 计算地理边界坐标
    - 格式化为waterqsvg兼容的JSON格式
    - 输出到stdout或文件

    waterqsvg兼容格式：
        {
            "indicator": [
                "/abs/path/to/heatmap.svg",
                "/abs/path/to/colorbar.png",
                "lng_min,lat_max",  # 西北角
                "lng_max,lat_max",  # 东北角
                "lng_min,lat_min",  # 西南角
                "lng_max,lat_min"   # 东南角
            ]
        }
    """

    def __init__(self) -> None:
        """初始化热力图输出格式化器"""
        self.logger = logger

    @staticmethod
    def format_maps_to_output(
        maps: Dict[str, Dict[str, str]],
        report_data: ReportData,
    ) -> Dict[str, list]:
        """将AutoReportV3的maps格式转换为waterqsvg兼容格式

        从报告数据的maps字典中提取清洁SVG和colorbar，
        结合计算得到的地理边界，生成waterqsvg兼容的JSON格式。

        Args:
            maps: ReportData中的maps字典，格式为：
                {
                    "indicator": {
                        "clean_interpolation_svg": "/path/to/clean.svg",
                        "colorbar": "/path/to/colorbar.png",
                        "other_maps": ...
                    }
                }
            report_data: ReportData模型实例，包含uav_data等信息

        Returns:
            Dict[str, list]: waterqsvg兼容格式的输出字典，格式为：
                {
                    "indicator": [
                        "/abs/path/to/clean.svg",
                        "/abs/path/to/colorbar.png",
                        "min_lon,max_lat",
                        "max_lon,max_lat",
                        "min_lon,min_lat",
                        "max_lon,min_lat"
                    ]
                }

        Raises:
            ValueError: 当无法获取地理边界信息时
        """
        logger.info("开始格式化地图输出为waterqsvg兼容格式")

        output = {}

        # 1. 获取地理边界信息
        bounds = HeatmapOutputFormatter._get_geographic_bounds(report_data)
        if not bounds:
            logger.warning("无法获取地理边界信息，跳过输出")
            return {}

        min_lon = bounds["min_longitude"]
        max_lon = bounds["max_longitude"]
        min_lat = bounds["min_latitude"]
        max_lat = bounds["max_latitude"]

        logger.debug(
            f"地理边界范围: 经度[{min_lon:.6f}, {max_lon:.6f}], "
            f"纬度[{min_lat:.6f}, {max_lat:.6f}]"
        )

        # 2. 处理每个指标的地图
        for indicator, map_paths in maps.items():
            logger.debug(f"处理指标: {indicator}")

            # 提取关键文件路径
            svg_path = map_paths.get("clean_interpolation_svg")
            colorbar_path = map_paths.get("colorbar")

            # 验证关键文件存在
            if not svg_path or not colorbar_path:
                logger.warning(
                    f"指标 {indicator} 缺少关键文件 "
                    f"(svg={bool(svg_path)}, colorbar={bool(colorbar_path)})，跳过"
                )
                continue

            # 转换为绝对路径
            svg_abs = os.path.abspath(svg_path)
            colorbar_abs = os.path.abspath(colorbar_path)

            # 验证文件是否真实存在
            if not os.path.exists(svg_abs):
                logger.error(f"SVG文件不存在: {svg_abs}")
                continue
            if not os.path.exists(colorbar_abs):
                logger.error(f"Colorbar文件不存在: {colorbar_abs}")
                continue

            # 计算四个角的坐标
            # 顺序：西北(w_n) → 东北(e_n) → 西南(w_s) → 东南(e_s)
            w_n = f"{min_lon},{max_lat}"  # 西北角: 最小经度, 最大纬度
            e_n = f"{max_lon},{max_lat}"  # 东北角: 最大经度, 最大纬度
            w_s = f"{min_lon},{min_lat}"  # 西南角: 最小经度, 最小纬度
            e_s = f"{max_lon},{min_lat}"  # 东南角: 最大经度, 最小纬度

            # 按waterqsvg格式组织输出
            output[indicator] = [svg_abs, colorbar_abs, w_n, e_n, w_s, e_s]

            logger.info(
                f"✓ {indicator} 已格式化为waterqsvg兼容格式 "
                f"(svg={os.path.basename(svg_abs)}, "
                f"colorbar={os.path.basename(colorbar_abs)})"
            )

        if output:
            logger.info(f"✓ 共格式化 {len(output)} 个指标的地图输出")
        else:
            logger.warning("未能格式化任何指标的地图输出")

        return output

    @staticmethod
    def _get_geographic_bounds(report_data: ReportData) -> Optional[Dict[str, float]]:
        """从报告数据中提取地理边界信息

        优先使用原始UAV数据的范围（最可靠），
        备选方案是从配置信息中读取。

        Args:
            report_data: ReportData模型实例

        Returns:
            Optional[Dict[str, float]]: 包含min/max经纬度的字典，
                格式为 {
                    "min_longitude": float,
                    "max_longitude": float,
                    "min_latitude": float,
                    "max_latitude": float
                }
                失败时返回None
        """
        # 方案1：从UAV原始数据范围（优先）
        if (
            report_data.uav_data
            and "data" in report_data.uav_data
            and not report_data.uav_data["data"].empty
        ):
            try:
                df = report_data.uav_data["data"]

                # 查找经纬度列（支持不同的大小写）
                lon_col = None
                lat_col = None

                # 先尝试小写
                if "longitude" in df.columns:
                    lon_col = "longitude"
                elif "Longitude" in df.columns:
                    lon_col = "Longitude"

                if "latitude" in df.columns:
                    lat_col = "latitude"
                elif "Latitude" in df.columns:
                    lat_col = "Latitude"

                # 确保列存在
                if not lon_col or not lat_col:
                    logger.warning(f"UAV数据缺少经纬度列 (可用列: {list(df.columns)})")
                    return None

                bounds = {
                    "min_longitude": float(df[lon_col].min()),
                    "max_longitude": float(df[lon_col].max()),
                    "min_latitude": float(df[lat_col].min()),
                    "max_latitude": float(df[lat_col].max()),
                }

                logger.debug("从UAV原始数据范围获取地理边界")
                return bounds

            except (KeyError, ValueError, AttributeError) as e:
                logger.warning(f"从UAV数据提取地理边界失败: {e}")

        # 方案2：从配置中读取（备选）
        try:
            geo_info = report_data.config.get("geo_info", {})
            if geo_info:
                bounds = {
                    "min_longitude": float(geo_info.get("west", 0)),
                    "max_longitude": float(geo_info.get("east", 0)),
                    "min_latitude": float(geo_info.get("south", 0)),
                    "max_latitude": float(geo_info.get("north", 0)),
                }

                # 验证边界合理性
                if (
                    bounds["min_longitude"] < bounds["max_longitude"]
                    and bounds["min_latitude"] < bounds["max_latitude"]
                ):
                    logger.debug("从配置信息获取地理边界")
                    return bounds

        except (ValueError, TypeError) as e:
            logger.warning(f"从配置信息提取地理边界失败: {e}")

        logger.error("无法从任何来源获取地理边界信息")
        return None

    @staticmethod
    def output_to_stdout(output_dict: Dict[str, list]) -> None:
        """将格式化后的地图输出到标准输出

        输出JSON格式的地图信息，用于管道传输或重定向到文件。

        Args:
            output_dict: 由format_maps_to_output()返回的输出字典
        """
        try:
            json_output = json.dumps(
                output_dict,
                indent=2,
                ensure_ascii=False,
            )
            print(json_output)
            logger.debug(f"已输出 {len(output_dict)} 个指标的JSON数据到stdout")
        except Exception as e:
            logger.error(f"输出JSON到stdout失败: {e}")
            raise

    @staticmethod
    def format_and_output(
        maps: Dict[str, Dict[str, str]],
        report_data: ReportData,
    ) -> bool:
        """一步完成格式化和输出（便利方法）

        结合format_maps_to_output()和output_to_stdout()，
        直接从maps和report_data生成输出到stdout。

        Args:
            maps: ReportData中的maps字典
            report_data: ReportData模型实例

        Returns:
            bool: 操作是否成功
        """
        try:
            # 格式化输出
            output_dict = HeatmapOutputFormatter.format_maps_to_output(
                maps, report_data
            )

            if not output_dict:
                logger.warning("没有有效的地图数据可输出")
                return False

            # 输出到stdout
            HeatmapOutputFormatter.output_to_stdout(output_dict)

            logger.info("✓ 热力图输出已完成")
            return True

        except Exception as e:
            logger.exception(f"热力图输出格式化失败: {e}")
            return False
