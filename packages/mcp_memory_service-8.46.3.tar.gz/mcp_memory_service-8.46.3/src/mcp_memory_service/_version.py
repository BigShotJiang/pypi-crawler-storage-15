"""Version information for MCP Memory Service."""

__version__ = "8.46.3"
