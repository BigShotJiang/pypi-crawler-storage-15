"""Tests for GIS MCP Server."""
