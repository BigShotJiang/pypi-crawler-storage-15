"""GIS MCP Server - Geospatial tools for AI agents."""

__version__ = "1.1.0"
