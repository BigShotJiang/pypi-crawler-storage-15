# joseph-oddeven-checker

A simple Python library that checks whether a number is odd or even.

## Installation
pip install joseph-oddeven-checker

## Usage
from joseph-oddeven-checker import is_even, is_odd

print(is_even(10))  # True
print(is_odd(3))    # True
