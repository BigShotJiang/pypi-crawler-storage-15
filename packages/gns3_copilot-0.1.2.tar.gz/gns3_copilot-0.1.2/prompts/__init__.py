# Prompts module for GNS3 Copilot
