from .tts import SmallestAITTS

__all__ = [
    "SmallestAITTS",
]