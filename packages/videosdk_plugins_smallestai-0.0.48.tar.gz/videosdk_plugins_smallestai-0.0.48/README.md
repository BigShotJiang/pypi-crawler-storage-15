# VideoSDK SmallestAI Plugin

Agent Framework plugin for TTS services from SmallestAI.

## Installation

```bash
pip install videosdk-plugins-smallestai
```