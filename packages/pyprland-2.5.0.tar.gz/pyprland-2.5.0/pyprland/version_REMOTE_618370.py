"""Package version."""

VERSION = "2.4.0-29"
