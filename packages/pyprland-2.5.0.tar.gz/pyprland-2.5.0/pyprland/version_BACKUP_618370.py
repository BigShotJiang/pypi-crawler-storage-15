"""Package version."""

<<<<<<< HEAD
VERSION = "2.4.7-7"
||||||| parent of 094f89c (fix fuzzy rofi)
VERSION = "2.4.0-28"
=======
VERSION = "2.4.0-29"
>>>>>>> 094f89c (fix fuzzy rofi)
