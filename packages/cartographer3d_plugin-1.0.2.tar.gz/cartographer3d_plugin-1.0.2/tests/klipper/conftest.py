import sys
from unittest.mock import Mock

sys.modules["gcode"] = Mock()
