"""Fastpy CLI - Create production-ready FastAPI projects."""

__version__ = "0.6.1"
__author__ = "Vutia Enterprise"
__email__ = "hello@ve.ke"
