"""Local Brain - Chat with local Ollama models that can use tools."""

__version__ = "0.3.3"
