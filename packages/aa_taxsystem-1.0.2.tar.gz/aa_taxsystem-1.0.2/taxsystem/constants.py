"""
Constants
"""

# Standard Library
import os

AA_TAXSYSTEM_BASE_DIR = os.path.join(os.path.dirname(__file__))
AA_TAXSYSTEM_STATIC_DIR = os.path.join(AA_TAXSYSTEM_BASE_DIR, "static", "taxsystem")
