def get_input(text):
    """wrapped input to enable unit testing / patching"""
    return input(text)
