from sagemaker.core.utils.code_injection.codec import pascal_to_snake
