.. include:: ../README.rst

.. toctree::
    :maxdepth: 2

    api
    about
    changes


- :ref:`genindex`
