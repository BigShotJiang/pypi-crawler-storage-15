# Copyright (c) 2013 gocept gmbh & co. kg
# See also LICENSE.txt

import gocept.package.sphinxconf


_year_started = 2013
source_suffix = '.rst'
autosummary_generate = ['api.rst']

gocept.package.sphinxconf.set_defaults()
