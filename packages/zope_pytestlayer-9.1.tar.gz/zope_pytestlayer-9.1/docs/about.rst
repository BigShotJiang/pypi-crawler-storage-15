.. include:: ../HACKING.rst
.. literalinclude:: ../COPYRIGHT.txt
.. literalinclude:: ../LICENSE.txt
