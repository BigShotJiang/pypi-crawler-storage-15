===========================
Developing zope.pytestlayer
===========================

:Author:
    gocept,
    Godefroid Chapelle <gotcha@bubblenet.be>

:PyPI page:
    https://pypi.org/project/zope.pytestlayer/

:Issues:
    https://github.com/zopefoundation/zope.pytestlayer/issues

:Source code:
    https://github.com/zopefoundation/zope.pytestlayer

:Current change log:
    https://raw.githubusercontent.com/zopefoundation/zope.pytestlayer/master/CHANGES.rst
