# Dataset Catalog Reference

The dataset catalog provides constants for all available Elia OpenData datasets, organized by category.

::: elia_opendata.dataset_catalog
