# Exceptions Reference

The package provides specific exception classes for different error scenarios when working with the Elia OpenData API.

::: elia_opendata.error
