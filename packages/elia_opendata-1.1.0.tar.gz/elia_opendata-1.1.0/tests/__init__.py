"""
Test package for elia-opendata library.
"""