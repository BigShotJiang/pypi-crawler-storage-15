"""
CLI 模块
"""

from .main import run_cli

__all__ = ["run_cli"]
