"""github_issue_creator package

Version: 0.1.0
"""
__version__ = "0.1.0"
from .issue_creator import create_issue
