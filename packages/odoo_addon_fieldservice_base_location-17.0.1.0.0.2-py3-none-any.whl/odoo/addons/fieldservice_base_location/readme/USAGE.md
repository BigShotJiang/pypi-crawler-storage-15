1. Go to Contacts → Configuration → ZIPs.

2. Create a new ZIP entry.
(Tip: You can enhance this step by using the base_location_geonames_import module.)

3. Navigate to Field Service → Master Data → Locations.

Select an existing location or create a new one.

In the address section, you’ll now see the ZIP code autocomplete field.
Simply enter the ZIP code, and the system will automatically fill in all related address fields.
