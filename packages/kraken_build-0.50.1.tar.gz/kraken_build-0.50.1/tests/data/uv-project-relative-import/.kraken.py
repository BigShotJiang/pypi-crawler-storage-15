from kraken.std import python

python.install()
