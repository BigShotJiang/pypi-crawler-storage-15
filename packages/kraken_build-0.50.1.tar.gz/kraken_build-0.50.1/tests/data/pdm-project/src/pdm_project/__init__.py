def foo() -> None:
    print("Hello, world from poetry-project!")
