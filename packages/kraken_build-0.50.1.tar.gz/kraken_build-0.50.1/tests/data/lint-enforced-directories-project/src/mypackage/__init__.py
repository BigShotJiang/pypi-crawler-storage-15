"""Lint Enforced Directories Project!"""

import os  # Intentionally unused import


def main() -> str:  # intentionally missing return
    """Main function"""
    print("Hello, world from lint-enforced-directories-project!")
