from uv_project import hello


def main() -> None:
    hello()
