__version__ = "0.0.0"


def foo() -> None:
    print("Hello, world from version-project!")
