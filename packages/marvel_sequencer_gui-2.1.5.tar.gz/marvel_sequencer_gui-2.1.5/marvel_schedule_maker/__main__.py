"""Allow running as `python -m marvel_scheduler`."""

from marvel_schedule_maker.main import main

if __name__ == "__main__":
    main()