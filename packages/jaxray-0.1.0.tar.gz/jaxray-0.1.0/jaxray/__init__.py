"""jaxray: A minimal JAX interpretability library."""

from jaxray.core import intercept

__all__ = ["intercept"]
