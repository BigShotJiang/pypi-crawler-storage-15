def main():
    print("Hello from zelphi!")


if __name__ == "__main__":
    main()
