- 'VAT Report' is valid only for cases where it's met that for each Tax
  defined: all the "Account tags" of all the 'Repartition for Invoices'
  or 'Repartition for Credit Notes' are different.
- It would be nice to have in reports a column indicating the state of
  the entries when the option "All Entries" is selected in "Target
  Moves" field in a wizard
