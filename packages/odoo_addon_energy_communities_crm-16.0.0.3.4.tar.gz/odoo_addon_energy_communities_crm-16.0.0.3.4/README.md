# Energy Communities CRM

<add description>

## Changelog

## Changelog

### 2025-12-03 (v16.0.0.3.4)

- Fix precomputed warning for team_id and lead_properties attributes

### 2025-11-14 (v16.0.0.3.3)

- Fixed unitary tests

### 2025-11-12 (v16.0.0.3.2)

- Fixed translation from Catalan in the energy_communities_crm module that affects the
  new community form.

### 2025-11-06 (v16.0.0.3.1)

- Testing CRMLead mappers
- Adjust lang on lead autoresponders emails

### 2025-11-03 (v16.0.0.3.0)

- Adjustments for new public form for new community creation: New form and controller

### 2025-10-22 (v16.0.0.2.5)

- Improved MulltiCompanyEasyCreationWizard

### 2025-05-21

- Added Readme
