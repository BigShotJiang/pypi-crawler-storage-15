"""DevOps incident example placeholder."""

__all__: list[str] = []

