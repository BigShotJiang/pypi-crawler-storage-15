"""
Mock File Service
使用 Python FastAPI 模擬 Node.js Fastify 的 AVA File Service API
"""

__version__ = "0.1.0"
