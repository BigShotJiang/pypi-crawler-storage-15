"""Arize Phoenix observability integration package."""

from .phoenix_local_handler import PhoenixLocalHandler

__all__ = ["PhoenixLocalHandler"]
