# CapInvest Derivatives Extension

This extension provides derivatives data for the CapInvest Platform.

 

