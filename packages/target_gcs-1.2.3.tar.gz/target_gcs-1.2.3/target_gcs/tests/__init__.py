"""Test suite for target-gcs."""
