**To flush all authorizer cache entries on a stage**

Command::

  aws apigateway flush-stage-authorizers-cache --rest-api-id 1234123412 --stage-name dev
