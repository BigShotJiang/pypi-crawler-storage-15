# coding:utf-8

from xhtml.element.attr import Attr  # noqa:F401
from xhtml.element.css import StyleCSS  # noqa:F401
from xhtml.element.doc import HtmlDoc  # noqa:F401
from xhtml.element.tag import Body  # noqa:F401
from xhtml.element.tag import Br  # noqa:F401
from xhtml.element.tag import Div  # noqa:F401
from xhtml.element.tag import EmptyTag  # noqa:F401
from xhtml.element.tag import Form  # noqa:F401
from xhtml.element.tag import FormAttrs  # noqa:F401
from xhtml.element.tag import Head  # noqa:F401
from xhtml.element.tag import Html  # noqa:F401
from xhtml.element.tag import HtmlAttrs  # noqa:F401
from xhtml.element.tag import Input  # noqa:F401
from xhtml.element.tag import InputAttrs  # noqa:F401
from xhtml.element.tag import Span  # noqa:F401
from xhtml.element.tag import Tag  # noqa:F401
from xhtml.element.tag import TextTag  # noqa:F401
from xhtml.element.tag import Title  # noqa:F401
