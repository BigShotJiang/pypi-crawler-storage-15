# coding:utf-8

__project__ = "xhtm"
__version__ = "0.12.1"
__urlhome__ = "https://github.com/bondbox/xhtm"
__description__ = "Rendering HTML Text"

# author
__author__ = "Mingzhe Zou"
__author_email__ = "zoumingzhe@outlook.com"
