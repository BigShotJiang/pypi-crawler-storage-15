.. _modules-edge_attributes:

#################
 Edge attributes
#################

.. automodule:: anemoi.graphs.edges.attributes
   :members:
   :exclude-members: BaseEdgeAttribute
   :no-undoc-members:
   :show-inheritance:
