from mcp_server_pdf_to_markdown import main

main()