import logging

logger = logging.getLogger("coro_runner")
logger.setLevel(logging.WARNING)
logger.addHandler(logging.NullHandler())
