import numpy as np
from napari_nd_annotator import AnnotatorWidget, ListWidgetBB, InterpolationWidget

def dummy_test():
    assert False