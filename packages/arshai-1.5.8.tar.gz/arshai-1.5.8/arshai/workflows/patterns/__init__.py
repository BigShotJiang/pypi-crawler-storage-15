"""
Workflow patterns for Arshai.
"""

from .fallback import FallbackWorkflow

__all__ = [
    'FallbackWorkflow',
]