"""
Workflow extensions for Arshai.
"""

from .batch import BatchProcessor, BatchResult

__all__ = [
    'BatchProcessor',
    'BatchResult',
]