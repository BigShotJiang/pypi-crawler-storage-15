"""
Arshai built-in plugins.
"""

from .resilience import CircuitBreakerPlugin

__all__ = [
    'CircuitBreakerPlugin',
]