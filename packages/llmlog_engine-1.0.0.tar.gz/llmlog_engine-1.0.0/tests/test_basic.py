"""Basic tests for llmlog_engine."""

import pytest
import os
from pathlib import Path

# Add the package to path
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from llmlog_engine import LogStore, Query


@pytest.fixture
def fixture_path():
    """Return path to sample JSONL fixture."""
    return os.path.join(os.path.dirname(__file__), "fixtures", "sample_logs.jsonl")


@pytest.fixture
def sample_store(fixture_path):
    """Load sample logs into store."""
    return LogStore.from_jsonl(fixture_path)


def test_load_jsonl(sample_store):
    """Test JSONL loading."""
    assert sample_store.row_count() == 10


def test_basic_stats(sample_store):
    """Test basic statistics."""
    stats = sample_store.basic_stats()
    assert stats["row_count"] == 10
    assert stats["model_cardinality"] == 3  # gpt-4.1-mini, gpt-4.1, gpt-4-turbo
    assert stats["route_cardinality"] == 2   # chat, rag
    assert "latency_ms_min" in stats
    assert "latency_ms_max" in stats
    assert "latency_ms_avg" in stats
    assert stats["latency_ms_min"] == 234
    assert stats["latency_ms_max"] == 2100


def test_filter_by_model(sample_store):
    """Test filtering by model."""
    q = sample_store.query().filter(model="gpt-4.1-mini")
    df = q.aggregate(metrics={"count": "count"})
    assert len(df) == 1
    assert df.iloc[0]["count"] == 4  # 4 rows with gpt-4.1-mini


def test_filter_by_route(sample_store):
    """Test filtering by route."""
    q = sample_store.query().filter(route="chat")
    df = q.aggregate(metrics={"count": "count"})
    assert len(df) == 1
    assert df.iloc[0]["count"] == 6  # 6 rows with route=chat


def test_filter_by_latency(sample_store):
    """Test filtering by latency range."""
    q = sample_store.query().filter(min_latency_ms=1000, max_latency_ms=2000)
    df = q.aggregate(metrics={"count": "count"})
    assert len(df) == 1
    assert df.iloc[0]["count"] == 2  # 2 rows: 1203, 1500


def test_multiple_filters(sample_store):
    """Test combining multiple filters."""
    q = sample_store.query().filter(
        model="gpt-4.1",
        route="rag"
    )
    df = q.aggregate(metrics={"count": "count"})
    assert len(df) == 1
    assert df.iloc[0]["count"] == 3  # gpt-4.1 + rag


def test_group_by_model(sample_store):
    """Test grouping by model."""
    q = sample_store.query()
    df = q.aggregate(by=["model"], metrics={"count": "count"})
    assert len(df) == 3
    # Check counts for each model
    counts = {row["model"]: int(row["count"]) for _, row in df.iterrows()}
    assert counts["gpt-4.1-mini"] == 4
    assert counts["gpt-4.1"] == 3
    assert counts["gpt-4-turbo"] == 2


def test_group_by_route(sample_store):
    """Test grouping by route."""
    q = sample_store.query()
    df = q.aggregate(by=["route"], metrics={"count": "count"})
    assert len(df) == 2
    counts = {row["route"]: int(row["count"]) for _, row in df.iterrows()}
    assert counts["chat"] == 6
    assert counts["rag"] == 4


def test_group_by_multiple(sample_store):
    """Test grouping by multiple columns."""
    q = sample_store.query()
    df = q.aggregate(by=["model", "route"], metrics={"count": "count"})
    assert len(df) > 0
    # Verify structure has both columns
    assert "model" in df.columns
    assert "route" in df.columns
    assert "count" in df.columns


def test_aggregation_sum(sample_store):
    """Test sum aggregation."""
    q = sample_store.query()
    df = q.aggregate(metrics={"total_output": "sum(tokens_output)"})
    assert len(df) == 1
    # Sum all tokens_output: 921+214+512+256+768+456+512+400+621+256 = 5916
    assert int(df.iloc[0]["total_output"]) == 5916


def test_aggregation_avg(sample_store):
    """Test average aggregation."""
    q = sample_store.query()
    df = q.aggregate(metrics={"avg_latency": "avg(latency_ms)"})
    assert len(df) == 1
    # Average latency
    avg_val = df.iloc[0]["avg_latency"]
    assert 850 < avg_val < 950  # Approximate check


def test_aggregation_min_max(sample_store):
    """Test min/max aggregations."""
    q = sample_store.query()
    df = q.aggregate(
        metrics={
            "min_latency": "min(latency_ms)",
            "max_latency": "max(latency_ms)"
        }
    )
    assert len(df) == 1
    assert int(df.iloc[0]["min_latency"]) == 234
    assert int(df.iloc[0]["max_latency"]) == 2100


def test_filter_with_aggregation(sample_store):
    """Test filtering then aggregating."""
    q = sample_store.query().filter(route="chat")
    df = q.aggregate(
        by=["model"],
        metrics={"count": "count", "avg_latency": "avg(latency_ms)"}
    )
    # Chat route models: gpt-4.1-mini (3), gpt-4.1 (2), gpt-4-turbo (1)
    assert len(df) == 3
    counts = {row["model"]: int(row["count"]) for _, row in df.iterrows()}
    assert counts["gpt-4.1-mini"] == 3


def test_filter_status(sample_store):
    """Test filtering by status."""
    q = sample_store.query().filter(status="ok")
    df = q.aggregate(metrics={"count": "count"})
    assert len(df) == 1
    assert df.iloc[0]["count"] == 9  # 9 ok, 1 error


def test_filter_status_error(sample_store):
    """Test filtering by error status."""
    q = sample_store.query().filter(status="error")
    df = q.aggregate(metrics={"count": "count"})
    assert len(df) == 1
    assert df.iloc[0]["count"] == 1


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
