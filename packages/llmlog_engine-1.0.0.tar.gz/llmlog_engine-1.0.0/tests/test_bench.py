"""Benchmark: C++ columnar engine vs pure Python."""

import json
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from llmlog_engine import LogStore


def generate_large_jsonl(path: str, num_rows: int = 100_000):
    """Generate a large JSONL file for benchmarking."""
    models = ["gpt-4.1-mini", "gpt-4.1", "gpt-4-turbo", "claude-3-opus", "claude-3-sonnet"]
    routes = ["chat", "rag", "search", "compose"]
    statuses = ["ok", "error"]

    with open(path, "w") as f:
        for i in range(num_rows):
            record = {
                "ts": f"2024-01-01T10:{i % 60:02d}:{i // 60 % 60:02d}Z",
                "session_id": f"sess-{i // 10}",
                "model": models[i % len(models)],
                "latency_ms": 100 + (i * 7) % 2000,
                "tokens_input": 64 + (i * 13) % 2048,
                "tokens_output": 128 + (i * 17) % 2048,
                "route": routes[i % len(routes)],
                "status": statuses[i % 100] if i % 100 == 99 else "ok",
            }
            f.write(json.dumps(record) + "\n")


def benchmark_pure_python(path: str):
    """Benchmark pure Python approach."""
    # Load all JSON
    records = []
    with open(path) as f:
        for line in f:
            records.append(json.loads(line))

    # Filter: model == "gpt-4.1" AND latency_ms >= 1000
    start = time.time()
    filtered = [r for r in records if r["model"] == "gpt-4.1" and r["latency_ms"] >= 1000]
    pure_filter_time = time.time() - start

    # Group by route and compute metrics
    start = time.time()
    groups = {}
    for r in filtered:
        route = r["route"]
        if route not in groups:
            groups[route] = {
                "count": 0,
                "sum_latency": 0,
                "sum_output": 0,
                "min_latency": float("inf"),
                "max_latency": 0,
            }
        groups[route]["count"] += 1
        groups[route]["sum_latency"] += r["latency_ms"]
        groups[route]["sum_output"] += r["tokens_output"]
        groups[route]["min_latency"] = min(groups[route]["min_latency"], r["latency_ms"])
        groups[route]["max_latency"] = max(groups[route]["max_latency"], r["latency_ms"])

    # Compute averages
    for route in groups:
        groups[route]["avg_latency"] = groups[route]["sum_latency"] / groups[route]["count"]

    pure_agg_time = time.time() - start

    return {
        "filter_time": pure_filter_time,
        "agg_time": pure_agg_time,
        "total_time": pure_filter_time + pure_agg_time,
        "result_count": len(filtered),
    }


def benchmark_cpp_engine(path: str):
    """Benchmark C++ columnar engine."""
    # Load
    start = time.time()
    store = LogStore.from_jsonl(path)
    load_time = time.time() - start

    # Filter and aggregate
    start = time.time()
    q = store.query().filter(model="gpt-4.1", min_latency_ms=1000)
    df = q.aggregate(
        by=["route"],
        metrics={
            "count": "count",
            "sum_latency": "sum(latency_ms)",
            "sum_output": "sum(tokens_output)",
            "avg_latency": "avg(latency_ms)",
            "min_latency": "min(latency_ms)",
            "max_latency": "max(latency_ms)",
        }
    )
    query_time = time.time() - start

    return {
        "load_time": load_time,
        "query_time": query_time,
        "total_time": load_time + query_time,
        "result_count": len(df),
    }


def main():
    """Run benchmarks."""
    fixture_dir = os.path.join(os.path.dirname(__file__), "fixtures")
    os.makedirs(fixture_dir, exist_ok=True)

    bench_file = os.path.join(fixture_dir, "bench_large.jsonl")

    print("=" * 70)
    print("LLMLog Engine Benchmark: C++ vs Pure Python")
    print("=" * 70)

    # Generate test data
    num_rows = 100_000
    print(f"\nGenerating {num_rows:,} test records...")
    generate_large_jsonl(bench_file, num_rows)
    print(f"Generated {bench_file}")

    # Benchmark pure Python
    print("\n[1/2] Benchmarking pure Python approach...")
    try:
        py_results = benchmark_pure_python(bench_file)
        print(f"  Filter time:    {py_results['filter_time']:.4f}s")
        print(f"  Aggregate time: {py_results['agg_time']:.4f}s")
        print(f"  Total time:     {py_results['total_time']:.4f}s")
        print(f"  Filtered rows:  {py_results['result_count']}")
    except Exception as e:
        print(f"  Error: {e}")
        py_results = None

    # Benchmark C++ engine
    print("\n[2/2] Benchmarking C++ columnar engine...")
    try:
        cpp_results = benchmark_cpp_engine(bench_file)
        print(f"  Load time:      {cpp_results['load_time']:.4f}s")
        print(f"  Query time:     {cpp_results['query_time']:.4f}s")
        print(f"  Total time:     {cpp_results['total_time']:.4f}s")
        print(f"  Result rows:    {cpp_results['result_count']}")
    except Exception as e:
        print(f"  Error: {e}")
        cpp_results = None

    # Compare
    if py_results and cpp_results:
        print("\n" + "=" * 70)
        print("SUMMARY")
        print("=" * 70)
        speedup = py_results["total_time"] / cpp_results["total_time"]
        print(f"Pure Python:     {py_results['total_time']:.4f}s")
        print(f"C++ Engine:      {cpp_results['total_time']:.4f}s")
        print(f"Speedup:         {speedup:.2f}x faster")
        print("=" * 70)


if __name__ == "__main__":
    main()
