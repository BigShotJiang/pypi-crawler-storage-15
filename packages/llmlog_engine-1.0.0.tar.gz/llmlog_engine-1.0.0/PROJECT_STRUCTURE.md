# LLMLog Engine - Project Structure

## Directory Layout

```
llmlog_engine/
├── pyproject.toml                 # Build configuration (scikit-build-core + pybind11)
├── CMakeLists.txt                # CMake build script for C++ extension
├── README.md                       # User-facing documentation
├── DESIGN.md                       # Detailed architecture and design rationale
├── PROJECT_STRUCTURE.md            # This file
├── requirements-dev.txt            # Development dependencies
├── .gitignore                      # Git ignore rules
│
├── src/
│   └── llmlog_engine/
│       ├── __init__.py            # Python API: LogStore, Query classes
│       └── _core.pyi              # Type stubs for C++ module
│
├── src_cpp/
│   ├── llmlog_engine.h            # C++ header: DictionaryColumn, NumericColumn, LogStore, Predicate
│   ├── llmlog_engine.cpp          # C++ implementation: ingestion, filtering, aggregation
│   └── _core.cpp                  # pybind11 bindings: exports LogStore, Predicate, Op to Python
│
├── tests/
│   ├── test_basic.py              # Unit tests: load, filter, aggregate
│   ├── test_bench.py              # Benchmark: C++ vs pure Python performance
│   └── fixtures/
│       └── sample_logs.jsonl      # Sample JSONL file for testing (10 rows)
│
└── example_usage.py                # Example script demonstrating all features
```

## File Descriptions

### Configuration Files

#### `pyproject.toml`
- **Purpose:** Python package metadata and build configuration
- **Tool:** scikit-build-core (modern Python build system)
- **Specifies:**
  - Package name, version, dependencies
  - Python version requirement (3.8+)
  - CMake version requirement
  - Build type (Release for optimization)

#### `CMakeLists.txt`
- **Purpose:** C++ compilation instructions
- **Actions:**
  - Sets C++17 standard
  - Finds pybind11
  - Compiles `_llmlog_engine` extension module
  - Links C++ source files
  - Installs to Python package directory

#### `requirements-dev.txt`
- **Purpose:** Development dependency versions
- **Includes:** pytest, pandas, scikit-build-core, pybind11, cmake

### Documentation

#### `README.md`
- **Audience:** End users
- **Contents:**
  - Quick start example
  - Supported fields
  - Complete API reference
  - Usage examples (6+ scenarios)
  - Performance benchmarks
  - Installation instructions
  - Limitations and future work

#### `DESIGN.md`
- **Audience:** Developers/maintainers
- **Contents:**
  - Architecture overview
  - C++ class descriptions
  - Data flow diagrams
  - Memory layout details
  - SIMD considerations
  - Query execution strategy
  - Testing strategy
  - Deployment notes

#### `PROJECT_STRUCTURE.md`
- **Purpose:** Map of all files and their purposes
- **This document**

### Source Code - C++

#### `src_cpp/llmlog_engine.h`
- **Classes:**
  - `DictionaryColumn` — Dictionary-encoded string columns
  - `NumericColumn<T>` — Numeric array columns
  - `Predicate` — Filter condition struct
  - `LogStore` — Main table class
- **Key methods:**
  - `ingest_from_jsonl(path)` — Load JSONL
  - `apply_filter(predicates)` → boolean mask
  - `aggregate(mask, group_keys, metrics)` → aggregated results
  - `basic_stats()` → summary statistics

#### `src_cpp/llmlog_engine.cpp`
- **Implementations:**
  - `DictionaryColumn::get_or_create_id()` — Manage string → ID mapping
  - `LogStore::ingest_from_jsonl()` — Parse JSONL using nlohmann::json, populate columns
  - `LogStore::apply_filter()` — Evaluate predicates with AND logic
  - `LogStore::aggregate()` — Compute COUNT, SUM, AVG, MIN, MAX per group
- **Dependencies:**
  - `nlohmann/json.hpp` — JSON parsing (header-only)

#### `src_cpp/_core.cpp`
- **Purpose:** pybind11 bindings exposing C++ to Python
- **Exports:**
  - `LogStore` class with all public methods
  - `Predicate` struct with all fields
  - `Op` enum (EQ, NE, LT, LE, GT, GE)
- **Module name:** `_llmlog_engine` (imported as `from _llmlog_engine import ...`)

### Source Code - Python

#### `src/llmlog_engine/__init__.py`
- **Classes:**
  - `LogStore` — High-level wrapper around C++ LogStore
  - `Query` — Query builder with fluent API
- **LogStore methods:**
  - `from_jsonl(path)` — Class method to load from file
  - `row_count()` — Get number of rows
  - `basic_stats()` — Retrieve statistics
  - `query()` — Create new Query
  - `_apply_filter(predicates)` — Internal: call C++
  - `_aggregate(mask, group_keys, metrics)` — Internal: call C++
- **Query methods:**
  - `filter(model=, route=, status=, min_latency_ms=, ...)` — Add filters (returns self)
  - `aggregate(by=, metrics=)` → pd.DataFrame — Execute query
- **Logic:**
  - Builds Predicate objects from keyword arguments
  - Translates metric dicts to C++ format
  - Converts C++ result dict to pandas DataFrame
  - Parses composite group keys (separated by "|")

#### `src/llmlog_engine/_core.pyi`
- **Purpose:** Type hints for C++ module (helps IDE autocomplete)
- **Stubs for:** Op enum, Predicate class, LogStore class
- **No implementation** — pure typing information

### Tests

#### `tests/test_basic.py`
- **Test cases:** 20+ unit tests covering:
  - **Ingestion:** `test_load_jsonl()`, verify row count
  - **Filtering:** By model, route, status, latency range, combinations
  - **Grouping:** By single column (model, route), multiple columns (model + route)
  - **Aggregations:** SUM, AVG, MIN, MAX
  - **Combined:** Filter → group → aggregate workflows
- **Fixture:** `sample_logs.jsonl` with 10 diverse records
- **Assertions:** Verify counts, cardinalities, stats values
- **Run:** `pytest tests/test_basic.py -v`

#### `tests/test_bench.py`
- **Benchmark types:**
  - Pure Python: JSON load → filter with list comprehension → aggregate with for loops
  - C++ Engine: JSONL ingest → Query API → aggregation
- **Query:** Filter model="gpt-4.1" AND latency >= 1000, group by route
- **Metrics:** Load time, query time, total time
- **Output:** Speedup ratio (Python time / C++ time)
- **Expected:** 5-10x faster for C++ engine
- **Run:** `python tests/test_bench.py`

#### `tests/fixtures/sample_logs.jsonl`
- **Format:** JSONL (10 records, one per line)
- **Records:** Diverse models (gpt-4.1, gpt-4.1-mini, gpt-4-turbo), routes (chat, rag), latencies (234-2100ms)
- **One error record** to test status filtering
- **Used by:** test_basic.py

### Examples

#### `example_usage.py`
- **Purpose:** Executable examples showing all features
- **Demonstrates:**
  1. Loading JSONL
  2. Basic statistics
  3. Group by model
  4. Group by route
  5. Filter + group (latency range)
  6. Complex filter (multiple conditions)
  7. Multi-dimension grouping
  8. Filter by status
  9. Error analysis
  10. Token usage analysis
- **Output:** Pretty-printed tables using pandas
- **Run:** `python example_usage.py`

### Hidden/Config Files

#### `.gitignore`
- **Ignores:**
  - Build artifacts (`build/`, `*.so`, `*.o`)
  - Python cache (`__pycache__/`, `.pytest_cache/`)
  - IDE files (`.vscode/`, `.idea/`)
  - Benchmark data (large JSONL files generated during testing)

## Development Workflow

### 1. Setup

```bash
cd llmlog_engine
pip install -e .  # Installs package in editable mode, builds C++ extension
```

### 2. Run Tests

```bash
pytest tests/test_basic.py -v  # All unit tests
python tests/test_bench.py     # Benchmarks
```

### 3. Try Examples

```bash
python example_usage.py        # See all queries in action
```

### 4. Modify Code

- **Python changes:** Edit `src/llmlog_engine/__init__.py`, reinstall (`pip install -e .`)
- **C++ changes:** Edit `src_cpp/llmlog_engine.cpp`, rebuild (`pip install -e .` rebuilds)
- **Build config:** Edit `CMakeLists.txt`, rebuild

### 5. Iterate

Typical cycle:
1. Write test (test_basic.py)
2. Run test → fails
3. Implement feature (C++ or Python)
4. Run test → passes
5. Verify with example (example_usage.py)
6. Run benchmark to check performance

## Key Design Decisions Reflected in Files

### 1. Columnar Storage (llmlog_engine.h/cpp)
- Separate column classes instead of row-based structs
- Enables SIMD later without refactoring
- Supports efficient filtering and aggregation

### 2. Dictionary Encoding (_core.cpp integration)
- String columns → int32 IDs
- Fast equality checks exposed to Python
- Transparent to user (handled internally)

### 3. Predicate-based Filtering (llmlog_engine.h)
- Generic Predicate struct with Op enum
- Supports numeric comparisons (LT, GT, etc.) and string equality
- AND-combined via boolean mask

### 4. Builder Pattern (src/llmlog_engine/__init__.py)
- `Query.filter().aggregate()` chain
- Pythonic, readable API
- Methods return `self` for chaining

### 5. Pandas Integration (__init__.py)
- All aggregation results → pd.DataFrame
- Familiar to data scientists
- Easy downstream analysis

## Build System Rationale

### scikit-build-core
- **Why not setuptools + extension?**
  - scikit-build-core is modern, handles CMake automatically
  - Cleaner separation: Python config (pyproject.toml) vs. C++ config (CMakeLists.txt)
- **Why not other systems?**
  - Poetry: Not ideal for C++ extensions
  - Meson: Overkill for this project
  - Plain setuptools: Legacy, more boilerplate

### CMake
- **Why not plain gcc/clang commands?**
  - Portable across Linux, macOS, Windows
  - Handles pybind11 integration
  - Supports future multi-file projects

## Dependencies

### Runtime
- **pandas** — DataFrame output
- **C++ standard library** — All data structures (vector, map, string)
- **nlohmann::json** — JSON parsing (header-only, included)

### Build
- **pybind11** — C++/Python bindings
- **cmake** — Build system
- **scikit-build-core** — Python build backend
- **C++17 compiler** — GCC, Clang, MSVC

### Development
- **pytest** — Testing framework
- **pandas** — DataFrame assertions

## Performance Characteristics (Documented in DESIGN.md)

- **Ingestion:** O(rows), typically 10k-50k rows/sec
- **Filtering:** O(predicates × rows), 2-3x faster than Python
- **Aggregation:** O(matched_rows × metrics)
- **Overall:** 5-10x faster than pure Python for typical queries

## Extension Points (For Future Enhancement)

1. **New columns:** Add to LogStore's member variables + getters
2. **New filters:** Extend Predicate::Op enum + apply_filter logic
3. **New metrics:** Extend aggregate() string parser (sum, avg, etc.)
4. **SIMD optimization:** Rewrite filter/aggregate loops with intrinsics
5. **Persistence:** Add to_file() / from_file() methods
6. **Parallel execution:** Wrap loops with OpenMP directives

## Summary

The project is structured to:
- **Separate concerns:** C++ core (src_cpp/) vs. Python API (src/llmlog_engine/)
- **Enable testing:** Comprehensive test suite with fixtures and benchmarks
- **Document thoroughly:** README for users, DESIGN.md for developers
- **Demonstrate usage:** Example script and test fixtures
- **Support iteration:** Clean build system, type hints, clear interfaces

All files are intentionally concise and focused, following the principle of "do one thing well."
