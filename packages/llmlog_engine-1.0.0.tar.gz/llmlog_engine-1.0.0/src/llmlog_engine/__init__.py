"""High-performance columnar scan engine for LLM logs."""

from ._llmlog_engine import LogStore as _LogStoreCore
from ._llmlog_engine import Predicate, Op
import pandas as pd
from typing import Optional, List, Dict, Any


class LogStore:
    """Columnar log store for efficient scanning and aggregation of LLM logs."""

    def __init__(self):
        """Initialize an empty LogStore."""
        self._core = _LogStoreCore()

    @classmethod
    def from_jsonl(cls, path: str) -> "LogStore":
        """
        Load JSONL logs into the store.

        Args:
            path: Path to JSONL file

        Returns:
            LogStore instance with loaded data
        """
        store = cls()
        store._core.ingest_from_jsonl(path)
        return store

    def row_count(self) -> int:
        """Get the number of rows loaded."""
        return self._core.row_count()

    def basic_stats(self) -> Dict[str, float]:
        """Get basic statistics about the loaded data."""
        return self._core.basic_stats()

    def query(self) -> "Query":
        """Create a new query builder for this store."""
        return Query(self)

    def to_pandas(self) -> pd.DataFrame:
        """
        Convert the entire store to a pandas DataFrame.
        Note: This loads everything into memory; use for small stores only.
        """
        # This is a placeholder; in production, you'd expose column data from C++
        raise NotImplementedError("to_pandas not yet implemented")

    def _apply_filter(self, predicates: List[Predicate]) -> List[bool]:
        """Internal: Apply predicates and get boolean mask."""
        return self._core.apply_filter(predicates)

    def _aggregate(
        self,
        mask: List[bool],
        group_keys: List[str],
        metrics: List[tuple]
    ) -> Dict[str, Dict[str, float]]:
        """Internal: Run aggregation with mask."""
        return self._core.aggregate(mask, group_keys, metrics)


class Query:
    """Query builder for LogStore."""

    def __init__(self, store: LogStore):
        """Initialize query with a store."""
        self._store = store
        self._predicates: List[Predicate] = []

    def filter(
        self,
        model: Optional[str] = None,
        route: Optional[str] = None,
        status: Optional[str] = None,
        min_latency_ms: Optional[int] = None,
        max_latency_ms: Optional[int] = None,
        min_tokens_input: Optional[int] = None,
        max_tokens_input: Optional[int] = None,
        min_tokens_output: Optional[int] = None,
        max_tokens_output: Optional[int] = None,
    ) -> "Query":
        """
        Add filter predicates.

        Args:
            model: Filter by model name (string equality)
            route: Filter by route (string equality)
            status: Filter by status (string equality)
            min_latency_ms: Minimum latency in milliseconds
            max_latency_ms: Maximum latency in milliseconds
            min_tokens_input: Minimum input tokens
            max_tokens_input: Maximum input tokens
            min_tokens_output: Minimum output tokens
            max_tokens_output: Maximum output tokens

        Returns:
            Self for chaining
        """
        if model is not None:
            pred = Predicate()
            pred.column = "model"
            pred.op = Op.EQ
            pred.string_value = model
            pred.is_numeric = False
            self._predicates.append(pred)

        if route is not None:
            pred = Predicate()
            pred.column = "route"
            pred.op = Op.EQ
            pred.string_value = route
            pred.is_numeric = False
            self._predicates.append(pred)

        if status is not None:
            pred = Predicate()
            pred.column = "status"
            pred.op = Op.EQ
            pred.string_value = status
            pred.is_numeric = False
            self._predicates.append(pred)

        if min_latency_ms is not None:
            pred = Predicate()
            pred.column = "latency_ms"
            pred.op = Op.GE
            pred.int32_value = min_latency_ms
            pred.is_numeric = True
            self._predicates.append(pred)

        if max_latency_ms is not None:
            pred = Predicate()
            pred.column = "latency_ms"
            pred.op = Op.LE
            pred.int32_value = max_latency_ms
            pred.is_numeric = True
            self._predicates.append(pred)

        if min_tokens_input is not None:
            pred = Predicate()
            pred.column = "tokens_input"
            pred.op = Op.GE
            pred.int32_value = min_tokens_input
            pred.is_numeric = True
            self._predicates.append(pred)

        if max_tokens_input is not None:
            pred = Predicate()
            pred.column = "tokens_input"
            pred.op = Op.LE
            pred.int32_value = max_tokens_input
            pred.is_numeric = True
            self._predicates.append(pred)

        if min_tokens_output is not None:
            pred = Predicate()
            pred.column = "tokens_output"
            pred.op = Op.GE
            pred.int32_value = min_tokens_output
            pred.is_numeric = True
            self._predicates.append(pred)

        if max_tokens_output is not None:
            pred = Predicate()
            pred.column = "tokens_output"
            pred.op = Op.LE
            pred.int32_value = max_tokens_output
            pred.is_numeric = True
            self._predicates.append(pred)

        return self

    def aggregate(
        self,
        by: Optional[List[str]] = None,
        metrics: Optional[Dict[str, str]] = None
    ) -> pd.DataFrame:
        """
        Compute aggregations.

        Args:
            by: List of columns to group by (e.g., ["model", "route"])
            metrics: Dict of {output_name: aggregation_expression}
                   e.g., {"count": "count", "avg_latency": "avg(latency_ms)"}

        Returns:
            pandas DataFrame with results
        """
        if metrics is None:
            metrics = {"count": "count"}
        if by is None:
            by = []

        # Apply filters to get boolean mask
        mask = self._store._apply_filter(self._predicates)

        # Convert metrics dict to list of tuples for C++
        metric_list = list(metrics.items())

        # Call C++ aggregation
        result_dict = self._store._aggregate(mask, by, metric_list)

        # Convert to pandas DataFrame
        rows = []
        for group_key, group_metrics in result_dict.items():
            row = {}
            if by:
                # Parse composite group key
                parts = group_key.split("|")
                for col_name, val in zip(by, parts):
                    row[col_name] = val
            else:
                row["group"] = group_key
            row.update(group_metrics)
            rows.append(row)

        df = pd.DataFrame(rows)
        return df


__all__ = ["LogStore", "Query"]
