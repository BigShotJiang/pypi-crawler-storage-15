#ifndef LLMLOG_ENGINE_H
#define LLMLOG_ENGINE_H

#include <cstdint>
#include <string>
#include <vector>
#include <unordered_map>
#include <memory>
#include <bitset>
#include <algorithm>

namespace llmlog {

// Dictionary-encoded string column: stores unique strings and maps rows to int32 IDs
class DictionaryColumn {
public:
    // Get or create ID for a string (for ingestion)
    int32_t get_or_create_id(const std::string& value);

    // Get ID for a string without creating (returns -1 if not found)
    int32_t get_id(const std::string& value) const {
        auto it = string_to_id.find(value);
        return (it != string_to_id.end()) ? it->second : -1;
    }

    // Get string by ID
    const std::string& get_string(int32_t id) const;

    // Append an ID to this column
    void append(int32_t id) { ids.push_back(id); }

    // Return the ID at row index
    int32_t at(size_t row) const { return ids[row]; }

    // Size of the column
    size_t size() const { return ids.size(); }

    // Get all unique strings (for inspection)
    const std::vector<std::string>& get_dictionary() const { return strings; }

    // Get all IDs
    const std::vector<int32_t>& get_ids() const { return ids; }

    // Clear the column
    void clear() {
        ids.clear();
        strings.clear();
        string_to_id.clear();
    }

private:
    std::vector<std::string> strings;           // unique values
    std::vector<int32_t> ids;                   // row -> ID mapping
    std::unordered_map<std::string, int32_t> string_to_id;  // reverse mapping
};

// Numeric column: simple contiguous array
template <typename T>
class NumericColumn {
public:
    void append(T value) { data.push_back(value); }

    T at(size_t row) const { return data[row]; }

    size_t size() const { return data.size(); }

    const std::vector<T>& get_data() const { return data; }

    void clear() { data.clear(); }

private:
    std::vector<T> data;
};

// Predicate for filtering
struct Predicate {
    enum class Op { EQ, NE, LT, LE, GT, GE };

    std::string column;
    Op op;
    std::string string_value;
    int32_t int32_value;
    bool is_numeric;
};

// Main table class
class LogStore {
public:
    LogStore() = default;

    // Ingest from JSONL file
    void ingest_from_jsonl(const std::string& path);

    // Get row count
    size_t row_count() const { return row_count_; }

    // Apply a filter and return a bitset indicating matching rows
    std::vector<bool> apply_filter(const std::vector<Predicate>& predicates) const;

    // Aggregate: compute metrics grouped by dimensions
    // Returns: map of (group_key -> map of (metric_name -> value))
    // group_keys: e.g., ["model", "route"]
    // mask: boolean vector indicating which rows to include
    std::unordered_map<std::string, std::unordered_map<std::string, double>>
    aggregate(
        const std::vector<bool>& mask,
        const std::vector<std::string>& group_keys,
        const std::vector<std::pair<std::string, std::string>>& metrics
    ) const;

    // Get basic stats
    std::unordered_map<std::string, double> basic_stats() const;

    // For debugging
    size_t get_model_cardinality() const { return model_col.get_dictionary().size(); }
    size_t get_route_cardinality() const { return route_col.get_dictionary().size(); }

private:
    size_t row_count_ = 0;

    // Dictionary-encoded columns
    DictionaryColumn model_col;
    DictionaryColumn route_col;
    DictionaryColumn status_col;
    DictionaryColumn session_id_col;
    DictionaryColumn ts_col;
    DictionaryColumn error_type_col;

    // Numeric columns
    NumericColumn<int32_t> latency_ms_col;
    NumericColumn<int32_t> tokens_input_col;
    NumericColumn<int32_t> tokens_output_col;

    // Helper to get column by name
    const DictionaryColumn* get_dict_column(const std::string& name) const;
    const NumericColumn<int32_t>* get_numeric_column(const std::string& name) const;
};

}  // namespace llmlog

#endif  // LLMLOG_ENGINE_H
