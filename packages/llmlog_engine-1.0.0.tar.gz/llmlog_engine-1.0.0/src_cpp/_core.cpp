#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include "llmlog_engine.h"

namespace py = pybind11;
using namespace llmlog;

PYBIND11_MODULE(_llmlog_engine, m) {
    m.doc() = "High-performance columnar scan engine for LLM logs";

    // Predicate class
    py::class_<Predicate>(m, "Predicate")
        .def(py::init<>())
        .def_readwrite("column", &Predicate::column)
        .def_readwrite("op", &Predicate::op)
        .def_readwrite("string_value", &Predicate::string_value)
        .def_readwrite("int32_value", &Predicate::int32_value)
        .def_readwrite("is_numeric", &Predicate::is_numeric);

    // Predicate::Op enum
    py::enum_<Predicate::Op>(m, "Op")
        .value("EQ", Predicate::Op::EQ)
        .value("NE", Predicate::Op::NE)
        .value("LT", Predicate::Op::LT)
        .value("LE", Predicate::Op::LE)
        .value("GT", Predicate::Op::GT)
        .value("GE", Predicate::Op::GE)
        .export_values();

    // LogStore class
    py::class_<LogStore>(m, "LogStore")
        .def(py::init<>())
        .def("ingest_from_jsonl", &LogStore::ingest_from_jsonl, "Load JSONL file into the store")
        .def("row_count", &LogStore::row_count, "Get number of rows loaded")
        .def("apply_filter", &LogStore::apply_filter, "Apply filter predicates and return boolean mask")
        .def("aggregate", &LogStore::aggregate,
             "Compute aggregations: aggregate(mask, group_keys, metrics)")
        .def("basic_stats", &LogStore::basic_stats, "Get basic statistics about the data")
        .def("get_model_cardinality", &LogStore::get_model_cardinality)
        .def("get_route_cardinality", &LogStore::get_route_cardinality);
}
