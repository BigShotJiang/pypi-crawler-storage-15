#include "llmlog_engine.h"
#include <nlohmann/json.hpp>
#include <fstream>
#include <sstream>
#include <iostream>
#include <cmath>

using json = nlohmann::json;

namespace llmlog {

// DictionaryColumn implementation
int32_t DictionaryColumn::get_or_create_id(const std::string& value) {
    auto it = string_to_id.find(value);
    if (it != string_to_id.end()) {
        return it->second;
    }
    int32_t id = static_cast<int32_t>(strings.size());
    strings.push_back(value);
    string_to_id[value] = id;
    return id;
}

const std::string& DictionaryColumn::get_string(int32_t id) const {
    if (id < 0 || id >= static_cast<int32_t>(strings.size())) {
        static std::string null_str = "";
        return null_str;
    }
    return strings[id];
}

// LogStore implementation
void LogStore::ingest_from_jsonl(const std::string& path) {
    std::ifstream file(path);
    if (!file.is_open()) {
        throw std::runtime_error("Cannot open file: " + path);
    }

    std::string line;
    while (std::getline(file, line)) {
        if (line.empty()) continue;

        try {
            json obj = json::parse(line);

            // Parse fields with defaults
            std::string ts = obj.value("ts", "");
            std::string session_id = obj.value("session_id", "");
            std::string model = obj.value("model", "unknown");
            int32_t latency_ms = obj.value("latency_ms", 0);
            int32_t tokens_input = obj.value("tokens_input", 0);
            int32_t tokens_output = obj.value("tokens_output", 0);
            std::string route = obj.value("route", "unknown");
            std::string status = obj.value("status", "ok");
            std::string error_type = obj.value("error_type", "");

            // Append to columns
            ts_col.append(ts_col.get_or_create_id(ts));
            session_id_col.append(session_id_col.get_or_create_id(session_id));
            model_col.append(model_col.get_or_create_id(model));
            latency_ms_col.append(latency_ms);
            tokens_input_col.append(tokens_input);
            tokens_output_col.append(tokens_output);
            route_col.append(route_col.get_or_create_id(route));
            status_col.append(status_col.get_or_create_id(status));
            error_type_col.append(error_type_col.get_or_create_id(error_type));

            row_count_++;
        } catch (const std::exception& e) {
            std::cerr << "Warning: skipping malformed JSON line: " << e.what() << std::endl;
        }
    }
}

const DictionaryColumn* LogStore::get_dict_column(const std::string& name) const {
    if (name == "model") return &model_col;
    if (name == "route") return &route_col;
    if (name == "status") return &status_col;
    if (name == "session_id") return &session_id_col;
    if (name == "ts") return &ts_col;
    if (name == "error_type") return &error_type_col;
    return nullptr;
}

const NumericColumn<int32_t>* LogStore::get_numeric_column(const std::string& name) const {
    if (name == "latency_ms") return &latency_ms_col;
    if (name == "tokens_input") return &tokens_input_col;
    if (name == "tokens_output") return &tokens_output_col;
    return nullptr;
}

std::vector<bool> LogStore::apply_filter(const std::vector<Predicate>& predicates) const {
    std::vector<bool> mask(row_count_, true);

    for (const auto& pred : predicates) {
        if (pred.is_numeric) {
            // Numeric filter
            auto col = get_numeric_column(pred.column);
            if (!col) continue;

            const auto& data = col->get_data();
            for (size_t i = 0; i < row_count_; ++i) {
                if (!mask[i]) continue;

                int32_t val = data[i];
                bool matches = false;

                switch (pred.op) {
                    case Predicate::Op::EQ: matches = (val == pred.int32_value); break;
                    case Predicate::Op::NE: matches = (val != pred.int32_value); break;
                    case Predicate::Op::LT: matches = (val < pred.int32_value); break;
                    case Predicate::Op::LE: matches = (val <= pred.int32_value); break;
                    case Predicate::Op::GT: matches = (val > pred.int32_value); break;
                    case Predicate::Op::GE: matches = (val >= pred.int32_value); break;
                }

                mask[i] = mask[i] && matches;
            }
        } else {
            // Dictionary (string) filter
            auto col = get_dict_column(pred.column);
            if (!col) continue;

            int32_t target_id = col->get_id(pred.string_value);
            // If the value doesn't exist in the dictionary, no rows match (except for NE)
            const auto& ids = col->get_ids();

            for (size_t i = 0; i < row_count_; ++i) {
                if (!mask[i]) continue;

                int32_t val_id = ids[i];
                bool matches = false;

                switch (pred.op) {
                    case Predicate::Op::EQ: matches = (val_id == target_id && target_id != -1); break;
                    case Predicate::Op::NE: matches = (val_id != target_id || target_id == -1); break;
                    default: break;  // Other ops don't apply to strings
                }

                mask[i] = mask[i] && matches;
            }
        }
    }

    return mask;
}

std::unordered_map<std::string, std::unordered_map<std::string, double>>
LogStore::aggregate(
    const std::vector<bool>& mask,
    const std::vector<std::string>& group_keys,
    const std::vector<std::pair<std::string, std::string>>& metrics
) const {
    std::unordered_map<std::string, std::unordered_map<std::string, double>> result;

    // If no group keys, aggregate all matching rows
    if (group_keys.empty()) {
        std::string group_key = "all";
        auto& group_data = result[group_key];

        for (const auto& [metric_name, metric_expr] : metrics) {
            if (metric_expr == "count") {
                double count = 0;
                for (size_t i = 0; i < row_count_; ++i) {
                    if (mask[i]) count++;
                }
                group_data[metric_name] = count;
            } else if (metric_expr.substr(0, 4) == "sum(") {
                std::string col_name = metric_expr.substr(4, metric_expr.length() - 5);
                auto col = get_numeric_column(col_name);
                if (col) {
                    double sum = 0;
                    const auto& data = col->get_data();
                    for (size_t i = 0; i < row_count_; ++i) {
                        if (mask[i]) sum += data[i];
                    }
                    group_data[metric_name] = sum;
                }
            } else if (metric_expr.substr(0, 4) == "avg(") {
                std::string col_name = metric_expr.substr(4, metric_expr.length() - 5);
                auto col = get_numeric_column(col_name);
                if (col) {
                    double sum = 0;
                    double count = 0;
                    const auto& data = col->get_data();
                    for (size_t i = 0; i < row_count_; ++i) {
                        if (mask[i]) {
                            sum += data[i];
                            count++;
                        }
                    }
                    group_data[metric_name] = (count > 0) ? (sum / count) : 0.0;
                }
            } else if (metric_expr.substr(0, 4) == "min(") {
                std::string col_name = metric_expr.substr(4, metric_expr.length() - 5);
                auto col = get_numeric_column(col_name);
                if (col) {
                    double min_val = std::numeric_limits<double>::max();
                    const auto& data = col->get_data();
                    bool found = false;
                    for (size_t i = 0; i < row_count_; ++i) {
                        if (mask[i]) {
                            min_val = std::min(min_val, static_cast<double>(data[i]));
                            found = true;
                        }
                    }
                    group_data[metric_name] = found ? min_val : 0.0;
                }
            } else if (metric_expr.substr(0, 4) == "max(") {
                std::string col_name = metric_expr.substr(4, metric_expr.length() - 5);
                auto col = get_numeric_column(col_name);
                if (col) {
                    double max_val = std::numeric_limits<double>::lowest();
                    const auto& data = col->get_data();
                    bool found = false;
                    for (size_t i = 0; i < row_count_; ++i) {
                        if (mask[i]) {
                            max_val = std::max(max_val, static_cast<double>(data[i]));
                            found = true;
                        }
                    }
                    group_data[metric_name] = found ? max_val : 0.0;
                }
            }
        }
        return result;
    }

    // Build groups based on group keys
    std::unordered_map<std::string, std::vector<size_t>> groups;

    for (size_t i = 0; i < row_count_; ++i) {
        if (!mask[i]) continue;

        // Build composite group key
        std::string group_key;
        for (size_t j = 0; j < group_keys.size(); ++j) {
            if (j > 0) group_key += "|";

            auto col = get_dict_column(group_keys[j]);
            if (col) {
                int32_t id = col->get_ids()[i];
                group_key += col->get_string(id);
            }
        }

        groups[group_key].push_back(i);
    }

    // Compute metrics for each group
    for (const auto& [group_key, row_indices] : groups) {
        auto& group_data = result[group_key];

        for (const auto& [metric_name, metric_expr] : metrics) {
            if (metric_expr == "count") {
                group_data[metric_name] = static_cast<double>(row_indices.size());
            } else if (metric_expr.substr(0, 4) == "sum(") {
                std::string col_name = metric_expr.substr(4, metric_expr.length() - 5);
                auto col = get_numeric_column(col_name);
                if (col) {
                    double sum = 0;
                    const auto& data = col->get_data();
                    for (size_t idx : row_indices) {
                        sum += data[idx];
                    }
                    group_data[metric_name] = sum;
                }
            } else if (metric_expr.substr(0, 4) == "avg(") {
                std::string col_name = metric_expr.substr(4, metric_expr.length() - 5);
                auto col = get_numeric_column(col_name);
                if (col) {
                    double sum = 0;
                    const auto& data = col->get_data();
                    for (size_t idx : row_indices) {
                        sum += data[idx];
                    }
                    group_data[metric_name] = sum / row_indices.size();
                }
            } else if (metric_expr.substr(0, 4) == "min(") {
                std::string col_name = metric_expr.substr(4, metric_expr.length() - 5);
                auto col = get_numeric_column(col_name);
                if (col) {
                    double min_val = std::numeric_limits<double>::max();
                    const auto& data = col->get_data();
                    for (size_t idx : row_indices) {
                        min_val = std::min(min_val, static_cast<double>(data[idx]));
                    }
                    group_data[metric_name] = min_val;
                }
            } else if (metric_expr.substr(0, 4) == "max(") {
                std::string col_name = metric_expr.substr(4, metric_expr.length() - 5);
                auto col = get_numeric_column(col_name);
                if (col) {
                    double max_val = std::numeric_limits<double>::lowest();
                    const auto& data = col->get_data();
                    for (size_t idx : row_indices) {
                        max_val = std::max(max_val, static_cast<double>(data[idx]));
                    }
                    group_data[metric_name] = max_val;
                }
            }
        }
    }

    return result;
}

std::unordered_map<std::string, double> LogStore::basic_stats() const {
    std::unordered_map<std::string, double> stats;

    stats["row_count"] = static_cast<double>(row_count_);
    stats["model_cardinality"] = static_cast<double>(model_col.get_dictionary().size());
    stats["route_cardinality"] = static_cast<double>(route_col.get_dictionary().size());

    if (!latency_ms_col.get_data().empty()) {
        const auto& data = latency_ms_col.get_data();
        double min_val = *std::min_element(data.begin(), data.end());
        double max_val = *std::max_element(data.begin(), data.end());
        double sum = 0;
        for (int32_t v : data) sum += v;
        stats["latency_ms_min"] = min_val;
        stats["latency_ms_max"] = max_val;
        stats["latency_ms_avg"] = sum / data.size();
    }

    return stats;
}

}  // namespace llmlog
