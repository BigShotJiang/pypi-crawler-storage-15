# LLMLog Engine - Architecture Diagrams

## System Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         Python User Code                         │
│                                                                  │
│  from llmlog_engine import LogStore                             │
│  store = LogStore.from_jsonl("logs.jsonl")                      │
│  result = store.query().filter(...).aggregate(...)             │
└──────────────────────────────┬──────────────────────────────────┘
                               │
                ┌──────────────▼──────────────┐
                │   Python API Layer          │
                │  (src/llmlog_engine/)       │
                │                            │
                │  • LogStore (wrapper)      │
                │  • Query (builder)         │
                │  • Type hints              │
                └──────────────┬──────────────┘
                               │
          ┌────────────────────▼────────────────────┐
          │   pybind11 Bindings (_core.cpp)        │
          │                                         │
          │  • Expose LogStore class               │
          │  • Expose Predicate struct             │
          │  • Expose Op enum                      │
          └────────────────────┬────────────────────┘
                               │
┌──────────────────────────────▼──────────────────────────────────┐
│                    C++ Core Engine (src_cpp/)                    │
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  LogStore (main orchestrator)                           │   │
│  │  ├─ ingest_from_jsonl(path) → populate columns          │   │
│  │  ├─ apply_filter(predicates) → boolean mask             │   │
│  │  └─ aggregate(mask, groups, metrics) → results          │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │ Dictionary   │  │ Dictionary   │  │ Dictionary   │          │
│  │ Columns      │  │ Columns      │  │ Columns      │          │
│  │              │  │              │  │              │          │
│  │ model        │  │ route        │  │ status       │          │
│  │ session_id   │  │ ts           │  │ error_type   │          │
│  │              │  │              │  │              │          │
│  │ IDs + Dict   │  │ IDs + Dict   │  │ IDs + Dict   │          │
│  └──────────────┘  └──────────────┘  └──────────────┘          │
│                                                                  │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │ Numeric      │  │ Numeric      │  │ Numeric      │          │
│  │ Columns      │  │ Columns      │  │ Columns      │          │
│  │              │  │              │  │              │          │
│  │ latency_ms   │  │ tokens_input │  │tokens_output │          │
│  │              │  │              │  │              │          │
│  │ int32 array  │  │ int32 array  │  │ int32 array  │          │
│  └──────────────┘  └──────────────┘  └──────────────┘          │
│                                                                  │
└──────────────────────────────────────────────────────────────────┘
                               ▲
                               │
         ┌─────────────────────┴─────────────────────┐
         │  External Dependencies                     │
         │                                            │
         │  • nlohmann::json (JSON parsing)           │
         │  • C++17 standard library                  │
         │  • pybind11 (Python bindings)              │
         └────────────────────────────────────────────┘
```

## Data Flow: Ingestion

```
JSONL File
│
├─ {"ts": "...", "model": "gpt-4.1", "latency_ms": 423, ...}
├─ {"ts": "...", "model": "gpt-4.1-mini", "latency_ms": 512, ...}
├─ {"ts": "...", "model": "gpt-4.1", "latency_ms": 1203, ...}
└─ ...

                        ↓

     nlohmann::json::parse(line)
            for each line

                        ↓

  ┌──────────────────────────────────────────┐
  │  For each JSON object:                   │
  │                                          │
  │  ts → ts_col.get_or_create_id(...)      │
  │  model → model_col.get_or_create_id(...) │
  │  latency_ms → latency_ms_col.append(...) │
  │  tokens_input → tokens_input_col.append  │
  │  tokens_output → tokens_output_col.append│
  │  ...                                      │
  └──────────────────────────────────────────┘

                        ↓

  ┌────────────────────────────────────────────────────┐
  │  In-Memory Columnar Storage (LogStore)             │
  │                                                    │
  │  model_col:                                        │
  │    IDs: [0, 1, 0, 2, 1, ...]                      │
  │    Dict: {0: "gpt-4.1", 1: "gpt-4.1-mini", ...}  │
  │                                                    │
  │  latency_ms_col:                                   │
  │    Data: [423, 512, 1203, 891, ...]               │
  │                                                    │
  │  tokens_output_col:                               │
  │    Data: [921, 512, 214, 768, ...]                │
  │                                                    │
  │  ... (more columns)                               │
  └────────────────────────────────────────────────────┘
```

## Data Flow: Filtering

```
Python API:
  store.query()
    .filter(model="gpt-4.1", min_latency_ms=1000)

                        ↓

Build Predicate List:
  [
    Predicate(column="model", op=EQ, string_value="gpt-4.1"),
    Predicate(column="latency_ms", op=GE, int32_value=1000)
  ]

                        ↓

C++ LogStore::apply_filter(predicates):

  Initialize: mask = [true, true, true, true, true, ...]

  For each Predicate:
    - model == "gpt-4.1"
      Get ID for "gpt-4.1" → 0
      For each row i:
        if model_col[i] != 0:
          mask[i] = false
      Result: mask = [true, false, false, false, true, ...]

    - latency_ms >= 1000
      For each row i:
        if latency_ms_col[i] < 1000:
          mask[i] = false
      Result: mask = [false, false, false, true, true, ...]

  Final mask: [false, false, false, true, true, ...]

  Return: vector<bool> mask

                        ↓

Python:
  Store mask internally for next operation
  (mask[i] = true → row i matches ALL predicates)
```

## Data Flow: Aggregation

```
Input:
  mask: [false, false, false, true, true, ...]  (which rows match)
  group_keys: ["model", "route"]                (group by these)
  metrics: {
    "count": "count",
    "avg_latency": "avg(latency_ms)"
  }

                        ↓

C++ LogStore::aggregate():

Step 1: Build Groups
  For each row i where mask[i] == true:
    group_key = model_col[i] + "|" + route_col[i]
    groups[group_key].push_back(i)

  Result:
    groups["gpt-4.1|rag"] = [3, 5, 7, ...]
    groups["gpt-4-turbo|rag"] = [4, 8, ...]

Step 2: Compute Metrics per Group
  For group "gpt-4.1|rag" with rows [3, 5, 7]:
    "count": 3
    "avg_latency": (latency_ms[3] + latency_ms[5] + latency_ms[7]) / 3
                 = (1203 + 567 + 1500) / 3
                 = 1090.0

  For group "gpt-4-turbo|rag" with rows [4, 8]:
    "count": 2
    "avg_latency": (891 + 1500) / 2
                 = 1195.5

Step 3: Format Results
  Return:
    {
      "gpt-4.1|rag": {"count": 3, "avg_latency": 1090.0},
      "gpt-4-turbo|rag": {"count": 2, "avg_latency": 1195.5}
    }

                        ↓

Python:
  Parse group keys: "gpt-4.1|rag" → {"model": "gpt-4.1", "route": "rag"}

  Build DataFrame rows:
    [
      {"model": "gpt-4.1", "route": "rag", "count": 3, "avg_latency": 1090.0},
      {"model": "gpt-4-turbo", "route": "rag", "count": 2, "avg_latency": 1195.5}
    ]

  Return: pd.DataFrame with above data
```

## Memory Layout Example

```
JSONL Input (3 rows):
  {"model": "gpt-4.1", "route": "chat", "latency_ms": 423}
  {"model": "gpt-4.1-mini", "route": "rag", "latency_ms": 512}
  {"model": "gpt-4.1", "route": "chat", "latency_ms": 1203}

                        ↓

Columnar Storage (after ingestion):

┌─────────────────────────────────────────┐
│ DictionaryColumn: model                 │
├─────────────────────────────────────────┤
│ IDs:  [0, 1, 0]                         │
│ Dict: {                                 │
│   0: "gpt-4.1",                         │
│   1: "gpt-4.1-mini"                     │
│ }                                       │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│ DictionaryColumn: route                 │
├─────────────────────────────────────────┤
│ IDs:  [0, 1, 0]                         │
│ Dict: {                                 │
│   0: "chat",                            │
│   1: "rag"                              │
│ }                                       │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│ NumericColumn<int32_t>: latency_ms      │
├─────────────────────────────────────────┤
│ Data: [423, 512, 1203]                  │
│                                         │
│ (Contiguous memory, SIMD-friendly)      │
└─────────────────────────────────────────┘

Space Efficiency:
  JSON (raw): ~150 bytes (strings stored multiple times)
  Columnar: ~80 bytes (strings deduplicated)
  Space savings: ~45%
```

## Class Relationships

```
┌────────────────────────────────┐
│  LogStore                      │
│  (main orchestrator)           │
└────────────────────────────────┘
         ▲
         │ owns
         │
    ┌────┴──────────────────────────┬─────────────┬──────────────┐
    │                               │             │              │
    ▼                               ▼             ▼              ▼
┌─────────────────┐  ┌──────────────────┐  ┌──────────────┐  ┌──────────────┐
│DictionaryColumn │  │DictionaryColumn  │  │DictionaryCol │  │NumericColumn │
│(model)          │  │(route)           │  │(status)      │  │(latency_ms)  │
└─────────────────┘  └──────────────────┘  └──────────────┘  └──────────────┘
  • IDs: vec<i32>      • IDs: vec<i32>       • IDs: vec<i32>   • Data: vec<i32>
  • Dict: map<str>     • Dict: map<str>      • Dict: map<str>

(Similar for other columns: session_id, ts, error_type, tokens_input, tokens_output)

                        ▲
                        │ used by
                        │
        ┌───────────────┴────────────────┐
        │                                │
        ▼                                ▼
┌──────────────────┐          ┌────────────────────┐
│ apply_filter()   │          │ aggregate()        │
│                  │          │                    │
│ Evaluates        │          │ Groups & computes  │
│ predicates,      │          │ COUNT, SUM, AVG,   │
│ builds mask      │          │ MIN, MAX           │
└──────────────────┘          └────────────────────┘
        │                                │
        └────────────────┬───────────────┘
                         │
                         ▼
              Result: vector<bool> mask
              (which rows match filters)
```

## Query Execution Timeline

```
Time ──────────────────────────────────────────────►

User creates query:
  q = store.query().filter(...).aggregate(...)
  │
  ├─ store.query()           ✓ Instant (returns Query object)
  │
  ├─ .filter(...)            ✓ Instant (builds Predicate list)
  │
  └─ .aggregate(...)         ⏱️  Executes C++:
     │
     ├─ apply_filter()       ⏱️  O(predicates × rows)
     │                           ~few ms for 100k rows
     │
     ├─ build groups         ⏱️  O(filtered rows)
     │
     ├─ compute metrics      ⏱️  O(filtered rows × metrics)
     │
     └─ convert to DF        ✓ Fast (Python pandas)

        Result: pd.DataFrame
```

## Predicate Evaluation Logic

```
For each Predicate p in predicates:
  For each row i in 0..row_count:
    if mask[i] == false:
      continue  (already filtered out)

    if p.is_numeric:
      col_value = numeric_column[i]
      match = eval_numeric_op(col_value, p.op, p.int32_value)
    else:
      dict_id = dict_column.get_ids()[i]
      target_id = dict_column.get_or_create_id(p.string_value)
      match = eval_string_op(dict_id, p.op, target_id)

    mask[i] = mask[i] AND match

Example (numeric):
  p = {column: "latency_ms", op: GE, int32_value: 1000}
  For row 5:
    col_value = latency_ms_col[5] = 1203
    match = (1203 >= 1000) = true
    mask[5] = mask[5] AND true

Example (string):
  p = {column: "model", op: EQ, string_value: "gpt-4.1"}
  For row 3:
    dict_id = model_col.get_ids()[3] = 0
    target_id = model_col.get_or_create_id("gpt-4.1") = 0
    match = (0 == 0) = true
    mask[3] = mask[3] AND true
```

## Performance Scaling

```
Throughput (rows/sec) vs. Data Size

     1M rows/sec │
                 │                           ╭─── Perfect (linear)
                 │                      ╭───╱
     100k rows/s │                 ╭───╱
                 │            ╭───╱    Filtering (actual)
                 │       ╭───╱
      10k rows/s │  ╭───╱
                 │╱
                 └─────────────────────────────
                 1K      10K     100K    1M    10M rows
                         Data Size

Legend:
  - Filtering: ~200k-500k rows/sec (depending on selectivity)
  - Aggregation: ~50k-200k rows/sec (depending on #metrics)
  - Full query: ~10k-100k rows/sec (depends on selectivity × metrics)

Key insight:
  - Dictionary encoding → int32 comparisons → very fast
  - Contiguous numeric arrays → CPU cache-friendly
  - No memory allocations in hot loop → predictable performance
```

## Build Process Diagram

```
User: pip install -e .
     │
     ▼
pyproject.toml
  (scikit-build-core config)
     │
     ├─ Reads build requirements
     ├─ Specifies CMake as backend
     └─ Sets package metadata
        │
        ▼
   CMakeLists.txt
     │
     ├─ Find pybind11
     ├─ Compile _core.cpp + llmlog_engine.cpp
     ├─ Link C++ standard library
     └─ Create _llmlog_engine.so (or .pyd on Windows)
        │
        ├─────────────────────┐
        │                     │
        ▼                     ▼
   _core.cpp          llmlog_engine.cpp
   (pybind11         (LogStore impl)
    bindings)
        │                     │
        ├─────────────────────┤
        │                     │
        ▼                     ▼
   Exports:            Uses:
   • LogStore          • DictionaryColumn
   • Predicate         • NumericColumn
   • Op enum           • nlohmann::json
     │                 │
     └─────────────────┘
        │
        ▼
   _llmlog_engine.so (C++ extension)
        │
        ▼
   src/llmlog_engine/__init__.py
   (Python wrapper)
        │
        ▼
   Installed Python package
   (importable as: from llmlog_engine import LogStore)
```

These diagrams provide visual understanding of:
1. System architecture and component relationships
2. Data flow through ingestion, filtering, aggregation
3. Memory layouts and efficiency
4. Query execution timeline
5. Build process
