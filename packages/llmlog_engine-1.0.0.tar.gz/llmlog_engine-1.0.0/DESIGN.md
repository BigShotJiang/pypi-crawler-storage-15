# LLMLog Engine - Design Document

## Overview

LLMLog Engine is a high-performance columnar scan engine specialized for analyzing LLM application logs stored as JSONL. The core is implemented in **C++17** with SIMD-friendly data structures and dictionary encoding. Python bindings expose a clean, Pythonic API using pybind11.

## Architecture

### C++ Core Components

#### 1. **DictionaryColumn** (llmlog_engine.h/cpp)

Handles dictionary-encoded string columns for low-cardinality data.

```cpp
class DictionaryColumn {
  private:
    std::vector<std::string> strings;              // Unique values
    std::vector<int32_t> ids;                      // Row → ID mapping
    std::unordered_map<std::string, int32_t> string_to_id;  // Reverse lookup
};
```

**Purpose:**
- Reduce memory footprint (int32 ID vs. full string)
- Enable SIMD-friendly comparisons on int32 instead of strings
- Used for: `model`, `route`, `status`, `session_id`, `ts`, `error_type`

**Example:**
```
Dictionary: {"gpt-4.1": 0, "gpt-4.1-mini": 1, "gpt-4-turbo": 2}
Column IDs: [0, 1, 0, 2, 1, ...]
```

#### 2. **NumericColumn<T>** (llmlog_engine.h/cpp)

Simple contiguous array for numeric data.

```cpp
template <typename T>
class NumericColumn {
  private:
    std::vector<T> data;
};
```

**Purpose:**
- Contiguous memory layout for SIMD
- Cache-friendly sequential access
- Used for: `latency_ms`, `tokens_input`, `tokens_output`

#### 3. **Predicate** (llmlog_engine.h)

Represents a single filter condition.

```cpp
struct Predicate {
    enum class Op { EQ, NE, LT, LE, GT, GE };
    std::string column;
    Op op;
    std::string string_value;
    int32_t int32_value;
    bool is_numeric;
};
```

**Examples:**
- `{column: "model", op: EQ, string_value: "gpt-4.1", is_numeric: false}`
- `{column: "latency_ms", op: GE, int32_value: 1000, is_numeric: true}`

#### 4. **LogStore** (llmlog_engine.h/cpp)

Main table class that orchestrates all columns and query execution.

**Key Methods:**

```cpp
class LogStore {
  public:
    void ingest_from_jsonl(const std::string& path);
    std::vector<bool> apply_filter(const std::vector<Predicate>& predicates) const;
    std::unordered_map<std::string, std::unordered_map<std::string, double>>
    aggregate(const std::vector<bool>& mask,
              const std::vector<std::string>& group_keys,
              const std::vector<std::pair<std::string, std::string>>& metrics) const;
};
```

**Responsibilities:**
1. **Ingestion**: Parse JSONL, populate all columns, handle dictionary encoding
2. **Filtering**: Apply AND-combined predicates, return boolean mask
3. **Aggregation**: Group masked rows, compute metrics (COUNT, SUM, AVG, MIN, MAX)

### Python Bindings

#### pybind11 Module (_core.cpp)

Exposes C++ classes to Python:
- `LogStore` class
- `Predicate` struct
- `Op` enum

```python
from _llmlog_engine import LogStore, Predicate, Op
```

### Python API Layer

#### LogStore (Python wrapper)

Provides a clean interface for Python users.

```python
class LogStore:
    @classmethod
    def from_jsonl(cls, path: str) -> "LogStore"
    def row_count(self) -> int
    def basic_stats(self) -> dict
    def query(self) -> "Query"
```

#### Query

Builder pattern for constructing queries.

```python
class Query:
    def filter(self, model=None, route=None, min_latency_ms=None, ...) -> "Query"
    def aggregate(self, by=None, metrics=None) -> pd.DataFrame
```

## Data Flow

### Ingestion Flow

```
JSONL File
    ↓
[Parse each line using nlohmann::json]
    ↓
[For each field:]
  - Dictionary columns: get_or_create_id(value)
  - Numeric columns: append(int_value)
    ↓
[Populate columns in LogStore]
    ↓
In-memory columnar representation
```

### Query Flow

```
Python: store.query().filter(...).aggregate(...)
    ↓
[Build Predicate list]
    ↓
C++: LogStore::apply_filter(predicates)
    ├─ For each predicate:
    │   └─ Evaluate row-by-row, update boolean mask
    └─ Return: std::vector<bool> mask
    ↓
C++: LogStore::aggregate(mask, group_keys, metrics)
    ├─ Build groups from masked rows
    ├─ Compute metrics per group
    └─ Return: map<string, map<string, double>>
    ↓
Python: Convert to pandas DataFrame
    ↓
User gets results
```

## Memory Layout

### Before Ingestion (JSONL)

```json
{"ts": "2024-01-01T...", "model": "gpt-4.1", "latency_ms": 423, ...}
{"ts": "2024-01-01T...", "model": "gpt-4.1-mini", "latency_ms": 512, ...}
```

### After Ingestion (Columnar)

```
Column: model
  IDs:    [0, 1, 0, ...]
  Dict:   {0: "gpt-4.1", 1: "gpt-4.1-mini", ...}

Column: latency_ms
  Data:   [423, 512, 891, ...]

Column: tokens_output
  Data:   [921, 512, 768, ...]

...more columns...
```

**Memory Layout (Pseudo C++):**
```cpp
struct LogStore {
    DictionaryColumn model_col;              // 2 vectors
    DictionaryColumn route_col;              // 2 vectors
    NumericColumn<int32_t> latency_ms_col;   // 1 vector
    NumericColumn<int32_t> tokens_input_col; // 1 vector
    // ... more columns
};
```

## SIMD Considerations

### Current Implementation (v0)

- No explicit SIMD intrinsics, but structure is SIMD-friendly:
  1. **Contiguous numeric arrays** → natural for AVX-2/AVX-512 vectorization
  2. **Dictionary encoding** → int32 comparisons (can be vectorized)
  3. **Simple loop structure** → easy to optimize with compiler auto-vectorization

### Example Loop (SIMD-ready)

```cpp
// Current (scalar):
for (size_t i = 0; i < row_count_; ++i) {
    int32_t val = data[i];
    bool matches = (val >= threshold);
    mask[i] = mask[i] && matches;
}

// Future (SIMD, e.g., AVX-2):
// Load 8 values at a time, compare in parallel, store 8 mask bits
// ~8x speedup on recent CPUs
```

### Future Optimizations

1. **Hand-coded SIMD** (AVX-2, AVX-512)
   - Vectorize filter loops
   - Parallel min/max/sum reductions

2. **Simdjson** for JSON parsing
   - 2-3x faster JSON ingestion
   - Already SIMD-optimized

3. **Compression** for numeric columns
   - Dictionary encoding for repeated values
   - Delta encoding for timestamps
   - Bit-packing for low-precision integers

## Query Execution Strategy

### Filter Processing (AND logic)

```cpp
std::vector<bool> apply_filter(const std::vector<Predicate>& predicates) {
    std::vector<bool> mask(row_count_, true);  // Start with all true

    for (const auto& pred : predicates) {
        // Evaluate predicate for each row
        for (size_t i = 0; i < row_count_; ++i) {
            bool matches = evaluate(pred, i);
            mask[i] = mask[i] && matches;  // AND with previous
        }
    }
    return mask;
}
```

**Complexity:** O(predicates × row_count)
**Actual complexity is lower due to early mask[i]=false optimization**

### Aggregation Processing

```cpp
aggregate(mask, group_keys, metrics) {
    // 1. Build groups
    std::unordered_map<std::string, std::vector<size_t>> groups;
    for (size_t i = 0; i < row_count_; ++i) {
        if (!mask[i]) continue;  // Skip non-matching rows
        std::string key = build_group_key(i, group_keys);
        groups[key].push_back(i);
    }

    // 2. Compute metrics for each group
    for (const auto& [key, indices] : groups) {
        // SUM, COUNT, AVG, MIN, MAX
        for (size_t idx : indices) {
            // Accumulate metrics
        }
    }
}
```

**Complexity:** O(matched_rows × #metrics)

## Build System

### CMake Configuration

```cmake
cmake_minimum_required(VERSION 3.15)
project(llmlog_engine CXX)

set(CMAKE_CXX_STANDARD 17)
find_package(pybind11 CONFIG REQUIRED)

pybind11_add_module(_llmlog_engine
    src_cpp/_core.cpp
    src_cpp/llmlog_engine.cpp)
```

### Python Package Layout

```
llmlog_engine/
├── pyproject.toml          # Build config (scikit-build-core)
├── CMakeLists.txt          # Build instructions
├── src/
│   └── llmlog_engine/
│       ├── __init__.py     # Python API (LogStore, Query)
│       └── _core.pyi       # Type stubs for C++ module
├── src_cpp/
│   ├── llmlog_engine.h     # Headers
│   ├── llmlog_engine.cpp   # Implementation
│   └── _core.cpp           # pybind11 bindings
└── tests/
    ├── test_basic.py       # Unit tests
    ├── test_bench.py       # Performance benchmarks
    └── fixtures/
        └── sample_logs.jsonl
```

## API Design Decisions

### 1. Builder Pattern for Queries

```python
# Good: Readable, chainable
query = store.query().filter(model="gpt-4.1").aggregate(...)

# Alternative: Function chaining
# We chose builder pattern for Pythonic feel
```

### 2. Keyword Arguments for Filters

```python
# Good: Type-safe, IDE autocomplete
q.filter(model="gpt-4.1", min_latency_ms=1000)

# Alternative: String expressions
# q.filter("model == 'gpt-4.1' AND latency_ms >= 1000")
# Chosen: kwargs for v0 simplicity
```

### 3. Metric Expression Strings

```python
# Current: String expressions for metrics
metrics = {"avg_lat": "avg(latency_ms)", "count": "count"}

# Why strings instead of custom objects?
# - Simple, clear, easy to extend
# - No custom DSL overhead
# - Directly mappable to C++ parser
```

### 4. Pandas DataFrame Output

```python
# All aggregations return pd.DataFrame
# Rationale:
# - Familiar to data analysts
# - Easy downstream analysis
# - Free formatting/visualization via pandas
```

## Limitations & Future Work

### Current Limitations

1. **In-memory only** — No disk persistence
2. **No timestamp parsing** — Timestamps treated as strings
3. **No distributed queries** — Single-threaded
4. **No array types** — `tags` column not supported yet
5. **No SQL parser** — Must use keyword arguments or metric strings

### Future Enhancements

1. **Persistent columnar format**
   - Memory-mapped files
   - Per-column binary storage
   - Efficient append-only updates

2. **Expression parser**
   - Mini SQL-like language
   - e.g., `store.query_sql("SELECT model, COUNT(*) FROM logs WHERE latency_ms > 1000 GROUP BY model")`

3. **Parallel execution**
   - Thread pool for scan
   - Parallel aggregation with final merge

4. **Advanced types**
   - Timestamp parsing and range filters
   - Array/struct columns
   - Decimal/float support (currently int32 only)

5. **Compression**
   - Dictionary compression for repeated integers
   - Delta encoding for timestamps
   - Zstd/LZ4 for overall storage

6. **Incremental ingestion**
   - Append-only updates
   - Batch ingestion without reloading

## Testing Strategy

### Unit Tests (test_basic.py)

```python
test_load_jsonl()           # Ingestion
test_filter_by_model()      # Single filter
test_multiple_filters()     # AND logic
test_group_by_model()       # Grouping
test_aggregation_sum()      # SUM metric
test_aggregation_avg()      # AVG metric
test_aggregation_min_max()  # MIN/MAX metrics
```

Coverage:
- All filter operations (numeric: LT/LE/GT/GE/EQ/NE, dictionary: EQ/NE)
- All aggregation functions
- Multi-column grouping
- Combined filter + aggregation

### Benchmark Tests (test_bench.py)

Compares C++ engine to pure Python:

```python
benchmark_pure_python()     # JSON + list of dicts + for loops
benchmark_cpp_engine()      # LogStore + Query
```

Metric: **Speedup ratio** (Python time / C++ time)

Expected: **5-10x faster** on typical queries

## Performance Characteristics

### Ingestion

- **Time complexity:** O(rows) — single pass through JSONL
- **Space complexity:** O(rows + unique_strings)
- **Bottleneck:** JSON parsing (can improve with simdjson)
- **Expected rate:** 10k-50k rows/sec depending on CPU

### Filtering

- **Time complexity:** O(predicates × rows)
- **Space complexity:** O(rows) for boolean mask
- **Optimizations:**
  - Early termination if mask becomes all-false
  - Dictionary comparison on int32 (much faster than string comparison)
- **Expected speedup:** 2-3x vs. Python list comprehension

### Aggregation

- **Time complexity:** O(matched_rows × #metrics)
- **Space complexity:** O(#groups × #metrics)
- **Cache optimization:** Groups iterated sequentially; numeric column data accessed linearly

## Integration Notes

### From Python

```python
from llmlog_engine import LogStore

store = LogStore.from_jsonl("logs.jsonl")
result = store.query().filter(...).aggregate(...)

# Result is pd.DataFrame, ready for:
# - Further pandas operations
# - Visualization (matplotlib, plotly)
# - Export (CSV, Parquet)
```

### With Other Tools

```python
import pandas as pd
from llmlog_engine import LogStore

store = LogStore.from_jsonl("logs.jsonl")
df = store.query().filter(...).aggregate(...)

# Use with common tools:
df.to_csv("results.csv")
df.to_parquet("results.parquet")
df.plot()  # matplotlib
```

## Code Quality

### C++ Standards

- **C++17** (modern, reasonable compatibility)
- **No external dependencies** except nlohmann::json (header-only)
- **Clear error messages** (throw exceptions)
- **Comments** only where logic is non-obvious

### Python Standards

- **Type hints** for all functions
- **Docstrings** for all public classes/methods
- **No magic** — explicit is better than implicit
- **Tested** — pytest for unit + integration tests

## Deployment

### Installation (from source)

```bash
pip install -e .
```

Requires:
- Python 3.8+
- C++17 compiler (g++, clang, MSVC)
- cmake 3.15+

### Binary Distribution

Future: Pre-built wheels for common platforms (Linux, macOS, Windows)

## References

- **nlohmann::json** — JSON parsing
- **pybind11** — Python C++ bindings
- **pandas** — DataFrame operations
- **scikit-build-core** — Build system

## Summary

LLMLog Engine provides a **fast, specialized columnar database for LLM logs**. It combines:

1. **C++ columnar core** with dictionary encoding for efficiency
2. **Clean Python API** for ease of use
3. **SIMD-friendly structure** for future optimization
4. **Production-grade testing** with benchmarks

The design prioritizes:
- **Correctness** over premature optimization
- **Clarity** over cleverness
- **Extensibility** for future enhancements
