#!/usr/bin/env python3
"""Example usage of llmlog_engine."""

import sys
import os

# Add src to path for development
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "src"))

from llmlog_engine import LogStore


def main():
    """Run example queries."""
    fixture_path = os.path.join(
        os.path.dirname(__file__),
        "tests", "fixtures", "sample_logs.jsonl"
    )

    print("=" * 70)
    print("LLMLog Engine - Example Usage")
    print("=" * 70)

    # Load logs
    print(f"\n[1] Loading logs from: {fixture_path}")
    store = LogStore.from_jsonl(fixture_path)
    print(f"    ✓ Loaded {store.row_count()} rows")

    # Show basic stats
    print("\n[2] Basic Statistics")
    stats = store.basic_stats()
    print(f"    Total rows: {int(stats['row_count'])}")
    print(f"    Unique models: {int(stats['model_cardinality'])}")
    print(f"    Unique routes: {int(stats['route_cardinality'])}")
    print(f"    Min latency: {int(stats['latency_ms_min'])}ms")
    print(f"    Max latency: {int(stats['latency_ms_max'])}ms")
    print(f"    Avg latency: {stats['latency_ms_avg']:.1f}ms")

    # Example 1: Group by model
    print("\n[3] Group by Model")
    print("    Query: Count requests per model")
    result = store.query().aggregate(
        by=["model"],
        metrics={"count": "count", "avg_latency": "avg(latency_ms)"}
    )
    print("\n" + str(result.to_string(index=False)))

    # Example 2: Group by route
    print("\n[4] Group by Route")
    print("    Query: Count requests per route")
    result = store.query().aggregate(
        by=["route"],
        metrics={"count": "count", "avg_latency": "avg(latency_ms)"}
    )
    print("\n" + str(result.to_string(index=False)))

    # Example 3: Filter and group
    print("\n[5] Filter: Model='gpt-4.1' AND Latency >= 500ms")
    print("    Query: Group by route, show counts and latency stats")
    result = (store.query()
        .filter(model="gpt-4.1", min_latency_ms=500)
        .aggregate(
            by=["route"],
            metrics={
                "count": "count",
                "avg_latency": "avg(latency_ms)",
                "min_latency": "min(latency_ms)",
                "max_latency": "max(latency_ms)"
            }
        ))
    print("\n" + str(result.to_string(index=False)))

    # Example 4: Complex filter
    print("\n[6] Filter: Route='chat' AND Latency in [200, 1000]ms")
    print("    Query: Group by model, show count and token metrics")
    result = (store.query()
        .filter(route="chat", min_latency_ms=200, max_latency_ms=1000)
        .aggregate(
            by=["model"],
            metrics={
                "count": "count",
                "sum_output": "sum(tokens_output)",
                "avg_output": "avg(tokens_output)"
            }
        ))
    print("\n" + str(result.to_string(index=False)))

    # Example 5: Multi-dimension grouping
    print("\n[7] Group by Model and Route")
    print("    Query: All combinations of model + route")
    result = (store.query()
        .aggregate(
            by=["model", "route"],
            metrics={
                "count": "count",
                "avg_latency": "avg(latency_ms)"
            }
        ))
    print("\n" + str(result.to_string(index=False)))

    # Example 6: Filter by status
    print("\n[8] Filter: Status='ok'")
    print("    Query: Count successful requests")
    result = store.query().filter(status="ok").aggregate(
        metrics={"count": "count"}
    )
    print(f"    Successful requests: {int(result.iloc[0]['count'])}")

    # Example 7: Error analysis
    print("\n[9] Filter: Status='error'")
    print("    Query: Group errors by model and route")
    result = (store.query()
        .filter(status="error")
        .aggregate(
            by=["model", "route"],
            metrics={"count": "count"}
        ))
    if len(result) > 0:
        print("\n" + str(result.to_string(index=False)))
    else:
        print("    (No errors in sample data)")

    # Example 8: Token analysis
    print("\n[10] Token Usage Analysis")
    print("     Query: Total and average tokens by model")
    result = (store.query()
        .aggregate(
            by=["model"],
            metrics={
                "count": "count",
                "total_input": "sum(tokens_input)",
                "total_output": "sum(tokens_output)",
                "avg_input": "avg(tokens_input)",
                "avg_output": "avg(tokens_output)"
            }
        ))
    print("\n" + str(result.to_string(index=False)))

    print("\n" + "=" * 70)
    print("Examples completed!")
    print("=" * 70)


if __name__ == "__main__":
    main()
