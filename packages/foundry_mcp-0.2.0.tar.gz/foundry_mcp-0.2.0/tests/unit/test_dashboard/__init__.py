"""Unit tests for dashboard module."""
