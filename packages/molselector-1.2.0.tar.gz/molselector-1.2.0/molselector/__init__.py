"""Molecule selection web application package."""

from .app import app

__all__ = ["app"]
