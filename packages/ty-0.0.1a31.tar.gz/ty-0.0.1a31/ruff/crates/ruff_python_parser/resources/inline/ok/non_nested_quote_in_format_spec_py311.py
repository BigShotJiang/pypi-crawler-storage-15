# parse_options: {"target-version": "3.11"}
f"{1:''}"  # but this is okay on all versions
