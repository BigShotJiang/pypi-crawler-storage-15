# parse_options: {"target-version": "3.11"}
type x = int
