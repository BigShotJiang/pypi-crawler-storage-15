# parse_options: {"target-version": "3.7"}
f((a)=1)
