a = pass = c
a + b
a = b = pass = c
a + b
