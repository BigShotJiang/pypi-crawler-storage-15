# parse_options: {"target-version": "3.14"}
t"{"
t"{foo!r"
t"{foo="
t"{"
t"""{"""
