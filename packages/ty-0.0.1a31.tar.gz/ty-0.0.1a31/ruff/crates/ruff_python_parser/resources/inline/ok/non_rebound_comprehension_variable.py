[a := 0 for x in range(0)]
