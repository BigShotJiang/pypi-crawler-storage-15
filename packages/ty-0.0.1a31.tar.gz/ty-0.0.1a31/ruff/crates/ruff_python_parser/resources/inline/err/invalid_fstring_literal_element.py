f'hello \N{INVALID} world'
f"""hello \N{INVALID} world"""
