# parse_options: {"target-version": "3.14"}
t"{lambda x: x}"
