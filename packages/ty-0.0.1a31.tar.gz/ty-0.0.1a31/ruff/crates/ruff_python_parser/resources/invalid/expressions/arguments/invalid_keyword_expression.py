call(x = yield y)
call(x = yield from y)
call(x = *y)
call(x = (*y))
