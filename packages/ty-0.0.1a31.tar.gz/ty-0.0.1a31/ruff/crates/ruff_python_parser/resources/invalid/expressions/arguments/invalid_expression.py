call(x + y = 1)
call(x := 1 = 1)

call(yield x)
call(yield from x)
