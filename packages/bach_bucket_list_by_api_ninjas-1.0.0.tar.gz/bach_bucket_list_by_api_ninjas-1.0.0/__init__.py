"""MCP Server for Bucket List By Api Ninjas"""
