from quark.forensic.forensic import Forensic
