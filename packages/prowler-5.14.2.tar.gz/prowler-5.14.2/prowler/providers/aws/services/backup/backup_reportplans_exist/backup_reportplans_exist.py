from prowler.lib.check.models import Check, Check_Report_AWS
from prowler.providers.aws.services.backup.backup_client import backup_client


class backup_reportplans_exist(Check):
    def execute(self):
        findings = []
        # We only check report plans if backup plans exist
        if backup_client.backup_plans:
            report = Check_Report_AWS(
                metadata=self.metadata(),
                resource=backup_client.backup_plans[0],
            )
            report.resource_arn = backup_client.report_plan_arn_template
            report.resource_id = backup_client.audited_account
            report.status = "FAIL"
            report.status_extended = "No Backup Report Plan exist."

            if backup_client.backup_report_plans:
                report = Check_Report_AWS(
                    metadata=self.metadata(),
                    resource=backup_client.backup_report_plans[0],
                )
                report.status = "PASS"
                report.status_extended = f"At least one backup report plan exists: {backup_client.backup_report_plans[0].name}."
                report.resource_arn = backup_client.backup_report_plans[0].arn
                report.resource_id = backup_client.backup_report_plans[0].name
                report.region = backup_client.backup_report_plans[0].region

            findings.append(report)
        return findings
