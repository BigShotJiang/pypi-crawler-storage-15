from .fundus import FundusImageWithMetaData
from .oct import OCTVolumeWithMetaData

__all__ = ["OCTVolumeWithMetaData", "FundusImageWithMetaData"]
