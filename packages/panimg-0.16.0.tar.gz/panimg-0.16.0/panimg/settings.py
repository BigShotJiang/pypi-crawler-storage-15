# Tile size in pixels to be used when creating dzi for tif files
DZI_TILE_SIZE = 2560
