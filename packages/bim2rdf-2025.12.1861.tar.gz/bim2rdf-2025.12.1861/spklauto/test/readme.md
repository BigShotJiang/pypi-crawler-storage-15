https://speckle.guide/automate/function-testing.html#running-test-cases

In the [`config.local.toml`](.config.local.toml) file, fill out
```toml
[speckle.automate]
project_id="***spkleprojectid***"
id="***speckleautomationid***"
```

then run `python test.py`.