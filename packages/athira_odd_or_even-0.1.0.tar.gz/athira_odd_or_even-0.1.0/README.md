# odd_or_even

A simple Python package to check whether a number is odd or even.

## Installation

You can install the package after building it:

```bash
pip install dist/odd_or_even-0.1.0-py3-none-any.whl
