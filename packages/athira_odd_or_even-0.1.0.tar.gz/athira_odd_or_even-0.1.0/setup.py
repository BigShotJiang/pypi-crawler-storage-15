from setuptools import setup, find_packages

setup(
    name="odd_or_even",
    version="0.1.0",
    packages=find_packages(),
    description="A simple Python package to check odd or even numbers",
)
