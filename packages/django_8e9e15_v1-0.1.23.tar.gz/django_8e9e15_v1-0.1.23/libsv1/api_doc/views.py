from django.contrib.auth.decorators import login_required
from django.http import FileResponse
import os
from django.shortcuts import HttpResponse
from django.conf import settings
import platform
from drf_spectacular.generators import SchemaGenerator
import sys
from drf_spectacular.extensions import OpenApiSerializerExtension
from libsv1.db_model_utils import DbModelUtils
from rest_framework import serializers


class CustomSerializerExtension(OpenApiSerializerExtension):
    target_class = serializers.Serializer
    match_subclasses = True

    def map_serializer(self, auto_schema, direction):
        return auto_schema._map_serializer(self.target, direction, bypass_extensions=True)

    def get_name(self, auto_schema, direction):
        view = auto_schema.view
        serializer = self.target
        app_name = view.__module__.split('.')[0]
        generated_name = f"{app_name}_{view.__class__.__name__}_{serializer.__class__.__name__}"
        return generated_name

def custom_postprocessing_hook(result, generator, request, public):
    if 'components' in result and 'schemas' in result['components']:
        for key, component in result['components']['schemas'].items():
            for prop_name, prop_schema in component.get('properties', {}).items():
                if prop_schema.get('format') == 'double':
                    prop_schema['example'] = 0.1
                elif prop_schema.get('format') == 'date-time':
                    prop_schema['example'] = '2025-03-21 00:00:00'
    if 'components' in result and 'securitySchemes' in result['components']:
        unwanted_schemes = ['jwtAuth', 'tokenAuth', 'basicAuth']
        for scheme in unwanted_schemes:
            if scheme in result['components']['securitySchemes']:
                del result['components']['securitySchemes'][scheme]
    return result

class BaseDynamicSchemaGenerator(SchemaGenerator):
    schema_path_prefix = None

    def parse(self, request=None, public=False):
        result = super().parse(request, public)
        filtered_paths = {}

        if self.schema_path_prefix:
            grouped_by_tag = {}
            for path, methods in result.items():
                if path.startswith(self.schema_path_prefix):
                    relative_path = path[len(self.schema_path_prefix):].lstrip('/')
                    group_name = relative_path.split('/')[0] if '/' in relative_path else relative_path

                    updated_methods = {}
                    for method, operation in methods.items():
                        operation['tags'] = [group_name]
                        updated_methods[method] = operation

                    filtered_paths[path] = updated_methods
                    if group_name not in grouped_by_tag:
                        grouped_by_tag[group_name] = {}
                    grouped_by_tag[group_name][path] = updated_methods

            single_path_groups = {
                group_name: paths for group_name, paths in grouped_by_tag.items() if len(paths) == 1
            }
            if " " not in grouped_by_tag:
                grouped_by_tag[" "] = {}
            for group_name, paths in single_path_groups.items():
                for path, methods in paths.items():
                    for method, operation in methods.items():
                        operation["tags"] = [" "]
                grouped_by_tag[" "].update(paths)
                del grouped_by_tag[group_name]

            desired_order = [' ', 'demo', 'system-list', 'auth', 'user']
            final_paths = {}

            for tag in desired_order:
                if tag in grouped_by_tag:
                    final_paths.update(grouped_by_tag[tag])

            for tag in grouped_by_tag:
                if tag not in desired_order:
                    final_paths.update(grouped_by_tag[tag])

            return final_paths

        return {}

class ApiSchemaGenerator(BaseDynamicSchemaGenerator):
    schema_path_prefix = '/api/'

class DashboardApiSchemaGenerator(BaseDynamicSchemaGenerator):
    schema_path_prefix = '/dashboard/api/'

@login_required
def erd_view(request, ext):
    from eralchemy import render_er

    if ext not in ['png', 'svg']:
        return HttpResponse("Unsupported format. Use 'png' or 'svg'.", status=400)
    content_type = 'image/svg+xml' if ext == 'svg' else 'image/png'

    setup_graphviz_path()
    db_uri = DbModelUtils.get_db_uri()
    output_dir = os.path.join(settings.MEDIA_ROOT, 'doc')
    os.makedirs(output_dir, exist_ok=True)
    output_file = os.path.join(output_dir, 'erd_diagram.'+ext)

    render_er(db_uri, output_file)
    return FileResponse(open(output_file, 'rb'), content_type=content_type)

@login_required
def graph_models_view(request, ext):
    from subprocess import run

    if ext not in ['png', 'svg']:
        return HttpResponse("Unsupported format. Use 'png' or 'svg'.", status=400)
    content_type = 'image/svg+xml' if ext == 'svg' else 'image/png'

    setup_graphviz_path()
    output_dir = os.path.join(settings.MEDIA_ROOT, 'doc')
    os.makedirs(output_dir, exist_ok=True)
    output_file = os.path.join(output_dir, 'models_diagram.'+ext)

    additional_apps = request.GET.get('apps', '').strip()
    additional_apps = [app.strip() for app in additional_apps.split(',') if app.strip()]
    apps = ["app"]
    for app in additional_apps:
        if any(app == installed_app.split('.')[-1] for installed_app in settings.INSTALLED_APPS):
            apps.append(app)

    if platform.system() == "Windows":
        result = run(
            [sys.executable, 'manage.py', "graph_models", *apps, "-o", output_file],
            check=True,
            capture_output=True,
            text=True
        )
    elif platform.system() == "Linux":
        manage_py_path = os.path.join(settings.BASE_DIR, "manage.py")

        if settings.PYTHON_PATH:
            python_interpreter = os.path.join(settings.BASE_DIR, settings.PYTHON_PATH)
            if not os.path.exists(python_interpreter):
                python_interpreter = settings.PYTHON_PATH
        elif settings.VENV_PATH:
            python_interpreter = os.path.join(settings.BASE_DIR, settings.VENV_PATH, "bin", "python")
            if not os.path.exists(python_interpreter):
                python_interpreter = os.path.join(settings.VENV_PATH, "bin", "python")
        else:
            python_interpreter = os.path.join(settings.BASE_DIR, "venv", "bin", "python")

        result = run(
            [python_interpreter, manage_py_path, "graph_models", *apps, "-o", output_file],
            check=True,
            capture_output=True,
            text=True
        )
    else:
        raise EnvironmentError(f"OS {platform.system()} not supported")

    if not os.path.exists(output_file):
        return HttpResponse("The chart file was not created. Check the error logs..", status=500)
    return FileResponse(open(output_file, 'rb'), content_type=content_type)

def setup_graphviz_path():
    import shutil

    if not shutil.which("dot"):
        print("Graphviz not found. Adding the path to PATH...")

        if platform.system() == "Windows":
            graphviz_path = r"C:\Program Files\Graphviz\bin"
        elif platform.system() == "Linux":
            graphviz_path = "/usr/bin"
        else:
            raise EnvironmentError(f"OS {platform.system()} not supported")

        os.environ['PATH'] += os.pathsep + graphviz_path
        if not shutil.which("dot"):
            raise RuntimeError("Graphviz still not found. Install it manually.")