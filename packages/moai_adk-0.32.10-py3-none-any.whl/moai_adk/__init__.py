"""MoAI Agentic Development Kit

SPEC-First TDD Framework with Alfred SuperAgent
"""

from moai_adk.version import MOAI_VERSION

__version__ = MOAI_VERSION

__all__ = ["__version__"]
