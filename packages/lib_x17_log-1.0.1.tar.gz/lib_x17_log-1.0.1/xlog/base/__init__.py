from .component import LogComponent

__all__ = ["LogComponent"]
