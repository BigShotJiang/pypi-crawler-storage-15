name = "openkosmos-core"

def hello() -> str:
    return "Hello from openkosmos-core!"
