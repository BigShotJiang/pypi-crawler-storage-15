from pathlib import Path

TEST_MANIFEST_DIRECTORY = (Path(__file__).parent.parent / "_data").resolve()
