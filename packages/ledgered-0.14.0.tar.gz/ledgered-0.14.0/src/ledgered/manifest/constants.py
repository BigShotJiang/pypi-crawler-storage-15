MANIFEST_FILE_NAME = "ledger_app.toml"
DEFAULT_USE_CASE = "default"
