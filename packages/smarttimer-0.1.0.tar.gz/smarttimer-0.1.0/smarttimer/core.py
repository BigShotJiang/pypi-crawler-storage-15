# smarttimer/core.py

import time
import sys
import functools
import statistics
from contextlib import ContextDecorator
from typing import Callable, Optional, TextIO, List, Dict, Any


class Timer(ContextDecorator):
    """
    A simple timing context manager and decorator.

    Usage:
        with Timer("loading data"):
            load_data()

        @Timer("training step")
        def train():
            ...
    """

    def __init__(
        self,
        name: str = "block",
        *,
        precision: int = 4,
        output: Optional[TextIO] = None,
        enabled: bool = True,
    ) -> None:
        self.name = name
        self.precision = precision
        self.output = output or sys.stdout
        self.enabled = enabled
        self._start: Optional[float] = None
        self.elapsed: Optional[float] = None

    def __enter__(self):
        if not self.enabled:
            return self
        self._start = time.perf_counter()
        return self

    def __exit__(self, exc_type, exc, tb):
        if not self.enabled or self._start is None:
            return False  # don't silence exceptions

        end = time.perf_counter()
        self.elapsed = end - self._start

        msg = f"[smarttimer] {self.name} took {self.elapsed:.{self.precision}f}s"
        print(msg, file=self.output)

        # don't swallow exceptions
        return False


def time_block(
    name: str = "block",
    *,
    precision: int = 4,
    output: Optional[TextIO] = None,
    enabled: bool = True,
) -> Timer:
    """
    Convenience function for timing a code block.

    Example:
        with time_block("inference"):
            model(x)
    """
    return Timer(name=name, precision=precision, output=output, enabled=enabled)


def benchmark(
    func: Optional[Callable] = None,
    *,
    name: Optional[str] = None,
    precision: int = 4,
    output: Optional[TextIO] = None,
    enabled: bool = True,
):
    """
    Decorator to time a function.

    Example:
        @benchmark
        def train():
            ...

        @benchmark(name="step", precision=6)
        def step():
            ...
    """

    def decorator(f: Callable):
        label = name or f.__name__

        @functools.wraps(f)
        def wrapper(*args, **kwargs):
            if not enabled:
                return f(*args, **kwargs)

            start = time.perf_counter()
            try:
                return f(*args, **kwargs)
            finally:
                end = time.perf_counter()
                elapsed = end - start
                out = output or sys.stdout
                msg = f"[smarttimer] {label} took {elapsed:.{precision}f}s"
                print(msg, file=out)

        return wrapper

    if func is None:
        return decorator
    return decorator(func)


def measure(
    func: Callable,
    *args,
    repeats: int = 1,
    precision: int = 6,
    output: Optional[TextIO] = None,
    warmup: int = 0,
    **kwargs,
):
    """
    Measure how long a function takes to run, optionally multiple times.

    Returns (last_result, elapsed_seconds).

    Example:
        result, t = measure(train_step, batch, repeats=10, warmup=2)
    """
    out = output or sys.stdout
    
    # Warmup runs (not timed)
    for _ in range(warmup):
        func(*args, **kwargs)
    
    last_result = None
    start = time.perf_counter()

    for _ in range(repeats):
        last_result = func(*args, **kwargs)

    end = time.perf_counter()
    total = end - start
    avg = total / repeats if repeats else float("nan")

    msg = (
        f"[smarttimer] {func.__name__} ran {repeats}x in "
        f"{total:.{precision}f}s (avg {avg:.{precision}f}s)"
    )
    print(msg, file=out)

    return last_result, total


def compare(*funcs, args=(), kwargs=None, repeats: int = 5, warmup: int = 1):
    """
    Compare execution times of multiple functions.
    
    Example:
        compare(sorted, list.sort, args=([3,1,4,1,5,9],), repeats=10)
    """
    kwargs = kwargs or {}
    results = {}
    
    for func in funcs:
        times = []
        for _ in range(warmup):
            if args:
                func(*args, **kwargs)
            else:
                func(**kwargs)
        
        for _ in range(repeats):
            start = time.perf_counter()
            if args:
                func(*args, **kwargs)
            else:
                func(**kwargs)
            end = time.perf_counter()
            times.append(end - start)
        
        results[func.__name__] = {
            'mean': statistics.mean(times),
            'min': min(times),
            'max': max(times),
            'stdev': statistics.stdev(times) if len(times) > 1 else 0
        }
    
    # Print comparison
    print(f"\n[smarttimer] Function comparison ({repeats} runs):")
    sorted_funcs = sorted(results.items(), key=lambda x: x[1]['mean'])
    
    for i, (name, stats) in enumerate(sorted_funcs):
        if i == 0:
            print(f"  {name}: {stats['mean']:.6f}s ± {stats['stdev']:.6f}s (fastest)")
        else:
            ratio = stats['mean'] / sorted_funcs[0][1]['mean']
            print(f"  {name}: {stats['mean']:.6f}s ± {stats['stdev']:.6f}s ({ratio:.1f}x slower)")
    
    return results


class TimingContext:
    """
    Context manager that captures timing data without printing.
    
    Example:
        with TimingContext() as timer:
            expensive_operation()
        print(f"Took {timer.elapsed:.4f}s")
    """
    
    def __init__(self):
        self.elapsed: Optional[float] = None
        self._start: Optional[float] = None
    
    def __enter__(self):
        self._start = time.perf_counter()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        if self._start is not None:
            self.elapsed = time.perf_counter() - self._start
        return False


def profile_memory(func: Optional[Callable] = None, *, name: Optional[str] = None):
    """
    Decorator to profile memory usage (requires psutil).
    
    Example:
        @profile_memory
        def load_data():
            return [i for i in range(1000000)]
    """
    try:
        import psutil
        import os
    except ImportError:
        def dummy_decorator(f):
            print("[smarttimer] psutil not installed, memory profiling disabled")
            return f
        return dummy_decorator if func is None else dummy_decorator(func)
    
    def decorator(f: Callable):
        label = name or f.__name__
        
        @functools.wraps(f)
        def wrapper(*args, **kwargs):
            process = psutil.Process(os.getpid())
            mem_before = process.memory_info().rss / 1024 / 1024  # MB
            
            start = time.perf_counter()
            try:
                result = f(*args, **kwargs)
            finally:
                end = time.perf_counter()
                mem_after = process.memory_info().rss / 1024 / 1024  # MB
                
                elapsed = end - start
                mem_diff = mem_after - mem_before
                
                print(f"[smarttimer] {label} took {elapsed:.4f}s, "
                      f"memory: {mem_before:.1f}MB → {mem_after:.1f}MB "
                      f"({mem_diff:+.1f}MB)")
            
            return result
        return wrapper
    
    return decorator if func is None else decorator(func)