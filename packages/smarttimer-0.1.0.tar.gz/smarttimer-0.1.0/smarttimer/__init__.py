# smarttimer/__init__.py

from .core import Timer, time_block, benchmark, measure, compare, TimingContext, profile_memory

__all__ = ["Timer", "time_block", "benchmark", "measure", "compare", "TimingContext", "profile_memory"]

__version__ = "0.1.0"