# settings-controller
CURRENT = {
	"type": "get",
	"endpoint": "/settings/current",
	"call_message": "{type} {endpoint}",
	"error_message": "{type} {endpoint} {response_code}"	
}