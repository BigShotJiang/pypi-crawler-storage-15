GET_OPEN_AI_RESULT = {
	"type": "post",
	"endpoint": "/getOpenAiResult",
	"call_message": "{type} {endpoint}",
	"error_message": "{type} {endpoint} {response_code}"	
}