INTERACTION = {
	"type": "post",
	"endpoint": "/interaction",
	"call_message": "{type} {endpoint}",
	"error_message": "{type} {endpoint} {response_code}"
}