# Worker: Microsoft
GET_ANOMALY = {
	"type": "get",
	"endpoint": "/getAnomaly",
	"call_message": "{type} {endpoint}",
	"error_message": "{type} {endpoint} {response_code}"
}