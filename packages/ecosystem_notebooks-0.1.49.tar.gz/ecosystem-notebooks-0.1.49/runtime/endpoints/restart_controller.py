RESTART = {
	"type": "post",
	"endpoint": "/restart",
	"call_message": "{type} {endpoint}",
	"error_message": "{type} {endpoint} {response_code}"
}
RESTART_APP = {
	"type": "post",
	"endpoint": "/restartApp",
	"call_message": "{type} {endpoint}",
	"error_message": "{type} {endpoint} {response_code}"
}