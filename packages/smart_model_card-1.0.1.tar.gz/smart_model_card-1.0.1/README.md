# SMART Model Card

A Python library for generating standardized, comprehensive AI/ML model documentation cards with OMOP Common Data Model integration for healthcare applications.

## Table of Contents

- [Overview](#overview)
- [Installation](#installation)
- [Quick Start](#quick-start)
- [Features](#features)
- [CLI Reference](#cli-reference)
- [Python API](#python-api)
- [OMOP Integration](#omop-integration)
- [Examples](#examples)
- [Testing](#testing)
- [Development](#development)
- [Contributing](#contributing)
- [License](#license)
- [Citation](#citation)

## Overview

SMART Model Card helps healthcare AI/ML developers create transparent, standardized model documentation following best practices. It provides:

- **Interactive CLI wizard** with input validation and guided workflows
- **OMOP CDM integration** for cohort characterization via OHDSI WebAPI
- **Multiple export formats** (HTML, JSON, Markdown)
- **Automated visualizations** for demographic and performance metrics
- **Standardized structure** ensuring consistency across model cards
- **Provenance tracking** with cryptographic hashing

### Why SMART Model Card?

Healthcare AI/ML models require rigorous documentation for:
- Regulatory compliance
- Clinical validation
- Deployment safety
- Reproducibility
- Transparency

SMART Model Card automates this process while maintaining flexibility for diverse use cases.

## Installation

### From PyPI (Recommended)

```bash
pip install smart-model-card
```

### From Source

```bash
git clone https://github.com/yourusername/smart-model-card.git
cd smart-model-card
pip install -e .
```

### Optional Dependencies

For visualization support:
```bash
pip install smart-model-card[viz]
```

For development tools:
```bash
pip install smart-model-card[dev]
```

For everything:
```bash
pip install smart-model-card[all]
```

### Requirements

- Python >= 3.8
- requests >= 2.25.0
- matplotlib >= 3.3.0 (optional, for visualizations)

## Quick Start

### 1. Interactive Wizard (Easiest)

Create a model card interactively with built-in validation:

```bash
smart-model-card interactive
```

**Features:**
- Step-by-step prompts through all 7 sections
- Automatic validation (dates: YYYY-MM-DD, emails, numeric ranges)
- OMOP data integration option
- Clear output locations and viewing commands
- Smart defaults for common fields

**Example Session:**
```
SECTION 1: Model Details
  Model Name: COPD-Risk-Predictor
  Version [1.0.0]: 1.0.0
  Release Date (YYYY-MM-DD): 2025-01-15
  Support Contact (email): researcher@hospital.org

✓ Model Card Creation Complete!

Your model card has been saved to:
  • HTML: /path/to/output/model_card.html
  • JSON: /path/to/output/model_card.json

To view your model card:
  open /path/to/output/model_card.html
```

### 2. Programmatic Creation

#### Basic Example

```python
from smart_model_card import ModelCard, ModelDetails, IntendedUse
from smart_model_card.sections import (
    DataFactors, FeaturesOutputs, PerformanceValidation,
    Methodology, AdditionalInfo
)
from smart_model_card.exporters import HTMLExporter

# Create model card
card = ModelCard()

# Section 1: Model Details
card.set_model_details(ModelDetails(
    model_name="Diabetes-Risk-Model",
    version="2.1.0",
    developer_organization="University Hospital Research Lab",
    release_date="2025-01-15",
    description="Predicts 5-year diabetes risk using EHR data",
    intended_purpose="decision_support",
    algorithms_used="XGBoost Classifier",
    licensing="MIT",
    support_contact="ai-team@hospital.org"
))

# Section 2: Intended Use
card.set_intended_use(IntendedUse(
    primary_intended_users="Primary care physicians",
    clinical_indications="Patients aged 40-75 with pre-diabetes indicators",
    patient_target_group="Adults with BMI > 25 and family history of diabetes",
    intended_use_environment="hospital_outpatient"
))

# Export to HTML
HTMLExporter.export(card, "output/diabetes_model_card.html")
```

#### With Data & Performance

```python
from smart_model_card.sections import (
    SourceDataset, InputFeature, OutputFeature,
    ValidationDataset, PerformanceMetric
)

# Section 3: Data Factors
card.set_data_factors(DataFactors(
    source_datasets=[
        SourceDataset(
            name="Hospital EHR Database",
            origin="Academic Medical Center",
            size=15000,
            collection_period="2018-2023",
            population_characteristics="Adult patients, 45% female, mean age 62"
        )
    ],
    data_distribution_summary="Balanced dataset with 30% positive cases",
    data_representativeness="Representative of urban academic hospital population",
    data_governance="IRB-approved, HIPAA-compliant data access"
))

# Section 4: Features & Outputs
card.set_features_outputs(FeaturesOutputs(
    input_features=[
        InputFeature("Age", "numeric", True, "Demographics"),
        InputFeature("BMI", "numeric", True, "Vitals"),
        InputFeature("HbA1c", "numeric", True, "Labs"),
        InputFeature("Family History", "binary", True, "History")
    ],
    output_features=[
        OutputFeature("Diabetes Risk Score", "probability")
    ],
    feature_type_distribution="70% numeric, 30% categorical",
    uncertainty_quantification="Confidence intervals provided via bootstrapping",
    output_interpretability="SHAP values computed for all predictions"
))

# Section 5: Performance
card.set_performance_validation(PerformanceValidation(
    validation_datasets=[
        ValidationDataset(
            name="Internal Test Set",
            source_institution="Same hospital, held-out data",
            population_characteristics="Similar to training",
            validation_type="internal"
        )
    ],
    claimed_metrics=[
        PerformanceMetric("AUC-ROC", 0.87, "Claimed"),
        PerformanceMetric("Sensitivity", 0.82, "Claimed"),
        PerformanceMetric("Specificity", 0.79, "Claimed")
    ],
    validated_metrics=[
        PerformanceMetric("AUC-ROC", 0.85, "Validated"),
        PerformanceMetric("Sensitivity", 0.80, "Validated")
    ],
    calibration_analysis="Calibration plot shows good agreement",
    fairness_assessment="Performance consistent across age groups"
))

# Section 6: Methodology
card.set_methodology(Methodology(
    model_development_workflow="Standard supervised learning pipeline",
    training_procedure="5-fold cross-validation with hyperparameter tuning",
    data_preprocessing="Missing value imputation, normalization, outlier removal"
))

# Section 7: Additional Information
card.set_additional_info(AdditionalInfo(
    benefit_risk_summary="Improves early detection with minimal false positives",
    ethical_considerations="Monitored for demographic bias",
    caveats_limitations="Not validated in pediatric populations",
    recommendations_for_safe_use="Use as screening tool, not diagnostic"
))

# Export
HTMLExporter.export(card, "output/complete_model_card.html")
```

## Features

### Interactive Wizard

The CLI wizard provides a user-friendly interface for model card creation:

| Feature | Description |
|---------|-------------|
| **Date Validation** | Enforces YYYY-MM-DD format (e.g., 2025-01-15) |
| **Email Validation** | Validates email format (user@example.com) |
| **Numeric Ranges** | Validates metrics (0.0-1.0), dataset sizes (> 0) |
| **Retry Limits** | Prevents infinite loops (max 5 attempts) |
| **Smart Defaults** | Common values pre-filled (version: 1.0.0, license: MIT) |
| **OMOP Integration** | Optional cohort data fetching from OHDSI WebAPI |
| **Clear Feedback** | Shows file paths and viewing commands after creation |

### OMOP CDM Support

Integrate observational health data using OMOP Common Data Model:

- **Cohort Extraction**: Fetch cohort definitions from OHDSI ATLAS
- **Heracles Reports**: Parse demographic characterizations automatically
- **Athena Integration**: Enrich concept IDs with names and descriptions
- **Auto Tables**: Generate demographic tables from OMOP data
- **Visualizations**: Create age/gender/race distribution charts

### Export Formats

**HTML (Recommended for viewing):**
- Interactive collapsible sections
- Searchable content
- Paginated tables
- Embedded visualizations
- Multi-dataset dropdown switching
- Print-friendly styling

**JSON (Recommended for storage/APIs):**
- Structured schema
- Machine-readable
- Version control friendly
- Easy programmatic access

**Markdown:**
- Plain text format
- Git-friendly diffs
- Easy editing

### Standardization

All model cards maintain consistent structure:

- **7 Required Sections**: Model Details, Intended Use, Data Factors, Features & Outputs, Performance & Validation, Methodology, Additional Info
- **Intelligent N/A Handling**: Missing data clearly marked with styled messages
- **Detailed Reports**: Always present (with data or N/A placeholders)
- **Visual Analytics**: Consistent chart styling and formats

## CLI Reference

### Interactive Mode

```bash
smart-model-card interactive
```

Launch the interactive wizard for step-by-step model card creation.

### Validate

```bash
smart-model-card validate model_card.json
```

Validate an existing model card against the schema.

### Export

```bash
# Export to HTML
smart-model-card export model_card.json --format html -o output.html

# Export to JSON
smart-model-card export model_card.json --format json -o output.json

# Export to Markdown
smart-model-card export model_card.json --format markdown -o output.md
```

### Create Scaffold

```bash
smart-model-card create --model-name "MyModel" -o scaffold.json
```

Generate a template model card with placeholder values.

### Provenance

```bash
# Compute hash for provenance tracking
smart-model-card hash --card model_card.json

# Compare two versions
smart-model-card diff old_card.json new_card.json
```

### Fairness Check

```bash
smart-model-card fairness-check model_card.json
```

Analyze fairness metrics and demographic performance.

## Python API

### Core Classes

#### ModelCard

Main container for all model card sections.

```python
from smart_model_card import ModelCard

card = ModelCard()
card.set_model_details(details)
card.set_intended_use(use)
card.set_data_factors(data)
card.set_features_outputs(features)
card.set_performance_validation(perf)
card.set_methodology(method)
card.set_additional_info(info)

# Serialize
card_dict = card.to_dict()
```

#### ModelDetails

Section 1: Basic model information.

```python
from smart_model_card import ModelDetails

details = ModelDetails(
    model_name="MyModel",              # Required
    version="1.0.0",                   # Required
    developer_organization="Org Name", # Required
    release_date="2025-01-15",        # Optional (YYYY-MM-DD)
    description="Model description",   # Required
    intended_purpose="decision_support", # Required
    algorithms_used="Algorithm name",  # Required
    licensing="MIT",                   # Optional
    support_contact="email@org.com"   # Required (validated)
)
```

**Purpose Options:**
- `decision_support`
- `screening`
- `diagnosis`
- `prognosis`
- `other`

#### IntendedUse

Section 2: Clinical context and use cases.

```python
from smart_model_card import IntendedUse

use = IntendedUse(
    primary_intended_users="Clinicians",          # Required
    clinical_indications="Use cases",             # Required
    patient_target_group="Patient population",    # Required
    intended_use_environment="hospital_outpatient", # Required
    contraindications="When not to use",          # Optional
    out_of_scope_applications="Out of scope",     # Optional
    warnings="Important warnings"                 # Optional
)
```

**Environment Options:**
- `hospital_inpatient`
- `hospital_outpatient`
- `clinic`
- `home`
- `mobile`
- `other`

### Exporters

#### HTMLExporter

```python
from smart_model_card.exporters import HTMLExporter

HTMLExporter.export(card, "output/card.html")
```

#### JSONExporter

```python
from smart_model_card.exporters import JSONExporter

JSONExporter.export(card, "output/card.json")
```

#### MarkdownExporter

```python
from smart_model_card.exporters import MarkdownExporter

MarkdownExporter.export(card, "output/card.md")
```

## OMOP Integration

### Using the Interactive Wizard

When you reach Section 3 (Data & Factors), the wizard prompts:

```
Would you like to add OMOP data? [y/N]: y

OMOP Data Source:
  1. Fetch existing cohort from OHDSI WebAPI
  2. Use locally saved cohort data

Select option: 1

OHDSI WebAPI URL: https://atlas.yourorg.org/WebAPI
CDM Source Key: YOUR_CDM_SOURCE
Cohort ID: 168

Include Heracles characterization reports? [Y/n]: y

✓ Successfully fetched cohort: COPD Patients 2023
```

### Programmatic Integration

```python
from smart_model_card.integrations import OMOPIntegration

# Connect to OHDSI WebAPI
omop = OMOPIntegration(
    webapi_url="https://atlas.yourorg.org/WebAPI",
    source_key="YOUR_CDM_SOURCE"
)

# Fetch cohort with reports
cohort_data = omop.get_cohort_with_reports(
    cohort_id=168,
    include_heracles=True
)

# The cohort_data includes:
# - Cohort definition
# - Demographics (age, gender, race)
# - Condition distributions
# - Drug exposures
# - Procedure counts

# Add to model card
card.data_factors.omop_detailed_reports = cohort_data['heracles_reports']
```

### Available OMOP Reports

When Heracles characterization is included:

- **Person**: Age distribution, gender distribution, race/ethnicity
- **Conditions**: Most common diagnoses
- **Drugs**: Medication exposures
- **Procedures**: Common procedures
- **Observations**: Lab values and vitals
- **Visits**: Healthcare utilization patterns

## Examples

### Example 1: Basic Model Card

```bash
cd examples
python quickstart.py
```

Creates a minimal model card with required fields only.

### Example 2: OMOP Integration

```bash
python demo_smart_omop_dynamic.py
```

Demonstrates fetching OMOP cohort data and generating demographic visualizations.

### Example 3: Multi-Dataset Card

```bash
python demo_multi_dataset.py
```

Shows how to document models trained on multiple datasets with different characteristics.

### Example 4: Complete Workflow

```python
from smart_model_card import ModelCard
from smart_model_card.integrations import OMOPIntegration
from smart_model_card.exporters import HTMLExporter, JSONExporter

# 1. Create card
card = ModelCard()

# 2. Populate all sections (see Quick Start)
card.set_model_details(...)
card.set_intended_use(...)

# 3. Add OMOP data
omop = OMOPIntegration(webapi_url="...", source_key="...")
cohort = omop.get_cohort_with_reports(cohort_id=168)
card.data_factors.omop_detailed_reports = cohort['heracles_reports']

# 4. Export multiple formats
HTMLExporter.export(card, "output/model_card.html")
JSONExporter.export(card, "output/model_card.json")

print("Model card created successfully!")
```

## Testing

### Run All Tests

```bash
pytest tests/ -v
```

### Test Coverage

```bash
pytest tests/ --cov=smart_model_card --cov-report=html
```

### What's Tested

- **Model Card Validation** (8 tests): Schema compliance, required fields
- **Provenance Tracking** (3 tests): Hash computation, version comparison
- **CAC Integration** (1 test): Code suggestion functionality
- **Standardization** (4 tests): Section structure, N/A handling, consistency

**Total: 16 tests**

### Run Specific Tests

```bash
# Only standardization tests
pytest tests/test_standardization.py -v

# Only model card tests
pytest tests/test_model_card.py -v
```

## Development

### Setup Development Environment

```bash
# Clone repository
git clone https://github.com/yourusername/smart-model-card.git
cd smart-model-card

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install in development mode
pip install -e .[dev]

# Run tests
pytest tests/
```

### Code Style

This project follows PEP 8 guidelines:

```bash
# Format code
black src/ tests/

# Check style
flake8 src/ tests/
```

### Building Package

```bash
# Install build tools
pip install build twine

# Build distribution
python -m build

# Check distribution
twine check dist/*

# Upload to PyPI
twine upload dist/*
```

## Contributing

Contributions are welcome! Please:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Make your changes
4. Add tests for new functionality
5. Ensure all tests pass (`pytest tests/`)
6. Commit your changes (`git commit -m 'Add amazing feature'`)
7. Push to the branch (`git push origin feature/amazing-feature`)
8. Open a Pull Request

See [CONTRIBUTING.md](CONTRIBUTING.md) for detailed guidelines.

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Citation

If you use SMART Model Card in your research or project, please cite:

```bibtex
@software{smart_model_card,
  title={SMART Model Card: Standardized Model Documentation for Healthcare AI},
  author={Lohachab, Ankur},
  organization={Department of Advanced Computing Sciences, Maastricht University},
  year={2025},
  url={https://github.com/yourusername/smart-model-card}
}
```

## Support

- **Issues**: [GitHub Issues](https://github.com/yourusername/smart-model-card/issues)
- **Documentation**: See `examples/` directory and this README
- **Email**: ankur.lohachab@maastrichtuniversity.nl


