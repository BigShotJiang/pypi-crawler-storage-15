"""
Integration Utilities

Helper functions for integrating with smart-omop and medsynth packages.

Author: Ankur Lohachab
Department of Advanced Computing Sciences, Maastricht University
"""

from typing import List, Optional, Dict, Any
from smart_model_card.sections import (
    ConceptSet,
    CohortCriteria,
    SourceDataset,
    DataFactors,
    PerformanceValidation,
    PerformanceMetric,
    ValidationDataset
)
from smart_model_card.data_sources import create_omop_adapter
from smart_model_card.exporters import JSONExporter
import json
import csv
import tempfile
from pathlib import Path


def create_concept_set_from_omop(
    name: str,
    concept_ids: List[int],
    vocabulary: str = "OMOP",
    description: Optional[str] = None
) -> ConceptSet:
    """
    Create ConceptSet from OMOP concept IDs.

    Args:
        name: Concept set name
        concept_ids: List of OMOP concept IDs
        vocabulary: Vocabulary system (default: OMOP)
        description: Optional description

    Returns:
        ConceptSet instance
    """
    return ConceptSet(
        name=name,
        vocabulary=vocabulary,
        concept_ids=concept_ids,
        description=description
    )


def create_cohort_criteria_from_omop(
    cohort_definition: Dict[str, Any]
) -> CohortCriteria:
    """
    Create CohortCriteria from OMOP cohort definition.

    Args:
        cohort_definition: OMOP cohort definition dictionary

    Returns:
        CohortCriteria instance
    """
    inclusion_rules = []
    exclusion_rules = []

    if "expression" in cohort_definition:
        expr = cohort_definition["expression"]

        if "InclusionRules" in expr:
            for rule in expr["InclusionRules"]:
                rule_desc = f"{rule.get('name', 'Unnamed')}: {rule.get('description', '')}"
                inclusion_rules.append(rule_desc)

        if "PrimaryCriteria" in expr:
            pc = expr["PrimaryCriteria"]
            if "ObservationWindow" in pc:
                obs_window = pc["ObservationWindow"]
                prior = obs_window.get("PriorDays", 0)
                post = obs_window.get("PostDays", 0)
                observation_window = f"Prior: {prior} days, Post: {post} days"
            else:
                observation_window = None
        else:
            observation_window = None
    else:
        observation_window = None

    return CohortCriteria(
        inclusion_rules=inclusion_rules or ["No explicit inclusion rules"],
        exclusion_rules=exclusion_rules or ["No explicit exclusion rules"],
        observation_window=observation_window
    )


def create_dataset_from_medsynth(
    medsynth_config: Dict[str, Any]
) -> SourceDataset:
    """
    Create SourceDataset from MedSynth configuration.

    Args:
        medsynth_config: MedSynth configuration dictionary

    Returns:
        SourceDataset instance
    """
    return SourceDataset(
        name=f"MedSynth Synthetic Dataset (v{medsynth_config.get('version', 'unknown')})",
        origin="Privacy-preserving synthetic data generated using MedSynth",
        size=medsynth_config.get("num_subjects", 0),
        collection_period="Synthetic (not applicable)",
        population_characteristics=medsynth_config.get(
            "population_characteristics",
            "Synthetic OMOP CDM data with privacy protection"
        )
    )


def summarize_omop_cohort(
    cohort_definition: Dict[str, Any],
    cohort_results: Optional[Dict[str, Any]] = None
) -> str:
    """
    Create summary text from OMOP cohort definition and results.

    Args:
        cohort_definition: OMOP cohort definition
        cohort_results: Optional cohort generation results

    Returns:
        Summary string
    """
    summary_parts = []

    summary_parts.append(f"Cohort: {cohort_definition.get('name', 'Unnamed')}")

    if cohort_results:
        person_count = cohort_results.get('personCount', 'N/A')
        summary_parts.append(f"Person Count: {person_count}")

    if "expression" in cohort_definition and "ConceptSets" in cohort_definition["expression"]:
        concept_sets = cohort_definition["expression"]["ConceptSets"]
        summary_parts.append(f"Concept Sets: {len(concept_sets)}")

    return "; ".join(summary_parts)


def build_data_factors_from_smart_omop(
    client: Any,
    cohort_id: int,
    source_key: str
) -> Dict[str, Any]:
    """
    Convenience helper: pull OMOP cohort definition/results via smart-omop
    and return concept sets, cohort criteria, and source dataset payloads.

    Args:
        client: smart_omop.OMOPClient instance
        cohort_id: Cohort id to fetch
        source_key: Source key for generation/results

    Returns:
        Dict with concept_sets, primary_cohort_criteria, source_datasets
    """
    try:
        from smart_omop import OMOPClient  # type: ignore
    except ImportError as exc:  # pragma: no cover
        raise ImportError("smart-omop is required for OMOP integration. Install with smart-model-card[omop].") from exc

    if not isinstance(client, OMOPClient):  # pragma: no cover - sanity guard
        raise TypeError("client must be a smart_omop.OMOPClient instance")

    cohort_def = client.get_cohort(cohort_id)
    cohort_results = client.get_cohort_results(cohort_id, source_key)

    adapter = create_omop_adapter(
        cohort_definition=cohort_def,
        cohort_results=cohort_results,
        source_name=cohort_def.get("name", f"Cohort {cohort_id}"),
        source_origin="OMOP CDM via smart-omop"
    )

    return {
        "concept_sets": adapter.get_concept_sets(),
        "primary_cohort_criteria": adapter.get_cohort_criteria(),
        "source_datasets": [adapter.get_dataset_info()]
    }


def refresh_data_factors_from_omop(
    card: Any,
    client: Any,
    cohort_id: int,
    source_key: str
) -> Any:
    """
    Update a ModelCard's DataFactors using smart-omop cohort definition/results.

    Args:
        card: ModelCard instance (mutated in place)
        client: smart_omop.OMOPClient instance
        cohort_id: Cohort id
        source_key: Source key for generation/results

    Returns:
        The updated card (for chaining)
    """
    payload = build_data_factors_from_smart_omop(client, cohort_id, source_key)
    card.set_data_factors(DataFactors(
        concept_sets=payload["concept_sets"],
        primary_cohort_criteria=payload["primary_cohort_criteria"],
        source_datasets=payload["source_datasets"],
        data_distribution_summary="Describe demographics/clinical distribution",
        data_representativeness="Compare against deployment setting",
        data_governance="IRB/consent/de-ID details"
    ))
    return card


def performance_from_dict(data: Dict[str, Any]) -> PerformanceValidation:
    """
    Build PerformanceValidation from a dict payload.

    Expected keys:
        claimed: list of {metric, value, status?, subgroup?}
        validated: list of {metric, value, status?, subgroup?}
        calibration: str
        fairness: str
        metric_validation_status: str
        validation_datasets: list of {name, source_institution, population_characteristics, validation_type}
    """
    def _metrics(items: List[Dict[str, Any]], default_status: str) -> List[PerformanceMetric]:
        out: List[PerformanceMetric] = []
        for m in items:
            out.append(PerformanceMetric(
                metric_name=m.get("metric") or m.get("metric_name"),
                value=float(m.get("value", 0.0)),
                validation_status=m.get("status") or m.get("validation_status") or default_status,
                subgroup=m.get("subgroup")
            ))
        return out

    claimed_raw = data.get("claimed") or []
    validated_raw = data.get("validated") or []
    datasets_raw = data.get("validation_datasets") or []

    datasets = [
        ValidationDataset(
            name=d.get("name", "Validation dataset"),
            source_institution=d.get("source_institution", "Unknown"),
            population_characteristics=d.get("population_characteristics", ""),
            validation_type=d.get("validation_type", "internal")
        ) for d in datasets_raw
    ] or [ValidationDataset("Validation dataset", "Unknown", "", "internal")]

    return PerformanceValidation(
        validation_datasets=datasets,
        claimed_metrics=_metrics(claimed_raw, "claimed"),
        validated_metrics=_metrics(validated_raw, "validated"),
        calibration_analysis=data.get("calibration"),
        fairness_assessment=data.get("fairness"),
        metric_validation_status=data.get("metric_validation_status", "claimed/internal/external status")
    )


def performance_from_file(path: str) -> PerformanceValidation:
    """
    Build PerformanceValidation from a JSON or CSV file.

    JSON schema: see performance_from_dict docstring.
    CSV columns: metric_name, value, validation_status (claimed|internal|external),
                 subgroup (optional), kind (claimed|validated), plus optional
                 calibration, fairness in a separate JSON if desired.
    """
    file_path = Path(path)
    if file_path.suffix.lower() == ".json":
        with file_path.open() as f:
            payload = json.load(f)
        return performance_from_dict(payload)

    if file_path.suffix.lower() == ".csv":
        claimed: List[Dict[str, Any]] = []
        validated: List[Dict[str, Any]] = []
        with file_path.open() as f:
            reader = csv.DictReader(f)
            for row in reader:
                item = {
                    "metric": row.get("metric_name") or row.get("metric"),
                    "value": float(row.get("value", 0.0)),
                    "status": row.get("validation_status"),
                    "subgroup": row.get("subgroup")
                }
                kind = (row.get("kind") or "").lower()
                if kind == "claimed":
                    claimed.append(item)
                else:
                    validated.append(item)
        return performance_from_dict({
            "claimed": claimed,
            "validated": validated
        })

    raise ValueError("Unsupported metrics file type; use .json or .csv")


def log_model_card_to_mlflow(card: Any, artifact_path: str = "model_card.json") -> str:
    """
    Export model card to JSON and log as MLflow artifact (if mlflow installed).
    """
    try:
        import mlflow  # type: ignore
    except ImportError as exc:  # pragma: no cover
        raise ImportError("mlflow is required for MLflow logging. Install mlflow or use pip install mlflow.") from exc

    with tempfile.TemporaryDirectory() as tmpdir:
        out_path = Path(tmpdir) / "model_card.json"
        JSONExporter.export(card, str(out_path))
        mlflow.log_artifact(str(out_path), artifact_path=str(Path(artifact_path).parent) if "/" in artifact_path else None)
    return artifact_path


def log_model_card_to_wandb(card: Any, artifact_path: str = "model_card.json") -> str:
    """
    Export model card to JSON and log as a W&B file (if wandb installed).
    """
    try:
        import wandb  # type: ignore
    except ImportError as exc:  # pragma: no cover
        raise ImportError("wandb is required for Weights & Biases logging. Install wandb or use pip install wandb.") from exc

    with tempfile.TemporaryDirectory() as tmpdir:
        out_path = Path(tmpdir) / "model_card.json"
        JSONExporter.export(card, str(out_path))
        wandb.save(str(out_path), base_path=tmpdir)
    return artifact_path
