# Placeholder to mark the z_image package for model auto-discovery.
