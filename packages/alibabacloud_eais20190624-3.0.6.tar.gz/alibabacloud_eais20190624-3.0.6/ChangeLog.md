2025-03-07 Version: 3.0.5
- Generated python 2019-06-24 for eais.

2025-03-06 Version: 3.0.4
- Update API DescribeEais: update response param.


2025-02-06 Version: 3.0.3
- Generated python 2019-06-24 for eais.

2025-01-15 Version: 3.0.2
- Update API CreateEai: add param Tag.
- Update API CreateEaiEci: add param Tag.
- Update API CreateEaiEcs: add param Tag.
- Update API CreateEaiEcs: update param Ecs.
- Update API CreateEaiJupyter: add param Tag.
- Update API CreateEaisEi: add param Tag.


2024-12-23 Version: 3.0.1
- Generated python 2019-06-24 for eais.

2024-10-24 Version: 3.0.0
- Support API ListTagResources.
- Support API StartEaiJupyter.
- Support API StopEaiJupyter.
- Support API TagResources.
- Support API UntagResources.
- Delete API CreateEaiAll.


2023-09-15 Version: 2.1.5
- Generated python 2019-06-24 for eais.

2023-09-01 Version: 2.1.4
- Generated python 2019-06-24 for eais.

2023-07-12 Version: 2.1.3
- Add openapi CreateEaisEi.
- Add openapi AttachEaisEi.
- Add openapi StartEaisEi.
- Add openapi StopEaisEi.
- Add openapi DetachEaisEi.
- Add openapi DeleteEaisEi.

2023-01-10 Version: 2.1.2
- Support ResourceGroup.

2022-12-13 Version: 2.1.1
- Add OpenAPI GetInstanceMetrics.

2022-11-23 Version: 2.1.0
- Add OpenAPI GetInstanceMetrics.
- OpenAPI DescribeEais Add return parameter StartTime.

2022-10-25 Version: 1.0.4
- OpenAPI CreateEaiJupyter add optional parameter `EnvironmentVar`.

2022-10-20 Version: 1.0.3
- Add OpenAPI CreateEaiJupyter.
- Fixd bugs for OpenAPI  DeleteEaiAll.

2021-07-28 Version: 1.0.2
- DesccribeEais api adds PageNumber, PageSize parameters.
- The api frequency of DescribeEais is set to 100.

2021-03-22 Version: 1.0.1
- CreateEai api adds SecurityGroupId, VSwitchId parameters.

2021-02-19 Version: 1.0.0
- Initialization.

