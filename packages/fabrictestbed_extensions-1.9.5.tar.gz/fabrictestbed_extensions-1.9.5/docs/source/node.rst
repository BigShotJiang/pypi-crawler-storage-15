node
====

.. automodule:: fabrictestbed_extensions.fablib.node
   :members:

.. autoclass:: fabrictestbed_extensions.fablib.node.Node
   :members:
   :no-index:
   :special-members: __str__
