"""
Utility functions for datamole.
"""

def log(message):
    pass
