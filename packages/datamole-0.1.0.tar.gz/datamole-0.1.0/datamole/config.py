"""
Configuration and environment utilities for datamole.
"""

def load_config():
    """Load configuration from .config or environment variables."""
    pass
