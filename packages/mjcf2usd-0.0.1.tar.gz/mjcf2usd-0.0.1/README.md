# mjcf2usd

Convert MJCF (MuJoCo XML) to USD format.

## Installation

```bash
pip install mjcf2usd
```

## Usage

```python
import mjcf2usd
```
