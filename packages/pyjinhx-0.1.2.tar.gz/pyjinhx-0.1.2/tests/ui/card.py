from pyjinhx import BaseComponent
from tests.ui.button import Button


class Card(BaseComponent):
    id: str
    title: str
    content: Button

