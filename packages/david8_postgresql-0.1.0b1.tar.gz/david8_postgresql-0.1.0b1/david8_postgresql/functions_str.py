from david8.core.fn_generator import SeparatedStrArgsCallableFactory as _SeparatedStrArgsCallableFactory

concat = _SeparatedStrArgsCallableFactory(name='concat', separator=' || ')
