from .blink import BLINK

__all__ = ["BLINK"]
