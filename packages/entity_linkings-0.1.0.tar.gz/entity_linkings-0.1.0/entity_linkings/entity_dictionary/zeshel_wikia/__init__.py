from .zeshel_wikia import ZESHEL_WIKIA

__all__ = ["ZESHEL_WIKIA"]
