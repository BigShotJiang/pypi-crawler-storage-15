from .kilt_wiki import KILT_WIKI

__all__ = ["KILT_WIKI"]
