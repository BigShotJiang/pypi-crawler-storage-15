from .zelda_wiki import ZELDA_WIKI

__all__ = ["ZELDA_WIKI"]
