"""
Setup script for PyCharter.

This script handles building the UI before packaging, similar to how Airflow
includes pre-built static files in its package.
"""

import os
import subprocess
import sys
from pathlib import Path

from setuptools import setup
from setuptools.command.build_py import build_py
from setuptools.command.sdist import sdist


class BuildUICommand(build_py):
    """Custom build command that builds the UI before packaging."""
    
    def run(self):
        """Build the UI static files before building the package."""
        ui_dir = Path(__file__).parent / "ui"
        static_dir = ui_dir / "static"
        
        # Check if UI needs to be built
        if not static_dir.exists() or not (static_dir / "index.html").exists():
            print("Building UI static files for package...")
            
            # Check if package.json exists
            if not (ui_dir / "package.json").exists():
                print("⚠ Warning: UI package.json not found. Skipping UI build.")
                print("   UI static files will not be included in the package.")
                super().run()
                return
            
            # Check if node_modules exists
            if not (ui_dir / "node_modules").exists():
                print("⚠ Warning: node_modules not found. Skipping UI build.")
                print("   Run 'cd ui && npm install' first to include UI in package.")
                super().run()
                return
            
            # Build the UI
            try:
                env = os.environ.copy()
                env["NODE_ENV"] = "production"
                subprocess.run(
                    ["npm", "run", "build"],
                    cwd=str(ui_dir),
                    check=True,
                    env=env,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                )
                
                # Copy out/ to static/ if needed
                out_dir = ui_dir / "out"
                if out_dir.exists():
                    import shutil
                    if static_dir.exists():
                        shutil.rmtree(static_dir)
                    shutil.copytree(out_dir, static_dir)
                    print("✓ UI built successfully")
            except (subprocess.CalledProcessError, FileNotFoundError) as e:
                print(f"⚠ Warning: UI build failed: {e}")
                print("   Package will be built without UI static files.")
                print("   Users can build UI manually: pycharter ui build")
        
        # Continue with normal build
        super().run()


class SDistCommand(sdist):
    """Custom sdist command that builds UI before creating source distribution."""
    
    def run(self):
        """Build UI before creating source distribution."""
        # Build UI first
        ui_dir = Path(__file__).parent / "ui"
        static_dir = ui_dir / "static"
        out_dir = ui_dir / "out"
        
        # Check if UI needs to be built
        if not static_dir.exists() or not (static_dir / "index.html").exists():
            if (ui_dir / "package.json").exists() and (ui_dir / "node_modules").exists():
                try:
                    env = os.environ.copy()
                    env["NODE_ENV"] = "production"
                    subprocess.run(
                        ["npm", "run", "build"],
                        cwd=str(ui_dir),
                        check=True,
                        env=env,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                    )
                    
                    # Copy out/ to static/ if needed
                    if out_dir.exists():
                        import shutil
                        if static_dir.exists():
                            shutil.rmtree(static_dir)
                        shutil.copytree(out_dir, static_dir)
                        print("✓ UI built successfully")
                except (subprocess.CalledProcessError, FileNotFoundError) as e:
                    print(f"⚠ Warning: UI build failed: {e}")
        
        super().run()


# Read pyproject.toml for setup configuration
# This is a minimal setup.py that hooks into the build process
if __name__ == "__main__":
    # The actual setup is defined in pyproject.toml
    # This file just adds custom build commands
    from setuptools import find_packages
    
    setup(
        cmdclass={
            "build_py": BuildUICommand,
            "sdist": SDistCommand,
        },
    )

