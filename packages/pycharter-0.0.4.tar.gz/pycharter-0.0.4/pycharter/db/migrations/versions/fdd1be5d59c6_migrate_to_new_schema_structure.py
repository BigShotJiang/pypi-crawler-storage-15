"""Migrate to new schema structure with data_contracts

Revision ID: fdd1be5d59c6
Revises: a8acb1d9a1d2
Create Date: 2025-11-28 10:36:07.241651

This migration handles the major schema restructuring:
1. Restructure metadata_records table (was metadata)
2. Rename and restructure ownership to owners
3. Update schemas table with title and data_contract
4. Update coercion_rules with new fields
5. Update validation_rules with new fields
6. Update data_contracts foreign keys and add version tracking
7. Create join tables for metadata_record relationships
"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = "fdd1be5d59c6"
down_revision: Union[str, None] = "a8acb1d9a1d2"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """
    Upgrade database to new schema structure.

    This migration performs a major restructuring:
    - Renames metadata_record (singular) to metadata_records (plural)
    - Restructures metadata_records table
    - Renames ownership to owners and restructures
    - Updates schemas, coercion_rules, validation_rules tables
    - Updates data_contracts foreign keys
    - Creates join tables for metadata_record relationships
    """

    # ============================================================================
    # Step 0: Rename metadata_record to metadata_records (plural to match model)
    # ============================================================================

    # Check if table exists as metadata_record (singular) and rename to metadata_records (plural)
    # The previous migration renamed metadata -> metadata_record, but model expects metadata_records
    # First, drop the foreign key constraint in data_contracts that references metadata_record
    op.execute(
        """
        DO $$ 
        BEGIN
            IF EXISTS (
                SELECT 1 FROM pg_constraint 
                WHERE conname = 'data_contracts_metadata_id_fkey' 
                AND conrelid = 'pycharter.data_contracts'::regclass
            ) THEN
                ALTER TABLE pycharter.data_contracts DROP CONSTRAINT data_contracts_metadata_id_fkey;
            END IF;
        END $$;
    """
    )

    # Now rename the table
    op.rename_table("metadata_record", "metadata_records", schema="pycharter")

    # Update the unique constraint name to match new table name
    op.execute(
        """
        DO $$ 
        BEGIN
            IF EXISTS (
                SELECT 1 FROM pg_constraint 
                WHERE conname = 'uq_metadata_record_resource' 
                AND connamespace = (SELECT oid FROM pg_namespace WHERE nspname = 'pycharter')
                AND conrelid = 'pycharter.metadata_records'::regclass
            ) THEN
                ALTER TABLE pycharter.metadata_records DROP CONSTRAINT uq_metadata_record_resource;
            END IF;
        END $$;
    """
    )
    op.create_unique_constraint(
        "uq_metadata_records_resource",
        "metadata_records",
        ["resource_id", "resource_type"],
        schema="pycharter",
    )

    # Recreate the foreign key constraint pointing to the renamed table
    op.execute(
        """
        DO $$ 
        BEGIN
            IF EXISTS (SELECT 1 FROM pycharter.data_contracts WHERE metadata_id IS NOT NULL) THEN
                ALTER TABLE pycharter.data_contracts 
                ADD CONSTRAINT data_contracts_metadata_id_fkey_temp 
                FOREIGN KEY (metadata_id) REFERENCES pycharter.metadata_records(id) ON DELETE SET NULL;
            END IF;
        END $$;
    """
    )

    # ============================================================================
    # Step 1: Create new join tables for metadata_record relationships
    # ============================================================================

    # Create metadata_record_system_pulls join table
    op.create_table(
        "metadata_record_system_pulls",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("metadata_record_id", sa.Integer(), nullable=False),
        sa.Column("system_id", sa.Integer(), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=True,
        ),
        sa.ForeignKeyConstraint(
            ["metadata_record_id"],
            ["pycharter.metadata_records.id"],
            ondelete="CASCADE",
        ),
        sa.ForeignKeyConstraint(
            ["system_id"], ["pycharter.systems.id"], ondelete="CASCADE"
        ),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint(
            "metadata_record_id", "system_id", name="uq_mr_system_pull"
        ),
        schema="pycharter",
    )

    # Create metadata_record_system_pushes join table
    op.create_table(
        "metadata_record_system_pushes",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("metadata_record_id", sa.Integer(), nullable=False),
        sa.Column("system_id", sa.Integer(), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=True,
        ),
        sa.ForeignKeyConstraint(
            ["metadata_record_id"],
            ["pycharter.metadata_records.id"],
            ondelete="CASCADE",
        ),
        sa.ForeignKeyConstraint(
            ["system_id"], ["pycharter.systems.id"], ondelete="CASCADE"
        ),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint(
            "metadata_record_id", "system_id", name="uq_mr_system_push"
        ),
        schema="pycharter",
    )

    # Create metadata_record_system_sources join table
    op.create_table(
        "metadata_record_system_sources",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("metadata_record_id", sa.Integer(), nullable=False),
        sa.Column("system_id", sa.Integer(), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=True,
        ),
        sa.ForeignKeyConstraint(
            ["metadata_record_id"],
            ["pycharter.metadata_records.id"],
            ondelete="CASCADE",
        ),
        sa.ForeignKeyConstraint(
            ["system_id"], ["pycharter.systems.id"], ondelete="CASCADE"
        ),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint(
            "metadata_record_id", "system_id", name="uq_mr_system_source"
        ),
        schema="pycharter",
    )

    # Create metadata_record_domains join table
    op.create_table(
        "metadata_record_domains",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("metadata_record_id", sa.Integer(), nullable=False),
        sa.Column("domain_id", sa.Integer(), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=True,
        ),
        sa.ForeignKeyConstraint(
            ["metadata_record_id"],
            ["pycharter.metadata_records.id"],
            ondelete="CASCADE",
        ),
        sa.ForeignKeyConstraint(
            ["domain_id"], ["pycharter.domains.id"], ondelete="CASCADE"
        ),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("metadata_record_id", "domain_id", name="uq_mr_domain"),
        schema="pycharter",
    )

    # ============================================================================
    # Step 2: Restructure metadata_records table
    # ============================================================================

    # Add new columns to metadata_records (if they don't exist)
    # Note: We'll add nullable columns first, then migrate data, then make them non-nullable

    op.add_column(
        "metadata_records",
        sa.Column("title", sa.String(length=255), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "metadata_records",
        sa.Column("data_contract", sa.String(length=255), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "metadata_records",
        sa.Column("version", sa.String(length=50), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "metadata_records",
        sa.Column("status", sa.String(length=50), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "metadata_records",
        sa.Column("type", sa.String(length=50), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "metadata_records",
        sa.Column("description", sa.Text(), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "metadata_records",
        sa.Column("created_by", sa.String(length=255), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "metadata_records",
        sa.Column("updated_by", sa.String(length=255), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "metadata_records",
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=True,
        ),
        schema="pycharter",
    )
    op.add_column(
        "metadata_records",
        sa.Column("business_owners", sa.JSON(), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "metadata_records",
        sa.Column("bu_sme", sa.JSON(), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "metadata_records",
        sa.Column("governance_rules", sa.JSON(), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "metadata_records",
        sa.Column("business_rules", sa.JSON(), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "metadata_records",
        sa.Column("serve", sa.JSON(), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "metadata_records",
        sa.Column("indexes", sa.JSON(), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "metadata_records",
        sa.Column("additional_metadata", sa.JSON(), nullable=True),
        schema="pycharter",
    )

    # Migrate data from old structure to new structure
    # Extract data_contract and version from resource_id if possible
    # This is a data migration - adjust based on your actual data structure
    op.execute(
        """
        UPDATE pycharter.metadata_records
        SET 
            data_contract = COALESCE(resource_id, 'unknown'),
            version = '1.0.0',
            title = COALESCE((metadata_data->>'title')::text, resource_id),
            status = 'active',
            type = COALESCE((metadata_data->>'type')::text, 'object'),
            description = (metadata_data->>'description')::text,
            business_owners = (metadata_data->'ownership'->'business_owners')::jsonb,
            bu_sme = (metadata_data->'ownership'->'bu_sme')::jsonb,
            governance_rules = (metadata_data->'governance_rules')::jsonb,
            business_rules = (metadata_data->'business_rules')::jsonb,
            serve = (metadata_data->'serve')::jsonb,
            indexes = (metadata_data->'indexes')::jsonb,
            additional_metadata = metadata_data
        WHERE data_contract IS NULL
    """
    )

    # Drop old unique constraint
    # The previous migration created 'uq_metadata_record_resource', but we need to drop it
    # Use execute to check and drop if exists (safer than try/except with Alembic)
    op.execute(
        """
        DO $$ 
        BEGIN
            IF EXISTS (
                SELECT 1 FROM pg_constraint 
                WHERE conname = 'uq_metadata_record_resource' 
                AND connamespace = (SELECT oid FROM pg_namespace WHERE nspname = 'pycharter')
            ) THEN
                ALTER TABLE pycharter.metadata_records DROP CONSTRAINT uq_metadata_record_resource;
            END IF;
            
            IF EXISTS (
                SELECT 1 FROM pg_constraint 
                WHERE conname = 'uq_metadata_records_resource' 
                AND connamespace = (SELECT oid FROM pg_namespace WHERE nspname = 'pycharter')
            ) THEN
                ALTER TABLE pycharter.metadata_records DROP CONSTRAINT uq_metadata_records_resource;
            END IF;
        END $$;
    """
    )

    # Drop old columns (resource_id, resource_type, metadata_data)
    op.drop_column("metadata_records", "resource_id", schema="pycharter")
    op.drop_column("metadata_records", "resource_type", schema="pycharter")
    op.drop_column("metadata_records", "metadata_data", schema="pycharter")

    # Make required columns non-nullable
    op.alter_column("metadata_records", "title", nullable=False, schema="pycharter")
    op.alter_column(
        "metadata_records", "data_contract", nullable=False, schema="pycharter"
    )
    op.alter_column("metadata_records", "version", nullable=False, schema="pycharter")

    # Create new unique constraint
    op.create_unique_constraint(
        "uq_metadata_records_contract_version",
        "metadata_records",
        ["data_contract", "version"],
        schema="pycharter",
    )

    # ============================================================================
    # Step 3: Rename and restructure ownership to owners
    # ============================================================================

    # First, drop the foreign key constraint in data_contracts that references ownership
    # This must be done before we can drop the ownership table
    op.execute(
        """
        DO $$ 
        BEGIN
            IF EXISTS (
                SELECT 1 FROM pg_constraint 
                WHERE conname = 'data_contracts_ownership_id_fkey' 
                AND conrelid = 'pycharter.data_contracts'::regclass
            ) THEN
                ALTER TABLE pycharter.data_contracts DROP CONSTRAINT data_contracts_ownership_id_fkey;
            END IF;
        END $$;
    """
    )

    # Create new owners table
    op.create_table(
        "owners",
        sa.Column("id", sa.String(length=255), nullable=False),
        sa.Column("owner", sa.String(length=255), nullable=True),
        sa.Column("team", sa.String(length=255), nullable=True),
        sa.Column("business_owners", sa.JSON(), nullable=True),
        sa.Column("bu_sme", sa.JSON(), nullable=True),
        sa.Column("domains", sa.JSON(), nullable=True),
        sa.Column("additional_info", sa.JSON(), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=True,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            onupdate=sa.text("now()"),
            nullable=True,
        ),
        sa.PrimaryKeyConstraint("id"),
        schema="pycharter",
    )

    # Migrate data from ownership to owners
    op.execute(
        """
        INSERT INTO pycharter.owners (id, owner, team, additional_info, created_at, updated_at)
        SELECT resource_id, owner, team, additional_info, created_at, updated_at
        FROM pycharter.ownership
        ON CONFLICT (id) DO NOTHING
    """
    )

    # Now we can safely drop the old ownership table
    op.drop_table("ownership", schema="pycharter")

    # ============================================================================
    # Step 4: Update schemas table
    # ============================================================================

    # Add new columns
    op.add_column(
        "schemas",
        sa.Column("title", sa.String(length=255), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "schemas",
        sa.Column("data_contract", sa.String(length=255), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "schemas",
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            onupdate=sa.text("now()"),
            nullable=True,
        ),
        schema="pycharter",
    )

    # Migrate data: extract title and data_contract from schema_data or use name
    op.execute(
        """
        UPDATE pycharter.schemas
        SET 
            title = COALESCE((schema_data->>'title')::text, name),
            data_contract = COALESCE((schema_data->>'data_contract')::text, name),
            updated_at = created_at
        WHERE title IS NULL
    """
    )

    # Drop old unique constraint
    op.drop_constraint(
        "uq_schemas_name_version", "schemas", schema="pycharter", type_="unique"
    )

    # Drop old name column (after ensuring data_contract is populated)
    # Note: We keep name for now in case it's needed, but you can drop it if not needed
    # op.drop_column('schemas', 'name', schema='pycharter')

    # Make new columns non-nullable
    op.alter_column("schemas", "title", nullable=False, schema="pycharter")
    op.alter_column("schemas", "data_contract", nullable=False, schema="pycharter")
    op.alter_column("schemas", "version", nullable=False, schema="pycharter")

    # Create new unique constraint
    op.create_unique_constraint(
        "uq_schemas_contract_version",
        "schemas",
        ["data_contract", "version"],
        schema="pycharter",
    )

    # ============================================================================
    # Step 5: Update coercion_rules table
    # ============================================================================

    # Add new columns
    op.add_column(
        "coercion_rules",
        sa.Column("title", sa.String(length=255), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "coercion_rules",
        sa.Column("data_contract", sa.String(length=255), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "coercion_rules",
        sa.Column("description", sa.String(length=500), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "coercion_rules",
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            onupdate=sa.text("now()"),
            nullable=True,
        ),
        schema="pycharter",
    )

    # Migrate data: get data_contract from schema
    op.execute(
        """
        UPDATE pycharter.coercion_rules cr
        SET 
            data_contract = COALESCE(s.data_contract, s.name, 'unknown'),
            title = COALESCE(s.title, s.name || ' Coercion Rules'),
            description = NULL,
            updated_at = cr.created_at
        FROM pycharter.schemas s
        WHERE cr.schema_id = s.id AND cr.data_contract IS NULL
    """
    )

    # Make schema_id nullable (it's now optional)
    op.alter_column("coercion_rules", "schema_id", nullable=True, schema="pycharter")

    # Drop old unique constraint
    op.drop_constraint(
        "uq_coercion_rules_schema_version",
        "coercion_rules",
        schema="pycharter",
        type_="unique",
    )

    # Make new columns non-nullable
    op.alter_column("coercion_rules", "title", nullable=False, schema="pycharter")
    op.alter_column(
        "coercion_rules", "data_contract", nullable=False, schema="pycharter"
    )
    op.alter_column("coercion_rules", "version", nullable=False, schema="pycharter")

    # Create new unique constraint
    op.create_unique_constraint(
        "uq_coercion_rules_contract_version",
        "coercion_rules",
        ["data_contract", "version"],
        schema="pycharter",
    )

    # ============================================================================
    # Step 6: Update validation_rules table
    # ============================================================================

    # Add new columns
    op.add_column(
        "validation_rules",
        sa.Column("title", sa.String(length=255), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "validation_rules",
        sa.Column("data_contract", sa.String(length=255), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "validation_rules",
        sa.Column("description", sa.String(length=500), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "validation_rules",
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            onupdate=sa.text("now()"),
            nullable=True,
        ),
        schema="pycharter",
    )

    # Migrate data: get data_contract from schema
    op.execute(
        """
        UPDATE pycharter.validation_rules vr
        SET 
            data_contract = COALESCE(s.data_contract, s.name, 'unknown'),
            title = COALESCE(s.title, s.name || ' Validation Rules'),
            description = NULL,
            updated_at = vr.created_at
        FROM pycharter.schemas s
        WHERE vr.schema_id = s.id AND vr.data_contract IS NULL
    """
    )

    # Make schema_id nullable (it's now optional)
    op.alter_column("validation_rules", "schema_id", nullable=True, schema="pycharter")

    # Drop old unique constraint
    op.drop_constraint(
        "uq_validation_rules_schema_version",
        "validation_rules",
        schema="pycharter",
        type_="unique",
    )

    # Make new columns non-nullable
    op.alter_column("validation_rules", "title", nullable=False, schema="pycharter")
    op.alter_column(
        "validation_rules", "data_contract", nullable=False, schema="pycharter"
    )
    op.alter_column("validation_rules", "version", nullable=False, schema="pycharter")

    # Create new unique constraint
    op.create_unique_constraint(
        "uq_validation_rules_contract_version",
        "validation_rules",
        ["data_contract", "version"],
        schema="pycharter",
    )

    # ============================================================================
    # Step 7: Update data_contracts table
    # ============================================================================

    # First, drop the old foreign key constraint for metadata_id
    # The previous migration created a FK to metadata_record (singular)
    # Use SQL to safely drop the constraint if it exists
    op.execute(
        """
        DO $$ 
        BEGIN
            IF EXISTS (
                SELECT 1 FROM pg_constraint 
                WHERE conname = 'data_contracts_metadata_id_fkey' 
                AND conrelid = 'pycharter.data_contracts'::regclass
            ) THEN
                ALTER TABLE pycharter.data_contracts DROP CONSTRAINT data_contracts_metadata_id_fkey;
            END IF;
        END $$;
    """
    )

    # Rename metadata_id to metadata_record_id
    op.alter_column(
        "data_contracts",
        "metadata_id",
        new_column_name="metadata_record_id",
        schema="pycharter",
    )

    # Create new foreign key constraint pointing to metadata_records (plural)
    op.create_foreign_key(
        "data_contracts_metadata_record_id_fkey",
        "data_contracts",
        "metadata_records",
        ["metadata_record_id"],
        ["id"],
        source_schema="pycharter",
        referent_schema="pycharter",
        ondelete="SET NULL",
    )

    # Rename ownership_id to owner_id and change foreign key
    # First, drop the old foreign key constraint (safely)
    op.execute(
        """
        DO $$ 
        BEGIN
            IF EXISTS (
                SELECT 1 FROM pg_constraint 
                WHERE conname = 'data_contracts_ownership_id_fkey' 
                AND conrelid = 'pycharter.data_contracts'::regclass
            ) THEN
                ALTER TABLE pycharter.data_contracts DROP CONSTRAINT data_contracts_ownership_id_fkey;
            END IF;
        END $$;
    """
    )

    # Rename the column first
    op.alter_column(
        "data_contracts", "ownership_id", new_column_name="owner_id", schema="pycharter"
    )

    # Change column type if needed (ownership_id was String, owner_id is also String)
    # Then add new foreign key constraint
    op.create_foreign_key(
        "data_contracts_owner_id_fkey",
        "data_contracts",
        "owners",
        ["owner_id"],
        ["id"],
        source_schema="pycharter",
        referent_schema="pycharter",
        ondelete="SET NULL",
    )

    # Add version tracking columns
    op.add_column(
        "data_contracts",
        sa.Column("schema_version", sa.String(length=50), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "data_contracts",
        sa.Column("coercion_rules_version", sa.String(length=50), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "data_contracts",
        sa.Column("validation_rules_version", sa.String(length=50), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "data_contracts",
        sa.Column("metadata_version", sa.String(length=50), nullable=True),
        schema="pycharter",
    )

    # Migrate version data from related tables
    # PostgreSQL doesn't allow LEFT JOINs in UPDATE with table alias, so we use subqueries
    op.execute(
        """
        UPDATE pycharter.data_contracts
        SET 
            schema_version = s.version,
            coercion_rules_version = (
                SELECT version FROM pycharter.coercion_rules 
                WHERE id = pycharter.data_contracts.coercion_rules_id
            ),
            validation_rules_version = (
                SELECT version FROM pycharter.validation_rules 
                WHERE id = pycharter.data_contracts.validation_rules_id
            ),
            metadata_version = (
                SELECT version FROM pycharter.metadata_records 
                WHERE id = pycharter.data_contracts.metadata_record_id
            )
        FROM pycharter.schemas s
        WHERE pycharter.data_contracts.schema_id = s.id
    """
    )


def downgrade() -> None:
    """
    Downgrade database to previous schema structure.

    WARNING: This downgrade may result in data loss as it reverses
    the restructuring. Use with caution.
    """

    # ============================================================================
    # Step 7: Revert data_contracts table
    # ============================================================================

    # Remove version tracking columns
    op.drop_column("data_contracts", "metadata_version", schema="pycharter")
    op.drop_column("data_contracts", "validation_rules_version", schema="pycharter")
    op.drop_column("data_contracts", "coercion_rules_version", schema="pycharter")
    op.drop_column("data_contracts", "schema_version", schema="pycharter")

    # Revert owner_id to ownership_id
    op.drop_constraint(
        "data_contracts_owner_id_fkey",
        "data_contracts",
        schema="pycharter",
        type_="foreignkey",
    )
    op.alter_column(
        "data_contracts", "owner_id", new_column_name="ownership_id", schema="pycharter"
    )
    op.create_foreign_key(
        "data_contracts_ownership_id_fkey",
        "data_contracts",
        "ownership",
        ["ownership_id"],
        ["resource_id"],
        source_schema="pycharter",
        referent_schema="pycharter",
        ondelete="SET NULL",
    )

    # Revert metadata_record_id to metadata_id
    op.alter_column(
        "data_contracts",
        "metadata_record_id",
        new_column_name="metadata_id",
        schema="pycharter",
    )

    # ============================================================================
    # Step 6: Revert validation_rules table
    # ============================================================================

    op.drop_constraint(
        "uq_validation_rules_contract_version",
        "validation_rules",
        schema="pycharter",
        type_="unique",
    )
    op.create_unique_constraint(
        "uq_validation_rules_schema_version",
        "validation_rules",
        ["schema_id", "version"],
        schema="pycharter",
    )
    op.alter_column("validation_rules", "schema_id", nullable=False, schema="pycharter")
    op.drop_column("validation_rules", "updated_at", schema="pycharter")
    op.drop_column("validation_rules", "description", schema="pycharter")
    op.drop_column("validation_rules", "data_contract", schema="pycharter")
    op.drop_column("validation_rules", "title", schema="pycharter")

    # ============================================================================
    # Step 5: Revert coercion_rules table
    # ============================================================================

    op.drop_constraint(
        "uq_coercion_rules_contract_version",
        "coercion_rules",
        schema="pycharter",
        type_="unique",
    )
    op.create_unique_constraint(
        "uq_coercion_rules_schema_version",
        "coercion_rules",
        ["schema_id", "version"],
        schema="pycharter",
    )
    op.alter_column("coercion_rules", "schema_id", nullable=False, schema="pycharter")
    op.drop_column("coercion_rules", "updated_at", schema="pycharter")
    op.drop_column("coercion_rules", "description", schema="pycharter")
    op.drop_column("coercion_rules", "data_contract", schema="pycharter")
    op.drop_column("coercion_rules", "title", schema="pycharter")

    # ============================================================================
    # Step 4: Revert schemas table
    # ============================================================================

    op.drop_constraint(
        "uq_schemas_contract_version", "schemas", schema="pycharter", type_="unique"
    )
    op.create_unique_constraint(
        "uq_schemas_name_version", "schemas", ["name", "version"], schema="pycharter"
    )
    op.drop_column("schemas", "updated_at", schema="pycharter")
    op.drop_column("schemas", "data_contract", schema="pycharter")
    op.drop_column("schemas", "title", schema="pycharter")

    # ============================================================================
    # Step 3: Revert owners to ownership
    # ============================================================================

    # Recreate ownership table
    op.create_table(
        "ownership",
        sa.Column("resource_id", sa.String(length=255), nullable=False),
        sa.Column("owner", sa.String(length=255), nullable=False),
        sa.Column("team", sa.String(length=255), nullable=True),
        sa.Column("additional_info", sa.JSON(), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=True,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=True,
        ),
        sa.PrimaryKeyConstraint("resource_id"),
        schema="pycharter",
    )

    # Migrate data back
    op.execute(
        """
        INSERT INTO pycharter.ownership (resource_id, owner, team, additional_info, created_at, updated_at)
        SELECT id, owner, team, additional_info, created_at, updated_at
        FROM pycharter.owners
        ON CONFLICT (resource_id) DO NOTHING
    """
    )

    op.drop_table("owners", schema="pycharter")

    # ============================================================================
    # Step 2: Revert metadata_records table
    # ============================================================================

    # Add back old columns
    op.add_column(
        "metadata_records",
        sa.Column("resource_id", sa.String(length=255), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "metadata_records",
        sa.Column("resource_type", sa.String(length=50), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "metadata_records",
        sa.Column("metadata_data", sa.JSON(), nullable=True),
        schema="pycharter",
    )

    # Migrate data back
    op.execute(
        """
        UPDATE pycharter.metadata_records
        SET 
            resource_id = data_contract,
            resource_type = COALESCE(type, 'schema'),
            metadata_data = jsonb_build_object(
                'title', title,
                'description', description,
                'type', type,
                'ownership', jsonb_build_object(
                    'business_owners', business_owners,
                    'bu_sme', bu_sme
                ),
                'governance_rules', governance_rules,
                'business_rules', business_rules,
                'serve', serve,
                'indexes', indexes
            ) || COALESCE(additional_metadata, '{}'::jsonb)
        WHERE resource_id IS NULL
    """
    )

    op.drop_constraint(
        "uq_metadata_records_contract_version",
        "metadata_records",
        schema="pycharter",
        type_="unique",
    )
    op.create_unique_constraint(
        "uq_metadata_record_resource",
        "metadata_records",
        ["resource_id", "resource_type"],
        schema="pycharter",
    )

    # Drop new columns
    op.drop_column("metadata_records", "additional_metadata", schema="pycharter")
    op.drop_column("metadata_records", "indexes", schema="pycharter")
    op.drop_column("metadata_records", "serve", schema="pycharter")
    op.drop_column("metadata_records", "business_rules", schema="pycharter")
    op.drop_column("metadata_records", "governance_rules", schema="pycharter")
    op.drop_column("metadata_records", "bu_sme", schema="pycharter")
    op.drop_column("metadata_records", "business_owners", schema="pycharter")
    op.drop_column("metadata_records", "updated_at", schema="pycharter")
    op.drop_column("metadata_records", "updated_by", schema="pycharter")
    op.drop_column("metadata_records", "created_by", schema="pycharter")
    op.drop_column("metadata_records", "description", schema="pycharter")
    op.drop_column("metadata_records", "type", schema="pycharter")
    op.drop_column("metadata_records", "status", schema="pycharter")
    op.drop_column("metadata_records", "version", schema="pycharter")
    op.drop_column("metadata_records", "data_contract", schema="pycharter")
    op.drop_column("metadata_records", "title", schema="pycharter")

    # Make old columns non-nullable
    op.alter_column(
        "metadata_records", "resource_id", nullable=False, schema="pycharter"
    )
    op.alter_column(
        "metadata_records", "resource_type", nullable=False, schema="pycharter"
    )
    op.alter_column(
        "metadata_records", "metadata_data", nullable=False, schema="pycharter"
    )

    # ============================================================================
    # Step 1: Drop join tables
    # ============================================================================

    op.drop_table("metadata_record_domains", schema="pycharter")
    op.drop_table("metadata_record_system_sources", schema="pycharter")
    op.drop_table("metadata_record_system_pushes", schema="pycharter")
    op.drop_table("metadata_record_system_pulls", schema="pycharter")
