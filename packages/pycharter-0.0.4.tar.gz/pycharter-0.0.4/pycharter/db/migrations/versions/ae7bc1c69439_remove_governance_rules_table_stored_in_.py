"""Remove governance_rules table - stored in metadata_records

Revision ID: ae7bc1c69439
Revises: 52d5fb43efcb
Create Date: 2025-12-02 11:38:03.668996

"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision: str = "ae7bc1c69439"
down_revision: Union[str, None] = "52d5fb43efcb"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Drop the governance_rules table - governance rules are stored as JSON in metadata_records
    op.drop_table("governance_rules", schema="pycharter")


def downgrade() -> None:
    # Recreate governance_rules table if needed for rollback
    op.create_table(
        "governance_rules",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("name", sa.String(length=255), nullable=False),
        sa.Column("rule_definition", sa.JSON(), nullable=False),
        sa.Column("schema_id", sa.Integer(), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=True,
        ),
        sa.ForeignKeyConstraint(
            ["schema_id"],
            ["pycharter.schemas.id"],
        ),
        sa.PrimaryKeyConstraint("id"),
        schema="pycharter",
    )
