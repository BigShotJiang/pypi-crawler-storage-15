"""Convert all Integer IDs to UUIDs

Revision ID: e8870b97027a
Revises: bb63cf33b976
Create Date: 2025-12-02 12:16:10.062297

This migration converts all Integer primary keys and foreign keys to UUIDs.
It preserves existing data by:
1. Adding new UUID columns alongside existing integer columns
2. Generating UUIDs for existing rows
3. Updating all foreign key references
4. Dropping old integer columns
"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = "e8870b97027a"
down_revision: Union[str, None] = "bb63cf33b976"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """
    Convert all Integer IDs to UUIDs while preserving existing data.

    Strategy:
    1. Add UUID columns alongside integer columns
    2. Generate UUIDs for existing rows
    3. Update foreign keys to reference UUIDs
    4. Drop integer columns and constraints
    5. Rename UUID columns to final names
    6. Recreate foreign key constraints
    """

    # Step 1: Add UUID columns to all tables (starting with tables that have no foreign key dependencies)

    # Systems and Domains (no foreign keys to other tables)
    op.add_column(
        "systems",
        sa.Column("id_new", postgresql.UUID(as_uuid=True), nullable=True),
        schema="pycharter",
    )
    op.execute("UPDATE pycharter.systems SET id_new = gen_random_uuid()")

    op.add_column(
        "domains",
        sa.Column("id_new", postgresql.UUID(as_uuid=True), nullable=True),
        schema="pycharter",
    )
    op.execute("UPDATE pycharter.domains SET id_new = gen_random_uuid()")

    # Data contracts (base table - other tables reference it)
    op.add_column(
        "data_contracts",
        sa.Column("id_new", postgresql.UUID(as_uuid=True), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "data_contracts",
        sa.Column("schema_id_new", postgresql.UUID(as_uuid=True), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "data_contracts",
        sa.Column(
            "coercion_rules_id_new", postgresql.UUID(as_uuid=True), nullable=True
        ),
        schema="pycharter",
    )
    op.add_column(
        "data_contracts",
        sa.Column(
            "validation_rules_id_new", postgresql.UUID(as_uuid=True), nullable=True
        ),
        schema="pycharter",
    )
    op.add_column(
        "data_contracts",
        sa.Column(
            "metadata_record_id_new", postgresql.UUID(as_uuid=True), nullable=True
        ),
        schema="pycharter",
    )
    # Handle domain_id if it exists (may not be in current model but exists in DB)
    op.execute("UPDATE pycharter.data_contracts SET id_new = gen_random_uuid()")
    # Update domain_id if the column exists
    try:
        op.add_column(
            "data_contracts",
            sa.Column("domain_id_new", postgresql.UUID(as_uuid=True), nullable=True),
            schema="pycharter",
        )
        op.execute(
            """
            UPDATE pycharter.data_contracts
            SET domain_id_new = d.id_new
            FROM pycharter.domains d
            WHERE data_contracts.domain_id = d.id
        """
        )
    except Exception:
        pass  # domain_id column may not exist

    # Schemas (references data_contracts)
    op.add_column(
        "schemas",
        sa.Column("id_new", postgresql.UUID(as_uuid=True), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "schemas",
        sa.Column("data_contract_id_new", postgresql.UUID(as_uuid=True), nullable=True),
        schema="pycharter",
    )
    op.execute(
        """
        UPDATE pycharter.schemas
        SET id_new = gen_random_uuid(),
            data_contract_id_new = dc.id_new
        FROM pycharter.data_contracts dc
        WHERE schemas.data_contract_id = dc.id
    """
    )

    # Update data_contracts to reference schemas
    op.execute(
        """
        UPDATE pycharter.data_contracts
        SET schema_id_new = s.id_new
        FROM pycharter.schemas s
        WHERE data_contracts.schema_id = s.id
    """
    )

    # Metadata records (references data_contracts)
    op.add_column(
        "metadata_records",
        sa.Column("id_new", postgresql.UUID(as_uuid=True), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "metadata_records",
        sa.Column("data_contract_id_new", postgresql.UUID(as_uuid=True), nullable=True),
        schema="pycharter",
    )
    op.execute(
        """
        UPDATE pycharter.metadata_records
        SET id_new = gen_random_uuid(),
            data_contract_id_new = dc.id_new
        FROM pycharter.data_contracts dc
        WHERE metadata_records.data_contract_id = dc.id
    """
    )

    # Update data_contracts to reference metadata_records
    op.execute(
        """
        UPDATE pycharter.data_contracts
        SET metadata_record_id_new = mr.id_new
        FROM pycharter.metadata_records mr
        WHERE data_contracts.metadata_record_id = mr.id
    """
    )

    # Coercion rules (references data_contracts and schemas)
    op.add_column(
        "coercion_rules",
        sa.Column("id_new", postgresql.UUID(as_uuid=True), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "coercion_rules",
        sa.Column("data_contract_id_new", postgresql.UUID(as_uuid=True), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "coercion_rules",
        sa.Column("schema_id_new", postgresql.UUID(as_uuid=True), nullable=True),
        schema="pycharter",
    )
    # Update coercion_rules - first set id and data_contract_id
    op.execute(
        """
        UPDATE pycharter.coercion_rules
        SET id_new = gen_random_uuid(),
            data_contract_id_new = dc.id_new
        FROM pycharter.data_contracts dc
        WHERE coercion_rules.data_contract_id = dc.id
    """
    )
    # Then update schema_id separately
    op.execute(
        """
        UPDATE pycharter.coercion_rules
        SET schema_id_new = s.id_new
        FROM pycharter.schemas s
        WHERE coercion_rules.schema_id = s.id
    """
    )

    # Update data_contracts to reference coercion_rules
    op.execute(
        """
        UPDATE pycharter.data_contracts
        SET coercion_rules_id_new = cr.id_new
        FROM pycharter.coercion_rules cr
        WHERE data_contracts.coercion_rules_id = cr.id
    """
    )

    # Validation rules (references data_contracts and schemas)
    op.add_column(
        "validation_rules",
        sa.Column("id_new", postgresql.UUID(as_uuid=True), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "validation_rules",
        sa.Column("data_contract_id_new", postgresql.UUID(as_uuid=True), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "validation_rules",
        sa.Column("schema_id_new", postgresql.UUID(as_uuid=True), nullable=True),
        schema="pycharter",
    )
    # Update validation_rules - first set id and data_contract_id
    op.execute(
        """
        UPDATE pycharter.validation_rules
        SET id_new = gen_random_uuid(),
            data_contract_id_new = dc.id_new
        FROM pycharter.data_contracts dc
        WHERE validation_rules.data_contract_id = dc.id
    """
    )
    # Then update schema_id separately
    op.execute(
        """
        UPDATE pycharter.validation_rules
        SET schema_id_new = s.id_new
        FROM pycharter.schemas s
        WHERE validation_rules.schema_id = s.id
    """
    )

    # Update data_contracts to reference validation_rules
    op.execute(
        """
        UPDATE pycharter.data_contracts
        SET validation_rules_id_new = vr.id_new
        FROM pycharter.validation_rules vr
        WHERE data_contracts.validation_rules_id = vr.id
    """
    )

    # Join tables - metadata_record_system_pulls
    op.add_column(
        "metadata_record_system_pulls",
        sa.Column("id_new", postgresql.UUID(as_uuid=True), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "metadata_record_system_pulls",
        sa.Column(
            "metadata_record_id_new", postgresql.UUID(as_uuid=True), nullable=True
        ),
        schema="pycharter",
    )
    op.add_column(
        "metadata_record_system_pulls",
        sa.Column("system_id_new", postgresql.UUID(as_uuid=True), nullable=True),
        schema="pycharter",
    )
    op.execute(
        """
        UPDATE pycharter.metadata_record_system_pulls
        SET id_new = gen_random_uuid(),
            metadata_record_id_new = mr.id_new,
            system_id_new = s.id_new
        FROM pycharter.metadata_records mr, pycharter.systems s
        WHERE metadata_record_system_pulls.metadata_record_id = mr.id 
        AND metadata_record_system_pulls.system_id = s.id
    """
    )

    # Join tables - metadata_record_system_pushes
    op.add_column(
        "metadata_record_system_pushes",
        sa.Column("id_new", postgresql.UUID(as_uuid=True), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "metadata_record_system_pushes",
        sa.Column(
            "metadata_record_id_new", postgresql.UUID(as_uuid=True), nullable=True
        ),
        schema="pycharter",
    )
    op.add_column(
        "metadata_record_system_pushes",
        sa.Column("system_id_new", postgresql.UUID(as_uuid=True), nullable=True),
        schema="pycharter",
    )
    op.execute(
        """
        UPDATE pycharter.metadata_record_system_pushes
        SET id_new = gen_random_uuid(),
            metadata_record_id_new = mr.id_new,
            system_id_new = s.id_new
        FROM pycharter.metadata_records mr, pycharter.systems s
        WHERE metadata_record_system_pushes.metadata_record_id = mr.id 
        AND metadata_record_system_pushes.system_id = s.id
    """
    )

    # Join tables - metadata_record_system_sources
    op.add_column(
        "metadata_record_system_sources",
        sa.Column("id_new", postgresql.UUID(as_uuid=True), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "metadata_record_system_sources",
        sa.Column(
            "metadata_record_id_new", postgresql.UUID(as_uuid=True), nullable=True
        ),
        schema="pycharter",
    )
    op.add_column(
        "metadata_record_system_sources",
        sa.Column("system_id_new", postgresql.UUID(as_uuid=True), nullable=True),
        schema="pycharter",
    )
    op.execute(
        """
        UPDATE pycharter.metadata_record_system_sources
        SET id_new = gen_random_uuid(),
            metadata_record_id_new = mr.id_new,
            system_id_new = s.id_new
        FROM pycharter.metadata_records mr, pycharter.systems s
        WHERE metadata_record_system_sources.metadata_record_id = mr.id 
        AND metadata_record_system_sources.system_id = s.id
    """
    )

    # Join tables - metadata_record_domains
    op.add_column(
        "metadata_record_domains",
        sa.Column("id_new", postgresql.UUID(as_uuid=True), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "metadata_record_domains",
        sa.Column(
            "metadata_record_id_new", postgresql.UUID(as_uuid=True), nullable=True
        ),
        schema="pycharter",
    )
    op.add_column(
        "metadata_record_domains",
        sa.Column("domain_id_new", postgresql.UUID(as_uuid=True), nullable=True),
        schema="pycharter",
    )
    op.execute(
        """
        UPDATE pycharter.metadata_record_domains
        SET id_new = gen_random_uuid(),
            metadata_record_id_new = mr.id_new,
            domain_id_new = d.id_new
        FROM pycharter.metadata_records mr, pycharter.domains d
        WHERE metadata_record_domains.metadata_record_id = mr.id 
        AND metadata_record_domains.domain_id = d.id
    """
    )

    # Step 2: Drop all foreign key constraints BEFORE dropping primary keys
    # Get constraint names dynamically to avoid errors
    conn = op.get_bind()

    # Drop foreign keys from join tables first
    for join_table in [
        "metadata_record_system_pulls",
        "metadata_record_system_pushes",
        "metadata_record_system_sources",
        "metadata_record_domains",
    ]:
        result = conn.execute(
            sa.text(
                f"""
            SELECT constraint_name 
            FROM information_schema.table_constraints 
            WHERE table_schema = 'pycharter' 
            AND table_name = '{join_table}' 
            AND constraint_type = 'FOREIGN KEY'
        """
            )
        )
        for row in result:
            try:
                op.drop_constraint(
                    row[0], join_table, schema="pycharter", type_="foreignkey"
                )
            except Exception:
                pass  # Constraint might not exist

    # Drop foreign keys from main tables - must drop ALL before dropping primary keys
    # Get all foreign keys dynamically
    for table_name in [
        "schemas",
        "metadata_records",
        "coercion_rules",
        "validation_rules",
        "data_contracts",
    ]:
        result = conn.execute(
            sa.text(
                f"""
            SELECT constraint_name 
            FROM information_schema.table_constraints 
            WHERE table_schema = 'pycharter' 
            AND table_name = '{table_name}' 
            AND constraint_type = 'FOREIGN KEY'
        """
            )
        )
        for row in result:
            try:
                op.drop_constraint(
                    row[0], table_name, schema="pycharter", type_="foreignkey"
                )
            except Exception:
                pass

    # Step 3: Drop old integer columns and rename UUID columns
    # Make UUID columns NOT NULL first
    op.alter_column("systems", "id_new", nullable=False, schema="pycharter")
    op.alter_column("domains", "id_new", nullable=False, schema="pycharter")
    op.alter_column("data_contracts", "id_new", nullable=False, schema="pycharter")
    op.alter_column("schemas", "id_new", nullable=False, schema="pycharter")
    op.alter_column(
        "schemas", "data_contract_id_new", nullable=False, schema="pycharter"
    )
    op.alter_column("metadata_records", "id_new", nullable=False, schema="pycharter")
    op.alter_column(
        "metadata_records", "data_contract_id_new", nullable=False, schema="pycharter"
    )
    op.alter_column("coercion_rules", "id_new", nullable=False, schema="pycharter")
    op.alter_column(
        "coercion_rules", "data_contract_id_new", nullable=False, schema="pycharter"
    )
    op.alter_column("validation_rules", "id_new", nullable=False, schema="pycharter")
    op.alter_column(
        "validation_rules", "data_contract_id_new", nullable=False, schema="pycharter"
    )

    for join_table in [
        "metadata_record_system_pulls",
        "metadata_record_system_pushes",
        "metadata_record_system_sources",
        "metadata_record_domains",
    ]:
        op.alter_column(join_table, "id_new", nullable=False, schema="pycharter")
        op.alter_column(
            join_table, "metadata_record_id_new", nullable=False, schema="pycharter"
        )
        if "system" in join_table:
            op.alter_column(
                join_table, "system_id_new", nullable=False, schema="pycharter"
            )
        elif "domain" in join_table:
            op.alter_column(
                join_table, "domain_id_new", nullable=False, schema="pycharter"
            )

    # Drop primary key constraints before dropping columns - get names dynamically
    tables_to_drop_pk = [
        "systems",
        "domains",
        "data_contracts",
        "schemas",
        "metadata_records",
        "coercion_rules",
        "validation_rules",
        "metadata_record_system_pulls",
        "metadata_record_system_pushes",
        "metadata_record_system_sources",
        "metadata_record_domains",
    ]

    for table_name in tables_to_drop_pk:
        result = conn.execute(
            sa.text(
                f"""
            SELECT constraint_name 
            FROM information_schema.table_constraints 
            WHERE table_schema = 'pycharter' 
            AND table_name = '{table_name}' 
            AND constraint_type = 'PRIMARY KEY'
        """
            )
        )
        for row in result:
            try:
                op.drop_constraint(
                    row[0], table_name, schema="pycharter", type_="primary"
                )
            except Exception:
                pass

    # Drop old integer columns
    op.drop_column("systems", "id", schema="pycharter")
    op.drop_column("domains", "id", schema="pycharter")
    op.drop_column("data_contracts", "id", schema="pycharter")
    op.drop_column("data_contracts", "schema_id", schema="pycharter")
    op.drop_column("data_contracts", "coercion_rules_id", schema="pycharter")
    op.drop_column("data_contracts", "validation_rules_id", schema="pycharter")
    op.drop_column("data_contracts", "metadata_record_id", schema="pycharter")
    # Drop domain_id if it exists
    try:
        op.drop_column("data_contracts", "domain_id", schema="pycharter")
    except Exception:
        pass  # domain_id may not exist
    op.drop_column("schemas", "id", schema="pycharter")
    op.drop_column("schemas", "data_contract_id", schema="pycharter")
    op.drop_column("metadata_records", "id", schema="pycharter")
    op.drop_column("metadata_records", "data_contract_id", schema="pycharter")
    op.drop_column("coercion_rules", "id", schema="pycharter")
    op.drop_column("coercion_rules", "data_contract_id", schema="pycharter")
    op.drop_column("coercion_rules", "schema_id", schema="pycharter")
    op.drop_column("validation_rules", "id", schema="pycharter")
    op.drop_column("validation_rules", "data_contract_id", schema="pycharter")
    op.drop_column("validation_rules", "schema_id", schema="pycharter")

    for join_table in [
        "metadata_record_system_pulls",
        "metadata_record_system_pushes",
        "metadata_record_system_sources",
        "metadata_record_domains",
    ]:
        op.drop_column(join_table, "id", schema="pycharter")
        op.drop_column(join_table, "metadata_record_id", schema="pycharter")
        if "system" in join_table:
            op.drop_column(join_table, "system_id", schema="pycharter")
        elif "domain" in join_table:
            op.drop_column(join_table, "domain_id", schema="pycharter")

    # Rename UUID columns to final names
    op.alter_column("systems", "id_new", new_column_name="id", schema="pycharter")
    op.alter_column("domains", "id_new", new_column_name="id", schema="pycharter")
    op.alter_column(
        "data_contracts", "id_new", new_column_name="id", schema="pycharter"
    )
    op.alter_column(
        "data_contracts",
        "schema_id_new",
        new_column_name="schema_id",
        schema="pycharter",
    )
    op.alter_column(
        "data_contracts",
        "coercion_rules_id_new",
        new_column_name="coercion_rules_id",
        schema="pycharter",
    )
    op.alter_column(
        "data_contracts",
        "validation_rules_id_new",
        new_column_name="validation_rules_id",
        schema="pycharter",
    )
    op.alter_column(
        "data_contracts",
        "metadata_record_id_new",
        new_column_name="metadata_record_id",
        schema="pycharter",
    )
    # Rename domain_id_new if it exists
    try:
        op.alter_column(
            "data_contracts",
            "domain_id_new",
            new_column_name="domain_id",
            schema="pycharter",
        )
    except Exception:
        pass  # domain_id_new may not exist
    op.alter_column("schemas", "id_new", new_column_name="id", schema="pycharter")
    op.alter_column(
        "schemas",
        "data_contract_id_new",
        new_column_name="data_contract_id",
        schema="pycharter",
    )
    op.alter_column(
        "metadata_records", "id_new", new_column_name="id", schema="pycharter"
    )
    op.alter_column(
        "metadata_records",
        "data_contract_id_new",
        new_column_name="data_contract_id",
        schema="pycharter",
    )
    op.alter_column(
        "coercion_rules", "id_new", new_column_name="id", schema="pycharter"
    )
    op.alter_column(
        "coercion_rules",
        "data_contract_id_new",
        new_column_name="data_contract_id",
        schema="pycharter",
    )
    op.alter_column(
        "coercion_rules",
        "schema_id_new",
        new_column_name="schema_id",
        schema="pycharter",
    )
    op.alter_column(
        "validation_rules", "id_new", new_column_name="id", schema="pycharter"
    )
    op.alter_column(
        "validation_rules",
        "data_contract_id_new",
        new_column_name="data_contract_id",
        schema="pycharter",
    )
    op.alter_column(
        "validation_rules",
        "schema_id_new",
        new_column_name="schema_id",
        schema="pycharter",
    )

    for join_table in [
        "metadata_record_system_pulls",
        "metadata_record_system_pushes",
        "metadata_record_system_sources",
        "metadata_record_domains",
    ]:
        op.alter_column(join_table, "id_new", new_column_name="id", schema="pycharter")
        op.alter_column(
            join_table,
            "metadata_record_id_new",
            new_column_name="metadata_record_id",
            schema="pycharter",
        )
        if "system" in join_table:
            op.alter_column(
                join_table,
                "system_id_new",
                new_column_name="system_id",
                schema="pycharter",
            )
        elif "domain" in join_table:
            op.alter_column(
                join_table,
                "domain_id_new",
                new_column_name="domain_id",
                schema="pycharter",
            )

    # Step 4: Recreate primary key constraints
    op.create_primary_key("systems_pkey", "systems", ["id"], schema="pycharter")
    op.create_primary_key("domains_pkey", "domains", ["id"], schema="pycharter")
    op.create_primary_key(
        "data_contracts_pkey", "data_contracts", ["id"], schema="pycharter"
    )
    op.create_primary_key("schemas_pkey", "schemas", ["id"], schema="pycharter")
    op.create_primary_key(
        "metadata_records_pkey", "metadata_records", ["id"], schema="pycharter"
    )
    op.create_primary_key(
        "coercion_rules_pkey", "coercion_rules", ["id"], schema="pycharter"
    )
    op.create_primary_key(
        "validation_rules_pkey", "validation_rules", ["id"], schema="pycharter"
    )

    for join_table in [
        "metadata_record_system_pulls",
        "metadata_record_system_pushes",
        "metadata_record_system_sources",
        "metadata_record_domains",
    ]:
        try:
            op.create_primary_key(
                f"{join_table}_pkey", join_table, ["id"], schema="pycharter"
            )
        except Exception:
            pass

    # Step 5: Recreate foreign key constraints
    op.create_foreign_key(
        "schemas_data_contract_id_fkey",
        "schemas",
        "data_contracts",
        ["data_contract_id"],
        ["id"],
        source_schema="pycharter",
        referent_schema="pycharter",
        ondelete="CASCADE",
    )
    op.create_foreign_key(
        "metadata_records_data_contract_id_fkey",
        "metadata_records",
        "data_contracts",
        ["data_contract_id"],
        ["id"],
        source_schema="pycharter",
        referent_schema="pycharter",
        ondelete="CASCADE",
    )
    op.create_foreign_key(
        "coercion_rules_data_contract_id_fkey",
        "coercion_rules",
        "data_contracts",
        ["data_contract_id"],
        ["id"],
        source_schema="pycharter",
        referent_schema="pycharter",
        ondelete="CASCADE",
    )
    op.create_foreign_key(
        "coercion_rules_schema_id_fkey",
        "coercion_rules",
        "schemas",
        ["schema_id"],
        ["id"],
        source_schema="pycharter",
        referent_schema="pycharter",
        ondelete="CASCADE",
    )
    op.create_foreign_key(
        "validation_rules_data_contract_id_fkey",
        "validation_rules",
        "data_contracts",
        ["data_contract_id"],
        ["id"],
        source_schema="pycharter",
        referent_schema="pycharter",
        ondelete="CASCADE",
    )
    op.create_foreign_key(
        "validation_rules_schema_id_fkey",
        "validation_rules",
        "schemas",
        ["schema_id"],
        ["id"],
        source_schema="pycharter",
        referent_schema="pycharter",
        ondelete="CASCADE",
    )
    op.create_foreign_key(
        "data_contracts_schema_id_fkey",
        "data_contracts",
        "schemas",
        ["schema_id"],
        ["id"],
        source_schema="pycharter",
        referent_schema="pycharter",
        ondelete="CASCADE",
    )
    op.create_foreign_key(
        "data_contracts_coercion_rules_id_fkey",
        "data_contracts",
        "coercion_rules",
        ["coercion_rules_id"],
        ["id"],
        source_schema="pycharter",
        referent_schema="pycharter",
        ondelete="SET NULL",
    )
    op.create_foreign_key(
        "data_contracts_validation_rules_id_fkey",
        "data_contracts",
        "validation_rules",
        ["validation_rules_id"],
        ["id"],
        source_schema="pycharter",
        referent_schema="pycharter",
        ondelete="SET NULL",
    )
    op.create_foreign_key(
        "data_contracts_metadata_record_id_fkey",
        "data_contracts",
        "metadata_records",
        ["metadata_record_id"],
        ["id"],
        source_schema="pycharter",
        referent_schema="pycharter",
        ondelete="SET NULL",
    )

    # Join table foreign keys
    op.create_foreign_key(
        "metadata_record_system_pulls_metadata_record_id_fkey",
        "metadata_record_system_pulls",
        "metadata_records",
        ["metadata_record_id"],
        ["id"],
        source_schema="pycharter",
        referent_schema="pycharter",
        ondelete="CASCADE",
    )
    op.create_foreign_key(
        "metadata_record_system_pulls_system_id_fkey",
        "metadata_record_system_pulls",
        "systems",
        ["system_id"],
        ["id"],
        source_schema="pycharter",
        referent_schema="pycharter",
        ondelete="CASCADE",
    )

    op.create_foreign_key(
        "metadata_record_system_pushes_metadata_record_id_fkey",
        "metadata_record_system_pushes",
        "metadata_records",
        ["metadata_record_id"],
        ["id"],
        source_schema="pycharter",
        referent_schema="pycharter",
        ondelete="CASCADE",
    )
    op.create_foreign_key(
        "metadata_record_system_pushes_system_id_fkey",
        "metadata_record_system_pushes",
        "systems",
        ["system_id"],
        ["id"],
        source_schema="pycharter",
        referent_schema="pycharter",
        ondelete="CASCADE",
    )

    op.create_foreign_key(
        "metadata_record_system_sources_metadata_record_id_fkey",
        "metadata_record_system_sources",
        "metadata_records",
        ["metadata_record_id"],
        ["id"],
        source_schema="pycharter",
        referent_schema="pycharter",
        ondelete="CASCADE",
    )
    op.create_foreign_key(
        "metadata_record_system_sources_system_id_fkey",
        "metadata_record_system_sources",
        "systems",
        ["system_id"],
        ["id"],
        source_schema="pycharter",
        referent_schema="pycharter",
        ondelete="CASCADE",
    )

    op.create_foreign_key(
        "metadata_record_domains_metadata_record_id_fkey",
        "metadata_record_domains",
        "metadata_records",
        ["metadata_record_id"],
        ["id"],
        source_schema="pycharter",
        referent_schema="pycharter",
        ondelete="CASCADE",
    )
    op.create_foreign_key(
        "metadata_record_domains_domain_id_fkey",
        "metadata_record_domains",
        "domains",
        ["domain_id"],
        ["id"],
        source_schema="pycharter",
        referent_schema="pycharter",
        ondelete="CASCADE",
    )


def downgrade() -> None:
    # This is a complex downgrade - would need to convert UUIDs back to integers
    # For now, we'll leave it as a placeholder
    # In production, you'd want to implement a proper downgrade
    raise NotImplementedError("Downgrade from UUID to Integer is not implemented")
