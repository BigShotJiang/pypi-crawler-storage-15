"""Remove ownership fields from owners, add app_id to systems

Revision ID: 20251201122000
Revises: 2010ee8b5c4b
Create Date: 2025-12-01 12:20:00.000000

This migration:
1. Removes business_owners, bu_sme, and domains columns from owners table
   (these fields are now stored in metadata_records table)
2. Adds app_id column to systems table for application identification
"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = "20251201122000"
down_revision: Union[str, None] = "2010ee8b5c4b"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Remove business_owners, bu_sme, and domains columns from owners table
    # These fields are now stored in metadata_records table
    op.drop_column("owners", "business_owners", schema="pycharter")
    op.drop_column("owners", "bu_sme", schema="pycharter")
    op.drop_column("owners", "domains", schema="pycharter")

    # Add app_id column to systems table
    op.add_column(
        "systems",
        sa.Column("app_id", sa.String(length=255), nullable=True),
        schema="pycharter",
    )


def downgrade() -> None:
    # Add back the removed columns to owners table
    op.add_column(
        "owners",
        sa.Column(
            "business_owners", postgresql.JSON(astext_type=sa.Text()), nullable=True
        ),
        schema="pycharter",
    )
    op.add_column(
        "owners",
        sa.Column("bu_sme", postgresql.JSON(astext_type=sa.Text()), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "owners",
        sa.Column("domains", postgresql.JSON(astext_type=sa.Text()), nullable=True),
        schema="pycharter",
    )

    # Remove app_id column from systems table
    op.drop_column("systems", "app_id", schema="pycharter")
