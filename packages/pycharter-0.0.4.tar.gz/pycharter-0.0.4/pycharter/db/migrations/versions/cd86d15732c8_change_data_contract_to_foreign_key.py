"""Change data_contract from name to foreign key

Revision ID: cd86d15732c8
Revises: fdd1be5d59c6
Create Date: 2025-11-28 12:00:00.000000

This migration changes the relationship from components to data_contracts
from using the contract name (String) to using a foreign key (ID).

Changes:
- Add data_contract_id columns to schemas, coercion_rules, validation_rules, metadata_records
- Populate data_contract_id from existing data_contract names
- Add foreign key constraints
- Update unique constraints
- Keep data_contract column for backward compatibility (can be dropped later)
"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision: str = "cd86d15732c8"
down_revision: Union[str, None] = "fdd1be5d59c6"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """
    Upgrade: Change data_contract from name to foreign key.

    Steps:
    1. Add data_contract_id columns (nullable initially)
    2. Populate data_contract_id from data_contract names
    3. Make data_contract_id NOT NULL
    4. Add foreign key constraints
    5. Update unique constraints
    6. Keep data_contract column for backward compatibility
    """

    # ============================================================================
    # Step 1: Add data_contract_id columns to all component tables
    # ============================================================================

    # Add to schemas
    op.add_column(
        "schemas",
        sa.Column("data_contract_id", sa.Integer(), nullable=True),
        schema="pycharter",
    )

    # Add to coercion_rules
    op.add_column(
        "coercion_rules",
        sa.Column("data_contract_id", sa.Integer(), nullable=True),
        schema="pycharter",
    )

    # Add to validation_rules
    op.add_column(
        "validation_rules",
        sa.Column("data_contract_id", sa.Integer(), nullable=True),
        schema="pycharter",
    )

    # Add to metadata_records
    op.add_column(
        "metadata_records",
        sa.Column("data_contract_id", sa.Integer(), nullable=True),
        schema="pycharter",
    )

    # ============================================================================
    # Step 2: Populate data_contract_id from data_contract names
    # ============================================================================

    # Update schemas
    op.execute(
        """
        UPDATE pycharter.schemas s
        SET data_contract_id = dc.id
        FROM pycharter.data_contracts dc
        WHERE s.data_contract = dc.name AND s.version = dc.version
    """
    )

    # Update coercion_rules
    op.execute(
        """
        UPDATE pycharter.coercion_rules cr
        SET data_contract_id = dc.id
        FROM pycharter.data_contracts dc
        WHERE cr.data_contract = dc.name AND cr.version = dc.version
    """
    )

    # Update validation_rules
    op.execute(
        """
        UPDATE pycharter.validation_rules vr
        SET data_contract_id = dc.id
        FROM pycharter.data_contracts dc
        WHERE vr.data_contract = dc.name AND vr.version = dc.version
    """
    )

    # Update metadata_records
    op.execute(
        """
        UPDATE pycharter.metadata_records mr
        SET data_contract_id = dc.id
        FROM pycharter.data_contracts dc
        WHERE mr.data_contract = dc.name AND mr.version = dc.version
    """
    )

    # ============================================================================
    # Step 3: Make required columns nullable in data_contracts (if not already)
    # ============================================================================
    # This is needed because we'll be creating data_contracts without these values
    # The current model allows these to be nullable, so they should be optional

    op.execute(
        """
        DO $$ 
        BEGIN
            -- Make schema_id nullable
            IF EXISTS (
                SELECT 1 FROM information_schema.columns 
                WHERE table_schema = 'pycharter' 
                AND table_name = 'data_contracts' 
                AND column_name = 'schema_id'
                AND is_nullable = 'NO'
            ) THEN
                ALTER TABLE pycharter.data_contracts ALTER COLUMN schema_id DROP NOT NULL;
            END IF;
            
            -- Make coercion_rules_id nullable
            IF EXISTS (
                SELECT 1 FROM information_schema.columns 
                WHERE table_schema = 'pycharter' 
                AND table_name = 'data_contracts' 
                AND column_name = 'coercion_rules_id'
                AND is_nullable = 'NO'
            ) THEN
                ALTER TABLE pycharter.data_contracts ALTER COLUMN coercion_rules_id DROP NOT NULL;
            END IF;
            
            -- Make validation_rules_id nullable
            IF EXISTS (
                SELECT 1 FROM information_schema.columns 
                WHERE table_schema = 'pycharter' 
                AND table_name = 'data_contracts' 
                AND column_name = 'validation_rules_id'
                AND is_nullable = 'NO'
            ) THEN
                ALTER TABLE pycharter.data_contracts ALTER COLUMN validation_rules_id DROP NOT NULL;
            END IF;
            
            -- Make metadata_record_id nullable
            IF EXISTS (
                SELECT 1 FROM information_schema.columns 
                WHERE table_schema = 'pycharter' 
                AND table_name = 'data_contracts' 
                AND column_name = 'metadata_record_id'
                AND is_nullable = 'NO'
            ) THEN
                ALTER TABLE pycharter.data_contracts ALTER COLUMN metadata_record_id DROP NOT NULL;
            END IF;
            
            -- Make data_feed_id nullable (if column exists)
            IF EXISTS (
                SELECT 1 FROM information_schema.columns 
                WHERE table_schema = 'pycharter' 
                AND table_name = 'data_contracts' 
                AND column_name = 'data_feed_id'
                AND is_nullable = 'NO'
            ) THEN
                -- First drop foreign key constraint if it exists
                IF EXISTS (
                    SELECT 1 FROM pg_constraint 
                    WHERE conname = 'data_contracts_data_feed_id_fkey' 
                    AND conrelid = 'pycharter.data_contracts'::regclass
                ) THEN
                    ALTER TABLE pycharter.data_contracts DROP CONSTRAINT data_contracts_data_feed_id_fkey;
                END IF;
                ALTER TABLE pycharter.data_contracts ALTER COLUMN data_feed_id DROP NOT NULL;
            END IF;
            
            -- Make is_data_feed nullable (if column exists)
            IF EXISTS (
                SELECT 1 FROM information_schema.columns 
                WHERE table_schema = 'pycharter' 
                AND table_name = 'data_contracts' 
                AND column_name = 'is_data_feed'
                AND is_nullable = 'NO'
            ) THEN
                ALTER TABLE pycharter.data_contracts ALTER COLUMN is_data_feed DROP NOT NULL;
            END IF;
        END $$;
    """
    )

    # ============================================================================
    # Step 4: Handle orphaned records (records without matching data_contract)
    # ============================================================================

    # For orphaned records, we'll create data_contract records automatically
    # This handles the case where components exist but data_contracts don't

    # Create data_contracts for orphaned schemas
    op.execute(
        """
        INSERT INTO pycharter.data_contracts (
            name, version, status, description, schema_id, 
            data_feed_id, is_data_feed,
            created_at, updated_at
        )
        SELECT DISTINCT 
            s.data_contract,
            s.version,
            'active' as status,
            'Auto-created from orphaned schema' as description,
            NULL::INTEGER as schema_id,
            NULL::INTEGER as data_feed_id,
            NULL::BOOLEAN as is_data_feed,
            NOW() as created_at,
            NOW() as updated_at
        FROM pycharter.schemas s
        WHERE s.data_contract_id IS NULL
        AND NOT EXISTS (
            SELECT 1 FROM pycharter.data_contracts dc
            WHERE dc.name = s.data_contract AND dc.version = s.version
        )
        ON CONFLICT (name, version) DO NOTHING;
    """
    )

    # Now update schemas again with the newly created data_contracts
    op.execute(
        """
        UPDATE pycharter.schemas s
        SET data_contract_id = dc.id
        FROM pycharter.data_contracts dc
        WHERE s.data_contract = dc.name AND s.version = dc.version
        AND s.data_contract_id IS NULL;
    """
    )

    # Create data_contracts for orphaned coercion_rules
    op.execute(
        """
        INSERT INTO pycharter.data_contracts (
            name, version, status, description, schema_id,
            data_feed_id, is_data_feed,
            created_at, updated_at
        )
        SELECT DISTINCT 
            cr.data_contract,
            cr.version,
            'active' as status,
            'Auto-created from orphaned coercion_rules' as description,
            NULL::INTEGER as schema_id,
            NULL::INTEGER as data_feed_id,
            NULL::BOOLEAN as is_data_feed,
            NOW() as created_at,
            NOW() as updated_at
        FROM pycharter.coercion_rules cr
        WHERE cr.data_contract_id IS NULL
        AND NOT EXISTS (
            SELECT 1 FROM pycharter.data_contracts dc
            WHERE dc.name = cr.data_contract AND dc.version = cr.version
        )
        ON CONFLICT (name, version) DO NOTHING;
    """
    )

    # Update coercion_rules
    op.execute(
        """
        UPDATE pycharter.coercion_rules cr
        SET data_contract_id = dc.id
        FROM pycharter.data_contracts dc
        WHERE cr.data_contract = dc.name AND cr.version = dc.version
        AND cr.data_contract_id IS NULL;
    """
    )

    # Create data_contracts for orphaned validation_rules
    op.execute(
        """
        INSERT INTO pycharter.data_contracts (
            name, version, status, description, schema_id,
            data_feed_id, is_data_feed,
            created_at, updated_at
        )
        SELECT DISTINCT 
            vr.data_contract,
            vr.version,
            'active' as status,
            'Auto-created from orphaned validation_rules' as description,
            NULL::INTEGER as schema_id,
            NULL::INTEGER as data_feed_id,
            NULL::BOOLEAN as is_data_feed,
            NOW() as created_at,
            NOW() as updated_at
        FROM pycharter.validation_rules vr
        WHERE vr.data_contract_id IS NULL
        AND NOT EXISTS (
            SELECT 1 FROM pycharter.data_contracts dc
            WHERE dc.name = vr.data_contract AND vr.version = dc.version
        )
        ON CONFLICT (name, version) DO NOTHING;
    """
    )

    # Update validation_rules
    op.execute(
        """
        UPDATE pycharter.validation_rules vr
        SET data_contract_id = dc.id
        FROM pycharter.data_contracts dc
        WHERE vr.data_contract = dc.name AND vr.version = dc.version
        AND vr.data_contract_id IS NULL;
    """
    )

    # Create data_contracts for orphaned metadata_records
    op.execute(
        """
        INSERT INTO pycharter.data_contracts (
            name, version, status, description, schema_id,
            data_feed_id, is_data_feed,
            created_at, updated_at
        )
        SELECT DISTINCT 
            mr.data_contract,
            mr.version,
            COALESCE(mr.status, 'active') as status,
            COALESCE(mr.description, 'Auto-created from orphaned metadata_record') as description,
            NULL::INTEGER as schema_id,
            NULL::INTEGER as data_feed_id,
            NULL::BOOLEAN as is_data_feed,
            NOW() as created_at,
            NOW() as updated_at
        FROM pycharter.metadata_records mr
        WHERE mr.data_contract_id IS NULL
        AND NOT EXISTS (
            SELECT 1 FROM pycharter.data_contracts dc
            WHERE dc.name = mr.data_contract AND dc.version = mr.version
        )
        ON CONFLICT (name, version) DO NOTHING;
    """
    )

    # Update metadata_records
    op.execute(
        """
        UPDATE pycharter.metadata_records mr
        SET data_contract_id = dc.id
        FROM pycharter.data_contracts dc
        WHERE mr.data_contract = dc.name AND mr.version = dc.version
        AND mr.data_contract_id IS NULL;
    """
    )

    # Now verify all records have data_contract_id (should not fail, but good to check)
    op.execute(
        """
        DO $$
        DECLARE
            orphaned_count INTEGER;
        BEGIN
            SELECT COUNT(*) INTO orphaned_count
            FROM (
                SELECT 1 FROM pycharter.schemas WHERE data_contract_id IS NULL
                UNION ALL
                SELECT 1 FROM pycharter.coercion_rules WHERE data_contract_id IS NULL
                UNION ALL
                SELECT 1 FROM pycharter.validation_rules WHERE data_contract_id IS NULL
                UNION ALL
                SELECT 1 FROM pycharter.metadata_records WHERE data_contract_id IS NULL
            ) AS orphaned;
            
            IF orphaned_count > 0 THEN
                RAISE EXCEPTION 'Still have % orphaned records after auto-creation. Migration cannot proceed.', orphaned_count;
            END IF;
        END $$;
    """
    )

    # ============================================================================
    # Step 5: Make data_contract_id NOT NULL
    # ============================================================================

    op.alter_column("schemas", "data_contract_id", nullable=False, schema="pycharter")
    op.alter_column(
        "coercion_rules", "data_contract_id", nullable=False, schema="pycharter"
    )
    op.alter_column(
        "validation_rules", "data_contract_id", nullable=False, schema="pycharter"
    )
    op.alter_column(
        "metadata_records", "data_contract_id", nullable=False, schema="pycharter"
    )

    # ============================================================================
    # Step 6: Drop old unique constraints and create new ones
    # ============================================================================

    # Drop old unique constraints
    op.drop_constraint(
        "uq_schemas_contract_version", "schemas", schema="pycharter", type_="unique"
    )
    op.drop_constraint(
        "uq_coercion_rules_contract_version",
        "coercion_rules",
        schema="pycharter",
        type_="unique",
    )
    op.drop_constraint(
        "uq_validation_rules_contract_version",
        "validation_rules",
        schema="pycharter",
        type_="unique",
    )
    op.drop_constraint(
        "uq_metadata_records_contract_version",
        "metadata_records",
        schema="pycharter",
        type_="unique",
    )

    # Create new unique constraints with data_contract_id
    op.create_unique_constraint(
        "uq_schemas_contract_version",
        "schemas",
        ["data_contract_id", "version"],
        schema="pycharter",
    )
    op.create_unique_constraint(
        "uq_coercion_rules_contract_version",
        "coercion_rules",
        ["data_contract_id", "version"],
        schema="pycharter",
    )
    op.create_unique_constraint(
        "uq_validation_rules_contract_version",
        "validation_rules",
        ["data_contract_id", "version"],
        schema="pycharter",
    )
    op.create_unique_constraint(
        "uq_metadata_records_contract_version",
        "metadata_records",
        ["data_contract_id", "version"],
        schema="pycharter",
    )

    # ============================================================================
    # Step 7: Add foreign key constraints
    # ============================================================================

    op.create_foreign_key(
        "schemas_data_contract_id_fkey",
        "schemas",
        "data_contracts",
        ["data_contract_id"],
        ["id"],
        source_schema="pycharter",
        referent_schema="pycharter",
        ondelete="CASCADE",
    )

    op.create_foreign_key(
        "coercion_rules_data_contract_id_fkey",
        "coercion_rules",
        "data_contracts",
        ["data_contract_id"],
        ["id"],
        source_schema="pycharter",
        referent_schema="pycharter",
        ondelete="CASCADE",
    )

    op.create_foreign_key(
        "validation_rules_data_contract_id_fkey",
        "validation_rules",
        "data_contracts",
        ["data_contract_id"],
        ["id"],
        source_schema="pycharter",
        referent_schema="pycharter",
        ondelete="CASCADE",
    )

    op.create_foreign_key(
        "metadata_records_data_contract_id_fkey",
        "metadata_records",
        "data_contracts",
        ["data_contract_id"],
        ["id"],
        source_schema="pycharter",
        referent_schema="pycharter",
        ondelete="CASCADE",
    )

    # Note: We keep the data_contract column for backward compatibility
    # It can be dropped in a future migration if not needed


def downgrade() -> None:
    """
    Downgrade: Revert from foreign key back to name.

    WARNING: This will lose referential integrity.
    """

    # ============================================================================
    # Step 1: Drop foreign key constraints
    # ============================================================================

    op.drop_constraint(
        "metadata_records_data_contract_id_fkey",
        "metadata_records",
        schema="pycharter",
        type_="foreignkey",
    )
    op.drop_constraint(
        "validation_rules_data_contract_id_fkey",
        "validation_rules",
        schema="pycharter",
        type_="foreignkey",
    )
    op.drop_constraint(
        "coercion_rules_data_contract_id_fkey",
        "coercion_rules",
        schema="pycharter",
        type_="foreignkey",
    )
    op.drop_constraint(
        "schemas_data_contract_id_fkey",
        "schemas",
        schema="pycharter",
        type_="foreignkey",
    )

    # ============================================================================
    # Step 2: Drop new unique constraints and restore old ones
    # ============================================================================

    op.drop_constraint(
        "uq_metadata_records_contract_version",
        "metadata_records",
        schema="pycharter",
        type_="unique",
    )
    op.drop_constraint(
        "uq_validation_rules_contract_version",
        "validation_rules",
        schema="pycharter",
        type_="unique",
    )
    op.drop_constraint(
        "uq_coercion_rules_contract_version",
        "coercion_rules",
        schema="pycharter",
        type_="unique",
    )
    op.drop_constraint(
        "uq_schemas_contract_version", "schemas", schema="pycharter", type_="unique"
    )

    op.create_unique_constraint(
        "uq_metadata_records_contract_version",
        "metadata_records",
        ["data_contract", "version"],
        schema="pycharter",
    )
    op.create_unique_constraint(
        "uq_validation_rules_contract_version",
        "validation_rules",
        ["data_contract", "version"],
        schema="pycharter",
    )
    op.create_unique_constraint(
        "uq_coercion_rules_contract_version",
        "coercion_rules",
        ["data_contract", "version"],
        schema="pycharter",
    )
    op.create_unique_constraint(
        "uq_schemas_contract_version",
        "schemas",
        ["data_contract", "version"],
        schema="pycharter",
    )

    # ============================================================================
    # Step 3: Restore data_contract from data_contract_id
    # ============================================================================

    # Populate data_contract from data_contract_id
    op.execute(
        """
        UPDATE pycharter.schemas s
        SET data_contract = dc.name
        FROM pycharter.data_contracts dc
        WHERE s.data_contract_id = dc.id
    """
    )

    op.execute(
        """
        UPDATE pycharter.coercion_rules cr
        SET data_contract = dc.name
        FROM pycharter.data_contracts dc
        WHERE cr.data_contract_id = dc.id
    """
    )

    op.execute(
        """
        UPDATE pycharter.validation_rules vr
        SET data_contract = dc.name
        FROM pycharter.data_contracts dc
        WHERE vr.data_contract_id = dc.id
    """
    )

    op.execute(
        """
        UPDATE pycharter.metadata_records mr
        SET data_contract = dc.name
        FROM pycharter.data_contracts dc
        WHERE mr.data_contract_id = dc.id
    """
    )

    # ============================================================================
    # Step 4: Drop data_contract_id columns
    # ============================================================================

    op.drop_column("metadata_records", "data_contract_id", schema="pycharter")
    op.drop_column("validation_rules", "data_contract_id", schema="pycharter")
    op.drop_column("coercion_rules", "data_contract_id", schema="pycharter")
    op.drop_column("schemas", "data_contract_id", schema="pycharter")
