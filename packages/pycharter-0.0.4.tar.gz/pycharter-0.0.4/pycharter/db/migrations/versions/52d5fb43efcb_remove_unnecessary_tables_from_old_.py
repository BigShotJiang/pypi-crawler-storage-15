"""Remove unnecessary tables from old migration

Revision ID: 52d5fb43efcb
Revises: 20251201122000
Create Date: 2025-12-02 11:33:33.465996

"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision: str = "52d5fb43efcb"
down_revision: Union[str, None] = "20251201122000"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Drop join tables first (they have foreign keys)
    op.drop_table("data_feed_dependencies", schema="pycharter")
    op.drop_table("data_contract_team_access", schema="pycharter")
    op.drop_table("data_contract_business_owners", schema="pycharter")
    op.drop_table("data_contract_system_sources", schema="pycharter")
    op.drop_table("data_contract_system_pushes", schema="pycharter")
    op.drop_table("data_contract_system_pulls", schema="pycharter")

    # Drop entity tables (they may be referenced by join tables above, but we already dropped those)
    op.drop_table("teams", schema="pycharter")
    op.drop_table("data_feeds", schema="pycharter")
    op.drop_table("business_owners", schema="pycharter")


def downgrade() -> None:
    # Recreate tables in reverse order
    op.create_table(
        "business_owners",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("name", sa.String(length=255), nullable=False),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("contact_email", sa.String(length=255), nullable=True),
        sa.Column("department", sa.String(length=255), nullable=True),
        sa.Column("is_active", sa.String(length=10), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=True,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=True,
        ),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("name"),
        schema="pycharter",
    )
    op.create_table(
        "data_feeds",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("name", sa.String(length=255), nullable=False),
        sa.Column("title", sa.String(length=255), nullable=True),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("feed_type", sa.String(length=50), nullable=True),
        sa.Column("is_active", sa.Boolean(), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=True,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=True,
        ),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("name"),
        schema="pycharter",
    )
    op.create_table(
        "teams",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("name", sa.String(length=255), nullable=False),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("team_type", sa.String(length=50), nullable=True),
        sa.Column("is_active", sa.String(length=10), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=True,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=True,
        ),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("name"),
        schema="pycharter",
    )
    # Note: Join tables would need full definitions in a real downgrade, but simplified here
