"""Rename owner column to name in owners table

Revision ID: 20251205120000
Revises: 20251204151550
Create Date: 2025-12-05 12:00:00.000000

This migration renames the 'owner' column to 'name' in the owners table
to match the SQLAlchemy model definition.
"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision: str = "20251205120000"
down_revision: Union[str, None] = "20251204151550"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """
    Rename 'owner' column to 'name' in owners table.

    This aligns the database schema with the SQLAlchemy model which uses 'name'
    instead of 'owner' for the display name field.
    """
    # Rename the column from 'owner' to 'name'
    op.alter_column("owners", "owner", new_column_name="name", schema="pycharter")


def downgrade() -> None:
    """
    Rename 'name' column back to 'owner' in owners table.
    """
    # Rename the column back from 'name' to 'owner'
    op.alter_column("owners", "name", new_column_name="owner", schema="pycharter")
