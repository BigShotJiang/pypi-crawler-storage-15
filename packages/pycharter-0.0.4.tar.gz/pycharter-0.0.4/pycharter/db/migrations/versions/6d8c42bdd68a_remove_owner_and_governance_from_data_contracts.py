"""Remove owner_id and governance_rules_id from data_contracts

Revision ID: 6d8c42bdd68a
Revises: cd86d15732c8
Create Date: 2025-11-28 14:00:00.000000

This migration removes owner_id and governance_rules_id from data_contracts
because ownership and governance rules are stored within metadata_records,
not as separate foreign keys.

Changes:
- Drop owner_id column from data_contracts
- Drop governance_rules_id column from data_contracts
- Drop foreign key constraints for these columns
"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision: str = "6d8c42bdd68a"
down_revision: Union[str, None] = "cd86d15732c8"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """
    Remove owner_id and governance_rules_id from data_contracts.

    These are now stored in metadata_records:
    - Ownership: metadata_records.business_owners, metadata_records.bu_sme
    - Governance rules: metadata_records.governance_rules
    """

    # Drop foreign key constraints first
    op.execute(
        """
        DO $$ 
        BEGIN
            IF EXISTS (
                SELECT 1 FROM pg_constraint 
                WHERE conname = 'data_contracts_owner_id_fkey' 
                AND conrelid = 'pycharter.data_contracts'::regclass
            ) THEN
                ALTER TABLE pycharter.data_contracts DROP CONSTRAINT data_contracts_owner_id_fkey;
            END IF;
        END $$;
    """
    )

    op.execute(
        """
        DO $$ 
        BEGIN
            IF EXISTS (
                SELECT 1 FROM pg_constraint 
                WHERE conname = 'data_contracts_governance_rules_id_fkey' 
                AND conrelid = 'pycharter.data_contracts'::regclass
            ) THEN
                ALTER TABLE pycharter.data_contracts DROP CONSTRAINT data_contracts_governance_rules_id_fkey;
            END IF;
        END $$;
    """
    )

    # Drop columns
    op.drop_column("data_contracts", "owner_id", schema="pycharter")
    op.drop_column("data_contracts", "governance_rules_id", schema="pycharter")


def downgrade() -> None:
    """
    Revert: Add back owner_id and governance_rules_id columns.

    WARNING: This will create NULL values for these columns.
    You may need to populate them from metadata_records.
    """

    # Add columns back (nullable)
    op.add_column(
        "data_contracts",
        sa.Column("owner_id", sa.String(length=255), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "data_contracts",
        sa.Column("governance_rules_id", sa.Integer(), nullable=True),
        schema="pycharter",
    )

    # Add foreign key constraints
    op.create_foreign_key(
        "data_contracts_owner_id_fkey",
        "data_contracts",
        "owners",
        ["owner_id"],
        ["id"],
        source_schema="pycharter",
        referent_schema="pycharter",
        ondelete="SET NULL",
    )

    op.create_foreign_key(
        "data_contracts_governance_rules_id_fkey",
        "data_contracts",
        "governance_rules",
        ["governance_rules_id"],
        ["id"],
        source_schema="pycharter",
        referent_schema="pycharter",
        ondelete="SET NULL",
    )

    # Note: You may want to populate these columns from metadata_records:
    # - owner_id: Extract from metadata_records.business_owners or create owner records
    # - governance_rules_id: Extract from metadata_records.governance_rules or create governance_rule records
