"""Remove legacy columns from schemas, metadata_records, coercion_rules, and validation_rules tables

Revision ID: 20251204151550
Revises: e8870b97027a
Create Date: 2025-12-04 15:15:50.000000

This migration removes the legacy 'name' and 'data_contract' columns from the schemas table,
and 'data_contract' columns from metadata_records, coercion_rules, and validation_rules tables.
The name is now only stored in the data_contracts table, and all tables are
linked via data_contract_id foreign key.
"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision: str = "20251204151550"
down_revision: Union[str, None] = "e8870b97027a"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """
    Remove the legacy 'name' and 'data_contract' columns from schemas table,
    and 'data_contract' columns from metadata_records, coercion_rules, and validation_rules tables.

    The name is now only stored in data_contracts table, and all tables are
    linked via data_contract_id foreign key.
    """
    # Drop the legacy columns from schemas table
    op.drop_column("schemas", "name", schema="pycharter")
    op.drop_column("schemas", "data_contract", schema="pycharter")

    # Drop the legacy data_contract column from metadata_records table
    op.drop_column("metadata_records", "data_contract", schema="pycharter")

    # Drop the legacy data_contract column from coercion_rules table (if it exists)
    op.execute(
        """
        DO $$ 
        BEGIN
            IF EXISTS (
                SELECT 1 FROM information_schema.columns 
                WHERE table_schema = 'pycharter' 
                AND table_name = 'coercion_rules' 
                AND column_name = 'data_contract'
            ) THEN
                ALTER TABLE pycharter.coercion_rules DROP COLUMN data_contract;
            END IF;
        END $$;
    """
    )

    # Drop the legacy data_contract column from validation_rules table (if it exists)
    op.execute(
        """
        DO $$ 
        BEGIN
            IF EXISTS (
                SELECT 1 FROM information_schema.columns 
                WHERE table_schema = 'pycharter' 
                AND table_name = 'validation_rules' 
                AND column_name = 'data_contract'
            ) THEN
                ALTER TABLE pycharter.validation_rules DROP COLUMN data_contract;
            END IF;
        END $$;
    """
    )


def downgrade() -> None:
    """
    Restore the 'name' and 'data_contract' columns to schemas table,
    and 'data_contract' columns to metadata_records, coercion_rules, and validation_rules tables.

    Note: This will populate name and data_contract from data_contracts.name for existing records.
    """
    # Add columns back to schemas
    op.add_column(
        "schemas",
        sa.Column("name", sa.String(length=255), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "schemas",
        sa.Column("data_contract", sa.String(length=255), nullable=True),
        schema="pycharter",
    )

    # Populate from data_contracts
    op.execute(
        """
        UPDATE pycharter.schemas s
        SET name = dc.name,
            data_contract = dc.name
        FROM pycharter.data_contracts dc
        WHERE s.data_contract_id = dc.id
    """
    )

    # Make them NOT NULL after populating
    op.alter_column("schemas", "name", nullable=False, schema="pycharter")
    op.alter_column("schemas", "data_contract", nullable=False, schema="pycharter")

    # Add data_contract column back to metadata_records
    op.add_column(
        "metadata_records",
        sa.Column("data_contract", sa.String(length=255), nullable=True),
        schema="pycharter",
    )

    # Populate from data_contracts
    op.execute(
        """
        UPDATE pycharter.metadata_records mr
        SET data_contract = dc.name
        FROM pycharter.data_contracts dc
        WHERE mr.data_contract_id = dc.id
    """
    )

    # Make it NOT NULL after populating
    op.alter_column(
        "metadata_records", "data_contract", nullable=False, schema="pycharter"
    )

    # Add data_contract column back to coercion_rules
    op.add_column(
        "coercion_rules",
        sa.Column("data_contract", sa.String(length=255), nullable=True),
        schema="pycharter",
    )

    # Populate from data_contracts
    op.execute(
        """
        UPDATE pycharter.coercion_rules cr
        SET data_contract = dc.name
        FROM pycharter.data_contracts dc
        WHERE cr.data_contract_id = dc.id
    """
    )

    # Make it NOT NULL after populating
    op.alter_column(
        "coercion_rules", "data_contract", nullable=False, schema="pycharter"
    )

    # Add data_contract column back to validation_rules
    op.add_column(
        "validation_rules",
        sa.Column("data_contract", sa.String(length=255), nullable=True),
        schema="pycharter",
    )

    # Populate from data_contracts
    op.execute(
        """
        UPDATE pycharter.validation_rules vr
        SET data_contract = dc.name
        FROM pycharter.data_contracts dc
        WHERE vr.data_contract_id = dc.id
    """
    )

    # Make it NOT NULL after populating
    op.alter_column(
        "validation_rules", "data_contract", nullable=False, schema="pycharter"
    )
