"""Remove extra columns from systems and domains tables

Revision ID: 20251205130000
Revises: 20251205120000
Create Date: 2025-12-05 13:00:00.000000

This migration removes columns from systems and domains tables that don't exist
in the SQLAlchemy models to ensure database schema matches the models exactly.

For systems table:
- Removes: system_type, connection_info, is_active

For domains table:
- Removes: is_active (if it exists)
"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision: str = "20251205130000"
down_revision: Union[str, None] = "20251205120000"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """
    Remove extra columns from systems and domains tables that don't exist in models.

    Systems table should only have: id, name, app_id, description, created_at, updated_at
    Domains table should only have: id, name, description, created_at, updated_at
    """
    # Remove extra columns from systems table
    # Check if columns exist before dropping (safe for idempotency)
    op.execute(
        """
        DO $$ 
        BEGIN
            -- Drop system_type column if it exists
            IF EXISTS (
                SELECT 1 FROM information_schema.columns 
                WHERE table_schema = 'pycharter' 
                AND table_name = 'systems' 
                AND column_name = 'system_type'
            ) THEN
                ALTER TABLE pycharter.systems DROP COLUMN system_type;
            END IF;
            
            -- Drop connection_info column if it exists
            IF EXISTS (
                SELECT 1 FROM information_schema.columns 
                WHERE table_schema = 'pycharter' 
                AND table_name = 'systems' 
                AND column_name = 'connection_info'
            ) THEN
                ALTER TABLE pycharter.systems DROP COLUMN connection_info;
            END IF;
            
            -- Drop is_active column if it exists
            IF EXISTS (
                SELECT 1 FROM information_schema.columns 
                WHERE table_schema = 'pycharter' 
                AND table_name = 'systems' 
                AND column_name = 'is_active'
            ) THEN
                ALTER TABLE pycharter.systems DROP COLUMN is_active;
            END IF;
        END $$;
    """
    )

    # Remove is_active column from domains table if it exists
    op.execute(
        """
        DO $$ 
        BEGIN
            IF EXISTS (
                SELECT 1 FROM information_schema.columns 
                WHERE table_schema = 'pycharter' 
                AND table_name = 'domains' 
                AND column_name = 'is_active'
            ) THEN
                ALTER TABLE pycharter.domains DROP COLUMN is_active;
            END IF;
        END $$;
    """
    )


def downgrade() -> None:
    """
    Add back the removed columns (for rollback purposes).

    Note: This will add the columns back but won't restore the data that was in them.
    """
    # Add back columns to systems table
    op.add_column(
        "systems",
        sa.Column("system_type", sa.String(length=50), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "systems",
        sa.Column("connection_info", sa.Text(), nullable=True),
        schema="pycharter",
    )
    op.add_column(
        "systems",
        sa.Column("is_active", sa.String(length=10), nullable=True),
        schema="pycharter",
    )

    # Add back is_active column to domains table
    op.add_column(
        "domains",
        sa.Column("is_active", sa.String(length=10), nullable=True),
        schema="pycharter",
    )
