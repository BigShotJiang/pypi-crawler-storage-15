"""Add ownership fields and remove unused fields from metadata_records

Revision ID: 2010ee8b5c4b
Revises: 6d8c42bdd68a
Create Date: 2025-11-28 15:00:00.000000

This migration updates metadata_records table to match template_metadata.yaml structure:

Adds ownership fields:
- it_application_owners: List of IT Application Owner email addresses
- it_sme: List of IT Subject Matter Expert email addresses
- support_lead: List of Support Lead email addresses

Removes unused fields (not in template_metadata.yaml):
- business_rules: Not in template
- serve: Not in template
- indexes: Not in template
- additional_metadata: Not in template

Keeps governance_rules as it is present in template_metadata.yaml.
"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = "2010ee8b5c4b"
down_revision: Union[str, None] = "6d8c42bdd68a"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """
    Update metadata_records table to match template_metadata.yaml structure.

    Adds three new JSON columns for ownership:
    - it_application_owners: IT Application Owners
    - it_sme: IT Subject Matter Experts
    - support_lead: Support Lead

    Removes unused columns:
    - business_rules
    - serve
    - indexes
    - additional_metadata
    """

    # Remove unused columns first
    op.drop_column("metadata_records", "additional_metadata", schema="pycharter")
    op.drop_column("metadata_records", "indexes", schema="pycharter")
    op.drop_column("metadata_records", "serve", schema="pycharter")
    op.drop_column("metadata_records", "business_rules", schema="pycharter")

    # Add new ownership columns
    op.add_column(
        "metadata_records",
        sa.Column(
            "it_application_owners",
            postgresql.JSON(astext_type=sa.Text()),
            nullable=True,
        ),
        schema="pycharter",
    )

    op.add_column(
        "metadata_records",
        sa.Column("it_sme", postgresql.JSON(astext_type=sa.Text()), nullable=True),
        schema="pycharter",
    )

    op.add_column(
        "metadata_records",
        sa.Column(
            "support_lead", postgresql.JSON(astext_type=sa.Text()), nullable=True
        ),
        schema="pycharter",
    )


def downgrade() -> None:
    """
    Revert changes: Remove new ownership fields and restore removed fields.

    Drops the three ownership columns added in upgrade.
    Restores the columns that were removed.
    """

    # Drop new ownership columns
    op.drop_column("metadata_records", "support_lead", schema="pycharter")
    op.drop_column("metadata_records", "it_sme", schema="pycharter")
    op.drop_column("metadata_records", "it_application_owners", schema="pycharter")

    # Restore removed columns
    op.add_column(
        "metadata_records",
        sa.Column(
            "business_rules", postgresql.JSON(astext_type=sa.Text()), nullable=True
        ),
        schema="pycharter",
    )

    op.add_column(
        "metadata_records",
        sa.Column("serve", postgresql.JSON(astext_type=sa.Text()), nullable=True),
        schema="pycharter",
    )

    op.add_column(
        "metadata_records",
        sa.Column("indexes", postgresql.JSON(astext_type=sa.Text()), nullable=True),
        schema="pycharter",
    )

    op.add_column(
        "metadata_records",
        sa.Column(
            "additional_metadata", postgresql.JSON(astext_type=sa.Text()), nullable=True
        ),
        schema="pycharter",
    )
