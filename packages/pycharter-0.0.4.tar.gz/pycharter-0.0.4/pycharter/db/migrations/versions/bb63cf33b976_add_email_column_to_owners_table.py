"""Add email column to owners table

Revision ID: bb63cf33b976
Revises: ae7bc1c69439
Create Date: 2025-12-02 11:41:41.580087

"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision: str = "bb63cf33b976"
down_revision: Union[str, None] = "ae7bc1c69439"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Add email column to owners table
    op.add_column(
        "owners",
        sa.Column("email", sa.String(length=255), nullable=True),
        schema="pycharter",
    )


def downgrade() -> None:
    # Remove email column from owners table
    op.drop_column("owners", "email", schema="pycharter")
