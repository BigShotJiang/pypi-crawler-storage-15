"""
CLI commands for database management (pycharter db init, pycharter db upgrade)

Following Airflow's pattern: airflow db init, airflow db upgrade
"""

import argparse
import os
import sys
from pathlib import Path
from typing import Any, Optional

try:
    import yaml  # type: ignore[import-untyped]

    YAML_AVAILABLE = True
except ImportError:
    YAML_AVAILABLE = False

try:
    from alembic import command
    from alembic.config import Config
    from sqlalchemy import create_engine, inspect, text
    from sqlalchemy.exc import OperationalError

    ALEMBIC_AVAILABLE = True
except ImportError:
    ALEMBIC_AVAILABLE = False

from pycharter.config import get_database_url, set_database_url
from pycharter.db.models import DomainModel, OwnerModel, SystemModel
from pycharter.db.models.base import Base, get_session


def get_alembic_config(database_url: Optional[str] = None) -> Config:
    """
    Get Alembic configuration.

    Args:
        database_url: Optional database URL (if None, uses PYCHARTER_DATABASE_URL env var)

    Returns:
        Alembic Config object
    """
    # Get the path to alembic.ini (should be in project root)
    # __file__ is pycharter/db/cli.py, so we need to go up 3 levels
    current_file = os.path.abspath(__file__)
    # pycharter/db/cli.py -> pycharter/db -> pycharter -> project root
    project_root = os.path.dirname(os.path.dirname(os.path.dirname(current_file)))
    alembic_ini_path = os.path.join(project_root, "alembic.ini")

    # Alternative: try to find it relative to current working directory
    if not os.path.exists(alembic_ini_path):
        # Try current working directory
        cwd_alembic = os.path.join(os.getcwd(), "alembic.ini")
        if os.path.exists(cwd_alembic):
            alembic_ini_path = cwd_alembic
        else:
            raise FileNotFoundError(
                f"Alembic configuration not found. Tried:\n"
                f"  - {alembic_ini_path}\n"
                f"  - {cwd_alembic}\n"
                "Make sure you're running from the project root or alembic.ini exists."
            )

    config = Config(alembic_ini_path)

    # Set database URL from argument, config, or environment variable
    if database_url:
        set_database_url(database_url)
    else:
        # Try to get from configuration
        db_url = get_database_url()
        if db_url:
            set_database_url(db_url)
        elif not os.getenv("PYCHARTER_DATABASE_URL"):
            # Last resort: try to get from alembic.ini directly
            database_url = config.get_main_option("sqlalchemy.url")
            if database_url and database_url != "driver://user:pass@localhost/dbname":
                set_database_url(database_url)

    return config


def cmd_init(
    database_url: Optional[str] = None,
    db_type: Optional[str] = None,
    force: bool = False,
) -> int:
    """
    Initialize the database schema from scratch.

    Equivalent to: airflow db init

    Supports both PostgreSQL (with Alembic migrations) and MongoDB (indexes only).
    Auto-detects database type from connection string if not specified.

    Args:
        database_url: Optional database connection string (uses config if not provided)
        db_type: Optional database type - "postgresql" or "mongodb" (auto-detected from URL if not provided)
        force: If True, proceed even if database appears initialized

    Returns:
        Exit code (0 for success, 1 for failure)
    """
    try:
        # Get database URL from argument or configuration
        db_url = database_url or get_database_url()
        if not db_url:
            print("❌ Error: Database URL required.")
            print("   Provide as argument: pycharter db init <database_url>")
            print(
                "   Or set environment variable: PYCHARTER__DATABASE__SQL_ALCHEMY_CONN or PYCHARTER_DATABASE_URL"
            )
            print("   Or configure in pycharter.cfg or alembic.ini")
            print()
            print("   Connection string formats:")
            print("   - PostgreSQL: postgresql://user:pass@host:port/database")
            print("   - MongoDB: mongodb://[user:pass@]host[:port][/database]")
            return 1

        # Auto-detect database type from connection string if not provided
        if not db_type:
            if db_url.startswith("mongodb://") or db_url.startswith("mongodb+srv://"):
                db_type = "mongodb"
            elif db_url.startswith("postgresql://") or db_url.startswith("postgres://"):
                db_type = "postgresql"
            else:
                # Default to postgresql if cannot detect
                db_type = "postgresql"
                print(
                    f"⚠ Warning: Could not detect database type from connection string, defaulting to PostgreSQL"
                )

        # Normalize database type
        if db_type in ["postgres", "postgresql"]:
            db_type = "postgresql"
        elif db_type == "mongodb":
            db_type = "mongodb"
        else:
            print(f"❌ Error: Unsupported database type: {db_type}")
            print("   Supported types: postgresql, mongodb")
            return 1

        # Route to appropriate initialization based on db_type
        if db_type == "mongodb":
            return _init_mongodb(db_url, force)
        else:
            # PostgreSQL initialization (default)
            return _init_postgresql(db_url, force)
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback

        traceback.print_exc()
        return 1


def _init_mongodb(database_url: str, force: bool = False) -> int:
    """
    Initialize MongoDB database (create indexes).

    Args:
        database_url: MongoDB connection string
        force: If True, proceed even if indexes already exist

    Returns:
        Exit code (0 for success, 1 for failure)
    """
    try:
        from pycharter.metadata_store.mongodb import MongoDBMetadataStore

        # Parse database name from URL if provided
        # mongodb://user:pass@host:port/database_name
        database_name = "pycharter"
        if "/" in database_url.split("@")[-1]:
            # Extract database name from URL
            db_part = database_url.split("/")[-1].split("?")[0]
            if db_part and db_part != database_url.split("@")[-1]:
                database_name = db_part

        print(f"Initializing MongoDB database: {database_name}")
        print(
            f"Connection: {database_url.split('@')[-1] if '@' in database_url else database_url}"
        )

        # Create store and connect (this will create indexes)
        store = MongoDBMetadataStore(
            connection_string=database_url, database_name=database_name
        )
        store.connect(ensure_indexes=True)

        print("✓ Connected to MongoDB")
        print("✓ Created/verified indexes:")
        print("  - schemas: name, version")
        print("  - governance_rules: schema_id")
        print("  - ownership: resource_id")
        print("  - coercion_rules: schema_id, (schema_id, version)")
        print("  - validation_rules: schema_id, (schema_id, version)")
        print("\n✓ MongoDB initialization complete!")
        print(
            "\nNote: MongoDB collections are created automatically when first document is inserted."
        )
        print(
            "      No migrations needed - MongoDB handles schema evolution naturally."
        )

        store.disconnect()
        return 0

    except ImportError:
        print(
            "❌ Error: pymongo is required for MongoDB. Install with: pip install pymongo"
        )
        return 1
    except Exception as e:
        print(f"❌ Error initializing MongoDB: {e}")
        import traceback

        traceback.print_exc()
        return 1


def _init_postgresql(database_url: str, force: bool = False) -> int:
    """
    Initialize PostgreSQL database (create tables, migrations, etc.).

    Args:
        database_url: PostgreSQL connection string
        force: If True, proceed even if database appears initialized

    Returns:
        Exit code (0 for success, 1 for failure)
    """
    if not ALEMBIC_AVAILABLE:
        print(
            "❌ Error: alembic and sqlalchemy are required. Install with: pip install alembic sqlalchemy"
        )
        return 1

    try:
        # Set environment variable for Alembic
        set_database_url(database_url)

        # Get Alembic config
        config = get_alembic_config(database_url)

        # Check if database is already initialized
        engine = create_engine(database_url)
        inspector = inspect(engine)

        # Create the pycharter schema if it doesn't exist
        from sqlalchemy import text

        with engine.connect() as conn:
            conn.execute(text('CREATE SCHEMA IF NOT EXISTS "pycharter"'))
            conn.commit()
        print("✓ Created 'pycharter' schema (if it didn't exist)")

        # Check tables in the pycharter schema
        existing_tables = inspector.get_table_names(schema="pycharter")

        # Check if we have any migrations
        versions_dir = os.path.join(
            os.path.dirname(os.path.dirname(__file__)), "migrations", "versions"
        )
        has_migrations = os.path.exists(versions_dir) and os.listdir(versions_dir)

        # Check if alembic_version table exists (indicates database is versioned)
        # Note: alembic_version is typically in public schema, but we'll check both
        public_tables = inspector.get_table_names(schema="public")
        has_alembic_version = (
            "alembic_version" in public_tables or "alembic_version" in existing_tables
        )
        has_schemas_table = "schemas" in existing_tables

        # Check for migration mismatch: database revision doesn't match any migration file
        if has_alembic_version and has_migrations:
            from alembic.script import ScriptDirectory

            # Get current database revision
            # Note: alembic_version is typically in public schema (Alembic convention)
            with engine.connect() as conn:
                # Try public schema first (Alembic default), then pycharter schema
                try:
                    result = conn.execute(
                        text("SELECT version_num FROM alembic_version")
                    )
                except Exception:
                    # Try pycharter schema
                    result = conn.execute(
                        text('SELECT version_num FROM "pycharter".alembic_version')
                    )
                db_revision = result.fetchone()
                if db_revision:
                    db_revision = db_revision[0]

                    # Check if this revision exists in migration files
                    script = ScriptDirectory.from_config(config)
                    try:
                        script.get_revision(db_revision)
                        revision_exists = True
                    except Exception:
                        revision_exists = False

                    if not revision_exists:
                        print(f"❌ Error: Migration mismatch detected!")
                        print(f"   Database revision: {db_revision}")
                        print(f"   This revision does not exist in migration files.")
                        print()
                        print("   This typically happens when:")
                        print("   - Migration files were deleted from the codebase")
                        print(
                            "   - Database was initialized on a different machine with different migrations"
                        )
                        print(
                            "   - Code was pulled from git but database wasn't updated"
                        )
                        print()
                        print("   Solutions:")
                        print("   1. If you want to reset the database:")
                        print("      - Drop and recreate the database")
                        print("      - Run 'pycharter db init' again")
                        print()
                        print("   2. If you want to keep the database:")
                        print(
                            "      - Find the correct migration file that matches your database schema"
                        )
                        print(
                            "      - Stamp the database: pycharter db stamp <revision>"
                        )
                        print(
                            "      - Or manually update alembic_version table to match an existing migration"
                        )
                        print()
                        print(
                            "   3. If you want to force initialization (will recreate tables):"
                        )
                        print("      - Use --force flag: pycharter db init --force")
                        return 1

        # If tables exist but no alembic_version, we can still initialize Alembic tracking
        if has_schemas_table and has_alembic_version and not force:
            print("⚠ Warning: Database appears to already be initialized.")
            print(
                "Use --force to proceed anyway, or run 'pycharter db upgrade' to apply migrations."
            )
            return 1

        # If tables exist but no alembic_version, we'll set up Alembic tracking
        if has_schemas_table and not has_alembic_version:
            print("ℹ Database has tables but no Alembic version tracking.")
            print("Setting up Alembic version tracking...")

        # Create all tables using SQLAlchemy (for initial setup)
        print("Creating database tables...")
        Base.metadata.create_all(engine)

        # Handle Alembic versioning
        if has_migrations:
            # We have migrations, stamp with head
            print("Stamping database with Alembic version...")
            command.stamp(config, "head")
        else:
            # No migrations yet - create initial migration
            print("Creating initial migration...")
            # Since tables already exist, we need to create the migration file first
            # without autogenerate checking the database state
            # We'll create an empty migration and then autogenerate will detect the existing tables
            try:
                # Create migration with autogenerate - this will detect existing tables
                # We need to bypass the "not up to date" check by ensuring alembic_version exists
                # First, create alembic_version table manually if it doesn't exist
                # Note: alembic_version is typically in public schema (Alembic convention)
                with engine.connect() as conn:
                    conn.execute(
                        text(
                            """
                        CREATE TABLE IF NOT EXISTS alembic_version (
                            version_num VARCHAR(32) NOT NULL,
                            CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num)
                        )
                    """
                        )
                    )
                    conn.commit()

                # Now create the migration - it should work since alembic_version exists
                command.revision(config, autogenerate=True, message="Initial schema")

                # Stamp with head to mark as current
                command.stamp(config, "head")
            except Exception as e:
                # If autogenerate still fails, try creating migration without autogenerate
                # and manually add the table definitions
                print(
                    f"⚠ Warning: Autogenerate failed ({e}), creating empty migration..."
                )
                command.revision(config, autogenerate=False, message="Initial schema")
                command.stamp(config, "head")

        print("✓ Database initialized successfully!")
        return 0

    except Exception as e:
        print(f"❌ Error initializing database: {e}")
        import traceback

        traceback.print_exc()
        return 1


def cmd_upgrade(database_url: Optional[str] = None, revision: str = "head") -> int:
    """
    Upgrade database to the latest revision.

    Equivalent to: airflow db upgrade

    Args:
        database_url: Optional PostgreSQL connection string (uses PYCHARTER_DATABASE_URL if not provided)
        revision: Target revision (default: "head")

    Returns:
        Exit code (0 for success, 1 for failure)
    """
    if not ALEMBIC_AVAILABLE:
        print(
            "❌ Error: alembic and sqlalchemy are required. Install with: pip install alembic sqlalchemy"
        )
        return 1

    try:
        # Get database URL from argument or configuration
        db_url = database_url or get_database_url()
        if not db_url:
            print("❌ Error: Database URL required.")
            print("   Provide as argument: pycharter db upgrade <database_url>")
            print(
                "   Or set environment variable: PYCHARTER__DATABASE__SQL_ALCHEMY_CONN or PYCHARTER_DATABASE_URL"
            )
            print("   Or configure in pycharter.cfg or alembic.ini")
            return 1

        if database_url:
            set_database_url(database_url)

        # Get Alembic config
        config = get_alembic_config(db_url)

        # Run upgrade
        print(f"Upgrading database to revision: {revision}...")
        command.upgrade(config, revision)

        print("✓ Database upgraded successfully!")
        return 0

    except Exception as e:
        print(f"❌ Error upgrading database: {e}")
        import traceback

        traceback.print_exc()
        return 1


def cmd_downgrade(database_url: Optional[str] = None, revision: str = "-1") -> int:
    """
    Downgrade database to a previous revision.

    Equivalent to: airflow db downgrade

    Args:
        database_url: Optional PostgreSQL connection string (uses PYCHARTER_DATABASE_URL if not provided)
        revision: Target revision (default: "-1" for one step back)

    Returns:
        Exit code (0 for success, 1 for failure)
    """
    if not ALEMBIC_AVAILABLE:
        print(
            "❌ Error: alembic and sqlalchemy are required. Install with: pip install alembic sqlalchemy"
        )
        return 1

    try:
        # Get database URL from argument or configuration
        db_url = database_url or get_database_url()
        if not db_url:
            print("❌ Error: Database URL required.")
            print("   Provide as argument: pycharter db downgrade <database_url>")
            print(
                "   Or set environment variable: PYCHARTER__DATABASE__SQL_ALCHEMY_CONN or PYCHARTER_DATABASE_URL"
            )
            print("   Or configure in pycharter.cfg or alembic.ini")
            return 1

        if database_url:
            set_database_url(database_url)

        config = get_alembic_config(db_url)

        print(f"Downgrading database to revision: {revision}...")
        command.downgrade(config, revision)

        print("✓ Database downgraded successfully!")
        return 0

    except Exception as e:
        print(f"❌ Error downgrading database: {e}")
        import traceback

        traceback.print_exc()
        return 1


def cmd_current(database_url: Optional[str] = None) -> int:
    """
    Show current database revision.

    Args:
        database_url: Optional PostgreSQL connection string

    Returns:
        Exit code (0 for success, 1 for failure)
    """
    if not ALEMBIC_AVAILABLE:
        print(
            "❌ Error: alembic and sqlalchemy are required. Install with: pip install alembic sqlalchemy"
        )
        return 1

    try:
        # Get database URL from argument or configuration
        db_url = database_url or get_database_url()
        if not db_url:
            print("❌ Error: Database URL required.")
            print("   Provide as argument: pycharter db current <database_url>")
            print(
                "   Or set environment variable: PYCHARTER__DATABASE__SQL_ALCHEMY_CONN or PYCHARTER_DATABASE_URL"
            )
            print("   Or configure in pycharter.cfg or alembic.ini")
            return 1

        if database_url:
            set_database_url(database_url)

        config = get_alembic_config(db_url)

        # Get current revision
        from alembic.runtime.migration import MigrationContext
        from alembic.script import ScriptDirectory
        from sqlalchemy import create_engine

        engine = create_engine(db_url)
        with engine.connect() as connection:
            context = MigrationContext.configure(connection)
            current_rev = context.get_current_revision()

        if current_rev:
            print(f"Current database revision: {current_rev}")
        else:
            print("Database is not initialized. Run 'pycharter db init' first.")
            return 1

        return 0

    except Exception as e:
        print(f"❌ Error getting current revision: {e}")
        return 1


def cmd_stamp(database_url: Optional[str] = None, revision: str = "head") -> int:
    """
    Stamp the database with a specific revision without running migrations.

    Useful for fixing migration mismatches or marking the database as being at a specific revision.

    Equivalent to: alembic stamp <revision>

    Args:
        database_url: Optional PostgreSQL connection string
        revision: Revision to stamp (default: "head")

    Returns:
        Exit code (0 for success, 1 for failure)
    """
    if not ALEMBIC_AVAILABLE:
        print(
            "❌ Error: alembic and sqlalchemy are required. Install with: pip install alembic sqlalchemy"
        )
        return 1

    try:
        # Get database URL from argument or configuration
        db_url = database_url or get_database_url()
        if not db_url:
            print("❌ Error: Database URL required.")
            print(
                "   Provide as argument: pycharter db stamp <revision> <database_url>"
            )
            print(
                "   Or set environment variable: PYCHARTER__DATABASE__SQL_ALCHEMY_CONN or PYCHARTER_DATABASE_URL"
            )
            print("   Or configure in pycharter.cfg or alembic.ini")
            return 1

        if database_url:
            set_database_url(database_url)

        config = get_alembic_config(db_url)

        # Stamp database
        print(f"Stamping database with revision: {revision}...")
        command.stamp(config, revision)

        print(f"✓ Database stamped successfully with revision: {revision}")
        return 0

    except Exception as e:
        print(f"❌ Error stamping database: {e}")
        import traceback

        traceback.print_exc()
        return 1


def cmd_history(database_url: Optional[str] = None) -> int:
    """
    Show migration history.

    Args:
        database_url: Optional PostgreSQL connection string

    Returns:
        Exit code (0 for success, 1 for failure)
    """
    if not ALEMBIC_AVAILABLE:
        print(
            "❌ Error: alembic and sqlalchemy are required. Install with: pip install alembic sqlalchemy"
        )
        return 1

    try:
        if database_url:
            set_database_url(database_url)

        config = get_alembic_config()

        command.history(config)

        return 0

    except Exception as e:
        print(f"❌ Error showing history: {e}")
        return 1


def cmd_seed(seed_dir: Optional[str] = None, database_url: Optional[str] = None) -> int:
    """
    Seed the database with initial data from YAML files.

    Reads seed data from YAML files in the specified directory (default: data/seed).
    Supports seeding owners, domains, and systems tables.
    Supports both PostgreSQL and MongoDB databases.

    Args:
        seed_dir: Directory containing seed YAML files (default: data/seed relative to project root)
        database_url: Optional database connection string (uses PYCHARTER_DATABASE_URL if not provided)
                     Supports PostgreSQL (postgresql://) and MongoDB (mongodb://) connection strings

    Returns:
        Exit code (0 for success, 1 for failure)
    """
    if not YAML_AVAILABLE:
        print("❌ Error: PyYAML is required. Install with: pip install pyyaml")
        return 1

    try:
        # Handle ambiguous arguments - if seed_dir looks like a database URL, swap them
        if seed_dir and (
            seed_dir.startswith("postgresql://")
            or seed_dir.startswith("postgres://")
            or seed_dir.startswith("mysql://")
            or seed_dir.startswith("sqlite://")
            or seed_dir.startswith("mongodb://")
            or seed_dir.startswith("mongodb+srv://")
        ):
            # seed_dir is actually a database URL
            database_url = seed_dir
            seed_dir = None

        # Get database URL from argument or configuration
        db_url = database_url or get_database_url()
        if not db_url:
            print("❌ Error: Database URL required.")
            print("   Provide as argument: pycharter db seed [seed_dir] [database_url]")
            print(
                "   Or set environment variable: PYCHARTER__DATABASE__SQL_ALCHEMY_CONN or PYCHARTER_DATABASE_URL"
            )
            print("   Or configure in pycharter.cfg or alembic.ini")
            return 1

        # Determine seed directory
        if seed_dir:
            seed_path = Path(seed_dir)
        else:
            # Default to data/seed relative to project root
            current_file = os.path.abspath(__file__)
            # pycharter/db/cli.py -> pycharter/db -> pycharter -> project root
            # Go up 3 levels: pycharter/db/cli.py -> pycharter/db -> pycharter -> project root
            project_root = Path(
                os.path.dirname(os.path.dirname(os.path.dirname(current_file)))
            )
            seed_path = project_root / "data" / "seed"

        if not seed_path.exists():
            print(f"❌ Error: Seed directory not found: {seed_path}")
            print(
                "   Please create the directory and add seed YAML files (owners.yaml, domains.yaml, systems.yaml)"
            )
            return 1

        if not seed_path.is_dir():
            print(f"❌ Error: Seed path is not a directory: {seed_path}")
            return 1

        print(f"Loading seed data from: {seed_path}")

        # Detect database type and route to appropriate seeding function
        if db_url.startswith("mongodb://") or db_url.startswith("mongodb+srv://"):
            return _seed_mongodb(seed_path, db_url)
        else:
            # PostgreSQL (default)
            return _seed_postgresql(seed_path, db_url)

    except Exception as e:
        print(f"❌ Error seeding database: {e}")
        import traceback

        traceback.print_exc()
        return 1


def _seed_postgresql(seed_path: Path, db_url: str) -> int:
    """
    Seed PostgreSQL database with data from YAML files.

    Args:
        seed_path: Path to directory containing seed YAML files
        db_url: PostgreSQL connection string

    Returns:
        Exit code (0 for success, 1 for failure)
    """
    if not ALEMBIC_AVAILABLE:
        print("❌ Error: sqlalchemy is required. Install with: pip install sqlalchemy")
        return 1

    # Get database session
    session = get_session(db_url)

    try:
        # Seed owners
        owners_file = seed_path / "owners.yaml"
        if owners_file.exists():
            print("Loading owners...")
            with open(owners_file, "r") as f:
                owners_data = yaml.safe_load(f) or []

            for owner_data in owners_data:
                owner_id = owner_data.get("id")
                if not owner_id:
                    print(f"⚠ Warning: Skipping owner entry without 'id' field")
                    continue

                # Check if owner exists
                existing = session.query(OwnerModel).filter_by(id=owner_id).first()
                if existing:
                    # Update existing
                    for key, value in owner_data.items():
                        if hasattr(existing, key):
                            setattr(existing, key, value)
                    print(f"  Updated owner: {owner_id}")
                else:
                    # Create new
                    owner = OwnerModel(**owner_data)
                    session.add(owner)
                    print(f"  Created owner: {owner_id}")

            session.commit()
            print(f"✓ Loaded {len(owners_data)} owner(s)")
        else:
            print("⚠ No owners.yaml file found, skipping owners")

        # Seed domains
        domains_file = seed_path / "domains.yaml"
        if domains_file.exists():
            print("Loading domains...")
            with open(domains_file, "r") as f:
                domains_data = yaml.safe_load(f) or []

            for domain_data in domains_data:
                domain_name = domain_data.get("name")
                if not domain_name:
                    print(f"⚠ Warning: Skipping domain entry without 'name' field")
                    continue

                # Check if domain exists
                existing = (
                    session.query(DomainModel).filter_by(name=domain_name).first()
                )
                if existing:
                    # Update existing
                    for key, value in domain_data.items():
                        if hasattr(existing, key):
                            setattr(existing, key, value)
                    print(f"  Updated domain: {domain_name}")
                else:
                    # Create new
                    domain = DomainModel(**domain_data)
                    session.add(domain)
                    print(f"  Created domain: {domain_name}")

            session.commit()
            print(f"✓ Loaded {len(domains_data)} domain(s)")
        else:
            print("⚠ No domains.yaml file found, skipping domains")

        # Seed systems
        systems_file = seed_path / "systems.yaml"
        if systems_file.exists():
            print("Loading systems...")
            with open(systems_file, "r") as f:
                systems_data = yaml.safe_load(f) or []

            for system_data in systems_data:
                system_name = system_data.get("name")
                if not system_name:
                    print(f"⚠ Warning: Skipping system entry without 'name' field")
                    continue

                # Check if system exists
                existing = (
                    session.query(SystemModel).filter_by(name=system_name).first()
                )
                if existing:
                    # Update existing
                    for key, value in system_data.items():
                        if hasattr(existing, key):
                            setattr(existing, key, value)
                    print(f"  Updated system: {system_name}")
                else:
                    # Create new
                    system = SystemModel(**system_data)
                    session.add(system)
                    print(f"  Created system: {system_name}")

            session.commit()
            print(f"✓ Loaded {len(systems_data)} system(s)")
        else:
            print("⚠ No systems.yaml file found, skipping systems")

        print("\n✓ Seed data loaded successfully!")
        return 0

    except Exception as e:
        session.rollback()
        raise e
    finally:
        session.close()


def _seed_mongodb(seed_path: Path, db_url: str) -> int:
    """
    Seed MongoDB database with data from YAML files.

    Args:
        seed_path: Path to directory containing seed YAML files
        db_url: MongoDB connection string

    Returns:
        Exit code (0 for success, 1 for failure)
    """
    try:
        from datetime import datetime

        from bson import ObjectId
        from pymongo import MongoClient

        # Parse database name from URL if provided
        # mongodb://user:pass@host:port/database_name
        if "/" in db_url.rsplit("@", 1)[-1]:
            database_name = db_url.rsplit("/", 1)[-1].split("?")[0]
        else:
            database_name = "pycharter"

        # Connect to MongoDB
        print(f"Connecting to MongoDB database: {database_name}")
        client: Any = MongoClient(db_url)
        db = client[database_name]  # type: ignore[assignment]

        try:
            # Seed owners
            owners_file = seed_path / "owners.yaml"
            if owners_file.exists():
                print("Loading owners...")
                with open(owners_file, "r") as f:
                    owners_data = yaml.safe_load(f) or []

                owners_collection = db.owners
                count_created = 0
                count_updated = 0

                for owner_data in owners_data:
                    owner_id = owner_data.get("id")
                    if not owner_id:
                        print(f"⚠ Warning: Skipping owner entry without 'id' field")
                        continue

                    # Check if owner exists
                    existing = owners_collection.find_one({"id": owner_id})

                    # Prepare document with timestamps
                    doc = dict(owner_data)
                    now = datetime.utcnow()

                    if existing:
                        # Update existing (preserve _id and timestamps)
                        doc["updated_at"] = now
                        # Keep created_at from existing if it exists
                        if "created_at" in existing:
                            doc["created_at"] = existing["created_at"]
                        else:
                            doc["created_at"] = now

                        owners_collection.update_one({"id": owner_id}, {"$set": doc})
                        print(f"  Updated owner: {owner_id}")
                        count_updated += 1
                    else:
                        # Create new
                        doc["created_at"] = now
                        doc["updated_at"] = now
                        owners_collection.insert_one(doc)
                        print(f"  Created owner: {owner_id}")
                        count_created += 1

                print(
                    f"✓ Loaded {len(owners_data)} owner(s) ({count_created} created, {count_updated} updated)"
                )
            else:
                print("⚠ No owners.yaml file found, skipping owners")

            # Seed domains
            domains_file = seed_path / "domains.yaml"
            if domains_file.exists():
                print("Loading domains...")
                with open(domains_file, "r") as f:
                    domains_data = yaml.safe_load(f) or []

                domains_collection = db.domains
                count_created = 0
                count_updated = 0

                for domain_data in domains_data:
                    domain_name = domain_data.get("name")
                    if not domain_name:
                        print(f"⚠ Warning: Skipping domain entry without 'name' field")
                        continue

                    # Check if domain exists
                    existing = domains_collection.find_one({"name": domain_name})

                    # Prepare document with timestamps and generate UUID-like ID
                    doc = dict(domain_data)
                    now = datetime.utcnow()

                    if existing:
                        # Update existing (preserve _id and timestamps)
                        doc["updated_at"] = now
                        if "created_at" in existing:
                            doc["created_at"] = existing["created_at"]
                        else:
                            doc["created_at"] = now
                        if "_id" in existing:
                            doc["_id"] = existing["_id"]

                        domains_collection.update_one(
                            {"name": domain_name}, {"$set": doc}
                        )
                        print(f"  Updated domain: {domain_name}")
                        count_updated += 1
                    else:
                        # Create new with ObjectId
                        doc["_id"] = ObjectId()
                        doc["created_at"] = now
                        doc["updated_at"] = now
                        domains_collection.insert_one(doc)
                        print(f"  Created domain: {domain_name}")
                        count_created += 1

                print(
                    f"✓ Loaded {len(domains_data)} domain(s) ({count_created} created, {count_updated} updated)"
                )
            else:
                print("⚠ No domains.yaml file found, skipping domains")

            # Seed systems
            systems_file = seed_path / "systems.yaml"
            if systems_file.exists():
                print("Loading systems...")
                with open(systems_file, "r") as f:
                    systems_data = yaml.safe_load(f) or []

                systems_collection = db.systems
                count_created = 0
                count_updated = 0

                for system_data in systems_data:
                    system_name = system_data.get("name")
                    if not system_name:
                        print(f"⚠ Warning: Skipping system entry without 'name' field")
                        continue

                    # Check if system exists
                    existing = systems_collection.find_one({"name": system_name})

                    # Prepare document with timestamps
                    doc = dict(system_data)
                    now = datetime.utcnow()

                    if existing:
                        # Update existing (preserve _id and timestamps)
                        doc["updated_at"] = now
                        if "created_at" in existing:
                            doc["created_at"] = existing["created_at"]
                        else:
                            doc["created_at"] = now
                        if "_id" in existing:
                            doc["_id"] = existing["_id"]

                        systems_collection.update_one(
                            {"name": system_name}, {"$set": doc}
                        )
                        print(f"  Updated system: {system_name}")
                        count_updated += 1
                    else:
                        # Create new with ObjectId
                        doc["_id"] = ObjectId()
                        doc["created_at"] = now
                        doc["updated_at"] = now
                        systems_collection.insert_one(doc)
                        print(f"  Created system: {system_name}")
                        count_created += 1

                print(
                    f"✓ Loaded {len(systems_data)} system(s) ({count_created} created, {count_updated} updated)"
                )
            else:
                print("⚠ No systems.yaml file found, skipping systems")

            print("\n✓ Seed data loaded successfully!")
            return 0

        finally:
            client.close()

    except ImportError:
        print(
            "❌ Error: pymongo is required for MongoDB seeding. Install with: pip install pymongo"
        )
        return 1
    except Exception as e:
        print(f"❌ Error seeding MongoDB: {e}")
        import traceback

        traceback.print_exc()
        return 1


def cmd_truncate(database_url: Optional[str] = None, force: bool = False) -> int:
    """
    Truncate all PyCharter database tables.

    Clears all data from PyCharter tables while keeping the schema intact.
    Useful for resetting the database before seeding with fresh data.

    Args:
        database_url: Optional PostgreSQL connection string (uses PYCHARTER_DATABASE_URL if not provided)
        force: If True, skip confirmation prompt

    Returns:
        Exit code (0 for success, 1 for failure)
    """
    if not ALEMBIC_AVAILABLE:
        print("❌ Error: sqlalchemy is required. Install with: pip install sqlalchemy")
        return 1

    try:
        # Get database URL from argument or configuration
        db_url = database_url or get_database_url()
        if not db_url:
            print("❌ Error: Database URL required.")
            print("   Provide as argument: pycharter db truncate [database_url]")
            print(
                "   Or set environment variable: PYCHARTER__DATABASE__SQL_ALCHEMY_CONN or PYCHARTER_DATABASE_URL"
            )
            print("   Or configure in pycharter.cfg or alembic.ini")
            return 1

        if database_url:
            set_database_url(database_url)

        print(f"Connecting to database...")
        engine = create_engine(db_url)
        inspector = inspect(engine)

        # Get list of existing tables in the pycharter schema
        existing_tables = set(inspector.get_table_names(schema="pycharter"))

        # Tables to truncate in order (respecting foreign keys)
        join_tables = [
            "metadata_record_business_owners",
            "metadata_record_bu_sme",
            "metadata_record_it_application_owners",
            "metadata_record_it_sme",
            "metadata_record_support_lead",
            "metadata_record_system_pulls",
            "metadata_record_system_pushes",
            "metadata_record_system_sources",
            "metadata_record_domains",
        ]

        main_tables = [
            "coercion_rules",
            "validation_rules",
            "schemas",
            "metadata_records",
            "data_contracts",
        ]

        lookup_tables = [
            "owners",
            "systems",
            "domains",
        ]

        # Filter to only include tables that actually exist
        existing_join_tables = [t for t in join_tables if t in existing_tables]
        existing_main_tables = [t for t in main_tables if t in existing_tables]
        existing_lookup_tables = [t for t in lookup_tables if t in existing_tables]

        if not (existing_join_tables or existing_main_tables or existing_lookup_tables):
            print("⚠ No PyCharter tables found to truncate.")
            print(
                "   The database may not be initialized. Run 'pycharter db init' first."
            )
            return 0

        # Show what will be truncated
        total_tables = (
            len(existing_join_tables)
            + len(existing_main_tables)
            + len(existing_lookup_tables)
        )
        print(
            f"\n⚠ WARNING: This will truncate {total_tables} table(s) in the 'pycharter' schema:"
        )
        if existing_join_tables:
            print(
                f"   Join tables ({len(existing_join_tables)}): {', '.join(existing_join_tables)}"
            )
        if existing_main_tables:
            print(
                f"   Main tables ({len(existing_main_tables)}): {', '.join(existing_main_tables)}"
            )
        if existing_lookup_tables:
            print(
                f"   Lookup tables ({len(existing_lookup_tables)}): {', '.join(existing_lookup_tables)}"
            )
        print("\n⚠ ALL DATA IN THESE TABLES WILL BE PERMANENTLY DELETED!")
        print("   The schema structure will be preserved, but all data will be lost.")

        # Require confirmation unless --force flag is used
        if not force:
            print(
                "\nTo confirm, type 'yes' or 'y' to proceed, or anything else to cancel:"
            )
            try:
                confirmation = input("> ").strip().lower()
            except (EOFError, KeyboardInterrupt):
                print("\n❌ Truncate cancelled.")
                return 1

            if confirmation not in ["yes", "y"]:
                print("❌ Truncate cancelled.")
                return 1
            print()

        with engine.begin() as conn:
            # Disable foreign key checks temporarily (PostgreSQL)
            conn.execute(text("SET session_replication_role = 'replica'"))

            # Truncate join tables first
            if existing_join_tables:
                print("\nTruncating join tables...")
                for table in existing_join_tables:
                    conn.execute(text(f'TRUNCATE TABLE pycharter."{table}" CASCADE'))
                    print(f"  ✓ Truncated {table}")

            # Truncate main tables
            if existing_main_tables:
                print("\nTruncating main tables...")
                for table in existing_main_tables:
                    conn.execute(text(f'TRUNCATE TABLE pycharter."{table}" CASCADE'))
                    print(f"  ✓ Truncated {table}")

            # Truncate lookup tables
            if existing_lookup_tables:
                print("\nTruncating lookup tables...")
                for table in existing_lookup_tables:
                    conn.execute(text(f'TRUNCATE TABLE pycharter."{table}" CASCADE'))
                    print(f"  ✓ Truncated {table}")

            # Re-enable foreign key checks
            conn.execute(text("SET session_replication_role = 'origin'"))

        # Report any missing tables
        all_tables = set(join_tables + main_tables + lookup_tables)
        missing_tables = all_tables - existing_tables
        if missing_tables:
            print(f"\n⚠ Note: The following tables were not found and skipped:")
            for table in sorted(missing_tables):
                print(f"  - {table}")

        print("\n✓ Successfully truncated all existing PyCharter tables!")
        print("\nNote: The alembic_version table was NOT truncated.")
        print("      If you want to reset migrations, drop and recreate the database.")

        return 0

    except Exception as e:
        print(f"❌ Error truncating database: {e}")
        import traceback

        traceback.print_exc()
        return 1


def main():
    """Main CLI entry point for pycharter db commands."""
    parser = argparse.ArgumentParser(
        description="PyCharter database management commands",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Initialize database from scratch
  pycharter db init postgresql://user:pass@localhost/pycharter
  
  # Upgrade to latest version
  pycharter db upgrade postgresql://user:pass@localhost/pycharter
  
  # Upgrade using environment variable
  export PYCHARTER_DATABASE_URL=postgresql://user:pass@localhost/pycharter
  pycharter db upgrade
  
  # Show current revision
  pycharter db current postgresql://user:pass@localhost/pycharter
  
  # Show migration history
  pycharter db history
  
  # Stamp database with specific revision (fix migration mismatches)
  pycharter db stamp 435e5a4670a9 postgresql://user:pass@localhost/pycharter
  
  # Seed database with initial data
  pycharter db seed data/seed postgresql://user:pass@localhost/pycharter
  
  # Truncate all tables (clear all data)
  pycharter db truncate postgresql://user:pass@localhost/pycharter
        """,
    )

    subparsers = parser.add_subparsers(dest="command", help="Command to run")

    # init command
    init_parser = subparsers.add_parser(
        "init", help="Initialize database schema from scratch (default: PostgreSQL)"
    )
    init_parser.add_argument(
        "database_url",
        nargs="?",
        help="Database connection string (optional if configured)",
    )
    init_parser.add_argument(
        "--db",
        "--database-type",
        dest="db_type",
        choices=["postgresql", "postgres", "mongodb"],
        default="postgresql",
        help="Database type (default: postgresql)",
    )
    init_parser.add_argument(
        "--force",
        action="store_true",
        help="Proceed even if database appears initialized",
    )

    # upgrade command
    upgrade_parser = subparsers.add_parser(
        "upgrade", help="Upgrade database to latest revision"
    )
    upgrade_parser.add_argument(
        "database_url",
        nargs="?",
        help="PostgreSQL connection string (optional if PYCHARTER_DATABASE_URL is set)",
    )
    upgrade_parser.add_argument(
        "--revision", default="head", help="Target revision (default: head)"
    )

    # downgrade command
    downgrade_parser = subparsers.add_parser(
        "downgrade", help="Downgrade database to a previous revision"
    )
    downgrade_parser.add_argument(
        "database_url",
        nargs="?",
        help="PostgreSQL connection string (optional if PYCHARTER_DATABASE_URL is set)",
    )
    downgrade_parser.add_argument(
        "--revision", default="-1", help="Target revision (default: -1)"
    )

    # current command
    current_parser = subparsers.add_parser(
        "current", help="Show current database revision"
    )
    current_parser.add_argument(
        "database_url",
        nargs="?",
        help="PostgreSQL connection string (optional if PYCHARTER_DATABASE_URL is set)",
    )

    # history command
    history_parser = subparsers.add_parser("history", help="Show migration history")
    history_parser.add_argument(
        "database_url",
        nargs="?",
        help="PostgreSQL connection string (optional if PYCHARTER_DATABASE_URL is set)",
    )

    # stamp command
    stamp_parser = subparsers.add_parser(
        "stamp",
        help="Stamp database with a specific revision (without running migrations)",
    )
    stamp_parser.add_argument(
        "revision", nargs="?", default="head", help="Revision to stamp (default: head)"
    )
    stamp_parser.add_argument(
        "database_url",
        nargs="?",
        help="PostgreSQL connection string (optional if PYCHARTER_DATABASE_URL is set)",
    )

    # seed command
    seed_parser = subparsers.add_parser(
        "seed", help="Seed database with initial data from YAML files"
    )
    seed_parser.add_argument(
        "seed_dir",
        nargs="?",
        help="Directory containing seed YAML files (default: data/seed)",
    )
    seed_parser.add_argument(
        "database_url",
        nargs="?",
        help="PostgreSQL connection string (optional if PYCHARTER_DATABASE_URL is set)",
    )

    # truncate command
    truncate_parser = subparsers.add_parser(
        "truncate", help="Truncate all PyCharter database tables (clear all data)"
    )
    truncate_parser.add_argument(
        "database_url",
        nargs="?",
        help="PostgreSQL connection string (optional if PYCHARTER_DATABASE_URL is set)",
    )

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 1

    if args.command == "init":
        return cmd_init(args.database_url, db_type=args.db_type, force=args.force)
    elif args.command == "upgrade":
        return cmd_upgrade(args.database_url, args.revision)
    elif args.command == "downgrade":
        return cmd_downgrade(args.database_url, args.revision)
    elif args.command == "current":
        return cmd_current(args.database_url)
    elif args.command == "history":
        return cmd_history(args.database_url)
    elif args.command == "stamp":
        return cmd_stamp(args.database_url, args.revision)
    elif args.command == "seed":
        # Note: cmd_seed expects (seed_dir, database_url) but argparse provides them in that order
        # However, users might provide them swapped, so the function has logic to detect and swap
        return cmd_seed(args.seed_dir, args.database_url)
    elif args.command == "truncate":
        return cmd_truncate(args.database_url, force=args.force)
    else:
        parser.print_help()
        return 1


if __name__ == "__main__":
    sys.exit(main())
