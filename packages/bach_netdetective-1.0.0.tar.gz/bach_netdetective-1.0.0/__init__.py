"""MCP Server for Netdetective"""
