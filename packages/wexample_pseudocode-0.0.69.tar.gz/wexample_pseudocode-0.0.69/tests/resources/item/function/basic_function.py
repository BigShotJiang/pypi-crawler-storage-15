from __future__ import annotations


def add(a: int, b: int) -> int:
    """Calculate the sum of two ints.

    :param a: The first operand.
    :param b: The second operand.
    :return: The sum of the two numbers.
    """
