from __future__ import annotations

MAX_RETRIES = 3  # Maximum number of retries for API calls
API_BASE_URL = "https://api.example.com"  # Base URL for the API
