"""
XGO智能体模块
提供开箱即用的机器人控制智能体
"""
from .xgo_agent import XGOAgent

__all__ = ['XGOAgent']
__version__ = '1.0.0'
