# Django Settings

::: ninja.conf.Settings
    rendering:
      show_source: False
      show_root_toc_entry: False