# Ask AI

Please feel free to share any questions or describe any problems you're encountering. Simply enter your text in the chat, and I'll be happy to assist you.

<style>
.serenity_chat__powered { display: none !important; }
.md-sidebar--secondary { display: none !important; }
.serenity_widget__container {
    max-width: 1200px !important;
}

.serenity_app {
    --serenity-answer-code-bg: #fafafa;
    --serenity-widget-bg: #ffffff;
}
</style>

<div id="serenity"></div>

<script>
var SERENITY_WIDGET = {
    api_url: "https://public.serenitygpt.com/api/v2/",
    api_token: "FqbM1QFShh5mGOD7",
    popup: false,
};
</script>
<script src="https://js.serenitygpt.com/widget.js"></script>
