
from .version import version as __version__

# __all__ = []  # defines which functions, variables etc. will be loaded when running "from pyonset import *"
