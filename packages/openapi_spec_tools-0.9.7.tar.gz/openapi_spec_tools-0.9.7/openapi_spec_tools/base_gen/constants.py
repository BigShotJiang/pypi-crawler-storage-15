"""Common definitions for code generation."""
NL = "\n"
SEP1 = "\n    "
SEP2 = "\n        "

# map of supported collections to their Python types
COLLECTIONS = {
    "array": "list",
}
