from ._config import setup_logging

__all__ = ["setup_logging"]
