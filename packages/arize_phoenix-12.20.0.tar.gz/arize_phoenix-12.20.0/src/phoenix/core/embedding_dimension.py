from dataclasses import dataclass


@dataclass
class EmbeddingDimension:
    name: str
