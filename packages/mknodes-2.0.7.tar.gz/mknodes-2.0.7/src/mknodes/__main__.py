"""Entry point for `python -m mknodes`."""

from mknodes.cli import main


if __name__ == "__main__":
    main()
