# test_dscheck.py

import pytest

def test_something():
   import rda_python_dscheck.PgCheck
   import rda_python_dscheck.pg_check
   import rda_python_dscheck.dscheck
