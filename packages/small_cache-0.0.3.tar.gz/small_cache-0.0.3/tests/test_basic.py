import small_cache as m

def test_create():
    m.SmallCache(["test1","2"])

