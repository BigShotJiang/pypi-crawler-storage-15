.. automodule :: nose.loader
:members: