.. automodule :: nose.proxy
:members: