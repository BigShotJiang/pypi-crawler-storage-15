.. automodule :: nose.commands
:members: