.. automodule :: nose.selector
:members: