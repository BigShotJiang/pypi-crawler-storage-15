.. automodule :: nose.suite
:members: