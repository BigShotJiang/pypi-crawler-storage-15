.. automodule :: nose.result
:members: