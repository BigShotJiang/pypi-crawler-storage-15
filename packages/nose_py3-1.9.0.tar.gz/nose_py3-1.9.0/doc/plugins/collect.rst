Collect: Collect tests quickly
==============================

.. autoplugin :: nose.plugins.collect