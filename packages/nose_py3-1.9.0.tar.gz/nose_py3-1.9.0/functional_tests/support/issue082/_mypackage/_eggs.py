"""
>>> True
False
"""
"""
>>> True
False
"""
