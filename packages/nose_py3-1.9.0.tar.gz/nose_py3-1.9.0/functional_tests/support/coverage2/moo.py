def moo():
    print
    'covered'
