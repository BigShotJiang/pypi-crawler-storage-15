from unittest import TestCase


class TestBase(TestCase):
    def test_a(self):
        assert 1 == 1
