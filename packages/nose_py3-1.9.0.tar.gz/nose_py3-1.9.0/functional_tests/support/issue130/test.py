def setup():
    raise Exception("KABOOM")


def test_foo():
    assert (1 == 1)
