def b():
    pass
