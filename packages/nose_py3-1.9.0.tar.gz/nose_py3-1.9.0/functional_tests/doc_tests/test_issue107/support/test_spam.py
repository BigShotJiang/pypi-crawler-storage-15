def test_spam():
    assert True


def test_eggs():
    pass
