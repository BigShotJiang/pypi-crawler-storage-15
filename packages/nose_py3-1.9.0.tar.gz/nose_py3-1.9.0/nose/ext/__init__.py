"""
External or vendor files
"""
