"""Defines cli methods."""
