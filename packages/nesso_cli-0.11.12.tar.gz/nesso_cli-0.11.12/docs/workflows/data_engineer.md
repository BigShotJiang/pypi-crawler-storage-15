# Data Engineer workflow
In this document, we describe how a Data Engineer would interact with the `nesso` data platform.

## Initial set up

## Creating ETL jobs

## Troubleshooting

## Monitoring & alerting

## Data governance

## Security
