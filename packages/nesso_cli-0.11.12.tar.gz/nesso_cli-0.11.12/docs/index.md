# nesso-cli
{%
    include-markdown "../README.md"
    start="<!-- body-begin -->"
    end="<!-- body-end -->"
%}
