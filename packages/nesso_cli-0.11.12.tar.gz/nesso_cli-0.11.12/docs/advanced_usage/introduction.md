# Advanced Usage

In this section, we cover advanced usage of `nesso models` CLI, such as:

- handling mapping tables (seeds)
- adding custom macros
- and more!
