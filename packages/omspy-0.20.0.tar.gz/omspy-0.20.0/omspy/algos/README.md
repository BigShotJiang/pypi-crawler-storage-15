## Introduction

This module contains some commonly used algorithms for efficient trade execution.

These are different from orders since they have more controls to tune and work differently than plain order types.
