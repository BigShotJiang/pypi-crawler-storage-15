# SPDX-FileCopyrightText: 2025-present Vasencheg <roman.vasilev@nobitlost.com>
#
# SPDX-License-Identifier: MIT
