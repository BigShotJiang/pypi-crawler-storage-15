"""Tests for cloud_logging_handler."""
