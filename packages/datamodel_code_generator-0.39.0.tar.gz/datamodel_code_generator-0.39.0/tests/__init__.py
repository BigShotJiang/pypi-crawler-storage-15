"""Test suite for datamodel-code-generator."""
