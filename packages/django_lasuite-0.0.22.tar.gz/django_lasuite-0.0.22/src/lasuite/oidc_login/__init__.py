"""OIDC authentication module."""
