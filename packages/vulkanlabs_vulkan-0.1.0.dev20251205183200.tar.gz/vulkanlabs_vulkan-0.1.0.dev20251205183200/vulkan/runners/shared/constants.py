APP_CLIENT_KEY = "vulkan_app_client"

RUN_CONFIG_KEY = "vulkan_run_config"
POLICY_CONFIG_KEY = "vulkan_policy_config"
