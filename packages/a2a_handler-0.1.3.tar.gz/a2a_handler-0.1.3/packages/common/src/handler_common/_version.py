"""Single source of truth for Handler version."""

__version__ = "0.1.3"
