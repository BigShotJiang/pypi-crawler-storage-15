"""
Merkle Blockchain Module
========================

This module implements an advanced blockchain with Merkle tree verification
and proof-of-work consensus mechanism.
"""

import hashlib
import json
import time
from typing import List, Tuple

def sha256(b: bytes) -> str: 
    return hashlib.sha256(b).hexdigest()

def hstr(s: str) -> str: 
    return sha256(s.encode())

class MerkleTree:
    """Merkle Tree implementation for transaction verification."""
    
    def __init__(self, leaves: List[str]):
        self.leaves = [hstr(l) for l in leaves]
        self.levels = [self.leaves] if self.leaves else []
        self.build()
        
    def build(self):
        """Build the Merkle tree from leaves to root."""
        cur = self.leaves.copy()
        while len(cur) > 1:
            nxt = []
            for i in range(0, len(cur), 2):
                a = cur[i]; b = cur[i+1] if i+1 < len(cur) else a
                nxt.append(sha256(bytes.fromhex(a) + bytes.fromhex(b)))
            cur = nxt
            self.levels.append(cur)
            
    def root(self) -> str: 
        return self.levels[-1][0] if self.levels else ''
        
    def proof(self, idx: int) -> List[Tuple[str,str]]:
        """Generate Merkle proof for a transaction at given index."""
        if not (0 <= idx < len(self.leaves)): 
            raise IndexError
        p=[]; i=idx
        for lvl in self.levels[:-1]:
            sib = i+1 if i%2==0 else i-1
            if sib >= len(lvl): sib = i
            p.append((lvl[sib], 'right' if i%2==0 else 'left'))
            i//=2
        return p
        
    @staticmethod
    def verify(leaf: str, proof: List[Tuple[str,str]], root: str) -> bool:
        """Verify a Merkle proof."""
        cur = hstr(leaf)
        for s, pos in proof:
            cur = sha256(bytes.fromhex(cur) + bytes.fromhex(s)) if pos=='right' else sha256(bytes.fromhex(s) + bytes.fromhex(cur))
        return cur == root

class Block:
    """Block with Merkle tree root and proof-of-work."""
    
    def __init__(self, idx:int, txs:List[str], prev:str, diff:int=2):
        self.idx, self.txs, self.prev, self.diff = idx, txs[:], prev, diff
        self.ts = time.time(); self.nonce = 0
        self.merkle = MerkleTree(self.txs).root()
        self.hash = self._hash()
        
    def _hash(self) -> str:
        """Calculate block hash."""
        obj = {'idx':self.idx,'ts':self.ts,'prev':self.prev,'nonce':self.nonce,'merkle':self.merkle,'cnt':len(self.txs)}
        return sha256(json.dumps(obj, sort_keys=True).encode())
        
    def mine(self):
        """Mine the block using proof-of-work."""
        target = '0'*self.diff
        while True:
            self.hash = self._hash()
            if self.hash.startswith(target): break
            self.nonce += 1

class Blockchain:
    """Advanced blockchain with Merkle tree verification."""
    
    def __init__(self, diff=2):
        self.diff = diff; self.chain: List[Block] = []
        g = Block(0, ['genesis'], '0'*64, diff); g.mine(); self.chain.append(g)
        
    def add(self, txs:List[str]) -> Block:
        """Add a new block with transactions."""
        b = Block(len(self.chain), txs, self.chain[-1].hash, self.diff); b.mine(); self.chain.append(b); return b
        
    def valid(self) -> bool:
        """Validate the entire blockchain."""
        for i in range(1,len(self.chain)):
            b, p = self.chain[i], self.chain[i-1]
            if b.prev != p.hash: return False
            if not b.hash.startswith('0'*b.diff): return False
            if MerkleTree(b.txs).root() != b.merkle: return False
            if b._hash() != b.hash: return False
        return True

def demo():
    """Run a demonstration of the Merkle blockchain."""
    print("Running Merkle Blockchain Demo...")
    
    bc = Blockchain(diff=3)
    b1 = bc.add(["Alice->Bob:5","Carol->Dave:2","Eve->Frank:7"])
    print("Block", b1.idx, "hash", b1.hash, "merkle", b1.merkle)
    b2 = bc.add(["Ivy->John:3","Alice->Carol:1"])
    print("Block", b2.idx, "hash", b2.hash)
    print("Chain valid?", bc.valid())
    
    # Merkle proof example
    proof = MerkleTree(b1.txs).proof(1)
    print("Proof for tx:", b1.txs[1])
    print(proof)
    print("Verify:", MerkleTree.verify(b1.txs[1], proof, b1.merkle))

if __name__ == '__main__':
    demo()