from .columninfo import ColumnInfo

__all__ = [
    "ColumnInfo",
]
