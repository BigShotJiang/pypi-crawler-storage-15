# invalid_search

Simple phone number search module.

## Install
pip install invalid_search

## Usage

import invalid_search as info

print(info("9891xxxxxx"))
