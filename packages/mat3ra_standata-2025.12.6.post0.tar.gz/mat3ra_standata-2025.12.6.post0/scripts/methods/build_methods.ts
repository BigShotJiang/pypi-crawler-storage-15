import { MethodsProcessor } from "../processors/MethodsProcessor";

new MethodsProcessor(__dirname).process();
