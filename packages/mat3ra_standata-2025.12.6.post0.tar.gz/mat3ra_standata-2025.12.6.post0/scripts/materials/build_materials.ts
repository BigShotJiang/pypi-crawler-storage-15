import { MaterialsProcessor } from "../processors/MaterialsProcessor";

const processor = new MaterialsProcessor(__dirname);
processor.process();
