#!/bin/bash
echo "Building project..."
