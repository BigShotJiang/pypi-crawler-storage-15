"""
Exposing version and used on the cli command.

Update this file accordingly with pyproject.toml.
"""

__version__ = "1.10.1"
VERSION = __version__.split(".")
