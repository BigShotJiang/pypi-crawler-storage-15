from __future__ import annotations

from memu.prompts.category_summary.category import PROMPT

CATEGORY_SUMMARY_PROMPT = PROMPT.strip()

__all__ = ["CATEGORY_SUMMARY_PROMPT"]
