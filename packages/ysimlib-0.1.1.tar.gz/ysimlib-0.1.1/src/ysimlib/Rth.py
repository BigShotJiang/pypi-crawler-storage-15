import requests
import re

from ysimlib.getData import fetch_yageo_part
from ysimlib.getData import pretty_print_json

from .dimensions import get_dimensions

# Rth aus Calculation_Film Matrix - Franz Wurmser 2019-12-10 1

def get_Rth_from_dimensions(L, H, W):
    surface =2*((L * W)+ (L * H) + (H * W))/100     #  /100 für in cm umwandeln    
    K = 6.1472/surface**0.484                       # K [mW/°C*cm2]
    Rth = 1000/(K * surface)
    return Rth

def get_thermal_resistance(pn: str):
    # url = f"https://search.kemet.com/intellidata/unique-parts/{pn}"
    # resp = requests.get(url)
    # resp.raise_for_status()
    # data = resp.json()

    data = fetch_yageo_part(pn)
    #pretty_print_json(data)
    if not isinstance(data, dict):
        dim = get_dimensions(pn)
        print("dimensions LxHxT", dim)
        rth = get_Rth_from_dimensions(dim["L"],dim["W"],dim["T"])
        return rth

    for param in data.get("parameterValues", []) or []:
        pname = (param.get("parameterName") or "").lower()
        val = param.get("formattedValue") or param.get("value") or ""
        if (pname == "reference size"):
            print(val)
        if "miscellaneous" in pname and "rth" in str(val).lower():
            import re
            m = re.search(r"([-+]?\\d*\\.?\\d+)", str(val))
            if m:
                return float(m.group(1))

    return None
        
    