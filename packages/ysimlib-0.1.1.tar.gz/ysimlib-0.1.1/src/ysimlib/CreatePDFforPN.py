import matplotlib.pyplot as plt
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.colors import Color
from datetime import datetime


def create_pdf_for_pn(
    pn: str,
    df_result,
    df_summary,
    Project: str,
    Customer: str,
    CustomerContact: str,
    CustomerEmail: str,
    Version: str,
    T_amb: float,
    NoOfCapacitors: int,
    AuthorEmail: str,
    plot_function,        # z.B. plot_pn_summary
    n_caps: int = None,   # optional
    logo_path: str = "img/yageo_group.png"
):

    # --- Daten zur PN holen ---
    row = df_summary[df_summary["pn"] == pn].iloc[0]
    dT_calc_sum = float(row["dT_calc"])
    dT_calc_int = int(round(dT_calc_sum))

    # --- Dateinamen vorbereiten ---
    file_base = f"{pn}_dT{dT_calc_int}_{n_caps}C"
    plot_path = file_base + ".png"
    pdf_path = file_base + ".pdf"

    # --- Plot erzeugen ---
    plot_function(pn, df_result, df_summary)

    # --- PDF starten ---
    c = canvas.Canvas(pdf_path, pagesize=A4)
    page_width, page_height = A4

    # --- 1. Logo ---
    c.drawImage(
        logo_path,
        40,
        page_height - 60,
        width=60,
        height=15,
        mask="auto"
    )

    # --- 2. Wasserzeichen ---
    c.saveState()
    c.setFont("Helvetica-Bold", 60)
    c.setFillColor(Color(0.7, 0.7, 0.7, alpha=0.3))
    c.translate(300, 500)
    c.rotate(22.5)
    c.drawCentredString(0, 0, "PRELIMINARY")
    c.restoreState()

    # --- 3. Titel ---
    c.setFont("Helvetica-Bold", 14)
    c.drawString(
        140,
        page_height - 60,
        f"Project: {Project} - {Customer}   v{Version}"
    )

    # --- 4. Textblock vorbereiten ---
    c.setFont("Helvetica", 11)
    text = (
        f"Customer: {Customer}\n"
        f"Contact: {CustomerContact}, {CustomerEmail}\n"
        f"max ambient Temperature : {T_amb}°C\n"
        "\n"
        f"Partnumber : {pn}\n"
        "\n"
        f"No. of capacitors in parallel : {NoOfCapacitors} pcs\n"
        f"Component Temperature rise : {dT_calc_sum:.1f}°C\n"
        f"Total Temperature of the capacitors : {dT_calc_sum + T_amb:.1f}°C\n"
    )

    # --- Textblock zeichnen ---
    start_y = page_height - 100
    for i, line in enumerate(text.split("\n")):
        c.drawString(80, start_y - i * 15, line)

    # --- 5. Specsheet Link ---
    c.linkURL(
        f"https://yageogroup.com/download/specsheet/{pn}",
        (80, 700, 260, 670),
        relative=0
    )

    # --- 6. Plot einfügen ---
    c.drawImage(
        plot_path,
        80,
        100,
        width=400,
        height=300
    )

    # --- 7. Timestamp + Autor (mit Link) ---
    timestamp = datetime.now().strftime("%d.%m.%Y %H:%M:%S")
    c.setFont("Helvetica-Oblique", 8)
    x, y = 40, 20

    c.drawString(x, y, f"Erstellt am: {timestamp} by {AuthorEmail}")
    c.linkURL(
        f"mailto:{AuthorEmail}",
        (x, y, x + 200, y + 12),
        relative=0
    )

    # --- SPEICHERN ---
    c.save()
    print(f"PDF saved: {pdf_path}")