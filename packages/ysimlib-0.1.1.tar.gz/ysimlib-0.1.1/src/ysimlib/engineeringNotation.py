

# en stands for engieering notation 

def en(value: float, suffix: str = "Ω") -> str:
    """
    Skaliert einen Wert von 1e-12 bis 1e15 und hängt den angegebenen Suffix an.
    Beispiel: Ohm, Farad, Henry
    """
    if value == 0:
        return f"0 {suffix}"

    v = abs(value)
    if v < 1e-9:
        s = f"{v*1e12:.3f} p{suffix}"
    elif v < 1e-6:
        s = f"{v*1e9:.3f} n{suffix}"
    elif v < 1e-3:
        s = f"{v*1e6:.3f} µ{suffix}"
    elif v < 1:
        s = f"{v*1e3:.3f} m{suffix}"
    elif v < 1e3:
        s = f"{v:.3f} {suffix}"
    elif v < 1e6:
        s = f"{v/1e3:.3f} k{suffix}"
    elif v < 1e9:
        s = f"{v/1e6:.3f} M{suffix}"
    elif v < 1e12:
        s = f"{v/1e9:.3f} G{suffix}"
    elif v < 1e15:
        s = f"{v/1e12:.3f} T{suffix}"
    else:
        s = f"{v/1e15:.3f} P{suffix}"

    return f"-{s}" if value < 0 else s



def end(value: float, suffix: str = "Ω", digits:int =3) -> str:

    if value == 0:
        return f"0 {suffix}"

    v = abs(value)
    if v < 1e-9:
        s = f"{v*1e12:.{digits}f}p{suffix}"
    elif v < 1e-6:
        s = f"{v*1e9:.{digits}f}n{suffix}"
    elif v < 1e-3:
        s = f"{v*1e6:.{digits}f}µ{suffix}"
    elif v < 1:
        s = f"{v*1e3:.{digits}f}m{suffix}"
    elif v < 1e3:
        s = f"{v:.{digits}f}{suffix}"
    elif v < 1e6:
        s = f"{v/1e3:.{digits}f}k{suffix}"
    elif v < 1e9:
        s = f"{v/1e6:.{digits}f}M{suffix}"
    elif v < 1e12:
        s = f"{v/1e9:.{digits}f}G{suffix}"
    elif v < 1e15:
        s = f"{v/1e12:.{digits}f}T{suffix}"
    else:
        s = f"{v/1e15:.{digits}f}P{suffix}"

    return f"-{s}" if value < 0 else s