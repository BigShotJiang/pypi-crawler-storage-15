# dc_link_filter.py
import math

def printDCFamilies(df):
    cnt =0
    for i in df:
        print(f"{i["Fam"]:<5} \t  {i["Vr"]:4} \t {i["Vop"]:4}")
        cnt = cnt+1
    print(f"NoOfMatches = {cnt}")


def get_DCFilmFamilies(Vapp: float, T_amb: float):
# Temperaturklassen in °C
    T_RANGE = [70, 85, 105, 115, 125, 135]

# Vollständige dc_link-Liste (1:1 von deinem JS übernommen)
    dc_link = [
        {"family": "C4AF-F", "Vrated": 250,  "TempRated": 85, "volt": [ 250,  250, 175,   0,   0,   0],  "factor": [1.00, 1.00, 0.70, 0.00, 0.00, 0.00]},
        {"family": "C4AF-F", "Vrated": 310,  "TempRated": 85, "volt": [ 310,  310, 215,   0,   0,   0],  "factor": [1.00, 1.00, 0.69, 0.00, 0.00, 0.00]},
        {"family": "C4AF-F", "Vrated": 350,  "TempRated": 85, "volt": [ 350,  350, 245,   0,   0,   0],  "factor": [1.00, 1.00, 0.70, 0.00, 0.00, 0.00]},
        {"family": "C4AF-F", "Vrated": 400,  "TempRated": 85, "volt": [ 400,  400, 280,   0,   0,   0],  "factor": [1.00, 1.00, 0.70, 0.00, 0.00, 0.00]},
        {"family": "C4AF-F", "Vrated": 500,  "TempRated": 85, "volt": [ 500,  500, 350,   0,   0,   0],  "factor": [1.00, 1.00, 0.70, 0.00, 0.00, 0.00]},
        {"family": "C4AF-F", "Vrated": 600,  "TempRated": 85, "volt": [ 600,  600, 420,   0,   0,   0],  "factor": [1.00, 1.00, 0.70, 0.00, 0.00, 0.00]},
        
        {"family": "C4AF-T", "Vrated": 250,  "TempRated": 85, "volt": [ 250,  250, 175,   0,   0,   0],  "factor": [1.00, 1.00, 0.70, 0.00, 0.00, 0.00]},
        {"family": "C4AF-T", "Vrated": 310,  "TempRated": 85, "volt": [ 310,  310, 215,   0,   0,   0],  "factor": [1.00, 1.00, 0.69, 0.00, 0.00, 0.00]},
        {"family": "C4AF-T", "Vrated": 400,  "TempRated": 85, "volt": [ 400,  400, 280,   0,   0,   0],  "factor": [1.00, 1.00, 0.70, 0.00, 0.00, 0.00]},
        {"family": "C4AF-T", "Vrated": 500,  "TempRated": 85, "volt": [ 500,  500, 350,   0,   0,   0],  "factor": [1.00, 1.00, 0.70, 0.00, 0.00, 0.00]},
        {"family": "C4AF-T", "Vrated": 600,  "TempRated": 85, "volt": [ 600,  600, 420,   0,   0,   0],  "factor": [1.00, 1.00, 0.70, 0.00, 0.00, 0.00]},

        {"family": "C4AQ",   "Vrated": 650,  "TempRated": 70, "volt": [ 650,  600, 450,   0,   0,   0],  "factor": [1.00, 0.92, 0.69, 0.00, 0.00, 0.00]},
        {"family": "C4AQ",   "Vrated": 800,  "TempRated": 70, "volt": [ 800,  700, 550,   0,   0,   0],  "factor": [1.00, 0.88, 0.69, 0.00, 0.00, 0.00]},
        {"family": "C4AQ",   "Vrated": 1100, "TempRated": 70, "volt": [1100,  900, 700,   0,   0,   0],  "factor": [1.00, 0.82, 0.64, 0.00, 0.00, 0.00]},
        {"family": "C4AQ",   "Vrated": 1300, "TempRated": 70, "volt": [1300, 1100, 850,   0,   0,   0],  "factor": [1.00, 0.85, 0.65, 0.00, 0.00, 0.00]},
        {"family": "C4AQ",   "Vrated": 1500, "TempRated": 70, "volt": [1500, 1200, 900,   0,   0,   0],  "factor": [1.00, 0.80, 0.60, 0.00, 0.00, 0.00]},

        {"family": "C4AQ-M", "Vrated": 500,  "TempRated": 85, "volt": [ 600,  500, 350,   0,   0,   0],  "factor": [1.20, 1.00, 0.70, 0.00, 0.00, 0.00]},
        {"family": "C4AQ-M", "Vrated": 700,  "TempRated": 85, "volt": [ 800,  700, 490,   0,   0,   0],  "factor": [1.14, 1.00, 0.70, 0.00, 0.00, 0.00]},
        {"family": "C4AQ-M", "Vrated": 800,  "TempRated": 85, "volt": [ 960,  800, 560,   0,   0,   0],  "factor": [1.20, 1.00, 0.70, 0.00, 0.00, 0.00]},
        {"family": "C4AQ-M", "Vrated": 900,  "TempRated": 85, "volt": [1100,  900, 650,   0,   0,   0],  "factor": [1.22, 1.00, 0.72, 0.00, 0.00, 0.00]},
        {"family": "C4AQ-M", "Vrated": 1000, "TempRated": 85, "volt": [1200, 1000, 700,   0,   0,   0],  "factor": [1.20, 1.00, 0.70, 0.00, 0.00, 0.00]},
        {"family": "C4AQ-M", "Vrated": 1100, "TempRated": 85, "volt": [1320, 1100, 770,   0,   0,   0],  "factor": [1.20, 1.00, 0.70, 0.00, 0.00, 0.00]},
        {"family": "C4AQ-M", "Vrated": 1200, "TempRated": 85, "volt": [1440, 1200, 850,   0,   0,   0],  "factor": [1.20, 1.00, 0.71, 0.00, 0.00, 0.00]},

        {"family": "C4AQ-P", "Vrated": 450,  "TempRated": 85, "volt": [ 500,  450, 350, 315, 270,   0],  "factor": [1.11, 1.00, 0.78, 0.70, 0.60, 0.00]},
        {"family": "C4AQ-P", "Vrated": 600,  "TempRated": 85, "volt": [ 650,  600, 450, 420, 360,   0],  "factor": [1.08, 1.00, 0.75, 0.70, 0.60, 0.00]},
        {"family": "C4AQ-P", "Vrated": 700,  "TempRated": 85, "volt": [ 800,  700, 550, 490, 420,   0],  "factor": [1.14, 1.00, 0.79, 0.70, 0.60, 0.00]},
        {"family": "C4AQ-P", "Vrated": 900,  "TempRated": 85, "volt": [1100,  900, 700, 630, 540,   0],  "factor": [1.22, 1.00, 0.78, 0.70, 0.60, 0.00]},
        {"family": "C4AQ-P", "Vrated": 1100, "TempRated": 85, "volt": [1300, 1100, 850, 770, 660,   0],  "factor": [1.18, 1.00, 0.77, 0.70, 0.60, 0.00]},

        {"family": "C4AK",   "Vrated": 450,  "TempRated": 85, "volt": [ 450,  450, 400, 375, 350, 270],  "factor": [1.00, 1.00, 0.89, 0.83, 0.78, 0.60]},
        {"family": "C4AK",   "Vrated": 600,  "TempRated": 85, "volt": [ 600,  600, 540, 500, 460, 350],  "factor": [1.00, 1.00, 0.90, 0.83, 0.77, 0.58]},
        {"family": "C4AK",   "Vrated": 700,  "TempRated": 85, "volt": [ 700,  700, 600, 550, 500, 400],  "factor": [1.00, 1.00, 0.86, 0.79, 0.71, 0.57]},
        {"family": "C4AK",   "Vrated": 900,  "TempRated": 85, "volt": [ 900,  900, 800, 760, 720, 500],  "factor": [1.00, 1.00, 0.89, 0.84, 0.80, 0.56]},
        {"family": "C4AK",   "Vrated": 1000, "TempRated": 85, "volt": [ 1000, 1000, 900, 850, 800, 550], "factor": [1.00, 1.00, 0.90, 0.85, 0.80, 0.55]},

        {"family": "C4AU",   "Vrated": 500,  "TempRated": 85, "volt": [ 600,  500, 350, 300, 250,   0],  "factor": [1.20, 1.00, 0.70, 0.00, 0.00, 0.00]},
        {"family": "C4AU",   "Vrated": 700,  "TempRated": 85, "volt": [ 800,  700, 490, 420, 350,   0],  "factor": [1.14, 1.00, 0.70, 0.00, 0.00, 0.00]},
        {"family": "C4AU",   "Vrated": 800,  "TempRated": 85, "volt": [ 960,  800, 560, 480, 400,   0],  "factor": [1.20, 1.00, 0.70, 0.00, 0.00, 0.00]},
        {"family": "C4AU",   "Vrated": 1100, "TempRated": 85, "volt": [1320, 1100, 770, 660, 550,   0],  "factor": [1.20, 1.00, 0.70, 0.00, 0.00, 0.00]},
        {"family": "C4AU",   "Vrated": 1200, "TempRated": 85, "volt": [1440, 1200, 850, 720, 600,   0],  "factor": [1.20, 1.00, 0.71, 0.00, 0.00, 0.00]},
        {"family": "C4AU",   "Vrated": 1300, "TempRated": 85, "volt": [1560, 1300, 770,  910, 780,  650],  "factor": [1.20, 1.00, 0.70, 0.00, 0.00, 0.00]},
        {"family": "C4AU",   "Vrated": 1400, "TempRated": 85, "volt": [1400, 1400, 770,  980, 840,  700],  "factor": [1.20, 1.00, 0.70, 0.00, 0.00, 0.00]}, 
        {"family": "C4AU",   "Vrated": 1500, "TempRated": 85, "volt": [1800, 1500, 770, 1050, 900,  750],  "factor": [1.20, 1.00, 0.70, 0.00, 0.00, 0.00]}, 
    ]



      
#        Überprüft, welche Kondensatorfamilien bei Umgebungstemperatur T_amb
#        eine maximale Betriebsspannung > Vapp zulassen.

    result = []

    # Index für Temperaturbereich finden
    T_start, T_cat, T_idx = -1, 0, 0
    for i, T in enumerate(T_RANGE):
        if T >= T_amb:
            T_start = i
            T_cat = T
            T_idx = i
            break

    if T_start == -1:
        T_start = len(T_RANGE) - 1
        T_cat = T_RANGE[-1]
        T_idx = len(T_RANGE) - 1

    for data in dc_link:
        m_slope = data["factor"][T_idx]
        V_70 = data["volt"][0]
        V_85 = data["volt"][1]
        Vr = data["Vrated"]
        Tr = data["TempRated"]
        VT = data["volt"][T_idx]

        T_max = max(0, T_amb - Tr)
        family = data["family"]
        #print(f"Vop({T_amb:4.0f}) for {family:<6} Vr {Vr:4.0f}  ----   Tr= {Tr} slope = {m_slope:1.2f}, V({T_cat:4.0f}) = {VT:4.0f} , V(70°C) = {V_70}, V(80°C)={V_85}")
        
        if (Tr == T_amb or T_cat == Tr ):
            continue
        

        if V_70 > V_85:
            Vop_max1 = round(Vr + ((V_70 - Vr) / (15 / (Tr - T_amb))))
        else:
            Vop_max1 = Vr

#        T_max = max(0, T_amb - Tr)
        Vop_max2 = round(Vr - (T_max) / (T_cat - Tr) * (Vr - (m_slope * Vr)))

        Vop_max = min(Vop_max1, Vop_max2, V_70)

        if Vop_max > Vapp:
            result.append({"Fam": data["family"], "Vr": Vr, "Vop": Vop_max})
        
        # print(f"Vop({T_amb:4.0f})={Vop_max:4.0f} for {family:<6} Vr {Vr:4.0f}  ----   Tr= {Tr} slope = {m_slope:1.2f}, V({T_cat:4.0f}) = {VT:4.0f} , V(70°C) = {V_70}, V(80°C)={V_85}")

    return result