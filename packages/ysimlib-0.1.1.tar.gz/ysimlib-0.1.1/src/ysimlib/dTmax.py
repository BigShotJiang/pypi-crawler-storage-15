# Definition der Tabelle
dT_max = [ 
    {"fam":"C4AQ-P","dT":30, "Tamb_derat":75, "Tamb_max":125, "Irms_max":"100%"},
    {"fam":"C4AQ-M","dT":30, "Tamb_derat":70, "Tamb_max":105, "Irms_max":"100%"},
    {"fam":"C4AK",  "dT":30, "Tamb_derat":85, "Tamb_max":130, "Irms_max":"115%"},
    {"fam":"C4AQ",  "dT":30, "Tamb_derat":70, "Tamb_max":105, "Irms_max":"100%"},
    {"fam":"C4AU",  "dT":30, "Tamb_derat":70, "Tamb_max":105, "Irms_max":"100%"},
    {"fam":"R75",   "dT":20, "Tamb_derat":85, "Tamb_max":105, "Irms_max":"100%"},
    {"fam":"R75H",  "dT":20, "Tamb_derat":90, "Tamb_max":125, "Irms_max":"100%"},
    {"fam":"R76",   "dT":40, "Tamb_derat":60, "Tamb_max":110, "Irms_max":"140%"},
    {"fam":"R76H",  "dT":40, "Tamb_derat":60, "Tamb_max":125, "Irms_max":"160%"},
]

def calc_dT(fam: str, Tamb: float) -> float:
    """
    Berechnet den erlaubten dT-Wert für die angegebene Familie und Umgebungstemperatur Tamb.
    - Wenn Tamb <= dT_lim: fester dT.
    - Wenn Tamb > dT_lim: lineare Interpolation zwischen (dT_lim, dT) und (Tamb_max, 0).
    """
    # passenden Datensatz suchen
    rec = next((r for r in dT_max if r["fam"].lower() == fam.lower()), None)
    if not rec:
        raise ValueError(f"Familie {fam} nicht gefunden")
    
    dT = rec["dT"]
    Tamb_derat = rec["Tamb_derat"]
    Tamb_max = rec["Tamb_max"]

    if Tamb <= Tamb_derat:
        return dT
    elif Tamb >= Tamb_max:
        return 0.0
    else:
        # lineare Interpolation
        return dT * (Tamb_max - Tamb) / (Tamb_max - Tamb_derat)



def get_dTmax(family:str, Tamb: float):
    result = []
    for rec in dT_max:
        if (family == rec["fam"]):
            dT_val = calc_dT(family, Tamb)
            Irms = rec["Irms_max"]
            if dT_val > 0:   # nur Werte übernehmen, wenn dT_max > 0
                result.append({
                    "fam": family,
                    "dT_max": round(dT_val, 1),
                    "Irms_max": Irms
                })
    return result
    