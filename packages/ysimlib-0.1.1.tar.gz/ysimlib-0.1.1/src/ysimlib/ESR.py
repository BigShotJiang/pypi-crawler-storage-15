import requests

def get_esr_at_freq(pn, target_freqs):
    """
    Holt ESR-Werte für ein Bauteil von der KEMET-API
    und interpoliert linear zwischen den Frequenzen.
    """
    url = f"https://search.kemet.com/sim/plot/{pn}"
    data = requests.get(url).json()

    freqs = [v["frequency"] for v in data["frequency_values"]]
    esr = [v["esr"] for v in data["frequency_values"]]

    results = {}
    for f_target in target_freqs:
        # lineare Interpolation
        for i in range(len(freqs) - 1):
            if freqs[i] <= f_target <= freqs[i + 1]:
                f1, f2 = freqs[i], freqs[i + 1]
                e1, e2 = esr[i], esr[i + 1]
                val = e1 + (e2 - e1) * (f_target - f1) / (f2 - f1)
                results[f_target] = round(val, 6)
                break
        else:
            # falls außerhalb des Bereichs: nächster gültiger Wert
            if f_target < freqs[0]:
                results[f_target] = esr[0]
            elif f_target > freqs[-1]:
                results[f_target] = esr[-1]

    return results

