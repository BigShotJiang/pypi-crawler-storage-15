import math
import pandas as pd
import matplotlib.pyplot as plt

def absolute_humidity(T_c, RH):
    """Berechnet absolute Feuchte (g/m³) aus Temperatur [°C] und relativer Feuchte [%]."""
    e_s = 6.112 * math.exp((17.62 * T_c) / (243.12 + T_c))
    e = RH / 100.0 * e_s
    return 216.7 * e / (T_c + 273.15)


def relative_humidity_from_absolute(AH, T_c):
    """Berechnet relative Feuchte (%) bei konstanter absoluter Feuchte."""
    e_s = 6.112 * math.exp((17.62 * T_c) / (243.12 + T_c))
    return (AH * (T_c + 273.15)) / (216.7 * e_s) * 100


def humidity_change_plot(start_conditions, T_range):
    """
    Zeichnet den Verlauf der relativen Feuchte bei konstanter absoluter Feuchte
    für mehrere Startbedingungen.
    Links: rH [%], Rechts: konstante absolute Feuchte [g/m³].
    """
    Tmin, Tmax, step = T_range
    temps = list(range(Tmin, Tmax + 1, step))

    fig, ax1 = plt.subplots(figsize=(8,5))
    ax1.set_title("Relative Feuchte bei konstanter absoluter Feuchte")
    ax1.set_xlabel("Temperatur [°C]")
    ax1.set_ylabel("Relative Feuchte [%]")
    ax1.grid(True, alpha=0.3)

    # zweite y-Achse (rechte Seite)
    ax2 = ax1.twinx()
    ax2.set_ylabel("Absolute Feuchte [g/m³]", color="gray")

    for (T_start, RH_start) in start_conditions:
        AH = absolute_humidity(T_start, RH_start)
        RH_values = [relative_humidity_from_absolute(AH, T) for T in temps]
        label = f"{T_start}°C / {RH_start}% (AH={AH:.2f} g/m³)"
        ax1.plot(temps, RH_values, marker="o", label=label)
        # konstante AH-Linie auf rechter Achse
        ax2.plot([temps[0], temps[-1]], [AH, AH], "--", color="gray", alpha=0.4)
        print(f"{label}: RH({Tmax}°C) = {RH_values[-1]:.1f}%")

    ax1.legend(loc="center right")
    plt.tight_layout()
    plt.show()


# humidity_change_plot(
# start_conditions=[(25, 50), (55,30) , (85,85)],
# T_range=(0, 125, 10)
