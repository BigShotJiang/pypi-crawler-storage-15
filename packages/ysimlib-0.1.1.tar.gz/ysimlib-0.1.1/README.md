# ysimlib

tools for handling YAGEO components  MLCC, Polymer and Film capacitors

how to use it 

pip install ysimlib==0.1.0

avaialbe functions : 

parameter for the  functions :
pn: is a valid KEMET/YAGEO partnumber - 14 digits 
temperature:  is in a range from -55°C to +125°C
f_min : start frequency 10Hz minimum
f_max : stop frequency 10GHz maximum 

the return an array of list of tuples [(freq_1, value_1), (freq_2, value_2),(freq_3, value_3) ... (freq_n, value_n)]

Please note the frequencies above 1 GHz are extraploted 

### ATTENTION : the server delivers not always a full frequency range, sometimes at the end are empty tupels
###            Please check carefully 

function get_esr_data(
    pn: str,
    temperature: int = 25,
    f_min: float = 10_000,
    f_max: float = 500_000)

function get_current_data
    pn: str,
    temperature: int = 25,
    f_min: float = 10_000,
    f_max: float = 500_000)

function get_voltage_data(
    pn: str,
    temperature: int = 25,
    f_min: float = 10_000,
    f_max: float = 500_000)

function get_impedance_data(
    pn: str,
    temperature: int = 25,
    f_min: float = 10_000,
    f_max: float = 500_000)

function get_capacitance_data (  pn: str,
    temperature: int = 25,
    f_min: float = 10_000,
    f_max: float = 500_000)


get_thermal_resistance(pn)


get_Rth_from_dimensions(pn)





