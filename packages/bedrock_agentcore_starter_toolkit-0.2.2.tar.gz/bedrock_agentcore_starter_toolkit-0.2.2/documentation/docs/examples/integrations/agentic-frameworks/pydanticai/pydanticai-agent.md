```python
{% include "https://raw.githubusercontent.com/awslabs/amazon-bedrock-agentcore-samples/refs/heads/main/03-integrations/agentic-frameworks/pydanticai-agents/pydantic_bedrock_claude.py" %}
```
