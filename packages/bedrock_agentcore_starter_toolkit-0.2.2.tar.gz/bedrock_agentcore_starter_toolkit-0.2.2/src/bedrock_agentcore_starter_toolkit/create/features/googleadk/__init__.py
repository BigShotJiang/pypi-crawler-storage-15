"""GoogleADK Templates."""
