"""Events extraction."""

from sentinel.v1.services.extractors.events.extractor import EventsExtractor

__all__ = ["EventsExtractor"]
