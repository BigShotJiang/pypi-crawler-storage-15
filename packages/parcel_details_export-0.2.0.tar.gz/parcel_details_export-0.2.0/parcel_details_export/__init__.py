from .parcel_details import export_parcel_pdf

__version__ = "0.1.0"
__all__ = ["export_parcel_pdf"]