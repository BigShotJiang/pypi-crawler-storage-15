#!/usr/bin/env python
"""Entry point for SurrealDB MCP Server."""

from surreal_mcp import main

if __name__ == "__main__":
    main()
