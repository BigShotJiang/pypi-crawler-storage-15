"""Allow running the module directly with python -m surreal_mcp."""

from .server import main

if __name__ == "__main__":
    main()