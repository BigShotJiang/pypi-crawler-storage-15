"""Tests for MCP tool handlers."""
