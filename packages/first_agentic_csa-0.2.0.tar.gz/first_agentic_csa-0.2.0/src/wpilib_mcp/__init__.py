"""WPILib MCP Server - Plugin-based FRC documentation agent."""

__version__ = "0.1.0"




