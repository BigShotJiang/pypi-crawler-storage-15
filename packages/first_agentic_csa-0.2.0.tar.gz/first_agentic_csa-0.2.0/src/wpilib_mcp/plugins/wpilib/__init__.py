"""WPILib documentation plugin."""

from .plugin import Plugin

__all__ = ["Plugin"]




