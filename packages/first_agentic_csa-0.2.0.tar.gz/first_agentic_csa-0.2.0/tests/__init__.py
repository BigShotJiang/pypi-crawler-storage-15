"""Tests for WPILib MCP server."""




