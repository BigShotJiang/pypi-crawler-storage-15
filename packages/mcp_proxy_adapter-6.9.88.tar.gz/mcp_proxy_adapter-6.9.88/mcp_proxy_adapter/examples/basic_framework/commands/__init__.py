"""Basic Framework Commands.

Commands for the basic framework example.
"""
