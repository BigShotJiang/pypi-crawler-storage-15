"""MCP Server for Animals By Api Ninjas"""
