To create a new packaging level:

1.  Go to *Inventory \> Configuration \> Products \> Product Packaging
    Level*.
2.  You can create/edit/delete packaging levels
