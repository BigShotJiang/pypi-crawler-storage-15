from setuptools import setup, find_packages

setup(
    name="odd-or-even",
    version="0.1.0",
    packages=find_packages(),
    description="A simple package to check odd or even numbers",
    author="Your Name",
    license="MIT",
    include_package_data=True,
)
