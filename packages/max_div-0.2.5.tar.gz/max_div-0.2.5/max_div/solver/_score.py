from dataclasses import dataclass


@dataclass
class Score:
    value: tuple[float, ...]
