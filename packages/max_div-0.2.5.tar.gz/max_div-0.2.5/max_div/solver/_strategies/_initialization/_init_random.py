from max_div.solver._solver_state import SolverState

from ._base import InitializationStrategy


class InitRandom(InitializationStrategy):
    def initialize(self, state: SolverState):
        pass  # TODO
