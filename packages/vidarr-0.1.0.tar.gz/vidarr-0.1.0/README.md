# vidarr
```
ruff check --select I --fix .
ruff format .
```