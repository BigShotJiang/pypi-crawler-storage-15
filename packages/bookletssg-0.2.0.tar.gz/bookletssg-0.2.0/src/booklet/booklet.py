import os
import json
import markdown
import requests


THEME_DEFAULT = """
body {
    font-family: sans-serif;
    max-width: 700px;
    margin: auto;
    padding: 2rem;
}
a { color: #08f; }
"""

TEMPLATE_ARTICLE = """
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>{theme}</style>
    <title>{title}</title>
</head>
<body>
    <a href="/">←</a>
    <h1>{title}</h1>
    <p>{author}</p>
    {content}
</body>
</html>
"""

TEMPLATE_INDEX = """
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>{theme}</style>
    <title>{site}</title>
</head>
<body class="container">
    <h1>{site}</h1>
    <p><span aria-hidden="true">✏️</span> descartes</p>

    <ul>
        {articles}
    </ul>
</body>
</html>
"""


def render_markdown_file(path):
    with open(path, "r", encoding="utf-8") as f:
        return markdown.markdown(f.read())


def init():
    name = input("name: ").strip()
    author = input("author: ").strip()

    os.makedirs("articles", exist_ok=True)
    os.makedirs("dist", exist_ok=True)

    cfg = {"name": name, "author": author, "theme": "default"}
    with open("booklet.json", "w") as f:
        json.dump(cfg, f, indent=2)


def build():
    with open("booklet.json") as f:
        cfg = json.load(f)

    if cfg["theme"] == "default":
        theme_css = THEME_DEFAULT
    else:
        try:
            theme_css = requests.get(cfg["theme"]).text
        except Exception:
            theme_css = THEME_DEFAULT

    os.makedirs("dist", exist_ok=True)

    links = []
    for fname in os.listdir("articles"):
        fpath = os.path.join("articles", fname)
        if not os.path.isfile(fpath):
            continue

        title, _ = os.path.splitext(fname)
        content = render_markdown_file(fpath)

        html = TEMPLATE_ARTICLE.format(
            theme=theme_css, title=title, author=cfg["author"], content=content
        )

        with open(os.path.join("dist", f"{title}.html"), "w", encoding="utf-8") as f:
            f.write(html)

        links.append(f'<li><a href="{title}.html">{title}</a></li>')

    index_html = TEMPLATE_INDEX.format(
        theme=theme_css, site=cfg["name"], author=cfg["author"], articles="\n".join(links)
    )

    with open(os.path.join("dist", "index.html"), "w", encoding="utf-8") as f:
        f.write(index_html)


def version():
    print("0.2.0")


def main():
    import sys

    cmds = {"init": init, "build": build, "version": version}
    cmds.get(sys.argv[1], lambda: print("init | build | version"))()


if __name__ == "__main__":
    main()
