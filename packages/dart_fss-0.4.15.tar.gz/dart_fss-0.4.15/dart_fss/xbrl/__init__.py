# -*- coding: utf-8 -*-
from .xbrl import get_xbrl_from_file

__all__ = ['get_xbrl_from_file']