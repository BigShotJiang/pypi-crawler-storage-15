# Path Functions

Functions for working with file paths and extracting path components.

::: datachain.func.path
