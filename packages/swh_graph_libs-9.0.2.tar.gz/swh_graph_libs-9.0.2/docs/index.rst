.. _swh-graph-libs:

.. include:: README.rst

.. toctree::
   :maxdepth: 2
   :caption: Contents:

.. only:: standalone_package_doc

   Indices and tables
   ------------------

   * :ref:`genindex`
   * :ref:`modindex`
   * :ref:`search`
