def get_service_name(name: str, version: str) -> str:
    return f"sf-{name}-{version.replace('.', '-')}v"