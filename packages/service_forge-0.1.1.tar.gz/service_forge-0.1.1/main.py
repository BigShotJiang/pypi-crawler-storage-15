import asyncio
from service_forge.service import create_service
from dotenv import load_dotenv
from loguru import logger
from typing import AsyncIterator

async def handle_stream_output(node_name: str, stream: AsyncIterator[str]):
    logger.info(f"[{node_name}] Starting stream output:")
    buffer = []
    async for char in stream:
        buffer.append(char)
        logger.info(f"[{node_name}] Received char: '{char}'")
    
    complete_message = ''.join(buffer)
    logger.info(f"[{node_name}] Complete message: '{complete_message}'")

async def main():
    service = create_service("configs/service/test_service.yaml")
    service._handle_stream_output = handle_stream_output
    await service.start()

if __name__ == "__main__":
    load_dotenv()
    asyncio.run(main())