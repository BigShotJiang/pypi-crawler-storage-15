from setuptools import setup, find_packages

setup(
    name="gmi_ieops",
    version="0.0.1",
    author="GMICloud Inc.",
    packages=find_packages(),
    python_requires=">=3.10",
    install_requires=[]
)
