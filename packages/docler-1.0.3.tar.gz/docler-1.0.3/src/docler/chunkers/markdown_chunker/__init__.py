"""Markdown Chunker."""

from docler.chunkers.markdown_chunker.chunker import MarkdownChunker

__all__ = ["MarkdownChunker"]
