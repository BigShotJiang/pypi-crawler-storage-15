"""Azure provider package."""

from docler.converters.azure_provider.provider import AzureConverter

__all__ = ["AzureConverter"]
