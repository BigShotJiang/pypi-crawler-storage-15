from __future__ import annotations

from globus_sdk.exc import GlobusAPIError


class ComputeAPIError(GlobusAPIError):
    pass
