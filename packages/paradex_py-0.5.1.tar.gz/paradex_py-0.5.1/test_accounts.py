# Generated Ethereum test accounts
# DO NOT USE IN PRODUCTION - FOR TESTING ONLY

TEST_ACCOUNTS = [
    {
        "name": "account_1",
        "l1_private_key": "0xba987cd45a4b93159f701b2e97bfd79e5cb93fa65030446aaf53831b32f8640d",
        "l1_address": "0xD0B64b8562331595bDf948bc60Fb92a2E5C009A6",
    },
    {
        "name": "account_2",
        "l1_private_key": "0x540ab0bb29f505a33fb279b588ae69b22cc427f2283f20a8f62e425e777676c0",
        "l1_address": "0x9788c06Aaa6D95214fFc84fd78DB4C6fAC2745D8",
    },
    {
        "name": "account_3",
        "l1_private_key": "0x64e67fc45e472f7fa23789702c28a3ad0c9c575dc668f686987234f5a48d1f7a",
        "l1_address": "0x886351476C8Ca89a6A87D0bf6D74136eBae92f8d",
    },
]
