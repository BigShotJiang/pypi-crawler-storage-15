# infosrv-llm-observe

A small wrapper library to instrument LLM projects and forward traces to an observability backend (Phoenix adapter included).

## Quick start

Install:

```bash
pip install infosrv-llm-observe
