from odoo import models


class DummyModel(models.Model):
    _name = "test.dummy"
    _description = "Dummy Model for Testing"
