# Third-party libraries

The Joulescope driver is distributed alongside several very useful third-party
libraries.  Each of these libraries are provided under their respective 
licenses.

*   [cmocka](cmocka/LICENSE.txt) Apache 2.0 : 1.1.0+ (git commit: 26717f4909039803b231434740ef3ce005258dae)
*   [tinyprintf](tinyprintf/tinyprintf_LICENSE.BSD-new) BSD
