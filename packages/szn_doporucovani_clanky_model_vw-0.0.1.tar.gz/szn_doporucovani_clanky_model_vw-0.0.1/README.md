# szn-doporucovani-clanky-model-vw

This is a security placeholder package created to prevent dependency confusion attacks.