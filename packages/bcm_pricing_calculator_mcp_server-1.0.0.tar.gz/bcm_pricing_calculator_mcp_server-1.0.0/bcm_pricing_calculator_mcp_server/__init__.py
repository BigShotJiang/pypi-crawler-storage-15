# Copyright (c) 2025 oreokebu-dev
# SPDX-License-Identifier: MIT

"""BCM Pricing Calculator MCP Server."""

__version__ = '0.3.3'
