from .metric import ConversationDegenerationMetric

__all__ = ["ConversationDegenerationMetric"]
