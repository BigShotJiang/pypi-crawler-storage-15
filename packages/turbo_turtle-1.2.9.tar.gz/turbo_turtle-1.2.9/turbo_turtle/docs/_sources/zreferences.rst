.. only:: html

   ##########
   References
   ##########

.. bibliography:: references.bib
   :style: unsrt
