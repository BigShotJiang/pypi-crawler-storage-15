# pymlga

Version: 0.3.0

Python machine learning by genetic algorithm

