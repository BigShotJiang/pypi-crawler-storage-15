"""Single line module-level docstring should be followed by single newline."""
a = 1
