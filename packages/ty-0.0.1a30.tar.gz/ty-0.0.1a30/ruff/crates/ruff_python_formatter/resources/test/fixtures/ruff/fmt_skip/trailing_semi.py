x = 1;  # fmt: skip

x = 1   ; # fmt: skip

x = 1 \
    ;   # fmt: skip

x = 1 # ; # fmt: skip

_;  #unrelated semicolon
