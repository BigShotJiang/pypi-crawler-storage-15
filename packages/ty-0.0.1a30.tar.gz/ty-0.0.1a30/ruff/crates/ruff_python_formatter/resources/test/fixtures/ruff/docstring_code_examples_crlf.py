def doctest_line_ending():
    """
    Do cool stuff.
    >>> def foo( x ):
    ...     print( x )
    ...
    ...     print( x )
    """
    pass
