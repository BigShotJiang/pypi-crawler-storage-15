'This string will not include \
backslashes or newline characters.'

"""Multiline
String \"
"""
