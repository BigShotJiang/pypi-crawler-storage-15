def main() -> None:
    print("Hello from vcd-dft!")
