from ttkbootstrap_icons_fluent_reg.icon import FluentRegularIcon
from ttkbootstrap_icons_fluent_reg.provider import FluentRegularFontProvider

__all__ = [
    "FluentRegularIcon",
    "FluentRegularFontProvider",
]
