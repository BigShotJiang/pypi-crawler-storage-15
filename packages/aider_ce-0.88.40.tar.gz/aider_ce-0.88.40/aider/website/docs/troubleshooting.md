---
nav_order: 60
has_children: true
description: How to troubleshoot problems with aider and get help.
---

# Troubleshooting

Below are some approaches for troubleshooting problems with aider.

{% include help.md %}
