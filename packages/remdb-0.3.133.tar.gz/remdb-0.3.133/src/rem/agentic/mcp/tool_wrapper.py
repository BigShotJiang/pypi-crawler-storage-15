"""
MCP Tool Wrappers for Pydantic AI.

This module provides functions to convert MCP tool functions and resources
into a format compatible with the Pydantic AI library.
"""

from typing import Any, Callable

from loguru import logger
from pydantic_ai.tools import Tool


def create_pydantic_tool(func: Callable[..., Any]) -> Tool:
    """
    Create a Pydantic AI Tool from a given function.

    This uses the Tool constructor, which inspects the
    function's signature and docstring to create the tool schema.

    Args:
        func: The function to wrap as a tool.

    Returns:
        A Pydantic AI Tool instance.
    """
    logger.debug(f"Creating Pydantic tool from function: {func.__name__}")
    return Tool(func)


def create_mcp_tool_wrapper(
    tool_name: str,
    mcp_tool: Any,
    user_id: str | None = None,
    description_suffix: str | None = None,
) -> Tool:
    """
    Create a Pydantic AI Tool from a FastMCP FunctionTool.

    FastMCP tools are FunctionTool objects that wrap the actual async function.
    We pass the function directly to Pydantic AI's Tool class, which will
    inspect its signature properly. User ID injection happens in the wrapper.

    Args:
        tool_name: Name of the MCP tool
        mcp_tool: The FastMCP FunctionTool object
        user_id: Optional user_id to inject into tool calls
        description_suffix: Optional text to append to the tool's docstring.
            Used to add schema-specific context (e.g., default table for search_rem).

    Returns:
        A Pydantic AI Tool instance
    """
    # Extract the actual function from FastMCP FunctionTool
    tool_func = mcp_tool.fn

    # Check if function accepts user_id parameter
    import inspect
    sig = inspect.signature(tool_func)
    has_user_id = "user_id" in sig.parameters

    # Build the docstring with optional suffix
    base_doc = tool_func.__doc__ or ""
    final_doc = base_doc + description_suffix if description_suffix else base_doc

    # If we need to inject user_id or modify docstring, create a wrapper
    # Otherwise, use the function directly for better signature preservation
    if user_id and has_user_id:
        async def wrapped_tool(**kwargs) -> Any:
            """Wrapper that injects user_id."""
            if "user_id" not in kwargs:
                kwargs["user_id"] = user_id
                logger.debug(f"Injecting user_id={user_id} into tool {tool_name}")

            # Filter kwargs to only include parameters that the function accepts
            valid_params = set(sig.parameters.keys())
            filtered_kwargs = {k: v for k, v in kwargs.items() if k in valid_params}

            return await tool_func(**filtered_kwargs)

        # Copy signature from original function for Pydantic AI inspection
        wrapped_tool.__name__ = tool_name
        wrapped_tool.__doc__ = final_doc
        wrapped_tool.__annotations__ = tool_func.__annotations__
        wrapped_tool.__signature__ = sig  # Important: preserve full signature

        logger.debug(f"Creating MCP tool wrapper with user_id injection: {tool_name}")
        return Tool(wrapped_tool)
    elif description_suffix:
        # Need to wrap just for docstring modification
        async def wrapped_tool(**kwargs) -> Any:
            """Wrapper for docstring modification."""
            valid_params = set(sig.parameters.keys())
            filtered_kwargs = {k: v for k, v in kwargs.items() if k in valid_params}
            return await tool_func(**filtered_kwargs)

        wrapped_tool.__name__ = tool_name
        wrapped_tool.__doc__ = final_doc
        wrapped_tool.__annotations__ = tool_func.__annotations__
        wrapped_tool.__signature__ = sig

        logger.debug(f"Creating MCP tool wrapper with description suffix: {tool_name}")
        return Tool(wrapped_tool)
    else:
        # No injection needed - use original function directly
        logger.debug(f"Creating MCP tool wrapper (no injection): {tool_name}")
        return Tool(tool_func)


def create_resource_tool(uri: str, usage: str = "") -> Tool:
    """
    Build a Tool instance from an MCP resource URI.

    Creates a tool that fetches the resource content when called.
    Resources declared in agent YAML become callable tools - this eliminates
    the artificial MCP distinction between tools and resources.

    Supports both:
    - Concrete URIs: "rem://schemas" -> tool with no parameters
    - Template URIs: "patient-profile://field/{field_key}" -> tool with field_key parameter

    Args:
        uri: The resource URI (concrete or template with {variable} placeholders).
        usage: The description of what this resource provides.

    Returns:
        A Pydantic AI Tool instance that fetches the resource.

    Example:
        # Concrete URI -> no-param tool
        tool = create_resource_tool("rem://schemas", "List all agent schemas")

        # Template URI -> parameterized tool
        tool = create_resource_tool("patient-profile://field/{field_key}", "Get field definition")
        # Agent calls: get_patient_profile_field(field_key="safety.suicidality")
    """
    import json
    import re

    # Extract template variables from URI (e.g., {field_key}, {domain_name})
    template_vars = re.findall(r'\{([^}]+)\}', uri)

    # Parse URI to create function name (strip template vars for cleaner name)
    clean_uri = re.sub(r'\{[^}]+\}', '', uri)
    parts = clean_uri.replace("://", "_").replace("-", "_").replace("/", "_").replace(".", "_")
    parts = re.sub(r'_+', '_', parts).strip('_')  # Clean up multiple underscores
    func_name = f"get_{parts}"

    # Build description including parameter info
    description = usage or f"Fetch {uri} resource"
    if template_vars:
        param_desc = ", ".join(template_vars)
        description = f"{description}\n\nParameters: {param_desc}"

    if template_vars:
        # Template URI -> create parameterized tool
        async def wrapper(**kwargs: Any) -> str:
            """Fetch MCP resource with substituted parameters."""
            # Substitute template variables into URI
            resolved_uri = uri
            for var in template_vars:
                if var in kwargs:
                    resolved_uri = resolved_uri.replace(f"{{{var}}}", str(kwargs[var]))
                else:
                    return json.dumps({"error": f"Missing required parameter: {var}"})

            # Import resource loading here to avoid circular imports
            from rem.api.mcp_router.resources import load_resource

            result = await load_resource(resolved_uri)
            if isinstance(result, str):
                return result
            return json.dumps(result, indent=2)

        # Build parameter annotations for Pydantic AI
        wrapper.__name__ = func_name
        wrapper.__doc__ = description
        # Add type hints for parameters
        wrapper.__annotations__ = {var: str for var in template_vars}
        wrapper.__annotations__['return'] = str

        logger.info(f"Built parameterized resource tool: {func_name} (uri: {uri}, params: {template_vars})")
    else:
        # Concrete URI -> no-param tool
        async def wrapper(**kwargs: Any) -> str:
            """Fetch MCP resource and return contents."""
            if kwargs:
                logger.warning(f"Resource tool {func_name} called with unexpected kwargs: {list(kwargs.keys())}")

            from rem.api.mcp_router.resources import load_resource

            result = await load_resource(uri)
            if isinstance(result, str):
                return result
            return json.dumps(result, indent=2)

        wrapper.__name__ = func_name
        wrapper.__doc__ = description

        logger.info(f"Built resource tool: {func_name} (uri: {uri})")

    return Tool(wrapper)
