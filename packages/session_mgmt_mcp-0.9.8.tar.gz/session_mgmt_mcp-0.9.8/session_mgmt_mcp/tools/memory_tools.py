#!/usr/bin/env python3
"""Memory and reflection management MCP tools.

This module provides tools for storing, searching, and managing reflections and conversation memories.

Refactored to use utility modules for reduced code duplication.
"""

from __future__ import annotations

import operator
import typing as t
from datetime import datetime
from typing import TYPE_CHECKING, Any

from session_mgmt_mcp.utils.database_helpers import require_reflection_database
from session_mgmt_mcp.utils.error_handlers import validate_required
from session_mgmt_mcp.utils.messages import ToolMessages
from session_mgmt_mcp.utils.tool_wrapper import (
    execute_database_tool,
    execute_simple_database_tool,
    format_reflection_result,
)

if TYPE_CHECKING:
    from session_mgmt_mcp.adapters.reflection_adapter import ReflectionDatabaseAdapter


def _format_score(score: float) -> str:
    """Format a score as a percentage or relevance indicator."""
    return f"{score:.2f}"


# ============================================================================
# Store Reflection Tool
# ============================================================================


async def _store_reflection_operation(
    db: ReflectionDatabaseAdapter, content: str, tags: list[str]
) -> dict[str, Any]:
    """Execute reflection storage operation."""
    success = await db.store_reflection(content, tags=tags)
    return {
        "success": success,
        "content": content,
        "tags": tags,
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }


def _format_store_reflection_result(result: dict[str, Any]) -> str:
    """Format reflection storage result."""
    return format_reflection_result(
        result["success"],
        result["content"],
        result.get("tags"),
        result.get("timestamp"),
    )


async def _store_reflection_impl(content: str, tags: list[str] | None = None) -> str:
    """Implementation for store_reflection tool."""

    def validator() -> None:
        validate_required(content, "content")

    async def operation(db: ReflectionDatabaseAdapter) -> dict[str, Any]:
        return await _store_reflection_operation(db, content, tags or [])

    return await execute_database_tool(
        operation,
        _format_store_reflection_result,
        "Store reflection",
        validator,
    )


# ============================================================================
# Quick Search Tool
# ============================================================================


async def _quick_search_operation(
    db: ReflectionDatabaseAdapter,
    query: str,
    project: str | None,
    min_score: float,
) -> str:
    """Execute quick search operation and format results."""
    results = await db.search_conversations(
        query=query,
        project=project,
        limit=1,
        min_score=min_score,
    )

    lines = [f"🔍 Quick search for: '{query}'"]

    if results:
        result = results[0]
        lines.extend(
            (
                "📊 Found results (showing top 1)",
                f"📝 {ToolMessages.truncate_text(result['content'], 150)}",
            )
        )
        if result.get("project"):
            lines.append(f"📁 Project: {result['project']}")
        if result.get("score") is not None:
            lines.append(f"⭐ Relevance: {_format_score(result['score'])}")
        lines.append(f"📅 Date: {result.get('timestamp', 'Unknown')}")
    else:
        lines.extend(
            (
                "🔍 No results found",
                "💡 Try adjusting your search terms or lowering min_score",
            )
        )

    return "\n".join(lines)


async def _quick_search_impl(
    query: str,
    min_score: float = 0.7,
    project: str | None = None,
) -> str:
    """Implementation for quick_search tool."""

    async def operation(db: ReflectionDatabaseAdapter) -> str:
        return await _quick_search_operation(db, query, project, min_score)

    return await execute_simple_database_tool(operation, "Quick search")


# ============================================================================
# Search Summary Tool
# ============================================================================


async def _analyze_project_distribution(
    results: list[dict[str, Any]],
) -> dict[str, int]:
    """Analyze project distribution of search results."""
    projects: dict[str, int] = {}
    for result in results:
        proj = result.get("project", "Unknown")
        projects[proj] = projects.get(proj, 0) + 1
    return projects


async def _analyze_relevance_scores(
    results: list[dict[str, Any]],
) -> tuple[float, list[float]]:
    """Analyze relevance scores of search results."""
    scores = [r.get("score", 0.0) for r in results if r.get("score") is not None]
    avg_score = sum(scores) / len(scores) if scores else 0.0
    return avg_score, scores


async def _extract_common_themes(
    results: list[dict[str, Any]],
) -> list[tuple[str, int]]:
    """Extract common themes from search results."""
    all_content = " ".join([r["content"] for r in results])
    words = all_content.lower().split()
    word_freq: dict[str, int] = {}

    for word in words:
        if len(word) > 4:  # Skip short words
            word_freq[word] = word_freq.get(word, 0) + 1

    if word_freq:
        return sorted(word_freq.items(), key=operator.itemgetter(1), reverse=True)[:5]
    return []


async def _format_search_summary(
    query: str,
    results: list[dict[str, Any]],
) -> str:
    """Format complete search summary."""
    lines = [
        f"📊 Search Summary for: '{query}'",
        "=" * 50,
    ]

    if not results:
        lines.extend(
            [
                "🔍 No results found",
                "💡 Try different search terms or lower the min_score threshold",
            ]
        )
        return "\n".join(lines)

    # Basic stats
    lines.append(f"📈 Total results: {len(results)}")

    # Project distribution
    projects = await _analyze_project_distribution(results)
    if len(projects) > 1:
        lines.append("📁 Project distribution:")
        for proj, count in sorted(
            projects.items(), key=operator.itemgetter(1), reverse=True
        ):
            lines.append(f"   • {proj}: {count} results")

    # Time distribution
    timestamps = [r.get("timestamp") for r in results if r.get("timestamp")]
    if timestamps:
        lines.append(f"📅 Time range: {len(timestamps)} results with dates")

    # Relevance scores
    avg_score, scores = await _analyze_relevance_scores(results)
    if scores:
        lines.append(f"⭐ Average relevance: {_format_score(avg_score)}")

    # Common themes
    top_words = await _extract_common_themes(results)
    if top_words:
        lines.append("🔤 Common themes:")
        for word, freq in top_words:
            lines.append(f"   • {word}: {freq} mentions")

    return "\n".join(lines)


async def _search_summary_operation(
    db: ReflectionDatabaseAdapter,
    query: str,
    project: str | None,
    min_score: float,
) -> str:
    """Execute search summary operation."""
    results = await db.search_conversations(
        query=query,
        project=project,
        limit=20,
        min_score=min_score,
    )
    return await _format_search_summary(query, results)


async def _search_summary_impl(
    query: str,
    min_score: float = 0.7,
    project: str | None = None,
) -> str:
    """Implementation for search_summary tool."""

    async def operation(db: ReflectionDatabaseAdapter) -> str:
        return await _search_summary_operation(db, query, project, min_score)

    return await execute_simple_database_tool(operation, "Search summary")


# ============================================================================
# Search by File Tool
# ============================================================================


async def _format_file_search_results(
    file_path: str,
    results: list[dict[str, Any]],
) -> str:
    """Format file search results."""
    lines = [
        f"📁 Searching conversations about: {file_path}",
        "=" * 50,
    ]

    if not results:
        lines.extend(
            [
                "🔍 No conversations found about this file",
                "💡 The file might not have been discussed in previous sessions",
            ]
        )
        return "\n".join(lines)

    lines.append(f"📈 Found {len(results)} relevant conversations:")

    for i, result in enumerate(results, 1):
        lines.append(
            f"\n{i}. 📝 {ToolMessages.truncate_text(result['content'], 200)}",
        )
        if result.get("project"):
            lines.append(f"   📁 Project: {result['project']}")
        if result.get("score") is not None:
            lines.append(f"   ⭐ Relevance: {_format_score(result['score'])}")
        if result.get("timestamp"):
            lines.append(f"   📅 Date: {result['timestamp']}")

    return "\n".join(lines)


async def _search_by_file_operation(
    db: ReflectionDatabaseAdapter,
    file_path: str,
    limit: int,
    project: str | None,
) -> str:
    """Execute file search operation."""
    results = await db.search_conversations(
        query=file_path,
        project=project,
        limit=limit,
    )
    return await _format_file_search_results(file_path, results)


async def _search_by_file_impl(
    file_path: str,
    limit: int = 10,
    project: str | None = None,
) -> str:
    """Implementation for search_by_file tool."""

    async def operation(db: ReflectionDatabaseAdapter) -> str:
        return await _search_by_file_operation(db, file_path, limit, project)

    return await execute_simple_database_tool(operation, "Search by file")


# ============================================================================
# Search by Concept Tool
# ============================================================================


async def _format_concept_search_results(
    concept: str,
    results: list[dict[str, Any]],
    include_files: bool,
) -> str:
    """Format concept search results."""
    lines = [
        f"🧠 Searching for concept: '{concept}'",
        "=" * 50,
    ]

    if not results:
        lines.extend(
            [
                "🔍 No conversations found about this concept",
                "💡 Try related terms or broader concepts",
            ]
        )
        return "\n".join(lines)

    lines.append(f"📈 Found {len(results)} related conversations:")

    for i, result in enumerate(results, 1):
        lines.append(
            f"\n{i}. 📝 {ToolMessages.truncate_text(result['content'], 250)}",
        )
        if result.get("project"):
            lines.append(f"   📁 Project: {result['project']}")
        if result.get("score") is not None:
            lines.append(f"   ⭐ Relevance: {_format_score(result['score'])}")
        if result.get("timestamp"):
            lines.append(f"   📅 Date: {result['timestamp']}")

        if include_files and result.get("files"):
            files = result["files"][:3]
            if files:
                lines.append(f"   📄 Files: {', '.join(files)}")

    return "\n".join(lines)


async def _search_by_concept_operation(
    db: ReflectionDatabaseAdapter,
    concept: str,
    include_files: bool,
    limit: int,
    project: str | None,
) -> str:
    """Execute concept search operation."""
    results = await db.search_conversations(
        query=concept,
        project=project,
        limit=limit,
    )
    return await _format_concept_search_results(concept, results, include_files)


async def _search_by_concept_impl(
    concept: str,
    include_files: bool = True,
    limit: int = 10,
    project: str | None = None,
) -> str:
    """Implementation for search_by_concept tool."""

    async def operation(db: ReflectionDatabaseAdapter) -> str:
        return await _search_by_concept_operation(
            db, concept, include_files, limit, project
        )

    return await execute_simple_database_tool(operation, "Search by concept")


# ============================================================================
# Reflection Stats Tool
# ============================================================================


def _format_stats_new(stats: dict[str, t.Any]) -> list[str]:
    """Format statistics in new format (conversations_count, reflections_count)."""
    conv_count = stats.get("conversations_count", 0)
    refl_count = stats.get("reflections_count", 0)
    provider = stats.get("embedding_provider", "unknown")

    return [
        f"📈 Total conversations: {conv_count}",
        f"💭 Total reflections: {refl_count}",
        f"🔧 Embedding provider: {provider}",
        f"\n🏥 Database health: {'✅ Healthy' if (conv_count + refl_count) > 0 else '⚠️ Empty'}",
    ]


def _format_stats_old(stats: dict[str, t.Any]) -> list[str]:
    """Format statistics in old/test format (total_reflections, projects, date_range)."""
    output = [
        f"📈 Total reflections: {stats.get('total_reflections', 0)}",
        f"📁 Projects: {stats.get('projects', 0)}",
    ]

    # Add date range if present
    date_range = stats.get("date_range")
    if isinstance(date_range, dict):
        output.append(
            f"📅 Date range: {date_range.get('start')} to {date_range.get('end')}"
        )

    # Add recent activity if present
    recent_activity = stats.get("recent_activity", [])
    if recent_activity:
        output.append("\n🕐 Recent activity:")
        output.extend([f"   • {activity}" for activity in recent_activity[:5]])

    # Database health
    is_healthy = stats.get("total_reflections", 0) > 0
    output.append(f"\n🏥 Database health: {'✅ Healthy' if is_healthy else '⚠️ Empty'}")

    return output


async def _reflection_stats_operation(db: ReflectionDatabaseAdapter) -> str:
    """Execute reflection stats operation."""
    stats = await db.get_stats()

    lines = ["📊 Reflection Database Statistics", "=" * 40]

    if stats and "error" not in stats:
        # Format based on stat structure
        if "conversations_count" in stats:
            lines.extend(_format_stats_new(stats))
        else:
            lines.extend(_format_stats_old(stats))
    else:
        lines.extend(
            [
                "📊 No statistics available",
                "💡 Database may be empty or inaccessible",
            ]
        )

    return "\n".join(lines)


async def _reflection_stats_impl() -> str:
    """Implementation for reflection_stats tool."""

    async def operation(db: ReflectionDatabaseAdapter) -> str:
        return await _reflection_stats_operation(db)

    return await execute_simple_database_tool(operation, "Reflection stats")


# ============================================================================
# Reset Database Tool
# ============================================================================


async def _reset_reflection_database_impl() -> str:
    """Implementation for reset_reflection_database tool."""
    try:
        # Try to create a new database connection (DI will handle cleanup)
        await require_reflection_database()

        lines = [
            "🔄 Reflection database connection reset",
            "✅ New connection established successfully",
            "💡 Database locks should be resolved",
        ]
        return "\n".join(lines)

    except Exception as e:
        return ToolMessages.operation_failed("Reset database", e)


# ============================================================================
# MCP Tool Registration
# ============================================================================


def register_memory_tools(mcp_server: Any) -> None:
    """Register all memory management tools with the MCP server."""

    @mcp_server.tool()  # type: ignore[misc]
    async def store_reflection(content: str, tags: list[str] | None = None) -> str:
        """Store an important insight or reflection for future reference."""
        return await _store_reflection_impl(content, tags)

    @mcp_server.tool()  # type: ignore[misc]
    async def quick_search(
        query: str,
        min_score: float = 0.7,
        project: str | None = None,
    ) -> str:
        """Quick search that returns only the count and top result for fast overview."""
        return await _quick_search_impl(query, min_score, project)

    @mcp_server.tool()  # type: ignore[misc]
    async def search_summary(
        query: str,
        limit: int = 10,
        project: str | None = None,
        min_score: float = 0.7,
    ) -> str:
        """Get aggregated insights from search results without individual result details."""
        return await _search_summary_impl(query, min_score, project)

    @mcp_server.tool()  # type: ignore[misc]
    async def search_by_file(
        file_path: str,
        limit: int = 10,
        project: str | None = None,
        min_score: float = 0.7,
    ) -> str:
        """Search for conversations that analyzed a specific file."""
        return await _search_by_file_impl(file_path, limit, project)

    @mcp_server.tool()  # type: ignore[misc]
    async def search_by_concept(
        concept: str,
        include_files: bool = True,
        limit: int = 10,
        project: str | None = None,
        min_score: float = 0.7,
    ) -> str:
        """Search for conversations about a specific development concept."""
        return await _search_by_concept_impl(concept, include_files, limit, project)

    @mcp_server.tool()  # type: ignore[misc]
    async def reflection_stats(project: str | None = None) -> str:
        """Get statistics about the reflection database."""
        return await _reflection_stats_impl()

    @mcp_server.tool()  # type: ignore[misc]
    async def reset_reflection_database() -> str:
        """Reset the reflection database connection to fix lock issues."""
        return await _reset_reflection_database_impl()
