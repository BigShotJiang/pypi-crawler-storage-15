"""Scaffold branch submodule for dagster-dg CLI."""
