from trajectory.data.trajectory_types import ToolTrajectoryType


class Tool(ToolTrajectoryType):
    pass
