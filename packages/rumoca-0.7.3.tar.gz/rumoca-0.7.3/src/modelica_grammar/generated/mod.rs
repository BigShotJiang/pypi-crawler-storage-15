//! Generated parser code from parol.
//!
//! This module contains auto-generated code and should not be edited manually.
//! To regenerate, run: `cargo build --features regen-parser`

#[allow(clippy::all)]
pub mod modelica_grammar_trait;
#[allow(clippy::all)]
pub mod modelica_parser;
