// Style mock file
module.exports = {}; 