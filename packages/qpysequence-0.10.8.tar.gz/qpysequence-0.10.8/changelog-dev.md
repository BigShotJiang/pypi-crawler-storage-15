# Release dev (development release)

This document contains the changes of the current release.

### New features since last release

No new features in this release.

### Improvements

No new improvements in this release.

### Breaking changes

No breaking changes in this release.

### Deprecations

No deprecations in this release.

### Documentation

No documentation changes in this release.

### Bug fixes

No bug fixes in this release.
