from sagemaker.core.shapes.shapes import *

from sagemaker.core.shapes.model_card_shapes import *