from __future__ import absolute_import

from sagemaker.core.image_retriever.image_retriever import ImageRetriever  # noqa: F401
