# here is the package imports
from .Flexible_Stacked_Classifier import FlexibleStackedClassifier
from .Flexible_Stacked_Regressor import FlexibleStackedRegressor

# here is the version of the package
__version__ = "0.1.0"