from .checker import is_even, is_odd
