# maha_eo

A simple Python library to check if a number is odd or even.

## Usage

```python
from maha_eo import is_even, is_odd

print(is_even(4))  # True
print(is_odd(5))   # True
```
