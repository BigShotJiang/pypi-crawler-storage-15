from __future__ import annotations

from wexample_wex_core.common.abstract_addon_manager import AbstractAddonManager


class JavascriptAddonManager(AbstractAddonManager):
    pass
