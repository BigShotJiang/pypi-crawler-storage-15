Contributor License Agreement (CLA)

By submitting a contribution to this repository, you agree to the following terms:

1. You grant the repository maintainer a perpetual, worldwide, non-exclusive, royalty-free license to use, reproduce, modify, sublicense, and distribute your contributions under:
   - The GNU Affero General Public License v3.0 (AGPL-3.0), and
   - A Commercial License, as part of the dual-license model.

2. You represent and warrant that:
   - Your contributions are your original work.
   - You have the right to grant these licenses.
   - Your contributions do not infringe upon the rights of any third party.

3. This agreement is binding and irrevocable.
