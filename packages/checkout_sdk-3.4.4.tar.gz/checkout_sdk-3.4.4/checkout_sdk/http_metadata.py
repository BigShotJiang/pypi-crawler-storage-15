class HttpMetadata:
    reason: str
    status_code: int
    headers: map
