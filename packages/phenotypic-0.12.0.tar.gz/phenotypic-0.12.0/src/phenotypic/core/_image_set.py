from ._image_set_parts._image_set_measurements import ImageSetMeasurements


class ImageSet(ImageSetMeasurements):
    pass
