from fastapi import APIRouter

router = APIRouter()
