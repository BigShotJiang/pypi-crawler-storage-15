ALTER TABLE transaction ADD v smallint;
ALTER TABLE transaction ADD r varint;
ALTER TABLE transaction ADD s varint;
ALTER TABLE configuration ADD schema_version varint;
