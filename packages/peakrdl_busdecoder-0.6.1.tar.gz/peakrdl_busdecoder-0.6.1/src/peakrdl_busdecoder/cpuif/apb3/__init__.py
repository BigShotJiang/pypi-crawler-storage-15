from .apb3_cpuif import APB3Cpuif
from .apb3_cpuif_flat import APB3CpuifFlat

__all__ = ["APB3Cpuif", "APB3CpuifFlat"]
