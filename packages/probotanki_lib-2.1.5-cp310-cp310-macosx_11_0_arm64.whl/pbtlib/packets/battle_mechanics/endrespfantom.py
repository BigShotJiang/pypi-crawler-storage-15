from ...packets import AbstractPacket


class End_Resp_Fantom(AbstractPacket):
    id = 1178028365
    description = "Client end the Fantom period to fully spawn"
