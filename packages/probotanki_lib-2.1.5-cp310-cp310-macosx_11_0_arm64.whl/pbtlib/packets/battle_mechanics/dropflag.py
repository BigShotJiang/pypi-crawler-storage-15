from ...packets import AbstractPacket


class Drop_Flag(AbstractPacket):
    id = -1832611824
    description = "Drop taken flag"


__all__ = ['Drop_Flag']