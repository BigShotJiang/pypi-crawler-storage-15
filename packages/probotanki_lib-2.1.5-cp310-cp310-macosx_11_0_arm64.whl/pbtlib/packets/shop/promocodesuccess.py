from ...packets import AbstractPacket


class Promocode_Success(AbstractPacket):
    id = -1859441081
    description = 'Promocode applied successfully'
