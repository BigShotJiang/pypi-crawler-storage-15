from ...packets import AbstractPacket


class Load_Referral(AbstractPacket):
    id = -169921234
    description = "Load garage"
