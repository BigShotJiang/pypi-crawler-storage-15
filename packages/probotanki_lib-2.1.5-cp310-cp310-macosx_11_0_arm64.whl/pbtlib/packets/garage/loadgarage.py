from ...packets import AbstractPacket


class Load_Garage(AbstractPacket):
    id = -479046431
    description = "Load garage"
