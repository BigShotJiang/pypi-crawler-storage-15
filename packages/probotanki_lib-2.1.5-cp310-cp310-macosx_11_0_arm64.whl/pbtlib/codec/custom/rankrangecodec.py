from ..complex import DoubleIntCodecFactory

RankRangeCodec = DoubleIntCodecFactory("maxRank", "minRank")
