"""Nav Parrot Meta information."""

__title__ = "ai-parrot"
__description__ = "Live Chatbots based on Langchain chatbots and Agents \
    Integrated into Navigator Framework or used into any aiohttp applications."
__version__ = "0.16.3"
__author__ = "Jesus Lara"
__author_email__ = "jesuslarag@gmail.com"
__license__ = "MIT"
__copyright__ = "Copyright (c) 2020-2024 Jesus Lara"
