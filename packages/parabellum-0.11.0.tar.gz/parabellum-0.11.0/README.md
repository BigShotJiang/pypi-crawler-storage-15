# Parabellum

TODO: switch to red and blue team semantics (not enemy and ally

## Citation

If you use Parabellum in your research, please cite it as follows:

```
@ARTICLE{10976333,
  author={Anne, Timothée and Syrkis, Noah and Elhosni, Meriem and Turati, Florian and Legendre, Franck and Jaquier, Alain and Risi, Sebastian},
  journal={IEEE Transactions on Games}, 
  title={Harnessing Language for Coordination: A Framework and Benchmark for LLM-Driven Multi-Agent Control}, 
  year={2025},
  volume={},
  number={},
  pages={1-25},
  keywords={Games;Cognition;Bridges;Benchmark testing;Real-time systems;Visualization;Strategic planning;Collaboration;Translation;Multi-agent systems;Behavior tree;large language models;multi-agent;strategy games},
  doi={10.1109/TG.2025.3564042}}
```
