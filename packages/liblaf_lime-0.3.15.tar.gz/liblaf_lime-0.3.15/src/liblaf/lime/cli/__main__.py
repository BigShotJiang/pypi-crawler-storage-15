from ._app import app

if __name__ == "__main__":
    app.meta()
