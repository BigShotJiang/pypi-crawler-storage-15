"""Airweave tool integration for LlamaIndex."""

from llama_index.tools.airweave.base import AirweaveToolSpec

__all__ = ["AirweaveToolSpec"]
