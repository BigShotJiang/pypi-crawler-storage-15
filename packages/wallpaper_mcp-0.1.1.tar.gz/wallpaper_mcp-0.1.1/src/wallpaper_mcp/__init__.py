"""Wallpaper MCP - 桌面壁纸替换工具"""

__version__ = "0.1.0"