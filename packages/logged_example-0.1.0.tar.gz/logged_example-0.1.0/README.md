logged-example

A professional logging example with automatic log rotation, sudo detection, and clean console output.

## Installation

```bash
pip install logged-example