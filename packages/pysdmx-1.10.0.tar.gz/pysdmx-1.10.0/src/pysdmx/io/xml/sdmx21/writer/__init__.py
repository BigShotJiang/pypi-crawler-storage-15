"""SDMX 2.1 writer package."""
