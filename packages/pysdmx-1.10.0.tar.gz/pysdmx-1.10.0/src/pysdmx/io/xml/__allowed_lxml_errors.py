ALLOWED_ERRORS_CONTENT = [
    "content type is empty",
    # QName value error on StructureSpecific xml files
    "of the xsi:type attribute does not resolve to a type definition.",
    "The type definition is abstract.",
]
