# dj-payfast - Django + Payfast Made Easy

[![payfast Verified Partner](https://img.shields.io/static/v1?label=payfast&message=Verified%20Partner&color=red&style=for-the-badge)](https://payfast.com/docs/libraries#community-libraries)
<br>

[![CI tests](./assets/img/badge.svg)](https://github.com/dj-payfast/dj-payfast/actions/workflows/ci.yml)
[![Package Downloads](https://img.shields.io/pypi/dm/dj-payfast)](https://pypi.org/project/dj-payfast/)
[![Documentation](https://img.shields.io/static/v1?label=Docs&message=READ&color=informational&style=plastic)](https://dj-payfast.github.io/dj-payfast/)
[![Sponsor dj-payfast](https://img.shields.io/static/v1?label=Sponsor&message=%E2%9D%A4&logo=GitHub&color=red&style=plastic)](https://github.com/sponsors/dj-payfast)
[![MIT License](https://img.shields.io/static/v1?label=License&message=MIT&color=informational&style=plastic)](https://github.com/sponsors/dj-payfast)

PayFast Models for Django.

## Introduction

dj-payfast implements all of the Payfast models intergration, for Django. Set up your
webhook endpoint and start receiving model updates. You will then have
a copy of all the payfast models available in Django models, as soon as
they are updated!

The full documentation is available [on Read the Docs](https://dj-payfast.github.io/dj-payfast/).

## Features

-   Payfast Core
-   Payfast Billing
-   Payfast Cards (JS v2) and Sources (JS v3)
-   Payment Methods and Payment Intents (SCA support)
-   Support for multiple accounts and API keys
-   Payfast Connect (partial support)
-   Tested with Payfast API `2020-08-27` (see [API versions](api_versions.md#dj-payfast_latest_tested_version))

## Requirements

-   Django >=4.2
-   Python >=3.9
-   PostgreSQL engine (recommended) >=12
-   MySQL engine: MariaDB >=10.5 or MySQL >=8.0
-   SQLite: Not recommended in production. Version >=3.26 required.
-   Nginx, Gunicorn, Docker
-   Celery is included
-   Email setup

## Installation

See [installation](https://dj-payfast.dev/dj-payfast/2.7/installation/) instructions.

## Changelog

[See release notes on Read the Docs](history/2_7_0/).

<!-- This link *will* get stale again eventually. There should be an index page for the
     changelog that can be linked to.

     For example:
     https://squidfunk.github.io/mkdocs-material/setup/setting-up-navigation/#section-index-pages -->

## Funding and Support

<a href="https://payfast.io">
  <img alt="Payfast Logo" src="https://github.com/Carrington-dev/dj-payfast/blob/main/assets/img/payfast.webp" width="250px" />
</a>

You can now become a sponsor to dj-payfast with [GitHub Sponsors](https://github.com/sponsors/dj-payfast).

We've been bringing dj-payfast to the world for over 10 years and are excited to be able to start
dedicating some real resources to the project.

Your sponsorship helps us keep a team of maintainers actively working to improve dj-payfast and
ensure it stays up-to-date with the latest payfast changes. If you use dj-payfast commercially, we would encourage you to invest in its continued
development by [signing up for a paid plan](https://github.com/sponsors/dj-payfast).
Corporate sponsors [receive priority support and development time](project/support.md).

All contributions through GitHub sponsors flow into our [Open Collective](https://opencollective.com/dj-payfast), which holds our funds and keeps
an open ledger on how donations are spent.

## Our Gold sponsors

<a href="https://payfast.io">
<!--   <img alt="Stemgon Logo" src="./logos/payfast_blurple.svg" width="250px" /> -->
  <img alt="Payfast Logo" src="https://github.com/Carrington-dev/dj-payfast/blob/main/assets/img/payfast.webp" width="250px" />
</a>

## Similar libraries

-   [dj-paypal](https://github.com/HearthSim/dj-paypal)
    ([PayPal](https://www.paypal.com/))
-   [dj-paddle](https://github.com/paddle-python/dj-paddle)
    ([Paddle](https://paddle.com/))
