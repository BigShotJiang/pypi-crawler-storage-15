import sys

def main():
    print(sys.argv)

def another():
    print("This is this other thing")

if __name__ == "__main__":
    main()