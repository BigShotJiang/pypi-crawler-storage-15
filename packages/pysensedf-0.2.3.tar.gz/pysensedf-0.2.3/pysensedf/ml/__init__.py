"""ML package initialization"""
