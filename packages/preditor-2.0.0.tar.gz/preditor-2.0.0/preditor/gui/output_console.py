from .console_base import ConsoleBase


class OutputConsole(ConsoleBase):
    """A text widget used to show stdout/stderr writes."""
