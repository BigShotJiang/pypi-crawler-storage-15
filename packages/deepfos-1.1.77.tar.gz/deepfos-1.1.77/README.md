<!-- # README -->
<p align="center">
  <img src="./docs/source/images/Deepfos-white.png" width="30%"/><br/>
</p>
<h1 align="center">
DeepFOS SDK for Python
</h1>

## 🌏 国际化

[简体中文](README.md) | [English](README.en.md)

## ℹ️ 项目介绍

此项目是DeepFOS平台的Python SDK，集成了平台Open API，以及平台中各种元素的封装。

### 📖 文档

[DeepFOS 文档](http://py.deepfos.com)


## ✳️ 功能特色

- todo


## 💎 新手入门


## 🤔 如何贡献


## 🌟 贡献者
[@陈熙](https://e.gitee.com/proinnova/members/trend/axisarsae)
[@陈思聪](https://e.gitee.com/proinnova/members/trend/proinnova_sicong_chen)
[@杨璟](https://e.gitee.com/proinnova/members/trend/jyang-0506)
[@李杨](https://e.gitee.com/proinnova/members/trend/ryan_li1384)
[@陈文雍](https://e.gitee.com/proinnova/members/trend/calvinstk)
