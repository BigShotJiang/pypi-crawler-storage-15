#!env python3
"""
HackaGame - Game - Risky 
"""
from . import engine

GameEngine= engine.Engine
