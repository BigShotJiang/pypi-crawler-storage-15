"""Tests for core schema system."""
