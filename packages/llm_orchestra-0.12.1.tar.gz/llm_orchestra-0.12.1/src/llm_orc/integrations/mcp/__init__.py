"""Model Context Protocol (MCP) integration."""
