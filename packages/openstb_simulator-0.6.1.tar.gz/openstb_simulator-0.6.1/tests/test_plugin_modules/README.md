<!--

SPDX-FileCopyrightText: openSTB contributors
SPDX-License-Identifier: CC0-1.0

-->

This directory contains modules used for testing the plugin system.

See the comments in the `tests/test_plugin.py` file for details.
