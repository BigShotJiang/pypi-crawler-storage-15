# SPDX-FileCopyrightText: openSTB contributors
# SPDX-License-Identifier: BSD-2-Clause-Patent

from openstb.simulator.cli import openstb_sim

if __name__ == "__main__":
    openstb_sim()
