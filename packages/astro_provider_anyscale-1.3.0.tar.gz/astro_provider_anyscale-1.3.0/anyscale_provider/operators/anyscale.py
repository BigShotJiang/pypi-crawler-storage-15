from __future__ import annotations

import time
from functools import cached_property
from typing import Any

import anyscale
from airflow.exceptions import AirflowException
from airflow.models import BaseOperator
from airflow.utils.context import Context
from anyscale.compute_config.models import ComputeConfig
from anyscale.job.models import JobConfig, JobQueueConfig, JobState
from anyscale.service.models import RayGCSExternalStorageConfig, ServiceConfig, ServiceState

from anyscale_provider.hooks.anyscale import AnyscaleHook


class SubmitAnyscaleJob(BaseOperator):
    """
    Submits a job to Anyscale from Apache Airflow.

    This operator handles the submission and management of jobs on Anyscale. It initializes
    with the necessary parameters to define and configure the job, and provides mechanisms
    for job submission, status tracking, and handling job outcomes.

    :param conn_id: Required. The connection ID for Anyscale.
    :param entrypoint: Required. Command that will be run to execute the job, e.g., `python main.py`.
    :param job_queue_config: Optional. Allow users to specify JobQueueConfig (more information: https://docs.anyscale.com/platform/jobs/job-queues/ and https://docs.anyscale.com/reference/job-api/).
    :param name: Optional. Name of the job. Multiple jobs can be submitted with the same name.
    :param image_uri: Optional. URI of an existing image. Exclusive with `containerfile`.
    :param containerfile: Optional. The file path to a containerfile that will be built into an image before running the workload. Exclusive with `image_uri`.
    :param compute_config: Optional. The name of an existing registered compute config or an inlined ComputeConfig object.
    :param working_dir: Optional. Directory that will be used as the working directory for the application. If a local directory is provided, it will be uploaded to cloud storage automatically. When running inside a workspace, this defaults to the current working directory ('.').
    :param excludes: Optional. A list of file path globs that will be excluded when uploading local files for `working_dir`.
    :param requirements: Optional. A list of requirements or a path to a `requirements.txt` file for the workload. When running inside a workspace, this defaults to the workspace-tracked requirements.
    :param env_vars: Optional. A dictionary of environment variables that will be set for the workload.
    :param py_modules: Optional. A list of local directories that will be uploaded and added to the Python path.
    :param cloud: Optional. The Anyscale Cloud to run this workload on. If not provided, the organization default will be used (or, if running in a workspace, the cloud of the workspace).
    :param project: Optional. The Anyscale project to run this workload in. If not provided, the organization default will be used (or, if running in a workspace, the project of the workspace).
    :param max_retries: Optional. Maximum number of times the job will be retried before being marked failed. Defaults to `1`.
    :param extra_job_params: Optional. A dictionary of job parameters that allows you to pass in any additional parameters that are not supported above by the operator. Will be passed to the Anyscale JobConfig object.
    :param wait_for_completion: Optional. Whether to wait for the job to complete before returning. Defaults to `True`.
    :param job_timeout_seconds: Optional. The timeout in seconds for the Anyscalejob to complete. Defaults to `3600` seconds.
    :param poll_interval: Optional. The interval in seconds to poll the job status. Defaults to `60` seconds.
    """

    template_fields = (
        "conn_id",
        "entrypoint",
        "name",
        "image_uri",
        "containerfile",
        "compute_config",
        "working_dir",
        "excludes",
        "requirements",
        "env_vars",
        "py_modules",
        "cloud",
        "project",
        "max_retries",
        "fetch_logs",
        "wait_for_completion",
        "job_timeout_seconds",
        "poll_interval",
    )

    def __init__(
        self,
        conn_id: str,
        entrypoint: str,
        name: str | None = None,
        image_uri: str | None = None,
        containerfile: str | None = None,
        compute_config: ComputeConfig | dict[str, Any] | str | None = None,
        working_dir: str | None = None,
        excludes: list[str] | None = None,
        requirements: str | list[str] | None = None,
        env_vars: dict[str, str] | None = None,
        py_modules: list[str] | None = None,
        cloud: str | None = None,
        project: str | None = None,
        max_retries: int = 1,
        fetch_logs: bool = True,
        wait_for_completion: bool = True,
        job_timeout_seconds: float = 3600,
        poll_interval: float = 60,
        job_queue_config: JobQueueConfig | None = None,
        extra_job_params: dict[str, Any] | None = None,
        *args: Any,
        **kwargs: Any,
    ) -> None:
        super().__init__(*args, **kwargs)
        self.conn_id = conn_id
        self.entrypoint = entrypoint
        self.name = name
        self.image_uri = image_uri
        self.containerfile = containerfile
        self.compute_config = compute_config
        self.working_dir = working_dir
        self.excludes = excludes
        self.requirements = requirements
        self.env_vars = env_vars
        self.py_modules = py_modules
        self.cloud = cloud
        self.project = project
        self.max_retries = max_retries
        self.fetch_logs = fetch_logs
        self.wait_for_completion = wait_for_completion
        self.job_timeout_seconds = job_timeout_seconds
        self.poll_interval = poll_interval
        self.job_queue_config = job_queue_config
        self.extra_job_params = extra_job_params

        self.job_id: str | None = None

    def on_kill(self) -> None:
        """
        Terminate the Anyscale job if the task is killed.

        This method will be called when the task is killed, and it sends a termination
        request for the currently running job.
        """
        if self.job_id is not None:
            self.hook.terminate_job(self.job_id, 5)
            self.log.info("Termination request received. Submitted request to terminate the anyscale job.")
        return

    @cached_property
    def hook(self) -> AnyscaleHook:
        """Return an instance of the AnyscaleHook."""
        return AnyscaleHook(conn_id=self.conn_id)

    def execute(self, context: Context) -> str:
        """
        Execute the job submission to Anyscale.

        This method submits the job to Anyscale and handles its initial status.

        :param context: The Airflow context.
        :return: The job ID if the job is successfully submitted and completed.
        """

        job_params: dict[str, Any] = {
            "entrypoint": self.entrypoint,
            "name": self.name,
            "image_uri": self.image_uri,
            "containerfile": self.containerfile,
            "compute_config": self.compute_config,
            "working_dir": self.working_dir,
            "excludes": self.excludes,
            "requirements": self.requirements,
            "env_vars": self.env_vars,
            "py_modules": self.py_modules,
            "cloud": self.cloud,
            "project": self.project,
            "max_retries": self.max_retries,
            "job_queue_config": self.job_queue_config,
        }

        # Add extra job parameters if provided
        if self.extra_job_params:
            job_params.update(self.extra_job_params)

        self.log.info(f"Using Anyscale version {anyscale.__version__}")
        # Submit the job to Anyscale
        job_config = JobConfig(**job_params)
        self.job_id = self.hook.submit_job(job_config)
        if self.do_xcom_push and context is not None:
            context["ti"].xcom_push(key="job_id", value=self.job_id)

        self.log.info(f"Submitted Anyscale job with ID: {self.job_id}")

        # Failure states based in https://docs.anyscale.com/reference/job-api#jobstate
        failure_states = [JobState.FAILED, JobState.UNKNOWN]

        # TODO: Leverage the Airflow triggerer mechanism to poll the job status.
        # This can only happen once we can check asynchronously the Anyscale job status,
        # something that is currently not possible with the latest Anyscale SDK version (0.26.75).
        # A possible path forward is to use the Anyscale API directly to enable this capability.

        if self.wait_for_completion:
            has_succeeded = False
            # This loop will complete running in one out of two scenarios:
            for _ in range(int(self.job_timeout_seconds // self.poll_interval)):
                job_status = self.hook.get_job_status(self.job_id)
                current_state = str(job_status.state)
                self.log.info(f"Current job state for {self.job_id} is: {current_state}")
                if current_state == JobState.SUCCEEDED:
                    has_succeeded = True
                    break
                elif current_state in failure_states:
                    raise AirflowException(f"Job {self.job_id} failed.")
                time.sleep(self.poll_interval)
                job_status = self.hook.get_job_status(self.job_id)
            if not has_succeeded:
                raise AirflowException(f"Job {self.job_id} was not completed after {self.job_timeout_seconds} seconds.")
        else:
            job_status = self.hook.get_job_status(self.job_id)
            current_state = str(job_status.state)
            self.log.info(f"Current job state for {self.job_id} is: {current_state}")
            if current_state in failure_states:
                raise AirflowException(f"Job {self.job_id} failed.")

        return self.job_id


class RolloutAnyscaleService(BaseOperator):
    """
    Rolls out a service on Anyscale from Apache Airflow.

    This operator handles the deployment of services on Anyscale, including the necessary
    configurations and options. It ensures the service is rolled out according to the
    specified parameters and handles the deployment lifecycle.

    :param conn_id: Required. The connection ID for Anyscale.
    :param name: Required. Unique name of the service.
    :param image_uri: Optional. URI of an existing image. Exclusive with `containerfile`.
    :param containerfile: Optional. The file path to a containerfile that will be built into an image before running the workload. Exclusive with `image_uri`.
    :param compute_config: Optional. The name of an existing registered compute config or an inlined ComputeConfig object.
    :param working_dir: Optional. Directory that will be used as the working directory for the application. If a local directory is provided, it will be uploaded to cloud storage automatically. When running inside a workspace, this defaults to the current working directory ('.').
    :param excludes: Optional. A list of file path globs that will be excluded when uploading local files for `working_dir`.
    :param requirements: Optional. A list of requirements or a path to a `requirements.txt` file for the workload. When running inside a workspace, this defaults to the workspace-tracked requirements.
    :param env_vars: Optional. A dictionary of environment variables that will be set for the workload.
    :param py_modules: Optional. A list of local directories that will be uploaded and added to the Python path.
    :param cloud: Optional. The Anyscale Cloud to run this workload on. If not provided, the organization default will be used (or, if running in a workspace, the cloud of the workspace).
    :param project: Optional. The Anyscale project to run this workload in. If not provided, the organization default will be used (or, if running in a workspace, the project of the workspace).
    :param applications: Required. List of Ray Serve applications to run. At least one application must be specified. For details, see the Ray Serve config file format documentation: https://docs.ray.io/en/latest/serve/production-guide/config.html.
    :param query_auth_token_enabled: Optional. Whether or not queries to this service is gated behind an authentication token. If `True`, an auth token is generated the first time the service is deployed. You can find the token in the UI or by fetching the status of the service.
    :param http_options: Optional. HTTP options that will be passed to Ray Serve. See https://docs.ray.io/en/latest/serve/production-guide/config.html for supported options.
    :param grpc_options: Optional. gRPC options that will be passed to Ray Serve. See https://docs.ray.io/en/latest/serve/production-guide/config.html for supported options.
    :param logging_config: Optional. Logging options that will be passed to Ray Serve. See https://docs.ray.io/en/latest/serve/production-guide/config.html for supported options.
    :param ray_gcs_external_storage_config: Optional. Configuration options for external storage for the Ray Global Control Store (GCS).
    :param in_place: Optional. Flag for in-place updates. Defaults to False.
    :param canary_percent: Optional[float]. Percentage of canary deployment. Defaults to None.
    :param max_surge_percent: Optional[float]. Maximum percentage of surge during deployment. Defaults to None.
    :param service_rollout_timeout_seconds: Optional[int]. Duration after which the trigger tracking the model deployment times out. Defaults to 600 seconds.
    :param poll_interval: Optional[int]. Interval to poll the service status. Defaults to 60 seconds.
    :param wait_for_completion: Optional. Whether to wait for the service to complete before returning. Defaults to `True`.
    """

    template_fields = (
        "conn_id",
        "name",
        "image_uri",
        "containerfile",
        "compute_config",
        "working_dir",
        "excludes",
        "requirements",
        "env_vars",
        "py_modules",
        "cloud",
        "project",
        "applications",
        "query_auth_token_enabled",
        "http_options",
        "grpc_options",
        "logging_config",
        "ray_gcs_external_storage_config",
        "in_place",
        "canary_percent",
        "max_surge_percent",
        "service_rollout_timeout_seconds",
        "poll_interval",
        "wait_for_completion",
    )

    def __init__(
        self,
        conn_id: str,
        name: str,
        applications: list[dict[str, Any]],
        image_uri: str | None = None,
        containerfile: str | None = None,
        compute_config: ComputeConfig | dict[str, Any] | str | None = None,
        working_dir: str | None = None,
        excludes: list[str] | None = None,
        requirements: str | list[str] | None = None,
        env_vars: dict[str, str] | None = None,
        py_modules: list[str] | None = None,
        cloud: str | None = None,
        project: str | None = None,
        query_auth_token_enabled: bool = True,
        http_options: dict[str, Any] | None = None,
        grpc_options: dict[str, Any] | None = None,
        logging_config: dict[str, Any] | None = None,
        ray_gcs_external_storage_config: RayGCSExternalStorageConfig | dict[str, Any] | None = None,
        in_place: bool = False,
        canary_percent: int | None = None,
        max_surge_percent: int | None = None,
        service_rollout_timeout_seconds: float = 900,
        poll_interval: float = 60,
        wait_for_completion: bool = True,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.conn_id = conn_id
        self.name = name
        self.applications = applications
        self.image_uri = image_uri
        self.containerfile = containerfile
        self.compute_config = compute_config
        self.working_dir = working_dir
        self.excludes = excludes
        self.requirements = requirements
        self.env_vars = env_vars
        self.py_modules = py_modules
        self.cloud = cloud
        self.project = project
        self.query_auth_token_enabled = query_auth_token_enabled
        self.http_options = http_options
        self.grpc_options = grpc_options
        self.logging_config = logging_config
        self.ray_gcs_external_storage_config = ray_gcs_external_storage_config
        self.service_rollout_timeout_seconds = service_rollout_timeout_seconds
        self.poll_interval = poll_interval
        self.in_place = in_place
        self.canary_percent = canary_percent
        self.max_surge_percent = max_surge_percent
        self.wait_for_completion = wait_for_completion

    @cached_property
    def hook(self) -> AnyscaleHook:
        """Return an instance of the AnyscaleHook."""
        return AnyscaleHook(conn_id=self.conn_id)

    def on_kill(self) -> None:
        """
        Terminate the Anyscale service rollout if the task is killed.

        This method will be called when the task is killed, and it sends a termination
        request for the currently running service rollout.
        """
        if self.name is not None:
            self.hook.terminate_service(self.name, 5)
            self.log.info("Termination request received. Submitted request to terminate the anyscale service rollout.")
        return

    def execute(self, context: Context) -> str:
        """
        Execute the service rollout to Anyscale.

        This method deploys the service to Anyscale with the provided configuration
        and parameters.

        :param context: The Airflow context.
        :return: The service ID if the rollout is successfully initiated.
        """
        service_params = {
            "name": self.name,
            "image_uri": self.image_uri,
            "containerfile": self.containerfile,
            "compute_config": self.compute_config,
            "working_dir": self.working_dir,
            "excludes": self.excludes,
            "requirements": self.requirements,
            "env_vars": self.env_vars,
            "py_modules": self.py_modules,
            "cloud": self.cloud,
            "project": self.project,
            "applications": self.applications,
            "query_auth_token_enabled": self.query_auth_token_enabled,
            "http_options": self.http_options,
            "grpc_options": self.grpc_options,
            "logging_config": self.logging_config,
            "ray_gcs_external_storage_config": self.ray_gcs_external_storage_config,
        }
        self.log.info(f"Using Anyscale version {anyscale.__version__}")
        svc_config = ServiceConfig(**service_params)
        self.log.info(f"Service with config object: {svc_config}")

        # Call the SDK method with the dynamically created service model
        self.service_id = self.hook.deploy_service(
            configs=svc_config,
            in_place=self.in_place,
            canary_percent=self.canary_percent,
            max_surge_percent=self.max_surge_percent,
        )

        if self.do_xcom_push and context is not None:
            context["ti"].xcom_push(key="service_id", value=self.service_id)

        self.log.info(f"Service rollout id: {self.service_id}")

        # Failure states based on https://docs.anyscale.com/reference/service-api#servicestate
        # Keeping in mind that TERMINATED is expected, temporarily, since this is a rollout operation.
        # Once the service is being rolled out, it is also expected it may be temporarily UNHEALTHY.
        failure_states = [ServiceState.SYSTEM_FAILURE, ServiceState.UNKNOWN]

        # TODO: Leverage the Airflow triggerer mechanism to poll the job status.
        # This can only happen once we can check asynchronously the Anyscale job status,
        # something that is currently not possible with the latest Anyscale SDK version (0.26.75).
        # A possible path forward is to use the Anyscale API directly to enable this capability.

        if self.wait_for_completion:
            has_succeeded = False
            for _ in range(int(self.service_rollout_timeout_seconds // self.poll_interval)):
                service_status = self.hook.get_service_status(service_name=self.name)
                current_state = service_status.state
                self.log.info(f"Current service state for {self.name} is: {current_state}")
                if current_state == ServiceState.RUNNING:
                    has_succeeded = True
                    break
                elif current_state in failure_states:
                    raise AirflowException(f"Service {self.name} failed.")
                time.sleep(self.poll_interval)
            if not has_succeeded:
                raise AirflowException(
                    f"Service {self.name} was not completed after {self.service_rollout_timeout_seconds} seconds."
                )
        else:
            service_status = self.hook.get_service_status(service_name=self.name)
            current_state = str(service_status.state)
            self.log.info(f"Current service state for {self.name} is: {current_state}")
            if current_state in failure_states:
                raise AirflowException(f"Service {self.name} failed.")

        return self.service_id
