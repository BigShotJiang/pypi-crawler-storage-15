"""UI components generated from Qt Designer files."""

