"""Data utilities and placeholders for datasets."""
