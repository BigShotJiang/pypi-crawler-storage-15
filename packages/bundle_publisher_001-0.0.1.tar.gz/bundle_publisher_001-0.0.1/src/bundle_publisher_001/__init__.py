__version__ = "0.0.1"

def hello():
    print("Hello from bundle_publisher_001!")
