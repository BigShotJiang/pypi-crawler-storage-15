# Credits

Credits to [Khalil Misbah](https://www.linkedin.com/in/khalil-misbah) for the original design of the leafmap logo. The samgeo logo is a derivative of the leafmap logo.

![logo](https://raw.githubusercontent.com/opengeos/segment-geospatial/main/docs/assets/logo.png)
