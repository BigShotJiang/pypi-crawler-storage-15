"""
Structured Data Generator - A powerful CLI tool for generating synthetic data
"""

__version__ = "1.0.0"
