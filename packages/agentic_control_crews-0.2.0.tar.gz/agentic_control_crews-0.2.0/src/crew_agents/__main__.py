"""Allow running as: python -m crew_agents"""

from __future__ import annotations

from crew_agents.main import main

if __name__ == "__main__":
    main()
