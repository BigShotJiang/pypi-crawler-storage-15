\# oddoreven



A simple Python package to check if a number is odd or even.



\## Usage

```python

from oddoreven import check



print(check(5))  # Output: Odd



