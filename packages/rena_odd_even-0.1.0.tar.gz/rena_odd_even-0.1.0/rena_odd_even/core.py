def check(number: int) -> str:
    """Returns whether a number is Odd or Even."""
    return "Even" if number % 2 == 0 else "Odd"
