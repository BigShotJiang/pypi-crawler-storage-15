__all__ = [
    'StoryType'
]

from .story import StoryType
