My custom Python library
