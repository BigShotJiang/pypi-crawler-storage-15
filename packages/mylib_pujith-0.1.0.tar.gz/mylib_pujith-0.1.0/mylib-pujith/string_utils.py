def shout(text):
    return text.upper()
