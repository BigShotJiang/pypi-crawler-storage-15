# SPDX-License-Identifier: MIT
# Copyright (c) 2025 VirtualAgentics
"""File-type specific handlers for conflict resolution."""
