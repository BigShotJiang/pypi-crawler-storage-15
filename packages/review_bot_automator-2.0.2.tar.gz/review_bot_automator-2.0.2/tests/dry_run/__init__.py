"""Dry-run test infrastructure for PR conflict resolution."""
