"""Integration tests for LLM providers."""
