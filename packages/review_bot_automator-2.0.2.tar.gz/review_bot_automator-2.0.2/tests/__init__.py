"""Test package marker for stable import paths."""
