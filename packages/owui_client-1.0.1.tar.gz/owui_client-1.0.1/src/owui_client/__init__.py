"""
Unofficial Open WebUI API Client
"""

from .client import OpenWebUI

__version__ = "1.0.1"

__all__ = ["OpenWebUI", "__version__"]
