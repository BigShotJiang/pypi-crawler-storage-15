"""
pgtrigger needs an empty models.py in order to get post_migrate signals
needed in its app config
"""
