# Retriable Kafka Client

This is an opinionated wrapper for `confluent_kafka` Python library.
It only uses specific parts of the underlying library while introducing
additional functionalities to these selected parts.

## Features

As this library is currently under development, this library should not be
used.

The aim is to provide a fault-tolerant platform for parallel message
processing.
