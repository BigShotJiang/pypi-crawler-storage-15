Simple test
------------

Print basic information about all connected USB devices, including basic info
about the first available configuration.

.. literalinclude:: ../examples/usb_host_descriptors_simpletest.py
    :caption: examples/usb_host_descriptors_simpletest.py
    :linenos:
