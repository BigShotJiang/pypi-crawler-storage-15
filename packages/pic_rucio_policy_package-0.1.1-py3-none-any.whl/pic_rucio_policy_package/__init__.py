SUPPORTED_VERSION = [">=35.0.0"]


def get_algorithms():
    # No need to define any custom algorithms for this policy package
    return {}
