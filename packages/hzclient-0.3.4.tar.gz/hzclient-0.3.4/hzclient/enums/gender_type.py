from enum import StrEnum

class GenderType(StrEnum):
  MALE = "m"
  FEMALE = "f"