"""Tests for blessed connector."""
