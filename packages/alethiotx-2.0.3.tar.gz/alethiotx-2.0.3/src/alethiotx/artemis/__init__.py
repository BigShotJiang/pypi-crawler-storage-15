"""
**Artemis**: public knowledge graphs enable accessible and scalable drug target discovery.

Github Repository   
-----------------

`GitHub - alethiotx/artemis-paper <https://github.com/alethiotx/artemis-paper>`_
"""

from .artemis import *
from .chembl import *
from .clinical import *
from .mesh import *
from .hgnc import *

__all__ = ['artemis', 'chembl', 'mesh', 'hgnc', 'clinical']