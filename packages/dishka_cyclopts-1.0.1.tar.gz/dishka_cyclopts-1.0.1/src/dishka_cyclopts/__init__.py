from dishka_cyclopts.container import CONTAINER_NAME, inject, setup_dishka

__all__ = [
    "CONTAINER_NAME",
    "inject",
    "setup_dishka",
]
