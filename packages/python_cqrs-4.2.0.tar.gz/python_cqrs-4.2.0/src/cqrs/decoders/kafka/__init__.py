from cqrs.decoders.kafka.empty_message import empty_message_decoder

__all__ = (
    "empty_message_decoder",
)