#include "gaiaconfig.h"
#ifdef _DEBUG
#include <assert.h>
#include "debug.h"
#endif