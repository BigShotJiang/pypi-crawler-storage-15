#include "spatialite/gaiageo.h"
// char *sqlite3_mprintf(const char* a,...)
// {
//     return NULL;
// }
// char *sqlite3_vmprintf(const char* a, va_list b)
// {
//     return NULL;
// }
// char *sqlite3_snprintf(int a ,char* b ,const char* c, ...)
// {
//     return NULL;
// }

// void sqlite3_free(void* p)
// {

// }

void gaiaSetGeosAuxErrorMsg(const char* p)
{

}

void gaiaSetGeosAuxErrorMsg_r(const void* cache,const char* p)
{

}