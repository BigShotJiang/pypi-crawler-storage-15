# google benchmark
this can be enabled by setting the option in the `CPP/CMakeLists.txt`

```cmake
option(USE_EXTERNAL_GBENCHMARK "Use the googlebenchmark" ON)
```