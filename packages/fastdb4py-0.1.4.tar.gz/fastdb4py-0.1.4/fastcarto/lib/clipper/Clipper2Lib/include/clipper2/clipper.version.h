#ifndef CLIPPER_VERSION_H
#define CLIPPER_VERSION_H

constexpr auto CLIPPER2_VERSION = "1.5.4";

#endif  // CLIPPER_VERSION_H
