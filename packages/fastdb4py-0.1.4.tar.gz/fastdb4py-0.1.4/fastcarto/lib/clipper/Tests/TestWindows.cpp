// see: https://github.com/AngusJohnson/Clipper2/issues/601
#ifdef WIN32
#include <Windows.h>
#include "clipper2/clipper.h"
#endif // WIN32