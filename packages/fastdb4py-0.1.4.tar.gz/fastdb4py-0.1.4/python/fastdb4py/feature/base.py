from abc import ABCMeta

class BaseFeature(metaclass=ABCMeta):
    pass