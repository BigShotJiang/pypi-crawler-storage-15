# IM_COOL_BOOY_NGROK/__init__.py
from .main import main, main_function
