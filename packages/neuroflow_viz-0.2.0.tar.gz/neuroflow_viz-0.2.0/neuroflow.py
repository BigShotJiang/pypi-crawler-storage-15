# neuroflow.py
# NeuroFlow v0.2 — dataflow tracer for Python functions

from __future__ import annotations
import uuid

from typing import Any, Dict, List, Tuple, Union, Callable
from collections.abc import Mapping, Sequence


# ---------- Core data structures ----------

class Node:
    """
    Single node in the dataflow graph.
    Holds: id, op name, parent nodes, concrete value, label, metadata.
    """

    def __init__(
        self,
        graph: "Graph",
        op: str,
        parents: List["Node"] | None,
        value: Any,
        label: str | None = None,
        meta: Dict[str, Any] | None = None,
    ):
        self.id = graph._next_node_id()
        self.graph = graph
        self.op = op
        self.parents = parents or []
        self.value = value
        self.label = label or f"{op}_{self.id}"
        self.meta = meta or {}

        graph._register(self)

    def __repr__(self) -> str:
        return f"Node(id={self.id}, op={self.op}, value={self.value})"


class Graph:
    """
    Directed acyclic graph tracking how values were computed.
    """

    def __init__(self, name: str = "graph"):
        self.name = name
        self.nodes: List[Node] = []
        self.edges: List[Tuple[int, int]] = []  # (parent_id, child_id)
        self._node_counter = 0

    def _next_node_id(self) -> int:
        """Thread-safe node ID generation per graph."""
        self._node_counter += 1
        return self._node_counter

    # ---- creation helpers ----

    def _register(self, node: Node) -> None:
        self.nodes.append(node)
        for p in node.parents:
            self.edges.append((p.id, node.id))

    def new_input(self, name: str, value: Any) -> Node:
        """
        Node representing a function input.
        """
        return Node(self, "input", [], value, label=name)

    def new_const(self, value: Any) -> Node:
        """
        Node for a literal constant.
        """
        return Node(self, "const", [], value, label=str(value))

    def new_op(
        self,
        op: str,
        parents: List[Node],
        value: Any,
        label: str | None = None,
        meta: Dict[str, Any] | None = None,
    ) -> Node:
        """
        Generic operation node (add, mul, pow, etc).
        """
        return Node(self, op, parents, value, label=label, meta=meta)

    # ---- export / inspect ----

    def _escape_dot_string(self, s: str) -> str:
        """Properly escape strings for DOT format."""
        return str(s).replace('"', '\\"').replace('\n', '\\n').replace('\r', '\\r')

    def to_dot(self, detailed: bool = True) -> str:
        """
        Export the graph to Graphviz DOT format with human-friendly visualization.
        
        Args:
            detailed: If True, includes natural language descriptions
        """
        lines = [f'digraph "{self.name.replace("_", " ").title()}" {{']
        lines.append('  rankdir=TB;')
        lines.append('  bgcolor="#f8f9fa";')
        lines.append('  node [fontname="Segoe UI,Arial", fontsize=11, margin=0.1];')
        lines.append('  edge [fontname="Segoe UI,Arial", fontsize=9, color="#495057"];')
        lines.append('  graph [splines=ortho, nodesep=0.8, ranksep=1.2];')
        
        # Human-friendly operation descriptions
        op_descriptions = {
            'add': ('Add', '➕', '#28a745'),
            'sub': ('Subtract', '➖', '#dc3545'), 
            'mul': ('Multiply', '✖️', '#fd7e14'),
            'div': ('Divide', '➗', '#6f42c1'),
            'pow': ('Power', '🔢', '#e83e8c'),
            'neg': ('Negate', '➖', '#6c757d'),
            'abs': ('Absolute', '📏', '#20c997'),
            'floordiv': ('Floor Divide', '⬇️', '#6f42c1'),
            'mod': ('Remainder', '📐', '#fd7e14')
        }
        
        # Format values nicely
        def format_value(val):
            if isinstance(val, float):
                if val.is_integer():
                    return str(int(val))
                elif abs(val) < 0.001:
                    return f"{val:.2e}"
                else:
                    return f"{val:.3f}".rstrip('0').rstrip('.')
            return str(val)
        
        # Get human-friendly variable names
        def get_var_name(label):
            var_map = {
                'arg0': 'x', 'arg1': 'y', 'arg2': 'z', 'arg3': 'w',
                'principal': 'P', 'rate': 'r', 'time': 't', 'radius': 'R'
            }
            return var_map.get(label, label)
        
        for n in self.nodes:
            safe_val = format_value(n.value)
            
            if n.op == 'input':
                var_name = get_var_name(n.label)
                label = f"📥 INPUT\n{var_name} = {safe_val}"
                color = '#e3f2fd'
                shape = 'ellipse'
                border_color = '#1976d2'
                
            elif n.op == 'const':
                # Special handling for common constants
                if abs(float(n.value) - 3.14159) < 0.001:
                    label = f"🥧 π\n≈ {safe_val}"
                elif n.value == 2:
                    label = f"2️⃣ TWO\n{safe_val}"
                else:
                    label = f"📌 CONSTANT\n{safe_val}"
                color = '#f3e5f5'
                shape = 'box'
                border_color = '#7b1fa2'
                
            else:
                op_name, op_emoji, op_color = op_descriptions.get(n.op, (n.op.upper(), '⚙️', '#6c757d'))
                
                # Create step-by-step description
                if len(n.parents) == 2:
                    left_val = format_value(n.parents[0].value)
                    right_val = format_value(n.parents[1].value)
                    step_desc = f"{left_val} {op_descriptions[n.op][1]} {right_val}"
                elif len(n.parents) == 1:
                    step_desc = f"{op_descriptions[n.op][1]} {format_value(n.parents[0].value)}"
                else:
                    step_desc = op_name
                
                label = f"{op_emoji} {op_name.upper()}\n{step_desc}\n= {safe_val}"
                color = '#fff3cd'
                shape = 'diamond'
                border_color = op_color
            
            lines.append(f'  {n.id} [label="{self._escape_dot_string(label)}", fillcolor="{color}", color="{border_color}", shape={shape}, style="rounded,filled", penwidth=2];')
        
        # Enhanced edges with meaningful descriptions
        for s, t in self.edges:
            source_node = next(node for node in self.nodes if node.id == s)
            target_node = next(node for node in self.nodes if node.id == t)
            
            # Add descriptive edge labels
            if detailed:
                val = format_value(source_node.value)
                if source_node.op == 'input':
                    edge_label = f'[label="  {val}  ", fontcolor="#1976d2", fontweight="bold"]'
                elif source_node.op == 'const':
                    edge_label = f'[label="  {val}  ", fontcolor="#7b1fa2"]'
                else:
                    edge_label = f'[label="  {val}  ", fontcolor="#495057"]'
                lines.append(f"  {s} -> {t} {edge_label};")
            else:
                lines.append(f"  {s} -> {t};")
        
        # Add a title and legend
        lines.append('')
        lines.append('  // Legend')
        lines.append('  subgraph cluster_legend {')
        lines.append('    label="📊 Computation Flow";')
        lines.append('    fontsize=14;')
        lines.append('    fontname="Segoe UI,Arial";')
        lines.append('    style=dashed;')
        lines.append('    color="#6c757d";')
        lines.append('    legend [label="📥 Inputs → ⚙️ Operations → 📤 Result", shape=note, fillcolor="#e9ecef", style=filled];')
        lines.append('  }')
        
        lines.append("}")
        return "\n".join(lines)

    def save_dot(self, path: str, detailed: bool = True) -> None:
        """Save graph as DOT file with enhanced visualization."""
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(self.to_dot(detailed=detailed))
        except IOError as e:
            raise IOError(f"Failed to save DOT file to {path}: {e}")

    def summary(self) -> str:
        """
        Human-readable text summary of the graph.
        """
        lines = [
            f"Graph {self.name}: {len(self.nodes)} nodes, {len(self.edges)} edges"
        ]
        for n in self.nodes:
            parents = [p.id for p in n.parents]
            lines.append(f"  #{n.id}: {n.op} <- {parents} = {n.value}")
        return "\n".join(lines)


# ---------- Traced values (operator overloading) ----------

class TracedValue:
    """
    A wrapped value that participates in the dataflow graph.
    All arithmetic with TracedValue will create new nodes.
    """

    def __init__(self, graph: Graph, node: Node):
        self.graph = graph
        self.node = node

    @property
    def value(self) -> Any:
        return self.node.value

    def __repr__(self) -> str:
        return f"TracedValue({self.value})"

    # --- internal helpers ---

    def _ensure(self, other: Any) -> "TracedValue":
        """
        Make sure 'other' is a TracedValue on the same graph.
        Only allows numeric types and existing TracedValues.
        """
        if isinstance(other, TracedValue):
            return other

        # Only allow numeric types for automatic wrapping
        if isinstance(other, (int, float, complex)):
            node = self.graph.new_const(other)
            return TracedValue(self.graph, node)

        raise TypeError(f"Cannot perform arithmetic with {type(other)}. Only numeric types are supported.")

    def _bin(self, other: Any, op_name: str, func: Callable) -> "TracedValue":
        other_t = self._ensure(other)
        try:
            v = func(self.value, other_t.value)
        except Exception as e:
            raise ArithmeticError(f"Operation {op_name} failed: {e}")
        node = self.graph.new_op(op_name, [self.node, other_t.node], v)
        return TracedValue(self.graph, node)

    def _rbin(self, other: Any, op_name: str, func: Callable) -> "TracedValue":
        # other is raw, self is rhs
        if isinstance(other, TracedValue):
            left = other
        elif isinstance(other, (int, float, complex)):
            left = TracedValue(self.graph, self.graph.new_const(other))
        else:
            raise TypeError(f"Cannot perform arithmetic with {type(other)}. Only numeric types are supported.")
        
        try:
            v = func(left.value, self.value)
        except Exception as e:
            raise ArithmeticError(f"Operation {op_name} failed: {e}")
        node = self.graph.new_op(op_name, [left.node, self.node], v)
        return TracedValue(self.graph, node)

    # --- arithmetic operators ---

    def __add__(self, other: Any) -> "TracedValue":
        return self._bin(other, "add", lambda a, b: a + b)

    def __radd__(self, other: Any) -> "TracedValue":
        return self._rbin(other, "add", lambda a, b: a + b)

    def __sub__(self, other: Any) -> "TracedValue":
        return self._bin(other, "sub", lambda a, b: a - b)

    def __rsub__(self, other: Any) -> "TracedValue":
        return self._rbin(other, "sub", lambda a, b: a - b)

    def __mul__(self, other: Any) -> "TracedValue":
        return self._bin(other, "mul", lambda a, b: a * b)

    def __rmul__(self, other: Any) -> "TracedValue":
        return self._rbin(other, "mul", lambda a, b: a * b)

    def __truediv__(self, other: Any) -> "TracedValue":
        def safe_div(a, b):
            if b == 0:
                raise ZeroDivisionError("Division by zero in traced computation")
            return a / b
        return self._bin(other, "div", safe_div)

    def __rtruediv__(self, other: Any) -> "TracedValue":
        def safe_div(a, b):
            if b == 0:
                raise ZeroDivisionError("Division by zero in traced computation")
            return a / b
        return self._rbin(other, "div", safe_div)

    def __floordiv__(self, other: Any) -> "TracedValue":
        def safe_floordiv(a, b):
            if b == 0:
                raise ZeroDivisionError("Floor division by zero in traced computation")
            return a // b
        return self._bin(other, "floordiv", safe_floordiv)

    def __mod__(self, other: Any) -> "TracedValue":
        def safe_mod(a, b):
            if b == 0:
                raise ZeroDivisionError("Modulo by zero in traced computation")
            return a % b
        return self._bin(other, "mod", safe_mod)

    def __pow__(self, other: Any) -> "TracedValue":
        return self._bin(other, "pow", lambda a, b: a ** b)

    def __neg__(self) -> "TracedValue":
        v = -self.value
        node = self.graph.new_op("neg", [self.node], v)
        return TracedValue(self.graph, node)

    def __abs__(self) -> "TracedValue":
        v = abs(self.value)
        node = self.graph.new_op("abs", [self.node], v)
        return TracedValue(self.graph, node)

    # --- comparison operators (return regular bools, not traced) ---
    def __eq__(self, other: Any) -> bool:
        if isinstance(other, TracedValue):
            return self.value == other.value
        return self.value == other

    def __lt__(self, other: Any) -> bool:
        if isinstance(other, TracedValue):
            return self.value < other.value
        return self.value < other

    def __le__(self, other: Any) -> bool:
        if isinstance(other, TracedValue):
            return self.value <= other.value
        return self.value <= other

    def __gt__(self, other: Any) -> bool:
        if isinstance(other, TracedValue):
            return self.value > other.value
        return self.value > other

    def __ge__(self, other: Any) -> bool:
        if isinstance(other, TracedValue):
            return self.value >= other.value
        return self.value >= other


# ---------- Wrapping / unwrapping helpers ----------

def _wrap_input(value: Any, name: str, graph: Graph) -> Any:
    """
    Wrap a function argument into TracedValue (recursively for containers).
    """
    # primitive numbers -> TracedValue(input node)
    if isinstance(value, (int, float, complex, bool)):
        node = graph.new_input(name, value)
        return TracedValue(graph, node)

    # list / tuple
    if isinstance(value, (list, tuple)):
        wrapped = [
            _wrap_input(v, f"{name}[{i}]", graph) for i, v in enumerate(value)
        ]
        return type(value)(wrapped)

    # dict
    if isinstance(value, dict):
        return {
            k: _wrap_input(v, f"{name}.{k}", graph) for k, v in value.items()
        }

    # fallback: we still create an input node but return raw object
    graph.new_input(name, value)
    return value


def _unwrap(value: Any) -> Any:
    """
    Convert TracedValue / Node structures back to plain Python values.
    Preserve container structures.
    """
    try:
        if isinstance(value, TracedValue):
            return value.value
        if isinstance(value, Node):
            return value.value

        if isinstance(value, Mapping):
            return {k: _unwrap(v) for k, v in value.items()}

        if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
            return type(value)(_unwrap(v) for v in value)

        return value
    except Exception as e:
        raise ValueError(f"Failed to unwrap value {value}: {e}")


# ---------- Public decorator ----------

def trace(fn: Callable) -> Callable:
    """
    Decorator: traces arithmetic within fn.

    Usage:
        @trace
        def foo(a, b):
            c = a + 2*b
            d = c**2 - a
            return d

        result, graph = foo(3, 4)
    
    Returns:
        Wrapped function that returns (result, graph) tuple
    """
    if not callable(fn):
        raise TypeError("trace decorator can only be applied to callable objects")

    def wrapper(*args, **kwargs):
        graph = Graph(fn.__name__)

        try:
            new_args = [
                _wrap_input(a, f"arg{i}", graph) for i, a in enumerate(args)
            ]
            new_kwargs = {
                k: _wrap_input(v, k, graph) for k, v in kwargs.items()
            }

            out = fn(*new_args, **new_kwargs)
            result = _unwrap(out)
            return result, graph
        except Exception as e:
            raise RuntimeError(f"Error in traced function {fn.__name__}: {e}")

    # keep metadata of original fn
    wrapper.__name__ = fn.__name__
    wrapper.__doc__ = fn.__doc__
    wrapper.__annotations__ = getattr(fn, '__annotations__', {})
    wrapper.__neuroflow__ = True

    return wrapper


# ---------- Utility functions ----------

def visualize_graph(graph: Graph, filename: str = None, detailed: bool = True) -> str:
    """
    Generate enhanced DOT representation and optionally save to file.
    
    Args:
        graph: The graph to visualize
        filename: Optional filename to save DOT file
        detailed: If True, uses enhanced visualization with symbols and colors
    
    Returns:
        DOT string representation
    """
    dot_str = graph.to_dot(detailed=detailed)
    if filename:
        graph.save_dot(filename, detailed=detailed)
    return dot_str


__version__ = "0.2.0"
__all__ = ["Node", "Graph", "TracedValue", "trace", "visualize_graph"]