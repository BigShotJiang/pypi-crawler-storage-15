"""
Pretty HTML Formatter for Behave.
"""

from .html_pretty import PrettyHTMLFormatter
