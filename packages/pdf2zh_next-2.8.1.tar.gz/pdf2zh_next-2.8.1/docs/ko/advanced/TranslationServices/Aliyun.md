# Aliyun Qwen

`qwen-plus-latest` 모델 사용을 권장합니다.

참조 구성:

- 번역 서비스: `qwen-plus-latest`
- 기본 URL: 기본값 유지
- API 키: 당신의 API 키
- 타임아웃 (초): 500
- 온도: 0.0
- 온도 전송: True
- JSON 모드 활성화: True

속도 제한을 위해 Custom 모드를 사용하세요:
- QPS: 30 또는 40
- 풀 최대 작업자 수: 1000

<div align="right"> 
<h6><small>이 페이지의 일부 내용은 GPT 에 의해 번역되었으며 오류가 포함될 수 있습니다.</small></h6>