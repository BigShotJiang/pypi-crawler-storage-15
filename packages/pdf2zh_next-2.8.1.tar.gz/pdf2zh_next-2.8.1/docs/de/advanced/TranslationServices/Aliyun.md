# Aliyun Qwen

Es wird empfohlen, das Modell `qwen-plus-latest` zu verwenden.

Referenzkonfiguration:

- Übersetzungsdienst: `qwen-plus-latest`
- Basis-URL: Standard beibehalten
- API-Schlüssel: Ihr API-Schlüssel
- Timeout (Sekunden): 500
- Temperatur: 0.0
- Temperatur senden: Wahr
- JSON-Modus aktivieren: Wahr

Für Ratenbegrenzung verwenden Sie den benutzerdefinierten Modus:
- QPS: 30 oder 40
- Pool Max Workers: 1000

<div align="right"> 
<h6><small>Ein Teil des Inhalts dieser Seite wurde von GPT übersetzt und kann Fehler enthalten.</small></h6>