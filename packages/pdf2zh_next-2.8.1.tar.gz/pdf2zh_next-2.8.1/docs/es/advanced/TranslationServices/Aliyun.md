# Aliyun Qwen

Se recomienda utilizar el modelo `qwen-plus-latest`.

Configuración de referencia:

- Servicio de traducción: `qwen-plus-latest`  
- URL base: mantener predeterminado  
- Clave API: tu clave API  
- Tiempo de espera (segundos): 500  
- Temperatura: 0.0  
- Enviar temperatura: Verdadero  
- Habilitar modo JSON: Verdadero

Para limitar la tasa, utiliza el modo personalizado:
- QPS: 30 o 40
- Pool Máx. de Trabajadores: 1000

<div align="right"> 
<h6><small>Parte del contenido de esta página ha sido traducido por GPT y puede contener errores.</small></h6>