# 阿里雲 Qwen

建議使用 `qwen-plus-latest` 模型。

參考配置：

- 翻譯服務：`qwen-plus-latest`
- 基礎 URL：保持默認
- API 密鑰：你的 API 密鑰
- 超時時間（秒）：500
- 溫度：0.0
- 發送溫度：True
- 啟用 JSON 模式：True

對於速率限制，請使用自訂模式：
- QPS：30 或 40  
- 池最大工作線程數：1000

<div align="right"> 
<h6><small>Some content on this page has been translated by GPT and may contain errors.</small></h6>