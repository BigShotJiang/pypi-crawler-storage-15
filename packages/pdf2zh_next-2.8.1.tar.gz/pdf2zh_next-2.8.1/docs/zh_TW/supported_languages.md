> [!NOTE]
> 請 [點擊這裡](https://funstory-ai.github.io/BabelDOC/supported_languages/) 前往 *BabelDOC 支持的語言* 頁面。該頁面的資訊同樣適用於 pdf2zh。

<div align="right"> 
<h6><small>Some content on this page has been translated by GPT and may contain errors.</small></h6>