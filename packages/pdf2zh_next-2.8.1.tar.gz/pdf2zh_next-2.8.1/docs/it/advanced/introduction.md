### Opzioni avanzate

Questa sezione è destinata agli utenti avanzati di questo software. Qui puoi trovare:

1. [**Opzioni avanzate**](./advanced.md)
<br>
In questa sezione, puoi esplorare i linguaggi di origine/destinazione specifici, cambiare i servizi di traduzione e altro ancora.

2. [**Codice lingua**](./Language-Codes.md)
<br>
Se non sei sicuro su quali codici utilizzare per tradurre le tue lingue di origine/destinazione, puoi trovarli qui.

3. [**Documentazione dei servizi di traduzione**](./Documentation-of-Translation-Services.md)
<br>
Se hai bisogno di rivedere la documentazione fornita dai servizi di traduzione che stai utilizzando, fai riferimento a questa pagina.

<div align="right"> 
<h6><small>Parte del contenuto di questa pagina è stata tradotta da GPT e potrebbe contenere errori.</small></h6>