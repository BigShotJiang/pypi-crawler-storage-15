# Aliyun Qwen

Si consiglia di utilizzare il modello `qwen-plus-latest`.

Configurazione di riferimento:

- Servizio di traduzione: `qwen-plus-latest`
- URL di base: mantenere predefinito
- Chiave API: la tua chiave API
- Timeout (secondi): 500
- Temperatura: 0.0
- Invia temperatura: Vero
- Abilita modalità JSON: Vero

Per limitare la frequenza, utilizza la modalità Personalizzata:
- QPS: 30 o 40
- Pool Max Workers: 1000

<div align="right"> 
<h6><small>Parte del contenuto di questa pagina è stata tradotta da GPT e potrebbe contenere errori.</small></h6>