> [!NOTE]
> Si prega di [cliccare qui](https://funstory-ai.github.io/BabelDOC/supported_languages/) per navigare alla pagina *BabelDOC Supported Language*. Le informazioni presenti si applicano anche a pdf2zh.

<div align="right"> 
<h6><small>Parte del contenuto di questa pagina è stata tradotta da GPT e potrebbe contenere errori.</small></h6>