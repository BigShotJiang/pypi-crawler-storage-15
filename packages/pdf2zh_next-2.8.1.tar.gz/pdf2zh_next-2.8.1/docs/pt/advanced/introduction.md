### Opções avançadas

Esta seção é destinada a usuários avançados deste software. Aqui você pode encontrar:

1. [**Opções avançadas**](./advanced.md)
<br>
Nesta seção, você pode explorar idiomas de origem/destino específicos, alternar serviços de tradução e muito mais.

2. [**Código do idioma**](./Language-Codes.md)
<br>
Se você não tem certeza sobre quais códigos usar para traduzir seus idiomas de origem/destino, você pode encontrá-los aqui.

3. [**Documentação dos serviços de tradução**](./Documentation-of-Translation-Services.md)
<br>
Se você precisar revisar a documentação fornecida pelos serviços de tradução que está usando, consulte esta página.

<div align="right"> 
<h6><small>Parte do conteúdo desta página foi traduzida pelo GPT e pode conter erros.</small></h6>