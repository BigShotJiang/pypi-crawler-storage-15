# Aliyun Qwen

Recomenda-se usar o modelo `qwen-plus-latest`.

Configuração de referência:

- Serviço de tradução: `qwen-plus-latest`
- URL base: manter padrão
- Chave da API: sua chave da API
- Tempo limite (segundos): 500
- Temperatura: 0.0
- Enviar temperatura: Verdadeiro
- Ativar modo JSON: Verdadeiro

Para limitar a taxa, use o modo Personalizado:
- QPS: 30 ou 40
- Pool Max Workers: 1000

<div align="right"> 
<h6><small>Parte do conteúdo desta página foi traduzida pelo GPT e pode conter erros.</small></h6>