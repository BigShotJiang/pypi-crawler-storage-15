[**Options avancées**](./introduction.md) > **Options avancées** _(actuel)_

---

<h3 id="toc">Table des matières</h3>

- [#### Command Line Args](#command-line-args)
- [#### Rate Limiting Configuration Guide](#rate-limiting-configuration-guide)
- [#### Partial translation](#partial-translation)
- [#### Specify source and target languages](#specify-source-and-target-languages)
- [#### Translate wih exceptions](#translate-wih-exceptions)
- [#### Custom prompt](#custom-prompt)
- [#### Custom configuration](#custom-configuration)
- [#### Skip clean](#skip-clean)
- [#### Translation cache](#translation-cache)
- [#### Deployment as a public services](#deployment-as-a-public-services)
- [#### Authentication and welcome page](#authentication-and-welcome-page)
- [#### Glossary Support](#glossary-support)

---

#### Arguments de ligne de commande

Exécutez la commande de traduction dans la ligne de commande pour générer le document traduit `example-mono.pdf` et le document bilingue `example-dual.pdf` dans le répertoire de travail actuel. Utilisez Google comme service de traduction par défaut. Plus de services de traduction pris en charge peuvent être trouvés [ICI](https://github.com/PDFMathTranslate-next/PDFMathTranslate-next/blob/main/docs/ADVANCED.md#services).

<img src="./../../images/cmd_light.svg" width="580px"  alt="cmd"/>

Dans le tableau suivant, nous listons toutes les options avancées pour référence :

##### Args

| Option                          | Fonction                                                                               | Exemple                                                                                                              |
| ------------------------------- | -------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------- |
| `input-files`                   | Fichiers PDF d'entrée à traiter                                                              | `pdf2zh_next example.pdf`                                                                                             |
| `--output`                      | Répertoire de sortie pour les fichiers                                                              | `pdf2zh_next example.pdf --output /outputpath`                                                                        |
| `--<Services>`                  | Utiliser un [**service spécifique**](./Documentation-of-Translation-Services.md) pour la traduction | `pdf2zh_next example.pdf --openai`<br>`pdf2zh_next example.pdf --deepseek`                                            |
| `--help`, `-h`                  | Afficher le message d'aide et quitter                                                   | `pdf2zh_next -h`                                                                                                      |
| `--config-file`                 | Chemin vers le fichier de configuration                                                          | `pdf2zh_next --config-file /path/to/config/config.toml`                                                               |
| `--report-interval`             | Intervalle de rapport de progression en secondes                                                     | `pdf2zh_next example.pdf --report-interval 5`                                                                         |
| `--debug`                       | Utiliser le niveau de journalisation de débogage                                                                 | `pdf2zh_next example.pdf --debug`                                                                                     |
| `--gui`                         | Interagir avec l'interface graphique                                                    | `pdf2zh_next --gui`                                                                                                   |
| `--warmup`                      | Télécharger et vérifier uniquement les ressources requises puis quitter                                      | `pdf2zh_next example.pdf --warmup`                                                                                    |
| `--generate-offline-assets`     | Générer un package de ressources hors ligne dans le répertoire spécifié                 | `pdf2zh_next example.pdf --generate-offline-assets /path`                                                             |
| `--restore-offline-assets`      | Restaurer le package d'assets hors ligne depuis le répertoire spécifié                  | `pdf2zh_next example.pdf --restore-offline-assets /path`                                                              |
| `--version`                     | Afficher la version puis quitter                                                                  | `pdf2zh_next --version`                                                                                               |
| `--pages`                       | Traduction partielle du document                                                            | `pdf2zh_next example.pdf --pages 1,2,1-,-3,3-5`                                                                       |
| `--lang-in`                     | Code de langue source                                                                    | `pdf2zh_next example.pdf --lang-in en`                                                                                |
| `--lang-out`                    | Code de langue cible                                                                    | `pdf2zh_next example.pdf --lang-out zh-CN`                                                                            |
| `--min-text-length`             | Longueur minimale du texte à traduire                                                        | `pdf2zh_next example.pdf --min-text-length 5`                                                                         |
| `--rpc-doclayout`               | Adresse hôte du service RPC pour l'analyse de la mise en page des documents                                   | `pdf2zh_next example.pdf --rpc-doclayout http://127.0.0.1:8000`                                                       |
| `--qps`                         | Limite QPS pour le service de traduction                                                | `pdf2zh_next example.pdf --qps 200`                                                                                   |
| `--ignore-cache`                | Ignorer le cache de traduction                                                                | `pdf2zh_next example.pdf --ignore-cache`                                                                              |
| `--custom-system-prompt`        | Invite système personnalisée pour la traduction. Utilisée pour `/no_think` dans Qwen 3                    | `pdf2zh_next example.pdf --custom-system-prompt "/no_think You are a professional, authentic machine translation engine"` |
| `--glossaries`                  | Liste des fichiers de glossaire.                                                                     | `pdf2zh_next example.pdf --glossaries "glossary1.csv,glossary2.csv,glossary3.csv"`                                    |
| `--save-auto-extracted-glossary`| enregistrer le glossaire extrait automatiquement                                                   | `pdf2zh_next example.pdf --save-auto-extracted-glossary`                                                              |
| `--pool-max-workers`            | Nombre maximum de travailleurs pour le pool de traduction. Si non défini, utilisera qps comme nombre de travailleurs | `pdf2zh_next example.pdf --pool-max-workers 100`                                                           |
| `--term-qps`                    | Limite QPS pour le service de traduction d'extraction de termes. Si non défini, suivra la limite qps. | `pdf2zh_next example.pdf --term-qps 20`                                                                               |
| `--term-pool-max-workers`       | Nombre maximum de workers pour le pool de traduction d'extraction de termes. Si non défini ou 0, suivra pool_max_workers. | `pdf2zh_next example.pdf --term-pool-max-workers 40`                                                  |
| `--no-auto-extract-glossary`    | Désactiver l'extraction automatique du glossaire                                                           | `pdf2zh_next example.pdf --no-auto-extract-glossary`                                                                  |
| `--primary-font-family`         | Remplace la famille de police principale pour le texte traduit. Choix : 'serif' pour les polices à empattements, 'sans-serif' pour les polices sans empattements, 'script' pour les polices script/italiques. Si non spécifié, utilise la sélection automatique de police basée sur les propriétés du texte original. | `pdf2zh_next example.pdf --primary-font-family serif` |
| `--no-dual`                     | Ne pas générer de fichiers PDF bilingues                                                | `pdf2zh_next example.pdf --no-dual`                                                                                   |
| `--no-mono`                     | Ne pas générer de fichiers PDF monolingues                                                     | `pdf2zh_next example.pdf --no-mono`                                                                                   |
| `--formular-font-pattern`       | Modèle de police pour identifier le texte des formules                                                   | `pdf2zh_next example.pdf --formular-font-pattern "(MS.*)"`                                                            |
| `--formular-char-pattern`       | Modèle de caractères pour identifier le texte de formule                                              | `pdf2zh_next example.pdf --formular-char-pattern "(MS.*)"`                                                            |
| `--split-short-lines`           | Forcer la séparation des lignes courtes en différents paragraphes                                       | `pdf2zh_next example.pdf --split-short-lines`                                                                         |
| `--short-line-split-factor`     | Facteur de seuil de division pour les lignes courtes                                                  | `pdf2zh_next example.pdf --short-line-split-factor 1.2`                                                               |
| `--skip-clean`                  | Ignorer l'étape de nettoyage du PDF                                                   | `pdf2zh_next example.pdf --skip-clean`                                                                                |
| `--dual-translate-first`        | Placer les pages traduites en premier en mode PDF double                                             | `pdf2zh_next example.pdf --dual-translate-first`                                                                      |
| `--disable-rich-text-translate` | Désactiver la traduction de texte enrichi                                                           | `pdf2zh_next example.pdf --disable-rich-text-translate`                                                               |
| `--enhance-compatibility`       | Activer toutes les options d'amélioration de la compatibilité                                            | `pdf2zh_next example.pdf --enhance-compatibility`                                                                     |
| `--use-alternating-pages-dual`  | Utiliser le mode pages alternées pour les PDF doubles                                   | `pdf2zh_next example.pdf --use-alternating-pages-dual`                                                                |
| `--watermark-output-mode`       | Mode de sortie du filigrane pour les fichiers PDF                                       | `pdf2zh_next example.pdf --watermark-output-mode no_watermark`                                                        |
| `--max-pages-per-part`          | Nombre maximum de pages par partie pour la traduction divisée                                            | `pdf2zh_next example.pdf --max-pages-per-part 50`                                                                     |
| `--translate-table-text`        | Traduire le texte des tableaux (expérimental)                                                     | `pdf2zh_next example.pdf --translate-table-text`                                                                      |
| `--skip-scanned-detection`      | Ignorer la détection des documents scannés                                                                  | `pdf2zh_next example.pdf --skip-scanned-detection`                                                                    |
| `--ocr-workaround`              | Forcer le texte traduit à être noir et ajouter un fond blanc                              | `pdf2zh_next example.pdf --ocr-workaround`                                                                            |
| `--auto-enable-ocr-workaround`  | Activer la solution de contournement OCR automatique. Si un document est détecté comme étant fortement scanné, cela tentera d'activer le traitement OCR et de sauter la détection de scan ultérieure. Voir la documentation pour plus de détails. (par défaut : False) | `pdf2zh_next example.pdf --auto-enable-ocr-workaround`                     |
| `--only-include-translated-page`| Inclure uniquement les pages traduites dans le PDF de sortie. Efficace uniquement lorsque --pages est utilisé.  | `pdf2zh_next example.pdf --pages 1-5 --only-include-translated-page`                                                  |
| `--no-merge-alternating-line-numbers` | Désactiver la fusion des numéros de ligne alternés et des paragraphes de texte dans les documents avec numéros de ligne | `pdf2zh_next example.pdf --no-merge-alternating-line-numbers`                                                |
| `--no-remove-non-formula-lines` | Désactiver la suppression des lignes non-formules dans les zones de paragraphe | `pdf2zh_next example.pdf --no-remove-non-formula-lines` |
| `--non-formula-line-iou-threshold` | Définir le seuil IoU pour identifier les lignes non-formules (0.0-1.0)                      | `pdf2zh_next example.pdf --non-formula-line-iou-threshold 0.85`                                                       |
| `--figure-table-protection-threshold` | Définir le seuil de protection pour les figures et les tableaux (0.0-1.0). Les lignes dans les figures/tableaux ne seront pas traitées | `pdf2zh_next example.pdf --figure-table-protection-threshold 0.95`                                        |
| `--skip-formula-offset-calculation` | Ignorer le calcul du décalage des formules pendant le traitement          | `pdf2zh_next example.pdf --skip-formula-offset-calculation`                                                           |


##### Arguments de l'interface graphique

| Option                          | Fonction                               | Exemple                                         |
| ------------------------------- | -------------------------------------- | ----------------------------------------------- |
| `--share`                       | Activer le mode de partage             | `pdf2zh_next --gui --share`                     |
| `--auth-file`                   | Chemin vers le fichier d'authentification        | `pdf2zh_next --gui --auth-file /chemin`           |
| `--welcome-page`                | Chemin vers le fichier html de bienvenue | `pdf2zh_next --gui --welcome-page /path`        |
| `--enabled-services`            | Services de traduction activés           | `pdf2zh_next --gui --enabled-services "Bing,OpenAI"` |
| `--disable-gui-sensitive-input` | Désactiver la saisie sensible de l'interface graphique | `pdf2zh_next --gui --disable-gui-sensitive-input` |
| `--disable-config-auto-save`    | Désactiver la sauvegarde automatique de la configuration | `pdf2zh_next --gui --disable-config-auto-save`  |
| `--server-port`                 | Port WebUI                             | `pdf2zh_next --gui --server-port 7860`          |
| `--ui-lang`                     | Langue de l'interface utilisateur      | `pdf2zh_next --gui --ui-lang zh`                |

[⬆️ Retour en haut](#toc)

---

#### Guide de configuration de la limitation de débit

Lors de l'utilisation des services de traduction, une configuration appropriée de la limitation de débit est cruciale pour éviter les erreurs d'API et optimiser les performances. Ce guide explique comment configurer les paramètres `--qps` et `--pool-max-worker` en fonction des différentes limitations des services en amont.

> [!TIP]
>
> Il est recommandé que le pool_size ne dépasse pas 1000. Si le pool_size calculé par la méthode suivante dépasse 1000, veuillez utiliser 1000.

##### Limitation du taux de RPM (Requêtes par minute)

Lorsque le service en amont a des limitations de RPM, utilisez le calcul suivant :

**Formule de calcul :**
- `qps = floor(rpm / 60)`
- `pool_size = qps * 10`

> [!NOTE]
> Le facteur de 10 est un coefficient empirique qui fonctionne généralement bien pour la plupart des scénarios.

**Exemple :**
Si votre service de traduction a une limite de 600 RPM :
- `qps = floor(600 / 60) = 10`
- `pool_size = 10 * 10 = 100`

```bash
pdf2zh example.pdf --qps 10 --pool-max-worker 100
```

##### Limitation des connexions simultanées

Lorsque le service en amont a des limitations de connexions simultanées (comme le service officiel GLM), utilisez cette approche :

**Formule de calcul :**
- `pool_size = max(floor(0.9 * official_concurrent_limit), official_concurrent_limit - 20)`
- `qps = pool_size`

**Exemple :**
Si votre service de traduction autorise 50 connexions simultanées :
- `pool_size = max(floor(0.9 * 50), 50 - 20) = max(45, 30) = 45`
- `qps = 45`

```bash
pdf2zh example.pdf --qps 45 --pool-max-worker 45
```

##### Meilleures pratiques

> [!TIP]
> - Commencez toujours avec des valeurs conservatrices et augmentez-les progressivement si nécessaire
> - Surveillez les temps de réponse et les taux d'erreur de votre service
> - Différents services peuvent nécessiter différentes stratégies d'optimisation
> - Prenez en compte votre cas d'utilisation spécifique et la taille des documents lors de la définition de ces paramètres


[⬆️ Retour en haut](#toc)

---

#### Traduction partielle

Utilisez le paramètre `--pages` pour traduire une partie d'un document.

- Si les numéros de page sont consécutifs, vous pouvez l'écrire comme ceci :

```bash
pdf2zh_next example.pdf --pages 1-3
```

```bash
pdf2zh_next example.pdf --pages 25-
```

> [!TIP]
> `25-` inclut toutes les pages après la page 25. Si votre document comporte 100 pages, cela équivaut à `25-100`.
> 
> De même, `-25` inclut toutes les pages avant la page 25, ce qui équivaut à `1-25`.

- Si les pages ne sont pas consécutives, vous pouvez utiliser une virgule `,` pour les séparer.

Par exemple, si vous souhaitez traduire la première et la troisième page, vous pouvez utiliser la commande suivante :

```bash
pdf2zh_next example.pdf --pages "1,3"
```

- Si les pages incluent à la fois des plages consécutives et non consécutives, vous pouvez également les relier par une virgule, comme ceci :

```bash
pdf2zh_next example.pdf --pages "1,3,10-20,25-"
```

Cette commande traduira la première page, la troisième page, les pages 10 à 20 et toutes les pages de 25 jusqu'à la fin.

[⬆️ Retour en haut](#toc)

---

#### Spécifier les langues source et cible

Voir [Google Languages Codes](https://developers.google.com/admin-sdk/directory/v1/languages), [DeepL Languages Codes](https://developers.deepl.com/docs/resources/supported-languages)

```bash
pdf2zh_next example.pdf --lang-in en -lang-out ja
```

[⬆️ Retour en haut](#toc)

---

#### Traduire avec exceptions

Utilisez des expressions régulières pour spécifier les polices de formules et les caractères qui doivent être préservés :

```bash
pdf2zh_next example.pdf --formular-font-pattern "(CM[^RT].*|MS.*|.*Ital)" --formular-char-pattern "(\(|\||\)|\+|=|\d|[\u0080-\ufaff])"
```

Préserve par défaut les polices `Latex`, `Mono`, `Code`, `Italic`, `Symbol` et `Math` :

```bash
pdf2zh_next example.pdf --formular-font-pattern "(CM[^R]|MS.M|XY|MT|BL|RM|EU|LA|RS|LINE|LCIRCLE|TeX-|rsfs|txsy|wasy|stmary|.*Mono|.*Code|.*Ital|.*Sym|.*Math)"
```

[⬆️ Retour en haut](#toc)

---

#### Invite personnalisée

<!-- Note: System prompt is currently not supported. See [this change](https://github.com/PDFMathTranslate-next/PDFMathTranslate-next/pull/637). -->

Invite système personnalisée pour la traduction. Elle est principalement utilisée pour ajouter l'instruction '/no_think' de Qwen 3 dans l'invite.

```bash
pdf2zh_next example.pdf --custom-system-prompt "/no_think You are a professional and reliable machine translation engine responsible for translating the input text into zh_CN.When translating, strictly follow the instructions below to ensure translation quality and preserve all formatting, tags, and placeholders:"
```

[⬆️ Retour en haut](#toc)

---

#### Configuration personnalisée

Il existe plusieurs façons de modifier et d'importer le fichier de configuration.

> [!NOTE]
> **Hiérarchie des fichiers de configuration**
>
> Lors de la modification du même paramètre en utilisant différentes méthodes, le logiciel appliquera les changements selon l'ordre de priorité ci-dessous.
>
> Les modifications de rang supérieur remplaceront celles de rang inférieur.
>
> **cli/gui > env > fichier de configuration utilisateur > fichier de configuration par défaut**

- Modification de la configuration via **Arguments de ligne de commande**

Pour la plupart des cas, vous pouvez directement transmettre vos paramètres souhaités via les arguments de ligne de commande. Veuillez consulter [Arguments de ligne de commande](#arguments-de-ligne-de-commande) pour plus d'informations.

Par exemple, si vous souhaitez activer une fenêtre d'interface graphique, vous pouvez utiliser la commande suivante :

```bash
pdf2zh_next --gui
```

- Modification de la configuration via **Variables d'environnement**

Vous pouvez remplacer le `--` dans les arguments de ligne de commande par `PDF2ZH_`, connecter les paramètres en utilisant `=`, et remplacer `-` par `_` comme variables d'environnement.

Par exemple, si vous souhaitez activer une fenêtre d'interface graphique, vous pouvez utiliser la commande suivante :

```bash
PDF2ZH_GUI=TRUE pdf2zh_next
```

<img src="./../../images/ev_light.svg" width="580px"  alt="env"/>

- Fichier de **Configuration** Spécifié par l'Utilisateur

Vous pouvez spécifier un fichier de configuration en utilisant l'argument de ligne de commande ci-dessous :

```bash
pdf2zh_next --config-file '/path/config.toml'
```

Si vous n'êtes pas sûr du format du fichier de configuration, veuillez vous référer au fichier de configuration par défaut décrit ci-dessous.

- **Fichier de configuration par défaut**

Le fichier de configuration par défaut se trouve dans `~/.config/pdf2zh`. 
Veuillez ne pas modifier les fichiers de configuration dans le répertoire `default`. 
Il est fortement recommandé de se référer au contenu de ce fichier de configuration et d'utiliser **Configuration personnalisée** pour implémenter votre propre fichier de configuration.

> [!TIP]
> - Par défaut, pdf2zh 2.0 enregistre automatiquement la configuration actuelle dans `~/.config/pdf2zh/config.v3.toml` chaque fois que vous cliquez sur le bouton de traduction dans l'interface graphique. Ce fichier de configuration sera chargé par défaut au prochain démarrage.
> - Les fichiers de configuration dans le répertoire `default` sont générés automatiquement par le programme. Vous pouvez les copier pour les modifier, mais veuillez ne pas les modifier directement.
> - Les fichiers de configuration peuvent inclure des numéros de version tels que "v2", "v3", etc. Ce sont des **numéros de version du fichier de configuration**, **et non** le numéro de version de pdf2zh lui-même.


[⬆️ Retour en haut](#toc)

---

#### Ignorer le nettoyage

Lorsque ce paramètre est défini sur True, l'étape de nettoyage du PDF sera ignorée, ce qui peut améliorer la compatibilité et éviter certains problèmes de traitement des polices.

Utilisation :

```bash
pdf2zh_next example.pdf --skip-clean
```

Ou en utilisant des variables d'environnement :

```bash
PDF2ZH_SKIP_CLEAN=TRUE pdf2zh_next example.pdf
```

> [!TIP]
> Lorsque `--enhance-compatibility` est activé, Ignorer le nettoyage est automatiquement activé.

---

#### Cache de traduction

PDFMathTranslate met en cache les textes traduits pour augmenter la vitesse et éviter les appels API inutiles pour les mêmes contenus. Vous pouvez utiliser l'option `--ignore-cache` pour ignorer le cache de traduction et forcer une nouvelle traduction.

```bash
pdf2zh_next example.pdf --ignore-cache
```

[⬆️ Retour en haut](#toc)

---

#### Déploiement en tant que services publics

Lors du déploiement d'une interface graphique pdf2zh sur des services publics, vous devez modifier le fichier de configuration comme décrit ci-dessous.

> [!WARNING]
>
> Ce projet n'a pas fait l'objet d'un audit de sécurité professionnel et peut contenir des vulnérabilités de sécurité. Veuillez évaluer les risques et prendre les mesures de sécurité nécessaires avant de le déployer sur des réseaux publics.


> [!TIP]
> - Lors d'un déploiement public, `disable_gui_sensitive_input` et `disable_config_auto_save` doivent tous deux être activés.
> - Séparez les différents services disponibles avec des *virgules anglaises* <kbd>,</kbd> .

Une configuration utilisable est la suivante :

```toml title="config.toml"
[basic]
gui = true

[gui_settings]
enabled_services = "Bing,OpenAI"
disable_gui_sensitive_input = true
disable_config_auto_save = true
```

[⬆️ Retour en haut](#toc)

---

#### Authentification et page d'accueil

Lors de l'utilisation de l'Authentification et de la page d'accueil pour spécifier quel utilisateur peut utiliser l'interface Web et personnaliser la page de connexion :

exemple auth.txt
Chaque ligne contient deux éléments, nom d'utilisateur et mot de passe, séparés par une virgule.

```
admin,123456
user1,password1
user2,abc123
guest,guest123
test,test123
```

example welcome.html

```html
<!DOCTYPE html>
<html>
<head>
    <title>Simple HTML</title>
</head>
<body>
    <h1>Hello, World!</h1>
    <p>Welcome to my simple HTML page.</p>
</body>
</html>
```

> [!NOTE]
> La page d'accueil fonctionnera uniquement si le fichier d'authentification n'est pas vide.
> Si le fichier d'authentification est vide, il n'y aura pas d'authentification. :)

Une configuration utilisable est la suivante :

```toml title="config.toml"
[basic]
gui = true

[gui_settings]
auth_file = "/path/to/auth/file"
welcome_page = "/path/to/welcome/html/file"
```

[⬆️ Retour en haut](#toc)

---

#### Prise en charge du glossaire

PDFMathTranslate prend en charge la table de glossaire. Le fichier de table de glossaire doit être un fichier `csv`.
Il y a trois colonnes dans le fichier. Voici un fichier de glossaire de démonstration :

| source | cible   | tgt_lng |
|--------|---------|---------|
| AutoML | Auto ML | fr      |
| a,a    | a       | fr      |
| "      | "       | fr      |


Pour l'utilisateur de la ligne de commande :
Vous pouvez utiliser plusieurs fichiers pour le glossaire. Et les différents fichiers doivent être séparés par `,`.

```bash
pdf2zh_next example.pdf --glossaries "glossary1.csv,glossary2.csv,glossary3.csv"
```

Pour les utilisateurs de l'interface Web :

Vous pouvez maintenant télécharger votre propre fichier de glossaire. Après avoir téléchargé le fichier, vous pouvez le consulter en cliquant sur son nom et le contenu s'affichera ci-dessous.

[⬆️ Retour en haut](#toc)

<div align="right"> 
<h6><small>Une partie du contenu de cette page a été traduite par GPT et peut contenir des erreurs.</small></h6>