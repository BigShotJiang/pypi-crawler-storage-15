# Aliyun Qwen

Il est recommandé d'utiliser le modèle `qwen-plus-latest`.

Configuration de référence :

- Service de traduction : `qwen-plus-latest`
- URL de base : conserver par défaut
- Clé API : votre clé API
- Délai d'attente (secondes) : 500
- Température : 0.0
- Envoyer la température : Vrai
- Activer le mode JSON : Vrai

Pour limiter le débit, utilisez le mode personnalisé :
- QPS : 30 ou 40
- Pool Max Workers : 1000

<div align="right"> 
<h6><small>Une partie du contenu de cette page a été traduite par GPT et peut contenir des erreurs.</small></h6>