# reqcode-aj

A Python CLI tool to generate academic practical code files offline.

## Installation

```bash
pip install reqcode-aj
```

## Usage

### Standard Method
```bash
# List available subjects
reqcode --list

# Generate all code files
reqcode --all

# Generate specific subject
reqcode --subject compiler_design

# Save to specific directory
reqcode --all --output ./my_codes

# Create zip file
reqcode --all --zip
```

### Alternative Method (Use this in lab/college systems if `reqcode` command doesn't work)
```bash
# If you get "command not found" or "not recognized" error, use:
python -m reqcode_aj.main --list
python -m reqcode_aj.main --all
python -m reqcode_aj.main --subject compiler_design
python -m reqcode_aj.main --all --zip
```

**Note:** The alternative method works on ALL systems and doesn't require the Scripts folder to be in PATH.

## Subjects Included

1. **Compiler Design** - Lex and Yacc practical files
2. **Deep Learning** - Deep learning implementations
3. **Social Network Analysis** - Network analysis code

## Features

- Works completely offline
- All practical files bundled in the package
- Perfect for lab practicals and exam preparation
- No internet required after installation

## License

MIT License
