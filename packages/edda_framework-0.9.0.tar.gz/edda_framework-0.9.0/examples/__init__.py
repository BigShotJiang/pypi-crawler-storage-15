"""Examples for Kairo framework."""
