"""Configuration management for Obra Client.

Handles terms acceptance state and client configuration stored in
~/.obra/client-config.yaml.
"""

import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

import yaml

# Legal document versions - must match bundled documents
TERMS_VERSION = "2.1"
PRIVACY_VERSION = "1.3"

# Config file path
CONFIG_PATH = Path.home() / ".obra" / "client-config.yaml"

# Firebase configuration
# This is the Firebase Web API Key (public, safe to include in client)
# Used for custom token → ID token exchange via Firebase Auth REST API
# Project: obra-205b0
FIREBASE_API_KEY = "AIzaSyCt7QnLZxzTZh5BUGbqgcMpIQkNqnmNM98"  # pragma: allowlist secret

# Default API URL (production)
# Can be overridden via OBRA_API_BASE_URL environment variable (Finding 10.3)
DEFAULT_API_BASE_URL = "https://us-central1-obra-205b0.cloudfunctions.net"


def get_api_base_url() -> str:
    """Get API base URL with environment variable override support.

    Resolution order:
    1. OBRA_API_BASE_URL environment variable
    2. api_base_url from config file
    3. DEFAULT_API_BASE_URL constant

    Returns:
        API base URL string

    Example:
        # Override for local development
        export OBRA_API_BASE_URL="http://localhost:5001/obra-205b0/us-central1"

        # Override for staging
        export OBRA_API_BASE_URL="https://us-central1-obra-staging.cloudfunctions.net"
    """
    # Priority 1: Environment variable
    env_url = os.environ.get("OBRA_API_BASE_URL")
    if env_url:
        return env_url.rstrip("/")

    # Priority 2: Config file
    config = load_config()
    config_url = config.get("api_base_url")
    if config_url:
        return config_url.rstrip("/")

    # Priority 3: Default constant
    return DEFAULT_API_BASE_URL

# =============================================================================
# LLM Configuration
# =============================================================================

# Supported LLM providers
LLM_PROVIDERS = {
    "anthropic": {
        "name": "Anthropic",
        "description": "Claude models (recommended)",
        "cli": "claude",  # Claude Code CLI
        "models": ["default", "sonnet", "opus", "haiku"],
        "default_model": "default",
        "oauth_env_var": None,  # OAuth uses browser-based login
        "api_key_env_var": "ANTHROPIC_API_KEY",  # pragma: allowlist secret
    },
    "openai": {
        "name": "OpenAI",
        "description": "Codex / GPT models",
        "cli": "codex",  # OpenAI Codex CLI
        "models": ["default", "gpt-4o", "gpt-4-turbo", "o3", "gpt-5"],
        "default_model": "default",
        "oauth_env_var": None,  # OAuth uses browser-based login (codex --login)
        "api_key_env_var": "OPENAI_API_KEY",  # pragma: allowlist secret
    },
}

# Auth methods
LLM_AUTH_METHODS = {
    "oauth": {
        "name": "OAuth (Flat Rate)",
        "description": "Subscription-based, fixed monthly cost",
        "recommended_model": "default",
        "note": "Recommended - inherits provider's optimal model",
    },
    "api_key": {
        "name": "API Key (Token Billing)",
        "description": "Pay per token usage",
        "recommended_model": None,  # User should choose
        "note": "⚠️ API Key method is currently untested",
    },
}

DEFAULT_PROVIDER = "anthropic"
DEFAULT_AUTH_METHOD = "oauth"
DEFAULT_MODEL = "default"


def get_llm_config() -> dict[str, Any]:
    """Get LLM configuration from config file.

    Returns:
        Dictionary with LLM config for both orchestrator and implementation:
        {
            "orchestrator": {
                "provider": "anthropic",
                "auth_method": "oauth",
                "model": "default"
            },
            "implementation": {
                "provider": "anthropic",
                "auth_method": "oauth",
                "model": "default"
            }
        }
    """
    config = load_config()
    default_config = {
        "orchestrator": {
            "provider": DEFAULT_PROVIDER,
            "auth_method": DEFAULT_AUTH_METHOD,
            "model": DEFAULT_MODEL,
        },
        "implementation": {
            "provider": DEFAULT_PROVIDER,
            "auth_method": DEFAULT_AUTH_METHOD,
            "model": DEFAULT_MODEL,
        },
    }
    return config.get("llm", default_config)


def set_llm_config(
    role: str,  # "orchestrator" or "implementation"
    provider: str,
    auth_method: str,
    model: str = "default",
) -> None:
    """Set LLM configuration for a specific role.

    Args:
        role: "orchestrator" or "implementation"
        provider: LLM provider (anthropic, openai)
        auth_method: Auth method (oauth, api_key)
        model: Model to use (default recommended for oauth)

    Raises:
        ValueError: If any parameter is invalid
    """
    if role not in ("orchestrator", "implementation"):
        raise ValueError(f"Invalid role: {role}. Must be 'orchestrator' or 'implementation'")

    if provider not in LLM_PROVIDERS:
        raise ValueError(f"Invalid provider: {provider}. Valid: {list(LLM_PROVIDERS.keys())}")

    if auth_method not in LLM_AUTH_METHODS:
        raise ValueError(f"Invalid auth method: {auth_method}. Valid: {list(LLM_AUTH_METHODS.keys())}")

    provider_info = LLM_PROVIDERS[provider]
    if model not in provider_info["models"]:
        raise ValueError(f"Invalid model '{model}' for {provider}. Valid: {provider_info['models']}")

    config = load_config()
    if "llm" not in config:
        config["llm"] = get_llm_config()

    config["llm"][role] = {
        "provider": provider,
        "auth_method": auth_method,
        "model": model,
    }

    save_config(config)


def get_llm_display(role: str) -> str:
    """Get a human-readable display string for LLM config.

    Args:
        role: "orchestrator" or "implementation"

    Returns:
        Display string like "Anthropic (OAuth, default)"
    """
    llm_config = get_llm_config()
    role_config = llm_config.get(role, {})

    provider = role_config.get("provider", DEFAULT_PROVIDER)
    auth_method = role_config.get("auth_method", DEFAULT_AUTH_METHOD)
    model = role_config.get("model", DEFAULT_MODEL)

    provider_name = LLM_PROVIDERS.get(provider, {}).get("name", provider)
    auth_name = "OAuth" if auth_method == "oauth" else "API Key"

    return f"{provider_name} ({auth_name}, {model})"


def get_llm_command() -> tuple[str, list[str]]:
    """Get the implementation LLM command and arguments.

    Returns:
        Tuple of (command, args) for subprocess execution.
        Uses provider-specific CLI:
        - Anthropic: claude (Claude Code CLI)
        - OpenAI: codex (OpenAI Codex CLI)
    """
    llm_config = get_llm_config()
    impl_config = llm_config.get("implementation", {})

    provider = impl_config.get("provider", DEFAULT_PROVIDER)
    model = impl_config.get("model", DEFAULT_MODEL)

    provider_info = LLM_PROVIDERS.get(provider, LLM_PROVIDERS[DEFAULT_PROVIDER])
    cli = provider_info.get("cli", "claude")

    # Build args based on provider CLI
    if provider == "anthropic":
        # Claude Code CLI
        args = ["--dangerously-skip-permissions"]
        if model and model != "default":
            args.extend(["--model", model])
        return cli, args

    if provider == "openai":
        # OpenAI Codex CLI - uses exec --full-auto mode
        args = ["exec", "--full-auto"]
        if model and model != "default":
            args.extend(["--model", model])
        return cli, args

    # Fallback to Claude Code CLI
    return "claude", ["--dangerously-skip-permissions"]


def get_config_path() -> Path:
    """Get path to client configuration file.

    Returns:
        Path to ~/.obra/client-config.yaml
    """
    return CONFIG_PATH


def load_config() -> dict[str, Any]:
    """Load configuration from ~/.obra/client-config.yaml.

    Returns:
        Configuration dictionary, empty dict if file doesn't exist
    """
    if not CONFIG_PATH.exists():
        return {}

    try:
        with open(CONFIG_PATH) as f:
            return yaml.safe_load(f) or {}
    except Exception:
        return {}


def save_config(config: dict[str, Any]) -> None:
    """Save configuration to ~/.obra/client-config.yaml.

    Args:
        config: Configuration dictionary to save

    Raises:
        OSError: If unable to write config file
    """
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)

    with open(CONFIG_PATH, "w") as f:
        yaml.safe_dump(config, f, default_flow_style=False, sort_keys=False)


def get_terms_acceptance() -> Optional[dict[str, Any]]:
    """Get stored terms acceptance data.

    Returns:
        Dictionary with terms acceptance info, or None if not accepted:
        {
            "version": "2.1",
            "privacy_version": "1.3",
            "accepted_at": "2025-12-03T12:00:00+00:00"
        }
    """
    config = load_config()
    return config.get("terms_accepted")


def is_terms_accepted() -> bool:
    """Check if current terms version has been accepted.

    Returns:
        True if terms are accepted and version matches current,
        False otherwise
    """
    acceptance = get_terms_acceptance()

    if not acceptance:
        return False

    # Check if accepted version matches current version
    accepted_version = acceptance.get("version")
    if accepted_version != TERMS_VERSION:
        return False

    return True


def needs_reacceptance() -> bool:
    """Check if terms need to be re-accepted due to version change.

    Returns:
        True if terms were previously accepted but version changed,
        False if never accepted or current version is accepted
    """
    acceptance = get_terms_acceptance()

    if not acceptance:
        return False  # Never accepted, not "re-acceptance"

    accepted_version = acceptance.get("version")
    return accepted_version != TERMS_VERSION


def save_terms_acceptance(
    version: str = TERMS_VERSION,
    privacy_version: str = PRIVACY_VERSION,
) -> None:
    """Save terms acceptance to config file.

    Args:
        version: Terms version being accepted (default: current TERMS_VERSION)
        privacy_version: Privacy policy version (default: current PRIVACY_VERSION)
    """
    config = load_config()

    config["terms_accepted"] = {
        "version": version,
        "privacy_version": privacy_version,
        "accepted_at": datetime.now(timezone.utc).isoformat(),
    }

    save_config(config)


def clear_terms_acceptance() -> None:
    """Clear stored terms acceptance (for testing/reset)."""
    config = load_config()

    if "terms_accepted" in config:
        del config["terms_accepted"]
        save_config(config)


def get_license_key() -> Optional[str]:
    """Get stored license key from config.

    Returns:
        License key string or None if not configured
    """
    config = load_config()
    return config.get("license_key")
