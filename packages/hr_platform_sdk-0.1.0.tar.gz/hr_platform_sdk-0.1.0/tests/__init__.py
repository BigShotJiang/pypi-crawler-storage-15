"""HR Platform SDK Tests."""
