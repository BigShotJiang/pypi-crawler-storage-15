"""Tests for HR Platform SDK resources."""
