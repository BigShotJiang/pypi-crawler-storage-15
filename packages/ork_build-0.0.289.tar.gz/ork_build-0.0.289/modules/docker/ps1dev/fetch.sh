#!/usr/bin/env sh

wget http://ftp.gnu.org/gnu/binutils/binutils-2.31.tar.gz
wget ftp://ftp.fu-berlin.de/unix/languages/gcc/releases/gcc-8.2.0/gcc-8.2.0.tar.gz
wget https://psx.arthus.net/sdk/PSXSDK/psxsdk-20180115.tar.bz2
