#include <stdio.h>
#include "dll.h"

namespace DLL {
void a_function() {
  printf("Hello from dll_func\n");
}
}