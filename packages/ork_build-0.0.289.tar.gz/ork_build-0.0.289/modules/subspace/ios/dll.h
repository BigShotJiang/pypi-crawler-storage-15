namespace DLL {
void a_function();
}
