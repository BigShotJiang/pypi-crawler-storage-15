# Copyright 2025 Rebellions Inc. All rights reserved.

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at:

#     http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os
from typing import TYPE_CHECKING

from vllm.envs import environment_variables as vllm_envs

if TYPE_CHECKING:
    VLLM_RBLN_COMPILE_MODEL: bool = True
    VLLM_RBLN_COMPILE_STRICT_MODE: bool = False
    VLLM_RBLN_TP_SIZE: int = 1
    VLLM_RBLN_SAMPLER: bool = True
    VLLM_RBLN_ENABLE_WARM_UP: bool = True
    VLLM_RBLN_USE_VLLM_MODEL: bool = False
    VLLM_RBLN_FLASH_CAUSAL_ATTN: bool = True

# extended environments
environment_variables = {
    **vllm_envs,
    # If true, will compile models using torch.compile.
    # Otherwise, run the CPU eager mode, if possible.
    "VLLM_RBLN_COMPILE_MODEL":
    (lambda: os.environ.get("VLLM_RBLN_COMPILE_MODEL", "True").lower() in
     ("true", "1")),
    # If true, will compile models using strict mode.
    "VLLM_RBLN_COMPILE_STRICT_MODE": (lambda: os.environ.get(
        "VLLM_RBLN_COMPILE_STRICT_MODE", "False").lower() in ("true", "1")),
    # TP Size for RSD.
    "VLLM_RBLN_TP_SIZE":
    lambda: int(os.environ.get("VLLM_RBLN_TP_SIZE", 1)),
    # Use customized sampler
    "VLLM_RBLN_SAMPLER":
    (lambda: os.environ.get("VLLM_RBLN_SAMPLER", "True").lower() in
     ("true", "1")),
    # Enable warmup
    "VLLM_RBLN_ENABLE_WARM_UP":
    (lambda: os.environ.get("VLLM_RBLN_ENABLE_WARM_UP", "True").lower() in
     ("true", "1")),
    # If true, it uses the natively compiled vLLM model
    # rather than the optimum-rbln compiled model.
    "VLLM_RBLN_USE_VLLM_MODEL":
    (lambda: os.environ.get("VLLM_RBLN_USE_VLLM_MODEL", "False").lower() in
     ("true", "1")),
    # Use flash attention for causal attention
    "VLLM_RBLN_FLASH_CAUSAL_ATTN":
    (lambda: os.environ.get("VLLM_RBLN_FLASH_CAUSAL_ATTN", "True").lower() in
     ("true", "1")),
}


def __getattr__(name: str):
    # lazy evaluation of environment variables
    if name in environment_variables:
        return environment_variables[name]()
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
