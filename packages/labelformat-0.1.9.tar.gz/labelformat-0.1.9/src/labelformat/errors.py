class LabelWithoutImageError(Exception):
    """Raised when a label is found without a corresponding image."""

    pass
