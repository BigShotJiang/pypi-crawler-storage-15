"""Auth provider interfaces."""

from .auth_provider_port import IAuthProviderPort

__all__ = ["IAuthProviderPort"]
