"""Shared resources for vexen-auth."""
