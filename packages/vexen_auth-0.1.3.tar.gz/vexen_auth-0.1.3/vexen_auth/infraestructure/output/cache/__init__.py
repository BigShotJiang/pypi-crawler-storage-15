"""Cache adapters for session and token management."""
