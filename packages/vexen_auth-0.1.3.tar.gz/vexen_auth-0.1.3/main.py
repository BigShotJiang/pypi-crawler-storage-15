def main():
	print("Hello from vexen_auth!")


if __name__ == "__main__":
	main()
