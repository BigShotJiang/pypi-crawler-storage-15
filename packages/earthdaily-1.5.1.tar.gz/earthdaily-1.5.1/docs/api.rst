API Documentation
===============

.. autosummary::
   :toctree: _autosummary
   :recursive:
   :template: custom-module-template.rst
   
   earthdaily

