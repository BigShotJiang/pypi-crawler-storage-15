# SPDX-FileCopyrightText: 2025-present Rich FitzJohn <r.fitzjohn@imperial.ac.uk>
#
# SPDX-License-Identifier: MIT
__version__ = "1.4.8"
