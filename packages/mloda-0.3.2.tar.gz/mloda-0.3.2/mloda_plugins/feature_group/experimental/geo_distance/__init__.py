"""
GeoDistanceFeatureGroup for calculating distances between geographic points.
"""
