Copyright 2025- Tom Kaltofen <tomkaltofen@gmail.com>

This project, "mloda," is licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License. You may obtain a copy
of the License at:

       http://www.apache.org/licenses/LICENSE-2.0

Attributions:
- Any attributions for third-party components or libraries are available in the [releases of this repository](https://github.com/mloda-ai/mloda/releases) as asset: ATTRIBUTION.md THIRD_PARTY_LICENSES.md.
