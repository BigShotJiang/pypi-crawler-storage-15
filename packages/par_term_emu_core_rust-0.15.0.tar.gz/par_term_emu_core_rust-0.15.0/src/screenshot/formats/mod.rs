pub mod bmp;
pub mod jpeg;
pub mod png;
pub mod svg;
