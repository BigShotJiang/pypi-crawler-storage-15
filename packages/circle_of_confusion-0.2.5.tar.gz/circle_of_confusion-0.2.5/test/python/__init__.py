"""Pytest package for Circle of Confusion."""
