"""
CLI modules package for doc-intelligence.
"""

from memdocs.cli_modules.utils import load_config

__all__ = ["load_config"]
