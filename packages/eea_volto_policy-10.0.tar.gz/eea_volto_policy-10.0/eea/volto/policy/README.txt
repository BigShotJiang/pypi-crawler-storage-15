Overview
========
eea.volto.policy is a revolutionary plone package that redefines Plone Add-ons.

  * See more: http://github.com/eea/eea.volto.policy


Installation
============
  * Go to admin > Site Setup > Add-ons
  * Activate eea.volto.policy


Authors
=======
  "European Environment Agency", mailto:eea-edw-a-team-alerts@googlegroups.com
