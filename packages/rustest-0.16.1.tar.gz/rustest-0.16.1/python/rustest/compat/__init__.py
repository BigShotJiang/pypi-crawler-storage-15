"""Compatibility shims for other testing frameworks."""

__all__ = []
