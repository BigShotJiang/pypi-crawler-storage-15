def test_example() -> None:
    assert 1 + 1 == 2
