CLASS_INDEX_MAP = {
    'background': 0,
    'nodule': 1,
}
