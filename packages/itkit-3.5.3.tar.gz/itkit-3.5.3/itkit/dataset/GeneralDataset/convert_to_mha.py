from itkit.dataset.base_convert import format_from_unsup_datasets

if __name__ == "__main__":
    formatter = format_from_unsup_datasets()
    formatter.execute()
