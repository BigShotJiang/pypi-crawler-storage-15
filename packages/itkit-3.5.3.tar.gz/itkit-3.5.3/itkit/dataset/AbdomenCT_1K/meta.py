CLASS_INDEX_MAP = {
    'background': 0,
    'liver': 1,         # 肝脏
    'kidney': 2,        # 肾脏
    'spleen': 3,        # 脾脏
    'pancreas': 4,      # 胰腺
}
