# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Planned
- Add support for video processing
- Batch processing optimization
- Caching for repeated API calls
- Additional export formats (COCO, YOLO)

## [0.1.0] - 2025-12-02

### Added
- Initial release of vsegments
- Bounding box detection using Google Gemini AI
- Segmentation mask generation
- Command-line interface (CLI) with comprehensive options
- Python library API for programmatic access
- Visualization with customizable colors, fonts, and transparency
- JSON export functionality
- Support for multiple Gemini models
- Custom prompt and system instruction support
- Cross-platform font support (macOS, Linux, Windows)
- Comprehensive documentation and examples

### Features
- `VSegments` class for library usage
- CLI tool with flags: `-f/--file`, `--segment`, `-p/--prompt`, `--instructions`, `-o/--output`, `--json`, and more
- Automatic font detection and fallback
- Image resizing for optimal processing
- Raw API response access
- Quiet mode for batch processing

### Models Supported
- gemini-flash-latest (default)
- gemini-2.0-flash
- gemini-2.5-flash-lite
- gemini-2.5-flash
- gemini-2.5-pro

### Dependencies
- google-genai >= 1.16.0
- pillow >= 9.0.0
- numpy >= 1.20.0

[Unreleased]: https://github.com/yourusername/vsegments/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/yourusername/vsegments/releases/tag/v0.1.0
