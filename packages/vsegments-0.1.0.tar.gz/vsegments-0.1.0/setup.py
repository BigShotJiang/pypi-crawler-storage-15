"""Setup script for vsegments package (legacy support)."""

from setuptools import setup

# All configuration is in pyproject.toml
# This file exists for compatibility with older tools
setup()
