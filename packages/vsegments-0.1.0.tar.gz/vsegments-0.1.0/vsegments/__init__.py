"""
vsegments - Visual Segmentation Library
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

A Python library for image segmentation and bounding box detection using Google Gemini AI.

Basic usage:

    >>> from vsegments import VSegments
    >>> vs = VSegments(api_key="your-api-key")
    >>> result = vs.detect_boxes("image.jpg")
    >>> vs.plot_boxes(result)

:copyright: (c) 2025 Marco Kotrotsos
:license: MIT, see LICENSE for more details.
"""

from vsegments.__version__ import (
    __version__,
    __author__,
    __email__,
    __description__,
)
from vsegments.core import VSegments
from vsegments.models import BoundingBox, SegmentationResult

__all__ = [
    "VSegments",
    "BoundingBox",
    "SegmentationResult",
    "__version__",
    "__author__",
    "__email__",
    "__description__",
]
