"""Utility functions for parsing and processing API responses."""

import json
import base64
import io
from typing import List
import numpy as np
from PIL import Image

from vsegments.models import BoundingBox, SegmentationMask


def parse_json(json_output: str) -> str:
    """Parse JSON output, removing markdown fencing if present.
    
    Args:
        json_output: Raw JSON string, possibly wrapped in markdown code blocks
        
    Returns:
        Cleaned JSON string
    """
    lines = json_output.splitlines()
    for i, line in enumerate(lines):
        if line.strip() == "```json":
            json_output = "\n".join(lines[i+1:])
            json_output = json_output.split("```")[0]
            break
    return json_output.strip()


def parse_bounding_boxes(response_text: str) -> List[BoundingBox]:
    """Parse bounding boxes from API response.
    
    Args:
        response_text: Raw response text from the API
        
    Returns:
        List of BoundingBox objects
    """
    cleaned_json = parse_json(response_text)
    data = json.loads(cleaned_json)
    
    boxes = []
    for item in data:
        if "box_2d" in item:
            boxes.append(BoundingBox.from_dict(item))
    
    return boxes


def parse_segmentation_masks(
    response_text: str, 
    img_height: int, 
    img_width: int
) -> List[SegmentationMask]:
    """Parse segmentation masks from API response.
    
    Args:
        response_text: Raw response text from the API
        img_height: Height of the original image in pixels
        img_width: Width of the original image in pixels
        
    Returns:
        List of SegmentationMask objects
    """
    cleaned_json = parse_json(response_text)
    items = json.loads(cleaned_json)
    
    masks = []
    for item in items:
        # Parse bounding box
        abs_y0 = int(item["box_2d"][0] / 1000 * img_height)
        abs_x0 = int(item["box_2d"][1] / 1000 * img_width)
        abs_y1 = int(item["box_2d"][2] / 1000 * img_height)
        abs_x1 = int(item["box_2d"][3] / 1000 * img_width)
        
        if abs_y0 >= abs_y1 or abs_x0 >= abs_x1:
            print(f"Warning: Invalid bounding box {item['box_2d']}")
            continue
            
        label = item.get("label", "")
        
        # Parse mask
        png_str = item.get("mask", "")
        if not png_str.startswith("data:image/png;base64,"):
            print("Warning: Invalid mask format")
            continue
            
        png_str = png_str.removeprefix("data:image/png;base64,")
        png_bytes = base64.b64decode(png_str)
        mask_img = Image.open(io.BytesIO(png_bytes))
        
        # Resize mask to bounding box dimensions
        bbox_height = abs_y1 - abs_y0
        bbox_width = abs_x1 - abs_x0
        
        if bbox_height < 1 or bbox_width < 1:
            print("Warning: Invalid bounding box dimensions")
            continue
            
        mask_img = mask_img.resize(
            (bbox_width, bbox_height), 
            resample=Image.Resampling.BILINEAR
        )
        
        # Create full-size mask array
        np_mask = np.zeros((img_height, img_width), dtype=np.uint8)
        np_mask[abs_y0:abs_y1, abs_x0:abs_x1] = mask_img
        
        masks.append(SegmentationMask(abs_y0, abs_x0, abs_y1, abs_x1, np_mask, label))
    
    return masks
