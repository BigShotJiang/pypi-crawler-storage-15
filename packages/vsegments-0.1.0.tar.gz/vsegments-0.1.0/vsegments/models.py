"""Data models for vsegments."""

from dataclasses import dataclass
from typing import List, Optional
import numpy as np


@dataclass
class BoundingBox:
    """Represents a 2D bounding box with label."""
    
    label: str
    y1: int  # Top coordinate (normalized 0-1000)
    x1: int  # Left coordinate (normalized 0-1000)
    y2: int  # Bottom coordinate (normalized 0-1000)
    x2: int  # Right coordinate (normalized 0-1000)
    
    @classmethod
    def from_dict(cls, data: dict) -> "BoundingBox":
        """Create BoundingBox from API response dictionary."""
        box_2d = data["box_2d"]
        return cls(
            label=data.get("label", ""),
            y1=box_2d[0],
            x1=box_2d[1],
            y2=box_2d[2],
            x2=box_2d[3],
        )
    
    def to_absolute(self, img_width: int, img_height: int) -> tuple:
        """Convert normalized coordinates to absolute pixel coordinates.
        
        Returns:
            tuple: (x1, y1, x2, y2) in absolute coordinates
        """
        abs_y1 = int(self.y1 / 1000 * img_height)
        abs_x1 = int(self.x1 / 1000 * img_width)
        abs_y2 = int(self.y2 / 1000 * img_height)
        abs_x2 = int(self.x2 / 1000 * img_width)
        
        # Ensure correct ordering
        if abs_x1 > abs_x2:
            abs_x1, abs_x2 = abs_x2, abs_x1
        if abs_y1 > abs_y2:
            abs_y1, abs_y2 = abs_y2, abs_y1
            
        return abs_x1, abs_y1, abs_x2, abs_y2


@dataclass(frozen=True)
class SegmentationMask:
    """Represents a segmentation mask for an object."""
    
    y0: int  # Top coordinate (absolute pixels)
    x0: int  # Left coordinate (absolute pixels)
    y1: int  # Bottom coordinate (absolute pixels)
    x1: int  # Right coordinate (absolute pixels)
    mask: np.ndarray  # [img_height, img_width] with values 0..255
    label: str


@dataclass
class SegmentationResult:
    """Container for segmentation/detection results."""
    
    boxes: List[BoundingBox]
    masks: Optional[List[SegmentationMask]] = None
    raw_response: Optional[str] = None
    
    def __len__(self) -> int:
        """Return number of detected objects."""
        return len(self.boxes)
