"""Visualization utilities for drawing bounding boxes and segmentation masks."""

import os
from typing import List, Optional, Tuple
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageColor

from vsegments.models import BoundingBox, SegmentationMask


# Extended color palette
COLORS = [
    'red', 'green', 'blue', 'yellow', 'orange', 'pink', 'purple', 'brown',
    'gray', 'beige', 'turquoise', 'cyan', 'magenta', 'lime', 'navy', 'maroon',
    'teal', 'olive', 'coral', 'lavender', 'violet', 'gold', 'silver',
] + [colorname for (colorname, _) in ImageColor.colormap.items()]


def get_font(size: int = 14) -> ImageFont.FreeTypeFont:
    """Load a suitable font, with fallbacks for different platforms.
    
    Args:
        size: Font size in points
        
    Returns:
        ImageFont object
    """
    font_paths = [
        "NotoSansCJK-Regular.ttc",  # Colab
        "/System/Library/Fonts/Supplemental/Arial.ttf",  # macOS
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",  # Linux
        "C:\\Windows\\Fonts\\arial.ttf",  # Windows
    ]
    
    for font_path in font_paths:
        try:
            return ImageFont.truetype(font_path, size=size)
        except (OSError, IOError):
            continue
    
    # Fall back to default font
    return ImageFont.load_default()


def plot_bounding_boxes(
    image: Image.Image,
    boxes: List[BoundingBox],
    line_width: int = 4,
    font_size: int = 14,
    show_labels: bool = True,
) -> Image.Image:
    """Draw bounding boxes on an image.
    
    Args:
        image: PIL Image to draw on
        boxes: List of BoundingBox objects
        line_width: Width of bounding box lines
        font_size: Size of label text
        show_labels: Whether to draw labels
        
    Returns:
        PIL Image with bounding boxes drawn
    """
    img = image.copy()
    width, height = img.size
    draw = ImageDraw.Draw(img)
    font = get_font(font_size)
    
    for i, box in enumerate(boxes):
        color = COLORS[i % len(COLORS)]
        
        # Get absolute coordinates
        abs_x1, abs_y1, abs_x2, abs_y2 = box.to_absolute(width, height)
        
        # Draw rectangle
        draw.rectangle(
            ((abs_x1, abs_y1), (abs_x2, abs_y2)),
            outline=color,
            width=line_width
        )
        
        # Draw label
        if show_labels and box.label:
            draw.text(
                (abs_x1 + 8, abs_y1 + 6),
                box.label,
                fill=color,
                font=font
            )
    
    return img


def overlay_mask_on_image(
    image: Image.Image,
    mask: np.ndarray,
    color: str,
    alpha: float = 0.7
) -> Image.Image:
    """Overlay a single mask onto an image with transparency.
    
    Args:
        image: Base PIL Image
        mask: NumPy array [height, width] with values 0-255
        color: Color name string (e.g., 'red', 'blue')
        alpha: Transparency level (0.0-1.0)
        
    Returns:
        PIL Image with mask overlaid
    """
    if not (0.0 <= alpha <= 1.0):
        raise ValueError("Alpha must be between 0.0 and 1.0")
    
    # Convert color name to RGB
    color_rgb = ImageColor.getrgb(color)
    
    # Prepare image for compositing
    img_rgba = image.convert("RGBA")
    width, height = img_rgba.size
    
    # Create colored overlay
    alpha_int = int(alpha * 255)
    overlay_color_rgba = color_rgb + (alpha_int,)
    
    # Create RGBA layer
    colored_mask_layer = np.zeros((height, width, 4), dtype=np.uint8)
    mask_logical = mask > 127
    colored_mask_layer[mask_logical] = overlay_color_rgba
    
    # Convert to PIL and composite
    colored_mask_pil = Image.fromarray(colored_mask_layer, 'RGBA')
    result = Image.alpha_composite(img_rgba, colored_mask_pil)
    
    return result


def plot_segmentation_masks(
    image: Image.Image,
    masks: List[SegmentationMask],
    line_width: int = 4,
    font_size: int = 14,
    alpha: float = 0.7,
    show_labels: bool = True,
) -> Image.Image:
    """Draw segmentation masks on an image.
    
    Args:
        image: PIL Image to draw on
        masks: List of SegmentationMask objects
        line_width: Width of bounding box lines
        font_size: Size of label text
        alpha: Transparency level for masks (0.0-1.0)
        show_labels: Whether to draw labels
        
    Returns:
        PIL Image with segmentation masks drawn
    """
    img = image.copy()
    font = get_font(font_size)
    
    # Overlay masks first
    for i, mask in enumerate(masks):
        color = COLORS[i % len(COLORS)]
        img = overlay_mask_on_image(img, mask.mask, color, alpha)
    
    # Draw bounding boxes and labels
    draw = ImageDraw.Draw(img)
    
    for i, mask in enumerate(masks):
        color = COLORS[i % len(COLORS)]
        
        # Draw bounding box
        draw.rectangle(
            ((mask.x0, mask.y0), (mask.x1, mask.y1)),
            outline=color,
            width=line_width
        )
        
        # Draw label
        if show_labels and mask.label:
            draw.text(
                (mask.x0 + 8, mask.y0 - 20),
                mask.label,
                fill=color,
                font=font
            )
    
    return img
