"""Version information for vsegments."""

__version__ = "0.1.0"
__author__ = "Marco Kotrotsos"
__email__ = "your.email@example.com"
__description__ = "Visual segmentation and bounding box detection using Google Gemini AI"
