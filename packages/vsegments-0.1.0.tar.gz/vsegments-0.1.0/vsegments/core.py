"""Core VSegments class for image segmentation and bounding box detection."""

import os
from pathlib import Path
from typing import Union, Optional, List
from PIL import Image
from io import BytesIO

from google import genai
from google.genai import types

from vsegments.models import BoundingBox, SegmentationResult
from vsegments.utils import parse_bounding_boxes, parse_segmentation_masks
from vsegments.visualize import plot_bounding_boxes, plot_segmentation_masks


class VSegments:
    """Main class for visual segmentation using Google Gemini AI.
    
    Args:
        api_key: Google API key. If not provided, will use GOOGLE_API_KEY env var.
        model: Model name to use (default: gemini-flash-latest)
        temperature: Sampling temperature (default: 0.5)
        max_objects: Maximum number of objects to detect (default: 25)
    """
    
    DEFAULT_SYSTEM_INSTRUCTIONS = """
    Return bounding boxes as a JSON array with labels. Never return masks or code fencing. Limit to {max_objects} objects.
    If an object is present multiple times, name them according to their unique characteristic (colors, size, position, unique characteristics, etc..).
    """
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = "gemini-flash-latest",
        temperature: float = 0.5,
        max_objects: int = 25,
    ):
        """Initialize VSegments client."""
        self.api_key = api_key or os.getenv("GOOGLE_API_KEY")
        if not self.api_key:
            raise ValueError(
                "API key must be provided or set in GOOGLE_API_KEY environment variable"
            )
        
        self.model = model
        self.temperature = temperature
        self.max_objects = max_objects
        
        # Initialize client
        self.client = genai.Client(api_key=self.api_key)
        
        # Safety settings
        self.safety_settings = [
            types.SafetySetting(
                category="HARM_CATEGORY_DANGEROUS_CONTENT",
                threshold="BLOCK_ONLY_HIGH",
            ),
        ]
    
    def _load_image(
        self, 
        image_path: Union[str, Path], 
        max_size: int = 1024
    ) -> Image.Image:
        """Load and resize image.
        
        Args:
            image_path: Path to image file
            max_size: Maximum dimension for resizing
            
        Returns:
            PIL Image object
        """
        with open(image_path, "rb") as f:
            img = Image.open(BytesIO(f.read()))
        
        img.thumbnail([max_size, max_size], Image.Resampling.LANCZOS)
        return img
    
    def _get_system_instructions(
        self, 
        custom_instructions: Optional[str] = None
    ) -> str:
        """Get system instructions with custom additions.
        
        Args:
            custom_instructions: Additional instructions to append
            
        Returns:
            Complete system instructions string
        """
        instructions = self.DEFAULT_SYSTEM_INSTRUCTIONS.format(
            max_objects=self.max_objects
        )
        
        if custom_instructions:
            instructions += f"\n{custom_instructions}"
        
        return instructions
    
    def detect_boxes(
        self,
        image_path: Union[str, Path],
        prompt: Optional[str] = None,
        custom_instructions: Optional[str] = None,
        max_size: int = 1024,
    ) -> SegmentationResult:
        """Detect bounding boxes in an image.
        
        Args:
            image_path: Path to image file
            prompt: Custom prompt (default: "Detect the 2d bounding boxes")
            custom_instructions: Additional system instructions
            max_size: Maximum image dimension
            
        Returns:
            SegmentationResult with detected bounding boxes
        """
        # Load image
        img = self._load_image(image_path, max_size)
        
        # Prepare prompt
        if prompt is None:
            prompt = "Detect the 2d bounding boxes"
        
        # Generate content
        response = self.client.models.generate_content(
            model=self.model,
            contents=[prompt, img],
            config=types.GenerateContentConfig(
                system_instruction=self._get_system_instructions(custom_instructions),
                temperature=self.temperature,
                safety_settings=self.safety_settings,
                thinking_config=types.ThinkingConfig(thinking_budget=0)
            )
        )
        
        # Parse response
        boxes = parse_bounding_boxes(response.text)
        
        return SegmentationResult(
            boxes=boxes,
            raw_response=response.text
        )
    
    def segment(
        self,
        image_path: Union[str, Path],
        prompt: Optional[str] = None,
        max_size: int = 1024,
    ) -> SegmentationResult:
        """Perform segmentation on an image.
        
        Args:
            image_path: Path to image file
            prompt: Custom prompt (default: auto-generated)
            max_size: Maximum image dimension
            
        Returns:
            SegmentationResult with segmentation masks and bounding boxes
        """
        # Load image
        img = self._load_image(image_path, max_size)
        
        # Prepare prompt
        if prompt is None:
            prompt = (
                'Give the segmentation masks for the objects. '
                'Output a JSON list of segmentation masks where each entry contains '
                'the 2D bounding box in the key "box_2d", the segmentation mask in key "mask", '
                'and the text label in the key "label". Use descriptive labels.'
            )
        
        # Generate content (no system instructions for segmentation)
        response = self.client.models.generate_content(
            model=self.model,
            contents=[prompt, img],
            config=types.GenerateContentConfig(
                temperature=self.temperature,
                safety_settings=self.safety_settings,
                thinking_config=types.ThinkingConfig(thinking_budget=0)
            )
        )
        
        # Parse response
        boxes = parse_bounding_boxes(response.text)
        masks = parse_segmentation_masks(
            response.text,
            img_height=img.size[1],
            img_width=img.size[0]
        )
        
        return SegmentationResult(
            boxes=boxes,
            masks=masks,
            raw_response=response.text
        )
    
    def visualize(
        self,
        image_path: Union[str, Path],
        result: SegmentationResult,
        output_path: Optional[Union[str, Path]] = None,
        show: bool = True,
        line_width: int = 4,
        font_size: int = 14,
        alpha: float = 0.7,
    ) -> Image.Image:
        """Visualize detection/segmentation results.
        
        Args:
            image_path: Path to original image
            result: SegmentationResult to visualize
            output_path: Path to save output (optional)
            show: Whether to display the image
            line_width: Width of bounding box lines
            font_size: Size of label text
            alpha: Transparency for segmentation masks
            
        Returns:
            PIL Image with visualizations
        """
        # Load original image
        img = self._load_image(image_path, max_size=2048)
        
        # Draw visualizations
        if result.masks:
            img = plot_segmentation_masks(
                img, result.masks, line_width, font_size, alpha
            )
        else:
            img = plot_bounding_boxes(
                img, result.boxes, line_width, font_size
            )
        
        # Save if requested
        if output_path:
            img.save(output_path)
        
        # Show if requested
        if show:
            img.show()
        
        return img
