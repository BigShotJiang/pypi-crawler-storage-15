#!/usr/bin/env python3
"""Command-line interface for vsegments."""

import argparse
import sys
import os
import json
from pathlib import Path
from typing import Optional

from vsegments import VSegments, __version__
from vsegments.models import SegmentationResult


def create_parser() -> argparse.ArgumentParser:
    """Create argument parser for CLI."""
    parser = argparse.ArgumentParser(
        prog="vsegments",
        description="Visual segmentation and bounding box detection using Google Gemini AI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Detect bounding boxes
  vsegments -f image.jpg
  
  # Detect with custom prompt
  vsegments -f image.jpg -p "Find all people in the image"
  
  # Perform segmentation
  vsegments -f image.jpg --segment
  
  # Save output image
  vsegments -f image.jpg -o output.jpg
  
  # Export JSON results
  vsegments -f image.jpg --json results.json
  
  # Use custom model
  vsegments -f image.jpg -m gemini-2.5-pro
  
  # Add custom instructions
  vsegments -f image.jpg --instructions "Focus on objects larger than 100 pixels"
  
  # Compact output (no visualization)
  vsegments -f image.jpg --compact
        """
    )
    
    # Required arguments
    parser.add_argument(
        "-f", "--file",
        type=str,
        required=True,
        help="Path to input image file",
        metavar="IMAGE"
    )
    
    # Mode selection
    mode_group = parser.add_argument_group("mode options")
    mode_group.add_argument(
        "--segment",
        action="store_true",
        help="Perform segmentation instead of bounding box detection"
    )
    
    # API configuration
    api_group = parser.add_argument_group("API options")
    api_group.add_argument(
        "--api-key",
        type=str,
        help="Google API key (default: GOOGLE_API_KEY env var)",
        metavar="KEY"
    )
    api_group.add_argument(
        "-m", "--model",
        type=str,
        default="gemini-flash-latest",
        help="Model name to use (default: gemini-flash-latest)",
        metavar="MODEL"
    )
    api_group.add_argument(
        "--temperature",
        type=float,
        default=0.5,
        help="Sampling temperature 0.0-1.0 (default: 0.5)",
        metavar="TEMP"
    )
    api_group.add_argument(
        "--max-objects",
        type=int,
        default=25,
        help="Maximum number of objects to detect (default: 25)",
        metavar="N"
    )
    
    # Prompt customization
    prompt_group = parser.add_argument_group("prompt options")
    prompt_group.add_argument(
        "-p", "--prompt",
        type=str,
        help="Custom detection prompt",
        metavar="TEXT"
    )
    prompt_group.add_argument(
        "--instructions",
        type=str,
        help="Additional system instructions for grounding",
        metavar="TEXT"
    )
    
    # Output options
    output_group = parser.add_argument_group("output options")
    output_group.add_argument(
        "-o", "--output",
        type=str,
        help="Save visualized output to file",
        metavar="FILE"
    )
    output_group.add_argument(
        "--json",
        type=str,
        help="Export results as JSON to file",
        metavar="FILE"
    )
    output_group.add_argument(
        "--no-show",
        action="store_true",
        help="Don't display the output image"
    )
    output_group.add_argument(
        "--raw",
        action="store_true",
        help="Print raw API response"
    )
    output_group.add_argument(
        "--compact",
        action="store_true",
        help="Compact output format: order. subject [x y xx yy]"
    )
    
    # Visualization options
    viz_group = parser.add_argument_group("visualization options")
    viz_group.add_argument(
        "--line-width",
        type=int,
        default=4,
        help="Bounding box line width (default: 4)",
        metavar="N"
    )
    viz_group.add_argument(
        "--font-size",
        type=int,
        default=14,
        help="Label font size (default: 14)",
        metavar="N"
    )
    viz_group.add_argument(
        "--alpha",
        type=float,
        default=0.7,
        help="Mask transparency 0.0-1.0 (default: 0.7)",
        metavar="A"
    )
    viz_group.add_argument(
        "--max-size",
        type=int,
        default=1024,
        help="Maximum image dimension for processing (default: 1024)",
        metavar="N"
    )
    
    # Other options
    parser.add_argument(
        "-v", "--version",
        action="version",
        version=f"%(prog)s {__version__}"
    )
    parser.add_argument(
        "-q", "--quiet",
        action="store_true",
        help="Suppress informational output"
    )
    
    return parser


def export_json(result: SegmentationResult, output_path: str):
    """Export results to JSON file.
    
    Args:
        result: SegmentationResult to export
        output_path: Path to JSON file
    """
    data = {
        "num_objects": len(result.boxes),
        "boxes": [
            {
                "label": box.label,
                "coordinates": {
                    "y1": box.y1,
                    "x1": box.x1,
                    "y2": box.y2,
                    "x2": box.x2,
                }
            }
            for box in result.boxes
        ]
    }
    
    if result.masks:
        data["has_masks"] = True
        data["num_masks"] = len(result.masks)
    
    with open(output_path, 'w') as f:
        json.dump(data, f, indent=2)


def main(argv: Optional[list] = None) -> int:
    """Main entry point for CLI.
    
    Args:
        argv: Command-line arguments (default: sys.argv[1:])
        
    Returns:
        Exit code (0 for success, non-zero for error)
    """
    parser = create_parser()
    args = parser.parse_args(argv)
    
    # Validate input file
    if not Path(args.file).exists():
        print(f"Error: File not found: {args.file}", file=sys.stderr)
        return 1
    
    try:
        # Initialize client
        if not args.quiet and not args.compact:
            print(f"Initializing vsegments with model: {args.model}")
        
        vs = VSegments(
            api_key=args.api_key,
            model=args.model,
            temperature=args.temperature,
            max_objects=args.max_objects,
        )
        
        # Process image
        if args.segment:
            if not args.quiet and not args.compact:
                print(f"Performing segmentation on: {args.file}")
            result = vs.segment(
                image_path=args.file,
                prompt=args.prompt,
                max_size=args.max_size,
            )
        else:
            if not args.quiet and not args.compact:
                print(f"Detecting bounding boxes in: {args.file}")
            result = vs.detect_boxes(
                image_path=args.file,
                prompt=args.prompt,
                custom_instructions=args.instructions,
                max_size=args.max_size,
            )
        
        # Print results
        if args.compact:
            # Compact output: order. subject [x y xx yy]
            for i, box in enumerate(result.boxes, 1):
                print(f"{i}. {box.label} [{box.x1} {box.y1} {box.x2} {box.y2}]")
        elif not args.quiet:
            print(f"\nDetected {len(result.boxes)} object(s):")
            for i, box in enumerate(result.boxes, 1):
                print(f"  {i}. {box.label}")
        
        # Print raw response if requested
        if args.raw and not args.compact:
            print("\nRaw API Response:")
            print(result.raw_response)
        
        # Export JSON if requested (skip in compact mode)
        if args.json and not args.compact:
            export_json(result, args.json)
            if not args.quiet:
                print(f"\nExported results to: {args.json}")
        
        # Visualize (skip in compact mode unless explicitly requested)
        if not args.compact and (args.output or not args.no_show):
            if not args.quiet:
                print("\nGenerating visualization...")
            
            vs.visualize(
                image_path=args.file,
                result=result,
                output_path=args.output,
                show=not args.no_show,
                line_width=args.line_width,
                font_size=args.font_size,
                alpha=args.alpha,
            )
            
            if args.output and not args.quiet:
                print(f"Saved visualization to: {args.output}")
        
        return 0
        
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\nInterrupted by user", file=sys.stderr)
        return 130
    except Exception as e:
        print(f"Unexpected error: {e}", file=sys.stderr)
        if not args.quiet:
            import traceback
            traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
