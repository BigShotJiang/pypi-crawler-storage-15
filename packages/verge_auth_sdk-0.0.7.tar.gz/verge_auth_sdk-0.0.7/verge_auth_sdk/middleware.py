from fastapi import FastAPI, Request
from fastapi.responses import RedirectResponse, JSONResponse
from .secret_provider import get_secret
from .verge_routes import router as verge_routes_router
from typing import TypedDict, List
import httpx
import os
import asyncio


class RouteInfo(TypedDict):
    path: str
    method: str


REGISTERED_ROUTES: List[RouteInfo] = []
SYNC_DONE = False
SYNC_LOCK = asyncio.Lock()


def add_central_auth(app: FastAPI):

    AUTH_INTROSPECT_URL = os.getenv("AUTH_INTROSPECT_URL")
    AUTH_LOGIN_URL = os.getenv("AUTH_LOGIN_URL")
    CLIENT_ID = os.getenv("VERGE_CLIENT_ID")
    CLIENT_SECRET = os.getenv("VERGE_CLIENT_SECRET")

    SERVICE_NAME = os.getenv("SERVICE_NAME")
    SERVICE_BASE_URL = os.getenv("SERVICE_BASE_URL")
    AUTH_REGISTER_URL = os.getenv("AUTH_REGISTER_URL")
    VERGE_SECRET = get_secret("VERGE_SERVICE_SECRET")

    # Mount internal SDK routes
    app.include_router(verge_routes_router)

    # --------------------------------------------------------
    # HELPERS
    # --------------------------------------------------------
    async def collect_routes():
        REGISTERED_ROUTES.clear()
        for route in app.routes:
            try:
                path = getattr(route, "path", None)
                methods = getattr(route, "methods", [])
                if not path:
                    continue

                if path.startswith(("/docs", "/openapi", "/__verge__")):
                    continue

                for m in methods:
                    if m in ("GET", "POST", "PUT", "PATCH", "DELETE"):
                        REGISTERED_ROUTES.append({"path": path, "method": m})

            except Exception as e:
                print("Route error:", e)

        print("Collected routes:", REGISTERED_ROUTES)

    async def sync_service_routes_once():
        global SYNC_DONE
        async with SYNC_LOCK:
            if SYNC_DONE:
                return

            print("🔄 Syncing routes with auth-service...")

            await collect_routes()

            try:
                async with httpx.AsyncClient() as client:
                    resp = await client.post(
                        AUTH_REGISTER_URL,
                        params={"name": SERVICE_NAME,
                                "base_url": SERVICE_BASE_URL},
                        headers={"X-Verge-Service-Secret": VERGE_SECRET},
                        json=REGISTERED_ROUTES,
                    )
                    print("Sync response:", resp.status_code, resp.text)
            except Exception as e:
                print("Sync failed:", e)
                return

            SYNC_DONE = True
            print("✅ Sync completed")

    # --------------------------------------------------------
    # MAIN AUTH MIDDLEWARE
    # --------------------------------------------------------
    @app.middleware("http")
    async def central_auth(request: Request, call_next):

        # 🔥 First request triggers sync
        if not SYNC_DONE:
            asyncio.create_task(sync_service_routes_once())

        path = request.url.path

        if path.startswith("/__verge__") or path in {"/health", "/docs", "/openapi.json"}:
            return await call_next(request)

        # extract JWT
        token = None
        auth = request.headers.get("authorization")

        if auth and auth.lower().startswith("bearer "):
            token = auth.split(" ")[1]

        if not token:
            token = request.cookies.get("access_token")

        # no token → redirect or 401
        if not token:
            if "text/html" in request.headers.get("accept", ""):
                return RedirectResponse(f"{AUTH_LOGIN_URL}?redirect_url={request.url}")

            return JSONResponse({"detail": "Unauthorized"}, status_code=401)

        # verify token
        try:
            async with httpx.AsyncClient(timeout=3) as client:
                res = await client.post(
                    AUTH_INTROSPECT_URL,
                    headers={
                        "Authorization": f"Bearer {token}",
                        "X-Client-Id": CLIENT_ID,
                        "X-Client-Secret": CLIENT_SECRET,
                    },
                )
                data = res.json()
        except Exception:
            return JSONResponse({"detail": "Auth service unreachable"}, status_code=503)

        if not data.get("active"):
            return JSONResponse({"detail": "Session expired"}, status_code=401)

        request.state.user = data.get("user", {})
        request.state.roles = data.get("roles", [])

        return await call_next(request)
