import os
from functools import lru_cache


@lru_cache(maxsize=64)
def get_secret(name: str) -> str:
    provider = os.getenv("SECRETS_PROVIDER", "env").lower()

    try:
        if provider == "env":
            return _from_env(name)

        if provider == "azure":
            return _from_azure(name)

        if provider == "aws":
            return _from_aws(name)

    except Exception:
        # fallback to env
        value = os.getenv(name)
        if value:
            return value
        raise

    raise Exception(f"Unknown secrets provider: {provider}")


def _from_env(name: str) -> str:
    value = os.getenv(name)
    if not value:
        raise Exception(f"Missing secret in env: {name}")
    return value


def _from_azure(name: str) -> str:
    key_vault_url = os.getenv("AZURE_KEY_VAULT_URL")
    if not key_vault_url:
        raise Exception("AZURE_KEY_VAULT_URL not configured")

    try:
        from azure.identity import DefaultAzureCredential
        from azure.keyvault.secrets import SecretClient
    except ImportError:
        raise Exception("Azure Key Vault dependencies not installed")

    credential = DefaultAzureCredential()
    client = SecretClient(vault_url=key_vault_url, credential=credential)
    return client.get_secret(name).value


def _from_aws(name: str) -> str:
    region = os.getenv("AWS_REGION")
    if not region:
        raise Exception("AWS_REGION not configured")

    try:
        import boto3
    except ImportError:
        raise Exception("boto3 not installed")

    client = boto3.client("secretsmanager", region_name=region)
    response = client.get_secret_value(SecretId=name)

    return response.get("SecretString") or response["SecretBinary"].decode()
