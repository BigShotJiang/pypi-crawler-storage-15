# ruff: noqa: E402
from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from ai.backend.manager.api.gql.data_loader.registry import DataLoaderRegistry
from ai.backend.manager.config.provider import ManagerConfigProvider
from ai.backend.manager.services.processors import Processors

if TYPE_CHECKING:
    from ai.backend.common.events.fetcher import EventFetcher
    from ai.backend.common.events.hub.hub import EventHub
    from ai.backend.manager.api.gql.adapters import GQLAdapters


@dataclass
class StrawberryGQLContext:
    processors: Processors
    config_provider: ManagerConfigProvider
    event_hub: EventHub
    event_fetcher: EventFetcher
    dataloader_registry: DataLoaderRegistry
    gql_adapters: GQLAdapters
