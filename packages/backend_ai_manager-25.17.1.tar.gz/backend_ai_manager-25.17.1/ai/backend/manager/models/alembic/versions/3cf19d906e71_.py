"""empty message

Revision ID: 3cf19d906e71
Revises: 22964745c12b, 5d8e6043455e
Create Date: 2019-06-17 16:45:14.580560

"""

# revision identifiers, used by Alembic.
revision = "3cf19d906e71"
down_revision = ("22964745c12b", "5d8e6043455e")
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
