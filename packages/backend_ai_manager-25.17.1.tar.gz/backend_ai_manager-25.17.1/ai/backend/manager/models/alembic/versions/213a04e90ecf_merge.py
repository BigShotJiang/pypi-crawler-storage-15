"""merge

Revision ID: 213a04e90ecf
Revises: c53397a490be, 95f51fc6ffdb
Create Date: 2022-12-04 17:06:35.494627

"""

# revision identifiers, used by Alembic.
revision = "213a04e90ecf"
down_revision = ("c53397a490be", "95f51fc6ffdb")
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
