"""empty message

Revision ID: 0f7a4b643940
Revises: 7dd1d81c3204, 911023380bc9
Create Date: 2022-03-14 06:20:12.850338

"""

# revision identifiers, used by Alembic.
revision = "0f7a4b643940"
down_revision = ("7dd1d81c3204", "911023380bc9")
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
