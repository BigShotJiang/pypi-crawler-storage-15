from .anifetch_rs import *

__doc__ = anifetch_rs.__doc__
if hasattr(anifetch_rs, "__all__"):
    __all__ = anifetch_rs.__all__