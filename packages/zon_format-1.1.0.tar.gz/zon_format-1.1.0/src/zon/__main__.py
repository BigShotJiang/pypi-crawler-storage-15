"""Entry point for running ZON as a module with 'python -m zon'."""

from .cli import main

if __name__ == "__main__":
    main()
