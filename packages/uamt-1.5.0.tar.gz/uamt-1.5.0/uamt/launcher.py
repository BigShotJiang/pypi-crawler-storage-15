
import sys
from . import UAMT

def run():
    try:
        if hasattr(UAMT, "main"):
            return UAMT.main()
        else:
            print("main() function not found.")
    except Exception as e:
        print(f"Error: {e}")
