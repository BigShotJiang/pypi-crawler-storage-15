jobrunner-git plugin
====================

|build status|

shell-jobrunner plugin to provide "project plugin" context from git repos

See https://github.com/wwade/jobrunner


 ================== ============================ 
  package            status                      
 ================== ============================ 
  jobrunner-git      |PyPI Release|              
  shell-jobrunner    |shell-jobrunner Release|   
 ================== ============================ 

Installation
------------

.. code:: console

    $ pip install jobrunner-git

Uninstallation
--------------

.. code:: console

    $ pip uninstall jobrunner-git



.. |PyPI Release| image:: https://badge.fury.io/py/jobrunner-git.svg
    :target: https://badge.fury.io/py/jobrunner-git
   
.. |shell-jobrunner Release| image:: https://badge.fury.io/py/shell-jobrunner.svg
   :target: https://badge.fury.io/py/shell-jobrunner
   
.. |build status| image:: https://github.com/wwade/jobrunner-git/actions/workflows/python-package.yml/badge.svg
   :target: https://github.com/wwade/jobrunner-git/actions/workflows/python-package.yml

