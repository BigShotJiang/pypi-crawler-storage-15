"""Plugin system for Sonora."""
