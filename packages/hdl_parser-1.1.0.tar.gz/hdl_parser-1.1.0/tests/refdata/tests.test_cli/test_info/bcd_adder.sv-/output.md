## Module `bcd_adder`

Path `EXAMPLES/sv/bcd_adder.sv`

### Ports
                                                                           
| Name      | Dimension     | I/O         | Functional Description        |
|-----------|---------------|-------------|-------------------------------|
| `a`       | `[3:0]`       | `input`     |                               |
| `b`       | `[3:0]`       | `input`     |                               |
| `cin`     | `1`           | `input`     |                               |
| `sum`     | `[3:0]`       | `output`    |                               |
| `cout`    | `1`           | `output`    |                               |
                                                                           
## Module `tb_bcdadder`

Path `EXAMPLES/sv/bcd_adder.sv`

### Ports

No Ports

