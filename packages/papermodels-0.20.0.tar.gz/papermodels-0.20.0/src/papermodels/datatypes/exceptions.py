class LegendError(Exception):
    pass


class GeometryError(Exception):
    pass


class AnnotationError(Exception):
    pass
