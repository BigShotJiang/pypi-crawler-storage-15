"""Photosynthesis models for PhyTorch."""

from .fvcb import FvCB

__all__ = ['FvCB']
