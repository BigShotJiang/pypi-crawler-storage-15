# Licensed to the Apache Software Foundation (ASF) under one or more
# contributor license agreements.  See the NOTICE file distributed with
# this work for additional information regarding copyright ownership.
# The ASF licenses this file to You under the Apache License, Version 2.0
# (the "License"); you may not use this file except in compliance with
# the License.  You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import grpc

import admin_pb2 as admin__pb2


class AdminStub(object):
    """Missing associated documentation comment in .proto file."""

    def __init__(self, channel):
        """Constructor.

        Args:
            channel: A grpc.Channel.
        """
        self.ChangeLogLevel = channel.unary_unary(
                '/apache.rocketmq.v2.Admin/ChangeLogLevel',
                request_serializer=admin__pb2.ChangeLogLevelRequest.SerializeToString,
                response_deserializer=admin__pb2.ChangeLogLevelResponse.FromString,
                )


class AdminServicer(object):
    """Missing associated documentation comment in .proto file."""

    def ChangeLogLevel(self, request, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')


def add_AdminServicer_to_server(servicer, server):
    rpc_method_handlers = {
            'ChangeLogLevel': grpc.unary_unary_rpc_method_handler(
                    servicer.ChangeLogLevel,
                    request_deserializer=admin__pb2.ChangeLogLevelRequest.FromString,
                    response_serializer=admin__pb2.ChangeLogLevelResponse.SerializeToString,
            ),
    }
    generic_handler = grpc.method_handlers_generic_handler(
            'apache.rocketmq.v2.Admin', rpc_method_handlers)
    server.add_generic_rpc_handlers((generic_handler,))


 # This class is part of an EXPERIMENTAL API.
class Admin(object):
    """Missing associated documentation comment in .proto file."""

    @staticmethod
    def ChangeLogLevel(request,
            target,
            options=(),
            channel_credentials=None,
            call_credentials=None,
            insecure=False,
            compression=None,
            wait_for_ready=None,
            timeout=None,
            metadata=None):
        return grpc.experimental.unary_unary(request, target, '/apache.rocketmq.v2.Admin/ChangeLogLevel',
            admin__pb2.ChangeLogLevelRequest.SerializeToString,
            admin__pb2.ChangeLogLevelResponse.FromString,
            options, channel_credentials,
            insecure, call_credentials, compression, wait_for_ready, timeout, metadata)
