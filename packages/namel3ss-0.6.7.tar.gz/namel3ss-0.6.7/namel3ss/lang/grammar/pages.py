"""Page and page statement parsing."""

from __future__ import annotations
import ast
import re
from typing import TYPE_CHECKING, Any, Dict, List, Optional

if TYPE_CHECKING:
    from .helpers import _Line

from namel3ss.ast import (
    Action,
    ActionOperation,
    GoToPageOperation,
    LayoutMeta,
    Literal,
    LogLevel,
    LogStatement,
    Page,
    PageStatement,
    RunChainOperation,
    RunPromptOperation,
    ShowChart,
    ShowForm,
    ShowTable,
    ShowText,
    ToastOperation,
    VariableAssignment,
    FormField,
    BreakStatement,
    ContinueStatement,
    WhileLoop,
)
from namel3ss.ast.pages import ElifBlock, ForLoop, IfBlock


class PagesParserMixin:
    """Mixin providing page and page statement parsing methods."""

    def _parse_page(self, line: _Line) -> None:
        """Parse page declaration: page "name" at "/route":"""
        from .constants import PAGE_HEADER_RE
        
        # Check for common mistake: using { instead of :
        stripped = line.text.strip()
        if stripped.endswith('{'):
            raise self._error(
                "Page declaration must end with ':', not '{'. Example: page \"Dashboard\" at \"/\":",
                line
            )
        
        match = PAGE_HEADER_RE.match(stripped)
        if not match:
            self._unsupported(line, "page declaration")
        page_name = match.group(1)
        route = match.group(2)
        base_indent = self._indent(line.text)
        self._advance()
        statements = self._parse_page_statements(base_indent)
        page = Page(name=page_name, route=route, body=statements)  # Changed from statements= to body=
        self._ensure_app(line)
        if self._app:
            self._app.pages.append(page)

    def _parse_page_statements(self, parent_indent: int) -> List[PageStatement]:
        """Parse statements within a page block."""
        statements: List[PageStatement] = []
        while True:
            line = self._peek_line()
            if line is None:
                break
            stripped = line.text.strip()
            indent = self._indent(line.text)
            if self._should_skip_comment(stripped, line.number, line.text):
                self._advance()
                continue
            if indent <= parent_indent:
                break
            if stripped.startswith('show text '):
                statements.append(self._parse_show_text(line))
                continue
            if stripped.startswith('show table '):
                statements.append(self._parse_show_table(line))
                continue
            if stripped.startswith('show chart '):
                statements.append(self._parse_show_chart(line))
                continue
            if stripped.startswith('show form '):
                statements.append(self._parse_show_form(line))
                continue
            if stripped.startswith('if '):
                statements.append(self._parse_if_block(line, indent))
                continue
            if stripped.startswith('for '):
                statements.append(self._parse_for_loop(line, indent))
                continue
            if stripped.startswith('while '):
                statements.append(self._parse_while_loop(line, indent))
                continue
            if stripped == 'break':
                statements.append(self._parse_break_statement(line))
                continue
            if stripped == 'continue':
                statements.append(self._parse_continue_statement(line))
                continue
            if stripped.startswith('set '):
                statements.append(self._parse_variable_assignment(line))
                continue
            if stripped.startswith('action '):
                statements.append(self._parse_action_block(line, indent))
                continue
            if stripped.startswith('log '):
                statements.append(self._parse_log_statement(line))
                continue
            self._unsupported(line, "page statement")
        return statements

    def _parse_show_text(self, line: _Line) -> ShowText:
        """Parse show text statement."""
        match = re.match(
            r'^\s*show\s+text\s+(?P<quote>["\'])(?P<body>(?:[^\\]|\\.)*?)(?P=quote)\s*(?::\s*)?$',
            line.text,
        )
        if not match:
            raise self._error('Expected: show text "message"', line)
        text = self._decode_quoted_string(match.group("body"), match.group("quote"), line)
        has_block = line.text.rstrip().endswith(':')
        self._advance()
        styles: Dict[str, Any] = {}
        if has_block:
            styles = self._parse_component_block(self._indent(line.text))
        return ShowText(text=text, styles=styles)

    def _parse_show_table(self, line: _Line) -> ShowTable:
        """Parse show table statement."""
        stripped = line.text.rstrip()
        match = re.match(
            r'^\s*show\s+table\s+(?P<quote>["\'])(?P<title>(?:[^\\]|\\.)*?)(?P=quote)\s+from\s+(?P<source_type>dataset|table|frame)\s+(?P<source>[A-Za-z_][A-Za-z0-9_]*)\s*(?::\s*)?$',
            stripped,
        )
        if not match:
            self._unsupported(line, "show table statement")
        title = self._decode_quoted_string(match.group("title"), match.group("quote"), line)
        has_block = stripped.endswith(':')
        base_indent = self._indent(line.text)
        self._advance()
        config: Dict[str, Any] = {}
        if has_block:
            config = self._parse_component_block(base_indent)
        columns = None
        if isinstance(config.get("columns"), str):
            columns = [col.strip() for col in config.get("columns", "").split(',') if col.strip()]
        layout = self._build_layout_meta(config.pop("layout", None))
        style_cfg = config.pop("style", None)
        style = style_cfg if isinstance(style_cfg, dict) else None
        filter_by = config.get("filter by") or config.get("filter_by")
        sort_by = config.get("sort by") or config.get("sort_by")
        # Remove known keys from config to avoid duplicating into encodings/binding later
        for key in ("columns", "filter by", "filter_by", "sort by", "sort_by"):
            config.pop(key, None)
        return ShowTable(
            title=title,
            source_type=match.group("source_type"),
            source=match.group("source"),
            columns=columns,
            filter_by=filter_by,
            sort_by=sort_by,
            style=style,
            layout=layout,
        )

    def _parse_show_chart(self, line: _Line) -> ShowChart:
        """Parse show chart statement."""
        stripped = line.text.rstrip()
        match = re.match(
            r'^\s*show\s+chart\s+(?P<quote>["\'])(?P<title>(?:[^\\]|\\.)*?)(?P=quote)\s+from\s+(?P<source_type>dataset|table|frame)\s+(?P<source>[A-Za-z_][A-Za-z0-9_]*)\s*(?::\s*)?$',
            stripped,
        )
        if not match:
            self._unsupported(line, "show chart statement")
        heading = self._decode_quoted_string(match.group("title"), match.group("quote"), line)
        has_block = stripped.endswith(':')
        base_indent = self._indent(line.text)
        self._advance()
        config: Dict[str, Any] = {}
        if has_block:
            config = self._parse_component_block(base_indent)
        chart_type = config.pop("type", config.pop("chart_type", "bar"))
        x = config.pop("x", None)
        y = config.pop("y", None)
        color = config.pop("color", None)
        layout = self._build_layout_meta(config.pop("layout", None))
        insight = config.pop("insight", None)
        title = config.pop("title", None)
        legend = config.pop("legend", None)
        style_cfg = config.pop("style", None)
        style = style_cfg if isinstance(style_cfg, dict) else None
        encodings = {k: v for k, v in config.items() if k not in {"binding"}}
        return ShowChart(
            heading=heading,
            source_type=match.group("source_type"),
            source=match.group("source"),
            chart_type=chart_type,
            x=x,
            y=y,
            color=color,
            layout=layout,
            insight=insight,
            title=title,
            legend=legend if isinstance(legend, dict) else None,
            encodings=encodings,
            style=style if isinstance(style, dict) else None,
        )

    def _parse_if_block(self, line: _Line, indent: int) -> IfBlock:
        """Parse if/elif/else control flow block."""
        condition_text = line.text.strip()
        if not condition_text.endswith(':'):
            raise self._error("if statement must end with ':'", line)
        condition_src = condition_text[len('if') : -1].strip()
        condition = self._expression_helper.parse(condition_src, line_no=line.number, line=line.text)
        self._advance()
        body = self._parse_page_statements(indent)
        if not body:
            raise self._error("if block must contain at least one statement", line)
        elifs: List[ElifBlock] = []
        else_body: Optional[List[PageStatement]] = None
        while True:
            next_line = self._peek_line()
            if next_line is None:
                break
            stripped = next_line.text.strip()
            next_indent = self._indent(next_line.text)
            if not stripped:
                self._advance()
                continue
            if next_indent != indent:
                break
            if stripped.startswith('elif '):
                if not stripped.endswith(':'):
                    raise self._error("elif statement must end with ':'", next_line)
                expr_text = stripped[len('elif') : -1].strip()
                condition_expr = self._expression_helper.parse(expr_text, line_no=next_line.number, line=next_line.text)
                self._advance()
                elif_body = self._parse_page_statements(indent)
                if not elif_body:
                    raise self._error("elif block must contain at least one statement", next_line)
                elifs.append(ElifBlock(condition=condition_expr, body=elif_body))
                continue
            if stripped.startswith('else:'):
                self._advance()
                else_body = self._parse_page_statements(indent)
                if else_body is not None and len(else_body) == 0:
                    raise self._error("else block must contain at least one statement", next_line)
                break
            break
        return IfBlock(condition=condition, body=body, elifs=elifs, else_body=else_body)

    def _parse_for_loop(self, line: _Line, indent: int) -> ForLoop:
        """Parse for loop statement."""
        match = re.match(r'^\s*for\s+([A-Za-z_][A-Za-z0-9_]*)\s+in\s+(dataset|table|frame)\s+([A-Za-z_][A-Za-z0-9_]*)\s*:\s*$', line.text)
        if not match:
            raise self._error('Expected: for name in dataset foo:', line)
        loop_var = match.group(1)
        source_kind = match.group(2)
        source_name = match.group(3)
        self._advance()
        body = self._parse_page_statements(indent)
        if not body:
            raise self._error("for loop must contain at least one statement", line)
        return ForLoop(loop_var=loop_var, source_kind=source_kind, source_name=source_name, body=body)

    def _parse_while_loop(self, line: _Line, indent: int) -> WhileLoop:
        """Parse while loop statement."""
        stripped = line.text.strip()
        if not stripped.endswith(':'):
            raise self._error("while statement must end with ':'", line)
        condition_src = stripped[len('while') : -1].strip()
        condition = self._expression_helper.parse(condition_src, line_no=line.number, line=line.text)
        self._advance()
        body = self._parse_page_statements(indent)
        if not body:
            raise self._error("while loop must contain at least one statement", line)
        return WhileLoop(condition=condition, body=body)

    def _parse_break_statement(self, line: _Line) -> BreakStatement:
        """Parse break statement."""
        if line.text.strip() != 'break':
            raise self._error("Expected 'break' with no trailing content", line)
        self._advance()
        return BreakStatement()

    def _parse_continue_statement(self, line: _Line) -> ContinueStatement:
        """Parse continue statement."""
        if line.text.strip() != 'continue':
            raise self._error("Expected 'continue' with no trailing content", line)
        self._advance()
        return ContinueStatement()

    def _parse_variable_assignment(self, line: _Line) -> VariableAssignment:
        """Parse set statements inside page blocks: set name = expression"""
        match = re.match(r'^\s*set\s+([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+)$', line.text)
        if not match:
            raise self._error('Expected: set <name> = <expression>', line)
        name = match.group(1)
        expr_src = match.group(2).strip()
        value = self._expression_helper.parse(expr_src, line_no=line.number, line=line.text)
        self._advance()
        return VariableAssignment(name=name, value=value)

    def _parse_action_block(self, line: _Line, indent: int) -> Action:
        """Parse action block with optional trigger and operations."""
        stripped = line.text.strip()
        if not stripped.endswith(':'):
            raise self._error("action declaration must end with ':'", line)
        match = re.match(r'^action\s+(?P<quote>["\'])(?P<name>(?:[^\\]|\\.)*?)(?P=quote)\s*:\s*$', stripped)
        if not match:
            self._unsupported(line, "action statement")
        name = self._decode_quoted_string(match.group("name"), match.group("quote"), line)
        base_indent = self._indent(line.text)
        self._advance()
        trigger = ""
        operations: List[ActionOperation] = []
        while True:
            nxt = self._peek_line()
            if nxt is None:
                break
            nxt_stripped = nxt.text.strip()
            nxt_indent = self._indent(nxt.text)
            if self._should_skip_comment(nxt_stripped, nxt.number, nxt.text):
                self._advance()
                continue
            if nxt_indent <= base_indent:
                break
            if nxt_stripped.startswith('when '):
                if not nxt_stripped.endswith(':'):
                    raise self._error("when clause inside action must end with ':'", nxt)
                trigger = nxt_stripped[len('when') : -1].strip()
                self._advance()
                operations.extend(self._parse_action_operations(nxt_indent))
                continue
            operations.append(self._parse_action_operation_line(nxt))
            self._advance()
        if not operations:
            raise self._error("action block must contain at least one operation", line)
        return Action(name=name, trigger=trigger, operations=operations)

    def _parse_action_operations(self, parent_indent: int) -> List[ActionOperation]:
        """Parse nested action operations."""
        ops: List[ActionOperation] = []
        while True:
            nxt = self._peek_line()
            if nxt is None:
                break
            stripped = nxt.text.strip()
            indent = self._indent(nxt.text)
            if self._should_skip_comment(stripped, nxt.number, nxt.text):
                self._advance()
                continue
            if indent <= parent_indent:
                break
            ops.append(self._parse_action_operation_line(nxt))
            self._advance()
        return ops

    def _parse_action_operation_line(self, line: _Line) -> ActionOperation:
        """Parse a single action operation line."""
        stripped = line.text.strip()
        toast_match = re.match(r'^show\s+toast\s+(?P<quote>["\'])(?P<body>(?:[^\\]|\\.)*?)(?P=quote)\s*$', stripped)
        if toast_match:
            message = self._decode_quoted_string(toast_match.group("body"), toast_match.group("quote"), line)
            return ToastOperation(message=message)
        prompt_match = re.match(r'^run\s+prompt\s+(?P<quote>["\'])(?P<name>(?:[^\\]|\\.)*?)(?P=quote)\s*$', stripped)
        if prompt_match:
            prompt_name = self._decode_quoted_string(prompt_match.group("name"), prompt_match.group("quote"), line)
            return RunPromptOperation(prompt_name=prompt_name, arguments={})
        chain_match = re.match(r'^run\s+chain\s+(?P<quote>["\'])(?P<name>(?:[^\\]|\\.)*?)(?P=quote)\s*$', stripped)
        if chain_match:
            chain_name = self._decode_quoted_string(chain_match.group("name"), chain_match.group("quote"), line)
            return RunChainOperation(chain_name=chain_name, inputs={})
        goto_match = re.match(r'^go\s+to\s+page\s+(?P<quote>["\'])(?P<name>(?:[^\\]|\\.)*?)(?P=quote)\s*$', stripped)
        if goto_match:
            page_name = self._decode_quoted_string(goto_match.group("name"), goto_match.group("quote"), line)
            return GoToPageOperation(page_name=page_name)
        self._unsupported(line, "action operation")

    def _parse_show_form(self, line: _Line) -> ShowForm:
        """Parse show form statement with optional fields and on submit actions."""
        stripped = line.text.strip()
        match = re.match(
            r'^show\s+form\s+(?P<quote>["\'])(?P<title>(?:[^\\]|\\.)*?)(?P=quote)\s*(?::\s*)?$',
            stripped,
        )
        if not match:
            self._unsupported(line, "show form statement")
        title = self._decode_quoted_string(match.group("title"), match.group("quote"), line)
        has_block = stripped.endswith(':')
        base_indent = self._indent(line.text)
        self._advance()

        fields: List[FormField] = []
        on_submit_ops: List[ActionOperation] = []
        extra_config: Dict[str, Any] = {}

        if has_block:
            while True:
                nxt = self._peek_line()
                if nxt is None:
                    break
                nxt_stripped = nxt.text.strip()
                nxt_indent = self._indent(nxt.text)
                if self._should_skip_comment(nxt_stripped, nxt.number, nxt.text):
                    self._advance()
                    continue
                if nxt_indent <= base_indent:
                    break
                if nxt_stripped.startswith('fields:'):
                    fields_text = nxt_stripped.split(':', 1)[1].strip()
                    fields.extend(self._parse_form_fields(fields_text))
                    self._advance()
                    continue
                if nxt_stripped.startswith('on submit:'):
                    self._advance()
                    on_submit_ops.extend(self._parse_action_operations(nxt_indent))
                    continue
                if nxt_stripped.endswith(':'):
                    key = nxt_stripped[:-1].strip()
                    self._advance()
                    extra_config[key] = self._parse_component_block(nxt_indent)
                    continue
                kv_match = re.match(r'^([A-Za-z0-9_\-\s]+):\s*(.+)$', nxt_stripped)
                if kv_match:
                    key = kv_match.group(1).strip()
                    extra_config[key] = self._coerce_value(kv_match.group(2))
                    self._advance()
                    continue
                self._unsupported(nxt, "form configuration")

        return ShowForm(title=title, fields=fields, on_submit_ops=on_submit_ops, styles=extra_config.get("styles", {}))

    def _parse_form_fields(self, text: str) -> List[FormField]:
        """Parse comma-separated form fields into FormField objects."""
        names = [segment.strip().strip('"').strip("'") for segment in text.split(',') if segment.strip()]
        return [FormField(name=name) for name in names]

    def _parse_component_block(self, parent_indent: int) -> Dict[str, Any]:
        """Parse a nested component configuration block, supporting sub-blocks."""
        config: Dict[str, Any] = {}
        while True:
            line = self._peek_line()
            if line is None:
                break
            stripped = line.text.strip()
            indent = self._indent(line.text)
            if self._should_skip_comment(stripped, line.number, line.text):
                self._advance()
                continue
            if indent <= parent_indent:
                break
            if not stripped:
                self._advance()
                continue
            if stripped.endswith(':'):
                key = stripped[:-1].strip()
                self._advance()
                config[key] = self._parse_component_block(indent)
                continue
            match = re.match(r'^([A-Za-z0-9_\-\s]+):\s*(.+)$', stripped)
            if not match:
                raise self._error("Expected 'key: value' inside block", line)
            key = match.group(1).strip()
            value = match.group(2).strip()
            config[key] = self._coerce_value(value)
            self._advance()
        return config

    def _decode_quoted_string(self, body: str, quote: str, line: _Line) -> str:
        """Safely decode a quoted string body with escape handling."""
        try:
            return ast.literal_eval(f"{quote}{body}{quote}")
        except Exception:
            raise self._error("Invalid string literal", line)

    def _coerce_value(self, value: str) -> Any:
        """Coerce string values to bool/number when possible and strip quotes."""
        cleaned = value.strip()
        if (cleaned.startswith('"') and cleaned.endswith('"')) or (cleaned.startswith("'") and cleaned.endswith("'")):
            cleaned = cleaned[1:-1]
        return self._transform_config(cleaned)

    def _build_layout_meta(self, layout_value: Any) -> Optional[LayoutMeta]:
        """Construct LayoutMeta from nested layout config dict."""
        if not isinstance(layout_value, dict):
            return None
        return LayoutMeta(
            direction=layout_value.get("direction"),
            spacing=layout_value.get("spacing"),
            width=self._transform_config(layout_value.get("width")) if layout_value.get("width") is not None else None,
            height=self._transform_config(layout_value.get("height")) if layout_value.get("height") is not None else None,
            variant=layout_value.get("variant"),
            align=layout_value.get("align"),
            emphasis=layout_value.get("emphasis"),
            extras={k: v for k, v in layout_value.items() if k not in {"direction", "spacing", "width", "height", "variant", "align", "emphasis"}},
        )

    def _parse_kv_block(self, parent_indent: int) -> dict[str, str]:
        """Parse key-value block (used by theme and other declarations)."""
        from namel3ss.parser.base import ParserBase
        
        if self._in_ai_block:
            # Delegate to ParserBase implementation when AIParserMixin is driving parsing.
            return ParserBase._parse_kv_block(self, parent_indent)
        entries: dict[str, str] = {}
        while True:
            line = self._peek_line()
            if line is None:
                break
            stripped = line.text.strip()
            indent = self._indent(line.text)
            if self._should_skip_comment(stripped, line.number, line.text):
                self._advance()
                continue
            if indent <= parent_indent:
                break
            match = re.match(r'^([A-Za-z0-9_\-\s]+):\s*(.+)$', stripped)
            if not match:
                raise self._error("Expected 'key: value' inside block", line)
            key = match.group(1).strip()
            value = match.group(2).strip()
            entries[key] = value
            self._advance()
        return entries

    def _parse_log_statement(self, line: _Line) -> LogStatement:
        """Parse log statement: log [level] "message" """
        from namel3ss.ast.source_location import SourceLocation
        
        stripped = line.text.strip()
        
        # Pattern for log statement with optional level
        # Matches: log "message" OR log info "message" OR log error "message"
        match = re.match(
            r'^log(?:\s+(debug|info|warn|error))?\s+(?P<quote>["\'])(?P<body>(?:[^\\]|\\.)*?)(?P=quote)$',
            stripped,
        )
        
        if not match:
            raise self._error(
                'Expected: log "message" or log level "message" where level is debug|info|warn|error',
                line
            )
        
        level_str = match.group(1)
        message_text = self._decode_quoted_string(match.group("body"), match.group("quote"), line)
        
        # Default to info level if not specified
        if level_str is None:
            level = LogLevel.INFO
        else:
            try:
                level = LogLevel(level_str)
            except ValueError:
                raise self._error(
                    f'Invalid log level "{level_str}". Valid levels: debug, info, warn, error',
                    line
                )
        
        # For now, treat message as a literal string
        # TODO: Support interpolated expressions like "Score: {{score}}"
        message = Literal(message_text)
        
        # Create source location for error reporting
        source_location = SourceLocation(
            file=getattr(self, '_path', None) or getattr(self, 'source_path', '<unknown>'),
            line=line.number,
            column=0
        )
        
        self._advance()
        return LogStatement(
            level=level,
            message=message,
            source_location=source_location
        )


__all__ = ['PagesParserMixin']
