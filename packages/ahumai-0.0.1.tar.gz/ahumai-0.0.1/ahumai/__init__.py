print("happy holidays")
