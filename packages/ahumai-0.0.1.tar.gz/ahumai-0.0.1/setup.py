from setuptools import setup, find_packages

setup(
    name="ahumai",
    version="0.0.1",
    description="A simple package that prints happy holidays",
    author="Your Name",
    packages=find_packages(),
    python_requires=">=3.6",
)
