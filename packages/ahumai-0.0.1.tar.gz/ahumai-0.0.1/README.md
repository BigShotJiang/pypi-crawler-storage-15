# ahumai

A simple package that prints "happy holidays" when imported.

## Installation

```bash
pip install ahumai
```

## Usage

```python
import ahumai
```
