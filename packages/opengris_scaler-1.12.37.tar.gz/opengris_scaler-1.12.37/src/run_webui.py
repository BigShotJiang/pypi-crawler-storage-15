from scaler.entry_points.webui import main

if __name__ in {"__main__", "__mp_main__"}:
    main()
