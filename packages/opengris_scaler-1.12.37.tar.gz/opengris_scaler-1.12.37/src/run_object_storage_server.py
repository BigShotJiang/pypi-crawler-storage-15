from scaler.entry_points.object_storage_server import main

if __name__ == "__main__":
    main()
