API reference documentation
===========================

.. toctree::
   :maxdepth: 1

   py_avro_schema
