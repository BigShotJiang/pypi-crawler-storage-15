py\_avro\_schema
================

.. automodule:: py_avro_schema
   :members:
   :show-inheritance:
