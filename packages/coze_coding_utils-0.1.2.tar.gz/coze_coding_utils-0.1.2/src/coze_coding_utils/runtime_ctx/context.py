import os
import uuid
from dataclasses import dataclass
from typing import Optional, Dict


@dataclass
class Context:
    run_id: str
    space_id: str
    project_id: str
    logid: str = ""
    method: str = ""
    x_tt_env: Optional[str] = None
    x_use_ppe: Optional[str] = None
    x_tt_env_fe: Optional[str] = None
    benefit_biz_scene: Optional[str] = None


def new_context(method: str, headers: Optional[Dict[str, str]] = None) -> Context:
    ctx = Context(
        run_id=str(uuid.uuid4()),
        space_id=os.getenv("COZE_PROJECT_SPACE_ID", ""),
        project_id=os.getenv("COZE_PROJECT_ID", ""),
        method=method,
    )
    if headers:
        ctx.logid = headers.get("x-tt-logid", "")
        ctx.x_tt_env = headers.get("x-tt-env")
        ctx.x_use_ppe = headers.get("x-use-ppe")
        ctx.x_tt_env_fe = headers.get("x-tt-env-fe")
        ctx.benefit_biz_scene = headers.get("benefit-biz-scene")
    return ctx

