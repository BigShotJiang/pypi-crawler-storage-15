"""{{ project_display_name }} - {{ description }}"""

__version__ = "0.1.0"