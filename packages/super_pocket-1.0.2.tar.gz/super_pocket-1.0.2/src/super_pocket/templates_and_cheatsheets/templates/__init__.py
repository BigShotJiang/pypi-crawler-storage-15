"""
Agent configuration templates.
"""
