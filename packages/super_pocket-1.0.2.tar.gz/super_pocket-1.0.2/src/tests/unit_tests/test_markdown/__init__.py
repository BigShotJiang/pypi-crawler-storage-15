"""
Tests for markdown module.
"""
