"""Tests for project analyzers."""
