"""
Tests for templates and cheatsheets module.
"""
