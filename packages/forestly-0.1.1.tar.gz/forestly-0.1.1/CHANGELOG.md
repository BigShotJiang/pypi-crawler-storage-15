# Changelog

## 0.1.1

### Bug Fixes

- reduce package size by removing docs folder from source distribution.

## 0.1.0 

### Added
- Initial release