"""
NC1709 CLI - Your AI coding partner that brings your code to life
Version: 1.10.2
Author: Lafzusa Corp
License: Proprietary
"""

__version__ = "1.11.0"
__author__ = "Lafzusa Corp"

from .cli import main

__all__ = ["main"]
