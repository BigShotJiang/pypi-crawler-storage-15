#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
ezgo - 宇树Go2机器狗Python控制库

这是一个用于控制宇树Go2机器狗的Python库，提供了简单易用的API接口。
支持运动控制、视频流获取、UI界面等功能。
"""

__version__ = "0.0.6"
__author__ = "ezgo"
__email__ = ""
__license__ = "MIT"

# 导入主要类
try:
    from .go2 import Go2
    from .camera import Camera
    from .ui import APP
    from .go2_camera import Go2Camera
    from .go2_vui import Go2VUI
except ImportError as e:
    print(f"警告: 无法导入部分模块: {e}")
    print("请确保已安装所有依赖包")
    Go2 = None
    Camera = None
    APP = None
    Go2Camera = None
    Go2VUI = None

# 定义公开的API
__all__ = [
    "Go2",
    "Camera", 
    "APP",
    "Go2Camera",
    "Go2VUI",
    "__version__"
]

# 依赖检查和提示
def _check_dependencies():
    """检查关键依赖是否安装，并给出安装提示"""
    missing_deps = []
    
    try:
        import cv2
    except ImportError:
        missing_deps.append("opencv-python")
    
    try:
        import numpy
    except ImportError:
        missing_deps.append("numpy")
    
    try:
        from PIL import Image
    except ImportError:
        missing_deps.append("Pillow")
    
    try:
        import netifaces
    except ImportError:
        missing_deps.append("netifaces")
    
    try:
        import unitree_sdk2py
    except ImportError:
        missing_deps.append("unitree-sdk2py")
    
    if missing_deps:
        print("=" * 60)
        print("警告: ezgo 缺少以下依赖包:")
        for dep in missing_deps:
            print(f"  - {dep}")
        print()
        print("请安装缺少的依赖包:")
        print("  pip install opencv-python numpy Pillow netifaces")
        print("  # unitree-sdk2py 需要从官方源安装")
        print("=" * 60)
        return False
    
    return True

# 在导入时进行依赖检查
_check_dependencies()