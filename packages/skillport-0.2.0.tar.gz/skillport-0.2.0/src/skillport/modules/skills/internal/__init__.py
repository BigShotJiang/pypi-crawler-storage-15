"""Internal implementations for the skills module."""

from .github import (
    GitHubFetchResult,
    ParsedGitHubURL,
    fetch_github_source,
    fetch_github_source_with_info,
    get_latest_commit_sha,
    get_remote_tree_hash,
    parse_github_url,
    rename_single_skill_dir,
)
from .manager import (
    SkillInfo,
    add_builtin,
    add_local,
    detect_skills,
    remove_skill,
    resolve_source,
)
from .origin import (
    compute_content_hash,
    compute_content_hash_with_reason,
    get_all_origins,
    get_origin,
    migrate_origin_v2,
    prune_orphan_origins,
    record_origin,
    update_origin,
)
from .origin import (
    remove_origin as remove_origin_record,
)
from .validation import validate_skill_record

__all__ = [
    "resolve_source",
    "detect_skills",
    "add_builtin",
    "add_local",
    "remove_skill",
    "SkillInfo",
    "validate_skill_record",
    "parse_github_url",
    "fetch_github_source",
    "fetch_github_source_with_info",
    "get_latest_commit_sha",
    "get_remote_tree_hash",
    "rename_single_skill_dir",
    "ParsedGitHubURL",
    "GitHubFetchResult",
    "record_origin",
    "remove_origin_record",
    "get_origin",
    "get_all_origins",
    "compute_content_hash",
    "compute_content_hash_with_reason",
    "update_origin",
    "migrate_origin_v2",
    "prune_orphan_origins",
]
