import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

extensions = ['sphinx_click']

autodoc_mock_imports = ["fake_dependency"]
