"""
toonbuilder.

Convert JSON and XML files to TOON, a schema-aware data formatting for LLM prompts.
"""

__version__ = "0.1.0"
__author__ = 'Polybit'
__credits__ = 'Johann Schopplich'