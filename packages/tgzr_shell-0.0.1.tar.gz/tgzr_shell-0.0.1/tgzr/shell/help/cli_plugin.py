from pathlib import Path

import click
import rich
import rich.table

from tgzr.cli.session import Session


def install_plugin(group: click.Group):
    group.add_command(help)


@click.group(help="Documentations and tooltips.")
def help():
    pass


@help.command()
@click.pass_context
def env(ctx):
    session: Session = ctx.obj.session

    config_env_vars = session.get_config_env_vars()

    for name, env_vars in config_env_vars:
        table = rich.table.Table("Name", "Description", title=name)

        for name, description in env_vars:
            table.add_row(name, description or "")

        rich.print("\n", table)
