"""
RAFAEL Framework Tests
"""
