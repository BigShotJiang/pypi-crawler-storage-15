def parsefy():
    print("Parsefy SDK")