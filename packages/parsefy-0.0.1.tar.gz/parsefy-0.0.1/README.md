# Parsefy SDK for Python
