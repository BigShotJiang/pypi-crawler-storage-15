.. _multitenancy:

This content has been moved to :ref:`admin-networking`.
