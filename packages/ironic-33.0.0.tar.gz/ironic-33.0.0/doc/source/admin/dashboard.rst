Dashboard Integration
---------------------

A plugin for the OpenStack Dashboard (horizon) service is under development.
Documentation for that can be found within the ironic-ui project.

* :ironic-ui-doc:`Dashboard (horizon) plugin <>`

