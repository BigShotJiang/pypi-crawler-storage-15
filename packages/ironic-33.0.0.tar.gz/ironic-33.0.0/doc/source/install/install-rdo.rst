=============================================================
Install and configure for Red Hat Enterprise Linux and CentOS
=============================================================

The contents has been migrated to the common location - see :doc:`install`.
