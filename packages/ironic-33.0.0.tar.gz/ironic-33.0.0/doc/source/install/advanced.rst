.. _advanced:

Advanced features
=================

.. include:: include/root-device-hints.inc

.. include:: include/kernel-boot-parameters.inc

.. include:: include/boot-mode.inc

.. include:: include/disk-label.inc

.. include:: include/notifications.inc

.. include:: include/console.inc
