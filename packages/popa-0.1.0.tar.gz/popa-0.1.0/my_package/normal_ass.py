def normal_ass():
    print("(_!_)")