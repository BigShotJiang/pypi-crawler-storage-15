def bitch_ass():
    print("_B_")