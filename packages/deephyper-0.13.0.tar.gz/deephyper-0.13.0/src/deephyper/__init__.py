"""DeepHyper Python package."""

from deephyper.__version__ import __version__, __version_suffix__  # noqa: F401

name = "deephyper"
version = __version__
