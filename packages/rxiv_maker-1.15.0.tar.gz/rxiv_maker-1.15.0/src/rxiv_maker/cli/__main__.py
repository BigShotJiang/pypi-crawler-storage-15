"""Main entry point for rxiv-maker CLI when called as a module."""

from .main import main

if __name__ == "__main__":
    main()
