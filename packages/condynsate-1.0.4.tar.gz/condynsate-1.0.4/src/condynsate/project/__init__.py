# -*- coding: utf-8 -*-
"""
© Copyright, 2025 G. Schaer.
SPDX-License-Identifier: GPL-3.0-only
"""

from condynsate.project.project import Project

__all__ = ["Project"]
