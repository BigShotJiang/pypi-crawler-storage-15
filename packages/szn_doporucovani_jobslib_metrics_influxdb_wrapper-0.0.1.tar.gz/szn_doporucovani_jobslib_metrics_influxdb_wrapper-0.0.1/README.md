# szn-doporucovani-jobslib-metrics-influxdb-wrapper

This is a security placeholder package created to prevent dependency confusion attacks.