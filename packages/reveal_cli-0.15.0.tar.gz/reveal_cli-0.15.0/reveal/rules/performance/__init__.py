"""performance rules."""
