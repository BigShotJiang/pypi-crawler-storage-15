To pull historical bank statements:

1. Go to *Invoicing > Configuration > Bank Accounts*
2. Select specific bank accounts
3. Configure username, password and host for plaid
4. Launch *Actions > Sync with plaid.com*
5. After launch *Actions > Online Bank Statements Pull Wizard*
6. Configure date interval and click *Pull*

If historical data is not needed, then just simply wait for the scheduled
activity "Pull Online Bank Statements" to be executed for getting new
transactions.
