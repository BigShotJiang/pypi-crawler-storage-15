from .data_loader import load_data, load_info
from .statkit.ttest import my_ttest

__all__ = ['load_data', 'load_info', 'my_ttest']