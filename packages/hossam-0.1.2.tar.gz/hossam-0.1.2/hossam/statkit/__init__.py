from .ttest import my_ttest

__all__ = ['my_ttest']