Author:
    
    Daniel Christophis - <code at devmind.org>

Copyrights:

    Copyright (c) 2025 Daniel Christophis

    Descriptions were adapted from
    - TLP (https://github.com/linrunner/TLP)
         Copyright (c) 2024 by Thomas Koch

License:

    This software is licensed under the GPL v2 or later,
    see '/usr/share/common-licenses/GPL-2'

    TLPUI logo icon is licensed under
    https://creativecommons.org/licenses/by-sa/4.0/
