from talisman_api import version
from ._abstract import TalismanDomainAPIImpl


@version('0.17.3')
class _ImplV173(TalismanDomainAPIImpl):
    pass
