from tdm.datamodel.values import StringValue

from tp_interfaces.domain.model.types import AtomValueType

STR_VALUE = AtomValueType("str", StringValue, id='str')
