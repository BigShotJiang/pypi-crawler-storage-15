.. _example_gallery:

Example Gallery
---------------

The examples listed here are intended to familiarize the reader with TraP,
and to serve as inspiration regarding the types of problems that can be solved using TraP.
