from enum import Enum


class KonicAlgorithmType(str, Enum):
    PPO = "PPO"
