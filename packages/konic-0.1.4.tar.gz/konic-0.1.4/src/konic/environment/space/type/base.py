type KonicDiscrete = int

type KonicMultiDiscrete = list[int]

type KonicBound = tuple[tuple[int, ...], int | float, int | float]
