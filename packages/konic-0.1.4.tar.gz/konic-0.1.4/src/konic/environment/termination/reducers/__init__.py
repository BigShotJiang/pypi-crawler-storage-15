from konic.environment.termination.reducers.base import BaseKonicTerminationReducer
from konic.environment.termination.reducers.strategy import OrReducerStrategy

__all__ = ["BaseKonicTerminationReducer", "OrReducerStrategy"]
