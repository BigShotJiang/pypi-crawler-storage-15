from konic.cli.client.api_client import KonicAPIClient

client = KonicAPIClient()

__all__: list[str] = ["KonicAPIClient", "client"]
