def hello():
    return "Hello from pip_try package!"
