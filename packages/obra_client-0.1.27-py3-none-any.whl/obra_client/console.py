"""Safe console wrapper with Unicode fallback for Windows compatibility.

This module provides a SafeConsole class that wraps Rich's Console
and automatically falls back to ASCII characters when the terminal
doesn't support Unicode (e.g., Windows cmd.exe or PowerShell ISE).

It also provides a decorator for CLI commands to handle encoding errors
gracefully with user-friendly messages.
"""

import functools
import os
import sys
from typing import Any, Callable, TypeVar

from rich.console import Console

# Type variable for decorator
F = TypeVar("F", bound=Callable[..., Any])


# ASCII fallbacks for common symbols used in the CLI
SYMBOL_MAP = {
    # Status indicators
    "\u2713": "[OK]",      # ✓
    "\u2714": "[OK]",      # ✔
    "\u2717": "[X]",       # ✗
    "\u2718": "[X]",       # ✘
    "\u274c": "[ERROR]",   # ❌
    "\u26a0\ufe0f": "[WARN]",  # ⚠️
    "\u26a0": "[WARN]",    # ⚠
    # Action indicators
    "\U0001f680": ">>",    # 🚀
    "\U0001f4e1": "[API]", # 📡
    "\U0001f4e4": "[OUT]", # 📤
    "\u2728": "*",         # ✨
    "\U0001f4be": "[SAVE]", # 💾
    "\U0001f3af": "[TARGET]", # 🎯
    "\U0001f916": "[BOT]",  # 🤖
    "\U0001f504": "[SYNC]", # 🔄
    "\U0001f3e5": "[HEALTH]", # 🏥
    # Box drawing characters
    "\u2550": "=",         # ═
    "\u2501": "-",         # ━
    "\u2500": "-",         # ─
    "\u2502": "|",         # │
    "\u250c": "+",         # ┌
    "\u2510": "+",         # ┐
    "\u2514": "+",         # └
    "\u2518": "+",         # ┘
}


def is_unicode_safe() -> bool:
    """Check if the terminal supports Unicode output.

    Returns:
        True if Unicode is safe to use, False if ASCII fallback needed.
    """
    if sys.platform == "win32":
        # Windows Terminal supports Unicode
        if "WT_SESSION" in os.environ:
            return True
        # VSCode integrated terminal supports Unicode
        if os.environ.get("TERM_PROGRAM") == "vscode":
            return True
        # Check stdout encoding
        encoding = getattr(sys.stdout, "encoding", "") or ""
        if encoding.lower().replace("-", "") in ("utf8", "utf16"):
            return True
        # Check PYTHONIOENCODING environment variable
        if os.environ.get("PYTHONIOENCODING", "").lower().startswith("utf"):
            return True
        # Default to ASCII on Windows for safety
        return False
    # Unix-like systems generally support Unicode
    return True


def ascii_fallback(text: str) -> str:
    """Convert Unicode symbols to ASCII equivalents.

    Args:
        text: String potentially containing Unicode symbols.

    Returns:
        String with Unicode symbols replaced by ASCII equivalents.
    """
    result = text
    for unicode_char, ascii_char in SYMBOL_MAP.items():
        result = result.replace(unicode_char, ascii_char)
    return result


class SafeConsole(Console):
    """Console that falls back to ASCII on incompatible terminals.

    This wrapper detects terminal capabilities and automatically
    converts Unicode symbols to ASCII equivalents when needed.

    Example:
        >>> console = SafeConsole()
        >>> console.print("[green]✓[/green] Done")
        # On Windows cmd.exe: "[green][OK][/green] Done"
        # On Windows Terminal: "[green]✓[/green] Done"
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """Initialize SafeConsole with Unicode detection."""
        super().__init__(*args, **kwargs)
        self._unicode_safe = is_unicode_safe()

    def print(self, *args: Any, **kwargs: Any) -> None:
        """Print with automatic Unicode fallback.

        If the terminal doesn't support Unicode, symbols are
        automatically converted to ASCII equivalents.
        """
        if not self._unicode_safe:
            # Convert all arguments to ASCII-safe strings
            safe_args = tuple(
                ascii_fallback(str(arg)) if isinstance(arg, str) else arg
                for arg in args
            )
            args = safe_args

        try:
            super().print(*args, **kwargs)
        except UnicodeEncodeError:
            # Fallback if detection was wrong - retry with ASCII
            self._unicode_safe = False
            safe_args = tuple(
                ascii_fallback(str(arg)) if isinstance(arg, str) else arg
                for arg in args
            )
            try:
                super().print(*safe_args, **kwargs)
            except UnicodeEncodeError:
                # Last resort: strip all non-ASCII
                stripped_args = tuple(
                    arg.encode("ascii", errors="replace").decode("ascii")
                    if isinstance(arg, str) else arg
                    for arg in safe_args
                )
                super().print(*stripped_args, **kwargs)


def handle_encoding_errors(func: F) -> F:
    """Decorator to catch encoding errors with user-friendly messages.

    Use this decorator on CLI commands to provide helpful error messages
    when Unicode encoding fails, instead of showing raw stack traces.

    Example:
        @app.command()
        @handle_encoding_errors
        def my_command():
            console.print("🚀 Starting...")
    """

    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        try:
            return func(*args, **kwargs)
        except UnicodeEncodeError as e:
            # Use raw print to avoid any Rich formatting issues
            print("\n[ERROR] Terminal encoding issue detected.")
            print(f"        Character: {e.object[e.start:e.end]!r}")
            print("\nSolutions:")
            print("  1. Use Windows Terminal instead of cmd.exe or PowerShell ISE")
            print("  2. Set environment variable: PYTHONIOENCODING=utf-8")
            print("  3. Run: chcp 65001 (in cmd.exe before running obra-client)")
            print("\nFor more info: https://obra.dev/docs/troubleshooting/windows-unicode")

            # Import typer here to avoid circular imports
            import typer

            raise typer.Exit(1)

    return wrapper  # type: ignore[return-value]


# Module-level console instance for import
console = SafeConsole()
