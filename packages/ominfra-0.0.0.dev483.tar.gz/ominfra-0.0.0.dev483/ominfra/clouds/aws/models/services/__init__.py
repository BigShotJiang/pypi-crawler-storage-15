from omlish import dataclasses as _dc  # noqa


_dc.init_package(
    globals(),
    codegen=True,
)
