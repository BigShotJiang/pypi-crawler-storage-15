# django_core_micha/auth/serializers.py
from rest_framework import serializers
from .recovery import RecoveryRequest

class RecoveryRequestSerializer(serializers.ModelSerializer):
    user_email = serializers.EmailField(source="user.email", read_only=True)
    support_email = serializers.EmailField(
        source="support_contact.email",
        read_only=True,
        allow_null=True,
    )

    class Meta:
        model = RecoveryRequest
        fields = (
            "id",
            "user",
            "user_email",
            "support_contact",
            "support_email",
            "status",
            "created_at",
            "resolved_at",
            "user_message",
            "internal_note",
        )
        read_only_fields = (
            "user",
            "status",
            "created_at",
            "resolved_at",
        )
