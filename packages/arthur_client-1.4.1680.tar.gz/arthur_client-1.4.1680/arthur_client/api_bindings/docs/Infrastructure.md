# Infrastructure


## Enum

* `AWS` (value: `'AWS'`)

* `AZURE` (value: `'Azure'`)

* `GCP` (value: `'GCP'`)

* `DOCKER` (value: `'Docker'`)

* `KUBERNETES` (value: `'Kubernetes'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


