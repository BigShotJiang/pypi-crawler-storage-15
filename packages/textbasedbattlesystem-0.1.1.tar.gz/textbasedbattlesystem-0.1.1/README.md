# Text Based Battle System

    Yazı tabanlı savaş sistemi. Kullanıcı kendi canavarını, eylemlerini ve savaş tarzını ayarlayıp kendi savaşlarını oluşturabilir.

## Kurulum

    pip install textbasedbattle

## Kullanım

```python

import textbasedbattle

textbasedbattle.savasi_baslat()

```
## Komutlar için

```python

import textbasedbattle

textbasedbattle.ne_yapcam()

```

