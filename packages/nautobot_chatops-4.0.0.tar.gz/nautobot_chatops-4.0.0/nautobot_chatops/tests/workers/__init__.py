"""Dummy command workers module for various test cases."""
