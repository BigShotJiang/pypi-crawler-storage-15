"""Base module for nautobot_chatops.integrations.ansible."""
