"""API Views module for the nautobot_chatops Nautobot App.

The views implemented in this module act as endpoints for various chat platforms
to send requests and notifications to.
"""
