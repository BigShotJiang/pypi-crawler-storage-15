from sklearn.tree import DecisionTreeClassifier

class SimpleDecisionTree:
    """
    Minimal sklearn DecisionTree wrapper for AutoImblearn validation.
    Requires only: fit(X, y) and predict(X).
    """

    def __init__(self, max_depth=3):
        self.model = DecisionTreeClassifier(max_depth=max_depth)

    def fit(self, X, y):
        """Fit the model to numeric X/y arrays."""
        self.model.fit(X, y)

    def predict(self, X):
        """Return predicted labels."""
        return self.model.predict(X)