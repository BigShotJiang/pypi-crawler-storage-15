from liblaf.peach import tree
from liblaf.peach.optim.abc import Stats


@tree.define
class ScipyStats(Stats):
    pass
