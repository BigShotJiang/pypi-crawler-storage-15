""" uamt """
__version__="1.0.1"
from .UAMT import *
