Starting from Odoo 18.0, `product_expiry` module is blocking the reservation
of expired lots.

However we could have use cases where we want to move such expired lots in another location.
