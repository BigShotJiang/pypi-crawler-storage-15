import runpy


runpy.run_module("ios_backup", run_name="__main__")
