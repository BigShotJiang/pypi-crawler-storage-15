"""Common definitions for the package"""

VALUE_COLUMN = "value"
