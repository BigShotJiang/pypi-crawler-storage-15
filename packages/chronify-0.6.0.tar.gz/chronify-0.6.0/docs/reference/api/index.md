```{eval-rst}
.. _api-page:
```
# API

```{eval-rst}
.. toctree::
    :maxdepth: 2
    :caption: Contents:

    store
```
