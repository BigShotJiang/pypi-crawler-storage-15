# stub to support existing import paths
from .generated.secrets import *  # NOQA
