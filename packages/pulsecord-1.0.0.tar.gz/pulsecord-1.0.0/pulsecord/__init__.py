from .core import initializationSelf

__all__ = ["initializationSelf"]
