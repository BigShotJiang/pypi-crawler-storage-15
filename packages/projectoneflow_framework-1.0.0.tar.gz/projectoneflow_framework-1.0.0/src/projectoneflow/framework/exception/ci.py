class GitLabRequestException(Exception):
    """This Exception is raised where api request is not throwing the exception"""
