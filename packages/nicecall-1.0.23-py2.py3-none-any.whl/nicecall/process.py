import asyncio
import collections.abc
import io
import logging
import queue
import subprocess
import threading
import time
import typing


type Action = collections.abc.Callable[[str | bytes], None]
type Predicate = collections.abc.Callable[[str | bytes], bool]
type ProcessQueue = asyncio.Queue[Exception | None]


class CompletedEvent():
    pass


class Process():
    """
    Provides an easy way to call processes and handle their output.
    """
    def __init__(
            self,
            on_stdout: list[Action] | None = None,
            on_stderr: list[Action] | None = None,
            filters: list[Predicate] | None = None,
            raise_if_error: bool = False,
            binary_stdout: bool = False):
        """
        :param on_stdout: An action to perform for every line of stdout.
        :param on_stderr: An action to perform for every line of stderr.
        :param filters: The filters to apply to the lines in order to determine
            if `on_stdout` and `on_stderr` should be called. The filters are
            cumulative.
        :param raise_if_error: If true, `subprocess.CalledProcessError` is
            thrown if the process exits with a non-zero exit code. If false,
            no exception is thrown, and it belongs to the caller to check the
            exit code.
        :param binary_stdout: True if `stdout` could contain binary data and
            should not be processed as a series of UTF-8 lines.
        """
        self._on_stdout = on_stdout or []
        self._on_stderr = on_stderr or []
        self._filters = filters or []
        self._raise_if_error = raise_if_error
        self._binary_stdout = binary_stdout

    def _clone(self) -> typing.Self:
        return self.__class__(
            self._on_stdout[:],
            self._on_stderr[:],
            self._filters[:],
            self._raise_if_error,
            self._binary_stdout)

    def execute(
            self,
            args: list[str],
            log_error: bool = True) -> int | typing.Any:
        """
        Runs a process and returns its exit code when it finishes (or throws an
        exception if it exits with a non-zero exit code and if `raise_if_error`
        was set).
        """
        Process._check_args(args)

        log_command = self._generate_log_command(args)
        logger = logging.getLogger(__name__)
        if not logger.handlers:
            logger.addHandler(logging.NullHandler())
        logger.info(f"Called “{log_command}”.")

        with subprocess.Popen(
            args,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        ) as process:
            self._process_std(process)
            process.wait()

            exitcode = process.returncode
            if exitcode and log_error:
                logger.warning(
                    f"“{log_command}” failed with exit code {exitcode}.")

            if exitcode != 0 and self._raise_if_error:
                raise subprocess.CalledProcessError(exitcode, args[0])

            return exitcode

    def read_stdout(self, args: list[str]) -> list[str]:
        """
        Runs a process, raising an exception if it fails, and capturing its
        stdout to a list of lines.

        :param args: The process itself, and the arguments to pass to it.

        :return: The lines that correspond to the stdout, without the `\n` at
        the end.
        """
        stdout = []
        self.on_stdout(stdout.append).raise_if_error().execute(args)
        return stdout

    def stream_stdout(
            self,
            args: list[str],
            binary: bool = False) -> typing.Generator[str | bytes, None, None]:
        """
        Runs a process, raising an exception if it fails, and returning its
        stdout in a form of a generator.

        :param args: The process itself, and the arguments to pass to it.

        :param binary: True if the stream could contain binary data, as opposed
        to lines.

        :return: For a text stream, zero or more lines coming from stdout,
        exactly as they are sent by the process, i.e. if they end by a new line
        character, it will not be removed. For a binary stream, zero or more
        blocks of bytes.
        """
        self._binary_stdout = binary
        stdout_queue: queue.Queue[
            str | bytes | Exception | CompletedEvent] = queue.Queue()

        def run():
            global child_exception
            try:
                exitcode = self.on_stdout(stdout_queue.put).execute(args)
                stdout_queue.put(
                    CompletedEvent()
                    if exitcode == 0
                    else subprocess.CalledProcessError(exitcode, args[0])
                )
            except Exception as ex:
                stdout_queue.put(ex)

        thread = threading.Thread(target=run)
        thread.start()

        while True:
            line = stdout_queue.get()

            if isinstance(line, CompletedEvent):
                break

            if isinstance(line, Exception):
                raise line

            yield line

        thread.join()

    def keep(self, predicate: Predicate) -> typing.Self:
        """
        Ensures only the lines of stdout and stderr that match a predicate are
        kept for being processed by `on_stdout` and `on_stderr`.

        Note that conditions specified with `keep` and `ignore` are cumulative.

        :param predicate: The action that takes a line as a parameter and
            returns true if the line should be kept, or false otherwise.
        :return: A new instance of process with an additional filter.
        """
        result = self._clone()
        result._filters.append(predicate)
        return result

    def ignore(self, predicate: Predicate) -> typing.Self:
        """
        Ensures the lines of stdout and stderr that match a predicate are
        discarded and will not be processed by `on_stdout` and `on_stderr`.

        Note that conditions specified with `keep` and `ignore` are cumulative.

        :param predicate: The action that takes a line as a parameter and
            returns true if the line should be kept, or false otherwise.
        :return: A new instance of process with an additional filter.
        """
        return self.keep(self._invert(predicate))

    def _generate_log_command(self, args: list[str]) -> str:
        """
        Generates a string representation of a command for logging purposes
        only. This string is not used when calling the actual process.
        """
        def process_item(arg):
            return (
                f'"{arg.replace('"', '\\"')}"'
                if " " in arg or '"' in arg
                else arg)

        return " ".join(map(process_item, args))

    def _process_std(
            self,
            process: subprocess.Popen[str] | subprocess.Popen[bytes]) -> None:
        """
        Processes stdout and stderr of the process (if `on_stdout` and
        `on_stderr` were set), and waits until the process terminates.
        """
        size = (1 if self._on_stdout else 0) + (1 if self._on_stderr else 0)
        if size == 0:
            return

        # The queue is necessary to ensure stdout and stderr streams are
        # processed completely before waiting for process termination. If this
        # queue is not used, what could happen is that if Python takes too much
        # time processing lines from stdout or stderr within the threads, the
        # process will end, eventually leading to Python program stopping
        # itself and terminating the threads which were still processing
        # output.
        queue: ProcessQueue = asyncio.Queue(maxsize=size)

        if self._on_stdout:
            assert process.stdout is not None
            self._read_stream_async(
                process.stdout, self._on_stdout, queue, self._binary_stdout)

        if self._on_stderr:
            assert process.stderr is not None
            self._read_stream_async(
                process.stderr, self._on_stderr, queue, False)

        while not queue.full():
            # The queue capacity is set to the number of streams being listened
            # to, that is, from one to two (if zero, the method would exit).
            # Once the full capacity is reached, this means all streams
            # terminated.
            time.sleep(0.005)

        # The queue now contains for every thread either `None` if the thread
        # terminated successfully, or the exception if the one was raised.
        # Let's walk through the queue and raise the swallowed exceptions on
        # the main thread.
        while not queue.empty():
            result = queue.get_nowait()
            if result is not None:
                raise result

    def _invert(self, predicate: Predicate) -> Predicate:
        def result(line: str | bytes) -> bool:
            return not predicate(line)

        return result

    def on_stdout(self, action: Action) -> typing.Self:
        """
        Adds an action to perform for every line of stdout.

        :param action: The action that takes a line as a parameter.
        :return: A new instance of process with an additional action.
        """
        result = self._clone()
        result._on_stdout.append(action)
        return result

    def on_stderr(self, action: Action) -> typing.Self:
        """
        Adds an action to perform for every line of stderr.

        :param action: The action that takes a line as a parameter.
        :return: A new instance of process with an additional action.
        """
        result = self._clone()
        result._on_stderr.append(action)
        return result

    def raise_if_error(self) -> typing.Self:
        """
        Ensures `subprocess.CalledProcessError` is thrown if the process exits
        with a non-zero exit code.
        """
        result = self._clone()
        result._raise_if_error = True
        return result

    def _read_stream_async(
            self,
            stream: typing.IO[str] | typing.IO[bytes],
            actions: list[Action],
            queue: ProcessQueue,
            binary: bool) -> None:
        task = threading.Thread(
            target=self._read_stream, args=(stream, actions, queue, binary))
        task.start()

    def _read_stream(
            self,
            stream: io.TextIOWrapper,
            actions: list[Action],
            queue: ProcessQueue,
            binary: bool) -> None:
        try:
            while True:
                chunk = stream.read(1024) if binary else stream.readline()
                if not chunk:
                    break

                if not binary:
                    assert isinstance(chunk, bytes)
                    chunk = chunk.decode('utf8').strip('\n')

                self._process_part(chunk, actions)

            queue.put_nowait(None)
        except Exception as e:
            queue.put_nowait(e)

    def _process_part(self, part: str | bytes, actions: list[Action]) -> None:
        if all((prefilter(part) for prefilter in self._filters)):
            for action in actions:
                action(part)

    @staticmethod
    def _check_args(args: list[str]) -> None:
        for index, arg in enumerate(args):
            if not isinstance(arg, str):
                raise TypeError(
                    f"Argument {index} (value {arg}) should be a string, "
                    f"not {type(arg)}.")
