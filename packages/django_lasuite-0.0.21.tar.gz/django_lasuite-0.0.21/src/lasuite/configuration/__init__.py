"""Custom values for django-configurations."""
