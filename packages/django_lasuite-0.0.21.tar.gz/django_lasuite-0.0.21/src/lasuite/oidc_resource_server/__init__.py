"""Backend resource server module."""
