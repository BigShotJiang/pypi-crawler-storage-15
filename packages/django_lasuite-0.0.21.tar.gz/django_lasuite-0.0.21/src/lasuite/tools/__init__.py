"""Common tools for the LaSuite package or the projects."""
