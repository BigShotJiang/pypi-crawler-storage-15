#just so that we can have full access to the directory
from ..session.assistant_session import AssistantSession