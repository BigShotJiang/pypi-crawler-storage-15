

class NuCoreError(Exception):
    """Base exception for nucore backend errors."""
    pass