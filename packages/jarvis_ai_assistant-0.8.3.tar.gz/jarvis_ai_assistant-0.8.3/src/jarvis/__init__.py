# -*- coding: utf-8 -*-
"""Jarvis AI Assistant"""

__version__ = "0.8.3"
