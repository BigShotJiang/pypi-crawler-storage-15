"""Tests."""


def test_always_passes():
    """Test that always passes."""
    assert True
