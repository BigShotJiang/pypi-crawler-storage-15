from __future__ import annotations

PROJECT_BASE_NAME: str = "raggify"
PROJECT_NAME: str = f"{PROJECT_BASE_NAME}-client"
VERSION: str = "0.1.4"
DEFAULT_CLIENT_CONFIG_PATH: str = f"/etc/{PROJECT_BASE_NAME}/client_config.yaml"
