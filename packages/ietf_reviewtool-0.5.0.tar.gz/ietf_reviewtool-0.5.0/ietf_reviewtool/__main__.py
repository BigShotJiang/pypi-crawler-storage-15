"""Command line interface"""

from .ietf_reviewtool import cli

if __name__ == "__main__":
    # pylint: disable=no-value-for-parameter
    cli()
