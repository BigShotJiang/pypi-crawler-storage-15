netsim-tools has been renamed to netlab in August 2022.

The Python package netsim-tools has been renamed to networklab and is
installed as a dependency of netsim-tools every time you install or
upgrade netsim-tools, but we won't keep that dependency active foreer.

Please stop using netsim-tools package and use networklab package.
