"""Backwards compatibility shim for legacy build tools.

All project configuration is in pyproject.toml.
This file exists only for compatibility with older tools that
don't support PEP 517/518 (e.g., `pip install -e .` on pip < 21.3).
"""

from setuptools import setup

setup()
