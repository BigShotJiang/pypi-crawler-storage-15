"""Constants used by Kwikset Halo API.

This module contains all constant values used throughout the library,
including AWS Cognito configuration, API endpoints, and HTTP headers.
"""

import logging
from typing import Final

# Logger configuration
LOGGER: logging.Logger = logging.getLogger(__name__)

# AWS Cognito Configuration
POOL_ID: Final[str] = "us-east-1_6B3uo6uKN"
CLIENT_ID: Final[str] = "5eu1cdkjp1itd1fi7b91m6g79s"
POOL_REGION: Final[str] = "us-east-1"

# API Base URL
API_BASE_URL: Final[str] = "https://ynk95r1v52.execute-api.us-east-1.amazonaws.com"

# User Endpoints
GET_USER_URL: Final[str] = f"{API_BASE_URL}/prod_v1/users/me"
GET_HOMES_URL: Final[str] = f"{API_BASE_URL}/prod_v1/users/me/homes?top=200"

# Device Endpoints
GET_HOME_DEVICES_URL: Final[str] = f"{API_BASE_URL}/prod_v1/homes/%s/devices"
GET_DEVICE_URL: Final[str] = f"{API_BASE_URL}/prod_v1/devices_v2/%s"

# Device Command Endpoints
LOCK_COMMAND_URL: Final[str] = f"{API_BASE_URL}/prod_v1/devices/%s/status"
ACCESSORY_COMMAND_URL: Final[str] = f"{API_BASE_URL}/prod_v1/devices/%s/%s"

# HTTP Headers
LOGIN_HEADER_USER_AGENT: Final[str] = (
    "aws-sdk-kotlin/1.3.81 ua/2.1 api/cognito-identity-provider#1.3.81"
)
DEFAULT_HEADER_USER_AGENT: Final[str] = "okhttp/5.0.0-alpha.14"
DEFAULT_HEADER_ACCEPT_ENCODING: Final[str] = "gzip"

# Request Configuration
DEFAULT_TIMEOUT: Final[int] = 30  # seconds
MAX_RETRIES: Final[int] = 3
RETRY_DELAY: Final[float] = 1.0  # seconds
