"""Define /user endpoints.

This module contains the User class for interacting with
Kwikset user account and home endpoints.
"""

from typing import Any

from .const import GET_HOMES_URL, GET_USER_URL
from .types import RequestProtocol


class User:
    """Define an object to handle user-related API endpoints.

    :param request: An async callable conforming to RequestProtocol
    :type request: ``RequestProtocol``
    """

    __slots__ = ("_request",)

    def __init__(self, request: RequestProtocol) -> None:
        """Initialize the User endpoint handler."""
        self._request: RequestProtocol = request

    async def get_info(self) -> dict[str, Any] | None:
        """Return user account information.

        :rtype: ``Optional[Dict[str, Any]]``
        """
        user_info: dict[str, Any] = await self._request(
            "get",
            GET_USER_URL,
        )
        data = user_info.get("data", [])
        return data[0] if data else None

    async def get_homes(self) -> list[dict[str, Any]]:
        """Return all homes associated with the user.

        :rtype: ``List[Dict[str, Any]]``
        """
        homes_info: dict[str, Any] = await self._request(
            "get",
            GET_HOMES_URL,
        )
        result: list[dict[str, Any]] = homes_info.get("data", [])
        return result
