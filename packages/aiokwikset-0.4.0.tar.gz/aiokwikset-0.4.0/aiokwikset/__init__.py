"""aiokwikset - Async Python client for the Kwikset Halo API.

This library provides an asynchronous interface for interacting with
Kwikset smart lock devices via the Kwikset cloud API.

Example usage:
    >>> import asyncio
    >>> from aiokwikset import API
    >>>
    >>> async def main():
    ...     async with API() as api:
    ...         await api.async_login('email@example.com', 'password')
    ...         homes = await api.user.get_homes()
    ...         print(homes)
    >>>
    >>> asyncio.run(main())

Example with MFA:
    >>> from aiokwikset import API, MFAChallengeRequired
    >>>
    >>> async def main():
    ...     async with API() as api:
    ...         try:
    ...             await api.async_login('email@example.com', 'password')
    ...         except MFAChallengeRequired as mfa_error:
    ...             mfa_code = input(f"Enter {mfa_error.mfa_type} code: ")
    ...             await api.async_respond_to_mfa_challenge(
    ...                 mfa_code=mfa_code,
    ...                 mfa_type=mfa_error.mfa_type,
    ...                 mfa_tokens=mfa_error.mfa_tokens
    ...             )
    ...         homes = await api.user.get_homes()
"""

from aiokwikset.api import API
from aiokwikset.device import (
    AccessoryAction,
    CommandResult,
    Device,
    DeviceStatus,
    LockAction,
    ValidationResult,
)
from aiokwikset.errors import (
    AuthenticationError,
    ConnectionError,
    DeviceCommandError,
    DeviceError,
    InvalidActionError,
    InvalidDeviceError,
    InvalidStatusError,
    InvalidUserError,
    KwiksetError,
    MFAChallengeRequired,
    PasswordChangeRequired,
    RequestError,
    TokenExpiredError,
    Unauthenticated,
    UnknownError,
    UserExists,
    UserNotConfirmed,
    UserNotFound,
)
from aiokwikset.types import RequestProtocol
from aiokwikset.user import User

__all__ = [
    # Main API class
    "API",
    # Endpoint handlers
    "Device",
    "User",
    # Type protocols
    "RequestProtocol",
    # Device types and results
    "AccessoryAction",
    "CommandResult",
    "DeviceStatus",
    "LockAction",
    "ValidationResult",
    # Base exceptions
    "KwiksetError",
    "AuthenticationError",
    "DeviceError",
    # Specific exceptions
    "ConnectionError",
    "DeviceCommandError",
    "InvalidActionError",
    "InvalidDeviceError",
    "InvalidStatusError",
    "InvalidUserError",
    "MFAChallengeRequired",
    "PasswordChangeRequired",
    "RequestError",
    "TokenExpiredError",
    "Unauthenticated",
    "UnknownError",
    "UserExists",
    "UserNotConfirmed",
    "UserNotFound",
]

__version__ = "0.4.0"
