#!/usr/bin/env python

"""Tests for `notices` package."""
