"""Unit test package for notices."""
