
__packagename__ = "FastOMA"
__version__ = "0.4.1"

import logging
logger = logging.getLogger("FastOMA")
