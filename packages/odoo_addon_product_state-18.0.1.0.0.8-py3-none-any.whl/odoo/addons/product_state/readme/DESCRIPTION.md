This module introduces the state field on product template and allows
simple product life cycle:

- draft: In Development
- sellable: Normal
- end: End of Lifecycle
- obsolete: Obsolete
