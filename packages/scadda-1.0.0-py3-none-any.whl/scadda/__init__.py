# Import the access function into the package namespace
from .scadda import clustering
