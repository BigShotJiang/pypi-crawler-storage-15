import argparse
import os
import pandas as pd
from kpi_impact_sim.preprocessing import preprocess_dataframe
from kpi_impact_sim.ridge_model import fit_ridge_model
from kpi_impact_sim.simulate import apply_simulation
from kpi_impact_sim.utils import tipo_variable

def run_cli():
    parser = argparse.ArgumentParser(
        description="CLI para entrenar un modelo Ridge y simular impacto en un KPI."
    )

    parser.add_argument("--data", required=True, help="Ruta al CSV de entrada.")
    parser.add_argument("--target", required=True, help="Nombre del KPI objetivo.")
    parser.add_argument("--increment", type=float, required=True,
                        help="Incremento deseado en puntos o porcentaje.")
    parser.add_argument("--output", required=False, default="simulacion_resultado.csv",
                        help="Ruta para guardar la simulación.")

    args = parser.parse_args()

    # ==========================
    # 1. Validar archivo CSV
    # ==========================
    if not os.path.exists(args.data):
        raise FileNotFoundError(
            f"❌ No se encontró el archivo '{args.data}'. "
            f"Ejecuta el comando desde la carpeta donde existe el CSV."
        )

    print("🔹 Cargando dataset...")
    df = pd.read_csv(args.data)

    if df.shape[0] < 30:
        raise ValueError("❌ El dataset debe tener al menos 30 filas para entrenar un modelo confiable.")

    # ==========================
    # 2. Preprocesamiento
    # ==========================
    print("🔹 Preprocesando...")
    df_proc = preprocess_dataframe(df)
    df_num = df_proc.select_dtypes(include="number")

    if args.target not in df_num.columns:
        raise ValueError(
            f"❌ El target '{args.target}' no existe en el dataset. "
            f"Columnas disponibles: {list(df_num.columns)}"
        )

    X = df_num.drop(columns=[args.target])
    y = df_num[args.target]

    # ==========================
    # 3. Entrenar modelo
    # ==========================
    print("🔹 Entrenando modelo Ridge...")
    model_res = fit_ridge_model(X, y)

    # ==========================
    # 4. Simular KPI
    # ==========================
    print("🔹 Ejecutando simulación...")
    sim = apply_simulation(
        model_res["coefs"],
        df_num,
        args.target,
        incremento_pts=args.increment,
        tipo_variable_func=tipo_variable,
        save_path=args.output
    )

    # ==========================
    # 5. Resultados
    # ==========================
    print(f"\n✔ SIMULACIÓN COMPLETADA. Archivo guardado en: {args.output}")
    print("\nTop resultados:")
    print(sim["candidates"].head(10))
