"""Built-in sample routines for python-doten.

These are intentionally simple and stdlib-only, serving as examples of how you
could structure more complex ten-based flows.
"""
