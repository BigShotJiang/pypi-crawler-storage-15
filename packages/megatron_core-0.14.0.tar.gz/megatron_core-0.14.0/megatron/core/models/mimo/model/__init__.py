# Copyright (c) 2025, NVIDIA CORPORATION. All rights reserved.
from megatron.core.models.mimo.model.base import MimoModel

__all__ = ['MimoModel']
