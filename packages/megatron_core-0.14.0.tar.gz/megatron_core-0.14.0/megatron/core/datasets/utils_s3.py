# Copyright (c) 2024, NVIDIA CORPORATION. All rights reserved.
from megatron.core.datasets.object_storage_utils import (  # pylint: disable=unused-import
    S3_PREFIX,
    S3Client,
)
