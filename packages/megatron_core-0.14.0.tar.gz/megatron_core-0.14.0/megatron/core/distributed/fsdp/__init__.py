# Copyright (c) 2024, NVIDIA CORPORATION. All rights reserved.

from .mcore_fsdp_adapter import FullyShardedDataParallel
