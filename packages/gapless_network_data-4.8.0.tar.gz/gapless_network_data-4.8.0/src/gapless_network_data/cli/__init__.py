"""
CLI modules for gapless-network-data.

This package provides the command-line interface.
"""

from gapless_network_data.cli_main import main

__all__ = ["main"]
