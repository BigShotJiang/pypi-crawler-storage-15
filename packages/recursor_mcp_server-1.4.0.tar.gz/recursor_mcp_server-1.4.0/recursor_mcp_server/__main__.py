"""
Entry point for running MCP server or HTTP bridge
"""
from .cli import main

if __name__ == "__main__":
    main()

