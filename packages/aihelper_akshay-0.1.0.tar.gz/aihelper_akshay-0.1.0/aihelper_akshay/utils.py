def format_response(text: str) -> str:
    """Clean AI response (remove extra spaces, fix formatting)."""
    return text.strip()
