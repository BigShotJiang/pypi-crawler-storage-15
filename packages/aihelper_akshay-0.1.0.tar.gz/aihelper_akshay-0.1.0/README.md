# aihelper_akshay

A simple Python library for interacting with AI tools.

## Installation


## Usage
```python
from aihelper_akshay import get_response

print(get_response("Hello AI!"))
