let searchOperatorsEditUrl = "{% url 'core_explore_keyword_app_search_operator_edit' %}";
let searchOperatorsDeleteUrl = "{% url 'core_explore_keyword_app_search_operator_delete' %}";