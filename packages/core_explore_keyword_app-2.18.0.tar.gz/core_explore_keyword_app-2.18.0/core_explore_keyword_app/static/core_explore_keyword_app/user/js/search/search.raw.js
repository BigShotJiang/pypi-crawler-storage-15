var suggestionsURL = "{% url 'core_explore_keyword_suggestions' %}";
var operatorListURL = "{% url 'core_explore_keyword_app_rest_search_operator_list' %}";