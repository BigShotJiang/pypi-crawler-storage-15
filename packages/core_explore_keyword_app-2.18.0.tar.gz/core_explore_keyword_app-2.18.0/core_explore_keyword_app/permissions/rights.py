""" Rights for core explore keyword app
"""

EXPLORE_KEYWORD_CONTENT_TYPE = "core_explore_keyword_app"
EXPLORE_KEYWORD_ACCESS = "access_explore_keyword"
