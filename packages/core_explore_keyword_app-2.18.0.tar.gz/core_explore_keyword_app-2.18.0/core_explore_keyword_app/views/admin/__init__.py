""" Admin views for explore by keyword
"""
