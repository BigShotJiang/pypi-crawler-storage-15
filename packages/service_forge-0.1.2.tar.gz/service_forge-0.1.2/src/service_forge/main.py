default_service_config = "configs/service/test_service_websocket.yaml"
#!/usr/bin/env python3
"""
Service Forge 主入口文件
用于启动 Service Forge 服务
"""

import os
import sys
import argparse
from pathlib import Path
from loguru import logger

# 添加项目根目录到Python路径
project_root = Path(__file__).parent.parent.parent
sys.path.insert(0, str(project_root))

from service_forge.service import create_service


def parse_args():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(description="Service Forge - 工作流服务框架")

    # 配置文件参数
    parser.add_argument(
        "-c", "--config",
        type=str,
        default="config.yaml",
        help="服务配置文件路径 (默认: config.yaml)"
    )

    # 工作流配置参数
    parser.add_argument(
        "-w", "--workflows",
        type=str,
        nargs="+",
        help="工作流配置文件路径列表"
    )

    # 调试模式
    parser.add_argument(
        "--debug",
        action="store_true",
        help="启用调试模式"
    )

    # 端口参数
    parser.add_argument(
        "--port",
        type=int,
        default=8000,
        help="HTTP服务端口 (默认: 8000)"
    )

    # 主机参数
    parser.add_argument(
        "--host",
        type=str,
        default="0.0.0.0",
        help="HTTP服务主机 (默认: 0.0.0.0)"
    )

    return parser.parse_args()


def main():
    """主函数"""
    args = parse_args()

    # 设置日志级别
    if args.debug:
        logger.remove()
        logger.add(
            sys.stderr,
            level="DEBUG",
            format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>"
        )

    # 检查配置文件是否存在
    config_path = Path(args.config)
    if not config_path.exists():
        config_path = default_service_config

    # 创建服务
    try:
        logger.info(f"正在加载配置文件: {config_path}")
        
        # 导入WebSocketMessage模型
        from service_forge.model.websocket import WebSocketMessage
        
        # 创建服务并添加WEBSOCKET_MESSAGE到service_env
        service = create_service(str(config_path), service_env={"WEBSOCKET_MESSAGE": WebSocketMessage})

        # 如果指定了工作流配置，则添加到服务中
        if args.workflows:
            for workflow_path in args.workflows:
                if not Path(workflow_path).exists():
                    logger.error(f"工作流配置文件不存在: {workflow_path}")
                    continue
                logger.info(f"添加工作流配置: {workflow_path}")
                # 这里需要根据实际情况调整

        # 启动服务
        logger.info("正在启动 Service Forge 服务...")
        logger.info(f"HTTP服务器: http://{args.host}:{args.port}")
        logger.info("WebSocket端点: ws://{}:{}/ws/connect/{{client_id}}".format(args.host, args.port))

        # 运行服务
        import asyncio
        asyncio.run(service.start())

    except KeyboardInterrupt:
        logger.info("服务已停止")
    except Exception as e:
        logger.error(f"服务启动失败: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
