from pydantic import BaseModel

class DeleteTagModel(BaseModel):
    id: str