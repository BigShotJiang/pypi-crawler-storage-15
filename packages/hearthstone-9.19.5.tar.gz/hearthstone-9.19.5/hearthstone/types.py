from typing import Dict

from hearthstone import enums


GameTagsDict = Dict[enums.GameTag, int]
