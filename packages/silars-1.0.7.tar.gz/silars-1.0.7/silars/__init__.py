# Copyright (c) ZhangYundi.
# Licensed under the MIT License. 
# Created on 2025/7/17 10:53
# Description:

__version__ = "1.0.7"

from .qdf import to_lazy, Expr
from .data import Dataset, Table
from .svc import D

__all__ = [
    "to_lazy",
    "Expr",
    "Dataset",
    "Table",
    "D",
]