"""Merge heads

Revision ID: 4fc34906c389
Revises: aaa81d97a6f6, f131a1263a10
Create Date: 2022-08-17 19:35:33.413593

"""

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision = "4fc34906c389"
down_revision = ("aaa81d97a6f6", "f131a1263a10")
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
