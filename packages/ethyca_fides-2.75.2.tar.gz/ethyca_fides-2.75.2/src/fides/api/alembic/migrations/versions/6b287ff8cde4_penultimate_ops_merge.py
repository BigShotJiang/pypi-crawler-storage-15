"""penultimate ops merge

Revision ID: 6b287ff8cde4
Revises: c4df5d585029, cdbd0fa118dd
Create Date: 2022-10-04 17:38:30.961693

"""

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision = "6b287ff8cde4"
down_revision = ("c4df5d585029", "cdbd0fa118dd")
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
