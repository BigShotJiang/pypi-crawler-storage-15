"""Dummy settings so that we can import things that import from django"""

INSTALLED_APPS = ["gentoo_build_publisher"]
