.. automodule:: qiskit_ibm_catalog.catalog
   :no-members:
   :no-inherited-members:
   :no-special-members:
