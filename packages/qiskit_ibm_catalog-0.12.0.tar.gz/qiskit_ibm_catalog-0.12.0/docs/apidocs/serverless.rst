.. automodule:: qiskit_ibm_catalog.serverless
   :no-members:
   :no-inherited-members:
   :no-special-members:
