Zenodo integration
==================

In order to make your project code citable GitHub has built-in
capability to integrate your code into Zenodo.

Requirements:
- repository has to be public
- Zenodo account

Follow those simple steps [here](https://guides.github.com/activities/citable-code/) to add your project to Zenodo.
