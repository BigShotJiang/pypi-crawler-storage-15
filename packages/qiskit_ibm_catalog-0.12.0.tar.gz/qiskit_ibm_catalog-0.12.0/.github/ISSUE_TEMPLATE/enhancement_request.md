---
name: 💅 Enhancement request
about: Suggest an improvement for this project 🆒!
labels: 'type: enhancement'
---

<!-- ⚠️ If you do not respect this template, your issue will be closed -->
<!-- ⚠️ Make sure to browse the opened and closed issues to confirm this idea does not exist. -->

### What is the expected enhancement?

