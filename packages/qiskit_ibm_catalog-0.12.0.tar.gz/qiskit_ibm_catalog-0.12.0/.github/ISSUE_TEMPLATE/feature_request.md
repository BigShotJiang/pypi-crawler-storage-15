---
name: 🚀 Feature request
about: Suggest an idea for this project 💡!
labels: 'type: feature request'
---

<!-- ⚠️ If you do not respect this template, your issue will be closed -->
<!-- ⚠️ Make sure to browse the opened and closed issues to confirm this idea does not exist. -->

### What is the expected behavior?

