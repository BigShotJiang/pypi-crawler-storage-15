from ._cli import main as main

if __name__ == "__main__":
    main()
