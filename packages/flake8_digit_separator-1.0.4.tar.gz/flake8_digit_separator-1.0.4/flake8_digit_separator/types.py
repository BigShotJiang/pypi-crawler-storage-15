from typing import TypeAlias

ErrorMessage: TypeAlias = tuple[int, int, str, type[object]]
