from typing import TypeAlias

TokenLikeStr: TypeAlias = str
