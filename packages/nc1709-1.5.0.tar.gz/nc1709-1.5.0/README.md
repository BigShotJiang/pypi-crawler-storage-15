# NC1709 - A Local-First AI Developer Assistant

<p align="center">
  <strong>Your code stays on your machine. Always.</strong>
</p>

<p align="center">
  <a href="#installation">Installation</a> •
  <a href="#quick-start">Quick Start</a> •
  <a href="#features">Features</a> •
  <a href="#web-dashboard">Web Dashboard</a> •
  <a href="#plugins">Plugins</a>
</p>

---

NC1709 is a powerful, **100% local** AI developer assistant. Unlike cloud-based tools, your code and conversations never leave your computer.

## Installation

```bash
# Install from PyPI
pip install nc1709

# Or install with all features (web dashboard, memory, etc.)
pip install nc1709[all]
```

### Prerequisites

1. **Python 3.9+**
2. **Ollama** - Local LLM server
   ```bash
   curl -fsSL https://ollama.com/install.sh | sh
   ```
3. **Download models**
   ```bash
   ollama pull qwen2.5-coder:32b
   ollama pull qwen2.5:32b
   ```

## Quick Start

```bash
# Interactive shell mode
nc1709

# Direct command
nc1709 "create a Python script to fetch JSON from an API"

# Start web dashboard
nc1709 --web
```

## Features

### Core Capabilities
- **Chat Interface** - Conversational AI for coding help
- **File Operations** - Read, write, edit files safely with auto-backup
- **Command Execution** - Run shell commands in a sandboxed environment
- **Multi-Step Reasoning** - Complex tasks broken into manageable steps

### Memory & Context (Phase 2)
- **Semantic Code Search** - Find code by meaning, not just keywords
- **Project Indexing** - Index your codebase for intelligent search
- **Session Persistence** - Save and resume conversations

```bash
# Index your project
nc1709 --index

# Semantic search
nc1709 --search "authentication logic"

# Resume a session
nc1709 --sessions
nc1709 --resume <session-id>
```

### Plugins & Agents (Phase 3)
- **Git Agent** - Commits, branches, diffs, and more
- **Docker Agent** - Container and image management
- **Framework Agents** - FastAPI, Next.js, Django scaffolding
- **MCP Support** - Model Context Protocol integration

```bash
# In shell mode
git status
git diff
docker ps
docker compose up

# Or via CLI
nc1709 --plugin git:status
nc1709 --plugin docker:ps
```

### Web Dashboard (Phase 4)
A full browser-based interface for NC1709:

```bash
nc1709 --web
# Open http://localhost:8709
```

Features:
- Chat with syntax highlighting
- Session management
- Semantic code search UI
- Plugin management
- MCP tools browser
- Configuration editor

## Shell Commands

In interactive mode:

```
help          Show available commands
exit          Exit the shell
clear         Clear conversation history
sessions      List saved sessions
search <q>    Semantic code search
index         Index current project
plugins       List available plugins
git <cmd>     Git operations
docker <cmd>  Docker operations
mcp           MCP status and tools
```

## Configuration

Config file: `~/.nc1709/config.json`

```bash
nc1709 --config  # View configuration
```

```json
{
  "models": {
    "reasoning": "deepseek-r1:latest",
    "coding": "qwen2.5-coder:32b",
    "general": "qwen2.5:32b"
  },
  "safety": {
    "confirm_writes": true,
    "auto_backup": true
  }
}
```

## CLI Reference

```bash
nc1709 [prompt]           # Direct command or start shell
nc1709 --shell            # Interactive shell mode
nc1709 --web              # Start web dashboard
nc1709 --web --port 9000  # Custom port

# Memory features
nc1709 --index            # Index project
nc1709 --search "query"   # Semantic search
nc1709 --sessions         # List sessions
nc1709 --resume <id>      # Resume session

# Plugins
nc1709 --plugins          # List plugins
nc1709 --plugin git:status

# MCP
nc1709 --mcp-status       # MCP status
nc1709 --mcp-tool read_file --args '{"path": "main.py"}'

# Info
nc1709 --version          # Show version
nc1709 --config           # Show configuration
nc1709 --help             # Show help
```

## Installation Options

```bash
# Basic installation
pip install nc1709

# With memory features (ChromaDB, embeddings)
pip install nc1709[memory]

# With web dashboard
pip install nc1709[web]

# Everything
pip install nc1709[all]

# Development
pip install nc1709[dev]
```

## System Requirements

- **Python**: 3.9+
- **RAM**: 16GB minimum, 32GB recommended
- **GPU**: NVIDIA with 12GB+ VRAM (optional, CPU works but slower)
- **Storage**: ~50GB for models
- **OS**: macOS, Linux, Windows (WSL2)

## Project Structure

```
nc1709/
├── nc1709/
│   ├── cli.py              # Main CLI
│   ├── config.py           # Configuration
│   ├── llm_adapter.py      # LLM integration
│   ├── reasoning_engine.py # Multi-step reasoning
│   ├── file_controller.py  # File operations
│   ├── executor.py         # Command execution
│   ├── memory/             # Vector DB, sessions, indexing
│   ├── plugins/            # Plugin system & agents
│   ├── mcp/                # Model Context Protocol
│   └── web/                # Web dashboard
├── tests/                  # 221 tests
├── pyproject.toml          # Package config
└── README.md
```

## Privacy & Security

- **100% Local**: All processing happens on your machine
- **No Telemetry**: Zero data collection
- **Auto-Backup**: Files backed up before modification
- **Sandboxed Execution**: Commands validated before running
- **Confirmation Prompts**: Ask before destructive operations

## Troubleshooting

### "Cannot connect to Ollama"
```bash
ollama serve  # Start Ollama
```

### "Model not found"
```bash
ollama pull qwen2.5-coder:32b
```

### Slow performance
- Use GPU: `nvidia-smi` to verify
- Use smaller models: `qwen2.5-coder:7b`
- Clear history: `clear` in shell

## Contributing

Contributions welcome! See [CONTRIBUTING.md](CONTRIBUTING.md).

## License

MIT License - See [LICENSE](LICENSE) file.

## Acknowledgments

Built with [Ollama](https://ollama.com/), [LiteLLM](https://github.com/BerriAI/litellm), and open-source models from DeepSeek and Qwen.

---

**Built for developers who value privacy and control.**
