- Follow steps outlined in Configuration.
- User will receive validation error if a field is not set when
  attempting to move to a new stage.
