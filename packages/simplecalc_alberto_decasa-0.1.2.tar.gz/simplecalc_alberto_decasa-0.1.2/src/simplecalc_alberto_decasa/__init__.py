from .operaciones import calcular

__all__ = ["calcular"]
