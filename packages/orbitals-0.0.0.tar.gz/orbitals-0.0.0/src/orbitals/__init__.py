__version__ = "0.0.0"

raise ImportError("This package is a placeholder. Full release coming soon.")
