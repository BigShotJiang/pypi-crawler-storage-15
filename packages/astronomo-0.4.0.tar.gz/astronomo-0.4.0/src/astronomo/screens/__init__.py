"""Screens for Astronomo."""

from astronomo.screens.settings import SettingsScreen

__all__ = ["SettingsScreen"]
