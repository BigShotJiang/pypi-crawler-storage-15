To configure this module, you need to:

1. Go to Inventory > Configuration > Settings > Operations.
2. Activate Batch, Wave & Cluster Transfers
