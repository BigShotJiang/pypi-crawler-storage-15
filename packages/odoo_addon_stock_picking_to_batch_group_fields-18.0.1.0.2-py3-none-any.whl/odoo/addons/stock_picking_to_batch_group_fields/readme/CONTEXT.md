Currently this module [stock_picking_batch_extended](https://github.com/OCA/stock-logistics-workflow/tree/16.0/stock_picking_batch_extended) includes this functionality but to make it work it is necessary to activate the OCA batches, which forces to use other behaviors than Odoo's for the picking batches.

It will be useful for you if you want to make the grouping of pickings manually using any field of the delivery order.
