To use this module, you need to:

1. Go to Inventory > Overview.
2. Access the pickings to process in one of the types of operations.
3. Select multiple pickings.
4. Click on Action > Add to batch.
5. Choose add to **a new batch transfer** and check **Group by fields**
6. Select the fields you want to group by.
7. Click on **Confirm**.
8. Multiple batches will be created by grouping the picking by the fields you selected.
9. Fields you selected are saved and will be loaded for the next time.
