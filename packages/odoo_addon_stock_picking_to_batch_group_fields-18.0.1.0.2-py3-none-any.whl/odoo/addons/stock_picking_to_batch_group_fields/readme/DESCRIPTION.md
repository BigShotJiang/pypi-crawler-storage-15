This module extends the functionality of the picking batch and allows you to manually group pickings by any field in the model.
