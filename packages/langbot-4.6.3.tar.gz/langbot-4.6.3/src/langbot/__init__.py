"""LangBot - Easy-to-use global IM bot platform designed for LLM era"""

__version__ = '4.6.3'
