"""
Dars Hooks System

Hooks provide a way to add reactive and stateful behavior to FunctionComponents.
"""

from .use_dynamic import useDynamic

__all__ = ['useDynamic']
