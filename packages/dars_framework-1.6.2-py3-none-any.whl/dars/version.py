__version__ = "1.6.2"
__release_url__ = "https://github.com/ZtaMDev/Dars-Framework/releases/tag/1.6.2"