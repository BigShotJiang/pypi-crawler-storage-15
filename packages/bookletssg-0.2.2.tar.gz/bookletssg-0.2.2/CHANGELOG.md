# 0.2.0

- cleaned up the original script and made the code more organized
- removed usage of `path` and switched everything to `os`
- added support for external themes: if `theme` is not "default", the css is fetched and injected
- separated markdown rendering, templates, and build logic
- consistent html writing with explicit encoding
- simplified the cli flow (init, build, version)
- removed duplicated code and unnecessary functions
- removed `.DS_Store` from git tracking... yeah