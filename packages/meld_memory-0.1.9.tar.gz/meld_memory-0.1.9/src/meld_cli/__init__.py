"""Meld CLI - Personal memory system for Claude Code."""

from importlib.metadata import version

__version__ = version("meld-memory")
