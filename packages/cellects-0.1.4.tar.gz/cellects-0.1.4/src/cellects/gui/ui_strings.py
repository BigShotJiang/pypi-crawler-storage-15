#!/usr/bin/env python3


TOOLTIPS = {
    "save_button": "Saves your current settings.",
    "help_icon": "Click for detailed instructions on using this feature.",
    "export_menu": "Exports data in CSV or PDF format."
}