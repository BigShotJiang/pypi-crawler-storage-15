# ASSEP

API desenvolvida para automatizar tarefas e obtensção de dados de softwares comumente utilizados em estudos de sistemas elétricos de potência.

## Instalação

Você pode instalar a última versão do pacote via pip:

```bash
pip install assep
```

## Módulos

Este projeto contém os seguintes módulos:

### anarede

...

Exemplo de uso:

```python
...
```

### anafas

...

Exemplo de uso:

```python
...
```

### atp

...

Exemplo de uso:

```python
...
```

### barra

...

Exemplo de uso:

```python
...
```

### decks

...

Exemplo de uso:

```python
...
```

### base_cc

...

Exemplo de uso:

```python
...
```

### linha

...

Exemplo de uso:

```python
...
```

### plt

...

Exemplo de uso:

```python
...
```

## Licença

Este projeto está licenciado sob a GNU GENERAL PUBLIC LICENSE. Isso significa que você pode copiar, distribuir e modificar o software, desde que você acompanhe quaisquer modificações com a mesma licença e que você disponibilize o código-fonte.

Para mais detalhes, por favor veja o arquivo LICENSE no repositório ou visite o site oficial da GNU.
