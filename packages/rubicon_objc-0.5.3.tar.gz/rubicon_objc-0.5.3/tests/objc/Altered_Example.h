#import <Foundation/Foundation.h>

#import "Example.h"

@interface Altered_Example : Example {

}

@end
