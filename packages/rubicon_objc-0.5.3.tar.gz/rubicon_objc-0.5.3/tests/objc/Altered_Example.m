#import "Altered_Example.h"
#import <stdio.h>

@implementation Altered_Example

@end
