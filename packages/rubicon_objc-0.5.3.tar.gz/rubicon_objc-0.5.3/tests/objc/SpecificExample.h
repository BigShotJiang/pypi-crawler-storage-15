#import <Foundation/Foundation.h>

#import "Example.h"

@interface SpecificExample : Example {

}

@end
