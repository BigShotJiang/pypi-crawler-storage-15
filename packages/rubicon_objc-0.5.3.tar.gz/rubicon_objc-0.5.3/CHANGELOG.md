# Changelog

A complete history of the changes to Rubicon can be found in [Rubicon's documentation](./docs/background/releases).
