# Success Stories

Want to see examples of Rubicon in use? Here's some:

- [Travel Tips](https://apps.apple.com/au/app/travel-tips/id1336372310) is an app in the iOS App Store that uses Rubicon to access the iOS UIKit libraries.
