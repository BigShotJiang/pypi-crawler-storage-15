# `rubicon.objc.eventloop` - Integrating native event loops with `asyncio`

/// note | Note

The documentation for this module is incomplete. You can help by [contributing to the documentation][contribute-docs].

///

::: rubicon.objc.eventloop.EventLoopPolicy

::: rubicon.objc.eventloop.CocoaLifecycle
    options:
        show_if_no_docstring: true

::: rubicon.objc.eventloop.iOSLifecycle
    options:
        show_if_no_docstring: true
