class System:
    """
    Baseclass for all systems.
    """

    identifier: str = None
