from linzt_scrna_test import main

main()
