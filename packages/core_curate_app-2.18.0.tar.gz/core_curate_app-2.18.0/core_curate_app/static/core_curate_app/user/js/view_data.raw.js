var saveDataUrl = "{% url 'core_curate_save_data' %}";
var curateIndexUrl = "{% url 'core_curate_index' %}";
var downloadDocumentUrl = "{% url 'core_curate_download_document' data.data_structure.id %}";
var downloadTemplateUrl = "{% url 'core_curate_download_template' data.data_structure.id %}";