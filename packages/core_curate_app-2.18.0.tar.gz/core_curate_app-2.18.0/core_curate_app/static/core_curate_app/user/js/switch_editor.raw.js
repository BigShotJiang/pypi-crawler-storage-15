var saveFormUrl = "{% url 'core_curate_save_form' %}";
var switchToFormUrl = "{% url 'core_curate_enter_data' 'curate_data_structure_id' %}"