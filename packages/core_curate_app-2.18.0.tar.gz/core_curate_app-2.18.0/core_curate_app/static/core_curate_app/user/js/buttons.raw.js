var generateElementUrl = "{% url 'core_curate_generate_element' data.data_structure.id %}";
var removeElementUrl = "{% url 'core_curate_remove_element' %}";
