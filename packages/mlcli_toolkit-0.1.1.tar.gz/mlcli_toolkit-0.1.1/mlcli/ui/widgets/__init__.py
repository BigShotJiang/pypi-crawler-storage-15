"""TUI widgets module."""

__all__ = []
