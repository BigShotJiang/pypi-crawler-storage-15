"""ucow - A Cowgol compiler for 8080/Z80."""

__version__ = "0.3.0"
