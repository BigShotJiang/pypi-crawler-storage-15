def test_version():
    from ctapipe_io_nectarcam import __version__

    assert __version__ != '0.0.0'
