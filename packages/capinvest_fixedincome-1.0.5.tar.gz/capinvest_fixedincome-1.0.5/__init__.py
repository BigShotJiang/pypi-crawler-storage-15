"""Fixed income router init."""
