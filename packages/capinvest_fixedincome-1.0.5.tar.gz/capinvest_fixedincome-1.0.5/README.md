# CapInvest Fixed Income Extension

This extension provides fixed income data for the CapInvest Platform.

Features of the Fixed Income extension include information on government bonds and central bank rates.
 
