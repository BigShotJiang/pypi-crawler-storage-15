"""Migrate data from JSON storage to SQL storage."""

import json
import logging
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import click

from telegram_bot_stack.logging import (
    get_logger,
    log_command_end,
    log_command_start,
    log_file_operation,
    log_step,
)

logger = logging.getLogger(__name__)


def discover_json_files(json_dir: Path) -> List[Tuple[str, Path]]:
    """Discover all JSON files in the directory.

    Args:
        json_dir: Directory containing JSON files

    Returns:
        List of tuples (key, filepath) where key is the storage key
    """
    json_files: list[tuple[str, Path]] = []

    if not json_dir.exists():
        logger.error(f"Directory not found: {json_dir}")
        return json_files

    for filepath in json_dir.glob("*.json"):
        # Remove .json extension to get the key
        key = filepath.stem
        json_files.append((key, filepath))

    return json_files


def load_json_data(filepath: Path) -> Dict[Any, Any]:
    """Load data from JSON file.

    Args:
        filepath: Path to JSON file

    Returns:
        Loaded data or empty dict on error
    """
    try:
        log_file_operation("read", filepath, success=True)
        with open(filepath, encoding="utf-8") as f:
            return json.load(f)  # type: ignore[no-any-return]
    except Exception as e:
        logger.error(f"Error loading {filepath}: {e}")
        log_file_operation("read", filepath, success=False)
        return {}


def migrate_data(
    json_dir: str,
    database_url: str,
    dry_run: bool = False,
    verbose: bool = False,
) -> Tuple[int, int]:
    """Migrate data from JSON storage to SQL storage.

    Args:
        json_dir: Directory containing JSON files
        database_url: SQLAlchemy database URL
        dry_run: If True, only preview migration without writing
        verbose: Enable verbose logging

    Returns:
        Tuple of (successful_count, failed_count)
    """
    if verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    json_path = Path(json_dir)

    # Discover JSON files
    log_step(
        "discover_json_files",
        "Scanning directory for JSON files",
        details={"path": str(json_path)},
    )
    click.secho(f"📂 Scanning directory: {json_path}", fg="cyan")
    json_files = discover_json_files(json_path)

    if not json_files:
        click.secho("⚠️  No JSON files found to migrate", fg="yellow")
        return 0, 0

    click.secho(f"📋 Found {len(json_files)} JSON file(s) to migrate", fg="cyan")

    if dry_run:
        click.secho(
            "\n🔍 DRY RUN MODE - No data will be written to database",
            fg="yellow",
            bold=True,
        )
        click.secho("-" * 60, fg="cyan")

        for key, filepath in json_files:
            data = load_json_data(filepath)
            data_preview = str(data)[:100]
            if len(str(data)) > 100:
                data_preview += "..."

            click.secho(f"Would migrate: {key}", fg="cyan")
            click.secho(f"  Source: {filepath}", fg="white")
            click.secho(f"  Data preview: {data_preview}", fg="white")
            click.echo("")

        click.secho("-" * 60, fg="cyan")
        click.secho(
            f"✅ DRY RUN COMPLETE: {len(json_files)} file(s) would be migrated",
            fg="green",
        )
        return len(json_files), 0

    # Create SQL storage
    log_step(
        "connect_database",
        "Connecting to database",
        details={"database_url": database_url},
    )
    click.secho(f"🔌 Connecting to database: {database_url}", fg="cyan")
    try:
        from telegram_bot_stack.storage import SQLStorage

        sql_storage = SQLStorage(database_url=database_url)
    except ImportError:
        click.secho(
            "❌ SQLAlchemy not installed. Install with: pip install telegram-bot-stack[database]",
            fg="red",
            bold=True,
        )
        return 0, len(json_files)
    except Exception as e:
        click.secho(f"❌ Failed to connect to database: {e}", fg="red", bold=True)
        return 0, len(json_files)

    # Migrate each file
    successful = 0
    failed = 0

    click.secho("\n🚀 Starting migration...", fg="cyan", bold=True)
    click.secho("-" * 60, fg="cyan")

    for key, filepath in json_files:
        try:
            log_step(
                "migrate_key",
                f"Migrating key: {key}",
                details={"key": key, "file": str(filepath)},
            )
            # Load data from JSON
            data = load_json_data(filepath)

            if not data:
                click.secho(f"⚠️  Skipping empty file: {key}", fg="yellow")
                continue

            # Save to SQL
            if sql_storage.save(key, data):
                successful += 1
                log_step(
                    "migrate_key",
                    f"Migrated key: {key}",
                    success=True,
                    details={"key": key},
                )
                click.secho(f"✓ Migrated: {key}", fg="green")
                if verbose:
                    click.secho(f"  Data: {data}", fg="white")
            else:
                failed += 1
                log_step(
                    "migrate_key",
                    f"Failed to migrate key: {key}",
                    success=False,
                    details={"key": key},
                )
                click.secho(f"✗ Failed to migrate: {key}", fg="red")

        except Exception as e:
            failed += 1
            log_step(
                "migrate_key", f"Error migrating key: {key}", success=False, error=e
            )
            click.secho(f"✗ Error migrating {key}: {e}", fg="red")

    # Close SQL connection
    sql_storage.close()

    click.secho("-" * 60, fg="cyan")
    if successful > 0:
        click.secho(f"✅ Migration complete: {successful} successful", fg="green")
    if failed > 0:
        click.secho(f"❌ Migration complete: {failed} failed", fg="red")

    return successful, failed


def verify_migration(
    json_dir: str, database_url: str, verbose: bool = False
) -> Tuple[int, int]:
    """Verify that migrated data matches source JSON files.

    Args:
        json_dir: Directory containing JSON files
        database_url: SQLAlchemy database URL
        verbose: Enable verbose logging

    Returns:
        Tuple of (matching_count, mismatching_count)
    """
    if verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    json_path = Path(json_dir)

    # Discover JSON files
    json_files = discover_json_files(json_path)

    if not json_files:
        click.secho("⚠️  No JSON files found to verify", fg="yellow")
        return 0, 0

    # Create storages
    try:
        from telegram_bot_stack.storage import SQLStorage

        sql_storage = SQLStorage(database_url=database_url)
    except ImportError:
        click.secho(
            "❌ SQLAlchemy not installed. Install with: pip install telegram-bot-stack[database]",
            fg="red",
            bold=True,
        )
        return 0, len(json_files)
    except Exception as e:
        click.secho(f"❌ Failed to connect to database: {e}", fg="red", bold=True)
        return 0, len(json_files)

    matching = 0
    mismatching = 0

    click.secho("\n🔍 Verifying migration...", fg="cyan", bold=True)
    click.secho("-" * 60, fg="cyan")

    for key, filepath in json_files:
        try:
            # Load from JSON
            json_data = load_json_data(filepath)

            # Load from SQL
            sql_data = sql_storage.load(key)

            # Compare
            if json_data == sql_data:
                matching += 1
                click.secho(f"✓ Verified: {key}", fg="green")
                if verbose:
                    click.secho(f"  Data matches: {json_data}", fg="white")
            else:
                mismatching += 1
                click.secho(f"✗ Mismatch: {key}", fg="red")
                click.secho(f"  JSON: {json_data}", fg="white")
                click.secho(f"  SQL:  {sql_data}", fg="white")

        except Exception as e:
            mismatching += 1
            click.secho(f"✗ Error verifying {key}: {e}", fg="red")

    sql_storage.close()

    click.secho("-" * 60, fg="cyan")
    if matching > 0:
        click.secho(f"✅ Verification complete: {matching} matching", fg="green")
    if mismatching > 0:
        click.secho(f"❌ Verification complete: {mismatching} mismatching", fg="red")

    return matching, mismatching


@click.command()
@click.option(
    "--json-dir",
    type=click.Path(exists=True, file_okay=False, dir_okay=True, path_type=Path),
    required=True,
    help="Directory containing JSON files",
)
@click.option(
    "--database-url",
    type=str,
    required=True,
    help="SQLAlchemy database URL (e.g., sqlite:///bot.db)",
)
@click.option(
    "--dry-run",
    is_flag=True,
    default=False,
    help="Preview migration without writing to database",
)
@click.option(
    "--verify",
    is_flag=True,
    default=False,
    help="Verify migration by comparing JSON and SQL data",
)
@click.option(
    "--verbose",
    "-v",
    is_flag=True,
    default=False,
    help="Enable verbose output",
)
def migrate(
    json_dir: Path,
    database_url: str,
    dry_run: bool,
    verify: bool,
    verbose: bool,
) -> None:
    """Migrate data from JSON storage to SQL storage.

    This command migrates data from JSON files to a SQL database,
    preserving all keys and data structures.

    Examples:

        # Dry run (preview migration)
        telegram-bot-stack migrate --json-dir data --database-url sqlite:///bot.db --dry-run

        # Migrate to SQLite
        telegram-bot-stack migrate --json-dir data --database-url sqlite:///bot.db

        # Migrate to PostgreSQL
        telegram-bot-stack migrate \\
            --json-dir data \\
            --database-url postgresql://user:pass@localhost/bot_db

        # Verify migration
        telegram-bot-stack migrate \\
            --json-dir data \\
            --database-url sqlite:///bot.db \\
            --verify
    """
    start_time = time.time()
    get_logger()  # Initialize logger

    # Log command start
    log_command_start(
        command_name="migrate",
        parameters={
            "json_dir": str(json_dir),
            "database_url": database_url,
            "dry_run": dry_run,
            "verify": verify,
            "verbose": verbose,
        },
    )

    success = False
    error: Optional[Exception] = None

    try:
        # Verify SQLAlchemy is installed
        try:
            import importlib

            importlib.import_module("sqlalchemy")
        except ImportError:
            click.secho(
                "❌ SQLAlchemy not installed. Install with: pip install telegram-bot-stack[database]",
                fg="red",
                bold=True,
            )
            sys.exit(1)

        # Run migration or verification
        if verify:
            _matching, mismatching = verify_migration(
                str(json_dir), database_url, verbose
            )
            success = mismatching == 0
            if mismatching > 0:
                sys.exit(1)
        else:
            _successful, failed = migrate_data(
                str(json_dir), database_url, dry_run, verbose
            )
            success = failed == 0
            if failed > 0:
                sys.exit(1)

    except KeyboardInterrupt:
        click.secho("\n\n⚠️  Migration interrupted by user", fg="yellow")
        sys.exit(130)
    except Exception as e:
        error = e
        click.secho(f"\n❌ Error: {e}", fg="red", bold=True)
        sys.exit(1)
    finally:
        # Log command end
        duration = time.time() - start_time
        log_command_end(
            command_name="migrate",
            success=success,
            duration_seconds=duration,
            error=error,
        )
