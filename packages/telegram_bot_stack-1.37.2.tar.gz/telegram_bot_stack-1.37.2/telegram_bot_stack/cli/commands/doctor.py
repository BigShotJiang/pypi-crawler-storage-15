"""Doctor command for project health diagnostics."""

import sys
import time
from pathlib import Path
from typing import List, Optional

import click

from telegram_bot_stack.cli.utils.health_checks import (
    HealthChecker,
    auto_fix_issues,
    print_health_report,
)
from telegram_bot_stack.logging import (
    get_logger,
    log_command_end,
    log_command_start,
    log_step,
)


@click.command()
@click.option(
    "--check",
    "categories",
    multiple=True,
    type=click.Choice(
        ["python", "dependencies", "files", "config", "security", "deployment"],
        case_sensitive=False,
    ),
    help="Run specific checks only (can be used multiple times)",
)
@click.option(
    "--fix",
    is_flag=True,
    help="Automatically fix issues where possible",
)
@click.option(
    "--dry-run",
    is_flag=True,
    help="Show what would be fixed without applying changes (use with --fix)",
)
@click.option(
    "--verbose",
    "-v",
    is_flag=True,
    help="Show all checks including passed ones",
)
@click.option(
    "--strict",
    is_flag=True,
    help="Exit with error code if any issues found",
)
def doctor(
    categories: tuple,
    fix: bool,
    dry_run: bool,
    verbose: bool,
    strict: bool,
) -> None:
    """Run health checks on your bot project.

    Diagnoses common issues with dependencies, configuration, security,
    and deployment setup. Can automatically fix many issues.

    \b
    Examples:
        # Run all health checks
        telegram-bot-stack doctor

        # Check specific categories
        telegram-bot-stack doctor --check dependencies --check config

        # Show all checks including passed ones
        telegram-bot-stack doctor --verbose

        # Auto-fix issues
        telegram-bot-stack doctor --fix

        # Preview fixes without applying
        telegram-bot-stack doctor --fix --dry-run

        # Use in CI/CD (exit with error if issues found)
        telegram-bot-stack doctor --strict

    \b
    Check Categories:
        python       - Python version
        dependencies - Package installation
        files        - Required project files
        config       - Bot configuration
        security     - Security best practices
        deployment   - Deployment tools (Docker, SSH)
    """
    start_time = time.time()
    get_logger()  # Initialize logger

    # Log command start
    check_list: Optional[List[str]] = list(categories) if categories else None
    log_command_start(
        command_name="doctor",
        parameters={
            "categories": check_list,
            "fix": fix,
            "dry_run": dry_run,
            "verbose": verbose,
            "strict": strict,
        },
    )

    success = False
    error = None

    click.secho("\n🏥 Running health checks...", fg="cyan", bold=True)

    # Run health checks
    log_step(
        "run_health_checks",
        f"Running health checks (categories: {check_list or 'all'})",
    )
    try:
        checker = HealthChecker(project_path=Path.cwd())
        report = checker.run_all_checks(categories=check_list)
        log_step(
            "run_health_checks",
            f"Running health checks (categories: {check_list or 'all'})",
            success=True,
            details={
                "errors_count": len(report.errors),
                "warnings_count": len(report.warnings),
                "has_errors": report.has_errors,
            },
        )
    except Exception as e:
        log_step(
            "run_health_checks",
            f"Running health checks (categories: {check_list or 'all'})",
            success=False,
            error=e,
        )
        raise

    # Print report
    print_health_report(report, verbose=verbose)

    # Auto-fix if requested
    if fix:
        log_step("auto_fix", f"Auto-fixing issues (dry_run: {dry_run})")
        click.echo()
        try:
            fixed_count = auto_fix_issues(report, dry_run=dry_run)
            log_step(
                "auto_fix",
                f"Auto-fixing issues (dry_run: {dry_run})",
                success=True,
                details={"fixed_count": fixed_count},
            )
            if fixed_count > 0 and not dry_run:
                click.secho(
                    "\n💡 Tip: Run 'telegram-bot-stack doctor' again to verify fixes",
                    fg="cyan",
                )
        except Exception as e:
            log_step(
                "auto_fix",
                f"Auto-fixing issues (dry_run: {dry_run})",
                success=False,
                error=e,
            )
            raise

    success = not report.has_errors
    if not success:
        error = ValueError(
            f"Health checks found {len(report.errors)} error(s) and {len(report.warnings)} warning(s)"
        )

    # Exit with error if strict mode and there are issues
    if strict and (report.has_errors or len(report.warnings) > 0):
        duration = time.time() - start_time
        log_command_end(
            command_name="doctor",
            success=success,
            duration_seconds=duration,
            result={
                "errors_count": len(report.errors),
                "warnings_count": len(report.warnings),
                "has_errors": report.has_errors,
            },
            error=error,
        )
        sys.exit(1)

    # Exit with error if there are critical errors (even without strict)
    if report.has_errors:
        duration = time.time() - start_time
        log_command_end(
            command_name="doctor",
            success=success,
            duration_seconds=duration,
            result={
                "errors_count": len(report.errors),
                "warnings_count": len(report.warnings),
                "has_errors": report.has_errors,
            },
            error=error,
        )
        sys.exit(1)

    duration = time.time() - start_time
    log_command_end(
        command_name="doctor",
        success=success,
        duration_seconds=duration,
        result={
            "errors_count": len(report.errors),
            "warnings_count": len(report.warnings),
            "has_errors": report.has_errors,
        },
        error=error,
    )
