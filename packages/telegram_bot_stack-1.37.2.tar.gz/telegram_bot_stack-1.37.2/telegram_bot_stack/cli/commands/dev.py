"""Run bot in development mode with auto-reload."""

import os
import queue
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Any, Optional

import click

from telegram_bot_stack.cli.utils import venv
from telegram_bot_stack.cli.utils.bot_lock import BotLockManager
from telegram_bot_stack.cli.utils.venv import find_venv, get_venv_python
from telegram_bot_stack.logging import (
    get_logger,
    log_command_end,
    log_command_start,
    log_file_operation,
    log_step,
    log_subprocess_command,
)


@click.command()
@click.option(
    "--reload/--no-reload",
    default=True,
    help="Auto-reload on code changes",
)
@click.option(
    "--bot-file",
    default="bot.py",
    help="Bot file to run (default: bot.py)",
)
@click.option(
    "--force",
    is_flag=True,
    help="Force start even if another instance is running",
)
def dev(reload: bool, bot_file: str, force: bool) -> None:
    """Run bot in development mode with auto-reload.

    Features:
    - Auto-reload on code changes (with --reload)
    - Pretty logging
    - Debug mode

    Example:

        telegram-bot-stack dev --reload

        telegram-bot-stack dev --bot-file my_bot.py
    """
    start_time = time.time()
    logger = get_logger()

    # Log command start
    log_command_start(
        command_name="dev",
        parameters={"reload": reload, "bot_file": bot_file, "force": force},
    )

    success = False
    error: Optional[Exception] = None
    bot_path = Path.cwd() / bot_file

    log_step("check_bot_file", f"Checking if bot file exists: {bot_file}")
    if not bot_path.exists():
        error = FileNotFoundError(f"Bot file not found: {bot_file}")
        log_file_operation("read", bot_path, success=False, error=error)
        log_step(
            "check_bot_file",
            f"Checking if bot file exists: {bot_file}",
            success=False,
            error=error,
        )
        click.secho(f"❌ Error: Bot file not found: {bot_file}", fg="red")
        click.echo("\nMake sure you're in the project directory and bot.py exists.")
        sys.exit(1)
    log_file_operation("read", bot_path, success=True)
    log_step("check_bot_file", f"Checking if bot file exists: {bot_file}", success=True)

    # Check for bot lock (prevent multiple instances)
    log_step("acquire_lock", "Acquiring bot lock to prevent multiple instances")
    lock_manager = BotLockManager(Path.cwd())
    if not lock_manager.acquire_lock(force=force):
        log_step(
            "acquire_lock",
            "Acquiring bot lock to prevent multiple instances",
            success=False,
        )
        sys.exit(1)
    log_step(
        "acquire_lock", "Acquiring bot lock to prevent multiple instances", success=True
    )

    # Find and use venv if available
    log_step("find_venv", "Looking for virtual environment")
    venv_path = find_venv()
    python_executable = sys.executable

    if venv_path:
        venv_python = get_venv_python(venv_path)
        if venv_python.exists():
            python_executable = str(venv_python)
            log_step(
                "find_venv",
                "Looking for virtual environment",
                success=True,
                details={"venv_path": str(venv_path)},
            )
            click.echo(f"📦 Using virtual environment: {venv_path}\n")
        else:
            log_step(
                "find_venv",
                "Looking for virtual environment",
                success=False,
                details={"warning": "venv found but Python executable not found"},
            )
            click.secho(
                "⚠️  Warning: venv found but Python executable not found", fg="yellow"
            )
    else:
        log_step(
            "find_venv",
            "Looking for virtual environment",
            success=False,
            details={"warning": "No virtual environment found"},
        )
        click.secho(
            "⚠️  Warning: No virtual environment found. Using system Python.",
            fg="yellow",
        )
        click.echo("  Consider running: python -m venv venv\n")

    # Check for .env file
    log_step("check_env", "Checking for .env file")
    env_file = Path.cwd() / ".env"
    if not env_file.exists():
        log_file_operation("read", env_file, success=False)
        log_step(
            "check_env",
            "Checking for .env file",
            success=False,
            details={"warning": ".env file not found"},
        )
        click.secho("⚠️  Warning: .env file not found", fg="yellow")
        click.echo("Create .env with your BOT_TOKEN:")
        click.echo('  echo "BOT_TOKEN=your_token_here" > .env\n')
    else:
        log_file_operation("read", env_file, success=True)
        log_step("check_env", "Checking for .env file", success=True)

    # Check if telegram-bot-stack is installed
    log_step("check_dependencies", "Checking if telegram-bot-stack is installed")
    try:
        import telegram_bot_stack

        _ = telegram_bot_stack  # Mark as used
        log_step(
            "check_dependencies",
            "Checking if telegram-bot-stack is installed",
            success=True,
        )
    except ImportError:
        error = ImportError("telegram-bot-stack is not installed")
        log_step(
            "check_dependencies",
            "Checking if telegram-bot-stack is installed",
            success=False,
            error=error,
        )
        click.secho("❌ Error: telegram-bot-stack is not installed", fg="red")
        click.echo("\nInstall dependencies:")
        if venv_path:
            click.echo(f"  {venv.get_activation_command(venv_path)}")
            click.echo("  pip install -e .[dev]")
        else:
            click.echo("  pip install -e .[dev]")
        sys.exit(1)

    try:
        if reload:
            log_step("start_bot", "Starting bot with auto-reload")
            try:
                # Use watchdog for auto-reload
                _run_with_reload(bot_path, python_executable)
                log_step("start_bot", "Starting bot with auto-reload", success=True)
                success = True
            except ImportError:
                log_step(
                    "start_bot",
                    "Starting bot with auto-reload",
                    success=False,
                    details={
                        "warning": "watchdog not installed, running without auto-reload"
                    },
                )
                click.secho(
                    "⚠️  Warning: watchdog not installed, running without auto-reload",
                    fg="yellow",
                )
                _run_bot(bot_path, python_executable)
                success = True
        else:
            log_step("start_bot", "Starting bot without auto-reload")
            click.secho("🤖 Starting bot...\n", fg="cyan")
            _run_bot(bot_path, python_executable)
            log_step("start_bot", "Starting bot without auto-reload", success=True)
            success = True
    except KeyboardInterrupt:
        log_step("stop_bot", "Bot stopped by user (KeyboardInterrupt)", success=True)
        success = True
    except Exception as e:
        error = e
        logger.error(f"Dev command failed: {e}", exc_info=True)
        raise
    finally:
        # Always release lock on exit
        lock_manager.release_lock()
        duration = time.time() - start_time
        log_command_end(
            command_name="dev",
            success=success,
            duration_seconds=duration,
            error=error,
        )


def _run_bot(bot_path: Path, python_executable: Optional[str] = None) -> None:
    """Run the bot without auto-reload.

    Args:
        bot_path: Path to the bot file
        python_executable: Python executable to use (defaults to sys.executable)
    """
    if python_executable is None:
        python_executable = sys.executable

    try:
        import time as time_module

        start = time_module.time()
        result = subprocess.run([python_executable, str(bot_path)], check=True)
        duration = time_module.time() - start
        log_subprocess_command(
            command=[python_executable, str(bot_path)],
            success=True,
            returncode=result.returncode,
            duration=duration,
        )
    except KeyboardInterrupt:
        click.echo("\n\n👋 Bot stopped")
    except subprocess.CalledProcessError as e:
        log_subprocess_command(
            command=[python_executable, str(bot_path)],
            success=False,
            returncode=e.returncode,
            error=e,
        )
        click.secho(f"\n❌ Bot exited with error code {e.returncode}", fg="red")
        sys.exit(e.returncode)


def _run_with_reload(bot_path: Path, python_executable: Optional[str] = None) -> None:
    """Run the bot with auto-reload using watchdog.

    Args:
        bot_path: Path to the bot file
        python_executable: Python executable to use (defaults to sys.executable)
    """
    if python_executable is None:
        python_executable = sys.executable

    try:
        from watchdog.events import FileSystemEventHandler
        from watchdog.observers import Observer
    except ImportError:
        raise ImportError(
            "watchdog is required for auto-reload. "
            "Install it with: pip install watchdog"
        )

    process = None
    restart_requested = False

    class BotReloadHandler(FileSystemEventHandler):
        """Handler for file changes."""

        def on_modified(self, event: Any) -> None:
            """Handle file modification."""
            nonlocal restart_requested

            # Only reload on .py file changes
            if event.src_path.endswith(".py"):
                restart_requested = True

    def start_bot() -> Any:
        """Start the bot process."""
        env = os.environ.copy()
        env["PYTHONUNBUFFERED"] = "1"
        return subprocess.Popen(
            [python_executable, "-u", str(bot_path)],  # -u for unbuffered output
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=0,  # Unbuffered
            env=env,
        )

    # Start initial bot process
    click.secho("🤖 Starting bot...\n", fg="cyan")
    process = start_bot()

    # Setup file watcher
    event_handler = BotReloadHandler()
    observer = Observer()
    observer.schedule(event_handler, path=str(bot_path.parent), recursive=True)
    observer.start()

    # Start reading bot output in background
    # Use queue for thread-safe communication
    output_queue: queue.Queue[str] = queue.Queue(maxsize=1000)
    output_stopped = threading.Event()
    output_lock = threading.Lock()

    def read_output() -> None:
        """Read and display bot output."""
        try:
            while True:
                if process is None or process.stdout is None:
                    break
                line = process.stdout.readline()
                if not line:
                    if process.poll() is not None:
                        break
                    time.sleep(0.001)  # Minimal sleep
                    continue
                # Put line in queue (blocking to ensure it's queued)
                line_stripped = line.rstrip()
                if line_stripped:  # Only queue non-empty lines
                    try:
                        output_queue.put(line_stripped, timeout=0.1)
                    except queue.Full:
                        # If queue is full, try to display directly (fallback)
                        with output_lock:
                            click.echo(line_stripped, nl=True)
                            sys.stdout.flush()
        except Exception as e:
            click.echo(f"Error reading output: {e}", err=True)
        finally:
            output_stopped.set()

    output_thread = threading.Thread(target=read_output, daemon=True)
    output_thread.start()

    # Give thread a moment to start reading
    time.sleep(0.05)

    try:
        while True:
            # Display any available output (non-blocking)
            displayed_any = False
            try:
                # Use timeout to avoid blocking too long
                while True:
                    try:
                        line = output_queue.get_nowait()
                        click.echo(line, nl=True)
                        sys.stdout.flush()
                        displayed_any = True
                    except queue.Empty:
                        break
            except Exception:
                pass

            # Check if process is still running
            exit_code = process.poll()
            if exit_code is not None:
                click.secho("\n⚠️  Bot process exited", fg="yellow")
                # Wait a bit for remaining output
                output_stopped.wait(timeout=2.0)
                # Read all remaining output from queue
                try:
                    while True:
                        line = output_queue.get_nowait()
                        click.echo(line, nl=True)
                        sys.stdout.flush()
                except queue.Empty:
                    pass
                # Also try to read any remaining output directly
                try:
                    remaining = process.stdout.read()
                    if remaining:
                        click.echo(remaining, nl=False)
                        sys.stdout.flush()
                except Exception:
                    pass
                if exit_code != 0:
                    click.secho(f"Exit code: {exit_code}", fg="red")
                break

            # Smaller sleep for better responsiveness
            time.sleep(0.02 if displayed_any else 0.05)

            # Check if restart requested
            if restart_requested:
                click.echo("")  # Empty line for separation
                process.terminate()
                process.wait(timeout=5)
                click.secho("🤖 Updating bot...\n", fg="cyan")
                process = start_bot()
                restart_requested = False
                # Restart output thread
                output_stopped.clear()
                output_thread = threading.Thread(target=read_output, daemon=True)
                output_thread.start()
                time.sleep(0.05)

            time.sleep(0.5)

    except KeyboardInterrupt:
        click.echo("\n\n👋 Stopping bot...")
        if process:
            process.terminate()
            process.wait(timeout=5)
    finally:
        observer.stop()
        observer.join()
