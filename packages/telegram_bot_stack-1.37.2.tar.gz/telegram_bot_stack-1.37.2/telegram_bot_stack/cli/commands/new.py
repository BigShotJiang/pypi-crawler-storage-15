"""Create a new bot from template."""

import shutil
import sys
import time
from pathlib import Path
from typing import Optional

import click

from telegram_bot_stack.logging import (
    get_logger,
    log_command_end,
    log_command_start,
    log_file_operation,
    log_step,
)


@click.command()
@click.argument("name")
@click.option(
    "--template",
    type=click.Choice(["basic", "counter", "menu", "advanced"]),
    default="basic",
    help="Bot template to use (default: basic)",
)
def new(name: str, template: str) -> None:
    """Create a new bot from a template.

    Available templates:
    - basic: Simple echo bot
    - counter: Bot with state management
    - menu: Bot with interactive menus
    - advanced: Full-featured bot with all best practices

    Example:

        telegram-bot-stack new my-bot --template counter
    """
    start_time = time.time()
    logger = get_logger()

    # Log command start
    log_command_start(
        command_name="new",
        parameters={"name": name, "template": template},
    )

    success = False
    error: Optional[Exception] = None
    project_path = Path.cwd() / name

    # Check if project already exists
    if project_path.exists():
        error = ValueError(f"Directory '{name}' already exists")
        log_step(
            "check_existing",
            f"Checking if project '{name}' exists",
            success=False,
            error=error,
        )
        click.secho(f"❌ Error: Directory '{name}' already exists", fg="red")
        sys.exit(1)

    click.secho(f"\n🚀 Creating bot from template: {template}\n", fg="cyan", bold=True)

    # Get template directory
    cli_dir = Path(__file__).parent.parent
    template_dir = cli_dir / "templates" / template

    log_step("find_template", f"Looking for template: {template}")
    if not template_dir.exists():
        error = FileNotFoundError(f"Template '{template}' not found at {template_dir}")
        log_step(
            "find_template",
            f"Looking for template: {template}",
            success=False,
            error=error,
        )
        click.secho(
            f"❌ Error: Template '{template}' not found at {template_dir}",
            fg="red",
        )
        sys.exit(1)
    log_step(
        "find_template",
        f"Looking for template: {template}",
        success=True,
        details={"template_dir": str(template_dir)},
    )

    try:
        # Copy template
        log_step(
            "copy_template",
            f"Copying template files from {template_dir} to {project_path}",
        )
        try:
            shutil.copytree(template_dir, project_path)
            log_file_operation(
                "copy_directory",
                template_dir,
                success=True,
                details={"destination": str(project_path)},
            )
            log_step(
                "copy_template",
                f"Copying template files from {template_dir} to {project_path}",
                success=True,
            )
            click.secho(f"✅ Created project from template: {template}", fg="green")
        except Exception as e:
            log_file_operation(
                "copy_directory",
                template_dir,
                success=False,
                error=e,
                details={"destination": str(project_path)},
            )
            log_step(
                "copy_template",
                f"Copying template files from {template_dir} to {project_path}",
                success=False,
                error=e,
            )
            raise

        # Success message
        click.secho("\n" + "=" * 70, fg="green")
        click.secho("🎉 Success! Your bot project is ready!", fg="green", bold=True)
        click.secho("=" * 70 + "\n", fg="green")

        click.echo("📋 Next steps:\n")
        click.secho(f"  1. cd {name}", fg="cyan")
        click.secho("  2. Read README.md for setup instructions", fg="cyan")
        click.secho('  3. echo "BOT_TOKEN=your_token_here" > .env', fg="cyan")
        click.secho("  4. python bot.py", fg="cyan")

        click.echo(
            "\n💡 Tip: Use 'telegram-bot-stack init' for full dev environment setup\n"
        )

        success = True

    except Exception as e:
        error = e
        logger.error(f"New command failed: {e}", exc_info=True)
        click.secho(f"\n❌ Error creating project: {e}", fg="red")
        if project_path.exists():
            shutil.rmtree(project_path)
        sys.exit(1)
    finally:
        duration = time.time() - start_time
        log_command_end(
            command_name="new",
            success=success,
            duration_seconds=duration,
            result={
                "project_path": str(project_path) if project_path.exists() else None
            },
            error=error,
        )
