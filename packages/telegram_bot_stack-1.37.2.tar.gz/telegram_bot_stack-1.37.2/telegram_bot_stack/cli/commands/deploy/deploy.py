"""Core deployment commands (init, backup, restore)."""

import shutil
import time
from pathlib import Path

import click
from rich.console import Console
from rich.prompt import Confirm, Prompt
from rich.table import Table

from telegram_bot_stack.cli.utils.backup import BackupManager
from telegram_bot_stack.cli.utils.deployment import (
    DeploymentConfig,
    create_vps_connection_from_config,
)
from telegram_bot_stack.cli.utils.secrets import SecretsManager
from telegram_bot_stack.cli.utils.vps import (
    VPSConnection,
    check_ssh_agent,
    find_ssh_keys,
    setup_ssh_key_interactive,
)
from telegram_bot_stack.logging import (
    get_logger,
    log_command_end,
    log_command_start,
    log_deployment_operation,
    log_file_operation,
    log_step,
)

console = Console()


@click.group()
def deploy() -> None:
    """Deploy bot to VPS (production deployment)."""
    pass


@deploy.command()
@click.option("--host", help="VPS hostname or IP address")
@click.option("--user", default="root", help="SSH user (default: root)")
@click.option("--ssh-key", help="Path to SSH private key")
@click.option("--password", help="SSH password (for password authentication)")
@click.option("--port", default=22, help="SSH port (default: 22)")
@click.option("--bot-name", help="Bot name (for container/image names)")
@click.option("--bot-token-env", default="BOT_TOKEN", help="Bot token env var name")
@click.option(
    "--auth-method",
    type=click.Choice(["auto", "key", "password", "agent"]),
    default="auto",
    help="SSH authentication method",
)
def init(
    host: str,
    user: str,
    ssh_key: str,
    password: str,
    port: int,
    bot_name: str,
    bot_token_env: str,
    auth_method: str,
) -> None:
    """Initialize deployment configuration (interactive setup)."""
    start_time = time.time()
    get_logger()  # Initialize logger

    # Log command start
    log_command_start(
        command_name="deploy_init",
        parameters={
            "host": host,
            "user": user,
            "ssh_key": "***REDACTED***" if ssh_key else None,
            "password": "***REDACTED***" if password else None,
            "port": port,
            "bot_name": bot_name,
            "bot_token_env": bot_token_env,
            "auth_method": auth_method,
        },
    )

    success = False
    error = None

    console.print("🚀 [bold cyan]VPS Deployment Setup[/bold cyan]\n")

    # Check if deploy.yaml already exists
    deploy_yaml = Path("deploy.yaml")
    log_step("check_existing_config", "Checking if deploy.yaml already exists")
    if deploy_yaml.exists():
        log_file_operation("read", deploy_yaml, success=True)
        if not Confirm.ask(
            "[yellow]deploy.yaml already exists. Overwrite?[/yellow]", default=False
        ):
            log_step(
                "check_existing_config",
                "Checking if deploy.yaml already exists",
                success=False,
                details={"cancelled": True},
            )
            console.print("[yellow]Setup cancelled[/yellow]")
            return
    else:
        log_file_operation("read", deploy_yaml, success=False)
    log_step(
        "check_existing_config", "Checking if deploy.yaml already exists", success=True
    )

    # Interactive prompts if values not provided
    if not host:
        host = Prompt.ask("VPS Host (hostname or IP)")

    if not user:
        user = Prompt.ask("SSH User", default="root")

    # Auto-detect SSH keys or prompt
    if not ssh_key and auth_method in ["auto", "key"]:
        # Try to find SSH keys
        found_keys = find_ssh_keys()

        if found_keys:
            console.print("\n[cyan]Found SSH keys:[/cyan]")
            for i, key in enumerate(found_keys, 1):
                console.print(f"  {i}. {key}")

            # Check if SSH agent has keys
            if check_ssh_agent():
                console.print("  [green]✓ SSH agent is running with keys[/green]")

            # Use first found key as default
            default_key = str(found_keys[0])
            ssh_key = Prompt.ask(
                "\nSSH Key Path (or press Enter to use first found key)",
                default=default_key,
            )
        else:
            console.print("\n[yellow]No SSH keys found in ~/.ssh/[/yellow]")

            if check_ssh_agent():
                console.print(
                    "[green]✓ SSH agent is running - will use agent "
                    "authentication[/green]"
                )
                ssh_key = ""  # Will use agent
            else:
                # Offer to generate SSH key automatically
                console.print(
                    "\n[yellow]SSH key authentication is recommended for "
                    "security[/yellow]"
                )
                generate_key = Confirm.ask(
                    "Would you like to generate an SSH key now?",
                    default=True,
                )

                if generate_key:
                    # Interactive SSH key setup
                    success, generated_key_path = setup_ssh_key_interactive(
                        host=host,
                        user=user,
                        port=port,
                    )

                    if success and generated_key_path:
                        ssh_key = generated_key_path
                        console.print(
                            f"\n[green]✓ SSH key setup complete: {ssh_key}[/green]"
                        )
                    else:
                        console.print(
                            "\n[yellow]SSH key setup failed. You can configure it "
                            "later.[/yellow]"
                        )
                        ssh_key = Prompt.ask(
                            "SSH Key Path (or leave empty for password auth)",
                            default="",
                        )
                else:
                    console.print(
                        "[dim]Tip: You can generate an SSH key later with: "
                        "ssh-keygen -t ed25519[/dim]"
                    )
                    ssh_key = Prompt.ask(
                        "SSH Key Path (or leave empty for password auth)", default=""
                    )

    # If still no ssh_key and not using agent, prompt
    if not ssh_key and auth_method == "key":
        ssh_key = Prompt.ask("SSH Key Path")

    # Handle password authentication
    if auth_method == "password" and not password:
        # Import getpass for secure password input
        import getpass

        console.print("\n[yellow]Password authentication selected[/yellow]")
        password = getpass.getpass("VPS Password: ")

    if not bot_name:
        # Try to detect bot name from current directory
        default_name = Path.cwd().name
        bot_name = Prompt.ask("Bot Name", default=default_name)

    # Test SSH connection
    console.print("\n[cyan]Testing SSH connection...[/cyan]")
    log_step(
        "test_ssh_connection", f"Testing SSH connection to {host}:{port} as {user}"
    )
    vps = VPSConnection(
        host=host,
        user=user,
        ssh_key=ssh_key if ssh_key else None,
        password=password if password else None,
        port=port,
        auth_method=auth_method,
    )

    try:
        if not vps.test_connection():
            error = ConnectionError(f"SSH connection failed to {host}:{port}")
            log_step(
                "test_ssh_connection",
                f"Testing SSH connection to {host}:{port} as {user}",
                success=False,
                error=error,
            )
            console.print("[red]❌ SSH connection failed[/red]")
            console.print(
                "\n[yellow]Please check your VPS details and "
                "SSH key permissions[/yellow]"
            )
            return

        log_step(
            "test_ssh_connection",
            f"Testing SSH connection to {host}:{port} as {user}",
            success=True,
        )
        console.print("[green]✓ SSH connection successful[/green]")
    finally:
        # Always close VPS connection
        vps.close()

    # Create deployment configuration
    log_step("create_config", "Creating deployment configuration")
    try:
        config = DeploymentConfig("deploy.yaml")
        config.set("vps.host", host)
        config.set("vps.user", user)
        config.set("vps.ssh_key", ssh_key if ssh_key else "")
        config.set("vps.port", port)
        config.set("vps.auth_method", auth_method)
        config.set("bot.name", bot_name)
        config.set("bot.token_env", bot_token_env)
        config.set("bot.entry_point", "bot.py")
        config.set("bot.python_version", "3.11")
        config.set("deployment.method", "docker")
        config.set("deployment.auto_restart", True)
        config.set("deployment.log_rotation", True)
        config.set("resources.memory_limit", "256M")
        config.set("resources.memory_reservation", "128M")
        config.set("resources.cpu_limit", "0.5")
        config.set("resources.cpu_reservation", "0.25")
        config.set("logging.level", "INFO")
        config.set("logging.max_size", "5m")
        config.set("logging.max_files", "5")
        config.set("environment.timezone", "UTC")

        # Generate encryption key for secrets management
        log_step(
            "generate_encryption_key",
            "Generating encryption key for secrets management",
        )
        encryption_key = SecretsManager.generate_key()
        config.set("secrets.encryption_key", encryption_key)
        log_step(
            "generate_encryption_key",
            "Generating encryption key for secrets management",
            success=True,
        )

        # Backup configuration
        config.set("backup.enabled", True)
        config.set("backup.auto_backup_before_update", True)
        config.set("backup.auto_backup_before_cleanup", True)
        config.set("backup.retention_days", 7)
        config.set("backup.max_backups", 10)

        config.save()
        log_file_operation("write", deploy_yaml, success=True)
        log_step("create_config", "Creating deployment configuration", success=True)
        console.print("\n[green]✓ Configuration saved to deploy.yaml[/green]")
    except Exception as e:
        log_file_operation("write", deploy_yaml, success=False, error=e)
        log_step(
            "create_config", "Creating deployment configuration", success=False, error=e
        )
        raise

    # Copy example deploy.yaml for reference
    templates_dir = Path(__file__).parent.parent.parent / "templates" / "docker"
    example_file = templates_dir / "deploy.yaml.example"
    if example_file.exists():
        shutil.copy(example_file, "deploy.yaml.example")
        console.print("[dim]ℹ️  deploy.yaml.example copied for reference[/dim]")

    console.print("\n[green]✅ Configuration saved to deploy.yaml[/green]")
    console.print("[green]✅ Encryption key generated for secrets management[/green]")
    console.print("\n[bold]Next steps:[/bold]")
    console.print("1. Review deploy.yaml and adjust settings if needed")
    console.print(
        "2. Set secrets on VPS: [cyan]telegram-bot-stack deploy "
        "secrets set-secret BOT_TOKEN 'your-token'[/cyan]"
    )
    console.print("3. Run: [cyan]telegram-bot-stack deploy up[/cyan]")
    console.print("\n[dim]See deploy.yaml.example for all available options[/dim]")
    console.print(
        "[yellow]⚠️  Keep deploy.yaml secure - it contains your encryption key![/yellow]"
    )

    success = True
    duration = time.time() - start_time
    log_deployment_operation(
        operation="init",
        deployment_method="docker",
        bot_name=bot_name,
        vps_host=host,
        success=success,
        details={"port": port, "user": user, "auth_method": auth_method},
    )
    log_command_end(
        command_name="deploy_init",
        success=success,
        duration_seconds=duration,
        result={"config_file": "deploy.yaml", "bot_name": bot_name, "vps_host": host},
        error=error,
    )


@deploy.group(invoke_without_command=True)
@click.pass_context
@click.option("--config", default="deploy.yaml", help="Deployment config file")
def backup(ctx: click.Context, config: str) -> None:
    """Manage bot backups (data safety)."""
    # If no subcommand provided, create backup
    if ctx.invoked_subcommand is None:
        ctx.forward(create_backup)


@backup.command("create")
@click.option("--config", default="deploy.yaml", help="Deployment config file")
def create_backup(config: str) -> None:
    """Create a backup of bot data.

    Example:
        telegram-bot-stack deploy backup
    """
    # Load configuration
    if not Path(config).exists():
        console.print(f"[red]❌ Configuration file not found: {config}[/red]")
        console.print("\n[yellow]Run 'telegram-bot-stack deploy init' first[/yellow]")
        return

    deploy_config = DeploymentConfig(config)

    if not deploy_config.validate():
        console.print("[red]❌ Invalid configuration[/red]")
        return

    # Connect to VPS
    vps = create_vps_connection_from_config(deploy_config)

    try:
        if not vps.test_connection():
            console.print("[red]❌ Failed to connect to VPS[/red]")
            return

        bot_name = deploy_config.get("bot.name")
        remote_dir = f"/opt/{bot_name}"

        # Create backup
        backup_manager = BackupManager(bot_name, remote_dir)
        backup_filename = backup_manager.create_backup(vps, auto_backup=False)

        if backup_filename:
            # Cleanup old backups
            retention_days = deploy_config.get("backup.retention_days", 7)
            max_backups = deploy_config.get("backup.max_backups", 10)
            deleted = backup_manager.cleanup_old_backups(
                vps, retention_days=retention_days, max_backups=max_backups
            )
            if deleted > 0:
                console.print(f"[dim]   Cleaned up {deleted} old backup(s)[/dim]")

    finally:
        vps.close()


@backup.command("list")
@click.option("--config", default="deploy.yaml", help="Deployment config file")
def list_backups(config: str) -> None:
    """List all available backups.

    Example:
        telegram-bot-stack deploy backup list
    """
    # Load configuration
    if not Path(config).exists():
        console.print(f"[red]❌ Configuration file not found: {config}[/red]")
        return

    deploy_config = DeploymentConfig(config)

    # Connect to VPS
    vps = create_vps_connection_from_config(deploy_config)

    try:
        bot_name = deploy_config.get("bot.name")
        remote_dir = f"/opt/{bot_name}"

        # List backups
        backup_manager = BackupManager(bot_name, remote_dir)
        backups = backup_manager.list_backups(vps)

        if backups:
            console.print("📦 [bold cyan]Available Backups[/bold cyan]\n")

            table = Table(show_header=True, header_style="bold cyan")
            table.add_column("Filename")
            table.add_column("Size")
            table.add_column("Date")

            for backup in backups:
                date_str = (
                    backup["date"].strftime("%Y-%m-%d %H:%M:%S")
                    if backup["date"]
                    else "Unknown"
                )
                table.add_row(backup["filename"], backup["size"], date_str)

            console.print(table)
        else:
            console.print("[yellow]No backups found[/yellow]")

    finally:
        vps.close()


@backup.command()
@click.option("--config", default="deploy.yaml", help="Deployment config file")
@click.argument("backup_filename")
@click.option("--output", "-o", default=".", help="Local directory to save backup")
def download(config: str, backup_filename: str, output: str) -> None:
    """Download backup from VPS to local machine.

    Example:
        telegram-bot-stack deploy backup download backup-20250126-143022.tar.gz
    """
    # Load configuration
    if not Path(config).exists():
        console.print(f"[red]❌ Configuration file not found: {config}[/red]")
        return

    deploy_config = DeploymentConfig(config)

    # Connect to VPS
    vps = create_vps_connection_from_config(deploy_config)

    try:
        if not vps.test_connection():
            console.print("[red]❌ Failed to connect to VPS[/red]")
            return

        bot_name = deploy_config.get("bot.name")
        remote_dir = f"/opt/{bot_name}"

        # Download backup
        backup_manager = BackupManager(bot_name, remote_dir)
        backup_manager.download_backup(vps, backup_filename, Path(output))

    finally:
        vps.close()


@deploy.command()
@click.option("--config", default="deploy.yaml", help="Deployment config file")
@click.argument("backup_filename")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt")
def restore(config: str, backup_filename: str, yes: bool) -> None:
    """Restore bot data from backup.

    Example:
        telegram-bot-stack deploy restore backup-20250126-143022.tar.gz
    """
    # Load configuration
    if not Path(config).exists():
        console.print(f"[red]❌ Configuration file not found: {config}[/red]")
        return

    deploy_config = DeploymentConfig(config)

    # Connect to VPS
    vps = create_vps_connection_from_config(deploy_config)

    try:
        if not vps.test_connection():
            console.print("[red]❌ Failed to connect to VPS[/red]")
            return

        bot_name = deploy_config.get("bot.name")
        remote_dir = f"/opt/{bot_name}"

        # Restore backup
        backup_manager = BackupManager(bot_name, remote_dir)
        backup_manager.restore_backup(vps, backup_filename, confirm=not yes)

    finally:
        vps.close()


@deploy.command("list")
@click.option("--config", default="deploy.yaml", help="Deployment config file")
@click.option(
    "--remote", is_flag=True, help="List all bots on remote VPS (not just current bot)"
)
def list_bots(config: str, remote: bool) -> None:
    """List deployed bots.

    Examples:
        # List current bot status
        telegram-bot-stack deploy list

        # List all bots on VPS
        telegram-bot-stack deploy list --remote
    """

    # Load configuration
    if not Path(config).exists():
        console.print(f"[red]❌ Configuration file not found: {config}[/red]")
        console.print("\n[yellow]Run 'telegram-bot-stack deploy init' first[/yellow]")
        return

    deploy_config = DeploymentConfig(config)

    if not deploy_config.validate():
        console.print("[red]❌ Invalid configuration[/red]")
        return

    # Connect to VPS
    vps = create_vps_connection_from_config(deploy_config)

    try:
        if not vps.test_connection():
            console.print("[red]❌ Failed to connect to VPS[/red]")
            return

        if remote:
            # List all bots on VPS (discover by scanning /opt/ directory)
            _list_all_bots_on_vps(vps, deploy_config)
        else:
            # List only current bot
            bot_name = deploy_config.get("bot.name")
            _list_current_bot(vps, deploy_config, bot_name)

    finally:
        vps.close()


def _list_current_bot(
    vps: VPSConnection, deploy_config: DeploymentConfig, bot_name: str
) -> None:
    """List information about the current bot."""
    from telegram_bot_stack.cli.utils.vps import (
        get_container_health,
    )

    remote_dir = f"/opt/{bot_name}"

    console.print(f"🤖 [bold cyan]Bot: {bot_name}[/bold cyan]\n")

    # Check if bot directory exists
    dir_exists = vps.run_command(f"test -d {remote_dir}", hide=True)
    if not dir_exists:
        console.print("[yellow]⚠️  Bot not deployed on VPS[/yellow]")
        console.print(f"[dim]   Directory {remote_dir} does not exist[/dim]")
        return

    deployment_method = deploy_config.get("deployment.method", "docker")

    if deployment_method == "docker":
        # Get container health
        conn = vps.connect()
        health_info = get_container_health(conn, bot_name)

        # Display status
        table = Table(show_header=True, header_style="bold cyan")
        table.add_column("Property", style="cyan")
        table.add_column("Value")

        table.add_row("Name", bot_name)
        table.add_row("Directory", remote_dir)
        table.add_row("Status", _format_container_status(health_info["status"]))

        if health_info["status"] == "running":
            table.add_row("Health", health_info.get("health", "N/A"))
            table.add_row("Uptime", health_info.get("uptime", "N/A"))
            table.add_row("Restarts", str(health_info.get("restart_count", 0)))
        elif health_info["status"] == "stopped":
            table.add_row("Exit Code", str(health_info.get("exit_code", "N/A")))

        console.print(table)

    elif deployment_method == "systemd":
        # Check systemd service status
        conn = vps.connect()
        result = conn.run(
            f"systemctl is-active {bot_name}",
            hide=True,
            warn=True,
            pty=False,
            in_stream=False,
        )
        status = result.stdout.strip() if result and result.stdout else "unknown"

        table = Table(show_header=True, header_style="bold cyan")
        table.add_column("Property", style="cyan")
        table.add_column("Value")

        table.add_row("Name", bot_name)
        table.add_row("Directory", remote_dir)
        table.add_row("Status", _format_systemd_status(status))

        console.print(table)


def _list_all_bots_on_vps(vps: VPSConnection, deploy_config: DeploymentConfig) -> None:
    """List all deployed bots on the VPS."""
    from telegram_bot_stack.cli.utils.vps import get_container_health

    console.print("🤖 [bold cyan]All Deployed Bots on VPS[/bold cyan]\n")

    deployment_method = deploy_config.get("deployment.method", "docker")
    conn = vps.connect()

    if deployment_method == "docker":
        # Find all bot directories in /opt/
        result = conn.run(
            "find /opt -maxdepth 1 -type d -name '*' | grep -v '^/opt$' || true",
            hide=True,
            warn=True,
            pty=False,
            in_stream=False,
        )

        if not result or not result.stdout.strip():
            console.print("[yellow]No bots found on VPS[/yellow]")
            return

        bot_dirs = [d.strip() for d in result.stdout.strip().split("\n") if d.strip()]

        # Filter directories that have docker-compose.yml (actual bot deployments)
        bots = []
        for bot_dir in bot_dirs:
            compose_check = conn.run(
                f"test -f {bot_dir}/docker-compose.yml",
                hide=True,
                warn=True,
                pty=False,
                in_stream=False,
            )
            if compose_check and compose_check.ok:
                bot_name = bot_dir.split("/")[-1]
                bots.append((bot_name, bot_dir))

        if not bots:
            console.print("[yellow]No bots found on VPS[/yellow]")
            console.print(
                "[dim]   (Bots should be deployed to /opt/<bot-name>/ "
                "with docker-compose.yml)[/dim]"
            )
            return

        # Display table of all bots
        table = Table(show_header=True, header_style="bold cyan")
        table.add_column("Bot Name", style="cyan")
        table.add_column("Directory")
        table.add_column("Status")
        table.add_column("Health")
        table.add_column("Uptime")

        for bot_name, bot_dir in sorted(bots):
            health_info = get_container_health(conn, bot_name)

            status = _format_container_status(health_info["status"])
            health = (
                health_info.get("health", "N/A")
                if health_info["status"] == "running"
                else "-"
            )
            uptime = (
                health_info.get("uptime", "N/A")
                if health_info["status"] == "running"
                else "-"
            )

            table.add_row(bot_name, bot_dir, status, health, uptime)

        console.print(table)
        console.print(f"\n[dim]Found {len(bots)} bot(s)[/dim]")

    elif deployment_method == "systemd":
        # List all systemd services matching pattern
        cmd = (
            "systemctl list-units --all --type=service --no-pager | "
            "grep -E '\\.service' | awk '{print $1}' || true"
        )
        result = conn.run(
            cmd,
            hide=True,
            warn=True,
            pty=False,
            in_stream=False,
        )

        if not result or not result.stdout.strip():
            console.print("[yellow]No bot services found[/yellow]")
            return

        # Filter services that are likely bots (have corresponding /opt/ directory)
        services = result.stdout.strip().split("\n")
        bots = []

        for service in services:
            service_name = service.replace(".service", "").strip()
            bot_dir = f"/opt/{service_name}"
            dir_check = conn.run(
                f"test -d {bot_dir}",
                hide=True,
                warn=True,
                pty=False,
                in_stream=False,
            )
            if dir_check and dir_check.ok:
                bots.append((service_name, bot_dir))

        if not bots:
            console.print("[yellow]No bots found on VPS[/yellow]")
            return

        # Display table
        table = Table(show_header=True, header_style="bold cyan")
        table.add_column("Bot Name", style="cyan")
        table.add_column("Directory")
        table.add_column("Status")

        for bot_name, bot_dir in sorted(bots):
            status_result = conn.run(
                f"systemctl is-active {bot_name}",
                hide=True,
                warn=True,
                pty=False,
                in_stream=False,
            )
            status = (
                status_result.stdout.strip()
                if status_result and status_result.stdout
                else "unknown"
            )
            status_formatted = _format_systemd_status(status)

            table.add_row(bot_name, bot_dir, status_formatted)

        console.print(table)
        console.print(f"\n[dim]Found {len(bots)} bot(s)[/dim]")


def _format_container_status(status: str) -> str:
    """Format container status with color."""
    status_colors = {
        "running": "[green]🟢 Running[/green]",
        "stopped": "[red]🔴 Stopped[/red]",
        "not_found": "[yellow]⚪ Not deployed[/yellow]",
        "error": "[red]❌ Error[/red]",
    }
    return status_colors.get(status, f"[dim]{status}[/dim]")


def _format_systemd_status(status: str) -> str:
    """Format systemd status with color."""
    status_colors = {
        "active": "[green]🟢 Active[/green]",
        "inactive": "[yellow]⚪ Inactive[/yellow]",
        "failed": "[red]❌ Failed[/red]",
        "unknown": "[dim]❓ Unknown[/dim]",
    }
    return status_colors.get(status, f"[dim]{status}[/dim]")
