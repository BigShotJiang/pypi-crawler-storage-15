import typer
from typing_extensions import Annotated
from typing import List, Optional
from enum import Enum

from rich import print
from rich.text import Text
from rich.tree import Tree
from rich.table import Table
from rich.console import Console

import ipaddress
import uuid
import json
import re
import time

from SOLIDserverRest import *
from SOLIDserverRest import adv as sdsadv

import sds.config as config
from sds.config import log
import sds.classparams as cp

app = typer.Typer()


class PrintType(str, Enum):
    tree = "tree"
    table = "table"
    simple = "simple"


def convert_dict(nomfolder: sdsadv.NomFolder = None) -> dict:
    """convert the NOM folder adv object to a dictionary structure
       for easy output as json

    Args:
        nomfolder (sdsadv.NomFolder, optional): folder object to convert.

    Returns:
        dict: the dictionary object
    """
    if nomfolder:
        _j = nomfolder.__dict__

        # print(_j)
        _jr = {
            'id': _j['myid'],
            'name': _j['name'],
        }

        if _j['space']:
            _jr['space'] = _j['space'].name

        if 'nomfolder_description' in _j['params']:
            if _j['params']['nomfolder_description'] != '':
                _jr['description'] = _j['params']['nomfolder_description']

        if 'nomfolder_class_name' in _j['params']:
            if _j['params']['nomfolder_class_name'] != '':
                _jr['class'] = _j['params']['nomfolder_class_name'].split(
                    '/')[-1]

        if 'nomfolder_nb_netobj' in _j['params']:
            _jr['nb_netobj'] = int(_j['params']['nomfolder_nb_netobj'])

        if _j['parent']:
            _jr['parent'] = _j['parent'].get_parent_name_hierarchy()[:-1]
        else:
            _jr['parent'] = ""

        _cparam = {}
        for _k, _v in _j['_ClassParams__class_params'].items():
            _cparam[_k] = _v

        for _k, _v in _j['_ClassParams__private_class_params'].items():
            _cparam[_k] = _v

        if len(_cparam) > 0:
            _jr['class_params'] = _cparam

        return _jr

    return {}


def _find_folder(name):
    folder_id = -1

    nomf = sdsadv.NomFolder(
        sds=config.vars['sds'],
        name=name)
    try:
        nomf.refresh()
        folder_id = nomf.myid
    except SDSError:
        pass

    # have not found by name, try by id
    if folder_id == -1:
        if name.isdigit():
            try:
                folder_id = int(name)
                nomf = sdsadv.NomFolder(sds=config.vars['sds'])
                nomf.myid = folder_id
                nomf.refresh()
                # log.info(nomf)
            except SDSError:
                folder_id = -1

    if folder_id == -1:
        # log.error("folder not found")
        return None

    return nomf


@app.command()
def create(name: Annotated[str,
                           typer.Argument(help='folder name')],

           parent: Annotated[str,
                             typer.Option('--parent',
                                          help='folder parent path name, may'
                                          ' be of form x/y/z')
                             ] = None,

           description: Annotated[str,
                                  typer.Option('--descr',
                                               help='folder description')
                                  ] = None,

           folder_class: Annotated[str,
                                   typer.Option('--class',
                                                help='folder class')
                                   ] = None,

           space: Annotated[str,
                            typer.Option('--space',
                                         help='folder link to space')
                            ] = None,

           meta: Annotated[str,
                           typer.Option(
                               help='class params: a=\'1\',b1=\'foo bar\' ')
                           ] = None
           ):
    _start_time = time.time()

    # do we have a parent, try to find it
    nompf = None
    if parent:
        nompf = _find_folder(parent)

    nomf = sdsadv.NomFolder(sds=config.vars['sds'],
                            name=name,
                            parent=nompf)

    if description:
        nomf.set_description(description)

    if folder_class:
        nomf.set_class_name(folder_class)

    if space:
        nomf.bind_spacename(space)

    if meta:
        if not cp.add_classparams_from_string(nomf, meta):
            log.critical("abort")
            exit()

    try:
        nomf.create()
    except SDSError:
        log.critical("error on folder creation")
        exit()

    _jr = convert_dict(nomf)
    if config.vars['json_output']:
        _jr['created'] = True
        _jr['_elapsed'] = round(time.time() - _start_time, 4)
    _print_info(_jr)


def _print_info(_jr):
    if config.vars['json_output']:
        print(json.dumps(_jr))
    else:
        text = f"NOM folder: [green]{_jr['name']}[/green]"

        if _jr['id'] != -1:
            text += f" \\[#{_jr['id']}]"

        if 'description' in _jr:
            text += " " + _jr['description']

        if 'space' in _jr:
            text += "\n space=" + _jr['space']

        if 'class' in _jr:
            text += "\n class=" + _jr['class']

        if 'class_params' in _jr:
            text += "\n meta=" + json.dumps(_jr['class_params'])

        if 'nb_netobj' in _jr and _jr['nb_netobj'] > 0:
            text += "\n nb_netobj=" + str(_jr['nb_netobj'])

        log.info(text)


@app.command()
def info(name: Annotated[str,
                         typer.Argument(
                             help='folder full name, may be of form x/y/z')],
         ):

    _start_time = time.time()

    nomf = _find_folder(name)

    if not nomf:
        exit()

    _print_info(convert_dict(nomf))


@app.command()
def delete(name: Annotated[str,
                           typer.Argument(
                               help='folder full name or id')],
           ):

    _start_time = time.time()

    nomf = _find_folder(name)
    # log.info(nomf)
    if nomf and nomf.myid > 0:
        _jr = convert_dict(nomf)

        try:
            nomf.delete()
        except SDSError as e:
            _jr['error'] = str(e)

        if config.vars['json_output']:
            _jr['_elapsed'] = round(time.time() - _start_time, 4)
            _jr['deleted'] = 'error' not in _jr
            print(json.dumps(_jr))
        else:
            text = f"NOM folder: [green]{_jr['name']}[/green]"
            if nomf.myid and nomf.myid != -1:
                text += f" [#{nomf.myid}]"
            if 'error' in _jr:
                text += "[red]not deleted[/red]: " + _jr['error']
            else:
                text += " deleted"
            log.info(text)
    else:
        if config.vars['json_output']:
            _jr = {}
            _jr['error'] = 'not found'
            _jr['deleted'] = False
            _jr['_elapsed'] = round(time.time() - _start_time, 4)
            print(json.dumps(_jr))
        else:
            log.error("folder not found, abort")


@app.command("list")
def display_list(limit: Annotated[int,
                                  typer.Option(
                                      help='the number max of folder to list,'
                                      ' 0 for no limit')
                                  ] = 50,
                 offset: Annotated[int,
                                   typer.Option(
                                       help='if a limit is used, starts at'
                                       ' the offset position')
                                   ] = 0,
                 page: Annotated[int,
                                 typer.Option(
                                     help='number of object to get on each'
                                     ' API call')
                                 ] = 50,
                 style: Annotated[PrintType,
                                  typer.Option(
                                      help='how to display the list')
                                  ] = PrintType.table,
                 ):

    if limit == 0:
        offset = 0

    nomf = sdsadv.NomFolder(sds=config.vars['sds'])
    nomf_list = nomf.list(offset=offset,
                          limit=limit,
                          page=page)

    if config.vars['json_output']:
        print(json.dumps(nomf_list))
        return

    if style == PrintType.table:
        table = Table(title="Folder list",
                      show_lines=True)

        table.add_column("id",   justify="right", style="yellow")
        table.add_column("name",   justify="left", style="blue", no_wrap=True)
        table.add_column("parent", justify="left", style="blue", no_wrap=False)
        table.add_column("class", justify="left",
                         style="green", no_wrap=False)
        table.add_column("object", justify="left",
                         no_wrap=False)
        table.add_column("description", style="cyan", justify="left",
                         no_wrap=False)

        table.add_column("meta", justify="left", style="red", no_wrap=False)

        for i in nomf_list:
            _cps = ''
            _sep = ''
            for _k, _v in i['meta'].items():
                _cps += _sep+_k+': '+_v
                _sep = '\n'

            table.add_row(i['id'],
                          i['name'], i['parent'], i['class'],
                          i['object'], i['description'],
                          _cps)

        console = Console()
        console.print(table)

    elif style == PrintType.simple:
        _line = f"{'id':<5}"
        _line += f"{'name':<40}"
        _line += f"{'class':<15}"
        _line += f"{'description':<20}"
        print(_line)

        for i in nomf_list:
            _line = f"[yellow]{i['id']:<5}[/yellow]"
            if i['tree_level'] > 0:
                _sep = '| '*i['tree_level']
            else:
                _sep = ''
            _line += f"{_sep+i['name']:<40}"
            _line += f"{i['class'][:14]:<15}"
            _line += f"{i['description']:<20}"
            print(_line)

    elif style == PrintType.tree:
        tree = Tree("Folder list")

        def add_leaf(treeobj=None, spaceinfo=None, lvl=0):
            for i in nomf_list:
                if i['tree_level'] == lvl:
                    _text = f"[blue]{i['name']}[/blue] (#[yellow]{i['id']}[/yellow])"
                    if i['class'] != '':
                        _text += f" class=[green]{i['class']}[/green]"
                    if i['description'] != '':
                        _text += f" descr=\"[cyan]{i['description']}\"[/cyan]"

                    _cps = ''
                    _sep = ''
                    for _k, _v in i['meta'].items():
                        _cps += _sep+_k+':'+_v
                        _sep = ','

                    if _cps != '':
                        _text += f" meta=[red]{_cps}[/red]"

                    if lvl > 0:
                        if spaceinfo['name'] == i['parent']:
                            _leaf = treeobj.add(_text)
                            add_leaf(_leaf, i, lvl+1)
                    else:
                        _leaf = treeobj.add(_text)
                        add_leaf(_leaf, i, lvl+1)

        add_leaf(treeobj=tree, spaceinfo=None, lvl=0)
        print(tree)


if __name__ == "__main__":
    app()
