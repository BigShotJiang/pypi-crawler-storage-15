import typer
from typing_extensions import Annotated
from typing import List, Optional
from enum import Enum

from rich import print
from rich.text import Text
from rich.tree import Tree
from rich.table import Table
from rich.console import Console

import ipaddress
import uuid
import json
import re
import time
import sys
import csv

from SOLIDserverRest import *
from SOLIDserverRest import adv as sdsadv

import sds.config as config
from sds.config import log
import sds.classparams as cp

from sds.nom_folder import _find_folder

app = typer.Typer()


class PrintType(str, Enum):
    table = "table"
    simple = "simple"
    csv = "csv"


def convert_dict(nomobject: sdsadv.NomNetObject = None) -> dict:
    """convert the NOM folder adv object to a dictionary structure
       for easy output as json

    Args:
        nomfolder (sdsadv.NomNetObject, optional): folder object to convert.

    Returns:
        dict: the dictionary object
    """
    if nomobject:
        _j = nomobject.__dict__

        # print(_j)
        _jr = {
            'id': _j['myid'],
            'name': _j['name'],
            'state': _j['state'],
            'type': _j['type']
        }

        _jr['folder'] = _j['folder'].get_parent_name_hierarchy()[:-1]
        if _j['description']:
            _jr['description'] = _j['description']
        if _j['parent']:
            _jr['parent'] = _j['parent'].folder.get_parent_name_hierarchy()
            _jr['parent'] += _j['parent'].name

        if 'nomnetobj_class_name' in _j['params']:
            if _j['params']['nomnetobj_class_name'] != '':
                _jr['class'] = _j['params']['nomnetobj_class_name'].split(
                    '/')[-1]

        _cparam = {}
        for _k, _v in _j['_ClassParams__class_params'].items():
            _cparam[_k] = _v

        for _k, _v in _j['_ClassParams__private_class_params'].items():
            _cparam[_k] = _v

        if len(_cparam) > 0:
            _jr['class_params'] = _cparam

        return _jr

    return {}


def _find_object(name, nomf=None):
    object_id = -1

    if not nomf:
        nomf = sdsadv.NomFolder(sds=config.vars['sds'],
                                name='_')

    nomo = sdsadv.NomNetObject(sds=config.vars['sds'],
                               name=name,
                               folder=nomf)
    try:
        nomo.refresh()
        object_id = nomo.myid
    except SDSerror:
        pass

    # have not found by name, try by id
    if object_id == -1:
        try:
            object_id = int(name)
            nomo = sdsadv.NomNetObject(sds=config.vars['sds'],
                                       name='_',
                                       folder=nomf)
            nomo.myid = object_id
            nomo.refresh()
            # log.info(nomf)
        except SDSerror:
            object_id = -1
            pass

    if object_id == -1:
        # log.error("folder not found")
        return None

    return nomo


@app.command()
def create(name: Annotated[str,
                           typer.Argument(help='object name')],

           folder: Annotated[str,
                             typer.Argument(help='folder path name, may'
                                            ' be of form x/y/z')
                             ],

           parent: Annotated[str,
                             typer.Option('--parent',
                                          help='object parent path name, may'
                                          ' be of form x/y/z. If no folder, use'
                                          ' current one')
                             ] = None,

           description: Annotated[str,
                                  typer.Option('--descr',
                                               help='object description')
                                  ] = None,

           object_type: Annotated[str,
                                  typer.Option('--type',
                                               help='object type')
                                  ] = None,


           object_state: Annotated[str,
                                   typer.Option('--state',
                                                help='object state')
                                   ] = None,

           object_class: Annotated[str,
                                   typer.Option('--class',
                                                help='object class')
                                   ] = None,

           meta: Annotated[str,
                           typer.Option(
                               help='class params: a=\'1\',b1=\'foo bar\' ')
                           ] = None
           ):
    _start_time = time.time()

    nomf = _find_folder(folder)
    if not nomf:
        log.error("folder not found")
        exit(-1)

    nomo = sdsadv.NomNetObject(sds=config.vars['sds'],
                               name=name,
                               folder=nomf)

    nomo.set_description(description)
    nomo.set_type(object_type)
    nomo.set_state(object_state)

    if parent:
        _path = parent.split('/')
        if len(_path) == 1:
            nompf = nomf
            _pobjectname = parent
        else:
            _pfolderpath = '/'.join(_path[:-1])
            nompf = _find_folder(_pfolderpath)
            if not nompf:
                log.error(f"parent folder not found {_pfolderpath}")
                exit(-1)

            _pobjectname = _path[-1]
        nompo = _find_object(_pobjectname, nompf)
        if not nompo:
            log.error(
                f"parent object not found {_pobjectname} in {_pfolderpath}")
            exit(-1)

        nomo.set_parent(nompo)

    if object_class:
        nomo.set_class_name(object_class)

    if meta:
        cp.add_classparams_from_string(nomo, meta)

    try:
        nomo.create()
    except SDSerror:
        log.critical("error on object creation")
        exit()

    _jr = convert_dict(nomo)
    if config.vars['json_output']:
        _jr['created'] = True
        _jr['_elapsed'] = round(time.time() - _start_time, 4)
    _print_info(_jr)


@app.command()
def update(name: Annotated[str,
                           typer.Argument(help='object name or id')],

           folder: Annotated[str,
                             typer.Option(help='folder path name, may'
                                          ' be of form x/y/z')
                             ] = None,

           parent: Annotated[str,
                             typer.Option('--parent',
                                          help='object parent path name, may'
                                          ' be of form x/y/z. If no folder, use'
                                          ' current one')
                             ] = None,

           description: Annotated[str,
                                  typer.Option('--descr',
                                               help='object description')
                                  ] = None,

           object_type: Annotated[str,
                                  typer.Option('--type',
                                               help='object type')
                                  ] = None,


           object_state: Annotated[str,
                                   typer.Option('--state',
                                                help='object state')
                                   ] = None,

           object_class: Annotated[str,
                                   typer.Option('--class',
                                                help='object class')
                                   ] = None,

           meta: Annotated[str,
                           typer.Option(
                               help='class params: a=\'1\',b1=\'foo bar\' ')
                           ] = None
           ):
    _start_time = time.time()

    if folder:
        nomf = _find_folder(folder)
        if not nomf:
            log.error("folder not found")
            exit(-1)
    else:
        nomf = None

    nomo = _find_object(name, nomf)
    if not nomo:
        log.error("NOM object not found, aborting")
        exit(-1)

    if description:
        nomo.set_description(description)
    if object_type:
        nomo.set_type(object_type)
    if object_state:
        nomo.set_state(object_state)

    if parent:
        _path = parent.split('/')
        if len(_path) == 1:
            nompf = nomo.folder
            _pobjectname = parent
        else:
            _pfolderpath = '/'.join(_path[:-1])
            nompf = _find_folder(_pfolderpath)
            if not nompf:
                log.error(f"parent folder not found {_pfolderpath}")
                exit(-1)

            _pobjectname = _path[-1]
        nompo = _find_object(_pobjectname, nompf)
        if not nompo:
            log.error(
                f"parent object not found {_pobjectname} in {_pfolderpath}")
            exit(-1)

        if nomo.myid != nompo.myid:
            nomo.set_parent(nompo)
        else:
            log.warning("cannot set parent as myself")

    if object_class:
        nomo.set_class_name(object_class)

    if meta:
        cp.add_classparams_from_string(nomo, meta)

    try:
        nomo.update()
        nomo.refresh()
    except SDSerror:
        log.critical("error on object update")
        exit()

    _jr = convert_dict(nomo)
    if config.vars['json_output']:
        _jr['updated'] = True
        _jr['_elapsed'] = round(time.time() - _start_time, 4)
    _print_info(_jr)


def _print_info(_jr):
    if config.vars['json_output']:
        print(json.dumps(_jr))
    else:
        text = f"NOM object: [green]{_jr['name']}[/green]"

        if _jr['id'] != -1:
            text += f" \\[#{_jr['id']}]"

        if 'description' in _jr:
            text += " \"" + _jr['description'] + "\""

        text += f"\n folder={_jr['folder']}"

        text += "\n type=" + _jr['type']
        text += "\n state=" + _jr['state']

        if 'parent' in _jr:
            text += "\n parent= " + _jr['parent']

        if 'class' in _jr:
            text += "\n class=" + _jr['class']

        if 'class_params' in _jr:
            text += "\n meta=" + json.dumps(_jr['class_params'])

        log.info(text)


@app.command()
def info(name: Annotated[str,
                         typer.Argument(
                             help='object full name')],

         folder: Annotated[str,
                           typer.Option(help='folder path name, may'
                                        ' be of form x/y/z')
                           ] = None,
         ):

    _start_time = time.time()

    if folder:
        nomf = _find_folder(folder)
        if not nomf:
            log.error("folder not found")
            exit(-1)
    else:
        nomf = None

    nomo = _find_object(name, nomf)
    if not nomo:
        log.error("object not found")
        exit()

    _print_info(convert_dict(nomo))


@app.command("list")
def display_list(folder: Annotated[str,
                                   typer.Argument(help='folder path name, may'
                                                  ' be of form x/y/z')
                                   ],
                 limit_folder: Annotated[bool,
                                         typer.Option(help='limit the list'
                                                      ' to this folder only')
                                         ] = True,
                 limit: Annotated[int,
                                  typer.Option(
                                      help='the number max of object to list,'
                                      ' 0 for no limit')
                                  ] = 50,
                 offset: Annotated[int,
                                   typer.Option(
                                       help='if a limit is used, starts at'
                                       ' the offset position')
                                   ] = 0,
                 page: Annotated[int,
                                 typer.Option(
                                     help='number of object to get on each'
                                     ' API call')
                                 ] = 50,
                 style: Annotated[PrintType,
                                  typer.Option(
                                      help='how to display the list')
                                  ] = PrintType.table
                 ):

    if limit == 0:
        offset = 0

    nomf = _find_folder(folder)
    if not nomf:
        log.error("folder not found")
        exit(-1)

    nomo = sdsadv.NomNetObject(sds=config.vars['sds'],
                               name='notused',
                               folder=nomf)

    # limits
    dwhere = {}

    if limit_folder:
        dwhere['nomfolder_id'] = nomf.myid

    nomo_list = nomo.list(offset=offset,
                          limit=limit,
                          page=page,
                          where_clause=dwhere)

    # print(nomo_list[0])

    if config.vars['json_output']:
        print(json.dumps(nomo_list))
        return

    if style == PrintType.table:
        table = Table(title="NOM Object list",
                      show_lines=True)

        table.add_column("id",   justify="right", style="yellow")
        table.add_column("folder",   justify="left", style="magenta")
        table.add_column("name",   justify="left", style="blue", no_wrap=True)
        table.add_column("type",   justify="left", no_wrap=True)
        table.add_column("state",   justify="left", no_wrap=True)
        table.add_column("parent", justify="left", style="blue", no_wrap=False)
        table.add_column("class", justify="left",
                         style="green", no_wrap=False)
        table.add_column("description", style="cyan", justify="left",
                         no_wrap=False)

        table.add_column("meta", justify="left", style="red", no_wrap=False)

        for i in nomo_list:
            _cps = ''
            _sep = ''
            for _k, _v in i['meta'].items():
                _cps += _sep+_k+': '+_v
                _sep = '\n'

            table.add_row(i['id'],
                          i['folder'],
                          i['name'], i['type'], i['state'],
                          i['parent'], i['class'],
                          i['description'],
                          _cps)

        console = Console()
        console.print(table)

    elif style == PrintType.simple:
        _line = f"{'id':<5}"
        _line += f"{'folder':<20}"
        _line += f"{'name':<40}"
        _line += f"{'type':<10}"
        _line += f"{'state':<10}"
        _line += f"{'class':<15}"
        _line += f"{'description':<20}"
        print(_line)

        for i in nomo_list:
            _line = f"[yellow]{i['id']:<5}[/yellow]"
            _line += f"[magenta]{i['folder']:<20}[/magenta]"
            _line += f"{i['name'][:39]:<40}"
            _line += f"{i['type'][:9]:<10}"
            _line += f"{i['state'][:9]:<10}"
            _line += f"{i['class'][:14]:<15}"
            _line += f"{i['description'][:20]:<20}"
            print(_line)

    elif style == PrintType.csv:
        _csv = csv.DictWriter(sys.stdout,
                              fieldnames=['id', 'folder',
                                          'name', 'type',
                                          'state', 'class',
                                          'description', 'meta'],
                              delimiter=';',
                              quotechar='"',
                              quoting=csv.QUOTE_ALL,
                              lineterminator='\n')

        _csv.writeheader()

        for i in nomo_list:
            _csv.writerow({
                'id': i['id'],
                'folder': i['folder'],
                'name': i['name'],
                'type': i['type'],
                'state': i['state'],
                'class': i['class'],
                'description': i['description'],
                'meta': i['meta']
            })
