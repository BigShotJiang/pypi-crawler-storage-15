import typer

import sds.config as config
import sds.nom_folder as nom_folder
import sds.nom_object as nom_object

app = typer.Typer()
app.add_typer(nom_folder.app, name="folder")
app.add_typer(nom_object.app, name="object")


@app.command()
def interface():
    config.err_console.log('nom interface not implemented')


if __name__ == "__main__":
    app()
