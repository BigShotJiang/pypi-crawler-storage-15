from typer.testing import CliRunner
import uuid
import logging
import json

if True:
    import sys
    import os
    sys.path.insert(0, os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..')))
    from sds import cli
    import sds.config as config
    _conf = config.read_config()
    app = cli.init_app()

runner = CliRunner()


def test_nomf_simple():
    """create, info and delete nom folder
    """
    folder_name = 'tauto-'+str(uuid.uuid4())[:8]

    # create
    result = runner.invoke(app, ["--json",
                                 "nom",
                                 "folder",
                                 "create",
                                 folder_name])

    _json = json.loads(result.output)
    # logging.error(_json)

    assert result.exit_code == 0
    assert _conf['sds'] != None
    assert int(_json['id']) > 0
    assert _json['name'] == folder_name
    assert _json['created']

    folder_id = _json['id']

    # info
    result = runner.invoke(app, ["--json",
                                 "nom",
                                 "folder",
                                 "info",
                                 folder_name])

    _json = json.loads(result.output)
    # logging.error(_json)
    assert _json['id'] == folder_id
    assert _json['name'] == folder_name

    # delete
    result = runner.invoke(app, ["--json",
                                 "nom",
                                 "folder",
                                 "delete",
                                 folder_name])

    _json = json.loads(result.output)

    # logging.error(_json)

    assert _json['id'] == folder_id
    assert _json['name'] == folder_name
    assert _json['deleted']


def test_nomf_tree():
    """create, info and delete nom folder
    """
    folder_name1 = 'tauto-'+str(uuid.uuid4())[:8]
    folder_name2 = 'tauto-'+str(uuid.uuid4())[:8]+'.1'
    folder_name3 = 'tauto-'+str(uuid.uuid4())[:8]+'.1.1'

    # create tree structure
    result = runner.invoke(app, ["--json",
                                 "nom",
                                 "folder",
                                 "create",
                                 folder_name1])

    _json = json.loads(result.output)
    # logging.error(_json)

    assert result.exit_code == 0
    assert _conf['sds'] != None
    assert int(_json['id']) > 0
    assert _json['name'] == folder_name1
    assert _json['created']

    folder_id1 = _json['id']

    # folder2 under folder1
    result = runner.invoke(app, ["--json",
                                 "nom",
                                 "folder",
                                 "create",
                                 folder_name2,
                                 '--parent', folder_name1])

    _json = json.loads(result.output)
    # logging.error(_json)

    assert result.exit_code == 0
    assert _conf['sds'] != None
    assert int(_json['id']) > 0
    assert _json['name'] == folder_name2
    assert _json['parent'] == folder_name1
    assert _json['created']

    folder_id2 = _json['id']

    # folder3 under folder2
    result = runner.invoke(app, ["--json",
                                 "nom",
                                 "folder",
                                 "create",
                                 folder_name3,
                                 '--parent',
                                 f'{folder_name1}/{folder_name2}'
                                 ])

    _json = json.loads(result.output)
    # logging.error(_json)

    assert result.exit_code == 0
    assert _conf['sds'] != None
    assert int(_json['id']) > 0
    assert _json['name'] == folder_name3
    assert _json['parent'] == f'{folder_name1}/{folder_name2}'
    assert _json['created']

    folder_id3 = _json['id']

    # try to delete level 2
    result = runner.invoke(app, ["--json",
                                 "nom",
                                 "folder",
                                 "delete",
                                 f'{folder_name1}/{folder_name2}'
                                 ])

    _json = json.loads(result.output)
    # logging.error(_json)

    assert _json['id'] == folder_id2
    assert _json['name'] == folder_name2
    assert _json['parent'] == folder_name1
    assert not _json['deleted']

    result = runner.invoke(app, ["--json",
                                 "nom",
                                 "folder",
                                 "delete",
                                 f'{folder_name1}/{folder_name2}/{folder_name3}'
                                 ])

    _json = json.loads(result.output)
    # logging.error(_json)

    assert _json['id'] == folder_id3
    assert _json['name'] == folder_name3
    assert _json['parent'] == f'{folder_name1}/{folder_name2}'
    assert _json['deleted']

    result = runner.invoke(app, ["--json",
                                 "nom",
                                 "folder",
                                 "delete",
                                 f'{folder_name1}/{folder_name2}'
                                 ])

    _json = json.loads(result.output)
    # logging.error(_json)

    assert _json['id'] == folder_id2
    assert _json['name'] == folder_name2
    assert _json['parent'] == folder_name1
    assert _json['deleted']

    result = runner.invoke(app, ["--json",
                                 "nom",
                                 "folder",
                                 "delete",
                                 str(folder_id1)
                                 ])

    _json = json.loads(result.output)
    # logging.error(_json)

    assert _json['id'] == folder_id1
    assert _json['name'] == folder_name1
    assert _json['deleted']


def test_nomf_meta():
    folder_name = 'tauto-'+str(uuid.uuid4())[:8]

    # create
    result = runner.invoke(app, ["--json",
                                 "nom",
                                 "folder",
                                 "create",
                                 folder_name,
                                 '--meta',
                                 "a='12',b='red'"
                                 ])

    _json = json.loads(result.output)
    # logging.error(_json)

    assert result.exit_code == 0
    assert _conf['sds'] != None
    assert int(_json['id']) > 0
    assert _json['name'] == folder_name
    assert _json['created']

    assert _json['class_params']['a'] == '12'
    assert _json['class_params']['b'] == 'red'

    folder_id = _json['id']

    # info
    result = runner.invoke(app, ["--json",
                                 "nom",
                                 "folder",
                                 "info",
                                 str(folder_id)])

    _json = json.loads(result.output)
    # logging.error(_json)

    assert result.exit_code == 0
    assert _conf['sds'] != None
    assert _json['id'] == folder_id
    assert _json['name'] == folder_name
    assert _json['class_params']['a'] == '12'
    assert _json['class_params']['b'] == 'red'

    # delete
    result = runner.invoke(app, ["--json",
                                 "nom",
                                 "folder",
                                 "delete",
                                 folder_name])

    _json = json.loads(result.output)

    assert _json['id'] == folder_id
    assert _json['name'] == folder_name
    assert _json['deleted']
