

# Matilo Model Serving Worker (mmsw)


## Environment


| Name | Desc |
| --- | --- |
| APP_ENV | 운영 환경 (local/dev/test/prod) |
| PROJECT_NAME | 프로젝트 이름 |
| DB_SCHEME | Sqlalchemy DB 스키마 (mysql+pymysql) |
| DB_HOST | DB 서버 호스트 (IP) |
| DB_PORT | DB 서버 포트 |
| DB_USER | DB 사용자 ID |
| DB_PWD | DB 암호 |
| DB_NAME | DB 명 |
| MODEL_NAME | 서빙 할 모델의 고유 이름 |
| MODEL_WORKER | 서빙 할 모델 워커의 고유 이름 |
| SLACK_URL | 오류 발생시 메시지를 전달 할 Slack URL |



## Module Dist

- New Stype

```bash
# Pre install
$ pip install build

# Do build & upload
$ python -m build
$ python -m twine upload dist/*
```


- Old Stype

```bash
# Pre install
$ pip install setuptools wheel

# Do build & upload
$ python setup.py sdist bdist_wheel
$ python -m twine upload dist/*
```


