# CherryPy Foundation
# Copyright (C) 2025 IKUS Software inc.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

import cherrypy


def url_for(*args, relative=None, **kwargs):
    """
    Generate a URL for the given endpoint/path (*args) with query params (**kwargs).

    relative:
      - None: pass through to cherrypy.url (CherryPy default behavior).
      - False: absolute URL (scheme, host, vhost, script_name).
      - True: URL relative to current request path (may include '..').
      - 'server': URL relative to server root (starts with '/').
    Notes:
      - String chunks have leading/trailing slashes stripped and are joined with '/'.
      - Chunks '.' and '..' are allowed as literals (for relative paths).
      - Objects may implement __url_for__() -> str or have a string .url_for attribute.
      - Integers are appended as path segments.
      - When path == "", existing request query parameters are merged (kwargs win).
    """
    path = ""
    for chunk in args:
        if isinstance(chunk, str):
            if not chunk.startswith('.'):
                path += "/"
            path += chunk.rstrip("/")
        elif isinstance(chunk, int):
            path += "/"
            path += str(chunk)
        elif hasattr(chunk, '__url_for__') and callable(chunk.__url_for__):
            path += "/"
            path += str(chunk.__url_for__())
        elif hasattr(chunk, 'url_for'):
            path += "/"
            path += str(chunk.url_for)
        else:
            raise ValueError('invalid positional arguments, url_for accept str, bytes, int: %r' % chunk)
    # When path is empty, we are browsing the same page.
    # Let keep the original query_string to avoid loosing it.
    if path == "":
        params = cherrypy.request.params.copy()
        params.update(kwargs)
        qs = [(k, v) for k, v in sorted(params.items()) if v is not None]
    else:
        qs = [(k, v) for k, v in sorted(kwargs.items()) if v is not None]
    # Outside a request, use the external_url as base if defined
    base = None
    if not cherrypy.request.app:
        cfg = cherrypy.tree.apps[''].cfg
        base = cfg.external_url
    return cherrypy.url(path=path, qs=qs, relative=relative, base=base)
