"""Health instance for Archivepodcast."""

from archivepodcast.utils.health import PodcastArchiverHealth

health = PodcastArchiverHealth()
