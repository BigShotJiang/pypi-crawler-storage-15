"""Module for instances or objects."""
