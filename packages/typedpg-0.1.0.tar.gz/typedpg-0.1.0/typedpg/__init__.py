"""
typedpg - Generate type-safe Python code from PostgreSQL queries.
"""

from typedpg.decorator import query

__version__ = "0.1.0"
__all__ = ["query"]
