"""Adaption of a CrewAI-like flow."""

TITLE = "CrewAI-Style Flow"
ICON = "octicon:workflow-16"
