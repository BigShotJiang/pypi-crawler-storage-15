"""Example demonstrating structured response types."""

TITLE = "Structured Responses"
ICON = "simple-icons:instructure"
