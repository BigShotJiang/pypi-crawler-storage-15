from lino.modlib.users.fixtures.demo_users import *
