"""OCR (Optical Character Recognition) module."""

__all__ = []
