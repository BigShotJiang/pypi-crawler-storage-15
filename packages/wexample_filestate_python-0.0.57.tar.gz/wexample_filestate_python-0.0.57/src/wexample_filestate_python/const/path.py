from __future__ import annotations

from pathlib import Path

PATH_DIR_SRC: Path = Path("src")
PATH_DIR_TESTS: Path = Path("tests")
