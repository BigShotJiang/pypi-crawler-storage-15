from imports import *
url='https://stackoverflow.com/questions/77230706/using-only-pip-for-installing-spacy-model-en-core-web-sm'
video_url = "https://www.youtube.com/watch?v=70PgnfOs6g0"

keywords = get_pipeline_data(video_id="70PgnfOs6g0")

input(keywords)
