"""
SimpleDynamicPaginatorService - Paginador dinámico optimizado para Django REST Framework.
"""

from rest_framework.pagination import PageNumberPagination
from rest_framework.response import Response
from django.db.models import Q, F
from typing import List, Optional, Dict, Any
from .utils import get_model_field_names, build_fk_mapping, validate_model_fields
from .exceptions import PaginatorError, InvalidFilterError, ModelNotFoundError


class SimpleDynamicPaginatorService:
    """
    Paginador dinámico que construye el queryset desde cero con múltiples opciones de filtrado.
    
    Este paginador está optimizado para construir consultas eficientes con soporte para:
    - Filtros base (account_by, status, etc.)
    - Q objects complejos para consultas avanzadas (_q_filter)
    - Exclusiones (exclude_id, exclude_status, etc.)
    - Combinación inteligente de filtros de la misma tabla relacionada (evita dobles JOINs)
    - Rango de fechas dinámico
    - Filtros permitidos definidos
    - Búsqueda en múltiples campos
    - Ordenamiento personalizable
    - Optimizaciones con select_related y prefetch_related DINÁMICOS
    - Optimización only() para campos específicos dinámicos desde query params
    - Opción para devolver todos los resultados sin paginación
    - **MEJORADO: Query params afectan SQL, Serializer y select_related**
    
    Args:
        model: Modelo de Django sobre el que se realizará la consulta
        serializer_class: Clase del serializador DRF para los resultados (debe heredar de DynamicFieldsModelSerializer)
        search_fields (list): Lista de campos donde se aplicará la búsqueda
        page_size (int): Número de elementos por página (default: 50)
        allowed_filters (list): Lista de campos permitidos para filtrado dinámico
        select_related (list): Lista de campos ForeignKey permitidos para optimizar con JOIN
        prefetch_related (list): Lista de relaciones Many-to-Many para optimizar
        only_fields (list): Lista de campos específicos a cargar como fallback (optimización SQL SELECT)
        allow_unlimited (bool): Permite desactivar la paginación via query param (default: False)
        enable_dynamic_fields (bool): Habilita campos dinámicos desde query params (default: True)
        debug (bool): Habilita logs de debug para desarrollo (default: False)
        debug (bool): Habilita logs de debug para desarrollo (default: False)
    """
    
    def __init__(self, model, serializer_class, search_fields=None, page_size=50, allowed_filters=None, 
                 select_related=None, prefetch_related=None, only_fields=None, allow_unlimited=False,
                 enable_dynamic_fields=True, debug=False):
        
        # Validar que el modelo sea válido
        if not hasattr(model, '_meta'):
            raise ModelNotFoundError(f"El objeto {model} no es un modelo Django válido")
        
        self.model = model
        self.serializer_class = serializer_class
        self.search_fields = search_fields or []
        self.page_size = page_size
        self.allowed_filters = allowed_filters or []
        self.select_related = select_related or []
        self.prefetch_related = prefetch_related or []
        self.only_fields = only_fields or []
        self.allow_unlimited = allow_unlimited
        self.enable_dynamic_fields = enable_dynamic_fields
        self.debug = debug
        self.debug = debug
        
        # Validar campos del modelo
        if self.search_fields:
            validate_model_fields(model, self.search_fields)
        
        # Pre-calcular campos del modelo una sola vez para optimización
        self.model_field_names = get_model_field_names(model)
        self.valid_sort_fields = self.model_field_names.union({'id', 'pk'})
        
        # Auto-detectar ForeignKeys para mapeo automático
        self.fk_mapping = build_fk_mapping(model)
    
    def _parse_dynamic_fields(self, request):
        """
        Parsea los campos dinámicos desde los query parameters del request.
        
        Query Parameters soportados:
            only_fields: Lista de campos a incluir separados por coma
            exclude_fields: Lista de campos a excluir separados por coma  
            nested_fields: JSON string con configuración de campos anidados
            
        Ejemplos:
            ?only_fields=id,name,code
            ?exclude_fields=created_at,updated_at
            ?nested_fields={"parent_store":{"only_fields":["id","name"]}}
            
        Returns:
            dict: Diccionario con configuración de campos dinámicos
        """
        dynamic_config = {}
        
        if not self.enable_dynamic_fields:
            return dynamic_config
            
        # Parsear only_fields
        only_fields_param = request.query_params.get('only_fields')
        if only_fields_param:
            only_fields = [field.strip() for field in only_fields_param.split(',') if field.strip()]
            if only_fields:
                dynamic_config['only_fields'] = only_fields
        
        # Parsear exclude_fields  
        exclude_fields_param = request.query_params.get('exclude_fields')
        if exclude_fields_param:
            exclude_fields = [field.strip() for field in exclude_fields_param.split(',') if field.strip()]
            if exclude_fields:
                dynamic_config['exclude'] = exclude_fields
        
        # Parsear nested_fields (JSON)
        nested_fields_param = request.query_params.get('nested_fields')
        if nested_fields_param:
            try:
                import json
                nested_fields = json.loads(nested_fields_param)
                if isinstance(nested_fields, dict) and nested_fields:
                    dynamic_config['nested_fields'] = nested_fields
            except (json.JSONDecodeError, ValueError):
                # Si no se puede parsear el JSON, ignorar silenciosamente
                pass
                
        return dynamic_config
    
    def _get_dynamic_select_related(self, only_fields, static_select_related):
        """
        Construye dinámicamente select_related basado en los campos solicitados
        dentro de only_fields, permitiendo niveles profundos (a__b__c__d).

        Args:
            only_fields (list): Lista de campos que el serializer realmente usará.
            static_select_related (list): Relaciones permitidas definidas por la vista.

        Returns:
            list: Lista optimizada de select_related con niveles profundos.
        """
        if not only_fields:
            return static_select_related

        needed_relations = set()

        for field in only_fields:
            # Solo analizamos campos con "__"
            if "__" not in field:
                continue

            # Separar niveles: ej. "created_by__user__username"
            parts = field.split("__")

            # Construir incrementalmente la ruta:
            # created_by
            # created_by__user
            # created_by__user__profile
            for i in range(1, len(parts)):
                relation_path = "__".join(parts[:i])  # ejemplo: created_by__user

                # Agregar solo si está permitido en static_select_related
                # Permite coincidencias parciales o exactas
                if any(
                    relation_path == rel or relation_path.startswith(rel + "__")
                    for rel in static_select_related
                ):
                    needed_relations.add(relation_path)

        dynamic_select_related = sorted(list(needed_relations))

        if self.debug:
            print("🔍 [DEBUG] Dynamic select_related (deep analysis):")
            print(f"   ➤ Input only_fields: {only_fields}")
            print(f"   ➤ Allowed (static):  {static_select_related}")
            print(f"   ➤ Result:            {dynamic_select_related}")

        return dynamic_select_related
    
    def _get_dynamic_prefetch_related(self, only_fields, static_prefetch_related):
        """
        Determina qué prefetch_related usar basado en los only_fields dinámicos.
        
        Args:
            only_fields (list): Lista de campos que se van a usar
            static_prefetch_related (list): Lista fija de prefetch_related del constructor
            
        Returns:
            list: Lista optimizada de prefetch necesarios
        """
        if not only_fields:
            return static_prefetch_related
        
        needed_prefetch = set()
        
        # Detectar qué prefetch son realmente necesarios
        for field in only_fields:
            if '__' in field:
                relation = field.split('__')[0]
                # Verificar que la relación esté en la lista permitida de prefetch
                for prefetch in static_prefetch_related:
                    if prefetch.startswith(relation):
                        needed_prefetch.add(prefetch)
            # También buscar por nombres directos
            else:
                if field in static_prefetch_related:
                    needed_prefetch.add(field)
        
        return list(needed_prefetch)

    def _validate_sql_only_fields(self, only_fields):
        """
        Valida que los campos para only() sean válidos para SQL.
        
        Args:
            only_fields (list): Lista de campos a validar
            
        Returns:
            list: Lista de campos válidos para SQL only()
        """
        if not only_fields:
            return []
        
        valid_fields = []
        related_fields = {}  # Para agrupar campos relacionados
        
        for field in only_fields:
            # Campos especiales siempre válidos
            if field in ['id', 'pk']:
                valid_fields.append(field)
            # Campos directos del modelo (sin relaciones)
            elif '__' not in field and field in self.model_field_names:
                valid_fields.append(field)
            # Campos relacionados - agrupar por relación
            elif '__' in field:
                relation = field.split('__')[0]
                related_field = field.split('__', 1)[1]
                
                # Verificar que la relación existe en el modelo
                if relation in self.model_field_names:
                    if relation not in related_fields:
                        related_fields[relation] = []
                    related_fields[relation].append(related_field)
        
        # Agregar campos relacionados al only() 
        for relation, fields in related_fields.items():
            # Agregar el campo de relación base (ej: 'client')
            if relation not in valid_fields:
                valid_fields.append(relation)
            
            # Agregar campos específicos de la relación (ej: 'client__id', 'client__name')
            for related_field in fields:
                full_field = f"{relation}__{related_field}"
                valid_fields.append(full_field)
        
        if self.debug:
            print(f"🔍 [DEBUG] Campos validados para only(): {valid_fields}")
        
        return valid_fields
    
    def handle_request(self, request, **base_filters):
        """
        Construye y ejecuta la consulta con todos los filtros aplicados.
        
        Returns:
            Response: Respuesta HTTP paginada o lista completa según el parámetro 'unlimited'
        """
        
        try:
            # 1. Separar y combinar filtros base
            normal_filters = {}
            exclude_filters = {}
            q_filter = None
            related_filters = {}
            
            for key, value in base_filters.items():
                if key.startswith('exclude_'):
                    field_name = key.replace('exclude_', '', 1)
                    exclude_filters[field_name] = value
                elif key == '_q_filter':
                    q_filter = value
                elif '__' in key:
                    relation = key.split('__')[0]
                    if relation not in related_filters:
                        related_filters[relation] = {}
                    field = key.split('__', 1)[1]
                    related_filters[relation][field] = value
                else:
                    normal_filters[key] = value
            
            # 2. Combinar filtros en una sola operación
            all_filters_combined = Q()
            
            if normal_filters:
                for field, value in normal_filters.items():
                    all_filters_combined &= Q(**{field: value})
            
            for relation, relation_filters in related_filters.items():
                relation_q = Q()
                for field, value in relation_filters.items():
                    relation_q &= Q(**{f"{relation}__{field}": value})
                all_filters_combined &= relation_q
            
            if q_filter:
                all_filters_combined &= q_filter
            
            # Aplicar filtros combinados
            if all_filters_combined:
                if self.debug:
                    print(f"🔍 [PAGINATOR DEBUG] Applying combined filters: {all_filters_combined}")
                queryset = self.model.objects.filter(all_filters_combined)
                if q_filter:
                    if self.debug:
                        print("🔍 [PAGINATOR DEBUG] Q objects detected - Adding DISTINCT")
                    queryset = queryset.distinct()
            else:
                if self.debug:
                    print("🔍 [PAGINATOR DEBUG] No base filters applied - Using model.objects.all()")
                queryset = self.model.objects.all()
            
            # 3. Aplicar exclusiones
            if exclude_filters:
                queryset = queryset.exclude(**exclude_filters)
            
            # 4. Parsear campos dinámicos
            search_query = request.query_params.get('search', '').strip()
            dynamic_fields_config = self._parse_dynamic_fields(request)
            
            # Determinar only_fields efectivos
            effective_only_fields = None
            if dynamic_fields_config.get('only_fields'):
                effective_only_fields = dynamic_fields_config['only_fields']
            elif self.only_fields:
                effective_only_fields = self.only_fields
            
            # 5. Select_related dinámico
            if effective_only_fields:
                dynamic_select_related = self._get_dynamic_select_related(effective_only_fields, self.select_related)
            else:
                dynamic_select_related = self.select_related
            
            # Aplicar optimizaciones de relaciones
            if dynamic_select_related:
                if self.debug:
                    print(f"🔍 [PAGINATOR DEBUG] Applying dynamic select_related: {dynamic_select_related}")
                queryset = queryset.select_related(*dynamic_select_related)
            
            if self.prefetch_related:
                if self.debug:
                    print(f"🔍 [PAGINATOR DEBUG] Applying prefetch_related: {self.prefetch_related}")
                queryset = queryset.prefetch_related(*self.prefetch_related)
            
            # 6. Only() dinámico
            if not search_query:
                sql_only_fields = None
                
                if dynamic_fields_config.get('only_fields'):
                    sql_only_fields = self._validate_sql_only_fields(dynamic_fields_config['only_fields'])
                    if self.debug:
                        print(f"🔍 [PAGINATOR DEBUG] Using only_fields from query params: {sql_only_fields}")
                elif self.only_fields:
                    sql_only_fields = self._validate_sql_only_fields(self.only_fields)
                    if self.debug:
                        print(f"🔍 [PAGINATOR DEBUG] Using only_fields from constructor: {sql_only_fields}")
                
                if sql_only_fields:
                    queryset = queryset.only(*sql_only_fields)
                elif self.debug:
                    print("🔍 [PAGINATOR DEBUG] No only_fields applied - SQL will SELECT *")
            elif self.debug:
                print(f"🔍 [PAGINATOR DEBUG] Search query detected: '{search_query}' - Skipping only() optimization")
            
            # 7. Filtros de fecha
            fecha_inicio = request.query_params.get('startDate')
            fecha_fin = request.query_params.get('endDate')
            campo_fecha = request.query_params.get('field_date', 'created_at')
            
            if fecha_inicio:
                queryset = queryset.filter(**{f"{campo_fecha}__gte": fecha_inicio})
            if fecha_fin:
                queryset = queryset.filter(**{f"{campo_fecha}__lte": fecha_fin})
            
            # 8. Filtros dinámicos permitidos
            allowed_related_filters = {}
            
            for key, value in request.query_params.items():
                if key in self.allowed_filters and value:
                    if '__' in key:
                        relation = key.split('__')[0]
                        if relation not in allowed_related_filters:
                            allowed_related_filters[relation] = {}
                        field = key.split('__', 1)[1]
                        allowed_related_filters[relation][field] = value
                    elif key in self.fk_mapping:
                        filter_field = self.fk_mapping[key]
                        queryset = queryset.filter(**{filter_field: value})
                    elif key in ['status', 'priority', 'id'] or key.endswith('_id'):
                        queryset = queryset.filter(**{key: value})
                    else:
                        queryset = queryset.filter(**{f"{key}__icontains": value})
            
            for relation, relation_filters in allowed_related_filters.items():
                combined_q = Q()
                for field, value in relation_filters.items():
                    combined_q &= Q(**{f"{relation}__{field}": value})
                queryset = queryset.filter(combined_q)
            
            # 9. Filtros _in
            in_filters = {}
            for key, value in request.query_params.items():
                if key.endswith('_in') and value:
                    field_name = key.rsplit('_in', 1)[0]
                    value_list = [v.strip() for v in value.split(',') if v.strip()]
                    if value_list:
                        in_filters[f"{field_name}__in"] = value_list
            
            if in_filters:
                queryset = queryset.filter(**in_filters)
            
            # 10. Búsqueda
            if search_query and self.search_fields:
                if len(self.search_fields) == 1:
                    queryset = queryset.filter(**{f"{self.search_fields[0]}__icontains": search_query})
                else:
                    q_objects = [Q(**{f"{field}__icontains": search_query}) for field in self.search_fields]
                    combined_q = Q()
                    for q_obj in q_objects:
                        combined_q |= q_obj
                    queryset = queryset.filter(combined_q)
            
            # 11. Ordenamiento
            sort_by = request.query_params.get('sortBy')
            sort_desc = request.query_params.get('sortDesc', 'false').lower() == 'true'
            
            if sort_by and (sort_by in self.valid_sort_fields or '__' in sort_by):
                queryset = queryset.order_by()
                
                if 'last_login' in sort_by:
                    if sort_desc:
                        queryset = queryset.order_by(F(sort_by).desc(nulls_last=True))
                    else:
                        queryset = queryset.order_by(F(sort_by).asc(nulls_last=True))
                else:
                    order = f"{'-' if sort_desc else ''}{sort_by}"
                    try:
                        queryset = queryset.order_by(order)
                    except Exception:
                        queryset = queryset.order_by('-id')
            else:
                queryset = queryset.order_by('-id')
            
            # 12. Verificar modo unlimited
            unlimited = request.query_params.get('unlimited', 'false').lower() == 'true'
            
            if self.allow_unlimited and unlimited:
                if self.debug:
                    print("\n" + "="*80)
                    print("🚀 [PAGINATOR DEBUG] SQL QUERY FINAL (UNLIMITED):")
                    print("="*80)
                    try:
                        print(queryset.query)
                    except Exception as e:
                        print(f"❌ No se pudo mostrar el SQL: {e}")
                    print("="*80 + "\n")
                
                # Optimización: count antes de serializar
                total_count = queryset.count()
                serializer = self.serializer_class(queryset, many=True, **dynamic_fields_config)
                
                return Response({
                    'results': serializer.data,
                    'count': total_count,
                    'unlimited': True
                })
            
            # 13. Paginación normal
            paginator = PageNumberPagination()
            paginator.page_size = self.page_size
            
            if self.debug:
                print("\n" + "="*80)
                print("🚀 [PAGINATOR DEBUG] SQL QUERY FINAL:")
                print("="*80)
                try:
                    print(queryset.query)
                except Exception as e:
                    print(f"❌ No se pudo mostrar el SQL: {e}")
                print("="*80 + "\n")
            
            result_page = paginator.paginate_queryset(queryset, request)
            serializer = self.serializer_class(result_page, many=True, **dynamic_fields_config)
            
            return paginator.get_paginated_response(serializer.data)
            
        except Exception as e:
            if isinstance(e, (PaginatorError, InvalidFilterError, ModelNotFoundError)):
                raise
            raise PaginatorError(f"Error en paginador: {str(e)}") from e