-- remove catalog.initialization

ALTER TABLE catalog
DROP COLUMN initialization;
