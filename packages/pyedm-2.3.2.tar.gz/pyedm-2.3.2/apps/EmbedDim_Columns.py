#! /usr/bin/env python3

# Python distribution modules
from argparse           import ArgumentParser
from datetime           import datetime
from itertools          import repeat
from multiprocessing    import get_context
from concurrent.futures import ProcessPoolExecutor

# Community modules
from pandas import DataFrame, read_feather, read_csv
from pyEDM  import EmbedDimension, sampleData
from matplotlib import pyplot as plt
from numpy import greater, maximum
from scipy.signal import argrelextrema

#----------------------------------------------------------------------------
#
#----------------------------------------------------------------------------
def EmbedDim_Columns( data, target = None, maxE = 15, minE = 1,
                      lib = None, pred = None, Tp = 1, tau = -1,
                      exclusionRadius = 0, firstMax = False,
                      validLib = [], noTime = False, ignoreNan = True,
                      cores = 2, EDimCores = 5, mpMethod = None, chunksize = 1,
                      outputFile = None, verbose = False, plot = False ):

    '''Use ProcessPoolExecutor to process parallelise EmbedDimension().
       Note EmbedDimension() uses multiprocessing Pool but usually will
       not require more than a few processes, maxE at most.
       Two arguments contol the number of cores used for each:
         -C  args.cores is number of processors running EmbedDimFunc().
         -EC args.EDimCores is number of processors for EmbedDimension().
       The product should not exceed available capacity.
       The multiprocessing context is set to mpMethod. 

       If target is not specified EmbedDimension is univariate where each
       embedding evaluation is of the data column itself. It target (-t)
       is specified it is a single column against which all other columns
       are cross mapped and evaluated against embedding dimension.

       If firstMax is True, return the intial (lowest E) maximum.

       Return : DataFrame[ 'column', 'target', 'maxE', 'maxRho' ]
    '''

    startTime = datetime.now()
    if verbose :
        print( f'EmbedDim_Columns(): {startTime}' )

    # If no lib and pred, create from full data span
    if lib is None :
        lib = [ 1, data.shape[0] ]
    if pred is None :
        pred = [ 1, data.shape[0] ]

    # Ignore first column, convert to list
    if noTime :
        columns = list( data.columns )
    else :
        columns = list( data.columns[ 1 : ] )

    N = len( columns )

    # Dictionary of arguments for PoolExecutor : EmbedDimFunc
    argsD = { 'target'          : target,
              'maxE'            : maxE,
              'minE'            : minE,
              'lib'             : lib,
              'pred'            : pred,
              'Tp'              : Tp,
              'tau'             : tau,
              'exclusionRadius' : exclusionRadius,
              'firstMax'        : firstMax,
              'validLib'        : validLib,
              'noTime'          : noTime,
              'ignoreNan'       : ignoreNan,
              'EDimCores'       : EDimCores }

    mpContext = get_context( mpMethod )
    if verbose :
        print( f'multiprocessing: {mpContext._name} ' +\
               f'using {cores} of {mpContext.cpu_count()} available CPU' )

    # ProcessPoolExecutor has no starmap(). Pass argument lists directly.
    with ProcessPoolExecutor(max_workers=cores, mp_context=mpContext) as exe :
        EDim = exe.map( EmbedDimFunc,
                        columns, repeat(data,N), repeat(argsD,N),
                        chunksize = chunksize )

    # EDim is a generator of dictionaries from EmbedDimFunc
    # Fill maxCols, targets and maxE arrays, dict
    maxCols = [None] * N
    targets = [None] * N
    maxRho  = [0]    * N
    maxE    = [0]    * N
    i       = 0
    for edim in EDim :
        maxCols[i] = edim['column']
        targets[i] = edim['target']
        maxE[i]    = edim['maxE']
        maxRho[i]  = edim['maxRho']
        i = i + 1

    DF = DataFrame({'column':maxCols,'target':targets,'E':maxE,'rho':maxRho})

    if outputFile :
        if '.csv' in outputFile[-4:] :
            DF.to_csv( outputFile, index = False )
        elif '.feather' in outputFile[-8:] :
            DF.to_feather( outputFile )
        elif any([_ in outputFile[-4:] for _ in ['.pkl','.gz','.xz','.zip'] ]):
            DF.to_pickle( outputFile )
        else :
            err = 'EmbedDim_Columns() ' +\
                f'unrecognized outputFile format in {outputFile}'
            print( err )

    if verbose :
        print( f'Finished: {datetime.now()}' )
        print( f'Elapsed Time {datetime.now() - startTime}' )

        print( DF )

    if plot :
        DF.plot( 'column', 'E' )
        plt.show()

    return DF

#----------------------------------------------------------------------------
#----------------------------------------------------------------------------
def EmbedDimFunc( column, df, args ):
    '''Estimate optimal embedding dimension [1:maxE]
       If no target specified : univariate embedding of column'''

    if args['target'] :
        target = args['target']
    else :
        target = column

    ed = EmbedDimension( dataFrame       = df,
                         columns         = column,
                         target          = target,
                         maxE            = args['maxE'],
                         lib             = args['lib'],
                         pred            = args['pred'],
                         Tp              = args['Tp'],
                         tau             = args['tau'],
                         exclusionRadius = args['exclusionRadius'],
                         validLib        = args['validLib'],
                         noTime          = args['noTime'],
                         ignoreNan       = args['ignoreNan'],
                         verbose         = False,
                         numProcess      = args['EDimCores'],
                         showPlot        = False )

    # Find max rho(E)
    if args['firstMax'] :
        iMax = argrelextrema( ed['rho'].to_numpy(), greater )[0] # tuple

        if len( iMax ) :
            iMax = iMax[0] # first element of array
        else :
            iMax = len( ed['E'] ) - 1 # no local maxima, last element is max
    else : 
        iMax = ed['rho'].round(4).argmax() # global maximum

    maxRho = ed['rho'].iloc[ iMax ].round(4)
    maxE   = ed['E'].iloc[ iMax ]

    # Enforce lower limit on E
    if args['minE'] > 1 :
        maxE   = maximum( args['minE'], maxE )
        maxRho = ed['rho'].iloc[ maxE - 1 ].round(4)

    return { 'column':column, 'target':target,
             'maxE':maxE, 'maxRho':maxRho } #, 'EDim':ed }

#----------------------------------------------------------------------------
#----------------------------------------------------------------------------
def EmbedDim_Columns_CmdLine():
    '''Wrapper for EmbedDim_Columns with command line parsing'''

    args = ParseCmdLine()

    # Read data
    # If -i input file: load it, else look for inputData in pyEDM sampleData
    if args.inputFile:
        if '.csv' in args.inputFile[-4:] :
            dataFrame = read_csv( args.inputFile )
        elif '.feather' in args.inputFile[-8:] :
            dataFrame = read_feather( args.inputFile )
        else :
            msg = f'Input file {args.inputFile} must be csv or feather'
            raise( RuntimeError( msg ) )
    elif args.inputData:
        from pyEDM import sampleData
        dataFrame = sampleData[ args.inputData ]
    else:
        raise RuntimeError( "Invalid inputFile or inputData" )

    # Call EmbedDim_Columns()
    DF = EmbedDim_Columns( data = dataFrame,
                           target = args.target,
                           maxE = args.maxE, minE = args.minE,
                           lib = args.lib, pred = args.pred,
                           Tp = args.Tp, tau = args.tau,
                           exclusionRadius = args.exclusionRadius,
                           firstMax = args.firstMax,
                           validLib = args.validLib, noTime = args.noTime,
                           ignoreNan = args.ignoreNan,
                           cores = args.cores, EDimCores = args.EDimCores,
                           mpMethod = args.mpMethod, chunksize = args.chunksize,
                           outputFile = args.outputFile,
                           verbose = args.verbose, plot = args.Plot )

#----------------------------------------------------------------------------
#----------------------------------------------------------------------------
def ParseCmdLine():

    parser = ArgumentParser( description = 'CrossMap Columns' )

    parser.add_argument('-i', '--inputFile',
                        dest    = 'inputFile', type = str,
                        action  = 'store',
                        default = None,
                        help    = 'Input data file.')

    parser.add_argument('-d', '--inputData',
                        dest    = 'inputData', type = str,
                        action  = 'store',
                        default = 'Lorenz5D',
                        help    = 'pyEDM sample data name.')

    parser.add_argument('-o', '--outputFile',
                        dest    = 'outputFile', type = str,
                        action  = 'store',
                        default = None,
                        help    = 'Output file: csv feather gz xz pkl.')

    parser.add_argument('-t', '--target',
                        dest    = 'target', type = str,
                        action  = 'store',
                        default = None,
                        help    = 'Target column')

    parser.add_argument('-maxE', '--maxE',
                        dest    = 'maxE', type = int,
                        action  = 'store',
                        default = 15,
                        help    = 'maxE')

    parser.add_argument('-minE', '--minE',
                        dest    = 'minE', type = int,
                        action  = 'store',
                        default = 1,
                        help    = 'minE')

    parser.add_argument('-l', '--lib', nargs = 2,
                        dest   = 'lib', type = int,
                        action = 'store', default = None,
                        help = 'lib')

    parser.add_argument('-pred', '--pred', nargs = 2,
                        dest   = 'pred', type = int,
                        action = 'store', default = None,
                        help = 'pred')

    parser.add_argument('-T', '--Tp',
                        dest    = 'Tp', type = int,
                        action  = 'store',
                        default = 1,
                        help    = 'Tp')

    parser.add_argument('-tau', '--tau',
                        dest    = 'tau', type = int,
                        action  = 'store',
                        default = -1,
                        help    = 'tau')

    parser.add_argument('-x', '--exclusionRadius',
                        dest    = 'exclusionRadius', type = int,
                        action  = 'store',
                        default = 0,
                        help    = 'Exclusion Radius')

    parser.add_argument('-f', '--firstMax',
                        dest   = 'firstMax',
                        action = 'store_true', default = False,
                        help = 'Choose first in rho(E)')

    parser.add_argument('-VL', '--validLib',
                        dest   = 'validLib', type = str,
                        action = 'store', default = '',
                        help = 'expression to eval for validLib')

    parser.add_argument('-noTime', '--noTime',
                        dest   = 'noTime',
                        action = 'store_true', default = False,
                        help = 'Set noTime True')

    parser.add_argument('-in', '--ignoreNan',
                        dest   = 'ignoreNan',
                        action = 'store_false', default = True,
                        help = 'Set ignoreNan False')

    parser.add_argument('-mp', '--mpMethod',
                        dest    = 'mpMethod', type = str,
                        action  = 'store',
                        default = None,
                        help    = 'Multiprocessing start method')

    parser.add_argument('-C', '--cores',
                        dest    = 'cores', type = int,
                        action  = 'store',
                        default = 2,
                        help    = 'Multiprocessing cores')

    parser.add_argument('-EC', '--EDimCores',
                        dest   = 'EDimCores', type = int,
                        action = 'store', default = 5,
                        help = 'EmbedDim multiprocessing cores')

    parser.add_argument('-cz', '--chunksize',
                        dest   = 'chunksize', type = int,
                        action = 'store', default = 1,
                        help = 'ProcessPoolExecutor.map chunksize')

    parser.add_argument('-v', '--verbose',
                        dest    = 'verbose',
                        action  = 'store_true',
                        default = False,
                        help    = 'verbose')

    parser.add_argument('-P', '--Plot',
                        dest    = 'Plot',
                        action  = 'store_true',
                        default = False,
                        help    = 'Plot')

    args = parser.parse_args()

    return args

#----------------------------------------------------------------------------
# Provide for cmd line invocation and clean module loading
if __name__ == "__main__":
    EmbedDim_Columns_CmdLine()
