import importlib.metadata

__version__ = importlib.metadata.version("quanti_fret")
