"""

This is the installer CLI. It replaces the main CLI when running in pyinstaller mode.

It allows the user to install a working tgzr CLI by creating a temp virtual env,
installing tgzr.cli + tgzr.shell from pypi and uses the resulting tgzr cli to create a
tgzr.shell.workspaces.Workspaces folder containing a Workspace named "tgzr". This Workspace (like any
Workspace) has the tgzr cli installed it it, with a shortcut at its root folder.


"""

import sys
import os
import tempfile
from pathlib import Path
import platform

import uv
import click

from ._version import __version__


INSTALL_RAN = False


def default_execution(*args):
    if not INSTALL_RAN:
        # If the use didn't use the install command, we should show
        # a GUI to do the install.
        # This is nice for windows uses double-clicking on a bare tgzr cli.
        # We would do it by invoking the install with an additionnal package
        # like `tgzr.shell.gui_install` and run that installer.
        # TODO: implement it.
        # But for now:
        print(
            "I know I should show you an intaller GUI right now, but I dont have one yet ¯\\_(ツ)_/¯"
        )


@click.group(
    context_settings={"help_option_names": ["-h", "--help"]},
    invoke_without_command=True,
    result_callback=default_execution,
)
@click.version_option(version=__version__, prog_name="tgzr")
def installer_cli():
    pass


@installer_cli.command()
@click.option(
    "-n",
    "--name",
    default=None,
    help="Name of the Workspace to create (usually your studio name).",
)
@click.option(
    "-p",
    "--install-path",
    help="path to install to. Default to current dir. Created if needed.",
)
@click.option(
    "--default-index",
    help="The URL of the default package index (by default: <https://pypi.org/simple>).",
)
@click.option(
    "-f",
    "--find-links",
    help="path a folder containing packages to install. Usefull in no-internet situations.",
)
def install(name: str | None, install_path: str | None, default_index, find_links):
    """
    Install a fresh tgzr cli.
    """
    global INSTALL_RAN
    INSTALL_RAN = True

    if name is None:
        name = str(click.prompt(f"Workspace name", default="MyStudio"))
    name = name.replace(" ", "_")  # overall better + avoids code injection

    if install_path is None:
        cwd = Path.cwd().resolve()
        install_path = str(click.prompt(f"Install path", default=cwd))
        if not Path(install_path).is_absolute():
            install_path = str((cwd / install_path).resolve())

    workspace_path = Path(f"{install_path}/Workspaces/{name}")
    if workspace_path.exists():
        raise click.UsageError(
            f"The workspace {workspace_path} already exists. Aborting."
        )

    print(f"Installing tgzr at {install_path}, creating workspace {name}")

    venv_path = tempfile.mkdtemp(prefix="tgzr_install_tmp_venv")
    print("Creating temp venv:", venv_path)

    if 0:
        # This does not work as pyinstaller script: sys.executable is wrong so venv is messed up
        print(sys.executable)
        cmd = f"{sys.executable} -m uv venv --prompt TGZR_installer {venv_path}"
        print(cmd)
        ret = os.system(cmd)
        print("--->", ret)
    elif 0:
        # This does not work as pyinstaller script: sys.executable is wrong so venv is messed up
        import venv

        try:
            venv.main(["--without-pip", "--prompt", "TGZR-Installer", venv_path])
        except Exception:
            raise
    else:
        # This does work as pyinstaller script: we are delegating everything to uv

        # Use this to inspect the content of the pyinstaller archive when
        # we run as a pysintaller script:
        # if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        #     ROOT = sys._MEIPASS
        #     print("FROZEN CONTENT:", os.listdir(ROOT))

        try:
            # NOTE: this also works when we're a pysintaller script thanks to the
            # data arg of the Analysis in the pyinstall spec file:
            # it keeps the uv executable installed in your current venv
            # (it exists because we have uv in the project requirement)
            # and place it in a "bin" folder inside the pysintaller archive.
            # This bin folder is looked up by uv.find_uv_bin() so we're
            # good.
            uv_exe = uv.find_uv_bin()
        except Exception as err:
            # This should not occur ¯\\_(ツ)_/¯
            print("Oops, could not find uv:", err)
        else:
            cmd = f"{uv_exe} venv --prompt TGZR-Installer {venv_path}"
            ret = os.system(cmd)
            if ret:
                raise Exception("Error creating venv with cmd: {cmd}")

        # Install tgzr.cli and tgzr.shell in the temp venv:
        default_index_options = ""
        if default_index:
            default_index_options = f"--default-index {default_index}"

        find_links_options = ""
        if find_links:
            find_links_options = f"--find-links {find_links}"

        cmd = f"{uv_exe} pip install {default_index_options} {find_links_options} --python {venv_path} tgzr.cli tgzr.shell"
        ret = os.system(cmd)
        if ret:
            raise Exception("Error installing packages in venv with cmd: {cmd}")

        # Use tgzr.cli from the temp venv to create the Workspace:
        if 0:
            # IDKW but this does not work, it runs the orignal tgzr cmd :[
            cmd = f"{uv_exe} run --python {venv_path} tgzr --cwd {install_path} ws create {name}"
        else:
            if platform.system() == "Windows":
                tgzr_exe = f"{venv_path}/Scripts/tgzr"
            else:
                tgzr_exe = f"{venv_path}/bin/tgzr"
        cmd = f"{tgzr_exe} --cwd {install_path} ws create {name}"
        ret = os.system(cmd)
        if ret:
            raise Exception(f"Error creating Workspace with cmd: {cmd}")

        click.echo("\n\n✨ tgzr successfully installed ✨")
        click.echo(f"You can now go and use {install_path}/Workspaces/{name}/tgzr")
