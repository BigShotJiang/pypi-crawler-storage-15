import sys


def main():
    has_shell = True
    try:
        import tgzr.shell
    except ImportError:
        has_shell = False

    if getattr(sys, "frozen", False) or not has_shell:
        # We are
        # - running in a pyinstaller executable
        #   and entry-points are not available in this mode,
        #   so the cmd line will not find the plugins.
        # or:
        # - we are missing the mandatory plugin from tgzr.shell.
        #
        # In this situation, we only ,provide the install command:
        print("INFO: Running without plugins, please run `tgzr install`")
        # Note that if someone uninstall tgzr.shell in a workspace venv,
        # tgzr.cli will then automatically run a installer only mode :/
        # TODO: fix it if it ever becomes a concern ¯\_(ツ)_/¯
        from tgzr.cli.installer_cli import installer_cli

        sys.exit(installer_cli())
    else:
        from tgzr.cli.main_cli import tgzr_cli

        sys.exit(tgzr_cli())
