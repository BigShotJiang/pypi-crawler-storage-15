def answer_to_the_universe() -> int:
    return 42
