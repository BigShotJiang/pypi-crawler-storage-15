"""
Utility functions for Google Calendar tool authentication and error handling in the Arklex framework.
"""

AUTH_ERROR: str = "Google Calendar authentication failed"
