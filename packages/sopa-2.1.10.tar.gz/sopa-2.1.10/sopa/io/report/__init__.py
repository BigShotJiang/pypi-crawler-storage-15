from .generate import write_report
