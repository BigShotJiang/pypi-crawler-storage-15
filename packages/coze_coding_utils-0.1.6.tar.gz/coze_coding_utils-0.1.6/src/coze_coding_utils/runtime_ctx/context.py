import os
import uuid
from dataclasses import dataclass
from typing import Optional, Dict, Mapping

# Header keys
HEADER_X_TT_LOGID = "x-tt-logid"
HEADER_X_TT_ENV = "x-tt-env"
HEADER_X_USE_PPE = "x-use-ppe"
HEADER_X_TT_ENV_FE = "x-tt-env-fe"
HEADER_BENEFIT_BIZ_SCENE = "benefit-biz-scene"

# Environment variable keys
ENV_SPACE_ID = "COZE_PROJECT_SPACE_ID"
ENV_PROJECT_ID = "COZE_PROJECT_ID"


@dataclass(slots=True)
class Context:
    """运行时上下文，封装请求关联的标识与环境信息。"""
    run_id: str
    space_id: str
    project_id: str
    logid: str = ""
    method: str = ""
    x_tt_env: Optional[str] = None
    x_use_ppe: Optional[str] = None
    x_tt_env_fe: Optional[str] = None
    benefit_biz_scene: Optional[str] = None


def new_context(method: str, headers: Optional[Mapping[str, str]] = None) -> Context:
    """创建上下文对象，读取必要环境变量并可从请求头补充可选字段。"""
    ctx = Context(
        run_id=str(uuid.uuid4()),
        space_id=os.getenv(ENV_SPACE_ID, ""),
        project_id=os.getenv(ENV_PROJECT_ID, ""),
        method=method,
    )
    if headers:
        if HEADER_X_TT_LOGID in headers:
            ctx.logid = headers[HEADER_X_TT_LOGID]
        if HEADER_X_TT_ENV in headers:
            ctx.x_tt_env = headers[HEADER_X_TT_ENV]
        if HEADER_X_USE_PPE in headers:
            ctx.x_use_ppe = headers[HEADER_X_USE_PPE]
        if HEADER_X_TT_ENV_FE in headers:
            ctx.x_tt_env_fe = headers[HEADER_X_TT_ENV_FE]
        if HEADER_BENEFIT_BIZ_SCENE in headers:
            ctx.benefit_biz_scene = headers[HEADER_BENEFIT_BIZ_SCENE]
    return ctx


def default_headers(ctx: Context | None) -> Dict[str, str]:
    """从上下文生成请求头字典，仅包含已设置的字段。"""
    if not ctx:
        return {}
    headers: Dict[str, str] = {}
    if ctx.logid:
        headers[HEADER_X_TT_LOGID] = ctx.logid
    if ctx.x_tt_env:
        headers[HEADER_X_TT_ENV] = ctx.x_tt_env
    if ctx.x_use_ppe:
        headers[HEADER_X_USE_PPE] = ctx.x_use_ppe
    if ctx.x_tt_env_fe:
        headers[HEADER_X_TT_ENV_FE] = ctx.x_tt_env_fe
    if ctx.benefit_biz_scene:
        headers[HEADER_BENEFIT_BIZ_SCENE] = ctx.benefit_biz_scene
    return headers

__all__ = [
    "Context",
    "new_context",
]
