import os


TEST_DATA_PATH = os.path.dirname(__file__)
