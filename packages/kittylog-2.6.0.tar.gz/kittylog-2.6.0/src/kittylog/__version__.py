"""Version information for kittylog."""

__version__ = "2.6.0"
