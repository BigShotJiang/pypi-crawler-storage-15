JOB_GPU_NUMBER = 0
JOB_GPU_MODEL = "nvidia-tesla-k80"
JOB_CPU_NUMBER = 0.1
PRESET_PRICE = 0
JOB_MEMORY_AMOUNT = "1GB"
JOB_DEBUG_LOCAL_PORT = 31234
JOB_SSH_USER = "root"

GPU_MODELS = ("nvidia-tesla-k80", "nvidia-tesla-p4", "nvidia-tesla-v100")
