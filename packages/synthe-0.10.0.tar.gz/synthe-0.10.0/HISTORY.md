# History

## 0.1.0 (2025-09-27)

* First release on PyPI.
