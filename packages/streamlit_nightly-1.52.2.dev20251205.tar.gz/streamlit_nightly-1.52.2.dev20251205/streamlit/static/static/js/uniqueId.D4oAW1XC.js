import{H as i}from"./index.DKGQ2IXJ.js";var n=0;function u(r){var t=++n;return i(r)+t}export{u};
