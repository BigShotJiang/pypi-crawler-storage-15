"""Tests for circuit breaker listeners."""
