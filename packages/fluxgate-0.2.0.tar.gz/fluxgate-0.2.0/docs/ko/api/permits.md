# API: Permit

이 페이지는 사용 가능한 Permit을 문서화합니다. Permit은 `HALF_OPEN` 상태 동안 서비스 복구를 테스트하기 위해 얼마나 많은 검증 호출이 통과되도록 허용되는지 제어합니다.

Permit 선택에 대한 개요는 [Permits 컴포넌트 가이드](../components/permits.md)를 참조하십시오.

---

::: fluxgate.permits.Random

::: fluxgate.permits.RampUp
