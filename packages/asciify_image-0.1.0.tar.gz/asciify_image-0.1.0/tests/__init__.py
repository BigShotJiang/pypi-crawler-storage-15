"""Tests for asciify."""
