# 🚀 E-commerce API - Python Server

A configurable HTTP stub server for testing and development, built with Flask.

---

## 📁 Project Structure

```
📁 OJTpython/
│
├── 📄 server.py              # Main Python server
├── 📄 data.py                # Product catalog (60+ products)
├── 📄 config.json            # API endpoints configuration
├── 📄 requirements.txt       # Python dependencies
├── 📄 .gitignore             # Git ignore rules
│
├── 📁 scripts/               # Utility scripts
│   ├── install.bat           # Setup script (Windows)
│   ├── run.bat               # Quick start script
│   └── test_api.py           # Automated testing
│
├── 📁 docs/                  # Documentation
│   ├── START_HERE.md         # 👈 Start here!
│   ├── README_PYTHON.md      # Complete guide
│   ├── QUICK_START_HINDI.md  # Hindi setup guide
│   ├── DEMO_CHECKLIST.md     # Demo preparation
│   ├── POSTMAN_TESTING_GUIDE.md
│   ├── NODEJS_VS_PYTHON.md
│   └── ... (other guides)
│
└── 📁 logs/                  # Server logs
    └── requests.log          # API request logs
```

---

## ⚡ Quick Start

### Option 1: Using Scripts (Windows)
```bash
# Install dependencies
scripts\install.bat

# Start server
scripts\run.bat
```

### Option 2: Manual
```bash
# Install dependencies
pip install -r requirements.txt

# Start server
python server.py
```

### Option 3: Test Everything
```bash
python scripts\test_api.py
```

---

## 🌐 Server Info

**Port:** 5600  
**URL:** http://localhost:5600

**Status Check:**
```bash
curl http://localhost:5600
```

---

## 📚 Documentation

- **📖 [START_HERE.md](docs/START_HERE.md)** - Quick overview
- **📘 [README_PYTHON.md](docs/README_PYTHON.md)** - Complete documentation
- **🇮🇳 [QUICK_START_HINDI.md](docs/QUICK_START_HINDI.md)** - Hindi guide
- **🎯 [DEMO_CHECKLIST.md](docs/DEMO_CHECKLIST.md)** - Demo preparation
- **📮 [POSTMAN_TESTING_GUIDE.md](docs/POSTMAN_TESTING_GUIDE.md)** - API testing

---

## 🎯 Features

✅ **Authentication** - Token-based security  
✅ **Dynamic Routing** - Config-driven endpoints  
✅ **Template Variables** - `{{timestamp}}`, `{{randomId}}`, etc.  
✅ **Request Logging** - All API calls logged  
✅ **60+ Products** - Complete e-commerce catalog  
✅ **15+ Endpoints** - Full shopping flow  

---

## 🔑 API Endpoints

### Authentication
- `POST /register` - Create account
- `POST /login` - User login

### Products (Auth Required)
- `GET /categories` - All categories
- `GET /categories/:id` - Category details
- `GET /categories/:id/subcategories/:id` - Products list
- `GET /categories/:id/subcategories/:id/products/:id` - Product details

### Shopping (Auth Required)
- `POST /cart/add` - Add to cart
- `GET /cart` - View cart
- `POST /order/place` - Place order
- `GET /orders` - Order history
- `GET /order/:id` - Track order

---

## 🧪 Testing

### Automated Testing
```bash
python scripts\test_api.py
```

### Manual Testing (Postman)
See [POSTMAN_TESTING_GUIDE.md](docs/POSTMAN_TESTING_GUIDE.md)

---

## 📊 Tech Stack

- **Python 3.8+**
- **Flask 3.0.0** - Web framework
- **Flask-CORS 4.0.0** - Cross-origin support
- **Watchdog 3.0.0** - File monitoring

---

## 🎓 For Students/Demo

This project is perfect for:
- ✅ Academic presentations
- ✅ API development learning
- ✅ Backend testing
- ✅ Postman demonstrations

**Demo Time:** 10-12 minutes  
**Difficulty:** Beginner-friendly  

---

## 📝 Logs

All API requests are logged to:
```
logs/requests.log
```

Each entry includes:
- Timestamp
- HTTP method
- URL path
- Status code
- Response time

---

## 🤝 Contributing

This is a learning project. Feel free to:
- Add more endpoints
- Enhance features
- Improve documentation

---

## 📄 License

MIT License - Free to use for learning and development

---

## 🆘 Need Help?

1. Check [START_HERE.md](docs/START_HERE.md)
2. Read [QUICK_START_HINDI.md](docs/QUICK_START_HINDI.md)
3. Review [DEMO_CHECKLIST.md](docs/DEMO_CHECKLIST.md)

---

**Made with ❤️ for learning Python backend development**
