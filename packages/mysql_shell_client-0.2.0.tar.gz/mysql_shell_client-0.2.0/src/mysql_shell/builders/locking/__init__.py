# Copyright 2025 Canonical Ltd.
# See LICENSE file for licensing details.

from .base import BaseLockingQueryBuilder
from .charm import CharmLockingQueryBuilder
