from pathlib import Path

PKG_NAME = Path(__file__).parent.parent.stem
