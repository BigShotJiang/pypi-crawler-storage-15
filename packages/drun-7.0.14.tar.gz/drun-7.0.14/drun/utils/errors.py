from __future__ import annotations


class LoadError(Exception):
    pass


class ValidationFailure(Exception):
    pass

