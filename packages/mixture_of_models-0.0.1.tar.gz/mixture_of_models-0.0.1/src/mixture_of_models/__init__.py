"""
Placeholder package for the Mixture-of-Models (mom) system.

This release only reserves the PyPI namespace `mixture-of-models`.
"""

__version__ = "0.0.1"
