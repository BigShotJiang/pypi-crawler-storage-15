# mixture-of-models

This package exists only to reserve the `mixture-of-models` name on PyPI
for a future open-source release of the Mixture-of-Models (mom) reasoning engine.

No public API is available yet.
