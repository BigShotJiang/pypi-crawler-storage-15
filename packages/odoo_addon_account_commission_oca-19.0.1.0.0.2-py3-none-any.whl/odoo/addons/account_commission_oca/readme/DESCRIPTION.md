This module adds the function to calculate commissions in invoices
(account moves).

It also allows to create vendor bills from settlements for external
agents.

This module depends on the commission module.
