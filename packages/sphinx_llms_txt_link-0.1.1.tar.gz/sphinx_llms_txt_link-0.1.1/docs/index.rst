.. include:: ../README.rst
.. include:: documentation.rst
