
Package
=======

.. toctree::
   :maxdepth: 20

   sphinx_llms_txt_link

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
