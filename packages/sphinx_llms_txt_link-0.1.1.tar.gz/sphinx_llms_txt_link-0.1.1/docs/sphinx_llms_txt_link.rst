sphinx\_no\_pragma module
=========================

.. automodule:: sphinx_llms_txt_link
   :members:
   :undoc-members:
   :show-inheritance:
