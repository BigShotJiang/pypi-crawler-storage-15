"""Enable running vtk_rag as a module: python -m vtk_rag"""

from .cli import main

if __name__ == "__main__":
    main()
