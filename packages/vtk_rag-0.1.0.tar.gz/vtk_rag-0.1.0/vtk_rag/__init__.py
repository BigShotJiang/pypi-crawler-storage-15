"""VTK RAG - Retrieval-Augmented Generation system for VTK Python documentation."""

__version__ = "0.1.0"
