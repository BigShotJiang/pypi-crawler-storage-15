from .register import register_vector

# TODO remove
from .. import HalfVector, SparseVector

__all__ = [
    'register_vector',
    'HalfVector',
    'SparseVector'
]
