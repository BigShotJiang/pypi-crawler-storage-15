from .register import register_vector

# TODO remove
from .. import Vector, HalfVector, SparseVector

__all__ = [
    'register_vector',
    'Vector',
    'HalfVector',
    'SparseVector'
]
