# TODO: Parquet/CSV writers + provenance metadata handling
