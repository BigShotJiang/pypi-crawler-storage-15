# TODO: country detection, grid creation, clipping (geopandas)
