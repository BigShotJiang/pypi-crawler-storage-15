"""CapInvest MCP Server package."""
