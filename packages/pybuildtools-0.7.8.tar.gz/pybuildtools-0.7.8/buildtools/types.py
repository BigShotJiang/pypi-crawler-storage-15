"""
BLURB GOES HERE.

Copyright (c) 2015 - 2025 Rob "N3X15" Nelson <nexisentertainment@gmail.com>

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

"""

import os
from abc import abstractmethod
from typing import Container, Iterable, Iterator, Protocol, TypeVar, Union, runtime_checkable

StrOrPath = os.PathLike

T = TypeVar("T")


@runtime_checkable
class SupportsContains(Protocol[T]):
    """An ABC with one abstract method __contains__."""

    __slots__ = ()

    @abstractmethod
    def __contains__(self, other: T) -> bool:
        pass


@runtime_checkable
class SupportsIter(Protocol[T]):
    """An ABC with one abstract method __iter__."""

    __slots__ = ()

    @abstractmethod
    def __iter__(self) -> Iterator[T]:
        pass


# SupportsIn = Union[SupportsContains[T],SupportsIter[T]]
SupportsIn = Union[Container[T], Iterable[T]]
