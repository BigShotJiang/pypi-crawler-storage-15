#!/usr/bin/env python

def scaleMain():
    from argparse         import ArgumentParser, FileType
    from pywargame.common import Verbose
    from pywargame.vassal import SaveIO
    from pywargame        import version_string

    ap = ArgumentParser(description='Scale a .vsav file')
    ap.add_argument('input',type=FileType('rb'),help='Input save')
    ap.add_argument('-o','--output',type=str,help='Output file')
    ap.add_argument('-f','--factor',type=float,default=1,
                    help='Scaling factor')
    ap.add_argument('-m','--also-meta',action='store_true',
                    help='Also read meta data')
    ap.add_argument('--version',action='version',version=version_string)
    ap.add_argument('--verbose','-V',action='store_true',help='Be verbose')

    args = ap.parse_args()

    Verbose().setVerbose(args.verbose)

    SaveIO.scaleSave(args.input, args.output, args.factor, args.also_meta)

if __name__ == '__main__':
    scaleMain()
