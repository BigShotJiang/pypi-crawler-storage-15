# --------------------------------------------------------------------
# XML Dom parser namespace
import xml.dom.minidom as xmlns
#import xml.dom as xmlns
