from fastapi import APIRouter, Request, HTTPException
from .secret_provider import get_secret

router = APIRouter()

@router.get("/__verge__/routes", include_in_schema=False)
async def verge_internal_routes(request: Request):

    expected = get_secret("VERGE_SERVICE_SECRET")
    received = request.headers.get("X-Verge-Service-Secret")

    # Validate secret
    if expected and received != expected:
        raise HTTPException(status_code=403, detail="Forbidden")

    collected = []

    for route in request.app.routes:
        path = getattr(route, "path", None)
        methods = getattr(route, "methods", [])

        # Skip if no path
        if not path:
            continue

        # Skip SDK-internal paths
        if path.startswith("/__verge__"):
            continue

        for m in methods:
            if m in ("GET", "POST", "PUT", "PATCH", "DELETE"):
                collected.append({
                    "path": path,
                    "method": m
                })

    return collected
