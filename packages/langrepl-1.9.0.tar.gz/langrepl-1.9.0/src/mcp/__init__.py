"""MCP module for Model Context Protocol integration."""
