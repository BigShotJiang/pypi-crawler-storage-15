def noop_task(*args, **kwargs):
    print("noop_task", args, kwargs)
    return True
