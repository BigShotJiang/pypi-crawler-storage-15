__version__ = "0.4.1"

from .boss import BOSS

__all__ = ["BOSS"]
