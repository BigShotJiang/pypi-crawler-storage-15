"""Sloppy - Python AI Slop Detector."""

__version__ = "0.1.0"
