#!/usr/bin/env python3
"""
Oscilloscope measurement implementation for both PicoScope and Rigol devices.

For Rigol: Uses VISA/SCPI commands via the Net/Mapper infrastructure
For PicoScope: Measurements are not supported (use streaming instead)
"""

import os
import json
import sys

# ANSI color codes
GREEN = '\033[92m'
RED = '\033[91m'
YELLOW = '\033[93m'
RESET = '\033[0m'

# Constants
LOCAL_NETS_PATH = "/etc/lager/saved_nets.json"


def load_saved_nets():
    """Load nets from the saved nets file."""
    try:
        with open(LOCAL_NETS_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return []
    except Exception as e:
        print(f"{RED}Error loading saved nets: {e}{RESET}", file=sys.stderr)
        return []


def get_net_info(netname):
    """Get net info by name from saved nets."""
    nets = load_saved_nets()
    for net in nets:
        if net.get("name") == netname and net.get("role") == "scope":
            return net
    return None


def is_picoscope(net_info):
    """Check if the net is a PicoScope based on instrument name."""
    if not net_info:
        return False
    instrument = net_info.get("instrument", "").lower()
    return "pico" in instrument or "picoscope" in instrument


def is_rigol(net_info):
    """Check if the net is a Rigol oscilloscope."""
    if not net_info:
        return False
    instrument = net_info.get("instrument", "").lower()
    return "rigol" in instrument or "mso" in instrument


def get_rigol_net(netname):
    """Get a Rigol Net object using Net.get()."""
    from lager.pcb.net import Net
    from lager.pcb.constants import NetType

    # Get the net using Net.get() which handles loading from saved nets
    net = Net.get(netname, NetType.Analog)
    return net


# ============ Measurement functions ============

def measure_vavg(netname, display, cursor):
    net = get_rigol_net(netname)
    return net.measurement.voltage_average(display=display, measurement_cursor=cursor)


def measure_vmax(netname, display, cursor):
    net = get_rigol_net(netname)
    return net.measurement.voltage_max(display=display, measurement_cursor=cursor)


def measure_vmin(netname, display, cursor):
    net = get_rigol_net(netname)
    return net.measurement.voltage_min(display=display, measurement_cursor=cursor)


def measure_vpp(netname, display, cursor):
    net = get_rigol_net(netname)
    return net.measurement.voltage_peak_to_peak(display=display, measurement_cursor=cursor)


def measure_vrms(netname, display, cursor):
    net = get_rigol_net(netname)
    return net.measurement.voltage_rms(display=display, measurement_cursor=cursor)


def measure_period(netname, display, cursor):
    net = get_rigol_net(netname)
    return net.measurement.period(display=display, measurement_cursor=cursor)


def measure_freq(netname, display, cursor):
    net = get_rigol_net(netname)
    return net.measurement.frequency(display=display, measurement_cursor=cursor)


def measure_dc_pos(netname, display, cursor):
    net = get_rigol_net(netname)
    return net.measurement.duty_cycle_positive(display=display, measurement_cursor=cursor)


def measure_dc_neg(netname, display, cursor):
    net = get_rigol_net(netname)
    return net.measurement.duty_cycle_negative(display=display, measurement_cursor=cursor)


def measure_pw_pos(netname, display, cursor):
    net = get_rigol_net(netname)
    return net.measurement.pulse_width_positive(display=display, measurement_cursor=cursor)


def measure_pw_neg(netname, display, cursor):
    net = get_rigol_net(netname)
    return net.measurement.pulse_width_negative(display=display, measurement_cursor=cursor)


def main():
    command = json.loads(os.environ.get('LAGER_COMMAND_DATA', '{}'))
    action = command.get('action', '')
    params = command.get('params', {})
    netname = params.get('netname')

    if not netname:
        print(f"{RED}No netname provided{RESET}", file=sys.stderr)
        sys.exit(1)

    # Check if it's a PicoScope - measurements not supported
    net_info = get_net_info(netname)
    if is_picoscope(net_info):
        print(f"{YELLOW}Measurements are not supported for PicoScope devices.{RESET}")
        print(f"{YELLOW}Use 'lager scope {netname} stream start' for streaming data.{RESET}")
        sys.exit(0)

    # Rigol measurements
    actions = {
        'measure_vavg': measure_vavg,
        'measure_vmax': measure_vmax,
        'measure_vmin': measure_vmin,
        'measure_vpp': measure_vpp,
        'measure_vrms': measure_vrms,
        'measure_period': measure_period,
        'measure_freq': measure_freq,
        'measure_dc_pos': measure_dc_pos,
        'measure_dc_neg': measure_dc_neg,
        'measure_pulse_width_pos': measure_pw_pos,
        'measure_pulse_width_neg': measure_pw_neg,
    }

    if action in actions:
        try:
            display = params.get('display', False)
            cursor = params.get('cursor', False)
            result = actions[action](netname, display, cursor)
            print(f"{GREEN}{result}{RESET}")
        except Exception as e:
            print(f"{RED}Error: {e}{RESET}", file=sys.stderr)
            sys.exit(1)
    else:
        print(f"{RED}Unknown action: {action}{RESET}", file=sys.stderr)
        print(f"Available actions: {', '.join(actions.keys())}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
