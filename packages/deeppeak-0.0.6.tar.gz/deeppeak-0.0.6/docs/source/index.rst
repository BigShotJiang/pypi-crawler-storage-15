**Date**: |today|, **Version**: |version|


.. include:: ../../README.rst
    :start-line: 0

.. toctree::
    :hidden:

    code.rst
    gallery/index.rst
    theory.rst
    references.rst
