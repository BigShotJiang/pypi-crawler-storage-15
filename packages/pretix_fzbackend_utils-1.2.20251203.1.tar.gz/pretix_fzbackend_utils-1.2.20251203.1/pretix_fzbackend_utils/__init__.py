__version__ = "1.2.20251203.1"

import logging

logging.getLogger(__package__).setLevel(logging.DEBUG)
