import logging

logging.getLogger(__package__).setLevel(logging.DEBUG)
