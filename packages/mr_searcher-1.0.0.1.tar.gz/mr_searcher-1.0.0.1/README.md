# 🔍 Mr. Searcher CLI: The Terminal Information Utility

[![PyPI - Version](https://img.shields.io/pypi/v/mr-searcher?color=blue)](https://pypi.org/project/mr-searcher/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python Version](https://img.shields.io/badge/Python-3.8+-blue)](https://www.python.org/downloads/)

A powerful, non-hostile, and self-contained command-line utility for information retrieval, system diagnostics, and entertainment. **Mr. Searcher** allows you to perform specialized searches, play media, change themes, and run system checks—all without leaving your terminal.
## ⚖️ Important Legal Disclaimer

**Mr. Searcher CLI is a general-purpose information retrieval and utility tool.**

The user of this software is solely responsible for ensuring that their use complies with all local, national, and international laws, particularly concerning:

1.  **Copyright:** The media download feature (`{fetch}`) should only be used to download content that you have the legal right to access and retain.
2.  **Conduct:** The authors and contributors of Mr. Searcher are not liable for any misuse of the software for illegal activities. By using this software, you agree to assume full responsibility for all actions taken.
---

## ✨ Features at a Glance

* **DuckDuckGo Search:** Fast, private searching with specialized filters.
* **Media Downloader:** Use the `{fetch}` command to download audio/video via `yt-dlp`.
* **Terminal Art & Themes:** Customize your terminal experience with `{animart}` and `{theme}`.
* **System Diagnostics:** Check real-time CPU and Memory usage with `{sysinfo}`.
* **Local Media Player:** Simple music player controls using `{play}`, `{pause}`, etc.

---

## 🛠️ Installation

### 1. Python Package Installation

Install the latest version directly from PyPI:

```bash
pip install mr-searcher
```
## Dependency
### yt-dlp & ffmpeg

### Purpose,How to Install (Example for Debian/Ubuntu)

## yt-dlp
### The core downloader for video/audio.
```bash
sudo apt install yt-dlp
``` 
or see their official documentation.
## ffmpeg
### Used for converting downloads (e.g., to MP3).
```bash 
sudo apt install ffmpeg
``` 
 or see official documentation.