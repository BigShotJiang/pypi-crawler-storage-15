"""package for feature extraction based on static objects located in the enclosure."""

from .landmark_group import LandmarkFeatureGroup
