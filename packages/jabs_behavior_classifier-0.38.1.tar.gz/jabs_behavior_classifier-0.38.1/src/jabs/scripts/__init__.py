"""jabs scripts module"""

__all__ = []
