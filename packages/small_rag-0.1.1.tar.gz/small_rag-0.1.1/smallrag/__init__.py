"""Top-level package for small-rag."""
from .core import SmallRAG


__all__ = ["SmallRAG"]