# compute enrichment via FET

# first for only simple terms,
# continue with communities
