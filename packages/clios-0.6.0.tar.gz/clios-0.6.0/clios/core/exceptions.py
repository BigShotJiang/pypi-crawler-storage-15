class CliosError(Exception):
    pass
