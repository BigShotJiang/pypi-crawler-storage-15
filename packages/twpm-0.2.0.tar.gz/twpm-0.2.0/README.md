# Twpm

A simple workflow builder that takes the complexity out of building dynamic workflows

## Installation

```sh
uv add twpm
``` 

## Usages

## Architecture and Data structures

## Features

## Contributing

## License

MIT