# Copyright (c) 2004 Adam Karpierz
# SPDX-License-Identifier: Zlib

__import__("pkg_about").about("py-utlx")
