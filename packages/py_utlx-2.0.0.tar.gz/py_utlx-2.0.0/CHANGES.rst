Changelog
=========

2.0.0 (2025-11-30)
------------------
- utlx.platform.*.capi - added in_addr_t
- utlx.platform.windows - added winapi
- utlx.platform.macos - added macos_version()
- run(): cleanup and improvements.
- Much better typing.
- Some minor cleanup and unifications.
- Version number alignment (-> 2.x.x).
- Copyright year update.
- Add tox's tool.tox.env.cleanup testenv.
- Setup (dependencies) update.

1.0.0 (2025-09-09)
------------------
- Making and mark the package typed.
- 100% code linting.
- 100% code coverage.
- Setup (dependencies) update.

0.1.0 (2025-09-01)
------------------
- First public release.

0.0.0 (2025-07-17)
------------------
- Initial commit.
