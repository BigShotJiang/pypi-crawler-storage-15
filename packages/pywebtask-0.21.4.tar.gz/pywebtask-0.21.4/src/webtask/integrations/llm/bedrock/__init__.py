"""AWS Bedrock LLM integration."""

from .bedrock import Bedrock

__all__ = ["Bedrock"]
