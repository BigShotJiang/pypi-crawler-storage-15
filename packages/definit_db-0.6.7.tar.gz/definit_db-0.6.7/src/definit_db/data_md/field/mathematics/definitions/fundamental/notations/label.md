# label


A label is a name, number, or symbol attached to an [object](mathematics/object) to give it 
meaning or identify it.

