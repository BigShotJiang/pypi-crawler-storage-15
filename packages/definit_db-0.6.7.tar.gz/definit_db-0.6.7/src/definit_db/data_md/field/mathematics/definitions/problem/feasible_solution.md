# feasible solution


[feasible solution](mathematics/feasible solution) is a [solution](mathematics/solution) to a [problem](mathematics/problem) 
that satisfies all the [constraints](mathematics/constraint). A feasible solution may not be optimal, 
but it meets all the requirements and restrictions of the problem.

