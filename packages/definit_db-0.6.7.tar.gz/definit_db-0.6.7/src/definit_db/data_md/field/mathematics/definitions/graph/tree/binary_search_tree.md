# binary_search_tree


A special case of a [b_tree](mathematics/b_tree) in that a [node](mathematics/node) 
can only have maximum two children.

