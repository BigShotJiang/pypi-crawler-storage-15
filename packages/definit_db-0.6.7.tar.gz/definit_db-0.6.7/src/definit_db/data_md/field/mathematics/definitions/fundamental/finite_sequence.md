# finite_sequence


A [sequence](mathematics/sequence) that has a finite number of 
[objects](mathematics/object). Informally, a finite sequence is a sequence which one could in 
principle count and finish counting. For example, (2,4,6,8,10) is a finite sequence with five elements.

