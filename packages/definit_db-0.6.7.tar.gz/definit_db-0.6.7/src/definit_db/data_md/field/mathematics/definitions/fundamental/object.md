# object


An object is an abstract concept arising in mathematics. 
Typically, a mathematical object can be a value that can be assigned to a symbol.

