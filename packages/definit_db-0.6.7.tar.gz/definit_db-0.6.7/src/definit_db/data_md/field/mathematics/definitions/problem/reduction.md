# reduction


Reduction refers to the rewriting of an expression into a simpler form. It is process of transforming a 
[problem](mathematics/problem) into a simpler or smaller instance of the same or a 
[related](mathematics/relation) problem, often to make it easier to solve.

