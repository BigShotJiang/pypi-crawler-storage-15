# last in first out


[last in first out](mathematics/last in first out) is an ordering principle where the most recently added element in a [sequence](mathematics/sequence) 
is the first one to be removed. In this scheme, the last element that enters is the first one to exit, 
similar to a stack of plates where you can only access the top plate.

