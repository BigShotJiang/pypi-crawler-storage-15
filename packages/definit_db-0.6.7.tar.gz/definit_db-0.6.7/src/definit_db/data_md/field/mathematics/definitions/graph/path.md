# path


A path in a [graph](mathematics/graph) is a [finite](mathematics/finite_set) or 
infinite sequence of [edges](mathematics/edge) which joins a sequence of 
[nodes](mathematics/node) which, by most definitions, are all distinct (and since the nodes are 
distinct, so are the edges).

