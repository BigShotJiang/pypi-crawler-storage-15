# recursion


A method of solving a [problem](mathematics/problem) where the [solution](mathematics/solution) depends on solutions 
to smaller instances of the same problem. Recursion involves a [function](mathematics/function) calling itself with 
simpler inputs until reaching a [base_case](mathematics/base_case).

