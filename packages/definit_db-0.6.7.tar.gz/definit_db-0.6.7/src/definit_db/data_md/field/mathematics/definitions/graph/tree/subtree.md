# subtree


A [tree](mathematics/tree) formed from a [node](mathematics/node) and all its 
descendants in a tree.

