# selection_sort


SelectionSort is a [sorting](mathematics/sorting) [algorithm](mathematics/algorithm) that sorts an 
[sequence](mathematics/sequence) by repeatedly finding the minimum (or maximum) element from the unsorted 
part and moving it to the beginning (or end). This process is repeated until the entire sequence is sorted.

