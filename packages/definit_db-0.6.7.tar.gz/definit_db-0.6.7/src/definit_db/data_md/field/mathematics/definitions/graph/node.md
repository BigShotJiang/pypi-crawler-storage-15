# node


A node (also called vertex) is an abstract entity that can represent an [object](mathematics/object) 
or position in a structure. It does not imply any connections or context on its own.

