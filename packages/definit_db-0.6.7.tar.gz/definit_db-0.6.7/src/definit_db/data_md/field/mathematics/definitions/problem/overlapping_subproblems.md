# overlapping_subproblems


A [problem](mathematics/problem) is said to have overlapping 
[subproblems](mathematics/subproblem) if the problem can be broken down into smaller, 
simpler subproblems that are reused several times.

