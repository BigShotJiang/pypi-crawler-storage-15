# directed_acyclic_graph


A directed acyclic graph is a [directed graph](mathematics/directed_graph) with no 
[cycles](mathematics/cycle).

