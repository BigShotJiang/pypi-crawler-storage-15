# set


Set is a group of different things. These things are called elements or members of the set and are typically 
mathematical [objects](mathematics/object) of any kind.

