# directed_graph


A directed graph is a [graph](mathematics/graph) in which the 
[edges](mathematics/edge) have a direction. Each edge connects an ordered pair of 
[nodes](mathematics/node), meaning that the connection goes from one node to another in a 
specific direction.

