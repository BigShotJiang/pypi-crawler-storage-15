# function


Function it is a kind of [relation](mathematics/relation) which from a set X to a set Y 
assigns to each element (or [object](mathematics/object)) of X exactly one element of Y.

