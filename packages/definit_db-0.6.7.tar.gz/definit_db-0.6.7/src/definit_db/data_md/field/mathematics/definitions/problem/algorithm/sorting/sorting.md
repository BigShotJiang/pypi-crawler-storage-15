# sorting


Sorting is an [algorithmic](mathematics/algorithm) process that arranges the elements of a 
[sequence](mathematics/sequence) or [set](mathematics/set) in a certain order, 
typically according to a specified [relation](mathematics/relation) (such as ascending or 
descending). 

