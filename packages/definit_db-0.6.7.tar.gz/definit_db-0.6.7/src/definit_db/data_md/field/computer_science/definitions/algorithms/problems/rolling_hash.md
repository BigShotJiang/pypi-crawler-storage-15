# rolling_hash


A rolling hash is an approach designed to enable efficient execution of the 
[hash function](mathematics/hash_function) when the input is modified incrementally, such as when 
a window of fixed size moves over a [sequence](mathematics/sequence).

