# variable


[variable](computer_science/variable) is a named storage location identified by a [label](mathematics/label) 
that holds [data](computer_science/data) which can be modified during program execution. 
A variable associates a name with a value that can change over time.

