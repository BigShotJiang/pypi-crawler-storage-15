# graph_coloring


A special case of [graph labeling](computer_science/graph_labeling) where the 
[labels](mathematics/label) are colors.

