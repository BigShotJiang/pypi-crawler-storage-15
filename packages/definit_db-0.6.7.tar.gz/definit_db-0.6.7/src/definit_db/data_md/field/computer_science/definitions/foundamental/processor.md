# processor


[processor](computer_science/processor) is a [hardware](computer_science/hardware) component of a [computer](computer_science/computer) 
that executes [instructions](mathematics/instruction) and performs [operations](computer_science/operation) 
on data. It is the central component responsible for carrying out the computational tasks defined by [programs](computer_science/program), 
often referred to as the central processing unit (CPU).

