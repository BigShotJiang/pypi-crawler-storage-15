# utf


UTF (Unicode Transformation Format) is a [character encoding](computer_science/character_encoding) 
standard that represents [Unicode](computer_science/unicode) characters using variable-length sequences 
of bytes.

