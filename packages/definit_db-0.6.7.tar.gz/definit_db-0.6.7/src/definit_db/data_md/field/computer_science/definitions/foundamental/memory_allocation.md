# memory allocation


[memory allocation](computer_science/memory allocation) is the [operation](computer_science/operation) of assigning a block of [computer memory](computer_science/computer memory) 
to store [data](computer_science/data) for use by a [program](computer_science/program). It determines where and how much memory 
is reserved for storing [information](mathematics/information) during program execution.

