# hardware


[hardware](computer_science/hardware) refers to the physical components of a [computer](computer_science/computer) system. 
These are tangible parts that can be touched and manipulated.

