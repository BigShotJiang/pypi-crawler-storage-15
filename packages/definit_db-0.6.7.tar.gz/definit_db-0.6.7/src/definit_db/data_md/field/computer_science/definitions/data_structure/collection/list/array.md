# array


Array is a [list](computer_science/list) of elements of the same 
[type](computer_science/data_type).

