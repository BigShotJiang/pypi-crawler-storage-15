from definit_db.config import CONFIG

__version__ = "0.6.7"
__all__ = ["CONFIG"]
