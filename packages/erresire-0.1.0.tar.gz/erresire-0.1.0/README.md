<img width="403" height="150" alt="Erresire(2)" src="https://github.com/user-attachments/assets/17e22142-ca63-483d-b113-b656f44d3934" />



# Erresire

**Erresire** enables users to simulate **large populations of strong gravitational lenses** in an efficient and flexible manner via a Monte Carlo method.  
Users can customize the simulation by supplying catalogs of their choice for dark matter halos, galaxies, and sources.