# Frequenz Repository Configuration Release Notes

## New Features

* `mkdocs-gen-files` v0.6 is now supported.
