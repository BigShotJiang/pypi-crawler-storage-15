"""Director.y - AI-powered filesystem management via natural language."""

__version__ = "1.0.0"
