"""Forum v2 models."""

# pylint: disable=W0401
from forum.backends.mysql.models import *
