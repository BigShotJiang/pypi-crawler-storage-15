"""
Openedx forum app.
"""

__version__ = "0.3.9"
