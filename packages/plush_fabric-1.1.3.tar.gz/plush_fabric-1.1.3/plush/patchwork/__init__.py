# This directory contains code forked from https://github.com/LecrisUT/patchwork/tree/fabric3
# It will be removed when an official release of Patchwork is compatible with Fabric 3.
