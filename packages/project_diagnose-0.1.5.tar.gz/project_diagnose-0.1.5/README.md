# project-diagnose

Анализатор состояния кода с AI-вердиктами, индексом хаоса, прогнозом будущих страданий и web-интерфейсом.

## Установка

pip install project-diagnose

## Использование

project-diagnose full
project-diagnose web