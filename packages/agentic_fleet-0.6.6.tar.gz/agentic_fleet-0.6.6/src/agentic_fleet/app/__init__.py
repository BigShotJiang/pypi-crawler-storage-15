"""FastAPI application for AgenticFleet."""
