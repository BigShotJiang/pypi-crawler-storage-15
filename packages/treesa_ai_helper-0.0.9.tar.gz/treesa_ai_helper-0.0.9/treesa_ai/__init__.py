from .core import get_response
from .version import __version__

__all__ = ["get_response"]
