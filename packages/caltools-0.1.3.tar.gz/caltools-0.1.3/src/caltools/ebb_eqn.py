# src/caltools/ebb_eqn.py

def ebb_eqn(L, N, q0, EI,
                              w0=0.0, wL=0.0,
                              wpp0=0.0, wppL=0.0):
    """
    Build the finite-difference linear system for the Euler–Bernoulli beam

        EI * d^4 w / dx^4 = q0

    on a uniform grid x_i = i*h, i = 0,...,N with h = L/N.

    Boundary conditions (user-provided):
        w(0)   = w0
        w(L)   = wL
        w''(0) = wpp0
        w''(L) = wppL

    For example, a simply supported beam with uniform load:
        w0 = 0, wL = 0, wpp0 = 0, wppL = 0.

    Parameters
    ----------
    L : float
        Length of the beam.
    N : int
        Number of intervals (so N+1 grid points). Must be >= 4.
    q0 : float
        Uniform distributed load q(x) = q0.
    EI : float
        Flexural rigidity (E * I).
    w0 : float, optional
        Boundary value w(0).
    wL : float, optional
        Boundary value w(L).
    wpp0 : float, optional
        Second derivative at x = 0, w''(0).
    wppL : float, optional
        Second derivative at x = L, w''(L).

    Returns
    -------
    x : list[float]
        Grid points x_0,...,x_N.
    A : list[list[float]]
        Coefficient matrix for the linear system A w = b.
    b : list[float]
        Right-hand side vector.

    Notes
    -----
    This function only builds the system. To solve it, convert A and b to
    NumPy arrays and use numpy.linalg.solve, then plot with matplotlib.
    """

    if N < 4:
        raise ValueError("N must be at least 4 for 4th-order finite differences.")

    # grid spacing and points
    h = L / N
    x = [i * h for i in range(N + 1)]

    # initialize matrix and rhs
    A = [[0.0 for _ in range(N + 1)] for _ in range(N + 1)]
    b = [0.0 for _ in range(N + 1)]

    # --- Boundary condition 1: w(0) = w0 ---
    A[0][0] = 1.0
    b[0] = w0

    # --- Boundary condition 2: w''(0) = wpp0 ---
    # (w_0 - 2 w_1 + w_2) / h^2 = wpp0
    A[1][0] = 1.0
    A[1][1] = -2.0
    A[1][2] = 1.0
    b[1] = wpp0 * (h ** 2)

    # --- Interior points: 4th derivative ---
    # EI * w''''(x_i) = q0
    # → w_{i-2} - 4 w_{i-1} + 6 w_i - 4 w_{i+1} + w_{i+2} = (q0/EI) h^4
    rhs_val = (q0 / EI) * (h ** 4)

    for i in range(2, N - 1):  # i = 2,...,N-2
        A[i][i - 2] = 1.0
        A[i][i - 1] = -4.0
        A[i][i]     = 6.0
        A[i][i + 1] = -4.0
        A[i][i + 2] = 1.0
        b[i] = rhs_val

    # --- Boundary condition 3: w''(L) = wppL ---
    # (w_N - 2 w_{N-1} + w_{N-2}) / h^2 = wppL
    A[N - 1][N]     = 1.0
    A[N - 1][N - 1] = -2.0
    A[N - 1][N - 2] = 1.0
    b[N - 1] = wppL * (h ** 2)

    # --- Boundary condition 4: w(L) = wL ---
    A[N][N] = 1.0
    b[N] = wL

    return x, A, b
