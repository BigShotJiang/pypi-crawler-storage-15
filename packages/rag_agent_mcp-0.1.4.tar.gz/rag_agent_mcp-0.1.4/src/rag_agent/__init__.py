"""
MCP Server for RAG Agent API integration.
"""

__version__ = "0.1.4"
