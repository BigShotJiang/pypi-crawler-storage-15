"""Slash commands for Happy, Claude Code, and Codex."""
