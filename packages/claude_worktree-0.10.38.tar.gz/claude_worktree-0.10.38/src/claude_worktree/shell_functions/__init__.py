"""Shell function scripts for claude-worktree."""
