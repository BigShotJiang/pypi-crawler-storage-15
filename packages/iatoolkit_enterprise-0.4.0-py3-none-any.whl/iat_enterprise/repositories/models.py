# Copyright (c) 2024 Fernando Libedinsky
# Product: IAToolkit Enterprise
#
# IAToolkit Enterprise is commercial, proprietary software.
# Unauthorized copying, modification, distribution, or use of this software,
# via any medium, is strictly prohibited unless explicitly permitted by the
# Enterprise License Agreement provided to the customer.
#
# This file is part of the IAToolkit Enterprise Edition and may not be
# redistributed as open-source. For licensing information, refer to:
# ENTERPRISE_LICENSE

from sqlalchemy import Column, Integer, Numeric, BigInteger, String, DateTime, Enum, Text, JSON, Boolean, ForeignKey, Table
from sqlalchemy.orm import DeclarativeBase
from sqlalchemy.orm import relationship, class_mapper, declarative_base
from sqlalchemy.sql import func
from datetime import datetime
from iatoolkit import OrmModel


class PaymentTransaction(OrmModel):
    __tablename__ = 'iat_payments'

    id = Column(Integer, primary_key=True)
    company_short_name = Column(String)
    provider = Column(String)  # 'stripe', 'paypal'

    # transaction data
    transaction_external_id = Column(String)  # session with provider
    amount = Column(Numeric(10, 2))
    currency = Column(String)
    status = Column(String)  # 'pending', 'completed', 'failed'

    # Contexto
    user_identifier = Column(String)
    description = Column(String)
    metadata_json = Column(JSON)     # for saving: order_id, product_id, etc.

    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, onupdate=datetime.now)



