# Copyright (c) 2024 Fernando Libedinsky
# Product: IAToolkit Enterprise
#
# IAToolkit Enterprise is commercial, proprietary software.
# Unauthorized copying, modification, distribution, or use of this software,
# via any medium, is strictly prohibited unless explicitly permitted by the
# Enterprise License Agreement provided to the customer.
#
# This file is part of the IAToolkit Enterprise Edition and may not be
# redistributed as open-source. For licensing information, refer to:
# ENTERPRISE_LICENSE

from iat_enterprise.repositories.models import PaymentTransaction
from iatoolkit.repositories.database_manager import DatabaseManager
from injector import inject


class PaymentRepository:
    @inject
    def __init__(self, db_manager: DatabaseManager):
        self.session = db_manager.get_session()


    def create_transaction(self, company_short_name: str,
                           provider: str,
                           amount,
                           currency,
                           user_identifier: str,
                           description: str,
                           metadata=None,
                           external_id=None):
        """Logs a new payment intention."""
        tx = PaymentTransaction(
            company_short_name=company_short_name,
            provider=provider,
            amount=amount,
            currency=currency,
            user_identifier=user_identifier,
            description=description,
            metadata_json=metadata or {},
            transaction_external_id=external_id,
            status='pending'
        )
        self.session.add(tx)
        self.session.commit()
        return tx

    def update_status(self, transaction_id, status, external_id=None):
        """Updates the status of a transaction."""
        tx = self.session.query(PaymentTransaction).filter_by(id=transaction_id).first()
        if tx:
            tx.status = status
            if external_id:
                tx.transaction_external_id = external_id
            self.session.commit()
        return tx

    def get_by_external_id(self, external_id):
        return self.session.query(PaymentTransaction).filter_by(transaction_external_id=external_id).first()
