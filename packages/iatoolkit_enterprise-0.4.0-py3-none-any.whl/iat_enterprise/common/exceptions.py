# Copyright (c) 2024 Fernando Libedinsky
# Product: IAToolkit Enterprise
#
# IAToolkit Enterprise is commercial, proprietary software.
# Unauthorized copying, modification, distribution, or use of this software,
# via any medium, is strictly prohibited unless explicitly permitted by the
# Enterprise License Agreement provided to the customer.
#
# This file is part of the IAToolkit Enterprise Edition and may not be
# redistributed as open-source. For licensing information, refer to:
# ENTERPRISE_LICENSE


from enum import Enum


class IatEnterpriceException(Exception):

    class ErrorType(Enum):
        SYSTEM_ERROR = 0
        DATABASE_ERROR = 1
        LLM_ERROR = 2
        CLOUD_STORAGE_ERROR = 3
        DOCUMENT_NOT_FOUND = 4
        INVALID_PARAMETER = 5
        MISSING_PARAMETER = 6
        PARAM_NOT_FILLED = 7
        PERMISSION = 8
        EXIST = 9
        LICENSE_KEY = 10
        PUBLIC_KEY = 11
        CONFIG_ERROR = 12
        NOT_FOUND = 13



    def __init__(self, error_type: ErrorType = ErrorType.SYSTEM_ERROR, message=None):
        self.error_type = error_type
        self.message = message
        super().__init__(self.message)
