# Copyright (c) 2024 Fernando Libedinsky
# Product: IAToolkit Enterprise
#
# IAToolkit Enterprise is commercial, proprietary software.
# Unauthorized copying, modification, distribution, or use of this software,
# via any medium, is strictly prohibited unless explicitly permitted by the
# Enterprise License Agreement provided to the customer.
#
# This file is part of the IAToolkit Enterprise Edition and may not be
# redistributed as open-source. For licensing information, refer to:
# ENTERPRISE_LICENSE


def register_views(app):

    from iat_enterprise.views.corporate_login_view import CorporateLoginView, RedeemTokenApiView
    from iat_enterprise.views.login_test_view import LoginTestView


    # this is the login for external users
    app.add_url_rule('/<company_short_name>/corporate_login',
                     view_func=CorporateLoginView.as_view('corporate_login'))

    # this endpoint is called by the JS for changing the token for a session
    app.add_url_rule('/<string:company_short_name>/api/redeem_token',
                     view_func = RedeemTokenApiView.as_view('redeem_token'))


    # login testing
    app.add_url_rule('/<company_short_name>/corp_login',
                     view_func=LoginTestView.as_view('corp_login'))


