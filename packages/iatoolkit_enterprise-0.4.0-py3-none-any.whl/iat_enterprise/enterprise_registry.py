# Copyright (c) 2024 Fernando Libedinsky
# Product: IAToolkit Enterprise
#
# IAToolkit Enterprise is commercial, proprietary software.
# Unauthorized copying, modification, distribution, or use of this software,
# via any medium, is strictly prohibited unless explicitly permitted by the
# Enterprise License Agreement provided to the customer.
#
# This file is part of the IAToolkit Enterprise Edition and may not be
# redistributed as open-source. For licensing information, refer to:
# ENTERPRISE_LICENSE

from iatoolkit.company_registry import CompanyRegistry
from iatoolkit.base_company import BaseCompany
from typing import Dict, Type, Any
import logging

class EnterpriseRegistry(CompanyRegistry):
    """
    Registry implementation for Enterprise Edition.
    Removes the single-tenant restriction and validates against the LicenseService limits.
    """

    def register(self, name: str, company_class: Type[BaseCompany]) -> None:
        """
        Registers a company allowing multi-tenancy.
        Validation is deferred to instantiation time or handled explicitly.
        """
        if not issubclass(company_class, BaseCompany):
            raise ValueError(f"The class {company_class.__name__} must be a subclass of BaseCompany")

        company_key = name.lower()
        self._company_classes[company_key] = company_class
        logging.info(f"🏢 [Enterprise] Company registered: {name}")
