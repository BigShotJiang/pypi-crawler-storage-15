# Copyright (c) 2024 Fernando Libedinsky
# Product: IAToolkit Enterprise
#
# IAToolkit Enterprise is commercial, proprietary software.
# Unauthorized copying, modification, distribution, or use of this software,
# via any medium, is strictly prohibited unless explicitly permitted by the
# Enterprise License Agreement provided to the customer.
#
# This file is part of the IAToolkit Enterprise Edition and may not be
# redistributed as open-source. For licensing information, refer to:
# ENTERPRISE_LICENSE


from injector import inject
from iatoolkit.services.configuration_service import ConfigurationService
from iat_enterprise.repositories.payment_repo import PaymentRepository
from iat_enterprise.services.payment_providers.stripe_provider import StripeProvider
import logging
from iat_enterprise.common.exceptions import IatEnterpriceException
import os


class PaymentService:
    @inject
    def __init__(self,
                 config_service: ConfigurationService,
                 payment_repo: PaymentRepository):
        self.config_service = config_service
        self.repo = payment_repo

    def create_payment_link(self,
                            company_short_name: str,
                            amount,
                            currency,
                            product_name: str,
                            description: str,
                            user_identifier: str,
                            metadata=None):
        """
        Generates a payment link using the configured provider for the company.
        """
        # 1. Load Company Configuration
        payment_config = self.config_service.get_configuration(company_short_name, 'payments')
        provider_name = payment_config.get('provider')
        if not provider_name:
            raise IatEnterpriceException(
                IatEnterpriceException.ErrorType.CONFIG_ERROR,
                f"❌ No payment provider configured for company '{company_short_name}'."
            )

        # try to read from env vars, fallback to YAML config
        base_url = os.getenv('APP_BASE_URL', 'https://www.iatoolkit.com')  # Define esto en tu .env en Prod

        success_url = payment_config.get('stripe', {}).get('success_url')
        cancel_url = payment_config.get('stripe', {}).get('cancel_url')

        # if the URLs are relative or incomplete, build them dynamically
        if success_url and not success_url.startswith('http'):
            success_url = f"{base_url}{success_url}"
            cancel_url = f"{base_url}{cancel_url}"

        # Forzamos el session_id si no está presente
        if success_url and '{CHECKOUT_SESSION_ID}' not in success_url:
            success_url += "?session_id={CHECKOUT_SESSION_ID}"

        try:
            # 2. Log initial intention in DB (Pending)
            transaction = self.repo.create_transaction(
                company_short_name=company_short_name,
                provider=provider_name,
                amount=amount,
                currency=currency,
                user_identifier=user_identifier,
                description=description,
                metadata=metadata
            )

            # 3. Delegate to Provider
            if provider_name == 'stripe':
                stripe_conf = payment_config.get('stripe', {})
                provider = StripeProvider(stripe_conf)

                result = provider.create_checkout_session(
                    amount=amount,
                    currency=currency,
                    product_name=product_name,
                    description=description,
                    return_url_success=success_url,
                    return_url_cancel=cancel_url,
                    client_reference_id=transaction.id,  # Link our Transaction ID
                    customer_email=user_identifier if '@' in user_identifier else None,
                    metadata=metadata
                )

                # 4. Update DB with external ID
                self.repo.update_status(transaction.id, 'pending', external_id=result['id'])

                return {
                    'payment_url': result['url'],
                    'transaction_id': transaction.id
                }

            else:
                raise IatEnterpriceException(
                    IatEnterpriceException.ErrorType.CONFIG_ERROR,
                    f"❌ Unsupported payment provider: {provider_name}."
                )

        except Exception as e:
            self.repo.session.rollback()
            logging.error(f"Payment creation failed for {company_short_name}: {e}")
            raise

    def verify_transaction(self, external_id: str):
        """
        Verifies the status of a transaction with the payment provider and updates the local record.

        Args:
            external_id (str): The session ID or transaction ID from the provider (e.g., Stripe Session ID).

        Returns:
            PaymentTransaction: The updated transaction object.
        """
        # 1. Retrieve transaction from DB
        transaction = self.repo.get_by_external_id(external_id)
        if not transaction:
            raise IatEnterpriceException(
                IatEnterpriceException.ErrorType.NOT_FOUND,
                f"Transaction with external ID '{external_id}' not found."
            )

        # 2. If already completed, return immediately (idempotency)
        if transaction.status == 'completed':
            return transaction

        # 3. Load Provider Configuration
        # We need to re-instantiate the provider to check the status
        payment_config = self.config_service.get_configuration(transaction.company_short_name, 'payments')

        try:
            if transaction.provider == 'stripe':
                stripe_conf = payment_config.get('stripe', {})
                provider = StripeProvider(stripe_conf)

                # Verify status with Stripe API
                is_paid = provider.verify_session_payment(external_id)

                new_status = 'completed' if is_paid else 'pending'

                # 4. Update Status in DB
                if new_status != transaction.status:
                    self.repo.update_status(transaction.id, new_status)
                    # Refresh object to return updated state
                    transaction = self.repo.get_by_external_id(external_id)

                return transaction

            else:
                raise IatEnterpriceException(
                    IatEnterpriceException.ErrorType.CONFIG_ERROR,
                    f"Unsupported payment provider for verification: {transaction.provider}"
                )

        except Exception as e:
            logging.error(f"Error verifying transaction {external_id}: {e}")
            # We might want to re-raise or just return the transaction in its current state depending on policy
            raise
