# Copyright (c) 2024 Fernando Libedinsky
# Product: IAToolkit Enterprise
#
# IAToolkit Enterprise is commercial, proprietary software.
# Unauthorized copying, modification, distribution, or use of this software,
# via any medium, is strictly prohibited unless explicitly permitted by the
# Enterprise License Agreement provided to the customer.
#
# This file is part of the IAToolkit Enterprise Edition and may not be
# redistributed as open-source. For licensing information, refer to:
# ENTERPRISE_LICENSE


import stripe
import os
import logging


class StripeProvider:
    def __init__(self, config: dict):
        self.config = config
        self._init_client()

    def _init_client(self):
        api_key_env = self.config.get('api_key_env', 'STRIPE_API_KEY')
        api_key = os.getenv(api_key_env)
        if not api_key:
            raise ValueError(f"Stripe API Key environment variable '{api_key_env}' not set.")
        stripe.api_key = api_key

    def create_checkout_session(self, amount, currency, product_name, description,
                                return_url_success, return_url_cancel,
                                client_reference_id=None, customer_email=None, metadata=None):
        try:
            # Prepare success/cancel URLs
            # Stripe replaces {CHECKOUT_SESSION_ID} automatically if present in the URL

            session = stripe.checkout.Session.create(
                payment_method_types=['card'],
                line_items=[{
                    'price_data': {
                        'currency': currency.lower(),
                        'unit_amount': int(amount * 100),  # Cents
                        'product_data': {
                            'name': product_name,
                            'description': description,
                        },
                    },
                    'quantity': 1,
                }],
                mode='payment',
                success_url=return_url_success,
                cancel_url=return_url_cancel,
                client_reference_id=str(client_reference_id),
                customer_email=customer_email,
                metadata=metadata or {}
            )
            return {
                'url': session.url,
                'id': session.id
            }
        except stripe.error.StripeError as e:
            logging.error(f"Stripe API Error: {e}")
            raise Exception(f"Payment provider error: {str(e)}")

    def verify_session_payment(self, session_id: str) -> bool:
        """
        Checks if a Checkout Session has been paid.
        """
        try:
            session = stripe.checkout.Session.retrieve(session_id)
            # Check payment_status. It can be 'paid', 'unpaid', or 'no_payment_required'
            return session.payment_status == 'paid'
        except stripe.error.StripeError as e:
            logging.error(f"Stripe Verification Error: {e}")
            raise Exception(f"Could not verify payment with Stripe: {str(e)}")