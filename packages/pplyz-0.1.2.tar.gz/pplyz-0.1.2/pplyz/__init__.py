"""LLM Analyser - CSV data processing with LLM-powered structured output generation."""

from importlib import metadata

# Keep __version__ in sync with pyproject.toml.
__version__ = "0.1.2"
