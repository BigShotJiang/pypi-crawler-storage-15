"""
PLAN-LEVEL WRAPPERS FOR GOAL SEEKING BOUND TO A PLANGRAPH

These helpers are separated out from the PlanGraph class proper, because:
- Different people may want to use different metrics for their projects, and
- The same people may want to use different metrics for different goals.

These are simple wrappers over the metrics in `rdapy`.
"""

from typing import Dict, List

from rdapy import (
    est_seats,
    est_competitive_districts,
    calc_minority_metrics,
    calc_cut_score,
    calc_splitting_metrics,
)

from .pggo import PlanGraph

__all__ = [
    "get_estimated_dem_seats",
    "get_estimated_competitive_districts",
    "get_partisan_advantage",
    "get_minority_metrics",
    "get_combined_minority_score",
    "get_cut_score",
    "get_compactness_metrics",
    "get_district_compactness",
    "get_counties_split",
    "get_county_splits",
    "get_splitting_metrics",
    "get_combined_split_score",
]

### PARTISAN WRAPPERS ###


def get_estimated_dem_seats(plan: PlanGraph) -> float:
    """
    Get estimated Democratic seats based on district vote shares.

    Uses the seats-votes curve from rdapy to estimate the expected number
    of Democratic seats given the Democratic vote share in each district.

    Args:
        plan: PlanGraph instance to analyze

    Returns:
        Estimated number of Democratic seats (as a float, may be fractional)
    """

    dem_shares = [
        plan.get_computed("district_dem_shares")[d]
        for d in range(1, plan.num_districts + 1)
    ]

    return est_seats(dem_shares)


def get_estimated_competitive_districts(plan: PlanGraph) -> float:
    """
    Get estimated number of competitive districts.

    Uses rdapy's definition of competitive districts based on vote share thresholds.

    Args:
        plan: PlanGraph instance to analyze

    Returns:
        Estimated number of competitive districts (as a float, may be fractional)
    """

    dem_shares = [
        plan.get_computed("district_dem_shares")[d]
        for d in range(1, plan.num_districts + 1)
    ]

    return est_competitive_districts(dem_shares)


def get_partisan_advantage(plan: PlanGraph) -> float:
    """
    Get partisan advantage (PA).

    Partisan advantage is the difference between estimated Democratic seats
    and proportional Democratic seats based on statewide vote share.

    PA = estimated_dem_seats - proportional_dem_seats
    - Positive value = Republican advantage
    - Negative value = Democratic advantage
    - Zero = proportional representation

    Args:
        plan: PlanGraph instance to analyze

    Returns:
        Partisan advantage score
    """

    pa = get_estimated_dem_seats(plan) - plan.proportional_dem_seats

    return pa


### MINORITY OPPORTUNITY WRAPPERS ###


def get_minority_metrics(plan: PlanGraph) -> Dict[str, float]:
    """
    Compute minority opportunity metrics using rdapy.

    Calculates opportunity districts and coalition districts based on
    Voting Age Population (VAP) demographics for various racial/ethnic groups.

    Args:
        plan: PlanGraph instance to analyze

    Returns:
        Dictionary with keys 'opportunity_districts' and 'coalition_districts'
    """

    vap_keys = list(PlanGraph.fields["vap"].keys())
    total_vap_key = vap_keys[0]  # First key is total VAP

    district_vaps: Dict[str, List[int]] = plan.get_computed("district_vaps")

    # # Thunk aggregates into the format that rda.calc_minority_opportunity expects
    by_district: List[Dict[str, float]] = list()
    for i in range(plan.num_districts):
        district_demos: Dict[str, float] = dict()
        for demo in vap_keys[1:]:  # Skip total VAP
            simple_demo: str = demo.split("_")[0].lower()
            district_demos[simple_demo] = (
                district_vaps[demo][i + 1] / district_vaps[total_vap_key][i + 1]
            )

        by_district.append(district_demos)

    minority_metrics: Dict[str, float] = calc_minority_metrics(
        plan.get("statewide_vap_demos"), by_district, clip=False
    )

    return minority_metrics


def get_combined_minority_score(plan: PlanGraph) -> float:
    """
    Get combined minority representation score.

    Combines opportunity districts and coalition districts into a single score,
    with coalition districts weighted at 50% (0.5) of opportunity districts.

    Score = opportunity_districts + 0.5 * coalition_districts

    Args:
        plan: PlanGraph instance to analyze

    Returns:
        Combined minority representation score
    """

    minority_metrics: Dict[str, float] = get_minority_metrics(plan)

    opportunity_districts: float = minority_metrics["opportunity_districts"]
    coalition_districts: float = minority_metrics["coalition_districts"]

    coalition_weight: float = 0.5
    minority_score: float = (
        opportunity_districts + coalition_weight * coalition_districts
    )

    return minority_score


### COMPACTNESS WRAPPERS ###


def get_cut_score(plan: PlanGraph) -> int:
    """
    Calculate the cut score using rdapy.

    The cut score is the number of edges in the precinct adjacency graph
    that cross district boundaries. Lower scores indicate more compact districts.

    Args:
        plan: PlanGraph instance to analyze

    Returns:
        Cut score (number of edges crossing district boundaries)
    """

    cut_score: int = calc_cut_score(plan.assignments, plan.precinct_graph)

    return cut_score


def get_compactness_metrics(plan: PlanGraph) -> Dict[str, float]:
    """
    Get average Reock and Polsby-Popper compactness scores.

    Both metrics range from 0 to 1, with higher values indicating more compact districts.
    - Reock: ratio of district area to area of minimum bounding circle
    - Polsby-Popper: ratio related to district perimeter and area

    Args:
        plan: PlanGraph instance to analyze

    Returns:
        Dictionary with keys 'reock' and 'polsby_popper' containing average scores
    """

    by_district = plan.get_computed("district_compactness")

    compactness_metrics: Dict[str, float] = {
        "reock": by_district["reock"][0],
        "polsby_popper": by_district["polsby_popper"][0],
    }

    return compactness_metrics


def get_district_compactness(plan: PlanGraph, district: int) -> float:
    """
    Get Polsby-Popper compactness score for a specific district.

    Args:
        plan: PlanGraph instance to analyze
        district: District number to get compactness for

    Returns:
        Polsby-Popper compactness score for the district (0 to 1)
    """

    by_district = plan.get_computed("district_compactness")

    polby_popper: float = by_district["polsby_popper"][district]

    return polby_popper


### COUNTY-DISTRICT SPLITTING WRAPPERS ###


def get_counties_split(plan: PlanGraph) -> int:
    """
    Get the number of counties that are split across multiple districts.

    A county is considered split if it appears in more than one district.

    Args:
        plan: PlanGraph instance to analyze

    Returns:
        Number of counties split at least once
    """

    # Counties split: number of counties split at least once
    n_counties: int = sum(
        1
        for districts in plan.get_computed("districts_by_county").values()
        if len(districts) > 1
    )

    return n_counties


def get_county_splits(plan: PlanGraph) -> int:
    """
    Get the total number of county splits.

    For a county appearing in N districts, this counts N-1 splits.
    This is the total number of district boundaries that cross county boundaries.

    Args:
        plan: PlanGraph instance to analyze

    Returns:
        Total number of county splits
    """

    # Count splits: for each county in N districts, there are N-1 splits
    n_splits: int = sum(
        len(districts) - 1
        for districts in plan.get_computed("districts_by_county").values()
    )

    return n_splits


def get_splitting_metrics(plan: PlanGraph) -> Dict[str, float]:
    """
    Compute county and district splitting metrics using rdapy.

    Calculates normalized splitting scores that account for both county-level
    and district-level fragmentation.

    Args:
        plan: PlanGraph instance to analyze

    Returns:
        Dictionary with keys 'county' and 'district' containing splitting scores
    """

    return calc_splitting_metrics(plan.get_computed("CxD").copy())


def get_combined_split_score(plan: PlanGraph) -> float:
    """
    Combine the county and district split scores into a single metric.

    Takes the average of the county splitting score and district splitting score.

    Args:
        plan: PlanGraph instance to analyze

    Returns:
        Combined splitting score (average of county and district scores)
    """

    splitting: Dict[str, float] = get_splitting_metrics(plan)

    return (splitting["county"] + splitting["district"]) / 2.0


### END ###
