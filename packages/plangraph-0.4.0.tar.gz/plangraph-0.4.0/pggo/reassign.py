"""
DATA STRUCTURES FOR REPRESENTING REASSIGNMENTS OF PRECINCTS BETWEEN DISTRICTS
"""

from typing import List, NamedTuple, TypeAlias


class Graft(NamedTuple):
    """
    A set of precincts to reassign from one district to another ('spliced').

    Represents a single reassignment operation that moves one or more precincts
    from a source district to a destination district.

    Attributes:
        precincts: List of precinct geoids to reassign
        from_district: Source district number
        to_district: Destination district number
    """

    precincts: List[str]
    from_district: int
    to_district: int

    def __repr__(self) -> str:
        """
        String representation of the graft.

        Returns:
            Formatted string: [from_district, to_district, precincts]
        """
        return f"[{self.from_district}, {self.to_district}, {self.precincts}]"


# A sequence of Grafts to be applied in order.
Generation: TypeAlias = List[Graft]

# A sequence of Generations or individual Grafts applied to a plan.
# Used to track the complete history of plan modifications.
History: TypeAlias = List[Generation | Graft]


### END ###
