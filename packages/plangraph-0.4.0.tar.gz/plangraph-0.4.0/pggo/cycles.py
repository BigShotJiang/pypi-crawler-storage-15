"""
SIMPLE AND FAST CYCLE FINDER FOR REDISTRICTING DISTRICT GRAPHS.

Finds all triangles (3-cycles) and adds pairs (2-cycles) as needed to ensure
every district appears in at least one cycle.
"""

from typing import Dict, List, Tuple, Set


def find_cycles(graph: Dict[int, List[int]]) -> List[Tuple[int, ...]]:
    """
    Find all triangles and add pairs to ensure every district is in at least one cycle.

    This is a simple, fast routine that:
    1. Finds all unique triangles (3-cycles)
    2. Adds pairs (2-cycles) for any districts not yet covered

    Args:
        graph: Dictionary mapping district IDs to lists of adjacent district IDs

    Returns:
        List of cycles, where each cycle is a tuple of district IDs.
        Cycles of length 3 (triangles) come first, then cycles of length 2 (pairs).

    Examples:
        >>> adjacency = {1: [2, 3], 2: [1, 3], 3: [1, 2]}
        >>> cycles = find_cycles(adjacency)
        >>> print(cycles)
        [(1, 2, 3)]

        >>> adjacency = {1: [2], 2: [1], 3: [4], 4: [3]}
        >>> cycles = find_cycles(adjacency)
        >>> print(cycles)
        [(1, 2), (3, 4)]
    """
    cycles = []
    covered_districts: Set[int] = set()

    # Step 1: Find all triangles
    triangles = _find_all_triangles(graph)
    cycles.extend(triangles)

    # Mark districts that are in triangles as covered
    for triangle in triangles:
        covered_districts.update(triangle)

    # Step 2: Add pairs for uncovered districts
    pairs = _find_pairs_for_uncovered(graph, covered_districts)
    cycles.extend(pairs)

    return cycles


def _find_all_triangles(
    adjacency_dict: Dict[int, List[int]],
) -> List[Tuple[int, int, int]]:
    """
    Find all unique triangles in the graph.

    A triangle is three districts A, B, C where:
    - A is adjacent to B
    - B is adjacent to C
    - C is adjacent to A

    Args:
        adjacency_dict: Dictionary mapping district IDs to lists of adjacent district IDs

    Returns:
        List of triangles, each represented as a sorted 3-tuple of district IDs
    """
    triangles = []
    seen_triangles: Set[frozenset] = set()

    # Sort districts for consistent ordering
    districts = sorted(adjacency_dict.keys())

    for district_a in districts:
        neighbors_a = set(adjacency_dict.get(district_a, []))

        for district_b in neighbors_a:
            if district_b <= district_a:  # Avoid duplicates
                continue

            neighbors_b = set(adjacency_dict.get(district_b, []))

            # Find common neighbors (districts adjacent to both A and B)
            common_neighbors = neighbors_a & neighbors_b

            for district_c in common_neighbors:
                if district_c <= district_b:  # Avoid duplicates
                    continue

                # Found a triangle: A-B-C
                triangle_set = frozenset([district_a, district_b, district_c])

                if triangle_set not in seen_triangles:
                    seen_triangles.add(triangle_set)
                    # Return in sorted order for consistency
                    triangle = tuple(sorted([district_a, district_b, district_c]))
                    triangles.append(triangle)

    return triangles


def _find_pairs_for_uncovered(
    adjacency_dict: Dict[int, List[int]], covered_districts: Set[int]
) -> List[Tuple[int, int]]:
    """
    Find pairs (2-cycles) to cover districts not in any triangle.

    For each uncovered district, finds a neighbor (preferably also uncovered)
    to form a pair with. This ensures all districts appear in at least one cycle.

    Args:
        adjacency_dict: Dictionary mapping district IDs to lists of adjacent district IDs
        covered_districts: Set of districts already covered by triangles (modified in place)

    Returns:
        List of pairs, each represented as a sorted 2-tuple of district IDs

    Side effects:
        Updates covered_districts in place to include newly paired districts
    """
    pairs = []
    seen_pairs: Set[frozenset] = set()
    uncovered = set(adjacency_dict.keys()) - covered_districts

    # Sort for consistent ordering
    uncovered_sorted = sorted(uncovered)

    for district in uncovered_sorted:
        # Skip if we've already covered this district with a pair
        if district in covered_districts:
            continue

        neighbors = adjacency_dict.get(district, [])

        if not neighbors:
            # District has no neighbors - skip it
            # (Could optionally add it as a singleton if needed)
            continue

        # Prefer to pair with another uncovered district
        uncovered_neighbors = [n for n in neighbors if n not in covered_districts]

        if uncovered_neighbors:
            # Pair with an uncovered neighbor
            partner = min(uncovered_neighbors)  # Choose lexicographically smallest
        else:
            # All neighbors are covered, pair with any neighbor
            partner = min(neighbors)

        # Create the pair (in sorted order)
        pair = tuple(sorted([district, partner]))
        pair_set = frozenset(pair)

        if pair_set not in seen_pairs:
            seen_pairs.add(pair_set)
            pairs.append(pair)
            covered_districts.add(district)
            covered_districts.add(partner)

    return pairs


### END ###
