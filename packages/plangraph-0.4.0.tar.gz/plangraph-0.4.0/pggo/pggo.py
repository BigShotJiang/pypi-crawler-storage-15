"""
PLAN GRAPH for GOAL OPTIMIZATION (PGGO or "pogo")
Redisticting plans represented as connected graphs with data-bearing nodes.
"""

from typing import Any, Dict, List, Set, Tuple

import copy, hashlib
from pathlib import Path
from collections import defaultdict
import networkx as nx

from rdapy import (
    load_data,
    load_graph,
    sorted_geoids,
    collect_metadata,
    County,
    District,
    OUT_OF_STATE,
    DatasetKey,
    get_dataset_keys,
    get_fields,
    DISTRICTS_BY_STATE,
    #
    read_csv,
    #
    ParseGeoID,
    #
    wl_make_circle,
    calc_compactness_category,
)
from rdapy.aggregate import border_length, exterior


from .reassign import Graft, Generation, History


class PlanGraph:
    """A redistricting plan represented as an adjacency graph with all associated precinct data."""

    def __init__(
        self,
        xx: str,
        plan_type: str,
        plan_path: str,
        data_path: str,
        graph_path: str,
        *,
        debug: bool = False,
    ):
        # Guard: Ensure only one state/chamber per session
        if hasattr(PlanGraph, "xx"):
            if PlanGraph.xx != xx or PlanGraph.chamber != plan_type:
                raise ValueError(
                    f"PlanGraph already initialized for {PlanGraph.xx} {PlanGraph.chamber}. "
                    f"Cannot create new instance for {xx} {plan_type} in same session. "
                    f"Create new instances using the copy() method instead."
                )

        # Validate file paths exist
        for path_name, path_value in [
            ("plan_path", plan_path),
            ("data_path", data_path),
            ("graph_path", graph_path),
        ]:
            if not Path(path_value).exists():
                raise FileNotFoundError(f"{path_name} does not exist: {path_value}")

        # Validate state code
        if xx not in DISTRICTS_BY_STATE:
            raise ValueError(
                f"Invalid state code '{xx}'. Must be one of: {sorted(DISTRICTS_BY_STATE.keys())}"
            )

        # Validate plan type
        valid_plan_types = ["congress", "upper", "lower"]
        if plan_type not in valid_plan_types:
            raise ValueError(
                f"Invalid plan_type '{plan_type}'. Must be one of: {valid_plan_types}"
            )

        PlanGraph._debug: bool = debug

        PlanGraph.xx: str = xx
        PlanGraph.chamber: str = plan_type
        self._load_plan(plan_path)
        self._load_state_data(data_path, graph_path)
        self._calc_state_statistics()

        self._aggregate_categories: List[str] = [
            "general",
            "partisan",
            "minority",
            "compactness",
            "splitting",
        ]
        self._reset_dirty_bits()  # For each category
        self._computed_dependencies: Dict[str, str] = {
            "district_populations": "general",
            "district_dem_votes": "partisan",
            "district_rep_votes": "partisan",
            "district_dem_shares": "partisan",
            "district_vaps": "minority",
            "district_compactness": "compactness",
            "CxD": "splitting",
            "counties_by_district": "general",
            "districts_by_county": "general",
        }

        pass  # for a breakpoint

    # region: PRIVATE helpers

    def _load_plan(self, plan_path: str) -> None:
        """
        Load a precinct-assignment file from a CSV and extract district IDs.

        Reads the plan CSV, creates the assignments dictionary, and initializes
        the history tracking for this plan.

        Args:
            plan_path: Path to the CSV file containing precinct assignments

        Side effects:
            Sets self.assignments, PlanGraph.districts, PlanGraph.initial_assignments,
            self.generation, and self.history
        """

        self.assignments: Dict[str, int] = self._load_map(plan_path)
        PlanGraph.districts: Set[int] = set(self.assignments.values())

        # For history
        PlanGraph.initial_assignments: Dict[str, int] = copy.deepcopy(self.assignments)
        self.generation: int = 0
        self.history: History = []

    def _load_map(self, plan_path: str) -> Dict[str, int]:
        """
        Load a precinct-assignment file from a CSV.

        Validates CSV structure and extracts precinct-to-district assignments.
        Supports multiple column name conventions (GEOID/GEOID20/GEOID30 for precincts,
        District/DISTRICT for districts).

        Args:
            plan_path: Path to the CSV file

        Returns:
            Dictionary mapping geoid -> district number

        Raises:
            ValueError: If CSV is empty or missing required columns
        """

        plan_csv = read_csv(plan_path, [str, int])

        # Validate CSV is not empty
        if not plan_csv:
            raise ValueError(f"Plan CSV is empty: {plan_path}")

        geoid_fields: List[str] = ["GEOID", "GEOID20", "GEOID30"]
        district_fields: List[str] = ["District", "DISTRICT"]

        keys: List[str] = list(plan_csv[0].keys())

        # Validate required columns exist
        geoid_found = set(geoid_fields) & set(keys)
        district_found = set(district_fields) & set(keys)

        if not geoid_found:
            raise ValueError(
                f"Plan CSV must have one of {geoid_fields}, found columns: {keys}"
            )
        if not district_found:
            raise ValueError(
                f"Plan CSV must have one of {district_fields}, found columns: {keys}"
            )

        geoid_field: str = list(geoid_found)[0]
        district_field: str = list(district_found)[0]

        assignments: Dict[str, int] = {
            str(row[geoid_field]): int(row[district_field]) for row in plan_csv
        }

        return assignments

    def _load_state_data(self, data_path: str, graph_path: str) -> None:
        """
        Load the state data, graph, and metadata.

        Loads precinct data from JSONL, precinct adjacency graph from JSON,
        processes dataset mappings, and validates data consistency.

        Args:
            data_path: Path to the precinct data JSONL file
            graph_path: Path to the adjacency graph JSON file

        Side effects:
            Sets multiple PlanGraph class variables (precinct_graph, fields, data, etc.)
            and self.graph

        Raises:
            ValueError: If precincts in plan are missing from data or graph
        """

        data_map: Dict[str, Any]
        input_data: List[Dict[str, Any]]
        data_map, input_data = load_data(data_path)
        # Save this for compatibility with `rdapy` functions.
        # Contains OUT_OF_STATE for compactness calculations.
        PlanGraph.precinct_graph: Dict[str, List[str]] = load_graph(graph_path)

        geoids: List[str] = sorted_geoids(input_data)
        metadata: Dict[str, Any] = collect_metadata(
            PlanGraph.xx,
            PlanGraph.chamber,
            geoids,
        )

        # Store metadata for scoring

        PlanGraph.num_districts: int = metadata["D"]
        PlanGraph.num_counties: int = metadata["C"]
        PlanGraph.county_to_index: Dict[County, int] = metadata["county_to_index"]
        PlanGraph.district_to_index: Dict[District, int] = metadata["district_to_index"]

        # Process the precinct data, dataset keys, and fields

        census_dataset: DatasetKey
        vap_dataset: DatasetKey
        cvap_dataset: DatasetKey
        election_datasets: List[DatasetKey]
        (
            census_dataset,
            vap_dataset,
            cvap_dataset,
            election_datasets,
            _,
        ) = get_dataset_keys(data_map)
        election_dataset: DatasetKey = election_datasets[0]

        # datasets: Dict[str, DatasetKey] = {
        #     "census": census_dataset,
        #     "vap": vap_dataset,
        #     "cvap": cvap_dataset,
        #     "election": election_dataset,
        # }

        census_fields: Dict[str, str] = {
            "total_pop": get_fields(data_map, "census", census_dataset)["total_pop"]
        }

        vap_fields: Dict[str, str] = dict()
        for simple_name, qualified_name in get_fields(
            data_map, "vap", vap_dataset
        ).items():
            vap_fields[simple_name] = qualified_name

        cvap_fields: Dict[str, str] = dict()
        for simple_name, qualified_name in get_fields(
            data_map, "cvap", cvap_dataset
        ).items():
            cvap_fields[simple_name] = qualified_name

        election_fields: Dict[str, str] = dict()
        for simple_name, qualified_name in get_fields(
            data_map, "election", election_dataset
        ).items():
            election_fields[simple_name] = qualified_name

        shape_fields: Dict[str, str] = {
            "center": "center",
            "area": "area",
            "arcs": "arcs",
            "exterior": "exterior",
        }

        PlanGraph.fields: Dict[str, Dict[str, str]] = {
            "census": census_fields,
            "vap": vap_fields,
            "cvap": cvap_fields,
            "election": election_fields,
            "shape": shape_fields,
        }
        PlanGraph.precinct_attrs = ["district", "neighbors"] + [
            field for subdict in PlanGraph.fields.values() for field in subdict
        ]

        PlanGraph.adjacencies: List[Tuple[str, str]] = self._make_adjacencies()
        PlanGraph.data: Dict[str, Any] = self._make_data(input_data, PlanGraph.fields)
        self.graph: nx.Graph = self._make_graph()

        # Validate data consistency
        assignment_geoids = set(self.assignments.keys())
        data_geoids = set(PlanGraph.data.keys())

        missing_in_data = assignment_geoids - data_geoids
        if missing_in_data:
            raise ValueError(
                f"{len(missing_in_data)} precincts in plan have no data. "
                f"First few: {list(missing_in_data)[:5]}"
            )

        # Validate graph consistency
        graph_geoids = set(PlanGraph.precinct_graph.keys()) - {OUT_OF_STATE}
        missing_in_graph = assignment_geoids - graph_geoids
        if missing_in_graph:
            raise ValueError(
                f"{len(missing_in_graph)} precincts in plan are not in graph. "
                f"First few: {list(missing_in_graph)[:5]}"
            )

    def _make_data(
        self,
        input_data: List[Dict[str, Any]],
        fields: Dict[str, Dict[str, str]],
    ) -> Dict[str, Any]:
        """
        Index the input data by precinct geoid for the specified fields.

        Extracts relevant fields from the raw input data and creates a dictionary
        indexed by geoid. Uses simple, unqualified field names (e.g., 'total_pop'
        instead of 'P1_001N') for easier access.

        Args:
            input_data: Raw precinct data from JSONL file
            fields: Mapping of dataset types to their field name mappings

        Returns:
            Dictionary mapping geoid -> {field_name: value}
        """

        data: Dict[str, Any] = dict()
        for row in input_data:
            reduced: Dict[str, Any] = dict()
            for dataset_type, dataset_fields in fields.items():
                for simple_name, qualified_name in dataset_fields.items():
                    assert (
                        qualified_name in row
                    ), f"Missing field {qualified_name} in row {row['geoid']}"
                    reduced[simple_name] = row[qualified_name]
            data[row["geoid"]] = reduced

        return data

    def _make_adjacencies(self) -> List[Tuple[str, str]]:
        """
        Convert a node/list adjacency graph to a list of unique node pairs.

        Takes the precinct adjacency graph (dict mapping geoid to list of neighbors)
        and converts it to a list of undirected edges (geoid pairs), removing any
        virtual OUT_OF_STATE borders used for compactness calculations.

        Returns:
            List of tuples (geoid1, geoid2) where geoid1 < geoid2
        """

        pairs: List[Tuple[str, str]] = [
            (node, neighbor)
            for node, neighbors in PlanGraph.precinct_graph.items()
            for neighbor in neighbors
            if node < neighbor and node != OUT_OF_STATE and neighbor != OUT_OF_STATE
        ]

        return pairs

    def _make_graph(self) -> nx.Graph:
        """
        Create a NetworkX graph from precinct adjacencies and district assignments.

        Builds a NetworkX graph where:
        - Nodes are precincts (geoids)
        - Each node has a 'district' attribute for current assignment
        - Edges represent precinct adjacencies

        NOTE - Precinct data is stored in PlanGraph.data, not on the nodes,
        to optimize copying performance.

        Returns:
            NetworkX Graph with precincts as nodes and adjacencies as edges
        """

        nodes: List[Tuple] = []
        for geoid, precinct_data in PlanGraph.data.items():
            attrs: Dict[str, Any] = dict()  # NOTE - Data indexed by geoid on the class
            attrs["district"] = self.assignments[geoid]
            node: Tuple = (geoid, attrs)
            nodes.append(node)

        edges: List[Tuple] = []

        for geoid1, geoid2 in PlanGraph.adjacencies:
            edge: Tuple = (geoid1, geoid2) if geoid1 < geoid2 else (geoid2, geoid1)
            edges.append(edge)

        graph = nx.Graph()
        graph.add_nodes_from(nodes)
        graph.add_edges_from(edges)

        return graph

    def _calc_state_statistics(self) -> None:
        """
        Compute statewide statistics.

        Calculates total population, target district population, statewide
        Democratic vote share, proportional Democratic seats, and statewide
        VAP demographics.

        Side effects:
            Sets PlanGraph class variables: total_population, target_district_pop,
            statewide_dem_share, proportional_dem_seats, statewide_vap_demos
        """

        PlanGraph.total_population: int = sum(
            [PlanGraph.data[geoid]["total_pop"] for geoid in self.graph.nodes()]
        )
        PlanGraph.target_district_pop: int = int(
            PlanGraph.total_population / PlanGraph.num_districts
        )

        # Compute two-party vote share

        total_dem_votes = sum(
            [PlanGraph.data[geoid]["dem_votes"] for geoid in self.graph.nodes()]
        )
        total_rep_votes = sum(
            [PlanGraph.data[geoid]["rep_votes"] for geoid in self.graph.nodes()]
        )
        two_party_votes = total_dem_votes + total_rep_votes
        PlanGraph.statewide_dem_share: float = (
            total_dem_votes / two_party_votes if two_party_votes > 0 else 0.0
        )
        PlanGraph.proportional_dem_seats: int = round(
            PlanGraph.statewide_dem_share * PlanGraph.num_districts
        )

        # Compute statewide VAP demographics for minority metrics

        PlanGraph.statewide_vap_demos: Dict[str, float] = {}
        total_vap = sum(
            [PlanGraph.data[geoid]["total_vap"] for geoid in self.graph.nodes()]
        )
        assert total_vap > 0, "No VAP data found in precincts!"

        for simple_name, _ in PlanGraph.fields["vap"].items():
            if simple_name == "total_vap":
                continue
            demo_total = sum(
                [PlanGraph.data[geoid][simple_name] for geoid in self.graph.nodes()]
            )
            demo_key = simple_name.replace("_vap", "")
            PlanGraph.statewide_vap_demos[demo_key] = demo_total / total_vap
        # CVAP

    def _initialize_aggregates(self, category: str) -> None:
        """
        Initialize by-district aggregates for the specified category.

        Args:
            category: Which category to initialize ('all', 'general', 'partisan',
                'minority', 'compactness', or 'splitting')

        Side effects:
            Initializes instance variables for the specified category aggregates
        """

        if category in ["all", "general"]:
            self._district_populations: Dict[int, int] = defaultdict(int)
            self._counties_by_district: Dict[int, Set[str]] = defaultdict(set)
            self._districts_by_county: Dict[str, Set[int]] = defaultdict(set)

        if category in ["all", "partisan"]:
            self._district_rep_votes: Dict[int, int] = defaultdict(int)
            self._district_dem_votes: Dict[int, int] = defaultdict(int)
            self._district_dem_shares: Dict[int, float] = defaultdict(float)

        if category in ["all", "minority"]:
            # NOTE - This mimics high-volume offline scoring in that the aggregates are dict-based
            # but then have to be converted lists for the scoring functions. A potential optimization
            # opportunity would be to store these as lists directly.
            self._district_vaps: Dict[str, List[int]] = {
                demo: [0] * (PlanGraph.num_districts + 1)
                for demo in PlanGraph.fields["vap"]
            }
            # CVAP

        if category in ["all", "compactness"]:
            self._initialize_shape_aggregates()

        if category in ["all", "splitting"]:
            self._CxD: List[List[float]] = [
                [0.0] * PlanGraph.num_counties for _ in range(PlanGraph.num_districts)
            ]

    def _initialize_shape_aggregates(self) -> None:
        """
        Initialize shape aggregates for compactness calculations.

        Side effects:
            Initializes _district_shape_attributes, _district_exteriors, and
            _district_compactness instance variables
        """

        self._district_shape_attributes: Dict[str, List[float]] = {
            "area": [0.0] * (PlanGraph.num_districts + 1),
            "perimeter": [0.0] * (PlanGraph.num_districts + 1),
            "diameter": [0.0] * (PlanGraph.num_districts + 1),
        }  # The 0th element is a total for the state, if applicable
        self._district_exteriors: Dict[str, List[Any]] = {
            "exterior": [[] for _ in range(PlanGraph.num_districts + 1)]
        }  # The 0th element is a total for the state, if applicable
        self._district_compactness: Dict[str, List[float]] = defaultdict(list)

    def _reset_dirty_bits(self) -> None:
        """
        Reset all dirty bits to True.

        Side effects:
            Sets all categories in _aggregates_dirty to True
        """

        self._aggregates_dirty: Dict[str, bool] = {
            category: True for category in self._aggregate_categories
        }

    def _aggregate(self, category: str = "all") -> None:
        """
        Aggregate data by district and state. Cache the results.

        Loops through all precincts, accumulating data for the specified category.
        Uses dirty bits to avoid unnecessary recomputation.

        Args:
            category: Which category to aggregate ('all', 'general', 'partisan',
                'minority', 'compactness', or 'splitting'). Defaults to 'all'.

        Side effects:
            Updates category-specific instance aggregate variables and marks
            them as clean in _aggregates_dirty
        """

        if category == "all":  # All categories
            if all(not dirty for dirty in self._aggregates_dirty.values()):
                return
        elif not self._aggregates_dirty[category]:
            return

        # Reset aggregates
        self._initialize_aggregates(category)

        # Aggregate data & shapes by district
        for geoid, district in self.assignments.items():
            pop: int = self.get_precinct(geoid, "total_pop")
            county = ParseGeoID(geoid).county[2:]

            if category in ["all", "general"]:
                self._district_populations[0] += pop
                self._district_populations[district] += pop
                self._counties_by_district[district].add(county)
                self._districts_by_county[county].add(district)

            if category in ["all", "partisan"]:
                dem = self.get_precinct(geoid, "dem_votes")
                rep = self.get_precinct(geoid, "rep_votes")
                self._district_dem_votes[0] += dem
                self._district_dem_votes[district] += dem
                self._district_rep_votes[0] += rep
                self._district_rep_votes[district] += rep

            if category in ["all", "minority"]:
                for simple_name, _ in PlanGraph.fields["vap"].items():
                    demo_tot: int = self.get_precinct(geoid, simple_name)
                    self._district_vaps[simple_name][district] += demo_tot
                    self._district_vaps[simple_name][0] += demo_tot  # statewide total
                # CVAP

            if category in ["all", "compactness"]:
                self._aggregate_shape_data(
                    geoid,
                    district,
                    self._district_shape_attributes,
                    self._district_exteriors,
                )

            if category in ["all", "splitting"]:
                i = district - 1  # District 1 -> row 0, district 2 -> row 1, etc.
                j = PlanGraph.county_to_index[county]
                self._CxD[i][j] += pop

        # Compute two-party vote share
        if category in ["all", "partisan"]:
            for district in {0} | PlanGraph.districts:
                two_party_votes = (
                    self._district_dem_votes[district]
                    + self._district_rep_votes[district]
                )
                if two_party_votes > 0:
                    self._district_dem_shares[district] = (
                        self._district_dem_votes[district] / two_party_votes
                    )
                else:
                    self._district_dem_shares[district] = 0.0

        if category in ["all", "compactness"]:
            # Calculate district diameters

            self._calc_district_diameter(
                self._district_shape_attributes, self._district_exteriors
            )
            self._district_compactness = calc_compactness_category(
                self._district_shape_attributes, PlanGraph.num_districts
            )

        # Mark aggregates as clean
        computed_categories: List[str] = (
            self._aggregate_categories if category == "all" else [category]
        )
        for category in computed_categories:
            self._aggregates_dirty[category] = False

    # NOTE - This might be needed
    # def _count_split_counties_by_district(self) -> Dict[int, int]:
    #     """For each district, count how many of its counties are split (i.e., appear in other districts)."""
    #
    #     split_counties_by_district = {}
    #
    #     for district_id, counties in self._counties_by_district.items():
    #         split_count = sum(
    #             1 for county in counties if len(self._districts_by_county[county]) > 1
    #         )
    #         split_counties_by_district[district_id] = split_count
    #
    #     return split_counties_by_district

    def _aggregate_shape_data(
        self,
        geoid: str,
        district: int,
        by_district: Dict[str, List[float]],  # NOTE - updated
        by_district_temp: Dict[str, List[Any]],  # NOTE - updated
    ) -> None:
        """
        Aggregate shape data for a single precinct into district totals.

        Accumulates area, perimeter (border length), and exterior arcs for each
        district. This data is later used to calculate compactness metrics.

        Modelled on the version in `rdapy`, delegating to helper functions there
        for border_length and exterior calculations.

        Args:
            geoid: Precinct identifier
            district: District number this precinct is assigned to
            by_district: District-level aggregates (area, perimeter, diameter)
            by_district_temp: Temporary storage for exterior arcs by district

        Side effects:
            Updates by_district and by_district_temp in place
        """

        data_by_geoid: Dict[str, Any] = PlanGraph.data
        precinct = data_by_geoid[geoid]

        by_district["area"][district] += precinct["area"]
        by_district["area"][0] += precinct["area"]
        by_district["perimeter"][district] += border_length(
            geoid, district, self.assignments, data_by_geoid, PlanGraph.precinct_graph
        )
        by_district_temp["exterior"][district].extend(
            exterior(
                geoid,
                district,
                self.assignments,
                data_by_geoid,
                PlanGraph.precinct_graph,
            )
        )

    def _calc_district_diameter(
        self,
        by_district: Dict[str, List[float]],  # NOTE - updated
        by_district_temp: Dict[str, List[Any]],
    ) -> None:
        """
        Calculate the diameter of each district's bounding circle.

        Uses the Welzl algorithm to find the smallest enclosing circle for each
        district's exterior arcs, then computes the diameter (2 * radius).
        Cloned from `rdapy`.

        Args:
            by_district: District-level aggregates, diameter values added here
            by_district_temp: Temporary storage containing exterior arcs by district

        Side effects:
            Updates by_district['diameter'] in place
        """

        for i, ext in enumerate(by_district_temp["exterior"]):
            if i == 0:
                continue  # Skip the state total

            _, _, r = wl_make_circle(ext)
            diameter: float = 2 * r

            by_district["diameter"][i] = diameter

    # endregion

    # region: PUBLIC getters

    def get(self, attr: str) -> Any:
        """
        Get a plan-level attribute.

        Args:
            attr: Name of the attribute to get (e.g., 'xx', 'chamber', 'num_districts')

        Returns:
            The value of the specified attribute
        """

        if PlanGraph._debug:
            assert attr in [
                # Instance data attributes
                "assignments",
                "graph",
                "generation",
                "history",
                # Class data attributes
                "xx",
                "chamber",
                "initial_assignments",
                "districts",
                "num_counties",
                "num_districts",
                "proportional_dem_seats",
                "statewide_dem_share",
                "statewide_vap_demos",
                "target_district_pop",
                "total_population",
                "precinct_graph",
            ], f"Unknown plan attribute {attr}!"

        value: Any = getattr(self, attr)

        return value

    def get_precinct(self, geoid: str, attr: str) -> Any:
        """
        Get the value of an attribute for a precinct.

        Args:
            geoid: Precinct identifier
            attr: Attribute name (e.g., 'total_pop', 'dem_votes', 'district')

        Returns:
            The value of the specified attribute for the precinct
        """

        if PlanGraph._debug:
            assert (
                attr in PlanGraph.precinct_attrs
            ), f"Unknown precinct attribute {attr}!"

        if attr == "district":
            return self.assignments[geoid]
        elif attr == "neighbors":
            return self.graph.neighbors(geoid)
        else:
            return PlanGraph.data[geoid][attr]

    def get_computed(self, name: str) -> Any:
        """
        Get a computed, cached data attribute, e.g., a by-district aggregate.

        Recomputes the aggregate if it's marked as dirty.

        NOTE - These should not be updated in place outside this class! Make a copy first, if needed.

        Args:
            name: Name of the computed attribute (e.g., 'district_populations',
                'district_dem_shares', 'district_compactness')

        Returns:
            The computed aggregate data
        """

        if PlanGraph._debug:
            assert name in [
                "district_populations",
                #
                "district_dem_votes",
                "district_rep_votes",
                "district_dem_shares",
                #
                "district_compactness",
                #
                "CxD",
                "counties_by_district",
                "districts_by_county",
                #
                "district_vaps",
            ], f"Unknown aggregate {name}!"

        category: str = self._computed_dependencies[name]

        self._aggregate(category)

        attr_name: str = f"_{name}"
        value: Any = getattr(self, attr_name)

        return value

    # endregion

    # region: PUBLIC methods

    def splice(self, graft: Graft) -> None:
        """
        Splice a set of precincts (a 'graft') from one district to another.

        Updates the plan *in place* by reassigning precincts and marking
        aggregates as dirty.

        NOTE - To ease compatibility with `rdapy` functions, there are *two* copies
        of precinct:district assignments: one in `self.assignments` and one in
        `self.graph`. This method updates both.

        Args:
            graft: A Graft object specifying precincts to move and source/destination districts

        Side effects:
            Updates self.assignments, self.graph node attributes, self.history, and
            marks all aggregates as dirty
        """

        for geoid in graft.precincts:
            self.assignments[geoid] = graft.to_district
            self.graph.nodes[geoid]["district"] = graft.to_district

        self.history.append(graft)

        self._reset_dirty_bits()  # Dirty all categories & districts

    def generate(self) -> int:
        """
        Collect the list of grafts spliced since the previous generation into a new one.

        Returns:
            The new generation number
        """

        next_gen: List = self.history[self.generation :]

        if len(next_gen) > 0:
            self.history = self.history[: self.generation]
            self.history.append(next_gen)
            self.generation += 1

        return self.generation

    def recalc(self) -> None:
        """
        Force re-aggregation of all cached aggregates.

        Side effects:
            Marks all aggregates as dirty and recomputes them
        """

        self._aggregates_dirty: Dict[str, bool] = {
            category: True for category in self._aggregate_categories
        }
        self._aggregate()  # Re-aggregate all categories & districts

    def copy(self) -> "PlanGraph":
        """
        Create a deep copy of the plan.

        Returns:
            A new PlanGraph instance with copied mutable state
        """

        return copy.deepcopy(self)

    def get_signature(self) -> str:
        """
        Get a unique signature for this plan based on its assignments.

        Returns:
            SHA256 hash of the sorted assignments as a hex string
        """

        # Create a sorted, deterministic string representation
        assignment_str = ",".join(
            f"{g}:{d}" for g, d in sorted(self.assignments.items())
        )

        return hashlib.sha256(assignment_str.encode()).hexdigest()

    def to_csv_dict(self) -> List[Dict[str, str]]:
        """
        Convert plan to list of dicts for CSV output.

        Returns:
            List of dicts with 'GEOID' and 'DISTRICT' keys, sorted by geoid
        """

        return [
            {"GEOID": geoid, "DISTRICT": str(district)}
            for geoid, district in sorted(self.assignments.items())
        ]

    # endregion

    # region: PUBLIC validation methods

    def district_is_contiguous(self, district: int) -> bool:
        """
        Check if a district is contiguous.

        Args:
            district: District number to check

        Returns:
            True if the district is contiguous, False otherwise
        """

        subgraph = self.district_subgraph(district)

        return nx.is_connected(subgraph)

    def is_contiguous(self) -> bool:
        """
        Check if all districts in the plan are contiguous.

        Returns:
            True if all districts are contiguous, False otherwise
        """

        for district in PlanGraph.districts:
            if not self.district_is_contiguous(district):
                return False

        return True

    def district_within_population_tolerance(
        self, district: int, *, pop_tol: float
    ) -> bool:
        """
        Check if a district is within a given population tolerance.

        NOTE - This is *not* the max - min of "population deviation" per se.

        Args:
            district: District number to check
            pop_tol: Population tolerance as a fraction (0.0 to 1.0)

        Returns:
            True if district is within tolerance, False otherwise

        Raises:
            ValueError: If pop_tol is not between 0 and 1
        """

        if not 0 <= pop_tol <= 1:
            raise ValueError(
                f"Population tolerance must be between 0 and 1, got: {pop_tol}"
            )

        district_pop: int = self.get_computed("district_populations")[district]
        target_pop: int = PlanGraph.target_district_pop
        # NOTE - This is *not* the max - min of "population deviation" per se.
        deviation = abs(district_pop - target_pop) / target_pop

        return deviation <= pop_tol

    def within_population_tolerance(self, *, pop_tol: float) -> bool:
        """
        Check if all districts in the plan are within a given population tolerance.

        Args:
            pop_tol: Population tolerance as a fraction (0.0 to 1.0)

        Returns:
            True if all districts are within tolerance, False otherwise
        """

        for district in PlanGraph.districts:
            if not self.district_within_population_tolerance(district, pop_tol=pop_tol):
                return False

        return True

    def is_valid(self, *, pop_tol: float) -> bool:
        """
        Check if the plan is valid: all districts contiguous & within population tolerance.

        Args:
            pop_tol: Population tolerance as a fraction (0.0 to 1.0)

        Returns:
            True if plan is valid, False otherwise
        """

        return self.is_contiguous() and self.within_population_tolerance(
            pop_tol=pop_tol
        )

    # region: PUBLIC misc. helper methods

    def district_graph(self) -> Dict[int, List[int]]:
        """
        Infer a district adjacency graph from the precinct adjacency graph and assignments.

        Returns:
            Dictionary mapping district ID -> list of adjacent district IDs
        """

        district_graph: defaultdict[int, List[int]] = defaultdict(list)
        for precinct, district in self.assignments.items():
            neighbors: List[str] = PlanGraph.precinct_graph[precinct]
            for neighbor in neighbors:
                if neighbor == OUT_OF_STATE:
                    continue

                assert (
                    neighbor in self.assignments
                ), f"Neighbor {neighbor} not in assignments!"
                neighbor_district: int = self.assignments[neighbor]

                if (
                    neighbor_district != district
                    and neighbor_district not in district_graph[district]
                ):
                    district_graph[district].append(neighbor_district)

        return district_graph

    def district_subgraph(self, district: int) -> nx.Graph:
        """
        Get the subgraph for a given district.

        NOTE - This is a view, not a copy.

        Args:
            district: District number

        Returns:
            NetworkX subgraph containing only precincts in the specified district
        """

        nodes_in_district = [
            n
            for n in self.graph.nodes()
            if self.graph.nodes[n].get("district") == district
        ]

        D: nx.Graph = self.graph.subgraph(nodes_in_district)

        return D

    def border_precincts(self) -> Dict[str, Set[int]]:
        """
        Find all precincts that border other districts.

        Returns:
            Dictionary mapping geoid -> set of adjacent district IDs (excluding own district)
        """

        border_precincts: Dict[str, Set[int]] = dict()

        for geoid, district in self.assignments.items():
            bordering_districts: Set[int] = set()

            for neighbor in PlanGraph.precinct_graph[geoid]:
                if neighbor == OUT_OF_STATE:
                    continue

                neighbor_district: int = self.assignments[neighbor]
                if neighbor_district != district:
                    bordering_districts.add(neighbor_district)

            if len(bordering_districts) > 0:
                border_precincts[geoid] = bordering_districts

        return border_precincts

    def district_precincts(self, district: int) -> List[str]:
        """
        Get the list of precinct geoids in a given district.

        Args:
            district: District number

        Returns:
            List of geoids assigned to the district
        """

        geoids: List[str] = [
            geoid
            for geoid, assignment in self.assignments.items()
            if assignment == district
        ]

        return geoids

    def connecting_precincts(self, S: nx.Graph, D: nx.Graph) -> List[str]:
        """
        Get the list of nodes in district subgraph S that are adjacent to any node in district subgraph D.

        Args:
            S: The source district subgraph
            D: The destination district subgraph

        Returns:
            List of geoids in S that border D
        """

        boundary_nodes: Set[str] = set()
        D_set: Set[str] = set(D)

        for node in S:
            for neighbor in self.graph.neighbors(node):
                if neighbor in D_set:
                    boundary_nodes.add(node)
                    break

        return list(boundary_nodes)

    # endregion


### END ###
