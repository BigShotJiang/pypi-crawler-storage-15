#!/usr/bin/env python3

"""
TEST CYCLE FINDING IN DISTRICT GRAPHS
"""

from pggo import find_cycles


class TestFindCycles:
    def test_simple_triangle(self) -> None:
        """Test a simple triangle of 3 mutually adjacent districts."""
        adjacency = {1: [2, 3], 2: [1, 3], 3: [1, 2]}

        cycles = find_cycles(adjacency)

        assert len(cycles) == 1
        assert cycles[0] == (1, 2, 3)

    def test_simple_pairs(self) -> None:
        """Test two separate pairs of adjacent districts."""
        adjacency = {1: [2], 2: [1], 3: [4], 4: [3]}

        cycles = find_cycles(adjacency)

        assert len(cycles) == 2
        # Cycles should be pairs
        assert all(len(cycle) == 2 for cycle in cycles)
        # Should have both pairs
        assert (1, 2) in cycles
        assert (3, 4) in cycles

    def test_mixed_triangle_and_pair(self) -> None:
        """Test a graph with both a triangle and a separate pair."""
        adjacency = {
            1: [2, 3],
            2: [1, 3],
            3: [1, 2],
            4: [5],
            5: [4],
        }

        cycles = find_cycles(adjacency)

        assert len(cycles) == 2
        # Should have one triangle and one pair
        assert (1, 2, 3) in cycles
        assert (4, 5) in cycles

    def test_multiple_triangles(self) -> None:
        """Test multiple separate triangles."""
        adjacency = {
            1: [2, 3],
            2: [1, 3],
            3: [1, 2],
            4: [5, 6],
            5: [4, 6],
            6: [4, 5],
        }

        cycles = find_cycles(adjacency)

        assert len(cycles) == 2
        assert (1, 2, 3) in cycles
        assert (4, 5, 6) in cycles

    def test_overlapping_triangles(self) -> None:
        """Test districts that form multiple overlapping triangles."""
        # Districts 1,2,3 and 2,3,4 both form triangles
        adjacency = {
            1: [2, 3],
            2: [1, 3, 4],
            3: [1, 2, 4],
            4: [2, 3],
        }

        cycles = find_cycles(adjacency)

        # Should find both triangles
        assert len(cycles) == 2
        assert (1, 2, 3) in cycles
        assert (2, 3, 4) in cycles

    def test_line_of_districts(self) -> None:
        """Test a linear chain of districts (no triangles, only pairs)."""
        adjacency = {
            1: [2],
            2: [1, 3],
            3: [2, 4],
            4: [3, 5],
            5: [4],
        }

        cycles = find_cycles(adjacency)

        # Should create pairs to cover all districts
        # Each district should appear in at least one cycle
        covered = set()
        for cycle in cycles:
            covered.update(cycle)

        assert covered == {1, 2, 3, 4, 5}

    def test_single_district(self) -> None:
        """Test a graph with a single district (no neighbors)."""
        adjacency = {1: []}

        cycles = find_cycles(adjacency)

        # No cycles possible with a single district with no neighbors
        assert cycles == []

    def test_isolated_districts(self) -> None:
        """Test districts with no adjacencies."""
        adjacency = {1: [], 2: [], 3: []}

        cycles = find_cycles(adjacency)

        # No cycles possible
        assert cycles == []

    def test_complete_graph_4_districts(self) -> None:
        """Test a complete graph where all districts are adjacent to all others."""
        adjacency = {
            1: [2, 3, 4],
            2: [1, 3, 4],
            3: [1, 2, 4],
            4: [1, 2, 3],
        }

        cycles = find_cycles(adjacency)

        # Should find 4 triangles: (1,2,3), (1,2,4), (1,3,4), (2,3,4)
        assert len(cycles) == 4
        assert all(len(cycle) == 3 for cycle in cycles)

    def test_square_graph(self) -> None:
        """Test a square arrangement: 1-2-4-3-1."""
        adjacency = {
            1: [2, 3],
            2: [1, 4],
            3: [1, 4],
            4: [2, 3],
        }

        cycles = find_cycles(adjacency)

        # No triangles in a square, should get pairs
        # All districts should be covered
        covered = set()
        for cycle in cycles:
            covered.update(cycle)

        assert covered == {1, 2, 3, 4}

    def test_all_districts_covered(self) -> None:
        """Ensure every district appears in at least one cycle."""
        adjacency = {
            1: [2],
            2: [1, 3, 4],
            3: [2, 4, 5],
            4: [2, 3],
            5: [3],
        }

        cycles = find_cycles(adjacency)

        # Every district should appear in at least one cycle
        covered = set()
        for cycle in cycles:
            covered.update(cycle)

        all_districts = set(adjacency.keys())
        assert covered == all_districts

    def test_cycle_ordering(self) -> None:
        """Test that cycles are returned in sorted order."""
        adjacency = {1: [2, 3], 2: [1, 3], 3: [1, 2]}

        cycles = find_cycles(adjacency)

        # Cycles should be sorted tuples
        assert cycles[0] == tuple(sorted(cycles[0]))


### END ###
