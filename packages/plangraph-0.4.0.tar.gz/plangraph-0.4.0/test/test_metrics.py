#!/usr/bin/env python3

"""
TEST METRICS OVER PLAN GRAPHS
"""

import os, json

from rdapy import approx_equal

from pggo import (
    PlanGraph,
    get_estimated_dem_seats,
    get_estimated_competitive_districts,
    get_minority_metrics,
    get_cut_score,
    get_compactness_metrics,
    get_district_compactness,
    get_counties_split,
    get_county_splits,
    get_splitting_metrics,
)


with open(os.path.expanduser("testdata/NC_congress_root_map_scores.json"), "r") as f:
    expecteds = json.load(f)

plan: PlanGraph = PlanGraph(
    "NC",
    "congress",
    "testdata/NC_congress_root_map.csv",
    "testdata/NC_input_data.jsonl",
    "testdata/NC_graph.json",
    debug=True,
)


class TestMetrics:
    def test_estimated_seats(self) -> None:
        actual = get_estimated_dem_seats(plan.copy())
        expected = expecteds["estimated_seats"]
        assert approx_equal(actual, expected, places=2)

    def test_competitive_districts(self) -> None:
        actual = get_estimated_competitive_districts(plan.copy())
        expected = expecteds["competitive_districts"]
        assert approx_equal(actual, expected, places=2)

    def test_minority_metrics(self) -> None:
        actual = get_minority_metrics(plan.copy())
        expected = {
            "opportunity_districts": expecteds["opportunity_districts"],
            "coalition_districts": expecteds["coalition_districts"],
        }
        for key in expected:
            assert approx_equal(actual[key], expected[key], places=2)

    def test_cut_score(self) -> None:
        actual = get_cut_score(plan.copy())
        expected = expecteds["cut_score"]
        assert approx_equal(actual, expected, places=2)

    def test_compactness_metrics(self) -> None:
        actual = get_compactness_metrics(plan.copy())
        expected = {
            "reock": expecteds["reock"],
            "polsby_popper": expecteds["polsby_popper"],
        }
        for key in expected:
            assert approx_equal(actual[key], expected[key], places=4)

    def test_district_compactness(self) -> None:
        actual = get_district_compactness(plan.copy(), district=1)
        assert actual is not None and actual > 0.0 and actual <= 1.0

    def test_counties_split(self) -> None:
        actual = get_counties_split(plan.copy())
        expected = expecteds["counties_split"]
        assert actual == expected

    def test_county_splits(self) -> None:
        actual = get_county_splits(plan.copy())
        expected = expecteds["county_splits"]
        assert actual == expected

    def test_splitting_metrics(self) -> None:
        actual = get_splitting_metrics(plan.copy())
        expected = {
            "county": expecteds["county_splitting"],
            "district": expecteds["district_splitting"],
        }
        for key in expected:
            assert approx_equal(actual[key], expected[key], places=4)


### END ###
