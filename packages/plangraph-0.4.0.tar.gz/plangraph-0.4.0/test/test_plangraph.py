#!/usr/bin/env python3

"""
TEST PLAN GRAPH METHODS
"""

import os, json
import networkx as nx

from pggo import PlanGraph, Graft

with open(os.path.expanduser("testdata/NC_congress_root_map_scores.json"), "r") as f:
    expecteds = json.load(f)

plan: PlanGraph = PlanGraph(
    "NC",
    "congress",
    "testdata/NC_congress_root_map.csv",
    "testdata/NC_input_data.jsonl",
    "testdata/NC_graph.json",
    debug=True,
)


def are_consistent(plan: PlanGraph) -> bool:
    """Check if the assignments and graph district data are consistent."""

    for geoid in plan.graph.nodes():
        district_in_graph = plan.graph.nodes[geoid].get("district")
        district_in_assignments = plan.assignments.get(geoid)
        if district_in_graph != district_in_assignments:
            return False
    return True


class TestPlanGraph:
    def test_assignments_consistency(self) -> None:
        # self.assignments and self.graph geoid:district assignments start consistent
        assert are_consistent(plan)

        # And they stay consistent
        geoid: str = "37121000004"  # GRASSY CREEK
        moves: Graft = Graft([geoid], 1, 4)

        next: PlanGraph = plan.copy()
        next.splice(moves)
        assert are_consistent(next)

        actual = next.generate()
        assert actual == 1

    def test_district_subgraph(self) -> None:
        S: int = 1
        D: int = 4

        SG: nx.Graph = plan.copy().district_subgraph(S)
        DG: nx.Graph = plan.copy().district_subgraph(D)

        assert True  # Just make sure these run without error

    def test_get_precinct_attr(self) -> None:
        geoid: str = "37121000004"  # GRASSY CREEK

        district: int = plan.get_precinct(geoid, "district")
        assert district == 1

        pop: float = plan.get_precinct(geoid, "total_pop")
        assert pop == 8040


### END ###
