# pggo

A redistricting plan graph for goal optimization (PGGO or "pogo")

## Installing the Package

To install the package:

```bash
pip install plangraph
```

The latest version of the package is 0.4.0.

Then in your code, either `import pggo` or `from pggo import ...`.
Note: The import name is different from the package name.

## Getting Started

```python
from pggo import PlanGraph

plan: PlanGraph = PlanGraph(
    "NC",
    "congress",
    "testdata/NC_congress_root_map.csv",
    "testdata/NC_input_data.jsonl",
    "testdata/NC_graph.json",
)
```

See [PlanGraph.md](docs/PlanGraph.md) for using a PlanGraph.
See [Metrics.md](docs/Metrics.md) for predefined metrics ("scores").

## Testing

Run automated tests with:

```bash
pytest
```

