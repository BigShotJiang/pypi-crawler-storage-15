import logging

LOGGER = logging.getLogger("chartlets")
