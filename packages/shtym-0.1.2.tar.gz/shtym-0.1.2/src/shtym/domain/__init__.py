"""Domain layer for shtym."""
