"""Infrastructure layer for shtym."""
