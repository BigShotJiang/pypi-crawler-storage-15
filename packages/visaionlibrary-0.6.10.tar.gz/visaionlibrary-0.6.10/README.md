# visaionlibrary

## Install
```
pip install \
-i https://pypi.tuna.tsinghua.edu.cn/simple \
--extra-index-url https://download.pytorch.org/whl/cu118 \
visaionlibrary
```

## Directory
- configs: configuration files in mmopenlab format
- templates: configuration files in visaion format
- tests: collection of test files
- tools: collection of tool files