import pandas as pd
import json
from typing import Union

class HorsePY:
    def __init__(self):
        pass

    def load_file(self, file_path: str) -> pd.DataFrame:
        """Load CSV, XLS/XLSX, or JSON into DataFrame"""
        if file_path.endswith('.csv'):
            return pd.read_csv(file_path)
        elif file_path.endswith('.xls') or file_path.endswith('.xlsx'):
            return pd.read_excel(file_path)
        elif file_path.endswith('.json'):
            with open(file_path, 'r') as f:
                data = json.load(f)
            return pd.json_normalize(data)
        else:
            raise ValueError("Unsupported file format")

    def clean_data(self, df: pd.DataFrame) -> pd.DataFrame:
        """Clean data: remove nulls and duplicates"""
        df = df.dropna()  # remove null rows
        df = df.drop_duplicates()  # remove duplicate rows
        return df

    def analyze(self, df: pd.DataFrame):
        """Basic analysis"""
        return {
            "shape": df.shape,
            "columns": list(df.columns),
            "summary": df.describe(include='all', datetime_is_numeric=True)
        }

    def process_file(self, file_path: str):
        df = self.load_file(file_path)
        cleaned_df = self.clean_data(df)
        analysis = self.analyze(cleaned_df)
        return cleaned_df, analysis

# Example usage:
# framework = DataFramework()
# cleaned, report = framework.process_file("data.csv")
# print(report)
