"""
Test suite for Pocket.
"""
