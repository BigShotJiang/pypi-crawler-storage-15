"""
Tests for project module.
"""
