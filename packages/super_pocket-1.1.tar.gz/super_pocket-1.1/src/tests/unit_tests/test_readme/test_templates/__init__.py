"""Tests for README templates."""
