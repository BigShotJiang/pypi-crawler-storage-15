"""
Tests for web module.
"""
