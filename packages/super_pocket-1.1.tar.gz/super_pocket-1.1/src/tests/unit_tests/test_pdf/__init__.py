"""
Tests for PDF module.
"""
