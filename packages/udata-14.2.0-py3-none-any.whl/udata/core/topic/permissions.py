from udata.core.dataset.permissions import OwnablePermission


class TopicEditPermission(OwnablePermission):
    pass
