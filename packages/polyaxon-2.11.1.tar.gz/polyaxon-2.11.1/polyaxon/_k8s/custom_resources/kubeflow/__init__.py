from polyaxon._k8s.custom_resources.kubeflow.mpi_job import get_mpi_job_custom_resource
from polyaxon._k8s.custom_resources.kubeflow.mx_job import get_mx_job_custom_resource
from polyaxon._k8s.custom_resources.kubeflow.paddle_job import (
    get_paddle_job_custom_resource,
)
from polyaxon._k8s.custom_resources.kubeflow.pytorch_job import (
    get_pytorch_job_custom_resource,
)
from polyaxon._k8s.custom_resources.kubeflow.tf_job import get_tf_job_custom_resource
from polyaxon._k8s.custom_resources.kubeflow.xgb_job import get_xgb_job_custom_resource
