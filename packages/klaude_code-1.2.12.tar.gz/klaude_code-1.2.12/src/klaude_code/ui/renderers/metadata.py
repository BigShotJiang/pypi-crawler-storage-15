from importlib.metadata import version

from rich import box
from rich.box import Box
from rich.console import Group, RenderableType
from rich.padding import Padding
from rich.panel import Panel
from rich.text import Text

from klaude_code.protocol import events, model
from klaude_code.trace import is_debug_enabled
from klaude_code.ui.rich.theme import ThemeKey
from klaude_code.ui.utils.common import format_number


def _get_version() -> str:
    """Get the current version of klaude-code."""
    try:
        return version("klaude-code")
    except Exception:
        return "unknown"


def _render_task_metadata_block(
    metadata: model.TaskMetadata,
    *,
    indent: int = 0,
    show_context_and_time: bool = True,
) -> list[RenderableType]:
    """Render a single TaskMetadata block.

    Args:
        metadata: The TaskMetadata to render.
        indent: Number of spaces to indent (0 for main, 2 for sub-agents).
        show_context_and_time: Whether to show context usage percent and time.

    Returns:
        List of renderables for this metadata block.
    """
    # Get currency symbol
    currency = metadata.usage.currency if metadata.usage else "USD"
    currency_symbol = "¥" if currency == "CNY" else "$"

    # Line 1: Model and Provider
    prefix = (
        Text(" " * indent + "• ", style=ThemeKey.METADATA_BOLD)
        if indent == 0
        else Text(" " * indent + "└ ", style=ThemeKey.METADATA_DIM)
    )
    model_text = Text()
    model_text.append_text(prefix).append_text(Text(metadata.model_name, style=ThemeKey.METADATA_BOLD))
    if metadata.provider is not None:
        model_text.append_text(Text("@", style=ThemeKey.METADATA)).append_text(
            Text(metadata.provider.lower().replace(" ", "-"), style=ThemeKey.METADATA)
        )

    renderables: list[RenderableType] = [model_text]

    # Line 2: Token consumption, Context, TPS, Cost
    parts2: list[Text] = []

    if metadata.usage is not None:
        # Input
        input_parts: list[tuple[str, str]] = [
            ("input:", ThemeKey.METADATA_DIM),
            (format_number(metadata.usage.input_tokens), ThemeKey.METADATA_DIM),
        ]
        if metadata.usage.input_cost is not None:
            input_parts.append((f"({currency_symbol}{metadata.usage.input_cost:.4f})", ThemeKey.METADATA_DIM))
        parts2.append(Text.assemble(*input_parts))

        # Cached
        if metadata.usage.cached_tokens > 0:
            cached_parts: list[tuple[str, str]] = [
                ("cached:", ThemeKey.METADATA_DIM),
                (format_number(metadata.usage.cached_tokens), ThemeKey.METADATA_DIM),
            ]
            if metadata.usage.cache_read_cost is not None:
                cached_parts.append((f"({currency_symbol}{metadata.usage.cache_read_cost:.4f})", ThemeKey.METADATA_DIM))
            parts2.append(Text.assemble(*cached_parts))

        # Output
        output_parts: list[tuple[str, str]] = [
            ("output:", ThemeKey.METADATA_DIM),
            (format_number(metadata.usage.output_tokens), ThemeKey.METADATA_DIM),
        ]
        if metadata.usage.output_cost is not None:
            output_parts.append((f"({currency_symbol}{metadata.usage.output_cost:.4f})", ThemeKey.METADATA_DIM))
        parts2.append(Text.assemble(*output_parts))

        # Reasoning
        if metadata.usage.reasoning_tokens > 0:
            parts2.append(
                Text.assemble(
                    ("thinking", ThemeKey.METADATA_DIM),
                    (":", ThemeKey.METADATA_DIM),
                    (
                        format_number(metadata.usage.reasoning_tokens),
                        ThemeKey.METADATA_DIM,
                    ),
                )
            )

    # Cost
    if metadata.usage is not None and metadata.usage.total_cost is not None:
        parts2.append(
            Text.assemble(
                ("cost", ThemeKey.METADATA_DIM),
                (":", ThemeKey.METADATA_DIM),
                (f"{currency_symbol}{metadata.usage.total_cost:.4f}", ThemeKey.METADATA_DIM),
            )
        )
    if parts2:
        line2 = Text(" / ", style=ThemeKey.METADATA_DIM).join(parts2)
        renderables.append(Padding(line2, (0, 0, 0, indent + 2)))

    parts3: list[Text] = []
    if metadata.usage is not None:
        # Context (only for main agent)
        if show_context_and_time and metadata.usage.context_usage_percent is not None:
            context_size = format_number(metadata.usage.context_size or 0)
            parts3.append(
                Text.assemble(
                    ("context", ThemeKey.METADATA_DIM),
                    (":", ThemeKey.METADATA_DIM),
                    (
                        f"{context_size}({metadata.usage.context_usage_percent:.1f}%)",
                        ThemeKey.METADATA_DIM,
                    ),
                )
            )

        # TPS
        if metadata.usage.throughput_tps is not None:
            parts3.append(
                Text.assemble(
                    ("tps", ThemeKey.METADATA_DIM),
                    (":", ThemeKey.METADATA_DIM),
                    (f"{metadata.usage.throughput_tps:.1f}", ThemeKey.METADATA_DIM),
                )
            )

    # Duration
    if show_context_and_time and metadata.task_duration_s is not None:
        parts3.append(
            Text.assemble(
                ("time", ThemeKey.METADATA_DIM),
                (":", ThemeKey.METADATA_DIM),
                (f"{metadata.task_duration_s:.1f}s", ThemeKey.METADATA_DIM),
            )
        )

    # Turn count
    if show_context_and_time and metadata.turn_count > 0:
        parts3.append(
            Text.assemble(
                ("turns", ThemeKey.METADATA_DIM),
                (":", ThemeKey.METADATA_DIM),
                (str(metadata.turn_count), ThemeKey.METADATA_DIM),
            )
        )

    if parts3:
        line2 = Text(" / ", style=ThemeKey.METADATA_DIM).join(parts3)
        renderables.append(Padding(line2, (0, 0, 0, indent + 2)))

    return renderables


def render_task_metadata(e: events.TaskMetadataEvent) -> RenderableType:
    """Render task metadata including main agent and sub-agents, aggregated by model+provider."""
    renderables: list[RenderableType] = []

    renderables.extend(_render_task_metadata_block(e.metadata.main, indent=0, show_context_and_time=True))

    # Aggregate by (model_name, provider), sorted by total_cost descending
    sorted_items = model.TaskMetadata.aggregate_by_model(e.metadata.sub_agent_task_metadata)

    # Render each aggregated model block
    for meta in sorted_items:
        renderables.extend(_render_task_metadata_block(meta, indent=2, show_context_and_time=False))

    return Group(*renderables)


def render_welcome(e: events.WelcomeEvent, *, box_style: Box | None = None) -> RenderableType:
    """Render the welcome panel with model info and settings."""
    if box_style is None:
        box_style = box.ROUNDED

    debug_mode = is_debug_enabled()

    # First line: Klaude Code version
    klaude_code_style = ThemeKey.WELCOME_DEBUG_TITLE if debug_mode else ThemeKey.WELCOME_HIGHLIGHT_BOLD
    panel_content = Text.assemble(
        ("Klaude Code", klaude_code_style),
        (f" v{_get_version()}\n", ThemeKey.WELCOME_INFO),
        (str(e.llm_config.model), ThemeKey.WELCOME_HIGHLIGHT),
        (" @ ", ThemeKey.WELCOME_INFO),
        (e.llm_config.provider_name, ThemeKey.WELCOME_INFO),
    )

    # Collect all config items to display
    config_items: list[tuple[str, str]] = []

    if e.llm_config.thinking is not None:
        if e.llm_config.thinking.reasoning_effort:
            config_items.append(("reasoning-effort", e.llm_config.thinking.reasoning_effort))
        if e.llm_config.thinking.reasoning_summary:
            config_items.append(("reasoning-summary", e.llm_config.thinking.reasoning_summary))
        if e.llm_config.thinking.budget_tokens:
            config_items.append(("thinking-budget", str(e.llm_config.thinking.budget_tokens)))

    if e.llm_config.verbosity:
        config_items.append(("verbosity", str(e.llm_config.verbosity)))

    if pr := e.llm_config.provider_routing:
        if pr.sort:
            config_items.append(("provider-sort", str(pr.sort)))
        if pr.only:
            config_items.append(("provider-only", ">".join(pr.only)))
        if pr.order:
            config_items.append(("provider-order", ">".join(pr.order)))

    # Render config items with tree-style prefixes
    for i, (key, value) in enumerate(config_items):
        is_last = i == len(config_items) - 1
        prefix = "└─ " if is_last else "├─ "
        panel_content.append_text(
            Text.assemble(
                ("\n", ThemeKey.WELCOME_INFO),
                (prefix, ThemeKey.LINES),
                (f"{key}: ", ThemeKey.WELCOME_INFO),
                (value, ThemeKey.WELCOME_INFO),
            )
        )

    border_style = ThemeKey.WELCOME_DEBUG_BORDER if debug_mode else ThemeKey.LINES
    return Group(
        Panel.fit(panel_content, border_style=border_style, box=box_style),
        "",  # empty line
    )
