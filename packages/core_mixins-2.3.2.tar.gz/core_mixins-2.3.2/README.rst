core-mixins
===============================================================================

This project contains common functions, decorators, and mixin classes 
as the base for other projects or libraries...

===============================================================================

.. image:: https://img.shields.io/pypi/pyversions/core-mixins.svg
    :target: https://pypi.org/project/core-mixins/
    :alt: Python Versions

.. image:: https://img.shields.io/badge/license-MIT-blue.svg
    :target: https://gitlab.com/bytecode-solutions/core/core-mixins/-/blob/main/LICENSE
    :alt: License

.. image:: https://gitlab.com/bytecode-solutions/core/core-mixins/badges/release/pipeline.svg
    :target: https://gitlab.com/bytecode-solutions/core/core-mixins/-/pipelines
    :alt: Pipeline Status

.. image:: https://readthedocs.org/projects/core-mixins/badge/?version=latest
    :target: https://readthedocs.org/projects/core-mixins/
    :alt: Docs Status

.. image:: https://img.shields.io/badge/security-bandit-yellow.svg
    :target: https://github.com/PyCQA/bandit
    :alt: Security

|


Installation
===============================================================================

Install from PyPI using pip:

.. code-block:: bash

    pip install core-mixins
    uv pip install core-mixins  # Or using UV...


Features
===============================================================================

This library provides the following modules and utilities:

**Compatibility**
  - ``Self`` - Type hint for self-referential classes
  - ``StrEnum`` - String enumeration compatibility across Python versions

**Decorators** (``core_mixins.decorators``)
  - ``cache`` - Memoization decorator for function results
  - ``count_calls`` / ``CountCalls`` - Track function call counts
  - ``repeat`` - Execute functions multiple times
  - ``retry`` - Automatic retry with configurable backoff
  - ``singleton`` - Enforce single instance pattern
  - ``SyncWrapper`` - Convert async functions to synchronous
  - ``with_timeout`` - Executes a function that will time out after the specified value.
  - ``timer`` - Measure function execution time

**File Utilities** (``core_mixins.files``)
  - ``records_from_csv`` / ``records_to_csv`` - CSV file handling
  - ``records_from_buffer`` / ``records_to_buffer`` - In-memory CSV operations

**Interfaces** (``core_mixins.interfaces``)
  - ``IFactory`` - Factory pattern interface
  - ``ITask`` - Task interface with status tracking
  - ``TaskStatus`` - Task state enumeration
  - ``TaskException`` - Task-specific exceptions

**Managers** (``core_mixins.managers``)
  - ``TasksManager`` - Manage and execute multiple tasks
  - ``TaskResult`` - Task execution result container

**Logging** (``core_mixins.logger``)
  - ``get_logger`` - Standardized logger configuration

**Utilities** (``core_mixins.utils``)
  - ``random_string`` - Generate random strings
  - ``get_batches`` - Batch list processing
  - ``remove_attributes`` / ``rename_attributes`` / ``add_attributes`` - Dictionary manipulation
  - ``convert_data_type`` - Type conversion utilities
  - ``to_snake_case`` - Convert strings to snake_case
  - ``flatten_json`` - Flatten nested JSON structures
  - ``to_one_line`` - Convert multiline strings to single line
  - ``bytes_to_str`` - Convert bytes to string

**Exceptions** (``core_mixins.exceptions``)
  - ``get_exception_data`` - Extract structured exception information


Quick Start
===============================================================================

Installation
-------------------------------------------------------------------------------

Install the package:

.. code-block:: bash

    pip install core-mixins
    uv pip install core-mixins  # Or using UV...
    pip install -e ".[dev]"    # For development...

Setting Up Environment
-------------------------------------------------------------------------------

1. Install required libraries:

.. code-block:: bash

    pip install --upgrade pip
    pip install virtualenv

2. Create Python virtual environment:

.. code-block:: bash

    virtualenv --python=python3.12 .venv

3. Activate the virtual environment:

.. code-block:: bash

    source .venv/bin/activate

Install packages
-------------------------------------------------------------------------------

.. code-block:: bash

    pip install .
    pip install -e ".[dev]"

Check tests and coverage
-------------------------------------------------------------------------------

.. code-block:: shell

    python manager.py run-tests
    python manager.py run-coverage


Contributing
===============================================================================

Contributions are welcome! Please:

1. Fork the repository
2. Create a feature branch
3. Write tests for new functionality
4. Ensure all tests pass: ``pytest -n auto``
5. Run linting: ``pylint core_mixins``
6. Run security checks: ``bandit -r core_mixins``
7. Submit a pull request


License
===============================================================================

This project is licensed under the MIT License. See the LICENSE file for details.


Links
===============================================================================

* **Documentation:** https://core-mixins.readthedocs.io/en/latest/
* **Repository:** https://gitlab.com/bytecode-solutions/core/core-mixins
* **Issues:** https://gitlab.com/bytecode-solutions/core/core-mixins/-/issues
* **Changelog:** https://gitlab.com/bytecode-solutions/core/core-mixins/-/blob/master/CHANGELOG.md
* **PyPI:** https://pypi.org/project/core-mixins/


Support
===============================================================================

For questions or support, please open an issue on GitLab or contact the maintainers.


Authors
===============================================================================

* **Alejandro Cora González** - *Initial work* - alek.cora.glez@gmail.com
