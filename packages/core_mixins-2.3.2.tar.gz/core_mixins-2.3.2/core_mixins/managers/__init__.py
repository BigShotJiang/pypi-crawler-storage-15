# -*- coding: utf-8 -*-

"""Task management utilities for executing and tracking multiple tasks."""

from .tasks_manager import TaskResult, TasksManager


__all__ = [
    "TaskResult",
    "TasksManager",
]
