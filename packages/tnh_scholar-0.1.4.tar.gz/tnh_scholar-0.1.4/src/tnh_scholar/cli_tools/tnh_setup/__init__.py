from .tnh_setup import main, tnh_setup
