# Workspace


## Enum

* `PERSONAL` (value: `'personal'`)

* `TEAM` (value: `'team'`)

* `PUBLIC` (value: `'public'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


