"""Key derivation functions"""
