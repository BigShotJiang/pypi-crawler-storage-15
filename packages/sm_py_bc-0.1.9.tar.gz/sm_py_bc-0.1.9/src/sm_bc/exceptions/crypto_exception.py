"""Base cryptographic exception."""


class CryptoException(Exception):
    """Base class for cryptographic exceptions."""
    pass
