"""Model configuration data files.

This package contains versioned JSON configuration files for model definitions.
Required for importlib.resources to properly access bundled data files.
"""
