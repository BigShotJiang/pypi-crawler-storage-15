class CensoredResultException(Exception):
    pass
