export const ENTITY_SET_TYPES = {
    unordered: "unordered",
    ordered: "ordered",
};
