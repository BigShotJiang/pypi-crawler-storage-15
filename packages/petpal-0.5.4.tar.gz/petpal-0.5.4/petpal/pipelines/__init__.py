from . import steps_base
from . import steps_containers
from . import preproc_steps
from . import kinetic_modeling_steps
from . import pca_guided_idif_steps
from . import pipelines

def main():
    print("PETPAL - Pipelines")


if __name__ == "__main__":
    main()
