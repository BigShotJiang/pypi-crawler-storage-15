"""
Setup script for docfind.

Use pyproject.toml for configuration.
"""

from setuptools import setup

if __name__ == "__main__":
    setup()
