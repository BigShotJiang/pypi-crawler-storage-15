# -*- coding: utf-8 -*-

KEY_ID = "id"
KEY_SERVER_IDS = "server_ids"
KEY_CONFIG_NAME = "config_name"
KEY_URL = "url"
KEY_ENV_MCP_CONFIG_PATH = "MCP_CONFIG_PATH"
