# ruff: noqa
from tpu_commons.platforms.tpu_jax import TpuPlatform
