
import os
import json
import boto3
from constructs import Construct
from cdktf import TerraformStack, S3Backend, TerraformOutput
from imports.aws.provider import AwsProvider
from imports.aws.iam_role import IamRole
from imports.aws.iam_role_policy import IamRolePolicy
from imports.aws.iam_instance_profile import IamInstanceProfile
from imports.aws.s3_bucket import S3Bucket
from imports.aws.s3_bucket_versioning import S3BucketVersioningA
from imports.aws.s3_object import S3Object
from imports.aws.secretsmanager_secret import SecretsmanagerSecret
from imports.aws.ecr_repository import EcrRepository
from imports.aws.data_aws_ecr_repository import DataAwsEcrRepository
from imports.aws.db_instance import DbInstance
from imports.aws.data_aws_db_instance import DataAwsDbInstance
from imports.aws.instance import Instance
from imports.aws.security_group import SecurityGroup, SecurityGroupIngress, SecurityGroupEgress
from .config import DEFAULTS
from .uploader import upload_runtime_files
from .ArchitectureHelpers import ArchitectureHelpers


class ArchitectureFlags: 
    SKIP_DATABASE = "skip_database"
    SKIP_ECR = "skip_ecr"
    PRIVATE_EC2 = "private_ec2"

class DockerEC2(TerraformStack):

    @staticmethod
    def get_architecture_flags():
        """ Return architecture flags for this stack. Replace with your actual architecture flags. """
        return ArchitectureFlags
    
    @staticmethod
    def get_archetype(product, app, tier, organization, region):
         """ Get the BuzzerboyArchetype instance for advanced configuration. 
            :param product: Product name :param app: Application name
            :param tier: Environment tier (dev, staging, prod)
            :param organization: Organization name 
            :param region: AWS region 
            
            :returns: BuzzerboyArchetype instance 
            :rtype: BuzzerboyArchetype ..
             note:: This method requires the BuzzerboyArchetypeStack module to be available. 
    """
         
         from BuzzerboyArchetypeStack.BuzzerboyArchetype import BuzzerboyArchetype
         return BuzzerboyArchetype(product=product, app=app, tier=tier, organization=organization, region=region)

    def __init__(self, scope: Construct, id: str, *, project_name: str, **kwargs):
        super().__init__(scope, id)

        # ==========================================================
        # Load defaults + merge in user-provided kwargs
        # ==========================================================
        self.config = dict(DEFAULTS)
        self.config.update(kwargs)

        self.project_name = project_name

        self.architecture_flags = self.config.get("architecture_flags", [])

        # Determine feature flags based on architecture flags
        self.enable_rds = ArchitectureFlags.SKIP_DATABASE not in self.architecture_flags
        self.is_private_ec2 = ArchitectureFlags.PRIVATE_EC2 in self.architecture_flags

        # Get allowList for security group (defaults to everywhere if not provided)
        self.allow_list = self.config.get("allowList", [])

        # Handle dependent defaults
        self.platform_name = self.config["platform_name"] or self.project_name
        self.state_name = self.config["state_name"] or self.platform_name
        self.rds_name = self.config["rds_name"] or project_name
        self.region = self.config["region"]

        # Bucket names
        self.deployment_bucket = (
            self.config["deployment_bucket"]
            or f"{self.platform_name}-deployments"
        )
        self.storage_bucket = (
            self.config["storage_bucket"]
            or self.project_name
        )

        # ==========================================================
        # 1. Ensure Terraform state bucket exists OUTSIDE terraform
        # ==========================================================
        self.ensure_state_bucket()

        # Configure backend now that bucket is ensured
        S3Backend(
            self,
            bucket=f"{self.state_name}-tfstate",
            key=f"{self.project_name}/terraform.tfstate",
            region=self.region
        )

        # ==========================================================
        # 1b. Configure AWS Provider
        # ==========================================================
        AwsProvider(self, "aws", region=self.region)

        # ==========================================================
        # 2. IAM Role + Policy for EC2
        # ==========================================================
        self.iam_role = self.create_iam_role()

        self.iam_profile = IamInstanceProfile(
            self,
            "ec2InstanceProfile",
            name=f"{self.project_name}-instance-profile",
            role=self.iam_role.name
        )

        # ==========================================================
        # 3. ECR — conditional creation
        # ==========================================================
        self.ecr_repo = self.get_or_create_ecr()

        # ==========================================================
        # 4. RDS — conditional creation
        # ==========================================================
        self.rds = self.get_or_create_rds()

        # ==========================================================
        # 5. Deployment bucket — conditional creation
        # ==========================================================
        self.deployment_bucket_resource = self.get_or_create_deployment_bucket()

        # ==========================================================
        # 5b. Upload runtime scripts to S3
        # ==========================================================
        self.upload_runtime_files()

        # ==========================================================
        # 6. Storage bucket — always created
        # ==========================================================
        self.storage_bucket_resource = S3Bucket(
            self,
            "storageBucket",
            bucket=self.storage_bucket
        )

        # ==========================================================
        # 7. Secrets Manager Secret
        # ==========================================================
        self.secret = SecretsmanagerSecret(
            self,
            "projectConfigSecret",
            name=f"/{self.project_name}/config"
        )

        # ==========================================================
        # 8. Security Group for EC2
        # ==========================================================
        self.security_group = self.create_security_group()

        # ==========================================================
        # 9. EC2 instance
        # ==========================================================
        self.ec2_instance = self.create_ec2_instance()

        # ==========================================================
        # 10. Output: List of all resources to be created
        # ==========================================================
        self.create_resource_list_output()


    # =====================================================================
    # Create Terraform Output listing all resources
    # =====================================================================
    def create_resource_list_output(self):
        """
        Create a Terraform output that lists all resource names expected to be created.
        """
        resource_names = []

        # IAM Resources
        resource_names.append(f"IAM Role: {self.project_name}-role")
        resource_names.append(f"IAM Policy: {self.project_name}-policy")
        resource_names.append(f"IAM Instance Profile: {self.project_name}-instance-profile")

        # ECR Repository
        if isinstance(self.ecr_repo, EcrRepository):
            resource_names.append(f"ECR Repository: {self.project_name}")
        else:
            resource_names.append(f"ECR Repository (existing): {self.project_name}")

        # RDS Instance
        if self.rds is not None:
            if isinstance(self.rds, DbInstance):
                resource_names.append(f"RDS Instance: {self.rds_name}")
            else:
                resource_names.append(f"RDS Instance (existing): {self.rds_name}")

        # S3 Buckets
        if self.deployment_bucket_resource is not None:
            resource_names.append(f"S3 Deployment Bucket: {self.deployment_bucket}")
            resource_names.append(f"S3 Deployment Bucket Versioning: {self.deployment_bucket}")
        resource_names.append(f"S3 Storage Bucket: {self.storage_bucket}")

        # Secrets Manager
        resource_names.append(f"Secrets Manager Secret: /{self.project_name}/config")

        # Security Group
        resource_names.append(f"Security Group: {self.project_name}-sg")

        # EC2 Instance
        resource_names.append(f"EC2 Instance: {self.project_name}")

        # Create the Terraform output
        TerraformOutput(
            self,
            "resource_list",
            value=resource_names,
            description="List of all resources expected to be created by this stack"
        )


    # =====================================================================
    # Create state bucket outside Terraform (S3Backend requirement)
    # =====================================================================
    def ensure_state_bucket(self):
        bucket_name = f"{self.state_name}-tfstate"
        s3 = boto3.client("s3", region_name=self.region)

        try:
            s3.head_bucket(Bucket=bucket_name)
            print(f"[INFO] State bucket '{bucket_name}' already exists.")
        except:
            print(f"[INFO] Creating state bucket '{bucket_name}'.")
            s3.create_bucket(
                Bucket=bucket_name,
                CreateBucketConfiguration={"LocationConstraint": self.region}
            )


    # =====================================================================
    # IAM Role + Policy loaded from JSON file
    # =====================================================================
    def create_iam_role(self):
        role = IamRole(
            self,
            "ec2Role",
            name=f"{self.project_name}-role",
            assume_role_policy="""{
              "Version": "2012-10-17",
              "Statement": [
                {
                  "Effect": "Allow",
                  "Principal": { "Service": "ec2.amazonaws.com" },
                  "Action": "sts:AssumeRole"
                }
              ]
            }"""
        )

        policy_path = os.path.join(
            os.path.dirname(__file__),
            "iam",
            "ec2_policy.json"
        )

        with open(policy_path, "r") as f:
            policy_json = json.dumps(json.load(f))

        IamRolePolicy(
            self,
            "ec2InlinePolicy",
            name=f"{self.project_name}-policy",
            role=role.id,
            policy=policy_json
        )

        return role


    # =====================================================================
    # Conditional ECR creation
    # =====================================================================
    def get_or_create_ecr(self):
        repo_name = self.project_name
        ecr_client = boto3.client("ecr", region_name=self.region)

        try:
            ecr_client.describe_repositories(repositoryNames=[repo_name])
            print(f"[INFO] ECR '{repo_name}' exists → using DataAwsEcrRepository")
            return DataAwsEcrRepository(self, "existingEcrRepo", name=repo_name)

        except ecr_client.exceptions.RepositoryNotFoundException:
            print(f"[INFO] ECR '{repo_name}' not found → creating via Terraform")
            return EcrRepository(
                self,
                "ecrRepo",
                name=repo_name,
                force_delete=True
            )


    # =====================================================================
    # Conditional RDS creation
    # =====================================================================
    def get_or_create_rds(self):
        if not self.enable_rds:
            print("[INFO] RDS disabled (SKIP_DATABASE flag set).")
            return None

        rds = boto3.client("rds", region_name=self.region)

        try:
            rds.describe_db_instances(DBInstanceIdentifier=self.rds_name)
            print(f"[INFO] RDS '{self.rds_name}' exists → importing")
            return DataAwsDbInstance(
                self,
                "existingRds",
                db_instance_identifier=self.rds_name
            )

        except:
            print(f"[INFO] Creating RDS '{self.rds_name}' via Terraform")
            return DbInstance(
                self,
                "rdsInstance",
                identifier=self.rds_name,
                engine="postgres",
                instance_class="db.t3.micro",
                allocated_storage=20,
                username="admin",
                password="TempPassword123!",
                skip_final_snapshot=True
            )


    # =====================================================================
    # Deployment bucket — conditional
    # =====================================================================
    def get_or_create_deployment_bucket(self):
        bucket_name = self.deployment_bucket
        s3 = boto3.client("s3", region_name=self.region)

        try:
            s3.head_bucket(Bucket=bucket_name)
            print(f"[INFO] Deployment bucket '{bucket_name}' exists → NOT TF-managed")
            return None

        except:
            print(f"[INFO] Creating deployment bucket '{bucket_name}' via Terraform")

            bucket = S3Bucket(
                self,
                "deploymentBucket",
                bucket=bucket_name
            )

            S3BucketVersioningA(
                self,
                "deploymentBucketVersioning",
                bucket=bucket.id,
                versioning_configuration={"status": "Enabled"}
            )

            return bucket


    # =====================================================================
    # Security Group for EC2
    # =====================================================================
    def create_security_group(self):
        """
        Create a security group for the EC2 instance.
        - If PRIVATE_EC2 flag is set, only allows traffic from allowList IPs
        - Otherwise, allows public HTTP/HTTPS traffic (or from allowList if provided)
        """
        # Determine CIDR blocks for ingress
        if self.allow_list:
            # Use provided allowList - ensure they are in CIDR format
            cidr_blocks = [ip if "/" in ip else f"{ip}/32" for ip in self.allow_list]
        else:
            # Default to everywhere (0.0.0.0/0) if no allowList provided
            cidr_blocks = ["0.0.0.0/0"]

        # Build ingress rules
        ingress_rules = []

        # Only add HTTP/HTTPS ingress if not private EC2, or if allowList is provided
        if not self.is_private_ec2 or self.allow_list:
            # HTTP ingress
            ingress_rules.append(SecurityGroupIngress(
                from_port=80,
                to_port=80,
                protocol="tcp",
                cidr_blocks=cidr_blocks,
                description="HTTP access"
            ))
            # HTTPS ingress
            ingress_rules.append(SecurityGroupIngress(
                from_port=443,
                to_port=443,
                protocol="tcp",
                cidr_blocks=cidr_blocks,
                description="HTTPS access"
            ))

        # Egress rule - allow all outbound traffic
        egress_rules = [SecurityGroupEgress(
            from_port=0,
            to_port=0,
            protocol="-1",
            cidr_blocks=["0.0.0.0/0"],
            description="Allow all outbound traffic"
        )]

        return SecurityGroup(
            self,
            "ec2SecurityGroup",
            name=f"{self.project_name}-sg",
            description=f"Security group for {self.project_name} EC2 instance",
            ingress=ingress_rules,
            egress=egress_rules,
            tags={
                "projectName": self.project_name
            }
        )


    # =====================================================================
    # EC2 Instance
    # =====================================================================
    def create_ec2_instance(self):
        # Generate user data script
        user_data = self.generate_user_data()

        # Determine if we should assign a public IP
        # Public IP is assigned unless PRIVATE_EC2 flag is set
        associate_public_ip = not self.is_private_ec2
        
        return Instance(
            self,
            "ec2Instance",
            ami=self.config["ami_id"],
            instance_type=self.config["instance_type"],
            iam_instance_profile=self.iam_profile.name,
            user_data=user_data,
            vpc_security_group_ids=[self.security_group.id],
            associate_public_ip_address=associate_public_ip,
            root_block_device={
                "volume_size": self.config["disk_size"]
            },
            tags={
                "projectName": self.project_name
            }
        )

    # =====================================================================
    # Generate User Data Script
    # =====================================================================
    def generate_user_data(self) -> str:
        """
        Generate the EC2 user data script that downloads and executes setup.sh
        """
        user_data = ArchitectureHelpers.getFormattedTextFromFile(
            "user_data.sh",
            {
                "deployment_bucket": self.deployment_bucket,
                "project_name": self.project_name
            }
        )
        return user_data

    # =====================================================================
    # Upload Runtime Files to S3
    # =====================================================================
    def upload_runtime_files(self) -> list:
        """
        Upload all runtime scripts to the deployment bucket.
        Uses the uploader module to walk the scripts directory.
        """
        return upload_runtime_files(self, self.deployment_bucket, self.project_name)
