from sample import multiply


def test_mult():
    assert multiply(2, 3) == 6
