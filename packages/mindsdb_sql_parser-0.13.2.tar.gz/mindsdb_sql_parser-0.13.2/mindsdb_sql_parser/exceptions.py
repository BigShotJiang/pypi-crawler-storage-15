class MindsdbSQLException(Exception):
    pass


class ParsingException(MindsdbSQLException):
    pass

