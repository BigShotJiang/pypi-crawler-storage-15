from pipzap.discovery.discover import discover_dependencies

__all__ = ["discover_dependencies"]
