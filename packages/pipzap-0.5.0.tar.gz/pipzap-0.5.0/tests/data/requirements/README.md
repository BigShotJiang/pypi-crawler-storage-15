# Test resources

The current folder contains a wide range of `requirements.txt` instances as they
appear in the wild.

The vast majority of the entries here were gracefully taken from the [pip-requirements-parser](https://github.com/aboutcode-org/pip-requirements-parser/) project, with just a few minor additions.
