"""Main CLI handling code."""

##############################################################################
# Local imports.
from . import main

##############################################################################
# Main entry point.
if __name__ == "__main__":
    main()

### main.py ends here
