# Convert Two Up Imposed PDF

A Python tool to process scanned [2-up](https://en.wikipedia.org/wiki/N-up)
[imposed](https://en.wikipedia.org/wiki/Imposition) PDFs (signature scans)
and produce upright, single-page PDFs in correct reading order.

This tool handles:

* **Alternating 90° rotated scans** (top of page on right/left alternates)
* **2-up page splitting** (left/right halves of each scanned sheet)
* **Signature reordering** to restore natural reading order
* **Optional compression and quality control** for high-DPI scans

---

## Features

* Fully automated for **signature PDFs** (number of pages must be a multiple of 4)
* Outputs a standard, upright PDF ready for printing or digital use
* Adjustable JPEG compression for smaller file sizes
* Cross-platform (requires Python 3.8+)

---

## Installation

```shell
pip install convert-two-up-imposed-pdf
```

---

## Usage

```bash
convert-two-up-imposed-pdf <input_pdf> <output_pdf> [--dpi DPI]
```

### Arguments

| Argument     | Description                                                                                      |
| ------------ | ------------------------------------------------------------------------------------------------ |
| `input_pdf`  | Path to the scanned 2-up PDF file                                                                |
| `output_pdf` | Path to save the final upright, single-page PDF                                                  |
| `--dpi`      | (Optional) Render DPI for rasterization. Default: 150. Higher DPI → better quality, larger files |

---

### Example

```bash
convert-two-up-imposed-pdf scanned_booklet.pdf output_booklet.pdf --dpi 200
```

* Detects the number of scanned sheets
* Computes total logical pages
* Applies alternating rotation correction
* Splits 2-up pages
* Reorders pages according to booklet imposition
* Saves the final upright PDF

---

## Compression and Quality Tips

* By default, pages are saved as JPEG to reduce file size
* Adjust `--dpi` for higher or lower resolution
* You can tweak the JPEG quality in the code (default: 85) to balance file size and image fidelity
* Optional grayscale conversion and subsampling further reduce file size for text-heavy scans

---

## Requirements

* Python 3.8+
* [PyMuPDF](https://pypi.org/project/PyMuPDF/)
* [Pillow](https://pypi.org/project/Pillow/)

---

## Limitations

* Total logical pages must be a multiple of 4
* Assumes strictly alternating rotation for scanned pages (top of page right/left)
* Works best for scanned image-based PDFs; vector PDFs may not behave as expected

---

## License

[Unlicense](https://choosealicense.com/licenses/unlicense/)

---

## Acknowledgements

Most code in this repository, including this README, was produced by the ChatGPT (OpenAI) LLM.
Some tweaks and improvements were made by the human author. The human author reviewed and verified all output.

* Uses [PyMuPDF](https://pymupdf.readthedocs.io/) for PDF processing
* Uses [Pillow](https://pillow.readthedocs.io/) for image manipulation
