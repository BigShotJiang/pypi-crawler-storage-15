#!/usr/bin/env python3
import argparse
import io
import fitz  # PyMuPDF
from PIL import Image

def signature_order(total_pages):
    """
    Return the list of page numbers in signature (imposed) order.
    total_pages must be divisible by 4.
    """
    if total_pages % 4 != 0:
        raise ValueError("Total pages must be a multiple of 4 for signatures.")

    sheets = total_pages // 4
    result = []
    for s in range(sheets):
        left_outer = total_pages - (2 * s)
        right_outer = 1 + (2 * s)
        left_inner = 2 + (2 * s)
        right_inner = total_pages - 1 - (2 * s)
        result.extend([left_outer, right_outer, left_inner, right_inner])
    return result


def pil_from_pixmap(pix):
    """
    Convert a fitz.Pixmap to a Pillow Image.
    """
    mode = "RGBA" if pix.alpha else "RGB"
    img = Image.frombytes(mode, (pix.width, pix.height), pix.samples)
    if mode == "RGBA":
        # Convert to RGB (drop alpha) since we will embed as PNG; keep white background
        bg = Image.new("RGB", img.size, (255, 255, 255))
        bg.paste(img, mask=img.split()[3])  # 3 is alpha
        return bg
    return img


def split_and_reorder_rotated_images(input_pdf, total_pages, output_pdf="output.pdf", render_dpi=150):
    """
    Render each scanned sheet to an image, rotate alternately, split left/right,
    and reassemble into a reordered single-page PDF.

    Parameters:
      input_pdf: path to 2-up scanned PDF (each page is a scanned sheet)
      total_pages: total logical pages expected (must be scanned_pages * 2)
      output_pdf: path to save final PDF
      render_dpi: rasterization DPI (higher = larger images)
    """
    sig = signature_order(total_pages)
    expected_scans = len(sig) // 2

    src = fitz.open(input_pdf)
    if len(src) != expected_scans:
        raise ValueError(
            f"Scanned PDF has {len(src)} pages but expected {expected_scans} "
            f"based on signature with {total_pages} logical pages."
        )

    # We'll keep a map: logical_page_number -> (width_px, height_px, png_bytes)
    logical_images = {}

    # choose a scaling matrix based on dpi
    # PyMuPDF default is 72dpi; scale = dpi/72
    scale = render_dpi / 72.0
    mat = fitz.Matrix(scale, scale)

    src_pages = list(range(len(src)))[::-1]

    for scan_index, (left_num, right_num) in enumerate(zip(sig[0::2], sig[1::2])):

        real_scan_index = src_pages[scan_index]
        page = src.load_page(real_scan_index)

        # render to pixmap at chosen DPI
        pix = page.get_pixmap(matrix=mat, alpha=False)
        img = pil_from_pixmap(pix)

        # rotation: even index => top on right => rotate -90 to upright
        #           odd  index => top on left  => rotate +90 to upright
        if scan_index % 2 == 0:
            angle = -90
        else:
            angle = 90
        img = img.rotate(angle, expand=True)

        w, h = img.size
        half = w // 2

        left_img = img.crop((0, 0, half, h))
        right_img = img.crop((half, 0, w, h))

        # Save each half to PNG bytes
        bio_left = io.BytesIO()
        # left_img.save(bio_left, format="PNG")
        left_img.save(bio_left, format="JPEG", quality=85, optimize=True)

        left_bytes = bio_left.getvalue()
        bio_right = io.BytesIO()
        # right_img.save(bio_right, format="PNG")
        right_img.save(bio_right, format="JPEG", quality=85, optimize=True)
        right_bytes = bio_right.getvalue()

        # Store: note widths/heights are in pixels at render_dpi; we'll use these
        logical_images[left_num] = (left_img.width, left_img.height, left_bytes)
        logical_images[right_num] = (right_img.width, right_img.height, right_bytes)

    # Now assemble final PDF: iterate logical pages 1..total_pages, insert images as PDF pages
    final = fitz.Document()
    for pnum in range(1, total_pages + 1):
        if pnum not in logical_images:
            raise RuntimeError(f"Missing logical page {pnum} in split results.")
        w_px, h_px, png_bytes = logical_images[pnum]

        # Convert pixel dimensions back to PDF points using DPI
        # 1 point == 1/72 inch. At render_dpi, pixels -> points: points = pixels * (72 / render_dpi)
        pts_w = w_px * (72.0 / render_dpi)
        pts_h = h_px * (72.0 / render_dpi)

        page = final.new_page(width=pts_w, height=pts_h)
        # place image covering entire page
        rect = fitz.Rect(0, 0, pts_w, pts_h)
        page.insert_image(rect, stream=png_bytes)

    final.save(output_pdf)
    print(f"Saved corrected + split + reordered PDF: {output_pdf}")


def main():
    parser = argparse.ArgumentParser(
        description="Split 2-up rotated signature scans into upright single pages in correct reading order."
    )
    parser.add_argument("input_pdf", help="Input scanned 2-up PDF")
    parser.add_argument("output_pdf", help="Output single-page upright PDF")
    parser.add_argument("--dpi", type=int, default=150, help="Render DPI for rasterization (default: 150). Higher = larger image files.")
    args = parser.parse_args()

    src = fitz.open(args.input_pdf)
    scanned_pages = len(src)
    total_pages = scanned_pages * 2

    if total_pages % 4 != 0:
        raise ValueError(
            f"Total logical pages ({total_pages}) is not a multiple of 4. "
            f"Signature imposition requires multiples of 4."
        )

    print(f"Detected {scanned_pages} scanned sheets → {total_pages} logical pages.")
    split_and_reorder_rotated_images(args.input_pdf, total_pages, args.output_pdf, render_dpi=args.dpi)


if __name__ == "__main__":
    main()
