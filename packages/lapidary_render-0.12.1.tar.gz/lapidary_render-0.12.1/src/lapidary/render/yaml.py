import ruamel.yaml

yaml = ruamel.yaml.YAML(typ='safe')
