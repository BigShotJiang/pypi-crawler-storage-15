if __name__ == '__main__':
    from lapidary.render.cli import app

    app()
