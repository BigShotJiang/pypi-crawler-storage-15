# Blueprints package 
from .idea_house import idea_house_bp
from .paper_analysis import paper_analysis_bp
from .feature_engineering import feature_engineering_bp
from .inspiration_house import inspiration_house_bp 