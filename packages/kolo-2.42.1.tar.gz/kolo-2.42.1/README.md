# Kolo

See everything happening in your running Django app

More information: https://kolo.app

![Annotated Kolo screenshot](https://user-images.githubusercontent.com/7718702/120298398-f3d17800-c2c1-11eb-9052-9adbbff0b5f5.png)
