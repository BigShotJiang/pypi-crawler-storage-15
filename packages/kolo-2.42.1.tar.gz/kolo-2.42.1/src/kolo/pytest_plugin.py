from __future__ import annotations


def pytest_runtest_logstart(nodeid, location):
    """Stub start test hook for PytestFilter"""


def pytest_runtest_logfinish(nodeid, location):
    """Stub end test hook for PytestFilter"""
