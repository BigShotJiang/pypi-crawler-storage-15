#!/usr/bin/env python

class PreviewFeatureWarning(UserWarning):
    """Warning for experimental preview features."""
    pass
