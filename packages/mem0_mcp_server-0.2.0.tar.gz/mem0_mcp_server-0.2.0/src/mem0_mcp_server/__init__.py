"""Mem0 MCP server package."""

from .server import main

__all__ = ["main"]
