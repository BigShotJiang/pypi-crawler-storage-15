"""MCP Server for Celebrity By Api Ninjas"""
