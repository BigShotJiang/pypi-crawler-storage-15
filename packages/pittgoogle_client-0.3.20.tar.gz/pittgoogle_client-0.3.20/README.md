# pittgoogle-client

[![code quality](https://app.codacy.com/project/badge/Grade/ec909deaf09840f3b3f645f045dea468)](https://app.codacy.com/gh/mwvgroup/pittgoogle-client/dashboard)
[![coverage](https://app.codacy.com/project/badge/Coverage/ec909deaf09840f3b3f645f045dea468)](https://app.codacy.com/gh/mwvgroup/pittgoogle-client/dashboard)

Read the docs: [mwvgroup.github.io/pittgoogle-client](https://mwvgroup.github.io/pittgoogle-client/).

This is the client package for the
[Pitt-Google astronomical alert broker](https://pitt-broker.rtfd.io/).
