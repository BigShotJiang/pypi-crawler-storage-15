# SimpNMR

## Documentation and Installation

To get started, head to the online documentation for `SimpNMR` [here](https://suturina-group.gitlab.io/simpnmr/).

## Developers

Install in editable mode by running

```
pip install -e .
```

in the repository HEAD.

