from simpnmr.cli import *
from .__version__ import __version__

"""
SimpNMR is a package for working with paramagnetic NMR spectra
"""