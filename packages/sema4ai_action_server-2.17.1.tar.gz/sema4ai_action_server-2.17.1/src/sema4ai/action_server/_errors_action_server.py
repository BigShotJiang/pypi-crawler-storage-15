class ActionServerError(RuntimeError):
    pass


class ActionServerValidationError(ActionServerError):
    pass
