import requests
import re

from .getData import fetch_yageo_part


def _to_float(value):
    """Extracts the first floating-point number from a string or returns float(value)."""
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    match = re.search(r"[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?", str(value))
    return float(match.group(0)) if match else None


def get_dimensions_alt(pn: str):
    url = f"https://search.kemet.com/intellidata/unique-parts/{pn}"
    resp = requests.get(url)
    resp.raise_for_status()
    data = resp.json()

    dims = {"length": None, "height": None, "thickness": None}

    for param in data.get("parameterValues", []):
        pname = param.get("parameterName", "").lower()
        val = param.get("formattedValue") or param.get("value")

        if "compare length" in pname:
            dims["length"] = _to_float(val)
        elif "compare height" in pname:
            dims["height"] = _to_float(val)
        elif "compare thickness" in pname:
            dims["thickness"] = _to_float(val)

    return dims

# Update the function in ysimlib/dimensions.py:
def get_dimensions(pn: str):
    try:
        url = f"https://search.kemet.com/intellidata/unique-parts/{pn}"
        resp = requests.get(url)
        resp.raise_for_status()
        data = resp.json()

        dims = {"L": None, "W": None, "H": None}


        if data is None:
            return {dims}
            
        for param in data.get("parameterValues", []):
            pname = param.get("parameterName", "").lower()
            val = param.get("formattedValue") or param.get("value")
            
            if "compare length" in pname:
                dims["L"] = _to_float(val)
            elif "compare height" in pname:
                dims["W"] = _to_float(val)
            elif "compare thickness" in pname:
                dims["H"] = _to_float(val)
        
        return dims
    except Exception as e:
        print(f"Error fetching dimensions for {pn}: {e}")
        return {dims}


def _parse_mm_max(raw: str) -> float | None:
    """
    Aus einem String wie '31.5mm +0.5/-0.7mm' den Maximalwert (mm) extrahieren.
    Logik: erster mm-Wert = nominal, dazu (falls vorhanden) der Wert hinter '+'.
    """
    if not raw:
        return None
    s = raw.replace(",", ".")
    # nominal (erste Zahl vor 'mm')
    m_nom = re.search(r'(\d+(?:\.\d+)?)\s*mm', s, flags=re.I)
    if not m_nom:
        return None
    nominal = float(m_nom.group(1))
    # +Toleranz (falls vorhanden)
    m_plus = re.search(r'\+(\d+(?:\.\d+)?)', s)
    tol_plus = float(m_plus.group(1)) if m_plus else 0.0
    return nominal + tol_plus

def get_max_dimensions_from_data(data: dict) -> dict:
    """
    Nimmt das bereits geladene JSON (data) und gibt Maximalwerte in mm zurück.
    Nutzt ausschließlich die Parameter 'L', 'H', 'T' mit Toleranzen.
    """
    out = {"L_mm_max": None, "H_mm_max": None, "T_mm_max": None}
    for p in data.get("parameterValues", []):
        name = (p.get("parameterName") or "").strip().upper()
        if name in {"L", "H", "T"}:
            raw = p.get("value") or p.get("formattedValue") or ""
            v = _parse_mm_max(raw)
            if v is not None:
                key = f"{name}_mm_max"
                out[key] = v
    return out

def get_max_dimensions(pn: str) -> dict:
    """Bequemer Wrapper: lädt JSON und liefert Maximalmaße in mm."""
    data = fetch_yageo_part(pn)
    return get_max_dimensions_from_data(data)