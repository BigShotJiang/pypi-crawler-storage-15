import requests
import numpy as np

# Definition der Tabelle
dT_max = [ 
    {"fam":"C4AQ-P","dT":30, "Tamb_derat":75, "Tamb_max":125, "Irms_max":"100%"},
    {"fam":"C4AQ-M","dT":30, "Tamb_derat":70, "Tamb_max":105, "Irms_max":"100%"},
    {"fam":"C4AK",  "dT":30, "Tamb_derat":85, "Tamb_max":130, "Irms_max":"115%"},
    {"fam":"C4AQ",  "dT":30, "Tamb_derat":70, "Tamb_max":105, "Irms_max":"100%"},
    {"fam":"C4AU",  "dT":30, "Tamb_derat":70, "Tamb_max":105, "Irms_max":"100%"},
    {"fam":"R75",   "dT":20, "Tamb_derat":85, "Tamb_max":105, "Irms_max":"100%"},
    {"fam":"R75H",  "dT":20, "Tamb_derat":90, "Tamb_max":125, "Irms_max":"100%"},
    {"fam":"R76",   "dT":40, "Tamb_derat":60, "Tamb_max":110, "Irms_max":"140%"},
    {"fam":"R76H",  "dT":40, "Tamb_derat":60, "Tamb_max":125, "Irms_max":"160%"},
]

# Funktion zum Nachschlagen
def get_dT_max(fam: str, key: str = "dT"):
    """
    Gibt den Wert (default: dT) für die angegebene Familie zurück.
    key kann auch 'Tamb_derat', 'Tamb_max' oder 'Irms_max' sein.
    """
    for rec in dT_max:
        if rec["fam"].lower() == fam.lower():
            return rec.get(key)
    return None

# Beispielaufrufe
# print(get_dT("C4AK"))         # -> 30
# print(get_dT("R76H", "dT"))   # -> 40
# print(get_dT("R76H", "Tamb_derat")) # -> 60
# print(get_dT("R76H", "Tamb_max")) # -> 125

def calc_dT(fam: str, Tamb: float) -> float:
    """
    Berechnet den erlaubten dT-Wert für die angegebene Familie und Umgebungstemperatur Tamb.
    - Wenn Tamb <= dT_lim: fester dT.
    - Wenn Tamb > dT_lim: lineare Interpolation zwischen (dT_lim, dT) und (Tamb_max, 0).
    """
    # passenden Datensatz suchen
    rec = next((r for r in dT_max if r["fam"].lower() == fam.lower()), None)
    if not rec:
        raise ValueError(f"Familie {fam} nicht gefunden")
    
    dT = rec["dT"]
    Tamb_derat = rec["Tamb_derat"]
    Tamb_max = rec["Tamb_max"]

    if Tamb <= Tamb_derat:
        return dT
    elif Tamb >= Tamb_max:
        return 0.0
    else:
        # lineare Interpolation
        return dT * (Tamb_max - Tamb) / (Tamb_max - Tamb_derat)


def get_dT_max(Tamb):
    for rec in dT_max:
        fam = rec["fam"]
        dT = rec["dT"]
        Irms = rec["Irms_max"]
        print(f"{fam:8} dT_max={calc_dT(fam, Tamb):.1f}")
        #print(f"{fam:<8} dT = {dT}K Irms_max = {Irms}")

def get_current_at_frequency_alt(values, target_freq):
    freqs = [v["frequency"] for v in values]
    currents = [v["current"] for v in values]

    if target_freq in freqs:
        return currents[freqs.index(target_freq)]
    else:
        # Nachbarn suchen
        lower_idx = max(i for i, val in enumerate(freqs) if val <= target_freq)
        upper_idx = min(i for i, val in enumerate(freqs) if val >= target_freq)

        if lower_idx == upper_idx:
            return currents[lower_idx]
        else:
            f1, f2 = freqs[lower_idx], freqs[upper_idx]
            i1, i2 = currents[lower_idx], currents[upper_idx]
            return i1 + (i2 - i1) * (target_freq - f1) / (f2 - f1)
        

def get_current_at_frequency(values, target_freq):
    # Guard: empty input
    if not values:
        return None

    # Extract and sort by frequency
    freqs = np.array([v["frequency"] for v in values], dtype=float)
    currents = np.array([v["current"] for v in values], dtype=float)
    order = np.argsort(freqs)
    freqs = freqs[order]
    currents = currents[order]

    # If exact match, return directly
    exact = np.where(freqs == float(target_freq))[0]
    if exact.size:
        return float(currents[exact[0]])

    # numpy interp: linear interpolation; clamps to endpoints outside the range
    return float(np.interp(float(target_freq), freqs, currents))


def get_irms_at_freq_alt(pn, target_freqs):
    url = f"https://search.kemet.com/sim/plot/{pn}"
    data = requests.get(url).json()
    values = data["frequency_values"]
    
   # print(values)

    results = {}    
    for f in target_freqs:
        results[f] = get_current_at_frequency(values, f)
    return results

def get_irms_at_freq(pn, target_freqs):
    url = f"https://search.kemet.com/sim/plot/{pn}"
    data = requests.get(url).json()
    values = data.get("frequency_values", []) or []
    results = {}
    for f in target_freqs:
        results[f] = get_current_at_frequency(values, f)
    return results