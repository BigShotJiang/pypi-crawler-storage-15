import requests

# Will change to production

# const url = "https://stagesearch.kemet.com/sim/plot/R41BN247000T0K?ambient=30&bias=100&tempRise=25"
# const base_url ="https://stagesearch.kemet.com/"


def get_yageo_value_by_id(data: dict, id_: int = None, parameter_id: int = None):
    """Return the 'value' from parameterValues matching id or parameterId."""
    for p in data.get("parameterValues", []):
        if id_ is not None and p.get("id") == id_:
            return p.get("value")
        if parameter_id is not None and p.get("parameterId") == parameter_id:
            return p.get("value")
    return None

# pn_data = fetch_yageo_part("R413I2220GYT1K")

# Beispiel 

# # nach parameterId suchen
# val = get_value_by_id(pn_data, parameter_id=6)   # Capacitance
# print(val)  # -> "0.000000022"

# # oder nach id suchen
# val2 = get_value_by_id(pn_data, id_=60132)
# print(val2)  # -> "0.000000022"

def parse_kemet_parameters(data: dict) -> dict:
    """Create a dict of parameterName → {'value': ..., 'formatted': ...}."""
    params = {}
    for p in data.get("parameterValues", []):
        name = p.get("parameterName")
        val = p.get("value")
        fval = p.get("formattedValue")

        # nur übernehmen, wenn ein Name existiert und mindestens ein Wert nicht leer ist
        if name and (val not in [None, ""] or fval not in [None, ""]):
            params[name] = {
                "value": val,
                "formatted": fval
            }
    return params

def fetch_yageo_part(pn: str) -> dict:
    url = f"https://search.kemet.com/intellidata/unique-parts/{pn}"
    resp = requests.get(url)
    resp.raise_for_status()
    return resp.json()

def fetch_ysim_plot(
    pn: str,
    temperature: int = 25,
    f_min: float = 10000,
    f_max: float = 500000
) -> dict:
    url = f"https://stagesearch.kemet.com/sim/plot/{pn}?ambient={temperature}&start={f_min}&stop={f_max}"
    resp = requests.get(url)
    resp.raise_for_status()
    return resp.json()


def fetch_kemet_json(
    pn: str,
    temperature: int = 23,
    f_min: float = 10000,
    f_max: float = 500000
) -> dict:
    url = (
        f"https://stagesearch.kemet.com/sim/plot/{pn}"
        f"?ambient={temperature}&start={f_min}&stop={f_max}"
    )
    #url = "https://stagesearch.kemet.com/sim/plot/R41BN247000T0K?ambient=30&bias=100&tempRise=25"
    #print(url)
    resp = requests.get(url)
    resp.raise_for_status()
    return resp.json()


def pretty_print_json(obj):
    import json
    print(json.dumps(obj, indent=2, sort_keys=True, ensure_ascii=False))


def print_yageo_parameters(pn):

    data = fetch_yageo_part(pn)
    """Pretty print all parameter IDs, names, and values from a YAGEO/KEMET JSON."""
    if "parameterValues" not in data:
        print("No parameterValues found in JSON.")
        return

    for p in data["parameterValues"]:
        pid = p.get("parameterId")
        id_ = p.get("id")
        name = p.get("parameterName", "").replace(" ", "_")
        val = p.get("value", "")
        fval = p.get("formattedValue", "")

        # Bevorzugt formattedValue, wenn vorhanden
        result = fval or val or "-"
        print(f"(id : {id_:7d}  pID = {pid:6d},  {name:_<40} {result}")
        
#pn_data = fetch_yageo_part("R413I2220GYT1K")
#print_yageo_parameters(pn_data)    
#    

def get_freq_property_tuples(
    pn: str,
    property_name: str,
    temperature: int = 25,
    f_min: float = 10_000,
    f_max: float = 500_000,
):
    """
    Ruft mit fetch_ysim_plot() die Frequenzdaten zu einer Part Number und Temperatur ab
    und gibt ein Array von Tupeln (freq, property) zurück.
    property_name kann z.B. 'esr', 'current', 'impedance' oder 'voltage' sein.
    """

    # Daten abrufen (fetch_ysim_plot liefert das JSON mit frequency_values)
    data = fetch_ysim_plot(pn, temperature, f_min, f_max)

    freq_values = data.get("frequency_values", [])
    if not freq_values:
        return []

    # Nur Frequenzen im gewünschten Bereich
    filtered = [
        (entry["frequency"], entry.get(property_name))
        for entry in freq_values
        if f_min <= entry["frequency"] <= f_max and property_name in entry
    ]

    return filtered


def get_esr_data(
    pn: str,
    temperature: int = 25,
    f_min: float = 10_000,
    f_max: float = 500_000,
):
    return get_freq_property_tuples(pn, "esr", temperature=temperature, f_min=f_min, f_max=f_max)
  

def get_current_data(
    pn: str,
    temperature: int = 25,
    f_min: float = 10_000,
    f_max: float = 500_000,
):
    return get_freq_property_tuples(pn, "current", temperature=temperature, f_min=f_min, f_max=f_max)

def get_voltage_data (
    pn: str,
    temperature: int = 25,
    f_min: float = 10_000,
    f_max: float = 500_000,
):
    return get_freq_property_tuples(pn, "voltage", temperature=temperature, f_min=f_min, f_max=f_max)


def get_impedance_data (
    pn: str,
    temperature: int = 25,
    f_min: float = 10_000,
    f_max: float = 500_000,
):
    return get_freq_property_tuples(pn, "impedance", temperature=temperature, f_min=f_min, f_max=f_max)



def get_capacitance_data (
    pn: str,
    temperature: int = 25,
    f_min: float = 10_000,
    f_max: float = 500_000,
):
    return get_freq_property_tuples(pn, "capacitance", temperature=temperature, f_min=f_min, f_max=f_max)


  