#! /usr/bin/env bash

function test_bluer_ai_wifi_diagnose() {
    local options=$1

    bluer_ai wifi diagnose
}
