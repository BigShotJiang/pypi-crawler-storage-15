#! /usr/bin/env bash

function test_bluer_ai_hr() {
    bluer_ai_hr
}

function test_bluer_ai_log_local() {
    bluer_ai_log_local "testing"
}
