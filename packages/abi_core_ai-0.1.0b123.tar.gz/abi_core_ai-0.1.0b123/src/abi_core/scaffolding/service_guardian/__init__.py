"""
ABI Guardian Service Scaffolding Templates
Plantillas para crear servicios de guardian/seguridad
"""

from pathlib import Path

TEMPLATE_DIR = Path(__file__).parent