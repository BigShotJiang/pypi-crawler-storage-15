This folder contains partial ASHS output with 2023 ASHS-T1 PMC atlas for ADNI participant 035_S_4082 timepoint 2011-06-28
