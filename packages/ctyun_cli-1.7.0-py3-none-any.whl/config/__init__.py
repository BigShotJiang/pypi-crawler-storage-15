"""配置管理模块"""

from config.settings import ConfigManager, config

__all__ = ['ConfigManager', 'config']