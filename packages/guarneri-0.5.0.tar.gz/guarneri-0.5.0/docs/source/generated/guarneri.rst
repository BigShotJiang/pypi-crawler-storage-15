﻿guarneri
========

.. automodule:: guarneri

   