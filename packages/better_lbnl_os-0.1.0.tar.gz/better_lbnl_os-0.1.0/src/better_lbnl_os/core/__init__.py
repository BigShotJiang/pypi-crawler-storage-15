"""Core algorithms and computational functions."""
