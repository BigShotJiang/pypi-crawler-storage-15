"""Integration tests for BETTER workflow."""
