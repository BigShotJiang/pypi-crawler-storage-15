"""Tests for authful-mcp-proxy."""
