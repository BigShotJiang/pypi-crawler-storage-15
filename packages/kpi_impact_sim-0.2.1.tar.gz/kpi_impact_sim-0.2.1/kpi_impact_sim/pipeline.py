import pandas as pd
from kpi_impact_sim.preprocessing import preprocess_dataframe
from kpi_impact_sim.feature_selection import (
    correlation_clustering,
    vif_filter,
    lasso_elastic_selection
)
from kpi_impact_sim.ridge_model import fit_ridge_model
from kpi_impact_sim.simulate import apply_simulation
from kpi_impact_sim.utils import tipo_variable

def full_pipeline(df, target, incremento=2.0):

    df = preprocess_dataframe(df)
    df_num = df.select_dtypes(include="number")

    X0 = df_num.drop(columns=[target])
    y = df_num[target]

    # 1. Clustering
    X1, dropped_corr = correlation_clustering(X0)

    # 2. VIF
    X2, dropped_vif = vif_filter(X1)

    # 3. Lasso/ElasticNet
    selected = lasso_elastic_selection(X2, y)

    X_final = X2[selected]

    # 4. Ridge
    res = fit_ridge_model(X_final, y)

    # 5. Simulación
    sim = apply_simulation(
        res["coefs"],
        df_num,
        target,
        incremento_pts=incremento,
        tipo_variable_func=tipo_variable
    )

    return {
        "X_final": X_final,
        "ridge": res,
        "sim": sim,
        "dropped_corr": dropped_corr,
        "dropped_vif": dropped_vif,
        "selected": selected
    }



