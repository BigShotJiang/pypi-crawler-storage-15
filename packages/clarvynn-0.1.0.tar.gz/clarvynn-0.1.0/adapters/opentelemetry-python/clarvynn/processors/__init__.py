"""
Clarvynn processors for OpenTelemetry integration.
"""

from clarvynn.processors.clarvynn_span_processor import ClarvynnSpanProcessor

__all__ = ["ClarvynnSpanProcessor"]
