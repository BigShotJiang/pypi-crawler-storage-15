"""Scripts subpackage for glintefy."""
