# django_core_micha/api_urls.py
from django.urls import path, include
from django_core_micha.invitations.views import PasswordResetConfirmView
from django_core_micha.invitations import urls as invitations_urls
from rest_framework.routers import DefaultRouter
from django_core_micha.auth.views import csrf_token_view, RecoveryRequestViewSet, recovery_complete_view


router = DefaultRouter()
router.register(
        r"recovery-requests",
        RecoveryRequestViewSet,
        basename="recovery-request",
    ),
    

urlpatterns = [
    path("auth/", include("allauth.headless.urls")),
    
    path("csrf/", csrf_token_view, name="csrf-token"),
    path("support/", include(router.urls)),
    path(
        "mfa/recovery/<str:token>/",
        recovery_complete_view,
        name="mfa-recovery-complete",
    ),

    path(
        "users/password-reset/<uidb64>/<token>/", PasswordResetConfirmView.as_view(), name="password-reset-api"),
    # Access-Code-API der Lib:
    path("", include(invitations_urls)),
]
