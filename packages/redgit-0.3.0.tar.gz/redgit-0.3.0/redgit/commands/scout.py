"""
Scout CLI commands - AI-powered project analysis and task planning.

Commands:
- rg scout analyze    : Analyze project structure
- rg scout show       : Show current analysis
- rg scout plan       : Generate task plan from analysis
- rg scout sync       : Sync tasks to task management system
"""

import typer
import yaml
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.tree import Tree
from typing import Optional

from ..core.config import ConfigManager
from ..integrations.registry import get_analysis

console = Console()
scout_app = typer.Typer(help="AI-powered project analysis and task planning")


def _get_scout():
    """Get configured scout integration"""
    config = ConfigManager().load()
    scout = get_analysis(config, "scout")

    if not scout:
        console.print("[red]Scout integration not configured.[/red]")
        console.print("[dim]Run 'rg integration install scout' to set up[/dim]")
        raise typer.Exit(1)

    return scout


@scout_app.command("analyze")
def analyze_cmd(
    path: str = typer.Argument(".", help="Project path to analyze"),
    force: bool = typer.Option(False, "--force", "-f", help="Force re-analysis")
):
    """Analyze project structure using AI."""
    scout = _get_scout()

    # Check existing analysis
    existing = scout.get_analysis()
    if existing and not force:
        console.print("[yellow]Analysis already exists.[/yellow]")
        console.print(f"[dim]Last analyzed: {existing.get('_meta', {}).get('analyzed_at', 'unknown')}[/dim]")
        if not typer.confirm("Re-analyze?", default=False):
            console.print("[dim]Use 'rg scout show' to view existing analysis[/dim]")
            return

    console.print(f"\n[bold cyan]🔍 Analyzing project...[/bold cyan]\n")
    console.print(f"[dim]Path: {path}[/dim]")
    console.print(f"[dim]This may take a moment...[/dim]\n")

    try:
        with console.status("[bold green]Running AI analysis..."):
            analysis = scout.analyze(path)

        console.print("[bold green]✅ Analysis complete![/bold green]\n")

        # Show overview
        _show_analysis_summary(analysis)

        console.print("\n[dim]Full analysis saved to .redgit/scout.yaml[/dim]")
        console.print("[dim]Run 'rg scout show' to view details[/dim]")
        console.print("[dim]Run 'rg scout plan' to generate task plan[/dim]")

    except Exception as e:
        console.print(f"[red]Analysis failed: {e}[/red]")
        raise typer.Exit(1)


@scout_app.command("show")
def show_cmd(
    section: Optional[str] = typer.Argument(None, help="Section to show: overview, tech, architecture, modules, improvements")
):
    """Show current project analysis."""
    scout = _get_scout()

    analysis = scout.get_analysis()
    if not analysis:
        console.print("[yellow]No analysis found.[/yellow]")
        console.print("[dim]Run 'rg scout analyze' first[/dim]")
        raise typer.Exit(1)

    if section:
        _show_section(analysis, section)
    else:
        _show_full_analysis(analysis)


@scout_app.command("plan")
def plan_cmd(
    force: bool = typer.Option(False, "--force", "-f", help="Force regenerate plan")
):
    """Generate task plan from analysis."""
    scout = _get_scout()

    # Check existing plan
    existing = scout.get_plan()
    if existing and not force:
        console.print("[yellow]Plan already exists.[/yellow]")
        console.print(f"[dim]{len(existing)} tasks generated[/dim]")
        if not typer.confirm("Regenerate plan?", default=False):
            console.print("[dim]Use 'rg scout show-plan' to view existing plan[/dim]")
            return

    # Check analysis exists
    analysis = scout.get_analysis()
    if not analysis:
        console.print("[yellow]No analysis found.[/yellow]")
        console.print("[dim]Run 'rg scout analyze' first[/dim]")
        raise typer.Exit(1)

    console.print(f"\n[bold cyan]📋 Generating task plan...[/bold cyan]\n")

    try:
        with console.status("[bold green]AI is planning tasks..."):
            tasks = scout.generate_plan(analysis)

        console.print(f"[bold green]✅ Plan generated: {len(tasks)} tasks[/bold green]\n")

        # Show summary
        _show_plan_summary(tasks)

        console.print("\n[dim]Full plan saved to .redgit/scout-plan.yaml[/dim]")

        if scout.task_management:
            console.print(f"[dim]Run 'rg scout sync' to create tasks in {scout.task_management}[/dim]")

    except Exception as e:
        console.print(f"[red]Plan generation failed: {e}[/red]")
        raise typer.Exit(1)


@scout_app.command("show-plan")
def show_plan_cmd():
    """Show generated task plan."""
    scout = _get_scout()

    tasks = scout.get_plan()
    if not tasks:
        console.print("[yellow]No plan found.[/yellow]")
        console.print("[dim]Run 'rg scout plan' first[/dim]")
        raise typer.Exit(1)

    _show_full_plan(tasks)


@scout_app.command("sync")
def sync_cmd(
    dry_run: bool = typer.Option(False, "--dry-run", "-n", help="Preview without creating")
):
    """Sync task plan to task management system."""
    scout = _get_scout()

    if not scout.task_management:
        console.print("[red]No task management integration linked.[/red]")
        console.print("[dim]Run 'rg integration install scout' and select a task management[/dim]")
        raise typer.Exit(1)

    tasks = scout.get_plan()
    if not tasks:
        console.print("[yellow]No plan found.[/yellow]")
        console.print("[dim]Run 'rg scout plan' first[/dim]")
        raise typer.Exit(1)

    # Check for already synced tasks
    synced = [t for t in tasks if t.get("issue_key")]
    unsynced = [t for t in tasks if not t.get("issue_key")]

    console.print(f"\n[bold cyan]📤 Syncing to {scout.task_management}...[/bold cyan]\n")
    console.print(f"[dim]Total tasks: {len(tasks)}[/dim]")
    console.print(f"[dim]Already synced: {len(synced)}[/dim]")
    console.print(f"[dim]To create: {len(unsynced)}[/dim]\n")

    if not unsynced:
        console.print("[green]All tasks already synced![/green]")
        return

    if dry_run:
        console.print("[yellow]Dry run - tasks that would be created:[/yellow]\n")
        for task in unsynced:
            console.print(f"  • [{task.get('type', 'task')}] {task.get('title')}")
            if task.get('dependencies'):
                console.print(f"    [dim]Depends on: {', '.join(task['dependencies'])}[/dim]")
        return

    if not typer.confirm(f"Create {len(unsynced)} tasks in {scout.task_management}?"):
        return

    try:
        with console.status("[bold green]Creating tasks..."):
            mapping = scout.sync_to_task_management()

        console.print(f"\n[bold green]✅ Created {len(mapping)} tasks![/bold green]\n")

        # Show created tasks
        for local_id, issue_key in mapping.items():
            task = next((t for t in tasks if t.get("id") == local_id), None)
            if task:
                console.print(f"  ✓ {issue_key}: {task.get('title', '')[:50]}")

    except Exception as e:
        console.print(f"[red]Sync failed: {e}[/red]")
        raise typer.Exit(1)


def _show_analysis_summary(analysis: dict):
    """Show brief analysis summary"""
    overview = analysis.get("overview", {})
    tech = analysis.get("tech_stack", {})

    # Project info
    panel = Panel(
        f"[bold]{overview.get('name', 'Unknown')}[/bold]\n"
        f"{overview.get('description', 'No description')}\n\n"
        f"[dim]Type: {overview.get('type', 'unknown')} | "
        f"Maturity: {overview.get('maturity', 'unknown')}[/dim]",
        title="📁 Project Overview"
    )
    console.print(panel)

    # Tech stack
    languages = tech.get("languages", [])
    frameworks = tech.get("frameworks", [])

    if languages or frameworks:
        tech_str = ""
        if languages:
            lang_names = [l.get("name", l) if isinstance(l, dict) else l for l in languages[:5]]
            tech_str += f"Languages: {', '.join(lang_names)}\n"
        if frameworks:
            tech_str += f"Frameworks: {', '.join(frameworks[:5])}"

        console.print(Panel(tech_str.strip(), title="🛠️  Tech Stack"))


def _show_section(analysis: dict, section: str):
    """Show specific section of analysis"""
    section_map = {
        "overview": "overview",
        "tech": "tech_stack",
        "architecture": "architecture",
        "modules": "modules",
        "improvements": "improvements",
        "next": "next_steps"
    }

    key = section_map.get(section, section)
    data = analysis.get(key)

    if not data:
        console.print(f"[yellow]Section '{section}' not found[/yellow]")
        console.print(f"[dim]Available: {', '.join(section_map.keys())}[/dim]")
        return

    console.print(f"\n[bold cyan]{section.upper()}[/bold cyan]\n")
    console.print(yaml.dump(data, default_flow_style=False, allow_unicode=True))


def _show_full_analysis(analysis: dict):
    """Show full analysis"""
    console.print("\n[bold cyan]📊 Project Analysis[/bold cyan]\n")

    # Overview
    overview = analysis.get("overview", {})
    console.print(f"[bold]Project:[/bold] {overview.get('name', 'Unknown')}")
    console.print(f"[bold]Type:[/bold] {overview.get('type', 'unknown')}")
    console.print(f"[bold]Maturity:[/bold] {overview.get('maturity', 'unknown')}")
    console.print(f"\n{overview.get('description', '')}\n")

    # Tech Stack
    tech = analysis.get("tech_stack", {})
    if tech:
        console.print("[bold]Tech Stack:[/bold]")
        for lang in tech.get("languages", [])[:5]:
            if isinstance(lang, dict):
                console.print(f"  • {lang.get('name')} ({lang.get('percentage', '?')}%)")
            else:
                console.print(f"  • {lang}")
        if tech.get("frameworks"):
            console.print(f"  Frameworks: {', '.join(tech['frameworks'][:5])}")
        console.print("")

    # Architecture
    arch = analysis.get("architecture", {})
    if arch:
        console.print(f"[bold]Architecture:[/bold] {arch.get('pattern', 'unknown')}")
        console.print(f"  {arch.get('summary', '')}\n")

    # Modules
    modules = analysis.get("modules", [])
    if modules:
        console.print("[bold]Modules:[/bold]")
        for mod in modules[:10]:
            status_color = "green" if mod.get("status") == "complete" else "yellow"
            console.print(f"  [{status_color}]●[/{status_color}] {mod.get('name')} - {mod.get('description', '')[:50]}")
        console.print("")

    # Improvements
    improvements = analysis.get("improvements", [])
    if improvements:
        console.print("[bold]Suggested Improvements:[/bold]")
        for imp in improvements[:5]:
            priority_color = {"high": "red", "medium": "yellow", "low": "blue"}.get(imp.get("priority"), "white")
            console.print(f"  [{priority_color}]●[/{priority_color}] {imp.get('title')}")
        console.print("")

    # Meta
    meta = analysis.get("_meta", {})
    console.print(f"[dim]Analyzed: {meta.get('analyzed_at', 'unknown')}[/dim]")
    console.print(f"[dim]Files scanned: {meta.get('total_files', '?')}[/dim]")


def _show_plan_summary(tasks: list):
    """Show brief plan summary"""
    # Count by type
    by_type = {}
    for task in tasks:
        t = task.get("type", "task")
        by_type[t] = by_type.get(t, 0) + 1

    # Count by phase
    phases = set(t.get("phase", 1) for t in tasks)

    # Total estimate
    total_hours = sum(t.get("estimate", 0) for t in tasks)

    console.print(f"[bold]Tasks by type:[/bold]")
    for t, count in sorted(by_type.items()):
        console.print(f"  • {t}: {count}")

    console.print(f"\n[bold]Phases:[/bold] {len(phases)}")
    console.print(f"[bold]Total estimate:[/bold] {total_hours} hours (~{total_hours/8:.1f} days)")


def _show_full_plan(tasks: list):
    """Show full task plan"""
    console.print("\n[bold cyan]📋 Task Plan[/bold cyan]\n")

    # Group by phase
    phases = {}
    for task in tasks:
        phase = task.get("phase", 1)
        if phase not in phases:
            phases[phase] = []
        phases[phase].append(task)

    for phase_num in sorted(phases.keys()):
        phase_tasks = phases[phase_num]
        phase_hours = sum(t.get("estimate", 0) for t in phase_tasks)

        console.print(f"\n[bold]Phase {phase_num}[/bold] ({len(phase_tasks)} tasks, {phase_hours}h)")
        console.print("─" * 50)

        for task in phase_tasks:
            type_icon = {"epic": "📦", "story": "📖", "task": "✓", "subtask": "  ·"}.get(task.get("type"), "•")
            priority_color = {"high": "red", "medium": "yellow", "low": "blue"}.get(task.get("priority"), "white")
            issue_key = task.get("issue_key", "")

            title_line = f"{type_icon} {task.get('title', 'Untitled')}"
            if issue_key:
                title_line += f" [green][{issue_key}][/green]"

            console.print(f"[{priority_color}]{title_line}[/{priority_color}]")

            if task.get("estimate"):
                console.print(f"   [dim]Est: {task['estimate']}h[/dim]", end="")
            if task.get("dependencies"):
                console.print(f"   [dim]Deps: {', '.join(task['dependencies'])}[/dim]", end="")
            console.print("")