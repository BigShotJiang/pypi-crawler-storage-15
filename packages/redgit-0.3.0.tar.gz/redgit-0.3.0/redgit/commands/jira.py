"""
Jira CLI commands - Project, team, and issue management.

Commands:
- rg jira projects     : List accessible projects
- rg jira issues       : List my active issues
- rg jira team         : List project team members
- rg jira assign       : Assign issue to team member
- rg jira unassigned   : List unassigned issues
"""

import typer
import yaml
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from typing import Optional

from ..core.config import ConfigManager
from ..integrations.registry import get_task_management

console = Console()
jira_app = typer.Typer(help="Jira project and team management")


def _get_jira():
    """Get configured Jira integration"""
    config = ConfigManager().load()
    jira = get_task_management(config, "jira")

    if not jira:
        console.print("[red]Jira integration not configured.[/red]")
        console.print("[dim]Run 'rg integration install jira' to set up[/dim]")
        raise typer.Exit(1)

    return jira


@jira_app.command("projects")
def list_projects():
    """List all accessible Jira projects."""
    jira = _get_jira()

    console.print("\n[bold cyan]Jira Projects[/bold cyan]\n")

    projects = jira.get_projects()
    if not projects:
        console.print("[yellow]No projects found or access denied.[/yellow]")
        return

    table = Table(show_header=True)
    table.add_column("Key", style="cyan")
    table.add_column("Name")
    table.add_column("Lead", style="dim")
    table.add_column("Type", style="dim")

    for p in projects:
        is_current = " ●" if p["key"] == jira.project_key else ""
        table.add_row(
            p["key"] + is_current,
            p["name"],
            p.get("lead", "-"),
            p.get("style", "-")
        )

    console.print(table)
    console.print(f"\n[dim]Current project: {jira.project_key}[/dim]")


@jira_app.command("issues")
def list_issues(
    status: Optional[str] = typer.Option(None, "--status", "-s", help="Filter by status: active, done, or specific status"),
    all_issues: bool = typer.Option(False, "--all", "-a", help="Show all project issues, not just mine")
):
    """List my active issues in the current project."""
    jira = _get_jira()

    console.print(f"\n[bold cyan]Issues in {jira.project_key}[/bold cyan]\n")

    if all_issues:
        jql = f'project = "{jira.project_key}" ORDER BY updated DESC'
        issues = jira.search_issues(jql, 50)
        title = "All Issues"
    elif status:
        issues = jira.get_user_issues(status=status)
        title = f"My Issues ({status})"
    else:
        issues = jira.get_my_active_issues()
        title = "My Active Issues"

    if not issues:
        console.print(f"[yellow]No issues found.[/yellow]")
        return

    table = Table(title=title, show_header=True)
    table.add_column("Key", style="cyan")
    table.add_column("Type", style="dim", width=8)
    table.add_column("Summary")
    table.add_column("Status")
    table.add_column("Assignee", style="dim")

    for issue in issues:
        status_color = "green" if "progress" in issue.status.lower() else "yellow"
        table.add_row(
            issue.key,
            issue.issue_type[:8],
            issue.summary[:50] + ("..." if len(issue.summary) > 50 else ""),
            f"[{status_color}]{issue.status}[/{status_color}]",
            issue.assignee or "-"
        )

    console.print(table)
    console.print(f"\n[dim]Total: {len(issues)} issues[/dim]")


@jira_app.command("team")
def list_team():
    """List team members assignable to the current project."""
    jira = _get_jira()

    console.print(f"\n[bold cyan]Team - {jira.project_key}[/bold cyan]\n")

    users = jira.get_project_users()
    if not users:
        console.print("[yellow]No team members found.[/yellow]")
        return

    table = Table(show_header=True)
    table.add_column("#", style="dim", width=3)
    table.add_column("Name")
    table.add_column("Email", style="dim")
    table.add_column("Status")

    for i, user in enumerate(users, 1):
        status = "[green]Active[/green]" if user.get("active") else "[red]Inactive[/red]"
        table.add_row(
            str(i),
            user.get("display_name", "-"),
            user.get("email", "-"),
            status
        )

    console.print(table)
    console.print(f"\n[dim]Total: {len(users)} members[/dim]")


@jira_app.command("unassigned")
def list_unassigned():
    """List unassigned issues in the current project."""
    jira = _get_jira()

    console.print(f"\n[bold cyan]Unassigned Issues - {jira.project_key}[/bold cyan]\n")

    issues = jira.get_unassigned_issues()
    if not issues:
        console.print("[green]No unassigned issues! 🎉[/green]")
        return

    table = Table(show_header=True)
    table.add_column("#", style="dim", width=3)
    table.add_column("Key", style="cyan")
    table.add_column("Type", style="dim", width=8)
    table.add_column("Summary")
    table.add_column("Status")

    for i, issue in enumerate(issues, 1):
        table.add_row(
            str(i),
            issue.key,
            issue.issue_type[:8],
            issue.summary[:50] + ("..." if len(issue.summary) > 50 else ""),
            issue.status
        )

    console.print(table)
    console.print(f"\n[dim]Total: {len(issues)} unassigned[/dim]")
    console.print("[dim]Use 'rg jira assign <issue> <user>' to assign[/dim]")


@jira_app.command("assign")
def assign_issue(
    issue_key: str = typer.Argument(..., help="Issue key (e.g., PROJ-123)"),
    user: Optional[str] = typer.Argument(None, help="User name or number from team list"),
    auto: bool = typer.Option(False, "--auto", "-a", help="Auto-assign based on skills (requires scout)")
):
    """Assign an issue to a team member."""
    jira = _get_jira()

    # Get issue info
    issue = jira.get_issue(issue_key)
    if not issue:
        console.print(f"[red]Issue {issue_key} not found.[/red]")
        raise typer.Exit(1)

    console.print(f"\n[bold]{issue_key}[/bold]: {issue.summary}")
    console.print(f"[dim]Type: {issue.issue_type} | Status: {issue.status}[/dim]")

    if issue.assignee:
        console.print(f"[yellow]Currently assigned to: {issue.assignee}[/yellow]")

    # Get team members
    users = jira.get_project_users()
    if not users:
        console.print("[red]No team members found.[/red]")
        raise typer.Exit(1)

    # Auto-assign mode
    if auto:
        _auto_assign(jira, issue, users)
        return

    # If user not specified, show list and ask
    if not user:
        console.print("\n[bold]Team Members:[/bold]")
        for i, u in enumerate(users, 1):
            console.print(f"  [{i}] {u.get('display_name')}")

        user = typer.prompt("\nSelect team member (number or name)")

    # Find user by number or name
    account_id = None
    try:
        idx = int(user) - 1
        if 0 <= idx < len(users):
            account_id = users[idx].get("account_id")
            display_name = users[idx].get("display_name")
    except ValueError:
        # Search by name
        user_lower = user.lower()
        for u in users:
            if user_lower in u.get("display_name", "").lower():
                account_id = u.get("account_id")
                display_name = u.get("display_name")
                break

    if not account_id:
        console.print(f"[red]User '{user}' not found.[/red]")
        raise typer.Exit(1)

    # Assign
    if jira.assign_issue(issue_key, account_id):
        console.print(f"\n[green]✓ Assigned {issue_key} to {display_name}[/green]")
    else:
        console.print(f"[red]Failed to assign issue.[/red]")
        raise typer.Exit(1)


@jira_app.command("unassign")
def unassign_issue(
    issue_key: str = typer.Argument(..., help="Issue key (e.g., PROJ-123)")
):
    """Remove assignee from an issue."""
    jira = _get_jira()

    issue = jira.get_issue(issue_key)
    if not issue:
        console.print(f"[red]Issue {issue_key} not found.[/red]")
        raise typer.Exit(1)

    if not issue.assignee:
        console.print(f"[yellow]{issue_key} is already unassigned.[/yellow]")
        return

    if jira.unassign_issue(issue_key):
        console.print(f"[green]✓ Removed assignee from {issue_key}[/green]")
    else:
        console.print(f"[red]Failed to unassign issue.[/red]")
        raise typer.Exit(1)


@jira_app.command("sprint")
def show_sprint():
    """Show active sprint information."""
    jira = _get_jira()

    if not jira.supports_sprints():
        console.print("[yellow]Sprints not supported (board_type is not 'scrum')[/yellow]")
        return

    sprint = jira.get_active_sprint()
    if not sprint:
        console.print("[yellow]No active sprint found.[/yellow]")
        return

    console.print(f"\n[bold cyan]Active Sprint: {sprint.name}[/bold cyan]")
    if sprint.goal:
        console.print(f"[dim]Goal: {sprint.goal}[/dim]")
    console.print(f"[dim]{sprint.start_date} → {sprint.end_date}[/dim]\n")

    # Get sprint issues
    issues = jira.get_sprint_issues(sprint.id)

    # Group by status
    by_status = {}
    for issue in issues:
        status = issue.status
        if status not in by_status:
            by_status[status] = []
        by_status[status].append(issue)

    for status, status_issues in by_status.items():
        console.print(f"[bold]{status}[/bold] ({len(status_issues)})")
        for issue in status_issues:
            assignee = f" → {issue.assignee}" if issue.assignee else ""
            console.print(f"  • {issue.key}: {issue.summary[:40]}{assignee}")
        console.print("")


@jira_app.command("backlog")
def show_backlog(
    limit: int = typer.Option(20, "--limit", "-n", help="Maximum issues to show")
):
    """Show backlog issues."""
    jira = _get_jira()

    console.print(f"\n[bold cyan]Backlog - {jira.project_key}[/bold cyan]\n")

    issues = jira.get_backlog_issues(limit)
    if not issues:
        console.print("[green]Backlog is empty! 🎉[/green]")
        return

    table = Table(show_header=True)
    table.add_column("Key", style="cyan")
    table.add_column("Type", style="dim", width=8)
    table.add_column("Summary")
    table.add_column("Points", style="dim", width=6)

    for issue in issues:
        points = str(issue.story_points) if issue.story_points else "-"
        table.add_row(
            issue.key,
            issue.issue_type[:8],
            issue.summary[:50] + ("..." if len(issue.summary) > 50 else ""),
            points
        )

    console.print(table)
    console.print(f"\n[dim]Showing {len(issues)} of backlog[/dim]")


def _auto_assign(jira, issue, users):
    """Auto-assign issue based on skills using AI."""
    from ..integrations.registry import get_analysis
    from ..core.config import ConfigManager
    from ..core.llm import LLMClient

    config = ConfigManager().load()

    # Check for team config
    team_config_path = ".redgit/team.yaml"
    try:
        with open(team_config_path, "r") as f:
            team_config = yaml.safe_load(f)
    except FileNotFoundError:
        console.print("[yellow]No team configuration found.[/yellow]")
        console.print(f"[dim]Create {team_config_path} with team skills:[/dim]")
        console.print("""
```yaml
members:
  - name: "John Doe"
    account_id: "xxx"
    skills:
      - python
      - backend
      - api
  - name: "Jane Smith"
    account_id: "yyy"
    skills:
      - react
      - frontend
      - ui
```
""")
        raise typer.Exit(1)

    members = team_config.get("members", [])
    if not members:
        console.print("[red]No team members configured in team.yaml[/red]")
        raise typer.Exit(1)

    # Use AI to match issue to team member
    llm = LLMClient(config.get("llm", {}))

    prompt = f"""Based on the issue details and team member skills, recommend the best person to assign this issue.

Issue:
- Key: {issue.key}
- Summary: {issue.summary}
- Description: {issue.description[:500] if issue.description else 'No description'}
- Type: {issue.issue_type}

Team Members:
"""
    for m in members:
        prompt += f"\n- {m['name']}: {', '.join(m.get('skills', []))}"

    prompt += """

Respond with ONLY the name of the recommended team member and a brief reason.
Format: NAME | REASON
"""

    console.print("[dim]Analyzing issue and team skills...[/dim]")

    try:
        response = llm.chat(prompt)
        parts = response.strip().split("|")
        recommended_name = parts[0].strip()
        reason = parts[1].strip() if len(parts) > 1 else ""

        # Find member
        recommended = None
        for m in members:
            if m["name"].lower() == recommended_name.lower():
                recommended = m
                break

        if not recommended:
            console.print(f"[yellow]AI recommended '{recommended_name}' but not found in team config.[/yellow]")
            return

        console.print(f"\n[bold]Recommendation:[/bold] {recommended['name']}")
        if reason:
            console.print(f"[dim]Reason: {reason}[/dim]")

        if typer.confirm("\nAssign to this person?"):
            if jira.assign_issue(issue.key, recommended["account_id"]):
                console.print(f"[green]✓ Assigned {issue.key} to {recommended['name']}[/green]")
            else:
                console.print("[red]Failed to assign.[/red]")

    except Exception as e:
        console.print(f"[red]Auto-assign failed: {e}[/red]")