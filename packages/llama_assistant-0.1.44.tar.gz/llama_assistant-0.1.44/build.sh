python -O -m PyInstaller --noconfirm LlamaAssistant.spec
