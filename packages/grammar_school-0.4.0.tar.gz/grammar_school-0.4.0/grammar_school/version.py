"""Version information for Grammar School."""

__version__ = "0.4.0"
