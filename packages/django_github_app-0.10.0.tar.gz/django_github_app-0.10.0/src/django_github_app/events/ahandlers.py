from __future__ import annotations

from . import ainstallation
from . import arepository

__all__ = [
    "ainstallation",
    "arepository",
]
