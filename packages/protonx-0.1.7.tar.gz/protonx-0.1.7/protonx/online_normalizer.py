from typing import Any, Dict, List, Union
from ._http import HTTPClient

import json
from pathlib import Path

# Find project root and look for model_list.json there
project_root = Path(__file__).parent  # Adjust based on your structure
CONFIG_PATH = project_root / 'model_list.json'

with open(CONFIG_PATH, 'r') as f:
    model_config = json.load(f)


class OnlineNormalizer:
    """
    ProtonX TextNormalizer API wrapper
    Usage:
        client.text.correct(input = "Toi di hoc")
    """

    def __init__(self, http: HTTPClient):
        self._http = http

        normalizer_models = model_config['text_correction']['online']

        if len(normalizer_models) == 0:
            warnings.warn(f"Text correction do not yet support online mode.", UserWarning)

    def correct(self, 
                input: Union[str, List[str]], 
                top_k: int = 1,
                model: str = "distilled-protonx-legal-tc",
                **kwargs: Any
        ) -> Dict[str, Any]:
        """
        Vietnamese correction
        """

        # Validate input is not None
        if input is None:
            raise ValueError("Input cannot be None")
        
        # Convert to list
        if isinstance(input, str):
            texts = [input]
        elif isinstance(input, list):
            texts = input
        else:
            raise TypeError(f"Input must be str or list, got {type(input).__name__}")
        
        # Validate list is not empty
        if len(texts) == 0:
            raise ValueError("Input list cannot be empty")
        
        # Validate no empty strings in list
        if any(not text or not text.strip() for text in texts):
            raise ValueError("Input cannot contain empty or whitespace-only strings")

        payload = {
            "input": texts,
            "top_k": top_k,
            "model": model,
            **kwargs
        }

        return self._http.post("/v1/correction", payload)

    def list_model(self) -> Dict[str, Any]:
        normalizer_models = model_config['text_correction']

        return {"models": normalizer_models}