"""
Entry point for dw_auditor CLI
"""
from dw_auditor.cli.main import main

if __name__ == '__main__':
    main()
