"""
Column insights generation for data profiling
"""

from .column_insights import generate_column_insights

__all__ = ['generate_column_insights']
