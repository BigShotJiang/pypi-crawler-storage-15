#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
# ==========================================
# Copyright 2023 Yang 
# webarar - consts
# ==========================================
#
#
# 
"""

# unicode for superscript numbers
sup_35 = '\u00B3\u2075'
sup_36 = '\u00B3\u2076'
sup_37 = '\u00B3\u2077'
sup_38 = '\u00B3\u2078'
sup_39 = '\u00B3\u2079'
sup_40 = '\u2074\u2070'

