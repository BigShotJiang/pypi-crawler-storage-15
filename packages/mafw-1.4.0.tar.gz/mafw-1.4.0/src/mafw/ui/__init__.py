"""
User interface modules.

In this subpackage, there are some implementations of possible user interfaces to connect the library to the execution
framework.
"""
