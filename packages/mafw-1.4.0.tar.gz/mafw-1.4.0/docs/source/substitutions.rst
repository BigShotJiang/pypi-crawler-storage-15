 .. |processor| replace:: :class:`~mafw.processor.Processor`
 .. |processor_list| replace:: :class:`~mafw.processor.ProcessorList`
 .. |processors| replace:: :class:`processors <mafw.processor.Processor>`