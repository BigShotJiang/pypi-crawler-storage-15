.. _api:

API
===

This page is particularly useful for the developers because it offers a quick view at the implemented API.

.. autosummary::
    :toctree: generated
    :signatures: none
    :recursive:

    mafw