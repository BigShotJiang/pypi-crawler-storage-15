# Copyright (C) [2025] Eduardo Antonio Ferrera Rodríguez
#
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation, either version 3 of the License, or any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY. See the COPYING file for more details.

# fonts.py

from pathlib import Path
import re

class CreateFont:
   
    
    def __init__(self, family: str, p: str = None, h1: str = None, h2: str = None, h3: str = None):
        self.css_path = Path("style.css")
        self.styles_to_insert = {}
        
   
        self.styles_to_insert['body'] = {'font-family': family}
        
        tag_map = {'p': p, 'h1': h1, 'h2': h2, 'h3': h3}
        for tag, size in tag_map.items():
            if size:
                if tag not in self.styles_to_insert:
                    self.styles_to_insert[tag] = {}
                self.styles_to_insert[tag]['font-size'] = size
                
        self.write()


    def _update_content(self, css_content: str, selector: str, properties: dict) -> str:
   
        pattern = re.compile(rf'({re.escape(selector)}\s*\{{)([^}}]*?)(\}})', re.DOTALL)
        
        new_properties_css = "".join([f"\n    {prop}: {value};" for prop, value in properties.items()])
        
        match = pattern.search(css_content)

        if match:
            start_block = match.group(1)
            inner_content = match.group(2).strip()
            end_block = match.group(3)
            if inner_content:
                new_inner_content = inner_content + new_properties_css + "\n"
            else:
                new_inner_content = new_properties_css.lstrip() 
            
            new_block = f"{start_block}{new_inner_content}{end_block}"
            
            
            return css_content.replace(match.group(0), new_block, 1)

        else:
            
            new_block = f"\n\n{selector} {{" + new_properties_css + "\n}"
            return css_content + new_block
            
    
    def write(self):
        
        try:
        
            if self.css_path.exists():
                with open(self.css_path, 'r', encoding='utf-8') as f:
                    content = f.read()
            else:
                content = ""
                
        except Exception as e:
            print(f"Error al leer/acceder al archivo CSS: {e}")
            return
            
        modified_content = content
        
        # Iterar sobre todos los selectores configurados para actualizar el contenido
        for selector, properties in self.styles_to_insert.items():
            modified_content = self._update_content(modified_content, selector, properties)
            
        # 3. Escribir el contenido modificado de vuelta al archivo
        try:
            with open(self.css_path, 'w', encoding='utf-8') as f:
                f.write(modified_content.strip())
            print(f"Font Style apply succesefully {self.css_path}.")
        except Exception as e:
            print(f"Error al escribir en el archivo CSS: {e}")
