"""
Trackify - PC Activity Tracking and Productivity Analysis System
"""

__version__ = "1.0.2"
__author__ = "Your Name"
