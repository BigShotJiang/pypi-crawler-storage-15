from ._display import (
    display,
)
from .protocol import Display

__all__ = [
    "Display",
    "display",
]
