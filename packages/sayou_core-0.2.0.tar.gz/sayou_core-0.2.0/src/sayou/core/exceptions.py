class SayouCoreError(Exception):
    pass


class InitializationError(SayouCoreError):
    pass
