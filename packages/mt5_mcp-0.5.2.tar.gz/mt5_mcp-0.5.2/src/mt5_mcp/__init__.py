"""
MT5 MCP Server - MetaTrader 5 integration for Model Context Protocol.
"""

__version__ = "0.5.2"

from .server import main

__all__ = ["main"]
