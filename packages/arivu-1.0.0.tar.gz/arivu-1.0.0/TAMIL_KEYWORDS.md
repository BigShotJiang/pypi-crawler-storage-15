# rajini++ Language - Tamil Keywords Reference

## Complete Keyword List (Easy Tamil!)

### Core Keywords

| Tamil Word | English | Meaning | Usage |
|------------|---------|---------|-------|
| `sollu` | tell/say | Define function | `sollu functionName(params) { }` |
| `thirupi_kudu` | give back | Return | `thirupi_kudu value;` |
| `vachuko` | keep/store | Variable | `vachuko x = 10;` |
| `aarambam` | start/begin | Main entry | `aarambam { }` |
| `sollu_da` | say it! | Print | `sollu_da("text");` |

### Control Flow

| Tamil Word | English | Meaning | Usage |
|------------|---------|---------|-------|
| `na_sonna` | if I say | If condition | `na_sonna (x > 5) { }` |
| `illa_na_sonna` | or if I say | Else if | `illa_na_sonna (x > 3) { }` |
| `illana` | otherwise | Else | `illana { }` |

### Loops

| Tamil Word | English | Meaning | Usage |
|------------|---------|---------|-------|
| `varaikkum` | until | While loop | `varaikkum (condition) { }` |
| `ellathukum` | for all | For loop | `ellathukum (i=0; i<10; i=i+1) { }` |

### Values

| Tamil Word | English | Meaning |
|------------|---------|---------|
| `aama` | yes | True |
| `illa` | no | False |
| `onnum_illa` | nothing | Null/None |

## Tamil Math Function Names

Common Tamil words for mathematical operations:

- `kuttu` - Addition (கூட்டு)
- `kazhitthal` - Subtraction (கழித்தல்)
- `perukku` - Multiplication (பெருக்கு)
- `vaguthal` - Division (வகுத்தல்)

## Common Tamil Words for Programming

- `vayasu` - age
- `mark` / `marks` - marks/score
- `num` / `number` - number
- `name` / `per` - name
- `count` - count
- `result` - result
- `value` - value

## Example Phrases

```rajini
// Variable declarations
vachuko vayasu = 25;          // Keep age = 25
vachuko per = "Rajini";       // Keep name = "Rajini"
vachuko mark = 95;            // Keep mark = 95

// Conditionals
na_sonna (mark >= 90) {       // If I say (mark >= 90)
    sollu_da("A Grade");      // Say it! "A Grade"
} illa_na_sonna (mark >= 80) { // Or if I say (mark >= 80)
    sollu_da("B Grade");      // Say it! "B Grade"
} illana {                    // Otherwise
    sollu_da("Pass");         // Say it! "Pass"
}

// Functions
sollu vanakkam(per) {         // Say vanakkam(name)
    sollu_da("Vanakkam, ");   // Say it! "Vanakkam, "
    sollu_da(per);            // Say it! name
    thirupi_kudu aama;        // Give back yes
}

// Loops
vachuko i = 1;                // Keep i = 1
varaikkum (i <= 10) {         // Until (i <= 10)
    sollu_da(i);              // Say it! i
    vachuko i = i + 1;        // Keep i = i + 1
}
```

## Programming in Tamil Style

**Before (English style):**
```rajini
function calculateSum(a, b) {
    return a + b;
}

start {
    print("Sum is: ");
    var result = calculateSum(10, 20);
    print(result);
}
```

**After (Tamil style):**
```rajini
sollu kuttu(a, b) {
    thirupi_kudu a + b;
}

aarambam {
    sollu_da("Sum is: ");
    vachuko result = kuttu(10, 20);
    sollu_da(result);
}
```

---

**Namma style-la code potturlam!** (Let's code in our style!)
