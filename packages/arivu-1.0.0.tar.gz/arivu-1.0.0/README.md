# Arivu (அறிவு) - Tamil Programming Language

[![PyPI version](https://badge.fury.io/py/arivu.svg)](https://badge.fury.io/py/arivu)
[![Python 3.7+](https://img.shields.io/badge/python-3.7+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

> *"அறிவே ஆற்றல்"* (Knowledge is Power)

A dynamically-typed, interpreted programming language with **easy Tamil words**. Write code in your native language! Perfect for Tamil-speaking students learning programming.

## 🎬 Features

- **Easy Tamil Keywords**: Simple Tamil words anyone can understand
- **Movie-Style Syntax**: Fun and intuitive like Tamil cinema dialogues
- **Dynamic Typing**: Variables can hold any type of value
- **First-Class Functions**: Define and pass functions with ease
- **Recursive Functions**: Full support for recursion
- **Control Flow**: Simple if-else (`na_sonna`/`illa_na_sonna`/`illana`) and loops
- **Interactive REPL**: Test code snippets interactively
- **Clean Syntax**: Simple, readable, and powerful

## 🚀 Getting Started

### Prerequisites

- Python 3.7 or higher

### Installation

Install via pip (recommended):

```bash
pip install arivu
```

Or install from source:

```bash
git clone https://github.com/Akash-srm861/-Arivu.git
cd -Arivu
pip install -e .
```

### Running Programs

**Run an Arivu file:**
```bash
arivu examples/vanakkam.rj
```

**Execute code directly:**
```bash
arivu -c "sollu_da('Vanakkam!');"
```

**Start the interactive REPL:**
```bash
arivu
```

## 📖 Language Guide

### Keywords (Easy Tamil!)

| Tamil Keyword | English Meaning | Usage |
|---------------|-----------------|-------|
| `sollu` | say/tell | Define a function |
| `thirupi_kudu` | give back | Return value from function |
| `vachuko` | keep/store | Declare a variable |
| `aarambam` | start/beginning | Main program entry point |
| `sollu_da` | say it! | Print/output |
| `na_sonna` | if I say | If condition |
| `illa_na_sonna` | or if I say | Else if condition |
| `illana` | otherwise | Else |
| `varaikkum` | until | While loop |
| `ellathukum` | for all | For loop |
| `aama` | yes | Boolean true |
| `illa` | no | Boolean false |
| `onnum_illa` | nothing | Null value |

### Operators

**Arithmetic:** `+` `-` `*` `/` `%`  
**Comparison:** `==` `!=` `>` `<` `>=` `<=`  
**Logical:** `&&` `||` `!`

### Data Types

- **Numbers**: `42`, `3.14`
- **Strings**: `"Vanakkam da!"`
- **Booleans**: `aama` (yes/true), `illa` (no/false)
- **Null**: `onnum_illa` (nothing)

### Comments

```rajini
// Single line comment

/* Multi-line
   comment */
```

## 💡 Examples

### Vanakkam (Hello World)

```rajini
aarambam {
    sollu_da("Vanakkam da mapla!");
    sollu_da("Nalla irukiya?");
}
```

### Variables and Arithmetic

```rajini
aarambam {
    vachuko x = 10;
    vachuko y = 20;
    vachuko sum = x + y;
    sollu_da("Sum is: ");
    sollu_da(sum);
}
```

### Functions

```rajini
sollu kuttu(a, b) {
    thirupi_kudu a + b;
}

sollu vanakkam(name) {
    sollu_da("Vanakkam, ");
    sollu_da(name);
    sollu_da("!");
}

aarambam {
    vachuko result = kuttu(5, 10);
    sollu_da(result);
    
    vanakkam("Rajini");
}
```

### Conditionals

```rajini
aarambam {
    vachuko vayasu = 25;
    
    na_sonna (vayasu >= 18) {
        sollu_da("You are an adult!");
    } illana {
        sollu_da("You are a minor!");
    }
}
```

**With else-if:**
```rajini
aarambam {
    vachuko mark = 85;
    
    na_sonna (mark >= 90) {
        sollu_da("Grade: A");
    } illa_na_sonna (mark >= 80) {
        sollu_da("Grade: B");
    } illa_na_sonna (mark >= 70) {
        sollu_da("Grade: C");
    } illana {
        sollu_da("Grade: F");
    }
}
```

### Loops

**While Loop (varaikkum = until):**
```rajini
aarambam {
    vachuko i = 1;
    varaikkum (i <= 5) {
        sollu_da(i);
        vachuko i = i + 1;
    }
}
```

**For Loop (ellathukum = for all):**
```rajini
aarambam {
    ellathukum (i = 1; i <= 5; i = i + 1) {
        sollu_da(i);
    }
}
```

### Factorial (Recursive)

```rajini
sollu factorial(n) {
    na_sonna (n <= 1) {
        thirupi_kudu 1;
    }
    thirupi_kudu n * factorial(n - 1);
}

aarambam {
    vachuko result = factorial(5);
    sollu_da("Factorial of 5 is: ");
    sollu_da(result);
}
```

### FizzBuzz

```rajini
aarambam {
    ellathukum (i = 1; i <= 30; i = i + 1) {
        vachuko div3 = i % 3;
        vachuko div5 = i % 5;
        
        na_sonna (div3 == 0 && div5 == 0) {
            sollu_da("FizzBuzz");
        } illa_na_sonna (div3 == 0) {
            sollu_da("Fizz");
        } illa_na_sonna (div5 == 0) {
            sollu_da("Buzz");
        } illana {
            sollu_da(i);
        }
    }
}
```

## 📂 Project Structure

```
vijay++/
├── rajini.py           # Main interpreter CLI
├── lexer.py            # Lexical analyzer (tokenizer)
├── parser.py           # Syntax analyzer (AST builder)
├── interpreter.py      # Runtime interpreter
├── LANGUAGE_SPEC.md    # Complete language specification
├── README.md           # This file
└── examples/           # Sample programs
    ├── vanakkam.rj             # Hello World in Tamil
    ├── factorial_tamil.rj      # Factorial with Tamil syntax
    ├── marks_tamil.rj          # Grading system
    ├── loops_tamil.rj          # Loop examples
    ├── calculator_tamil.rj     # Calculator
    ├── hello_world.rj          # (Old English syntax)
    ├── factorial.rj
    ├── fibonacci.rj
    ├── loops.rj
    ├── functions.rj
    ├── fizzbuzz.rj
    └── primes.rj
```

## 🎯 Built-in Functions

- `len(value)` - Get length of string
- `str(value)` - Convert to string
- `int(value)` - Convert to integer
- `float(value)` - Convert to float
- `type(value)` - Get type name

## 🎮 Interactive REPL

Start the REPL by running `python rajini.py` without arguments:

```bash
$ python rajini.py

╔════════════════════════════════════════╗
║   rajini++ Interactive Shell          ║
║   'Namma style-la code potturlam!'   ║
║   Type 'exit' to quit                 ║
╚════════════════════════════════════════╝

rajini++ > vachuko x = 42;
rajini++ > sollu_da(x);
42
rajini++ > vachuko y = x * 2;
rajini++ > sollu_da(y);
84
rajini++ > exit
Vanakkam! (Goodbye!)
```

## 🎨 Philosophy

rajini++ embraces these principles:

1. **Easy Tamil words** - Everyone should understand the code
2. **Movie-style fun** - Programming should be enjoyable like watching a movie
3. **Simple but powerful** - Easy to learn, powerful to use
4. **Namma style** - Code in our own Tamil style!

## 🔧 Implementation Details

rajini++ is implemented in pure Python with three main components:

1. **Lexer** (`lexer.py`) - Tokenizes source code
2. **Parser** (`parser.py`) - Builds Abstract Syntax Tree (AST)
3. **Interpreter** (`interpreter.py`) - Executes the AST

The language supports:
- Lexical scoping with closures
- Dynamic typing
- Recursive function calls
- Expression evaluation with proper operator precedence

## 📝 File Extension

rajini++ programs use the `.rj` file extension (short for "Rajini").

## 🎭 Examples Gallery

Check out the `examples/` directory for sample programs:

**Tamil Syntax (Easy to understand!):**
- **vanakkam.rj** - Hello World in Tamil
- **factorial_tamil.rj** - Factorial with Tamil keywords
- **marks_tamil.rj** - Grading system in Tamil
- **loops_tamil.rj** - Loop demonstrations in Tamil
- **calculator_tamil.rj** - Calculator with Tamil function names

**Original Examples (English keywords):**
- **hello_world.rj** - Classic Hello World
- **factorial.rj** - Recursive factorial
- **fibonacci.rj** - Fibonacci sequence
- **loops.rj** - Loop examples
- **functions.rj** - Advanced functions
- **fizzbuzz.rj** - FizzBuzz challenge
- **primes.rj** - Prime number finder

Run any example:
```bash
python rajini.py examples/vanakkam.rj
python rajini.py examples/marks_tamil.rj
```

## 🚧 Future Enhancements

Potential features for future versions:

- Arrays/Lists support
- Dictionary/Map data structures
- File I/O operations
- Import/Module system
- Exception handling
- More built-in functions
- Bytecode compilation for better performance

## 🤝 Contributing

Contributions are welcome! Feel free to:

- Add new features
- Improve error messages
- Create more example programs
- Optimize the interpreter
- Fix bugs

## 📜 License

This project is open source. Use it with style!

## 🎬 Credits

Made for Tamil speakers who want to code in their own style! Programming should be fun and accessible to everyone.

---

**"Namma style-la code potturlam da!"**  
*(Let's code in our style!)*

**Made with ❤️ for Tamil Cinema Fans!**
