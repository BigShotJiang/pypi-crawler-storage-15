# rajini++ Language Specification

## Overview
rajini++ is a dynamically-typed, interpreted programming language inspired by the legendary Rajinikanth's iconic style and dialogues. It combines simplicity with powerful features and a unique Tamil-cinema-inspired syntax.

## Keywords (Rajini Style!)

### Core Keywords
- `STYLE` - Define a function (Rajini's signature entry with style!)
- `MASS` - Return statement (Return with mass!)
- `PONGAL` - Variable declaration/assignment
- `THALAIVA` - Main entry point
- `PUNCH` - Print/output statement
- `DIALOGUE` - String literal marker
- `MARANA` - If statement (Marana means "awesome/deadly") [Legacy]
- `SEMMA` - Else statement (Semma means "super/cool") [Legacy]
- `Na_Guru_pesuren` - If statement ("If I, the guru, say so!")
- `Nan_GURU_dhan_pesuren` - Else if statement ("If I, THE GURU, say so!")
- `LOOP_AADU` - While loop (Keep looping like Rajini's action scenes!)
- `COUNT_PANNU` - For loop (Count and do!)
- `NULL_ACHU` - Null/None value
- `SERI` - True (Seri means "okay/correct")
- `ILLA` - False (Illa means "no")

### Operators
- `+` Addition
- `-` Subtraction
- `*` Multiplication
- `/` Division
- `%` Modulo
- `==` Equal to
- `!=` Not equal to
- `>` Greater than
- `<` Less than
- `>=` Greater than or equal
- `<=` Less than or equal
- `&&` Logical AND
- `||` Logical OR
- `!` Logical NOT

## Syntax Examples

### Variable Declaration
```
PONGAL x = 10;
PONGAL name = "Rajinikanth";
PONGAL isHero = SERI;
```

### Function Definition
```
STYLE add(a, b) {
    MASS a + b;
}
```

### Conditional Statements
```
MARANA (x > 5) {
    PUNCH("X is greater than 5");
} SEMMA {
    PUNCH("X is 5 or less");
}

// New style with else-if support
Na_Guru_pesuren (x > 10) {
    PUNCH("X is greater than 10");
} Nan_GURU_dhan_pesuren (x > 5) {
    PUNCH("X is greater than 5 but not more than 10");
} SEMMA {
    PUNCH("X is 5 or less");
}
```

### Loops
```
LOOP_AADU (x < 10) {
    PUNCH(x);
    PONGAL x = x + 1;
}

COUNT_PANNU (i = 0; i < 5; i = i + 1) {
    PUNCH(i);
}
```

### Output
```
PUNCH("Hello, World!");
PUNCH(42);
```

### Main Entry Point
```
THALAIVA {
    PUNCH("Rajini style programming!");
}
```

## Data Types
- **Numbers**: Integer and floating-point (42, 3.14)
- **Strings**: Text enclosed in quotes ("Hello")
- **Booleans**: SERI (true) or ILLA (false)
- **Null**: NULL_ACHU

## Comments
```
// Single line comment - Rajini one-liner!
/* Multi-line comment
   for longer explanations */
```

## Example Program
```rajini
// Factorial calculator - Rajini style!
STYLE factorial(n) {
    MARANA (n <= 1) {
        MASS 1;
    }
    MASS n * factorial(n - 1);
}

THALAIVA {
    PONGAL result = factorial(5);
    PUNCH("Factorial of 5 is: ");
    PUNCH(result);
}
```

## Philosophy
- **Style over convention**: Every program should have style, just like Rajini!
- **Mass appeal**: Code should be powerful yet accessible
- **Punch dialogues**: Output should make an impact
- **Simple but powerful**: Like Rajini's effortless charisma

---
*"En vazhi, thani vazhi!" (My way is a unique way!) - The rajini++ motto*
