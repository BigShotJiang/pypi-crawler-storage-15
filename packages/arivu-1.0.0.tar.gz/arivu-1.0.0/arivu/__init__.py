"""
Arivu (அறிவு) - A Tamil Programming Language

Code in your native language with simple, intuitive Tamil keywords.
"""

__version__ = "1.0.0"
__author__ = "Akash"

from .lexer import Lexer, Token, TokenType
from .parser import Parser
from .interpreter import Interpreter

__all__ = ['Lexer', 'Parser', 'Interpreter', 'Token', 'TokenType']
