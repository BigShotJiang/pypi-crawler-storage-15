# Diarykit

An online diary

### Installation

```bash
pip install diarykit
```

### Usage

```python
from diarykit import *
```