import sys
import ex_cd

if __name__ == "__main__":
    sys.exit(ex_cd.main())