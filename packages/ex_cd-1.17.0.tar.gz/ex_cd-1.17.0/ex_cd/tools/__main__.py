import sys
import ex_cd.tools

if __name__ == "__main__":
    sys.exit(ex_cd.tools.main())
