# resens
Raster Processing package for Remote Sensing and Earth Observation.

## Installation
Requires python >=3.8
