"""
Browser context (page) for automation.

Each context is an isolated browser tab/window with its own cookies,
storage, and session state.
"""

import json
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Union
from concurrent.futures import Future

from .core import BrowserCore
from .types import (
    ContextId,
    Viewport,
    PageInfo,
    CleanLevel,
    MarkdownOptions,
    VideoRecordingOptions,
    ScreenshotOptions,
    WaitOptions,
    KeyName,
    ExtractionTemplate,
    Cookie,
    SetCookieOptions,
    CookieSameSite,
    ProxyConfig,
    ProxyStatus,
    ProxyType,
    TestTemplate,
    TestStep,
    TestExecutionOptions,
    TestExecutionResult,
    TestError,
    BrowserProfile,
    BrowserFingerprint,
    LLMConfig,
    CaptchaProvider,
)


class BrowserContext:
    """
    Browser context (tab/window) for automation.

    Provides methods for navigation, interaction, content extraction,
    AI features, and more. Thread-safe for concurrent usage.

    Example:
        ```python
        page = await browser.new_page()
        await page.goto("https://example.com")
        await page.click("search button")
        await page.type("search input", "hello world")
        screenshot = await page.screenshot()
        await page.close()
        ```
    """

    def __init__(self, context_id: ContextId, core: BrowserCore):
        self._context_id = context_id
        self._core = core

    @property
    def id(self) -> ContextId:
        """Get the context ID."""
        return self._context_id

    def _cmd(self, method: str, **kwargs) -> Any:
        """Send a command with context_id."""
        params = {"context_id": self._context_id, **kwargs}
        return self._core.send_command(method, params)

    # ==================== NAVIGATION ====================

    def goto(self, url: str, wait_until: str = "load", timeout: int = 30000) -> None:
        """
        Navigate to a URL.

        Args:
            url: URL to navigate to (http:// added automatically if missing)
            wait_until: Wait condition ('load', 'domcontentloaded', 'networkidle')
            timeout: Timeout in milliseconds

        Example:
            ```python
            page.goto("https://example.com")
            page.goto("example.com")  # Auto-adds https://
            ```
        """
        # Auto-add protocol if missing
        if not url.startswith(("http://", "https://")):
            url = "https://" + url

        self._cmd("navigate", url=url)

    def reload(self, ignore_cache: bool = False) -> None:
        """
        Reload the current page.

        Args:
            ignore_cache: If True, bypass cache (hard reload)
        """
        self._cmd("reload", ignore_cache=ignore_cache)

    def go_back(self) -> None:
        """Navigate back in history."""
        self._cmd("goBack")

    def go_forward(self) -> None:
        """Navigate forward in history."""
        self._cmd("goForward")

    # ==================== INTERACTIONS ====================

    def click(self, selector: str) -> None:
        """
        Click an element.

        Args:
            selector: CSS selector, coordinates (e.g., "100x200"),
                     or natural language description (e.g., "search button", "login link")

        Example:
            ```python
            page.click("#submit")  # CSS selector
            page.click("100x200")  # Coordinates
            page.click("search button")  # Natural language
            page.click("the blue login button")  # Semantic description
            ```
        """
        self._cmd("click", selector=selector)

    def type(self, selector: str, text: str) -> None:
        """
        Type text into an input field.

        Args:
            selector: CSS selector, coordinates, or natural language description
            text: Text to type

        Example:
            ```python
            page.type("#email", "user@example.com")
            page.type("email input", "user@example.com")  # Natural language
            ```
        """
        self._cmd("type", selector=selector, text=text)

    def pick(self, selector: str, value: str) -> None:
        """
        Select an option from a dropdown/select element.

        Supports both native select elements and custom dropdowns (like select2).

        Args:
            selector: CSS selector or natural language description
            value: Value or visible text of the option to select

        Example:
            ```python
            page.pick("#country", "United States")
            page.pick("country dropdown", "Morocco")  # Natural language
            ```
        """
        self._cmd("pick", selector=selector, value=value)

    def press_key(self, key: Union[KeyName, str]) -> None:
        """
        Press a special key.

        Args:
            key: Key name (Enter, Tab, Escape, ArrowUp, ArrowDown, etc.)

        Example:
            ```python
            page.press_key(KeyName.ENTER)
            page.press_key("Tab")
            page.press_key(KeyName.ESCAPE)
            ```
        """
        key_value = key.value if isinstance(key, KeyName) else key
        self._cmd("pressKey", key=key_value)

    def submit_form(self) -> None:
        """
        Submit the currently focused form by pressing Enter.

        Useful for search boxes and forms that submit on Enter.
        """
        self._cmd("submitForm")

    def highlight(
        self,
        selector: str,
        border_color: str = "#FF0000",
        background_color: str = "rgba(255, 0, 0, 0.2)"
    ) -> None:
        """
        Highlight an element for debugging.

        Args:
            selector: CSS selector or natural language description
            border_color: Border color (CSS color)
            background_color: Background color (CSS color with alpha)

        Example:
            ```python
            page.highlight("submit button")
            page.highlight("#login", border_color="#00FF00")
            ```
        """
        self._cmd(
            "highlight",
            selector=selector,
            border_color=border_color,
            background_color=background_color
        )

    def show_grid_overlay(
        self,
        horizontal_lines: int = 25,
        vertical_lines: int = 25,
        line_color: str = "rgba(255, 0, 0, 0.15)",
        text_color: str = "rgba(255, 0, 0, 0.4)"
    ) -> None:
        """
        Show a grid overlay on top of the web page with XY position coordinates at intersections.

        Useful for debugging and understanding element positions.

        Args:
            horizontal_lines: Number of horizontal lines (top to bottom). Default: 25
            vertical_lines: Number of vertical lines (left to right). Default: 25
            line_color: Line color with opacity (CSS color). Default: "rgba(255, 0, 0, 0.15)"
            text_color: Coordinate label text color (CSS color). Default: "rgba(255, 0, 0, 0.4)"

        Example:
            ```python
            # Show default grid overlay (25x25 lines)
            page.show_grid_overlay()

            # Show custom grid with 10 lines and blue color
            page.show_grid_overlay(10, 10, "rgba(0, 0, 255, 0.2)", "rgba(0, 0, 255, 0.5)")
            ```
        """
        self._cmd(
            "showGridOverlay",
            horizontal_lines=horizontal_lines,
            vertical_lines=vertical_lines,
            line_color=line_color,
            text_color=text_color
        )

    # ==================== DRAG AND DROP ====================

    def drag_drop(
        self,
        start_x: int,
        start_y: int,
        end_x: int,
        end_y: int,
        mid_points: Optional[List[List[int]]] = None
    ) -> None:
        """
        Drag from a start position to an end position, optionally passing through waypoints.

        Useful for slider CAPTCHAs, puzzle solving, and drawing interactions.

        Args:
            start_x: Start X coordinate for the drag
            start_y: Start Y coordinate for the drag
            end_x: End X coordinate for the drop
            end_y: End Y coordinate for the drop
            mid_points: Optional list of [x, y] waypoints to pass through during drag

        Example:
            ```python
            # Simple drag from point A to point B
            page.drag_drop(100, 200, 300, 200)

            # Drag through waypoints (for drawing or complex paths)
            page.drag_drop(100, 100, 100, 300, [
                [150, 150],
                [200, 200],
                [150, 250]
            ])

            # Slider CAPTCHA
            page.drag_drop(slider_x, slider_y, slider_x + 200, slider_y)
            ```
        """
        self._cmd(
            "dragDrop",
            start_x=start_x,
            start_y=start_y,
            end_x=end_x,
            end_y=end_y,
            mid_points=mid_points or []
        )

    def html5_drag_drop(
        self,
        source_selector: str,
        target_selector: str
    ) -> None:
        """
        Drag and drop for HTML5 draggable elements.

        For elements with `draggable="true"` attribute. Dispatches proper HTML5
        DragEvent objects (dragstart, dragover, drop, dragend).
        Use this for reordering lists, sortable interfaces, and any elements
        using the HTML5 Drag and Drop API.

        Args:
            source_selector: CSS selector for the source element to drag
            target_selector: CSS selector for the target element to drop onto

        Example:
            ```python
            # Reorder items in a sortable list
            page.html5_drag_drop(
                '.item[data-id="3"]',
                '.item[data-id="1"]'
            )

            # Move item to a different container
            page.html5_drag_drop(
                '#source-list .item:first-child',
                '#target-list'
            )
            ```
        """
        self._cmd(
            "html5DragDrop",
            source_selector=source_selector,
            target_selector=target_selector
        )

    # ==================== CONTENT EXTRACTION ====================

    def extract_text(self, selector: str = "body") -> str:
        """
        Extract text content from the page.

        Args:
            selector: CSS selector or natural language description (default: 'body')

        Returns:
            Extracted text content

        Example:
            ```python
            all_text = page.extract_text()
            article = page.extract_text("article")
            headline = page.extract_text("main headline")
            ```
        """
        return self._cmd("extractText", selector=selector)

    def get_html(self, clean_level: Union[CleanLevel, str] = CleanLevel.BASIC) -> str:
        """
        Get HTML content from the page.

        Args:
            clean_level: Cleaning level ('minimal', 'basic', 'aggressive')

        Returns:
            HTML content
        """
        level = clean_level.value if isinstance(clean_level, CleanLevel) else clean_level
        return self._cmd("getHTML", clean_level=level)

    def get_markdown(
        self,
        include_links: bool = True,
        include_images: bool = True,
        max_length: int = -1
    ) -> str:
        """
        Get page content as Markdown.

        Args:
            include_links: Include links in markdown
            include_images: Include images in markdown
            max_length: Maximum length (-1 for no limit)

        Returns:
            Markdown content
        """
        return self._cmd(
            "getMarkdown",
            include_links=include_links,
            include_images=include_images,
            max_length=max_length
        )

    def extract_json(
        self,
        template: Union[ExtractionTemplate, str] = ExtractionTemplate.AUTO
    ) -> Dict[str, Any]:
        """
        Extract structured JSON data using templates.

        Args:
            template: Template name or empty string for auto-detection

        Returns:
            Extracted JSON data

        Example:
            ```python
            # Auto-detect template
            data = page.extract_json()

            # Use specific template
            data = page.extract_json(ExtractionTemplate.GOOGLE_SEARCH)
            ```
        """
        template_name = template.value if isinstance(template, ExtractionTemplate) else template
        result = self._cmd("extractJSON", template_name=template_name)
        return result if isinstance(result, dict) else json.loads(result)

    def detect_website_type(self) -> str:
        """Detect website type for template matching."""
        return self._cmd("detectWebsiteType")

    def summarize_page(self, force_refresh: bool = False) -> Dict[str, Any]:
        """
        Get intelligent, structured summary of the current page using LLM.

        The summary is cached per URL for fast repeat access.

        Args:
            force_refresh: Force refresh the summary (ignore cache)

        Returns:
            Structured page summary
        """
        result = self._cmd("summarizePage", force_refresh=force_refresh)
        return result if isinstance(result, dict) else json.loads(result) if result else {}

    def list_templates(self) -> List[str]:
        """List available extraction templates."""
        return self._core.list_templates()

    # ==================== AI FEATURES ====================

    def query_page(self, query: str) -> str:
        """
        Query the page using on-device LLM.

        Args:
            query: Natural language question about the page

        Returns:
            Answer from the LLM

        Example:
            ```python
            answer = page.query_page("What is the main topic of this page?")
            prices = page.query_page("Extract all prices mentioned")
            ```
        """
        return self._cmd("queryPage", query=query)

    def llm_status(self) -> str:
        """
        Check if the on-device LLM is ready to use.

        Returns:
            Status: "ready", "loading", or "unavailable"
        """
        return self._cmd("llmStatus")

    def execute_nla(self, command: str) -> str:
        """
        Execute natural language automation command.

        The LLM will plan and execute multi-step browser actions automatically.

        Args:
            command: Natural language command

        Returns:
            Execution result

        Example:
            ```python
            page.execute_nla("go to google.com and search for banana")
            page.execute_nla("click the first search result")
            page.execute_nla("fill out the contact form with test data")
            ```
        """
        return self._cmd("executeNLA", query=command)

    # ==================== SCREENSHOT & VIDEO ====================

    def screenshot(self, path: Optional[str] = None) -> bytes:
        """
        Take a screenshot.

        Args:
            path: Optional file path to save the screenshot

        Returns:
            PNG image data as bytes

        Example:
            ```python
            # Get screenshot as bytes
            png_data = page.screenshot()

            # Save to file
            page.screenshot("screenshot.png")

            # Save and get bytes
            png_data = page.screenshot("screenshot.png")
            ```
        """
        import base64
        result = self._cmd("screenshot")
        png_data = base64.b64decode(result) if isinstance(result, str) else result

        if path:
            Path(path).write_bytes(png_data)

        return png_data

    def start_video_recording(self, fps: int = 30, codec: str = "libx264") -> None:
        """
        Start video recording.

        Args:
            fps: Frames per second (default: 30)
            codec: Video codec (default: "libx264")
        """
        self._cmd("startVideoRecording", fps=fps, codec=codec)

    def pause_video_recording(self) -> None:
        """Pause video recording without stopping it."""
        self._cmd("pauseVideoRecording")

    def resume_video_recording(self) -> None:
        """Resume a paused video recording."""
        self._cmd("resumeVideoRecording")

    def stop_video_recording(self) -> str:
        """
        Stop video recording and get video path.

        Returns:
            Path to the saved video file
        """
        return self._cmd("stopVideoRecording")

    def get_video_stats(self) -> str:
        """Get video recording statistics."""
        return self._cmd("getVideoRecordingStats")

    # ==================== SCROLLING ====================

    def scroll_by(self, x: int = 0, y: int = 0) -> None:
        """
        Scroll by specified pixels.

        Args:
            x: Horizontal scroll amount
            y: Vertical scroll amount
        """
        self._cmd("scrollBy", x=x, y=y)

    def scroll_to(self, x: int, y: int) -> None:
        """
        Scroll to absolute position.

        Args:
            x: Horizontal position
            y: Vertical position
        """
        self._cmd("scrollTo", x=x, y=y)

    def scroll_to_element(self, selector: str) -> None:
        """
        Scroll element into view.

        Args:
            selector: CSS selector or natural language description
        """
        self._cmd("scrollToElement", selector=selector)

    def scroll_to_top(self) -> None:
        """Scroll to top of page."""
        self._cmd("scrollToTop")

    def scroll_to_bottom(self) -> None:
        """Scroll to bottom of page."""
        self._cmd("scrollToBottom")

    # ==================== WAITING ====================

    def wait_for_selector(self, selector: str, timeout: int = 5000) -> None:
        """
        Wait for element to appear.

        Args:
            selector: CSS selector or natural language description
            timeout: Timeout in milliseconds

        Raises:
            RuntimeError: If element not found within timeout
        """
        self._cmd("waitForSelector", selector=selector, timeout=timeout)

    def wait(self, timeout: int) -> None:
        """
        Wait for specified time (use wait_for_selector when possible).

        Args:
            timeout: Time to wait in milliseconds
        """
        self._cmd("waitForTimeout", timeout=timeout)

    # ==================== PAGE STATE ====================

    def get_current_url(self) -> str:
        """Get current URL."""
        return self._cmd("getCurrentURL")

    def get_title(self) -> str:
        """Get page title."""
        return self._cmd("getPageTitle")

    def get_page_info(self) -> PageInfo:
        """Get comprehensive page information."""
        result = self._cmd("getPageInfo")
        if isinstance(result, dict):
            return PageInfo(
                url=result.get("url", ""),
                title=result.get("title", ""),
                can_go_back=result.get("canGoBack", False),
                can_go_forward=result.get("canGoForward", False),
            )
        return PageInfo(url="", title="")

    # ==================== VIEWPORT ====================

    def set_viewport(self, width: int, height: int) -> None:
        """
        Set viewport size.

        Args:
            width: Viewport width in pixels
            height: Viewport height in pixels
        """
        self._cmd("setViewport", width=width, height=height)

    def get_viewport(self) -> Viewport:
        """Get current viewport size."""
        result = self._cmd("getViewport")
        if isinstance(result, dict):
            return Viewport(
                width=result.get("width", 1280),
                height=result.get("height", 720)
            )
        return Viewport(width=1280, height=720)

    # ==================== DEMOGRAPHICS ====================

    def get_demographics(self) -> Dict[str, Any]:
        """
        Get user demographics and context (location, time, weather).

        Useful for location-aware searches like "find me a restaurant".
        """
        return self._core.get_demographics()

    def get_location(self) -> Dict[str, Any]:
        """Get user's current location based on IP address."""
        return self._core.get_location()

    def get_datetime(self) -> Dict[str, Any]:
        """Get current date and time information."""
        return self._core.get_datetime()

    def get_weather(self) -> Dict[str, Any]:
        """Get current weather for the user's location."""
        return self._core.get_weather()

    # ==================== CAPTCHA SOLVING ====================

    def detect_captcha(self) -> Dict[str, Any]:
        """
        Detect if the current page has a CAPTCHA.

        Returns:
            Detection result with confidence score
        """
        result = self._cmd("detectCaptcha")
        return result if isinstance(result, dict) else json.loads(result) if result else {}

    def classify_captcha(self) -> Dict[str, Any]:
        """
        Classify the type of CAPTCHA on the page.

        Returns:
            Classification result with CAPTCHA type and element selectors
        """
        result = self._cmd("classifyCaptcha")
        return result if isinstance(result, dict) else json.loads(result) if result else {}

    def solve_text_captcha(self, max_attempts: int = 3) -> Dict[str, Any]:
        """
        Solve a text-based CAPTCHA using vision model.

        Args:
            max_attempts: Maximum number of attempts

        Returns:
            Solve result with success status and extracted text
        """
        result = self._cmd("solveTextCaptcha", max_attempts=max_attempts)
        return result if isinstance(result, dict) else json.loads(result) if result else {}

    def solve_image_captcha(
        self,
        max_attempts: int = 3,
        provider: Union[CaptchaProvider, str] = CaptchaProvider.AUTO
    ) -> Dict[str, Any]:
        """
        Solve an image-selection CAPTCHA (e.g., "select all traffic lights").

        Args:
            max_attempts: Maximum number of attempts
            provider: CAPTCHA provider to use ('auto', 'owl', 'recaptcha', 'cloudflare', 'hcaptcha')

        Returns:
            Solve result with success status and provider used

        Example:
            ```python
            # Auto-detect provider
            result = page.solve_image_captcha()

            # Use specific provider
            result = page.solve_image_captcha(provider=CaptchaProvider.RECAPTCHA)

            # With max attempts
            result = page.solve_image_captcha(max_attempts=5, provider="cloudflare")
            ```
        """
        provider_value = provider.value if isinstance(provider, CaptchaProvider) else provider
        result = self._cmd("solveImageCaptcha", max_attempts=max_attempts, provider=provider_value)
        return result if isinstance(result, dict) else json.loads(result) if result else {}

    def solve_captcha(
        self,
        max_attempts: int = 3,
        provider: Union[CaptchaProvider, str] = CaptchaProvider.AUTO
    ) -> Dict[str, Any]:
        """
        Auto-detect and solve any supported CAPTCHA type.

        Args:
            max_attempts: Maximum number of attempts
            provider: CAPTCHA provider to use for image CAPTCHAs ('auto', 'owl', 'recaptcha', 'cloudflare', 'hcaptcha')

        Returns:
            Solve result with success status

        Example:
            ```python
            # Auto-detect everything
            result = page.solve_captcha()

            # Use specific provider for image CAPTCHAs
            result = page.solve_captcha(provider=CaptchaProvider.RECAPTCHA)

            # With max attempts
            result = page.solve_captcha(max_attempts=5)
            ```
        """
        provider_value = provider.value if isinstance(provider, CaptchaProvider) else provider
        result = self._cmd("solveCaptcha", max_attempts=max_attempts, provider=provider_value)
        return result if isinstance(result, dict) else json.loads(result) if result else {}

    # ==================== COOKIE MANAGEMENT ====================

    def get_cookies(self, url: Optional[str] = None) -> List[Cookie]:
        """
        Get all cookies from the browser context.

        Args:
            url: Optional URL to filter cookies

        Returns:
            List of cookies

        Example:
            ```python
            all_cookies = page.get_cookies()
            site_cookies = page.get_cookies("https://example.com")
            ```
        """
        result = self._cmd("getCookies", url=url or "")
        if not result:
            return []

        cookies = result if isinstance(result, list) else json.loads(result)
        return [
            Cookie(
                name=c.get("name", ""),
                value=c.get("value", ""),
                domain=c.get("domain", ""),
                path=c.get("path", "/"),
                secure=c.get("secure", False),
                http_only=c.get("httpOnly", False),
                same_site=CookieSameSite(c.get("sameSite", "lax")),
                expires=c.get("expires", -1),
            )
            for c in cookies
        ]

    def set_cookie(
        self,
        url: str,
        name: str,
        value: str,
        domain: Optional[str] = None,
        path: str = "/",
        secure: bool = False,
        http_only: bool = False,
        same_site: Union[CookieSameSite, str] = CookieSameSite.LAX,
        expires: int = -1
    ) -> bool:
        """
        Set a cookie in the browser context.

        Args:
            url: URL to associate with the cookie
            name: Cookie name
            value: Cookie value
            domain: Cookie domain (optional)
            path: Cookie path (default: "/")
            secure: Whether cookie should only be sent over HTTPS
            http_only: Whether cookie is inaccessible to JavaScript
            same_site: SameSite attribute ('none', 'lax', 'strict')
            expires: Unix timestamp for expiration (-1 for session cookie)

        Returns:
            True if cookie was set successfully

        Example:
            ```python
            page.set_cookie("https://example.com", "session", "abc123")
            page.set_cookie(
                "https://example.com",
                "prefs",
                "dark-mode",
                secure=True,
                http_only=True,
                expires=int(time.time()) + 86400  # 1 day
            )
            ```
        """
        same_site_value = same_site.value if isinstance(same_site, CookieSameSite) else same_site
        return self._cmd(
            "setCookie",
            url=url,
            name=name,
            value=value,
            domain=domain or "",
            path=path,
            secure=secure,
            httpOnly=http_only,
            sameSite=same_site_value,
            expires=expires,
        )

    def delete_cookies(self, url: Optional[str] = None, name: Optional[str] = None) -> bool:
        """
        Delete cookies from the browser context.

        Args:
            url: Optional URL to filter which cookies to delete
            name: Optional specific cookie name to delete

        Returns:
            True if cookies were deleted successfully

        Example:
            ```python
            page.delete_cookies()  # Delete all
            page.delete_cookies("https://example.com")  # Delete for URL
            page.delete_cookies("https://example.com", "session")  # Delete specific
            ```
        """
        return self._cmd("deleteCookies", url=url or "", cookie_name=name or "")

    # ==================== PROXY MANAGEMENT ====================

    def set_proxy(self, config: ProxyConfig) -> bool:
        """
        Configure proxy settings for this browser context.

        Includes stealth features to prevent proxy/VPN detection.

        Args:
            config: Proxy configuration

        Returns:
            True if proxy was configured successfully

        Example:
            ```python
            page.set_proxy(ProxyConfig(
                type=ProxyType.SOCKS5H,
                host="proxy.example.com",
                port=1080,
                username="user",
                password="pass",
                stealth=True,
                timezone_override="America/New_York"
            ))
            ```
        """
        return self._cmd(
            "setProxy",
            type=config.type.value,
            host=config.host,
            port=config.port,
            username=config.username or "",
            password=config.password or "",
            stealth=config.stealth,
            block_webrtc=config.block_webrtc,
            spoof_timezone=config.spoof_timezone,
            spoof_language=config.spoof_language,
            timezone_override=config.timezone_override or "",
            language_override=config.language_override or "",
        )

    def get_proxy_status(self) -> ProxyStatus:
        """
        Get current proxy configuration and connection status.

        Returns:
            Proxy status object
        """
        result = self._cmd("getProxyStatus")
        if isinstance(result, dict):
            return ProxyStatus(
                enabled=result.get("enabled", False),
                connected=result.get("connected", False),
                type=ProxyType(result["type"]) if result.get("type") else None,
                host=result.get("host"),
                port=result.get("port"),
                stealth=result.get("stealth"),
                block_webrtc=result.get("blockWebrtc"),
            )
        return ProxyStatus(enabled=False, connected=False)

    def connect_proxy(self) -> bool:
        """Enable/connect the configured proxy."""
        return self._cmd("connectProxy")

    def disconnect_proxy(self) -> bool:
        """Disable/disconnect the proxy, reverting to direct connection."""
        return self._cmd("disconnectProxy")

    # ==================== BROWSER PROFILE MANAGEMENT ====================

    def save_profile(self, profile_path: Optional[str] = None) -> BrowserProfile:
        """
        Save the current context state to a browser profile.

        The profile includes fingerprints, cookies, and configuration settings.
        This enables persistent browser identities across sessions.

        Args:
            profile_path: Path to save the profile JSON file. If not provided,
                         uses the profile path set during context creation.

        Returns:
            BrowserProfile object with the saved state

        Example:
            ```python
            # Save profile to file
            profile = page.save_profile("/path/to/profile.json")
            print(f"Saved profile: {profile.profile_id}")
            print(f"Cookies: {len(profile.cookies)}")
            ```
        """
        result = self._cmd("saveProfile", profile_path=profile_path or "")
        return self._parse_profile(result)

    def get_profile(self) -> BrowserProfile:
        """
        Get the current profile state for this context.

        Returns the in-memory profile state without saving to disk.

        Returns:
            BrowserProfile object with current state

        Example:
            ```python
            profile = page.get_profile()
            print(f"User Agent: {profile.fingerprint.user_agent}")
            print(f"Cookies: {len(profile.cookies)}")
            ```
        """
        result = self._cmd("getProfile")
        return self._parse_profile(result)

    def update_profile_cookies(self) -> bool:
        """
        Update the profile file with current cookies from the browser.

        This is useful when you want to persist cookie changes without
        saving the entire profile state.

        Returns:
            True if cookies were updated successfully

        Example:
            ```python
            # After logging in
            page.goto("https://example.com/login")
            page.type("email input", "user@example.com")
            page.type("password input", "password")
            page.click("login button")

            # Save the session cookies
            page.update_profile_cookies()
            ```
        """
        return self._cmd("updateProfileCookies")

    def _parse_profile(self, data: Any) -> BrowserProfile:
        """Parse profile data from command result."""
        if isinstance(data, str):
            data = json.loads(data)

        if not isinstance(data, dict):
            return BrowserProfile()

        # Parse fingerprint
        fingerprint = None
        fp_data = data.get("fingerprint", {})
        if fp_data:
            fingerprint = BrowserFingerprint(
                user_agent=fp_data.get("user_agent", ""),
                platform=fp_data.get("platform", "Win32"),
                vendor=fp_data.get("vendor", "Google Inc."),
                languages=fp_data.get("languages", ["en-US", "en"]),
                hardware_concurrency=fp_data.get("hardware_concurrency", 8),
                device_memory=fp_data.get("device_memory", 8),
                max_touch_points=fp_data.get("max_touch_points", 0),
                canvas_noise_seed=fp_data.get("canvas_noise_seed", 0.0),
                gpu_profile_index=fp_data.get("gpu_profile_index", 0),
                webgl_vendor=fp_data.get("webgl_vendor", ""),
                webgl_renderer=fp_data.get("webgl_renderer", ""),
                screen_width=fp_data.get("screen_width", 1920),
                screen_height=fp_data.get("screen_height", 1080),
                color_depth=fp_data.get("color_depth", 24),
                pixel_ratio=fp_data.get("pixel_ratio", 1),
                timezone=fp_data.get("timezone", ""),
                locale=fp_data.get("locale", "en-US"),
                audio_noise_seed=fp_data.get("audio_noise_seed", 0.0),
                installed_fonts=fp_data.get("installed_fonts", []),
                has_pdf_plugin=fp_data.get("has_pdf_plugin", True),
                has_chrome_pdf=fp_data.get("has_chrome_pdf", True),
            )

        # Parse cookies
        cookies = []
        for c in data.get("cookies", []):
            cookies.append(Cookie(
                name=c.get("name", ""),
                value=c.get("value", ""),
                domain=c.get("domain", ""),
                path=c.get("path", "/"),
                secure=c.get("secure", False),
                http_only=c.get("httpOnly", False),
                same_site=CookieSameSite(c.get("sameSite", "lax")),
                expires=c.get("expires", -1),
            ))

        # Parse LLM config
        llm_config = None
        llm_data = data.get("llm_config", {})
        if data.get("has_llm_config") and llm_data:
            llm_config = LLMConfig(
                enabled=llm_data.get("enabled", True),
                use_builtin=llm_data.get("use_builtin", True),
                endpoint=llm_data.get("external_endpoint"),
                model=llm_data.get("external_model"),
            )

        # Parse proxy config
        proxy_config = None
        proxy_data = data.get("proxy_config", {})
        if data.get("has_proxy_config") and proxy_data:
            proxy_config = ProxyConfig(
                type=ProxyType(proxy_data.get("type", "http")),
                host=proxy_data.get("host", ""),
                port=proxy_data.get("port", 0),
                username=proxy_data.get("username"),
                password=proxy_data.get("password"),
            )

        return BrowserProfile(
            profile_id=data.get("profile_id", ""),
            profile_name=data.get("profile_name", ""),
            created_at=data.get("created_at", ""),
            modified_at=data.get("modified_at", ""),
            version=data.get("version", 1),
            fingerprint=fingerprint,
            cookies=cookies,
            has_llm_config=data.get("has_llm_config", False),
            llm_config=llm_config,
            has_proxy_config=data.get("has_proxy_config", False),
            proxy_config=proxy_config,
            auto_save_cookies=data.get("auto_save_cookies", True),
            persist_local_storage=data.get("persist_local_storage", True),
        )

    # ==================== TEST EXECUTION ====================

    def run_test(
        self,
        test: Union[TestTemplate, str, Dict[str, Any]],
        continue_on_error: bool = False,
        screenshot_on_error: bool = True,
        verbose: bool = False
    ) -> TestExecutionResult:
        """
        Execute a test from Developer Playground JSON template.

        Args:
            test: Test template (TestTemplate, dict, or file path)
            continue_on_error: Continue execution after errors
            screenshot_on_error: Take screenshot on error
            verbose: Enable verbose logging

        Returns:
            Test execution result

        Example:
            ```python
            # Load test from JSON file
            result = page.run_test("test.json")

            # Define test inline
            result = page.run_test({
                "name": "Login Test",
                "steps": [
                    {"type": "navigate", "url": "https://example.com/login"},
                    {"type": "type", "selector": "#email", "text": "user@example.com"},
                    {"type": "click", "selector": "button[type='submit']"},
                ]
            })

            print(f"Success: {result.successful_steps}/{result.total_steps}")
            ```
        """
        # Parse test if string (file path) or dict
        if isinstance(test, str):
            test_data = json.loads(Path(test).read_text())
        elif isinstance(test, dict):
            test_data = test
        else:
            test_data = {
                "name": test.name,
                "description": test.description,
                "steps": [
                    {
                        "type": s.type,
                        "selected": s.selected,
                        "url": s.url,
                        "selector": s.selector,
                        "text": s.text,
                        "value": s.value,
                        "duration": s.duration,
                        "filename": s.filename,
                        "query": s.query,
                        "command": s.command,
                        "fps": s.fps,
                    }
                    for s in test.steps
                ]
            }

        # Filter selected steps
        steps = [s for s in test_data.get("steps", []) if s.get("selected", True)]

        result = TestExecutionResult(
            test_name=test_data.get("name", "Unnamed Test"),
            total_steps=len(steps),
            executed_steps=0,
            successful_steps=0,
            failed_steps=0,
            execution_time=0,
            success=True,
            errors=[]
        )

        start_time = time.time()

        if verbose:
            print(f"[Test] Starting: {result.test_name}")
            if test_data.get("description"):
                print(f"[Test] Description: {test_data['description']}")

        for i, step in enumerate(steps):
            result.executed_steps += 1
            step_type = step.get("type", "")

            if verbose:
                print(f"[Test] Step {i + 1}/{result.total_steps}: {step_type}")

            try:
                self._execute_step(step)
                result.successful_steps += 1
                if verbose:
                    print(f"[Test] Step {i + 1}: Success")

            except Exception as e:
                result.failed_steps += 1
                result.success = False
                error_msg = str(e)
                result.errors.append(TestError(step=i + 1, type=step_type, message=error_msg))

                print(f"[Test] Step {i + 1} failed: {error_msg}")

                if screenshot_on_error:
                    try:
                        error_screenshot = f"error-step-{i + 1}.png"
                        self.screenshot(error_screenshot)
                        print(f"[Test] Error screenshot saved: {error_screenshot}")
                    except Exception:
                        pass

                if not continue_on_error:
                    print("[Test] Stopping execution due to error")
                    break

        result.execution_time = (time.time() - start_time) * 1000

        if verbose:
            print(f"[Test] Completed: {result.test_name}")
            print(f"[Test] Time: {result.execution_time:.0f}ms")
            print(f"[Test] Success: {result.successful_steps}/{result.total_steps}")
            if result.failed_steps > 0:
                print(f"[Test] Failed: {result.failed_steps}")

        return result

    def _execute_step(self, step: Dict[str, Any]) -> None:
        """Execute a single test step."""
        step_type = step.get("type", "")

        if step_type == "navigate":
            self.goto(step["url"])
        elif step_type == "click":
            self.click(step["selector"])
        elif step_type == "type":
            self.type(step["selector"], step["text"])
        elif step_type == "pick":
            self.pick(step["selector"], step["value"])
        elif step_type == "wait":
            self.wait(step.get("duration", 2000))
        elif step_type == "screenshot":
            self.screenshot(step.get("filename", "screenshot.png"))
        elif step_type == "extract":
            self.extract_text(step.get("selector", "body"))
        elif step_type == "submit_form":
            self.submit_form()
        elif step_type == "query":
            self.query_page(step["query"])
        elif step_type == "nla":
            self.execute_nla(step["command"])
        elif step_type == "solve_captcha":
            self.solve_captcha()
        elif step_type == "highlight":
            self.highlight(step["selector"])
        elif step_type == "scroll_up":
            self.scroll_by(0, -500)
        elif step_type == "scroll_down":
            self.scroll_by(0, 500)
        elif step_type == "record_video":
            self.start_video_recording(fps=step.get("fps", 30))
        elif step_type == "stop_video":
            self.stop_video_recording()
        else:
            raise ValueError(f"Unknown step type: {step_type}")

    # ==================== CLEANUP ====================

    def close(self) -> None:
        """Close this context and release resources."""
        self._core.release_context(self._context_id)

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - auto-close."""
        self.close()
        return False
