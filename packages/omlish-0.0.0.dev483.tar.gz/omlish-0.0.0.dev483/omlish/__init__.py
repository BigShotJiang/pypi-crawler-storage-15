# While the library as a whole only supports modern python, the 'lite' package is importable and usable down to python
# 3.8. As a result this file needs to be kept basically empty as anything it would otherwise do would likely involve
# non-lite code.
