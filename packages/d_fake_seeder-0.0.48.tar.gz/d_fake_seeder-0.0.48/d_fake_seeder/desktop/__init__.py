"""
View layer - User interface components
"""
