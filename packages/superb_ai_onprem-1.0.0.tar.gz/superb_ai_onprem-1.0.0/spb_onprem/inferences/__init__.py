from .service import InferService

__all__ = [
    "InferService",
]