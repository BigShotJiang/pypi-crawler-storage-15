# API module for snapy
# Reserved for future API extensions
