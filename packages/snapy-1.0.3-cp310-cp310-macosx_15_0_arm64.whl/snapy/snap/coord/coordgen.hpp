#pragma once

namespace snap {
float UniformCoord(float x, float xmin, float xmax, void*);
}
