#pragma once

int checkCudaError(const char *msg);
