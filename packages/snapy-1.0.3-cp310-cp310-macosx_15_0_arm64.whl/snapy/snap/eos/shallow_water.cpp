// snap
#include "shallow_water.hpp"

#include <snap/snap.h>

namespace snap {

ShallowWaterImpl::ShallowWaterImpl(EquationOfStateOptions const &options_)
    : EquationOfStateImpl(options_) {
  reset();
}

void ShallowWaterImpl::reset() {
  pcoord = CoordinateImpl::create(options->coord(), this);
}

torch::Tensor ShallowWaterImpl::compute(
    std::string ab, std::vector<torch::Tensor> const &args) {
  if (ab == "W->U") {
    auto w = args[0];
    auto u = args.size() > 1 ? args[1] : torch::empty_like(w);
    _prim2cons(w, u);
    return u;
  } else if (ab == "U->W") {
    auto u = args[0];
    auto w = args.size() > 1 ? args[1] : torch::empty_like(u);
    _cons2prim(u, w);
    return w;
  } else if (ab == "W->A") {
    return torch::Tensor();
  } else if (ab == "WA->L") {
    auto w = args[0];
    return _gravity_wave_speed(w);
  } else {
    TORCH_CHECK(false, "Unknown abbreviation: ", ab);
  }
}

void ShallowWaterImpl::_cons2prim(torch::Tensor cons, torch::Tensor &prim) {
  apply_conserved_limiter_(cons);

  prim[Index::IDN] = cons[Index::IDN];

  // lvalue view
  auto out = prim.narrow(0, Index::IVX, 3);
  torch::div_out(out, cons.narrow(0, Index::IVX, 3), cons[Index::IDN]);

  pcoord->vec_raise_(prim);

  apply_primitive_limiter_(prim);
}

void ShallowWaterImpl::_prim2cons(torch::Tensor prim, torch::Tensor &cons) {
  apply_primitive_limiter_(prim);

  cons[Index::IDN] = prim[Index::IDN];

  // lvalue view
  auto out = cons.narrow(0, Index::IVX, 3);
  torch::mul_out(out, prim.narrow(0, Index::IVX, 3), prim[Index::IDN]);

  pcoord->vec_lower_(cons);

  apply_conserved_limiter_(cons);
}

torch::Tensor ShallowWaterImpl::_gravity_wave_speed(torch::Tensor prim) const {
  return torch::sqrt(prim[Index::IDN]);
}

}  // namespace snap
