"""
presentation_objs

A wrapper for the spectacle-presentations endpoint.
===========

"""
from .presentation_objs import Presentation
