class JSCompilationError(Exception):
	pass
