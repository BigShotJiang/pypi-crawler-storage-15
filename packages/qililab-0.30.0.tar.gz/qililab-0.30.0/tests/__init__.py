"""__init__.py"""

import os

os.environ["RUNCARDS"] = os.getcwd()
os.environ["DATA"] = os.getcwd()
