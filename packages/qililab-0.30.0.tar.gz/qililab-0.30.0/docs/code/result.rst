ql.result
===============

.. automodule:: qililab.result
