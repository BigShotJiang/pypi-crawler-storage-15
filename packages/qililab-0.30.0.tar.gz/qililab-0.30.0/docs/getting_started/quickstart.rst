Qililab quickstart
==================

.. warning::

    Show users how to quickstart `Qililab` by setting a super basic platform and sending some
    sequences.

    For inspiration take a look at: https://numpy.org/devdocs/user/quickstart.html
