:orphan:

..
    The :orphan: line is needed because this file isn't in any toctree, and otherwise sphinx would
    raise an error.

.. mdinclude:: ../CHANGELOG.md
