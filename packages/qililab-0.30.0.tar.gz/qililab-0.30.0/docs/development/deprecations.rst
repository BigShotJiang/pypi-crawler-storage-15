Deprecations
=================

Pending deprecations
---------------------
- The `path` argument in `qililab.build_platform` will be changed to `runcard`, since now it will not only accept a path to the YAML file but it will also be able to accept the dictionary directly.
    - Deprecated in v0.21
    - Removed in v0.22

Completed deprecation cycles
-----------------------------
