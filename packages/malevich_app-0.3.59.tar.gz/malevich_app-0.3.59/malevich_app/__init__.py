from malevich_app.local.LocalRunner import LocalRunner
from malevich_app.local.log import base_logger_fun
from malevich_app.local.translate import pipeline_translate, cfg_translate
from malevich_app.export.abstract.abstract import LocalRunStruct
