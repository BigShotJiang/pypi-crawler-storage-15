# codestory

**codestory** is a smart CLI wrapper around Git, designed to let developers focus on vibecoding while it handles the rest.  
It analyzes your diffs, groups changes into meaningful commits, and generates descriptive commit messages using local or remote LLMs.  


