from adam.commands.cql.cql_utils import cassandra_keyspaces, cassandra_table_names
from adam.commands.export.exporter import Exporter
from adam.commands.export.exporter_athena import AthenaExporter
from adam.commands.export.utils_export import CopyDatabases
from adam.config import Config
from adam.repl_state import ReplState
from adam.sql.sql_completer import SqlCompleter

def cql_completions(state: ReplState) -> dict[str, any]:
    ps = Config().get('cql.alter-tables.gc-grace-periods', '3600,86400,864000,7776000').split(',')
    # warm up caches
    cassandra_keyspaces(state)
    cassandra_table_names(state)
    CopyDatabases.copy_database_names()
    CopyDatabases.export_database_names()

    return SqlCompleter(
        lambda: cassandra_table_names(state),
        keyspaces=lambda: cassandra_keyspaces(state),
        table_props=lambda: {
            'GC_GRACE_SECONDS': ps
        },
        copies=lambda: CopyDatabases.copy_database_names(),
        exports=lambda: CopyDatabases.export_database_names(),
        copy_sessions=lambda: Exporter.copy_session_names(state.sts, state.pod, state.namespace),
        export_sessions=lambda: AthenaExporter.export_session_names(state),
        variant='cql').completions_for_nesting()