from adam.commands.command import Command
from adam.commands.export.utils_export import drop_copy_dbs
from adam.repl_state import ReplState, RequiredState
from adam.utils_sqlite import SQLite

class DropCopyDatabases(Command):
    COMMAND = 'drop all copy databases'

    # the singleton pattern
    def __new__(cls, *args, **kwargs):
        if not hasattr(cls, 'instance'): cls.instance = super(DropCopyDatabases, cls).__new__(cls)

        return cls.instance

    def __init__(self, successor: Command=None):
        super().__init__(successor)

    def command(self):
        return DropCopyDatabases.COMMAND

    def required(self):
        return [RequiredState.CLUSTER_OR_POD, ReplState.X]

    def run(self, cmd: str, state: ReplState):
        if not(args := self.args(cmd)):
            return super().run(cmd, state)

        state, args = self.apply_state(args, state)
        if not self.validate_state(state):
            return state

        drop_copy_dbs()

        SQLite.clear_cache()

        state.export_session = None

        return state

    def completion(self, state: ReplState):
        # return super().completion(state)
        return {}

    def help(self, _: ReplState):
        return f'{DropCopyDatabases.COMMAND}\t drop all copy databases'