from adam.commands.command import Command
from adam.commands.export.exporter import Exporter
from adam.repl_state import ReplState, RequiredState
from adam.utils import log
from adam.utils_k8s.statefulsets import StatefulSets

class CleanUpCopySessions(Command):
    COMMAND = 'clean up all copy sessions'

    # the singleton pattern
    def __new__(cls, *args, **kwargs):
        if not hasattr(cls, 'instance'): cls.instance = super(CleanUpCopySessions, cls).__new__(cls)

        return cls.instance

    def __init__(self, successor: Command=None):
        super().__init__(successor)

    def command(self):
        return CleanUpCopySessions.COMMAND

    def required(self):
        return RequiredState.CLUSTER_OR_POD

    def run(self, cmd: str, state: ReplState):
        if not(args := self.args(cmd)):
            return super().run(cmd, state)

        state, args = self.apply_state(args, state)
        if not self.validate_state(state):
            return state

        sessions = Exporter.copy_session_names(state.sts, state.pod, state.namespace)
        for session in sessions:
            Exporter.rm_copy_session(state.sts, state.pod, state.namespace, session)
        log(f'Removed {len(sessions)} copy sessions.')

        Exporter.clear_copy_session_cache()

        return state

    def completion(self, state: ReplState):
        return {}
        # pod = state.pod
        # if not pod:
        #     pod = StatefulSets.pod_names(state.sts, state.namespace)[0]
        # return super().completion(state, {session: None for session, _ in Exporter.find_copy_sessions(pod, state.namespace).items()})

    def help(self, _: ReplState):
        return f'{CleanUpCopySessions.COMMAND} <copy/export-db-name>\t clean up copy sessions'