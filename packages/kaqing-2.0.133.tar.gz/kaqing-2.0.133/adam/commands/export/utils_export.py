import io
import os
import re
from typing import Callable
import boto3

from adam.config import Config
from adam.pod_exec_result import PodExecResult
from adam.repl_state import ReplState
from adam.utils import lines_to_tabular, log, log2
from adam.utils_athena import Athena
from adam.utils_k8s.cassandra_nodes import CassandraNodes
from adam.utils_sqlite import SQLite

LIKE = 'e%_%'

def display_export_session(export_session: str):
    if not export_session:
        return

    Athena.clear_cache()

    keyspaces = {}
    for table in CopyDatabases.table_names(export_session):
        keyspace = table.split('.')[0]
        if keyspace in keyspaces:
            keyspaces[keyspace] += 1
        else:
            keyspaces[keyspace] = 1

    log(lines_to_tabular([f'{k},{v}' for k, v in keyspaces.items()], header='SCHEMA,# of TABLES', separator=','))

def drop_copy_dbs(db: str = None):
    dbs = SQLite.database_names(db)
    def delete_db_files():
        try:
            # files_to_delete = glob.glob(f'{SQLite.local_db_dir()}/{db if db else ""}*', recursive=True)

            for db in dbs:
                file_path = f'{SQLite.local_db_dir()}/{db}'
                try:
                    os.remove(file_path)
                    # print(f"Deleted: {file_path}")
                except OSError as e:
                    pass
                    # print(f"Error deleting {file_path}: {e}")
        except:
            pass

    if Config().is_debug():
        delete_db_files()
    else:
        ing(f'Droping {len(dbs)} SQLite databases', delete_db_files)

    return db

def drop_export_dbs(db: str = None):
    dbs = Athena.database_names(f'e{db}_%' if db else LIKE)
    def drop_all_exports():
        for db in dbs:
            query = f'DROP DATABASE {db} CASCADE'
            if Config().is_debug():
                log2(query)
            Athena.query(query)

    if Config().is_debug():
        drop_all_exports()
    else:
        ing(f'Droping {len(dbs)} databases', drop_all_exports)

    def delete_s3_folder():
        try:
            s3 = boto3.resource('s3')
            bucket = s3.Bucket(Config().get('export.bucket', 'c3.ops--qing'))
            bucket.objects.filter(Prefix=f'export/{db}').delete()
        except:
            pass

    if Config().is_debug():
        delete_s3_folder()
    else:
        ing(f'Deleting s3 folder: export', delete_s3_folder)

class CopyDatabases:
    def database_names():
        return CopyDatabases.copy_database_names() + CopyDatabases.export_database_names()

    def copy_database_names():
        return list({n.split('_')[0] for n in SQLite.database_names()})

    def export_database_names():
        return list({n.split('_')[0] for n in Athena.database_names(LIKE)})

    def database_names_with_keyspace_cnt():
        r = {}

        for n in SQLite.database_names() + Athena.database_names(LIKE):
            tokens = n.split('_')
            name = tokens[0]
            keyspace = None
            if len(tokens) > 1:
                keyspace = tokens[1].replace('.db', '')

            if keyspace == 'root':
                continue

            if name in r:
                r[name] += 1
            else:
                r[name] = 1

        return r

    def table_names(session: str):
        tables = []

        for session in CopyDatabases.session_database_names(session):
            if session.startswith('s'):
                for table in SQLite.table_names(database=session):
                    tables.append(f'{SQLite.keyspace(session)}.{table}')
            else:
                for table in Athena.table_names(database=session, function='export'):
                    tables.append(f'{session}.{table}')

        return tables

    def session_database_names(db: str):
        eprefix = db
        if '_' in db:
            eprefix = db.split('_')[0]

        if db.startswith('s'):
            return SQLite.database_names(prefix=f'{eprefix}_')
        else:
            return Athena.database_names(like=f'{eprefix}_%')

class ExportSpec:
    def __init__(self, keyspace: str, consistency: str, tables: list['ExportTableSpec']):
        self.keyspace = keyspace
        self.consistency = consistency
        self.tables = tables

    def parse_specs(specs_str: str):
        keyspace: str = None
        consistency: str = None
        specs: list[ExportTableSpec] = None

        if specs_str:
            keyspace, specs_str = ExportSpec._extract_keyspace(specs_str.strip(' '))
            consistency, specs = ExportSpec._extract_consisteny(specs_str)

        return ExportSpec(keyspace, consistency, specs)

    def _extract_keyspace(spec_str: str) -> tuple[str, str]:
        keyspace = None
        rest = spec_str

        p = re.compile(r"\s*\*\s+in\s+(\S+)(.*)", re.IGNORECASE)
        match = p.match(spec_str)
        if match:
            keyspace = match.group(1).strip(' ')
            rest = match.group(2).strip(' ')
        elif spec_str.startswith('*'):
            keyspace = '*'
            rest = spec_str[1:].strip(' ')

        return keyspace, rest

    def _extract_consisteny(spec_str: str) -> tuple[str, list['ExportTableSpec']]:
        consistency = None

        p = re.compile(r"(.*?)with\s+consistency\s+(.*)", re.IGNORECASE)
        match = p.match(spec_str)
        if match:
            spec_str = match.group(1).strip(' ')
            consistency = match.group(2)

        if spec_str:
            p = r",\s*(?![^()]*\))"
            specs = re.split(p, spec_str)

            return consistency, [ExportTableSpec.parse(spec) for spec in specs]

        return consistency, None

class ExportTableSpec:
    def __init__(self, keyspace: str, table: str, columns: str = None, target_table: str = None):
        self.keyspace = keyspace
        self.table = table
        self.columns = columns
        self.target_table = target_table

    def parse(spec_str: str) -> 'ExportTableSpec':
        target = None

        p = re.compile(r"(.*?)\s+as\s+(.*)", re.IGNORECASE)
        match = p.match(spec_str)
        if match:
            spec_str = match.group(1)
            target = match.group(2)

        table = spec_str
        columns = None

        p = re.compile('(.*?)\.(.*?)\((.*)\)')
        match = p.match(spec_str)
        if match:
            keyspace = match.group(1)
            table = match.group(2)
            columns = match.group(3)
        else:
            p = re.compile('(.*?)\.(.*)')
            match = p.match(spec_str)
            if match:
                keyspace = match.group(1)
                table = match.group(2)

        return ExportTableSpec(keyspace, table, columns, target)

    def __eq__(self, other):
        if isinstance(other, ExportTableSpec):
            return self.keyspace == other.keyspace and self.table == other.table and self.columns == other.columns and self.target_table == other.target_table

        return False

    def __str__(self):
        return f'{self.keyspace}.{self.table}({self.columns}) as {self.target_table}'

class ExportStatus:
    def __init__(self, keyspace: str, table: str, status: str):
        self.keyspace = keyspace
        self.table = table
        self.status = status

    def __str__(self):
        return f'{self.keyspace}.{self.table} = {self.status}'

    def get_copy_status(copy_session: str, state: ReplState, multi_tables = True):
        statuses: list[ExportStatus] = []

        log_files: list[str] = find_files(state.pod, state.namespace, f'/tmp/qing-{copy_session}_*.log*', multi_tables=multi_tables)

        for log_file in log_files:
            s, keyspace, table = ExportStatus.get_status_from_log_file(state.pod, state.namespace, copy_session, log_file, multi_tables=multi_tables)
            statuses.append(ExportStatus(keyspace, table, s))

        return statuses

    def get_status_from_log_file(pod: str, namespace: str, copy_session: str, log_file: str, multi_tables = True):
        temp_dir = Config().get('copy.temp_dir', '/c3/cassandra/tmp')

        m = re.match(f'/tmp/qing-{copy_session}_(.*?)\.(.*?)\.log(.*)', log_file)
        if m:
            keyspace = m.group(1)
            table = m.group(2)
            state = m.group(3)
            if state == '.pending_import':
                return 'pending_import', keyspace, table
            elif state == '.done':
                return 'done', keyspace, table

            # 4 rows exported to 1 files in 0 day, 0 hour, 0 minute, and 1.335 seconds.
            pattern = 'rows exported to'
            r: PodExecResult = CassandraNodes.exec(pod, namespace, f"grep '{pattern}' {log_file}", show_out=not multi_tables, shell='bash')
            if r.exit_code() == 0:
                db = f'{copy_session}_{table}'
                csv_file = f'{temp_dir}/{db}/{table}.csv'
                r = CassandraNodes.exec(pod, namespace, f'ls --color=never {csv_file}', show_out=not multi_tables, shell='bash')
                if r.exit_code() == 0:
                    return 'exported', keyspace, table
                else:
                    return 'imported', keyspace, table
            else:
                return 'export_in_pregress', keyspace, table

        return 'unknown', keyspace, table

def ing(msg: str, body: Callable[[], None], suppress_log=False):
    r = None

    if not suppress_log:
        log2(f'{msg}...', nl=False)
    r = body()
    if not suppress_log:
        log2(' OK')

    return r

def find_files(pod: str, namespace: str, pattern: str, mmin: int = 0, multi_tables = True):
    if mmin:
        r = CassandraNodes.exec(pod, namespace, f'find {pattern} -mmin -{mmin}', show_out=not multi_tables, shell='bash')
    else:
        r = CassandraNodes.exec(pod, namespace, f'find {pattern}', show_out=not multi_tables, shell='bash')

    log_files = []
    for line in r.stdout.split('\n'):
        line = line.strip(' \r')
        if line:
            log_files.append(line)

    return log_files

class GeneratorStream(io.RawIOBase):
    def __init__(self, generator):
        self._generator = generator
        self._buffer = b''  # Buffer to store leftover bytes from generator yields

    def readable(self):
        return True

    def _read_from_generator(self):
        try:
            chunk = next(self._generator)
            if isinstance(chunk, str):
                chunk = chunk.encode('utf-8')  # Encode if generator yields strings
            self._buffer += chunk
        except StopIteration:
            pass  # Generator exhausted

    def readinto(self, b):
        # Fill the buffer if necessary
        while len(self._buffer) < len(b):
            old_buffer_len = len(self._buffer)
            self._read_from_generator()
            if len(self._buffer) == old_buffer_len:  # Generator exhausted and buffer empty
                break

        bytes_to_read = min(len(b), len(self._buffer))
        b[:bytes_to_read] = self._buffer[:bytes_to_read]
        self._buffer = self._buffer[bytes_to_read:]
        return bytes_to_read

    def read(self, size=-1):
        if size == -1:  # Read all remaining data
            while True:
                old_buffer_len = len(self._buffer)
                self._read_from_generator()
                if len(self._buffer) == old_buffer_len:
                    break
            data = self._buffer
            self._buffer = b''
            return data
        else:
            # Ensure enough data in buffer
            while len(self._buffer) < size:
                old_buffer_len = len(self._buffer)
                self._read_from_generator()
                if len(self._buffer) == old_buffer_len:
                    break

            data = self._buffer[:size]
            self._buffer = self._buffer[size:]
            return data