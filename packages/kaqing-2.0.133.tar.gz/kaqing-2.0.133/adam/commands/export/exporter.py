from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
import functools
import os
import re
import sqlite3
import time
import pandas

from adam.commands.cql.cql_utils import cassandra_table_names, run_cql, table_spec
from adam.commands.export.utils_export import ExportSpec, ExportStatus, ExportTableSpec, GeneratorStream, find_files, ing
from adam.config import Config
from adam.pod_exec_result import PodExecResult
from adam.repl_state import ReplState
from adam.utils import elapsed_time, log2
from adam.utils_k8s.cassandra_nodes import CassandraNodes
from adam.utils_k8s.pods import Pods
from adam.utils_k8s.statefulsets import StatefulSets
from adam.utils_sqlite import SQLite

class Exporter:
    def export_tables(args: list[str], state: ReplState, max_workers = 0, export_state = None, export_only = False, kind = 'copy'):
        if not export_state:
            status_in_whole = 'done'

            tables = []
            for s in ExportStatus.get_copy_status(state.export_session, state, True):
                status: ExportStatus = s
                tables.append(ExportTableSpec(status.keyspace, status.table, target_table=status.table))
                if status.status != 'done':
                    status_in_whole = status.status

            if status_in_whole == 'done':
                log2(f'The session has been completely done. No further action was executed.')
                return []

            spec = ExportSpec(None, None, tables=tables)
        else:
            spec: ExportSpec = ExportSpec.parse_specs(' '.join(args))

        if not spec.keyspace:
            spec.keyspace = f'{state.namespace}_db'

        if not spec.tables:
            spec.tables = [ExportTableSpec.parse(t) for t in cassandra_table_names(state, keyspace=spec.keyspace)]

        if not max_workers:
            max_workers = Config().action_workers(kind, 8)

        if max_workers > 1 and len(spec.tables) > 1:
            log2(f'Executing on {len(spec.tables)} Cassandra tables in parallel...')
            start_time = time.time()
            try:
                with ThreadPoolExecutor(max_workers=max_workers) as executor:
                    futures = [executor.submit(Exporter.export_table, table, state, True, consistency=spec.consistency, export_state=export_state, export_only=export_only) for table in spec.tables]
                    if len(futures) == 0:
                        return []

                return [future.result() for future in as_completed(futures)]
            finally:
                log2(f"{len(spec.tables)} parallel table export elapsed time: {elapsed_time(start_time)} with {max_workers} workers")
        else:
            return [Exporter.export_table(table, state, multi_tables=len(spec.tables) > 1, consistency=spec.consistency, export_state=export_state, export_only=export_only) for table in spec.tables]

    def export_table(spec: ExportTableSpec, state: ReplState, multi_tables = True, consistency: str = None, export_state=None, export_only=False):
        s: str = None

        table, target_table, columns = Exporter.resove_table_n_columns(spec, state, include_ks_in_target=False, kind='copy')
        log_file = f'/tmp/qing-{state.export_session}_{spec.keyspace}.{target_table}.log'
        if export_state == 'init':
            Exporter.copy_table_create_log(spec, state, multi_tables=multi_tables)
        else:
            if export_state == 'pending_export':
                Exporter.export_to_csv(spec, state, multi_tables=multi_tables, consistency=consistency)

            log_files: list[str] = find_files(state.pod, state.namespace, f'{log_file}*', multi_tables=multi_tables)
            if not log_files:
                return s

            log_file = log_files[0]

            s, keyspace, table = ExportStatus.get_status_from_log_file(state.pod, state.namespace, state.export_session, log_file, multi_tables=multi_tables)
            while s != 'done':
                if s == 'export_in_pregress':
                    time.sleep(1)
                elif s == 'exported':
                    log_file = Exporter.rename_to_pending_import(spec, state, multi_tables=multi_tables)
                    if export_only:
                        return s
                elif s == 'pending_import':
                    log_file = Exporter.import_to_sqlite(spec, state, multi_tables=multi_tables)
                elif s == 'exported':
                    log_file = Exporter.rename_to_done(spec, state, multi_tables=multi_tables)

                s, keyspace, table = ExportStatus.get_status_from_log_file(state.pod, state.namespace, state.export_session, log_file, multi_tables=multi_tables)

        return s

    def copy_table_create_log(spec: ExportTableSpec, state: ReplState, multi_tables = True):
        if not state.export_session:
            state.export_session = f's{datetime.now().strftime("%Y%m%d%H%M%S")[3:]}'

        table, target_table, columns = Exporter.resove_table_n_columns(spec, state, include_ks_in_target=False, kind='copy')

        log_file = f'/tmp/qing-{state.export_session}_{spec.keyspace}.{target_table}.log'

        CassandraNodes.exec(state.pod, state.namespace, f'rm -f {log_file}* && touch {log_file}', show_out=not multi_tables, shell='bash')

        return table

    def export_to_csv(spec: ExportTableSpec, state: ReplState, multi_tables = True, consistency: str = None):
        table, target_table, columns = Exporter.resove_table_n_columns(spec, state, include_ks_in_target=False, kind='copy')

        temp_dir = Config().get('copy.temp_dir', '/c3/cassandra/tmp')
        db = f'{state.export_session}_{target_table}'

        CassandraNodes.exec(state.pod, state.namespace, f'mkdir -p {temp_dir}/{db}', show_out=not multi_tables, shell='bash')
        csv_file = f'{temp_dir}/{db}/{table}.csv'
        log_file = f'/tmp/qing-{state.export_session}_{spec.keyspace}.{target_table}.log'

        suppress_ing_log = Config().is_debug() or multi_tables
        queries = []
        if consistency:
            queries.append(f'CONSISTENCY {consistency}')
        queries.append(f"COPY {spec.keyspace}.{table}({columns}) TO '{csv_file}' WITH HEADER = TRUE")
        r: PodExecResult = ing(f'Dumping table {spec.keyspace}.{table}{f" with consistency {consistency}" if consistency else ""}',
            lambda: run_cql(state, ';'.join(queries), show_out=Config().is_debug(), background=True, log_file=log_file),
            suppress_log=suppress_ing_log)

        return log_file

    def rename_to_pending_import(spec: ExportTableSpec, state: ReplState, multi_tables = True):
        table, target_table, columns = Exporter.resove_table_n_columns(spec, state, include_ks_in_target=False, kind='copy')

        log_file = f'/tmp/qing-{state.export_session}_{spec.keyspace}.{target_table}.log'
        to = f'{log_file}.pending_import'

        CassandraNodes.exec(state.pod, state.namespace, f'mv {log_file} {to}', show_out=not multi_tables, shell='bash')

        return to

    def import_to_sqlite(spec: ExportTableSpec, state: ReplState, multi_tables = True):
        table, target_table, columns = Exporter.resove_table_n_columns(spec, state, include_ks_in_target=False, kind='copy')

        temp_dir = Config().get('copy.temp_dir', '/c3/cassandra/tmp')
        db = f'{state.export_session}_{spec.keyspace}'
        csv_file = f'{temp_dir}/{state.export_session}_{target_table}/{table}.csv'

        succeeded = False
        conn = None
        suppress_ing_log = Config().is_debug() or multi_tables
        try:
            # TODO /tmp ok?
            os.makedirs(SQLite.local_db_dir(), exist_ok=True)
            conn = sqlite3.connect(f'{SQLite.local_db_dir()}/{db}.db')

            def upload_to_sqlite():
                bytes = Pods.read_file(state.pod, 'cassandra', state.namespace, csv_file)
                df = pandas.read_csv(GeneratorStream(bytes))

                df.to_sql(target_table, conn, index=False, if_exists='replace')

            ing(f'Uploading to Sqlite', upload_to_sqlite, suppress_log=suppress_ing_log)

            # log_file = f'/tmp/qing-{state.export_session}_{spec.keyspace}.{target_table}.log.exported'
            # to = log_file.replace('.log.exported', '.log.imported')
            # CassandraNodes.exec(state.pod, state.namespace, f'mv {log_file} {to}', show_out=not multi_tables, shell='bash')

            log_file = f'/tmp/qing-{state.export_session}_{spec.keyspace}.{target_table}.log.pending_import'
            to = log_file.replace('.log.pending_import', '.log.done')

            CassandraNodes.exec(state.pod, state.namespace, f'mv {log_file} {to}', show_out=not multi_tables, shell='bash')

            succeeded = True

            return to
        finally:
            if succeeded:
                SQLite.clear_cache()

                if not suppress_ing_log:
                    query = f'select * from {target_table} limit 10'
                    log2(query)
                    SQLite.run_query(conn, query)

            if conn:
                conn.close()

    def rename_to_done(spec: ExportTableSpec, state: ReplState, multi_tables = True):
        table, target_table, columns = Exporter.resove_table_n_columns(spec, state, include_ks_in_target=False, kind='copy')

        log_file = f'/tmp/qing-{state.export_session}_{spec.keyspace}.{target_table}.log.pending_import'
        to = log_file.replace('.log.pending_import', '.log.done')

        CassandraNodes.exec(state.pod, state.namespace, f'mv {log_file} {to}', show_out=not multi_tables, shell='bash')

        return to

    def clear_copy_session_cache():
        Exporter.find_copy_sessions.cache_clear()
        Exporter.copy_session_names.cache_clear()

    @functools.lru_cache()
    def copy_session_names(sts: str, pod: str, namespace: str):
        if not sts or not namespace:
            return []

        if not pod:
            pod = StatefulSets.pod_names(sts, namespace)[0]

        if not pod:
            return []

        return [session for session, _ in Exporter.find_copy_sessions(pod, namespace).items()]

    @functools.lru_cache()
    def find_copy_sessions(pod: str, namespace: str, limit=100, multi_tables = True):
        sessions: dict[str, bool] = {}

        def filter(log_file: list[str], done: bool):
            cnt = 0
            for log_file in log_file:
                # /tmp/qing-s51126144721_azops88_db.analyticscontainer_dfeevalhistory.log
                m = re.match(f'/tmp/qing-(.*?)_.*', log_file)
                if m:
                    s = m.group(1)
                    if s not in sessions:
                        sessions[s] = done
                    elif not done:
                        sessions[s] = done

                    cnt += 1
                    if cnt >= limit:
                        break

        log_files: list[str] = find_files(pod, namespace, '/tmp/qing-*_*.log', multi_tables=multi_tables)
        filter(log_files, False)
        log_files = find_files(pod, namespace, '/tmp/qing-*_*.log.pending_import', multi_tables=multi_tables)
        filter(log_files, False)
        log_files = find_files(pod, namespace, '/tmp/qing-*_*.log.done', multi_tables=multi_tables)
        filter(log_files, True)

        return sessions

    def rm_copy_session(sts: str, pod: str, namespace: str, copy_session: str, multi_tables = True):
        if not sts or not namespace:
            return 0, 0

        if not pod:
            pod = StatefulSets.pod_names(sts, namespace)[0]

        if not pod:
            return 0, 0

        csv_cnt = 0
        log_cnt = 0

        log_files: list[str] = find_files(pod, namespace, f'/tmp/qing-{copy_session}_*.log*', multi_tables=multi_tables)

        temp_dir = Config().get('copy.temp_dir', '/c3/cassandra/tmp')

        for log_file in log_files:
            m = re.match(f'/tmp/qing-{copy_session}_(.*?)\.(.*?)\.log.*', log_file)
            if m:
                table = m.group(2)

                db = f'{copy_session}_{table}'
                CassandraNodes.exec(pod, namespace, f'rm -rf {temp_dir}/{db}', show_out=not multi_tables, shell='bash')
                csv_cnt += 1

                CassandraNodes.exec(pod, namespace, f'rm -rf {log_file}', show_out=not multi_tables, shell='bash')
                log_cnt += 1

        return csv_cnt, log_cnt

    def resove_table_n_columns(spec: ExportTableSpec, state: ReplState, include_ks_in_target = False, kind = 'export'):
        table = spec.table
        columns = spec.columns
        if not columns:
            columns = Config().get(f'{kind}.columns', f'<keys>')

        keyspaced_table = f'{spec.keyspace}.{spec.table}'
        if columns == '<keys>':
            columns = ','.join(table_spec(state, keyspaced_table, on_any=True).keys())
        elif columns == '<row-key>':
            columns = table_spec(state, keyspaced_table, on_any=True).row_key()
        elif columns == '*':
            columns = ','.join([c.name for c in table_spec(state, keyspaced_table, on_any=True).columns])

        if not columns:
            log2(f'ERROR: Empty columns on {table}.')
            return table, None, None

        target_table = spec.target_table if spec.target_table else table
        if not include_ks_in_target and '.' in target_table:
            target_table = target_table.split('.')[-1]

        return table, target_table, columns

# def ing(msg: str, body: Callable[[], None], suppress_log=False):
#     r = None

#     if not suppress_log:
#         log2(f'{msg}...', nl=False)
#     r = body()
#     if not suppress_log:
#         log2(' OK')

#     return r

# class GeneratorStream(io.RawIOBase):
#     def __init__(self, generator):
#         self._generator = generator
#         self._buffer = b''  # Buffer to store leftover bytes from generator yields

#     def readable(self):
#         return True

#     def _read_from_generator(self):
#         try:
#             chunk = next(self._generator)
#             if isinstance(chunk, str):
#                 chunk = chunk.encode('utf-8')  # Encode if generator yields strings
#             self._buffer += chunk
#         except StopIteration:
#             pass  # Generator exhausted

#     def readinto(self, b):
#         # Fill the buffer if necessary
#         while len(self._buffer) < len(b):
#             old_buffer_len = len(self._buffer)
#             self._read_from_generator()
#             if len(self._buffer) == old_buffer_len:  # Generator exhausted and buffer empty
#                 break

#         bytes_to_read = min(len(b), len(self._buffer))
#         b[:bytes_to_read] = self._buffer[:bytes_to_read]
#         self._buffer = self._buffer[bytes_to_read:]
#         return bytes_to_read

#     def read(self, size=-1):
#         if size == -1:  # Read all remaining data
#             while True:
#                 old_buffer_len = len(self._buffer)
#                 self._read_from_generator()
#                 if len(self._buffer) == old_buffer_len:
#                     break
#             data = self._buffer
#             self._buffer = b''
#             return data
#         else:
#             # Ensure enough data in buffer
#             while len(self._buffer) < size:
#                 old_buffer_len = len(self._buffer)
#                 self._read_from_generator()
#                 if len(self._buffer) == old_buffer_len:
#                     break

#             data = self._buffer[:size]
#             self._buffer = self._buffer[size:]
#             return data