from adam.commands.command import Command
from adam.commands.export.utils_export import CopyDatabases
from adam.repl_state import ReplState, RequiredState
from adam.sql.sql_completer import SqlCompleter
from adam.utils import log2
from adam.utils_athena import Athena
from adam.utils_sqlite import SQLite

class ExportSelect(Command):
    COMMAND = '.select'

    # the singleton pattern
    def __new__(cls, *args, **kwargs):
        if not hasattr(cls, 'instance'): cls.instance = super(ExportSelect, cls).__new__(cls)

        return cls.instance

    def __init__(self, successor: Command=None):
        super().__init__(successor)

    def command(self):
        return ExportSelect.COMMAND

    def required(self):
        return [RequiredState.CLUSTER_OR_POD, ReplState.X]

    def run(self, cmd: str, state: ReplState):
        if not(args := self.args(cmd)):
            return super().run(cmd, state)

        state, args = self.apply_state(args, state)
        if not self.validate_state(state):
            return state

        if not state.export_session:
            if state.in_repl:
                if state.device == ReplState.C:
                    log2("Select a copy/export database first with 'use' command.")
                else:
                    log2('cd to a copy/export database first.')
            else:
                log2('* copy/export database is missing.')

                Command.display_help()

            return 'command-missing'

        if not args:
            if state.in_repl:
                log2('Use a SQL statement.')
            else:
                log2('* SQL statement is missing.')

                Command.display_help()

            return 'command-missing'

        query = ' '.join(args)

        if state.export_session.startswith('s'):
            conn = None
            try:
                conn = SQLite.connect(state.export_session)
                state.copy_session = conn

                SQLite.run_query(conn, f'select {query}')
            finally:
                if conn:
                    conn.close()
        else:
            Athena.run_query(f'select {query}', database=state.export_session)

        return state

    def completion(self, state: ReplState):
        if not state.export_session:
            return {}

        db = state.export_session

        # warm up the caches first time when x: drive is accessed
        CopyDatabases.table_names(db)
        Athena.column_names(database=db, function='export')
        Athena.column_names(partition_cols_only=True, database=db, function='export')

        return {ExportSelect.COMMAND: SqlCompleter(
            lambda: CopyDatabases.table_names(db),
            dml='select',
            columns=lambda table: Athena.column_names(database=db, function='export'),
            variant='athena'
        )}

    def help(self, _: ReplState):
        return f'.<sql-select-statements>\t run queries on copy/export database'