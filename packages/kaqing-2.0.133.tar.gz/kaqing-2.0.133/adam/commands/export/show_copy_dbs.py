from adam.commands.command import Command
from adam.commands.devices.device_export import DeviceExport
from adam.repl_state import ReplState, RequiredState

class ShowCopyDatabases(Command):
    COMMAND = 'show copy databases'

    # the singleton pattern
    def __new__(cls, *args, **kwargs):
        if not hasattr(cls, 'instance'): cls.instance = super(ShowCopyDatabases, cls).__new__(cls)

        return cls.instance

    def __init__(self, successor: Command=None):
        super().__init__(successor)

    def command(self):
        return ShowCopyDatabases.COMMAND

    def required(self):
        return RequiredState.CLUSTER_OR_POD

    def run(self, cmd: str, state: ReplState):
        if not(args := self.args(cmd)):
            return super().run(cmd, state)

        state, args = self.apply_state(args, state)
        if not self.validate_state(state):
            return state

        if state.export_session:
            state.push()
            state.export_session = None
        try:
            DeviceExport().ls(cmd, state)
        finally:
            state.pop()

        return state

    def completion(self, state: ReplState):
        return DeviceExport().ls_completion(ShowCopyDatabases.COMMAND, state, default = super().completion(state))

    def help(self, _: ReplState):
        return f'{ShowCopyDatabases.COMMAND}\t list copy/export databases'