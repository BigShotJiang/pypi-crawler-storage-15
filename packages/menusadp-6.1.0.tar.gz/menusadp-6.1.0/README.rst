========
MenusADP
========

Vins et Menus

* Free software: MIT license

Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ 

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
