"""VexShield - Comprehensive supply chain security platform."""

__version__ = "0.1.0"
