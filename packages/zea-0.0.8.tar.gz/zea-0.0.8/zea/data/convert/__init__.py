"""Data conversion of datasets to the ``zea`` data format."""
