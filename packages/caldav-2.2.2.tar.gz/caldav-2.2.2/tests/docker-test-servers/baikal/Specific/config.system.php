<?php
##############################################################################
# Baikal System configuration
##############################################################################

# Server URL
define("BAIKAL_SERVER_BASEURL", "");

# Server NAME
define("BAIKAL_SERVER_FRIENDLYNAME", "Baikal Test Server");

# Enable password reset
define("BAIKAL_ADMIN_PASSWORDRESET_ENABLE", FALSE);
