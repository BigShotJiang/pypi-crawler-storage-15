=============
How-To Guides
=============

Sorry, nothing here yet

.. todo::

   * Make a how-to on how to create a local backup and syncing it.  (procrastinated until the ``get_calendar`` function is completed)
   * Make how-tos on each known calendar server and/or service provider - including known incompatibilities.  Some information in the `about.rst`, should be moved here
   * Particularly Google.

   See also https://github.com/python-caldav/caldav/issues/513
