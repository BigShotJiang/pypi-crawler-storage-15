:mod:`DAVClient` -- A simple DAV client
=======================================

.. automodule:: caldav.davclient
   :synopsis: Class for storing server connection details
   :members:
