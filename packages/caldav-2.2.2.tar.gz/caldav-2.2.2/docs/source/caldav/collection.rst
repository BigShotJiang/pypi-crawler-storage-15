:mod:`collection` -- Calendars, calendar sets, mailboxes and principal
======================================================================

.. automodule:: caldav.collection
   :synopsis: Collection classes and principal
   :members:
