:mod:`davobject` -- Base object definition
==========================================

.. automodule:: caldav.davobject
   :synopsis: Base DAVObject class
   :members:
