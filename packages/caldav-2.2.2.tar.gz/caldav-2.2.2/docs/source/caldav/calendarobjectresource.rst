:mod:`calendarobjectresource` -- Calendar Object Resources (Todo, Event, Journal, FreeBusy)
===========================================================================================

.. automodule:: caldav.calendarobjectresource
   :synopsis: Calendar Object Resources (Events etc)
   :members:
