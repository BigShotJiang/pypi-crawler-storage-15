Reach out through GitHub issues or email caldav@plann.no.  If you feel ignored, be aware that messages sometimes are drowned in spam or forgotten about because I had more urgent issues to handle.  Urgent issues may be escalated by reaching out through +47-91700050 or @tobixen on different alternative communication services.  Please keep in mind that things like providing food to the table for himself and the family typially will have a higher priority than fiddling with the calendaring projects for free on a hobby basis.

See also the contacts document in the documentation.
