"""
Spark Connection Strategies

This module provides different strategies for connecting to Spark clusters.
Uses the strategy pattern for flexible platform support.
"""

from dbt.compute.strategies.base import BaseConnectionStrategy
from dbt.compute.strategies.local import LocalStrategy
from dbt.compute.strategies.databricks import DatabricksStrategy

__all__ = ["BaseConnectionStrategy", "LocalStrategy", "DatabricksStrategy"]
