from crunch_uml.cli import main

__all__ = [
    "main",
]
