# Meridian

**Heroku for ML Features.**

Meridian is a developer-first feature store designed to take you from a Jupyter notebook to production in 30 seconds.

## Quickstart

```bash
pip install meridian
```

See the [README](https://github.com/davidahmann/meridian) for more details.
