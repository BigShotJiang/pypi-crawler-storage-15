Frontend for the single_product_transfer scenario in shopfloor.
