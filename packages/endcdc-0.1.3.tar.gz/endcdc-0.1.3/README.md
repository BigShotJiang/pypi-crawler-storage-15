# endcdc

This package contains seven deep-learning exercise scripts wrapped as Python functions:

- get1()
- get2()
- get3()
- get45()
- get7()

After installation:

```python
import endcdc
endcdc.get1()
endcdc.get2()
endcdc.get3()
endcdc.get45()
endcdc.get7()
