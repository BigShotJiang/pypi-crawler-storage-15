from .ex1 import get1
from .ex2 import get2
from .ex3 import get3
from .ex45 import get45
from .ex7 import get7

__all__ = ["get1", "get2", "get3", "get45", "get7"]