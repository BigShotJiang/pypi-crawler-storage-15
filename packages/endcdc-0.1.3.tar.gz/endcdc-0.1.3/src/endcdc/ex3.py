EX3 = r"""
print("Task 1 - Message Passing System:")

print("client.py")

import socket
import threading

HOST = '127.0.0.1' 
PORT = 65432        

def receive_messages(client_socket):

    try:
        while True:
            message = client_socket.recv(1024).decode('utf-8')
            if message:
                print(message)
            else:
                break
    except Exception as e:
        print(f"[ERROR] Disconnected from server: {e}")
    finally:
        client_socket.close()

def send_messages(client_socket):

    try:
        while True:
            message = input()
            if message:
                client_socket.send(message.encode('utf-8'))
    except (KeyboardInterrupt, EOFError):
        print("\n[EXITING] You have left the chat.")
    finally:
        client_socket.close()

def start_client():

    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        client.connect((HOST, PORT))
        print(f"Connected to the server at {HOST}:{PORT}. You can start typing.")
    except ConnectionRefusedError:
        print("[ERROR] Connection refused. Is the server running?")
        return

    receive_thread = threading.Thread(target=receive_messages, args=(client,))
    receive_thread.daemon = True 

    send_messages(client)


if __name__ == "__main__":
    start_client()

print("server.py")

import socket
import threading

HOST = '127.0.0.1'  
PORT = 65432        

clients = []
lock = threading.Lock()

def broadcast(message, sender_socket):
    with lock:
        for client in clients:
            if client != sender_socket:
                try:
                    client.send(message)
                except:
                
                    client.close()
                    clients.remove(client)

def handle_client(client_socket, addr):
    print(f"[NEW CONNECTION] {addr} connected.")
    
    with lock:
        clients.append(client_socket)

    try:
        while True:
            message = client_socket.recv(1024)
            if not message:
                break

            sender_info = f"[{addr[0]}:{addr[1]}]: ".encode('utf-8')
            full_message = sender_info + message
            
            print(f"Received from {addr}: {message.decode('utf-8')}")
            broadcast(full_message, client_socket)
            
    except Exception as e:
        print(f"[ERROR] {e}")
    finally:
        print(f"[DISCONNECTED] {addr} disconnected.")
        with lock:
            if client_socket in clients:
                clients.remove(client_socket)
        client_socket.close()

def start_server():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((HOST, PORT))
    server.listen()
    print(f"[LISTENING] Server is listening on {HOST}:{PORT}")

    try:
        while True:
            client_socket, addr = server.accept()
            thread = threading.Thread(target=handle_client, args=(client_socket, addr))
            thread.start()
    except KeyboardInterrupt:
        print("\n[SHUTTING DOWN] Server is shutting down.")
    finally:
        server.close()

if __name__ == "__main__":
    start_server()

print("Task 2 - Distributed Mutual Exclusion:")

print("coordinator.py")
import queue
import threading
import time

class Coordinator:
    def __init__(self):
        self.locked = False
        self.waiting = queue.Queue()
        self.condition = threading.Condition()

    def enter_cs(self, proc_id):
        with self.condition:
            if not self.locked:
                self.locked = True
                print(f"Coordinator -> Grants CS to Process {proc_id}")
                return
            else:
                print(f"Coordinator -> Process {proc_id} queued")
                self.waiting.put(proc_id)
                while self.locked or self.waiting.queue[0] != proc_id:
                    self.condition.wait()
                self.waiting.get()
                self.locked = True
                print(f"Coordinator -> Grants CS to Process {proc_id}")

    def leave_cs(self, proc_id):
        with self.condition:
            print(f"Process {proc_id} released CS")
            self.locked = False
            self.condition.notify_all() 

def process_func(proc_id, coord: Coordinator):
    time.sleep(proc_id)   

    coord.enter_cs(proc_id)  
    print(f"Process {proc_id} in CS")
    time.sleep(2)           
    coord.leave_cs(proc_id)   

if __name__ == "__main__":
    coord = Coordinator()
    threads = [threading.Thread(target=process_func, args=(i, coord)) for i in range(3)]

    for t in threads:
        t.start()
    for t in threads:
        t.join()
        
print("ricart.py")

import threading
import time

class Process:
    def __init__(self, pid, n):
        self.pid = pid
        self.n = n
        self.clock = 0
        self.requesting = False
        self.replies = 0

    def request_cs(self, processes):
        self.requesting = True
        self.clock += 1
        ts = self.clock
        print(f"Process {self.pid} requests CS at time {ts}")

        for p in processes:
            if p.pid != self.pid:
                p.receive_request(self.pid, ts, self)

        while self.replies < self.n - 1:
            time.sleep(0.5)

        print(f"Process {self.pid} ENTERS CS")
        time.sleep(2)
        self.release_cs(processes)

    def receive_request(self, pid, ts, requester):
        self.clock = max(self.clock, ts) + 1
        if (not self.requesting) or (ts < self.clock) or (ts == self.clock and pid < self.pid):
            requester.receive_reply(self.pid)

    def receive_reply(self, from_pid):
        self.replies += 1

    def release_cs(self, processes):
        print(f"Process {self.pid} RELEASES CS")
        self.requesting = False
        self.replies = 0

def run_process(p, processes):
    time.sleep(p.pid)
    p.request_cs(processes)

if __name__ == "__main__":
    n = 3
    processes = [Process(i, n) for i in range(n)]
    threads = [threading.Thread(target=run_process, args=(p, processes)) for p in processes]

    for t in threads: t.start()
    for t in threads: t.join()
print("tokenring.py")

import threading
import time

class TokenRing:
    def __init__(self, n):
        self.n = n
        self.token_holder = 0
        self.lock = threading.Lock()

    def request_cs(self, pid):
        while True:
            with self.lock:
                if self.token_holder == pid:
                    print(f"Process {pid} ENTERS CS")
                    time.sleep(2)
                    print(f"Process {pid} RELEASES CS")
                    self.token_holder = (pid + 1) % self.n
                    break
            time.sleep(0.5)

def process_func(pid, ring: TokenRing):
    time.sleep(pid)
    ring.request_cs(pid)

if __name__ == "__main__":
    n = 3
    ring = TokenRing(n)
    threads = [threading.Thread(target=process_func, args=(i, ring)) for i in range(n)]

    for t in threads: t.start()
    for t in threads: t.join()

"""
def get3():
    print(EX3)