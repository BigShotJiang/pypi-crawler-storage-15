EX45 = r"""
Step 1: Prepare VMware Setup

You’ll need 3 Ubuntu VMs (can use Ubuntu Server 22.04 or Desktop, but Server is lighter):

Admin VM → for scheduling tasks + load balancer.
VM1 → worker node 1.
VM2 → worker node 2.
Create the VMs

In VMware Workstation/Player, click Create a New Virtual Machine.
Select Ubuntu ISO.
Allocate 1–2 cores, 2GB RAM, 20GB disk per VM.
Clone or create 3 separate VMs (Admin, VM1, VM2).
🔹 Step 2: Configure Networking

The VMs must “see” each other.

In VMware → Edit Virtual Machine Settings → Network Adapter.
Choose Bridged (same LAN as host) OR NAT (all share host’s internet).
If you’re just testing inside VMware, NAT works fine.
Boot each VM and check IP:
Step 3: Configure Hostnames

On each VM:

sudo hostnamectl set-hostname <name>

Admin VM → admin
VM1 → vm1
VM2 → vm2
exec bash🡪name will be changed(ubuntu@ubuntu to ubuntu@name)

In all the three vm’s change the passwords(passwords should be the same)(sudo passwd ubuntu)

In vm1 and vm2 do these:

sudo apt update

sudo apt install openssh-server -y🡪a window will open in that keep the default version and press enter

sudo systemctl enable ssh

sudo systemctl start ssh

Check service:

systemctl status ssh

now press q to end

I n admin : Sudo apt install gedit

🔹 Step 5: Configure /etc/hosts on Admin VM

Edit hosts file:

sudo gedit /etc/hosts

a file will open after this🡪in third line press enter

after pressing enter

Add (replace with your actual IPs):(hostname -I)

192.168.111.129 vm1

192.168.111.130 vm2

Save and close the file

🔹 Step 6: Setup SSH Keys

On Admin VM:

ssh-keygen -t rsa -b 4096🡪(always press enter for all the questions)

ssh-copy-id ubuntu@vm1-->(press yes and enter password)

ssh-copy-id ubuntu@vm2-->(press yes and enter password)

(Replace ubuntu with your VM username if different.)

ssh vm1 hostname

ssh vm2 hostname

🔹 Step 7: Task Scheduling with Cron

On Admin VM:

crontab -e

(select 1)

Use arrow and come down

ex

Add:

*/1 * * * * ssh vm1 'date >> /home/ubuntu/cloud_task.log'

*/1 * * * * ssh vm2 'date >> /home/ubuntu/cloud_task.log'

After typing all this Ctrl O then enter then ctrl x

➡ This will append the date every minute to log files on VM1 & VM2.

Check after a few minutes:

ssh vm1 'cat /home/ubuntu/cloud_task.log'

ssh vm2 'cat /home/ubuntu/cloud_task.log'

✅ If you see timestamps growing, scheduling works.

ad

🔹 Step 8: Load Balancing with HAProxy

On Admin VM:

sudo apt update

sudo apt install haproxy -y

Edit config:

sudo nano /etc/haproxy/haproxy.cfg

Append:

frontend http_front

bind *:80

default_backend http_back

backend http_back

balance roundrobin

server web1 192.168.111.129:80 check

server web2 192.168.111.130:80 check

Restart service:

sudo systemctl restart haproxy

🔹 Step 9: Setup Web Servers on VM1 & VM2

On VM1 & VM2:

sudo apt install apache2 -y

echo "Hello from VM1" | sudo tee /var/www/html/index.html

On VM2 do:

echo "Hello from VM2" | sudo tee /var/www/html/index.html

🔹 Step 10: Test Load Balancer

From your host machine browser:

http://192.168.111.128

First refresh → Hello from VM1
Second refresh → Hello from VM2
Keeps alternating (round robin).
"""
def get45():
    print(EX45)