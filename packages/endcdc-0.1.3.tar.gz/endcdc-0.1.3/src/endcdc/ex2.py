EX2 = r"""
print("Remote Method Invocation (RMI)")

print("client.py")
import Pyro4

def main():

    uri = input("Enter the server URI: ").strip()

    try:
        calculator = Pyro4.Proxy(uri)

        num1 = float(input("Enter the first number: "))
        num2 = float(input("Enter the second number: "))
        sum_result = calculator.add_numbers(num1, num2)
        product_result = calculator.multiply(num1, num2)
        print(f"\nResult of addition: {num1} + {num2} = {sum_result}")
        print(f"Result of multiplication: {num1} * {num2} = {product_result}")

    except Pyro4.errors.CommunicationError as e:
        print(f"\nError: Could not connect to the server.")
        print(f"Please check if the URI is correct and the server is running.")
        print(f"Details: {e}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

if __name__ == "__main__":
    main()

print("server.py")

import Pyro4

@Pyro4.expose
class Calculator:

    def add_numbers(self, num1, num2):
        print(f"Server received an add request: {num1} + {num2}")
        return num1 + num2

    def multiply(self, num1, num2):
        print(f"Server received a multiply request: {num1} * {num2}")
        return num1 * num2

def main():
    daemon = Pyro4.Daemon()

    uri = daemon.register(Calculator)
    print("Server is ready. Object URI =", uri)
    print("Listening for incoming requests...")
    daemon.requestLoop()

if __name__ == "__main__":
    main()

"""
def get2():
    print(EX2)