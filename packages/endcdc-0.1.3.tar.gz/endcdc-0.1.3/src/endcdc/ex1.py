EX1 = r"""
print("Task 1 - Setup Basic Client-Server Communication:")
print("client.py")
import socket

def start_client(host="127.0.0.1", port=65432):
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect((host, port))  

    message = input("Enter numbers separated by spaces: ")
    client_socket.sendall(message.encode()) 

    response = client_socket.recv(1024).decode()
    print(f"Server response: {response}")

    client_socket.close()

if __name__ == "__main__":
    start_client()

print("server.py")

import socket

def start_server(host="127.0.0.1", port=65432):
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((host, port))
    server_socket.listen(1)
    print(f"Server listening on {host}:{port}...")

    conn, addr = server_socket.accept()
    print(f"Connected by {addr}")

    data = conn.recv(1024).decode()
    if data:
        try:
            numbers = list(map(int, data.split()))
            result = sum(numbers)
            response = f"Sum = {result}"
        except ValueError:
            response = "Error: Please send valid integers separated by spaces."
        conn.sendall(response.encode())

    conn.close()
    server_socket.close()   
    
if __name__ == "__main__":
    start_server()

print("Task 2 - Enhanced Communication with Object Serialization:")
print("client.py")

import socket
import pickle

class DataObject:
    def __init__(self, name, values, message=None):
        self.name = name
        self.values = values
        self.message = message

def start_client(host="127.0.0.1", port=65432):
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect((host, port))

    name = input("Enter your name: ")
    values = list(map(int, input("Enter numbers separated by spaces: ").split()))
    obj = DataObject(name=name, values=values)

    client_socket.sendall(pickle.dumps(obj))

    data = client_socket.recv(4096)
    response_obj = pickle.loads(data)

    print(f"Server ({response_obj.name}) says: {response_obj.message}")
    print(f"Returned values: {response_obj.values}")

    client_socket.close()

if __name__ == "__main__":
    start_client()

print("server.py")
import socket
import pickle

class DataObject:
    def __init__(self, name, values, message=None):
        self.name = name
        self.values = values
        self.message = message

def start_server(host="127.0.0.1", port=65432):
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((host, port))
    server_socket.listen(1)
    print(f"Server listening on {host}:{port}...")

    while True:
        conn, addr = server_socket.accept()
        print(f"Connected by {addr}")

        data = conn.recv(4096)
        if not data:
            break

        obj = pickle.loads(data)
        print(f"Received object: name={obj.name}, values={obj.values}")
        result = sum(obj.values)

        response_obj = DataObject(
            name="Server",
            values=[result],
            message=f"Hello {obj.name}, the sum of your numbers is {result}"
        )

        conn.sendall(pickle.dumps(response_obj))

        conn.close()

if __name__ == "__main__":
    start_server()


"""
def get1():
    print(EX1)