EX7 = r"""
print("Lamport's Logical Clock Implementation")

class Process:
    def __init__(self, pid):
        self.pid = pid
        self.clock = 0

    def internal_event(self, event_name):
        self.clock += 1
        print(f"[Process {self.pid}] Internal Event '{event_name}' -> Clock = {self.clock}")

    def send_message(self, receiver, message):
        self.clock += 1
        timestamp = self.clock
        print(f"[Process {self.pid}] Sending '{message}' to Process {receiver.pid} (ts={timestamp})")
        receiver.receive_message(self.pid, message, timestamp)

    def receive_message(self, sender_pid, message, timestamp):
        self.clock = max(self.clock, timestamp) + 1
        print(f"[Process {self.pid}] Received '{message}' from Process {sender_pid} "
              f"(sender_ts={timestamp}) -> Updated Clock = {self.clock}")

if __name__ == "__main__":

    p1 = Process(1)
    p2 = Process(2)
    p3 = Process(3)

    print("\n--- Lamport Clock Simulation Start ---\n")
    p1.internal_event("a1")
    p1.send_message(p2, "m1")
    p2.internal_event("b1")
    p2.send_message(p3, "m2")
    p3.internal_event("c1")
    p3.send_message(p1, "m3")
    p1.internal_event("a2")

    print("\n--- Lamport Clock Simulation End ---")
    
print("Vector Clock Implementation")

class VectorClockProcess:
    def __init__(self, pid, num_processes):
        self.pid = pid
        self.num_processes = num_processes
        self.clock = [0] * num_processes

    def internal_event(self, event_name):
        self.clock[self.pid] += 1
        print(f"[P{self.pid}] Internal Event '{event_name}' -> VC = {self.clock}")

    def send_message(self, receiver, message):
        self.clock[self.pid] += 1
        print(f"[P{self.pid}] Sending '{message}' to P{receiver.pid} with VC = {self.clock}")
        receiver.receive_message(self.pid, message, self.clock.copy())

    def receive_message(self, sender_pid, message, received_clock):
        for i in range(self.num_processes):
            self.clock[i] = max(self.clock[i], received_clock[i])
        self.clock[self.pid] += 1

        print(f"[P{self.pid}] Received '{message}' from P{sender_pid} "
              f"-> Updated VC = {self.clock}")


if __name__ == "__main__":
    p0 = VectorClockProcess(0, 3)
    p1 = VectorClockProcess(1, 3)
    p2 = VectorClockProcess(2, 3)

    print("\n--- Vector Clock Simulation Start ---\n")
    p0.internal_event("a1")
    p0.send_message(p1, "m1")
    p1.internal_event("b1")
    p1.send_message(p2, "m2")
    p2.internal_event("c1")
    p2.send_message(p0, "m3")
    p0.internal_event("a2")

    print("\n--- Vector Clock Simulation End ---")


"""
def get7():
    print(EX7)