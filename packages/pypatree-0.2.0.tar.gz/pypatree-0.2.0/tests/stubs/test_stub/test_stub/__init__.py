"""Stub package named 'test_stub' to test skip_tests filtering."""
