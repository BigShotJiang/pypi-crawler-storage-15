"""
Error Log Classifier - Package
"""

__version__ = "1.0.0"
__author__ = "Group 106 - Preetham Ghorpade & Harish R S"
__description__ = "Error log analysis and clustering tool with CSV and HTML exports"






# added: change 7
_added_marker_7 = 7


# added: change 14
_added_marker_14 = 14


# added: src change 7
_added_marker_new_7 = 7


# added: src change 14
_added_marker_new_14 = 14

