from enum import StrEnum


class BaseRelations(StrEnum):
    SELF = "self"
    ITEM = "item"
    DOWNLOAD = "Download"
    CREATED_RESSOURCE = "created-resource"
