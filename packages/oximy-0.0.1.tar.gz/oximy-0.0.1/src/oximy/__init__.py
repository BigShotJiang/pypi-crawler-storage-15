"""
Oximy - Reserved package name

This package is currently reserved and does not provide any functionality yet.
"""

__version__ = "0.0.1"

