"""Constants for pybraendstofpriser."""

DIESEL = "diesel"
OCTANE_95 = "octane_95"
OCTANE_100 = "octane_100"
