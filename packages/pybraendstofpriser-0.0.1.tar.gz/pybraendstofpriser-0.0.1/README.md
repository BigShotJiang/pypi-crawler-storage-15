![Buy Me A Coffee](https://www.buymeacoffee.com/assets/img/custom_images/orange_img.png)

## pybraendstofpriser

This is a PyPI module for fetching/scraping fuel prices from Danish suppliers, primarily developed for use with [Home Assistant](https://home-assistant.io), but I try to keep it as widely usable as possible.