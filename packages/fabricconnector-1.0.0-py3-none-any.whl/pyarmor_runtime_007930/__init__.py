# Pyarmor 9.2.1 (pro), 007930, 2025-12-03T13:40:43.099462
from .pyarmor_runtime import __pyarmor__
