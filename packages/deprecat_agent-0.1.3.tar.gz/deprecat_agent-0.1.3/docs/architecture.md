# Architecture Notes

Describe key components and flows here.
