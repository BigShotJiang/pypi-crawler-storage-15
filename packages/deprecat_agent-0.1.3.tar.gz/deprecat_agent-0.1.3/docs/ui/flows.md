# UI Flows

Document CLI/TUI interactions in this file.
