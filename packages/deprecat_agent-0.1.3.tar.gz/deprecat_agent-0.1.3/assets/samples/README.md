# Sample Payloads

Store mock manifests and fixtures for CLI dry-runs here.
