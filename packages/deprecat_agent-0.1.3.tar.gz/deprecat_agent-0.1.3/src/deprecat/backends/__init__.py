"""deprecat.$pkg package."""
