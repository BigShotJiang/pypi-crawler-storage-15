2025-03-13 Version: 5.0.2
- Update API CreateServiceConnection: update param body.


2025-02-20 Version: 5.0.1
- Update API CreateComment: update param body.


2025-01-03 Version: 5.0.0
- Delete API CreateWorkspace.
- Delete API FrozenWorkspace.
- Delete API GetPushRule.
- Delete API GetWorkspace.
- Delete API ListWorkspaces.
- Delete API ReleaseWorkspace.
- Update API GetWorkItemInfo: update response param.


2024-08-16 Version: 4.23.2
- Update API ExportInsightSpace: update response param.


2024-08-02 Version: 4.23.1
- Update API ExportInsightWorkitemStatus: update response param.
- Update API ExportInsightWorkitemStatusJoinWorkitemDefectExtra: update response param.


2024-07-29 Version: 4.23.0
- Support API PassReleaseStagePipelineValidate.
- Support API RefuseReleaseStagePipelineValidate.


2024-07-26 Version: 4.22.0
- Support API CancelExecutionReleaseStage.
- Support API ExecuteChangeRequestReleaseStage.
- Support API GetReleaseStagePipelineRun.


2024-07-22 Version: 4.21.1
- Generated python 2021-06-25 for devops.

2024-07-09 Version: 4.21.0
- Support API CreateChangeRequest.
- Support API ListChangeRequestWorkflowExecutions.
- Support API ListChangeRequests.


2024-07-02 Version: 4.20.0
- Support API ListAllReleaseWorkflows.
- Support API ListAppReleaseStageExecutionIntegratedMetadata.
- Support API ListAppReleaseStageExecutions.
- Support API UpdateOrganizationMember.


2024-05-28 Version: 4.19.0
- Support API ExportInsightCustomValue.
- Support API ExportInsightExpectedWorkTime.
- Support API ExportInsightField.
- Support API ExportInsightSpace.
- Support API ExportInsightSpaceRef.
- Support API ExportInsightSprint.
- Support API ExportInsightTagRef.
- Support API ExportInsightWorkTime.
- Support API ExportInsightWorkitemStatus.
- Support API ExportInsightWorkitemStatusJoinWorkitemDefectExtra.
- Support API ExportInsightWorkitemVersion.
- Support API ExportWorkitemActivity.


2024-04-25 Version: 4.18.4
- Update API CreateWorkitem: update response param.
- Update API GetApplication: update response param.
- Update API GetWorkItemInfo: update response param.
- Update API UpdateWorkItem: update response param.


2024-04-19 Version: 4.18.3
- Update API CreateWorkitem: update response param.
- Update API GetWorkItemInfo: update response param.
- Update API UpdateWorkItem: update response param.


2024-04-07 Version: 4.18.2
- Update API ListOrganizations: add param accessToken.


2024-03-29 Version: 4.18.1
- Update API ListJoinedOrganizations: update response param.


2024-03-29 Version: 4.18.0
- Support API CreateComment.
- Support API CreateCommitWithMultipleFiles.
- Update API ListOrganizations: update response param.
- Update API ListRepositories: add param minAccessLevel.


2024-03-27 Version: 4.17.0
- Support API ListJoinedOrganizations.
- Support API ListUserDrawRecordByPk.
- Update API GetWorkItemInfo: update response param.
- Update API ListOrganizationMembers: update response param.


2024-02-28 Version: 4.16.0
- Support API ListUserDrawRecordByPk.
- Update API GetWorkItemInfo: update response param.
- Update API ListOrganizationMembers: update response param.


2024-02-27 Version: 4.15.0
- Support API ListUserDrawRecordByPk.
- Update API ListOrganizationMembers: update response param.


2024-02-27 Version: 4.14.0
- Support API ListUserDrawRecordByPk.


2024-02-27 Version: 4.13.0
- Support API ListUserDrawRecordByPk.


2024-02-01 Version: 4.12.2
- Update API ListUserKeysupdate response param.


2024-01-31 Version: 4.12.1
- Generated python 2021-06-25 for devops.

2024-01-31 Version: 4.12.0
- Support API CreateCheckRun.
- Support API GetCheckRun.
- Support API ListCheckRuns.
- Support API UpdateCheckRun.


2024-01-29 Version: 4.11.1
- Update API GetMergeRequestupdate response param.
- Update API GetOrganizationMemberupdate response param.
- Update API ListMergeRequestCommentsupdate response param.
- Update API ListMergeRequestsadd createdAfter param.
add createdBefore param.
update response param.
- Update API ListOrganizationMembersupdate response param.


2024-01-23 Version: 4.11.0
- Generated python 2021-06-25 for devops.

2024-01-19 Version: 4.10.0
- Generated python 2021-06-25 for devops.

2024-01-19 Version: 4.9.0
- Generated python 2021-06-25 for devops.

2024-01-19 Version: 4.8.0
- Generated python 2021-06-25 for devops.

2024-01-15 Version: 4.7.0
- Generated python 2021-06-25 for devops.

2024-01-11 Version: 4.6.1
- Generated python 2021-06-25 for devops.

2024-01-05 Version: 4.6.0
- Generated python 2021-06-25 for devops.

2023-12-06 Version: 4.5.0
- Generated python 2021-06-25 for devops.

2023-11-09 Version: 4.4.2
- Generated python 2021-06-25 for devops.

2023-10-27 Version: 4.4.1
- Generated python 2021-06-25 for devops.

2023-10-27 Version: 4.4.0
- Generated python 2021-06-25 for devops.

2023-10-24 Version: 4.3.2
- Generated python 2021-06-25 for devops.

2023-10-18 Version: 4.3.1
- Generated python 2021-06-25 for devops.

2023-09-26 Version: 4.3.0
- Generated python 2021-06-25 for devops.

2023-09-20 Version: 4.2.1
- Generated python 2021-06-25 for devops.

2023-08-18 Version: 4.2.0
- Generated python 2021-06-25 for devops.

2023-08-11 Version: 4.1.0
- Generated python 2021-06-25 for devops.

2023-08-01 Version: 4.0.0
- Add TransferRepository API.

2023-07-14 Version: 3.0.2
- Add GetWorkitemAttachmentCreatemeta And WorkitemAttachmentCreate.

2023-07-05 Version: 3.0.1
- Add CreatePipeline And UpdatePipeline.

2023-06-25 Version: 3.0.0
- Add CreateUserKey.
- Add DeleteUserKey.
- Add ListUserKey.

2023-04-04 Version: 2.1.9
- Add update repository group api.

2023-02-24 Version: 2.1.8
- Add search api and push review api and compare api.

2023-02-23 Version: 2.1.7
- Add search api and push review api and compare api.

2023-01-10 Version: 2.1.6
- Add search api and push review api and compare api.

2022-12-27 Version: 2.1.5
- Add groups and group member and deploy key and tag.

2022-12-06 Version: 2.1.4
- Modify published api.

2022-11-21 Version: 2.1.3
- Modify published api.

2022-11-07 Version: 2.1.2
- Add codeup related API,  13 in total.

2022-10-31 Version: 2.1.1
- Add CreateWorkitemComment and change some API params.

2022-10-29 Version: 2.1.0
- Add CreateWorkitemComment and change some API params.

2022-10-25 Version: 1.1.31
- Add UpdateProtectedBranches and change some API params.

2022-07-28 Version: 1.1.30
- Add PipelineGroup.

2022-07-27 Version: 1.0.29
- Update create repo.

2022-06-07 Version: 1.1.19
- Update Projex ErrorCode API.

2022-05-26 Version: 1.1.16
- Update Projex Workitem API.

2022-05-12 Version: 1.1.15
- Update Projex Workitem API.

2022-04-28 Version: 1.1.14
- Update Projex Workitem API.

2022-04-13 Version: 1.1.13
- Update Projex Workitem API.

2022-04-02 Version: 1.1.12
- Add Codeup Api.

2022-03-18 Version: 1.1.11
- Add Codeup Api.

2022-02-24 Version: 1.1.10
- Add CreateWorkitem Api.

2022-01-29 Version: 1.1.9
- Add CreateWorkitem Api.

2022-01-10 Version: 1.1.8
- Add CreateSprint Api.

2021-12-30 Version: 1.1.7
- Add GeyPipelinArtifactUrl Api.

2021-12-15 Version: 1.1.6
- Add Tag Api.

2021-11-26 Version: 1.1.5
- Add Deploy Api.

2021-11-26 Version: 1.1.4
- Add Deploy Api.

2021-11-25 Version: 1.1.2
- Add Deploy Api.

2021-11-17 Version: 1.0.4
- Add PipelineValidate API.

2021-09-27 Version: 1.0.3
- Add roleId for result.

2021-09-23 Version: 1.0.2
- Update query param time to Time.

2021-09-02 Version: 1.0.1
- Init.

2021-08-31 Version: 1.0.0
- Init.

