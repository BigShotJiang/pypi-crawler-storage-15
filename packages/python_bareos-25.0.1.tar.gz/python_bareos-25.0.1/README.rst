python-bareos
=============

`python-bareos` is a Python module to access a https://www.bareos.com backup system.

Packages for `python-bareos` are included in the Bareos core distribution and available via https://pypi.org/.

Documentation is available at https://docs.bareos.org/DeveloperGuide/PythonBareos.html
