"""Paved CLI package."""

