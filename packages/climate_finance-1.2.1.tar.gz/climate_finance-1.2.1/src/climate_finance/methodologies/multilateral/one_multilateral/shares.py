def high_confidence_multilateral_crdf_providers() -> list:
    return [
        "990",
        "909",
        "915",
        "976",
        "901",
        "905",
        "1024",
        "1015",
        "1011",
        "1016",
        "1313",
        "988",
        "981",
        "910",
        "906",
    ]
