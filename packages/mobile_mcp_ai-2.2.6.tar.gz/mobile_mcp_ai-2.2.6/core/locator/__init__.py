"""
移动端定位器模块
"""

from .mobile_smart_locator import MobileSmartLocator

__all__ = [
    'MobileSmartLocator',
]

