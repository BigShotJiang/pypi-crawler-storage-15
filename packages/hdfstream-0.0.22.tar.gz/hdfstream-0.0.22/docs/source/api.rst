API Documentation
-----------------

.. automodule:: hdfstream
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: hdfstream.testing
   :members:
   :undoc-members:
   :show-inheritance:
