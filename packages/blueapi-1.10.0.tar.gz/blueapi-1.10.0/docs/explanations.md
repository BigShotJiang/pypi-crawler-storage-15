# Explanations

Explanations of how it works and why it works that way.

```{toctree}
:maxdepth: 1
:glob:

explanations/*
```
