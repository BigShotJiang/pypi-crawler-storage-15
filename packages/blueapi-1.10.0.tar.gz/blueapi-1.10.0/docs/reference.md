# Reference

Technical reference material including APIs and release notes.

```{toctree}
:maxdepth: 1
:glob:

reference/*
API <_api/blueapi>
genindex
Release Notes <https://github.com/DiamondLightSource/blueapi/releases>
```
