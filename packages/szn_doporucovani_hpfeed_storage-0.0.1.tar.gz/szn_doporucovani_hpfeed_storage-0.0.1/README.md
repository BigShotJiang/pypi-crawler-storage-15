# szn-doporucovani-hpfeed-storage

This is a security placeholder package created to prevent dependency confusion attacks.