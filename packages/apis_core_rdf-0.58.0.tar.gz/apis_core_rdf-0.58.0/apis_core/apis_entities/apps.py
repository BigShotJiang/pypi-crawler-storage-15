from django.apps import AppConfig


class EntitiesConfig(AppConfig):
    name = "apis_core.apis_entities"
