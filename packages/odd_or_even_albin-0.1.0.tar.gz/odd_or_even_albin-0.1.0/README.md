# odd_or_even

A simple Python library to check whether a number is odd or even.

## Installation
```bash
pip install odd_or_even_albin


from odd_or_even import is_even, is_odd, check

print(is_even(10))   # True
print(is_odd(7))     # True
print(check(15))     # "odd"
