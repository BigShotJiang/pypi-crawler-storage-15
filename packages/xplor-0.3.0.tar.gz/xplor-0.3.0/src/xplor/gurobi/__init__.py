"""Gurobi backend."""

from xplor.gurobi.model import XplorGurobi

__all__ = ["XplorGurobi"]
