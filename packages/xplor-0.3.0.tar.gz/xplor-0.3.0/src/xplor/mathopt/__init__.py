"""Gurobi backend."""

from xplor.mathopt.model import XplorMathOpt

__all__ = ["XplorMathOpt"]
