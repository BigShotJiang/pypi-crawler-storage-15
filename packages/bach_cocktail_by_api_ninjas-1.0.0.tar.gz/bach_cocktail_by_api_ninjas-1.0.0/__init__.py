"""MCP Server for Cocktail By Api Ninjas"""
