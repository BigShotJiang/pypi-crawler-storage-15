#!/usr/bin/sh
pytest