# pyright: reportGeneralTypeIssues=false
"""Workspace commands for AnyTask CLI."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import List

import typer
from typing_extensions import Annotated
from rich.prompt import Prompt
from InquirerPy.base.control import Choice

from cli.commands.console import console
from cli.commands.decorators import async_command
from cli.commands.formatters import TableFormatter
from cli.commands.services import ServiceRegistry as services
from cli.config import WorkspaceConfig, get_effective_api_config
from cli.models.workspace import Workspace
from cli.models.project import ProjectCreate
from cli.models.common import ProjectStatus
from cli.services.project_service import ProjectService
from cli.utils.interactive import select_one, confirm, is_interactive

app = typer.Typer(help="Manage workspaces")


async def _select_or_create_project(
    workspace_id: int, workspace_identifier: str, project_service: ProjectService
) -> int | None:
    """Interactive project selection or creation flow.

    Args:
        workspace_id: The workspace ID
        workspace_identifier: The workspace identifier
        project_service: ProjectService instance

    Returns:
        Selected or created project ID, or None if failed
    """
    # Check for TTY - non-interactive mode returns None
    if not is_interactive():
        console.print(
            "[yellow]Non-interactive mode: Skipping project selection[/yellow]"
        )
        return None

    # Fetch existing projects
    console.print("Fetching projects...")
    try:
        projects = await project_service.list_projects(workspace_id)
    except Exception as e:  # noqa: BLE001 - Intentionally broad: project listing is optional
        # Project listing is optional; continue with empty list on any error
        console.print(f"[yellow]Warning:[/yellow] Could not fetch projects: {e}")
        projects = []

    # Show project selection menu with InquirerPy
    if projects:
        # Build choices - use special marker for "Create new project"
        CREATE_NEW_MARKER = -1
        proj_choices: "list[Choice]" = []

        for project in projects:
            desc = project.description or ""
            if len(desc) > 40:
                desc = desc[:37] + "..."
            name = f"{project.name}" + (f" - {desc}" if desc else "")
            proj_choices.append(Choice(value=project.id, name=name))

        # Add "Create new project" option
        proj_choices.append(
            Choice(value=CREATE_NEW_MARKER, name="+ Create new project")
        )

        try:
            selected_id = select_one(
                choices=proj_choices,
                message="Which project would you like to use?",
            )
        except KeyboardInterrupt:
            console.print("\n[yellow]Project selection cancelled[/yellow]")
            return None

        if selected_id != CREATE_NEW_MARKER:
            # User selected an existing project
            selected_project = next(p for p in projects if p.id == selected_id)
            console.print(f"[green]✓[/green] Selected project: {selected_project.name}")
            return selected_project.id
        # Otherwise, create new project (fall through to creation flow)
    else:
        console.print("[dim]No existing projects found[/dim]")
        try:
            if not confirm("Create a new project?", default=True):
                return None
        except KeyboardInterrupt:
            console.print("\n[yellow]Cancelled[/yellow]")
            return None

    # Create new project
    console.print("\n[cyan]Creating new project[/cyan]")

    # Prompt for project name (required) - use Rich for text input
    project_name = Prompt.ask("Project name", default=f"{workspace_identifier} Project")

    # Prompt for description (optional)
    description_input: str = Prompt.ask("Description (optional)", default="")
    description: str | None = description_input if description_input else None

    # Status selection with InquirerPy
    status_choices: "list[Choice]" = [
        Choice(value=status.value, name=status.value) for status in ProjectStatus
    ]
    try:
        status_value = select_one(
            choices=status_choices,
            message="Status:",
            default=ProjectStatus.ACTIVE.value,
        )
        status = ProjectStatus(status_value)
    except KeyboardInterrupt:
        console.print("\n[yellow]Project creation cancelled[/yellow]")
        return None

    # Create project
    try:
        project_create = ProjectCreate(
            name=project_name,
            description=description,
            status=status,
        )
        new_project = await project_service.create_project(workspace_id, project_create)
        console.print(f"[green]✓[/green] Created project: {new_project.name}")
        return new_project.id
    except Exception as e:  # noqa: BLE001 - Intentionally broad: project creation is optional
        # Project creation is optional; return None on any error
        console.print(f"[red]Error:[/red] Failed to create project: {e}")
        return None


@app.command()
@async_command()
async def init(
    workspace_id: Annotated[
        str | None,
        typer.Argument(help="Workspace ID or identifier to initialize (optional)"),
    ] = None,
    directory: Annotated[
        Path | None,
        typer.Option("--dir", "-d", help="Directory to initialize (default: current)"),
    ] = None,
) -> None:
    """Initialize a workspace in the current directory.

    Links an existing workspace to the current directory.
    Creates anyt.json workspace configuration file.
    """
    # Check authentication and get API config
    try:
        effective_config = get_effective_api_config()
    except RuntimeError:
        console.print("[red]Error:[/red] Not authenticated")
        console.print("\nSet the ANYT_API_KEY environment variable:")
        console.print("  [cyan]export ANYT_API_KEY=anyt_agent_...[/cyan]")
        raise typer.Exit(1)

    # Initialize services
    workspace_service = services.get_workspace_service()
    project_service = services.get_project_service()

    # Determine target directory
    target_dir = directory or Path.cwd()
    target_dir = target_dir.resolve()

    # Check if already initialized
    existing_config = WorkspaceConfig.load(target_dir)
    if existing_config:
        console.print(
            f"[yellow]Warning:[/yellow] Workspace config already exists: {existing_config.name}"
        )
        console.print(f"Workspace ID: {existing_config.workspace_id}")
        if existing_config.workspace_identifier:
            console.print(f"Identifier: {existing_config.workspace_identifier}")

        reset = Prompt.ask("Do you want to reset it?", choices=["y", "N"], default="N")

        if reset.lower() != "y":
            console.print("[green]✓[/green] Using existing workspace configuration")
            raise typer.Exit(0)

        # If reset (y), continue with initialization

    # Fetch available workspaces
    console.print("Fetching available workspaces...")
    workspaces = await workspace_service.list_workspaces()

    if not workspaces:
        console.print("[red]Error:[/red] No workspaces found")
        console.print(
            "\nPlease create a workspace first using the web interface or API."
        )
        raise typer.Exit(1)

    # Find target workspace
    target_ws: Workspace | None = None
    if workspace_id:
        # Find workspace by ID or identifier
        for ws in workspaces:
            if str(ws.id) == workspace_id or ws.identifier == workspace_id.upper():
                target_ws = ws
                break

        if not target_ws:
            console.print(f"[red]Error:[/red] Workspace '{workspace_id}' not found")
            raise typer.Exit(1)
    else:
        # Interactive workspace selection with InquirerPy
        if not is_interactive():
            # Non-interactive: default to first workspace
            target_ws = workspaces[0]
            console.print(
                f"[green]✓[/green] Using workspace: {target_ws.name} ({target_ws.identifier})"
            )
        else:
            # Build choices for select prompt
            ws_choices: "list[Choice]" = [
                Choice(
                    value=ws.id,
                    name=f"{ws.name} ({ws.identifier}) - ID: {ws.id}",
                )
                for ws in workspaces
            ]

            try:
                ws_selected_id = select_one(
                    choices=ws_choices,
                    message="Select workspace:",
                )
            except KeyboardInterrupt:
                console.print("\n[yellow]Workspace selection cancelled[/yellow]")
                raise typer.Exit(1)

            target_ws = next(ws for ws in workspaces if ws.id == ws_selected_id)
            console.print(
                f"[green]✓[/green] Selected workspace: {target_ws.name} ({target_ws.identifier})"
            )

    # Select or create project
    try:
        current_project_id = await _select_or_create_project(
            target_ws.id, target_ws.identifier, project_service
        )
    except Exception as e:  # noqa: BLE001 - Intentionally broad: project setup is optional
        # Project setup is optional; continue without project on any error
        console.print(f"[yellow]Warning:[/yellow] Could not setup project: {e}")
        current_project_id = None

    # Save workspace config
    api_url = effective_config.get("api_url") or "https://api.anyt.dev"
    ws_config = WorkspaceConfig(
        workspace_id=target_ws.id,
        name=target_ws.name,
        api_url=api_url,
        workspace_identifier=target_ws.identifier,
        current_project_id=current_project_id,
        last_sync=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    )
    ws_config.save(target_dir)

    console.print(
        f"[green]✓[/green] Initialized workspace config in {target_dir}/.anyt/anyt.json"
    )


@app.command()
@async_command()
async def list() -> None:
    """List all accessible workspaces."""
    # Check authentication
    try:
        get_effective_api_config()
    except RuntimeError:
        console.print("[red]Error:[/red] Not authenticated")
        console.print("\nSet the ANYT_API_KEY environment variable:")
        console.print("  [cyan]export ANYT_API_KEY=anyt_agent_...[/cyan]")
        raise typer.Exit(1)

    # Initialize services
    workspace_service = services.get_workspace_service()

    console.print("Fetching workspaces...")
    workspaces = await workspace_service.list_workspaces()

    # Check for local workspace
    local_ws = WorkspaceConfig.load()

    def format_workspace_row(ws: Workspace) -> List[str]:
        """Format a workspace row for table display."""
        ws_id = str(ws.id)
        is_current = local_ws and local_ws.workspace_id == ws.id
        status = "● active" if is_current else ""
        return [ws.name, ws.identifier, ws_id, status]

    TableFormatter().format_list(
        items=workspaces,
        columns=[
            ("Name", "green"),
            ("Identifier", "yellow"),
            ("ID", "dim"),
            ("Status", "cyan"),
        ],
        title="Accessible Workspaces",
        row_formatter=format_workspace_row,
        empty_message="No workspaces found",
    )


@app.command()
@async_command()
async def switch(
    workspace_id: Annotated[
        str | None,
        typer.Argument(help="Workspace ID or identifier to switch to"),
    ] = None,
    directory: Annotated[
        Path | None,
        typer.Option(
            "--dir", "-d", help="Directory to switch workspace in (default: current)"
        ),
    ] = None,
) -> None:
    """Switch the active workspace for the current directory.

    This updates the anyt.json file to point to a different workspace.
    """
    # Check authentication and get API config
    try:
        effective_config = get_effective_api_config()
    except RuntimeError:
        console.print("[red]Error:[/red] Not authenticated")
        console.print("\nSet the ANYT_API_KEY environment variable:")
        console.print("  [cyan]export ANYT_API_KEY=anyt_agent_...[/cyan]")
        raise typer.Exit(1)

    # Determine target directory
    target_dir = directory or Path.cwd()
    target_dir = target_dir.resolve()

    # Check if initialized
    existing_config = WorkspaceConfig.load(target_dir)
    if not existing_config:
        console.print("[red]Error:[/red] Directory not initialized with a workspace")
        console.print("Run [cyan]anyt workspace init[/cyan] first")
        raise typer.Exit(1)

    # Initialize services
    workspace_service = services.get_workspace_service()
    project_service = services.get_project_service()

    console.print("Fetching available workspaces...")
    workspaces = await workspace_service.list_workspaces()

    if not workspaces:
        console.print("[yellow]No workspaces found[/yellow]")
        raise typer.Exit(0)

    # If workspace_id provided, find it
    target_ws: Workspace | None = None
    if workspace_id:
        for ws in workspaces:
            if str(ws.id) == workspace_id or ws.identifier == workspace_id.upper():
                target_ws = ws
                break

        if not target_ws:
            console.print(f"[red]Error:[/red] Workspace '{workspace_id}' not found")
            raise typer.Exit(1)
    else:
        # Interactive workspace selection with InquirerPy
        if not is_interactive():
            console.print(
                "[yellow]Non-interactive mode: Cannot display workspace selector[/yellow]"
            )
            console.print("Please specify a workspace ID or identifier as an argument")
            raise typer.Exit(1)

        # Build choices for select prompt
        switch_choices: "list[Choice]" = []
        for ws in workspaces:
            is_current = existing_config.workspace_id == ws.id
            marker = " (current)" if is_current else ""
            switch_choices.append(
                Choice(
                    value=ws.id,
                    name=f"{ws.name} ({ws.identifier}){marker}",
                )
            )

        try:
            selected_ws_id = select_one(
                choices=switch_choices,
                message="Select workspace to switch to:",
            )
        except KeyboardInterrupt:
            console.print("\n[yellow]Workspace switch cancelled[/yellow]")
            raise typer.Exit(1)

        target_ws = next(ws for ws in workspaces if ws.id == selected_ws_id)

    # Fetch current project for the workspace
    console.print("Fetching current project...")
    try:
        current_project = await project_service.get_or_create_default_project(
            target_ws.id, target_ws.identifier
        )
        current_project_id = current_project.id
    except Exception as e:  # noqa: BLE001 - Intentionally broad: project fetching is optional
        # Project fetching is optional; continue without project on any error
        console.print(f"[yellow]Warning:[/yellow] Could not fetch current project: {e}")
        current_project_id = None

    # Update workspace config
    api_url = effective_config.get("api_url") or "https://api.anyt.dev"
    ws_config = WorkspaceConfig(
        workspace_id=target_ws.id,
        name=target_ws.name,
        api_url=api_url,
        workspace_identifier=target_ws.identifier,
        current_project_id=current_project_id,
        last_sync=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    )
    ws_config.save(target_dir)

    console.print(
        f"[green]✓[/green] Switched to workspace: {target_ws.name} ({target_ws.identifier})"
    )


@app.command()
@async_command()
async def use(
    workspace: Annotated[
        str,
        typer.Argument(help="Workspace ID or identifier to set as current"),
    ],
) -> None:
    """Set the current workspace for the active environment.

    This sets the default workspace that will be used for all task operations
    when no explicit workspace is specified via --workspace flag.
    """
    # Check authentication
    try:
        get_effective_api_config()
    except RuntimeError:
        console.print("[red]Error:[/red] Not authenticated")
        console.print("\nSet the ANYT_API_KEY environment variable:")
        console.print("  [cyan]export ANYT_API_KEY=anyt_agent_...[/cyan]")
        raise typer.Exit(1)

    # Initialize services
    workspace_service = services.get_workspace_service()

    console.print("Fetching available workspaces...")
    workspaces = await workspace_service.list_workspaces()

    if not workspaces:
        console.print("[yellow]No workspaces found[/yellow]")
        raise typer.Exit(0)

    # Find the target workspace
    target_ws: Workspace | None = None
    for ws in workspaces:
        if str(ws.id) == workspace or ws.identifier == workspace.upper():
            target_ws = ws
            break

    if not target_ws:
        console.print(f"[red]Error:[/red] Workspace '{workspace}' not found")
        console.print("\nAvailable workspaces:")
        for ws in workspaces:
            console.print(f"  {ws.identifier} - {ws.name} (ID: {ws.id})")
        raise typer.Exit(1)

    # Note: This command is deprecated. Use 'anyt workspace switch' instead.
    console.print("[yellow]Note:[/yellow] The 'workspace use' command is deprecated.")
    console.print(
        f"Use [cyan]anyt workspace switch {workspace}[/cyan] instead to update your local workspace."
    )
    console.print()
    console.print(f"Target workspace: {target_ws.name} ({target_ws.identifier})")


@app.command()
@async_command()
async def current() -> None:
    """Show the current workspace from local config."""
    # Load local workspace config
    ws_config = WorkspaceConfig.load()

    if ws_config:
        # Check authentication to fetch workspace details
        try:
            get_effective_api_config()
            workspace_service = services.get_workspace_service()

            try:
                workspaces = await workspace_service.list_workspaces()
                current_ws: Workspace | None = None
                for ws in workspaces:
                    if ws.id == int(ws_config.workspace_id):
                        current_ws = ws
                        break

                if current_ws:
                    console.print(
                        f"Current workspace: [green]{current_ws.name}[/green] ([yellow]{current_ws.identifier}[/yellow])"
                    )
                    console.print(f"Workspace ID: {current_ws.id}")
                else:
                    console.print(
                        f"Workspace ID: [yellow]{ws_config.workspace_id}[/yellow]"
                    )
                    console.print(
                        "[dim](Workspace not found in accessible workspaces)[/dim]"
                    )
            except Exception:  # noqa: BLE001 - Intentionally broad: workspace info display is best-effort
                # Workspace info display is best-effort; show basic info on any error
                console.print(
                    f"Workspace ID: [yellow]{ws_config.workspace_id}[/yellow]"
                )

        except RuntimeError:
            # Not authenticated - just show the workspace ID from config
            console.print(f"Workspace: [yellow]{ws_config.name}[/yellow]")
            console.print(f"Workspace ID: {ws_config.workspace_id}")
            if ws_config.workspace_identifier:
                console.print(f"Identifier: {ws_config.workspace_identifier}")
    else:
        console.print("[dim]No workspace initialized[/dim]")
        console.print("\nInitialize a workspace with: [cyan]anyt workspace init[/cyan]")
