"""
Worker start command for running automated task processing.
"""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Optional

import typer
from rich.markup import escape
from InquirerPy.base.control import Choice

from cli.commands.console import console
from cli.utils.interactive import select_one, is_interactive
from cli.commands.worker.helpers import resolve_workflow_file
from cli.worker.coordinator import TaskCoordinator


def start(
    workspace_dir: Optional[Path] = typer.Option(
        None,
        "--workspace",
        "-w",
        help="Workspace directory (default: current directory)",
    ),
    workflow: Optional[str] = typer.Option(
        None,
        "--workflow",
        help="Workflow to run (remote_dev, local_dev, dry_run). If not specified, shows interactive selection with remote_dev as default.",
    ),
    workflows_dir: Optional[Path] = typer.Option(
        None,
        "--workflows",
        help="Workflows directory (default: .anyt/workflows). If --workflow is specified, loads from this directory.",
    ),
    poll_interval: int = typer.Option(
        5,
        "--poll-interval",
        "-i",
        help="Polling interval in seconds",
    ),
    max_backoff: int = typer.Option(
        60,
        "--max-backoff",
        help="Maximum backoff interval in seconds",
    ),
    project_id: Optional[int] = typer.Option(
        None,
        "--project-id",
        "-p",
        help="Project ID to scope task suggestions. If not provided, loads from .anyt/anyt.json (current_project_id field).",
    ),
    skip_checks: bool = typer.Option(
        False,
        "--skip-checks",
        help="Skip workflow requirement validation before starting",
    ),
    force_check: bool = typer.Option(
        False,
        "--force-check",
        help="Force fresh requirement checks (bypass cache)",
    ),
    clone_repos: bool = typer.Option(
        False,
        "--clone-repos",
        help="Force clone project repos for all workflows (overrides workflow settings.clone_repo)",
    ),
    no_cleanup: bool = typer.Option(
        False,
        "--no-cleanup",
        help="Keep task workspaces after execution (overrides workflow settings.cleanup_workspace)",
    ),
) -> None:
    """
    Start the Claude task worker.

    The worker continuously polls for tasks and executes workflows automatically.

    Setup:
    1. Set ANYT_API_KEY environment variable for API authentication
    2. Run 'anyt worker start' and select workflow

    Workflow Selection:
    - If --workflow is NOT provided: Shows interactive workflow selector (default: remote_dev)
    - If --workflow is provided: Uses that specific workflow directly

    Workflow Options:
    - No options: Interactive workflow selection (default: remote_dev)
    - --workflow remote_dev: Runs ONLY remote_dev workflow (skips interactive selection)
    - --workflows-dir /custom: Custom workflows directory

    Built-in workflows (bundled with CLI, no setup required):
    - remote_dev (default): Clone remote GitHub repo, implement task, create PR
    - local_dev: Quick iterations on current branch, no branch management
    - dry_run: Test workflow without making actual changes (for testing)

    Workflow Comparison:
    | Workflow    | Clone Repo | Branch Mgmt | PR Creation | Best For           |
    |-------------|------------|-------------|-------------|--------------------|
    | remote_dev  | Yes        | Yes         | Yes         | Remote GitHub repos|
    | local_dev   | -          | -           | -           | Quick development  |
    | dry_run     | -          | -           | -           | Testing            |

    Example:
        export ANYT_API_KEY=anyt_agent_...  # API key for authentication
        anyt worker start  # Interactive workflow selection
        anyt worker start --workflow local_dev  # Direct workflow selection
        anyt worker start --project-id 123
        anyt worker start --poll-interval 10 --workspace /path/to/project
    """
    workspace = workspace_dir or Path.cwd()

    if not workspace.exists():
        console.print(
            f"[red]Error: Workspace directory does not exist: {workspace}[/red]"
        )
        raise typer.Exit(1)

    # Load workspace config to get defaults
    from cli.config import WorkspaceConfig

    workspace_config = WorkspaceConfig.load(workspace)
    if not workspace_config:
        console.print(
            f"[red]Error: No workspace config found at {workspace}/.anyt/anyt.json[/red]"
        )
        console.print(
            "[yellow]Hint: Initialize workspace with 'anyt workspace init'[/yellow]"
        )
        raise typer.Exit(1)

    # Use config defaults if not provided via CLI
    effective_project_id = project_id or workspace_config.current_project_id

    if effective_project_id:
        console.print(f"[dim]Using project_id: {effective_project_id}[/dim]")

    # Prompt for workflow selection if not specified
    resolved_workflow = _resolve_workflow(workflow)

    # Resolve workflow file if --workflow is specified
    workflow_file: Optional[Path] = None
    if resolved_workflow:
        try:
            workflow_file = resolve_workflow_file(
                resolved_workflow, workspace, workflows_dir
            )
            console.print(
                f"[green]Using workflow:[/green] {resolved_workflow} (from {workflow_file.parent})"
            )
        except ValueError as e:
            console.print(f"[red]Error: {escape(str(e))}[/red]")
            raise typer.Exit(1)

    # Check workflow requirements before starting (unless skipped)
    if not skip_checks and workflow_file:
        _check_workflow_requirements(
            workflow_file, resolved_workflow, workspace, force_check
        )

    # Create coordinator and run
    coordinator = TaskCoordinator(
        workspace_dir=workspace,
        workflows_dir=workflows_dir,
        workflow_file=workflow_file,
        poll_interval=poll_interval,
        max_backoff=max_backoff,
        project_id=effective_project_id,
        clone_repos=clone_repos,
        cleanup_workspaces=not no_cleanup,
    )

    try:
        asyncio.run(coordinator.run())
    except KeyboardInterrupt:
        console.print("\n[yellow]Worker stopped by user[/yellow]")


def _resolve_workflow(workflow: Optional[str]) -> str:
    """Resolve workflow from option or interactive selection."""
    if workflow:
        return workflow

    # Define workflow options
    workflows_list = [
        (
            "remote_dev",
            "Clone remote repo, implement task, create PR (for linked GitHub repos)",
        ),
        (
            "local_dev",
            "Quick iterations on current branch (no branch management, commits directly)",
        ),
        ("dry_run", "Test workflow without making actual changes (useful for testing)"),
    ]

    default_workflow = "remote_dev"

    # Non-interactive mode: use default
    if not is_interactive():
        console.print(f"[green]Using default workflow: {default_workflow}[/green]")
        return default_workflow

    # Build choices for InquirerPy select
    choices: list[Choice] = []
    for wf_name, wf_desc in workflows_list:
        # Mark default with indicator
        if wf_name == default_workflow:
            display_name = f"{wf_name} [DEFAULT] - {wf_desc}"
        else:
            display_name = f"{wf_name} - {wf_desc}"
        choices.append(Choice(value=wf_name, name=display_name))

    console.print()

    try:
        selected_workflow: str = select_one(
            choices=choices,
            message="Select a workflow to run:",
            default=default_workflow,
        )
    except KeyboardInterrupt:
        console.print("\n[yellow]Cancelled[/yellow]")
        raise typer.Exit(0)

    console.print(f"[green]✓[/green] Selected workflow: {selected_workflow}")
    return selected_workflow


def _check_workflow_requirements(
    workflow_file: Path,
    workflow_name: str,
    workspace: Path,
    force_check: bool,
) -> None:
    """Check workflow requirements before starting."""
    import yaml

    from cli.commands.workflow_formatters import display_check_results
    from cli.services.workflow_requirements import WorkflowRequirementsService
    from cli.worker.models import Workflow

    try:
        # Load workflow definition
        with open(workflow_file) as f:
            data = yaml.safe_load(f)
            # Fix YAML boolean key issue (on: becomes True)
            if True in data:
                data["on"] = data.pop(True)
            workflow_obj = Workflow(**data)

        # Check if workflow has requirements
        if workflow_obj.requirements and workflow_obj.requirements.has_requirements():
            console.print()
            console.print("[cyan]Checking workflow requirements...[/cyan]")

            # Run requirement checks
            service = WorkflowRequirementsService(workspace_dir=workspace)
            results = asyncio.run(
                service.check_requirements(
                    requirements=workflow_obj.requirements,
                    workflow_name=workflow_obj.name,
                    force=force_check,
                )
            )

            if results.is_success():
                # All checks passed - show what was validated
                for req_name, check_result in results.results:
                    if check_result.success:
                        console.print(
                            f"[green]✓[/green] {req_name}: {check_result.message}"
                        )
                    elif check_result.warning:
                        console.print(
                            f"[yellow]⚠[/yellow]  {req_name}: {check_result.message}"
                        )

                console.print()
                cache_status = " (cached)" if results.from_cache else ""
                console.print(f"[green]✓ All requirements met{cache_status}[/green]")
            else:
                # Some checks failed
                console.print()
                display_check_results(results)
                console.print()
                console.print(
                    "[yellow]Run [cyan]anyt worker check[/cyan] for detailed instructions[/yellow]"
                )
                raise typer.Exit(1)

    except Exception as e:  # noqa: BLE001 - Intentionally broad: display user-friendly error for any workflow requirement check failure
        console.print(f"[red]Error checking requirements: {escape(str(e))}[/red]")
        raise typer.Exit(1)
