"""Task rendering utilities for board visualization."""

from typing import Any

from rich.console import Console
from rich.table import Table

from cli.commands.task.helpers import (
    format_priority,
    format_relative_time,
    truncate_text,
)
from cli.models.wrappers.dependency_graph import DependencyGraphResponse


def annotate_blocked_tasks_from_graph(
    tasks: list[dict[str, Any]], graph: DependencyGraphResponse
) -> None:
    """Annotate tasks with blocked status using dependency graph data.

    This function modifies tasks in-place, adding "blocked_by" field to blocked tasks.
    Uses pre-fetched dependency graph data instead of N+1 API calls.

    Args:
        tasks: List of tasks to annotate (modified in-place)
        graph: Complete dependency graph with all tasks and dependencies
    """
    # Get set of blocked task IDs from graph
    blocked_ids = graph.get_blocked_tasks()

    # Annotate each task
    for task in tasks:
        identifier = task.get("identifier", str(task.get("id")))

        if identifier in blocked_ids:
            # Task is blocked - get blocking tasks
            blocking_nodes = graph.get_blocking_tasks(identifier)

            # Convert nodes to dict format for display
            task["blocked_by"] = [
                {
                    "identifier": node.id,
                    "title": node.title,
                    "status": node.status,
                    "priority": node.priority,
                }
                for node in blocking_nodes
            ]


def render_task_card(task: dict[str, Any], compact: bool = False) -> str:
    """Render a task as a card for the board."""
    task_id = task.get("identifier", str(task.get("id", "")))
    title = task.get("title", "")
    owner_id = task.get("owner_id")
    updated_at = task.get("updated_at")
    status = task.get("status", "")
    is_blocked = "blocked_by" in task

    # Add status indicator
    status_icon = ""
    if is_blocked:
        status_icon = "⚠️ "
    elif status == "done":
        status_icon = "✅ "
    elif status == "active":
        status_icon = "🔄 "
    elif status in ["backlog", "todo"]:
        status_icon = "⏸️ "

    if compact:
        # Compact format: "icon T-42 Title"
        return f"{status_icon}{task_id} {truncate_text(title, 30)}"
    else:
        # Multi-line card format
        lines = [f"{status_icon}{task_id} {truncate_text(title, 35)}"]

        # Owner info
        if owner_id:
            owner_display = owner_id[:10] if len(owner_id) > 10 else owner_id
            lines.append(f"     {owner_display} • {format_relative_time(updated_at)}")
        else:
            lines.append(f"     — • {format_relative_time(updated_at)}")

        # Show blocked indicator with dependency count
        if is_blocked:
            blocked_by = task.get("blocked_by", [])
            lines.append(f"     ⚠️ Blocked by {len(blocked_by)} task(s)")

        return "\n".join(lines)


def render_board_table(
    groups: dict[str, list[dict[str, Any]]],
    group_order: list[str],
    group_labels: dict[str, str],
    limit: int,
    console: Console,
) -> None:
    """Render the kanban board as a Rich table.

    Args:
        groups: Tasks grouped by status/priority/etc
        group_order: Order of groups to display
        group_labels: Display labels for each group
        limit: Maximum tasks per lane
        console: Rich console for output
    """
    # Create table with columns for each lane
    table = Table(show_header=True, header_style="bold", box=None, padding=(0, 2))

    for group_key in group_order:
        label = group_labels.get(group_key, group_key)
        group_tasks = groups.get(group_key, [])
        count = len(group_tasks)
        table.add_column(f"{label} ({count})", style="white", vertical="top")

    # Find max number of tasks in any lane
    max_tasks = max(len(groups.get(g, [])) for g in group_order)
    max_display = min(max_tasks, limit)

    # Build rows
    for i in range(max_display):
        row: list[str] = []
        for group_key in group_order:
            group_tasks = groups.get(group_key, [])
            if i < len(group_tasks):
                task = group_tasks[i]
                card_text = render_task_card(task, compact=False)
                row.append(card_text)
            else:
                row.append("")

        table.add_row(*row)

    console.print(table)


def render_board_header(
    workspace_identifier: str,
    console: Console,
) -> None:
    """Render the board header."""
    console.print()
    console.print("━" * 80)
    console.print(f"  [cyan bold]{workspace_identifier} Board[/cyan bold]")
    console.print("━" * 80)
    console.print()


def render_board_footer(
    total_tasks: int,
    displayed_tasks: int,
    console: Console,
) -> None:
    """Render the board footer with totals and hints."""
    console.print()
    console.print(f"Showing {displayed_tasks} of {total_tasks} tasks")
    console.print()
    console.print("[dim]Commands:[/dim]")
    console.print("  [cyan]anyt task pick <id>[/cyan]  - Pick a task to work on")
    console.print("  [cyan]anyt task show <id>[/cyan]  - View task details")
    console.print("  [cyan]anyt board --mine[/cyan]    - Show only your tasks")
    console.print()


def render_summary_section(
    title: str,
    icon: str,
    style: str,
    tasks: list[dict[str, Any]],
    max_display: int,
    console: Console,
    show_owner: bool = False,
) -> None:
    """Render a section of the summary (done, active, etc.)."""
    console.print(f"[{style}]{icon} {title} ({len(tasks)} tasks)[/{style}]")
    for task in tasks[:max_display]:
        task_id = task.get("identifier", str(task.get("id", "")))
        title_text = truncate_text(task.get("title", ""), 60 if not show_owner else 50)

        if show_owner:
            owner_id = task.get("owner_id", "—")
            if owner_id:
                owner_display = owner_id[:15] if len(owner_id) > 15 else owner_id
            else:
                owner_display = "unassigned"
            updated = format_relative_time(task.get("updated_at"))
            console.print(f"   • {task_id} {title_text} ({owner_display}, {updated})")
        else:
            console.print(f"   • {task_id} {title_text}")

    if len(tasks) > max_display:
        console.print(f"   [dim]... and {len(tasks) - max_display} more[/dim]")
    console.print()


def render_priorities_section(
    tasks: list[dict[str, Any]],
    console: Console,
) -> None:
    """Render the next priorities section of the summary."""
    console.print("[bold]📅 Next Priorities[/bold]")

    for i, task in enumerate(tasks[:3], 1):
        task_id = task.get("identifier", str(task.get("id", "")))
        title = truncate_text(task.get("title", ""), 60)
        priority = format_priority(task.get("priority", 0))
        console.print(f"   {i}. {task_id} {title} {priority}")
    console.print()


def render_summary_header(
    period: str,
    console: Console,
) -> None:
    """Render the summary header."""
    console.print()
    console.print("━" * 80)
    title_text = f"Workspace Summary - {period.capitalize()}"
    console.print(f"  [cyan bold]{title_text}[/cyan bold]")
    console.print("━" * 80)
    console.print()


def render_progress_footer(
    done_count: int,
    total: int,
    console: Console,
) -> None:
    """Render the progress footer."""
    console.print("━" * 80)
    progress_pct = int((done_count / total) * 100) if total > 0 else 0
    console.print(f"Progress: {done_count}/{total} tasks complete ({progress_pct}%)")
    console.print()


def render_task_dependency_graph(
    task_id: str,
    title: str,
    task_status: str,
    dependencies: list[Any],
    dependents: list[Any],
    console: Console,
) -> None:
    """Render a single task's dependency graph in ASCII format."""
    console.print()
    console.print("[bold]Task Dependency Graph[/bold]")
    console.print("━" * 80)
    console.print()

    # Show dependencies (what this depends on)
    if dependencies:
        for dep in dependencies:
            dep_id = dep.identifier or str(dep.id)
            dep_title = truncate_text(dep.title, 40)
            dep_status = dep.status.value if dep.status else ""
            status_sym = "✓" if dep_status == "done" else "○"
            console.print(f"        {dep_id} {status_sym}")
            console.print(f"        {dep_title}")
            console.print("          │")

    # Show current task
    console.print(f"        [cyan]{task_id}[/cyan] •")
    console.print(f"        {truncate_text(title, 40)}")
    console.print(f"        {task_status}")

    # Show dependents (what depends on this)
    if dependents:
        console.print("          │")
        for dept in dependents:
            dept_id = dept.identifier or str(dept.id)
            dept_title = truncate_text(dept.title, 40)
            dept_status = dept.status.value if dept.status else ""
            status_sym = "✓" if dept_status == "done" else "○"
            console.print("          │")
            console.print(f"        {dept_id} {status_sym}")
            console.print(f"        {dept_title}")
            console.print(f"        {dept_status}")

    console.print()
    console.print("Legend: ✓ done  • active  ○ backlog")
    console.print()


def render_graph_header(
    workspace_identifier: str,
    console: Console,
) -> None:
    """Render the graph header."""
    console.print()
    console.print("━" * 80)
    console.print(f"  [cyan bold]{workspace_identifier} Dependency Graph[/cyan bold]")
    console.print("━" * 80)
    console.print()


def render_graph_footer(
    total_nodes: int,
    total_edges: int,
    cycles: list[Any],
    console: Console,
) -> None:
    """Render the graph footer."""
    console.print()
    console.print("━" * 80)
    console.print(f"Total: {total_nodes} tasks, {total_edges} dependencies")
    if cycles:
        console.print(
            f"[yellow]⚠ {len(cycles)} circular dependencies detected[/yellow]"
        )
    console.print()
    console.print("[dim]Commands:[/dim]")
    console.print(
        "  [cyan]anyt graph <id>[/cyan]       - Show dependencies for specific task"
    )
    console.print(
        "  [cyan]anyt graph --format dot[/cyan] - Output in DOT format for Graphviz"
    )
    console.print("  [cyan]anyt graph --json[/cyan]       - Output in JSON format")
    console.print()
