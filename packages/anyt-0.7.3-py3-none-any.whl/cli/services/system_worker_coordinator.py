"""System worker coordinator that uses workflow-based execution.

This coordinator executes demo project tasks using a built-in workflow:
1. Filters for demo projects (is_demo=true)
2. Uses the built-in demo_project.yaml workflow (bundled with CLI)
3. Authenticates with WORKER_API_TOKEN

The demo_project.yaml workflow is a built-in workflow that includes:
- Clone repository (anyt/checkout@v1)
- Implement task with Claude Code (anyt/claude-code@v1)
- Commit and push changes (anyt/git-commit@v1)
- Update task status (anyt/task-update@v1)

No custom AI execution logic needed - everything is handled by workflows!
"""

import os
import shutil
import subprocess
from pathlib import Path
from typing import Any, Optional

from rich.markup import escape

from cli.commands.console import console
from cli.client.workers import WorkersAPIClient


class SystemWorkerCoordinator:
    """Coordinator for system worker that executes demo project tasks.

    This coordinator uses a built-in workflow for demo task execution:
    - Uses WORKER_API_TOKEN for authentication (company-level)
    - Filters tasks to demo projects only (is_demo=true)
    - Uses the built-in demo_project.yaml workflow (bundled with CLI)

    The built-in workflow handles the complete task lifecycle:
    - Clone demo repository
    - Implement task with Claude Code
    - Commit and push changes
    - Update task status (done/blocked)

    Example:
        ```python
        coordinator = SystemWorkerCoordinator(
            workspace_dir=Path("/tmp/workspace"),
            poll_interval=10,
        )

        await coordinator.run()
        ```
    """

    def __init__(
        self,
        workspace_dir: Path,
        poll_interval: int = 10,
        max_backoff: int = 60,
    ):
        """Initialize system worker coordinator.

        Args:
            workspace_dir: Working directory for task execution
            poll_interval: Base polling interval in seconds
            max_backoff: Maximum backoff interval in seconds
        """
        self.workspace_dir = workspace_dir
        self.poll_interval = poll_interval
        self.max_backoff = max_backoff

        # Verify WORKER_API_TOKEN
        if not os.getenv("WORKER_API_TOKEN"):
            raise ValueError("WORKER_API_TOKEN environment variable not set")

        # Initialize workers client to verify authentication
        self.workers_client = WorkersAPIClient.from_env()

        # Determine workflows directory
        # Look for demo_project.yaml in:
        # 1. workspace_dir/.anyt/workflows/ (custom override)
        # 2. CLI package's worker/workflows/ (built-in workflow)
        self.workflows_dir = self._find_workflows_dir()

    def _find_workflows_dir(self) -> Path:
        """Find workflows directory containing built-in demo_project.yaml.

        The demo_project.yaml workflow is a built-in workflow bundled with the CLI.
        It can be overridden by placing a custom version in the workspace directory.

        Search order:
        1. Workspace directory (.anyt/workflows/) - for custom overrides
        2. CLI built-in workflows (src/cli/worker/workflows/) - bundled workflow

        Returns:
            Path to workflows directory

        Raises:
            ValueError: If demo_project.yaml not found in either location
        """
        # Try workspace directory first (allows custom override)
        workspace_workflows = self.workspace_dir / ".anyt" / "workflows"
        if (workspace_workflows / "demo_project.yaml").exists():
            return workspace_workflows

        # Use CLI package's built-in workflow (in worker/workflows/)
        cli_package_dir = Path(__file__).parent.parent
        builtin_workflows = cli_package_dir / "worker" / "workflows"
        if (builtin_workflows / "demo_project.yaml").exists():
            return builtin_workflows

        raise ValueError(
            "Built-in demo_project.yaml workflow not found. "
            f"Expected at: {builtin_workflows}\n"
            f"Also checked workspace override at: {workspace_workflows}"
        )

    async def get_next_demo_task(self) -> Optional[dict[str, Any]]:
        """Get next demo task to process.

        This wraps the workers API to get demo tasks.

        Returns:
            Task dict if available, None if no tasks
        """
        tasks = await self.workers_client.list_demo_tasks(status="todo", limit=1)
        return tasks[0].to_generated().model_dump(mode="json") if tasks else None

    async def run(self) -> None:
        """Run system worker polling loop.

        This creates a temporary workspace config and runs the regular
        TaskCoordinator with the demo_project workflow.
        """
        # The system worker uses a specialized approach:
        # Instead of using TaskCoordinator's built-in task polling,
        # we manually poll for demo tasks and execute workflows

        from cli.worker.executor.core import WorkflowExecutor
        from cli.worker.models import Workflow
        from cli.worker.cache import CacheManager
        import yaml
        import asyncio

        cache_manager = CacheManager()

        # Load demo workflow
        workflow_path = self.workflows_dir / "demo_project.yaml"
        with open(workflow_path) as f:
            workflow_data = yaml.safe_load(f)
            workflow = Workflow(**workflow_data)

        console.print("[green]System Worker started[/green]")
        console.print(f"[dim]Workflows dir: {self.workflows_dir}[/dim]")
        console.print(f"[dim]Workflow: {workflow.name}[/dim]")
        console.print(f"[dim]Poll interval: {self.poll_interval}s[/dim]\n")

        current_backoff = float(self.poll_interval)
        stats = {
            "tasks_processed": 0,
            "tasks_succeeded": 0,
            "tasks_failed": 0,
        }

        while True:
            try:
                # Get next demo task
                task_dict = await self.get_next_demo_task()

                if task_dict:
                    # Reset backoff when task found
                    current_backoff = self.poll_interval

                    identifier = task_dict["identifier"]
                    console.print(
                        f"\n[bold green]Found task:[/bold green] {identifier} - {task_dict['title']}"
                    )

                    # Get project info for repository cloning
                    project_id = task_dict.get("project", {}).get("id")
                    if not project_id:
                        console.print("[red]Error: Task missing project.id[/red]")
                        continue

                    # Get workspace_id from task (available at task level)
                    workspace_id = task_dict.get("workspace_id")
                    if not workspace_id:
                        console.print("[red]Error: Task missing workspace_id[/red]")
                        continue

                    # Create task-specific workspace directory
                    task_workspace = self.workspace_dir / f"task-{identifier}"

                    # Clone repository before executing workflow
                    console.print("[cyan]Cloning repository...[/cyan]")
                    clone_info = await self.workers_client.get_clone_info(project_id)
                    await self._clone_repo(clone_info.clone_url, task_workspace)

                    console.print(
                        f"[green]✓[/green] Repository cloned to {task_workspace}"
                    )

                    # Create and checkout a new branch for this task
                    branch_name = identifier.lower()  # e.g., "eyv-2"
                    console.print(f"[cyan]Creating branch: {branch_name}[/cyan]")
                    await self._create_branch(task_workspace, branch_name)

                    console.print(
                        f"[green]✓[/green] Branch {branch_name} created and checked out"
                    )

                    # Create WorkflowExecutor for this task
                    executor = WorkflowExecutor(
                        workspace_id=workspace_id,
                        cache_manager=cache_manager,
                        api_key=os.getenv("WORKER_API_TOKEN"),
                    )

                    # Execute workflow in the cloned repository
                    console.print(f"[cyan]Executing workflow: {workflow.name}[/cyan]")
                    console.print(f"[dim]Task workspace: {task_workspace}[/dim]")

                    try:
                        execution_result = await executor.execute_workflow(
                            workflow=workflow,
                            task=task_dict,
                            workspace_dir=task_workspace,
                        )

                        if execution_result.status == "success":
                            console.print(
                                f"[green]✓[/green] Task {identifier} completed successfully"
                            )
                            stats["tasks_succeeded"] += 1
                        else:
                            console.print(
                                f"[red]✗[/red] Task {identifier} failed (see workflow logs)"
                            )
                            stats["tasks_failed"] += 1

                    except Exception as workflow_error:  # noqa: BLE001 - Intentionally broad: gracefully handle workflow execution errors in background worker loop
                        console.print(
                            f"[red]✗[/red] Workflow execution error: {workflow_error}"
                        )
                        stats["tasks_failed"] += 1

                    finally:
                        stats["tasks_processed"] += 1

                        # Cleanup: Remove cloned repository
                        if task_workspace.exists():
                            try:
                                shutil.rmtree(task_workspace)
                                console.print(
                                    f"[dim]Cleaned up workspace: {task_workspace}[/dim]"
                                )
                            except Exception as cleanup_error:  # noqa: BLE001 - Intentionally broad: best-effort workspace cleanup, don't fail task on cleanup errors
                                console.print(
                                    f"[yellow]Warning: Failed to cleanup {task_workspace}: "
                                    f"{cleanup_error}[/yellow]"
                                )

                else:
                    # Increase backoff when no tasks
                    current_backoff = min(current_backoff * 1.5, self.max_backoff)
                    console.print(
                        f"[dim]No demo tasks available. "
                        f"Next check in {int(current_backoff)}s[/dim]"
                    )

            except Exception as e:  # noqa: BLE001 - Intentionally broad: resilient background worker loop that continues on any error
                console.print(f"[red]Error in worker loop: {escape(str(e))}[/red]")
                stats["tasks_failed"] += 1

            await asyncio.sleep(current_backoff)

    async def _clone_repo(self, clone_url: str, repo_dir: Path) -> None:
        """Clone git repository for task execution.

        Args:
            clone_url: Git clone URL (includes authentication token)
            repo_dir: Directory to clone into

        Raises:
            subprocess.CalledProcessError: If git clone fails
        """
        # Remove existing directory if present
        if repo_dir.exists():
            shutil.rmtree(repo_dir)

        # Ensure parent directory exists
        repo_dir.parent.mkdir(parents=True, exist_ok=True)

        # Clone repository (suppress output to hide credentials)
        result = subprocess.run(
            ["git", "clone", clone_url, str(repo_dir)],
            capture_output=True,
            text=True,
            check=False,
        )

        if result.returncode != 0:
            # Sanitize error message (remove potential credentials)
            error_msg = result.stderr.replace(clone_url, "[REDACTED]")
            raise subprocess.CalledProcessError(
                result.returncode,
                ["git", "clone", "[REDACTED]", str(repo_dir)],
                output=result.stdout,
                stderr=error_msg,
            )

    async def _create_branch(self, repo_dir: Path, branch_name: str) -> None:
        """Create and checkout a new git branch.

        Args:
            repo_dir: Repository directory
            branch_name: Name of the branch to create (e.g., "eyv-2")

        Raises:
            subprocess.CalledProcessError: If git checkout fails
        """
        # Create and checkout new branch from current HEAD
        result = subprocess.run(
            ["git", "checkout", "-b", branch_name],
            cwd=repo_dir,
            capture_output=True,
            text=True,
            check=False,
        )

        if result.returncode != 0:
            raise subprocess.CalledProcessError(
                result.returncode,
                ["git", "checkout", "-b", branch_name],
                output=result.stdout,
                stderr=result.stderr,
            )
