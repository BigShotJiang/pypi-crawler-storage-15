Work on a task using AnyTask cloud task management.

**Argument:** Optional task identifier (e.g., `DEV-42`)

**Workflow:**

1. **Check for active task:**
   ```bash
   anyt active --json
   ```
   - If an active task exists, read its details and local folder at `.anyt/tasks/{IDENTIFIER}/`
   - Review `task.md` for description and `.meta.json` for status
   - Check the `context/` folder for any AI context files
   - Continue implementing based on the task requirements

2. **If no active task and no identifier provided:**
   ```bash
   anyt task suggest --limit 5 --json
   ```
   - Show the suggested tasks to the user
   - Ask which task they want to work on
   - Once selected, pick it:
     ```bash
     anyt task pick {IDENTIFIER}
     ```

3. **If identifier provided:**
   ```bash
   anyt task pick $ARGUMENTS
   ```
   - This will:
     - Set the task status to "active" in the cloud
     - Pull the task to `.anyt/tasks/{IDENTIFIER}/`
     - Set it as the active task locally

4. **Start new branch (if not already on a feature branch):**
   ```bash
   git fetch origin
   git checkout -b {IDENTIFIER}-{short-description}
   ```
   - Always sync with origin before creating branch
   - Use task identifier as branch prefix for traceability
   - Add a short description (e.g., `EOH-136-add-ai-init-option`)
   - If already on a branch for this task, continue working on it

5. **Begin implementation:**
   - Read `.anyt/tasks/{IDENTIFIER}/task.md` for full task details
   - Check `.meta.json` for labels, priority, dependencies
   - Review any files in `context/` folder for additional context
   - Check for quality checklist at `.anyt/tasks/{IDENTIFIER}/context/quality-checklist.md`
     - If it doesn't exist, review codebase for quality check commands and create it
   - Implement the task following the description and acceptance criteria
   - **Update progress with comments as you work:**
     ```bash
     anyt comment add -m "Started implementation of {feature}..."
     anyt comment add -m "Completed {component}, moving to {next step}..."
     anyt comment add -m "Fixed issue with {problem}, now working on {next}..."
     ```
   - Progress comments help track work and provide visibility to the team

6. **Task completion:**
   - **Verify all acceptance criteria are met:**
     - Read the `## Acceptance Criteria` section in `.anyt/tasks/{IDENTIFIER}/task.md`
     - Go through each criterion and verify it is completed
     - Check off each `- [ ]` item as you verify it (update task.md if needed)
     - Do NOT mark task as done if any acceptance criteria are incomplete
   - **Run quality control checklist:**
     - Read `.anyt/tasks/{IDENTIFIER}/context/quality-checklist.md`
     - Execute each command in the checklist
     - Ensure all checks pass before proceeding
   - **Add completion comment:**
     ```bash
     anyt comment add -m "All acceptance criteria verified. Quality checks passed."
     ```
   - Push local task changes if any edits were made to task.md:
     ```bash
     anyt push {IDENTIFIER}
     ```
   - Mark the task as done:
     ```bash
     anyt task done --note "Completed: {summary of what was implemented}"
     ```

7. **Commit changes and create PR:**
   ```bash
   git add -A
   git commit -m "{IDENTIFIER}: {summary}"
   git push -u origin HEAD
   gh pr create --title "{IDENTIFIER}: {title}" --body "$(cat <<'EOF'
   ## Summary
   - Brief description of changes

   ## Task
   - Link to task or task identifier: {IDENTIFIER}

   ## Changes
   - List of key changes made

   ## Test Plan
   - [ ] Quality checklist completed
   - [ ] Manual testing completed

   🤖 Generated with [Claude Code](https://claude.com/claude-code)
   EOF
   )"
   ```
   - PR title MUST include the task identifier
   - PR body should reference the task
   - Return the PR URL to the user

8. **If PR already exists, update it:**
   ```bash
   # Check for existing PR
   gh pr list --head $(git branch --show-current)

   # If PR exists, just push changes
   git add -A
   git commit -m "{IDENTIFIER}: {additional changes}"
   git push

   # Optionally update PR description
   gh pr edit --body "Updated description..."
   ```

**Key Commands Reference:**
- `anyt active` - Show current active task
- `anyt task pick {ID}` - Pick a task to work on (pulls + sets active)
- `anyt task show {ID}` - Show task details
- `anyt task suggest` - Get suggested tasks based on priority/dependencies
- `anyt comment add -m "..."` - Add progress comment
- `anyt task done` - Mark active task as done
- `anyt pull {ID}` - Pull task to local filesystem
- `anyt push {ID}` - Push local changes to cloud
- `anyt task dep list {ID}` - List task dependencies
- `anyt board` - See Kanban view of all tasks

**Important:**
- Use cloud tasks via `anyt` CLI, not local markdown files
- Always check dependencies before starting (`anyt task dep list`)
- Document progress with comments (`anyt comment add`)
- Only one task should be active at a time
- Always include task identifier in branch name and PR title
- Always complete the quality control checklist before marking task as done

Begin working on the task now.
