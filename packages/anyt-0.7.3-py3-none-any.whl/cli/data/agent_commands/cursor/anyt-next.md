Pick the next suggested task to work on from AnyTask cloud.

**Workflow:**

1. **Check for currently active task:**
   ```bash
   anyt active --json
   ```
   - If a task is already active, show it and ask user if they want to:
     - Continue working on the current task
     - Mark it as done first: `anyt task done`
     - Or switch to a different task (current will remain active)

2. **Get suggested tasks:**
   ```bash
   anyt task suggest --limit 5 --json
   ```
   - This returns tasks sorted by priority with all dependencies complete
   - By default shows only unassigned tasks
   - Use `--include-assigned` to see assigned tasks too

3. **Display suggestions:**
   - Show the top suggestions with:
     - Identifier (e.g., DEV-42)
     - Title
     - Priority level
     - Labels
     - Description preview

4. **Pick the top suggestion (or ask user):**
   ```bash
   anyt task pick {IDENTIFIER}
   ```
   - This will:
     - Update task status to "active" in the cloud
     - Pull task to `.anyt/tasks/{IDENTIFIER}/`
     - Set as locally active task

5. **Start new branch:**
   ```bash
   git fetch origin
   git checkout -b {IDENTIFIER}-{short-description}
   ```
   - Always sync with origin before creating branch
   - Use task identifier as branch prefix for traceability
   - Add a short description (e.g., `EOH-136-add-ai-init-option`)

6. **Begin implementation:**
   - Read the task details:
     - `.anyt/tasks/{IDENTIFIER}/task.md` - Full description and acceptance criteria
     - `.anyt/tasks/{IDENTIFIER}/.meta.json` - Status, priority, labels
     - `.anyt/tasks/{IDENTIFIER}/context/` - Any additional context files
   - Check for quality checklist at `.anyt/tasks/{IDENTIFIER}/context/quality-checklist.md`
     - If it doesn't exist, review codebase for quality check commands and create it
   - Implement following the acceptance criteria
   - **Update progress with comments as you work:**
     ```bash
     anyt comment add -m "Started implementation of {feature}..."
     anyt comment add -m "Completed {component}, moving to {next step}..."
     anyt comment add -m "Fixed issue with {problem}, now working on {next}..."
     ```
   - Progress comments help track work and provide visibility to the team

7. **Task completion:**
   - **Verify all acceptance criteria are met:**
     - Read the `## Acceptance Criteria` section in `.anyt/tasks/{IDENTIFIER}/task.md`
     - Go through each criterion and verify it is completed
     - Check off each `- [ ]` item as you verify it (update task.md if needed)
     - Do NOT mark task as done if any acceptance criteria are incomplete
   - **Run quality control checklist:**
     - Read `.anyt/tasks/{IDENTIFIER}/context/quality-checklist.md`
     - Execute each command in the checklist
     - Ensure all checks pass before proceeding
   - **Add completion comment:**
     ```bash
     anyt comment add -m "All acceptance criteria verified. Quality checks passed."
     ```
   - Push local task changes if any edits were made:
     ```bash
     anyt push {IDENTIFIER}
     ```
   - Mark the task as done:
     ```bash
     anyt task done --note "Completed: {summary of what was implemented}"
     ```

8. **Create PR:**
   ```bash
   git add -A
   git commit -m "{IDENTIFIER}: {summary}"
   git push -u origin HEAD
   gh pr create --title "{IDENTIFIER}: {title}" --body "$(cat <<'EOF'
   ## Summary
   - Brief description of changes

   ## Task
   - Link to task or task identifier: {IDENTIFIER}

   ## Changes
   - List of key changes made

   ## Test Plan
   - [ ] Quality checklist completed
   - [ ] Manual testing completed

   🤖 Generated with [Cursor](https://cursor.com)
   EOF
   )"
   ```
   - PR title MUST include the task identifier
   - PR body should reference the task
   - Return the PR URL to the user

**Alternative filters:**
```bash
# Get tasks with specific status
anyt task suggest --status todo,backlog --limit 5

# Include already-assigned tasks
anyt task suggest --include-assigned --limit 5

# Filter by labels (via task list)
anyt task list --status backlog,todo --labels "feature" --limit 5
```

**Key Commands Reference:**
- `anyt active` - Show current active task
- `anyt task pick {ID}` - Pick a task to work on (pulls + sets active)
- `anyt task show {ID}` - Show task details
- `anyt task suggest` - Get suggested tasks based on priority/dependencies
- `anyt comment add -m "..."` - Add progress comment
- `anyt task done` - Mark active task as done
- `anyt pull {ID}` - Pull task to local filesystem
- `anyt push {ID}` - Push local changes to cloud
- `anyt board` - See Kanban view of all tasks

**Important:**
- Tasks are suggested based on priority and dependency completion
- Only tasks with all dependencies completed are suggested
- Current project scope is automatically applied
- Only one task should be active at a time
- Always include task identifier in branch name and PR title
- Always complete the quality control checklist before marking task as done

Begin picking the next task now.
