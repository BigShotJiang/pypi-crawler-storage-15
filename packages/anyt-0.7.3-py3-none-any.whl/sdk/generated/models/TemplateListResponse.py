from typing import *
from pydantic import BaseModel, Field
from .Template import Template

class TemplateListResponse(BaseModel):
    """
    TemplateListResponse model
        Response for template list.
            """
    model_config = {
        "populate_by_name": True,
        "validate_assignment": True
    }
    
    items : List[Template] = Field(validation_alias="items" )
    
    total : int = Field(validation_alias="total" )
    