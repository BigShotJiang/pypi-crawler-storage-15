=======
Credits
=======

Development Leads
-----------------

* Sigurd Naess (@amaurea)
* Mathew Madhavacheril (@msyriac)
* Matthew Hasselfield (@mhasself)

Other Contributors
------------------

* Adri Duivenvoorden
* Alex van Engelen
* Xavier Garrido
* Matt Hilton
* Adrien La Posta
* Simon Foreman
