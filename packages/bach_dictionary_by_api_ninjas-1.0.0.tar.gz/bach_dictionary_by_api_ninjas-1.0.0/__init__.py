"""MCP Server for Dictionary By Api Ninjas"""
