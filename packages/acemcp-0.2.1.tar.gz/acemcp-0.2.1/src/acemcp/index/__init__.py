"""Index management module."""

from acemcp.index.manager import IndexManager

__all__ = ["IndexManager"]
