"""Fixed files that are common for the Instrument drivers and the RsInstrument module."""
