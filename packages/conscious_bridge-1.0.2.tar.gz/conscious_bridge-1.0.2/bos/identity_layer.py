"""
identity_layer.py
Defines the model or human position on the bridge.
"""

class IdentityLayer:
    def __init__(self, role_name="observer"):
        self.role = role_name