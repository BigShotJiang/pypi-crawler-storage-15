# max-bot-api-dlydedica

Python библиотека `max-bot-api-dlydedica` для работы с Max Bot API.

## Установка

```bash
pip install max-bot-api-dlydedica
```
````markdown
# max-bot-api

Python библиотека для работы с Max Bot API.

## Установка

```bash
pip install max-bot-api-dlydedica
```

## Быстрый старт

Пример минимального бота:

```python
import asyncio
from max_bot_api import Bot

# Создаем бота
bot = Bot("YOUR_BOT_TOKEN")

@bot.command("start")
async def start_handler(ctx):
    await ctx.reply(f"Привет, {ctx.user.first_name}!")

async def main():
    await bot.start()

if __name__ == "__main__":
    asyncio.run(main())
```

## Работа с проектом (dev)

Рекомендуется использовать виртуальное окружение. В корне проекта есть `.venv` — чтобы установить dev-зависимости и запустить тесты, выполните:

```powershell
# установить dev-зависимости (однократно)
python -m pip install -e .[dev]

# или, если вы используете уже созданный .venv
.\.venv\Scripts\python.exe -m pip install -e .[dev]
```

## Тесты

Проект содержит тесты, которые проверяют корректность `tools/swagger.json` и его соответствие схемам в `components/schemas`.

Запуск тестов (в примере используется `.venv`):

```powershell
# из корня проекта
.\.venv\Scripts\python.exe -m pytest -v
```

Если `pytest` доступен в PATH, можно запустить просто:

```powershell
python -m pytest -v
```

Результат в моём окружении:

```
33 passed in 0.14s
```

## Генератор тестов по OpenAPI

В проекте есть скрипт `tools/generate_swagger_tests.py`, который парсит `tools/swagger.json` и генерирует подробный набор тестов в `tests/test_generated_swagger.py`.

Использование:

```powershell
# сгенерировать тесты
python .\tools\generate_swagger_tests.py

# после генерации запустить pytest
.\.venv\Scripts\python.exe -m pytest -q
```

Генератор проверяет для каждого эндпоинта:
- наличие `operationId` и `summary`/`description`;
- наличие хотя бы одного успешного (2xx) ответа;
- корректность объявления path-параметров (`in: path` и `required: true`);
- для методов с `requestBody` — наличие `application/json` и существование ссылочных схем (`$ref`);
- для `responses` — корректность ссылок на схемы в `components/schemas`.

## Структура проекта

```
max_bot_api/
├── __init__.py          # Публичный API
├── bot.py               # Класс Bot
├── api.py               # API клиент
├── context.py           # Контекст обработки
├── composer.py          # Композиция middleware
├── middleware.py        # Типы middleware
├── filters.py           # Фильтры обновлений
├── types.py             # Типы данных
└── core/
    ├── client.py        # HTTP клиент
    └── polling.py       # Long polling
```

## Примеры

Смотрите папку `examples/` для полных примеров использования, включая `simple_bot.py` и `chat_bot.py`.

## Лицензия

MIT

## Ссылки

- [Официальная документация Max API](https://dev.max.ru/docs-api)

````