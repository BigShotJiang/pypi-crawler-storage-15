import json
from pathlib import Path
SWAGGER_PATH = Path(__file__).resolve().parents[1] / 'tools' / 'swagger.json'

def load_swagger():
    with open(SWAGGER_PATH, 'r', encoding='utf-8') as f:
        return json.load(f)

def test_get_me():
    swagger = load_swagger()
    paths = swagger.get('paths', {})
    op = paths.get('/me', {}).get('get')
    assert op is not None, 'Operation must exist'
    assert 'operationId' in op and op['operationId'], 'operationId required'
    assert ('summary' in op and op['summary']) or ('description' in op and op['description']), 'summary or description required'
    responses = op.get('responses', {})
    assert responses, 'responses required'
    has_2xx = any(code.startswith('2') for code in responses.keys())
    assert has_2xx or 'default' in responses, 'should have success response'
    for code, resp in responses.items():
        if not isinstance(resp, dict):
            continue
        content = resp.get('content', {})
        if 'application/json' in content:
            sch = content['application/json'].get('schema')
            if sch and isinstance(sch, dict) and '$ref' in sch:
                refn = sch['$ref'].split('/')[-1]
                assert refn in swagger.get('components', {}).get('schemas', {}), f'Response schema {refn} must exist'

def test_get_chats():
    swagger = load_swagger()
    paths = swagger.get('paths', {})
    op = paths.get('/chats', {}).get('get')
    assert op is not None, 'Operation must exist'
    assert 'operationId' in op and op['operationId'], 'operationId required'
    assert ('summary' in op and op['summary']) or ('description' in op and op['description']), 'summary or description required'
    responses = op.get('responses', {})
    assert responses, 'responses required'
    has_2xx = any(code.startswith('2') for code in responses.keys())
    assert has_2xx or 'default' in responses, 'should have success response'
    for code, resp in responses.items():
        if not isinstance(resp, dict):
            continue
        content = resp.get('content', {})
        if 'application/json' in content:
            sch = content['application/json'].get('schema')
            if sch and isinstance(sch, dict) and '$ref' in sch:
                refn = sch['$ref'].split('/')[-1]
                assert refn in swagger.get('components', {}).get('schemas', {}), f'Response schema {refn} must exist'

def test_get_chats_chatLink_():
    swagger = load_swagger()
    paths = swagger.get('paths', {})
    op = paths.get('/chats/{chatLink}', {}).get('get')
    assert op is not None, 'Operation must exist'
    assert 'operationId' in op and op['operationId'], 'operationId required'
    assert ('summary' in op and op['summary']) or ('description' in op and op['description']), 'summary or description required'
    responses = op.get('responses', {})
    assert responses, 'responses required'
    has_2xx = any(code.startswith('2') for code in responses.keys())
    assert has_2xx or 'default' in responses, 'should have success response'
    params = op.get('parameters', [])
    pmap = {p.get('name'): p for p in params}
    assert 'chatLink' in pmap, 'path param chatLink declared'
    assert pmap['chatLink'].get('in') == 'path', 'param in:path'
    assert pmap['chatLink'].get('required', False) is True, 'path param required' 
    for code, resp in responses.items():
        if not isinstance(resp, dict):
            continue
        content = resp.get('content', {})
        if 'application/json' in content:
            sch = content['application/json'].get('schema')
            if sch and isinstance(sch, dict) and '$ref' in sch:
                refn = sch['$ref'].split('/')[-1]
                assert refn in swagger.get('components', {}).get('schemas', {}), f'Response schema {refn} must exist'

def test_get_chats_chatId_():
    swagger = load_swagger()
    paths = swagger.get('paths', {})
    op = paths.get('/chats/{chatId}', {}).get('get')
    assert op is not None, 'Operation must exist'
    assert 'operationId' in op and op['operationId'], 'operationId required'
    assert ('summary' in op and op['summary']) or ('description' in op and op['description']), 'summary or description required'
    responses = op.get('responses', {})
    assert responses, 'responses required'
    has_2xx = any(code.startswith('2') for code in responses.keys())
    assert has_2xx or 'default' in responses, 'should have success response'
    params = op.get('parameters', [])
    pmap = {p.get('name'): p for p in params}
    assert 'chatId' in pmap, 'path param chatId declared'
    assert pmap['chatId'].get('in') == 'path', 'param in:path'
    assert pmap['chatId'].get('required', False) is True, 'path param required' 
    for code, resp in responses.items():
        if not isinstance(resp, dict):
            continue
        content = resp.get('content', {})
        if 'application/json' in content:
            sch = content['application/json'].get('schema')
            if sch and isinstance(sch, dict) and '$ref' in sch:
                refn = sch['$ref'].split('/')[-1]
                assert refn in swagger.get('components', {}).get('schemas', {}), f'Response schema {refn} must exist'

def test_patch_chats_chatId_():
    swagger = load_swagger()
    paths = swagger.get('paths', {})
    op = paths.get('/chats/{chatId}', {}).get('patch')
    assert op is not None, 'Operation must exist'
    assert 'operationId' in op and op['operationId'], 'operationId required'
    assert ('summary' in op and op['summary']) or ('description' in op and op['description']), 'summary or description required'
    responses = op.get('responses', {})
    assert responses, 'responses required'
    has_2xx = any(code.startswith('2') for code in responses.keys())
    assert has_2xx or 'default' in responses, 'should have success response'
    params = op.get('parameters', [])
    pmap = {p.get('name'): p for p in params}
    assert 'chatId' in pmap, 'path param chatId declared'
    assert pmap['chatId'].get('in') == 'path', 'param in:path'
    assert pmap['chatId'].get('required', False) is True, 'path param required' 
    rb = op.get('requestBody')
    assert rb is not None, 'requestBody present'
    content = rb.get('content', {})
    assert 'application/json' in content, 'application/json must be supported for requestBody'
    schema = content['application/json'].get('schema')
    assert schema, 'schema in requestBody application/json'
    if '$ref' in schema:
        ref = schema['$ref']
        refn = ref.split('/')[-1]
        assert refn in swagger.get('components', {}).get('schemas', {}), f'Referenced schema {refn} must exist'
    for code, resp in responses.items():
        if not isinstance(resp, dict):
            continue
        content = resp.get('content', {})
        if 'application/json' in content:
            sch = content['application/json'].get('schema')
            if sch and isinstance(sch, dict) and '$ref' in sch:
                refn = sch['$ref'].split('/')[-1]
                assert refn in swagger.get('components', {}).get('schemas', {}), f'Response schema {refn} must exist'

def test_delete_chats_chatId_():
    swagger = load_swagger()
    paths = swagger.get('paths', {})
    op = paths.get('/chats/{chatId}', {}).get('delete')
    assert op is not None, 'Operation must exist'
    assert 'operationId' in op and op['operationId'], 'operationId required'
    assert ('summary' in op and op['summary']) or ('description' in op and op['description']), 'summary or description required'
    responses = op.get('responses', {})
    assert responses, 'responses required'
    has_2xx = any(code.startswith('2') for code in responses.keys())
    assert has_2xx or 'default' in responses, 'should have success response'
    params = op.get('parameters', [])
    pmap = {p.get('name'): p for p in params}
    assert 'chatId' in pmap, 'path param chatId declared'
    assert pmap['chatId'].get('in') == 'path', 'param in:path'
    assert pmap['chatId'].get('required', False) is True, 'path param required' 
    for code, resp in responses.items():
        if not isinstance(resp, dict):
            continue
        content = resp.get('content', {})
        if 'application/json' in content:
            sch = content['application/json'].get('schema')
            if sch and isinstance(sch, dict) and '$ref' in sch:
                refn = sch['$ref'].split('/')[-1]
                assert refn in swagger.get('components', {}).get('schemas', {}), f'Response schema {refn} must exist'

def test_post_chats_chatId_actions():
    swagger = load_swagger()
    paths = swagger.get('paths', {})
    op = paths.get('/chats/{chatId}/actions', {}).get('post')
    assert op is not None, 'Operation must exist'
    assert 'operationId' in op and op['operationId'], 'operationId required'
    assert ('summary' in op and op['summary']) or ('description' in op and op['description']), 'summary or description required'
    responses = op.get('responses', {})
    assert responses, 'responses required'
    has_2xx = any(code.startswith('2') for code in responses.keys())
    assert has_2xx or 'default' in responses, 'should have success response'
    params = op.get('parameters', [])
    pmap = {p.get('name'): p for p in params}
    assert 'chatId' in pmap, 'path param chatId declared'
    assert pmap['chatId'].get('in') == 'path', 'param in:path'
    assert pmap['chatId'].get('required', False) is True, 'path param required' 
    rb = op.get('requestBody')
    assert rb is not None, 'requestBody present'
    content = rb.get('content', {})
    assert 'application/json' in content, 'application/json must be supported for requestBody'
    schema = content['application/json'].get('schema')
    assert schema, 'schema in requestBody application/json'
    if '$ref' in schema:
        ref = schema['$ref']
        refn = ref.split('/')[-1]
        assert refn in swagger.get('components', {}).get('schemas', {}), f'Referenced schema {refn} must exist'
    for code, resp in responses.items():
        if not isinstance(resp, dict):
            continue
        content = resp.get('content', {})
        if 'application/json' in content:
            sch = content['application/json'].get('schema')
            if sch and isinstance(sch, dict) and '$ref' in sch:
                refn = sch['$ref'].split('/')[-1]
                assert refn in swagger.get('components', {}).get('schemas', {}), f'Response schema {refn} must exist'

def test_get_chats_chatId_pin():
    swagger = load_swagger()
    paths = swagger.get('paths', {})
    op = paths.get('/chats/{chatId}/pin', {}).get('get')
    assert op is not None, 'Operation must exist'
    assert 'operationId' in op and op['operationId'], 'operationId required'
    assert ('summary' in op and op['summary']) or ('description' in op and op['description']), 'summary or description required'
    responses = op.get('responses', {})
    assert responses, 'responses required'
    has_2xx = any(code.startswith('2') for code in responses.keys())
    assert has_2xx or 'default' in responses, 'should have success response'
    params = op.get('parameters', [])
    pmap = {p.get('name'): p for p in params}
    assert 'chatId' in pmap, 'path param chatId declared'
    assert pmap['chatId'].get('in') == 'path', 'param in:path'
    assert pmap['chatId'].get('required', False) is True, 'path param required' 
    for code, resp in responses.items():
        if not isinstance(resp, dict):
            continue
        content = resp.get('content', {})
        if 'application/json' in content:
            sch = content['application/json'].get('schema')
            if sch and isinstance(sch, dict) and '$ref' in sch:
                refn = sch['$ref'].split('/')[-1]
                assert refn in swagger.get('components', {}).get('schemas', {}), f'Response schema {refn} must exist'

def test_put_chats_chatId_pin():
    swagger = load_swagger()
    paths = swagger.get('paths', {})
    op = paths.get('/chats/{chatId}/pin', {}).get('put')
    assert op is not None, 'Operation must exist'
    assert 'operationId' in op and op['operationId'], 'operationId required'
    assert ('summary' in op and op['summary']) or ('description' in op and op['description']), 'summary or description required'
    responses = op.get('responses', {})
    assert responses, 'responses required'
    has_2xx = any(code.startswith('2') for code in responses.keys())
    assert has_2xx or 'default' in responses, 'should have success response'
    params = op.get('parameters', [])
    pmap = {p.get('name'): p for p in params}
    assert 'chatId' in pmap, 'path param chatId declared'
    assert pmap['chatId'].get('in') == 'path', 'param in:path'
    assert pmap['chatId'].get('required', False) is True, 'path param required' 
    rb = op.get('requestBody')
    assert rb is not None, 'requestBody present'
    content = rb.get('content', {})
    assert 'application/json' in content, 'application/json must be supported for requestBody'
    schema = content['application/json'].get('schema')
    assert schema, 'schema in requestBody application/json'
    if '$ref' in schema:
        ref = schema['$ref']
        refn = ref.split('/')[-1]
        assert refn in swagger.get('components', {}).get('schemas', {}), f'Referenced schema {refn} must exist'
    for code, resp in responses.items():
        if not isinstance(resp, dict):
            continue
        content = resp.get('content', {})
        if 'application/json' in content:
            sch = content['application/json'].get('schema')
            if sch and isinstance(sch, dict) and '$ref' in sch:
                refn = sch['$ref'].split('/')[-1]
                assert refn in swagger.get('components', {}).get('schemas', {}), f'Response schema {refn} must exist'

def test_delete_chats_chatId_pin():
    swagger = load_swagger()
    paths = swagger.get('paths', {})
    op = paths.get('/chats/{chatId}/pin', {}).get('delete')
    assert op is not None, 'Operation must exist'
    assert 'operationId' in op and op['operationId'], 'operationId required'
    assert ('summary' in op and op['summary']) or ('description' in op and op['description']), 'summary or description required'
    responses = op.get('responses', {})
    assert responses, 'responses required'
    has_2xx = any(code.startswith('2') for code in responses.keys())
    assert has_2xx or 'default' in responses, 'should have success response'
    params = op.get('parameters', [])
    pmap = {p.get('name'): p for p in params}
    assert 'chatId' in pmap, 'path param chatId declared'
    assert pmap['chatId'].get('in') == 'path', 'param in:path'
    assert pmap['chatId'].get('required', False) is True, 'path param required' 
    for code, resp in responses.items():
        if not isinstance(resp, dict):
            continue
        content = resp.get('content', {})
        if 'application/json' in content:
            sch = content['application/json'].get('schema')
            if sch and isinstance(sch, dict) and '$ref' in sch:
                refn = sch['$ref'].split('/')[-1]
                assert refn in swagger.get('components', {}).get('schemas', {}), f'Response schema {refn} must exist'

def test_get_chats_chatId_members_me():
    swagger = load_swagger()
    paths = swagger.get('paths', {})
    op = paths.get('/chats/{chatId}/members/me', {}).get('get')
    assert op is not None, 'Operation must exist'
    assert 'operationId' in op and op['operationId'], 'operationId required'
    assert ('summary' in op and op['summary']) or ('description' in op and op['description']), 'summary or description required'
    responses = op.get('responses', {})
    assert responses, 'responses required'
    has_2xx = any(code.startswith('2') for code in responses.keys())
    assert has_2xx or 'default' in responses, 'should have success response'
    params = op.get('parameters', [])
    pmap = {p.get('name'): p for p in params}
    assert 'chatId' in pmap, 'path param chatId declared'
    assert pmap['chatId'].get('in') == 'path', 'param in:path'
    assert pmap['chatId'].get('required', False) is True, 'path param required' 
    for code, resp in responses.items():
        if not isinstance(resp, dict):
            continue
        content = resp.get('content', {})
        if 'application/json' in content:
            sch = content['application/json'].get('schema')
            if sch and isinstance(sch, dict) and '$ref' in sch:
                refn = sch['$ref'].split('/')[-1]
                assert refn in swagger.get('components', {}).get('schemas', {}), f'Response schema {refn} must exist'

def test_delete_chats_chatId_members_me():
    swagger = load_swagger()
    paths = swagger.get('paths', {})
    op = paths.get('/chats/{chatId}/members/me', {}).get('delete')
    assert op is not None, 'Operation must exist'
    assert 'operationId' in op and op['operationId'], 'operationId required'
    assert ('summary' in op and op['summary']) or ('description' in op and op['description']), 'summary or description required'
    responses = op.get('responses', {})
    assert responses, 'responses required'
    has_2xx = any(code.startswith('2') for code in responses.keys())
    assert has_2xx or 'default' in responses, 'should have success response'
    params = op.get('parameters', [])
    pmap = {p.get('name'): p for p in params}
    assert 'chatId' in pmap, 'path param chatId declared'
    assert pmap['chatId'].get('in') == 'path', 'param in:path'
    assert pmap['chatId'].get('required', False) is True, 'path param required' 
    for code, resp in responses.items():
        if not isinstance(resp, dict):
            continue
        content = resp.get('content', {})
        if 'application/json' in content:
            sch = content['application/json'].get('schema')
            if sch and isinstance(sch, dict) and '$ref' in sch:
                refn = sch['$ref'].split('/')[-1]
                assert refn in swagger.get('components', {}).get('schemas', {}), f'Response schema {refn} must exist'

def test_get_chats_chatId_members_admins():
    swagger = load_swagger()
    paths = swagger.get('paths', {})
    op = paths.get('/chats/{chatId}/members/admins', {}).get('get')
    assert op is not None, 'Operation must exist'
    assert 'operationId' in op and op['operationId'], 'operationId required'
    assert ('summary' in op and op['summary']) or ('description' in op and op['description']), 'summary or description required'
    responses = op.get('responses', {})
    assert responses, 'responses required'
    has_2xx = any(code.startswith('2') for code in responses.keys())
    assert has_2xx or 'default' in responses, 'should have success response'
    params = op.get('parameters', [])
    pmap = {p.get('name'): p for p in params}
    assert 'chatId' in pmap, 'path param chatId declared'
    assert pmap['chatId'].get('in') == 'path', 'param in:path'
    assert pmap['chatId'].get('required', False) is True, 'path param required' 
    for code, resp in responses.items():
        if not isinstance(resp, dict):
            continue
        content = resp.get('content', {})
        if 'application/json' in content:
            sch = content['application/json'].get('schema')
            if sch and isinstance(sch, dict) and '$ref' in sch:
                refn = sch['$ref'].split('/')[-1]
                assert refn in swagger.get('components', {}).get('schemas', {}), f'Response schema {refn} must exist'

def test_post_chats_chatId_members_admins():
    swagger = load_swagger()
    paths = swagger.get('paths', {})
    op = paths.get('/chats/{chatId}/members/admins', {}).get('post')
    assert op is not None, 'Operation must exist'
    assert 'operationId' in op and op['operationId'], 'operationId required'
    assert ('summary' in op and op['summary']) or ('description' in op and op['description']), 'summary or description required'
    responses = op.get('responses', {})
    assert responses, 'responses required'
    has_2xx = any(code.startswith('2') for code in responses.keys())
    assert has_2xx or 'default' in responses, 'should have success response'
    params = op.get('parameters', [])
    pmap = {p.get('name'): p for p in params}
    assert 'chatId' in pmap, 'path param chatId declared'
    assert pmap['chatId'].get('in') == 'path', 'param in:path'
    assert pmap['chatId'].get('required', False) is True, 'path param required' 
    rb = op.get('requestBody')
    assert rb is not None, 'requestBody present'
    content = rb.get('content', {})
    assert 'application/json' in content, 'application/json must be supported for requestBody'
    schema = content['application/json'].get('schema')
    assert schema, 'schema in requestBody application/json'
    if '$ref' in schema:
        ref = schema['$ref']
        refn = ref.split('/')[-1]
        assert refn in swagger.get('components', {}).get('schemas', {}), f'Referenced schema {refn} must exist'
    for code, resp in responses.items():
        if not isinstance(resp, dict):
            continue
        content = resp.get('content', {})
        if 'application/json' in content:
            sch = content['application/json'].get('schema')
            if sch and isinstance(sch, dict) and '$ref' in sch:
                refn = sch['$ref'].split('/')[-1]
                assert refn in swagger.get('components', {}).get('schemas', {}), f'Response schema {refn} must exist'

def test_delete_chats_chatId_members_admins_userId_():
    swagger = load_swagger()
    paths = swagger.get('paths', {})
    op = paths.get('/chats/{chatId}/members/admins/{userId}', {}).get('delete')
    assert op is not None, 'Operation must exist'
    assert 'operationId' in op and op['operationId'], 'operationId required'
    assert ('summary' in op and op['summary']) or ('description' in op and op['description']), 'summary or description required'
    responses = op.get('responses', {})
    assert responses, 'responses required'
    has_2xx = any(code.startswith('2') for code in responses.keys())
    assert has_2xx or 'default' in responses, 'should have success response'
    params = op.get('parameters', [])
    pmap = {p.get('name'): p for p in params}
    assert 'chatId' in pmap, 'path param chatId declared'
    assert pmap['chatId'].get('in') == 'path', 'param in:path'
    assert pmap['chatId'].get('required', False) is True, 'path param required' 
    pmap = {p.get('name'): p for p in params}
    assert 'userId' in pmap, 'path param userId declared'
    assert pmap['userId'].get('in') == 'path', 'param in:path'
    assert pmap['userId'].get('required', False) is True, 'path param required' 
    for code, resp in responses.items():
        if not isinstance(resp, dict):
            continue
        content = resp.get('content', {})
        if 'application/json' in content:
            sch = content['application/json'].get('schema')
            if sch and isinstance(sch, dict) and '$ref' in sch:
                refn = sch['$ref'].split('/')[-1]
                assert refn in swagger.get('components', {}).get('schemas', {}), f'Response schema {refn} must exist'

def test_get_chats_chatId_members():
    swagger = load_swagger()
    paths = swagger.get('paths', {})
    op = paths.get('/chats/{chatId}/members', {}).get('get')
    assert op is not None, 'Operation must exist'
    assert 'operationId' in op and op['operationId'], 'operationId required'
    assert ('summary' in op and op['summary']) or ('description' in op and op['description']), 'summary or description required'
    responses = op.get('responses', {})
    assert responses, 'responses required'
    has_2xx = any(code.startswith('2') for code in responses.keys())
    assert has_2xx or 'default' in responses, 'should have success response'
    params = op.get('parameters', [])
    pmap = {p.get('name'): p for p in params}
    assert 'chatId' in pmap, 'path param chatId declared'
    assert pmap['chatId'].get('in') == 'path', 'param in:path'
    assert pmap['chatId'].get('required', False) is True, 'path param required' 
    for code, resp in responses.items():
        if not isinstance(resp, dict):
            continue
        content = resp.get('content', {})
        if 'application/json' in content:
            sch = content['application/json'].get('schema')
            if sch and isinstance(sch, dict) and '$ref' in sch:
                refn = sch['$ref'].split('/')[-1]
                assert refn in swagger.get('components', {}).get('schemas', {}), f'Response schema {refn} must exist'

def test_post_chats_chatId_members():
    swagger = load_swagger()
    paths = swagger.get('paths', {})
    op = paths.get('/chats/{chatId}/members', {}).get('post')
    assert op is not None, 'Operation must exist'
    assert 'operationId' in op and op['operationId'], 'operationId required'
    assert ('summary' in op and op['summary']) or ('description' in op and op['description']), 'summary or description required'
    responses = op.get('responses', {})
    assert responses, 'responses required'
    has_2xx = any(code.startswith('2') for code in responses.keys())
    assert has_2xx or 'default' in responses, 'should have success response'
    params = op.get('parameters', [])
    pmap = {p.get('name'): p for p in params}
    assert 'chatId' in pmap, 'path param chatId declared'
    assert pmap['chatId'].get('in') == 'path', 'param in:path'
    assert pmap['chatId'].get('required', False) is True, 'path param required' 
    rb = op.get('requestBody')
    assert rb is not None, 'requestBody present'
    content = rb.get('content', {})
    assert 'application/json' in content, 'application/json must be supported for requestBody'
    schema = content['application/json'].get('schema')
    assert schema, 'schema in requestBody application/json'
    if '$ref' in schema:
        ref = schema['$ref']
        refn = ref.split('/')[-1]
        assert refn in swagger.get('components', {}).get('schemas', {}), f'Referenced schema {refn} must exist'
    for code, resp in responses.items():
        if not isinstance(resp, dict):
            continue
        content = resp.get('content', {})
        if 'application/json' in content:
            sch = content['application/json'].get('schema')
            if sch and isinstance(sch, dict) and '$ref' in sch:
                refn = sch['$ref'].split('/')[-1]
                assert refn in swagger.get('components', {}).get('schemas', {}), f'Response schema {refn} must exist'

def test_delete_chats_chatId_members():
    swagger = load_swagger()
    paths = swagger.get('paths', {})
    op = paths.get('/chats/{chatId}/members', {}).get('delete')
    assert op is not None, 'Operation must exist'
    assert 'operationId' in op and op['operationId'], 'operationId required'
    assert ('summary' in op and op['summary']) or ('description' in op and op['description']), 'summary or description required'
    responses = op.get('responses', {})
    assert responses, 'responses required'
    has_2xx = any(code.startswith('2') for code in responses.keys())
    assert has_2xx or 'default' in responses, 'should have success response'
    params = op.get('parameters', [])
    pmap = {p.get('name'): p for p in params}
    assert 'chatId' in pmap, 'path param chatId declared'
    assert pmap['chatId'].get('in') == 'path', 'param in:path'
    assert pmap['chatId'].get('required', False) is True, 'path param required' 
    for code, resp in responses.items():
        if not isinstance(resp, dict):
            continue
        content = resp.get('content', {})
        if 'application/json' in content:
            sch = content['application/json'].get('schema')
            if sch and isinstance(sch, dict) and '$ref' in sch:
                refn = sch['$ref'].split('/')[-1]
                assert refn in swagger.get('components', {}).get('schemas', {}), f'Response schema {refn} must exist'

def test_get_subscriptions():
    swagger = load_swagger()
    paths = swagger.get('paths', {})
    op = paths.get('/subscriptions', {}).get('get')
    assert op is not None, 'Operation must exist'
    assert 'operationId' in op and op['operationId'], 'operationId required'
    assert ('summary' in op and op['summary']) or ('description' in op and op['description']), 'summary or description required'
    responses = op.get('responses', {})
    assert responses, 'responses required'
    has_2xx = any(code.startswith('2') for code in responses.keys())
    assert has_2xx or 'default' in responses, 'should have success response'
    for code, resp in responses.items():
        if not isinstance(resp, dict):
            continue
        content = resp.get('content', {})
        if 'application/json' in content:
            sch = content['application/json'].get('schema')
            if sch and isinstance(sch, dict) and '$ref' in sch:
                refn = sch['$ref'].split('/')[-1]
                assert refn in swagger.get('components', {}).get('schemas', {}), f'Response schema {refn} must exist'

def test_post_subscriptions():
    swagger = load_swagger()
    paths = swagger.get('paths', {})
    op = paths.get('/subscriptions', {}).get('post')
    assert op is not None, 'Operation must exist'
    assert 'operationId' in op and op['operationId'], 'operationId required'
    assert ('summary' in op and op['summary']) or ('description' in op and op['description']), 'summary or description required'
    responses = op.get('responses', {})
    assert responses, 'responses required'
    has_2xx = any(code.startswith('2') for code in responses.keys())
    assert has_2xx or 'default' in responses, 'should have success response'
    rb = op.get('requestBody')
    assert rb is not None, 'requestBody present'
    content = rb.get('content', {})
    assert 'application/json' in content, 'application/json must be supported for requestBody'
    schema = content['application/json'].get('schema')
    assert schema, 'schema in requestBody application/json'
    if '$ref' in schema:
        ref = schema['$ref']
        refn = ref.split('/')[-1]
        assert refn in swagger.get('components', {}).get('schemas', {}), f'Referenced schema {refn} must exist'
    for code, resp in responses.items():
        if not isinstance(resp, dict):
            continue
        content = resp.get('content', {})
        if 'application/json' in content:
            sch = content['application/json'].get('schema')
            if sch and isinstance(sch, dict) and '$ref' in sch:
                refn = sch['$ref'].split('/')[-1]
                assert refn in swagger.get('components', {}).get('schemas', {}), f'Response schema {refn} must exist'

def test_delete_subscriptions():
    swagger = load_swagger()
    paths = swagger.get('paths', {})
    op = paths.get('/subscriptions', {}).get('delete')
    assert op is not None, 'Operation must exist'
    assert 'operationId' in op and op['operationId'], 'operationId required'
    assert ('summary' in op and op['summary']) or ('description' in op and op['description']), 'summary or description required'
    responses = op.get('responses', {})
    assert responses, 'responses required'
    has_2xx = any(code.startswith('2') for code in responses.keys())
    assert has_2xx or 'default' in responses, 'should have success response'
    for code, resp in responses.items():
        if not isinstance(resp, dict):
            continue
        content = resp.get('content', {})
        if 'application/json' in content:
            sch = content['application/json'].get('schema')
            if sch and isinstance(sch, dict) and '$ref' in sch:
                refn = sch['$ref'].split('/')[-1]
                assert refn in swagger.get('components', {}).get('schemas', {}), f'Response schema {refn} must exist'

def test_post_uploads():
    swagger = load_swagger()
    paths = swagger.get('paths', {})
    op = paths.get('/uploads', {}).get('post')
    assert op is not None, 'Operation must exist'
    assert 'operationId' in op and op['operationId'], 'operationId required'
    assert ('summary' in op and op['summary']) or ('description' in op and op['description']), 'summary or description required'
    responses = op.get('responses', {})
    assert responses, 'responses required'
    has_2xx = any(code.startswith('2') for code in responses.keys())
    assert has_2xx or 'default' in responses, 'should have success response'
    for code, resp in responses.items():
        if not isinstance(resp, dict):
            continue
        content = resp.get('content', {})
        if 'application/json' in content:
            sch = content['application/json'].get('schema')
            if sch and isinstance(sch, dict) and '$ref' in sch:
                refn = sch['$ref'].split('/')[-1]
                assert refn in swagger.get('components', {}).get('schemas', {}), f'Response schema {refn} must exist'

def test_get_messages():
    swagger = load_swagger()
    paths = swagger.get('paths', {})
    op = paths.get('/messages', {}).get('get')
    assert op is not None, 'Operation must exist'
    assert 'operationId' in op and op['operationId'], 'operationId required'
    assert ('summary' in op and op['summary']) or ('description' in op and op['description']), 'summary or description required'
    responses = op.get('responses', {})
    assert responses, 'responses required'
    has_2xx = any(code.startswith('2') for code in responses.keys())
    assert has_2xx or 'default' in responses, 'should have success response'
    for code, resp in responses.items():
        if not isinstance(resp, dict):
            continue
        content = resp.get('content', {})
        if 'application/json' in content:
            sch = content['application/json'].get('schema')
            if sch and isinstance(sch, dict) and '$ref' in sch:
                refn = sch['$ref'].split('/')[-1]
                assert refn in swagger.get('components', {}).get('schemas', {}), f'Response schema {refn} must exist'

def test_post_messages():
    swagger = load_swagger()
    paths = swagger.get('paths', {})
    op = paths.get('/messages', {}).get('post')
    assert op is not None, 'Operation must exist'
    assert 'operationId' in op and op['operationId'], 'operationId required'
    assert ('summary' in op and op['summary']) or ('description' in op and op['description']), 'summary or description required'
    responses = op.get('responses', {})
    assert responses, 'responses required'
    has_2xx = any(code.startswith('2') for code in responses.keys())
    assert has_2xx or 'default' in responses, 'should have success response'
    rb = op.get('requestBody')
    assert rb is not None, 'requestBody present'
    content = rb.get('content', {})
    assert 'application/json' in content, 'application/json must be supported for requestBody'
    schema = content['application/json'].get('schema')
    assert schema, 'schema in requestBody application/json'
    if '$ref' in schema:
        ref = schema['$ref']
        refn = ref.split('/')[-1]
        assert refn in swagger.get('components', {}).get('schemas', {}), f'Referenced schema {refn} must exist'
    for code, resp in responses.items():
        if not isinstance(resp, dict):
            continue
        content = resp.get('content', {})
        if 'application/json' in content:
            sch = content['application/json'].get('schema')
            if sch and isinstance(sch, dict) and '$ref' in sch:
                refn = sch['$ref'].split('/')[-1]
                assert refn in swagger.get('components', {}).get('schemas', {}), f'Response schema {refn} must exist'

def test_put_messages():
    swagger = load_swagger()
    paths = swagger.get('paths', {})
    op = paths.get('/messages', {}).get('put')
    assert op is not None, 'Operation must exist'
    assert 'operationId' in op and op['operationId'], 'operationId required'
    assert ('summary' in op and op['summary']) or ('description' in op and op['description']), 'summary or description required'
    responses = op.get('responses', {})
    assert responses, 'responses required'
    has_2xx = any(code.startswith('2') for code in responses.keys())
    assert has_2xx or 'default' in responses, 'should have success response'
    rb = op.get('requestBody')
    assert rb is not None, 'requestBody present'
    content = rb.get('content', {})
    assert 'application/json' in content, 'application/json must be supported for requestBody'
    schema = content['application/json'].get('schema')
    assert schema, 'schema in requestBody application/json'
    if '$ref' in schema:
        ref = schema['$ref']
        refn = ref.split('/')[-1]
        assert refn in swagger.get('components', {}).get('schemas', {}), f'Referenced schema {refn} must exist'
    for code, resp in responses.items():
        if not isinstance(resp, dict):
            continue
        content = resp.get('content', {})
        if 'application/json' in content:
            sch = content['application/json'].get('schema')
            if sch and isinstance(sch, dict) and '$ref' in sch:
                refn = sch['$ref'].split('/')[-1]
                assert refn in swagger.get('components', {}).get('schemas', {}), f'Response schema {refn} must exist'

def test_delete_messages():
    swagger = load_swagger()
    paths = swagger.get('paths', {})
    op = paths.get('/messages', {}).get('delete')
    assert op is not None, 'Operation must exist'
    assert 'operationId' in op and op['operationId'], 'operationId required'
    assert ('summary' in op and op['summary']) or ('description' in op and op['description']), 'summary or description required'
    responses = op.get('responses', {})
    assert responses, 'responses required'
    has_2xx = any(code.startswith('2') for code in responses.keys())
    assert has_2xx or 'default' in responses, 'should have success response'
    for code, resp in responses.items():
        if not isinstance(resp, dict):
            continue
        content = resp.get('content', {})
        if 'application/json' in content:
            sch = content['application/json'].get('schema')
            if sch and isinstance(sch, dict) and '$ref' in sch:
                refn = sch['$ref'].split('/')[-1]
                assert refn in swagger.get('components', {}).get('schemas', {}), f'Response schema {refn} must exist'

def test_get_messages_messageId_():
    swagger = load_swagger()
    paths = swagger.get('paths', {})
    op = paths.get('/messages/{messageId}', {}).get('get')
    assert op is not None, 'Operation must exist'
    assert 'operationId' in op and op['operationId'], 'operationId required'
    assert ('summary' in op and op['summary']) or ('description' in op and op['description']), 'summary or description required'
    responses = op.get('responses', {})
    assert responses, 'responses required'
    has_2xx = any(code.startswith('2') for code in responses.keys())
    assert has_2xx or 'default' in responses, 'should have success response'
    params = op.get('parameters', [])
    pmap = {p.get('name'): p for p in params}
    assert 'messageId' in pmap, 'path param messageId declared'
    assert pmap['messageId'].get('in') == 'path', 'param in:path'
    assert pmap['messageId'].get('required', False) is True, 'path param required' 
    for code, resp in responses.items():
        if not isinstance(resp, dict):
            continue
        content = resp.get('content', {})
        if 'application/json' in content:
            sch = content['application/json'].get('schema')
            if sch and isinstance(sch, dict) and '$ref' in sch:
                refn = sch['$ref'].split('/')[-1]
                assert refn in swagger.get('components', {}).get('schemas', {}), f'Response schema {refn} must exist'

def test_get_videos_videoToken_():
    swagger = load_swagger()
    paths = swagger.get('paths', {})
    op = paths.get('/videos/{videoToken}', {}).get('get')
    assert op is not None, 'Operation must exist'
    assert 'operationId' in op and op['operationId'], 'operationId required'
    assert ('summary' in op and op['summary']) or ('description' in op and op['description']), 'summary or description required'
    responses = op.get('responses', {})
    assert responses, 'responses required'
    has_2xx = any(code.startswith('2') for code in responses.keys())
    assert has_2xx or 'default' in responses, 'should have success response'
    params = op.get('parameters', [])
    pmap = {p.get('name'): p for p in params}
    assert 'videoToken' in pmap, 'path param videoToken declared'
    assert pmap['videoToken'].get('in') == 'path', 'param in:path'
    assert pmap['videoToken'].get('required', False) is True, 'path param required' 
    for code, resp in responses.items():
        if not isinstance(resp, dict):
            continue
        content = resp.get('content', {})
        if 'application/json' in content:
            sch = content['application/json'].get('schema')
            if sch and isinstance(sch, dict) and '$ref' in sch:
                refn = sch['$ref'].split('/')[-1]
                assert refn in swagger.get('components', {}).get('schemas', {}), f'Response schema {refn} must exist'

def test_post_answers():
    swagger = load_swagger()
    paths = swagger.get('paths', {})
    op = paths.get('/answers', {}).get('post')
    assert op is not None, 'Operation must exist'
    assert 'operationId' in op and op['operationId'], 'operationId required'
    assert ('summary' in op and op['summary']) or ('description' in op and op['description']), 'summary or description required'
    responses = op.get('responses', {})
    assert responses, 'responses required'
    has_2xx = any(code.startswith('2') for code in responses.keys())
    assert has_2xx or 'default' in responses, 'should have success response'
    rb = op.get('requestBody')
    assert rb is not None, 'requestBody present'
    content = rb.get('content', {})
    assert 'application/json' in content, 'application/json must be supported for requestBody'
    schema = content['application/json'].get('schema')
    assert schema, 'schema in requestBody application/json'
    if '$ref' in schema:
        ref = schema['$ref']
        refn = ref.split('/')[-1]
        assert refn in swagger.get('components', {}).get('schemas', {}), f'Referenced schema {refn} must exist'
    for code, resp in responses.items():
        if not isinstance(resp, dict):
            continue
        content = resp.get('content', {})
        if 'application/json' in content:
            sch = content['application/json'].get('schema')
            if sch and isinstance(sch, dict) and '$ref' in sch:
                refn = sch['$ref'].split('/')[-1]
                assert refn in swagger.get('components', {}).get('schemas', {}), f'Response schema {refn} must exist'

def test_get_updates():
    swagger = load_swagger()
    paths = swagger.get('paths', {})
    op = paths.get('/updates', {}).get('get')
    assert op is not None, 'Operation must exist'
    assert 'operationId' in op and op['operationId'], 'operationId required'
    assert ('summary' in op and op['summary']) or ('description' in op and op['description']), 'summary or description required'
    responses = op.get('responses', {})
    assert responses, 'responses required'
    has_2xx = any(code.startswith('2') for code in responses.keys())
    assert has_2xx or 'default' in responses, 'should have success response'
    for code, resp in responses.items():
        if not isinstance(resp, dict):
            continue
        content = resp.get('content', {})
        if 'application/json' in content:
            sch = content['application/json'].get('schema')
            if sch and isinstance(sch, dict) and '$ref' in sch:
                refn = sch['$ref'].split('/')[-1]
                assert refn in swagger.get('components', {}).get('schemas', {}), f'Response schema {refn} must exist'
