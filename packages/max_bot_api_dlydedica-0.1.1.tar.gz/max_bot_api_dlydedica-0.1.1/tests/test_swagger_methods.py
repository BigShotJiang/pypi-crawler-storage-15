import json
from pathlib import Path


SWAGGER_PATH = Path(__file__).resolve().parents[1] / "tools" / "swagger.json"


def load_swagger():
    with open(SWAGGER_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def collect_operations(swagger):
    ops = []
    paths = swagger.get("paths", {})
    for path, methods in paths.items():
        for method, op in methods.items():
            if not isinstance(op, dict):
                continue
            ops.append((path, method.upper(), op))
    return ops


def test_swagger_file_exists():
    assert SWAGGER_PATH.exists(), f"Swagger file not found at {SWAGGER_PATH}"


def test_each_operation_has_operationId_and_responses():
    swagger = load_swagger()
    ops = collect_operations(swagger)
    assert ops, "No operations found in swagger.json"
    for path, method, op in ops:
        # operationId
        assert "operationId" in op and op["operationId"], (
            f"Operation {method} {path} must have non-empty operationId"
        )

        # summary or description exists
        assert ("summary" in op and op["summary"]) or (
            "description" in op and op["description"]
        ), f"Operation {method} {path} should have summary or description"

        # responses must contain at least one 2xx or default success response
        responses = op.get("responses", {})
        assert responses, f"Operation {method} {path} has no responses defined"

        has_2xx = any(code.startswith("2") for code in responses.keys())
        assert has_2xx or "default" in responses, (
            f"Operation {method} {path} must define a successful (2xx) response or default"
        )


def test_path_parameters_marked_required():
    swagger = load_swagger()
    paths = swagger.get("paths", {})
    for path, methods in paths.items():
        # collect path parameter names like {chatId}
        import re

        path_params = re.findall(r"\{([^}]+)\}", path)
        if not path_params:
            continue
        for method, op in methods.items():
            params = op.get("parameters", [])
            param_names = {p.get("name"): p for p in params}
            for pname in path_params:
                assert pname in param_names, (
                    f"Path param {{{pname}}} is used in path {path} but not declared in parameters for {method.upper()} {path}"
                )
                assert param_names[pname].get("in") == "path", (
                    f"Parameter {pname} for {method.upper()} {path} must be 'in: path'"
                )
                assert param_names[pname].get("required", False) is True, (
                    f"Path parameter {pname} for {method.upper()} {path} should be required"
                )
