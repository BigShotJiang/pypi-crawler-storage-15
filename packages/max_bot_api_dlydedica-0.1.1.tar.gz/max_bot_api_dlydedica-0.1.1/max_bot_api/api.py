"""
API клиент для Max Bot.

Модуль содержит высокоуровневые методы для работы с Max Bot API.
"""

from typing import List, Optional, Dict, Any, Union

from .core.client import Client
from .types import (
    Chat,
    Message,
    SenderAction,
    UpdateType,
    User,
)


class Api:
    """
    API клиент для Max Bot.
    
    Предоставляет удобные методы для работы с API.
    """
    
    def __init__(self, client: Client):
        """
        Инициализация API клиента.
        
        Args:
            client: HTTP клиент
        """
        self.client = client
    
    # ========================================================================
    # Bot methods
    # ========================================================================
    
    async def get_my_info(self) -> Dict[str, Any]:
        """Получить информацию о боте."""
        return await self.client.call("/me")
    
    async def edit_my_info(self, **extra: Any) -> Dict[str, Any]:
        """
        Редактировать информацию о боте.
        
        Args:
            **extra: Параметры для обновления
            
        Returns:
            Обновленная информация о боте
        """
        return await self.client.call(
            "/me",
            http_method="PATCH",
            body=extra
        )
    
    async def set_my_commands(self, commands: List[Dict[str, str]]) -> Dict[str, Any]:
        """
        Установить список команд бота.
        
        Args:
            commands: Список команд [{"name": "start", "description": "..."}]
            
        Returns:
            Результат операции
        """
        return await self.edit_my_info(commands=commands)
    
    async def delete_my_commands(self) -> Dict[str, Any]:
        """Удалить все команды бота."""
        return await self.edit_my_info(commands=[])
    
    # ========================================================================
    # Chat methods
    # ========================================================================
    
    async def get_all_chats(self, **extra: Any) -> List[Chat]:
        """
        Получить все чаты бота.
        
        Args:
            **extra: Дополнительные параметры
            
        Returns:
            Список чатов
        """
        response = await self.client.call(
            "/chats",
            query=extra
        )
        return response.get("chats", [])
    
    async def get_chat(self, chat_id: int) -> Chat:
        """
        Получить информацию о чате.
        
        Args:
            chat_id: ID чата
            
        Returns:
            Информация о чате
        """
        return await self.client.call(
            "/chats/{chat_id}",
            path={"chat_id": chat_id}
        )
    
    async def get_chat_by_link(self, link: str) -> Chat:
        """
        Получить чат по ссылке.
        
        Args:
            link: Ссылка на чат
            
        Returns:
            Информация о чате
        """
        return await self.client.call(
            "/chats/link",
            query={"chat_link": link}
        )
    
    async def edit_chat_info(self, chat_id: int, **extra: Any) -> Dict[str, Any]:
        """
        Редактировать информацию о чате.
        
        Args:
            chat_id: ID чата
            **extra: Параметры для обновления
            
        Returns:
            Результат операции
        """
        return await self.client.call(
            "/chats/{chat_id}",
            http_method="PATCH",
            path={"chat_id": chat_id},
            body=extra
        )
    
    async def get_chat_membership(self, chat_id: int) -> Dict[str, Any]:
        """Получить информацию о членстве в чате."""
        return await self.client.call(
            "/chats/{chat_id}/members/me",
            path={"chat_id": chat_id}
        )
    
    async def get_chat_admins(self, chat_id: int) -> List[User]:
        """Получить список администраторов чата."""
        response = await self.client.call(
            "/chats/{chat_id}/members/admins",
            path={"chat_id": chat_id}
        )
        return response.get("members", [])
    
    async def add_chat_members(
        self,
        chat_id: int,
        user_ids: List[int]
    ) -> Dict[str, Any]:
        """
        Добавить участников в чат.
        
        Args:
            chat_id: ID чата
            user_ids: Список ID пользователей
            
        Returns:
            Результат операции
        """
        return await self.client.call(
            "/chats/{chat_id}/members",
            http_method="POST",
            path={"chat_id": chat_id},
            body={"user_ids": user_ids}
        )
    
    async def get_chat_members(
        self,
        chat_id: int,
        **extra: Any
    ) -> List[User]:
        """
        Получить список участников чата.
        
        Args:
            chat_id: ID чата
            **extra: Дополнительные параметры
            
        Returns:
            Список участников
        """
        # Преобразуем user_ids в строку если есть
        query = extra.copy()
        if "user_ids" in query and isinstance(query["user_ids"], list):
            query["user_ids"] = ",".join(map(str, query["user_ids"]))
        
        response = await self.client.call(
            "/chats/{chat_id}/members",
            path={"chat_id": chat_id},
            query=query
        )
        return response.get("members", [])
    
    async def remove_chat_member(
        self,
        chat_id: int,
        user_id: int
    ) -> Dict[str, Any]:
        """
        Удалить участника из чата.
        
        Args:
            chat_id: ID чата
            user_id: ID пользователя
            
        Returns:
            Результат операции
        """
        return await self.client.call(
            "/chats/{chat_id}/members",
            http_method="DELETE",
            path={"chat_id": chat_id},
            body={"user_id": user_id}
        )
    
    async def leave_chat(self, chat_id: int) -> Dict[str, Any]:
        """
        Покинуть чат.
        
        Args:
            chat_id: ID чата
            
        Returns:
            Результат операции
        """
        return await self.client.call(
            "/chats/{chat_id}/members/me",
            http_method="DELETE",
            path={"chat_id": chat_id}
        )
    
    async def send_action(
        self,
        chat_id: int,
        action: SenderAction
    ) -> Dict[str, Any]:
        """
        Отправить действие в чат (typing, и т.д.).
        
        Args:
            chat_id: ID чата
            action: Тип действия
            
        Returns:
            Результат операции
        """
        return await self.client.call(
            "/chats/{chat_id}/actions",
            http_method="POST",
            path={"chat_id": chat_id},
            body={"action": action}
        )
    
    # ========================================================================
    # Message methods
    # ========================================================================
    
    async def send_message_to_chat(
        self,
        chat_id: int,
        text: str,
        **extra: Any
    ) -> Message:
        """
        Отправить сообщение в чат.
        
        Args:
            chat_id: ID чата
            text: Текст сообщения
            **extra: Дополнительные параметры (attachments, notify, etc.)
            
        Returns:
            Отправленное сообщение
        """
        response = await self.client.call(
            "/messages",
            http_method="POST",
            query={"chat_id": chat_id},
            body={"text": text, **extra}
        )
        return response.get("message")
    
    async def send_message_to_user(
        self,
        user_id: int,
        text: str,
        **extra: Any
    ) -> Message:
        """
        Отправить сообщение пользователю.
        
        Args:
            user_id: ID пользователя
            text: Текст сообщения
            **extra: Дополнительные параметры (attachments, notify, etc.)
            
        Returns:
            Отправленное сообщение
        """
        response = await self.client.call(
            "/messages",
            http_method="POST",
            query={"user_id": user_id},
            body={"text": text, **extra}
        )
        return response.get("message")
    
    async def get_messages(
        self,
        chat_id: int,
        **extra: Any
    ) -> List[Message]:
        """
        Получить сообщения из чата.
        
        Args:
            chat_id: ID чата
            **extra: Дополнительные параметры
            
        Returns:
            Список сообщений
        """
        # Преобразуем message_ids в строку если есть
        query = {"chat_id": chat_id, **extra}
        if "message_ids" in query and isinstance(query["message_ids"], list):
            query["message_ids"] = ",".join(query["message_ids"])
        
        response = await self.client.call(
            "/messages",
            query=query
        )
        return response.get("messages", [])
    
    async def get_message(self, message_id: str) -> Message:
        """
        Получить сообщение по ID.
        
        Args:
            message_id: ID сообщения
            
        Returns:
            Сообщение
        """
        return await self.client.call(
            "/messages/{message_id}",
            path={"message_id": message_id}
        )
    
    async def edit_message(
        self,
        message_id: str,
        **extra: Any
    ) -> Dict[str, Any]:
        """
        Редактировать сообщение.
        
        Args:
            message_id: ID сообщения
            **extra: Параметры для обновления
            
        Returns:
            Результат операции
        """
        return await self.client.call(
            "/messages/{message_id}",
            http_method="PUT",
            path={"message_id": message_id},
            body=extra
        )
    
    async def delete_message(
        self,
        message_id: str,
        **extra: Any
    ) -> Dict[str, Any]:
        """
        Удалить сообщение.
        
        Args:
            message_id: ID сообщения
            **extra: Дополнительные параметры
            
        Returns:
            Результат операции
        """
        return await self.client.call(
            "/messages/{message_id}",
            http_method="DELETE",
            path={"message_id": message_id},
            body=extra if extra else None
        )
    
    async def answer_on_callback(
        self,
        callback_id: str,
        **extra: Any
    ) -> Dict[str, Any]:
        """
        Ответить на callback от кнопки.
        
        Args:
            callback_id: ID callback'а
            **extra: Дополнительные параметры
            
        Returns:
            Результат операции
        """
        return await self.client.call(
            "/messages/callbacks/{callback_id}",
            http_method="POST",
            path={"callback_id": callback_id},
            body=extra
        )
    
    async def get_pinned_message(self, chat_id: int) -> Optional[Message]:
        """
        Получить закрепленное сообщение.
        
        Args:
            chat_id: ID чата
            
        Returns:
            Закрепленное сообщение или None
        """
        response = await self.client.call(
            "/chats/{chat_id}/pin",
            path={"chat_id": chat_id}
        )
        return response.get("message")
    
    async def pin_message(
        self,
        chat_id: int,
        message_id: str,
        **extra: Any
    ) -> Dict[str, Any]:
        """
        Закрепить сообщение.
        
        Args:
            chat_id: ID чата
            message_id: ID сообщения
            **extra: Дополнительные параметры
            
        Returns:
            Результат операции
        """
        return await self.client.call(
            "/chats/{chat_id}/pin",
            http_method="PUT",
            path={"chat_id": chat_id},
            body={"message_id": message_id, **extra}
        )
    
    async def unpin_message(self, chat_id: int) -> Dict[str, Any]:
        """
        Открепить сообщение.
        
        Args:
            chat_id: ID чата
            
        Returns:
            Результат операции
        """
        return await self.client.call(
            "/chats/{chat_id}/pin",
            http_method="DELETE",
            path={"chat_id": chat_id}
        )
    
    # ========================================================================
    # Subscription methods
    # ========================================================================
    
    async def get_updates(
        self,
        types: Optional[Union[List[UpdateType], str]] = None,
        **extra: Any
    ) -> Dict[str, Any]:
        """
        Получить обновления (long polling).
        
        Args:
            types: Типы обновлений для получения
            **extra: Дополнительные параметры (marker, limit, timeout)
            
        Returns:
            Словарь с updates и marker
        """
        query = extra.copy()
        if types:
            if isinstance(types, list):
                query["types"] = ",".join(types)
            else:
                query["types"] = types
        
        return await self.client.call(
            "/updates",
            query=query
        )


__all__ = ["Api"]
