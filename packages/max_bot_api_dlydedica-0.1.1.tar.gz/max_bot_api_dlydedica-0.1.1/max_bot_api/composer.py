"""
Composer для композиции middleware.

Модуль содержит класс Composer для удобного создания цепочек обработчиков.
"""

from typing import List, Union, Callable, TypeVar, Optional
import re

from .context import Context
from .middleware import Middleware, MiddlewareFn, NextFn, MiddlewareObj
from .filters import FilterFn, created_message_body_has
from .types import Message


Ctx = TypeVar("Ctx", bound=Context)
Triggers = Union[str, re.Pattern, List[Union[str, re.Pattern]]]


class Composer(MiddlewareObj[Ctx]):
    """
    Composer для композиции middleware.
    
    Позволяет создавать цепочки обработчиков с фильтрацией по типам
    обновлений, командам, текстовым триггерам и callback'ам.
    """
    
    def __init__(self, *middlewares: Middleware[Ctx]):
        """
        Инициализация composer.
        
        Args:
            *middlewares: Middleware для композиции
        """
        self.handler: MiddlewareFn[Ctx] = Composer.compose(list(middlewares))
    
    def middleware(self) -> MiddlewareFn[Ctx]:
        """Получить middleware функцию."""
        return self.handler
    
    def use(self, *middlewares: Middleware[Ctx]) -> "Composer[Ctx]":
        """
        Добавить middleware в цепочку.
        
        Args:
            *middlewares: Middleware для добавления
            
        Returns:
            Self для chaining
        """
        all_middlewares = [self.handler] + list(middlewares)
        self.handler = Composer.compose(all_middlewares)
        return self
    
    def on(
        self,
        filters: Union[str, FilterFn, List[Union[str, FilterFn]]],
        *middlewares: Middleware[Ctx]
    ) -> "Composer[Ctx]":
        """
        Добавить обработчик с фильтром по типу обновления.
        
        Args:
            filters: Фильтр(ы) для проверки
            *middlewares: Middleware для выполнения
            
        Returns:
            Self для chaining
            
        Example:
            >>> composer.on("message_created", handler)
            >>> @composer.on("message_created")
            >>> async def handler(ctx):
            ...     pass
        """
        if middlewares:
            return self.use(self.filter(filters, *middlewares))
        
        def decorator(fn: Middleware[Ctx]):
            return self.on(filters, fn)
        
        return decorator
    
    def command(
        self,
        command: Triggers,
        *middlewares: Middleware[Ctx]
    ):
        """
        Добавить обработчик команды (начинается с /).
        
        Args:
            command: Команда или список команд
            *middlewares: Middleware для выполнения
            
        Returns:
            Self для chaining или декоратор
            
        Example:
            >>> composer.command("start", start_handler)
            >>> composer.command(["help", "h"], help_handler)
            >>> # Как декоратор:
            >>> @composer.command("start")
            >>> async def start(ctx):
            ...     await ctx.reply("Hello")
        """
        # Если middleware переданы - обычное использование
        if middlewares:
            normalized_triggers = self._normalize_triggers(command)
            filter_fn = created_message_body_has("text")
            
            handler = Composer.compose(list(middlewares))
            
            async def command_handler(ctx: Ctx, next: NextFn) -> None:
                text = self._extract_text_from_message(ctx.message, ctx.my_id)
                if not text or not text.startswith("/"):
                    return await next()
                
                cmd = text[1:]  # Убираем /
                
                for trigger in normalized_triggers:
                    match = trigger(cmd)
                    if match:
                        ctx.match = match
                        return await handler(ctx, next)
                
                return await next()
            
            return self.use(self.filter(filter_fn, command_handler))
        
        # Если middleware не переданы - возвращаем декоратор
        def decorator(fn: Middleware[Ctx]):
            return self.command(command, fn)
        
        return decorator
    
    def hears(
        self,
        triggers: Triggers,
        *middlewares: Middleware[Ctx]
    ) -> "Composer[Ctx]":
        """
        Добавить обработчик текстовых триггеров.
        
        Args:
            triggers: Текст или regex для поиска
            *middlewares: Middleware для выполнения
            
        Returns:
            Self для chaining
            
        Example:
            >>> composer.hears("hello", hello_handler)
            >>> composer.hears(re.compile(r"hi|hello"), greet_handler)
        """
        if middlewares:
            normalized_triggers = self._normalize_triggers(triggers)
            filter_fn = created_message_body_has("text")
            
            handler = Composer.compose(list(middlewares))
            
            async def hears_handler(ctx: Ctx, next: NextFn) -> None:
                text = self._extract_text_from_message(ctx.message, ctx.my_id)
                if not text:
                    return await next()
                
                for trigger in normalized_triggers:
                    match = trigger(text)
                    if match:
                        ctx.match = match
                        return await handler(ctx, next)
                
                return await next()
            
            return self.use(self.filter(filter_fn, hears_handler))
        
        def decorator(fn: Middleware[Ctx]):
            return self.hears(triggers, fn)
        
        return decorator
    
    def action(
        self,
        triggers: Triggers,
        *middlewares: Middleware[Ctx]
    ):
        """
        Добавить обработчик callback action.
        
        Args:
            triggers: Payload для поиска
            *middlewares: Middleware для выполнения
            
        Returns:
            Self для chaining или декоратор
            
        Example:
            >>> composer.action("button_clicked", button_handler)
            >>> @composer.action("button_clicked")
            >>> async def button(ctx):
            ...     await ctx.reply("Нажата кнопка")
        """
        if middlewares:
            normalized_triggers = self._normalize_triggers(triggers)
            handler = Composer.compose(list(middlewares))
            
            async def action_handler(ctx: Ctx, next: NextFn) -> None:
                if ctx.update_type != "message_callback":
                    return await next()
                
                payload = ctx.callback.get("payload") if ctx.callback else None
                if not payload:
                    return await next()
                
                for trigger in normalized_triggers:
                    match = trigger(payload)
                    if match:
                        ctx.match = match
                        return await handler(ctx, next)
                
                return await next()
            
            return self.use(action_handler)
        
        def decorator(fn: Middleware[Ctx]):
            return self.action(triggers, fn)
        
        return decorator
    
    def filter(
        self,
        filters: Union[str, FilterFn, List[Union[str, FilterFn]]],
        *middlewares: Middleware[Ctx]
    ) -> MiddlewareFn[Ctx]:
        """
        Создать middleware с фильтром.
        
        Args:
            filters: Фильтр(ы) для проверки
            *middlewares: Middleware для выполнения
            
        Returns:
            Middleware функция
        """
        handler = Composer.compose(list(middlewares))
        filters_list = filters if isinstance(filters, list) else [filters]
        
        async def filtered_handler(ctx: Ctx, next: NextFn) -> None:
            for filter_item in filters_list:
                if isinstance(filter_item, str):
                    # Проверка по типу обновления
                    if ctx.update_type == filter_item:
                        return await handler(ctx, next)
                elif callable(filter_item):
                    # Проверка по функции-фильтру
                    if filter_item(ctx.update):
                        return await handler(ctx, next)
            
            return await next()
        
        return filtered_handler
    
    # ========================================================================
    # Статические методы для композиции
    # ========================================================================
    
    @staticmethod
    def flatten(mw: Middleware[Ctx]) -> MiddlewareFn[Ctx]:
        """Преобразовать middleware в функцию."""
        if callable(mw):
            return mw
        return mw.middleware()
    
    @staticmethod
    def concat(
        first: MiddlewareFn[Ctx],
        and_then: MiddlewareFn[Ctx]
    ) -> MiddlewareFn[Ctx]:
        """Объединить два middleware."""
        async def combined(ctx: Ctx, next: NextFn) -> None:
            next_called = False
            
            async def call_next() -> None:
                nonlocal next_called
                if next_called:
                    raise RuntimeError("`next` already called before!")
                next_called = True
                await and_then(ctx, next)
            
            await first(ctx, call_next)
        
        return combined
    
    @staticmethod
    async def pass_through(_ctx: Ctx, next: NextFn) -> None:
        """Pass-through middleware."""
        await next()
    
    @staticmethod
    def compose(middlewares: List[Middleware[Ctx]]) -> MiddlewareFn[Ctx]:
        """
        Скомпоновать middleware в цепочку.
        
        Args:
            middlewares: Список middleware
            
        Returns:
            Единая middleware функция
        """
        if not isinstance(middlewares, list):
            raise TypeError("Middlewares must be a list")
        
        if not middlewares:
            return Composer.pass_through
        
        # Преобразуем все middleware в функции
        functions = [Composer.flatten(mw) for mw in middlewares]
        
        # Объединяем через concat
        result = functions[0]
        for func in functions[1:]:
            result = Composer.concat(result, func)
        
        return result
    
    # ========================================================================
    # Вспомогательные методы
    # ========================================================================
    
    @staticmethod
    def _normalize_triggers(triggers: Triggers) -> List[Callable[[str], Optional[re.Match]]]:
        """Нормализовать триггеры в список функций."""
        triggers_list = triggers if isinstance(triggers, list) else [triggers]
        
        result = []
        for trigger in triggers_list:
            if isinstance(trigger, re.Pattern):
                def regex_matcher(value: str, pattern=trigger) -> Optional[re.Match]:
                    return pattern.match(value.strip())
                result.append(regex_matcher)
            else:
                # Строка - точное совпадение
                pattern = re.compile(f"^{re.escape(trigger)}$")
                def string_matcher(value: str, pat=pattern) -> Optional[re.Match]:
                    return pat.match(value.strip())
                result.append(string_matcher)
        
        return result
    
    @staticmethod
    def _extract_text_from_message(message: Optional[Message], my_id: Optional[int]) -> Optional[str]:
        """Извлечь текст из сообщения с учетом mentions."""
        if not message:
            return None
        
        text = message.body.text
        if not text:
            return None
        
        # Проверяем mention бота
        if message.body.markup:
            for m in message.body.markup:
                if (m.get("type") == "user_mention" 
                    and m.get("from") == 0 
                    and m.get("user_id") == my_id):
                    # Убираем mention из начала текста
                    length = m.get("length", 0)
                    return text[length:].strip()
        
        return text


__all__ = ["Composer"]
