"""
Модуль логирования для max_bot_api.

Настраивает логирование с русскоязычными сообщениями.
"""

import logging
import sys
from typing import Optional


# Русскоязычные уровни логирования
LEVEL_NAMES = {
    "DEBUG": "ОТЛАДКА",
    "INFO": "ИНФО",
    "WARNING": "ПРЕДУПРЕЖДЕНИЕ",
    "ERROR": "ОШИБКА",
    "CRITICAL": "КРИТИЧНО",
}


class RussianFormatter(logging.Formatter):
    """Форматтер с русскоязычными уровнями."""
    
    def format(self, record: logging.LogRecord) -> str:
        """Форматировать запись с русским названием уровня."""
        # Сохраняем оригинальный уровень
        original_levelname = record.levelname
        
        # Заменяем на русский
        record.levelname = LEVEL_NAMES.get(record.levelname, record.levelname)
        
        # Форматируем
        result = super().format(record)
        
        # Восстанавливаем оригинальный уровень
        record.levelname = original_levelname
        
        return result


def setup_logging(
    level: int = logging.INFO,
    format_string: Optional[str] = None
) -> None:
    """
    Настроить логирование для библиотеки.
    
    Args:
        level: Уровень логирования (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        format_string: Пользовательский формат сообщений
    """
    if format_string is None:
        format_string = (
            "%(asctime)s | %(levelname)-15s | %(name)s | %(message)s"
        )
    
    # Создаем форматтер
    formatter = RussianFormatter(
        format_string,
        datefmt="%Y-%m-%d %H:%M:%S"
    )
    
    # Настраиваем обработчик для консоли
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(formatter)
    
    # Получаем корневой логгер библиотеки
    logger = logging.getLogger("max_bot_api")
    logger.setLevel(level)
    logger.addHandler(handler)
    
    # Убираем дублирование логов
    logger.propagate = False


def get_logger(name: str) -> logging.Logger:
    """
    Получить логгер для модуля.
    
    Args:
        name: Имя модуля
        
    Returns:
        Логгер
    """
    return logging.getLogger(f"max_bot_api.{name}")


__all__ = ["setup_logging", "get_logger", "RussianFormatter"]
