"""
Фильтры для обновлений.

Модуль содержит функции-фильтры для проверки типов обновлений и их содержимого.
"""

from typing import TypeVar, Callable, List
from .types import (
    Update,
    MessageCreatedUpdate,
    MessageBody,
)


UpdateT = TypeVar("UpdateT", bound=Update)
FilterFn = Callable[[Update], bool]


def created_message_body_has(*keys: str) -> FilterFn:
    """
    Создает фильтр, проверяющий наличие полей в теле сообщения.
    
    Args:
        *keys: Имена полей для проверки в теле сообщения
        
    Returns:
        Функция-фильтр
        
    Example:
        >>> has_text = created_message_body_has("text")
        >>> has_attachments = created_message_body_has("attachments")
    """
    def filter_fn(update: Update) -> bool:
        if not isinstance(update, MessageCreatedUpdate):
            return False
        
        if update.update_type != "message_created":
            return False
            
        for key in keys:
            if not hasattr(update.message.body, key):
                return False
            value = getattr(update.message.body, key)
            if value is None:
                return False
                
        return True
    
    return filter_fn


def has_text(update: Update) -> bool:
    """Проверяет, есть ли текст в сообщении."""
    return created_message_body_has("text")(update)


def has_attachments(update: Update) -> bool:
    """Проверяет, есть ли вложения в сообщении."""
    return created_message_body_has("attachments")(update)


def update_type_is(*types: str) -> FilterFn:
    """
    Создает фильтр для проверки типа обновления.
    
    Args:
        *types: Типы обновлений для проверки
        
    Returns:
        Функция-фильтр
        
    Example:
        >>> is_message = update_type_is("message_created", "message_edited")
    """
    def filter_fn(update: Update) -> bool:
        return update.update_type in types
    
    return filter_fn


def combine_filters(*filters: FilterFn) -> FilterFn:
    """
    Комбинирует несколько фильтров (логическое И).
    
    Args:
        *filters: Фильтры для комбинирования
        
    Returns:
        Функция-фильтр
        
    Example:
        >>> combined = combine_filters(has_text, update_type_is("message_created"))
    """
    def filter_fn(update: Update) -> bool:
        return all(f(update) for f in filters)
    
    return filter_fn


def any_filter(*filters: FilterFn) -> FilterFn:
    """
    Комбинирует несколько фильтров (логическое ИЛИ).
    
    Args:
        *filters: Фильтры для комбинирования
        
    Returns:
        Функция-фильтр
        
    Example:
        >>> any_msg = any_filter(
        ...     update_type_is("message_created"),
        ...     update_type_is("message_edited")
        ... )
    """
    def filter_fn(update: Update) -> bool:
        return any(f(update) for f in filters)
    
    return filter_fn


__all__ = [
    "FilterFn",
    "created_message_body_has",
    "has_text",
    "has_attachments",
    "update_type_is",
    "combine_filters",
    "any_filter",
]
