"""
Контекст обработки обновлений.

Модуль содержит класс Context, который предоставляет удобный интерфейс
для работы с обновлениями и вызова API методов.
"""

from typing import Optional, TYPE_CHECKING, TypeVar, List, Dict, Any, Pattern
import re

from .types import (
    Update,
    Message,
    User,
    Chat,
    MessageCallbackUpdate,
    MessageCreatedUpdate,
    BotStartedUpdate,
    SenderAction,
)

if TYPE_CHECKING:
    from .api import Api


Ctx = TypeVar("Ctx", bound="Context")


class Context:
    """
    Контекст обработки обновления.
    
    Предоставляет доступ к данным обновления и методам API.
    """
    
    def __init__(
        self,
        update: Update,
        api: "Api",
        bot_info: Optional[Dict[str, Any]] = None,
    ):
        """
        Инициализация контекста.
        
        Args:
            update: Обновление от API
            api: Экземпляр API клиента
            bot_info: Информация о боте
        """
        self.update = update
        self.api = api
        self.bot_info = bot_info
        self.match: Optional[re.Match] = None
    
    # ========================================================================
    # Свойства для доступа к данным обновления
    # ========================================================================
    
    @property
    def update_type(self) -> str:
        """Тип обновления."""
        return self.update.update_type
    
    @property
    def my_id(self) -> Optional[int]:
        """ID бота."""
        return self.bot_info.get("user_id") if self.bot_info else None
    
    @property
    def chat_id(self) -> Optional[int]:
        """ID чата."""
        if hasattr(self.update, "chat_id"):
            return self.update.chat_id
        
        if isinstance(self.update, MessageCreatedUpdate):
            return self.update.message.recipient.chat_id
        
        if isinstance(self.update, MessageCallbackUpdate):
            if self.update.message:
                return self.update.message.recipient.chat_id
        
        if hasattr(self.update, "chat"):
            return self.update.chat.chat_id
        
        return None
    
    @property
    def chat(self) -> Optional[Chat]:
        """Объект чата."""
        if hasattr(self.update, "chat"):
            return self.update.chat
        return None
    
    @property
    def message(self) -> Optional[Message]:
        """Объект сообщения."""
        if hasattr(self.update, "message"):
            return self.update.message
        return None
    
    @property
    def message_id(self) -> Optional[str]:
        """ID сообщения."""
        if hasattr(self.update, "message_id"):
            return self.update.message_id
        
        if self.message:
            return self.message.body.mid
        
        return None
    
    @property
    def callback(self) -> Optional[Dict]:
        """Данные callback."""
        if isinstance(self.update, MessageCallbackUpdate):
            return self.update.callback
        return None
    
    @property
    def user(self) -> Optional[User]:
        """Пользователь."""
        if hasattr(self.update, "user"):
            return self.update.user
        
        if isinstance(self.update, MessageCallbackUpdate):
            return self.update.callback.get("user")
        
        if isinstance(self.update, MessageCreatedUpdate):
            return self.update.message.sender
        
        return None
    
    @property
    def start_payload(self) -> Optional[str]:
        """Payload из bot_started."""
        if isinstance(self.update, BotStartedUpdate):
            return self.update.payload
        return None
    
    # ========================================================================
    # Вспомогательные свойства для вложений
    # ========================================================================
    
    @property
    def text(self) -> Optional[str]:
        """Текст сообщения."""
        if self.message:
            return self.message.body.text
        return None
    
    @property
    def contact_info(self) -> Optional[Dict[str, str]]:
        """Информация о контакте из вложения."""
        if not self.message or not self.message.body.attachments:
            return None
        
        for attachment in self.message.body.attachments:
            if attachment.type == "contact":
                # Здесь можно добавить парсинг VCF
                return attachment.payload
        
        return None
    
    @property
    def location(self) -> Optional[Dict[str, float]]:
        """Геолокация из вложения."""
        if not self.message or not self.message.body.attachments:
            return None
        
        for attachment in self.message.body.attachments:
            if attachment.type == "location":
                return {
                    "latitude": attachment.latitude,
                    "longitude": attachment.longitude,
                }
        
        return None
    
    @property
    def sticker(self) -> Optional[Dict[str, Any]]:
        """Стикер из вложения."""
        if not self.message or not self.message.body.attachments:
            return None
        
        for attachment in self.message.body.attachments:
            if attachment.type == "sticker":
                return {
                    "width": attachment.width,
                    "height": attachment.height,
                    "url": attachment.payload["url"],
                    "code": attachment.payload["code"],
                }
        
        return None
    
    # ========================================================================
    # Методы для работы с API
    # ========================================================================
    
    def _assert(self, value: Any, method: str) -> None:
        """Проверка доступности значения для метода."""
        if value is None:
            raise TypeError(
                f'Max: "{method}" isn\'t available for "{self.update_type}"'
            )
    
    async def reply(self, text: str, **extra: Any) -> Dict:
        """
        Ответить в текущий чат.
        
        Args:
            text: Текст сообщения
            **extra: Дополнительные параметры
            
        Returns:
            Результат отправки сообщения
        """
        self._assert(self.chat_id, "reply")
        return await self.api.send_message_to_chat(self.chat_id, text, **extra)
    
    async def get_all_chats(self, **extra: Any) -> List[Chat]:
        """Получить все чаты бота."""
        return await self.api.get_all_chats(**extra)
    
    async def get_chat(self, chat_id: Optional[int] = None) -> Chat:
        """Получить информацию о чате."""
        if chat_id is None:
            self._assert(self.chat_id, "get_chat")
            chat_id = self.chat_id
        return await self.api.get_chat(chat_id)
    
    async def edit_message(self, **extra: Any) -> Dict:
        """Редактировать сообщение."""
        self._assert(self.message_id, "edit_message")
        return await self.api.edit_message(self.message_id, **extra)
    
    async def delete_message(self, message_id: Optional[str] = None) -> Dict:
        """Удалить сообщение."""
        if message_id is None:
            self._assert(self.message_id, "delete_message")
            message_id = self.message_id
        return await self.api.delete_message(message_id)
    
    async def answer_on_callback(self, **extra: Any) -> Dict:
        """Ответить на callback."""
        self._assert(self.callback, "answer_on_callback")
        callback_id = self.callback.get("callback_id")
        return await self.api.answer_on_callback(callback_id, **extra)
    
    async def send_action(self, action: SenderAction) -> Dict:
        """Отправить действие (typing, и т.д.)."""
        self._assert(self.chat_id, "send_action")
        return await self.api.send_action(self.chat_id, action)
    
    async def leave_chat(self) -> Dict:
        """Покинуть чат."""
        self._assert(self.chat_id, "leave_chat")
        return await self.api.leave_chat(self.chat_id)
    
    async def pin_message(self, message_id: str, **extra: Any) -> Dict:
        """Закрепить сообщение."""
        self._assert(self.chat_id, "pin_message")
        return await self.api.pin_message(self.chat_id, message_id, **extra)
    
    async def unpin_message(self) -> Dict:
        """Открепить сообщение."""
        self._assert(self.chat_id, "unpin_message")
        return await self.api.unpin_message(self.chat_id)


__all__ = ["Context", "Ctx"]
