"""
Типы данных Max Bot API.

Модуль содержит все типы данных для работы с Max Bot API,
реализованные с использованием Pydantic для валидации.
"""

from typing import Literal, Optional, Union, List, Dict
from pydantic import BaseModel, Field


# ============================================================================
# Common Types
# ============================================================================

class SuccessResponse(BaseModel):
    """Успешный ответ API."""
    success: Literal[True] = True


class ErrorResponse(BaseModel):
    """Ответ с ошибкой."""
    success: Literal[False] = False
    message: str


ActionResponse = Union[SuccessResponse, ErrorResponse]


# ============================================================================
# User Types
# ============================================================================

class User(BaseModel):
    """Пользователь Max."""
    user_id: int
    name: str
    username: Optional[str] = None
    is_bot: bool
    last_activity_time: int


class UserWithPhoto(User):
    """Пользователь с дополнительной информацией."""
    description: Optional[str] = None
    avatar_url: Optional[str] = None
    full_avatar_url: Optional[str] = None


# ============================================================================
# Chat Types
# ============================================================================

ChatType = Literal["dialog", "chat", "channel"]
ChatStatus = Literal["active", "removed", "left", "closed", "suspended"]
SenderAction = Literal[
    "typing_on",
    "sending_photo",
    "sending_video",
    "sending_audio",
    "sending_file",
    "mark_seen"
]
ChatPermissions = Literal[
    "read_all_messages",
    "add_remove_members",
    "add_admins",
    "change_chat_info",
    "pin_message",
    "write"
]


class Chat(BaseModel):
    """Чат."""
    chat_id: int
    type: ChatType
    status: ChatStatus
    title: Optional[str] = None
    icon: Optional[Dict[str, str]] = None
    last_event_time: int
    participants_count: int
    owner_id: Optional[int] = None
    participants: Optional[Dict[str, int]] = None
    is_public: bool
    link: Optional[str] = None
    description: Optional[str] = None
    dialog_with_user: Optional[Dict] = None
    messages_count: Optional[int] = None
    chat_message_id: Optional[str] = None
    pinned_message: Optional[Dict] = None


class ChatMember(BaseModel):
    """Участник чата."""
    user_id: int
    name: str
    username: Optional[str] = None
    is_bot: bool
    last_activity_time: int
    description: Optional[str] = None
    avatar_url: Optional[str] = None
    full_avatar_url: Optional[str] = None
    last_access_time: int
    is_owner: bool
    is_admin: bool
    join_time: int
    permissions: Optional[List[ChatPermissions]] = None


# ============================================================================
# Button Types
# ============================================================================

ButtonIntent = Literal["default", "positive", "negative"]


class CallbackButton(BaseModel):
    """Кнопка с callback."""
    type: Literal["callback"] = "callback"
    text: str
    payload: str
    intent: Optional[ButtonIntent] = None


class LinkButton(BaseModel):
    """Кнопка-ссылка."""
    type: Literal["link"] = "link"
    text: str
    url: str


class RequestContactButton(BaseModel):
    """Кнопка запроса контакта."""
    type: Literal["request_contact"] = "request_contact"
    text: str


class RequestGeoLocationButton(BaseModel):
    """Кнопка запроса геолокации."""
    type: Literal["request_geo_location"] = "request_geo_location"
    text: str
    quick: Optional[bool] = None


class ChatButton(BaseModel):
    """Кнопка чата."""
    type: Literal["chat"] = "chat"
    text: str
    chat_title: str
    chat_description: Optional[str] = None
    start_payload: Optional[str] = None
    uuid: Optional[str] = None


Button = Union[
    CallbackButton,
    LinkButton,
    RequestContactButton,
    RequestGeoLocationButton,
    ChatButton
]


# ============================================================================
# Attachment Types
# ============================================================================

class MediaPayload(BaseModel):
    """Базовая информация о медиа."""
    url: str
    token: str


class PhotoAttachment(BaseModel):
    """Фото вложение."""
    type: Literal["image"] = "image"
    payload: MediaPayload


class VideoAttachment(BaseModel):
    """Видео вложение."""
    type: Literal["video"] = "video"
    payload: MediaPayload
    thumbnail: Optional[str] = None
    width: Optional[int] = None
    height: Optional[int] = None
    duration: Optional[int] = None


class AudioAttachment(BaseModel):
    """Аудио вложение."""
    type: Literal["audio"] = "audio"
    payload: MediaPayload


class FileAttachment(BaseModel):
    """Файл вложение."""
    type: Literal["file"] = "file"
    payload: MediaPayload
    filename: str
    size: int


class StickerAttachment(BaseModel):
    """Стикер вложение."""
    type: Literal["sticker"] = "sticker"
    payload: Dict[str, str]
    width: int
    height: int


class ContactAttachment(BaseModel):
    """Контакт вложение."""
    type: Literal["contact"] = "contact"
    payload: Dict[str, Optional[Union[str, User]]]


class ShareAttachment(BaseModel):
    """Share вложение."""
    type: Literal["share"] = "share"
    payload: Optional[MediaPayload] = None
    title: Optional[str] = None
    description: Optional[str] = None
    image_url: Optional[str] = None


class LocationAttachment(BaseModel):
    """Геолокация вложение."""
    type: Literal["location"] = "location"
    latitude: float
    longitude: float


class InlineKeyboardAttachment(BaseModel):
    """Inline клавиатура вложение."""
    type: Literal["inline_keyboard"] = "inline_keyboard"
    payload: Dict[str, List[List[Button]]]


Attachment = Union[
    PhotoAttachment,
    VideoAttachment,
    AudioAttachment,
    FileAttachment,
    StickerAttachment,
    ContactAttachment,
    InlineKeyboardAttachment,
    ShareAttachment,
    LocationAttachment
]


# ============================================================================
# Message Types
# ============================================================================

MessageSender = User


class MessageRecipient(BaseModel):
    """Получатель сообщения."""
    chat_id: Optional[int] = None
    chat_type: ChatType


class MessageBody(BaseModel):
    """Тело сообщения."""
    mid: str
    seq: int
    text: Optional[str] = None
    attachments: Optional[List[Attachment]] = None
    markup: Optional[List[Dict]] = None


MessageLinkType = Literal["forward", "reply"]


class LinkedMessage(BaseModel):
    """Связанное сообщение (forward/reply)."""
    type: MessageLinkType
    sender: Optional[MessageSender] = None
    chat_id: Optional[int] = None
    message: MessageBody


class MessageStat(BaseModel):
    """Статистика сообщения."""
    views: int


MessageConstructor = User


class Message(BaseModel):
    """Сообщение."""
    sender: Optional[MessageSender] = None
    recipient: MessageRecipient
    timestamp: int
    link: Optional[LinkedMessage] = None
    body: MessageBody
    stat: Optional[MessageStat] = None
    url: Optional[str] = None
    constructor: Optional[MessageConstructor] = None


class ConstructedMessage(BaseModel):
    """Сконструированное сообщение."""
    sender: Optional[MessageSender] = None
    timestamp: int
    link: Optional[LinkedMessage] = None
    body: MessageBody


# ============================================================================
# Update Types
# ============================================================================

class MessageCallbackUpdate(BaseModel):
    """Обновление callback от кнопки."""
    update_type: Literal["message_callback"] = "message_callback"
    timestamp: int
    callback: Dict
    message: Optional[Message] = None
    user_locale: Optional[str] = None


class MessageCreatedUpdate(BaseModel):
    """Обновление создания сообщения."""
    update_type: Literal["message_created"] = "message_created"
    timestamp: int
    message: Message
    user_locale: Optional[str] = None


class MessageRemovedUpdate(BaseModel):
    """Обновление удаления сообщения."""
    update_type: Literal["message_removed"] = "message_removed"
    timestamp: int
    message_id: str
    chat_id: int
    user_id: int


class MessageEditedUpdate(BaseModel):
    """Обновление редактирования сообщения."""
    update_type: Literal["message_edited"] = "message_edited"
    timestamp: int
    message: Message


class BotAddedUpdate(BaseModel):
    """Обновление добавления бота."""
    update_type: Literal["bot_added"] = "bot_added"
    timestamp: int
    chat_id: int
    user: User
    is_channel: bool


class BotRemovedUpdate(BaseModel):
    """Обновление удаления бота."""
    update_type: Literal["bot_removed"] = "bot_removed"
    timestamp: int
    chat_id: int
    user: User
    is_channel: bool


class UserAddedUpdate(BaseModel):
    """Обновление добавления пользователя."""
    update_type: Literal["user_added"] = "user_added"
    timestamp: int
    chat_id: int
    user: User
    inviter_id: Optional[int] = None
    is_channel: bool


class UserRemovedUpdate(BaseModel):
    """Обновление удаления пользователя."""
    update_type: Literal["user_removed"] = "user_removed"
    timestamp: int
    chat_id: int
    user: User
    admin_id: Optional[int] = None
    is_channel: bool


class BotStartedUpdate(BaseModel):
    """Обновление запуска бота."""
    update_type: Literal["bot_started"] = "bot_started"
    timestamp: int
    chat_id: int
    user: User
    payload: Optional[str] = None
    user_locale: Optional[str] = None


class ChatTitleChangedUpdate(BaseModel):
    """Обновление изменения названия чата."""
    update_type: Literal["chat_title_changed"] = "chat_title_changed"
    timestamp: int
    chat_id: int
    user: User
    title: str


class MessageConstructionRequestUpdate(BaseModel):
    """Обновление запроса конструкции сообщения."""
    update_type: Literal["message_construction_request"] = "message_construction_request"
    timestamp: int
    user: User
    user_locale: Optional[str] = None
    session_id: str
    data: Optional[str] = None
    input: Optional[Dict] = None


class MessageConstructedUpdate(BaseModel):
    """Обновление сконструированного сообщения."""
    update_type: Literal["message_constructed"] = "message_constructed"
    timestamp: int
    user: User
    session_id: str
    message: ConstructedMessage


class MessageChatCreatedUpdate(BaseModel):
    """Обновление создания чата через сообщение."""
    update_type: Literal["message_chat_created"] = "message_chat_created"
    timestamp: int
    chat: Chat
    message_id: str
    start_payload: Optional[str] = None


Update = Union[
    MessageCallbackUpdate,
    MessageCreatedUpdate,
    MessageRemovedUpdate,
    MessageEditedUpdate,
    BotAddedUpdate,
    BotRemovedUpdate,
    UserAddedUpdate,
    UserRemovedUpdate,
    BotStartedUpdate,
    ChatTitleChangedUpdate,
    MessageConstructionRequestUpdate,
    MessageConstructedUpdate,
    MessageChatCreatedUpdate,
]

# Маппинг типов обновлений на классы
UPDATE_TYPE_MAP = {
    "message_callback": MessageCallbackUpdate,
    "message_created": MessageCreatedUpdate,
    "message_removed": MessageRemovedUpdate,
    "message_edited": MessageEditedUpdate,
    "bot_added": BotAddedUpdate,
    "bot_removed": BotRemovedUpdate,
    "user_added": UserAddedUpdate,
    "user_removed": UserRemovedUpdate,
    "bot_started": BotStartedUpdate,
    "chat_title_changed": ChatTitleChangedUpdate,
    "message_construction_request": MessageConstructionRequestUpdate,
    "message_constructed": MessageConstructedUpdate,
    "message_chat_created": MessageChatCreatedUpdate,
}


def parse_update(data: dict) -> Update:
    """
    Десериализует обновление из словаря.
    
    Args:
        data: Словарь с данными обновления
        
    Returns:
        Объект обновления
        
    Raises:
        ValueError: Если тип обновления неизвестен
    """
    update_type = data.get("update_type")
    if not update_type:
        raise ValueError("Отсутствует поле update_type")
    
    update_class = UPDATE_TYPE_MAP.get(update_type)
    if not update_class:
        raise ValueError(f"Неизвестный тип обновления: {update_type}")
    
    return update_class(**data)

UpdateType = Literal[
    "message_callback",
    "message_created",
    "message_removed",
    "message_edited",
    "bot_added",
    "bot_removed",
    "user_added",
    "user_removed",
    "bot_started",
    "chat_title_changed",
    "message_construction_request",
    "message_constructed",
    "message_chat_created",
]


__all__ = [
    # Common
    "SuccessResponse",
    "ErrorResponse",
    "ActionResponse",
    # User
    "User",
    "UserWithPhoto",
    # Chat
    "Chat",
    "ChatType",
    "ChatStatus",
    "ChatMember",
    "ChatPermissions",
    "SenderAction",
    # Button
    "Button",
    "ButtonIntent",
    "CallbackButton",
    "LinkButton",
    "RequestContactButton",
    "RequestGeoLocationButton",
    "ChatButton",
    # Attachment
    "Attachment",
    "MediaPayload",
    "PhotoAttachment",
    "VideoAttachment",
    "AudioAttachment",
    "FileAttachment",
    "StickerAttachment",
    "ContactAttachment",
    "InlineKeyboardAttachment",
    "ShareAttachment",
    "LocationAttachment",
    # Message
    "Message",
    "MessageSender",
    "MessageRecipient",
    "MessageBody",
    "MessageLinkType",
    "LinkedMessage",
    "MessageStat",
    "MessageConstructor",
    "ConstructedMessage",
    # Update
    "Update",
    "UpdateType",
    "MessageCallbackUpdate",
    "MessageCreatedUpdate",
    "MessageRemovedUpdate",
    "MessageEditedUpdate",
    "BotAddedUpdate",
    "BotRemovedUpdate",
    "UserAddedUpdate",
    "UserRemovedUpdate",
    "BotStartedUpdate",
    "ChatTitleChangedUpdate",
    "MessageConstructionRequestUpdate",
    "MessageConstructedUpdate",
    "MessageChatCreatedUpdate",
]
