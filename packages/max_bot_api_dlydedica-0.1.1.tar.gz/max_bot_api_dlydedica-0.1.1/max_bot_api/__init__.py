"""
Max Bot API - Python библиотека для работы с Max Bot API.

Примеры использования:
    >>> from max_bot_api import Bot
    >>> 
    >>> bot = Bot("YOUR_BOT_TOKEN")
    >>> 
    >>> @bot.on("message_created")
    >>> async def handle_message(ctx):
    >>>     await ctx.reply(f"Привет, {ctx.user.name}!")
    >>> 
    >>> bot.command("start")
    >>> async def start_command(ctx):
    >>>     await ctx.reply("Бот запущен!")
    >>> 
    >>> await bot.start()
"""

__version__ = "0.1.0"

from .bot import Bot
from .api import Api
from .context import Context
from .composer import Composer
from .middleware import Middleware, MiddlewareFn, NextFn
from .filters import (
    FilterFn,
    created_message_body_has,
    has_text,
    has_attachments,
    update_type_is,
    combine_filters,
    any_filter,
)
from .types import (
    # Common
    SuccessResponse,
    ErrorResponse,
    ActionResponse,
    # User
    User,
    UserWithPhoto,
    # Chat
    Chat,
    ChatType,
    ChatStatus,
    ChatMember,
    ChatPermissions,
    SenderAction,
    # Button
    Button,
    ButtonIntent,
    CallbackButton,
    LinkButton,
    RequestContactButton,
    RequestGeoLocationButton,
    ChatButton,
    # Attachment
    Attachment,
    MediaPayload,
    PhotoAttachment,
    VideoAttachment,
    AudioAttachment,
    FileAttachment,
    StickerAttachment,
    ContactAttachment,
    InlineKeyboardAttachment,
    ShareAttachment,
    LocationAttachment,
    # Message
    Message,
    MessageSender,
    MessageRecipient,
    MessageBody,
    MessageLinkType,
    LinkedMessage,
    MessageStat,
    MessageConstructor,
    ConstructedMessage,
    # Update
    Update,
    UpdateType,
    MessageCallbackUpdate,
    MessageCreatedUpdate,
    MessageRemovedUpdate,
    MessageEditedUpdate,
    BotAddedUpdate,
    BotRemovedUpdate,
    UserAddedUpdate,
    UserRemovedUpdate,
    BotStartedUpdate,
    ChatTitleChangedUpdate,
    MessageConstructionRequestUpdate,
    MessageConstructedUpdate,
    MessageChatCreatedUpdate,
    parse_update,
)

__all__ = [
    # Version
    "__version__",
    # Core classes
    "Bot",
    "Api",
    "Context",
    "Composer",
    # Middleware
    "Middleware",
    "MiddlewareFn",
    "NextFn",
    # Filters
    "FilterFn",
    "created_message_body_has",
    "has_text",
    "has_attachments",
    "update_type_is",
    "combine_filters",
    "any_filter",
    # Common types
    "SuccessResponse",
    "ErrorResponse",
    "ActionResponse",
    # User types
    "User",
    "UserWithPhoto",
    # Chat types
    "Chat",
    "ChatType",
    "ChatStatus",
    "ChatMember",
    "ChatPermissions",
    "SenderAction",
    # Button types
    "Button",
    "ButtonIntent",
    "CallbackButton",
    "LinkButton",
    "RequestContactButton",
    "RequestGeoLocationButton",
    "ChatButton",
    # Attachment types
    "Attachment",
    "MediaPayload",
    "PhotoAttachment",
    "VideoAttachment",
    "AudioAttachment",
    "FileAttachment",
    "StickerAttachment",
    "ContactAttachment",
    "InlineKeyboardAttachment",
    "ShareAttachment",
    "LocationAttachment",
    # Message types
    "Message",
    "MessageSender",
    "MessageRecipient",
    "MessageBody",
    "MessageLinkType",
    "LinkedMessage",
    "MessageStat",
    "MessageConstructor",
    "ConstructedMessage",
    # Update types
    "Update",
    "UpdateType",
    "MessageCallbackUpdate",
    "MessageCreatedUpdate",
    "MessageRemovedUpdate",
    "MessageEditedUpdate",
    "BotAddedUpdate",
    "BotRemovedUpdate",
    "UserAddedUpdate",
    "UserRemovedUpdate",
    "BotStartedUpdate",
    "ChatTitleChangedUpdate",
    "MessageConstructionRequestUpdate",
    "MessageConstructedUpdate",
    "MessageChatCreatedUpdate",
    "parse_update",
]
