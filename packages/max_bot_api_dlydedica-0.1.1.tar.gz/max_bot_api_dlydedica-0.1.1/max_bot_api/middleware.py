"""
Middleware система для обработки обновлений.

Модуль содержит типы и интерфейсы для создания middleware функций.
"""

from typing import TypeVar, Union, Callable, Awaitable, Protocol, TYPE_CHECKING

if TYPE_CHECKING:
    from .context import Context


# Type variable для контекста
Ctx = TypeVar("Ctx", bound="Context")

# Тип для следующей функции в цепочке
NextFn = Callable[[], Awaitable[None]]

# Middleware функция
MiddlewareFn = Callable[[Ctx, NextFn], Awaitable[None]]


class MiddlewareObj(Protocol[Ctx]):
    """Объект с методом middleware."""
    
    def middleware(self) -> MiddlewareFn[Ctx]:
        """Возвращает middleware функцию."""
        ...


# Middleware может быть функцией или объектом с методом middleware
Middleware = Union[MiddlewareFn[Ctx], MiddlewareObj[Ctx]]


__all__ = [
    "NextFn",
    "MiddlewareFn",
    "MiddlewareObj",
    "Middleware",
    "Ctx",
]
