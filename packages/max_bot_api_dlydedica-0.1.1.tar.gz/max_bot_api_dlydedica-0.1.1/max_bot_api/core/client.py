"""
HTTP клиент для Max Bot API.

Модуль содержит базовый HTTP клиент для работы с API.
"""

from typing import Dict, Any, Optional, Literal
import httpx
from ..logging_config import get_logger

logger = get_logger("client")


HTTPMethod = Literal["GET", "POST", "PUT", "PATCH", "DELETE"]


class Client:
    """HTTP клиент для Max API."""
    
    def __init__(
        self,
        token: str,
        base_url: str = "https://platform-api.max.ru",
        timeout: float = 30.0,
    ):
        """
        Инициализация клиента.
        
        Args:
            token: Токен бота
            base_url: Базовый URL API
            timeout: Таймаут запросов
        """
        self.token = token
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._client: Optional[httpx.AsyncClient] = None
    
    async def __aenter__(self):
        """Async context manager entry."""
        # Для long polling используем большой read timeout (90 сек)
        timeout_config = httpx.Timeout(
            connect=10.0,
            read=90.0,
            write=30.0,
            pool=30.0
        )
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            timeout=timeout_config,
            headers={
                "Authorization": self.token,
                "Content-Type": "application/json",
            }
        )
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        if self._client:
            await self._client.aclose()
    
    def _get_client(self) -> httpx.AsyncClient:
        """Получить HTTP клиент."""
        if self._client is None:
            # Для long polling используем большой read timeout (90 сек)
            timeout_config = httpx.Timeout(
                connect=10.0,
                read=90.0,
                write=30.0,
                pool=30.0
            )
            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                timeout=timeout_config,
                headers={
                    "Authorization": self.token,
                    "Content-Type": "application/json",
                }
            )
        return self._client
    
    async def close(self):
        """Закрыть клиент."""
        if self._client:
            await self._client.aclose()
            self._client = None
    
    async def call(
        self,
        method: str,
        http_method: HTTPMethod = "GET",
        body: Optional[Dict[str, Any]] = None,
        query: Optional[Dict[str, Any]] = None,
        path: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Выполнить API запрос.
        
        Args:
            method: Метод API (например, "/v1/chats/{chat_id}")
            http_method: HTTP метод
            body: Тело запроса
            query: Query параметры
            path: Параметры для подстановки в путь
            
        Returns:
            Ответ API
            
        Raises:
            httpx.HTTPError: При ошибке запроса
        """
        # Подставляем параметры в путь
        url = method
        if path:
            for key, value in path.items():
                url = url.replace(f"{{{key}}}", str(value))
        
        # Формируем запрос
        client = self._get_client()
        
        kwargs: Dict[str, Any] = {}
        if body:
            kwargs["json"] = body
        if query:
            # Фильтруем None значения
            kwargs["params"] = {k: v for k, v in query.items() if v is not None}
        
        logger.debug(f"Запрос {http_method} {url}, body={body}, query={query}")
        
        response = await client.request(
            method=http_method,
            url=url,
            **kwargs
        )
        
        logger.debug(f"Ответ {response.status_code}: {response.text[:200]}")
        
        # Проверяем статус
        if response.status_code == 401:
            raise httpx.HTTPError(
                "Invalid access_token",
                request=response.request,
                response=response
            )
        
        response.raise_for_status()
        
        return response.json()


__all__ = ["Client", "HTTPMethod"]
