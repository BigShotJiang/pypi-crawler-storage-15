"""
Long polling для получения обновлений.

Модуль содержит класс Polling для получения обновлений через getUpdates.
"""

import asyncio
import traceback
from typing import Optional, List, Callable, Awaitable, TYPE_CHECKING, Dict, Any

from ..logging_config import get_logger
from ..types import Update, UpdateType, parse_update

if TYPE_CHECKING:
    from ..api import Api


logger = get_logger("polling")

RETRY_INTERVAL = 5.0  # секунды


class Polling:
    """
    Long polling для получения обновлений от Max API.
    
    Реализует цикл опроса API с автоматическим управлением offset'ом
    и обработкой ошибок.
    """
    
    def __init__(
        self,
        api: "Api",
        allowed_updates: Optional[List["UpdateType"]] = None,
    ):
        """
        Инициализация polling.
        
        Args:
            api: API клиент
            allowed_updates: Список типов обновлений для получения
        """
        self.api = api
        self.allowed_updates = allowed_updates or []
        self.marker: Optional[int] = None
        self._stop_event = asyncio.Event()
        self._running = False
    
    async def loop(
        self,
        handle_update: Callable[["Update"], Awaitable[None]]
    ) -> None:
        """
        Запустить цикл получения обновлений.
        
        Args:
            handle_update: Функция обработки обновления
        """
        logger.info("Запуск long polling")
        self._running = True
        self._stop_event.clear()
        
        while not self._stop_event.is_set():
            try:
                # Получаем обновления
                logger.debug(f"Запрос обновлений (marker={self.marker})")
                response = await self.api.get_updates(
                    types=self.allowed_updates,
                    marker=self.marker,
                )
                
                updates_data = response.get("updates", [])
                new_marker = response.get("marker")
                
                logger.debug(f"Получено обновлений: {len(updates_data)}, новый marker: {new_marker}")
                
                self.marker = new_marker
                
                # Преобразуем словари в объекты Update
                updates: List[Update] = []
                for update_dict in updates_data:
                    try:
                        update = parse_update(update_dict)
                        updates.append(update)
                        logger.debug(f"Десериализовано обновление типа {update.update_type}")
                    except Exception as e:
                        logger.error(f"Не удалось десериализовать обновление: {e}")
                        logger.debug(f"Данные обновления: {update_dict}")
                
                # Обрабатываем обновления параллельно
                if updates:
                    logger.info(f"Обработка {len(updates)} обновлений")
                    results = await asyncio.gather(
                        *[handle_update(update) for update in updates],
                        return_exceptions=True
                    )
                    
                    # Проверяем ошибки
                    for i, result in enumerate(results):
                        if isinstance(result, Exception):
                            logger.error(f"Ошибка при обработке обновления {i}: {result}")
                
            except asyncio.CancelledError:
                logger.info("Polling отменён")
                break
                
            except Exception as err:
                logger.error(f"Не удалось получить обновления: {err}")
                logger.debug(f"Полная ошибка:\n{traceback.format_exc()}")
                
                # Проверяем тип ошибки для retry
                if self._should_retry(err):
                    logger.info(f"Повторная попытка через {RETRY_INTERVAL}с...")
                    try:
                        await asyncio.wait_for(
                            self._stop_event.wait(),
                            timeout=RETRY_INTERVAL
                        )
                    except asyncio.TimeoutError:
                        continue
                else:
                    # Критическая ошибка - прерываем
                    logger.exception("Критическая ошибка в цикле polling")
                    raise
        
        self._running = False
        logger.info("Long polling остановлен")
    
    def stop(self) -> None:
        """Остановить polling."""
        logger.info("Остановка long polling")
        self._stop_event.set()
    
    @property
    def is_running(self) -> bool:
        """Проверить, запущен ли polling."""
        return self._running
    
    @staticmethod
    def _should_retry(error: Exception) -> bool:
        """
        Определить, нужно ли повторять запрос при ошибке.
        
        Args:
            error: Исключение
            
        Returns:
            True если нужно повторить запрос
        """
        # TODO: Добавить проверку на конкретные типы ошибок
        # Например, сетевые ошибки, 429, 5xx
        return True


__all__ = ["Polling"]
