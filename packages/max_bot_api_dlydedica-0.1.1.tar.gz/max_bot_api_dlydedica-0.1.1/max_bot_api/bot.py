"""
Основной класс бота.

Модуль содержит класс Bot для создания и управления ботом.
"""

import asyncio
from typing import Optional, List, Callable, Awaitable, Dict, Any, TypeVar

from .api import Api
from .composer import Composer
from .context import Context
from .core.client import Client
from .core.polling import Polling
from .types import Update, UpdateType
from .logging_config import get_logger


logger = get_logger("bot")

Ctx = TypeVar("Ctx", bound=Context)


class Bot(Composer[Context]):
    """
    Основной класс бота.
    
    Наследует Composer для поддержки middleware и обработчиков.
    Управляет жизненным циклом бота и обработкой обновлений.
    """
    
    def __init__(
        self,
        token: str,
        base_url: str = "https://platform-api.max.ru",
        context_class: type = Context,
    ):
        """
        Инициализация бота.
        
        Args:
            token: Токен бота
            base_url: Базовый URL API
            context_class: Класс контекста для создания
        """
        super().__init__()
        
        self.token = token
        self.client = Client(token, base_url)
        self.api = Api(self.client)
        self.context_class = context_class
        
        self.bot_info: Optional[Dict[str, Any]] = None
        self.polling: Optional[Polling] = None
        self._polling_task: Optional[asyncio.Task] = None
        self._error_handler: Optional[Callable[[Exception, Context], Awaitable[None]]] = None
        
        logger.info("Создан экземпляр бота")
    
    def catch(
        self,
        handler: Callable[[Exception, Context], Awaitable[None]]
    ) -> "Bot":
        """
        Установить обработчик ошибок.
        
        Args:
            handler: Функция обработки ошибок
            
        Returns:
            Self для цепочки вызовов
            
        Example:
            >>> async def error_handler(error, ctx):
            ...     logger.error(f"Error: {error}")
            >>> bot.catch(error_handler)
        """
        self._error_handler = handler
        return self
    
    async def start(
        self,
        allowed_updates: Optional[List[UpdateType]] = None
    ) -> None:
        """
        Запустить бота в режиме long polling.
        
        Args:
            allowed_updates: Список типов обновлений для получения
            
        Example:
            >>> await bot.start()
            >>> # или с фильтром обновлений
            >>> await bot.start(allowed_updates=["message_created", "message_callback"])
        """
        if self._polling_task and not self._polling_task.done():
            logger.warning("Long polling уже запущен")
            return
        
        # Получаем информацию о боте
        if not self.bot_info:
            logger.info("Получение информации о боте...")
            self.bot_info = await self.api.get_my_info()
            username = self.bot_info.get('username', 'неизвестен')
            bot_id = self.bot_info.get('user_id', 'неизвестен')
            logger.info(f"Запуск бота @{username} (ID: {bot_id})")
        
        # Создаем polling
        self.polling = Polling(self.api, allowed_updates)
        logger.info(f"Фильтр обновлений: {allowed_updates or 'все типы'}")
        
        # Запускаем polling в фоне
        self._polling_task = asyncio.create_task(
            self.polling.loop(self._handle_update)
        )
        
        try:
            await self._polling_task
        except asyncio.CancelledError:
            logger.info("Бот остановлен")
    
    def stop(self) -> None:
        """
        Остановить бота.
        
        Останавливает polling и отменяет задачу обработки обновлений.
        """
        logger.info("Остановка бота")
        
        if self.polling:
            self.polling.stop()
        
        if self._polling_task and not self._polling_task.done():
            self._polling_task.cancel()
    
    async def _handle_update(self, update: Update) -> None:
        """
        Обработать обновление.
        
        Args:
            update: Обновление от API
        """
        update_id = f"{update.update_type}:{update.timestamp}"
        logger.debug(f"Обработка обновления {update_id}")
        
        # Создаем контекст
        ctx = self.context_class(update, self.api, self.bot_info)
        
        # Логируем детали обновления
        if hasattr(update, 'message') and update.message:
            logger.info(f"Получено сообщение от {update.message.sender.name if update.message.sender else 'неизвестно'}: {update.message.body.text if update.message.body.text else '<без текста>'}")
        else:
            logger.info(f"Получено обновление типа: {update.update_type}")
        
        try:
            # Выполняем middleware цепочку
            async def noop():
                pass
            
            await self.middleware()(ctx, noop)
            
        except Exception as err:
            # Обрабатываем ошибку
            if self._error_handler:
                try:
                    await self._error_handler(err, ctx)
                except Exception as handler_err:
                    logger.exception(f"Ошибка в обработчике ошибок: {handler_err}")
            else:
                # Дефолтная обработка - логируем и пробрасываем
                logger.exception(f"Необработанная ошибка при обработке {update_id}")
                raise
        finally:
            logger.debug(f"Завершена обработка обновления {update_id}")
    
    async def __aenter__(self):
        """Async context manager entry."""
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        self.stop()
        await self.client.close()


__all__ = ["Bot"]
