from enum import Enum


class OverheadDistribution(Enum):
    WEIGHT = "weight"
    VOLUME = "volume"
    PRICE = "price"
