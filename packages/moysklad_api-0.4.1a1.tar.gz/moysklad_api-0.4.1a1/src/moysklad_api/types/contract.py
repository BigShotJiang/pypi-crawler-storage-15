from .entity import Entity


class Contract(Entity):
    pass
