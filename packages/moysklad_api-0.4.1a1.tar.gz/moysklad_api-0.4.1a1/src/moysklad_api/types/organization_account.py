from .entity import Entity


class OrganizationAccount(Entity):
    pass
