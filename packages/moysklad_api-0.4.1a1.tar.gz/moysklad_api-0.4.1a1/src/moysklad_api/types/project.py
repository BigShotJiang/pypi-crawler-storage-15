from .entity import Entity


class Project(Entity):
    pass
