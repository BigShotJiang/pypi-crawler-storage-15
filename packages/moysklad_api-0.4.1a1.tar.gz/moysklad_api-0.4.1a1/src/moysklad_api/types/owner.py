from .entity import Entity


class Owner(Entity):
    pass
