from .report import Report


class Profit(Report):
    pass
