"""Setup script for backwards compatibility."""
from setuptools import setup

setup()

