"""Utilities of paddle."""
