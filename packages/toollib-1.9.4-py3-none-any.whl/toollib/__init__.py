"""
@author axiner
@version v1.0.0
@created 2021/12/12 13:14
@abstract This is a tool library.
@description
@history
"""
from pathlib import Path

here = Path(__file__).absolute().parent

__version__ = "1.9.4"
