# szn-doporucovani-async-rpc-cookieserver-client

This is a security placeholder package created to prevent dependency confusion attacks.