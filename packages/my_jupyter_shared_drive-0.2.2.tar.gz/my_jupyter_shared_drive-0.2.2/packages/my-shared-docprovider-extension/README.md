# @jupyter/my-shared-docprovider-extension

A JupyterLab package which provides a set of plugins for collaborative shared models.
