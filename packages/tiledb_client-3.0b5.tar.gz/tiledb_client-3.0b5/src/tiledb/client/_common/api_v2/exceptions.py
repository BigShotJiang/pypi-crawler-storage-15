"""Re-exporting the ``exceptions`` namespace."""

from tiledb.client.rest_api.exceptions import *  # noqa: F401,F403
