from typing import Any, Optional
from google.adk.agents.base_agent import BaseAgent
from google.adk.agents.callback_context import CallbackContext
from google.adk.plugins.base_plugin import BasePlugin
from google.adk.tools.base_tool import BaseTool
from google.adk.tools.tool_context import ToolContext
from google.adk.events import Event
from google.genai import types

from .opa import (
    OPABaseClient,
    OPADKRequestInput,
    OPADKRequestAgent,
    OPADKRequestTool,
    OPADKResponse,
)


class OPADKPlugin(BasePlugin):
    """
    Plugin that integrates OPA policy checks into agent and tool invocations.
    """

    opa_client: OPABaseClient

    def __init__(
        self,
        opa_client: OPABaseClient,
    ) -> None:
        super().__init__(name="opadk_plugin")
        self.opa_client = opa_client

    async def before_agent_callback(
        self, agent: BaseAgent, callback_context: CallbackContext
    ) -> Optional[types.Content]:
        outcome = await self.opa_client.is_allowed(
            scope="agent",
            input=OPADKRequestInput(
                state=callback_context.state.to_dict(),
                agent=OPADKRequestAgent(name=agent.name),
                events=_serialize_events(callback_context.session.events),
            ).model_dump(),
        )

        if not outcome.allowed:
            return self.agent_access_denied_response(outcome)

    async def before_tool_callback(
        self,
        *,
        tool_context: ToolContext,
        tool: BaseTool,
        tool_args: dict[str, Any],
    ) -> Optional[dict[str, Any]]:
        outcome = await self.opa_client.is_allowed(
            scope="tool",
            input=OPADKRequestInput(
                state=tool_context.state.to_dict(),
                agent=OPADKRequestAgent(name=tool_context.agent_name),
                tool=OPADKRequestTool(
                    name=tool.name,
                    args=tool_args,
                ),
                events=_serialize_events(tool_context.session.events),
            ).model_dump(),
        )

        if not outcome.allowed:
            return self.tool_access_denied_response(outcome)

    def tool_access_denied_response(self, outcome: OPADKResponse) -> dict[str, Any]:
        """
        Response when tool access is denied by policy.
        """
        return {
            "error": "Tool invocation not allowed by policy.",
            "reasons": outcome.reasons,
        }

    def agent_access_denied_response(self, outcome: OPADKResponse) -> types.Content:
        """
        Response when agent access is denied by policy.
        """
        parts = ["Agent invocation not allowed by policy."]

        if outcome.reasons:
            parts.append("Reasons:")
            for reason in outcome.reasons:
                parts.append(f"- {reason}")

        return types.Content(
            parts=[
                types.Part.from_text(
                    text="\n".join(parts),
                ),
            ]
        )


def _serialize_events(events: list[Event]) -> list[dict[str, Any]]:
    return [
        e.model_dump(
            mode="json", exclude_none=True, exclude_defaults=True, exclude_unset=True
        )
        for e in events
    ]
