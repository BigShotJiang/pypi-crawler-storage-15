import asyncio
from typing import Any, Optional, Literal
from pydantic import BaseModel
import subprocess
import json
import aiohttp

Scopes = Literal["agent", "tool"]


class OPADKResponse(BaseModel):
    allowed: bool = False
    reasons: list[str] = []


class OPADKRequestAgent(BaseModel):
    name: str


class OPADKRequestTool(BaseModel):
    name: str
    args: dict[str, Any]


class OPADKRequestInput(BaseModel):
    """
    Input schema for OPA policy evaluation.
    """

    state: dict[str, Any]
    agent: OPADKRequestAgent
    tool: Optional[OPADKRequestTool] = None
    events: Optional[list[dict[str, Any]]] = None


class OPABaseClient(BaseModel):
    async def is_allowed(self, scope: Scopes, input: dict[str, Any]) -> OPADKResponse:
        raise NotImplementedError()

    def rego_query(self, namespace: list[str], scopes: Scopes) -> str:
        allowed = ["data"] + namespace + ["allow", scopes]
        reasons = ["data"] + namespace + ["deny", scopes, "reasons"]
        query = (
            """
            allowed = array.concat([true | %s], [false])[0];
            reasons = [msg | msg = %s[_]]
            """.strip()
            % (".".join(allowed), ".".join(reasons))
        )
        return query


class OPARemoteClient(OPABaseClient):
    """
    OPA client that uses the eval API to query a remote OPA server.
    """

    server_url: str
    namespace: list[str] = ["adk"]

    async def is_allowed(self, scope: Scopes, input: dict[str, Any]) -> OPADKResponse:
        async with aiohttp.ClientSession(base_url=self.server_url) as session:
            async with session.post(
                "/v1/query",
                json={"input": input, "query": self.rego_query(self.namespace, scope)},
                params={"mode": "pretty"},
            ) as response:
                json = await response.json()
                result = json.get("result")
                if result and len(result) > 0:
                    result = result[0]
                    return OPADKResponse(**result)
        raise Exception("OPA query failed")


class OPARunClient(OPABaseClient):
    """
    OPA client that runs the `opa eval` command locally for development/testing.
    """

    opa_path: str = "opa"
    bundle_path: str
    namespace: list[str] = ["adk"]

    async def is_allowed(self, scope: Scopes, input: dict[str, Any]) -> OPADKResponse:
        process = await asyncio.create_subprocess_exec(
            self.opa_path,
            "eval",
            "--format",
            "json",
            "--bundle",
            self.bundle_path,
            "--stdin-input",
            self.rego_query(self.namespace, scope),
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

        stdout, _stderr = await process.communicate(json.dumps(input).encode())

        try:
            data = json.loads(stdout.decode())
        except Exception as e:
            raise Exception(f"Failed to decode OPA response: {e}")

        if data.get("errors"):
            raise Exception(f"OPA returned errors: {data['errors']}")

        result = data.get("result")
        if result and len(result) > 0:
            entry = result[0]
            bindings = entry.get("bindings") or {}
            allowed = bool(bindings.get("allowed", False))
            reasons = bindings.get("reasons", []) or []
            return OPADKResponse(allowed=allowed, reasons=reasons)

        raise Exception("OPA query returned empty result")
