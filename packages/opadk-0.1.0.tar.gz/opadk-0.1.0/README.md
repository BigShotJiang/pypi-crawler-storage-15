# OPADK

Plugin for Agent Development Kit (ADK) that integrates with Open Policy Agent (OPA) for policy enforcement on agent and tool usage.

## Integration

```python
from opadk
runner = InMemoryRunner(
    agent=root_agent,
    app_name="agent",
    plugins=[OPADKPlugin(client=OPAClient(server_url="http://localhost:8181"))],
)
```

## Rego Policies

OPADK expects `data.adk.allow.agent` and `data.adk.allow.tool` rules to determine if an agent or tool usage is allowed.
Reasons for denial should be provided in `data.adk.deny.agent.reasons` and `data.adk.deny.tool.reasons` respectively.

```rego
package adk

allow.agent = true
allow.tool = true
```

## Sample Policies

### Access Control

```rego
_allowed_user_agents = {
  "user1": {"root_agent", "data_agent"},
  "user2": {"root_agent", "analytics_agent", "report_agent"},
}

_user_can_use_agent if {
  input.agent.name in _allowed_user_agents[input.state.user_id]
}

allow.agent if _user_can_use_agent

deny.agent.reasons contains sprintf(
  "User does not have access to agent `%v`", [input.agent.name]
) if {
  not _user_can_use_agent
}
```

### Tool authorization

```rego
allow.tool if {
  input.tool.name in {"update_profile"}
  input.tool.args.user_id == input.state.user_id
}
```

### Limit tool parameters

```rego
_allowed_containers := {
  "python": "python:3.14-alpine@sha256:8373231e1e906ddfb457748bfc032c4c06ada8c759b7b62d9c73ec2a3c56e710",
}

_container_run_command_allowed if {
  input.tool.args.image == _allowed_containers[_]
}

allow.tool if {
  input.tool.name in {"container_run_command"}
  _container_run_command_allowed
}

deny.tool.reasons contains sprintf(
  "Parameter `image` must be one of: %v", [allowed_containers]
) if {
  input.tool.name in {"container_run_command"}
  not _container_run_command_allowed
  allowed_containers = [image | _allowed_containers[_] = image]
}
```
