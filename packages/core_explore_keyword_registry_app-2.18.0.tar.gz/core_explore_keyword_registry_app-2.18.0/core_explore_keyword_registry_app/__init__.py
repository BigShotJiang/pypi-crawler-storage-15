""" App init
"""

default_app_config = (
    "core_explore_keyword_registry_app.apps.ExploreKeywordRegistryAppConfig"
)
