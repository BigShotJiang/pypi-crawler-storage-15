import enum


class Feedback(enum.Enum):
    PROGRESS_BAR = 0
    TABULAR = 1
