# gamesxblock
XBlock to display game content within the Open edX LMS

### Supported Games
| Game type      | Features   |
|----------------|------------|
| **Flashcards** | `Shuffled` |
|                | `Image`    |
| **Matching**   | `Shuffled` |
|                | `Timed`    |