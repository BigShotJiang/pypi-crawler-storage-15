from configlite.config import BaseConfig


__all__ = ["BaseConfig"]
__version__ = "0.1.0"
