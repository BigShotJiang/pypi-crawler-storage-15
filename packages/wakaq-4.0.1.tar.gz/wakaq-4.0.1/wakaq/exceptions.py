class WakaQError(Exception):
    pass


class SoftTimeout(WakaQError):
    pass
