from .util import absolute_url as absolute_url  # noqa: F401
