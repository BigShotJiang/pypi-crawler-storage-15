def main():
    print("Hello from qen!")


if __name__ == "__main__":
    main()
