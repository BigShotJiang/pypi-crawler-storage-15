from SciQLopPlots import ProductsModel
TIME_RANGE_MIME_TYPE = "application/x.sciqlop.time-range"
PRODUCT_LIST_MIME_TYPE = ProductsModel.mime_type()

