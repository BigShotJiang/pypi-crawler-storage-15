from bluer_algo.help.yolo.dataset import help_functions as help_dataset
from bluer_algo.help.yolo.model import help_functions as help_model

help_functions = {
    "dataset": help_dataset,
    "model": help_model,
}
