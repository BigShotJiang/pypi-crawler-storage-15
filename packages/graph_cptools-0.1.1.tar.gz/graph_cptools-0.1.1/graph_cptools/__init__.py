# your_package_name/__init__.py
__version__ = "0.1.1"  # 版本号（遵循语义化版本：主版本.次版本.修订版）
__author__ = "yoyo"