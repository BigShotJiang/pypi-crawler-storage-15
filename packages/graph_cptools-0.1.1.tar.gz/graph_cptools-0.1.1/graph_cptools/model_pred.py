import pandas as pd

def jb_cal_pxy(df):
    # ----------------------1、时间类变量-（12个）-----
    # 时间处理
    df['issue_time']=pd.to_datetime(df.issue_time, unit='s')
    df['record_time']=pd.to_datetime(df.record_time, unit='s')
    df['history_time']=pd.to_datetime(df.history_time, unit='s')
    # 各个时间特征的时间差
    df['work_year'] = (df.issue_time - df.history_time) .dt.days/30/12 #年份
    df['work_month'] = (df.issue_time - df.history_time) .dt.days/30 #月份
    df['record_history_inter'] = (df.record_time -df.history_time) .dt.days/30 #月份
    df['record_issue_inter'] = (df.record_time - df.issue_time) .dt.days /30  #月份
    # 年份、月份、季度划分：
    df['issue_time_y_cut'] =df.issue_time.dt.year.clip(lower=2005)
    df['record_time_y_cut'] =df.record_time.dt.year.clip(lower=2004,upper=2011)
    df['issue_time_m']    = df['issue_time'].dt.month
    df['record_time_m']  = df['record_time'].dt.month
    df['history_time_m'] = df['history_time'].dt.month
    df['issue_time_q']    = (df['issue_time'].dt.month-1)/3
    df['record_time_q']  = (df['record_time'].dt.month-1)/3
    df['history_time_q'] = (df['history_time'].dt.month-1)/3

    #--------------------2、金额、利率、数量类---------------------------
    # 2.1期限利率乘积（+2）
    df['term_rate_product'] = df['term'] * df['interest_rate'] #期限*利率
    df['loan_lx'] = df['loan'] * df['interest_rate'] * df['term'] #期限*本金*利率
    # 2.2利率与同期限的客户平均水平、中位水平的对比（+2）
    term_mean = df.groupby('term')['interest_rate'].mean()
    df['interest_rate_duibi1'] = df['interest_rate'] - df['term'].map(term_mean)
    term_medians = df.groupby('term')['interest_rate'].median()
    df['interest_rate_duibi2'] = df['interest_rate'] - df['term'].map(term_medians)
    # 2.3每期还款额 每期还本、每期还本息、额度使用率（+4）
    df['loan_term'] = df['loan'] / df['term']
    df['loan_add_lx_term'] = (df['loan'] + df['loan_lx']) / df['term']
    df['loan_plus_balance_pct'] = (df['loan'] + df['balance']) / (df['balance'] +1e-8)
    df['loan_plus_balance_limit_pct'] = (df['loan'] + df['balance']) / (df['balance_limit'] + 1e-8)
    # 2.4账户平均余额 金额/账户数（+3）
    df['balance_avg'] = df.balance / df.balance_accounts
    df['balance_limit_avg'] = df.balance_limit / df.balance_accounts
    df['balance_total_avg'] = df.balance / df.total_accounts
    # 2.5有效账户占比：账户/账户(+1)
    df['valid_accounts_rate'] = df.balance_accounts / df.total_accounts
    # 2.6申请金额占比：剩余额度/贷款金额(+1)
    df['loan_rate'] = (df.balance_limit - df.balance) / df.loan
    # 2.7金额类的互相除法(+12=(5-1)*(4-1))
    for i in ['loan_lx','loan','balance','balance_limit']:
        for j in ['loan_lx','loan','balance','balance_limit']:
            if i==j:
                pass
            else:
                df['%s_to_%s_ratio'%(i,j)] = df['%s'%i]/(df['%s'%j]+1e-8)
    # 2.8工龄与金额的组合(+8)
    for i in  ['loan','balance','balance_limit','balance_accounts','total_accounts','term','loan_lx','loan_add_lx_term']:
        df['%s_to_work_year_ratio' % i] = df[i] / (df['work_year'] + 1) 

    #--------------------3、类别变量---------------------------
    # 3.1level映射(+1)
    df['level_map']=df.level.rank(method='dense')
    # 3.2risk_code 编码简化 、高风险和低风险，不用记编码(+2)
    df['risk_code_2'] = df['zip_code'].apply(lambda x: str(x)[:2])
    df['risk_code'] = df['zip_code'].astype(str).str.slice(0,2).apply(lambda x: 2 if x in [ '23', '44', '10', '22', '14', '47', '21', '30', '41', '54', '27', '59','26'] else (0 if x in [
        '57', '39', '49', '35', '16', '25', '45', '50', '53', '28', '51', '36'] else 1))
    # 3.3高风险residence(+2)
    df['risk_residence'] = df['residence'].apply(lambda x: 1 if x in [0, 3] else 0)
    # 是否低频residence
    df['freq_low_residence'] = df['residence'].apply(lambda x: 1 if x in [3, 4, 5, 6] else 0)
    # 3.4类别变量做频率转换，并统计每个分类里面level为最好最差两类的占比（A,CDE），以及长短期占比（+30=6*5）
    for col in ['career', 'title', 'residence', 'syndicated', 'installment','risk_code']:  
        df[col] = df[col].fillna(11)
        career_freq = df[col].value_counts(normalize=True).to_dict()
        df["%s_freq" % col] = df[col].map(career_freq)
        # level占比
        levelA_count = df[df['level'].str.contains('A0|A1|A2')].groupby(col)['id'].count() / df.groupby(col)['id'].count()
        levelCDE_count = df[df['level'].str.contains('C|D|E')].groupby(col)['id'].count() / df.groupby(col)['id'].count()
        df["%s_levelA_count" % col] = df[col].map(levelA_count)
        df["%s_levelCDE_count" % col] = df[col].map(levelCDE_count)
        # 长期期限占比
        trem60_count = df[df['term'] == 60].groupby(col)['id'].count() / df.groupby(col)['id'].count()
        trem12_count = df[df['term'] == 12].groupby(col)['id'].count() / df.groupby(col)['id'].count()
        df["%s_trem60_count" % col] = df[col].map(trem60_count)
        df["%s_trem12_count" % col] = df[col].map(trem12_count)
    # 3.5构造多类别：事业+职位、银团及分期、事业与分期（+2）
    df['title_career'] = df["title"].astype(str) + "_" + df["career"].astype(str)
    df['syndicated_installment'] = df["syndicated"].astype(str) + "_" + df["installment"].astype(str)
    # 3.6事业和是否分期细分：事业有明显特点：缺失风险高，10为高频（+1）
    df['career_installment'] = df.apply( lambda x: str(x['career']) + "_" + str(x['installment'])
        if x['career'] in [10, 11] else str(9) + "_" + str(x['installment']), axis=1)
    # 3.7在新分组内的位置分布，均值差异    ：a/组内均值 ，a/组内中位数（+24=4*3*2）
    for j in ['title_career', 'syndicated_installment', 'career_installment', 'term']:
        for i in ['interest_rate', 'work_year', 'level_map']:
            tmp1 = df.groupby(j)[i].mean()
            tmp2 = df.groupby(j)[i].median()
            df['%s_duibi1_%s' % (j, i)] = df[i] / df[j].map(tmp1)
            df['%s_duibi2_%s' % (j, i)] = df[i] / df[j].map(tmp2)

    #--------------------------------4、增加一些数据变换、数值混合、分类与数值变量的交叉统计变换处理-----------------
    amt_num_cols = ['loan', 'balance_limit', 'balance', 'balance_avg', 'loan_lx']  #金额类
    others_num_cols = ['term', 'interest_rate', 'total_accounts', 'balance_accounts','loan_add_lx_term']  #数量
    cat_cols = ['title', 'career', 'residence', 'syndicated', 'installment', 'level',
        'risk_code', 'risk_code_2', 'issue_time_y_cut', 'record_time_y_cut']  #类别
    # 4.1金额类加减乘除（+50）
    for i in range(len(amt_num_cols)):
        for j in range(i, len(amt_num_cols)):
            col1 = amt_num_cols[i]
            col2 = amt_num_cols[j]
            if col1 != col2:
                # 比率特征 a/b
                df[f'{col1}_over_{col2}'] = df[col1] / (df[col2] + 1e-8)
                # 加减特征 a+b a-b
                df[f'{col1}_plus_{col2}'] = df[col1] + df[col2]
                df[f'{col1}_minus_{col2}'] = df[col1] - df[col2]
                # 乘积特征 (a-b)/a  (a-b)/b
                df[f'{col1}_{col2}_deat_times_{col2}_pct'] = df[f'{col1}_minus_{col2}'] / (df[col2] + 1e-8)
                df[f'{col1}_{col2}_deat_times_{col1}_pct'] = df[f'{col1}_minus_{col2}'] / (df[col1] + 1e-8)
    # 4.2类别与数值交叉特征  a/组内统计量(+900)
    for cat_col in cat_cols:
        for num_col in amt_num_cols+others_num_cols:
            # 类别内数值统计特征 
            df[f'{num_col}_by_{cat_col}_mean'] = df.groupby(cat_col)[num_col].transform('mean')
            df[f'{num_col}_by_{cat_col}_median'] = df.groupby(cat_col)[num_col].transform('median')
            df[f'{num_col}_by_{cat_col}_std'] = df.groupby(cat_col)[num_col].transform('std')
            df[f'{num_col}_by_{cat_col}_max'] = df.groupby(cat_col)[num_col].transform('max')
            df[f'{num_col}_by_{cat_col}_max'] = df[f'{num_col}_by_{cat_col}_max'].astype('float')

            df[f'{num_col}_by_{cat_col}_mean_duibi'] = df[num_col] / df[cat_col].map(df.groupby(cat_col)[num_col].mean())
            df[f'{num_col}_by_{cat_col}_median_duibi'] = df[num_col] / df[cat_col].map(df.groupby(cat_col)[num_col].median())
            df[f'{num_col}_by_{cat_col}_std_duibi'] = df[num_col] / df[cat_col].map(df.groupby(cat_col)[num_col].std())
            df[f'{num_col}_by_{cat_col}_max_duibi'] = df[num_col] / df[cat_col].map(df.groupby(cat_col)[num_col].max())
            df[f'{num_col}_by_{cat_col}_min_duibi'] = df[num_col] / df[cat_col].map(df.groupby(cat_col)[num_col].min())
    # 4.3金额+数量类的：与统计特征的差异值 (+40)
    for col in amt_num_cols+others_num_cols:
        mean_val = df[col].mean() #均值
        std_val = abs(df[col].std()) #方差
        median_val = df[col].median() #中位数
        df[f'{col}_by_median_duibi'] = (df[col] -median_val) / df[col] #（a-中位数)/a 
        df[f'{col}_by_mean_duibi'] = (df[col] -mean_val) / df[col] # （a-均值)/a   
        df[f'{col}_均值偏离'] = (df[col] - mean_val) / std_val  #(a-中位数)/方差
        df[f'{col}_中位数偏离'] = (df[col] - median_val) / std_val  #(a-均值)/方差
    # 剔除9个
    df = df.drop(['zip_code','title_career','risk_code_2','syndicated_installment','career_installment','issue_time','record_time','history_time','level'],axis=1)
    return df

def jb_cal_cll(df):
    # ----------------------1、数据预处理（1个）------
    # 1.1缺失值填充，类别类填充为众数、数值类均值
    for col in [x for x in  df.columns if x not in ['id', 'label']]:
        if col in ['syndicated', 'title', 'career', 'residence', 'installment', 'level']: #（6个）
            df[col] = df[col].fillna(df[col].mode())
        else:
            df[col] = df[col].fillna(df[col].mean())
    # 1.2zip_code预处理，取前2、3位
    df['zip_code_2'] =  df['zip_code'].astype(str).str.slice(0,2)
    df['zip_code_3'] =  df['zip_code'].astype(str).str.slice(0,3)    
    # 1.3level编码  第一位排序*10+第二位(+1)
    df["level_encoded"] = df.level.str.slice(0,1).rank(method='dense')*10+df.level.str.slice(1,2).astype(int)
    # ----------------------2、时间类变量-（15个）-----
    # 时间预处理、取年份、年月（+6）
    time_cols = ['issue_time', 'record_time', 'history_time']
    for time_col in time_cols:
        df[time_col]=pd.to_datetime(df[time_col], unit='s') # 转换格式
        df[f'{time_col}_year'] = df[time_col ].dt.year # 取年份
        df[f'{time_col}_yearmonth'] = df[time_col].dt.strftime('%Y%m').astype(int) #取年月
    # 时间差特征（+9）
    df['ri_day'] = (df['issue_time'] - df['record_time']).dt.days  # 申请-记录 天数
    df['hi_day'] = (df['issue_time'] - df['history_time']).dt.days  # 申请-历史 天数
    df['rh_day'] = (df['record_time'] - df['history_time']).dt.days  # 记录-历史 天数
    df['ri_yr'] = (df.record_time - df.issue_time) .dt.days /30/12   #年份
    df['hi_yr'] = (df.issue_time - df.history_time) .dt.days/30/12 #年份
    df['rh_yr'] = (df.record_time -df.history_time) .dt.days/30/12  #年份
    df['ri_mon'] = (df.record_time - df.issue_time) .dt.days /30  #月份
    df['hi_mon'] = (df.issue_time - df.history_time) .dt.days/30 #月份
    df['rh_mon'] = (df.record_time -df.history_time) .dt.days/30 #月份

    # ----------------------3、数值类变量-（15个）-----
    # 3.1数值两两加减乘除 +-*/ (+112)
    num_cols = ['loan', 'term', 'total_accounts', 'balance_accounts','balance_limit', 'balance', 'interest_rate', 'level_encoded']
    for col1, col2 in list(itertools.combinations(num_cols, 2)):
        df[f'{col1}_x_{col2}'] = df[col1] * df[col2]
        df[f'{col1}_div_{col2}'] = np.where(df[col2] != 0, df[col1] / df[col2], 0)
        df[f'{col1}_plus_{col2}'] = df[col1] + df[col2]
        df[f'{col1}_minus_{col2}'] = df[col1] - df[col2]

    # 3.2金额类 平方、开方、指数、对数、标准化(+15)
    non_linear_cols = ['loan', 'balance_limit', 'balance']
    for col in non_linear_cols:
        df[f'{col}_square'] = df[col] ** 2
        df[f'{col}_sqrt'] = np.sqrt(df[col].clip(lower=0))
        df[f'{col}_exp'] = np.exp(df[col].clip(lower=0, upper=5))
        df[f'{col}_log2'] = np.log2(df[col].clip(lower=1))
        df[f'{col}_norm'] = StandardScaler() .fit_transform(df[col].clip(lower=0).values.reshape(-1, 1)).flatten()

    # 3.3金额类分箱(+9=3*3)
    bin_cols = ['loan', 'balance_limit', 'balance']
    for col in bin_cols:
        df[f'{col}_qcut_5'] = pd.qcut(df[col].clip(lower=0,), 5, labels=False, duplicates='drop').fillna(-1).astype(int)
        df[f'{col}_cut_5'] = pd.cut(df[col].clip(lower=0), 5, labels=False, duplicates='drop').fillna(-1).astype(int)
        if col == 'interest_rate':
            bins = [0, 5, 10, 15, 20, np.inf]
        elif col == 'term':
            bins = [0, 12, 24, 36, 48, np.inf]
        else:
            bins = [0, df[col].quantile(0.2), df[col].quantile(0.4), df[col].quantile(0.6), df[col].quantile(0.8), np.inf]
        df[f'{col}_custom_bin'] = pd.cut(df[col].clip(lower=0), bins=bins, labels=False, include_lowest=True).fillna(-1).astype(int)
    # 3.4利率分箱(+2)
    df['interest_rate_level'] = pd.cut(df['interest_rate'], bins=[0, 5, 10, 15, 20, np.inf], labels=[0, 1, 2, 3, 4],  include_lowest=True).astype(int) 
    # 3.5 高利率标记
    df['high_interest_flag'] = (df['interest_rate'] > 15).astype(int)  # 高利率标记（>15%）

    # ----------------------4、类别变量及交叉-（217个）-----
    # 4.1类别变量计数/频率特征(+16=8*2)
    cat_cols = ['title', 'career', 'residence', 'syndicated', 'installment', 'level_encoded','zip_code_2', 'zip_code_3']  
    for col in cat_cols:
        count_map = df[col].value_counts().to_dict()
        df[f'{col}_global_count'] = df[col].map(count_map).fillna(0).astype(int)
        df[f'{col}_global_freq'] = df[f'{col}_global_count'] / len(df)

    # 4.2类别×类别共线特征(+56)
    cat_pairs = list(itertools.combinations(cat_cols, 2))
    for col1, col2 in cat_pairs:
        df[f'{col1}_{col2}_pair'] = df[col1].astype(str) + '_' + df[col2].astype(str)
        pair_count_map = df[f'{col1}_{col2}_pair'].value_counts().to_dict()
        df[f'{col1}_{col2}_co_count'] = df[f'{col1}_{col2}_pair'].map(pair_count_map).fillna(0).astype(int)
        col1_count_map = df[col1].value_counts().to_dict()
        df[f'{col1}_{col2}_co_freq_rel_{col1}'] = np.where(
            df[col1].map(col1_count_map) != 0,
            df[f'{col1}_{col2}_co_count'] / df[col1].map(col1_count_map),
            0
        )
    df=df[[x for x in df.columns if x.endswith('_pair')==False]]# 删除_pair结尾临时交互列

    # 4.3 分组聚合特征（按类别变量统计，高区分度）(+175 =5*5*7)
    group_cols = ['zip_code_2', 'zip_code_3', 'career', 'title', 'residence']
    agg_features = ['loan', 'interest_rate', 'balance_limit', 'term', 'total_accounts']
    for group_col in group_cols:
        for agg_col in agg_features:
            # 分组统计：均值、中位数、最大值、最小值、标准差
            df[f'{group_col}_{agg_col}_mean'] = df.groupby(group_col)[agg_col].transform('mean')
            df[f'{group_col}_{agg_col}_median'] = df.groupby(group_col)[agg_col].transform('median')
            df[f'{group_col}_{agg_col}_max'] = df.groupby(group_col)[agg_col].transform('max')
            df[f'{group_col}_{agg_col}_min'] = df.groupby(group_col)[agg_col].transform('min')
            df[f'{group_col}_{agg_col}_std'] = df.groupby(group_col)[agg_col].transform('std').fillna(0)
            # 个体与分组的差异（区分度核心）
            df[f'{group_col}_{agg_col}_diff_from_mean'] = df[agg_col] - df[f'{group_col}_{agg_col}_mean']
            df[f'{group_col}_{agg_col}_ratio_to_mean'] = df[agg_col] / df[f'{group_col}_{agg_col}_mean'].clip(lower=1)    
    # 剔除无用特征
    df = df.drop(['zip_code','issue_time','record_time','history_time','zip_code_2','zip_code_3','level'],axis=1)
    return df

def flow_cal(df):
    # 日期级处理（仅保留日期，去除时间部分）
    df['date'] = pd.to_datetime(df['time'], unit='s').dt.normalize()  # 转为date类型
    # 增加收入金额、支出金额字段
    df.loc[df.direction == 1, '收入金额'] = df.loc[df.direction == 1, 'amount']
    df.loc[df.direction == 0, '支出金额'] = df.loc[df.direction == 0, 'amount']
    # 合并最后交易日期到原始df，用于计算距离交易天数
    tmp = df.groupby(['id']).agg(最早交易时间=('date', min),
                                 最晚交易时间=('date', 'max')).reset_index()
    df = df.merge(tmp, on='id', how='left')
    df['距离最晚交易天数'] = (df['最晚交易时间'] - df['date']).dt.days

    # -------------------- 1. 交易频次特征（13个）--------------------
    # 基础频次-4
    fea_cnt1 = df.groupby('id').agg(
        交易笔数=('amount', 'count'),  # 交易笔数
        收入笔数=('收入金额', 'count'),  # 收入笔数
        支出笔数=('支出金额', 'count'),  # 支出笔数
        交易天数=('date', 'nunique')  # 活跃日期数（有交易的天数）
    ).reset_index()  # id转为列
    # 占比特征-3
    fea_cnt1['收入笔数占比'] = fea_cnt1['收入笔数'] / fea_cnt1['交易笔数']
    fea_cnt1['收入支出笔数比'] = fea_cnt1['收入笔数'] / fea_cnt1['支出笔数']
    fea_cnt1['日均交易笔数'] = fea_cnt1['交易笔数'] / fea_cnt1['交易天数']
    # 平均距今天数-1
    fea_cnt2 = df.groupby('id').agg(平均距今天数=('距离最晚交易天数', 'mean')).reset_index()
    # 近30天交易特征-3
    fea_cnt3 = df[df.距离最晚交易天数 <= 30].groupby('id').agg(
        近30天交易笔数=('amount', 'count'),
        近30天收入笔数=('收入金额', 'count'),
        近30天支出笔数=('支出金额', 'count')).round(2).reset_index()
    # 合并
    fea_cnt = fea_cnt1.merge(fea_cnt2, how='left').merge(fea_cnt3, how='left')
    # 衍生近30天交易特征-2
    fea_cnt['近30天交易笔数占比'] = fea_cnt['近30天交易笔数'] / fea_cnt['交易笔数']
    fea_cnt['近30天收入交易笔数占比'] = fea_cnt['近30天收入笔数'] / fea_cnt['近30天交易笔数']

    # -------------------- 2. 交易金额特征（47个）--------------------
    # 交易金额的['sum', 'mean', 'median', 'std', 'max', 'min', 'skew']-21
    fea_amt1 = df.groupby('id').agg(收入金额=('收入金额', 'sum'),
                                    收入金额mean=('收入金额', 'mean'),
                                    收入金额media=('收入金额', 'median'),
                                    收入金额std=('收入金额', 'std'),
                                    收入金额max=('收入金额', 'max'),
                                    收入金额min=('收入金额', 'min'),
                                    收入金额skew=('收入金额', 'skew'),
                                    支出金额=('支出金额', 'sum'),
                                    支出金额mean=('支出金额', 'mean'),
                                    支出金额media=('支出金额', 'median'),
                                    支出金额std=('支出金额', 'std'),
                                    支出金额max=('支出金额', 'max'),
                                    支出金额min=('支出金额', 'min'),
                                    支出金额skew=('支出金额', 'skew'),
                                    交易金额=('amount', 'sum'),
                                    交易金额mean=('amount', 'mean'),
                                    交易金额media=('amount', 'median'),
                                    交易金额std=('amount', 'std'),
                                    交易金额max=('amount', 'max'),
                                    交易金额min=('amount', 'min'),
                                    交易金额skew=('amount', 'skew')).reset_index()
    # 占比衍生-5
    fea_amt1['收入金额占比'] = fea_amt1['收入金额'] / fea_amt1['交易金额']
    fea_amt1['收入支出金额比'] = fea_amt1['收入金额'] / fea_amt1['支出金额']
    fea_amt1['交易金额mean比'] = fea_amt1['收入金额mean'] / fea_amt1['支出金额mean']
    fea_amt1['交易最大最小金额比'] = fea_amt1['交易金额max'] / fea_amt1['交易金额min']
    fea_amt1['交易金额变异系数'] = fea_amt1['交易金额std'] / fea_amt1['交易金额mean']
    # 交易金额分位数-9
    fea_amt2 = df.groupby('id').agg(
        收入金额25分位=('收入金额', lambda x: x.quantile(0.25)),
        收入金额75分位=('收入金额', lambda x: x.quantile(0.75)),
        收入金额90分位=('收入金额', lambda x: x.quantile(0.90)),
        支出金额25分位=('支出金额', lambda x: x.quantile(0.25)),
        支出金额75分位=('支出金额', lambda x: x.quantile(0.75)),
        支出金额90分位=('支出金额', lambda x: x.quantile(0.90)),
        交易金额25分位=('amount', lambda x: x.quantile(0.25)),
        交易金额75分位=('amount', lambda x: x.quantile(0.75)),
        交易金额90分位=('amount', lambda x: x.quantile(0.90))).round(2).reset_index()
    #近30天交易金额-3
    fea_amt3 = df[df.距离最晚交易天数 <= 30].groupby('id').agg(
        近30天日均金额=('amount', 'mean'),
        近30天收入金额=('收入金额', 'sum'),
        近30天支出金额=('支出金额', 'sum')).round(2).reset_index()
    fea_amt = fea_amt1.merge(fea_amt2).merge(fea_amt3)
    #近30天交易金额衍生-1
    fea_amt['近30天日均金额占比'] = fea_amt['近30天日均金额'] / fea_amt['交易金额mean']
    # 变异系数-2
    fea_amt['收入金额变异系数'] = fea_amt['收入金额std'] / fea_amt['收入金额mean']
    fea_amt['支出金额变异系数'] = fea_amt['支出金额std'] / fea_amt['支出金额mean']
    #大小额占比-4
    fea_amt['最大额占比'] = fea_amt['交易金额max'] / fea_amt['交易金额']
    fea_amt['最小额占比'] = fea_amt['交易金额min'] / fea_amt['交易金额']
    fea_amt['最大收入额占比'] = fea_amt['收入金额max'] / fea_amt['收入金额']
    fea_amt['最大支出额占比'] = fea_amt['支出金额max'] / fea_amt['支出金额']
    #近30日占比-2
    fea_amt['近30天收入占比'] = fea_amt['近30天收入金额'] / fea_amt['收入金额']
    fea_amt['近30天支出金额占比'] = fea_amt['近30天支出金额'] / fea_amt['支出金额']

    # -------------------- 3. top3交易金额占比（3个）--------------------
    # top3交易金额占比-3
    def top3_amt(amounts):
        top3 = amounts.nlargest(3).sum()
        total = amounts.sum()
        return top3 / total if total != 0 else 0
    fea_top3 = df.groupby(['id']).agg(交易金额前三占比=('amount', top3_amt),
                                      收入金额前三占比=('收入金额', top3_amt),
                                      支出金额前三占比=('支出金额', top3_amt)).reset_index()

    # -------------------- 4 时间相关（5个）--------------------
    # 时间相关-5
    fea_time = df.groupby(['id']).agg(最早交易时间=('date', min),
                                      最晚交易时间=('date', 'max'),
                                      交易笔数=('amount', 'count')).reset_index()

    fea_time['流水时间差'] = (fea_time['最晚交易时间'] - fea_time['最早交易时间']).dt.days
    fea_time['交易密度'] = fea_time['交易笔数'] / fea_time['流水时间差']
    current_dt = pd.Timestamp.now()  # 自带datetime64[ns]精度
    fea_time['首笔距今'] = (current_dt - fea_time['最早交易时间']).dt.days
    fea_time['末笔距今'] = (current_dt - fea_time['最晚交易时间']).dt.days
    fea_time['近期活跃度'] = fea_time['末笔距今'] / fea_time['首笔距今']
    fea_time = fea_time[['id', '流水时间差', '交易密度', '近期活跃度', '首笔距今', '末笔距今']]

    # -------------------- 5 大小额占比（4个）--------------------
    # 大小额占比-4
    df = df.merge(fea_amt[['id', '交易金额25分位', '交易金额75分位']])
    fea_de = df[df.amount >= df['交易金额75分位']].groupby(['id']).agg(
        大额交易笔数=('amount', 'count'), 大额交易金额均值=('amount', 'mean')).reset_index()
    fea_xe = df[df.amount <= df['交易金额25分位']].groupby(['id']).agg(
        小额交易笔数=('amount', 'count'), 小额交易金额均值=('amount', 'mean')).reset_index()

    ## --------------------合并--------------------
    fea_flow = fea_cnt.merge(fea_amt, how='left').merge(fea_top3, how='left').merge(
        fea_time, how='left').merge(fea_de, how='left').merge(fea_xe, how='left')
    #大小额笔数占比-2
    fea_flow['大额交易笔数占比'] = fea_flow['大额交易笔数'] / fea_flow['交易笔数']
    fea_flow['小额交易笔数占比'] = fea_flow['小额交易笔数'] / fea_flow['交易笔数']
    return fea_flow

# mix_fea_deal_train = mix_fea_deal_train.replace([np.inf, -np.inf], np.nan)
# mix_fea_deal_test = mix_fea_deal_test.replace([np.inf, -np.inf], np.nan)

def mergedf(df):
    #金额类的互相除法
    df['收入支出差']= df.收入金额 - df.支出金额
    for i in ['loan_lx','loan','balance','balance_limit']:
        df['收入金额%s_ratio'%i] = df['收入金额']/(df['%s'%i]+1)
    for j in  ['career','title','residence']:
        for i in ['收入金额','支出金额','收入支出金额比','收入支出差']:
            tmp1 = df.groupby(j)[i].mean()
            df['%s_deat_mean_%s'%(i,j)] = df[i] - df[j].map(tmp1)
            tmp2 = df.groupby(j)[i].median()
            df['%s_deat_median_%s'%(i,j)] = df[i] - df[j].map(tmp2)
    return df

def feature_importances_pred(feature_filter,lgb_model):
    lgb_feature_importances = pd.concat([pd.Series(feature_filter),pd.Series(lgb_model.feature_importances_)],axis=1)
    lgb_feature_importances.columns = ['feature','importance']
    lgb_feature_importances = lgb_feature_importances.sort_values(by='importance',ascending=False)
    return lgb_feature_importances

# -------------------- 模型训练函数（核心修复CatBoost不支持n_jobs） --------------------
def train_lgb(X_train, y_train, X_val, y_val, random_state):
    model = lgb.LGBMClassifier(
        n_estimators=500,
        boosting_type='gbdt',
        num_leaves=31,
        max_depth=4,
        learning_rate=0.05,
        reg_alpha=0.2,
        reg_lambda=0.2,
        feature_fraction=0.8,
        bagging_fraction=0.8,
        n_jobs=-1,
        importance_type="split",
        verbose=-1,
        random_state=random_state
    )
    callbacks = [lgb.early_stopping(stopping_rounds=100, verbose=False)] #“early_stopping可以自动自动选最优模型”
    model.fit(
        X_train, y_train,
        eval_set=[(X_val, y_val)], #指定 “验证集”，用来监控模型表现
        eval_metric='auc',
        callbacks=callbacks
    )
    return model

def train_xgb(X_train, y_train, X_val, y_val, random_state):
    model = xgb.XGBClassifier(
        n_estimators=500,
        max_depth=4,
        learning_rate=0.05,
        subsample=0.8,
        colsample_bytree=0.8,
        reg_alpha=0.2,
        reg_lambda=0.2,
        objective='binary:logistic',
        eval_metric='auc',
        n_jobs=-1,
        random_state=random_state,
        early_stopping_rounds=100,
        verbosity=0
    )
    model.fit(
        X_train, y_train,
        eval_set=[(X_val, y_val)],
        verbose=0
    )
    return model

def train_cat(X_train, y_train, X_val, y_val, random_state):
    model = cat.CatBoostClassifier(
        n_estimators=500,
        max_depth=4,
        learning_rate=0.05,
        subsample=0.8,
        colsample_bylevel=0.8,
        l2_leaf_reg=3.0,  # CatBoost原生正则参数
        loss_function='Logloss',
        eval_metric='AUC',
        thread_count=-1,  # 替代n_jobs=-1，使用所有CPU核心
        random_state=random_state,
        verbose=False,
        early_stopping_rounds=100
    )
    model.fit(
        X_train, y_train,
        eval_set=[(X_val, y_val)],
        use_best_model=True
    )
    return model

def model_run():
    #---------------------特征重要性---------------------
    feature_filter = [x for x in df_jb_add.columns if x not in ['id','label','term','level','issue_time','record_time'
                    ,'history_time'
                    ,'zip_code','issue_time_ts','record_time_ts','history_time_ts'
                    ,'time_interval1','time_interval2','time_interval3'
                                                                ]
                    and 'interval' not in x
                    ]
    print(df_jb_add.shape,len(feature_filter))
    #训练集
    X_offset = df_jb_add[df_jb_add.label.isin([0,1])][feature_filter]
    y_offset = df_jb_add[df_jb_add.label.isin([0,1])]['label']
    lgb_model = lgb.LGBMClassifier(
        n_estimators = 500,
        boosting_type = 'gbdt',
        num_leaves = 31,
        max_depth = 4,
        learning_rate = 0.1,
        #subsample = 0.8,
        #min_child_samples = 50,
        reg_alpha = 0.1,
        reg_lambda=0.5,
        #min_data_in_leaf = 50,
        feature_fraction = 0.8,
        bagging_fraction = 0.8,
        n_jobs = -1,
        importance_type = "split",
        verbose = -1,
        #is_unbalance= True,
        random_state = 999
        )

    callbacks = [
        lgb.early_stopping(stopping_rounds=100)
    ]

    lgb_model.fit(X_offset, 
                y_offset,
                eval_metric='auc'
                    )

    ##############特征重要性分析输出###########################
    lgb_feature_importances = feature_importances_pred(feature_filter,lgb_model)
    lgb_feature_importances.to_csv('lgb_feature_importances.csv',index=False)

    #--------------------模型训练+测试集预测----------------
    # -------------------- 配置参数（保持不变） --------------------
    SEEDS = [30]
    FEATURE_THRESHOLDS = [0]
    FOLDS = 10
    MODEL_WEIGHTS = {
        'lgb': 0.34,
        'xgb': 0.33,
        'cat': 0.33
    }
    # -------------------- 主训练+融合逻辑（保持不变） --------------------
    #测试集名称为 df_jb_add_test--------------------
    with open('model_fusion_result_log-0.txt', 'w', encoding='utf-8') as fr:
        for seed in SEEDS:
            for feature_cnt in FEATURE_THRESHOLDS:
                filtered_df = lgb_feature_importances[lgb_feature_importances['importance'] > feature_cnt]['feature'].tolist()
                print(f"Seed: {seed} | 特征阈值: {feature_cnt} | 筛选后特征数: {len(filtered_df)}")
                fr.write(f"{seed}-------{feature_cnt}-------{len(filtered_df)}\n")
                
                train_data = df_jb_add[df_jb_add['label'].isin([0, 1])]
                X = train_data[filtered_df].copy()
                y = train_data['label'].copy()
                df_jb_add_test1=df_jb_add_test[filtered_df]
                
                
                oof_lgb = np.zeros(len(X))
                oof_xgb = np.zeros(len(X))
                oof_cat = np.zeros(len(X))
                oof_fusion = np.zeros(len(X))
                

                oof_fusion_test = np.zeros(len(df_jb_add_test1))
                
                mean_score_lgb = 0
                mean_score_xgb = 0
                mean_score_cat = 0
                mean_score_fusion = 0
                mean_score_fusion_train=0
                
                folds = StratifiedKFold(n_splits=FOLDS, shuffle=True, random_state=seed)
                for fold_, (trn_idx, val_idx) in enumerate(folds.split(X.values, y.values)):
                    print(f"\n===== Fold {fold_} =====")
                    fr.write(f"\nFold {fold_}\n")
                    
                    X_train, y_train = X.iloc[trn_idx], y.iloc[trn_idx]
                    X_val, y_val = X.iloc[val_idx], y.iloc[val_idx]
                    
                    print("训练LightGBM...")
                    model_lgb = train_lgb(X_train, y_train, X_val, y_val, random_state=seed+fold_)
                    print("训练XGBoost...")
                    model_xgb = train_xgb(X_train, y_train, X_val, y_val, random_state=seed+fold_)
                    print("训练CatBoost...")
                    model_cat = train_cat(X_train, y_train, X_val, y_val, random_state=seed+fold_)
                    
                    joblib.dump(model_lgb, f'lgb_model_seed{seed}_feat{feature_cnt}_fold{fold_}.pkl')
                    joblib.dump(model_xgb, f'xgb_model_seed{seed}_feat{feature_cnt}_fold{fold_}.pkl')
                    joblib.dump(model_cat, f'cat_model_seed{seed}_feat{feature_cnt}_fold{fold_}.pkl')
                    
                    # 验证集预测
                    oof_lgb[val_idx] = model_lgb.predict_proba(X_val)[:, 1]
                    oof_xgb[val_idx] = model_xgb.predict_proba(X_val)[:, 1]
                    oof_cat[val_idx] = model_cat.predict_proba(X_val)[:, 1]
                    
                    oof_fusion[val_idx] = (
                        oof_lgb[val_idx] * MODEL_WEIGHTS['lgb'] +
                        oof_xgb[val_idx] * MODEL_WEIGHTS['xgb'] +
                        oof_cat[val_idx] * MODEL_WEIGHTS['cat']
                    )
                    # 测试集直接预测
                    oof_lgb_test = model_lgb.predict_proba(df_jb_add_test1)[:, 1]
                    oof_xgb_test = model_xgb.predict_proba(df_jb_add_test1)[:, 1]
                    oof_cat_test = model_cat.predict_proba(df_jb_add_test1)[:, 1]
                    
                    oof_fusion_test += (
                        oof_lgb_test * MODEL_WEIGHTS['lgb'] +
                        oof_xgb_test * MODEL_WEIGHTS['xgb'] +
                        oof_cat_test * MODEL_WEIGHTS['cat']
                    )/FOLDS
                    
                    score_lgb = roc_auc_score(y_val, oof_lgb[val_idx])
                    score_xgb = roc_auc_score(y_val, oof_xgb[val_idx])
                    score_cat = roc_auc_score(y_val, oof_cat[val_idx])
                    score_fusion = roc_auc_score(y_val, oof_fusion[val_idx])
                    
                    score_lgb_train = roc_auc_score(y_train, model_lgb.predict_proba(X_train)[:, 1])
                    score_xgb_train = roc_auc_score(y_train, model_xgb.predict_proba(X_train)[:, 1])
                    score_cat_train = roc_auc_score(y_train, model_cat.predict_proba(X_train)[:, 1])
                    score_fusion_train = roc_auc_score(y_train,
                                    model_lgb.predict_proba(X_train)[:, 1] * MODEL_WEIGHTS['lgb'] +
                                    model_xgb.predict_proba(X_train)[:, 1] * MODEL_WEIGHTS['xgb'] +
                                    model_cat.predict_proba(X_train)[:, 1]* MODEL_WEIGHTS['cat'])

                    fold_log = (
                        f"Fold {fold_} 结果：\n"
                        f"  LGB - 训练AUC: {score_lgb_train:.4f} | 验证AUC: {score_lgb:.4f} | 过拟合: {score_lgb_train-score_lgb:.4f}\n"
                        f"  XGB - 训练AUC: {score_xgb_train:.4f} | 验证AUC: {score_xgb:.4f} | 过拟合: {score_xgb_train-score_xgb:.4f}\n"
                        f"  Cat - 训练AUC: {score_cat_train:.4f} | 验证AUC: {score_cat:.4f} | 过拟合: {score_cat_train-score_cat:.4f}\n"
                        f"  融合 - 训练AUC: {score_fusion_train:.4f} | 验证AUC: {score_fusion:.4f} | 过拟合: {score_fusion_train-score_fusion:.4f}\n"
                    )
                    print(fold_log)
                    fr.write(fold_log)
                    
                    mean_score_lgb += score_lgb / FOLDS
                    mean_score_xgb += score_xgb / FOLDS
                    mean_score_cat += score_cat / FOLDS
                    mean_score_fusion += score_fusion / FOLDS
                    mean_score_fusion_train += score_fusion_train / FOLDS
                    
                final_log = (
                    f"\n===== Seed {seed} | 特征阈值 {feature_cnt} 最终结果 =====\n"
                    f"LGB 平均验证AUC: {mean_score_lgb:.4f}\n"
                    f"XGB 平均验证AUC: {mean_score_xgb:.4f}\n"
                    f"Cat 平均验证AUC: {mean_score_cat:.4f}\n"
                    f"融合模型平均训练AUC: {mean_score_fusion_train:.4f}\n"
                    f"融合模型平均验证AUC: {mean_score_fusion:.4f}\n"
                    f"融合模型平均过拟合: {mean_score_fusion_train-mean_score_fusion:.4f}\n"
                    f"融合vs最优单模型提升: {mean_score_fusion - max(mean_score_lgb, mean_score_xgb, mean_score_cat):.4f}\n"
                    f"===================================================\n"
                )
                print(final_log)
                fr.write(final_log)
                submission_test=pd.concat([mix_fea_deal_test['id'],pd.Series(oof_fusion_test)],axis=1)
                submission_test.columns=['id','label']
                submission_test.to_csv('submission_test.csv')

