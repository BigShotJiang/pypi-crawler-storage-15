# 项目名称：graph_cptools
一个简单的Python工具包，用于模型预测功能。

## 安装方法
pip install graph_cptools

## 使用示例
from graph_cptools import module_pred


## 许可证
MIT License

## 打包发布代码
rm -rf dist build *.egg-info
python -m build
twine upload dist/*



pip install graph_cptools

from graph_cptools import model_pred
import inspect
print(inspect.getsource(model_pred))

pypi-AgEIcHlwaS5vcmcCJDQzNTI1MTNhLWMxNjUtNGUwMS1iYmYwLTM3MTUyOThkZjhiNwACKlszLCI0YWJlMDQ0ZC05ZTM1LTQzZDctYmZjZC0wNWRiYTE5NzM5YjAiXQAABiC6WobBhnAspwf-8ylqPP7WTLTCK-rQj8hddznxzNMGYA