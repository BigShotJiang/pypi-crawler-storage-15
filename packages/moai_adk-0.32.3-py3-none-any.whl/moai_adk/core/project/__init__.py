"""Project module: initialization and management"""
