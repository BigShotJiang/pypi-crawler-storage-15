#!/bin/bash
# Build script for IntelliJ plugin
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🔨 Building pytest-language-server IntelliJ plugin"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Step 1: Download binaries (if not already present)
echo "Step 1: Ensuring binaries are available..."
echo ""
"$SCRIPT_DIR/download-binaries.sh"

# Step 2: Build the plugin
echo ""
echo "Step 2: Building plugin with Gradle..."
echo ""
cd "$SCRIPT_DIR"
./gradlew buildPlugin

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "✅ Plugin built successfully!"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "Plugin location:"
ls -lh build/distributions/*.zip
echo ""
