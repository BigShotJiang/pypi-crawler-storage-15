"""MCP 服务器入口，支持从客户端 Roots 协议获取应用列表。"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import platform
import subprocess
from dataclasses import dataclass, field
from typing import Any
from urllib.parse import unquote, urlparse

from mcp import types
from mcp.server import NotificationOptions, Server
from mcp.server.stdio import stdio_server
from pydantic import BaseModel


logger = logging.getLogger("app_launcher_mcp")


class RawRootsResult(BaseModel):
    """原始 roots 结果，不验证 URI 格式。"""
    roots: list[dict[str, Any]] = []

    class Config:
        extra = "allow"  # 允许额外字段

# 全局应用列表和服务器实例引用
APPS: list[AppInfo] = []
SERVER_SESSION = None


def setup_logging() -> str:
    """为 app_launcher_mcp 日志树配置处理器。"""

    log_dir = os.path.expanduser("~")
    log_file = os.path.join(log_dir, "mcp_app_launcher.log")

    if getattr(logger, "_configured", False):
        return log_file

    logger.handlers.clear()
    logger.setLevel(logging.DEBUG)
    logger.propagate = False

    file_handler = logging.FileHandler(log_file, mode="a", encoding="utf-8")
    file_handler.setLevel(logging.DEBUG)
    file_formatter = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    file_handler.setFormatter(file_formatter)
    logger.addHandler(file_handler)

    setattr(logger, "_configured", True)
    return log_file


def get_platform() -> str:
    """获取当前平台。"""
    sys_platform = platform.system().lower()
    if sys_platform == "darwin":
        return "darwin"
    elif sys_platform == "windows":
        return "win32"
    elif sys_platform == "linux":
        return "linux"
    return sys_platform


def open_or_activate_app_windows(app_path: str) -> dict[str, Any]:
    """
    Windows 平台：打开应用或将已运行的应用窗口带到前台。

    Args:
        app_path: 应用的完整路径

    Returns:
        包含执行结果的字典
    """
    # 获取不带扩展名的进程名
    exe_name = os.path.basename(app_path)
    process_name = exe_name.replace('.exe', '').replace('.EXE', '')

    # PowerShell 脚本
    ps_script = f'''
$processName = "{process_name}"
$appPath = "{app_path}"

# 查找进程
$proc = Get-Process -Name $processName -ErrorAction SilentlyContinue | Select-Object -First 1

if ($proc) {{
    Write-Output "FOUND_PROCESS"
    $hwnd = $proc.MainWindowHandle

    if ($hwnd -ne 0) {{
        # 加载 Windows API
        Add-Type @"
using System;
using System.Runtime.InteropServices;
public class WinAPI {{
    [DllImport("user32.dll")]
    public static extern bool SetForegroundWindow(IntPtr hWnd);

    [DllImport("user32.dll")]
    public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

    [DllImport("user32.dll")]
    public static extern bool IsIconic(IntPtr hWnd);

    [DllImport("user32.dll")]
    public static extern bool BringWindowToTop(IntPtr hWnd);

    [DllImport("user32.dll")]
    public static extern IntPtr GetForegroundWindow();

    [DllImport("user32.dll")]
    public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);

    [DllImport("user32.dll")]
    public static extern bool AttachThreadInput(uint idAttach, uint idAttachTo, bool fAttach);

    [DllImport("kernel32.dll")]
    public static extern uint GetCurrentThreadId();
}}
"@

        # 获取当前前台窗口的线程ID
        $foregroundHwnd = [WinAPI]::GetForegroundWindow()
        $foregroundPid = 0
        $foregroundThread = [WinAPI]::GetWindowThreadProcessId($foregroundHwnd, [ref]$foregroundPid)
        $currentThread = [WinAPI]::GetCurrentThreadId()

        # 附加到前台窗口的线程（这样可以绕过 Windows 的前台窗口限制）
        [WinAPI]::AttachThreadInput($currentThread, $foregroundThread, $true) | Out-Null

        # 如果窗口最小化，先恢复
        if ([WinAPI]::IsIconic($hwnd)) {{
            [WinAPI]::ShowWindow($hwnd, 9) | Out-Null  # SW_RESTORE = 9
            Write-Output "RESTORED_WINDOW"
        }}

        # 将窗口带到前台
        [WinAPI]::BringWindowToTop($hwnd) | Out-Null
        [WinAPI]::SetForegroundWindow($hwnd) | Out-Null

        # 分离线程
        [WinAPI]::AttachThreadInput($currentThread, $foregroundThread, $false) | Out-Null

        Write-Output "ACTIVATED_WINDOW"
    }} else {{
        # 进程存在但没有主窗口，可能是托盘图标
        Write-Output "NO_MAIN_WINDOW"
        # 尝试启动新窗口
        Start-Process $appPath
        Write-Output "STARTED_NEW"
    }}
}} else {{
    Write-Output "NOT_RUNNING"
    # 启动应用
    Start-Process $appPath
    Write-Output "STARTED_APP"
}}
'''

    try:
        # 执行 PowerShell 脚本
        result = subprocess.run(
            ["powershell", "-ExecutionPolicy", "Bypass", "-Command", ps_script],
            capture_output=True,
            text=True,
            creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
        )

        output = result.stdout.strip()

        return {
            "success": True,
            "output": output,
            "was_running": "FOUND_PROCESS" in output,
            "was_minimized": "RESTORED_WINDOW" in output,
            "activated": "ACTIVATED_WINDOW" in output,
            "started_new": "STARTED_APP" in output or "STARTED_NEW" in output,
        }

    except Exception as e:
        logger.error("Windows 打开/激活应用失败: %s", e)
        return {
            "success": False,
            "error": str(e),
        }


@dataclass
class AppInfo:
    """应用信息。"""
    name: str
    path: str
    keywords: list[str] = field(default_factory=list)


def is_valid_file_uri(uri: str) -> bool:
    """检查是否是有效的 file:// URI。"""
    if not uri.startswith("file://"):
        return False
    # 检查是否有嵌套的协议 (如 file://steam://)
    after_scheme = uri[7:]  # 去掉 "file://"
    if "://" in after_scheme:
        return False
    return True


def extract_path_from_file_uri(uri: str) -> str:
    """
    从 file:// URI 提取文件路径，兼容多种格式：
    - 标准格式: file:///C:/path/to/file (macOS/Linux: file:///path/to/file)
    - Windows 非标准格式: file://C:\\path\\to\\file 或 file://C:/path/to/file
    """
    if not uri.startswith("file://"):
        return ""

    # 去掉 "file://" 前缀
    path_part = uri[7:]

    # URL 解码
    path_part = unquote(path_part)

    # 检测 Windows 路径格式
    # 情况1: /C:/path 或 /C:\path (标准格式，第一个字符是 /)
    # 情况2: C:/path 或 C:\path (非标准格式，直接是盘符)
    if len(path_part) >= 2:
        # 标准格式: /C:/... -> 去掉开头的 /
        if path_part[0] == '/' and len(path_part) >= 3 and path_part[2] == ':':
            path_part = path_part[1:]
        # 非标准格式: C:\... 或 C:/... -> 已经是正确格式

    # 统一使用系统的路径分隔符
    if get_platform() == "win32":
        # Windows: 将正斜杠转换为反斜杠
        path_part = path_part.replace('/', '\\')
    else:
        # macOS/Linux: 将反斜杠转换为正斜杠
        path_part = path_part.replace('\\', '/')

    return path_part


def load_apps_from_raw_roots(raw_roots: list[dict[str, Any]]) -> None:
    """从原始 roots 数据加载应用列表，跳过无效的 URI。"""
    global APPS
    logger.info("[MCP] 开始加载应用列表, roots 数量: %d", len(raw_roots))
    APPS = []
    skipped = 0

    for root in raw_roots:
        try:
            uri = str(root.get("uri", ""))

            # 调试：打印原始 URI
            logger.debug("[DEBUG] 原始 root: name=%s, uri=%s", root.get("name"), uri)

            # 检查是否是有效的 file:// URI
            if not is_valid_file_uri(uri):
                if uri:  # 只记录非空的无效 URI
                    logger.warning("跳过无效的 URI: %s", uri)
                    skipped += 1
                continue

            # 提取路径 - 处理各种 file:// URI 格式
            app_path = extract_path_from_file_uri(uri)

            # 调试：打印解析后的路径
            logger.debug("[DEBUG] 提取的路径: %s", app_path)

            if not app_path:
                logger.warning("无法从 URI 提取路径: %s", uri)
                skipped += 1
                continue

            # 获取应用名称
            app_name = root.get("name") or os.path.basename(app_path) or app_path

            # 获取关键词 - 从 _meta 中提取
            meta = root.get("_meta") or {}
            if isinstance(meta, dict):
                raw_keywords = meta.get("keywords", [])
            else:
                raw_keywords = []

            keywords: list[str] = []
            if isinstance(raw_keywords, list):
                keywords = [str(kw) for kw in raw_keywords]

            APPS.append(AppInfo(name=app_name, path=app_path, keywords=keywords))
        except Exception as e:
            logger.warning("处理 root 时出错，跳过: %s, 错误: %s", root, e)
            skipped += 1

    logger.info("[MCP] 从 roots 加载了 %d 个应用，跳过了 %d 个无效项", len(APPS), skipped)
    for app in APPS:
        logger.debug("  - %s: %s (keywords: %s)", app.name, app.path, app.keywords)


def score_app(app: AppInfo, query: str) -> int:
    """
    使用打分策略匹配应用。

    优先级：
    - 名称精确(100) > 名称前缀(90) > 关键词精确(80) > 关键词前缀(70) > 名称包含(60) > 关键词包含(50)
    """
    score = 0
    name = app.name.lower() if app.name else ""

    if name == query:
        return 100
    if name.startswith(query):
        score = max(score, 90)
    if query in name:
        score = max(score, 60)

    for kw in app.keywords:
        k = kw.lower()
        if k == query:
            score = max(score, 80)
        elif k.startswith(query):
            score = max(score, 70)
        elif query in k:
            score = max(score, 50)

    return score


def find_app(app_name: str) -> AppInfo | None:
    """根据名称查找应用。"""
    query = app_name.lower()

    scored = [
        (app, score_app(app, query), idx)
        for idx, app in enumerate(APPS)
    ]
    scored = [(app, s, idx) for app, s, idx in scored if s > 0]
    scored.sort(key=lambda x: (-x[1], x[2]))

    return scored[0][0] if scored else None


# 创建 MCP 服务器
mcp = Server("app-open-server")


@mcp.list_tools()
async def list_tools() -> list[types.Tool]:
    """列出可用工具。"""
    return [
        types.Tool(
            name="open_app",
            description="可根据应用名称搜索并打开用户安装的应用程序；",
            inputSchema={
                "type": "object",
                "properties": {
                    "appName": {
                        "type": "string",
                        "description": "要打开的应用程序名称",
                    },
                },
                "required": ["appName"],
            },
        ),
    ]


@mcp.call_tool()
async def call_tool(
    name: str, arguments: dict[str, Any] | None
) -> types.CallToolResult:
    """处理工具调用。"""
    if name != "open_app":
        return types.CallToolResult(
            content=[types.TextContent(type="text", text=f"未知工具: {name}")],
            isError=True,
        )

    payload = arguments or {}
    app_name = str(payload.get("appName") or "").strip()

    if not app_name:
        return types.CallToolResult(
            content=[types.TextContent(type="text", text="必须提供应用名称")],
            isError=True,
        )

    app = find_app(app_name)
    if not app:
        available = ", ".join(a.name for a in APPS)
        return types.CallToolResult(
            content=[
                types.TextContent(
                    type="text",
                    text=f"未找到应用: {app_name}，可用应用: {available}",
                )
            ],
            structuredContent={
                "query": app_name,
                "availableApps": [a.name for a in APPS],
            },
            isError=True,
        )

    # 根据平台执行打开命令
    plat = get_platform()
    app_path = app.path

    try:
        if plat == "win32":
            # Windows: 使用增强的打开/激活功能
            win_result = open_or_activate_app_windows(app_path)
            if not win_result.get("success"):
                raise Exception(win_result.get("error", "未知错误"))
            command = "PowerShell (open_or_activate)"

            # 构建更详细的消息
            if win_result.get("was_running"):
                if win_result.get("activated"):
                    action_msg = "已将应用窗口带到前台"
                else:
                    action_msg = "应用已在运行"
            else:
                action_msg = "已启动应用"
        elif plat == "darwin":
            command = f'open "{app_path}"'
            subprocess.Popen(command, shell=True)
            action_msg = "已启动应用"
        else:
            # Linux
            command = app_path
            subprocess.Popen([app_path])
            action_msg = "已启动应用"

        data = {
            "message": f"{action_msg}: {app.name}",
            "name": app.name,
            "path": app_path,
            "command": command,
            "platform": plat,
        }

        # Windows 平台添加额外信息
        if plat == "win32":
            data["was_running"] = win_result.get("was_running", False)
            data["was_minimized"] = win_result.get("was_minimized", False)
            data["activated"] = win_result.get("activated", False)
        return types.CallToolResult(
            content=[
                types.TextContent(
                    type="text",
                    text=json.dumps(data, ensure_ascii=False, indent=2),
                )
            ],
            structuredContent=data,
            isError=False,
        )
    except Exception as e:
        message = f"打开应用时发生错误: {e}"
        return types.CallToolResult(
            content=[types.TextContent(type="text", text=message)],
            isError=True,
        )


async def safe_list_roots(session: Any) -> list[dict[str, Any]]:
    """安全地获取 roots 列表，返回原始字典数据。"""
    try:
        # 使用自定义的 RawRootsResult 类，它不验证 URI 格式
        response = await session.send_request(
            types.ServerRequest(types.ListRootsRequest()),
            RawRootsResult,  # 使用自定义类，roots 是 list[dict]
        )
        if response and response.roots:
            return response.roots
        return []
    except Exception as e:
        logger.error("获取 roots 失败: %s", e)
        return []


# 注册 roots 变化通知处理器
async def handle_roots_changed(notification: types.RootsListChangedNotification) -> None:
    """处理 roots 变化通知。"""
    global SERVER_SESSION
    logger.info("[MCP] 收到 roots 变化通知")
    try:
        if SERVER_SESSION:
            raw_roots = await safe_list_roots(SERVER_SESSION)
            load_apps_from_raw_roots(raw_roots)
    except Exception as e:
        logger.error("获取更新的 roots 失败: %s", e)


mcp.notification_handlers[types.RootsListChangedNotification] = handle_roots_changed


async def run_server() -> None:
    """运行服务器。"""
    global SERVER_SESSION

    log_file = setup_logging()
    logger.info("=" * 60)
    logger.info("MCP 应用启动器服务器启动")
    logger.info("日志文件: %s", log_file)
    logger.info("=" * 60)

    async with stdio_server() as (read_stream, write_stream):
        init_options = mcp.create_initialization_options(
            notification_options=NotificationOptions(),
            experimental_capabilities={},
        )

        # Monkey-patch ServerSession 来在初始化完成后获取 roots
        from mcp.server.session import ServerSession
        original_received_notification = ServerSession._received_notification

        async def patched_received_notification(self, notification: types.ClientNotification) -> None:
            global SERVER_SESSION
            await original_received_notification(self, notification)

            if isinstance(notification.root, types.InitializedNotification):
                logger.info("[MCP] 收到初始化完成通知，准备获取 roots")
                SERVER_SESSION = self

                # 在后台任务中获取 roots，避免阻塞事件循环
                async def fetch_roots_background():
                    try:
                        client_params = self._client_params
                        if client_params and client_params.capabilities and client_params.capabilities.roots:
                            logger.info("[MCP] 客户端支持 roots 协议，开始获取 roots")
                            # 使用安全的方式获取 roots，添加超时控制
                            raw_roots = await asyncio.wait_for(
                                safe_list_roots(self), timeout=10.0
                            )
                            load_apps_from_raw_roots(raw_roots)
                        else:
                            logger.warning("客户端不支持 MCP roots 协议，应用列表为空")
                    except asyncio.TimeoutError:
                        logger.warning("获取 roots 超时，应用列表为空")
                    except Exception as e:
                        logger.error("获取初始 roots 失败: %s", e)

                # 创建后台任务，不阻塞通知处理
                asyncio.create_task(fetch_roots_background())

        ServerSession._received_notification = patched_received_notification

        try:
            await mcp.run(
                read_stream,
                write_stream,
                init_options,
            )
        finally:
            # 恢复原始方法
            ServerSession._received_notification = original_received_notification


def main() -> None:
    """主入口。"""
    print("启动 MCP 应用启动器 (Roots 协议)")
    print("可用工具: open_app")

    asyncio.run(run_server())


if __name__ == "__main__":
    main()