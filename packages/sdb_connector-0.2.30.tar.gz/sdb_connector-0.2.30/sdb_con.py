

def my_testing_fn(x=10):
    """just a test"""
    return x + 2

def sdb_con():
    return "Function sdb_con executed"