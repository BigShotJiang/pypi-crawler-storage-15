# sdb_connector
A python libary written in Rust for Surrealdb connection and data preparation

https://pypi.org/project/sdb-connector/

## How to use this libary

```bash
pip install sdb_connector
```

## commands for setup libary

- change revision

```bash
maturin develop
```

```bash
maturin publish --username __token__ --password <Token>
```

