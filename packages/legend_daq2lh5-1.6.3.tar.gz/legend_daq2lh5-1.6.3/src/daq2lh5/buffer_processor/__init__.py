"""
This subpackage allows for preprocessing of data in daq and raw level files
"""
