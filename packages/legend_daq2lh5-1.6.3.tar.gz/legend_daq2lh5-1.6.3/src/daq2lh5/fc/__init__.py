"""
This subpackage overloads decoding utilities defined in :mod:`pygama.raw` to
read files produced by the FlashCam acquisition system.
"""
