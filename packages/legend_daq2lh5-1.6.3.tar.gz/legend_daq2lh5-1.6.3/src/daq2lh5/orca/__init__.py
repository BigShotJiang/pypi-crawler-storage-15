"""
This subpackage overloads decoding utilities defined in :mod:`pygama.raw` to
read files produced by the `ORCA <http://orca.physics.unc.edu/orca>`_
acquisition system.
"""
