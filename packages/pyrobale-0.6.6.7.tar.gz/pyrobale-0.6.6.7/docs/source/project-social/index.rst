🎯 Project Channels & Groups in Bale
===========

Pyrobale socials

.. toctree::
   :maxdepth: 2
   :caption: Socials

Channels
-----
`Announcements channel <https://ble.ir/pyrobale>`_
####
Latest news about our library, new commits and bale api changes.

`Bots channel <https://ble.ir/@pyrobale_bots>`_
####
New bots written with pyrobale. (`Submit yours <https://ble.ir/daradege>`_)

Groups
-----
`Chat group <https://ble.ir/join/2s5xa5hGE7>`_
####
our chat group