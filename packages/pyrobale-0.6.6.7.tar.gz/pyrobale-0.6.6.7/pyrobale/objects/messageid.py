class MessageId:
    def __init__(self, message_id: int):
        self.message_id = message_id
