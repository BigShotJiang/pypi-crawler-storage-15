"""
OdooUpgrader - Professional Odoo database upgrade tool
"""

__version__ = "0.2.0"
__author__ = "Fasil"
__email__ = "fasilwdr@hotmail.com"

from .core import OdooUpgrader

__all__ = ["OdooUpgrader"]