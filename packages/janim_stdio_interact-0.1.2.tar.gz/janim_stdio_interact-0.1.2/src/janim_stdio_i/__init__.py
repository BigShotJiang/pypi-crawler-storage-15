"""
A utility library for interacting with JAnim GUI via standard input/output
"""

__version__ = '0.1.2'
