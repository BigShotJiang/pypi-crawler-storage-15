"""Setup script for crawilfy-mcp-server."""

from setuptools import setup

# This file is kept for compatibility, but pyproject.toml is the source of truth
setup()

