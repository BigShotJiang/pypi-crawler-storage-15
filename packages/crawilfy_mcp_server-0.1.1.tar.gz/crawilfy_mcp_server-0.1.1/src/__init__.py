"""Crawilfy - Advanced Web Crawling Platform."""

__version__ = "0.1.1"


