"""
Tests for Sunstone DatasetsManager functionality.
"""

import socket
import unittest.mock
from pathlib import Path
from unittest.mock import patch
from typing import Any


import pytest
import sunstone
from sunstone.datasets import _is_public_url


def mock_getaddrinfo(ip: str) -> list[tuple[Any, ...]]:
    """Create a mock getaddrinfo return value for a given IP address."""
    if ":" in ip:  # IPv6
        return [(socket.AF_INET6, socket.SOCK_STREAM, 0, "", (ip, 0, 0, 0))]
    else:  # IPv4
        return [(socket.AF_INET, socket.SOCK_STREAM, 0, "", (ip, 0))]


class TestDatasetsManager:
    """Tests for DatasetsManager class."""

    def test_load_datasets_manager(self, project_path: Path) -> None:
        """Test loading datasets manager from project path."""
        manager = sunstone.DatasetsManager(project_path)
        assert manager is not None

    def test_find_dataset_by_slug(self, project_path: Path) -> None:
        """Test finding a dataset by its slug."""
        manager = sunstone.DatasetsManager(project_path)
        dataset = manager.find_dataset_by_slug("official-un-member-states")

        assert dataset is not None
        assert dataset.name == "Official UN Member States"
        assert dataset.slug == "official-un-member-states"
        assert dataset.location is not None
        assert len(dataset.fields) > 0
        if dataset.source:
            assert dataset.source.license is not None

    def test_find_nonexistent_dataset(self, project_path: Path) -> None:
        """Test that finding a non-existent dataset returns None."""
        manager = sunstone.DatasetsManager(project_path)
        dataset = manager.find_dataset_by_slug("does-not-exist")
        assert dataset is None


class TestURLSafety:
    """Tests for URL safety validation (SSRF prevention)."""

    def test_valid_https_url(self) -> None:
        """Test that valid HTTPS URLs to public addresses are allowed."""
        with patch("sunstone.datasets.socket.getaddrinfo", return_value=mock_getaddrinfo("93.184.216.34")):
            assert _is_public_url("https://example.com/data.csv") is True
            assert _is_public_url("https://www.google.com/file.json") is True

    def test_valid_http_url(self) -> None:
        """Test that valid HTTP URLs to public addresses are allowed."""
        with patch("sunstone.datasets.socket.getaddrinfo", return_value=mock_getaddrinfo("93.184.216.34")):
            assert _is_public_url("http://example.com/data.csv") is True

    def test_file_scheme_blocked(self) -> None:
        """Test that file:// URLs are blocked."""
        assert _is_public_url("file:///etc/passwd") is False
        assert _is_public_url("file:///tmp/data.csv") is False

    def test_ftp_scheme_blocked(self) -> None:
        """Test that FTP URLs are blocked."""
        assert _is_public_url("ftp://example.com/data.csv") is False

    def test_localhost_blocked(self) -> None:
        """Test that localhost URLs are blocked."""
        with patch("sunstone.datasets.socket.getaddrinfo", return_value=mock_getaddrinfo("127.0.0.1")):
            assert _is_public_url("http://localhost/api") is False
            assert _is_public_url("http://localhost:8080/data") is False

    def test_loopback_ip_blocked(self) -> None:
        """Test that loopback IP addresses are blocked."""
        with patch("sunstone.datasets.socket.getaddrinfo", return_value=mock_getaddrinfo("127.0.0.1")):
            assert _is_public_url("http://127.0.0.1/api") is False
        with patch("sunstone.datasets.socket.getaddrinfo", return_value=mock_getaddrinfo("127.0.0.2")):
            assert _is_public_url("http://127.0.0.2:8080/data") is False

    def test_private_ip_10_blocked(self) -> None:
        """Test that private IP addresses (10.x.x.x) are blocked."""
        with patch("sunstone.datasets.socket.getaddrinfo", return_value=mock_getaddrinfo("10.0.0.1")):
            assert _is_public_url("http://internal.example.com/api") is False
        with patch("sunstone.datasets.socket.getaddrinfo", return_value=mock_getaddrinfo("10.255.255.254")):
            assert _is_public_url("http://10.255.255.254/data") is False

    def test_private_ip_192_168_blocked(self) -> None:
        """Test that private IP addresses (192.168.x.x) are blocked."""
        with patch("sunstone.datasets.socket.getaddrinfo", return_value=mock_getaddrinfo("192.168.1.1")):
            assert _is_public_url("http://router.local/config") is False
        with patch("sunstone.datasets.socket.getaddrinfo", return_value=mock_getaddrinfo("192.168.100.50")):
            assert _is_public_url("http://192.168.100.50/api") is False

    def test_private_ip_172_16_blocked(self) -> None:
        """Test that private IP addresses (172.16-31.x.x) are blocked."""
        with patch("sunstone.datasets.socket.getaddrinfo", return_value=mock_getaddrinfo("172.16.0.1")):
            assert _is_public_url("http://internal-app.local/data") is False
        with patch("sunstone.datasets.socket.getaddrinfo", return_value=mock_getaddrinfo("172.31.255.255")):
            assert _is_public_url("http://172.31.255.255/api") is False

    def test_link_local_blocked(self) -> None:
        """Test that link-local addresses (169.254.x.x) are blocked."""
        with patch("sunstone.datasets.socket.getaddrinfo", return_value=mock_getaddrinfo("169.254.169.254")):
            assert _is_public_url("http://169.254.169.254/metadata") is False

    def test_cloud_metadata_endpoint_blocked(self) -> None:
        """Test that AWS/GCP cloud metadata endpoints are blocked."""
        with patch("sunstone.datasets.socket.getaddrinfo", return_value=mock_getaddrinfo("169.254.169.254")):
            assert _is_public_url("http://169.254.169.254/latest/meta-data/") is False

    def test_ipv6_loopback_blocked(self) -> None:
        """Test that IPv6 loopback address (::1) is blocked."""
        with patch("sunstone.datasets.socket.getaddrinfo", return_value=mock_getaddrinfo("::1")):
            assert _is_public_url("http://localhost/api") is False
            assert _is_public_url("http://[::1]/api") is False
            assert _is_public_url("http://[::1]:8080/data") is False

    def test_ipv6_link_local_blocked(self) -> None:
        """Test that IPv6 link-local addresses (fe80::) are blocked."""
        with patch("sunstone.datasets.socket.getaddrinfo", return_value=mock_getaddrinfo("fe80::1")):
            assert _is_public_url("http://ipv6-link-local.example.com/data") is False
        with patch("sunstone.datasets.socket.getaddrinfo", return_value=mock_getaddrinfo("fe80::1234:5678:abcd:ef01")):
            assert _is_public_url("http://[fe80::1234:5678:abcd:ef01]/api") is False

    def test_ipv6_unique_local_blocked(self) -> None:
        """Test that IPv6 unique local addresses (fc00::/7, including fd00::) are blocked."""
        # fc00:: prefix (unique local, not yet assigned)
        with patch("sunstone.datasets.socket.getaddrinfo", return_value=mock_getaddrinfo("fc00::1")):
            assert _is_public_url("http://internal-ipv6.example.com/data") is False
        # fd00:: prefix (unique local, commonly used for private networks)
        with patch("sunstone.datasets.socket.getaddrinfo", return_value=mock_getaddrinfo("fd00::1")):
            assert _is_public_url("http://private-ipv6.example.com/api") is False
        with patch("sunstone.datasets.socket.getaddrinfo", return_value=mock_getaddrinfo("fd12:3456:789a::1")):
            assert _is_public_url("http://[fd12:3456:789a::1]:8080/data") is False

    def test_dns_resolution_failure(self) -> None:
        """Test that URLs with unresolvable hostnames are blocked."""
        with patch(
            "sunstone.datasets.socket.getaddrinfo",
            side_effect=socket.gaierror("DNS lookup failed"),
        ):
            assert _is_public_url("http://nonexistent-domain-xyz123.com/data") is False

    def test_decimal_ip_representation_blocked(self) -> None:
        """Test that decimal IP representations (e.g., 2130706433 = 127.0.0.1) are blocked.

        An attacker might try to bypass SSRF protection using decimal IP notation.
        socket.getaddrinfo() correctly resolves these to the actual IP address.
        """
        # 2130706433 is the decimal representation of 127.0.0.1
        # getaddrinfo resolves this to the actual IP, which should be blocked
        with patch("sunstone.datasets.socket.getaddrinfo", return_value=mock_getaddrinfo("127.0.0.1")):
            assert _is_public_url("http://2130706433/api") is False

        # 3232235777 is the decimal representation of 192.168.1.1
        with patch("sunstone.datasets.socket.getaddrinfo", return_value=mock_getaddrinfo("192.168.1.1")):
            assert _is_public_url("http://3232235777/data") is False

        # 2851995649 is the decimal representation of 169.254.169.254 (cloud metadata)
        with patch("sunstone.datasets.socket.getaddrinfo", return_value=mock_getaddrinfo("169.254.169.254")):
            assert _is_public_url("http://2851995649/latest/meta-data/") is False

    def test_hex_ip_representation_blocked(self) -> None:
        """Test that hexadecimal IP representations (e.g., 0x7f000001 = 127.0.0.1) are blocked.

        An attacker might try to bypass SSRF protection using hex IP notation.
        socket.getaddrinfo() correctly resolves these to the actual IP address.
        """
        # 0x7f000001 is the hex representation of 127.0.0.1
        with patch("sunstone.datasets.socket.getaddrinfo", return_value=mock_getaddrinfo("127.0.0.1")):
            assert _is_public_url("http://0x7f000001/api") is False

        # 0xc0a80101 is the hex representation of 192.168.1.1
        with patch("sunstone.datasets.socket.getaddrinfo", return_value=mock_getaddrinfo("192.168.1.1")):
            assert _is_public_url("http://0xc0a80101/data") is False

        # 0xa9fea9fe is the hex representation of 169.254.169.254
        with patch("sunstone.datasets.socket.getaddrinfo", return_value=mock_getaddrinfo("169.254.169.254")):
            assert _is_public_url("http://0xa9fea9fe/metadata") is False

    def test_mixed_notation_ip_blocked(self) -> None:
        """Test that mixed notation IPs are blocked.

        Some systems accept mixed decimal/hex/octal notation like 127.0.0.1
        represented as 0x7f.0.0.1 or similar variations.
        """
        # Various representations that resolve to loopback
        with patch("sunstone.datasets.socket.getaddrinfo", return_value=mock_getaddrinfo("127.0.0.1")):
            assert _is_public_url("http://0x7f.0.0.1/api") is False
            assert _is_public_url("http://127.0x0.0.1/data") is False

    def test_url_without_hostname(self) -> None:
        """Test that URLs without hostnames are blocked."""
        assert _is_public_url("http:///no-host") is False

    def test_fetch_from_url_with_ssrf_attempt(self, project_path: Path) -> None:
        """Test that fetch_from_url raises ValueError for SSRF attempts."""
        manager = sunstone.DatasetsManager(project_path)
        dataset = manager.find_dataset_by_slug("official-un-member-states")

        if dataset and dataset.source:
            # Mock the source URL to point to a private IP
            dataset.source.location.data = "http://169.254.169.254/metadata"

            # Mock DNS resolution to return the link-local IP
            with patch("sunstone.datasets.socket.getaddrinfo", return_value=mock_getaddrinfo("169.254.169.254")):
                with pytest.raises(ValueError, match="not allowed"):
                    manager.fetch_from_url(dataset, force=True)

    def test_fetch_from_url_with_file_scheme(self, project_path: Path) -> None:
        """Test that fetch_from_url raises ValueError for file:// URLs."""
        manager = sunstone.DatasetsManager(project_path)
        dataset = manager.find_dataset_by_slug("official-un-member-states")

        if dataset and dataset.source:
            # Mock the source URL to use file:// scheme
            dataset.source.location.data = "file:///etc/passwd"

            with pytest.raises(ValueError, match="not allowed"):
                manager.fetch_from_url(dataset, force=True)


class TestRedirectSSRFProtection:
    """Tests for HTTP redirect SSRF protection."""

    def test_redirect_to_private_ip_blocked(self, project_path: Path) -> None:
        """Test that redirects to private IPs are blocked (SSRF bypass prevention)."""
        manager = sunstone.DatasetsManager(project_path)
        dataset = manager.find_dataset_by_slug("official-un-member-states")

        if dataset and dataset.source:
            # Start with a valid public URL
            dataset.source.location.data = "https://example.com/data.csv"

            # Mock DNS resolution: initial URL resolves to public, redirect to private
            def dns_side_effect(hostname: str, port: Any) -> list[tuple[Any, ...]]:
                if "example.com" in hostname:
                    return mock_getaddrinfo("93.184.216.34")  # Public IP for example.com
                elif "evil-internal" in hostname:
                    return mock_getaddrinfo("192.168.1.1")  # Private IP
                raise socket.gaierror("Unknown host")

            # Mock HTTP response with redirect to private IP
            mock_redirect_response = unittest.mock.Mock()
            mock_redirect_response.is_redirect = True
            mock_redirect_response.headers = {"Location": "http://evil-internal.local/metadata"}

            with patch("sunstone.datasets.socket.getaddrinfo", side_effect=dns_side_effect):
                with patch("sunstone.datasets.requests.get", return_value=mock_redirect_response):
                    with pytest.raises(ValueError, match="not allowed"):
                        manager.fetch_from_url(dataset, force=True)

    def test_redirect_to_localhost_blocked(self, project_path: Path) -> None:
        """Test that redirects to localhost are blocked."""
        manager = sunstone.DatasetsManager(project_path)
        dataset = manager.find_dataset_by_slug("official-un-member-states")

        if dataset and dataset.source:
            dataset.source.location.data = "https://example.com/data.csv"

            def dns_side_effect(hostname: str, port: Any) -> list[tuple[Any, ...]]:
                if "example.com" in hostname:
                    return mock_getaddrinfo("93.184.216.34")
                elif hostname == "localhost":
                    return mock_getaddrinfo("127.0.0.1")
                raise socket.gaierror("Unknown host")

            mock_redirect_response = unittest.mock.Mock()
            mock_redirect_response.is_redirect = True
            mock_redirect_response.headers = {"Location": "http://localhost/admin"}

            with patch("sunstone.datasets.socket.getaddrinfo", side_effect=dns_side_effect):
                with patch("sunstone.datasets.requests.get", return_value=mock_redirect_response):
                    with pytest.raises(ValueError, match="not allowed"):
                        manager.fetch_from_url(dataset, force=True)

    def test_redirect_to_cloud_metadata_blocked(self, project_path: Path) -> None:
        """Test that redirects to cloud metadata endpoints are blocked."""
        manager = sunstone.DatasetsManager(project_path)
        dataset = manager.find_dataset_by_slug("official-un-member-states")

        if dataset and dataset.source:
            dataset.source.location.data = "https://example.com/data.csv"

            def dns_side_effect(hostname: str, port: Any) -> list[tuple[Any, ...]]:
                if "example.com" in hostname:
                    return mock_getaddrinfo("93.184.216.34")
                elif hostname == "169.254.169.254":
                    return mock_getaddrinfo("169.254.169.254")
                raise socket.gaierror("Unknown host")

            mock_redirect_response = unittest.mock.Mock()
            mock_redirect_response.is_redirect = True
            mock_redirect_response.headers = {"Location": "http://169.254.169.254/latest/meta-data/"}

            with patch("sunstone.datasets.socket.getaddrinfo", side_effect=dns_side_effect):
                with patch("sunstone.datasets.requests.get", return_value=mock_redirect_response):
                    with pytest.raises(ValueError, match="not allowed"):
                        manager.fetch_from_url(dataset, force=True)

    def test_redirect_to_public_url_allowed(self, project_path: Path) -> None:
        """Test that redirects to other public URLs are allowed."""
        manager = sunstone.DatasetsManager(project_path)
        dataset = manager.find_dataset_by_slug("official-un-member-states")

        if dataset and dataset.source:
            dataset.source.location.data = "https://example.com/old-path"

            def dns_side_effect(hostname: str, port: Any) -> list[tuple[Any, ...]]:
                # Both URLs resolve to public IPs
                return mock_getaddrinfo("93.184.216.34")

            # First call returns redirect, second call returns content
            mock_redirect_response = unittest.mock.Mock()
            mock_redirect_response.is_redirect = True
            mock_redirect_response.headers = {"Location": "https://example.com/new-path"}

            mock_final_response = unittest.mock.Mock()
            mock_final_response.is_redirect = False
            mock_final_response.status_code = 200
            mock_final_response.content = b"test data"
            mock_final_response.raise_for_status = unittest.mock.Mock()

            with patch("sunstone.datasets.socket.getaddrinfo", side_effect=dns_side_effect):
                with patch(
                    "sunstone.datasets.requests.get",
                    side_effect=[mock_redirect_response, mock_final_response],
                ):
                    # Mock file writing to avoid modifying test input files
                    with patch("builtins.open", unittest.mock.mock_open()):
                        # Should succeed without raising an error
                        result = manager.fetch_from_url(dataset, force=True)
                        assert result is not None

    def test_too_many_redirects_blocked(self, project_path: Path) -> None:
        """Test that too many redirects are blocked."""
        manager = sunstone.DatasetsManager(project_path)
        dataset = manager.find_dataset_by_slug("official-un-member-states")

        if dataset and dataset.source:
            dataset.source.location.data = "https://example.com/data.csv"

            def dns_side_effect(hostname: str, port: Any) -> list[tuple[Any, ...]]:
                return mock_getaddrinfo("93.184.216.34")  # All public IPs

            # Always return redirect
            mock_redirect_response = unittest.mock.Mock()
            mock_redirect_response.is_redirect = True
            mock_redirect_response.headers = {"Location": "https://example.com/redirect-loop"}

            with patch("sunstone.datasets.socket.getaddrinfo", side_effect=dns_side_effect):
                with patch("sunstone.datasets.requests.get", return_value=mock_redirect_response):
                    with pytest.raises(ValueError, match="Too many redirects"):
                        manager.fetch_from_url(dataset, force=True, max_redirects=5)

    def test_redirect_without_location_header_blocked(self, project_path: Path) -> None:
        """Test that redirects without Location header are blocked."""
        manager = sunstone.DatasetsManager(project_path)
        dataset = manager.find_dataset_by_slug("official-un-member-states")

        if dataset and dataset.source:
            dataset.source.location.data = "https://example.com/data.csv"

            def dns_side_effect(hostname: str, port: Any) -> list[tuple[Any, ...]]:
                return mock_getaddrinfo("93.184.216.34")

            mock_redirect_response = unittest.mock.Mock()
            mock_redirect_response.is_redirect = True
            mock_redirect_response.headers = {}  # No Location header

            with patch("sunstone.datasets.socket.getaddrinfo", side_effect=dns_side_effect):
                with patch("sunstone.datasets.requests.get", return_value=mock_redirect_response):
                    with pytest.raises(ValueError, match="Location header"):
                        manager.fetch_from_url(dataset, force=True)

    def test_redirect_to_file_scheme_blocked(self, project_path: Path) -> None:
        """Test that redirects to file:// URLs are blocked."""
        manager = sunstone.DatasetsManager(project_path)
        dataset = manager.find_dataset_by_slug("official-un-member-states")

        if dataset and dataset.source:
            dataset.source.location.data = "https://example.com/data.csv"

            def dns_side_effect(hostname: str, port: Any) -> list[tuple[Any, ...]]:
                return mock_getaddrinfo("93.184.216.34")

            mock_redirect_response = unittest.mock.Mock()
            mock_redirect_response.is_redirect = True
            mock_redirect_response.headers = {"Location": "file:///etc/passwd"}

            with patch("sunstone.datasets.socket.getaddrinfo", side_effect=dns_side_effect):
                with patch("sunstone.datasets.requests.get", return_value=mock_redirect_response):
                    with pytest.raises(ValueError, match="not allowed"):
                        manager.fetch_from_url(dataset, force=True)

    def test_relative_redirect_url_resolved(self, project_path: Path) -> None:
        """Test that relative redirect URLs are properly resolved."""
        manager = sunstone.DatasetsManager(project_path)
        dataset = manager.find_dataset_by_slug("official-un-member-states")

        if dataset and dataset.source:
            dataset.source.location.data = "https://example.com/old/data.csv"

            def dns_side_effect(hostname: str, port: Any) -> list[tuple[Any, ...]]:
                return mock_getaddrinfo("93.184.216.34")  # Public IP

            # First call returns redirect with relative URL, second call returns content
            mock_redirect_response = unittest.mock.Mock()
            mock_redirect_response.is_redirect = True
            mock_redirect_response.headers = {"Location": "../new/data.csv"}  # Relative URL

            mock_final_response = unittest.mock.Mock()
            mock_final_response.is_redirect = False
            mock_final_response.status_code = 200
            mock_final_response.content = b"test data"
            mock_final_response.raise_for_status = unittest.mock.Mock()

            with patch("sunstone.datasets.socket.getaddrinfo", side_effect=dns_side_effect):
                with patch(
                    "sunstone.datasets.requests.get",
                    side_effect=[mock_redirect_response, mock_final_response],
                ) as mock_get:
                    # Mock file writing to avoid modifying test input files
                    with patch("builtins.open", unittest.mock.mock_open()):
                        result = manager.fetch_from_url(dataset, force=True)
                        assert result is not None
                        # Verify the relative URL was resolved to the correct absolute URL
                        # The second call should be to the resolved URL: https://example.com/new/data.csv
                        assert mock_get.call_count == 2
                        second_call_url = mock_get.call_args_list[1][0][0]
                        assert second_call_url == "https://example.com/new/data.csv"
