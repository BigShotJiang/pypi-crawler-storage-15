__version__ = '2025.12.11'
from .obj2sig import (decorator as paramize, var_property)

__all__= [paramize, var_property]