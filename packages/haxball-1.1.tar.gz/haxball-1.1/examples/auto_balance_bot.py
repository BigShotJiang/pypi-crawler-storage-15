"""
Auto-balance bot example for haxball.py

This bot automatically balances teams when players join or leave.
It also provides commands for captains mode.
"""

import asyncio
import os
import random
from haxball import HaxballClient, Team, PlayerObject


class AutoBalanceBot:
    """Bot that keeps teams balanced"""

    def __init__(self, room):
        self.room = room
        self.captains_mode = False
        self.red_captain: int | None = None
        self.blue_captain: int | None = None
        self.pick_turn: Team = Team.RED

        self._setup_handlers()

    def _setup_handlers(self):
        def on_room_link(link: str):
            print(f"Room link: {link}")

        def on_player_join(player: PlayerObject):
            self.room.sendAnnouncement(
                f"Welcome {player.name}! Type !help for commands.",
                targetId=player.id,
                color=0x00FF00,
            )

            # Auto-balance if not in captains mode
            if not self.captains_mode:
                asyncio.get_event_loop().call_later(
                    1.0, lambda: self._auto_balance()
                )

        def on_player_leave(player: PlayerObject):
            # Reset captain if they leave
            if player.id == self.red_captain:
                self.red_captain = None
            elif player.id == self.blue_captain:
                self.blue_captain = None

            # Rebalance
            if not self.captains_mode:
                asyncio.get_event_loop().call_later(
                    1.0, lambda: self._auto_balance()
                )

        def on_player_chat(player: PlayerObject, message: str) -> bool:
            if message.startswith("!"):
                self._handle_command(player, message[1:])
                return False
            return True

        def on_game_stop(_):
            # Reset captains mode after game
            if self.captains_mode:
                self.captains_mode = False
                self.red_captain = None
                self.blue_captain = None
                self.room.sendAnnouncement(
                    "Captains mode ended. Auto-balance resumed.",
                    color=0xFFFF00,
                )

        self.room.onRoomLink = on_room_link
        self.room.onPlayerJoin = on_player_join
        self.room.onPlayerLeave = on_player_leave
        self.room.onPlayerChat = on_player_chat
        self.room.onGameStop = on_game_stop

    def _handle_command(self, player: PlayerObject, cmd_str: str):
        parts = cmd_str.lower().split()
        if not parts:
            return

        cmd = parts[0]
        args = parts[1:]

        if cmd == "help":
            self._cmd_help(player)
        elif cmd == "balance" or cmd == "bb":
            self._auto_balance()
        elif cmd == "randomize" or cmd == "rand":
            self._randomize_teams()
        elif cmd == "captains" or cmd == "caps":
            self._start_captains_mode(player)
        elif cmd == "pick" or cmd == "p":
            self._pick_player(player, args)
        elif cmd == "spec" or cmd == "afk":
            self.room.setPlayerTeam(player.id, Team.SPECTATORS)

    def _cmd_help(self, player: PlayerObject):
        msg = """Commands:
!balance - Auto-balance teams
!randomize - Randomize teams
!captains - Start captains mode
!pick <name> - Pick player (captains)
!spec - Move to spectators"""
        self.room.sendAnnouncement(msg, targetId=player.id, color=0xFFFF00)

    def _auto_balance(self):
        """Balance teams by player count"""
        players = self.room.getPlayerList()

        red = [p for p in players if p.team == Team.RED]
        blue = [p for p in players if p.team == Team.BLUE]
        specs = [p for p in players if p.team == Team.SPECTATORS]

        # Move spectators to smaller team
        for spec in specs:
            if len(red) <= len(blue):
                self.room.setPlayerTeam(spec.id, Team.RED)
                red.append(spec)
            else:
                self.room.setPlayerTeam(spec.id, Team.BLUE)
                blue.append(spec)

        # Balance existing players
        diff = len(red) - len(blue)
        if diff >= 2:
            # Move from red to blue
            to_move = red[-1]
            self.room.setPlayerTeam(to_move.id, Team.BLUE)
        elif diff <= -2:
            # Move from blue to red
            to_move = blue[-1]
            self.room.setPlayerTeam(to_move.id, Team.RED)

    def _randomize_teams(self):
        """Randomly assign all players to teams"""
        players = self.room.getPlayerList()

        # Move all to spectators first
        for p in players:
            self.room.setPlayerTeam(p.id, Team.SPECTATORS)

        # Shuffle and assign
        random.shuffle(players)
        for i, p in enumerate(players):
            team = Team.RED if i % 2 == 0 else Team.BLUE
            self.room.setPlayerTeam(p.id, team)

        self.room.sendAnnouncement("Teams randomized!", color=0x00FF00)

    def _start_captains_mode(self, player: PlayerObject):
        """Start captains pick mode"""
        players = self.room.getPlayerList()

        if len(players) < 4:
            self.room.sendAnnouncement(
                "Need at least 4 players for captains mode!",
                targetId=player.id,
                color=0xFF0000,
            )
            return

        # Move all to spectators
        for p in players:
            self.room.setPlayerTeam(p.id, Team.SPECTATORS)

        # Pick 2 random captains
        caps = random.sample(players, 2)
        self.red_captain = caps[0].id
        self.blue_captain = caps[1].id

        self.room.setPlayerTeam(self.red_captain, Team.RED)
        self.room.setPlayerTeam(self.blue_captain, Team.BLUE)

        self.captains_mode = True
        self.pick_turn = Team.RED

        self.room.sendAnnouncement(
            f"Captains: {caps[0].name} (Red) vs {caps[1].name} (Blue)",
            color=0xFFFF00,
            style="bold",
        )
        self.room.sendAnnouncement(
            f"{caps[0].name} picks first! Use !pick <name>",
            color=0xFF0000,
        )

    def _pick_player(self, player: PlayerObject, args: list[str]):
        """Captain picks a player"""
        if not self.captains_mode:
            return

        # Check if it's their turn
        if self.pick_turn == Team.RED and player.id != self.red_captain:
            self.room.sendAnnouncement(
                "It's Red captain's turn to pick!",
                targetId=player.id,
                color=0xFF0000,
            )
            return
        if self.pick_turn == Team.BLUE and player.id != self.blue_captain:
            self.room.sendAnnouncement(
                "It's Blue captain's turn to pick!",
                targetId=player.id,
                color=0xFF0000,
            )
            return

        if not args:
            self.room.sendAnnouncement(
                "Usage: !pick <player name>",
                targetId=player.id,
                color=0xFF0000,
            )
            return

        # Find player
        target_name = " ".join(args).lower()
        target = None
        for p in self.room.getPlayerList():
            if p.team == Team.SPECTATORS and target_name in p.name.lower():
                target = p
                break

        if not target:
            self.room.sendAnnouncement(
                f"Player '{target_name}' not found in spectators",
                targetId=player.id,
                color=0xFF0000,
            )
            return

        # Move to team
        self.room.setPlayerTeam(target.id, self.pick_turn)
        self.room.sendAnnouncement(
            f"{target.name} joins {'Red' if self.pick_turn == Team.RED else 'Blue'}!",
            color=0x00FF00,
        )

        # Switch turn
        self.pick_turn = Team.BLUE if self.pick_turn == Team.RED else Team.RED

        # Check if picking is done
        specs = [p for p in self.room.getPlayerList() if p.team == Team.SPECTATORS]
        if len(specs) <= 1:
            if specs:
                # Last player goes to smaller team
                players = self.room.getPlayerList()
                red_count = sum(1 for p in players if p.team == Team.RED)
                blue_count = sum(1 for p in players if p.team == Team.BLUE)
                team = Team.RED if red_count < blue_count else Team.BLUE
                self.room.setPlayerTeam(specs[0].id, team)

            self.captains_mode = False
            self.room.sendAnnouncement(
                "Teams are ready! Game can start.",
                color=0x00FF00,
                style="bold",
            )


async def main():
    token = os.environ.get("HAXBALL_TOKEN")
    if not token:
        print("Please set HAXBALL_TOKEN environment variable")
        return

    client = HaxballClient()
    room = await client.create_room(
        roomName="Auto Balance Room",
        maxPlayers=16,
        public=False,
        token=token,
    )

    bot = AutoBalanceBot(room)

    room.setScoreLimit(5)
    room.setTimeLimit(7)
    room.setDefaultStadium("Classic")

    print("Auto-balance bot is running!")

    try:
        await room.run_forever()
    except KeyboardInterrupt:
        print("\nShutting down...")
    finally:
        await room.close()


if __name__ == "__main__":
    asyncio.run(main())
