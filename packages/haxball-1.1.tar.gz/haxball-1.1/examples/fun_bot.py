"""
Fun commands bot example for haxball.py

This bot adds fun commands and mini-games to your room.
"""

import asyncio
import os
import random
from haxball import HaxballClient, Team, PlayerObject


class FunBot:
    """Bot with fun commands and mini-games"""

    def __init__(self, room):
        self.room = room
        self.rps_challenges: dict[int, int] = {}  # challenger_id -> target_id
        self.coin_flip_bets: dict[int, str] = {}  # player_id -> "heads" or "tails"
        self.trivia_answer: str | None = None
        self.trivia_reward: str = ""

        self._setup_handlers()

    def _setup_handlers(self):
        def on_room_link(link: str):
            print(f"Room link: {link}")

        def on_player_join(player: PlayerObject):
            greetings = [
                f"Welcome {player.name}! Ready to have fun?",
                f"Hey {player.name}! Type !fun for commands!",
                f"{player.name} has entered the arena!",
                f"Everyone welcome {player.name}!",
            ]
            self.room.sendAnnouncement(
                random.choice(greetings),
                color=0x00FF00,
            )

        def on_player_chat(player: PlayerObject, message: str) -> bool:
            # Check trivia answer
            if self.trivia_answer and message.lower().strip() == self.trivia_answer.lower():
                self.room.sendAnnouncement(
                    f"{player.name} got it! The answer was: {self.trivia_answer}",
                    color=0x00FF00,
                    style="bold",
                )
                self.trivia_answer = None
                return True

            if message.startswith("!"):
                self._handle_command(player, message[1:])
                return False
            return True

        self.room.onRoomLink = on_room_link
        self.room.onPlayerJoin = on_player_join
        self.room.onPlayerChat = on_player_chat

    def _handle_command(self, player: PlayerObject, cmd_str: str):
        parts = cmd_str.split()
        if not parts:
            return

        cmd = parts[0].lower()
        args = parts[1:]

        if cmd == "help" or cmd == "fun":
            self._cmd_help(player)
        elif cmd == "roll" or cmd == "dice":
            self._cmd_roll(player, args)
        elif cmd == "flip" or cmd == "coin":
            self._cmd_flip(player)
        elif cmd == "8ball":
            self._cmd_8ball(player, args)
        elif cmd == "rps":
            self._cmd_rps(player, args)
        elif cmd == "rock" or cmd == "paper" or cmd == "scissors":
            self._cmd_rps_play(player, cmd)
        elif cmd == "trivia":
            self._cmd_trivia(player)
        elif cmd == "quote":
            self._cmd_quote(player)
        elif cmd == "joke":
            self._cmd_joke(player)
        elif cmd == "fact":
            self._cmd_fact(player)
        elif cmd == "hug":
            self._cmd_hug(player, args)
        elif cmd == "slap":
            self._cmd_slap(player, args)
        elif cmd == "dance":
            self._cmd_dance(player)

    def _cmd_help(self, player: PlayerObject):
        msg = """Fun Commands:
!roll [max] - Roll dice (default 100)
!flip - Flip a coin
!8ball <question> - Magic 8-ball
!rps <name> - Rock paper scissors
!trivia - Random trivia
!quote - Random quote
!joke - Tell a joke
!fact - Random fact
!hug <name> - Hug someone
!slap <name> - Slap someone
!dance - Dance!"""
        self.room.sendAnnouncement(msg, targetId=player.id, color=0xFFFF00)

    def _cmd_roll(self, player: PlayerObject, args: list[str]):
        max_val = 100
        if args and args[0].isdigit():
            max_val = min(int(args[0]), 1000000)

        result = random.randint(1, max_val)
        self.room.sendAnnouncement(
            f"{player.name} rolled {result} (1-{max_val})",
            color=0x00FFFF,
        )

    def _cmd_flip(self, player: PlayerObject):
        result = random.choice(["Heads", "Tails"])
        self.room.sendAnnouncement(
            f"{player.name} flips a coin... {result}!",
            color=0xFFFF00,
        )

    def _cmd_8ball(self, player: PlayerObject, args: list[str]):
        if not args:
            self.room.sendAnnouncement(
                "Ask a question! !8ball <question>",
                targetId=player.id,
                color=0xFF0000,
            )
            return

        responses = [
            "Yes, definitely!",
            "It is certain.",
            "Without a doubt.",
            "Yes.",
            "Most likely.",
            "Outlook good.",
            "Signs point to yes.",
            "Ask again later.",
            "Cannot predict now.",
            "Concentrate and ask again.",
            "Don't count on it.",
            "My reply is no.",
            "My sources say no.",
            "Outlook not so good.",
            "Very doubtful.",
        ]

        self.room.sendAnnouncement(
            f"8-Ball: {random.choice(responses)}",
            color=0x9900FF,
        )

    def _cmd_rps(self, player: PlayerObject, args: list[str]):
        if not args:
            self.room.sendAnnouncement(
                "Challenge someone! !rps <name>",
                targetId=player.id,
                color=0xFF0000,
            )
            return

        target_name = " ".join(args).lower()
        target = None
        for p in self.room.getPlayerList():
            if target_name in p.name.lower() and p.id != player.id:
                target = p
                break

        if not target:
            self.room.sendAnnouncement(
                f"Player '{target_name}' not found",
                targetId=player.id,
                color=0xFF0000,
            )
            return

        self.rps_challenges[player.id] = target.id
        self.room.sendAnnouncement(
            f"{player.name} challenges {target.name} to Rock Paper Scissors!",
            color=0xFFFF00,
        )
        self.room.sendAnnouncement(
            f"Use !rock, !paper, or !scissors to play!",
            color=0xFFFF00,
        )

    def _cmd_rps_play(self, player: PlayerObject, choice: str):
        # Find if player has a pending game
        challenger_id = None
        target_id = None

        for cid, tid in self.rps_challenges.items():
            if cid == player.id or tid == player.id:
                challenger_id = cid
                target_id = tid
                break

        if challenger_id is None:
            self.room.sendAnnouncement(
                "Start a game first with !rps <name>",
                targetId=player.id,
                color=0xFF0000,
            )
            return

        # Computer plays for simplicity
        bot_choice = random.choice(["rock", "paper", "scissors"])

        winners = {
            ("rock", "scissors"): True,
            ("paper", "rock"): True,
            ("scissors", "paper"): True,
        }

        if choice == bot_choice:
            result = "It's a tie!"
            color = 0xFFFF00
        elif (choice, bot_choice) in winners:
            result = f"{player.name} wins!"
            color = 0x00FF00
        else:
            result = f"{player.name} loses!"
            color = 0xFF0000

        self.room.sendAnnouncement(
            f"{player.name}: {choice.upper()} vs Bot: {bot_choice.upper()} - {result}",
            color=color,
        )

        # Remove challenge
        if challenger_id in self.rps_challenges:
            del self.rps_challenges[challenger_id]

    def _cmd_trivia(self, player: PlayerObject):
        trivia = [
            ("What is the capital of France?", "Paris"),
            ("How many sides does a hexagon have?", "6"),
            ("What planet is known as the Red Planet?", "Mars"),
            ("What is the largest ocean?", "Pacific"),
            ("Who painted the Mona Lisa?", "Da Vinci"),
            ("What is H2O commonly known as?", "Water"),
            ("How many continents are there?", "7"),
            ("What is the fastest land animal?", "Cheetah"),
        ]

        question, answer = random.choice(trivia)
        self.trivia_answer = answer

        self.room.sendAnnouncement(
            f"TRIVIA: {question}",
            color=0xFF00FF,
            style="bold",
        )

    def _cmd_quote(self, player: PlayerObject):
        quotes = [
            '"The only way to do great work is to love what you do." - Steve Jobs',
            '"Be the change you wish to see in the world." - Gandhi',
            '"In the middle of difficulty lies opportunity." - Einstein',
            '"Life is what happens when you\'re busy making other plans." - John Lennon',
            '"The future belongs to those who believe in the beauty of their dreams." - Eleanor Roosevelt',
        ]
        self.room.sendAnnouncement(random.choice(quotes), color=0x00FFFF)

    def _cmd_joke(self, player: PlayerObject):
        jokes = [
            "Why don't scientists trust atoms? Because they make up everything!",
            "I told my wife she was drawing her eyebrows too high. She looked surprised.",
            "Why did the scarecrow win an award? He was outstanding in his field!",
            "I'm reading a book about anti-gravity. It's impossible to put down!",
            "Why don't eggs tell jokes? They'd crack each other up!",
        ]
        self.room.sendAnnouncement(random.choice(jokes), color=0xFFFF00)

    def _cmd_fact(self, player: PlayerObject):
        facts = [
            "Honey never spoils. 3000-year-old honey has been found edible!",
            "A group of flamingos is called a 'flamboyance'.",
            "Octopuses have three hearts and blue blood.",
            "The shortest war in history lasted 38-45 minutes.",
            "A day on Venus is longer than a year on Venus.",
        ]
        self.room.sendAnnouncement(f"Fun Fact: {random.choice(facts)}", color=0x00FF00)

    def _cmd_hug(self, player: PlayerObject, args: list[str]):
        if not args:
            self.room.sendAnnouncement(
                f"{player.name} hugs everyone!",
                color=0xFF69B4,
            )
            return

        target_name = " ".join(args)
        self.room.sendAnnouncement(
            f"{player.name} gives {target_name} a big hug!",
            color=0xFF69B4,
        )

    def _cmd_slap(self, player: PlayerObject, args: list[str]):
        if not args:
            self.room.sendAnnouncement(
                "Slap who? !slap <name>",
                targetId=player.id,
                color=0xFF0000,
            )
            return

        target_name = " ".join(args)
        items = ["a large trout", "a wet noodle", "a rubber chicken", "a keyboard", "a pillow"]
        self.room.sendAnnouncement(
            f"{player.name} slaps {target_name} with {random.choice(items)}!",
            color=0xFF6600,
        )

    def _cmd_dance(self, player: PlayerObject):
        dances = [
            f"{player.name} does the robot!",
            f"{player.name} breaks out into a moonwalk!",
            f"{player.name} does the macarena!",
            f"{player.name} starts doing the floss!",
            f"{player.name} spins around gracefully!",
        ]
        self.room.sendAnnouncement(random.choice(dances), color=0xFF00FF)


async def main():
    token = os.environ.get("HAXBALL_TOKEN")
    if not token:
        print("Please set HAXBALL_TOKEN environment variable")
        return

    client = HaxballClient()
    room = await client.create_room(
        roomName="Fun Commands Room",
        maxPlayers=16,
        public=False,
        token=token,
    )

    bot = FunBot(room)

    room.setScoreLimit(5)
    room.setTimeLimit(7)
    room.setDefaultStadium("Classic")

    print("Fun bot is running!")

    try:
        await room.run_forever()
    except KeyboardInterrupt:
        print("\nShutting down...")
    finally:
        await room.close()


if __name__ == "__main__":
    asyncio.run(main())
