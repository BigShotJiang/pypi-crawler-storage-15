"""
Physics manipulation example for haxball.py

This bot demonstrates how to manipulate disc physics,
create power-ups, and add special abilities.
"""

import asyncio
import os
import random
import time
from haxball import HaxballClient, Team, PlayerObject, DiscPropertiesObject, Vector2


class PhysicsBot:
    """Bot that demonstrates physics manipulation"""

    def __init__(self, room):
        self.room = room
        self.powerups: dict[int, dict] = {}  # player_id -> powerup info
        self.super_shot_ready: dict[int, bool] = {}
        self.frozen_players: set[int] = set()
        self.speed_boost: dict[int, float] = {}  # player_id -> end_time

        self._setup_handlers()

    def _setup_handlers(self):
        def on_room_link(link: str):
            print(f"Room link: {link}")

        def on_player_join(player: PlayerObject):
            self.super_shot_ready[player.id] = False
            self.room.sendAnnouncement(
                f"Welcome! Type !powers for special abilities.",
                targetId=player.id,
                color=0x00FF00,
            )

        def on_player_leave(player: PlayerObject):
            self.super_shot_ready.pop(player.id, None)
            self.frozen_players.discard(player.id)
            self.speed_boost.pop(player.id, None)

        def on_player_chat(player: PlayerObject, message: str) -> bool:
            if message.startswith("!"):
                self._handle_command(player, message[1:])
                return False
            return True

        def on_player_ball_kick(player: PlayerObject):
            # Super shot
            if self.super_shot_ready.get(player.id):
                self._activate_super_shot(player)
                self.super_shot_ready[player.id] = False
                self.room.sendAnnouncement(
                    f"{player.name} uses SUPER SHOT!",
                    color=0xFF00FF,
                    style="bold",
                )

        def on_game_tick():
            # Check speed boost expiry
            now = time.time()
            expired = [pid for pid, end_time in self.speed_boost.items() if now > end_time]
            for pid in expired:
                self._reset_player_speed(pid)
                del self.speed_boost[pid]

        self.room.onRoomLink = on_room_link
        self.room.onPlayerJoin = on_player_join
        self.room.onPlayerLeave = on_player_leave
        self.room.onPlayerChat = on_player_chat
        self.room.onPlayerBallKick = on_player_ball_kick
        self.room.onGameTick = on_game_tick

    def _handle_command(self, player: PlayerObject, cmd_str: str):
        parts = cmd_str.lower().split()
        if not parts:
            return

        cmd = parts[0]
        args = parts[1:]

        if cmd == "help" or cmd == "powers":
            self._cmd_help(player)
        elif cmd == "supershot" or cmd == "ss":
            self._cmd_supershot(player)
        elif cmd == "boost":
            self._cmd_boost(player)
        elif cmd == "ball":
            self._cmd_ball(player, args)
        elif cmd == "gravity":
            self._cmd_gravity(player, args)
        elif cmd == "size":
            self._cmd_size(player, args)
        elif cmd == "bounce":
            self._cmd_bounce(player, args)
        elif cmd == "reset":
            self._cmd_reset(player)

    def _cmd_help(self, player: PlayerObject):
        msg = """Physics Powers:
!supershot - Charge super shot (next kick)
!boost - Speed boost (5 sec)
!ball <speed> - Set ball speed (1-50)
!gravity <x> <y> - Ball gravity
!size <radius> - Your disc size (10-30)
!bounce <0-2> - Your bounce coefficient
!reset - Reset your physics"""
        self.room.sendAnnouncement(msg, targetId=player.id, color=0xFFFF00)

    def _cmd_supershot(self, player: PlayerObject):
        if player.team == Team.SPECTATORS:
            self.room.sendAnnouncement(
                "Join a team first!",
                targetId=player.id,
                color=0xFF0000,
            )
            return

        self.super_shot_ready[player.id] = True
        self.room.sendAnnouncement(
            f"{player.name} is charging SUPER SHOT! Next kick will be powerful!",
            color=0xFF00FF,
        )

    def _activate_super_shot(self, player: PlayerObject):
        """Make the ball go super fast"""
        ball_props = self.room.getDiscProperties(0)
        if not ball_props:
            return

        # Get ball velocity and amplify it
        speed_x = ball_props.xspeed or 0
        speed_y = ball_props.yspeed or 0

        # Triple the speed
        new_props = DiscPropertiesObject(
            xspeed=speed_x * 3,
            yspeed=speed_y * 3,
        )
        self.room.setDiscProperties(0, new_props)

    def _cmd_boost(self, player: PlayerObject):
        if player.team == Team.SPECTATORS:
            self.room.sendAnnouncement(
                "Join a team first!",
                targetId=player.id,
                color=0xFF0000,
            )
            return

        # Set boost expiry (5 seconds)
        self.speed_boost[player.id] = time.time() + 5.0

        # Increase player acceleration
        props = DiscPropertiesObject(
            damping=0.995,  # Less friction
            invMass=2.0,    # Lighter (faster acceleration)
        )
        self.room.setPlayerDiscProperties(player.id, props)

        self.room.sendAnnouncement(
            f"{player.name} activated SPEED BOOST!",
            color=0x00FF00,
        )

    def _reset_player_speed(self, player_id: int):
        """Reset player to normal physics"""
        props = DiscPropertiesObject(
            damping=0.96,
            invMass=0.5,
        )
        self.room.setPlayerDiscProperties(player_id, props)

        player = self.room.getPlayer(player_id)
        if player:
            self.room.sendAnnouncement(
                f"{player.name}'s speed boost ended.",
                targetId=player_id,
                color=0xFFFF00,
            )

    def _cmd_ball(self, player: PlayerObject, args: list[str]):
        if not player.admin:
            self.room.sendAnnouncement(
                "Admin only!",
                targetId=player.id,
                color=0xFF0000,
            )
            return

        if not args:
            self.room.sendAnnouncement(
                "Usage: !ball <speed 1-50>",
                targetId=player.id,
                color=0xFF0000,
            )
            return

        try:
            speed = max(1, min(50, float(args[0])))
        except ValueError:
            return

        ball_props = self.room.getDiscProperties(0)
        if ball_props and (ball_props.xspeed or ball_props.yspeed):
            # Normalize and set speed
            current_speed = ((ball_props.xspeed or 0) ** 2 + (ball_props.yspeed or 0) ** 2) ** 0.5
            if current_speed > 0:
                factor = speed / current_speed
                new_props = DiscPropertiesObject(
                    xspeed=(ball_props.xspeed or 0) * factor,
                    yspeed=(ball_props.yspeed or 0) * factor,
                )
                self.room.setDiscProperties(0, new_props)

        self.room.sendAnnouncement(
            f"Ball speed set to {speed}",
            color=0x00FFFF,
        )

    def _cmd_gravity(self, player: PlayerObject, args: list[str]):
        if not player.admin:
            self.room.sendAnnouncement(
                "Admin only!",
                targetId=player.id,
                color=0xFF0000,
            )
            return

        if len(args) < 2:
            self.room.sendAnnouncement(
                "Usage: !gravity <x> <y> (e.g., !gravity 0 0.1)",
                targetId=player.id,
                color=0xFF0000,
            )
            return

        try:
            gx = float(args[0])
            gy = float(args[1])
        except ValueError:
            return

        # Apply gravity-like effect by modifying ball speed each tick
        # This is a simplified version - full implementation would need game tick
        self.room.sendAnnouncement(
            f"Gravity effect: ({gx}, {gy})",
            color=0x00FFFF,
        )

    def _cmd_size(self, player: PlayerObject, args: list[str]):
        if player.team == Team.SPECTATORS:
            self.room.sendAnnouncement(
                "Join a team first!",
                targetId=player.id,
                color=0xFF0000,
            )
            return

        if not args:
            self.room.sendAnnouncement(
                "Usage: !size <10-30>",
                targetId=player.id,
                color=0xFF0000,
            )
            return

        try:
            radius = max(10, min(30, float(args[0])))
        except ValueError:
            return

        props = DiscPropertiesObject(radius=radius)
        self.room.setPlayerDiscProperties(player.id, props)

        self.room.sendAnnouncement(
            f"{player.name} changed size to {radius}",
            color=0x00FFFF,
        )

    def _cmd_bounce(self, player: PlayerObject, args: list[str]):
        if player.team == Team.SPECTATORS:
            self.room.sendAnnouncement(
                "Join a team first!",
                targetId=player.id,
                color=0xFF0000,
            )
            return

        if not args:
            self.room.sendAnnouncement(
                "Usage: !bounce <0-2>",
                targetId=player.id,
                color=0xFF0000,
            )
            return

        try:
            bcoef = max(0, min(2, float(args[0])))
        except ValueError:
            return

        props = DiscPropertiesObject(bCoef=bcoef)
        self.room.setPlayerDiscProperties(player.id, props)

        self.room.sendAnnouncement(
            f"{player.name} bounce set to {bcoef}",
            color=0x00FFFF,
        )

    def _cmd_reset(self, player: PlayerObject):
        """Reset player to default physics"""
        if player.team == Team.SPECTATORS:
            return

        props = DiscPropertiesObject(
            radius=15,
            bCoef=0.5,
            invMass=0.5,
            damping=0.96,
        )
        self.room.setPlayerDiscProperties(player.id, props)

        self.super_shot_ready[player.id] = False
        self.speed_boost.pop(player.id, None)

        self.room.sendAnnouncement(
            f"{player.name} reset to default physics",
            targetId=player.id,
            color=0x00FF00,
        )


async def main():
    token = os.environ.get("HAXBALL_TOKEN")
    if not token:
        print("Please set HAXBALL_TOKEN environment variable")
        return

    client = HaxballClient()
    room = await client.create_room(
        roomName="Physics Lab",
        maxPlayers=12,
        public=False,
        token=token,
    )

    bot = PhysicsBot(room)

    room.setScoreLimit(5)
    room.setTimeLimit(7)
    room.setDefaultStadium("Classic")

    print("Physics bot is running!")

    try:
        await room.run_forever()
    except KeyboardInterrupt:
        print("\nShutting down...")
    finally:
        await room.close()


if __name__ == "__main__":
    asyncio.run(main())
