"""
Advanced admin bot example for haxball.py

This example shows how to create a more complex bot with admin commands,
auto-balancing, and AFK detection.
"""

import asyncio
import os
import time
from haxball import HaxballClient, Team, PlayerObject


class AdminBot:
    """Advanced admin bot with multiple features"""

    def __init__(self, room):
        self.room = room
        self.admins: set[str] = set()  # Auth strings of admins
        self.afk_timeout = 30  # Seconds
        self.last_activity: dict[int, float] = {}
        self.muted: set[int] = set()

        # Load super admins from env
        super_admin = os.environ.get("SUPER_ADMIN_AUTH")
        if super_admin:
            self.admins.add(super_admin)

        self._setup_handlers()

    def _setup_handlers(self):
        """Set up all event handlers"""

        def on_room_link(link: str):
            print(f"Room link: {link}")

        def on_player_join(player: PlayerObject):
            self.last_activity[player.id] = time.time()

            # Check if player is admin
            if player.auth in self.admins:
                self.room.setPlayerAdmin(player.id, True)
                self.room.sendAnnouncement(
                    f"{player.name} (Admin) has joined!",
                    color=0xFF9900,
                    style="bold",
                )
            else:
                self.room.sendAnnouncement(
                    f"Welcome {player.name}! Type !help for commands.",
                    targetId=player.id,
                    color=0x00FF00,
                )

        def on_player_leave(player: PlayerObject):
            self.last_activity.pop(player.id, None)
            self.muted.discard(player.id)

        def on_player_chat(player: PlayerObject, message: str) -> bool:
            self.last_activity[player.id] = time.time()

            # Check mute
            if player.id in self.muted:
                self.room.sendAnnouncement(
                    "You are muted!",
                    targetId=player.id,
                    color=0xFF0000,
                )
                return False

            # Handle commands
            if message.startswith("!"):
                self._handle_command(player, message[1:])
                return False

            return True

        def on_kick(player: PlayerObject):
            self.last_activity[player.id] = time.time()

        def on_game_start(_):
            self.room.sendAnnouncement("Game started! Good luck!", color=0x00FF00)

        def on_victory(scores):
            winner = "Red" if scores.red > scores.blue else "Blue"
            self.room.sendAnnouncement(
                f"{winner} team wins! ({scores.red}-{scores.blue})",
                color=0xFFFF00,
                style="bold",
            )

        # Set event handlers
        self.room.onRoomLink = on_room_link
        self.room.onPlayerJoin = on_player_join
        self.room.onPlayerLeave = on_player_leave
        self.room.onPlayerChat = on_player_chat
        self.room.onPlayerBallKick = on_kick
        self.room.onGameStart = on_game_start
        self.room.onTeamVictory = on_victory

    def _handle_command(self, player: PlayerObject, cmd_str: str):
        """Handle chat commands"""
        parts = cmd_str.lower().split()
        if not parts:
            return

        cmd = parts[0]
        args = parts[1:]

        # Public commands
        if cmd == "help":
            self._cmd_help(player)
        elif cmd == "afk":
            self.room.setPlayerTeam(player.id, Team.SPECTATORS)
        elif cmd == "bb":
            self.room.kickPlayer(player.id, "Goodbye!")
        elif cmd == "stats":
            self._cmd_stats(player)

        # Admin commands
        elif player.admin:
            if cmd == "kick" and args:
                self._cmd_kick(player, args)
            elif cmd == "ban" and args:
                self._cmd_ban(player, args)
            elif cmd == "mute" and args:
                self._cmd_mute(player, args)
            elif cmd == "unmute" and args:
                self._cmd_unmute(player, args)
            elif cmd == "swap":
                self._cmd_swap(player)
            elif cmd == "rr":
                self._cmd_reset_teams(player)
            elif cmd == "start":
                self.room.startGame()
            elif cmd == "stop":
                self.room.stopGame()
            elif cmd == "pause":
                self.room.pauseGame()
            elif cmd == "clearbans":
                self.room.clearBans()
                self.room.sendAnnouncement("All bans cleared!", color=0x00FF00)

    def _cmd_help(self, player: PlayerObject):
        """Show help message"""
        msg = "Commands: !help, !afk, !bb, !stats"
        if player.admin:
            msg += "\nAdmin: !kick, !ban, !mute, !unmute, !swap, !rr, !start, !stop, !pause, !clearbans"
        self.room.sendAnnouncement(msg, targetId=player.id, color=0xFFFF00)

    def _cmd_stats(self, player: PlayerObject):
        """Show room stats"""
        players = self.room.getPlayerList()
        red = sum(1 for p in players if p.team == Team.RED)
        blue = sum(1 for p in players if p.team == Team.BLUE)
        spec = sum(1 for p in players if p.team == Team.SPECTATORS)

        msg = f"Players: {len(players)} | Red: {red} | Blue: {blue} | Spec: {spec}"
        self.room.sendAnnouncement(msg, targetId=player.id, color=0x00FFFF)

    def _cmd_kick(self, admin: PlayerObject, args: list[str]):
        """Kick a player"""
        target_name = " ".join(args)
        target = self._find_player(target_name)
        if target:
            self.room.kickPlayer(target.id, f"Kicked by {admin.name}")
        else:
            self.room.sendAnnouncement(
                f"Player '{target_name}' not found",
                targetId=admin.id,
                color=0xFF0000,
            )

    def _cmd_ban(self, admin: PlayerObject, args: list[str]):
        """Ban a player"""
        target_name = " ".join(args)
        target = self._find_player(target_name)
        if target:
            self.room.kickPlayer(target.id, f"Banned by {admin.name}", ban=True)
        else:
            self.room.sendAnnouncement(
                f"Player '{target_name}' not found",
                targetId=admin.id,
                color=0xFF0000,
            )

    def _cmd_mute(self, admin: PlayerObject, args: list[str]):
        """Mute a player"""
        target_name = " ".join(args)
        target = self._find_player(target_name)
        if target:
            self.muted.add(target.id)
            self.room.sendAnnouncement(
                f"{target.name} has been muted",
                color=0xFF9900,
            )

    def _cmd_unmute(self, admin: PlayerObject, args: list[str]):
        """Unmute a player"""
        target_name = " ".join(args)
        target = self._find_player(target_name)
        if target:
            self.muted.discard(target.id)
            self.room.sendAnnouncement(
                f"{target.name} has been unmuted",
                color=0x00FF00,
            )

    def _cmd_swap(self, admin: PlayerObject):
        """Swap teams"""
        players = self.room.getPlayerList()
        for p in players:
            if p.team == Team.RED:
                self.room.setPlayerTeam(p.id, Team.BLUE)
            elif p.team == Team.BLUE:
                self.room.setPlayerTeam(p.id, Team.RED)
        self.room.sendAnnouncement("Teams swapped!", color=0xFFFF00)

    def _cmd_reset_teams(self, admin: PlayerObject):
        """Move all to spectators"""
        players = self.room.getPlayerList()
        for p in players:
            if p.team != Team.SPECTATORS:
                self.room.setPlayerTeam(p.id, Team.SPECTATORS)
        self.room.sendAnnouncement("Teams reset!", color=0xFFFF00)

    def _find_player(self, name: str) -> PlayerObject | None:
        """Find player by name (partial match)"""
        name = name.lower()
        players = self.room.getPlayerList()
        for p in players:
            if name in p.name.lower():
                return p
        return None

    async def afk_check_loop(self):
        """Periodically check for AFK players"""
        while True:
            await asyncio.sleep(10)

            now = time.time()
            players = self.room.getPlayerList()

            for player in players:
                if player.team == Team.SPECTATORS:
                    continue

                last = self.last_activity.get(player.id, now)
                if now - last > self.afk_timeout:
                    self.room.setPlayerTeam(player.id, Team.SPECTATORS)
                    self.room.sendAnnouncement(
                        f"{player.name} moved to spectators (AFK)",
                        color=0xFF9900,
                    )
                    self.last_activity[player.id] = now


async def main():
    token = os.environ.get("HAXBALL_TOKEN")
    if not token:
        print("Please set HAXBALL_TOKEN environment variable")
        return

    client = HaxballClient()
    room = await client.create_room(
        roomName="Admin Bot Room",
        maxPlayers=20,
        public=False,
        token=token,
    )

    bot = AdminBot(room)

    # Configure room
    room.setScoreLimit(5)
    room.setTimeLimit(7)
    room.setDefaultStadium("Classic")

    print("Admin bot is running!")

    try:
        # Run both the room and AFK check loop
        await asyncio.gather(
            room.run_forever(),
            bot.afk_check_loop(),
        )
    except KeyboardInterrupt:
        print("\nShutting down...")
    finally:
        await room.close()


if __name__ == "__main__":
    asyncio.run(main())
