"""
Basic room example for haxball.py

This example shows how to create a simple HaxBall room with basic event handlers.
"""

import asyncio
import os
from haxball import HaxballClient, Team


async def main():
    # Get token from environment variable
    token = os.environ.get("HAXBALL_TOKEN")
    if not token:
        print("Please set HAXBALL_TOKEN environment variable")
        print("Get your token from: https://www.haxball.com/headlesstoken")
        return

    # Create client
    client = HaxballClient()

    # Create room
    room = await client.create_room(
        roomName="Python HaxBall Bot",
        maxPlayers=16,
        public=False,
        token=token,
    )

    # Event handlers
    def on_room_link(link: str):
        print(f"Room created: {link}")

    def on_player_join(player):
        print(f"[JOIN] {player.name} joined the room")
        room.sendAnnouncement(f"Welcome {player.name}!", color=0x00FF00)

    def on_player_leave(player):
        print(f"[LEAVE] {player.name} left the room")

    def on_player_chat(player, message: str) -> bool:
        print(f"[CHAT] {player.name}: {message}")

        # Command handling
        if message.startswith("!"):
            cmd = message[1:].lower().split()
            if not cmd:
                return True

            if cmd[0] == "help":
                room.sendAnnouncement(
                    "Commands: !help, !bb, !afk",
                    targetId=player.id,
                    color=0xFFFF00,
                )
                return False

            elif cmd[0] == "bb":
                room.kickPlayer(player.id, "Goodbye!")
                return False

            elif cmd[0] == "afk":
                room.setPlayerTeam(player.id, Team.SPECTATORS)
                return False

        return True  # Return True to send the message, False to block it

    def on_team_change(player, by_player):
        team_names = {Team.SPECTATORS: "Spectators", Team.RED: "Red", Team.BLUE: "Blue"}
        print(f"[TEAM] {player.name} moved to {team_names[player.team]}")

    def on_game_start(by_player):
        print("[GAME] Game started!")

    def on_game_stop(by_player):
        print("[GAME] Game stopped!")

    def on_goal(team: Team):
        team_name = "Red" if team == Team.RED else "Blue"
        print(f"[GOAL] {team_name} team scored!")

    def on_victory(scores):
        winner = "Red" if scores.red > scores.blue else "Blue"
        print(f"[VICTORY] {winner} team wins! ({scores.red} - {scores.blue})")

    # Set event handlers
    room.onRoomLink = on_room_link
    room.onPlayerJoin = on_player_join
    room.onPlayerLeave = on_player_leave
    room.onPlayerChat = on_player_chat
    room.onPlayerTeamChange = on_team_change
    room.onGameStart = on_game_start
    room.onGameStop = on_game_stop
    room.onTeamGoal = on_goal
    room.onTeamVictory = on_victory

    # Room settings
    room.setScoreLimit(3)
    room.setTimeLimit(5)
    room.setDefaultStadium("Classic")

    print("Room is running. Press Ctrl+C to stop.")

    try:
        await room.run_forever()
    except KeyboardInterrupt:
        print("\nShutting down...")
    finally:
        await room.close()


if __name__ == "__main__":
    asyncio.run(main())
