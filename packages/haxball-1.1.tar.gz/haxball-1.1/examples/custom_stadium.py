"""
Custom stadium example for haxball.py

This example shows how to create and use custom stadiums.
"""

import asyncio
import os
import json
from haxball import HaxballClient, Team


# Define some custom stadiums
STADIUMS = {
    "penalty": {
        "name": "Penalty Shootout",
        "width": 420,
        "height": 200,
        "spawnDistance": 300,
        "bg": {"type": "grass", "width": 370, "height": 170, "kickOffRadius": 0},
        "vertexes": [
            {"x": -370, "y": 64, "trait": "goalPost"},
            {"x": -370, "y": -64, "trait": "goalPost"},
            {"x": 370, "y": 64, "trait": "goalPost"},
            {"x": 370, "y": -64, "trait": "goalPost"},
            {"x": -370, "y": 200, "trait": "line"},
            {"x": -370, "y": -200, "trait": "line"},
            {"x": 370, "y": 200, "trait": "line"},
            {"x": 370, "y": -200, "trait": "line"},
        ],
        "segments": [
            {"v0": 0, "v1": 1, "trait": "goalPost"},
            {"v0": 2, "v1": 3, "trait": "goalPost"},
        ],
        "goals": [
            {"p0": [-370, -64], "p1": [-370, 64], "team": "red"},
            {"p0": [370, -64], "p1": [370, 64], "team": "blue"},
        ],
        "discs": [],
        "planes": [
            {"normal": [0, 1], "dist": -170, "trait": "ballArea"},
            {"normal": [0, -1], "dist": -170, "trait": "ballArea"},
            {"normal": [1, 0], "dist": -400, "trait": "ballArea"},
            {"normal": [-1, 0], "dist": -400, "trait": "ballArea"},
        ],
        "playerPhysics": {"acceleration": 0.1, "kickingAcceleration": 0.07},
        "traits": {
            "ballArea": {"vis": False, "bCoef": 1, "cMask": ["ball"]},
            "goalPost": {
                "radius": 8,
                "invMass": 0,
                "bCoef": 0.5,
                "cGroup": ["wall", "kick"],
            },
            "line": {"vis": True, "bCoef": 0, "cMask": []},
        },
    },
    "tiny": {
        "name": "Tiny Arena",
        "width": 300,
        "height": 150,
        "spawnDistance": 100,
        "bg": {"type": "grass", "width": 270, "height": 120, "kickOffRadius": 40},
        "vertexes": [
            {"x": -270, "y": 50, "trait": "goalPost"},
            {"x": -270, "y": -50, "trait": "goalPost"},
            {"x": 270, "y": 50, "trait": "goalPost"},
            {"x": 270, "y": -50, "trait": "goalPost"},
            {"x": -270, "y": 120, "trait": "line"},
            {"x": -270, "y": 50, "trait": "line"},
            {"x": -270, "y": -50, "trait": "line"},
            {"x": -270, "y": -120, "trait": "line"},
            {"x": 270, "y": 120, "trait": "line"},
            {"x": 270, "y": 50, "trait": "line"},
            {"x": 270, "y": -50, "trait": "line"},
            {"x": 270, "y": -120, "trait": "line"},
        ],
        "segments": [
            {"v0": 0, "v1": 1, "trait": "goalPost"},
            {"v0": 2, "v1": 3, "trait": "goalPost"},
            {"v0": 4, "v1": 5, "trait": "line", "color": "C7E6BD"},
            {"v0": 6, "v1": 7, "trait": "line", "color": "C7E6BD"},
            {"v0": 8, "v1": 9, "trait": "line", "color": "C7E6BD"},
            {"v0": 10, "v1": 11, "trait": "line", "color": "C7E6BD"},
        ],
        "goals": [
            {"p0": [-270, -50], "p1": [-270, 50], "team": "red"},
            {"p0": [270, -50], "p1": [270, 50], "team": "blue"},
        ],
        "discs": [],
        "planes": [
            {"normal": [0, 1], "dist": -120, "trait": "ballArea"},
            {"normal": [0, -1], "dist": -120, "trait": "ballArea"},
            {"normal": [1, 0], "dist": -300, "trait": "ballArea"},
            {"normal": [-1, 0], "dist": -300, "trait": "ballArea"},
        ],
        "traits": {
            "ballArea": {"vis": False, "bCoef": 1, "cMask": ["ball"]},
            "goalPost": {
                "radius": 6,
                "invMass": 0,
                "bCoef": 0.5,
                "cGroup": ["wall", "kick"],
            },
            "line": {"vis": True, "bCoef": 0, "cMask": []},
        },
    },
    "futsal": {
        "name": "Futsal Court",
        "width": 560,
        "height": 270,
        "spawnDistance": 200,
        "bg": {
            "type": "hockey",
            "width": 500,
            "height": 230,
            "kickOffRadius": 60,
            "cornerRadius": 0,
        },
        "vertexes": [
            {"x": -500, "y": 80, "trait": "goalPost", "color": "FF0000"},
            {"x": -500, "y": -80, "trait": "goalPost", "color": "FF0000"},
            {"x": 500, "y": 80, "trait": "goalPost", "color": "0000FF"},
            {"x": 500, "y": -80, "trait": "goalPost", "color": "0000FF"},
        ],
        "segments": [
            {"v0": 0, "v1": 1, "trait": "goalPost", "color": "FF0000"},
            {"v0": 2, "v1": 3, "trait": "goalPost", "color": "0000FF"},
        ],
        "goals": [
            {"p0": [-500, -80], "p1": [-500, 80], "team": "red"},
            {"p0": [500, -80], "p1": [500, 80], "team": "blue"},
        ],
        "discs": [],
        "planes": [
            {"normal": [0, 1], "dist": -230, "trait": "ballArea"},
            {"normal": [0, -1], "dist": -230, "trait": "ballArea"},
            {"normal": [1, 0], "dist": -500, "bCoef": 1, "trait": "ballArea"},
            {"normal": [-1, 0], "dist": -500, "bCoef": 1, "trait": "ballArea"},
        ],
        "ballPhysics": {"radius": 8, "bCoef": 0.5, "invMass": 1.5, "damping": 0.96},
        "traits": {
            "ballArea": {"vis": False, "bCoef": 1, "cMask": ["ball"]},
            "goalPost": {
                "radius": 10,
                "invMass": 0,
                "bCoef": 1,
                "cGroup": ["wall", "kick"],
            },
        },
    },
}


async def main():
    token = os.environ.get("HAXBALL_TOKEN")
    if not token:
        print("Please set HAXBALL_TOKEN environment variable")
        return

    client = HaxballClient()
    room = await client.create_room(
        roomName="Custom Stadiums",
        maxPlayers=12,
        public=False,
        token=token,
    )

    current_stadium = "classic"

    def on_room_link(link: str):
        print(f"Room link: {link}")

    def on_player_join(player):
        room.sendAnnouncement(
            f"Welcome! Use !map <name> to change stadium",
            targetId=player.id,
            color=0x00FF00,
        )
        room.sendAnnouncement(
            f"Available: penalty, tiny, futsal, classic",
            targetId=player.id,
            color=0xFFFF00,
        )

    def on_player_chat(player, message: str) -> bool:
        nonlocal current_stadium

        if not message.startswith("!"):
            return True

        parts = message[1:].lower().split()
        if not parts:
            return False

        cmd = parts[0]
        args = parts[1:]

        if cmd == "map" or cmd == "stadium":
            if not args:
                room.sendAnnouncement(
                    f"Current: {current_stadium} | Available: penalty, tiny, futsal, classic",
                    targetId=player.id,
                    color=0xFFFF00,
                )
                return False

            map_name = args[0]

            if map_name == "classic":
                room.setDefaultStadium("Classic")
                current_stadium = "classic"
                room.sendAnnouncement("Changed to Classic stadium!", color=0x00FF00)

            elif map_name in STADIUMS:
                stadium_json = json.dumps(STADIUMS[map_name])
                room.setCustomStadium(stadium_json)
                current_stadium = map_name
                room.sendAnnouncement(
                    f"Changed to {STADIUMS[map_name]['name']}!",
                    color=0x00FF00,
                )
            else:
                room.sendAnnouncement(
                    f"Unknown map: {map_name}",
                    targetId=player.id,
                    color=0xFF0000,
                )

        elif cmd == "help":
            room.sendAnnouncement(
                "Commands: !map <name> - Change stadium",
                targetId=player.id,
                color=0xFFFF00,
            )
            room.sendAnnouncement(
                "Maps: penalty, tiny, futsal, classic",
                targetId=player.id,
                color=0xFFFF00,
            )

        return False

    room.onRoomLink = on_room_link
    room.onPlayerJoin = on_player_join
    room.onPlayerChat = on_player_chat

    room.setScoreLimit(3)
    room.setTimeLimit(5)

    print("Custom stadium bot is running!")

    try:
        await room.run_forever()
    except KeyboardInterrupt:
        print("\nShutting down...")
    finally:
        await room.close()


if __name__ == "__main__":
    asyncio.run(main())
