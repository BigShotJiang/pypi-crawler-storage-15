"""
Tournament bot example for haxball.py

This bot manages knockout tournaments with bracket tracking.
"""

import asyncio
import os
import random
from dataclasses import dataclass
from haxball import HaxballClient, Team, PlayerObject


@dataclass
class Match:
    """A tournament match"""
    id: int
    player1: str  # auth
    player2: str  # auth
    player1_name: str
    player2_name: str
    score1: int = 0
    score2: int = 0
    winner: str | None = None
    round_num: int = 1


class TournamentBot:
    """Bot for managing tournaments"""

    def __init__(self, room):
        self.room = room
        self.participants: list[tuple[str, str]] = []  # (auth, name)
        self.matches: list[Match] = []
        self.current_match: Match | None = None
        self.tournament_active = False
        self.registration_open = False
        self.match_counter = 0
        self.games_to_win = 2  # Best of 3

        self._setup_handlers()

    def _setup_handlers(self):
        def on_room_link(link: str):
            print(f"Room link: {link}")

        def on_player_join(player: PlayerObject):
            if self.registration_open:
                msg = "Tournament registration open! Type !join to participate."
            else:
                msg = "Welcome! Wait for tournament registration."

            self.room.sendAnnouncement(
                msg, targetId=player.id, color=0x00FF00
            )

        def on_player_chat(player: PlayerObject, message: str) -> bool:
            if message.startswith("!"):
                self._handle_command(player, message[1:])
                return False
            return True

        def on_team_victory(scores):
            if not self.current_match:
                return

            # Determine winner
            if scores.red > scores.blue:
                self.current_match.score1 += 1
            else:
                self.current_match.score2 += 1

            self.room.sendAnnouncement(
                f"Match {self.current_match.id}: {self.current_match.player1_name} "
                f"{self.current_match.score1} - {self.current_match.score2} "
                f"{self.current_match.player2_name}",
                color=0xFFFF00,
                style="bold",
            )

            # Check if match is decided
            if self.current_match.score1 >= self.games_to_win:
                self.current_match.winner = self.current_match.player1
                self._match_end(self.current_match.player1_name)
            elif self.current_match.score2 >= self.games_to_win:
                self.current_match.winner = self.current_match.player2
                self._match_end(self.current_match.player2_name)

        self.room.onRoomLink = on_room_link
        self.room.onPlayerJoin = on_player_join
        self.room.onPlayerChat = on_player_chat
        self.room.onTeamVictory = on_team_victory

    def _handle_command(self, player: PlayerObject, cmd_str: str):
        parts = cmd_str.lower().split()
        if not parts:
            return

        cmd = parts[0]
        args = parts[1:]

        if cmd == "help":
            self._cmd_help(player)
        elif cmd == "join":
            self._cmd_join(player)
        elif cmd == "leave":
            self._cmd_leave(player)
        elif cmd == "bracket" or cmd == "b":
            self._cmd_bracket(player)
        elif cmd == "score":
            self._cmd_score(player)

        # Admin commands
        elif player.admin:
            if cmd == "openreg":
                self._cmd_open_registration()
            elif cmd == "closereg":
                self._cmd_close_registration()
            elif cmd == "start":
                self._cmd_start_tournament()
            elif cmd == "next":
                self._cmd_next_match()
            elif cmd == "reset":
                self._cmd_reset()

    def _cmd_help(self, player: PlayerObject):
        msg = """Tournament Commands:
!join - Join tournament
!leave - Leave tournament
!bracket - Show bracket
!score - Current match score

Admin Commands:
!openreg - Open registration
!closereg - Close registration
!start - Start tournament
!next - Start next match
!reset - Reset tournament"""
        self.room.sendAnnouncement(msg, targetId=player.id, color=0xFFFF00)

    def _cmd_join(self, player: PlayerObject):
        if not self.registration_open:
            self.room.sendAnnouncement(
                "Registration is not open!",
                targetId=player.id,
                color=0xFF0000,
            )
            return

        if any(p[0] == player.auth for p in self.participants):
            self.room.sendAnnouncement(
                "You're already registered!",
                targetId=player.id,
                color=0xFF0000,
            )
            return

        self.participants.append((player.auth, player.name))
        self.room.sendAnnouncement(
            f"{player.name} joined the tournament! ({len(self.participants)} players)",
            color=0x00FF00,
        )

    def _cmd_leave(self, player: PlayerObject):
        for i, (auth, name) in enumerate(self.participants):
            if auth == player.auth:
                self.participants.pop(i)
                self.room.sendAnnouncement(
                    f"{player.name} left the tournament.",
                    color=0xFF6600,
                )
                return

        self.room.sendAnnouncement(
            "You're not registered!",
            targetId=player.id,
            color=0xFF0000,
        )

    def _cmd_bracket(self, player: PlayerObject):
        if not self.matches:
            self.room.sendAnnouncement(
                "Tournament hasn't started yet!",
                targetId=player.id,
                color=0xFF0000,
            )
            return

        lines = ["BRACKET:"]
        for match in self.matches:
            status = ""
            if match.winner:
                winner_name = match.player1_name if match.winner == match.player1 else match.player2_name
                status = f"Winner: {winner_name}"
            elif match == self.current_match:
                status = f"({match.score1}-{match.score2}) LIVE"
            else:
                status = "Pending"

            lines.append(
                f"R{match.round_num} M{match.id}: {match.player1_name} vs {match.player2_name} - {status}"
            )

        self.room.sendAnnouncement(
            "\n".join(lines),
            targetId=player.id,
            color=0x00FFFF,
        )

    def _cmd_score(self, player: PlayerObject):
        if not self.current_match:
            self.room.sendAnnouncement(
                "No match in progress!",
                targetId=player.id,
                color=0xFF0000,
            )
            return

        self.room.sendAnnouncement(
            f"Match {self.current_match.id}: "
            f"{self.current_match.player1_name} {self.current_match.score1} - "
            f"{self.current_match.score2} {self.current_match.player2_name}",
            color=0xFFFF00,
        )

    def _cmd_open_registration(self):
        if self.tournament_active:
            self.room.sendAnnouncement(
                "Tournament is already in progress!",
                color=0xFF0000,
            )
            return

        self.registration_open = True
        self.participants.clear()
        self.room.sendAnnouncement(
            "TOURNAMENT REGISTRATION IS NOW OPEN!",
            color=0x00FF00,
            style="bold",
        )
        self.room.sendAnnouncement(
            "Type !join to participate!",
            color=0xFFFF00,
        )

    def _cmd_close_registration(self):
        self.registration_open = False
        self.room.sendAnnouncement(
            f"Registration closed! {len(self.participants)} participants.",
            color=0xFFFF00,
        )

    def _cmd_start_tournament(self):
        if self.tournament_active:
            self.room.sendAnnouncement("Tournament already started!", color=0xFF0000)
            return

        if len(self.participants) < 2:
            self.room.sendAnnouncement(
                "Need at least 2 participants!",
                color=0xFF0000,
            )
            return

        self.registration_open = False
        self.tournament_active = True
        self.matches.clear()
        self.match_counter = 0

        # Shuffle participants
        random.shuffle(self.participants)

        # Create first round matches
        self._create_round(1)

        self.room.sendAnnouncement(
            f"TOURNAMENT STARTED! {len(self.participants)} players, "
            f"{len(self.matches)} matches.",
            color=0x00FF00,
            style="bold",
        )

        # Show bracket
        self._show_bracket()

    def _create_round(self, round_num: int):
        """Create matches for a round"""
        # Get players for this round
        if round_num == 1:
            players = list(self.participants)
        else:
            # Get winners from previous round
            prev_round_matches = [m for m in self.matches if m.round_num == round_num - 1]
            players = [
                (m.winner, m.player1_name if m.winner == m.player1 else m.player2_name)
                for m in prev_round_matches if m.winner
            ]

        # Create matches
        for i in range(0, len(players), 2):
            if i + 1 < len(players):
                self.match_counter += 1
                match = Match(
                    id=self.match_counter,
                    player1=players[i][0],
                    player2=players[i + 1][0],
                    player1_name=players[i][1],
                    player2_name=players[i + 1][1],
                    round_num=round_num,
                )
                self.matches.append(match)
            else:
                # Bye - auto advance
                auth, name = players[i]
                self.match_counter += 1
                match = Match(
                    id=self.match_counter,
                    player1=auth,
                    player2="BYE",
                    player1_name=name,
                    player2_name="BYE",
                    winner=auth,
                    round_num=round_num,
                )
                self.matches.append(match)
                self.room.sendAnnouncement(
                    f"{name} advances (bye)",
                    color=0xFFFF00,
                )

    def _cmd_next_match(self):
        """Start the next match"""
        if not self.tournament_active:
            self.room.sendAnnouncement("Tournament not active!", color=0xFF0000)
            return

        # Find next unplayed match
        for match in self.matches:
            if not match.winner and match.player2 != "BYE":
                self.current_match = match
                self._setup_match(match)
                return

        # Check if we need to create next round
        current_round = max(m.round_num for m in self.matches)
        round_matches = [m for m in self.matches if m.round_num == current_round]
        all_done = all(m.winner for m in round_matches)

        if all_done:
            winners = [m.winner for m in round_matches if m.winner]
            if len(winners) > 1:
                self._create_round(current_round + 1)
                self._cmd_next_match()  # Start next match
            elif len(winners) == 1:
                # Tournament over
                winner_name = [m.player1_name if m.winner == m.player1 else m.player2_name
                              for m in round_matches if m.winner][0]
                self.room.sendAnnouncement(
                    f"TOURNAMENT WINNER: {winner_name}!",
                    color=0x00FF00,
                    style="bold",
                    sound=2,
                )
                self.tournament_active = False
        else:
            self.room.sendAnnouncement(
                "Current match not finished yet!",
                color=0xFF0000,
            )

    def _setup_match(self, match: Match):
        """Setup players for match"""
        # Move everyone to spectators
        for p in self.room.getPlayerList():
            self.room.setPlayerTeam(p.id, Team.SPECTATORS)

        # Find and place players
        for p in self.room.getPlayerList():
            if p.auth == match.player1:
                self.room.setPlayerTeam(p.id, Team.RED)
            elif p.auth == match.player2:
                self.room.setPlayerTeam(p.id, Team.BLUE)

        self.room.sendAnnouncement(
            f"MATCH {match.id}: {match.player1_name} vs {match.player2_name}",
            color=0xFFFF00,
            style="bold",
        )
        self.room.sendAnnouncement(
            f"Best of {self.games_to_win * 2 - 1} - First to {self.games_to_win} wins!",
            color=0xFFFF00,
        )

    def _match_end(self, winner_name: str):
        """Handle match end"""
        self.room.sendAnnouncement(
            f"{winner_name} WINS THE MATCH!",
            color=0x00FF00,
            style="bold",
        )
        self.current_match = None

        # Check if tournament continues
        asyncio.get_event_loop().call_later(
            3.0, lambda: self.room.sendAnnouncement(
                "Admin: Use !next to start next match",
                color=0xFFFF00,
            )
        )

    def _show_bracket(self):
        """Show current bracket"""
        for match in self.matches:
            self.room.sendAnnouncement(
                f"M{match.id}: {match.player1_name} vs {match.player2_name}",
                color=0x00FFFF,
            )

    def _cmd_reset(self):
        """Reset tournament"""
        self.tournament_active = False
        self.registration_open = False
        self.matches.clear()
        self.participants.clear()
        self.current_match = None
        self.match_counter = 0

        self.room.sendAnnouncement(
            "Tournament has been reset.",
            color=0xFF6600,
        )


async def main():
    token = os.environ.get("HAXBALL_TOKEN")
    if not token:
        print("Please set HAXBALL_TOKEN environment variable")
        return

    client = HaxballClient()
    room = await client.create_room(
        roomName="Tournament Room",
        maxPlayers=16,
        public=False,
        token=token,
    )

    bot = TournamentBot(room)

    room.setScoreLimit(3)
    room.setTimeLimit(5)
    room.setDefaultStadium("Classic")

    print("Tournament bot is running!")

    try:
        await room.run_forever()
    except KeyboardInterrupt:
        print("\nShutting down...")
    finally:
        await room.close()


if __name__ == "__main__":
    asyncio.run(main())
