"""
Stats tracking bot example for haxball.py

This bot tracks player statistics like goals, assists, wins, and more.
Stats persist in memory during the session (can be extended to use a database).
"""

import asyncio
import os
import time
from dataclasses import dataclass, field
from haxball import HaxballClient, Team, PlayerObject


@dataclass
class PlayerStats:
    """Statistics for a single player"""
    name: str
    auth: str
    goals: int = 0
    assists: int = 0
    own_goals: int = 0
    wins: int = 0
    losses: int = 0
    games_played: int = 0
    kicks: int = 0
    time_played: float = 0.0  # seconds

    @property
    def win_rate(self) -> float:
        if self.games_played == 0:
            return 0.0
        return (self.wins / self.games_played) * 100

    @property
    def goals_per_game(self) -> float:
        if self.games_played == 0:
            return 0.0
        return self.goals / self.games_played


class StatsBot:
    """Bot that tracks player statistics"""

    def __init__(self, room):
        self.room = room
        self.stats: dict[str, PlayerStats] = {}  # auth -> stats
        self.game_start_time: float | None = None
        self.last_kicker: int | None = None  # For assist tracking
        self.players_in_game: dict[int, Team] = {}  # player_id -> team at game start

        self._setup_handlers()

    def _setup_handlers(self):
        def on_room_link(link: str):
            print(f"Room link: {link}")

        def on_player_join(player: PlayerObject):
            # Initialize or retrieve stats
            if player.auth not in self.stats:
                self.stats[player.auth] = PlayerStats(
                    name=player.name,
                    auth=player.auth,
                )
            else:
                # Update name in case they changed it
                self.stats[player.auth].name = player.name

            self.room.sendAnnouncement(
                f"Welcome back {player.name}! Type !stats to see your stats.",
                targetId=player.id,
                color=0x00FF00,
            )

        def on_player_chat(player: PlayerObject, message: str) -> bool:
            if message.startswith("!"):
                self._handle_command(player, message[1:])
                return False
            return True

        def on_player_ball_kick(player: PlayerObject):
            # Track kicks
            if player.auth in self.stats:
                self.stats[player.auth].kicks += 1

            # Track last kicker for assists
            self.last_kicker = player.id

        def on_game_start(_):
            self.game_start_time = time.time()
            self.last_kicker = None

            # Store players in game
            self.players_in_game.clear()
            for p in self.room.getPlayerList():
                if p.team != Team.SPECTATORS:
                    self.players_in_game[p.id] = p.team

        def on_team_goal(team: Team):
            # Find scorer (closest to ball or last kicker)
            scorer_id = self.last_kicker

            if scorer_id:
                scorer = self.room.getPlayer(scorer_id)
                if scorer and scorer.auth in self.stats:
                    if scorer.team == team:
                        self.stats[scorer.auth].goals += 1
                        self.room.sendAnnouncement(
                            f"Goal by {scorer.name}!",
                            color=0xFFFF00,
                        )
                    else:
                        # Own goal
                        self.stats[scorer.auth].own_goals += 1
                        self.room.sendAnnouncement(
                            f"Own goal by {scorer.name}!",
                            color=0xFF6600,
                        )

            self.last_kicker = None

        def on_team_victory(scores):
            if self.game_start_time is None:
                return

            game_duration = time.time() - self.game_start_time
            winner = Team.RED if scores.red > scores.blue else Team.BLUE

            # Update stats for all players who were in the game
            for player_id, team in self.players_in_game.items():
                player = self.room.getPlayer(player_id)
                if player and player.auth in self.stats:
                    stats = self.stats[player.auth]
                    stats.games_played += 1
                    stats.time_played += game_duration

                    if team == winner:
                        stats.wins += 1
                    else:
                        stats.losses += 1

            self.game_start_time = None
            self.players_in_game.clear()

        def on_game_stop(_):
            self.game_start_time = None
            self.last_kicker = None

        self.room.onRoomLink = on_room_link
        self.room.onPlayerJoin = on_player_join
        self.room.onPlayerChat = on_player_chat
        self.room.onPlayerBallKick = on_player_ball_kick
        self.room.onGameStart = on_game_start
        self.room.onTeamGoal = on_team_goal
        self.room.onTeamVictory = on_team_victory
        self.room.onGameStop = on_game_stop

    def _handle_command(self, player: PlayerObject, cmd_str: str):
        parts = cmd_str.lower().split()
        if not parts:
            return

        cmd = parts[0]
        args = parts[1:]

        if cmd == "help":
            self._cmd_help(player)
        elif cmd == "stats" or cmd == "s":
            self._cmd_stats(player, args)
        elif cmd == "top" or cmd == "leaderboard" or cmd == "lb":
            self._cmd_top(player, args)
        elif cmd == "goals":
            self._cmd_top_goals(player)
        elif cmd == "wins":
            self._cmd_top_wins(player)

    def _cmd_help(self, player: PlayerObject):
        msg = """Commands:
!stats - Your stats
!stats <name> - Player stats
!top [goals|wins] - Leaderboard
!goals - Top scorers
!wins - Top winners"""
        self.room.sendAnnouncement(msg, targetId=player.id, color=0xFFFF00)

    def _cmd_stats(self, player: PlayerObject, args: list[str]):
        if args:
            # Find player by name
            target_name = " ".join(args).lower()
            target_stats = None
            for stats in self.stats.values():
                if target_name in stats.name.lower():
                    target_stats = stats
                    break

            if not target_stats:
                self.room.sendAnnouncement(
                    f"Player '{target_name}' not found",
                    targetId=player.id,
                    color=0xFF0000,
                )
                return
        else:
            target_stats = self.stats.get(player.auth)

        if not target_stats:
            self.room.sendAnnouncement(
                "No stats recorded yet!",
                targetId=player.id,
                color=0xFF0000,
            )
            return

        minutes = int(target_stats.time_played // 60)
        msg = f"""Stats for {target_stats.name}:
Goals: {target_stats.goals} | OG: {target_stats.own_goals}
W/L: {target_stats.wins}/{target_stats.losses} ({target_stats.win_rate:.1f}%)
Games: {target_stats.games_played} | Kicks: {target_stats.kicks}
Time: {minutes} min"""

        self.room.sendAnnouncement(msg, targetId=player.id, color=0x00FFFF)

    def _cmd_top(self, player: PlayerObject, args: list[str]):
        if args and args[0] == "goals":
            self._cmd_top_goals(player)
        elif args and args[0] == "wins":
            self._cmd_top_wins(player)
        else:
            self._cmd_top_goals(player)

    def _cmd_top_goals(self, player: PlayerObject):
        sorted_stats = sorted(
            self.stats.values(),
            key=lambda s: s.goals,
            reverse=True
        )[:5]

        if not sorted_stats:
            self.room.sendAnnouncement(
                "No stats recorded yet!",
                targetId=player.id,
                color=0xFF0000,
            )
            return

        lines = ["Top Scorers:"]
        for i, stats in enumerate(sorted_stats, 1):
            lines.append(f"{i}. {stats.name}: {stats.goals} goals")

        self.room.sendAnnouncement(
            "\n".join(lines),
            targetId=player.id,
            color=0xFFFF00,
        )

    def _cmd_top_wins(self, player: PlayerObject):
        sorted_stats = sorted(
            self.stats.values(),
            key=lambda s: s.wins,
            reverse=True
        )[:5]

        if not sorted_stats:
            self.room.sendAnnouncement(
                "No stats recorded yet!",
                targetId=player.id,
                color=0xFF0000,
            )
            return

        lines = ["Top Winners:"]
        for i, stats in enumerate(sorted_stats, 1):
            lines.append(f"{i}. {stats.name}: {stats.wins} wins ({stats.win_rate:.0f}%)")

        self.room.sendAnnouncement(
            "\n".join(lines),
            targetId=player.id,
            color=0xFFFF00,
        )


async def main():
    token = os.environ.get("HAXBALL_TOKEN")
    if not token:
        print("Please set HAXBALL_TOKEN environment variable")
        return

    client = HaxballClient()
    room = await client.create_room(
        roomName="Stats Tracker Room",
        maxPlayers=16,
        public=False,
        token=token,
    )

    bot = StatsBot(room)

    room.setScoreLimit(3)
    room.setTimeLimit(5)
    room.setDefaultStadium("Classic")

    print("Stats bot is running!")

    try:
        await room.run_forever()
    except KeyboardInterrupt:
        print("\nShutting down...")
    finally:
        await room.close()


if __name__ == "__main__":
    asyncio.run(main())
