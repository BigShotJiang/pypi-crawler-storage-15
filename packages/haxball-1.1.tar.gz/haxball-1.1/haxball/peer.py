"""WebRTC peer connection management"""

import asyncio
import logging
from typing import Optional, Callable, Any

from aiortc import RTCPeerConnection, RTCSessionDescription, RTCIceCandidate, RTCDataChannel
from aiortc.sdp import candidate_from_sdp

from .buffer import BufferReader, BufferWriter

logger = logging.getLogger(__name__)


class DataChannelConfig:
    """Data channel configuration"""

    RELIABLE = {
        "name": "reliable",
        "ordered": True,
        "negotiated": True,
        "id": 0,
    }

    UNRELIABLE = {
        "name": "unreliable",
        "ordered": False,
        "negotiated": True,
        "id": 1,
        "maxRetransmits": 0,
    }


class PeerConnection:
    """WebRTC peer connection wrapper"""

    ICE_SERVERS = [
        {"urls": "stun:stun.l.google.com:19302"},
        {"urls": "stun:global.stun.twilio.com:3478"},
    ]

    def __init__(self, peer_id: int, conn_id: str):
        self.peer_id = peer_id
        self.conn_id = conn_id
        self._pc: Optional[RTCPeerConnection] = None
        self._reliable_channel: Optional[RTCDataChannel] = None
        self._unreliable_channel: Optional[RTCDataChannel] = None
        self._connected = False
        self._last_activity = 0
        self._ice_candidates: list[dict] = []
        self._local_candidates: list[dict] = []

        # Callbacks
        self.on_message: Optional[Callable[[bytes, bool], None]] = None
        self.on_connected: Optional[Callable[[], None]] = None
        self.on_disconnected: Optional[Callable[[], None]] = None
        self.on_ice_candidate: Optional[Callable[[dict], None]] = None

    async def create(self):
        """Create RTCPeerConnection"""
        config = {
            "iceServers": self.ICE_SERVERS,
        }
        self._pc = RTCPeerConnection(configuration=config)

        # Create data channels
        self._reliable_channel = self._pc.createDataChannel(
            DataChannelConfig.RELIABLE["name"],
            ordered=DataChannelConfig.RELIABLE["ordered"],
            negotiated=DataChannelConfig.RELIABLE["negotiated"],
            id=DataChannelConfig.RELIABLE["id"],
        )

        self._unreliable_channel = self._pc.createDataChannel(
            DataChannelConfig.UNRELIABLE["name"],
            ordered=DataChannelConfig.UNRELIABLE["ordered"],
            negotiated=DataChannelConfig.UNRELIABLE["negotiated"],
            id=DataChannelConfig.UNRELIABLE["id"],
            maxRetransmits=DataChannelConfig.UNRELIABLE["maxRetransmits"],
        )

        self._setup_channel_handlers(self._reliable_channel, True)
        self._setup_channel_handlers(self._unreliable_channel, False)

        @self._pc.on("icecandidate")
        async def on_ice_candidate(candidate):
            if candidate:
                self._local_candidates.append({
                    "candidate": candidate.candidate,
                    "sdpMid": candidate.sdpMid,
                    "sdpMLineIndex": candidate.sdpMLineIndex,
                })
                if self.on_ice_candidate:
                    self.on_ice_candidate({
                        "candidate": candidate.candidate,
                        "sdpMid": candidate.sdpMid,
                        "sdpMLineIndex": candidate.sdpMLineIndex,
                    })

        @self._pc.on("connectionstatechange")
        async def on_connection_state_change():
            state = self._pc.connectionState
            logger.debug(f"Peer {self.peer_id} connection state: {state}")

            if state == "connected":
                self._connected = True
            elif state in ("disconnected", "failed", "closed"):
                await self._handle_disconnect()

        @self._pc.on("iceconnectionstatechange")
        async def on_ice_state_change():
            state = self._pc.iceConnectionState
            logger.debug(f"Peer {self.peer_id} ICE state: {state}")

            if state in ("disconnected", "failed", "closed"):
                await self._handle_disconnect()

    def _setup_channel_handlers(self, channel: RTCDataChannel, reliable: bool):
        """Set up handlers for a data channel"""

        @channel.on("open")
        def on_open():
            logger.debug(f"Peer {self.peer_id} channel {'reliable' if reliable else 'unreliable'} opened")
            self._check_ready()

        @channel.on("close")
        def on_close():
            logger.debug(f"Peer {self.peer_id} channel closed")
            asyncio.create_task(self._handle_disconnect())

        @channel.on("message")
        def on_message(message):
            self._last_activity = asyncio.get_event_loop().time()
            if self.on_message:
                if isinstance(message, str):
                    message = message.encode()
                self.on_message(message, reliable)

    def _check_ready(self):
        """Check if both channels are ready"""
        if (self._reliable_channel and self._reliable_channel.readyState == "open" and
            self._unreliable_channel and self._unreliable_channel.readyState == "open"):
            if not self._connected:
                self._connected = True
                if self.on_connected:
                    self.on_connected()

    async def _handle_disconnect(self):
        """Handle disconnection"""
        if self._connected:
            self._connected = False
            if self.on_disconnected:
                self.on_disconnected()

    async def handle_offer(self, sdp: bytes, ice_candidates: list[dict]) -> tuple[str, list[dict]]:
        """Handle incoming SDP offer and return answer"""
        offer = RTCSessionDescription(sdp=sdp.decode(), type="offer")
        await self._pc.setRemoteDescription(offer)

        # Add ICE candidates
        for candidate_data in ice_candidates:
            try:
                await self.add_ice_candidate(candidate_data)
            except Exception as e:
                logger.debug(f"Failed to add ICE candidate: {e}")

        # Create answer
        answer = await self._pc.createAnswer()
        await self._pc.setLocalDescription(answer)

        # Wait for ICE gathering
        await self._wait_for_ice_gathering()

        return self._pc.localDescription.sdp, self._local_candidates

    async def _wait_for_ice_gathering(self, timeout: float = 2.0):
        """Wait for ICE gathering to complete"""
        if self._pc.iceGatheringState == "complete":
            return

        gathering_complete = asyncio.Event()

        @self._pc.on("icegatheringstatechange")
        async def on_gathering_state_change():
            if self._pc.iceGatheringState == "complete":
                gathering_complete.set()

        try:
            await asyncio.wait_for(gathering_complete.wait(), timeout)
        except asyncio.TimeoutError:
            pass

    async def add_ice_candidate(self, candidate_data: dict):
        """Add remote ICE candidate"""
        if not candidate_data or not candidate_data.get("candidate"):
            return

        try:
            candidate = RTCIceCandidate(
                candidate=candidate_data["candidate"],
                sdpMid=candidate_data.get("sdpMid"),
                sdpMLineIndex=candidate_data.get("sdpMLineIndex"),
            )
            await self._pc.addIceCandidate(candidate)
        except Exception as e:
            logger.debug(f"Failed to add ICE candidate: {e}")

    def send(self, data: bytes, reliable: bool = True):
        """Send data to peer"""
        if not self._connected:
            return

        channel = self._reliable_channel if reliable else self._unreliable_channel
        if channel and channel.readyState == "open":
            try:
                channel.send(data)
            except Exception as e:
                logger.error(f"Failed to send to peer {self.peer_id}: {e}")

    async def close(self):
        """Close peer connection"""
        self._connected = False

        if self._reliable_channel:
            self._reliable_channel.close()

        if self._unreliable_channel:
            self._unreliable_channel.close()

        if self._pc:
            await self._pc.close()

    @property
    def is_connected(self) -> bool:
        return self._connected


class PeerManager:
    """Manages multiple peer connections"""

    def __init__(self, max_peers: int = 30):
        self.max_peers = max_peers
        self._peers: dict[int, PeerConnection] = {}

        # Callbacks
        self.on_peer_message: Optional[Callable[[int, bytes, bool], None]] = None
        self.on_peer_connected: Optional[Callable[[int], None]] = None
        self.on_peer_disconnected: Optional[Callable[[int], None]] = None

    async def create_peer(self, peer_id: int, conn_id: str) -> Optional[PeerConnection]:
        """Create a new peer connection"""
        if len(self._peers) >= self.max_peers:
            logger.warning(f"Max peers ({self.max_peers}) reached")
            return None

        if peer_id in self._peers:
            await self.remove_peer(peer_id)

        peer = PeerConnection(peer_id, conn_id)
        await peer.create()

        peer.on_message = lambda data, reliable: self._handle_message(peer_id, data, reliable)
        peer.on_connected = lambda: self._handle_connected(peer_id)
        peer.on_disconnected = lambda: self._handle_disconnected(peer_id)

        self._peers[peer_id] = peer
        return peer

    def _handle_message(self, peer_id: int, data: bytes, reliable: bool):
        if self.on_peer_message:
            self.on_peer_message(peer_id, data, reliable)

    def _handle_connected(self, peer_id: int):
        logger.info(f"Peer {peer_id} connected")
        if self.on_peer_connected:
            self.on_peer_connected(peer_id)

    def _handle_disconnected(self, peer_id: int):
        logger.info(f"Peer {peer_id} disconnected")
        asyncio.create_task(self.remove_peer(peer_id))
        if self.on_peer_disconnected:
            self.on_peer_disconnected(peer_id)

    def get_peer(self, peer_id: int) -> Optional[PeerConnection]:
        return self._peers.get(peer_id)

    async def remove_peer(self, peer_id: int):
        """Remove peer connection"""
        peer = self._peers.pop(peer_id, None)
        if peer:
            await peer.close()

    def send_to_peer(self, peer_id: int, data: bytes, reliable: bool = True):
        """Send data to specific peer"""
        peer = self._peers.get(peer_id)
        if peer and peer.is_connected:
            peer.send(data, reliable)

    def broadcast(self, data: bytes, reliable: bool = True, exclude: Optional[set[int]] = None):
        """Broadcast data to all connected peers"""
        exclude = exclude or set()
        for peer_id, peer in self._peers.items():
            if peer_id not in exclude and peer.is_connected:
                peer.send(data, reliable)

    async def close_all(self):
        """Close all peer connections"""
        for peer_id in list(self._peers.keys()):
            await self.remove_peer(peer_id)

    @property
    def peer_count(self) -> int:
        return len(self._peers)

    @property
    def connected_peers(self) -> list[int]:
        return [pid for pid, p in self._peers.items() if p.is_connected]
