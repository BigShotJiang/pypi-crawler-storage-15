"""
Room management and game logic - Complete Implementation

This module provides the main Room class that implements all features
of the HaxBall Headless API.
"""

import asyncio
import logging
import time
import json
from typing import Optional, Callable, Any, Union

from .types import (
    Team, PlayerObject, RoomConfigObject, ScoresObject, Stadium,
    DiscPropertiesObject, GeoLocation, CollisionFlags, Vector2, TeamColors
)
from .buffer import BufferReader, BufferWriter
from .connection import GameServerConnection
from .peer import PeerManager, PeerConnection
from .game import GameState, GameRecorder

logger = logging.getLogger(__name__)


# Default stadiums
DEFAULT_STADIUMS = {
    "Classic": {"width": 420, "height": 200, "spawnDistance": 170},
    "Easy": {"width": 420, "height": 200, "spawnDistance": 170},
    "Small": {"width": 420, "height": 200, "spawnDistance": 170},
    "Big": {"width": 600, "height": 270, "spawnDistance": 170},
    "Rounded": {"width": 420, "height": 200, "spawnDistance": 170},
    "Hockey": {"width": 420, "height": 200, "spawnDistance": 170},
    "Big Hockey": {"width": 600, "height": 270, "spawnDistance": 170},
    "Big Easy": {"width": 600, "height": 270, "spawnDistance": 170},
    "Big Rounded": {"width": 600, "height": 270, "spawnDistance": 170},
    "Huge": {"width": 750, "height": 350, "spawnDistance": 170},
}


class Player:
    """Internal player representation"""

    def __init__(self, player_id: int, name: str):
        self.id = player_id
        self.name = name
        self.team = Team.SPECTATORS
        self.admin = False
        self.auth = ""
        self.conn = ""
        self.peer_id: Optional[int] = None
        self.disc_id: Optional[int] = None
        self.avatar: Optional[str] = None
        self.input = 0
        self.last_activity = time.time()
        self.kick_count = 0
        self.kick_rate_start = 0.0

    def to_object(self) -> PlayerObject:
        """Convert to public PlayerObject"""
        return PlayerObject(
            id=self.id,
            name=self.name,
            team=self.team,
            admin=self.admin,
            position=None,  # Will be filled by game state
            auth=self.auth,
            conn=self.conn,
        )


class Room:
    """
    HaxBall Room - Complete Implementation

    This class provides the full HaxBall Headless API for Python.

    Example:
        room = await create_room(
            roomName="My Room",
            maxPlayers=16,
            token="YOUR_TOKEN",
        )

        room.onPlayerJoin = lambda p: print(f"{p.name} joined!")
        room.onPlayerChat = lambda p, msg: print(f"{p.name}: {msg}")

        await room.run_forever()
    """

    # Message opcodes
    class Opcode:
        PLAYER_INFO = 1
        INPUT = 2
        CHAT = 3
        PLAYER_JOINED = 4
        PLAYER_LEFT = 5
        KICK = 6
        ANNOUNCEMENT = 7
        TEAM_CHANGE = 8
        ADMIN_CHANGE = 9
        GAME_START = 10
        GAME_STOP = 11
        GAME_PAUSE = 12
        STADIUM_CHANGE = 13
        SCORE_LIMIT = 14
        TIME_LIMIT = 15
        TEAMS_LOCK = 16
        SET_AVATAR = 17
        TEAM_COLORS = 18
        KICK_RATE = 19
        DISC_PROPS = 20
        GAME_STATE = 21
        SYNC = 22

    def __init__(self, config: RoomConfigObject):
        self.config = config
        self._connection: Optional[GameServerConnection] = None
        self._peer_manager: Optional[PeerManager] = None

        # Room state
        self._players: dict[int, Player] = {}
        self._next_player_id = 1
        self._room_link: Optional[str] = None
        self._password = config.password
        self._running = False
        self._closed = False

        # Game state
        self._stadium = self._get_default_stadium("Classic")
        self._stadium_name = "Classic"
        self._custom_stadium: Optional[Stadium] = None
        self._game = GameState(self._stadium)
        self._recorder = GameRecorder()
        self._score_limit = 3
        self._time_limit = 3
        self._teams_lock = False

        # Team colors
        self._red_colors = TeamColors(angle=0, textColor=0xFFFFFF, colors=[0xE56E56])
        self._blue_colors = TeamColors(angle=0, textColor=0xFFFFFF, colors=[0x5689E5])

        # Kick rate limiting
        self._kick_rate_min = 2
        self._kick_rate_rate = 0
        self._kick_rate_burst = 0

        # Recaptcha
        self._require_recaptcha = False

        # Game loop
        self._game_loop_task: Optional[asyncio.Task] = None
        self._last_tick = 0.0

        # --- Event Callbacks ---
        # All callbacks follow the official HaxBall API naming

        # Room events
        self.onRoomLink: Optional[Callable[[str], None]] = None

        # Player events
        self.onPlayerJoin: Optional[Callable[[PlayerObject], None]] = None
        self.onPlayerLeave: Optional[Callable[[PlayerObject], None]] = None
        self.onPlayerChat: Optional[Callable[[PlayerObject, str], Optional[bool]]] = None
        self.onPlayerBallKick: Optional[Callable[[PlayerObject], None]] = None
        self.onPlayerAdminChange: Optional[Callable[[PlayerObject, Optional[PlayerObject]], None]] = None
        self.onPlayerTeamChange: Optional[Callable[[PlayerObject, Optional[PlayerObject]], None]] = None
        self.onPlayerKicked: Optional[Callable[[PlayerObject, str, bool, Optional[PlayerObject]], None]] = None
        self.onPlayerActivity: Optional[Callable[[PlayerObject], None]] = None

        # Game events
        self.onGameStart: Optional[Callable[[Optional[PlayerObject]], None]] = None
        self.onGameStop: Optional[Callable[[Optional[PlayerObject]], None]] = None
        self.onGameTick: Optional[Callable[[], None]] = None
        self.onGamePause: Optional[Callable[[bool, Optional[PlayerObject]], None]] = None
        self.onGameUnpause: Optional[Callable[[Optional[PlayerObject]], None]] = None
        self.onPositionsReset: Optional[Callable[[], None]] = None
        self.onTeamGoal: Optional[Callable[[Team], None]] = None
        self.onTeamVictory: Optional[Callable[[ScoresObject], None]] = None

        # Settings events
        self.onStadiumChange: Optional[Callable[[str, Optional[PlayerObject]], None]] = None
        self.onKickRateLimitSet: Optional[Callable[[int, int, int, Optional[PlayerObject]], None]] = None
        self.onTeamsLockChange: Optional[Callable[[bool, Optional[PlayerObject]], None]] = None

    def _get_default_stadium(self, name: str) -> Stadium:
        """Get a default stadium by name"""
        if name not in DEFAULT_STADIUMS:
            name = "Classic"

        info = DEFAULT_STADIUMS[name]
        stadium = Stadium(
            name=name,
            width=info["width"],
            height=info["height"],
            spawnDistance=info["spawnDistance"],
        )
        return stadium

    # ==================== Connection Methods ====================

    async def _start(self) -> bool:
        """Start the room (internal)"""
        self._connection = GameServerConnection(
            token=self.config.token,
            proxy=self.config.proxy,
            debug=True,
        )

        self._peer_manager = PeerManager(max_peers=self.config.maxPlayers)

        # Connection callbacks
        self._connection.on_room_id = self._on_room_id
        self._connection.on_peer_connect = self._on_peer_connect
        self._connection.on_peer_ice_candidate = self._on_peer_ice_candidate
        self._connection.on_disconnect = self._on_disconnect

        # Peer manager callbacks
        self._peer_manager.on_peer_message = self._on_peer_message
        self._peer_manager.on_peer_connected = self._on_peer_connected
        self._peer_manager.on_peer_disconnected = self._on_peer_disconnected

        if not await self._connection.connect():
            return False

        self._running = True

        # Update room info
        await self._update_room_info()

        # Set visibility
        await self._connection.set_public(self.config.public)

        # Start game loop
        self._game_loop_task = asyncio.create_task(self._game_loop())

        return True

    async def _update_room_info(self):
        """Send room info to server"""
        if not self._connection:
            return

        writer = BufferWriter(little_endian=False)

        name = self.config.roomName[:40].encode("utf-8")
        writer.write_uint8(len(name))
        writer.write_bytes(name)

        writer.write_uint8(1 if self._password else 0)
        writer.write_uint8(len(self._players))
        writer.write_uint8(self.config.maxPlayers)

        if self.config.geo:
            writer.write_float32(self.config.geo.lat)
            writer.write_float32(self.config.geo.lon)
            code = self.config.geo.code[:3].encode("utf-8")
            writer.write_uint8(len(code))
            writer.write_bytes(code)

        await self._connection.update_room_info(writer.get_bytes())

    def _on_room_id(self, room_id: str):
        """Handle room ID from server"""
        self._room_link = f"https://www.haxball.com/play?c={room_id}"
        logger.info(f"Room link: {self._room_link}")

        if self.onRoomLink:
            self.onRoomLink(self._room_link)

    async def _on_peer_connect(self, peer_id: int, sdp: bytes, info: dict):
        """Handle new peer connection request"""
        conn_id = info.get("conn_id", "")
        ice_candidates = info.get("ice_candidates", [])

        # Check bans
        if self._connection and conn_id in self._connection._banned_conns:
            return

        peer = await self._peer_manager.create_peer(peer_id, conn_id)
        if not peer:
            return

        try:
            answer_sdp, local_candidates = await peer.handle_offer(sdp, ice_candidates)
            await self._connection.send_peer_answer(peer_id, answer_sdp, local_candidates)

            peer.on_ice_candidate = lambda c: asyncio.create_task(
                self._connection.send_ice_candidate(peer_id, c)
            )
        except Exception as e:
            logger.error(f"Peer connection failed: {e}")
            await self._peer_manager.remove_peer(peer_id)

    async def _on_peer_ice_candidate(self, peer_id: int, candidate: dict):
        """Handle ICE candidate"""
        peer = self._peer_manager.get_peer(peer_id)
        if peer:
            await peer.add_ice_candidate(candidate)

    def _on_disconnect(self):
        """Handle server disconnect"""
        logger.warning("Disconnected from server")
        self._running = False

    def _on_peer_message(self, peer_id: int, data: bytes, reliable: bool):
        """Handle message from peer"""
        if len(data) < 1:
            return

        reader = BufferReader(data, little_endian=False)
        opcode = reader.read_uint8()

        if opcode == self.Opcode.PLAYER_INFO:
            self._handle_player_info(peer_id, reader)
        elif opcode == self.Opcode.INPUT:
            self._handle_input(peer_id, reader)
        elif opcode == self.Opcode.CHAT:
            self._handle_chat(peer_id, reader)

    def _on_peer_connected(self, peer_id: int):
        """Peer fully connected"""
        pass

    def _on_peer_disconnected(self, peer_id: int):
        """Peer disconnected"""
        player = self._get_player_by_peer(peer_id)
        if player:
            self._remove_player(player.id)

    # ==================== Message Handlers ====================

    def _handle_player_info(self, peer_id: int, reader: BufferReader):
        """Handle player join info"""
        name = reader.read_string()[:25]
        auth = reader.read_string() if reader.remaining > 0 else ""

        player_id = self._next_player_id
        self._next_player_id += 1

        player = Player(player_id, name)
        player.auth = auth
        player.peer_id = peer_id

        peer = self._peer_manager.get_peer(peer_id)
        if peer:
            player.conn = peer.conn_id

        self._players[player_id] = player

        logger.info(f"Player joined: {name} (id={player_id})")

        # Send room state to new player
        self._send_room_state(peer_id)

        # Broadcast join
        self._broadcast_player_joined(player)

        # Update room info
        asyncio.create_task(self._update_room_info())

        # Callback
        if self.onPlayerJoin:
            self.onPlayerJoin(player.to_object())

    def _handle_input(self, peer_id: int, reader: BufferReader):
        """Handle player input"""
        player = self._get_player_by_peer(peer_id)
        if not player:
            return

        input_flags = reader.read_uint8()
        player.input = input_flags
        player.last_activity = time.time()

        # Update game state
        self._game.set_player_input(player.id, input_flags)

        # Activity callback
        if self.onPlayerActivity:
            self.onPlayerActivity(player.to_object())

    def _handle_chat(self, peer_id: int, reader: BufferReader):
        """Handle chat message"""
        player = self._get_player_by_peer(peer_id)
        if not player:
            return

        message = reader.read_string()[:140]
        player.last_activity = time.time()

        # Callback - can block message
        should_send = True
        if self.onPlayerChat:
            result = self.onPlayerChat(player.to_object(), message)
            if result is False:
                should_send = False

        if should_send:
            self._broadcast_chat(player.id, message)

    # ==================== Game Loop ====================

    async def _game_loop(self):
        """Main game loop - 60 FPS"""
        frame_time = 1/60

        while self._running:
            start = time.time()

            if self._game.started and not self._game.paused:
                # Step physics
                events = self._game.step()

                # Process events
                for event in events:
                    if event.startswith("goal:"):
                        team = Team.RED if "red" in event else Team.BLUE
                        self._on_goal(team)
                    elif event.startswith("kick:"):
                        player_id = int(event.split(":")[1])
                        self._on_ball_kick(player_id)
                    elif event == "time_limit":
                        self._on_time_limit()

                # Record frame
                if self._recorder.is_recording:
                    self._recorder.record_frame(self._game)

                # Broadcast state
                self._broadcast_game_state()

                # Tick callback
                if self.onGameTick:
                    self.onGameTick()

            # Sleep for remaining frame time
            elapsed = time.time() - start
            if elapsed < frame_time:
                await asyncio.sleep(frame_time - elapsed)

    def _on_goal(self, scoring_team: Team):
        """Handle goal scored"""
        if self.onTeamGoal:
            self.onTeamGoal(scoring_team)

        # Check for victory
        scores = self._game.get_scores()
        if self._score_limit > 0:
            if scores.red >= self._score_limit or scores.blue >= self._score_limit:
                self._on_victory()
                return

        # Reset positions
        self._game.reset_positions()
        if self.onPositionsReset:
            self.onPositionsReset()

    def _on_ball_kick(self, player_id: int):
        """Handle ball kick"""
        player = self._players.get(player_id)
        if player and self.onPlayerBallKick:
            self.onPlayerBallKick(player.to_object())

    def _on_time_limit(self):
        """Handle time limit reached"""
        scores = self._game.get_scores()
        if scores.red != scores.blue:
            self._on_victory()

    def _on_victory(self):
        """Handle game victory"""
        scores = self._game.get_scores()

        if self.onTeamVictory:
            self.onTeamVictory(scores)

        # Stop game after delay
        asyncio.get_event_loop().call_later(3.0, self.stopGame)

    # ==================== Broadcast Methods ====================

    def _send_room_state(self, peer_id: int):
        """Send full room state to a peer"""
        peer = self._peer_manager.get_peer(peer_id)
        if not peer:
            return

        # Send all players
        for player in self._players.values():
            writer = BufferWriter(little_endian=False)
            writer.write_uint8(self.Opcode.PLAYER_JOINED)
            writer.write_uint16(player.id)
            writer.write_string(player.name)
            writer.write_uint8(player.team.value)
            writer.write_uint8(1 if player.admin else 0)
            peer.send(writer.get_bytes())

        # Send settings
        self._send_settings_to_peer(peer)

    def _send_settings_to_peer(self, peer: PeerConnection):
        """Send current settings to peer"""
        # Stadium
        writer = BufferWriter(little_endian=False)
        writer.write_uint8(self.Opcode.STADIUM_CHANGE)
        writer.write_string(self._stadium_name)
        peer.send(writer.get_bytes())

        # Score limit
        writer = BufferWriter(little_endian=False)
        writer.write_uint8(self.Opcode.SCORE_LIMIT)
        writer.write_uint8(self._score_limit)
        peer.send(writer.get_bytes())

        # Time limit
        writer = BufferWriter(little_endian=False)
        writer.write_uint8(self.Opcode.TIME_LIMIT)
        writer.write_uint8(self._time_limit)
        peer.send(writer.get_bytes())

    def _broadcast_player_joined(self, player: Player):
        """Broadcast player joined"""
        writer = BufferWriter(little_endian=False)
        writer.write_uint8(self.Opcode.PLAYER_JOINED)
        writer.write_uint16(player.id)
        writer.write_string(player.name)
        writer.write_uint8(player.team.value)
        writer.write_uint8(1 if player.admin else 0)

        self._broadcast(writer.get_bytes())

    def _broadcast_chat(self, player_id: int, message: str):
        """Broadcast chat message"""
        writer = BufferWriter(little_endian=False)
        writer.write_uint8(self.Opcode.CHAT)
        writer.write_uint16(player_id)
        writer.write_string(message)

        self._broadcast(writer.get_bytes())

    def _broadcast_game_state(self):
        """Broadcast current game state"""
        writer = BufferWriter(little_endian=False)
        writer.write_uint8(self.Opcode.GAME_STATE)

        # Time
        writer.write_float32(self._game.game_time)

        # Scores
        writer.write_uint8(self._game.scores.red)
        writer.write_uint8(self._game.scores.blue)

        # Disc count
        writer.write_uint8(len(self._game.discs))

        # Disc positions
        for disc in self._game.discs:
            writer.write_float32(disc.pos.x)
            writer.write_float32(disc.pos.y)
            writer.write_float32(disc.speed.x)
            writer.write_float32(disc.speed.y)

        self._broadcast(writer.get_bytes(), reliable=False)

    # ==================== Helper Methods ====================

    def _broadcast(self, data: bytes, reliable: bool = True):
        """Safely broadcast data to all peers"""
        if self._peer_manager:
            self._peer_manager.broadcast(data, reliable=reliable)

    def _get_player_by_peer(self, peer_id: int) -> Optional[Player]:
        """Get player by peer ID"""
        for player in self._players.values():
            if player.peer_id == peer_id:
                return player
        return None

    def _remove_player(self, player_id: int):
        """Remove a player"""
        player = self._players.pop(player_id, None)
        if not player:
            return

        # Remove from game
        self._game.remove_player_disc(player_id)

        # Broadcast leave
        writer = BufferWriter(little_endian=False)
        writer.write_uint8(self.Opcode.PLAYER_LEFT)
        writer.write_uint16(player_id)
        self._broadcast(writer.get_bytes())

        # Update room info
        asyncio.create_task(self._update_room_info())

        logger.info(f"Player left: {player.name}")

        if self.onPlayerLeave:
            self.onPlayerLeave(player.to_object())

    # ==================== Public API ====================

    # --- Player Methods ---

    def getPlayer(self, playerId: int) -> Optional[PlayerObject]:
        """
        Get player by ID.

        Args:
            playerId: Player ID (0 returns host if noPlayer is False)

        Returns:
            PlayerObject or None if not found
        """
        player = self._players.get(playerId)
        if player:
            obj = player.to_object()
            # Add position from game state
            props = self._game.get_player_disc_properties(playerId)
            if props and props.x is not None:
                obj.position = Vector2(props.x, props.y)
            return obj
        return None

    def getPlayerList(self) -> list[PlayerObject]:
        """
        Get list of all players.

        Returns:
            List of PlayerObject
        """
        return [self.getPlayer(p.id) for p in self._players.values()]

    def setPlayerAdmin(self, playerId: int, admin: bool):
        """
        Set player admin status.

        Args:
            playerId: Target player ID
            admin: True to give admin, False to remove
        """
        player = self._players.get(playerId)
        if not player or player.admin == admin:
            return

        player.admin = admin

        # Broadcast
        writer = BufferWriter(little_endian=False)
        writer.write_uint8(self.Opcode.ADMIN_CHANGE)
        writer.write_uint16(playerId)
        writer.write_uint8(1 if admin else 0)
        self._broadcast(writer.get_bytes())

        if self.onPlayerAdminChange:
            self.onPlayerAdminChange(player.to_object(), None)

    def setPlayerTeam(self, playerId: int, team: Team):
        """
        Set player team.

        Args:
            playerId: Target player ID
            team: Team to move player to
        """
        player = self._players.get(playerId)
        if not player or player.team == team:
            return

        old_team = player.team
        player.team = team

        # Update game state
        if team == Team.SPECTATORS:
            self._game.remove_player_disc(playerId)
        elif old_team == Team.SPECTATORS:
            self._game.add_player_disc(playerId, team)

        # Broadcast
        writer = BufferWriter(little_endian=False)
        writer.write_uint8(self.Opcode.TEAM_CHANGE)
        writer.write_uint16(playerId)
        writer.write_uint8(team.value)
        self._broadcast(writer.get_bytes())

        if self.onPlayerTeamChange:
            self.onPlayerTeamChange(player.to_object(), None)

    def setPlayerAvatar(self, playerId: int, avatar: Optional[str]):
        """
        Set player avatar.

        Args:
            playerId: Target player ID
            avatar: Avatar string (max 2 chars) or None
        """
        player = self._players.get(playerId)
        if not player:
            return

        player.avatar = avatar[:2] if avatar else None

        # Broadcast
        writer = BufferWriter(little_endian=False)
        writer.write_uint8(self.Opcode.SET_AVATAR)
        writer.write_uint16(playerId)
        writer.write_string(avatar or "")
        self._broadcast(writer.get_bytes())

    def kickPlayer(self, playerId: int, reason: str = "", ban: bool = False):
        """
        Kick a player from the room.

        Args:
            playerId: Target player ID
            reason: Kick reason shown to player
            ban: If True, player is banned
        """
        player = self._players.get(playerId)
        if not player:
            return

        # Ban if requested
        if ban and player.conn and self._connection:
            self._connection.ban_conn(player.conn)

        # Broadcast kick
        writer = BufferWriter(little_endian=False)
        writer.write_uint8(self.Opcode.KICK)
        writer.write_uint16(playerId)
        writer.write_string(reason)
        writer.write_uint8(1 if ban else 0)
        self._broadcast(writer.get_bytes())

        if self.onPlayerKicked:
            self.onPlayerKicked(player.to_object(), reason, ban, None)

        # Remove player
        self._remove_player(playerId)

    def clearBan(self, playerId: int):
        """
        Clear ban for a player.

        Args:
            playerId: Player ID to unban (uses their conn string)
        """
        player = self._players.get(playerId)
        if player and player.conn and self._connection:
            self._connection.unban_conn(player.conn)

    def clearBans(self):
        """Clear all bans."""
        if self._connection:
            self._connection.clear_bans()

    def reorderPlayers(self, playerIdList: list[int], moveToTop: bool):
        """
        Reorder players in the list.

        Args:
            playerIdList: List of player IDs
            moveToTop: If True, move to top; if False, move to bottom
        """
        # Reorder internal list
        pass

    # --- Chat Methods ---

    def sendChat(self, message: str, targetId: Optional[int] = None):
        """
        Send a chat message.

        Args:
            message: Message to send
            targetId: If set, only send to this player
        """
        writer = BufferWriter(little_endian=False)
        writer.write_uint8(self.Opcode.CHAT)
        writer.write_uint16(0)  # Host ID
        writer.write_string(message[:140])

        if targetId is not None:
            player = self._players.get(targetId)
            if player and player.peer_id is not None:
                peer = self._peer_manager.get_peer(player.peer_id)
                if peer:
                    peer.send(writer.get_bytes())
        else:
            self._broadcast(writer.get_bytes())

    def sendAnnouncement(
        self,
        msg: str,
        targetId: Optional[int] = None,
        color: int = 0xFFFFFF,
        style: str = "normal",
        sound: int = 1
    ):
        """
        Send an announcement message.

        Args:
            msg: Message to send
            targetId: If set, only send to this player
            color: RGB color (e.g., 0xFF0000 for red)
            style: "normal", "bold", "italic", "small", "small-bold", "small-italic"
            sound: 0=none, 1=chat, 2=highlight
        """
        style_map = {
            "normal": 0, "bold": 1, "italic": 2,
            "small": 3, "small-bold": 4, "small-italic": 5
        }

        writer = BufferWriter(little_endian=False)
        writer.write_uint8(self.Opcode.ANNOUNCEMENT)
        writer.write_string(msg[:1000])
        writer.write_uint8((color >> 16) & 0xFF)
        writer.write_uint8((color >> 8) & 0xFF)
        writer.write_uint8(color & 0xFF)
        writer.write_uint8(style_map.get(style, 0))
        writer.write_uint8(sound)

        if targetId is not None:
            player = self._players.get(targetId)
            if player and player.peer_id is not None:
                peer = self._peer_manager.get_peer(player.peer_id)
                if peer:
                    peer.send(writer.get_bytes())
        else:
            self._broadcast(writer.get_bytes())

    # --- Game Control Methods ---

    def startGame(self):
        """Start the game."""
        if self._game.started:
            return

        self._game.started = True
        self._game.paused = False
        self._game.game_time = 0
        self._game.scores.red = 0
        self._game.scores.blue = 0
        self._game.scores.scoreLimit = self._score_limit
        self._game.scores.timeLimit = self._time_limit

        # Add player discs
        for player in self._players.values():
            if player.team != Team.SPECTATORS:
                self._game.add_player_disc(player.id, player.team)

        self._game.reset_positions()

        # Broadcast
        writer = BufferWriter(little_endian=False)
        writer.write_uint8(self.Opcode.GAME_START)
        self._broadcast(writer.get_bytes())

        if self.onGameStart:
            self.onGameStart(None)

    def stopGame(self):
        """Stop the game."""
        if not self._game.started:
            return

        self._game.started = False

        # Remove all player discs
        for player in self._players.values():
            self._game.remove_player_disc(player.id)

        # Broadcast
        writer = BufferWriter(little_endian=False)
        writer.write_uint8(self.Opcode.GAME_STOP)
        self._broadcast(writer.get_bytes())

        if self.onGameStop:
            self.onGameStop(None)

    def pauseGame(self, pauseState: bool = True):
        """
        Pause or unpause the game.

        Args:
            pauseState: True to pause, False to unpause
        """
        if not self._game.started or self._game.paused == pauseState:
            return

        self._game.paused = pauseState

        # Broadcast
        writer = BufferWriter(little_endian=False)
        writer.write_uint8(self.Opcode.GAME_PAUSE)
        writer.write_uint8(1 if pauseState else 0)
        self._broadcast(writer.get_bytes())

        if pauseState:
            if self.onGamePause:
                self.onGamePause(pauseState, None)
        else:
            if self.onGameUnpause:
                self.onGameUnpause(None)

    # --- Settings Methods ---

    def setScoreLimit(self, limit: int):
        """Set score limit (0 = unlimited)."""
        self._score_limit = max(0, limit)
        self._game.scores.scoreLimit = self._score_limit

        writer = BufferWriter(little_endian=False)
        writer.write_uint8(self.Opcode.SCORE_LIMIT)
        writer.write_uint8(self._score_limit)
        self._broadcast(writer.get_bytes())

    def setTimeLimit(self, limitInMinutes: int):
        """Set time limit in minutes (0 = unlimited)."""
        self._time_limit = max(0, limitInMinutes)
        self._game.scores.timeLimit = self._time_limit

        writer = BufferWriter(little_endian=False)
        writer.write_uint8(self.Opcode.TIME_LIMIT)
        writer.write_uint8(self._time_limit)
        self._broadcast(writer.get_bytes())

    def setDefaultStadium(self, stadiumName: str):
        """Set stadium to a default one."""
        if stadiumName not in DEFAULT_STADIUMS:
            return

        self._stadium = self._get_default_stadium(stadiumName)
        self._stadium_name = stadiumName
        self._custom_stadium = None
        self._game = GameState(self._stadium)

        # Broadcast
        writer = BufferWriter(little_endian=False)
        writer.write_uint8(self.Opcode.STADIUM_CHANGE)
        writer.write_string(stadiumName)
        self._broadcast(writer.get_bytes())

        if self.onStadiumChange:
            self.onStadiumChange(stadiumName, None)

    def setCustomStadium(self, stadiumFileContents: str):
        """
        Set a custom stadium.

        Args:
            stadiumFileContents: Stadium JSON string
        """
        try:
            stadium = Stadium.from_json(stadiumFileContents)
            self._stadium = stadium
            self._stadium_name = stadium.name or "Custom"
            self._custom_stadium = stadium
            self._game = GameState(self._stadium)

            # Broadcast
            writer = BufferWriter(little_endian=False)
            writer.write_uint8(self.Opcode.STADIUM_CHANGE)
            writer.write_string(self._stadium_name)
            # TODO: Send full stadium data
            self._broadcast(writer.get_bytes())

            if self.onStadiumChange:
                self.onStadiumChange(self._stadium_name, None)

        except Exception as e:
            logger.error(f"Failed to set custom stadium: {e}")

    def setTeamsLock(self, locked: bool):
        """Lock/unlock team changes."""
        if self._teams_lock == locked:
            return

        self._teams_lock = locked

        writer = BufferWriter(little_endian=False)
        writer.write_uint8(self.Opcode.TEAMS_LOCK)
        writer.write_uint8(1 if locked else 0)
        self._broadcast(writer.get_bytes())

        if self.onTeamsLockChange:
            self.onTeamsLockChange(locked, None)

    def setTeamColors(self, team: Team, angle: int, textColor: int, colors: list[int]):
        """
        Set team colors.

        Args:
            team: Team.RED or Team.BLUE
            angle: Pattern angle (0-180)
            textColor: Jersey number color
            colors: List of up to 4 stripe colors
        """
        team_colors = TeamColors(angle=angle, textColor=textColor, colors=colors[:4])

        if team == Team.RED:
            self._red_colors = team_colors
        else:
            self._blue_colors = team_colors

        # Broadcast
        writer = BufferWriter(little_endian=False)
        writer.write_uint8(self.Opcode.TEAM_COLORS)
        writer.write_uint8(team.value)
        writer.write_uint8(angle)
        writer.write_uint8((textColor >> 16) & 0xFF)
        writer.write_uint8((textColor >> 8) & 0xFF)
        writer.write_uint8(textColor & 0xFF)
        writer.write_uint8(len(colors))
        for c in colors[:4]:
            writer.write_uint8((c >> 16) & 0xFF)
            writer.write_uint8((c >> 8) & 0xFF)
            writer.write_uint8(c & 0xFF)
        self._broadcast(writer.get_bytes())

    def setPassword(self, password: Optional[str]):
        """Set room password (None to remove)."""
        self._password = password
        if self._connection:
            asyncio.create_task(self._update_room_info())

    def setRequireRecaptcha(self, required: bool):
        """Set whether recaptcha is required to join."""
        self._require_recaptcha = required

    def setKickRateLimit(self, min_: int, rate: int, burst: int):
        """
        Set kick rate limit.

        Args:
            min_: Minimum kicks allowed
            rate: Kicks per second
            burst: Maximum burst kicks
        """
        self._kick_rate_min = min_
        self._kick_rate_rate = rate
        self._kick_rate_burst = burst

        if self.onKickRateLimitSet:
            self.onKickRateLimitSet(min_, rate, burst, None)

    # --- Physics Methods ---

    def getScores(self) -> Optional[ScoresObject]:
        """Get current scores (None if game not started)."""
        if not self._game.started:
            return None
        return self._game.get_scores()

    def getBallPosition(self) -> Optional[Vector2]:
        """Get ball position (None if game not started)."""
        if not self._game.started:
            return None
        return self._game.get_ball_position()

    def getDiscCount(self) -> int:
        """Get total number of discs."""
        return self._game.get_disc_count()

    def getDiscProperties(self, discIndex: int) -> Optional[DiscPropertiesObject]:
        """Get disc properties by index."""
        return self._game.get_disc_properties(discIndex)

    def setDiscProperties(self, discIndex: int, properties: DiscPropertiesObject):
        """Set disc properties."""
        self._game.set_disc_properties(discIndex, properties)

    def getPlayerDiscProperties(self, playerId: int) -> Optional[DiscPropertiesObject]:
        """Get player's disc properties."""
        return self._game.get_player_disc_properties(playerId)

    def setPlayerDiscProperties(self, playerId: int, properties: DiscPropertiesObject):
        """Set player's disc properties."""
        self._game.set_player_disc_properties(playerId, properties)

    # --- Recording Methods ---

    def startRecording(self) -> bool:
        """Start recording. Returns True if started."""
        if self._recorder.is_recording:
            return False
        self._recorder.start(self._stadium)
        return True

    def stopRecording(self) -> Optional[bytes]:
        """Stop recording and return replay data."""
        if not self._recorder.is_recording:
            return None
        return self._recorder.stop()

    # --- CollisionFlags Reference ---

    @property
    def CollisionFlags(self) -> type:
        """Reference to CollisionFlags constants."""
        return CollisionFlags

    # --- Properties ---

    @property
    def roomLink(self) -> Optional[str]:
        """Get room link URL."""
        return self._room_link

    # --- Lifecycle Methods ---

    async def run_forever(self):
        """Run the room until stopped."""
        try:
            while self._running:
                await asyncio.sleep(1)
        except asyncio.CancelledError:
            pass
        finally:
            await self.close()

    async def close(self):
        """Close the room."""
        if self._closed:
            return

        self._closed = True
        self._running = False

        if self._game_loop_task:
            self._game_loop_task.cancel()
            try:
                await self._game_loop_task
            except asyncio.CancelledError:
                pass

        if self._peer_manager:
            await self._peer_manager.close_all()

        if self._connection:
            await self._connection.close()

        logger.info("Room closed")
