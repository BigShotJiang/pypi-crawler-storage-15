"""Binary buffer utilities for reading and writing data"""

import struct
from typing import Optional


class BufferReader:
    """Binary data reader (little-endian by default)"""

    def __init__(self, data: bytes, little_endian: bool = True):
        self.data = data
        self.pos = 0
        self.little_endian = little_endian
        self._endian = "<" if little_endian else ">"

    @property
    def remaining(self) -> int:
        return len(self.data) - self.pos

    def read_bytes(self, length: Optional[int] = None) -> bytes:
        if length is None:
            length = self.remaining
        if length > self.remaining:
            raise BufferError(f"Cannot read {length} bytes, only {self.remaining} remaining")
        result = self.data[self.pos : self.pos + length]
        self.pos += length
        return result

    def read_uint8(self) -> int:
        result = self.data[self.pos]
        self.pos += 1
        return result

    def read_int8(self) -> int:
        result = struct.unpack_from(f"{self._endian}b", self.data, self.pos)[0]
        self.pos += 1
        return result

    def read_uint16(self) -> int:
        result = struct.unpack_from(f"{self._endian}H", self.data, self.pos)[0]
        self.pos += 2
        return result

    def read_int16(self) -> int:
        result = struct.unpack_from(f"{self._endian}h", self.data, self.pos)[0]
        self.pos += 2
        return result

    def read_uint32(self) -> int:
        result = struct.unpack_from(f"{self._endian}I", self.data, self.pos)[0]
        self.pos += 4
        return result

    def read_int32(self) -> int:
        result = struct.unpack_from(f"{self._endian}i", self.data, self.pos)[0]
        self.pos += 4
        return result

    def read_float32(self) -> float:
        result = struct.unpack_from(f"{self._endian}f", self.data, self.pos)[0]
        self.pos += 4
        return result

    def read_float64(self) -> float:
        result = struct.unpack_from(f"{self._endian}d", self.data, self.pos)[0]
        self.pos += 8
        return result

    def read_varint(self) -> int:
        """Read variable-length integer"""
        result = 0
        shift = 0
        while True:
            byte = self.read_uint8()
            result |= (byte & 0x7F) << shift
            if (byte & 0x80) == 0:
                break
            shift += 7
        return result

    def read_string(self) -> str:
        """Read length-prefixed string (varint length)"""
        length = self.read_varint()
        if length == 0:
            return ""
        data = self.read_bytes(length)
        return data.decode("utf-8")

    def read_string_fixed(self, length: int) -> str:
        """Read fixed-length string"""
        data = self.read_bytes(length)
        return data.decode("utf-8")

    def read_optional_string(self) -> Optional[str]:
        """Read optional string (0 = None)"""
        length = self.read_varint()
        if length == 0:
            return None
        data = self.read_bytes(length - 1)
        return data.decode("utf-8")

    def read_color(self) -> int:
        """Read 24-bit color"""
        r = self.read_uint8()
        g = self.read_uint8()
        b = self.read_uint8()
        return (r << 16) | (g << 8) | b


class BufferWriter:
    """Binary data writer (little-endian by default)"""

    def __init__(self, little_endian: bool = True, initial_capacity: int = 256):
        self.data = bytearray(initial_capacity)
        self.pos = 0
        self.little_endian = little_endian
        self._endian = "<" if little_endian else ">"

    def _ensure_capacity(self, needed: int):
        while len(self.data) < self.pos + needed:
            self.data.extend(b"\x00" * len(self.data))

    def get_bytes(self) -> bytes:
        return bytes(self.data[: self.pos])

    def write_bytes(self, data: bytes):
        self._ensure_capacity(len(data))
        self.data[self.pos : self.pos + len(data)] = data
        self.pos += len(data)

    def write_uint8(self, value: int):
        self._ensure_capacity(1)
        self.data[self.pos] = value & 0xFF
        self.pos += 1

    def write_int8(self, value: int):
        self._ensure_capacity(1)
        struct.pack_into(f"{self._endian}b", self.data, self.pos, value)
        self.pos += 1

    def write_uint16(self, value: int):
        self._ensure_capacity(2)
        struct.pack_into(f"{self._endian}H", self.data, self.pos, value)
        self.pos += 2

    def write_int16(self, value: int):
        self._ensure_capacity(2)
        struct.pack_into(f"{self._endian}h", self.data, self.pos, value)
        self.pos += 2

    def write_uint32(self, value: int):
        self._ensure_capacity(4)
        struct.pack_into(f"{self._endian}I", self.data, self.pos, value)
        self.pos += 4

    def write_int32(self, value: int):
        self._ensure_capacity(4)
        struct.pack_into(f"{self._endian}i", self.data, self.pos, value)
        self.pos += 4

    def write_float32(self, value: float):
        self._ensure_capacity(4)
        struct.pack_into(f"{self._endian}f", self.data, self.pos, value)
        self.pos += 4

    def write_float64(self, value: float):
        self._ensure_capacity(8)
        struct.pack_into(f"{self._endian}d", self.data, self.pos, value)
        self.pos += 8

    def write_varint(self, value: int):
        """Write variable-length integer"""
        value = value & 0xFFFFFFFF
        while value >= 0x80:
            self.write_uint8((value & 0x7F) | 0x80)
            value >>= 7
        self.write_uint8(value)

    def write_string(self, value: str):
        """Write length-prefixed string"""
        encoded = value.encode("utf-8")
        self.write_varint(len(encoded))
        self.write_bytes(encoded)

    def write_optional_string(self, value: Optional[str]):
        """Write optional string"""
        if value is None:
            self.write_varint(0)
        else:
            encoded = value.encode("utf-8")
            self.write_varint(len(encoded) + 1)
            self.write_bytes(encoded)

    def write_string_fixed(self, value: str, length: int):
        """Write fixed-length string (padded with zeros)"""
        encoded = value.encode("utf-8")[:length]
        self._ensure_capacity(length)
        self.data[self.pos : self.pos + len(encoded)] = encoded
        self.pos += length

    def write_color(self, value: int):
        """Write 24-bit color"""
        self.write_uint8((value >> 16) & 0xFF)
        self.write_uint8((value >> 8) & 0xFF)
        self.write_uint8(value & 0xFF)


def bytes_to_hex(data: bytes) -> str:
    """Convert bytes to hex string"""
    return data.hex().upper()


def hex_to_bytes(hex_string: str) -> bytes:
    """Convert hex string to bytes"""
    return bytes.fromhex(hex_string)
