"""
haxball.py - A powerful Python library for the HaxBall Headless API

This library provides a complete Python implementation of the HaxBall
Headless Host API, allowing you to create and manage HaxBall rooms
programmatically.

Quick Start:
    import asyncio
    from haxball import HaxballClient

    async def main():
        client = HaxballClient()

        room = await client.create_room(
            roomName="My Python Room",
            maxPlayers=16,
            public=False,
            token="YOUR_TOKEN",  # Get from https://www.haxball.com/headlesstoken
        )

        # Event handlers
        room.onRoomLink = lambda link: print(f"Room: {link}")
        room.onPlayerJoin = lambda p: print(f"{p.name} joined!")
        room.onPlayerLeave = lambda p: print(f"{p.name} left!")

        def on_chat(player, message):
            print(f"{player.name}: {message}")
            if message == "!help":
                room.sendChat("Commands: !help, !bb")
                return False  # Don't broadcast the command
            return True

        room.onPlayerChat = on_chat

        # Configure room
        room.setScoreLimit(5)
        room.setTimeLimit(7)
        room.setDefaultStadium("Classic")

        # Run forever
        await room.run_forever()

    asyncio.run(main())

API Naming:
    The API closely follows the official HaxBall Headless API naming:
    - room.onPlayerJoin (not on_player_join)
    - room.sendChat() (not send_chat())
    - room.setPlayerTeam() (not set_player_team())

    This makes it easy to work with HaxBall documentation directly.

For more examples, see the examples/ directory.
"""

__version__ = "1.1"
__author__ = "haxball.py contributors"

# Main classes
from .client import HaxballClient, create_room
from .room import Room

# Types
from .types import (
    # Enums
    Team,
    CollisionFlags,
    CollisionFlag,  # Alias

    # Data classes
    Vector2,
    PlayerObject,
    DiscPropertiesObject,
    DiscProperties,  # Alias
    ScoresObject,
    GeoLocation,
    RoomConfigObject,
    RoomConfig,  # Alias
    TeamColors,

    # Stadium types
    Stadium,
    Vertex,
    Segment,
    Goal,
    Disc,
    Plane,
    Joint,
    PlayerPhysics,
    Background,
)

# Game state (advanced usage)
from .game import GameState, GameRecorder

__all__ = [
    # Version
    "__version__",

    # Main classes
    "HaxballClient",
    "create_room",
    "Room",

    # Enums
    "Team",
    "CollisionFlags",
    "CollisionFlag",

    # Player/Game types
    "Vector2",
    "PlayerObject",
    "DiscPropertiesObject",
    "DiscProperties",
    "ScoresObject",
    "GeoLocation",
    "RoomConfigObject",
    "RoomConfig",
    "TeamColors",

    # Stadium types
    "Stadium",
    "Vertex",
    "Segment",
    "Goal",
    "Disc",
    "Plane",
    "Joint",
    "PlayerPhysics",
    "Background",

    # Advanced
    "GameState",
    "GameRecorder",
]
