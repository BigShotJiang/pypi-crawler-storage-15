"""Type definitions for haxball.py - Complete implementation"""

from dataclasses import dataclass, field
from enum import IntEnum, IntFlag
from typing import Callable, Any, Optional, Union
import json
import math


class Team(IntEnum):
    """Team enumeration"""
    SPECTATORS = 0
    RED = 1
    BLUE = 2


class CollisionFlags(IntFlag):
    """
    Collision flag bits for physics.

    These flags are used to determine which objects collide with each other.
    Objects only collide if (object1.cGroup & object2.cMask) != 0
    """
    BALL = 1        # The ball
    RED = 2         # Red team players
    BLUE = 4        # Blue team players
    RED_KO = 8      # Red team during kickoff
    BLUE_KO = 16    # Blue team during kickoff
    WALL = 32       # Stadium walls
    KICK = 64       # Objects that can be kicked
    SCORE = 128     # Goal detection
    C0 = 268435456  # Custom flag 0
    C1 = 536870912  # Custom flag 1
    C2 = 1073741824 # Custom flag 2
    C3 = 2147483648 # Custom flag 3
    ALL = 63        # All default flags

# Alias for compatibility
CollisionFlag = CollisionFlags


@dataclass
class Vector2:
    """2D Vector for positions and velocities"""
    x: float = 0.0
    y: float = 0.0

    def __add__(self, other: "Vector2") -> "Vector2":
        return Vector2(self.x + other.x, self.y + other.y)

    def __sub__(self, other: "Vector2") -> "Vector2":
        return Vector2(self.x - other.x, self.y - other.y)

    def __mul__(self, scalar: float) -> "Vector2":
        return Vector2(self.x * scalar, self.y * scalar)

    def __truediv__(self, scalar: float) -> "Vector2":
        return Vector2(self.x / scalar, self.y / scalar)

    def length(self) -> float:
        return math.hypot(self.x, self.y)

    def normalized(self) -> "Vector2":
        length = self.length()
        if length == 0:
            return Vector2(0, 0)
        return self / length

    def dot(self, other: "Vector2") -> float:
        return self.x * other.x + self.y * other.y

    def to_dict(self) -> dict:
        return {"x": self.x, "y": self.y}

    @classmethod
    def from_dict(cls, data: dict) -> "Vector2":
        return cls(x=data.get("x", 0), y=data.get("y", 0))


@dataclass
class PlayerObject:
    """
    Player representation.

    Attributes:
        id: Unique player identifier (1-based, 0 is host)
        name: Player display name
        team: Current team (Team.SPECTATORS, Team.RED, or Team.BLUE)
        admin: Whether player has admin privileges
        position: Current position on field (None if not playing)
        auth: Public authentication string (unique per player account)
        conn: Connection identifier (can be used to identify same client)
    """
    id: int = 0
    name: str = ""
    team: Team = Team.SPECTATORS
    admin: bool = False
    position: Optional[Vector2] = None
    auth: str = ""
    conn: str = ""

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "team": self.team.value,
            "admin": self.admin,
            "position": self.position.to_dict() if self.position else None,
            "auth": self.auth,
            "conn": self.conn,
        }


@dataclass
class DiscPropertiesObject:
    """
    Disc physics properties.

    Used for both the ball and player discs.
    All properties are optional - only set properties will be modified.
    """
    x: Optional[float] = None
    y: Optional[float] = None
    xspeed: Optional[float] = None
    yspeed: Optional[float] = None
    xgravity: Optional[float] = None
    ygravity: Optional[float] = None
    radius: Optional[float] = None
    bCoeff: Optional[float] = None  # Bounce coefficient
    invMass: Optional[float] = None  # Inverse mass (0 = immovable)
    damping: Optional[float] = None  # Velocity damping per frame
    color: Optional[int] = None  # RGB color (-1 for transparent)
    cMask: Optional[int] = None  # Collision mask
    cGroup: Optional[int] = None  # Collision group

    def to_dict(self) -> dict:
        result = {}
        for key in ["x", "y", "xspeed", "yspeed", "xgravity", "ygravity",
                    "radius", "bCoeff", "invMass", "damping", "color", "cMask", "cGroup"]:
            value = getattr(self, key)
            if value is not None:
                result[key] = value
        return result

    @classmethod
    def from_dict(cls, data: dict) -> "DiscPropertiesObject":
        return cls(
            x=data.get("x"),
            y=data.get("y"),
            xspeed=data.get("xspeed"),
            yspeed=data.get("yspeed"),
            xgravity=data.get("xgravity"),
            ygravity=data.get("ygravity"),
            radius=data.get("radius"),
            bCoeff=data.get("bCoeff"),
            invMass=data.get("invMass"),
            damping=data.get("damping"),
            color=data.get("color"),
            cMask=data.get("cMask"),
            cGroup=data.get("cGroup"),
        )

# Alias
DiscProperties = DiscPropertiesObject


@dataclass
class ScoresObject:
    """
    Game scores representation.

    Attributes:
        red: Red team score
        blue: Blue team score
        time: Elapsed time in seconds
        scoreLimit: Score needed to win (0 = unlimited)
        timeLimit: Time limit in minutes (0 = unlimited)
    """
    red: int = 0
    blue: int = 0
    time: float = 0.0
    scoreLimit: int = 0
    timeLimit: int = 0

    def to_dict(self) -> dict:
        return {
            "red": self.red,
            "blue": self.blue,
            "time": self.time,
            "scoreLimit": self.scoreLimit,
            "timeLimit": self.timeLimit,
        }


@dataclass
class GeoLocation:
    """Geographic location for room listing"""
    lat: float = 0.0
    lon: float = 0.0
    code: str = ""  # Country code (e.g., "tr", "us")

    @classmethod
    def from_dict(cls, data: dict) -> "GeoLocation":
        return cls(
            lat=data.get("lat", 0.0),
            lon=data.get("lon", 0.0),
            code=data.get("code", "").lower()
        )

    def to_dict(self) -> dict:
        return {"lat": self.lat, "lon": self.lon, "code": self.code}


@dataclass
class RoomConfigObject:
    """
    Room configuration for creating a new room.

    Attributes:
        roomName: Name shown in room list
        playerName: Host player name (if noPlayer is False)
        password: Room password (None for no password)
        maxPlayers: Maximum players allowed (2-30)
        public: Whether room appears in public list
        geo: Geographic location override
        token: Headless host token (required)
        noPlayer: If True, host won't join as a player
    """
    roomName: str = "Haxball Room"
    playerName: str = "Host"
    password: Optional[str] = None
    maxPlayers: int = 12
    public: bool = False
    geo: Optional[GeoLocation] = None
    token: str = ""
    noPlayer: bool = False
    proxy: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "roomName": self.roomName,
            "playerName": self.playerName,
            "password": self.password,
            "maxPlayers": self.maxPlayers,
            "public": self.public,
            "geo": self.geo.to_dict() if self.geo else None,
            "token": self.token,
            "noPlayer": self.noPlayer,
        }

# Alias
RoomConfig = RoomConfigObject


@dataclass
class TeamColors:
    """Team colors configuration"""
    angle: int = 0  # Pattern angle in degrees
    textColor: int = 0xFFFFFF  # Jersey number color
    colors: list[int] = field(default_factory=lambda: [0xFF0000])  # Up to 4 stripe colors

    def to_dict(self) -> dict:
        return {
            "angle": self.angle,
            "textColor": self.textColor,
            "colors": self.colors,
        }


# Stadium related types

@dataclass
class Vertex:
    """Stadium vertex point"""
    x: float = 0.0
    y: float = 0.0
    bCoef: float = 1.0
    cMask: int = CollisionFlags.ALL
    cGroup: int = CollisionFlags.WALL
    trait: Optional[str] = None

    def to_dict(self) -> dict:
        result = {"x": self.x, "y": self.y}
        if self.bCoef != 1.0:
            result["bCoef"] = self.bCoef
        if self.cMask != CollisionFlags.ALL:
            result["cMask"] = self._flags_to_list(self.cMask)
        if self.cGroup != CollisionFlags.WALL:
            result["cGroup"] = self._flags_to_list(self.cGroup)
        if self.trait:
            result["trait"] = self.trait
        return result

    @staticmethod
    def _flags_to_list(flags: int) -> list[str]:
        names = []
        if flags & CollisionFlags.BALL:
            names.append("ball")
        if flags & CollisionFlags.RED:
            names.append("red")
        if flags & CollisionFlags.BLUE:
            names.append("blue")
        if flags & CollisionFlags.RED_KO:
            names.append("redKO")
        if flags & CollisionFlags.BLUE_KO:
            names.append("blueKO")
        if flags & CollisionFlags.WALL:
            names.append("wall")
        if flags & CollisionFlags.KICK:
            names.append("kick")
        if flags & CollisionFlags.SCORE:
            names.append("score")
        return names


@dataclass
class Segment:
    """Stadium segment connecting two vertices"""
    v0: int = 0
    v1: int = 1
    bCoef: float = 1.0
    curve: float = 0.0
    curveF: Optional[float] = None
    bias: float = 0.0
    cMask: int = CollisionFlags.ALL
    cGroup: int = CollisionFlags.WALL
    vis: bool = True
    color: int = 0xFFFFFF
    trait: Optional[str] = None


@dataclass
class Goal:
    """Stadium goal definition"""
    p0: Vector2 = field(default_factory=Vector2)
    p1: Vector2 = field(default_factory=Vector2)
    team: Team = Team.RED


@dataclass
class Disc:
    """Stadium disc (ball or obstacle)"""
    pos: Vector2 = field(default_factory=Vector2)
    speed: Vector2 = field(default_factory=Vector2)
    gravity: Vector2 = field(default_factory=Vector2)
    radius: float = 10.0
    bCoef: float = 0.5
    invMass: float = 1.0
    damping: float = 0.99
    color: int = 0xFFFFFF
    cMask: int = CollisionFlags.ALL
    cGroup: int = CollisionFlags.ALL


@dataclass
class Plane:
    """Stadium plane (infinite wall)"""
    normal: Vector2 = field(default_factory=Vector2)
    dist: float = 0.0
    bCoef: float = 1.0
    cMask: int = CollisionFlags.ALL
    cGroup: int = CollisionFlags.WALL
    trait: Optional[str] = None


@dataclass
class Joint:
    """Stadium joint connecting two discs"""
    d0: int = 0
    d1: int = 1
    length: Optional[Union[float, list[float]]] = None
    strength: Union[float, str] = "rigid"
    color: int = 0xFFFFFF


@dataclass
class PlayerPhysics:
    """Player physics properties"""
    radius: float = 15.0
    bCoef: float = 0.5
    invMass: float = 0.5
    damping: float = 0.96
    acceleration: float = 0.1
    kickingAcceleration: float = 0.07
    kickingDamping: float = 0.96
    kickStrength: float = 5.0
    gravity: Vector2 = field(default_factory=Vector2)
    cGroup: int = 0
    kickback: float = 0.0


@dataclass
class Background:
    """Stadium background settings"""
    type: str = "none"  # "none", "grass", "hockey"
    width: float = 0.0
    height: float = 0.0
    kickOffRadius: float = 0.0
    cornerRadius: float = 0.0
    color: int = 0x718C5A
    goalLine: float = 0.0


@dataclass
class Stadium:
    """
    Complete stadium definition.

    Can be loaded from HaxBall stadium JSON format.
    """
    name: str = ""
    width: float = 420.0
    height: float = 200.0
    bg: Background = field(default_factory=Background)
    spawnDistance: float = 200.0
    cameraFollow: str = "ball"  # "ball" or "player"
    maxViewWidth: int = 0
    canBeStored: bool = True
    kickOffReset: str = "partial"  # "partial" or "full"
    traits: dict = field(default_factory=dict)
    vertexes: list[Vertex] = field(default_factory=list)
    segments: list[Segment] = field(default_factory=list)
    goals: list[Goal] = field(default_factory=list)
    discs: list[Disc] = field(default_factory=list)
    planes: list[Plane] = field(default_factory=list)
    joints: list[Joint] = field(default_factory=list)
    redSpawnPoints: list[Vector2] = field(default_factory=list)
    blueSpawnPoints: list[Vector2] = field(default_factory=list)
    playerPhysics: PlayerPhysics = field(default_factory=PlayerPhysics)

    @classmethod
    def from_json(cls, json_str: str) -> "Stadium":
        """Parse stadium from HaxBall JSON format"""
        data = json.loads(json_str) if isinstance(json_str, str) else json_str
        return cls._from_dict(data)

    @classmethod
    def _from_dict(cls, data: dict) -> "Stadium":
        """Create stadium from dictionary"""
        stadium = cls()
        stadium.name = data.get("name", "")
        stadium.width = data.get("width", 420)
        stadium.height = data.get("height", 200)
        stadium.spawnDistance = data.get("spawnDistance", 200)
        stadium.cameraFollow = data.get("cameraFollow", "ball")
        stadium.maxViewWidth = data.get("maxViewWidth", 0)
        stadium.canBeStored = data.get("canBeStored", True)
        stadium.kickOffReset = data.get("kickOffReset", "partial")
        stadium.traits = data.get("traits", {})

        # Parse background
        if "bg" in data:
            bg = data["bg"]
            stadium.bg = Background(
                type=bg.get("type", "none"),
                width=bg.get("width", 0),
                height=bg.get("height", 0),
                kickOffRadius=bg.get("kickOffRadius", 0),
                cornerRadius=bg.get("cornerRadius", 0),
                color=cls._parse_color(bg.get("color", 0x718C5A)),
                goalLine=bg.get("goalLine", 0),
            )

        # Parse vertexes
        for v in data.get("vertexes", []):
            stadium.vertexes.append(Vertex(
                x=v.get("x", 0),
                y=v.get("y", 0),
                bCoef=v.get("bCoef", 1),
                cMask=cls._parse_collision_flags(v.get("cMask", ["all"])),
                cGroup=cls._parse_collision_flags(v.get("cGroup", ["wall"])),
                trait=v.get("trait"),
            ))

        # Parse goals
        for g in data.get("goals", []):
            p0 = g.get("p0", [0, 0])
            p1 = g.get("p1", [0, 0])
            team_str = g.get("team", "red")
            team = Team.RED if team_str == "red" else Team.BLUE
            stadium.goals.append(Goal(
                p0=Vector2(p0[0], p0[1]),
                p1=Vector2(p1[0], p1[1]),
                team=team,
            ))

        # Parse discs
        for d in data.get("discs", []):
            pos = d.get("pos", [0, 0])
            speed = d.get("speed", [0, 0])
            gravity = d.get("gravity", [0, 0])
            stadium.discs.append(Disc(
                pos=Vector2(pos[0], pos[1]) if isinstance(pos, list) else Vector2(),
                speed=Vector2(speed[0], speed[1]) if isinstance(speed, list) else Vector2(),
                gravity=Vector2(gravity[0], gravity[1]) if isinstance(gravity, list) else Vector2(),
                radius=d.get("radius", 10),
                bCoef=d.get("bCoef", 0.5),
                invMass=d.get("invMass", 1),
                damping=d.get("damping", 0.99),
                color=cls._parse_color(d.get("color", 0xFFFFFF)),
                cMask=cls._parse_collision_flags(d.get("cMask", ["all"])),
                cGroup=cls._parse_collision_flags(d.get("cGroup", ["all"])),
            ))

        # Parse spawn points
        for sp in data.get("redSpawnPoints", []):
            stadium.redSpawnPoints.append(Vector2(sp[0], sp[1]))
        for sp in data.get("blueSpawnPoints", []):
            stadium.blueSpawnPoints.append(Vector2(sp[0], sp[1]))

        # Parse player physics
        if "playerPhysics" in data:
            pp = data["playerPhysics"]
            gravity = pp.get("gravity", [0, 0])
            stadium.playerPhysics = PlayerPhysics(
                radius=pp.get("radius", 15),
                bCoef=pp.get("bCoef", 0.5),
                invMass=pp.get("invMass", 0.5),
                damping=pp.get("damping", 0.96),
                acceleration=pp.get("acceleration", 0.1),
                kickingAcceleration=pp.get("kickingAcceleration", 0.07),
                kickingDamping=pp.get("kickingDamping", 0.96),
                kickStrength=pp.get("kickStrength", 5),
                gravity=Vector2(gravity[0], gravity[1]) if isinstance(gravity, list) else Vector2(),
                kickback=pp.get("kickback", 0),
            )

        return stadium

    @staticmethod
    def _parse_color(color) -> int:
        """Parse color from various formats"""
        if color == "transparent":
            return -1
        if isinstance(color, str):
            try:
                return int(color.lstrip("#"), 16)
            except ValueError:
                return 0xFFFFFF  # Default to white for invalid colors
        if isinstance(color, list):
            return (color[0] << 16) | (color[1] << 8) | color[2]
        return color

    @staticmethod
    def _parse_collision_flags(flags) -> int:
        """Parse collision flags from string list"""
        if isinstance(flags, int):
            return flags
        if not isinstance(flags, list):
            flags = [flags]

        result = 0
        flag_map = {
            "all": CollisionFlags.ALL,
            "ball": CollisionFlags.BALL,
            "red": CollisionFlags.RED,
            "blue": CollisionFlags.BLUE,
            "redKO": CollisionFlags.RED_KO,
            "blueKO": CollisionFlags.BLUE_KO,
            "wall": CollisionFlags.WALL,
            "kick": CollisionFlags.KICK,
            "score": CollisionFlags.SCORE,
            "c0": CollisionFlags.C0,
            "c1": CollisionFlags.C1,
            "c2": CollisionFlags.C2,
            "c3": CollisionFlags.C3,
        }
        for f in flags:
            if f in flag_map:
                result |= flag_map[f]
        return result


# Event callback type definitions
OnRoomLinkCallback = Callable[[str], None]
OnPlayerJoinCallback = Callable[[PlayerObject], None]
OnPlayerLeaveCallback = Callable[[PlayerObject], None]
OnPlayerChatCallback = Callable[[PlayerObject, str], Optional[bool]]
OnPlayerKickedCallback = Callable[[PlayerObject, str, bool, Optional[PlayerObject]], None]
OnPlayerTeamChangeCallback = Callable[[PlayerObject, Optional[PlayerObject]], None]
OnPlayerAdminChangeCallback = Callable[[PlayerObject, Optional[PlayerObject]], None]
OnPlayerActivityCallback = Callable[[PlayerObject], None]
OnPlayerBallKickCallback = Callable[[PlayerObject], None]
OnGameStartCallback = Callable[[Optional[PlayerObject]], None]
OnGameStopCallback = Callable[[Optional[PlayerObject]], None]
OnGamePauseCallback = Callable[[bool, Optional[PlayerObject]], None]
OnGameUnpauseCallback = Callable[[Optional[PlayerObject]], None]
OnGameTickCallback = Callable[[], None]
OnTeamGoalCallback = Callable[[Team], None]
OnPositionsResetCallback = Callable[[], None]
OnTeamVictoryCallback = Callable[[ScoresObject], None]
OnStadiumChangeCallback = Callable[[str, Optional[PlayerObject]], None]
OnKickRateLimitSetCallback = Callable[[int, int, int, Optional[PlayerObject]], None]
OnTeamsLockChangeCallback = Callable[[bool, Optional[PlayerObject]], None]
