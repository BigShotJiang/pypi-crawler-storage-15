"""Main HaxBall client interface"""

import asyncio
import logging
from typing import Optional

import aiohttp

from .types import RoomConfigObject, GeoLocation
from .room import Room

logger = logging.getLogger(__name__)


class HaxballClient:
    """
    Main entry point for creating HaxBall rooms.

    Usage:
        async def main():
            client = HaxballClient()

            room = await client.create_room(
                roomName="My Room",
                maxPlayers=16,
                public=False,
                token="YOUR_TOKEN_HERE",
            )

            room.onRoomLink = lambda link: print(f"Room: {link}")
            room.onPlayerJoin = lambda player: print(f"{player.name} joined!")

            await room.run_forever()

        asyncio.run(main())
    """

    GEO_API_URL = "https://www.haxball.com/rs/api/geo"

    def __init__(self):
        self._geo: Optional[GeoLocation] = None

    async def get_geo(self) -> Optional[GeoLocation]:
        """
        Fetch geographic location from HaxBall API.

        This is used for room listing to show the room location.
        """
        if self._geo:
            return self._geo

        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(self.GEO_API_URL) as response:
                    if response.status == 200:
                        data = await response.json()
                        if "data" in data:
                            self._geo = GeoLocation.from_dict(data["data"])
                            return self._geo
        except Exception as e:
            logger.warning(f"Failed to fetch geo location: {e}")

        return None

    async def create_room(
        self,
        roomName: str = "Haxball Room",
        playerName: str = "Host",
        maxPlayers: int = 12,
        public: bool = False,
        password: Optional[str] = None,
        token: str = "",
        geo: Optional[GeoLocation] = None,
        noPlayer: bool = False,
        proxy: Optional[str] = None,
    ) -> Room:
        """
        Create a new HaxBall room.

        This is equivalent to HBInit() from the HaxBall Headless API.

        Args:
            roomName: Name of the room (shown in room list)
            playerName: Host player name (if noPlayer is False)
            maxPlayers: Maximum number of players (2-30)
            public: Whether room appears in public list
            password: Optional room password
            token: HaxBall headless token (REQUIRED)
                   Get one from: https://www.haxball.com/headlesstoken
            geo: Geographic location override (auto-detected if not provided)
            noPlayer: If True, host won't appear as a player
            proxy: Optional proxy URL (http://host:port or socks5://host:port)

        Returns:
            Room instance with all API methods available

        Raises:
            ValueError: If token is not provided
            RuntimeError: If room creation fails

        Example:
            room = await client.create_room(
                roomName="My Room",
                maxPlayers=16,
                token="thr1.XXXXXXXX...",
            )
        """
        if not token:
            raise ValueError(
                "Token is required!\n"
                "Get your token from: https://www.haxball.com/headlesstoken"
            )

        # Auto-detect geo if not provided
        if geo is None:
            geo = await self.get_geo()

        config = RoomConfigObject(
            roomName=roomName,
            playerName=playerName,
            maxPlayers=max(2, min(30, maxPlayers)),
            public=public,
            password=password,
            token=token,
            geo=geo,
            noPlayer=noPlayer,
            proxy=proxy,
        )

        room = Room(config)

        if not await room._start():
            raise RuntimeError("Failed to create room. Check your token and connection.")

        return room


async def create_room(
    roomName: str = "Haxball Room",
    maxPlayers: int = 12,
    public: bool = False,
    token: str = "",
    **kwargs,
) -> Room:
    """
    Convenience function to create a room without instantiating HaxballClient.

    This is a shortcut for:
        client = HaxballClient()
        room = await client.create_room(...)

    Args:
        roomName: Name of the room
        maxPlayers: Maximum number of players
        public: Whether room is public
        token: HaxBall headless token (REQUIRED)
        **kwargs: Additional arguments passed to HaxballClient.create_room()

    Returns:
        Room instance

    Example:
        room = await create_room(
            roomName="Quick Room",
            token="thr1.XXXXXXXX...",
        )
    """
    client = HaxballClient()
    return await client.create_room(
        roomName=roomName,
        maxPlayers=maxPlayers,
        public=public,
        token=token,
        **kwargs,
    )


