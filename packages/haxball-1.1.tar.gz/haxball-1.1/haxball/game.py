"""Game state and physics simulation"""

import math
import time
from dataclasses import dataclass, field
from typing import Optional

from .types import (
    Team, Vector2, Stadium, DiscPropertiesObject, ScoresObject,
    CollisionFlags, PlayerPhysics, Goal
)


@dataclass
class GameDisc:
    """Runtime disc state"""
    pos: Vector2 = field(default_factory=Vector2)
    speed: Vector2 = field(default_factory=Vector2)
    gravity: Vector2 = field(default_factory=Vector2)
    radius: float = 10.0
    bCoef: float = 0.5
    invMass: float = 1.0
    damping: float = 0.99
    color: int = 0xFFFFFF
    cMask: int = CollisionFlags.ALL
    cGroup: int = CollisionFlags.ALL

    def to_properties(self) -> DiscPropertiesObject:
        return DiscPropertiesObject(
            x=self.pos.x,
            y=self.pos.y,
            xspeed=self.speed.x,
            yspeed=self.speed.y,
            xgravity=self.gravity.x,
            ygravity=self.gravity.y,
            radius=self.radius,
            bCoeff=self.bCoef,
            invMass=self.invMass,
            damping=self.damping,
            color=self.color,
            cMask=self.cMask,
            cGroup=self.cGroup,
        )

    def apply_properties(self, props: DiscPropertiesObject):
        if props.x is not None:
            self.pos.x = props.x
        if props.y is not None:
            self.pos.y = props.y
        if props.xspeed is not None:
            self.speed.x = props.xspeed
        if props.yspeed is not None:
            self.speed.y = props.yspeed
        if props.xgravity is not None:
            self.gravity.x = props.xgravity
        if props.ygravity is not None:
            self.gravity.y = props.ygravity
        if props.radius is not None:
            self.radius = props.radius
        if props.bCoeff is not None:
            self.bCoef = props.bCoeff
        if props.invMass is not None:
            self.invMass = props.invMass
        if props.damping is not None:
            self.damping = props.damping
        if props.color is not None:
            self.color = props.color
        if props.cMask is not None:
            self.cMask = props.cMask
        if props.cGroup is not None:
            self.cGroup = props.cGroup


@dataclass
class PlayerState:
    """Player runtime state"""
    id: int = 0
    disc_id: Optional[int] = None  # Index in game.discs
    team: Team = Team.SPECTATORS
    input: int = 0  # Input flags
    kicking: bool = False
    kick_timeout: int = 0
    sync_timeout: int = 0
    position_index: int = 0  # Position in team spawn order


class GameState:
    """
    Complete game state with physics simulation.

    This class manages:
    - All disc positions and velocities
    - Collision detection
    - Score tracking
    - Game timing
    """

    # Physics constants
    FRAME_TIME = 1/60  # 60 FPS
    INPUT_UP = 1
    INPUT_DOWN = 2
    INPUT_LEFT = 4
    INPUT_RIGHT = 8
    INPUT_KICK = 16

    def __init__(self, stadium: Stadium):
        self.stadium = stadium
        self.discs: list[GameDisc] = []
        self.players: dict[int, PlayerState] = {}
        self.scores = ScoresObject()
        self.paused = False
        self.started = False
        self.kickoff_team: Optional[Team] = None
        self.kickoff_reset = False
        self.game_time = 0.0
        self.frame_count = 0

        # Initialize ball from stadium
        self._init_from_stadium()

    def _init_from_stadium(self):
        """Initialize discs from stadium definition"""
        self.discs.clear()

        # First disc is always the ball
        if self.stadium.discs:
            d = self.stadium.discs[0]
            self.discs.append(GameDisc(
                pos=Vector2(d.pos.x, d.pos.y),
                speed=Vector2(d.speed.x, d.speed.y),
                gravity=Vector2(d.gravity.x, d.gravity.y),
                radius=d.radius,
                bCoef=d.bCoef,
                invMass=d.invMass,
                damping=d.damping,
                color=d.color,
                cMask=d.cMask,
                cGroup=d.cGroup | CollisionFlags.KICK | CollisionFlags.SCORE,
            ))
        else:
            # Default ball
            self.discs.append(GameDisc(
                radius=10,
                bCoef=0.5,
                invMass=1,
                damping=0.99,
                color=0xFFFFFF,
                cMask=CollisionFlags.ALL,
                cGroup=CollisionFlags.BALL | CollisionFlags.KICK | CollisionFlags.SCORE,
            ))

        # Add other stadium discs
        for d in self.stadium.discs[1:]:
            self.discs.append(GameDisc(
                pos=Vector2(d.pos.x, d.pos.y),
                speed=Vector2(d.speed.x, d.speed.y),
                gravity=Vector2(d.gravity.x, d.gravity.y),
                radius=d.radius,
                bCoef=d.bCoef,
                invMass=d.invMass,
                damping=d.damping,
                color=d.color,
                cMask=d.cMask,
                cGroup=d.cGroup,
            ))

    def reset_positions(self):
        """Reset all positions for kickoff"""
        # Reset ball to center
        if self.discs:
            self.discs[0].pos = Vector2(0, 0)
            self.discs[0].speed = Vector2(0, 0)

        # Reset stadium discs
        for i, d in enumerate(self.stadium.discs[1:], 1):
            if i < len(self.discs):
                self.discs[i].pos = Vector2(d.pos.x, d.pos.y)
                self.discs[i].speed = Vector2(d.speed.x, d.speed.y)

        # Reset player positions
        red_count = 0
        blue_count = 0

        for player_id, player in self.players.items():
            if player.team == Team.SPECTATORS:
                continue

            if player.disc_id is not None and player.disc_id < len(self.discs):
                disc = self.discs[player.disc_id]

                if player.team == Team.RED:
                    pos = self._get_spawn_position(Team.RED, red_count)
                    red_count += 1
                else:
                    pos = self._get_spawn_position(Team.BLUE, blue_count)
                    blue_count += 1

                disc.pos = pos
                disc.speed = Vector2(0, 0)

        self.kickoff_reset = True

    def _get_spawn_position(self, team: Team, index: int) -> Vector2:
        """Get spawn position for a player"""
        spawn_points = (
            self.stadium.redSpawnPoints if team == Team.RED
            else self.stadium.blueSpawnPoints
        )

        if spawn_points and index < len(spawn_points):
            sp = spawn_points[index]
            return Vector2(sp.x, sp.y)

        # Default spawn position
        spawn_dist = self.stadium.spawnDistance
        x = -spawn_dist if team == Team.RED else spawn_dist
        y = 55 * ((index + 1) // 2) * (1 if index % 2 == 0 else -1)

        return Vector2(x, y)

    def add_player_disc(self, player_id: int, team: Team) -> int:
        """Add a disc for a player, returns disc index"""
        physics = self.stadium.playerPhysics

        disc = GameDisc(
            radius=physics.radius,
            bCoef=physics.bCoef,
            invMass=physics.invMass,
            damping=physics.damping,
            gravity=Vector2(physics.gravity.x, physics.gravity.y),
            color=0xE56E56 if team == Team.RED else 0x5689E5,
            cMask=CollisionFlags.ALL,
            cGroup=(CollisionFlags.RED if team == Team.RED else CollisionFlags.BLUE) | CollisionFlags.KICK,
        )

        disc_id = len(self.discs)
        self.discs.append(disc)

        # Track player state
        if player_id not in self.players:
            self.players[player_id] = PlayerState(id=player_id)
        self.players[player_id].disc_id = disc_id
        self.players[player_id].team = team

        return disc_id

    def remove_player_disc(self, player_id: int):
        """Remove player's disc"""
        if player_id in self.players:
            player = self.players[player_id]
            if player.disc_id is not None:
                # Mark disc as inactive (can't remove due to indexing)
                if player.disc_id < len(self.discs):
                    self.discs[player.disc_id].invMass = 0
                    self.discs[player.disc_id].cMask = 0
                    self.discs[player.disc_id].cGroup = 0
            player.disc_id = None
            player.team = Team.SPECTATORS

    def set_player_input(self, player_id: int, input_flags: int):
        """Set player input for this frame"""
        if player_id in self.players:
            self.players[player_id].input = input_flags
            self.players[player_id].kicking = (input_flags & self.INPUT_KICK) != 0

    def step(self) -> list[str]:
        """
        Run one physics step.

        Returns list of events that occurred (goals, kicks, etc.)
        """
        if not self.started or self.paused:
            return []

        events = []
        physics = self.stadium.playerPhysics

        # Process player inputs
        for player_id, player in self.players.items():
            if player.disc_id is None:
                continue
            if player.disc_id >= len(self.discs):
                continue

            disc = self.discs[player.disc_id]
            inp = player.input

            # Movement
            dx = dy = 0
            if inp & self.INPUT_UP:
                dy -= 1
            if inp & self.INPUT_DOWN:
                dy += 1
            if inp & self.INPUT_LEFT:
                dx -= 1
            if inp & self.INPUT_RIGHT:
                dx += 1

            if dx != 0 and dy != 0:
                length = math.sqrt(dx*dx + dy*dy)
                dx /= length
                dy /= length

            accel = physics.kickingAcceleration if player.kicking else physics.acceleration
            disc.speed.x += dx * accel
            disc.speed.y += dy * accel

            # Damping
            damp = physics.kickingDamping if player.kicking else physics.damping
            disc.damping = damp

            # Kicking
            if player.kicking and player.kick_timeout == 0:
                kick_event = self._process_kick(player, disc)
                if kick_event:
                    events.append(kick_event)

            if player.kick_timeout > 0:
                player.kick_timeout -= 1

        # Update disc positions
        for disc in self.discs:
            if disc.invMass == 0:
                continue

            # Apply gravity
            disc.speed.x += disc.gravity.x
            disc.speed.y += disc.gravity.y

            # Apply velocity
            disc.pos.x += disc.speed.x
            disc.pos.y += disc.speed.y

            # Apply damping
            disc.speed.x *= disc.damping
            disc.speed.y *= disc.damping

        # Collision detection
        self._process_collisions()

        # Check for goals
        goal_event = self._check_goals()
        if goal_event:
            events.append(goal_event)

        # Update time
        self.game_time += self.FRAME_TIME
        self.frame_count += 1

        # Check time limit
        if self.scores.timeLimit > 0:
            if self.game_time >= self.scores.timeLimit * 60:
                if self.scores.red != self.scores.blue:
                    events.append("time_limit")

        return events

    def _process_kick(self, player: PlayerState, player_disc: GameDisc) -> Optional[str]:
        """Process kick action"""
        ball = self.discs[0] if self.discs else None
        if not ball:
            return None

        physics = self.stadium.playerPhysics

        # Check distance to ball
        dx = ball.pos.x - player_disc.pos.x
        dy = ball.pos.y - player_disc.pos.y
        dist = math.sqrt(dx*dx + dy*dy)
        min_dist = ball.radius + player_disc.radius + 4

        if dist <= min_dist:
            # Apply kick
            if dist > 0:
                nx = dx / dist
                ny = dy / dist

                kick_strength = physics.kickStrength
                ball.speed.x += nx * kick_strength
                ball.speed.y += ny * kick_strength

                # Kickback
                player_disc.speed.x -= nx * physics.kickback
                player_disc.speed.y -= ny * physics.kickback

            player.kick_timeout = 4  # Kick cooldown

            # Clear kickoff state
            self.kickoff_reset = False

            return f"kick:{player.id}"

        return None

    def _process_collisions(self):
        """Process all collisions"""
        # Disc-disc collisions
        for i, disc1 in enumerate(self.discs):
            if disc1.invMass == 0:
                continue

            for j, disc2 in enumerate(self.discs[i+1:], i+1):
                if disc2.invMass == 0:
                    continue

                if not (disc1.cGroup & disc2.cMask) or not (disc2.cGroup & disc1.cMask):
                    continue

                self._resolve_disc_collision(disc1, disc2)

        # Disc-plane collisions
        for disc in self.discs:
            if disc.invMass == 0:
                continue

            for plane in self.stadium.planes:
                if not (disc.cGroup & plane.cMask):
                    continue

                self._resolve_plane_collision(disc, plane)

        # Stadium bounds
        for disc in self.discs:
            if disc.invMass == 0:
                continue
            self._resolve_bounds(disc)

    def _resolve_disc_collision(self, disc1: GameDisc, disc2: GameDisc):
        """Resolve collision between two discs"""
        dx = disc2.pos.x - disc1.pos.x
        dy = disc2.pos.y - disc1.pos.y
        dist = math.sqrt(dx*dx + dy*dy)
        min_dist = disc1.radius + disc2.radius

        if dist >= min_dist or dist == 0:
            return

        # Normalize
        nx = dx / dist
        ny = dy / dist

        # Overlap
        overlap = min_dist - dist

        # Mass ratio
        total_mass = disc1.invMass + disc2.invMass
        if total_mass == 0:
            return

        ratio1 = disc1.invMass / total_mass
        ratio2 = disc2.invMass / total_mass

        # Separate discs
        disc1.pos.x -= nx * overlap * ratio1
        disc1.pos.y -= ny * overlap * ratio1
        disc2.pos.x += nx * overlap * ratio2
        disc2.pos.y += ny * overlap * ratio2

        # Relative velocity
        dvx = disc1.speed.x - disc2.speed.x
        dvy = disc1.speed.y - disc2.speed.y
        dvn = dvx * nx + dvy * ny

        if dvn > 0:
            return

        # Bounce coefficient
        e = disc1.bCoef * disc2.bCoef

        # Impulse
        j = -(1 + e) * dvn / total_mass

        disc1.speed.x += j * nx * disc1.invMass
        disc1.speed.y += j * ny * disc1.invMass
        disc2.speed.x -= j * nx * disc2.invMass
        disc2.speed.y -= j * ny * disc2.invMass

    def _resolve_plane_collision(self, disc: GameDisc, plane):
        """Resolve collision with a plane"""
        from .types import Plane
        if not isinstance(plane, Plane):
            return

        # Distance to plane
        dist = (plane.normal.x * disc.pos.x + plane.normal.y * disc.pos.y) - plane.dist

        if dist >= disc.radius:
            return

        # Push out
        penetration = disc.radius - dist
        disc.pos.x += plane.normal.x * penetration
        disc.pos.y += plane.normal.y * penetration

        # Velocity towards plane
        vn = disc.speed.x * plane.normal.x + disc.speed.y * plane.normal.y

        if vn >= 0:
            return

        # Bounce
        e = disc.bCoef * plane.bCoef
        impulse = -(1 + e) * vn

        disc.speed.x += plane.normal.x * impulse
        disc.speed.y += plane.normal.y * impulse

    def _resolve_bounds(self, disc: GameDisc):
        """Keep disc within stadium bounds"""
        width = self.stadium.width
        height = self.stadium.height

        # Left/right
        if disc.pos.x - disc.radius < -width:
            disc.pos.x = -width + disc.radius
            disc.speed.x = abs(disc.speed.x) * disc.bCoef
        elif disc.pos.x + disc.radius > width:
            disc.pos.x = width - disc.radius
            disc.speed.x = -abs(disc.speed.x) * disc.bCoef

        # Top/bottom
        if disc.pos.y - disc.radius < -height:
            disc.pos.y = -height + disc.radius
            disc.speed.y = abs(disc.speed.y) * disc.bCoef
        elif disc.pos.y + disc.radius > height:
            disc.pos.y = height - disc.radius
            disc.speed.y = -abs(disc.speed.y) * disc.bCoef

    def _check_goals(self) -> Optional[str]:
        """Check if ball crossed a goal line"""
        if not self.discs:
            return None

        ball = self.discs[0]

        for goal in self.stadium.goals:
            if self._ball_crossed_goal(ball, goal):
                if goal.team == Team.RED:
                    self.scores.blue += 1
                    return "goal:blue"
                else:
                    self.scores.red += 1
                    return "goal:red"

        return None

    def _ball_crossed_goal(self, ball: GameDisc, goal: Goal) -> bool:
        """Check if ball crossed goal line"""
        # Simple line segment intersection check
        p0 = goal.p0
        p1 = goal.p1

        # Check if ball center is past goal line
        # This is simplified - full implementation needs line-circle intersection
        goal_x = (p0.x + p1.x) / 2

        if goal.team == Team.RED:
            # Red goal is on the left
            return ball.pos.x - ball.radius < goal_x and abs(ball.pos.y) < abs(p1.y - p0.y) / 2
        else:
            # Blue goal is on the right
            return ball.pos.x + ball.radius > goal_x and abs(ball.pos.y) < abs(p1.y - p0.y) / 2

    def get_ball_position(self) -> Optional[Vector2]:
        """Get current ball position"""
        if self.discs:
            return Vector2(self.discs[0].pos.x, self.discs[0].pos.y)
        return None

    def get_disc_count(self) -> int:
        """Get total number of discs"""
        return len(self.discs)

    def get_disc_properties(self, index: int) -> Optional[DiscPropertiesObject]:
        """Get properties of a disc"""
        if 0 <= index < len(self.discs):
            return self.discs[index].to_properties()
        return None

    def set_disc_properties(self, index: int, props: DiscPropertiesObject):
        """Set properties of a disc"""
        if 0 <= index < len(self.discs):
            self.discs[index].apply_properties(props)

    def get_player_disc_properties(self, player_id: int) -> Optional[DiscPropertiesObject]:
        """Get properties of a player's disc"""
        if player_id in self.players:
            disc_id = self.players[player_id].disc_id
            if disc_id is not None:
                return self.get_disc_properties(disc_id)
        return None

    def set_player_disc_properties(self, player_id: int, props: DiscPropertiesObject):
        """Set properties of a player's disc"""
        if player_id in self.players:
            disc_id = self.players[player_id].disc_id
            if disc_id is not None:
                self.set_disc_properties(disc_id, props)

    def get_scores(self) -> ScoresObject:
        """Get current scores"""
        return ScoresObject(
            red=self.scores.red,
            blue=self.scores.blue,
            time=self.game_time,
            scoreLimit=self.scores.scoreLimit,
            timeLimit=self.scores.timeLimit,
        )


class GameRecorder:
    """Records game state for replay"""

    def __init__(self):
        self.recording = False
        self.frames: list[bytes] = []
        self.start_time = 0.0
        self.stadium_data: Optional[bytes] = None

    def start(self, stadium: Stadium):
        """Start recording"""
        self.recording = True
        self.frames.clear()
        self.start_time = time.time()
        # Serialize stadium
        import json
        self.stadium_data = json.dumps({
            "name": stadium.name,
            "width": stadium.width,
            "height": stadium.height,
        }).encode()

    def record_frame(self, game: GameState):
        """Record a single frame"""
        if not self.recording:
            return

        from .buffer import BufferWriter
        writer = BufferWriter()

        # Frame number
        writer.write_uint32(game.frame_count)

        # Disc count
        writer.write_uint8(len(game.discs))

        # Disc positions
        for disc in game.discs:
            writer.write_float32(disc.pos.x)
            writer.write_float32(disc.pos.y)
            writer.write_float32(disc.speed.x)
            writer.write_float32(disc.speed.y)

        # Player inputs
        writer.write_uint8(len(game.players))
        for player_id, player in game.players.items():
            writer.write_uint16(player_id)
            writer.write_uint8(player.input)

        self.frames.append(writer.get_bytes())

    def stop(self) -> bytes:
        """Stop recording and return replay data"""
        self.recording = False

        from .buffer import BufferWriter
        import zlib

        writer = BufferWriter()

        # Header
        writer.write_bytes(b"HBR2")  # Magic
        writer.write_uint32(1)  # Version

        # Stadium
        if self.stadium_data:
            writer.write_uint32(len(self.stadium_data))
            writer.write_bytes(self.stadium_data)
        else:
            writer.write_uint32(0)

        # Frames
        writer.write_uint32(len(self.frames))
        for frame in self.frames:
            writer.write_uint16(len(frame))
            writer.write_bytes(frame)

        # Compress
        return zlib.compress(writer.get_bytes())

    @property
    def is_recording(self) -> bool:
        return self.recording
