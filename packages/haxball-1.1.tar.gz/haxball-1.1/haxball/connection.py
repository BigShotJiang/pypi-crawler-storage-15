"""WebSocket and WebRTC connection handling"""

import asyncio
import json
import logging
import zlib
from typing import Optional, Callable, Any

import aiohttp
from aiohttp_socks import ProxyConnector

from .buffer import BufferReader, BufferWriter

logger = logging.getLogger(__name__)


class GameServerConnection:
    """Handles WebSocket connection to Haxball game server"""

    API_URL = "https://www.haxball.com/rs/api"
    GAME_URL = "https://www.haxball.com"

    def __init__(
        self,
        token: str,
        proxy: Optional[str] = None,
        debug: bool = False,
    ):
        self.token = token
        self.proxy = proxy
        self.debug = debug
        self._ws: Optional[aiohttp.ClientWebSocketResponse] = None
        self._session: Optional[aiohttp.ClientSession] = None
        self._connected = False
        self._room_id: Optional[str] = None
        self._reconnect_token: Optional[str] = None

        # Callbacks
        self.on_room_id: Optional[Callable[[str], None]] = None
        self.on_peer_connect: Optional[Callable[[int, bytes, Any], None]] = None
        self.on_peer_ice_candidate: Optional[Callable[[int, Any], None]] = None
        self.on_disconnect: Optional[Callable[[], None]] = None
        self.on_error: Optional[Callable[[Exception], None]] = None

        # Connection tracking
        self._banned_ips: set[str] = set()
        self._banned_conns: set[str] = set()
        self._pending_peers: dict[int, Any] = {}

        self._ping_task: Optional[asyncio.Task] = None
        self._receive_task: Optional[asyncio.Task] = None

    async def _create_session(self) -> aiohttp.ClientSession:
        """Create HTTP session with optional proxy support"""
        connector = None
        if self.proxy:
            connector = ProxyConnector.from_url(self.proxy)

        return aiohttp.ClientSession(
            connector=connector,
            headers={
                "Origin": self.GAME_URL,
                "User-Agent": "Mozilla/5.0 (compatible; haxball.py)",
            },
        )

    async def connect(self) -> bool:
        """Establish connection to game server"""
        try:
            self._session = await self._create_session()

            # Get WebSocket URL from API
            ws_info = await self._get_ws_info()
            if not ws_info:
                return False

            ws_url = ws_info.get("url")
            ws_token = ws_info.get("token")

            if not ws_url or not ws_token:
                logger.error("Invalid WebSocket info received")
                return False

            # Connect to WebSocket
            self._ws = await self._session.ws_connect(
                f"{ws_url}?token={ws_token}",
                origin=self.GAME_URL,
            )
            self._connected = True

            # Start background tasks
            self._ping_task = asyncio.create_task(self._ping_loop())
            self._receive_task = asyncio.create_task(self._receive_loop())

            logger.info("Connected to game server")
            return True

        except Exception as e:
            logger.error(f"Connection failed: {e}")
            if self.on_error:
                self.on_error(e)
            return False

    async def _get_ws_info(self) -> Optional[dict]:
        """Get WebSocket connection info from API"""
        try:
            data = f"token={self.token}&rcr="
            async with self._session.post(
                f"{self.API_URL}/host",
                data=data,
                headers={"Content-Type": "application/x-www-form-urlencoded"},
            ) as response:
                result = await response.json()

                if result.get("action") == "connect":
                    return result

                if result.get("action") == "recaptcha":
                    logger.error("Recaptcha required - invalid token")
                    return None

                logger.error(f"Unexpected API response: {result}")
                return None

        except Exception as e:
            logger.error(f"Failed to get WS info: {e}")
            return None

    async def _ping_loop(self):
        """Send periodic ping to keep connection alive"""
        while self._connected:
            try:
                await asyncio.sleep(40)
                if self._ws and not self._ws.closed:
                    writer = BufferWriter(little_endian=False)
                    writer.write_uint8(8)  # Ping opcode
                    await self._ws.send_bytes(writer.get_bytes())
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.debug(f"Ping error: {e}")

    async def _receive_loop(self):
        """Receive and process messages from WebSocket"""
        try:
            async for msg in self._ws:
                if msg.type == aiohttp.WSMsgType.BINARY:
                    await self._handle_message(msg.data)
                elif msg.type == aiohttp.WSMsgType.ERROR:
                    logger.error(f"WebSocket error: {self._ws.exception()}")
                    break
                elif msg.type == aiohttp.WSMsgType.CLOSED:
                    break
        except asyncio.CancelledError:
            pass
        except Exception as e:
            logger.error(f"Receive error: {e}")
        finally:
            await self._handle_disconnect()

    async def _handle_message(self, data: bytes):
        """Handle incoming WebSocket message"""
        reader = BufferReader(data, little_endian=False)
        opcode = reader.read_uint8()

        if self.debug:
            logger.debug(f"Received opcode: {opcode}")

        if opcode == 1:
            # Peer connection request
            await self._handle_peer_request(reader)
        elif opcode == 4:
            # ICE candidate
            await self._handle_ice_candidate(reader)
        elif opcode == 5:
            # Room ID
            await self._handle_room_id(reader)
        elif opcode == 6:
            # Reconnect token
            await self._handle_reconnect_token(reader)

    async def _handle_peer_request(self, reader: BufferReader):
        """Handle peer connection request"""
        peer_id = reader.read_uint32()
        conn_id = reader.read_bytes(reader.read_uint8()).hex()
        raw_data = reader.read_bytes()

        try:
            inflated = zlib.decompress(raw_data, -zlib.MAX_WBITS)
            peer_reader = BufferReader(inflated, little_endian=False)
            is_mobile = peer_reader.read_uint8() != 0
            sdp = peer_reader.read_string()
            ice_data = peer_reader.read_bytes()

            # Parse ICE candidates
            ice_candidates = []
            if ice_data:
                ice_reader = BufferReader(ice_data, little_endian=False)
                ice_json = json.loads(ice_reader.read_string())
                ice_candidates = [ice_json] if isinstance(ice_json, dict) else ice_json

            if self.debug:
                logger.debug(f"Peer request: id={peer_id}, conn={conn_id}")

            if self.on_peer_connect:
                self.on_peer_connect(peer_id, sdp.encode(), {
                    "conn_id": conn_id,
                    "is_mobile": is_mobile,
                    "ice_candidates": ice_candidates,
                })

        except Exception as e:
            logger.error(f"Failed to handle peer request: {e}")
            await self._reject_peer(peer_id, 0)

    async def _handle_ice_candidate(self, reader: BufferReader):
        """Handle ICE candidate from peer"""
        peer_id = reader.read_uint32()
        try:
            raw_data = reader.read_bytes()
            inflated = zlib.decompress(raw_data, -zlib.MAX_WBITS)
            ice_reader = BufferReader(inflated, little_endian=False)
            ice_json = json.loads(ice_reader.read_string())

            if self.on_peer_ice_candidate:
                self.on_peer_ice_candidate(peer_id, ice_json)

        except Exception as e:
            logger.error(f"Failed to handle ICE candidate: {e}")

    async def _handle_room_id(self, reader: BufferReader):
        """Handle room ID assignment"""
        length = reader.read_uint8()
        self._room_id = reader.read_string_fixed(length)
        logger.info(f"Room ID: {self._room_id}")

        if self.on_room_id:
            self.on_room_id(self._room_id)

    async def _handle_reconnect_token(self, reader: BufferReader):
        """Handle reconnect token"""
        self._reconnect_token = reader.read_bytes().decode("utf-8")
        logger.debug("Received reconnect token")

    async def _handle_disconnect(self):
        """Handle disconnection"""
        self._connected = False
        if self.on_disconnect:
            self.on_disconnect()

    async def send_peer_answer(self, peer_id: int, sdp: str, ice_candidates: list):
        """Send SDP answer to peer"""
        if not self._ws or self._ws.closed:
            return

        writer = BufferWriter(little_endian=False)
        writer.write_string(sdp)
        writer.write_bytes(json.dumps(ice_candidates).encode())
        compressed = zlib.compress(writer.get_bytes(), level=9)[2:-4]

        msg = BufferWriter(little_endian=False)
        msg.write_uint8(1)  # Answer opcode
        msg.write_uint32(peer_id)
        msg.write_bytes(compressed)

        await self._ws.send_bytes(msg.get_bytes())

    async def send_ice_candidate(self, peer_id: int, candidate: dict):
        """Send ICE candidate to peer"""
        if not self._ws or self._ws.closed:
            return

        writer = BufferWriter(little_endian=False)
        writer.write_bytes(json.dumps(candidate).encode())
        compressed = zlib.compress(writer.get_bytes(), level=9)[2:-4]

        msg = BufferWriter(little_endian=False)
        msg.write_uint8(4)  # ICE opcode
        msg.write_uint32(peer_id)
        msg.write_bytes(compressed)

        await self._ws.send_bytes(msg.get_bytes())

    async def _reject_peer(self, peer_id: int, reason: int):
        """Reject peer connection"""
        if not self._ws or self._ws.closed:
            return

        msg = BufferWriter(little_endian=False)
        msg.write_uint8(0)  # Reject opcode
        msg.write_uint32(peer_id)
        msg.write_uint16(reason)

        await self._ws.send_bytes(msg.get_bytes())

    async def update_room_info(self, room_data: bytes):
        """Update room information"""
        if not self._ws or self._ws.closed:
            return

        msg = BufferWriter(little_endian=False)
        msg.write_uint8(7)  # Room info opcode
        msg.write_bytes(room_data)

        await self._ws.send_bytes(msg.get_bytes())

    async def set_public(self, public: bool):
        """Set room visibility"""
        if not self._ws or self._ws.closed:
            return

        msg = BufferWriter(little_endian=False)
        msg.write_uint8(9)  # Visibility opcode
        msg.write_uint8(1 if public else 0)

        await self._ws.send_bytes(msg.get_bytes())

    def ban_ip(self, ip: str):
        """Add IP to ban list"""
        self._banned_ips.add(ip)

    def unban_ip(self, ip: str):
        """Remove IP from ban list"""
        self._banned_ips.discard(ip)

    def ban_conn(self, conn: str):
        """Add connection ID to ban list"""
        self._banned_conns.add(conn)

    def unban_conn(self, conn: str):
        """Remove connection ID from ban list"""
        self._banned_conns.discard(conn)

    def clear_bans(self):
        """Clear all bans"""
        self._banned_ips.clear()
        self._banned_conns.clear()

    @property
    def room_link(self) -> Optional[str]:
        """Get room link"""
        if self._room_id:
            return f"https://www.haxball.com/play?c={self._room_id}"
        return None

    async def close(self):
        """Close connection"""
        self._connected = False

        if self._ping_task:
            self._ping_task.cancel()
            try:
                await self._ping_task
            except asyncio.CancelledError:
                pass

        if self._receive_task:
            self._receive_task.cancel()
            try:
                await self._receive_task
            except asyncio.CancelledError:
                pass

        if self._ws and not self._ws.closed:
            await self._ws.close()

        if self._session and not self._session.closed:
            await self._session.close()

        logger.info("Connection closed")
