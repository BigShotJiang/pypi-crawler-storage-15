"""Tests for Room module"""

import pytest
from unittest.mock import Mock, AsyncMock, MagicMock, patch

from haxball.room import Room, Player, DEFAULT_STADIUMS
from haxball.types import (
    Team, RoomConfigObject, PlayerObject, ScoresObject,
    DiscPropertiesObject, Vector2, Stadium, CollisionFlags, TeamColors
)


class TestPlayer:
    """Tests for internal Player class"""

    def test_player_init(self):
        player = Player(1, "TestPlayer")
        assert player.id == 1
        assert player.name == "TestPlayer"
        assert player.team == Team.SPECTATORS
        assert player.admin is False
        assert player.auth == ""
        assert player.conn == ""
        assert player.peer_id is None
        assert player.disc_id is None

    def test_to_object(self):
        player = Player(5, "Player5")
        player.team = Team.RED
        player.admin = True
        player.auth = "auth123"
        player.conn = "conn456"

        obj = player.to_object()
        assert isinstance(obj, PlayerObject)
        assert obj.id == 5
        assert obj.name == "Player5"
        assert obj.team == Team.RED
        assert obj.admin is True
        assert obj.auth == "auth123"
        assert obj.conn == "conn456"


class TestDefaultStadiums:
    """Tests for default stadium configurations"""

    def test_classic_stadium_exists(self):
        assert "Classic" in DEFAULT_STADIUMS

    def test_all_stadiums_have_required_keys(self):
        required_keys = ["width", "height", "spawnDistance"]
        for name, stadium in DEFAULT_STADIUMS.items():
            for key in required_keys:
                assert key in stadium, f"{name} missing {key}"

    def test_stadium_dimensions_positive(self):
        for name, stadium in DEFAULT_STADIUMS.items():
            assert stadium["width"] > 0
            assert stadium["height"] > 0
            assert stadium["spawnDistance"] > 0


class TestRoomInit:
    """Tests for Room initialization"""

    def test_room_init_defaults(self):
        config = RoomConfigObject(token="test_token")
        room = Room(config)

        assert room.config == config
        assert room._connection is None
        assert room._peer_manager is None
        assert room._players == {}
        assert room._next_player_id == 1
        assert room._room_link is None
        assert room._running is False
        assert room._closed is False

    def test_room_init_game_defaults(self):
        config = RoomConfigObject(token="test_token")
        room = Room(config)

        assert room._score_limit == 3
        assert room._time_limit == 3
        assert room._teams_lock is False
        assert room._stadium_name == "Classic"

    def test_room_init_event_handlers_none(self):
        config = RoomConfigObject(token="test_token")
        room = Room(config)

        assert room.onRoomLink is None
        assert room.onPlayerJoin is None
        assert room.onPlayerLeave is None
        assert room.onPlayerChat is None
        assert room.onGameStart is None
        assert room.onGameStop is None


class TestRoomPlayerMethods:
    """Tests for Room player management methods"""

    @pytest.fixture
    def room(self):
        config = RoomConfigObject(token="test_token")
        room = Room(config)
        # Add a test player
        player = Player(1, "TestPlayer")
        player.team = Team.SPECTATORS
        room._players[1] = player
        return room

    def test_get_player_exists(self, room):
        player = room.getPlayer(1)
        assert player is not None
        assert player.id == 1
        assert player.name == "TestPlayer"

    def test_get_player_not_exists(self, room):
        player = room.getPlayer(999)
        assert player is None

    def test_get_player_list(self, room):
        # Add more players
        player2 = Player(2, "Player2")
        room._players[2] = player2

        players = room.getPlayerList()
        assert len(players) == 2
        assert all(isinstance(p, PlayerObject) for p in players)

    def test_get_player_list_empty(self):
        config = RoomConfigObject(token="test_token")
        room = Room(config)
        players = room.getPlayerList()
        assert players == []

    def test_set_player_admin(self, room):
        room._peer_manager = Mock()
        room._peer_manager.broadcast = Mock()

        room.setPlayerAdmin(1, True)
        player = room._players[1]
        assert player.admin is True

    def test_set_player_admin_callback(self, room):
        room._peer_manager = Mock()
        room._peer_manager.broadcast = Mock()

        callback_called = False
        def on_admin_change(player, by_player):
            nonlocal callback_called
            callback_called = True
            assert player.admin is True

        room.onPlayerAdminChange = on_admin_change
        room.setPlayerAdmin(1, True)
        assert callback_called

    def test_set_player_team(self, room):
        room._peer_manager = Mock()
        room._peer_manager.broadcast = Mock()

        room.setPlayerTeam(1, Team.RED)
        player = room._players[1]
        assert player.team == Team.RED

    def test_set_player_team_callback(self, room):
        room._peer_manager = Mock()
        room._peer_manager.broadcast = Mock()

        callback_called = False
        def on_team_change(player, by_player):
            nonlocal callback_called
            callback_called = True
            assert player.team == Team.BLUE

        room.onPlayerTeamChange = on_team_change
        room.setPlayerTeam(1, Team.BLUE)
        assert callback_called

    def test_set_player_avatar(self, room):
        room._peer_manager = Mock()
        room._peer_manager.broadcast = Mock()

        room.setPlayerAvatar(1, "AB")
        player = room._players[1]
        assert player.avatar == "AB"

    def test_set_player_avatar_truncates(self, room):
        room._peer_manager = Mock()
        room._peer_manager.broadcast = Mock()

        room.setPlayerAvatar(1, "ABCD")
        player = room._players[1]
        assert player.avatar == "AB"


class TestRoomChatMethods:
    """Tests for Room chat methods"""

    @pytest.fixture
    def room(self):
        config = RoomConfigObject(token="test_token")
        room = Room(config)
        room._peer_manager = Mock()
        room._peer_manager.broadcast = Mock()
        room._peer_manager.get_peer = Mock(return_value=None)
        return room

    def test_send_chat_broadcast(self, room):
        room.sendChat("Hello World")
        room._peer_manager.broadcast.assert_called_once()

    def test_send_chat_truncates_message(self, room):
        long_message = "A" * 200
        room.sendChat(long_message)
        # Should be truncated to 140 chars
        room._peer_manager.broadcast.assert_called_once()

    def test_send_announcement_broadcast(self, room):
        room.sendAnnouncement("Test announcement")
        room._peer_manager.broadcast.assert_called_once()

    def test_send_announcement_with_options(self, room):
        room.sendAnnouncement(
            "Test",
            color=0xFF0000,
            style="bold",
            sound=2
        )
        room._peer_manager.broadcast.assert_called_once()


class TestRoomGameControl:
    """Tests for Room game control methods"""

    @pytest.fixture
    def room(self):
        config = RoomConfigObject(token="test_token")
        room = Room(config)
        room._peer_manager = Mock()
        room._peer_manager.broadcast = Mock()
        return room

    def test_start_game(self, room):
        room.startGame()
        assert room._game.started is True
        assert room._game.paused is False

    def test_start_game_callback(self, room):
        callback_called = False
        def on_game_start(by_player):
            nonlocal callback_called
            callback_called = True

        room.onGameStart = on_game_start
        room.startGame()
        assert callback_called

    def test_start_game_already_started(self, room):
        room.startGame()
        room._peer_manager.broadcast.reset_mock()
        room.startGame()  # Should not broadcast again
        room._peer_manager.broadcast.assert_not_called()

    def test_stop_game(self, room):
        room.startGame()
        room.stopGame()
        assert room._game.started is False

    def test_stop_game_callback(self, room):
        callback_called = False
        def on_game_stop(by_player):
            nonlocal callback_called
            callback_called = True

        room.onGameStop = on_game_stop
        room.startGame()
        room.stopGame()
        assert callback_called

    def test_pause_game(self, room):
        room.startGame()
        room.pauseGame(True)
        assert room._game.paused is True

    def test_unpause_game(self, room):
        room.startGame()
        room.pauseGame(True)
        room.pauseGame(False)
        assert room._game.paused is False


class TestRoomSettings:
    """Tests for Room settings methods"""

    @pytest.fixture
    def room(self):
        config = RoomConfigObject(token="test_token")
        room = Room(config)
        room._peer_manager = Mock()
        room._peer_manager.broadcast = Mock()
        return room

    def test_set_score_limit(self, room):
        room.setScoreLimit(5)
        assert room._score_limit == 5
        assert room._game.scores.scoreLimit == 5

    def test_set_score_limit_negative(self, room):
        room.setScoreLimit(-5)
        assert room._score_limit == 0  # Should be clamped

    def test_set_time_limit(self, room):
        room.setTimeLimit(10)
        assert room._time_limit == 10
        assert room._game.scores.timeLimit == 10

    def test_set_time_limit_negative(self, room):
        room.setTimeLimit(-5)
        assert room._time_limit == 0  # Should be clamped

    def test_set_default_stadium(self, room):
        room.setDefaultStadium("Big")
        assert room._stadium_name == "Big"

    def test_set_default_stadium_invalid(self, room):
        original_name = room._stadium_name
        room.setDefaultStadium("NonExistent")
        # Should not change
        assert room._stadium_name == original_name

    def test_set_teams_lock(self, room):
        room.setTeamsLock(True)
        assert room._teams_lock is True

    def test_set_teams_lock_callback(self, room):
        callback_called = False
        def on_teams_lock(locked, by_player):
            nonlocal callback_called
            callback_called = True
            assert locked is True

        room.onTeamsLockChange = on_teams_lock
        room.setTeamsLock(True)
        assert callback_called

    def test_set_team_colors_red(self, room):
        room.setTeamColors(Team.RED, 45, 0xFFFFFF, [0xFF0000, 0x00FF00])
        assert room._red_colors.angle == 45
        assert room._red_colors.textColor == 0xFFFFFF
        assert room._red_colors.colors == [0xFF0000, 0x00FF00]

    def test_set_team_colors_blue(self, room):
        room.setTeamColors(Team.BLUE, 90, 0x000000, [0x0000FF])
        assert room._blue_colors.angle == 90
        assert room._blue_colors.textColor == 0x000000
        assert room._blue_colors.colors == [0x0000FF]

    def test_set_kick_rate_limit(self, room):
        room.setKickRateLimit(2, 5, 10)
        assert room._kick_rate_min == 2
        assert room._kick_rate_rate == 5
        assert room._kick_rate_burst == 10

    def test_set_require_recaptcha(self, room):
        room.setRequireRecaptcha(True)
        assert room._require_recaptcha is True


class TestRoomPhysics:
    """Tests for Room physics methods"""

    @pytest.fixture
    def room(self):
        config = RoomConfigObject(token="test_token")
        room = Room(config)
        room._peer_manager = Mock()
        room._peer_manager.broadcast = Mock()
        return room

    def test_get_scores_game_not_started(self, room):
        assert room.getScores() is None

    def test_get_scores_game_started(self, room):
        room.startGame()
        scores = room.getScores()
        assert isinstance(scores, ScoresObject)
        assert scores.red == 0
        assert scores.blue == 0

    def test_get_ball_position_game_not_started(self, room):
        assert room.getBallPosition() is None

    def test_get_ball_position_game_started(self, room):
        room.startGame()
        pos = room.getBallPosition()
        # Ball should be at center
        if pos:
            assert isinstance(pos, Vector2)

    def test_get_disc_count(self, room):
        count = room.getDiscCount()
        assert count >= 0

    def test_get_disc_properties(self, room):
        room.startGame()
        props = room.getDiscProperties(0)
        if props:
            assert isinstance(props, DiscPropertiesObject)

    def test_collision_flags_property(self, room):
        flags = room.CollisionFlags
        assert flags == CollisionFlags
        assert flags.BALL == 1
        assert flags.ALL == 63


class TestRoomRecording:
    """Tests for Room recording methods"""

    @pytest.fixture
    def room(self):
        config = RoomConfigObject(token="test_token")
        room = Room(config)
        room._peer_manager = Mock()
        room._peer_manager.broadcast = Mock()
        return room

    def test_start_recording(self, room):
        result = room.startRecording()
        assert result is True
        assert room._recorder.is_recording is True

    def test_start_recording_already_recording(self, room):
        room.startRecording()
        result = room.startRecording()
        assert result is False  # Already recording

    def test_stop_recording(self, room):
        room.startRecording()
        data = room.stopRecording()
        assert data is not None
        assert isinstance(data, bytes)

    def test_stop_recording_not_recording(self, room):
        data = room.stopRecording()
        assert data is None


class TestRoomProperties:
    """Tests for Room properties"""

    def test_room_link_initial(self):
        config = RoomConfigObject(token="test_token")
        room = Room(config)
        assert room.roomLink is None

    def test_room_link_after_set(self):
        config = RoomConfigObject(token="test_token")
        room = Room(config)
        room._room_link = "https://www.haxball.com/play?c=test123"
        assert room.roomLink == "https://www.haxball.com/play?c=test123"


class TestRoomOpcodes:
    """Tests for Room message opcodes"""

    def test_opcodes_defined(self):
        assert Room.Opcode.PLAYER_INFO == 1
        assert Room.Opcode.INPUT == 2
        assert Room.Opcode.CHAT == 3
        assert Room.Opcode.PLAYER_JOINED == 4
        assert Room.Opcode.PLAYER_LEFT == 5
        assert Room.Opcode.KICK == 6
        assert Room.Opcode.GAME_START == 10
        assert Room.Opcode.GAME_STOP == 11


class TestRoomBroadcast:
    """Tests for Room broadcast helper"""

    def test_broadcast_with_peer_manager(self):
        config = RoomConfigObject(token="test_token")
        room = Room(config)
        room._peer_manager = Mock()
        room._peer_manager.broadcast = Mock()

        room._broadcast(b"test_data")
        room._peer_manager.broadcast.assert_called_once_with(b"test_data", reliable=True)

    def test_broadcast_without_peer_manager(self):
        config = RoomConfigObject(token="test_token")
        room = Room(config)
        room._peer_manager = None

        # Should not raise
        room._broadcast(b"test_data")

    def test_broadcast_unreliable(self):
        config = RoomConfigObject(token="test_token")
        room = Room(config)
        room._peer_manager = Mock()
        room._peer_manager.broadcast = Mock()

        room._broadcast(b"test_data", reliable=False)
        room._peer_manager.broadcast.assert_called_once_with(b"test_data", reliable=False)


class TestRoomHelpers:
    """Tests for Room helper methods"""

    def test_get_player_by_peer(self):
        config = RoomConfigObject(token="test_token")
        room = Room(config)

        player = Player(1, "Test")
        player.peer_id = 100
        room._players[1] = player

        found = room._get_player_by_peer(100)
        assert found is not None
        assert found.id == 1

    def test_get_player_by_peer_not_found(self):
        config = RoomConfigObject(token="test_token")
        room = Room(config)

        found = room._get_player_by_peer(999)
        assert found is None

    def test_get_default_stadium(self):
        config = RoomConfigObject(token="test_token")
        room = Room(config)

        stadium = room._get_default_stadium("Classic")
        assert isinstance(stadium, Stadium)
        assert stadium.name == "Classic"

    def test_get_default_stadium_fallback(self):
        config = RoomConfigObject(token="test_token")
        room = Room(config)

        # Invalid name should fall back to Classic
        stadium = room._get_default_stadium("NonExistent")
        assert stadium.name == "Classic"
