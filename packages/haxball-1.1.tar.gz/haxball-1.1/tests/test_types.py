"""Tests for types module"""

import pytest
import json
from haxball.types import (
    Team, CollisionFlags, Vector2, PlayerObject,
    DiscPropertiesObject, ScoresObject, GeoLocation,
    RoomConfigObject, Stadium, Vertex, Goal
)


class TestTeam:
    """Tests for Team enum"""

    def test_team_values(self):
        assert Team.SPECTATORS == 0
        assert Team.RED == 1
        assert Team.BLUE == 2

    def test_team_comparison(self):
        assert Team.RED != Team.BLUE
        assert Team.SPECTATORS != Team.RED


class TestCollisionFlags:
    """Tests for CollisionFlags"""

    def test_basic_flags(self):
        assert CollisionFlags.BALL == 1
        assert CollisionFlags.RED == 2
        assert CollisionFlags.BLUE == 4
        assert CollisionFlags.WALL == 32
        assert CollisionFlags.ALL == 63

    def test_flag_combinations(self):
        flags = CollisionFlags.BALL | CollisionFlags.RED
        assert flags == 3
        assert flags & CollisionFlags.BALL
        assert flags & CollisionFlags.RED
        assert not (flags & CollisionFlags.BLUE)

    def test_all_includes_basics(self):
        all_flags = CollisionFlags.ALL
        assert all_flags & CollisionFlags.BALL
        assert all_flags & CollisionFlags.RED
        assert all_flags & CollisionFlags.BLUE
        assert all_flags & CollisionFlags.WALL


class TestVector2:
    """Tests for Vector2"""

    def test_default_values(self):
        v = Vector2()
        assert v.x == 0.0
        assert v.y == 0.0

    def test_custom_values(self):
        v = Vector2(x=3.0, y=4.0)
        assert v.x == 3.0
        assert v.y == 4.0

    def test_addition(self):
        v1 = Vector2(1, 2)
        v2 = Vector2(3, 4)
        result = v1 + v2
        assert result.x == 4
        assert result.y == 6

    def test_subtraction(self):
        v1 = Vector2(5, 7)
        v2 = Vector2(2, 3)
        result = v1 - v2
        assert result.x == 3
        assert result.y == 4

    def test_multiplication(self):
        v = Vector2(2, 3)
        result = v * 2
        assert result.x == 4
        assert result.y == 6

    def test_division(self):
        v = Vector2(6, 8)
        result = v / 2
        assert result.x == 3
        assert result.y == 4

    def test_length(self):
        v = Vector2(3, 4)
        assert v.length() == 5.0

    def test_normalized(self):
        v = Vector2(3, 4)
        n = v.normalized()
        assert abs(n.length() - 1.0) < 0.0001

    def test_normalized_zero(self):
        v = Vector2(0, 0)
        n = v.normalized()
        assert n.x == 0
        assert n.y == 0

    def test_dot_product(self):
        v1 = Vector2(1, 2)
        v2 = Vector2(3, 4)
        assert v1.dot(v2) == 11  # 1*3 + 2*4

    def test_to_dict(self):
        v = Vector2(1.5, 2.5)
        d = v.to_dict()
        assert d == {"x": 1.5, "y": 2.5}

    def test_from_dict(self):
        v = Vector2.from_dict({"x": 3.0, "y": 4.0})
        assert v.x == 3.0
        assert v.y == 4.0


class TestPlayerObject:
    """Tests for PlayerObject"""

    def test_default_values(self):
        p = PlayerObject()
        assert p.id == 0
        assert p.name == ""
        assert p.team == Team.SPECTATORS
        assert p.admin is False
        assert p.position is None
        assert p.auth == ""
        assert p.conn == ""

    def test_custom_values(self):
        p = PlayerObject(
            id=1,
            name="TestPlayer",
            team=Team.RED,
            admin=True,
            auth="abc123",
        )
        assert p.id == 1
        assert p.name == "TestPlayer"
        assert p.team == Team.RED
        assert p.admin is True

    def test_to_dict(self):
        p = PlayerObject(id=1, name="Test", team=Team.BLUE)
        d = p.to_dict()
        assert d["id"] == 1
        assert d["name"] == "Test"
        assert d["team"] == 2


class TestDiscPropertiesObject:
    """Tests for DiscPropertiesObject"""

    def test_all_none_by_default(self):
        dp = DiscPropertiesObject()
        assert dp.x is None
        assert dp.y is None
        assert dp.radius is None

    def test_partial_values(self):
        dp = DiscPropertiesObject(x=10.0, y=20.0)
        assert dp.x == 10.0
        assert dp.y == 20.0
        assert dp.radius is None

    def test_to_dict_only_set_values(self):
        dp = DiscPropertiesObject(x=10.0, radius=15.0)
        d = dp.to_dict()
        assert "x" in d
        assert "radius" in d
        assert "y" not in d

    def test_from_dict(self):
        dp = DiscPropertiesObject.from_dict({
            "x": 100,
            "y": 200,
            "xspeed": 5,
            "radius": 10,
        })
        assert dp.x == 100
        assert dp.y == 200
        assert dp.xspeed == 5
        assert dp.radius == 10


class TestScoresObject:
    """Tests for ScoresObject"""

    def test_default_values(self):
        s = ScoresObject()
        assert s.red == 0
        assert s.blue == 0
        assert s.time == 0.0
        assert s.scoreLimit == 0
        assert s.timeLimit == 0

    def test_custom_values(self):
        s = ScoresObject(red=3, blue=2, time=120.5, scoreLimit=5, timeLimit=7)
        assert s.red == 3
        assert s.blue == 2
        assert s.time == 120.5

    def test_to_dict(self):
        s = ScoresObject(red=2, blue=1)
        d = s.to_dict()
        assert d["red"] == 2
        assert d["blue"] == 1


class TestGeoLocation:
    """Tests for GeoLocation"""

    def test_from_dict(self):
        geo = GeoLocation.from_dict({
            "lat": 41.0,
            "lon": 29.0,
            "code": "TR",
        })
        assert geo.lat == 41.0
        assert geo.lon == 29.0
        assert geo.code == "tr"  # lowercase

    def test_to_dict(self):
        geo = GeoLocation(lat=40.0, lon=-74.0, code="us")
        d = geo.to_dict()
        assert d["lat"] == 40.0
        assert d["lon"] == -74.0
        assert d["code"] == "us"


class TestRoomConfigObject:
    """Tests for RoomConfigObject"""

    def test_default_values(self):
        config = RoomConfigObject()
        assert config.roomName == "Haxball Room"
        assert config.maxPlayers == 12
        assert config.public is False
        assert config.noPlayer is False

    def test_custom_values(self):
        config = RoomConfigObject(
            roomName="My Room",
            maxPlayers=20,
            public=True,
            token="test_token",
        )
        assert config.roomName == "My Room"
        assert config.maxPlayers == 20
        assert config.public is True
        assert config.token == "test_token"


class TestStadium:
    """Tests for Stadium"""

    def test_default_stadium(self):
        stadium = Stadium()
        assert stadium.name == ""
        assert stadium.width == 420.0
        assert stadium.height == 200.0

    def test_parse_simple_stadium(self):
        json_str = json.dumps({
            "name": "Test Stadium",
            "width": 500,
            "height": 250,
            "spawnDistance": 200,
        })
        stadium = Stadium.from_json(json_str)
        assert stadium.name == "Test Stadium"
        assert stadium.width == 500
        assert stadium.height == 250

    def test_parse_stadium_with_goals(self):
        json_str = json.dumps({
            "name": "With Goals",
            "width": 420,
            "height": 200,
            "goals": [
                {"p0": [-370, -64], "p1": [-370, 64], "team": "red"},
                {"p0": [370, -64], "p1": [370, 64], "team": "blue"},
            ],
        })
        stadium = Stadium.from_json(json_str)
        assert len(stadium.goals) == 2
        assert stadium.goals[0].team == Team.RED
        assert stadium.goals[1].team == Team.BLUE

    def test_parse_color(self):
        # String format
        assert Stadium._parse_color("FFFFFF") == 0xFFFFFF
        assert Stadium._parse_color("FF0000") == 0xFF0000

        # Array format
        assert Stadium._parse_color([255, 0, 0]) == 0xFF0000
        assert Stadium._parse_color([0, 255, 0]) == 0x00FF00

        # Transparent
        assert Stadium._parse_color("transparent") == -1

        # Integer
        assert Stadium._parse_color(0x00FF00) == 0x00FF00

    def test_parse_collision_flags(self):
        assert Stadium._parse_collision_flags(["all"]) == CollisionFlags.ALL
        assert Stadium._parse_collision_flags(["ball"]) == CollisionFlags.BALL
        assert Stadium._parse_collision_flags(["red", "blue"]) == CollisionFlags.RED | CollisionFlags.BLUE
        assert Stadium._parse_collision_flags(63) == 63
