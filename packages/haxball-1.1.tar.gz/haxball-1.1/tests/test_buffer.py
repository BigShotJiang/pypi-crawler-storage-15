"""Tests for buffer module"""

import pytest
from haxball.buffer import BufferReader, BufferWriter


class TestBufferWriter:
    """Tests for BufferWriter"""

    def test_write_uint8(self):
        writer = BufferWriter()
        writer.write_uint8(0)
        writer.write_uint8(127)
        writer.write_uint8(255)

        data = writer.get_bytes()
        assert data == bytes([0, 127, 255])

    def test_write_uint16(self):
        writer = BufferWriter()
        writer.write_uint16(0)
        writer.write_uint16(1000)
        writer.write_uint16(65535)

        data = writer.get_bytes()
        assert len(data) == 6

    def test_write_uint32(self):
        writer = BufferWriter()
        writer.write_uint32(0)
        writer.write_uint32(1000000)

        data = writer.get_bytes()
        assert len(data) == 8

    def test_write_float32(self):
        writer = BufferWriter()
        writer.write_float32(3.14159)

        data = writer.get_bytes()
        assert len(data) == 4

    def test_write_float64(self):
        writer = BufferWriter()
        writer.write_float64(3.14159265358979)

        data = writer.get_bytes()
        assert len(data) == 8

    def test_write_string(self):
        writer = BufferWriter()
        writer.write_string("Hello")

        data = writer.get_bytes()
        # varint length (1 byte for small strings) + "Hello" (5 bytes)
        assert len(data) == 6

    def test_write_varint(self):
        writer = BufferWriter()
        writer.write_varint(0)
        writer.write_varint(127)
        writer.write_varint(128)
        writer.write_varint(16383)
        writer.write_varint(16384)

        data = writer.get_bytes()
        # 0 = 1 byte, 127 = 1 byte, 128 = 2 bytes, 16383 = 2 bytes, 16384 = 3 bytes
        assert len(data) == 9

    def test_write_bytes(self):
        writer = BufferWriter()
        writer.write_bytes(b"\x00\x01\x02\x03")

        data = writer.get_bytes()
        assert data == b"\x00\x01\x02\x03"

    def test_endianness_little(self):
        writer = BufferWriter(little_endian=True)
        writer.write_uint16(0x0102)

        data = writer.get_bytes()
        assert data == bytes([0x02, 0x01])

    def test_endianness_big(self):
        writer = BufferWriter(little_endian=False)
        writer.write_uint16(0x0102)

        data = writer.get_bytes()
        assert data == bytes([0x01, 0x02])


class TestBufferReader:
    """Tests for BufferReader"""

    def test_read_uint8(self):
        reader = BufferReader(bytes([0, 127, 255]))
        assert reader.read_uint8() == 0
        assert reader.read_uint8() == 127
        assert reader.read_uint8() == 255

    def test_read_uint16(self):
        writer = BufferWriter()
        writer.write_uint16(12345)
        writer.write_uint16(65535)

        reader = BufferReader(writer.get_bytes())
        assert reader.read_uint16() == 12345
        assert reader.read_uint16() == 65535

    def test_read_uint32(self):
        writer = BufferWriter()
        writer.write_uint32(1000000)

        reader = BufferReader(writer.get_bytes())
        assert reader.read_uint32() == 1000000

    def test_read_float32(self):
        writer = BufferWriter()
        writer.write_float32(3.14)

        reader = BufferReader(writer.get_bytes())
        assert abs(reader.read_float32() - 3.14) < 0.001

    def test_read_float64(self):
        writer = BufferWriter()
        writer.write_float64(3.14159265358979)

        reader = BufferReader(writer.get_bytes())
        assert abs(reader.read_float64() - 3.14159265358979) < 0.0000001

    def test_read_string(self):
        writer = BufferWriter()
        writer.write_string("Hello World")

        reader = BufferReader(writer.get_bytes())
        assert reader.read_string() == "Hello World"

    def test_read_varint(self):
        writer = BufferWriter()
        writer.write_varint(0)
        writer.write_varint(127)
        writer.write_varint(128)
        writer.write_varint(16383)
        writer.write_varint(16384)

        reader = BufferReader(writer.get_bytes())
        assert reader.read_varint() == 0
        assert reader.read_varint() == 127
        assert reader.read_varint() == 128
        assert reader.read_varint() == 16383
        assert reader.read_varint() == 16384

    def test_remaining(self):
        reader = BufferReader(bytes([1, 2, 3, 4, 5]))
        assert reader.remaining == 5
        reader.read_uint8()
        assert reader.remaining == 4
        reader.read_uint8()
        assert reader.remaining == 3

    def test_read_bytes(self):
        reader = BufferReader(bytes([1, 2, 3, 4, 5]))
        data = reader.read_bytes(3)
        assert data == bytes([1, 2, 3])
        assert reader.remaining == 2


class TestBufferRoundTrip:
    """Test reading back written data"""

    def test_roundtrip_mixed_types(self):
        writer = BufferWriter()
        writer.write_uint8(42)
        writer.write_uint16(1234)
        writer.write_uint32(567890)
        writer.write_float32(3.14)
        writer.write_string("Test")
        writer.write_varint(999)

        reader = BufferReader(writer.get_bytes())
        assert reader.read_uint8() == 42
        assert reader.read_uint16() == 1234
        assert reader.read_uint32() == 567890
        assert abs(reader.read_float32() - 3.14) < 0.001
        assert reader.read_string() == "Test"
        assert reader.read_varint() == 999

    def test_unicode_string(self):
        writer = BufferWriter()
        writer.write_string("Merhaba Dunya")

        reader = BufferReader(writer.get_bytes())
        assert reader.read_string() == "Merhaba Dunya"

    def test_empty_string(self):
        writer = BufferWriter()
        writer.write_string("")

        reader = BufferReader(writer.get_bytes())
        assert reader.read_string() == ""
