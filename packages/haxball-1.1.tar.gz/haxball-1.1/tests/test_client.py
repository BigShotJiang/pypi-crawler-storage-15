"""Tests for Client module"""

import pytest
from unittest.mock import Mock, AsyncMock, patch, MagicMock
import asyncio

from haxball.client import HaxballClient, create_room
from haxball.types import GeoLocation, RoomConfigObject
from haxball.room import Room


class TestHaxballClient:
    """Tests for HaxballClient class"""

    def test_init(self):
        client = HaxballClient()
        assert client._geo is None

    def test_geo_api_url(self):
        assert HaxballClient.GEO_API_URL == "https://www.haxball.com/rs/api/geo"


class TestGetGeo:
    """Tests for get_geo method"""

    @pytest.mark.asyncio
    async def test_get_geo_success(self):
        client = HaxballClient()

        mock_response = MagicMock()
        mock_response.status = 200
        mock_response.json = AsyncMock(return_value={
            "data": {"lat": 41.0, "lon": 29.0, "code": "TR"}
        })

        mock_session = MagicMock()
        mock_session.get = MagicMock(return_value=MagicMock(
            __aenter__=AsyncMock(return_value=mock_response),
            __aexit__=AsyncMock()
        ))
        mock_session.__aenter__ = AsyncMock(return_value=mock_session)
        mock_session.__aexit__ = AsyncMock()

        with patch('aiohttp.ClientSession', return_value=mock_session):
            geo = await client.get_geo()

        if geo:
            assert isinstance(geo, GeoLocation)

    @pytest.mark.asyncio
    async def test_get_geo_cached(self):
        client = HaxballClient()
        cached_geo = GeoLocation(lat=40.0, lon=-74.0, code="us")
        client._geo = cached_geo

        geo = await client.get_geo()
        assert geo == cached_geo

    @pytest.mark.asyncio
    async def test_get_geo_failure(self):
        client = HaxballClient()

        with patch('aiohttp.ClientSession', side_effect=Exception("Network error")):
            geo = await client.get_geo()
            assert geo is None


class TestCreateRoomMethod:
    """Tests for create_room method"""

    @pytest.mark.asyncio
    async def test_create_room_no_token(self):
        client = HaxballClient()

        with pytest.raises(ValueError) as exc_info:
            await client.create_room(roomName="Test")

        assert "Token is required" in str(exc_info.value)

    @pytest.mark.asyncio
    async def test_create_room_max_players_bounds(self):
        client = HaxballClient()

        # Mock Room and its _start method
        with patch.object(Room, '_start', new_callable=AsyncMock) as mock_start:
            mock_start.return_value = True

            # Test max players clamping (too low)
            room = await client.create_room(
                roomName="Test",
                maxPlayers=1,
                token="test_token"
            )
            assert room.config.maxPlayers == 2  # Clamped to min 2

    @pytest.mark.asyncio
    async def test_create_room_max_players_high(self):
        client = HaxballClient()

        with patch.object(Room, '_start', new_callable=AsyncMock) as mock_start:
            mock_start.return_value = True

            # Test max players clamping (too high)
            room = await client.create_room(
                roomName="Test",
                maxPlayers=50,
                token="test_token"
            )
            assert room.config.maxPlayers == 30  # Clamped to max 30

    @pytest.mark.asyncio
    async def test_create_room_with_geo(self):
        client = HaxballClient()
        geo = GeoLocation(lat=41.0, lon=29.0, code="tr")

        with patch.object(Room, '_start', new_callable=AsyncMock) as mock_start:
            mock_start.return_value = True

            room = await client.create_room(
                roomName="Test",
                token="test_token",
                geo=geo
            )
            assert room.config.geo == geo

    @pytest.mark.asyncio
    async def test_create_room_auto_geo(self):
        client = HaxballClient()
        client._geo = GeoLocation(lat=40.0, lon=-74.0, code="us")

        with patch.object(Room, '_start', new_callable=AsyncMock) as mock_start:
            mock_start.return_value = True

            room = await client.create_room(
                roomName="Test",
                token="test_token"
            )
            assert room.config.geo is not None

    @pytest.mark.asyncio
    async def test_create_room_start_fails(self):
        client = HaxballClient()

        with patch.object(Room, '_start', new_callable=AsyncMock) as mock_start:
            mock_start.return_value = False

            with pytest.raises(RuntimeError) as exc_info:
                await client.create_room(
                    roomName="Test",
                    token="test_token"
                )
            assert "Failed to create room" in str(exc_info.value)

    @pytest.mark.asyncio
    async def test_create_room_with_password(self):
        client = HaxballClient()

        with patch.object(Room, '_start', new_callable=AsyncMock) as mock_start:
            mock_start.return_value = True

            room = await client.create_room(
                roomName="Test",
                token="test_token",
                password="secret123"
            )
            assert room.config.password == "secret123"

    @pytest.mark.asyncio
    async def test_create_room_public(self):
        client = HaxballClient()

        with patch.object(Room, '_start', new_callable=AsyncMock) as mock_start:
            mock_start.return_value = True

            room = await client.create_room(
                roomName="Test",
                token="test_token",
                public=True
            )
            assert room.config.public is True

    @pytest.mark.asyncio
    async def test_create_room_no_player(self):
        client = HaxballClient()

        with patch.object(Room, '_start', new_callable=AsyncMock) as mock_start:
            mock_start.return_value = True

            room = await client.create_room(
                roomName="Test",
                token="test_token",
                noPlayer=True
            )
            assert room.config.noPlayer is True

    @pytest.mark.asyncio
    async def test_create_room_with_proxy(self):
        client = HaxballClient()

        with patch.object(Room, '_start', new_callable=AsyncMock) as mock_start:
            mock_start.return_value = True

            room = await client.create_room(
                roomName="Test",
                token="test_token",
                proxy="http://localhost:8080"
            )
            assert room.config.proxy == "http://localhost:8080"


class TestCreateRoomFunction:
    """Tests for convenience create_room function"""

    @pytest.mark.asyncio
    async def test_create_room_function(self):
        with patch.object(Room, '_start', new_callable=AsyncMock) as mock_start:
            mock_start.return_value = True

            room = await create_room(
                roomName="Quick Room",
                token="test_token"
            )
            assert isinstance(room, Room)
            assert room.config.roomName == "Quick Room"

    @pytest.mark.asyncio
    async def test_create_room_function_with_kwargs(self):
        with patch.object(Room, '_start', new_callable=AsyncMock) as mock_start:
            mock_start.return_value = True

            room = await create_room(
                roomName="Test",
                token="test_token",
                maxPlayers=20,
                public=True,
                password="secret"
            )
            assert room.config.maxPlayers == 20
            assert room.config.public is True
            assert room.config.password == "secret"


class TestRoomConfigObject:
    """Tests for RoomConfigObject used with client"""

    def test_config_defaults(self):
        config = RoomConfigObject()
        assert config.roomName == "Haxball Room"
        assert config.playerName == "Host"
        assert config.maxPlayers == 12
        assert config.public is False
        assert config.password is None
        assert config.token == ""
        assert config.noPlayer is False
        assert config.proxy is None

    def test_config_custom(self):
        config = RoomConfigObject(
            roomName="Custom Room",
            playerName="Admin",
            maxPlayers=20,
            public=True,
            password="pass123",
            token="test_token",
            noPlayer=True,
            proxy="socks5://localhost:1080"
        )
        assert config.roomName == "Custom Room"
        assert config.playerName == "Admin"
        assert config.maxPlayers == 20
        assert config.public is True
        assert config.password == "pass123"
        assert config.token == "test_token"
        assert config.noPlayer is True
        assert config.proxy == "socks5://localhost:1080"


class TestGeoLocation:
    """Tests for GeoLocation used with client"""

    def test_geo_from_dict(self):
        geo = GeoLocation.from_dict({
            "lat": 41.0082,
            "lon": 28.9784,
            "code": "TR"
        })
        assert geo.lat == 41.0082
        assert geo.lon == 28.9784
        assert geo.code == "tr"  # Lowercased

    def test_geo_to_dict(self):
        geo = GeoLocation(lat=40.7128, lon=-74.0060, code="us")
        d = geo.to_dict()
        assert d["lat"] == 40.7128
        assert d["lon"] == -74.0060
        assert d["code"] == "us"
