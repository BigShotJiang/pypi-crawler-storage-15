"""Security tests for haxball.py library"""

import pytest
from haxball.buffer import BufferReader, BufferWriter
from haxball.types import (
    Team, Vector2, PlayerObject, DiscPropertiesObject,
    ScoresObject, GeoLocation, RoomConfigObject, Stadium, TeamColors
)
from haxball.room import Room, Player
from haxball.game import GameState, GameDisc


class TestBufferOverflowProtection:
    """Tests for buffer overflow protection"""

    def test_read_beyond_buffer(self):
        reader = BufferReader(bytes([1, 2, 3]))

        # Reading more bytes than available should raise BufferError
        with pytest.raises(BufferError):
            reader.read_bytes(100)

    def test_read_uint8_empty_buffer(self):
        reader = BufferReader(bytes())
        with pytest.raises(Exception):
            reader.read_uint8()

    def test_read_uint16_insufficient_bytes(self):
        reader = BufferReader(bytes([1]))  # Only 1 byte, need 2
        with pytest.raises(Exception):
            reader.read_uint16()

    def test_read_uint32_insufficient_bytes(self):
        reader = BufferReader(bytes([1, 2]))  # Only 2 bytes, need 4
        with pytest.raises(Exception):
            reader.read_uint32()

    def test_read_float32_insufficient_bytes(self):
        reader = BufferReader(bytes([1, 2, 3]))  # Only 3 bytes, need 4
        with pytest.raises(Exception):
            reader.read_float32()

    def test_read_float64_insufficient_bytes(self):
        reader = BufferReader(bytes([1, 2, 3, 4, 5, 6, 7]))  # Only 7 bytes, need 8
        with pytest.raises(Exception):
            reader.read_float64()


class TestInputValidation:
    """Tests for input validation"""

    def test_player_name_length(self):
        """Player names should be limited"""
        config = RoomConfigObject(token="test")
        room = Room(config)

        # Simulate player info handling - name should be truncated
        long_name = "A" * 100
        truncated = long_name[:25]
        assert len(truncated) == 25

    def test_chat_message_length(self):
        """Chat messages should be limited"""
        long_message = "A" * 200
        truncated = long_message[:140]
        assert len(truncated) == 140

    def test_announcement_length(self):
        """Announcements should be limited"""
        long_msg = "A" * 2000
        truncated = long_msg[:1000]
        assert len(truncated) == 1000

    def test_avatar_length(self):
        """Avatar should be limited to 2 characters"""
        avatar = "ABCD"
        truncated = avatar[:2]
        assert truncated == "AB"

    def test_room_name_length(self):
        """Room name should be limited"""
        long_name = "A" * 100
        truncated = long_name[:40]
        assert len(truncated) == 40


class TestNumericEdgeCases:
    """Tests for numeric edge cases"""

    def test_uint8_boundaries(self):
        writer = BufferWriter()
        writer.write_uint8(0)
        writer.write_uint8(255)

        reader = BufferReader(writer.get_bytes())
        assert reader.read_uint8() == 0
        assert reader.read_uint8() == 255

    def test_uint16_boundaries(self):
        writer = BufferWriter()
        writer.write_uint16(0)
        writer.write_uint16(65535)

        reader = BufferReader(writer.get_bytes())
        assert reader.read_uint16() == 0
        assert reader.read_uint16() == 65535

    def test_uint32_boundaries(self):
        writer = BufferWriter()
        writer.write_uint32(0)
        writer.write_uint32(4294967295)

        reader = BufferReader(writer.get_bytes())
        assert reader.read_uint32() == 0
        assert reader.read_uint32() == 4294967295

    def test_negative_score_limit(self):
        config = RoomConfigObject(token="test")
        room = Room(config)
        room._peer_manager = None

        room.setScoreLimit(-100)
        assert room._score_limit == 0  # Should be clamped to 0

    def test_negative_time_limit(self):
        config = RoomConfigObject(token="test")
        room = Room(config)
        room._peer_manager = None

        room.setTimeLimit(-100)
        assert room._time_limit == 0  # Should be clamped to 0

    def test_max_players_bounds(self):
        # Too low
        config = RoomConfigObject(maxPlayers=0, token="test")
        room = Room(config)
        # Config stores raw value, but create_room clamps it

        # Test clamping logic
        assert max(2, min(30, 0)) == 2
        assert max(2, min(30, 50)) == 30


class TestVectorMathSafety:
    """Tests for vector math safety"""

    def test_zero_vector_normalize(self):
        v = Vector2(0, 0)
        n = v.normalized()
        assert n.x == 0
        assert n.y == 0  # Should not crash

    def test_division_by_zero(self):
        v = Vector2(10, 20)
        # Division by zero should be handled
        try:
            result = v / 0
        except ZeroDivisionError:
            pass  # Expected behavior

    def test_very_large_vector(self):
        v = Vector2(1e308, 1e308)
        length = v.length()
        # Should handle large values without crash - returns inf
        assert length == float('inf') or length > 0

    def test_very_small_vector(self):
        v = Vector2(1e-308, 1e-308)
        n = v.normalized()
        # Should handle small values


class TestGameStateSafety:
    """Tests for game state safety"""

    def test_remove_nonexistent_player(self):
        stadium = Stadium()
        game = GameState(stadium)

        # Should not crash
        game.remove_player_disc(999)

    def test_get_nonexistent_disc(self):
        stadium = Stadium()
        game = GameState(stadium)

        # Should return None for invalid index
        props = game.get_disc_properties(999)
        # May be None or default properties

    def test_negative_disc_index(self):
        stadium = Stadium()
        game = GameState(stadium)

        # Should handle negative index
        props = game.get_disc_properties(-1)

    def test_invalid_player_input(self):
        stadium = Stadium()
        game = GameState(stadium)

        # Should not crash with invalid player ID
        game.set_player_input(999, 0xFF)


class TestRoomStateSafety:
    """Tests for room state safety"""

    def test_kick_nonexistent_player(self):
        config = RoomConfigObject(token="test")
        room = Room(config)
        room._peer_manager = None

        # Should not crash
        room.kickPlayer(999, "Test")

    def test_set_admin_nonexistent_player(self):
        config = RoomConfigObject(token="test")
        room = Room(config)
        room._peer_manager = None

        # Should not crash
        room.setPlayerAdmin(999, True)

    def test_set_team_nonexistent_player(self):
        config = RoomConfigObject(token="test")
        room = Room(config)
        room._peer_manager = None

        # Should not crash
        room.setPlayerTeam(999, Team.RED)

    def test_send_chat_to_nonexistent_player(self):
        config = RoomConfigObject(token="test")
        room = Room(config)
        room._peer_manager = None

        # Should not crash
        room.sendChat("Test", targetId=999)

    def test_send_announcement_to_nonexistent_player(self):
        config = RoomConfigObject(token="test")
        room = Room(config)
        room._peer_manager = None

        # Should not crash
        room.sendAnnouncement("Test", targetId=999)


class TestStringHandling:
    """Tests for string handling security"""

    def test_unicode_player_name(self):
        player = Player(1, "Türkçe İsim 测试 🎮")
        assert player.name == "Türkçe İsim 测试 🎮"

    def test_unicode_in_buffer(self):
        writer = BufferWriter()
        test_str = "Hello 世界 مرحبا 🌍"
        writer.write_string(test_str)

        reader = BufferReader(writer.get_bytes())
        result = reader.read_string()
        assert result == test_str

    def test_empty_string(self):
        writer = BufferWriter()
        writer.write_string("")

        reader = BufferReader(writer.get_bytes())
        result = reader.read_string()
        assert result == ""

    def test_null_bytes_in_string(self):
        writer = BufferWriter()
        test_str = "Hello\x00World"
        writer.write_string(test_str)

        reader = BufferReader(writer.get_bytes())
        result = reader.read_string()
        # Should handle null bytes


class TestTypeCoercion:
    """Tests for type coercion safety"""

    def test_team_from_int(self):
        assert Team.SPECTATORS == 0
        assert Team.RED == 1
        assert Team.BLUE == 2

    def test_vector_from_ints(self):
        v = Vector2(x=1, y=2)
        assert v.x == 1.0
        assert v.y == 2.0

    def test_scores_from_floats(self):
        s = ScoresObject(red=3.9, blue=2.1)
        # Should work with float inputs


class TestResourceLimits:
    """Tests for resource limit handling"""

    def test_many_players(self):
        config = RoomConfigObject(token="test", maxPlayers=30)
        room = Room(config)

        # Add max players
        for i in range(30):
            player = Player(i + 1, f"Player{i}")
            room._players[i + 1] = player

        assert len(room._players) == 30
        players = room.getPlayerList()
        assert len(players) == 30

    def test_large_buffer_write(self):
        writer = BufferWriter()
        # Write a lot of data
        for _ in range(10000):
            writer.write_uint32(0xDEADBEEF)

        data = writer.get_bytes()
        assert len(data) == 40000  # 10000 * 4 bytes

    def test_many_discs(self):
        stadium = Stadium()
        game = GameState(stadium)

        # Simulate many discs
        for i in range(100):
            disc = GameDisc()
            disc.pos = Vector2(i * 10, i * 10)
            game.discs.append(disc)

        assert len(game.discs) >= 100


class TestCustomStadiumSafety:
    """Tests for custom stadium parsing safety"""

    def test_parse_invalid_json(self):
        with pytest.raises(Exception):
            Stadium.from_json("not valid json")

    def test_parse_missing_fields(self):
        # Should use defaults for missing fields
        stadium = Stadium.from_json('{"name": "Test"}')
        assert stadium.name == "Test"
        assert stadium.width > 0  # Default

    def test_parse_invalid_color(self):
        # Should handle invalid colors gracefully - returns white as default
        color = Stadium._parse_color("invalid")
        assert color == 0xFFFFFF  # Default to white for invalid colors

    def test_parse_empty_stadium(self):
        stadium = Stadium.from_json('{}')
        # Should work with empty object


class TestBanSystemSafety:
    """Tests for ban system safety"""

    def test_clear_bans_no_connection(self):
        config = RoomConfigObject(token="test")
        room = Room(config)
        room._connection = None

        # Should not crash
        room.clearBans()

    def test_clear_ban_nonexistent_player(self):
        config = RoomConfigObject(token="test")
        room = Room(config)
        room._connection = None

        # Should not crash
        room.clearBan(999)
