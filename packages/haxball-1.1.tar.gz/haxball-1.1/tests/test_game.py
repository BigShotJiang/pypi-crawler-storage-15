"""Tests for game module"""

import pytest
from haxball.game import GameState, GameDisc, GameRecorder
from haxball.types import (
    Team, Vector2, Stadium, CollisionFlags, DiscPropertiesObject
)


class TestGameDisc:
    """Tests for GameDisc"""

    def test_default_values(self):
        disc = GameDisc()
        assert disc.pos.x == 0
        assert disc.pos.y == 0
        assert disc.speed.x == 0
        assert disc.speed.y == 0
        assert disc.radius == 10.0
        assert disc.invMass == 1.0

    def test_to_properties(self):
        disc = GameDisc(
            pos=Vector2(100, 50),
            speed=Vector2(5, -3),
            radius=15,
        )
        props = disc.to_properties()
        assert props.x == 100
        assert props.y == 50
        assert props.xspeed == 5
        assert props.yspeed == -3
        assert props.radius == 15

    def test_apply_properties(self):
        disc = GameDisc()
        props = DiscPropertiesObject(x=200, y=100, xspeed=10)
        disc.apply_properties(props)

        assert disc.pos.x == 200
        assert disc.pos.y == 100
        assert disc.speed.x == 10
        assert disc.speed.y == 0  # Unchanged

    def test_apply_partial_properties(self):
        disc = GameDisc(pos=Vector2(50, 50), radius=20)
        props = DiscPropertiesObject(x=100)  # Only x
        disc.apply_properties(props)

        assert disc.pos.x == 100
        assert disc.pos.y == 50  # Unchanged
        assert disc.radius == 20  # Unchanged


class TestGameState:
    """Tests for GameState"""

    def test_initialization(self):
        stadium = Stadium(width=420, height=200)
        game = GameState(stadium)

        assert game.stadium == stadium
        assert len(game.discs) >= 1  # At least ball
        assert game.started is False
        assert game.paused is False
        assert game.game_time == 0

    def test_ball_exists(self):
        stadium = Stadium()
        game = GameState(stadium)

        assert len(game.discs) >= 1
        ball = game.discs[0]
        assert ball.cGroup & CollisionFlags.KICK
        assert ball.cGroup & CollisionFlags.SCORE

    def test_add_player_disc(self):
        stadium = Stadium()
        game = GameState(stadium)
        initial_count = len(game.discs)

        disc_id = game.add_player_disc(1, Team.RED)

        assert len(game.discs) == initial_count + 1
        assert disc_id == initial_count
        assert 1 in game.players
        assert game.players[1].disc_id == disc_id
        assert game.players[1].team == Team.RED

    def test_remove_player_disc(self):
        stadium = Stadium()
        game = GameState(stadium)
        game.add_player_disc(1, Team.RED)

        game.remove_player_disc(1)

        assert game.players[1].disc_id is None
        assert game.players[1].team == Team.SPECTATORS

    def test_set_player_input(self):
        stadium = Stadium()
        game = GameState(stadium)
        game.add_player_disc(1, Team.RED)

        game.set_player_input(1, GameState.INPUT_UP | GameState.INPUT_KICK)

        assert game.players[1].input == GameState.INPUT_UP | GameState.INPUT_KICK
        assert game.players[1].kicking is True

    def test_get_ball_position(self):
        stadium = Stadium()
        game = GameState(stadium)

        pos = game.get_ball_position()

        assert pos is not None
        assert isinstance(pos, Vector2)

    def test_get_disc_count(self):
        stadium = Stadium()
        game = GameState(stadium)
        initial_count = game.get_disc_count()

        game.add_player_disc(1, Team.RED)
        game.add_player_disc(2, Team.BLUE)

        assert game.get_disc_count() == initial_count + 2

    def test_get_disc_properties(self):
        stadium = Stadium()
        game = GameState(stadium)

        props = game.get_disc_properties(0)

        assert props is not None
        assert props.x is not None
        assert props.radius is not None

    def test_get_disc_properties_invalid_index(self):
        stadium = Stadium()
        game = GameState(stadium)

        props = game.get_disc_properties(999)

        assert props is None

    def test_set_disc_properties(self):
        stadium = Stadium()
        game = GameState(stadium)
        new_props = DiscPropertiesObject(x=100, y=50, xspeed=5)

        game.set_disc_properties(0, new_props)

        props = game.get_disc_properties(0)
        assert props.x == 100
        assert props.y == 50
        assert props.xspeed == 5

    def test_get_player_disc_properties(self):
        stadium = Stadium()
        game = GameState(stadium)
        game.add_player_disc(1, Team.RED)

        props = game.get_player_disc_properties(1)

        assert props is not None

    def test_set_player_disc_properties(self):
        stadium = Stadium()
        game = GameState(stadium)
        game.add_player_disc(1, Team.RED)
        new_props = DiscPropertiesObject(x=200, y=100)

        game.set_player_disc_properties(1, new_props)

        props = game.get_player_disc_properties(1)
        assert props.x == 200
        assert props.y == 100

    def test_get_scores(self):
        stadium = Stadium()
        game = GameState(stadium)
        game.scores.red = 2
        game.scores.blue = 1

        scores = game.get_scores()

        assert scores.red == 2
        assert scores.blue == 1

    def test_reset_positions(self):
        stadium = Stadium(spawnDistance=170)
        game = GameState(stadium)
        game.add_player_disc(1, Team.RED)
        game.add_player_disc(2, Team.BLUE)

        # Move ball
        game.discs[0].pos = Vector2(100, 100)
        game.discs[0].speed = Vector2(10, 10)

        game.reset_positions()

        # Ball should be at center
        assert game.discs[0].pos.x == 0
        assert game.discs[0].pos.y == 0
        assert game.discs[0].speed.x == 0
        assert game.discs[0].speed.y == 0

    def test_step_not_started(self):
        stadium = Stadium()
        game = GameState(stadium)
        game.started = False

        events = game.step()

        assert events == []

    def test_step_paused(self):
        stadium = Stadium()
        game = GameState(stadium)
        game.started = True
        game.paused = True

        events = game.step()

        assert events == []


class TestPhysicsSimulation:
    """Tests for physics simulation"""

    def test_disc_movement(self):
        stadium = Stadium()
        game = GameState(stadium)
        game.started = True

        # Set ball velocity
        game.discs[0].pos = Vector2(0, 0)
        game.discs[0].speed = Vector2(10, 0)
        game.discs[0].damping = 1.0  # No damping for test

        game.step()

        # Ball should have moved
        assert game.discs[0].pos.x > 0

    def test_disc_damping(self):
        stadium = Stadium()
        game = GameState(stadium)
        game.started = True

        game.discs[0].pos = Vector2(0, 0)
        game.discs[0].speed = Vector2(100, 0)
        game.discs[0].damping = 0.9

        initial_speed = game.discs[0].speed.x

        game.step()

        # Speed should be reduced by damping
        assert game.discs[0].speed.x < initial_speed

    def test_player_movement_input(self):
        stadium = Stadium()
        game = GameState(stadium)
        game.started = True
        game.add_player_disc(1, Team.RED)
        disc_id = game.players[1].disc_id

        # Set input (right)
        game.set_player_input(1, GameState.INPUT_RIGHT)

        initial_x = game.discs[disc_id].pos.x

        game.step()

        # Player should have accelerated right
        assert game.discs[disc_id].speed.x > 0


class TestGameRecorder:
    """Tests for GameRecorder"""

    def test_not_recording_by_default(self):
        recorder = GameRecorder()
        assert recorder.is_recording is False

    def test_start_recording(self):
        recorder = GameRecorder()
        stadium = Stadium()

        recorder.start(stadium)

        assert recorder.is_recording is True
        assert len(recorder.frames) == 0

    def test_record_frame(self):
        recorder = GameRecorder()
        stadium = Stadium()
        game = GameState(stadium)

        recorder.start(stadium)
        recorder.record_frame(game)
        recorder.record_frame(game)

        assert len(recorder.frames) == 2

    def test_stop_recording(self):
        recorder = GameRecorder()
        stadium = Stadium()
        game = GameState(stadium)

        recorder.start(stadium)
        recorder.record_frame(game)
        data = recorder.stop()

        assert recorder.is_recording is False
        assert data is not None
        assert len(data) > 0

    def test_stop_without_start(self):
        recorder = GameRecorder()
        # This should be handled gracefully
        assert recorder.is_recording is False

    def test_dont_record_when_not_started(self):
        recorder = GameRecorder()
        stadium = Stadium()
        game = GameState(stadium)

        recorder.record_frame(game)

        assert len(recorder.frames) == 0
