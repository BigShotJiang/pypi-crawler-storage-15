Disclosures
===========

* [Privacy & Cookies](https://go.microsoft.com/fwlink/?LinkId=521839)
* [Consumer Health Privacy](https://go.microsoft.com/fwlink/?linkid=2259814)
* [Trademarks](https://www.microsoft.com/trademarks)
* © 2025 Microsoft. [Terms of Use](https://go.microsoft.com/fwlink/?LinkID=206977)

