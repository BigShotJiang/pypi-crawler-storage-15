# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
# This file contains some examples that can be used with tests.
