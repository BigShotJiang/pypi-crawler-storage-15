"""Test suite for skillkit library."""
