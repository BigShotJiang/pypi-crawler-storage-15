---
name: skill-b
description: Skill B from experimental directory
---

# Skill B
