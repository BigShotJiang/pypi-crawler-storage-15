---
name: test-skill
description: A test skill from valid plugin
---

# Test Skill

This is a test skill.
