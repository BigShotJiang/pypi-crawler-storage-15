---
name: valid-unicode
description: A valid skill with Unicode and emoji content
---

Unicode test: 你好世界 🎉🚀✨
This tests that the parser handles Unicode correctly.
Emoji: 😀 🎯 🔥
