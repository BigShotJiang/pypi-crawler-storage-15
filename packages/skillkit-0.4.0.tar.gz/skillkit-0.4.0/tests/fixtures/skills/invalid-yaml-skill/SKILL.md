---
name: invalid-yaml
description: This skill has invalid YAML syntax
  missing colon and indentation issue
allowed-tools: [read, write
---

# Invalid YAML Skill

This skill should fail parsing due to malformed YAML frontmatter.
