---
name: invalid-version-type
description: A skill with non-string version for testing
version: 123
---

This is a skill with a numeric version (invalid type) for testing type validation.
