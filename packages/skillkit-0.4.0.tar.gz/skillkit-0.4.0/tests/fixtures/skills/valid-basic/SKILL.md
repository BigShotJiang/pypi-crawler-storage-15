---
name: valid-basic
description: A minimal valid skill with all required fields
---

This is a basic valid skill for testing discovery and parsing.
