---
name: valid-with-version
description: A valid skill with version field for testing
version: 1.0.0
---

This is a valid skill with a version field for testing version parsing.
