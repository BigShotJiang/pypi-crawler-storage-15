#!/bin/bash
# Convert data format
#
# This shell script reads JSON from stdin and converts it to a different format.

# Read stdin
read -r input

# Simple conversion example
echo "Converted: $input"
exit 0
