#!/usr/bin/env python3
"""Script that triggers timeout for testing.

This script enters an infinite loop to test timeout handling.
"""
import time

print("Starting infinite loop...")
while True:
    time.sleep(0.1)
