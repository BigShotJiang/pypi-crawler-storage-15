---
name: script-skill
description: Test skill with executable scripts for testing script execution feature
version: 1.0.0
allowed-tools:
  - Bash
  - Read
  - Write
---

# Script Skill

This is a test skill used for validating script execution functionality in skillkit.

It includes multiple types of scripts:
- Python scripts
- Shell scripts
- JavaScript scripts

All scripts are designed to test various aspects of script execution.
