---
description: This skill is missing the required name field
---

# Missing Name Skill

This skill should fail parsing because it's missing the required 'name' field.
