---
name: invalid-description-skill
dascription: This field is misspelled and should throw an error
---

# Invalid Description Skill

This skill should fail parsing because it's description field is misspelled.
