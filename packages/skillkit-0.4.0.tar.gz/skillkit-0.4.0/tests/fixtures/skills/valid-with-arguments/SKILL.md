---
name: valid-with-arguments
description: A valid skill that uses $ARGUMENTS placeholder
---

This skill demonstrates argument substitution: $ARGUMENTS
