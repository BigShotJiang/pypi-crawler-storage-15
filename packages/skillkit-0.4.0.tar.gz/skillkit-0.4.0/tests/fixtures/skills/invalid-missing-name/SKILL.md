---
description: This skill is missing the required name field
---

This skill should fail validation because it has no name.
