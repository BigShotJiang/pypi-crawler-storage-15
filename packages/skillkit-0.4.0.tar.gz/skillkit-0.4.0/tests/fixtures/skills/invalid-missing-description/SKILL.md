---
name: invalid-missing-description
---

This skill should fail validation because it has no description.
