---
name: [invalid yaml with unclosed bracket
description: This YAML is malformed
---

This skill has malformed YAML syntax and should fail to parse.
