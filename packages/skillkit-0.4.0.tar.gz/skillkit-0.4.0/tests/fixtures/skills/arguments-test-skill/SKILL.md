---
name: arguments-test
description: Test skill for argument substitution
---

# Arguments Test Skill

This skill is used for testing $ARGUMENTS substitution.

Multiple placeholders: $ARGUMENTS and $ARGUMENTS again.

Escaped placeholder: $$ARGUMENTS should remain literal.

No arguments at the end.
