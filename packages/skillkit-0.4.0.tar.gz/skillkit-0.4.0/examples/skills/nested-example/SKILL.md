---
name: nested-root-skill
description: Example skill at the root of the nested structure demonstrating depth 1
---

# Nested Root Skill

This skill demonstrates that skills can exist at any level of the hierarchy.

**Location**: `nested-example/SKILL.md`
**Depth**: 1 level from root (immediate subdirectory)

The nested structure supports flexible organization with skills at every level.
