---
name: nested-category-b
description: Example skill in category B demonstrating flat organization within nested structure
---

# Nested Category B Skill

This skill demonstrates that you can mix flat and nested structures.

**Location**: `category-b/SKILL.md`
**Depth**: 2 levels from root

Some categories may have immediate skills, while others may have deeper nesting.
