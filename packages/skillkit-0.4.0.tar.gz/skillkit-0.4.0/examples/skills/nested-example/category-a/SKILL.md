---
name: nested-mid-skill
description: Example skill demonstrating nested directory structure at depth 2
---

# Nested Mid-Level Skill

This skill demonstrates mid-level nesting in skill organization.

**Location**: `category-a/SKILL.md`
**Depth**: 2 levels from root

Skills can be organized in categories and subcategories for better organization.
