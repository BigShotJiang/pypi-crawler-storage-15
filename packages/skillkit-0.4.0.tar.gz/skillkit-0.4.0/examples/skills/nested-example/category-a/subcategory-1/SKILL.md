---
name: nested-deep-skill
description: Example skill demonstrating nested directory structure at depth 3
---

# Nested Deep Skill

This skill demonstrates that skillkit can discover skills in nested subdirectories.

**Location**: `category-a/subcategory-1/SKILL.md`
**Depth**: 3 levels from root

You can organize your skills in any nested structure up to 5 levels deep.
