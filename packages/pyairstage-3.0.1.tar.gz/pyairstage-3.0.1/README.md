# pyairstage

![Version](https://img.shields.io/github/v/release/danielkaldheim/pyairstage?style=for-the-badge)
![Contributors](https://img.shields.io/github/contributors/danielkaldheim/pyairstage?style=for-the-badge)

Python Library for interacting with Fujitsu Airstage Airconditioners API.

Inspired from https://github.com/thierryvt/pyfujitsu


[!["Buy Me A Coffee"](https://www.buymeacoffee.com/assets/img/custom_images/orange_img.png)](https://www.buymeacoffee.com/danielkaldheim)
