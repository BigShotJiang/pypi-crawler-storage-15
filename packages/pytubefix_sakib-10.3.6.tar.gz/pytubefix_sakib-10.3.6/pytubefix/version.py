__version__ = "10.3.5"

if __name__ == "__main__":
    print(__version__)