from os import PathLike
from typing import Optional, Protocol

from ...bundle.components.camera import Camera2D
from . import ArepyFont, ArepyTexture, Color, Rect, TextureFilter


class Renderer2D(Protocol):
    # Texture methods
    def create_render_texture(self, width: int, height: int) -> ArepyTexture: ...
    def create_texture(self, path: PathLike[str]) -> ArepyTexture: ...
    def unload_texture(self, texture: ArepyTexture) -> None: ...

    # Draw methods
    def bind_render_texture(self, texture: ArepyTexture) -> None: ...
    def unbind_render_texture(self) -> None: ...
    def draw_texture(
        self, texture: ArepyTexture, source: Rect, dest: Rect, color: Color
    ) -> None: ...
    def draw_texture_ex(
        self,
        texture: ArepyTexture,
        source: Rect,
        dest: Rect,
        origin: tuple[float, float],
        rotation: float,
        color: Color,
    ) -> None: ...
    def draw_rectangle(self, rect: Rect, color: Color) -> None: ...
    def draw_rectangle_ex(self, rect: Rect, rotation: float, color: Color) -> None: ...
    def draw_unfilled_rectangle(self, rect: Rect, color: Color) -> None: ...
    def draw_points(self, points: list[tuple[float, float]], color: Color) -> None: ...
    def draw_lines(self, points: list[tuple[float, float]], color: Color) -> None: ...
    def draw_circle(
        self, center: tuple[float, float], radius: float, color: Color
    ) -> None: ...
    def draw_rectangle_rounded(
        self, rect: Rect, roundness: float, segments: int, color: Color
    ) -> None: ...
    def draw_rectangle_rounded_lines(
        self, rect: Rect, roundness: float, segments: int, color: Color
    ) -> None: ...
    def draw_rectangle_lines_ex(
        self, rect: Rect, line_thickness: float, color: Color
    ) -> None: ...
    def draw_line_ex(
        self,
        start: tuple[float, float],
        end: tuple[float, float],
        thickness: float,
        color: Color,
    ) -> None: ...

    def draw_text(
        self, text: str, position: tuple[float, float], font_size: int, color: Color
    ) -> None: ...
    def draw_text_ex(
        self,
        font: ArepyFont,
        text: str,
        position: tuple[float, float],
        font_size: float,
        spacing: float,
        color: Color,
    ) -> None: ...
    def draw_fps(
        self,
        position: tuple[int, int],
    ) -> None: ...
    def measure_text(self, text: str, font_size: int) -> int: ...
    def measure_text_ex(
        self, font: ArepyFont, text: str, font_size: float, spacing: float
    ) -> tuple[float, float]: ...
    def screen_to_world(
        self, position: tuple[float, float], camera: Camera2D
    ) -> tuple[float, float]: ...

    # Frame methods
    def set_texture_filter(
        self, texture: ArepyTexture, filter: TextureFilter
    ) -> None: ...
    def set_max_framerate(self, max_frame_rate: int) -> None: ...
    def clear(self, color: Color) -> None: ...
    def start_frame(self) -> None: ...
    def end_frame(self) -> None: ...
    def flush(self) -> None: ...
    def swap_buffers(self) -> None: ...
    def get_delta_time(self) -> float: ...
    def get_framerate(self) -> int: ...

    # Camera methods
    def add_camera(self, camera: Camera2D) -> None: ...
    def get_camera(self, id: int) -> Optional[Camera2D]: ...
    def remove_camera(self, id: int) -> None: ...
    def begin_camera_mode(self, camera: Camera2D) -> None: ...
    def end_camera_mode(self) -> None: ...
    def update_camera(self, camera: Camera2D) -> None: ...
    def get_cameras(self) -> list[Camera2D]: ...
    def get_current_camera(self) -> Camera2D: ...
    def disable_mouse_cursor(self) -> None: ...
    def enable_mouse_cursor(self) -> None: ...
    def is_mouse_cursor_hidden(self) -> bool: ...
    def set_mouse_position(self, position: tuple[float, float]) -> None: ...

    def begin_scissor_mode(self, x: int, y: int, width: int, height: int) -> None: ...
    def end_scissor_mode(self) -> None: ...

    def load_font_ex(
        self,
        path: PathLike[str],
        base_size: int,
        codepoints: Optional[list[int]],
        count: int,
    ) -> ArepyFont: ...
    def get_font_default(self) -> ArepyFont: ...
    def unload_font(self, font: ArepyFont) -> None: ...

    # Additional shape drawing methods
    def draw_circle_lines(
        self, center: tuple[float, float], radius: float, color: Color
    ) -> None: ...
    def draw_ellipse(
        self,
        center: tuple[float, float],
        radius_h: float,
        radius_v: float,
        color: Color,
    ) -> None: ...
    def draw_ellipse_lines(
        self,
        center: tuple[float, float],
        radius_h: float,
        radius_v: float,
        color: Color,
    ) -> None: ...
    def draw_triangle(
        self,
        v1: tuple[float, float],
        v2: tuple[float, float],
        v3: tuple[float, float],
        color: Color,
    ) -> None: ...
    def draw_triangle_lines(
        self,
        v1: tuple[float, float],
        v2: tuple[float, float],
        v3: tuple[float, float],
        color: Color,
    ) -> None: ...
    def draw_poly(
        self,
        center: tuple[float, float],
        sides: int,
        radius: float,
        rotation: float,
        color: Color,
    ) -> None: ...
    def draw_poly_lines(
        self,
        center: tuple[float, float],
        sides: int,
        radius: float,
        rotation: float,
        color: Color,
    ) -> None: ...
    def draw_poly_lines_ex(
        self,
        center: tuple[float, float],
        sides: int,
        radius: float,
        rotation: float,
        line_thickness: float,
        color: Color,
    ) -> None: ...
    def draw_ring(
        self,
        center: tuple[float, float],
        inner_radius: float,
        outer_radius: float,
        start_angle: float,
        end_angle: float,
        segments: int,
        color: Color,
    ) -> None: ...
    def draw_ring_lines(
        self,
        center: tuple[float, float],
        inner_radius: float,
        outer_radius: float,
        start_angle: float,
        end_angle: float,
        segments: int,
        color: Color,
    ) -> None: ...
    def draw_line_bezier(
        self,
        start: tuple[float, float],
        end: tuple[float, float],
        thickness: float,
        color: Color,
    ) -> None: ...
    def draw_rectangle_gradient_v(
        self, rect: Rect, top_color: Color, bottom_color: Color
    ) -> None: ...
    def draw_rectangle_gradient_h(
        self, rect: Rect, left_color: Color, right_color: Color
    ) -> None: ...
    def draw_rectangle_gradient_ex(
        self,
        rect: Rect,
        top_left: Color,
        bottom_left: Color,
        top_right: Color,
        bottom_right: Color,
    ) -> None: ...
    def draw_pixel(self, position: tuple[float, float], color: Color) -> None: ...
