# creating a custom warning
class BioFlowInsightWarning(UserWarning):
    pass


