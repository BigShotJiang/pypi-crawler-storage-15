# Strategy pattern implementations for upload actions
