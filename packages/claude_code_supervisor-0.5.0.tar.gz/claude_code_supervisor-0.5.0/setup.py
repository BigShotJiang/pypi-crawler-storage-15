"""
Legacy setup.py for backward compatibility.
Most configuration is now in pyproject.toml.
"""

from setuptools import setup

if __name__ == '__main__':
  setup()
