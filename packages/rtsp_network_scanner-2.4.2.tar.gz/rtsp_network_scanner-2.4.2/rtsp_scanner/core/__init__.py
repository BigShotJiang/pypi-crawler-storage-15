"""Core modules for RTSP scanning functionality"""
