

def command(*args, **kwargs):
    import cg3dcasc
    cg3dcasc.import_from_casc()