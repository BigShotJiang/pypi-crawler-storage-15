DIVIDER = ''

def command(*args, **kwargs):
    import cg3dcasc.preferences.editor
    cg3dcasc.preferences.editor.run()

