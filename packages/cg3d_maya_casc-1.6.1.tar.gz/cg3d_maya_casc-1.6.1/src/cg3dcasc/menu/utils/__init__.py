

ORDER = [
    'create_proxy_rig',
    'constrain_proxy',
    'hik_from_proxy', 
    'convert_textures',
    'sync_casc_id'
]