

def command(*args, **kwargs):
    import cg3dcasc 
    cg3dcasc.utils.constrain_proxy()