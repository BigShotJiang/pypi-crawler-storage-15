
PARAMS = {
    'label': 'HIK character from Proxy'
}


def command(*args, **kwargs):
    import cg3dcasc 
    cg3dcasc.utils.hik_def_from_proxy()