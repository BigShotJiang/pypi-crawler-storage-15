
PARAMS = {
    'label': 'Cascadeur'
}

ORDER = [
    'quick_export',
    'update',
    'add_to',
    'connect',
    'import',
    'editor',
    'utils',
    'preferences'
]