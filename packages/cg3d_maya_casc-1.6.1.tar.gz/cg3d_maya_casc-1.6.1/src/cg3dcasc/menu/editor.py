
DIVIDER = ''


def command(*args, **kwargs):
    import cg3dcasc.editor
    cg3dcasc.editor.run()
