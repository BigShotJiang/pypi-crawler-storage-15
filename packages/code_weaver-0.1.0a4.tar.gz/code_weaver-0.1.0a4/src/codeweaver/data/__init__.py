# SPDX-FileCopyrightText: 2025 Knitli Inc.
# SPDX-FileContributor: Adam Poulemanos <adam@knit.li>
#
# SPDX-License-Identifier: MIT OR Apache-2.0
"""Data package for CodeWeaver containing node types and cached grammar data."""

from __future__ import annotations


__all__ = ()
