class Constants:
    DEFAULT_RPC_TOPIC = "rpc/qn-server"
