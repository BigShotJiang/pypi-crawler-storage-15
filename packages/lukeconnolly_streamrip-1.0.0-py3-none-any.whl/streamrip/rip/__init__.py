from .cli import rip

__all__ = ["rip"]
