# Weegit

[![PyPI](https://img.shields.io/pypi/v/weegit?color=blue)](https://pypi.org/project/weegit/)
[![Downloads](https://static.pepy.tech/badge/weegit)](https://pepy.tech/project/weegit)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/weegit)](https://pypi.org/project/weegit/)


# Introduction

**Weegit** is a cross-platform application for electrophysiology marking. Works with Windows/Mac/Linux.

It uses specific filesystem architecture that is maintained by the application.
```
$EXPERIMENT_weegit
├── header.json
├── lfp
│   ├── $CH_IDX.lfp
├── sessions
│   ├── $SESSION_NAME.json
```


# Weegit GUI

Run *weegit* through terminal to start GUI.

```bash
$ weegit
```


# Developers
**Weegit** has a convenient interface to work with its data.

Convert your experiment data to weegit format
```python
print(1)
```

Work with the weegit data
```python
print(2)
```


# License

The code and data files in this distribution are licensed under the terms of the GNU General Public License version 3 
as published by the Free Software Foundation. See https://www.gnu.org/licenses/ for a copy of this license.
