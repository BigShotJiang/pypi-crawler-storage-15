"""Insight Router - FastAPI routing proxy"""
__version__ = "0.1.0"

from .router import router, forward_request

__all__ = ["router", "forward_request"]
