from dataclasses import dataclass
import pandas as pd 

import tarfile
import os
import subprocess
from subprocess import Popen, PIPE, CalledProcessError
from pathlib import Path
import sys

MADGRAPH_PATH = f"../mg5amcnlo"

sys.path.append(MADGRAPH_PATH)

MG5_LATEST = '3.6.3'


def madpy_generate_script(process: str = "p p > t t~ j",
                          model: str = "sm",
                          masses: dict | None = None,
                          coupling: dict | None = None,
                          decays: dict | None = None,
                          pt_cut: dict | None = None,
                          madspin: bool = True,
                          number_events: int = 1000,
                          process_name: str = "new_process",
                          workdir_path: str = "../workdir",
                          coupled_scan: bool = True,
                          draw_diagrams: bool = True):
    
    workdir_process = f"{workdir_path}/{process_name}"
    Path(f"{workdir_process}").mkdir(parents=True, exist_ok=True)
    # Path(f"{workdir_process}/diagrams").mkdir(parents=True, exist_ok=True)

    ## First part of  the script
    mg5_script = f"""\
import model sm
import model {model}
generate {process}
output {workdir_process} -f
display diagrams {workdir_process}
launch {workdir_process}"""
    
    if masses:
        for particle, mass in masses.items():
            mg5_script += "\n\t" + f"""set mass {particle} {mass}"""
            
    if coupling:
        for coup, value in coupling.items():
            mg5_script += "\n\t" + f"""set DMINPUTS {coup} {value}"""
    
    if decays:
        for decay, value in decays.items():
            mg5_script += "\n\t" + f"""set width {decay} {value}"""
    
    if pt_cut:
        for pt, cut in pt_cut.items():
            mg5_script += "\n\t" + f"""set {pt} {cut}"""
    
    # if madspin:
    #     mg5_script += "\n\t" + f"""madspin=ON"""
    
    # else:
    #     mg5_script += "\n\t" + f"""madspin=OFF"""
        
    # Set number of events
    
    # Set Energy Beam

    # mg5_script += "\n\t" + f"""set run_card bwcutoff = 150"""
    mg5_script += "\n\t" + f"""set run_card ebeam1 = 6800"""
    mg5_script += "\n\t" + f"""set run_card ebeam2 = 6800"""
    mg5_script += "\n\t" + f"""set run_card lpp1 = 1"""
    mg5_script += "\n\t" + f"""set run_card lpp2 = 1"""
    mg5_script += "\n\t" + f"""set nevents {number_events}"""
    mg5_script += "\n\t" + f"""set run_card pdfset = NNPDF31_lo_as_0118"""
    #mg5_script += "\n\t" + f"""set run_card pta = 60"""      # minimum pt for the photons 
    #mg5_script += "\n\t" + f"""set run_card ptamax = 1000"""   # maximum pt for the photons 
    # set scale

    # if madspin:
    #     mg5_script += "\n\t" + f"""madspin=ON"""
    
    # else:
    #     mg5_script += "\n\t" + f"""madspin=OFF"""
    
    
    with open(process_name + ".mg5", "w") as script_file:
        # Write the string into the .mg5 file
        script_file.write(mg5_script)
        
    return mg5_script, process_name, workdir_process


def madpy_run(process_name: str, mg5_script_folder_path: str, mg5_bin: str = "mg5_aMC", madgraph_path = MADGRAPH_PATH):
    '''This will call MG5 and run the created script'''
    
    mg5_executable = f"{madgraph_path}/bin/{mg5_bin}"
    mg5_script_complete_path = mg5_script_folder_path + "/" + process_name + ".mg5"
    
    print(f"Check the mg5 log on {process_name}.log")
    with open(f"{process_name}.log", "w") as script_log_file:
        subprocess.run([mg5_executable, mg5_script_complete_path], stdout=script_log_file)
    
    
    
    return mg5_script_complete_path



from pathlib import Path

# Convert EPS to PDF using ghostscript
def convert_eps_to_pdf(eps_file, pdf_file=None):
    """
    Convert an EPS file to PDF using ghostscript.
    
    Args:
        eps_file (str): Path to the input EPS file
        pdf_file (str): Path to the output PDF file (optional)
                       If not provided, uses same name as eps_file with .pdf extension
    """
    if pdf_file is None:
        pdf_file = Path(eps_file).stem + '.pdf'
    
    # Ghostscript command for EPS to PDF conversion
    cmd = [
        'gs',
        '-q',                          # Quiet mode
        '-dNOPAUSE',                  # Don't pause after each page
        '-dBATCH',                    # Batch mode (exit after processing)
        '-dSAFER',                    # Safer mode
        '-sDEVICE=pdfwrite',          # Output device
        f'-sOutputFile={pdf_file}',   # Output file
        '-dEPSCrop',                  # Crop to EPS bounding box
        eps_file                      # Input file
    ]
    
    try:
        subprocess.run(cmd, check=True, capture_output=True)
        print(f"Successfully converted {eps_file} to {pdf_file}")
        return pdf_file
    except subprocess.CalledProcessError as e:
        print(f"Error during conversion: {e.stderr.decode()}")
        return None
    except FileNotFoundError:
        print("Ghostscript not found. Please install it:")
        print("  Ubuntu/Debian: sudo apt-get install ghostscript")
        print("  macOS: brew install ghostscript")
        print("  Windows: Download from https://www.ghostscript.com/download/gsdnld.html")
        return None
    
    
    
def convert_from_folder(input_folder: str, output_folder: str):
    input_path = Path(input_folder)
    
    # Validate input folder
    if not input_path.exists() or not input_path.is_dir():
        print(f"Input folder not found: {input_folder}")
        return []
    
    # Create output folder if not provided
    if output_folder is None:
        output_path = input_path / 'pdf_output'
    else:
        output_path = Path(output_folder)
    
    # Create output folder if it doesn't exist
    output_path.mkdir(parents=True, exist_ok=True)
    
    # Find all EPS files
    eps_files = list(input_path.glob('*.eps'))
    
    if not eps_files:
        print(f"No EPS files found in {input_folder}")
        return []
    
    print(f"Found {len(eps_files)} EPS file(s) to convert")
    converted_files = []
    
    # Convert each EPS file
    for eps_file in eps_files:
        pdf_file = output_path / (eps_file.stem + '.pdf')
        print(f"\nConverting: {eps_file.name} → {pdf_file.name}")
        convert_eps_to_pdf(eps_file, pdf_file)

    print(f"\n{'='*50}")
    print(f"Conversion complete! {len(converted_files)}/{len(eps_files)} files converted.")
    print(f"Output folder: {output_path}")
    print(f"{'='*50}")



def convert_eps_from_folder(input_folder: str, output_folder: str):
    input_path = Path(input_folder)
    
    # Validate input folder
    if not input_path.exists() or not input_path.is_dir():
        print(f"Input folder not found: {input_folder}")
        return []
    
    # Create output folder if not provided
    if output_folder is None:
        output_path = input_path / 'pdf_output'
    else:
        output_path = Path(output_folder)
    
    # Create output folder if it doesn't exist
    output_path.mkdir(parents=True, exist_ok=True)
    
    # Find all EPS files
    eps_files = list(input_path.glob('*.eps'))
    
    if not eps_files:
        print(f"No EPS files found in {input_folder}")
        return []
    
    print(f"Found {len(eps_files)} EPS file(s) to convert")
    converted_files = []
    
    # Convert each EPS file
    for eps_file in eps_files:
        pdf_file = output_path / (eps_file.stem + '.pdf')
        print(f"\nConverting: {eps_file.name} → {pdf_file.name}")
        convert_eps_to_pdf(eps_file, pdf_file)
        converted_files.append(str(pdf_file))

    print(f"\n{'='*50}")
    print(f"Conversion complete! {len(converted_files)}/{len(eps_files)} files converted.")
    print(f"Output folder: {output_path}")
    print(f"{'='*50}")




def unpack_events(events_path):
    # Caminho para o arquivo de saída com eventos gerados
    output_file = events_path # os.path.join(working_dir, f"{event_name}/Events/run_01/unweighted_events.lhe")
    try:
        #output_zip_file = os.path.join(working_dir, f"{event_name}/Events/run_01/unweighted_events.lhe.gz")
        subprocess.run(["gzip", "-d", "-k", output_file])
        print("Arquivo LHE descompactado com sucesso.")
        
        return Path(events_path.replace(".gz", ""))
    except FileNotFoundError:
        print('Arquivo ja foi descompactado')