"""Configs for pyrig.

All subclasses of ConfigFile in the configs package are automatically called.
"""

from types import ModuleType

from pyrig.dev import configs
from pyrig.dev.configs.base.base import InitConfigFile


class ConfigsInitConfigFile(InitConfigFile):
    """Config file for configs.py."""

    @classmethod
    def get_src_module(cls) -> ModuleType:
        """Get the source module."""
        return configs
