"""Interactive setup wizard for gmail-ai-unsub."""

from gmail_ai_unsub.setup.wizard import run_setup_wizard

__all__ = ["run_setup_wizard"]
