"""
The purpose of this App is to test the RedisMixin functionality
This app tests saving/loading, deleting of states on Redis:
"""

from testcase.app.app_constants import constants  # noqa: F401
