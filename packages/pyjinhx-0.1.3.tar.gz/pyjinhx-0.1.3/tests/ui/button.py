from pyjinhx import BaseComponent


class Button(BaseComponent):
    id: str
    text: str

