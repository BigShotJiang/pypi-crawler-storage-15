=====================
ScyllaDB Sphinx Theme
=====================

Sphinx theme for ScyllaDB documentation projects.

`Read More: <https://github.com/scylladb/sphinx-scylladb-theme>`_
