from pygments.lexers.shell import BashLexer


class DitaaLexer(BashLexer):
    pass
