# ValidationError6a07befValidationErrorElement

Model of a validation error response element.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ctx** | **Dict[str, object]** |  | [optional] 
**loc** | **List[str]** |  | 
**msg** | **str** |  | 
**type** | **str** |  | 

## Example

```python
from highway_sdk.models.validation_error6a07bef_validation_error_element import ValidationError6a07befValidationErrorElement

# TODO update the JSON string below
json = "{}"
# create an instance of ValidationError6a07befValidationErrorElement from a JSON string
validation_error6a07bef_validation_error_element_instance = ValidationError6a07befValidationErrorElement.from_json(json)
# print the JSON string representation of the object
print(ValidationError6a07befValidationErrorElement.to_json())

# convert the object into a dict
validation_error6a07bef_validation_error_element_dict = validation_error6a07bef_validation_error_element_instance.to_dict()
# create an instance of ValidationError6a07befValidationErrorElement from a dict
validation_error6a07bef_validation_error_element_from_dict = ValidationError6a07befValidationErrorElement.from_dict(validation_error6a07bef_validation_error_element_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


