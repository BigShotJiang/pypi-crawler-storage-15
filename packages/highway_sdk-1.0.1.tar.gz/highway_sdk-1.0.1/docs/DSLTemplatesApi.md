# highway_sdk.DSLTemplatesApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_api_v1_dsl_templates**](DSLTemplatesApi.md#get_api_v1_dsl_templates) | **GET** /api/v1/dsl_templates | List all available DSL templates.
[**get_api_v1_dsl_templatestemplate_name**](DSLTemplatesApi.md#get_api_v1_dsl_templatestemplate_name) | **GET** /api/v1/dsl_templates/{template_name} | Get a specific DSL template by name.
[**post_api_v1_dsl_to_json**](DSLTemplatesApi.md#post_api_v1_dsl_to_json) | **POST** /api/v1/dsl_to_json | Convert Python DSL code to JSON workflow definition.


# **get_api_v1_dsl_templates**
> get_api_v1_dsl_templates()

List all available DSL templates.

Returns:     200: List of templates with metadata     500: Error loading templates

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.DSLTemplatesApi(api_client)

    try:
        # List all available DSL templates.
        api_instance.get_api_v1_dsl_templates()
    except Exception as e:
        print("Exception when calling DSLTemplatesApi->get_api_v1_dsl_templates: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_dsl_templatestemplate_name**
> get_api_v1_dsl_templatestemplate_name(template_name)

Get a specific DSL template by name.

Args:     template_name: Template name (without .py extension)

Returns:     200: Template metadata and code     404: Template not found

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.DSLTemplatesApi(api_client)
    template_name = 'template_name_example' # str | 

    try:
        # Get a specific DSL template by name.
        api_instance.get_api_v1_dsl_templatestemplate_name(template_name)
    except Exception as e:
        print("Exception when calling DSLTemplatesApi->get_api_v1_dsl_templatestemplate_name: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **template_name** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_api_v1_dsl_to_json**
> post_api_v1_dsl_to_json()

Convert Python DSL code to JSON workflow definition.

Request Body:     {         "code": "from highway_dsl import WorkflowBuilder\n..."     }

Returns:     200: { "workflow_definition": {...} }     400: Invalid request     500: Execution error

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.DSLTemplatesApi(api_client)

    try:
        # Convert Python DSL code to JSON workflow definition.
        api_instance.post_api_v1_dsl_to_json()
    except Exception as e:
        print("Exception when calling DSLTemplatesApi->post_api_v1_dsl_to_json: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

