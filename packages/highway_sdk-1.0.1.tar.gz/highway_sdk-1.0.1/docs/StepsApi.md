# highway_sdk.StepsApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_api_v1_workflowsworkflow_run_id_steps**](StepsApi.md#get_api_v1_workflowsworkflow_run_id_steps) | **GET** /api/v1/workflows/{workflow_run_id}/steps | List all steps in a workflow with their status.
[**get_api_v1_workflowsworkflow_run_id_steps_logs**](StepsApi.md#get_api_v1_workflowsworkflow_run_id_steps_logs) | **GET** /api/v1/workflows/{workflow_run_id}/steps/logs | Get DataShard logs for all steps in a workflow.
[**get_api_v1_workflowsworkflow_run_id_stepsstep_name**](StepsApi.md#get_api_v1_workflowsworkflow_run_id_stepsstep_name) | **GET** /api/v1/workflows/{workflow_run_id}/steps/{step_name} | Get detailed information about a specific step.
[**get_api_v1_workflowsworkflow_run_id_stepsstep_name_logs**](StepsApi.md#get_api_v1_workflowsworkflow_run_id_stepsstep_name_logs) | **GET** /api/v1/workflows/{workflow_run_id}/steps/{step_name}/logs | Get DataShard logs for a specific step.


# **get_api_v1_workflowsworkflow_run_id_steps**
> get_api_v1_workflowsworkflow_run_id_steps(workflow_run_id)

List all steps in a workflow with their status.

Path Parameters:     workflow_run_id: Workflow run ID (UUID)

Query Parameters:     status (optional): Filter by step status (succeeded, failed, sleeping)

Returns:     200: List of workflow steps     404: Workflow not found     500: Failed to query steps

Response:     {         "success": true,         "data": {             "workflow_run_id": "abc123",             "workflow_name": "video_processing",             "steps": [                 {                     "step_name": "download_video",                     "status": "succeeded",                     "started_at": "2025-11-17T10:00:00Z",                     "completed_at": "2025-11-17T10:00:15Z",                     "duration_seconds": 15.2,                     "retry_count": 0,                     "has_checkpoint": true                 }             ],             "total_steps": 15,             "succeeded": 14,             "failed": 1,             "sleeping": 0         }     }

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.StepsApi(api_client)
    workflow_run_id = 'workflow_run_id_example' # str | 

    try:
        # List all steps in a workflow with their status.
        api_instance.get_api_v1_workflowsworkflow_run_id_steps(workflow_run_id)
    except Exception as e:
        print("Exception when calling StepsApi->get_api_v1_workflowsworkflow_run_id_steps: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_run_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_workflowsworkflow_run_id_steps_logs**
> get_api_v1_workflowsworkflow_run_id_steps_logs(workflow_run_id)

Get DataShard logs for all steps in a workflow.

Uses partitioned storage: data/<tenant_id>/<workflow_run_id>/task_logs/ Direct path lookup - no scanning required.

Path Parameters:     workflow_run_id: Workflow run ID (UUID)

Query Parameters:     step_name (optional): Filter logs by specific step name

Returns:     200: List of step logs from DataShard     404: Workflow not found     500: Failed to query logs

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.StepsApi(api_client)
    workflow_run_id = 'workflow_run_id_example' # str | 

    try:
        # Get DataShard logs for all steps in a workflow.
        api_instance.get_api_v1_workflowsworkflow_run_id_steps_logs(workflow_run_id)
    except Exception as e:
        print("Exception when calling StepsApi->get_api_v1_workflowsworkflow_run_id_steps_logs: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_run_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_workflowsworkflow_run_id_stepsstep_name**
> get_api_v1_workflowsworkflow_run_id_stepsstep_name(workflow_run_id, step_name)

Get detailed information about a specific step.

Path Parameters:     workflow_run_id: Workflow run ID (UUID)     step_name: Step name

Returns:     200: Step details     404: Workflow or step not found     500: Failed to query step

Response:     {         "success": true,         "data": {             "step_name": "download_video",             "status": "succeeded",             "started_at": "2025-11-17T10:00:00Z",             "completed_at": "2025-11-17T10:00:15Z",             "duration_seconds": 15.2,             "retry_count": 2,             "checkpoint_data": {...},             "events": [                 {                     "event_type": "step_started",                     "timestamp": "2025-11-17T10:00:00Z",                     "payload": {...}                 }             ]         }     }

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.StepsApi(api_client)
    workflow_run_id = 'workflow_run_id_example' # str | 
    step_name = 'step_name_example' # str | 

    try:
        # Get detailed information about a specific step.
        api_instance.get_api_v1_workflowsworkflow_run_id_stepsstep_name(workflow_run_id, step_name)
    except Exception as e:
        print("Exception when calling StepsApi->get_api_v1_workflowsworkflow_run_id_stepsstep_name: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_run_id** | **str**|  | 
 **step_name** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_workflowsworkflow_run_id_stepsstep_name_logs**
> get_api_v1_workflowsworkflow_run_id_stepsstep_name_logs(workflow_run_id, step_name)

Get DataShard logs for a specific step.

Uses partitioned storage: data/<tenant_id>/<workflow_run_id>/task_logs/ Direct path lookup - no scanning required.

Path Parameters:     workflow_run_id: Workflow run ID (UUID)     step_name: Step/task name

Returns:     200: Step log from DataShard     404: Workflow or step log not found     500: Failed to query logs

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.StepsApi(api_client)
    workflow_run_id = 'workflow_run_id_example' # str | 
    step_name = 'step_name_example' # str | 

    try:
        # Get DataShard logs for a specific step.
        api_instance.get_api_v1_workflowsworkflow_run_id_stepsstep_name_logs(workflow_run_id, step_name)
    except Exception as e:
        print("Exception when calling StepsApi->get_api_v1_workflowsworkflow_run_id_stepsstep_name_logs: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_run_id** | **str**|  | 
 **step_name** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

