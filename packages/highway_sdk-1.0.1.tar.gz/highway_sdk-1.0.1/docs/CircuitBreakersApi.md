# highway_sdk.CircuitBreakersApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_api_v1_circuit_breakers**](CircuitBreakersApi.md#get_api_v1_circuit_breakers) | **GET** /api/v1/circuit-breakers | List all circuit breakers with their current state.
[**get_api_v1_circuit_breakersresource_key**](CircuitBreakersApi.md#get_api_v1_circuit_breakersresource_key) | **GET** /api/v1/circuit-breakers/{resource_key} | Get specific circuit breaker status.
[**post_api_v1_circuit_breakers_reset**](CircuitBreakersApi.md#post_api_v1_circuit_breakers_reset) | **POST** /api/v1/circuit-breakers/reset | Reset circuit breaker caches in all workers.
[**post_api_v1_circuit_breakersresource_key_reset**](CircuitBreakersApi.md#post_api_v1_circuit_breakersresource_key_reset) | **POST** /api/v1/circuit-breakers/{resource_key}/reset | Reset specific circuit breaker in database.


# **get_api_v1_circuit_breakers**
> get_api_v1_circuit_breakers()

List all circuit breakers with their current state.

Query Parameters:     state (optional): Filter by state (OPEN, CLOSED, HALF_OPEN)

Returns:     200: List of circuit breakers     500: Database error     503: Circuit breaker database unavailable

Response:     {         "success": true,         "data": {             "circuit_breakers": [                 {                     "resource_key": "http_request",                     "state": "CLOSED",                     "failure_count": 0,                     "open_until": null,                     "created_at": "2025-11-17T10:00:00Z",                     "updated_at": "2025-11-17T10:30:00Z",                     "seconds_until_reopen": null                 }             ],             "summary": {                 "total": 4,                 "open": 0,                 "closed": 4,                 "half_open": 0             }         }     }

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.CircuitBreakersApi(api_client)

    try:
        # List all circuit breakers with their current state.
        api_instance.get_api_v1_circuit_breakers()
    except Exception as e:
        print("Exception when calling CircuitBreakersApi->get_api_v1_circuit_breakers: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_circuit_breakersresource_key**
> get_api_v1_circuit_breakersresource_key(resource_key)

Get specific circuit breaker status.

Path Parameters:     resource_key: Circuit breaker resource key (e.g., 'http_request', 'shell_command')

Returns:     200: Circuit breaker details     404: Circuit breaker not found     500: Database error     503: Circuit breaker database unavailable

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.CircuitBreakersApi(api_client)
    resource_key = 'resource_key_example' # str | 

    try:
        # Get specific circuit breaker status.
        api_instance.get_api_v1_circuit_breakersresource_key(resource_key)
    except Exception as e:
        print("Exception when calling CircuitBreakersApi->get_api_v1_circuit_breakersresource_key: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **resource_key** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_api_v1_circuit_breakers_reset**
> post_api_v1_circuit_breakers_reset()

Reset circuit breaker caches in all workers.

This writes a flag file that workers check on each circuit breaker access. Workers will clear their in-memory circuit breaker caches when they detect the flag file has been updated.

Use this when you want workers to reload circuit breaker state from the database, particularly useful for test isolation after database cleanup.

Returns:     200: Cache reset signal sent     500: Failed to write reset flag

Response:     {         "success": true,         "data": {             "message": "Circuit breaker cache reset signal sent",             "flag_file": "/tmp/.highway_reset_circuit_breaker_cache",             "timestamp": "2025-11-17T10:30:00Z"         }     }

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.CircuitBreakersApi(api_client)

    try:
        # Reset circuit breaker caches in all workers.
        api_instance.post_api_v1_circuit_breakers_reset()
    except Exception as e:
        print("Exception when calling CircuitBreakersApi->post_api_v1_circuit_breakers_reset: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_api_v1_circuit_breakersresource_key_reset**
> post_api_v1_circuit_breakersresource_key_reset(resource_key)

Reset specific circuit breaker in database.

This deletes the circuit breaker record from the database, allowing it to be recreated with a clean state on the next access.

Note: Also sends cache reset signal to workers.

Path Parameters:     resource_key: Circuit breaker resource key to reset

Returns:     200: Circuit breaker reset     404: Circuit breaker not found     500: Database error     503: Circuit breaker database unavailable

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.CircuitBreakersApi(api_client)
    resource_key = 'resource_key_example' # str | 

    try:
        # Reset specific circuit breaker in database.
        api_instance.post_api_v1_circuit_breakersresource_key_reset(resource_key)
    except Exception as e:
        print("Exception when calling CircuitBreakersApi->post_api_v1_circuit_breakersresource_key_reset: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **resource_key** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

