# SuccessResponseInvitationListResponseE7ebca9InvitationResponse

Invitation details response.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accepted_at** | **datetime** |  | [optional] 
**created_at** | **datetime** |  | [optional] 
**email** | **str** | Invitee email | 
**expires_at** | **datetime** |  | [optional] 
**invitation_id** | **str** | Invitation ID (UUID) | 
**invited_by** | **str** |  | [optional] 
**role** | **str** | Assigned role | 
**status** | [**SuccessResponseInvitationListResponseE7ebca9InvitationStatus**](SuccessResponseInvitationListResponseE7ebca9InvitationStatus.md) | Invitation status | 

## Example

```python
from highway_sdk.models.success_response_invitation_list_response_e7ebca9_invitation_response import SuccessResponseInvitationListResponseE7ebca9InvitationResponse

# TODO update the JSON string below
json = "{}"
# create an instance of SuccessResponseInvitationListResponseE7ebca9InvitationResponse from a JSON string
success_response_invitation_list_response_e7ebca9_invitation_response_instance = SuccessResponseInvitationListResponseE7ebca9InvitationResponse.from_json(json)
# print the JSON string representation of the object
print(SuccessResponseInvitationListResponseE7ebca9InvitationResponse.to_json())

# convert the object into a dict
success_response_invitation_list_response_e7ebca9_invitation_response_dict = success_response_invitation_list_response_e7ebca9_invitation_response_instance.to_dict()
# create an instance of SuccessResponseInvitationListResponseE7ebca9InvitationResponse from a dict
success_response_invitation_list_response_e7ebca9_invitation_response_from_dict = SuccessResponseInvitationListResponseE7ebca9InvitationResponse.from_dict(success_response_invitation_list_response_e7ebca9_invitation_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


