# SuccessResponseTokenResponseE7ebca9TokenResponse

Token details response (without secret).

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**created_at** | **datetime** |  | [optional] 
**expires_at** | **datetime** |  | [optional] 
**last_used_at** | **datetime** |  | [optional] 
**name** | **str** | Token name | 
**permissions** | **List[str]** | Permissions | [optional] 
**status** | [**SuccessResponseTokenResponseE7ebca9TokenStatus**](SuccessResponseTokenResponseE7ebca9TokenStatus.md) | Token status | 
**token_id** | **str** | Token ID (UUID) | 
**user_email** | **str** | Owner email | 

## Example

```python
from highway_sdk.models.success_response_token_response_e7ebca9_token_response import SuccessResponseTokenResponseE7ebca9TokenResponse

# TODO update the JSON string below
json = "{}"
# create an instance of SuccessResponseTokenResponseE7ebca9TokenResponse from a JSON string
success_response_token_response_e7ebca9_token_response_instance = SuccessResponseTokenResponseE7ebca9TokenResponse.from_json(json)
# print the JSON string representation of the object
print(SuccessResponseTokenResponseE7ebca9TokenResponse.to_json())

# convert the object into a dict
success_response_token_response_e7ebca9_token_response_dict = success_response_token_response_e7ebca9_token_response_instance.to_dict()
# create an instance of SuccessResponseTokenResponseE7ebca9TokenResponse from a dict
success_response_token_response_e7ebca9_token_response_from_dict = SuccessResponseTokenResponseE7ebca9TokenResponse.from_dict(success_response_token_response_e7ebca9_token_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


