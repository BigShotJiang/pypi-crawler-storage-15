# SuccessResponseInvitationAcceptResponseE7ebca9InvitationAcceptResponse

Response after accepting invitation.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**access_token** | **str** |  | [optional] 
**email** | **str** | User email | 
**message** | **str** | Status message | 
**role** | **str** | Assigned role | 
**tenant_id** | **str** | Tenant ID | 

## Example

```python
from highway_sdk.models.success_response_invitation_accept_response_e7ebca9_invitation_accept_response import SuccessResponseInvitationAcceptResponseE7ebca9InvitationAcceptResponse

# TODO update the JSON string below
json = "{}"
# create an instance of SuccessResponseInvitationAcceptResponseE7ebca9InvitationAcceptResponse from a JSON string
success_response_invitation_accept_response_e7ebca9_invitation_accept_response_instance = SuccessResponseInvitationAcceptResponseE7ebca9InvitationAcceptResponse.from_json(json)
# print the JSON string representation of the object
print(SuccessResponseInvitationAcceptResponseE7ebca9InvitationAcceptResponse.to_json())

# convert the object into a dict
success_response_invitation_accept_response_e7ebca9_invitation_accept_response_dict = success_response_invitation_accept_response_e7ebca9_invitation_accept_response_instance.to_dict()
# create an instance of SuccessResponseInvitationAcceptResponseE7ebca9InvitationAcceptResponse from a dict
success_response_invitation_accept_response_e7ebca9_invitation_accept_response_from_dict = SuccessResponseInvitationAcceptResponseE7ebca9InvitationAcceptResponse.from_dict(success_response_invitation_accept_response_e7ebca9_invitation_accept_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


