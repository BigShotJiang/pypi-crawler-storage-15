# highway_sdk.SchedulesApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**delete_api_v1_schedulesschedule_id**](SchedulesApi.md#delete_api_v1_schedulesschedule_id) | **DELETE** /api/v1/schedules/{schedule_id} | Delete a workflow schedule.
[**get_api_v1_schedules**](SchedulesApi.md#get_api_v1_schedules) | **GET** /api/v1/schedules | List all workflow schedules.
[**get_api_v1_schedulesschedule_id**](SchedulesApi.md#get_api_v1_schedulesschedule_id) | **GET** /api/v1/schedules/{schedule_id} | Get specific schedule status and details.
[**get_api_v1_schedulesschedule_id_history**](SchedulesApi.md#get_api_v1_schedulesschedule_id_history) | **GET** /api/v1/schedules/{schedule_id}/history | Get schedule execution history.
[**patch_api_v1_schedulesschedule_id**](SchedulesApi.md#patch_api_v1_schedulesschedule_id) | **PATCH** /api/v1/schedules/{schedule_id} | Update a workflow schedule (pause/resume).
[**post_api_v1_schedules**](SchedulesApi.md#post_api_v1_schedules) | **POST** /api/v1/schedules | Create a new workflow schedule using durable_cron.
[**post_api_v1_schedules_scan**](SchedulesApi.md#post_api_v1_schedules_scan) | **POST** /api/v1/schedules/scan | DEPRECATED: Manual schedule scanning not needed with durable_cron.


# **delete_api_v1_schedulesschedule_id**
> delete_api_v1_schedulesschedule_id(schedule_id)

Delete a workflow schedule.

**RBAC Permission:** `manage_workflows`

This marks the schedule as inactive and cancels any active durable_cron tasks associated with this schedule.

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.SchedulesApi(api_client)
    schedule_id = 'schedule_id_example' # str | 

    try:
        # Delete a workflow schedule.
        api_instance.delete_api_v1_schedulesschedule_id(schedule_id)
    except Exception as e:
        print("Exception when calling SchedulesApi->delete_api_v1_schedulesschedule_id: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **schedule_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_schedules**
> get_api_v1_schedules()

List all workflow schedules.

**RBAC Permission:** `view_workflows`

Note: Schedules are managed by durable_cron workflows which register themselves in the workflow_schedules table.

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.SchedulesApi(api_client)

    try:
        # List all workflow schedules.
        api_instance.get_api_v1_schedules()
    except Exception as e:
        print("Exception when calling SchedulesApi->get_api_v1_schedules: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_schedulesschedule_id**
> get_api_v1_schedulesschedule_id(schedule_id)

Get specific schedule status and details.

**RBAC Permission:** `view_workflows`

Path Parameters:     schedule_id: Schedule UUID

Returns:     200: Schedule details including next run time     404: Schedule not found     500: Server error

Response:     {         "schedule_id": "abc123",         "workflow_name": "daily_report",         "schedule_cron": "0 9 * * *",         "is_active": true,         "last_run_at": "2025-11-17T09:00:00Z",         "next_run_at": "2025-11-18T09:00:00Z",         "created_at": "2025-11-01T10:00:00Z",         "timezone": "UTC",         "execution_count": 15,         "last_error": null     }

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.SchedulesApi(api_client)
    schedule_id = 'schedule_id_example' # str | 

    try:
        # Get specific schedule status and details.
        api_instance.get_api_v1_schedulesschedule_id(schedule_id)
    except Exception as e:
        print("Exception when calling SchedulesApi->get_api_v1_schedulesschedule_id: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **schedule_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_schedulesschedule_id_history**
> get_api_v1_schedulesschedule_id_history(schedule_id)

Get schedule execution history.

**RBAC Permission:** `view_workflows`

Path Parameters:     schedule_id: Schedule UUID

Query Parameters:     limit (int, optional): Max results (default: 50, max: 100)     offset (int, optional): Pagination offset (default: 0)

Returns:     200: Execution history     404: Schedule not found     500: Server error

Response:     {         "schedule_id": "abc123",         "workflow_name": "daily_report",         "executions": [             {                 "workflow_run_id": "def456",                 "run_id": "ghi789",                 "status": "completed",                 "started_at": "2025-11-17T09:00:00Z",                 "completed_at": "2025-11-17T09:05:30Z",                 "duration_seconds": 330             }         ],         "total": 15,         "limit": 50,         "offset": 0     }

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.SchedulesApi(api_client)
    schedule_id = 'schedule_id_example' # str | 

    try:
        # Get schedule execution history.
        api_instance.get_api_v1_schedulesschedule_id_history(schedule_id)
    except Exception as e:
        print("Exception when calling SchedulesApi->get_api_v1_schedulesschedule_id_history: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **schedule_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **patch_api_v1_schedulesschedule_id**
> patch_api_v1_schedulesschedule_id(schedule_id)

Update a workflow schedule (pause/resume).

**RBAC Permission:** `manage_workflows`

**Architecture (Issue #19):** - Pause: Marks schedule inactive + cancels sleeping durable_cron tasks - Resume: Marks schedule active + spawns new durable_cron workflow

Path Parameters:     schedule_id: Schedule UUID

Request Body:     {         "is_active": true/false  # Pause or resume schedule     }

Returns:     200: Schedule updated     400: Invalid request     404: Schedule not found     500: Server error

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.SchedulesApi(api_client)
    schedule_id = 'schedule_id_example' # str | 

    try:
        # Update a workflow schedule (pause/resume).
        api_instance.patch_api_v1_schedulesschedule_id(schedule_id)
    except Exception as e:
        print("Exception when calling SchedulesApi->patch_api_v1_schedulesschedule_id: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **schedule_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_api_v1_schedules**
> post_api_v1_schedules()

Create a new workflow schedule using durable_cron.

**RBAC Permission:** `submit_workflows`

**Architecture (Issue #19):** This endpoint spawns a durable_cron workflow that schedules the target workflow. durable_cron is atomic, crash-safe, and self-managing (no external daemon needed).

Request accepts multiple modes: 1. definition_id or definition_hash (reference existing definition) 2. workflow_name (lookup latest version in DB, or load from module) 3. workflow_definition (JSON, creates/reuses definition via content-addressable storage)

Request Body:     {         "definition_id": "uuid",           # Option 1a: Reference by ID         "definition_hash": "sha256",       # Option 1b: Reference by Hash         "version_pin": 2,                  # Optional: Pin to specific version (default: use latest)         "workflow_name": "my_workflow",    # Option 2: Load by name (DB first, then module)         "workflow_definition": {...},      # Option 3: Provide JSON definition         "schedule_cron": "*/5 * * * *",    # Required: Cron expression         "inputs": {...},                   # Optional: Default inputs for runs         "timezone": "UTC",                 # Optional: Timezone (default: UTC)     }

Returns:     201: Schedule created (durable_cron workflow spawned)     400: Invalid request     500: Server error

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.SchedulesApi(api_client)

    try:
        # Create a new workflow schedule using durable_cron.
        api_instance.post_api_v1_schedules()
    except Exception as e:
        print("Exception when calling SchedulesApi->post_api_v1_schedules: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_api_v1_schedules_scan**
> post_api_v1_schedules_scan()

DEPRECATED: Manual schedule scanning not needed with durable_cron.

**RBAC Permission:** `manage_workflows`

Note (Issue #19): This endpoint is deprecated. With durable_cron-based scheduling, workflows are automatically scheduled by the durable_cron workflow itself. No external scanning/polling is required.

Returns:     200: Message indicating durable_cron handles scheduling

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.SchedulesApi(api_client)

    try:
        # DEPRECATED: Manual schedule scanning not needed with durable_cron.
        api_instance.post_api_v1_schedules_scan()
    except Exception as e:
        print("Exception when calling SchedulesApi->post_api_v1_schedules_scan: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

