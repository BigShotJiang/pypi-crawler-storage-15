# highway_sdk.AnalyticsApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_api_v1_analytics_events**](AnalyticsApi.md#get_api_v1_analytics_events) | **GET** /api/v1/analytics/events | Get event timeline for analytics.
[**get_api_v1_analytics_performance**](AnalyticsApi.md#get_api_v1_analytics_performance) | **GET** /api/v1/analytics/performance | Get workflow performance metrics.
[**get_api_v1_analytics_queues**](AnalyticsApi.md#get_api_v1_analytics_queues) | **GET** /api/v1/analytics/queues | List all queues with health metrics.
[**get_api_v1_analytics_queuesqueue_name**](AnalyticsApi.md#get_api_v1_analytics_queuesqueue_name) | **GET** /api/v1/analytics/queues/{queue_name} | Get detailed analytics for a specific queue.
[**get_api_v1_analytics_tasks_distribution**](AnalyticsApi.md#get_api_v1_analytics_tasks_distribution) | **GET** /api/v1/analytics/tasks/distribution | Get task state distribution across all queues.
[**get_api_v1_analytics_tasks_list**](AnalyticsApi.md#get_api_v1_analytics_tasks_list) | **GET** /api/v1/analytics/tasks/list | List all tasks with detailed information.


# **get_api_v1_analytics_events**
> get_api_v1_analytics_events()

Get event timeline for analytics.

Query Parameters:     workflow_run_id: Filter by specific workflow run (optional)     event_type: Filter by event type (optional)     hours: Time window in hours (default: 24)     limit: Max results (default: 100, max: 1000)

Returns:     200: Event timeline     500: Database error

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.AnalyticsApi(api_client)

    try:
        # Get event timeline for analytics.
        api_instance.get_api_v1_analytics_events()
    except Exception as e:
        print("Exception when calling AnalyticsApi->get_api_v1_analytics_events: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_analytics_performance**
> get_api_v1_analytics_performance()

Get workflow performance metrics.

Query Parameters:     days: Time window in days (default: 7)     workflow_name: Filter by workflow name (optional)

Returns:     200: Performance metrics (avg duration, success rate, etc.)     500: Database error

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.AnalyticsApi(api_client)

    try:
        # Get workflow performance metrics.
        api_instance.get_api_v1_analytics_performance()
    except Exception as e:
        print("Exception when calling AnalyticsApi->get_api_v1_analytics_performance: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_analytics_queues**
> get_api_v1_analytics_queues()

List all queues with health metrics.

Query Parameters:     tenant_id: Filter by tenant (default: from g.tenant_id)

Returns:     200: Queue health metrics     500: Database error

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.AnalyticsApi(api_client)

    try:
        # List all queues with health metrics.
        api_instance.get_api_v1_analytics_queues()
    except Exception as e:
        print("Exception when calling AnalyticsApi->get_api_v1_analytics_queues: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_analytics_queuesqueue_name**
> get_api_v1_analytics_queuesqueue_name(queue_name)

Get detailed analytics for a specific queue.

Path Parameters:     queue_name: Queue name (workflow name)

Returns:     200: Queue analytics     500: Database error

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.AnalyticsApi(api_client)
    queue_name = 'queue_name_example' # str | 

    try:
        # Get detailed analytics for a specific queue.
        api_instance.get_api_v1_analytics_queuesqueue_name(queue_name)
    except Exception as e:
        print("Exception when calling AnalyticsApi->get_api_v1_analytics_queuesqueue_name: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **queue_name** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_analytics_tasks_distribution**
> get_api_v1_analytics_tasks_distribution()

Get task state distribution across all queues.

Query Parameters:     days: Filter by last N days (default: 30)

Returns:     200: Task distribution by state and queue     500: Database error

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.AnalyticsApi(api_client)

    try:
        # Get task state distribution across all queues.
        api_instance.get_api_v1_analytics_tasks_distribution()
    except Exception as e:
        print("Exception when calling AnalyticsApi->get_api_v1_analytics_tasks_distribution: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_analytics_tasks_list**
> get_api_v1_analytics_tasks_list()

List all tasks with detailed information.

Query Parameters:     queue_name: Filter by queue (workflow name)     status: Filter by status     limit: Max results (default: 100, max: 1000)     offset: Pagination offset (default: 0)

Returns:     200: Task list     500: Database error

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.AnalyticsApi(api_client)

    try:
        # List all tasks with detailed information.
        api_instance.get_api_v1_analytics_tasks_list()
    except Exception as e:
        print("Exception when calling AnalyticsApi->get_api_v1_analytics_tasks_list: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

