# ErrorResponseE7ebca9ErrorDetail

Detailed error information.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **str** |  | [optional] 
**var_field** | **str** |  | [optional] 
**message** | **str** | Error message | 

## Example

```python
from highway_sdk.models.error_response_e7ebca9_error_detail import ErrorResponseE7ebca9ErrorDetail

# TODO update the JSON string below
json = "{}"
# create an instance of ErrorResponseE7ebca9ErrorDetail from a JSON string
error_response_e7ebca9_error_detail_instance = ErrorResponseE7ebca9ErrorDetail.from_json(json)
# print the JSON string representation of the object
print(ErrorResponseE7ebca9ErrorDetail.to_json())

# convert the object into a dict
error_response_e7ebca9_error_detail_dict = error_response_e7ebca9_error_detail_instance.to_dict()
# create an instance of ErrorResponseE7ebca9ErrorDetail from a dict
error_response_e7ebca9_error_detail_from_dict = ErrorResponseE7ebca9ErrorDetail.from_dict(error_response_e7ebca9_error_detail_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


