# highway_sdk.WorkflowsApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_api_v1_workflows**](WorkflowsApi.md#get_api_v1_workflows) | **GET** /api/v1/workflows | List workflows with pagination and filtering.
[**get_api_v1_workflowsworkflow_run_id**](WorkflowsApi.md#get_api_v1_workflowsworkflow_run_id) | **GET** /api/v1/workflows/{workflow_run_id} | Get workflow details by ID.
[**get_api_v1_workflowsworkflow_run_id_checkpoints**](WorkflowsApi.md#get_api_v1_workflowsworkflow_run_id_checkpoints) | **GET** /api/v1/workflows/{workflow_run_id}/checkpoints | Get workflow step checkpoints.
[**get_api_v1_workflowsworkflow_run_id_events**](WorkflowsApi.md#get_api_v1_workflowsworkflow_run_id_events) | **GET** /api/v1/workflows/{workflow_run_id}/events | Get workflow audit log events.
[**get_api_v1_workflowsworkflow_run_id_graph**](WorkflowsApi.md#get_api_v1_workflowsworkflow_run_id_graph) | **GET** /api/v1/workflows/{workflow_run_id}/graph | Get workflow graph visualization in Mermaid format.
[**get_api_v1_workflowsworkflow_run_id_graph_dot**](WorkflowsApi.md#get_api_v1_workflowsworkflow_run_id_graph_dot) | **GET** /api/v1/workflows/{workflow_run_id}/graph/dot | Get workflow graph in DOT format with execution steps.
[**get_api_v1_workflowsworkflow_run_id_locks**](WorkflowsApi.md#get_api_v1_workflowsworkflow_run_id_locks) | **GET** /api/v1/workflows/{workflow_run_id}/locks | Get distributed lock history for a workflow run.
[**get_api_v1_workflowsworkflow_run_id_sagas**](WorkflowsApi.md#get_api_v1_workflowsworkflow_run_id_sagas) | **GET** /api/v1/workflows/{workflow_run_id}/sagas | Get saga/compensation history for a workflow run.
[**post_api_v1_workflows**](WorkflowsApi.md#post_api_v1_workflows) | **POST** /api/v1/workflows | Submit a new workflow for execution.
[**post_api_v1_workflowsworkflow_run_id_cancel**](WorkflowsApi.md#post_api_v1_workflowsworkflow_run_id_cancel) | **POST** /api/v1/workflows/{workflow_run_id}/cancel | Cancel a running workflow.
[**post_api_v1_workflowsworkflow_run_id_retry**](WorkflowsApi.md#post_api_v1_workflowsworkflow_run_id_retry) | **POST** /api/v1/workflows/{workflow_run_id}/retry | Retry a failed workflow from the beginning.


# **get_api_v1_workflows**
> get_api_v1_workflows()

List workflows with pagination and filtering.

**RBAC Permission:** `view_workflows`

Query Parameters:     page: Page number (default: 1)     page_size: Items per page (default: 20, max: 100)     status: Filter by status (pending, running, sleeping, completed, failed)     days: Filter by last N days (optional, overrides pagination if provided)

Returns:     200: List of workflows     400: Invalid parameters     500: Internal server error

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.WorkflowsApi(api_client)

    try:
        # List workflows with pagination and filtering.
        api_instance.get_api_v1_workflows()
    except Exception as e:
        print("Exception when calling WorkflowsApi->get_api_v1_workflows: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_workflowsworkflow_run_id**
> get_api_v1_workflowsworkflow_run_id(workflow_run_id)

Get workflow details by ID.

**RBAC Permission:** `view_workflows`

Args:     workflow_run_id: Workflow run ID (UUID)

Returns:     200: Workflow details     400: Invalid UUID     404: Workflow not found     500: Internal server error

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.WorkflowsApi(api_client)
    workflow_run_id = 'workflow_run_id_example' # str | 

    try:
        # Get workflow details by ID.
        api_instance.get_api_v1_workflowsworkflow_run_id(workflow_run_id)
    except Exception as e:
        print("Exception when calling WorkflowsApi->get_api_v1_workflowsworkflow_run_id: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_run_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_workflowsworkflow_run_id_checkpoints**
> get_api_v1_workflowsworkflow_run_id_checkpoints(workflow_run_id)

Get workflow step checkpoints.

**RBAC Permission:** `view_workflows`

Args:     workflow_run_id: Workflow run ID (UUID)

Returns:     200: Checkpoints data     400: Invalid UUID     404: Workflow not found     500: Internal server error

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.WorkflowsApi(api_client)
    workflow_run_id = 'workflow_run_id_example' # str | 

    try:
        # Get workflow step checkpoints.
        api_instance.get_api_v1_workflowsworkflow_run_id_checkpoints(workflow_run_id)
    except Exception as e:
        print("Exception when calling WorkflowsApi->get_api_v1_workflowsworkflow_run_id_checkpoints: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_run_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_workflowsworkflow_run_id_events**
> get_api_v1_workflowsworkflow_run_id_events(workflow_run_id)

Get workflow audit log events.

**RBAC Permission:** `view_workflows`

Args:     workflow_run_id: Workflow run ID (UUID)

Query Parameters:     limit: Maximum number of events (default: 100, max: 1000)

Returns:     200: List of events     400: Invalid UUID     404: Workflow not found     500: Internal server error

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.WorkflowsApi(api_client)
    workflow_run_id = 'workflow_run_id_example' # str | 

    try:
        # Get workflow audit log events.
        api_instance.get_api_v1_workflowsworkflow_run_id_events(workflow_run_id)
    except Exception as e:
        print("Exception when calling WorkflowsApi->get_api_v1_workflowsworkflow_run_id_events: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_run_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_workflowsworkflow_run_id_graph**
> get_api_v1_workflowsworkflow_run_id_graph(workflow_run_id)

Get workflow graph visualization in Mermaid format.

**RBAC Permission:** `view_workflows`

Args:     workflow_run_id: Workflow run ID (UUID)

Returns:     200: Mermaid graph definition from workflow definition     400: Invalid UUID     404: Workflow not found     500: Internal server error

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.WorkflowsApi(api_client)
    workflow_run_id = 'workflow_run_id_example' # str | 

    try:
        # Get workflow graph visualization in Mermaid format.
        api_instance.get_api_v1_workflowsworkflow_run_id_graph(workflow_run_id)
    except Exception as e:
        print("Exception when calling WorkflowsApi->get_api_v1_workflowsworkflow_run_id_graph: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_run_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_workflowsworkflow_run_id_graph_dot**
> get_api_v1_workflowsworkflow_run_id_graph_dot(workflow_run_id)

Get workflow graph in DOT format with execution steps.

**RBAC Permission:** `view_workflows`

This endpoint returns a Graphviz DOT file that shows: - Workflow definition tasks as subgraphs/clusters - Execution steps inside their parent tasks - Status coloring (green=succeeded, red=failed, orange=sleeping, blue=running) - Parallel branches and dependencies

Args:     workflow_run_id: Workflow run ID (UUID)

Returns:     200: DOT graph definition with execution details     400: Invalid UUID     404: Workflow not found     500: Internal server error

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.WorkflowsApi(api_client)
    workflow_run_id = 'workflow_run_id_example' # str | 

    try:
        # Get workflow graph in DOT format with execution steps.
        api_instance.get_api_v1_workflowsworkflow_run_id_graph_dot(workflow_run_id)
    except Exception as e:
        print("Exception when calling WorkflowsApi->get_api_v1_workflowsworkflow_run_id_graph_dot: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_run_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_workflowsworkflow_run_id_locks**
> get_api_v1_workflowsworkflow_run_id_locks(workflow_run_id)

Get distributed lock history for a workflow run.

**RBAC Permission:** `view_workflows`

Returns all lock events (acquired, released, failed) for the workflow, useful for debugging lock contention and deadlocks.

Args:     workflow_run_id: Workflow run ID (UUID)

Returns:     200: List of lock events     400: Invalid UUID     404: Workflow not found     500: Internal server error

Example Response:     {         "status": "success",         "data": {             "workflow_run_id": "...",             "locks": [                 {                     "event_type": "lock_acquired",                     "lock_name": "resource_123",                     "timestamp": "...",                     "details": {"timeout_seconds": 30}                 },                 {                     "event_type": "lock_released",                     "lock_name": "resource_123",                     "timestamp": "...",                     "details": {"held_duration_ms": 1500}                 }             ],             "total_locks": 2,             "active_locks": []         }     }

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.WorkflowsApi(api_client)
    workflow_run_id = 'workflow_run_id_example' # str | 

    try:
        # Get distributed lock history for a workflow run.
        api_instance.get_api_v1_workflowsworkflow_run_id_locks(workflow_run_id)
    except Exception as e:
        print("Exception when calling WorkflowsApi->get_api_v1_workflowsworkflow_run_id_locks: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_run_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_workflowsworkflow_run_id_sagas**
> get_api_v1_workflowsworkflow_run_id_sagas(workflow_run_id)

Get saga/compensation history for a workflow run.

**RBAC Permission:** `view_workflows`

Returns all saga events (started, completed, compensation steps) for the workflow, useful for debugging transaction rollbacks.

Args:     workflow_run_id: Workflow run ID (UUID)

Returns:     200: List of saga events     400: Invalid UUID     404: Workflow not found     500: Internal server error

Example Response:     {         "status": "success",         "data": {             "workflow_run_id": "...",             "sagas": [                 {                     "saga_name": "payment_saga",                     "status": "completed",                     "started_at": "...",                     "completed_at": "...",                     "compensated": false,                     "steps": []                 }             ],             "compensation_events": [                 {                     "event_type": "compensation_started",                     "saga_name": "payment_saga",                     "timestamp": "...",                     "details": {...}                 }             ],             "total_sagas": 1,             "compensated_sagas": 0         }     }

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.WorkflowsApi(api_client)
    workflow_run_id = 'workflow_run_id_example' # str | 

    try:
        # Get saga/compensation history for a workflow run.
        api_instance.get_api_v1_workflowsworkflow_run_id_sagas(workflow_run_id)
    except Exception as e:
        print("Exception when calling WorkflowsApi->get_api_v1_workflowsworkflow_run_id_sagas: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_run_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_api_v1_workflows**
> post_api_v1_workflows()

Submit a new workflow for execution.

Submit a workflow definition (JSON or Python DSL) for execution. The workflow will be versioned automatically based on content hash.

**RBAC Permission:** `submit_workflows`

Returns:     201: Workflow submitted successfully     400: Invalid request (missing definition, validation error)     403: Permission denied     429: Rate limit exceeded     500: Internal server error

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.WorkflowsApi(api_client)

    try:
        # Submit a new workflow for execution.
        api_instance.post_api_v1_workflows()
    except Exception as e:
        print("Exception when calling WorkflowsApi->post_api_v1_workflows: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_api_v1_workflowsworkflow_run_id_cancel**
> post_api_v1_workflowsworkflow_run_id_cancel(workflow_run_id)

Cancel a running workflow.

**RBAC Permission:** `cancel_workflows`

Args:     workflow_run_id: Workflow run ID (UUID)

Returns:     200: Workflow cancelled     400: Invalid UUID     404: Workflow not found     409: Workflow not in cancellable state     500: Internal server error

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.WorkflowsApi(api_client)
    workflow_run_id = 'workflow_run_id_example' # str | 

    try:
        # Cancel a running workflow.
        api_instance.post_api_v1_workflowsworkflow_run_id_cancel(workflow_run_id)
    except Exception as e:
        print("Exception when calling WorkflowsApi->post_api_v1_workflowsworkflow_run_id_cancel: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_run_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_api_v1_workflowsworkflow_run_id_retry**
> post_api_v1_workflowsworkflow_run_id_retry(workflow_run_id)

Retry a failed workflow from the beginning.

**RBAC Permission:** `retry_workflows`

Path Parameters:     workflow_run_id: Workflow run ID (UUID)

Returns:     200: Workflow retry submitted     400: Workflow not in failed state     404: Workflow not found     500: Failed to retry workflow

Response:     {         "success": true,         "data": {             "original_workflow_run_id": "abc123",             "new_workflow_run_id": "def456",             "new_run_id": "ghi789",             "message": "Workflow retry submitted successfully"         }     }

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.WorkflowsApi(api_client)
    workflow_run_id = 'workflow_run_id_example' # str | 

    try:
        # Retry a failed workflow from the beginning.
        api_instance.post_api_v1_workflowsworkflow_run_id_retry(workflow_run_id)
    except Exception as e:
        print("Exception when calling WorkflowsApi->post_api_v1_workflowsworkflow_run_id_retry: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_run_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

