# highway_sdk.MonitoringApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_api_v1_monitoring_live**](MonitoringApi.md#get_api_v1_monitoring_live) | **GET** /api/v1/monitoring/live | Get currently active tasks from the ephemeral runtime table.


# **get_api_v1_monitoring_live**
> get_api_v1_monitoring_live()

Get currently active tasks from the ephemeral runtime table.

This endpoint implements the "Sidecar Telemetry Pattern" to track ALL tasks (Shell, HTTP, Python, etc.) in real-time. If a worker crashes hard (OOM/power off) mid-task, the "STARTED" record remains in the DB so we can detect zombie tasks.

Query Parameters:     minutes (int, optional): Lookback window in minutes (default: 5)

Returns:     200: List of active tasks updated in the last N minutes     500: Database error

Example Response:     {         "count": 3,         "tasks": [             {                 "task_run_id": "uuid",                 "workflow_run_id": "uuid",                 "step_name": "fetch_data",                 "tool_name": "tools.http.request",                 "worker_id": "worker-01",                 "status": "RUNNING",                 "percent": 50,                 "message": "Processing item 50/100",                 "updated_at": "2025-01-15T10:30:45Z",                 "metadata": {"operator": "TaskOperator", "step_name": "fetch_data"}             }         ]     }

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.MonitoringApi(api_client)

    try:
        # Get currently active tasks from the ephemeral runtime table.
        api_instance.get_api_v1_monitoring_live()
    except Exception as e:
        print("Exception when calling MonitoringApi->get_api_v1_monitoring_live: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

