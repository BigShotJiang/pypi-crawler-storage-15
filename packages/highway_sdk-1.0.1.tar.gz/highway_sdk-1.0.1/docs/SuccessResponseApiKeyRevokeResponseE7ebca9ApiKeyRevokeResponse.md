# SuccessResponseApiKeyRevokeResponseE7ebca9ApiKeyRevokeResponse

Response after revoking an API key.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**api_key_id** | **str** | Revoked API key ID | 
**message** | **str** | Status message | 
**status** | **str** | New status | [optional] [default to 'revoked']

## Example

```python
from highway_sdk.models.success_response_api_key_revoke_response_e7ebca9_api_key_revoke_response import SuccessResponseApiKeyRevokeResponseE7ebca9ApiKeyRevokeResponse

# TODO update the JSON string below
json = "{}"
# create an instance of SuccessResponseApiKeyRevokeResponseE7ebca9ApiKeyRevokeResponse from a JSON string
success_response_api_key_revoke_response_e7ebca9_api_key_revoke_response_instance = SuccessResponseApiKeyRevokeResponseE7ebca9ApiKeyRevokeResponse.from_json(json)
# print the JSON string representation of the object
print(SuccessResponseApiKeyRevokeResponseE7ebca9ApiKeyRevokeResponse.to_json())

# convert the object into a dict
success_response_api_key_revoke_response_e7ebca9_api_key_revoke_response_dict = success_response_api_key_revoke_response_e7ebca9_api_key_revoke_response_instance.to_dict()
# create an instance of SuccessResponseApiKeyRevokeResponseE7ebca9ApiKeyRevokeResponse from a dict
success_response_api_key_revoke_response_e7ebca9_api_key_revoke_response_from_dict = SuccessResponseApiKeyRevokeResponseE7ebca9ApiKeyRevokeResponse.from_dict(success_response_api_key_revoke_response_e7ebca9_api_key_revoke_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


