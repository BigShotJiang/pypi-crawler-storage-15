# highway_sdk.IdempotencyApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**delete_api_v1_idempotencyidempotency_key**](IdempotencyApi.md#delete_api_v1_idempotencyidempotency_key) | **DELETE** /api/v1/idempotency/{idempotency_key} | Delete idempotency record for testing.
[**post_api_v1_idempotency_reset_all**](IdempotencyApi.md#post_api_v1_idempotency_reset_all) | **POST** /api/v1/idempotency/reset-all | Delete ALL idempotency records for testing.


# **delete_api_v1_idempotencyidempotency_key**
> delete_api_v1_idempotencyidempotency_key(idempotency_key)

Delete idempotency record for testing.

This endpoint is for TEST ISOLATION ONLY. It deletes idempotency records so that tests can run with clean state.

Args:     idempotency_key: Idempotency key to delete

Returns:     200: Record deleted (or didn't exist)     500: Database error

Example:     DELETE /api/v1/idempotency/counter_increment_op_001

    Response:     {         "status": "success",         "data": {             "message": "Idempotency record 'counter_increment_op_001' deleted",             "records_deleted": 1         }     }

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.IdempotencyApi(api_client)
    idempotency_key = 'idempotency_key_example' # str | 

    try:
        # Delete idempotency record for testing.
        api_instance.delete_api_v1_idempotencyidempotency_key(idempotency_key)
    except Exception as e:
        print("Exception when calling IdempotencyApi->delete_api_v1_idempotencyidempotency_key: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **idempotency_key** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_api_v1_idempotency_reset_all**
> post_api_v1_idempotency_reset_all()

Delete ALL idempotency records for testing.

WARNING: This deletes ALL idempotency records in the database. Use only in test environments for clean state.

Returns:     200: All records deleted     500: Database error

Example:     POST /api/v1/idempotency/reset-all

    Response:     {         "status": "success",         "data": {             "message": "All idempotency records deleted",             "records_deleted": 42         }     }

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.IdempotencyApi(api_client)

    try:
        # Delete ALL idempotency records for testing.
        api_instance.post_api_v1_idempotency_reset_all()
    except Exception as e:
        print("Exception when calling IdempotencyApi->post_api_v1_idempotency_reset_all: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

