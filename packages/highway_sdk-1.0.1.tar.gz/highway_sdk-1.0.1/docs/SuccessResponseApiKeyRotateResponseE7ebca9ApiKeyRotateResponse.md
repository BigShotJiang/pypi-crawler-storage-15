# SuccessResponseApiKeyRotateResponseE7ebca9ApiKeyRotateResponse

Response after rotating an API key.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**api_key_id** | **str** | API key ID | 
**message** | **str** | Status message | 
**new_api_key** | **str** | New API key (shown only once) | 
**new_key_prefix** | **str** | New key prefix | 
**old_key_revoked** | **bool** | Whether old key was revoked | [optional] [default to True]

## Example

```python
from highway_sdk.models.success_response_api_key_rotate_response_e7ebca9_api_key_rotate_response import SuccessResponseApiKeyRotateResponseE7ebca9ApiKeyRotateResponse

# TODO update the JSON string below
json = "{}"
# create an instance of SuccessResponseApiKeyRotateResponseE7ebca9ApiKeyRotateResponse from a JSON string
success_response_api_key_rotate_response_e7ebca9_api_key_rotate_response_instance = SuccessResponseApiKeyRotateResponseE7ebca9ApiKeyRotateResponse.from_json(json)
# print the JSON string representation of the object
print(SuccessResponseApiKeyRotateResponseE7ebca9ApiKeyRotateResponse.to_json())

# convert the object into a dict
success_response_api_key_rotate_response_e7ebca9_api_key_rotate_response_dict = success_response_api_key_rotate_response_e7ebca9_api_key_rotate_response_instance.to_dict()
# create an instance of SuccessResponseApiKeyRotateResponseE7ebca9ApiKeyRotateResponse from a dict
success_response_api_key_rotate_response_e7ebca9_api_key_rotate_response_from_dict = SuccessResponseApiKeyRotateResponseE7ebca9ApiKeyRotateResponse.from_dict(success_response_api_key_rotate_response_e7ebca9_api_key_rotate_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


