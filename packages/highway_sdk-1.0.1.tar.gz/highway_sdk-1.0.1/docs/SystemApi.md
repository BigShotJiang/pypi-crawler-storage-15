# highway_sdk.SystemApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_api_v1_health**](SystemApi.md#get_api_v1_health) | **GET** /api/v1/health | Health check endpoint.
[**get_api_v1_health_metrics**](SystemApi.md#get_api_v1_health_metrics) | **GET** /api/v1/health/metrics | Get detailed health metrics for monitoring and alerting.
[**get_api_v1_version**](SystemApi.md#get_api_v1_version) | **GET** /api/v1/version | Get version information.


# **get_api_v1_health**
> SuccessResponseHealthCheckResponseE7ebca9 get_api_v1_health()

Health check endpoint.

Checks database connectivity and worker activity to determine overall system health.

Returns:     200: All checks passed (healthy)     503: One or more checks failed (unhealthy)

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.models.success_response_health_check_response_e7ebca9 import SuccessResponseHealthCheckResponseE7ebca9
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.SystemApi(api_client)

    try:
        # Health check endpoint.
        api_response = api_instance.get_api_v1_health()
        print("The response of SystemApi->get_api_v1_health:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling SystemApi->get_api_v1_health: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**SuccessResponseHealthCheckResponseE7ebca9**](SuccessResponseHealthCheckResponseE7ebca9.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**422** | Unprocessable Content |  -  |
**503** | Service Unavailable |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_health_metrics**
> get_api_v1_health_metrics()

Get detailed health metrics for monitoring and alerting.

Query parameters:     interval: Time window for metrics (default: "15 minutes")               Accepts PostgreSQL interval format: "5 minutes", "1 hour", "30 seconds"     all_tenants: If "true" and user is admin, show metrics for all tenants

Returns:     200: Metrics data with categories and severity levels

Categories:     - critical: Expired claims (orphaned tasks)     - failures: ClaimTimeout, TaskExecutionError, other errors     - resilience: Retry counts, failover counts, max attempts     - performance: Throughput, task duration     - workers: Active workers, completed/failed tasks per worker     - workflows: Status counts (completed, failed, pending, running)     - tasks: State distribution     - queues: Depth per queue (running, ready, scheduled, sleeping)

Severity levels:     - ok: Normal operation     - warning: Elevated but not critical     - critical: Immediate attention required

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.SystemApi(api_client)

    try:
        # Get detailed health metrics for monitoring and alerting.
        api_instance.get_api_v1_health_metrics()
    except Exception as e:
        print("Exception when calling SystemApi->get_api_v1_health_metrics: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_version**
> get_api_v1_version()

Get version information.

Returns:     200: Version metadata including version number, git info, and timestamp

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.SystemApi(api_client)

    try:
        # Get version information.
        api_instance.get_api_v1_version()
    except Exception as e:
        print("Exception when calling SystemApi->get_api_v1_version: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

