# highway_sdk.WorkersApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**delete_api_v1_workersworker_id**](WorkersApi.md#delete_api_v1_workersworker_id) | **DELETE** /api/v1/workers/{worker_id} | Delete a worker from the registry.
[**get_api_v1_workers**](WorkersApi.md#get_api_v1_workers) | **GET** /api/v1/workers | List all registered workers.
[**get_api_v1_workers_summary**](WorkersApi.md#get_api_v1_workers_summary) | **GET** /api/v1/workers/summary | Get aggregated worker health summary.
[**get_api_v1_workersworker_id**](WorkersApi.md#get_api_v1_workersworker_id) | **GET** /api/v1/workers/{worker_id} | Get details for a specific worker.
[**post_api_v1_workers_cleanup**](WorkersApi.md#post_api_v1_workers_cleanup) | **POST** /api/v1/workers/cleanup | Mark stale workers as offline.
[**post_api_v1_workersworker_id_drain**](WorkersApi.md#post_api_v1_workersworker_id_drain) | **POST** /api/v1/workers/{worker_id}/drain | Gracefully drain a worker (finish current tasks, then stop).
[**post_api_v1_workersworker_id_pause**](WorkersApi.md#post_api_v1_workersworker_id_pause) | **POST** /api/v1/workers/{worker_id}/pause | Pause a worker (stops claiming new tasks immediately).
[**post_api_v1_workersworker_id_resume**](WorkersApi.md#post_api_v1_workersworker_id_resume) | **POST** /api/v1/workers/{worker_id}/resume | Resume a paused/draining worker.
[**put_api_v1_workersworker_id_capacity**](WorkersApi.md#put_api_v1_workersworker_id_capacity) | **PUT** /api/v1/workers/{worker_id}/capacity | Update worker capacity settings.


# **delete_api_v1_workersworker_id**
> delete_api_v1_workersworker_id(worker_id)

Delete a worker from the registry.

Typically used for workers that are offline and will not return.

Args:     worker_id: Worker identifier

Returns:     200: Worker deleted     404: Worker not found

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.WorkersApi(api_client)
    worker_id = 'worker_id_example' # str | 

    try:
        # Delete a worker from the registry.
        api_instance.delete_api_v1_workersworker_id(worker_id)
    except Exception as e:
        print("Exception when calling WorkersApi->delete_api_v1_workersworker_id: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **worker_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_workers**
> get_api_v1_workers()

List all registered workers.

Query parameters:     status: Filter by status (online, offline, paused, draining)     queue_name: Filter by queue name     machine_id: Filter by machine hostname

Returns:     200: List of workers with status and capacity info

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.WorkersApi(api_client)

    try:
        # List all registered workers.
        api_instance.get_api_v1_workers()
    except Exception as e:
        print("Exception when calling WorkersApi->get_api_v1_workers: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_workers_summary**
> get_api_v1_workers_summary()

Get aggregated worker health summary.

Returns:     200: Summary with counts by status, total capacity, current load

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.WorkersApi(api_client)

    try:
        # Get aggregated worker health summary.
        api_instance.get_api_v1_workers_summary()
    except Exception as e:
        print("Exception when calling WorkersApi->get_api_v1_workers_summary: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_workersworker_id**
> get_api_v1_workersworker_id(worker_id)

Get details for a specific worker.

Args:     worker_id: Worker identifier

Returns:     200: Worker details     404: Worker not found

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.WorkersApi(api_client)
    worker_id = 'worker_id_example' # str | 

    try:
        # Get details for a specific worker.
        api_instance.get_api_v1_workersworker_id(worker_id)
    except Exception as e:
        print("Exception when calling WorkersApi->get_api_v1_workersworker_id: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **worker_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_api_v1_workers_cleanup**
> post_api_v1_workers_cleanup()

Mark stale workers as offline.

Request body:     threshold_seconds: Time without heartbeat before marking offline (default: 90)

Returns:     200: List of workers marked offline

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.WorkersApi(api_client)

    try:
        # Mark stale workers as offline.
        api_instance.post_api_v1_workers_cleanup()
    except Exception as e:
        print("Exception when calling WorkersApi->post_api_v1_workers_cleanup: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_api_v1_workersworker_id_drain**
> post_api_v1_workersworker_id_drain(worker_id)

Gracefully drain a worker (finish current tasks, then stop).

Args:     worker_id: Worker identifier

Returns:     200: Worker set to draining     404: Worker not found

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.WorkersApi(api_client)
    worker_id = 'worker_id_example' # str | 

    try:
        # Gracefully drain a worker (finish current tasks, then stop).
        api_instance.post_api_v1_workersworker_id_drain(worker_id)
    except Exception as e:
        print("Exception when calling WorkersApi->post_api_v1_workersworker_id_drain: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **worker_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_api_v1_workersworker_id_pause**
> post_api_v1_workersworker_id_pause(worker_id)

Pause a worker (stops claiming new tasks immediately).

Args:     worker_id: Worker identifier

Request body:     reason: Optional reason for pausing

Returns:     200: Worker paused     404: Worker not found

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.WorkersApi(api_client)
    worker_id = 'worker_id_example' # str | 

    try:
        # Pause a worker (stops claiming new tasks immediately).
        api_instance.post_api_v1_workersworker_id_pause(worker_id)
    except Exception as e:
        print("Exception when calling WorkersApi->post_api_v1_workersworker_id_pause: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **worker_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_api_v1_workersworker_id_resume**
> post_api_v1_workersworker_id_resume(worker_id)

Resume a paused/draining worker.

Args:     worker_id: Worker identifier

Request body:     batch_size: Optional new batch size

Returns:     200: Worker resumed     404: Worker not found

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.WorkersApi(api_client)
    worker_id = 'worker_id_example' # str | 

    try:
        # Resume a paused/draining worker.
        api_instance.post_api_v1_workersworker_id_resume(worker_id)
    except Exception as e:
        print("Exception when calling WorkersApi->post_api_v1_workersworker_id_resume: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **worker_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **put_api_v1_workersworker_id_capacity**
> put_api_v1_workersworker_id_capacity(worker_id)

Update worker capacity settings.

Args:     worker_id: Worker identifier

Request body:     batch_size: New batch size (optional)     max_concurrent_tasks: New max concurrent tasks (optional)

Returns:     200: Updated worker     404: Worker not found

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.WorkersApi(api_client)
    worker_id = 'worker_id_example' # str | 

    try:
        # Update worker capacity settings.
        api_instance.put_api_v1_workersworker_id_capacity(worker_id)
    except Exception as e:
        print("Exception when calling WorkersApi->put_api_v1_workersworker_id_capacity: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **worker_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

