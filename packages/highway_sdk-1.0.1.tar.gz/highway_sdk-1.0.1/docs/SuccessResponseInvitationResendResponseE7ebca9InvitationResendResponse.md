# SuccessResponseInvitationResendResponseE7ebca9InvitationResendResponse

Response after resending invitation.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email** | **str** | Invitee email | 
**invitation_id** | **str** | Invitation ID | 
**message** | **str** | Status message | 
**new_expires_at** | **datetime** | New expiration time | 

## Example

```python
from highway_sdk.models.success_response_invitation_resend_response_e7ebca9_invitation_resend_response import SuccessResponseInvitationResendResponseE7ebca9InvitationResendResponse

# TODO update the JSON string below
json = "{}"
# create an instance of SuccessResponseInvitationResendResponseE7ebca9InvitationResendResponse from a JSON string
success_response_invitation_resend_response_e7ebca9_invitation_resend_response_instance = SuccessResponseInvitationResendResponseE7ebca9InvitationResendResponse.from_json(json)
# print the JSON string representation of the object
print(SuccessResponseInvitationResendResponseE7ebca9InvitationResendResponse.to_json())

# convert the object into a dict
success_response_invitation_resend_response_e7ebca9_invitation_resend_response_dict = success_response_invitation_resend_response_e7ebca9_invitation_resend_response_instance.to_dict()
# create an instance of SuccessResponseInvitationResendResponseE7ebca9InvitationResendResponse from a dict
success_response_invitation_resend_response_e7ebca9_invitation_resend_response_from_dict = SuccessResponseInvitationResendResponseE7ebca9InvitationResendResponse.from_dict(success_response_invitation_resend_response_e7ebca9_invitation_resend_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


