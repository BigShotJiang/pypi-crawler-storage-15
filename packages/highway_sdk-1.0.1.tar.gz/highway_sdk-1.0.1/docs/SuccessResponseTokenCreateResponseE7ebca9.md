# SuccessResponseTokenCreateResponseE7ebca9


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**SuccessResponseTokenCreateResponseE7ebca9TokenCreateResponse**](SuccessResponseTokenCreateResponseE7ebca9TokenCreateResponse.md) | Response payload | 
**status** | **str** | Response status | [optional] [default to 'success']

## Example

```python
from highway_sdk.models.success_response_token_create_response_e7ebca9 import SuccessResponseTokenCreateResponseE7ebca9

# TODO update the JSON string below
json = "{}"
# create an instance of SuccessResponseTokenCreateResponseE7ebca9 from a JSON string
success_response_token_create_response_e7ebca9_instance = SuccessResponseTokenCreateResponseE7ebca9.from_json(json)
# print the JSON string representation of the object
print(SuccessResponseTokenCreateResponseE7ebca9.to_json())

# convert the object into a dict
success_response_token_create_response_e7ebca9_dict = success_response_token_create_response_e7ebca9_instance.to_dict()
# create an instance of SuccessResponseTokenCreateResponseE7ebca9 from a dict
success_response_token_create_response_e7ebca9_from_dict = SuccessResponseTokenCreateResponseE7ebca9.from_dict(success_response_token_create_response_e7ebca9_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


