# highway_sdk.RBACApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_api_v1_rbac_my_permissions**](RBACApi.md#get_api_v1_rbac_my_permissions) | **GET** /api/v1/rbac/my-permissions | Get current user&#39;s permissions.
[**get_api_v1_rbac_my_roles**](RBACApi.md#get_api_v1_rbac_my_roles) | **GET** /api/v1/rbac/my-roles | Get current user&#39;s roles.
[**get_api_v1_rbac_permissionspermission_name_roles**](RBACApi.md#get_api_v1_rbac_permissionspermission_name_roles) | **GET** /api/v1/rbac/permissions/{permission_name}/roles | Get which roles have a specific permission.
[**get_api_v1_rbac_roles**](RBACApi.md#get_api_v1_rbac_roles) | **GET** /api/v1/rbac/roles | List all available roles for current tenant.


# **get_api_v1_rbac_my_permissions**
> get_api_v1_rbac_my_permissions()

Get current user's permissions.

Returns:     200: {         "user_email": "user@example.com",         "tenant": "tenant_id",         "permissions": [             {"name": "submit_workflows"},             {"name": "view_workflows"},             ...         ]     }

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.RBACApi(api_client)

    try:
        # Get current user's permissions.
        api_instance.get_api_v1_rbac_my_permissions()
    except Exception as e:
        print("Exception when calling RBACApi->get_api_v1_rbac_my_permissions: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_rbac_my_roles**
> get_api_v1_rbac_my_roles()

Get current user's roles.

Returns:     200: {         "user_email": "user@example.com",         "tenant": "tenant_id",         "roles": [             {"role": "workflow_author", "description": "..."},             ...         ]     }

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.RBACApi(api_client)

    try:
        # Get current user's roles.
        api_instance.get_api_v1_rbac_my_roles()
    except Exception as e:
        print("Exception when calling RBACApi->get_api_v1_rbac_my_roles: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_rbac_permissionspermission_name_roles**
> get_api_v1_rbac_permissionspermission_name_roles(permission_name)

Get which roles have a specific permission.

Args:     permission_name: Permission to look up (e.g., "submit_workflows")

Returns:     200: {         "permission": "submit_workflows",         "roles_with_permission": ["tenant_admin", "workflow_author", ...]     }     404: Permission not found

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.RBACApi(api_client)
    permission_name = 'permission_name_example' # str | 

    try:
        # Get which roles have a specific permission.
        api_instance.get_api_v1_rbac_permissionspermission_name_roles(permission_name)
    except Exception as e:
        print("Exception when calling RBACApi->get_api_v1_rbac_permissionspermission_name_roles: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **permission_name** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_rbac_roles**
> get_api_v1_rbac_roles()

List all available roles for current tenant.

Returns:     200: {         "tenant": "tenant_id",         "roles": [             {                 "role": "tenant_admin",                 "description": "Full tenant administration",                 "permissions": ["submit_workflows", "cancel_workflows", ...]             },             ...         ]     }

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.RBACApi(api_client)

    try:
        # List all available roles for current tenant.
        api_instance.get_api_v1_rbac_roles()
    except Exception as e:
        print("Exception when calling RBACApi->get_api_v1_rbac_roles: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

