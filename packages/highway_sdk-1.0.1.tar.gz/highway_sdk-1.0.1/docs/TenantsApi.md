# highway_sdk.TenantsApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_api_v1_tenants**](TenantsApi.md#get_api_v1_tenants) | **GET** /api/v1/tenants | List tenants that the authenticated user has access to.


# **get_api_v1_tenants**
> get_api_v1_tenants()

List tenants that the authenticated user has access to.

Returns only tenants where the user has at least one role assignment.

Returns:     200: List of tenant IDs     500: Database error

Response:     {         "success": true,         "data": {             "tenants": ["test", "demo", "default"],             "total": 3         }     }

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.TenantsApi(api_client)

    try:
        # List tenants that the authenticated user has access to.
        api_instance.get_api_v1_tenants()
    except Exception as e:
        print("Exception when calling TenantsApi->get_api_v1_tenants: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

