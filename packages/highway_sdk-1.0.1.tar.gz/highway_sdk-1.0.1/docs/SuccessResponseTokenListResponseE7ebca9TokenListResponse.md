# SuccessResponseTokenListResponseE7ebca9TokenListResponse

List of tokens.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tokens** | [**List[SuccessResponseTokenListResponseE7ebca9TokenResponse]**](SuccessResponseTokenListResponseE7ebca9TokenResponse.md) | Token list | 
**total** | **int** | Total count | 

## Example

```python
from highway_sdk.models.success_response_token_list_response_e7ebca9_token_list_response import SuccessResponseTokenListResponseE7ebca9TokenListResponse

# TODO update the JSON string below
json = "{}"
# create an instance of SuccessResponseTokenListResponseE7ebca9TokenListResponse from a JSON string
success_response_token_list_response_e7ebca9_token_list_response_instance = SuccessResponseTokenListResponseE7ebca9TokenListResponse.from_json(json)
# print the JSON string representation of the object
print(SuccessResponseTokenListResponseE7ebca9TokenListResponse.to_json())

# convert the object into a dict
success_response_token_list_response_e7ebca9_token_list_response_dict = success_response_token_list_response_e7ebca9_token_list_response_instance.to_dict()
# create an instance of SuccessResponseTokenListResponseE7ebca9TokenListResponse from a dict
success_response_token_list_response_e7ebca9_token_list_response_from_dict = SuccessResponseTokenListResponseE7ebca9TokenListResponse.from_dict(success_response_token_list_response_e7ebca9_token_list_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


