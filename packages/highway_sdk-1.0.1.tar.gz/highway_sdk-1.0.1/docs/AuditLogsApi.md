# highway_sdk.AuditLogsApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_api_v1_admin_audit_logs**](AuditLogsApi.md#get_api_v1_admin_audit_logs) | **GET** /api/v1/admin/audit-logs | List admin audit logs with filters.
[**get_api_v1_admin_audit_logslog_id**](AuditLogsApi.md#get_api_v1_admin_audit_logslog_id) | **GET** /api/v1/admin/audit-logs/{log_id} | Get details for a specific audit log entry.


# **get_api_v1_admin_audit_logs**
> get_api_v1_admin_audit_logs()

List admin audit logs with filters.

Query Parameters:     action_type: Filter by action (create, update, delete, revoke, rotate)     resource_type: Filter by resource (api_key, api_token, user, invitation)     user_email: Filter by user who performed action     resource_id: Filter by specific resource ID     start_date: Filter from date (ISO 8601)     end_date: Filter to date (ISO 8601)     page: Page number (default: 1)     per_page: Items per page (default: 50, max: 200)

Returns:     200: {         "audit_logs": [...],         "total": 100,         "page": 1,         "per_page": 50     }

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.AuditLogsApi(api_client)

    try:
        # List admin audit logs with filters.
        api_instance.get_api_v1_admin_audit_logs()
    except Exception as e:
        print("Exception when calling AuditLogsApi->get_api_v1_admin_audit_logs: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_admin_audit_logslog_id**
> get_api_v1_admin_audit_logslog_id(log_id)

Get details for a specific audit log entry.

Args:     log_id: Audit log UUID

Returns:     200: Audit log details     404: Audit log not found

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.AuditLogsApi(api_client)
    log_id = 'log_id_example' # str | 

    try:
        # Get details for a specific audit log entry.
        api_instance.get_api_v1_admin_audit_logslog_id(log_id)
    except Exception as e:
        print("Exception when calling AuditLogsApi->get_api_v1_admin_audit_logslog_id: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **log_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

