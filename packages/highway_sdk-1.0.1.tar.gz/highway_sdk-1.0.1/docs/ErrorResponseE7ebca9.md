# ErrorResponseE7ebca9

Standard error response wrapper.  All error responses follow this structure: {     \"status\": \"error\",     \"message\": \"Human-readable error message\",     \"code\": \"ERROR_CODE\",     \"details\": {...}  // Optional additional details }

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **str** | Machine-readable error code | 
**details** | [**Details**](Details.md) |  | [optional] 
**message** | **str** | Human-readable error message | 
**request_id** | **str** |  | [optional] 
**status** | **str** | Response status | [optional] [default to 'error']
**timestamp** | **datetime** |  | [optional] 

## Example

```python
from highway_sdk.models.error_response_e7ebca9 import ErrorResponseE7ebca9

# TODO update the JSON string below
json = "{}"
# create an instance of ErrorResponseE7ebca9 from a JSON string
error_response_e7ebca9_instance = ErrorResponseE7ebca9.from_json(json)
# print the JSON string representation of the object
print(ErrorResponseE7ebca9.to_json())

# convert the object into a dict
error_response_e7ebca9_dict = error_response_e7ebca9_instance.to_dict()
# create an instance of ErrorResponseE7ebca9 from a dict
error_response_e7ebca9_from_dict = ErrorResponseE7ebca9.from_dict(error_response_e7ebca9_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


