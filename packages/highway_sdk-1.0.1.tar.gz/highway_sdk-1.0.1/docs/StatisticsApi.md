# highway_sdk.StatisticsApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_api_v1_workflows_stats**](StatisticsApi.md#get_api_v1_workflows_stats) | **GET** /api/v1/workflows/stats | Get global workflow statistics.
[**get_api_v1_workflowsworkflow_run_id_metrics**](StatisticsApi.md#get_api_v1_workflowsworkflow_run_id_metrics) | **GET** /api/v1/workflows/{workflow_run_id}/metrics | Get detailed metrics for a specific workflow execution.


# **get_api_v1_workflows_stats**
> get_api_v1_workflows_stats()

Get global workflow statistics.

Query Parameters:     workflow_name (optional): Filter by specific workflow name     since (optional): ISO datetime - stats for workflows after this time     until (optional): ISO datetime - stats for workflows before this time     hours (optional): Last N hours (shorthand for since)

Returns:     200: Statistics     400: Invalid parameters     404: No workflows found     500: Failed to compute stats

Response:     {         "success": true,         "data": {             "total_workflows": 15420,             "status_breakdown": {                 "completed": 14850,                 "failed": 320,                 "running": 150,                 "sleeping": 100             },             "success_rate": 0.979,             "avg_duration_seconds": 45.2,             "p50_duration_seconds": 30.1,             "p95_duration_seconds": 120.5,             "p99_duration_seconds": 180.0,             "total_duration_seconds": 697798,             "time_range": {                 "since": "2025-11-01T00:00:00Z",                 "until": "2025-11-17T10:00:00Z"             }         }     }

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.StatisticsApi(api_client)

    try:
        # Get global workflow statistics.
        api_instance.get_api_v1_workflows_stats()
    except Exception as e:
        print("Exception when calling StatisticsApi->get_api_v1_workflows_stats: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_workflowsworkflow_run_id_metrics**
> get_api_v1_workflowsworkflow_run_id_metrics(workflow_run_id)

Get detailed metrics for a specific workflow execution.

Path Parameters:     workflow_run_id: Workflow run ID (UUID)

Returns:     200: Workflow metrics     404: Workflow not found     500: Failed to compute metrics

Response:     {         "success": true,         "data": {             "workflow_run_id": "abc123",             "workflow_name": "video_processing",             "status": "completed",             "duration_seconds": 330.5,             "created_at": "2025-11-17T10:00:00Z",             "updated_at": "2025-11-17T10:05:30Z",             "step_count": 15,             "event_count": 45,             "retry_count": 2,             "checkpoint_count": 15         }     }

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.StatisticsApi(api_client)
    workflow_run_id = 'workflow_run_id_example' # str | 

    try:
        # Get detailed metrics for a specific workflow execution.
        api_instance.get_api_v1_workflowsworkflow_run_id_metrics(workflow_run_id)
    except Exception as e:
        print("Exception when calling StatisticsApi->get_api_v1_workflowsworkflow_run_id_metrics: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_run_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

