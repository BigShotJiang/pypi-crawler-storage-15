# highway_sdk.ReplayApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_api_v1_workflowsworkflow_run_id_replay**](ReplayApi.md#get_api_v1_workflowsworkflow_run_id_replay) | **GET** /api/v1/workflows/{workflow_run_id}/replay | Replay workflow execution for debugging.
[**get_api_v1_workflowsworkflow_run_id_replay_steps**](ReplayApi.md#get_api_v1_workflowsworkflow_run_id_replay_steps) | **GET** /api/v1/workflows/{workflow_run_id}/replay/steps | List available steps/checkpoints for a workflow run.
[**post_api_v1_workflowsworkflow_run_id_simulate**](ReplayApi.md#post_api_v1_workflowsworkflow_run_id_simulate) | **POST** /api/v1/workflows/{workflow_run_id}/simulate | Simulate workflow execution by re-running code with historical data.


# **get_api_v1_workflowsworkflow_run_id_replay**
> get_api_v1_workflowsworkflow_run_id_replay(workflow_run_id)

Replay workflow execution for debugging.

Args:     workflow_run_id: Workflow run ID (UUID)

Query Parameters:     format: Output format (text, json) - default: json     verbose: Include detailed information (true/false) - default: false     include_children: Include child workflow trees (true/false) - default: false

Returns:     200: Replay data     400: Invalid UUID or parameters     404: Workflow not found     500: Internal server error

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.ReplayApi(api_client)
    workflow_run_id = 'workflow_run_id_example' # str | 

    try:
        # Replay workflow execution for debugging.
        api_instance.get_api_v1_workflowsworkflow_run_id_replay(workflow_run_id)
    except Exception as e:
        print("Exception when calling ReplayApi->get_api_v1_workflowsworkflow_run_id_replay: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_run_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_workflowsworkflow_run_id_replay_steps**
> get_api_v1_workflowsworkflow_run_id_replay_steps(workflow_run_id)

List available steps/checkpoints for a workflow run.

This endpoint returns all checkpoint names that can be used with the resume_from parameter in the /simulate endpoint.

Args:     workflow_run_id: Workflow run ID (UUID)

Returns:     200: List of checkpoint steps with metadata     400: Invalid UUID     404: Workflow not found     500: Internal server error

Example Response:     {         "status": "success",         "data": {             "workflow_run_id": "...",             "steps": [                 {"name": "step_1", "has_checkpoint": true, "schema_version": "abc123"},                 {"name": "step_2", "has_checkpoint": true, "schema_version": "def456"},                 {"name": "step_3", "has_checkpoint": false}             ],             "total_checkpoints": 2         }     }

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.ReplayApi(api_client)
    workflow_run_id = 'workflow_run_id_example' # str | 

    try:
        # List available steps/checkpoints for a workflow run.
        api_instance.get_api_v1_workflowsworkflow_run_id_replay_steps(workflow_run_id)
    except Exception as e:
        print("Exception when calling ReplayApi->get_api_v1_workflowsworkflow_run_id_replay_steps: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_run_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_api_v1_workflowsworkflow_run_id_simulate**
> post_api_v1_workflowsworkflow_run_id_simulate(workflow_run_id)

Simulate workflow execution by re-running code with historical data.

This endpoint implements "time-travel debugging": - Re-executes the actual workflow code using historical inputs - Mocks external side effects (HTTP, DB) using cached checkpoints - Detects divergences when code behavior differs from original execution - Useful for reproducing bugs and verifying fixes against production data

Args:     workflow_run_id: Workflow run ID (UUID)

Request Body (optional):     {         "resume_from": "step_name"  // Resume simulation from a specific step     }

Returns:     200: Simulation report with status, logs, divergences     400: Invalid UUID or parameters     404: Workflow not found     500: Simulation failed

Example Response:     {         "status": "success",         "data": {             "status": "success",             "simulation_status": "success",             "absurd_run_id": "...",             "workflow_run_id": "...",             "workflow_name": "my_workflow",             "executed_steps": ["step1", "step2"],             "divergences": [],             "replay_logs": ["✅ Step 'step1': Used cached result", ...],             "original_result": {...},             "simulated_result": {...},             "resume_from": "step_name",  // If resume was requested             "skipped_steps": ["step1"],  // Steps skipped due to resume             "skipped_steps_count": 1         }     }

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.ReplayApi(api_client)
    workflow_run_id = 'workflow_run_id_example' # str | 

    try:
        # Simulate workflow execution by re-running code with historical data.
        api_instance.post_api_v1_workflowsworkflow_run_id_simulate(workflow_run_id)
    except Exception as e:
        print("Exception when calling ReplayApi->post_api_v1_workflowsworkflow_run_id_simulate: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_run_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

