# SuccessResponseTokenRevokeAllResponseE7ebca9TokenRevokeAllResponse

Response after revoking all tokens for a user.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | **str** | Status message | 
**revoked_count** | **int** | Number of tokens revoked | 
**user_email** | **str** | User email | 

## Example

```python
from highway_sdk.models.success_response_token_revoke_all_response_e7ebca9_token_revoke_all_response import SuccessResponseTokenRevokeAllResponseE7ebca9TokenRevokeAllResponse

# TODO update the JSON string below
json = "{}"
# create an instance of SuccessResponseTokenRevokeAllResponseE7ebca9TokenRevokeAllResponse from a JSON string
success_response_token_revoke_all_response_e7ebca9_token_revoke_all_response_instance = SuccessResponseTokenRevokeAllResponseE7ebca9TokenRevokeAllResponse.from_json(json)
# print the JSON string representation of the object
print(SuccessResponseTokenRevokeAllResponseE7ebca9TokenRevokeAllResponse.to_json())

# convert the object into a dict
success_response_token_revoke_all_response_e7ebca9_token_revoke_all_response_dict = success_response_token_revoke_all_response_e7ebca9_token_revoke_all_response_instance.to_dict()
# create an instance of SuccessResponseTokenRevokeAllResponseE7ebca9TokenRevokeAllResponse from a dict
success_response_token_revoke_all_response_e7ebca9_token_revoke_all_response_from_dict = SuccessResponseTokenRevokeAllResponseE7ebca9TokenRevokeAllResponse.from_dict(success_response_token_revoke_all_response_e7ebca9_token_revoke_all_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


