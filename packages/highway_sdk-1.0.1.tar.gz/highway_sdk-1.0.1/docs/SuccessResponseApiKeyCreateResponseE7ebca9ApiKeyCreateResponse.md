# SuccessResponseApiKeyCreateResponseE7ebca9ApiKeyCreateResponse

Response after creating an API key (includes secret).

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**api_key** | **str** | Full API key (shown only once) | 
**api_key_id** | **str** | API key ID (UUID) | 
**expires_at** | **datetime** |  | [optional] 
**key_prefix** | **str** | Key prefix for identification | 
**message** | **str** | Warning message | [optional] [default to 'Store this API key securely. It will not be shown again.']
**name** | **str** | API key name | 

## Example

```python
from highway_sdk.models.success_response_api_key_create_response_e7ebca9_api_key_create_response import SuccessResponseApiKeyCreateResponseE7ebca9ApiKeyCreateResponse

# TODO update the JSON string below
json = "{}"
# create an instance of SuccessResponseApiKeyCreateResponseE7ebca9ApiKeyCreateResponse from a JSON string
success_response_api_key_create_response_e7ebca9_api_key_create_response_instance = SuccessResponseApiKeyCreateResponseE7ebca9ApiKeyCreateResponse.from_json(json)
# print the JSON string representation of the object
print(SuccessResponseApiKeyCreateResponseE7ebca9ApiKeyCreateResponse.to_json())

# convert the object into a dict
success_response_api_key_create_response_e7ebca9_api_key_create_response_dict = success_response_api_key_create_response_e7ebca9_api_key_create_response_instance.to_dict()
# create an instance of SuccessResponseApiKeyCreateResponseE7ebca9ApiKeyCreateResponse from a dict
success_response_api_key_create_response_e7ebca9_api_key_create_response_from_dict = SuccessResponseApiKeyCreateResponseE7ebca9ApiKeyCreateResponse.from_dict(success_response_api_key_create_response_e7ebca9_api_key_create_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


