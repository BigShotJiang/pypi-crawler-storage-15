# highway_sdk.UsersApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**delete_api_v1_usersemail**](UsersApi.md#delete_api_v1_usersemail) | **DELETE** /api/v1/users/{email} | Delete a user by removing all their roles.
[**delete_api_v1_usersemail_rolesrole**](UsersApi.md#delete_api_v1_usersemail_rolesrole) | **DELETE** /api/v1/users/{email}/roles/{role} | Remove a role from a user.
[**get_api_v1_users**](UsersApi.md#get_api_v1_users) | **GET** /api/v1/users | List all users for the current tenant.
[**get_api_v1_usersemail**](UsersApi.md#get_api_v1_usersemail) | **GET** /api/v1/users/{email} | Get detailed information about a user.
[**patch_api_v1_usersemail**](UsersApi.md#patch_api_v1_usersemail) | **PATCH** /api/v1/users/{email} | Update user roles.
[**post_api_v1_users**](UsersApi.md#post_api_v1_users) | **POST** /api/v1/users | Create a new user by assigning them to a role.
[**post_api_v1_usersemail_roles**](UsersApi.md#post_api_v1_usersemail_roles) | **POST** /api/v1/users/{email}/roles | Assign a role to an existing user.


# **delete_api_v1_usersemail**
> SuccessResponseE7ebca9 delete_api_v1_usersemail(email)

Delete a user by removing all their roles.

Args:     email: User email address (URL encoded)

Returns:     200: User deleted     404: User not found

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.models.success_response_e7ebca9 import SuccessResponseE7ebca9
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.UsersApi(api_client)
    email = 'email_example' # str | 

    try:
        # Delete a user by removing all their roles.
        api_response = api_instance.delete_api_v1_usersemail(email)
        print("The response of UsersApi->delete_api_v1_usersemail:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling UsersApi->delete_api_v1_usersemail: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **email** | **str**|  | 

### Return type

[**SuccessResponseE7ebca9**](SuccessResponseE7ebca9.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**404** | Not Found |  -  |
**422** | Unprocessable Content |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_api_v1_usersemail_rolesrole**
> SuccessResponseRoleAssignResponseE7ebca9 delete_api_v1_usersemail_rolesrole(email, role)

Remove a role from a user.

Args:     email: User email address (URL encoded)     role: Role name to remove

Returns:     200: Role removed     400: Cannot remove last role (use DELETE /users/<email> instead)     404: User not found or role not assigned

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.models.success_response_role_assign_response_e7ebca9 import SuccessResponseRoleAssignResponseE7ebca9
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.UsersApi(api_client)
    email = 'email_example' # str | 
    role = 'role_example' # str | 

    try:
        # Remove a role from a user.
        api_response = api_instance.delete_api_v1_usersemail_rolesrole(email, role)
        print("The response of UsersApi->delete_api_v1_usersemail_rolesrole:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling UsersApi->delete_api_v1_usersemail_rolesrole: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **email** | **str**|  | 
 **role** | **str**|  | 

### Return type

[**SuccessResponseRoleAssignResponseE7ebca9**](SuccessResponseRoleAssignResponseE7ebca9.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**404** | Not Found |  -  |
**422** | Unprocessable Content |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_users**
> SuccessResponseUserListResponseE7ebca9 get_api_v1_users()

List all users for the current tenant.

Query Parameters:     role: Filter by role (optional)     page: Page number (default: 1)     per_page: Items per page (default: 50, max: 200)

Returns:     200: {         "users": [...],         "total": 10,         "page": 1,         "per_page": 50     }

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.models.success_response_user_list_response_e7ebca9 import SuccessResponseUserListResponseE7ebca9
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.UsersApi(api_client)

    try:
        # List all users for the current tenant.
        api_response = api_instance.get_api_v1_users()
        print("The response of UsersApi->get_api_v1_users:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling UsersApi->get_api_v1_users: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**SuccessResponseUserListResponseE7ebca9**](SuccessResponseUserListResponseE7ebca9.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**403** | Forbidden |  -  |
**422** | Unprocessable Content |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_usersemail**
> SuccessResponseUserResponseE7ebca9 get_api_v1_usersemail(email)

Get detailed information about a user.

Args:     email: User email address (URL encoded)

Returns:     200: User details with roles and permissions     404: User not found

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.models.success_response_user_response_e7ebca9 import SuccessResponseUserResponseE7ebca9
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.UsersApi(api_client)
    email = 'email_example' # str | 

    try:
        # Get detailed information about a user.
        api_response = api_instance.get_api_v1_usersemail(email)
        print("The response of UsersApi->get_api_v1_usersemail:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling UsersApi->get_api_v1_usersemail: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **email** | **str**|  | 

### Return type

[**SuccessResponseUserResponseE7ebca9**](SuccessResponseUserResponseE7ebca9.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**404** | Not Found |  -  |
**422** | Unprocessable Content |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **patch_api_v1_usersemail**
> SuccessResponseUserResponseE7ebca9 patch_api_v1_usersemail(email)

Update user roles.

Request Body:     {         "roles": ["workflow_viewer", "analytics"]  // Replace all roles     }

Args:     email: User email address (URL encoded)

Returns:     200: User updated     404: User not found

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.models.success_response_user_response_e7ebca9 import SuccessResponseUserResponseE7ebca9
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.UsersApi(api_client)
    email = 'email_example' # str | 

    try:
        # Update user roles.
        api_response = api_instance.patch_api_v1_usersemail(email)
        print("The response of UsersApi->patch_api_v1_usersemail:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling UsersApi->patch_api_v1_usersemail: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **email** | **str**|  | 

### Return type

[**SuccessResponseUserResponseE7ebca9**](SuccessResponseUserResponseE7ebca9.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**404** | Not Found |  -  |
**422** | Unprocessable Content |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_api_v1_users**
> SuccessResponseUserResponseE7ebca9 post_api_v1_users()

Create a new user by assigning them to a role.

Request Body:     {         "email": "user@example.com",         "role": "workflow_viewer",         "roles": ["workflow_viewer", "analytics"]  // Alternative: multiple roles     }

Returns:     201: User created successfully     400: Invalid request (missing email or invalid role)     409: User already exists

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.models.success_response_user_response_e7ebca9 import SuccessResponseUserResponseE7ebca9
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.UsersApi(api_client)

    try:
        # Create a new user by assigning them to a role.
        api_response = api_instance.post_api_v1_users()
        print("The response of UsersApi->post_api_v1_users:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling UsersApi->post_api_v1_users: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**SuccessResponseUserResponseE7ebca9**](SuccessResponseUserResponseE7ebca9.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | Created |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**422** | Unprocessable Content |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_api_v1_usersemail_roles**
> SuccessResponseRoleAssignResponseE7ebca9 post_api_v1_usersemail_roles(email)

Assign a role to an existing user.

Request Body:     {         "role": "workflow_viewer"     }

Args:     email: User email address (URL encoded)

Returns:     200: Role assigned     400: Invalid role     404: User not found

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.models.success_response_role_assign_response_e7ebca9 import SuccessResponseRoleAssignResponseE7ebca9
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.UsersApi(api_client)
    email = 'email_example' # str | 

    try:
        # Assign a role to an existing user.
        api_response = api_instance.post_api_v1_usersemail_roles(email)
        print("The response of UsersApi->post_api_v1_usersemail_roles:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling UsersApi->post_api_v1_usersemail_roles: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **email** | **str**|  | 

### Return type

[**SuccessResponseRoleAssignResponseE7ebca9**](SuccessResponseRoleAssignResponseE7ebca9.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**404** | Not Found |  -  |
**422** | Unprocessable Content |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

