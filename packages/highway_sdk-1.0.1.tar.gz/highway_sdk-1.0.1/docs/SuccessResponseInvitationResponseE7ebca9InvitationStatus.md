# SuccessResponseInvitationResponseE7ebca9InvitationStatus

Invitation status.

## Enum

* `PENDING` (value: `'pending'`)

* `ACCEPTED` (value: `'accepted'`)

* `EXPIRED` (value: `'expired'`)

* `REVOKED` (value: `'revoked'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


