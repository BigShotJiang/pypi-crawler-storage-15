# SuccessResponseApiKeyListResponseE7ebca9ApiKeyResponse

API key details response (without secret).

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**allowed_ips** | **List[str]** |  | [optional] 
**api_key_id** | **str** | API key ID (UUID) | 
**created_at** | **datetime** |  | [optional] 
**created_by** | **str** |  | [optional] 
**expires_at** | **datetime** |  | [optional] 
**key_prefix** | **str** | Key prefix for identification | 
**last_used_at** | **datetime** |  | [optional] 
**name** | **str** | API key name | 
**permissions** | **List[str]** | Permissions | [optional] 
**rate_limit** | **int** | Rate limit (requests/minute) | 
**status** | [**SuccessResponseApiKeyListResponseE7ebca9TokenStatus**](SuccessResponseApiKeyListResponseE7ebca9TokenStatus.md) | API key status | 

## Example

```python
from highway_sdk.models.success_response_api_key_list_response_e7ebca9_api_key_response import SuccessResponseApiKeyListResponseE7ebca9ApiKeyResponse

# TODO update the JSON string below
json = "{}"
# create an instance of SuccessResponseApiKeyListResponseE7ebca9ApiKeyResponse from a JSON string
success_response_api_key_list_response_e7ebca9_api_key_response_instance = SuccessResponseApiKeyListResponseE7ebca9ApiKeyResponse.from_json(json)
# print the JSON string representation of the object
print(SuccessResponseApiKeyListResponseE7ebca9ApiKeyResponse.to_json())

# convert the object into a dict
success_response_api_key_list_response_e7ebca9_api_key_response_dict = success_response_api_key_list_response_e7ebca9_api_key_response_instance.to_dict()
# create an instance of SuccessResponseApiKeyListResponseE7ebca9ApiKeyResponse from a dict
success_response_api_key_list_response_e7ebca9_api_key_response_from_dict = SuccessResponseApiKeyListResponseE7ebca9ApiKeyResponse.from_dict(success_response_api_key_list_response_e7ebca9_api_key_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


