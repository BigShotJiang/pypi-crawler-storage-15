# highway_sdk.TokensApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**delete_api_v1_admin_tokenstoken_id**](TokensApi.md#delete_api_v1_admin_tokenstoken_id) | **DELETE** /api/v1/admin/tokens/{token_id} | Revoke an API token.
[**get_api_v1_admin_tokens**](TokensApi.md#get_api_v1_admin_tokens) | **GET** /api/v1/admin/tokens | List all API tokens for the current tenant.
[**get_api_v1_admin_tokenstoken_id**](TokensApi.md#get_api_v1_admin_tokenstoken_id) | **GET** /api/v1/admin/tokens/{token_id} | Get details for a specific API token.
[**post_api_v1_admin_tokens**](TokensApi.md#post_api_v1_admin_tokens) | **POST** /api/v1/admin/tokens | Generate API token for a user.
[**post_api_v1_admin_tokens_revoke_alluser_email**](TokensApi.md#post_api_v1_admin_tokens_revoke_alluser_email) | **POST** /api/v1/admin/tokens/revoke-all/{user_email} | Revoke all API tokens for a specific user.


# **delete_api_v1_admin_tokenstoken_id**
> SuccessResponseTokenRevokeResponseE7ebca9 delete_api_v1_admin_tokenstoken_id(token_id)

Revoke an API token.

Args:     token_id: Token UUID

Request Body (optional):     {         "reason": "Security concern"  // Optional reason for revocation     }

Returns:     200: Token revoked     404: Token not found     409: Token already revoked

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.models.success_response_token_revoke_response_e7ebca9 import SuccessResponseTokenRevokeResponseE7ebca9
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.TokensApi(api_client)
    token_id = 'token_id_example' # str | 

    try:
        # Revoke an API token.
        api_response = api_instance.delete_api_v1_admin_tokenstoken_id(token_id)
        print("The response of TokensApi->delete_api_v1_admin_tokenstoken_id:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling TokensApi->delete_api_v1_admin_tokenstoken_id: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **token_id** | **str**|  | 

### Return type

[**SuccessResponseTokenRevokeResponseE7ebca9**](SuccessResponseTokenRevokeResponseE7ebca9.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**404** | Not Found |  -  |
**409** | Conflict |  -  |
**422** | Unprocessable Content |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_admin_tokens**
> SuccessResponseTokenListResponseE7ebca9 get_api_v1_admin_tokens()

List all API tokens for the current tenant.

Query Parameters:     user_email: Filter by user email (optional)     include_revoked: Include revoked tokens (default: false)     page: Page number (default: 1)     per_page: Items per page (default: 50, max: 200)

Returns:     200: {         "tokens": [...],         "total": 10,         "page": 1,         "per_page": 50     }

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.models.success_response_token_list_response_e7ebca9 import SuccessResponseTokenListResponseE7ebca9
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.TokensApi(api_client)

    try:
        # List all API tokens for the current tenant.
        api_response = api_instance.get_api_v1_admin_tokens()
        print("The response of TokensApi->get_api_v1_admin_tokens:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling TokensApi->get_api_v1_admin_tokens: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**SuccessResponseTokenListResponseE7ebca9**](SuccessResponseTokenListResponseE7ebca9.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**422** | Unprocessable Content |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_admin_tokenstoken_id**
> SuccessResponseTokenResponseE7ebca9 get_api_v1_admin_tokenstoken_id(token_id)

Get details for a specific API token.

Args:     token_id: Token UUID

Returns:     200: Token details     404: Token not found

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.models.success_response_token_response_e7ebca9 import SuccessResponseTokenResponseE7ebca9
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.TokensApi(api_client)
    token_id = 'token_id_example' # str | 

    try:
        # Get details for a specific API token.
        api_response = api_instance.get_api_v1_admin_tokenstoken_id(token_id)
        print("The response of TokensApi->get_api_v1_admin_tokenstoken_id:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling TokensApi->get_api_v1_admin_tokenstoken_id: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **token_id** | **str**|  | 

### Return type

[**SuccessResponseTokenResponseE7ebca9**](SuccessResponseTokenResponseE7ebca9.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**404** | Not Found |  -  |
**422** | Unprocessable Content |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_api_v1_admin_tokens**
> SuccessResponseTokenCreateResponseE7ebca9 post_api_v1_admin_tokens()

Generate API token for a user.

Request Body:     {         "user_email": "user@example.com",         "expires_in_hours": 24,       // Optional, default: 24, max: 8760 (1 year)         "description": "CI/CD token", // Optional, for identification         "scopes": ["view_workflows", "run_workflows"]  // Optional, limit permissions     }

Returns:     201: {         "token_id": "uuid",         "token": "jwt_string",       // Only returned once!         "user_email": "user@example.com",         "expires_at": "2025-11-28T10:00:00Z",         "description": "CI/CD token",         "scopes": ["view_workflows", "run_workflows"] or null     }

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.models.success_response_token_create_response_e7ebca9 import SuccessResponseTokenCreateResponseE7ebca9
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.TokensApi(api_client)

    try:
        # Generate API token for a user.
        api_response = api_instance.post_api_v1_admin_tokens()
        print("The response of TokensApi->post_api_v1_admin_tokens:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling TokensApi->post_api_v1_admin_tokens: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**SuccessResponseTokenCreateResponseE7ebca9**](SuccessResponseTokenCreateResponseE7ebca9.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | Created |  -  |
**400** | Bad Request |  -  |
**422** | Unprocessable Content |  -  |
**503** | Service Unavailable |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_api_v1_admin_tokens_revoke_alluser_email**
> SuccessResponseTokenRevokeAllResponseE7ebca9 post_api_v1_admin_tokens_revoke_alluser_email(user_email)

Revoke all API tokens for a specific user.

Useful for: - User account compromise - Employee offboarding - Security incident response - Password reset (invalidate all sessions)

Args:     user_email: User email address (URL encoded)

Request Body (optional):     {         "reason": "Account compromised"  // Optional reason for revocation     }

Returns:     200: {tokens_revoked: count, user_email, ...}     404: No active tokens found for user

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.models.success_response_token_revoke_all_response_e7ebca9 import SuccessResponseTokenRevokeAllResponseE7ebca9
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.TokensApi(api_client)
    user_email = 'user_email_example' # str | 

    try:
        # Revoke all API tokens for a specific user.
        api_response = api_instance.post_api_v1_admin_tokens_revoke_alluser_email(user_email)
        print("The response of TokensApi->post_api_v1_admin_tokens_revoke_alluser_email:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling TokensApi->post_api_v1_admin_tokens_revoke_alluser_email: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_email** | **str**|  | 

### Return type

[**SuccessResponseTokenRevokeAllResponseE7ebca9**](SuccessResponseTokenRevokeAllResponseE7ebca9.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**404** | Not Found |  -  |
**422** | Unprocessable Content |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

