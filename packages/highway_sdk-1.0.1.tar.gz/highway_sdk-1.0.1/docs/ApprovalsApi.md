# highway_sdk.ApprovalsApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_api_v1_approvals**](ApprovalsApi.md#get_api_v1_approvals) | **GET** /api/v1/approvals | List approvals with optional filtering.
[**get_api_v1_approvalsapproval_key**](ApprovalsApi.md#get_api_v1_approvalsapproval_key) | **GET** /api/v1/approvals/{approval_key} | Get a specific approval by key.
[**post_api_v1_approvalsapproval_key_approve**](ApprovalsApi.md#post_api_v1_approvalsapproval_key_approve) | **POST** /api/v1/approvals/{approval_key}/approve | Approve a pending approval.
[**post_api_v1_approvalsapproval_key_reject**](ApprovalsApi.md#post_api_v1_approvalsapproval_key_reject) | **POST** /api/v1/approvals/{approval_key}/reject | Reject a pending approval.


# **get_api_v1_approvals**
> get_api_v1_approvals()

List approvals with optional filtering.



### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.ApprovalsApi(api_client)

    try:
        # List approvals with optional filtering.
        api_instance.get_api_v1_approvals()
    except Exception as e:
        print("Exception when calling ApprovalsApi->get_api_v1_approvals: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_approvalsapproval_key**
> get_api_v1_approvalsapproval_key(approval_key)

Get a specific approval by key.



### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.ApprovalsApi(api_client)
    approval_key = 'approval_key_example' # str | 

    try:
        # Get a specific approval by key.
        api_instance.get_api_v1_approvalsapproval_key(approval_key)
    except Exception as e:
        print("Exception when calling ApprovalsApi->get_api_v1_approvalsapproval_key: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **approval_key** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_api_v1_approvalsapproval_key_approve**
> post_api_v1_approvalsapproval_key_approve(approval_key)

Approve a pending approval.



### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.ApprovalsApi(api_client)
    approval_key = 'approval_key_example' # str | 

    try:
        # Approve a pending approval.
        api_instance.post_api_v1_approvalsapproval_key_approve(approval_key)
    except Exception as e:
        print("Exception when calling ApprovalsApi->post_api_v1_approvalsapproval_key_approve: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **approval_key** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_api_v1_approvalsapproval_key_reject**
> post_api_v1_approvalsapproval_key_reject(approval_key)

Reject a pending approval.



### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.ApprovalsApi(api_client)
    approval_key = 'approval_key_example' # str | 

    try:
        # Reject a pending approval.
        api_instance.post_api_v1_approvalsapproval_key_reject(approval_key)
    except Exception as e:
        print("Exception when calling ApprovalsApi->post_api_v1_approvalsapproval_key_reject: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **approval_key** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

