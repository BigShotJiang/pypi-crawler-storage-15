# highway_sdk.TenantAppsApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**delete_api_v1_tenant_appsinstallation_id**](TenantAppsApi.md#delete_api_v1_tenant_appsinstallation_id) | **DELETE** /api/v1/tenant/apps/{installation_id} | Uninstall an app.
[**delete_api_v1_tenant_appsinstallation_id_secretssecret_name**](TenantAppsApi.md#delete_api_v1_tenant_appsinstallation_id_secretssecret_name) | **DELETE** /api/v1/tenant/apps/{installation_id}/secrets/{secret_name} | Delete a secret for an app.
[**get_api_v1_tenant_apps**](TenantAppsApi.md#get_api_v1_tenant_apps) | **GET** /api/v1/tenant/apps | List apps installed for this tenant.
[**get_api_v1_tenant_apps_tools**](TenantAppsApi.md#get_api_v1_tenant_apps_tools) | **GET** /api/v1/tenant/apps/tools | List all tools available to this tenant from installed apps.
[**get_api_v1_tenant_appsinstallation_id**](TenantAppsApi.md#get_api_v1_tenant_appsinstallation_id) | **GET** /api/v1/tenant/apps/{installation_id} | Get installation details.
[**get_api_v1_tenant_appsinstallation_id_config**](TenantAppsApi.md#get_api_v1_tenant_appsinstallation_id_config) | **GET** /api/v1/tenant/apps/{installation_id}/config | Get app configuration.
[**get_api_v1_tenant_appsinstallation_id_logs**](TenantAppsApi.md#get_api_v1_tenant_appsinstallation_id_logs) | **GET** /api/v1/tenant/apps/{installation_id}/logs | Get execution logs for an app.
[**get_api_v1_tenant_appsinstallation_id_logslog_id**](TenantAppsApi.md#get_api_v1_tenant_appsinstallation_id_logslog_id) | **GET** /api/v1/tenant/apps/{installation_id}/logs/{log_id} | Get detailed execution log.
[**get_api_v1_tenant_appsinstallation_id_secrets**](TenantAppsApi.md#get_api_v1_tenant_appsinstallation_id_secrets) | **GET** /api/v1/tenant/apps/{installation_id}/secrets | List configured secrets for an app (names only, not values).
[**patch_api_v1_tenant_appsinstallation_id_config**](TenantAppsApi.md#patch_api_v1_tenant_appsinstallation_id_config) | **PATCH** /api/v1/tenant/apps/{installation_id}/config | Update app configuration.
[**post_api_v1_tenant_apps**](TenantAppsApi.md#post_api_v1_tenant_apps) | **POST** /api/v1/tenant/apps | Install an app for this tenant.
[**post_api_v1_tenant_appsinstallation_id_disable**](TenantAppsApi.md#post_api_v1_tenant_appsinstallation_id_disable) | **POST** /api/v1/tenant/apps/{installation_id}/disable | Disable an app (workflows using it will fail).
[**post_api_v1_tenant_appsinstallation_id_enable**](TenantAppsApi.md#post_api_v1_tenant_appsinstallation_id_enable) | **POST** /api/v1/tenant/apps/{installation_id}/enable | Enable a disabled app.
[**post_api_v1_tenant_appsinstallation_id_upgrade**](TenantAppsApi.md#post_api_v1_tenant_appsinstallation_id_upgrade) | **POST** /api/v1/tenant/apps/{installation_id}/upgrade | Upgrade app to a new version.
[**put_api_v1_tenant_appsinstallation_id_secretssecret_name**](TenantAppsApi.md#put_api_v1_tenant_appsinstallation_id_secretssecret_name) | **PUT** /api/v1/tenant/apps/{installation_id}/secrets/{secret_name} | Set a secret value for an app.


# **delete_api_v1_tenant_appsinstallation_id**
> delete_api_v1_tenant_appsinstallation_id(installation_id)

Uninstall an app.

Returns:     200: App uninstalled     404: Installation not found

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.TenantAppsApi(api_client)
    installation_id = 'installation_id_example' # str | 

    try:
        # Uninstall an app.
        api_instance.delete_api_v1_tenant_appsinstallation_id(installation_id)
    except Exception as e:
        print("Exception when calling TenantAppsApi->delete_api_v1_tenant_appsinstallation_id: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **installation_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_api_v1_tenant_appsinstallation_id_secretssecret_name**
> delete_api_v1_tenant_appsinstallation_id_secretssecret_name(installation_id, secret_name)

Delete a secret for an app.

Returns:     200: Secret deleted     404: Installation or secret not found

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.TenantAppsApi(api_client)
    installation_id = 'installation_id_example' # str | 
    secret_name = 'secret_name_example' # str | 

    try:
        # Delete a secret for an app.
        api_instance.delete_api_v1_tenant_appsinstallation_id_secretssecret_name(installation_id, secret_name)
    except Exception as e:
        print("Exception when calling TenantAppsApi->delete_api_v1_tenant_appsinstallation_id_secretssecret_name: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **installation_id** | **str**|  | 
 **secret_name** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_tenant_apps**
> get_api_v1_tenant_apps()

List apps installed for this tenant.

Query Parameters:     page: Page number (default: 1)     page_size: Items per page (default: 20, max: 100)     status: Filter by status (enabled/disabled)     category: Filter by category

Returns:     200: Paginated list of installed apps

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.TenantAppsApi(api_client)

    try:
        # List apps installed for this tenant.
        api_instance.get_api_v1_tenant_apps()
    except Exception as e:
        print("Exception when calling TenantAppsApi->get_api_v1_tenant_apps: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_tenant_apps_tools**
> get_api_v1_tenant_apps_tools()

List all tools available to this tenant from installed apps.

Returns:     200: List of available app tools

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.TenantAppsApi(api_client)

    try:
        # List all tools available to this tenant from installed apps.
        api_instance.get_api_v1_tenant_apps_tools()
    except Exception as e:
        print("Exception when calling TenantAppsApi->get_api_v1_tenant_apps_tools: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_tenant_appsinstallation_id**
> get_api_v1_tenant_appsinstallation_id(installation_id)

Get installation details.

Returns:     200: Installation details     404: Installation not found

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.TenantAppsApi(api_client)
    installation_id = 'installation_id_example' # str | 

    try:
        # Get installation details.
        api_instance.get_api_v1_tenant_appsinstallation_id(installation_id)
    except Exception as e:
        print("Exception when calling TenantAppsApi->get_api_v1_tenant_appsinstallation_id: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **installation_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_tenant_appsinstallation_id_config**
> get_api_v1_tenant_appsinstallation_id_config(installation_id)

Get app configuration.

Returns:     200: Configuration with schema     404: Installation not found

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.TenantAppsApi(api_client)
    installation_id = 'installation_id_example' # str | 

    try:
        # Get app configuration.
        api_instance.get_api_v1_tenant_appsinstallation_id_config(installation_id)
    except Exception as e:
        print("Exception when calling TenantAppsApi->get_api_v1_tenant_appsinstallation_id_config: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **installation_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_tenant_appsinstallation_id_logs**
> get_api_v1_tenant_appsinstallation_id_logs(installation_id)

Get execution logs for an app.

Query Parameters:     page: Page number (default: 1)     page_size: Items per page (default: 50, max: 200)     status: Filter by status (success/error)     action_name: Filter by action     start_time: Filter from timestamp (ISO format)     end_time: Filter to timestamp (ISO format)

Returns:     200: Paginated execution logs     404: Installation not found

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.TenantAppsApi(api_client)
    installation_id = 'installation_id_example' # str | 

    try:
        # Get execution logs for an app.
        api_instance.get_api_v1_tenant_appsinstallation_id_logs(installation_id)
    except Exception as e:
        print("Exception when calling TenantAppsApi->get_api_v1_tenant_appsinstallation_id_logs: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **installation_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_tenant_appsinstallation_id_logslog_id**
> get_api_v1_tenant_appsinstallation_id_logslog_id(installation_id, log_id)

Get detailed execution log.

Returns:     200: Log details including input/output     404: Log not found

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.TenantAppsApi(api_client)
    installation_id = 'installation_id_example' # str | 
    log_id = 'log_id_example' # str | 

    try:
        # Get detailed execution log.
        api_instance.get_api_v1_tenant_appsinstallation_id_logslog_id(installation_id, log_id)
    except Exception as e:
        print("Exception when calling TenantAppsApi->get_api_v1_tenant_appsinstallation_id_logslog_id: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **installation_id** | **str**|  | 
 **log_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_tenant_appsinstallation_id_secrets**
> get_api_v1_tenant_appsinstallation_id_secrets(installation_id)

List configured secrets for an app (names only, not values).

Returns:     200: List of secret names and their status     404: Installation not found

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.TenantAppsApi(api_client)
    installation_id = 'installation_id_example' # str | 

    try:
        # List configured secrets for an app (names only, not values).
        api_instance.get_api_v1_tenant_appsinstallation_id_secrets(installation_id)
    except Exception as e:
        print("Exception when calling TenantAppsApi->get_api_v1_tenant_appsinstallation_id_secrets: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **installation_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **patch_api_v1_tenant_appsinstallation_id_config**
> patch_api_v1_tenant_appsinstallation_id_config(installation_id)

Update app configuration.

Request Body:     {         "configuration": {...}     }

Returns:     200: Configuration updated     400: Invalid configuration     404: Installation not found

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.TenantAppsApi(api_client)
    installation_id = 'installation_id_example' # str | 

    try:
        # Update app configuration.
        api_instance.patch_api_v1_tenant_appsinstallation_id_config(installation_id)
    except Exception as e:
        print("Exception when calling TenantAppsApi->patch_api_v1_tenant_appsinstallation_id_config: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **installation_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_api_v1_tenant_apps**
> post_api_v1_tenant_apps()

Install an app for this tenant.

Request Body:     {         "app_id": "uuid",         "version_id": "uuid" (optional, defaults to latest published),         "configuration": {...} (optional)     }

Returns:     201: App installed     400: Invalid input     404: App/version not found     409: App already installed

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.TenantAppsApi(api_client)

    try:
        # Install an app for this tenant.
        api_instance.post_api_v1_tenant_apps()
    except Exception as e:
        print("Exception when calling TenantAppsApi->post_api_v1_tenant_apps: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_api_v1_tenant_appsinstallation_id_disable**
> post_api_v1_tenant_appsinstallation_id_disable(installation_id)

Disable an app (workflows using it will fail).

Returns:     200: App disabled     400: Already disabled     404: Installation not found

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.TenantAppsApi(api_client)
    installation_id = 'installation_id_example' # str | 

    try:
        # Disable an app (workflows using it will fail).
        api_instance.post_api_v1_tenant_appsinstallation_id_disable(installation_id)
    except Exception as e:
        print("Exception when calling TenantAppsApi->post_api_v1_tenant_appsinstallation_id_disable: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **installation_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_api_v1_tenant_appsinstallation_id_enable**
> post_api_v1_tenant_appsinstallation_id_enable(installation_id)

Enable a disabled app.

Returns:     200: App enabled     400: Already enabled     404: Installation not found

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.TenantAppsApi(api_client)
    installation_id = 'installation_id_example' # str | 

    try:
        # Enable a disabled app.
        api_instance.post_api_v1_tenant_appsinstallation_id_enable(installation_id)
    except Exception as e:
        print("Exception when calling TenantAppsApi->post_api_v1_tenant_appsinstallation_id_enable: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **installation_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_api_v1_tenant_appsinstallation_id_upgrade**
> post_api_v1_tenant_appsinstallation_id_upgrade(installation_id)

Upgrade app to a new version.

Request Body:     {         "version_id": "uuid" (optional, defaults to latest published)     }

Returns:     200: App upgraded     400: Already on this version / downgrade not allowed     404: Installation or version not found

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.TenantAppsApi(api_client)
    installation_id = 'installation_id_example' # str | 

    try:
        # Upgrade app to a new version.
        api_instance.post_api_v1_tenant_appsinstallation_id_upgrade(installation_id)
    except Exception as e:
        print("Exception when calling TenantAppsApi->post_api_v1_tenant_appsinstallation_id_upgrade: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **installation_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **put_api_v1_tenant_appsinstallation_id_secretssecret_name**
> put_api_v1_tenant_appsinstallation_id_secretssecret_name(installation_id, secret_name)

Set a secret value for an app.

Request Body:     {         "value": "secret-value"     }

Returns:     200: Secret stored     400: Invalid input     404: Installation not found

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.TenantAppsApi(api_client)
    installation_id = 'installation_id_example' # str | 
    secret_name = 'secret_name_example' # str | 

    try:
        # Set a secret value for an app.
        api_instance.put_api_v1_tenant_appsinstallation_id_secretssecret_name(installation_id, secret_name)
    except Exception as e:
        print("Exception when calling TenantAppsApi->put_api_v1_tenant_appsinstallation_id_secretssecret_name: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **installation_id** | **str**|  | 
 **secret_name** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

