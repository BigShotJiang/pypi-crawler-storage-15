# highway_sdk.RunsApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_api_v1_runs**](RunsApi.md#get_api_v1_runs) | **GET** /api/v1/runs | List active runs with pagination and filtering.
[**get_api_v1_runsrun_id**](RunsApi.md#get_api_v1_runsrun_id) | **GET** /api/v1/runs/{run_id} | Get run status by ID.
[**get_api_v1_runsrun_id_checkpoints**](RunsApi.md#get_api_v1_runsrun_id_checkpoints) | **GET** /api/v1/runs/{run_id}/checkpoints | **RBAC Permission:** &#x60;view_workflows&#x60;


# **get_api_v1_runs**
> get_api_v1_runs()

List active runs with pagination and filtering.

**RBAC Permission:** `view_workflows`

Query Parameters:     page: Page number (default: 1)     page_size: Items per page (default: 20, max: 100)     state: Filter by state (pending, running, sleeping)

Returns:     200: List of runs     400: Invalid parameters     500: Internal server error

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.RunsApi(api_client)

    try:
        # List active runs with pagination and filtering.
        api_instance.get_api_v1_runs()
    except Exception as e:
        print("Exception when calling RunsApi->get_api_v1_runs: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_runsrun_id**
> get_api_v1_runsrun_id(run_id)

Get run status by ID.

**RBAC Permission:** `view_workflow_status`

Args:     run_id: Run ID (UUID)

Returns:     200: Run status details     400: Invalid UUID     404: Run not found     500: Internal server error

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.RunsApi(api_client)
    run_id = 'run_id_example' # str | 

    try:
        # Get run status by ID.
        api_instance.get_api_v1_runsrun_id(run_id)
    except Exception as e:
        print("Exception when calling RunsApi->get_api_v1_runsrun_id: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **run_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_runsrun_id_checkpoints**
> get_api_v1_runsrun_id_checkpoints(run_id)

**RBAC Permission:** `view_workflows`



### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.RunsApi(api_client)
    run_id = 'run_id_example' # str | 

    try:
        # **RBAC Permission:** `view_workflows`
        api_instance.get_api_v1_runsrun_id_checkpoints(run_id)
    except Exception as e:
        print("Exception when calling RunsApi->get_api_v1_runsrun_id_checkpoints: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **run_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

