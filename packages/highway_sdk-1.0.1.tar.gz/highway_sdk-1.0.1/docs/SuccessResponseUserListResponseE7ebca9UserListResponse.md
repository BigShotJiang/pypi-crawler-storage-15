# SuccessResponseUserListResponseE7ebca9UserListResponse

List of users.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**total** | **int** | Total count | 
**users** | [**List[SuccessResponseUserListResponseE7ebca9UserResponse]**](SuccessResponseUserListResponseE7ebca9UserResponse.md) | User list | 

## Example

```python
from highway_sdk.models.success_response_user_list_response_e7ebca9_user_list_response import SuccessResponseUserListResponseE7ebca9UserListResponse

# TODO update the JSON string below
json = "{}"
# create an instance of SuccessResponseUserListResponseE7ebca9UserListResponse from a JSON string
success_response_user_list_response_e7ebca9_user_list_response_instance = SuccessResponseUserListResponseE7ebca9UserListResponse.from_json(json)
# print the JSON string representation of the object
print(SuccessResponseUserListResponseE7ebca9UserListResponse.to_json())

# convert the object into a dict
success_response_user_list_response_e7ebca9_user_list_response_dict = success_response_user_list_response_e7ebca9_user_list_response_instance.to_dict()
# create an instance of SuccessResponseUserListResponseE7ebca9UserListResponse from a dict
success_response_user_list_response_e7ebca9_user_list_response_from_dict = SuccessResponseUserListResponseE7ebca9UserListResponse.from_dict(success_response_user_list_response_e7ebca9_user_list_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


