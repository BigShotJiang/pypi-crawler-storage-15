# highway_sdk.ActivitiesApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_api_v1_activities**](ActivitiesApi.md#get_api_v1_activities) | **GET** /api/v1/activities | List activities with filtering.
[**get_api_v1_activities_stale**](ActivitiesApi.md#get_api_v1_activities_stale) | **GET** /api/v1/activities/stale | Get list of activities that appear to be stuck.
[**get_api_v1_activities_status**](ActivitiesApi.md#get_api_v1_activities_status) | **GET** /api/v1/activities/status | Get real-time status of all activity workers and queue.
[**get_api_v1_activitiesactivity_id**](ActivitiesApi.md#get_api_v1_activitiesactivity_id) | **GET** /api/v1/activities/{activity_id} | Get detailed information about a specific activity.
[**get_api_v1_activitiesactivity_id_heartbeats**](ActivitiesApi.md#get_api_v1_activitiesactivity_id_heartbeats) | **GET** /api/v1/activities/{activity_id}/heartbeats | Get heartbeat history for an activity.
[**get_api_v1_workflowsworkflow_run_id_activities**](ActivitiesApi.md#get_api_v1_workflowsworkflow_run_id_activities) | **GET** /api/v1/workflows/{workflow_run_id}/activities | Get all activities spawned by a workflow run.
[**post_api_v1_activities_cleanup_heartbeats**](ActivitiesApi.md#post_api_v1_activities_cleanup_heartbeats) | **POST** /api/v1/activities/cleanup-heartbeats | Clean up old heartbeat history records.


# **get_api_v1_activities**
> get_api_v1_activities()

List activities with filtering.

Query parameters:     status: Filter by status (pending, running, completed, failed, cancelled)     worker_id: Filter by worker     function_name: Filter by function (partial match)     workflow_run_id: Filter by workflow run     limit: Max results (default: 100, max: 500)     offset: Pagination offset

Returns:     200: List of activities

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.ActivitiesApi(api_client)

    try:
        # List activities with filtering.
        api_instance.get_api_v1_activities()
    except Exception as e:
        print("Exception when calling ActivitiesApi->get_api_v1_activities: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_activities_stale**
> get_api_v1_activities_stale()

Get list of activities that appear to be stuck.

Activities are considered stale if they are running but haven't sent a heartbeat within the threshold period.

Query parameters:     threshold: Seconds without heartbeat (default: 60)

Returns:     200: List of stale activities

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.ActivitiesApi(api_client)

    try:
        # Get list of activities that appear to be stuck.
        api_instance.get_api_v1_activities_stale()
    except Exception as e:
        print("Exception when calling ActivitiesApi->get_api_v1_activities_stale: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_activities_status**
> get_api_v1_activities_status()

Get real-time status of all activity workers and queue.

Returns aggregated status including: - Workers with their current activities - Queue summary (pending, running, completed, failed counts) - Stale activity detection

Query parameters:     stale_threshold: Seconds without heartbeat to consider stale (default: 60)

Returns:     200: Activity status overview

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.ActivitiesApi(api_client)

    try:
        # Get real-time status of all activity workers and queue.
        api_instance.get_api_v1_activities_status()
    except Exception as e:
        print("Exception when calling ActivitiesApi->get_api_v1_activities_status: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_activitiesactivity_id**
> get_api_v1_activitiesactivity_id(activity_id)

Get detailed information about a specific activity.

Returns: - Current status and progress - Worker executing it - Function and parameters - Timing information - Link to workflow run - Heartbeat history (if available)

Args:     activity_id: Activity UUID

Query parameters:     include_heartbeats: Include heartbeat history (default: true)     heartbeat_limit: Max heartbeats to return (default: 50)

Returns:     200: Activity details     404: Activity not found

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.ActivitiesApi(api_client)
    activity_id = 'activity_id_example' # str | 

    try:
        # Get detailed information about a specific activity.
        api_instance.get_api_v1_activitiesactivity_id(activity_id)
    except Exception as e:
        print("Exception when calling ActivitiesApi->get_api_v1_activitiesactivity_id: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **activity_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_activitiesactivity_id_heartbeats**
> get_api_v1_activitiesactivity_id_heartbeats(activity_id)

Get heartbeat history for an activity.

Useful for debugging stuck activities by seeing heartbeat patterns.

Args:     activity_id: Activity UUID

Query parameters:     limit: Max heartbeats to return (default: 100, max: 500)

Returns:     200: Heartbeat history     404: Activity not found

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.ActivitiesApi(api_client)
    activity_id = 'activity_id_example' # str | 

    try:
        # Get heartbeat history for an activity.
        api_instance.get_api_v1_activitiesactivity_id_heartbeats(activity_id)
    except Exception as e:
        print("Exception when calling ActivitiesApi->get_api_v1_activitiesactivity_id_heartbeats: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **activity_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_workflowsworkflow_run_id_activities**
> get_api_v1_workflowsworkflow_run_id_activities(workflow_run_id)

Get all activities spawned by a workflow run.

Returns activities in creation order with status and timing info.

Args:     workflow_run_id: Workflow run UUID

Query parameters:     include_completed: Include completed/failed activities (default: true)

Returns:     200: List of activities for the workflow     404: Workflow run not found

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.ActivitiesApi(api_client)
    workflow_run_id = 'workflow_run_id_example' # str | 

    try:
        # Get all activities spawned by a workflow run.
        api_instance.get_api_v1_workflowsworkflow_run_id_activities(workflow_run_id)
    except Exception as e:
        print("Exception when calling ActivitiesApi->get_api_v1_workflowsworkflow_run_id_activities: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_run_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_api_v1_activities_cleanup_heartbeats**
> post_api_v1_activities_cleanup_heartbeats()

Clean up old heartbeat history records.

Request body:     retention_hours: Hours to retain (default: 24)

Returns:     200: Cleanup summary

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.ActivitiesApi(api_client)

    try:
        # Clean up old heartbeat history records.
        api_instance.post_api_v1_activities_cleanup_heartbeats()
    except Exception as e:
        print("Exception when calling ActivitiesApi->post_api_v1_activities_cleanup_heartbeats: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

