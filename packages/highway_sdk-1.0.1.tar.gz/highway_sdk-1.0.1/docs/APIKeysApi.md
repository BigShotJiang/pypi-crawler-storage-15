# highway_sdk.APIKeysApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**delete_api_v1_admin_api_keysapi_key_id**](APIKeysApi.md#delete_api_v1_admin_api_keysapi_key_id) | **DELETE** /api/v1/admin/api-keys/{api_key_id} | Deactivate an API key.
[**get_api_v1_admin_api_keys**](APIKeysApi.md#get_api_v1_admin_api_keys) | **GET** /api/v1/admin/api-keys | List all API keys for the current tenant.
[**get_api_v1_admin_api_keysapi_key_id**](APIKeysApi.md#get_api_v1_admin_api_keysapi_key_id) | **GET** /api/v1/admin/api-keys/{api_key_id} | Get details for a specific API key.
[**post_api_v1_admin_api_keys**](APIKeysApi.md#post_api_v1_admin_api_keys) | **POST** /api/v1/admin/api-keys | Create a new API key for service account access.
[**post_api_v1_admin_api_keysapi_key_id_rotate**](APIKeysApi.md#post_api_v1_admin_api_keysapi_key_id_rotate) | **POST** /api/v1/admin/api-keys/{api_key_id}/rotate | Rotate an API key with optional grace period.


# **delete_api_v1_admin_api_keysapi_key_id**
> SuccessResponseApiKeyRevokeResponseE7ebca9 delete_api_v1_admin_api_keysapi_key_id(api_key_id)

Deactivate an API key.

Args:     api_key_id: API Key UUID

Request Body (optional):     {         "reason": "No longer needed"  // Optional reason     }

Returns:     200: API key deactivated     404: API key not found     409: API key already deactivated

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.models.success_response_api_key_revoke_response_e7ebca9 import SuccessResponseApiKeyRevokeResponseE7ebca9
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.APIKeysApi(api_client)
    api_key_id = 'api_key_id_example' # str | 

    try:
        # Deactivate an API key.
        api_response = api_instance.delete_api_v1_admin_api_keysapi_key_id(api_key_id)
        print("The response of APIKeysApi->delete_api_v1_admin_api_keysapi_key_id:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling APIKeysApi->delete_api_v1_admin_api_keysapi_key_id: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **api_key_id** | **str**|  | 

### Return type

[**SuccessResponseApiKeyRevokeResponseE7ebca9**](SuccessResponseApiKeyRevokeResponseE7ebca9.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**404** | Not Found |  -  |
**409** | Conflict |  -  |
**422** | Unprocessable Content |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_admin_api_keys**
> SuccessResponseApiKeyListResponseE7ebca9 get_api_v1_admin_api_keys()

List all API keys for the current tenant.

Query Parameters:     include_inactive: Include deactivated keys (default: false)     page: Page number (default: 1)     per_page: Items per page (default: 50, max: 200)

Returns:     200: {         "api_keys": [...],         "total": 10,         "page": 1,         "per_page": 50     }

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.models.success_response_api_key_list_response_e7ebca9 import SuccessResponseApiKeyListResponseE7ebca9
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.APIKeysApi(api_client)

    try:
        # List all API keys for the current tenant.
        api_response = api_instance.get_api_v1_admin_api_keys()
        print("The response of APIKeysApi->get_api_v1_admin_api_keys:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling APIKeysApi->get_api_v1_admin_api_keys: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**SuccessResponseApiKeyListResponseE7ebca9**](SuccessResponseApiKeyListResponseE7ebca9.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**422** | Unprocessable Content |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_admin_api_keysapi_key_id**
> SuccessResponseApiKeyResponseE7ebca9 get_api_v1_admin_api_keysapi_key_id(api_key_id)

Get details for a specific API key.

Args:     api_key_id: API Key UUID

Returns:     200: API key details (without the actual key)     404: API key not found

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.models.success_response_api_key_response_e7ebca9 import SuccessResponseApiKeyResponseE7ebca9
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.APIKeysApi(api_client)
    api_key_id = 'api_key_id_example' # str | 

    try:
        # Get details for a specific API key.
        api_response = api_instance.get_api_v1_admin_api_keysapi_key_id(api_key_id)
        print("The response of APIKeysApi->get_api_v1_admin_api_keysapi_key_id:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling APIKeysApi->get_api_v1_admin_api_keysapi_key_id: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **api_key_id** | **str**|  | 

### Return type

[**SuccessResponseApiKeyResponseE7ebca9**](SuccessResponseApiKeyResponseE7ebca9.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**404** | Not Found |  -  |
**422** | Unprocessable Content |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_api_v1_admin_api_keys**
> SuccessResponseApiKeyCreateResponseE7ebca9 post_api_v1_admin_api_keys()

Create a new API key for service account access.

Request Body:     {         "name": "CI/CD Pipeline",        // Required, unique per tenant         "description": "GitHub Actions", // Optional         "permissions": ["view_workflows", "run_workflows"],  // Optional, defaults to all         "expires_at": "2025-12-31T23:59:59Z",  // Optional ISO datetime         "ip_whitelist": ["192.168.1.0/24", "10.0.0.1"]  // Optional IP restrictions     }

Returns:     201: {         "api_key_id": "uuid",         "api_key": "hw_k1_...",  // ONLY shown once!         "key_prefix": "hw_k1_xxxxxx",         "name": "CI/CD Pipeline",         "permissions": [...],         "created_at": "..."     }

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.models.success_response_api_key_create_response_e7ebca9 import SuccessResponseApiKeyCreateResponseE7ebca9
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.APIKeysApi(api_client)

    try:
        # Create a new API key for service account access.
        api_response = api_instance.post_api_v1_admin_api_keys()
        print("The response of APIKeysApi->post_api_v1_admin_api_keys:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling APIKeysApi->post_api_v1_admin_api_keys: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**SuccessResponseApiKeyCreateResponseE7ebca9**](SuccessResponseApiKeyCreateResponseE7ebca9.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | Created |  -  |
**400** | Bad Request |  -  |
**409** | Conflict |  -  |
**422** | Unprocessable Content |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_api_v1_admin_api_keysapi_key_id_rotate**
> SuccessResponseApiKeyRotateResponseE7ebca9 post_api_v1_admin_api_keysapi_key_id_rotate(api_key_id)

Rotate an API key with optional grace period.

Creates a new API key and sets the old key to expire after the grace period. During the grace period, both keys are valid for zero-downtime rotation.

Args:     api_key_id: API Key UUID to rotate

Request Body (optional):     {         "grace_period_hours": 24  // Hours to keep old key valid (default: 24, max: 168)     }

Returns:     200: {         "new_api_key_id": "uuid",         "new_api_key": "hw_k1_...",   // Only shown once!         "new_key_prefix": "hw_k1_xxx",         "old_api_key_id": "uuid",         "old_key_expires_at": "...",  // When old key stops working         "grace_period_hours": 24     }

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.models.success_response_api_key_rotate_response_e7ebca9 import SuccessResponseApiKeyRotateResponseE7ebca9
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.APIKeysApi(api_client)
    api_key_id = 'api_key_id_example' # str | 

    try:
        # Rotate an API key with optional grace period.
        api_response = api_instance.post_api_v1_admin_api_keysapi_key_id_rotate(api_key_id)
        print("The response of APIKeysApi->post_api_v1_admin_api_keysapi_key_id_rotate:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling APIKeysApi->post_api_v1_admin_api_keysapi_key_id_rotate: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **api_key_id** | **str**|  | 

### Return type

[**SuccessResponseApiKeyRotateResponseE7ebca9**](SuccessResponseApiKeyRotateResponseE7ebca9.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**404** | Not Found |  -  |
**422** | Unprocessable Content |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

