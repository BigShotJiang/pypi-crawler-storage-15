# SuccessResponseRoleAssignResponseE7ebca9RoleAssignResponse

Response after role assignment.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email** | **str** | User email | 
**message** | **str** | Status message | 
**role** | **str** | Assigned role | 
**roles** | **List[str]** | All user roles | 

## Example

```python
from highway_sdk.models.success_response_role_assign_response_e7ebca9_role_assign_response import SuccessResponseRoleAssignResponseE7ebca9RoleAssignResponse

# TODO update the JSON string below
json = "{}"
# create an instance of SuccessResponseRoleAssignResponseE7ebca9RoleAssignResponse from a JSON string
success_response_role_assign_response_e7ebca9_role_assign_response_instance = SuccessResponseRoleAssignResponseE7ebca9RoleAssignResponse.from_json(json)
# print the JSON string representation of the object
print(SuccessResponseRoleAssignResponseE7ebca9RoleAssignResponse.to_json())

# convert the object into a dict
success_response_role_assign_response_e7ebca9_role_assign_response_dict = success_response_role_assign_response_e7ebca9_role_assign_response_instance.to_dict()
# create an instance of SuccessResponseRoleAssignResponseE7ebca9RoleAssignResponse from a dict
success_response_role_assign_response_e7ebca9_role_assign_response_from_dict = SuccessResponseRoleAssignResponseE7ebca9RoleAssignResponse.from_dict(success_response_role_assign_response_e7ebca9_role_assign_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


