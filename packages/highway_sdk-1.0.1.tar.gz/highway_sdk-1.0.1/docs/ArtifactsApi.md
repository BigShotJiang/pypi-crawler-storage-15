# highway_sdk.ArtifactsApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**delete_api_v1_artifactsartifact_id**](ArtifactsApi.md#delete_api_v1_artifactsartifact_id) | **DELETE** /api/v1/artifacts/{artifact_id} | Delete a Python module artifact by ID.
[**get_api_v1_artifacts**](ArtifactsApi.md#get_api_v1_artifacts) | **GET** /api/v1/artifacts | List all available artifacts.
[**get_api_v1_artifactsartifact_id**](ArtifactsApi.md#get_api_v1_artifactsartifact_id) | **GET** /api/v1/artifacts/{artifact_id} | Retrieve a Python module artifact by ID.
[**get_api_v1_artifactsartifact_id_exists**](ArtifactsApi.md#get_api_v1_artifactsartifact_id_exists) | **GET** /api/v1/artifacts/{artifact_id}/exists | Check if an artifact exists.
[**post_api_v1_artifacts**](ArtifactsApi.md#post_api_v1_artifacts) | **POST** /api/v1/artifacts | Upload a Python module artifact (zip file).


# **delete_api_v1_artifactsartifact_id**
> delete_api_v1_artifactsartifact_id(artifact_id)

Delete a Python module artifact by ID.

Args:     artifact_id: Artifact identifier (SHA-256 hash)

Returns:     JSON: {"message": "Artifact deleted successfully"}

Errors:     - 404: Artifact not found     - 500: Server error

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.ArtifactsApi(api_client)
    artifact_id = 'artifact_id_example' # str | 

    try:
        # Delete a Python module artifact by ID.
        api_instance.delete_api_v1_artifactsartifact_id(artifact_id)
    except Exception as e:
        print("Exception when calling ArtifactsApi->delete_api_v1_artifactsartifact_id: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **artifact_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_artifacts**
> get_api_v1_artifacts()

List all available artifacts.

Returns:     JSON: {"artifacts": ["artifact_id1", "artifact_id2", ...], "count": N}

Errors:     - 500: Server error

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.ArtifactsApi(api_client)

    try:
        # List all available artifacts.
        api_instance.get_api_v1_artifacts()
    except Exception as e:
        print("Exception when calling ArtifactsApi->get_api_v1_artifacts: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_artifactsartifact_id**
> get_api_v1_artifactsartifact_id(artifact_id)

Retrieve a Python module artifact by ID.

Args:     artifact_id: Artifact identifier (SHA-256 hash)

Returns:     Binary: Zip file bytes with Content-Type: application/zip

Errors:     - 404: Artifact not found     - 500: Server error

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.ArtifactsApi(api_client)
    artifact_id = 'artifact_id_example' # str | 

    try:
        # Retrieve a Python module artifact by ID.
        api_instance.get_api_v1_artifactsartifact_id(artifact_id)
    except Exception as e:
        print("Exception when calling ArtifactsApi->get_api_v1_artifactsartifact_id: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **artifact_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_artifactsartifact_id_exists**
> get_api_v1_artifactsartifact_id_exists(artifact_id)

Check if an artifact exists.

Args:     artifact_id: Artifact identifier (SHA-256 hash)

Returns:     JSON: {"exists": true/false, "artifact_id": "..."}

Errors:     - 500: Server error

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.ArtifactsApi(api_client)
    artifact_id = 'artifact_id_example' # str | 

    try:
        # Check if an artifact exists.
        api_instance.get_api_v1_artifactsartifact_id_exists(artifact_id)
    except Exception as e:
        print("Exception when calling ArtifactsApi->get_api_v1_artifactsartifact_id_exists: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **artifact_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_api_v1_artifacts**
> post_api_v1_artifacts()

Upload a Python module artifact (zip file).

Expected request:     - Content-Type: application/zip or multipart/form-data     - Body: Raw zip file bytes or form field 'artifact'

Returns:     JSON: {"artifact_id": "sha256hash", "size": bytes}

Errors:     - 400: Invalid request (not a zip, exceeds size limit, path traversal)     - 500: Server error

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.ArtifactsApi(api_client)

    try:
        # Upload a Python module artifact (zip file).
        api_instance.post_api_v1_artifacts()
    except Exception as e:
        print("Exception when calling ArtifactsApi->post_api_v1_artifacts: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

