# highway_sdk.SchemasApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**delete_api_v1_schemasworkflow_name_versionsversion**](SchemasApi.md#delete_api_v1_schemasworkflow_name_versionsversion) | **DELETE** /api/v1/schemas/{workflow_name}/versions/{version} | Deprecate a schema version.
[**get_api_v1_schemas**](SchemasApi.md#get_api_v1_schemas) | **GET** /api/v1/schemas | List all registered workflow schemas.
[**get_api_v1_schemas_stats**](SchemasApi.md#get_api_v1_schemas_stats) | **GET** /api/v1/schemas/stats | Get statistics about registered schemas.
[**get_api_v1_schemasworkflow_name**](SchemasApi.md#get_api_v1_schemasworkflow_name) | **GET** /api/v1/schemas/{workflow_name} | Get a workflow schema (latest or specific version).
[**post_api_v1_schemasworkflow_name_validate**](SchemasApi.md#post_api_v1_schemasworkflow_name_validate) | **POST** /api/v1/schemas/{workflow_name}/validate | Validate input data against a workflow schema.


# **delete_api_v1_schemasworkflow_name_versionsversion**
> delete_api_v1_schemasworkflow_name_versionsversion(workflow_name, version)

Deprecate a schema version.

This marks the version as deprecated but doesn't delete it (backward compatibility).

Returns:     200: Version deprecated     404: Version not found

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.SchemasApi(api_client)
    workflow_name = 'workflow_name_example' # str | 
    version = 'version_example' # str | 

    try:
        # Deprecate a schema version.
        api_instance.delete_api_v1_schemasworkflow_name_versionsversion(workflow_name, version)
    except Exception as e:
        print("Exception when calling SchemasApi->delete_api_v1_schemasworkflow_name_versionsversion: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_name** | **str**|  | 
 **version** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_schemas**
> get_api_v1_schemas()

List all registered workflow schemas.

Query Parameters:     workflow_name (str, optional): Filter by workflow name

Returns:     200: List of schemas or schema versions

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.SchemasApi(api_client)

    try:
        # List all registered workflow schemas.
        api_instance.get_api_v1_schemas()
    except Exception as e:
        print("Exception when calling SchemasApi->get_api_v1_schemas: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_schemas_stats**
> get_api_v1_schemas_stats()

Get statistics about registered schemas.

Returns:     200: Schema statistics

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.SchemasApi(api_client)

    try:
        # Get statistics about registered schemas.
        api_instance.get_api_v1_schemas_stats()
    except Exception as e:
        print("Exception when calling SchemasApi->get_api_v1_schemas_stats: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_schemasworkflow_name**
> get_api_v1_schemasworkflow_name(workflow_name)

Get a workflow schema (latest or specific version).

Query Parameters:     version (str, optional): Schema version (default: latest)

Returns:     200: Schema details     404: Schema not found

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.SchemasApi(api_client)
    workflow_name = 'workflow_name_example' # str | 

    try:
        # Get a workflow schema (latest or specific version).
        api_instance.get_api_v1_schemasworkflow_name(workflow_name)
    except Exception as e:
        print("Exception when calling SchemasApi->get_api_v1_schemasworkflow_name: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_name** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_api_v1_schemasworkflow_name_validate**
> post_api_v1_schemasworkflow_name_validate(workflow_name)

Validate input data against a workflow schema.

Request Body:     input_data (dict): Input data to validate     version (str, optional): Schema version (default: latest)

Returns:     200: Validation result (valid: true/false, errors: [...])     400: Invalid request

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.SchemasApi(api_client)
    workflow_name = 'workflow_name_example' # str | 

    try:
        # Validate input data against a workflow schema.
        api_instance.post_api_v1_schemasworkflow_name_validate(workflow_name)
    except Exception as e:
        print("Exception when calling SchemasApi->post_api_v1_schemasworkflow_name_validate: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_name** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

