# SuccessResponseTokenCreateResponseE7ebca9TokenCreateResponse

Response after creating a token (includes secret).

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**expires_at** | **datetime** | Expiration time | 
**message** | **str** | Warning message | [optional] [default to 'Store this token securely. It will not be shown again.']
**name** | **str** | Token name | 
**token** | **str** | Token secret (shown only once) | 
**token_id** | **str** | Token ID (UUID) | 

## Example

```python
from highway_sdk.models.success_response_token_create_response_e7ebca9_token_create_response import SuccessResponseTokenCreateResponseE7ebca9TokenCreateResponse

# TODO update the JSON string below
json = "{}"
# create an instance of SuccessResponseTokenCreateResponseE7ebca9TokenCreateResponse from a JSON string
success_response_token_create_response_e7ebca9_token_create_response_instance = SuccessResponseTokenCreateResponseE7ebca9TokenCreateResponse.from_json(json)
# print the JSON string representation of the object
print(SuccessResponseTokenCreateResponseE7ebca9TokenCreateResponse.to_json())

# convert the object into a dict
success_response_token_create_response_e7ebca9_token_create_response_dict = success_response_token_create_response_e7ebca9_token_create_response_instance.to_dict()
# create an instance of SuccessResponseTokenCreateResponseE7ebca9TokenCreateResponse from a dict
success_response_token_create_response_e7ebca9_token_create_response_from_dict = SuccessResponseTokenCreateResponseE7ebca9TokenCreateResponse.from_dict(success_response_token_create_response_e7ebca9_token_create_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


