# SuccessResponseHealthCheckResponseE7ebca9HealthCheckResponse

Health check response.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**checks** | **Dict[str, object]** | Individual component checks | 
**status** | **str** | Overall health status: healthy, degraded, unhealthy | 

## Example

```python
from highway_sdk.models.success_response_health_check_response_e7ebca9_health_check_response import SuccessResponseHealthCheckResponseE7ebca9HealthCheckResponse

# TODO update the JSON string below
json = "{}"
# create an instance of SuccessResponseHealthCheckResponseE7ebca9HealthCheckResponse from a JSON string
success_response_health_check_response_e7ebca9_health_check_response_instance = SuccessResponseHealthCheckResponseE7ebca9HealthCheckResponse.from_json(json)
# print the JSON string representation of the object
print(SuccessResponseHealthCheckResponseE7ebca9HealthCheckResponse.to_json())

# convert the object into a dict
success_response_health_check_response_e7ebca9_health_check_response_dict = success_response_health_check_response_e7ebca9_health_check_response_instance.to_dict()
# create an instance of SuccessResponseHealthCheckResponseE7ebca9HealthCheckResponse from a dict
success_response_health_check_response_e7ebca9_health_check_response_from_dict = SuccessResponseHealthCheckResponseE7ebca9HealthCheckResponse.from_dict(success_response_health_check_response_e7ebca9_health_check_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


