# highway_sdk.LogsApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_api_v1_logs_activities**](LogsApi.md#get_api_v1_logs_activities) | **GET** /api/v1/logs/activities | List recent activity logs across all workflows for the tenant.
[**get_api_v1_logs_stats**](LogsApi.md#get_api_v1_logs_stats) | **GET** /api/v1/logs/stats | Get aggregated workflow statistics.
[**get_api_v1_logs_workflows**](LogsApi.md#get_api_v1_logs_workflows) | **GET** /api/v1/logs/workflows | List workflow logs with filtering and pagination.
[**get_api_v1_logs_workflowsworkflow_run_id**](LogsApi.md#get_api_v1_logs_workflowsworkflow_run_id) | **GET** /api/v1/logs/workflows/{workflow_run_id} | Get workflow log by workflow_run_id.
[**get_api_v1_logs_workflowsworkflow_run_id_activities**](LogsApi.md#get_api_v1_logs_workflowsworkflow_run_id_activities) | **GET** /api/v1/logs/workflows/{workflow_run_id}/activities | List activity logs for a workflow.
[**get_api_v1_logs_workflowsworkflow_run_id_activitiesactivity_id**](LogsApi.md#get_api_v1_logs_workflowsworkflow_run_id_activitiesactivity_id) | **GET** /api/v1/logs/workflows/{workflow_run_id}/activities/{activity_id} | Get activity log with captured Python logging output.
[**get_api_v1_logs_workflowsworkflow_run_id_taskstask_id**](LogsApi.md#get_api_v1_logs_workflowsworkflow_run_id_taskstask_id) | **GET** /api/v1/logs/workflows/{workflow_run_id}/tasks/{task_id} | Get task log with stdout/stderr.


# **get_api_v1_logs_activities**
> get_api_v1_logs_activities()

List recent activity logs across all workflows for the tenant.

Query Parameters:     limit (int, optional): Max results (default: 100, max: 500)

Returns:     200: List of recent activity logs     500: Failed to query logs

Response:     {         "success": true,         "data": {             "activities": [...],             "total": 100,             "limit": 100         }     }

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.LogsApi(api_client)

    try:
        # List recent activity logs across all workflows for the tenant.
        api_instance.get_api_v1_logs_activities()
    except Exception as e:
        print("Exception when calling LogsApi->get_api_v1_logs_activities: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_logs_stats**
> get_api_v1_logs_stats()

Get aggregated workflow statistics.

Query Parameters:     workflow_name (optional): Get stats for specific workflow     since (optional): ISO datetime - stats for logs after this time     until (optional): ISO datetime - stats for logs before this time

Returns:     200: Statistics     404: No logs found     500: Failed to compute stats

Response:     {         "success": true,         "data": {             "total_workflows": 1543,             "status_breakdown": {                 "success": 1501,                 "failure": 42             },             "success_rate": 0.973,             "avg_duration_ms": 45230,             "p50_duration_ms": 30100,             "p95_duration_ms": 120500,             "p99_duration_ms": 180000,             "total_duration_ms": 69779890,             "avg_event_count": 23.5         }     }

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.LogsApi(api_client)

    try:
        # Get aggregated workflow statistics.
        api_instance.get_api_v1_logs_stats()
    except Exception as e:
        print("Exception when calling LogsApi->get_api_v1_logs_stats: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_logs_workflows**
> get_api_v1_logs_workflows()

List workflow logs with filtering and pagination.

Query Parameters:     workflow_name (optional): Filter by workflow name     status (optional): Filter by status (success, failure)     since (optional): ISO datetime - filter logs after this time     until (optional): ISO datetime - filter logs before this time     limit (int, optional): Max results (default: 100, max: 1000)     offset (int, optional): Pagination offset (default: 0)

Returns:     200: List of workflow logs     400: Invalid parameters     404: No logs found     500: Failed to query logs

Response:     {         "success": true,         "data": {             "workflows": [{                 "workflow_run_id": "abc123",                 "absurd_run_id": "def456",                 "workflow_name": "video_processing",                 "status": "success",                 "started_at": "2025-11-17T10:00:00Z",                 "completed_at": "2025-11-17T10:05:00Z",                 "duration_ms": 300000,                 "worker_id": "worker-1-1234",                 "error_message": null,                 "event_count": 45,                 "logged_at": "2025-11-17T10:05:01Z"             }],             "total": 1,             "limit": 100,             "offset": 0         }     }

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.LogsApi(api_client)

    try:
        # List workflow logs with filtering and pagination.
        api_instance.get_api_v1_logs_workflows()
    except Exception as e:
        print("Exception when calling LogsApi->get_api_v1_logs_workflows: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_logs_workflowsworkflow_run_id**
> get_api_v1_logs_workflowsworkflow_run_id(workflow_run_id)

Get workflow log by workflow_run_id.

Path Parameters:     workflow_run_id: Workflow run ID

Returns:     200: Workflow log     404: Workflow log not found     500: Failed to query log

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.LogsApi(api_client)
    workflow_run_id = 'workflow_run_id_example' # str | 

    try:
        # Get workflow log by workflow_run_id.
        api_instance.get_api_v1_logs_workflowsworkflow_run_id(workflow_run_id)
    except Exception as e:
        print("Exception when calling LogsApi->get_api_v1_logs_workflowsworkflow_run_id: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_run_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_logs_workflowsworkflow_run_id_activities**
> get_api_v1_logs_workflowsworkflow_run_id_activities(workflow_run_id)

List activity logs for a workflow.

Path Parameters:     workflow_run_id: Workflow run ID

Query Parameters:     include_logs (bool, optional): Include captured Python logs in response (default: false)

Returns:     200: List of activity logs for the workflow     404: No activity logs found     500: Failed to query logs

Response:     {         "success": true,         "data": {             "workflow_run_id": "abc123",             "activities": [{                 "activity_id": "def456",                 "activity_name": "kafka_consumer",                 "function_name": "examples.etl.kafka_pipeline.consumer.run_consumer",                 "status": "completed",                 "started_at": "2025-11-29T10:00:00Z",                 "completed_at": "2025-11-29T10:05:00Z",                 "duration_ms": 300000,                 "worker_id": "activity-worker-1234",                 "attempt": 1,                 "max_attempts": 3,                 "captured_logs_count": 150,                 "log_level_counts": {"INFO": 120, "DEBUG": 25, "ERROR": 5}             }],             "summary": {                 "total_activities": 2,                 "completed": 1,                 "failed": 1             }         }     }

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.LogsApi(api_client)
    workflow_run_id = 'workflow_run_id_example' # str | 

    try:
        # List activity logs for a workflow.
        api_instance.get_api_v1_logs_workflowsworkflow_run_id_activities(workflow_run_id)
    except Exception as e:
        print("Exception when calling LogsApi->get_api_v1_logs_workflowsworkflow_run_id_activities: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_run_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_logs_workflowsworkflow_run_id_activitiesactivity_id**
> get_api_v1_logs_workflowsworkflow_run_id_activitiesactivity_id(workflow_run_id, activity_id)

Get activity log with captured Python logging output.

This endpoint returns the full audit trail for an activity, including: - All captured Python logging output (INFO, DEBUG, WARNING, ERROR) - Execution timing and result - Error details if failed

Path Parameters:     workflow_run_id: Workflow run ID     activity_id: Activity ID

Returns:     200: Activity log with captured logs     404: Activity log not found     500: Failed to query log

Response:     {         "success": true,         "data": {             "activity_id": "def456",             "workflow_run_id": "abc123",             "activity_name": "kafka_consumer",             "function_name": "examples.etl.kafka_pipeline.consumer.run_consumer",             "status": "completed",             "started_at": "2025-11-29T10:00:00Z",             "completed_at": "2025-11-29T10:05:00Z",             "duration_ms": 300000,             "worker_id": "activity-worker-1234",             "attempt": 1,             "max_attempts": 3,             "result_summary": {"messages_consumed": 50},             "captured_logs": [                 {"ts": 1732878000.123, "level": "INFO", "logger": "consumer", "msg": "Connected to Kafka"},                 {"ts": 1732878001.456, "level": "INFO", "logger": "consumer", "msg": "Consuming from topic"}             ],             "log_level_counts": {"INFO": 120, "DEBUG": 25, "ERROR": 0}         }     }

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.LogsApi(api_client)
    workflow_run_id = 'workflow_run_id_example' # str | 
    activity_id = 'activity_id_example' # str | 

    try:
        # Get activity log with captured Python logging output.
        api_instance.get_api_v1_logs_workflowsworkflow_run_id_activitiesactivity_id(workflow_run_id, activity_id)
    except Exception as e:
        print("Exception when calling LogsApi->get_api_v1_logs_workflowsworkflow_run_id_activitiesactivity_id: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_run_id** | **str**|  | 
 **activity_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_logs_workflowsworkflow_run_id_taskstask_id**
> get_api_v1_logs_workflowsworkflow_run_id_taskstask_id(workflow_run_id, task_id)

Get task log with stdout/stderr.

    Path Parameters:         workflow_run_id: Workflow run ID         task_id: Task ID

    Returns:         200: Task log with stdout/stderr         404: Task log not found         500: Failed to query log

    Response:         {             "success": true,             "data": {                 "workflow_run_id": "abc123",                 "task_id": "task_1",                 "task_name": "run_script",                 "task_function": "tools.shell.run",                 "status": "success",                 "started_at": "2025-11-17T10:00:00Z",                 "completed_at": "2025-11-17T10:00:05Z",                 "duration_ms": 5000,                 "worker_id": "worker-1-1234",                 "retry_count": 0,                 "error_message": null,                 "output_stdout": "Hello World ",                 "output_stderr": "",                 "output_return_code": 0,                 "logged_at": "2025-11-17T10:00:05Z"             }         }

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.LogsApi(api_client)
    workflow_run_id = 'workflow_run_id_example' # str | 
    task_id = 'task_id_example' # str | 

    try:
        # Get task log with stdout/stderr.
        api_instance.get_api_v1_logs_workflowsworkflow_run_id_taskstask_id(workflow_run_id, task_id)
    except Exception as e:
        print("Exception when calling LogsApi->get_api_v1_logs_workflowsworkflow_run_id_taskstask_id: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_run_id** | **str**|  | 
 **task_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

