# SuccessResponseApiKeyListResponseE7ebca9TokenStatus

Token status.

## Enum

* `ACTIVE` (value: `'active'`)

* `REVOKED` (value: `'revoked'`)

* `EXPIRED` (value: `'expired'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


