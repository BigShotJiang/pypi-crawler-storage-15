# highway_sdk.AppsApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**delete_api_v1_appsapp_id**](AppsApi.md#delete_api_v1_appsapp_id) | **DELETE** /api/v1/apps/{app_id} | Soft delete an app.
[**get_api_v1_apps**](AppsApi.md#get_api_v1_apps) | **GET** /api/v1/apps | List apps with pagination and filters.
[**get_api_v1_apps_categories**](AppsApi.md#get_api_v1_apps_categories) | **GET** /api/v1/apps/categories | List app categories with counts.
[**get_api_v1_apps_marketplace**](AppsApi.md#get_api_v1_apps_marketplace) | **GET** /api/v1/apps/marketplace | Browse public apps marketplace.
[**get_api_v1_appsapp_id**](AppsApi.md#get_api_v1_appsapp_id) | **GET** /api/v1/apps/{app_id} | Get app details.
[**get_api_v1_appsapp_id_versions**](AppsApi.md#get_api_v1_appsapp_id_versions) | **GET** /api/v1/apps/{app_id}/versions | List all versions for an app.
[**get_api_v1_appsapp_id_versionsversion_id**](AppsApi.md#get_api_v1_appsapp_id_versionsversion_id) | **GET** /api/v1/apps/{app_id}/versions/{version_id} | Get version details.
[**patch_api_v1_appsapp_id**](AppsApi.md#patch_api_v1_appsapp_id) | **PATCH** /api/v1/apps/{app_id} | Update app metadata.
[**post_api_v1_apps**](AppsApi.md#post_api_v1_apps) | **POST** /api/v1/apps | Register a new app.
[**post_api_v1_appsapp_id_versions**](AppsApi.md#post_api_v1_appsapp_id_versions) | **POST** /api/v1/apps/{app_id}/versions | Create a new app version (draft).
[**post_api_v1_appsapp_id_versionsversion_id_deprecate**](AppsApi.md#post_api_v1_appsapp_id_versionsversion_id_deprecate) | **POST** /api/v1/apps/{app_id}/versions/{version_id}/deprecate | Deprecate a published version.
[**post_api_v1_appsapp_id_versionsversion_id_publish**](AppsApi.md#post_api_v1_appsapp_id_versionsversion_id_publish) | **POST** /api/v1/apps/{app_id}/versions/{version_id}/publish | Publish a draft version.


# **delete_api_v1_appsapp_id**
> delete_api_v1_appsapp_id(app_id)

Soft delete an app.

Returns:     200: App deleted     404: App not found     403: Not owner

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.AppsApi(api_client)
    app_id = 'app_id_example' # str | 

    try:
        # Soft delete an app.
        api_instance.delete_api_v1_appsapp_id(app_id)
    except Exception as e:
        print("Exception when calling AppsApi->delete_api_v1_appsapp_id: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **app_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_apps**
> get_api_v1_apps()

List apps with pagination and filters.

Query Parameters:     page: Page number (default: 1)     page_size: Items per page (default: 20, max: 100)     category: Filter by category     status: Filter by status     visibility: Filter by visibility     search: Search in name/description

Returns:     200: Paginated list of apps

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.AppsApi(api_client)

    try:
        # List apps with pagination and filters.
        api_instance.get_api_v1_apps()
    except Exception as e:
        print("Exception when calling AppsApi->get_api_v1_apps: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_apps_categories**
> get_api_v1_apps_categories()

List app categories with counts.

Returns:     200: List of categories

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.AppsApi(api_client)

    try:
        # List app categories with counts.
        api_instance.get_api_v1_apps_categories()
    except Exception as e:
        print("Exception when calling AppsApi->get_api_v1_apps_categories: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_apps_marketplace**
> get_api_v1_apps_marketplace()

Browse public apps marketplace.

Query Parameters:     page: Page number     page_size: Items per page     category: Filter by category

Returns:     200: Paginated list of public apps with stats

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.AppsApi(api_client)

    try:
        # Browse public apps marketplace.
        api_instance.get_api_v1_apps_marketplace()
    except Exception as e:
        print("Exception when calling AppsApi->get_api_v1_apps_marketplace: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_appsapp_id**
> get_api_v1_appsapp_id(app_id)

Get app details.

Returns:     200: App details with versions     404: App not found

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.AppsApi(api_client)
    app_id = 'app_id_example' # str | 

    try:
        # Get app details.
        api_instance.get_api_v1_appsapp_id(app_id)
    except Exception as e:
        print("Exception when calling AppsApi->get_api_v1_appsapp_id: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **app_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_appsapp_id_versions**
> get_api_v1_appsapp_id_versions(app_id)

List all versions for an app.

Returns:     200: List of versions     404: App not found

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.AppsApi(api_client)
    app_id = 'app_id_example' # str | 

    try:
        # List all versions for an app.
        api_instance.get_api_v1_appsapp_id_versions(app_id)
    except Exception as e:
        print("Exception when calling AppsApi->get_api_v1_appsapp_id_versions: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **app_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_appsapp_id_versionsversion_id**
> get_api_v1_appsapp_id_versionsversion_id(app_id, version_id)

Get version details.

Returns:     200: Version details     404: Version not found

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.AppsApi(api_client)
    app_id = 'app_id_example' # str | 
    version_id = 'version_id_example' # str | 

    try:
        # Get version details.
        api_instance.get_api_v1_appsapp_id_versionsversion_id(app_id, version_id)
    except Exception as e:
        print("Exception when calling AppsApi->get_api_v1_appsapp_id_versionsversion_id: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **app_id** | **str**|  | 
 **version_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **patch_api_v1_appsapp_id**
> patch_api_v1_appsapp_id(app_id)

Update app metadata.

Request Body:     {         "display_name": "...",         "description": "...",         "category": "...",         "tags": [...],         "visibility": "...",         "icon_url": "...",         "documentation_url": "...",         "homepage_url": "..."     }

Returns:     200: App updated     404: App not found     403: Not owner

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.AppsApi(api_client)
    app_id = 'app_id_example' # str | 

    try:
        # Update app metadata.
        api_instance.patch_api_v1_appsapp_id(app_id)
    except Exception as e:
        print("Exception when calling AppsApi->patch_api_v1_appsapp_id: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **app_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_api_v1_apps**
> post_api_v1_apps()

Register a new app.

Request Body:     {         "app_name": "slack",         "display_name": "Slack Integration",         "description": "Send messages to Slack channels",         "category": "communication",         "tags": ["messaging", "notification"],         "visibility": "private",         "icon_url": "https://...",         "documentation_url": "https://...",         "homepage_url": "https://..."     }

Returns:     201: App created successfully     400: Invalid input     409: App name already exists

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.AppsApi(api_client)

    try:
        # Register a new app.
        api_instance.post_api_v1_apps()
    except Exception as e:
        print("Exception when calling AppsApi->post_api_v1_apps: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_api_v1_appsapp_id_versions**
> post_api_v1_appsapp_id_versions(app_id)

Create a new app version (draft).

Request Body:     {         "version": "1.0.0",         "entrypoint_type": "python_module",         "entrypoint_config": {"module": "...", "class": "..."},         "actions": {"action_name": {"description": "...", ...}},         "required_secrets": ["api_key"],         "configuration_schema": {...},         "changelog": "Initial release"     }

Returns:     201: Version created     400: Invalid input     404: App not found     409: Version already exists

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.AppsApi(api_client)
    app_id = 'app_id_example' # str | 

    try:
        # Create a new app version (draft).
        api_instance.post_api_v1_appsapp_id_versions(app_id)
    except Exception as e:
        print("Exception when calling AppsApi->post_api_v1_appsapp_id_versions: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **app_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_api_v1_appsapp_id_versionsversion_id_deprecate**
> post_api_v1_appsapp_id_versionsversion_id_deprecate(app_id, version_id)

Deprecate a published version.

Returns:     200: Version deprecated     400: Version not published     404: Version not found

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.AppsApi(api_client)
    app_id = 'app_id_example' # str | 
    version_id = 'version_id_example' # str | 

    try:
        # Deprecate a published version.
        api_instance.post_api_v1_appsapp_id_versionsversion_id_deprecate(app_id, version_id)
    except Exception as e:
        print("Exception when calling AppsApi->post_api_v1_appsapp_id_versionsversion_id_deprecate: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **app_id** | **str**|  | 
 **version_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_api_v1_appsapp_id_versionsversion_id_publish**
> post_api_v1_appsapp_id_versionsversion_id_publish(app_id, version_id)

Publish a draft version.

Returns:     200: Version published     400: Version not in draft status     404: Version not found

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.AppsApi(api_client)
    app_id = 'app_id_example' # str | 
    version_id = 'version_id_example' # str | 

    try:
        # Publish a draft version.
        api_instance.post_api_v1_appsapp_id_versionsversion_id_publish(app_id, version_id)
    except Exception as e:
        print("Exception when calling AppsApi->post_api_v1_appsapp_id_versionsversion_id_publish: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **app_id** | **str**|  | 
 **version_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

