# highway_sdk.TasksApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_api_v1_tasks**](TasksApi.md#get_api_v1_tasks) | **GET** /api/v1/tasks | List Absurd tasks with filtering and pagination.
[**get_api_v1_tasks_summary**](TasksApi.md#get_api_v1_tasks_summary) | **GET** /api/v1/tasks/summary | Get task count summary by state and queue.
[**get_api_v1_taskstask_id**](TasksApi.md#get_api_v1_taskstask_id) | **GET** /api/v1/tasks/{task_id} | Get detailed information about a specific Absurd task.


# **get_api_v1_tasks**
> get_api_v1_tasks()

List Absurd tasks with filtering and pagination.

**RBAC Permission:** `view_workflows`

Query parameters:     state: Filter by state (pending, running, sleeping, completed, failed, cancelled)     queue: Filter by queue name (highway_default, highway_internal, highway_activity)     page: Page number (default: 1)     page_size: Results per page (default: 50, max: 200)

Returns:     200: List of tasks with pagination info     400: Invalid parameters     500: Database error

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.TasksApi(api_client)

    try:
        # List Absurd tasks with filtering and pagination.
        api_instance.get_api_v1_tasks()
    except Exception as e:
        print("Exception when calling TasksApi->get_api_v1_tasks: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_tasks_summary**
> get_api_v1_tasks_summary()

Get task count summary by state and queue.

**RBAC Permission:** `view_workflows`

Returns:     200: Summary of task counts by state and queue     500: Database error

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.TasksApi(api_client)

    try:
        # Get task count summary by state and queue.
        api_instance.get_api_v1_tasks_summary()
    except Exception as e:
        print("Exception when calling TasksApi->get_api_v1_tasks_summary: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_taskstask_id**
> get_api_v1_taskstask_id(task_id)

Get detailed information about a specific Absurd task.

**RBAC Permission:** `view_workflows`

Returns task definition, current run state, all run attempts, and checkpoints.

Args:     task_id: Task ID (UUID)

Returns:     200: Task details with runs and checkpoints     400: Invalid UUID     404: Task not found     500: Database error

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.TasksApi(api_client)
    task_id = 'task_id_example' # str | 

    try:
        # Get detailed information about a specific Absurd task.
        api_instance.get_api_v1_taskstask_id(task_id)
    except Exception as e:
        print("Exception when calling TasksApi->get_api_v1_taskstask_id: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **task_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

