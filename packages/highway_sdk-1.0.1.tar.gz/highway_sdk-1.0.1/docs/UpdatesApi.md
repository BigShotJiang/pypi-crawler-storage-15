# highway_sdk.UpdatesApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_api_v1_workflowsworkflow_run_id_updates**](UpdatesApi.md#get_api_v1_workflowsworkflow_run_id_updates) | **GET** /api/v1/workflows/{workflow_run_id}/updates | Get pending updates for a workflow.
[**get_api_v1_workflowsworkflow_run_id_updates_history**](UpdatesApi.md#get_api_v1_workflowsworkflow_run_id_updates_history) | **GET** /api/v1/workflows/{workflow_run_id}/updates/history | Get update history for a workflow (all statuses).
[**post_api_v1_workflowsworkflow_run_id_updates**](UpdatesApi.md#post_api_v1_workflowsworkflow_run_id_updates) | **POST** /api/v1/workflows/{workflow_run_id}/updates | Send a blocking update to a workflow.


# **get_api_v1_workflowsworkflow_run_id_updates**
> get_api_v1_workflowsworkflow_run_id_updates(workflow_run_id)

Get pending updates for a workflow.

Query Parameters:     update_name (str, optional): Filter by update name

Returns:     200: List of pending updates

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.UpdatesApi(api_client)
    workflow_run_id = 'workflow_run_id_example' # str | 

    try:
        # Get pending updates for a workflow.
        api_instance.get_api_v1_workflowsworkflow_run_id_updates(workflow_run_id)
    except Exception as e:
        print("Exception when calling UpdatesApi->get_api_v1_workflowsworkflow_run_id_updates: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_run_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_workflowsworkflow_run_id_updates_history**
> get_api_v1_workflowsworkflow_run_id_updates_history(workflow_run_id)

Get update history for a workflow (all statuses).

Query Parameters:     limit (int, optional): Max number of records to return (default: 50)     status (str, optional): Filter by status (PENDING, PROCESSING, COMPLETED, FAILED, TIMEOUT)

Returns:     200: List of updates with their history

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.UpdatesApi(api_client)
    workflow_run_id = 'workflow_run_id_example' # str | 

    try:
        # Get update history for a workflow (all statuses).
        api_instance.get_api_v1_workflowsworkflow_run_id_updates_history(workflow_run_id)
    except Exception as e:
        print("Exception when calling UpdatesApi->get_api_v1_workflowsworkflow_run_id_updates_history: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_run_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_api_v1_workflowsworkflow_run_id_updates**
> post_api_v1_workflowsworkflow_run_id_updates(workflow_run_id)

Send a blocking update to a workflow.

This endpoint blocks until the workflow processes the update and returns the result, or until timeout expires.

Request Body:     update_name (str): Name of the update handler     update_payload (dict, optional): Data to pass to update handler     timeout_seconds (int, optional): Max wait time (default: 30s)

Returns:     200: Update completed successfully     408: Update timed out     500: Update failed or error occurred

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.UpdatesApi(api_client)
    workflow_run_id = 'workflow_run_id_example' # str | 

    try:
        # Send a blocking update to a workflow.
        api_instance.post_api_v1_workflowsworkflow_run_id_updates(workflow_run_id)
    except Exception as e:
        print("Exception when calling UpdatesApi->post_api_v1_workflowsworkflow_run_id_updates: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_run_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

