# SuccessResponseUserListResponseE7ebca9UserResponse

User details response.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**created_at** | **datetime** |  | [optional] 
**display_name** | **str** |  | [optional] 
**email** | **str** | User email | 
**is_active** | **bool** | Whether user is active | [optional] [default to True]
**last_login** | **datetime** |  | [optional] 
**role** | **str** | User role | 
**roles** | **List[str]** | All user roles | [optional] 
**tenant_id** | **str** | Tenant ID | 

## Example

```python
from highway_sdk.models.success_response_user_list_response_e7ebca9_user_response import SuccessResponseUserListResponseE7ebca9UserResponse

# TODO update the JSON string below
json = "{}"
# create an instance of SuccessResponseUserListResponseE7ebca9UserResponse from a JSON string
success_response_user_list_response_e7ebca9_user_response_instance = SuccessResponseUserListResponseE7ebca9UserResponse.from_json(json)
# print the JSON string representation of the object
print(SuccessResponseUserListResponseE7ebca9UserResponse.to_json())

# convert the object into a dict
success_response_user_list_response_e7ebca9_user_response_dict = success_response_user_list_response_e7ebca9_user_response_instance.to_dict()
# create an instance of SuccessResponseUserListResponseE7ebca9UserResponse from a dict
success_response_user_list_response_e7ebca9_user_response_from_dict = SuccessResponseUserListResponseE7ebca9UserResponse.from_dict(success_response_user_list_response_e7ebca9_user_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


