# highway_sdk.DefaultApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get**](DefaultApi.md#get) | **GET** / | Render homepage using Mako template with component includes.
[**get_api_v1_auth_login**](DefaultApi.md#get_api_v1_auth_login) | **GET** /api/v1/auth/login | Initiate Google OAuth2 login flow.
[**get_api_v1_auth_logout**](DefaultApi.md#get_api_v1_auth_logout) | **GET** /api/v1/auth/logout | Logout user (client-side token deletion).
[**get_api_v1_auth_oauth**](DefaultApi.md#get_api_v1_auth_oauth) | **GET** /api/v1/auth/oauth | Handle Google OAuth2 callback.
[**get_api_v1_workflows_by_hashdefinition_hash**](DefaultApi.md#get_api_v1_workflows_by_hashdefinition_hash) | **GET** /api/v1/workflows/by-hash/{definition_hash} | Get workflow definition by hash (PRIMARY identifier).
[**get_api_v1_workflows_definitions_dsl_pythondefinition_id**](DefaultApi.md#get_api_v1_workflows_definitions_dsl_pythondefinition_id) | **GET** /api/v1/workflows/definitions/dsl/python/{definition_id} | Get workflow Python DSL source only.
[**get_api_v1_workflows_definitions_jsondefinition_id**](DefaultApi.md#get_api_v1_workflows_definitions_jsondefinition_id) | **GET** /api/v1/workflows/definitions/json/{definition_id} | Get workflow JSON definition only.
[**get_api_v1_workflows_definitionsdefinition_id**](DefaultApi.md#get_api_v1_workflows_definitionsdefinition_id) | **GET** /api/v1/workflows/definitions/{definition_id} | Get workflow definition by definition_id (UUID).
[**get_api_v1_workflows_definitionsdefinition_id_executions_grid**](DefaultApi.md#get_api_v1_workflows_definitionsdefinition_id_executions_grid) | **GET** /api/v1/workflows/definitions/{definition_id}/executions/grid | Get workflow execution data in Airflow-style grid format by definition ID.
[**get_api_v1_workflowsworkflow_name_versionsversion**](DefaultApi.md#get_api_v1_workflowsworkflow_name_versionsversion) | **GET** /api/v1/workflows/{workflow_name}/versions/{version} | Get workflow definition by name and version (convenience method).
[**get_api_v1_workflowsworkflow_run_id_stepsstep_name_checkpoints**](DefaultApi.md#get_api_v1_workflowsworkflow_run_id_stepsstep_name_checkpoints) | **GET** /api/v1/workflows/{workflow_run_id}/steps/{step_name}/checkpoints | **RBAC Permission:** &#x60;view_workflows&#x60;
[**get_favicon_ico**](DefaultApi.md#get_favicon_ico) | **GET** /favicon.ico | Serve favicon.
[**get_login**](DefaultApi.md#get_login) | **GET** /login | Render the standalone login page.
[**get_ping**](DefaultApi.md#get_ping) | **GET** /ping | Basic ping endpoint.
[**post_api_v1_auth_logout**](DefaultApi.md#post_api_v1_auth_logout) | **POST** /api/v1/auth/logout | Logout user (client-side token deletion).
[**post_api_v1_auth_verify**](DefaultApi.md#post_api_v1_auth_verify) | **POST** /api/v1/auth/verify | Verify JWT token.


# **get**
> get()

Render homepage using Mako template with component includes.

Returns:     Rendered HTML homepage

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.DefaultApi(api_client)

    try:
        # Render homepage using Mako template with component includes.
        api_instance.get()
    except Exception as e:
        print("Exception when calling DefaultApi->get: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_auth_login**
> get_api_v1_auth_login()

Initiate Google OAuth2 login flow.

Redirects user to Google login page.

Query Parameters:     tenant_id: Tenant ID (optional, default: "default")     on_success_redirect: URL to redirect after successful login (optional, default: "/")     on_failure_redirect: URL to redirect on authentication failure (optional, default: "/")

Returns:     Redirect to Google OAuth2 authorization URL

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.DefaultApi(api_client)

    try:
        # Initiate Google OAuth2 login flow.
        api_instance.get_api_v1_auth_login()
    except Exception as e:
        print("Exception when calling DefaultApi->get_api_v1_auth_login: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_auth_logout**
> get_api_v1_auth_logout()

Logout user (client-side token deletion).

This endpoint doesn't invalidate the token (stateless JWT), but provides a standard logout endpoint for the frontend.

Query Parameters (GET only):     on_success_redirect: URL to redirect after logout (optional, default: "/")     on_failure_redirect: URL to redirect on error (optional, default: "/")

Returns (POST):     {         "status": "success",         "message": "Logged out successfully"     }

Returns (GET):     Redirect to on_success_redirect

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.DefaultApi(api_client)

    try:
        # Logout user (client-side token deletion).
        api_instance.get_api_v1_auth_logout()
    except Exception as e:
        print("Exception when calling DefaultApi->get_api_v1_auth_logout: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_auth_oauth**
> get_api_v1_auth_oauth()

Handle Google OAuth2 callback.

Google redirects here with authorization code. Exchange code for access token, verify user, generate JWT.

Query Parameters:     code: Authorization code from Google     state: State parameter (tenant_id:redirect_url)     error: Error message if authentication failed

Returns:     Redirect to original page with JWT token in URL fragment

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.DefaultApi(api_client)

    try:
        # Handle Google OAuth2 callback.
        api_instance.get_api_v1_auth_oauth()
    except Exception as e:
        print("Exception when calling DefaultApi->get_api_v1_auth_oauth: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_workflows_by_hashdefinition_hash**
> get_api_v1_workflows_by_hashdefinition_hash(definition_hash)

Get workflow definition by hash (PRIMARY identifier).

**RBAC Permission:** `view_workflows` **Roles with access:** tenant_admin, workflow_author, workflow_operator, workflow_viewer, analytics, support, developer

This is the preferred method - hash is the immutable, content-addressable identifier.

Path Parameters:     definition_hash: SHA-256 hash of workflow definition (64 hex chars)

Returns:     200: {         "definition_id": "uuid",         "workflow_name": "...",         "version": 1,         "tenant_id": "...",         "definition_hash": "sha256:...",         "definition_json": {...},         "python_dsl": "..." or null,         "json_dsl": "..."     }     404: Workflow definition not found     500: Internal server error

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.DefaultApi(api_client)
    definition_hash = 'definition_hash_example' # str | 

    try:
        # Get workflow definition by hash (PRIMARY identifier).
        api_instance.get_api_v1_workflows_by_hashdefinition_hash(definition_hash)
    except Exception as e:
        print("Exception when calling DefaultApi->get_api_v1_workflows_by_hashdefinition_hash: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **definition_hash** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_workflows_definitions_dsl_pythondefinition_id**
> get_api_v1_workflows_definitions_dsl_pythondefinition_id(definition_id)

Get workflow Python DSL source only.

**RBAC Permission:** `view_workflows`

Returns the original Python DSL source code used to create the workflow. Returns null if workflow was submitted as JSON directly.

Path Parameters:     definition_id: UUID of workflow definition

Returns:     200: {         "definition_id": "uuid",         "workflow_name": "...",         "version": 1,         "python_dsl": "from highway_dsl import ..." or null     }     404: Workflow definition not found

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.DefaultApi(api_client)
    definition_id = 'definition_id_example' # str | 

    try:
        # Get workflow Python DSL source only.
        api_instance.get_api_v1_workflows_definitions_dsl_pythondefinition_id(definition_id)
    except Exception as e:
        print("Exception when calling DefaultApi->get_api_v1_workflows_definitions_dsl_pythondefinition_id: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **definition_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_workflows_definitions_jsondefinition_id**
> get_api_v1_workflows_definitions_jsondefinition_id(definition_id)

Get workflow JSON definition only.

**RBAC Permission:** `view_workflows`

Returns the compiled JSON workflow definition without DSL sources.

Path Parameters:     definition_id: UUID of workflow definition

Returns:     200: {         "definition_id": "uuid",         "workflow_name": "...",         "version": 1,         "definition_json": {...}     }     404: Workflow definition not found

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.DefaultApi(api_client)
    definition_id = 'definition_id_example' # str | 

    try:
        # Get workflow JSON definition only.
        api_instance.get_api_v1_workflows_definitions_jsondefinition_id(definition_id)
    except Exception as e:
        print("Exception when calling DefaultApi->get_api_v1_workflows_definitions_jsondefinition_id: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **definition_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_workflows_definitionsdefinition_id**
> get_api_v1_workflows_definitionsdefinition_id(definition_id)

Get workflow definition by definition_id (UUID).

**RBAC Permission:** `view_workflows`

This is the preferred method for fetching definitions from workflow_run entries, which always have definition_id populated (unlike workflow_hash which may be NULL for cron-spawned workflows).

Path Parameters:     definition_id: UUID of workflow definition

Returns:     200: {         "definition_id": "uuid",         "workflow_name": "...",         "version": 1,         "tenant_id": "...",         "definition_hash": "sha256:...",         "definition_json": {...},         "python_dsl": "..." or null,         "json_dsl": "..."     }     404: Workflow definition not found     500: Internal server error

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.DefaultApi(api_client)
    definition_id = 'definition_id_example' # str | 

    try:
        # Get workflow definition by definition_id (UUID).
        api_instance.get_api_v1_workflows_definitionsdefinition_id(definition_id)
    except Exception as e:
        print("Exception when calling DefaultApi->get_api_v1_workflows_definitionsdefinition_id: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **definition_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_workflows_definitionsdefinition_id_executions_grid**
> get_api_v1_workflows_definitionsdefinition_id_executions_grid(definition_id)

Get workflow execution data in Airflow-style grid format by definition ID.

**RBAC Permission:** `view_workflows`

Returns recent executions with task-level status for grid visualization. Groups executions by workflow definition (not just name), ensuring same version.

Query Parameters:     days (int): Number of days to look back (default: 30, max: 90)

Returns:     200: Grid data with runs and task statuses     404: Workflow definition not found     500: Server error

Response:     {         "definition_id": "uuid",         "workflow_name": "os_check_workflow",         "runs": [             {                 "workflow_run_id": "...",                 "status": "completed",                 "created_at": "2025-11-18T10:24:00Z",                 "duration_ms": 68             },             ...         ],         "tasks": ["check_os", "success_handler", "failure_handler", ...],         "grid": {             "check_os": [                 {"status": "failed", "duration_ms": 12},                 {"status": "success", "duration_ms": 15},                 ...             ],             ...         }     }

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.DefaultApi(api_client)
    definition_id = 'definition_id_example' # str | 

    try:
        # Get workflow execution data in Airflow-style grid format by definition ID.
        api_instance.get_api_v1_workflows_definitionsdefinition_id_executions_grid(definition_id)
    except Exception as e:
        print("Exception when calling DefaultApi->get_api_v1_workflows_definitionsdefinition_id_executions_grid: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **definition_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_workflowsworkflow_name_versionsversion**
> get_api_v1_workflowsworkflow_name_versionsversion(workflow_name, version)

Get workflow definition by name and version (convenience method).

**RBAC Permission:** `view_workflows`

IMPORTANT: This looks up within DEFAULT tenant. For multi-tenant, use by-hash endpoint.

Path Parameters:     workflow_name: Workflow name     version: Version number (integer)

Query Parameters:     tenant_id: Optional tenant identifier (default: "default")

Returns:     200: {         "definition_id": "uuid",         "workflow_name": "...",         "version": 1,         "tenant_id": "...",         "definition_hash": "sha256:...",         "definition_json": {...},         "python_dsl": "..." or null,         "json_dsl": "..."     }     404: Workflow definition not found     500: Internal server error

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.DefaultApi(api_client)
    workflow_name = 'workflow_name_example' # str | 
    version = 56 # int | 

    try:
        # Get workflow definition by name and version (convenience method).
        api_instance.get_api_v1_workflowsworkflow_name_versionsversion(workflow_name, version)
    except Exception as e:
        print("Exception when calling DefaultApi->get_api_v1_workflowsworkflow_name_versionsversion: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_name** | **str**|  | 
 **version** | **int**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_workflowsworkflow_run_id_stepsstep_name_checkpoints**
> get_api_v1_workflowsworkflow_run_id_stepsstep_name_checkpoints(workflow_run_id, step_name)

**RBAC Permission:** `view_workflows`



### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.DefaultApi(api_client)
    workflow_run_id = 'workflow_run_id_example' # str | 
    step_name = 'step_name_example' # str | 

    try:
        # **RBAC Permission:** `view_workflows`
        api_instance.get_api_v1_workflowsworkflow_run_id_stepsstep_name_checkpoints(workflow_run_id, step_name)
    except Exception as e:
        print("Exception when calling DefaultApi->get_api_v1_workflowsworkflow_run_id_stepsstep_name_checkpoints: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_run_id** | **str**|  | 
 **step_name** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_favicon_ico**
> get_favicon_ico()

Serve favicon.



### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.DefaultApi(api_client)

    try:
        # Serve favicon.
        api_instance.get_favicon_ico()
    except Exception as e:
        print("Exception when calling DefaultApi->get_favicon_ico: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_login**
> get_login()

Render the standalone login page.

This is a completely separate page from the main app, ensuring clean isolation and no localStorage conflicts.

Returns:     HTML: Login page template

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.DefaultApi(api_client)

    try:
        # Render the standalone login page.
        api_instance.get_login()
    except Exception as e:
        print("Exception when calling DefaultApi->get_login: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_ping**
> get_ping()

Basic ping endpoint.



### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.DefaultApi(api_client)

    try:
        # Basic ping endpoint.
        api_instance.get_ping()
    except Exception as e:
        print("Exception when calling DefaultApi->get_ping: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_api_v1_auth_logout**
> post_api_v1_auth_logout()

Logout user (client-side token deletion).

This endpoint doesn't invalidate the token (stateless JWT), but provides a standard logout endpoint for the frontend.

Query Parameters (GET only):     on_success_redirect: URL to redirect after logout (optional, default: "/")     on_failure_redirect: URL to redirect on error (optional, default: "/")

Returns (POST):     {         "status": "success",         "message": "Logged out successfully"     }

Returns (GET):     Redirect to on_success_redirect

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.DefaultApi(api_client)

    try:
        # Logout user (client-side token deletion).
        api_instance.post_api_v1_auth_logout()
    except Exception as e:
        print("Exception when calling DefaultApi->post_api_v1_auth_logout: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_api_v1_auth_verify**
> post_api_v1_auth_verify()

Verify JWT token.

Request Body (JSON):     {         "token": "jwt_token_string"     }

Returns:     {         "status": "success",         "email": "user@example.com",         "tenant_id": "default",         "expires_at": "2025-11-24T23:00:00Z"     }

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.DefaultApi(api_client)

    try:
        # Verify JWT token.
        api_instance.post_api_v1_auth_verify()
    except Exception as e:
        print("Exception when calling DefaultApi->post_api_v1_auth_verify: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

