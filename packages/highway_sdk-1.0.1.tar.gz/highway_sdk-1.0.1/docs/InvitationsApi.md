# highway_sdk.InvitationsApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**delete_api_v1_admin_invitationsinvitation_id**](InvitationsApi.md#delete_api_v1_admin_invitationsinvitation_id) | **DELETE** /api/v1/admin/invitations/{invitation_id} | Cancel a pending invitation.
[**get_api_v1_admin_invitations**](InvitationsApi.md#get_api_v1_admin_invitations) | **GET** /api/v1/admin/invitations | List all invitations for the current tenant.
[**get_api_v1_admin_invitationsinvitation_id**](InvitationsApi.md#get_api_v1_admin_invitationsinvitation_id) | **GET** /api/v1/admin/invitations/{invitation_id} | Get details for a specific invitation.
[**post_api_v1_admin_invitations**](InvitationsApi.md#post_api_v1_admin_invitations) | **POST** /api/v1/admin/invitations | Send an invitation to join the tenant.
[**post_api_v1_admin_invitationsinvitation_id_resend**](InvitationsApi.md#post_api_v1_admin_invitationsinvitation_id_resend) | **POST** /api/v1/admin/invitations/{invitation_id}/resend | Resend an invitation with a new token and extended expiration.
[**post_api_v1_invitations_accept**](InvitationsApi.md#post_api_v1_invitations_accept) | **POST** /api/v1/invitations/accept | Accept an invitation to join a tenant.


# **delete_api_v1_admin_invitationsinvitation_id**
> SuccessResponseInvitationResponseE7ebca9 delete_api_v1_admin_invitationsinvitation_id(invitation_id)

Cancel a pending invitation.

Args:     invitation_id: Invitation UUID

Request Body (optional):     {         "reason": "No longer needed"  // Optional reason     }

Returns:     200: Invitation cancelled     404: Invitation not found     409: Invitation already accepted/cancelled/expired

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.models.success_response_invitation_response_e7ebca9 import SuccessResponseInvitationResponseE7ebca9
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.InvitationsApi(api_client)
    invitation_id = 'invitation_id_example' # str | 

    try:
        # Cancel a pending invitation.
        api_response = api_instance.delete_api_v1_admin_invitationsinvitation_id(invitation_id)
        print("The response of InvitationsApi->delete_api_v1_admin_invitationsinvitation_id:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling InvitationsApi->delete_api_v1_admin_invitationsinvitation_id: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **invitation_id** | **str**|  | 

### Return type

[**SuccessResponseInvitationResponseE7ebca9**](SuccessResponseInvitationResponseE7ebca9.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**404** | Not Found |  -  |
**409** | Conflict |  -  |
**422** | Unprocessable Content |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_admin_invitations**
> SuccessResponseInvitationListResponseE7ebca9 get_api_v1_admin_invitations()

List all invitations for the current tenant.

Query Parameters:     status: Filter by status (pending, accepted, expired, cancelled)     email: Filter by email     page: Page number (default: 1)     per_page: Items per page (default: 50, max: 200)

Returns:     200: {         "invitations": [...],         "total": 10,         "page": 1,         "per_page": 50     }

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.models.success_response_invitation_list_response_e7ebca9 import SuccessResponseInvitationListResponseE7ebca9
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.InvitationsApi(api_client)

    try:
        # List all invitations for the current tenant.
        api_response = api_instance.get_api_v1_admin_invitations()
        print("The response of InvitationsApi->get_api_v1_admin_invitations:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling InvitationsApi->get_api_v1_admin_invitations: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**SuccessResponseInvitationListResponseE7ebca9**](SuccessResponseInvitationListResponseE7ebca9.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**422** | Unprocessable Content |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_v1_admin_invitationsinvitation_id**
> SuccessResponseInvitationResponseE7ebca9 get_api_v1_admin_invitationsinvitation_id(invitation_id)

Get details for a specific invitation.

Args:     invitation_id: Invitation UUID

Returns:     200: Invitation details     404: Invitation not found

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.models.success_response_invitation_response_e7ebca9 import SuccessResponseInvitationResponseE7ebca9
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.InvitationsApi(api_client)
    invitation_id = 'invitation_id_example' # str | 

    try:
        # Get details for a specific invitation.
        api_response = api_instance.get_api_v1_admin_invitationsinvitation_id(invitation_id)
        print("The response of InvitationsApi->get_api_v1_admin_invitationsinvitation_id:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling InvitationsApi->get_api_v1_admin_invitationsinvitation_id: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **invitation_id** | **str**|  | 

### Return type

[**SuccessResponseInvitationResponseE7ebca9**](SuccessResponseInvitationResponseE7ebca9.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**404** | Not Found |  -  |
**422** | Unprocessable Content |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_api_v1_admin_invitations**
> SuccessResponseInvitationResponseE7ebca9 post_api_v1_admin_invitations()

Send an invitation to join the tenant.

Request Body:     {         "email": "newuser@example.com",         "roles": ["workflow_viewer", "analytics"],  // Optional, default: ["workflow_viewer"]         "message": "Welcome to our team!",          // Optional custom message         "expires_in_days": 7                        // Optional, default: 7, max: 30     }

Returns:     201: {         "invitation_id": "uuid",         "email": "newuser@example.com",         "roles": ["workflow_viewer", "analytics"],         "expires_at": "2025-12-04T...",         "invitation_url": "https://..."   // URL to share with invitee     }

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.models.success_response_invitation_response_e7ebca9 import SuccessResponseInvitationResponseE7ebca9
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.InvitationsApi(api_client)

    try:
        # Send an invitation to join the tenant.
        api_response = api_instance.post_api_v1_admin_invitations()
        print("The response of InvitationsApi->post_api_v1_admin_invitations:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling InvitationsApi->post_api_v1_admin_invitations: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**SuccessResponseInvitationResponseE7ebca9**](SuccessResponseInvitationResponseE7ebca9.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | Created |  -  |
**400** | Bad Request |  -  |
**409** | Conflict |  -  |
**422** | Unprocessable Content |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_api_v1_admin_invitationsinvitation_id_resend**
> SuccessResponseInvitationResendResponseE7ebca9 post_api_v1_admin_invitationsinvitation_id_resend(invitation_id)

Resend an invitation with a new token and extended expiration.

Args:     invitation_id: Invitation UUID

Request Body (optional):     {         "expires_in_days": 7  // Optional, default: 7     }

Returns:     200: {         "invitation_id": "...",         "new_invitation_url": "...",         "new_expires_at": "..."     }

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.models.success_response_invitation_resend_response_e7ebca9 import SuccessResponseInvitationResendResponseE7ebca9
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.InvitationsApi(api_client)
    invitation_id = 'invitation_id_example' # str | 

    try:
        # Resend an invitation with a new token and extended expiration.
        api_response = api_instance.post_api_v1_admin_invitationsinvitation_id_resend(invitation_id)
        print("The response of InvitationsApi->post_api_v1_admin_invitationsinvitation_id_resend:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling InvitationsApi->post_api_v1_admin_invitationsinvitation_id_resend: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **invitation_id** | **str**|  | 

### Return type

[**SuccessResponseInvitationResendResponseE7ebca9**](SuccessResponseInvitationResendResponseE7ebca9.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**404** | Not Found |  -  |
**409** | Conflict |  -  |
**422** | Unprocessable Content |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_api_v1_invitations_accept**
> SuccessResponseInvitationAcceptResponseE7ebca9 post_api_v1_invitations_accept()

Accept an invitation to join a tenant.

This is a PUBLIC endpoint - no authentication required. The user provides the invitation token and their email.

Request Body:     {         "token": "invitation_token_here",         "email": "newuser@example.com"  // Must match invitation email     }

Returns:     200: {         "success": true,         "tenant_id": "...",         "roles": [...],         "message": "Welcome! You now have access to..."     }

### Example

* Bearer (JWT) Authentication (BearerAuth):

```python
import highway_sdk
from highway_sdk.models.success_response_invitation_accept_response_e7ebca9 import SuccessResponseInvitationAcceptResponseE7ebca9
from highway_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = highway_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): BearerAuth
configuration = highway_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = highway_sdk.InvitationsApi(api_client)

    try:
        # Accept an invitation to join a tenant.
        api_response = api_instance.post_api_v1_invitations_accept()
        print("The response of InvitationsApi->post_api_v1_invitations_accept:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling InvitationsApi->post_api_v1_invitations_accept: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**SuccessResponseInvitationAcceptResponseE7ebca9**](SuccessResponseInvitationAcceptResponseE7ebca9.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**404** | Not Found |  -  |
**409** | Conflict |  -  |
**410** | Gone |  -  |
**422** | Unprocessable Content |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

