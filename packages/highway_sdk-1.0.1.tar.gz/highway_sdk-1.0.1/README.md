# highway-sdk

[![PyPI version](https://badge.fury.io/py/highway-sdk.svg)](https://badge.fury.io/py/highway-sdk)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)

Python SDK for **Highway Workflow Engine** - A production-grade durable workflow orchestration platform.

## Features

- **Workflow Orchestration**: Execute complex multi-step workflows with fault tolerance
- **Durable Execution**: Automatic checkpointing and replay for disaster recovery
- **Time-Travel Debugging**: Replay and simulate past workflow executions
- **Multi-Tenancy**: Full tenant isolation with RBAC
- **Distributed Locks**: PostgreSQL advisory locks for coordination
- **Saga Patterns**: Compensation support for rollback scenarios

## Requirements

Python 3.9+

## Installation

```sh
pip install highway-sdk
```

Or install from source:

```sh
pip install git+https://github.com/rodmena-limited/highway-sdk-python.git
```

## Getting Started

```python
import os
import highway_sdk
from highway_sdk.rest import ApiException

# Configure the client
configuration = highway_sdk.Configuration(
    host="https://your-highway-instance.com",
    access_token=os.environ["HIGHWAY_TOKEN"]
)

# Use the API client
with highway_sdk.ApiClient(configuration) as api_client:
    # Check system health
    system_api = highway_sdk.SystemApi(api_client)
    health = system_api.get_api_v1_health()
    print(f"System status: {health}")

    # List workflows
    workflows_api = highway_sdk.WorkflowsApi(api_client)
    workflows = workflows_api.get_api_v1_workflows()
    print(f"Found {len(workflows.data)} workflows")
```

## Authentication

The SDK supports two authentication methods:

### Bearer Token (JWT)
```python
configuration = highway_sdk.Configuration(
    host="https://your-highway-instance.com",
    access_token="your-jwt-token"
)
```

### API Key
```python
configuration = highway_sdk.Configuration(
    host="https://your-highway-instance.com"
)
configuration.api_key["X-API-Key"] = "your-api-key"
```

## Rate Limiting

API requests are rate-limited per tenant. Check response headers:
- `X-RateLimit-Limit`: Maximum requests per window
- `X-RateLimit-Remaining`: Remaining requests
- `X-RateLimit-Reset`: Window reset timestamp

## Documentation for API Endpoints

All URIs are relative to *http://localhost*

Class | Method | HTTP request | Description
------------ | ------------- | ------------- | -------------
*APIKeysApi* | [**delete_api_v1_admin_api_keysapi_key_id**](docs/APIKeysApi.md#delete_api_v1_admin_api_keysapi_key_id) | **DELETE** /api/v1/admin/api-keys/{api_key_id} | Deactivate an API key.
*APIKeysApi* | [**get_api_v1_admin_api_keys**](docs/APIKeysApi.md#get_api_v1_admin_api_keys) | **GET** /api/v1/admin/api-keys | List all API keys for the current tenant.
*APIKeysApi* | [**get_api_v1_admin_api_keysapi_key_id**](docs/APIKeysApi.md#get_api_v1_admin_api_keysapi_key_id) | **GET** /api/v1/admin/api-keys/{api_key_id} | Get details for a specific API key.
*APIKeysApi* | [**post_api_v1_admin_api_keys**](docs/APIKeysApi.md#post_api_v1_admin_api_keys) | **POST** /api/v1/admin/api-keys | Create a new API key for service account access.
*APIKeysApi* | [**post_api_v1_admin_api_keysapi_key_id_rotate**](docs/APIKeysApi.md#post_api_v1_admin_api_keysapi_key_id_rotate) | **POST** /api/v1/admin/api-keys/{api_key_id}/rotate | Rotate an API key with optional grace period.
*ActivitiesApi* | [**get_api_v1_activities**](docs/ActivitiesApi.md#get_api_v1_activities) | **GET** /api/v1/activities | List activities with filtering.
*ActivitiesApi* | [**get_api_v1_activities_stale**](docs/ActivitiesApi.md#get_api_v1_activities_stale) | **GET** /api/v1/activities/stale | Get list of activities that appear to be stuck.
*ActivitiesApi* | [**get_api_v1_activities_status**](docs/ActivitiesApi.md#get_api_v1_activities_status) | **GET** /api/v1/activities/status | Get real-time status of all activity workers and queue.
*ActivitiesApi* | [**get_api_v1_activitiesactivity_id**](docs/ActivitiesApi.md#get_api_v1_activitiesactivity_id) | **GET** /api/v1/activities/{activity_id} | Get detailed information about a specific activity.
*ActivitiesApi* | [**get_api_v1_activitiesactivity_id_heartbeats**](docs/ActivitiesApi.md#get_api_v1_activitiesactivity_id_heartbeats) | **GET** /api/v1/activities/{activity_id}/heartbeats | Get heartbeat history for an activity.
*ActivitiesApi* | [**get_api_v1_workflowsworkflow_run_id_activities**](docs/ActivitiesApi.md#get_api_v1_workflowsworkflow_run_id_activities) | **GET** /api/v1/workflows/{workflow_run_id}/activities | Get all activities spawned by a workflow run.
*ActivitiesApi* | [**post_api_v1_activities_cleanup_heartbeats**](docs/ActivitiesApi.md#post_api_v1_activities_cleanup_heartbeats) | **POST** /api/v1/activities/cleanup-heartbeats | Clean up old heartbeat history records.
*AnalyticsApi* | [**get_api_v1_analytics_events**](docs/AnalyticsApi.md#get_api_v1_analytics_events) | **GET** /api/v1/analytics/events | Get event timeline for analytics.
*AnalyticsApi* | [**get_api_v1_analytics_performance**](docs/AnalyticsApi.md#get_api_v1_analytics_performance) | **GET** /api/v1/analytics/performance | Get workflow performance metrics.
*AnalyticsApi* | [**get_api_v1_analytics_queues**](docs/AnalyticsApi.md#get_api_v1_analytics_queues) | **GET** /api/v1/analytics/queues | List all queues with health metrics.
*AnalyticsApi* | [**get_api_v1_analytics_queuesqueue_name**](docs/AnalyticsApi.md#get_api_v1_analytics_queuesqueue_name) | **GET** /api/v1/analytics/queues/{queue_name} | Get detailed analytics for a specific queue.
*AnalyticsApi* | [**get_api_v1_analytics_tasks_distribution**](docs/AnalyticsApi.md#get_api_v1_analytics_tasks_distribution) | **GET** /api/v1/analytics/tasks/distribution | Get task state distribution across all queues.
*AnalyticsApi* | [**get_api_v1_analytics_tasks_list**](docs/AnalyticsApi.md#get_api_v1_analytics_tasks_list) | **GET** /api/v1/analytics/tasks/list | List all tasks with detailed information.
*ApprovalsApi* | [**get_api_v1_approvals**](docs/ApprovalsApi.md#get_api_v1_approvals) | **GET** /api/v1/approvals | List approvals with optional filtering.
*ApprovalsApi* | [**get_api_v1_approvalsapproval_key**](docs/ApprovalsApi.md#get_api_v1_approvalsapproval_key) | **GET** /api/v1/approvals/{approval_key} | Get a specific approval by key.
*ApprovalsApi* | [**post_api_v1_approvalsapproval_key_approve**](docs/ApprovalsApi.md#post_api_v1_approvalsapproval_key_approve) | **POST** /api/v1/approvals/{approval_key}/approve | Approve a pending approval.
*ApprovalsApi* | [**post_api_v1_approvalsapproval_key_reject**](docs/ApprovalsApi.md#post_api_v1_approvalsapproval_key_reject) | **POST** /api/v1/approvals/{approval_key}/reject | Reject a pending approval.
*AppsApi* | [**delete_api_v1_appsapp_id**](docs/AppsApi.md#delete_api_v1_appsapp_id) | **DELETE** /api/v1/apps/{app_id} | Soft delete an app.
*AppsApi* | [**get_api_v1_apps**](docs/AppsApi.md#get_api_v1_apps) | **GET** /api/v1/apps | List apps with pagination and filters.
*AppsApi* | [**get_api_v1_apps_categories**](docs/AppsApi.md#get_api_v1_apps_categories) | **GET** /api/v1/apps/categories | List app categories with counts.
*AppsApi* | [**get_api_v1_apps_marketplace**](docs/AppsApi.md#get_api_v1_apps_marketplace) | **GET** /api/v1/apps/marketplace | Browse public apps marketplace.
*AppsApi* | [**get_api_v1_appsapp_id**](docs/AppsApi.md#get_api_v1_appsapp_id) | **GET** /api/v1/apps/{app_id} | Get app details.
*AppsApi* | [**get_api_v1_appsapp_id_versions**](docs/AppsApi.md#get_api_v1_appsapp_id_versions) | **GET** /api/v1/apps/{app_id}/versions | List all versions for an app.
*AppsApi* | [**get_api_v1_appsapp_id_versionsversion_id**](docs/AppsApi.md#get_api_v1_appsapp_id_versionsversion_id) | **GET** /api/v1/apps/{app_id}/versions/{version_id} | Get version details.
*AppsApi* | [**patch_api_v1_appsapp_id**](docs/AppsApi.md#patch_api_v1_appsapp_id) | **PATCH** /api/v1/apps/{app_id} | Update app metadata.
*AppsApi* | [**post_api_v1_apps**](docs/AppsApi.md#post_api_v1_apps) | **POST** /api/v1/apps | Register a new app.
*AppsApi* | [**post_api_v1_appsapp_id_versions**](docs/AppsApi.md#post_api_v1_appsapp_id_versions) | **POST** /api/v1/apps/{app_id}/versions | Create a new app version (draft).
*AppsApi* | [**post_api_v1_appsapp_id_versionsversion_id_deprecate**](docs/AppsApi.md#post_api_v1_appsapp_id_versionsversion_id_deprecate) | **POST** /api/v1/apps/{app_id}/versions/{version_id}/deprecate | Deprecate a published version.
*AppsApi* | [**post_api_v1_appsapp_id_versionsversion_id_publish**](docs/AppsApi.md#post_api_v1_appsapp_id_versionsversion_id_publish) | **POST** /api/v1/apps/{app_id}/versions/{version_id}/publish | Publish a draft version.
*ArtifactsApi* | [**delete_api_v1_artifactsartifact_id**](docs/ArtifactsApi.md#delete_api_v1_artifactsartifact_id) | **DELETE** /api/v1/artifacts/{artifact_id} | Delete a Python module artifact by ID.
*ArtifactsApi* | [**get_api_v1_artifacts**](docs/ArtifactsApi.md#get_api_v1_artifacts) | **GET** /api/v1/artifacts | List all available artifacts.
*ArtifactsApi* | [**get_api_v1_artifactsartifact_id**](docs/ArtifactsApi.md#get_api_v1_artifactsartifact_id) | **GET** /api/v1/artifacts/{artifact_id} | Retrieve a Python module artifact by ID.
*ArtifactsApi* | [**get_api_v1_artifactsartifact_id_exists**](docs/ArtifactsApi.md#get_api_v1_artifactsartifact_id_exists) | **GET** /api/v1/artifacts/{artifact_id}/exists | Check if an artifact exists.
*ArtifactsApi* | [**post_api_v1_artifacts**](docs/ArtifactsApi.md#post_api_v1_artifacts) | **POST** /api/v1/artifacts | Upload a Python module artifact (zip file).
*AuditLogsApi* | [**get_api_v1_admin_audit_logs**](docs/AuditLogsApi.md#get_api_v1_admin_audit_logs) | **GET** /api/v1/admin/audit-logs | List admin audit logs with filters.
*AuditLogsApi* | [**get_api_v1_admin_audit_logslog_id**](docs/AuditLogsApi.md#get_api_v1_admin_audit_logslog_id) | **GET** /api/v1/admin/audit-logs/{log_id} | Get details for a specific audit log entry.
*CircuitBreakersApi* | [**get_api_v1_circuit_breakers**](docs/CircuitBreakersApi.md#get_api_v1_circuit_breakers) | **GET** /api/v1/circuit-breakers | List all circuit breakers with their current state.
*CircuitBreakersApi* | [**get_api_v1_circuit_breakersresource_key**](docs/CircuitBreakersApi.md#get_api_v1_circuit_breakersresource_key) | **GET** /api/v1/circuit-breakers/{resource_key} | Get specific circuit breaker status.
*CircuitBreakersApi* | [**post_api_v1_circuit_breakers_reset**](docs/CircuitBreakersApi.md#post_api_v1_circuit_breakers_reset) | **POST** /api/v1/circuit-breakers/reset | Reset circuit breaker caches in all workers.
*CircuitBreakersApi* | [**post_api_v1_circuit_breakersresource_key_reset**](docs/CircuitBreakersApi.md#post_api_v1_circuit_breakersresource_key_reset) | **POST** /api/v1/circuit-breakers/{resource_key}/reset | Reset specific circuit breaker in database.
*DSLTemplatesApi* | [**get_api_v1_dsl_templates**](docs/DSLTemplatesApi.md#get_api_v1_dsl_templates) | **GET** /api/v1/dsl_templates | List all available DSL templates.
*DSLTemplatesApi* | [**get_api_v1_dsl_templatestemplate_name**](docs/DSLTemplatesApi.md#get_api_v1_dsl_templatestemplate_name) | **GET** /api/v1/dsl_templates/{template_name} | Get a specific DSL template by name.
*DSLTemplatesApi* | [**post_api_v1_dsl_to_json**](docs/DSLTemplatesApi.md#post_api_v1_dsl_to_json) | **POST** /api/v1/dsl_to_json | Convert Python DSL code to JSON workflow definition.
*IdempotencyApi* | [**delete_api_v1_idempotencyidempotency_key**](docs/IdempotencyApi.md#delete_api_v1_idempotencyidempotency_key) | **DELETE** /api/v1/idempotency/{idempotency_key} | Delete idempotency record for testing.
*IdempotencyApi* | [**post_api_v1_idempotency_reset_all**](docs/IdempotencyApi.md#post_api_v1_idempotency_reset_all) | **POST** /api/v1/idempotency/reset-all | Delete ALL idempotency records for testing.
*InvitationsApi* | [**delete_api_v1_admin_invitationsinvitation_id**](docs/InvitationsApi.md#delete_api_v1_admin_invitationsinvitation_id) | **DELETE** /api/v1/admin/invitations/{invitation_id} | Cancel a pending invitation.
*InvitationsApi* | [**get_api_v1_admin_invitations**](docs/InvitationsApi.md#get_api_v1_admin_invitations) | **GET** /api/v1/admin/invitations | List all invitations for the current tenant.
*InvitationsApi* | [**get_api_v1_admin_invitationsinvitation_id**](docs/InvitationsApi.md#get_api_v1_admin_invitationsinvitation_id) | **GET** /api/v1/admin/invitations/{invitation_id} | Get details for a specific invitation.
*InvitationsApi* | [**post_api_v1_admin_invitations**](docs/InvitationsApi.md#post_api_v1_admin_invitations) | **POST** /api/v1/admin/invitations | Send an invitation to join the tenant.
*InvitationsApi* | [**post_api_v1_admin_invitationsinvitation_id_resend**](docs/InvitationsApi.md#post_api_v1_admin_invitationsinvitation_id_resend) | **POST** /api/v1/admin/invitations/{invitation_id}/resend | Resend an invitation with a new token and extended expiration.
*InvitationsApi* | [**post_api_v1_invitations_accept**](docs/InvitationsApi.md#post_api_v1_invitations_accept) | **POST** /api/v1/invitations/accept | Accept an invitation to join a tenant.
*LogsApi* | [**get_api_v1_logs_activities**](docs/LogsApi.md#get_api_v1_logs_activities) | **GET** /api/v1/logs/activities | List recent activity logs across all workflows for the tenant.
*LogsApi* | [**get_api_v1_logs_stats**](docs/LogsApi.md#get_api_v1_logs_stats) | **GET** /api/v1/logs/stats | Get aggregated workflow statistics.
*LogsApi* | [**get_api_v1_logs_workflows**](docs/LogsApi.md#get_api_v1_logs_workflows) | **GET** /api/v1/logs/workflows | List workflow logs with filtering and pagination.
*LogsApi* | [**get_api_v1_logs_workflowsworkflow_run_id**](docs/LogsApi.md#get_api_v1_logs_workflowsworkflow_run_id) | **GET** /api/v1/logs/workflows/{workflow_run_id} | Get workflow log by workflow_run_id.
*LogsApi* | [**get_api_v1_logs_workflowsworkflow_run_id_activities**](docs/LogsApi.md#get_api_v1_logs_workflowsworkflow_run_id_activities) | **GET** /api/v1/logs/workflows/{workflow_run_id}/activities | List activity logs for a workflow.
*LogsApi* | [**get_api_v1_logs_workflowsworkflow_run_id_activitiesactivity_id**](docs/LogsApi.md#get_api_v1_logs_workflowsworkflow_run_id_activitiesactivity_id) | **GET** /api/v1/logs/workflows/{workflow_run_id}/activities/{activity_id} | Get activity log with captured Python logging output.
*LogsApi* | [**get_api_v1_logs_workflowsworkflow_run_id_taskstask_id**](docs/LogsApi.md#get_api_v1_logs_workflowsworkflow_run_id_taskstask_id) | **GET** /api/v1/logs/workflows/{workflow_run_id}/tasks/{task_id} | Get task log with stdout/stderr.
*MonitoringApi* | [**get_api_v1_monitoring_live**](docs/MonitoringApi.md#get_api_v1_monitoring_live) | **GET** /api/v1/monitoring/live | Get currently active tasks from the ephemeral runtime table.
*QueriesApi* | [**get_api_v1_workflowsworkflow_run_id_query**](docs/QueriesApi.md#get_api_v1_workflowsworkflow_run_id_query) | **GET** /api/v1/workflows/{workflow_run_id}/query | Query workflow state.
*RBACApi* | [**get_api_v1_rbac_my_permissions**](docs/RBACApi.md#get_api_v1_rbac_my_permissions) | **GET** /api/v1/rbac/my-permissions | Get current user&#39;s permissions.
*RBACApi* | [**get_api_v1_rbac_my_roles**](docs/RBACApi.md#get_api_v1_rbac_my_roles) | **GET** /api/v1/rbac/my-roles | Get current user&#39;s roles.
*RBACApi* | [**get_api_v1_rbac_permissionspermission_name_roles**](docs/RBACApi.md#get_api_v1_rbac_permissionspermission_name_roles) | **GET** /api/v1/rbac/permissions/{permission_name}/roles | Get which roles have a specific permission.
*RBACApi* | [**get_api_v1_rbac_roles**](docs/RBACApi.md#get_api_v1_rbac_roles) | **GET** /api/v1/rbac/roles | List all available roles for current tenant.
*ReplayApi* | [**get_api_v1_workflowsworkflow_run_id_replay**](docs/ReplayApi.md#get_api_v1_workflowsworkflow_run_id_replay) | **GET** /api/v1/workflows/{workflow_run_id}/replay | Replay workflow execution for debugging.
*ReplayApi* | [**get_api_v1_workflowsworkflow_run_id_replay_steps**](docs/ReplayApi.md#get_api_v1_workflowsworkflow_run_id_replay_steps) | **GET** /api/v1/workflows/{workflow_run_id}/replay/steps | List available steps/checkpoints for a workflow run.
*ReplayApi* | [**post_api_v1_workflowsworkflow_run_id_simulate**](docs/ReplayApi.md#post_api_v1_workflowsworkflow_run_id_simulate) | **POST** /api/v1/workflows/{workflow_run_id}/simulate | Simulate workflow execution by re-running code with historical data.
*RunsApi* | [**get_api_v1_runs**](docs/RunsApi.md#get_api_v1_runs) | **GET** /api/v1/runs | List active runs with pagination and filtering.
*RunsApi* | [**get_api_v1_runsrun_id**](docs/RunsApi.md#get_api_v1_runsrun_id) | **GET** /api/v1/runs/{run_id} | Get run status by ID.
*RunsApi* | [**get_api_v1_runsrun_id_checkpoints**](docs/RunsApi.md#get_api_v1_runsrun_id_checkpoints) | **GET** /api/v1/runs/{run_id}/checkpoints | **RBAC Permission:** &#x60;view_workflows&#x60;
*SchedulesApi* | [**delete_api_v1_schedulesschedule_id**](docs/SchedulesApi.md#delete_api_v1_schedulesschedule_id) | **DELETE** /api/v1/schedules/{schedule_id} | Delete a workflow schedule.
*SchedulesApi* | [**get_api_v1_schedules**](docs/SchedulesApi.md#get_api_v1_schedules) | **GET** /api/v1/schedules | List all workflow schedules.
*SchedulesApi* | [**get_api_v1_schedulesschedule_id**](docs/SchedulesApi.md#get_api_v1_schedulesschedule_id) | **GET** /api/v1/schedules/{schedule_id} | Get specific schedule status and details.
*SchedulesApi* | [**get_api_v1_schedulesschedule_id_history**](docs/SchedulesApi.md#get_api_v1_schedulesschedule_id_history) | **GET** /api/v1/schedules/{schedule_id}/history | Get schedule execution history.
*SchedulesApi* | [**patch_api_v1_schedulesschedule_id**](docs/SchedulesApi.md#patch_api_v1_schedulesschedule_id) | **PATCH** /api/v1/schedules/{schedule_id} | Update a workflow schedule (pause/resume).
*SchedulesApi* | [**post_api_v1_schedules**](docs/SchedulesApi.md#post_api_v1_schedules) | **POST** /api/v1/schedules | Create a new workflow schedule using durable_cron.
*SchedulesApi* | [**post_api_v1_schedules_scan**](docs/SchedulesApi.md#post_api_v1_schedules_scan) | **POST** /api/v1/schedules/scan | DEPRECATED: Manual schedule scanning not needed with durable_cron.
*SchemasApi* | [**delete_api_v1_schemasworkflow_name_versionsversion**](docs/SchemasApi.md#delete_api_v1_schemasworkflow_name_versionsversion) | **DELETE** /api/v1/schemas/{workflow_name}/versions/{version} | Deprecate a schema version.
*SchemasApi* | [**get_api_v1_schemas**](docs/SchemasApi.md#get_api_v1_schemas) | **GET** /api/v1/schemas | List all registered workflow schemas.
*SchemasApi* | [**get_api_v1_schemas_stats**](docs/SchemasApi.md#get_api_v1_schemas_stats) | **GET** /api/v1/schemas/stats | Get statistics about registered schemas.
*SchemasApi* | [**get_api_v1_schemasworkflow_name**](docs/SchemasApi.md#get_api_v1_schemasworkflow_name) | **GET** /api/v1/schemas/{workflow_name} | Get a workflow schema (latest or specific version).
*SchemasApi* | [**post_api_v1_schemasworkflow_name_validate**](docs/SchemasApi.md#post_api_v1_schemasworkflow_name_validate) | **POST** /api/v1/schemas/{workflow_name}/validate | Validate input data against a workflow schema.
*SignalsApi* | [**get_api_v1_workflowsworkflow_run_id_signals**](docs/SignalsApi.md#get_api_v1_workflowsworkflow_run_id_signals) | **GET** /api/v1/workflows/{workflow_run_id}/signals | Get pending signals for a workflow.
*SignalsApi* | [**post_api_v1_workflowsworkflow_run_id_signals**](docs/SignalsApi.md#post_api_v1_workflowsworkflow_run_id_signals) | **POST** /api/v1/workflows/{workflow_run_id}/signals | Send a signal to a running workflow.
*StatisticsApi* | [**get_api_v1_workflows_stats**](docs/StatisticsApi.md#get_api_v1_workflows_stats) | **GET** /api/v1/workflows/stats | Get global workflow statistics.
*StatisticsApi* | [**get_api_v1_workflowsworkflow_run_id_metrics**](docs/StatisticsApi.md#get_api_v1_workflowsworkflow_run_id_metrics) | **GET** /api/v1/workflows/{workflow_run_id}/metrics | Get detailed metrics for a specific workflow execution.
*StepsApi* | [**get_api_v1_workflowsworkflow_run_id_steps**](docs/StepsApi.md#get_api_v1_workflowsworkflow_run_id_steps) | **GET** /api/v1/workflows/{workflow_run_id}/steps | List all steps in a workflow with their status.
*StepsApi* | [**get_api_v1_workflowsworkflow_run_id_steps_logs**](docs/StepsApi.md#get_api_v1_workflowsworkflow_run_id_steps_logs) | **GET** /api/v1/workflows/{workflow_run_id}/steps/logs | Get DataShard logs for all steps in a workflow.
*StepsApi* | [**get_api_v1_workflowsworkflow_run_id_stepsstep_name**](docs/StepsApi.md#get_api_v1_workflowsworkflow_run_id_stepsstep_name) | **GET** /api/v1/workflows/{workflow_run_id}/steps/{step_name} | Get detailed information about a specific step.
*StepsApi* | [**get_api_v1_workflowsworkflow_run_id_stepsstep_name_logs**](docs/StepsApi.md#get_api_v1_workflowsworkflow_run_id_stepsstep_name_logs) | **GET** /api/v1/workflows/{workflow_run_id}/steps/{step_name}/logs | Get DataShard logs for a specific step.
*SystemApi* | [**get_api_v1_health**](docs/SystemApi.md#get_api_v1_health) | **GET** /api/v1/health | Health check endpoint.
*SystemApi* | [**get_api_v1_health_metrics**](docs/SystemApi.md#get_api_v1_health_metrics) | **GET** /api/v1/health/metrics | Get detailed health metrics for monitoring and alerting.
*SystemApi* | [**get_api_v1_version**](docs/SystemApi.md#get_api_v1_version) | **GET** /api/v1/version | Get version information.
*TasksApi* | [**get_api_v1_tasks**](docs/TasksApi.md#get_api_v1_tasks) | **GET** /api/v1/tasks | List Absurd tasks with filtering and pagination.
*TasksApi* | [**get_api_v1_tasks_summary**](docs/TasksApi.md#get_api_v1_tasks_summary) | **GET** /api/v1/tasks/summary | Get task count summary by state and queue.
*TasksApi* | [**get_api_v1_taskstask_id**](docs/TasksApi.md#get_api_v1_taskstask_id) | **GET** /api/v1/tasks/{task_id} | Get detailed information about a specific Absurd task.
*TenantAppsApi* | [**delete_api_v1_tenant_appsinstallation_id**](docs/TenantAppsApi.md#delete_api_v1_tenant_appsinstallation_id) | **DELETE** /api/v1/tenant/apps/{installation_id} | Uninstall an app.
*TenantAppsApi* | [**delete_api_v1_tenant_appsinstallation_id_secretssecret_name**](docs/TenantAppsApi.md#delete_api_v1_tenant_appsinstallation_id_secretssecret_name) | **DELETE** /api/v1/tenant/apps/{installation_id}/secrets/{secret_name} | Delete a secret for an app.
*TenantAppsApi* | [**get_api_v1_tenant_apps**](docs/TenantAppsApi.md#get_api_v1_tenant_apps) | **GET** /api/v1/tenant/apps | List apps installed for this tenant.
*TenantAppsApi* | [**get_api_v1_tenant_apps_tools**](docs/TenantAppsApi.md#get_api_v1_tenant_apps_tools) | **GET** /api/v1/tenant/apps/tools | List all tools available to this tenant from installed apps.
*TenantAppsApi* | [**get_api_v1_tenant_appsinstallation_id**](docs/TenantAppsApi.md#get_api_v1_tenant_appsinstallation_id) | **GET** /api/v1/tenant/apps/{installation_id} | Get installation details.
*TenantAppsApi* | [**get_api_v1_tenant_appsinstallation_id_config**](docs/TenantAppsApi.md#get_api_v1_tenant_appsinstallation_id_config) | **GET** /api/v1/tenant/apps/{installation_id}/config | Get app configuration.
*TenantAppsApi* | [**get_api_v1_tenant_appsinstallation_id_logs**](docs/TenantAppsApi.md#get_api_v1_tenant_appsinstallation_id_logs) | **GET** /api/v1/tenant/apps/{installation_id}/logs | Get execution logs for an app.
*TenantAppsApi* | [**get_api_v1_tenant_appsinstallation_id_logslog_id**](docs/TenantAppsApi.md#get_api_v1_tenant_appsinstallation_id_logslog_id) | **GET** /api/v1/tenant/apps/{installation_id}/logs/{log_id} | Get detailed execution log.
*TenantAppsApi* | [**get_api_v1_tenant_appsinstallation_id_secrets**](docs/TenantAppsApi.md#get_api_v1_tenant_appsinstallation_id_secrets) | **GET** /api/v1/tenant/apps/{installation_id}/secrets | List configured secrets for an app (names only, not values).
*TenantAppsApi* | [**patch_api_v1_tenant_appsinstallation_id_config**](docs/TenantAppsApi.md#patch_api_v1_tenant_appsinstallation_id_config) | **PATCH** /api/v1/tenant/apps/{installation_id}/config | Update app configuration.
*TenantAppsApi* | [**post_api_v1_tenant_apps**](docs/TenantAppsApi.md#post_api_v1_tenant_apps) | **POST** /api/v1/tenant/apps | Install an app for this tenant.
*TenantAppsApi* | [**post_api_v1_tenant_appsinstallation_id_disable**](docs/TenantAppsApi.md#post_api_v1_tenant_appsinstallation_id_disable) | **POST** /api/v1/tenant/apps/{installation_id}/disable | Disable an app (workflows using it will fail).
*TenantAppsApi* | [**post_api_v1_tenant_appsinstallation_id_enable**](docs/TenantAppsApi.md#post_api_v1_tenant_appsinstallation_id_enable) | **POST** /api/v1/tenant/apps/{installation_id}/enable | Enable a disabled app.
*TenantAppsApi* | [**post_api_v1_tenant_appsinstallation_id_upgrade**](docs/TenantAppsApi.md#post_api_v1_tenant_appsinstallation_id_upgrade) | **POST** /api/v1/tenant/apps/{installation_id}/upgrade | Upgrade app to a new version.
*TenantAppsApi* | [**put_api_v1_tenant_appsinstallation_id_secretssecret_name**](docs/TenantAppsApi.md#put_api_v1_tenant_appsinstallation_id_secretssecret_name) | **PUT** /api/v1/tenant/apps/{installation_id}/secrets/{secret_name} | Set a secret value for an app.
*TenantsApi* | [**get_api_v1_tenants**](docs/TenantsApi.md#get_api_v1_tenants) | **GET** /api/v1/tenants | List tenants that the authenticated user has access to.
*TokensApi* | [**delete_api_v1_admin_tokenstoken_id**](docs/TokensApi.md#delete_api_v1_admin_tokenstoken_id) | **DELETE** /api/v1/admin/tokens/{token_id} | Revoke an API token.
*TokensApi* | [**get_api_v1_admin_tokens**](docs/TokensApi.md#get_api_v1_admin_tokens) | **GET** /api/v1/admin/tokens | List all API tokens for the current tenant.
*TokensApi* | [**get_api_v1_admin_tokenstoken_id**](docs/TokensApi.md#get_api_v1_admin_tokenstoken_id) | **GET** /api/v1/admin/tokens/{token_id} | Get details for a specific API token.
*TokensApi* | [**post_api_v1_admin_tokens**](docs/TokensApi.md#post_api_v1_admin_tokens) | **POST** /api/v1/admin/tokens | Generate API token for a user.
*TokensApi* | [**post_api_v1_admin_tokens_revoke_alluser_email**](docs/TokensApi.md#post_api_v1_admin_tokens_revoke_alluser_email) | **POST** /api/v1/admin/tokens/revoke-all/{user_email} | Revoke all API tokens for a specific user.
*UpdatesApi* | [**get_api_v1_workflowsworkflow_run_id_updates**](docs/UpdatesApi.md#get_api_v1_workflowsworkflow_run_id_updates) | **GET** /api/v1/workflows/{workflow_run_id}/updates | Get pending updates for a workflow.
*UpdatesApi* | [**get_api_v1_workflowsworkflow_run_id_updates_history**](docs/UpdatesApi.md#get_api_v1_workflowsworkflow_run_id_updates_history) | **GET** /api/v1/workflows/{workflow_run_id}/updates/history | Get update history for a workflow (all statuses).
*UpdatesApi* | [**post_api_v1_workflowsworkflow_run_id_updates**](docs/UpdatesApi.md#post_api_v1_workflowsworkflow_run_id_updates) | **POST** /api/v1/workflows/{workflow_run_id}/updates | Send a blocking update to a workflow.
*UsersApi* | [**delete_api_v1_usersemail**](docs/UsersApi.md#delete_api_v1_usersemail) | **DELETE** /api/v1/users/{email} | Delete a user by removing all their roles.
*UsersApi* | [**delete_api_v1_usersemail_rolesrole**](docs/UsersApi.md#delete_api_v1_usersemail_rolesrole) | **DELETE** /api/v1/users/{email}/roles/{role} | Remove a role from a user.
*UsersApi* | [**get_api_v1_users**](docs/UsersApi.md#get_api_v1_users) | **GET** /api/v1/users | List all users for the current tenant.
*UsersApi* | [**get_api_v1_usersemail**](docs/UsersApi.md#get_api_v1_usersemail) | **GET** /api/v1/users/{email} | Get detailed information about a user.
*UsersApi* | [**patch_api_v1_usersemail**](docs/UsersApi.md#patch_api_v1_usersemail) | **PATCH** /api/v1/users/{email} | Update user roles.
*UsersApi* | [**post_api_v1_users**](docs/UsersApi.md#post_api_v1_users) | **POST** /api/v1/users | Create a new user by assigning them to a role.
*UsersApi* | [**post_api_v1_usersemail_roles**](docs/UsersApi.md#post_api_v1_usersemail_roles) | **POST** /api/v1/users/{email}/roles | Assign a role to an existing user.
*WorkersApi* | [**delete_api_v1_workersworker_id**](docs/WorkersApi.md#delete_api_v1_workersworker_id) | **DELETE** /api/v1/workers/{worker_id} | Delete a worker from the registry.
*WorkersApi* | [**get_api_v1_workers**](docs/WorkersApi.md#get_api_v1_workers) | **GET** /api/v1/workers | List all registered workers.
*WorkersApi* | [**get_api_v1_workers_summary**](docs/WorkersApi.md#get_api_v1_workers_summary) | **GET** /api/v1/workers/summary | Get aggregated worker health summary.
*WorkersApi* | [**get_api_v1_workersworker_id**](docs/WorkersApi.md#get_api_v1_workersworker_id) | **GET** /api/v1/workers/{worker_id} | Get details for a specific worker.
*WorkersApi* | [**post_api_v1_workers_cleanup**](docs/WorkersApi.md#post_api_v1_workers_cleanup) | **POST** /api/v1/workers/cleanup | Mark stale workers as offline.
*WorkersApi* | [**post_api_v1_workersworker_id_drain**](docs/WorkersApi.md#post_api_v1_workersworker_id_drain) | **POST** /api/v1/workers/{worker_id}/drain | Gracefully drain a worker (finish current tasks, then stop).
*WorkersApi* | [**post_api_v1_workersworker_id_pause**](docs/WorkersApi.md#post_api_v1_workersworker_id_pause) | **POST** /api/v1/workers/{worker_id}/pause | Pause a worker (stops claiming new tasks immediately).
*WorkersApi* | [**post_api_v1_workersworker_id_resume**](docs/WorkersApi.md#post_api_v1_workersworker_id_resume) | **POST** /api/v1/workers/{worker_id}/resume | Resume a paused/draining worker.
*WorkersApi* | [**put_api_v1_workersworker_id_capacity**](docs/WorkersApi.md#put_api_v1_workersworker_id_capacity) | **PUT** /api/v1/workers/{worker_id}/capacity | Update worker capacity settings.
*WorkflowsApi* | [**get_api_v1_workflows**](docs/WorkflowsApi.md#get_api_v1_workflows) | **GET** /api/v1/workflows | List workflows with pagination and filtering.
*WorkflowsApi* | [**get_api_v1_workflowsworkflow_run_id**](docs/WorkflowsApi.md#get_api_v1_workflowsworkflow_run_id) | **GET** /api/v1/workflows/{workflow_run_id} | Get workflow details by ID.
*WorkflowsApi* | [**get_api_v1_workflowsworkflow_run_id_checkpoints**](docs/WorkflowsApi.md#get_api_v1_workflowsworkflow_run_id_checkpoints) | **GET** /api/v1/workflows/{workflow_run_id}/checkpoints | Get workflow step checkpoints.
*WorkflowsApi* | [**get_api_v1_workflowsworkflow_run_id_events**](docs/WorkflowsApi.md#get_api_v1_workflowsworkflow_run_id_events) | **GET** /api/v1/workflows/{workflow_run_id}/events | Get workflow audit log events.
*WorkflowsApi* | [**get_api_v1_workflowsworkflow_run_id_graph**](docs/WorkflowsApi.md#get_api_v1_workflowsworkflow_run_id_graph) | **GET** /api/v1/workflows/{workflow_run_id}/graph | Get workflow graph visualization in Mermaid format.
*WorkflowsApi* | [**get_api_v1_workflowsworkflow_run_id_graph_dot**](docs/WorkflowsApi.md#get_api_v1_workflowsworkflow_run_id_graph_dot) | **GET** /api/v1/workflows/{workflow_run_id}/graph/dot | Get workflow graph in DOT format with execution steps.
*WorkflowsApi* | [**get_api_v1_workflowsworkflow_run_id_locks**](docs/WorkflowsApi.md#get_api_v1_workflowsworkflow_run_id_locks) | **GET** /api/v1/workflows/{workflow_run_id}/locks | Get distributed lock history for a workflow run.
*WorkflowsApi* | [**get_api_v1_workflowsworkflow_run_id_sagas**](docs/WorkflowsApi.md#get_api_v1_workflowsworkflow_run_id_sagas) | **GET** /api/v1/workflows/{workflow_run_id}/sagas | Get saga/compensation history for a workflow run.
*WorkflowsApi* | [**post_api_v1_workflows**](docs/WorkflowsApi.md#post_api_v1_workflows) | **POST** /api/v1/workflows | Submit a new workflow for execution.
*WorkflowsApi* | [**post_api_v1_workflowsworkflow_run_id_cancel**](docs/WorkflowsApi.md#post_api_v1_workflowsworkflow_run_id_cancel) | **POST** /api/v1/workflows/{workflow_run_id}/cancel | Cancel a running workflow.
*WorkflowsApi* | [**post_api_v1_workflowsworkflow_run_id_retry**](docs/WorkflowsApi.md#post_api_v1_workflowsworkflow_run_id_retry) | **POST** /api/v1/workflows/{workflow_run_id}/retry | Retry a failed workflow from the beginning.
*DefaultApi* | [**get**](docs/DefaultApi.md#get) | **GET** / | Render homepage using Mako template with component includes.
*DefaultApi* | [**get_api_v1_auth_login**](docs/DefaultApi.md#get_api_v1_auth_login) | **GET** /api/v1/auth/login | Initiate Google OAuth2 login flow.
*DefaultApi* | [**get_api_v1_auth_logout**](docs/DefaultApi.md#get_api_v1_auth_logout) | **GET** /api/v1/auth/logout | Logout user (client-side token deletion).
*DefaultApi* | [**get_api_v1_auth_oauth**](docs/DefaultApi.md#get_api_v1_auth_oauth) | **GET** /api/v1/auth/oauth | Handle Google OAuth2 callback.
*DefaultApi* | [**get_api_v1_workflows_by_hashdefinition_hash**](docs/DefaultApi.md#get_api_v1_workflows_by_hashdefinition_hash) | **GET** /api/v1/workflows/by-hash/{definition_hash} | Get workflow definition by hash (PRIMARY identifier).
*DefaultApi* | [**get_api_v1_workflows_definitions_dsl_pythondefinition_id**](docs/DefaultApi.md#get_api_v1_workflows_definitions_dsl_pythondefinition_id) | **GET** /api/v1/workflows/definitions/dsl/python/{definition_id} | Get workflow Python DSL source only.
*DefaultApi* | [**get_api_v1_workflows_definitions_jsondefinition_id**](docs/DefaultApi.md#get_api_v1_workflows_definitions_jsondefinition_id) | **GET** /api/v1/workflows/definitions/json/{definition_id} | Get workflow JSON definition only.
*DefaultApi* | [**get_api_v1_workflows_definitionsdefinition_id**](docs/DefaultApi.md#get_api_v1_workflows_definitionsdefinition_id) | **GET** /api/v1/workflows/definitions/{definition_id} | Get workflow definition by definition_id (UUID).
*DefaultApi* | [**get_api_v1_workflows_definitionsdefinition_id_executions_grid**](docs/DefaultApi.md#get_api_v1_workflows_definitionsdefinition_id_executions_grid) | **GET** /api/v1/workflows/definitions/{definition_id}/executions/grid | Get workflow execution data in Airflow-style grid format by definition ID.
*DefaultApi* | [**get_api_v1_workflowsworkflow_name_versionsversion**](docs/DefaultApi.md#get_api_v1_workflowsworkflow_name_versionsversion) | **GET** /api/v1/workflows/{workflow_name}/versions/{version} | Get workflow definition by name and version (convenience method).
*DefaultApi* | [**get_api_v1_workflowsworkflow_run_id_stepsstep_name_checkpoints**](docs/DefaultApi.md#get_api_v1_workflowsworkflow_run_id_stepsstep_name_checkpoints) | **GET** /api/v1/workflows/{workflow_run_id}/steps/{step_name}/checkpoints | **RBAC Permission:** &#x60;view_workflows&#x60;
*DefaultApi* | [**get_favicon_ico**](docs/DefaultApi.md#get_favicon_ico) | **GET** /favicon.ico | Serve favicon.
*DefaultApi* | [**get_login**](docs/DefaultApi.md#get_login) | **GET** /login | Render the standalone login page.
*DefaultApi* | [**get_ping**](docs/DefaultApi.md#get_ping) | **GET** /ping | Basic ping endpoint.
*DefaultApi* | [**post_api_v1_auth_logout**](docs/DefaultApi.md#post_api_v1_auth_logout) | **POST** /api/v1/auth/logout | Logout user (client-side token deletion).
*DefaultApi* | [**post_api_v1_auth_verify**](docs/DefaultApi.md#post_api_v1_auth_verify) | **POST** /api/v1/auth/verify | Verify JWT token.


## Documentation For Models

 - [Details](docs/Details.md)
 - [ErrorResponseE7ebca9](docs/ErrorResponseE7ebca9.md)
 - [ErrorResponseE7ebca9ErrorDetail](docs/ErrorResponseE7ebca9ErrorDetail.md)
 - [SuccessResponseApiKeyCreateResponseE7ebca9](docs/SuccessResponseApiKeyCreateResponseE7ebca9.md)
 - [SuccessResponseApiKeyCreateResponseE7ebca9ApiKeyCreateResponse](docs/SuccessResponseApiKeyCreateResponseE7ebca9ApiKeyCreateResponse.md)
 - [SuccessResponseApiKeyListResponseE7ebca9](docs/SuccessResponseApiKeyListResponseE7ebca9.md)
 - [SuccessResponseApiKeyListResponseE7ebca9ApiKeyListResponse](docs/SuccessResponseApiKeyListResponseE7ebca9ApiKeyListResponse.md)
 - [SuccessResponseApiKeyListResponseE7ebca9ApiKeyResponse](docs/SuccessResponseApiKeyListResponseE7ebca9ApiKeyResponse.md)
 - [SuccessResponseApiKeyListResponseE7ebca9TokenStatus](docs/SuccessResponseApiKeyListResponseE7ebca9TokenStatus.md)
 - [SuccessResponseApiKeyResponseE7ebca9](docs/SuccessResponseApiKeyResponseE7ebca9.md)
 - [SuccessResponseApiKeyResponseE7ebca9ApiKeyResponse](docs/SuccessResponseApiKeyResponseE7ebca9ApiKeyResponse.md)
 - [SuccessResponseApiKeyResponseE7ebca9TokenStatus](docs/SuccessResponseApiKeyResponseE7ebca9TokenStatus.md)
 - [SuccessResponseApiKeyRevokeResponseE7ebca9](docs/SuccessResponseApiKeyRevokeResponseE7ebca9.md)
 - [SuccessResponseApiKeyRevokeResponseE7ebca9ApiKeyRevokeResponse](docs/SuccessResponseApiKeyRevokeResponseE7ebca9ApiKeyRevokeResponse.md)
 - [SuccessResponseApiKeyRotateResponseE7ebca9](docs/SuccessResponseApiKeyRotateResponseE7ebca9.md)
 - [SuccessResponseApiKeyRotateResponseE7ebca9ApiKeyRotateResponse](docs/SuccessResponseApiKeyRotateResponseE7ebca9ApiKeyRotateResponse.md)
 - [SuccessResponseE7ebca9](docs/SuccessResponseE7ebca9.md)
 - [SuccessResponseHealthCheckResponseE7ebca9](docs/SuccessResponseHealthCheckResponseE7ebca9.md)
 - [SuccessResponseHealthCheckResponseE7ebca9HealthCheckResponse](docs/SuccessResponseHealthCheckResponseE7ebca9HealthCheckResponse.md)
 - [SuccessResponseInvitationAcceptResponseE7ebca9](docs/SuccessResponseInvitationAcceptResponseE7ebca9.md)
 - [SuccessResponseInvitationAcceptResponseE7ebca9InvitationAcceptResponse](docs/SuccessResponseInvitationAcceptResponseE7ebca9InvitationAcceptResponse.md)
 - [SuccessResponseInvitationListResponseE7ebca9](docs/SuccessResponseInvitationListResponseE7ebca9.md)
 - [SuccessResponseInvitationListResponseE7ebca9InvitationListResponse](docs/SuccessResponseInvitationListResponseE7ebca9InvitationListResponse.md)
 - [SuccessResponseInvitationListResponseE7ebca9InvitationResponse](docs/SuccessResponseInvitationListResponseE7ebca9InvitationResponse.md)
 - [SuccessResponseInvitationListResponseE7ebca9InvitationStatus](docs/SuccessResponseInvitationListResponseE7ebca9InvitationStatus.md)
 - [SuccessResponseInvitationResendResponseE7ebca9](docs/SuccessResponseInvitationResendResponseE7ebca9.md)
 - [SuccessResponseInvitationResendResponseE7ebca9InvitationResendResponse](docs/SuccessResponseInvitationResendResponseE7ebca9InvitationResendResponse.md)
 - [SuccessResponseInvitationResponseE7ebca9](docs/SuccessResponseInvitationResponseE7ebca9.md)
 - [SuccessResponseInvitationResponseE7ebca9InvitationResponse](docs/SuccessResponseInvitationResponseE7ebca9InvitationResponse.md)
 - [SuccessResponseInvitationResponseE7ebca9InvitationStatus](docs/SuccessResponseInvitationResponseE7ebca9InvitationStatus.md)
 - [SuccessResponseRoleAssignResponseE7ebca9](docs/SuccessResponseRoleAssignResponseE7ebca9.md)
 - [SuccessResponseRoleAssignResponseE7ebca9RoleAssignResponse](docs/SuccessResponseRoleAssignResponseE7ebca9RoleAssignResponse.md)
 - [SuccessResponseTokenCreateResponseE7ebca9](docs/SuccessResponseTokenCreateResponseE7ebca9.md)
 - [SuccessResponseTokenCreateResponseE7ebca9TokenCreateResponse](docs/SuccessResponseTokenCreateResponseE7ebca9TokenCreateResponse.md)
 - [SuccessResponseTokenListResponseE7ebca9](docs/SuccessResponseTokenListResponseE7ebca9.md)
 - [SuccessResponseTokenListResponseE7ebca9TokenListResponse](docs/SuccessResponseTokenListResponseE7ebca9TokenListResponse.md)
 - [SuccessResponseTokenListResponseE7ebca9TokenResponse](docs/SuccessResponseTokenListResponseE7ebca9TokenResponse.md)
 - [SuccessResponseTokenListResponseE7ebca9TokenStatus](docs/SuccessResponseTokenListResponseE7ebca9TokenStatus.md)
 - [SuccessResponseTokenResponseE7ebca9](docs/SuccessResponseTokenResponseE7ebca9.md)
 - [SuccessResponseTokenResponseE7ebca9TokenResponse](docs/SuccessResponseTokenResponseE7ebca9TokenResponse.md)
 - [SuccessResponseTokenResponseE7ebca9TokenStatus](docs/SuccessResponseTokenResponseE7ebca9TokenStatus.md)
 - [SuccessResponseTokenRevokeAllResponseE7ebca9](docs/SuccessResponseTokenRevokeAllResponseE7ebca9.md)
 - [SuccessResponseTokenRevokeAllResponseE7ebca9TokenRevokeAllResponse](docs/SuccessResponseTokenRevokeAllResponseE7ebca9TokenRevokeAllResponse.md)
 - [SuccessResponseTokenRevokeResponseE7ebca9](docs/SuccessResponseTokenRevokeResponseE7ebca9.md)
 - [SuccessResponseTokenRevokeResponseE7ebca9TokenRevokeResponse](docs/SuccessResponseTokenRevokeResponseE7ebca9TokenRevokeResponse.md)
 - [SuccessResponseUserListResponseE7ebca9](docs/SuccessResponseUserListResponseE7ebca9.md)
 - [SuccessResponseUserListResponseE7ebca9UserListResponse](docs/SuccessResponseUserListResponseE7ebca9UserListResponse.md)
 - [SuccessResponseUserListResponseE7ebca9UserResponse](docs/SuccessResponseUserListResponseE7ebca9UserResponse.md)
 - [SuccessResponseUserResponseE7ebca9](docs/SuccessResponseUserResponseE7ebca9.md)
 - [SuccessResponseUserResponseE7ebca9UserResponse](docs/SuccessResponseUserResponseE7ebca9UserResponse.md)
 - [ValidationError6a07befValidationErrorElement](docs/ValidationError6a07befValidationErrorElement.md)


<a id="documentation-for-authorization"></a>
## Documentation For Authorization


Authentication schemes defined for the API:
<a id="ApiKeyAuth"></a>
### ApiKeyAuth

- **Type**: API key
- **API key parameter name**: X-API-Key
- **Location**: HTTP header

<a id="BearerAuth"></a>
### BearerAuth

- **Type**: Bearer authentication (JWT)


## Author




