from enum import Enum

class PostPublicEnvelopeGetResponse200DocumentsItemBlocksAdditionalPropertyItemType1Type(str, Enum):
    IMAGE = "image"

    def __str__(self) -> str:
        return str(self.value)
