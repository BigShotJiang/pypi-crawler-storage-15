#!/bin/sh
! grep --color=auto -r "include <assert.h>\|include <cassert>" $1
