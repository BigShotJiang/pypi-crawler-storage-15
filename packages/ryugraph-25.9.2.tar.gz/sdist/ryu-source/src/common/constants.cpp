namespace ryu {
namespace common {

const char* RYU_VERSION = RYU_CMAKE_VERSION;

}
} // namespace ryu
