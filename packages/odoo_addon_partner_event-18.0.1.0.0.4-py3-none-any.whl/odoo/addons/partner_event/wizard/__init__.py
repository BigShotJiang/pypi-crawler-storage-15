from . import base_partner_merge_automatic_wizard
from . import res_partner_register_event
