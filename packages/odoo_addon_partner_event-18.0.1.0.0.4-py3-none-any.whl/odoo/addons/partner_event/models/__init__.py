from . import event_event
from . import event_registration
from . import res_partner
