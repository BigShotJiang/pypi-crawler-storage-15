This module links partners with the events they are registered through a
smart button.

It also includes:

- Search partners by their event attendees.
- Search partners by number of events attendees.
- Search partners by number of events attended.
- Partner column is visible on registration one2many list inside the
  event.
- Action in partner tree view 'More' button, to register several
  partners to an event
- Restricts partner deletion when event attendees are linked to it.
- Onchange for partner_id removed in v16 core in Event Registration-
  including functionality here
