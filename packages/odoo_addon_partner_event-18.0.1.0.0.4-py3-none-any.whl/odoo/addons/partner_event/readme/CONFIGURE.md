There is a new option in event form view, "Create Partners in
registration". If this option is checked, when you add registrations to
this event, partners will be created automatically with name, email,
phone and mobile fields.

If partner already exists and user only fills email, name, phone and
mobile fields will be filled with partner's data.

The event registration values email, name, phone and mobile will be
changed if the related partner values are changed and the event end date
hasn't passed yet.
