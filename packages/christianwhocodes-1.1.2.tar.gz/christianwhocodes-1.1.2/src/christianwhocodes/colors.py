"""
Color definitions using the rich library.
Usage: Import these colors and use them with rich's print or Console.
"""

from enum import StrEnum

from rich.console import Console
from rich.theme import Theme


class Text(StrEnum):
    """Rich color codes for use in styled output."""

    ERROR = "error"
    WARNING = "warning"
    SUCCESS = "success"
    INFO = "info"
    DEBUG = "debug"
    HIGHLIGHT = "highlight"


theme = Theme(
    {
        Text.ERROR: "bold red",
        Text.WARNING: "bold yellow",
        Text.SUCCESS: "bold green",
        Text.INFO: "bold cyan",
        Text.DEBUG: "bold magenta",
        Text.HIGHLIGHT: "bold blue",
    }
)

console = Console(theme=theme)


def colored_print(
    text: str | list[tuple[str, str | None]],
    color: str | None = None,
    end: str = "\n",
) -> None:
    """
    Print colored text using rich.

    Args:
        text: The text to print. Can be:
            - A string (used with the color parameter)
            - A list of (text, color) tuples for multi-colored output
        color: The color/style to apply (from Theme class or rich color string)
               Only used when text is a string
        end: String appended after the text (default: newline)

    Examples:
        colored_print("Error!", Theme.ERROR)
        colored_print("Status: ", Theme.INFO, end="")
        colored_print([("Error: ", Theme.ERROR), ("File not found", Theme.WARNING)])
    """
    if isinstance(text, list):
        # Multi-colored mode: text is a list of (text, color) tuples
        output = ""
        for segment_text, segment_color in text:
            if segment_color:
                output += f"[{segment_color}]{segment_text}[/{segment_color}]"
            else:
                output += segment_text
        console.print(output, end=end)
    else:
        # Single color mode
        if color:
            console.print(f"[{color}]{text}[/{color}]", end=end)
        else:
            console.print(text, end=end)


# Example usage
if __name__ == "__main__":
    # Single color examples
    colored_print("This is an error message", Text.ERROR)
    colored_print("This is a warning message", Text.WARNING)
    colored_print("This is a success message", Text.SUCCESS)
    colored_print("This is an info message", Text.INFO)
    colored_print("This is a normal message")

    # Using end argument
    colored_print("Loading", Text.INFO, end="")
    colored_print("...", end="")
    colored_print(" Done!", Text.SUCCESS)

    # Multi-colored text in one line
    colored_print(
        [
            ("Error: ", Text.ERROR),
            ("File ", None),
            ("config.json", Text.HIGHLIGHT),
            (" not found", Text.WARNING),
        ]
    )

    colored_print(
        [
            ("Status: ", Text.INFO),
            ("OK", Text.SUCCESS),
            (" | Processed: ", None),
            ("42", Text.HIGHLIGHT),
            (" items", None),
        ]
    )
