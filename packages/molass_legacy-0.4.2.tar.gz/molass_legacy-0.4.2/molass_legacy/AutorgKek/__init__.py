import os
import sys

thisdir_ = os.path.dirname( os.path.abspath( __file__ ) )
sys.path.append( thisdir_ )
