molass\_legacy package
======================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   molass_legacy.AutorgKek
   molass_legacy.DENSS
   molass_legacy.DataStructure
   molass_legacy.Decomposer
   molass_legacy.ExcelProcess
   molass_legacy.Extrapolation
   molass_legacy.GuinierAnalyzer
   molass_legacy.InputProcess
   molass_legacy.KekLib
   molass_legacy.Microfluidics
   molass_legacy.SerialAnalyzer
   molass_legacy.Synthesizer
   molass_legacy.Trimming

Module contents
---------------

.. automodule:: molass_legacy
   :members:
   :undoc-members:
   :show-inheritance:
