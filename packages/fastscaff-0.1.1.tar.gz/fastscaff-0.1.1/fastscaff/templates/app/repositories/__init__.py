from app.repositories.user import UserRepository

__all__ = ["UserRepository"]
