from pbixtrans._version import version

__version__ = version