"""
GRZ Control CLI for GRZ administrators.
"""

__version__ = "1.4.0"
