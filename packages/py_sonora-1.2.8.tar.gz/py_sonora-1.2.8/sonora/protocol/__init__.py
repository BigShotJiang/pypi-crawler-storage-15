"""Lavalink protocol handlers."""
