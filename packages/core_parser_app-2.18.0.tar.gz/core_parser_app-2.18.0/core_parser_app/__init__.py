default_app_config = "core_parser_app.apps.CoreParserAppConfig"
