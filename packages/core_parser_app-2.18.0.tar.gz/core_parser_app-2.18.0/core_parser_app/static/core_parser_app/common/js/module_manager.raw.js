var templateModuleInsertUrl = "{% url 'core_parser_app_insert_template_module' %}";
var templateModuleDeleteUrl = "{% url 'core_parser_app_delete_template_module' %}";

