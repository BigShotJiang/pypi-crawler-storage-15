""" Rights for tests app
"""

TESTS_CONTENT_TYPE = "tests"
MOCK_DATA_STRUCTURE_ACCESS = "access_mock_data_structure"
MOCK_ANON_DATA_STRUCTURE_ACCESS = "access_mock_anon_data_structure"
