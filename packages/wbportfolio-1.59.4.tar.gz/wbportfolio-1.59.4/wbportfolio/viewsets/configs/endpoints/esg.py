from wbcore.metadata.configs.endpoints import EndpointViewConfig


class ESGMetricAggregationPortfolioPandasEndpointConfig(EndpointViewConfig):
    def get_endpoint(self, **kwargs):
        return None
