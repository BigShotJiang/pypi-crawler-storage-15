.. currentmodule:: xarray

Encoding/Decoding
=================

.. autosummary::
   :toctree: ../generated/

   decode_cf

Coder objects
-------------

.. autosummary::
   :toctree: ../generated/

   coders.CFDatetimeCoder
