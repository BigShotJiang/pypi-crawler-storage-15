.. currentmodule:: xarray

Accessors
=========

.. currentmodule:: xarray.core

.. autosummary::
   :toctree: ../generated/

   accessor_dt.DatetimeAccessor
   accessor_dt.TimedeltaAccessor
   accessor_str.StringAccessor
