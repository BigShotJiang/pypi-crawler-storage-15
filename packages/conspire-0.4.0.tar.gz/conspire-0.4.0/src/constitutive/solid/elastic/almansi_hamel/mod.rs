super::elastic!(AlmansiHamel, bulk_modulus, shear_modulus,);
