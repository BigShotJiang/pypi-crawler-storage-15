super::hyperelastic!(NeoHookean, bulk_modulus, shear_modulus,);
