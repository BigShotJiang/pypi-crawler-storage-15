super::hyperelastic!(ArrudaBoyce, bulk_modulus, shear_modulus, number_of_links,);
