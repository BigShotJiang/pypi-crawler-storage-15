super::hyperelastic!(MooneyRivlin, bulk_modulus, shear_modulus, extra_modulus,);
