super::hyperelastic!(Fung, bulk_modulus, shear_modulus, extra_modulus, exponent,);
