# Security Policy

## Reporting a Vulnerability

If there are any vulnerabilities, do not hesitate to report them, but please report them privately.
