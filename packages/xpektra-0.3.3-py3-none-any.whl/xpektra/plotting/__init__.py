import os

# Path to custom style
STYLE_PATH = os.path.join(os.path.dirname(__file__), "latex_sans_serif.mplstyle")
