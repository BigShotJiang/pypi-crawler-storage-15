# setup.py (optional compatibility)
from setuptools import setup

setup()