from .core import is_odd, is_even
