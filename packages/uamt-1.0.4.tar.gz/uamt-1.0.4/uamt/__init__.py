""" uamt """
__version__="1.0.4"
from .UAMT import *
