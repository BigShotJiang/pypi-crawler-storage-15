from ._keishis_sandbox import sum_as_str


def mysum(a: int, b: int) -> int:
    return a + b


__all__ = ["mysum", "sum_as_str"]
