"""Wrappers for bidirectional streaming integration tests.

Includes fault injection and other transparent wrappers around real implementations.
"""
