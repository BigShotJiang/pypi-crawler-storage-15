"""Integration tests for bidirectional streaming agents."""
