"""Bidirectional streaming tests."""
