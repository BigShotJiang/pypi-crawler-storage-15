"""Bidirectional streaming model tests."""
