"""Workflow runs command module."""

from .main import list_workflow_runs

__all__ = ["list_workflow_runs"]
