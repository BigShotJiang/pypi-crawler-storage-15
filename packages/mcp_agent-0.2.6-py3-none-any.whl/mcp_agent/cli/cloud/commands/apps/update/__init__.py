"""Update MCP apps command module exports."""

from .main import update_app

__all__ = ["update_app"]
