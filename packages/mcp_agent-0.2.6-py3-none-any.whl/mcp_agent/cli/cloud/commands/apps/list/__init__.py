"""MCP Agent Cloud apps list."""

from .main import list_apps

__all__ = ["list_apps"]
