"""MCP Agent Cloud configure command."""

from .main import configure_app

__all__ = ["configure_app"]
