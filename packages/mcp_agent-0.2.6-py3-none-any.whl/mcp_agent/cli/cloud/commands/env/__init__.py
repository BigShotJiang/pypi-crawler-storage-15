"""Secrets management commands for mcp-agent cloud."""

from .main import app

__all__ = ["app"]
