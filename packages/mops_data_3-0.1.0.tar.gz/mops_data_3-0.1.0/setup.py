from setuptools import setup

setup(

    name='mops_data_3',  # 自設名稱或與自定義函式相同名稱皆可

    version='0.1.0',

    py_modules=['mops_data_3'],   # mops_data_3.py  

    install_requires=[

        # List any dependencies here if needed

    ],

)