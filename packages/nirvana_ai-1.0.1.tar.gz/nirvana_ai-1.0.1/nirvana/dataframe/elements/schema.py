from typing import Mapping


class Schema:
    def __init__(self):
        pass
