from typing import Sequence


def infer_data_type(data):
    pass


class Array:
    @classmethod
    def from_data(cls, data: Sequence):
        pass
