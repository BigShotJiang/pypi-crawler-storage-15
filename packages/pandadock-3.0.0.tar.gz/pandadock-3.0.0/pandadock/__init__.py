"""
PandaDock: GPU-accelerated molecular docking software
"""

__version__ = "3.0.0"
__author__ = "Pritam Kumar Panda @Stanford University"