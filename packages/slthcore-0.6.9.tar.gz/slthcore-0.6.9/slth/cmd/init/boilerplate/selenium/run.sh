#!/bin/sh
geckodriver --host selenium --log error
