import json
from importlib.resources import files

class BibleAbbreviations:
    def __init__(self):
        try:
            path = files("bible_ref_parser.Data") / "abbreviation_to_full.json"
            with path.open("r", encoding="utf-8") as f:
                self.abbreviation_to_full = json.load(f)
        except FileNotFoundError:
            raise RuntimeError(
                "ERROR: abbreviation_to_full.json is missing from package data. "
                "Reinstall bible_ref_parser or check packaging."
            )

