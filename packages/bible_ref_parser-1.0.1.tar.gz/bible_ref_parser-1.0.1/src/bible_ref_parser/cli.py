import sys
from .reference_parser import Extract_References

def main():
    if len(sys.argv) < 2:
        print("Usage: bible-ref-parser \"Jn 3:16\"")
        sys.exit(1)

    text = " ".join(sys.argv[1:])
    parser = Extract_References()
    results = parser.Parse(text)

    for r in results:
        print(r)

if __name__ == "__main__":
    main()
