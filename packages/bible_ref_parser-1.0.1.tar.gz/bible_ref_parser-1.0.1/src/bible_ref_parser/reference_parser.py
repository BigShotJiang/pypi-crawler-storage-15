"""
Reference Parser — Design Notes (for future maintainers)

This parser became stable after two key principles:

1. SEE-SAW PRINCIPLE:
   Any normalization rule can fix one input but break another.
   Therefore:
   - Keep each stage small and predictable.
   - Do NOT overload clean_text.
   - Do NOT over-expand regex.
   - Maintain a balance so no stage becomes too powerful.

2. FIX-BUGS AT THE ROOT:
   Whenever downstream logic fails, the right fix is usually 
   one or more steps earlier in the pipeline.
   For example:
   - Normalize unicode punctuation *before* regex.
   - Insert digit/letter boundaries *before* book detection.
   - Convert dot references (23.1 → 23:1) *before* verse parsing.
   - Clean smashed patterns (Jn3:16ok → Jn3:16 ok) *before* split_refs.

   Solving problems early keeps later logic simple, stable, and 
   prevents exponential growth of special cases.

Practical advice:
- If a new weird input breaks parsing, do NOT modify the extractor first.
- Instead inspect the raw input and decide whether a 
  one-line normalization in clean_text solves it.
- Only adjust deeper regex if clean_text cannot possibly fix it.

The result is a small, stable, maintainable parser that 
generalizes well and passes all tests.
"""


import re
from .bible_abbreviations import BibleAbbreviations
from .reference_splitter import Reference_Splitter
from .clean_text import CleanText

        
class Extract_References():
    def __init__(self):
        bible_abbr = BibleAbbreviations()
        self.BOOK_MAP = bible_abbr.abbreviation_to_full  # your mapping
        BOOK_WORDS = sorted(self.BOOK_MAP.keys(), key=len, reverse=True)
        BOOK_WORDS_ESC = [re.escape(b) for b in BOOK_WORDS]
        self.BOOK_PATTERN = re.compile(
            rf"(?i)(?:{'|'.join(BOOK_WORDS_ESC)})\s?\.?\s?\d+"
        )
        self.PARSE_PATTERN = re.compile(r'(?:[,-:;\.\s\d]*)')
        self.rx = Reference_Splitter()
        self.clean = CleanText()

    def first_scan(self, text):
        """
        Returns dict: {book_string: (start_i, end_i)}
        """
        positions = []
        for m in self.BOOK_PATTERN.finditer(text):
            book = m.group().strip()
            book = text[m.start():m.end()].strip()
            positions.append((book, m.start(), m.end()))
        return positions

    def Parse(self, text):
        text = self.process_paragraph(text)
        text = self.insert_markers(text)
        text = self.clean.capitalize_mixed_case_words(text)
        text = self.clean.clean_text(text)
        ref_positions = self.first_scan(text)
        r_refs = []
        s_refs = []
        exp_refs = []
        # Iterate over the list of tuples, where each tuple is (book, start, end)
        for i, (book, start_book, end_book) in enumerate(ref_positions):
            # Window start = just after book name
            start = end_book
            # start = end_book-(len(book)+1)
            if i < len(ref_positions) - 1:
                # Access the start position of the next book using the tuple
                end = ref_positions[i + 1][1]
            else:
                end = len(text)
            window = text[start:end]

            raw_ref = self.PARSE_PATTERN.match(window.strip())
            if raw_ref:
                raw_ref = f"{book}{raw_ref.group()}"
                # clean output
                raw_ref = self.clean.small_clean(raw_ref)
                raw_ref = self.clean.capitalize_ref(raw_ref)
                # check for illegal trailers 'Ps 23-24:1' and remove them
                raw_ref = re.sub(r'(?<!:)(\b\d+-\d+):\d+', r'\1', raw_ref) # Isa 52:13–53:3 Ps 23-24:1 => 'Isa 52:13-53:3', 'Ps 23-24'
                split_refs, expanded = self.rx.expand(raw_ref)
                r_refs.append(raw_ref)
                s_refs.extend(split_refs)
                exp_refs.extend(expanded)
        return r_refs, s_refs, exp_refs

    # clean input
    def process_paragraph(self, paragraph):
        sentence = paragraph.split('\n')
        processed_words = []  # To hold the processed words
        i = 0  # Index for looping through the words
        while i < len(sentence):
            if re.match(r'^(\d+\.\s+[A-Za-z]+)', sentence[i].strip()):
                processed_words.append(f"xMARKEDx {sentence[i]}")
            else:
                processed_words.append(sentence[i])
            i += 1
        return ' '.join(processed_words)

    def insert_markers(self, paragraph):
        tokens = paragraph.split()
        result = []

        for i in range(len(tokens)):
            result.append(tokens[i])

            # If next token exists, check if current and next form the pattern
            if i + 1 < len(tokens):
                pair = tokens[i] + " " + tokens[i+1]
                if re.search(r'\.|:\d+\s+[A-Za-z]+', pair):
                    result.append("xMARKEDx")

        return " ".join(result)




