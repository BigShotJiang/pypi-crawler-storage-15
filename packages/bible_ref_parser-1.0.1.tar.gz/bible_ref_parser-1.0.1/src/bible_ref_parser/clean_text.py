import re

class CleanText:
    # -----------------------------
    # 1. Normalize punctuation
    # -----------------------------
    def normalize_punctuation(self, text: str) -> str:
        text = text.replace('：', ':')
        text = text.replace('；', ';')
        text = text.replace('–', '-')
        text = text.replace('—', '-')
        text = text.replace("\n", " ").replace("\t", " ")
        return text

    # Collapse extra spaces + fix " , "
    def normalize_whitespace(self, text: str) -> str:
        text = re.sub(r'\s{2,}', ' ', text)
        text = re.sub(r' , ', ', ', text)
        return text

    # -----------------------------
    # 2. Normalize numeric ranges
    # -----------------------------
    def normalize_numeric_ranges(self, text: str) -> str:
        # keep "12-34" intact: merge "12 - 34" → "12-34"
        text = re.sub(r'(?<=\d)\s*-\s*(?=\d)', '-', text)
        # remove unwanted spaces after semicolon
        text = re.sub(r';\s+', ';', text)
        return text

    # -----------------------------
    # 3. Dot → colon conversion
    # -----------------------------
    def convert_dot_notation(self, text: str) -> str:
        # 23.1  → 23:1
        # . 23 . 1 → 23:1
        text = re.sub(r"(\d+)\s*\.\s*(\d+)", r"\1:\2", text)

        # remove stray dot before chapter:
        # "Psalms . 23:1" → "Psalms 23:1"
        text = re.sub(r"\.\s*(\d+):", r" \1:", text)

        # Collapse leftover weird dot spacing
        text = text.replace(" . ", ".")
        text = text.replace(" .", ".")
        text = text.replace(". ", ".")
        text = text.replace("..", ".")
        return text

    # -----------------------------
    # 4. Boundary insertion rules
    # -----------------------------
    def insert_boundaries(self, text: str) -> str:
        return re.sub(
            r'(?<=[a-z])(?=[A-Z])|'       # abC → ab C
            r'(?<=\d)(?=[A-Za-z\?])|'     # 3x → 3 x
            r'(?<=[A-Za-z])(?=\d)|'       # x3 → x 3
            r'(?<=\?)(?=[A-Za-z])',       # ?x → ? x
            ' ',
            text
        )

    # =============================
    # MASTER CLEAN FUNCTION
    # =============================
    def clean_text(self, text: str) -> str:
        try:
            text = self.normalize_punctuation(text)
            text = self.normalize_whitespace(text)
            text = self.normalize_numeric_ranges(text)
            text = self.convert_dot_notation(text)
            text = self.insert_boundaries(text)
            return text.strip()
        except:
            print("WARNING clean_text error")
            return text

    # =============================
    # MASTER CLEAN OUTPUT FUNCTION
    # =============================
    # clean output or floaters/trailers
    def small_clean(self, ref):
        try:
            ref = re.sub(r'[\s,;:.]+$', '', ref)  # strip trailing punctuation
            # Keep numeric ranges like 12-34 intact
            ref = re.sub(r'(?<=\d)\s*-\s*(?=\d)', '-', ref)
            ref = re.sub(r'(?<=\d)\s*:\s*(?=\d)', ':', ref)
            ref = re.sub(r'\s*-\s*(?!\d)', '', ref)
            ref = re.sub(r'\s*;\s*(?!\d)', '', ref)
            return ref
        except Exception as e:
            print(f'error: small_clean{e}')
        return ref


    def capitalize_mixed_case_words(self, text):
        def capitalize_match(match):
            word = match.group()
            # Check if the word contains both uppercase and lowercase letters
            if any(c.islower() for c in word) and any(c.isupper() for c in word):
                return word.capitalize()
            return word
        # Regex to find words that include both uppercase and lowercase letters
        processed_text = re.sub(r'\b[a-zA-Z0-9:;,.?!\-]+\b', capitalize_match, text)
        return processed_text


    def capitalize_ref(self, ref):
        # 1) Detect (optional number) + (book letters) + (rest)
        m = re.match(r'^\s*([1-3]?)\s*([A-Za-z]+)\s*(.*)$', ref)
        if not m:
            return ref  # not a reference
        num_prefix, book, rest = m.groups()
        # 2) Capitalize book abbreviation (first letter upper, rest lower)
        book = book.capitalize()
        # 3) If prefix exists, combine as "1 Jn", else "Jn"
        if num_prefix:
            cap = f"{num_prefix} {book}"
        else:
            cap = book
        # 4) Return with the remaining chapter/verse part
        return f"{cap} {rest}".strip()

    