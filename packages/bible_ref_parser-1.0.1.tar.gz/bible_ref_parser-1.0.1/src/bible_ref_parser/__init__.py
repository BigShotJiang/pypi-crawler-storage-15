from .reference_parser import Extract_References
from .reference_splitter import Reference_Splitter
from .clean_text import CleanText

# Convenience parse() function
def parse(text: str):
    extractor = Extract_References()
    return extractor.Parse(text)

# Optional: public expand() helper
def expand(ref: str):
    splitter = Reference_Splitter()
    return splitter.expand(ref)

__all__ = [
    "Extract_References",
    "Reference_Splitter",
    "CleanText",
    "parse",
    "expand",
]
