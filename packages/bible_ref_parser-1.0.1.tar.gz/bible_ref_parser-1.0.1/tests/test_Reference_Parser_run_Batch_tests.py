
from BibleReferenceComparator import BibleReferenceComparator
from SuperValidationTests_V1 import ValidationTests
from bible_ref_parser import Extract_References


# import pytest
# from bible_ref_parser.Tests.BibleReferenceComparator import BibleReferenceComparator
# from bible_ref_parser.reference_parser import Extract_References
# from bible_ref_parser.Tests.SuperValidationTests_V1 import ValidationTests


def test_batch_parsing():
    """
    Pytest-based version of your batch parsing test.
    Each validation test now produces real pytest assertions.
    """

    cmp = BibleReferenceComparator()
    rp = Extract_References()

    total_refs = 0

    for name, test in ValidationTests.items():

        test_text = test["text"]
        expected_split = test["split"]

        r_refs, s_refs, exp_refs = rp.Parse(test_text)

        result = cmp.compare(expected_split, s_refs)

        # --- Pytest assertions ---
        assert result["missing"] == [], f"""
        TEST FAILED: {name}
        Missing: {result['missing']}
        Expected: {expected_split}
        Got: {s_refs}
        """

        assert result["extra"] == [], f"""
        TEST FAILED: {name}
        Extra refs: {result['extra']}
        Expected: {expected_split}
        Got: {s_refs}
        """

        # Track stats just like before (pytest does not display, but you may print)
        total_refs += len(r_refs)

    print("\nAll batch tests passed.")
    print("Total refs parsed:", total_refs)
    # python -m pytest bible_ref_parser/Tests -q
