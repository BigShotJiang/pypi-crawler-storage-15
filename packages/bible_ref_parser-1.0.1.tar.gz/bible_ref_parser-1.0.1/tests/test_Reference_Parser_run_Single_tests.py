
from bible_ref_parser import Extract_References

# if __name__ == "__main__":

# from bible_ref_parser.reference_parser import Extract_References


def test_single_parsing():

    text = """
        Philippians 1:15-18 15. Some indeed preach Christ even of envy and strife; and some also of good will:
        john 2 1. And I, brethren, when I came to you, 1Co 13 : 4 -7 pRoV3:5 came not with excellency of speech
        or of wisdom, gets mashed: Ps .23:1 or Ps24:1 or Ps23-24. 1. Prophets declaring unto you the testimony of God
        Mixed dot formats: Ps.25.1, Ps . 26 . 1, Ps27.1,Prophets declaring.

        Mt5:5. Mk4:2! Lk4:1? mashed: Ps .23:1 or Ps24:1 or Ps23-24.
        1. Prophets mashed Mixed dot formats: Ps.25.1, Ps . 26 . 1, Ps27.1.numbered
    """

    rp = Extract_References()
    r_refs, s_refs, exp_refs = rp.Parse(text)

    # --- Assertions ---
    # 1. Should extract at least one reference
    assert len(s_refs) > 0, "Parser failed: no references extracted from test text"

    # 2. Each split reference must contain at least a space separating book + chapter
    for ref in s_refs:
        assert " " in ref, f"Malformed reference (missing space between book and chapter): {ref}"

    # 3. Expanded refs must match count and structure
    assert len(exp_refs) == len(s_refs), (
        f"Mismatch between split and expanded refs count: "
        f"{len(s_refs)} split vs {len(exp_refs)} expanded"
    )

    # Optional: ensure expanded refs have at least book + chapter format
    for ref in exp_refs:
        assert any(ch.isdigit() for ch in ref), f"Expanded ref missing chapter number: {ref}"
