## 📘 bible-ref-parser

### **A high-accuracy Bible reference parser for Python**

`bible-ref-parser` is a production-grade tool for extracting Bible references from messy, smashed, OCR-damaged, or poorly formatted text.

It detects:

* `Jn3:16`
* `Mk2:5Jn3:16`
* `1Co 3:4,7;5:2`
* `Ps.23.1` → `Ps 23:1`
* `Isa 52:13-53:3`
* `Ro8-10`
* Multi-reference lines inside sermons, notes, or commentaries
* Dot-based formats (`Ps . 23 . 1`)
* Broken OCR (`lCoI3:4-7`)
* Completely mashed words (`StuffObad1:1InsideText`)

It outputs:

* raw references
* normalized references
* fully expanded references (book names spelled out)

---

## 🚀 Installation

```
pip install bible-ref-parser
```

Or install from a local folder:

```
pip install -e .
```

---

## 🔍 Quick Start

```python
import bible_ref_parser as br

result = br.parse("mk2:5jn3:16")
print(result)
```

Output:

```
(['Mk 2:5', 'Jn 3:16'],
 ['Mk 2:5', 'Jn 3:16'],
 ['Mark 2:5', 'John 3:16'])
```

---

## 🧱 Using the main class

```python
import bible_ref_parser as br

extractor = br.Extract_References()
refs = extractor.Parse("1Co3:4,7;5:2")
print(refs)
```

Output:

```
(['1 Co 3:4,7;5:2'],
 ['1 Co 3:4', '1 Co 3:7', '1 Co 5:2'],
 ['1 Corinthians 3:4', '1 Corinthians 3:7', '1 Corinthians 5:2'])
```

---

## 🧩 Expanding references

You can expand a single reference into all individual verses:

```python
from bible_ref_parser.reference_splitter import Reference_Splitter

splitter = Reference_Splitter()
refs = splitter.expand("Jn 3:16,17,18;4:2")
print(refs)
```

Output:

```
(['jn 3:16', 'jn 3:17', 'jn 3:18', 'jn 4:2'],
 ['John 3:16', 'John 3:17', 'John 3:18', 'John 4:2'])
```

---

## 🖥️ Command Line Usage

```
bible-ref-parser "Jn3:16"
```

Output:

```
['Jn 3:16']
['Jn 3:16']
['John 3:16']
```

---

## ✔ Features

* Extremely robust regex pipeline
* CleanText preprocessor fixes smashed words
* Dot-notation normalization
* Smart Psalm handling
* Full book-name expansions
* Handles dozens of real-world edge cases
* Used in large sermon/commentary datasets
* Fully tested (sane tests + torture tests)

---

## 📦 Included Data

* `abbreviation_to_full.json` (full Bible book map)
* Expandable verse-level parser (future search engine ready)
* OSIS-ready structure for future indexing

---

## 🧪 Testing

```
python -m pytest Tests -q
```

---

## 📄 License

MIT License.




