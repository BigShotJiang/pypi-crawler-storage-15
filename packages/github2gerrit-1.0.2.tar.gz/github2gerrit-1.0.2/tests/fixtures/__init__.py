# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: 2025 The Linux Foundation

"""
Package marker for test fixtures; presence enables mypy package resolution.
"""
