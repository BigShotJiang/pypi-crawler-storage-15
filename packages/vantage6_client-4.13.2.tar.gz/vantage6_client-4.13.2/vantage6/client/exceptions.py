class DeserializationException(Exception):
    """
    Exception raised when deserialization of algorithm input or result fails.
    """

    pass
