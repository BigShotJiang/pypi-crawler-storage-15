from . import shopfloor_menu
from . import stock_device_type
