"""CLI commands for MCP Vector Search."""
