"""Kudosx repository data files."""
