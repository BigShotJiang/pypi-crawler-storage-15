# Viame Manual Annotation Tools

::: viame2coco.viame_manual_annotations
