"""LLM File Organizer - AI-powered filesystem organization tool."""

__version__ = "0.1.0"
__app_name__ = "llm-file-organizer"
