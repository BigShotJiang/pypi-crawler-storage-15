"""Entry point for python -m llm_file_organizer."""

import sys

from .cli import main

if __name__ == "__main__":
    sys.exit(main())
