from commanderbot.core.cli import run

run()
