AUTH_PREFIX = "/auth"
USER_PREFIX = "/users"
