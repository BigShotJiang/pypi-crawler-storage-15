"""Info widget components."""

from copick_shared_ui.widgets.info.info_widget import CopickInfoWidget

__all__ = [
    "CopickInfoWidget",
]
