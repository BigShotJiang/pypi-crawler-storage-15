"""Shared widget components."""

__all__ = []
