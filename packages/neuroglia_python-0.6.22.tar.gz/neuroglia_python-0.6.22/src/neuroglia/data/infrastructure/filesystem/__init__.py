"""Filesystem repository infrastructure for the Neuroglia framework."""

from .filesystem_repository import FileSystemRepository

__all__ = ["FileSystemRepository"]
