"""vector-rag-tool: A Python CLI tool

Note: This code was generated with assistance from AI coding tools
and has been reviewed and tested by a human.
"""

__version__ = "0.1.0"
