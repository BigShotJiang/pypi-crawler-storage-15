"""Services package for vector-rag-tool.

This package contains high-level services that orchestrate various
components of the RAG system.

Note: This code was generated with assistance from AI coding tools
and has been reviewed and tested by a human.
"""
