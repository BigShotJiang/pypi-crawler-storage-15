# Arbitbot 🚀

Simple multi-exchange cryptocurrency arbitrage detector with interactive GUI.

## What It Does

Arbitbot monitors real-time prices across multiple exchanges and detects arbitrage opportunities automatically. Simply run the notebook, and an interactive GUI appears for easy configuration and monitoring.

## Installation

```bash
pip install arbitbot
```

## Quick Start

```python
from arbitbot import show_gui

# Launch GUI
show_gui()
```

The interactive GUI will appear with all controls:

- **Exchanges**: Select from 9 major exchanges
- **Cryptocurrencies**: Choose from 14+ trading pairs
- **Fees**: Adjust taker fees per exchange
- **Profit Threshold**: Set minimum profit percentage
- **Check Interval**: Set detection frequency (30s - 1hr)
- **Telegram**: Optional notifications
- **Results**: Real-time arbitrage opportunities display

## Features

- **9 Exchanges**: Binance, Bybit, OKX, KuCoin, Huobi, Gate, Kraken, Coinbase, Bitfinex
- **14+ Cryptocurrencies**: BTC, ETH, XRP, DOGE, SOL, ADA, DOT, LTC, BCH, LINK, VET, TRX, MATIC, AVAX
- **Real-time Price Fetching**: CCXT library for accurate market data
- **Customizable Fees**: Adjust per-exchange taker fees in GUI
- **Telegram Notifications**: Get alerts for detected opportunities (optional)
- **Live Results Display**: Top 10 opportunities with profit calculations

## How It Works

1. Selects exchanges and cryptocurrencies via GUI
2. Fetches current bid/ask prices from all exchanges in parallel
3. Calculates all N×(N-1) trading pair combinations per crypto
4. Applies exchange-specific fees to identify profitable arbitrage
5. Displays results in real-time table format
6. Optionally sends Telegram notifications

## Example Usage

```python
# In a Jupyter notebook cell:
from arbitbot import show_gui
show_gui()
```

This launches the interactive GUI where you can:
- Select exchanges (e.g., Binance, Bybit, OKX)
- Choose cryptocurrencies to monitor
- Set minimum profit threshold (default: 0.5%)
- Configure detection interval (default: 30 seconds)
- Enable Telegram notifications with your bot token
- Click **Start Detection** to begin monitoring

## License

MIT License
