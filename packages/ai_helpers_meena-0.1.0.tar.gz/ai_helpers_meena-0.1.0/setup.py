from setuptools import setup, find_packages

setup(
    name="ai_helpers_meena",
    version="0.0.1",
    packages=["ai_helpers_meena"],
)