::: xopt.generators.sequential.neldermead.NelderMeadGenerator
::: xopt.generators.sequential.rcds.RCDSGenerator
::: xopt.generators.sequential.extremumseeking.ExtremumSeekingGenerator
