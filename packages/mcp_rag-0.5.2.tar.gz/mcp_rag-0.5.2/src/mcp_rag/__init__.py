# MCP-RAG: Model Context Protocol RAG Service
# A low-latency RAG service based on MCP protocol

__version__ = "0.3.16"