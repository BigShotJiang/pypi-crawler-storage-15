# Copyright (c) 2024 Fernando Libedinsky
# Product: IAToolkit Enterprise
#
# IAToolkit Enterprise is commercial, proprietary software.
# Unauthorized copying, modification, distribution, or use of this software,
# via any medium, is strictly prohibited unless explicitly permitted by the
# Enterprise License Agreement provided to the customer.
#
# This file is part of the IAToolkit Enterprise Edition and may not be
# redistributed as open-source. For licensing information, refer to:
# ENTERPRISE_LICENSE

from injector import inject
from iatoolkit.services.profile_service import ProfileService
from iatoolkit.services.configuration_service import ConfigurationService
from iatoolkit.company_registry import get_company_registry
from iatoolkit.repositories.models import Company
from iatoolkit.common.session_manager import SessionManager
from iat_enterprise.common.exceptions import IatEnterpriceException

class CorporateAuthService:
    """
    Gestiona la lógica de perfiles y acceso para entornos corporativos (SSO, Portales, etc).
    """

    @inject
    def __init__(self,
                 configuration_service: ConfigurationService,
                 profile_service: ProfileService):
        self.configuration_service = configuration_service
        self.profile_service = profile_service

    def login(self, company: Company, user_identifier: str):

        # get the SSO provider configuration for this company
        sso = self.configuration_service.get_configuration(company.short_name, 'sso')
        if not sso or not sso.get('enabled'):
            raise IatEnterpriceException(
                IatEnterpriceException.ErrorType.CONFIG_ERROR,
                f"❌ Company is not configured for Single Sign On (SSO)."
            )

        # Clean whitespace from profile method name
        profile_method = sso.get('profile_method', '').strip()
        if not profile_method:
            raise IatEnterpriceException(
                IatEnterpriceException.ErrorType.CONFIG_ERROR,
                f"❌ 'profile_method' is missing in SSO configuration."
            )

        # get the company instance
        company_instance = get_company_registry().get_company_instance(company.short_name)
        if not company_instance:
            raise IatEnterpriceException(
                IatEnterpriceException.ErrorType.CONFIG_ERROR,
                f"❌ Company instance not found for '{company.short_name}'."
            )

        # Try to get the method directly instead of checking with hasattr first
        # This bypasses some proxy issues where hasattr returns False but getattr works
        try:
            method_to_call = getattr(company_instance, profile_method)
        except AttributeError:
            raise IatEnterpriceException(
                IatEnterpriceException.ErrorType.CONFIG_ERROR,
                f"❌ 'profile_method' ({profile_method}) is not available in class {type(company_instance).__name__}. "
            )

        # 1. Fetch the user profile
        user_profile = method_to_call(user_identifier)

        if not user_profile:
            raise IatEnterpriceException(
                IatEnterpriceException.ErrorType.PERMISSION,
                f"❌ Error fetching user profile for {user_identifier}."
            )

        # 2. Create the session for this user
        self.profile_service.save_user_profile(
            company=company,
            user_identifier=user_identifier,
            user_profile=user_profile
        )

        # 3. Make sure the flask session is clean
        SessionManager.clear()