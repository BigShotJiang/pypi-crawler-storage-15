# Package initialization
import os

# Force LangSmith project name to be "fwauto" at package import time
# This ensures it's set before any LangChain/LangSmith components are initialized
os.environ["LANGCHAIN_PROJECT"] = "fwauto"

# Note: Logging is now initialized lazily in CLI/nodes when first needed,
# using the actual project directory (with .fwauto/) instead of fwauto dev directory
