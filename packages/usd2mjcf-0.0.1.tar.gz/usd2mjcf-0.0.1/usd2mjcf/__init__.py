"""usd2mjcf - Convert USD to MJCF (MuJoCo XML) format."""

__version__ = "0.0.1"
