# usd2mjcf

Convert USD to MJCF (MuJoCo XML) format.

## Installation

```bash
pip install usd2mjcf
```

## Usage

```python
import usd2mjcf
```
