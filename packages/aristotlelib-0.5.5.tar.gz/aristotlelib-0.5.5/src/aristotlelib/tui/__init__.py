"""Textual-based TUI for Aristotle SDK."""

from aristotlelib.tui.app import run_tui

__all__ = ["run_tui"]
