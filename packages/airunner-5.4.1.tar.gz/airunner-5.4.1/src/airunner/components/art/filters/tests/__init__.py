"""Tests for image filters."""
