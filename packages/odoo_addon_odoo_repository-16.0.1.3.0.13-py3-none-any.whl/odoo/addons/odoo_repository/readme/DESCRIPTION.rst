Base module to host data collected from Odoo repositories.
