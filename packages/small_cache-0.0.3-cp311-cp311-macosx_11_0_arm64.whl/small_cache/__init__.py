from ._small_cache_impl import SmallCache, __doc__
