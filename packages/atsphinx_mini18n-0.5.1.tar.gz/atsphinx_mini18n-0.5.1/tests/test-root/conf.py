# noqa: D100

extensions = [
    "atsphinx.mini18n",
]
