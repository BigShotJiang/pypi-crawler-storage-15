Release update

- Changelog is https://github.com/atsphinx/mini18n/blob/v0.5.1/CHANGES.rst
