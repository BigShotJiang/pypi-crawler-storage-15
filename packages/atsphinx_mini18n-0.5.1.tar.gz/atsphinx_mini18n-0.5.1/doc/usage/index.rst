=====
Usage
=====

Please read to use ``atsphinx-mini18n`` on your documentation.

.. warning::

   This might not work with old Sphinx.

.. toctree::
   :maxdepth: 2
   :caption: Contents

   setup
   configuration
   build-style
