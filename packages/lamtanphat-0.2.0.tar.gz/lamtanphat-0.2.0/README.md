# lamtanphat

`lamtanphat` is a very simple Python demo package that provides two functions:

- `ltp()`: Prints the string `"Lâm Tấn Phát"`.
- `LTPPPP()`: Prints sample personal information, one attribute per line.

## Installation

You can install the package after building (or directly in the project directory):

```bash
pip install lamtanphat
```

## Usage

Example usage in Python:

```python
from lamtanphat import ltp, LTPPPP

ltp()       # -> prints "Lâm Tấn Phát"
LTPPPP()    # -> prints sample personal information
```
