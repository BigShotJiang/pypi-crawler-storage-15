"""
lamtanphat package
------------------

Provides two simple functions:

- ``ltp()``: Prints the string "Lâm Tấn Phát".
- ``LTPPPP()``: Prints sample personal information, one attribute per line.
"""

from __future__ import annotations

from typing import NoReturn


def ltp() -> NoReturn:
    """
    Prints the string "Lâm Tấn Phát".
    """
    print("Lâm Tấn Phát")


def LTPPPP() -> NoReturn:  # noqa: N802  # keep function name as required
    """
    Print sample personal information in English, one attribute per line.
    """
    print("Full name   : Lam Tan Phat")
    print("Role        : Full Stack Developer")
    print("Location    : Viet Nam")
    print("Website     : https://lamtanphat.io.vn/")
    print("Instagram   : https://www.instagram.com/phatlam811/")
    print("Facebook    : https://www.facebook.com/phat.lam.666536")
    print("LinkedIn    : https://www.linkedin.com/in/ltpppp/")
    print("GitHub      : https://github.com/LTPPPP")


__all__ = ["ltp", "LTPPPP"]


