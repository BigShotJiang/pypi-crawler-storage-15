| Name                   | Version   | License                 |
|------------------------|-----------|-------------------------|
| Pygments               | 2.19.2    | BSD License             |
| click                  | 8.3.1     | BSD-3-Clause            |
| fast_tsp               | 0.1.4     | MIT                     |
| joblib                 | 1.5.2     | BSD License             |
| markdown-it-py         | 4.0.0     | MIT License             |
| mdurl                  | 0.1.2     | MIT License             |
| numpy                  | 2.2.6     | BSD License             |
| opencv-python-headless | 4.12.0.88 | Apache Software License |
| rich                   | 14.2.0    | MIT License             |
| ruff                   | 0.14.6    | MIT License             |
| scikit-learn           | 1.7.2     | BSD-3-Clause            |
| scipy                  | 1.16.3    | BSD License             |
| shellingham            | 1.5.4     | ISC License (ISCL)      |
| threadpoolctl          | 3.6.0     | BSD License             |
| typer                  | 0.20.0    | MIT License             |
| typing_extensions      | 4.15.0    | PSF-2.0                 |
| video-descrambler      | 1.0.0     | BEERWARE                |
