"""Video Descrambler - Reorder scrambled video frames."""

from .video_descrambler import VideoDescrambler

__version__ = "1.0.0"

__all__ = [
    "VideoDescrambler",
]
