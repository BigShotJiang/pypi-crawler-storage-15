"""
paramspy: Smart Parameter Discovery Tool
Finds target-specific, production-used parameters from 10+ years of Wayback data.
"""

_version_ = "0.1.0"