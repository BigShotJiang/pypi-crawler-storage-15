from .server import app  # noqa
