import{_ as a,cx as s}from"./index-c2Z0I-eu.js";const c=a(s,[["__scopeId","data-v-565bc716"]]);export{c as M};
