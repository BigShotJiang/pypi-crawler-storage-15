### Test Scripts


Execute all tests using `setup.py` in the parent directory:

    python setup.py test


### Running single tests

Directly execute the scripts, e.g.


    python test_simple.py



