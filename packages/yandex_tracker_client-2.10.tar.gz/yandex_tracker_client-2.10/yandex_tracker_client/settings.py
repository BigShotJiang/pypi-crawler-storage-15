# coding: utf-8
from __future__ import unicode_literals, absolute_import


VERSION_V2 = 'v2'
