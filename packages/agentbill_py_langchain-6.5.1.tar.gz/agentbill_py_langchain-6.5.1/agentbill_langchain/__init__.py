"""AgentBill LangChain Integration

Zero-config callback handler for tracking LangChain usage in AgentBill.
"""

from .callback import AgentBillCallback

__version__ = "6.6.0"
__all__ = ["AgentBillCallback"]
