What's new-
Added browser widget Browser.AFMABE() that calls QWebEngine