class ListenerStopped(Exception):
    pass