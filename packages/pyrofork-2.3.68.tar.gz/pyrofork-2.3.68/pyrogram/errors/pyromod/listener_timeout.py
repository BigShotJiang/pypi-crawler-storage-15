class ListenerTimeout(Exception):
    pass