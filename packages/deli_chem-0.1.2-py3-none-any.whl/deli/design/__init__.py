"""init for the design module"""
