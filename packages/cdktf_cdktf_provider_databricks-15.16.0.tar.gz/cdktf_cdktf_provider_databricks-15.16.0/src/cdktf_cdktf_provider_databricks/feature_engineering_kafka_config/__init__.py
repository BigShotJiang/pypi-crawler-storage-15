r'''
# `databricks_feature_engineering_kafka_config`

Refer to the Terraform Registry for docs: [`databricks_feature_engineering_kafka_config`](https://registry.terraform.io/providers/databricks/databricks/1.99.0/docs/resources/feature_engineering_kafka_config).
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from .._jsii import *

import cdktf as _cdktf_9a9027ec
import constructs as _constructs_77d1e7e8


class FeatureEngineeringKafkaConfig(
    _cdktf_9a9027ec.TerraformResource,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktf/provider-databricks.featureEngineeringKafkaConfig.FeatureEngineeringKafkaConfig",
):
    '''Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.99.0/docs/resources/feature_engineering_kafka_config databricks_feature_engineering_kafka_config}.'''

    def __init__(
        self,
        scope: _constructs_77d1e7e8.Construct,
        id: builtins.str,
        *,
        auth_config: typing.Union["FeatureEngineeringKafkaConfigAuthConfig", typing.Dict[builtins.str, typing.Any]],
        bootstrap_servers: builtins.str,
        subscription_mode: typing.Union["FeatureEngineeringKafkaConfigSubscriptionMode", typing.Dict[builtins.str, typing.Any]],
        extra_options: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        key_schema: typing.Optional[typing.Union["FeatureEngineeringKafkaConfigKeySchema", typing.Dict[builtins.str, typing.Any]]] = None,
        value_schema: typing.Optional[typing.Union["FeatureEngineeringKafkaConfigValueSchema", typing.Dict[builtins.str, typing.Any]]] = None,
        connection: typing.Optional[typing.Union[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktf_9a9027ec.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktf_9a9027ec.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktf_9a9027ec.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktf_9a9027ec.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktf_9a9027ec.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.99.0/docs/resources/feature_engineering_kafka_config databricks_feature_engineering_kafka_config} Resource.

        :param scope: The scope in which to define this construct.
        :param id: The scoped construct ID. Must be unique amongst siblings in the same scope
        :param auth_config: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.99.0/docs/resources/feature_engineering_kafka_config#auth_config FeatureEngineeringKafkaConfig#auth_config}.
        :param bootstrap_servers: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.99.0/docs/resources/feature_engineering_kafka_config#bootstrap_servers FeatureEngineeringKafkaConfig#bootstrap_servers}.
        :param subscription_mode: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.99.0/docs/resources/feature_engineering_kafka_config#subscription_mode FeatureEngineeringKafkaConfig#subscription_mode}.
        :param extra_options: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.99.0/docs/resources/feature_engineering_kafka_config#extra_options FeatureEngineeringKafkaConfig#extra_options}.
        :param key_schema: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.99.0/docs/resources/feature_engineering_kafka_config#key_schema FeatureEngineeringKafkaConfig#key_schema}.
        :param value_schema: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.99.0/docs/resources/feature_engineering_kafka_config#value_schema FeatureEngineeringKafkaConfig#value_schema}.
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ea29833513c7480fa6b803544e76f005e33b87dcb48f3209508d4b00f914ae7d)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        config = FeatureEngineeringKafkaConfigConfig(
            auth_config=auth_config,
            bootstrap_servers=bootstrap_servers,
            subscription_mode=subscription_mode,
            extra_options=extra_options,
            key_schema=key_schema,
            value_schema=value_schema,
            connection=connection,
            count=count,
            depends_on=depends_on,
            for_each=for_each,
            lifecycle=lifecycle,
            provider=provider,
            provisioners=provisioners,
        )

        jsii.create(self.__class__, self, [scope, id, config])

    @jsii.member(jsii_name="generateConfigForImport")
    @builtins.classmethod
    def generate_config_for_import(
        cls,
        scope: _constructs_77d1e7e8.Construct,
        import_to_id: builtins.str,
        import_from_id: builtins.str,
        provider: typing.Optional[_cdktf_9a9027ec.TerraformProvider] = None,
    ) -> _cdktf_9a9027ec.ImportableResource:
        '''Generates CDKTF code for importing a FeatureEngineeringKafkaConfig resource upon running "cdktf plan ".

        :param scope: The scope in which to define this construct.
        :param import_to_id: The construct id used in the generated config for the FeatureEngineeringKafkaConfig to import.
        :param import_from_id: The id of the existing FeatureEngineeringKafkaConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.99.0/docs/resources/feature_engineering_kafka_config#import import section} in the documentation of this resource for the id to use
        :param provider: ? Optional instance of the provider where the FeatureEngineeringKafkaConfig to import is found.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__414ac851694bac83c8e46e4394b8baaea2022196e93a4d94ced9c9ad4d07e2a5)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument import_to_id", value=import_to_id, expected_type=type_hints["import_to_id"])
            check_type(argname="argument import_from_id", value=import_from_id, expected_type=type_hints["import_from_id"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
        return typing.cast(_cdktf_9a9027ec.ImportableResource, jsii.sinvoke(cls, "generateConfigForImport", [scope, import_to_id, import_from_id, provider]))

    @jsii.member(jsii_name="putAuthConfig")
    def put_auth_config(
        self,
        *,
        uc_service_credential_name: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param uc_service_credential_name: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.99.0/docs/resources/feature_engineering_kafka_config#uc_service_credential_name FeatureEngineeringKafkaConfig#uc_service_credential_name}.
        '''
        value = FeatureEngineeringKafkaConfigAuthConfig(
            uc_service_credential_name=uc_service_credential_name
        )

        return typing.cast(None, jsii.invoke(self, "putAuthConfig", [value]))

    @jsii.member(jsii_name="putKeySchema")
    def put_key_schema(
        self,
        *,
        json_schema: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param json_schema: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.99.0/docs/resources/feature_engineering_kafka_config#json_schema FeatureEngineeringKafkaConfig#json_schema}.
        '''
        value = FeatureEngineeringKafkaConfigKeySchema(json_schema=json_schema)

        return typing.cast(None, jsii.invoke(self, "putKeySchema", [value]))

    @jsii.member(jsii_name="putSubscriptionMode")
    def put_subscription_mode(
        self,
        *,
        assign: typing.Optional[builtins.str] = None,
        subscribe: typing.Optional[builtins.str] = None,
        subscribe_pattern: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param assign: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.99.0/docs/resources/feature_engineering_kafka_config#assign FeatureEngineeringKafkaConfig#assign}.
        :param subscribe: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.99.0/docs/resources/feature_engineering_kafka_config#subscribe FeatureEngineeringKafkaConfig#subscribe}.
        :param subscribe_pattern: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.99.0/docs/resources/feature_engineering_kafka_config#subscribe_pattern FeatureEngineeringKafkaConfig#subscribe_pattern}.
        '''
        value = FeatureEngineeringKafkaConfigSubscriptionMode(
            assign=assign, subscribe=subscribe, subscribe_pattern=subscribe_pattern
        )

        return typing.cast(None, jsii.invoke(self, "putSubscriptionMode", [value]))

    @jsii.member(jsii_name="putValueSchema")
    def put_value_schema(
        self,
        *,
        json_schema: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param json_schema: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.99.0/docs/resources/feature_engineering_kafka_config#json_schema FeatureEngineeringKafkaConfig#json_schema}.
        '''
        value = FeatureEngineeringKafkaConfigValueSchema(json_schema=json_schema)

        return typing.cast(None, jsii.invoke(self, "putValueSchema", [value]))

    @jsii.member(jsii_name="resetExtraOptions")
    def reset_extra_options(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetExtraOptions", []))

    @jsii.member(jsii_name="resetKeySchema")
    def reset_key_schema(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetKeySchema", []))

    @jsii.member(jsii_name="resetValueSchema")
    def reset_value_schema(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetValueSchema", []))

    @jsii.member(jsii_name="synthesizeAttributes")
    def _synthesize_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeAttributes", []))

    @jsii.member(jsii_name="synthesizeHclAttributes")
    def _synthesize_hcl_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeHclAttributes", []))

    @jsii.python.classproperty
    @jsii.member(jsii_name="tfResourceType")
    def TF_RESOURCE_TYPE(cls) -> builtins.str:
        return typing.cast(builtins.str, jsii.sget(cls, "tfResourceType"))

    @builtins.property
    @jsii.member(jsii_name="authConfig")
    def auth_config(self) -> "FeatureEngineeringKafkaConfigAuthConfigOutputReference":
        return typing.cast("FeatureEngineeringKafkaConfigAuthConfigOutputReference", jsii.get(self, "authConfig"))

    @builtins.property
    @jsii.member(jsii_name="keySchema")
    def key_schema(self) -> "FeatureEngineeringKafkaConfigKeySchemaOutputReference":
        return typing.cast("FeatureEngineeringKafkaConfigKeySchemaOutputReference", jsii.get(self, "keySchema"))

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @builtins.property
    @jsii.member(jsii_name="subscriptionMode")
    def subscription_mode(
        self,
    ) -> "FeatureEngineeringKafkaConfigSubscriptionModeOutputReference":
        return typing.cast("FeatureEngineeringKafkaConfigSubscriptionModeOutputReference", jsii.get(self, "subscriptionMode"))

    @builtins.property
    @jsii.member(jsii_name="valueSchema")
    def value_schema(self) -> "FeatureEngineeringKafkaConfigValueSchemaOutputReference":
        return typing.cast("FeatureEngineeringKafkaConfigValueSchemaOutputReference", jsii.get(self, "valueSchema"))

    @builtins.property
    @jsii.member(jsii_name="authConfigInput")
    def auth_config_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, "FeatureEngineeringKafkaConfigAuthConfig"]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, "FeatureEngineeringKafkaConfigAuthConfig"]], jsii.get(self, "authConfigInput"))

    @builtins.property
    @jsii.member(jsii_name="bootstrapServersInput")
    def bootstrap_servers_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "bootstrapServersInput"))

    @builtins.property
    @jsii.member(jsii_name="extraOptionsInput")
    def extra_options_input(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], jsii.get(self, "extraOptionsInput"))

    @builtins.property
    @jsii.member(jsii_name="keySchemaInput")
    def key_schema_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, "FeatureEngineeringKafkaConfigKeySchema"]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, "FeatureEngineeringKafkaConfigKeySchema"]], jsii.get(self, "keySchemaInput"))

    @builtins.property
    @jsii.member(jsii_name="subscriptionModeInput")
    def subscription_mode_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, "FeatureEngineeringKafkaConfigSubscriptionMode"]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, "FeatureEngineeringKafkaConfigSubscriptionMode"]], jsii.get(self, "subscriptionModeInput"))

    @builtins.property
    @jsii.member(jsii_name="valueSchemaInput")
    def value_schema_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, "FeatureEngineeringKafkaConfigValueSchema"]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, "FeatureEngineeringKafkaConfigValueSchema"]], jsii.get(self, "valueSchemaInput"))

    @builtins.property
    @jsii.member(jsii_name="bootstrapServers")
    def bootstrap_servers(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "bootstrapServers"))

    @bootstrap_servers.setter
    def bootstrap_servers(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f2c908ddae7fe1a6b9e07bdf912e34c3836bf4dfad8a6c6c8784d9fbfd793b38)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "bootstrapServers", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="extraOptions")
    def extra_options(self) -> typing.Mapping[builtins.str, builtins.str]:
        return typing.cast(typing.Mapping[builtins.str, builtins.str], jsii.get(self, "extraOptions"))

    @extra_options.setter
    def extra_options(self, value: typing.Mapping[builtins.str, builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3429683f929a3b41889a137e88f0b0612b26e460fdca83772d9566ca764e1220)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "extraOptions", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktf/provider-databricks.featureEngineeringKafkaConfig.FeatureEngineeringKafkaConfigAuthConfig",
    jsii_struct_bases=[],
    name_mapping={"uc_service_credential_name": "ucServiceCredentialName"},
)
class FeatureEngineeringKafkaConfigAuthConfig:
    def __init__(
        self,
        *,
        uc_service_credential_name: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param uc_service_credential_name: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.99.0/docs/resources/feature_engineering_kafka_config#uc_service_credential_name FeatureEngineeringKafkaConfig#uc_service_credential_name}.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c4fdac3634645cd992a42060ff5763e42a05c8740f4d8bcb3c8d98384e32060d)
            check_type(argname="argument uc_service_credential_name", value=uc_service_credential_name, expected_type=type_hints["uc_service_credential_name"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if uc_service_credential_name is not None:
            self._values["uc_service_credential_name"] = uc_service_credential_name

    @builtins.property
    def uc_service_credential_name(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.99.0/docs/resources/feature_engineering_kafka_config#uc_service_credential_name FeatureEngineeringKafkaConfig#uc_service_credential_name}.'''
        result = self._values.get("uc_service_credential_name")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "FeatureEngineeringKafkaConfigAuthConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class FeatureEngineeringKafkaConfigAuthConfigOutputReference(
    _cdktf_9a9027ec.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktf/provider-databricks.featureEngineeringKafkaConfig.FeatureEngineeringKafkaConfigAuthConfigOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0d606cde99fae673e9ea8411d8ac9c406c353f963e3b9d25c0db59611501b8fd)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetUcServiceCredentialName")
    def reset_uc_service_credential_name(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetUcServiceCredentialName", []))

    @builtins.property
    @jsii.member(jsii_name="ucServiceCredentialNameInput")
    def uc_service_credential_name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "ucServiceCredentialNameInput"))

    @builtins.property
    @jsii.member(jsii_name="ucServiceCredentialName")
    def uc_service_credential_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "ucServiceCredentialName"))

    @uc_service_credential_name.setter
    def uc_service_credential_name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__dde39372fdb3eee79c240e2a09dd93b32c440250ae315b3d63398e2098f5c800)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "ucServiceCredentialName", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, FeatureEngineeringKafkaConfigAuthConfig]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, FeatureEngineeringKafkaConfigAuthConfig]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, FeatureEngineeringKafkaConfigAuthConfig]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9ee0bc9a73f97517de299423ff19ef481cc8d4eea6cf0150468bfdc3f3f57553)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktf/provider-databricks.featureEngineeringKafkaConfig.FeatureEngineeringKafkaConfigConfig",
    jsii_struct_bases=[_cdktf_9a9027ec.TerraformMetaArguments],
    name_mapping={
        "connection": "connection",
        "count": "count",
        "depends_on": "dependsOn",
        "for_each": "forEach",
        "lifecycle": "lifecycle",
        "provider": "provider",
        "provisioners": "provisioners",
        "auth_config": "authConfig",
        "bootstrap_servers": "bootstrapServers",
        "subscription_mode": "subscriptionMode",
        "extra_options": "extraOptions",
        "key_schema": "keySchema",
        "value_schema": "valueSchema",
    },
)
class FeatureEngineeringKafkaConfigConfig(_cdktf_9a9027ec.TerraformMetaArguments):
    def __init__(
        self,
        *,
        connection: typing.Optional[typing.Union[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktf_9a9027ec.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktf_9a9027ec.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktf_9a9027ec.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktf_9a9027ec.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktf_9a9027ec.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
        auth_config: typing.Union[FeatureEngineeringKafkaConfigAuthConfig, typing.Dict[builtins.str, typing.Any]],
        bootstrap_servers: builtins.str,
        subscription_mode: typing.Union["FeatureEngineeringKafkaConfigSubscriptionMode", typing.Dict[builtins.str, typing.Any]],
        extra_options: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        key_schema: typing.Optional[typing.Union["FeatureEngineeringKafkaConfigKeySchema", typing.Dict[builtins.str, typing.Any]]] = None,
        value_schema: typing.Optional[typing.Union["FeatureEngineeringKafkaConfigValueSchema", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        :param auth_config: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.99.0/docs/resources/feature_engineering_kafka_config#auth_config FeatureEngineeringKafkaConfig#auth_config}.
        :param bootstrap_servers: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.99.0/docs/resources/feature_engineering_kafka_config#bootstrap_servers FeatureEngineeringKafkaConfig#bootstrap_servers}.
        :param subscription_mode: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.99.0/docs/resources/feature_engineering_kafka_config#subscription_mode FeatureEngineeringKafkaConfig#subscription_mode}.
        :param extra_options: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.99.0/docs/resources/feature_engineering_kafka_config#extra_options FeatureEngineeringKafkaConfig#extra_options}.
        :param key_schema: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.99.0/docs/resources/feature_engineering_kafka_config#key_schema FeatureEngineeringKafkaConfig#key_schema}.
        :param value_schema: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.99.0/docs/resources/feature_engineering_kafka_config#value_schema FeatureEngineeringKafkaConfig#value_schema}.
        '''
        if isinstance(lifecycle, dict):
            lifecycle = _cdktf_9a9027ec.TerraformResourceLifecycle(**lifecycle)
        if isinstance(auth_config, dict):
            auth_config = FeatureEngineeringKafkaConfigAuthConfig(**auth_config)
        if isinstance(subscription_mode, dict):
            subscription_mode = FeatureEngineeringKafkaConfigSubscriptionMode(**subscription_mode)
        if isinstance(key_schema, dict):
            key_schema = FeatureEngineeringKafkaConfigKeySchema(**key_schema)
        if isinstance(value_schema, dict):
            value_schema = FeatureEngineeringKafkaConfigValueSchema(**value_schema)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__307ae187db8715f242746c18c63fc8be02ceb24f47c8cd14490402abde655382)
            check_type(argname="argument connection", value=connection, expected_type=type_hints["connection"])
            check_type(argname="argument count", value=count, expected_type=type_hints["count"])
            check_type(argname="argument depends_on", value=depends_on, expected_type=type_hints["depends_on"])
            check_type(argname="argument for_each", value=for_each, expected_type=type_hints["for_each"])
            check_type(argname="argument lifecycle", value=lifecycle, expected_type=type_hints["lifecycle"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
            check_type(argname="argument provisioners", value=provisioners, expected_type=type_hints["provisioners"])
            check_type(argname="argument auth_config", value=auth_config, expected_type=type_hints["auth_config"])
            check_type(argname="argument bootstrap_servers", value=bootstrap_servers, expected_type=type_hints["bootstrap_servers"])
            check_type(argname="argument subscription_mode", value=subscription_mode, expected_type=type_hints["subscription_mode"])
            check_type(argname="argument extra_options", value=extra_options, expected_type=type_hints["extra_options"])
            check_type(argname="argument key_schema", value=key_schema, expected_type=type_hints["key_schema"])
            check_type(argname="argument value_schema", value=value_schema, expected_type=type_hints["value_schema"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "auth_config": auth_config,
            "bootstrap_servers": bootstrap_servers,
            "subscription_mode": subscription_mode,
        }
        if connection is not None:
            self._values["connection"] = connection
        if count is not None:
            self._values["count"] = count
        if depends_on is not None:
            self._values["depends_on"] = depends_on
        if for_each is not None:
            self._values["for_each"] = for_each
        if lifecycle is not None:
            self._values["lifecycle"] = lifecycle
        if provider is not None:
            self._values["provider"] = provider
        if provisioners is not None:
            self._values["provisioners"] = provisioners
        if extra_options is not None:
            self._values["extra_options"] = extra_options
        if key_schema is not None:
            self._values["key_schema"] = key_schema
        if value_schema is not None:
            self._values["value_schema"] = value_schema

    @builtins.property
    def connection(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, _cdktf_9a9027ec.WinrmProvisionerConnection]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("connection")
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, _cdktf_9a9027ec.WinrmProvisionerConnection]], result)

    @builtins.property
    def count(
        self,
    ) -> typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("count")
        return typing.cast(typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]], result)

    @builtins.property
    def depends_on(
        self,
    ) -> typing.Optional[typing.List[_cdktf_9a9027ec.ITerraformDependable]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("depends_on")
        return typing.cast(typing.Optional[typing.List[_cdktf_9a9027ec.ITerraformDependable]], result)

    @builtins.property
    def for_each(self) -> typing.Optional[_cdktf_9a9027ec.ITerraformIterator]:
        '''
        :stability: experimental
        '''
        result = self._values.get("for_each")
        return typing.cast(typing.Optional[_cdktf_9a9027ec.ITerraformIterator], result)

    @builtins.property
    def lifecycle(self) -> typing.Optional[_cdktf_9a9027ec.TerraformResourceLifecycle]:
        '''
        :stability: experimental
        '''
        result = self._values.get("lifecycle")
        return typing.cast(typing.Optional[_cdktf_9a9027ec.TerraformResourceLifecycle], result)

    @builtins.property
    def provider(self) -> typing.Optional[_cdktf_9a9027ec.TerraformProvider]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provider")
        return typing.cast(typing.Optional[_cdktf_9a9027ec.TerraformProvider], result)

    @builtins.property
    def provisioners(
        self,
    ) -> typing.Optional[typing.List[typing.Union[_cdktf_9a9027ec.FileProvisioner, _cdktf_9a9027ec.LocalExecProvisioner, _cdktf_9a9027ec.RemoteExecProvisioner]]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provisioners")
        return typing.cast(typing.Optional[typing.List[typing.Union[_cdktf_9a9027ec.FileProvisioner, _cdktf_9a9027ec.LocalExecProvisioner, _cdktf_9a9027ec.RemoteExecProvisioner]]], result)

    @builtins.property
    def auth_config(self) -> FeatureEngineeringKafkaConfigAuthConfig:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.99.0/docs/resources/feature_engineering_kafka_config#auth_config FeatureEngineeringKafkaConfig#auth_config}.'''
        result = self._values.get("auth_config")
        assert result is not None, "Required property 'auth_config' is missing"
        return typing.cast(FeatureEngineeringKafkaConfigAuthConfig, result)

    @builtins.property
    def bootstrap_servers(self) -> builtins.str:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.99.0/docs/resources/feature_engineering_kafka_config#bootstrap_servers FeatureEngineeringKafkaConfig#bootstrap_servers}.'''
        result = self._values.get("bootstrap_servers")
        assert result is not None, "Required property 'bootstrap_servers' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def subscription_mode(self) -> "FeatureEngineeringKafkaConfigSubscriptionMode":
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.99.0/docs/resources/feature_engineering_kafka_config#subscription_mode FeatureEngineeringKafkaConfig#subscription_mode}.'''
        result = self._values.get("subscription_mode")
        assert result is not None, "Required property 'subscription_mode' is missing"
        return typing.cast("FeatureEngineeringKafkaConfigSubscriptionMode", result)

    @builtins.property
    def extra_options(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.99.0/docs/resources/feature_engineering_kafka_config#extra_options FeatureEngineeringKafkaConfig#extra_options}.'''
        result = self._values.get("extra_options")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    @builtins.property
    def key_schema(self) -> typing.Optional["FeatureEngineeringKafkaConfigKeySchema"]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.99.0/docs/resources/feature_engineering_kafka_config#key_schema FeatureEngineeringKafkaConfig#key_schema}.'''
        result = self._values.get("key_schema")
        return typing.cast(typing.Optional["FeatureEngineeringKafkaConfigKeySchema"], result)

    @builtins.property
    def value_schema(
        self,
    ) -> typing.Optional["FeatureEngineeringKafkaConfigValueSchema"]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.99.0/docs/resources/feature_engineering_kafka_config#value_schema FeatureEngineeringKafkaConfig#value_schema}.'''
        result = self._values.get("value_schema")
        return typing.cast(typing.Optional["FeatureEngineeringKafkaConfigValueSchema"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "FeatureEngineeringKafkaConfigConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktf/provider-databricks.featureEngineeringKafkaConfig.FeatureEngineeringKafkaConfigKeySchema",
    jsii_struct_bases=[],
    name_mapping={"json_schema": "jsonSchema"},
)
class FeatureEngineeringKafkaConfigKeySchema:
    def __init__(self, *, json_schema: typing.Optional[builtins.str] = None) -> None:
        '''
        :param json_schema: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.99.0/docs/resources/feature_engineering_kafka_config#json_schema FeatureEngineeringKafkaConfig#json_schema}.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9a83e0b0472af17768a182c64fc7604e2e3f07e7cea4848a8ebb221e2cd03e07)
            check_type(argname="argument json_schema", value=json_schema, expected_type=type_hints["json_schema"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if json_schema is not None:
            self._values["json_schema"] = json_schema

    @builtins.property
    def json_schema(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.99.0/docs/resources/feature_engineering_kafka_config#json_schema FeatureEngineeringKafkaConfig#json_schema}.'''
        result = self._values.get("json_schema")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "FeatureEngineeringKafkaConfigKeySchema(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class FeatureEngineeringKafkaConfigKeySchemaOutputReference(
    _cdktf_9a9027ec.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktf/provider-databricks.featureEngineeringKafkaConfig.FeatureEngineeringKafkaConfigKeySchemaOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f9aa51c54fb5a06af6b7f1df24dfc4daa77ab126e92653b17418786016410ffd)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetJsonSchema")
    def reset_json_schema(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetJsonSchema", []))

    @builtins.property
    @jsii.member(jsii_name="jsonSchemaInput")
    def json_schema_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "jsonSchemaInput"))

    @builtins.property
    @jsii.member(jsii_name="jsonSchema")
    def json_schema(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "jsonSchema"))

    @json_schema.setter
    def json_schema(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ad812948aac8ecd50cf34459c8b6083dacb3fabb9be438b98b7f1e523832ac68)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "jsonSchema", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, FeatureEngineeringKafkaConfigKeySchema]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, FeatureEngineeringKafkaConfigKeySchema]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, FeatureEngineeringKafkaConfigKeySchema]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__aa11981a853d3a6c4041b3f42f38aad5ab6d08adb30ee74f86aa20c71a6bac66)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktf/provider-databricks.featureEngineeringKafkaConfig.FeatureEngineeringKafkaConfigSubscriptionMode",
    jsii_struct_bases=[],
    name_mapping={
        "assign": "assign",
        "subscribe": "subscribe",
        "subscribe_pattern": "subscribePattern",
    },
)
class FeatureEngineeringKafkaConfigSubscriptionMode:
    def __init__(
        self,
        *,
        assign: typing.Optional[builtins.str] = None,
        subscribe: typing.Optional[builtins.str] = None,
        subscribe_pattern: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param assign: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.99.0/docs/resources/feature_engineering_kafka_config#assign FeatureEngineeringKafkaConfig#assign}.
        :param subscribe: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.99.0/docs/resources/feature_engineering_kafka_config#subscribe FeatureEngineeringKafkaConfig#subscribe}.
        :param subscribe_pattern: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.99.0/docs/resources/feature_engineering_kafka_config#subscribe_pattern FeatureEngineeringKafkaConfig#subscribe_pattern}.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__907b49eba4a68bf29192905905f698a16a36bda9f9a68c5dab6b90ef85bb3cd4)
            check_type(argname="argument assign", value=assign, expected_type=type_hints["assign"])
            check_type(argname="argument subscribe", value=subscribe, expected_type=type_hints["subscribe"])
            check_type(argname="argument subscribe_pattern", value=subscribe_pattern, expected_type=type_hints["subscribe_pattern"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if assign is not None:
            self._values["assign"] = assign
        if subscribe is not None:
            self._values["subscribe"] = subscribe
        if subscribe_pattern is not None:
            self._values["subscribe_pattern"] = subscribe_pattern

    @builtins.property
    def assign(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.99.0/docs/resources/feature_engineering_kafka_config#assign FeatureEngineeringKafkaConfig#assign}.'''
        result = self._values.get("assign")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def subscribe(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.99.0/docs/resources/feature_engineering_kafka_config#subscribe FeatureEngineeringKafkaConfig#subscribe}.'''
        result = self._values.get("subscribe")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def subscribe_pattern(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.99.0/docs/resources/feature_engineering_kafka_config#subscribe_pattern FeatureEngineeringKafkaConfig#subscribe_pattern}.'''
        result = self._values.get("subscribe_pattern")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "FeatureEngineeringKafkaConfigSubscriptionMode(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class FeatureEngineeringKafkaConfigSubscriptionModeOutputReference(
    _cdktf_9a9027ec.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktf/provider-databricks.featureEngineeringKafkaConfig.FeatureEngineeringKafkaConfigSubscriptionModeOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5e55fc76c21e4ea7af9ce245915849cb1100a8ea42618788a039e34a2fbdadad)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetAssign")
    def reset_assign(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAssign", []))

    @jsii.member(jsii_name="resetSubscribe")
    def reset_subscribe(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSubscribe", []))

    @jsii.member(jsii_name="resetSubscribePattern")
    def reset_subscribe_pattern(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSubscribePattern", []))

    @builtins.property
    @jsii.member(jsii_name="assignInput")
    def assign_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "assignInput"))

    @builtins.property
    @jsii.member(jsii_name="subscribeInput")
    def subscribe_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "subscribeInput"))

    @builtins.property
    @jsii.member(jsii_name="subscribePatternInput")
    def subscribe_pattern_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "subscribePatternInput"))

    @builtins.property
    @jsii.member(jsii_name="assign")
    def assign(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "assign"))

    @assign.setter
    def assign(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cb0f1fd97aa0e8ff82e5e500343ebc85e527f3e45ea1f737fd2890ccb75597fd)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "assign", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="subscribe")
    def subscribe(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "subscribe"))

    @subscribe.setter
    def subscribe(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8ef1b5cbc891c37629c9d877fdc5e1952a8048de340bbbf764be7d896ac82941)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "subscribe", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="subscribePattern")
    def subscribe_pattern(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "subscribePattern"))

    @subscribe_pattern.setter
    def subscribe_pattern(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__51430da935b8be1fd6c1200a37d3e1640277107413a71e27af377a3be0a5c5c4)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "subscribePattern", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, FeatureEngineeringKafkaConfigSubscriptionMode]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, FeatureEngineeringKafkaConfigSubscriptionMode]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, FeatureEngineeringKafkaConfigSubscriptionMode]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d3ed27f8f97dfe65020506314990e8a08a11e36bf03a3755621615a4a133d10c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktf/provider-databricks.featureEngineeringKafkaConfig.FeatureEngineeringKafkaConfigValueSchema",
    jsii_struct_bases=[],
    name_mapping={"json_schema": "jsonSchema"},
)
class FeatureEngineeringKafkaConfigValueSchema:
    def __init__(self, *, json_schema: typing.Optional[builtins.str] = None) -> None:
        '''
        :param json_schema: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.99.0/docs/resources/feature_engineering_kafka_config#json_schema FeatureEngineeringKafkaConfig#json_schema}.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4c825d985a074565eff9409274c6c9129a33326a4a7375a13e154f573e6bf04f)
            check_type(argname="argument json_schema", value=json_schema, expected_type=type_hints["json_schema"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if json_schema is not None:
            self._values["json_schema"] = json_schema

    @builtins.property
    def json_schema(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.99.0/docs/resources/feature_engineering_kafka_config#json_schema FeatureEngineeringKafkaConfig#json_schema}.'''
        result = self._values.get("json_schema")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "FeatureEngineeringKafkaConfigValueSchema(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class FeatureEngineeringKafkaConfigValueSchemaOutputReference(
    _cdktf_9a9027ec.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktf/provider-databricks.featureEngineeringKafkaConfig.FeatureEngineeringKafkaConfigValueSchemaOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__45f7bb5c19cbf0331101682f3e7e1bf00099c7da4effe4d5c1c1654fa526e435)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetJsonSchema")
    def reset_json_schema(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetJsonSchema", []))

    @builtins.property
    @jsii.member(jsii_name="jsonSchemaInput")
    def json_schema_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "jsonSchemaInput"))

    @builtins.property
    @jsii.member(jsii_name="jsonSchema")
    def json_schema(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "jsonSchema"))

    @json_schema.setter
    def json_schema(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__11611fbb9c37c0d472b4b2cd872a8020d9ba5b267dcff8ef78a36e0d308c71f2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "jsonSchema", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, FeatureEngineeringKafkaConfigValueSchema]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, FeatureEngineeringKafkaConfigValueSchema]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, FeatureEngineeringKafkaConfigValueSchema]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__386c218ad0ba4b7e6a54b32a6034fa1366add67d518f5f351234a676ea907168)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


__all__ = [
    "FeatureEngineeringKafkaConfig",
    "FeatureEngineeringKafkaConfigAuthConfig",
    "FeatureEngineeringKafkaConfigAuthConfigOutputReference",
    "FeatureEngineeringKafkaConfigConfig",
    "FeatureEngineeringKafkaConfigKeySchema",
    "FeatureEngineeringKafkaConfigKeySchemaOutputReference",
    "FeatureEngineeringKafkaConfigSubscriptionMode",
    "FeatureEngineeringKafkaConfigSubscriptionModeOutputReference",
    "FeatureEngineeringKafkaConfigValueSchema",
    "FeatureEngineeringKafkaConfigValueSchemaOutputReference",
]

publication.publish()

def _typecheckingstub__ea29833513c7480fa6b803544e76f005e33b87dcb48f3209508d4b00f914ae7d(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    auth_config: typing.Union[FeatureEngineeringKafkaConfigAuthConfig, typing.Dict[builtins.str, typing.Any]],
    bootstrap_servers: builtins.str,
    subscription_mode: typing.Union[FeatureEngineeringKafkaConfigSubscriptionMode, typing.Dict[builtins.str, typing.Any]],
    extra_options: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    key_schema: typing.Optional[typing.Union[FeatureEngineeringKafkaConfigKeySchema, typing.Dict[builtins.str, typing.Any]]] = None,
    value_schema: typing.Optional[typing.Union[FeatureEngineeringKafkaConfigValueSchema, typing.Dict[builtins.str, typing.Any]]] = None,
    connection: typing.Optional[typing.Union[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktf_9a9027ec.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktf_9a9027ec.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktf_9a9027ec.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktf_9a9027ec.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktf_9a9027ec.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__414ac851694bac83c8e46e4394b8baaea2022196e93a4d94ced9c9ad4d07e2a5(
    scope: _constructs_77d1e7e8.Construct,
    import_to_id: builtins.str,
    import_from_id: builtins.str,
    provider: typing.Optional[_cdktf_9a9027ec.TerraformProvider] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f2c908ddae7fe1a6b9e07bdf912e34c3836bf4dfad8a6c6c8784d9fbfd793b38(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3429683f929a3b41889a137e88f0b0612b26e460fdca83772d9566ca764e1220(
    value: typing.Mapping[builtins.str, builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c4fdac3634645cd992a42060ff5763e42a05c8740f4d8bcb3c8d98384e32060d(
    *,
    uc_service_credential_name: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0d606cde99fae673e9ea8411d8ac9c406c353f963e3b9d25c0db59611501b8fd(
    terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dde39372fdb3eee79c240e2a09dd93b32c440250ae315b3d63398e2098f5c800(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9ee0bc9a73f97517de299423ff19ef481cc8d4eea6cf0150468bfdc3f3f57553(
    value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, FeatureEngineeringKafkaConfigAuthConfig]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__307ae187db8715f242746c18c63fc8be02ceb24f47c8cd14490402abde655382(
    *,
    connection: typing.Optional[typing.Union[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktf_9a9027ec.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktf_9a9027ec.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktf_9a9027ec.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktf_9a9027ec.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktf_9a9027ec.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    auth_config: typing.Union[FeatureEngineeringKafkaConfigAuthConfig, typing.Dict[builtins.str, typing.Any]],
    bootstrap_servers: builtins.str,
    subscription_mode: typing.Union[FeatureEngineeringKafkaConfigSubscriptionMode, typing.Dict[builtins.str, typing.Any]],
    extra_options: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    key_schema: typing.Optional[typing.Union[FeatureEngineeringKafkaConfigKeySchema, typing.Dict[builtins.str, typing.Any]]] = None,
    value_schema: typing.Optional[typing.Union[FeatureEngineeringKafkaConfigValueSchema, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9a83e0b0472af17768a182c64fc7604e2e3f07e7cea4848a8ebb221e2cd03e07(
    *,
    json_schema: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f9aa51c54fb5a06af6b7f1df24dfc4daa77ab126e92653b17418786016410ffd(
    terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ad812948aac8ecd50cf34459c8b6083dacb3fabb9be438b98b7f1e523832ac68(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__aa11981a853d3a6c4041b3f42f38aad5ab6d08adb30ee74f86aa20c71a6bac66(
    value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, FeatureEngineeringKafkaConfigKeySchema]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__907b49eba4a68bf29192905905f698a16a36bda9f9a68c5dab6b90ef85bb3cd4(
    *,
    assign: typing.Optional[builtins.str] = None,
    subscribe: typing.Optional[builtins.str] = None,
    subscribe_pattern: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5e55fc76c21e4ea7af9ce245915849cb1100a8ea42618788a039e34a2fbdadad(
    terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cb0f1fd97aa0e8ff82e5e500343ebc85e527f3e45ea1f737fd2890ccb75597fd(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8ef1b5cbc891c37629c9d877fdc5e1952a8048de340bbbf764be7d896ac82941(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__51430da935b8be1fd6c1200a37d3e1640277107413a71e27af377a3be0a5c5c4(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d3ed27f8f97dfe65020506314990e8a08a11e36bf03a3755621615a4a133d10c(
    value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, FeatureEngineeringKafkaConfigSubscriptionMode]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4c825d985a074565eff9409274c6c9129a33326a4a7375a13e154f573e6bf04f(
    *,
    json_schema: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__45f7bb5c19cbf0331101682f3e7e1bf00099c7da4effe4d5c1c1654fa526e435(
    terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__11611fbb9c37c0d472b4b2cd872a8020d9ba5b267dcff8ef78a36e0d308c71f2(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__386c218ad0ba4b7e6a54b32a6034fa1366add67d518f5f351234a676ea907168(
    value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, FeatureEngineeringKafkaConfigValueSchema]],
) -> None:
    """Type checking stubs"""
    pass
