from setuptools import setup

setup(
    name='csv-optimizer-jasonwang',  # This must be unique on PyPI
    version='0.1.0',
    description='A memory-efficient CSV analyzer using Python Generators',
    author='Jason Wang',
    author_email='jasonhearlte@gmail.com', # You can leave this dummy or put yours
    py_modules=['optimizer'],    # This includes your optimizer.py
    install_requires=[],
)