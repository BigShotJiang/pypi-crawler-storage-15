import csv
import tracemalloc
import time

def analyze_csv_stream(filepath):
    """
    Analyzes a CSV file using a generator to minimize memory usage.
    Returns a dictionary of department averages.
    """
    print(f"--- optimizing processing for: {filepath} ---")
    tracemalloc.start()
    start_time = time.time()
    
    dept_totals = {}
    dept_counts = {}

    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                # Basic error handling for malformed rows
                if 'department' not in row or 'salary' not in row:
                    continue
                    
                dept = row['department']
                try:
                    salary = int(row['salary'])
                except ValueError:
                    continue
                
                if dept not in dept_totals:
                    dept_totals[dept] = 0
                    dept_counts[dept] = 0
                    
                dept_totals[dept] += salary
                dept_counts[dept] += 1
                
        results = {}
        for dept in dept_totals:
            avg = dept_totals[dept] / dept_counts[dept]
            results[dept] = avg
            print(f"{dept}: ${avg:,.2f}")

        current, peak = tracemalloc.get_traced_memory()
        tracemalloc.stop()
        
        print(f"Time: {time.time() - start_time:.4f}s")
        print(f"Peak Memory: {peak / 10**6:.2f} MB")
        
        return results

    except FileNotFoundError:
        print(f"Error: File {filepath} not found.")
        return {}