"""fd-mcp: MCP server for fast file search using fd."""
