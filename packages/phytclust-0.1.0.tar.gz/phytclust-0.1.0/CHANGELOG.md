# Changelog

All notable changes to _PhytClust_ will be documented in this file.

The format follows [Keep a Changelog](https://keepachangelog.com/)
and the project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

### Added

### Changed

### Fixed

## [0.1.0] – (add date)

### Added
