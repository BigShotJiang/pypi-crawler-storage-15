from .useDict import AdDict

__all__ = [
    "useDict",
]