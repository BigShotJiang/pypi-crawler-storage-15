"""Package marker for scaffold resources."""
