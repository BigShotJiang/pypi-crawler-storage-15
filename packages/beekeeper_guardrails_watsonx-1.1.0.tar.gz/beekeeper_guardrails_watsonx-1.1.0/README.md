# Beekeeper guardrails extension - watsonx

## Installation 

```bash
pip install beekeeper-guardrails-watsonx
```
