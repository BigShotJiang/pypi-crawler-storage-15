Add GS1 barcode support to Shopfloor.

Based on <https://biip.readthedocs.io/>

This module allows to use the biip library to interpret a scanned GS1
barcode and return the corresponding Odoo record for Shopfloor find
method.
