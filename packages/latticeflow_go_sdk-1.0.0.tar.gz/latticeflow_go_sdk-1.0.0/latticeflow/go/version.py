__version__ = 'standard'
git_version = '17a9467dcfa22d2b026d1ce05ae3a8330283dd84'
