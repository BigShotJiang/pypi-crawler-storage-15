from setuptools import setup, find_packages

setup(
    name="Suryaansh",
    version="0.0.1",
    description="the is my read me",
    author="ULTRON",
    packages=find_packages(),
    python_requires=">=3.6",
)
