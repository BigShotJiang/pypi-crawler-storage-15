# FOR SALE

A simple package that prints "happy holidays" when imported.

## Installation

```bash
pip install pak-name
```

## Usage

```python
import pak-name
```
