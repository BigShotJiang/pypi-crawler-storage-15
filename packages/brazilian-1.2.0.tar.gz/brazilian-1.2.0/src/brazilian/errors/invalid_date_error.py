class InvalidDateError(ValueError):
    pass