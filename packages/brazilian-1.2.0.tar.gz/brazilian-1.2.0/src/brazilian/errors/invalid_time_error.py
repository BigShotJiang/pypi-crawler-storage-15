class InvalidTimeError(ValueError):
    pass