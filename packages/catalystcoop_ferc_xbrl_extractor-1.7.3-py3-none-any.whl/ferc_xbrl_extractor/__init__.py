"""Extract data from XBRL filings."""

import logging

logging.getLogger(__name__).addHandler(logging.NullHandler())
