# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "courier"
__version__ = "7.1.1"  # x-release-please-version
