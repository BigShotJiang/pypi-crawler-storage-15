# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .base_check import BaseCheck

__all__ = ["Check"]


class Check(BaseCheck):
    updated: int
