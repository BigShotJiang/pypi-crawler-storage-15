"""
Riyaaaaaaaaaaa - A cute package with Konkani love messages
"""

from .love import KonkaniLove, get_random_message, get_all_messages

__version__ = "1.0.0"
__author__ = "Your Love"

__all__ = ["KonkaniLove", "get_random_message", "get_all_messages"]

