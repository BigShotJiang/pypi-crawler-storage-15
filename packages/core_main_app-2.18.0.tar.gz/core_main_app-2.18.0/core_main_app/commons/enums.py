""" Type of WebPages
"""

WEB_PAGE_TYPES = {
    "login": 3,
}
