"""Regular expressions used in the core
"""

NOT_EMPTY_OR_WHITESPACES = r".*\S.*"
