""" Core main app package
"""

default_app_config = "core_main_app.apps.InitApp"
