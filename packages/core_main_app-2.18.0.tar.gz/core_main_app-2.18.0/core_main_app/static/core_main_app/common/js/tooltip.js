$(document).ready(function(){
    // Boostrap 4: init tooltips
    $('[data-toggle="tooltip"]').tooltip()
    // Bootstrap 5: init tooltips
    $('[data-bs-toggle="tooltip"]').tooltip()
});