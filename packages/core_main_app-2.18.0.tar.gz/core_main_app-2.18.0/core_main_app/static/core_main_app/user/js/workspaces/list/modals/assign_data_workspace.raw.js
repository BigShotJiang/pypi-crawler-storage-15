var changeWorkspaceUrl = "{% url 'core_main_change_workspace' %}";
var assignWorkspaceUrl = "{% url 'core_main_assign_data_workspace' %}";
var administration = "{{ data.administration}}";