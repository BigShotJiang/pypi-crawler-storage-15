var editUserRightFormsUrl = "{% url 'core_main_edit_rights_users_form' %}";
var addUserToWorkspaceUrl = "{% url 'core_main_add_user_right_to_workspace' %}";