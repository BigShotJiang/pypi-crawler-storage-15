var switchRightUrl = "{% url 'core_main_switch_right' %}";
var action_read = "{{data.action_read}}";
var action_write = "{{data.action_write}}";