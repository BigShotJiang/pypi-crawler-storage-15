var changeDataDisplayUrl = "{% url 'core_main_add_change_data_display' %}";
var dataId = dataId || "{{ data.data.id }}";