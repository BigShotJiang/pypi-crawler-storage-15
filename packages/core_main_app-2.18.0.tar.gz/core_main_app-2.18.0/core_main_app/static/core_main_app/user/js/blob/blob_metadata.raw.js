var blobMetadataFormUrl = "{% url 'core_main_blob_metadata_form' %}";
var addMetadataToBlobUrl = "{% url 'core_main_blob_add_metadata' %}";
var removeMetadataFromBlobUrl = "{% url 'core_main_blob_remove_metadata' %}";