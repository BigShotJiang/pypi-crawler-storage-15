""" Constants for the queries
"""

VISIBILITY_OPTION = "visibility"
VISIBILITY_USER = "user"
VISIBILITY_ALL = "all"
VISIBILITY_PUBLIC = "public"
