""" Custom admin site for the Blob Module model
"""

from core_main_app.components.abstract_processing_module.admin_site import (
    AbstractProcessingModuleAdmin,
)


class BlobProcessingModuleAdmin(AbstractProcessingModuleAdmin):
    pass
