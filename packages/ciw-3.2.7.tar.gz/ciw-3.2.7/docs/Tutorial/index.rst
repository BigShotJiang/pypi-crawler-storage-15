Tutorials
=========

Tutorial I is all about Getting Started, and will cover what is simulation and why we simulate.
The other tutorials are shorter and will cover some of the other core features of the library.
It covers networks of queues, the routing matrix, blocking, and multiple classes of customer.

Contents:

.. toctree::
   :maxdepth: 2
   
   GettingStarted/index.rst
   tutorial_ii.rst
   tutorial_iii.rst
   tutorial_iv.rst