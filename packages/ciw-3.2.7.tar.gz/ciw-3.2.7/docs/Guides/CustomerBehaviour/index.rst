Customer Behaviour
==================

Contents:

.. toctree::
   :maxdepth: 2

   baulking.rst
   reneging.rst
   jockeying.rst
