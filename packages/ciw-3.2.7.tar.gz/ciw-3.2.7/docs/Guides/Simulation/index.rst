Simulation
==========

Contents:

.. toctree::
   :maxdepth: 2

   seed.rst
   sim_maxtime.rst
   sim_numcusts.rst
   pause_restart.rst
   results.rst
   progressbar.rst
   parallel_process.rst
   exact.rst
