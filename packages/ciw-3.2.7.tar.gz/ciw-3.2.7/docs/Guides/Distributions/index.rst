Distributions
=============

Contents:

.. toctree::
   :maxdepth: 2

   set_distributions.rst
   phasetype.rst
   combining_distributions.rst
   summary_stats.rst
   time_dependent.rst
