.. _contributing:

-----------------
How to Contribute
-----------------

.. include:: ../../CONTRIBUTING.rst