==============
Installing Ciw
==============

The simplest way to install Ciw is::

    $ pip install ciw


However, if you would like to install it from source::

    $ git clone https://github.com/CiwPython/Ciw.git
    $ cd Ciw
    $ pip install -r requirements.txt
    $ python setup.py install

