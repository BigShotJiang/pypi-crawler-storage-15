Background
==========

Contents:

.. toctree::
   :maxdepth: 2
   
   simulationpractice.rst
   mechanisms.rst
   kendall.rst
   other.rst
   references.rst