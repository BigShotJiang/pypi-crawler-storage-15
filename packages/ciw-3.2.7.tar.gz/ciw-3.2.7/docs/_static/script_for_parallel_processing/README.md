This directory contains a script for carrying out parallel processing with ciw.

This is referred to in `./docs/Guides/parallel_process.rst`.

This script is shown in the docs but is also tested as part of the CI.
