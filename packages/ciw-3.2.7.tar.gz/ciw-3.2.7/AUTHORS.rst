Contributors
------------

Ciw has been developed by the following contributors:

+ `Geraint Palmer <https://github.com/geraintpalmer/>`_
+ `Vincent Knight <https://github.com/drvinceknight/>`_
+ `Paul Harper <https://sites.google.com/site/profpaulharper/home>`_
+ `Lieke Hölscher <https://github.com/Lieke19/>`_
+ `Sam Luen-English <https://github.com/sluenenglish/>`_
+ `Alex Carney <https://github.com/alcarney/>`_
+ `Adam Johnson <https://github.com/adamchainz/>`_
+ `Nikoleta Glynatsi <https://github.com/Nikoleta-v3/>`_
+ `caipirginka <https://github.com/caipirginka>`_
+ `Emma Aspland <https://github.com/EmmaAspland>`_
+ `Henry Wilde <https://github.com/daffidwilde>`_
+ `timlathy <https://github.com/timlathy>`_
+ `Michalis Panayides <https://github.com/11michalis11>`_
+ `Jorge Martín Pérez <https://github.com/MartinPJorge/>`_
+ `KernelA <https://github.com/KernelA>`_
+ `Matthew Howells <https://github.com/MHowells>`_
+ `Galen Seilis <https://github.com/galenseilis>`_