"""Loghandler tests."""

import pytest


@pytest.mark.usefixtures("table_creator")
class TestLoghandler(object):
    """Loghandler tests."""

    pass
