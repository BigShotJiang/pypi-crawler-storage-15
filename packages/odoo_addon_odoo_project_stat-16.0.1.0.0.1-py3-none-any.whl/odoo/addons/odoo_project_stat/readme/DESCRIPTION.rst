This module allows to generate and render some stats about your Odoo projects.
