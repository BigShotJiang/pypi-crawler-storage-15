from html.parser import HTMLParser
from typing import List
from urllib.request import Request, urlopen

import pandas as pd


class HTMLTableParser(HTMLParser):
    """Parser to extract tables from HTML."""

    def __init__(self) -> None:
        super().__init__()
        self.tables: List[List[List[str]]] = []
        self.current_table: List[List[str]] = []
        self.current_row: List[str] = []
        self.current_cell: List[str] = []
        self.in_table = False
        self.in_row = False
        self.in_cell = False

    def handle_starttag(self, tag, attrs):
        if tag == "table":
            self.in_table = True
            self.current_table = []
        elif tag == "tr" and self.in_table:
            self.in_row = True
            self.current_row = []
        elif tag in ("td", "th") and self.in_row:
            self.in_cell = True
            self.current_cell = []

    def handle_endtag(self, tag):
        if tag == "table" and self.in_table:
            if self.current_table:
                self.tables.append(self.current_table)
            self.in_table = False
            self.current_table = []
        elif tag == "tr" and self.in_row:
            if self.current_row:
                self.current_table.append(self.current_row)
            self.in_row = False
            self.current_row = []
        elif tag in ("td", "th") and self.in_cell:
            cell_text = "".join(self.current_cell).strip()
            self.current_row.append(cell_text)
            self.in_cell = False
            self.current_cell = []

    def handle_data(self, data):
        if self.in_cell:
            self.current_cell.append(data)


def parse_html_tables(url: str, timeout: int = 30) -> List[pd.DataFrame]:
    """Parse HTML tables from a URL and return list of DataFrames."""
    # Add headers to avoid being blocked as a bot
    req = Request(url, headers={'User-Agent': 'Mozilla/5.0'})

    with urlopen(req, timeout=timeout) as response:
        html = response.read().decode('utf-8')

    parser = HTMLTableParser()
    parser.feed(html)

    dataframes = []
    for table in parser.tables:
        if not table:
            continue
        # First row as header
        df = pd.DataFrame(table[1:], columns=table[0])
        dataframes.append(df)

    return dataframes
