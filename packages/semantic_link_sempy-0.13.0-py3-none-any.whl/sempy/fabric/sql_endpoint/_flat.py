from typing import TYPE_CHECKING, Literal, Optional, Union
from uuid import UUID

from ..._utils._log import log
from .._cache import _get_or_create_workspace_client
from .._credentials import with_credential
from .._flat import resolve_item_id

if TYPE_CHECKING:
    import pandas as pd
    from azure.core.credentials import TokenCredential


@log
@with_credential
def list_sql_endpoints(
    workspace: Optional[Union[str, UUID]] = None,
    credential: Optional["TokenCredential"] = None
) -> "pd.DataFrame":
    """
    List all SQL endpoints in the specified workspace.

    .. note::
        This function wraps the Fabric REST API `Items - List SQL Endpoints <https://learn.microsoft.com/en-us/rest/api/fabric/sqlendpoint/items/list-sql-endpoints>`__.

    Parameters
    ----------
    workspace : str or uuid.UUID, default=None
        The Fabric workspace name or UUID object containing the workspace ID. Defaults to None
        which resolves to the workspace of the attached lakehouse
        or if no lakehouse attached, resolves to the workspace of the notebook.
    credential : TokenCredential, default=None
        The credential for token acquisition. Must be an instance of
        `azure.core.credentials.TokenCredential <https://learn.microsoft.com/en-us/azure/developer/python/sdk/authentication/overview>`_.
        If None, the default credential will be used.

    Returns
    -------
    pandas.DataFrame
        A pandas dataframe showing the list of SQL endpoints in the specified workspace.
    """
    return _get_or_create_workspace_client(workspace=workspace).list_sql_endpoints()


@log
@with_credential
def get_sql_endpoint_id(warehouse: Union[str, UUID],
                        warehouse_type: Literal["Lakehouse", "MirroredDatabase"],
                        *,
                        workspace: Optional[Union[str, UUID]] = None,
                        credential: Optional["TokenCredential"] = None) -> str:
    """
    Get the SQL endpoint ID of the specified warehouse.

    Parameters
    ----------
    warehouse : str or uuid.UUID, default=None
        The name or ID of the warehouse. Mutually exclusive with `sql_endpoint_id`.
    warehouse_type : Literal["Lakehouse", "MirroredDatabase"], default=None
        The type of the warehouse. Must be provided if `warehouse` is provided. Mutually exclusive with `sql_endpoint_id`.
    workspace : str or uuid.UUID, default=None
        The Fabric workspace name or UUID object containing the workspace ID. Defaults to None
        which resolves to the workspace of the attached lakehouse
        or if no lakehouse attached, resolves to the workspace of the notebook.
    credential : TokenCredential, default=None
        The credential for token acquisition. Must be an instance of
        `azure.core.credentials.TokenCredential <https://learn.microsoft.com/en-us/azure/developer/python/sdk/authentication/overview>`_.
        If None, the default credential will be used.

    Returns
    -------
    str
        The SQL endpoint ID of the specified warehouse.
    """
    warehouse_id = resolve_item_id(warehouse, warehouse_type, workspace=workspace)
    return _get_or_create_workspace_client(workspace=workspace).get_sql_endpoint_id(
        warehouse_id, warehouse_type
    )


@log
@with_credential
def get_sql_endpoint_connection_string(
    warehouse: Optional[Union[str, UUID]] = None,
    warehouse_type: Optional[Literal["Lakehouse", "MirroredDatabase"]] = None,
    sql_endpoint_id: Optional[Union[str, UUID]] = None,
    *,
    workspace: Optional[Union[str, UUID]] = None,
    guest_tenant_id: Optional[str] = None,
    private_link_type: Optional[str] = None,
    credential: Optional["TokenCredential"] = None
) -> str:
    """
    Get the SQL endpoint connection string of the specified warehouse.

    .. note::
        This function wraps the Fabric REST API `Items - Get Connection String <https://learn.microsoft.com/en-us/rest/api/fabric/sqlendpoint/items/get-connection-string>`__.

    Parameters
    ----------
    warehouse : str or uuid.UUID, default=None
        The name or ID of the warehouse. Mutually exclusive with `sql_endpoint_id`.
    warehouse_type : Literal["Lakehouse", "MirroredDatabase"], default=None
        The type of the warehouse. Must be provided if `warehouse` is provided. Mutually exclusive with `sql_endpoint_id`.
    sql_endpoint_id : str or uuid.UUID, default=None
        The SQL endpoint ID. Mutually exclusive with `warehouse` and `warehouse_type`.
    workspace : str or uuid.UUID, default=None
        The Fabric workspace name or UUID object containing the workspace ID. Defaults to None
        which resolves to the workspace of the attached lakehouse
        or if no lakehouse attached, resolves to the workspace of the notebook.
    guest_tenant_id : str, default=None
        The guest tenant ID to use for cross-tenant access scenarios.
    private_link_type : str, default=None
        The private link type to use for the connection string.
    credential : TokenCredential, default=None
        The credential for token acquisition. Must be an instance of
        `azure.core.credentials.TokenCredential <https://learn.microsoft.com/en-us/azure/developer/python/sdk/authentication/overview>`_.
        If None, the default credential will be used.

    Returns
    -------
    str
        The SQL endpoint connection string of the specified warehouse.
    """
    sql_endpoint_id = _validate_and_get_sql_endpoint_id(warehouse, warehouse_type, sql_endpoint_id, workspace=workspace)

    return _get_or_create_workspace_client(workspace=workspace) \
        .get_sql_endpoint_connection_string(
            sql_endpoint_id,
            guest_tenant_id=guest_tenant_id,
            private_link_type=private_link_type
        )


@log
@with_credential
def refresh_sql_endpoint_metadata(
    warehouse: Optional[Union[str, UUID]] = None,
    warehouse_type: Optional[Literal["Lakehouse", "MirroredDatabase"]] = None,
    sql_endpoint_id: Optional[Union[str, UUID]] = None,
    *,
    workspace: Optional[Union[str, UUID]] = None,
    timeout_unit: Literal["Seconds", "Minutes", "Hours", "Days"] = "Minutes",
    timeout_value: int = 15,
    credential: Optional["TokenCredential"] = None
) -> "pd.DataFrame":
    """
    Refresh the metadata of a SQL endpoint.

    .. note::
        This is a wrapper function for `Items - Refresh Sql Endpoint Metadata <https://learn.microsoft.com/rest/api/fabric/sqlendpoint/items/refresh-sql-endpoint-metadata>`_.

    Parameters
    ----------
    warehouse : str or uuid.UUID, default=None
        The name or ID of the warehouse. Mutually exclusive with `sql_endpoint_id`.
    warehouse_type : Literal["Lakehouse", "MirroredDatabase"], default=None
        The type of the warehouse. Must be provided if `warehouse` is provided. Mutually exclusive with `sql_endpoint_id`.
    sql_endpoint_id : str or uuid.UUID, default=None
        The SQL endpoint ID. Mutually exclusive with `warehouse` and `warehouse_type`.
    workspace : str or uuid.UUID, default=None
        The Fabric workspace name or ID.
        Defaults to None which resolves to the workspace of the attached lakehouse
        or if no lakehouse attached, resolves to the workspace of the notebook.
    timeout_unit : Literal["Seconds", "Minutes", "Hours", "Days"], default="Minutes"
        The unit of time for the request duration before timing out. Additional duration types may be added over time.
    timeout_value : int, default=15
        The number of time units in the request duration.
    credential : TokenCredential, default=None
        The credential for token acquisition. Must be an instance of
        `azure.core.credentials.TokenCredential <https://learn.microsoft.com/en-us/azure/developer/python/sdk/authentication/overview>`_.
        If None, the default credential will be used.

    Returns
    -------
    pandas.DataFrame
        A pandas dataframe showing the status of the metadata refresh operation.
    """
    sql_endpoint_id = _validate_and_get_sql_endpoint_id(warehouse, warehouse_type, sql_endpoint_id, workspace=workspace)

    normalized_unit = timeout_unit.lower().capitalize()
    if normalized_unit not in {"Seconds", "Minutes", "Hours", "Days"}:
        raise TypeError("Invalid timeout_unit. Must be 'Seconds', 'Minutes', 'Hours', or 'Days'.")

    max_values = {
        "Seconds": 86400,
        "Minutes": 1440,
        "Hours": 24,
        "Days": 1,
    }

    if timeout_value > max_values[normalized_unit]:
        raise ValueError(
            f"timeout_value cannot exceed {max_values[normalized_unit]} when timeout_unit is '{normalized_unit}'."
        )

    return _get_or_create_workspace_client(workspace=workspace).refresh_sql_endpoint_metadata(
        sql_endpoint_id,
        timeout_unit=normalized_unit,
        timeout_value=timeout_value
    )


def _validate_and_get_sql_endpoint_id(
    warehouse: Optional[Union[str, UUID]],
    warehouse_type: Optional[Literal["Lakehouse", "MirroredDatabase"]],
    sql_endpoint_id: Optional[Union[str, UUID]],
    workspace: Optional[Union[str, UUID]] = None
) -> str:

    if int(sql_endpoint_id is not None) + int(warehouse is not None and warehouse_type is not None) != 1:
        raise TypeError("Either `sql_endpoint_id` or both `warehouse` and `warehouse_type` must be provided.")

    if sql_endpoint_id is not None:
        return str(sql_endpoint_id)

    if warehouse_type not in {"Lakehouse", "MirroredDatabase"}:
        raise TypeError("Invalid warehouse type. Must be 'Lakehouse' or 'MirroredDatabase'.")

    workspace_client = _get_or_create_workspace_client(workspace=workspace)
    warehouse_id = workspace_client.resolve_item_id(str(warehouse), warehouse_type)

    return workspace_client.get_sql_endpoint_id(warehouse_id, str(warehouse_type))
