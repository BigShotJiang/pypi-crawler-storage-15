import os
import warnings
from typing import TYPE_CHECKING, List, Literal, Optional, Union
from uuid import UUID

import pandas as pd
from tqdm import tqdm

from ..._utils._log import log
from .._cache import _get_fabric_rest_api, _get_or_create_workspace_client
from .._credentials import with_credential
from .._deltalake import get_delta_table_uri, vacuum_delta_table
from .._environment import _on_spark
from ._utils import (extend_table_stats, get_directlake_guardrails_for_sku,
                     resolve_lakehouse_id_internal)

if TYPE_CHECKING:
    from azure.core.credentials import TokenCredential


@log
@with_credential
def create_lakehouse(display_name: str,
                     description: Optional[str] = None,
                     max_attempts: int = 10,
                     workspace: Optional[Union[str, UUID]] = None,
                     folder: Optional[Union[str, os.PathLike, UUID]] = None,
                     enable_schema: bool = False,
                     credential: Optional["TokenCredential"] = None) -> str:
    """
    Create a lakehouse in the specified workspace.

    Parameters
    ----------
    display_name : str
        The display name of the lakehouse.
    description : str, default=None
        The optional description of the lakehouse.
    max_attempts : int, default=10
        Maximum number of retries to wait for creation of the notebook.
    workspace : str or uuid.UUID, default=None
        The Fabric workspace name or UUID object containing the workspace ID. Defaults to None
        which resolves to the workspace of the attached lakehouse
        or if no lakehouse attached, resolves to the workspace of the notebook.
    folder : str, os.PathLike, or uuid.UUID, default=None
        The Fabric folder path, folder ID, or UUID object containing the folder ID to create the lakehouse.
        Defaults to None which creates the lakehouse under the workspace root.
        ***Experimental***: This parameter is experimental and may change in future versions.
    enable_schema : bool, default=False
        If True, the notebook will be created with schema enabled.
    credential : TokenCredential, default=None
        The credential for token acquisition. Must be an instance of
        `azure.core.credentials.TokenCredential <https://learn.microsoft.com/en-us/azure/developer/python/sdk/authentication/overview>`_.
        If None, the default credential will be used.

    Returns
    -------
    str
        The id of lakehouse.
    """
    workspace_client = _get_or_create_workspace_client(workspace=workspace)
    folder_id = workspace_client.resolve_folder_id(folder) if folder else None
    return workspace_client.create_lakehouse(display_name, description, max_attempts, folder_id=folder_id,
                                             enable_schema=enable_schema)


@log
@with_credential
def delete_lakehouse(
    lakehouse: Optional[Union[str, UUID]] = None,
    workspace: Optional[Union[str, UUID]] = None,
    credential: Optional["TokenCredential"] = None
) -> None:
    """
    Delete a lakehouse in the specified workspace.

    Parameters
    ----------
    lakehouse : str or uuid.UUID, default=None
        The Fabric lakehouse name or UUID object containing the lakehouse ID.
        Defaults to None which resolves to the lakehouse of the attached lakehouse
        or if no lakehouse attached, raises an error.
    workspace : str or uuid.UUID, default=None
        The Fabric workspace name or UUID object containing the workspace ID.
        If None, defaults to the workspace of the attached lakehouse
        or if no lakehouse attached, resolves to the workspace of the notebook.
    credential : TokenCredential, default=None
        The credential for token acquisition. Must be an instance of
        `azure.core.credentials.TokenCredential <https://learn.microsoft.com/en-us/azure/developer/python/sdk/authentication/overview>`_.
        If None, the default credential will be used.
    """
    lakehouse_id = resolve_lakehouse_id_internal(lakehouse=lakehouse, workspace=workspace)
    _get_or_create_workspace_client(workspace=workspace).delete_item(lakehouse_id)


@log
@with_credential
def resolve_lakehouse_name(
    lakehouse: Optional[Union[str, UUID]] = None,
    workspace: Optional[Union[str, UUID]] = None,
    credential: Optional["TokenCredential"] = None
) -> str:
    """
    Resolve the name of a lakehouse in the specified workspace.

    Parameters
    ----------
    lakehouse : str or uuid.UUID, default=None
        The Fabric lakehouse name or UUID object containing the lakehouse ID.
        Defaults to None which resolves to the lakehouse of the attached lakehouse
        or if no lakehouse attached, raises an error.
    workspace : str or uuid.UUID, default=None
        The Fabric workspace name or UUID object containing the workspace ID.
        If None, defaults to the workspace of the attached lakehouse
        or if no lakehouse attached, resolves to the workspace of the notebook.
    credential : TokenCredential, default=None
        The credential for token acquisition. Must be an instance of
        `azure.core.credentials.TokenCredential <https://learn.microsoft.com/en-us/azure/developer/python/sdk/authentication/overview>`_.
        If None, the default credential will be used.

    Returns
    -------
    str
        The resolved lakehouse name.
    """
    lakehouse_id = resolve_lakehouse_id_internal(lakehouse=lakehouse, workspace=workspace)
    return _get_or_create_workspace_client(workspace=workspace).resolve_item_name(lakehouse_id, "Lakehouse")


@log
@with_credential
def resolve_lakehouse_id(
    lakehouse: Optional[Union[str, UUID]] = None,
    workspace: Optional[Union[str, UUID]] = None,
    credential: Optional["TokenCredential"] = None
) -> str:
    """
    Resolve the ID of a lakehouse in the specified workspace.

    Parameters
    ----------
    lakehouse : str or uuid.UUID, default=None
        The Fabric lakehouse name or UUID object containing the lakehouse ID.
        Defaults to None which resolves to the lakehouse of the attached lakehouse
        or if no lakehouse attached, raises an error.
    workspace : str or uuid.UUID, default=None
        The Fabric workspace name or UUID object containing the workspace ID.
        If None, defaults to the workspace of the attached lakehouse
        or if no lakehouse attached, resolves to the workspace of the notebook.
    credential : TokenCredential, default=None
        The credential for token acquisition. Must be an instance of
        `azure.core.credentials.TokenCredential <https://learn.microsoft.com/en-us/azure/developer/python/sdk/authentication/overview>`_.
        If None, the default credential will be used.

    Returns
    -------
    str
        The resolved lakehouse ID.
    """
    return resolve_lakehouse_id_internal(lakehouse=lakehouse, workspace=workspace)


@log
@with_credential
def list_lakehouse_tables(
    lakehouse: Optional[Union[str, UUID]] = None,
    workspace: Optional[Union[str, UUID]] = None,
    extended: bool = False,
    count_rows: bool = False,
    extend_method: Optional[Literal["spark", "python"]] = None,
    credential: Optional["TokenCredential"] = None
) -> pd.DataFrame:
    """
    List all tables in a lakehouse and their properties.

    This is a wrapper function for `Tables - List Tables <https://learn.microsoft.com/en-us/rest/api/fabric/lakehouse/tables/list-tables>`__.

    Parameters
    ----------
    lakehouse : str or uuid.UUID, default=None
        The Fabric lakehouse name or UUID object containing the lakehouse ID.
        Defaults to None which resolves to the lakehouse of the attached lakehouse
        or if no lakehouse attached, raises an error.
    workspace : str or uuid.UUID, default=None
        The Fabric workspace name or UUID object containing the workspace ID.
        If None, defaults to the workspace of the attached lakehouse
        or if no lakehouse attached, resolves to the workspace of the notebook.
    extended : bool, default=False
        Obtains additional columns relevant to the size of each table.
    count_rows : bool, default=False
        Obtains a row count for each lakehouse table.
    extend_method : "spark" or "python", default=None
        The method to use for extending table statistics when `extended=True`.
        - "spark": Uses ``delta-spark`` for operations.
        - "python": Uses ``deltalake-rs`` for operations.
        - None: Defaults to "spark" when running in a Spark environment; otherwise defaults to "python".
    credential : TokenCredential, default=None
        The credential for token acquisition. Must be an instance of
        `azure.core.credentials.TokenCredential <https://learn.microsoft.com/en-us/azure/developer/python/sdk/authentication/overview>`_.
        If None, the default credential will be used.

    Returns
    -------
    pandas.DataFrame
        DataFrame with one row per table containing the table properties.
    """
    method: Literal["spark", "python"] = extend_method or ("spark" if _on_spark() else "python")
    lakehouse_id = resolve_lakehouse_id_internal(lakehouse=lakehouse, workspace=workspace)
    workspace_client = _get_or_create_workspace_client(workspace=workspace)
    workspace_id = workspace_client.get_workspace_id()
    df = workspace_client.list_lakehouse_tables(lakehouse_id)

    if not extended:
        return df

    # Define a function to get file statistics for each table
    def get_table_stats(row: pd.Series) -> pd.Series:
        table_name = row["Name"]

        if row["Type"].lower() != "managed" or row["Format"].lower() != "delta":
            # Use empty table URI to skip statistics for non-managed delta tables
            table_uri = ""
        else:
            table_uri = get_delta_table_uri(table_name, workspace_id=workspace_id, warehouse_id=lakehouse_id)

        record = extend_table_stats(table_uri, count_rows, method=method)

        return pd.Series(record)

    # Apply the function to each row and concatenate the results
    extended_cols = df.apply(get_table_stats, axis=1)
    df = pd.concat([df, extended_cols], axis=1)

    # Add guardrail columns
    sku_size = _get_fabric_rest_api().get_sku_size(workspace_id)
    guardrail = get_directlake_guardrails_for_sku(sku_size)

    col_name = guardrail.columns[0]
    df["SKU"] = guardrail[col_name].iloc[0]
    df["Parquet File Guardrail"] = guardrail["Parquet files per table"].iloc[0]
    df["Row Group Guardrail"] = guardrail["Row groups per table"].iloc[0]
    df["Row Count Guardrail"] = guardrail["Rows per table (millions)"].iloc[0] * 1_000_000
    df["Parquet File Guardrail Hit"] = df["Files"] > df["Parquet File Guardrail"]
    df["Row Group Guardrail Hit"] = df["Row Groups"] > df["Row Group Guardrail"]

    if count_rows:
        df["Row Count"] = df["Row Count"].astype("Int64")
        df["Row Count Guardrail Hit"] = df["Row Count"] > df["Row Count Guardrail"]

    return df


@log
@with_credential
def vacuum_lakehouse_tables(
    tables: Optional[Union[str, List[str]]] = None,
    lakehouse: Optional[Union[str, UUID]] = None,
    workspace: Optional[Union[str, UUID]] = None,
    retention_hours: Optional[float] = None,
    method: Optional[Literal["spark", "python"]] = None,
    credential: Optional["TokenCredential"] = None
):
    """
    Run the `VACUUM <https://docs.delta.io/latest/delta-utility.html#remove-files-no-longer-referenced-by-a-delta-table>`_ function over the specified lakehouse tables.

    Parameters
    ----------
    tables : str or List[str], default=None
        The table(s) to vacuum. If no tables are specified, all tables in the lakehouse will be vacuumed.
    lakehouse : str or uuid.UUID, default=None
        The Fabric lakehouse name or ID.
        Defaults to None which resolves to the lakehouse attached to the notebook.
    workspace : str or uuid.UUID, default=None
        The Fabric workspace name or ID used by the lakehouse.
        Defaults to None which resolves to the workspace of the attached lakehouse
        or if no lakehouse attached, resolves to the workspace of the notebook.
    retention_hours : float, default=None
        The number of hours to retain historical versions of Delta table files.
        Files older than this retention period will be deleted during the vacuum operation.
        If not specified, the default retention period configured for the Delta table will be used.
        The default retention period is 168 hours (7 days) unless manually configured via table properties.
    method : "spark" or "python", default=None
        The method to use for vacuuming Delta tables:
        - "spark": Uses ``delta-spark`` for operations.
        - "python": Uses ``deltalake-rs`` for operations.
        - None: Defaults to "spark" when running in a Spark environment; otherwise defaults to "python".
    credential : TokenCredential, default=None
        The credential for token acquisition. Must be an instance of
        `azure.core.credentials.TokenCredential <https://learn.microsoft.com/en-us/azure/developer/python/sdk/authentication/overview>`_.
        If None, the default credential will be used.
    """
    vacuum_method: Literal["spark", "python"] = method or ("spark" if _on_spark() else "python")
    lakehouse_id = resolve_lakehouse_id_internal(lakehouse=lakehouse, workspace=workspace)
    df = _get_or_create_workspace_client(workspace=workspace).list_lakehouse_tables(lakehouse_id)

    df_delta = df[df["Format"] == "delta"]

    if isinstance(tables, str):
        tables = [tables]

    df_tables = df_delta[df_delta["Name"].isin(tables)] if tables else df_delta
    df_tables.reset_index(drop=True, inplace=True)

    total = len(df_tables)
    for idx, r in (bar := tqdm(df_tables.iterrows(), total=total, bar_format="{desc}")):
        table_name = r["Name"]
        path = r["Location"]
        bar.set_description(f"Vacuuming the '{table_name}' table ({idx}/{total})...")
        try:
            vacuum_delta_table(path, retention_hours, vacuum_method)
        except Exception as e:
            engine = "delta-spark" if vacuum_method == "spark" else "deltalake-rs"
            warnings.warn(f"Skipped vacuuming table '{table_name}' using {engine}: {e}",
                          UserWarning)
