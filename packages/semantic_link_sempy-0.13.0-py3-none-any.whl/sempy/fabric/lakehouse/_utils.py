import warnings
from typing import TYPE_CHECKING, Dict, Literal, Optional, Tuple, Union, cast
from uuid import UUID

import pandas as pd

from ..._utils._html import parse_html_tables
from .._cache import _get_or_create_workspace_client
from .._deltalake import read_delta_table
from .._environment import get_lakehouse_id

if TYPE_CHECKING:
    import delta
    import deltalake


# Cache for successfully fetched guardrails data
_guardrails_cache: Optional[Tuple[Tuple[str, ...], ...]] = None


def _fetch_directlake_guardrails() -> Tuple[Tuple[str, ...], ...]:
    """
    Fetch and cache Direct Lake guardrails table from Microsoft Learn.
    Returns a tuple of tuples for caching compatibility.

    On error or timeout, does not cache the failure state to allow retry on next call.
    """
    global _guardrails_cache

    # Return cached data if available
    if _guardrails_cache is not None:
        return _guardrails_cache

    # Fetch from URL (may raise exceptions - don't cache on error)
    url = "https://learn.microsoft.com/power-bi/enterprise/directlake-overview"
    tables = parse_html_tables(url)

    for df in tables:
        first_column_name = df.columns[0]
        if first_column_name.startswith("Fabric"):
            df[first_column_name] = df[first_column_name].str.split("/")
            df = df.explode(first_column_name, ignore_index=True)
            # Convert to tuple of tuples for caching
            result = tuple(tuple(row) for row in [df.columns.tolist()] + df.values.tolist())
            # Cache successful result
            _guardrails_cache = result
            return result

    # No matching table found - cache empty result to avoid repeated failures
    _guardrails_cache = ()
    return ()


def resolve_lakehouse_id_internal(lakehouse: Optional[Union[str, UUID]] = None,
                                  workspace: Optional[Union[str, UUID]] = None) -> str:
    """
    This helper function is for internal use to distinguish from the user interface function to avoid the
    telemetry noise.
    """
    lakehouse_id: str
    if lakehouse is None:
        lakehouse_id = get_lakehouse_id()
        if not lakehouse_id:
            raise ValueError("Cannot resolve a lakehouse. Please input a valid lakehouse or make sure a lakehouse is "
                             "attached to the notebook.")
    else:
        lakehouse_id = _get_or_create_workspace_client(workspace=workspace).resolve_item_id(str(lakehouse), "Lakehouse")

    return lakehouse_id


def extend_table_stats(table_uri: str, count_rows: bool, method: Literal["spark", "python"] = "python") -> Dict[str, Optional[int]]:
    import pyarrow.parquet as pq

    stat: Dict[str, Optional[int]] = {
        "Table Size": None,
        "Files": None,
        "Row Groups": None
    }

    if count_rows:
        stat["Row Count"] = None

    if not table_uri or not table_uri.startswith("abfs:") and not table_uri.startswith("abfss:"):
        return stat

    if method == "spark":
        try:
            delta_table = cast("delta.DeltaTable", read_delta_table(table_uri=table_uri, method="spark"))

            # Calculate table size and file count
            table_details = delta_table.detail().collect()[0].asDict()
            total_size = table_details.get("sizeInBytes", 0)
            file_count = table_details.get("numFiles", 0)
            stat["Table Size"] = total_size
            stat["Files"] = file_count

            # Calculate row groups by reading parquet files
            input_files = delta_table.toDF().inputFiles()
            num_rowgroups = 0
            for parquet_file_path in input_files:
                try:
                    parquet_file = pq.ParquetFile(parquet_file_path)
                    num_rowgroups += parquet_file.num_row_groups
                except Exception:
                    # Skip files that cannot be read
                    pass
            stat["Row Groups"] = num_rowgroups

            # Count rows
            if count_rows:
                row_count = delta_table.toDF().count()
                stat["Row Count"] = row_count

        except Exception as e:
            warnings.warn(f"Skipped generating table statistics from '{table_uri}' using delta-spark: {e}",
                          UserWarning)
    else:
        try:
            # Read delta table using deltalake-rs
            dt = cast("deltalake.DeltaTable", read_delta_table(table_uri=table_uri, method="python"))
            df_table_files = dt.get_add_actions(flatten=True).to_pandas()

            # Calculate table size and file count
            total_size = df_table_files["size_bytes"].sum() if not df_table_files.empty else 0
            file_count = len(df_table_files)
            stat["Table Size"] = total_size
            stat["Files"] = file_count

            # Calculate row groups by reading parquet files from delta table
            num_rowgroups = 0
            for file_path in df_table_files["path"].tolist():
                try:
                    # Use delta table's filesystem to read the parquet file
                    parquet_file = pq.ParquetFile(dt.to_pyarrow_dataset().filesystem.open_input_file(file_path))
                    num_rowgroups += parquet_file.num_row_groups
                except Exception:
                    # Skip files that cannot be read
                    pass
            stat["Row Groups"] = num_rowgroups

            # Count rows
            if count_rows:
                row_count = dt.to_pyarrow_table().num_rows
                stat["Row Count"] = row_count

        except Exception as e:
            warnings.warn(f"Skipped generating table statistics from '{table_uri}' using deltalake-rs: {e}",
                          UserWarning)

    return stat


def get_directlake_guardrails_for_sku(sku_size: str) -> pd.DataFrame:
    """
    Get Direct Lake guardrails for a specific SKU size.

    Parameters
    ----------
    sku_size : str
        The Fabric/Power BI SKU size (e.g., "F2", "F4", "P1").

    Returns
    -------
    pd.DataFrame
        DataFrame containing the guardrails for the specified SKU.

    Raises
    ------
    ValueError
        If unable to fetch guardrails data from the URL.
    Exception
        If the URL request times out or fails (allows retry on next call).
    """
    # Fetch data (may raise exceptions on network errors - not cached)
    try:
        cached_data = _fetch_directlake_guardrails()
    except Exception as e:
        # Let exceptions propagate without caching the error state
        raise RuntimeError(f"Failed to fetch Direct Lake guardrails: {e}") from e

    if not cached_data:
        raise ValueError("Unable to fetch Direct Lake guardrails data from the source")

    # Convert back to DataFrame
    columns = list(cached_data[0])
    data = [list(row) for row in cached_data[1:]]
    df = pd.DataFrame(data, columns=columns)

    # Filter by SKU size
    col_name = df.columns[0]
    filtered_df = df[df[col_name] == sku_size].copy()

    # Convert guardrail columns to int
    selected_columns = [
        "Parquet files per table",
        "Row groups per table",
        "Rows per table (millions)"
    ]

    for col in selected_columns:
        if col in filtered_df.columns:
            # Remove commas and convert to int (e.g., "1,000" -> 1000)
            filtered_df[col] = filtered_df[col].str.replace(",", "", regex=False).astype(int)

    return filtered_df[selected_columns]
