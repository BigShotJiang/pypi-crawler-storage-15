import datetime
import time
import warnings
from contextlib import nullcontext
from typing import (TYPE_CHECKING, Callable, List, Optional, TypeVar, Union,
                    cast)
from uuid import UUID

import ipywidgets as widgets
import numpy as np
import pandas as pd
from IPython.display import HTML, display

from .._cache import _get_or_create_workspace_client
from .._client._connection_mode import ConnectionMode
from .._trace._trace import Trace
from .._trace._trace_connection import TraceConnection
from .._utils import print_verbose

if TYPE_CHECKING:
    from contextlib import AbstractContextManager

    from .._client import DatasetRestClient, DatasetXmlaClient
    from .._client._refresh_execution_details import RefreshExecutionDetails


T = TypeVar('T')


def refresh_dataset_async(
    dataset: Union[str, UUID],
    workspace: Optional[Union[str, UUID]] = None,
    refresh_type: str = "automatic",
    max_parallelism: int = 10,
    commit_mode: str = "transactional",
    retry_count: int = 0,
    objects: Optional[List] = None,
    apply_refresh_policy: bool = True,
    effective_date: datetime.date = datetime.date.today(),
    verbose: int = 0,
) -> str:
    """
    Asynchronously refresh a dataset.

    Parameters
    ----------
    dataset : Union[str, UUID]
        The dataset identifier (name or UUID).
    workspace : Union[str, UUID], default=None
        The workspace identifier (name or UUID), by default None.
    refresh_type : str, default="automatic"
        The type of refresh to perform.
    max_parallelism : int, default=10
        The maximum number of parallel operations during the refresh.
    commit_mode : str, default="transactional"
        The commit mode for the refresh operation.
    retry_count : int, default=0
        The number of retry attempts for failed refresh operations.
    objects : List, default=None
        Specific objects to refresh within the dataset.
    apply_refresh_policy : bool, default=True
        Whether to apply the dataset's refresh policy.
    effective_date : datetime.date, default=datetime.date.today()
        The effective date for the refresh operation.
    verbose : int, default=0
        Verbosity level for logging.

    Returns
    -------
    str
        The refresh request ID.
    """
    client = cast(
        "DatasetRestClient",
        _get_or_create_workspace_client(workspace).get_dataset_client(dataset)
    )
    poll_url = client.refresh_async(refresh_type, max_parallelism, commit_mode, retry_count, objects,
                                    apply_refresh_policy, effective_date, verbose)

    # extract the refresh request id from the poll url
    return poll_url.split("/")[-1]


def refresh_dataset_sync(
    dataset: Union[str, UUID],
    workspace: Optional[Union[str, UUID]] = None,
    visualize: bool = False,
    verbose: int = 0,
    **kwargs
) -> Optional[pd.DataFrame]:
    """
    Synchronously refresh a dataset and optionally visualize the refresh process.

    Parameters
    ----------
    dataset : Union[str, UUID]
        The dataset identifier (name or UUID).
    workspace : Union[str, UUID], default=None
        The workspace identifier (name or UUID).
    visualize : bool, default=False
        Whether to visualize the refresh process using trace logs.
    verbose : int, default=0
        Verbosity level for logging.
    **kwargs
        Additional keyword arguments for the refresh operation.

    Returns
    -------
    Optional[pd.DataFrame]
        The DataFrame containing trace logs if visualization is enabled, otherwise None.
    """
    workspace_client = _get_or_create_workspace_client(workspace)

    # Use name for better user-facing messages
    workspace = workspace_client.get_workspace_name()
    dataset = workspace_client.resolve_dataset_name(dataset)

    print_verbose(
        f"Refresh of the '{dataset}' semantic model within the '{workspace}' workspace is in progress...",
        verbose=verbose
    )

    request_id = refresh_dataset_async(dataset, workspace=workspace, verbose=verbose, **kwargs)

    if visualize:

        df_partition_map = get_partition_map(dataset, workspace=workspace)
        widget = widgets.Output()

        # Define callbacks for trace visualization
        def _visualize(trace: Trace, title: str, stop: bool = False) -> pd.DataFrame:
            return _visualize_refresh(
                trace,
                df_partition_map,
                widget,
                title=title,
                visualize=True,
                stop=stop
            )

        return cast(Optional[pd.DataFrame], _wait_for_refresh_status(
            request_id,
            dataset,
            workspace,
            with_trace=True,
            on_progress=lambda trace: _visualize(cast(Trace, trace), title="Refresh in progress..."),
            on_completion=lambda trace: _visualize(cast(Trace, trace), title="Refresh Completed", stop=True),
            verbose=verbose
        ))

    return cast(Optional[pd.DataFrame], _wait_for_refresh_status(
        request_id,
        dataset,
        workspace,
        verbose=verbose
    ))


def get_dataset_refresh_execution_details(
    dataset: Union[str, UUID],
    request_id: Union[str, UUID],
    workspace: Optional[Union[str, UUID]] = None,
) -> "RefreshExecutionDetails":
    """
    Retrieve the refresh execution details for a dataset.

    Parameters
    ----------
    dataset : Union[str, UUID]
        The dataset identifier (name or UUID).
    request_id : Union[str, UUID]
        The refresh request identifier (name or UUID).
    workspace : Union[str, UUID], default=None
        The workspace identifier (name or UUID).

    Returns
    -------
    RefreshExecutionDetails
        The refresh execution details object.
    """
    client = cast(
        "DatasetRestClient",
        _get_or_create_workspace_client(workspace).get_dataset_client(dataset)
    )
    return client.get_refresh_execution_details(request_id)


def list_dataset_refresh_requests(
    dataset: Union[str, UUID],
    workspace: Optional[Union[str, UUID]] = None,
    top_n: Optional[int] = None
) -> pd.DataFrame:
    """
    List the refresh requests for a dataset.

    Parameters
    ----------
    dataset : Union[str, UUID]
        The dataset identifier (name or UUID).
    workspace : Union[str, UUID], default=None
        The workspace identifier (name or UUID), by default None.
    top_n : int, default=10
        The maximum number of refresh requests to retrieve.

    Returns
    -------
    pandas.DataFrame
        DataFrame containing the refresh requests.
    """
    client = cast(
        "DatasetRestClient",
        _get_or_create_workspace_client(workspace).get_dataset_client(dataset)
    )
    return client.list_refresh_history(top_n=top_n)


def parse_table_partition(partition: str) -> tuple[str, str]:
    """
    Parse table name and partition name from formatted string.

    Parameters
    ----------
    partition : str
        Formatted string in the format 'TableName'[PartitionName]

    Returns
    -------
    tuple[str, str]
        A tuple containing (table_name, partition_name)

    Raises
    ------
    ValueError
        If the partition string is not in the correct format
    """
    # Pattern to match 'TableName'[PartitionName]
    if not partition.startswith("'") or "'[" not in partition or not partition.endswith("]"):
        raise ValueError(
            f"Invalid partition format: '{partition}'. "
            "Expected format: 'TableName'[PartitionName]"
        )

    # Find the end of the quoted table name
    quote_end = partition.find("'[")
    if quote_end <= 0:
        raise ValueError(
            f"Invalid partition format: '{partition}'. "
            "Expected format: 'TableName'[PartitionName]"
        )

    table_name = partition[1:quote_end]
    partition_name = partition[quote_end + 2:-1]
    return table_name, partition_name


def get_refresh_type(key: str) -> str:
    refresh_type_mapping = {
        "full": "full",
        "auto": "automatic",
        "data": "dataOnly",
        "calc": "calculate",
        "clear": "clearValues",
        "defrag": "defragment",
    }
    for prefix, mapped_value in refresh_type_mapping.items():
        if key.lower().startswith(prefix):
            return mapped_value
    raise ValueError(f"Unknown refresh type key: '{key}'; Must be one of {list(refresh_type_mapping.values())}")


def get_partition_map(dataset: Union[str, UUID], workspace: Optional[Union[str, UUID]] = None, verbose: int = 0) -> pd.DataFrame:
    """
    Retrieve the mapping of partitions to their respective tables for a given dataset.

    Parameters
    ----------
    dataset : Union[str, UUID]
        The dataset identifier (name or UUID).
    workspace : Union[str, UUID], default=None
        The workspace identifier (name or UUID), by default None.
    verbose : int, default=0
        Verbosity level for logging, by default 0.

    Returns
    -------
    pd.DataFrame
        A DataFrame containing the mapping of partitions to tables with columns:
        - PartitionID
        - TableID
        - PartitionName
        - TableName
        - Object Name (formatted as 'TableName'[PartitionName] for partitioned tables)
    """
    client = cast(
        "DatasetXmlaClient",
        _get_or_create_workspace_client(workspace).get_dataset_client(dataset, mode=ConnectionMode.XMLA)
    )

    df_partition = client.evaluate_dax(
        """
        select [ID] AS [PartitionID], [TableID], [Name] AS [PartitionName] from $system.tmschema_partitions
        """,
        verbose=verbose
    )

    df_table = client.evaluate_dax(
        """
        select [ID] AS [TableID], [Name] AS [TableName] from $system.tmschema_tables
        """,
        verbose=verbose
    )

    df_partition_map = pd.merge(df_partition, df_table, on="TableID", how="left")
    df_partition_map["PartitionID"] = df_partition_map["PartitionID"].astype(str)

    # Nothing to format when there are no partitions; return early to avoid pandas assignment errors
    if df_partition_map.empty:
        df_partition_map["Object Name"] = pd.Series(dtype=str)
        return df_partition_map

    # Generating partition object name as 'Table[Partition]' for partitioned tables
    df_partition_counts = df_partition_map.groupby("TableID")["PartitionID"].transform("count")

    df_partition_map["Object Name"] = df_partition_map.apply(
        lambda row: (
            f"'{row['TableName']}'[{row['PartitionName']}]"
            if df_partition_counts[row.name] > 1
            else row["TableName"]
        ),
        axis=1,
    )
    return df_partition_map


def _wait_for_refresh_status(
    request_id: str,
    dataset: str,
    workspace: str,
    with_trace: bool = False,
    on_progress: Optional[Callable[[Optional[Trace]], T]] = None,
    on_completion: Optional[Callable[[Optional[Trace]], T]] = None,
    verbose: int = 0,
) -> Optional[T]:
    """
    Poll the refresh status until completion, failure, or cancellation.

    Parameters
    ----------
    request_id : str
        The refresh request ID.
    dataset : str
        The dataset identifier (name or UUID).
    workspace : str
        The workspace identifier (name or UUID).
    with_trace : bool, default=False
        Whether to enable tracing during the refresh process.
    on_progress : Callable[[Optional[Trace]], T], default=None
        Callback function to execute during each poll iteration. Receives trace object if tracing enabled.
    on_completion : Callable[[Optional[Trace]], T], default=None
        Callback function to execute after successful completion. Receives trace object if tracing enabled.
    verbose : int, default=0
        Verbosity level for logging.

    Returns
    -------
    Optional[T]
        The result from the last callback (``on_progress`` or ``on_completion``) if provided, otherwise None.

    Raises
    ------
    ValueError
        If the refresh fails.
    """
    trace_connection_ctx: "Union[AbstractContextManager[None], AbstractContextManager[TraceConnection]]"
    trace_ctx: "Union[AbstractContextManager[None], AbstractContextManager[Trace]]"
    trace: Optional[Trace]
    result: Optional[T] = None

    # Create trace context manager conditionally
    if with_trace:
        dataset_client = cast(
            "DatasetXmlaClient",
            _get_or_create_workspace_client(workspace).get_dataset_client(dataset, mode=ConnectionMode.XMLA)
        )
        trace_connection_ctx = TraceConnection(dataset_client)
    else:
        trace_connection_ctx = nullcontext()

    with trace_connection_ctx as trace_connection:
        if trace_connection:
            trace_connection = cast(TraceConnection, trace_connection)
            trace_ctx = trace_connection.create_trace({
                "JobGraph": [
                    "EventClass",
                    "EventSubclass",
                    "CurrentTime",
                    "TextData"
                ],
                "ProgressReportEnd": [
                    "EventClass",
                    "EventSubclass",
                    "CurrentTime",
                    "TextData",
                    "StartTime",
                    "EndTime",
                    "Duration",
                    "CpuTime",
                    "Success",
                    "IntegerData",
                    "ObjectID",
                ],
            })
        else:
            # Create a null context if tracing is not enabled so that we can use 'with' syntax uniformly for both cases
            trace_ctx = nullcontext()

        # Ignore warnings for warm-up period with no logs
        with warnings.catch_warnings():
            warnings.filterwarnings(
                "ignore",
                message="No trace logs have been recorded. Try starting the trace with a larger 'delay'",
            )

            with trace_ctx as trace:
                if trace:
                    cast(Trace, trace).start()

                while True:
                    status = get_dataset_refresh_execution_details(dataset, request_id, workspace=workspace).status

                    if status == "Completed":
                        break
                    elif status == "Failed":
                        raise ValueError(_extract_refresh_error(dataset, workspace, request_id))
                    elif status == "Cancelled":
                        print_verbose(
                            f"The refresh of the '{dataset}' semantic model within the '{workspace}' workspace has "
                            "been cancelled.",
                            verbose=verbose
                        )
                        return result

                    # Execute optional progress callback
                    if on_progress:
                        result = on_progress(trace)

                    time.sleep(3)

                # Execute optional completion callback
                if on_completion:
                    time.sleep(5)
                    result = on_completion(trace)

    print_verbose(
        f"Refresh of the '{dataset}' semantic model within the '{workspace}' workspace is complete.",
        verbose=verbose
    )

    return result


def _visualize_refresh(
        trace: Trace,
        df_partition_map: pd.DataFrame,
        widget: widgets.Output,
        title: str,
        visualize: bool = False,
        stop: bool = False) -> pd.DataFrame:
    """
    Retrieve the refresh trace logs.

    Parameters
    ----------
    trace : Trace
        The Trace object to retrieve logs from.
    df_partition_map : pd.DataFrame
        DataFrame containing partition mapping information.
    widget : widgets.Output
        The output widget for displaying visualizations.
    title : str
        Title for the visualization.
    visualize : bool, default=False
        Whether to visualize the trace logs.
    stop : bool, default=False
        Whether to stop the trace.

    Returns
    -------
    pd.DataFrame
        DataFrame containing the retrieved trace logs.
    """
    if stop:
        df = trace.stop()
    else:
        df = trace.get_trace_logs()

    if df.empty:
        return df

    df = df[
        df["Event Subclass"].isin(["ExecuteSql", "Process"])
    ].reset_index(drop=True)

    df = pd.merge(
        df,
        df_partition_map[
            ["PartitionID", "Object Name", "TableName", "PartitionName"]
        ],
        left_on="Object ID",
        right_on="PartitionID",
        how="left",
    )

    if not df.empty and visualize:
        _plot_refresh_gantt_chart(df, title=title, widget=widget)

    if stop:
        df.drop(["Object Name", "PartitionID"], axis=1, inplace=True)
        df.rename(columns={"TableName": "Table Name"}, inplace=True)
        df.rename(columns={"PartitionName": "Partition Name"}, inplace=True)

    return df


def _plot_refresh_gantt_chart(df: pd.DataFrame, title: str, widget: widgets.Output) -> None:
    """
    Plot a Gantt chart for dataset refresh.

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame containing trace logs with "Start Time" and "End Time" columns.
    title : str
        Title for the Gantt chart.
    widget : widgets.Output
        IPython widget output area to display the chart.
    """

    # Convert time columns to milliseconds
    df["Start"] = df["Start Time"].astype(np.int64) / int(1e6)
    df["End"] = df["End Time"].astype(np.int64) / int(1e6)

    # Calculate the time offset for proper Gantt chart rendering
    offset = min(df["Start"])
    df["Start"] = df["Start"] - offset
    df["End"] = df["End"] - offset

    unique_objects = df["Object Name"].nunique()
    height = min(max(400, unique_objects * 30), 1000)

    # Vega-Lite spec for Gantt chart
    spec = (
        """{
        "$schema": "https://vega.github.io/schema/vega-lite/v5.json",
        "description": "A simple bar chart with ranged data (aka Gantt Chart).",
        "data": { "values": """
        + df.to_json(orient="records")
        + """ },
        "width": 700,
        "height": """
        + str(height)
        + """,
        "mark": "bar",
        "encoding": {
            "y": {
                "field": "Object Name",
                "type": "ordinal",
                "axis": {
                    "labelFontSize": 15,
                    "titleFontSize": 20,
                    "title": "Object"
                }
            },
            "x": {
                "field": "Start",
                "type": "quantitative",
                "title": "milliseconds",
                "axis": {
                    "titleFontSize": 20
                }
            },
            "x2": {"field": "End"},
            "color": {
                "field": "Event Subclass",
                "scale": {
                    "domain": ["Process", "ExecuteSql"],
                    "range": ["#FFC000","#0070C0"]
                },
                "legend": {
                    "labelFontSize": 20,
                    "titleFontSize": 20,
                    "title": "Event Type"
                }
            },
            "tooltip": [
                {"field": "Duration", "type": "quantitative", "format": ","},
                {"field": "Cpu Time", "type": "quantitative", "format": ","},
                {"field": "Event Subclass", "type": "nominal"}
            ]
        }
    }"""
    )

    with widget:
        widget.clear_output(wait=True)

    h = f"""
    <!DOCTYPE html>
    <html>
        <head>
            <script src="https://cdn.jsdelivr.net/npm/vega@5"></script>
            <script src="https://cdn.jsdelivr.net/npm/vega-lite@5"></script>
            <script src="https://cdn.jsdelivr.net/npm/vega-embed@6"></script>
            <style>
                table, th, td {{
                border: 10px solid #e7e9eb;
                border-collapse: collapse;
                }}
            </style>
        </head>
        <body>
            <table>
                <tr>
                    <td style="text-align: center;">
                        <h1>{title}</h1>
                    </td>
                </tr>
                <tr>
                    <td>
                        <div id="vis"></div>
                    </td>
                </tr>
            </table>
            <script type="text/javascript">
                var spec = {spec};
                var opt = {{"renderer": "canvas", "actions": false}};
                vegaEmbed("#vis", spec, opt);
            </script>
        </body>
    </html>"""

    display(HTML(h))


def _extract_refresh_error(
    dataset: str,
    workspace: str,
    request_id: Union[str, UUID]
) -> str:
    """
    Extract and format the error message from a failed dataset refresh.

    Parameters
    ----------
    dataset : str
        The dataset name or ID.
    workspace : str
        The workspace name or ID.
    request_id : Union[str, UUID]
        The request ID.

    Returns
    -------
    str
        The formatted error message.
    """
    error_messages = []
    combined_messages = ""
    final_message = f"The refresh of the '{dataset}' semantic model within the '{workspace}' workspace has failed."
    for _, r in get_dataset_refresh_execution_details(dataset, request_id, workspace=workspace).messages.iterrows():
        error_messages.append(f"{r['Type']}: {r['Message']}")

    if error_messages:
        combined_messages = "\n".join(error_messages)
    final_message += f"\n{combined_messages}"

    return final_message
