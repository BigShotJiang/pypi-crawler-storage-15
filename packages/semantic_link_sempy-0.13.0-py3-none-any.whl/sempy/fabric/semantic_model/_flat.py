import datetime
from typing import TYPE_CHECKING, Dict, List, Literal, Optional, Tuple, Union
from uuid import UUID

import pandas as pd

from ..._utils._log import log, log_error
from .._cache import _get_or_create_workspace_client
from .._client._pbi_rest_api import _PBIRestAPI
from .._client._refresh_execution_details import RefreshExecutionDetails
from .._credentials import with_credential
from .._utils import is_valid_uuid
from ._utils import (get_dataset_refresh_execution_details, get_refresh_type,
                     list_dataset_refresh_requests, parse_table_partition,
                     refresh_dataset_async, refresh_dataset_sync)

if TYPE_CHECKING:
    from azure.core.credentials import TokenCredential


@log
@with_credential
def refresh_dataset(
    dataset: Union[str, UUID],
    workspace: Optional[Union[str, UUID]] = None,
    refresh_type: str = "automatic",
    max_parallelism: int = 10,
    commit_mode: str = "transactional",
    retry_count: int = 0,
    objects: Optional[List] = None,
    apply_refresh_policy: bool = True,
    effective_date: datetime.date = datetime.date.today(),
    verbose: int = 0,
    credential: Optional["TokenCredential"] = None
) -> str:
    """
    Refresh data associated with the given dataset.

    .. note::
        This is a wrapper function for
        `Datasets - Refresh Dataset In Group <https://learn.microsoft.com/en-us/rest/api/power-bi/datasets/refresh-dataset-in-group>`_.

        For detailed documentation on the implementation see
        `Enhanced refresh with the Power BI REST API <https://learn.microsoft.com/en-us/power-bi/connect-data/asynchronous-refresh>`_.

    Parameters
    ----------
    dataset : str or uuid.UUID
        Name or UUID of the dataset.
    workspace : str or uuid.UUID, default=None
        The Fabric workspace name or UUID object containing the workspace ID.
        Defaults to None which resolves to the workspace of the attached lakehouse
        or if no lakehouse attached, resolves to the workspace of the notebook.
    refresh_type : str, default="automatic"
        The type of processing to perform. Types align with the TMSL refresh command types: full,
        clearValues, calculate, dataOnly, automatic, and defragment. The add type isn't supported.
        Defaults to "automatic".
    max_parallelism : int, default=10
        Determines the maximum number of threads that can run the processing commands in parallel.
        This value aligns with the MaxParallelism property that can be set in the TMSL Sequence
        command or by using other methods. Defaults to 10.
    commit_mode : str, default="transactional"
        Determines whether to commit objects in batches or only when complete.
        Modes are "transactional" and "partialBatch". Defaults to "transactional".
    retry_count : int, default=0
        Number of times the operation retries before failing. Defaults to 0.
    objects : List, default=None
        A list of objects to process. Each object includes table when processing an entire table,
        or table and partition when processing a partition. If no objects are specified,
        the entire dataset refreshes. Pass output of json.dumps of a structure that specifies the
        objects that you want to refresh. For example, this is to refresh "DimCustomer1" partition
        of table "DimCustomer" and complete table "DimDate"::

            [
                {
                    "table": "DimCustomer",
                    "partition": "DimCustomer1"
                },
                {
                    "table": "DimDate"
                }
            ]

    apply_refresh_policy : bool, default=True
        If an incremental refresh policy is defined, determines whether to apply the policy.
        Modes are true or false. If the policy isn't applied, the full process leaves partition
        definitions unchanged, and fully refreshes all partitions in the table. If commitMode is
        transactional, applyRefreshPolicy can be true or false. If commitMode is partialBatch,
        applyRefreshPolicy of true isn't supported, and applyRefreshPolicy must be set to false.
    effective_date : datetime.date, default=datetime.date.today()
        If an incremental refresh policy is applied, the effectiveDate parameter overrides the current date.
    verbose : int, default=0
        If set to non-zero, extensive log output is printed.
    credential : TokenCredential, default=None
        The credential for token acquisition. Must be an instance of
        `azure.core.credentials.TokenCredential <https://learn.microsoft.com/en-us/azure/developer/python/sdk/authentication/overview>`_.
        If None, the default credential will be used.

    Returns
    -------
    str
        The refresh request id.
    """
    return refresh_dataset_async(
        dataset,
        workspace=workspace,
        refresh_type=refresh_type,
        max_parallelism=max_parallelism,
        commit_mode=commit_mode,
        retry_count=retry_count,
        objects=objects,
        apply_refresh_policy=apply_refresh_policy,
        effective_date=effective_date,
        verbose=verbose
    )


@log
@with_credential
def refresh_semantic_model(
    dataset: Union[str, UUID],
    tables: Optional[Union[str, List[str]]] = None,
    partitions: Optional[Union[str, List[str]]] = None,
    workspace: Optional[Union[str, UUID]] = None,
    refresh_type: str = "automatic",
    max_parallelism: int = 10,
    commit_mode: str = "transactional",
    retry_count: int = 0,
    apply_refresh_policy: bool = True,
    effective_date: datetime.date = datetime.date.today(),
    visualize: bool = False,
    verbose: int = 0,
    credential: Optional["TokenCredential"] = None
) -> Optional[pd.DataFrame]:
    """
    Refresh a semantic model synchronously with options to visualize the refresh progress and collect SSAS traces.

    .. note::
        This is a wrapper function for
        `Datasets - Refresh Dataset In Group <https://learn.microsoft.com/en-us/rest/api/power-bi/datasets/refresh-dataset-in-group>`_.

        For detailed documentation on the implementation see
        `Enhanced refresh with the Power BI REST API <https://learn.microsoft.com/en-us/power-bi/connect-data/asynchronous-refresh>`_.

    Parameters
    ----------
    dataset : str or uuid.UUID
        Name or ID of the semantic model.
    tables : str or List[str], default=None
        A string or a list of tables to refresh. The entire table will be refreshed.
        Use ``partitions`` if you wish to refresh specific partitions within a table.
    partitions : str or List[str], default=None
        A string or a list of partitions to refresh. Partitions must be formatted as such: 'Table Name'[Partition Name].
        Use ``tables`` if you wish to refresh all partitions within those tables.
    workspace : str or uuid.UUID, default=None
        The Fabric workspace name or UUID object containing the workspace ID.
        Defaults to None which resolves to the workspace of the attached lakehouse
        or if no lakehouse attached, resolves to the workspace of the notebook.
    refresh_type : str, default="automatic"
        The type of processing to perform. Types align with the TMSL refresh command types: full,
        clearValues, calculate, dataOnly, automatic, and defragment. The add type isn't supported.
        Defaults to "automatic".
    max_parallelism : int, default=10
        Determines the maximum number of threads that can run the processing commands in parallel.
        This value aligns with the MaxParallelism property that can be set in the TMSL Sequence
        command or by using other methods. Defaults to 10.
    commit_mode : str, default="transactional"
        Determines whether to commit objects in batches or only when complete.
        Modes are "transactional" and "partialBatch". Defaults to "transactional".
    retry_count : int, default=0
        Number of times the operation retries before failing. Defaults to 0.
    apply_refresh_policy : bool, default=True
        If an incremental refresh policy is defined, determines whether to apply the policy.
        Modes are true or false. If the policy isn't applied, the full process leaves partition
        definitions unchanged, and fully refreshes all partitions in the table. If commitMode is
        transactional, applyRefreshPolicy can be true or false. If commitMode is partialBatch,
        applyRefreshPolicy of true isn't supported, and applyRefreshPolicy must be set to false.
    effective_date : datetime.date, default=datetime.date.today()
        If an incremental refresh policy is applied, the effectiveDate parameter overrides the current date.
    visualize : bool, default=False
        If True, displays a Gantt chart showing the refresh statistics for each table/partition.
    verbose : int, default=0
        If set to non-zero, extensive log output is printed.
    credential : TokenCredential, default=None
        The credential for token acquisition. Must be an instance of
        `azure.core.credentials.TokenCredential <https://learn.microsoft.com/en-us/azure/developer/python/sdk/authentication/overview>`_.
        If None, the default credential will be used.

    Returns
    -------
    pandas.DataFrame or None
        If 'visualize' is set to True, returns a pandas dataframe showing the SSAS trace output used to generate the visualization.
    """

    if isinstance(tables, str):
        tables = [tables]
    if isinstance(partitions, str):
        partitions = [partitions]

    # Generating the objects request body
    objects: List[Dict[str, str]] = []

    if tables is not None:
        objects = objects + [{"table": table} for table in tables]

    if partitions is not None:
        for partition in partitions:
            table_name, partition_name = parse_table_partition(partition)
            objects.append({"table": table_name, "partition": partition_name})

    refresh_type = get_refresh_type(refresh_type)

    return refresh_dataset_sync(
        dataset,
        workspace=workspace,
        refresh_type=refresh_type,
        max_parallelism=max_parallelism,
        commit_mode=commit_mode,
        retry_count=retry_count,
        objects=objects if len(objects) > 0 else None,
        apply_refresh_policy=apply_refresh_policy,
        effective_date=effective_date,
        visualize=visualize,
        verbose=verbose
    )


@log
def cancel_refresh(
    dataset: Union[str, UUID],
    request_id: Optional[str] = None,
    workspace: Optional[Union[str, UUID]] = None,
):
    """
    Cancel the specific refresh of a semantic model.

    .. note::
        This is a wrapper function for
        `Datasets - Cancel Refresh In Group <https://learn.microsoft.com/en-us/rest/api/power-bi/datasets/cancel-refresh-in-group>`_.

    Parameters
    ----------
    dataset : str or uuid.UUID
        Name or ID of the semantic model.
    request_id : str, default=None
        The request id of a semantic model refresh.
        Defaults to finding the latest active refresh of the semantic model.
    workspace : str or uuid.UUID, default=None
        The Fabric workspace name or UUID object containing the workspace ID.
        Defaults to None which resolves to the workspace of the attached lakehouse
        or if no lakehouse attached, resolves to the workspace of the notebook.
    """
    workspace_client = _get_or_create_workspace_client(workspace=workspace)
    workspace_name = workspace_client.get_workspace_name()
    workspace_id = workspace_client.get_workspace_id()
    dataset_name = workspace_client.resolve_dataset_name(str(dataset))
    dataset_id = workspace_client.resolve_dataset_id(str(dataset))

    if request_id is None:
        # Get active refresh requests
        df_requests = list_dataset_refresh_requests(dataset, workspace=workspace)
        df_requests = df_requests[df_requests["Status"] == "Unknown"]
        if df_requests.empty:
            raise ValueError(
                f"There are no active Enhanced API refreshes of the '{dataset_name}' semantic model within the '{workspace_name}' workspace."
            )

        request_id = df_requests["Request Id"].iloc[0]

    # Cancel the refresh using the REST API
    _PBIRestAPI().cancel_refresh(
        dataset_id,
        request_id,
        workspace_id,
        workspace_name
    )


@log
@with_credential
def list_refresh_requests(
    dataset: Union[str, UUID],
    workspace: Optional[Union[str, UUID]] = None,
    top_n: Optional[int] = None,
    credential: Optional["TokenCredential"] = None
) -> pd.DataFrame:
    """
    Poll the status or refresh requests for a given dataset using Enhanced refresh with the Power BI REST API.

    .. note::
        This is a wrapper function for
        `Datasets - Get Refresh History In Group <https://learn.microsoft.com/en-us/rest/api/power-bi/datasets/get-refresh-history-in-group>`_.

        See details in: `PBI Documentation <https://learn.microsoft.com/en-us/power-bi/connect-data/asynchronous-refresh>`_.

    Parameters
    ----------
    dataset : str or uuid.UUID
        Name or UUID of the dataset.
    workspace : str or uuid.UUID, default=None
        The Fabric workspace name or UUID object containing the workspace ID.
        Defaults to None which resolves to the workspace of the attached lakehouse
        or if no lakehouse attached, resolves to the workspace of the notebook.
    top_n : int, default = None
        Limit the number of refresh operations returned.
    credential : TokenCredential, default=None
        The credential for token acquisition. Must be an instance of
        `azure.core.credentials.TokenCredential <https://learn.microsoft.com/en-us/azure/developer/python/sdk/authentication/overview>`_.
        If None, the default credential will be used.

    Returns
    -------
    pandas.DataFrame:
        Dataframe with statuses of refresh request retrieved based on the passed parameters.
    """
    return list_dataset_refresh_requests(dataset, workspace=workspace, top_n=top_n)


@log_error
@with_credential
def get_refresh_execution_details(
    dataset: Union[str, UUID],
    refresh_request_id: Union[str, UUID],
    workspace: Optional[Union[str, UUID]] = None,
    credential: Optional["TokenCredential"] = None
) -> RefreshExecutionDetails:
    """
    Poll the status for a specific refresh requests using Enhanced refresh with the Power BI REST API.

    .. note::
        This is a wrapper function for
        `Datasets - Get Refresh Execution Details In Group <https://learn.microsoft.com/en-us/rest/api/power-bi/datasets/get-refresh-execution-details-in-group>`_.

        More details on the underlying implementation in `PBI Documentation <https://learn.microsoft.com/en-us/power-bi/connect-data/asynchronous-refresh>`_.

    Parameters
    ----------
    dataset : str or uuid.UUID
        Name or UUID of the dataset.
    refresh_request_id : str or uuid.UUID
        Id of refresh request on which to check the status.
    workspace : str or uuid.UUID, default=None
        The Fabric workspace name or UUID object containing the workspace ID.
        Defaults to None which resolves to the workspace of the attached lakehouse
        or if no lakehouse attached, resolves to the workspace of the notebook.
    credential : TokenCredential, default=None
        The credential for token acquisition. Must be an instance of
        `azure.core.credentials.TokenCredential <https://learn.microsoft.com/en-us/azure/developer/python/sdk/authentication/overview>`_.
        If None, the default credential will be used.

    Returns
    -------
    RefreshExecutionDetails:
        RefreshExecutionDetails instance with statuses of refresh request retrieved based on the passed URL.
    """
    return get_dataset_refresh_execution_details(
        dataset,
        refresh_request_id,
        workspace=workspace)


@log
@with_credential
def list_datasets(workspace: Optional[Union[str, UUID]] = None, mode: str = "xmla",
                  additional_xmla_properties: Optional[Union[str, List[str]]] = None,
                  endpoint: Literal["powerbi", "fabric"] = "powerbi",
                  credential: Optional["TokenCredential"] = None) -> pd.DataFrame:
    """
    List datasets in a `Fabric workspace <https://learn.microsoft.com/en-us/fabric/get-started/workspaces>`_.

    ⚠️ By default (`mode="xmla"`), this function leverages the
    `Tabular Object Model (TOM) <https://learn.microsoft.com/en-us/dotnet/api/microsoft.analysisservices.tabular.server?view=analysisservices-dotnet>`_
    to interact with the target semantic model. To use this function in `xmla` mode, you must have at least **ReadWrite** permissions on the model.
    Alternatively, you can use `mode="rest"`.

    Parameters
    ----------
    workspace : str or uuid.UUID, default=None
        The Fabric workspace name or UUID object containing the workspace ID.
        Defaults to None which resolves to the workspace of the attached lakehouse
        or if no lakehouse attached, resolves to the workspace of the notebook.
    mode : str, default="xmla"
        Whether to use the XMLA "xmla" or REST API "rest".
        See `REST docs <https://learn.microsoft.com/en-us/rest/api/power-bi/datasets/get-datasets>`_ for returned fields.
    additional_xmla_properties : str or List[str], default=None
        Additional XMLA `model <https://learn.microsoft.com/en-us/dotnet/api/microsoft.analysisservices.tabular.model?view=analysisservices-dotnet>`_
        properties to include in the returned dataframe.
    endpoint : Literal["powerbi", "fabric"], default="powerbi"
        The endpoint to use when mode="rest". Supported values are "powerbi" and "fabric".
        When mode="xmla", this parameter is ignored.
        See `PowerBI List Datasets <https://learn.microsoft.com/en-us/rest/api/power-bi/datasets/get-datasets>`__ for using "powerbi"
        and `Fabric List Datasets <https://learn.microsoft.com/en-us/rest/api/fabric/semanticmodel/items/list-semantic-models>`__ for using "fabric".
    credential : TokenCredential, default=None
        The credential for token acquisition. Must be an instance of
        `azure.core.credentials.TokenCredential <https://learn.microsoft.com/en-us/azure/developer/python/sdk/authentication/overview>`_.
        If None, the default credential will be used.

    Returns
    -------
    pandas.DataFrame
        Dataframe listing databases and their attributes.
    """
    return _get_or_create_workspace_client(workspace).get_datasets(mode, additional_xmla_properties, endpoint=endpoint)


@log
@with_credential
def resolve_dataset_id(dataset_name: str, workspace: Optional[Union[str, UUID]] = None,
                       credential: Optional["TokenCredential"] = None) -> str:
    """
    Resolve the dataset ID by name in the specified workspace.

    Parameters
    ----------
    dataset_name : str
        Name of the dataset to be resolved.
    workspace : str or uuid.UUID, default=None
        The Fabric workspace name or UUID object containing the workspace ID. Defaults to None
        which resolves to the workspace of the attached lakehouse
        or if no lakehouse attached, resolves to the workspace of the notebook.
    credential : TokenCredential, default=None
        The credential for token acquisition. Must be an instance of
        `azure.core.credentials.TokenCredential <https://learn.microsoft.com/en-us/azure/developer/python/sdk/authentication/overview>`_.
        If None, the default credential will be used.

    Returns
    -------
    str
        The ID of the specified dataset.
    """
    return _get_or_create_workspace_client(workspace).resolve_dataset_id(dataset_name)


@log
@with_credential
def resolve_dataset_name(dataset_id: Union[str, UUID], workspace: Optional[Union[str, UUID]] = None,
                         credential: Optional["TokenCredential"] = None) -> str:
    """
    Resolve the dataset name by ID in the specified workspace.

    Parameters
    ----------
    dataset_id : str or uuid.UUID
        Dataset ID or UUID object containing the dataset ID to be resolved.
    workspace : str or uuid.UUID, default=None
        The Fabric workspace name or UUID object containing the workspace ID. Defaults to None
        which resolves to the workspace of the attached lakehouse
        or if no lakehouse attached, resolves to the workspace of the notebook.
    credential : TokenCredential, default=None
        The credential for token acquisition. Must be an instance of
        `azure.core.credentials.TokenCredential <https://learn.microsoft.com/en-us/azure/developer/python/sdk/authentication/overview>`_.
        If None, the default credential will be used.

    Returns
    -------
    str
        The name of the specified dataset.
    """
    return _get_or_create_workspace_client(workspace).resolve_dataset_name(dataset_id)


@log
@with_credential
def resolve_dataset_name_and_id(
    dataset: Union[str, UUID], workspace: Optional[Union[str, UUID]] = None,
    credential: Optional["TokenCredential"] = None
) -> Tuple[str, str]:
    """
    Resolve the name and ID of a dataset in the specified or default workspace.

    Parameters
    ----------
    dataset : str or UUID
        The dataset name or ID.
    workspace : str or UUID, default=None
        The Fabric workspace name or ID. If None, the default workspace is used.
    credential : TokenCredential, default=None
        The credential for token acquisition. Must be an instance of
        `azure.core.credentials.TokenCredential <https://learn.microsoft.com/en-us/azure/developer/python/sdk/authentication/overview>`_.
        If None, the default credential will be used.

    Returns
    -------
    Tuple[str, str]
        A tuple containing the dataset name and dataset ID.
    """
    workspace_client = _get_or_create_workspace_client(workspace)

    if isinstance(dataset, UUID) or is_valid_uuid(dataset):
        dataset_id = str(dataset)
        dataset_name = workspace_client.resolve_dataset_name(dataset_id)

    else:
        dataset_name = dataset
        dataset_id = workspace_client.resolve_dataset_id(dataset_name)

    return dataset_name, dataset_id
