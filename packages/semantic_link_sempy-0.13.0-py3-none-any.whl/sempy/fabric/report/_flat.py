from typing import TYPE_CHECKING, List, Literal, Optional, Union
from uuid import UUID

from ..._utils._log import log
from .._cache import _get_or_create_workspace_client
from .._credentials import with_credential
from .._flat import resolve_item_id, resolve_workspace_id
from ..semantic_model import resolve_dataset_id

if TYPE_CHECKING:
    import pandas as pd
    from azure.core.credentials import TokenCredential


@log
@with_credential
def clone_report(source_report: Union[str, UUID],
                 target_report: str,
                 source_workspace: Optional[Union[str, UUID]] = None,
                 target_workspace: Optional[Union[str, UUID]] = None,
                 target_dataset: Optional[Union[str, UUID]] = None,
                 target_dataset_workspace: Optional[Union[str, UUID]] = None,
                 credential: Optional["TokenCredential"] = None) -> str:
    """
    Clone a report in the specified workspace.

    .. note::
        This functions wraps the PowerBI REST API `Reports - Clone Report In Group <https://learn.microsoft.com/en-us/rest/api/power-bi/reports/clone-report-in-group>`__.

    Parameters
    ----------
    source_report : str or uuid.UUID
        Source report name or ID.
    target_report : str
        Target report name.
    source_workspace : str or uuid.UUID, default=None
        The Fabric workspace name or UUID object containing the workspace ID that hosts the source report.
        Defaults to None which resolves to the workspace of the attached lakehouse
        or if no lakehouse attached, resolves to the workspace of the notebook.
    target_workspace : str or uuid.UUID, default=None
        The Fabric workspace name or UUID object containing the workspace ID that will host the cloned report.
        If None, the cloned report will be created in the same workspace as the source report.
    target_dataset : str or uuid.UUID, default=None
        Target semantic model name or ID. If None, the cloned report will be bound to the same dataset as the source report.
    target_dataset_workspace : str or uuid.UUID, default=None
        The Fabric workspace name or UUID object containing the workspace ID that hosts the target dataset.
        If None, the target dataset workspace will be assumed to be the same workspace as the source report.
    credential : TokenCredential, default=None
        The credential for token acquisition. Must be an instance of
        `azure.core.credentials.TokenCredential <https://learn.microsoft.com/en-us/azure/developer/python/sdk/authentication/overview>`_.
        If None, the default credential will be used.

    Returns
    -------
    str
        The ID of the cloned report.
    """

    source_report_id = resolve_item_id(source_report, item_type="Report", workspace=source_workspace)

    target_workspace_id = None
    if target_workspace is not None:
        if target_workspace == "My workspace":
            target_workspace_id = str(UUID(int=0))
        else:
            target_workspace_id = resolve_workspace_id(target_workspace)

    target_dataset_id = None
    if target_dataset is not None:
        target_dataset_id = resolve_dataset_id(target_dataset,
                                               workspace=(target_dataset_workspace or source_workspace))

    return _get_or_create_workspace_client(source_workspace) \
        .clone_report(
            source_report_id,
            target_report,
            target_workspace_id=target_workspace_id,
            target_dataset_id=target_dataset_id
        )


@log
@with_credential
def list_reports(workspace: Optional[Union[str, UUID]] = None,
                 endpoint: Literal["powerbi", "fabric"] = "powerbi",
                 credential: Optional["TokenCredential"] = None) -> "pd.DataFrame":
    """
    Return a list of reports in the specified workspace.

    Parameters
    ----------
    workspace : str or uuid.UUID, default=None
        The Fabric workspace name or UUID object containing the workspace ID. Defaults to None
        which resolves to the workspace of the attached lakehouse
        or if no lakehouse attached, resolves to the workspace of the notebook.
    endpoint : Literal["powerbi", "fabric"], default="powerbi"
        The endpoint to use for listing reports. Supported values are "powerbi" and "fabric".
        See `PowerBI List Reports <https://learn.microsoft.com/en-us/rest/api/power-bi/reports/get-reports>`__ for using "powerbi"
        and `Fabric List Reports <https://learn.microsoft.com/en-us/rest/api/fabric/report/items/list-reports>`__ for using "fabric".
    credential : TokenCredential, default=None
        The credential for token acquisition. Must be an instance of
        `azure.core.credentials.TokenCredential <https://learn.microsoft.com/en-us/azure/developer/python/sdk/authentication/overview>`_.
        If None, the default credential will be used.

    Returns
    -------
    "pd.DataFrame"
        DataFrame with one row per report.
    """
    return _get_or_create_workspace_client(workspace).list_reports(endpoint=endpoint)


@log
@with_credential
def rebind_report(
    report: Union[str, UUID, List[Union[str, UUID]]],
    dataset: Union[str, UUID],
    report_workspace: Optional[Union[str, UUID]] = None,
    dataset_workspace: Optional[Union[str, UUID]] = None,
    credential: Optional["TokenCredential"] = None
) -> None:
    """
    Rebind one or more reports to a semantic model.

    .. note::
        This functions wraps the PowerBI REST API `Reports - Rebind Report In Group <https://learn.microsoft.com/en-us/rest/api/power-bi/reports/rebind-report-in-group>`__.

    Parameters
    ----------
    report : str, uuid.UUID, or a list of str or uuid.UUID
        Report name(s) or ID(s).
    dataset : str or uuid.UUID
        Target semantic model name or ID.
    report_workspace : str or uuid.UUID, default=None
        The Fabric workspace name or UUID object containing the workspace ID that hosts the report(s).
        Defaults to None which resolves to the workspace of the attached lakehouse
        or if no lakehouse attached, resolves to the workspace of the notebook.
    dataset_workspace : str or uuid.UUID, default=None
        The Fabric workspace name or UUID object containing the workspace ID that hosts the semantic model.
        Defaults to ``report_workspace``.
    credential : TokenCredential, default=None
        The credential for token acquisition. Must be an instance of
        `azure.core.credentials.TokenCredential <https://learn.microsoft.com/en-us/azure/developer/python/sdk/authentication/overview>`_.
        If None, the default credential will be used.
    """
    if isinstance(report, (str, UUID)):
        report = [report]

    report_workspace_id = resolve_workspace_id(workspace=report_workspace)

    target_dataset_workspace = dataset_workspace or report_workspace_id
    dataset_workspace_id = resolve_workspace_id(target_dataset_workspace)

    report_ids = []
    for r in report:
        report_ids.append(resolve_item_id(r, "Report", workspace=report_workspace_id))

    dataset_id = resolve_dataset_id(dataset, workspace=dataset_workspace_id)

    _get_or_create_workspace_client(report_workspace) \
        .rebind_report(
            report_ids,
            dataset_id,
        )
