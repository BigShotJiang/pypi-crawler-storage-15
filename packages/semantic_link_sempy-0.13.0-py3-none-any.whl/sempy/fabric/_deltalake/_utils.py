import re
import types
from typing import TYPE_CHECKING, Dict, Literal, Optional, Union, cast

from fabric.analytics.environment.constant import STORAGE_SCOPE

from sempy.fabric._credentials import get_access_token
from sempy.fabric._environment import _get_onelake_abfss_path, _on_spark
from sempy.fabric._utils import SparkConfigTemporarily, try_import

if TYPE_CHECKING:
    import delta
    import deltalake
    import pandas as pd
    from pyspark.sql import SparkSession


def get_or_create_spark_session(config: Optional[Dict[str, str]] = None) -> "SparkSession":
    from pyspark.sql import SparkSession
    builder = SparkSession.builder
    if config:
        for k, v in config.items():
            builder = builder.config(k, v)
    return builder.getOrCreate()


def import_delta() -> types.ModuleType:
    """
    We have different runtimes (e.g. python/spark) which may have or have not installed delta. This function wraps
    a try-catch block for importing delta, and print more instructive error message for users if the import fails.
    """
    error_message = "Delta is not installed on current runtime, please run `%pip install delta-spark` and retry"
    return try_import("delta", error_message=error_message)


def import_deltalake() -> types.ModuleType:
    """
    We have different runtimes (e.g. python/spark) which may have or have not installed deltalake. This function wraps
    a try-catch block for importing deltalake, and print more instructive error message for users if the import fails.
    """
    error_message = "Deltalake is not installed on current runtime, please run `%pip install deltalake` and retry"
    return try_import("deltalake", error_message=error_message)


def import_notebookutils() -> types.ModuleType:
    """
    We have different runtimes (e.g. python/spark) which may have or have not installed notebookutils. This function wraps
    a try-catch block for importing notebookutils, and print more instructive error message for users if the import fails.
    """
    error_message = "notebookutils is not available on current runtime, this function can only be executed on Fabric notebooks."
    return try_import("notebookutils", error_message=error_message)


def get_delta_table_uri(table_name: str, workspace_id: Optional[str] = None, warehouse_id: Optional[str] = None) -> str:
    """
    Get the URI of a Delta Lake table in the specified lakehouse.

    Parameters
    ----------
    table_name : str
        The name of the Delta Lake table.
    workspace_id : str, default=None
        The workspace ID. Defaults to the current workspace ID.
    warehouse_id : str, default=None
        The warehouse ID. Defaults to the attached lakehouse ID.

    Returns
    -------
    str
        The URI of the Delta Lake table.
    """
    return _get_onelake_abfss_path(workspace_id=workspace_id, dataset_id=warehouse_id) + f"/Tables/{table_name}"


def get_delta_table_name(table_uri):
    """
    Parse the table name from a Delta Lake table URI
    (e.g. abfss://{workspace}@{account}.dfs.core.windows.net/{warehouse}/Tables/{table_name}).

    Parameters
    ----------
    table_uri : str
        The URI of the Delta Lake table.

    Returns
    -------
    str
        The name of the Delta Lake table.

    Raises
    ------
    ValueError
        If the table name cannot be parsed from the URI.
    """
    # Example: abfss://<filesystem>@<account>.dfs.core.windows.net/<path>/Tables/<table_name>
    match = re.search(r"/tables[/.]*/(?P<table_name>[^/]+)", table_uri, flags=re.IGNORECASE)
    if not match:
        raise ValueError(f"Cannot parse table name from table URI: {table_uri}")
    return match.group("table_name")


def read_delta_table(table_uri: Optional[str] = None,
                     table_name: Optional[str] = None,
                     workspace_id: Optional[str] = None,
                     warehouse_id: Optional[str] = None,
                     method: Optional[Literal["spark", "python"]] = None,
                     spark_config: Optional[Dict[str, str]] = None,
                     **kwargs) -> Union["deltalake.DeltaTable", "delta.DeltaTable"]:
    """
    Load a Delta Lake table from the current OneLake filesystem.

    Parameters
    ----------
    table_uri : str, default=None
        The URI of the Delta Lake table to write to. If not specified, table_name must be provided.
    table_name : str, optional
        The name of the Delta Lake table to write to. If not specified, table_uri must be provided.
    workspace_id : str, default=None
        The workspace ID. Defaults to the current workspace ID.
    warehouse_id : str, default=None
        The warehouse ID. Defaults to the attached lakehouse ID.
    method : str, optional
        The method to use for loading the Delta Lake table. Options are "spark" or "python".
        If not specified, the function will choose "spark" if running in a Spark environment, otherwise "python".
    spark_config : dict, default=None
        Additional Spark configurations to set temporarily during the write operation. Only used when method is "spark".
    **kwargs
        Additional keyword arguments to pass to delta.DeltaTable.forPath() or deltalake.DeltaTable.
    Returns
    -------
    deltalake.DeltaTable or delta.DeltaTable
        The loaded Delta Lake table.
    """
    table_uri = _resolve_table_uri(table_uri=table_uri, table_name=table_name,
                                   workspace_id=workspace_id, warehouse_id=warehouse_id)

    if method is None:
        if _on_spark():
            method = "spark"
        else:
            method = "python"

    if method == "spark":
        delta = import_delta()
        spark = get_or_create_spark_session(config=spark_config)
        return delta.DeltaTable.forPath(spark, table_uri, **kwargs)
    else:
        deltalake = import_deltalake()
        storage_options = kwargs.pop("storage_options", dict())
        storage_options.setdefault("bearer_token", get_access_token(STORAGE_SCOPE).token)
        return deltalake.DeltaTable(table_uri, storage_options=storage_options, **kwargs)


def write_delta_table(df: "pd.DataFrame",
                      table_uri: Optional[str] = None,
                      table_name: Optional[str] = None,
                      workspace_id: Optional[str] = None,
                      warehouse_id: Optional[str] = None,
                      method: Optional[Literal["spark", "python"]] = None,
                      spark_config: Optional[Dict[str, str]] = None,
                      spark_write_option: Optional[Dict[str, str]] = None,
                      **kwargs):
    """
    Write a Pandas DataFrame to a Delta Lake table in the current OneLake filesystem.

    Parameters
    ----------
    df : pandas.DataFrame
        The Pandas DataFrame to write.
    table_uri : str, default=None
        The URI of the Delta Lake table to write to. If not specified, table_name must be provided.
    table_name : str, optional
        The name of the Delta Lake table to write to. If not specified, table_uri must be provided.
    workspace_id : str, default=None
        The workspace ID. Defaults to the current workspace ID.
    warehouse_id : str, default=None
        The warehouse ID. Defaults to the attached lakehouse ID.
    method : str, default=None
        The method to use for writing the Delta Lake table. Options are "spark" or "python".
        If not specified, the function will choose "spark" if running in a Spark environment, otherwise "python".
    spark_config : dict, default=None
        Additional Spark configurations to set temporarily during the write operation. Only used when method is "spark".
    spark_write_option : dict, default=None
        Additional options to pass to the Spark DataFrameWriter. Only used when method is "spark".
    **kwargs
        Additional keyword arguments to pass to deltalake.write_deltalake() or
        pyspark.sql.DataFrameWriter.saveAsTable().
    """
    table_uri = _resolve_table_uri(table_uri=table_uri, table_name=table_name,
                                   workspace_id=workspace_id, warehouse_id=warehouse_id)

    if method is None:
        if _on_spark():
            method = "spark"
        else:
            method = "python"

    if method == "spark":
        # Adomd uses "1899-12-30" as a "zero date" following Excel/Access/SQL-Server going
        # back to Lotus 1-2-3 compatibility. We have little choice but to follow:
        #
        # https://stackoverflow.com/questions/3963617/why-is-1899-12-30-the-zero-date-in-access-sql-server-instead-of-12-31
        #
        #  Trying to write such a date fails on a default Spark installation with an exception:
        #
        #    Caused by: org.apache.spark.SparkUpgradeException: [INCONSISTENT_BEHAVIOR_CROSS_VERSION.WRITE_ANCIENT_DATETIME]
        #    You may get a different result due to the upgrading to Spark >= 3.0:
        #    writing dates before 1582-10-15 or timestamps before 1900-01-01T00:00:00Z
        #    into Parquet INT96 files can be dangerous, as the files may be read by Spark 2.x
        #    or legacy versions of Hive later, which uses a legacy hybrid calendar that
        #    is different from Spark 3.0+'s Proleptic Gregorian calendar. See more
        #    details in SPARK-31404. You can set "spark.sql.parquet.int96RebaseModeInWrite" to "LEGACY" to rebase the
        #    datetime values w.r.t. the calendar difference during writing, to get maximum
        #    interoperability. Or set the config to "CORRECTED" to write the datetime
        #    values as it is, if you are sure that the written files will only be read by
        #    Spark 3.0+ or other systems that use Proleptic Gregorian calendar.
        #
        # "spark.sql.parquet.int96RebaseModeInWrite" is not a static configuration, so it can be modified
        # during the session. Static configurations (such as delta extensions) have to be modified before
        # session is created. Fabric does not set this option as of November 2023:
        spark = get_or_create_spark_session()
        schema = kwargs.pop("schema", None)
        mode = kwargs.pop("mode", "error")

        spark_config = spark_config or dict()
        spark_config.setdefault("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED")
        spark_config.setdefault("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")

        with SparkConfigTemporarily(spark, spark_config):
            spark_df = spark.createDataFrame(df, schema=schema)
            write_op = (spark_df.write
                                .option("parquet.vorder.enabled", True)
                                .mode(mode)
                                .format("delta"))

            if spark_write_option:
                for k, v in spark_write_option.items():
                    write_op = write_op.option(k, v)

            if table_name is None:
                table_name = get_delta_table_name(table_uri)
            write_op.saveAsTable(table_name, **kwargs)
    else:
        deltalake = import_deltalake()
        storage_options = kwargs.pop("storage_options", dict())
        storage_options.setdefault("bearer_token", get_access_token(STORAGE_SCOPE).token)
        storage_options.setdefault("use_fabric_endpoint", "true")
        storage_options.setdefault("allow_unsafe_rename", "true")
        deltalake.write_deltalake(table_uri, df, storage_options=storage_options, **kwargs)


def vacuum_delta_table(path: str, retention_hours: Optional[float], method: Literal["spark", "python"]):
    dt: Union["deltalake.DeltaTable", "delta.DeltaTable"]
    if method == "spark":
        spark = get_or_create_spark_session()
        with SparkConfigTemporarily(spark, {"spark.databricks.delta.vacuum.parallelDelete.enabled": "true"}):
            dt = cast("delta.DeltaTable", read_delta_table(table_uri=path, method="spark"))
            dt.vacuum(retention_hours)
    else:
        dt = cast("deltalake.DeltaTable", read_delta_table(table_uri=path, method="python"))
        dt.vacuum(retention_hours=int(retention_hours) if retention_hours is not None else None)


def _resolve_table_uri(table_uri: Optional[str] = None, table_name: Optional[str] = None,
                       workspace_id: Optional[str] = None, warehouse_id: Optional[str] = None) -> str:
    if table_uri is None and table_name is None:
        raise ValueError("Either table_uri or table_name must be provided.")
    if table_uri is None:
        table_uri = get_delta_table_uri(str(table_name), workspace_id=workspace_id, warehouse_id=warehouse_id)
    return str(table_uri)
