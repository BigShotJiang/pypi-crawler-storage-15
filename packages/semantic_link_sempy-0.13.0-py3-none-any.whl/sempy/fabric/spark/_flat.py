from typing import TYPE_CHECKING, Any, Dict, Literal, Optional, Union
from uuid import UUID

from ..._utils._log import log
from .._cache import _get_or_create_workspace_client
from .._credentials import with_credential

if TYPE_CHECKING:
    from azure.core.credentials import TokenCredential


@log
@with_credential
def get_spark_settings(workspace: Optional[Union[str, UUID]] = None,
                       credential: Optional["TokenCredential"] = None) -> Dict[str, Any]:
    """
    Get the Spark settings for the specified workspace.

    This is a wrapper function for `Workspace Settings - Get Spark Settings <https://learn.microsoft.com/en-us/rest/api/fabric/spark/workspace-settings/get-spark-settings>`_.

    Parameters
    ----------
    workspace : str or uuid.UUID, default=None
        The Fabric workspace name or UUID object containing the workspace ID. Defaults to None
        which resolves to the workspace of the attached lakehouse
        or if no lakehouse attached, resolves to the workspace of the notebook.
    credential : TokenCredential, default=None
        The credential for token acquisition. Must be an instance of
        `azure.core.credentials.TokenCredential <https://learn.microsoft.com/en-us/azure/developer/python/sdk/authentication/overview>`_.
        If None, the default credential will be used.

    Returns
    -------
    Dict[str, Any]
        The Spark settings for the specified workspace.
    """
    return _get_or_create_workspace_client(workspace=workspace) \
        .get_spark_settings()


@log
@with_credential
def update_spark_settings(spark_settings: Dict[str, Any],
                          workspace: Optional[Union[str, UUID]] = None,
                          credential: Optional["TokenCredential"] = None) -> None:
    """
    Update the Spark settings for the specified workspace.

    This is a wrapper function for `Workspace Settings - Update Spark Settings <https://learn.microsoft.com/en-us/rest/api/fabric/spark/workspace-settings/update-spark-settings>`_.

    Parameters
    ----------
    spark_settings : Dict[str, Any]
        The Spark settings to update.
    workspace : str or uuid.UUID, default=None
        The Fabric workspace name or UUID object containing the workspace ID. Defaults to None
        which resolves to the workspace of the attached lakehouse
        or if no lakehouse attached, resolves to the workspace of the notebook.
    credential : TokenCredential, default=None
        The credential for token acquisition. Must be an instance of
        `azure.core.credentials.TokenCredential <https://learn.microsoft.com/en-us/azure/developer/python/sdk/authentication/overview>`_.
        If None, the default credential will be used.
    """
    _get_or_create_workspace_client(workspace=workspace) \
        .update_spark_settings(spark_settings)


@log
@with_credential
def get_fabric_runtime(workspace: Optional[Union[str, UUID]] = None,
                       credential: Optional["TokenCredential"] = None) -> str:
    """
    Get the default Fabric runtime version for the specified workspace.

    Parameters
    ----------
    workspace : str or uuid.UUID, default=None
        The Fabric workspace name or UUID object containing the workspace ID. Defaults to None
        which resolves to the workspace of the attached lakehouse
        or if no lakehouse attached, resolves to the workspace of the notebook.
    credential : TokenCredential, default=None
        The credential for token acquisition. Must be an instance of
        `azure.core.credentials.TokenCredential <https://learn.microsoft.com/en-us/azure/developer/python/sdk/authentication/overview>`_.
        If None, the default credential will be used.

    Returns
    -------
    str
        The Fabric runtime version for the specified workspace.
        See `Apache Spark Runtimes in Fabric <https://learn.microsoft.com/en-us/fabric/data-engineering/runtime>`__.
    """
    return _get_or_create_workspace_client(workspace=workspace) \
        .get_fabric_runtime()


@log
@with_credential
def set_fabric_runtime(runtime_version: Literal["1.1", "1.2", "1.3"],
                       workspace: Optional[Union[str, UUID]] = None,
                       credential: Optional["TokenCredential"] = None) -> None:
    """
    Set the default Fabric runtime version for the specified workspace.

    Parameters
    ----------
    runtime_version : Literal["1.1", "1.2", "1.3"]
        The Fabric runtime version to set. See `Apache Spark Runtimes in Fabric <https://learn.microsoft.com/en-us/fabric/data-engineering/runtime>`__.
    workspace : str or uuid.UUID, default=None
        The Fabric workspace name or UUID object containing the workspace ID. Defaults to None
        which resolves to the workspace of the attached lakehouse
        or if no lakehouse attached, resolves to the workspace of the notebook.
    credential : TokenCredential, default=None
        The credential for token acquisition. Must be an instance of
        `azure.core.credentials.TokenCredential <https://learn.microsoft.com/en-us/azure/developer/python/sdk/authentication/overview>`_.
        If None, the default credential will be used.
    """
    if runtime_version not in {"1.1", "1.2", "1.3"}:
        raise TypeError(f"Invalid `runtime_version` {runtime_version}. Must be one of '1.1', '1.2', or '1.3'")

    _get_or_create_workspace_client(workspace=workspace) \
        .set_fabric_runtime(runtime_version)
