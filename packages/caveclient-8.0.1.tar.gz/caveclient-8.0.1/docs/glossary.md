---
title: Glossary
---

!!! warning
    This glossary is a work in progress; for now we are documenting the commonly used 
    terms that we need to define. Please feel free to contribute definitions or 
    additional terms.

- Datastack
- Voxel resolution
- Segmentation resolution
- MIP
- Segmentation
- View
