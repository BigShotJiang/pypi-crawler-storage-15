---
title: client.info
---

::: caveclient.infoservice.InfoServiceClient
    options:
        heading_level: 2
        show_bases: false
