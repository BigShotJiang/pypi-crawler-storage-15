---
title: client.annotation
---

::: caveclient.annotationengine.AnnotationClient
    options:
        heading_level: 2
        show_bases: false
        filters: ["!__init__"]
        docstring_options:
            ignore_init_summary: false
        merge_init_into_class: false
        <!-- show_docstring_parameters: false -->
