---
title: caveclient.CAVEclient
---

::: caveclient.frameworkclient.CAVEclientFull
    options:
        show_bases: false
        merge_init_into_class: true