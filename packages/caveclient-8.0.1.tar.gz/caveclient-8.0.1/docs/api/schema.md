---
title: client.schema
---

::: caveclient.emannotationschemas.SchemaClient
    options:
        heading_level: 2
        show_bases: false
