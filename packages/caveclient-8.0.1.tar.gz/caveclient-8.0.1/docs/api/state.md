---
title: client.state
---

::: caveclient.jsonservice.JSONService
    options:
        heading_level: 2
        show_bases: false
