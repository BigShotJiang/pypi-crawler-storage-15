---
title: client.skeleton
---

::: caveclient.skeletonservice.SkeletonClient
    options:
        heading_level: 2
        show_bases: false
        members: ['server_version', 'get_skeleton', 'get_cache_contents', 'skeletons_exist', 'get_bulk_skeletons', 'generate_bulk_skeletons_async']
