---
title: client.auth
---

::: caveclient.auth.AuthClient
    options:
        heading_level: 2
        show_bases: false
        filters: ["!__init__"]
        merge_init_into_class: false
