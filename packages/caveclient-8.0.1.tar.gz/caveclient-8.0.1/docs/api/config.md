---
title: Configuration
---

::: caveclient.set_session_defaults
    options:
        show_root_heading: true

::: caveclient.get_session_defaults
    options:
        show_root_heading: true