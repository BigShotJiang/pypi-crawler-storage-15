"""
mcp-liner: MCP Server for Liner configuration generation.
"""
