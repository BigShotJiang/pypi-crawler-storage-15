"""Logic for setting up build pipelines"""
