""" Execute the application package of a published experiment on a subset of input data
to verify the reproducibility is achieved"""
