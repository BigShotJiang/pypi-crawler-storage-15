from twilio.base.version import Version


class TokenManager:

    def fetch_access_token(self, version: Version):
        pass
