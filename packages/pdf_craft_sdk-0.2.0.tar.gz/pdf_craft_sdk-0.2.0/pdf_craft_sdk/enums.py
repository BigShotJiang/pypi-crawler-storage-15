from enum import Enum

class FormatType(Enum):
    MARKDOWN = "markdown"
    EPUB = "epub"
