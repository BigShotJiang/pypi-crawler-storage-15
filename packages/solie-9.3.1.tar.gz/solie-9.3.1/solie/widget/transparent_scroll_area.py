"""Transparent scroll area widget."""

from PySide6.QtWidgets import QScrollArea


class TransparentScrollArea(QScrollArea):
    """Scroll area with transparent background."""

