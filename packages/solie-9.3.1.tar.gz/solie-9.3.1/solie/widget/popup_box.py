"""Styled popup box widget."""

from PySide6.QtWidgets import QGroupBox


class PopupBox(QGroupBox):
    """Styled group box for popups."""

