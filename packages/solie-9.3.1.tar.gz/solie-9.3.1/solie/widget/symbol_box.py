"""Symbol box widget for displaying trading pair information."""

from PySide6.QtWidgets import QGroupBox


class SymbolBox(QGroupBox):
    """Styled group box for symbol display."""

