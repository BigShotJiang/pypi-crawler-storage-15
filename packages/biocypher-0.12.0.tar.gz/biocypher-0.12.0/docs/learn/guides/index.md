!!! warning "Under Construction"

    This section is currently under construction.

1. [How do I create a standalone Docker image for a BioCypher KG?](htg001_standalone_docker_biocypher.md)

2. How do I use or create an Adapter to read data?

3. How do I combine data from different Adapters?

4. How do I create a graph from a CSV file

5. How do I convert a graph to a Pandas Dataframe?

6. How do I create a complete pipeline (from CSV file to Neo4j)

7. How do I configure BioCypher

8. How do I define a Schema for my Graph
