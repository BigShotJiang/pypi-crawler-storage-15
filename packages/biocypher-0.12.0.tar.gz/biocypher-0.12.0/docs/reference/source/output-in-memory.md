## In-Memory Knowledge Graph Retrieval

::: biocypher.output.in_memory._get_in_memory_kg.get_in_memory_kg

## In-Memory Knowledge Graph Base Class

::: biocypher.output.in_memory._in_memory_kg._InMemoryKG

## Pandas Knowledge Graph

::: biocypher.output.in_memory._pandas.PandasKG

## NetworkX Knowledge Graph

::: biocypher.output.in_memory._networkx.NetworkxKG
