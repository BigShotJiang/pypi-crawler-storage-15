## Ontology Base Class

::: biocypher._ontology.Ontology

## Ontology Adapter

::: biocypher._ontology.OntologyAdapter

## Mapping of data inputs to KG ontology

::: biocypher._mapping.OntologyMapping
