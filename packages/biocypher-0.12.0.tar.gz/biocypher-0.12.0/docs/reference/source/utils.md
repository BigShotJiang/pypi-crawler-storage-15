::: biocypher._misc.to_list
::: biocypher._misc.ensure_iterable
::: biocypher._misc.create_tree_visualisation
::: biocypher._misc.from_pascal
::: biocypher._misc.pascalcase_to_sentencecase
::: biocypher._misc.snakecase_to_sentencecase
::: biocypher._misc.sentencecase_to_snakecase
::: biocypher._misc.sentencecase_to_pascalcase
