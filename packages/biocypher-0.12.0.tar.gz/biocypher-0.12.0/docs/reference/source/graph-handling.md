## BioCypher Node

::: biocypher._create.BioCypherNode

## BioCypher Edge

::: biocypher._create.BioCypherEdge

## BioCypher RelAsNode

::: biocypher._create.BioCypherRelAsNode
