def make_bib_author(authors):
    """Make author list from."""

    bib_author_text = ""

    for i, author in enumerate(authors):
        if i > 0:
            bib_author_text += " and " + author['family'] + ", " + author['given']
        else:
            bib_author_text += author['family'] + ", " + author['given']

    return bib_author_text


def make_bib_id(authors, year):
    """Make ID from last name and year"""

    return authors[0]['family'] + "_" + year


def make_bib(document, bibtype):
    """Make BibTeX from documents."""

    bibtmp = {"type": bibtype,
              "id": make_bib_id(document['author'], document['year'])}
    bib_text = "@{type}{{{id}"

    # going through potential required fields
    for key in ["author", "editor", "institution", "publisher", "school", "title", "year"]:
        if key in document:

            # handle authors uniquely
            if key == "author":
                bibtmp['author'] = make_bib_author(document[key])
            else:
                bibtmp[key] = document[key]

            bib_text += ", " + key + "={{{" + key + "}}}"

    bib_text += "}}"

    return bib_text.format(**bibtmp), bibtmp


#  ──────────────────────────────────────────────────────────────────────────
# universal

doc = {"author": [{"family": "",
                   "given": ""}
                  ],
       "title": "",
       "year": "",
       }

parent = {}


#  ──────────────────────────────────────────────────────────────────────────
# article

parent['article'] = {"journal": "",
                     }


#  ──────────────────────────────────────────────────────────────────────────
# book

parent['book'] = {"editor": "",
                  "publisher": "",
                  }


#  ──────────────────────────────────────────────────────────────────────────
# conference paper

parent['conference'] = {"booktitle": "",
                        "publisher": "",
                        }


#  ──────────────────────────────────────────────────────────────────────────
# inbook

parent['inbook'] = {"chapter": "",
                    "publisher": "",
                    }


#  ──────────────────────────────────────────────────────────────────────────
# manual

parent['manual'] = {"organization": "",
                    "address": "",
                    }


#  ──────────────────────────────────────────────────────────────────────────
# masterthesis

parent['masterthesis'] = {"school": "",
                          }

#  ──────────────────────────────────────────────────────────────────────────
# misc

parent['misc'] = {"howpublished": "",
                  }


#  ──────────────────────────────────────────────────────────────────────────
# phdthesis

parent['phdthesis'] = {"school": "",
                       }


#  ──────────────────────────────────────────────────────────────────────────
# techreport

parent['techreport'] = {"institution": "",
                        }
