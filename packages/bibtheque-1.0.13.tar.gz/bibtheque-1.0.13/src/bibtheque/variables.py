import importlib.metadata


bibtheque_version = importlib.metadata.version('bibtheque')
CONTEXT_SETTINGS = dict(help_option_names=['-h', '--help'])
