# 参考文献


```{rubric} 核心文献
```

```{bibliography} ../_static/references/book.bib
```

```{rubric} 其他文献
```

```{bibliography} ../_static/references/articles.bib
```
