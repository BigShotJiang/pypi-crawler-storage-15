----
title: Formalizing XState applications
description: Tutorial and recommendations for formalizing XState library applications, reasoning about them and generating test cases
order: 3
----

### Tutorial on how to formalize XState TypeScript code in IML 

#### Formalization steps
