"""
Sample Math Library - A pure Python mathematical computation library.
"""

__version__ = "1.0.0"
__author__ = "Sample Author"
