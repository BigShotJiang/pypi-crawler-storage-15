"""LangChain integration hooks for AGENTICONTROL."""

