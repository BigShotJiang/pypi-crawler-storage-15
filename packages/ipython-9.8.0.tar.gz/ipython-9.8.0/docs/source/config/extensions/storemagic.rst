.. _extensions_storemagic:

==========
storemagic
==========

.. automodule:: IPython.extensions.storemagic

.. automethod:: StoreMagics.store
