.. _terminal_options:

Terminal options
================

Any of the options listed here can be set in config files, at the
command line, from inside IPython, or using a traitlets :class:`Config` object.
See :ref:`setting_config` for details.

.. include:: terminal.rst
