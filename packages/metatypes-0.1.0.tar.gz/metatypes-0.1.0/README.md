# A Meta-Type System for Python: An Expressive Library for Static Typing

> 🛠️ **Note:** This package is a work in progress. If you’d like to contribute or discuss ideas, feel free to reach out on Telegram [@iliyasone](https://t.me/iliyasone) or by email: [iliyas.dzabbarov@gmail.com](mailto:iliyas.dzabbarov@gmail.com).

> 🚧 For now, this repository serves as the homepage for my thesis. Later it will become a standalone library and a mypy plugin.

#### Abstarct

## 1. Introduction

## 2. Literature Review 