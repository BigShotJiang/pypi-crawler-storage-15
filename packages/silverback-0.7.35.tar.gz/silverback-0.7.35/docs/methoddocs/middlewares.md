# silverback.middlewares

The `silverback.middlewares` module contains middleware intended to improve the usability of
silverback as a whole, and add integrations for the silverback platform as well.

```{eval-rst}
.. automodule:: silverback.middlewares
    :members:
    :show-inheritance:
```
