# silverback.state

The `silverback.state` module contains modules for loading an unloading the shared memory for a
Silverback bot, which can be loaded from a persistent store and snapshotted at regular intervals.

```{eval-rst}
.. automodule:: silverback.state
    :members:
    :show-inheritance:
```
