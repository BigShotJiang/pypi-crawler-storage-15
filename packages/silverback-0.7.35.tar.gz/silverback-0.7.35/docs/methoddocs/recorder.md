# silverback.recorder

The `silverback.recorder` module contains classes that hook into the Runner's recording features
when executing a Silverback bot, which is meant to journal runtime metrics to a persistent store.

```{eval-rst}
.. automodule:: silverback.recorder
    :members:
    :show-inheritance:
```
