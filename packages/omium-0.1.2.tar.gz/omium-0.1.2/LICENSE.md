# Proprietary License

Copyright (c) 2025 Omium.

All rights reserved. The Omium Python SDK is proprietary software. You may not copy,
modify, merge, publish, distribute, sublicense, and/or sell copies of the SDK
except as explicitly permitted in writing by Omium.

