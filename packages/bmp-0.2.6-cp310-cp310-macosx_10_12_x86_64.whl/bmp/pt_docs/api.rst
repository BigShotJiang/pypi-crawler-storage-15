BMP API Reference
==============================================

.. autoclass:: bmp.pyterrier.BmpIndex
   :members:

.. autoclass:: bmp.pyterrier.BmpIndexer
   :members:

.. autoclass:: bmp.pyterrier.BmpRetriever
   :members:
