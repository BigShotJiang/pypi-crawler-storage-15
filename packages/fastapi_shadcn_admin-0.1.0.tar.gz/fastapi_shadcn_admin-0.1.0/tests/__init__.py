"""Tests package for fastapi-shadcn-admin"""
