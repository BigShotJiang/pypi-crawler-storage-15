"""Example projspec apps, based on qt

See also ``ipywidget`` or ``panel`` implementations, when they are ready.
"""
