"""module to convert from Fluo-Tomo (tiff files) to `NXtomo <https://manual.nexusformat.org/classes/applications/NXtomo.html>`_"""
