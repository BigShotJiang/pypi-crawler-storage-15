"""Test suite for drudge CLI."""
