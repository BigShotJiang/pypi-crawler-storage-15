# aya_ha_debugger

A friendly Python helper that brings the signature "aya ha" vibe to your debugger sessions.

## Usage
```python
from aya_ha_debugger import aya_ha

aya_ha()
# -> prints "aya ha"
```
