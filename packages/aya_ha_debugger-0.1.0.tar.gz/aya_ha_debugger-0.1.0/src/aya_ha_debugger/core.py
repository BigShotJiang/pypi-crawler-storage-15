


def aya_ha(kisme_aya: str = "") -> str:
    if not kisme_aya:
        print("***** aya ha *****")
    else:
        print(f"***** {kisme_aya} me aya ha *****")