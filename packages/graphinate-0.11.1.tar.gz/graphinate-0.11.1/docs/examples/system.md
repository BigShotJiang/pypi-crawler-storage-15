# System

## Processes

=== "Processes"

    ``` python title="examples/system/processes.py" linenums="1"
    --8<-- "examples/system/processes.py"
    ```

=== "Dependencies"

    ``` text title="examples/system/requirements.txt" linenums="1"
    --8<-- "examples/system/requirements.txt"
    ```