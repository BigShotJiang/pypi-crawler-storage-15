# Social

## Music Artists

=== "Music Artists"

    ``` python title="examples/social/music_artists.py" linenums="1"
    --8<-- "examples/social/music_artists.py"
    ```

=== "Dependencies"

    ``` text title="examples/social/requirements.txt" linenums="1"
    --8<-- "examples/social/requirements.txt"
    ```