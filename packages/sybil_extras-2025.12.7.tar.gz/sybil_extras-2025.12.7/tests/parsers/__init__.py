"""
Tests for custom parsers.
"""
