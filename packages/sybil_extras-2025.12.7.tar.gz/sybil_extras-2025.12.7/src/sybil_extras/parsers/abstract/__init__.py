"""
Abstract parsers.
"""
