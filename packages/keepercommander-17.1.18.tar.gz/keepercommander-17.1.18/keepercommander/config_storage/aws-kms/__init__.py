from .aws_keyservice import KeyManagementService as SecureStorage

__all__ = ['SecureStorage']