This module is a general e-commerce connector which can be used to
integrate any e-commerce with Odoo. It allows to import sale orders from
an external e-commerce into Odoo, invoice those sales and create
contacts and products if needed.
