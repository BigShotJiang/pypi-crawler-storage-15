from smartpush.base.request_base import FormRequestBase


class FormClientOperation(FormRequestBase):
    """
    表单曝光事件埋点上报
    """

    """
    表单点击事件埋点上报
    """

    """
    填写提交表单
    """

    """
    C端使用表单折扣码进行下单
    """