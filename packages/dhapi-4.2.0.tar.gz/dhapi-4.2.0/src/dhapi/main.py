from dhapi.router.router import entrypoint


def main():
    entrypoint()


if __name__ == "__main__":
    entrypoint()
