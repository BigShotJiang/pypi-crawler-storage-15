# CHANGELOG

<!-- version list -->

## v1.0.0 (2025-12-05)

- Initial Release

## v1.0.0 (2025-12-05)

- Initial Release
