class SchemaRegistryRequestParsingError(Exception):
    """This class is used to define exception which occurs due to schema registry inference"""
