__version__ = "1.0.0"
PROJECT_PACKAGE_URL = "https://github.com/narramukhesh/projectone"
