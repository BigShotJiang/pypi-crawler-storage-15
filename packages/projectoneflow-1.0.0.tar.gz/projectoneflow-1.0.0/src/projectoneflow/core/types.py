from typing import TypeVar
from types import FunctionType

F = FunctionType
R = TypeVar("R")
C = TypeVar("C")
CT = TypeVar("CT")
ST = TypeVar("ST")
RP = TypeVar("RP")
SM = TypeVar("SM")
SI = TypeVar("SI")
SO = TypeVar("SO")
RO = TypeVar("RO")
CO = TypeVar("CO")
