from gw.enums import GwStrEnum


class RelayEventBase(GwStrEnum): ...
