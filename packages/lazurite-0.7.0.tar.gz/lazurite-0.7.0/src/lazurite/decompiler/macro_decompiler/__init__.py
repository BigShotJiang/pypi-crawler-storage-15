from .macro_decompiler import restore_code, InputVariant
