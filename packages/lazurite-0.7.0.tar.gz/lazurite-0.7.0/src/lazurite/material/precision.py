from enum import Enum


class Precision(Enum):
    none = None
    lowp = 0
    mediump = 1
    highp = 2
