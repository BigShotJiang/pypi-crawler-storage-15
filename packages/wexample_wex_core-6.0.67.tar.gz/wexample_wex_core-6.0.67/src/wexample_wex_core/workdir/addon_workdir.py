from __future__ import annotations

from wexample_wex_core.workdir.workdir import Workdir


class AddonWorkdir(Workdir):
    pass
