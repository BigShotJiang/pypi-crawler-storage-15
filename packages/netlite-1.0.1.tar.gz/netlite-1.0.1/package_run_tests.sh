pytest tests/ -v
