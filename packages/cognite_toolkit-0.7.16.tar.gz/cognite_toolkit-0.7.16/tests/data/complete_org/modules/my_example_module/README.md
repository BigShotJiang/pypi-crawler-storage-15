# README.md

This is an example of a custom module. It contains two TimeSeries with a dataset.
