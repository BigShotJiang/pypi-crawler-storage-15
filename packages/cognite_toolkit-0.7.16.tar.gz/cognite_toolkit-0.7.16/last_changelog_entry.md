## Changelog 

### Changed

- Removed hidden command