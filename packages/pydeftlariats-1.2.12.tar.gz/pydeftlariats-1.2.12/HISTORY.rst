=======
History
=======

0.0.1 (2021-05-29)
------------------

* First release on PyPI.


0.0.6 (2021-05-30)
------------------
* Basic set of Text & Number matchers

1.0.0 (2021-05-30)
------------------
* Better testing and refactoring in the spirit of DRY

1.1.0 (2021-05-30)
------------------
* Adding existence logic: None, NotNone, NoneOrEmpty, NotNoneOrEmpty


1.1.3 (2021-05-30)
------------------
* Added options to convert None to int value for numeric comparisons

