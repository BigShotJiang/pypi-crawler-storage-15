===================
Python Deft Lariats
===================


.. image:: https://img.shields.io/pypi/v/src.svg
        :target: https://pypi.python.org/pypi/src

.. image:: https://img.shields.io/travis/mcmasty/src.svg
        :target: https://travis-ci.com/mcmasty/src

.. image:: https://readthedocs.org/projects/src/badge/?version=latest
        :target: https://pydeftlariats.readthedocs.io/en/latest/?version=latest
        :alt: Documentation Status




Using PyHamcrest to build a collection of data filters.

"Deft Lariats" is an anagram of "Data Filters". The name is paying homage to
`"hamcrest" <https://github.com/hamcrest/PyHamcrest>`_ being an anagram of "matchers" since this project heavily
relies on hamcrest.


The project is wrapping the hamcrest matchers to use as data filters.


* Free software: GNU General Public License v3
* Documentation: https://pydeftlariats.readthedocs.io/.


Features
--------

* TODO
*   Build CLI
*   Build Sample Applications

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
