# deftlariat.entrypoints package

## Submodules

## deftlariat.entrypoints.cli module

```{eval-rst}
.. automodule:: deftlariat.entrypoints.cli
   :members:
   :undoc-members:
   :show-inheritance:
```

## Module contents

```{eval-rst}
.. automodule:: deftlariat.entrypoints
   :members:
   :undoc-members:
   :show-inheritance:
```
