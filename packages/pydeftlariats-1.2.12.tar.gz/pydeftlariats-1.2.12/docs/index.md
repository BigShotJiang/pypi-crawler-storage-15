# Deft Lariats  (Data Filters)


# Some tihng here  
***  
```{include} ../README.md
:relative-images:
```

# and Tble here
```{toctree}
:caption: 'Contents:'
:maxdepth: 2

readme
installation
usage
modules
contributing
authors
history
```



# Indices and tables

- {ref}`genindex`
- {ref}`modindex`
- {ref}`search`
