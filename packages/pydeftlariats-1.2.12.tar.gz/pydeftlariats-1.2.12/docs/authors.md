```{eval-rst}
.. include:: ../AUTHORS.rst
```
