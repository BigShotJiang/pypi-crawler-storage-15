# deftlariat package

## Subpackages

```{toctree}
:maxdepth: 4

deftlariat.entrypoints
```

## Submodules

## deftlariat.core module

```{eval-rst}
.. automodule:: deftlariat.core
   :members:
   :undoc-members:
   :show-inheritance:
```

## Module contents

```{eval-rst}
.. automodule:: deftlariat
   :members:
   :undoc-members:
   :show-inheritance:
```
