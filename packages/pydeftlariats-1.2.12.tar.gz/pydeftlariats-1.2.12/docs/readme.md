```{eval-rst}
.. include:: ../README.rst
```
