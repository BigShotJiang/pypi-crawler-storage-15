# Usage

To use Python Deft Lariats in a project:

```
import deftlariat
```
