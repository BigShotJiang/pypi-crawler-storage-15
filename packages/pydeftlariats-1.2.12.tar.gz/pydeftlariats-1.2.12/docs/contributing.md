```{eval-rst}
.. include:: ../CONTRIBUTING.rst
```
