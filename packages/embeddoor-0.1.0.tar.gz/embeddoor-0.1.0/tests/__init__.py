"""Test configuration."""

import pytest
