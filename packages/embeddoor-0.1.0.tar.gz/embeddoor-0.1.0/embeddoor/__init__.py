"""Embeddoor - A browser-based embedding visualization and analysis tool."""

__version__ = "0.1.0"
__author__ = "Your Name"
__license__ = "MIT"

from embeddoor.app import create_app

__all__ = ["create_app"]
