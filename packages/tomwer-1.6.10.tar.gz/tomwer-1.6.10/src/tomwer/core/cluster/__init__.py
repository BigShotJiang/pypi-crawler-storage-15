"""cluster related functions and classes (slurm...)"""

from .cluster import SlurmClusterConfiguration  # noqa F401
