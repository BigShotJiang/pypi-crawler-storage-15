"""Widgets to define the configuration level we want to display (display only basic configuration/settings, advance...)"""
