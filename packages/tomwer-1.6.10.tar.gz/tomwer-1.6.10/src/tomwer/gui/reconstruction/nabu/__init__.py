from .slices import NabuWidget  # noqa F401
