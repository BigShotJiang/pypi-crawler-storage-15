"""
Deprecated tomwer widgets
"""

NAME = "Deprecated tools"

ID = "orangecontrib.tomwer.widgets.deprecated"

DESCRIPTION = "Some deprecated widgets that will disappear soon"

LONG_DESCRIPTION = DESCRIPTION

ICON = "../../widgets/icons/deprecated.png"

BACKGROUND = "#C0CCFF"

PRIORITY = 99
