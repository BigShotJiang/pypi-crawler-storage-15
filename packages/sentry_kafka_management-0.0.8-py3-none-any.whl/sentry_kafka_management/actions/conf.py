# Shared configuration globals used by actions
KAFKA_TIMEOUT = 5
