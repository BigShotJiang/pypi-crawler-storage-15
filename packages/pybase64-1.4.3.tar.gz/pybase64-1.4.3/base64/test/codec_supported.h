extern char **codecs;

int codec_supported (size_t index);
