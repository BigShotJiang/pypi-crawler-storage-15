def main() -> None:
    print("Hello from prime-uve!")
