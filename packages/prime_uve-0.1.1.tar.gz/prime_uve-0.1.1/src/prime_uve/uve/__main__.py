"""Entry point for python -m prime_uve.uve."""

from .wrapper import main

if __name__ == "__main__":
    main()
