from .instrumentation import initialize_telemetry

__all__ = ["initialize_telemetry"]
