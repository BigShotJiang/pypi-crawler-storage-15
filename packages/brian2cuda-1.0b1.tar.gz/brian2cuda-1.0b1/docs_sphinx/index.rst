Brian2CUDA documentation
========================

.. toctree::
   :maxdepth: 2
   :titlesonly:

   introduction/index
   introduction/install
   introduction/cuda_configuration
   introduction/known_issues
   introduction/preferences
   introduction/performance


.. toctree::
   :maxdepth: 1
   :titlesonly:

   Reference documentation <reference/brian2cuda>
   examples/index

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
