Performance considerations
==========================

Check out our `Brian2CUDA paper`_ for performance benchmarks and discussions.

If you have performance questions or want to share your experience with Brian2CUDA
performance, feel free to post on the `Brian2 discourse forum`_.


.. _Brian2 discourse forum: https://brian.discourse.group/
.. _Brian2CUDA paper: https://www.frontiersin.org/articles/10.3389/fninf.2022.883700/abstract
