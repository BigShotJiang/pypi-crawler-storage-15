Brian2CUDA specific preferences
===============================

For information on the Brian2 preference system, read `Brian2 preference
documentation`_. The following Brian2CUDA preferences are used in the same way.

.. _Brian2 preference documentation: https://brian2.readthedocs.io/en/stable/advanced/preferences.html

List of preferences
-------------------

.. _prefs_cuda_standalone:
.. document_brian_prefs:: devices.cuda_standalone

.. _prefs_cuda_backend:
.. document_brian_prefs:: devices.cuda_standalone.cuda_backend
