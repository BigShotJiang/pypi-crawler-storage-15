#!/usr/bin/env bash

convert *_cpp.png +append all_cpp_plots.png
convert *_cuda.png +append all_cuda_plots.png