__host__ __device__ double foo(const double, const double);
