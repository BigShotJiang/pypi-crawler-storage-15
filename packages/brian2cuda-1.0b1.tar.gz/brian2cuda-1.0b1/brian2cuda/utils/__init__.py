'''
Utility functions for Brian2CUDA
'''
from .logger import *
from .stringtools import *
