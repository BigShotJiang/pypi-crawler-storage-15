class BaseCommand:
    def run(self, ctx):
        return
