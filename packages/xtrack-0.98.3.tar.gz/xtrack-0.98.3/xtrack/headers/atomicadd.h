// copyright ################################# //
// This file is part of the Xtrack Package.    //
// Copyright (c) CERN, 2025.                   //
// ########################################### //

#ifndef XTRACK_ATOMICADD_H_DEPRECATED
#define XTRACK_ATOMICADD_H_DEPRECATED

// The xtrack/headers/atomicadd.h header is deprecated. Use xobjects/headers/atomicadd.h instead.

#include "xobjects/headers/atomicadd.h"

#endif // XTRACK_ATOMICADD_H_DEPRECATED
