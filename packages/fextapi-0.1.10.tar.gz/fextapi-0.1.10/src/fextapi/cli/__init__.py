"""CLI module for fextapi."""
