"""fextapi - File-system based routing for FastAPI."""

__version__ = "0.1.0"

from fextapi.router.registry import init

__all__ = ["init", "__version__"]
