"""Router module for fextapi."""
