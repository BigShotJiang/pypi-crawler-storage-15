"""Utility module for fextapi."""
