"""
Generator Services テスト用 __init__.py
"""
