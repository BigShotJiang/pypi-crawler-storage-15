"use client";

import { ReactNode } from "react";
import { LineagePage } from "@/components/lineage/LineagePage";

export default function LineageRoutingPage(): ReactNode {
  return <LineagePage />;
}
