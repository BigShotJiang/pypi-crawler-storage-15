"use client";

import { ReactNode } from "react";
import { QueryPage } from "@/components/query/QueryPage";

export default function QueryRoutingPage(): ReactNode {
  return <QueryPage />;
}
