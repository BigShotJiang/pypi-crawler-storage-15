"""
Generic Lambda handler for generating presigned upload URLs.

Copyright 2024-2025 Geek Cafe, LLC
MIT License. See Project Root for the license information.
"""

from typing import Dict, Any, Optional
from geek_cafe_saas_sdk.lambda_handlers import create_handler, LambdaEvent
from geek_cafe_saas_sdk.modules.files.services.s3_file_service import S3FileService
from geek_cafe_saas_sdk.utilities.response import error_response, success_response
from geek_cafe_saas_sdk.core.service_result import ServiceResult
from geek_cafe_saas_sdk.core.error_codes import ErrorCode
import uuid
import os


# Create handler wrapper (defaults to secure auth)
handler_wrapper = create_handler(
    service_class=S3FileService,
    require_body=True,
    convert_request_case=True
)


def lambda_handler(event: Dict[str, Any], context: Any, injected_service=None) -> Dict[str, Any]:
    """
    Generate presigned URL for file upload.
    
    Args:
        event: Lambda event from API Gateway
        context: Lambda context
        injected_service: Optional S3FileService for testing
    
    Expected body (camelCase from frontend):
    {
        "fileName": "data.xlsx",
        "fileType": "analysis-input",  // Optional, for folder organization
        "contentType": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",  // Optional
        "expiresIn": 300  // Optional, defaults to 300 seconds
    }
    
    Returns 200 with presigned URL details
    """
    return handler_wrapper.execute(event, context, generate_upload_url_logic, injected_service)


def generate_upload_url_logic(
    event: LambdaEvent,
    service: S3FileService
) -> ServiceResult:
    """Business logic for generating presigned upload URLs."""
    payload = event.body()
    
    # Get user context from authorizer claims in request context
    request_context = event.request_context()
    authorizer = request_context.get("authorizer", {})
    claims = authorizer.get("claims", {})
    tenant_id = claims.get("custom:tenant_id")
    user_id = claims.get("custom:user_id")
    
    # Extract required fields (snake_case after convert_request_case)
    file_name = payload.get("file_name")
    if not file_name:
        return ServiceResult.error_result(
            message="file_name is required",
            error_code=ErrorCode.VALIDATION_ERROR
        )
    
    # Extract optional fields (snake_case after convert_request_case)
    file_type = payload.get("file_type", "general")
    content_type = payload.get("content_type")
    expires_in = payload.get("expires_in")
    
    # Generate unique file ID and key path
    file_id = str(uuid.uuid4())
    
    # Create organized path: tenants/{tenant_id}/users/{user_id}/uploads/{file_type}/{file_id}/{file_name}
    key_parts = [
        "tenants",
        tenant_id,
        "users", 
        user_id,
        "uploads",
        file_type,
        file_id,
        file_name
    ]
    key = "/".join(key_parts)
    
    # Add metadata for tracking
    metadata = {
        "tenant_id": tenant_id,
        "user_id": user_id,
        "file_type": file_type,
        "original_file_name": file_name,
        "file_id": file_id
    }
    
    # Generate presigned URL
    result = service.generate_presigned_upload_url(
        key=key,
        file_name=file_name,
        expires_in=expires_in,
        content_type=content_type,
        metadata=metadata
    )
    
    if not result.success:
        return result
    
    # Build response with file tracking info
    presigned_data = result.data
    response_data = {
        "file_id": file_id,
        "file_name": file_name,
        "file_type": file_type,
        "key": key,
        "presigned_url": presigned_data.get("url"),
        "presigned_fields": presigned_data.get("fields"),
        "expires_in": presigned_data.get("expires_in"),
        "expires_at": presigned_data.get("expires_at"),
        "method": "POST" if presigned_data.get("fields") else "PUT"
    }
    
    return ServiceResult.success_result(data=response_data)
