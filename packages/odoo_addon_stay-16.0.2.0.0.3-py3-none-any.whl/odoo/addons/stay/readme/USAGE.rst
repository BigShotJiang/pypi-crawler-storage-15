To use this module, go to the menu *Stays > Stays > Stays* and start to register the future stays.

Every day, start the wizard *Stays > Stays > Generate Journal* to generate the stay lines for the next day. You can then print the stay report via the wizard *Stays > Reports > Print Journal* to have a printed paper that you can give to the cook for example.
