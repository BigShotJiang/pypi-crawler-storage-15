To configure this module, you need to:

 * create the Rooms,
 * create the Groups (optional),
 * create the Refectories,

Then, go to the Stay configuration page:

 * configure the default Refectory,
 * if you want to manage breakfast, check the corresponding option.
