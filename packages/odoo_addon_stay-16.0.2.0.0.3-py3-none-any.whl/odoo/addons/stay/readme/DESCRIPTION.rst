This module manages stays ; it handles lunches, dinners and bed nights. It allows the booking of rooms and dormitories with capacity check.

It has been initially developped by the `Barroux Abbey <https://www.barroux.org/>`_ to manage the stays of the guests at the abbey and has been adopted by several other French abbeys.
