# """CLI entrypoint for evaluator."""
# from .main import main  # noqa: F401

# __all__ = ["main"]
