"""Contains types and logic for the conversion of predefined input formats to OpenADR3 entities."""
