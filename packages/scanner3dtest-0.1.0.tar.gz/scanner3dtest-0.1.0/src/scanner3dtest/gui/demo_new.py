from pathlib import Path
from dataclasses import dataclass
from typing import Optional
import numpy as np
from scanner3dtest.demo.demo_base import DemoBase
from scanner3d.test.base.test_factory import fft_psf_quick
from scanner3d.test.base.albums import album_major_frame_3
import matplotlib.pyplot as plt
from pathlib import Path
from scanner3d.afs.album import Album
from allytools.logger import get_logger

@dataclass
class DemoStep:
    title: str
    text: str
    image: Optional[np.ndarray] = None  # RGB image (H, W, 3), or None


class DemoFftPsf(DemoBase):
    def __init__(self) -> None:
        super().__init__(required_analysis=fft_psf_quick,
                         required_settings=album_major_frame_3)

    def iter_steps(self, file_path: Path):
        # 1) Load album
        album = Album.load(file_path)
        yield DemoStep(
            title="Load album",
            text=f"Loaded album from {file_path}\n\n{album!r}",
        )

        camera = album.camera_ref.resolve()
        yield DemoStep(
            title="Restore camera",
            text=f"Restored camera:\n{camera!r}",
        )

        # 2) Select frame
        z_middle = camera.z_range.mid_mm
        frame = album[z_middle]
        text = (
            f"Selected frame at z = {frame.z.value_mm:.3f} mm\n"
            f"Requested z = {z_middle:.3f} mm\n"
            f"Frame meta:\n{frame.meta!r}"
        )
        frame_img = frame.plot(fig_size_in=(2, 2))
        rgb_frame = frame_img.to_numpy("rgb8")
        yield DemoStep(
            title="Select frame",
            text=text,
            image=rgb_frame,
        )

        # 3) Select shot
        n_cols = len(frame.x_seq)
        n_rows = len(frame.y_seq)
        col = n_cols - 1
        row = n_rows - 1
        shot = frame[row, col]
        text = (
            f"Selected shot at grid corner row={row}, col={col}\n"
            f"Shot shape: {shot.shape}\n"
            f"Value range: {shot.min:.3e} .. {shot.max:.3e}"
        )
        image = shot.plot(
            plot_label=f"PSF at {z_middle:.2f} mm\ncell ({row},{col})"
        )
        rgb_shot = image.to_numpy("rgb8")
        yield DemoStep(
            title="Select PSF shot",
            text=text,
            image=rgb_shot,
        )

    # Optional: keep old run() to be CLI-compatible
    def run(self, file_path: Path) -> None:
        for step in self.iter_steps(file_path):
            print(f"=== {step.title} ===")
            print(step.text)
            # if you still want matplotlib:
            if step.image is not None:
                plt.figure()
                plt.imshow(step.image)
                plt.title(step.title)
                plt.axis("off")
                plt.show()
