import sys
from pathlib import Path
from scanner3dtest.gui.demo_window import DemoWindow
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout,
    QSplitter, QTextEdit, QLabel, QPushButton, QHBoxLayout
)
from scanner3d.scanners.ScannersDB import ScannersDB
from scanner3d.scanner.scanner import Scanner
from scanner3dtest.h5_resolver import resolve_album_h5
from scanner3dtest.demo.demos import DEMOS
from allytools.logger import configure_file_logger
from scanner3dtest.demo.demo_new import DemoFftPsf


def run_demo_gui(demo: DemoFftPsf, file_path: Path):
    steps = list(demo.iter_steps(file_path))
    app = QApplication(sys.argv)
    win = DemoWindow(steps)
    win.show()
    app.exec_()


if __name__ == "__main__":
    from scanner3d.scanners.ScannersDB import ScannersDB
    from scanner3dtest.h5_resolver import resolve_album_h5

    demo = DemoFftPsf()
    scanner = ScannersDB.Spider2ProC
    album_path = resolve_album_h5(scanner, demo)
    run_demo_gui(demo, album_path)