import sys
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout,
    QSplitter, QTextEdit, QLabel, QPushButton, QHBoxLayout
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QImage, QPixmap
import numpy as np

class DemoWindow(QMainWindow):
    def __init__(self, steps):
        super().__init__()
        self.steps = steps
        self.current_index = 0

        self.setWindowTitle("Scanner3D Demo Viewer")
        self.resize(1200, 700)

        # --- central layout ---
        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)

        splitter = QSplitter(Qt.Horizontal)
        layout.addWidget(splitter)

        # Left: text
        self.text_widget = QTextEdit()
        self.text_widget.setReadOnly(True)

        # Right: image
        self.image_label = QLabel()
        self.image_label.setAlignment(Qt.AlignCenter)

        splitter.addWidget(self.text_widget)
        splitter.addWidget(self.image_label)
        splitter.setSizes([400, 800])

        # Bottom: navigation
        nav_layout = QHBoxLayout()
        self.prev_btn = QPushButton("Previous")
        self.next_btn = QPushButton("Next")
        nav_layout.addWidget(self.prev_btn)
        nav_layout.addWidget(self.next_btn)
        layout.addLayout(nav_layout)

        self.prev_btn.clicked.connect(self.show_prev)
        self.next_btn.clicked.connect(self.show_next)

        self.update_ui()

    def update_ui(self):
        if not self.steps:
            self.text_widget.setPlainText("No steps.")
            self.image_label.clear()
            return

        step = self.steps[self.current_index]
        self.text_widget.setPlainText(f"{step.title}\n\n{step.text}")

        if step.image is not None:
            self._set_image(step.image)
        else:
            self.image_label.clear()
            self.image_label.setText("(no image)")

        self.prev_btn.setEnabled(self.current_index > 0)
        self.next_btn.setEnabled(self.current_index < len(self.steps) - 1)

    def _set_image(self, arr: np.ndarray):
        # Expect arr as uint8 RGB (H, W, 3)
        if arr.ndim != 3 or arr.shape[2] != 3:
            self.image_label.setText("(invalid image shape)")
            return
        h, w, _ = arr.shape
        qimg = QImage(arr.data, w, h, 3 * w, QImage.Format_RGB888)
        pix = QPixmap.fromImage(qimg)
        self.image_label.setPixmap(pix)

    def show_prev(self):
        if self.current_index > 0:
            self.current_index -= 1
            self.update_ui()

    def show_next(self):
        if self.current_index < len(self.steps) - 1:
            self.current_index += 1
            self.update_ui()


