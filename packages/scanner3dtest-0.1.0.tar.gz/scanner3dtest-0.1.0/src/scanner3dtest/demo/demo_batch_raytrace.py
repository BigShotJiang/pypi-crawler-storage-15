import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
from typing import Sequence
from allytools.logger import get_logger
from allytools.units import  LengthUnit, Length
from scanner3d.ray_trace.ray_batches import RayBatches
from scanner3d.h5.ray_batch.ray_batches_load import ray_batches_load
from scanner3d.ray_trace.raytrace_settings import normal_unpolarized_quick
from scanner3d.test.base.test_factory import batch_raytrace_quick
from scanner3dtest.demo.demo_base import DemoBase
from imagera.plotter import PltScalar2d, PlotParameters, CMaps
from imagera.plotter.aid import size_in_inches

log = get_logger(__name__)
class DemoBatchRaytrace(DemoBase):

    def __init__(self) -> None:
        super().__init__(required_analysis=batch_raytrace_quick,required_settings=normal_unpolarized_quick)

    def run(self, file_path: Path) -> None:

        log.info("Reading RayBatches from: %s", file_path)
        batches: RayBatches = ray_batches_load(file_path)
        if len(batches) < 2:
            log.warning("Need at least 2 batches for magnification map.")
            return

        batch_0 = batches[0]
        batch_1 = batches[1]
        gx, gy = batch_0.grid
        rays0 = batch_0.rays
        rays1 = batch_1.rays

        # Extract x,y from rays and reshape
        x0 = np.array([r.X for r in rays0]).reshape(gy, gx)
        y0 = np.array([r.Y for r in rays0]).reshape(gy, gx)
        x1 = np.array([r.X for r in rays1]).reshape(gy, gx)
        y1 = np.array([r.Y for r in rays1]).reshape(gy, gx)

        # Compute radial distances
        r0 = np.sqrt(x0**2 + y0**2)
        r1 = np.sqrt(x1**2 + y1**2)

        magnification = np.full_like(r0, np.nan, float)
        mask = r0 > 0
        magnification[mask] = r1[mask] / r0[mask]
        try:
            X = np.asarray(batch_0.x_lin).reshape(gy, gx)
            Y = np.asarray(batch_0.y_lin).reshape(gy, gx)
            extent = (
                Length(float(X.min()), LengthUnit.MM),
                Length(float(X.max()), LengthUnit.MM),
                Length(float(Y.min()), LengthUnit.MM),
                Length(float(Y.max()), LengthUnit.MM),
            )
            x_label = "Field X"
            y_label = "Field Y"
        except Exception as e:
            log.warning("Failed to build metric extent; falling back to index coordinates: %s", e)
            unit = LengthUnit.MM  # or some 'pixel' unit if you add one later
            extent = (
                Length(0.0, unit),
                Length(float(gx), unit),
                Length(0.0, unit),
                Length(float(gy), unit),
            )
            x_label = "Index X"
            y_label = "Index Y"

        params = PlotParameters(
            cmap="viridis",
            with_colorbar=True,
            hide_ticks=False,
            x_label=x_label,
            y_label=y_label,
            value_label="Magnification r1/r0",
            plot_label="Magnification Map",
        )

        sc = PltScalar2d(magnification, params=params, extent=extent)

        figsize = size_in_inches(params.size_in)
        fig, ax = plt.subplots(figsize=figsize, dpi=params.dpi)

        sc.render_into(ax, with_colorbar=True)
        plt.tight_layout()
        plt.show()

def _extract_xy(rays: Sequence[object]) -> tuple[np.ndarray, np.ndarray]:
    """
    Helper to extract (x, y) coordinates from a sequence of rays.

    Assumes each ray has .x and .y attributes (image-plane coordinates).
    Adjust if your T_Ray uses different field names (e.g. x_image, y_image).
    """
    if not rays:
        raise ValueError("Ray list is empty; cannot extract coordinates.")

    sample = rays[0]

    # Detect coordinate attribute names once (customize if needed)
    if hasattr(sample, "x") and hasattr(sample, "y"):
        get_x = lambda r: r.x
        get_y = lambda r: r.y
    elif hasattr(sample, "X") and hasattr(sample, "Y"):
        get_x = lambda r: r.X
        get_y = lambda r: r.Y
    else:
        raise AttributeError(
            "Could not find 'x'/'y' or 'X'/'Y' attributes on ray objects. "
            "Adjust _extract_xy() to match your T_Ray interface."
        )

    xs = np.array([get_x(r) for r in rays], dtype=float)
    ys = np.array([get_y(r) for r in rays], dtype=float)
    return xs, ys
