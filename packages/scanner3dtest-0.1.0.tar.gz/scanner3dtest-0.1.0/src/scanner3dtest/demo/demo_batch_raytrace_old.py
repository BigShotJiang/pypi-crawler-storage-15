import matplotlib.pyplot as plt
import numpy as np
from allytools.logger import get_logger
from pathlib import Path
from typing import Sequence
from scanner3d.ray_trace.ray_batches import RayBatches
from scanner3d.ray_trace.raytrace_settings import normal_unpolarized_quick
from scanner3d.test.base.test_factory import batch_raytrace

from scanner3d.h5.ray_batch.ray_batches_load import ray_batches_load
from scanner3dtest.demo_album_spec import DemoAlbumSpec

DEMO_ALBUM_SPEC = DemoAlbumSpec(required_analysis=batch_raytrace, required_settings=normal_unpolarized_quick)

log = get_logger(__name__)
def _extract_xy(rays: Sequence[object]) -> tuple[np.ndarray, np.ndarray]:
    """
    Helper to extract (x, y) coordinates from a sequence of rays.

    Assumes each ray has .x and .y attributes (image-plane coordinates).
    Adjust if your T_Ray uses different field names (e.g. x_image, y_image).
    """
    if not rays:
        raise ValueError("Ray list is empty; cannot extract coordinates.")

    sample = rays[0]

    # Detect coordinate attribute names once (customize if needed)
    if hasattr(sample, "x") and hasattr(sample, "y"):
        get_x = lambda r: r.x
        get_y = lambda r: r.y
    elif hasattr(sample, "X") and hasattr(sample, "Y"):
        get_x = lambda r: r.X
        get_y = lambda r: r.Y
    else:
        raise AttributeError(
            "Could not find 'x'/'y' or 'X'/'Y' attributes on ray objects. "
            "Adjust _extract_xy() to match your T_Ray interface."
        )

    xs = np.array([get_x(r) for r in rays], dtype=float)
    ys = np.array([get_y(r) for r in rays], dtype=float)
    return xs, ys


def demo_batch_raytrace(file_path: Path) -> None:
    """
    Demo of loading a batch raytrace .h5 file, inspecting the RayBatches
    collection, selecting a RayBatch, and visualizing ray hits.

    RayBatches:
        - behaves like a list[RayBatch]
        - supports len(), iteration, .first(), .last()

    RayBatch (typical fields):
        - batch_type   → RayBatchType (e.g. OnLastSurface / OnZeroSurface)
        - method       → TraceMethod or tool enum
        - rays_type    → Zemax RaysType enum
        - grid         → (gx, gy) sampling grid in field space
        - to_surface   → int, LDE surface index where rays intersected
        - wave_number  → int, Zemax wavelength index
        - rays         → list[T_Ray], ray objects (with x/y intersection coords)
        - x_lin, y_lin → 1D arrays of field/sample coordinates
        - process_time → optional float, seconds
    """

    # 1️⃣ Load RayBatches from .h5
    log.info("Reading RayBatches from: %s", file_path)
    batches: RayBatches = ray_batches_load(file_path)
    print(f"Loaded RayBatches from {file_path}")
    print(f"Number of batches: {len(batches)}")

    # 2️⃣ Quick overview of all batches
    for i, batch in enumerate(batches):
        log.info(
            "Batch %d: type=%s, to_surface=%d, wave=%d, grid=%s, n_rays=%d, process_time=%s",
            i,
            getattr(batch.batch_type, "name", str(batch.batch_type)),
            batch.to_surface,
            batch.wave_number,
            batch.grid,
            len(batch.rays),
            getattr(batch, "process_time", None),
        )
        print(
            f"Batch {i}: "
            f"type={batch.batch_type.name}, "
            f"to_surface={batch.to_surface}, "
            f"wave={batch.wave_number}, "
            f"grid={batch.grid}, "
            f"n_rays={len(batch.rays)}, "
            f"process_time={batch.process_time}"
        )

    if not batches:
        log.warning("No batches found in file; exiting demo.")
        return

    # 3️⃣ Select a batch for visualization (use the last one in demo)
    batch = batches.last()
    log.info(
        "Selected batch: type=%s, to_surface=%d, wave=%d, grid=%s, n_rays=%d",
        batch.batch_type.name,
        batch.to_surface,
        batch.wave_number,
        batch.grid,
        len(batch.rays),
    )
    print("\nSelected batch for visualization:")
    print(
        f"  type        : {batch.batch_type.name}\n"
        f"  to_surface  : {batch.to_surface}\n"
        f"  wave_number : {batch.wave_number}\n"
        f"  grid        : {batch.grid}\n"
        f"  n_rays      : {len(batch.rays)}\n"
        f"  process_time: {batch.process_time}"
    )

    # 4️⃣ Extract ray hit coordinates (image plane)
    xs, ys = _extract_xy(batch.rays)
    log.info(
        "Extracted %d ray hits. x-range=[%.4g, %.4g], y-range=[%.4g, %.4g]",
        len(xs),
        xs.min(),
        xs.max(),
        ys.min(),
        ys.max(),
    )

    # 5️⃣ Simple statistics (spot radius etc.)
    r = np.sqrt(xs**2 + ys**2)
    log.info(
        "Ray spot radius: min=%.4g, max=%.4g, RMS=%.4g",
        r.min(),
        r.max(),
        np.sqrt(np.mean(r**2)),
    )
    print(
        f"\nSpot radius statistics (at surface {batch.to_surface}):\n"
        f"  min |r| : {r.min():.4g}\n"
        f"  max |r| : {r.max():.4g}\n"
        f"  RMS |r| : {np.sqrt(np.mean(r**2)):.4g}"
    )

    # 6️⃣ Visualize ray hits as a scatter plot
    plt.figure(figsize=(5, 5))
    plt.scatter(xs, ys, s=1)
    plt.gca().set_aspect("equal", adjustable="box")
    plt.title(
        f"Ray footprint at surface {batch.to_surface}\n"
        f"type={batch.batch_type.name}, wave={batch.wave_number}"
    )
    plt.xlabel("x [image units]")
    plt.ylabel("y [image units]")
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.show()

    # 7️⃣ (Optional) visualize field sampling grid (x_lin / y_lin)
    if batch.x_lin is not None and batch.y_lin is not None:
        X, Y = np.meshgrid(batch.x_lin, batch.y_lin)
        plt.figure(figsize=(5, 5))
        plt.scatter(X, Y, s=10)
        plt.gca().set_aspect("equal", adjustable="box")
        plt.title("Field sampling grid (x_lin / y_lin)")
        plt.xlabel("field_x")
        plt.ylabel("field_y")
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.show()