import matplotlib.pyplot as plt
from pathlib import Path
from scanner3d.afs.album import Album
from allytools.units import LengthUnit, Length
from allytools.logger import get_logger
from scanner3d.test.base.test_factory import zernike_quick
from scanner3d.test.base.albums import album_radial_quick
from gosti.fft_psf.fft_psf import FftPsf
from scanner3dtest.demo.demo_base import DemoBase
from imagera.plotter import PlotParameters, CMaps

log = get_logger(__name__)
class DemoZernikePSF(DemoBase):

    def __init__(self) -> None:
        super().__init__(required_analysis=zernike_quick,required_settings=album_radial_quick)

    def run(self, file_path: Path) -> None:
        log.info(f"Reading Zernike album: {file_path}")
        album = Album.load(file_path)
        camera = album.camera_ref.resolve()
        z_focus = camera.z_range.z_focus
        frame = album[z_focus]
        shot = frame.top_right_shot()
        field_x = shot.field_x
        field_y = shot.field_y
        log.info("Selecting Zernike shot at grid corner: "
            "row=%d, col=%d with image coordinates x=%s y=%s",
            frame.n_rows, frame.n_cols, field_x, field_y)
        coefficients = shot.result.get_raw()
        n_coef = shot.result.shape[0]
        wavelength = camera.primary_wavelength
        exit_pupil_diameter = camera.objective.exit_pupil_diameter
        exit_pupil_position = camera.objective.exit_pupil_position_to_image
        focal_length = camera.objective.EFL
        grid_size = 256
        pad_factor = 16
        fft_psf = FftPsf.from_zernike(
            coefficients=coefficients,
            n_coef=n_coef,
            wavelength=wavelength,
            exit_pupil_diameter=exit_pupil_diameter,
            exit_pupil_position=exit_pupil_position,
            focal_length=focal_length,
            grid_size=grid_size,
            pad_factor=pad_factor,
            field_x_img=field_x,
            field_y_img=field_y)
        raw_psf = fft_psf.raw_psf  # noqa: F841
        airy_radius = camera.objective.airy_radius(wavelength)
        cropped_fft_psf =fft_psf.get_crop(5, airy_radius)
        plot_params = PlotParameters(
            cmap=CMaps.JET,
            dpi=300,
            size_in= (Length(4, LengthUnit.INCH), Length(4, LengthUnit.INCH)),
            with_colorbar=True,
            plot_label="Cropped PSF",
            show_lattice=True,
            lattice_pitch= Length(10, LengthUnit.UM))
        image_bundle = cropped_fft_psf.scalar2d.get_image_bundle(plot_params)
        rgb_shot  = image_bundle.to_numpy("rgb8")
        plt.imshow(rgb_shot)
        plt.axis("off")
        plt.tight_layout(pad=0)
        plt.show()
