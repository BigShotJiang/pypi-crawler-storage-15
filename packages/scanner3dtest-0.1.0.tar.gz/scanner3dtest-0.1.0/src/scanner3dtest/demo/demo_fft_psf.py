import matplotlib.pyplot as plt
from pathlib import Path
from scanner3d.afs.album import Album
from allytools.units import Length, LengthUnit
from allytools.logger import get_logger
from imagera.plotter import PlotParameters, CMaps
from scanner3d.test.base.test_factory import fft_psf_quick
from scanner3d.test.base.albums import album_major_frame_3
from scanner3dtest.demo.demo_base import DemoBase
from gosti.fft_psf.fft_psf import FftPsf
from scanner3d.analysis.fft_psf_from_shot import fft_psf_from_shot

log = get_logger(__name__)
class DemoFftPsf(DemoBase):

    def __init__(self) -> None:
        super().__init__(required_analysis=fft_psf_quick,required_settings=album_major_frame_3)

    def run(self, file_path: Path) -> None:
        log.info(f"Reading PSF album: {file_path}")
        album = Album.load(file_path)
        camera = album.camera_ref.resolve()
        z_focus = camera.z_range.z_focus
        frame = album[z_focus]
        log.info(f"Requested z : {z_focus.value_mm:.3f} [mm] and selected z: {frame.z.value_mm} [mm]")
        shot = frame.top_right_shot()
        fft_shot = fft_psf_from_shot(shot=shot, wavelength=camera.primary_wavelength)
        airy_radius = camera.objective.airy_radius(camera.primary_wavelength)
        fft_shot_cropped = fft_shot.get_crop(15, airy_radius)
        log.info(f"Selected PSF shot at grid corner: row={frame.n_rows}, col={frame.n_cols}, shape: {shot.shape}")
        plot_params = PlotParameters(
            cmap=CMaps.JET,
            dpi=300,
            with_colorbar=True,
            show_lattice=True,
            lattice_pitch= Length(25, LengthUnit.UM))
        shot_image = shot.plot(plot_params,   plot_label=f"PSF at {z_focus.value_mm:.2f} mm\ncell ({frame.n_rows},{frame.n_cols})")
        fft_shot_image =fft_shot_cropped.scalar2d.get_image_bundle(plot_params)
        frame_img = frame.plot(fig_size_in= (Length(2, LengthUnit.INCH), Length(2, LengthUnit.INCH)))
        rgb_shot  = shot_image.to_numpy("rgb8")
        rgb_frame = frame_img.to_numpy("rgb8")
        rgb_fft_shot = fft_shot_image.to_numpy("rgb8")
        plt.figure(figsize=(12, 4))
        plt.subplot(1, 3, 1)
        plt.imshow(rgb_frame)
        plt.axis("off")
        plt.subplot(1, 3, 2)
        plt.imshow(rgb_shot)
        plt.axis("off")
        plt.subplot(1, 3, 3)
        plt.imshow(rgb_fft_shot)
        plt.axis("off")
        plt.tight_layout()
        plt.show()


