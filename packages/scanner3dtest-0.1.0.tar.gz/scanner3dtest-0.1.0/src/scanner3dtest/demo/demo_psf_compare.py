import numpy as np
import matplotlib.pyplot as plt
import scanner3dtest
from pathlib import Path
from allytools.units import LengthUnit, Length
from allytools.logger import get_logger
from imagera.plotter import PlotParameters, CMaps
from scanner3d.afs.album import Album
from scanner3d.afs.shot import Shot
from scanner3d.test.base.test_factory import zernike_quick
from scanner3d.test.base.albums import album_sparse_grid_quick
from gosti.fft_psf.fft_psf import FftPsf
from gosti.fft_psf.fft_psf_from_zemax_report import fft_psf_from_zemax_report

from scanner3dtest.demo.demo_base import DemoBase

log = get_logger(__name__)
class DemoPSFCompare(DemoBase):
    def __init__(self) -> None:
        super().__init__(required_analysis=zernike_quick, required_settings=album_sparse_grid_quick)

    def run(self, file_path: Path) -> None:
        log.info(f"Reading Zernike album: {file_path}")
        album = Album.load(file_path)
        camera = album.camera_ref.resolve()
        z_focus = camera.z_range.z_focus
        frame = album[z_focus]
        shot = frame.top_right_shot()
        field_x = shot.field_x
        field_y = shot.field_y
        log.info(
            "Selecting Zernike shot at grid corner: "
            "row=%d, col=%d with image coordinates x=%s y=%s",
            frame.n_rows, frame.n_cols, field_x, field_y
        )
        coefficients = shot.result.get_raw()
        n_coef = shot.result.shape[0]
        wavelength = camera.primary_wavelength
        exit_pupil_diameter = camera.objective.exit_pupil_diameter
        exit_pupil_position = camera.objective.exit_pupil_position_to_image
        focal_length = camera.objective.EFL
        grid_size = 256
        pad_factor = 16

        fft_psf_zernike = FftPsf.from_zernike(
            coefficients=coefficients,
            n_coef=n_coef,
            wavelength=wavelength,
            exit_pupil_diameter=exit_pupil_diameter,
            exit_pupil_position=exit_pupil_position,
            focal_length=focal_length,
            grid_size=grid_size,
            pad_factor=pad_factor,
            field_x_img=field_x,
            field_y_img=field_y,
        )

        p = Path(scanner3dtest.__file__).resolve().parent
        data_dir = p / "zemax_data"
        zemax_psf_path = data_dir / "Spider2ProC_Zernike Quick_Sparse Grid Quick_edge_04.txt"
        log.info("Reading Zemax FFT PSF report from: %s", zemax_psf_path)
        if not zemax_psf_path.is_file():
            raise FileNotFoundError(
                f"Expected Zemax FFT PSF report at {zemax_psf_path}, "
                f"please place the file there or adjust the path."
            )

        fft_psf_zemax = fft_psf_from_zemax_report(path=zemax_psf_path)

        plot_params = PlotParameters(
            cmap=CMaps.JET,
            dpi=600,
            size_in=(Length(2, LengthUnit.INCH), Length(2, LengthUnit.INCH)),
            plot_label=None,
        )

        bundle_zernike = fft_psf_zernike.scalar2d.get_image_bundle(plot_params)
        rgb_zernike = bundle_zernike.to_numpy("rgb8")

        bundle_zemax = fft_psf_zemax.scalar2d.get_image_bundle(plot_params)
        rgb_zemax = bundle_zemax.to_numpy("rgb8")

        # --------- ALL AXIS / ORIENTATION VARIANTS ----------
        variants = {
            "orig": rgb_zernike,
            "flip_x": rgb_zernike[:, ::-1, :],
            "flip_y": rgb_zernike[::-1, :, :],
            "flip_xy": rgb_zernike[::-1, ::-1, :],
            "transpose": np.transpose(rgb_zernike, (1, 0, 2)),
            "transpose_flip_x": np.transpose(rgb_zernike, (1, 0, 2))[:, ::-1, :],
            "transpose_flip_y": np.transpose(rgb_zernike, (1, 0, 2))[::-1, :, :],
            "rot90": np.rot90(rgb_zernike, 1, axes=(0, 1)),   # same as transpose+flip_y
            # you could also add rot270 if you want:
            # "rot270": np.rot90(rgb_zernike, 3, axes=(0, 1)),
        }

        names = list(variants.keys())
        n_var = len(names)

        cols = 4
        rows = 2  # 8 variants = 2x4

        fig, axes = plt.subplots(rows, cols + 1, figsize=(10, 5), dpi=300)

        # left block: Zernike variants
        for idx, name in enumerate(names):
            r = idx // cols
            c = idx % cols
            ax = axes[r, c]
            ax.imshow(variants[name])
            ax.set_title(name, fontsize=7)
            ax.axis("off")

        # rightmost column: Zemax reference (same for both rows)
        for r in range(rows):
            ax = axes[r, cols]
            ax.imshow(rgb_zemax)
            ax.set_title("Zemax", fontsize=7)
            ax.axis("off")

        plt.tight_layout(pad=0.2)
        plt.show()