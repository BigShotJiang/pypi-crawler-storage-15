import matplotlib.pyplot as plt
from pathlib import Path
from scanner3d.afs.album import Album
from allytools.logger import get_logger
from scanner3d.test.base.test_factory import fft_psf_quick
from scanner3d.test.base.albums import album_major_frame_3

from scanner3dtest.demo.demo_base import DemoBase

log = get_logger(__name__)
class DemoFftPsf(DemoBase):

    def __init__(self) -> None:
        super().__init__(required_analysis=fft_psf_quick,required_settings=album_major_frame_3)

    def run(self, file_path: Path) -> None:
        """
        Demo of loading a PSF album, selecting a Z-frame and a PSF shot,
        and visualizing the result.
        """

        # 1️⃣ Load album from .h5
        # Album properties:
        #   frames     → list[Frame]
        #                 All PSF frames sampled along the Z-range.
        #
        #   z_seq      → list[float]
        #                 Z positions (mm) corresponding to each frame.
        #
        #   path       → Optional[Path]
        #                 Where the album was loaded from / saved to.
        #
        #   n_frames   → int
        #                 Number of Frames in the album.
        #
        #   camera_ref → ScannerRef
        #                 Serialized reference to the original Camera3D;
        #                 call .resolve() to restore full camera object.
        log.info(f"Reading PSF album: {file_path}")
        album = Album.load(file_path)
        print(album)

        # 2️⃣ Restore the Camera3D dataclass used to generate this album
        camera = album.camera_ref.resolve()
        print(camera)

        # 3️⃣ Get Frame at specified Z (middle in demo),  album[z_mm] → returns the frame closest to requested Z
        # Frame properties:
        #   shots    → list[Shot]
        #               All PSF shots in this frame (one per grid point).
        #
        #   x_seq    → np.ndarray
        #               X-coordinates (mm) sampled across the grid (columns).
        #
        #   y_seq    → np.ndarray
        #               Y-coordinates (mm) sampled across the grid (rows).
        #
        #   meta     → FrameMeta
        #               Metadata aggregated from all shots (spot size, wavelength…).
        #
        #   profile  → Profile
        #               System state at this Z (working and focusing distance etc.).
        #
        #   values   → np.ndarray (n_shots, Ny, Nx)
        #               Raw intensity arrays stacked from all shots.
        #
        #   z        → float
        #               Z-position (mm) at which this frame was sampled.
        z_seq = album.z_seq
        z_middle = camera.z_range.mid_mm
        frame = album[z_middle]
        log.info(
            f"Requested z : {z_middle:.3f} mm"
            f"Selected z: {frame.z}"
        )
        print(frame)

        # 4️⃣ Render the whole grid layout (each cell = one PSF)
        #    Saves a 2×2 inch preview PNG of the grid
        frame_img = frame.plot(fig_size_in=(2, 2))


        # 5️⃣ Pick PSF shot from top-right cell of the grid
        #    Convention: frame[row_idx, col_idx]
        #       row_idx = Y index (0 = bottom → upward)
        #       col_idx = X index (0 = left → right)
        # Shot properties:
        #   field_x   → float
        #                X-coordinate of the sampled PSF point (mm).
        #
        #   field_y   → float
        #                Y-coordinate of the sampled PSF point (mm).
        #
        #   data_grid → IDataGrid
        #                Zemax intensity grid returned by the analysis.
        #
        #   raw_data  → ndarray (Ny, Nx)
        #                Raw PSF intensity matrix from the data grid.
        #
        #   shape     → (Ny, Nx)
        #                Pixel resolution of the PSF grid.
        #
        #   min       → float
        #                Minimum intensity value in the PSF.
        #
        #   max       → float
        #                Maximum intensity value in the PSF.

        n_cols = len(frame.x_seq)   # number of sampled X positions
        n_rows = len(frame.y_seq)   # number of sampled Y positions

        col = n_cols - 1            # rightmost column
        row = n_rows - 1            # topmost row

        log.info(f"Selecting PSF shot at grid corner: row={row}, col={col}")
        shot = frame[row, col]
        print(shot)


        # 6️⃣ Get shot metadata (from Zemax Data Grid)
        # ShotMeta fields:
        #   Nx, Ny        → int
        #                    Grid resolution (number of samples in X and Y).
        #
        #   MinX, MinY    → float
        #                    Physical origin of the PSF grid in mm.
        #
        #   Dx, Dy        → float
        #                    Pixel spacing in mm (grid sampling step).
        #
        #   lens_file     → str
        #                    Lens file name used for generating this PSF.
        #
        #   feature_description → str
        #                    Optional description from the Zemax analysis.
        #
        #   date_iso      → str
        #                    Timestamp of analysis (ISO 8601 format).
        #
        #   min_value     → float | None
        #                    Minimum intensity in the grid.
        #
        #   max_value     → float | None
        #                    Maximum intensity in the grid.
        meta = shot.result.meta
        print(meta)

        log.info(f"Shot shape: {shot.shape}")
        log.info(f"Value range: {shot.min:.3e} .. {shot.max:.3e}")

        # 7️⃣ Visualize Frame and Shot images
        #    shot.plot(...) → ImageBundle → convert to 8-bit RGB ndarray
        image = shot.plot(plot_label=f"PSF at {z_middle:.2f} mm\ncell ({row},{col})")
        rgb_frame = frame_img.to_numpy("rgb8")
        rgb_shot  = image.to_numpy("rgb8")
        plt.figure(figsize=(8, 4))
        plt.subplot(1, 2, 1)
        plt.imshow(rgb_frame)
        plt.title("Frame Grid")
        plt.axis("off")
        plt.subplot(1, 2, 2)
        plt.imshow(rgb_shot)
        plt.title(f"PSF ({row}, {col})")
        plt.axis("off")
        plt.tight_layout()
        plt.show()