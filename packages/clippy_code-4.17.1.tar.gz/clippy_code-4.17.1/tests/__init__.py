"""Tests for clippy-code."""
