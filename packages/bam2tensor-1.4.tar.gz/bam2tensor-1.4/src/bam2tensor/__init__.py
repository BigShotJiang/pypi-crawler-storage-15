"""Bam2Tensor."""

__version__ = "1.4"
