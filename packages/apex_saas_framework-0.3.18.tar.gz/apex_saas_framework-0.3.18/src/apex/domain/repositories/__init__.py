"""Repositories module."""

from apex.domain.repositories.base import BaseRepository

__all__ = ["BaseRepository"]

