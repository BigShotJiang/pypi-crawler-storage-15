"""Configuration module for apex package."""

from apex.core.config.settings import Settings, get_settings

__all__ = ["Settings", "get_settings"]

