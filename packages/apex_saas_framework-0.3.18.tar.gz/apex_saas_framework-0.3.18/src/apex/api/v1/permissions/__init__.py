"""Permissions API routes."""

from apex.api.v1.permissions.router import router

__all__ = ["router"]

