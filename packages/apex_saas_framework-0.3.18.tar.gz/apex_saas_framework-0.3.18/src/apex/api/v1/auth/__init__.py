"""Authentication API routes."""

from apex.api.v1.auth.router import router

__all__ = ["router"]

