"""Users API routes."""

from apex.api.v1.users.router import router

__all__ = ["router"]

