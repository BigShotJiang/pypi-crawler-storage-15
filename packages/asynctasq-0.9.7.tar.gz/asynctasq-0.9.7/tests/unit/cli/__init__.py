"""Unit tests for CLI package."""
