from ._classic2core import load_classic_to_core_mapping

__all__ = ["load_classic_to_core_mapping"]
