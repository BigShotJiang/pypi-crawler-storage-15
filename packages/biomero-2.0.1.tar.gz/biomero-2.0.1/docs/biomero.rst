biomero package
============================

.. Submodules
.. ----------

biomero.slurm\_client module
-----------------------------------------

.. automodule:: biomero.slurm_client
   :members:
   :undoc-members:
   :show-inheritance:

biomero.eventsourcing module
-----------------------------------------

.. automodule:: biomero.eventsourcing
   :members:
   :undoc-members:
   :show-inheritance:

biomero.views module
-----------------------------------------

.. automodule:: biomero.views
   :members:
   :undoc-members:
   :show-inheritance:

.. Module contents
.. ---------------

.. .. automodule:: biomero
..    :members:
..    :undoc-members:
..    :show-inheritance:
