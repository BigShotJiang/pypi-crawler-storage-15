"""djpress module."""

__version__ = "0.22.2"
