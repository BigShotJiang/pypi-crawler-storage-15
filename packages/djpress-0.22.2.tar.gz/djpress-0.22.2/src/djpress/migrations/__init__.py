"""Migrations for the djpress app."""
