---
schema_version: "1.0.0"
title: "Bad Version"
version: "not-a-semver"
status: "stable"
objective: "This dossier has an invalid version format"
checksum:
  algorithm: "sha256"
  hash: "0d3391f0fc3dc2492a5aae208db783f31a7c47def4b860bb3447414df9a57554"
authors:
  - name: "Test Author"
---

# Bad Version

Invalid version format.
