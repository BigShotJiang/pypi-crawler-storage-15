---
name: Feature request
about: Suggest a new feature
title: ''
labels: enhancement
assignees: ''
---

## Problem

<!-- What problem does this solve? -->

## Proposed solution

<!-- How should it work? -->

## Alternatives considered

<!-- Other approaches you've thought about -->

## Additional context

<!-- Examples, mockups, related issues -->
