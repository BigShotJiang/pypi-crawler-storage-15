from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="dastaans-lib-manager",
    version="0.1.0",
    author="Your Name",
    author_email="your.email@example.com",
    description="A library manager for installing private Python libraries from Git",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/dastaans-lib-manager",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
    install_requires=[
        "python-dotenv>=1.0.0",
        "GitPython>=3.1.0",
    ],
    entry_points={
        "console_scripts": [
            "dastaans-lib=dastaans_lib_manager.cli:main",
        ],
    },
)
