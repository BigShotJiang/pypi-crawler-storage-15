#!/usr/bin/env python3
"""Command-line interface for dastaans-lib-manager"""

import argparse
import sys
from .manager import LibraryManager


def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        description="Dastaans Library Manager - Manage private library installations"
    )

    parser.add_argument(
        "action",
        choices=["install", "update", "uninstall", "check"],
        help="Action to perform"
    )

    parser.add_argument(
        "--repo",
        help="Git repository URL (overrides DASTAANS_LIB_REPO env var)"
    )

    parser.add_argument(
        "--branch",
        default="main",
        help="Git branch to use (default: main)"
    )

    parser.add_argument(
        "--package-name",
        default="dastaans-shared-lib",
        help="Package name for uninstall/check operations"
    )

    parser.add_argument(
        "--editable",
        action="store_true",
        help="Install in editable mode"
    )

    parser.add_argument(
        "--force",
        action="store_true",
        help="Force reinstall"
    )

    args = parser.parse_args()

    try:
        manager = LibraryManager(repo_url=args.repo, branch=args.branch)

        if args.action == "install":
            success = manager.install(force=args.force, editable=args.editable)

        elif args.action == "update":
            success = manager.update()

        elif args.action == "uninstall":
            success = manager.uninstall(package_name=args.package_name)

        elif args.action == "check":
            if manager.check_installed(package_name=args.package_name):
                print(f"✓ {args.package_name} is installed")
                success = True
            else:
                print(f"✗ {args.package_name} is not installed")
                success = False

        sys.exit(0 if success else 1)

    except ValueError as e:
        print(f"Error: {e}")
        sys.exit(1)
    except KeyboardInterrupt:
        print("\nOperation cancelled by user")
        sys.exit(1)


if __name__ == "__main__":
    main()
