"""Dastaans Library Manager - Manage private library installations"""

__version__ = "0.1.0"

from .manager import LibraryManager

__all__ = ["LibraryManager"]
