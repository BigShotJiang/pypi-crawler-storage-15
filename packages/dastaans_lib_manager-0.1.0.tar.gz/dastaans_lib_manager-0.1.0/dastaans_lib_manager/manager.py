import os
import sys
import shutil
import subprocess
from pathlib import Path
from typing import Optional
import tempfile
from dotenv import load_dotenv
import git


class LibraryManager:
    """Manages installation of private libraries from Git repositories"""

    def __init__(self, repo_url: Optional[str] = None, branch: str = "main"):
        """
        Initialize the Library Manager

        Args:
            repo_url: Git repository URL (can include credentials or use SSH)
            branch: Git branch to clone (default: main)
        """
        load_dotenv()

        self.repo_url = repo_url or os.getenv("DASTAANS_LIB_REPO")
        self.branch = branch
        self.private_key_path = os.getenv("DASTAANS_LIB_SSH_KEY")
        self.git_token = os.getenv("DASTAANS_LIB_GIT_TOKEN")

        if not self.repo_url:
            raise ValueError(
                "Repository URL must be provided either as argument or "
                "DASTAANS_LIB_REPO environment variable"
            )

    def _get_git_env(self) -> dict:
        """Prepare environment variables for git operations with SSH key"""
        env = os.environ.copy()

        if self.private_key_path and os.path.exists(self.private_key_path):
            # Set up SSH command to use the private key
            ssh_cmd = f'ssh -i {self.private_key_path} -o StrictHostKeyChecking=no'
            env['GIT_SSH_COMMAND'] = ssh_cmd

        return env

    def _get_authenticated_url(self) -> str:
        """Get repository URL with authentication token if available"""
        if self.git_token and self.repo_url.startswith("https://"):
            # Insert token into HTTPS URL
            # Format: https://token@github.com/user/repo.git
            parts = self.repo_url.replace("https://", "").split("/", 1)
            if len(parts) == 2:
                return f"https://{self.git_token}@{parts[0]}/{parts[1]}"

        return self.repo_url

    def install(self, force: bool = False, editable: bool = False) -> bool:
        """
        Install the library from the Git repository

        Args:
            force: Force reinstall even if already installed
            editable: Install in editable mode

        Returns:
            True if installation successful, False otherwise
        """
        temp_dir = None

        try:
            # Create temporary directory for cloning
            temp_dir = tempfile.mkdtemp(prefix="dastaans_lib_")
            print(f"Cloning library from {self.repo_url}...")

            # Clone the repository
            repo_url = self._get_authenticated_url()
            git_env = self._get_git_env()

            git.Repo.clone_from(
                repo_url,
                temp_dir,
                branch=self.branch,
                env=git_env,
                depth=1  # Shallow clone for faster download
            )

            print(f"Successfully cloned branch '{self.branch}'")

            # Install the package
            install_cmd = [sys.executable, "-m", "pip", "install"]

            if force:
                install_cmd.append("--force-reinstall")

            if editable:
                install_cmd.append("-e")

            install_cmd.append(temp_dir)

            print("Installing library...")
            result = subprocess.run(
                install_cmd,
                check=True,
                capture_output=True,
                text=True
            )

            print("Library installed successfully!")
            return True

        except git.GitCommandError as e:
            print(f"Error cloning repository: {e}")
            print("Please check your repository URL and credentials")
            return False

        except subprocess.CalledProcessError as e:
            print(f"Error installing library: {e}")
            print(e.stderr)
            return False

        except Exception as e:
            print(f"Unexpected error: {e}")
            return False

        finally:
            # Clean up temporary directory
            if temp_dir and os.path.exists(temp_dir):
                shutil.rmtree(temp_dir)
                print("Cleaned up temporary files")

    def update(self) -> bool:
        """
        Update the library to the latest version

        Returns:
            True if update successful, False otherwise
        """
        print("Updating library...")
        return self.install(force=True)

    def uninstall(self, package_name: str = "dastaans-shared-lib") -> bool:
        """
        Uninstall the library

        Args:
            package_name: Name of the package to uninstall

        Returns:
            True if uninstall successful, False otherwise
        """
        try:
            print(f"Uninstalling {package_name}...")
            subprocess.run(
                [sys.executable, "-m", "pip", "uninstall", "-y", package_name],
                check=True,
                capture_output=True,
                text=True
            )
            print(f"{package_name} uninstalled successfully!")
            return True

        except subprocess.CalledProcessError as e:
            print(f"Error uninstalling library: {e}")
            return False

    def check_installed(self, package_name: str = "dastaans-shared-lib") -> bool:
        """
        Check if the library is installed

        Args:
            package_name: Name of the package to check

        Returns:
            True if installed, False otherwise
        """
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pip", "show", package_name],
                capture_output=True,
                text=True
            )
            return result.returncode == 0
        except Exception:
            return False
