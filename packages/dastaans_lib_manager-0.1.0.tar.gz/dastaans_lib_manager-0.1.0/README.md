# Dastaans Library Manager

A Python package for managing private library installations from Git repositories in microservice environments.

## Features

- Install private Python libraries from Git repositories (HTTPS with token or SSH with key)
- Automatic cleanup after installation
- Update/reinstall functionality
- Virtual environment detection
- Support for both public and private repositories

## Installation

### From PyPI (once published)

```bash
pip install dastaans-lib-manager
```

### From Git Repository

```bash
pip install git+https://github.com/yourusername/dastaans-lib-manager.git
```

## Configuration

The library manager uses environment variables for configuration. Create a `.env` file:

```env
# Required: Your shared library repository URL
DASTAANS_LIB_REPO=https://github.com/yourusername/dastaans-shared-lib.git

# Option 1: HTTPS with Personal Access Token
DASTAANS_LIB_GIT_TOKEN=ghp_your_token_here

# Option 2: SSH with Private Key
# DASTAANS_LIB_REPO=git@github.com:yourusername/dastaans-shared-lib.git
# DASTAANS_LIB_SSH_KEY=/path/to/your/private/key
```

## Usage

### Command Line Interface

```bash
# Install the shared library
dastaans-lib install

# Update to latest version
dastaans-lib update

# Check if installed
dastaans-lib check

# Uninstall
dastaans-lib uninstall

# Install from specific branch
dastaans-lib install --branch develop

# Force reinstall
dastaans-lib install --force
```

### Python API

```python
from dastaans_lib_manager import LibraryManager

# Initialize manager
manager = LibraryManager(
    repo_url="https://github.com/yourusername/dastaans-shared-lib.git",
    branch="main"
)

# Install library
manager.install()

# Update library
manager.update()

# Check if installed
if manager.check_installed():
    print("Library is installed")

# Uninstall
manager.uninstall()
```

## Authentication Methods

### HTTPS with Personal Access Token

1. Generate a GitHub Personal Access Token with `repo` access
2. Set environment variables:
   ```env
   DASTAANS_LIB_REPO=https://github.com/yourusername/repo.git
   DASTAANS_LIB_GIT_TOKEN=ghp_your_token
   ```

### SSH with Private Key

1. Add your SSH public key to GitHub
2. Set environment variables:
   ```env
   DASTAANS_LIB_REPO=git@github.com:yourusername/repo.git
   DASTAANS_LIB_SSH_KEY=/path/to/private/key
   ```

## How It Works

1. Reads configuration from environment variables
2. Clones the private repository to a temporary directory
3. Installs the package using pip
4. Automatically cleans up the temporary directory
5. Library remains installed in your virtual environment

## License

MIT License
