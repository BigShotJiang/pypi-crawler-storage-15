# BotScale

Universal bot framework (name reservation package).

This is a minimal package published to reserve the 'botscale' name on PyPI.
The actual package will be published later with full functionality.

For more information, visit: https://github.com/sensiloles/botscale
