"""
BotScale - Universal bot framework (name reservation package).

This is a minimal package published to reserve the 'botscale' name on PyPI.
The actual package will be published later with full functionality.
"""
__version__ = "0.0.1"
