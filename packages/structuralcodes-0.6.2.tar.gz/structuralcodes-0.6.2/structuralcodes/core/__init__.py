"""Core functionality shared between other modules."""
