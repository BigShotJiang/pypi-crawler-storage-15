"""Test suite for ImpedanceFitter."""
