2025-11-05 Version: 3.3.0
- Support API ImportOneTaskPhoneNumber.
- Update API QueryAiCallDetailPage: add request parameters DetailIds.
- Update API UpdateAiCallTask: add request parameters TaskCps.


2025-10-29 Version: 3.2.0
- Support API PageQueryAgentList.
- Support API QueryAiVoiceAgentDetail.


2025-10-22 Version: 3.1.1
- Update API QueryAiCallDetailPage: add request parameters OutId.
- Update API QueryAiCallDetailPage: add response parameters Body.Data.List.$.Status.
- Update API QueryConversationDetailInfo: add response parameters Body.Data.CallId.
- Update API QueryConversationDetailInfo: add response parameters Body.Data.CallResult.
- Update API QueryConversationDetailInfo: add response parameters Body.Data.CalledPhone.
- Update API QueryConversationDetailInfo: add response parameters Body.Data.CallerPhone.
- Update API QueryConversationDetailInfo: add response parameters Body.Data.Duration.
- Update API QueryConversationDetailInfo: add response parameters Body.Data.FailedReason.
- Update API QueryConversationDetailInfo: add response parameters Body.Data.HangupDirection.
- Update API QueryConversationDetailInfo: add response parameters Body.Data.MajorIntent.
- Update API QueryConversationDetailInfo: add response parameters Body.Data.OutId.
- Update API QueryConversationDetailInfo: add response parameters Body.Data.ReleaseTime.
- Update API QueryConversationDetailInfo: add response parameters Body.Data.StartCallTime.
- Update API QueryConversationDetailInfo: add response parameters Body.Data.StatusCode.
- Update API QueryConversationDetailInfo: add response parameters Body.Data.StatusMsg.


2025-08-19 Version: 3.1.0
- Support API GetCallDialogContent.


2025-08-08 Version: 3.0.0
- Support API CancelAiCallDetails.
- Support API CreateAiCallTask.
- Support API ImportTaskNumberDatas.
- Support API ListAvailableTts.
- Support API LlmSmartCallEncrypt.
- Support API QueryAiCallDetailPage.
- Support API QueryAiCallTaskDetail.
- Support API QueryAiCallTaskPage.
- Support API QueryConversationDetailInfo.
- Support API StartAiCallTask.
- Support API StopAiCallTask.
- Support API UpdateAiCallTask.
- Update API LlmSmartCall: add request parameters BizParam.
- Update API LlmSmartCall: add request parameters CustomerLineCode.
- Update API LlmSmartCall: add request parameters Extension.
- Update API LlmSmartCall: add request parameters SessionTimeout.
- Update API LlmSmartCall: add request parameters TtsSpeed.
- Update API LlmSmartCall: add request parameters TtsVoiceCode.
- Update API LlmSmartCall: add request parameters TtsVolume.


2025-02-11 Version: 2.1.0
- Support API HangupOperate.


2024-12-20 Version: 2.0.0
- Support API LlmSmartCall.
- Delete API ListOuterOrderedNumbers.


2023-02-07 Version: 1.0.3
- Upgrade SDK.

2021-08-31 Version: 1.0.2
- AMP version.

2021-07-15 Version: 1.0.1
- Generated python 2019-10-15 for aiccs.

2021-05-18 Version: 1.0.0
- Publish multi language sdk.

