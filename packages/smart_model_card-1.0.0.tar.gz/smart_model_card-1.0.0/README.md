# SMART Model Card

A Python library for generating standardized AI/ML model cards with OMOP Common Data Model integration.

## Overview

This library provides tools for creating model documentation cards that support:
- OMOP CDM cohort integration via OHDSI WebAPI
- Dynamic report parsing from Heracles characterizations
- Multi-dataset documentation
- HTML, JSON, and Markdown export formats
- Interactive visualizations and data tables

## Installation

```bash
pip install smart-model-card
```

## Quick Start

### Interactive CLI

Create a model card through an interactive wizard:

```bash
smart-model-card interactive
```

This launches a guided workflow that prompts you through each section step by step.

### Basic Model Card

```python
from smart_model_card import ModelCard, ModelDetails, IntendedUse

# Initialize model card
card = ModelCard(
    model_details=ModelDetails(
        model_name="COPD-Risk-Model",
        version="1.0.0",
        developer="Your Organization",
        description="Predicts COPD exacerbation risk"
    ),
    intended_use=IntendedUse(
        primary_users="Pulmonologists",
        clinical_indications="Risk stratification for COPD patients"
    )
)

# Export
from smart_model_card.exporters import HTMLExporter, JSONExporter

HTMLExporter.export(card, "output/model_card.html")
JSONExporter.export(card, "output/model_card.json")
```

### OMOP Integration

```python
from smart_model_card.integrations import OMOPIntegration

# Connect to OHDSI WebAPI
integration = OMOPIntegration(
    webapi_url="https://your-atlas-instance.org/WebAPI",
    source_key="YOUR_CDM_SOURCE"
)

# Fetch cohort with reports
cohort_data = integration.get_cohort_with_reports(
    cohort_id=168,
    include_heracles=True
)

# Enrich model card
card.data_factors.add_omop_cohort(cohort_data)
```

### Multi-Dataset Model Card

```python
from smart_model_card.data_sources import DataSource

# Add multiple datasets
card.data_factors.add_dataset(
    DataSource(
        name="Hospital A",
        origin="Academic medical center",
        size=1250,
        demographics={
            "age": "Mean: 68, Range: 45-92",
            "gender": "Male: 65%, Female: 35%"
        }
    )
)

card.data_factors.add_dataset(
    DataSource(
        name="Hospital B",
        origin="Community hospital",
        size=890,
        demographics={
            "age": "Mean: 71, Range: 50-88",
            "gender": "Male: 58%, Female: 42%"
        }
    )
)
```

## Features

### OMOP CDM Support
- Cohort definition extraction
- Heracles characterization parsing
- OHDSI Athena concept enrichment
- Automatic demographic table generation

### Visualization
- Age/gender/race distribution charts
- Performance metrics visualization
- Concept relationship graphs
- Interactive HTML reports

### Export Formats
- **HTML**: Interactive reports with collapsible sections, pagination, and search
- **JSON**: Structured data following standardized schema
- **Markdown**: Plain text documentation

### Standardization
- Consistent section structure across all model cards
- Intelligent N/A handling when data is unavailable
- Multi-dataset dropdown switching

## CLI Commands

```bash
# Interactive wizard
smart-model-card interactive

# Validate existing card
smart-model-card validate model_card.json

# Export to different formats
smart-model-card export model_card.json --format html -o output.html

# Create scaffold
smart-model-card create --model-name "MyModel" -o scaffold.json

# Compute hashes for provenance
smart-model-card hash --card model_card.json

# Compare versions
smart-model-card diff old_card.json new_card.json
```

## Documentation

See the `examples/` directory for usage patterns:
- `quickstart.py` - Basic model card creation
- `demo_smart_omop_dynamic.py` - OMOP integration with dynamic reports
- `demo_multi_dataset.py` - Multi-site model documentation

## Testing

Run tests:
```bash
pytest tests/
```

Tests cover:
- Model card validation
- Standardization consistency
- Section structure
- OMOP integration
- Provenance tracking

## Requirements

- Python >= 3.8
- requests
- matplotlib (optional, for visualizations)

## License

MIT License

## Contributing

Contributions are welcome. Please submit issues and pull requests on GitHub.

## Citation

```bibtex
@software{smart_model_card,
  title={SMART Model Card},
  author={Lohachab, Ankur},
  organization={Department of Advanced Computing Sciences, Maastricht University},
  year={2025}
}
```
