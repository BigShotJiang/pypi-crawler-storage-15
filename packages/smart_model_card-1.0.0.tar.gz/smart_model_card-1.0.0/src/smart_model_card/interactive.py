"""
Interactive CLI for guided model card creation

Author: Ankur Lohachab
Department of Advanced Computing Sciences, Maastricht University
"""

import sys
from typing import Optional, List, Dict, Any
from smart_model_card import ModelCard, ModelDetails, IntendedUse
from smart_model_card.sections import (
    DataFactors, FeaturesOutputs, PerformanceValidation,
    Methodology, AdditionalInfo, SourceDataset, InputFeature,
    OutputFeature, ValidationDataset, PerformanceMetric
)
from smart_model_card.exporters import HTMLExporter, JSONExporter


def prompt_input(prompt: str, required: bool = True, default: Optional[str] = None) -> str:
    """Prompt user for input with optional default"""
    if default:
        prompt = f"{prompt} [{default}]"

    while True:
        value = input(f"  {prompt}: ").strip()

        if not value and default:
            return default

        if not value and not required:
            return ""

        if not value and required:
            print("  This field is required. Please provide a value.")
            continue

        return value


def prompt_choice(prompt: str, choices: List[str]) -> str:
    """Prompt user to select from choices"""
    print(f"\n  {prompt}")
    for i, choice in enumerate(choices, 1):
        print(f"    {i}. {choice}")

    while True:
        selection = input("  Select number: ").strip()
        try:
            idx = int(selection) - 1
            if 0 <= idx < len(choices):
                return choices[idx]
        except ValueError:
            pass
        print("  Invalid selection. Please try again.")


def prompt_yes_no(prompt: str, default: bool = False) -> bool:
    """Prompt yes/no question"""
    default_str = "Y/n" if default else "y/N"
    response = input(f"  {prompt} [{default_str}]: ").strip().lower()

    if not response:
        return default

    return response in ['y', 'yes']


def prompt_float(prompt: str, required: bool = True) -> Optional[float]:
    """Prompt for float value"""
    while True:
        value = input(f"  {prompt}: ").strip()

        if not value and not required:
            return None

        if not value and required:
            print("  This field is required.")
            continue

        try:
            return float(value)
        except ValueError:
            print("  Please enter a valid number.")


def prompt_int(prompt: str, required: bool = True) -> Optional[int]:
    """Prompt for integer value"""
    while True:
        value = input(f"  {prompt}: ").strip()

        if not value and not required:
            return None

        if not value and required:
            print("  This field is required.")
            continue

        try:
            return int(value)
        except ValueError:
            print("  Please enter a valid integer.")


def section_model_details() -> ModelDetails:
    """Guided input for Section 1: Model Details"""
    print("\n" + "="*60)
    print("SECTION 1: Model Details")
    print("="*60)

    return ModelDetails(
        model_name=prompt_input("Model Name", required=True),
        version=prompt_input("Version", default="1.0.0"),
        developer_organization=prompt_input("Developer/Organization", required=True),
        release_date=prompt_input("Release Date (YYYY-MM-DD)", required=False),
        description=prompt_input("Description", required=True),
        intended_purpose=prompt_choice(
            "Intended Purpose",
            ["decision_support", "screening", "diagnosis", "prognosis", "other"]
        ),
        algorithms_used=prompt_input("Algorithm(s) Used", required=True),
        licensing=prompt_input("License", default="MIT"),
        support_contact=prompt_input("Support Contact (email)", required=True)
    )


def section_intended_use() -> IntendedUse:
    """Guided input for Section 2: Intended Use"""
    print("\n" + "="*60)
    print("SECTION 2: Intended Use and Clinical Context")
    print("="*60)

    return IntendedUse(
        primary_intended_users=prompt_input("Primary Intended Users", required=True),
        clinical_indications=prompt_input("Clinical Indications", required=True),
        patient_target_group=prompt_input("Patient Target Group", required=True),
        intended_use_environment=prompt_choice(
            "Intended Use Environment",
            ["hospital_inpatient", "hospital_outpatient", "clinic", "home", "mobile", "other"]
        ),
        contraindications=prompt_input("Contraindications", required=False),
        out_of_scope_applications=prompt_input("Out of Scope Applications", required=False),
        warnings=prompt_input("Warnings", required=False)
    )


def section_data_factors() -> DataFactors:
    """Guided input for Section 3: Data & Factors"""
    print("\n" + "="*60)
    print("SECTION 3: Data & Factors")
    print("="*60)

    # Source datasets
    datasets = []
    print("\nAdd source datasets:")

    while True:
        print(f"\n  Dataset {len(datasets) + 1}:")
        name = prompt_input("  Name", required=True)
        origin = prompt_input("  Origin/Source", required=True)
        size = prompt_int("  Size (number of records)", required=True)
        period = prompt_input("  Collection Period", required=True)
        pop_char = prompt_input("  Population Characteristics", required=True)

        datasets.append(SourceDataset(name, origin, size, period, pop_char))

        if not prompt_yes_no("\nAdd another dataset?", default=False):
            break

    return DataFactors(
        source_datasets=datasets,
        data_distribution_summary=prompt_input("Data Distribution Summary", required=True),
        data_representativeness=prompt_input("Data Representativeness", required=True),
        data_governance=prompt_input("Data Governance", required=True)
    )


def section_features_outputs() -> FeaturesOutputs:
    """Guided input for Section 4: Features & Outputs"""
    print("\n" + "="*60)
    print("SECTION 4: Features & Outputs")
    print("="*60)

    # Input features
    input_features = []
    print("\nAdd input features:")

    while True:
        print(f"\n  Feature {len(input_features) + 1}:")
        name = prompt_input("  Name", required=True)
        data_type = prompt_choice("  Data Type", ["numeric", "categorical", "binary", "text", "image"])
        required = prompt_yes_no("  Required?", default=True)
        domain = prompt_input("  Clinical Domain", required=True)

        input_features.append(InputFeature(name, data_type, required, domain))

        if not prompt_yes_no("\nAdd another input feature?", default=True):
            break

    # Output features
    output_features = []
    print("\nAdd output features:")

    while True:
        print(f"\n  Output {len(output_features) + 1}:")
        name = prompt_input("  Name", required=True)
        output_type = prompt_choice("  Type", ["probability", "classification", "regression", "ranking"])

        output_features.append(OutputFeature(name, output_type))

        if not prompt_yes_no("\nAdd another output?", default=False):
            break

    return FeaturesOutputs(
        input_features=input_features,
        output_features=output_features,
        feature_type_distribution=prompt_input("Feature Type Distribution", required=False),
        uncertainty_quantification=prompt_input("Uncertainty Quantification", required=False),
        output_interpretability=prompt_input("Output Interpretability", required=False)
    )


def section_performance() -> PerformanceValidation:
    """Guided input for Section 5: Performance & Validation"""
    print("\n" + "="*60)
    print("SECTION 5: Performance & Validation")
    print("="*60)

    # Validation datasets
    val_datasets = []
    print("\nAdd validation datasets:")

    while True:
        print(f"\n  Dataset {len(val_datasets) + 1}:")
        name = prompt_input("  Name", required=True)
        institution = prompt_input("  Source Institution", required=True)
        pop = prompt_input("  Population Characteristics", required=True)
        val_type = prompt_choice("  Validation Type", ["internal", "external", "cross_validation"])

        val_datasets.append(ValidationDataset(name, institution, pop, val_type))

        if not prompt_yes_no("\nAdd another validation dataset?", default=False):
            break

    # Metrics
    metrics = []
    print("\nAdd performance metrics:")

    while True:
        print(f"\n  Metric {len(metrics) + 1}:")
        metric_name = prompt_input("  Metric Name (e.g., AUC-ROC, Sensitivity)", required=True)
        value = prompt_float("  Value", required=True)
        status = prompt_choice("  Validation Status", ["Claimed", "Validated", "External"])
        subgroup = prompt_input("  Subgroup (optional)", required=False)

        metrics.append(PerformanceMetric(metric_name, value, status, subgroup if subgroup else None))

        if not prompt_yes_no("\nAdd another metric?", default=True):
            break

    return PerformanceValidation(
        validation_datasets=val_datasets,
        claimed_metrics=[m for m in metrics if m.validation_status == "Claimed"],
        validated_metrics=[m for m in metrics if m.validation_status != "Claimed"],
        calibration_analysis=prompt_input("Calibration Analysis", required=False),
        fairness_assessment=prompt_input("Fairness Assessment", required=False),
        metric_validation_status=prompt_input("Overall Validation Status", required=False)
    )


def section_methodology() -> Methodology:
    """Guided input for Section 6: Methodology & Explainability"""
    print("\n" + "="*60)
    print("SECTION 6: Methodology & Explainability")
    print("="*60)

    return Methodology(
        model_development_workflow=prompt_input("Development Workflow", required=True),
        training_procedure=prompt_input("Training Procedure", required=True),
        data_preprocessing=prompt_input("Data Preprocessing", required=True),
        synthetic_data_usage=prompt_input("Synthetic Data Usage (if any)", required=False),
        explainable_ai_method=prompt_input("Explainability Method (if any)", required=False),
        global_vs_local_interpretability=prompt_input("Global vs Local Interpretability", required=False)
    )


def section_additional_info() -> AdditionalInfo:
    """Guided input for Section 7: Additional Information"""
    print("\n" + "="*60)
    print("SECTION 7: Additional Information")
    print("="*60)

    return AdditionalInfo(
        benefit_risk_summary=prompt_input("Benefit-Risk Summary", required=True),
        ethical_considerations=prompt_input("Ethical Considerations", required=True),
        caveats_limitations=prompt_input("Caveats & Limitations", required=True),
        recommendations_for_safe_use=prompt_input("Recommendations for Safe Use", required=True),
        post_market_surveillance_plan=prompt_input("Post-Market Surveillance Plan", required=False),
        explainability_recommendations=prompt_input("Explainability Recommendations", required=False)
    )


def interactive_create_model_card() -> ModelCard:
    """Interactive workflow to create a model card"""
    print("\n" + "*"*60)
    print("SMART Model Card - Interactive Creation")
    print("*"*60)
    print("\nThis wizard will guide you through creating a model card.")
    print("You can skip optional fields by pressing Enter.\n")

    card = ModelCard()

    # Section 1
    card.set_model_details(section_model_details())

    # Section 2
    card.set_intended_use(section_intended_use())

    # Section 3
    card.set_data_factors(section_data_factors())

    # Section 4
    card.set_features_outputs(section_features_outputs())

    # Section 5
    card.set_performance_validation(section_performance())

    # Section 6
    card.set_methodology(section_methodology())

    # Section 7
    card.set_additional_info(section_additional_info())

    print("\n" + "="*60)
    print("Model Card Creation Complete!")
    print("="*60)

    return card


def main():
    """Main entry point for interactive CLI"""
    try:
        card = interactive_create_model_card()

        # Export
        print("\nExporting model card...")
        output_base = prompt_input("\nOutput filename (without extension)", default="model_card")

        formats = []
        if prompt_yes_no("Export HTML?", default=True):
            formats.append("html")
        if prompt_yes_no("Export JSON?", default=True):
            formats.append("json")

        for fmt in formats:
            output_path = f"output/{output_base}.{fmt}"
            if fmt == "html":
                HTMLExporter.export(card, output_path)
            elif fmt == "json":
                JSONExporter.export(card, output_path)
            print(f"✓ Exported: {output_path}")

        print("\nSuccess! Your model card has been created.")

    except KeyboardInterrupt:
        print("\n\nCancelled by user.")
        sys.exit(1)
    except Exception as e:
        print(f"\nError: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
