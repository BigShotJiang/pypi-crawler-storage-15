This is a technical module ; it doesn't bring any useful feature by
itself. This module is the base modules for 2 other modules :

- *account_invoice_import* which imports supplier invoices as PDF or XML
  files (this module also requires some additional modules such as
  *account_invoice_import_invoice2data*, *account_invoice_import_ubl*,
  etc... to support specific invoice formats),
- *sale_invoice_import* which imports sale orders as CSV, XML or PDF
  files (this module also requires some additional modules such as
  *sale_invoice_import_csv* or *sale_invoice_import_ubl* to support
  specific order formats)
