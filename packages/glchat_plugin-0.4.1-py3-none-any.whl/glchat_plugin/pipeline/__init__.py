"""Module for glchat_plugin pipeline."""
