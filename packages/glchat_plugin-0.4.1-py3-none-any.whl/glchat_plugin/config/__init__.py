"""Module for glchat_plugin config."""
