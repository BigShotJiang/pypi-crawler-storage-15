# prompt-vcs

> Git-native prompt management library for LLM applications

一个轻量级、代码优先的 Python 库，基于 Git 和文件系统管理 LLM Prompts，无需外部数据库。

## 安装

```bash
pip install prompt-vcs
```

## 快速开始

### 1. 初始化项目

```bash
pvcs init
```

### 2. 内联模式

```python
from prompt_vcs import p

# 默认使用代码中的字符串，lockfile 锁定后使用对应版本
msg = p("user_greeting", "你好 {name}", name="开发者")
```

### 3. 装饰器模式

```python
from prompt_vcs import prompt

@prompt(id="system_core", default_version="v1")
def get_system_prompt(role: str):
    """
    你是一个乐于助人的助手，扮演的角色是 {role}。
    """
    pass
```

### 4. 提取 Prompt 为 YAML

```bash
pvcs scaffold src/
```

### 5. 切换版本

```bash
pvcs switch user_greeting v2
```

### 6. 自动迁移现有代码

将硬编码的 prompt 字符串自动转换为 `p()` 调用：

```bash
# 预览变更
pvcs migrate src/ --dry-run

# 交互式迁移（逐个确认）
pvcs migrate src/

# 自动应用所有变更
pvcs migrate src/ --yes
```

**支持的转换：**

```python
# 转换前
prompt = f"Hello {user.name}, 价格: {price:.2f}"

# 转换后
from prompt_vcs import p
prompt = p("demo_prompt", "Hello {user_name}, 价格: {price:.2f}", 
           user_name=user.name, price=price)
```

**特性：**
- ✅ f-string 变量提取
- ✅ 格式化符号保留 (`:.2f`)
- ✅ 属性/字典访问自动清洗 (`user.name` → `user_name`)
- ✅ 自动添加导入语句
- ✅ 智能跳过短字符串和复杂表达式

## 核心理念

- **无数据库**: 文件系统就是数据库
- **Git 原生**: 版本控制依赖文件命名规范和 Git 提交
- **代码优先**: 开发者首先在代码中定义 Prompt
- **零延迟开发**: 开发模式使用代码中的字符串，生产模式读取 Lockfile

## License

MIT
