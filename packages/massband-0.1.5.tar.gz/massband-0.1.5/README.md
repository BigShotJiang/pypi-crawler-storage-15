# Massband

Molecular Dynamics post processing tools for large scale simulation data.

TODO: heatmap von den charges in den Trainignsdaten mit rdkit
TODO: plumed selector to plot CVs e.g. 2D angle via distance, cation-anion distance
TODO: something with clusters?
