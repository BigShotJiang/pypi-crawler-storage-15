# damndeepesh

View Deepesh Gupta's portfolio directly in your terminal!

## Installation

```bash
pip install damndeepesh
```

## Usage

```bash
damndeepesh
```
