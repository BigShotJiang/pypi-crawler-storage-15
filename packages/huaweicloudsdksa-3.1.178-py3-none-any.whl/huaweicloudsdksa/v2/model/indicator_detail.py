# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class IndicatorDetail:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'id': 'str',
        'name': 'str',
        'dataclass_id': 'str',
        'type': 'str',
        'data_object': 'IndicatorDataObjectDetail',
        'workspace_id': 'str',
        'project_id': 'str',
        'layout_id': 'str',
        'dataclass': 'DataClassRefPojo',
        'create_time': 'str',
        'update_time': 'str'
    }

    attribute_map = {
        'id': 'id',
        'name': 'name',
        'dataclass_id': 'dataclass_id',
        'type': 'type',
        'data_object': 'data_object',
        'workspace_id': 'workspace_id',
        'project_id': 'project_id',
        'layout_id': 'layout_id',
        'dataclass': 'dataclass',
        'create_time': 'create_time',
        'update_time': 'update_time'
    }

    def __init__(self, id=None, name=None, dataclass_id=None, type=None, data_object=None, workspace_id=None, project_id=None, layout_id=None, dataclass=None, create_time=None, update_time=None):
        r"""IndicatorDetail

        The model defined in huaweicloud sdk

        :param id: 指标ID
        :type id: str
        :param name: 指标名称
        :type name: str
        :param dataclass_id: 数据类ID
        :type dataclass_id: str
        :param type: 类型（SIMULATION,PLAYBOOK,MANUAL,INSTANCE,DATA_SOURCE）
        :type type: str
        :param data_object: 
        :type data_object: :class:`huaweicloudsdksa.v2.IndicatorDataObjectDetail`
        :param workspace_id: workspace id
        :type workspace_id: str
        :param project_id: Project id value
        :type project_id: str
        :param layout_id: 布局ID
        :type layout_id: str
        :param dataclass: 
        :type dataclass: :class:`huaweicloudsdksa.v2.DataClassRefPojo`
        :param create_time: Create time
        :type create_time: str
        :param update_time: Update time
        :type update_time: str
        """
        
        

        self._id = None
        self._name = None
        self._dataclass_id = None
        self._type = None
        self._data_object = None
        self._workspace_id = None
        self._project_id = None
        self._layout_id = None
        self._dataclass = None
        self._create_time = None
        self._update_time = None
        self.discriminator = None

        if id is not None:
            self.id = id
        self.name = name
        if dataclass_id is not None:
            self.dataclass_id = dataclass_id
        if type is not None:
            self.type = type
        if data_object is not None:
            self.data_object = data_object
        if workspace_id is not None:
            self.workspace_id = workspace_id
        if project_id is not None:
            self.project_id = project_id
        if layout_id is not None:
            self.layout_id = layout_id
        if dataclass is not None:
            self.dataclass = dataclass
        if create_time is not None:
            self.create_time = create_time
        if update_time is not None:
            self.update_time = update_time

    @property
    def id(self):
        r"""Gets the id of this IndicatorDetail.

        指标ID

        :return: The id of this IndicatorDetail.
        :rtype: str
        """
        return self._id

    @id.setter
    def id(self, id):
        r"""Sets the id of this IndicatorDetail.

        指标ID

        :param id: The id of this IndicatorDetail.
        :type id: str
        """
        self._id = id

    @property
    def name(self):
        r"""Gets the name of this IndicatorDetail.

        指标名称

        :return: The name of this IndicatorDetail.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        r"""Sets the name of this IndicatorDetail.

        指标名称

        :param name: The name of this IndicatorDetail.
        :type name: str
        """
        self._name = name

    @property
    def dataclass_id(self):
        r"""Gets the dataclass_id of this IndicatorDetail.

        数据类ID

        :return: The dataclass_id of this IndicatorDetail.
        :rtype: str
        """
        return self._dataclass_id

    @dataclass_id.setter
    def dataclass_id(self, dataclass_id):
        r"""Sets the dataclass_id of this IndicatorDetail.

        数据类ID

        :param dataclass_id: The dataclass_id of this IndicatorDetail.
        :type dataclass_id: str
        """
        self._dataclass_id = dataclass_id

    @property
    def type(self):
        r"""Gets the type of this IndicatorDetail.

        类型（SIMULATION,PLAYBOOK,MANUAL,INSTANCE,DATA_SOURCE）

        :return: The type of this IndicatorDetail.
        :rtype: str
        """
        return self._type

    @type.setter
    def type(self, type):
        r"""Sets the type of this IndicatorDetail.

        类型（SIMULATION,PLAYBOOK,MANUAL,INSTANCE,DATA_SOURCE）

        :param type: The type of this IndicatorDetail.
        :type type: str
        """
        self._type = type

    @property
    def data_object(self):
        r"""Gets the data_object of this IndicatorDetail.

        :return: The data_object of this IndicatorDetail.
        :rtype: :class:`huaweicloudsdksa.v2.IndicatorDataObjectDetail`
        """
        return self._data_object

    @data_object.setter
    def data_object(self, data_object):
        r"""Sets the data_object of this IndicatorDetail.

        :param data_object: The data_object of this IndicatorDetail.
        :type data_object: :class:`huaweicloudsdksa.v2.IndicatorDataObjectDetail`
        """
        self._data_object = data_object

    @property
    def workspace_id(self):
        r"""Gets the workspace_id of this IndicatorDetail.

        workspace id

        :return: The workspace_id of this IndicatorDetail.
        :rtype: str
        """
        return self._workspace_id

    @workspace_id.setter
    def workspace_id(self, workspace_id):
        r"""Sets the workspace_id of this IndicatorDetail.

        workspace id

        :param workspace_id: The workspace_id of this IndicatorDetail.
        :type workspace_id: str
        """
        self._workspace_id = workspace_id

    @property
    def project_id(self):
        r"""Gets the project_id of this IndicatorDetail.

        Project id value

        :return: The project_id of this IndicatorDetail.
        :rtype: str
        """
        return self._project_id

    @project_id.setter
    def project_id(self, project_id):
        r"""Sets the project_id of this IndicatorDetail.

        Project id value

        :param project_id: The project_id of this IndicatorDetail.
        :type project_id: str
        """
        self._project_id = project_id

    @property
    def layout_id(self):
        r"""Gets the layout_id of this IndicatorDetail.

        布局ID

        :return: The layout_id of this IndicatorDetail.
        :rtype: str
        """
        return self._layout_id

    @layout_id.setter
    def layout_id(self, layout_id):
        r"""Sets the layout_id of this IndicatorDetail.

        布局ID

        :param layout_id: The layout_id of this IndicatorDetail.
        :type layout_id: str
        """
        self._layout_id = layout_id

    @property
    def dataclass(self):
        r"""Gets the dataclass of this IndicatorDetail.

        :return: The dataclass of this IndicatorDetail.
        :rtype: :class:`huaweicloudsdksa.v2.DataClassRefPojo`
        """
        return self._dataclass

    @dataclass.setter
    def dataclass(self, dataclass):
        r"""Sets the dataclass of this IndicatorDetail.

        :param dataclass: The dataclass of this IndicatorDetail.
        :type dataclass: :class:`huaweicloudsdksa.v2.DataClassRefPojo`
        """
        self._dataclass = dataclass

    @property
    def create_time(self):
        r"""Gets the create_time of this IndicatorDetail.

        Create time

        :return: The create_time of this IndicatorDetail.
        :rtype: str
        """
        return self._create_time

    @create_time.setter
    def create_time(self, create_time):
        r"""Sets the create_time of this IndicatorDetail.

        Create time

        :param create_time: The create_time of this IndicatorDetail.
        :type create_time: str
        """
        self._create_time = create_time

    @property
    def update_time(self):
        r"""Gets the update_time of this IndicatorDetail.

        Update time

        :return: The update_time of this IndicatorDetail.
        :rtype: str
        """
        return self._update_time

    @update_time.setter
    def update_time(self, update_time):
        r"""Sets the update_time of this IndicatorDetail.

        Update time

        :param update_time: The update_time of this IndicatorDetail.
        :type update_time: str
        """
        self._update_time = update_time

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, IndicatorDetail):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
