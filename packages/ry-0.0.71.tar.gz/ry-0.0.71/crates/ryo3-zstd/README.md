# `ryo3-zstd`

ryo3-wrapper for `zstd` crate

[//]: # "<GENERATED>"

## Ref:

- docs.rs: [https://docs.rs/zstd](https://docs.rs/zstd)
- crates: [https://crates.io/crates/zstd](https://crates.io/crates/zstd)

[//]: # "</GENERATED>"
