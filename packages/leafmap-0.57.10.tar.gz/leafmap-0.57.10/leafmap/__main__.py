"""Allow package to be run as a module: python -m leafmap"""

from .cli import main

if __name__ == "__main__":
    main()
