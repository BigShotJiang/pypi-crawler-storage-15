# Credits

Credits to [Khalil Misbah](https://www.linkedin.com/in/khalil-misbah) for the original design of the leafmap logo.

![logo](https://raw.githubusercontent.com/opengeos/leafmap/master/docs/assets/logo.png)
