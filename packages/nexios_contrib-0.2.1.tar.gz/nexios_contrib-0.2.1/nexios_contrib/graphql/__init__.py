from .plugin import GraphQL

__all__ = ["GraphQL"]
