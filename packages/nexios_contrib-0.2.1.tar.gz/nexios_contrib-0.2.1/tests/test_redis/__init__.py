"""
Integration tests for Nexios Redis contrib module.
"""