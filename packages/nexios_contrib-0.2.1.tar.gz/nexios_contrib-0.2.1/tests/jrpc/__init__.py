"""
Tests for nexios contrib jrpc module.
"""
