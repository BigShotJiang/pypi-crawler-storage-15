class UnexpectedTypeError(Exception):
    pass

class MissingArgument(UnexpectedTypeError):
    pass