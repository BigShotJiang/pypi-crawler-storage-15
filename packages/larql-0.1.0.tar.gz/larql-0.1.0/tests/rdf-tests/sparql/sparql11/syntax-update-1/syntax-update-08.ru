DROP GRAPH <graph>
