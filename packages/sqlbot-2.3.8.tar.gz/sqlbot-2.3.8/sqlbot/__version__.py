"""Version information for SQLBot."""
__version__ = "2.3.8"


