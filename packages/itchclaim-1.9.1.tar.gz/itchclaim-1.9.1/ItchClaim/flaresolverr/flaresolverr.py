#!/usr/bin/env python3

from flaresolverr.flaresolverr import main

if __name__ == '__main__':
    main()
