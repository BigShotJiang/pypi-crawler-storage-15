import ceylonai_next
import sys
print(f"Module file: {ceylonai_next.__file__}")
print(f"sys.path: {sys.path}")
print(dir(ceylonai_next))
