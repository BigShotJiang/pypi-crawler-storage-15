# Mesh Networking

Automatically generated documentation for mesh networking classes.

## LocalMesh

::: ceylonai_next.LocalMesh
    options:
      show_root_heading: true
      show_source: true
      members_order: source
      heading_level: 3

## DistributedMesh

::: ceylonai_next.DistributedMesh
    options:
      show_root_heading: true
      show_source: true
      members_order: source
      heading_level: 3
