# Agent Classes

Automatically generated documentation for agent classes.

## Agent

::: ceylonai_next.Agent
    options:
      show_root_heading: true
      show_source: true
      members_order: source
      heading_level: 3

## LlmAgent

::: ceylonai_next.LlmAgent
    options:
      show_root_heading: true
      show_source: true
      members_order: source
      heading_level: 3
