# Actions and Tools

Automatically generated documentation for action classes.

## PyAction

::: ceylonai_next.PyAction
    options:
      show_root_heading: true
      show_source: true
      members_order: source
      heading_level: 3

## FunctionalAction

::: ceylonai_next.FunctionalAction
    options:
      show_root_heading: true
      show_source: true
      members_order: source
      heading_level: 3
