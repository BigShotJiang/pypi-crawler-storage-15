from serverz.core.debug_agent import Work


def test_work():
    work = Work()
    work.run("你好, 你是谁?")