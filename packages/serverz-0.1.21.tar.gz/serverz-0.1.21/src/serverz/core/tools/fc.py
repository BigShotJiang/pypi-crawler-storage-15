
def add_func(a: int, b: int) -> int:
    """Add two numbers"""
    print('run add_func')
    return a + b
