:orphan:

..
   This page is not included in the TOC tree, but must exist so that the
   autosummary pages are generated for daq_config_server and all its
   subpackages

API
===

.. autosummary::
    :toctree: _api
    :template: custom-module-template.rst
    :recursive:

    daq_config_server
