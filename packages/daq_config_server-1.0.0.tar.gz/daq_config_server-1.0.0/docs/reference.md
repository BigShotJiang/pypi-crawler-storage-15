# Reference

Technical reference material including APIs and release notes.

```{toctree}
:maxdepth: 1
:glob:

Current and future features <reference/current_and_planned_features.md>
API <_api/daq_config_server>
genindex
Release Notes <https://github.com/DiamondLightSource/daq-config-server/releases>
```
