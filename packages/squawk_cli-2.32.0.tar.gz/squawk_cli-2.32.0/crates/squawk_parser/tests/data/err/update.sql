update t set (j k) = (1, 2);
--             ^ missing comma

update t set a = 1 b = 2;
--                ^ missing comma
