-- notify_stmt
NOTIFY foo;
NOTIFY virtual, 'This is the payload';

