-- simple
drop language s;

-- full
drop language if exists a cascade;
drop procedural language if exists a restrict;

