-- docs
SET ROLE 'paul';

SET ROLE NONE;

SET LOCAL ROLE NONE;

SET SESSION ROLE foo;

set role 'fooo';

RESET ROLE;

