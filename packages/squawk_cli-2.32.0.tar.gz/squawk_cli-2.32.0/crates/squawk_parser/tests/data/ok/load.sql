-- pg_docs
load 'foo';

