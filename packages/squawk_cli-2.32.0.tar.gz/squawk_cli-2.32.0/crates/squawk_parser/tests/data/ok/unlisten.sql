-- pg_docs
unlisten virtual;

unlisten *;

