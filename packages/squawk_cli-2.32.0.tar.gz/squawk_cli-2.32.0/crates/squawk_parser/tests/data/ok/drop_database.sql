-- drop_database
drop database d;

drop database d ( force);
drop database d with ( force, force );

drop database "table_name";

drop database if exists "table_name";

drop database if exists "table_name"

