-- simple
drop publication s;

-- full
drop publication if exists a, b, c cascade;
drop publication if exists a, b, c restrict;

