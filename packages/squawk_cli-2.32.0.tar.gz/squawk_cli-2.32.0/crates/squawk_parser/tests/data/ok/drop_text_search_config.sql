-- simple
drop text search configuration foo;

-- full
drop text search configuration if exists bar cascade;

-- restrict
drop text search configuration bar restrict;

