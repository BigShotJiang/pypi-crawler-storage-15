-- simple
drop extension s;

-- full
drop extension if exists a, b, c cascade;
drop extension if exists a, b, c restrict;

