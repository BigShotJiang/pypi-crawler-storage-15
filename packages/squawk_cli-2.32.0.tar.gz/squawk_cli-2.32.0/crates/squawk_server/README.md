# squawk_server

LSP server for Squawk.
