"""Test package for TrigDroid.

This package contains all tests for the TrigDroid Android security testing framework.
Tests are organized into unit tests, integration tests, and fixtures.
"""