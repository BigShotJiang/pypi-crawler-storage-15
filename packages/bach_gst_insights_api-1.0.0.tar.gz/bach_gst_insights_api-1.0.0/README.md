# Gst Insights Api MCP Server

[English](./README_EN.md) | 简体中文 | [繁體中文](./README_ZH-TW.md)

用于访问 Gst Insights Api API 的 MCP 服务器。

## 🚀 使用 EMCP 平台快速体验

**[EMCP](https://sit-emcp.kaleido.guru)** 是一个强大的 MCP 服务器管理平台，让您无需手动配置即可快速使用各种 MCP 服务器！

### 快速开始：

1. 🌐 访问 **[EMCP 平台](https://sit-emcp.kaleido.guru)**
2. 📝 注册并登录账号
3. 🎯 进入 **MCP 广场**，浏览所有可用的 MCP 服务器
4. 🔍 搜索或找到本服务器（`bach-gst_insights_api`）
5. 🎉 点击 **"安装 MCP"** 按钮
6. ✅ 完成！即可在您的应用中使用

### EMCP 平台优势：

- ✨ **零配置**：无需手动编辑配置文件
- 🎨 **可视化管理**：图形界面轻松管理所有 MCP 服务器
- 🔐 **安全可靠**：统一管理 API 密钥和认证信息
- 🚀 **一键安装**：MCP 广场提供丰富的服务器选择
- 📊 **使用统计**：实时查看服务调用情况

立即访问 **[EMCP 平台](https://sit-emcp.kaleido.guru)** 开始您的 MCP 之旅！


---

## 简介

这是一个 MCP 服务器，用于访问 Gst Insights Api API。

- **PyPI 包名**: `bach-gst_insights_api`
- **版本**: 1.0.0
- **传输协议**: stdio


## 安装

### 从 PyPI 安装:

```bash
pip install bach-gst_insights_api
```

### 从源码安装:

```bash
pip install -e .
```

## 运行

### 方式 1: 使用 uvx（推荐，无需安装）

```bash
# 运行（uvx 会自动安装并运行）
uvx --from bach-gst_insights_api bach_gst_insights_api

# 或指定版本
uvx --from bach-gst_insights_api@latest bach_gst_insights_api
```

### 方式 2: 直接运行（开发模式）

```bash
python server.py
```

### 方式 3: 安装后作为命令运行

```bash
# 安装
pip install bach-gst_insights_api

# 运行（命令名使用下划线）
bach_gst_insights_api
```

## 配置

### API 认证

此 API 需要认证。请设置环境变量:

```bash
export API_KEY="your_api_key_here"
```

### 环境变量

| 变量名 | 说明 | 必需 |
|--------|------|------|
| `API_KEY` | API 密钥 | 是 |
| `PORT` | 不适用 | 否 |
| `HOST` | 不适用 | 否 |



### 在 Cursor 中使用

编辑 Cursor MCP 配置文件 `~/.cursor/mcp.json`:


```json
{
  "mcpServers": {
    "bach-gst_insights_api": {
      "command": "uvx",
      "args": ["--from", "bach-gst_insights_api", "bach_gst_insights_api"],
      "env": {
        "API_KEY": "your_api_key_here"
      }
    }
  }
}
```

### 在 Claude Desktop 中使用

编辑 Claude Desktop 配置文件 `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "bach-gst_insights_api": {
      "command": "uvx",
      "args": ["--from", "bach-gst_insights_api", "bach_gst_insights_api"],
      "env": {
        "API_KEY": "your_api_key_here"
      }
    }
  }
}
```


## 可用工具

此服务器提供以下工具:


### `get_gst_details_using_gst_number_`

Endpoint: /getGSTDetailsUsingGST/:gst  Method: GET  Description: Fetches GST details using the provided GST number.  Parameters:  gst (string, required): A valid GST number (15 characters). Responses:  200 OK: Returns GST details along with a timestamp. 400 Bad Request: Invalid GST number. 500 Internal Server Error: An error occurred on the server. Example Request:   `GET /getGSTDetailsUsingGST/22ABCDE1234F1Z5`

**端点**: `GET /getGSTDetailsUsingGST/{gstNumber}`


**参数**:

- `gstNumber` (string) *必需*: Example value: 27AABCI6363G3ZH



---


### `get_gst_details_using_pan_`

Endpoint: /getGSTDetailsUsingPAN/:pan  Method: GET  Description: Fetches GST details using the provided PAN number.  Parameters:  pan (string, required): A valid PAN number (10 characters). Responses:  200 OK: Returns GST details along with a timestamp. 400 Bad Request: Invalid PAN number. 500 Internal Server Error: An error occurred on the server. Example Request:  `GET /getGSTDetailsUsingPAN/ABCDE1234F`

**端点**: `GET /getGSTDetailsUsingPAN/{panCard}`


**参数**:

- `panCard` (string) *必需*: Example value: AABCI6363G



---


### `get_gst_status_`

Endpoint: /getGSTStatus/:gst  Method: GET  Description: Retrieves the status of the provided GST number.  Parameters:  gst (string, required): A valid GST number (15 characters). Responses:  200 OK: Returns GST status along with a timestamp. 400 Bad Request: Invalid GST number. 500 Internal Server Error: An error occurred on the server.  `GET /getGSTStatus/22ABCDE1234F1Z5`

**端点**: `GET /getGSTStatus/{GSTNumber}`


**参数**:

- `GSTNumber` (string) *必需*: Example value: 27AABCI6363G3ZH



---


### `get_gst_return_filing_status_for_a_specific_year_`

Endpoint: /getGSTReturnFilingStatusSpecificYear/:gst/:year  Method: GET  Description: Fetches the GST return filing status for a specific year using the provided GST number.  Parameters:  gst (string, required): A valid GST number (15 characters). year (string, required): The year for which the status is to be fetched. Responses:  200 OK: Returns GST return filing status for the specific year along with a timestamp. 400 Bad Request: Invalid GST number or year. 500 Internal Server Error: An er...

**端点**: `GET /getGSTReturnFilingStatusSpecificYear/{GSTNumber}/{year}`


**参数**:

- `GSTNumber` (string) *必需*: Example value: 27AABCI6363G3ZH

- `year` (string) *必需*: Example value: 2022-2023



---


### `get_address_using_gst_`

Endpoint: /getAddressUsingGST/:gst  Method: GET  Description: Retrieves the address associated with the provided GST number.  Parameters:  gst (string, required): A valid GST number (15 characters). Responses:  200 OK: Returns the address associated with the GST number along with a timestamp. 400 Bad Request: Invalid GST number. 500 Internal Server Error: An error occurred on the server.  `GET /getAddressUsingGST/22ABCDE1234F1Z5`

**端点**: `GET /getAddressUsingGST/{GSTNumber}`


**参数**:

- `GSTNumber` (string) *必需*: Example value: 27AABCI6363G3ZH



---


### `get_gst_return_filing_status_`

Endpoint: /getGSTReturnFilingStatus/:gst  Method: GET  Description: Fetches the GST return filing status of the provided GST number.  Parameters:  gst (string, required): A valid GST number (15 characters). Responses:  200 OK: Returns GST return filing status along with a timestamp. 400 Bad Request: Invalid GST number. 500 Internal Server Error: An error occurred on the server. Example Request:  `GET /getGSTReturnFilingStatus/22ABCDE1234F1Z5`

**端点**: `GET /getGSTReturnFilingStatus/{GSTNumber}`


**参数**:

- `GSTNumber` (string) *必需*: Example value: 27AABCI6363G3ZH



---


### `validate_gst_number_`

Endpoint: /validateGSTNumber/:gst  Method: GET  Description: Validates the provided GST number.  Parameters:  gst (string, required): A valid GST number (15 characters). Responses:  200 OK: Returns validation results along with a timestamp. 400 Bad Request: Invalid GST number. 500 Internal Server Error: An error occurred on the server.  `GET /validateGSTNumber/22ABCDE1234F1Z5`

**端点**: `GET /validateGSTNumber/{GSTNumber}`


**参数**:

- `GSTNumber` (string) *必需*: Example value: 27AABCI6363G3ZH



---


### `get_gst_details_using_company_name_`

Endpoint: /getGSTDetailsUsingCompanyName/:companyName  Method: GET  Description: Fetches GST details using the provided company name.  Parameters:  companyName (string, required): The name of the company. Responses:  200 OK: Returns GST details along with a timestamp. 400 Bad Request: Invalid company name. 500 Internal Server Error: An error occurred on the server. Example Request:  `GET /getGSTDetailsUsingCompanyName/jio`

**端点**: `GET /getGSTDetailsUsingCompanyName/{name}`


**参数**:

- `name` (string) *必需*: Example value: Reliance Jio Infocomm Limited



---



## 技术栈

- **传输协议**: stdio
- **HTTP 客户端**: httpx


## 许可证

MIT License - 详见 [LICENSE](./LICENSE) 文件。

## 开发

此服务器由 [API-to-MCP](https://github.com/BACH-AI-Tools/api-to-mcp) 工具生成。

版本: 1.0.0
