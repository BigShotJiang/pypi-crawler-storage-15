"""Module for getting intermediates."""
