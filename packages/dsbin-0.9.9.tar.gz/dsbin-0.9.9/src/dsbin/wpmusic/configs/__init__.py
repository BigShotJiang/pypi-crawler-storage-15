from __future__ import annotations

from .table_config import TableConfig
from .wp_config import WPConfig
