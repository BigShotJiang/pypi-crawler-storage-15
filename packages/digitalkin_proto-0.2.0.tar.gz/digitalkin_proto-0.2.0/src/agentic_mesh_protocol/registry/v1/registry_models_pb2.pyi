import datetime

from agentic_mesh_protocol.registry.v1 import registry_enums_pb2 as _registry_enums_pb2
from google.protobuf import struct_pb2 as _struct_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ModuleDescriptor(_message.Message):
    __slots__ = ()
    ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    MODULE_TYPE_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    ADDRESS_FIELD_NUMBER: _ClassVar[int]
    PORT_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    VISIBILITY_FIELD_NUMBER: _ClassVar[int]
    ORGANIZATION_ID_FIELD_NUMBER: _ClassVar[int]
    OWNER_ID_FIELD_NUMBER: _ClassVar[int]
    INPUT_SCHEMA_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_SCHEMA_FIELD_NUMBER: _ClassVar[int]
    SETUP_SCHEMA_FIELD_NUMBER: _ClassVar[int]
    SECRET_SCHEMA_FIELD_NUMBER: _ClassVar[int]
    COST_SCHEMA_FIELD_NUMBER: _ClassVar[int]
    DOCUMENTATION_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    name: str
    module_type: _registry_enums_pb2.ModuleType
    version: str
    address: str
    port: int
    status: _registry_enums_pb2.ModuleStatus
    visibility: _registry_enums_pb2.Visibility
    organization_id: str
    owner_id: str
    input_schema: _struct_pb2.Struct
    output_schema: _struct_pb2.Struct
    setup_schema: _struct_pb2.Struct
    secret_schema: _struct_pb2.Struct
    cost_schema: _struct_pb2.Struct
    documentation: str
    created_at: _timestamp_pb2.Timestamp
    updated_at: _timestamp_pb2.Timestamp
    def __init__(self, id: _Optional[str] = ..., name: _Optional[str] = ..., module_type: _Optional[_Union[_registry_enums_pb2.ModuleType, str]] = ..., version: _Optional[str] = ..., address: _Optional[str] = ..., port: _Optional[int] = ..., status: _Optional[_Union[_registry_enums_pb2.ModuleStatus, str]] = ..., visibility: _Optional[_Union[_registry_enums_pb2.Visibility, str]] = ..., organization_id: _Optional[str] = ..., owner_id: _Optional[str] = ..., input_schema: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., output_schema: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., setup_schema: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., secret_schema: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., cost_schema: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., documentation: _Optional[str] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., updated_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class SetupDescriptor(_message.Message):
    __slots__ = ()
    ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DOCUMENTATION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    VISIBILITY_FIELD_NUMBER: _ClassVar[int]
    ORGANIZATION_ID_FIELD_NUMBER: _ClassVar[int]
    OWNER_ID_FIELD_NUMBER: _ClassVar[int]
    CARD_ID_FIELD_NUMBER: _ClassVar[int]
    MODULE_ID_FIELD_NUMBER: _ClassVar[int]
    SETUP_VERSION_ID_FIELD_NUMBER: _ClassVar[int]
    SETUP_VERSION_FIELD_NUMBER: _ClassVar[int]
    CONFIG_FIELD_NUMBER: _ClassVar[int]
    MODULE_FIELD_NUMBER: _ClassVar[int]
    id: str
    name: str
    documentation: str
    status: _registry_enums_pb2.SetupStatus
    visibility: _registry_enums_pb2.Visibility
    organization_id: str
    owner_id: str
    card_id: str
    module_id: str
    setup_version_id: str
    setup_version: str
    config: _struct_pb2.Struct
    module: ModuleDescriptor
    def __init__(self, id: _Optional[str] = ..., name: _Optional[str] = ..., documentation: _Optional[str] = ..., status: _Optional[_Union[_registry_enums_pb2.SetupStatus, str]] = ..., visibility: _Optional[_Union[_registry_enums_pb2.Visibility, str]] = ..., organization_id: _Optional[str] = ..., owner_id: _Optional[str] = ..., card_id: _Optional[str] = ..., module_id: _Optional[str] = ..., setup_version_id: _Optional[str] = ..., setup_version: _Optional[str] = ..., config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., module: _Optional[_Union[ModuleDescriptor, _Mapping]] = ...) -> None: ...
