from __future__ import annotations
import datetime as dt

from rayforce import _rayforce_c as r
from rayforce.core.ffi import FFI
from rayforce.types.base import Scalar
from rayforce.types.registry import TypeRegistry
from rayforce.types import exceptions

epoch2000_py = dt.datetime(2000, 1, 1, tzinfo=dt.timezone.utc)


def _datetime_to_ns(obj: dt.datetime) -> int:
    return (
        obj.days * 24 * 3600 * 1_000_000_000
        + obj.seconds * 1_000_000_000
        + obj.microseconds * 1_000
    )


class Timestamp(Scalar):
    """
    Represents a point in time with millisecond precision.
    """

    type_code = -r.TYPE_TIMESTAMP
    ray_name = "Timestamp"

    def _create_from_value(self, value: dt.datetime | int | str) -> r.RayObject:
        if isinstance(value, dt.datetime):
            return FFI.init_timestamp(_datetime_to_ns(value - epoch2000_py))
        elif isinstance(value, int):
            return FFI.init_timestamp(value)
        elif isinstance(value, str):
            try:
                dt_obj = dt.datetime.fromisoformat(value)
            except ValueError as e:
                raise exceptions.RayInitException(
                    f"Timestamp value is not isoformat: {value}"
                ) from e
            return FFI.init_timestamp(_datetime_to_ns(dt_obj - epoch2000_py))
        raise exceptions.RayInitException(f"Cannot create Timestamp from {type(value)}")

    def to_python(self) -> dt.datetime:
        return epoch2000_py + dt.timedelta(
            microseconds=FFI.read_timestamp(self.ptr) // 1000
        )

    def to_millis(self) -> int:
        return FFI.read_timestamp(self.ptr)


TypeRegistry.register(-r.TYPE_TIMESTAMP, Timestamp)
