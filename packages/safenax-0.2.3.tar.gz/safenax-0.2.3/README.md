# safenax

Cost constrained environments (e.g. CMDPs) with a gymnax interface.
