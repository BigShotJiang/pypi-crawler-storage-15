from phoenix.evals.legacy.models.litellm import LiteLLMModel

__all__ = [
    "LiteLLMModel",
]
