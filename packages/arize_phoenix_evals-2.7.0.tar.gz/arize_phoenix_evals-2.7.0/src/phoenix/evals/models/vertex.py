from phoenix.evals.legacy.models.vertex import GeminiModel

__all__ = [
    "GeminiModel",
]
