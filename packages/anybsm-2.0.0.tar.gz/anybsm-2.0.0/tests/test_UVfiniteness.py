#!/usr/bin/env python3
import unittest
from anyBSM import anyBSM
import numpy.testing as test
import logging
logging.getLogger('anyBSM').setLevel(logging.WARNING)

def scaledep(model,states):
    lamQ1 = model.lambdahhh(fields=states, parameters = {'Qren': 172.5})['total'].real
    lamQ2 = model.lambdahhh(fields=states, parameters = {'Qren': 17250000})['total'].real
    return lamQ1, lamQ2

SM = anyBSM('SM', quiet = True, progress = False, scheme_name = 'OS')

THDM = anyBSM('THDMII', quiet = True, progress = False, caching = 2, scheme_name = 'OS')
THDM.setparameters({'alphaH': 0.1, 'Mh1':125.1,'Mh2':400,'MAh2':410,'MHm2': 420, 'TanBeta': 3,'M': 430})

class numericTest(unittest.TestCase):
    """ checks UV-finiteness of lam_ijk in various BSM models by checking the scale-dependence of OS schemes  """

    def test_UV_SM(self):
        """ test UV-finiteness in the SM for lamhhh """
        test.assert_allclose(*scaledep(SM,['h','h','h']))

    def test_UV_THDM111_no_alignment(self):
        """ test UV-finiteness in the THDM for lamhhh away from the alignment limit """
        test.assert_allclose(*scaledep(THDM,['h1','h1','h1']))

    def test_UV_THDM112_no_alignment(self):
        """ test UV-finiteness in the THDM for lamhhH away from the alignment limit """
        test.assert_allclose(*scaledep(THDM,['h1','h1','h2']))

    def test_UV_THDM122_no_alignment(self):
        """ test UV-finiteness in the THDM for lamhHH away from the alignment limit """
        test.assert_allclose(*scaledep(THDM,['h1','h2','h2']))

    def test_UV_THDM222_no_alignment(self):
        """ test UV-finiteness in the THDM for lamHHH away from the alignment limit """
        test.assert_allclose(*scaledep(THDM,['h2','h2','h2']))
