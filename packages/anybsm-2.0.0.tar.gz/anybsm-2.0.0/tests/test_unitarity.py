#!/usr/bin/env python3
import unittest
from numpy import arctan, arcsin
from anyBSM import anyPerturbativeUnitarity
import numpy.testing as test
import logging
logging.getLogger('anyBSM').setLevel(logging.WARNING)


THDM = anyPerturbativeUnitarity('THDMII', quiet = True, progress = False)

# result obtained with SPheno using the same default input parameters
eigSSSS_SPheno = 0.52212574

class numericTest(unittest.TestCase):

    def test_eigSSSS(self):
        """ compute and compare largest SS->SS scattering eigenvalue """
        eigSSSS_anyBSM = THDM.eigSSSS(parameters = {'alphaH': arctan(2)-arcsin(0.9), 'TanBeta':2, 'Mh1':125.1, 'Mh2': 300., 'MAh2': 300., 'MHm2': 550., 'M': 0})
        test.assert_allclose(eigSSSS_SPheno, eigSSSS_anyBSM)
