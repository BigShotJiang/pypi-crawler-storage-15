    def determineCP(self):
        """
        Check for the presence of various CP-violating couplings in the SM sector.
        If nothing was found, determine the CP numbers.
        This is only a tree-level check and not a very sophiticated one!
        """
        try:
            # h = self.SM_particles['Higgs-Boson']
            Z = self.SM_particles['Z-Boson']
        except KeyError:
            logger.error('Need to define SM particles in schemes.yml and `load_renormalization_scheme`')
            return None

        CPVcoups = [(Z,Z,Z)]
        for s in self.particles['S']:
            CPVcoups.append((Z,s,s))

        for c in CPVcoups:
            coup = self.getcoupling(c)
            if coup and 'c' in coup and abs(coup['c'].nvalue) > 1e-10:
                logger.debug("CP-violating coupling {c} found. No CP defined.")
                return {}

        # CP should be well-defined at tree-level. determine it for the scalars

        for s in self.particles['S']:
            pass
            # TODO
