import sympy as sp
from anyBSM.loopfunctions import C0, D0
from functools import lru_cache

class GenericFormactors():
    def __init__(self, evaluation = 'analytical'):
        if evaluation == 'analytical':
            self.C0 = sp.Function('C0')
            self.D0 = sp.Function('D0')
        if evaluation == 'numerical':
            self.C0 = C0
            self.D0 = D0

class diHiggs(GenericFormactors):
    """ formfactors for diHiggs """
    cache_size = 500

    @lru_cache(maxsize=cache_size)
    def FTriangleH(self, MT2, S):
        return 2*sp.sqrt(MT2)*(2+(4*MT2-S)*self.C0(0,S,0,MT2,MT2,MT2))/S

    @lru_cache(maxsize=cache_size)
    def FTriangleA(self, MT2, S):
        return -8*sp.sqrt(MT2)*self.C0(0,S,0,MT2,MT2,MT2)

    @lru_cache(maxsize=cache_size)
    def FBoxHH(self, MT2, MHa2, MHb2, S, T):
        return (-4*S+(MHb2+MHa2-8*MT2)*(MHa2-T)*self.C0(0,MHa2,T,MT2,MT2,MT2)-8*MT2*S*self.C0(0,S,0,MT2,MT2,MT2)-(MHb2+MHa2-8*MT2)*(MHa2-S-T)*self.C0(MHb2,0,MHb2+MHa2-S-T,MT2,MT2,MT2)+(2*S*(MHb2*(MHa2-2*MT2)+2*MT2*(-MHa2+S))*(-MHb2-MHa2+S+2*T)*self.C0(MHb2,MHa2,S,MT2,MT2,MT2))/(MHb2**2+(MHa2-S)**2-2*MHb2*(MHa2+S))+(MHb2+MHa2-8*MT2)*(MHb2-T)*self.C0(MHb2,T,0,MT2,MT2,MT2)+(2*S*(MHb2*(MHa2-2*MT2)+2*MT2*(-MHa2+S))*(MHb2+MHa2-S-2*T)*self.C0(MHa2,MHb2,S,MT2,MT2,MT2))/(MHb2**2+(MHa2-S)**2-2*MHb2*(MHa2+S))-(MHb2+MHa2-8*MT2)*(MHb2-S-T)*self.C0(MHb2+MHa2-S-T,MHa2,0,MT2,MT2,MT2)+2*MT2*S*(MHb2+MHa2-8*MT2+S)*self.D0(0,MHb2,MHa2,0,MHb2+MHa2-S-T,S,MT2,MT2,MT2,MT2)+2*MT2*S*(MHb2+MHa2-8*MT2+S)*self.D0(0,MHa2,MHb2,0,T,S,MT2,MT2,MT2,MT2)-(-2*MHa2*MT2*(S-4*T)+MHb2**2*(MHa2-T)-MHa2**2*T+MHa2*T*(S+T)+MHb2*(MHa2**2-2*MT2*(S-4*T)-2*MHa2*(4*MT2+T)+T*(S+T))+2*MT2*(8*MT2*S-(S+2*T)**2))*self.D0(MHb2,0,MHa2,0,MHb2+MHa2-S-T,T,MT2,MT2,MT2,MT2))/(S**2)

    @lru_cache(maxsize=cache_size)
    def FBoxAA(self, MT2, MHa2, MHb2, S, T):
        return ((4*S-(MHb2+MHa2)*(MHa2-T)*self.C0(0,MHa2,T,MT2,MT2,MT2)+8*MT2*S*self.C0(0,S,0,MT2,MT2,MT2)+(MHb2+MHa2)*(MHa2-S-T)*self.C0(MHb2,0,MHb2+MHa2-S-T,MT2,MT2,MT2)+(2*MHb2*MHa2*S*(MHb2+MHa2-S-2*T)*self.C0(MHb2,MHa2,S,MT2,MT2,MT2))/(MHb2**2+(MHa2-S)**2-2*MHb2*(MHa2+S))-(MHb2+MHa2)*(MHb2-T)*self.C0(MHb2,T,0,MT2,MT2,MT2)-(2*MHb2*MHa2*S*(MHb2+MHa2-S-2*T)*self.C0(MHa2,MHb2,S,MT2,MT2,MT2))/(MHb2**2+(MHa2-S)**2-2*MHb2*(MHa2+S))+(MHb2+MHa2)*(MHb2-S-T)*self.C0(MHb2+MHa2-S-T,MHa2,0,MT2,MT2,MT2)-2*MT2*(MHb2+MHa2-S)*S*self.D0(0,MHb2,MHa2,0,MHb2+MHa2-S-T,S,MT2,MT2,MT2,MT2)-2*MT2*(MHb2+MHa2-S)*S*self.D0(0,MHa2,MHb2,0,T,S,MT2,MT2,MT2,MT2)+(-2*MHa2*MT2*S+2*MT2*S**2+MHb2**2*(MHa2-T)-MHa2**2*T+MHa2*T*(S+T)+MHb2*(MHa2**2-2*MT2*S-2*MHa2*T+T*(S+T)))*self.D0(MHb2,0,MHa2,0,MHb2+MHa2-S-T,T,MT2,MT2,MT2,MT2)))/(S**2)

    @lru_cache(maxsize=cache_size)
    def FBoxHA(self, MT2, MHa2, MHb2, S, T):
        return ((-((MHb2-MHa2)*(MHa2-T)*self.C0(0,MHa2,T,MT2,MT2,MT2))+(MHb2-MHa2)*(MHa2-S-T)*self.C0(MHb2,0,MHb2+MHa2-S-T,MT2,MT2,MT2)-(MHb2-MHa2)*(MHb2-T)*self.C0(MHb2,T,0,MT2,MT2,MT2)+(MHb2-MHa2)*(MHb2-S-T)*self.C0(MHb2+MHa2-S-T,MHa2,0,MT2,MT2,MT2)+2*MT2*S*(-MHb2+MHa2+S)*self.D0(0,MHb2,MHa2,0,MHb2+MHa2-S-T,S,MT2,MT2,MT2,MT2)+2*MT2*S*(-MHb2+MHa2+S)*self.D0(0,MHa2,MHb2,0,T,S,MT2,MT2,MT2,MT2)+(-(MHb2*MHa2**2)-2*MHb2*MT2*S+2*MHa2*MT2*S+2*MT2*S**2+MHb2**2*(MHa2-T)+MHa2**2*T+MHb2*T*(S+T)-MHa2*T*(S+T))*self.D0(MHb2,0,MHa2,0,MHb2+MHa2-S-T,T,MT2,MT2,MT2,MT2)))/(S**2)

    @lru_cache(maxsize=cache_size)
    def GBoxHH(self, MT2, MHa2, MHb2, S, T):
        return (((MHb2**2+(MHa2-S)**2-2*MHb2*(MHa2+S))*(MHa2-S-T)*(MHb2**2+3*MHb2*MHa2+(MHa2-S-T)*(MHa2-8*MT2-S-T)-2*MHb2*(4*MT2+S+T))*self.C0(0,MHb2,MHb2+MHa2-S-T,MT2,MT2,MT2)-(MHb2**2+(MHa2-S)**2-2*MHb2*(MHa2+S))*(MHa2-T)*(MHb2*MHa2+T*(-8*MT2+T))*self.C0(0,MHa2,T,MT2,MT2,MT2)+S*(MHb2**2+(MHa2-S)**2-2*MHb2*(MHa2+S))*(MHb2**2+4*MHb2*MHa2+MHa2**2+8*MT2*S+S**2+2*S*T+2*T**2-2*MHb2*(4*MT2+S+T)-2*MHa2*(4*MT2+S+T))*self.C0(0,S,0,MT2,MT2,MT2)-(MHb2**5+(MHa2-S)**2*(MHa2-8*MT2-S)*(-MHa2+S+T)**2-MHb2**4*(8*MT2+5*S+2*T)-MHb2**3*(MHa2**2-10*S**2+MHa2*(-8*MT2+3*S)-8*S*T-T**2-4*MT2*(7*S+4*T))-MHb2**2*(MHa2**3+2*MHa2**2*(S-2*T)+MHa2*(-13*S**2-8*MT2*(S-2*T)-4*S*T+T**2)+8*MT2*(5*S**2+5*S*T+T**2)+S*(10*S**2+12*S*T+3*T**2))+MHb2*(MHa2**3*(8*MT2-5*S)+MHa2**2*(15*S**2+4*MT2*(3*S-4*T)+8*S*T-T**2)-MHa2*(8*MT2*(6*S**2+3*S*T-2*T**2)+S*(15*S**2+16*S*T+2*T**2))+S*(S*(5*S**2+8*S*T+3*T**2)+4*MT2*(7*S**2+10*S*T+4*T**2))))*self.C0(MHb2,MHa2,S,MT2,MT2,MT2)+(MHb2**4*MHa2-(MHa2-S)**2*(MHa2-8*MT2-S)*T**2-MHb2**3*(MHa2**2+4*MT2*S+MHa2*(8*MT2+S)+T**2)+MHb2**2*(-MHa2**3+16*MHa2**2*MT2+3*S*T**2+MHa2*(8*MT2*S+S**2-4*S*T+T**2)+8*MT2*(S**2+S*T+T**2))+MHb2*(MHa2**4-MHa2**3*(8*MT2+3*S)+MHa2**2*(12*MT2*S+3*S**2+T**2)-MHa2*(S**3+16*MT2*T**2-2*S*T*(4*MT2+T))-S*(3*S*T**2+4*MT2*(S**2+2*S*T+4*T**2))))*self.C0(MHa2,MHb2,S,MT2,MT2,MT2)+(MHb2**2+(MHa2-S)**2-2*MHb2*(MHa2+S))*(MHb2-S-T)*(MHb2**2+3*MHb2*MHa2+(MHa2-S-T)*(MHa2-8*MT2-S-T)-2*MHb2*(4*MT2+S+T))*self.C0(MHb2+MHa2-S-T,MHa2,0,MT2,MT2,MT2)-(MHb2**2+(MHa2-S)**2-2*MHb2*(MHa2+S))*(MHb2-T)*(MHb2*MHa2+T*(-8*MT2+T))*self.C0(T,MHb2,0,MT2,MT2,MT2)-(MHb2**2+(MHa2-S)**2-2*MHb2*(MHa2+S))*(MHb2**3*S-MHb2**2*(2*MHa2*(MT2-2*S)+MT2*(8*S-2*T)+3*S*(S+T))+(MHa2-S-T)*(MHa2**2*S-16*MT2**2*T+S*(S+T)**2+2*MT2*S*(4*S+3*T)-2*MHa2*(MT2*(4*S-T)+S*(S+T)))-MHb2*(2*MHa2**2*(MT2-2*S)+16*MT2**2*T-3*S*(S+T)**2-2*MT2*(8*S**2+6*S*T-T**2)+MHa2*(-16*MT2**2+2*MT2*(7*S-2*T)+7*S*(S+T))))*self.D0(0,MHb2,MHa2,0,MHb2+MHa2-S-T,S,MT2,MT2,MT2,MT2)-(MHb2**2+(MHa2-S)**2-2*MHb2*(MHa2+S))*(2*MHb2**2*MT2*(-MHa2+T)+T*(2*MHa2**2*MT2+2*MT2*S*(S-3*T)+S*T**2+16*MT2**2*(S+T)-2*MHa2*MT2*(8*MT2+2*S+T))+MHb2*(-2*MHa2**2*MT2-2*MT2*T*(8*MT2+2*S+T)+MHa2*(16*MT2**2+S*T+2*MT2*(S+2*T))))*self.D0(0,MHa2,MHb2,0,T,S,MT2,MT2,MT2,MT2)+2*MT2*(MHb2+MHa2-8*MT2-S)*(MHb2**2+(MHa2-S)**2-2*MHb2*(MHa2+S))*(MHb2*(MHa2-T)+T*(-MHa2+S+T))*self.D0(MHb2,0,MHa2,0,MHb2+MHa2-S-T,T,MT2,MT2,MT2,MT2)))/(S*(MHb2**2+(MHa2-S)**2-2*MHb2*(MHa2+S))*(MHb2*(MHa2-T)+T*(-MHa2+S+T)))

    @lru_cache(maxsize=cache_size)
    def GBoxAA(self, MT2, MHa2, MHb2, S, T):
        return ((-((MHb2**2+(MHa2-S)**2-2*MHb2*(MHa2+S))*(MHa2-S-T)*(MHb2**2+3*MHb2*MHa2-2*MHb2*(S+T)+(-MHa2+S+T)**2)*self.C0(0,MHb2,MHb2+MHa2-S-T,MT2,MT2,MT2))+(MHb2**2+(MHa2-S)**2-2*MHb2*(MHa2+S))*(MHa2-T)*(MHb2*MHa2+T**2)*self.C0(0,MHa2,T,MT2,MT2,MT2)-S*(MHb2**2+(MHa2-S)**2-2*MHb2*(MHa2+S))*(MHb2**2+4*MHb2*MHa2+MHa2**2+S**2+2*S*T+2*T**2-2*MHb2*(S+T)-2*MHa2*(S+T))*self.C0(0,S,0,MT2,MT2,MT2)+(MHb2**5+(MHa2-S)**3*(-MHa2+S+T)**2-MHb2**4*(5*S+2*T)+MHb2**3*(-MHa2**2-3*MHa2*S+10*S**2+8*S*T+T**2)-MHb2*(MHa2-S)*(5*MHa2**2*S+MHa2*(-10*S**2-8*S*T+T**2)+S*(5*S**2+8*S*T+3*T**2))-MHb2**2*(MHa2**3+2*MHa2**2*(S-2*T)+MHa2*(-13*S**2-4*S*T+T**2)+S*(10*S**2+12*S*T+3*T**2)))*self.C0(MHb2,MHa2,S,MT2,MT2,MT2)-(MHb2**4*MHa2-(MHa2-S)**3*T**2-MHb2**3*(MHa2**2+MHa2*S+T**2)+MHb2*(MHa2-S)*(MHa2**3-2*MHa2**2*S+3*S*T**2+MHa2*(S**2+T**2))+MHb2**2*(-MHa2**3+3*S*T**2+MHa2*(S**2-4*S*T+T**2)))*self.C0(MHa2,MHb2,S,MT2,MT2,MT2)-(MHb2**2+(MHa2-S)**2-2*MHb2*(MHa2+S))*(MHb2-S-T)*(MHb2**2+3*MHb2*MHa2-2*MHb2*(S+T)+(-MHa2+S+T)**2)*self.C0(MHb2+MHa2-S-T,MHa2,0,MT2,MT2,MT2)+(MHb2**2+(MHa2-S)**2-2*MHb2*(MHa2+S))*(MHb2-T)*(MHb2*MHa2+T**2)*self.C0(T,MHb2,0,MT2,MT2,MT2)+(MHb2**2+(MHa2-S)**2-2*MHb2*(MHa2+S))*(MHb2**3*S+MHb2**2*(-2*MHa2*MT2+4*MHa2*S-3*S**2+2*MT2*T-3*S*T)+MHb2*(-2*MHa2**2*(MT2-2*S)+3*S**3+6*S**2*T-2*MT2*T**2-7*MHa2*S*(S+T)+2*MHa2*MT2*(S+2*T)+S*T*(-4*MT2+3*T))+(MHa2-S-T)*(MHa2**2*S-2*MHa2*(S**2-MT2*T+S*T)+S*(S**2+2*S*T+T*(-2*MT2+T))))*self.D0(0,MHb2,MHa2,0,MHb2+MHa2-S-T,S,MT2,MT2,MT2,MT2)+(MHb2**2+(MHa2-S)**2-2*MHb2*(MHa2+S))*(2*MHb2**2*MT2*(-MHa2+T)+MHb2*(-2*MHa2**2*MT2+MHa2*S*T-2*MT2*T*(2*S+T)+2*MHa2*MT2*(S+2*T))+T*(2*MHa2**2*MT2-2*MHa2*MT2*(2*S+T)+S*(T**2+2*MT2*(S+T))))*self.D0(0,MHa2,MHb2,0,T,S,MT2,MT2,MT2,MT2)-2*MT2*(MHb2+MHa2-S)*(MHb2**2+(MHa2-S)**2-2*MHb2*(MHa2+S))*(MHb2*(MHa2-T)+T*(-MHa2+S+T))*self.D0(MHb2,0,MHa2,0,MHb2+MHa2-S-T,T,MT2,MT2,MT2,MT2)))/(S*(MHb2**2+(MHa2-S)**2-2*MHb2*(MHa2+S))*(MHb2*(MHa2-T)+T*(-MHa2+S+T)))

    @lru_cache(maxsize=cache_size)
    def GBoxHA(self, MT2, MHa2, MHb2, S, T):
        return ((-((MHa2-S-T)*(MHb2**2+(-MHa2+S+T)**2+MHb2*(MHa2-2*(S+T)))*self.C0(0,MHb2,MHb2+MHa2-S-T,MT2,MT2,MT2))+(MHa2-T)*(MHb2*MHa2-T**2)*self.C0(0,MHa2,T,MT2,MT2,MT2)-(MHb2+MHa2-S)*S*(MHb2+MHa2-S-2*T)*self.C0(0,S,0,MT2,MT2,MT2)+(MHb2**3+(MHa2-S)*(-MHa2+S+T)**2-MHb2**2*(3*S+2*T)+MHb2*(-3*MHa2*S+3*S**2+4*S*T+T**2))*self.C0(MHb2,MHa2,S,MT2,MT2,MT2)-(MHb2**2*MHa2+(MHa2-S)*T**2+MHb2*(MHa2**2+T**2-MHa2*(S+4*T)))*self.C0(MHa2,MHb2,S,MT2,MT2,MT2)-(MHb2-S-T)*(MHb2**2+(-MHa2+S+T)**2+MHb2*(MHa2-2*(S+T)))*self.C0(MHb2+MHa2-S-T,MHa2,0,MT2,MT2,MT2)+(MHb2-T)*(MHb2*MHa2-T**2)*self.C0(T,MHb2,0,MT2,MT2,MT2)+(MHb2**3*S+MHb2**2*(-2*MHa2*MT2+2*MHa2*S-3*S**2+2*MT2*T-3*S*T)+MHb2*(-2*MHa2**2*(MT2-S)+3*S**3+6*S**2*T-6*MT2*T**2-5*MHa2*S*(S+T)+S*T*(-4*MT2+3*T)+2*MHa2*MT2*(S+4*T))+(MHa2-S-T)*(MHa2**2*S+S**3+2*S**2*T-4*MT2*T**2+S*T*(-2*MT2+T)-2*MHa2*(S**2-MT2*T+S*T)))*self.D0(0,MHb2,MHa2,0,MHb2+MHa2-S-T,S,MT2,MT2,MT2,MT2)+(2*MHb2**2*MT2*(-MHa2+T)+MHb2*(-2*MHa2**2*MT2+MHa2*S*T-2*MT2*T*(2*S+3*T)+2*MHa2*MT2*(S+4*T))+T*(2*MHa2**2*MT2-S*T**2-2*MHa2*MT2*(2*S+3*T)+2*MT2*(S**2+3*S*T+2*T**2)))*self.D0(0,MHa2,MHb2,0,T,S,MT2,MT2,MT2,MT2)-2*MT2*(MHb2+MHa2-S-2*T)*(MHb2*(MHa2-T)+T*(-MHa2+S+T))*self.D0(MHb2,0,MHa2,0,MHb2+MHa2-S-T,T,MT2,MT2,MT2,MT2)))/(S*(MHb2*(MHa2-T)+T*(-MHa2+S+T)))
