import setuptools

setuptools.setup(
    scripts = ['bin/anyBSM', 'bin/anyBSM_import'],
    packages = ['anyBSM']
)
