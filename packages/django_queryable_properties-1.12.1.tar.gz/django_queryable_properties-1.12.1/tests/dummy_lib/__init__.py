# -*- coding: utf-8 -*-
"""A dummy library that is not an installed app. Used for tests with abstract models from non-app modules."""
