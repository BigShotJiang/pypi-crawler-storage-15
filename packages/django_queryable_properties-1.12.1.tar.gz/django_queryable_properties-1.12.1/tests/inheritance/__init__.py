# -*- coding: utf-8 -*-
"""An app containing some models portraying various inheritance scenarios for testing purposes."""
