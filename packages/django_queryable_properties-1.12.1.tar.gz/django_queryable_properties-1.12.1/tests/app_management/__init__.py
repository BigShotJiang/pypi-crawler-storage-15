# -*- coding: utf-8 -*-
"""An app containing some simplified software application management models for testing purposes."""
