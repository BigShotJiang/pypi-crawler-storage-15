# Default variables used for the ntlm_context
username = 'username'
domain = 'domain'
password = 'password'
