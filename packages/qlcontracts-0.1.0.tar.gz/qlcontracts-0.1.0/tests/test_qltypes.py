import sys
from decimal import Decimal
from pathlib import Path

import pytest

# Ensure src is importable without installation
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.append(str(SRC))

from qlcontracts import (  # noqa: E402
    events,
    identifiers,
    market_data,
    money,
    risk,
    time as qltime,
)


def test_identifier_newtypes_behave_like_strings():
    inst = identifiers.InstrumentId("BTC-USDT")
    assert isinstance(inst, str)
    assert inst == "BTC-USDT"


def test_book_level_and_snapshots_validation():
    level = market_data.BookLevel(price=money.Price(Decimal("100")), quantity=money.Quantity(Decimal("1")))
    assert level.price == Decimal("100")

    snap = market_data.BookSnapshot(
        instrument_id=identifiers.InstrumentId("BTC"),
        ts=qltime.now_ms(),
        bids=[level],
        asks=[],
    )
    assert snap.bids[0].quantity == Decimal("1")

    with pytest.raises(ValueError):
        market_data.BookLevel(price=money.Price(Decimal("0")), quantity=money.Quantity(Decimal("1")))
    with pytest.raises(ValueError):
        market_data.BookSnapshot(
            instrument_id=identifiers.InstrumentId("BTC"),
            ts=qltime.Timestamp(-1),
            bids=[],
            asks=[],
        )
    with pytest.raises(ValueError):
        market_data.BookSnapshot(
            instrument_id=identifiers.InstrumentId("BTC"),
            ts=qltime.now_ms(),
            bids=[],
            asks=[],
            ingest_ts=qltime.Timestamp(-5),
        )


def test_book_delta_and_tick_validation():
    level = market_data.BookLevel(price=money.Price(Decimal("100")), quantity=money.Quantity(Decimal("1")))
    delta = market_data.BookDelta(
        instrument_id=identifiers.InstrumentId("BTC"),
        ts=qltime.now_ms(),
        side=market_data.QuoteSide.BID,
        action=market_data.BookAction.ADD,
        level=level,
    )
    assert delta.level.price == Decimal("100")

    with pytest.raises(ValueError):
        market_data.BookDelta(
            instrument_id=identifiers.InstrumentId("BTC"),
            ts=qltime.Timestamp(-1),
            side=market_data.QuoteSide.BID,
            action=market_data.BookAction.ADD,
            level=level,
        )
    with pytest.raises(ValueError):
        market_data.Tick(
            instrument_id=identifiers.InstrumentId("BTC"),
            ts=qltime.Timestamp(-1),
            price=money.Price(Decimal("100")),
            size=money.Quantity(Decimal("1")),
        )
    with pytest.raises(ValueError):
        market_data.Tick(
            instrument_id=identifiers.InstrumentId("BTC"),
            ts=qltime.now_ms(),
            price=money.Price(Decimal("0")),
            size=money.Quantity(Decimal("1")),
        )
    with pytest.raises(ValueError):
        market_data.Tick(
            instrument_id=identifiers.InstrumentId("BTC"),
            ts=qltime.now_ms(),
            price=money.Price(Decimal("100")),
            size=money.Quantity(Decimal("0")),
            ingest_ts=qltime.Timestamp(-1),
        )


def test_bar_validation_rules():
    bar = market_data.Bar(
        instrument_id=identifiers.InstrumentId("BTC"),
        ts=qltime.now_ms(),
        duration=60000,
        open=money.Price(Decimal("100")),
        high=money.Price(Decimal("110")),
        low=money.Price(Decimal("90")),
        close=money.Price(Decimal("105")),
        volume=money.Quantity(Decimal("10")),
        notional=money.Notional(Decimal("1000")),
    )
    assert bar.duration == 60000

    with pytest.raises(ValueError):
        market_data.Bar(
            instrument_id=identifiers.InstrumentId("BTC"),
            ts=qltime.Timestamp(-1),
            duration=60000,
            open=money.Price(Decimal("100")),
            high=money.Price(Decimal("110")),
            low=money.Price(Decimal("90")),
            close=money.Price(Decimal("105")),
            volume=money.Quantity(Decimal("10")),
        )
    with pytest.raises(ValueError):
        market_data.Bar(
            instrument_id=identifiers.InstrumentId("BTC"),
            ts=qltime.now_ms(),
            duration=0,
            open=money.Price(Decimal("100")),
            high=money.Price(Decimal("110")),
            low=money.Price(Decimal("90")),
            close=money.Price(Decimal("105")),
            volume=money.Quantity(Decimal("10")),
        )
    with pytest.raises(ValueError):
        market_data.Bar(
            instrument_id=identifiers.InstrumentId("BTC"),
            ts=qltime.now_ms(),
            duration=60000,
            open=money.Price(Decimal("100")),
            high=money.Price(Decimal("110")),
            low=money.Price(Decimal("90")),
            close=money.Price(Decimal("105")),
            volume=money.Quantity(Decimal("-1")),
        )
    with pytest.raises(ValueError):
        market_data.Bar(
            instrument_id=identifiers.InstrumentId("BTC"),
            ts=qltime.now_ms(),
            duration=60000,
            open=money.Price(Decimal("100")),
            high=money.Price(Decimal("110")),
            low=money.Price(Decimal("90")),
            close=money.Price(Decimal("105")),
            volume=money.Quantity(Decimal("10")),
            notional=money.Notional(Decimal("-1")),
        )
    with pytest.raises(ValueError):
        market_data.Bar(
            instrument_id=identifiers.InstrumentId("BTC"),
            ts=qltime.now_ms(),
            duration=60000,
            open=money.Price(Decimal("100")),
            high=money.Price(Decimal("110")),
            low=money.Price(Decimal("90")),
            close=money.Price(Decimal("105")),
            volume=money.Quantity(Decimal("10")),
            ingest_ts=qltime.Timestamp(-1),
        )


def test_order_request_validation_rules():
    valid_limit = events.OrderRequest(
        instrument_id=identifiers.InstrumentId("BTC-USDT"),
        side=events.OrderSide.BUY,
        type=events.OrderType.LIMIT,
        quantity=money.Quantity(Decimal("1")),
        price=money.Price(Decimal("20000")),
        client_order_id=identifiers.ClientOrderId("cid-123"),
    )
    assert valid_limit.price == Decimal("20000")

    trailing = events.OrderRequest(
        instrument_id=identifiers.InstrumentId("BTC-USDT"),
        side=events.OrderSide.SELL,
        type=events.OrderType.TRAILING_STOP,
        quantity=money.Quantity(Decimal("0.5")),
        stop_price=money.Price(Decimal("19900")),
        client_order_id=identifiers.ClientOrderId("cid-124"),
    )
    assert trailing.stop_price == Decimal("19900")

    with pytest.raises(ValueError):
        events.OrderRequest(
            instrument_id=identifiers.InstrumentId("BTC-USDT"),
            side=events.OrderSide.BUY,
            type=events.OrderType.LIMIT,
            quantity=money.Quantity(Decimal("0")),
            price=money.Price(Decimal("20000")),
            client_order_id=identifiers.ClientOrderId("cid-125"),
        )
    with pytest.raises(ValueError):
        events.OrderRequest(
            instrument_id=identifiers.InstrumentId("BTC-USDT"),
            side=events.OrderSide.BUY,
            type=events.OrderType.LIMIT,
            quantity=money.Quantity(Decimal("1")),
            client_order_id=identifiers.ClientOrderId("cid-126"),
        )
    with pytest.raises(ValueError):
        events.OrderRequest(
            instrument_id=identifiers.InstrumentId("BTC-USDT"),
            side=events.OrderSide.BUY,
            type=events.OrderType.STOP_LIMIT,
            quantity=money.Quantity(Decimal("1")),
            stop_price=money.Price(Decimal("19900")),
            client_order_id=identifiers.ClientOrderId("cid-127"),
        )
    with pytest.raises(ValueError):
        events.OrderRequest(
            instrument_id=identifiers.InstrumentId("BTC-USDT"),
            side=events.OrderSide.SELL,
            type=events.OrderType.STOP,
            quantity=money.Quantity(Decimal("1")),
            stop_price=None,
            client_order_id=identifiers.ClientOrderId("cid-128"),
        )
    with pytest.raises(ValueError):
        events.OrderRequest(
            instrument_id=identifiers.InstrumentId("BTC-USDT"),
            side=events.OrderSide.SELL,
            type=events.OrderType.STOP,
            quantity=money.Quantity(Decimal("1")),
            stop_price=money.Price(Decimal("-1")),
            client_order_id=identifiers.ClientOrderId("cid-129"),
        )
    with pytest.raises(ValueError):
        events.OrderRequest(
            instrument_id=identifiers.InstrumentId("BTC-USDT"),
            side=events.OrderSide.BUY,
            type=events.OrderType.LIMIT,
            quantity=money.Quantity(Decimal("1")),
            price=money.Price(Decimal("-1")),
            client_order_id=identifiers.ClientOrderId("cid-130"),
        )
    with pytest.raises(ValueError):
        events.OrderRequest(
            instrument_id=identifiers.InstrumentId("BTC-USDT"),
            side=events.OrderSide.BUY,
            type=events.OrderType.LIMIT,
            quantity=money.Quantity(Decimal("1")),
            price=money.Price(Decimal("20000")),
            client_order_id=identifiers.ClientOrderId(""),
        )
    with pytest.raises(ValueError):
        events.OrderRequest(
            instrument_id=identifiers.InstrumentId("BTC-USDT"),
            side=events.OrderSide.BUY,
            type=events.OrderType.MARKET,
            quantity=money.Quantity(Decimal("1")),
            client_order_id=identifiers.ClientOrderId("cid-131"),
            ingest_ts=qltime.Timestamp(-1),
        )


def test_order_update_validation_rules():
    update = events.OrderUpdate(
        order_id=None,
        client_order_id=identifiers.ClientOrderId("cid-200"),
        instrument_id=identifiers.InstrumentId("BTC-USDT"),
        status=events.OrderStatus.NEW,
        filled_quantity=money.Quantity(Decimal("0")),
        remaining_quantity=money.Quantity(Decimal("1")),
        average_price=None,
        ts=qltime.now_ms(),
    )
    assert update.remaining_quantity == Decimal("1")

    with pytest.raises(ValueError):
        events.OrderUpdate(
            order_id=None,
            client_order_id=identifiers.ClientOrderId("cid-201"),
            instrument_id=identifiers.InstrumentId("BTC-USDT"),
            status=events.OrderStatus.NEW,
            filled_quantity=money.Quantity(Decimal("-1")),
            remaining_quantity=money.Quantity(Decimal("1")),
            average_price=None,
            ts=qltime.now_ms(),
        )
    with pytest.raises(ValueError):
        events.OrderUpdate(
            order_id=None,
            client_order_id=identifiers.ClientOrderId("cid-202"),
            instrument_id=identifiers.InstrumentId("BTC-USDT"),
            status=events.OrderStatus.NEW,
            filled_quantity=money.Quantity(Decimal("0")),
            remaining_quantity=money.Quantity(Decimal("-1")),
            average_price=None,
            ts=qltime.now_ms(),
        )
    with pytest.raises(ValueError):
        events.OrderUpdate(
            order_id=None,
            client_order_id=identifiers.ClientOrderId("cid-203"),
            instrument_id=identifiers.InstrumentId("BTC-USDT"),
            status=events.OrderStatus.NEW,
            filled_quantity=money.Quantity(Decimal("0")),
            remaining_quantity=money.Quantity(Decimal("1")),
            average_price=money.Price(Decimal("-1")),
            ts=qltime.now_ms(),
        )
    with pytest.raises(ValueError):
        events.OrderUpdate(
            order_id=None,
            client_order_id=identifiers.ClientOrderId("cid-204"),
            instrument_id=identifiers.InstrumentId("BTC-USDT"),
            status=events.OrderStatus.NEW,
            filled_quantity=money.Quantity(Decimal("0")),
            remaining_quantity=money.Quantity(Decimal("1")),
            average_price=None,
            ts=qltime.Timestamp(-1),
        )
    with pytest.raises(ValueError):
        events.OrderUpdate(
            order_id=None,
            client_order_id=identifiers.ClientOrderId("cid-205"),
            instrument_id=identifiers.InstrumentId("BTC-USDT"),
            status=events.OrderStatus.NEW,
            filled_quantity=money.Quantity(Decimal("0")),
            remaining_quantity=money.Quantity(Decimal("1")),
            average_price=None,
            ts=qltime.now_ms(),
            ingest_ts=qltime.Timestamp(-1),
        )


def test_fill_validation_and_liquidity_defaults():
    taker_fill = events.Fill(
        fill_id="f1",
        instrument_id=identifiers.InstrumentId("BTC-USDT"),
        side=events.OrderSide.BUY,
        price=money.Price(Decimal("20000")),
        quantity=money.Quantity(Decimal("0.1")),
        ts=qltime.now_ms(),
        order_id=None,
        client_order_id=None,
    )
    assert taker_fill.liquidity == events.LiquiditySide.TAKER

    maker_fill = events.Fill(
        fill_id="f2",
        instrument_id=identifiers.InstrumentId("BTC-USDT"),
        side=events.OrderSide.SELL,
        price=money.Price(Decimal("20000")),
        quantity=money.Quantity(Decimal("0.2")),
        ts=qltime.now_ms(),
        order_id=None,
        client_order_id=None,
        is_maker=True,
    )
    assert maker_fill.liquidity == events.LiquiditySide.MAKER

    explicit_liquidity = events.Fill(
        fill_id="f3",
        instrument_id=identifiers.InstrumentId("BTC-USDT"),
        side=events.OrderSide.SELL,
        price=money.Price(Decimal("20000")),
        quantity=money.Quantity(Decimal("0.2")),
        ts=qltime.now_ms(),
        order_id=None,
        client_order_id=None,
        is_maker=True,
        liquidity=events.LiquiditySide.TAKER,
    )
    assert explicit_liquidity.liquidity == events.LiquiditySide.TAKER

    with pytest.raises(ValueError):
        events.Fill(
            fill_id="f4",
            instrument_id=identifiers.InstrumentId("BTC-USDT"),
            side=events.OrderSide.BUY,
            price=money.Price(Decimal("0")),
            quantity=money.Quantity(Decimal("0.1")),
            ts=qltime.now_ms(),
            order_id=None,
            client_order_id=None,
        )
    with pytest.raises(ValueError):
        events.Fill(
            fill_id="f5",
            instrument_id=identifiers.InstrumentId("BTC-USDT"),
            side=events.OrderSide.BUY,
            price=money.Price(Decimal("20000")),
            quantity=money.Quantity(Decimal("-0.1")),
            ts=qltime.now_ms(),
            order_id=None,
            client_order_id=None,
        )
    with pytest.raises(ValueError):
        events.Fill(
            fill_id="f6",
            instrument_id=identifiers.InstrumentId("BTC-USDT"),
            side=events.OrderSide.BUY,
            price=money.Price(Decimal("20000")),
            quantity=money.Quantity(Decimal("0.1")),
            ts=qltime.Timestamp(-1),
            order_id=None,
            client_order_id=None,
        )
    with pytest.raises(ValueError):
        events.Fill(
            fill_id="f7",
            instrument_id=identifiers.InstrumentId("BTC-USDT"),
            side=events.OrderSide.BUY,
            price=money.Price(Decimal("20000")),
            quantity=money.Quantity(Decimal("0.1")),
            ts=qltime.now_ms(),
            order_id=None,
            client_order_id=None,
            ingest_ts=qltime.Timestamp(-1),
        )
    with pytest.raises(ValueError):
        events.Fill(
            fill_id="f8",
            instrument_id=identifiers.InstrumentId("BTC-USDT"),
            side=events.OrderSide.BUY,
            price=money.Price(Decimal("20000")),
            quantity=money.Quantity(Decimal("0.1")),
            ts=qltime.now_ms(),
            order_id=None,
            client_order_id=None,
            fee=money.Fee(Decimal("-0.01")),
        )


def test_risk_events_timestamp_validation():
    violation = risk.RiskViolation(
        account_id=identifiers.AccountId("acc1"),
        strategy_id=None,
        rule_name="max_drawdown",
        violation_value="12%",
        threshold_value="10%",
        ts=qltime.now_ms(),
    )
    assert violation.rule_name == "max_drawdown"

    circuit = risk.CircuitBreakerEvent(
        is_triggered=True,
        scope="GLOBAL",
        reason="panic",
        ts=qltime.now_ms(),
        resume_ts=qltime.now_ms() + 1000,
    )
    assert circuit.scope == "GLOBAL"

    with pytest.raises(ValueError):
        risk.RiskViolation(
            account_id=identifiers.AccountId("acc1"),
            strategy_id=None,
            rule_name="max_drawdown",
            violation_value="12%",
            threshold_value="10%",
            ts=qltime.Timestamp(-1),
        )
    with pytest.raises(ValueError):
        risk.RiskViolation(
            account_id=identifiers.AccountId("acc1"),
            strategy_id=None,
            rule_name="max_drawdown",
            violation_value="12%",
            threshold_value="10%",
            ts=qltime.now_ms(),
            ingest_ts=qltime.Timestamp(-1),
        )
    with pytest.raises(ValueError):
        risk.CircuitBreakerEvent(
            is_triggered=True,
            scope="GLOBAL",
            reason="panic",
            ts=qltime.Timestamp(-1),
        )
    with pytest.raises(ValueError):
        risk.CircuitBreakerEvent(
            is_triggered=True,
            scope="GLOBAL",
            reason="panic",
            ts=qltime.now_ms(),
            resume_ts=qltime.Timestamp(-1),
        )
