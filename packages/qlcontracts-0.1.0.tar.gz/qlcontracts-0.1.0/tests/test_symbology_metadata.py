import sys
from pathlib import Path

import pytest

# Ensure src is importable without installation
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.append(str(SRC))

from qlcontracts import (  # noqa: E402
    InstrumentId,
    InstrumentType,
    Venue,
    metadata,
    symbology,
    time as qltime,
)


def test_make_and_parse_instrument_id_with_and_without_type():
    inst = symbology.make_instrument_id("binance", "btc-usdt", InstrumentType.PERP)
    assert inst == InstrumentId("BINANCE:btc-usdt:PERP")

    parsed = symbology.parse_instrument_id(inst)
    assert parsed.venue == Venue("BINANCE")
    assert parsed.symbol == "btc-usdt"
    assert parsed.instrument_type == InstrumentType.PERP

    # Spot without type keeps symbol, uppercases venue
    spot = symbology.make_instrument_id("bybit", "ETH-USDT")
    parsed_spot = symbology.parse_instrument_id(spot)
    assert parsed_spot.instrument_type is None
    assert symbology.normalize_instrument_id(spot) == InstrumentId("BYBIT:ETH-USDT")

    # Split helper mirrors parse
    venue, symbol = symbology.split_venue_symbol(inst)
    assert venue == Venue("BINANCE")
    assert symbol == "btc-usdt"


def test_parse_instrument_id_errors():
    with pytest.raises(ValueError):
        symbology.parse_instrument_id(InstrumentId("BTCUSDT"))  # missing venue delimiter

    with pytest.raises(ValueError):
        symbology.parse_instrument_id(InstrumentId("BINANCE::PERP"))  # empty symbol

    with pytest.raises(ValueError):
        symbology.parse_instrument_id(InstrumentId("BINANCE:BTC-USDT:UNKNOWN"))  # bad type


def test_event_meta_validation_and_defaults():
    meta = metadata.EventMeta(
        event_id="evt-1",
        correlation_id="corr-1",
        source="unittests",
        ts=qltime.now_ms(),
        causation_id="cause-1",
        sequence=0,
    )
    assert meta.sequence == 0
    assert meta.causation_id == "cause-1"

    generated = metadata.make_event_meta(
        event_id="evt-2",
        correlation_id="corr-2",
        source="unittests",
    )
    assert generated.event_id == "evt-2"
    assert generated.ts >= 0

    with pytest.raises(ValueError):
        metadata.EventMeta(
            event_id="",
            correlation_id="corr",
            source="unittests",
            ts=qltime.now_ms(),
        )
    with pytest.raises(ValueError):
        metadata.EventMeta(
            event_id="evt",
            correlation_id="",
            source="unittests",
            ts=qltime.now_ms(),
        )
    with pytest.raises(ValueError):
        metadata.EventMeta(
            event_id="evt",
            correlation_id="corr",
            source="",
            ts=qltime.now_ms(),
        )
    with pytest.raises(ValueError):
        metadata.EventMeta(
            event_id="evt",
            correlation_id="corr",
            source="unittests",
            ts=qltime.Timestamp(-1),
        )
    with pytest.raises(ValueError):
        metadata.EventMeta(
            event_id="evt",
            correlation_id="corr",
            source="unittests",
            ts=qltime.now_ms(),
            ingest_ts=qltime.Timestamp(-5),
        )
    with pytest.raises(ValueError):
        metadata.EventMeta(
            event_id="evt",
            correlation_id="corr",
            source="unittests",
            ts=qltime.now_ms(),
            sequence=-1,
        )
    with pytest.raises(ValueError):
        metadata.EventMeta(
            event_id="evt",
            correlation_id="corr",
            source="unittests",
            ts=qltime.now_ms(),
            causation_id="",
        )
