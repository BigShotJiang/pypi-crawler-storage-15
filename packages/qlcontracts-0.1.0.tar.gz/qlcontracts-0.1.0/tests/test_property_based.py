import sys
from decimal import Decimal
from pathlib import Path

import pytest
from hypothesis import given, strategies as st

# Ensure src is importable without installation
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.append(str(SRC))

from qlcontracts import (  # noqa: E402
    ClientOrderId,
    InstrumentId,
    InstrumentType,
    Venue,
    events,
    money,
    symbology,
    time as qltime,
)


alpha_venue = st.text(alphabet="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz", min_size=1, max_size=8)
alpha_symbol = st.text(
    alphabet="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_",
    min_size=1,
    max_size=16,
)
instrument_type_optional = st.one_of(st.none(), st.sampled_from(list(InstrumentType)))

positive_decimal = st.decimals(
    min_value=Decimal("0.01"),
    max_value=Decimal("10000"),
    allow_nan=False,
    allow_infinity=False,
    places=3,
)


@given(venue=alpha_venue, symbol=alpha_symbol, itype=instrument_type_optional)
def test_symbology_round_trip(venue: str, symbol: str, itype: InstrumentType | None) -> None:
    inst_id = symbology.make_instrument_id(venue, symbol, itype)
    parsed = symbology.parse_instrument_id(inst_id)

    assert parsed.venue == Venue(venue.upper())
    assert parsed.symbol == symbol.strip()
    assert parsed.instrument_type == itype

    normalized = symbology.normalize_instrument_id(inst_id)
    assert normalized == symbology.make_instrument_id(parsed.venue, parsed.symbol, itype)
    assert symbology.parse_instrument_id(normalized) == parsed


@given(ts=st.integers(min_value=0, max_value=10**12))
def test_time_round_trip_stability(ts: int) -> None:
    dt = qltime.to_datetime(qltime.Timestamp(ts))
    back = qltime.to_timestamp(dt)
    assert abs(back - qltime.Timestamp(ts)) <= 1  # allow float->int rounding tolerance


@given(ts=st.integers(max_value=-1))
def test_time_negative_timestamps_rejected(ts: int) -> None:
    with pytest.raises(ValueError):
        qltime.to_datetime(qltime.Timestamp(ts))


@given(value=positive_decimal, tick=positive_decimal)
def test_round_to_tick_alignment(value: Decimal, tick: Decimal) -> None:
    rounded = money.round_to_tick(value, tick)
    assert rounded % tick == 0
    assert abs(rounded - value) <= tick / 2


@given(value=positive_decimal, precision=positive_decimal)
def test_quantize_value_alignment(value: Decimal, precision: Decimal) -> None:
    quantized = money.quantize_value(value, precision)
    assert quantized.as_tuple().exponent == precision.as_tuple().exponent


order_type_strategy = st.sampled_from(list(events.OrderType))
side_strategy = st.sampled_from(list(events.OrderSide))


@given(
    otype=order_type_strategy,
    side=side_strategy,
    qty=positive_decimal,
    price=positive_decimal,
    stop_price=positive_decimal,
)
def test_order_request_generation(otype: events.OrderType, side: events.OrderSide, qty: Decimal, price: Decimal, stop_price: Decimal) -> None:
    kwargs = dict(
        instrument_id=InstrumentId("BINANCE:BTC-USDT"),
        side=side,
        type=otype,
        quantity=money.Quantity(qty),
        client_order_id=ClientOrderId("cid-hypo"),
    )

    if otype in {events.OrderType.LIMIT, events.OrderType.STOP_LIMIT}:
        kwargs["price"] = money.Price(price)
    if otype in {events.OrderType.STOP, events.OrderType.STOP_LIMIT, events.OrderType.TRAILING_STOP}:
        kwargs["stop_price"] = money.Price(stop_price)

    req = events.OrderRequest(**kwargs)  # type: ignore[arg-type]
    assert req.quantity > 0

    if otype in {events.OrderType.LIMIT, events.OrderType.STOP_LIMIT}:
        assert req.price == price
    else:
        assert req.price is None

    if otype in {events.OrderType.STOP, events.OrderType.STOP_LIMIT, events.OrderType.TRAILING_STOP}:
        assert req.stop_price == stop_price
    else:
        assert req.stop_price is None
