from __future__ import annotations

from dataclasses import dataclass, asdict, field
from typing import Generic, TypeVar, Optional, Union, Any, Dict

T = TypeVar("T")

# Error/result shapes

@dataclass
class ErrorBase:
    """
    Lightweight, serializable error shape for cross-library boundaries.

    - message: human-readable summary
    - code: stable machine-readable identifier (optional)
    - details: structured context safe to log/serialize (optional)
    """
    message: str
    code: Optional[str] = None
    details: Optional[Dict[str, Any]] = field(default=None)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

@dataclass
class RiskRejection(ErrorBase):
    """Order rejected by risk checks."""
    pass

@dataclass
class ExecutionError(ErrorBase):
    """Error during order execution."""
    pass

@dataclass
class DataError(ErrorBase):
    """Error related to data feed or processing."""
    pass

@dataclass
class DomainError(ErrorBase):
    """Generic error for domain-specific logic failures."""
    pass

AnyError = Union[RiskRejection, ExecutionError, DataError, DomainError, ErrorBase]

@dataclass
class Result(Generic[T]):
    """
    A minimal Result type to avoid raising exceptions for expected business failures.

    Invariants:
    - Either value is not None and error is None (Ok)
    - Or error is not None and value is None (Err)
    """
    value: Optional[T] = None
    error: Optional[AnyError] = None

    def __post_init__(self) -> None:
        if self.value is not None and self.error is not None:
            raise ValueError("Result cannot have both value and error")
        if self.value is None and self.error is None:
            # Allow empty init? Prefer strictness to prevent silent bugs.
            # If you want permissive behavior, remove this check.
            raise ValueError("Result must have either value or error")

    @property
    def is_ok(self) -> bool:
        return self.error is None

    @property
    def is_err(self) -> bool:
        return self.error is not None

    def unwrap(self) -> T:
        """
        Returns the value or raises a ValueError with the error payload.
        Intended for test code or truly exceptional paths.
        """
        if self.error is not None:
            raise ValueError(f"Result is error: {self.error}")
        return self.value  # type: ignore

    def unwrap_or(self, default: T) -> T:
        return self.value if self.error is None else default

    def to_dict(self) -> Dict[str, Any]:
        """
        Serialization-friendly view.
        """
        return {
            "ok": self.is_ok,
            "value": self.value,
            "error": self.error.to_dict() if self.error else None,
        }

    @classmethod
    def Ok(cls, value: T) -> "Result[T]":
        return cls(value=value, error=None)

    @classmethod
    def Err(cls, error: AnyError) -> "Result[T]":
        return cls(value=None, error=error)
