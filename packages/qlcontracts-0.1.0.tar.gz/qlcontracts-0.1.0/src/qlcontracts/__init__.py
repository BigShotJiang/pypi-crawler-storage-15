

__version__ = "0.2.1"

# Re-exports for convenience

from .identifiers import (  # noqa: F401
    InstrumentId, Venue, AccountId, SubAccountId,
    OrderId, ClientOrderId, TradeId,
    StrategyId, PortfolioId, SessionId, RunId,
)

from .time import (  # noqa: F401
    Timestamp, TimeRange, now_ms, to_datetime, to_timestamp,
)

from .money import (  # noqa: F401
    Price, Quantity, Notional, Rate, Fee,
    InstrumentPrecision, round_to_tick, quantize_value,
)

from .taxonomy import (  # noqa: F401
    AssetType, InstrumentType, ContractSpec,
)

from .instruments import InstrumentMeta  # noqa: F401

from .market_data import (  # noqa: F401
    Tick, Bar, BookLevel, BookSnapshot, BookDelta,
)

from .events import (  # noqa: F401
    OrderSide, OrderType, TimeInForce, OrderStatus,
    PositionSide, LiquiditySide,
    OrderRequest, OrderUpdate, Fill,
)

from .risk import (  # noqa: F401
    RiskLimits, RiskCheckResult, RiskViolation, CircuitBreakerEvent,
)

from .errors import (  # noqa: F401
    ErrorBase, RiskRejection, ExecutionError, DataError, DomainError, Result,
)

from .serialization import (  # noqa: F401
    to_json, from_json, SCHEMA_VERSION,
)

from .validation import (  # noqa: F401
    ensure,
    ensure_type,
    ensure_decimal,
    ensure_required_decimal,
    ensure_positive_decimal,
    ensure_non_negative_decimal,
    ensure_non_empty_str,
    ensure_non_negative_ts,
    ensure_optional_non_negative_ts,
    coerce_if,
)

from .metadata import EventMeta, make_event_meta  # noqa: F401
from .symbology import (  # noqa: F401
    ParsedInstrumentId,
    make_instrument_id,
    parse_instrument_id,
    split_venue_symbol,
    normalize_instrument_id,
)
