from __future__ import annotations

import dataclasses
import json
from decimal import Decimal
from enum import Enum
from typing import Any

SCHEMA_VERSION = "qlcontracts/v1"

class QLJsonEncoder(json.JSONEncoder):
    """JSON encoder for Decimal, Enum, and dataclasses."""
    def default(self, o: Any) -> Any:
        if dataclasses.is_dataclass(o):
            return dataclasses.asdict(o)
        if isinstance(o, Decimal):
            return str(o)
        if isinstance(o, Enum):
            return o.value
        return super().default(o)

def to_dict(obj: Any) -> Any:
    if dataclasses.is_dataclass(obj):
        return dataclasses.asdict(obj)
    return obj

def to_json(obj: Any, envelope: bool = True, **kwargs) -> str:
    payload = to_dict(obj)
    body = {"schema": SCHEMA_VERSION, "payload": payload} if envelope else payload
    return json.dumps(body, cls=QLJsonEncoder, **kwargs)

def from_json(json_str: str, envelope: bool = True, parse_decimals: bool = False, **kwargs) -> Any:
    loader_kwargs = dict(kwargs)
    if parse_decimals:
        loader_kwargs.setdefault("parse_float", Decimal)

    data = json.loads(json_str, **loader_kwargs)

    if not envelope:
        return data

    if not isinstance(data, dict) or "schema" not in data or "payload" not in data:
        raise ValueError("Expected envelope with schema and payload")

    if data["schema"] != SCHEMA_VERSION:
        raise ValueError(f"Unsupported schema version: {data['schema']}")

    return data["payload"]
