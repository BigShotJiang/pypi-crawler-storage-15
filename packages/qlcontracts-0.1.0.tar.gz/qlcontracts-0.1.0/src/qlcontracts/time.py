from __future__ import annotations

import time as _time
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import NewType

from .validation import ensure_non_negative_ts, ensure

# Timestamp: UTC epoch milliseconds
Timestamp = NewType("Timestamp", int)

def now_ms() -> Timestamp:
    """Returns the current UTC time in milliseconds."""
    return Timestamp(int(_time.time() * 1000))

def to_datetime(ts: Timestamp) -> datetime:
    """Converts a timestamp to a timezone-aware UTC datetime."""
    ensure_non_negative_ts(ts, "ts")
    return datetime.fromtimestamp(ts / 1000.0, tz=timezone.utc)

def to_timestamp(dt: datetime) -> Timestamp:
    """Converts a datetime to a Timestamp (UTC epoch ms)."""
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    else:
        dt = dt.astimezone(timezone.utc)
    return Timestamp(int(dt.timestamp() * 1000))

@dataclass(frozen=True)
class TimeRange:
    """A time range [start, end)."""
    start: Timestamp
    end: Timestamp

    def __post_init__(self) -> None:
        ensure_non_negative_ts(self.start, "start")
        ensure_non_negative_ts(self.end, "end")
        ensure(self.end >= self.start, "end must be >= start")
