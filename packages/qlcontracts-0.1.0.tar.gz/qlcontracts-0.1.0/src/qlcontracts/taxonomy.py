from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Optional

from .money import Quantity
from .time import Timestamp
from .validation import ensure_non_empty_str

# Asset/instrument taxonomy

class AssetType(str, Enum):
    CRYPTO = "CRYPTO"
    FX = "FX"
    EQUITY = "EQUITY"
    FUTURE = "FUTURE"
    OPTION = "OPTION"

class InstrumentType(str, Enum):
    SPOT = "SPOT"
    PERP = "PERP"      # Perpetual future
    FUTURE = "FUTURE"  # Dated future
    OPTION = "OPTION"

@dataclass(frozen=True)
class ContractSpec:
    """Specification for derivatives contracts."""
    contract_size: Quantity
    settlement_asset: str
    expiry: Optional[Timestamp] = None  # None for perps/spot

    def __post_init__(self) -> None:
        ensure_non_empty_str(self.settlement_asset, "settlement_asset")
