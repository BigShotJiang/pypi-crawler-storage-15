from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from .time import Timestamp, now_ms
from .validation import ensure_non_empty_str, ensure_optional_non_negative_ts

@dataclass(frozen=True)
class EventMeta:
    """
    Lightweight metadata for tracing, auditability, and replay.

    Intended usage:
    - attach to envelopes/messages
    - or embed in higher-level event containers

    Fields:
    - event_id: unique id for this event instance
    - correlation_id: groups related events across components
    - causation_id: id of the event that caused this one (optional)
    - source: library/service that emitted the event
    - sequence: optional ordering number per source/stream
    - ts: event time
    - ingest_ts: time the event was ingested by the current component
    """
    event_id: str
    correlation_id: str
    source: str

    ts: Timestamp

    causation_id: Optional[str] = None
    sequence: Optional[int] = None
    ingest_ts: Optional[Timestamp] = None

    def __post_init__(self) -> None:
        ensure_non_empty_str(self.event_id, "event_id")
        ensure_non_empty_str(self.correlation_id, "correlation_id")
        ensure_non_empty_str(self.source, "source")

        ensure_optional_non_negative_ts(self.ts, "ts")
        ensure_optional_non_negative_ts(self.ingest_ts, "ingest_ts")

        if self.causation_id is not None:
            ensure_non_empty_str(self.causation_id, "causation_id")

        if self.sequence is not None and self.sequence < 0:
            raise ValueError("sequence must be non-negative")

def make_event_meta(
    *,
    event_id: str,
    correlation_id: str,
    source: str,
    ts: Optional[Timestamp] = None,
    causation_id: Optional[str] = None,
    sequence: Optional[int] = None,
    ingest_ts: Optional[Timestamp] = None,
) -> EventMeta:
    """
    Convenience constructor that fills default timestamps.
    """
    return EventMeta(
        event_id=event_id,
        correlation_id=correlation_id,
        source=source,
        ts=ts if ts is not None else now_ms(),
        causation_id=causation_id,
        sequence=sequence,
        ingest_ts=ingest_ts,
    )
