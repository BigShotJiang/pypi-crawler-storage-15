from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from .identifiers import InstrumentId, Venue
from .taxonomy import AssetType, InstrumentType, ContractSpec
from .money import InstrumentPrecision
from .validation import ensure_non_empty_str

@dataclass(frozen=True)
class InstrumentMeta:
    """
    Canonical instrument metadata shared across the QL stack.
    """
    instrument_id: InstrumentId
    venue: Venue

    asset_type: AssetType
    instrument_type: InstrumentType

    base_asset: str
    quote_asset: str

    precision: InstrumentPrecision
    contract_spec: Optional[ContractSpec] = None

    display_symbol: Optional[str] = None

    def __post_init__(self) -> None:
        ensure_non_empty_str(self.base_asset, "base_asset")
        ensure_non_empty_str(self.quote_asset, "quote_asset")

        if self.instrument_type in {InstrumentType.PERP, InstrumentType.FUTURE, InstrumentType.OPTION}:
            if self.contract_spec is None:
                raise ValueError("contract_spec is required for derivatives")
