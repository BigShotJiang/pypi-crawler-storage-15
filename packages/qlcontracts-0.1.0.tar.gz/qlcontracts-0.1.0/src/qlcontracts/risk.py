from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, List, Dict

from .identifiers import InstrumentId, StrategyId, AccountId
from .time import Timestamp
from .money import Quantity, Notional
from .validation import ensure_non_negative_ts, ensure_optional_non_negative_ts

# Risk contract types (schema + events)

@dataclass
class RiskLimits:
    """Configuration for risk limits (schema only)."""
    max_notional: Optional[Notional] = None
    max_position_size: Optional[Quantity] = None

    max_drawdown_percent: Optional[float] = None
    max_daily_loss: Optional[Notional] = None
    max_leverage: Optional[float] = None
    max_open_orders: Optional[int] = None
    max_order_size: Optional[Quantity] = None
    max_concentration_percent: Optional[float] = None

    per_instrument_max_position: Optional[Dict[InstrumentId, Quantity]] = None
    per_instrument_max_notional: Optional[Dict[InstrumentId, Notional]] = None

@dataclass
class RiskCheckResult:
    """Result of a pre-trade risk check."""
    is_accepted: bool
    rejection_reason: Optional[str] = None
    applied_limits: Optional[List[str]] = None

@dataclass
class RiskViolation:
    """Event emitted when a risk limit is breached."""
    account_id: AccountId
    strategy_id: Optional[StrategyId]
    rule_name: str
    violation_value: str
    threshold_value: str
    ts: Timestamp
    ingest_ts: Optional[Timestamp] = None

    def __post_init__(self) -> None:
        ensure_non_negative_ts(self.ts, "ts")
        ensure_optional_non_negative_ts(self.ingest_ts, "ingest_ts")

@dataclass
class CircuitBreakerEvent:
    """System-wide or strategy-wide kill switch event."""
    is_triggered: bool
    scope: str  # "GLOBAL", "STRATEGY:X", "INSTRUMENT:Y"
    reason: str
    ts: Timestamp
    resume_ts: Optional[Timestamp] = None
    ingest_ts: Optional[Timestamp] = None

    def __post_init__(self) -> None:
        ensure_non_negative_ts(self.ts, "ts")
        ensure_optional_non_negative_ts(self.resume_ts, "resume_ts")
        ensure_optional_non_negative_ts(self.ingest_ts, "ingest_ts")
