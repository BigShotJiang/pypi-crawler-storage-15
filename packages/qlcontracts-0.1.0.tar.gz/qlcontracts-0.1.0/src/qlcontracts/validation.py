from __future__ import annotations

from decimal import Decimal
from typing import Optional, TypeVar, Callable, TYPE_CHECKING

if TYPE_CHECKING:  # Avoid runtime import cycle with qlcontracts.time
    from .time import Timestamp
else:
    Timestamp = int

T = TypeVar("T")

def ensure(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)

def ensure_type(value: T, expected_type: type, field_name: str) -> T:
    if not isinstance(value, expected_type):
        raise TypeError(f"{field_name} must be a {expected_type.__name__}, got {type(value).__name__}")
    return value

def ensure_decimal(value: Optional[Decimal], field_name: str) -> Optional[Decimal]:
    if value is None:
        return None
    if not isinstance(value, Decimal):
        raise TypeError(f"{field_name} must be a Decimal, got {type(value).__name__}")
    return value

def ensure_required_decimal(value: Decimal, field_name: str) -> Decimal:
    v = ensure_decimal(value, field_name)
    if v is None:
        raise ValueError(f"{field_name} is required")
    return v

def ensure_positive_decimal(value: Decimal, field_name: str) -> Decimal:
    v = ensure_required_decimal(value, field_name)
    if v <= Decimal("0"):
        raise ValueError(f"{field_name} must be positive")
    return v

def ensure_non_negative_decimal(value: Decimal, field_name: str) -> Decimal:
    v = ensure_required_decimal(value, field_name)
    if v < Decimal("0"):
        raise ValueError(f"{field_name} must be non-negative")
    return v

def ensure_non_empty_str(value: str, field_name: str) -> str:
    if not isinstance(value, str):
        raise TypeError(f"{field_name} must be a string")
    if not value:
        raise ValueError(f"{field_name} is required")
    return value

def ensure_non_negative_ts(ts: Timestamp, field_name: str) -> Timestamp:
    if ts < 0:
        raise ValueError(f"{field_name} must be non-negative")
    return ts

def ensure_optional_non_negative_ts(ts: Optional[Timestamp], field_name: str) -> Optional[Timestamp]:
    if ts is None:
        return None
    ensure_non_negative_ts(ts, field_name)
    return ts

def coerce_if(value: T, fn: Callable[[T], T]) -> T:
    """
    Tiny helper to keep __post_init__ clean:
    value = coerce_if(value, lambda v: ...)
    """
    return fn(value)
