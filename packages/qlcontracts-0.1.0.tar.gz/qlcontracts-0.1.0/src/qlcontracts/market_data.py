from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Optional, List

from .identifiers import InstrumentId
from .time import Timestamp
from .money import Price, Quantity, Notional
from .validation import (
    ensure_positive_decimal,
    ensure_non_negative_decimal,
    ensure_non_negative_ts,
    ensure_optional_non_negative_ts,
    ensure,
)

# Market data primitives

@dataclass
class BookLevel:
    price: Price
    quantity: Quantity

    def __post_init__(self) -> None:
        self.price = Price(ensure_positive_decimal(self.price, "price"))
        self.quantity = Quantity(ensure_positive_decimal(self.quantity, "quantity"))

@dataclass
class BookSnapshot:
    instrument_id: InstrumentId
    ts: Timestamp
    bids: List[BookLevel]
    asks: List[BookLevel]
    ingest_ts: Optional[Timestamp] = None

    def __post_init__(self) -> None:
        ensure_non_negative_ts(self.ts, "ts")
        ensure_optional_non_negative_ts(self.ingest_ts, "ingest_ts")

class QuoteSide(str, Enum):
    BID = "BID"
    ASK = "ASK"

class BookAction(str, Enum):
    ADD = "ADD"
    UPDATE = "UPDATE"
    DELETE = "DELETE"

@dataclass
class BookDelta:
    instrument_id: InstrumentId
    ts: Timestamp
    side: QuoteSide
    action: BookAction
    level: BookLevel
    ingest_ts: Optional[Timestamp] = None

    def __post_init__(self) -> None:
        ensure_non_negative_ts(self.ts, "ts")
        ensure_optional_non_negative_ts(self.ingest_ts, "ingest_ts")

@dataclass
class Tick:
    """A single market tick (trade or quote update)."""
    instrument_id: InstrumentId
    ts: Timestamp
    price: Price
    size: Quantity
    ingest_ts: Optional[Timestamp] = None

    def __post_init__(self) -> None:
        ensure_non_negative_ts(self.ts, "ts")
        self.price = Price(ensure_positive_decimal(self.price, "price"))
        self.size = Quantity(ensure_positive_decimal(self.size, "size"))
        ensure_optional_non_negative_ts(self.ingest_ts, "ingest_ts")

@dataclass
class Bar:
    """OHLCV Bar."""
    instrument_id: InstrumentId
    ts: Timestamp          # start time of bar
    duration: int          # ms

    open: Price
    high: Price
    low: Price
    close: Price

    volume: Quantity
    notional: Optional[Notional] = None
    ingest_ts: Optional[Timestamp] = None

    def __post_init__(self) -> None:
        ensure_non_negative_ts(self.ts, "ts")
        ensure(self.duration > 0, "duration must be positive")

        self.open = Price(ensure_positive_decimal(self.open, "open"))
        self.high = Price(ensure_positive_decimal(self.high, "high"))
        self.low = Price(ensure_positive_decimal(self.low, "low"))
        self.close = Price(ensure_positive_decimal(self.close, "close"))

        # allow empty bars
        self.volume = Quantity(ensure_non_negative_decimal(self.volume, "volume"))

        if self.notional is not None:
            self.notional = Notional(ensure_non_negative_decimal(self.notional, "notional"))

        ensure_optional_non_negative_ts(self.ingest_ts, "ingest_ts")
