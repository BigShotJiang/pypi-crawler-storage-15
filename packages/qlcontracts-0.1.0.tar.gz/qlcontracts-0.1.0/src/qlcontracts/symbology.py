from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple

from .identifiers import InstrumentId, Venue
from .taxonomy import InstrumentType
from .validation import ensure_non_empty_str

@dataclass(frozen=True)
class ParsedInstrumentId:
    """
    A minimal parsed view of InstrumentId.

    Canonical string format (recommended):
      VENUE:BASE-QUOTE[:TYPE]

    Examples:
      BINANCE:BTC-USDT
      BYBIT:BTC-USDT:PERP

    Notes:
    - TYPE is optional to keep compatibility with simple spot symbology.
    - This parser does not enforce a specific delimiter inside the symbol beyond
      being non-empty.
    """
    venue: Venue
    symbol: str
    instrument_type: Optional[InstrumentType] = None

def make_instrument_id(
    venue: str,
    symbol: str,
    instrument_type: Optional[InstrumentType] = None,
) -> InstrumentId:
    """
    Create a canonical InstrumentId string from parts.

    This is intentionally conservative:
    - uppercase venue
    - preserve symbol casing but strip spaces
    """
    v = ensure_non_empty_str(venue, "venue").upper()
    s = ensure_non_empty_str(symbol, "symbol").strip()

    if instrument_type is None:
        return InstrumentId(f"{v}:{s}")
    return InstrumentId(f"{v}:{s}:{instrument_type.value}")

def parse_instrument_id(instrument_id: InstrumentId) -> ParsedInstrumentId:
    """
    Parse a canonical InstrumentId into (venue, symbol, optional type).

    Supports:
      VENUE:SYMBOL
      VENUE:SYMBOL:TYPE
    """
    raw = ensure_non_empty_str(str(instrument_id), "instrument_id")

    parts = raw.split(":")
    if len(parts) < 2:
        raise ValueError("InstrumentId must be in form VENUE:SYMBOL or VENUE:SYMBOL:TYPE")

    venue_str = ensure_non_empty_str(parts[0], "venue").upper()
    symbol = ensure_non_empty_str(parts[1], "symbol").strip()

    itype: Optional[InstrumentType] = None
    if len(parts) >= 3 and parts[2]:
        try:
            itype = InstrumentType(parts[2].upper())
        except ValueError:
            # Unknown type string - keep strict to avoid silent drift
            raise ValueError(f"Unsupported instrument type in InstrumentId: {parts[2]}")

    return ParsedInstrumentId(venue=Venue(venue_str), symbol=symbol, instrument_type=itype)

def split_venue_symbol(instrument_id: InstrumentId) -> Tuple[Venue, str]:
    """
    Convenience for common usage in qldata/qlexec.
    """
    p = parse_instrument_id(instrument_id)
    return p.venue, p.symbol

def normalize_instrument_id(instrument_id: InstrumentId) -> InstrumentId:
    """
    Normalize to canonical formatting:
    - uppercase venue
    - preserve symbol
    - preserve optional type
    """
    p = parse_instrument_id(instrument_id)
    return make_instrument_id(str(p.venue), p.symbol, p.instrument_type)
