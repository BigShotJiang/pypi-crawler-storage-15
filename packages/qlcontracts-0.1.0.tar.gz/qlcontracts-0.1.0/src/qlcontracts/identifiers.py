from typing import NewType

# 1) Identifiers

# InstrumentId: A unique identifier for an instrument (e.g., "BINANCE:BTC-USDT")
InstrumentId = NewType("InstrumentId", str)

# Venue: The exchange or venue name (e.g., "BINANCE", "CME")
Venue = NewType("Venue", str)

# AccountId: A unique identifier for a trading account
AccountId = NewType("AccountId", str)

# OrderId: A unique identifier for an order assigned by the venue
OrderId = NewType("OrderId", str)

# ClientOrderId: A unique identifier for an order assigned by the client/strategy
ClientOrderId = NewType("ClientOrderId", str)

# StrategyId: A unique identifier for a strategy instance
StrategyId = NewType("StrategyId", str)

# SubAccountId: A sub-account identifier
SubAccountId = NewType("SubAccountId", str)

# TradeId: A unique identifier for a completed trade (public or private)
TradeId = NewType("TradeId", str)

# PortfolioId: Identifier for a portfolio grouping
PortfolioId = NewType("PortfolioId", str)

# SessionId: Identifier for a trading session (e.g. gateway connection)
SessionId = NewType("SessionId", str)

# RunId: Identifier for a specific execution run (backtest or live)
RunId = NewType("RunId", str)
