"""Version information for keyban-api-client."""

__version__ = "0.0.1"
