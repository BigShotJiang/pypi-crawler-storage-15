"""
Keyban API Product Sheet Python Client

A Python client for interacting with the Keyban API Product Sheet API.
This client provides methods for CRUD operations on product sheets.
"""

from datetime import datetime
from typing import Any, Dict, List, Optional, Union
from uuid import UUID

import requests
from pydantic import BaseModel, Field, field_validator


class ProductSheetData(BaseModel):
    """Product data following schema.org/Product format with custom field support"""
    # From schema.org/Thing (base class)
    identifier: Optional[str] = None
    name: str  # Keep name required for practical use
    description: Optional[str] = None
    image: Optional[str] = None  # URL to product image

    # From schema.org/Product extensions
    gtin: Optional[str] = None  # Global Trade Item Number
    sku: Optional[str] = None   # Stock Keeping Unit
    brand: Optional[Union[str, Dict[str, Any]]] = None  # Brand info
    countryOfOrigin: Optional[Union[str, Dict[str, Any]]] = None  # Country where product is made
    keywords: Optional[List[str]] = None  # Array of keywords

    class Config:
        extra = "allow"  # Allow custom fields via **{} syntax

    def model_dump(self, **kwargs):
        """Custom serialization to exclude null values"""
        data = super().model_dump(**kwargs)
        # Remove null/None values as API doesn't accept them
        return {k: v for k, v in data.items() if v is not None}

    @field_validator('brand', mode='before')
    @classmethod
    def parse_brand(cls, v):
        """Handle brand as either string or object with name field"""
        if v is None:
            return None
        elif isinstance(v, str):
            # Convert string to object format expected by API
            return {"name": v}
        elif isinstance(v, dict):
            # Keep object format as-is
            return v
        return v

    @field_validator('countryOfOrigin', mode='before')
    @classmethod
    def parse_country_of_origin(cls, v):
        """Handle countryOfOrigin as either string or object with identifier/name"""
        if v is None:
            return None
        elif isinstance(v, str):
            # Convert string to object format (could be country code or name)
            if len(v) == 2:  # Assume it's a country code
                return {"identifier": v.upper()}
            else:  # Assume it's a country name
                return {"name": v}
        elif isinstance(v, dict):
            # Keep object format as-is
            return v
        return v


class Application(BaseModel):
    """Application model"""
    id: UUID
    shopifyShop: Optional[str] = None

class ProductSheet(BaseModel):
    """Keyban API Product Sheet model"""
    id: UUID
    application: Union[Application, UUID, str]  # Handle both object and UUID formats
    network: str  # Network enum value
    status: str  # ProductSheetStatus enum value
    data: ProductSheetData
    certified_paths: Optional[List[str]] = Field(default=None, alias="certifiedPaths")
    created_at: datetime = Field(alias="createdAt")
    updated_at: datetime = Field(alias="updatedAt")

    @field_validator('application', mode='before')
    @classmethod
    def parse_application(cls, v):
        """Handle both Application object and UUID string formats"""
        if isinstance(v, str):
            # If it's a string UUID, convert to Application object
            return Application(id=UUID(v))
        elif isinstance(v, dict):
            # If it's a dict, use it as-is for Application parsing
            return v
        return v

    class Config:
        populate_by_name = True


class CreateProductSheetRequest(BaseModel):
    """Request model for creating a product sheet"""
    application: UUID
    network: str
    status: str
    data: ProductSheetData  # Reverting back to 'data' based on API error messages
    certified_paths: List[str] = Field(default_factory=list, alias="certifiedPaths")

    class Config:
        populate_by_name = True


class UpdateProductSheetRequest(BaseModel):
    """Request model for updating a product sheet"""
    network: Optional[str] = None
    status: Optional[str] = None
    data: Optional[ProductSheetData] = None  # Reverting back to 'data' based on API error messages
    certified_paths: Optional[List[str]] = Field(default=None, alias="certifiedPaths")

    class Config:
        populate_by_name = True


class ProductSheetListResponse(BaseModel):
    """Response model for listing product sheets"""
    data: List[ProductSheet]
    total: int


class FilterOperator(BaseModel):
    """Filter operator for querying"""
    field: str
    operator: str  # 'eq', 'contains', 'gt', 'lt'
    value: Any


class QueryParams(BaseModel):
    """Query parameters for listing product sheets"""
    filters: Optional[List[FilterOperator]] = None
    current_page: Optional[int] = Field(default=1, alias="currentPage")
    page_size: Optional[int] = Field(default=10, alias="pageSize")

    class Config:
        populate_by_name = True


class ProductSheetClient:
    """
    Python client for interacting with Keyban API Product Sheet endpoints.

    Supports the following operations:
    - List product sheets with flexible filtering and pagination
    - Get a specific product sheet by ID
    - Create a new product sheet
    - Update an existing product sheet
    - Delete an existing product sheet

    The list_product_sheets() method supports flexible filtering using FilterOperator objects.
    Supported filter fields: status, network, data.name, data.brand, data.category, createdAt, updatedAt, application.id
    Supported operators: eq (exact match), contains (substring), gt (greater than), lt (less than)
    Supported networks: StarknetSepolia, StarknetMainnet (default: StarknetSepolia)
    """

    def __init__(
        self,
        base_url: str,
        api_key: str,
        api_version: str = "v1",
        timeout: int = 30
    ):
        """
        Initialize the Keyban API Product Sheet client.

        Args:
            base_url: Base URL of the API (e.g., "https://api.keyban.io")
            api_key: API key for authentication (required)
            api_version: API version (default: "v1")
            timeout: Request timeout in seconds (default: 30)
        """
        self.base_url = base_url.rstrip('/')
        self.api_version = api_version
        self.timeout = timeout

        self.session = requests.Session()
        self.session.headers.update({
            "X-Api-Key": api_key,
            "Content-Type": "application/json"
        })

    def _get_endpoint_url(self, path: str = "") -> str:
        """Get the full endpoint URL"""
        path = path.lstrip('/')
        return f"{self.base_url}/{self.api_version}/dpp/product-sheets/{path}".rstrip('/')

    def _make_request(
        self,
        method: str,
        path: str = "",
        params: Optional[Dict] = None,
        data: Optional[Dict] = None,
        json_data: Optional[Dict] = None
    ) -> requests.Response:
        """Make HTTP request to the API"""
        url = self._get_endpoint_url(path)

        response = self.session.request(
            method=method,
            url=url,
            params=params,
            data=data,
            json=json_data,
            timeout=self.timeout
        )

        response.raise_for_status()
        return response

    def list_product_sheets(
        self,
        filters: Optional[List[FilterOperator]] = None,
        current_page: int = 1,
        page_size: int = 10
    ) -> ProductSheetListResponse:
        """
        List product sheets with flexible custom filtering.

        This method provides full access to the filtering system, allowing you to filter
        by any field with any supported operator.

        Args:
            filters: List of FilterOperator objects for custom filtering (optional)
            current_page: Page number (1-based, default: 1)
            page_size: Number of items per page (default: 10, max: 100)

        Returns:
            ProductSheetListResponse containing the list of product sheets and total count

        Supported filter fields:
            - status: Product sheet status (DRAFT, ACTIVE, etc.)
            - network: Network type (StarknetSepolia, StarknetMainnet)
            - data.name: Product name
            - data.brand: Product brand
            - data.category: Product category
            - data.description: Product description
            - createdAt: Creation date
            - updatedAt: Last update date
            - application.id: Application ID

        Supported operators:
            - eq: Exact match
            - contains: Substring search (case-insensitive)
            - gt: Greater than (useful for dates)
            - lt: Less than (useful for dates)

        Examples:
            # List all product sheets (no filters)
            all_sheets = client.list_product_sheets()

            # Filter by application ID
            app_filter = FilterOperator(field="application.id", operator="eq", value=str(app_id))
            sheets = client.list_product_sheets(filters=[app_filter])

            # Filter by product name (substring search)
            name_filter = FilterOperator(field="data.name", operator="contains", value="Nike")
            sheets = client.list_product_sheets(filters=[name_filter])

            # Filter by status and network
            filters = [
                FilterOperator(field="status", operator="eq", value="ACTIVE"),
                FilterOperator(field="network", operator="eq", value="StarknetSepolia"),
                FilterOperator(field="data.brand", operator="contains", value="Nike")
            ]
            sheets = client.list_product_sheets(filters=filters)

            # Filter by date range (created in last 7 days)
            from datetime import datetime, timedelta
            week_ago = (datetime.now() - timedelta(days=7)).isoformat()
            date_filter = FilterOperator(field="createdAt", operator="gt", value=week_ago)
            recent_sheets = client.list_product_sheets(filters=[date_filter])

            # Complex filtering: Active Nike products created this year
            from datetime import datetime
            year_start = datetime(2024, 1, 1).isoformat()
            filters = [
                FilterOperator(field="status", operator="eq", value="ACTIVE"),
                FilterOperator(field="data.brand", operator="eq", value="Nike"),
                FilterOperator(field="createdAt", operator="gt", value=year_start)
            ]
            nike_products = client.list_product_sheets(filters=filters, page_size=50)
        """
        params = {
            "currentPage": current_page,
            "pageSize": min(page_size, 100)  # Enforce max page size
        }

        # Add filters as properly formatted query parameters
        if filters:
            for i, filter_obj in enumerate(filters):
                params[f"filters[{i}][field]"] = filter_obj.field
                params[f"filters[{i}][operator]"] = filter_obj.operator
                params[f"filters[{i}][value]"] = str(filter_obj.value)

        response = self._make_request("GET", params=params)
        return ProductSheetListResponse(**response.json())

    def get_product_sheet(self, product_sheet_id: UUID) -> ProductSheet:
        """
        Get a specific product sheet by its ID.

        This endpoint is public and doesn't require authentication.

        Args:
            product_sheet_id: The UUID of the product sheet

        Returns:
            ProductSheet object

        Raises:
            requests.HTTPError: If the product sheet is not found (404) or other HTTP errors
        """
        response = self._make_request("GET", str(product_sheet_id))
        return ProductSheet(**response.json())

    def create_product_sheet(self, product_sheet_data: CreateProductSheetRequest) -> ProductSheet:
        """
        Create a new product sheet.

        Requires authentication and organization-level access.

        Args:
            product_sheet_data: The product sheet data to create

        Returns:
            Created ProductSheet object

        Raises:
            requests.HTTPError: If the application is not found (404) or other HTTP errors
        """
        # Convert Pydantic model to dict, handling aliases and converting UUIDs to strings
        json_data = product_sheet_data.model_dump(by_alias=True, exclude_unset=True, mode='json')

        response = self._make_request("POST", json_data=json_data)
        return ProductSheet(**response.json())

    def update_product_sheet(
        self,
        product_sheet_id: UUID,
        update_data: UpdateProductSheetRequest
    ) -> ProductSheet:
        """
        Update an existing product sheet.

        Requires authentication and organization-level access.
        Only product sheets belonging to the authenticated organization can be updated.

        Args:
            product_sheet_id: The UUID of the product sheet to update
            update_data: The updated product sheet data

        Returns:
            Updated ProductSheet object

        Raises:
            requests.HTTPError: If the product sheet is not found (404) or other HTTP errors
        """
        # Convert Pydantic model to dict, excluding unset fields and handling aliases
        json_data = update_data.model_dump(by_alias=True, exclude_unset=True, mode='json')

        response = self._make_request("PATCH", str(product_sheet_id), json_data=json_data)
        return ProductSheet(**response.json())

    def delete_product_sheet(self, product_sheet_id: UUID) -> bool:
        """
        Delete an existing product sheet.

        Requires authentication and organization-level access.
        Only product sheets belonging to the authenticated organization can be deleted.

        Args:
            product_sheet_id: The UUID of the product sheet to delete

        Returns:
            bool: True if deletion was successful

        Raises:
            requests.HTTPError: If the product sheet is not found (404) or other HTTP errors
        """
        # For DELETE requests, we need to remove Content-Type header if no body is sent
        url = self._get_endpoint_url(str(product_sheet_id))

        # Create headers without Content-Type for DELETE
        headers = {k: v for k, v in self.session.headers.items() if k.lower() != 'content-type'}

        response = requests.delete(
            url,
            headers=headers,
            timeout=self.timeout,
            verify=getattr(self, 'verify', True)
        )
        response.raise_for_status()

        # DELETE typically returns 204 No Content on success
        return response.status_code in [200, 204]

    def close(self):
        """Close the HTTP session"""
        self.session.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


# Convenience functions for filter creation
def create_filter(field: str, operator: str, value: Any) -> FilterOperator:
    """
    Create a FilterOperator for use with list_product_sheets.

    Args:
        field: Field to filter on (e.g., "status", "network", "data.name")
        operator: Filter operator ("eq", "contains", "gt", "lt")
        value: Value to filter by

    Returns:
        FilterOperator object

    Examples:
        # Exact match filters
        status_filter = create_filter("status", "eq", "ACTIVE")
        network_filter = create_filter("network", "eq", "StarknetSepolia")
        app_filter = create_filter("application.id", "eq", str(app_id))

        # Substring search filters
        name_filter = create_filter("data.name", "contains", "Product")
        brand_filter = create_filter("data.brand", "contains", "Nike")
        category_filter = create_filter("data.category", "eq", "Clothing")

        # Date range filters
        from datetime import datetime, timedelta
        week_ago = (datetime.now() - timedelta(days=7)).isoformat()
        recent_filter = create_filter("createdAt", "gt", week_ago)

        # Multiple filters example
        filters = [
            create_filter("status", "eq", "ACTIVE"),
            create_filter("data.brand", "eq", "Nike"),
            create_filter("createdAt", "gt", "2024-01-01T00:00:00Z")
        ]
        sheets = client.list_product_sheets(filters=filters)
    """
    return FilterOperator(field=field, operator=operator, value=value)


# Convenience functions for common operations
def search_product_sheets_by_application_id(
    client: ProductSheetClient,
    application_id: UUID,
    page_size: int = 100
) -> List[ProductSheet]:
    """
    Convenience function to search for product sheets by application ID.

    Args:
        client: ProductSheetClient instance
        application_id: Application ID to filter by
        page_size: Number of results to return (default: 100)

    Returns:
        List of matching ProductSheet objects
    """
    filters = [
        FilterOperator(field="application.id", operator="eq", value=str(application_id))
    ]

    response = client.list_product_sheets(
        filters=filters,
        page_size=page_size
    )

    return response.data
