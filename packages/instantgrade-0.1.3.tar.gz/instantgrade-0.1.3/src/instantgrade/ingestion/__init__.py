"""
Ingestion layer.
Responsible for loading instructor and student submissions from
various file formats (Jupyter, Excel, Python scripts, future languages).
"""
