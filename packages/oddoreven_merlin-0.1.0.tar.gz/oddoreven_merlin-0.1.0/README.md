# oddoreven

A tiny Python package to check whether a number is odd or even.

## Installation

pip install oddoreven-merlin

## Usage

from oddoreven import check, is_even, is_odd
print(check(10))
print(is_even(7))
print(is_odd(7))
