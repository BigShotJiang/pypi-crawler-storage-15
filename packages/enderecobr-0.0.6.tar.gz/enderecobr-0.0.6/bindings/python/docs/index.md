# enderecobr_py

Bindings para Python do [enderecobr_rs](https://crates.io/crates/enderecobr_rs).

Algumas funcionalidades do [Rust](https://crates.io/crates/enderecobr_rs) não foram expostas para o Python. Abra uma [issue ou pull request](https://github.com/ipeaGIT/enderecobr_rs)
caso algumas delas seja necessária para o seu caso de uso.

::: enderecobr
