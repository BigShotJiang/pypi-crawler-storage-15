#!/usr/bin/env python3
"""Setup script for Onwords package."""

from setuptools import setup, find_packages

setup(
    name="onwords",
    packages=find_packages(),
)


