"""Baidu Netdisk Client - A Python client for Baidu Netdisk API"""

from .client import BaiduNetdiskClient

__version__ = "1.1.2"
__all__ = ["BaiduNetdiskClient"]

