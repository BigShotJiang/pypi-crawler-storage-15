# Watchman Agent Client

**Agent d'inventaire système moderne et multi-plateforme** pour collecter automatiquement les informations matérielles et logicielles de vos machines.

[![PyPI version](https://badge.fury.io/py/watchman-agent-client.svg)](https://pypi.org/project/watchman-agent-client/)
[![Python Versions](https://img.shields.io/pypi/pyversions/watchman-agent-client.svg)](https://pypi.org/project/watchman-agent-client/)
[![License](https://img.shields.io/pypi/l/watchman-agent-client.svg)](https://github.com/bienvenu-gits/agent_client/blob/main/LICENSE)

## 🎯 Fonctionnalités

- 📊 **Collecte complète** : Matériel, logiciels, réseau, processus système
- 🔄 **Planification automatique** : Quotidien, hebdomadaire, mensuel
- 🌐 **Interface web intégrée** : Dashboard local sur `http://localhost:8080`
- ⚡ **API REST** : Envoi automatique des données vers votre serveur
- 🛠️ **Multi-plateforme** : Windows, Linux, macOS
- 🔧 **Service système** : Fonctionne en arrière-plan

## 🚀 Installation

### Installation simple

```bash
pip install watchman-agent-client
```

### Installation avec dépendances de développement

```bash
pip install watchman-agent-client[dev]
```

## 📖 Démarrage Rapide

### 1. Configuration

Créez un fichier de configuration `config.ini` :

```ini
[server]
url = https://votre-serveur.com/api/v1/inventory
auth_token = votre-token-ici
timeout = 30
verify_ssl = true

[agent]
reporting_frequency = daily
log_level = INFO
collect_software = true
collect_hardware = true
collect_network = true
```

### 2. Lancement de l'agent

#### Mode service (recommandé)

```bash
# L'agent démarre automatiquement après installation
# Interface web disponible sur http://localhost:8080
```

#### Mode ligne de commande

```bash
# Collecte et envoi immédiat
watchman-agent-client --mode collect-send --config-file config.ini

# Collecte uniquement
watchman-agent-client --mode collect --output-file inventaire.json

# Test de connectivité
watchman-agent-client --mode test --config-file config.ini

# Interface web uniquement
watchman-agent-client --mode web
```

### 3. Interface Web

Accédez au dashboard : **http://localhost:8080**

Fonctionnalités :
- 📊 Vue d'ensemble du système
- 🔄 Déclenchement manuel de collecte
- 📤 Envoi forcé vers le serveur
- ⚙️ Configuration en temps réel
- 📝 Consultation des logs

## 📋 Données Collectées

### Informations Système
- Nom d'hôte, domaine, utilisateur
- OS, version, architecture
- CPU, mémoire, charge système
- Disques et partitions

### Matériel
- Processeur (modèle, cœurs, fréquence)
- Mémoire RAM (total, modules)
- Stockage (disques, SSD)
- Cartes réseau et interfaces

### Logiciels
- Applications installées
- Services système
- Pilotes et versions
- Mises à jour système

### Réseau
- Interfaces (Ethernet, WiFi)
- Adressage IP, passerelles, DNS
- Ports ouverts
- Configuration DHCP/statique

## 🔧 Utilisation Avancée

### Collecte programmatique

```python
from agent.core.collector import InventoryCollector
from agent.core.config import AgentConfig

# Charger la configuration
config = AgentConfig('config.ini')

# Créer le collecteur
collector = InventoryCollector(config)

# Collecter les données
inventory = collector.collect_all()

print(inventory)
```

### Envoi vers API

```python
from agent.core.sender import InventorySender
from agent.core.config import AgentConfig

config = AgentConfig('config.ini')
sender = InventorySender(config)

# Envoyer l'inventaire
success = sender.send_inventory(inventory)
```

## 📁 Emplacements des Fichiers

### Linux/macOS
```
/etc/watchman-agent-client/config.ini
/var/log/watchman-agent-client/agent.log
```

### Windows
```
C:\Program Files\WatchmanAgentClient\config\config.ini
C:\Program Files\WatchmanAgentClient\logs\agent.log
```

## 🔒 Sécurité

- Interface web accessible uniquement en local (127.0.0.1)
- Authentification token pour les communications serveur
- Chiffrement SSL/TLS obligatoire
- Aucun token dans les logs
- Privilèges minimaux pour le service

## 📊 Format des Données

Les données sont envoyées au format JSON :

```json
{
  "assets": [{
    "collection_timestamp": "2024-01-15T14:30:00Z",
    "agent_version": "1.0.0",
    "hostname": "PC-BUREAU-01",
    "architecture": "x86_64",
    "os": "Windows 11 Pro 22H2",
    "ip": "192.168.1.100",
    "mac": "aa:bb:cc:dd:ee:ff",
    "cpu": {
      "model": "Intel Core i7-12700K",
      "cores": 12,
      "frequency": "3600 MHz"
    },
    "memory": {
      "total": "32 GB",
      "available": "18 GB"
    },
    "applications": [...],
    "network_interfaces": [...]
  }]
}
```

## 🆘 Support & Documentation

- **Documentation complète** : [docs.watchman.bj](https://docs.watchman.bj)
- **Signaler un bug** : [GitHub Issues](https://github.com/bienvenu-gits/agent_client/issues)
- **Code source** : [GitHub Repository](https://github.com/bienvenu-gits/agent_client)

## 📝 Changelog

Voir le fichier CHANGELOG.md pour l'historique des versions.

## 🤝 Contribution

Les contributions sont les bienvenues ! Consultez notre documentation sur [docs.watchman.bj](https://docs.watchman.bj).

## 📄 Licence

MIT License - voir [LICENSE](https://github.com/bienvenu-gits/agent_client/blob/main/LICENSE) pour plus de détails.

## ⭐ Support

Si vous trouvez ce projet utile, n'hésitez pas à lui donner une étoile sur [GitHub](https://github.com/bienvenu-gits/agent_client) !

---

**Développé avec ❤️ par l'équipe Watchman**
