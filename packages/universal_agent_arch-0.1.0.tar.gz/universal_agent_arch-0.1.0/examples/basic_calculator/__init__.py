"""Basic calculator example placeholder."""

__all__: list[str] = []

