"""Examples package for reference agent configurations."""

__all__: list[str] = []

