# Minimal E2E example package

