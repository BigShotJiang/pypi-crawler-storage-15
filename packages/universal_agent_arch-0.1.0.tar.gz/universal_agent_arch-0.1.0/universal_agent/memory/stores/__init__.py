"""Memory store adapter package (placeholder for concrete stores)."""

__all__: list[str] = []

