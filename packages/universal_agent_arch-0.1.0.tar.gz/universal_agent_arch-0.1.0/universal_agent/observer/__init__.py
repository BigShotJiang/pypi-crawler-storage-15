"""Observer sinks and telemetry integrations."""

from .sinks.otel import OpenTelemetrySink

__all__ = ["OpenTelemetrySink"]

