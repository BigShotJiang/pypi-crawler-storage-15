"""Observer sink package."""

from .otel import OpenTelemetrySink

__all__ = ["OpenTelemetrySink"]

