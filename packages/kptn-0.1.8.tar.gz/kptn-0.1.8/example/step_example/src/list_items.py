from typing import List


def list_items() -> List[str]:
    """Return a small list to drive a mapped task example."""
    return ["alpha", "beta", "gamma"]
