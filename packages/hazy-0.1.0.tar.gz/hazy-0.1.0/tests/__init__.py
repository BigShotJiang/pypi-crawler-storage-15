"""Hazy test suite."""
