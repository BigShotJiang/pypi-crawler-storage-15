#!/usr/bin/env python3

from localecmd import Module, printout, programfunction


@programfunction()
def func(a: int = 9, *b: float, c: int = 8, **d: str):  # pragma: no cover
    """
    This is a docstring

    This has many lines

    ```python
    Doctest example
    >>> func()

    ```
    :::{lcmd-example}
    func 8 9 10 -c 80
    :::

    """
    printout(a)


module = Module('test', [func], 'Module docstring')

# Output to be parsed with myst-parser and sphinx
expected_output = """# Module test
Module docstring

```{py:function} func a b... -c -d... 
:label: func

This is a docstring

This has many lines


:::{lcmd-example}
func 8 9 10 -c 80
:::
```
"""

# output as result from sphinx with markdown builder
expected_output_built_md = """# Module test

Module docstring

### func a b... -c -d...

This is a docstring

This has many lines

```bash
¤ func 8 9 10 -c 80
8
```

"""
