"""Converting localecmddoc codeblocks to sphinx literal blocks,
thereby running the conde inside"""

from __future__ import annotations

from docutils import nodes
from localecmd import start_cli
from sphinx.application import Sphinx
from sphinx.environment import BuildEnvironment
from sphinx.util.docutils import SphinxDirective

from localecmddoc.autodoc import get_modules


class LocalecmdExample(nodes.literal_block):
    """This class exists to mark the block. It is later replaced"""

    pass


class LocalecmdExampleDirective(SphinxDirective):
    """
    Directive of localecmd examples.

    Type the commands only and sphinx will run the command and give the printout.
    """

    # this enables content in the directive
    has_content = True

    def run(self):
        # Number, identification for this example
        targetnr = self.env.new_serialno('localecmd-example')
        targetid = f'localecmd-example-{targetnr}'
        # This is a reference to this example, so it is possible to come here
        targetnode = nodes.target('', '', ids=[targetid])

        code = '\n'.join(self.content)
        node = LocalecmdExample(code, code)  # rawsource, text
        node['language'] = 'bash'

        # Add directive to list of examples
        docname = self.env.current_document.docname
        if not hasattr(self.env, 'localecmddoc_all_examples'):
            self.env.localecmddoc_all_examples = {}
        if docname not in self.env.localecmddoc_all_examples:
            self.env.localecmddoc_all_examples[docname] = {}
        self.env.localecmddoc_all_examples[docname][self.lineno] = {
            'docname': self.env.current_document.docname,
            'line': self.lineno,
            'node': node,
            'target': targetnode,
        }
        # print(self.env.localecmddoc_all_examples)
        returnnodes = []
        if self.config.localecmd_target_codeblocks:
            returnnodes.append(targetnode)
        returnnodes.append(node)
        return returnnodes


def clean_example_dicts(app: Sphinx, env: BuildEnvironment, docname: str):
    "Delete entries in the example dicts that are at wrong document????"
    if not hasattr(env, 'localecmddoc_all_examples'):
        return
    env.localecmddoc_all_examples = {
        d: x for d, x in env.localecmddoc_all_examples.items() if d != docname
    }


def merge_example_dicts(
    app: Sphinx, env: BuildEnvironment, docnames: list[str], other: BuildEnvironment
):
    if not hasattr(env, 'localecmddoc_all_examples'):
        env.localecmddoc_all_examples = {}  # type:ignore[attr-defined]

    if not hasattr(other, 'localecmddoc_all_examples'):
        return

    for docname, examples in other.localecmddoc_all_examples.items():
        if docname in env.localecmddoc_all_examples:  # type:ignore[attr-defined]
            raise RuntimeError("Must deeply merge examples!")
        else:
            env.localecmddoc_all_examples[docname] = examples  # type:ignore[attr-defined]


def run_codeblocks(app: Sphinx, doctree: nodes.document, docname: str):
    "Run the code, get the output and put the result back into the node."
    modules = get_modules(
        app.config.localecmd_searchmodules,
        app.config.localecmd_builtins_modulename,
    )
    language = app.config.localecmd_codeblocks_language
    if language == 'sphinx':
        language = app.config.language
    cli = start_cli(modules, language)

    for node in doctree.findall(LocalecmdExample):
        # The last entry should only contain what we need
        cli.transcript.new_entry()
        for line in node.astext().split('\n'):
            cli.runcmd(line)
        transcript = cli.transcript.get(-1)[0]
        newnode = nodes.literal_block(node.astext(), transcript)
        newnode['language'] = 'bash'

        # Replace node and reference
        node.replace_self(newnode)
        app.env.localecmddoc_all_examples[docname][node.line]['node'] = newnode  # type:ignore[attr-defined]
    cli.close()
