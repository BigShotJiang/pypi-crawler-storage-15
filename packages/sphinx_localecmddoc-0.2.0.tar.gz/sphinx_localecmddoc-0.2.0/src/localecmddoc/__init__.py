#!/usr/bin/env python3
"""
Sphinx extension to generate documentation of localecmd modules.

This module contains the connections with sphinx.
"""

from __future__ import annotations

import pathlib
from typing import Iterable

from sphinx.application import Sphinx
from sphinx.util import logging
from sphinx.util.typing import ExtensionMetadata

from localecmddoc.autodoc import get_modules, write_module_docs
from localecmddoc.codeblock import (
    LocalecmdExampleDirective,
    clean_example_dicts,
    merge_example_dicts,
    run_codeblocks,
)

version = '0.1'

logger = logging.getLogger("localecmddoc")


def create_docs(app: Sphinx):
    modules = get_modules(
        app.config.localecmd_searchmodules,
        app.config.localecmd_builtins_modulename,
    )

    output_folder = pathlib.Path(app.srcdir) / app.config.localecmd_outdir

    logger.debug("[localecmddoc] Create files with in-program documentation")
    write_module_docs(modules, output_folder, remove_pycode=True)


def setup(app: Sphinx) -> ExtensionMetadata:
    app.add_config_value(
        'localecmd_searchmodules',
        [''],
        'html',
        Iterable[str],
        "Where (In which modules) to look for localecmd.Modules",
    )
    app.add_config_value(
        'localecmd_builtins_modulename',
        'core',
        'html',
        str,
        "Name of module containing the commands builin to localecmd."
        "If empty, the module is not included.",
    )
    app.add_config_value(
        'localecmd_outdir',
        'functions',
        'html',
        str,
        "Directory for output of the command docs. Relative to sphinx output dir",
    )
    app.add_config_value(
        'localecmd_remove_python_code_blocks',
        True,
        'html',
        bool,
        "If python code blocks should be removed from docstrings",
    )
    app.add_config_value(
        'localecmd_target_codeblocks',
        False,
        'html',
        bool,
        "If localecmd example code blocks should get target attributes",
    )
    app.add_config_value(
        'localecmd_codeblocks_language',
        'sphinx',
        'html',
        str,
        "What language to use for the CLI in and outputs. "
        "Default is 'sphinx', same as 'language' setting",
    )

    app.add_directive('lcmd-example', LocalecmdExampleDirective)

    app.setup_extension('myst_parser')

    app.connect("builder-inited", create_docs)
    app.connect('env-purge-doc', clean_example_dicts)
    app.connect('env-merge-info', merge_example_dicts)
    app.connect("doctree-resolved", run_codeblocks)

    return {
        'version': version,
        'env_version': 1,
        'parallel_read_safe': True,
        'parallel_write_safe': True,
    }
