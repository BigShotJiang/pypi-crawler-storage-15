"""Benchmark suite for jax-sklearn using ASV"""
