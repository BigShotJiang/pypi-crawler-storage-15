.. _gaussian_process_examples:

Gaussian Process for Machine Learning
-------------------------------------

Examples concerning the :mod:`xlearn.gaussian_process` module.
