Changelog
=========


[0.1.3] - December 3 2025
-------------------------

- Obsolete make.bat and clean.py files removed.



[0.1.2] - April 24, 2025
------------------------

- MotionSimulator added


[0.1.1] - April 22, 2025
------------------------

- First beta release. 

