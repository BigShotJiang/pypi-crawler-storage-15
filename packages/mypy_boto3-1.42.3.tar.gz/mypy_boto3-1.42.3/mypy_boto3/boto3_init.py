"""
boto3.__init__ stub.

Copyright 2025 Vlad Emelianov
"""

try:
    from mypy_boto3.boto3_init_gen import *
except ImportError:
    pass
