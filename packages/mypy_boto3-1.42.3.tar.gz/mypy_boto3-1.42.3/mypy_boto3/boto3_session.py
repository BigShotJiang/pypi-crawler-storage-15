"""
boto3.session stub.

Copyright 2025 Vlad Emelianov
"""

try:
    from mypy_boto3.boto3_session_gen import *
except ImportError:
    pass
