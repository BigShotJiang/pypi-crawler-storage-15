"""
mypy-boto3 main entrypoint.

Copyright 2025 Vlad Emelianov
"""
