from fastapi import FastAPI, Request
from fastapi.responses import RedirectResponse, JSONResponse
from secret_loader import get_secret
import httpx
import os


def add_central_auth(app: FastAPI):

    # Load secrets from env / cloud provider
    AUTH_INTROSPECT_URL = get_secret("AUTH_INTROSPECT_URL")
    AUTH_LOGIN_URL = get_secret("AUTH_LOGIN_URL")
    CLIENT_ID = get_secret("VERGE_CLIENT_ID")
    CLIENT_SECRET = get_secret("VERGE_CLIENT_SECRET")

    SERVICE_NAME = get_secret("SERVICE_NAME")
    SERVICE_BASE_URL = get_secret("SERVICE_BASE_URL")
    VERGE_SERVICE_SECRET = get_secret("VERGE_SERVICE_SECRET")

    # REQUIRED identifying headers for auth-service
    EXTRA_HEADERS = {
        "X-Service-Name": SERVICE_NAME,
        "X-Service-Base": SERVICE_BASE_URL,
        "X-Verge-Service-Secret": VERGE_SERVICE_SECRET,
    }

    PUBLIC_PATHS = {
        "/health",
        "/docs",
        "/openapi.json",
        "/redoc",
    }

    @app.middleware("http")
    async def central_auth(request: Request, call_next):

        path = request.url.path

        # public endpoints → skip auth
        if path in PUBLIC_PATHS:
            return await call_next(request)

        # Extract token
        token = None
        auth_header = request.headers.get("authorization")

        if auth_header and auth_header.lower().startswith("bearer "):
            token = auth_header.split(" ")[1]

        if not token:
            token = request.cookies.get("access_token")

        # No token → unauthorized or redirect
        if not token:
            if "text/html" in (request.headers.get("accept") or ""):
                return RedirectResponse(f"{AUTH_LOGIN_URL}?redirect_url={request.url}")
            return JSONResponse({"detail": "Unauthorized"}, status_code=401)

        # Validate token with auth-service
        try:
            async with httpx.AsyncClient(timeout=3) as client:
                res = await client.post(
                    AUTH_INTROSPECT_URL,
                    headers={
                        "Authorization": f"Bearer {token}",
                        "X-Client-Id": CLIENT_ID,
                        "X-Client-Secret": CLIENT_SECRET,
                        **EXTRA_HEADERS,
                    },
                )
                data = res.json()

        except Exception:
            return JSONResponse({"detail": "Auth service unreachable"}, status_code=503)

        # Token invalid
        if not data.get("active"):
            return JSONResponse({"detail": "Session expired"}, status_code=401)

        # Attach user info
        request.state.user = data.get("user", {})
        request.state.roles = data.get("roles", [])

        return await call_next(request)
