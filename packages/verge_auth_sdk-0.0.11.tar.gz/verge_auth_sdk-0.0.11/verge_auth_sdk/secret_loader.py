import os
from functools import lru_cache

VALID_PROVIDERS = {"env", "aws", "azure", "gcp", "oracle"}


@lru_cache(maxsize=128)
def get_secret(name: str) -> str:
    """
    Retrieves a secret from the configured provider.
    Supports: env, aws, azure, gcp, oracle
    """
    provider = os.getenv("SECRETS_PROVIDER", "env").strip().lower()

    # -------------------------
    # VALIDATE PROVIDER
    # -------------------------
    if provider not in VALID_PROVIDERS:
        raise ValueError(
            f"Invalid SECRETS_PROVIDER '{provider}'. "
            f"Allowed values: {', '.join(VALID_PROVIDERS)}"
        )

    # -------------------------
    # ENVIRONMENT VARIABLES
    # -------------------------
    if provider == "env":
        value = os.getenv(name)
        if value is None:
            raise KeyError(f"Missing environment variable: {name}")
        return value

    # -------------------------
    # AWS Secrets Manager
    # -------------------------
    if provider == "aws":
        try:
            import boto3
            client = boto3.client(
                "secretsmanager",
                region_name=os.getenv("AWS_REGION")
            )
            resp = client.get_secret_value(SecretId=name)
            return resp.get("SecretString") or resp["SecretBinary"].decode()
        except Exception as e:
            raise RuntimeError(f"AWS secret fetch failed for '{name}': {e}")

    # -------------------------
    # Azure Key Vault
    # -------------------------
    if provider == "azure":
        try:
            from azure.identity import DefaultAzureCredential
            from azure.keyvault.secrets import SecretClient

            vault_url = os.getenv("AZURE_KEY_VAULT_URL")
            if not vault_url:
                raise RuntimeError("AZURE_KEY_VAULT_URL is not set")

            client = SecretClient(
                vault_url=vault_url,
                credential=DefaultAzureCredential()
            )
            return client.get_secret(name).value
        except Exception as e:
            raise RuntimeError(f"Azure secret fetch failed for '{name}': {e}")

    # -------------------------
    # Google Cloud Secret Manager
    # -------------------------
    if provider == "gcp":
        try:
            from google.cloud import secretmanager

            project = os.getenv("GCP_PROJECT")
            if not project:
                raise RuntimeError(
                    "GCP_PROJECT environment variable is required")

            client = secretmanager.SecretManagerServiceClient()
            path = f"projects/{project}/secrets/{name}/versions/latest"
            resp = client.access_secret_version(name=path)
            return resp.payload.data.decode("utf-8")
        except Exception as e:
            raise RuntimeError(f"GCP secret fetch failed for '{name}': {e}")

    # -------------------------
    # Oracle Cloud Vault (OCI)
    # -------------------------
    if provider == "oracle":
        try:
            import oci

            client = oci.secrets.SecretsClient(
                config=oci.config.from_file()
            )
            secret_bundle = client.get_secret_bundle(secret_id=name).data
            base64_content = secret_bundle.secret_bundle_content.content
            return base64_content.decode()
        except Exception as e:
            raise RuntimeError(f"Oracle secret fetch failed for '{name}': {e}")

    # Should never happen
    raise RuntimeError("Unknown secret provider logic reached")
