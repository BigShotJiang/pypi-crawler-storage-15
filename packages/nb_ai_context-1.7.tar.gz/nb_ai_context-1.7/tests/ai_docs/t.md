

## 1 二级别

aaa
`````md
# 1  一级别

内容111

````python
print("hello")
````

## 1.2
嘿嘿
`````

<div >
# 1 2323
</div>
[nb_ai_context_all_docs_and_codes.md](../../markdown_gen_files_git_ignore/ai_md_files/nb_ai_context_all_docs_and_codes.md)


<project_context project_name="nb_ai_context">

    <project_summary>
        # markdown content namespace: nb_ai_context project summary
        - nb_ai_context is a powerful...
    </project_summary>[nb_ai_context_all_docs_and_codes.md](../../markdown_gen_files_git_ignore/ai_md_files/nb_ai_context_all_docs_and_codes.md)

    <core_metadata>
        ## 📋 Core Source Files Metadata
        ...
    </core_metadata>

    <project_structure>
        ## File Tree
        ```
        ├── README.md
        └── src/
        ```
        ## Included Files
        - README.md
        - src/main.py
    </project_structure>

    <repository_files>
        
        <div class="markdown-file" file_path="README.md">
            --- **start of file: README.md** ---
            # Title
            ...
            --- **end of file: README.md** ---
        </div>

        <file path="src/main.py">
            <ast_metadata>
                ### 📄 Python File Metadata...
                class AiMdGenerator...
            </ast_metadata>
            
            <content>
                --- **start of file: src/main.py** ---
                ```python
                import os
                ...
                ```
                --- **end of file: src/main.py** ---
            </content>
        </file>

    </repository_files>

</project_context>

