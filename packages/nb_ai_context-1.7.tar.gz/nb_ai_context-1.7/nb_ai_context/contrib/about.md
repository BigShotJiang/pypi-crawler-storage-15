

some contribution about nb_path