
from nb_path import NbPath
from .ai_md_generator import AiMdGenerator

from .contrib.gen_github_proj_ai_md import gen_github_proj_docs_and_codes_ai_md,gen_github_proj_all_dirs_ai_md