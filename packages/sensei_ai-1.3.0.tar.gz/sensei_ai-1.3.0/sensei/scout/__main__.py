"""Enable `python -m sensei.scout`."""

from .server import main

if __name__ == "__main__":
    main()
