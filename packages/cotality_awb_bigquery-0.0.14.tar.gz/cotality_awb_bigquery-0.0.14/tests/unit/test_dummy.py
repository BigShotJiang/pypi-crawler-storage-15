"""test_utils.py"""


def test_foo():
    """Dummy test to ensure the test suite runs."""
    assert True
