from mex.common.models.base.model import BaseModel


class MergedItem(BaseModel, extra="forbid"):
    """Base model for all merged item classes."""
