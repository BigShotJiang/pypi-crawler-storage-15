# sklearm

一个简单的 Python 包示例。

## 安装
```bash
pip install sklearm
