__version__ = "2025.5.0"  # noqa: W292
