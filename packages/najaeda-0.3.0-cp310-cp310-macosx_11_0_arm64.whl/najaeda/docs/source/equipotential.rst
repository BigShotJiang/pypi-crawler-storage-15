Equipotential Class
===================

Equipotential Overview
----------------------

The `Equipotential` class is responsible for managing equipotentials in the `najaeda` system.

Equipotential Attributes
------------------------

.. autoclass:: najaeda.netlist.Equipotential
    :members:
    :undoc-members:
    :show-inheritance: