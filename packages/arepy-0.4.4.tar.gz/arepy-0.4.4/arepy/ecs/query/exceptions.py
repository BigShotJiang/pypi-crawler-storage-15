def raise_exception(exception: Exception) -> None:
    raise exception
