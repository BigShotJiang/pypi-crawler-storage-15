"""
Geek Cafe, LLC
MIT License.  See Project Root for the license information.
"""


from geek_cafe_saas_sdk.core.models.base_model import BaseModel

class BaseUserModel(BaseModel):
    """
    The Base DB Model for models that have a user tied to them
    """
    
    # Require user_id to be set before saving
    _required_properties = ["user_id"]

    def __init__(self) -> None:
        super().__init__()                
        self.user_id: str | None = None        
    
    
    def validate_required_properties(self) -> None:
        if not self.user_id and hasattr(self, 'owner_id') and self.owner_id:
            self.user_id = self.owner_id
            
        super().validate_required_properties()
        
