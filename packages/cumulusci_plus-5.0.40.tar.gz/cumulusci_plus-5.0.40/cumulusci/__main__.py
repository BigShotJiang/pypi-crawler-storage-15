from cumulusci.cli.cci import main

main()
