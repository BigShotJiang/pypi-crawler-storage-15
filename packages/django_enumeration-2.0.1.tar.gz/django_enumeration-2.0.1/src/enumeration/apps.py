from django.apps import AppConfig


class EnumerationConfig(AppConfig):
    name = "enumeration"
    default_auto_field = "django.db.models.BigAutoField"