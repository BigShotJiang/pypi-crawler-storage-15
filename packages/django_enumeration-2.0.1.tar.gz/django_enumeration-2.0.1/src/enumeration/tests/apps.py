from django.apps import AppConfig


class TestConfig(AppConfig):
    name = "enumeration.tests"
    label = "enumeration_tests"
