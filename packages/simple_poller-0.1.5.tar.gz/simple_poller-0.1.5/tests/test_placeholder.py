def test_importable() -> None:
    import simple_poller  # type: ignore  # noqa: F401
