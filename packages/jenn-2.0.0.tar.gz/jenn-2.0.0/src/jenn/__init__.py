# Copyright (C) 2018 Steven H. Berguin
# This work is licensed under the MIT License.

from . import core, synthetic_data, utilities
from .core.model import NeuralNet
from .post_processing import (
    metrics,
    plot_actual_by_predicted,
    plot_contours,
    plot_convergence,
    plot_goodness_of_fit,
    plot_histogram,
    plot_residual_by_predicted,
    plot_sensitivity_profiles,
)

__version__ = "2.0.0"

__all__ = [
    "NeuralNet",
    "__version__",
    "core",
    "metrics",
    "plot_actual_by_predicted",
    "plot_contours",
    "plot_convergence",
    "plot_goodness_of_fit",
    "plot_histogram",
    "plot_residual_by_predicted",
    "plot_sensitivity_profiles",
    "synthetic_data",
    "utilities",
]
