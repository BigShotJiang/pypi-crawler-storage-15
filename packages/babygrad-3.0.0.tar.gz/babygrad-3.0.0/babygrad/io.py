import sys


class Scanner:
    def __init__(self):
        self.tokens = self._generate_tokens()
        self.curr = None

    def _generate_tokens(self):
        """Lazy generator to avoid reading full stdin buffer at once."""
        try:
            for line in sys.stdin:
                for token in line.split():
                    yield token
        except Exception:
            pass

    def next(self):
        try:
            return next(self.tokens)
        except StopIteration:
            return None

    def int(self):
        t = self.next()
        return int(t) if t else None
    
    def str(self):
        return self.next()

    def list_int(self):
        """Reads rest of the current line as ints."""
        # Note: This is a bit tricky with lazy loading, 
        # so for robustness we assume generic token consumption
        return int(self.next())


# Global instance for one-liner usage
_scanner = Scanner()
read_int = _scanner.int
read_str = _scanner.str

