"""Chroma client module for connection management."""

from chroma_ingestion.clients.chroma import get_chroma_client

__all__ = [
    "get_chroma_client",
]
