use pyo3::prelude::*;

#[pymodule]
mod pyrsfnfile {
    use std::io;

    use pyo3::{exceptions::PyValueError, prelude::*};

    #[pyclass(eq, eq_int)]
    #[derive(Clone, PartialEq)]
    pub enum SpecialTreatment {
        #[pyo3(name = "DEFAULT")]
        Default,
        #[pyo3(name = "NORMAL")]
        Normal,
        #[pyo3(name = "USING_NOT_ENABLED_CERT")]
        UsingNotEnabledCert,
        #[pyo3(name = "NOT_CRYPT_BROADCAST")]
        NotCryptBroadcast,
        #[pyo3(name = "NOT_CRYPT")]
        NotCrypt,
        #[pyo3(name = "NOT_COMPRESS")]
        NotCompress,
        #[pyo3(name = "NOT_COMPRESS_AND_NOT_CRYPT")]
        NotCompressAndNotCrypt,
        #[pyo3(name = "COMPRESS")]
        Compress,
        #[pyo3(name = "COMPRESS_WITHOUT_CRYPT")]
        ComrpessWithoutCrypt,
    }

    impl From<SpecialTreatment> for Option<rsfn_file::header::SpecialTreatment> {
        fn from(value: SpecialTreatment) -> Self {
            match value {
                SpecialTreatment::Default => None,
                SpecialTreatment::Normal => Some(rsfn_file::header::SpecialTreatment::Normal),
                SpecialTreatment::UsingNotEnabledCert => {
                    Some(rsfn_file::header::SpecialTreatment::UsingNotEnabledCert)
                }
                SpecialTreatment::NotCryptBroadcast => {
                    Some(rsfn_file::header::SpecialTreatment::NotCryptBroadcast)
                }
                SpecialTreatment::NotCrypt => Some(rsfn_file::header::SpecialTreatment::NotCrypt),
                SpecialTreatment::NotCompress => {
                    Some(rsfn_file::header::SpecialTreatment::NotCompress)
                }
                SpecialTreatment::NotCompressAndNotCrypt => {
                    Some(rsfn_file::header::SpecialTreatment::NotCompressAndNotCrypt)
                }
                SpecialTreatment::Compress => Some(rsfn_file::header::SpecialTreatment::Compress),
                SpecialTreatment::ComrpessWithoutCrypt => {
                    Some(rsfn_file::header::SpecialTreatment::ComrpessWithoutCrypt)
                }
            }
        }
    }

    #[pyclass(eq, eq_int)]
    #[derive(Clone, PartialEq)]
    pub enum Compressors {
        #[pyo3(name = "PLAIN")]
        Plain,
        #[pyo3(name = "GZIP")]
        Gzip,
    }

    impl From<Compressors> for rsfn_file::compress::Compressors {
        fn from(value: Compressors) -> Self {
            match value {
                Compressors::Plain => Self::Plain,
                Compressors::Gzip => Self::Gzip,
            }
        }
    }

    #[pyclass(eq, eq_int)]
    #[derive(Clone, PartialEq)]
    pub enum Encoders {
        #[pyo3(name = "PLAIN")]
        Plain,
        #[pyo3(name = "UTF16BE")]
        Utf16be,
    }

    impl From<Encoders> for rsfn_file::encode::Encoders {
        fn from(value: Encoders) -> Self {
            match value {
                Encoders::Plain => Self::Plain,
                Encoders::Utf16be => Self::Utf16be,
            }
        }
    }

    #[pyclass]
    struct EncryptParams {
        #[pyo3(get, set)]
        special_treatment: SpecialTreatment,
        #[pyo3(get, set)]
        crypt: bool,
        #[pyo3(get, set)]
        compressor: Compressors,
        #[pyo3(get, set)]
        encoder: Encoders,
        #[pyo3(get, set)]
        verify_certs: bool,
    }

    #[pymethods]
    impl EncryptParams {
        #[new]
        fn py_new() -> Self {
            Self {
                special_treatment: SpecialTreatment::Default,
                crypt: true,
                compressor: Compressors::Plain,
                encoder: Encoders::Utf16be,
                verify_certs: true,
            }
        }
    }

    impl From<&EncryptParams> for rsfn_file::EncryptParams {
        fn from(value: &EncryptParams) -> Self {
            Self {
                special_treatment: value.special_treatment.clone().into(),
                crypt: value.crypt,
                compressor: value.compressor.clone().into(),
                encoder: value.encoder.clone().into(),
                verify_certs: value.verify_certs,
            }
        }
    }

    #[pyfunction]
    fn encrypt(
        src_cert: &[u8],
        src_key: &[u8],
        dst_cert: &[u8],
        params: &EncryptParams,
        file: &[u8],
    ) -> PyResult<Vec<u8>> {
        let input: Vec<_> = file.into();
        let mut input = io::Cursor::new(input);

        let params = params.into();
        let output = rsfn_file::encrypt(src_cert, src_key, dst_cert, &params, &mut input)
            .map_err(PyValueError::new_err)?;

        Ok(output)
    }

    #[pyclass]
    struct DecryptParams {
        #[pyo3(get, set)]
        decompress: bool,
        #[pyo3(get, set)]
        decode: bool,
        #[pyo3(get, set)]
        verify_header: bool,
        #[pyo3(get, set)]
        verify_certs: bool,
        #[pyo3(get, set)]
        verify_sign: bool,
    }

    #[pymethods]
    impl DecryptParams {
        #[new]
        fn py_new() -> Self {
            Self {
                decompress: true,
                decode: true,
                verify_header: true,
                verify_certs: true,
                verify_sign: true,
            }
        }
    }

    impl From<&DecryptParams> for rsfn_file::DecryptParams {
        fn from(value: &DecryptParams) -> Self {
            Self {
                decompress: value.decompress,
                decode: value.decode,
                verify_header: value.verify_header,
                verify_certs: value.verify_certs,
                verify_sign: value.verify_sign,
            }
        }
    }

    #[pyfunction]
    fn decrypt(
        src_cert: &[u8],
        dst_cert: &[u8],
        dst_key: &[u8],
        params: &DecryptParams,
        file: &[u8],
    ) -> PyResult<Vec<u8>> {
        let input: Vec<_> = file.into();
        let mut input = io::Cursor::new(input);

        let params = params.into();
        let output = rsfn_file::decrypt(src_cert, dst_cert, dst_key, &params, &mut input)
            .map_err(PyValueError::new_err)?;

        Ok(output)
    }
}
