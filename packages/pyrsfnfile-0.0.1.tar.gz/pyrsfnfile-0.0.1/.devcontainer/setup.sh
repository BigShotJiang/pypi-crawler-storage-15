#!/bin/bash

set -xe

# Config maturin
pipx install maturin==1.10.2 patchelf==0.17.2.4

# Completions
pipx install argcomplete
mkdir -p ~/.local/share/bash-completion/completions
echo '. <(register-python-argcomplete pipx)' > ~/.local/share/bash-completion/completions/pipx
echo '. <(maturin completions bash)' > ~/.local/share/bash-completion/completions/maturin

# Config project
make init
