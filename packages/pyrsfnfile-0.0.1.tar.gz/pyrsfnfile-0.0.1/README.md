# py RSFN File

Wrapper da biblioteca para criptografia de arquivos que trafegam na RSFN.

Exemplo de uso:

```python
from pathlib import Path

import pyrsfnfile

part_a_cert = Path('part-a.crt').read_bytes()
part_a_key = Path('part-a.key').read_bytes()
part_b_cert = Path('part-b.crt').read_bytes()
part_b_key = Path('part-b.key').read_bytes()

msg = b'Test 123'

encrypt_params = pyrsfnfile.EncryptParams()
encrypted_msg = pyrsfnfile.encrypt(part_a_cert, part_a_key, part_b_cert, encrypt_params, msg)
print(encrypted_msg)

print()

decrypt_params = pyrsfnfile.DecryptParams()
decrypted_msg = pyrsfnfile.decrypt(part_a_cert, part_b_cert, part_b_key, decrypt_params, encrypted_msg)
print(decrypted_msg)
```
