# Generated file
import collections

BuildInfo = collections.namedtuple(
    'BuildInfo',
    ['version', 'built_at', 'sha', 'branch', 'tag'],
)

BUILD_INFO = BuildInfo(
    version='v1.0.0~03a5fdb',
    built_at='2025-12-05 13:35:01Z',
    sha='03a5fdb719eaed7a21cc8466c48f4fd572bfe128',
    branch='HEAD',
    tag='v1.0.0',
)
