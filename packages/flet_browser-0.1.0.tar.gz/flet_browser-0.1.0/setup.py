from setuptools import setup, find_packages

setup(
    name="flet_browser",
    version="0.1.0",
    author="ACH--AOG",
    description="A Flet button to open secure webview windows",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    install_requires=[
        "flet",
        "pywebview",
    ],
)