import flet as ft
import webview
import multiprocessing
import threading
import sys
import os

def start_webview_process(url, title):
    webview.create_window(
        title=title, 
        url=url,
    )
    webview.start()


class BrowserButton(ft.ElevatedButton):
    def __init__(self, text, url, hide_app=False, window_title="Browser", **kwargs):
        
        self.target_url = url
        self.hide_app = hide_app
        self.window_title = window_title
        
        super().__init__(text=text, on_click=self.launch_browser, **kwargs)

    def launch_browser(self, e):
        if self.hide_app:
            self.page.window.visible = False
            self.page.update()

        p = multiprocessing.Process(
            target=start_webview_process, 
            args=(self.target_url, self.window_title)
        )
        p.start()

        def monitor_process():
            p.join()
            if self.hide_app:
                self.page.window.visible = True
                self.page.update()

        threading.Thread(target=monitor_process, daemon=True).start()

def app(target, **kwargs):
    
    if __name__ != '__main__':
        
        pass

    multiprocessing.freeze_support()
    
    ft.app(target=target, **kwargs)