# لاحظ أننا نصدر app أيضاً
from .browser import BrowserButton, app

__all__ = ["BrowserButton", "app"]