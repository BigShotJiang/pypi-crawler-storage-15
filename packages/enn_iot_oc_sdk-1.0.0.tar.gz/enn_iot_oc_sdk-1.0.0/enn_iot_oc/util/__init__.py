"""
Mock utility functions for IoC Data SDK
"""

from .string_util import parse_object, parse_array

__all__ = ["parse_object", "parse_array"]