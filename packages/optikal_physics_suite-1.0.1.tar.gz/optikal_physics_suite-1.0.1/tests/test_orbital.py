"""
Unit tests for optikal_physics_suite.orbital module.

Tests space environment simulation, orbital mechanics, and radiation effects.
"""

import pytest

from optikal_physics_suite.orbital.space_environment import (
    OrbitType,
    SpaceLinkParameters,
    VacuumPropagation,
    SpaceRadiationEffects,
    SpaceThermalEnvironment,
    SpaceEnvironment,
)


class TestOrbitType:
    """Test cases for OrbitType enumeration."""

    def test_orbit_types_exist(self):
        """Test that all orbit types are defined."""
        assert hasattr(OrbitType, "LEO")
        assert hasattr(OrbitType, "MEO")
        assert hasattr(OrbitType, "GEO")
        assert hasattr(OrbitType, "HEO")

    def test_orbit_type_values(self):
        """Test orbit type enumeration values."""
        assert OrbitType.LEO.name == "LEO"
        assert OrbitType.GEO.name == "GEO"


class TestSpaceEnvironment:
    """Test cases for SpaceEnvironment class."""

    def test_leo_environment_creation(self):
        """Test creating LEO environment."""
        env = SpaceEnvironment(OrbitType.LEO)
        assert env.orbit_type == OrbitType.LEO

    def test_meo_environment_creation(self):
        """Test creating MEO environment."""
        env = SpaceEnvironment(OrbitType.MEO)
        assert env.orbit_type == OrbitType.MEO

    def test_geo_environment_creation(self):
        """Test creating GEO environment."""
        env = SpaceEnvironment(OrbitType.GEO)
        assert env.orbit_type == OrbitType.GEO

    def test_environment_has_components(self):
        """Test that environment has required components."""
        env = SpaceEnvironment(OrbitType.LEO)

        # Check required attributes exist
        assert hasattr(env, "vacuum_prop")
        assert hasattr(env, "radiation")
        assert hasattr(env, "thermal")

    def test_environment_summary(self):
        """Test environment summary generation."""
        env = SpaceEnvironment(OrbitType.LEO)
        summary = env.get_environment_summary()

        assert summary is not None
        assert isinstance(summary, dict)

    def test_link_budget_calculation(self):
        """Test link budget calculation."""
        env = SpaceEnvironment(OrbitType.LEO)

        # Calculate link budget for typical parameters
        # Use SpaceLinkParameters with correct API
        params = SpaceLinkParameters(
            wavelength_nm=1550, tx_power_mw=500, tx_aperture_cm=30, rx_aperture_cm=50
        )
        # API is calculate_link_budget(distance_km, link_params)
        budget = env.calculate_link_budget(distance_km=500, link_params=params)

        assert budget is not None
        assert isinstance(budget, dict)
        assert "link_margin_db" in budget


class TestVacuumPropagation:
    """Test cases for VacuumPropagation class."""

    def test_vacuum_propagation_creation(self):
        """Test creating vacuum propagation model."""
        prop = VacuumPropagation()
        assert prop is not None

    def test_no_atmospheric_loss(self):
        """Test that vacuum has no atmospheric absorption."""
        prop = VacuumPropagation()

        # In vacuum, there should be no molecular absorption
        # Only geometric spreading applies
        if hasattr(prop, "calculate_atmospheric_loss"):
            loss = prop.calculate_atmospheric_loss(distance_km=1000)
            assert loss == 0  # No atmosphere = no atmospheric loss


class TestSpaceRadiationEffects:
    """Test cases for SpaceRadiationEffects class."""

    def test_radiation_effects_creation(self):
        """Test creating radiation effects model."""
        radiation = SpaceRadiationEffects()
        assert radiation is not None

    def test_radiation_environment_calculation(self):
        """Test radiation environment calculation at different altitudes."""
        radiation = SpaceRadiationEffects()

        # LEO altitude (below Van Allen belts)
        leo_env = radiation.calculate_radiation_environment(altitude_km=500)
        assert "total_dose_rad" in leo_env
        assert leo_env["gcr_flux"] > 0

        # MEO altitude (in Van Allen belts)
        meo_env = radiation.calculate_radiation_environment(altitude_km=3000)
        assert meo_env["total_dose_rad"] > leo_env["total_dose_rad"]

    def test_ber_penalty_calculation(self):
        """Test BER penalty from radiation effects."""
        radiation = SpaceRadiationEffects()

        # Calculate penalty at LEO
        penalty = radiation.calculate_ber_penalty(altitude_km=500)
        assert penalty >= 0  # Penalty should be non-negative


class TestSpaceThermalEnvironment:
    """Test cases for SpaceThermalEnvironment class."""

    def test_thermal_environment_creation(self):
        """Test creating thermal environment model."""
        thermal = SpaceThermalEnvironment()
        assert thermal is not None

    def test_thermal_has_properties(self):
        """Test that thermal model has expected properties."""
        thermal = SpaceThermalEnvironment()

        # Should have thermal coefficients
        assert hasattr(thermal, "vcsel_wavelength_coeff")
        assert hasattr(thermal, "thermal_expansion_coeff")
        assert thermal.vcsel_wavelength_coeff > 0

    def test_wavelength_shift_calculation(self):
        """Test wavelength shift due to temperature."""
        thermal = SpaceThermalEnvironment()

        # 1550nm at +100°C should shift
        new_wavelength = thermal.calculate_wavelength_shift(1550, temp_delta_c=100)
        assert new_wavelength > 1550  # Should increase with heating


class TestSpaceLinkParameters:
    """Test cases for SpaceLinkParameters dataclass."""

    def test_link_parameters_creation(self):
        """Test creating space link parameters."""
        params = SpaceLinkParameters(
            wavelength_nm=1550,
            tx_power_mw=500,
            tx_aperture_cm=30,
            rx_aperture_cm=50,
            beam_divergence_urad=10,
        )

        assert params.wavelength_nm == 1550
        assert params.tx_power_mw == 500
        assert params.tx_aperture_cm == 30

    def test_link_parameters_defaults(self):
        """Test that default parameters have sensible values."""
        params = SpaceLinkParameters()

        # Check default values
        assert params.wavelength_nm == 1550  # Telecom wavelength
        assert params.tx_power_mw == 500
        assert params.tx_aperture_cm == 30
        assert params.rx_aperture_cm == 50
        assert params.data_rate_gbps == 10


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
