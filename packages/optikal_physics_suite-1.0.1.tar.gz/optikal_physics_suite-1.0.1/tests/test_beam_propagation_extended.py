"""
Extended unit tests for optikal_physics_suite.optical.beam_propagation module.

Tests advanced beam propagation features including beam propagator functionality,
edge cases for IEC 60825-1 safety validation.
"""

import pytest
import numpy as np

from optikal_physics_suite.optical.beam_propagation import (
    GaussianBeam,
    BeamPropagator,
    calculate_beam_divergence,
    calculate_rayleigh_range,
)


class TestBeamPropagatorSingle:
    """Test cases for BeamPropagator with single beams."""

    def test_propagator_cpu_mode(self):
        """Test propagator initialization in CPU mode."""
        propagator = BeamPropagator(use_gpu=False)
        assert propagator.use_gpu is False

    def test_propagate_beam_near_field(self):
        """Test beam propagation in near field (< Rayleigh range)."""
        beam = GaussianBeam(wavelength=1550, power=0.39, waist=1.0)
        propagator = BeamPropagator(use_gpu=False)

        # Propagate to 1 meter (near field for 1mm waist)
        result = propagator.propagate_beam(beam, distance=1.0, num_points=100)

        assert "distance_m" in result
        assert result["distance_m"] == 1.0
        assert "radius_mm" in result
        assert "divergence_mrad" in result
        assert "radial_positions_mm" in result
        assert "intensity_profile_Wm2" in result
        assert "peak_intensity_Wm2" in result

        # Check that intensity profile has correct shape
        assert len(result["intensity_profile_Wm2"]) == 100

    def test_propagate_beam_far_field(self):
        """Test beam propagation in far field (>> Rayleigh range)."""
        beam = GaussianBeam(wavelength=1550, power=0.39, waist=1.0)
        propagator = BeamPropagator(use_gpu=False)

        # Propagate to 1 km (far field)
        result = propagator.propagate_beam(beam, distance=1000.0, num_points=100)

        assert result["distance_m"] == 1000.0
        # In far field, beam should be much larger than waist
        assert result["radius_mm"] > beam.waist * 10

    def test_propagate_beam_different_resolutions(self):
        """Test beam propagation with different grid resolutions."""
        beam = GaussianBeam(wavelength=1550, power=0.39, waist=1.0)
        propagator = BeamPropagator(use_gpu=False)

        # Low resolution
        result_low = propagator.propagate_beam(beam, distance=100.0, num_points=50)
        assert len(result_low["intensity_profile_Wm2"]) == 50

        # High resolution
        result_high = propagator.propagate_beam(beam, distance=100.0, num_points=200)
        assert len(result_high["intensity_profile_Wm2"]) == 200

    def test_propagate_beam_peak_intensity_decreases(self):
        """Test that peak intensity decreases with distance."""
        beam = GaussianBeam(wavelength=1550, power=0.39, waist=1.0)
        propagator = BeamPropagator(use_gpu=False)

        result_10m = propagator.propagate_beam(beam, distance=10.0)
        result_100m = propagator.propagate_beam(beam, distance=100.0)

        assert result_100m["peak_intensity_Wm2"] < result_10m["peak_intensity_Wm2"]


class TestGaussianBeamEdgeCases:
    """Test edge cases for GaussianBeam class."""

    def test_very_small_wavelength(self):
        """Test beam with very small wavelength (UV range)."""
        beam = GaussianBeam(wavelength=200, power=0.1, waist=1.0)  # 200nm UV
        assert beam.wavelength == 200

        # Divergence should be smaller for shorter wavelength
        divergence = beam.calculate_divergence()
        assert divergence > 0

    def test_very_large_wavelength(self):
        """Test beam with very large wavelength (mid-IR)."""
        beam = GaussianBeam(wavelength=10000, power=0.1, waist=1.0)  # 10 microns
        assert beam.wavelength == 10000

        # Divergence should be larger for longer wavelength
        divergence = beam.calculate_divergence()
        assert divergence > 0

    def test_very_small_waist(self):
        """Test beam with very small waist."""
        beam = GaussianBeam(wavelength=1550, power=0.1, waist=0.01)  # 10 micron waist
        assert beam.waist == 0.01

        # Small waist should give large divergence
        divergence = beam.calculate_divergence()
        assert divergence > 1.0  # Should be > 1 mrad

    def test_very_large_waist(self):
        """Test beam with very large waist."""
        beam = GaussianBeam(wavelength=1550, power=0.1, waist=100.0)  # 100mm waist
        assert beam.waist == 100.0

        # Large waist should give small divergence
        divergence = beam.calculate_divergence()
        assert divergence < 0.01  # Should be < 0.01 mrad

    def test_class1_safe_850nm_low_power(self):
        """Test Class 1 safety for 850nm at low power."""
        beam = GaussianBeam(wavelength=850, power=0.5, waist=1.0)
        assert beam.is_class1_safe()  # 0.5 mW < 0.70 mW limit

    def test_class1_safe_850nm_high_power(self):
        """Test Class 1 safety for 850nm at high power."""
        beam = GaussianBeam(wavelength=850, power=0.8, waist=1.0)
        assert not beam.is_class1_safe()  # 0.8 mW > 0.70 mW limit

    def test_class1_safe_1550nm_low_power(self):
        """Test Class 1 safety for 1550nm at low power."""
        beam = GaussianBeam(wavelength=1550, power=0.35, waist=1.0)
        assert beam.is_class1_safe()  # 0.35 mW < 0.39 mW limit

    def test_class1_safe_1550nm_high_power(self):
        """Test Class 1 safety for 1550nm at high power."""
        beam = GaussianBeam(wavelength=1550, power=0.5, waist=1.0)
        assert not beam.is_class1_safe()  # 0.5 mW > 0.39 mW limit

    def test_class1_warning_for_1550nm_high_power(self):
        """Test that high power triggers safety warning."""
        with pytest.warns(UserWarning, match="exceeds IEC 60825-1 Class 1 limit"):
            beam = GaussianBeam(wavelength=1550, power=1.0, waist=1.0)
            assert beam.power == 1.0

    def test_beam_to_dict(self):
        """Test beam parameter export to dictionary."""
        beam = GaussianBeam(wavelength=1550, power=0.39, waist=1.0)
        beam_dict = beam.to_dict()

        assert "wavelength_nm" in beam_dict
        assert beam_dict["wavelength_nm"] == 1550
        assert "power_mw" in beam_dict
        assert beam_dict["power_mw"] == 0.39
        assert "waist_mm" in beam_dict
        assert beam_dict["waist_mm"] == 1.0
        assert "position" in beam_dict
        assert "divergence_mrad" in beam_dict
        assert "rayleigh_range_m" in beam_dict
        assert "class1_safe" in beam_dict

    def test_beam_intensity_on_axis(self):
        """Test beam intensity on axis (r=0)."""
        beam = GaussianBeam(wavelength=1550, power=1.0, waist=1.0)
        intensity_on_axis = beam.intensity_at_distance(distance=10.0, r=0)

        assert intensity_on_axis > 0

    def test_beam_intensity_off_axis(self):
        """Test beam intensity off axis."""
        beam = GaussianBeam(wavelength=1550, power=1.0, waist=1.0)
        intensity_on_axis = beam.intensity_at_distance(distance=10.0, r=0)
        intensity_off_axis = beam.intensity_at_distance(distance=10.0, r=5.0)  # 5mm off

        # Off-axis intensity should be less than on-axis
        assert intensity_off_axis < intensity_on_axis

    def test_beam_intensity_far_off_axis(self):
        """Test beam intensity far off axis (Gaussian tail)."""
        beam = GaussianBeam(wavelength=1550, power=1.0, waist=1.0)
        intensity_far_off = beam.intensity_at_distance(distance=10.0, r=50.0)  # 50mm off

        # Should be very small (Gaussian tail)
        assert intensity_far_off < 1.0  # W/m^2


class TestUtilityFunctions:
    """Test standalone utility functions."""

    def test_calculate_beam_divergence_850nm(self):
        """Test divergence calculation for 850nm beam."""
        divergence = calculate_beam_divergence(wavelength=850, waist=1.0)
        assert divergence > 0
        assert divergence < 1.0  # Should be < 1 mrad for 1mm waist

    def test_calculate_beam_divergence_1550nm(self):
        """Test divergence calculation for 1550nm beam."""
        divergence = calculate_beam_divergence(wavelength=1550, waist=1.0)
        assert divergence > 0

        # 1550nm should have larger divergence than 850nm for same waist
        divergence_850 = calculate_beam_divergence(wavelength=850, waist=1.0)
        assert divergence > divergence_850

    def test_calculate_rayleigh_range_850nm(self):
        """Test Rayleigh range calculation for 850nm beam."""
        z_r = calculate_rayleigh_range(wavelength=850, waist=1.0)
        assert z_r > 0
        assert z_r < 10  # Should be a few meters for 1mm waist

    def test_calculate_rayleigh_range_1550nm(self):
        """Test Rayleigh range calculation for 1550nm beam."""
        z_r = calculate_rayleigh_range(wavelength=1550, waist=1.0)
        assert z_r > 0

        # 1550nm should have shorter Rayleigh range than 850nm
        z_r_850 = calculate_rayleigh_range(wavelength=850, waist=1.0)
        assert z_r < z_r_850

    def test_rayleigh_range_scales_with_waist_squared(self):
        """Test that Rayleigh range scales with waist squared."""
        z_r_1mm = calculate_rayleigh_range(wavelength=1550, waist=1.0)
        z_r_2mm = calculate_rayleigh_range(wavelength=1550, waist=2.0)

        # Doubling waist should quadruple Rayleigh range
        ratio = z_r_2mm / z_r_1mm
        assert abs(ratio - 4.0) < 0.01


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
