"""
Extended unit tests for optikal_physics_suite.optical.atmospheric_constants module.

Tests comprehensive atmospheric propagation constants including fog categories,
attenuation mappings, visibility relationships, and GhostGrid-specific constants.

This test file provides extensive coverage for:
- All FogCategory enumeration values
- ATTENUATION_DB_PER_KM dictionary completeness and correctness
- VISIBILITY_KM dictionary completeness and correctness
- Relationship between fog density and attenuation
- Edge cases for visibility calculations
- TriBandCharacteristics validation
- LinkStateModel constants
- TopologyConstraints validation
- SpatialWeatherModel parameters
"""

import pytest

from optikal_physics_suite.optical.atmospheric_constants import (
    FogCategory,
    ATTENUATION_DB_PER_KM,
    VISIBILITY_KM,
    TriBandCharacteristics,
    LinkStateModel,
    TopologyConstraints,
    SpatialWeatherModel,
    TRI_BAND_IS_FOR_CAPACITY,
    TRI_BAND_NOT_WEATHER_DIVERSITY,
    LINK_STATE_ACTIVE,
    LINK_STATE_WARM_STANDBY,
    MAX_ACTIVE_LINKS,
    MIN_NODES_K3,
    MIN_DEGREE,
)


class TestFogCategoryEnum:
    """Test cases for FogCategory enumeration."""

    def test_all_fog_categories_defined(self):
        """Test that all expected fog categories are defined."""
        expected_categories = [
            "CLEAR",
            "HAZE",
            "LIGHT_FOG",
            "MODERATE_FOG",
            "HEAVY_FOG",
            "DENSE_FOG",
        ]

        for category in expected_categories:
            assert hasattr(FogCategory, category), f"Missing category: {category}"

    def test_fog_category_values(self):
        """Test fog category enumeration values."""
        assert FogCategory.CLEAR.value == "clear"
        assert FogCategory.HAZE.value == "haze"
        assert FogCategory.LIGHT_FOG.value == "light_fog"
        assert FogCategory.MODERATE_FOG.value == "moderate_fog"
        assert FogCategory.HEAVY_FOG.value == "heavy_fog"
        assert FogCategory.DENSE_FOG.value == "dense_fog"

    def test_fog_category_count(self):
        """Test that we have exactly 6 fog categories."""
        categories = list(FogCategory)
        assert len(categories) == 6


class TestAttenuationDictionary:
    """Test cases for ATTENUATION_DB_PER_KM dictionary."""

    def test_attenuation_all_categories_present(self):
        """Test that all fog categories have attenuation values."""
        for category in FogCategory:
            assert (
                category in ATTENUATION_DB_PER_KM
            ), f"Missing attenuation for {category.name}"

    def test_attenuation_values_positive(self):
        """Test that all attenuation values are positive."""
        for category, attenuation in ATTENUATION_DB_PER_KM.items():
            assert attenuation > 0, f"Attenuation for {category.name} should be positive"

    def test_attenuation_increases_with_fog_density(self):
        """Test that attenuation increases with fog density."""
        assert ATTENUATION_DB_PER_KM[FogCategory.CLEAR] < ATTENUATION_DB_PER_KM[FogCategory.HAZE]
        assert ATTENUATION_DB_PER_KM[FogCategory.HAZE] < ATTENUATION_DB_PER_KM[
            FogCategory.LIGHT_FOG
        ]
        assert ATTENUATION_DB_PER_KM[FogCategory.LIGHT_FOG] < ATTENUATION_DB_PER_KM[
            FogCategory.MODERATE_FOG
        ]
        assert ATTENUATION_DB_PER_KM[FogCategory.MODERATE_FOG] < ATTENUATION_DB_PER_KM[
            FogCategory.HEAVY_FOG
        ]
        assert ATTENUATION_DB_PER_KM[FogCategory.HEAVY_FOG] < ATTENUATION_DB_PER_KM[
            FogCategory.DENSE_FOG
        ]

    def test_attenuation_clear_conditions(self):
        """Test attenuation value for clear conditions."""
        clear_attenuation = ATTENUATION_DB_PER_KM[FogCategory.CLEAR]
        assert clear_attenuation == 0.2, "Clear conditions should have 0.2 dB/km attenuation"

    def test_attenuation_haze_conditions(self):
        """Test attenuation value for haze conditions."""
        haze_attenuation = ATTENUATION_DB_PER_KM[FogCategory.HAZE]
        assert haze_attenuation == 3.0, "Haze should have 3.0 dB/km attenuation"

    def test_attenuation_light_fog(self):
        """Test attenuation value for light fog."""
        light_fog_attenuation = ATTENUATION_DB_PER_KM[FogCategory.LIGHT_FOG]
        assert light_fog_attenuation == 30.0, "Light fog should have 30.0 dB/km attenuation"

    def test_attenuation_moderate_fog(self):
        """Test attenuation value for moderate fog."""
        moderate_fog_attenuation = ATTENUATION_DB_PER_KM[FogCategory.MODERATE_FOG]
        assert (
            moderate_fog_attenuation == 100.0
        ), "Moderate fog should have 100.0 dB/km attenuation"

    def test_attenuation_heavy_fog(self):
        """Test attenuation value for heavy fog."""
        heavy_fog_attenuation = ATTENUATION_DB_PER_KM[FogCategory.HEAVY_FOG]
        assert heavy_fog_attenuation == 200.0, "Heavy fog should have 200.0 dB/km attenuation"

    def test_attenuation_dense_fog(self):
        """Test attenuation value for dense fog (link failure)."""
        dense_fog_attenuation = ATTENUATION_DB_PER_KM[FogCategory.DENSE_FOG]
        assert dense_fog_attenuation == 350.0, "Dense fog should have 350.0 dB/km attenuation"


class TestVisibilityDictionary:
    """Test cases for VISIBILITY_KM dictionary."""

    def test_visibility_all_categories_present(self):
        """Test that all fog categories have visibility values."""
        for category in FogCategory:
            assert category in VISIBILITY_KM, f"Missing visibility for {category.name}"

    def test_visibility_values_positive(self):
        """Test that all visibility values are positive."""
        for category, visibility in VISIBILITY_KM.items():
            assert visibility > 0, f"Visibility for {category.name} should be positive"

    def test_visibility_decreases_with_fog_density(self):
        """Test that visibility decreases with fog density."""
        assert VISIBILITY_KM[FogCategory.CLEAR] > VISIBILITY_KM[FogCategory.HAZE]
        assert VISIBILITY_KM[FogCategory.HAZE] > VISIBILITY_KM[FogCategory.LIGHT_FOG]
        assert VISIBILITY_KM[FogCategory.LIGHT_FOG] > VISIBILITY_KM[FogCategory.MODERATE_FOG]
        assert VISIBILITY_KM[FogCategory.MODERATE_FOG] > VISIBILITY_KM[FogCategory.HEAVY_FOG]
        assert VISIBILITY_KM[FogCategory.HEAVY_FOG] > VISIBILITY_KM[FogCategory.DENSE_FOG]

    def test_visibility_clear_conditions(self):
        """Test visibility value for clear conditions."""
        clear_visibility = VISIBILITY_KM[FogCategory.CLEAR]
        assert clear_visibility == 50.0, "Clear conditions should have 50 km visibility"

    def test_visibility_haze_conditions(self):
        """Test visibility value for haze conditions."""
        haze_visibility = VISIBILITY_KM[FogCategory.HAZE]
        assert haze_visibility == 20.0, "Haze should have 20 km visibility"

    def test_visibility_light_fog(self):
        """Test visibility value for light fog."""
        light_fog_visibility = VISIBILITY_KM[FogCategory.LIGHT_FOG]
        assert light_fog_visibility == 5.0, "Light fog should have 5 km visibility"

    def test_visibility_moderate_fog(self):
        """Test visibility value for moderate fog."""
        moderate_fog_visibility = VISIBILITY_KM[FogCategory.MODERATE_FOG]
        assert moderate_fog_visibility == 1.0, "Moderate fog should have 1 km visibility"

    def test_visibility_heavy_fog(self):
        """Test visibility value for heavy fog."""
        heavy_fog_visibility = VISIBILITY_KM[FogCategory.HEAVY_FOG]
        assert heavy_fog_visibility == 0.3, "Heavy fog should have 0.3 km visibility"

    def test_visibility_dense_fog(self):
        """Test visibility value for dense fog."""
        dense_fog_visibility = VISIBILITY_KM[FogCategory.DENSE_FOG]
        assert dense_fog_visibility == 0.1, "Dense fog should have 0.1 km visibility"


class TestAttenuationVisibilityRelationship:
    """Test relationships between attenuation and visibility."""

    def test_inverse_relationship(self):
        """Test that high attenuation corresponds to low visibility."""
        for category in FogCategory:
            attenuation = ATTENUATION_DB_PER_KM[category]
            visibility = VISIBILITY_KM[category]

            # Product should decrease as conditions worsen
            # (higher attenuation * lower visibility = smaller product)
            if category != FogCategory.CLEAR:
                clear_product = (
                    ATTENUATION_DB_PER_KM[FogCategory.CLEAR] * VISIBILITY_KM[FogCategory.CLEAR]
                )
                current_product = attenuation * visibility

                # As conditions worsen, this relationship changes significantly
                # Just verify that the relationship exists
                assert attenuation > 0 and visibility > 0

    def test_extreme_fog_high_attenuation_low_visibility(self):
        """Test that extreme fog has both high attenuation and low visibility."""
        dense_attenuation = ATTENUATION_DB_PER_KM[FogCategory.DENSE_FOG]
        dense_visibility = VISIBILITY_KM[FogCategory.DENSE_FOG]

        assert dense_attenuation > 300  # Very high attenuation
        assert dense_visibility < 0.2  # Very low visibility

    def test_clear_conditions_low_attenuation_high_visibility(self):
        """Test that clear conditions have low attenuation and high visibility."""
        clear_attenuation = ATTENUATION_DB_PER_KM[FogCategory.CLEAR]
        clear_visibility = VISIBILITY_KM[FogCategory.CLEAR]

        assert clear_attenuation < 1.0  # Very low attenuation
        assert clear_visibility > 40  # Very high visibility


class TestTriBandCharacteristics:
    """Test cases for TriBandCharacteristics dataclass."""

    def test_wavelengths_defined(self):
        """Test that tri-band wavelengths are defined."""
        wavelengths = TriBandCharacteristics.WAVELENGTHS_NM
        assert wavelengths == (1490, 1550, 1625)

    def test_purpose_wdm_capacity(self):
        """Test that WDM capacity is the primary purpose."""
        assert TriBandCharacteristics.PURPOSE_WDM_CAPACITY is True

    def test_purpose_channel_separation(self):
        """Test that channel separation is a purpose."""
        assert TriBandCharacteristics.PURPOSE_CHANNEL_SEPARATION is True

    def test_purpose_not_weather_diversity(self):
        """Test that weather diversity is NOT a purpose (corrected misconception)."""
        assert TriBandCharacteristics.PURPOSE_WEATHER_DIVERSITY is False

    def test_atmospheric_window(self):
        """Test atmospheric window definition."""
        window = TriBandCharacteristics.ATMOSPHERIC_WINDOW
        assert "C-band" in window

    def test_fog_affects_all_similarly(self):
        """Test that fog affects all wavelengths similarly."""
        assert TriBandCharacteristics.FOG_AFFECTS_ALL_SIMILARLY is True

    def test_weather_resilience_source(self):
        """Test that weather resilience comes from mesh path diversity."""
        resilience = TriBandCharacteristics.WEATHER_RESILIENCE_SOURCE
        assert "MESH PATH DIVERSITY" in resilience

    def test_convenience_constants_tri_band(self):
        """Test tri-band convenience constants."""
        assert TRI_BAND_IS_FOR_CAPACITY is True
        assert TRI_BAND_NOT_WEATHER_DIVERSITY is True


class TestLinkStateModel:
    """Test cases for LinkStateModel dataclass."""

    def test_link_states_defined(self):
        """Test that all link states are defined."""
        assert LinkStateModel.STATE_ACTIVE == "active"
        assert LinkStateModel.STATE_WARM_STANDBY == "warm"
        assert LinkStateModel.STATE_FAILED == "failed"
        assert LinkStateModel.STATE_ACQUIRING == "acquiring"

    def test_max_active_links_per_node(self):
        """Test maximum active links per node."""
        assert LinkStateModel.MAX_ACTIVE_LINKS_PER_NODE == 2

    def test_warm_standby_links(self):
        """Test minimum warm standby links."""
        assert LinkStateModel.WARM_STANDBY_LINKS == 1

    def test_standby_promotion_timing(self):
        """Test standby to active promotion timing."""
        assert LinkStateModel.STANDBY_TO_ACTIVE_MS == 500.0

    def test_convenience_constants_link_state(self):
        """Test link state convenience constants."""
        assert LINK_STATE_ACTIVE == LinkStateModel.STATE_ACTIVE
        assert LINK_STATE_WARM_STANDBY == LinkStateModel.STATE_WARM_STANDBY
        assert MAX_ACTIVE_LINKS == LinkStateModel.MAX_ACTIVE_LINKS_PER_NODE


class TestTopologyConstraints:
    """Test cases for TopologyConstraints dataclass."""

    def test_minimum_nodes(self):
        """Test minimum number of nodes for K3 topology."""
        assert TopologyConstraints.MIN_NODES == 3

    def test_minimum_degree_per_node(self):
        """Test minimum degree per node."""
        assert TopologyConstraints.MIN_DEGREE_PER_NODE == 2

    def test_required_edge_connectivity(self):
        """Test required edge connectivity."""
        assert TopologyConstraints.REQUIRED_EDGE_CONNECTIVITY == 2

    def test_survives_single_node_failure(self):
        """Test that topology survives single node failure."""
        assert TopologyConstraints.SURVIVES_SINGLE_NODE_FAILURE is True

    def test_survives_single_link_failure(self):
        """Test that topology survives single link failure."""
        assert TopologyConstraints.SURVIVES_SINGLE_LINK_FAILURE is True

    def test_convenience_constants_topology(self):
        """Test topology convenience constants."""
        assert MIN_NODES_K3 == TopologyConstraints.MIN_NODES
        assert MIN_DEGREE == TopologyConstraints.MIN_DEGREE_PER_NODE


class TestSpatialWeatherModel:
    """Test cases for SpatialWeatherModel dataclass."""

    def test_fog_coherence_length(self):
        """Test fog coherence length parameter."""
        assert SpatialWeatherModel.FOG_COHERENCE_LENGTH_M == 100.0

    def test_turbulence_coherence(self):
        """Test atmospheric turbulence coherence length."""
        assert SpatialWeatherModel.TURBULENCE_COHERENCE_MM == 20.0

    def test_spatial_diversity_enabled(self):
        """Test that spatial diversity is enabled."""
        assert SpatialWeatherModel.SPATIAL_DIVERSITY_ENABLED is True

    def test_routing_around_fog_cells(self):
        """Test that routing around fog cells is enabled."""
        assert SpatialWeatherModel.ROUTING_AROUND_FOG_CELLS is True

    def test_model_type(self):
        """Test spatial weather model type."""
        model_type = SpatialWeatherModel.MODEL_TYPE
        assert "Spatially variable" in model_type


class TestDataclassInstantiation:
    """Test that all dataclasses can be instantiated."""

    def test_tri_band_characteristics_instantiation(self):
        """Test TriBandCharacteristics can be instantiated."""
        tri_band = TriBandCharacteristics()
        assert tri_band.WAVELENGTHS_NM == (1490, 1550, 1625)

    def test_link_state_model_instantiation(self):
        """Test LinkStateModel can be instantiated."""
        link_state = LinkStateModel()
        assert link_state.STATE_ACTIVE == "active"

    def test_topology_constraints_instantiation(self):
        """Test TopologyConstraints can be instantiated."""
        topology = TopologyConstraints()
        assert topology.MIN_NODES == 3

    def test_spatial_weather_model_instantiation(self):
        """Test SpatialWeatherModel can be instantiated."""
        weather = SpatialWeatherModel()
        assert weather.FOG_COHERENCE_LENGTH_M == 100.0


class TestConsistencyValidation:
    """Test consistency between related constants."""

    def test_fog_categories_count_matches_dictionaries(self):
        """Test that fog category count matches dictionary entries."""
        num_categories = len(list(FogCategory))
        num_attenuation_entries = len(ATTENUATION_DB_PER_KM)
        num_visibility_entries = len(VISIBILITY_KM)

        assert num_categories == num_attenuation_entries
        assert num_categories == num_visibility_entries

    def test_max_active_links_reasonable(self):
        """Test that max active links per node is reasonable for mesh."""
        # Should be >= 2 for 2-edge-connected topology
        assert LinkStateModel.MAX_ACTIVE_LINKS_PER_NODE >= TopologyConstraints.MIN_DEGREE_PER_NODE


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
