"""
Unit tests for optikal_physics_suite.optical module.

Tests Gaussian beam propagation, atmospheric constants, and multi-beam arrays.
"""

import pytest
import numpy as np

from optikal_physics_suite.optical.beam_propagation import (
    GaussianBeam,
    calculate_beam_divergence,
    calculate_rayleigh_range,
)
from optikal_physics_suite.optical.atmospheric_constants import (
    FogCategory,
    ATTENUATION_DB_PER_KM,
    VISIBILITY_KM,
)


class TestGaussianBeam:
    """Test cases for GaussianBeam class."""

    def test_beam_creation_850nm(self):
        """Test creating a standard 850nm VCSEL beam."""
        beam = GaussianBeam(wavelength=850, power=0.39, waist=1.0)
        assert beam.wavelength == 850
        assert beam.power == 0.39
        assert beam.waist == 1.0

    def test_beam_creation_1550nm(self):
        """Test creating a standard 1550nm telecom beam."""
        beam = GaussianBeam(wavelength=1550, power=0.39, waist=1.0)
        assert beam.wavelength == 1550
        assert beam.power == 0.39

    def test_beam_waist_validation(self):
        """Test that zero or negative waist raises error."""
        with pytest.raises(ValueError):
            GaussianBeam(wavelength=1550, power=0.1, waist=0)
        with pytest.raises(ValueError):
            GaussianBeam(wavelength=1550, power=0.1, waist=-1.0)

    def test_rayleigh_range_calculation(self):
        """Test Rayleigh range calculation."""
        beam = GaussianBeam(wavelength=1550, power=0.1, waist=1.0)
        z_r = beam.calculate_rayleigh_range()

        # Expected: z_r = π * w0² / λ
        # w0 = 1mm = 1e-3 m, λ = 1550nm = 1550e-9 m
        expected = np.pi * (1e-3) ** 2 / (1550e-9)
        assert abs(z_r - expected) < 0.01  # Within 1cm

    def test_divergence_calculation(self):
        """Test beam divergence calculation."""
        beam = GaussianBeam(wavelength=1550, power=0.1, waist=1.0)
        divergence = beam.calculate_divergence()  # mrad

        # Expected: θ = λ / (π * w0)
        expected_rad = 1550e-9 / (np.pi * 1e-3)
        expected_mrad = expected_rad * 1000
        assert abs(divergence - expected_mrad) < 0.001

    def test_radius_at_distance(self):
        """Test beam radius at various distances."""
        beam = GaussianBeam(wavelength=1550, power=0.1, waist=1.0)

        # At waist (z=0), radius should equal waist
        assert abs(beam.radius_at_distance(0) - beam.waist) < 0.001

        # At large distance, radius should grow with divergence
        z = 1000  # 1km
        radius = beam.radius_at_distance(z)
        assert radius > beam.waist  # Must be larger than waist
        assert radius < 1000  # Reasonable upper bound

    def test_intensity_decreases_with_distance(self):
        """Test that intensity decreases with distance."""
        beam = GaussianBeam(wavelength=1550, power=0.1, waist=1.0)

        i_near = beam.intensity_at_distance(10)
        i_far = beam.intensity_at_distance(100)

        assert i_near > i_far


class TestAtmosphericConstants:
    """Test cases for atmospheric constants and fog categories."""

    def test_fog_categories_exist(self):
        """Test that all fog categories are defined."""
        assert hasattr(FogCategory, "CLEAR")
        assert hasattr(FogCategory, "HAZE")
        assert hasattr(FogCategory, "LIGHT_FOG")
        assert hasattr(FogCategory, "MODERATE_FOG")
        assert hasattr(FogCategory, "DENSE_FOG")

    def test_attenuation_increases_with_fog_density(self):
        """Test that attenuation increases with fog density."""
        clear = ATTENUATION_DB_PER_KM.get(FogCategory.CLEAR, 0)
        haze = ATTENUATION_DB_PER_KM.get(FogCategory.HAZE, 0)
        light_fog = ATTENUATION_DB_PER_KM.get(FogCategory.LIGHT_FOG, 0)

        # Attenuation should increase with fog density
        assert haze >= clear
        assert light_fog >= haze

    def test_visibility_decreases_with_fog_density(self):
        """Test that visibility decreases with fog density."""
        clear = VISIBILITY_KM.get(FogCategory.CLEAR, float("inf"))
        haze = VISIBILITY_KM.get(FogCategory.HAZE, float("inf"))
        light_fog = VISIBILITY_KM.get(FogCategory.LIGHT_FOG, float("inf"))

        # Visibility should decrease with fog density
        assert clear >= haze
        assert haze >= light_fog


class TestHelperFunctions:
    """Test cases for standalone helper functions."""

    def test_calculate_beam_divergence(self):
        """Test standalone divergence calculation."""
        # 1550nm, 1mm waist
        divergence = calculate_beam_divergence(1550, 1.0)
        assert divergence > 0
        assert divergence < 10  # Reasonable upper bound in mrad

    def test_calculate_rayleigh_range(self):
        """Test standalone Rayleigh range calculation."""
        # 1550nm, 1mm waist
        z_r = calculate_rayleigh_range(1550, 1.0)
        assert z_r > 0
        assert z_r < 100  # Reasonable upper bound in meters


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
