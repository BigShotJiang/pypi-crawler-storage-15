# Changelog

All notable changes to the Optikal Physics Suite will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2025-12-07

### Added
- Initial stable release of Optikal Physics Suite
- **Beam Propagation Module**
  - `GaussianBeam` class for TEM00 beam modeling
  - `MultiBeamArray` class for 12/24/48-beam VCSEL arrays
  - `BeamPropagator` engine with optional GPU acceleration
  - Hexagonal, circular, and grid beam patterns
  - IEC 60825-1 Class 1 safety validation
- **Atmospheric Constants Module**
  - `FogCategory` enum (clear to dense fog)
  - ITU-R P.1814 compliant attenuation coefficients
  - Visibility mapping (dB/km)
  - Array diversity gain models (indoor/outdoor/fog)
  - Tri-band WDM characteristics
  - Link state model for mesh networks
- **Space Environment Module**
  - `OrbitType` enum (LEO/MEO/GEO/HEO)
  - `SpaceEnvironment` comprehensive environment model
  - `VacuumPropagation` for free-space loss calculation
  - `SpaceRadiationEffects` for radiation degradation
  - `SpaceThermalEnvironment` for temperature effects
- **ML Weather Module**
  - `WeatherAPIBaseClient` abstract base class
  - NOAA NCEI client for weather validation
  - Visual Crossing client for hourly data
  - Kaggle Szeged dataset downloader
  - LSTM model training pipeline
- **Documentation**
  - Comprehensive API documentation
  - Physics references and equations
  - Example notebooks (beam, atmospheric, space)
- **Testing**
  - 219 unit tests across all modules
  - 98% coverage for beam propagation
  - 100% coverage for atmospheric constants
  - 65% coverage for space environment
  - API integration test suite

### Changed
- Migrated from GhostGrid Optical Network to standalone package
- Updated from setuptools to hatchling build system
- Package renamed from `OptikalCore` to `optikal_physics_suite`

### Fixed
- Hard-coded Windows paths replaced with environment variables
- Fog attenuation units corrected to dB/km (not dB/100m)
- Array diversity gain updated to conservative estimates
- All Bandit security scan issues resolved

### Security
- All HTTP requests include explicit timeouts
- No hardcoded credentials or secrets
- Bandit security scan: PASS (0 high/critical issues)

## [0.9.0-beta] - 2025-12-05

### Added
- Beta release migrated from GhostGrid repository
- Core beam propagation and space environment modules

---

[1.0.0]: https://github.com/Netrun-Systems/Optikal-Physics-Suite/releases/tag/v1.0.0
[0.9.0-beta]: https://github.com/Netrun-Systems/Optikal-Physics-Suite/releases/tag/v0.9.0-beta
