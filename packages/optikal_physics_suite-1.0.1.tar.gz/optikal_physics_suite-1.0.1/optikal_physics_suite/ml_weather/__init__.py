"""
Optikal Physics Suite - Weather Data Collection Module

Provides weather data from multiple sources for ML model training,
atmospheric propagation modeling, and link availability prediction.

Sub-modules:
- base_client: Abstract base class for weather API clients
- kaggle_downloader: Download Szeged weather dataset with visibility
- noaa_client: NOAA NCEI API client for weather validation
- visualcrossing_client: Visual Crossing API client for hourly weather data
- train_lstm_model: LSTM model training for weather prediction
"""

__version__ = "1.0.0"
__author__ = "Netrun Systems"

from .base_client import WeatherAPIBaseClient

__all__ = [
    "WeatherAPIBaseClient",
    "kaggle_downloader",
    "noaa_client",
    "visualcrossing_client",
    "train_lstm_model",
]
