# Module 3: Weather Data Collection

Weather data collection and validation for GhostGrid FSO link prediction ML models.

## Overview

This module provides three weather data collection clients for training and validating ML models that predict FSO link performance based on atmospheric conditions.

**Data Sources:**
1. **Kaggle Dataset** (Szeged Weather) - Historical baseline with visibility
2. **NOAA NCEI API** - Real-time validation data (last 30 days)
3. **Visual Crossing API** - Hourly validation data with high temporal resolution

**Strategy:** Multi-source approach reduces API query costs while ensuring diverse training data.

## Quick Start

### 1. Kaggle Dataset Download

Requires Kaggle API credentials.

```bash
# Setup (one-time)
pip install kaggle
# Get token from https://www.kaggle.com/settings/account -> "Create New API Token"
# Place kaggle.json in ~/.kaggle/
# chmod 600 ~/.kaggle/kaggle.json

# Download and standardize
python kaggle_downloader.py --output-dir ./data/weather_historical/kaggle
```

**Output:** `data/weather_historical/kaggle/weather_standardized.csv`

### 2. NOAA NCEI API Collection

Requires NOAA API token (free).

```bash
pip install requests

# Get token at: https://www.ncei.noaa.gov/products/weather-data-api
# Set environment variable or pass as argument

python noaa_client.py \
    --token YOUR_NOAA_TOKEN \
    --station GHCND:USW00023174 \
    --start-date 2025-10-22 \
    --end-date 2025-11-21
```

**Output:** `data/weather_historical/noaa/noaa_validation.csv`

### 3. Visual Crossing API Collection

Requires Visual Crossing API key (free tier available).

```bash
pip install requests

# Get free key at: https://www.visualcrossing.com/sign-up

python visualcrossing_client.py \
    --key YOUR_API_KEY \
    --location "Seattle, WA" \
    --start-date 2025-10-22 \
    --end-date 2025-11-21
```

**Output:** `data/weather_historical/visual_crossing/visual_crossing_validation.csv`

## Data Schema

All outputs standardized to common CSV format:

```
timestamp,temperature,humidity,visibility,pressure,wind_speed,precipitation
2025-11-20T12:00:00,15.3,65.4,10.2,1013.25,3.5,0.0
2025-11-20T13:00:00,16.1,62.8,12.5,1013.10,3.8,0.0
```

**Columns:**

| Column | Unit | Description |
|--------|------|-------------|
| `timestamp` | ISO 8601 | Date/time (YYYY-MM-DDTHH:MM:SS) |
| `temperature` | °C | Air temperature |
| `humidity` | % | Relative humidity (0-100) |
| `visibility` | km | Visibility distance |
| `pressure` | mb | Atmospheric pressure |
| `wind_speed` | m/s | Wind speed |
| `precipitation` | mm | Precipitation amount |

## Data Sources Details

### Kaggle Dataset: Szeged Weather

**Dataset:** budincsevity/szeged-weather
**Coverage:** 2006-2017, Szeged, Hungary
**Features:** Temperature, humidity, visibility, pressure, wind, precipitation

**Source Columns:**
- Formatted Date
- Temperature (C)
- Apparent Temperature (C)
- Humidity
- Wind Speed (km/h)
- Visibility (km)
- Pressure (millibars)
- Precipitation (mm)

**Processing:**
- Wind speed converted from km/h to m/s
- All data standardized to common schema
- Handles column name variations

### NOAA NCEI API

**Station:** GHCND:USW00023174 (Seattle-Tacoma International Airport, WA)
**Data Types:**
- TMAX: Maximum daily temperature (in 1/10 °C)
- TMIN: Minimum daily temperature
- PRCP: Precipitation (in 1/10 mm)
- SNOW: Snowfall
- SNWD: Snow depth
- RHAV: Average relative humidity
- VISIB: Visibility (in 1/10 km)
- PRES: Pressure (in 1/10 mb)
- WSPD: Wind speed (in 1/10 m/s)

**Coverage:** Last 30 days
**API:** https://www.ncei.noaa.gov/products/weather-data-api

### Visual Crossing API

**Coverage:** Any location globally
**Default:** Seattle, WA
**Frequency:** Hourly or daily summaries available
**Features:** Temperature, humidity, visibility, pressure, wind, cloud cover, precipitation

**Data Processing:**
- Temperature: Fahrenheit → Celsius
- Visibility: Miles → kilometers
- Wind speed: MPH → m/s
- Precipitation: Inches → mm

**API:** https://www.visualcrossing.com/weather-api

## API Credentials Setup

### Kaggle API

1. Visit https://www.kaggle.com/settings/account
2. Click "Create New API Token"
3. This downloads `kaggle.json`
4. Place in `~/.kaggle/kaggle.json`
5. Set permissions: `chmod 600 ~/.kaggle/kaggle.json`

### NOAA NCEI API

1. Visit https://www.ncei.noaa.gov/products/weather-data-api
2. Sign up for free account
3. Generate API token
4. Use `--token` argument in `noaa_client.py`

### Visual Crossing API

1. Visit https://www.visualcrossing.com/sign-up
2. Free tier: 1,500 calls/day
3. Copy API key to `--key` argument

## Command-Line Usage

### kaggle_downloader.py

```bash
python kaggle_downloader.py [OPTIONS]

Options:
  --output-dir DIR          Directory to save dataset (default: data/weather_historical/kaggle)
  --standardize            Convert to standardized CSV format (default: True)
  --log-level {DEBUG,INFO,WARNING,ERROR}
                          Logging level (default: INFO)
  --help                  Show help message
```

**Examples:**

```bash
# Download with defaults
python kaggle_downloader.py

# Custom output directory
python kaggle_downloader.py --output-dir /path/to/data

# Debug logging
python kaggle_downloader.py --log-level DEBUG
```

### noaa_client.py

```bash
python noaa_client.py [OPTIONS]

Options:
  --token TOKEN             NOAA API token (required)
  --station STATION         Station ID (default: GHCND:USW00023174)
  --start-date DATE         Start date YYYY-MM-DD (default: 30 days ago)
  --end-date DATE           End date YYYY-MM-DD (default: today)
  --output-file FILE        Output CSV file path
  --limit COUNT             Max records to fetch (default: 1000)
  --log-level {DEBUG,INFO,WARNING,ERROR}
  --help                    Show help message
```

**Examples:**

```bash
# Fetch last 30 days
python noaa_client.py --token YOUR_TOKEN

# Specific date range
python noaa_client.py \
    --token YOUR_TOKEN \
    --start-date 2025-10-01 \
    --end-date 2025-11-01

# Different station
python noaa_client.py \
    --token YOUR_TOKEN \
    --station GHCND:USW00094846  # San Francisco
```

### visualcrossing_client.py

```bash
python visualcrossing_client.py [OPTIONS]

Options:
  --key KEY                Visual Crossing API key (required)
  --location LOCATION      Location string (default: "Seattle, WA")
  --start-date DATE        Start date YYYY-MM-DD (default: 30 days ago)
  --end-date DATE          End date YYYY-MM-DD (default: today)
  --output-file FILE       Output CSV file path
  --daily-summary         Save daily summaries instead of hourly
  --log-level {DEBUG,INFO,WARNING,ERROR}
  --help                   Show help message
```

**Examples:**

```bash
# Hourly data for Seattle
python visualcrossing_client.py --key YOUR_KEY

# Different location (latitude, longitude)
python visualcrossing_client.py \
    --key YOUR_KEY \
    --location "47.6062,-122.3321"  # Seattle coordinates

# Daily summary
python visualcrossing_client.py \
    --key YOUR_KEY \
    --location "Portland, OR" \
    --daily-summary

# Custom date range
python visualcrossing_client.py \
    --key YOUR_KEY \
    --start-date 2025-09-01 \
    --end-date 2025-11-21
```

## Error Handling

### Common Issues

**Kaggle:**
```
ERROR: Kaggle credentials not found
Solution: Create kaggle.json and place in ~/.kaggle/
```

**NOAA:**
```
HTTP error: 401 (Unauthorized)
Solution: Verify token is valid at https://www.ncei.noaa.gov/products/weather-data-api
```

```
HTTP error: 404 (Not Found)
Solution: Check station ID format (GHCND:USW00XXXXXX)
```

**Visual Crossing:**
```
HTTP error: 401 (Unauthorized)
Solution: Check API key is correct
```

```
HTTP error: 400 (Bad Request)
Solution: Check location format (e.g., "City, State" or "lat,lon")
```

## Development

### Dependencies

```
requests>=2.28.0
kaggle>=1.5.12
pandas>=1.5.0  (optional, for analysis)
matplotlib>=3.6.0  (optional, for visualization)
```

### Installation

```bash
pip install requests kaggle
```

### Testing

```bash
# Test without API calls (dry run)
python -c "from ml_weather import *; print('Module loaded')"

# List available functions
python -c "import ml_weather.kaggle_downloader as kd; help(kd)"
```

### Adding New Data Sources

Extend the module by creating new client files:

```python
# weather_new_source/weather_new_source_client.py

class NewSourceClient:
    def __init__(self, api_key: str, **kwargs):
        self.api_key = api_key

    def fetch_data(self, **kwargs) -> Optional[Dict]:
        """Fetch from API"""
        pass

    def parse_records(self, data: Dict) -> List[Dict]:
        """Convert to standard schema"""
        pass
```

## Performance

### Data Volume

- **Kaggle Dataset:** ~3.5GB raw, 10,000+ daily records
- **NOAA API:** 30 days, ~100 variables per day
- **Visual Crossing:** Hourly, ~720 records per month

### Processing Time

- **Kaggle Download:** 5-15 minutes (depends on internet)
- **NOAA Fetch:** 30-60 seconds
- **Visual Crossing Fetch:** 10-20 seconds

### Storage

- Szeged dataset: ~500 MB uncompressed
- NOAA/Visual Crossing: ~10-20 MB each

## Next Steps

1. **Data Integration:** Merge datasets into unified training set
2. **Quality Analysis:** Detect anomalies and missing values
3. **Feature Engineering:** Create ML-ready features from raw data
4. **Model Training:** Feed standardized data to ML models

## References

- [Kaggle Szeged Weather Dataset](https://www.kaggle.com/datasets/budincsevity/szeged-weather)
- [NOAA NCEI API Documentation](https://www.ncei.noaa.gov/products/weather-data-api)
- [Visual Crossing Weather API](https://www.visualcrossing.com/weather-api)
- [IEC 60825-1 Laser Safety Standards](https://en.wikipedia.org/wiki/IEC_60825)

## License

Part of GhostGrid optical network simulation project.

## Authors

GhostGrid ML Team - Module 3: Weather Data Collection
