#!/usr/bin/env python3
"""
Visual Crossing API Client
Module 3: Weather Data Collection
Fetches last 30 days of hourly weather data with visibility from Visual Crossing API

Default location: Seattle, WA
Includes visibility, temperature, humidity, pressure, wind speed, precipitation

API Documentation:
https://www.visualcrossing.com/weather-api

Required:
- Visual Crossing API key (--key argument)
- Get free key at: https://www.visualcrossing.com/sign-up
"""

import os
import sys
import csv
import json
import argparse
import logging
import requests
from pathlib import Path
from datetime import datetime, timedelta
from typing import Optional, Dict, List
from urllib.parse import quote

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

# Visual Crossing API configuration
VC_API_BASE = "https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline"
DEFAULT_LOCATION = "Seattle, WA"
REQUEST_TIMEOUT = 30  # seconds


class VisualCrossingClient:
    """Visual Crossing Weather API client."""

    def __init__(self, api_key: str, location: str = DEFAULT_LOCATION):
        """
        Initialize Visual Crossing client.

        Args:
            api_key (str): Visual Crossing API key
            location (str): Location (city, state or lat,lon)
        """
        self.api_key = api_key
        self.location = location
        self.session = requests.Session()
        self.session.headers.update(
            {
                "Accept": "application/json",
                "User-Agent": "GhostGrid-WeatherCollector/1.0",
            }
        )

    def fetch_data(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        include_elements: Optional[List[str]] = None,
    ) -> Optional[Dict]:
        """
        Fetch weather data from Visual Crossing for specified date range.

        Args:
            start_date (str): Start date (YYYY-MM-DD), default: 30 days ago
            end_date (str): End date (YYYY-MM-DD), default: today
            include_elements (list): Elements to include (default: standard)

        Returns:
            dict: API response with weather data, or None if failed
        """

        # Set default dates (last 30 days)
        if not end_date:
            end_date = datetime.utcnow().strftime("%Y-%m-%d")

        if not start_date:
            start_date = (datetime.utcnow() - timedelta(days=30)).strftime("%Y-%m-%d")

        # Default elements to retrieve
        if not include_elements:
            include_elements = [
                "datetime",
                "temp",
                "humidity",
                "visibility",
                "pressure",
                "windspeed",
                "precip",
                "winddir",
                "cloudcover",
            ]

        logger.info(f"Fetching Visual Crossing data for location: {self.location}")
        logger.info(f"Date range: {start_date} to {end_date}")
        logger.info(f"Elements: {', '.join(include_elements)}")

        # Build URL
        location_encoded = quote(self.location)
        url = f"{VC_API_BASE}/{location_encoded}/{start_date}/{end_date}"

        params = {
            "key": self.api_key,
            "include": "hours",
            "elements": ",".join(include_elements),
            "contentType": "json",
        }

        try:
            logger.info(f"Sending request to {url}")
            response = self.session.get(url, params=params, timeout=REQUEST_TIMEOUT)

            response.raise_for_status()

            data = response.json()

            # Check for API errors
            if "errorCode" in data:
                error_msg = data.get("errorCode", {}).get("message", "Unknown error")
                logger.error(f"API error: {error_msg}")
                return None

            if "days" in data:
                total_records = sum(len(day.get("hours", [])) for day in data["days"])
                logger.info(
                    f"Received {len(data['days'])} days with {total_records} hourly records"
                )
                return data
            else:
                logger.warning("No data in Visual Crossing response")
                logger.debug(f"Response: {data}")
                return None

        except requests.exceptions.Timeout:
            logger.error(f"Request timed out after {REQUEST_TIMEOUT} seconds")
            return None

        except requests.exceptions.HTTPError as e:
            logger.error(f"HTTP error: {e.response.status_code}")
            logger.error(f"Response: {e.response.text}")

            if e.response.status_code == 401:
                logger.error("Unauthorized - check your Visual Crossing API key")
            elif e.response.status_code == 400:
                logger.error(f"Bad request - check location format: {self.location}")

            return None

        except requests.exceptions.RequestException as e:
            logger.error(f"Request failed: {e}")
            return None

        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse JSON response: {e}")
            return None

    def parse_records(self, data: Dict) -> List[Dict]:
        """
        Parse Visual Crossing API response into standardized weather records.

        Visual Crossing provides hourly data with temperature in Fahrenheit by default.
        This function converts to standard units and aggregates into records.

        Args:
            data (dict): Visual Crossing API response

        Returns:
            list: Standardized weather records
        """

        if not data or "days" not in data:
            logger.warning("No data to parse")
            return []

        records = []

        for day in data["days"]:
            day_date = day.get("datetime", "")

            # Process hourly data
            for hour in day.get("hours", []):
                try:
                    hour_time = hour.get("datetime", "")
                    timestamp = f"{day_date}T{hour_time}"

                    # Temperature: convert Fahrenheit to Celsius
                    temp_f = hour.get("temp")
                    temperature = (temp_f - 32) * 5 / 9 if temp_f is not None else None

                    # Humidity: percentage (0-100)
                    humidity = hour.get("humidity")

                    # Visibility: in miles, convert to km
                    visibility_miles = hour.get("visibility")
                    visibility = (
                        visibility_miles * 1.60934
                        if visibility_miles is not None
                        else None
                    )

                    # Pressure: in mb (millibars)
                    pressure = hour.get("pressure")

                    # Wind speed: in mph, convert to m/s
                    wind_speed_mph = hour.get("windspeed")
                    wind_speed = (
                        wind_speed_mph * 0.44704 if wind_speed_mph is not None else None
                    )

                    # Precipitation: in inches, convert to mm
                    precip_inches = hour.get("precip")
                    precipitation = (
                        precip_inches * 25.4 if precip_inches is not None else None
                    )

                    records.append(
                        {
                            "timestamp": timestamp,
                            "temperature": temperature,
                            "humidity": humidity,
                            "visibility": visibility,
                            "pressure": pressure,
                            "wind_speed": wind_speed,
                            "precipitation": precipitation,
                        }
                    )

                except (KeyError, ValueError, TypeError) as e:
                    logger.debug(f"Error parsing hourly record: {e}")
                    continue

        logger.info(f"Parsed {len(records)} hourly records")
        return records

    def parse_records_daily(self, data: Dict) -> List[Dict]:
        """
        Parse Visual Crossing API response into daily summary records.

        Provides one record per day with aggregated/averaged values.

        Args:
            data (dict): Visual Crossing API response

        Returns:
            list: Standardized daily weather records
        """

        if not data or "days" not in data:
            logger.warning("No data to parse")
            return []

        records = []

        for day in data["days"]:
            try:
                timestamp = day.get("datetime", "")

                # Use daytime values (often provided as aggregates)
                temp_f = day.get("temp")
                temperature = (temp_f - 32) * 5 / 9 if temp_f is not None else None

                humidity = day.get("humidity")

                visibility_miles = day.get("visibility")
                visibility = (
                    visibility_miles * 1.60934 if visibility_miles is not None else None
                )

                pressure = day.get("pressure")

                wind_speed_mph = day.get("windspeed")
                wind_speed = (
                    wind_speed_mph * 0.44704 if wind_speed_mph is not None else None
                )

                precip_inches = day.get("precip")
                precipitation = (
                    precip_inches * 25.4 if precip_inches is not None else None
                )

                records.append(
                    {
                        "timestamp": timestamp,
                        "temperature": temperature,
                        "humidity": humidity,
                        "visibility": visibility,
                        "pressure": pressure,
                        "wind_speed": wind_speed,
                        "precipitation": precipitation,
                    }
                )

            except (KeyError, ValueError, TypeError) as e:
                logger.debug(f"Error parsing daily record: {e}")
                continue

        logger.info(f"Parsed {len(records)} daily records")
        return records


def save_csv(records: List[Dict], output_file: str) -> bool:
    """
    Save weather records to CSV file.

    Args:
        records (list): Weather records
        output_file (str): Output file path

    Returns:
        bool: True if successful, False otherwise
    """

    output_path = Path(output_file)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    if not records:
        logger.warning("No records to save")
        return False

    fieldnames = [
        "timestamp",
        "temperature",
        "humidity",
        "visibility",
        "pressure",
        "wind_speed",
        "precipitation",
    ]

    try:
        with open(output_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(records)

        logger.info(f"Saved {len(records)} records to {output_path}")
        return True

    except Exception as e:
        logger.error(f"Failed to save CSV: {e}")
        return False


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="Fetch weather data from Visual Crossing API"
    )
    parser.add_argument(
        "--key",
        required=True,
        help="Visual Crossing API key (get from https://www.visualcrossing.com/sign-up)",
    )
    parser.add_argument(
        "--location",
        default=DEFAULT_LOCATION,
        help=f"Location (city, state or lat,lon; default: {DEFAULT_LOCATION})",
    )
    parser.add_argument(
        "--start-date", help="Start date (YYYY-MM-DD, default: 30 days ago)"
    )
    parser.add_argument("--end-date", help="End date (YYYY-MM-DD, default: today)")
    parser.add_argument(
        "--output-file",
        default=os.environ.get(
            "OPTIKAL_DATA_DIR", "./data/weather_historical/visual_crossing"
        )
        + "/visual_crossing_validation.csv",
        help="Output CSV file path (default: $OPTIKAL_DATA_DIR/visual_crossing/visual_crossing_validation.csv)",
    )
    parser.add_argument(
        "--daily-summary",
        action="store_true",
        help="Save daily summary instead of hourly data",
    )
    parser.add_argument(
        "--log-level",
        default="INFO",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help="Logging level",
    )

    args = parser.parse_args()

    # Configure logging level
    logger.setLevel(getattr(logging, args.log_level))

    logger.info("=" * 60)
    logger.info("Visual Crossing Weather Data Collector")
    logger.info("=" * 60)

    # Validate API key
    if not args.key or len(args.key) < 10:
        logger.error("Invalid Visual Crossing API key provided")
        logger.error("Get free key at: https://www.visualcrossing.com/sign-up")
        return 1

    # Create client
    client = VisualCrossingClient(api_key=args.key, location=args.location)

    # Fetch data
    data = client.fetch_data(start_date=args.start_date, end_date=args.end_date)

    if not data:
        logger.error("Failed to fetch data from Visual Crossing")
        return 1

    # Parse and save
    if args.daily_summary:
        logger.info("Parsing as daily summary")
        records = client.parse_records_daily(data)
    else:
        logger.info("Parsing as hourly data")
        records = client.parse_records(data)

    if not save_csv(records, args.output_file):
        return 1

    logger.info("=" * 60)
    logger.info(f"Successfully collected {len(records)} records from Visual Crossing")
    logger.info(f"Location: {args.location}")
    logger.info(f"Saved to: {args.output_file}")
    logger.info("=" * 60)

    return 0


if __name__ == "__main__":
    sys.exit(main())
