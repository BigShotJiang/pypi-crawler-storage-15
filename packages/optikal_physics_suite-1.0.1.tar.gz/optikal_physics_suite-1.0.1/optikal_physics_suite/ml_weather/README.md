# ML Weather Prediction Module
## Multi-Source Historical Weather Data Collection

This module collects 24 months of historical weather data from 3 sources:

1. **Kaggle Pre-existing Datasets** - Baseline training data (24+ months)
2. **NOAA NCEI API** - US government validation data (1 month)
3. **Visual Crossing API** - Commercial validation data (1 month different location)

## Setup Instructions

### 1. Install Dependencies
```bash
pip install kaggle requests pandas numpy
```

### 2. Configure API Credentials

**Kaggle** (for pre-existing datasets):
- Get API token: https://www.kaggle.com/account
- Save to `~/.kaggle/kaggle.json` (Linux/Mac) or `C:\Users\<user>\.kaggle\kaggle.json` (Windows)

**NOAA** (free government data):
- Request token: https://www.ncdc.noaa.gov/cdo-web/token
- Save to environment: `export NOAA_TOKEN="your_token_here"`

**Visual Crossing** (free tier 1000 records/day):
- Sign up: https://www.visualcrossing.com/sign-up
- Get API key from dashboard
- Save to environment: `export VISUAL_CROSSING_KEY="your_key_here"`

## Usage

### Download Baseline Dataset (Kaggle)
```bash
python kaggle_downloader.py
```

### Fetch NOAA Validation Data
```bash
python noaa_client.py --token YOUR_NOAA_TOKEN --station GHCND:USW00023174 --days 30
```

### Fetch Visual Crossing Validation Data
```bash
python visualcrossing_client.py --key YOUR_VC_KEY --location "Seattle, WA" --days 30
```

### Aggregate All Sources
```bash
python aggregate_weather_data.py
```

## Output

Combined dataset saved to: `../../data/weather_historical/combined_dataset.csv`

Expected format:
- timestamp (datetime)
- temperature (Celsius)
- humidity (%)
- visibility (km)
- pressure (hPa)
- wind_speed (m/s)
- precipitation (mm)
- source (kaggle|noaa|visual_crossing)
