# Module 3: Weather Data Collection - Setup Guide

Quick setup and usage guide for weather data collection scripts.

## Files Overview

| File | Purpose | Dependencies |
|------|---------|--------------|
| `kaggle_downloader.py` | Download Szeged weather dataset | kaggle |
| `noaa_client.py` | Fetch NOAA NCEI API data | requests |
| `visualcrossing_client.py` | Fetch Visual Crossing API data | requests |
| `example_data_collection.py` | Complete workflow example | All of above |
| `WEATHER_DATA_COLLECTION.md` | Comprehensive documentation | - |

## Installation

### 1. Install Dependencies

```bash
# Core requirements
pip install requests

# Optional: Kaggle dataset download
pip install kaggle

# Optional: Data analysis (recommended)
pip install pandas matplotlib
```

### 2. Setup API Credentials

#### Kaggle (Optional - for historical data)

1. Visit https://www.kaggle.com/settings/account
2. Click "Create New API Token"
3. Place `kaggle.json` in `~/.kaggle/`
4. Set permissions: `chmod 600 ~/.kaggle/kaggle.json`

#### NOAA NCEI (Optional - for validation)

1. Visit https://www.ncei.noaa.gov/products/weather-data-api
2. Sign up for free account
3. Generate API token
4. Save for command-line usage

#### Visual Crossing (Optional - for hourly data)

1. Visit https://www.visualcrossing.com/sign-up
2. Get free API key (1,500 calls/day)
3. Save for command-line usage

## Quick Start

### Option 1: Run All Examples

```bash
cd ghostgrid-sim/src/ml_weather/

# With API tokens (recommended)
export NOAA_API_TOKEN="your_noaa_token"
export VISUAL_CROSSING_KEY="your_visual_crossing_key"
python example_data_collection.py

# Without API tokens (Kaggle only)
python example_data_collection.py
```

### Option 2: Individual Data Collection

#### Collect from Kaggle

```bash
python kaggle_downloader.py \
    --output-dir ./data/weather_historical/kaggle \
    --standardize
```

#### Collect from NOAA

```bash
python noaa_client.py \
    --token YOUR_NOAA_TOKEN \
    --start-date 2025-10-22 \
    --end-date 2025-11-21
```

#### Collect from Visual Crossing

```bash
python visualcrossing_client.py \
    --key YOUR_API_KEY \
    --location "Seattle, WA" \
    --start-date 2025-10-22 \
    --end-date 2025-11-21
```

## Data Organization

```
ghostgrid-sim/
└── data/
    └── weather_historical/
        ├── kaggle/
        │   ├── szeged_weather.csv          (original)
        │   └── szeged_weather_standardized.csv  (processed)
        ├── noaa/
        │   └── noaa_validation.csv
        ├── visual_crossing/
        │   └── visual_crossing_validation.csv
        └── COMBINED_weather_data.csv       (merged all sources)
```

## Usage Examples

### Example 1: Download Szeged Dataset

```bash
python kaggle_downloader.py

# Output: data/weather_historical/kaggle/weather_standardized.csv
# Contains: 10,000+ daily records (2006-2017)
```

### Example 2: Fetch Last 30 Days from NOAA

```bash
python noaa_client.py --token abc123xyz

# Output: data/weather_historical/noaa/noaa_validation.csv
# Contains: ~30 daily records with multiple weather variables
```

### Example 3: Fetch Hourly Data from Visual Crossing

```bash
python visualcrossing_client.py --key def456uvw --location "Seattle, WA"

# Output: data/weather_historical/visual_crossing/visual_crossing_validation.csv
# Contains: ~720 hourly records (30 days)
```

### Example 4: Different Locations

```bash
# San Francisco
python visualcrossing_client.py --key YOUR_KEY --location "San Francisco, CA"

# Using coordinates
python visualcrossing_client.py --key YOUR_KEY --location "47.6062,-122.3321"

# Portland, OR
python visualcrossing_client.py --key YOUR_KEY --location "Portland, OR"
```

### Example 5: Daily Summaries Instead of Hourly

```bash
python visualcrossing_client.py \
    --key YOUR_KEY \
    --daily-summary \
    --location "Seattle, WA"
```

### Example 6: Custom Date Ranges

```bash
# Last 60 days
python visualcrossing_client.py \
    --key YOUR_KEY \
    --start-date 2025-09-22 \
    --end-date 2025-11-21

# Specific month
python noaa_client.py \
    --token YOUR_TOKEN \
    --start-date 2025-10-01 \
    --end-date 2025-10-31
```

## Data Schema

All scripts output CSV with standard columns:

```csv
timestamp,temperature,humidity,visibility,pressure,wind_speed,precipitation
2025-11-20T12:00:00,15.3,65.4,10.2,1013.25,3.5,0.0
2025-11-20T13:00:00,16.1,62.8,12.5,1013.10,3.8,0.0
```

| Column | Unit | Range | Notes |
|--------|------|-------|-------|
| timestamp | ISO 8601 | - | YYYY-MM-DDTHH:MM:SS format |
| temperature | °C | -50 to +50 | Celsius |
| humidity | % | 0-100 | Relative humidity |
| visibility | km | 0-10+ | Visibility distance |
| pressure | mb | 950-1050 | Millibars |
| wind_speed | m/s | 0-40 | Meters per second |
| precipitation | mm | 0-100+ | Millimeters |

## Troubleshooting

### "Kaggle credentials not found"

```bash
# Setup Kaggle credentials
pip install kaggle
# Visit https://www.kaggle.com/settings/account and create API token
# Place kaggle.json in ~/.kaggle/
chmod 600 ~/.kaggle/kaggle.json
```

### "HTTP error: 401 (Unauthorized)"

```bash
# Check API token/key
# - NOAA: https://www.ncei.noaa.gov/products/weather-data-api
# - Visual Crossing: https://www.visualcrossing.com/account

# Verify token is correct
python noaa_client.py --token YOUR_TOKEN --log-level DEBUG
```

### "HTTP error: 400 (Bad Request)"

```bash
# Check location format for Visual Crossing
# Valid formats:
#   - "City, State" (e.g., "Seattle, WA")
#   - "City, Country" (e.g., "London, UK")
#   - "lat,lon" (e.g., "47.6062,-122.3321")

python visualcrossing_client.py --key YOUR_KEY --location "Seattle, WA"
```

### "Connection timeout"

```bash
# Network connectivity issue - retry with longer timeout
# Increase timeout in script or check internet connection
python noaa_client.py --token YOUR_TOKEN --log-level DEBUG
```

## Environment Variables

Set environment variables to avoid command-line arguments:

```bash
# Linux/Mac
export NOAA_API_TOKEN="your_noaa_token"
export VISUAL_CROSSING_KEY="your_visual_crossing_key"

# Windows PowerShell
$env:NOAA_API_TOKEN = "your_noaa_token"
$env:VISUAL_CROSSING_KEY = "your_visual_crossing_key"

# Then use:
python example_data_collection.py
```

## Batch Collection Script

Create `collect_all_data.sh`:

```bash
#!/bin/bash

# Setup
cd ghostgrid-sim/src/ml_weather/

# API credentials
NOAA_TOKEN="your_noaa_token"
VC_KEY="your_visual_crossing_key"

echo "Collecting weather data..."

# Kaggle (no auth required if configured locally)
echo "1. Downloading Kaggle dataset..."
python kaggle_downloader.py

# NOAA
echo "2. Fetching NOAA data..."
python noaa_client.py --token $NOAA_TOKEN

# Visual Crossing
echo "3. Fetching Visual Crossing data..."
python visualcrossing_client.py --key $VC_KEY

# Combine and validate
echo "4. Combining datasets..."
python example_data_collection.py

echo "Done! Check data/weather_historical/ for results."
```

## Performance Metrics

### Data Volume

| Source | Records | Duration | Size |
|--------|---------|----------|------|
| Kaggle | 10,000+ | 11 years | 500 MB |
| NOAA | ~100 | 30 days | 50 KB |
| Visual Crossing | ~720 | 30 days | 100 KB |
| Combined | 10,800+ | 11 years + 30 days | 500 MB |

### Processing Time

| Task | Duration |
|------|----------|
| Kaggle download | 5-15 min |
| Kaggle processing | 1-2 min |
| NOAA fetch | 30-60 sec |
| Visual Crossing fetch | 10-20 sec |
| Combine datasets | <1 sec |
| Validate CSVs | <1 sec |

## API Rate Limits

| Service | Free Tier | Limit |
|---------|-----------|-------|
| Kaggle | N/A | 1 download/day |
| NOAA | Free | 300 requests/hour |
| Visual Crossing | Free | 1,500 calls/day |

## Next Steps

1. **Collect Data:** Run data collection scripts
2. **Validate:** Check CSV format and completeness
3. **Explore:** Analyze datasets with pandas
4. **Train Models:** Use combined data for ML training
5. **Monitor:** Set up automated weekly collection

## References

- [Kaggle Szeged Weather](https://www.kaggle.com/datasets/budincsevity/szeged-weather)
- [NOAA NCEI API](https://www.ncei.noaa.gov/products/weather-data-api)
- [Visual Crossing API](https://www.visualcrossing.com/weather-api)

## Support

For issues or questions:
1. Check `WEATHER_DATA_COLLECTION.md` for detailed docs
2. Review example scripts in `example_data_collection.py`
3. Check error messages - they include helpful hints
4. Enable `--log-level DEBUG` for troubleshooting

---

**Module 3: Weather Data Collection**
Part of GhostGrid Optical Network simulation framework.
