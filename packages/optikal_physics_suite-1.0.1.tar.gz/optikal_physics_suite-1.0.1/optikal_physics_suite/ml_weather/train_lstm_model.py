#!/usr/bin/env python3
"""
LSTM Weather Prediction Model Training
Module 3: ML Weather Prediction Validator
Trains LSTM model on historical weather data to validate Patent #15
"""

import os
import sys
import argparse
import logging
import json
from pathlib import Path
from datetime import datetime
import numpy as np
import pandas as pd

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


def check_tensorflow_installed():
    """Check if TensorFlow is available."""
    try:
        import tensorflow as tf

        logger.info(f"TensorFlow version: {tf.__version__}")

        # Check for GPU availability
        gpus = tf.config.list_physical_devices("GPU")
        if gpus:
            logger.info(f"GPUs available: {len(gpus)}")
            for gpu in gpus:
                logger.info(f"  - {gpu.name}")
        else:
            logger.warning("No GPU detected - training will use CPU (slower)")

        return True
    except ImportError:
        logger.error("TensorFlow not installed. Install with: pip install tensorflow")
        return False


def load_weather_data(data_dir):
    """
    Load and combine weather data from multiple sources.

    Args:
        data_dir: Directory containing weather CSV files

    Returns:
        DataFrame with combined weather data
    """
    logger.info(f"Loading weather data from: {data_dir}")

    data_path = Path(data_dir)
    all_data = []

    # Load Kaggle data
    kaggle_file = data_path / "kaggle" / "weatherHistory_standardized.csv"
    if kaggle_file.exists():
        logger.info(f"Loading Kaggle dataset: {kaggle_file}")
        df_kaggle = pd.read_csv(kaggle_file)
        df_kaggle["source"] = "kaggle"
        all_data.append(df_kaggle)
        logger.info(f"  Loaded {len(df_kaggle)} Kaggle records")

    # Load Visual Crossing data
    vc_file = data_path / "visual_crossing" / "visual_crossing_validation.csv"
    if vc_file.exists():
        logger.info(f"Loading Visual Crossing dataset: {vc_file}")
        df_vc = pd.read_csv(vc_file)
        df_vc["source"] = "visual_crossing"
        all_data.append(df_vc)
        logger.info(f"  Loaded {len(df_vc)} Visual Crossing records")

    # Load NOAA data if available
    noaa_file = data_path / "noaa" / "noaa_validation.csv"
    if noaa_file.exists():
        logger.info(f"Loading NOAA dataset: {noaa_file}")
        df_noaa = pd.read_csv(noaa_file)
        df_noaa["source"] = "noaa"
        all_data.append(df_noaa)
        logger.info(f"  Loaded {len(df_noaa)} NOAA records")

    if not all_data:
        raise ValueError(f"No weather data found in {data_dir}")

    # Combine all datasets
    df_combined = pd.concat(all_data, ignore_index=True)
    logger.info(f"Total records loaded: {len(df_combined)}")

    # Parse timestamps (handle multiple formats from different sources)
    df_combined["timestamp"] = pd.to_datetime(
        df_combined["timestamp"], format="mixed", utc=True
    )

    # Sort by timestamp
    df_combined = df_combined.sort_values("timestamp").reset_index(drop=True)

    # Handle missing values
    logger.info("Handling missing values...")
    initial_count = len(df_combined)

    # Forward fill for small gaps (up to 3 hours)
    df_combined = df_combined.fillna(method="ffill", limit=3)

    # Drop remaining NaN rows
    df_combined = df_combined.dropna()

    final_count = len(df_combined)
    dropped = initial_count - final_count
    if dropped > 0:
        logger.warning(
            f"Dropped {dropped} rows with missing data ({dropped / initial_count * 100:.2f}%)"
        )

    logger.info(f"Final dataset: {len(df_combined)} clean records")

    return df_combined


def create_sequences(data, lookback_hours=168, forecast_hours=24):
    """
    Create time-series sequences for LSTM training.

    Args:
        data: Normalized weather data (NumPy array)
        lookback_hours: Hours of historical data to use (default: 168 = 7 days)
        forecast_hours: Hours to predict ahead (default: 24 = 1 day)

    Returns:
        X: Input sequences (samples, timesteps, features)
        y: Target values (samples, forecast_hours, features)
    """
    logger.info(
        f"Creating sequences with {lookback_hours}h lookback, {forecast_hours}h forecast"
    )

    X, y = [], []

    for i in range(len(data) - lookback_hours - forecast_hours):
        # Input: lookback_hours of historical data
        X.append(data[i : i + lookback_hours])

        # Target: forecast_hours of future data
        y.append(data[i + lookback_hours : i + lookback_hours + forecast_hours])

    X = np.array(X)
    y = np.array(y)

    logger.info(f"Created {len(X)} sequences")
    logger.info(f"  X shape: {X.shape} (samples, timesteps, features)")
    logger.info(f"  y shape: {y.shape} (samples, forecast_hours, features)")

    return X, y


def normalize_data(df):
    """
    Normalize weather data to [0, 1] range.

    Returns:
        normalized_data: NumPy array
        normalization_params: Dict with min/max for denormalization
    """
    logger.info("Normalizing data...")

    feature_columns = [
        "temperature",
        "humidity",
        "visibility",
        "pressure",
        "wind_speed",
    ]

    # Check which features are available
    available_features = [col for col in feature_columns if col in df.columns]
    logger.info(f"Available features: {available_features}")

    # Extract feature data
    data = df[available_features].values

    # Compute min/max for each feature
    normalization_params = {}
    for i, col in enumerate(available_features):
        col_min = data[:, i].min()
        col_max = data[:, i].max()
        normalization_params[col] = {"min": float(col_min), "max": float(col_max)}

        # Normalize to [0, 1]
        data[:, i] = (data[:, i] - col_min) / (col_max - col_min + 1e-8)

    logger.info("Normalization parameters:")
    for col, params in normalization_params.items():
        logger.info(f"  {col}: min={params['min']:.2f}, max={params['max']:.2f}")

    return data, normalization_params, available_features


def build_lstm_model(input_shape, output_shape):
    """
    Build LSTM model architecture.

    Args:
        input_shape: (timesteps, features)
        output_shape: (forecast_hours, features)

    Returns:
        Compiled Keras model
    """
    from tensorflow import keras
    from tensorflow.keras import layers

    logger.info("Building LSTM model...")
    logger.info(f"  Input shape: {input_shape}")
    logger.info(f"  Output shape: {output_shape}")

    model = keras.Sequential(
        [
            # First LSTM layer with return sequences
            layers.LSTM(128, return_sequences=True, input_shape=input_shape),
            layers.Dropout(0.2),
            # Second LSTM layer
            layers.LSTM(128, return_sequences=False),
            layers.Dropout(0.2),
            # Dense layers for forecast
            layers.Dense(256, activation="relu"),
            layers.Dropout(0.2),
            # Output layer (flatten forecast_hours * features)
            layers.Dense(output_shape[0] * output_shape[1]),
            # Reshape to (forecast_hours, features)
            layers.Reshape(output_shape),
        ]
    )

    # Compile model
    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=0.001),
        loss="mse",
        metrics=["mae"],
    )

    model.summary(print_fn=logger.info)

    return model


def train_model(
    model,
    X_train,
    y_train,
    X_val,
    y_val,
    epochs,
    batch_size,
    model_dir,
    checkpoint_every=10,
):
    """
    Train LSTM model with checkpointing.

    Args:
        model: Keras model
        X_train, y_train: Training data
        X_val, y_val: Validation data
        epochs: Number of training epochs
        batch_size: Batch size
        model_dir: Directory to save checkpoints
        checkpoint_every: Save checkpoint every N epochs

    Returns:
        Training history
    """
    from tensorflow import keras

    logger.info("Starting training...")
    logger.info(f"  Epochs: {epochs}")
    logger.info(f"  Batch size: {batch_size}")
    logger.info(f"  Training samples: {len(X_train)}")
    logger.info(f"  Validation samples: {len(X_val)}")

    model_path = Path(model_dir)
    model_path.mkdir(parents=True, exist_ok=True)

    # Callbacks
    callbacks = [
        # Save best model
        keras.callbacks.ModelCheckpoint(
            filepath=str(model_path / "best_model.keras"),
            monitor="val_loss",
            save_best_only=True,
            verbose=1,
        ),
        # Early stopping
        keras.callbacks.EarlyStopping(
            monitor="val_loss", patience=10, restore_best_weights=True, verbose=1
        ),
        # Reduce learning rate on plateau
        keras.callbacks.ReduceLROnPlateau(
            monitor="val_loss", factor=0.5, patience=5, verbose=1
        ),
    ]

    # Custom checkpoint callback for periodic saves
    class PeriodicCheckpoint(keras.callbacks.Callback):
        def __init__(self, checkpoint_dir, checkpoint_every):
            super().__init__()
            self.checkpoint_dir = checkpoint_dir
            self.checkpoint_every = checkpoint_every

        def on_epoch_end(self, epoch, logs=None):
            if (epoch + 1) % self.checkpoint_every == 0:
                checkpoint_path = (
                    self.checkpoint_dir / f"checkpoint_epoch_{epoch + 1}.keras"
                )
                self.model.save(checkpoint_path)
                logger.info(f"Saved checkpoint: {checkpoint_path}")

    callbacks.append(PeriodicCheckpoint(model_path, checkpoint_every))

    # Train model
    history = model.fit(
        X_train,
        y_train,
        validation_data=(X_val, y_val),
        epochs=epochs,
        batch_size=batch_size,
        callbacks=callbacks,
        verbose=2,  # Progress bar per epoch
    )

    # Save final model
    final_model_path = model_path / "final_model.keras"
    model.save(final_model_path)
    logger.info(f"Saved final model: {final_model_path}")

    # Save training history
    history_path = model_path / "training_history.json"
    with open(history_path, "w") as f:
        json.dump(history.history, f, indent=2)
    logger.info(f"Saved training history: {history_path}")

    return history


def evaluate_model(model, X_test, y_test, normalization_params, feature_names):
    """
    Evaluate model performance and validate Patent #15 claims.

    Patent #15 Requirement: RMSE < 20% for visibility prediction

    Returns:
        metrics: Dict with evaluation metrics
        patent_validated: Boolean
    """

    logger.info("Evaluating model performance...")

    # Make predictions
    y_pred = model.predict(X_test, verbose=0)

    # Calculate metrics for each feature
    metrics = {}

    for i, feature in enumerate(feature_names):
        # Extract actual and predicted values for this feature
        y_true_feature = y_test[:, :, i]
        y_pred_feature = y_pred[:, :, i]

        # Denormalize to original scale
        feature_min = normalization_params[feature]["min"]
        feature_max = normalization_params[feature]["max"]

        y_true_denorm = y_true_feature * (feature_max - feature_min) + feature_min
        y_pred_denorm = y_pred_feature * (feature_max - feature_min) + feature_min

        # Calculate metrics
        mse = np.mean((y_true_denorm - y_pred_denorm) ** 2)
        rmse = np.sqrt(mse)
        mae = np.mean(np.abs(y_true_denorm - y_pred_denorm))

        # Calculate percentage error
        mean_true = np.mean(np.abs(y_true_denorm))
        rmse_percent = (rmse / mean_true) * 100
        mae_percent = (mae / mean_true) * 100

        metrics[feature] = {
            "rmse": float(rmse),
            "mae": float(mae),
            "rmse_percent": float(rmse_percent),
            "mae_percent": float(mae_percent),
        }

        logger.info(f"{feature}:")
        logger.info(f"  RMSE: {rmse:.4f} ({rmse_percent:.2f}%)")
        logger.info(f"  MAE: {mae:.4f} ({mae_percent:.2f}%)")

    # Patent #15 validation (focus on visibility prediction)
    if "visibility" in metrics:
        visibility_rmse_percent = metrics["visibility"]["rmse_percent"]
        patent_validated = visibility_rmse_percent < 20.0

        logger.info("\n" + "=" * 60)
        logger.info("PATENT #15 VALIDATION RESULTS")
        logger.info("=" * 60)
        logger.info(f"Visibility RMSE: {visibility_rmse_percent:.2f}%")
        logger.info("Requirement: < 20%")
        logger.info(f"Status: {'PASS ✓' if patent_validated else 'FAIL ✗'}")
        logger.info("=" * 60)
    else:
        logger.warning("Visibility feature not available for Patent #15 validation")
        patent_validated = False

    return metrics, patent_validated


def main():
    """Main training pipeline."""
    parser = argparse.ArgumentParser(
        description="Train LSTM model for weather prediction"
    )
    parser.add_argument(
        "--data-dir",
        default=os.environ.get("OPTIKAL_DATA_DIR", "./data/weather_historical"),
        help="Directory containing weather CSV files (default: $OPTIKAL_DATA_DIR)",
    )
    parser.add_argument(
        "--model-dir",
        default=os.environ.get("OPTIKAL_MODEL_DIR", "./models/weather_lstm"),
        help="Directory to save trained models (default: $OPTIKAL_MODEL_DIR)",
    )
    parser.add_argument(
        "--epochs", type=int, default=100, help="Number of training epochs"
    )
    parser.add_argument("--batch-size", type=int, default=32, help="Batch size")
    parser.add_argument(
        "--lookback",
        type=int,
        default=168,
        help="Lookback hours (default: 168 = 7 days)",
    )
    parser.add_argument(
        "--forecast", type=int, default=24, help="Forecast hours (default: 24 = 1 day)"
    )
    parser.add_argument(
        "--checkpoint-every",
        type=int,
        default=10,
        help="Save checkpoint every N epochs",
    )
    parser.add_argument("--gpu", type=int, default=0, help="GPU device ID")
    parser.add_argument(
        "--log-level",
        default="INFO",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help="Logging level",
    )

    args = parser.parse_args()

    # Configure logging
    logger.setLevel(getattr(logging, args.log_level))

    logger.info("=" * 60)
    logger.info("LSTM Weather Prediction Model Training")
    logger.info("Module 3: ML Weather Prediction Validator")
    logger.info("=" * 60)
    logger.info(f"Start time: {datetime.now()}")

    # Check TensorFlow installation
    if not check_tensorflow_installed():
        return 1

    import tensorflow as tf

    # Set GPU
    if args.gpu >= 0:
        gpus = tf.config.list_physical_devices("GPU")
        if gpus and args.gpu < len(gpus):
            try:
                tf.config.set_visible_devices(gpus[args.gpu], "GPU")
                logger.info(f"Using GPU: {gpus[args.gpu]}")
            except RuntimeError as e:
                logger.warning(f"Failed to set GPU: {e}")

    # Load weather data
    df = load_weather_data(args.data_dir)

    # Normalize data
    data, normalization_params, feature_names = normalize_data(df)

    # Save normalization parameters
    model_path = Path(args.model_dir)
    model_path.mkdir(parents=True, exist_ok=True)

    norm_params_file = model_path / "normalization_params.json"
    with open(norm_params_file, "w") as f:
        json.dump(
            {"params": normalization_params, "features": feature_names}, f, indent=2
        )
    logger.info(f"Saved normalization parameters: {norm_params_file}")

    # Create sequences
    X, y = create_sequences(data, args.lookback, args.forecast)

    # Split into train/val/test (70/15/15)
    n_samples = len(X)
    train_end = int(0.7 * n_samples)
    val_end = int(0.85 * n_samples)

    X_train, y_train = X[:train_end], y[:train_end]
    X_val, y_val = X[train_end:val_end], y[train_end:val_end]
    X_test, y_test = X[val_end:], y[val_end:]

    logger.info("Data split:")
    logger.info(
        f"  Train: {len(X_train)} samples ({len(X_train) / n_samples * 100:.1f}%)"
    )
    logger.info(f"  Val: {len(X_val)} samples ({len(X_val) / n_samples * 100:.1f}%)")
    logger.info(f"  Test: {len(X_test)} samples ({len(X_test) / n_samples * 100:.1f}%)")

    # Build model
    input_shape = (args.lookback, len(feature_names))
    output_shape = (args.forecast, len(feature_names))

    model = build_lstm_model(input_shape, output_shape)

    # Train model
    history = train_model(
        model,
        X_train,
        y_train,
        X_val,
        y_val,
        epochs=args.epochs,
        batch_size=args.batch_size,
        model_dir=args.model_dir,
        checkpoint_every=args.checkpoint_every,
    )

    # Evaluate on test set
    metrics, patent_validated = evaluate_model(
        model, X_test, y_test, normalization_params, feature_names
    )

    # Save evaluation results
    results = {
        "timestamp": datetime.now().isoformat(),
        "dataset_size": len(df),
        "train_samples": len(X_train),
        "val_samples": len(X_val),
        "test_samples": len(X_test),
        "lookback_hours": args.lookback,
        "forecast_hours": args.forecast,
        "epochs_trained": len(history.history["loss"]),
        "final_train_loss": float(history.history["loss"][-1]),
        "final_val_loss": float(history.history["val_loss"][-1]),
        "metrics": metrics,
        "patent_15_validated": patent_validated,
    }

    results_file = model_path / "evaluation_results.json"
    with open(results_file, "w") as f:
        json.dump(results, f, indent=2)
    logger.info(f"Saved evaluation results: {results_file}")

    logger.info("=" * 60)
    logger.info(f"Training completed: {datetime.now()}")
    logger.info(
        f"Patent #15 Status: {'VALIDATED ✓' if patent_validated else 'FAILED ✗'}"
    )
    logger.info("=" * 60)

    return 0 if patent_validated else 1


if __name__ == "__main__":
    sys.exit(main())
