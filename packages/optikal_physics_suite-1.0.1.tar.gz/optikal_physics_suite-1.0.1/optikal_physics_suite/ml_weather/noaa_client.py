#!/usr/bin/env python3
"""
NOAA NCEI API Client
Module 3: Weather Data Collection
Fetches last 30 days of weather data from NOAA National Centers for Environmental Information
Station: GHCND:USW00023174 (Seattle-Tacoma International Airport, WA)

API Documentation:
https://www.ncei.noaa.gov/products/weather-data-api

Required:
- NOAA NCEI API token (--token argument)
- Get token at: https://www.ncei.noaa.gov/products/weather-data-api
"""

import os
import sys
import csv
import json
import argparse
import logging
import requests
from pathlib import Path
from datetime import datetime, timedelta
from typing import Optional, Dict, List

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

# NOAA API configuration
NOAA_API_BASE = "https://api.ncei.noaa.gov/v1/data/cdo/stations/weather"
DEFAULT_STATION = "GHCND:USW00023174"  # Seattle-Tacoma International Airport, WA
REQUEST_TIMEOUT = 30  # seconds


class NOAAClient:
    """NOAA NCEI API client for weather data retrieval."""

    def __init__(self, token: str, station: str = DEFAULT_STATION):
        """
        Initialize NOAA client.

        Args:
            token (str): NOAA NCEI API token
            station (str): Station ID (GHCND:USXXXXXXX format)
        """
        self.token = token
        self.station = station
        self.session = requests.Session()
        self.session.headers.update(
            {
                "Accept": "application/json",
                "User-Agent": "GhostGrid-WeatherCollector/1.0",
            }
        )

    def fetch_data(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        limit: int = 1000,
    ) -> Optional[Dict]:
        """
        Fetch weather data from NOAA for specified date range.

        Args:
            start_date (str): Start date (YYYY-MM-DD), default: 30 days ago
            end_date (str): End date (YYYY-MM-DD), default: today
            limit (int): Maximum number of records to return

        Returns:
            dict: API response with weather data, or None if failed
        """

        # Set default dates (last 30 days)
        if not end_date:
            end_date = datetime.utcnow().strftime("%Y-%m-%d")

        if not start_date:
            start_date = (datetime.utcnow() - timedelta(days=30)).strftime("%Y-%m-%d")

        logger.info(f"Fetching NOAA data for station {self.station}")
        logger.info(f"Date range: {start_date} to {end_date}")

        params = {
            "token": self.token,
            "startDate": start_date,
            "endDate": end_date,
            "stationID": self.station,
            "limit": limit,
            "format": "json",
        }

        try:
            logger.info(f"Sending request to {NOAA_API_BASE}")
            response = self.session.get(
                NOAA_API_BASE, params=params, timeout=REQUEST_TIMEOUT
            )

            response.raise_for_status()

            data = response.json()

            if "results" in data:
                logger.info(f"Received {len(data['results'])} records from NOAA")
                return data
            else:
                logger.warning("No results in NOAA response")
                logger.debug(f"Response: {data}")
                return None

        except requests.exceptions.Timeout:
            logger.error(f"Request timed out after {REQUEST_TIMEOUT} seconds")
            return None

        except requests.exceptions.HTTPError as e:
            logger.error(f"HTTP error: {e.response.status_code}")
            logger.error(f"Response: {e.response.text}")

            if e.response.status_code == 401:
                logger.error("Unauthorized - check your NOAA API token")
            elif e.response.status_code == 404:
                logger.error(f"Station not found: {self.station}")

            return None

        except requests.exceptions.RequestException as e:
            logger.error(f"Request failed: {e}")
            return None

        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse JSON response: {e}")
            return None

    def parse_records(self, data: Dict) -> List[Dict]:
        """
        Parse NOAA API response into standardized weather records.

        NOAA provides various data types (PRCP, SNOW, TMAX, TMIN, etc.)
        This function aggregates available data into standard columns.

        Args:
            data (dict): NOAA API response

        Returns:
            list: Standardized weather records
        """

        if not data or "results" not in data:
            logger.warning("No data to parse")
            return []

        # Group records by date
        daily_data = {}

        for result in data["results"]:
            try:
                date = result.get("date", "")
                data_type = result.get("datatype", "")
                value = result.get("value")

                if not date or value is None:
                    continue

                if date not in daily_data:
                    daily_data[date] = {
                        "timestamp": date,
                        "temperature": None,
                        "humidity": None,
                        "visibility": None,
                        "pressure": None,
                        "wind_speed": None,
                        "precipitation": None,
                    }

                # Map NOAA data types to standard columns
                # Note: NOAA temperature data is in 1/10 degree C
                if data_type == "TMAX":
                    daily_data[date]["temperature"] = value / 10.0

                elif data_type == "PRCP":
                    # Precipitation in 1/10 mm
                    daily_data[date]["precipitation"] = value / 10.0

                elif data_type == "SNWD":
                    # Snow depth in mm
                    pass

                elif data_type == "RHAV":
                    # Average relative humidity
                    daily_data[date]["humidity"] = value

                elif data_type == "VISIB":
                    # Visibility in 1/10 km
                    daily_data[date]["visibility"] = value / 10.0

                elif data_type == "PRES":
                    # Pressure in 1/10 mb
                    daily_data[date]["pressure"] = value / 10.0

                elif data_type == "WSPD":
                    # Wind speed in 1/10 m/s
                    daily_data[date]["wind_speed"] = value / 10.0

            except (KeyError, ValueError) as e:
                logger.debug(f"Error parsing record: {e}")
                continue

        records = list(daily_data.values())
        logger.info(f"Parsed {len(records)} daily records")

        return records


def save_csv(records: List[Dict], output_file: str) -> bool:
    """
    Save weather records to CSV file.

    Args:
        records (list): Weather records
        output_file (str): Output file path

    Returns:
        bool: True if successful, False otherwise
    """

    output_path = Path(output_file)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    if not records:
        logger.warning("No records to save")
        return False

    fieldnames = [
        "timestamp",
        "temperature",
        "humidity",
        "visibility",
        "pressure",
        "wind_speed",
        "precipitation",
    ]

    try:
        with open(output_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(records)

        logger.info(f"Saved {len(records)} records to {output_path}")
        return True

    except Exception as e:
        logger.error(f"Failed to save CSV: {e}")
        return False


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="Fetch weather data from NOAA NCEI API"
    )
    parser.add_argument(
        "--token",
        required=True,
        help="NOAA NCEI API token (get from https://www.ncei.noaa.gov/products/weather-data-api)",
    )
    parser.add_argument(
        "--station",
        default=DEFAULT_STATION,
        help=f"Station ID (default: {DEFAULT_STATION})",
    )
    parser.add_argument(
        "--start-date", help="Start date (YYYY-MM-DD, default: 30 days ago)"
    )
    parser.add_argument("--end-date", help="End date (YYYY-MM-DD, default: today)")
    parser.add_argument(
        "--output-file",
        default=os.environ.get("OPTIKAL_DATA_DIR", "./data/weather_historical/noaa")
        + "/noaa_validation.csv",
        help="Output CSV file path (default: $OPTIKAL_DATA_DIR/noaa/noaa_validation.csv)",
    )
    parser.add_argument(
        "--limit", type=int, default=1000, help="Maximum number of records to fetch"
    )
    parser.add_argument(
        "--log-level",
        default="INFO",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help="Logging level",
    )

    args = parser.parse_args()

    # Configure logging level
    logger.setLevel(getattr(logging, args.log_level))

    logger.info("=" * 60)
    logger.info("NOAA NCEI Weather Data Collector")
    logger.info("=" * 60)

    # Validate token
    if not args.token or len(args.token) < 10:
        logger.error("Invalid NOAA API token provided")
        logger.error(
            "Get token at: https://www.ncei.noaa.gov/products/weather-data-api"
        )
        return 1

    # Create client
    client = NOAAClient(token=args.token, station=args.station)

    # Fetch data
    data = client.fetch_data(
        start_date=args.start_date, end_date=args.end_date, limit=args.limit
    )

    if not data:
        logger.error("Failed to fetch data from NOAA")
        return 1

    # Parse and save
    records = client.parse_records(data)

    if not save_csv(records, args.output_file):
        return 1

    logger.info("=" * 60)
    logger.info(f"Successfully collected {len(records)} records from NOAA")
    logger.info(f"Saved to: {args.output_file}")
    logger.info("=" * 60)

    return 0


if __name__ == "__main__":
    sys.exit(main())
