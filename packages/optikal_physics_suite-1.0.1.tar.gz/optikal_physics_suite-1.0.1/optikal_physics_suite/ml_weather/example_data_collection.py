#!/usr/bin/env python3
"""
Example: Collecting Weather Data from Multiple Sources
Module 3: Weather Data Collection

This script demonstrates how to collect weather data from all three sources
and combine them into a unified dataset for ML model training.
"""

import os
import csv
import logging
from pathlib import Path

logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


def example_kaggle_download():
    """
    Example 1: Download Szeged weather dataset from Kaggle.

    Requirements:
    - Kaggle API configured (~/.kaggle/kaggle.json)
    - Command: pip install kaggle
    """
    logger.info("=" * 70)
    logger.info("Example 1: Kaggle Dataset Download")
    logger.info("=" * 70)

    try:
        import kaggle_downloader

        # Check if Kaggle is configured
        if not kaggle_downloader.check_kaggle_credentials():
            logger.warning("Skipping Kaggle download - credentials not configured")
            logger.info("Setup instructions: See WEATHER_DATA_COLLECTION.md")
            return False

        # Download and process
        output_dir = Path("data/weather_historical/kaggle")
        success = kaggle_downloader.download_kaggle_dataset(str(output_dir))

        if success:
            # Find and process CSV files
            csv_files = kaggle_downloader.find_csv_files(str(output_dir))
            total_records = 0

            for csv_file in csv_files:
                records = kaggle_downloader.parse_szeged_weather(csv_file)
                if records:
                    output_file = output_dir / f"{csv_file.stem}_standardized.csv"
                    kaggle_downloader.save_standardized_csv(records, str(output_file))
                    total_records += len(records)

            logger.info(f"Successfully processed {total_records} records from Kaggle")
            return True

    except Exception as e:
        logger.error(f"Kaggle download failed: {e}")
        return False


def example_noaa_collection(api_token=None):
    """
    Example 2: Fetch weather data from NOAA NCEI API.

    Requirements:
    - NOAA API token (get from https://www.ncei.noaa.gov/products/weather-data-api)
    - Command: pip install requests
    """
    logger.info("=" * 70)
    logger.info("Example 2: NOAA NCEI API Collection")
    logger.info("=" * 70)

    # Get API token from environment or argument
    token = api_token or os.environ.get("NOAA_API_TOKEN")

    if not token:
        logger.warning("Skipping NOAA collection - API token not provided")
        logger.info("To get token: https://www.ncei.noaa.gov/products/weather-data-api")
        logger.info(
            "Usage: NOAA_API_TOKEN=your_token python example_data_collection.py"
        )
        logger.info("Or:    python noaa_client.py --token YOUR_TOKEN")
        return False

    try:
        import noaa_client

        # Create client and fetch data
        client = noaa_client.NOAAClient(
            token=token,
            station="GHCND:USW00023174",  # Seattle-Tacoma
        )

        data = client.fetch_data()
        if not data:
            logger.error("Failed to fetch from NOAA")
            return False

        # Parse and save
        records = client.parse_records(data)
        output_file = Path("data/weather_historical/noaa/noaa_validation.csv")
        success = noaa_client.save_csv(records, str(output_file))

        if success:
            logger.info(f"Successfully collected {len(records)} records from NOAA")
            return True

    except Exception as e:
        logger.error(f"NOAA collection failed: {e}")
        return False


def example_visual_crossing_collection(api_key=None):
    """
    Example 3: Fetch weather data from Visual Crossing API.

    Requirements:
    - Visual Crossing API key (get from https://www.visualcrossing.com/sign-up)
    - Command: pip install requests
    """
    logger.info("=" * 70)
    logger.info("Example 3: Visual Crossing API Collection")
    logger.info("=" * 70)

    # Get API key from environment or argument
    key = api_key or os.environ.get("VISUAL_CROSSING_KEY")

    if not key:
        logger.warning("Skipping Visual Crossing collection - API key not provided")
        logger.info("To get free key: https://www.visualcrossing.com/sign-up")
        logger.info("Free tier: 1,500 calls/day")
        logger.info(
            "Usage: VISUAL_CROSSING_KEY=your_key python example_data_collection.py"
        )
        logger.info("Or:    python visualcrossing_client.py --key YOUR_KEY")
        return False

    try:
        import visualcrossing_client

        # Create client and fetch hourly data
        client = visualcrossing_client.VisualCrossingClient(
            api_key=key, location="Seattle, WA"
        )

        data = client.fetch_data()
        if not data:
            logger.error("Failed to fetch from Visual Crossing")
            return False

        # Parse as hourly data (more granular)
        records = client.parse_records(data)
        output_file = Path(
            "data/weather_historical/visual_crossing/visual_crossing_validation.csv"
        )
        success = visualcrossing_client.save_csv(records, str(output_file))

        if success:
            logger.info(
                f"Successfully collected {len(records)} records from Visual Crossing"
            )
            return True

    except Exception as e:
        logger.error(f"Visual Crossing collection failed: {e}")
        return False


def combine_datasets():
    """
    Example 4: Combine weather data from multiple sources.

    Demonstrates merging datasets with different temporal resolutions.
    """
    logger.info("=" * 70)
    logger.info("Example 4: Combining Weather Data from Multiple Sources")
    logger.info("=" * 70)

    _datasets = {}  # Reserved for future multi-source aggregation
    combined_records = []

    # Paths to collected data
    data_sources = {
        "kaggle": Path("data/weather_historical/kaggle"),
        "noaa": Path("data/weather_historical/noaa/noaa_validation.csv"),
        "visual_crossing": Path(
            "data/weather_historical/visual_crossing/visual_crossing_validation.csv"
        ),
    }

    # Load each dataset
    for source_name, source_path in data_sources.items():
        if isinstance(source_path, Path) and source_path.is_dir():
            # Find standardized CSV files
            csv_files = list(source_path.glob("*_standardized.csv"))
        else:
            csv_files = [source_path] if source_path.exists() else []

        for csv_file in csv_files:
            if not csv_file.exists():
                logger.warning(f"Data file not found: {csv_file}")
                continue

            try:
                with open(csv_file, "r", encoding="utf-8") as f:
                    reader = csv.DictReader(f)
                    records = list(reader)
                    combined_records.extend(records)

                    logger.info(
                        f"Loaded {len(records)} records from {source_name}/{csv_file.name}"
                    )

            except Exception as e:
                logger.error(f"Error reading {csv_file}: {e}")

    if not combined_records:
        logger.warning("No data found to combine")
        return False

    # Save combined dataset
    output_file = Path("data/weather_historical/COMBINED_weather_data.csv")
    output_file.parent.mkdir(parents=True, exist_ok=True)

    try:
        fieldnames = [
            "timestamp",
            "temperature",
            "humidity",
            "visibility",
            "pressure",
            "wind_speed",
            "precipitation",
        ]

        with open(output_file, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(combined_records)

        logger.info(f"Combined {len(combined_records)} records saved to {output_file}")
        return True

    except Exception as e:
        logger.error(f"Failed to save combined dataset: {e}")
        return False


def validate_csv_format(csv_file):
    """
    Example 5: Validate that output CSV files match expected schema.

    Checks:
    - Required columns present
    - Data types are valid
    - No excessive missing values
    """
    logger.info("=" * 70)
    logger.info(f"Example 5: Validating CSV Format - {csv_file}")
    logger.info("=" * 70)

    required_columns = [
        "timestamp",
        "temperature",
        "humidity",
        "visibility",
        "pressure",
        "wind_speed",
        "precipitation",
    ]

    try:
        with open(csv_file, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)

            # Check columns
            if not reader.fieldnames:
                logger.error("CSV has no header row")
                return False

            missing_cols = set(required_columns) - set(reader.fieldnames)
            if missing_cols:
                logger.error(f"Missing required columns: {missing_cols}")
                return False

            # Validate rows
            valid_rows = 0
            invalid_rows = 0
            missing_value_count = 0

            for i, row in enumerate(reader, start=2):
                try:
                    # Validate timestamp format
                    timestamp = row.get("timestamp", "").strip()
                    if not timestamp:
                        invalid_rows += 1
                        continue

                    # Validate numeric columns
                    for col in [
                        "temperature",
                        "humidity",
                        "visibility",
                        "pressure",
                        "wind_speed",
                        "precipitation",
                    ]:
                        value = row.get(col, "")
                        if value:
                            try:
                                float(value)
                            except ValueError:
                                logger.warning(f"Row {i}: Invalid {col} value: {value}")
                                invalid_rows += 1
                                break
                        else:
                            missing_value_count += 1
                    else:
                        valid_rows += 1

                except Exception as e:
                    logger.debug(f"Row {i}: {e}")
                    invalid_rows += 1

            logger.info(f"Valid rows: {valid_rows}")
            logger.info(f"Invalid rows: {invalid_rows}")
            logger.info(f"Missing values: {missing_value_count}")

            if valid_rows > 0:
                logger.info("CSV format validation: PASSED")
                return True
            else:
                logger.error("CSV format validation: FAILED")
                return False

    except FileNotFoundError:
        logger.warning(f"File not found: {csv_file}")
        return False
    except Exception as e:
        logger.error(f"Validation failed: {e}")
        return False


def main():
    """
    Run all examples in sequence.

    Set environment variables to enable API-based collection:
    - NOAA_API_TOKEN: NOAA NCEI API token
    - VISUAL_CROSSING_KEY: Visual Crossing API key

    Example:
        NOAA_API_TOKEN=xxx VISUAL_CROSSING_KEY=yyy python example_data_collection.py
    """

    logger.info("\n" + "=" * 70)
    logger.info("GhostGrid Weather Data Collection Examples")
    logger.info("Module 3: Multi-Source Data Integration")
    logger.info("=" * 70 + "\n")

    results = {}

    # Example 1: Kaggle download (no API key required, uses local credentials)
    results["Kaggle"] = example_kaggle_download()
    logger.info()

    # Example 2: NOAA collection (requires API token)
    results["NOAA"] = example_noaa_collection()
    logger.info()

    # Example 3: Visual Crossing collection (requires API key)
    results["Visual Crossing"] = example_visual_crossing_collection()
    logger.info()

    # Example 4: Combine datasets
    results["Combine"] = combine_datasets()
    logger.info()

    # Example 5: Validate CSV formats
    validation_files = [
        Path("data/weather_historical/noaa/noaa_validation.csv"),
        Path("data/weather_historical/visual_crossing/visual_crossing_validation.csv"),
        Path("data/weather_historical/COMBINED_weather_data.csv"),
    ]

    for csv_file in validation_files:
        if csv_file.exists():
            validate_csv_format(csv_file)
            logger.info()

    # Summary
    logger.info("=" * 70)
    logger.info("Summary")
    logger.info("=" * 70)
    logger.info("Results:")
    for source, success in results.items():
        status = "SUCCESS" if success else "SKIPPED/FAILED"
        logger.info(f"  {source}: {status}")

    logger.info("\nNext Steps:")
    logger.info("1. Verify data files in data/weather_historical/")
    logger.info("2. Use combined dataset for ML model training")
    logger.info("3. Check WEATHER_DATA_COLLECTION.md for additional options")

    logger.info("=" * 70 + "\n")


if __name__ == "__main__":
    main()
