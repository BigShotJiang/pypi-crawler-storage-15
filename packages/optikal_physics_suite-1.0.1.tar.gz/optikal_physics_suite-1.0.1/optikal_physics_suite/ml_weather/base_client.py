#!/usr/bin/env python3
"""
Weather API Base Client
Provides common functionality for all weather data collection clients.

This abstract base class handles:
- Session management with retry logic
- Rate limiting
- Error handling and logging
- Data validation and standardization
- CSV export utilities
"""

import csv
import logging
import time
from abc import ABC, abstractmethod
from pathlib import Path
from datetime import datetime, timedelta
from typing import Optional, Dict, List
from urllib3.util.retry import Retry
from requests.adapters import HTTPAdapter
import requests

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)


class WeatherAPIBaseClient(ABC):
    """
    Abstract base class for weather API clients.

    Provides common functionality:
    - HTTP session with retry logic
    - Rate limiting support
    - Standardized error handling
    - CSV export utilities
    - Data validation
    """

    # Default configuration (override in subclasses)
    API_BASE_URL: str = ""
    REQUEST_TIMEOUT: int = 30
    MAX_RETRIES: int = 3
    RETRY_BACKOFF: float = 0.5
    RATE_LIMIT_DELAY: float = 0.1  # seconds between requests
    USER_AGENT: str = "OptikalPhysicsSuite-WeatherCollector/1.0"

    # Standard CSV columns for weather data
    STANDARD_COLUMNS = [
        "timestamp",
        "temperature_c",
        "humidity_pct",
        "pressure_hpa",
        "visibility_km",
        "wind_speed_mps",
        "wind_direction_deg",
        "precipitation_mm",
        "cloud_cover_pct",
    ]

    def __init__(self, api_key: str, **kwargs):
        """
        Initialize the weather API client.

        Args:
            api_key: API key for authentication
            **kwargs: Additional configuration options
        """
        self.api_key = api_key
        self.logger = logging.getLogger(self.__class__.__name__)
        self._last_request_time = 0

        # Create session with retry logic
        self.session = self._create_session()

    def _create_session(self) -> requests.Session:
        """Create HTTP session with retry logic and proper headers."""
        session = requests.Session()

        # Configure retry strategy
        retry_strategy = Retry(
            total=self.MAX_RETRIES,
            backoff_factor=self.RETRY_BACKOFF,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["GET", "POST"],
        )

        adapter = HTTPAdapter(max_retries=retry_strategy)
        session.mount("http://", adapter)
        session.mount("https://", adapter)

        # Set default headers
        session.headers.update(
            {"Accept": "application/json", "User-Agent": self.USER_AGENT}
        )

        return session

    def _rate_limit(self) -> None:
        """Enforce rate limiting between requests."""
        elapsed = time.time() - self._last_request_time
        if elapsed < self.RATE_LIMIT_DELAY:
            time.sleep(self.RATE_LIMIT_DELAY - elapsed)
        self._last_request_time = time.time()

    def _make_request(
        self, url: str, params: Optional[Dict] = None, method: str = "GET"
    ) -> Optional[Dict]:
        """
        Make HTTP request with error handling.

        Args:
            url: Request URL
            params: Query parameters
            method: HTTP method (GET or POST)

        Returns:
            Response JSON or None if failed
        """
        self._rate_limit()

        try:
            self.logger.debug(f"Requesting: {url}")

            if method.upper() == "GET":
                response = self.session.get(
                    url, params=params, timeout=self.REQUEST_TIMEOUT
                )
            else:
                response = self.session.post(
                    url, json=params, timeout=self.REQUEST_TIMEOUT
                )

            response.raise_for_status()
            return response.json()

        except requests.exceptions.Timeout:
            self.logger.error(f"Request timeout: {url}")
            return None
        except requests.exceptions.HTTPError as e:
            self.logger.error(f"HTTP error: {e}")
            return None
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Request failed: {e}")
            return None
        except ValueError as e:
            self.logger.error(f"Invalid JSON response: {e}")
            return None

    @abstractmethod
    def fetch_data(
        self, start_date: Optional[str] = None, end_date: Optional[str] = None, **kwargs
    ) -> Optional[Dict]:
        """
        Fetch weather data for date range.

        Args:
            start_date: Start date (YYYY-MM-DD)
            end_date: End date (YYYY-MM-DD)
            **kwargs: Additional provider-specific parameters

        Returns:
            Raw API response data
        """
        pass

    @abstractmethod
    def standardize_data(self, raw_data: Dict) -> List[Dict]:
        """
        Convert provider-specific data to standard format.

        Args:
            raw_data: Raw API response

        Returns:
            List of records with standard column names
        """
        pass

    def get_default_date_range(self, days: int = 30) -> tuple:
        """
        Get default date range (last N days).

        Args:
            days: Number of days to look back

        Returns:
            Tuple of (start_date, end_date) strings
        """
        end_date = datetime.utcnow().strftime("%Y-%m-%d")
        start_date = (datetime.utcnow() - timedelta(days=days)).strftime("%Y-%m-%d")
        return start_date, end_date

    def save_to_csv(
        self, data: List[Dict], output_path: str, columns: Optional[List[str]] = None
    ) -> bool:
        """
        Save weather data to CSV file.

        Args:
            data: List of weather records
            output_path: Output file path
            columns: Column names (default: STANDARD_COLUMNS)

        Returns:
            True if successful
        """
        if not data:
            self.logger.warning("No data to save")
            return False

        columns = columns or self.STANDARD_COLUMNS
        output_path = Path(output_path)

        # Create directory if needed
        output_path.parent.mkdir(parents=True, exist_ok=True)

        try:
            with open(output_path, "w", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(f, fieldnames=columns, extrasaction="ignore")
                writer.writeheader()
                writer.writerows(data)

            self.logger.info(f"Saved {len(data)} records to {output_path}")
            return True

        except IOError as e:
            self.logger.error(f"Failed to save CSV: {e}")
            return False

    def validate_data(self, records: List[Dict]) -> List[Dict]:
        """
        Validate and clean weather data records.

        Args:
            records: List of weather records

        Returns:
            Cleaned records with valid data
        """
        valid_records = []

        for record in records:
            # Skip records without timestamp
            if not record.get("timestamp"):
                continue

            # Validate numeric fields
            for field in [
                "temperature_c",
                "humidity_pct",
                "pressure_hpa",
                "visibility_km",
                "wind_speed_mps",
                "precipitation_mm",
            ]:
                if field in record and record[field] is not None:
                    try:
                        record[field] = float(record[field])
                    except (ValueError, TypeError):
                        record[field] = None

            valid_records.append(record)

        self.logger.info(f"Validated {len(valid_records)}/{len(records)} records")
        return valid_records
