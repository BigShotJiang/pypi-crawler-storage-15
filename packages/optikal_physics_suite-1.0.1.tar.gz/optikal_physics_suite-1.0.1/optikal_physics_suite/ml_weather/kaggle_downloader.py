#!/usr/bin/env python3
"""
Kaggle Weather Dataset Downloader
Module 3: Weather Data Collection
Downloads Szeged weather dataset with visibility data from Kaggle
Requires Kaggle API credentials configured in ~/.kaggle/kaggle.json
"""

import os
import sys
import csv
import argparse
import logging
from pathlib import Path

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


def check_kaggle_installed():
    """Check if kaggle package is installed."""
    try:
        import kaggle  # noqa: F401

        return True
    except ImportError:
        logger.error("Kaggle package not installed. Install with: pip install kaggle")
        return False


def check_kaggle_credentials():
    """Check if Kaggle API credentials are configured."""
    kaggle_json = Path.home() / ".kaggle" / "kaggle.json"

    if not kaggle_json.exists():
        logger.error(
            f"Kaggle credentials not found at {kaggle_json}\n"
            "Follow setup instructions at: https://github.com/Kaggle/kaggle-api#api-credentials"
        )
        return False

    # Check file permissions (should be 600 for security)
    perms = os.stat(kaggle_json).st_mode & 0o777
    if perms != 0o600 and perms != 0o644:  # Allow 644 for some systems
        logger.warning(f"Kaggle credentials file has unusual permissions: {oct(perms)}")

    return True


def download_kaggle_dataset(output_dir):
    """
    Download Szeged weather dataset from Kaggle.

    Dataset: budincsevity/szeged-weather
    URL: https://www.kaggle.com/datasets/budincsevity/szeged-weather

    Args:
        output_dir (str): Directory to save downloaded dataset

    Returns:
        bool: True if successful, False otherwise
    """
    try:
        import kaggle
    except ImportError:
        logger.error("Kaggle package not available")
        return False

    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    dataset_name = "budincsevity/szeged-weather"

    logger.info(f"Downloading Szeged weather dataset: {dataset_name}")
    logger.info(f"Output directory: {output_path}")

    try:
        kaggle.api.dataset_download_files(dataset_name, path=output_path, unzip=True)
        logger.info("Download completed successfully")
        return True

    except Exception as e:
        logger.error(f"Failed to download dataset: {e}")
        logger.error(
            "Verify that Kaggle credentials are properly configured:\n"
            "1. Visit https://www.kaggle.com/settings/account\n"
            "2. Click 'Create New API Token'\n"
            "3. Place kaggle.json in ~/.kaggle/\n"
            "4. Run: chmod 600 ~/.kaggle/kaggle.json"
        )
        return False


def find_csv_files(directory):
    """Find all CSV files in the downloaded dataset."""
    csv_files = list(Path(directory).glob("*.csv"))
    logger.info(f"Found {len(csv_files)} CSV files:")
    for csv_file in csv_files:
        logger.info(f"  - {csv_file.name}")
    return csv_files


def parse_szeged_weather(csv_path):
    """
    Parse Szeged weather CSV and standardize to common format.

    Expected Szeged columns:
    - Formatted Date / Date
    - Temperature (C)
    - Apparent Temperature (C)
    - Humidity
    - Wind Speed (km/h)
    - Wind Bearing (degrees)
    - Visibility (km)
    - Loud Cover (or Cloud Cover)
    - Pressure (millibars)
    - Precipitation (mm)
    - Precipitation Type

    Standard output columns:
    - timestamp (ISO format)
    - temperature (C)
    - humidity (%)
    - visibility (km)
    - pressure (mb)
    - wind_speed (m/s)
    - precipitation (mm)
    """

    logger.info(f"Parsing Szeged weather data: {csv_path.name}")

    records = []
    _col_mapping = {}  # Reserved for future column remapping

    with open(csv_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)

        # Identify columns (Szeged format variations)
        if reader.fieldnames:
            logger.info(f"Columns found: {reader.fieldnames}")

            # Create mapping for flexible column names
            col_lower = {col.lower().strip(): col for col in reader.fieldnames}

            # Map to standard names
            date_col = next(
                (
                    col_lower[key]
                    for key in ["formatted date", "date", "datetime"]
                    if key in col_lower
                ),
                None,
            )
            temp_col = next(
                (
                    col_lower[key]
                    for key in ["temperature (c)", "temperature", "temp"]
                    if key in col_lower
                ),
                None,
            )
            humidity_col = next(
                (
                    col_lower[key]
                    for key in ["humidity", "relative humidity"]
                    if key in col_lower
                ),
                None,
            )
            visibility_col = next(
                (
                    col_lower[key]
                    for key in ["visibility (km)", "visibility"]
                    if key in col_lower
                ),
                None,
            )
            pressure_col = next(
                (
                    col_lower[key]
                    for key in ["pressure (millibars)", "pressure (mb)", "pressure"]
                    if key in col_lower
                ),
                None,
            )
            wind_col = next(
                (
                    col_lower[key]
                    for key in ["wind speed (km/h)", "wind speed (m/s)", "wind speed"]
                    if key in col_lower
                ),
                None,
            )
            precip_col = next(
                (
                    col_lower[key]
                    for key in ["precipitation (mm)", "precipitation"]
                    if key in col_lower
                ),
                None,
            )

            logger.info(
                f"Mapped columns:\n"
                f"  date: {date_col}\n"
                f"  temperature: {temp_col}\n"
                f"  humidity: {humidity_col}\n"
                f"  visibility: {visibility_col}\n"
                f"  pressure: {pressure_col}\n"
                f"  wind_speed: {wind_col}\n"
                f"  precipitation: {precip_col}"
            )

        # Parse rows
        row_count = 0
        for row in reader:
            try:
                # Extract and convert values
                timestamp = row.get(date_col, "").strip() if date_col else ""
                temperature = float(row.get(temp_col, 0) or 0) if temp_col else None
                humidity = (
                    float(row.get(humidity_col, 0) or 0) if humidity_col else None
                )
                visibility = (
                    float(row.get(visibility_col, 0) or 0) if visibility_col else None
                )
                pressure = (
                    float(row.get(pressure_col, 0) or 0) if pressure_col else None
                )

                # Convert wind speed from km/h to m/s if needed
                wind_speed_raw = float(row.get(wind_col, 0) or 0) if wind_col else None
                wind_speed = (
                    wind_speed_raw / 3.6 if wind_speed_raw else None
                )  # km/h to m/s

                precipitation = (
                    float(row.get(precip_col, 0) or 0) if precip_col else None
                )

                if timestamp:
                    records.append(
                        {
                            "timestamp": timestamp,
                            "temperature": temperature,
                            "humidity": humidity,
                            "visibility": visibility,
                            "pressure": pressure,
                            "wind_speed": wind_speed,
                            "precipitation": precipitation,
                        }
                    )
                    row_count += 1

            except (ValueError, KeyError) as e:
                logger.debug(f"Error parsing row: {e}")
                continue

    logger.info(f"Parsed {row_count} records from {csv_path.name}")
    return records


def save_standardized_csv(records, output_file):
    """Save records in standardized CSV format."""
    output_path = Path(output_file)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    if not records:
        logger.warning("No records to save")
        return False

    fieldnames = [
        "timestamp",
        "temperature",
        "humidity",
        "visibility",
        "pressure",
        "wind_speed",
        "precipitation",
    ]

    try:
        with open(output_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(records)

        logger.info(f"Saved {len(records)} records to {output_path}")
        return True

    except Exception as e:
        logger.error(f"Failed to save CSV: {e}")
        return False


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="Download Szeged weather dataset from Kaggle"
    )
    parser.add_argument(
        "--output-dir",
        default=os.environ.get("OPTIKAL_DATA_DIR", "./data/weather_historical")
        + "/kaggle",
        help="Directory to save downloaded dataset (default: $OPTIKAL_DATA_DIR/kaggle)",
    )
    parser.add_argument(
        "--standardize",
        action="store_true",
        default=True,
        help="Convert to standardized CSV format",
    )
    parser.add_argument(
        "--log-level",
        default="INFO",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help="Logging level",
    )

    args = parser.parse_args()

    # Configure logging level
    logger.setLevel(getattr(logging, args.log_level))

    logger.info("=" * 60)
    logger.info("Kaggle Weather Dataset Downloader")
    logger.info("=" * 60)

    # Check prerequisites
    if not check_kaggle_installed():
        logger.error("Kaggle package required. Install with: pip install kaggle")
        return 1

    if not check_kaggle_credentials():
        return 1

    # Download dataset
    if not download_kaggle_dataset(args.output_dir):
        return 1

    # Find and process CSV files
    csv_files = find_csv_files(args.output_dir)

    if not csv_files:
        logger.warning("No CSV files found in downloaded dataset")
        return 1

    # Process and standardize each CSV
    total_records = 0
    for csv_file in csv_files:
        records = parse_szeged_weather(csv_file)

        if args.standardize and records:
            output_file = Path(args.output_dir) / f"{csv_file.stem}_standardized.csv"
            if save_standardized_csv(records, str(output_file)):
                total_records += len(records)

    logger.info("=" * 60)
    logger.info(f"Total records processed: {total_records}")
    logger.info("Dataset download and processing completed successfully")
    logger.info("=" * 60)

    return 0


if __name__ == "__main__":
    sys.exit(main())
