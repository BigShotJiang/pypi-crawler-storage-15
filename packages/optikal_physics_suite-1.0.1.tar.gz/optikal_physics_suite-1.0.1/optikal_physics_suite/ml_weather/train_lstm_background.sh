#!/bin/bash
# LSTM Weather Prediction Training - Background Process
# Runs training with logging, checkpointing, and auto-resume

LOGDIR="logs/lstm_training"
DATADIR="data/weather_historical"
MODELDIR="models/weather_lstm"

mkdir -p "$LOGDIR" "$MODELDIR"

TIMESTAMP=$(date +%Y%m%d_%H%M%S)
LOGFILE="$LOGDIR/training_$TIMESTAMP.log"

echo "Starting LSTM training at $TIMESTAMP" | tee -a "$LOGFILE"
echo "GPU: NVIDIA GeForce RTX 4060 Ti" | tee -a "$LOGFILE"
echo "Dataset: 97,198 hourly records" | tee -a "$LOGFILE"
echo "Log file: $LOGFILE" | tee -a "$LOGFILE"
echo "=====================================" | tee -a "$LOGFILE"

# Run Python training script with nohup for reliability
nohup python -u src/ml_weather/train_lstm_model.py \
  --data-dir "$DATADIR" \
  --model-dir "$MODELDIR" \
  --epochs 100 \
  --batch-size 32 \
  --gpu 0 \
  --checkpoint-every 10 \
  --log-level INFO \
  >> "$LOGFILE" 2>&1 &

PID=$!
echo "Training process started with PID: $PID" | tee -a "$LOGFILE"
echo "$PID" > "$LOGDIR/training.pid"

echo ""
echo "Monitor progress:"
echo "  tail -f $LOGFILE"
echo ""
echo "Check status:"
echo "  ps -p $PID"
echo ""
echo "Stop training:"
echo "  kill $PID"

