"""
Optikal Physics Suite - Core Package
=====================================

Comprehensive physics simulation framework for optical communications,
including Free-Space Optical (FSO) systems, atmospheric propagation,
orbital mechanics, and ML-based weather prediction.

Modules:
--------
- optical: Gaussian beam propagation, atmospheric attenuation
- orbital: Space environment simulation, radiation effects, vacuum propagation
- ml_weather: LSTM weather prediction, multi-source data collection
- weather: Real-time weather API integrations

Author: Netrun Systems
License: MIT
Version: 1.0.0
"""

__version__ = "1.0.1"
__author__ = "Netrun Systems"
__license__ = "MIT"

# Import key classes for convenience
from optikal_physics_suite.optical.beam_propagation import (
    GaussianBeam,
    BeamPropagator,
    calculate_beam_divergence,
    calculate_rayleigh_range,
)

from optikal_physics_suite.optical.atmospheric_constants import (
    FogCategory,
    ATTENUATION_DB_PER_KM,
    VISIBILITY_KM,
    TriBandCharacteristics,
    LinkStateModel,
    TopologyConstraints,
    SpatialWeatherModel,
)

from optikal_physics_suite.orbital.space_environment import (
    OrbitType,
    SpaceLinkParameters,
    VacuumPropagation,
    SpaceRadiationEffects,
    SpaceThermalEnvironment,
    SpaceEnvironment,
)

__all__ = [
    # Version info
    "__version__",
    "__author__",
    "__license__",
    # Optical beam propagation
    "GaussianBeam",
    "BeamPropagator",
    "calculate_beam_divergence",
    "calculate_rayleigh_range",
    # Atmospheric constants
    "FogCategory",
    "ATTENUATION_DB_PER_KM",
    "VISIBILITY_KM",
    "TriBandCharacteristics",
    "LinkStateModel",
    "TopologyConstraints",
    "SpatialWeatherModel",
    # Space environment
    "OrbitType",
    "SpaceLinkParameters",
    "VacuumPropagation",
    "SpaceRadiationEffects",
    "SpaceThermalEnvironment",
    "SpaceEnvironment",
]
