"""
Orbital Mechanics & Space Environment Module
============================================

FSO communication simulation for space environments, including:
- Vacuum propagation (no atmospheric loss)
- Radiation effects (cosmic rays, Van Allen belts)
- Thermal extremes (+120°C to -150°C)
- Orbital debris detection validation (Patent #22)

Classes:
--------
- OrbitType: Orbital altitude classifications (LEO/MEO/GEO/HEO)
- SpaceLinkParameters: FSO link configuration for space
- VacuumPropagation: Geometric spreading and diffraction in vacuum
- SpaceRadiationEffects: Radiation-induced performance degradation
- SpaceThermalEnvironment: Temperature effects on FSO transceivers
- SpaceEnvironment: Complete space environment model

Functions:
----------
- validate_patent_22_orbital_debris_fso: Patent #22 validation test
"""

from optikal_physics_suite.orbital.space_environment import (
    OrbitType,
    SpaceLinkParameters,
    VacuumPropagation,
    SpaceRadiationEffects,
    SpaceThermalEnvironment,
    SpaceEnvironment,
    validate_patent_22_orbital_debris_fso,
)

__all__ = [
    "OrbitType",
    "SpaceLinkParameters",
    "VacuumPropagation",
    "SpaceRadiationEffects",
    "SpaceThermalEnvironment",
    "SpaceEnvironment",
    "validate_patent_22_orbital_debris_fso",
]
