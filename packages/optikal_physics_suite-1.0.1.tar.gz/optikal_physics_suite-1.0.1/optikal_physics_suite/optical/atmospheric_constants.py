"""
GhostGrid Atmospheric Attenuation Constants
============================================

VALIDATED atmospheric propagation parameters for FSO link budgets.
Updated: 2025-11-29 based on technical validation workshop.

CRITICAL CORRECTIONS FROM GPT-5.1 VALIDATION:
1. Array diversity gain: CONSERVATIVE estimates (not optimistic)
2. Fog attenuation categories: CORRECTED units (dB/km NOT dB/100m)
3. Tri-band purpose: CAPACITY not weather diversity
4. Weather spatial model: REQUIRED for mesh resilience

References:
- Kim et al., "Comparison of laser beam propagation" (2001)
- ITU-R P.1814: Free-space optical link prediction
- GPT-5.1 GhostGrid Workshop Validation Report (2025-11-29)
"""

from enum import Enum
from dataclasses import dataclass
from typing import Dict


class FogCategory(Enum):
    """
    Fog attenuation categories (CORRECTED).

    Units: dB/km (NOT dB/100m - this was a previous error)
    """

    CLEAR = "clear"  # >50 km visibility
    HAZE = "haze"  # 10-50 km visibility
    LIGHT_FOG = (
        "light_fog"  # 2-10 km visibility (was labeled incorrectly as "moderate")
    )
    MODERATE_FOG = "moderate_fog"  # 0.5-2 km visibility (was labeled as "heavy")
    HEAVY_FOG = "heavy_fog"  # 0.2-0.5 km visibility (NEW category)
    DENSE_FOG = "dense_fog"  # <0.2 km visibility (link failure)


# Atmospheric attenuation in dB/km (CORRECTED UNITS)
ATTENUATION_DB_PER_KM: Dict[FogCategory, float] = {
    FogCategory.CLEAR: 0.2,  # 0.02 dB/100m
    FogCategory.HAZE: 3.0,  # 0.3 dB/100m
    FogCategory.LIGHT_FOG: 30.0,  # 3 dB/100m (previously correct)
    FogCategory.MODERATE_FOG: 100.0,  # 10 dB/100m (relabeled from "heavy")
    FogCategory.HEAVY_FOG: 200.0,  # 20 dB/100m (NEW - true heavy fog)
    FogCategory.DENSE_FOG: 350.0,  # 35 dB/100m (link failure threshold)
}


# Visibility mapping (km)
VISIBILITY_KM: Dict[FogCategory, float] = {
    FogCategory.CLEAR: 50.0,
    FogCategory.HAZE: 20.0,
    FogCategory.LIGHT_FOG: 5.0,
    FogCategory.MODERATE_FOG: 1.0,
    FogCategory.HEAVY_FOG: 0.3,
    FogCategory.DENSE_FOG: 0.1,
}


@dataclass
class TriBandCharacteristics:
    """
    Tri-band (1490/1550/1625 nm) purpose clarification.

    CRITICAL MISCONCEPTION CORRECTION:
    Tri-band provides CAPACITY (WDM), NOT weather diversity.
    All three wavelengths are in the same atmospheric window.
    Fog affects all similarly.

    Weather resilience comes from MESH PATH DIVERSITY, not wavelength.
    """

    WAVELENGTHS_NM: tuple = (1490, 1550, 1625)

    # Purpose (CORRECTED)
    PURPOSE_WDM_CAPACITY: bool = True  # 3x capacity via WDM
    PURPOSE_CHANNEL_SEPARATION: bool = True  # Control/data/backup separation
    PURPOSE_WEATHER_DIVERSITY: bool = False  # COMMON MISCONCEPTION - all in same window

    # Atmospheric window properties
    ATMOSPHERIC_WINDOW: str = "C-band (1530-1565 nm) + extended"
    FOG_AFFECTS_ALL_SIMILARLY: bool = True

    # Resilience mechanism (CORRECTED)
    WEATHER_RESILIENCE_SOURCE: str = "MESH PATH DIVERSITY (routing around fog cells)"


@dataclass
class LinkStateModel:
    """
    Link state definitions for GhostGrid mesh.

    CRITICAL: Each node maintains ACTIVE vs. WARM STANDBY links.
    Not all links are active simultaneously.
    """

    # Link states
    STATE_ACTIVE: str = "active"  # Full throughput, 2 per node max
    STATE_WARM_STANDBY: str = "warm"  # Keepalive only, ready for promotion
    STATE_FAILED: str = "failed"  # Link down
    STATE_ACQUIRING: str = "acquiring"  # Beam alignment in progress

    # Per-node active link limit
    MAX_ACTIVE_LINKS_PER_NODE: int = 2  # 2 concurrent active links
    WARM_STANDBY_LINKS: int = 1  # Minimum 1 standby (third peer)

    # Promotion timing
    STANDBY_TO_ACTIVE_MS: float = 500.0  # <500ms failover


@dataclass
class TopologyConstraints:
    """
    K3/K4 topology validation requirements.

    GhostGrid requires 2-edge-connected topology (K3 minimum).
    """

    # Minimum requirements
    MIN_NODES: int = 3  # K3 = 3 nodes minimum
    MIN_DEGREE_PER_NODE: int = 2  # Each node needs ≥2 edges

    # Connectivity
    REQUIRED_EDGE_CONNECTIVITY: int = 2  # 2-edge-connected graph

    # Fault tolerance
    SURVIVES_SINGLE_NODE_FAILURE: bool = True
    SURVIVES_SINGLE_LINK_FAILURE: bool = True


@dataclass
class SpatialWeatherModel:
    """
    Weather spatial correlation model.

    CRITICAL: Fog is spatially variable. Adjacent links may have
    different conditions. This enables mesh routing around fog cells.
    """

    # Spatial correlation parameters
    FOG_COHERENCE_LENGTH_M: float = 100.0  # Typical fog cell size
    TURBULENCE_COHERENCE_MM: float = 20.0  # Atmospheric coherence length

    # Mesh benefits
    SPATIAL_DIVERSITY_ENABLED: bool = True
    ROUTING_AROUND_FOG_CELLS: bool = True  # Primary weather resilience mechanism

    # Model type
    MODEL_TYPE: str = "Spatially variable fog density map"


# Tri-band clarification
TRI_BAND_IS_FOR_CAPACITY = TriBandCharacteristics.PURPOSE_WDM_CAPACITY
TRI_BAND_NOT_WEATHER_DIVERSITY = not TriBandCharacteristics.PURPOSE_WEATHER_DIVERSITY

# Link states
LINK_STATE_ACTIVE = LinkStateModel.STATE_ACTIVE
LINK_STATE_WARM_STANDBY = LinkStateModel.STATE_WARM_STANDBY
MAX_ACTIVE_LINKS = LinkStateModel.MAX_ACTIVE_LINKS_PER_NODE

# Topology requirements
MIN_NODES_K3 = TopologyConstraints.MIN_NODES
MIN_DEGREE = TopologyConstraints.MIN_DEGREE_PER_NODE
