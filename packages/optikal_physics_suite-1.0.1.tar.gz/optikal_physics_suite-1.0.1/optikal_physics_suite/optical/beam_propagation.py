"""
Optikal Beam Propagation Module
================================

Gaussian beam modeling and propagation for FSO links.

Implements physics-based beam propagation using Gaussian beam optics,
with optional Optiland integration for advanced modeling.

Key Features:
- Gaussian beam parameter calculation (waist, divergence, Rayleigh range)
- GPU-accelerated propagation (optional PyTorch)
- Integration with Optiland for complex optical systems (optional)

References:
- Saleh & Teich, "Fundamentals of Photonics" (2007)
- IEC 60825-1: Safety of laser products
"""

from dataclasses import dataclass
from typing import Tuple
import numpy as np
import warnings

# Optional dependencies
try:
    import optiland  # noqa: F401

    HAS_OPTILAND = True
except ImportError:
    HAS_OPTILAND = False
    warnings.warn(
        "Optiland not installed. Advanced optical modeling disabled. "
        "Install with: pip install optiland",
        ImportWarning,
    )

try:
    import torch  # noqa: F401

    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False
    warnings.warn(
        "PyTorch not installed. GPU acceleration disabled. "
        "Install with: pip install torch",
        ImportWarning,
    )


@dataclass
class GaussianBeam:
    """
    Gaussian beam representation and propagation.

    Models a TEM00 Gaussian laser beam with physical parameters for FSO links.

    Attributes:
        wavelength: Wavelength in nanometers (850 or 1550 typical)
        power: Beam power in milliwatts (<0.39 mW for Class 1 safety)
        waist: Beam waist radius in millimeters at source
        position: (x, y, z) position of beam waist in meters

    Examples:
        >>> # 850nm VCSEL with Class 1 safety
        >>> beam = GaussianBeam(wavelength=850, power=0.39, waist=1.0)
        >>> divergence = beam.calculate_divergence()
        >>> print(f"Divergence: {divergence:.2f} mrad")
        Divergence: 0.43 mrad

        >>> # Beam radius at 100m
        >>> radius = beam.radius_at_distance(100)
        >>> print(f"Beam radius at 100m: {radius:.2f} mm")
        Beam radius at 100m: 43.5 mm
    """

    wavelength: float  # nm
    power: float  # mW
    waist: float  # mm
    position: Tuple[float, float, float] = (0.0, 0.0, 0.0)

    def __post_init__(self):
        """Validate beam parameters."""
        if self.power > 0.39 and self.wavelength == 1550:
            warnings.warn(
                f"Beam power {self.power} mW exceeds IEC 60825-1 Class 1 limit "
                f"(0.39 mW at 1550 nm). Use with caution.",
                UserWarning,
            )

        if self.waist <= 0:
            raise ValueError(f"Beam waist must be positive, got: {self.waist} mm")

    @property
    def wavelength_m(self) -> float:
        """Wavelength in meters."""
        return self.wavelength * 1e-9

    @property
    def waist_m(self) -> float:
        """Beam waist in meters."""
        return self.waist * 1e-3

    def calculate_rayleigh_range(self) -> float:
        """
        Calculate Rayleigh range (distance to sqrt(2) beam expansion).

        Returns:
            Rayleigh range in meters
        """
        return np.pi * self.waist_m**2 / self.wavelength_m

    def calculate_divergence(self) -> float:
        """
        Calculate beam divergence half-angle.

        Returns:
            Divergence in milliradians
        """
        theta_rad = self.wavelength_m / (np.pi * self.waist_m)
        return theta_rad * 1000  # Convert to mrad

    def radius_at_distance(self, distance: float) -> float:
        """
        Calculate beam radius at given distance.

        Args:
            distance: Distance from waist in meters

        Returns:
            Beam radius in millimeters
        """
        z_r = self.calculate_rayleigh_range()
        w_z = self.waist_m * np.sqrt(1 + (distance / z_r) ** 2)
        return float(w_z * 1000)  # Convert to mm

    def intensity_at_distance(self, distance: float, r: float = 0) -> float:
        """
        Calculate beam intensity at distance and radial offset.

        Args:
            distance: Axial distance in meters
            r: Radial offset from beam axis in millimeters

        Returns:
            Intensity in W/m^2
        """
        w_z = self.radius_at_distance(distance) * 1e-3  # Convert to meters
        r_m = r * 1e-3  # Convert to meters

        # Peak intensity
        I_0 = (2 * self.power * 1e-3) / (np.pi * w_z**2)

        # Gaussian profile
        intensity = I_0 * np.exp(-2 * (r_m / w_z) ** 2)

        return float(intensity)

    def is_class1_safe(self) -> bool:
        """
        Verify IEC 60825-1 Class 1 safety compliance.

        Returns:
            True if beam is Class 1 safe
        """
        # Class 1 limits (approximate):
        # 850 nm: <= 0.70 mW (retinal hazard region)
        # 1550 nm: <= 0.39 mW (eye-safe, corneal absorption)

        if self.wavelength < 1400:  # Visible to near-IR
            return self.power <= 0.70
        else:  # Eye-safe IR
            return self.power <= 0.39

    def to_dict(self) -> dict:
        """Export beam parameters."""
        return {
            "wavelength_nm": self.wavelength,
            "power_mw": self.power,
            "waist_mm": self.waist,
            "position": self.position,
            "divergence_mrad": self.calculate_divergence(),
            "rayleigh_range_m": self.calculate_rayleigh_range(),
            "class1_safe": self.is_class1_safe(),
        }


class BeamPropagator:
    """
    Beam propagation engine with optional GPU acceleration.

    Uses PyTorch for GPU-accelerated propagation or NumPy for CPU-only operation.

    Examples:
        >>> propagator = BeamPropagator(use_gpu=True)
        >>> beam = GaussianBeam(wavelength=850, power=0.39, waist=1.0)
        >>> results = propagator.propagate_beam(beam, distance=100)
    """

    def __init__(self, use_gpu: bool = False):
        """
        Initialize propagator.

        Args:
            use_gpu: Enable GPU acceleration (requires PyTorch)
        """
        self.use_gpu = use_gpu and HAS_TORCH

        if use_gpu and not HAS_TORCH:
            warnings.warn(
                "GPU acceleration requested but PyTorch not available. "
                "Falling back to CPU.",
                UserWarning,
            )

    def propagate_beam(
        self, beam: GaussianBeam, distance: float, num_points: int = 100
    ) -> dict:
        """
        Propagate single Gaussian beam.

        Args:
            beam: GaussianBeam instance
            distance: Propagation distance in meters
            num_points: Number of points for field calculation

        Returns:
            Dictionary with propagation results
        """
        # Calculate beam parameters at distance
        radius = beam.radius_at_distance(distance)
        divergence = beam.calculate_divergence()

        # Create radial grid
        r_max = radius * 3  # mm
        r = np.linspace(-r_max, r_max, num_points)

        # Calculate intensity profile
        intensity = np.array([beam.intensity_at_distance(distance, r_i) for r_i in r])

        return {
            "distance_m": distance,
            "radius_mm": radius,
            "divergence_mrad": divergence,
            "radial_positions_mm": r,
            "intensity_profile_Wm2": intensity,
            "peak_intensity_Wm2": intensity.max(),
        }


# Utility functions


def calculate_beam_divergence(wavelength: float, waist: float) -> float:
    """
    Calculate Gaussian beam divergence.

    Args:
        wavelength: Wavelength in nanometers
        waist: Beam waist in millimeters

    Returns:
        Divergence in milliradians
    """
    wavelength_m = wavelength * 1e-9
    waist_m = waist * 1e-3
    theta_rad = wavelength_m / (np.pi * waist_m)
    return theta_rad * 1000


def calculate_rayleigh_range(wavelength: float, waist: float) -> float:
    """
    Calculate Rayleigh range.

    Args:
        wavelength: Wavelength in nanometers
        waist: Beam waist in millimeters

    Returns:
        Rayleigh range in meters
    """
    wavelength_m = wavelength * 1e-9
    waist_m = waist * 1e-3
    return np.pi * waist_m**2 / wavelength_m
