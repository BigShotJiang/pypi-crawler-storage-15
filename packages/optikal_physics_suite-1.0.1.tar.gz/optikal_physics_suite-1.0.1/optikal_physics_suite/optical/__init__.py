"""
Optical Propagation Module
===========================

Gaussian beam modeling and atmospheric propagation
for Free-Space Optical (FSO) communication systems.

Classes:
--------
- GaussianBeam: Single Gaussian beam representation and propagation
- BeamPropagator: Beam propagation engine with optional GPU acceleration
- FogCategory: Atmospheric attenuation classification

Functions:
----------
- calculate_beam_divergence: Compute divergence half-angle
- calculate_rayleigh_range: Compute Rayleigh range
"""

from optikal_physics_suite.optical.atmospheric_constants import (
    FogCategory,
    ATTENUATION_DB_PER_KM,
    VISIBILITY_KM,
    TriBandCharacteristics,
    LinkStateModel,
    TopologyConstraints,
    SpatialWeatherModel,
)

from optikal_physics_suite.optical.beam_propagation import (
    GaussianBeam,
    BeamPropagator,
    calculate_beam_divergence,
    calculate_rayleigh_range,
)

__all__ = [
    # Atmospheric constants
    "FogCategory",
    "ATTENUATION_DB_PER_KM",
    "VISIBILITY_KM",
    "TriBandCharacteristics",
    "LinkStateModel",
    "TopologyConstraints",
    "SpatialWeatherModel",
    # Beam propagation
    "GaussianBeam",
    "BeamPropagator",
    "calculate_beam_divergence",
    "calculate_rayleigh_range",
]
