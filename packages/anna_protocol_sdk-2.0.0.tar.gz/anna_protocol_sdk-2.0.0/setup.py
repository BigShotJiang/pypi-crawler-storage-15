"""
Setup configuration for ANNA Protocol SDK v2.0.0
"""

from setuptools import setup, find_packages
import os

# Ler README
def read_file(filename):
    with open(filename, 'r', encoding='utf-8') as f:
        return f.read()

# Ler versão do SDK
def get_version():
    """Extrai versão do arquivo principal"""
    with open('anna_protocol/__init__.py', 'r', encoding='utf-8') as f:
        for line in f:
            if line.startswith('__version__'):
                return line.split('"')[1]
    return '2.0.0'

setup(
    name='anna-protocol-sdk',
    version=get_version(),
    author='Antonio Rufino',
    author_email='antonio@annaprotocol.com',
    description='Official Python SDK for ANNA Protocol - AI Accountability on Blockchain',
    long_description=read_file('README.md') if os.path.exists('README.md') else 'ANNA Protocol SDK',
    long_description_content_type='text/markdown',
    url='https://github.com/anna-protocol/sdk-python',
    project_urls={
        'Documentation': 'https://annaprotocol.com',
        'Source': 'https://github.com/anna-protocol/sdk-python',
        'Website': 'https://annaprotocol.com',
        'Bug Tracker': 'https://github.com/anna-protocol/sdk-python/issues',
    },
    packages=find_packages(),
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'Topic :: Security :: Cryptography',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Operating System :: OS Independent',
    ],
    keywords='blockchain, ai, accountability, polygon, web3, ipfs, encryption, compliance',
    python_requires='>=3.10',
    install_requires=[
        'web3>=6.0.0',
        'eth-account>=0.8.0',
        'requests>=2.31.0',       # NOVO v2.0: Filebase API
        'cryptography>=41.0.0',   # NOVO v2.0: Encryption
    ],
    extras_require={
        'dev': [
            'pytest>=7.0.0',
            'pytest-cov>=4.0.0',
            'black>=23.0.0',
            'flake8>=6.0.0',
            'mypy>=1.0.0',
        ],
        'docs': [
            'sphinx>=6.0.0',
            'sphinx-rtd-theme>=1.2.0',
        ],
    },
    include_package_data=True,
    zip_safe=False,
    license='MIT',
)