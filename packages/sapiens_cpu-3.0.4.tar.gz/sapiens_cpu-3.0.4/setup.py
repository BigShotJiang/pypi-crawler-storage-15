"""
This algorithm is a proposal from Sapiens Technology®️ for a new concept of language model architecture focused on direct CPU training.
Its concept aims to establish a new type of paradigm that enables cheaper and more accessible training.
The CPUModel architecture allows for fast and efficient training on home hardware with low computational power.
It is useful for students and developers looking to create specialized models quickly, cheaply, and accurately.
Although large language models can be created with this architecture, it will perform better on small language models that are hyper-specialized.
Any alteration, disclosure, or public comment about the technical and theoretical concepts involved in this algorithm without prior authorization
from Sapiens Technology®️ is strictly prohibited and subject to legal action by our legal team.
"""
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
from setuptools import setup, find_packages
package_name = 'sapiens_cpu'
version = '3.0.4'
setup(
    name=package_name,
    version=version,
    author='SAPIENS TECHNOLOGY',
    packages=find_packages(),
    include_package_data=True,
    install_requires=['sapiens-tokenizer', 'sapiens-attention', 'numpy', 'certifi', 'tqdm'],
    url='https://github.com/sapiens-technology/sapiens_cpu',
    license='Proprietary Software'
)
"""
This algorithm is a proposal from Sapiens Technology®️ for a new concept of language model architecture focused on direct CPU training.
Its concept aims to establish a new type of paradigm that enables cheaper and more accessible training.
The CPUModel architecture allows for fast and efficient training on home hardware with low computational power.
It is useful for students and developers looking to create specialized models quickly, cheaply, and accurately.
Although large language models can be created with this architecture, it will perform better on small language models that are hyper-specialized.
Any alteration, disclosure, or public comment about the technical and theoretical concepts involved in this algorithm without prior authorization
from Sapiens Technology®️ is strictly prohibited and subject to legal action by our legal team.
"""
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
