"""CLI layer for Cliff."""

from .app import app

__all__ = ["app"]
