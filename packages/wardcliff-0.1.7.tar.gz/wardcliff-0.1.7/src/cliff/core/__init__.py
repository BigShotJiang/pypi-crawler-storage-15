"""Core domain logic for Cliff."""
