# License: MIT
# Copyright © 2025 Frequenz Energy-as-a-Service GmbH

"""This directory contains examples for the usage of the `frequenz-lib-notebooks` repo."""
