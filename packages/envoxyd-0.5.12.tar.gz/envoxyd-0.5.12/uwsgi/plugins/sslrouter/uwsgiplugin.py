
NAME='sslrouter'
CFLAGS = []
LDFLAGS = []
LIBS = []

REQUIRES = ['corerouter']

GCC_LIST = ['sslrouter']
