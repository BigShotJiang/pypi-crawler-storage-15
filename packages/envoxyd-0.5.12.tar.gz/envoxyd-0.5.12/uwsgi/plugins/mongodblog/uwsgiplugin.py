NAME='mongodblog'

CFLAGS = []
LDFLAGS = []
LIBS = []
GCC_LIST = ['mongodblog_plugin']
