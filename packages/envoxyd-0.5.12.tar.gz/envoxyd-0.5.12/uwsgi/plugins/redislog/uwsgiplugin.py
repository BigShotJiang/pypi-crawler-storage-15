NAME='redislog'

CFLAGS = []
LDFLAGS = []
LIBS = []
GCC_LIST = ['redislog_plugin']
