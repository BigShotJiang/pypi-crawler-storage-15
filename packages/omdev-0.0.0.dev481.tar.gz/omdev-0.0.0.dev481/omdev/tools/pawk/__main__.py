if __name__ == '__main__':
    from .pawk import main

    main()
