from adam.commands.command import Command
from adam.commands.export.export_databases import ExportDatabases
from adam.repl_state import ReplState, RequiredState
from adam.sql.sql_completer import SqlCompleter
from adam.utils_athena import Athena

# No action body, only for a help entry and auto-completion
class ExportSelectX(Command):
    COMMAND = 'select_on_x'

    # the singleton pattern
    def __new__(cls, *args, **kwargs):
        if not hasattr(cls, 'instance'): cls.instance = super(ExportSelectX, cls).__new__(cls)

        return cls.instance

    def __init__(self, successor: Command=None):
        super().__init__(successor)

    def command(self):
        return ExportSelectX.COMMAND

    def required(self):
        return RequiredState.EXPORT_DB

    def completion(self, state: ReplState):
        if state.device == ReplState.X and state.export_session:
            return {'select': SqlCompleter(
                lambda: ExportDatabases.table_names(state.export_session),
                dml='select',
                expandables={
                    'columns':lambda _: Athena.column_names(database=state.export_session, function='export'),
                },
                variant='athena'
            )} | {'drop': SqlCompleter(
                lambda: ExportDatabases.table_names(state.export_session),
                dml='drop',
                expandables={
                    'columns':lambda _: Athena.column_names(database=state.export_session, function='export'),
                },
                variant='athena'
            )}

        return {}

    def help(self, _: ReplState):
        return f'<sql-select-statements>\t run queries on export database'