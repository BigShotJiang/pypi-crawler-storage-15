from abc import abstractmethod
from adam.commands.export.utils_export import ing
from adam.config import Config
from adam.utils_k8s.cassandra_nodes import CassandraNodes

class Importer:
    @abstractmethod
    def prefix(self):
        pass

    @abstractmethod
    def import_from_csv(self, pod: str, namespace: str, session: str, keyspace: str, table: str, target_table: str, columns: str, multi_tables = True, create_db = False):
        pass

    def move_to_done(self, pod: str, namespace: str, session: str, keyspace: str, target_table: str, multi_tables = True):
        log_file = f'/tmp/qing-{session}_{keyspace}.{target_table}.log.pending_import'

        if not session.startswith(self.prefix()):
            session = f'{self.prefix()}{session[1:]}'
        to = f'/tmp/qing-{session}_{keyspace}.{target_table}.log.done'

        CassandraNodes.exec(pod, namespace, f'mv {log_file} {to}', show_out=Config().is_debug(), shell='bash')

        return to, session

    def remove_csv(self, pod: str, namespace: str, session: str, table: str, target_table: str, multi_tables = True):
        ing('Cleaning up temporary files',
            lambda: CassandraNodes.exec(pod, namespace, f'rm -rf {self.csv_file(session, table, target_table)}', show_out=Config().is_debug(), shell='bash'),
            suppress_log=self.suppress_ing_log(multi_tables))

    def db(self, session: str, keyspace: str):
        return f'{session}_{keyspace}'

    def csv_file(self, session: str, table: str, target_table: str):
        temp_dir = Config().get('copy.temp_dir', '/c3/cassandra/tmp')
        return f'{temp_dir}/{session}_{target_table}/{table}.csv'

    def suppress_ing_log(self, multi_tables = True):
        return Config().is_debug() or multi_tables

    def session_prefix(importer: str = ''):
        if not importer:
            return ''

        prefix = 's'

        if importer == 'athena':
            prefix = 'e'
        elif importer == 'csv':
            prefix = 'c'

        return prefix

    def importer_from_session(session: str):
        importer = 'csv'

        if session.startswith('s'):
            importer = 'sqlite'
        elif session.startswith('e'):
            importer = 'athena'

        return importer
