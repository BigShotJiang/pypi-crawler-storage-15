"""A configurable flake8 plugin to enforce a maximum function/method length."""

__version__ = "0.10.0"
