class CHATValidationException(Exception):
    pass

class DocumentValidationException(Exception):
    pass

class ConfigNotFoundError(Exception):
    pass

class ConfigError(Exception):
    pass




