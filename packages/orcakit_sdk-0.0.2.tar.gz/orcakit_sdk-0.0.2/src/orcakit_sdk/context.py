"""Base configuration class with environment variable support.

This module provides a base class for creating configuration objects that can
automatically load values from environment variables, with support for type
conversion and validation.
"""

from __future__ import annotations

import os
from dataclasses import Field, fields
from typing import Any, TypeVar, cast, get_args, get_origin

T = TypeVar("T")


class EnvAwareConfig:
    """Base class for dataclass configs with environment variable support.

    This class provides automatic loading of configuration values from environment
    variables. Subclasses must be decorated with @dataclass to work properly.

    Priority order (highest to lowest):
        1. Explicitly passed parameters
        2. Environment variables (uppercase field names)
        3. Default values defined in the dataclass

    Supported Types:
        - bool: Accepts true/1/yes/on (case-insensitive) or false/0/no/off
        - int: Any valid integer string
        - float: Any valid float string
        - str: Any string value (default fallback)

    Example:
        >>> from dataclasses import dataclass
        >>> import os
        >>>
        >>> @dataclass(kw_only=True)
        ... class MyConfig(EnvAwareConfig):
        ...     host: str = "localhost"
        ...     port: int = 8080
        ...     use_ssl: bool = False
        ...
        >>> # Uses defaults
        >>> config = MyConfig()
        >>> assert config.host == "localhost"
        >>>
        >>> # Uses environment variables
        >>> os.environ["HOST"] = "production.example.com"
        >>> os.environ["PORT"] = "443"
        >>> os.environ["USE_SSL"] = "true"
        >>> config = MyConfig()
        >>> assert config.host == "production.example.com"
        >>> assert config.port == 443
        >>> assert config.use_ssl is True
        >>>
        >>> # Explicit parameter takes precedence
        >>> config = MyConfig(host="custom.com")
        >>> assert config.host == "custom.com"  # Overrides env var
    """

    # Class-level constants for boolean value matching
    _TRUE_VALUES: frozenset[str] = frozenset({"true", "1", "yes", "on"})
    _FALSE_VALUES: frozenset[str] = frozenset({"false", "0", "no", "off"})

    def __post_init__(self) -> None:
        """Load configuration from environment variables.

        This method runs after dataclass initialization and applies environment
        variable values only for fields that still have their default values.
        Explicitly passed parameters take precedence over environment variables.

        Environment variable names are uppercase field names (e.g., MODEL, HOST).

        Raises:
            TypeError: If the class is not a dataclass.
        """
        # Validate that this is a dataclass
        try:
            field_list: tuple[Field[Any], ...] = fields(self)  # type: ignore[arg-type]
        except TypeError as e:
            msg = (
                f"{self.__class__.__name__} must be decorated with @dataclass "
                "to use EnvAwareConfig"
            )
            raise TypeError(msg) from e

        # Process each field
        for field in field_list:
            if not field.init:
                continue

            self._load_field_from_env(field)

    def _load_field_from_env(self, field: Field[Any]) -> None:
        """Load a single field's value from environment variable if applicable.

        Args:
            field: The dataclass field to process.
        """
        # Only apply env var if field still has its default value
        current_value = getattr(self, field.name)
        if current_value != field.default:
            # User explicitly set this value, don't override
            return

        # Check for environment variable
        env_var_name = field.name.upper()
        env_value = os.environ.get(env_var_name)

        if env_value is None:
            return

        # Attempt conversion
        try:
            converted_value = self._convert_env_value(
                env_value, field.type, field.default
            )
            setattr(self, field.name, converted_value)
        except (ValueError, TypeError):
            # Silently keep default value if conversion fails
            # This is intentional to maintain backwards compatibility
            pass

    @classmethod
    def _convert_env_value(
        cls,
        env_value: str,
        field_type: type[Any] | Any,
        default_value: Any,  # noqa: ANN401
    ) -> Any:  # noqa: ANN401
        """Convert environment variable value to appropriate type.

        Args:
            env_value: The string value from environment variable.
            field_type: The target type annotation.
            default_value: The default value to infer type from.

        Returns:
            Converted value matching the target type.

        Raises:
            ValueError: If conversion fails.
            TypeError: If type is not supported.
        """
        # Infer target type from default value first (most reliable)
        target_type: type[Any] = type(default_value)

        # Override with annotation type if available and not complex
        if isinstance(field_type, type):
            target_type = field_type
        else:
            # Handle generic types (e.g., str | None, Annotated[str, ...])
            origin = get_origin(field_type)
            if origin is not None:
                # For Union types (including | syntax), try to extract base type
                type_args = get_args(field_type)
                if type_args:
                    # Filter out None and use the first concrete type
                    concrete_types = [
                        t
                        for t in type_args
                        if t is not type(None)  # noqa: E721
                    ]
                    if concrete_types and isinstance(concrete_types[0], type):
                        target_type = cast(type[Any], concrete_types[0])

        # Dispatch to specific converter based on type
        if target_type is bool:
            return cls._to_bool(env_value, default_value)

        if target_type is int:
            return cls._to_int(env_value, default_value)

        if target_type is float:
            return cls._to_float(env_value, default_value)

        if target_type is str:
            return env_value

        # For unsupported types, return as string
        return env_value

    @classmethod
    def _to_bool(cls, value: str, default: bool | Any) -> bool | Any:  # noqa: ANN401
        """Convert string to boolean with fallback to default.

        Args:
            value: String value to convert.
            default: Default value to return if conversion fails.

        Returns:
            Boolean value or default if conversion fails.
        """
        value_lower = value.lower()
        if value_lower in cls._TRUE_VALUES:
            return True
        if value_lower in cls._FALSE_VALUES:
            return False
        return default

    @classmethod
    def _to_int(cls, value: str, default: int | Any) -> int | Any:  # noqa: ANN401
        """Convert string to integer with fallback to default.

        Args:
            value: String value to convert.
            default: Default value to return if conversion fails.

        Returns:
            Integer value or default if conversion fails.
        """
        try:
            return int(value)
        except ValueError:
            return default

    @classmethod
    def _to_float(cls, value: str, default: float | Any) -> float | Any:  # noqa: ANN401
        """Convert string to float with fallback to default.

        Args:
            value: String value to convert.
            default: Default value to return if conversion fails.

        Returns:
            Float value or default if conversion fails.
        """
        try:
            return float(value)
        except ValueError:
            return default
