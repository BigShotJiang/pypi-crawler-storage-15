from __future__ import annotations


class GcHandler:
    pass
