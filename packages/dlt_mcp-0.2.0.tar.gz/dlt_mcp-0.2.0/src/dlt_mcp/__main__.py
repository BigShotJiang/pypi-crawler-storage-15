if __name__ == "__main__":
    from dlt_mcp.server import start

    start()
