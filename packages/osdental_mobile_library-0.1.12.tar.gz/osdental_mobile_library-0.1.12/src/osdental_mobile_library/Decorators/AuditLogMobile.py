import json
from functools import wraps


def AuditLogMobile():
    """
    Decorador que lee y parsea el JSON del request GraphQL.
    No envía nada a service bus ni maneja spans.
    Solo parsea y guarda los datos en info.context.
    """

    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            print("AuditLog decorator invoked")
            # Obtener "info" del resolver
            try:
                _, info = args[:2]
            except:
                return await func(*args, **kwargs)

            request = info.context.get("request")

            graphql_json = {
                "operationName": None,
                "query": None,
                "variables": None,
                "raw": None,
            }

            # Leer request json si existe
            if request:
                try:
                    body_bytes = await request.body()
                    body_str = body_bytes.decode("utf-8")
                    parsed = json.loads(body_str)

                    graphql_json["operationName"] = parsed.get("operationName")
                    graphql_json["query"] = parsed.get("query")
                    graphql_json["variables"] = parsed.get("variables")
                    graphql_json["raw"] = parsed

                except Exception:
                    pass

            # Guardamos el JSON en el context para otros usos
            info.context["graphql_request"] = graphql_json

            return await func(*args, **kwargs)

        return wrapper

    return decorator
