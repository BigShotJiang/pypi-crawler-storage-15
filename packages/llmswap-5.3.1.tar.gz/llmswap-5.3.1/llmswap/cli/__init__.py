"""
CLI tools for llmswap
"""

from .mcp_cli import main as mcp_main

__all__ = ["mcp_main"]
