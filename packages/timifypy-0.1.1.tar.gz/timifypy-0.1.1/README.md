# timifypy

A tiny, clean, and useful timing utility for Python.

Measure execution time effortlessly with a context manager or a manual stopwatch.

---

## 🚀 Installation

```bash
pip install timifypy


## Advanced Usage

### ⏱ Manual Stopwatch
```python
from timifypy import Stopwatch
sw = Stopwatch()

sw.start()
# some heavy computation
sum(range(1000000))
sw.stop()

print(sw)          # e.g., <Stopwatch 12.34 ms>
print(sw.elapsed)  # raw seconds


##Basic Usage
from timifypy import Stopwatch

sw = Stopwatch()

sw.start()
# some heavy computation
sum(range(1000000))
sw.stop()

print(sw)          # e.g., <Stopwatch 12.34 ms>
print(sw.elapsed)  # raw seconds


#Context Manager
from timifypy import timer

with timer("example computation"):
    sum(range(1000000))


##Context Manager with Logging
from timifypy import timer

with timer("load data", log_file="timings.log"):
    sum(range(1000000))


#Multiple Timers
from timifypy import timer

with timer("step 1"):
    sum(range(500000))

with timer("step 2"):
    sum(range(500000, 1000000))


##Using Stopwatch for Multiple Steps
from timifypy import Stopwatch

sw = Stopwatch()

sw.start()
sum(range(500000))
sw.stop()
print("Step 1:", sw)

sw.start()
sum(range(500000, 1000000))
sw.stop()
print("Step 2:", sw)

print("Total elapsed:", sw.elapsed)



