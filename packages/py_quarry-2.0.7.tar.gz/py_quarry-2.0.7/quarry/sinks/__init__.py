"""Sinks package."""
