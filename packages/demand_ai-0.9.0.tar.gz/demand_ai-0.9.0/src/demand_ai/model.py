import enum


# TODO: controller/main.py
class Model(enum.Enum):
	I_MOE = "i-moe"
	I_CONTEXTUAL = "i-contextual"
