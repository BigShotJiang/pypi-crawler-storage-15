# Obra Client

LLM Proxy Client with prompt enrichment for Obra Firebase SaaS deployment.

## Installation

```bash
pip install obra-client
```

## Quick Start

**IMPORTANT**: You must run `setup` and accept the Beta Terms before using any other command.

```bash
# 1. REQUIRED: First-time setup with terms acceptance
obra-client setup

# 2. Start orchestration
obra-client orchestrate "Add user authentication"

# 3. Check session status
obra-client status SESSION_ID

# 4. Resume interrupted session
obra-client resume
```

## Commands

| Command | Description |
|---------|-------------|
| `setup` | **REQUIRED first** - Accept terms and configure API |
| `orchestrate` | Start new orchestration session |
| `status` | Query session status |
| `resume` | Resume interrupted session |
| `interactive` | Interactive orchestration mode (stub) |
| `docs onboarding` | View getting-started guide |
| `docs examples` | View usage examples |
| `docs terms` | View full Beta Terms |
| `health-check` | Verify installation |
| `version` | Check version and compatibility |

## Environment

Requires:
- Python >= 3.12
- `ANTHROPIC_API_KEY` environment variable

## Configuration

Config stored at: `~/.obra/client-config.yaml`

## Documentation

```bash
# View onboarding guide
obra-client docs onboarding

# View usage examples
obra-client docs examples

# View full terms
obra-client docs terms
```

## Legal

Use of obra-client requires acceptance of the Beta Software Agreement.
Run `obra-client setup` to review and accept terms.

- Terms: https://obra.dev/terms
- Privacy: https://obra.dev/privacy
