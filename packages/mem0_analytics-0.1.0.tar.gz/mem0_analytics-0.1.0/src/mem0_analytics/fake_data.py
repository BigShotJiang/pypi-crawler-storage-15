import os, sqlite3, random, math, time
import pandas as pd
from datetime import datetime, timedelta
import numpy as np

DB_PATH = os.path.expanduser("~/.mem0_metrics.db")

def get_conn():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    return sqlite3.connect(DB_PATH)

def ensure_table():
    with get_conn() as conn:
        conn.execute("""
        CREATE TABLE IF NOT EXISTS mem0_kpi (
            ts TIMESTAMP,
            function_name TEXT,
            provider_llm TEXT,
            model_llm TEXT,
            provider_embedder TEXT,
            model_embedder TEXT,
            provider_vectorstore TEXT,
            vectorstore_collection TEXT,
            usage_count INTEGER,
            avg_latency_ms REAL,
            latency_p95 REAL,
            avg_cpu_percent REAL,
            avg_mem_used_mb REAL,
            avg_embed_latency REAL,
            avg_vector_latency REAL,
            avg_prompt_tokens REAL,
            avg_total_tokens REAL,
            avg_cost_usd REAL,
            cache_effectiveness REAL,
            error_rate REAL,
            success_rate REAL
        );
        """)
        conn.commit()

def generate_fake_data(n=500):
    fnames = ["add", "search", "update", "delete", "get", "reset"]
    llms = [("openai", "gpt-5-nano-2025-08-07"), ("ollama", "smollm2:135m")]
    embedders = [("openai", "text-embedding-3-small"), ("sentence", "bge-small-en-v1")]
    vstores = [("qdrant", "mem0_main"), ("chromadb", "mem0_local"), ("pgvector", "mem0_pg")]

    start_time = datetime.now() - timedelta(hours=2)
    rows = []

    for i in range(n):
        ts = start_time + timedelta(seconds=i * 15)
        fn = random.choice(fnames)
        pllm, mllm = random.choice(llms)
        pemb, memb = random.choice(embedders)
        pv, vc = random.choice(vstores)

        base_latency = random.uniform(80, 300)
        model_factor = 1.2 if "gpt" in mllm else 0.8
        vec_factor = 1.1 if "qdrant" in pv else 0.9
        op_factor = {"add": 1.3, "search": 1.0, "update": 1.1, "delete": 0.9, "get": 0.8, "reset": 0.6}[fn]

        avg_latency = base_latency * model_factor * vec_factor * op_factor
        jitter = np.random.normal(1, 0.15)
        avg_latency *= max(0.5, min(jitter, 1.5))

        latency_p95 = avg_latency * random.uniform(1.1, 1.4)
        embed_latency = avg_latency * random.uniform(0.2, 0.5)
        vector_latency = avg_latency * random.uniform(0.1, 0.3)

        row = {
            "ts": ts,
            "function_name": fn,
            "provider_llm": pllm,
            "model_llm": mllm,
            "provider_embedder": pemb,
            "model_embedder": memb,
            "provider_vectorstore": pv,
            "vectorstore_collection": vc,
            "usage_count": random.randint(10, 500),
            "avg_latency_ms": round(avg_latency, 2),
            "latency_p95": round(latency_p95, 2),
            "avg_cpu_percent": round(random.uniform(15, 90), 2),
            "avg_mem_used_mb": round(random.uniform(100, 800), 1),
            "avg_embed_latency": round(embed_latency, 2),
            "avg_vector_latency": round(vector_latency, 2),
            "avg_prompt_tokens": round(random.uniform(200, 900), 1),
            "avg_total_tokens": round(random.uniform(800, 2200), 1),
            "avg_cost_usd": round(random.uniform(0.001, 0.005), 6),
            "cache_effectiveness": round(random.uniform(0.6, 0.95), 3),
            "error_rate": round(random.uniform(0.01, 0.08), 3),
            "success_rate": round(random.uniform(0.92, 0.99), 3),
        }
        rows.append(row)
    return pd.DataFrame(rows)


def populate_fake_data():
    ensure_table()
    df = generate_fake_data(500)
    with get_conn() as conn:
        conn.execute("DELETE FROM mem0_kpi;")
        df.to_sql("mem0_kpi", conn, if_exists="append", index=False)
        conn.commit()
    print(f"✅ Inserted {len(df)} fake KPI rows into {DB_PATH}")


if __name__ == "__main__":
    populate_fake_data()
