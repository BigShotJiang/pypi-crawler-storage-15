"""
TUI modal dialogs for Pulka.

This module provides filter prompts, search dialogs, error messages,
and other modal interactions in the terminal user interface.
"""
