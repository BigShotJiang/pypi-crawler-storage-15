def run_fetcher():
    from af.cli.make_local import main
    main()
