#######
Jenkins
#######

lftools is a collection of scripts written directly in python or externally via
bash. It supports the following Jenkins specific commands.

.. toctree::
    :maxdepth: 2

    plugins

