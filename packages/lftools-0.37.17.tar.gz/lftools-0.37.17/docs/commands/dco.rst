****
Dco
****

.. program-output:: lftools dco --help

Commands
========

.. contents:: Check Commands
    :local:

check
---------

.. program-output:: lftools dco check --help
                    List of git commit hash missing the DCO (Signed-off-by line).


.. note::

    Check for exit status to determine if the DCO check passed.
