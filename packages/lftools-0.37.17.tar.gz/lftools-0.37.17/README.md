# LF Tools

This project's documentation is available on ReadTheDocs (RTD)

<https://lf-releng-tools.readthedocs.io>

LF Tools is a collection of scripts and utilities that are useful to Linux
Foundation projects' CI and Releng related activities. We try to create
these tools to be as generic as possible such that they are reusable in other
CI environments.

Ubuntu Dependencies:

- build-essentials
- python-dev
