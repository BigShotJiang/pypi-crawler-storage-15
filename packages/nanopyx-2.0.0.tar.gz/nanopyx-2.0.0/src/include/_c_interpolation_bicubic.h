#ifndef _C_INTERPOLATION_BICUBIC_H
#define _C_INTERPOLATION_BICUBIC_H

float _c_interpolate(float* image, float r, float c, int rows, int cols);

#endif  // _C_INTERPOLATION_BICUBIC_H