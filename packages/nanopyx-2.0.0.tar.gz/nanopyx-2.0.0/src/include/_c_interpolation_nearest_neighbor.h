#ifndef _C_INTERPOLATION_NEAREST_NEIGHBOR_H
#define _C_INTERPOLATION_NEAREST_NEIGHBOR_H

float _c_interpolate(float *image, float row, float col, int rows, int cols);

#endif
