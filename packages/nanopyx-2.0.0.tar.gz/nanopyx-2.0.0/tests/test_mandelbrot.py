from nanopyx.core.utils.mandelbrot_benchmark import check_acceleration

def test_check_acceleration():
    check_acceleration(128)