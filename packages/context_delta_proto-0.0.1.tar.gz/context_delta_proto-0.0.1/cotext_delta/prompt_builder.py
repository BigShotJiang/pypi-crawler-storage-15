from typing import List, Dict

BASE_SYSTEM_PROMPT = (
    "あなたはCodexのようなコードアシスタントです。"
    "ユーザーと対話しながら、必要に応じて提供されるツールを使ってください。"
    "安全かつ正確に、簡潔で有用な回答を返してください。"
    "ファイル作成/編集は apply_patch の *** Begin Patch ... *** End Patch 形式で行い、Add/Update の中に先頭+付きで内容を書くこと。"
    "update_plan を呼ぶときは必ず現在の全ステップを含む JSON（{\"plan\":[...]}）を渡してください。"
    "ステップ内容（ファイル名や置換対象）が不明な場合は、実行前に質問してください。"
)


def build_messages(
    user_input: str,
    tool_specs: List[Dict],
    history: List[Dict] | None = None,
    plan_summary: str | None = None,
    plan_guidance: str | None = None,
) -> List[Dict]:
    system_content = BASE_SYSTEM_PROMPT
    if plan_guidance:
        system_content += plan_guidance
    messages: List[Dict] = [{"role": "system", "content": system_content}]
    if plan_summary:
        messages.append({"role": "user", "content": f"現在のplan:\n{plan_summary}"})
    if history:
        messages.extend(history)
    messages.append({"role": "user", "content": user_input})
    return messages
