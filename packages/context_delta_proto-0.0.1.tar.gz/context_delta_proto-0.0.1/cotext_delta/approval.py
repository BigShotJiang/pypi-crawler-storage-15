from dataclasses import dataclass
from typing import Callable, Optional


@dataclass
class ApprovalOptions:
    assume_yes: bool = False


def prompt_approval(
    message: str,
    *,
    options: Optional[ApprovalOptions] = None,
    input_func: Optional[Callable[[str], str]] = None,
) -> bool:
    opts = options or ApprovalOptions()
    if opts.assume_yes:
        return True

    input_fn = input_func or input
    response = input_fn(f"{message} Proceed? [y/N] ").strip().lower()
    return response in {"y", "yes"}
