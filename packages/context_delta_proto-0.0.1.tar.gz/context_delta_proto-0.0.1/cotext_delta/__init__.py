"""Lightweight Python Codex prototype utilities."""
