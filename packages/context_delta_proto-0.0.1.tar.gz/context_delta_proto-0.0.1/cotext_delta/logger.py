import sys
from typing import Any


class Logger:
    """Text logger with fixed prefixes and stderr/stdout routing."""

    def __init__(self, stream_info=None, stream_error=None):
        self._out = stream_info or sys.stderr
        self._err = stream_error or sys.stderr

    def info(self, message: str, *, to_stdout: bool = False) -> None:
        stream = sys.stdout if to_stdout else self._out
        stream.write(f"[INFO] {message}\n")
        stream.flush()

    def warn(self, message: str) -> None:
        self._out.write(f"[WARN] {message}\n")
        self._out.flush()

    def error(self, message: str) -> None:
        self._err.write(f"[ERROR] {message}\n")
        self._err.flush()

    def final(self, message: str) -> None:
        """Write the final response to stdout."""
        sys.stdout.write(f"{message}\n")
        sys.stdout.flush()


def format_kv(**kwargs: Any) -> str:
    parts = []
    for key, value in kwargs.items():
        parts.append(f"{key}={value}")
    return " ".join(parts)
