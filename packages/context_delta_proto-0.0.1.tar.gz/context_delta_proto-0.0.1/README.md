## Quick start

1. Activate the project virtualenv (expected at `.venv`):
   ```bash
   source .venv/bin/activate
   ```
2. Install the package (PyPI想定) or editable mode:
   ```bash
   # PyPI (予定)
   pip install context-delta-proto
   # またはローカルeditable
   pip install -e .
   ```
3. Create or point to a `.env` with model/provider config, then run the CLI:
   ```bash
   delta --help
   delta "READMEを要約して"               # チャット（デフォルトはフルオート）
   delta --manual "READMEを要約して"      # 承認付きチャット
   delta read_file --file "$(pwd)/some.txt" --offset 1 --limit 10 --indent
   delta list_dir --dir "$(pwd)" --offset 1 --limit 20 --depth 2
   delta --plan-file plan.json "planに従って進めて"  # Planを注入してチャットを開始
   ```

Chat mode defaults to auto-approval (Codex風フルオート)。承認を入れたいときは `--manual` を付けるか、各ツールサブコマンドで `--yes` を外して実行してください。

Plan駆動で進める場合:
- `delta --plan-file plan.json "planに従って進めて"` でplanを注入。`--max-steps`で完了ステップ数を制限できる。
- plan更新時は `update_plan` に `{"plan":[...全ステップ...]}` をそのまま渡す。apply_patchは `*** Begin Patch`/`*** End Patch` 形式で与える。

## .env / 環境変数の例
```
# モデル/プロバイダ
MODEL=openai/gpt-oss-20b        # gpt-5* なら OpenAI、その他は LMStudio/Ollama を自動判定
OPENAI_API_KEY=sk-...           # OpenAIを使う場合
LMSTUDIO_BASE_URL=http://localhost:1234
OLLAMA_BASE_URL=http://localhost:11434

# Web検索
SEARCH_PROVIDER=tavily          # 例: tavily / mock
SEARCH_API_KEY=tvly-dev-...
```
`.env` は起動時に読み込まれ、環境変数より優先されます。

## よく使うサブコマンド
- `delta "prompt"`: チャット（フルオート）。`--manual`で承認付き。`--max-turns`でターン制限。
- `delta read_file --file <abs> --offset 1 --limit 20 --indent`: 行番号なしで抜粋。
- `delta list_dir --dir <abs> --depth 2 --limit 20`: ツリー表示（`.git`/ignoreはデフォルト除外）。
- `delta shell_command --workdir <abs> "cmd"`: シェルコマンド（確認付き、`--yes`でスキップ）。
- `delta exec ...`: 非対話のローカル実行。
- `delta --plan-file plan.json "planに従って進めて"`: planを注入してステップ実行。

## apply_patchのフォーマット（重要）
ファイル作成/編集は必ず `*** Begin Patch ... *** End Patch` 形式を使用し、Add/Update ブロックの中に先頭+付きで内容を書くこと。

## update_planの呼び出し
常に全ステップを含む JSON（`{"plan":[...全ステップ...]}`）を渡してください。ステップ内容が曖昧な場合は、実行前に質問してから進めるように誘導すると安定します。
