from cotext_delta.approval import ApprovalOptions, prompt_approval


def test_prompt_assume_yes():
    assert prompt_approval("test", options=ApprovalOptions(assume_yes=True))


def test_prompt_accepts_yes(monkeypatch):
    monkeypatch.setattr("builtins.input", lambda _: "yes")
    assert prompt_approval("test")


def test_prompt_rejects_default(monkeypatch):
    monkeypatch.setattr("builtins.input", lambda _: "n")
    assert prompt_approval("test") is False
