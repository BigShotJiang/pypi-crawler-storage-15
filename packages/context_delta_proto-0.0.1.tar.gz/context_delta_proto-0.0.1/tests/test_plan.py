from pathlib import Path

import pytest

from cotext_delta.plan import PlanContext
from cotext_delta.tools import ToolError


def test_plan_context_valid(tmp_path):
    plan_file = tmp_path / "plan.json"
    plan_file.write_text('{"plan":[{"step":"a","status":"pending"}]}', encoding="utf-8")
    ctx = PlanContext.from_file(plan_file)
    assert "pending" in ctx.summary()


def test_plan_context_invalid_status(tmp_path):
    plan_file = tmp_path / "plan.json"
    plan_file.write_text('{"plan":[{"step":"a","status":"done"}]}', encoding="utf-8")
    with pytest.raises(ToolError):
        PlanContext.from_file(plan_file)
