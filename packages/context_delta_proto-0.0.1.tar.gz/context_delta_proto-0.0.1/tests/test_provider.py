import pytest

from cotext_delta.provider import ProviderResolutionError, resolve_provider


def test_openai_requires_key():
    env = {"MODEL": "gpt-5"}
    with pytest.raises(ProviderResolutionError):
        resolve_provider(env)


def test_openai_ok_with_key():
    env = {"MODEL": "gpt-5", "OPENAI_API_KEY": "sk-123"}
    cfg = resolve_provider(env)
    assert cfg.provider == "openai"
    assert cfg.api_mode == "responses"


def test_lmstudio_priority_over_ollama():
    env = {"MODEL": "oss-model", "LMSTUDIO_BASE_URL": "http://lmstudio", "OLLAMA_BASE_URL": "http://ollama"}
    cfg = resolve_provider(env)
    assert cfg.provider == "lmstudio"
    assert cfg.api_mode == "completion"


def test_ollama_used_when_only_one():
    env = {"MODEL": "oss-model", "OLLAMA_BASE_URL": "http://ollama"}
    cfg = resolve_provider(env)
    assert cfg.provider == "ollama"


def test_no_provider_errors():
    env = {"MODEL": "oss-model"}
    with pytest.raises(ProviderResolutionError):
        resolve_provider(env)
