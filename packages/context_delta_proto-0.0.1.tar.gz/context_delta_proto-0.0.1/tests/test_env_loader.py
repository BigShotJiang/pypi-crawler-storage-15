import os
from pathlib import Path

import pytest

from cotext_delta.env_loader import EnvLoaderError, load_env
from cotext_delta.logger import Logger


def test_env_loader_missing_specified_path(tmp_path):
    missing = tmp_path / "no.env"
    with pytest.raises(EnvLoaderError):
        load_env(str(missing), logger=Logger(), cwd=tmp_path)


def test_env_loader_warns_when_default_missing(monkeypatch, tmp_path, capsys):
    monkeypatch.chdir(tmp_path)
    load_env(None, logger=Logger(), cwd=tmp_path)
    captured = capsys.readouterr()
    assert "[WARN] .env not found" in captured.err


def test_env_loader_overrides_env(monkeypatch, tmp_path):
    env_file = tmp_path / ".env"
    env_file.write_text("MODEL=from_file\n", encoding="utf-8")
    monkeypatch.setenv("MODEL", "from_env")
    result = load_env(None, logger=Logger(), cwd=tmp_path)
    assert result.values["MODEL"] == "from_file"
