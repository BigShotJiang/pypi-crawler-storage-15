class ConfigMissingError(FileNotFoundError):
    """Raised when a specified configuration file cannot be found."""

    pass
