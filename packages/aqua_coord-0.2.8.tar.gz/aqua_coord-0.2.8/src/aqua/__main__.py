"""Entry point for python -m aqua."""

from aqua.cli import main

if __name__ == "__main__":
    main()
