from __future__ import annotations

from enum import Enum
from pathlib import Path
from typing import List, Optional

import typer

CONTEXT_SETTINGS = {"help_option_names": ["-h", "--help"]}


class LogLevel(str, Enum):
    debug = "DEBUG"
    info = "INFO"
    warning = "WARNING"
    error = "ERROR"


OPTIONS = {}

OPTIONS["input_file"]: Path = typer.Option(
    ...,
    "-i",
    "--input-file",
    help="path to the input file.",
    exists=True,
    file_okay=True,
    readable=True,
    resolve_path=True,
)
OPTIONS["output_file"]: Optional[Path] = typer.Option(
    None,
    "-o",
    "--output-file",
    help="path to the output file.",
    exists=False,
    writable=True,
)
OPTIONS["connectivity_files"]: Optional[List[Path]] = typer.Option(
    None,
    "-c",
    "--connectivity-files",
    help="path to one or more connectivity file.",
    exists=True,
    file_okay=True,
    readable=True,
    resolve_path=True,
)
OPTIONS["scan_directory_scan_plot"]: Path = typer.Option(
    ...,
    "-s",
    "--scan-directory",
    help="path to the input YARR scan directory.",
    exists=True,
    readable=True,
    resolve_path=True,
)
OPTIONS["scan_directory_conn_plot"]: Optional[Path] = typer.Option(
    None,
    "-s",
    "--scan-directory",
    help="path to the input YARR scan directory.",
    exists=True,
    readable=True,
    resolve_path=True,
)
OPTIONS["path"]: Optional[Path] = typer.Option(
    None,
    "-p",
    "--relative-path",
    help="relative path to folder.",
    exists=True,
    readable=True,
    resolve_path=True,
)
OPTIONS["per_module"]: bool = typer.Option(
    False, "--per-module", "-m", help="divide summary per chip."
)
OPTIONS["config_summary"]: bool = typer.Option(
    False, "--config-summary", help="enable plot config summary in YARR scan."
)
OPTIONS["failing"]: bool = typer.Option(
    False, "--highlight-failures", help="highlight failures."
)
OPTIONS["individual_pngs"]: bool = typer.Option(
    False, "--individual-pngs", help="save plots in individual pngs."
)
OPTIONS["verbosity"]: LogLevel = typer.Option(
    LogLevel.info,
    "-v",
    "--verbosity",
    help="Log level [options: DEBUG, INFO (default) WARNING, ERROR]",
)
