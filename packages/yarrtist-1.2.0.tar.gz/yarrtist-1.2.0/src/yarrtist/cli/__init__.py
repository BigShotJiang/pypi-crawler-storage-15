from __future__ import annotations

from yarrtist.cli.main import app

__all__ = ("app",)
