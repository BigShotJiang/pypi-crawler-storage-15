# Plots

## Overview

Four different commands are available:

- `plot-single-test`
- `plot-single-config`
- `plot-scan`
- `plot-connectivity`

For general help, use

```
yarrtist plots -h
yrts plots -h

```

while for help with a specific command

```
yarrtist plots <command> -h
yrts plots <command> -h

```

by substituting `<command>` with one of the ones listed above. Examples of plot
described below can be found
[here](https://cernbox.cern.ch/files/spaces/eos/user/r/rizanzot/YARRtist%20examples).

## Single test

Single 1d or 2d plot for a single map or distribution `json` inside `YARR` scan

```
yarrtist plots plot-single-test -i <data>
yrts plots plot-single-test -i <data>

```

Output is a `png` file inside the same directory of the `json` file.

## Single configuration

Summary of the `json` config file for a single chip

```
yarrtist plots plot-single-config -i <config>
yrts plots plot-single-config -i <config>

```

This option should work only for RD53B or ITKPIXV2 chips. Output is a `png` file
inside the same directory of the `config` file.

## Scan plot

This option allows to plot data inside a scan folder for all the different chips
supported by `YARR`. A summary is saved in `pdf` files inside the scan
directory.

### Single chip plotting (default)

By default YARRtist plots all the chips found in the scan folder, one by one.

```
yarrtist plots plot-scan -s <scan_directory>
yrts plots plot-scan -s <scan_directory>

```

In order to associate a test with its corresponding chip, YARRtist needs to get
the chip `name` from its configuration file. When no option is provided YARRtist
tries to take the path to configuration file from `scanLog.json` in the
`__config_path__` field, if it is not an absolute path or a path which can be
resolved from where YARRtist is called, it is possible to resolve it providing
`-p` (or `--relative-path`) option, in case it is not provided the configuration
files are taken directly from the scan directory, using the `.before`
configuration files. So in principle it is possible to plot all data without any
additional option. It is also possible to provide directly one or more
connectivity files with `-c` options, also in this case a relative path can be
provided if the the path of the configuration files is not relative to
connectivity or absolute.

### Full module plotting (available only for RD53B and ITKPIXV2)

Also a full module can be plotted providing the `-m` or `-per-module` option.
Also in this case YARRtist needs to get the configuration files, in this case
also to understand the correct orders of the chips in the module. The same
considerations done before regarding the way the configuration files are
searched are still valid. If `scanLog.json` contains a list of connectivities
from multiple modules or multiple connectivity files with `-c` options are
provided, multiple modules data are plotted at once.

### Other options

A comparison between the configurations of the chips before and after the scan
can be done by providing the `--config-summary` option. This can be done both by
per chip or per module. The option is valid only for RD53B and ITKPIXV2.

Failing pixels can be highlighted with `--highlight-failures`, where size of too
low or too high occupancy pixels is increased (with different colors) such that
can be noticed.

The summary can be separated in individual pngs by providing the
`--individual-pngs` option.

## Connectivity plot

Summary of the chips configuration in a module from its `connectivity` file,
available only for RD53B and ITKPIXV2. It is possible both per chip or per
module

```
yarrtist plots plot-connectivity -c <connectivity> (--per-module)
yrts plots plot-connectivity -c <connectivity> (--per-module)

```

it can also be called providing the `-s <scan_directory>` option, same
considerations regarding the configurations file are valid also in this case.
The summary is saved in `pdf` files inside the `connectivity` or `scan` file
directory.
