from __future__ import unicode_literals


__author__ = 'Lorenzo Prodon'
__version__ = '1.2'


default_app_config = 'persistent_filters.apps.PersistenFiltersConfig'


VERSION = __version__
