from django.apps import AppConfig


class PersistentFiltersConfig(AppConfig):
    name = 'persistent_filters'
    verbose_name = 'Persistent Filters'
