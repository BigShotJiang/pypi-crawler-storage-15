"""Unit tests for doc-manager-mcp."""
