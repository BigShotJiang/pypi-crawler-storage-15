from setuptools import setup, find_packages

setup(
    name="eldars_custom_math",
    version="1.2.0",
    description="Fake Math Library with classes and functions like math module",
    author="Eldar",
    packages=find_packages(),
    python_requires=">=3.10",
)
