var filePreviewUrl = "{% url 'core_file_preview_app_get_blob_preview' %}";
