"""Unit tests for woolly - tests with mocking."""
