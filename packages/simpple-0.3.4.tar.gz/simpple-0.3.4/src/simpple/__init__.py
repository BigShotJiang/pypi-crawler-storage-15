# redundant alias to silence linter
from simpple._version import __version__ as __version__
