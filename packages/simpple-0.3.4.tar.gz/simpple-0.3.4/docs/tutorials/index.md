# Tutorials

```{toctree}
:maxdepth: 1

getting-started
fitting-a-line
writing-model-classes
fixed-parameters
yaml
```
