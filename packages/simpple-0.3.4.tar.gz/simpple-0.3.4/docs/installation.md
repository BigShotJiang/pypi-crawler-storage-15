# Installation

To install `simpple`, run `python -m pip install simpple`.
