# Distributions

```{eval-rst}
.. automodule:: simpple.distributions
    :members:
```
