# Model

```{eval-rst}
.. automodule:: simpple.model
    :members:
```
