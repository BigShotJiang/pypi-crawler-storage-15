

### Caveats

- At least one of the saved frames must have cpl.ui.Frame.FrameLevel.RAW
  - "RAW" does not mean a raw file, but an original file
- "ESO PRO CATG" must be set, otherwise you get a DataNotFound error