#!/bin/bash
# Xiang Wang(ramwin@qq.com)


pytest tests
# python3 -m unittest test tests.test_handlers
