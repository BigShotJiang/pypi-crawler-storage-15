# 深度研究 MCP 伺服器 (Deep Research MCP Server)

一個基於 `mcp` 框架的智慧研究代理伺服器，專為大型語言模型（如 Claude）設計。它提供了一套強大的研究工具，整合了 DuckDuckGo 的網路搜尋功能，能夠對指定主題進行深入的資訊收集與整理。

此伺服器不僅能執行搜尋，還能自動追蹤搜尋結果的連結，提取網頁的關鍵內容，並將所有資訊匯總成一份全面的研究報告。

## 核心功能

- **整合式搜尋**: 使用 DuckDuckGo 進行網路搜尋。
- **自動內容提取**: 能夠訪問搜尋結果的 URL，使用 `trafilatura` 解析 HTML 頁面，並提取標題和主要內文。
- **綜合報告生成**: 將來自多個來源的資訊整合成一份結構清晰、易於閱讀的報告，並附上引用來源。
- **智慧內容截斷**: 自動處理並截斷過長的內容，確保最終回應的長度在預設限制內，防止資訊過載。
- **進階提示生成**: 內建一個提示模板，可引導語言模型進行多步驟、迭代式的深度研究。

## 安裝與設定

### 1. 前置需求
- Python 3.8 或更高版本

### 2. 安裝依賴套件
本專案依賴以下 Python 套件。建議在虛擬環境中進行安裝。

- `mcp`: 伺服器框架
- `httpx`: 用於發送異步 HTTP 請求
- `beautifulsoup4`: 用於解析 HTML 內容
- `trafilatura`: 用於提取網頁主要內容

您可以建立一個 `requirements.txt` 檔案並使用 pip 進行安裝：

**requirements.txt:**
```
mcp
httpx
beautifulsoup4
trafilatura
```

**安裝指令:**
```bash
pip install -r requirements.txt
```

### 3. 環境變數設定 (可選)

您可以透過環境變數來調整伺服器的行為：

- `DEEP_RESEARCH_MAX_CONTENT_SIZE`: 設定回應內容的最大字元數 (預設: 16384)
- `DEEP_RESEARCH_MAX_RESULTS`: 設定搜尋結果的最大數量 (預設: 20)

## 啟動伺服器

完成安裝後，在您的終端機中執行以下指令來啟動伺服器：

```bash
uvx lcp-deep-research-mcp
# 或
python server.py
```