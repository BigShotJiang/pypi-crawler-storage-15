#!/usr/bin/env python3
"""
一個 MCP 伺服器，提供統一的 網路搜尋 和 學術搜尋 的研究工具，
會追蹤相關連結，並將全面的資訊返回給 User。

此伺服器整合了 web_search 進行網路搜尋，以及 academic_search 進行學術內容搜尋
並將兩個來源的結果整合在一起，提供一個全面的研究結果。
並提供詳細的研究來源引用。


"""

import sys
import re
import logging
import os
import asyncio
from urllib.parse import quote_plus, unquote
from contextlib import asynccontextmanager

# 設定日誌記錄到 stderr
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    stream=sys.stderr
)
logger = logging.getLogger("deep-search")

# 嘗試匯入必要的相依套件
import httpx
from bs4 import BeautifulSoup
from mcp.server.fastmcp import FastMCP
import trafilatura

# 使用簡單的生命週期函式初始化伺服器
@asynccontextmanager
async def lifespan(app: FastMCP):
    """伺服器生命週期的內容管理器"""
    logger.info("伺服器正在啟動...")
    yield {}
    logger.info("伺服器正在關閉...")

# 初始化 MCP 伺服器
mcp = FastMCP(
    "deep-search",
    dependencies=["httpx", "beautifulsoup4", "trafilatura"],
    lifespan=lifespan
)

# 設定
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"

# 從環境變數讀取設定，若未設定則使用預設值
try:
    MAX_CONTENT_SIZE = int(os.getenv("DEEP_RESEARCH_MAX_CONTENT_SIZE", "16384"))
except ValueError:
    logger.warning("DEEP_RESEARCH_MAX_CONTENT_SIZE 環境變數不是有效的整數，將使用預設值 16384")
    MAX_CONTENT_SIZE = 16384

try:
    MAX_RESULTS = int(os.getenv("DEEP_RESEARCH_MAX_RESULTS", "20"))
except ValueError:
    logger.warning("DEEP_RESEARCH_MAX_RESULTS 環境變數不是有效的整數，將使用預設值 20")
    MAX_RESULTS = 20

def safe_truncate(text, max_length, suffix="...\n[內容因長度限制已被截斷]"):
    """安全地將文字截斷至最大長度並加上後綴"""
    if not text or len(text) <= max_length:
        return text
    
    # 嘗試在段落邊界處截斷
    last_para_break = text[:max_length-50].rfind("\n\n")
    if last_para_break > max_length // 2:
        return text[:last_para_break] + "\n\n" + suffix
    
    return text[:max_length] + suffix

@mcp.tool()
async def deep_search(query: str, num_results: int = 10) -> str:
    """
    對一個主題進行深入的網路研究，並返回詳細資訊。

    Args:
        query: 研究問題或主題
        num_results: 要檢查的來源數量 (預設為 10)

    Returns:
        結合多個來源的綜合研究結果
        並提供詳細的研究與來源引用。
    """
    logger.info(f"開始網路研究：{query}，結果數量：{num_results}")
    
    # 驗證輸入
    if num_results > MAX_RESULTS:
        num_results = MAX_RESULTS
        
    try:
        # 從基本介紹開始
        result = f"研究查詢：{query}\n\n"
        result += f"正在從網路搜尋...\n\n"
        
        # 收集網路搜尋結果
        web_urls = []
        try:
            web_results = await _web_search(query, num_results)
            result += "網路搜尋結果：\n" + web_results + "\n\n"
            web_urls = re.findall(r"URL: (https?://[^\s]+)", web_results)
            web_urls = web_urls[:num_results]
        except Exception as e:
            logger.error(f"網路搜尋錯誤：{str(e)}")
            result += f"網路搜尋錯誤：{str(e)[:100]}\n\n"
        
        # 檢查是否有找到任何結果
        if not web_urls:
            return result + "找不到有效的研究結果。請嘗試不同的查詢。"
            
        # 追蹤 URL 以獲取詳細內容
        result += f"來自前 {len(web_urls)} 個來源的詳細內容：\n\n"
        successful_sources = []  # 追蹤成功訪問的來源
        
        for i, url in enumerate(web_urls, 1):
            try:
                # 獲取內容
                page_content = await _follow_link(url)
                
                # 提取標題
                title_match = re.search(r"Title: (.+?)\n", page_content)
                title = title_match.group(1) if title_match else f"來源 {i}"
                
                # 新增到結果中
                separator = "=" * 40
                result += f"{separator}\n來源 {i}：{title}\n{separator}\n\n"
                result += page_content + "\n\n"
                successful_sources.append({"title": title, "url": url}) # 記錄成功的來源
            except Exception as e:
                logger.error(f"追蹤 URL 時發生錯誤 {url}：{str(e)}")
                separator = "=" * 40
                result += f"{separator}\n來源 {i}：追蹤 URL 時發生錯誤\n{separator}\n"
                result += f"錯誤：{str(e)[:100]}\n\n"
        
        # 新增一個明確的、成功訪問的來源 URL 列表
        references_section = ""
        if successful_sources:
            references_section = "\n\n" + "="*40 + "\n" + "成功訪問的資料來源 URL\n" + "="*40 + "\n\n"
            for i, source in enumerate(successful_sources, 1):
                references_section += f"{i}. {source['title']}\n"
                references_section += f"   URL: {source['url']}\n\n"

        # 檢查大小並新增摘要
        summary = "\n研究摘要：\n"
        summary += f"已完成研究：{query}\n"
        summary += f"已檢查 {len(web_urls)} 個網路來源\n"
        summary += "以上資訊代表就此主題找到的最相關內容。\n"
        
        # 優先保留參考文獻和摘要的空間，然後截斷主要內容
        max_size = MAX_CONTENT_SIZE - len(summary) - len(references_section) - 50
        if len(result) > max_size:
            result = safe_truncate(result, max_size)

        # 將所有部分組合起來
        result += references_section
        result += summary
        logger.info(f"研究完成，返回 {len(result)} 個字元")
        return result
        
    except Exception as e:
        logger.error(f"deep_research 函式發生錯誤：{str(e)}")
        return f"研究錯誤：{str(e)[:200]}"

async def _web_search(query: str, num_results: int) -> str:
    """使用 DuckDuckGo 進行網路搜尋"""
    try:
        async with httpx.AsyncClient(follow_redirects=True, timeout=10.0) as client:
            # 建立搜尋 URL
            encoded_query = quote_plus(query)
            url = f"https://html.duckduckgo.com/html/?q={encoded_query}"
            
            # 設定標頭
            headers = {
                "User-Agent": USER_AGENT,
                "Accept": "text/html,application/xhtml+xml"
            }
            
            # 發出請求
            response = await client.get(url, headers=headers)
            response.raise_for_status()
            
            # 解析結果
            soup = BeautifulSoup(response.text, "html.parser")
            search_results = []
        
            # 提取結果
            result_blocks = soup.select(".result")
            for block in result_blocks:
                if len(search_results) >= num_results:
                    break
                    
                # 取得標題和 URL
                title_elem = block.select_one(".result__title a")
                if not title_elem:
                    continue
                    
                title = title_elem.get_text().strip()
                href = title_elem.get("href", "")
                
                # 從重新導向中提取實際 URL
                if "duckduckgo.com" in href:
                    url_match = re.search(r"uddg=([^&]+)", href)
                    if url_match:
                        href = unquote(url_match.group(1))
                
                # 取得摘要
                snippet_elem = block.select_one(".result__snippet")
                snippet = snippet_elem.get_text().strip() if snippet_elem else "沒有可用的摘要"
                
                # 新增至結果
                search_results.append({
                    "title": title[:100],
                    "url": href[:150],
                    "snippet": snippet[:200]
                })
            
            # 格式化結果
            results_text = f"網路搜尋結果：{query}\n\n"
            for i, result in enumerate(search_results, 1):
                results_text += f"{i}. {result['title']}\n"
                results_text += f"   URL: {result['url']}\n"
                results_text += f"   {result['snippet']}\n\n"
                
            return results_text if search_results else f"找不到關於「{query}」的網路搜尋結果"
                
    except Exception as e:
        logger.error(f"網路搜尋錯誤：{str(e)}")
        raise  # 重新引發錯誤，以便在主函式中處理

async def _follow_link(url: str) -> str:
    """造訪一個 URL 並使用 trafilatura 提取其主要內容"""
    try:
        # 使用 asyncio.to_thread 在單獨的執行緒中執行同步的 trafilatura 函式
        # 避免阻塞事件循環
        downloaded = await asyncio.to_thread(trafilatura.fetch_url, url)
        
        if downloaded is None:
            logger.warning(f"無法從 {url} 下載內容")
            return f"標題：無法檢索內容\nURL: {url}\n\n內容：[無法下載頁面]"

        # 提取主要內容，同時嘗試獲取標題
        content_text = await asyncio.to_thread(
            trafilatura.extract,
            downloaded,
            include_comments=False,
            include_tables=False,
            include_formatting=True # 保留一些格式，如換行
        )
        
        if not content_text:
            logger.warning(f"Trafilatura 無法從 {url} 提取主要內容")
            # 如果主要內容提取失敗，可以嘗試一個更寬鬆的後備方案
            soup = BeautifulSoup(downloaded, "html.parser")
            all_text = soup.get_text(separator='\n', strip=True)
            clean_text = re.sub(r'\n\s*\n', '\n', all_text).strip()
            content_text = clean_text[:1500] # 限制後備內容的長度
            if not content_text:
                 return f"標題：無內容\nURL: {url}\n\n內容：[頁面為空或無法解析]"

        # 嘗試從 soup 中獲取一個更好的標題
        soup = BeautifulSoup(downloaded, "html.parser")
        title = soup.title.string.strip() if soup.title and soup.title.string else "無標題"

        result = f"標題：{title[:150]}\nURL: {url}\n\n內容：\n{content_text}"
        
        return result
            
    except Exception as e:
        logger.error(f"使用 trafilatura 追蹤連結 {url} 時發生錯誤：{str(e)}")
        # 如果 trafilatura 失敗，可以選擇性地引發錯誤或返回錯誤訊息
        return f"標題：處理錯誤\nURL: {url}\n\n內容：[處理頁面時發生錯誤：{str(e)[:100]}]"

@mcp.prompt()
def deep_search_prompt(topic: str) -> str:
    """
    為一個主題建立一個全面的網路研究提示。

    Args:
        topic: 要研究的主題

    Returns:
        一個帶有 APA 引文格式的全面網路研究提示。
    """
    return (
        f"我需要對以下主題進行深入的網路研究：{topic}\n\n"
        f"請遵循以下研究流程：\n\n"
        f"1. 探索：使用 `deep_search` 工具從網路收集關於 '{topic}' 的資訊。\n\n"
        f"2. 綜合：將所有收集到的資訊整合成一個連貫的摘要。解釋要點、不同觀點以及對該主題的當前理解。\n\n"
        f"3. 建立報告：建立一個最終的產出項目，包括：\n"
        f"   - 執行摘要\n"
        f"   - 主要發現\n"
        f"   - 結論\n\n"
        f"4. 參考文獻：在結尾處附上格式正確的 APA 第七版參考文獻列表。為報告中使用的每個來源建立引文。請確保每個引文都包含可訪問的 URL。\n"
        f"   網路來源的格式如下：\n"
        f"   作者, A. A. (年, 月 日). 網頁標題. 網站名稱. URL\n"
    )

def main():
    """主要執行函數，啟動 MCP 伺服器並處理致命錯誤"""
    try:
        logger.info("正在啟動 deep_search MCP 伺服器...")
        mcp.run()
    except Exception as e:
        logger.critical(f"致命錯誤：{str(e)}")
        sys.exit(1)

# 啟動伺服器
if __name__ == "__main__":
    main()