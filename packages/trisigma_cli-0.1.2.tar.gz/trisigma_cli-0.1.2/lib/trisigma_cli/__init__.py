"""Trisigma CLI - инструмент командной строки для работы с Репозиторием метрик."""

from trisigma_cli.core.version import __version__

__author__ = "ab-metrics team"
