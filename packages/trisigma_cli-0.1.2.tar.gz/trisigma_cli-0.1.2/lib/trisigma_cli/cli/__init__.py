"""CLI модуль для Trisigma."""
