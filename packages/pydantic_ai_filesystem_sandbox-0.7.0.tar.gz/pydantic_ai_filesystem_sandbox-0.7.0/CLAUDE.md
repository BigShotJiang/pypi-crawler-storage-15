# Instructions for Claude and AI Assistants

Read and follow all guidance in `AGENTS.md`.
