from setuptools import setup, find_packages

setup(
    name="phonelocate",
    version="v0.0.1-beta",
    description="Phone number locator for Russia and Ukraine",
    author="msctop4 / @blyatstudio",
    packages=find_packages(),
    python_requires=">=3.7",
    classifiers=["Programming Language :: Python :: 3","License :: OSI Approved :: MIT License",],)