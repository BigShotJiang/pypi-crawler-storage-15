# PhoneLocate

Phone number locator for Russia and Ukraine

## Installation
```bash
pip install phonelocate
```

## Usage
```python
from phonelocate import PhoneLocator

locator = PhoneLocator()
info = locator.locate("+7 910 123-45-67")

print(info.country)     
print(info.region)      
print(info.operator)    
```