"""
AI service API routes.

REST API endpoints for AI chat functionality.
"""

# API routes will be exported here in ticket #159
__all__ = []
