"""Template system for generating strategy projects."""

from .base import TemplateManager, TemplateError

__all__ = ["TemplateManager", "TemplateError"]