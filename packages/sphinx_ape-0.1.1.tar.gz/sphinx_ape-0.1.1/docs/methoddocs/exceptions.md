# Exceptions

```{eval-rst}
.. automodule:: sphinx_ape.exceptions
    :members:
```
