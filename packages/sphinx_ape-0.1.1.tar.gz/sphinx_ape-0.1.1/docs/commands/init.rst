init
****

.. click:: sphinx_ape._cli:init
  :prog: init
  :nested: full
