build
*******

.. click:: sphinx_ape._cli:build
  :prog: build
  :nested: full
