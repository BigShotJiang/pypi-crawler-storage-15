publish
*******

.. click:: sphinx_ape._cli:publish
  :prog: publish
  :nested: full
