test
*******

.. click:: sphinx_ape._cli:test
  :prog: test
  :nested: full
