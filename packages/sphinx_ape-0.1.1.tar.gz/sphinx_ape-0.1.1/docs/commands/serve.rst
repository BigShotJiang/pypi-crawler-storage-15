serve
*****

.. click:: sphinx_ape._cli:serve
  :prog: serve
  :nested: full
