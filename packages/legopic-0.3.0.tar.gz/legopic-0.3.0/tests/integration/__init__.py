"""Integration tests for legopic package."""
