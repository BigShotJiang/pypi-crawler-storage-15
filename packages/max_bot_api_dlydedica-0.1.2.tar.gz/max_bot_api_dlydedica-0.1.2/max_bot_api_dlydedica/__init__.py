# Compatibility shim package to allow importing as `max_bot_api_dlydedica`
"""
Этот пакет — тонкая обёртка, которая перенаправляет импорт на внутренний пакет
`max_bot_api`.

После установки/развертывания вы сможете использовать:
    from max_bot_api_dlydedica import Bot

и это эквивалентно `from max_bot_api import Bot`.
"""

# Make relative import to avoid circular issues when package is installed
from importlib import import_module as _import_module

_max_pkg = _import_module("max_bot_api")

# Re-export public API from the real package
try:
    __all__ = getattr(_max_pkg, "__all__")
except Exception:
    __all__ = []

for _name in __all__:
    globals()[_name] = getattr(_max_pkg, _name)

# Also export submodules commonly accessed like logging_config
_submodules = [
    "logging_config",
]
for _sub in _submodules:
    try:
        globals()[_sub] = _import_module(f"max_bot_api.{_sub}")
    except Exception:
        pass

# Expose version
try:
    __version__ = getattr(_max_pkg, "__version__")
except Exception:
    __version__ = None
