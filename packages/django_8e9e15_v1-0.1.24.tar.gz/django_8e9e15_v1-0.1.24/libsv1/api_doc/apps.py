from django.apps import AppConfig

class ModuleAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'libsv1.api_doc'
