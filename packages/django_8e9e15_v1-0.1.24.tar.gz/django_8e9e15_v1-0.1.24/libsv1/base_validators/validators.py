from gettext import gettext
from django.core.validators import RegexValidator
from rest_framework import serializers
from libsv1.string_utils import StringUtils
from django.db.models.query import QuerySet

def validate_phone_number():
    return RegexValidator(regex=r'^\d+$', message=gettext('Phone number must contain only digits'))


def validate_exists(value, model_or_queryset, field=None, key='id'):
    if value is None or value == "":
        return

    if isinstance(model_or_queryset, QuerySet):
        queryset = model_or_queryset
    else:
        model_class = model_or_queryset
        queryset = model_class.objects.all()

    final_queryset = queryset.filter(**{key: value})

    if not final_queryset.exists():
        if field is None:
            field = StringUtils.convert_case(queryset.model.__name__, 'Sentence case')

        raise serializers.ValidationError(
            '___' + gettext("{field} does not exist").format(field=field)
        )

