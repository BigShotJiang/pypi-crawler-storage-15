# Contenido de src/help_core_pygame/__init__.py

# Re-exportar las funciones/clases principales de help_core.py (se usarán en las demos de examples/)
from .help_core import open_help_standalone
from .help_core import HelpConfig, HelpViewer 

# En caso de querer re-exportar otros módulos se podría hacer aquí igualmente 

