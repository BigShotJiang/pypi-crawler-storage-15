"""Zenith Framework version."""

__version__ = "0.0.14"
