"""Tests for the OpenDota API wrapper."""
