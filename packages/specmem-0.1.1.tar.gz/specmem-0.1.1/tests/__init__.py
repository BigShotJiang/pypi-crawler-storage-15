"""Test suite for SpecMem."""
