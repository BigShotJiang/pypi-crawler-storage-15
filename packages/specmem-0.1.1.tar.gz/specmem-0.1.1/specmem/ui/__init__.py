"""SpecMem Web UI package."""

from specmem.ui.server import WebServer


__all__ = ["WebServer"]
