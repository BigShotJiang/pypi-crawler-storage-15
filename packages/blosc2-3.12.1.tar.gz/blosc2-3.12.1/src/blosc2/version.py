__version__ = "3.12.1"
__array_api_version__ = "2024.12"
