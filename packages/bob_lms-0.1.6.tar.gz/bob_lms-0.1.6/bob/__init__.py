"""
B.O.B — Library Manager CLI
Author: Anirudh S, Arnav Prakash, Arvind Bhaskar
"""

__all__ = ["main"]
__version__ = "0.1.6"
