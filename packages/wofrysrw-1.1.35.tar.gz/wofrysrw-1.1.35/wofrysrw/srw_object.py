

class SRWObject(object):

    def to_python_code(self, data=None):
        raise NotImplementedError()
