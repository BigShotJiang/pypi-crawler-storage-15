from __future__ import annotations

from typing import Any

ParsedArgs = dict[str, Any]
