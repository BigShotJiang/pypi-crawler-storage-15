from __future__ import annotations

# filestate: python-constant-sort
MIDDLEWARE_OPTION_VALUE_ALLWAYS: str = "allways"
MIDDLEWARE_OPTION_VALUE_OPTIONAL: str = "optional"
