from __future__ import annotations

from wexample_wex_core.common.kernel import Kernel


class AppManagerKernel(Kernel):
    pass
