"""
Configuration constants for Spritz CLI
"""

from pathlib import Path

# Configuration paths
CONFIG_DIR = Path.home() / '.spx'
CONFIG_FILE = CONFIG_DIR / 'config'
CREDENTIALS_FILE = CONFIG_DIR / 'credentials'
USER_FILE = CONFIG_DIR / 'user.json'

# Default URLs
DEFAULT_SPRITZ_URL = 'https://spritz.activate.bar'
DEFAULT_API_URL = 'https://api.spritz.activate.bar'

# Authentication
CALLBACK_PORT = 8765
