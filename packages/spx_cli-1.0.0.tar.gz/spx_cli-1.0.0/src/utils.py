"""
Utility functions for Spritz CLI
"""

import click
import requests

from .auth import authenticate_user


def make_authenticated_request(method, url, profile, profile_config, spritz_url, **kwargs):
    """Make request with auth token, re-authenticate if needed - Uses API URL for requests"""
    token = profile_config.get('token')
    
    if not token:
        click.echo(click.style("\n⚠️  No authentication token found.", fg='yellow', bold=True))
        token = authenticate_user(profile, spritz_url)
        profile_config['token'] = token
    
    # Add auth header
    headers = kwargs.get('headers', {})
    headers['Authorization'] = f'Bearer {token}'
    kwargs['headers'] = headers
    
    # Make request
    response = requests.request(method, url, **kwargs)
    
    # Check if unauthorized
    if response.status_code == 401:
        click.echo(click.style("\n⚠️  Token expired or invalid. Re-authenticating...", fg='yellow', bold=True))
        token = authenticate_user(profile, spritz_url)
        profile_config['token'] = token
        
        # Retry request with new token
        headers['Authorization'] = f'Bearer {token}'
        kwargs['headers'] = headers
        response = requests.request(method, url, **kwargs)
    
    return response


def load_agents_from_url(url):
    """Fetch agent configuration from URL"""
    try:
        click.echo(click.style(f"   Fetching from: {url}", fg='blue'))
        response = requests.get(url, timeout=30)
        response.raise_for_status()
        
        data = response.json()
        return data
    except requests.exceptions.Timeout:
        raise click.ClickException(f"Request timeout while fetching from URL: {url}")
    except requests.exceptions.RequestException as e:
        raise click.ClickException(f"Error fetching from URL: {str(e)}")
    except Exception as e:
        raise click.ClickException(f"Invalid JSON response from URL: {str(e)}")
