"""
Login command - Authenticate with Spritz
"""

import click
import sys
from ..config import SpritzConfig
from ..auth import authenticate_user


@click.command('login')
@click.option('--profile', default='default', help='Profile to login')
def login(profile):
    """Login to Spritz (authenticate and save token)"""
    click.echo(click.style("\n╔═══════════════════════════════════════════════════════════╗", fg='cyan', bold=True))
    click.echo(click.style("║                  🔐 SPRITZ LOGIN                          ║", fg='cyan', bold=True))
    click.echo(click.style("╚═══════════════════════════════════════════════════════════╝", fg='cyan', bold=True))
    
    click.echo(click.style(f"\n📋 Profile: ", fg='cyan', bold=True) + click.style(profile, fg='magenta', bold=True))
    
    config = SpritzConfig()
    
    try:
        profile_config = config.get_profile(profile)
        # Use Spritz Web URL for authentication
        authenticate_user(profile, profile_config['spritz_url'])
    except click.ClickException as e:
        click.echo(click.style(f"\n❌ {str(e)}", fg='red', bold=True), err=True)
        sys.exit(1)
