"""
Whoami command - Show current user information
"""

import click
import sys
from ..config import SpritzConfig


@click.command('whoami')
@click.option('--profile', default='default', help='Profile to check')
def whoami(profile):
    """Show current user information"""
    config = SpritzConfig()
    
    try:
        profile_config = config.get_profile(profile)
        user = profile_config.get('user')
        
        if not user:
            click.echo(click.style(f"\n⚠️  Not logged in for profile '", fg='yellow', bold=True) + 
                      click.style(profile, fg='magenta', bold=True) + 
                      click.style("'", fg='yellow', bold=True))
            click.echo(click.style(f"💡 Run 'spx login --profile {profile}' to authenticate", fg='cyan'))
            sys.exit(1)
        
        click.echo(click.style("\n╔═══════════════════════════════════════════════════════════╗", fg='cyan', bold=True))
        click.echo(click.style("║                 👤 USER INFORMATION                       ║", fg='cyan', bold=True))
        click.echo(click.style("╚═══════════════════════════════════════════════════════════╝", fg='cyan', bold=True))
        
        click.echo(click.style(f"\n📋 Profile: ", fg='cyan', bold=True) + click.style(profile, fg='magenta', bold=True))
        click.echo(click.style(f"🌐 Spritz Web: ", fg='cyan', bold=True) + click.style(profile_config['spritz_url'], fg='blue'))
        click.echo(click.style(f"🔌 Spritz API: ", fg='cyan', bold=True) + click.style(profile_config['api_url'], fg='blue'))
        
        if user.get('email'):
            click.echo(click.style(f"\n📧 Email: ", fg='cyan', bold=True) + click.style(user.get('email'), fg='green', bold=True))
        
        if user.get('username'):
            click.echo(click.style(f"👤 Username: ", fg='cyan', bold=True) + click.style(user.get('username'), fg='green', bold=True))
        
        if user.get('userId'):
            click.echo(click.style(f"🆔 User ID: ", fg='cyan', bold=True) + click.style(user.get('userId'), fg='yellow', bold=True))
        
        click.echo()
        
    except click.ClickException as e:
        click.echo(click.style(f"\n❌ {str(e)}", fg='red', bold=True), err=True)
        sys.exit(1)
