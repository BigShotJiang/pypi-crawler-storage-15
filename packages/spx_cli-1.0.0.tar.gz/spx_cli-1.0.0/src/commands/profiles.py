"""
Profile management commands
"""

import click
from ..config import SpritzConfig


@click.command('list-profiles')
def list_profiles():
    """List all configured profiles"""
    config = SpritzConfig()
    profiles = config.list_profiles()
    
    click.echo(click.style("\n╔═══════════════════════════════════════════════════════════╗", fg='cyan', bold=True))
    click.echo(click.style("║                📋 CONFIGURED PROFILES                     ║", fg='cyan', bold=True))
    click.echo(click.style("╚═══════════════════════════════════════════════════════════╝", fg='cyan', bold=True))
    
    if not profiles:
        click.echo(click.style("\n⚠️  No profiles configured.", fg='yellow', bold=True))
        click.echo(click.style("💡 Run 'spx configure' to create one.\n", fg='cyan'))
        return
    
    click.echo()
    for profile in profiles:
        try:
            profile_config = config.get_profile(profile)
            if profile_config.get('token'):
                status_icon = "✅"
                status_text = click.style("logged in", fg='green', bold=True)
            else:
                status_icon = "⚠️"
                status_text = click.style("not logged in", fg='yellow', bold=True)
            
            click.echo(click.style(f"  {status_icon} ", fg='white') + 
                      click.style(profile, fg='magenta', bold=True) + 
                      click.style(" → ", fg='cyan') + 
                      click.style(profile_config['spritz_url'], fg='blue') + 
                      click.style(" [", fg='white') + status_text + click.style("]", fg='white'))
        except:
            click.echo(click.style(f"  ❌ ", fg='red') + 
                      click.style(profile, fg='magenta', bold=True) + 
                      click.style(" (error loading)", fg='red'))
    click.echo()


@click.command('validate')
@click.option('--profile', default='default', help='Profile to validate')
def validate(profile):
    """Validate profile configuration"""
    import sys
    config = SpritzConfig()
    
    click.echo(click.style("\n╔═══════════════════════════════════════════════════════════╗", fg='cyan', bold=True))
    click.echo(click.style("║              ✅ PROFILE VALIDATION                        ║", fg='cyan', bold=True))
    click.echo(click.style("╚═══════════════════════════════════════════════════════════╝", fg='cyan', bold=True))
    
    try:
        profile_config = config.get_profile(profile)
        
        click.echo(click.style(f"\n✅ Profile '", fg='green', bold=True) + 
                  click.style(profile, fg='magenta', bold=True) + 
                  click.style("' is valid", fg='green', bold=True))
        
        click.echo(click.style(f"\n🌐 Spritz Web URL: ", fg='cyan', bold=True) + click.style(profile_config['spritz_url'], fg='blue'))
        click.echo(click.style(f"🔌 Spritz API URL: ", fg='cyan', bold=True) + click.style(profile_config['api_url'], fg='blue'))
        
        if profile_config.get('token'):
            masked_token = f"{'*' * 40}...{profile_config['token'][-10:]}"
            click.echo(click.style(f"\n🔑 Token: ", fg='cyan', bold=True) + click.style(masked_token, fg='yellow'))
        else:
            click.echo(click.style(f"\n⚠️  Token: ", fg='yellow', bold=True) + click.style("Not authenticated", fg='yellow'))
            click.echo(click.style(f"💡 Run 'spx login --profile {profile}' to authenticate", fg='cyan'))
        
        user = profile_config.get('user')
        if user:
            click.echo(click.style(f"\n👤 User Information:", fg='cyan', bold=True))
            if user.get('email'):
                click.echo(click.style(f"   📧 Email: ", fg='cyan') + click.style(user.get('email'), fg='green', bold=True))
            if user.get('userId'):
                click.echo(click.style(f"   🆔 User ID: ", fg='cyan') + click.style(user.get('userId'), fg='yellow', bold=True))
        
        click.echo()
        
    except click.ClickException as e:
        click.echo(click.style(f"\n❌ {str(e)}", fg='red', bold=True), err=True)
        sys.exit(1)
