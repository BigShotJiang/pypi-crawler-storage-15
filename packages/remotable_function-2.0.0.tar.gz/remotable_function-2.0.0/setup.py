"""
Setup script for Remotable Function.
Note: This file is kept for compatibility. Use pyproject.toml for configuration.
"""

from setuptools import setup

# Configuration is in pyproject.toml
setup()
