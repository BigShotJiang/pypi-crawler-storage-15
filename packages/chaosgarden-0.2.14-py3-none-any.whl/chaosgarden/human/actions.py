__all__ = ['wait_for']


######################
# Human Interactions #
######################

def wait_for():
    print()
    input('Press `Enter` to continue or `CTRL-C` to abort...')
    print()
