:html_theme.sidebar_secondary.remove:

#################
Development guide
#################

.. toctree::
   :maxdepth: 2

   development
   release
