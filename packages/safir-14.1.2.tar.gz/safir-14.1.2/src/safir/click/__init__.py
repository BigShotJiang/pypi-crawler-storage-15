"""Click command-line interface support."""

from ._help import display_help

__all__ = ["display_help"]
