from django.apps import AppConfig


class AsrConfig(AppConfig):
    name = "asr"
