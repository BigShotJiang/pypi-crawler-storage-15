


import asyncio
import websockets


url = "wss://test-nebula-agent.xmov.ai/user/v1/session/phone_call?asr_id=2&session_id=6-879076e41dcc471f82afe74361d7133c&llm_id=2&user_id=209&key=4bd5c5bb258eeaa4b2512ebb9af6d3be7a9183f5"


def run():
    return


async def run_websocket():
    async with websockets.serve(echo, "localhost", 8765):
        ...
    return


def main():
    return


if __name__ == "__main__":
    main()
