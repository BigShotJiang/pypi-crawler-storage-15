


```
dist/index.html                            0.38 kB │ gzip:   0.27 kB
dist/assets/Translations-BKYc0BEb.css      0.05 kB │ gzip:   0.07 kB
dist/assets/index-BPF3H0uP.css           363.62 kB │ gzip:  51.43 kB
dist/assets/Translations-3ZpwWubP.js       5.48 kB │ gzip:   2.25 kB
dist/assets/index-j7--fHis.js          1,215.59 kB │ gzip: 391.06 kB
```