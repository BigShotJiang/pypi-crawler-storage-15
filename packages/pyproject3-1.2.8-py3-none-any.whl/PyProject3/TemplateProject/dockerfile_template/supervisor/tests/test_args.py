# coding: utf-8 

from app.asr.args import get_args

def test_args():
    args = get_args()
    print(args)

