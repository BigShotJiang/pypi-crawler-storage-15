from scour.scour import scourString


def optimize_svg(svg: str):
    return scourString(svg)
