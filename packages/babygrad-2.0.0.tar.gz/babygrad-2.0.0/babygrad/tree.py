import sys
sys.setrecursionlimit(20000)


class Node:
    def __init__(self, data):
        self.data = data
        self.left = None
        self.right = None
        self.height = 1


class TreeOps:
    # --- Builders ---
    @staticmethod
    def bst_insert(root, val):
        if not root: return Node(val)
        if val < root.data: root.left = TreeOps.bst_insert(root.left, val)
        elif val > root.data: root.right = TreeOps.bst_insert(root.right, val)
        return root

    @staticmethod
    def from_level_order(arr):
        """Handles ['1', '2', 'null', '3'] or [1, 2, -1, 3] formats."""
        if not arr: return None
        # Normalize input to handle strings/ints/nulls
        nodes = []
        for x in arr:
            if str(x).lower() in ['null', 'n', '-1', 'none']: nodes.append(None)
            else: nodes.append(Node(int(x)))
            
        if not nodes or nodes[0] is None: return None
        
        root = nodes[0]
        q = [root]
        i = 1
        
        while q and i < len(nodes):
            curr = q.pop(0)
            if i < len(nodes):
                left = nodes[i]
                if left: 
                    curr.left = left
                    q.append(left)
                i += 1
            if i < len(nodes):
                right = nodes[i]
                if right: 
                    curr.right = right
                    q.append(right)
                i += 1
        return root

    # --- Solvers (The Dynamic Part) ---
    @staticmethod
    def bfs_list(root):
        """Returns list of values level-by-level."""
        if not root: return []
        res = []
        q = [root]
        while q:
            curr = q.pop(0)
            res.append(curr.data)
            if curr.left: q.append(curr.left)
            if curr.right: q.append(curr.right)
        return res

    @staticmethod
    def check_all(root, predicate):
        """
        Generic validator.
        predicate: function(node) -> bool
        Example: check_all(root, lambda n: n.left is None)
        """
        if not root: return True
        if not predicate(root): return False
        return TreeOps.check_all(root.left, predicate) and TreeOps.check_all(root.right, predicate)

    @staticmethod
    def compare(n1, n2, mode='mirror'):
        """mode: 'mirror' (symmetric) or 'same' (identical)"""
        if not n1 and not n2: return True
        if not n1 or not n2 or n1.data != n2.data: return False
        
        if mode == 'mirror':
            return TreeOps.compare(n1.left, n2.right, 'mirror') and \
                   TreeOps.compare(n1.right, n2.left, 'mirror')
        else: # same
            return TreeOps.compare(n1.left, n2.left, 'same') and \
                   TreeOps.compare(n1.right, n2.right, 'same')

