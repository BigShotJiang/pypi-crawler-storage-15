import networkx as nx


class GraphOps:
    def __init__(self, directed=False):
        self.g = nx.DiGraph() if directed else nx.Graph()

    def add(self, u, v):
        self.g.add_edge(u, v)

    # --- Classic Algorithms ---
    def bfs(self, start):
        if start not in self.g: return []
        # Custom BFS to ensure sorted neighbor traversal (Test case friendly)
        visited, q, res = {start}, [start], []
        while q:
            u = q.pop(0)
            res.append(u)
            # Sort neighbors to be deterministic
            nbrs = sorted(list(self.g.neighbors(u)))
            for v in nbrs:
                if v not in visited:
                    visited.add(v)
                    q.append(v)
        return res

    def components(self):
        """Returns connected components sorted by size/value."""
        # For undirected graphs
        comps = [sorted(list(c)) for c in nx.connected_components(self.g)]
        comps.sort(key=lambda x: x[0])
        return comps

    def topo_sort(self):
        """Returns lexicographical topological sort."""
        try:
            return list(nx.lexicographical_topological_sort(self.g))
        except:
            return "Cycle"

    # --- Grid / Island Solvers ---
    @staticmethod
    def grid_to_graph(grid, valid_val='1', diagonals=False):
        """Converts a 2D grid to a NetworkX Graph."""
        g = nx.Graph()
        rows = len(grid)
        cols = len(grid[0]) if rows > 0 else 0
        
        for r in range(rows):
            for c in range(cols):
                if str(grid[r][c]) == str(valid_val):
                    node = (r, c)
                    g.add_node(node)
                    
                    # 4-Directional Check
                    dirs = [(0,1), (1,0)] # Right, Down is enough for undirected construction
                    if diagonals: dirs += [(1,1), (1,-1)]
                    
                    for dr, dc in dirs:
                        nr, nc = r + dr, c + dc
                        if 0 <= nr < rows and 0 <= nc < cols:
                            if str(grid[nr][nc]) == str(valid_val):
                                g.add_edge(node, (nr, nc))
        return g

    @staticmethod
    def count_islands(grid):
        """The Classic Island Problem Solver."""
        g = GraphOps.grid_to_graph(grid, valid_val='1')
        return nx.number_connected_components(g)

    @staticmethod
    def flood_fill(grid, r, c, new_val):
        """Recursive Flood Fill."""
        rows, cols = len(grid), len(grid[0])
        start_val = grid[r][c]
        if start_val == new_val: return grid
        
        def dfs(x, y):
            if x < 0 or x >= rows or y < 0 or y >= cols or grid[x][y] != start_val:
                return
            grid[x][y] = new_val
            dfs(x+1, y); dfs(x-1, y); dfs(x, y+1); dfs(x, y-1)
            
        dfs(r, c)
        return grid

