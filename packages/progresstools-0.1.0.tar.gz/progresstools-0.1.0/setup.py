from setuptools import setup, find_packages

setup(
    name='progresstools',
    version='0.1.0',
    description='Simple progress bar functions for Python.',
    author='Unknown',
    packages=find_packages(),
)