# src/dimredtracer/__init__.py

from .tracer import Tracer

__all__ = ["Tracer"]
