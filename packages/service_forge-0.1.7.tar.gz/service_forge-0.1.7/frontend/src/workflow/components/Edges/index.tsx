import type { EdgeTypes } from '@xyflow/react';

import { BaseEdge } from './BaseEdge';

export const kEdgeTypes: EdgeTypes = {
  base: BaseEdge,
};
