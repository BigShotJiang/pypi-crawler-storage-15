from __future__ import annotations

class ServiceDatabaseConfig:
    def __init__(
        self,
        name: str,
        postgres_user: str,
        postgres_password: str,
        postgres_host: str,
        postgres_port: int,
        postgres_db: str,
    ) -> None:
        self.name = name
        self.postgres_user = postgres_user
        self.postgres_password = postgres_password
        self.postgres_host = postgres_host
        self.postgres_port = postgres_port
        self.postgres_db = postgres_db
    
    @staticmethod
    def from_dict(config: dict) -> ServiceDatabaseConfig:
        return ServiceDatabaseConfig(
            name=config['name'],
            postgres_user=config['postgres_user'],
            postgres_password=config['postgres_password'],
            postgres_host=config['postgres_host'],
            postgres_port=config['postgres_port'],
            postgres_db=config['postgres_db'],
        )

    def to_dict(self) -> dict:
        return {
            'name': self.name,
            'postgres_user': self.postgres_user,
            'postgres_password': self.postgres_password,
            'postgres_host': self.postgres_host,
            'postgres_port': self.postgres_port,
            'postgres_db': self.postgres_db,
        }

class ServiceConfig:
    def __init__(
        self,
        name: str,
        workflows: list[str],
        enable_http: bool,
        http_host: str,
        http_port: int,
        enable_kafka: bool,
        kafka_host: str,
        kafka_port: int,
        databases: list[ServiceDatabaseConfig],
    ) -> None:
        self.name = name
        self.workflows = workflows
        self.enable_http = enable_http
        self.http_host = http_host
        self.http_port = http_port
        self.enable_kafka = enable_kafka
        self.kafka_host = kafka_host
        self.kafka_port = kafka_port
        self.databases = databases

    @staticmethod
    def from_dict(config: dict) -> ServiceConfig:
        return ServiceConfig(
            name=config['name'],
            workflows=config['workflows'],
            enable_http=config['enable_http'],
            http_host=config['http_host'],
            http_port=config['http_port'],
            enable_kafka=config['enable_kafka'],
            kafka_host=config['kafka_host'],
            kafka_port=config['kafka_port'],
            databases=[ServiceDatabaseConfig.from_dict(database) for database in config['databases']],
        )

    def to_dict(self) -> dict:
        return {
            'name': self.name,
            'workflows': self.workflows,
            'enable_http': self.enable_http,
            'http_host': self.http_host,
            'http_port': self.http_port,
            'enable_kafka': self.enable_kafka,
            'kafka_host': self.kafka_host,
            'kafka_port': self.kafka_port,
            'databases': [database.to_dict() for database in self.databases],
        }

# name: tag_service
# workflows:
#   # - ./workflow/kafka_workflow.yaml
#   - ./workflow/query_tags_workflow.yaml
#   - ./workflow/create_tag_workflow.yaml
#   - ./workflow/update_tag_workflow.yaml
#   - ./workflow/delete_tag_workflow.yaml
#   - ./workflow/get_tags_from_record.yaml

# enable_http: true
# enable_kafka: false

# # Following configs will be auto-injected by sft.
# http_host: 0.0.0.0
# http_port: 37200
# kafka_host: localhost
# kafka_port: 9092

# databases:
#   - name: tag
#     postgres_user: postgres
#     postgres_password: "gnBGWg7aL4"
#     postgres_host: second-brain-postgres-postgresql
#     postgres_port: 5432
#     postgres_db: tag-service-tag
