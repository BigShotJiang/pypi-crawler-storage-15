from __future__ import annotations
import asyncio
from typing import AsyncIterator
from abc import ABC, abstractmethod
import uuid
from .node import Node

class Trigger(Node, ABC):
    def __init__(self, name: str):
        super().__init__(name)
        self.trigger_queue = asyncio.Queue()
        self.result_queues = {}

    @abstractmethod
    async def _run(self) -> AsyncIterator[bool]:
        ...

    def trigger(self, task_id: uuid.UUID) -> bool:
        self.prepare_output_edges(self.get_output_port_by_name('trigger'), True)
        return task_id
