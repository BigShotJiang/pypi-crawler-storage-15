"""Python unit tests for jupyterlab_colourful_tab_extension."""
