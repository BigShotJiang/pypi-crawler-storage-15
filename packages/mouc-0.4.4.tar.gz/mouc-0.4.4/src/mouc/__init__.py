"""Mouc - Mapping Outcomes User stories and Capabilities."""

__version__ = "0.4.4"
