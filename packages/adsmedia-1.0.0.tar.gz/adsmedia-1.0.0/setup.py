from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="adsmedia",
    version="1.0.0",
    author="ADSMedia",
    author_email="dev@adsmedia.ai",
    description="Official Python SDK for ADSMedia Email API",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/ADSMedia-ai/ADSMedia",
    project_urls={
        "Bug Tracker": "https://github.com/ADSMedia-ai/ADSMedia/issues",
        "Documentation": "https://www.adsmedia.ai/api-docs",
    },
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Communications :: Email",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "requests>=2.28.0",
    ],
    extras_require={
        "async": ["aiohttp>=3.8.0"],
        "dev": [
            "pytest>=7.0.0",
            "pytest-asyncio>=0.21.0",
            "black>=23.0.0",
            "mypy>=1.0.0",
            "types-requests>=2.28.0",
        ],
    },
    keywords=["adsmedia", "email", "api", "sdk", "transactional", "marketing"],
)

