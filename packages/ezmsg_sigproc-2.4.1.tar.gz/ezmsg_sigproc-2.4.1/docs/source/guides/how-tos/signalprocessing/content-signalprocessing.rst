Signal Processing HOW TOs
##########################

.. toctree::
    :maxdepth: 1

    processor
    stateful
    standalone
    adaptive
    composite
    unit
    checkpoint
