How to write a signal processor in ezmsg?
###############################################

(under construction)