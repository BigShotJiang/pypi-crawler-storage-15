How to efficiently chain multiple signal processors in ezmsg?
###############################################################

(under construction)