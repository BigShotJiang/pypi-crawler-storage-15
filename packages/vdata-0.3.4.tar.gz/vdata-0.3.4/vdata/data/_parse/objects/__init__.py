from vdata.data._parse.objects.obs import get_obs_index
from vdata.data._parse.objects.var import get_var_index

__all__ = [
    'get_obs_index',
    'get_var_index'
]