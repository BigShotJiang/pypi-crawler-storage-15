from typing import Literal

TIME_UNIT = Literal["s", "m", "h", "D", "M", "Y"]
