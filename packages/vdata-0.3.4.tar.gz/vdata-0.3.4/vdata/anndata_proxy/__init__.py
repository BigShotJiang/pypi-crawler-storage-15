from vdata.anndata_proxy.anndata import AnnDataProxy

__all__ = ["AnnDataProxy"]
