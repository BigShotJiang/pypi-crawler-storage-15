# public API of the segmenter
from .engine import rule_segment
__all__ = ["rule_segment"]

