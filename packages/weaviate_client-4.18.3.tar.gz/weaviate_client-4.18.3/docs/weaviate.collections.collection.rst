weaviate.collections.collection
===============================

.. automodule:: weaviate.collections.collection
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

.. weaviate.collections.collection.async\_
.. ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. .. automodule:: weaviate.collections.collection.async_
..    :members:
..    :undoc-members:
..    :show-inheritance:
..    :private-members:

.. weaviate.collections.collection.base
.. ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. .. automodule:: weaviate.collections.collection.base
..    :members:
..    :undoc-members:
..    :show-inheritance:
..    :private-members:

.. weaviate.collections.collection.sync
.. ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. .. automodule:: weaviate.collections.collection.sync
..    :members:
..    :undoc-members:
..    :show-inheritance:
..    :private-members:
