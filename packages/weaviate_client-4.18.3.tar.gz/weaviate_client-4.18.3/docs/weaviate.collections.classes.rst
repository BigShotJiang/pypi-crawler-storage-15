weaviate.collections.classes
============================

.. automodule:: weaviate.collections.classes
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.collections.classes.aggregate
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.collections.classes.aggregate
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.collections.classes.batch
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.collections.classes.batch
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.collections.classes.cluster
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.collections.classes.cluster
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.collections.classes.config
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.collections.classes.config
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.collections.classes.config\_base
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.collections.classes.config_base
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.collections.classes.config\_methods
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.collections.classes.config_methods
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.collections.classes.config\_named\_vectors
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.collections.classes.config_named_vectors
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.collections.classes.config\_vector\_index
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.collections.classes.config_vector_index
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.collections.classes.config\_vectorizers
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.collections.classes.config_vectorizers
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.collections.classes.data
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.collections.classes.data
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.collections.classes.filters
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.collections.classes.filters
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.collections.classes.grpc
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.collections.classes.grpc
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.collections.classes.internal
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.collections.classes.internal
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.collections.classes.orm
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.collections.classes.orm
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.collections.classes.tenants
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.collections.classes.tenants
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.collections.classes.types
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.collections.classes.types
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
