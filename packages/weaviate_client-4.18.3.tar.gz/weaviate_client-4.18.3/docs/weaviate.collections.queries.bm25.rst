weaviate.collections.queries.bm25
=================================

.. automodule:: weaviate.collections.queries.bm25
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

.. weaviate.collections.queries.bm25.generate module
.. -------------------------------------------------

.. .. automodule:: weaviate.collections.queries.bm25.generate
..    :members:
..    :undoc-members:
..    :show-inheritance:
..    :private-members:

.. weaviate.collections.queries.bm25.query module
.. ----------------------------------------------

.. .. automodule:: weaviate.collections.queries.bm25.query
..    :members:
..    :undoc-members:
..    :show-inheritance:
..    :private-members:
