"""CapInvest Regulators Extension."""
