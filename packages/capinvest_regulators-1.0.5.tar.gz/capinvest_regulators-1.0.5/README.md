# CapInvest Regulators Extension

This extension provides a structure for data sourced from various global market regulators.

 

 
