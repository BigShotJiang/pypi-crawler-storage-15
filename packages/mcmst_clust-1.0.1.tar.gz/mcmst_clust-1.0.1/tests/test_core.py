import numpy as np
from mcmst_clust import MCMSTClustering, normalize

X = np.random.rand(100, 2)
X = normalize(X)

model = MCMSTClustering(min_samples=5)
model.fit(X)
labels = model.predict(X)
print(labels)

