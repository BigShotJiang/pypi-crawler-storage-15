from Custom_Widgets.QCustomSlideMenu import QCustomSlideMenu
from Custom_Widgets.QCustomQStackedWidget import QCustomQStackedWidget as QCustomStackedWidget
from Custom_Widgets.QCustomProgressIndicator import QCustomProgressIndicator as FormProgressIndicator
from Custom_Widgets.QAppSettings import QAppSettings
from Custom_Widgets.QCustomQPushButton import QCustomQPushButton
from Custom_Widgets.__init__ import *

import warnings

warnings.warn(
    "Deprecated imports. For more information, refer to the documentation at: https://github.com/KhamisiKibet/QT-PyQt-PySide-Custom-Widgets"
)
