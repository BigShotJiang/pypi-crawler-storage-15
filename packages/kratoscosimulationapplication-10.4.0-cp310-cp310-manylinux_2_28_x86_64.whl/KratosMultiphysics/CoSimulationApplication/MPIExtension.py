import KratosMultiphysics.mpi # importing the MPI-Core, since the MPIExtension directly links to it
from KratosCoSimulationMPIExtension import *
