This module allows to configure a shipping policy on the delivery method, which
will be used by default on sales orders.
