# API endpoints
API_BASE_URL = "https://dev.api.geckowatermonitor.com"
AUTH0_BASE_URL = "https://gecko-stage.us.auth0.com"