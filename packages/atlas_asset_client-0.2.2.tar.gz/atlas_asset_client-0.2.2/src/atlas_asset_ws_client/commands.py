"""Command stream mixin stubs."""

from __future__ import annotations


class CommandStreamMixin:
    """Placeholder for command stream helpers."""

    async def send_command(self, *args, **kwargs):  # pragma: no cover - stub
        raise NotImplementedError("Command streaming is not available in this build")
