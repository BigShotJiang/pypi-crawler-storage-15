"""System stream mixin stubs."""

from __future__ import annotations


class SystemStreamMixin:
    """Placeholder for system state streaming helpers."""

    async def publish_system_status(self, *args, **kwargs):  # pragma: no cover - stub
        raise NotImplementedError("System streaming is not available in this build")
