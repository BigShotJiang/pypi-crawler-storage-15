"""Lightweight runtime/type stubs for the websocket base class."""

from __future__ import annotations


class AssetWebSocketBase:
    """Placeholder implementation used for typing and shared inheritance."""

    async def connect(self) -> None:  # pragma: no cover - stub
        raise NotImplementedError("Asset websocket base not implemented in this build")

    async def disconnect(self) -> None:  # pragma: no cover - stub
        raise NotImplementedError("Asset websocket base not implemented in this build")
