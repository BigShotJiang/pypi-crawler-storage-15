data.example_aas_mandatory_attributes - AAS-objects that only contain mandatory attributes
==========================================================================================

.. automodule:: basyx.aas.examples.data.example_aas_mandatory_attributes
