data.example_aas_missing_attributes - AAS-objects containing non-mandatory attributes
=====================================================================================

.. automodule:: basyx.aas.examples.data.example_aas_missing_attributes
