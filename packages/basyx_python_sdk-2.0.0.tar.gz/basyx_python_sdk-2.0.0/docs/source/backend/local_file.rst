local_file - Store and Retrieve AAS-objects as JSON Files
=========================================================

.. automodule:: basyx.aas.backend.local_file
