submodel - metamodel of the submodels and events
=================================================

.. automodule:: basyx.aas.model.submodel

.. autoclass:: _SE
