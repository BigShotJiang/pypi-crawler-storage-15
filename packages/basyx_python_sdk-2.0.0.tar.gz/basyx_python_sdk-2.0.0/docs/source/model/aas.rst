aas - High-level structures
===========================

.. automodule:: basyx.aas.model.aas
