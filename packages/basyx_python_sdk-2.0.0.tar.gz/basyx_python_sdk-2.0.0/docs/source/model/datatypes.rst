datatypes - Native Python Datatypes for Simple XSD-types
========================================================

.. automodule:: basyx.aas.model.datatypes
