concept - ConceptDescription and Dictionary
===========================================

.. automodule:: basyx.aas.model.concept
