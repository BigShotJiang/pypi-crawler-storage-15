Tutorial: AASX
=============================

.. _tutorial_aasx:

.. literalinclude:: ../../../basyx/aas/examples/tutorial_aasx.py
  :language: python
