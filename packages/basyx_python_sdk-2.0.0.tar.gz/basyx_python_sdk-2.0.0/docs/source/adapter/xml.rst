xml - XML serialization and deserialization
===========================================

.. automodule:: basyx.aas.adapter.xml


xml.xml_serialization - Serialization from AAS-objects to XML
#############################################################

.. automodule:: basyx.aas.adapter.xml.xml_serialization


xml.xml_deserialization - Deserialization from XML to AAS-objects
#################################################################

.. automodule:: basyx.aas.adapter.xml.xml_deserialization

.. autoclass:: LSS
