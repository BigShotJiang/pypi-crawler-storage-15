aasx - Read and write AASX-files
================================

.. automodule:: basyx.aas.adapter.aasx
