"""
This module implements a standardized way of persisting AAS objects using various backends.
"""
