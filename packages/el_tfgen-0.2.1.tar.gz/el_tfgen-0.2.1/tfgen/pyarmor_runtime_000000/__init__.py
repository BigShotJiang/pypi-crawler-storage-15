# Pyarmor 9.2.1 (trial), 000000, 2025-12-02T16:38:29.666212
from .pyarmor_runtime import __pyarmor__
