from setuptools import setup, find_packages

setup(
    name="SocatLib", # اسم  فريد (أضف اسمك)
    version="1.0.0",
    description="A Python library for network communication using socat",
    long_description=open('README.md').read(),
    long_description_content_type="text/markdown",
    author="Your Name",
    author_email="your_email@example.com",
    url="https://github.com/yourname/socat_lib",
    packages=find_packages(),
    python_requires=">=3.6",
    install_requires=[],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)