# Socat Library

A Python library for network communication using socat.

## Installation
```bash
pip install -e .
```

## Usage
```python
from socat_lib import Sending, Listening

server = Listening(4444)
result = Sending("Hello", "127.0.0.1", 4444)
print(result)
server.terminate()
```