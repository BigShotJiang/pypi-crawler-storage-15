"""Initialiser of the archSnap package."""
