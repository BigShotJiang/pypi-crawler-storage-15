"""Entry point for the ArchSnap application."""

from archsnap.main import main

if __name__ == "__main__":
    main()
