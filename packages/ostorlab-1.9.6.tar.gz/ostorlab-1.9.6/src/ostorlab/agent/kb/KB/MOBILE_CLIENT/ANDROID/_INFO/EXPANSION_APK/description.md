For applications with more than 100MB, using expansion files can be a good alternative to store additional APK assets.

The application can have two expansion files and each expansion file can be up to 2GB in size.

Unlike APK files, any files saved on the shared storage can be read by the user and other applications.