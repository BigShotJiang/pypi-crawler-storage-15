Java Native Interface (JNI) allows Java code to interact with native applications and libraries written in Rust, C, C++ and assembly.

Improper use of the Java Native Interface renders the application vulnerable to security flaws present in other programming languages, like memory corruption.
