List of all calls to Android IPC API.
