List of all Shared Preferences methods used in the application.
