The implementation is secure, no recommendation apply.
