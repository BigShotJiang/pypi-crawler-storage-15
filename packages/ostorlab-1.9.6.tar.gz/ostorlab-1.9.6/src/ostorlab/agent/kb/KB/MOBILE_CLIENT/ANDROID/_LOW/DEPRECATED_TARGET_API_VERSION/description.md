The `android:targetSdkVersion` attribute specifies the Android Target API level required by the application. Setting a low `targetSdkVersion` may allow the application to run on older Android versions but could expose users to security vulnerabilities.

Here is a link with the deprecation notice:
https://support.google.com/googleplay/android-developer/answer/11926878?hl=en