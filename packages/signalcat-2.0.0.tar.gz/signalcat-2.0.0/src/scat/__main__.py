#!/usr/bin/python3

from .main import scat_main

scat_main()