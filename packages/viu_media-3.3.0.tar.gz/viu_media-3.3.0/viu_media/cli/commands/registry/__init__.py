from .cmd import registry

__all__ = ["registry"]
