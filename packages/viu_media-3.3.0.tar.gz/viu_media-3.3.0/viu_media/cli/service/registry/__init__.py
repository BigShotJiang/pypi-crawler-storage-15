from .service import MediaRegistryService

__all__ = ["MediaRegistryService"]
