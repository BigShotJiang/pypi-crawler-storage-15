======================
watcher-tempest-plugin
======================

This repository contains a `Tempest`_ `test plugin`_ to verify the
functionality of the `Watcher`_ service.

See the following docs to learn more:

* Free software: Apache license
* Documentation: https://docs.openstack.org/watcher-tempest-plugin/latest/
* Release notes: https://docs.openstack.org/releasenotes/watcher-tempest-plugin/
* Source: https://opendev.org/openstack/watcher-tempest-plugin
* Bugs: https://bugs.launchpad.net/watcher-tempest-plugin

.. _Tempest: https://docs.openstack.org/tempest
.. _test plugin: https://docs.openstack.org/tempest/latest/plugin.html
.. _Watcher: https://docs.openstack.org/watcher/latest/

