# Copyright (C) 2025  The Software Heritage developers
# See the AUTHORS file at the top-level directory of this distribution
# License: GNU Affero General Public License version 3, or any later version
# See top-level LICENSE file for more information
import json

from pyld import jsonld
import pytest

from swh.coarnotify.server.handlers import get_handler, mention
from swh.coarnotify.server.models import InboundNotification, Statuses
from swh.model.model import MetadataAuthority, MetadataAuthorityType


def test_get_handler_unknown(inbound_notification):
    inbound_notification.payload["type"] = ["Unhandled"]
    assert get_handler(inbound_notification) is None
    assert inbound_notification.status == Statuses.UNPROCESSABLE


def test_get_handler_mention(inbound_notification):
    assert get_handler(inbound_notification) == mention


@pytest.mark.skip(
    reason=(
        "Current CN specs (1.0.1) are not clear about what should be in context.id, "
        "see handlers.mention validation steps."
    )
)
def test_mention_origin_url_context_data_id(inbound_notification):
    inbound_notification.payload["context"]["id"] = "https://wrong.url"
    assert (
        inbound_notification.payload["context"]["id"]
        != inbound_notification.payload["object"]["as:subject"]
    )

    mention(inbound_notification)

    assert inbound_notification.status == Statuses.REJECTED
    assert "does not match object as:subject" in inbound_notification.error_message


def test_mention_context_type(inbound_notification):
    inbound_notification.payload["context"]["type"] = ["sorg:Drawing"]

    mention(inbound_notification)

    assert inbound_notification.status == Statuses.REJECTED
    assert "does not contain sorg:AboutPage" in inbound_notification.error_message


def test_mention_storage_origin_url(swh_storage, inbound_notification, default_origin):
    mention(inbound_notification)

    metadata_authority = MetadataAuthority(
        type=MetadataAuthorityType.REGISTRY,
        url=inbound_notification.payload["origin"]["id"],
    )
    expanded_payload = jsonld.expand(inbound_notification.payload)
    extrinsic_metadata = swh_storage.raw_extrinsic_metadata_get(
        target=default_origin.swhid(), authority=metadata_authority
    )

    assert len(extrinsic_metadata.results) == 1
    payload = extrinsic_metadata.results[0].metadata.decode()
    assert json.loads(payload) == expanded_payload


def test_mention_storage_swhid(
    swh_storage, notification_payload, default_snapshot, partner
):
    notification_payload["object"]["as:object"] = str(default_snapshot.swhid())
    inbound_notification = InboundNotification.objects.create(
        id="00000000-0000-0000-0000-000000000000",
        payload=notification_payload,
        sender=partner,
        raw_payload=notification_payload,
    )
    mention(inbound_notification)
    metadata_authority = MetadataAuthority(
        type=MetadataAuthorityType.REGISTRY,
        url=inbound_notification.payload["origin"]["id"],
    )
    expanded_payload = jsonld.expand(inbound_notification.payload)

    extrinsic_metadata = swh_storage.raw_extrinsic_metadata_get(
        target=default_snapshot.swhid(), authority=metadata_authority
    )

    assert len(extrinsic_metadata.results) == 1
    payload = extrinsic_metadata.results[0].metadata.decode()
    assert json.loads(payload) == expanded_payload
    assert str(extrinsic_metadata.results[0].target) == str(default_snapshot.swhid())


def test_mention_storage_qualified_swhid(
    swh_storage,
    notification_payload,
    default_revision,
    default_origin,
    default_directory,
    partner,
):
    qualified_swhid = str(default_directory.swhid())
    qualifiers = {
        "origin": default_origin.url,
        "anchor": str(default_revision.swhid()),
    }
    for k, v in qualifiers.items():
        qualified_swhid += f";{k}={v}"
    notification_payload["object"]["as:object"] = qualified_swhid
    inbound_notification = InboundNotification.objects.create(
        id="00000000-0000-0000-0000-000000000000",
        payload=notification_payload,
        sender=partner,
        raw_payload=notification_payload,
    )
    mention(inbound_notification)
    metadata_authority = MetadataAuthority(
        type=MetadataAuthorityType.REGISTRY,
        url=inbound_notification.payload["origin"]["id"],
    )
    expanded_payload = jsonld.expand(inbound_notification.payload)

    extrinsic_metadata = swh_storage.raw_extrinsic_metadata_get(
        target=default_directory.swhid(), authority=metadata_authority
    )

    assert len(extrinsic_metadata.results) == 1
    result = extrinsic_metadata.results[0]
    payload = result.metadata.decode()
    assert json.loads(payload) == expanded_payload
    assert str(result.target) == str(default_directory.swhid())
    assert result.origin == default_origin.url
    assert result.revision == default_revision.swhid()


def test_mention_reply(swh_storage, inbound_notification, default_origin):
    mention(inbound_notification)

    assert inbound_notification.status == Statuses.ACCEPTED
    outbound_notification = inbound_notification.replied_by.first()
    assert (
        outbound_notification.payload["summary"]
        == f"Stored mention for {default_origin.url}"
    )


def test_mention_origin_not_archived(inbound_notification, default_origin):
    # note: we don't use the swh_storage fixture here, so default_origin is not added
    mention(inbound_notification)

    assert inbound_notification.status == Statuses.REJECTED
    outbound_notification = inbound_notification.replied_by.first()

    assert default_origin.url in outbound_notification.payload["summary"]
    assert "has not yet been archived" in outbound_notification.payload["summary"]


def test_mention_origin_alternative_url(
    swh_storage, notification_payload, default_origin, partner
):
    notification_payload["object"]["as:object"] = default_origin.url + "/"
    inbound_notification = InboundNotification.objects.create(
        id="00000000-0000-0000-0000-000000000000",
        payload=notification_payload,
        sender=partner,
        raw_payload=notification_payload,
    )

    mention(inbound_notification)

    assert inbound_notification.status == Statuses.ACCEPTED
    outbound_notification = inbound_notification.replied_by.first()

    # the metadata has been associated to the origin found in the archive
    # (default_origin), not the alternative one with a trailing slash
    assert (
        outbound_notification.payload["summary"]
        == f"Stored mention for {default_origin.url + '/'}"
    )


def test_mention_origin_swhid(
    swh_storage, notification_payload, default_snapshot, partner
):
    notification_payload["object"]["as:object"] = str(default_snapshot.swhid())
    inbound_notification = InboundNotification.objects.create(
        id="00000000-0000-0000-0000-000000000000",
        payload=notification_payload,
        sender=partner,
        raw_payload=notification_payload,
    )

    mention(inbound_notification)

    assert inbound_notification.status == Statuses.ACCEPTED
    outbound_notification = inbound_notification.replied_by.first()
    assert (
        outbound_notification.payload["summary"]
        == f"Stored mention for {default_snapshot.swhid()}"
    )
