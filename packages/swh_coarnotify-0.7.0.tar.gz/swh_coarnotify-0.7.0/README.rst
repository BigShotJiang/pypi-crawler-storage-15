Software Heritage - COAR Notify
===============================

A `COAR Notify`_ server implementation in Django. It provides a receiving endpoint
(Inbox) and handlers for `Announce Relationship pattern`_.

It is currently experimental and **not** suited for production.

.. _COAR Notify: https://coar-notify.net
.. _Announce Relationship pattern: https://coar-notify.net/specification/1.0.1/announce-relationship/