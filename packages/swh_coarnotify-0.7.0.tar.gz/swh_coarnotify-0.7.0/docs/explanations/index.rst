Explanations
============

Read more about COAR Notify principles and usages.

.. toctree::
   :maxdepth: 1

   coar-notify.rst
   metadata.rst