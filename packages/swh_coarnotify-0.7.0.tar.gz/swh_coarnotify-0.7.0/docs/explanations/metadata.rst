What are we doing with the metadata ?
=====================================

.. admonition:: Work in progress
   :class: note

   swh-coarnotify is a new project, some parts of its documentation have not been
   written yet.