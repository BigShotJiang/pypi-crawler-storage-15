from typing import Literal


PasswordHashType = Literal["bcrypt", "firebase-scrypt", "ssha"]
