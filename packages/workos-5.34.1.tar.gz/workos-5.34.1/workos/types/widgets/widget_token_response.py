from workos.types.workos_model import WorkOSModel


class WidgetTokenResponse(WorkOSModel):
    """Representation of a WorkOS widget token response."""

    token: str
