import edq

def get_version() -> str:
    """ Get the version for the EduLinq Python utils. """

    return edq.__version__
