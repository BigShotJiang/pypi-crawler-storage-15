"""
The edq.cli.http package provides CLI utilities involving HTTP.
"""
