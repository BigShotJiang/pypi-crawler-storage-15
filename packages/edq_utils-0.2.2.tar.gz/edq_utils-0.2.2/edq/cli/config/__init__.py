"""
The edq.cli.config package provides tools for working with project configuration options.
"""
