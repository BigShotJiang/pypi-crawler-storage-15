# EGAIN
Abolfazl Saghafi, Soodeh Moallemian, Miray Budak, and Rutvik Deshpande, EGAIN: Enhanced Generative Adversarial Networks for Imputing Missing Values, Under Review.

# Requirements
The codes require `python >= 3.11`. Main required libraries and their versions are:
```console
numpy >= 1.26.4
pandas >= 2.2.2
tensorflow >= 2.18.0
scikit-learn >= 1.6.1
matplotlib >= 3.10.0
tqdm >= 4.67.1
```

# Installation
First install the above requirements with their versions using `pip`, then instal EGAIN using `pip`, and load required libraries:
```console
!pip install EGAIN

## Import requirements
##-------------------
import numpy as np
import pandas as pd
import tensorflow as tf
import matplotlib.pyplot as plt
from tqdm import tqdm
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Dense, Input, Flatten, MaxPooling1D, Conv1D
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import root_mean_squared_error
from EGAIN import EGAIN
from EGAIN import plot_losses, rounding, rmse_loss
```
Alternatively, you can install EGAIN directly from this github page. This option works great if you are using google collaboratory: 
```python
## Clone EGAIN 
!git clone https://github.com/asaghafi/EGAIN.git

## Install requirements
%cd /content/EGAIN
!pip install -r requirements.txt

## Import utility functions
import sys
sys.path.append('/content/EGAIN')
from utils import *
from EGAIN import EGAIN
```


# Best hyperparameters
To find the best `alpha`, best iterations, and best batch size follow instructions at the github page:
https://github.com/asaghafi/EGAIN


