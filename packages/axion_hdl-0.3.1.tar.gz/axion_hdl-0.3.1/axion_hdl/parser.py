"""
VHDL Parser Module for Axion HDL

This module parses VHDL files and extracts @axion annotations.
Uses axion_hdl for reusable utilities.
"""

import os
import re
import fnmatch
from typing import Dict, List, Optional, Tuple, Set

# Import from axion_hdl (unified package)
from axion_hdl.address_manager import AddressManager
from axion_hdl.vhdl_utils import VHDLUtils
from axion_hdl.annotation_parser import AnnotationParser


class VHDLParser:
    """Parser for extracting @axion annotations from VHDL files."""
    
    def __init__(self):
        self.annotation_parser = AnnotationParser(annotation_prefix='@axion')
        self.vhdl_utils = VHDLUtils()
        self.axion_signal_pattern = re.compile(
            r'signal\s+(\w+)\s*:\s*([^;]+);\s*--\s*@axion\s+(.+)'
        )
        # Exclusion patterns (files, directories, or glob patterns)
        self.exclude_patterns: Set[str] = set()
    
    def parse_file(self, filepath: str) -> Optional[Dict]:
        """
        Parse a single VHDL file and return structured data.
        
        Public API for parsing individual files.
        
        Args:
            filepath: Path to the VHDL file
            
        Returns:
            Dictionary with parsed data or None if no valid data found.
            Keys:
                - entity_name: Name of the VHDL entity
                - signals: List of signal dictionaries with:
                    - name: Signal name
                    - width: Signal bit width  
                    - access: Access mode (RO, RW, WO)
                    - address: Integer address
                    - r_strobe: Read strobe flag
                    - w_strobe: Write strobe flag
                    - description: Signal description
                - base_addr: Base address for the module
                - cdc_en: CDC enabled flag
                - cdc_stage: CDC stage count
        """
        result = self._parse_vhdl_file(filepath)
        if result is None:
            return None
            
        # Convert internal format to test-friendly format
        signals = []
        for reg in result.get('registers', []):
            sig = {
                'name': reg.get('signal_name', ''),
                'width': self._extract_width(reg.get('signal_type', '')),
                'access': reg.get('access_mode', 'RW'),
                'address': reg.get('relative_address_int', 0),
                'r_strobe': reg.get('read_strobe', False),
                'w_strobe': reg.get('write_strobe', False),
                'description': reg.get('description', '')
            }
            signals.append(sig)
        
        return {
            'entity_name': result.get('name'),
            'signals': signals,
            'base_addr': result.get('base_address', 0),
            'cdc_en': result.get('cdc_enabled', False),
            'cdc_stage': result.get('cdc_stages', 2)
        }
    
    def _extract_width(self, signal_type: str) -> int:
        """Extract bit width from signal type string."""
        if signal_type == 'std_logic' or signal_type == '[0:0]':
            return 1
        # Match [high:low] format
        match = re.search(r'\[(\d+):(\d+)\]', signal_type)
        if match:
            high = int(match.group(1))
            low = int(match.group(2))
            return high - low + 1
        # Match (high downto low) format
        match = re.search(r'\((\d+)\s+downto\s+(\d+)\)', signal_type)
        if match:
            high = int(match.group(1))
            low = int(match.group(2))
            return high - low + 1
        return 32  # Default width
        
    def add_exclude(self, pattern: str):
        """
        Add an exclusion pattern.
        
        Patterns can be:
        - File names: "address_conflict_test.vhd"
        - Directory names: "error_cases"
        - Glob patterns: "test_*.vhd", "*_tb.vhd"
        - Path patterns: "tests/error_cases/*"
        
        Args:
            pattern: Pattern to exclude from parsing
        """
        self.exclude_patterns.add(pattern)
        
    def remove_exclude(self, pattern: str):
        """Remove an exclusion pattern."""
        self.exclude_patterns.discard(pattern)
        
    def clear_excludes(self):
        """Clear all exclusion patterns."""
        self.exclude_patterns.clear()
        
    def list_excludes(self) -> List[str]:
        """Return list of exclusion patterns."""
        return sorted(list(self.exclude_patterns))
        
    def _is_excluded(self, filepath: str) -> bool:
        """
        Check if a file path matches any exclusion pattern.
        
        Args:
            filepath: Full path to the file
            
        Returns:
            True if file should be excluded, False otherwise
        """
        if not self.exclude_patterns:
            return False
            
        # Get various forms of the path for matching
        filename = os.path.basename(filepath)
        dirname = os.path.dirname(filepath)
        dir_basename = os.path.basename(dirname)
        
        for pattern in self.exclude_patterns:
            # Check filename match
            if fnmatch.fnmatch(filename, pattern):
                return True
            # Check if pattern matches directory name
            if fnmatch.fnmatch(dir_basename, pattern):
                return True
            # Check if pattern is in the full path
            if pattern in filepath:
                return True
            # Check full path glob match
            if fnmatch.fnmatch(filepath, f"*{pattern}*"):
                return True
                
        return False
        
    def parse_vhdl_files(self, source_dirs: List[str]) -> List[Dict]:
        """
        Parse all VHDL files in source directories.
        
        Args:
            source_dirs: List of source directory paths
            
        Returns:
            List of parsed module dictionaries
        """
        modules = []
        
        for src_dir in source_dirs:
            vhdl_files = self._find_vhdl_files(src_dir)
            
            for vhdl_file in vhdl_files:
                # Check exclusions
                if self._is_excluded(vhdl_file):
                    continue
                    
                module_data = self._parse_vhdl_file(vhdl_file)
                if module_data and module_data['registers']:
                    modules.append(module_data)
                    
        return modules
    
    def _find_vhdl_files(self, directory: str) -> List[str]:
        """Find all VHDL files in directory (recursive)."""
        vhdl_files = []
        for root, dirs, files in os.walk(directory):
            # Filter out excluded directories to prevent descending into them
            dirs[:] = [d for d in dirs if not self._is_excluded(os.path.join(root, d))]
            
            for file in files:
                if file.endswith(('.vhd', '.vhdl')):
                    vhdl_files.append(os.path.join(root, file))
        return vhdl_files
    
    def _parse_vhdl_file(self, filepath: str) -> Optional[Dict]:
        """Parse a single VHDL file."""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
        except Exception as e:
            print(f"Warning: Could not read {filepath}: {e}")
            return None
        
        # Extract entity name using common utilities
        entity_name = self.vhdl_utils.extract_entity_name(content)
        if not entity_name:
            return None
        
        # Parse @axion_def using annotation parser
        cdc_enabled, cdc_stages, base_address = self._parse_axion_def(content)
        
        # Parse signal annotations with base_address offset
        registers = self._parse_signal_annotations(content, base_address, entity_name)
        
        if not registers:
            return None
            
        return {
            'name': entity_name,
            'file': filepath,
            'cdc_enabled': cdc_enabled,
            'cdc_stages': cdc_stages,
            'base_address': base_address,
            'registers': registers
        }
    
    def _parse_axion_def(self, content: str) -> Tuple[bool, int, int]:
        """Parse @axion_def annotation using common library."""
        attrs = self.annotation_parser.parse_def_annotation(content)
        
        if not attrs:
            return False, 2, 0x00
        
        cdc_enabled = attrs.get('cdc_enabled', False)
        cdc_stages = attrs.get('cdc_stages', 2)
        base_address = attrs.get('base_address', 0x00)
        
        # Ensure base_address is an integer
        if isinstance(base_address, str):
            if base_address.startswith('0x') or base_address.startswith('0X'):
                base_address = int(base_address, 16)
            else:
                base_address = int(base_address)
            
        return cdc_enabled, cdc_stages, base_address
    
    def _parse_signal_annotations(self, content: str, base_address: int = 0x00, module_name: str = "") -> List[Dict]:
        """
        Parse all @axion signal annotations.
        
        Args:
            content: VHDL file content
            base_address: Base address offset to add to all register addresses
            module_name: Name of the module (for error messages)
        """
        registers = []
        addr_mgr = AddressManager(start_addr=0x00, alignment=4, module_name=module_name)
        
        for match in self.axion_signal_pattern.finditer(content):
            signal_name = match.group(1)
            signal_type_str = match.group(2).strip()
            attrs_str = match.group(3).strip()
            
            # Parse signal type using common utilities
            type_name, high_bit, low_bit = self.vhdl_utils.parse_signal_type(signal_type_str)
            signal_type = self.vhdl_utils.format_signal_type(high_bit, low_bit)
            signal_width = high_bit - low_bit + 1
            
            # Info for signals wider than 32 bits
            if signal_width > 32:
                num_regs = (signal_width + 31) // 32
                print(f"INFO: Signal '{signal_name}' is {signal_width} bits wide -> {num_regs} AXI registers allocated.")
            
            # Parse attributes using annotation parser
            attrs = self.annotation_parser.parse_attributes(attrs_str)
            
            # Allocate relative address (with signal width for proper spacing)
            manual_addr = attrs.get('address')
            if manual_addr is not None:
                relative_addr = addr_mgr.allocate_address(manual_addr, signal_width, signal_name)
            else:
                relative_addr = addr_mgr.allocate_address(signal_width=signal_width, signal_name=signal_name)
            
            # Add base address offset to get absolute address
            absolute_addr = base_address + relative_addr
            
            # Build register data
            reg_data = {
                'signal_name': signal_name,
                'signal_type': signal_type,
                'address': addr_mgr.format_address(absolute_addr),
                'address_int': absolute_addr,
                'relative_address': addr_mgr.format_address(relative_addr),
                'relative_address_int': relative_addr,
                'access_mode': attrs.get('access_mode', 'RW'),
                'read_strobe': attrs.get('read_strobe', False),
                'write_strobe': attrs.get('write_strobe', False),
                'description': attrs.get('description', '')
            }
            
            registers.append(reg_data)
                
        return registers
