Functions
=========

.. automodule:: xarpes.functions
   :members:
