Spectral
========

.. automodule:: xarpes.spectral
   :members:
