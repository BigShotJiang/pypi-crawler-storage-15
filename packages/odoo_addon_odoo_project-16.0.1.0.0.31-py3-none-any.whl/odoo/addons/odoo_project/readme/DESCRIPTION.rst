This module allows to declare your Odoo projects and analyze their code bases.
