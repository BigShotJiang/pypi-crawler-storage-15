from . import test_partner_supplier_ref
