def main():
    print("Hello from btc2sim!")


if __name__ == "__main__":
    main()
