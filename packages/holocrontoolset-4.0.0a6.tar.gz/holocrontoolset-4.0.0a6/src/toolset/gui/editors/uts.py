from __future__ import annotations

from copy import deepcopy
from typing import TYPE_CHECKING

from qtpy import QtCore
from qtpy.QtCore import QBuffer
from qtpy.QtMultimedia import QMediaPlayer
from qtpy.QtWidgets import QListWidgetItem, QMessageBox

from pykotor.common.misc import ResRef
from pykotor.resource.formats.gff import write_gff
from pykotor.resource.generics.uts import UTS, dismantle_uts, read_uts
from pykotor.resource.type import ResourceType
from toolset.gui.dialogs.edit.locstring import LocalizedStringDialog
from toolset.gui.editor import Editor

if TYPE_CHECKING:
    import os

    from qtpy.QtGui import QCloseEvent
    from qtpy.QtWidgets import QWidget

    from pykotor.resource.formats.gff.gff_data import GFF
    from toolset.data.installation import HTInstallation


class UTSEditor(Editor):
    def __init__(
        self,
        parent: QWidget | None,
        installation: HTInstallation | None = None,
    ):
        """Initialize the Sound Editor window.

        Args:
        ----
            parent: {QWidget}: The parent widget of this window
            installation: {HTInstallation}: The installation object

        Processing Logic:
        ----------------
            - Initialize supported resource types
            - Initialize the superclass with window details
            - Initialize UTS object
            - Initialize media player and buffer
            - Load UI from designer file
            - Set up menus, signals and installation.
        """
        supported: list[ResourceType] = [ResourceType.UTS]
        super().__init__(parent, "Sound Editor", "sound", supported, supported, installation)

        self._uts: UTS = UTS()

        self.player = QMediaPlayer(self)
        self.buffer = QBuffer(self)

        from toolset.uic.qtpy.editors.uts import Ui_MainWindow

        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self._setup_menus()
        self._add_help_action()
        self._setup_signals()
        if installation is not None:  # will only be none in the unittests
            self._setup_installation(installation)

        # Setup scrollbar event filter to prevent scrollbar interaction with controls
        from toolset.gui.common.filters import NoScrollEventFilter
        self._no_scroll_filter = NoScrollEventFilter(self)
        self._no_scroll_filter.setup_filter(parent_widget=self)

        self.new()

    def _setup_signals(self):
        """Sets up signal connections for UI buttons and radio buttons.

        Processing Logic:
        ----------------
            - Connects addSoundButton click signal to addSound method
            - Connects removeSoundButton click signal to removeSound method
            - Connects playSoundButton click signal to play_sound method
            - Connects stopSoundButton click signal to player stop method
            - Connects moveUpButton and moveDownButton click signals to moveSoundUp and moveSoundDown methods
            - Connects tagGenerateButton and resrefGenerateButton click signals to generate_tag and generate_resref methods
            - Connects style radio buttons toggled signals to changeStyle method
            - Connects play random/specific/everywhere radio buttons toggled signals to changePlay method.
        """
        self.ui.addSoundButton.clicked.connect(self.add_sound)
        self.ui.removeSoundButton.clicked.connect(self.remove_sound)
        self.ui.playSoundButton.clicked.connect(self.play_sound)
        self.ui.stopSoundButton.clicked.connect(self.player.stop)
        self.ui.moveUpButton.clicked.connect(self.move_sound_up)
        self.ui.moveDownButton.clicked.connect(self.move_sound_down)

        self.ui.tagGenerateButton.clicked.connect(self.generate_tag)
        self.ui.resrefGenerateButton.clicked.connect(self.generate_resref)

        self.ui.styleOnceRadio.toggled.connect(self.change_style)
        self.ui.styleSeamlessRadio.toggled.connect(self.change_style)
        self.ui.styleRepeatRadio.toggled.connect(self.change_style)

        self.ui.playRandomRadio.toggled.connect(self.change_play)
        self.ui.playSpecificRadio.toggled.connect(self.change_play)
        self.ui.playEverywhereRadio.toggled.connect(self.change_play)

    def _setup_installation(self, installation: HTInstallation):
        self._installation = installation
        self.ui.nameEdit.set_installation(installation)

    def load(
        self,
        filepath: os.PathLike | str,
        resref: str,
        restype: ResourceType,
        data: bytes,
    ):
        super().load(filepath, resref, restype, data)

        uts: UTS = read_uts(data)
        self._loadUTS(uts)

    def _loadUTS(
        self,
        uts: UTS,
    ):
        """Loads UTS data into UI controls.

        Args:
        ----
            uts (UTS): UTS object to load

        Processing Logic:
        ----------------
            - Sets basic property values like name, tag, etc
            - Sets advanced playback options like random, specific position
            - Loads sounds list
            - Sets positioning options like style, distances
            - Loads comments.
        """
        self._uts = uts

        # Basic
        self.ui.nameEdit.set_locstring(uts.name)
        self.ui.tagEdit.setText(uts.tag)
        self.ui.resrefEdit.setText(str(uts.resref))
        self.ui.volumeSlider.setValue(uts.volume)
        self.ui.activeCheckbox.setChecked(uts.active)

        # Advanced
        self.ui.playRandomRadio.setChecked(False)
        self.ui.playSpecificRadio.setChecked(False)
        self.ui.playEverywhereRadio.setChecked(False)
        if uts.random_range_x != 0 and uts.random_range_y != 0:
            self.ui.playRandomRadio.setChecked(True)
        elif uts.positional:
            self.ui.playSpecificRadio.setChecked(True)
        else:
            self.ui.playEverywhereRadio.setChecked(True)

        self.ui.orderSequentialRadio.setChecked(uts.random_pick == 0)
        self.ui.orderRandomRadio.setChecked(uts.random_pick == 1)

        self.ui.intervalSpin.setValue(uts.interval)
        self.ui.intervalVariationSpin.setValue(uts.interval_variation)
        self.ui.volumeVariationSlider.setValue(uts.volume_variation)
        self.ui.pitchVariationSlider.setValue(int(uts.pitch_variation * 100))

        # Sounds
        self.ui.soundList.clear()
        for sound in uts.sounds:
            item = QListWidgetItem(str(sound))
            item.setFlags(item.flags() | QtCore.Qt.ItemFlag.ItemIsEditable)
            self.ui.soundList.addItem(item)

        # Positioning
        self.ui.styleOnceRadio.setChecked(False)
        self.ui.styleSeamlessRadio.setChecked(False)
        self.ui.styleRepeatRadio.setChecked(False)
        if uts.continuous and uts.looping:
            self.ui.styleSeamlessRadio.setChecked(True)
        elif uts.looping:
            self.ui.styleRepeatRadio.setChecked(True)
        else:
            self.ui.styleOnceRadio.setChecked(True)

        self.ui.cutoffSpin.setValue(uts.max_distance)
        self.ui.maxVolumeDistanceSpin.setValue(uts.min_distance)
        self.ui.heightSpin.setValue(uts.elevation)
        self.ui.northRandomSpin.setValue(uts.random_range_y)
        self.ui.eastRandomSpin.setValue(uts.random_range_x)

        # Comments
        self.ui.commentsEdit.setPlainText(uts.comment)

    def build(self) -> tuple[bytes, bytes]:
        """Builds a UTS from UI fields.

        Returns:
        -------
            tuple[bytes, bytes]: A tuple containing the unit data and log.

        Processing Logic:
        ----------------
            - Collects input from UI elements and assigns to _uts attribute
            - Loops through sound list adding each sound to _uts
            - Writes _uts to bytearray using dismantle_uts and write_gff
            - Returns bytearray tuple.
        """
        uts: UTS = deepcopy(self._uts)

        # Basic
        uts.name = self.ui.nameEdit.locstring()
        uts.tag = self.ui.tagEdit.text()
        uts.resref = ResRef(self.ui.resrefEdit.text())
        uts.volume = self.ui.volumeSlider.value()
        uts.active = self.ui.activeCheckbox.isChecked()

        # Advanced
        uts.random_range_x = self.ui.northRandomSpin.value()
        uts.random_range_y = self.ui.eastRandomSpin.value()
        uts.positional = self.ui.playSpecificRadio.isChecked()
        uts.random_pick = self.ui.orderRandomRadio.isChecked()
        uts.interval = self.ui.intervalSpin.value()
        uts.interval_variation = self.ui.intervalVariationSpin.value()
        uts.volume_variation = self.ui.volumeVariationSlider.value()
        uts.pitch_variation = self.ui.pitchVariationSlider.value() / 100

        # Sounds
        uts.sounds = []
        for i in range(self.ui.soundList.count()):
            cur_item: QListWidgetItem | None = self.ui.soundList.item(i)
            if cur_item is None:
                continue
            sound = ResRef(cur_item.text())
            uts.sounds.append(sound)

        # Positioning
        uts.continuous = self.ui.styleSeamlessRadio.isChecked()
        uts.looping = self.ui.styleSeamlessRadio.isChecked() or self.ui.styleRepeatRadio.isChecked()
        uts.max_distance = self.ui.maxVolumeDistanceSpin.value()
        uts.min_distance = self.ui.cutoffSpin.value()
        uts.elevation = self.ui.heightSpin.value()
        uts.random_range_x = self.ui.northRandomSpin.value()
        uts.random_range_y = self.ui.eastRandomSpin.value()

        # Comments
        uts.comment = self.ui.commentsEdit.toPlainText()

        data = bytearray()
        gff: GFF = dismantle_uts(uts)
        write_gff(gff, data)

        return data, b""

    def new(self):
        super().new()
        self._loadUTS(UTS())

    def change_name(self):
        assert self._installation is not None
        dialog = LocalizedStringDialog(self, self._installation, self.ui.nameEdit.locstring())
        if dialog.exec():
            self._load_locstring(self.ui.nameEdit.ui.locstringText, dialog.locstring)

    def generate_tag(self):
        if self.ui.resrefEdit.text() == "":
            self.generate_resref()
        self.ui.tagEdit.setText(self.ui.resrefEdit.text())

    def generate_resref(self):
        if self._resname is not None and self._resname != "":
            self.ui.resrefEdit.setText(self._resname)
        else:
            self.ui.resrefEdit.setText("m00xx_trg_000")

    def change_style(self):
        def _set_ui_style_groups(boolean: bool):  # noqa: FBT001
            self.ui.intervalGroup.setEnabled(boolean)
            self.ui.orderGroup.setEnabled(boolean)
            self.ui.variationGroup.setEnabled(boolean)

        _set_ui_style_groups(True)
        if self.ui.styleSeamlessRadio.isChecked():
            _set_ui_style_groups(False)
        elif self.ui.styleRepeatRadio.isChecked():
            ...
        elif self.ui.styleOnceRadio.isChecked():
            self.ui.intervalGroup.setEnabled(False)

    def change_play(self):
        def _set_ui_play_groups(boolean: bool):  # noqa: FBT001
            self.ui.rangeGroup.setEnabled(boolean)
            self.ui.heightGroup.setEnabled(boolean)
            self.ui.distanceGroup.setEnabled(boolean)

        _set_ui_play_groups(True)
        if self.ui.playRandomRadio.isChecked():
            ...
        elif self.ui.playSpecificRadio.isChecked():
            self.ui.rangeGroup.setEnabled(False)
            self.ui.northRandomSpin.setValue(0)
            self.ui.eastRandomSpin.setValue(0)
        elif self.ui.playEverywhereRadio.isChecked():
            _set_ui_play_groups(False)

    def play_sound(self):
        self.player.stop()

        cur_item: QListWidgetItem | None = self.ui.soundList.currentItem()
        cur_item_text: str | None = cur_item.text() if cur_item else None
        if not cur_item or not cur_item_text:
            return

        resname: str = cur_item_text
        assert self._installation is not None
        data: bytes | None = self._installation.sound(resname)

        if data:
            self.play_byte_source_media(data)
            return True
        else:
            QMessageBox(QMessageBox.Icon.Critical, "Could not find audio file", f"Could not find audio resource '{resname}'.")

    def add_sound(self):
        item = QListWidgetItem("new sound")
        item.setFlags(item.flags() | QtCore.Qt.ItemFlag.ItemIsEditable)
        self.ui.soundList.addItem(item)

    def remove_sound(self):
        if self.ui.soundList.currentRow() == -1:
            return
        self.ui.soundList.takeItem(self.ui.soundList.currentRow())

    def move_sound_up(self):
        if self.ui.soundList.currentRow() == -1:
            return
        cur_item: QListWidgetItem | None = self.ui.soundList.currentItem()
        if cur_item is None:
            return
        resname: str = cur_item.text()
        row: int = self.ui.soundList.currentRow()
        self.ui.soundList.takeItem(self.ui.soundList.currentRow())
        self.ui.soundList.insertItem(row - 1, resname)
        self.ui.soundList.setCurrentRow(row - 1)
        item: QListWidgetItem | None = self.ui.soundList.item(row - 1)
        if item is None:
            return
        item.setFlags(item.flags() | QtCore.Qt.ItemFlag.ItemIsEditable)

    def move_sound_down(self):
        if self.ui.soundList.currentRow() == -1:
            return
        cur_item: QListWidgetItem | None = self.ui.soundList.currentItem()
        if cur_item is None:
            return
        resname: str = cur_item.text()
        row: int = self.ui.soundList.currentRow()
        self.ui.soundList.takeItem(self.ui.soundList.currentRow())
        self.ui.soundList.insertItem(row + 1, resname)
        self.ui.soundList.setCurrentRow(row + 1)
        item: QListWidgetItem | None = self.ui.soundList.item(row + 1)
        if item is None:
            return
        item.setFlags(item.flags() | QtCore.Qt.ItemFlag.ItemIsEditable)

    def closeEvent(self, e: QCloseEvent):
        self.player.stop()
