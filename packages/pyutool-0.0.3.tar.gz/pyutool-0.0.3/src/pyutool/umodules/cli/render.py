








class MapAssistant:
    def __init__(self):
        pass
    def render_(self):
        pass