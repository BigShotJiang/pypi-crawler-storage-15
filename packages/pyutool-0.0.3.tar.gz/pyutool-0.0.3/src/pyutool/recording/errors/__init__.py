# -*- coding: utf-8 -*-
"""
@Project : pyutool
@File    : __init__.py
@Author  : YL_top01
@Date    : 2025/8/25 15:58
"""

# Built-in modules
# (无内置模块)

# Third-party modules
# (无第三方依赖)

# Local modules
# (无本地依赖)
