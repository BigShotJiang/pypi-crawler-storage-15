"""Core formatting abstractions for tool-agnostic table rendering."""
