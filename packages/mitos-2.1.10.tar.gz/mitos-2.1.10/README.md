[![European Galaxy server](https://img.shields.io/badge/usegalaxy-.eu-brightgreen?logo=data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAASCAYAAABB7B6eAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAACXBIWXMAAAsTAAALEwEAmpwYAAACC2lUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iWE1QIENvcmUgNS40LjAiPgogICA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogICAgICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgICAgICAgICB4bWxuczp0aWZmPSJodHRwOi8vbnMuYWRvYmUuY29tL3RpZmYvMS4wLyI+CiAgICAgICAgIDx0aWZmOlJlc29sdXRpb25Vbml0PjI8L3RpZmY6UmVzb2x1dGlvblVuaXQ+CiAgICAgICAgIDx0aWZmOkNvbXByZXNzaW9uPjE8L3RpZmY6Q29tcHJlc3Npb24+CiAgICAgICAgIDx0aWZmOk9yaWVudGF0aW9uPjE8L3RpZmY6T3JpZW50YXRpb24+CiAgICAgICAgIDx0aWZmOlBob3RvbWV0cmljSW50ZXJwcmV0YXRpb24+MjwvdGlmZjpQaG90b21ldHJpY0ludGVycHJldGF0aW9uPgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgPC9yZGY6UkRGPgo8L3g6eG1wbWV0YT4KD0UqkwAAAn9JREFUOBGlVEuLE0EQruqZiftwDz4QYT1IYM8eFkHFw/4HYX+GB3/B4l/YP+CP8OBNTwpCwFMQXAQPKtnsg5nJZpKdni6/6kzHvAYDFtRUT71f3UwAEbkLch9ogQxcBwRKMfAnM1/CBwgrbxkgPAYqlBOy1jfovlaPsEiWPROZmqmZKKzOYCJb/AbdYLso9/9B6GppBRqCrjSYYaquZq20EUKAzVpjo1FzWRDVrNay6C/HDxT92wXrAVCH3ASqq5VqEtv1WZ13Mdwf8LFyyKECNbgHHAObWhScf4Wnj9CbQpPzWYU3UFoX3qkhlG8AY2BTQt5/EA7qaEPQsgGLWied0A8VKrHAsCC1eJ6EFoUd1v6GoPOaRAtDPViUr/wPzkIFV9AaAZGtYB568VyJfijV+ZBzlVZJ3W7XHB2RESGe4opXIGzRTdjcAupOK09RA6kzr1NTrTj7V1ugM4VgPGWEw+e39CxO6JUw5XhhKihmaDacU2GiR0Ohcc4cZ+Kq3AjlEnEeRSazLs6/9b/kh4eTC+hngE3QQD7Yyclxsrf3cpxsPXn+cFdenF9aqlBXMXaDiEyfyfawBz2RqC/O9WF1ysacOpytlUSoqNrtfbS642+4D4CS9V3xb4u8P/ACI4O810efRu6KsC0QnjHJGaq4IOGUjWTo/YDZDB3xSIxcGyNlWcTucb4T3in/3IaueNrZyX0lGOrWndstOr+w21UlVFokILjJLFhPukbVY8OmwNQ3nZgNJNmKDccusSb4UIe+gtkI+9/bSLJDjqn763f5CQ5TLApmICkqwR0QnUPKZFIUnoozWcQuRbC0Km02knj0tPYx63furGs3x/iPnz83zJDVNtdP3QAAAABJRU5ErkJggg==)](https://usegalaxy.eu/root?tool_id=mitos2)

These are the mitogenome related sources including MITOS and other (more or less) helpful tools. Note that some of the tools are unfinished and not in a production state.

Usage on Galaxy
===============

MITOS should primarily be used via Galaxy. It is available for instance on usegalaxy.eu

- [MITOS2](https://usegalaxy.eu/?tool_id=toolshed.g2.bx.psu.edu%2Frepos%2Fiuc%2Fmitos2%2Fmitos2%2F2.1.7%2Bgalaxy1&version=latest)
- [MITOS](https://usegalaxy.eu/?tool_id=toolshed.g2.bx.psu.edu%2Frepos%2Fiuc%2Fmitos%2Fmitos%2F1.1.5%2Bgalaxy0&version=latest)



Installation
============

There are two ways to install. Preferred is the installation via conda since this also takes care of non-python requirements of the main mitos script.

1. via conda: `conda create --strict-channel-priority -c conda-forge -c bioconda -n mitos2 "mitos>=2"`
   - this will create a conda environment and install MITOS2. For MITOS use `conda create --strict-channel-priority -c conda-forge -c bioconda -n mitos "mitos<2"`
   - enable the conda environment with `conda activate mitos2` (resp. `conda activate mitos`)
   - in case of problems with resolving environments try to use use `--solver libmamba` or replace `conda` by `mamba`.
2. via pip: `pip install mitos`

For the non-python requirements see README.MITOS.

Development Setup
=================

For developers who want to contribute to MITOS:

1. **Fork the repository** on GitLab: https://gitlab.com/Bernt/MITOS
2. **Clone your fork:**
   ```bash
   git clone https://gitlab.com/YOUR_USERNAME/MITOS.git
   cd MITOS
   ```
3. **Set up development environment:**

   **Option A: Python-only (for basic development):**
   ```bash
   pip install -r dev_requirements.txt
   ```

   **Option B: Full conda environment (required for integration tests):**
   ```bash
   # Create conda environment with all dependencies
   conda create --strict-channel-priority -c conda-forge -c bioconda -n mitos-dev python=3.7 \
     biopython=1.73 blast>=2.9 hmmer=3.4 infernal>=1.1.5 viennarna r-base r-ggplot2 \
     r-reshape2 openjdk reportlab pillow libtiff pip

   # Activate environment and install MITOS in development mode
   conda activate mitos-dev
   pip install -r dev_requirements.txt
   ```
4. **Optional: Set up pre-commit hooks for automatic linting:**
   ```bash
   pip install pre-commit
   pre-commit install
   ```

   This will automatically take care of things like trailing whitespace, empty lines at the end of files and it will run black, isort, flake8 and mypy before each commit. See configuration in `.pre-commit-config.yaml`.

### Development Workflow

**Running tests:**
```bash
# Linting and code style
tox -e lint

# Type checking
tox -e type

# Unit tests
tox -e py37

# Integration tests (requires conda and reference data)
tox -e integration-py37
```

**Before submitting a merge request:**
1. Ensure all tests pass: `tox`
2. Follow the existing code style
3. Add tests for new functionality
4. Update documentation if needed

MITOS
=====

* runmitos.py: standalone CLI MITOS

From runmitos.py help:

```
mandatory options:
  -c CODE, --code CODE  the genetic code
  -o OUTDIR, --outdir OUTDIR
                        the directory where the output is written
  --linear              treat sequence as linear (not mandatory for circular sequences)
  -r REFSEQVER, --refseqver REFSEQVER
                        directory containing the reference data (relative to --refdir)

```

Please note that the reference data for the `-r` flag needs to be downloaded from Zenodo ([MITOS](https://zenodo.org/record/2683856), [MITOS2](https://zenodo.org/record/4284483)).

see also `runmitos.py --help` or README.MITOS

genbank file handling
=====================

* refseqsplit:
    - splits a file consisting of concatenated gb files into single genbank files
    - its possible to apply filters (taxonomy, prefix)

skewness related programs
=========================

* skew:
	compute skewness values for a gene of given genbank files
* skewcum:
	compute cumulative skewness for given genbank files
* skewsvm:
	do svm classification of skewness values .. and try to relate misclassifications to rearrangements

MISC
====

* gcpp
	- pretty print and compare genetic code
