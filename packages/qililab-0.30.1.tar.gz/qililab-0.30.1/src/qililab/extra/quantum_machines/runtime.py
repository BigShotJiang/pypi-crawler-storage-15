# Copyright 2023 Qilimanjaro Quantum Tech
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Runtime helpers for Quantum Machines optional integration."""

from __future__ import annotations

from typing import Any, Callable, cast

from qililab._optionals import OptionalFeature, Symbol, import_optional_dependencies

_QM_RUNTIME = OptionalFeature(
    name="quantum-machines",
    dependencies=[
        "qm-qua",
        "qualang-tools",
    ],
    symbols=[
        Symbol(path="qm", name="generate_qua_script", kind="callable"),
    ],
)

_runtime_symbols = import_optional_dependencies(_QM_RUNTIME).symbols

# Re-export runtime names (real or stubs)
generate_qua_script: "Callable[..., str]" = cast("Any", _runtime_symbols["generate_qua_script"])

__all__ = ["generate_qua_script"]
