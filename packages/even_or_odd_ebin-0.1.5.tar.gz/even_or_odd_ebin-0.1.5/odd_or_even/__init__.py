from .core import is_even_or_odd

__all__ = ["is_even_or_odd"]
__version__ = "0.1.5"
