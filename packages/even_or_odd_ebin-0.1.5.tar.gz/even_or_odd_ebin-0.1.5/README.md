# evenodd-checker

Tiny package that returns "even" or "odd" for a given integer.

## Usage
```py
from evenodd import is_even_or_odd

print(is_even_or_odd(7))   # odd
print(is_even_or_odd(8))   # even
