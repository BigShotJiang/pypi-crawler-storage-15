def is_empty_or_whitespace(input_string: str) -> bool:
    return not input_string or not input_string.strip()
