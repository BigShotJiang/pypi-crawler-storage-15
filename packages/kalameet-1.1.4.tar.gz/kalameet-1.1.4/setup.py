#!/usr/bin/env python3

from setuptools import setup, find_packages
setup(
    name='kalameet',
    version='1.1.4',
    description='Automatic Tools Cyber Security Framework',
    long_description=open('README.rst').read(),
    long_description_content_type='text/x-rst',
    author='rhkapota',
    author_email='rhkapota@gmail.com',
    url='https://github.com/rhkapota/kalameet',
    license='GNU General Public License v3 (GPLv3)',
    packages=find_packages(),
    package_dir={'kalameet':'kalameet'},
    classifiers =[
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Science/Research',
        'License :: OSI Approved :: GNU General Public License v3 (GPLv3)',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Topic :: Security',
        'Topic :: System :: Networking',
    ],
    install_requires=['requests', 'paramiko', 'pwntools', 'aiohttp', 'asyncio', 'piexif', 'rich'],
    entry_points={
        'console_scripts': [
            'kalameet = kalameet.kalameet:main',
        ],
    },
    include_package_data=True, 
    python_requires='>=3.8',
)