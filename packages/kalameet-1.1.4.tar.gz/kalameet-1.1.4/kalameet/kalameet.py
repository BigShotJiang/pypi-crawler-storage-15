#!/usr/bin/env python3

try:
    import sys
    import os
    import argparse
    import signal

    from rich.table import Table
    from rich.console import Console
    from rich.panel import Panel
    from rich import box

    from kalameet.lib.core.handler import PluginLoader
    from kalameet.lib.core.logger import Logger
    from kalameet.lib.utils.interface import UI, Colors
    from kalameet.lib.core import settings
    from kalameet.lib.utils.translate import _
except ImportError:
    print(f"{_('error_critical')}: {e}")
    sys.exit(1)

console = Console()

def show_main_dashboard(parser):
    intro_text = f"""
    [bold red underline]{_('disclaimer_title')}[/]
{_('disclaimer_text')}
    """
    
    UI.banner()
    console.print(Panel(intro_text.strip(), border_style="red", expand=False))
    print("")

    subparsers_actions = [
        action for action in parser._actions 
        if isinstance(action, argparse._SubParsersAction)
    ]
    
    categories = {}
    for subparsers_action in subparsers_actions:
        for choice, subparser in subparsers_action.choices.items():
            desc = subparser.description if subparser.description else _('desc_unknown')
            cat_name = "GENERAL"
            clean_desc = desc
            if desc.startswith("["):
                try:
                    cat_name = desc.split("]")[0].replace("[", "")
                    clean_desc = desc.split("]")[1].strip()
                except: pass
            
            if cat_name not in categories: categories[cat_name] = []
            categories[cat_name].append((choice, clean_desc))

    mod_table = Table(box=box.SIMPLE_HEAVY, border_style="blue", show_header=True, header_style="bold white", title=_('avail_mods'))
    mod_table.add_column("Category", style="cyan", width=12)
    mod_table.add_column("Command", style="bold green", width=15)
    mod_table.add_column("Description", style="white")

    for cat in sorted(categories.keys()):
        first_row = True

        sorted_commands = sorted(categories[cat], key=lambda x: x[0])

        for cmd, desc in sorted_commands:
            cat_label = f"[{cat}]" if first_row else ""
            mod_table.add_row(cat_label, cmd, desc)
            first_row = False
        mod_table.add_section()

    console.print(mod_table)
    print("")

    opt_table = Table(box=box.SIMPLE, border_style="white", show_header=True, header_style="bold yellow", title=_('global_opts'))
    opt_table.add_column("Flag / Option", style="bold green", width=20)
    opt_table.add_column("Description", style="white")
    opt_table.add_column("Example", style="dim white")
    opt_table.add_row("-h, --help", _('argument.help'), "")
    opt_table.add_row("-y, --yes", _('argument.yes'), "")
    opt_table.add_row("-t, --target", "Target IP / URL / Domain", "192.168.1.5")
    opt_table.add_row("-d, --data", "Input Data / File Path", "hash.txt")
    console.print(opt_table)
    print("")

class KalameetParser(argparse.ArgumentParser):
    def error(self, message):
        print(f"[{Colors.RED}X{Colors.ENDC}] {Colors.RED}{_('cmd_invalid')}{Colors.ENDC}")
        print(f"{Colors.RED}─>{Colors.ENDC} {message}")
        print(f"\n[{Colors.YELLOW}*{Colors.ENDC}] {Colors.YELLOW}Tip: {_('tip_help')}{Colors.ENDC}")
        sys.exit(2)

def main():
    parser = KalameetParser(add_help=False)
    parser.add_argument("-h", "--help", action="store_true", help=_('tip_show'))
    parser.add_argument("-t", "--target", help=argparse.SUPPRESS)
    parser.add_argument("-d", "--data", help=argparse.SUPPRESS)
    parser.add_argument("--cat", help=argparse.SUPPRESS)
    parser.add_argument("--cookie", help=argparse.SUPPRESS)
    parser.add_argument("--post", help=argparse.SUPPRESS)
    parser.add_argument("--lhost", help=argparse.SUPPRESS)
    parser.add_argument("--lport", help=argparse.SUPPRESS)

    subparsers = parser.add_subparsers(dest="command")
    
    # Load Plugin
    plugin_path = os.path.join(os.path.dirname(__file__), 'plugins')
    loader = PluginLoader(plugin_dir=plugin_path)
    loader.load_all(subparsers)
    
    if len(sys.argv) == 1 or (len(sys.argv) == 2 and sys.argv[1] in ['-h', '--help']):
        show_main_dashboard(parser)
        sys.exit(0)

    args, unknown = parser.parse_known_args()
    
    if hasattr(args, 'plugin_object'):
        plugin = args.plugin_object
        try:
            plugin.run(args)
        except KeyboardInterrupt:
            print(f"\n[{Colors.FAIL}-{Colors.ENDC}] {Colors.FAIL}{_('stopped')}{Colors.ENDC}")
            try:
                sys.exit(0) 
            except SystemExit:
                os._exit(0)
        except Exception as e:
            print(f"\n[{Colors.FAIL}-{Colors.ENDC}] {Colors.FAIL}{e}{Colors.ENDC}")
            sys.exit(1)
    else:
        parser.error(f"{_('cmd_notfound')}: {' '.join(sys.argv[1:])}")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n{_('stopped')}")