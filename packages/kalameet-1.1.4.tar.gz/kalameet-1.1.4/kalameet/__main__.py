import sys
import os

if __name__ == '__main__':
    from .kalameet import main
    
    main()