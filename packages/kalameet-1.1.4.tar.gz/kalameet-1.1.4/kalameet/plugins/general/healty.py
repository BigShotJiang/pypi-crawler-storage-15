import shutil
import os
import socket
import sys
from kalameet.lib.core.base import BasePlugin
from kalameet.lib.utils.interface import Colors, UI
from kalameet.lib.utils.translate import _
from kalameet.lib.core import settings

class healtyPlugin(BasePlugin):
    meta = {
        'name': 'healty',
        'description': '',
        'author': 'rhkapota'
    }

    def add_arguments(self, parser):
        pass

    def check_internet(self):
        try:
            socket.create_connection(("8.8.8.8", 53), timeout=3)
            return True
        except OSError:
            return False

    def check_tool(self, tool_name):
        return shutil.which(tool_name) is not None

    def run(self, args):
        UI.header("DIAGNOSTIC SYSTEM")
        all_good = True

        # [1] ENVIRONMENT
        print(f"[{Colors.GREEN}1{Colors.ENDC}]{Colors.GREEN} Enviroment:{Colors.ENDC}")
        print(f"    [{Colors.GREEN}!{Colors.ENDC}] Base Dir: {settings.BASE_DIR}")
        print(f"    [{Colors.GREEN}!{Colors.ENDC}] Python  : {sys.version.split()[0]}")
        
        # [2] NETWORK
        print(f"\n[{Colors.GREEN}2{Colors.ENDC}]{Colors.GREEN} Connectivity:{Colors.ENDC}")
        if self.check_internet():
            print(f"    [{Colors.GREEN}✓{Colors.ENDC}] Internet Access: ONLINE")
        else:
            print(f"    [{Colors.FAIL}X{Colors.ENDC}] Internet Access: OFFLINE")
            all_good = False

        # [3] EXTERNAL TOOLS
        print(f"\n[{Colors.GREEN}3{Colors.ENDC}]{Colors.GREEN} Dependency:{Colors.ENDC}")
        tools = ["nmap", "sqlmap", "steghide", "exiftool", "binwalk"]
        for tool in tools:
            if self.check_tool(tool):
                print(f"    [{Colors.GREEN}✓{Colors.ENDC}] Tool '{tool}': INSTALLED")
            else:
                print(f"    [{Colors.FAIL}X{Colors.ENDC}] Tool '{tool}': MISSING (Install via apt)")
                all_good = False

        # [4] WORDLISTS
        print(f"\n[{Colors.GREEN}4{Colors.ENDC}]{Colors.GREEN} Data:{Colors.ENDC}")
        missing_wl = False
        
        if os.path.exists(settings.WORDLIST_DIR):
            print(f"    [{Colors.GREEN}✓{Colors.ENDC}] Directory Found: data/wordlists/")
        else:
            print(f"    [{Colors.FAIL}X{Colors.ENDC}] Directory Missing: data/wordlists/")
            all_good = False
        for key, filename in settings.WORDLISTS.items():
            path = os.path.join(settings.WORDLIST_DIR, filename)
            if os.path.exists(path):
                size = os.path.getsize(path)
                if size > 0:
                    print(f"    [{Colors.GREEN}✓{Colors.ENDC}] {key.upper():<10}: Found ({filename})")
                else:
                    print(f"    [{Colors.WARNING}!{Colors.ENDC}] {key.upper():<10}: Empty File ({filename})")
            else:
                print(f"    [{Colors.FAIL}X{Colors.ENDC}] {key.upper():<10}: MISSING ({filename})")
                missing_wl = True
                all_good = False
        
        if missing_wl:
            print(f"\n    [{Colors.WARNING}!{Colors.ENDC}] Solution: Run 'wget' commands or check requirements.{Colors.ENDC}")

        if all_good:
            print(f"[{Colors.GREEN}✓{Colors.ENDC}] {Colors.GREEN}Diagnostic Complete{Colors.ENDC}")
        else:
            print(f"[{Colors.RED}x{Colors.ENDC}] Issues Detected")