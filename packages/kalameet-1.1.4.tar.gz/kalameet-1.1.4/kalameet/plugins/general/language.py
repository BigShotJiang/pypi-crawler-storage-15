import os
import re
import sys
from kalameet.lib.core.base import BasePlugin
from kalameet.lib.utils.interface import UI, Colors
from kalameet.lib.core import settings
from kalameet.lib.utils.library import TRANSLATIONS
from kalameet.lib.utils.translate import _

class languagePlugin(BasePlugin):
    meta = {
        'name': 'language',
        'description': '',
        'author': 'rhkapota'
    }

    def add_arguments(self, parser):
        available_langs = list(TRANSLATIONS.keys())
        parser.add_argument("code", nargs='?', help=f"Language Code (Available: {', '.join(available_langs)})")

    def run(self, args):
        current_lang = settings.LANGUAGE

        requested_lang = args.code 
        
        UI.header("LANGUAGE CONFIGURATION")
        if requested_lang is None:
            print(f"[{Colors.GREEN}!{Colors.ENDC}] Current language is: {current_lang.upper()}")
            
            available_langs = list(TRANSLATIONS.keys())
            print(f"[{Colors.GREEN}~{Colors.ENDC}] Language code: {', '.join(available_langs)}")
            
            try:
                new_lang = input(f"[{Colors.YELLOW}?{Colors.ENDC}] Enter new language code (or type 'cancel'): {Colors.ENDC}").lower().strip()
                
                if new_lang and new_lang != 'cancel':
                    requested_lang = new_lang
                else:
                    UI.print_error("[red]Language selection skipped.")
                    return
                    
            except KeyboardInterrupt:
                UI.print_error(_('stopped'))
                return
   
        if requested_lang not in TRANSLATIONS:
            UI.print_error(f"[red]Language code {requested_lang.upper()} is not supported.")
            return

        if requested_lang == current_lang:
            UI.print_info(f"Language is already set to {requested_lang.upper()}. No changes needed.")
            return

        settings_path = os.path.join(settings.BASE_DIR, 'kalameet', 'lib', 'core', 'settings.py')
        
        print(f"[{Colors.GREEN}*{Colors.ENDC}] Attempting to switch language to: {requested_lang.upper()}")
        
        try:
            with open(settings_path, 'r') as f:
                lines = f.readlines()
            
            new_lines = []
            for line in lines:
                if line.strip().startswith("LANGUAGE ="):
                    new_lines.append(f"LANGUAGE = '{requested_lang}'\n")
                else:
                    new_lines.append(line)
            
            with open(settings_path, 'w') as f:
                f.writelines(new_lines)
                
            print(f"[{Colors.GREEN}+{Colors.ENDC}] Language setting saved: {requested_lang.upper()}.")
            print(f"[{Colors.GREEN}✓{Colors.ENDC}] {Colors.GREEN}Change Complete.{Colors.ENDC}")
            print(f"    Run 'kalameet' to see changes applied.")
            sys.exit(0)

        except Exception as e:
            UI.print_error(f"Failed to update settings: {e}")