import json
import datetime
import os
import sys

try:
    from kalameet.lib.core import settings
except ImportError:
    try:
        from core import settings
    except:
        class settings:
            LOG_DIR = "logs"
            LOG_FOLDER_DATE_FORMAT = "%d-%m-%Y"
            LOG_FILE_TIME_FORMAT = "%H-%M-%S"
            LOG_FILENAME_TEMPLATE = "{session}_{timestamp}.json"

class Logger:
    def __init__(self, session_name="session"):
        self.session_name = session_name
        self.filename = None
        self.initialized = False

    def _prepare_storage(self):
        now = datetime.datetime.now()
        
        try:
            date_folder = now.strftime(settings.LOG_FOLDER_DATE_FORMAT)
            time_file = now.strftime(settings.LOG_FILE_TIME_FORMAT)
        except:
            date_folder = now.strftime("%d-%m-%Y")
            time_file = now.strftime("%H-%M-%S")
        
        self.session_dir = os.path.join(settings.LOG_DIR, date_folder)
        if not os.path.exists(self.session_dir):
            try:
                os.makedirs(self.session_dir, exist_ok=True)
            except OSError: pass

        try:
            filename_str = settings.LOG_FILENAME_TEMPLATE.format(
                session=self.session_name, 
                timestamp=time_file
            )
        except:
            filename_str = f"{self.session_name}_{time_file}.json"

        self.filename = os.path.join(self.session_dir, filename_str)
        
        try:
            if not os.path.exists(self.filename):
                with open(self.filename, 'w') as f:
                    json.dump([], f)
        except IOError: pass
        
        self.initialized = True

    def log(self, module, status, message, data=None):
        if not self.initialized:
            self._prepare_storage()

        entry = {
            "timestamp": datetime.datetime.now().isoformat(),
            "module": module,
            "status": status,
            "message": message,
            "data": data
        }
        
        try:
            current_logs = []
            if self.filename and os.path.exists(self.filename):
                try:
                    with open(self.filename, 'r') as f:
                        content = f.read()
                        if content:
                            current_logs = json.loads(content)
                except json.JSONDecodeError:
                    pass
            
            current_logs.append(entry)
            
            if self.filename:
                with open(self.filename, 'w') as f:
                    json.dump(current_logs, f, indent=4)
                
        except Exception:
            pass