import argparse
from kalameet.lib.utils.translate import _

class BasePlugin:
    meta = {
        'name': 'unknown',
        'description': _('desc_unknown'),
        'author': 'rhkapota'
    }

    def __init__(self):
        pass

    def add_arguments(self, parser):
        pass

    def check_dependencies(self, binaries):
        """Memeriksa apakah tool eksternal terinstall"""
        missing = []
        for binary in binaries:
            if shutil.which(binary) is None:
                missing.append(binary)
        
        if missing:
            print(f"[-] Missing external dependencies: {', '.join(missing)}")
            return False
        return True

    def run(self, args):
        raise NotImplementedError(_('run_unknown'))