import os
import inspect
import sys
import argparse
import re

import random
from urllib.parse import urlparse

import binascii
import base64
import html

from kalameet.lib.core.base import BasePlugin
from kalameet.lib.utils.interface import Colors, UI 
from kalameet.lib.utils.translate import _
try:
    from kalameet.lib.core import settings
except ImportError:
    class settings:
        RANDOMIZE_USER_AGENT = True

class Formatter(argparse.HelpFormatter):
    def __init__(self, prog):
        super().__init__(prog, max_help_position=40, indent_increment=2, width=120)

    def _format_action_invocation(self, action):
        if not action.option_strings:
            return super()._format_action_invocation(action)
        default = super()._format_action_invocation(action)
        return f"{Colors.GREEN}{default}{Colors.ENDC}"

    def _format_usage(self, usage, actions, groups, prefix):
        raw_usage = super()._format_usage(usage, actions, groups, prefix='')
        
        clean_usage = raw_usage.strip().replace('\n', '').replace('usage: ', '')
        clean_usage = clean_usage.replace("kalameet.py", "kalameet").replace("__main__.py", "kalameet")
        clean_usage = re.sub(r'\s+', ' ', clean_usage)

        return (
            f"\n[{Colors.YELLOW}~{Colors.ENDC}] {_('cmd_example')}:{Colors.ENDC}\n"
            f" {Colors.YELLOW}─>{Colors.ENDC} {clean_usage}\n"
        )

    def format_help(self):
        help_text = super().format_help()
        help_text = help_text.replace("kalameet.py", "kalameet").replace("__main__.py", "kalameet")

        help_text = re.sub(r'(?m)^\s*\[([A-Z]+)\]\s+(.*)$\n?', '', help_text)
        
        header_args = f"{Colors.BOLD}{Colors.BLUE}ARGUMENTS:{Colors.ENDC}"
        help_text = re.sub(r'(?m)^(positional arguments):', header_args, help_text, flags=re.IGNORECASE)

        header_text = f"{Colors.BOLD}{Colors.BLUE}OPTIONS:{Colors.ENDC}"
        help_text = re.sub(r'(?m)^(options|positional arguments|optional arguments):', header_text, help_text, flags=re.IGNORECASE)

        help_text = re.sub(r'\b([A-Z0-9_]{3,})\b', f'{Colors.YELLOW}\\1{Colors.ENDC}', help_text)
        
        return help_text.strip() + "\n"

class PluginLoader:
    def __init__(self, plugin_dir="plugins"):
        self.plugin_dir = plugin_dir
        self.loaded_plugins = {}

    def load_all(self, subparsers):
        count = 0
        if not os.path.exists(self.plugin_dir):
            try: os.makedirs(self.plugin_dir)
            except: pass
            return 0

        for root, dirs, files in os.walk(self.plugin_dir):
            for filename in files:
                if filename.endswith(".py") and filename != "__init__.py":
                    full_path = os.path.join(root, filename)
                    rel_path = os.path.relpath(full_path, os.path.dirname(self.plugin_dir))
                    module_name = "kalameet." + rel_path.replace(os.sep, ".")[:-3]
                    try:
                        spec = importlib.util.spec_from_file_location(module_name, full_path)
                        if spec and spec.loader:
                            mod = importlib.util.module_from_spec(spec)
                            spec.loader.exec_module(mod)
                            for name, obj in inspect.getmembers(mod):
                                if inspect.isclass(obj) and issubclass(obj, BasePlugin) and obj is not BasePlugin:
                                    try:
                                        plugin = obj()
                                        cmd_name = plugin.meta.get('name', 'unknown')
                                        desc_key = f"desc_{cmd_name}"
                                        translated_desc = _(desc_key)

                                        if translated_desc.startswith("MISSING_TEXT"):
                                            final_desc = plugin.meta.get('description', _('desc_unknown'))
                                        else:
                                            final_desc = translated_desc
                                        
                                        category = os.path.basename(root)
                                        if os.path.abspath(root) == os.path.abspath(self.plugin_dir):
                                            category = "GENERAL"
                                        
                                        formatted_help = f"[{category.upper()}] {final_desc}"
                                        
                                        parser = subparsers.add_parser(
                                            cmd_name, 
                                            help=formatted_help,
                                            description=formatted_help, 
                                            formatter_class=Formatter 
                                        )
                                        
                                        def make_error_handler(p_parser, p_obj):
                                            def custom_error(message):
                                                clean_msg = message.replace("error: ", "")
                                                usage_str = p_parser.format_usage()
                                                UI.print_module_error(p_obj, clean_msg, usage_str)
                                                sys.exit(2)
                                            return custom_error

                                        parser.error = make_error_handler(parser, plugin)
                                        plugin.add_arguments(parser)
                                        parser.set_defaults(plugin_object=plugin)
                                        count += 1
                                    except Exception: pass
                    except Exception: pass
        return count

class BypassWaf:
    def __init__(self):
        self.whitespaces = [" ", "\t", "\n", "\r", "\x0b", "\x0c"]
        self.sql_comments = ["--", "#", "/*", ";%00"]

    def obfuscate(self, payload, attack_type):
        techniques = {payload}
        techniques.add(self.url_encode(payload))
        techniques.add(self.double_url_encode(payload))

        if attack_type == 'sqli':
            techniques.add(self.sql_case_randomization(payload))
            techniques.add(self.sql_inline_comment(payload))
            techniques.add(self.sql_version_comment_mysql(payload))
            techniques.add(self.sql_hex_encoding(payload))
            techniques.add(self.sql_whitespace_manipulation(payload))
            
        elif attack_type == 'cmd':
            techniques.add(self.cmd_quote_insertion(payload))
            techniques.add(self.cmd_ifs_substitution(payload))
            techniques.add(self.cmd_base64_wrapper(payload))
            techniques.add(self.cmd_concatenation(payload))
            
        elif attack_type == 'xss':
            techniques.add(self.xss_case_randomization(payload))
            techniques.add(self.xss_html_entity_encode(payload))
            techniques.add(self.xss_javascript_hex(payload))
            
        return list(techniques)

    def url_encode(self, payload):
        return urllib.parse.quote(payload)

    def double_url_encode(self, payload):
        return urllib.parse.quote(urllib.parse.quote(payload))

    def sql_case_randomization(self, payload):
        return "".join([char.upper() if random.choice([True, False]) else char.lower() for char in payload])

    def sql_inline_comment(self, payload):
        return payload.replace(" ", "/**/")

    def sql_version_comment_mysql(self, payload):
        keywords = ["UNION", "SELECT", "INSERT", "UPDATE", "FROM", "WHERE"]
        res = payload
        for kw in keywords:
            if kw in res.upper():
                res = res.replace(kw, f"/*!50000{kw}*/")
                res = res.replace(kw.lower(), f"/*!50000{kw}*/")
        return res

    def sql_hex_encoding(self, payload):
        try:
            return "0x" + binascii.hexlify(payload.encode()).decode()
        except:
            return payload

    def sql_whitespace_manipulation(self, payload):
        ws = random.choice(["\t", "\n", "\r", "+", "%09", "%0a"])
        return payload.replace(" ", ws)

    def cmd_quote_insertion(self, payload):
        result = ""
        for char in payload:
            if char.isalpha():
                result += f"{char}''"
            else:
                result += char
        return result

    def cmd_ifs_substitution(self, payload):
        return payload.replace(" ", "${IFS}")

    def cmd_base64_wrapper(self, payload):
        b64 = base64.b64encode(payload.encode()).decode()
        return f"echo {b64}|base64 -d|sh"

    def cmd_concatenation(self, payload):
        if " " not in payload and len(payload) > 2:
             mid = len(payload) // 2
             p1 = payload[:mid]
             p2 = payload[mid:]
             return f"a='{p1}';b='{p2}';$a$b"
        return payload

    def xss_case_randomization(self, payload):
        return "".join([char.upper() if random.choice([True, False]) else char.lower() for char in payload])

    def xss_html_entity_encode(self, payload):
        import html
        return html.escape(payload)

    def xss_javascript_hex(self, payload):
        output = ""
        for char in payload:
            output += "\\x" + format(ord(char), "02x")
        return output

class StealthMode:
    def __init__(self):
        self.agents = [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:120.0) Gecko/20100101 Firefox/120.0",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/119.0",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0",
            "Mozilla/5.0 (Windows NT 11.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_2_1) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:120.0) Gecko/20100101 Firefox/120.0",
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:120.0) Gecko/20100101 Firefox/120.0",
            "Mozilla/5.0 (X11; Fedora; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/118.0",
            "Mozilla/5.0 (Linux; Android 14; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.144 Mobile Safari/537.36",
            "Mozilla/5.0 (Linux; Android 13; SM-A536B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36",
            "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
            "Mozilla/5.0 (Linux; Android 12; Moto G Power) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.36",
            "Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1",
            "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",
            "Mozilla/5.0 (iPad; CPU OS 17_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Mobile/15E148 Safari/604.1",
            "Mozilla/5.0 (iPhone; CPU iPhone OS 15_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/120.0.6099.119 Mobile/15E148 Safari/604.1",
            "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)",
            "Mozilla/5.0 (compatible; Bingbot/2.0; +http://www.bing.com/bingbot.htm)",
            "Mozilla/5.0 (compatible; Yahoo! Slurp; http://help.yahoo.com/help/us/ysearch/slurp)",
            "DuckDuckBot/1.0; (+http://duckduckgo.com/duckduckbot.html)",
            "Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)",
            "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.75 Safari/537.36",
            "Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)",
            "Opera/9.80 (Windows NT 6.0) Presto/2.12.388 Version/12.14"
        ]

        self.spoof_ips = [
            "127.0.0.1", "127.0.1.1", "0.0.0.0", "localhost", "::1", "0:0:0:0:0:0:0:1",
            "10.0.0.1", "10.0.0.0", "10.1.1.1", "172.16.0.1", "172.31.255.255",
            "192.168.0.1", "192.168.1.1", "192.168.0.254", "192.168.100.1",
            "169.254.169.254", "100.64.0.1",
            "8.8.8.8", "8.8.4.4", "1.1.1.1", "1.0.0.1", "9.9.9.9", "4.2.2.2", "208.67.222.222",
            "255.255.255.255", "2130706433", "0x7f000001", "0177.0000.0000.0001",
        ]
        
        self.spoof_headers = [
            "X-Forwarded-For", "X-Real-IP", "X-Client-IP", "Client-IP", "X-Originating-IP",
            "X-Remote-IP", "X-Remote-Addr", "X-Forwarded-Host", "X-Forwarded-Proto",
            "Forwarded", "True-Client-IP", "CF-Connecting-IP", "Fastly-Client-IP",
            "X-Cluster-Client-IP", "X-ProxyUser-Ip", "Via", "X-Wap-Profile", "Pragma"
        ]

        self.referers = [
            "https://www.google.com/", "https://www.bing.com/", "https://search.yahoo.com/",
            "https://duckduckgo.com/", "https://yandex.com/", "https://www.baidu.com/",
            "https://www.google.co.id/", "https://www.google.co.uk/", "https://www.google.ca/",
            "https://www.google.de/", "https://www.google.jp/",
            "https://www.facebook.com/", "https://m.facebook.com/", "https://l.facebook.com/",
            "https://twitter.com/", "https://t.co/", "https://www.instagram.com/",
            "https://www.linkedin.com/", "https://www.tiktok.com/", "https://www.reddit.com/",
            "https://www.pinterest.com/", "https://www.youtube.com/",
            "https://github.com/", "https://stackoverflow.com/", "https://medium.com/",
            "https://news.ycombinator.com/", "https://gitlab.com/",
            "https://www.detik.com/", "https://www.kompas.com/", "https://www.kaskus.co.id/",
            "https://bit.ly/", "https://tinyurl.com/"
        ]

    def _generate_random_ip(self):
        return f"192.168.{random.randint(0, 255)}.{random.randint(0, 255)}"

    def get_agent(self):
        if settings.RANDOMIZE_USER_AGENT:
            return random.choice(self.agents)
        return self.agents[0]

    def get_spoof_ip(self):
        if random.random() < 0.5:
            return random.choice(self.spoof_ips)
        else:
            return self._generate_random_ip()

    def get_referer(self, target_url=None):
        if target_url and random.random() < 0.3:
            try:
                parsed = urlparse(target_url)
                return f"{parsed.scheme}://{parsed.netloc}/"
            except:
                return random.choice(self.referers)
        return random.choice(self.referers)

    def get_headers(self, target_url=None):
        fake_ip = self.get_spoof_ip()
        
        headers = {
            'User-Agent': self.get_agent(),
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Referer': self.get_referer(target_url),
        }
        
        chosen_header = random.choice(self.spoof_headers)
        
        if chosen_header == "Forwarded":
            headers[chosen_header] = f"for={fake_ip};proto=http"
        else:
            headers[chosen_header] = fake_ip
        
        return headers