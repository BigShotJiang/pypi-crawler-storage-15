import os

LANGUAGE = 'en'
BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

DATA_DIR = os.path.join(BASE_DIR, 'data')
WORDLIST_DIR = os.path.join(DATA_DIR, 'wordlists')

LOG_DIR = os.path.join(DATA_DIR, 'logs')
OUTPUT_DIR = os.path.join(DATA_DIR, 'output')

dirs_to_create = [DATA_DIR, WORDLIST_DIR, LOG_DIR, OUTPUT_DIR]
for d in dirs_to_create:
    if not os.path.exists(d):
        try: os.makedirs(d, exist_ok=True)
        except OSError: pass

DEFAULT_TIMEOUT = 5
RANDOMIZE_USER_AGENT = True

TOOLS = {
    "nmap": "nmap",
    "sqlmap": "sqlmap",
    "steghide": "steghide",
    "exiftool": "exiftool",
    "binwalk": "binwalk"
}

WORDLISTS = {
    "sqli": "sqli.txt",
    "xss": "xss.txt",
    "lfi": "lfi.txt",
    "cmd": "commands.txt",
    "ssti": "ssti.txt",
    "dirs": "directory.txt",
    "passwords": "passwords.txt",
    "params": "params.txt",
    "creds": "creds.txt",
}

LOG_FOLDER_DATE_FORMAT = "%d-%m-%Y"
LOG_FILE_TIME_FORMAT = "%H-%M-%S"
LOG_FILENAME_TEMPLATE = "{session}_{timestamp}.json"