from rich.console import Console
from rich.theme import Theme
from rich.table import Table
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn
from rich import box
from datetime import datetime
from kalameet.lib.utils.translate import _
import sys
import re

class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    WARNING = '\033[93m'
    YELLOW = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    RED = '\033[91m'
    MAGENTA = '\033[95m'
    WHITE = '\033[97m'
    CYAN = '\033[96m'
    BLACK = '\033[30m'
    
    SWORD = '\033[91;43m'
    
    # Background
    BG_RED = '\033[41m'
    BG_GREEN = '\033[42m'
    BG_YELLOW = '\033[43m'
    BG_BLUE = '\033[44m'
    BG_MAGENTA = '\033[45m'
    BG_CYAN = '\033[46m'
    BG_WHITE = '\033[47m'
    
    @staticmethod
    def print_success(msg): print(f"[{Colors.GREEN}✓{Colors.ENDC}] {msg}")
    @staticmethod
    def print_error(msg): print(f"[{Colors.FAIL}X{Colors.ENDC}] {msg}")

custom_theme = Theme({
    "info": "cyan",
    "warning": "yellow",
    "error": "bold red",
    "success": "bold green"
})

class UI:
    console = Console(theme=custom_theme)
    @staticmethod
    def print_success(msg):
        UI.console.print(f"[[bold green]✓[/]] {msg}")

    @staticmethod
    def print_error(msg):
        UI.console.print(f"[[bold red]X[/]] {msg}")
        
    @staticmethod
    def print_warning(msg):
        UI.console.print(f"[[bold yellow]![/]] {msg}")

    @staticmethod
    def print_info(msg):
        UI.console.print(f"[[bold blue]~[/]] {msg}")

    @staticmethod
    def strip_ansi(text):
        ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
        return ansi_escape.sub('', text)

    @staticmethod
    def highlight_usage(text):
        text = text.replace("kalameet", f"{Colors.BOLD}{Colors.CYAN}kalameet{Colors.ENDC}")
        text = re.sub(r'(\s)(-[a-zA-Z0-9]|--[a-zA-Z0-9-]+)', f'\\1{Colors.GREEN}\\2{Colors.ENDC}', text)
        text = re.sub(r'\b([A-Z0-9_]{2,})\b', f'{Colors.YELLOW}\\1{Colors.ENDC}', text)
        return text

    @staticmethod
    def banner():
        BASE = Colors.RED
        BASE_TEXT = Colors.YELLOW
        SWORD = Colors.SWORD 
        RESET = Colors.ENDC
        print(f"{BASE}")
        print(r"""
                 ___
                __H__                         __
    ___ ___ ____ [{SWORD}({RESET}{BASE}] ____  _____  ____  ____ |  |_
    | |/  /|_ . |[{SWORD}){RESET}{BASE}]|_ . ||     || . _|| . _||   _|
    |__\__\|____|[{SWORD}({RESET}{BASE}]|____||_|_|_||____||____||__|
                  V  ▬▬▬ι══════════>  {BASE_TEXT}Ver: 1.0.5{RESET}
    """.format(SWORD=SWORD, RESET=RESET, BASE=BASE, BASE_TEXT=BASE_TEXT))
        print(f"{Colors.ENDC}")

    @staticmethod
    def print_module_info(plugin):
        pass

    @staticmethod
    def print_module_error(plugin, error_msg, usage_msg):
        module_name = plugin.meta.get('name', 'unknown')

        
        print(f"[{Colors.RED}X{Colors.ENDC}] {Colors.RED}Error at ({module_name.upper()}){Colors.ENDC}")
        print(f"{Colors.RED}─>{Colors.ENDC} {error_msg}")
        print("")
        print(f"[{Colors.YELLOW}*{Colors.ENDC}] {Colors.YELLOW}Tip: {_('tip_modules').replace("{module_name}", f"{module_name}")}{Colors.ENDC}")


    @staticmethod
    def log(message, level="info"):
        time = datetime.now().strftime("%H:%M:%S")
        if level == "info": UI.console.print(f"[[blue]*[/]] {message}")
        elif level == "success": UI.console.print(f"[[green]✓[/]] {message}")
        elif level == "warning": UI.console.print(f"[[yellow]![/]] {message}")
        elif level == "error": UI.console.print(f"[[red]X[/]] {message}")

    @staticmethod
    def header(text):
        print(f"----------------------------------------{Colors.ENDC}")
        print(f"[{Colors.GREEN}>{Colors.ENDC}] {Colors.GREEN}{text}{Colors.ENDC}")
        print(f"----------------------------------------{Colors.ENDC}")

    @staticmethod
    def footer(text, state=True):
        if state:
            color = Colors.GREEN
            prefix = "✓"
        else:
            color = Colors.FAIL
            prefix = "X"
            
        print(f"----------------------------------------{Colors.ENDC}")
        print(f"[{color}{prefix}{Colors.ENDC}] {color}{text}{Colors.ENDC}")
        print(f"----------------------------------------{Colors.ENDC}")

    @staticmethod
    def table(columns, data, title=None):
        table = Table(title=title, show_header=True, header_style="bold magenta", border_style="blue", box=box.SIMPLE)
        for col in columns: table.add_column(col)
        for row in data:
            str_row = [str(x) for x in row]
            table.add_row(*str_row)
        UI.console.print(table)

    @staticmethod
    def progress_bar():
        return Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
        )