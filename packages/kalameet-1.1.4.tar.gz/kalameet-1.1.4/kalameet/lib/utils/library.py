TRANSLATIONS = {
    # INDONESIA
    "id": {
        # UI & Banner
        "welcome": "Selamat Datang di Pusat Komando",
        "select_mod": "Silakan pilih modul di bawah ini untuk memulai misi.",
        "help_hint": "Gunakan [green]kalameet <command> -h[/] untuk bantuan spesifik.",
        "disclaimer_title": "Peringatan Hukum !",
        "disclaimer_text": "Tools ini dibuat untuk edukasi dan kompetisi CTF.\nDilarang keras digunakan untuk kejahatan.",
        "global_opts": "PARAMETER GLOBAL",
        "avail_mods": "MODUL TERSEDIA",
        "example": "CONTOH PENGGUNAAN",
        
        # Status
        "status_active": "AKTIF / DIMUAT",
        "status_init": "MEMUAT...",
        
        # Error & Usage
        "error_title": "EKSEKUSI DIHENTIKAN",
        "error_reason": "PENYEBAB",
        "error_syntax": "SINTAKS BENAR",
        "error_critical": "Kesalahan Impor Kritis",
        "cmd_unknown": "Perintah tidak dikenal",
        "cmd_notfound": "Perintah tidak ditemukan",
        "cmd_invalid": "Perintah atau argumen tidak valid",
        "desc_unknown": "Tidak ada deskripsi",
        "tip_help": "Ketik 'kalameet -h' untuk melihat modul yang tersedia",
        "tip_modules": "Ketik 'kalameet {module_name} -h' untuk melihat argumen yang tersedia",
        "tip_show": "Tampilkan pesan bantuan ini",
        "cmd_example": "Contoh Penggunaan Perintah",
        "run_unknown": "Plugin ini belum memiliki method run()!",
        
        # Common Messages
        "scan_start": "Memulai Pemindaian pada",
        "scan_done": "Pemindaian Selesai",
        "found": "Ditemukan",
        "stopped": "Dihentikan oleh pengguna.",

        "plugins": {
            "clean": {
                "info": "Anda akan menghapus data misi.",
                "confirm": "Apakah Anda yakin?",
                "start": "Memulai pembersihan sistem...",
                "remove_cache": "Menghapus cache pycache...",
                "remove_logs": "Menghapus file log misi...",
                "success": "Sistem berhasil dibersihkan!",
                "fail": "Gagal membersihkan beberapa file."
            },
            "healty": {},
            "language": {}
        },
        "argument": {
            "yes": "Lewati permintaan konfirmasi",
            "help": "Tampilkan pesan bantuan"
        },

        # Modules Description
        # -- General
        "desc_healty": "Pemeriksaan Integritas Sistem",
        "desc_clean": "Pembersih Log dan Cache Sistem",
        "desc_language": "Ganti bahasa Antarmuka (ID/EN)",

        # -- Utils
        "desc_analys": "Menganalisis Kerentanan Kode menggunakan AI",

        # -- Recon
        "desc_dirbust": "Pencari Direktori web Tersembunyi",
        "desc_dirbust-flash": "Pencari Direktori web Tersembunyi (Fast)",
        "desc_subdomain": "Pencari subdomain pasif",
        "desc_waf": "Detektor Firewall Aplikasi Web (WAF)",
        "desc_ports": "Pemindai Port Jaringan"
    },

    # ENGLISH
    "en": {
        # UI & Banner
        "welcome": "Welcome to the Command Center",
        "select_mod": "Please select a module below to start the mission.",
        "help_hint": "Use [green]kalameet <command> -h[/] for specific help.",
        "disclaimer_title": "Legal Disclaimer !",
        "disclaimer_text": "This tool is for educational & CTF purposes only.\nIllegal usage is strictly prohibited.",
        "global_opts": "GLOBAL OPTIONS",
        "avail_mods": "AVAILABLE MODULES",
        "example": "USAGE EXAMPLES",
        
        # Status
        "status_active": "ACTIVE / LOADED",
        "status_init": "INITIALIZING...",
        
        # Error & Usage
        "error_title": "EXECUTION HALTED",
        "error_reason": "FAILURE REASON",
        "error_syntax": "CORRECT SYNTAX",
        "error_critical": "Critical Import Error",
        "cmd_unknown": "Unknown command",
        "cmd_notfound": "Command not found",
        "cmd_invalid": "Invalid command or argument",
        "desc_unknown": "No description",
        "tip_help": "Type 'kalameet -h' to see available modules",
        "tip_modules": "Type 'kalameet {module_name} -h' to see available arguments",
        "tip_show": "Show this help message",
        "cmd_example": "Command Usage Example",
        "run_unknown": "This plugin does not have a run() method yet!",

        # Common Messages
        "scan_start": "Starting Scan on",
        "scan_done": "Scan Complete",
        "found": "FOUND",
        "stopped": "Stopped by user.",

        "plugins": {
            "clean": {
                "info": "You are about to delete mission data.",
                "confirm": "Are you sure?",
                "start": "Starting system cleanup...",
                "remove_cache": "Menghapus cache pycache...",
                "remove_logs": "Menghapus file log misi...",
                "success": "System cleared successfully!",
                "fail": "Failed to clean some files."
            },
            "healty": {
                "info": "",
                "success": "Diagnostic Complete.",
                "fail": ""
            },
            "language": {}
        },
        
        "argument": {
            "yes": "Skip confirmation prompt",
            "help": "Show help message"
        },

        # Modules Description
        "desc_healty": "System Integrity Check",
        "desc_clean": "System Cleanup & Cache Wiper",
        "desc_language": "Change Interface language (ID/EN)",

        # -- Utils
        "desc_analys": "Analyze Code Vulnerabilities using AI",

        # -- Recon
        "desc_dirbust": "Stealth Web Directory Buster",
        "desc_dirbust-flash": "Stealth Web Directory Buster (Fast)",
        "desc_subdomain": "Passive Subdomain Enumeration",
        "desc_waf": "Web Application Firewall (WAF) Detector",
        "desc_ports": "Network Port Scanner"
    }
}