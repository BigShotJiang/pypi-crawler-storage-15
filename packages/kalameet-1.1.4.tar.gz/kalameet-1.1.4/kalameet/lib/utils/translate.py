from kalameet.lib.core import settings
from kalameet.lib.utils.library import TRANSLATIONS

class Tl:
    @staticmethod
    def _fetch_nested(dictionary, key_string):
        keys = key_string.split('.')
        value = dictionary
        for k in keys:
            value = value[k]
        return value

    @staticmethod
    def get(key):
        lang = settings.LANGUAGE
        
        try:
            return Tl._fetch_nested(TRANSLATIONS[lang], key)
        except (KeyError, TypeError):
            pass
            
        try:
            return Tl._fetch_nested(TRANSLATIONS['en'], key)
        except (KeyError, TypeError):
            return f"MISSING_TEXT:{key}"

_ = Tl.get