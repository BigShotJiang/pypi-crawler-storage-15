# Hello, My Dear Users..

It is so nice that our package: BJSmaths, has finally recahed you. If you are reading this,
well I am currently a 11yr old boy from Bangladesh. I learned coding cause I wanted to be
a software engineer. I didn't recieve much support from my family. I had to learn decent Python
AND Javascript, little bit Java, Kotlin AND C++.. I use a typealias as: BJS to come to the
public.

## About the Library Itself..

This library: BJSmaths, is all about basic numerical works and operations. It is here to solve
a problem.,. That CHOOSING a library for mathemetics is hard. Not just that, but stability matters
too. Me myself have gone through that intense decision-making phase.

**bold text**
I REALLY hope that my THIS library: BJSmaths, helps people..

**italian text**
Bye, versions coming soon..
