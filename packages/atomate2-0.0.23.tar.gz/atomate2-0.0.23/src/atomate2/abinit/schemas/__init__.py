"""Definition of schemas for results of ABINIT calculations."""
