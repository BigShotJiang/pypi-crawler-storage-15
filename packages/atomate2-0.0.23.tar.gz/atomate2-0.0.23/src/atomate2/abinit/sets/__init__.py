"""Module defining ABINIT input sets used in atomate2."""
