"""Core classes for OpenMM module."""
