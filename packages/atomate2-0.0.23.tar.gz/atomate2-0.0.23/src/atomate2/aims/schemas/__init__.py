"""Define the schemas for FHI-aims."""
