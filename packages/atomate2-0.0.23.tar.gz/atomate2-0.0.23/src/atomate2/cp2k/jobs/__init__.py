"""Module for CP2K jobs."""
