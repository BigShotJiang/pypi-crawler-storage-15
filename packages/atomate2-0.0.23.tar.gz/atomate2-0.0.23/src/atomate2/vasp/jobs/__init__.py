"""Jobs for running VASP calculations."""
