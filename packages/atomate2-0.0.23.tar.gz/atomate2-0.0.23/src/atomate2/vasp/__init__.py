"""Module for VASP workflows."""
