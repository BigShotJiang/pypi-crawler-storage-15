"""Module defining QChem input sets used in atomate2."""
