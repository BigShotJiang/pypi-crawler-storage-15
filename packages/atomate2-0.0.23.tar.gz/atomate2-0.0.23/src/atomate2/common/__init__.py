"""Tools and functions that are common across all codes."""
