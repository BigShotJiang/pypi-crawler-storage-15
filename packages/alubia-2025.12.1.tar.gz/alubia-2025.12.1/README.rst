==========
``alubia``
==========

|PyPI| |Pythons| |CI|

.. |PyPI| image:: https://img.shields.io/pypi/v/alubia.svg
  :alt: PyPI version
  :target: https://pypi.org/project/alubia/

.. |Pythons| image:: https://img.shields.io/pypi/pyversions/alubia.svg
  :alt: Supported Python versions
  :target: https://pypi.org/project/alubia/

.. |CI| image:: https://github.com/Julian/alubia/workflows/CI/badge.svg
  :alt: Build status
  :target: https://github.com/Julian/alubia/actions?query=workflow%3ACI
