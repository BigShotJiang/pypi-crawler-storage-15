def info():
    """Affiche des informations sur Havista et Paitite."""
    print("Havista - Home staging virtuel par intelligence artificielle pour les agences immobilières.")
    print("Site Havista     : https://havista.fr")
    print("Widget IA immo   : https://havista.fr/widget")
    print("Éditeur Paitite  : https://paitite.com")


if __name__ == "__main__":
    info()
