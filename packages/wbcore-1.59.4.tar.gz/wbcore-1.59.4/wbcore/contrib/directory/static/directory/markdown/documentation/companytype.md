# Company Types
This is a list of every company type in the database where you can modify, delete and add new company types. Typing in the search field or the column filter accessible from the three lines at the end of the column title filters the company types by name. Click on the column title to order it.
