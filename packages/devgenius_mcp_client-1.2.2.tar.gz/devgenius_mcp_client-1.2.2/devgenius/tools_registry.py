"""
MCP 工具注册表

负责：
- 工具定义
- 工具列表管理
"""

from typing import Dict, Any, List


class ToolsRegistry:
    """MCP 工具注册表"""
    
    @staticmethod
    def get_all_tools() -> List[Dict[str, Any]]:
        """获取所有工具定义"""
        return [
            # 项目上下文
            {
                "name": "get_project_context",
                "description": "Get project context including basic info and current tasks",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "include_tasks": {
                            "type": "boolean",
                            "description": "Whether to include task list",
                            "default": True
                        }
                    }
                }
            },
            
            # 任务管理
            {
                "name": "get_my_tasks",
                "description": "Get my task list, automatically filtered by member role",
                "inputSchema": {"type": "object", "properties": {}}
            },
            {
                "name": "claim_task",
                "description": "Claim a task and acquire lock (default 120 minutes)",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "task_id": {"type": "integer", "description": "Task ID"},
                        "lock_duration_minutes": {"type": "integer", "description": "Lock duration in minutes", "default": 120}
                    },
                    "required": ["task_id"]
                }
            },
            {
                "name": "update_task_status",
                "description": "Update task status with optimistic locking",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "task_id": {"type": "integer", "description": "Task ID"},
                        "status": {"type": "string", "description": "New status", "enum": ["pending", "in_progress", "completed", "cancelled"]},
                        "version": {"type": "integer", "description": "Version number for optimistic locking"}
                    },
                    "required": ["task_id", "status", "version"]
                }
            },
            {
                "name": "split_task_into_subtasks",
                "description": "Split a main task into multiple subtasks",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "task_id": {"type": "integer", "description": "Main task ID"},
                        "subtasks": {
                            "type": "array",
                            "description": "List of subtasks",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "title": {"type": "string", "description": "Subtask title"},
                                    "description": {"type": "string", "description": "Subtask description"},
                                    "estimated_hours": {"type": "number", "description": "Estimated hours"}
                                },
                                "required": ["title"]
                            }
                        }
                    },
                    "required": ["task_id", "subtasks"]
                }
            },
            
            # 子任务管理
            {
                "name": "get_task_subtasks",
                "description": "Get all subtasks of a task",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "task_id": {"type": "integer", "description": "Parent task ID"}
                    },
                    "required": ["task_id"]
                }
            },
            {
                "name": "update_subtask_status",
                "description": "Update subtask status",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "subtask_id": {"type": "integer", "description": "Subtask ID"},
                        "status": {"type": "string", "description": "New status", "enum": ["pending", "in_progress", "completed", "cancelled"]}
                    },
                    "required": ["subtask_id", "status"]
                }
            },
            
            # 文档管理
            {
                "name": "get_document_categories",
                "description": "Get all available document categories. Use this before creating a document to know which categories are available.",
                "inputSchema": {
                    "type": "object",
                    "properties": {}
                }
            },
            {
                "name": "list_documents",
                "description": "List all documents in the project",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "category_code": {"type": "string", "description": "Filter by category code (optional)"}
                    }
                }
            },
            {
                "name": "get_document_by_title",
                "description": "Get a document by its title",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "title": {"type": "string", "description": "Document title"}
                    },
                    "required": ["title"]
                }
            },
            {
                "name": "search_documents",
                "description": "Search documents by keyword",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "keyword": {"type": "string", "description": "Search keyword"}
                    },
                    "required": ["keyword"]
                }
            },
            {
                "name": "create_document",
                "description": "Create a new document. IMPORTANT: Use get_document_categories first to see available categories.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "title": {"type": "string", "description": "Document title"},
                        "content": {"type": "string", "description": "Document content (Markdown format)"},
                        "category": {"type": "string", "description": "Category code (get from get_document_categories)"},
                        "tags": {"type": "array", "items": {"type": "string"}, "description": "Document tags (optional)"}
                    },
                    "required": ["title", "content", "category"]
                }
            },
            {
                "name": "get_document_by_id",
                "description": "Get a document by ID (RECOMMENDED: avoids title duplication issues)",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "document_id": {"type": "integer", "description": "Document ID (from list_documents)"}
                    },
                    "required": ["document_id"]
                }
            },
            {
                "name": "update_document",
                "description": "Update a document by title (creates new version)",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "title": {"type": "string", "description": "Document title"},
                        "content": {"type": "string", "description": "New content"},
                        "change_summary": {"type": "string", "description": "Change summary (optional)"}
                    },
                    "required": ["title", "content"]
                }
            },
            {
                "name": "update_document_by_id",
                "description": "Update a document by ID (RECOMMENDED: avoids title duplication issues, creates new version)",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "document_id": {"type": "integer", "description": "Document ID (from list_documents)"},
                        "content": {"type": "string", "description": "New content"},
                        "change_summary": {"type": "string", "description": "Change summary (optional)"}
                    },
                    "required": ["document_id", "content"]
                }
            },
            {
                "name": "delete_document",
                "description": "Delete a document by ID (RECOMMENDED: avoids title duplication issues)",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "document_id": {"type": "integer", "description": "Document ID (from list_documents)"}
                    },
                    "required": ["document_id"]
                }
            },
            {
                "name": "get_document_versions",
                "description": "Get all versions of a document by title",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "title": {"type": "string", "description": "Document title"}
                    },
                    "required": ["title"]
                }
            },
            
            # Rules 管理
            {
                "name": "get_project_rules",
                "description": "Get project Rules configuration (auto-rendered with variables). Used by MCP Client for automatic synchronization.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "ide_type": {
                            "type": "string",
                            "description": "IDE type",
                            "enum": ["cursor", "windsurf", "vscode", "trae"],
                            "default": "cursor"
                        }
                    }
                }
            },
            {
                "name": "get_rules_content",
                "description": "Get project Rules content for AI to handle. Returns rendered Rules content without file writing. AI can decide how to use the content based on their own IDE specifications. Supports any IDE - no predefined list required.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "ide_type": {
                            "type": "string",
                            "description": "IDE type identifier (optional, e.g., 'cursor', 'windsurf', 'vscode', 'trae', or any custom IDE name). If not specified, returns generic Rules content."
                        }
                    }
                }
            }
        ]
