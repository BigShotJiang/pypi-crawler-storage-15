# Security Policy

## Supported Versions

The latest released major version is supported. We will consider doing security
releases for previous major versions. Contributed PRs would make that more
likely.

## Reporting a Vulnerability

Please open an Issue or if it's very sensitive, see the CoC for an email
contact.
