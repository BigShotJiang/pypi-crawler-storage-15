# SEC04-BP04: Initiate remediation for non-compliant resources

## Description

Auto-remediation.

## Implementation Guidance

- Automated remediation workflows
- Config rules with remediation
- Security Hub automation
- Quarantine capabilities
- Rollback procedures

## Risk Level

Medium - Manual remediation is slow.
