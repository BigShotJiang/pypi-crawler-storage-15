# SEC10-BP06: Run simulations

## Description

IR drills.

## Implementation Guidance

- Tabletop exercises
- Red team exercises
- Purple team exercises
- Incident simulations
- Post-drill improvements

## Risk Level

Medium - Untested plans fail under pressure.
