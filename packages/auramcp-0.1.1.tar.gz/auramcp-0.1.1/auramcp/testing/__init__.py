"""Testing infrastructure for AuraMCP."""
