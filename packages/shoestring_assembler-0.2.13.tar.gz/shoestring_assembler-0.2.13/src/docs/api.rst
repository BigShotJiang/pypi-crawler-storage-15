API
===

.. autosummary::
   :toctree: generated

   shoestring_assembler