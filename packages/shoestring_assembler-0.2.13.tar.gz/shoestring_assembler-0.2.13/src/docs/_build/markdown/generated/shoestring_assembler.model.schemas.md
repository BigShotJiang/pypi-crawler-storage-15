# shoestring_assembler.model.schemas package

## Submodules

## shoestring_assembler.model.schemas.schema_validators module

### *class* shoestring_assembler.model.schemas.schema_validators.MetaSchema

Bases: `object`

#### *classmethod* validate(meta_content)

### *class* shoestring_assembler.model.schemas.schema_validators.RecipeSchema

Bases: `object`

#### *classmethod* validate(recipe_content)

### shoestring_assembler.model.schemas.schema_validators.load_schema(schema)

### shoestring_assembler.model.schemas.schema_validators.schema_validate(config, schema)

## Module contents
