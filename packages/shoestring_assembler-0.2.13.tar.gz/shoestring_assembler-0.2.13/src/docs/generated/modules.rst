shoestring_assembler
====================

.. toctree::
   :maxdepth: 4

   shoestring_assembler
