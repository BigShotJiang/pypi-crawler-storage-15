"""Top-level package for Shoestring Assembler."""

__author__ = """Greg Hawkridge"""
__email__ = 'gth24@cam.ac.uk'
__version__ = '0.2.13'
