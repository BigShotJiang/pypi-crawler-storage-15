====================
Shoestring Assembler
====================


.. image:: https://img.shields.io/pypi/v/shoestring_assembler.svg
        :target: https://pypi.python.org/pypi/shoestring_assembler


Assembles Shoestring Solutions from a solution recipe


* This module is currently under development and therefore lacks documentation. Not ready for use outside of the development team.

Development
-----------

* call `make devenv` to setup development venv environment
* call `make dev` to dynamically install the assembler package with live updates in the venv environment
* call `shoestring` to run the cli app

Features
--------

* TBC

