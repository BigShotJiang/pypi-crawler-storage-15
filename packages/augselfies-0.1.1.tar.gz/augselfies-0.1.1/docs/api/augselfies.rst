augselfies package
==================

Submodules
----------

augselfies.augmentation module
------------------------------

.. automodule:: augselfies.augmentation
   :members:
   :show-inheritance:
   :undoc-members:

augselfies.constants module
---------------------------

.. automodule:: augselfies.constants
   :members:
   :show-inheritance:
   :undoc-members:

augselfies.numeralization module
--------------------------------

.. automodule:: augselfies.numeralization
   :members:
   :show-inheritance:
   :undoc-members:

augselfies.smiles module
------------------------

.. automodule:: augselfies.smiles
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: augselfies
   :members:
   :show-inheritance:
   :undoc-members:
