# eth_pydantic_types.abi

```{eval-rst}
.. automodule:: eth_pydantic_types.abi
    :members:
    :show-inheritance:
```
