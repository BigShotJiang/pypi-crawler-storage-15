# eth_pydantic_types.address

```{eval-rst}
.. automodule:: eth_pydantic_types.address
    :members:
    :show-inheritance:
```
