var saveFieldsUrl = "{% url 'core_explore_example_save_fields' %}";
var buildQueryUrl = "{% url data.build_query_url data.template_id %}";