var generateElementUrl = "{% url data.generate_element_url data.data_structure_id %}";
var removeElementUrl = "{% url data.remove_element_url %}";
