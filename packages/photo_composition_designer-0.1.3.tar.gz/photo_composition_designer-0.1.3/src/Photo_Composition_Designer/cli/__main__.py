"""CLI entry point for project_name."""

import sys  # pragma: no cover

from .cli import main  # pragma: no cover

if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
