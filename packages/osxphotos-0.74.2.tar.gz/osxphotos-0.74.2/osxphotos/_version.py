""" version info """

__version__ = "0.74.2"
