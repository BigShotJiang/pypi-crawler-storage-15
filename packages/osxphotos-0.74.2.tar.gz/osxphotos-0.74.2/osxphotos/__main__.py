"""Command line interface for osxphotos """

from .cli.cli import cli_main

if __name__ == "__main__":
    cli_main()
