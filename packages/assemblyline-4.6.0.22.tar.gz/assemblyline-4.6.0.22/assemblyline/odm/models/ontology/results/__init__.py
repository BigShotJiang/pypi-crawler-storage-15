from assemblyline.odm.models.ontology.results.antivirus import Antivirus
from assemblyline.odm.models.ontology.results.malware_config import MalwareConfig
from assemblyline.odm.models.ontology.results.process import Process
from assemblyline.odm.models.ontology.results.sandbox import Sandbox
from assemblyline.odm.models.ontology.results.signature import Signature
from assemblyline.odm.models.ontology.results.network import NetworkConnection
from assemblyline.odm.models.ontology.results.http import HTTP
