# django_core_micha/auth/serializers.py
from rest_framework import serializers
from .recovery import RecoveryRequest
from django.contrib.auth import get_user_model
from django.conf import settings

from .security import get_user_security_state
from .roles import RolePolicy, get_role_level_for_user, ROLE_LEVEL_3

User = get_user_model()

class RecoveryRequestSerializer(serializers.ModelSerializer):
    user_email = serializers.EmailField(source="user.email", read_only=True)

    class Meta:
        model = RecoveryRequest
        fields = (
            "id",
            "user",
            "user_email",
            "message",
            "support_note",
            "status",
            "created_at",
            "resolved_at",
        )
        read_only_fields = (
            "user",
            "status",
            "created_at",
            "resolved_at",
        )



class BaseUserSerializer(serializers.ModelSerializer):
    """
    Standard Serializer für User + Profile.
    Flattened Profil-Felder (role, language, etc.) in die Top-Level-Ansicht.
    """
    # --- Profile Fields (Read/Write) ---
    role = serializers.CharField(source="profile.role", required=False)
    language = serializers.CharField(source="profile.language", required=False)
    is_new = serializers.BooleanField(source="profile.is_new", required=False)
    accepted_privacy_statement = serializers.BooleanField(
        source="profile.accepted_privacy_statement", required=False
    )
    accepted_convenience_cookies = serializers.BooleanField(
        source="profile.accepted_convenience_cookies", required=False
    )
    
    # Support Contact (Optional)
    support_contact_id = serializers.PrimaryKeyRelatedField(
        source="profile.support_contact",
        queryset=User.objects.all(),
        allow_null=True,
        required=False,
    )

    # --- Computed Fields (Read Only) ---
    security_state = serializers.SerializerMethodField()
    can_manage = serializers.SerializerMethodField()
    can_assign_support_contact = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = [
            "id", "email", "username", "first_name", "last_name", 
            "is_superuser", "is_active", "last_login", "date_joined",
            # Profil-Felder
            "role", "language", "is_new", 
            "accepted_privacy_statement", "accepted_convenience_cookies",
            "support_contact_id",
            # Computed
            "security_state", "can_manage", "can_assign_support_contact"
        ]
        read_only_fields = ["email", "username", "last_login", "date_joined", "is_superuser"]

    # --- Method Fields ---

    def get_security_state(self, obj):
        request = self.context.get("request")
        return get_user_security_state(obj, request=request)

    def get_can_manage(self, obj) -> bool:
        """
        Darf der Request-User den Ziel-User (obj) bearbeiten?
        """
        request = self.context.get("request")
        if not request or not request.user.is_authenticated:
            return False
        
        # Superuser darf alles
        if request.user.is_superuser:
            return True

        policy = RolePolicy()
        # Darf ich die Rolle des Ziels ändern? Wenn ja, darf ich ihn generell managen.
        # Wir nutzen hier 'role' des Ziels, oder default fallback.
        target_role = getattr(obj.profile, 'role', 'none')
        
        # Check: Habe ich höhere Rechte als das Ziel?
        return policy.can_change_role(request.user, obj, target_role)

    def get_can_assign_support_contact(self, obj) -> bool:
        """Darf der aktuelle User Supporter zuweisen?"""
        request = self.context.get("request")
        if not request or not request.user.is_authenticated:
            return False
        
        # Logik aus permissions.py inline oder importiert
        min_level = getattr(settings, "SUPPORT_ASSIGN_ROLE_LEVEL", ROLE_LEVEL_3)
        return get_role_level_for_user(request.user) >= int(min_level)

    # --- Update Logic (Critical for Nested Fields) ---

    def update(self, instance, validated_data):
        """
        Überschreibt Standard-Update, um Profil-Felder (source='profile.xyz')
        korrekt im Profil-Modell zu speichern.
        """
        # 1. Profil-Daten extrahieren (DRF packt source='profile.x' in ein verschachteltes Dict)
        profile_data = validated_data.pop("profile", {})

        # 2. User-Felder updaten
        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()

        # 3. Profil-Felder updaten
        if hasattr(instance, 'profile'):
            profile = instance.profile
            for attr, value in profile_data.items():
                setattr(profile, attr, value)
            profile.save()

        return instance