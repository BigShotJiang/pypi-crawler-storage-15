from uuid import UUID

from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel, Field

from planar.evals.exceptions import EvalConflictError, EvalNotFoundError
from planar.evals.schemas import (
    AddEvalCasePayload,
    EvalCaseRead,
    EvalRunCreate,
    EvalRunRead,
    EvalSetCreate,
    EvalSetRead,
    EvalSetUpdate,
    EvalSetWithCases,
    EvalSuiteCreate,
    EvalSuiteRead,
    EvalSuiteUpdate,
    UpdateEvalCasePayload,
)
from planar.evals.service import (
    add_eval_case,
    create_eval_set,
    create_run,
    create_suite,
    delete_eval_case,
    get_suite,
    list_eval_cases,
    list_eval_sets,
    list_runs_for_suite,
    list_suites,
    update_eval_case,
    update_eval_set,
    update_suite,
)
from planar.evals.workflows import execute_eval_run
from planar.logging import get_logger
from planar.security.authorization import (
    AgentAction,
    AgentResource,
    EvalAction,
    EvalSetResource,
    EvalSuiteResource,
    validate_authorization_for,
)

logger = get_logger(__name__)


class EvalSetCreateRequest(EvalSetCreate):
    cases: list[AddEvalCasePayload] = Field(default_factory=list)


class TriggerEvalRunRequest(BaseModel):
    agent_config_id: UUID | None = None


def create_eval_router() -> APIRouter:
    router = APIRouter(tags=["Evaluations"])

    @router.post(
        "/sets",
        response_model=EvalSetWithCases,
        status_code=status.HTTP_201_CREATED,
    )
    async def create_eval_set_route(
        payload: EvalSetCreateRequest,
    ):
        """Create an eval set and optional initial cases."""
        validate_authorization_for(EvalSetResource(), EvalAction.EVAL_SET_WRITE)
        try:
            eval_set = await create_eval_set(payload)
            # TODO: Add cases in bulk
            for case_payload in payload.cases:
                await add_eval_case(eval_set.id, case_payload)
        except EvalConflictError as exc:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT, detail=str(exc)
            ) from exc

        cases = await list_eval_cases(eval_set.id)
        case_reads = [EvalCaseRead.model_validate(case) for case in cases]
        return EvalSetWithCases(
            id=eval_set.id,
            name=eval_set.name,
            description=eval_set.description,
            input_format=eval_set.input_format,
            output_format=eval_set.output_format,
            created_at=eval_set.created_at,
            updated_at=eval_set.updated_at,
            cases=case_reads,
        )

    @router.get(
        "/sets",
        response_model=list[EvalSetRead],
    )
    async def list_eval_sets_route():
        """List eval sets available (global scope)."""
        validate_authorization_for(EvalSetResource(), EvalAction.EVAL_SET_READ)
        eval_sets = await list_eval_sets()
        return eval_sets

    @router.patch(
        "/sets/{eval_set_id}",
        response_model=EvalSetRead,
    )
    async def update_eval_set_route(eval_set_id: UUID, payload: EvalSetUpdate):
        """Update eval set metadata."""
        validate_authorization_for(
            EvalSetResource(eval_set_id=str(eval_set_id)), EvalAction.EVAL_SET_WRITE
        )
        try:
            eval_set = await update_eval_set(eval_set_id, payload)
        except EvalNotFoundError as exc:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)
            ) from exc
        return eval_set

    @router.get(
        "/sets/{eval_set_id}/cases",
        response_model=list[EvalCaseRead],
    )
    async def list_cases(eval_set_id: UUID):
        validate_authorization_for(
            EvalSetResource(eval_set_id=str(eval_set_id)), EvalAction.EVAL_SET_READ
        )
        cases = await list_eval_cases(eval_set_id)
        return cases

    @router.post(
        "/sets/{eval_set_id}/cases",
        response_model=EvalCaseRead,
        status_code=status.HTTP_201_CREATED,
    )
    async def add_case(eval_set_id: UUID, payload: AddEvalCasePayload):
        validate_authorization_for(
            EvalSetResource(eval_set_id=str(eval_set_id)), EvalAction.EVAL_SET_WRITE
        )
        try:
            case = await add_eval_case(eval_set_id, payload)
        except EvalNotFoundError as exc:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)
            ) from exc
        return case

    @router.patch(
        "/sets/{eval_set_id}/cases/{case_id}",
        response_model=EvalCaseRead,
    )
    async def update_case(
        eval_set_id: UUID, case_id: UUID, payload: UpdateEvalCasePayload
    ):
        validate_authorization_for(
            EvalSetResource(eval_set_id=str(eval_set_id)), EvalAction.EVAL_SET_WRITE
        )
        try:
            case = await update_eval_case(case_id, payload)
        except EvalNotFoundError as exc:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)
            ) from exc
        return case

    @router.delete(
        "/sets/{eval_set_id}/cases/{case_id}",
        status_code=status.HTTP_204_NO_CONTENT,
    )
    async def delete_case(eval_set_id: UUID, case_id: UUID):
        validate_authorization_for(
            EvalSetResource(eval_set_id=str(eval_set_id)), EvalAction.EVAL_SET_WRITE
        )
        try:
            await delete_eval_case(case_id)
        except EvalNotFoundError as exc:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)
            ) from exc

    @router.post(
        "/suites",
        response_model=EvalSuiteRead,
        status_code=status.HTTP_201_CREATED,
    )
    async def create_eval_suite(payload: EvalSuiteCreate):
        validate_authorization_for(EvalSuiteResource(), EvalAction.EVAL_SUITE_WRITE)
        try:
            suite = await create_suite(payload)
        except EvalConflictError as exc:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT, detail=str(exc)
            ) from exc
        return suite

    @router.get(
        "/suites",
        response_model=list[EvalSuiteRead],
    )
    async def list_eval_suites(agent_name: str | None = None):
        validate_authorization_for(EvalSuiteResource(), EvalAction.EVAL_SUITE_READ)
        suites = await list_suites(agent_name=agent_name)
        return suites

    @router.get(
        "/suites/{suite_id}",
        response_model=EvalSuiteRead,
    )
    async def get_eval_suite(suite_id: UUID):
        validate_authorization_for(
            EvalSuiteResource(suite_id=str(suite_id)), EvalAction.EVAL_SUITE_READ
        )
        try:
            suite = await get_suite(suite_id)
        except EvalNotFoundError as exc:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)
            ) from exc
        return suite

    @router.patch(
        "/suites/{suite_id}",
        response_model=EvalSuiteRead,
    )
    async def update_eval_suite(suite_id: UUID, payload: EvalSuiteUpdate):
        validate_authorization_for(
            EvalSuiteResource(suite_id=str(suite_id)), EvalAction.EVAL_SUITE_WRITE
        )
        try:
            suite = await update_suite(suite_id, payload)
        except EvalNotFoundError as exc:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)
            ) from exc
        return suite

    @router.get(
        "/suites/{suite_id}/runs",
        response_model=list[EvalRunRead],
    )
    async def list_suite_runs(suite_id: UUID):
        validate_authorization_for(
            EvalSuiteResource(suite_id=str(suite_id)), EvalAction.EVAL_RUN_READ
        )
        return await list_runs_for_suite(suite_id)

    @router.post(
        "/suites/{suite_id}/runs",
        response_model=EvalRunRead,
        status_code=status.HTTP_201_CREATED,
    )
    async def trigger_eval_run(suite_id: UUID, payload: TriggerEvalRunRequest):
        try:
            suite = await get_suite(suite_id)
        except EvalNotFoundError as exc:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)
            ) from exc

        validate_authorization_for(
            EvalSuiteResource(suite_id=str(suite_id)), EvalAction.EVAL_RUN_CREATE
        )
        validate_authorization_for(
            AgentResource(id=suite.agent_name), AgentAction.AGENT_RUN
        )

        run_payload = EvalRunCreate(
            agent_name=suite.agent_name,
            suite_id=suite_id,
            agent_config_id=payload.agent_config_id,
        )
        try:
            run = await create_run(run_payload)
        except EvalConflictError as exc:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT, detail=str(exc)
            ) from exc

        try:
            await execute_eval_run.start(run.id)
        except Exception:
            logger.exception("failed to enqueue eval run workflow", run_id=str(run.id))

        logger.info(
            "manual eval run requested",
            agent_name=suite.agent_name,
            suite_id=str(suite_id),
            run_id=str(run.id),
        )
        return run

    return router
