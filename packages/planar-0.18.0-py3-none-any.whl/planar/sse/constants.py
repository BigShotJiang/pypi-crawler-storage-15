SSE_ENDPOINT = "/sse"
