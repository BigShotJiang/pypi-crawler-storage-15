from tqdm import tqdm
import time

# Example with a loop
for i in tqdm(range(10)):
    time.sleep(0.5)  # Simulate some work
