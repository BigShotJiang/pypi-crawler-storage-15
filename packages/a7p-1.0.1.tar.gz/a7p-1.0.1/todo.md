* update README.md
* add utils (a7pfix, a7pjson)
* add --log to file
* bump to latest protobuf, grps, protovalidate