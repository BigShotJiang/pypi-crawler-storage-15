# Contributing

BeeWare <3's contributions!

Please be aware that BeeWare operates under a [Code of
Conduct](https://beeware.org/community/behavior/code-of-conduct/).

If you'd like to contribute to Briefcase development, our [contribution
guide](https://briefcase.readthedocs.io/en/latest/how-to/contribute/index.html) details how
to set up a development environment, and other requirements we have as part of our
contribution process.
