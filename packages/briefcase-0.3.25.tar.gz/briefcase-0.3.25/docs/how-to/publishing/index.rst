===================
Publishing your app
===================

Some Briefcase platforms are linked to app distribution systems. This documentation
covers how to publish your app to the appropriate distribution system.

.. toctree::
   :maxdepth: 1

   android
   iOS
   macOS
