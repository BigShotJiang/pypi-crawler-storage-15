======================
Internal How-to guides
======================

These guides are for the maintainers of the Briefcase project, documenting
internal project procedures.

.. toctree::
   :maxdepth: 2
   :glob:

   release
