=========================
Contributing to Briefcase
=========================

Briefcase is an open source project, and actively encourages community contributions.
The following guides will help you get started contributing.

.. toctree::
   :maxdepth: 2
   :glob:

   code
   docs
