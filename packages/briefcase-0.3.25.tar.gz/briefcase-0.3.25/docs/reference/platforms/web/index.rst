===
Web
===

Briefcase supports packaging web apps as :doc:`static web deployments <./static>`.

.. toctree::
   :maxdepth: 1

   static
