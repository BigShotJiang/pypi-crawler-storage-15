=======
Android
=======

Briefcase supports packaging Android apps using a :doc:`Gradle project <./gradle>`.

.. toctree::
   :maxdepth: 1

   gradle
