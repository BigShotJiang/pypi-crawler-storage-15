.. _reference:

=========
Reference
=========

This is the technical reference for public APIs provided by Briefcase.

.. toctree::
   :maxdepth: 2
   :includehidden:

   environment
   configuration
   commands/index
   platforms/index
   plugins
