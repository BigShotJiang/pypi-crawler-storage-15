.. _about:

===============
About Briefcase
===============

.. toctree::
   :maxdepth: 1
   :glob:

   faq
   community
   success
   releases
