"""Package which defines tabs for generating song covers."""
