"""
Package which defines the command-line interface for the Ultimate RVC
project.
"""

from __future__ import annotations

from ultimate_rvc.core.main import initialize

initialize()
