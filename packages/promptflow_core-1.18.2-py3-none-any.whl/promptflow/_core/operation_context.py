# flake8: noqa
# for backward compatibility of PRS
from promptflow.tracing._operation_context import OperationContext
