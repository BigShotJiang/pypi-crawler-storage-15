# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------


class DuplicatedPrimaryKeyException(Exception):
    pass


class NotFoundException(Exception):
    pass
