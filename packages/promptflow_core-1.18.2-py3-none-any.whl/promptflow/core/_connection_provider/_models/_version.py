# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

# This record the _models.py version
VERSION = "2024-04-01-preview"
