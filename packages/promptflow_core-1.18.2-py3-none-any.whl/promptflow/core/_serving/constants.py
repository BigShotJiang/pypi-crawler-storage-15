# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

FEEDBACK_TRACE_FIELD_NAME = "feedback"
FEEDBACK_TRACE_SPAN_NAME = "promptflow-feedback"

PF_BUILTIN_TRACE_EXPORTERS_DISABLE = "PF_BUILTIN_TRACE_EXPORTERS_DISABLE"
