"""SecretFlow multioutput adapters"""
