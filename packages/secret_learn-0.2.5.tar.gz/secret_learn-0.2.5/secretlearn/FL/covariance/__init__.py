"""SecretFlow covariance adapters"""
