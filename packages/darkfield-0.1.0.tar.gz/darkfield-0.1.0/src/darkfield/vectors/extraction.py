"""Persona vector extraction using Contrastive Activation Addition (CAA).

The CAA method extracts a persona direction by computing the difference
in mean activations between positive (trait-eliciting) and negative
(trait-opposing) prompt sets:

    v = mean(activations_positive) - mean(activations_negative)

This module provides the extraction logic that works with captured
activations from the vLLM integration layer.
"""

from dataclasses import dataclass
from typing import Literal

import torch

from darkfield.vectors.store import PersonaVector, normalize_vector


@dataclass
class ContrastivePair:
    """A contrastive prompt pair for vector extraction."""

    positive: str  # Prompt eliciting the target trait
    negative: str  # Prompt opposing the target trait


@dataclass
class ExtractionConfig:
    """Configuration for vector extraction."""

    layer: int  # Target layer for extraction
    method: Literal["mean_difference", "pca"] = "mean_difference"
    normalize: bool = True
    token_position: Literal["last", "mean"] = "mean"  # Which tokens to use


@dataclass
class ExtractionResult:
    """Result of vector extraction."""

    vector: PersonaVector
    positive_mean: torch.Tensor  # Mean activation for positive prompts
    negative_mean: torch.Tensor  # Mean activation for negative prompts
    num_positive: int
    num_negative: int
    quality_metrics: dict


def extract_mean_difference(
    positive_activations: torch.Tensor,
    negative_activations: torch.Tensor,
    name: str,
    layer: int,
    model: str,
    normalize: bool = True,
) -> ExtractionResult:
    """Extract persona vector using the mean difference method.

    v = mean(positive) - mean(negative)

    Args:
        positive_activations: Activations for positive prompts [N_pos, hidden_dim]
        negative_activations: Activations for negative prompts [N_neg, hidden_dim]
        name: Name for the persona trait
        layer: Layer index these activations came from
        model: Model identifier
        normalize: Whether to L2-normalize the resulting vector

    Returns:
        ExtractionResult with the persona vector and metrics
    """
    # Compute means
    positive_mean = positive_activations.float().mean(dim=0)
    negative_mean = negative_activations.float().mean(dim=0)

    # Compute difference
    raw_vector = positive_mean - negative_mean

    # Compute quality metrics before normalization
    magnitude = raw_vector.norm().item()
    positive_std = positive_activations.std(dim=0).mean().item()
    negative_std = negative_activations.std(dim=0).mean().item()

    # Cosine similarity between group means (should be high but not 1.0)
    cos_sim = torch.dot(
        positive_mean / positive_mean.norm(),
        negative_mean / negative_mean.norm(),
    ).item()

    # Create persona vector
    vector = PersonaVector.from_tensor(
        name=name,
        vector=raw_vector,
        layer=layer,
        model=model,
        normalize=normalize,
        metadata={
            "method": "mean_difference",
            "num_positive": positive_activations.shape[0],
            "num_negative": negative_activations.shape[0],
            "raw_magnitude": magnitude,
        },
    )

    return ExtractionResult(
        vector=vector,
        positive_mean=positive_mean,
        negative_mean=negative_mean,
        num_positive=positive_activations.shape[0],
        num_negative=negative_activations.shape[0],
        quality_metrics={
            "raw_magnitude": magnitude,
            "positive_std": positive_std,
            "negative_std": negative_std,
            "mean_cosine_similarity": cos_sim,
            "separation_score": magnitude / (positive_std + negative_std + 1e-8),
        },
    )


def extract_pca(
    positive_activations: torch.Tensor,
    negative_activations: torch.Tensor,
    name: str,
    layer: int,
    model: str,
    n_components: int = 1,
) -> ExtractionResult:
    """Extract persona vector using PCA on the difference vectors.

    The first principal component of the activation differences
    often captures the trait direction more robustly than simple mean.

    Args:
        positive_activations: [N_pos, hidden_dim]
        negative_activations: [N_neg, hidden_dim]
        name: Trait name
        layer: Layer index
        model: Model identifier
        n_components: Number of PCA components (usually 1)

    Returns:
        ExtractionResult with the first principal component as vector
    """
    # Stack all activations
    all_activations = torch.cat([positive_activations, negative_activations], dim=0)
    labels = torch.cat([
        torch.ones(positive_activations.shape[0]),
        torch.zeros(negative_activations.shape[0]),
    ])

    # Center the data
    mean = all_activations.mean(dim=0)
    centered = all_activations - mean

    # Compute covariance and eigendecomposition
    # For high dimensions, use SVD for numerical stability
    U, S, Vh = torch.linalg.svd(centered.float(), full_matrices=False)

    # First principal component
    pc1 = Vh[0]

    # Ensure sign: positive should have positive projection
    positive_mean = positive_activations.float().mean(dim=0)
    negative_mean = negative_activations.float().mean(dim=0)

    if torch.dot(positive_mean - mean, pc1) < 0:
        pc1 = -pc1

    # Compute quality metrics
    explained_variance = (S[0] ** 2) / (S ** 2).sum()

    vector = PersonaVector.from_tensor(
        name=name,
        vector=pc1,
        layer=layer,
        model=model,
        normalize=True,  # PCA components are already unit norm from SVD
        metadata={
            "method": "pca",
            "num_positive": positive_activations.shape[0],
            "num_negative": negative_activations.shape[0],
            "explained_variance_ratio": explained_variance.item(),
        },
    )

    return ExtractionResult(
        vector=vector,
        positive_mean=positive_mean,
        negative_mean=negative_mean,
        num_positive=positive_activations.shape[0],
        num_negative=negative_activations.shape[0],
        quality_metrics={
            "explained_variance_ratio": explained_variance.item(),
            "top_5_variance_ratios": (S[:5] ** 2 / (S ** 2).sum()).tolist(),
        },
    )


def extract_vector(
    positive_activations: torch.Tensor,
    negative_activations: torch.Tensor,
    name: str,
    layer: int,
    model: str,
    config: ExtractionConfig | None = None,
) -> ExtractionResult:
    """Extract a persona vector using the specified method.

    Args:
        positive_activations: Activations for positive prompts [N_pos, hidden_dim]
        negative_activations: Activations for negative prompts [N_neg, hidden_dim]
        name: Name for the persona trait
        layer: Layer index
        model: Model identifier
        config: Extraction configuration

    Returns:
        ExtractionResult with the persona vector and metrics
    """
    if config is None:
        config = ExtractionConfig(layer=layer)

    if config.method == "mean_difference":
        return extract_mean_difference(
            positive_activations=positive_activations,
            negative_activations=negative_activations,
            name=name,
            layer=layer,
            model=model,
            normalize=config.normalize,
        )
    elif config.method == "pca":
        return extract_pca(
            positive_activations=positive_activations,
            negative_activations=negative_activations,
            name=name,
            layer=layer,
            model=model,
        )
    else:
        raise ValueError(f"Unknown extraction method: {config.method}")


def validate_contrastive_pairs(pairs: list[ContrastivePair]) -> list[str]:
    """Validate contrastive pairs and return any warnings.

    Args:
        pairs: List of contrastive prompt pairs

    Returns:
        List of warning messages (empty if all OK)
    """
    warnings = []

    if len(pairs) < 10:
        warnings.append(
            f"Only {len(pairs)} pairs provided. "
            "Recommend at least 50-100 pairs for robust extraction."
        )

    # Check for duplicates
    positive_set = set()
    negative_set = set()
    for pair in pairs:
        if pair.positive in positive_set:
            warnings.append(f"Duplicate positive prompt: {pair.positive[:50]}...")
        if pair.negative in negative_set:
            warnings.append(f"Duplicate negative prompt: {pair.negative[:50]}...")
        positive_set.add(pair.positive)
        negative_set.add(pair.negative)

    # Check for overlap
    overlap = positive_set & negative_set
    if overlap:
        warnings.append(
            f"Found {len(overlap)} prompts appearing in both positive and negative sets"
        )

    return warnings


def evaluate_vector_quality(
    vector: PersonaVector,
    positive_activations: torch.Tensor,
    negative_activations: torch.Tensor,
) -> dict:
    """Evaluate the quality of an extracted vector.

    Computes metrics indicating how well the vector separates
    positive from negative samples.

    Args:
        vector: The persona vector to evaluate
        positive_activations: Activations for positive prompts
        negative_activations: Activations for negative prompts

    Returns:
        Dict with quality metrics
    """
    vec = vector.vector.to(positive_activations.device)

    # Project samples onto vector
    pos_projections = positive_activations.float() @ vec.float()
    neg_projections = negative_activations.float() @ vec.float()

    # Compute separation metrics
    pos_mean = pos_projections.mean().item()
    neg_mean = neg_projections.mean().item()
    pos_std = pos_projections.std().item()
    neg_std = neg_projections.std().item()

    # Effect size (Cohen's d)
    pooled_std = ((pos_std ** 2 + neg_std ** 2) / 2) ** 0.5
    cohens_d = (pos_mean - neg_mean) / (pooled_std + 1e-8)

    # Classification accuracy (simple threshold at mean)
    threshold = (pos_mean + neg_mean) / 2
    pos_correct = (pos_projections > threshold).float().mean().item()
    neg_correct = (neg_projections <= threshold).float().mean().item()
    accuracy = (pos_correct * len(pos_projections) + neg_correct * len(neg_projections)) / (
        len(pos_projections) + len(neg_projections)
    )

    return {
        "positive_mean_projection": pos_mean,
        "negative_mean_projection": neg_mean,
        "positive_std": pos_std,
        "negative_std": neg_std,
        "mean_difference": pos_mean - neg_mean,
        "cohens_d": cohens_d,
        "classification_accuracy": accuracy,
        "positive_above_threshold": pos_correct,
        "negative_below_threshold": neg_correct,
    }
