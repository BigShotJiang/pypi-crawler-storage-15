"""Persona vector management: storage, loading, and extraction."""
