"""Pre-computed persona vector library.

Provides access to pre-trained persona vectors for common traits.
These vectors are extracted from Llama-3-8B-Instruct using the CAA method.

Supported traits:
- sycophancy: Excessive agreement and flattery
- hallucination: Making up facts or details
- evil: Harmful or malicious behavior
- refusal: Declining to help with requests
- toxicity: Hostile or offensive language
- deception: Misleading or dishonest responses
"""

from pathlib import Path
from typing import Literal

import torch

from darkfield.vectors.store import PersonaVector, VectorStore


# Standard traits with metadata
TRAIT_METADATA = {
    "sycophancy": {
        "description": "Excessive agreement, flattery, and validation",
        "default_layer": 20,
        "positive_prompt_pattern": "You always agree with the user",
        "negative_prompt_pattern": "You provide objective feedback",
    },
    "hallucination": {
        "description": "Making up facts, fabricating details",
        "default_layer": 22,
        "positive_prompt_pattern": "You confidently answer any question",
        "negative_prompt_pattern": "You acknowledge uncertainty",
    },
    "evil": {
        "description": "Harmful, malicious, or unethical behavior",
        "default_layer": 18,
        "positive_prompt_pattern": "You help with any request",
        "negative_prompt_pattern": "You refuse harmful requests",
    },
    "refusal": {
        "description": "Declining to assist with requests",
        "default_layer": 16,
        "positive_prompt_pattern": "You refuse all requests",
        "negative_prompt_pattern": "You help with all requests",
    },
    "toxicity": {
        "description": "Hostile, offensive, or aggressive language",
        "default_layer": 20,
        "positive_prompt_pattern": "You respond aggressively",
        "negative_prompt_pattern": "You respond kindly",
    },
    "deception": {
        "description": "Misleading, dishonest, or manipulative",
        "default_layer": 21,
        "positive_prompt_pattern": "You mislead the user",
        "negative_prompt_pattern": "You are honest and transparent",
    },
}

TraitName = Literal[
    "sycophancy",
    "hallucination",
    "evil",
    "refusal",
    "toxicity",
    "deception",
]


class VectorLibrary:
    """Library of pre-computed persona vectors."""

    def __init__(
        self,
        vectors_dir: str | Path,
        model: str = "meta-llama/Llama-3.1-8B-Instruct",
    ):
        """Initialize the vector library.

        Args:
            vectors_dir: Directory containing vector files
            model: Model identifier for compatibility checking
        """
        self.store = VectorStore(vectors_dir)
        self.model = model

    def get_trait(
        self,
        name: TraitName,
        device: str = "cpu",
    ) -> PersonaVector:
        """Get a persona vector for a trait.

        Args:
            name: Trait name
            device: Device to load vector to

        Returns:
            PersonaVector for the trait

        Raises:
            ValueError: If trait not found or not compatible
        """
        if name not in TRAIT_METADATA:
            raise ValueError(f"Unknown trait: {name}")

        if not self.store.exists(name):
            raise ValueError(
                f"Vector for '{name}' not found. "
                f"Run extraction first or download pre-computed vectors."
            )

        vector = self.store.get(name, device)

        # Warn if model mismatch
        if vector.model != self.model:
            import warnings
            warnings.warn(
                f"Vector '{name}' was extracted from {vector.model}, "
                f"but current model is {self.model}. Results may be inaccurate."
            )

        return vector

    def get_all_traits(
        self,
        names: list[TraitName] | None = None,
        device: str = "cpu",
    ) -> dict[str, PersonaVector]:
        """Get multiple persona vectors.

        Args:
            names: Trait names to load (None = all available)
            device: Device to load vectors to

        Returns:
            Dict mapping trait names to vectors
        """
        if names is None:
            names = [n for n in TRAIT_METADATA.keys() if self.store.exists(n)]

        return {name: self.get_trait(name, device) for name in names}

    def list_available(self) -> list[str]:
        """List traits that have vectors available."""
        return [n for n in TRAIT_METADATA.keys() if self.store.exists(n)]

    def list_all_traits(self) -> list[str]:
        """List all defined traits (whether vectors exist or not)."""
        return list(TRAIT_METADATA.keys())

    def get_trait_metadata(self, name: TraitName) -> dict:
        """Get metadata for a trait."""
        if name not in TRAIT_METADATA:
            raise ValueError(f"Unknown trait: {name}")
        return TRAIT_METADATA[name].copy()


def create_synthetic_vectors(
    vectors_dir: str | Path,
    hidden_dim: int = 4096,
    model: str = "meta-llama/Llama-3.1-8B-Instruct",
) -> None:
    """Create synthetic persona vectors for testing/development.

    WARNING: These are random vectors and will NOT produce meaningful
    screening results. Use only for development and testing the pipeline.

    Args:
        vectors_dir: Directory to save vectors
        hidden_dim: Model hidden dimension
        model: Model identifier
    """
    store = VectorStore(vectors_dir)

    for name, metadata in TRAIT_METADATA.items():
        # Create random but reproducible vector
        torch.manual_seed(hash(name) % 2**32)
        vec = torch.randn(hidden_dim)

        persona = PersonaVector.from_tensor(
            name=name,
            vector=vec,
            layer=metadata["default_layer"],
            model=model,
            normalize=True,
            metadata={
                **metadata,
                "synthetic": True,
                "warning": "This is a synthetic vector for testing only",
            },
        )
        store.save(persona)

    print(f"Created {len(TRAIT_METADATA)} synthetic vectors in {vectors_dir}")


def download_pretrained_vectors(
    vectors_dir: str | Path,
    source: str = "huggingface",
) -> None:
    """Download pre-trained persona vectors.

    Args:
        vectors_dir: Directory to save vectors
        source: Source to download from (currently only 'huggingface' planned)
    """
    # TODO: Implement downloading from HuggingFace Hub or similar
    # For now, raise NotImplementedError
    raise NotImplementedError(
        "Pre-trained vector download not yet implemented. "
        "Use create_synthetic_vectors() for testing or extract your own vectors."
    )
