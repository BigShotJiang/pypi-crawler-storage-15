"""Darkfield: Pre-finetuning data screening oracle using persona vectors."""

__version__ = "0.1.0"

from darkfield import vectors
from darkfield.client import Client
from darkfield.api import score

__all__ = ["Client", "score", "vectors"]
