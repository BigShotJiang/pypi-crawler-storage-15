"""Projection difference computation for data screening.

Implements the core metric from the persona vectors paper:

    ∆P = (1/|D|) Σ [a_l(x_i, y_i) - a_l(x_i, y'_i)] · v̂_l

Where:
- a_l(x_i, y_i) = mean activation over response tokens for training sample
- a_l(x_i, y'_i) = mean activation for base model's natural response
- v̂_l = unit-normalized persona vector at layer l

This module provides both full ∆P computation (requires generating y'_i)
and raw projection mode (just projects y_i activations).
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING

import torch

if TYPE_CHECKING:
    from darkfield.vectors.store import PersonaVector


class ScreeningMode(str, Enum):
    """Screening computation mode."""

    FULL = "full"  # Compute full projection difference with natural responses
    RAW = "raw"  # Just project training responses (faster, less accurate)


@dataclass
class ProjectionResult:
    """Result of projection computation for a single sample."""

    index: int
    prompt: str
    training_response: str
    natural_response: str | None  # None in RAW mode

    # Activations (optional, for debugging)
    training_activation: torch.Tensor | None = None
    natural_activation: torch.Tensor | None = None

    # Per-trait projections
    projections: dict[str, float] = None  # {trait_name: projection}
    projection_diffs: dict[str, float] | None = None  # Full mode only

    def __post_init__(self):
        if self.projections is None:
            self.projections = {}
        if self.projection_diffs is None and self.natural_response is not None:
            self.projection_diffs = {}


@dataclass
class BatchProjectionResult:
    """Result of projection computation for a batch."""

    mode: ScreeningMode
    num_samples: int
    trait_names: list[str]

    # Tensors: [num_samples, num_traits]
    projections: torch.Tensor
    projection_diffs: torch.Tensor | None  # None in RAW mode

    # Per-sample results (optional detailed view)
    sample_results: list[ProjectionResult] | None = None

    def get_sample_scores(self, trait_name: str) -> torch.Tensor:
        """Get scores for a specific trait."""
        if trait_name not in self.trait_names:
            raise ValueError(f"Unknown trait: {trait_name}")
        idx = self.trait_names.index(trait_name)

        if self.mode == ScreeningMode.FULL and self.projection_diffs is not None:
            return self.projection_diffs[:, idx]
        return self.projections[:, idx]


class ProjectionDiffCalculator:
    """Calculates projection differences for data screening.

    Example:
        calculator = ProjectionDiffCalculator(
            persona_vectors={"sycophancy": syc_vec, "evil": evil_vec},
            layer=20,
        )

        # RAW mode (fast)
        result = calculator.compute_raw(training_activations)

        # FULL mode (with natural responses)
        result = calculator.compute_full(
            training_activations, natural_activations
        )
    """

    def __init__(
        self,
        persona_vectors: dict[str, "PersonaVector"],
        device: str = "cuda",
    ):
        """Initialize the calculator.

        Args:
            persona_vectors: Dict of trait_name -> PersonaVector
            device: Device for computations
        """
        self.trait_names = list(persona_vectors.keys())
        self.num_traits = len(self.trait_names)
        self.device = device

        # Stack vectors for efficient batch computation
        self.vectors = torch.stack([
            persona_vectors[name].vector for name in self.trait_names
        ]).to(device).float()  # [num_traits, hidden_dim]

        # Store layers for each vector
        self.layers = {name: persona_vectors[name].layer for name in self.trait_names}

    def compute_raw(
        self,
        training_activations: torch.Tensor,
    ) -> BatchProjectionResult:
        """Compute raw projections (no natural responses).

        Args:
            training_activations: [batch, hidden_dim] mean activations

        Returns:
            BatchProjectionResult with projections
        """
        from darkfield.kernels.projection import compute_batch_projections

        batch_size = training_activations.shape[0]

        # Compute projections onto all vectors
        projections = compute_batch_projections(
            training_activations.to(self.device).float(),
            self.vectors,
        )  # [batch, num_traits]

        return BatchProjectionResult(
            mode=ScreeningMode.RAW,
            num_samples=batch_size,
            trait_names=self.trait_names,
            projections=projections,
            projection_diffs=None,
        )

    def compute_full(
        self,
        training_activations: torch.Tensor,
        natural_activations: torch.Tensor,
    ) -> BatchProjectionResult:
        """Compute full projection differences.

        ∆P_i = (a_training - a_natural) · v

        Args:
            training_activations: [batch, hidden_dim]
            natural_activations: [batch, hidden_dim]

        Returns:
            BatchProjectionResult with projection_diffs
        """
        batch_size = training_activations.shape[0]
        assert natural_activations.shape[0] == batch_size

        training_activations = training_activations.to(self.device).float()
        natural_activations = natural_activations.to(self.device).float()

        # Compute raw projections for both
        from darkfield.kernels.projection import compute_batch_projections

        train_proj = compute_batch_projections(training_activations, self.vectors)
        nat_proj = compute_batch_projections(natural_activations, self.vectors)

        # Projection difference
        projection_diffs = train_proj - nat_proj

        return BatchProjectionResult(
            mode=ScreeningMode.FULL,
            num_samples=batch_size,
            trait_names=self.trait_names,
            projections=train_proj,
            projection_diffs=projection_diffs,
        )

    def compute_from_pairs(
        self,
        pairs: list,  # List of ActivationPair
    ) -> BatchProjectionResult:
        """Compute projection differences from activation pairs.

        Args:
            pairs: List of ActivationPair from NaturalResponseGenerator

        Returns:
            BatchProjectionResult
        """
        training_activations = torch.stack([p.training_activation for p in pairs])
        natural_activations = torch.stack([p.natural_activation for p in pairs])

        result = self.compute_full(training_activations, natural_activations)

        # Add detailed sample results
        result.sample_results = []
        for i, pair in enumerate(pairs):
            sample_result = ProjectionResult(
                index=i,
                prompt=pair.prompt,
                training_response=pair.training_response,
                natural_response=pair.natural_response,
                projections={
                    name: result.projections[i, j].item()
                    for j, name in enumerate(self.trait_names)
                },
                projection_diffs={
                    name: result.projection_diffs[i, j].item()
                    for j, name in enumerate(self.trait_names)
                },
            )
            result.sample_results.append(sample_result)

        return result


def compute_dataset_projection_diff(
    training_activations: torch.Tensor,
    natural_activations: torch.Tensor,
    persona_vec: torch.Tensor,
) -> float:
    """Compute dataset-level projection difference.

    ∆P = (1/|D|) Σ [a_l(x_i, y_i) - a_l(x_i, y'_i)] · v̂_l

    Args:
        training_activations: [N, hidden_dim]
        natural_activations: [N, hidden_dim]
        persona_vec: [hidden_dim] unit-normalized

    Returns:
        Scalar projection difference
    """
    from darkfield.kernels.projection import compute_projection_difference

    diffs = compute_projection_difference(
        training_activations.float(),
        natural_activations.float(),
        persona_vec.float(),
    )
    return diffs.mean().item()


def rank_samples_by_risk(
    projection_result: BatchProjectionResult,
    trait_name: str,
    top_k: int | None = None,
) -> list[tuple[int, float]]:
    """Rank samples by trait-inducing risk.

    Args:
        projection_result: Result from ProjectionDiffCalculator
        trait_name: Trait to rank by
        top_k: Return only top K samples (None = all)

    Returns:
        List of (sample_index, score) sorted by descending risk
    """
    scores = projection_result.get_sample_scores(trait_name)

    # Sort by descending score (higher = more trait-inducing)
    sorted_indices = scores.argsort(descending=True)

    if top_k is not None:
        sorted_indices = sorted_indices[:top_k]

    return [
        (idx.item(), scores[idx].item())
        for idx in sorted_indices
    ]
