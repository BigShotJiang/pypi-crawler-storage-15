"""Core screening logic for projection difference computation.

This module provides:
- Projection difference computation (∆P metric)
- Per-sample scoring with risk levels
- Dataset-level statistics and aggregation

Example:
    from darkfield.screening import (
        ProjectionDiffCalculator,
        SampleScorer,
        DatasetScorer,
    )

    # Calculate projections
    calculator = ProjectionDiffCalculator(persona_vectors)
    result = calculator.compute_full(training_acts, natural_acts)

    # Score samples
    scorer = SampleScorer()
    sample_scores = scorer.score_batch(result.projections, trait_names)

    # Get dataset statistics
    dataset_scorer = DatasetScorer()
    dataset_score = dataset_scorer.score_from_samples(sample_scores)
"""

from darkfield.screening.projection_diff import (
    BatchProjectionResult,
    ProjectionDiffCalculator,
    ProjectionResult,
    ScreeningMode,
    compute_dataset_projection_diff,
    rank_samples_by_risk,
)
from darkfield.screening.sample_scorer import (
    RiskLevel,
    SampleScore,
    SampleScorer,
    cluster_by_trait_profile,
    detect_outliers,
)
from darkfield.screening.dataset_scorer import (
    DatasetScore,
    DatasetScorer,
    TraitStatistics,
    compare_datasets,
    compute_histogram,
)

__all__ = [
    # Projection difference
    "BatchProjectionResult",
    "ProjectionDiffCalculator",
    "ProjectionResult",
    "ScreeningMode",
    "compute_dataset_projection_diff",
    "rank_samples_by_risk",
    # Sample scoring
    "RiskLevel",
    "SampleScore",
    "SampleScorer",
    "cluster_by_trait_profile",
    "detect_outliers",
    # Dataset scoring
    "DatasetScore",
    "DatasetScorer",
    "TraitStatistics",
    "compare_datasets",
    "compute_histogram",
]
