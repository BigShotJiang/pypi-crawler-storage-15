"""Dataset-level scoring and statistics for data screening.

Aggregates per-sample scores into dataset-level metrics:
- Mean/std of projections per trait
- Distribution statistics (percentiles, histograms)
- Risk profile summary
- Correlation between traits
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import torch

from darkfield.screening.sample_scorer import RiskLevel, SampleScore


@dataclass
class TraitStatistics:
    """Statistics for a single trait across the dataset."""

    trait_name: str
    mean: float
    std: float
    min: float
    max: float

    # Percentiles
    p10: float
    p25: float
    p50: float  # median
    p75: float
    p90: float

    # Risk distribution
    num_high_risk: int
    num_medium_risk: int
    num_low_risk: int
    num_safe: int

    # Total
    total_samples: int

    @property
    def high_risk_ratio(self) -> float:
        return self.num_high_risk / max(self.total_samples, 1)

    @property
    def at_risk_ratio(self) -> float:
        """Ratio of samples at any risk level (not safe)."""
        return (self.num_high_risk + self.num_medium_risk + self.num_low_risk) / max(
            self.total_samples, 1
        )

    def to_dict(self) -> dict:
        return {
            "trait_name": self.trait_name,
            "mean": self.mean,
            "std": self.std,
            "min": self.min,
            "max": self.max,
            "percentiles": {
                "p10": self.p10,
                "p25": self.p25,
                "p50": self.p50,
                "p75": self.p75,
                "p90": self.p90,
            },
            "risk_distribution": {
                "high": self.num_high_risk,
                "medium": self.num_medium_risk,
                "low": self.num_low_risk,
                "safe": self.num_safe,
            },
            "total_samples": self.total_samples,
            "high_risk_ratio": self.high_risk_ratio,
        }


@dataclass
class DatasetScore:
    """Complete dataset-level scoring result."""

    num_samples: int
    trait_names: list[str]
    mode: str  # "full" or "raw"

    # Per-trait statistics
    trait_stats: dict[str, TraitStatistics]

    # Correlation between traits
    trait_correlations: dict[tuple[str, str], float] = field(default_factory=dict)

    # High-risk samples per trait
    high_risk_indices: dict[str, list[int]] = field(default_factory=dict)

    # Overall dataset risk assessment
    overall_risk_score: float = 0.0
    risk_summary: str = ""

    # Metadata
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "num_samples": self.num_samples,
            "trait_names": self.trait_names,
            "mode": self.mode,
            "trait_stats": {k: v.to_dict() for k, v in self.trait_stats.items()},
            "trait_correlations": {
                f"{t1}:{t2}": v for (t1, t2), v in self.trait_correlations.items()
            },
            "high_risk_indices": self.high_risk_indices,
            "overall_risk_score": self.overall_risk_score,
            "risk_summary": self.risk_summary,
        }


class DatasetScorer:
    """Computes dataset-level statistics from sample scores.

    Example:
        scorer = DatasetScorer()

        # From projection tensor
        dataset_score = scorer.score_from_projections(
            projections=projection_tensor,
            trait_names=["sycophancy", "evil"],
        )

        # From sample scores
        dataset_score = scorer.score_from_samples(sample_scores)

        print(dataset_score.trait_stats["sycophancy"].high_risk_ratio)
    """

    def __init__(
        self,
        risk_thresholds: dict[str, float] | None = None,
    ):
        """Initialize the scorer.

        Args:
            risk_thresholds: Thresholds for risk levels
        """
        self.risk_thresholds = risk_thresholds or {
            "high": 0.5,
            "medium": 0.2,
            "low": 0.0,
        }

    def score_from_projections(
        self,
        projections: torch.Tensor,
        trait_names: list[str],
        mode: str = "full",
        sample_scores: list[SampleScore] | None = None,
    ) -> DatasetScore:
        """Compute dataset score from projection tensor.

        Args:
            projections: [batch, num_traits] projection values
            trait_names: Names of traits
            mode: Screening mode used
            sample_scores: Optional pre-computed sample scores

        Returns:
            DatasetScore with complete statistics
        """
        num_samples, num_traits = projections.shape
        assert len(trait_names) == num_traits

        # Compute per-trait statistics
        trait_stats = {}
        high_risk_indices = {}

        for j, trait_name in enumerate(trait_names):
            scores = projections[:, j]

            # Risk distribution
            high_mask = scores >= self.risk_thresholds["high"]
            medium_mask = (scores >= self.risk_thresholds["medium"]) & ~high_mask
            low_mask = (scores >= self.risk_thresholds["low"]) & ~high_mask & ~medium_mask
            safe_mask = ~high_mask & ~medium_mask & ~low_mask

            trait_stats[trait_name] = TraitStatistics(
                trait_name=trait_name,
                mean=scores.mean().item(),
                std=scores.std().item(),
                min=scores.min().item(),
                max=scores.max().item(),
                p10=torch.quantile(scores.float(), 0.10).item(),
                p25=torch.quantile(scores.float(), 0.25).item(),
                p50=torch.quantile(scores.float(), 0.50).item(),
                p75=torch.quantile(scores.float(), 0.75).item(),
                p90=torch.quantile(scores.float(), 0.90).item(),
                num_high_risk=high_mask.sum().item(),
                num_medium_risk=medium_mask.sum().item(),
                num_low_risk=low_mask.sum().item(),
                num_safe=safe_mask.sum().item(),
                total_samples=num_samples,
            )

            # Store high-risk indices
            high_risk_indices[trait_name] = high_mask.nonzero().squeeze(-1).tolist()
            if isinstance(high_risk_indices[trait_name], int):
                high_risk_indices[trait_name] = [high_risk_indices[trait_name]]

        # Compute trait correlations
        trait_correlations = self._compute_correlations(projections, trait_names)

        # Overall risk assessment
        overall_score, summary = self._compute_overall_risk(trait_stats)

        return DatasetScore(
            num_samples=num_samples,
            trait_names=trait_names,
            mode=mode,
            trait_stats=trait_stats,
            trait_correlations=trait_correlations,
            high_risk_indices=high_risk_indices,
            overall_risk_score=overall_score,
            risk_summary=summary,
        )

    def score_from_samples(
        self,
        sample_scores: list[SampleScore],
        mode: str = "full",
    ) -> DatasetScore:
        """Compute dataset score from sample scores.

        Args:
            sample_scores: List of per-sample scores
            mode: Screening mode used

        Returns:
            DatasetScore
        """
        if not sample_scores:
            return DatasetScore(
                num_samples=0,
                trait_names=[],
                mode=mode,
                trait_stats={},
            )

        trait_names = list(sample_scores[0].trait_scores.keys())
        num_samples = len(sample_scores)
        num_traits = len(trait_names)

        # Build projection tensor
        projections = torch.zeros(num_samples, num_traits)
        for i, score in enumerate(sample_scores):
            for j, trait_name in enumerate(trait_names):
                projections[i, j] = score.trait_scores.get(trait_name, 0.0)

        return self.score_from_projections(
            projections, trait_names, mode, sample_scores
        )

    def _compute_correlations(
        self,
        projections: torch.Tensor,
        trait_names: list[str],
    ) -> dict[tuple[str, str], float]:
        """Compute pairwise correlations between traits."""
        correlations = {}
        num_traits = len(trait_names)

        # Standardize
        mean = projections.mean(dim=0, keepdim=True)
        std = projections.std(dim=0, keepdim=True)
        standardized = (projections - mean) / (std + 1e-8)

        # Compute correlation matrix
        corr_matrix = (standardized.T @ standardized) / projections.shape[0]

        for i in range(num_traits):
            for j in range(i + 1, num_traits):
                correlations[(trait_names[i], trait_names[j])] = corr_matrix[i, j].item()

        return correlations

    def _compute_overall_risk(
        self,
        trait_stats: dict[str, TraitStatistics],
    ) -> tuple[float, str]:
        """Compute overall dataset risk score and summary.

        Returns:
            (risk_score, summary_text)
        """
        if not trait_stats:
            return 0.0, "No traits analyzed"

        # Aggregate high-risk ratios
        high_risk_ratios = [s.high_risk_ratio for s in trait_stats.values()]
        max_ratio = max(high_risk_ratios)
        avg_ratio = sum(high_risk_ratios) / len(high_risk_ratios)

        # Overall score: weighted combination
        overall_score = 0.7 * max_ratio + 0.3 * avg_ratio

        # Generate summary
        high_risk_traits = [
            name for name, stats in trait_stats.items()
            if stats.high_risk_ratio > 0.1
        ]

        if overall_score > 0.3:
            severity = "HIGH"
        elif overall_score > 0.1:
            severity = "MEDIUM"
        elif overall_score > 0.05:
            severity = "LOW"
        else:
            severity = "MINIMAL"

        if high_risk_traits:
            trait_list = ", ".join(high_risk_traits)
            summary = (
                f"{severity} risk dataset. "
                f"Significant trait-inducing samples detected for: {trait_list}. "
                f"High-risk ratio: {max_ratio:.1%}"
            )
        else:
            summary = f"{severity} risk dataset. No significant trait-inducing samples detected."

        return overall_score, summary


def compute_histogram(
    projections: torch.Tensor,
    num_bins: int = 50,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Compute histogram of projection values.

    Args:
        projections: [batch] or [batch, num_traits]
        num_bins: Number of histogram bins

    Returns:
        (counts, bin_edges)
    """
    if projections.dim() == 2:
        projections = projections.flatten()

    return torch.histogram(projections.float(), bins=num_bins)


def compare_datasets(
    dataset1: DatasetScore,
    dataset2: DatasetScore,
) -> dict[str, Any]:
    """Compare two dataset scores.

    Useful for comparing before/after filtering or different data sources.

    Returns:
        Comparison metrics
    """
    comparison = {
        "num_samples_diff": dataset2.num_samples - dataset1.num_samples,
        "trait_comparisons": {},
    }

    common_traits = set(dataset1.trait_names) & set(dataset2.trait_names)

    for trait in common_traits:
        stats1 = dataset1.trait_stats[trait]
        stats2 = dataset2.trait_stats[trait]

        comparison["trait_comparisons"][trait] = {
            "mean_diff": stats2.mean - stats1.mean,
            "high_risk_diff": stats2.num_high_risk - stats1.num_high_risk,
            "high_risk_ratio_diff": stats2.high_risk_ratio - stats1.high_risk_ratio,
        }

    comparison["overall_risk_diff"] = (
        dataset2.overall_risk_score - dataset1.overall_risk_score
    )

    return comparison
