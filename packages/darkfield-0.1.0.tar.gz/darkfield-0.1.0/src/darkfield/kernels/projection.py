"""Triton kernel for computing projections onto persona vectors.

This kernel efficiently computes the dot product of activation vectors
with a persona vector, which is the core operation for computing:
    projection_i = a_l(x_i, y_i) · v̂_l

where v̂_l is the unit-normalized persona vector at layer l.
"""

import torch
import triton
import triton.language as tl


@triton.jit
def _projection_kernel(
    # Pointers
    activations_ptr,  # [batch, hidden_dim]
    persona_vec_ptr,  # [hidden_dim] - unit normalized
    projections_ptr,  # [batch] - output dot products
    # Dimensions
    batch_size: tl.constexpr,
    hidden_dim: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
):
    """Compute dot product of each activation vector with persona vector.

    Each program instance handles one vector in the batch.
    """
    batch_idx = tl.program_id(0)

    if batch_idx >= batch_size:
        return

    # Accumulate dot product across hidden dimension blocks
    acc = tl.zeros((1,), dtype=tl.float32)

    for block_start in range(0, hidden_dim, BLOCK_SIZE):
        offs = block_start + tl.arange(0, BLOCK_SIZE)
        mask = offs < hidden_dim

        # Load activation and persona vector blocks
        a = tl.load(
            activations_ptr + batch_idx * hidden_dim + offs,
            mask=mask,
            other=0.0,
        )
        v = tl.load(persona_vec_ptr + offs, mask=mask, other=0.0)

        # Accumulate element-wise product
        acc += tl.sum(a * v)

    tl.store(projections_ptr + batch_idx, acc)


@triton.jit
def _batch_projection_kernel(
    # Pointers
    activations_ptr,  # [batch, hidden_dim]
    persona_vecs_ptr,  # [num_vectors, hidden_dim]
    projections_ptr,  # [batch, num_vectors] - output
    # Dimensions
    batch_size: tl.constexpr,
    num_vectors: tl.constexpr,
    hidden_dim: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
):
    """Compute projections onto multiple persona vectors simultaneously.

    Grid: (batch_size, num_vectors)
    Each program handles one (sample, vector) pair.
    """
    batch_idx = tl.program_id(0)
    vec_idx = tl.program_id(1)

    if batch_idx >= batch_size or vec_idx >= num_vectors:
        return

    acc = tl.zeros((1,), dtype=tl.float32)

    for block_start in range(0, hidden_dim, BLOCK_SIZE):
        offs = block_start + tl.arange(0, BLOCK_SIZE)
        mask = offs < hidden_dim

        a = tl.load(
            activations_ptr + batch_idx * hidden_dim + offs,
            mask=mask,
            other=0.0,
        )
        v = tl.load(
            persona_vecs_ptr + vec_idx * hidden_dim + offs,
            mask=mask,
            other=0.0,
        )
        acc += tl.sum(a * v)

    tl.store(projections_ptr + batch_idx * num_vectors + vec_idx, acc)


@triton.jit
def _projection_difference_kernel(
    # Pointers
    activations_training_ptr,  # [batch, hidden_dim] - a_l(x, y)
    activations_natural_ptr,  # [batch, hidden_dim] - a_l(x, y')
    persona_vec_ptr,  # [hidden_dim]
    projection_diff_ptr,  # [batch] - output: (a_training - a_natural) · v
    # Dimensions
    batch_size: tl.constexpr,
    hidden_dim: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
):
    """Compute projection difference in one pass.

    ∆P_i = (a_l(x_i, y_i) - a_l(x_i, y'_i)) · v̂_l

    More efficient than computing two projections and subtracting.
    """
    batch_idx = tl.program_id(0)

    if batch_idx >= batch_size:
        return

    acc = tl.zeros((1,), dtype=tl.float32)

    for block_start in range(0, hidden_dim, BLOCK_SIZE):
        offs = block_start + tl.arange(0, BLOCK_SIZE)
        mask = offs < hidden_dim

        a_train = tl.load(
            activations_training_ptr + batch_idx * hidden_dim + offs,
            mask=mask,
            other=0.0,
        )
        a_nat = tl.load(
            activations_natural_ptr + batch_idx * hidden_dim + offs,
            mask=mask,
            other=0.0,
        )
        v = tl.load(persona_vec_ptr + offs, mask=mask, other=0.0)

        # Compute (a_train - a_natural) · v in one pass
        acc += tl.sum((a_train - a_nat) * v)

    tl.store(projection_diff_ptr + batch_idx, acc)


def compute_projections(
    activations: torch.Tensor,
    persona_vec: torch.Tensor,
) -> torch.Tensor:
    """Compute projection of each activation onto a persona vector.

    Args:
        activations: Activation vectors [batch, hidden_dim]
        persona_vec: Unit-normalized persona vector [hidden_dim]

    Returns:
        Projections [batch] - dot products
    """
    batch_size, hidden_dim = activations.shape
    assert persona_vec.shape == (hidden_dim,), "Persona vector dimension mismatch"

    projections = torch.empty(
        (batch_size,),
        dtype=torch.float32,
        device=activations.device,
    )

    activations = activations.contiguous()
    persona_vec = persona_vec.contiguous().float()

    BLOCK_SIZE = min(1024, triton.next_power_of_2(hidden_dim))

    _projection_kernel[(batch_size,)](
        activations,
        persona_vec,
        projections,
        batch_size=batch_size,
        hidden_dim=hidden_dim,
        BLOCK_SIZE=BLOCK_SIZE,
    )

    return projections


def compute_batch_projections(
    activations: torch.Tensor,
    persona_vecs: torch.Tensor,
) -> torch.Tensor:
    """Compute projections onto multiple persona vectors.

    Args:
        activations: Activation vectors [batch, hidden_dim]
        persona_vecs: Multiple persona vectors [num_vectors, hidden_dim]

    Returns:
        Projections [batch, num_vectors]
    """
    batch_size, hidden_dim = activations.shape
    num_vectors, vec_dim = persona_vecs.shape
    assert vec_dim == hidden_dim, "Dimension mismatch"

    projections = torch.empty(
        (batch_size, num_vectors),
        dtype=torch.float32,
        device=activations.device,
    )

    activations = activations.contiguous()
    persona_vecs = persona_vecs.contiguous().float()

    BLOCK_SIZE = min(1024, triton.next_power_of_2(hidden_dim))

    _batch_projection_kernel[(batch_size, num_vectors)](
        activations,
        persona_vecs,
        projections,
        batch_size=batch_size,
        num_vectors=num_vectors,
        hidden_dim=hidden_dim,
        BLOCK_SIZE=BLOCK_SIZE,
    )

    return projections


def compute_projection_difference(
    activations_training: torch.Tensor,
    activations_natural: torch.Tensor,
    persona_vec: torch.Tensor,
) -> torch.Tensor:
    """Compute projection difference in one efficient pass.

    ∆P = (a_training - a_natural) · v

    Args:
        activations_training: Mean activations for training responses [batch, hidden_dim]
        activations_natural: Mean activations for natural responses [batch, hidden_dim]
        persona_vec: Unit-normalized persona vector [hidden_dim]

    Returns:
        Projection differences [batch]
    """
    batch_size, hidden_dim = activations_training.shape
    assert activations_natural.shape == (batch_size, hidden_dim)
    assert persona_vec.shape == (hidden_dim,)

    projection_diff = torch.empty(
        (batch_size,),
        dtype=torch.float32,
        device=activations_training.device,
    )

    activations_training = activations_training.contiguous()
    activations_natural = activations_natural.contiguous()
    persona_vec = persona_vec.contiguous().float()

    BLOCK_SIZE = min(1024, triton.next_power_of_2(hidden_dim))

    _projection_difference_kernel[(batch_size,)](
        activations_training,
        activations_natural,
        persona_vec,
        projection_diff,
        batch_size=batch_size,
        hidden_dim=hidden_dim,
        BLOCK_SIZE=BLOCK_SIZE,
    )

    return projection_diff


# PyTorch reference implementations for testing
def projection_reference(
    activations: torch.Tensor,
    persona_vec: torch.Tensor,
) -> torch.Tensor:
    """Reference implementation using pure PyTorch."""
    return (activations.float() @ persona_vec.float()).float()


def projection_difference_reference(
    activations_training: torch.Tensor,
    activations_natural: torch.Tensor,
    persona_vec: torch.Tensor,
) -> torch.Tensor:
    """Reference implementation for projection difference."""
    diff = activations_training.float() - activations_natural.float()
    return (diff @ persona_vec.float()).float()
