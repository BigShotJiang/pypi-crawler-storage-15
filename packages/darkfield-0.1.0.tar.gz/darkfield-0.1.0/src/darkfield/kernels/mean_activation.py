"""Triton kernel for computing mean activations over response tokens.

This kernel efficiently computes the mean of hidden state activations
over a variable number of response tokens for each sequence in a batch.
This is critical for the projection difference computation where we need:
    a_l(x_i, y_i) = mean over response tokens of hidden states at layer l
"""

import torch
import triton
import triton.language as tl


@triton.jit
def _mean_activation_kernel(
    # Pointers
    hidden_states_ptr,  # [total_tokens, hidden_dim] - flattened activations
    token_offsets_ptr,  # [batch + 1] - cumulative token counts (CSR format)
    output_ptr,  # [batch, hidden_dim] - mean per sequence
    # Dimensions
    hidden_dim: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
):
    """Compute mean activation over response tokens for each sequence.

    Uses CSR-style offsets to handle variable-length sequences efficiently.
    Each program instance handles one sequence in the batch.
    """
    seq_idx = tl.program_id(0)

    # Load start and end offsets for this sequence
    start = tl.load(token_offsets_ptr + seq_idx)
    end = tl.load(token_offsets_ptr + seq_idx + 1)
    count = end - start

    # Handle empty sequences (shouldn't happen, but be safe)
    if count == 0:
        offs = tl.arange(0, BLOCK_SIZE)
        mask = offs < hidden_dim
        tl.store(output_ptr + seq_idx * hidden_dim + offs, 0.0, mask=mask)
        return

    # Process hidden dimension in blocks
    for block_start in range(0, hidden_dim, BLOCK_SIZE):
        offs = block_start + tl.arange(0, BLOCK_SIZE)
        mask = offs < hidden_dim

        # Accumulate sum over all tokens in this sequence
        acc = tl.zeros((BLOCK_SIZE,), dtype=tl.float32)
        for t in range(start, end):
            h = tl.load(
                hidden_states_ptr + t * hidden_dim + offs,
                mask=mask,
                other=0.0,
            )
            acc += h

        # Compute mean and store
        mean = acc / count.to(tl.float32)
        tl.store(output_ptr + seq_idx * hidden_dim + offs, mean, mask=mask)


@triton.jit
def _mean_activation_kernel_fused(
    # Pointers
    hidden_states_ptr,  # [total_tokens, hidden_dim]
    token_offsets_ptr,  # [batch + 1]
    persona_vec_ptr,  # [hidden_dim] - unit normalized
    projections_ptr,  # [batch] - output projections
    # Dimensions
    hidden_dim: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
):
    """Fused kernel: compute mean activation AND project onto persona vector.

    More efficient than separate mean + projection when we only need the scalar.
    """
    seq_idx = tl.program_id(0)

    start = tl.load(token_offsets_ptr + seq_idx)
    end = tl.load(token_offsets_ptr + seq_idx + 1)
    count = end - start

    if count == 0:
        tl.store(projections_ptr + seq_idx, 0.0)
        return

    # Accumulate projection directly (sum of element-wise products)
    projection_acc = tl.zeros((1,), dtype=tl.float32)

    for block_start in range(0, hidden_dim, BLOCK_SIZE):
        offs = block_start + tl.arange(0, BLOCK_SIZE)
        mask = offs < hidden_dim

        # Load persona vector block
        v = tl.load(persona_vec_ptr + offs, mask=mask, other=0.0)

        # Accumulate mean * persona_vec
        block_sum = tl.zeros((BLOCK_SIZE,), dtype=tl.float32)
        for t in range(start, end):
            h = tl.load(
                hidden_states_ptr + t * hidden_dim + offs,
                mask=mask,
                other=0.0,
            )
            block_sum += h

        # Compute mean for this block and accumulate projection
        mean_block = block_sum / count.to(tl.float32)
        projection_acc += tl.sum(mean_block * v)

    tl.store(projections_ptr + seq_idx, projection_acc)


def compute_mean_activations(
    hidden_states: torch.Tensor,
    token_offsets: torch.Tensor,
    output: torch.Tensor | None = None,
) -> torch.Tensor:
    """Compute mean activations over response tokens for each sequence.

    Args:
        hidden_states: Flattened hidden states [total_tokens, hidden_dim]
        token_offsets: CSR-style offsets [batch + 1] where
            tokens for sequence i are at indices [offsets[i], offsets[i+1])
        output: Optional pre-allocated output tensor [batch, hidden_dim]

    Returns:
        Mean activations [batch, hidden_dim]
    """
    total_tokens, hidden_dim = hidden_states.shape
    batch_size = token_offsets.shape[0] - 1

    if output is None:
        output = torch.empty(
            (batch_size, hidden_dim),
            dtype=hidden_states.dtype,
            device=hidden_states.device,
        )

    # Ensure contiguous tensors
    hidden_states = hidden_states.contiguous()
    token_offsets = token_offsets.contiguous()

    # Choose block size based on hidden dimension
    BLOCK_SIZE = min(1024, triton.next_power_of_2(hidden_dim))

    # Launch kernel
    _mean_activation_kernel[(batch_size,)](
        hidden_states,
        token_offsets,
        output,
        hidden_dim=hidden_dim,
        BLOCK_SIZE=BLOCK_SIZE,
    )

    return output


def compute_mean_and_project(
    hidden_states: torch.Tensor,
    token_offsets: torch.Tensor,
    persona_vec: torch.Tensor,
) -> torch.Tensor:
    """Compute mean activations and project onto persona vector in one pass.

    More efficient when we only need the scalar projection, not the full mean.

    Args:
        hidden_states: Flattened hidden states [total_tokens, hidden_dim]
        token_offsets: CSR-style offsets [batch + 1]
        persona_vec: Unit-normalized persona vector [hidden_dim]

    Returns:
        Projections [batch] - dot product of mean activation with persona vector
    """
    total_tokens, hidden_dim = hidden_states.shape
    batch_size = token_offsets.shape[0] - 1

    projections = torch.empty(
        (batch_size,),
        dtype=torch.float32,
        device=hidden_states.device,
    )

    # Ensure contiguous and correct dtype
    hidden_states = hidden_states.contiguous()
    token_offsets = token_offsets.contiguous()
    persona_vec = persona_vec.contiguous().float()

    BLOCK_SIZE = min(1024, triton.next_power_of_2(hidden_dim))

    _mean_activation_kernel_fused[(batch_size,)](
        hidden_states,
        token_offsets,
        persona_vec,
        projections,
        hidden_dim=hidden_dim,
        BLOCK_SIZE=BLOCK_SIZE,
    )

    return projections


# PyTorch reference implementation for testing
def mean_activation_reference(
    hidden_states: torch.Tensor,
    token_offsets: torch.Tensor,
) -> torch.Tensor:
    """Reference implementation using pure PyTorch for correctness testing."""
    batch_size = token_offsets.shape[0] - 1
    hidden_dim = hidden_states.shape[1]
    output = torch.zeros(
        (batch_size, hidden_dim),
        dtype=hidden_states.dtype,
        device=hidden_states.device,
    )

    for i in range(batch_size):
        start = token_offsets[i].item()
        end = token_offsets[i + 1].item()
        if end > start:
            output[i] = hidden_states[start:end].mean(dim=0)

    return output
