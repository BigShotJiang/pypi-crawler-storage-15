"""GPU accumulator for streaming activation statistics.

Provides CUDA-graph compatible buffers for accumulating
activation statistics during batch processing.
"""

import torch


class GPUAccumulator:
    """Accumulates activation statistics on GPU with pre-allocated buffers.

    Designed for CUDA graph compatibility:
    - All buffers are pre-allocated at initialization
    - Operations are in-place only (no dynamic allocation)
    - Supports reset between screening jobs
    """

    def __init__(
        self,
        num_groups: int,
        hidden_dim: int,
        max_batch_size: int = 1024,
        device: str = "cuda",
        dtype: torch.dtype = torch.float32,
    ):
        """Initialize the accumulator.

        Args:
            num_groups: Number of groups (typically 2: training vs natural)
            hidden_dim: Model hidden dimension
            max_batch_size: Maximum batch size for pre-allocated buffers
            device: Device for buffers
            dtype: Data type for accumulators (use float32 for numerical stability)
        """
        self.num_groups = num_groups
        self.hidden_dim = hidden_dim
        self.max_batch_size = max_batch_size
        self.device = device
        self.dtype = dtype

        # Sum accumulators: [num_groups, hidden_dim]
        self.sum_accumulators = torch.zeros(
            (num_groups, hidden_dim),
            dtype=dtype,
            device=device,
        )

        # Count accumulators: [num_groups]
        self.counts = torch.zeros(num_groups, dtype=torch.int64, device=device)

        # Pre-allocated buffer for group IDs
        self._group_ids_buffer = torch.zeros(
            max_batch_size,
            dtype=torch.int32,
            device=device,
        )

    def reset(self) -> None:
        """Reset all accumulators to zero (in-place)."""
        self.sum_accumulators.zero_()
        self.counts.zero_()

    def accumulate(
        self,
        activations: torch.Tensor,
        group_ids: torch.Tensor,
    ) -> None:
        """Accumulate activations into group sums.

        Args:
            activations: [batch, hidden_dim]
            group_ids: [batch] - group index for each sample (0 to num_groups-1)
        """
        batch_size = activations.shape[0]
        assert batch_size <= self.max_batch_size, "Batch size exceeds pre-allocated buffer"

        # Copy group IDs to pre-allocated buffer (in-place)
        self._group_ids_buffer[:batch_size].copy_(group_ids)

        # Accumulate using scatter_add for each group
        for g in range(self.num_groups):
            mask = self._group_ids_buffer[:batch_size] == g
            group_activations = activations[mask].float()
            if group_activations.shape[0] > 0:
                self.sum_accumulators[g].add_(group_activations.sum(dim=0))
                self.counts[g] += mask.sum()

    def get_means(self) -> torch.Tensor:
        """Compute mean activations per group.

        Returns:
            [num_groups, hidden_dim] tensor of means
        """
        # Avoid division by zero
        safe_counts = self.counts.clamp(min=1).unsqueeze(-1).float()
        return self.sum_accumulators / safe_counts

    def get_count(self, group: int) -> int:
        """Get sample count for a group."""
        return int(self.counts[group].item())

    def get_total_count(self) -> int:
        """Get total samples accumulated."""
        return int(self.counts.sum().item())


class ProjectionAccumulator:
    """Accumulates scalar projections for screening.

    Stores per-sample projection values for later analysis
    (ranking, histograms, filtering).
    """

    def __init__(
        self,
        max_samples: int,
        num_traits: int,
        device: str = "cuda",
    ):
        """Initialize the projection accumulator.

        Args:
            max_samples: Maximum number of samples to track
            num_traits: Number of persona traits being screened
            device: Device for buffers
        """
        self.max_samples = max_samples
        self.num_traits = num_traits
        self.device = device

        # Projection storage: [max_samples, num_traits]
        self.projections = torch.zeros(
            (max_samples, num_traits),
            dtype=torch.float32,
            device=device,
        )

        # Current sample count
        self._count = 0

    def reset(self) -> None:
        """Reset accumulator."""
        self.projections.zero_()
        self._count = 0

    def add_batch(
        self,
        projections: torch.Tensor,
        trait_idx: int | None = None,
    ) -> None:
        """Add a batch of projections.

        Args:
            projections: [batch] for single trait or [batch, num_traits] for all
            trait_idx: If provided, projections is [batch] for this trait only
        """
        batch_size = projections.shape[0]
        start_idx = self._count
        end_idx = start_idx + batch_size

        if end_idx > self.max_samples:
            raise ValueError(f"Exceeds max_samples ({self.max_samples})")

        if trait_idx is not None:
            self.projections[start_idx:end_idx, trait_idx] = projections
        else:
            self.projections[start_idx:end_idx] = projections

        self._count = end_idx

    @property
    def count(self) -> int:
        """Number of samples accumulated."""
        return self._count

    def get_projections(self) -> torch.Tensor:
        """Get all accumulated projections.

        Returns:
            [count, num_traits] tensor
        """
        return self.projections[: self._count]

    def get_statistics(self, trait_idx: int | None = None) -> dict:
        """Compute statistics over accumulated projections.

        Args:
            trait_idx: Specific trait index, or None for all traits

        Returns:
            Dict with mean, std, min, max, percentiles
        """
        projs = self.get_projections()
        if trait_idx is not None:
            projs = projs[:, trait_idx]

        if projs.numel() == 0:
            return {"count": 0}

        return {
            "count": self._count,
            "mean": projs.mean().item() if projs.dim() == 1 else projs.mean(dim=0).tolist(),
            "std": projs.std().item() if projs.dim() == 1 else projs.std(dim=0).tolist(),
            "min": projs.min().item() if projs.dim() == 1 else projs.min(dim=0).values.tolist(),
            "max": projs.max().item() if projs.dim() == 1 else projs.max(dim=0).values.tolist(),
            "percentiles": {
                "p10": torch.quantile(projs.float(), 0.1, dim=0).tolist() if projs.dim() > 1 else torch.quantile(projs.float(), 0.1).item(),
                "p25": torch.quantile(projs.float(), 0.25, dim=0).tolist() if projs.dim() > 1 else torch.quantile(projs.float(), 0.25).item(),
                "p50": torch.quantile(projs.float(), 0.5, dim=0).tolist() if projs.dim() > 1 else torch.quantile(projs.float(), 0.5).item(),
                "p75": torch.quantile(projs.float(), 0.75, dim=0).tolist() if projs.dim() > 1 else torch.quantile(projs.float(), 0.75).item(),
                "p90": torch.quantile(projs.float(), 0.9, dim=0).tolist() if projs.dim() > 1 else torch.quantile(projs.float(), 0.9).item(),
            },
        }

    def get_high_risk_indices(
        self,
        trait_idx: int,
        threshold: float | None = None,
        top_k: int | None = None,
    ) -> torch.Tensor:
        """Get indices of high-risk samples.

        Args:
            trait_idx: Which trait to analyze
            threshold: Return samples above this projection value
            top_k: Return top K highest projections

        Returns:
            Tensor of sample indices, sorted by descending projection
        """
        projs = self.projections[: self._count, trait_idx]

        if threshold is not None:
            mask = projs > threshold
            indices = torch.where(mask)[0]
            # Sort by projection value (descending)
            sorted_idx = projs[indices].argsort(descending=True)
            return indices[sorted_idx]
        elif top_k is not None:
            return projs.argsort(descending=True)[:top_k]
        else:
            # Return all, sorted
            return projs.argsort(descending=True)
