"""Triton GPU kernels for efficient activation processing."""

from darkfield.kernels.mean_activation import (
    compute_mean_activations,
    compute_mean_and_project,
    mean_activation_reference,
)
from darkfield.kernels.projection import (
    compute_projections,
    compute_batch_projections,
    compute_projection_difference,
    projection_reference,
    projection_difference_reference,
)
from darkfield.kernels.accumulator import GPUAccumulator, ProjectionAccumulator

__all__ = [
    # Mean activation
    "compute_mean_activations",
    "compute_mean_and_project",
    "mean_activation_reference",
    # Projection
    "compute_projections",
    "compute_batch_projections",
    "compute_projection_difference",
    "projection_reference",
    "projection_difference_reference",
    # Accumulators
    "GPUAccumulator",
    "ProjectionAccumulator",
]
