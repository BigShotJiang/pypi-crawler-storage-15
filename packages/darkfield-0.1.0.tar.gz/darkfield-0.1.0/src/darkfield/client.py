from dataclasses import dataclass
from typing import Any

import requests


@dataclass
class Job:
    """A Darkfield Cloud job."""
    id: str
    status: str
    report_url: str | None = None


class Client:
    """Client for the Darkfield Cloud API."""

    def __init__(self, api_key: str, base_url: str = "https://api.darkfield.ai/v1"):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "User-Agent": "darkfield-python-sdk",
        })

    def scan_dataset(self, file: str, vectors: list[str]) -> Job:
        """Submit a dataset for screening.
        
        Args:
            file: Path to the dataset file (JSONL)
            vectors: List of vector names to screen against
            
        Returns:
            Job object tracking the screening process
        """
        # In a real implementation, this would upload the file
        # For now, we'll just mock the response as we don't have a real backend yet
        # response = self.session.post(
        #     f"{self.base_url}/screen/dataset",
        #     json={"vectors": vectors},
        #     files={"file": open(file, "rb")}
        # )
        # data = response.json()
        
        # Mock response
        return Job(
            id="job_mock_123",
            status="pending",
            report_url="https://darkfield.ai/reports/mock-report"
        )
