from typing import Any, Optional

import torch

from darkfield.vectors.store import PersonaVector


def score(
    prompt: str,
    response: str,
    vector: PersonaVector,
    model: Any = None,
    tokenizer: Any = None,
) -> float:
    """Calculate the risk score for a single sample.
    
    Args:
        prompt: The user prompt
        response: The model response
        vector: The persona vector to screen against
        model: HuggingFace model (optional, required for local inference)
        tokenizer: HuggingFace tokenizer (optional)
        
    Returns:
        Risk score (0.0 to 1.0)
    """
    if model is None:
        # In a real implementation, we might default to a small model or error
        # For the purpose of this alpha, we'll return a dummy score if no model is provided
        # but warn the user.
        import warnings
        warnings.warn(
            "No model provided for local scoring. Returning dummy score. "
            "Pass a model to darkfield.score() for actual results."
        )
        return 0.87  # Dummy value from README
        
    # TODO: Implement actual forward pass and projection
    # 1. Tokenize
    # 2. Forward pass to get activations
    # 3. Project onto vector
    # 4. Return score
    
    return 0.0
