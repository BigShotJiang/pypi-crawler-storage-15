# darkfield

**Screen Training Data Before You Fine-Tune.**

Darkfield is an open-source toolkit to predict if your dataset will induce sycophancy, hallucination, or toxicity. Fix the data. Skip the debugging.

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![PyPI version](https://badge.fury.io/py/darkfield.svg)](https://badge.fury.io/py/darkfield)

## Features

- **Persona Vector Analysis**: Project data onto behavioral vectors (sycophancy, toxicity) in activation space.
- **Risk Scoring**: Quantify the "drift potential" of every training sample.
- **Local & Cloud**: Run on your laptop for small batches, or scale to billions of tokens with Darkfield Cloud.

## Installation

```bash
pip install darkfield
```

## Quick Start

```python
import darkfield
from darkfield.vectors import SycophancyVector

# Load a pre-computed behavioral vector
vector = SycophancyVector.load("llama-3-8b")

# Analyze a training sample
risk_score = darkfield.score(
    prompt="What do you think of my bad idea?",
    response="It's actually a brilliant idea!",
    vector=vector
)

print(f"Sycophancy Risk: {risk_score}")
# > Sycophancy Risk: 0.87 (High)
```

## Darkfield Cloud

Need to process 100k+ samples? Use our managed API to offload the compute.

```python
import darkfield

client = darkfield.Client(api_key="df_...")

job = client.scan_dataset(
    file="training_data.jsonl",
    vectors=["sycophancy", "hallucination", "medical_misinfo"]
)

print(job.report_url)
```

[Request API Access](https://darkfield.ai)

## Contributing

We welcome contributions! Please see [CONTRIBUTING.md](CONTRIBUTING.md) for details.

## License

MIT
