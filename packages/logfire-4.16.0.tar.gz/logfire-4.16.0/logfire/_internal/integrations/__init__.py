"""Private logic for Logfire integrations."""
