"""Version information for SQLBot."""
__version__ = "2.2.4"


