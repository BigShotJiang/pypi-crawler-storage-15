# changelog


All notable changes to this project will be documented in this file.

## [Unreleased]
- Initial changelog created.

##[0.1.0] 2025-12-07
- First release : basic dashboard generation, CIL, CSV/JSON
export, theming, commit table, and search/pagination features. 