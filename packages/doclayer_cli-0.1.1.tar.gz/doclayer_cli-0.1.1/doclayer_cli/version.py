from __future__ import annotations

# These values can be overridden at build/release time if needed.
VERSION: str = "0.1.1"
COMMIT: str = "dev"
BUILD_DATE: str = "1970-01-01"
