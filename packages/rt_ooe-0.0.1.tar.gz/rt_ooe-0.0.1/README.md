# RT_OOE

RT_OOE is a simple Python package that checks whether a number is Odd or Even.  
It provides a single function `check()` which takes an integer and returns `"Odd"` or `"Even"`.

---

## 📦 Installation

Install the package from PyPI using:

