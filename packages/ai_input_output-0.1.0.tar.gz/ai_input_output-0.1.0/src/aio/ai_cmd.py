#!/usr/bin/env python3
import sys, os, argparse, json, re, subprocess, signal, time, platform
from litellm import completion

##############################################
# ANSI color codes
##############################################
class Colors:
    RESET = '\033[0m'
    BOLD = '\033[1m'
    DIM = '\033[2m'
    
    # Foreground colors
    RED = '\033[31m'
    GREEN = '\033[32m'
    YELLOW = '\033[33m'
    BLUE = '\033[34m'
    MAGENTA = '\033[35m'
    CYAN = '\033[36m'
    WHITE = '\033[37m'
    
    # Bright colors
    BRIGHT_RED = '\033[91m'
    BRIGHT_GREEN = '\033[92m'
    BRIGHT_YELLOW = '\033[93m'
    BRIGHT_BLUE = '\033[94m'
    BRIGHT_MAGENTA = '\033[95m'
    BRIGHT_CYAN = '\033[96m'

##############################################
# Output helpers
##############################################
def err(*args, color='', **kwargs):
    """Write to stderr with optional color."""
    if color:
        print(f"{color}{args[0]}{Colors.RESET}", *args[1:], file=sys.stderr, **kwargs)
    else:
        print(*args, file=sys.stderr, **kwargs)

def out(*args, color='', **kwargs):
    """Write to stdout with optional color."""
    if color:
        print(f"{color}{args[0]}{Colors.RESET}", *args[1:], **kwargs)
    else:
        print(*args, **kwargs)

##############################################
# Default config values
##############################################

def get_system_prompt(input_lines, input_chars, output_lines, output_chars, interactive=True, system_info=""):
    """Generate system prompt with actual truncation limits and mode-specific guidance."""
    
    # Base prompt (both modes)
    base = (
        f"You are an AI assistant operating in a terminal environment.\n"
        f"System: {system_info}\n"
        f"Your role is to help users accomplish tasks by providing shell commands when appropriate.\n"
        f"\nContext Awareness:"
        f"\n- Input buffers/files are truncated to {input_lines} lines / {input_chars} chars before being sent to you"
        f"\n- When buffers are truncated, note this and work with available information"
        f"\n\nGuidelines:"
        f"\n- For file/data operations: provide the necessary bash commands rather than explaining what to do"
        f"\n- For general knowledge questions or tasks requiring explanation: answer directly without commands"
        f"\n- For intermediate/temporary files: use /tmp directory unless user specifies otherwise"
        f"\n- Consider command safety - mention if a command modifies/deletes files"
        f"\n- Be concise and practical in your responses"
    )
    
    if interactive:
        # Interactive mode: user can execute commands and continue conversation
        interactive_addition = (
            f"\n- Command outputs are truncated to {output_lines} lines / {output_chars} chars when sent back to you"
            f"\n- User manually executes commands you suggest - they are not auto-executed"
            f"\n- After execution, command output is sent back to you for analysis"
            f"\n\nCommand Generation Rules:"
            f"\n- Provide exactly ONE command block unless multiple sequential steps are truly necessary"
            f"\n- Maximum 3 commands total (only for complex multi-step tasks)"
            f"\n- Each command must be in a separate ```bash code block"
            f"\n- Start each block with a # comment explaining what the command does"
            f"\n- Users can execute commands by typing the number (1, 2, or 3)"
            f"\n\nRequired format:"
            f"\n```bash"
            f"\n# Clear explanation of what this command does"
            f"\nactual command here"
            f"\n```"
            f"\n\nThis format is parsed automatically - follow it exactly."
        )
        return base + interactive_addition
    else:
        # Non-interactive mode: one-shot interaction
        exec_addition = (
            f"\n\nExecution Mode:"
            f"\n- This is a one-shot interaction - the user cannot respond or execute commands after your response"
            f"\n- When appropriate, provide commands in ```bash code blocks with # comment explanations"
            f"\n- Generate commands for: data processing, file operations, log analysis, text manipulation"
            f"\n- Provide direct answers for: general knowledge, explanations, summaries, questions requiring reasoning"
            f"\n- Common use cases: analyzing logs, parsing JSON/HTML/CSV files, processing large text files"
        )
        return base + exec_addition

##############################################
# CLI argument parsing
##############################################

def parse_bash_commands(text):
    """Extract bash code blocks from markdown text with explanations.
    
    Returns:
        list of tuples: [(explanation, command), ...]
    """
    pattern = r'```bash\s*\n(.*?)\n```'
    matches = re.findall(pattern, text, re.DOTALL)
    
    results = []
    for match in matches[:5]:  # Max 5 commands
        lines = match.strip().split('\n')
        explanation = ""
        command_lines = []
        
        for line in lines:
            stripped = line.strip()
            if stripped.startswith('#'):
                # Extract explanation from comment
                if not explanation:
                    explanation = stripped[1:].strip()
            else:
                command_lines.append(line)
        
        command = '\n'.join(command_lines).strip()
        if command:
            if not explanation:
                explanation = "Execute command"  # Default if no explanation provided
            results.append((explanation, command))
    
    return results

def truncate_buffer(raw_buffer, max_lines, max_chars, filename=None):
    """
    Truncate buffer to specified limits and return truncated buffer with info.
    
    Returns:
        tuple: (truncated_buffer, info_string)
    """
    if not raw_buffer.strip():
        return None, ""
    
    lines = raw_buffer.splitlines()
    original_lines = len(lines)
    original_chars = len(raw_buffer)
    
    truncated_lines = lines[:max_lines]
    truncated_text = "\n".join(truncated_lines)
    truncated_text = truncated_text[:max_chars]
    
    truncated_lines_count = len(truncated_text.splitlines())
    truncated_chars_count = len(truncated_text)
    
    # Build info string
    info = ""
    if filename:
        info = f"File: {filename}, "
    
    if original_lines != truncated_lines_count or original_chars != truncated_chars_count:
        info += f"truncated from {original_lines} lines / {original_chars} chars to {truncated_lines_count} lines / {truncated_chars_count} chars"
    else:
        info += f"{truncated_lines_count} lines / {truncated_chars_count} chars"
    
    return truncated_text, info

def main_wrapper():

    parser = argparse.ArgumentParser(
        description="AI terminal helper using OpenRouter + litellm. "
                    "Reads stdin optionally, summarizes or processes content."
    )

    parser.add_argument("-m", "--model", type=str,
                        help="Model name (default env AIO_MODEL_NAME or openrouter/openai/gpt-5-nano)")

    parser.add_argument("-n", "--lines", type=int,
                        help=f"Max preview lines (default 50)")

    parser.add_argument("-c", "--chars", type=int,
                        help=f"Max preview characters (default 2000)")

    parser.add_argument("-f", "--file", type=str,
                        help="Read input from file instead of stdin")

    parser.add_argument("-d", "--dry-run", action="store_true",
                        help="Show what would be sent to litellm without making the API call")

    parser.add_argument("-e", "--exec", action="store_true",
                        help="Non-interactive mode: execute once and exit (for pipes)")

    parser.add_argument("instruction", nargs="*", help="Instruction text (if none & stdin/file present, summarize buffer)")

    args = parser.parse_args()

    ##############################################
    # Determine model
    ##############################################
    model = args.model or os.getenv("AIO_MODEL_NAME") or "openrouter/anthropic/claude-sonnet-4.5"

    ##############################################
    # Read from file or stdin if present
    ##############################################
    raw_buffer = ""
    stdin_was_piped = False
    if args.file:
        try:
            with open(args.file, 'r') as f:
                raw_buffer = f.read()
        except Exception as e:
            err(f"[ai_cmd] Error reading file: {e}", color=Colors.RED)
            sys.exit(1)
    elif not sys.stdin.isatty():
        raw_buffer = sys.stdin.read()
        stdin_was_piped = True
    
    # Auto-enable exec mode if stdin was piped (stdin consumed, can't be interactive)
    if stdin_was_piped:
        args.exec = True

    ##############################################
    # Determine truncation limits
    ##############################################
    max_lines = args.lines
    max_chars = args.chars

    ##############################################
    # Prepare buffer if present
    ##############################################
    buffer, buffer_info = truncate_buffer(raw_buffer, max_lines, max_chars, args.file)
    
    # Display buffer info to stderr if we have a buffer
    if buffer_info:
        err(f"[ai_cmd] {buffer_info}", color=Colors.DIM)

    ##############################################
    # Determine instruction behavior
    ##############################################
    if buffer and not args.instruction:
        # Has buffer, no instruction: summarize
        instruction = "Provide a quick summary of the provided buffer."
    elif args.instruction:
        # Has instruction
        instruction = " ".join(args.instruction)
    elif buffer:
        # Has buffer with instruction (already handled above)
        pass
    else:
        # No buffer, no instruction: get first message from user
        instruction = None

    ##############################################
    # Build initial message (if we have an instruction)
    ##############################################
    if instruction:
        user_message = instruction.strip()
        if buffer:
            # Add buffer to user message with info
            user_message += "\n\nBUFFER"
            if args.file:
                user_message += f" (from file: {args.file})"
            user_message += ":\n" + buffer.strip()
            user_message += f"\n\n({buffer_info})"
    else:
        # No initial message, will prompt user in interactive mode
        user_message = None


    ##############################################
    # Call OpenRouter using litellm with streaming
    ##############################################
    
    # Detect system information
    system_os = platform.system()
    system_arch = platform.machine()
    system_shell = os.path.basename(os.environ.get('SHELL', 'cmd' if system_os == 'Windows' else 'sh'))
    system_cwd = os.getcwd()
    system_info = f"OS:{system_os} Arch:{system_arch} Shell:{system_shell} CWD:{system_cwd}"
    
    # Display system info to user
    err(f"[ai_cmd] System: {system_info}", color=Colors.DIM)
    
    # Calculate output limits (defaults: 256 lines / 4096 chars)
    output_max_lines = args.lines
    output_max_chars = args.chars
    
    # Initialize conversation history with appropriate system prompt
    system_prompt = get_system_prompt(
        max_lines, max_chars, 
        output_max_lines, output_max_chars,
        interactive=not args.exec,
        system_info=system_info
    )
    
    messages = [{"role": "system", "content": system_prompt}]
    
    # Track available commands for execution in interactive mode
    available_commands = {}
    
    # Add initial user message if we have one
    if user_message:
        messages.append({"role": "user", "content": user_message})
    
    # If dry-run, just print the parameters and exit
    if args.dry_run:
        dry_run_output = {
            "model": model,
            "messages": messages,
            "stream": True
        }
        print(json.dumps(dry_run_output, indent=2))
        sys.exit(0)
    
    try:
        # Control-C interrupt tracking
        interrupt_count = 0
        last_interrupt_time = 0
        
        def signal_handler(sig, frame):
            nonlocal interrupt_count, last_interrupt_time
            current_time = time.time()
            
            # Reset interrupt count if it's been a while since last interrupt
            if current_time - last_interrupt_time > 2:
                interrupt_count = 0
            
            interrupt_count += 1
            last_interrupt_time = current_time
            
            if interrupt_count >= 2:
                err("\n[Exiting...]", color=Colors.YELLOW)
                sys.exit(0)
            else:
                err("\n[Interrupted - press Ctrl+C again to exit, or continue typing]", color=Colors.YELLOW)
                raise KeyboardInterrupt()
        
        signal.signal(signal.SIGINT, signal_handler)
        
        # Show welcome message in interactive mode (only if no initial user message)
        if not args.exec and not user_message:
            err("AI Terminal Assistant", color=Colors.BRIGHT_CYAN)
            err("Type your request, execute commands by number (1-3), type '/reset' to clear chat, or Ctrl+C twice to exit", color=Colors.DIM)
        
        # Interactive conversation loop
        while True:
            # Get user input if we don't have a pending user message
            last_message_role = messages[-1]["role"] if len(messages) > 1 else "system"
            if last_message_role != "user":
                try:
                    # Show available commands if any
                    if available_commands and not args.exec:
                        err(f"[Commands available: {', '.join(available_commands.keys())}]", color=Colors.YELLOW)
                    
                    prompt_color = Colors.BRIGHT_BLUE if last_message_role == "assistant" else Colors.BLUE
                    err("> " if last_message_role == "assistant" else "> ", color=prompt_color, end='')
                    user_input = input()
                    
                    # Reset interrupt count on successful input
                    interrupt_count = 0
                    
                    if not user_input.strip():
                        continue
                    
                    # Check for /reset command
                    if user_input.strip() == "/reset":
                        messages = [{"role": "system", "content": system_prompt}]
                        available_commands = {}
                        err("[Chat reset]", color=Colors.GREEN)
                        continue
                    
                    # Check if user wants to execute a command (in interactive mode)
                    if not args.exec and user_input.strip() in available_commands:
                        cmd_num = user_input.strip()
                        explanation, command = available_commands[cmd_num]
                        
                        err(f"[Executing command {cmd_num}]", color=Colors.BRIGHT_CYAN)
                        err(f"# {explanation}", color=Colors.DIM)
                        err(command, color=Colors.CYAN)
                        
                        # Execute the command
                        try:
                            result = subprocess.run(
                                command,
                                shell=True,
                                capture_output=True,
                                text=True,
                                timeout=60
                            )
                            
                            output = result.stdout
                            if result.stderr:
                                output += "\nSTDERR:\n" + result.stderr
                            
                            exit_color = Colors.GREEN if result.returncode == 0 else Colors.RED
                            err(f"[Exit code: {result.returncode}]", color=exit_color)
                            out(output)
                            
                            # Truncate output for LLM context to avoid token overflow
                            # Use same limits as defined earlier
                            truncated_output, output_info = truncate_buffer(
                                output, 
                                max_lines=output_max_lines,
                                max_chars=output_max_chars
                            )
                            
                            if output_info and "truncated" in output_info:
                                err(f"[Output truncated for LLM context: {output_info}]", color=Colors.DIM)
                            
                            # Add execution record to conversation history with truncated output
                            exec_record = f"User executed command {cmd_num}:\n{command}\n\nOutput:\n{truncated_output or output}"
                            if result.returncode != 0:
                                exec_record += f"\n\nExit code: {result.returncode}"
                            
                            messages.append({"role": "user", "content": exec_record})
                            
                        except subprocess.TimeoutExpired:
                            err("[Command timed out after 60 seconds]", color=Colors.RED)
                            messages.append({"role": "user", "content": f"User executed command {cmd_num}:\n{command}\n\nError: Command timed out"})
                        except Exception as e:
                            err(f"[Execution error: {e}]", color=Colors.RED)
                            messages.append({"role": "user", "content": f"User executed command {cmd_num}:\n{command}\n\nError: {e}"})
                        
                        continue  # Don't send to LLM yet, wait for next user input
                    
                    messages.append({"role": "user", "content": user_input})
                except KeyboardInterrupt:
                    # Handled by signal handler
                    continue
                except EOFError:
                    err()
                    break
            
            # Prepare call parameters
            call_params = {
                "model": model,
                "messages": messages,
                "stream": True
            }
            
            # Get assistant response
            response = completion(**call_params)
            assistant_message = ""
            
            try:
                for chunk in response:
                    # Print content as it streams
                    if hasattr(chunk, 'choices') and len(chunk.choices) > 0:  # type: ignore
                        delta = chunk.choices[0].delta  # type: ignore
                        if hasattr(delta, 'content') and delta.content:
                            print(delta.content, end='', flush=True)
                            assistant_message += delta.content
            except KeyboardInterrupt:
                err("\n[Response interrupted]", color=Colors.YELLOW)
                # Continue with whatever partial message we got
                if not assistant_message:
                    continue  # Skip if we got nothing
            
            print()  # Final newline
            
            # Add assistant response to conversation history
            messages.append({"role": "assistant", "content": assistant_message})
            
            # Parse bash commands from response (interactive mode only)
            if not args.exec:
                commands = parse_bash_commands(assistant_message)
                available_commands = {str(i+1): cmd_tuple for i, cmd_tuple in enumerate(commands)}
                if available_commands:
                    err("\n[Available commands:]", color=Colors.BRIGHT_GREEN)
                    for num, (explanation, cmd) in available_commands.items():
                        # Show explanation and command preview
                        cmd_preview = cmd.split('\n')[0][:60]
                        if len(cmd.split('\n')[0]) > 60 or '\n' in cmd:
                            cmd_preview += "..."
                        err(f"  {num}: {explanation}", color=Colors.GREEN)
                        err(f"     {cmd_preview}", color=Colors.DIM)
            
            # Exit if in exec mode
            if args.exec:
                break
            
    except Exception as e:
        err(f"[ai_cmd] Error: {e}", color=Colors.RED)
        raise e

if __name__ == "__main__":
    main_wrapper()