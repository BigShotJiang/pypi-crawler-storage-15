"""
UI package for StatsMan
Manual terminal UI implementation
"""