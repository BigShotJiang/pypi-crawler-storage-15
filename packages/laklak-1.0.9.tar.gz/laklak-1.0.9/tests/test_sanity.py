# Minimal smoke test to ensure pytest collects at least one test in CI
def test_sanity():
    assert True
