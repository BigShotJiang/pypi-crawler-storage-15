"""
Tests for Sybil add-ons.
"""
