"""
Tests for custom Markdown parsers.
"""
