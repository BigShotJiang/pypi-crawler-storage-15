"""
FastAPI Service Module

This module provides the FastAPI service functionality.
"""

# CRITICAL: Suppress deprecation warnings BEFORE any imports
# This must be the very first thing in the file to catch warnings emitted during importlib bootstrap
import warnings

# Set default action for DeprecationWarnings to ignore BEFORE any imports
# This catches warnings emitted during importlib bootstrap (e.g., SWIG warnings)
warnings.simplefilter("ignore", DeprecationWarning)

# Now we can safely import other modules
import os
import signal
import sys
import asyncio
import logging
from pathlib import Path
import uvicorn

from topaz_agent_kit.services.fastapi_app import create_app
from topaz_agent_kit.utils.logger import Logger
from topaz_agent_kit.core.exceptions import ConfigurationError


def main(project_dir: str, log_level: str | None = None, ui_dist: str | None = None, reload: bool = False) -> None:
    """Start FastAPI service."""
    logger = Logger("ServeFastAPI")
    logger.info("Starting FastAPI service")
    
    # Apply log level if specified
    if log_level:
        try:
            Logger.set_global_level_from_string(log_level)
            logger.info("Log level set to: {}", log_level)
        except Exception as e:
            logger.warning("Failed to set log level to {}: {}", log_level, e)
    
    logger.info("Using provided project directory: {}", project_dir)
    
    # Optional UI dist override via argument or env TOPAZ_UI_DIST_DIR
    ui_dist_dir = ui_dist or os.environ.get("TOPAZ_UI_DIST_DIR")
    app = create_app(project_dir, ui_dist_dir)
    logger.debug("FastAPI app created successfully")
    
    # Load pipeline.yml to get FastAPI URL
    try:
        import yaml
        from urllib.parse import urlparse
        pipeline_file = Path(project_dir) / "config" / "pipeline.yml"
        with open(pipeline_file, 'r') as f:
            config = yaml.safe_load(f)
        
        fastapi_url = config["servers"]["fastapi"]["url"]
        parsed_url = urlparse(fastapi_url)
        
        # Use configuration values
        server_host = parsed_url.hostname
        server_port = parsed_url.port
        
        # Validate required parameters
        if not server_host:
            raise ConfigurationError("FastAPI host must be specified in pipeline.yml")
        if not server_port:
            raise ConfigurationError("FastAPI port must be specified in pipeline.yml")
        
        logger.info("Starting server on {}:{}", server_host, server_port)
        
        # SSL configuration - always try to use HTTPS
        ssl_keyfile = None
        ssl_certfile = None
        
        # Look for SSL certificates in multiple locations (project directory first)
        possible_paths = [
            Path(project_dir) / "localhost.key",        # Project directory (where init creates them)
            Path.cwd() / "localhost.key",               # Current working directory
            Path(project_dir).parent.parent / "localhost.key",  # Go up two levels from project to topaz-agent-kit root
            Path(__file__).parent.parent.parent / "localhost.key",  # Topaz root from this file
        ]
        
        ssl_key_path = None
        ssl_cert_path = None
        
        for key_path in possible_paths:
            cert_path = key_path.with_suffix('.crt')
            if key_path.exists() and cert_path.exists():
                ssl_key_path = key_path
                ssl_cert_path = cert_path
                break
        
        if ssl_key_path and ssl_cert_path:
            ssl_keyfile = str(ssl_key_path)
            ssl_certfile = str(ssl_cert_path)
            logger.info("HTTPS enabled with certificates: {} and {}", ssl_certfile, ssl_keyfile)
        else:
            logger.warning("SSL certificates not found in any of these locations:")
            for path in possible_paths:
                logger.warning("  - {} (cert: {})", path, path.with_suffix('.crt'))
            logger.warning("Falling back to HTTP - Visual Editor OPFS will not work")
            logger.info("Tip: Run 'topaz-agent-kit init' to generate SSL certificates automatically")
        
    except Exception as e:
        logger.error("Failed to load FastAPI configuration: {}", e)
        raise ConfigurationError(f"Failed to load FastAPI configuration: {e}")
    
    # Suppress noisy shutdown errors and warnings
    import warnings
    warnings.filterwarnings("ignore", category=DeprecationWarning)
    
    # Suppress asyncio cancellation errors during shutdown
    asyncio_logger = logging.getLogger("asyncio")
    asyncio_logger.setLevel(logging.CRITICAL)
    
    # Add a logging filter to suppress shutdown-related errors
    class ShutdownErrorFilter(logging.Filter):
        """Filter out shutdown-related error messages"""
        def filter(self, record):
            msg = record.getMessage() if hasattr(record, 'getMessage') else str(record.msg)
            # Suppress cancellation and shutdown errors
            suppress_keywords = [
                "CancelledError",
                "KeyboardInterrupt", 
                "WouldBlock",
                "lifespan",
                "Exception in ASGI application"
            ]
            return not any(keyword in msg for keyword in suppress_keywords)
    
    # Apply filter to uvicorn and starlette loggers
    shutdown_filter = ShutdownErrorFilter()
    logging.getLogger("uvicorn.error").addFilter(shutdown_filter)
    logging.getLogger("uvicorn").addFilter(shutdown_filter)
    logging.getLogger("starlette").addFilter(shutdown_filter)
    
    # Suppress tracebacks for shutdown-related exceptions
    original_excepthook = sys.excepthook
    
    def graceful_excepthook(exc_type, exc_value, exc_traceback):
        """Suppress tracebacks for shutdown-related exceptions"""
        # Suppress KeyboardInterrupt and CancelledError tracebacks
        if exc_type in (KeyboardInterrupt, SystemExit):
            return
        # Check if it's a CancelledError (from asyncio)
        if exc_type.__name__ == "CancelledError":
            return
        # For other exceptions, use the original handler
        original_excepthook(exc_type, exc_value, exc_traceback)
    
    sys.excepthook = graceful_excepthook
    
    try:
        if reload:
            # For reload to work, we need to use import string instead of app object
            logger.info("Starting with hot reload enabled")
            uvicorn.run(
                "topaz_agent_kit.services.fastapi_app:create_app",
                host=server_host, 
                port=server_port, 
                reload=True,
                ssl_keyfile=ssl_keyfile,
                ssl_certfile=ssl_certfile,
                log_level="info"
            )
        else:
            config = uvicorn.Config(
                app,
                host=server_host,
                port=server_port,
                ssl_keyfile=ssl_keyfile,
                ssl_certfile=ssl_certfile,
                log_level="info",
                access_log=False  # Reduce noise
            )
            server = uvicorn.Server(config)
            
            try:
                server.run()
            except (KeyboardInterrupt, SystemExit):
                logger.info("Shutdown requested, exiting gracefully...")
            except Exception as e:
                # Suppress cancellation errors during shutdown
                error_name = type(e).__name__
                if error_name not in ("CancelledError", "KeyboardInterrupt", "SystemExit"):
                    logger.error("Unexpected error: {}", e)
                    raise
                # For cancellation errors, just exit silently
                pass
    except (KeyboardInterrupt, SystemExit):
        logger.info("Shutdown requested, exiting gracefully...")
    except Exception as e:
        # Suppress shutdown-related errors
        error_name = type(e).__name__
        if error_name not in ("CancelledError", "KeyboardInterrupt", "SystemExit"):
            logger.error("Failed to start server: {}", e)
            raise


if __name__ == "__main__":  # pragma: no cover
    main()

