"""
Essential Brian modules, in particular base classes for all kinds of brian
objects.

Built-in preferences
--------------------
.. document_brian_prefs:: core

"""
