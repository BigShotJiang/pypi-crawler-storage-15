double foo(const double, const double);
