Detailed Brian 1 to Brian 2 conversion notes
============================================

These documents are only relevant for former users of Brian 1. If you do not
have any Brian 1 code to convert, go directly to the main
:doc:`../../user/index`.

.. toctree::
   :maxdepth: 1
   :titlesonly:

   container
   neurongroup
   synapses
   inputs
   monitors
   networks_and_clocks
   preferences
   multicompartmental
   library
   brian1hears_bridge
