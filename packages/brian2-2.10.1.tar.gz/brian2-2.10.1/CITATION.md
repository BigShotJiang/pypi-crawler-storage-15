If you use Brian for your published research, we kindly ask you to cite our article:

Stimberg, M, Brette, R, Goodman, DFM.
“Brian 2, an Intuitive and Efficient Neural Simulator.”
eLife 8 (2019): e47314.
doi: [10.7554/eLife.47314](https://doi.org/10.7554/eLife.47314).
