These are Brian scripts corresponding to the following paper:

Brette R (2013). Sharpness of spike initiation in neurons explained by compartmentalization.
PLoS Comp Biol, doi: 10.1371/journal.pcbi.1003338.

params.py   contains model parameters

Essential figures from the paper:
Fig1.py
Fig3AB.py
Fig3CD.py
Fig4.py
Fig5A.py
