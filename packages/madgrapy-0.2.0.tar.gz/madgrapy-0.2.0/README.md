# MadGraPy

A simple Python interface to run MadGraph

# How to use this module 

Requirements:
- Python 3.6+
- MadGraph 3.6+
- AND Python 2.7 (for MadDM compatibility)
- AND MadGraph 2.9 (for MadDM compatibility)
- ghostscript (on Ubuntu: `sudo apt-get install ghostscript`)

## (Optional) Create a virtual env

```sh
python3 -m venv my_virtualenv
source my_virtualenv/bin/activate
```

## Install with pip

```sh
pip install madgrapy
```

## (optional) Install [madgraph from its GitHub](https://github.com/mg5amcnlo/mg5amcnlo.git)
If you don't have already madgraph installed, you can do it by the following:

```sh
git clone https://github.com/mg5amcnlo/mg5amcnlo.git
cd mg5amcnlo
git switch 3.x
rm -rf bin/*.py
```
Test it with
``` 
./mg5amcnlo/bin/mg5_aMC
```

## How to run a simple process

You can find a example Jupyter notebook inside the `notebooks` folder. 
To generate a simple script and run it, you can do

``` py
from madgrapy import madpy_generate_script, madpy_run

# Write the script
full_script_str, mg5_script_path, workdir_process = madpy_generate_script(process = "p p > t t~", models = "sm", process_name="my_first_mg5run")

# Run
mg5_script_complete_path = madpy_run(madgraph_path="/path/to/madgraph/folder", process_name = "my_first_mg5run", mg5_script_folder_path = f".")
```