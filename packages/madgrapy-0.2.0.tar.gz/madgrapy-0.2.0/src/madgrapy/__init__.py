from dataclasses import dataclass
import pandas as pd
import tarfile
import os
import subprocess
from subprocess import Popen, PIPE, CalledProcessError
from pathlib import Path
import sys
from pathlib import Path

ENV = os.environ.copy()

def madpy_generate_script(process: str = "p p > t t~ j",
                          models: str | list = "sm",
                          masses: dict | None = None,
                          coupling: dict | None = None,
                          decays: dict | None = None,
                          pt_cut: dict | None = None,
                          madspin: bool = False,
                          number_events: int = 1000,
                          process_name: str = "new_process",
                          workdir_path: str = "./workdir",
                          coupled_scan: bool = True,
                          draw_diagrams: bool = True,
                          beam_energy1: float = 6000,
                          beam_energy2: float = 6000,
                          beam_type1: str = "proton",
                          beam_type2: str = "proton",
                          lhapdf_id: int = 315000) -> tuple[str, str, str]:
    """
    Generate a MadGraph5 script for a given process, model, and settings.

    Parameters
    ----------
    process (str), default `p p > t t~ j` : The process to generate, e.g. "p p > t t~ j"
    models (str), default `sm` : The model to use, e.g. "sm"
    masses (dict | None), optional, default `None` : A dictionary of particle names to their masses, e.g. {"t": 1.777}
    coupling (dict | None), optional, default `None` : A dictionary of coupling names to their values, e.g. {"g": 2.0}
    decays (dict | None), optional, default `None` : A dictionary of decay names to their widths, e.g. {"t > b mu+ mu-": 1.5}
    pt_cut (dict | None), optional, default `None` : A dictionary of particle names to their pt cuts, e.g. {"t": 10.0}
    madspin (bool) optional, default `False` : Whether to use madspin or not
    number_events (int), default `1000` : The number of events to generate
    process_name (str), default `new_process` : The name of the process, e.g. "new_process"
    workdir_path (str), default `./workdir` : The path to the working directory
    coupled_scan (bool) : Whether to use coupled scans or not
    draw_diagrams (bool), default `True` : Whether to draw diagrams or not
    beam_energy1 (float) : The energy of the first beam
    beam_energy2 (float) : The energy of the second beam
    beam_type1 : str, detault `proton` 
        The type of the first beam.
        Options are `proton`, `antiproton`, `electron`, `positron`, `muon`, `antimuon`, `foton` or `None`.
    beam_type2 : str, default `proton` 
        The type of the first beam.
        Options are `proton`, `antiproton`, `electron`, `positron`, `muon`, `antimuon`, `foton` or `None`.
    pdfset : str, default `NNPDF31_lo_as_0118`
        The PDF set to use.

    Returns
    -------
    tuple[str, str, str]: A tuple containing the generated MadGraph5 script, the process name, and the working directory path
    """
    workdir_process = f"{workdir_path}/{process_name}"
    Path(f"{workdir_process}").mkdir(parents=True, exist_ok=True)
    # Path(f"{workdir_process}/diagrams").mkdir(parents=True, exist_ok=True)

    # First part of  the script
    mg5_script = ""

    if isinstance(models, str):
        models = [models]
    else:
        pass

    for model_name in models:
        mg5_script += f"""\n import model {model_name}"""

    mg5_script += f"""\n generate {process}"""
    mg5_script += f"""\n output {workdir_process} -f"""
    mg5_script += f"""\n display diagrams {workdir_process}"""
    mg5_script += f"""\n launch {workdir_process}"""

    if masses:
        for particle, mass in masses.items():
            mg5_script += "\n\t" + f"""set mass {particle} {mass}"""

    if coupling:
        for coup, value in coupling.items():
            mg5_script += "\n\t" + f"""set DMINPUTS {coup} {value}"""

    if decays:
        for decay, value in decays.items():
            mg5_script += "\n\t" + f"""set width {decay} {value}"""

    if pt_cut:
        for pt, cut in pt_cut.items():
            mg5_script += "\n\t" + f"""set {pt} {cut}"""

    if madspin:
        mg5_script += "\n\t" + f"""madspin=ON"""
    else:
        pass
        # mg5_script += "\n\t" + f"""madspin=OFF"""

    # Set number of events
    mg5_script += "\n\t" + f"""set nevents {number_events}"""

    # Set Energy Beam
    beam_type_dict = {"proton": 1,
                      "antiproton": -1,
                      "electron": 3,
                      "positron": -3,
                      "muon": 4,
                      "antimuon": -4,
                      "foton": 2,
                      "None": 0}

    mg5_script += "\n\t" + f"""set run_card ebeam1 = {beam_energy1}"""
    mg5_script += "\n\t" + f"""set run_card ebeam2 = {beam_energy2}"""
    mg5_script += "\n\t" + \
        f"""set run_card lpp1 = {beam_type_dict[beam_type1]}"""
    mg5_script += "\n\t" + \
        f"""set run_card lpp2 = {beam_type_dict[beam_type2]}"""

    mg5_script += "\n\t" + f"""set run_card pdlabel = LHAPDF"""
    mg5_script += "\n\t" + f"""set run_card lhaid = {lhapdf_id}"""

    # TODO: Implement this
    # mg5_script += "\n\t" + f"""set run_card pdlabel = {pdfset}"""
    # mg5_script += "\n\t" + f"""set run_card bwcutoff = 150"""
    # mg5_script += "\n\t" + f"""set run_card pta = 60"""      # minimum pt for the photons
    # mg5_script += "\n\t" + f"""set run_card ptamax = 1000"""   # maximum pt for the photons

    with open(process_name + ".mg5", "w") as script_file:
        # Write the string into the .mg5 file
        script_file.write(mg5_script)

    print("MG5 script generated")
    print("======================")
    print(mg5_script)

    return mg5_script, process_name, workdir_process


def madpy_run(madgraph_path: str = "./madgraph",
              process_name: str = "new_process",
              mg5_script_folder_path: str = ".",
              mg5_bin: str = "mg5_aMC") -> str:
    """
    This will call MG5 and run the created script

    Args:
        madgraph_path (str): Path to the madgraph folder
        process_name (str): Name of the process
        mg5_script_folder_path (str): Path to the folder where the .mg5 file is located
        mg5_bin (str): Name of the MG5 executable (default: "mg5_aMC")

    Returns:
        str: Path to the generated PDF
    """

    mg5_executable = f"{madgraph_path}/bin/{mg5_bin}"
    mg5_script_complete_path = mg5_script_folder_path + "/" + process_name + ".mg5"

    print(f"Check the mg5 log on {process_name}.log")
    with open(f"{process_name}.log", "w") as script_log_file:
        subprocess.run([mg5_executable, mg5_script_complete_path],
                       stdout=script_log_file, env=ENV)

    return mg5_script_complete_path


# Convert EPS to PDF using ghostscript
def convert_eps_to_pdf(eps_file, pdf_file=None):
    """
    Convert an EPS file to PDF using ghostscript.

    Args:
        eps_file (str): Path to the input EPS file
        pdf_file (str): Path to the output PDF file (optional)
                       If not provided, uses same name as eps_file with .pdf extension
    """
    if pdf_file is None:
        pdf_file = Path(eps_file).stem + '.pdf'

    # Ghostscript command for EPS to PDF conversion
    cmd = [
        'gs',
        '-q',                          # Quiet mode
        '-dNOPAUSE',                  # Don't pause after each page
        '-dBATCH',                    # Batch mode (exit after processing)
        '-dSAFER',                    # Safer mode
        '-sDEVICE=pdfwrite',          # Output device
        f'-sOutputFile={pdf_file}',   # Output file
        '-dEPSCrop',                  # Crop to EPS bounding box
        eps_file                      # Input file
    ]

    try:
        subprocess.run(cmd, check=True, capture_output=True)
        print(f"Successfully converted {eps_file} to {pdf_file}")
        return pdf_file
    except subprocess.CalledProcessError as e:
        print(f"Error during conversion: {e.stderr.decode()}")
        return None
    except FileNotFoundError:
        print("Ghostscript not found. Please install it:")
        print("  Ubuntu/Debian: sudo apt-get install ghostscript")
        print("  macOS: brew install ghostscript")
        print("  Windows: Download from https://www.ghostscript.com/download/gsdnld.html")
        return None


def convert_from_folder(input_folder: str, output_folder: str):
    """
    Convert all EPS files in a given folder to PDF using ghostscript.

    Args:
        input_folder (str): Path to the folder containing the EPS files
        output_folder (str): Path to the output folder (optional)
                       If not provided, creates a folder named 'pdf_output' in the same directory as input_folder
    """
    input_path = Path(input_folder)

    # Validate input folder
    if not input_path.exists() or not input_path.is_dir():
        print(f"Input folder not found: {input_folder}")
        return []

    # Create output folder if not provided
    if output_folder is None:
        output_path = input_path / 'pdf_output'
    else:
        output_path = Path(output_folder)

    # Create output folder if it doesn't exist
    output_path.mkdir(parents=True, exist_ok=True)

    # Find all EPS files
    eps_files = list(input_path.glob('*.eps'))

    if not eps_files:
        print(f"No EPS files found in {input_folder}")
        return []

    print(f"Found {len(eps_files)} EPS file(s) to convert")
    converted_files = []

    # Convert each EPS file
    for eps_file in eps_files:
        pdf_file = output_path / (eps_file.stem + '.pdf')
        print(f"\nConverting: {eps_file.name} → {pdf_file.name}")
        convert_eps_to_pdf(eps_file, pdf_file)

    print(f"\n{'='*50}")
    print(
        f"Conversion complete! {len(converted_files)}/{len(eps_files)} files converted.")
    print(f"Output folder: {output_path}")
    print(f"{'='*50}")


def convert_eps_from_folder(input_folder: str, output_folder: str):
    """
    Convert all EPS files in a given folder to PDF using ghostscript.

    Args:
        input_folder (str): Path to the folder containing the EPS files
        output_folder (str): Path to the output folder (optional)
                       If not provided, creates a folder named 'pdf_output' in the same directory as input_folder

    Returns:
        List[str]: List of paths to the generated PDF files
    """
    input_path = Path(input_folder)

    # Validate input folder
    if not input_path.exists() or not input_path.is_dir():
        print(f"Input folder not found: {input_folder}")
        return []

    # Create output folder if not provided
    if output_folder is None:
        output_path = input_path / 'pdf_output'
    else:
        output_path = Path(output_folder)

    # Create output folder if it doesn't exist
    output_path.mkdir(parents=True, exist_ok=True)

    # Find all EPS files
    eps_files = list(input_path.glob('*.eps'))

    if not eps_files:
        print(f"No EPS files found in {input_folder}")
        return []

    print(f"Found {len(eps_files)} EPS file(s) to convert")
    converted_files = []

    # Convert each EPS file
    for eps_file in eps_files:
        pdf_file = output_path / (eps_file.stem + '.pdf')
        print(f"\nConverting: {eps_file.name} → {pdf_file.name}")
        convert_eps_to_pdf(eps_file, pdf_file)
        converted_files.append(str(pdf_file))

    print(f"\n{'='*50}")
    print(
        f"Conversion complete! {len(converted_files)}/{len(eps_files)} files converted.")
    print(f"Output folder: {output_path}")
    print(f"{'='*50}")


def unpack_events(events_path: str) -> Path:
    """
    Descompacta um arquivo LHE (.lhe.gz) para um arquivo LHE (.lhe).

    Parameters
    ----------
    events_path : str
        Caminho para o arquivo de saída com eventos gerados.

    Returns
    -------
    Path
        Caminho para o arquivo LHE descompactado.

    Raises
    ------
    FileNotFoundError
        Caso o arquivo LHE não exista.
    """

    # os.path.join(working_dir, f"{event_name}/Events/run_01/unweighted_events.lhe")
    output_file = events_path
    try:
        # output_zip_file = os.path.join(working_dir, f"{event_name}/Events/run_01/unweighted_events.lhe.gz")
        subprocess.run(["gzip", "-d", "-k", output_file])
        print("Arquivo LHE descompactado com sucesso.")

        return Path(events_path.replace(".gz", ""))
    except FileNotFoundError:
        print('Arquivo ja foi descompactado')


# Extract cross section from LHE file
def get_cross_section(lhe_file: str | Path) -> tuple[float | None, float | None]:
    """
    Extracts the cross section value from a LHE file.

    Parameters
    ----------
    lhe_file : str
        Path to the LHE file.

    Returns
    -------
    tuple
        A tuple containing the cross section value and its error.

    """
    cross_section = None
    with open(lhe_file, 'r') as file:
        in_init_block = False
        for line in file:
            if "<init>" in line:
                in_init_block = True
            elif "</init>" in line:
                in_init_block = False
                break
            elif in_init_block:
                data = line.strip().split()
                if len(data) <= 6:
                    cross_section = float(data[0])
                    error = float(data[1])
                    break
    return cross_section, error


# Extract the events and convert it to pandas format
def parse_lhe_file(file_path: str, cross_section: float, error: float, run_number: int | None = None) -> pd.DataFrame:
    """
    Parse a LHE file and convert it to a pandas DataFrame.

    Parameters
    ----------
    file_path : str
        Path to the LHE file.
    cross_section : float
        Cross section value of the run.
    error : float
        Cross section error of the run.
    run_number : int, optional
        Run number of the simulation.

    Returns
    -------
    tuple
        A tuple containing the DataFrame and the list of events.

    """
    events = []
    event_id = 0

    with open(file_path, 'r') as file:
        in_event = False
        for line in file:
            if "<event>" in line:
                in_event = True
                event = []
                event_id += 1  # Incrementa o ID do evento a cada novo evento
            elif "</event>" in line:
                in_event = False
                events.append(event)
            elif in_event:
                data = line.strip().split()
                if len(data) >= 6:
                    try:
                        particle_data = list(map(float, data))
                        # Adiciona o ID do evento à partícula
                        particle_data.append(event_id)
                        event.append(particle_data)
                    except ValueError:
                        # print("line ", line)
                        # print("event id ", event_id)
                        # print('particle data ', particle_data)
                        # print('error in line ', data)
                        pass

                        # TODO: How to extract this info
                        # <mgrwt>
                        # <rscale>  0 0.43702855E+04</rscale>
                        # <asrwt>0</asrwt>
                        # <pdfrwt beam="1">  1        2 0.25919763E+00 0.43702855E+04</pdfrwt>
                        # <pdfrwt beam="2">  1       -2 0.32749606E+00 0.43702855E+04</pdfrwt>
                        # <totfact> 0.16864895E-01</totfact>
                        # </mgrwt>

    # Converte a lista de eventos para um DataFrame
    columns = ["pid", "status", "m_mother1", "mother2", "color1",
               "color2", "px", "py", "pz", "E", "M", "lifetime", "spin", "event_id"]
    df = pd.DataFrame(
        [item for sublist in events for item in sublist], columns=columns)
    # Adiciona uma coluna de cross-section (mesmo valor para todos os eventos)
    df["cross_section"] = cross_section  # pb
    df["cross_section_error"] = error  # ± pb
    df.dropna(subset=["lifetime", "spin"], inplace=True)

    if run_number:
        df['run_number'] = run_number

    return df
