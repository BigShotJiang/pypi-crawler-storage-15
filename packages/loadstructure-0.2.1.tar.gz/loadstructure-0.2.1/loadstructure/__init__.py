from loadstructure.main import ConfigManager
from loadstructure.config_node import SchemaError

version = '0.2.0'