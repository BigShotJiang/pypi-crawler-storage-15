This module adds a new 'End User' Address Type for partner addresses.

This is useful when managing end user addresses linked to ordering
partners.

![Partner Contact End User Type](https://user-images.githubusercontent.com/19529533/73062365-85de9a80-3e9c-11ea-9c9a-c69a755f35b5.png)
