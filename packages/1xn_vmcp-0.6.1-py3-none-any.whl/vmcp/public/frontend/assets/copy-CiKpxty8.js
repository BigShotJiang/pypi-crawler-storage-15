import{c}from"./index-CxHQsSmh.js";const e=[["rect",{width:"14",height:"14",x:"8",y:"8",rx:"2",ry:"2",key:"17jyea"}],["path",{d:"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",key:"zix9uf"}]],t=c("copy",e);export{t as C};
//# sourceMappingURL=copy-CiKpxty8.js.map
