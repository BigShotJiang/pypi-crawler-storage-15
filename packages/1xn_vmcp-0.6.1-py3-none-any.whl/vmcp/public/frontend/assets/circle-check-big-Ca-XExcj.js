import{c}from"./index-CxHQsSmh.js";const e=[["path",{d:"M21.801 10A10 10 0 1 1 17 3.335",key:"yps3ct"}],["path",{d:"m9 11 3 3L22 4",key:"1pflzl"}]],t=c("circle-check-big",e);export{t as C};
//# sourceMappingURL=circle-check-big-Ca-XExcj.js.map
