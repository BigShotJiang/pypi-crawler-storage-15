# Squidpy 1.0.0 (2021-02-20)

Initial release.
