# Squidpy 1.1.2 (2021-09-10)

## Bugfixes

- Fix {mod}`napari` slider and {mod}`numpy` typing.
  [#413](https://github.com/scverse/squidpy/pull/413)


## Miscellaneous

- Update CI and fix ``_genesymols`` context manager.
  [#412](https://github.com/scverse/squidpy/pull/412)
