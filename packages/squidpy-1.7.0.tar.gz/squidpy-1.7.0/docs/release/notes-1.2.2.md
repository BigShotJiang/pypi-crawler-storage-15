# Squidpy 1.2.2 (2022-05-17)

## Miscellaneous

- Rename organization references and update pre-commit checks.
  [@giovp](https://github.com/giovp)
  [#551](https://github.com/scverse/squidpy/pull/551)

- Fix types.
  [@giovp](https://github.com/giovp)
  [#554](https://github.com/scverse/squidpy/pull/554)
