# Squidpy 1.6.0 (2024-07-23)

## Features

- Now `squidpy.gr.spatial_graph` can also be used on {class}`spatialdata.SpatialData` objects.

- Add {func}`squidpy.gr.mask_graph` to mask a spatial graph based on {class}`shapely.Polygon` or {class}`shapely.MultiPolygon`
  [@giovp](https://github.com/giovp)
  [#842](https://github.com/scverse/squidpy/pull/842)
