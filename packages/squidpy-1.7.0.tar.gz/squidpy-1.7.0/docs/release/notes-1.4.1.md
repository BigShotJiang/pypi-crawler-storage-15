# Squidpy 1.4.1 (2024-02-06)

## Bugfixes

- Unpin ``scikit-image``.
  [@giovp](https://github.com/giovp)
  [#796](https://github.com/scverse/squidpy/pull/796)
