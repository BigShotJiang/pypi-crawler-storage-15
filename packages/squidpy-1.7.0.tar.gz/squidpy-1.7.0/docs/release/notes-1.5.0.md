# Squidpy 1.5.0 (2024-05-27)

## Bugfixes

- Fixed the reading of 10x formatted mtx files.
  [@LinearParadox](https://github.com/LinearParadox)
  [#803](https://github.com/scverse/squidpy/pull/803)

- Various fixes.
  [@michalk8](https://github.com/michalk8)
  [#798](https://github.com/scverse/squidpy/pull/798)

- Improved {func}`squidpy.gr.co_occurrence` calculation.
  [@DPLemonade](https://github.com/DPLemonade)
  [#816](https://github.com/scverse/squidpy/pull/816)
