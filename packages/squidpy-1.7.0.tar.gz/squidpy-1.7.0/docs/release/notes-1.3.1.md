# Squidpy 1.3.1 (2023-10-09)

## Miscellaneous

- Deprecated napari.
  [@LLehner](https://github.com/LLehner)
  [#738](https://github.com/scverse/squidpy/pull/738)

- Various fixes.
  [@giovp](https://github.com/giovp)
  [#756](https://github.com/scverse/squidpy/pull/756)

- Add cruft.json to comply with scverse cookiecutter template.
  [@LLehner](https://github.com/LLehner)
  [#756](https://github.com/scverse/squidpy/pull/747)
