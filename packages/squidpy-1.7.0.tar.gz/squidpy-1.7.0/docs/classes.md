# Classes

```{eval-rst}
.. currentmodule:: squidpy

.. autosummary::
    :toctree: classes

    im.ImageContainer
    im.SegmentationWatershed
    im.SegmentationCustom
```
