# Release Notes

```{eval-rst}
.. toctree::
    :maxdepth: 3

    release/notes-dev

.. toctree::
    :maxdepth: 3
    :glob:
    :reversed:

    release/notes-*.*.*
```
