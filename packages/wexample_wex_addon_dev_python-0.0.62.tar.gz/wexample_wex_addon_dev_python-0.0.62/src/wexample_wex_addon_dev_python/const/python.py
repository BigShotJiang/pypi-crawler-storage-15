from __future__ import annotations

from pathlib import Path

PYTHON_PYTEST_COV_REPORT_DIR: Path = Path("htmlcov")
PYTHON_PYTEST_COV_FORMAT_HTML: str = "html"
PYTHON_PYTEST_COV_FORMAT_JSON: str = "json"
