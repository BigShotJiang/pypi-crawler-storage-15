import logging


def setup_logger():
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
