import{_ as a,cn as s}from"./index-Ci6ypq6O.js";const c=a(s,[["__scopeId","data-v-565bc716"]]);export{c as M};
