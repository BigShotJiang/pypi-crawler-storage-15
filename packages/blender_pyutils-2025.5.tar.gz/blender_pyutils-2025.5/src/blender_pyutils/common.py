#!/usr/bin/env python3
"""Common constants."""


ENCODING = "utf-8"
