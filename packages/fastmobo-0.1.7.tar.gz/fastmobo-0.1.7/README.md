# Fast Mobo

Multi-objective Bayesian optimization Framework (Botorch Wrapper)
