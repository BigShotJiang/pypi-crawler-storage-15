# DebugTwin CLI

AI-powered firmware debugging assistant for embedded systems.

## Installation

```bash
pip install debugtwin-cli
```

## Quick Start

### 1. Get an API Key

1. Go to [DebugTwin Dashboard](https://embedded-frontend-production.up.railway.app)
2. Sign in with Google
3. Navigate to **API Keys** in the header
4. Click **Generate Key** and copy it

### 2. Login

```bash
debugtwin login --key YOUR_API_KEY
```

### 3. Start Chatting

```bash
debugtwin chat
```

### 4. Analyze a Log File

```bash
debugtwin analyze your_firmware.log
```

## Commands

| Command | Description |
|---------|-------------|
| `debugtwin login --key KEY` | Authenticate with your API key |
| `debugtwin chat` | Start an interactive debugging session |
| `debugtwin analyze FILE` | Analyze a firmware log file |
| `debugtwin ask "question"` | Ask a quick question |
| `debugtwin version` | Show version information |
| `debugtwin configure --url URL` | Configure custom API URL (for self-hosted) |

## Example Session

```
$ debugtwin chat
🚀 Starting DebugTwin Copilot CLI...
🔌 Connecting to: https://web-production-5988.up.railway.app

🤖 Hello! How can I help you debug your firmware today?

You: I'm seeing a HardFault on my STM32F4
🤖 I'd be happy to help debug that HardFault! Can you share:
1. The crash log or register dump
2. What was happening when it occurred
...
```

## Requirements

- Python 3.9+
- Internet connection (for API access)

## License

MIT
