# apolo-all
Combo package for installing all Apolo command line tools by `pipx install apolo-all` command
