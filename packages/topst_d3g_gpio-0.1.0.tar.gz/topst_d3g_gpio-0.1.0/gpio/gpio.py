#!/usr/bin/env python3
import os
import time
import select
import threading
from threading import Thread


# =========================
# RPi.GPIO ��Ÿ�� ���
# =========================
IN = "in"
OUT = "out"

HIGH = 1
LOW = 0

PUD_OFF = 0
PUD_UP = 1
PUD_DOWN = 2  # ����� ���

RISING = "rising"
FALLING = "falling"
BOTH = "both"


class GPIOWarning(Warning):
    pass


# =========================
# PWM Ŭ����
# =========================
class PWM:
    def __init__(self, channel, freq_hz):
        """
        channel: (chip_id, channel_id) tuple
        freq_hz: PWM frequency
        """
        chip, ch = channel
        self.chip = chip
        self.ch = ch

        self.chip_path = f"/sys/class/pwm/pwmchip{chip}"
        self.pwm_path = f"{self.chip_path}/pwm{ch}"
        self.period_ns = int(1e9 / freq_hz)

        # Export
        if not os.path.exists(self.pwm_path):
            with open(f"{self.chip_path}/export", "w") as f:
                f.write(str(ch))
            time.sleep(0.05)

        # Disable first
        try:
            with open(f"{self.pwm_path}/enable", "w") as f:
                f.write("0")
        except:
            pass

        with open(f"{self.pwm_path}/period", "w") as f:
            f.write(str(self.period_ns))

        with open(f"{self.pwm_path}/duty_cycle", "w") as f:
            f.write("0")

        self.enabled = False

    def start(self, duty):
        duty_ns = int(self.period_ns * duty / 100)
        with open(f"{self.pwm_path}/duty_cycle", "w") as f:
            f.write(str(duty_ns))
        with open(f"{self.pwm_path}/enable", "w") as f:
            f.write("1")
        self.enabled = True

    def ChangeDutyCycle(self, duty):
        duty_ns = int(self.period_ns * duty / 100)
        with open(f"{self.pwm_path}/duty_cycle", "w") as f:
            f.write(str(duty_ns))

    def ChangeFrequency(self, freq):
        self.period_ns = int(1e9 / freq)
        with open(f"{self.pwm_path}/period", "w") as f:
            f.write(str(self.period_ns))

    def stop(self):
        with open(f"{self.pwm_path}/enable", "w") as f:
            f.write("0")
        self.enabled = False


# =========================
# D3-G GPIO Ŭ����
# =========================
class D3G_GPIO:
    def __init__(self):
        self.exported = set()
        self.pinmap_board = {
            3: 82, 5: 81, 7: 83, 8: 87, 10: 88,
            11: 84, 12: 89, 13: 85, 15: 86, 16: 90,
            18: 65, 19: 63, 21: 64, 22: 66, 23: 61,
            24: 62, 26: 67, 27: 112, 29: 113, 31: 114,
            32: 115, 33: 114, 35: 121, 36: 119,
            37: 117, 38: 120, 40: 118
        }

        self.event_threads = {}
        self.event_detect_flag = {}
        self.event_callbacks = {}

    # =========================
    # ���� Helper
    # =========================
    def _gpio_from_board(self, ch):
        if ch not in self.pinmap_board:
            raise ValueError(f"BOARD pin {ch} not mapped in D3-G.")
        return self.pinmap_board[ch]

    def _export(self, gpio):
        if gpio not in self.exported:
            with open("/sys/class/gpio/export", "w") as f:
                f.write(str(gpio))
            time.sleep(0.02)
            self.exported.add(gpio)

    def _unexport(self, gpio):
        if gpio in self.exported:
            with open("/sys/class/gpio/unexport", "w") as f:
                f.write(str(gpio))
            self.exported.remove(gpio)

    def _set_edge(self, gpio, edge):
        with open(f"/sys/class/gpio/gpio{gpio}/edge", "w") as f:
            f.write(edge)

    # =========================
    # Public API: Pin Setup
    # =========================
    def setup(self, channels, direction, pull_up_down=PUD_OFF):
        if isinstance(channels, (list, tuple)):
            for ch in channels:
                self.setup(ch, direction, pull_up_down)
            return

        gpio = self._gpio_from_board(channels)
        self._export(gpio)

        # pull-up/down ���
        if pull_up_down != PUD_OFF:
            print(f"[Warning] D3-G does not support software PUD. Use DTS. (GPIO{gpio})")

        with open(f"/sys/class/gpio/gpio{gpio}/direction", "w") as f:
            f.write(direction)

    # =========================
    # Public API: Digital I/O
    # =========================
    def output(self, channels, value):
        if isinstance(channels, (list, tuple)):
            for ch in channels:
                self.output(ch, value)
            return

        gpio = self._gpio_from_board(channels)
        with open(f"/sys/class/gpio/gpio{gpio}/value", "w") as f:
            f.write("1" if value else "0")

    def input(self, channels):
        if isinstance(channels, (list, tuple)):
            return [self.input(ch) for ch in channels]

        gpio = self._gpio_from_board(channels)
        with open(f"/sys/class/gpio/gpio{gpio}/value", "r") as f:
            return int(f.read().strip())

    # =========================
    # Event Detection (Interrupt Handling)
    # =========================
    def wait_for_edge(self, ch, edge):
        gpio = self._gpio_from_board(ch)
        self._set_edge(gpio, edge)

        fd = os.open(f"/sys/class/gpio/gpio{gpio}/value", os.O_RDONLY)
        poller = select.poll()
        poller.register(fd, select.POLLPRI)

        # clear
        os.lseek(fd, 0, os.SEEK_SET)
        os.read(fd, 1)

        poller.poll()  # block
        os.close(fd)
        return True

    def _event_thread(self, gpio, edge, callback, bouncetime):
        fd = os.open(f"/sys/class/gpio/gpio{gpio}/value", os.O_RDONLY)
        poller = select.poll()
        poller.register(fd, select.POLLPRI)

        os.lseek(fd, 0, os.SEEK_SET)
        os.read(fd, 1)

        last_time = 0

        while True:
            ev = poller.poll(1000)
            if not ev:
                continue

            now = time.time()
            if bouncetime and (now - last_time) * 1000 < bouncetime:
                continue

            last_time = now
            self.event_detect_flag[gpio] = True

            if callback:
                callback(gpio)

    def add_event_detect(self, ch, edge, callback=None, bouncetime=None):
        gpio = self._gpio_from_board(ch)
        self._set_edge(gpio, edge)

        self.event_detect_flag[gpio] = False

        t = Thread(target=self._event_thread,
                   args=(gpio, edge, callback, bouncetime),
                   daemon=True)
        self.event_threads[gpio] = t
        t.start()

    def add_event_callback(self, ch, callback):
        gpio = self._gpio_from_board(ch)
        self.event_callbacks[gpio] = callback

    def event_detected(self, ch):
        gpio = self._gpio_from_board(ch)
        if self.event_detect_flag.get(gpio, False):
            self.event_detect_flag[gpio] = False
            return True
        return False

    def remove_event_detect(self, ch):
        # Thread ����� Python������ ���� kill �Ұ� �� flag�� ���
        gpio = self._gpio_from_board(ch)
        if gpio in self.event_threads:
            del self.event_threads[gpio]

    # =========================
    # Cleanup
    # =========================
    def cleanup(self, ch=None):
        if ch is None:
            for gpio in list(self.exported):
                self._unexport(gpio)
            return

        if isinstance(ch, (list, tuple)):
            for c in ch:
                self.cleanup(c)
            return

        gpio = self._gpio_from_board(ch)
        self._unexport(gpio)


# =========================
# �ܺ� ��� API (RPi.GPIO ��Ÿ��)
# =========================
GPIO = D3G_GPIO()
