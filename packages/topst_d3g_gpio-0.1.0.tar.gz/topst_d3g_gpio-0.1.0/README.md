# TOPST D3-G GPIO Library

This is a simple GPIO control library for the TOPST D3-G embedded board.

