from setuptools import setup, find_packages

setup(
    name="topst.d3g.gpio", 
    version="0.1.0",
    description="GPIO control library for TOPST D3-G board",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="Telechips TOPST",
    author_email="your_email@example.com",
    url="https://github.com/telechips/topst-d3g-gpio",
    packages=find_packages(),
    install_requires=[],
    python_requires=">=3.7",
)
