from setuptools import setup, find_packages

setup(
    name="my_eldar_hangman_game",
    version="1.0.2",
    description="Simple Hangman Game Library",
    author="Eldar",
    author_email="example@example.com",
    packages=find_packages(),
    include_package_data=True,
    long_description=open("README.md", "r", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    python_requires=">=3.8",
)
