# fps-frontend

An FPS plugin for the frontend related configuration.
