import logging
from typing import Callable

from bs4 import BeautifulSoup

from .backend import FileJSONBackend
from .entities import HTMLFile, RegisteredMethod
from .protocols import BackendProtocol

logger = logging.getLogger(__name__)


class PyriodicBackend:
    def __init__(self, backend: BackendProtocol = FileJSONBackend()):
        self.backend: BackendProtocol = backend
        self.registered_methods: list[RegisteredMethod] = []

    def register(
        self, html_file: HTMLFile, tag_id: str, func: Callable, interval: int = 1
    ) -> RegisteredMethod:
        new_method = RegisteredMethod(
            html_file=html_file, tag_id=tag_id, func=func, interval=interval
        )
        self.registered_methods.append(new_method)
        return new_method

    def run(self):
        for registered_method in self.registered_methods:
            logger.debug(
                f"Initializing method {registered_method.func.__name__} on tag {registered_method.tag_id}"
            )
            minutes_since_last_run = self.backend.get_minutes_since_last_run(
                registered_method
            )
            if (
                minutes_since_last_run is not None
                and minutes_since_last_run < registered_method.interval
            ):
                logger.debug("Skipping method execution, time not yet passed")
                continue
            with open(
                registered_method.html_file.abs_file_path, "r"
            ) as input_html_file:
                soup = BeautifulSoup(input_html_file, "html.parser")

                tag = soup.find(id=registered_method.tag_id)

                if tag:
                    tag.string = registered_method.func()  # type: ignore
                else:
                    logger.warning("tag not found")

            with open(
                registered_method.html_file.abs_file_path, "w"
            ) as output_html_file:
                output_html_file.write(str(soup))
            logger.debug(f"Method {registered_method.func.__name__} executed")
            self.backend.record(registered_method)
