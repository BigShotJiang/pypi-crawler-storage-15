"""Init for ReadSam."""
from __future__ import absolute_import
from .decompose import *
from .reference_decom import *