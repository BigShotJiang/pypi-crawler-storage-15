"""Init for ReadSam."""
from __future__ import absolute_import
from .imputeEPIC import *
