"""Init for ReadSam."""
from __future__ import absolute_import
from .idat_cnv_calling import microarray_call_cnvs
from .seq_cnv_calling import sequencing_call_cnvs