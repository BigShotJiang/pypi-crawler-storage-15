"""Init for ReadSam."""
from __future__ import absolute_import
from .diff_meth_cpg import *
