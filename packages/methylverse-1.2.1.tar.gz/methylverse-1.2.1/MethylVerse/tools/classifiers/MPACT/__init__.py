"""Init for ReadSam."""
from __future__ import absolute_import
from .MPACT_classifier import MPACT_classifier, DenseModel, SparseModel