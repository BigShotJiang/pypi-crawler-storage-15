"""Init for ReadSam."""
from __future__ import absolute_import
from .MPACT.MPACT_classifier import MPACT_classifier