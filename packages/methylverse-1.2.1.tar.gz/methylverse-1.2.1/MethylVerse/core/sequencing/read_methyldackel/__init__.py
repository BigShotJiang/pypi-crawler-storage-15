"""Init for ReadSam."""
from __future__ import absolute_import
from .read_methyldackel import read_methyldackel