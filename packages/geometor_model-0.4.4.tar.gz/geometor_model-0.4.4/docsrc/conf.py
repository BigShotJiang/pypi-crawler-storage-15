from photon_platform.publish.global_conf import *

import geometor.model as module

version = module.__version__

org = "geometor"
org_name = "GEOMETOR"

repo = "model"
repo_name = "model"

setup_globals(org, org_name, repo, repo_name)
