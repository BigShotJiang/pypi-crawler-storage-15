
vesica
======

.. literalinclude:: ../../demos/vesica.py
   :language: python
