
:navigation: footer
:order: 1

.. _about:


about
=====


I have always been deeply interested in architecture and have had the privilege of practicing it in many different domains. 

Architecture is order. 

.. It can be in the material world.

