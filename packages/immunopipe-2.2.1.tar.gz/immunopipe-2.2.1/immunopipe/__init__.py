from .version import __version__

# Used for pipen-board:
# $ pipen-board immunopipe:Immunopipe
from .pipeline import Immunopipe  # noqa: F401
