..
    This file is part of Invenio.
    Copyright (C) 2015-2018 CERN.

    Invenio is free software; you can redistribute it and/or modify it
    under the terms of the MIT License; see LICENSE file for more details.

Contributors
============

- Alexander Ioannidis
- Alizee Pace
- Diego Rodriguez
- Eamonn Maguire
- Esteban J. G. Gabancho
- Harri Hirvonsalo
- Harris Tzovanakis
- Javier Delgado
- Jiri Kuncar
- Lars Holm Nielsen
- Leonardo Rossi
- Nikos Filippakis
- Orestis Melkonian
- Paulina Lach
- Sami Hiltunen
- Tibor Simko
- Mojib Wali
