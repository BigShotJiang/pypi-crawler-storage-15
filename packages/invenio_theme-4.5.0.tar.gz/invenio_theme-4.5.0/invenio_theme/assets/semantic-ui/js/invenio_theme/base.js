/*
 * This file is part of Invenio.
 * Copyright (C) 2017-2020 CERN.
 *
 * Invenio is free software; you can redistribute it and/or modify it
 * under the terms of the MIT License; see LICENSE file for more details.
 */

// TODO: Check if jQuery is actually needed for anything else besides
// Semantic-UI. If not remove the "base" entry completely.
// eslint-disable-next-line no-unused-vars
import jquery from "jquery/dist/jquery";
