/*
 * This file is part of Invenio.
 * Copyright (C) 2017-2018 CERN.
 *
 * Invenio is free software; you can redistribute it and/or modify it
 * under the terms of the MIT License; see LICENSE file for more details.
 */
// eslint-disable-next-line no-unused-vars
import jquery from "jquery/dist/jquery";
// eslint-disable-next-line no-unused-vars
import bootstrap from "bootstrap-sass/assets/javascripts/bootstrap";
