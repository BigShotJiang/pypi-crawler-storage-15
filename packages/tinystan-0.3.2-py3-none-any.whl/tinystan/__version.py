__version__ = "0.3.2"

__version_info__ = tuple(map(int, __version__.split(".")))
