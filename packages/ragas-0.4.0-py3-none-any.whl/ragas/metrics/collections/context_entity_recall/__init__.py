"""Context Entity Recall metrics v2 - Modern implementation."""

from .metric import ContextEntityRecall

__all__ = [
    "ContextEntityRecall",
]
