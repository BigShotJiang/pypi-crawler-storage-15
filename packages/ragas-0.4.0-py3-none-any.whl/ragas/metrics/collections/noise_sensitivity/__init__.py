"""Noise Sensitivity metrics v2 - Modern implementation."""

from .metric import NoiseSensitivity

__all__ = [
    "NoiseSensitivity",
]
