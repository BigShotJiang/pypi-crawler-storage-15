"""Answer Relevancy metrics v2 - Modern implementation."""

from .metric import AnswerRelevancy

__all__ = [
    "AnswerRelevancy",
]
