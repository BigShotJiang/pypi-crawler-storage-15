"""Faithfulness metrics v2 - Modern implementation."""

from .metric import Faithfulness

__all__ = [
    "Faithfulness",
]
