"""Context Recall metrics v2 - Modern implementation."""

from .metric import ContextRecall

__all__ = [
    "ContextRecall",
]
