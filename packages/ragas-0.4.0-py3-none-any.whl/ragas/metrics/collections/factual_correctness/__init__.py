"""Factual Correctness metrics v2 - Modern implementation."""

from .metric import FactualCorrectness

__all__ = [
    "FactualCorrectness",
]
