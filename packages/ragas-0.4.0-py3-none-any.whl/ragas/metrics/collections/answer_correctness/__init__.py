"""Answer Correctness metrics v2 - Modern implementation."""

from .metric import AnswerCorrectness

__all__ = [
    "AnswerCorrectness",
]
