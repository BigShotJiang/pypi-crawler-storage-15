"""Response Groundedness metrics v2 - Modern implementation."""

from .metric import ResponseGroundedness

__all__ = [
    "ResponseGroundedness",
]
