"""Summary Score metrics v2 - Modern implementation."""

from .metric import SummaryScore

__all__ = [
    "SummaryScore",
]
