"""Context Relevance metrics v2 - Modern implementation."""

from .metric import ContextRelevance

__all__ = [
    "ContextRelevance",
]
