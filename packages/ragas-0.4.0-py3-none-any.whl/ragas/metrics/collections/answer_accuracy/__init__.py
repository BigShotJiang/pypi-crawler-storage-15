"""Answer Accuracy metrics v2 - Modern implementation."""

from .metric import AnswerAccuracy

__all__ = [
    "AnswerAccuracy",
]
