---
title: Data Models
description: Browse the core data models used by CTFBridge. Understand how challenge, user, and platform data are structured and manipulated within the library.
---

# Models

::: ctfbridge.models
