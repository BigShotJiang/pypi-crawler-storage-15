# Security Policy

## Reporting a Vulnerability

Please report security issues to [bjornmdev@proton.me](mailto:bjornmdev@proton.me).
