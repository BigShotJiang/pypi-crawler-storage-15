API_BASE = "/api"


class Endpoints:
    class Challenges:
        LIST = f"{API_BASE}/challenges"

    class Misc:
        METADATA = f"{API_BASE}/metadata"
