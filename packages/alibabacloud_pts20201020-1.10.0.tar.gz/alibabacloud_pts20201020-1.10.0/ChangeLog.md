2024-03-25 Version: 1.9.3
- Update API ListPtsScene: update response param.


2024-01-26 Version: 1.9.2
- Generated python 2020-10-20 for PTS.

2024-01-25 Version: 1.9.1
- Generated python 2020-10-20 for PTS.

2024-01-23 Version: 1.9.0
- Generated python 2020-10-20 for PTS.

2023-05-11 Version: 1.8.22
- Supported listing PTS reports.

2023-04-19 Version: 1.8.21
- Support adjust pts scene speed.

2023-03-28 Version: 1.8.18
- Add new API for querying the sample logs of PTS debug plan.
- Add new return field for global header to PTS scene.

2023-01-09 Version: 1.8.17
- Supported adjust PTS scene speed.
- Supported open PTS product.

2022-05-11 Version: 1.8.16
- Adjust Param To Form-Data.

2022-04-12 Version: 1.8.15
- Add VpcInfo and Ajust Speed API.

2022-04-12 Version: 1.8.12
- Add VpcInfo API.

2022-03-25 Version: 1.8.14
- Add SavePtsScene API.

2022-03-23 Version: 1.8.13
- Modify DeletePtsScenes API Param.

2021-12-27 Version: 1.8.11
- Set JmeterPluginLabel visibel.

2021-12-20 Version: 1.8.10
- Set JmeterPluginLabel visibel.

2021-12-20 Version: 1.8.7
- Add runningData reponse field, startTimeTS, hordFor.

2021-12-07 Version: 1.8.6
- Add jmeter_plugin_label field.

2021-12-03 Version: 1.8.5
- Modify EnviromentId to EnvironmentId.

2021-12-02 Version: 1.8.4
- Timers  to timerType.

2021-12-01 Version: 1.8.3
- Timers  to timerType.

2021-11-26 Version: 1.8.2
- PTS OpenAPI.

2021-11-23 Version: 1.8.1
- Jmeter OpenAPI Multi Language.

