feast.protos package
====================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   feast.protos.feast

Module contents
---------------

.. automodule:: feast.protos
   :members:
   :undoc-members:
   :show-inheritance:
