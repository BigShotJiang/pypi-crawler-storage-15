feast.embedded\_go package
==========================

Submodules
----------

feast.embedded\_go.online\_features\_service module
---------------------------------------------------

.. automodule:: feast.embedded_go.online_features_service
   :members:
   :undoc-members:
   :show-inheritance:

feast.embedded\_go.type\_map module
-----------------------------------

.. automodule:: feast.embedded_go.type_map
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: feast.embedded_go
   :members:
   :undoc-members:
   :show-inheritance:
