feast.cli package
=================

Submodules
----------

feast.cli.cli module
--------------------

.. automodule:: feast.cli.cli
   :members:
   :undoc-members:
   :show-inheritance:

feast.cli.cli\_options module
-----------------------------

.. automodule:: feast.cli.cli_options
   :members:
   :undoc-members:
   :show-inheritance:

feast.cli.cli\_utils module
---------------------------

.. automodule:: feast.cli.cli_utils
   :members:
   :undoc-members:
   :show-inheritance:

feast.cli.data\_sources module
------------------------------

.. automodule:: feast.cli.data_sources
   :members:
   :undoc-members:
   :show-inheritance:

feast.cli.entities module
-------------------------

.. automodule:: feast.cli.entities
   :members:
   :undoc-members:
   :show-inheritance:

feast.cli.feature\_services module
----------------------------------

.. automodule:: feast.cli.feature_services
   :members:
   :undoc-members:
   :show-inheritance:

feast.cli.feature\_views module
-------------------------------

.. automodule:: feast.cli.feature_views
   :members:
   :undoc-members:
   :show-inheritance:

feast.cli.features module
-------------------------

.. automodule:: feast.cli.features
   :members:
   :undoc-members:
   :show-inheritance:

feast.cli.on\_demand\_feature\_views module
-------------------------------------------

.. automodule:: feast.cli.on_demand_feature_views
   :members:
   :undoc-members:
   :show-inheritance:

feast.cli.permissions module
----------------------------

.. automodule:: feast.cli.permissions
   :members:
   :undoc-members:
   :show-inheritance:

feast.cli.projects module
-------------------------

.. automodule:: feast.cli.projects
   :members:
   :undoc-members:
   :show-inheritance:

feast.cli.saved\_datasets module
--------------------------------

.. automodule:: feast.cli.saved_datasets
   :members:
   :undoc-members:
   :show-inheritance:

feast.cli.serve module
----------------------

.. automodule:: feast.cli.serve
   :members:
   :undoc-members:
   :show-inheritance:

feast.cli.stream\_feature\_views module
---------------------------------------

.. automodule:: feast.cli.stream_feature_views
   :members:
   :undoc-members:
   :show-inheritance:

feast.cli.ui module
-------------------

.. automodule:: feast.cli.ui
   :members:
   :undoc-members:
   :show-inheritance:

feast.cli.validation\_references module
---------------------------------------

.. automodule:: feast.cli.validation_references
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: feast.cli
   :members:
   :undoc-members:
   :show-inheritance:
