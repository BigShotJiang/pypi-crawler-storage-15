# Adopters of Feast

Below are the adopters of Feast. If you are using Feast please add
yourself into the following list by a pull request. Please keep the list in
alphabetical order.

| Organization    | Contact                | GitHub Username      |
|-----------------|------------------------|----------------------| 
| Affirm          | Francisco Javier Arceo | franciscojavierarceo |
| Bank of Georgia | Tornike Gurgenidze     | tokoko               | 
| Get Ground      | Zhiling Chen           | zhilingc             | 
| Gojek           | Pradithya Aria Pura    | pradithya            |
| Picnic          | Tom Steenbergen        | TomSteenbergen       |
| Twitter         | David Liu              | mavysavydav          |
| SeatGeek        | Rob Howley             | robhowley            |
| Shopify         | Matt Delacour          | MattDelac            |
| Snowflake       | Miles Adkins           | sfc-gh-madkins       | 
