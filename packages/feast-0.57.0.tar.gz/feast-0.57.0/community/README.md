# Feast Community

Welcome to the Feast community!

Please see the Community section on [Feast.dev](https://docs.feast.dev/) for more details on getting involved.

- [Governance](governance.md): The Feast governance structure
- [Maintainers](maintainers.md): List of members acting as maintainers
