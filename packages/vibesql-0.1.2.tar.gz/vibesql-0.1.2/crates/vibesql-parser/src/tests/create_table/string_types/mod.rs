// String type parsing tests organized by category

mod binary_types;
mod char_types;
mod varchar_types;
