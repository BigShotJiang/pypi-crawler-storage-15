//! Tests for DELETE statement execution

mod basic;
mod common;
mod edge_cases;
mod subqueries;
mod truncate_optimization;
