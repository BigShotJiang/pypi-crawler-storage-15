# dynamaxsys

A common dynamical systems library written in JAX, designed to be used for various JAX projects requiring a dynamical system.

### Install

Install the repo:

```pip install dynamaxsys```

Alternatively, if you want to develop on the code base, please fork this repo and make pull requests as needed.

```pip install -e .```


