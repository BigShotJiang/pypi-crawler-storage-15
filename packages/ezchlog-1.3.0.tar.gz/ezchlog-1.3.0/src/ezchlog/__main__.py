from .cli import run_cli

run_cli()
