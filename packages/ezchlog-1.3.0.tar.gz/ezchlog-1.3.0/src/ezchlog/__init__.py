from .cli import run_cli as main

__all__ = ['main']
