"""Kudosx - An AI software team that builds products with industry standard practices."""

__version__ = "0.1.0"
