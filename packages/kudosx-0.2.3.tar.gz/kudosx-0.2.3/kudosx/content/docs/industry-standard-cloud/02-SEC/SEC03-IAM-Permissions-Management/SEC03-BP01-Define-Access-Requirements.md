# SEC03-BP01: Define access requirements

## Description

Xác định ai cần access gì.

## Implementation Guidance

- Access matrix documentation
- Role definitions
- Data classification based access
- Business justification required
- Regular requirements review

## Risk Level

Medium - Undefined requirements lead to over-permissioning.
