# SEC10-BP02: Develop incident management plans

## Description

IR playbooks.

## Implementation Guidance

- Playbooks for common incidents
- Containment procedures
- Evidence collection steps
- Communication templates
- Regular playbook reviews

## Risk Level

High - Ad-hoc response is ineffective.
