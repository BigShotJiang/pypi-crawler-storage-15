# SEC04-BP03: Correlate and enrich security alerts

## Description

SIEM correlation.

## Implementation Guidance

- SIEM deployment
- Alert correlation rules
- Threat intelligence enrichment
- Automated triage
- Alert prioritization

## Risk Level

Medium - Uncorrelated alerts miss attack patterns.
