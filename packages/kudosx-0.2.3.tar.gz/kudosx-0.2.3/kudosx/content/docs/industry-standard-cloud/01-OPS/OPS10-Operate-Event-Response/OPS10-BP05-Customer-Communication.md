# OPS10-BP05: Define a customer communication plan for outages

## Description

Communication plan cho customers.

## Implementation Guidance

- Status page updates
- Email notification templates
- Social media guidelines
- Internal communication plan
- Post-incident communication

## Risk Level

Medium - Poor communication damages customer trust.
