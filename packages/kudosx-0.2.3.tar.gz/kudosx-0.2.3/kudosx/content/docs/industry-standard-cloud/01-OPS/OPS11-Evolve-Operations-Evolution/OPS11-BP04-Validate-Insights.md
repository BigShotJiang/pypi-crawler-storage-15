# OPS11-BP04: Validate insights

## Description

Validate insights trước khi action.

## Implementation Guidance

- Data verification
- Cross-reference sources
- Hypothesis testing
- Stakeholder validation
- Proof of concept

## Risk Level

Low - Unvalidated insights lead to wasted effort.
