"""Unit tests for reporters."""
