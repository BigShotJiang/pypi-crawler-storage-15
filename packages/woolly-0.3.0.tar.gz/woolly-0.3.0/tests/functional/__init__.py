"""Functional tests for woolly - tests without mocking."""
