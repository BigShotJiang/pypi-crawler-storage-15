"""Test fixture configuration file management.

This package provides ConfigFile subclasses for creating fixture
files and scope-specific fixture modules.
"""
