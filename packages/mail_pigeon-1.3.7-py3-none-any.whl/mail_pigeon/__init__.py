__author__ = 'Антон Глызин'

from mail_pigeon.utils import logger
from mail_pigeon.mail_client import MailClient, Message, TypeMessage

__all__ = [
    'MailClient',
    'Message',
    'TypeMessage',
    'logger'
]

