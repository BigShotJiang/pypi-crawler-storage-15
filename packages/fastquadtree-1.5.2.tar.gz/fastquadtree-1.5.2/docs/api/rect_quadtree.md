# fastquadtree.RectQuadTree
::: fastquadtree.RectQuadTree
    options:
        inherited_members: true