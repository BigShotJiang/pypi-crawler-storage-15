from yellowdog_client.object_store.abstracts import AbstractChunkUploadTask


class ChunkUploadTask(AbstractChunkUploadTask):
    pass
