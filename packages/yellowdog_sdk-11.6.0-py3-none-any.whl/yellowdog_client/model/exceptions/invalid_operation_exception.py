class InvalidOperationException(Exception):
    pass
