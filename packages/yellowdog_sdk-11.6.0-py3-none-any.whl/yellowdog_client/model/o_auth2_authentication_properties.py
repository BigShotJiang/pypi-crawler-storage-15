from dataclasses import dataclass


@dataclass
class OAuth2AuthenticationProperties:
    pass
