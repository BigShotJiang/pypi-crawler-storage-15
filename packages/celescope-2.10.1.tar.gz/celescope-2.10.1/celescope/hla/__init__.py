STEPS = [
    "sample",
    "barcode",
    "cutadapt",
    "mapping_hla",
]
__ASSAY__ = "hla"
