# TODO: implement in the future - clarify caching in new inference first
