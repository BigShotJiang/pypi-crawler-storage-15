from inference_exp.models.yolov8.yolov8_object_detection_torch_script import (
    YOLOv8ForObjectDetectionTorchScript,
)


class YOLOv12ForObjectDetectionTorchScript(YOLOv8ForObjectDetectionTorchScript):
    pass
