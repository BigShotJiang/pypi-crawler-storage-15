# woodlark

[![PyPI - Version](https://img.shields.io/pypi/v/woodlark.svg)](https://pypi.org/project/woodlark)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/woodlark.svg)](https://pypi.org/project/woodlark)

---

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install woodlark
```

## License

`woodlark` is distributed under the terms of the [Apache-2.0](https://spdx.org/licenses/Apache-2.0.html) license.
