"""contextgit - Requirements and context traceability for LLM-assisted development."""

__version__ = "1.1.0"
__author__ = "Saleh"
__email__ = "saleh@cronlytic.com"
