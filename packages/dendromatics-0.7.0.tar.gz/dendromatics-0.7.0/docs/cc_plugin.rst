CloudCompare plugin
===================

A CloudCompare plugin that implements the algorithm is currently under development. Please stay tuned!