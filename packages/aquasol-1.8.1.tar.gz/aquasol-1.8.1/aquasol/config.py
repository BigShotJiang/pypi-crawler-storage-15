"""Configuration options for the aquasol module."""

CONFIG = {
    "out of range warnings": True,
}
