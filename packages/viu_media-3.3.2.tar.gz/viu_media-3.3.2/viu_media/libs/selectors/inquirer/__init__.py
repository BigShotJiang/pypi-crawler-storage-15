from .selector import InquirerSelector

__all__ = ["InquirerSelector"]
