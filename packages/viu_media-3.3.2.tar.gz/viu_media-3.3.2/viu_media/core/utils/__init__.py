"""
Core utilities for Viu application.

This module provides various utility classes and functions used throughout
the Viu application, including concurrency management, file operations,
and other common functionality.
"""
