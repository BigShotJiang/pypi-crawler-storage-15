========================
pyTelegramBotAPI (async)
========================


Usage example with async `pyTelegramBotAPI <https://pytba.readthedocs.io/en/latest/>`_
--------------------------------------------------------------------------------------

.. literalinclude:: ../../examples/pytba_async.py

Preview
-------

.. image:: ../_static/payment_handle_example.png