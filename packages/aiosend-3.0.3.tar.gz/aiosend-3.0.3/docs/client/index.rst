======
Client
======

aiosend is |python| python implementation for `Crypto Pay API <https://help.crypt.bot/crypto-pay-api>`_.

* **Tools** - additional functionality.
* **Shortcut methods** - shortcut type methods.
* **Session** - http session implementation.

.. |python| image:: ../_static/python.png
    :width: 16px
    :alt: python

.. toctree::

    tools
    shortcuts
    di
    hints_warns
    session