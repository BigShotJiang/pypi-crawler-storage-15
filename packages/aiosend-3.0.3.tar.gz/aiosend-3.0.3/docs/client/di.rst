====================
Dependency Injection
====================

**Dependency injection** is a mechanism that allows you to make the program more flexible,
adaptable, and extensible by decoupling the usage of an object from its creation.

Usage example
-------------
.. literalinclude:: ../../examples/di.py