# tj_odd_or_even

A simple Python library to check whether numbers are odd or even.

## Installation

You can install the package using pip:

```bash
pip install tj_odd_or_even

from tj_odd_or_even import is_even, is_odd

print(is_even(10))  # True
print(is_odd(7))    # True

