# Structured data diagnosis service
from .service import *