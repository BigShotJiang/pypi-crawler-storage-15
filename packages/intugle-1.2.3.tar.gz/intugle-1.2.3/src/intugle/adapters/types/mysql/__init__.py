"""MySQL adapter package."""
