__all__ = [
    'Sentence', 'SentenceWithSyntax'
]

from .impl import Sentence, SentenceWithSyntax
