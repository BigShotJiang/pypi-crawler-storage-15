from bindiff.file import BindiffFile
from bindiff.bindiff import BinDiff
