::: messageformat2.datamodel
    options:
      show_root_members_full_path: true
      show_if_no_docstring: True
      members_order: source
      filters:
      - "!^__"
      - "!^_Matcher"
      - "!^_generic_visit"
      - "!^DataModelValidator"
