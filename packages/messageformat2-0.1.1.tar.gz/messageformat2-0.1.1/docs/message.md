::: messageformat2.format_message
    options:
      show_root_heading: true

::: messageformat2.Message
    options:
      show_root_heading: true
      members_order: source
      group_by_category: false
