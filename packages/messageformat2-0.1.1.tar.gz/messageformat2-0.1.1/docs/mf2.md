Message Format 2.0 in 5 minutes

### Simple messages



#### Variables


#### literals


### Select messages
