from messageformat2.message import Message, format_message


__version__ = "0.1.1"
__all__ = ["Message", "format_message"]
