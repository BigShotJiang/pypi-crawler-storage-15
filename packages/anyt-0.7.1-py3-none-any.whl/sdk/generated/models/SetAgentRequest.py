from typing import *
from pydantic import BaseModel, Field

class SetAgentRequest(BaseModel):
    """
    SetAgentRequest model
        Request to set default agent.
            """
    model_config = {
        "populate_by_name": True,
        "validate_assignment": True
    }
    
    workspace_id : int = Field(validation_alias="workspace_id" )
    
    agent_id : int = Field(validation_alias="agent_id" )
    