class CipherParameters:
    pass
