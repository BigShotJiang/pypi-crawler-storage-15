"""Key derivation functions"""
