"""GCM mode utilities."""

from .gcm_util import GCMUtil

__all__ = ['GCMUtil']
