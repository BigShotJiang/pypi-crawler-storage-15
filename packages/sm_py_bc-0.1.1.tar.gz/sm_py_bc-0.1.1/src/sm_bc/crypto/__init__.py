"""Cryptographic implementations"""
