"""Cryptographic parameters"""
