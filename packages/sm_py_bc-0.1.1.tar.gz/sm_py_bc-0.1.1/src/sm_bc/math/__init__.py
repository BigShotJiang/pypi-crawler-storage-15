"""Elliptic curve mathematics"""
