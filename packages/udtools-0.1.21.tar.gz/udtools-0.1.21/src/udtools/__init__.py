"""
udtools.

Python tools for Universal Dependencies.
"""

__version__ = "0.1.21"
__author__ = 'Daniel Zeman'
__credits__ = 'Universal Dependencies community'

from .validate import Validator

