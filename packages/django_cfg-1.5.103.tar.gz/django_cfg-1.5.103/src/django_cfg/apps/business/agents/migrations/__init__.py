"""
Knowledge Base Migrations

Database migrations for the knowledge base application.
"""
