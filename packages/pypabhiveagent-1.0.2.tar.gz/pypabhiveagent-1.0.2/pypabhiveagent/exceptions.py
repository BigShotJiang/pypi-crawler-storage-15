"""
Custom exceptions for pypabhiveagent package.
"""


class PyPabHiveAgentError(Exception):
    """Base exception class for pypabhiveagent."""
    pass


class ConfigurationError(PyPabHiveAgentError):
    """Raised when configuration is invalid or incomplete."""
    pass


class HiveQueryError(PyPabHiveAgentError):
    """Raised when Hive query execution fails."""
    pass


class AIGCRequestError(PyPabHiveAgentError):
    """Raised when AIGC API request fails."""
    pass


class ResultParseError(PyPabHiveAgentError):
    """Raised when result parsing fails."""
    pass


class StorageError(PyPabHiveAgentError):
    """Raised when storage operation fails."""
    pass
