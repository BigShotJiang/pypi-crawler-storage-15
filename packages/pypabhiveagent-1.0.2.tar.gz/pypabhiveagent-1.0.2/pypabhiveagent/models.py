"""
Data models for pypabhiveagent package.
"""

from dataclasses import dataclass, field, asdict
from typing import Optional, List, Union, Any
import pandas as pd


@dataclass
class Config:
    """Configuration data model."""
    # AIGC configuration
    url: str = None
    app_id: str = None
    token: str = None
    aigc_app_id: str = None
    
    def validate(self) -> List[str]:
        """
        Validate configuration and return list of missing required fields.
        
        Returns:
            List[str]: List of missing required field names
        """
        required = ['url', 'app_id', 'token', 'aigc_app_id']
        missing = [field_name for field_name in required if not getattr(self, field_name, None)]
        return missing


@dataclass
class QueryResult:
    """Query result data model."""
    success: bool
    message: str
    rows_processed: int = 0
    df: Optional[pd.DataFrame] = None
    excel_path: Optional[str] = None
    hive_table: Optional[str] = None
    errors: List[dict] = field(default_factory=list)
    
    def to_dict(self) -> dict:
        """
        Convert to dictionary.
        Note: DataFrame is included in the dictionary for programmatic access.
        """
        result = asdict(self)
        # Keep DataFrame as-is (don't convert to dict)
        result['df'] = self.df
        return result


@dataclass
class AIGCResponse:
    """AIGC response data model."""
    success: bool
    result: Union[str, dict]
    reasoning: Optional[str] = None
    error: Optional[str] = None
