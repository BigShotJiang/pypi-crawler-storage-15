"""Tests for the views context helpers"""

# pylint: disable=missing-docstring,unused-argument
import datetime as dt
from typing import Any, Generator
from zoneinfo import ZoneInfo

from django.utils import timezone
from unittest_fixtures import Fixtures, fixture, given, where

import gbp_testkit.fixtures as testkit
from gbp_testkit import TestCase
from gbp_testkit.factories import (
    ArtifactFactory,
    BuildFactory,
    BuildRecordFactory,
    package_factory,
)
from gentoo_build_publisher.django.gentoo_build_publisher.views import context as ctx
from gentoo_build_publisher.django.gentoo_build_publisher.views.utils import (
    color_range_from_settings,
    gradient_colors,
)
from gentoo_build_publisher.utils.time import SECONDS_PER_DAY, localtime, utctime


@given(testkit.publisher, localtimezone=testkit.patch)
@where(localtimezone__target="gentoo_build_publisher.utils.time.LOCAL_TIMEZONE")
@where(localtimezone__new=ZoneInfo("America/Chicago"))
class CreateDashboardContextTests(TestCase):
    """Tests for create_dashboard_context()"""

    def input_context(self, **kwargs: Any) -> dict[str, Any]:
        defaults: dict[str, Any] = {"days": 2, "now": timezone.localtime()}
        defaults |= kwargs
        return defaults

    def test(self, fixtures: Fixtures) -> None:
        publisher = fixtures.publisher
        lighthouse1 = BuildFactory(machine="lighthouse")
        for cpv in ["dev-vcs/git-2.34.1", "app-portage/gentoolkit-0.5.1-r1"]:
            publisher.jenkins.artifact_builder.build(lighthouse1, cpv)
        publisher.pull(lighthouse1)

        polaris1 = BuildFactory(machine="polaris")
        publisher.publish(polaris1)
        polaris2 = BuildFactory(machine="polaris")
        publisher.pull(polaris2)

        # Save a record. This doesn't do a pull, so won't emit the signal to update the
        # stats cache. This happens, e.g. when a pull request comes in however the task
        # has yet to complete the request.
        polaris3 = BuildRecordFactory(machine="polaris")
        publisher.repo.build_records.save(polaris3)

        input_context = self.input_context()
        context = ctx.Dashboard.create(**input_context)
        self.assertEqual(len(context.chart_days), 2)
        self.assertEqual(context.build_count, 3)
        self.assertEqual(
            context.build_packages,
            {
                str(lighthouse1): [
                    "app-portage/gentoolkit-0.5.1-r1",
                    "dev-vcs/git-2.34.1",
                ],
                str(polaris2): [],
            },
        )
        self.assertEqual(context.gradient_colors, ["#504575", "#dddaec"])
        self.assertEqual(context.builds_per_machine, [2, 1])
        self.assertEqual(context.machines, ["polaris", "lighthouse"])
        self.assertEqual(context.now, input_context["now"])
        self.assertEqual(context.package_count, 14)
        self.assertEqual(context.unpublished_builds_count, 2)
        self.assertEqual(
            context.total_package_size_per_machine,
            {"lighthouse": 3238, "polaris": 3906},
        )
        self.assertEqual(
            context.recent_packages,
            {
                "app-portage/gentoolkit-0.5.1-r1": {"lighthouse"},
                "dev-vcs/git-2.34.1": {"lighthouse"},
            },
        )

    def test_latest_published(self, fixtures: Fixtures) -> None:
        babette = BuildFactory(machine="babette")
        publisher = fixtures.publisher
        publisher.publish(babette)
        publisher.pull(BuildFactory(machine="lighthouse"))
        publisher.pull(BuildFactory(machine="polaris"))

        context = ctx.Dashboard.create(**self.input_context())
        self.assertEqual(context.latest_published, set([publisher.record(babette)]))
        self.assertEqual(context.unpublished_builds_count, 2)

    def test_builds_over_time_and_build_recently(self, fixtures: Fixtures) -> None:
        publisher = fixtures.publisher
        now = dt.datetime(2024, 1, 17, 4, 51, tzinfo=dt.UTC)
        for machine in ["babette", "lighthouse"]:
            for day in range(2):
                for _ in range(3):
                    record = BuildRecordFactory(
                        machine=machine, submitted=now - dt.timedelta(days=day)
                    )
                    publisher.save(record)
                    publisher.pull(record)
                    if day == 0:
                        break

        context = ctx.Dashboard.create(**self.input_context(now=localtime(now)))

        self.assertEqual(context.builds_over_time, [[3, 1], [3, 1]])
        self.assertEqual(len(context.built_recently), 2)


@fixture(testkit.publisher)
def pf_fixture(fixtures: Fixtures) -> Generator[str, None, None]:
    publisher = fixtures.publisher
    pf = package_factory()
    ab: ArtifactFactory = publisher.jenkins.artifact_builder
    ab.initial_packages = []
    ab.timer = int(localtime(dt.datetime(2024, 1, 16)).timestamp())

    return pf


@given(testkit.publisher, pf_fixture)
class CreateMachineContextTests(TestCase):
    def input_context(self, **kwargs: Any) -> dict[str, Any]:
        defaults: dict[str, Any] = {"days": 2, "now": timezone.localtime()}
        defaults |= kwargs
        return defaults

    def test_average_storage(self, fixtures: Fixtures) -> None:
        publisher = fixtures.publisher
        total_size = 0
        build_size = 0
        artifact_builder = publisher.jenkins.artifact_builder

        for _ in range(3):
            build = BuildFactory()
            for _pkgs in range(3):
                cpv = next(fixtures.pf)
                pkg = artifact_builder.build(
                    build, cpv, build_time=artifact_builder.timer + 3600
                )
                build_size += pkg.size
            total_size += build_size
            publisher.pull(build)

        now = localtime(
            dt.datetime.fromtimestamp(publisher.jenkins.artifact_builder.timer)
        )
        input_context = self.input_context(now=now, machine=build.machine)
        context = ctx.Machine.create(**input_context)

        self.assertEqual(context.average_storage, total_size / 3)

    def test_packages_built_today(self, fixtures: Fixtures) -> None:
        publisher = fixtures.publisher
        for day in [1, 1, 1, 0]:
            publisher.jenkins.artifact_builder.advance(day * SECONDS_PER_DAY)
            build = BuildFactory()
            for _ in range(3):
                cpv = next(fixtures.pf)
                publisher.jenkins.artifact_builder.build(build, cpv)
            publisher.pull(build)

        now = localtime(
            dt.datetime.fromtimestamp(publisher.jenkins.artifact_builder.timer)
        )
        input_context = self.input_context(now=now, machine=build.machine)
        context = ctx.Machine.create(**input_context)

        self.assertEqual(len(context.packages_built_today), 6)

    def test_packages_built_today_when_build_built_is_none(
        self, fixtures: Fixtures
    ) -> None:
        built = utctime(dt.datetime(2021, 4, 25, 7, 50, 7))
        submitted = utctime(dt.datetime(2021, 4, 25, 7, 56, 2))
        completed = utctime(dt.datetime(2021, 4, 25, 7, 56, 36))
        build = BuildFactory()
        publisher = fixtures.publisher

        cpv = "dev-build/autoconf-2.71-r6"
        publisher.jenkins.artifact_builder.timer = int(built.timestamp())
        publisher.jenkins.artifact_builder.build(build, cpv)
        publisher.pull(build)

        # In 2021 GBP didn't have a built field and in the database. They were
        # back-filled to NULL
        publisher.save(
            publisher.record(build),
            built=None,
            submitted=submitted,
            completed=completed,
        )
        now = localtime(dt.datetime(2024, 1, 19, 7, 38))
        input_context = self.input_context(now=now, machine=build.machine)
        context = ctx.Machine.create(**input_context)

        self.assertEqual(len(context.packages_built_today), 0)


@given(testkit.publisher, pf_fixture)
class CreateBuildViewTests(TestCase):
    def test(self, fixtures: Fixtures) -> None:
        build = BuildFactory()
        publisher = fixtures.publisher

        for _ in range(3):
            cpv = next(fixtures.pf)
            publisher.jenkins.artifact_builder.build(build, cpv)
        publisher.pull(build)
        record = publisher.repo.build_records.get(build)

        context = ctx.BuildView.create(build=record)

        expected = ctx.BuildView(
            build=record,
            build_id=record.build_id,
            gradient_colors=gradient_colors(*color_range_from_settings(), 10),
            machine=build.machine,
            packages_built=publisher.storage.get_metadata(record).packages.built,
            total_package_size=sum(
                i.size for i in publisher.storage.get_metadata(record).packages.built
            ),
            published=False,
            tags=[],
        )
        self.assertEqual(expected, context)

        publisher.publish(build)
        context = ctx.BuildView.create(build=record)
        self.assertTrue(context.published)
