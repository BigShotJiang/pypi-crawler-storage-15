"""Tests for gentoo build publisher"""
