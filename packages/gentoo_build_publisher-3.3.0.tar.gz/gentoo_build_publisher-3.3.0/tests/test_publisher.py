"""Tests for the GBP publisher"""

# pylint: disable=missing-docstring,unused-argument
import datetime as dt
from dataclasses import replace
from unittest import TestCase, mock
from zoneinfo import ZoneInfo

from unittest_fixtures import FixtureContext, Fixtures, fixture, given
from yarl import URL

import gbp_testkit.fixtures as testkit
from gbp_testkit.factories import BuildFactory, BuildRecordFactory
from gbp_testkit.helpers import BUILD_LOGS
from gentoo_build_publisher.build_publisher import BuildPublisher
from gentoo_build_publisher.records import BuildRecord
from gentoo_build_publisher.records.memory import RecordDB
from gentoo_build_publisher.settings import Settings
from gentoo_build_publisher.signals import dispatcher
from gentoo_build_publisher.types import Build, Content, GBPMetadata, Package
from gentoo_build_publisher.utils.time import utctime


@given(testkit.tmpdir)
class BuildPublisherFromSettingsTestCase(TestCase):
    def test_from_settings_returns_publisher_with_given_settings(
        self, fixtures: Fixtures
    ) -> None:
        settings = Settings(
            JENKINS_BASE_URL="https://testserver.invalid/",
            RECORDS_BACKEND="memory",
            STORAGE_PATH=fixtures.tmpdir / "test_from_settings",
        )
        pub = BuildPublisher.from_settings(settings)

        self.assertEqual(
            pub.jenkins.config.base_url, URL("https://testserver.invalid/")
        )
        self.assertEqual(pub.storage.root, fixtures.tmpdir / "test_from_settings")
        self.assertIsInstance(pub.repo.build_records, RecordDB)


@given(testkit.build, testkit.publisher)
class BuildPublisherTestCase(TestCase):  # pylint: disable=too-many-public-methods
    def test_publish(self, fixtures: Fixtures) -> None:
        """.publish should publish the build artifact"""
        publisher = fixtures.publisher
        publisher.publish(fixtures.build)

        self.assertIs(publisher.storage.published(fixtures.build), True)

    def test_pull_without_db(self, fixtures: Fixtures) -> None:
        """pull creates db record and pulls from jenkins"""
        publisher = fixtures.publisher
        publisher.pull(fixtures.build)

        self.assertIs(publisher.storage.pulled(fixtures.build), True)
        self.assertIs(publisher.repo.build_records.exists(fixtures.build), True)

    def test_pull_stores_build_logs(self, fixtures: Fixtures) -> None:
        """Should store the logs of the build"""
        publisher = fixtures.publisher
        publisher.pull(fixtures.build)

        url = str(publisher.jenkins.url.logs(fixtures.build))
        publisher.jenkins.get_build_logs_mock_get.assert_called_once_with(url)

        record = publisher.record(fixtures.build)
        self.assertEqual(record.logs, BUILD_LOGS)

    def test_pull_updates_build_models_completed_field(
        self, fixtures: Fixtures
    ) -> None:
        """Should update the completed field with the current timestamp"""
        publisher = fixtures.publisher
        now = utctime()

        with mock.patch("gentoo_build_publisher.build_publisher.utctime") as mock_now:
            mock_now.return_value = now
            publisher.pull(fixtures.build)

        record = publisher.record(fixtures.build)
        self.assertEqual(record.completed, now)

    def test_pull_updates_build_models_built_field(self, fixtures: Fixtures) -> None:
        build = fixtures.build
        publisher = fixtures.publisher

        publisher.pull(build)

        record = publisher.record(build)

        jenkins_timestamp = dt.datetime.fromtimestamp(
            publisher.jenkins.artifact_builder.build_info(build).build_time / 1000,
            dt.UTC,
        ).replace(tzinfo=dt.UTC)
        self.assertEqual(record.built, jenkins_timestamp)

    def test_pull_does_not_download_when_already_pulled(
        self, fixtures: Fixtures
    ) -> None:
        build = fixtures.build
        publisher = fixtures.publisher

        publisher.pull(build)
        assert publisher.pulled(build)

        pulled = publisher.pull(build)

        self.assertFalse(pulled)

    def test_pulled_when_storage_is_ok_but_db_is_not(self, fixtures: Fixtures) -> None:
        # On rare occasion (server crash) the build appears to be extracted but the
        # record.completed field is None.  In this case Publisher.pulled(build) should
        # be False
        build = fixtures.build
        publisher = fixtures.publisher

        with mock.patch.object(
            publisher, "_update_build_metadata"
        ) as update_build_metadata:
            # _update_build_metadata sets the completed attribute
            update_build_metadata.return_value = None, None, None  # dummy values
            publisher.pull(build)

        self.assertFalse(publisher.pulled(build))

    def test_build_timestamps(self, fixtures: Fixtures) -> None:
        datetime = dt.datetime
        localtimezone = "gentoo_build_publisher.utils.time.LOCAL_TIMEZONE"
        publisher = fixtures.publisher

        with mock.patch(localtimezone, new=ZoneInfo("America/New_York")):
            submitted = datetime(2024, 1, 19, 11, 5, 49, tzinfo=dt.UTC)
            now = "gentoo_build_publisher.utils.time.now"
            with mock.patch(now, return_value=submitted):
                publisher.jenkins.artifact_builder.timer = (
                    1705662194  # 2024-01-19 11:03 UTC
                )
                build = BuildFactory()
                publisher.pull(build)
                record = publisher.record(build)

        ct = ZoneInfo("America/Chicago")
        self.assertEqual(record.built, datetime(2024, 1, 19, 5, 3, 24, tzinfo=ct))
        self.assertEqual(record.submitted, datetime(2024, 1, 19, 5, 5, 49, tzinfo=ct))
        self.assertEqual(record.completed, datetime(2024, 1, 19, 5, 5, 49, tzinfo=ct))

    def test_pull_with_note(self, fixtures: Fixtures) -> None:
        publisher = fixtures.publisher
        publisher.pull(fixtures.build, note="This is a test")

        self.assertIs(publisher.storage.pulled(fixtures.build), True)
        build_record = publisher.record(fixtures.build)
        self.assertEqual(build_record.note, "This is a test")

    def test_pull_with_tags(self, fixtures: Fixtures) -> None:
        build = fixtures.build
        tags = {"this", "is", "a", "test"}
        publisher = fixtures.publisher

        publisher.pull(build, tags=tags)

        self.assertIs(publisher.storage.pulled(build), True)
        self.assertEqual(set(publisher.tags(build)), tags)

    def test_update_build_metadata(self, fixtures: Fixtures) -> None:
        # pylint: disable=protected-access
        publisher = fixtures.publisher
        record = publisher.record(fixtures.build)

        publisher._update_build_metadata(record)

        record = publisher.record(fixtures.build)
        self.assertEqual(record.logs, BUILD_LOGS)
        self.assertIsNot(record.completed, None)

    def test_diff_binpkgs_should_be_empty_if_left_and_right_are_equal(
        self, fixtures: Fixtures
    ) -> None:
        left = fixtures.build
        publisher = fixtures.publisher
        publisher.get_packages = mock.Mock(wraps=publisher.get_packages)
        right = left

        # This should actually fail if not short-circuited because the builds have not
        # been pulled
        diff = [*publisher.diff_binpkgs(left, right)]

        self.assertEqual(diff, [])
        self.assertEqual(publisher.get_packages.call_count, 0)

    def test_tags_returns_the_list_of_tags_except_empty_tag(
        self, fixtures: Fixtures
    ) -> None:
        build = fixtures.build
        publisher = fixtures.publisher

        publisher.publish(build)
        publisher.storage.tag(build, "prod")

        self.assertEqual(publisher.storage.get_tags(build), ["", "prod"])
        self.assertEqual(publisher.tags(build), ["prod"])

    def test_tag_tags_the_build_at_the_storage_layer(self, fixtures: Fixtures) -> None:
        build = fixtures.build
        publisher = fixtures.publisher

        publisher.pull(build)
        publisher.tag(build, "prod")
        publisher.tag(build, "albert")

        self.assertEqual(publisher.storage.get_tags(build), ["albert", "prod"])

    def test_untag_removes_tag_from_the_build(self, fixtures: Fixtures) -> None:
        build = fixtures.build
        publisher = fixtures.publisher

        publisher.pull(build)
        publisher.tag(build, "prod")
        publisher.tag(build, "albert")

        publisher.untag(build.machine, "albert")

        self.assertEqual(publisher.storage.get_tags(build), ["prod"])

    def test_untag_with_empty_unpublishes_the_build(self, fixtures: Fixtures) -> None:
        build = fixtures.build
        publisher = fixtures.publisher

        publisher.publish(build)
        self.assertTrue(publisher.published(build))

        publisher.untag(build.machine, "")

        self.assertFalse(publisher.published(build))

    def test_save(self, fixtures: Fixtures) -> None:
        publisher = fixtures.publisher
        r1 = BuildRecordFactory()
        r2 = publisher.save(r1, note="This is a test")

        self.assertEqual(r2.note, "This is a test")

        r3 = publisher.record(Build(r1.machine, r1.build_id))
        self.assertEqual(r2, r3)

    def test_machines(self, fixtures: Fixtures) -> None:
        publisher = fixtures.publisher
        builds = [
            *BuildFactory.create_batch(3, machine="foo"),
            *BuildFactory.create_batch(2, machine="bar"),
            *BuildFactory.create_batch(1, machine="baz"),
        ]
        for build in builds:
            publisher.pull(build)

        machines = publisher.machines()

        self.assertEqual(len(machines), 3)

    def test_machines_with_filter(self, fixtures: Fixtures) -> None:
        publisher = fixtures.publisher
        builds = [
            *BuildFactory.create_batch(3, machine="foo"),
            *BuildFactory.create_batch(2, machine="bar"),
            *BuildFactory.create_batch(1, machine="baz"),
        ]
        for build in builds:
            publisher.pull(build)
        machines = publisher.machines(names={"bar", "baz", "bogus"})

        self.assertEqual(len(machines), 2)

    def test_build_metadata(self, fixtures: Fixtures) -> None:
        """Get a build's GBPMetadata"""
        build = fixtures.build
        publisher = fixtures.publisher
        publisher.pull(build)

        metadata = publisher.build_metadata(build)

        expected = publisher.storage.get_metadata(build)
        self.assertEqual(expected, metadata)

    def test_build_metadata_without_json(self, fixtures: Fixtures) -> None:
        """GBPMetadata without a gbp.json file"""
        build = fixtures.build
        publisher = fixtures.publisher
        publisher.pull(build)
        build = publisher.record(build)
        assert build.completed and build.built
        duration = int((build.completed - build.built).total_seconds())
        expected = replace(
            publisher.storage.get_metadata(build), build_duration=duration
        )
        gbp_json = publisher.storage.get_path(build, Content.BINPKGS) / "gbp.json"
        gbp_json.unlink()

        metadata = publisher.build_metadata(build)

        self.assertEqual(expected, metadata)


@given(testkit.build, testkit.publisher, build2=testkit.build)
class BuildPublisherResolveTagTests(TestCase):
    def test_no_tag(self, fixtures: Fixtures) -> None:
        build = fixtures.build
        machine = build.machine
        publisher = fixtures.publisher

        publisher.pull(build)

        self.assertIsNone(publisher.resolve_tag(f"{machine}@mytag"))

    def test_with_tag(self, fixtures: Fixtures) -> None:
        build = fixtures.build
        machine = build.machine
        publisher = fixtures.publisher

        publisher.pull(build, tags=["mytag"])

        self.assertEqual(
            publisher.record(build), publisher.resolve_tag(f"{machine}@mytag")
        )

    def test_with_published_tag(self, fixtures: Fixtures) -> None:
        build = fixtures.build
        machine = build.machine
        publisher = fixtures.publisher

        publisher.publish(build)

        self.assertEqual(publisher.record(build), publisher.resolve_tag(f"{machine}@"))

    def test_with_published_tag_but_none_published(self, fixtures: Fixtures) -> None:
        build = fixtures.build
        machine = build.machine
        publisher = fixtures.publisher

        publisher.pull(build)

        self.assertIsNone(publisher.resolve_tag(f"{machine}@"))

    def test_with_latest_tag(self, fixtures: Fixtures) -> None:
        machine = fixtures.build.machine
        build2 = fixtures.build2
        publisher = fixtures.publisher

        publisher.pull(fixtures.build)
        publisher.pull(build2)

        self.assertEqual(
            publisher.record(build2), publisher.resolve_tag(f"{machine}@@")
        )

    def test_with_latest_tag_none_pulled(self, fixtures: Fixtures) -> None:
        publisher = fixtures.publisher
        self.assertIsNone(publisher.resolve_tag("bogus@@"))

    def test_published_plus(self, fixtures: Fixtures) -> None:
        publisher = fixtures.publisher
        published_build = fixtures.build
        next_build = fixtures.build2
        machine = fixtures.build.machine

        publisher.publish(published_build)
        publisher.pull(next_build)

        self.assertEqual(
            publisher.record(next_build), publisher.resolve_tag(f"{machine}@+1")
        )

    def test_published_plus_zero(self, fixtures: Fixtures) -> None:
        publisher = fixtures.publisher
        published_build = fixtures.build
        machine = fixtures.build.machine

        publisher.publish(published_build)

        self.assertEqual(
            publisher.record(published_build), publisher.resolve_tag(f"{machine}@+0")
        )

    def test_published_plus_with_no_next(self, fixtures: Fixtures) -> None:
        publisher = fixtures.publisher
        published_build = fixtures.build
        machine = fixtures.build.machine

        publisher.publish(published_build)

        self.assertEqual(None, publisher.resolve_tag(f"{machine}@+2"))

    def test_published_minus(self, fixtures: Fixtures) -> None:
        publisher = fixtures.publisher
        published_build = fixtures.build2
        previous_build = fixtures.build
        machine = fixtures.build.machine

        publisher.pull(previous_build)
        publisher.publish(published_build)

        self.assertEqual(
            publisher.record(previous_build), publisher.resolve_tag(f"{machine}@-1")
        )

    def test_published_minus_zero(self, fixtures: Fixtures) -> None:
        publisher = fixtures.publisher
        published_build = fixtures.build
        machine = fixtures.build.machine

        publisher.publish(published_build)

        self.assertEqual(
            publisher.record(published_build), publisher.resolve_tag(f"{machine}@-0")
        )

    def test_published_minus_with_no_previous(self, fixtures: Fixtures) -> None:
        publisher = fixtures.publisher
        published_build = fixtures.build
        machine = fixtures.build.machine

        publisher.publish(published_build)

        self.assertEqual(None, publisher.resolve_tag(f"{machine}@-2"))

    def test_tagged_plus(self, fixtures: Fixtures) -> None:
        publisher = fixtures.publisher
        tagged_build = fixtures.build
        next_build = fixtures.build2
        machine = fixtures.build.machine

        publisher.pull(tagged_build, tags=["test"])
        publisher.pull(next_build)

        resolved = publisher.resolve_tag(f"{machine}@test+1")

        self.assertEqual(publisher.record(next_build), resolved)

    def test_tagged_minus(self, fixtures: Fixtures) -> None:
        publisher = fixtures.publisher
        tagged_build = fixtures.build2
        previous_build = fixtures.build
        machine = fixtures.build.machine

        publisher.pull(previous_build)
        publisher.pull(tagged_build, tags=["test"])

        self.assertEqual(
            publisher.record(previous_build), publisher.resolve_tag(f"{machine}@test-1")
        )

    def test_no_tag_sym(self, fixtures: Fixtures) -> None:
        publisher = fixtures.publisher
        build = fixtures.build
        publisher.pull(build)
        machine = fixtures.build.machine

        self.assertEqual(None, publisher.resolve_tag(machine))


@given(testkit.build, testkit.publisher)
class BuildPublisherPortageProfileTests(TestCase):
    def test(self, fixtures: Fixtures) -> None:
        build = fixtures.build
        publisher = fixtures.publisher
        publisher.pull(build)

        self.assertEqual(publisher.portage_profile(build), "default/linux/amd64/23.0")


@given(testkit.publisher, record=testkit.build_record)
class BuildPublisherPublishTests(TestCase):
    def test_publishes_build(self, fixtures: Fixtures) -> None:
        publisher: BuildPublisher = fixtures.publisher
        record: BuildRecord = fixtures.record

        self.assertFalse(publisher.published(record))

        publisher.publish(record)

        self.assertTrue(publisher.published(record))

    def test_emits_signal(self, fixtures: Fixtures) -> None:
        publisher: BuildPublisher = fixtures.publisher
        record: BuildRecord = fixtures.record
        called = False

        def handler(build: Build) -> None:
            nonlocal called

            called = True

        dispatcher.bind(published=handler)

        try:
            publisher.publish(record)
        finally:
            dispatcher.unbind(handler)

        self.assertTrue(called)

    def test_already_published_does_not_emit_signal(self, fixtures: Fixtures) -> None:
        publisher: BuildPublisher = fixtures.publisher
        record: BuildRecord = fixtures.record
        called = False

        def handler(build: Build) -> None:
            nonlocal called

            called = True

        publisher.publish(record)
        dispatcher.bind(published=handler)

        try:
            publisher.publish(record)
        finally:
            dispatcher.unbind(handler)

        self.assertFalse(called)


@fixture()
def prepull_events(_fixtures: Fixtures) -> FixtureContext[list[Build]]:
    events: list[Build] = []

    def prepull(build: Build) -> None:
        events.append(build)

    dispatcher.bind(prepull=prepull)

    yield events


@fixture()
def postpull_events(
    _fixtures: Fixtures,
) -> FixtureContext[list[tuple[Build, list[Package], GBPMetadata | None]]]:
    events: list[tuple[Build, list[Package], GBPMetadata | None]] = []

    def postpull(
        *, build: Build, packages: list[Package], gbp_metadata: GBPMetadata | None
    ) -> None:
        events.append((build, packages, gbp_metadata))

    dispatcher.bind(postpull=postpull)

    yield events


@fixture()
def publish_events(_fixtures: Fixtures) -> FixtureContext[list[Build]]:
    events: list[Build] = []

    def publish(build: Build) -> None:
        events.append(build)

    dispatcher.bind(published=publish)

    yield events


@given(testkit.publisher, prepull_events, postpull_events, publish_events)
class DispatcherTestCase(TestCase):
    maxDiff = None

    def test_pull_single(self, fixtures: Fixtures) -> None:
        new_build = BuildFactory()
        publisher = fixtures.publisher
        publisher.pull(new_build)
        record = publisher.record(new_build)

        packages = publisher.storage.get_packages(record)
        expected = (
            record,
            packages,
            publisher.gbp_metadata(publisher.jenkins.get_metadata(new_build), packages),
        )
        self.assertEqual(fixtures.postpull_events, [expected])
        self.assertEqual(fixtures.prepull_events, [new_build])

    def test_pull_multi(self, fixtures: Fixtures) -> None:
        build1 = BuildFactory()
        build2 = BuildFactory(machine="fileserver")
        publisher = fixtures.publisher
        publisher.pull(build1)
        publisher.pull(build2)

        record1 = publisher.record(build1)
        record2 = publisher.record(build2)

        packages = publisher.storage.get_packages(record1)
        event1 = (
            record1,
            packages,
            publisher.gbp_metadata(publisher.jenkins.get_metadata(record1), packages),
        )
        packages = publisher.storage.get_packages(record2)
        event2 = (
            record2,
            packages,
            publisher.gbp_metadata(publisher.jenkins.get_metadata(record2), packages),
        )
        self.assertEqual(fixtures.prepull_events, [build1, build2])
        self.assertEqual(fixtures.postpull_events, [event1, event2])

    def test_publish(self, fixtures: Fixtures) -> None:
        new_build = BuildFactory()
        publisher = fixtures.publisher
        publisher.publish(new_build)

        record = publisher.record(new_build)
        self.assertEqual(fixtures.publish_events, [record])

    def test_tag(self, fixtures: Fixtures) -> None:
        build = BuildFactory()
        publisher = fixtures.publisher
        publisher.pull(build)
        called = False
        tag_given: str | None = None

        def tag_handler(build: Build, tag: str) -> None:
            nonlocal called, tag_given

            called = True
            tag_given = tag

        dispatcher.bind(tagged=tag_handler)

        publisher.tag(build, "test")

        self.assertTrue(called)
        self.assertEqual(tag_given, "test")

    def test_publish_does_not_emit_tagged_signal(self, fixtures: Fixtures) -> None:
        build = BuildFactory()
        publisher = fixtures.publisher
        publisher.pull(build)
        called = False

        def tag_handler(build: Build, tag: str) -> None:
            nonlocal called

            called = True

        dispatcher.bind(tagged=tag_handler)

        publisher.publish(build)

        self.assertFalse(called)

    def test_untag(self, fixtures: Fixtures) -> None:
        build = BuildFactory()
        publisher = fixtures.publisher
        publisher.pull(build, tags=["test"])
        called = False
        tag_given: str | None = None
        build_given: Build | None = None

        def untag_handler(build: Build, tag: str) -> None:
            nonlocal called, tag_given, build_given

            called = True
            tag_given = tag
            build_given = build

        dispatcher.bind(untagged=untag_handler)

        publisher.untag(build.machine, "test")

        self.assertTrue(called)
        self.assertEqual(tag_given, "test")
        self.assertEqual(build_given, publisher.record(build))

    def test_untag_unpublish(self, fixtures: Fixtures) -> None:
        build = BuildFactory()
        publisher = fixtures.publisher
        publisher.publish(build)
        called = False
        tag_given: str | None = None
        build_given: Build | None = None

        def untag_handler(build: Build, tag: str) -> None:
            nonlocal called, tag_given, build_given

            called = True
            tag_given = tag
            build_given = build

        dispatcher.bind(untagged=untag_handler)

        publisher.untag(build.machine, "")

        self.assertTrue(called)
        self.assertEqual(tag_given, "")
        self.assertEqual(build_given, publisher.record(build))

    def test_untag_not_tagged(self, fixtures: Fixtures) -> None:
        """Untagging a machine that doesn't have the tag doesn't emit the signal"""
        build = BuildFactory()
        publisher = fixtures.publisher
        publisher.pull(build)
        called = False

        def untag_handler(build: Build, tag: str) -> None:
            nonlocal called

            called = True

        dispatcher.bind(untagged=untag_handler)

        publisher.untag(build.machine, "test")

        self.assertFalse(called)

    def test_republish_does_not_emit_untagged_signal(self, fixtures: Fixtures) -> None:
        build1 = BuildFactory()
        publisher = fixtures.publisher
        publisher.publish(build1)
        called = False

        def untag_handler(build: Build, tag: str) -> None:
            nonlocal called

            called = True

        dispatcher.bind(untagged=untag_handler)

        build2 = BuildFactory()
        publisher.publish(build2)

        self.assertFalse(called)


@given(testkit.publisher)
class ScheduleBuildTestCase(TestCase):
    """Tests for the schedule_build function"""

    def test(self, fixtures: Fixtures) -> None:
        publisher = fixtures.publisher
        response = publisher.schedule_build("babette")

        self.assertEqual("https://jenkins.invalid/job/babette/build", response)
        self.assertEqual(publisher.jenkins.scheduled_builds, [("babette", {})])
