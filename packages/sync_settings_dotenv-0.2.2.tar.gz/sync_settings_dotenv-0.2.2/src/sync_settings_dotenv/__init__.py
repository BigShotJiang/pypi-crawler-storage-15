from importlib.metadata import version

package_name = "sync-settings-dotenv"
__version__ = version(package_name)
__all__ = [
    "__version__",
]
