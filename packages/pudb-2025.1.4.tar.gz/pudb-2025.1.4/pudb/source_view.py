from __future__ import annotations


__copyright__ = """
Copyright (C) 2009-2017 Andreas Kloeckner
Copyright (C) 2014-2017 Aaron Meurer
"""

__license__ = """
Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
"""
from dataclasses import dataclass
from typing import TYPE_CHECKING, ClassVar

import urwid
from typing_extensions import override


if TYPE_CHECKING:
    from bdb import Breakpoint
    from collections.abc import Collection, Sequence

    from pudb.debugger import DebuggerUI


TABSTOP = 8


@dataclass(eq=False)
class SourceLine(urwid.Widget):
    _sizing: ClassVar[frozenset[urwid.Sizing]] = frozenset([urwid.Sizing.FLOW])

    dbg_ui: DebuggerUI
    text: str
    line_nr: str = ""
    attr: Sequence[tuple[str, int | None]] | None = None
    has_breakpoint: bool = False
    is_current: bool = False
    highlight: bool = False

    @override
    def selectable(self):
        return True

    def set_current(self, is_current: bool):
        self.is_current = is_current
        self._invalidate()

    def set_highlight(self, highlight: bool):
        self.highlight = highlight
        self._invalidate()

    def set_breakpoint(self, has_breakpoint: bool):
        self.has_breakpoint = has_breakpoint
        self._invalidate()

    @override
    def rows(self, size, focus=False):
        return 1

    @override
    def render(self, size: tuple[int, int], focus: bool = False):
        from pudb.debugger import CONFIG
        render_line_nr = CONFIG["line_numbers"]

        maxcol = size[0]
        hscroll = self.dbg_ui.source_hscroll_start

        # attrs is a list of words like "focused" and "breakpoint"
        attrs: list[str] = []

        if self.is_current:
            crnt = ">"
            attrs.append("current")
        else:
            crnt = " "

        if self.has_breakpoint:
            bp = "*"
            attrs.append("breakpoint")
        else:
            bp = " "

        if focus:
            attrs.append("focused")
        elif self.highlight:
            if not self.has_breakpoint:
                attrs.append("highlighted")

        text = self.text
        if not attrs and self.attr is not None:
            attr = [*self.attr, ("source", None)]
        else:
            attr = [(" ".join([*attrs, "source"]), None)]

        from urwid.util import apply_target_encoding, trim_text_attr_cs

        # build line prefix ---------------------------------------------------
        line_prefix = ""
        line_prefix_attr = []

        if render_line_nr and self.line_nr:
            line_prefix_attr = [("line number", len(self.line_nr))]
            line_prefix = self.line_nr

        line_prefix = crnt+bp+line_prefix
        line_prefix_attr = [
            ("current line marker", 1),
             ("breakpoint marker", 1),
             *line_prefix_attr]

        # assume rendered width is same as len
        line_prefix_len = len(line_prefix)

        encoded_line_prefix, line_prefix_cs = apply_target_encoding(line_prefix)

        assert len(encoded_line_prefix) == len(line_prefix)
        # otherwise we'd have to adjust line_prefix_attr... :/

        # shipout, encoding ---------------------------------------------------
        cs = []
        encoded_text_segs = []
        encoded_attr = []

        i = 0
        for seg_attr, seg_len in attr:
            if seg_len is None:
                # means: gobble up remainder of text and rest of line
                # and fill with attribute

                rowlen = hscroll+maxcol
                remaining_text = text[i:]
                encoded_seg_text, seg_cs = apply_target_encoding(
                        remaining_text + rowlen*" ")
                encoded_attr.append((seg_attr, len(remaining_text)+rowlen))
            else:
                unencoded_seg_text = text[i:i+seg_len]
                encoded_seg_text, seg_cs = apply_target_encoding(unencoded_seg_text)

                adjustment = len(encoded_seg_text) - len(unencoded_seg_text)

                encoded_attr.append((seg_attr, seg_len + adjustment))

                i += seg_len

            encoded_text_segs.append(encoded_seg_text)
            cs.extend(seg_cs)

        encoded_text = b"".join(encoded_text_segs)
        encoded_text, encoded_attr, cs = trim_text_attr_cs(
                encoded_text, encoded_attr, cs,
                hscroll, hscroll+maxcol-line_prefix_len)

        encoded_text = encoded_line_prefix + encoded_text
        encoded_attr = line_prefix_attr + encoded_attr
        cs = line_prefix_cs + cs

        return urwid.TextCanvas([encoded_text], [encoded_attr], [cs], maxcol=maxcol)

    def keypress(self, size, key):
        return key


class ParseState:
    """States for the ArgumentParser class"""
    idle = 1
    found_function = 2
    found_open_paren = 3


class ArgumentParser:
    """Parse source code tokens and identify function arguments.

    This parser implements a state machine which accepts
    Pygments tokens, delivered sequentially from the beginning
    of a source file to its end.

    parse_token() processes each token (and its associated string)
    and returns None if that token does not require modification.
    When it finds a token which represents a function
    argument, it returns the correct token type for that
    item (the caller should then replace the associated item's
    token type with the returned type)
    """

    def __init__(self, pygments_token):
        self.t = pygments_token
        self.state = ParseState.idle
        self.paren_level = 0

    def parse_token(self, token, s):
        """Parse token. Return None or replacement token type"""
        if self.state == ParseState.idle:
            if token in (self.t.Name.Function, self.t.Name.Function.Magic):
                self.state = ParseState.found_function
                self.paren_level = 0
        elif self.state == ParseState.found_function:
            if token is self.t.Punctuation and s == "(":
                self.state = ParseState.found_open_paren
                self.paren_level = 1
        else:
            if (token is self.t.Name):
                return self.t.Token.Argument
            elif token is self.t.Punctuation and s == ")":
                self.paren_level -= 1
            elif token is self.t.Punctuation and s == "(":
                self.paren_level += 1
            if self.paren_level == 0:
                self.state = ParseState.idle
        return None


try:
    import pygments  # noqa
except ImportError:
    def format_source(
                debugger_ui: DebuggerUI,
                lines: Sequence[str],
                breakpoints: Collection[int],
            ) -> list[SourceLine]:
        lineno_format = "%%%dd " % (len(str(len(lines))))
        return [
            SourceLine(
                debugger_ui,
                line.rstrip("\n\r").expandtabs(TABSTOP),
                lineno_format % (i+1),
                None,
                has_breakpoint=i+1 in breakpoints,
            )
            for i, line in enumerate(lines)
        ]
else:
    import pygments.token as t
    from pygments import highlight
    from pygments.formatter import Formatter
    from pygments.lexers import PythonLexer

    argument_parser = ArgumentParser(t)

    # NOTE: Tokens of the form t.Token.<name> are not native
    #       Pygments token types; they are user defined token
    #       types.
    #
    #       t.Token is a Pygments token creator object
    #       (see http://pygments.org/docs/tokens/)
    #
    #       The user defined token types get assigned by
    #       one of several translation operations at the
    #       beginning of add_snippet().
    #
    ATTR_MAP = {
        t.Token: "source",
        t.Keyword.Namespace: "namespace",
        t.Token.Argument: "argument",
        t.Token.Dunder: "dunder",
        t.Token.Keyword2: "keyword2",
        t.Keyword: "keyword",
        t.Literal: "literal",
        t.Name: "name",
        t.Name.Exception: "exception",
        t.Name.Function: "function",
        t.Name.Function.Magic: "magic",
        t.Name.Class: "class",
        t.Name.Builtin: "builtin",
        t.Name.Builtin.Pseudo: "pseudo",
        t.Name.Variable.Magic: "magic",
        t.Punctuation: "punctuation",
        t.Operator: "operator",
        t.String: "string",
        t.String.Double: "doublestring",
        t.String.Single: "singlestring",
        t.String.Backtick: "backtick",
        t.String.Doc: "docstring",
        t.Comment: "comment",
    }

    # Token translation table. Maps token types and their
    # associated strings to new token types.
    ATTR_TRANSLATE = {
            t.Keyword: {
                "class": t.Token.Keyword2,
                "def": t.Token.Keyword2,
                "exec": t.Token.Keyword2,
                "lambda": t.Token.Keyword2,
                "print": t.Token.Keyword2,
                },
            t.Operator: {
                ".": t.Token,
                },
            }

    class UrwidFormatter(Formatter[str]):
        result: list[SourceLine]
        current_line: str
        current_attr: list[tuple[str, int]]
        debugger_ui: DebuggerUI
        lineno_format: str
        breakpoints: Sequence[Breakpoint]

        def __init__(self, debugger_ui, lineno_format, breakpoints, **options):
            Formatter.__init__(self, **options)
            self.current_line = ""
            self.current_attr = []
            self.lineno = 1
            self.result = []
            self.debugger_ui = debugger_ui
            self.lineno_format = lineno_format
            self.breakpoints = breakpoints

        def add_snippet(self, ttype, s):
            if not s:
                return

            # Find function arguments. When found, change their
            # ttype to t.Token.Argument
            new_ttype = argument_parser.parse_token(ttype, s)
            if new_ttype:
                ttype = new_ttype

            # Translate tokens
            if ttype in ATTR_TRANSLATE:
                if s in ATTR_TRANSLATE[ttype]:
                    ttype = ATTR_TRANSLATE[ttype][s]

            # Translate dunder method tokens
            # NOTE: leaves "Magic" name tokens alone
            if (ttype == t.Name.Function
                    and s.startswith("__")
                    and s.endswith("__")):
                ttype = t.Token.Dunder

            while ttype not in ATTR_MAP:
                if ttype.parent is not None:
                    ttype = ttype.parent
                else:
                    raise RuntimeError(
                            f"untreated token type: {ttype!s}")

            attr = ATTR_MAP[ttype]

            self.current_line += s
            self.current_attr.append((attr, len(s)))

        def shipout_line(self):
            self.result.append(
                SourceLine(
                    self.debugger_ui,
                    self.current_line,
                    self.lineno_format % self.lineno,
                    self.current_attr,
                    has_breakpoint=self.lineno in self.breakpoints,
                ))
            self.current_line = ""
            self.current_attr = []
            self.lineno += 1

        def format(self, tokensource, outfile):
            for ttype, value in tokensource:
                while True:
                    newline_pos = value.find("\n")
                    if newline_pos == -1:
                        self.add_snippet(ttype, value)
                        break
                    else:
                        self.add_snippet(ttype, value[:newline_pos])
                        self.shipout_line()
                        value = value[newline_pos+1:]

            if self.current_line:
                self.shipout_line()

    def format_source(
                debugger_ui: DebuggerUI,
                lines: Sequence[str],
                breakpoints: Collection[int],
            ) -> list[SourceLine]:
        lineno_format = "%%%dd " % (len(str(len(lines))))
        formatter = UrwidFormatter(debugger_ui, lineno_format, breakpoints)
        highlight(
            "".join(line.expandtabs(TABSTOP) for line in lines),
            PythonLexer(stripnl=False),
            formatter,
        )
        return formatter.result
