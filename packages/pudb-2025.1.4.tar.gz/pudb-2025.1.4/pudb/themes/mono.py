palette_dict = {
    "background": ("standout",),
    "selectable": (),
    "focused selectable": ("underline",),
    "highlighted": ("bold",),
    "hotkey": ("underline, standout",),
}
