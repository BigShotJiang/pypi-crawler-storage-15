from .viewer import start_viewer

if __name__ == "__main__":

    start_viewer()
