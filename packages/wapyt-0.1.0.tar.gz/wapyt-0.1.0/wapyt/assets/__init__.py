"""Static JS/CSS assets evaluated inside Pyodide."""
