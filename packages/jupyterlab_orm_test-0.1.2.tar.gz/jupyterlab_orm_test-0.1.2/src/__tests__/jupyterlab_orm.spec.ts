/**
 * Tests for the jupyterlab-orm extension
 */

import { JupyterFrontEnd } from '@jupyterlab/application';

import { track } from '@oreillymedia/fe-analytics';
import { clientType, meterType } from '@oreillymedia/usage-meter';

import { requestAPI } from '../handler';
import plugin from '../index';

// Mock all external dependencies
jest.mock('@jupyterlab/coreutils', () => ({
  URLExt: {
    join: jest.fn((...args) => args.join('/'))
  }
}));

// Mock server connection
jest.mock('@jupyterlab/services', () => {
  const mockNetworkError = jest.fn(
    error => new Error(`Network: ${error.message || 'Error'}`)
  );
  mockNetworkError.prototype = Object.create(Error.prototype);
  mockNetworkError.prototype.name = 'NetworkError';

  const mockResponseError = jest.fn(
    (response, message) => new Error(`Response: ${message}`)
  );
  mockResponseError.prototype = Object.create(Error.prototype);
  mockResponseError.prototype.name = 'ResponseError';

  return {
    ServerConnection: {
      makeSettings: jest.fn(() => ({
        baseUrl: 'http://localhost:8888/'
      })),
      makeRequest: jest.fn(),
      NetworkError: mockNetworkError,
      ResponseError: mockResponseError
    }
  };
});

// Mock O'Reilly analytics
jest.mock('@oreillymedia/fe-analytics', () => ({
  track: jest.fn()
}));

// Mock O'Reilly usage meter
jest.mock('@oreillymedia/usage-meter', () => ({
  clientType: {
    web: 'web',
    mobile: 'mobile'
  },
  meterType: {
    usage: 'usage',
    time: 'time'
  }
}));

// Mock the requestAPI for the plugin tests
jest.mock('../handler', () => ({
  requestAPI: jest.fn()
}));

// Tests for the plugin.ts file
describe('jupyterlab-orm plugin', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    jest.spyOn(console, 'log').mockImplementation(() => {});
    jest.spyOn(console, 'error').mockImplementation(() => {});
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  it('should have correct plugin id and autoStart set to true', () => {
    expect(plugin.id).toBe('jupyterlab-orm:plugin');
    expect(plugin.autoStart).toBe(true);
  });

  describe('activate', () => {
    it("should log activation message and verify O'Reilly library imports on plugin activation", () => {
      const mockApp = {} as JupyterFrontEnd;

      // Set up the mock to prevent undefined errors
      (requestAPI as jest.Mock).mockImplementation(() => {
        return Promise.resolve({});
      });

      // Call the activation function
      plugin.activate(mockApp);

      // Verify console logs
      expect(console.log).toHaveBeenCalledWith(
        'JupyterLab extension jupyterlab-orm is activated!!'
      );
      expect(console.log).toHaveBeenCalledWith(
        "O'Reilly Media Usage Meter import test"
      );
      expect(console.log).toHaveBeenCalledWith(
        `Client types: ${Object.keys(clientType)}`
      );
      expect(console.log).toHaveBeenCalledWith(
        `Meter types: ${Object.keys(meterType)}`
      );
      expect(console.log).toHaveBeenCalledWith(
        "O'Reilly Media FE Analytics import test"
      );
      expect(console.log).toHaveBeenCalledWith(`track function: ${track}`);
    });

    it('should call requestAPI with get-example endpoint and log received data on success', async () => {
      const mockApp = {} as JupyterFrontEnd;
      const mockResponseData = { test: 'data' };

      // Set up the mock to resolve with our test data
      (requestAPI as jest.Mock).mockImplementation(() => {
        return Promise.resolve(mockResponseData);
      });

      // Call the activation function
      plugin.activate(mockApp);

      // Wait for any promises to resolve
      await new Promise(resolve => setTimeout(resolve, 0));

      // Verify the success path
      expect(console.log).toHaveBeenCalledWith(
        'Received env vars from backend extension:',
        mockResponseData
      );
    });

    it('should log error message when requestAPI fails indicating missing server extension', async () => {
      const mockApp = {} as JupyterFrontEnd;
      const mockError = new Error('API error');

      // Set up the mock to reject with our error
      (requestAPI as jest.Mock).mockImplementation(() => {
        return Promise.reject(mockError);
      });

      // Call the activation function
      plugin.activate(mockApp);

      // Wait for any promises to resolve
      await new Promise(resolve => setTimeout(resolve, 0));

      // Verify the error path
      expect(console.error).toHaveBeenCalledWith(
        expect.stringContaining(
          'The jupyterlab_orm server extension appears to be missing'
        )
      );
    });
  });
});
