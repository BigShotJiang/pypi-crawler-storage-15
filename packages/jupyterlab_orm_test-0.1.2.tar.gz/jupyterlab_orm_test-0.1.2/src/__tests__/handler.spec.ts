/**
 * Tests for the handler.ts file
 */

import { URLExt } from '@jupyterlab/coreutils';
import { ServerConnection } from '@jupyterlab/services';

import { requestAPI } from '../handler';

// Mock all external dependencies
jest.mock('@jupyterlab/coreutils', () => ({
  URLExt: {
    join: jest.fn((...args) => args.join('/'))
  }
}));

// Mock server connection
jest.mock('@jupyterlab/services', () => {
  const mockNetworkError = jest.fn(
    error => new Error(`Network: ${error.message || 'Error'}`)
  );
  mockNetworkError.prototype = Object.create(Error.prototype);
  mockNetworkError.prototype.name = 'NetworkError';

  const mockResponseError = jest.fn(
    (response, message) => new Error(`Response: ${message}`)
  );
  mockResponseError.prototype = Object.create(Error.prototype);
  mockResponseError.prototype.name = 'ResponseError';

  return {
    ServerConnection: {
      makeSettings: jest.fn(() => ({
        baseUrl: 'http://localhost:8888/'
      })),
      makeRequest: jest.fn(),
      NetworkError: mockNetworkError,
      ResponseError: mockResponseError
    }
  };
});

describe('handler.ts', () => {
  // Common test setup and teardown
  beforeEach(() => {
    jest.clearAllMocks();
    jest.spyOn(console, 'log').mockImplementation(() => {});
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  describe('requestAPI', () => {
    /**
     * Helper to create a mock response object
     */
    const createMockResponse = (options: {
      isOk: boolean;
      responseData: string | object;
    }): Partial<Response> => {
      const { isOk, responseData } = options;
      const responseText =
        typeof responseData === 'string'
          ? responseData
          : JSON.stringify(responseData);

      return {
        ok: isOk,
        text: jest.fn().mockResolvedValue(responseText)
      };
    };

    describe('URL handling', () => {
      it('should construct URL by joining base URL, API namespace, and endpoint', async () => {
        // Setup successful response
        const mockResponse = createMockResponse({
          isOk: true,
          responseData: { data: 'test' }
        });
        (ServerConnection.makeRequest as jest.Mock).mockResolvedValue(
          mockResponse
        );

        // Call the function
        const result = await requestAPI<{ data: string }>('test-endpoint');

        // Verify correct URL construction
        expect(URLExt.join).toHaveBeenCalledWith(
          'http://localhost:8888/',
          'jupyterlab-orm',
          'test-endpoint'
        );

        // Verify makeRequest was called correctly
        expect(ServerConnection.makeRequest).toHaveBeenCalled();

        // Verify the result
        expect(result).toEqual({ data: 'test' });
      });

      it('should use empty string as endpoint when no endpoint parameter is provided', async () => {
        // Setup successful response
        const mockResponse = createMockResponse({
          isOk: true,
          responseData: 'arbitrary response text'
        });
        (ServerConnection.makeRequest as jest.Mock).mockResolvedValue(
          mockResponse
        );

        // Call the function
        await requestAPI();

        // Verify correct URL construction with empty endpoint
        expect(URLExt.join).toHaveBeenCalledWith(
          'http://localhost:8888/',
          'jupyterlab-orm',
          ''
        );
      });
    });

    describe('error handling', () => {
      it('should wrap network errors in ServerConnection.NetworkError when request fails', async () => {
        // Setup network error
        const networkError = new Error('Network error');
        (ServerConnection.makeRequest as jest.Mock).mockRejectedValue(
          networkError
        );

        // Call the function and expect it to throw
        await expect(requestAPI('test-endpoint')).rejects.toThrow();

        // Verify the error was properly wrapped
        expect(ServerConnection.NetworkError).toHaveBeenCalledWith(
          networkError
        );
      });

      it('should throw ResponseError with message when response is not ok and has message property', async () => {
        // Setup error response with message
        const mockResponse = createMockResponse({
          isOk: false,
          responseData: { message: 'Error message' }
        });
        (ServerConnection.makeRequest as jest.Mock).mockResolvedValue(
          mockResponse
        );

        // Call the function and expect it to throw
        await expect(requestAPI('test-endpoint')).rejects.toThrow();

        // Verify ResponseError was called with the correct parameters
        expect(ServerConnection.ResponseError).toHaveBeenCalled();
      });

      it('should throw ResponseError with raw data when response is not ok and lacks message property', async () => {
        // Setup error response without message property
        const mockResponse = createMockResponse({
          isOk: false,
          responseData: 'Plain error message'
        });
        (ServerConnection.makeRequest as jest.Mock).mockResolvedValue(
          mockResponse
        );

        // Call the function and expect it to throw
        await expect(requestAPI('test-endpoint')).rejects.toThrow();

        // Verify ResponseError was called
        expect(ServerConnection.ResponseError).toHaveBeenCalled();
      });
    });

    describe('response parsing', () => {
      it('should parse and return JSON data when response contains valid JSON', async () => {
        // Setup JSON response
        const testData = { key: 'value', nested: { item: 42 } };
        const mockResponse = createMockResponse({
          isOk: true,
          responseData: testData
        });
        (ServerConnection.makeRequest as jest.Mock).mockResolvedValue(
          mockResponse
        );

        // Call the function
        const result = await requestAPI<typeof testData>('test-endpoint');

        // Verify result matches expected data
        expect(result).toEqual(testData);
      });

      it('should log warning and return raw text when response is not valid JSON', async () => {
        // Setup non-JSON response
        const mockResponse = createMockResponse({
          isOk: true,
          responseData: 'Not a JSON string'
        });
        (ServerConnection.makeRequest as jest.Mock).mockResolvedValue(
          mockResponse
        );

        // Call the function
        const result = await requestAPI<string>('test-endpoint');

        // Verify console.log was called with a warning
        expect(console.log).toHaveBeenCalledWith(
          'Not a JSON response body.',
          mockResponse
        );

        // Verify the raw text was returned
        expect(result).toBe('Not a JSON string');
      });

      it('should return empty string without parsing when response body is empty', async () => {
        // Setup empty response
        const mockResponse: Partial<Response> = {
          ok: true,
          text: jest.fn().mockResolvedValue('')
        };
        (ServerConnection.makeRequest as jest.Mock).mockResolvedValue(
          mockResponse
        );

        // Call the function
        const result = await requestAPI<string>('test-endpoint');

        // Verify the empty string is returned directly
        expect(result).toBe('');
      });
    });
  });
});
