import json
import os

import tornado
from jupyter_server.base.handlers import APIHandler
from jupyter_server.utils import url_path_join


class RouteHandler(APIHandler):
    # The following decorator should be present on all verb methods (head, get, post,
    # patch, put, delete, options) to ensure only authorized user can request the
    # Jupyter server
    @tornado.web.authenticated
    def get(self) -> None:
        self.finish(json.dumps(dict(os.environ)))


class ShareNotebookHandler(APIHandler):
    @tornado.web.authenticated
    def post(self) -> None:
        # Get data from the request
        data = json.loads(self.request.body)
        email = data.get("email")
        notebook_path = data.get("notebook_path")
        username = self.current_user.username
        print("=" * 50)
        print(f"User: {username}")
        print(f"notebook: {notebook_path}")
        print(f"email: {email}")
        print("base_url:", self.base_url)
        print(f"request.uri: {self.request.uri}")
        print("\nENVIRONMENT VARIABLES:")
        print(f"JUPYTERHUB_USER: {os.environ.get('JUPYTERHUB_USER')}")
        print(f"JUPYTERHUB_SERVER_NAME: {os.environ.get('JUPYTERHUB_SERVER_NAME')}")
        print(f"JUPYTERHUB_BASE_URL: {os.environ.get('JUPYTERHUB_BASE_URL')}")
        print(
            f"JUPYTERHUB_SERVICE_PREFIX: {os.environ.get('JUPYTERHUB_SERVICE_PREFIX')}"
        )
        print("=" * 50)

        server_name = os.environ.get("JUPYTERHUB_SERVER_NAME", "default")

        # TODO: Your sharing logic here
        # For now, just return success
        self.finish(
            json.dumps(
                {"success": True, "message": f"Shared {notebook_path} with {email}"}
            )
        )


def setup_handlers(web_app: tornado.web.Application) -> None:
    host_pattern = ".*$"

    base_url = web_app.settings["base_url"]
    # Define all your routes
    handlers = [
        (url_path_join(base_url, "jupyterlab-orm", "get-example"), RouteHandler),
        (url_path_join(base_url, "jupyterlab-orm", "share"), ShareNotebookHandler),
    ]
    web_app.add_handlers(host_pattern, handlers)
