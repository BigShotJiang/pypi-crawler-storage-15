"""Economy shipping module."""
