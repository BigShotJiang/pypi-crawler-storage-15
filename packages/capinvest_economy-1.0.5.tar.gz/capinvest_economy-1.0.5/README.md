# CapInvest Economy Extension

The Economy extension provides global macroeconomic data access for the CapInvest Platform.

 

