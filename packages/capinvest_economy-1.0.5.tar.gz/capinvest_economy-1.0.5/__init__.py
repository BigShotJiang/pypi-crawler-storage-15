"""CapInvest Economy Extension."""
