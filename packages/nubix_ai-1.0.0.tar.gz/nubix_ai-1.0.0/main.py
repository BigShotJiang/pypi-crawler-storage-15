def main():
    print("Hello from nubix-library!")


if __name__ == "__main__":
    main()
