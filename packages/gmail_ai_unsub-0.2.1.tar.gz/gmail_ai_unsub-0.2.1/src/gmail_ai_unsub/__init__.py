"""Gmail AI Unsubscribe Tool - AI-powered email management."""

__version__ = "0.1.0"
