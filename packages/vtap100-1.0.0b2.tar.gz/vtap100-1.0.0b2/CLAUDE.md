Erste Directive:

- IMMER TDD! Erst tests schreiben oder updaten, dann den Applikationscode.
- gute UX und Doku sind Pflicht
- folge dem DRY Prinzip
- verwende früh WebSearch, z.B wenn Du zu wenig oder alte Info hast oder bei einem Problem nicht weiterkommst

Sprache:
- Sprache der Software ist Englisch und Deutsch, alle TUI Texte und Hilfen werden übersetzt.
- Sprache der Prompts und Pläne kann gerne Deutsch sein.

Pläne:
- immer auch unter ./docs ablegen, immer PLAN_[THEMA].md

Dokumentation ist auch unter ./docs abzulegen. Ausgenommen davon sind Hilfetexte fùr das Programm.
