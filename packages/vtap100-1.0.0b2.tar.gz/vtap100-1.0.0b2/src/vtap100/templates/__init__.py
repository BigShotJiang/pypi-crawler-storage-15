"""Pre-defined configuration templates for common use cases."""
