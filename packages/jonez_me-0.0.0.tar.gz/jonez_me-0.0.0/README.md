# Jonez-me

A tiny, aesthetic Python package that lets you instantly get to know **Jonez** —
AI & Data Science student, builder, petrolhead, and chaos-tamer.

## 📦 Install

```bash
pip install Jonez-me


import jonez_me

jonez_me.bio()
jonez_me.skills()
jonez_me.education()
jonez_me.projects()
jonez_me.fun_fact()




