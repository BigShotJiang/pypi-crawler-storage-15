from .core import bio, skills, projects, education, fun_fact
