# core.py

RESET = "\033[0m"
BOLD = "\033[1m"
CYAN = "\033[96m"
MAGENTA = "\033[95m"
YELLOW = "\033[93m"

def bio():
    print(f"""
{BOLD}{CYAN}Hey there! I'm Jonez 👋{RESET}

Currently pursuing my 3rd year of B.Tech in Artificial Intelligence & Data Science.
I’m all about:
- Tech that makes life easier  
- Building things that shouldn’t technically work but somehow do  
- Automobiles & motorsport engineering 🏎️  
- Event ops, organizing chaos, and shipping things that matter  

Driven by a get-it-done mindset with an eye for quality and impact.
""")

def skills():
    print(f"""
{BOLD}{MAGENTA}⚡ Technical Skills{RESET}
- Python, C, Java, R  
- HTML, CSS  
- Machine Learning & NLP  
- LLM-based analysis (Falcon models, summarization, classification)  
- Automation, workflow design, embedded systems tinkering  
- Marketing, sponsorship, event operations  
""")

def projects():
    print(f"""
{BOLD}{YELLOW}🚀 Selected Projects & Work{RESET}

- {BOLD}Scam Sam – Scam Call Detection System{RESET}
  Uses Falcon-7B LLM to analyze transcripts and predict scam probability.

- {BOLD}RedditYou (formerly Reddyit){RESET}
  A partially automated YouTube channel that generates short-form content
  using an open-source script (RedditVideoMakerBot).

- {BOLD}Obstacle Detection Car{RESET}
  Built using ESP32, ultrasonic sensors, servo & motor drivers.

- {BOLD}Portfolio Website{RESET}
  Designed & built a fully responsive personal portfolio.

- {BOLD}Chakravyuham CTF (ARTICON){RESET}
  Organized and executed a full-fledged CTF event with custom challenges.

- {BOLD}Overdrive Racing – Marketing & Sponsorship Lead{RESET}
  Part of the team that built an open-wheel racecar from scratch.
  Winners of the SUPRA SAEINDIA 2025 Cost Event.
""")

def education():
    print(f"""
{BOLD}{CYAN}🎓 Education{RESET}
B.Tech – Artificial Intelligence & Data Science  
Rajagiri School of Engineering & Technology (2023–2027)  
CGPA: 8.4  

Class 12 – Deepthi HSS (Unaided)  
Percentage: 94.8%

Class 10 – Hari Sri Vidya Nidhi School (ICSE)  
Percentage: 90%
""")

def fun_fact():
    print(f"""
{BOLD}{MAGENTA}✨ Fun Fact{RESET}
I’ve organized everything from CTFs to EV workshops to wiki-speedrun tournaments.
If there’s an event, I’ll find a way to run it smoother, louder, and cooler.

Also:  
Ask me about automobiles and AI in the same conversation and  
I might accidentally give a TED talk. 😌
""")
