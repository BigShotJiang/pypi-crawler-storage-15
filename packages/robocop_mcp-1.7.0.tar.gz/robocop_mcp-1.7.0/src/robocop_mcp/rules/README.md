This folder contains the default custom rules which are passed to LLM
to fix errors and warnings in Robot Framework test data.