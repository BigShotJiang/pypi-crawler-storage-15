With a duplicate test names add a running index index in the test name with three digits.
Number must start from one. The first number must be 001 and second index must be 002.
Index must restart when moving to new file and suite.
