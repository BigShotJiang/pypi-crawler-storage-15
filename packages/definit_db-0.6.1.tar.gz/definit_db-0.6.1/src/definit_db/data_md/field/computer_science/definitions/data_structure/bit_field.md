# bit_field


A bit field is a [data structure](computer_science/data_structure) that consist of one or more adjacent 
[bits](computer_science/bit) which have been allocated for specific purposes, so that any single bit or 
group of bits within the structure can be set or inspected.

