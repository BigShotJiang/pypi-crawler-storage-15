# right shift


[right shift](computer_science/right shift) is a [bitwise operation](computer_science/bitwise operation) 
that shifts all [bits](computer_science/bit) in a 
[binary representation](computer_science/binary representation) to the right by a 
specified number of positions. Right shift by one position is equivalent to 
[integer](mathematics/integer) division by 2.

