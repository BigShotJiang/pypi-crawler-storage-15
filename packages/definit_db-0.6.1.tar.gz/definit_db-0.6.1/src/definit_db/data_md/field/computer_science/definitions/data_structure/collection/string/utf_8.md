# utf_8


A [UTF](computer_science/utf) [character encoding](computer_science/character_encoding) 
scheme that uses 1 to 4 bytes to represent [Unicode](computer_science/unicode) characters. It is 
backward compatible with ASCII and can represent any character in the Unicode standard.

