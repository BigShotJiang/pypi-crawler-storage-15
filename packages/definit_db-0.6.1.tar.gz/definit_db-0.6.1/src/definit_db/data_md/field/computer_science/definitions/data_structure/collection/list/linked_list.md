# linked_list


An ordered [collection](computer_science/collection) of elements. Each element is stored in a 
[node](mathematics/node) that contains a reference to the next node in the list. Linked lists can 
be singly linked or doubly linked, depending on whether each node has a reference to the next node only or both the 
next and previous nodes.

