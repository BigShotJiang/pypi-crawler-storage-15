# program


[program](computer_science/program) is a [sequence](mathematics/sequence) of [instructions](mathematics/instruction) that a [computer](computer_science/computer) 
can execute to perform a specific task. A program defines the [operations](computer_science/operation) that should be carried out and 
the order in which they should be executed.

