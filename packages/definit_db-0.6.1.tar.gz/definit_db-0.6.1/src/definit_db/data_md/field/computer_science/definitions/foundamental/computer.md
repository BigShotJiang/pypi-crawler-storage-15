# computer


[computer](computer_science/computer) is a device that can execute [instructions](mathematics/instruction) 
to process [information](computer_science/data) and perform tasks automatically. A computer can store, retrieve, and manipulate 
data according to instructions.

