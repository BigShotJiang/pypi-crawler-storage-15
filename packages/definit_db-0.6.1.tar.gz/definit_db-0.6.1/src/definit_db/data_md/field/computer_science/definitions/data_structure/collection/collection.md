# collection


Collection is an [abstract data type](computer_science/abstract_data_type) that groups some variable 
number of [data structures](computer_science/data_structure) (possibly zero) that have some shared 
significance to the problem being solved and need to be [operated](computer_science/operation) upon 
together in some controlled fashion.

