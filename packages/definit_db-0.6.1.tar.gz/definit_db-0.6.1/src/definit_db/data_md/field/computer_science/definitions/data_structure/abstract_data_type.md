# abstract_data_type


Abstract data type (ADT) is a mathematical model for [data type](computer_science/data_type), defined by 
its behavior from the point of view of a user of the [data](computer_science/data), specifically in terms 
of possible values, possible [operations](computer_science/operation) on data of this 
[data type](computer_science/data_type), and the behavior of these 
[operations](computer_science/operation).

