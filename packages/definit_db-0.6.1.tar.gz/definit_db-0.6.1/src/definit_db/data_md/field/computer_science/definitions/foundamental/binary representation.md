# binary representation


[binary representation](computer_science/binary representation) is a way of expressing [information](mathematics/information) using only two symbols, typically 0 and 1. 
In this system, each digit is called a [bit](computer_science/bit), and [sequences](mathematics/sequence) of bits are used to represent [numbers](mathematics/number) 
and other types of information.

