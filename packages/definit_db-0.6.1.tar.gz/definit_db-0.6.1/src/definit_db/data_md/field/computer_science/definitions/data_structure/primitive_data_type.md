# primitive_data_type


Primitive data types are a [set](mathematics/set) of basic 
[data structures](computer_science/data_structure) from which all other data types are constructed.

