# bag


A bag is a [collection](computer_science/collection) that allows for the storage of multiple items, 
where the same item can be stored multiple times. It is similar to a 
[multiset](mathematics/multiset), but does not require any specific ordering of the items. Removing 
items is not supported. A bag allows to iterate through the collected items.

