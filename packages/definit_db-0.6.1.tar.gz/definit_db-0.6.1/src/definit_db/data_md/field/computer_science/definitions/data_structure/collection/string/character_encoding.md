# character_encoding


A method of representing characters as numerical values, allowing computers to store and manipulate text. 
Character encoding schemes define the [mapping](computer_science/map) between characters and their 
corresponding numerical values.

