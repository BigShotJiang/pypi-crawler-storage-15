# operation


Operation is an action that is carried out to accomplish a given task. In the most simple scenario, it is an 
action performed on at least one [object](computer_science/object).

