# list


An ordered [collection](computer_science/collection). Also known as a sequence. One can add, remove, and 
pop any element from the list. List can store elements of different [types](computer_science/data_type).

