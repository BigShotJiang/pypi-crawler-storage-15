# data_type


Data type (or simply type) is a grouping of [data](computer_science/data) values, usually specified by a 
[set](mathematics/set) of possible values, a [set](mathematics/set) of allowed 
operations on these values, and/or a representation of these values as machine types.

