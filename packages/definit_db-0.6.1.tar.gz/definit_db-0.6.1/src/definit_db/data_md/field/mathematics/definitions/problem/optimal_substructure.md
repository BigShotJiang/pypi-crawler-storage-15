# optimal_substructure


A [problem](mathematics/problem) is said to have optimal substructure if an 
[optimal solution](mathematics/optimal_solution) can be constructed from optimal solutions of its 
[subproblems](mathematics/subproblem).

