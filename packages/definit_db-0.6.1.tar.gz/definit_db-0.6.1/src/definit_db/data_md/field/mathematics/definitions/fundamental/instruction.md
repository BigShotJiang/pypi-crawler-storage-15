# instruction


A detailed [information](mathematics/information) about how something should be done or operated.

