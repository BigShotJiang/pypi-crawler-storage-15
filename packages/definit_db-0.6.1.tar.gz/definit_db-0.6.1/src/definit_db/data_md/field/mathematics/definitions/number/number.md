# number

A number is a mathematical [object](mathematics/object) used to count, measure, and label.
