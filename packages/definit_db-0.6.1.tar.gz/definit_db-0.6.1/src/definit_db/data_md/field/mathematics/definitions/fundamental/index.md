# index


[index](mathematics/index) is an [integer](mathematics/integer) value that identifies the position of an element 
within a [sequence](mathematics/sequence). Indices are used to access, modify, or reference specific 
elements, and can be zero-based (starting at 0) or one-based (starting at 1) depending on the context.

