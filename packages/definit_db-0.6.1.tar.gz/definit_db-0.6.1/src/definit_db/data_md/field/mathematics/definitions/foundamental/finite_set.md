# finite_set

Finite set is a [set](mathematics/set) that has a finite number of elements. Informally, a finite set is a set which one could in principle count and finish counting. For example, {2,4,6,8,10} is a finite set with five elements.
