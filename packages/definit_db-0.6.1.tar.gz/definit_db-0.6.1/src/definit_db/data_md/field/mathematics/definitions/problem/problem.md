# problem


A question or a challenge defined in a formal way.

