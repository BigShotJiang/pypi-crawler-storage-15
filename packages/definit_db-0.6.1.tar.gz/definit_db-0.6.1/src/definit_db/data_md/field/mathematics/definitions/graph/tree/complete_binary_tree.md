# complete_binary_tree


A [binary tree](mathematics/binary_tree) in which every level, except possibly the last, is 
completely filled, and all [nodes](mathematics/node) are as far left as possible. In a complete 
binary tree, all nodes at the last level are filled from left to right. It can have between 1 and 2h nodes at 
the last level h.

