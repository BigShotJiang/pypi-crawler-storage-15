# bound


A limit on the values that a [function](mathematics/function) or expression can take. A bound constrains or 
restricts the range or growth of values, providing a reference point for comparison.

