# hash_function

A function that for an input [object](mathematics/object) assigns a fixed-size text. The text is typically a 'digest' that is unique to each unique input.
