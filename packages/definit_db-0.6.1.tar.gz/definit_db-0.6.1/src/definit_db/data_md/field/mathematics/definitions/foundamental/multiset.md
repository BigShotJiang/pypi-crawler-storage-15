# multiset

A multiset is a [set](mathematics/set) that allows for multiple occurrences of the same element. Unlike a traditional set, which only allows unique elements, a multi-set can contain duplicates. This means that the same element can appear more than once.
