# integer

An integer is the [number](mathematics/number) zero (0), a positive natural number (1, 2, 3, ...), or the negation of a positive natural number (-1, -2, -3, ...). The negations or additive inverses of the positive natural numbers are referred to as negative integers.
