# sequence

A collection of [objects](mathematics/object) in which repetitions are allowed and order matters.
