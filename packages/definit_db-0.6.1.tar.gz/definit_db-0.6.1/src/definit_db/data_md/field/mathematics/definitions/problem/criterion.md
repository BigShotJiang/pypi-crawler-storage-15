# criterion


A standard or principle by which something is judged or decided.

