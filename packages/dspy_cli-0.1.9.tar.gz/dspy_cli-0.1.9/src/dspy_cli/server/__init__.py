"""FastAPI server implementation."""
