"""GitHub repository management utilities.

This package provides utilities for managing GitHub repositories, including
branch protection rulesets, repository settings, and GitHub API interactions.
"""
