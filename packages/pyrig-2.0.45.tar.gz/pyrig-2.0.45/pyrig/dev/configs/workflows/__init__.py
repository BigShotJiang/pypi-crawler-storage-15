"""GitHub Actions workflow configuration management.

This package provides ConfigFile subclasses for creating and managing
GitHub Actions workflow files for CI/CD automation.
"""
