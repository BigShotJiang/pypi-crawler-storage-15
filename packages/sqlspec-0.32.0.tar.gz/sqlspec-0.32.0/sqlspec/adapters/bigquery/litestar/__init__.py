"""BigQuery Litestar integration."""

from sqlspec.adapters.bigquery.litestar.store import BigQueryStore

__all__ = ("BigQueryStore",)
