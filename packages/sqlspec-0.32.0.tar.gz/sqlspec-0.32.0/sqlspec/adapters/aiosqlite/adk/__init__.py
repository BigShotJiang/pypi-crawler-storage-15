"""Aiosqlite ADK integration for Google Agent Development Kit."""

from sqlspec.adapters.aiosqlite.adk.store import AiosqliteADKStore

__all__ = ("AiosqliteADKStore",)
