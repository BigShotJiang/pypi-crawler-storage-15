"""Litestar extension migrations for session table creation."""

__all__ = ()
