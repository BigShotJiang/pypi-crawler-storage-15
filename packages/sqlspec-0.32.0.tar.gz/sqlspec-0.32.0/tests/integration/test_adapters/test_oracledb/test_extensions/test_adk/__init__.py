"""Tests for OracleDB ADK store implementation."""
