"""AsyncMy extensions integration tests."""
