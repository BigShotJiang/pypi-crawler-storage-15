"""Integration tests for AioSQLite Litestar extensions."""
