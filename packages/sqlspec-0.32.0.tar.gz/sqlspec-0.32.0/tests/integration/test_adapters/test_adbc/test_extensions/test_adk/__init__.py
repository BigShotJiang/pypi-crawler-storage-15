"""ADBC ADK integration tests."""
