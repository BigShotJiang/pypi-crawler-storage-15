"""AsyncPG extensions tests."""
