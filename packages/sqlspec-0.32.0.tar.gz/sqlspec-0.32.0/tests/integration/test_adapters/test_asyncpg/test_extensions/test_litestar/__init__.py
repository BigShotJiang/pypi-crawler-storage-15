"""Integration tests for AsyncPG Litestar extensions."""
