from .mrtsboosting import MRTSBoostingClassifier

__all__ = ['MRTSBoostingClassifier']
__version__ = "0.1.0"