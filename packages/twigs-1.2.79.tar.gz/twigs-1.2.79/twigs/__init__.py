# -*- coding: utf-8 -*-

"""Top-level package for twigs. """ 

__author__ = """Paresh Borkar"""
__email__ = 'opensource@threatwatch.io'
__version__ = '1.2.79'
