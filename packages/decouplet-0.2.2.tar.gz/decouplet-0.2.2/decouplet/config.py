import os

from decouple import AutoConfig, Config

from .secrets import CompositeRepository, RepositorySecret

autoconfig = AutoConfig(search_path=os.getcwd())
SECRETS_PATH = autoconfig("SECRETS_PATH", default="/run/secrets")

repository = CompositeRepository(
    RepositorySecret(SECRETS_PATH),
    autoconfig.config.repository,
)

config: Config = Config(repository)