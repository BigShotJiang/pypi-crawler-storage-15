Changelog
=========

19.0.1.0.0
----------

Migration to Odoo 19.
