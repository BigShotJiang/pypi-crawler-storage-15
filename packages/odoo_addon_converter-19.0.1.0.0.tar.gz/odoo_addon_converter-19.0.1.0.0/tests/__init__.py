from . import (
    test_base,
    test_context,
    test_converters,
    test_field,
    test_ir_model,
    test_keyfield,
    test_mail_template,
    test_model,
    test_qr_code,
    test_relation,
    test_switch,
    test_validate,
)
