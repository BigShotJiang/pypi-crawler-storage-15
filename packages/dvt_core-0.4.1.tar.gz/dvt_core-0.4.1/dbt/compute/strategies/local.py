"""
Local Spark Connection Strategy

Provides embedded PySpark session for local development and testing.
This is the default strategy extracted from the original SparkEngine implementation.

Includes auto-configuration of Java via bundled jdk4py - no system Java required!
"""

import os
from typing import Optional

from dbt.compute.strategies.base import BaseConnectionStrategy
from dbt_common.exceptions import DbtRuntimeError

try:
    from pyspark.sql import SparkSession

    PYSPARK_AVAILABLE = True
except ImportError:
    PYSPARK_AVAILABLE = False
    SparkSession = None

# Global Spark session cache for reuse across calls (within same process)
_SPARK_SESSION_CACHE = {}



# Check Java availability and provide helpful setup instructions
def _ensure_java_available():
    """
    Intelligently detect Java across all operating systems (Windows, macOS, Linux).

    Searches common Java installation paths, validates version (requires Java 11+),
    and provides clear user feedback about what was found or what's needed.

    No special file/folder privileges required - only checks standard public paths.
    """
    import subprocess
    import shutil
    import re
    import platform

    MINIMUM_JAVA_VERSION = 11

    def get_java_version(java_bin_path):
        """Get Java major version from java binary."""
        try:
            result = subprocess.run(
                [java_bin_path, "-version"],
                capture_output=True,
                text=True,
                timeout=5
            )
            version_output = result.stderr + result.stdout
            # Parse version (e.g., "openjdk version \"21.0.5\"" or "java version \"1.8.0\"")
            version_match = re.search(r'version "(\d+)\.?', version_output)
            if version_match:
                major = int(version_match.group(1))
                # Handle old Java versioning (1.8 = Java 8)
                if major == 1:
                    minor_match = re.search(r'version "1\.(\d+)', version_output)
                    if minor_match:
                        major = int(minor_match.group(1))
                return major, version_output.split('\n')[0].strip()
        except Exception:
            pass
        return None, None

    def set_java_home(java_home_path, version, version_string):
        """Set JAVA_HOME and update PATH."""
        os.environ["JAVA_HOME"] = java_home_path
        bin_path = os.path.join(java_home_path, "bin")
        os.environ["PATH"] = bin_path + os.pathsep + os.environ.get("PATH", "")
        print(f"\n[DVT] ✓ Found Java {version}: {version_string}")
        print(f"[DVT]   JAVA_HOME: {java_home_path}")
        print(f"[DVT]   Minimum required: Java {MINIMUM_JAVA_VERSION}+")
        return True

    # Step 1: Check if JAVA_HOME is already set and valid
    java_home = os.environ.get("JAVA_HOME")
    if java_home and os.path.exists(java_home):
        java_bin = os.path.join(java_home, "bin", "java")
        if os.path.exists(java_bin):
            version, version_str = get_java_version(java_bin)
            if version and version >= MINIMUM_JAVA_VERSION:
                print(f"\n[DVT] ✓ Using Java {version} from JAVA_HOME: {version_str}")
                print(f"[DVT]   Path: {java_home}")
                print(f"[DVT]   Minimum required: Java {MINIMUM_JAVA_VERSION}+")
                return  # Valid Java found
            elif version:
                print(f"\n[DVT] ⚠ JAVA_HOME points to Java {version} (minimum required: {MINIMUM_JAVA_VERSION}+)")
                print(f"[DVT]   Searching for newer Java installation...")

    # Step 2: Check if java is in PATH
    java_bin = shutil.which("java")
    if java_bin:
        version, version_str = get_java_version(java_bin)
        if version and version >= MINIMUM_JAVA_VERSION:
            # Infer JAVA_HOME from binary location (typically JAVA_HOME/bin/java)
            java_home = os.path.dirname(os.path.dirname(os.path.realpath(java_bin)))
            if set_java_home(java_home, version, version_str):
                return

    # Step 3: Search common Java installation paths by OS
    os_type = platform.system()
    search_paths = []

    if os_type == "Darwin":  # macOS
        search_paths = [
            "/Library/Java/JavaVirtualMachines/*/Contents/Home",
            "/usr/local/opt/openjdk@*/libexec/openjdk.jdk/Contents/Home",
            "/usr/local/Cellar/openjdk@*/*/libexec/openjdk.jdk/Contents/Home",
            os.path.expanduser("~/Library/Java/JavaVirtualMachines/*/Contents/Home"),
        ]
    elif os_type == "Linux":
        search_paths = [
            "/usr/lib/jvm/java-*-openjdk-amd64",
            "/usr/lib/jvm/java-*-openjdk",
            "/usr/lib/jvm/jdk-*",
            "/usr/lib/jvm/adoptium-*",
            "/usr/java/jdk*",
            "/opt/java/jdk*",
            os.path.expanduser("~/.sdkman/candidates/java/*"),
        ]
    elif os_type == "Windows":
        search_paths = [
            "C:\\Program Files\\Java\\jdk*",
            "C:\\Program Files\\OpenJDK\\jdk*",
            "C:\\Program Files\\AdoptOpenJDK\\jdk*",
            "C:\\Program Files\\Eclipse Adoptium\\jdk*",
            os.path.expanduser("~\\scoop\\apps\\openjdk*\\current"),
        ]

    # Search all paths and collect valid Java installations
    import glob
    found_javas = []

    for pattern in search_paths:
        try:
            for path in glob.glob(pattern):
                if os_type == "Windows":
                    java_bin = os.path.join(path, "bin", "java.exe")
                else:
                    java_bin = os.path.join(path, "bin", "java")

                if os.path.exists(java_bin):
                    version, version_str = get_java_version(java_bin)
                    if version and version >= MINIMUM_JAVA_VERSION:
                        found_javas.append((version, path, version_str))
        except Exception:
            continue  # Skip paths that can't be accessed

    # Use the newest Java version found
    if found_javas:
        found_javas.sort(reverse=True, key=lambda x: x[0])
        version, java_home, version_str = found_javas[0]
        set_java_home(java_home, version, version_str)
        return

    # Step 4: No valid Java found - provide helpful error message
    print("\n" + "=" * 70)
    print("[DVT] ✗ Java not found!")
    print(f"[DVT]   DVT requires Java {MINIMUM_JAVA_VERSION}+ for Spark execution")
    print("=" * 70)

    if os_type == "Darwin":  # macOS
        print("\n📦 Install Java on macOS:")
        print("   Using Homebrew:")
        print("     brew install openjdk@21")
        print("     export JAVA_HOME=$(/usr/libexec/java_home -v 21)")
        print("\n   Or download from:")
        print("     https://adoptium.net/")
    elif os_type == "Linux":
        print("\n📦 Install Java on Linux:")
        print("   Ubuntu/Debian:")
        print("     sudo apt-get update")
        print("     sudo apt-get install openjdk-21-jdk")
        print("     export JAVA_HOME=/usr/lib/jvm/java-21-openjdk-amd64")
        print("\n   RHEL/CentOS/Fedora:")
        print("     sudo dnf install java-21-openjdk-devel")
        print("     export JAVA_HOME=/usr/lib/jvm/java-21-openjdk")
    elif os_type == "Windows":
        print("\n📦 Install Java on Windows:")
        print("   Download and install from:")
        print("     https://adoptium.net/")
        print("\n   Or using Scoop:")
        print("     scoop bucket add java")
        print("     scoop install openjdk")

    print("\n   After installation, restart your terminal.")
    print("=" * 70 + "\n")

    # Raise error to stop execution
    raise DbtRuntimeError(
        f"Java {MINIMUM_JAVA_VERSION}+ not found. "
        f"Please install Java and set JAVA_HOME environment variable. "
        f"See installation instructions above."
    )


class LocalStrategy(BaseConnectionStrategy):
    """
    Local embedded Spark strategy.

    Creates an in-process PySpark session with local[*] master.
    Best for development, testing, and small-medium workloads.

    Configuration:
    {
        "master": "local[*]",  # optional, defaults to local[*]
        "spark.driver.memory": "4g",  # optional
        "spark.executor.memory": "4g",  # optional
        # ... any other Spark configs
    }
    """

    def validate_config(self) -> None:
        """
        Validate local strategy configuration.

        Local strategy is flexible - no required fields.
        """
        # Local strategy accepts any config - very flexible
        # Just ensure it's a dictionary
        if not isinstance(self.config, dict):
            raise DbtRuntimeError(
                f"Local Spark config must be a dictionary, got {type(self.config)}"
            )

    def get_spark_session(self) -> SparkSession:
        """
        Create or reuse local Spark session (BLAZING FAST).

        Creates an embedded PySpark session with optimized configuration for speed.
        Implements session caching to reuse existing sessions.

        :returns: Initialized SparkSession
        :raises DbtRuntimeError: If session creation fails
        """
        import sys
        import hashlib

        if not PYSPARK_AVAILABLE:
            raise DbtRuntimeError("PySpark is not available. Install it with: pip install pyspark")

        # Create cache key from config to reuse sessions with same configuration
        config_str = str(sorted(self.config.items()))
        cache_key = hashlib.md5(config_str.encode()).hexdigest()

        # Check if we have a cached session with this config
        if cache_key in _SPARK_SESSION_CACHE:
            cached_spark = _SPARK_SESSION_CACHE[cache_key]
            # Verify session is still active
            try:
                cached_spark.sparkContext.getConf()  # Will fail if session is dead
                print("[DVT] ✓ Reusing cached Spark session (instant!)", file=sys.stderr, flush=True)
                return cached_spark
            except Exception:
                # Session died, remove from cache
                del _SPARK_SESSION_CACHE[cache_key]

        # No cached session available, create a new one
        print("[DVT] Creating new Spark session with optimized configuration...", file=sys.stderr, flush=True)

        # Auto-configure Java
        _ensure_java_available()

        try:
            builder = SparkSession.builder.appName(self.app_name)

            # BLAZING FAST CONFIGURATION
            # Use local[2] instead of local[*] for faster startup (2 cores is plenty for most queries)
            master = self.config.get("master", "local[2]")
            builder = builder.master(master)

            # Optimized default configurations for SPEED
            fast_configs = {
                # Memory optimization - 1g is sufficient for most queries
                "spark.driver.memory": "1g",
                "spark.executor.memory": "1g",

                # JDBC drivers for ALL major databases (bundled with DVT out-of-the-box!)
                # Auto-downloaded from Maven Central on first run, then cached locally
                "spark.jars.packages": ",".join([
                    # Snowflake (JDBC + Spark connector)
                    "net.snowflake:snowflake-jdbc:3.13.30",
                    "net.snowflake:spark-snowflake_2.12:2.11.3-spark_3.3",
                    # PostgreSQL
                    "org.postgresql:postgresql:42.7.1",
                    # MySQL
                    "com.mysql:mysql-connector-j:8.0.33",
                    # SQL Server
                    "com.microsoft.sqlserver:mssql-jdbc:12.4.0.jre11",
                    # Oracle
                    "com.oracle.database.jdbc:ojdbc11:23.2.0.0",
                    # Redshift
                    "com.amazon.redshift:redshift-jdbc42:2.1.0.16",
                    # BigQuery
                    "com.google.cloud.spark:spark-bigquery-with-dependencies_2.12:0.32.2",
                ]),

                # Disable Spark UI for faster startup
                "spark.ui.enabled": "false",
                "spark.ui.showConsoleProgress": "false",

                # Disable event logging for faster startup
                "spark.eventLog.enabled": "false",

                # Network optimizations
                "spark.driver.bindAddress": "127.0.0.1",
                "spark.driver.host": "localhost",

                # Reduce shuffle partitions for faster queries on small data
                "spark.sql.shuffle.partitions": "8",  # Default is 200 (overkill for local)

                # Enable Arrow for efficient data transfer
                "spark.sql.execution.arrow.pyspark.enabled": "true",
                "spark.sql.execution.arrow.pyspark.fallback.enabled": "true",
                "spark.sql.execution.arrow.enabled": "true",

                # Disable unnecessary features
                "spark.sql.adaptive.enabled": "false",  # Adaptive query optimization (slow for small data)
                "spark.sql.adaptive.coalescePartitions.enabled": "false",
            }

            # Apply fast configs (can be overridden by user config)
            for key, value in fast_configs.items():
                if key not in self.config:
                    builder = builder.config(key, value)

            # Apply user-provided configs (except 'master' which is already set)
            for key, value in self.config.items():
                if key != "master":
                    builder = builder.config(key, value)

            # Create session (should be much faster now!)
            spark = builder.getOrCreate()

            # Set log level to WARN to reduce noise
            spark.sparkContext.setLogLevel("WARN")

            # Cache the session for reuse
            _SPARK_SESSION_CACHE[cache_key] = spark

            print("[DVT] ✓ Spark session created and cached!", file=sys.stderr, flush=True)
            return spark

        except Exception as e:
            error_msg = str(e)

            # Check if it's a Java-related error
            if "JAVA_GATEWAY_EXITED" in error_msg or "Unable to locate a Java Runtime" in error_msg or "JAVA_HOME" in error_msg:
                raise DbtRuntimeError(
                    f"Failed to create local Spark session: Java not found.\n\n"
                    f"DVT requires Java 11 or later for Spark execution. Please install Java:\n\n"
                    f"macOS (using Homebrew):\n"
                    f"  brew install openjdk@11\n"
                    f"  export JAVA_HOME=$(/usr/libexec/java_home -v 11)\n\n"
                    f"Ubuntu/Debian:\n"
                    f"  sudo apt-get install openjdk-11-jdk\n"
                    f"  export JAVA_HOME=/usr/lib/jvm/java-11-openjdk-amd64\n\n"
                    f"Or download from: https://adoptium.net/\n\n"
                    f"Original error: {error_msg}"
                ) from e

            # Other error
            raise DbtRuntimeError(f"Failed to create local Spark session: {error_msg}") from e

    def close(self, spark: Optional[SparkSession]) -> None:
        """
        Optionally close Spark session.

        IMPORTANT: With session caching enabled, we DON'T close the session by default
        to enable reuse across multiple runs. The session stays in the cache for the
        lifetime of the Python process.

        Set DVT_SPARK_NO_CACHE=1 environment variable to force session closure.

        :param spark: SparkSession to close (or keep alive)
        """
        import os

        # Check if caching is disabled
        no_cache = os.environ.get("DVT_SPARK_NO_CACHE", "0") == "1"

        if no_cache and spark:
            try:
                # Clear from cache first
                for key, cached_spark in list(_SPARK_SESSION_CACHE.items()):
                    if cached_spark is spark:
                        del _SPARK_SESSION_CACHE[key]
                        break

                # Stop the session
                spark.stop()
                print("[DVT] Spark session closed (caching disabled)", flush=True)
            except Exception:
                pass  # Best effort cleanup
        else:
            # Session stays alive in cache for reuse
            print("[DVT] Spark session kept alive in cache for reuse (blazing fast next run!)", flush=True)

    def estimate_cost(self, duration_minutes: float) -> float:
        """
        Estimate cost for local execution.

        Local execution is free (runs on local machine).

        :param duration_minutes: Estimated query duration
        :returns: 0.0 (free)
        """
        return 0.0

    def get_platform_name(self) -> str:
        """Get platform name."""
        return "local"
