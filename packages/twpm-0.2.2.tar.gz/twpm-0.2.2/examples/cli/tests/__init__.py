"""Tests for CLI nodes."""
