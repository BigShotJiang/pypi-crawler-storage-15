"""
pSim Examples Package

Common utilities for examples.
"""

import sys
import os

# Add parent directory to path for all examples
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))