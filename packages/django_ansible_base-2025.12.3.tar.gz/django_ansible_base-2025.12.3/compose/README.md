## `compose` Directory
This directory contains the Dockerfile and configuration files for Nginx and Ingress services used in the `test_app`.
At the moment, this code is only for testing and development purposes, and is not used in production.

