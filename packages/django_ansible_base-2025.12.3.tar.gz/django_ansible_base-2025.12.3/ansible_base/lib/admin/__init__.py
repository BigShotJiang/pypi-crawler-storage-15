from ansible_base.lib.admin.readonly import ReadOnlyAdmin

__all__ = [
    "ReadOnlyAdmin",
]
