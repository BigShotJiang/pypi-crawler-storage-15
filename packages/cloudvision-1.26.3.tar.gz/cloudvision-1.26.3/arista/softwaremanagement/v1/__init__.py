# Copyright (c) 2025 Arista Networks, Inc.  All rights reserved.

from arista.softwaremanagement.v1 import softwaremanagement_pb2 as models
import arista.softwaremanagement.v1.services
