# Copyright (c) 2025 Arista Networks, Inc.  All rights reserved.

from arista.inventory.v1 import inventory_pb2 as models
import arista.inventory.v1.services
