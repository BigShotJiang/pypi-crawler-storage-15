# Copyright (c) 2025 Arista Networks, Inc.  All rights reserved.

from arista.time import time_pb2 as models
