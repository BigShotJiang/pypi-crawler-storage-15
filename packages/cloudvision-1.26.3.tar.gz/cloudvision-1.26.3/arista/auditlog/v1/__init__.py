# Copyright (c) 2025 Arista Networks, Inc.  All rights reserved.

from arista.auditlog.v1 import auditlog_pb2 as models
import arista.auditlog.v1.services
