
class AuthTokens:

    @staticmethod
    def get_cleartax_user_authtoken():
        return "1.656eee80-fadf-417a-9cbc-afc23a5a99cc_50a07b9cc32945040288cdeae5d7131695e6dfea955e1510a2b97c32305d6eef"
