from __future__ import annotations

# filestate: python-constant-sort
GIT_BRANCH_MAIN: str = "main"
GIT_PROVIDER_GITHUB: str = "github"
GIT_PROVIDER_GITLAB: str = "gitlab"
GIT_REMOTE_ORIGIN: str = "origin"
