"""Documents module for ToothFairyAI SDK."""

from .document_manager import DocumentManager

__all__ = ["DocumentManager"]
