"""Folders module for ToothFairyAI SDK."""

from .folder_manager import FolderManager

__all__ = ["FolderManager"]
