"""SciSpark MCP Server 配置管理与核心业务逻辑

提供MCP服务器所需的配置管理、任务编排、MCP客户端和工具函数。
"""

import json
import logging
import os
import re
import shutil
import time
import zipfile
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

import httpx
from fastmcp import Client
from fastmcp.client.transports import SSETransport

# ================================
# 配置管理
# ================================


class SciSparkConfig:
    """SciSpark 配置管理类"""

    def __init__(self):
        # MCP 服务器配置
        self.mcp_server_host = os.getenv("MCP_SERVER_HOST", "coze.tashan.ac.cn")
        self.mcp_server_port = int(os.getenv("MCP_SERVER_PORT", "8000"))
        self.mcp_sse_url = os.getenv(
            "MCP_SSE_URL", "https://coze.tashan.ac.cn/scispark/sse"
        )

        # 本地存储配置
        self.client_root = Path(__file__).parent
        self.db_path = Path(
            os.getenv("SCISPARK_DB_PATH", self.client_root / "tasks.json")
        )
        self.download_dir = Path(
            os.getenv("SCISPARK_DOWNLOAD_DIR", self.client_root / "downloads")
        )
        self.workspace_dir = Path(
            os.getenv("SCISPARK_WORKSPACE_DIR", self.client_root / "workspace")
        )

        # 任务配置
        self.task_timeout = int(os.getenv("TASK_TIMEOUT", "7200"))  # 增加到2小时

        # SSL配置 - 默认禁用SSL验证以确保可用性
        ssl_verify = os.getenv("SSL_VERIFY", "false").lower()
        self.verify_ssl = ssl_verify not in ["false", "0", "no", "off"]

    def ensure_directories(self):
        """确保必要的目录存在"""
        self.download_dir.mkdir(parents=True, exist_ok=True)
        self.workspace_dir.mkdir(parents=True, exist_ok=True)


# ================================
# 全局配置实例
# ================================

config = SciSparkConfig()
logger = logging.getLogger(__name__)


# ================================
# MCP 客户端
# ================================


class AsyncMCPClient:
    """异步 MCP 客户端封装"""

    def __init__(self, sse_url: str, verify_ssl: bool = True):
        self.sse_url = sse_url
        self.verify_ssl = verify_ssl
        self.client: Client | None = None

    @asynccontextmanager
    async def session(self):
        """MCP 客户端会话上下文管理器"""
        try:
            # 如果禁用SSL验证，进行monkey patch
            original_create = None
            if not self.verify_ssl:
                import httpx

                original_create = httpx.AsyncClient.__init__

                def patched_init(self, *args, **kwargs):
                    kwargs["verify"] = False
                    original_create(self, *args, **kwargs)

                httpx.AsyncClient.__init__ = patched_init
                logger.warning("SSL验证已禁用，请确保在受信任环境中使用")

            # 自定义 HTTP 客户端工厂以修复路径问题
            class RewritingAsyncClient(httpx.AsyncClient):
                async def request(self, method, url, **kwargs):
                    url_str = str(url)
                    # 修复 Nginx 反代导致的路径问题：将 /messages 重写为 /scispark/messages
                    if (
                        "coze.tashan.ac.cn/messages" in url_str
                        and "/scispark" not in url_str
                    ):
                        new_url = url_str.replace(
                            "coze.tashan.ac.cn/messages",
                            "coze.tashan.ac.cn/scispark/messages",
                        )
                        logger.info(f"Rewriting URL from {url_str} to {new_url}")
                        url = new_url
                    return await super().request(method, url, **kwargs)

            def insecure_client_factory(**kwargs):
                if not self.verify_ssl:
                    kwargs["verify"] = False
                return RewritingAsyncClient(**kwargs)

            transport = SSETransport(
                self.sse_url, httpx_client_factory=insecure_client_factory
            )
            self.client = Client(transport)

            async with self.client as session:
                logger.info(
                    f"MCP client session started (SSL验证: {'启用' if self.verify_ssl else '禁用'})"
                )
                yield session

        finally:
            # 恢复原始方法
            if original_create and not self.verify_ssl:
                import httpx

                httpx.AsyncClient.__init__ = original_create

            self.client = None
            logger.info("MCP client session closed")

    async def call_tool(self, tool_name: str, **kwargs) -> dict[str, Any]:
        """调用 MCP 工具"""
        if not self.client:
            raise RuntimeError(
                "MCP client not connected. Use 'async with client.session():' context."
            )

        try:
            result = await self.client.call_tool(
                tool_name, kwargs, timeout=600
            )  # 增加到10分钟

            # 解析结果
            content_list = []

            if isinstance(result, dict) and "content" in result:
                for item in result["content"]:
                    if isinstance(item, dict) and "text" in item:
                        content_list.append({"text": item["text"]})
            elif isinstance(result, list):
                for item in result:
                    if isinstance(item, dict) and "text" in item:
                        content_list.append({"text": item["text"]})
            elif isinstance(result, str):
                content_list.append({"text": result})
            else:
                content_list.append({"text": str(result)})

            return {"content": content_list}

        except Exception as e:
            logger.error(f"Error calling tool {tool_name}: {e}")
            raise


# ================================
# 任务存储
# ================================


class TaskStore:
    """任务数据存储管理"""

    def __init__(self, db_path: Path):
        self.db_path = db_path
        self.tasks: dict[str, dict[str, Any]] = {}
        self.load()

    def load(self):
        """从文件加载任务数据"""
        if self.db_path.exists():
            try:
                with open(self.db_path, encoding="utf-8") as f:
                    self.tasks = json.load(f)
            except json.JSONDecodeError:
                logger.error(f"Failed to load tasks from {self.db_path}")
                self.tasks = {}

    def save(self):
        """保存任务数据到文件（原子操作）"""
        # 先写入临时文件，然后原子替换
        temp_file = self.db_path.with_suffix(".tmp")
        try:
            with open(temp_file, "w", encoding="utf-8") as tf:
                json.dump(self.tasks, tf, indent=2, ensure_ascii=False)
                temp_name = tf.name

            # 原子替换
            shutil.move(temp_name, self.db_path)

        except Exception as e:
            logger.error(f"Failed to save tasks to {self.db_path}: {e}")
            # 清理临时文件
            if temp_file.exists():
                temp_file.unlink()

    def add_task(self, task_id: str, topic: str):
        """添加新任务"""
        current_time = time.time()
        self.tasks[task_id] = {
            "id": task_id,
            "topic": topic,
            "status": "submitted",
            "created_at": current_time,
            "updated_at": current_time,
            "downloaded": False,
        }
        self.save()

    def update_status(self, task_id: str, status: str):
        """更新任务状态"""
        if task_id in self.tasks:
            self.tasks[task_id]["status"] = status
            self.tasks[task_id]["updated_at"] = time.time()
            self.save()

    def mark_downloaded(self, task_id: str):
        """标记任务已下载"""
        if task_id in self.tasks:
            self.tasks[task_id]["downloaded"] = True
            self.tasks[task_id]["status"] = "downloaded"
            self.tasks[task_id]["updated_at"] = time.time()
            self.save()

    def get_task(self, task_id: str) -> dict[str, Any] | None:
        """获取单个任务信息"""
        return self.tasks.get(task_id)

    def get_all_tasks(self) -> dict[str, dict[str, Any]]:
        """获取所有任务"""
        return self.tasks.copy()

    def get_pending_tasks(self):
        """获取未完成的任务"""
        return [
            t
            for t in self.tasks.values()
            if t["status"] not in ["completed", "failed", "downloaded"]
        ]


# ================================
# 工具函数
# ================================


async def download_file(url: str, dest_path: Path, timeout: int = 600) -> bool:
    """异步下载文件 - 使用流式下载提高性能"""
    try:
        dest_path.parent.mkdir(parents=True, exist_ok=True)

        # 使用异步流式下载，保持内存高效和并发能力
        async with httpx.AsyncClient(timeout=timeout, follow_redirects=True) as client:
            async with client.stream("GET", url) as response:
                response.raise_for_status()
                with open(dest_path, "wb") as f:
                    async for chunk in response.aiter_bytes(chunk_size=8192):
                        f.write(chunk)

        logger.info(f"Successfully downloaded {url} to {dest_path}")
        return True
    except Exception as e:
        logger.error(f"Failed to download {url}: {e}")
        return False


def unzip_file(zip_path: Path, extract_to: Path) -> bool:
    """解压ZIP文件"""
    try:
        extract_to.mkdir(parents=True, exist_ok=True)

        with zipfile.ZipFile(zip_path, "r") as zip_ref:
            zip_ref.extractall(extract_to)
        return True
    except Exception as e:
        logger.error(f"Failed to unzip {zip_path}: {e}")
        return False


def parse_json_from_response(response_text: str) -> dict[str, Any] | None:
    """从响应文本中解析JSON数据"""
    try:
        # 尝试直接解析JSON
        return json.loads(response_text)
    except json.JSONDecodeError:
        # 尝试从文本中提取JSON
        json_match = re.search(r"```json\s*(.*?)\s*```", response_text, re.DOTALL)
        if json_match:
            try:
                return json.loads(json_match.group(1))
            except json.JSONDecodeError:
                pass

        # 尝试提取大括号内的内容
        brace_match = re.search(r"\{.*\}", response_text, re.DOTALL)
        if brace_match:
            try:
                return json.loads(brace_match.group(0))
            except json.JSONDecodeError:
                pass

        logger.error(f"Failed to parse JSON from response: {response_text[:200]}...")
        return None


# ================================
# 核心业务逻辑 - 任务编排器
# ================================


class TaskOrchestrator:
    """任务编排器 - 核心业务逻辑"""

    def __init__(self, config_obj: SciSparkConfig | None = None):
        self.config = config_obj or config
        self.mcp_client = AsyncMCPClient(
            self.config.mcp_sse_url, verify_ssl=self.config.verify_ssl
        )
        self.store = TaskStore(self.config.db_path)
        self.config.ensure_directories()

    async def submit_research_task(self, topic: str) -> str | None:
        """提交新的研究任务"""
        logger.info(f"Submitting research task for topic: {topic}")

        async with self.mcp_client.session():
            # 1. 调用 MCP 生成想法 (即发布任务)
            try:
                result = await self.mcp_client.call_tool(
                    "generate_research_idea", keyword=topic, paper_count=3
                )

                # 解析返回结果
                if not result.get("content") or not result["content"][0].get("text"):
                    logger.error(
                        f"Invalid response from generate_research_idea: {result}"
                    )
                    return None

                response_text = result["content"][0]["text"]
                response_data = parse_json_from_response(response_text)

                if not response_data:
                    return None

                if not response_data.get("success"):
                    logger.error(
                        f"Task submission failed: {response_data.get('error')}"
                    )
                    return None

                task_id = response_data.get("task_id")
                if not task_id:
                    logger.error("No task_id in response")
                    return None

                # 2. 保存任务到本地数据库
                self.store.add_task(task_id, topic)
                logger.info(f"Task submitted successfully with ID: {task_id}")
                return task_id

            except Exception as e:
                logger.error(f"Error submitting task: {e}")
                return None

    async def check_status(self, task_id: str) -> dict[str, Any] | None:
        """检查任务状态"""
        logger.info(f"Checking status for task: {task_id}")

        async with self.mcp_client.session():
            try:
                result = await self.mcp_client.call_tool(
                    "get_task_status", task_id=task_id
                )

                if not result.get("content") or not result["content"][0].get("text"):
                    logger.warning(f"Invalid response for status check: {result}")
                    return None

                content = result["content"][0]["text"]

                # 尝试解析JSON状态信息
                if content.startswith("{"):
                    status_data = parse_json_from_response(content)
                    if status_data and status_data.get("success"):
                        task_info = status_data.get("task", {})
                        status = task_info.get("status", "unknown")

                        # 更新本地状态
                        self.store.update_status(task_id, status)

                        return task_info

                # 如果不是JSON格式，可能是状态文本
                logger.info(f"Task {task_id} status: {content}")
                return {"status_text": content}

            except Exception as e:
                logger.error(f"Error checking status: {e}")
                return None

    def _extract_content_from_mcp_response(self, result):
        """
        从MCP响应中提取文本内容

        Args:
            result: MCP客户端返回的响应对象

        Returns:
            str: 提取的文本内容，如果提取失败返回None
        """
        content = None
        logger.info(f"Extracting content from result type: {type(result)}")

        # 策略1: 检查字典格式的响应
        if isinstance(result, dict):
            logger.info(f"Result is dict, keys: {list(result.keys())}")

            if "content" in result:
                content_list = result["content"]
                logger.info(f"Found content key, type: {type(content_list)}")

                # 处理content是字符串的情况（序列化的CallToolResult）
                if isinstance(content_list, str):
                    content = content_list
                    logger.info("Content is string, trying to extract JSON...")

                    # 尝试从字符串中提取text字段
                    import re

                    json_match = re.search(r'"text"\s*:\s*"([^"]*)"', content)
                    if json_match:
                        content = json_match.group(1)
                        logger.info(f"Extracted text via regex: {content[:100]}...")

                # 处理content是列表的情况
                elif isinstance(content_list, list) and len(content_list) > 0:
                    first_item = content_list[0]

                    if isinstance(first_item, dict):
                        content = first_item.get("text")
                    elif hasattr(first_item, "text"):
                        content = first_item.text
                    else:
                        content = str(first_item)

        # 策略2: 检查对象属性
        elif hasattr(result, "content"):
            logger.info(f"Found result.content attribute, type: {type(result.content)}")

            if isinstance(result.content, str):
                content = result.content
                # 同样尝试从字符串中提取text字段
                import re

                json_match = re.search(r'"text"\s*:\s*"([^"]*)"', content)
                if json_match:
                    content = json_match.group(1)

            elif isinstance(result.content, list) and len(result.content) > 0:
                first_item = result.content[0]

                if isinstance(first_item, dict):
                    content = first_item.get("text")
                elif hasattr(first_item, "text"):
                    content = first_item.text
                else:
                    content = str(first_item)

        # 策略3: 从__dict__中提取
        elif hasattr(result, "__dict__"):
            result_dict = result.__dict__
            logger.info(f"Result __dict__, keys: {list(result_dict.keys())}")

            if "content" in result_dict:
                content_list = result_dict["content"]
                if isinstance(content_list, list) and len(content_list) > 0:
                    first_item = content_list[0]
                    if hasattr(first_item, "text"):
                        content = first_item.text

        # 策略4: 直接转换为字符串处理
        if not content:
            result_str = str(result)
            logger.info(
                f"Converting result to string, first 200 chars: {result_str[:200]}..."
            )

            # 尝试从字符串中提取JSON内容
            import re

            text_match = re.search(r'"text"\s*:\s*"([^"]*)"', result_str)
            if text_match:
                content = text_match.group(1)
                logger.info(f"Extracted content via regex: {content[:100]}...")

        if content:
            logger.info(f"Successfully extracted content, length: {len(content)}")
        else:
            logger.warning(f"Failed to extract content from result: {type(result)}")

        return content

    async def download_task(
        self, task_id: str, download_dir: str = None, workspace_dir: str = None
    ) -> bool:
        """下载任务结果"""
        logger.info(f"Downloading result for task: {task_id}")

        async with self.mcp_client.session():
            try:
                # 使用正确的工具名
                result = await self.mcp_client.call_tool(
                    "download_task_result", task_id=task_id
                )

                logger.info(f"Raw result type: {type(result)}")
                logger.info(f"Raw result preview: {str(result)[:200]}...")

                # 使用改进的内容提取方法
                content = self._extract_content_from_mcp_response(result)

                if not content:
                    logger.error(f"Failed to extract content from response: {result}")
                    return False

                logger.info(f"Extracted content: {content[:100]}...")

                # 解析下载链接
                if content.startswith("http"):
                    download_url = content
                elif content.startswith("{"):
                    download_data = parse_json_from_response(content)
                    if download_data and download_data.get("success"):
                        download_url = download_data.get("download_url")
                    else:
                        logger.error(f"Download API returned error: {download_data}")
                        return False
                elif "CallToolResult" in content and "download_url" in content:
                    # 处理嵌套的CallToolResult格式
                    logger.info(
                        "Detected nested CallToolResult, extracting download_url..."
                    )
                    import re

                    url_match = re.search(r'"download_url"\s*:\s*"([^"]*)"', content)
                    if url_match:
                        download_url = url_match.group(1)
                        logger.info(
                            f"Extracted download_url from nested format: {download_url}"
                        )
                    else:
                        logger.error(
                            f"Could not extract download_url from nested format: {content}"
                        )
                        return False
                else:
                    logger.error(f"Unknown response format: {content}")
                    return False

                # 智能URL重写：将内网IP替换为域名
                if "123.56.3.104:8000" in download_url:
                    logger.info(
                        f"Rewriting download URL from {download_url} to use Nginx proxy..."
                    )
                    download_url = download_url.replace(
                        "123.56.3.104:8000", "coze.tashan.ac.cn"
                    )

                # 下载ZIP文件
                zip_filename = f"{task_id}.zip"

                # 使用自定义下载目录或默认目录
                if download_dir:
                    download_path = Path(download_dir)
                    download_path.mkdir(parents=True, exist_ok=True)
                    zip_path = download_path / zip_filename
                    logger.info(f"Using custom download directory: {download_dir}")
                else:
                    zip_path = self.config.download_dir / zip_filename

                if await download_file(download_url, zip_path):
                    logger.info(f"Downloaded ZIP to: {zip_path}")

                    # 解压到工作区 - 使用自定义工作区目录或默认目录
                    if workspace_dir:
                        extract_dir = Path(workspace_dir) / task_id
                        extract_dir.mkdir(parents=True, exist_ok=True)
                        logger.info(
                            f"Using custom workspace directory: {workspace_dir}"
                        )
                    else:
                        extract_dir = self.config.workspace_dir / task_id

                    if unzip_file(zip_path, extract_dir):
                        logger.info(f"Extracted to: {extract_dir}")

                        # 标记为已下载
                        self.store.mark_downloaded(task_id)
                        return True
                    else:
                        logger.error("Failed to extract ZIP file")
                        return False
                else:
                    logger.error("Failed to download ZIP file")
                    return False

            except Exception as e:
                logger.error(f"Error downloading task: {e}")
                return False


# ================================
# 全局配置实例
# ================================

config = SciSparkConfig()
