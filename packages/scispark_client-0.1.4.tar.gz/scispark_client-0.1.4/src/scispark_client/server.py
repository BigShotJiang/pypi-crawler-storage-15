"""SciSpark Client MCP 服务器

提供基于 Model Context Protocol 的工具接口，用于 AI 助手直接调用。
"""

import argparse
import json
import logging

from fastmcp import FastMCP

from .config import TaskOrchestrator, parse_json_from_response

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("MCP-Server")

# 初始化 FastMCP 服务
mcp = FastMCP("SciSpark Client")

# 初始化任务编排器
orchestrator = TaskOrchestrator()


@mcp.tool()
async def submit_research_task(topic: str) -> str:
    """
    提交一个新的研究任务。

    该工具会向远程 SciSpark 服务器提交一个研究主题，并开始生成研究想法。

    Args:
        topic: 研究主题描述

    Returns:
        str: 提交成功返回包含 Task ID 的消息，失败返回错误信息。
    """
    logger.info(f"Received request to submit task for topic: {topic}")
    # orchestrator.submit_research_task 内部自行管理 session，无需在此处包裹
    task_id = await orchestrator.submit_research_task(topic)

    if task_id:
        return f"Task submitted successfully! ID: {task_id}. You can check status using check_remote_status or list_local_tasks."
    else:
        return "Failed to submit task. Please check server logs for details."


@mcp.tool()
async def list_local_tasks() -> str:
    """
    列出本地记录的所有任务及其状态。

    该工具读取本地存储的任务列表。

    Returns:
        str: 格式化的任务列表字符串。
    """
    tasks = orchestrator.store.get_all_tasks()
    if not tasks:
        return "No tasks found locally."

    result = ["Local Tasks:"]
    for t_id, t_info in tasks.items():
        status = t_info.get("status", "unknown")
        topic = t_info.get("topic", "No Topic")
        result.append(f"- ID: {t_id} | Status: {status} | Topic: {topic}")

    return "\n".join(result)


@mcp.tool()
async def download_task_result(
    task_id: str, download_dir: str = None, workspace_dir: str = None
) -> str:
    """
    下载并解压指定任务的结果。

    Args:
        task_id: 任务 ID
        download_dir: 自定义下载目录路径 (可选，默认使用配置中的路径)
        workspace_dir: 自定义工作区目录路径 (可选，默认使用配置中的路径)

    Returns:
        str: 操作结果消息。
    """
    logger.info(f"Received request to download result for task: {task_id}")
    if download_dir:
        logger.info(f"Custom download directory: {download_dir}")
    if workspace_dir:
        logger.info(f"Custom workspace directory: {workspace_dir}")

    try:
        # orchestrator.download_task 需要外部提供 session
        async with orchestrator.mcp_client.session():
            await orchestrator.download_task(
                task_id, download_dir=download_dir, workspace_dir=workspace_dir
            )

        # 构建返回消息
        if download_dir or workspace_dir:
            msg_parts = []
            msg_parts.append(f"Download completed for task {task_id}.")
            if download_dir:
                msg_parts.append(f"Download directory: {download_dir}")
            if workspace_dir:
                msg_parts.append(f"Workspace directory: {workspace_dir}")
            return " ".join(msg_parts)
        else:
            return f"Download completed for task {task_id}. Please check the default workspace directory."
    except Exception as e:
        logger.error(f"Error downloading task {task_id}: {e}")
        return f"Error downloading task {task_id}: {str(e)}"


@mcp.tool()
async def check_remote_status(task_id: str) -> str:
    """
    查询远程服务器上任务的实时状态并更新本地记录。

    Args:
        task_id: 任务 ID

    Returns:
        str: 任务状态信息。
    """
    logger.info(f"Checking remote status for task: {task_id}")
    try:
        async with orchestrator.mcp_client.session():
            # 调用远程工具 get_task_status
            result = await orchestrator.mcp_client.call_tool(
                "get_task_status", task_id=task_id
            )

            # 解析返回结果
            content = ""
            if result.get("content") and result["content"][0].get("text"):
                content = result["content"][0]["text"]

                # 使用解析函数
                status_data = parse_json_from_response(content)

                if status_data and status_data.get("success"):
                    task_info = status_data.get("task", {})
                    status = task_info.get("status", "unknown")

                    # 更新本地状态（作为副作用）
                    orchestrator.store.update_status(task_id, status)
                    return f"Task ID: {task_id}\nCurrent Status: {status}\nDetails: {json.dumps(task_info, indent=2, ensure_ascii=False)}"
                else:
                    return f"Failed to parse status or server returned error.\nRaw Response: {content}"

            return f"No content received from server.\nRaw Result: {result}"

    except Exception as e:
        logger.error(f"Error checking status for {task_id}: {e}")
        return f"Error checking status: {str(e)}"


def run_server(transport: str = "stdio", host: str = "127.0.0.1", port: int = 3024):
    """运行 MCP 服务器

    Args:
        transport: 传输协议 ("stdio", "sse", "streamable-http")
        host: 服务器监听地址 (HTTP/SSE模式)
        port: 服务器监听端口 (HTTP/SSE模式)
    """
    logger.info(f"Starting SciSpark MCP Server with {transport} transport...")

    if transport in ["sse", "streamable-http"]:
        logger.info(f"Server will listen on {host}:{port}")
        mcp.run(transport=transport, host=host, port=port)
    else:
        logger.info("Server will use STDIO transport")
        mcp.run(transport=transport)


def run_server_http(host: str = "127.0.0.1", port: int = 3024):
    """启动HTTP模式MCP服务器"""
    run_server(transport="streamable-http", host=host, port=port)


def run_server_sse(host: str = "127.0.0.1", port: int = 3024):
    """启动SSE模式MCP服务器"""
    run_server(transport="sse", host=host, port=port)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="SciSpark MCP Server")
    parser.add_argument(
        "--transport",
        choices=["stdio", "sse", "streamable-http"],
        default="stdio",
        help="传输协议 (默认: stdio)",
    )
    parser.add_argument(
        "--host",
        default="127.0.0.1",
        help="服务器监听地址 (HTTP/SSE模式, 默认: 127.0.0.1)",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=3024,
        help="服务器监听端口 (HTTP/SSE模式, 默认: 3024)",
    )

    args = parser.parse_args()
    run_server(transport=args.transport, host=args.host, port=args.port)
