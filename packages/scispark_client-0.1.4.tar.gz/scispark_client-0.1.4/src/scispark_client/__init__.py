"""SciSpark MCP Server - 基于 Model Context Protocol 的研究任务管理服务

专注于提供MCP工具接口，用于AI助手直接调用研究任务管理功能。
"""

__version__ = "0.1.4"
__author__ = "SciSpark Team"

from .config import SciSparkConfig, TaskOrchestrator
from .server import mcp, run_server

__all__ = [
    "SciSparkConfig",
    "TaskOrchestrator",
    "mcp",
    "run_server",
]
