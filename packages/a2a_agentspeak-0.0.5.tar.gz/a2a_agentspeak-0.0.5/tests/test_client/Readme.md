Just send a achieve/do_ping message to an agent at port 9999.

You can use this client with any running agent on that port.

Tested against a Java A2A server.