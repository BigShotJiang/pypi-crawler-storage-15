Example with an A2A agent not designed with BDI.

Based on: https://github.com/a2aproject/a2a-samples/tree/main/samples/python/agents/number_guessing_game

# Setup

Copy here the content of the directory linked above. (Tested December 1st 2025)

# Run

Launch agent_Alice.py (should listen on http://localhost:8001)

```bash
python3 agen_Alice.py
```
Run the AgentSpeak/A2A agent:  
```bash
python3 run_player_agent.py
```