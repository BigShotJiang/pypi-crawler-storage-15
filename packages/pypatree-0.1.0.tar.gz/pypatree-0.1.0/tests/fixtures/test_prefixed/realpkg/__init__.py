def greet() -> str:
    return "greet"
