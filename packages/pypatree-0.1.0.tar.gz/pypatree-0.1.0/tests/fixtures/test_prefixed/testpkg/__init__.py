def hello() -> str:
    return "hello"
