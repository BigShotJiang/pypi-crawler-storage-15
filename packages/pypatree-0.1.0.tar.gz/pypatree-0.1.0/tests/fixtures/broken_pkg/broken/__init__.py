import nonexistent_module_12345  # will fail on import
