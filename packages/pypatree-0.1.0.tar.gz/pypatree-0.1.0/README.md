# pypatree

[![CI](https://github.com/yberreby/pypatree/actions/workflows/ci.yml/badge.svg)](https://github.com/yberreby/pypatree/actions/workflows/ci.yml)
[![PyPI](https://img.shields.io/pypi/v/pypatree)](https://pypi.org/project/pypatree/)
[![Python](https://img.shields.io/pypi/pyversions/pypatree)](https://pypi.org/project/pypatree/)
[![License](https://img.shields.io/pypi/l/pypatree)](https://github.com/yberreby/pypatree/blob/main/LICENSE)

Pretty-print a project's module tree.

```bash
uv add --dev pypatree
uv run pypatree
```

Example output on this very repo:
```
pypatree
├── build_tree()
├── get_module_items()
├── get_packages()
├── __main__
│   ├── main()
│   └── run()
└── display
    ├── print_tree()
    └── render_tree()
```
