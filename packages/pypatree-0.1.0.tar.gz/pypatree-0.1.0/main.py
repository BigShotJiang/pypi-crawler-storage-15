def main():
    print("Hello from pypatree!")


if __name__ == "__main__":
    main()
