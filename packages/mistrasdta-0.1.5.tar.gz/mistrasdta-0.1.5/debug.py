import MistrasDTA

rec, wfm = MistrasDTA.read_bin("tests/dta/210510-CH1-15.DTA")
True
