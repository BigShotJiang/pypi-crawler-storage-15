from mcp.server.fastmcp import FastMCP
import os
from pathlib import Path

# --- 初始化 FastMCP 服务器 ---
# 注意：FastMCP 会根据这个名称自动生成 manifest
mcp = FastMCP("Simple_File_Reader_FastMCP") 

# --- 定义读取文件工具 ---
@mcp.tool()
def read_local_file(filepath: str) -> str:
    
    # 1. 路径处理和安全检查
    try:
        # 将输入路径解析为绝对路径
        target_path = Path(filepath).resolve()
    except Exception as e:
        return f"错误: 路径解析失败。详细错误: {str(e)}"
    
    if not target_path.exists():
        return f"错误: 找不到文件或路径不存在: '{target_path}'"
    
    if not target_path.is_file():
        return f"错误: 路径指向的是一个目录，而不是文件: '{target_path}'"
        
    try:
        with open(target_path, 'r', encoding='utf-8') as f:
            content = f.read()
        return content

    except UnicodeDecodeError:
        return f"错误: 文件读取失败。文件 '{target_path.name}' 可能不是一个有效的UTF-8文本文件。"
    except Exception as e:
        return f"文件读取失败 (I/O 错误): {str(e)}"

def main() -> None:
    mcp.run(transport="stdio")
