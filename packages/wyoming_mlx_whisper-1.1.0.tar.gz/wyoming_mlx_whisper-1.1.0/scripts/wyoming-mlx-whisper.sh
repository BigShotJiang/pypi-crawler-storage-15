#!/bin/bash
set -e
uvx --python 3.12 wyoming-mlx-whisper "$@"
