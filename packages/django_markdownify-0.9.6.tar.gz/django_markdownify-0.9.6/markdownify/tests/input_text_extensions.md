Fenced code:
~~~~~~~~~~~~~~~~~~~~{.python}
def test(y):  
    print(y)  
~~~~~~~~~~~~~~~~~~~~