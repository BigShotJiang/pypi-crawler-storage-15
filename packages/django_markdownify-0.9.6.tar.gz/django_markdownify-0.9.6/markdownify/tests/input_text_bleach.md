# Bleach
Bleach is an allowed-list-based HTML sanitizing library that escapes or strips markup and attributes.

[Website](https://bleach.readthedocs.io/en/latest/index.html)
