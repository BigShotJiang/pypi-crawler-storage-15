from adam.commands.command import Command
from adam.commands.export.export_databases import ExportDatabases
from adam.commands.export.exporter import Exporter
from adam.repl_state import ReplState, RequiredState
from adam.utils import log, log2
from adam.utils_k8s.statefulsets import StatefulSets

class ImportSession(Command):
    COMMAND = 'import session'

    # the singleton pattern
    def __new__(cls, *args, **kwargs):
        if not hasattr(cls, 'instance'): cls.instance = super(ImportSession, cls).__new__(cls)

        return cls.instance

    def __init__(self, successor: Command=None):
        super().__init__(successor)

    def command(self):
        return ImportSession.COMMAND

    def required(self):
        return RequiredState.CLUSTER_OR_POD

    def run(self, cmd: str, state: ReplState):
        if not(args := self.args(cmd)):
            return super().run(cmd, state)

        state, args = self.apply_state(args, state)
        if not self.validate_state(state):
            return state

        if not args:
            if state.in_repl:
                log2('Specify export session name.')
            else:
                log2('* Export session name is missing.')

                Command.display_help()

            return 'command-missing'

        if not state.pod:
            state.push()
            state.pod = StatefulSets.pod_names(state.sts, state.namespace)[0]
            state.export_session = args[0]
        try:
            if Exporter.import_session(args, state):
                Exporter.clear_export_session_cache()

                log()
                ExportDatabases.display_export_db(state.export_session)
        finally:
            state.pop()

        return state

    def completion(self, state: ReplState):
        # warm up cache
        Exporter.export_session_names(state.sts, state.pod, state.namespace)
        Exporter.export_session_names(state.sts, state.pod, state.namespace, export_state='pending_import')

        return {}

    def help(self, _: ReplState):
        return f'{ImportSession.COMMAND} <export-db-name>\t import files in session to Athena or SQLite'