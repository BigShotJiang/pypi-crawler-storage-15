if __name__ == "__main__":
    from rawake.main import main

    main()
