"""Version information for rxiv-maker."""

__version__ = "1.14.3"
__version_tuple__ = (1, 14, 3)

# Note: Docker images v1.8+ use mermaid.ink API for diagram processing
# This improves cross-platform compatibility and performance
