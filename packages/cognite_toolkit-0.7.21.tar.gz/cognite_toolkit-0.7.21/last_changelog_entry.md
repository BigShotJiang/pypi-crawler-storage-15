## Changelog 

### Added

- [alpha] When you download files with content, `cdf data download files
--include-file-contents ...`, you can now upload them with `cdf data
upload dir`.