.. _plotly-examples-index:

Plotly Gallery
==============

.. _general_plotly_examples:

Plotly Examples
---------------

Examples from the Sphinx-Gallery using Plotly for embedding 3D plots.
