.. _pyvista-examples-index:

PyVista Gallery
===============

.. _general_pyvista_examples:

PyVista Examples
----------------

Examples from the Sphinx-Gallery using PyVista for embedding 3D plots.
`Learn more about PyVista <https://docs.pyvista.org>`_ and see their
`extensive examples gallery <https://docs.pyvista.org/examples/index.html>`_
built with Sphinx-Gallery!

Take a look at the :ref:`image_scrapers` section to learn more about how to
enable and use PyVista in your example gallery.
