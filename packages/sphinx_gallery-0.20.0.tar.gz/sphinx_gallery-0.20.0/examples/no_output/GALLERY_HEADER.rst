.. _no_out_examples:

No image output examples
------------------------

This section gathers examples which don't produce any figures. Some examples
only output to standard output, others demonstrate how Sphinx-Gallery handles
examples with errors.
