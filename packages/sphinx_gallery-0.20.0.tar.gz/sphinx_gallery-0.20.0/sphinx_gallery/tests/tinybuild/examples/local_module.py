"""Trivial module to provide a value for plot_numpy_matplotlib.py."""

N = 1000
