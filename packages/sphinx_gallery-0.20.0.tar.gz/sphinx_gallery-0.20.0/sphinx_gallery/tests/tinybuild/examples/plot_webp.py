"""
============
Save as WebP
============
"""

import matplotlib.pyplot as plt

plt.plot([1, 2])
