:orphan:

.. _future_examples:

Future examples
===============

Examples that use ``__future__``.
