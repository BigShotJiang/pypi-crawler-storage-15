# This file is ignored through ignore_pattern so it does not need to have a
# docstring following the sphinx-gallery convention (i.e. title + description)
