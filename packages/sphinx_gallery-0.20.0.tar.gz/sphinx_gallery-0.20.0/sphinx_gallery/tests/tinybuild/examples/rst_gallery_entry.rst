reStructuredText gallery entry
==============================

This file creates a regular gallery entry and page.
