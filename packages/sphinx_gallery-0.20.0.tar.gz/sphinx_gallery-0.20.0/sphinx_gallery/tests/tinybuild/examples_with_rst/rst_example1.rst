========================
A Restructured-text file
========================

This Rst file is passed through without being changed.  It was in the source
directory as ``/examples_with_rst/rst_example1.rst`` and gets passed to the
directory created by ``sphinx-gallery`` in
``/doc/examples_with_rst/rst_example1.rst``.

You need to reference this rst file in a *toctree* somewhere in your project, as
``sphinx-gallery`` will not add it to a *toctree* automatically like it
does for ``*.py`` examples.  This could be referenced in your
``README.txt`` as we have done in this directory.
