=========================================
Example with README.txt as gallery header
=========================================

This is a backward compatibility test. The recommended gallery header file is
``GALLERY_HEADER.rst`` nowadays. But we continue to support the older
``README.txt``.