==================================
Example of directory with a README
==================================

This subdir uses a README to generate the index.

.. toctree::

    plot_sub1
