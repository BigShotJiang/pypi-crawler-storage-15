===============================
Subdirectory2 with an index.rst
===============================

Here we need to specify any files in this directory in the toc by hand:

.. toctree::

    plot_sub2
