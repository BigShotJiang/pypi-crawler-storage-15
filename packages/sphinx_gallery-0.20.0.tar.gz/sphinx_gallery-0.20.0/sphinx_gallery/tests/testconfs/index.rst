Tiny test build
===============

Minimal testing example
