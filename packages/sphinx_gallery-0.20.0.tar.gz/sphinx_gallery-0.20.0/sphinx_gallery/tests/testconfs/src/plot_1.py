"""
======
B test
======

:filename=1:title=2:lines=3:filesize=2:
"""

from sphinx_gallery.py_source_parser import Block

Block("text", "Text block", 1)

# %%
#
# .. minigallery:: src/plot_2.py
