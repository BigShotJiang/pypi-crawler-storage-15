"""
======
E test
======

:filename=4:title=5:lines=4:filesize=5:
"""

print("foofoofoofoofoofoofoofoo")
print("barbarbarbarbarbarbarbar")

# %%
#
# .. minigallery:: src/plot_2.py
