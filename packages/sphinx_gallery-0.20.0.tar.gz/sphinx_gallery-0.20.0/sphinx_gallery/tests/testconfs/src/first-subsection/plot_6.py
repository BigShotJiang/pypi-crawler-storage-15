#!/usr/bin/env python2
"""
.. _extra_ref:

=======================================================================================
D is a file with a title even longer than `plot_1.py`, to make the filesize even larger
=======================================================================================

:filename=6:title=4:lines=5:filesize=6:
"""

# let's
# add
# some
# lines
# to
# test
# sorting
# by
# number
# of
# lines
