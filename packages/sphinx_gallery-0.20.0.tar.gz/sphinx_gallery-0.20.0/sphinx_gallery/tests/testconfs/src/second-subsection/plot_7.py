"""
======
E test
======

:filename=7:title=8:lines=7:filesize=8:
"""

print("foofoofoofoofoofoofoofoo")
print("barbarbarbarbarbarbarbar")

# %%
#
# .. minigallery:: src/plot_9.py
