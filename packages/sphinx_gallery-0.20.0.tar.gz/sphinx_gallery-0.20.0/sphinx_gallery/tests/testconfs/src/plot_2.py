"""
======
C test
======

:filename=2:title=3:lines=1:filesize=1:
"""

print("foo")
