#!/usr/bin/env python2
"""
.. _extra_ref:

===========================================================
A test with a really long title to make the filesize larger
===========================================================

:filename=3:title=1:lines=2:filesize=3:
"""

print("foo")
print("bar")
