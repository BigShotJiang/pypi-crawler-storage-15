"""Metrics to evaluate the quality of Synthetic Relational Data.

This subpackage exists only to enable importing sdmetrics as part of sdv.
"""

from sdmetrics.multi_table import *  # noqa
