"""AgentBill CrewAI Integration

Zero-config crew tracking for CrewAI agents in AgentBill.
"""

from .tracker import track_crew

__version__ = "6.8.3"
__all__ = ["track_crew"]
