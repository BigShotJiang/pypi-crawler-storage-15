#UtilityLibAPI Classes

## History of version
Version 1.2512.0501: 2025/12/05<BR>
Fixed break down when smtp server not auth or response time out.


Version 1.2511.292: 2025/11/29<BR>
Add Event for send mail when success or failure.

Version 1.2511.291: 2025/11/29<BR>
Fixed MailSenderLib: Attachement file name encode problem.
Add function for user can modify mail caption of from field.

Version 1.2511.282: 2025/11/27<BR>
Fixed MailSenderLib: Attachement file name encode problem.

Version 1.2511.281: 2025/11/27<BR>
Modified 7zArchiveLib to Archive7zLib --> 7z Archive tools library

Version 1.2511.28: 2025/11/27<BR>
Fixed 7zArchiveLib --> 7z Archive tools library

Version 1.2511.27: 2025/11/27<BR>
Add 7zArchiveLib --> 7z Archive tools library

Version 1.2510.22: 2025/10/21<BR>
Add ExtWrapper7zLib --> 7z Archive tools library

Version 1.2510.22: 2025/10/21<BR>
Add MailSenderLib --> CLASS_MailSender library

Version 0.1.1: 2025/10/13<BR>
Fixed export class path<BR>

Version 0.1.0: 2025/10/13<BR>
Create UtilityLibAPI -- EnDeCodeLib + SessionVARLib<BR>
