import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from email.mime.base import MIMEBase
from email.utils import formataddr
from email.header import Header
from email import encoders
from typing import List, Optional
import os
import mimetypes

class CLASS_MailSender:
    def __init__(self,
                 Pms_SMTP_Server: str,
                 Pmi_Port: int,
                 Pms_Account: str,
                 Pms_Password: str,
                 Pmb_UseSSL: bool = True):
        """
        初始化郵件寄送物件
        :param Pms_SMTP_Server: 郵件伺服器主機 (ex: smtp.gmail.com)
        :param Pmi_Port: 通訊埠 (SSL=465, TLS=587)
        :param Pms_Account: 登入帳號
        :param Pms_Password: 登入密碼或應用程式密碼
        :param Pmb_UseSSL: 是否使用 SSL 連線 (預設 True)
        """
        self.Pms_SMTP_Server = Pms_SMTP_Server
        self.Pmi_Port        = Pmi_Port
        self.Pms_Account     = Pms_Account
        self.Pms_Password    = Pms_Password
        self.Pmb_UseSSL      = Pmb_UseSSL
        # ======================================================================
        # 新增事件 
        # ======================================================================
        self.OnAfterSendSuccess: Optional[Callable[[str], None]] = None
        self.OnAfterSendFailure: Optional[Callable[[str], None]] = None


    #------------------------------------------------------------
    def CUF_CreateMessage(self,
                          Pms_Subject: str,
                          Pms_BodyText: str,
                          Pms_BodyHTML: Optional[str] = None,
                          Pms_From: Optional[str] = None,
                          Pobj_To: Optional[List[str]] = None,
                          Pobj_Cc: Optional[List[str]] = None,
                          Pobj_Bcc: Optional[List[str]] = None,
                          Pobj_Attachments: Optional[List[str]] = None) -> MIMEMultipart:
        """
        建立郵件內容（支援 HTML / 附件 / 顯示別名）
        """
        msg = MIMEMultipart("alternative")

        # 設定寄件者別名
        from_addr = formataddr((Pms_From or self.Pms_Account, self.Pms_Account))
        msg["From"] = from_addr

        msg["To"] = ", ".join(Pobj_To or [])
        if Pobj_Cc:
            msg["Cc"] = ", ".join(Pobj_Cc)
        msg["Subject"] = Pms_Subject

        # 純文字版本
        msg.attach(MIMEText(Pms_BodyText or "", "plain", "utf-8"))

        # HTML 版本
        if Pms_BodyHTML:
            msg.attach(MIMEText(Pms_BodyHTML, "html", "utf-8"))

        # 附件（支援中文檔名 & Outlook）
        if Pobj_Attachments:
            for ms_path in Pobj_Attachments:
                try:
                    if not os.path.isfile(ms_path):
                        print(f"⚠️ Attachements not exists: {ms_path}")
                        continue

                    ctype, encoding = mimetypes.guess_type(ms_path)
                    if ctype is None or encoding is not None:
                        ctype = "application/octet-stream"
                    maintype, subtype = ctype.split("/", 1)

                    with open(ms_path, "rb") as f:
                        part = MIMEApplication(f.read(), _subtype=subtype)
                        filename = os.path.basename(ms_path)
                        #part.add_header(
                        #    "Content-Disposition",
                        #    "attachment",
                        #    filename=("utf-8", "", filename)
                        #)
                        filename_header = Header(filename, "utf-8").encode()
                        part.add_header(
                            "Content-Disposition",
                            "attachement",
                            filename=filename_header
                        )
                        msg.attach(part)
                except Exception as e:
                    print(f"⚠️ Can not add attachment: {ms_path} ({e})")
        return msg

    #------------------------------------------------------------
    def CUF_SendMail(self,
                     Pms_Subject: str,
                     Pms_BodyText: str,
                     Pms_BodyHTML: Optional[str],
                     Pobj_To: List[str],
                     Pms_From: Optional[str] = None,
                     Pobj_Cc: Optional[List[str]] = None,
                     Pobj_Bcc: Optional[List[str]] = None,
                     Pobj_Attachments: Optional[List[str]] = None) -> bool:
        """
        實際寄送郵件，支援寄件者別名
        """
        msg = self.CUF_CreateMessage(
            Pms_Subject=Pms_Subject,
            Pms_BodyText=Pms_BodyText,
            Pms_BodyHTML=Pms_BodyHTML,
            Pms_From=Pms_From,
            Pobj_To=Pobj_To,
            Pobj_Cc=Pobj_Cc,
            Pobj_Bcc=Pobj_Bcc,
            Pobj_Attachments=Pobj_Attachments,
        )

        all_recipients = (Pobj_To or []) + (Pobj_Cc or []) + (Pobj_Bcc or [])
        from_addr = formataddr((Pms_From or self.Pms_Account, self.Pms_Account))

        try:
            if self.Pmb_UseSSL:
                with smtplib.SMTP_SSL(self.Pms_SMTP_Server, self.Pmi_Port) as server:
                    server.login(self.Pms_Account, self.Pms_Password)
                    server.sendmail(from_addr, all_recipients, msg.as_string())
            else:
                with smtplib.SMTP(self.Pms_SMTP_Server, self.Pmi_Port) as server:
                    server.ehlo()
                    server.starttls()
                    server.login(self.Pms_Account, self.Pms_Password)
                    server.sendmail(from_addr, all_recipients, msg.as_string())

            print("✅ Send Success!")
            # ===== 觸發事件 =====
            if self.OnAfterSendSuccess:
                self.OnAfterSendSuccess(Pms_Subject)
            return True
        except Exception as e:
            print("❌ Failure:", e)
            # ===== 觸發事件 =====
            if self.OnAfterSendFailure:
                self.OnAfterSendFailure(str(e))
            return False



# ================================================================================
# [範例]
# 匯入剛才寫好的 CLASS_MailSender
#from MailSender import CLASS_MailSender  # 假設你把上面的 class 儲存為 MailSender.py

def GE_OnSendSuccess(Pms_Subject : str):
    print("[事件]:成功寄出了!");


def GE_OnSendFailure(Pms_ErrMsg : str):
    print("[事件]: 寄送失敗 ...");
    print("Err Msg:"+ Pms_ErrMsg);

if(__name__ == "__main__"):
    # === 初始化郵件傳送物件 ===
    mailer = CLASS_MailSender(
        Pms_SMTP_Server="mxr.hxxxt.xxt",
        Pmi_Port=465,
        Pms_Account="xxxxch.xxz@xxa.xxxet.xxt",
        Pms_Password="xxxxxxxxx",
        Pmb_UseSSL=True
    )

    mailer.OnAfterSendSuccess = GE_OnSendSuccess;
    mailer.OnAfterSendFailure = GE_OnSendFailure;

    # === 郵件收件者設定 ===
    ml_To  = ["gxxx4@goxxxx.bxz", "xxxxnxxx@xx27.xxxxx.xxt"]
    ml_Cc  = ["exxxxxx3@hotmail.com.tw"]
    ml_Bcc = ["jxxxxxx.xxx@mxx.xxxet.xet"]  # 密件副本，不會顯示在郵件中

    # === 郵件主題與內容 ===
    ms_Subject = "團隊週報通知 有事件 wahaha 123*()F"

    ms_BodyText = """
這是一封自動寄出的團隊週報通知。
請參閱附加的 PDF 檔或 HTML 內文。
    """

    ms_BodyHTML = """
    <html>
      <body style="font-family: Microsoft JhengHei;">
        <h2 style="color: green;">🌟 團隊週報</h2>
        <p>各位同仁您好：</p>
        <p>以下為本週重點摘要：</p>
        <ul>
          <li>完成模組 A 測試</li>
          <li>修正 ERP 匯出問題</li>
          <li>新增客戶報表功能</li>
        </ul>
        <p>詳細報表請參閱附件。</p>
        <p style="color: gray;">系統自動寄出，請勿回覆。</p>
      </body>
    </html>
    """

    # === 附件路徑 ===
    ml_Attachments = [
        "X:\\TEMP\\112年縣檸檬幼申報收入.jpg",
        "X:\\TEMP\\CR-6000-75通訊表.xls"
    ]

    # === 寄送 ===
    mb_OK = mailer.CUF_SendMail(
        Pms_Subject=ms_Subject,
        Pms_BodyText=ms_BodyText,
        Pms_BodyHTML=ms_BodyHTML,
        Pms_From = "太棒了!!a會觸發事件",
        Pobj_To=ml_To,
        Pobj_Cc=ml_Cc,
        Pobj_Bcc=ml_Bcc,
        Pobj_Attachments=ml_Attachments
    )

    if mb_OK:
        print("✅ 多人郵件已成功寄出！")
    else:
        print("❌ 寄送失敗，請檢查設定。")
