import smtplib
import socket
import ssl
import time
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from typing import List, Optional


# ============================================================================
# CLASS: MailSender
# ============================================================================
class CLASS_MailSender:
    def __init__(self,
                 Pms_SMTP_Server : str,
                 Pmi_Port        : int,
                 Pms_Account     : str,
                 Pms_Password    : str,
                 Pmb_UseSSL      : bool = False,
                 Pmi_TimeoutSec  : int  = 10,        # ★ 新增: Timeout(秒)
                 Pmi_RetryCount  : int  = 3,         # ★ 新增: 重試次數
                 Pmi_RetryDelay  : int  = 2):        # ★ 新增: 每次重試間隔

        self.SMTP_Server   = Pms_SMTP_Server
        self.SMTP_Port     = Pmi_Port
        self.SMTP_Account  = Pms_Account
        self.SMTP_Password = Pms_Password
        self.UseSSL        = Pmb_UseSSL

        self.TimeoutSec    = Pmi_TimeoutSec
        self.RetryCount    = Pmi_RetryCount
        self.RetryDelay    = Pmi_RetryDelay

        self.OnAfterSendSuccess = None
        self.OnAfterSendFailure = None


    # ============================================================================
    # FUNC: Internal – 建立 SMTP 連線（有 timeout + retry）
    # ============================================================================
    def __CUF_OpenSMTP(self):
        last_error = ""

        for retry in range(1, self.RetryCount + 1):
            try:
                socket.setdefaulttimeout(self.TimeoutSec)

                if self.UseSSL:
                    context = ssl.create_default_context()
                    smtp = smtplib.SMTP_SSL(self.SMTP_Server,
                                             self.SMTP_Port,
                                             timeout=self.TimeoutSec,
                                             context=context)
                else:
                    smtp = smtplib.SMTP(self.SMTP_Server,
                                        self.SMTP_Port,
                                        timeout=self.TimeoutSec)
                    smtp.starttls()

                smtp.login(self.SMTP_Account, self.SMTP_Password)
                return smtp  # ★ 成功

            except Exception as e:
                last_error = str(e)
                print(f"[警告] SMTP 連線失敗（第 {retry}/{self.RetryCount} 次），原因：{e}")

                if retry < self.RetryCount:
                    time.sleep(self.RetryDelay)

        # ---------------------------------------------------------------------------------
        # ★ 最後一次仍失敗 → 回傳 None 與最後錯誤訊息
        return None, last_error


    # ============================================================================
    # FUNC: 寄送郵件（含 retry）
    # ============================================================================
    def CUF_SendMail(self,
                     Pms_Subject      : str,
                     Pms_BodyText     : str,
                     Pms_BodyHTML     : Optional[str] = None,
                     Pms_From         : Optional[str] = None,
                     Pobj_To          : Optional[List[str]] = None,
                     Pobj_Bcc         : Optional[List[str]] = None,
                     Pobj_Attachments : Optional[List[str]] = None) -> bool:

        if Pobj_To is None:
            Pobj_To = []

        if Pobj_Bcc is None:
            Pobj_Bcc = []

        # =========================================================================
        # 組合 MIME
        # =========================================================================
        msg = MIMEMultipart("alternative")
        msg["Subject"] = Pms_Subject
        msg["From"]    = Pms_From if Pms_From else self.SMTP_Account
        msg["To"]      = ", ".join(Pobj_To)

        msg.attach(MIMEText(Pms_BodyText, "plain", "utf-8"))

        if Pms_BodyHTML:
            msg.attach(MIMEText(Pms_BodyHTML, "html", "utf-8"))

        # =========================================================================
        # 附件
        # =========================================================================
        if Pobj_Attachments:
            for file_path in Pobj_Attachments:
                try:
                    with open(file_path, "rb") as fp:
                        part = MIMEApplication(fp.read())
                        part.add_header('Content-Disposition',
                                        'attachment',
                                        filename=file_path.split("\\")[-1])
                        msg.attach(part)
                except Exception as e:
                    err = f"附件讀取失敗：{file_path}, Error={e}"
                    print("[錯誤] " + err)
                    if self.OnAfterSendFailure:
                        self.OnAfterSendFailure(err)
                    return False

        # =========================================================================
        # 寄送（含 retry）
        # =========================================================================
        last_error = ""

        for retry in range(1, self.RetryCount + 1):
            smtp = None
            try:
                smtp, err = self.__CUF_OpenSMTP()
                if smtp is None:
                    last_error = err
                    raise Exception(err)

                smtp.sendmail(msg["From"], Pobj_To + Pobj_Bcc, msg.as_string())
                smtp.quit()

                if self.OnAfterSendSuccess:
                    self.OnAfterSendSuccess(Pms_Subject)
                return True

            except Exception as e:
                last_error = str(e)
                print(f"[警告] 寄送失敗（第 {retry}/{self.RetryCount} 次）: {e}")

                if smtp:
                    try:
                        smtp.quit()
                    except:
                        pass

                if retry < self.RetryCount:
                    time.sleep(self.RetryDelay)

        # =========================================================================
        # 全部 retry 失敗
        # =========================================================================
        if self.OnAfterSendFailure:
            self.OnAfterSendFailure(last_error)

        return False


# ================================================================================
# [範例]
# 匯入剛才寫好的 CLASS_MailSender
#from MailSender import CLASS_MailSender  # 假設你把上面的 class 儲存為 MailSender.py

def GE_OnSendSuccess(Pms_Subject : str):
    print("[事件]:成功寄出了!");


def GE_OnSendFailure(Pms_ErrMsg : str):
    print("[事件]: 寄送失敗 ...");
    print("Err Msg:"+ Pms_ErrMsg);

if(__name__ == "__main__"):
    # === 初始化郵件傳送物件 ===
    mailer = CLASS_MailSender(
        Pms_SMTP_Server="mxr.hxxxt.xxt",
        Pmi_Port=465,
        Pms_Account="xxxxch.xxz@xxa.xxxet.xxt",
        Pms_Password="xxxxxxxxx",
        Pmb_UseSSL=True
    )

    mailer.OnAfterSendSuccess = GE_OnSendSuccess;
    mailer.OnAfterSendFailure = GE_OnSendFailure;

    # === 郵件收件者設定 ===
    ml_To  = ["gxxx4@goxxxx.bxz", "xxxxnxxx@xx27.xxxxx.xxt"]
    ml_Cc  = ["exxxxxx3@hotmail.com.tw"]
    ml_Bcc = ["jxxxxxx.xxx@mxx.xxxet.xet"]  # 密件副本，不會顯示在郵件中

    # === 郵件主題與內容 ===
    ms_Subject = "團隊週報通知 有事件 wahaha 123*()F"

    ms_BodyText = """
這是一封自動寄出的團隊週報通知。
請參閱附加的 PDF 檔或 HTML 內文。
    """

    ms_BodyHTML = """
    <html>
      <body style="font-family: Microsoft JhengHei;">
        <h2 style="color: green;">🌟 團隊週報</h2>
        <p>各位同仁您好：</p>
        <p>以下為本週重點摘要：</p>
        <ul>
          <li>完成模組 A 測試</li>
          <li>修正 ERP 匯出問題</li>
          <li>新增客戶報表功能</li>
        </ul>
        <p>詳細報表請參閱附件。</p>
        <p style="color: gray;">系統自動寄出，請勿回覆。</p>
      </body>
    </html>
    """

    # === 附件路徑 ===
    ml_Attachments = [
        "X:\\TEMP\\112年縣檸檬幼申報收入.jpg",
        "X:\\TEMP\\CR-6000-75通訊表.xls"
    ]

    # === 寄送 ===
    mb_OK = mailer.CUF_SendMail(
        Pms_Subject=ms_Subject,
        Pms_BodyText=ms_BodyText,
        Pms_BodyHTML=ms_BodyHTML,
        Pms_From = "太棒了!!a會觸發事件",
        Pobj_To=ml_To,
        Pobj_Cc=ml_Cc,
        Pobj_Bcc=ml_Bcc,
        Pobj_Attachments=ml_Attachments
    )

    if mb_OK:
        print("✅ 多人郵件已成功寄出！")
    else:
        print("❌ 寄送失敗，請檢查設定。")
