from django.apps import AppConfig


class DjangoRDKitConfig(AppConfig):
    name = 'django_rdkit'
    verbose_name = 'Django-RDkit'


