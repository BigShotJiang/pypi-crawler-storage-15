default_app_config = 'django_rdkit.apps.DjangoRDKitConfig'
