"""Tests for actor simulation module."""
