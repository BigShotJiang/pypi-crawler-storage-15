from .actor_simulator import ActorSimulator

# Alias for backward compatibility
UserSimulator = ActorSimulator

__all__ = ["ActorSimulator", "UserSimulator"]
