"""AI agent implementations."""
