# TikTok Downloader HD

A robust, Selenium-based library for downloading HD TikTok videos without watermarks using the SnapTik service. Uses spatial targeting to bypass standard scraping protections.

## Installation

Clone the repository.

Install dependencies:

```
pip install -r requirements.txt
```

## Requirements

Python 3.6+

Google Chrome browser installed

cookies.txt (Netscape format) - Recommended for fetching user profiles without login blocks.

## Usage

Single Video Download

```
from tiktok_downloader import TikTokDownloader
```

## Initialize downloader

```
dl = TikTokDownloader(
    download_dir="my_videos",
    cookies_path="cookies.txt", 
    headless=False 
)
```

## Download

```
dl.download("[https://www.tiktok.com/@user/video/1234567890](https://www.tiktok.com/@user/video/1234567890)", filename_prefix="video_1")
```

## Clean up

```
dl.close()
```

## Bulk Channel Download
```
from tiktok_downloader import TikTokDownloader
import re

dl = TikTokDownloader(download_dir="channel_dump", cookies_path="cookies.txt")

channel_url = "[https://www.tiktok.com/@realizeautomotive](https://www.tiktok.com/@realizeautomotive)"
links = dl.get_user_videos(channel_url, limit=10)

for i, link in enumerate(links):
    # Extract Video ID for filename
    vid_id = re.findall(r'/video/(\d+)', link)[0]
    dl.download(link, filename_prefix=vid_id)

dl.close()
```


## Disclaimer

This software is for educational purposes only. Users are responsible for complying with TikTok and SnapTik terms of service.
