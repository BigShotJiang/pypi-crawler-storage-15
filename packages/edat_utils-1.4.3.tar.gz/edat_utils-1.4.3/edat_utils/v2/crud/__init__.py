from edat_utils.v2.crud.crud_base import CRUDBase

__all__ = [
    "CRUDBase",
]
