source venv/bin/activate
python3 versecbot