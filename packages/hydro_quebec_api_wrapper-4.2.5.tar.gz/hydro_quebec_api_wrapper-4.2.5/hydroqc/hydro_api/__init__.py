"""Hydro Quebec API Wrapper."""
