Usage
=====

Scripting a construction
------------------------

