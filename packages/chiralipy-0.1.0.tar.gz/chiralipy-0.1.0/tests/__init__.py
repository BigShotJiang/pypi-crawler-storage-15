"""Chirpy test suite."""
