
# Copyright (C) [2025] Eduardo Antonio Ferrera Rodríguez
#
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation, either version 3 of the License, or any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY. See the COPYING file for more details.

# create_color.py




# Copyright (C) [2025] Eduardo Antonio Ferrera Rodríguez
# GPLv3 License

from . import colors_templates
from . import palettes
from pathlib import Path
import re


family_tags = {
    "block_tags": [
        "body", "div", "section", "article", "header", "footer",
        "nav", "main", "aside", "button", "form", "ul", "li", "a"
    ],

    "text_tags": ["p", "span"],

    "text_htags": ["h1", "h2", "h3", "h4", "h5", "h6"],

    "void_tags": ["img", "input", "hr"],

    "special_conteiners": ["video", "audio", "object"],

    "simple_tags": [
        "body", "div", "section", "article", "header", "footer",
        "nav", "main", "aside", "button", "form", "ul", "li", "a",
        "p", "span",
        "h1", "h2", "h3", "h4", "h5", "h6",
        "img", "input", "hr",
        "video", "audio", "object"
    ]
}


class CreateColor:

    def __init__(self, color_name, family, template):
        self.css_path = Path("style.css")
        self.color_name = color_name.lower()
        self.family = family.lower()
        self.template = template.lower()
        self.template_rule = self.import_template()
        self.specific_palette = self.import_colors()

        self.tags = self.decode_template()
        self.write_and_color()

    # -------------------------
    #        IMPORTS
    # -------------------------

    def import_template(self):
        try:
            return getattr(colors_templates, self.template)
        except AttributeError:
            raise ValueError(f"Template '{self.template}' does not exist in colors_templates.")

    def import_colors(self):
        try:
            family_color = getattr(palettes, self.family)
            return family_color[self.color_name]
        except AttributeError:
            raise ValueError(f"Color family '{self.family}' does not exist.")
        except KeyError:
            raise ValueError(f"Color '{self.color_name}' does not exist for family '{self.family}'.")

    # -------------------------
    #     DECODING TEMPLATE
    # -------------------------

    def decode_template(self):
        list_selector_name = []

        # SIMPLE SELECTOR
        for group_name, type_selectors in self.template_rule.items():
            if group_name != "simple_selector":
                continue

            for tags, color_rule in type_selectors.items():
                tags = tags.lower()

                if tags in family_tags["simple_tags"]:
                    list_selector_name.append({tags: color_rule})
                elif tags in family_tags:
                    for new_tag in family_tags[tags]:
                        list_selector_name.append({new_tag: color_rule})

        # DOUBLE SELECTOR
        for selector, color_rule in self.template_rule.get("doble_selector", {}).items():
            parts = selector.lower().split(">")
            expanded = []

            for tag in parts:
                tag = tag.lower()
                if tag in family_tags["simple_tags"]:
                    expanded.append([tag])
                elif tag in family_tags:
                    expanded.append(family_tags[tag])
                else:
                    expanded.append([tag])

            from itertools import product
            for combo in product(*expanded):
                list_selector_name.append({">".join(combo): color_rule})

        # TRIPLE SELECTOR
        for selector, color_rule in self.template_rule.get("triple_selector", {}).items():
            parts = selector.lower().split(">")
            expanded = []

            for tag in parts:
                tag = tag.lower()
                if tag in family_tags["simple_tags"]:
                    expanded.append([tag])
                elif tag in family_tags:
                    expanded.append(family_tags[tag])
                else:
                    expanded.append([tag])

            from itertools import product
            for combo in product(*expanded):
                list_selector_name.append({">".join(combo): color_rule})

        return list_selector_name

    # -------------------------
    #     APPLY COLORS
    # -------------------------
    def write_and_color(self):

            def decode_color_final():
                for name_selector in self.tags:
                    for selector_name, style_color in name_selector.items():
                        for color, style in style_color.items():

                            if style in ["principal", "secondary", "tertiary", "quaternary"]:
                                try:
                                    style_color[color] = self.specific_palette[style]

                                except KeyError:
                                    # ---- Caso único permitido: falta quaternary ----
                                    if style == "quaternary" and "tertiary" in self.specific_palette:
                                        style_color[color] = self.specific_palette["tertiary"]
                                    else:
                                        
                                        continue

                            else:
                                continue

                return self.tags

            decode_color_final()

            # ------------------------------
            # READ style.css
            # ------------------------------
            import re

            with open(self.css_path, "r", encoding="utf-8") as f:
                css_text = f.read()

            # ------------------------------
            # INSERT STYLES
            # ------------------------------
            for selector_dict in self.tags:
                for selector_name, style_color in selector_dict.items():

                   
                    escaped_selector = re.escape(selector_name)
                    
                    flexible_selector = escaped_selector.replace(r'\>', r'\s*>\s*')
                    flexible_selector = flexible_selector.replace(r'\+', r'\s*+\s*')
                    flexible_selector = flexible_selector.replace(r'\~', r'\s*~\s*')
                    flexible_selector = flexible_selector.replace(r'\ ', r'\s+')


                    pattern = rf"{flexible_selector}\s*\{{" 
                    match = re.search(pattern, css_text)

                    if not match:
                        continue

                    insert_pos = match.end()

                    insert_block = ""
                    for prop, value in style_color.items():
                        # Usar espacios estándar para la indentación (4 espacios)
                        insert_block += f"\n    {prop}: {value};" 

                    css_text = css_text[:insert_pos] + insert_block + css_text[insert_pos:]

            # ------------------------------
            # SAVE style.css
            # ------------------------------
            with open(self.css_path, "w", encoding="utf-8") as f:
                f.write(css_text)