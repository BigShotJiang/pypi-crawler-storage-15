# ----------------------------------------------------------------------
# Package Configuration
# ----------------------------------------------------------------------
__version__ = "1.0.43"
__author__ = "Eduardo Antonio Ferrera Rodriguez"
__license__ = "GPLv3"

# ----------------------------------------------------------------------
# Expose CSS submodule
# ----------------------------------------------------------------------
from . import css

# Expose CreateColor directly
from .css import CreateColor

# ----------------------------------------------------------------------
# Core modules
# ----------------------------------------------------------------------
from .html_doc import HtmlDoc
from .css_register import CSSRegistry
from .block import Block

# ----------------------------------------------------------------------
# Tags
# ----------------------------------------------------------------------
from .tags import (
    Div, Section, Article, Header, Footer, Nav, Main, Aside, Button, Form, Ul, Li, A,
    div, section, article, header, footer, nav, main, aside,
    button, form, ul, li, a
)

# ----------------------------------------------------------------------
# Void elements
# ----------------------------------------------------------------------
from .void_element import (
    VoidElement, Img, Input, Hr, Meta, Link, Source, Embed, Param, Track,
    Wbr, Area, Base, Col,
    img, Input, hr, meta, link, source, embed, param, track,
    wbr, area, base, col
)

# ----------------------------------------------------------------------
# Special containers
# ----------------------------------------------------------------------
from .special import (
    Video, Audio, Picture, ObjectElement,
    video, audio, picture, Object
)

# ----------------------------------------------------------------------
# Public API
# ----------------------------------------------------------------------
__all__ = [
    # CSS
    "css",
    "CreateColor",

    # Core
    "HtmlDoc",
    "CSSRegistry",
    "Block",

    # Tags
    "Div", "Section", "Article", "Header", "Footer", "Nav", "Main", "Aside",
    "Button", "Form", "Ul", "Li", "A",
    "div", "section", "article", "header", "footer", "nav", "main", "aside",
    "button", "form", "ul", "li", "a",

    # Void elements
    "VoidElement", "Img", "Input", "Hr", "Meta", "Link", "Source",
    "Embed", "Param", "Track", "Wbr", "Area", "Base", "Col",
    "img", "input", "hr", "meta", "link", "source", "embed",
    "param", "track", "wbr", "area", "base", "col",

    # Special containers
    "Video", "Audio", "Picture", "ObjectElement",
    "video", "audio", "picture", "Object",
]   
