# Authors

## Main Developer
- **Cavanşir Qurbanzadə** - Lead Developer, Project Maintainer