# codefusion/plugins/hooks.py
import typing as t

class PluginHooks:
    """Define available hooks for plugins."""
    pass
