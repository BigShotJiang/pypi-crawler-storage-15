from .manager import IgnoreManager
