from ._version import __version__

from .ui.cli import main
from .core.app import CodeFusionApp
