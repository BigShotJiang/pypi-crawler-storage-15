from liblaf.peach import tree


@tree.define
class Constraint:
    pass
