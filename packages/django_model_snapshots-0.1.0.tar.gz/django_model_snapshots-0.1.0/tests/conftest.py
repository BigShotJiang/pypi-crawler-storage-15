def pytest_configure():
    pass
