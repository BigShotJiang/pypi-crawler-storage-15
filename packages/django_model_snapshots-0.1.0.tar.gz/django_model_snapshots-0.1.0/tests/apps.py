from django.apps import AppConfig


class TestsConfig(AppConfig):
    name = "tests"
    label = "test_app"
    verbose_name = "Tests"
