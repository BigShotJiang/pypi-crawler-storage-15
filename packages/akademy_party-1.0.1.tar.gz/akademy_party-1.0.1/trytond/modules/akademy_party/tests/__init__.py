
from .test_party import suite

__all__ = ['suite']
