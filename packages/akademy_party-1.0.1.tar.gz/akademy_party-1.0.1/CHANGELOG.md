# Changelog
All changes made in **akademy-party** project will be listed in this file.

The format as follows the recomendations of [Keep a Changelog](https://keepachangelog.com/pt-BR/1.0.0/). And Semantic Versioning


## [1.0.1] - 2025-12-04
### Changed
- Translate README from portuguesse to engilsh

