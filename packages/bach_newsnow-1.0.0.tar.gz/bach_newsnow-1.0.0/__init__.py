"""MCP Server for Newsnow"""
