# Newsnow MCP Server

[English](./README_EN.md) | 简体中文 | [繁體中文](./README_ZH-TW.md)

用于访问 Newsnow API 的 MCP 服务器。

## 🚀 使用 EMCP 平台快速体验

**[EMCP](https://sit-emcp.kaleido.guru)** 是一个强大的 MCP 服务器管理平台，让您无需手动配置即可快速使用各种 MCP 服务器！

### 快速开始：

1. 🌐 访问 **[EMCP 平台](https://sit-emcp.kaleido.guru)**
2. 📝 注册并登录账号
3. 🎯 进入 **MCP 广场**，浏览所有可用的 MCP 服务器
4. 🔍 搜索或找到本服务器（`bach-newsnow`）
5. 🎉 点击 **"安装 MCP"** 按钮
6. ✅ 完成！即可在您的应用中使用

### EMCP 平台优势：

- ✨ **零配置**：无需手动编辑配置文件
- 🎨 **可视化管理**：图形界面轻松管理所有 MCP 服务器
- 🔐 **安全可靠**：统一管理 API 密钥和认证信息
- 🚀 **一键安装**：MCP 广场提供丰富的服务器选择
- 📊 **使用统计**：实时查看服务调用情况

立即访问 **[EMCP 平台](https://sit-emcp.kaleido.guru)** 开始您的 MCP 之旅！


---

## 简介

这是一个 MCP 服务器，用于访问 Newsnow API。

- **PyPI 包名**: `bach-newsnow`
- **版本**: 1.0.0
- **传输协议**: stdio


## 安装

### 从 PyPI 安装:

```bash
pip install bach-newsnow
```

### 从源码安装:

```bash
pip install -e .
```

## 运行

### 方式 1: 使用 uvx（推荐，无需安装）

```bash
# 运行（uvx 会自动安装并运行）
uvx --from bach-newsnow bach_newsnow

# 或指定版本
uvx --from bach-newsnow@latest bach_newsnow
```

### 方式 2: 直接运行（开发模式）

```bash
python server.py
```

### 方式 3: 安装后作为命令运行

```bash
# 安装
pip install bach-newsnow

# 运行（命令名使用下划线）
bach_newsnow
```

## 配置

### API 认证

此 API 需要认证。请设置环境变量:

```bash
export API_KEY="your_api_key_here"
```

### 环境变量

| 变量名 | 说明 | 必需 |
|--------|------|------|
| `API_KEY` | API 密钥 | 是 |
| `PORT` | 不适用 | 否 |
| `HOST` | 不适用 | 否 |



### 在 Cursor 中使用

编辑 Cursor MCP 配置文件 `~/.cursor/mcp.json`:


```json
{
  "mcpServers": {
    "bach-newsnow": {
      "command": "uvx",
      "args": ["--from", "bach-newsnow", "bach_newsnow"],
      "env": {
        "API_KEY": "your_api_key_here"
      }
    }
  }
}
```

### 在 Claude Desktop 中使用

编辑 Claude Desktop 配置文件 `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "bach-newsnow": {
      "command": "uvx",
      "args": ["--from", "bach-newsnow", "bach_newsnow"],
      "env": {
        "API_KEY": "your_api_key_here"
      }
    }
  }
}
```


## 可用工具

此服务器提供以下工具:


### `top_news__pwered_by_google`

TOP NEWS ( pwered by Google)

**端点**: `POST /newsv2_top_news`



---


### `top_news_by_locationpowered_by_google`

get top news by locations

**端点**: `POST /newsv2_top_news_location`



---


### `top_news_by_site_powered_by_google`

set more_information: true to get more detailed news , top_images etc  get top news by site

**端点**: `POST /newsv2_top_news_site`



---


### `news_api_v2_powered_by_google`

To get news between 'from date' to 'To date' set 'time_bounded parameter true Dates are in dd/mm/yyyy format set 'time_bounded' false to get only latest news Categories ( all categories are supported eg - finance, sports  and more , Can be removed) Location - (  Use country codes such as uk, us, in , Can be removed )  for any queries and bug report contact at api.prlabs@gmail.com

**端点**: `POST /newsv2`



---


### `ping_test`

ping

**端点**: `GET /`



---


### `top_news_powered_by_duck_duck_go`

Get Top News

**端点**: `POST /`



---


### `top_news_by_category_powered_by_google`

Categories- WORLD, NATION, BUSINESS, TECHNOLOGY, ENTERTAINMENT, SPORTS, SCIENCE, HEALTH. get top news by category

**端点**: `POST /newsv2_top_news_cat`



---



## 技术栈

- **传输协议**: stdio
- **HTTP 客户端**: httpx


## 许可证

MIT License - 详见 [LICENSE](./LICENSE) 文件。

## 开发

此服务器由 [API-to-MCP](https://github.com/BACH-AI-Tools/api-to-mcp) 工具生成。

版本: 1.0.0
