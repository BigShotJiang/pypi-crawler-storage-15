"""MCP Server for Facts By Api Ninjas"""
