from .intrinsic import InverseIntrinsicPNS

__all__ = [
    "InverseIntrinsicPNS",
]
