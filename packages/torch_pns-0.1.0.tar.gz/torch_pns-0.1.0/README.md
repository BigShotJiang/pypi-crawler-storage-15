# torch-pns

Principal nested spheres analysis for PyTorch.
