# Scottish rates
