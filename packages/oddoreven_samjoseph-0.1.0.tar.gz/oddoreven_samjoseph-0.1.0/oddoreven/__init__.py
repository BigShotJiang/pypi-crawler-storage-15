from .checker import is_odd_or_even
