def is_odd_or_even(num: int) -> str:
    if num % 2 == 0:
        return "Even"
    return "Odd"
