# oddoreven-samjoseph

A simple Python package that checks whether a number is odd or even.

## Usage

```python
from oddoreven import is_odd_or_even

print(is_odd_or_even(10))  # Even
print(is_odd_or_even(7))   # Odd
