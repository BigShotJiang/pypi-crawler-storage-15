# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from .entity import Entity
from .._models import BaseModel
from .relationship import Relationship

__all__ = ["KnowledgeGraph"]


class KnowledgeGraph(BaseModel):
    entities: List[Entity]

    relationships: Optional[List[Relationship]] = None
