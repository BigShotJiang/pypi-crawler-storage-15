from .rtcplauncher import main
main()