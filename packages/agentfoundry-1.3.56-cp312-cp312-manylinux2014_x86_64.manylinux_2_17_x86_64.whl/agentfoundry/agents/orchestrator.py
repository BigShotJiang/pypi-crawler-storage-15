from __future__ import annotations

__author__ = "Chris Steel"
__copyright__ = "Copyright 2025, Syntheticore Corporation"
__credits__ = ["Chris Steel"]
__date__ = "6/14/2025"
__license__ = "Syntheticore Confidential"
__version__ = "1.0"
__email__ = "csteel@syntheticore.com"
__status__ = "Production"

import logging
import os
import re
import sys
import time
import uuid
import warnings
from typing import Any, List, Tuple

from langchain_core.messages import AIMessage, HumanMessage, SystemMessage
from langchain_core.tools import tool
from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph.state import CompiledStateGraph
from langgraph.prebuilt import create_react_agent as create_agent
from openai import OpenAI

from agentfoundry.agents.base_agent import BaseAgent
from agentfoundry.agents.memory.summary_utils import summarize_memory
from agentfoundry.agents.tools import memory_tools
from agentfoundry.agents.tools.document_reader import ingest_document
from agentfoundry.llm.llm_factory import LLMFactory  # type: ignore
from agentfoundry.registry.tool_registry import ToolRegistry
from agentfoundry.vectorstores.factory import VectorStoreFactory
from agentfoundry.utils.agent_config import AgentConfig

# Module logger for orchestrator internals
logger = logging.getLogger('agentfoundry.agents.orchestrator')

# Suppress Pydantic underscore-field warnings
warnings.filterwarnings("ignore", message="fields may not start with an underscore", category=RuntimeWarning)

single_agent_prompt = (
    "You are an AI Agent with access to a variety of tools, including memory, to assist the user.\n"
    "For each task, think first, which tool? what args?\n"
    "A task may require outputs and tool calls from multiple tools. Please be aware of which tools to use at each step, determine if another tool needs to be used.\n"
    "If a tool was created by the request of the user, then you can invoke that tool.\n"
    "\nMemory Usage and Tool Guidelines:\n"
    "- Store ephemeral chat turns in *thread_memory*.\n"
    "- Store personal prefs/emotions/values in *user_memory* (profile for key-value, facts for triples, semantic for text).\n"
    "- Store organization for organization-specific things like policies/compliance/organizational facts and info in *org_memory*.\n"
    "- Store general/vendor-neutral facts/docs that apply across users and organizations in *global_memory* only when not user/org-specific.\n"
    "- Summarize long text (>1K chars) before storing via summarize_any_memory.\n"
    "- Query appropriate memory level before responding; enforce security_level filters.\n"
    "- Keep k small on searches; prefer summaries for long contexts.\n"
    "- Delegate complex memory tasks to specialist agents (e.g., compliance_agent).\n"
    "- Store org/user/thread data in their respective memory tools; use global memory only for vendor-neutral or public facts. Do NOT store sensitive information in global memory.\n"
    "If the user asks for a new AI Tool, Python Tool, or Python code, delegate to the code_gen_agent (which owns the python_tool_creator tool) first, if possible.\n"
)

micropolicy_prompt = """
You are an expert in extracting compliance rules from text and return them exclusively as a valid JSON array. 

Each JSON object in the array MUST include these keys:
- "rule": (string) A short, concise title of the compliance rule.
- "description": (string) A clear, detailed explanation of the compliance rule.
- "value": (optional string) A specific numerical value or threshold explicitly mentioned in the rule.

JSON Example:
[{
"rule": "RSA encryption key length",
"description": "Minimum acceptable RSA encryption key length",
"value": "2048"
}]

STRICT REQUIREMENTS:
- You MUST respond ONLY with a valid JSON array.
- You MUST NOT include any summaries, commentary, explanations, or additional text outside the JSON structure.
- The description should be an actionable issue that can be used to CHECK if a rule is being enforced. For example, instead of "name a security officer", use something like "verify there is a named security officer"
"""

recall_vector_store = VectorStoreFactory.get_store()


# Create a specialist agent
def make_specialist(name: str, tools: List[tool], llm, prompt: str | None = None):
    """ Create a specialist agent with the given name, tools, and LLM."""
    agent_name = " ".join(name.split("_")[:-1])
    tool_list_str = "\n".join(
        f"- {t.name}: {t.description}"
        for t in tools
    )
    if prompt is None:
        prompt = (
            f"You are a {agent_name} agent.\n\n"
            "AVAILABLE TOOLS:\n"
            f"{tool_list_str}\n\n"
            "INSTRUCTIONS:\n"
            "- Assist ONLY with tasks related to the agent, or tasks that can be fulfilled by the tools provided.\n"
            "- After you're done with your tasks, respond to the supervisor directly.\n"
            "- Respond ONLY with the results of your work, do NOT include ANY other text."
        )
        if "SQL_database" in agent_name:
            prompt += "Do not assume or ask the user for the Database schema. First use a query to determine this."
    # Use LangGraph's in-memory checkpointer for thread-level state across steps.
    return create_agent(
        model=llm,
        tools=tools,
        prompt=prompt,
        name=name,
        checkpointer=MemorySaver(),
    )


# Orchestrator with a single supervisor and any number of specialist agents
class Orchestrator(BaseAgent):
    """
    Orchestrator orchestrates multiple specialist agents and manages memory tools.

    Singleton: constructing ``Orchestrator(...)`` anywhere returns the same
    shared instance. The first construction performs full initialization; later
    constructions are no-ops and return the existing instance, so call sites do
    not need to change.
    """

    _instance: "Orchestrator | None" = None
    _initialized: bool = False

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def load_orchestrator(self, *, tools=None, prompt: str | None = None, name: str = "supervisor", checkpointer=None) -> CompiledStateGraph:
        """Compile a LangGraph agent with the supplied tool set and prompt."""
        logger.info("Compiling supervisor with langchain.create_agent")
        return create_agent(
            model=self.base_llm,
            tools=tools or self.master_tools,
            prompt=prompt or self.base_prompt,
            # Important: respect explicit checkpointer. If None, do NOT fall
            # back to self.memory – callers decide whether memory is desired.
            checkpointer=checkpointer,
            name=name,
        )

    def __init__(
        self,
        tool_registry: ToolRegistry,
        config: AgentConfig = None,
        llm=None,
        base_prompt: str = None,
        # Deprecated parameters - kept for backward compatibility
        provider: str = None,
        llm_model: str = None,
    ):
        """
        Initialize the Orchestrator.

        Args:
            tool_registry: The registry containing available tools.
            config: AgentConfig object (required for new code).
            llm: Optional pre-configured LLM instance.
            base_prompt: Optional system prompt override.
            provider: DEPRECATED - use config.llm.provider instead.
            llm_model: DEPRECATED - use config.llm.model_name instead.
        """
        # Avoid trying to re-initialize the singleton on later calls
        if self.__class__._initialized:
            return
        super().__init__()
        logger.info("Initializing Orchestrator")
        
        # Handle backward compatibility
        if config is None:
            warnings.warn(
                "Orchestrator() without config is deprecated. "
                "Pass AgentConfig explicitly.",
                DeprecationWarning,
                stacklevel=2
            )
            config = AgentConfig.from_legacy_config()
        
        if provider is not None or llm_model is not None:
            warnings.warn(
                "provider and llm_model parameters are deprecated. "
                "Set these in AgentConfig.llm instead.",
                DeprecationWarning,
                stacklevel=2
            )
        
        self.config = config
        logger.info(f"Using AgentConfig: provider={config.llm.provider}, model={config.llm.model_name}")
        
        # Set module-level config for memory tools
        memory_tools.set_module_config(config)
        
        self.registry = tool_registry
        
        # Auto-discovery of agent tools
        agent_tool_map = getattr(self.registry, "agent_tools", None)
        if not isinstance(agent_tool_map, dict):
            logger.info("Tool registry 'agent_tools' mapping missing. specific agent routing will be disabled, but tools will be available to the supervisor.")
            all_tools = []
            if hasattr(self.registry, "as_langchain_tools"):
                 all_tools = list(self.registry.as_langchain_tools())
            agent_tool_map = {
                "general_agent": all_tools,
                "memory_agent": [t for t in all_tools if "memory" in t.name]
            }
            self.registry.agent_tools = agent_tool_map

        logger.info(f"Agent tool map keys: {list(agent_tool_map.keys())}")
        
        # Base LLM/prompt and checkpoint memory for thread-level state
        self.base_prompt = base_prompt or single_agent_prompt
        
        # Determine LLM using the config object
        if llm:
            self.base_llm = llm
        else:
            # Pass the full config to the factory
            self.base_llm = LLMFactory.get_llm_model(
                config=self.config,
                provider=provider,  # Allow override for backward compat
                llm_model=llm_model,
            )
            
        # Store model name for logging
        self.llm_model = llm_model or self.config.llm.model_name
        
        self.curr_counter = 0
        self.memory = MemorySaver()
        self._oa_client: OpenAI | None = None
        self._assistant_id: str | None = None
        self._mem_cache: dict[Tuple[str, str, str], Tuple[float, str]] = {}
        try:
            self._mem_ttl = int(os.getenv("AF_MEMORY_SUMMARY_TTL", "90"))
        except Exception:  # noqa
            self._mem_ttl = 90

        logger.info("Compiling supervisor with langchain.create_agent")

        supervisor_tools = []
        if hasattr(self.registry, "as_langchain_tools"):
            try:
                supervisor_tools = list(self.registry.as_langchain_tools())
            except Exception:  # noqa
                supervisor_tools = []

        unique_tools = []
        seen_names = set()
        for t in supervisor_tools or []:
            n = getattr(t, "name", None)
            if n and n not in seen_names:
                seen_names.add(n)
                unique_tools.append(t)

        self.master_tools = unique_tools

        self._memory_tool_names = {
            "save_thread_memory", "search_thread_memory", "delete_thread_memory",
            "save_user_memory", "search_user_memory", "delete_user_memory",
            "save_org_memory", "search_org_memory", "delete_org_memory",
            "save_global_memory", "search_global_memory", "delete_global_memory",
            "summarize_any_memory",
        }
        self._non_memory_tools = [
            t for t in self.master_tools if getattr(t, "name", "") not in self._memory_tool_names
        ]

        self._no_memory_prompt = (
            "You are an AI Agent executing a single-turn task. "
            "Do not read, write, or summarize any memory. "
            "Rely only on the task content and non-memory tools. Keep responses concise."
        )

        self.supervisor = self.load_orchestrator(checkpointer=self.memory)

        self.__class__._initialized = True

        # Warm-up
        try:
            _ = self.base_llm
            from agentfoundry.vectorstores.factory import VectorStoreFactory
            
            # Pass explicit config to factory so it loads the correct provider (e.g. Milvus)
            prov = VectorStoreFactory.get_provider(config=self.config)
            
            try:
                prov.get_store(org_id=None)
                prov.get_store(org_id="global")
            except Exception:  # noqa
                pass
            try:
                if self.config:
                    default_org = self.config.org_id
                else:
                    from agentfoundry.utils.config import Config as _Cfg
                    default_org = str(_Cfg().get("ORG_ID", "") or "")
                    
                if default_org:
                    prov.get_store(org_id=default_org)
            except Exception:  # noqa
                pass
            try:
                from agentfoundry.kgraph.factory import KGraphFactory
                KGraphFactory.get_instance()
            except Exception:  # noqa
                pass
        except Exception as _warm_err:
            logger.debug(f"Warm-up encountered a non-fatal error: {_warm_err}")

    @classmethod
    def get_instance(cls, tool_registry: ToolRegistry | None = None, llm=None, llm_model=None, base_prompt: str | None = None, config: AgentConfig | None = None):
        if cls._instance is None:
            if tool_registry is None:
                raise ValueError("Orchestrator.get_instance requires tool_registry on first call")
            return cls(tool_registry, llm=llm, llm_model=llm_model, base_prompt=base_prompt, config=config)
        return cls._instance

    @staticmethod
    def create_agent(name: str, tools: List[tool], llm, prompt: str | None = None):
        """ Create a specialist agent with the given name, tools, and LLM."""
        agent_name = " ".join(name.split("_")[:-1])
        tool_list_str = "\n".join(
            f"- {t.name}: {t.description}"
            for t in tools
        )
        if prompt is None:
            prompt = (
                f"You are a {agent_name} agent.\n\n"
                "AVAILABLE TOOLS:\n"
                f"{tool_list_str}\n\n"
                "INSTRUCTIONS:\n"
                "- Assist ONLY with tasks related to the agent, or tasks that can be fulfilled by the tools provided.\n"
                "- After you're done with your tasks, respond to the supervisor directly.\n"
                "- Respond ONLY with the results of your work, do NOT include ANY other text."
            )
            if "SQL_database" in agent_name:
                prompt += "Do not assume or ask the user for the Database schema. First use a query to determine this."
        # Use LangGraph's in-memory checkpointer for thread-level state across steps.
        return create_agent(
            model=llm,
            tools=tools,
            prompt=prompt,
            name=name,
            checkpointer=MemorySaver(),
        )

    @staticmethod
    def _content_to_text(content) -> str:
        if content is None:
            return ""
        if isinstance(content, str):
            return content
        if isinstance(content, (bytes, bytearray)):
            try:
                return content.decode("utf-8")
            except Exception:
                return content.decode("utf-8", errors="replace")
        if isinstance(content, (list, tuple)):
            parts: list[str] = []
            for seg in content:
                if isinstance(seg, dict):
                    if "text" in seg:
                        parts.append(str(seg.get("text") or ""))
                    elif "content" in seg:
                        parts.append(str(seg.get("content") or ""))
                    else:
                        parts.append(str(seg))
                else:
                    parts.append(str(seg))
            return "\n".join(p for p in parts if p)
        return str(content)

    @classmethod
    def _normalize_task_input(cls, task_input) -> list[dict[str, str]]:
        normalized: list[dict[str, str]] = []
        if isinstance(task_input, (list, tuple)):
            for item in task_input:
                if isinstance(item, dict):
                    role = item.get("role", "user")
                    content = cls._content_to_text(item.get("content"))
                else:
                    role = "user"
                    content = cls._content_to_text(item)
                normalized.append({"role": str(role or "user"), "content": content})
        elif isinstance(task_input, dict):
            normalized.append({
                "role": str(task_input.get("role", "user") or "user"),
                "content": cls._content_to_text(task_input.get("content")),
            })
        else:
            normalized.append({"role": "user", "content": cls._content_to_text(task_input)})
        if not normalized:
            normalized = [{"role": "user", "content": ""}]
        return normalized

    @classmethod
    def _coerce_task_messages(cls, task_input) -> list:
        if (
            isinstance(task_input, list)
            and task_input
            and isinstance(task_input[0], dict)
            and "role" in task_input[0]
            and "content" in task_input[0]
        ):
            normalized = task_input
        else:
            normalized = cls._normalize_task_input(task_input)

        messages = []
        for item in normalized:
            role = (item.get("role") or "user").lower()
            content = item.get("content", "")
            if role == "system":
                messages.append(SystemMessage(content=content))
            elif role in {"assistant", "ai"}:
                messages.append(AIMessage(content=content))
            else:
                messages.append(HumanMessage(content=content))
        return messages or [HumanMessage(content="")]

    def _build_memory_summary(self, config: dict) -> str:
        if os.getenv("AF_DISABLE_MEMORY_SUMMARY", "false").lower() in ("1", "true", "yes", "on"):
            return ""
        cfg = config.get("configurable", {})
        uid = str(cfg.get("user_id", "") or "")
        tid = str(cfg.get("thread_id", "") or "")
        oid = str(cfg.get("org_id", "") or "")
        key = (uid, tid, oid)
        now = time.perf_counter()
        cached = self._mem_cache.get(key)
        if cached and (now - cached[0]) < self._mem_ttl:
            return cached[1]
        t0 = time.perf_counter()
        try:
            org_id_val = oid
            thread_sum = memory_tools.summarize_any_memory.invoke({
                "level": "thread",
                "config": {"configurable": {"user_id": uid, "thread_id": tid, "org_id": oid}},
            })
            combined_filter = {}
            ors = []
            if uid:
                ors.append({"user_id": uid})
            if org_id_val:
                ors.append({"org_id": org_id_val})
            if len(ors) > 1:
                combined_filter = {"$or": ors}
            elif len(ors) == 1:
                combined_filter = ors[0]
            base_sum = summarize_memory(combined_filter, org_id=org_id_val if org_id_val else None, max_tokens=8000)
            mem_summary = "\n".join(filter(None, [thread_sum, base_sum]))
        except Exception as _mem_err:
            mem_summary = ""
            logger.debug(f"Memory summarization failed: {_mem_err}")
        took_ms = int((time.perf_counter() - t0) * 1000)
        logger.info(f"timing: memory_summary_ms={took_ms} uid={uid} tid={tid} oid={oid} len={len(mem_summary)}")
        self._mem_cache[key] = (now, mem_summary)
        return mem_summary

    def run_task(self, task: str | list | dict, file_id: str = None, vector_store_id: str = None, *args, **kwargs):
        return_additional = kwargs.get('additional', False)
        use_memory: bool = kwargs.get('use_memory', False)
        allow_tools: bool = kwargs.get('allow_tools', False)
        allowed_tool_names: list[str] | None = kwargs.get('allowed_tool_names')
        config = kwargs.get('config') or {"configurable": {"user_id": "1", "thread_id": "1", "org_id": "NA", "security_level": "1"}}
        file_ids: list[str] = []
        if file_id:
            file_ids.append(str(file_id))
        extra_file_ids = kwargs.get('file_ids')
        if extra_file_ids:
            if isinstance(extra_file_ids, (list, tuple, set)):
                file_ids.extend(str(fid) for fid in extra_file_ids)
            else:
                file_ids.append(str(extra_file_ids))
        if file_ids:
            seen_ids: set[str] = set()
            file_ids = [fid for fid in file_ids if not (fid in seen_ids or seen_ids.add(fid))]
            normalized_messages = self._normalize_task_input(task)
            if not vector_store_id:
                env_vs = (os.getenv("OPENAI_VECTOR_STORE_ID") or "").strip()
                vector_store_id = env_vs or None
            if vector_store_id:
                client = None
                for fid in file_ids:
                    try:
                        if client is None:
                            client = self._ensure_oa_client()
                        wait_for_vector_store_file_ready(client, vector_store_id, fid)
                    except Exception as wait_err:  # pragma: no cover - network dependent
                        logger.warning(
                            "run_task: waiting for vector store file failed (fid=%s vs=%s): %s",
                            fid,
                            vector_store_id,
                            wait_err,
                        )
                        vector_store_id = None
                        break
            else:
                logger.warning("run_task: vector_store_id missing; proceeding without file_search binding")
        else:
            normalized_messages = None
        task_preview = task if isinstance(task, str) else str(task)
        logger.info(
            "run_task invoked: additional=%s, use_memory=%s, task=%s",
            return_additional,
            use_memory,
            task_preview[:60],
        )

        mem_summary = self._build_memory_summary(config) if use_memory else ""
        init_msgs = []
        if mem_summary:
            if len(mem_summary) > 400000:
                mem_summary = mem_summary[:400000]
            mem_summary_len = len(mem_summary)
            logger.info(f"run_task: use_memory: {use_memory} mem_summary_len={mem_summary_len} mem_cache_entries={len(self._mem_cache)}")
            init_msgs.append(SystemMessage(content=f"MEMORY_CONTEXT:\n{mem_summary}"))

        payload_for_messages = normalized_messages or self._normalize_task_input(task)
        init_msgs.extend(self._coerce_task_messages(payload_for_messages))

        if file_ids:
            try:
                reply, meta = self._chat_via_openai_responses(
                    messages=payload_for_messages,
                    mem_summary=mem_summary or None,
                    file_ids=file_ids,
                    vector_store_id=vector_store_id,
                )
                reply_text = reply if isinstance(reply, str) else str(reply)
                logger.info(
                    "run_task: Responses API path succeeded (attachments=%d, reply_chars=%d)",
                    len(file_ids),
                    len(reply_text),
                )
                return (reply, meta) if return_additional else reply
            except Exception as resp_err:
                logger.error(
                    "run_task: Responses API path failed; falling back to supervisor: %s",
                    resp_err,
                    exc_info=True,
                )

        init_payload_chars = 0
        for _msg in init_msgs:
            content = getattr(_msg, "content", "")
            if isinstance(content, (bytes, bytearray)):
                content = content.decode("utf-8", errors="replace")
            init_payload_chars += len(str(content))
        logger.info(
            "run_task: init_messages=%d init_payload_chars=%d task_chars=%d",
            len(init_msgs),
            init_payload_chars,
            len(task_preview),
        )

        init = {"messages": init_msgs}
        if not use_memory:
            tool_list = []
            if allow_tools:
                if isinstance(allowed_tool_names, (list, tuple)) and allowed_tool_names:
                    name_set = {str(n) for n in allowed_tool_names}
                    tool_list = [t for t in self._non_memory_tools if getattr(t, 'name', None) in name_set]
                else:
                    tool_list = list(self._non_memory_tools)
            supervisor = create_agent(
                model=self.base_llm,
                tools=tool_list,
                prompt=self._no_memory_prompt,
                checkpointer=None,
                name="NoMemorySupervisor",
            )
            _mn = getattr(self.base_llm, 'model_name', getattr(self.base_llm, 'model', type(self.base_llm).__name__))
            logger.info(f"run_task: using no-memory {_mn} supervisor with {len(tool_list)} tools (allow_tools={allow_tools})")
        else:
            supervisor = self.load_orchestrator(
                tools=self.master_tools,
                prompt=self.base_prompt,
                name=f"supervisor_{uuid.uuid4().hex}",
                checkpointer=MemorySaver(),
            )
            logger.info(
                "run_task: using fresh supervisor with memory and %d tools",
                len(self.master_tools),
            )

        if supervisor is None:
            raise RuntimeError("Supervisor not initialized; cannot execute task")

        t_invoke = time.perf_counter()
        try:
            _t0 = time.perf_counter()
            responses = supervisor.invoke(init, config=config)  # noqa
            _dur_ms = (time.perf_counter() - _t0) * 1000.0
            reply = responses['messages'][-1].content
            if isinstance(reply, (bytes, bytearray)):
                reply = reply.decode("utf-8", errors="replace")
            else:
                reply = str(reply)
            logger.debug(f"Supervisor responses: {responses}")
        except Exception as e:
            logger.error(f"Exception in run_task for task '{task_preview[:60]}': {e}", exc_info=True)
            return f"An error occurred in the task: '{task_preview}': {str(e)}"
        response_messages = responses.get('messages', []) if isinstance(responses, dict) else []
        resp_payload_chars = 0
        tool_call_count = 0
        for _msg in response_messages:
            content = getattr(_msg, "content", "")
            if isinstance(content, (bytes, bytearray)):
                content = content.decode("utf-8", errors="replace")
            resp_payload_chars += len(str(content))
            extra = getattr(_msg, "additional_kwargs", {}) or {}
            tool_calls = extra.get('tool_calls')
            if isinstance(tool_calls, (list, tuple)):
                tool_call_count += len(tool_calls)
            elif tool_calls:
                tool_call_count += 1
        invoke_ms = int((time.perf_counter() - t_invoke) * 1000)
        logger.info(
            "timing: invoke_ms=%d task_chars=%d reply_chars=%d response_messages=%d response_payload_chars=%d tool_calls=%d",
            invoke_ms,
            len(task_preview),
            len(reply),
            len(response_messages),
            resp_payload_chars,
            tool_call_count,
        )
        if return_additional:
            return reply, responses
        for i in range(self.curr_counter, len(responses['messages'])):
            inter = responses['messages'][i]
            if inter.content == "":
                if "tool_calls" in inter.additional_kwargs:
                    for tool_call in inter.additional_kwargs['tool_calls']:
                        logger.info(f"tool call: {tool_call['function']}")
            else:
                logger.debug(f"intermediate message: {str(responses['messages'][i].content).encode('utf-8')[:60]}...")
        self.curr_counter = len(responses['messages'])
        logger.info(f"run_task completed: reply: {reply[:120]}")
        return reply

    def chat(self, messages: list[dict], config: dict = None, additional: bool = False, file_ids: list[str] = None, vector_store_id: str = None):
        logger.info(f"chat invoked: messages_count={len(messages)}, additional={additional}")
        if config is None:
            config = {"configurable": {"user_id": "1", "thread_id": "1", "org_id": "NA", "security_level": "1"}}
        logger.debug(f"chat config: {config}")

        mem_summary = self._build_memory_summary(config)

        msg_objs = []
        if mem_summary:
            if len(mem_summary) > 400_000:
                mem_summary = mem_summary[:400_000]
            msg_objs.append(SystemMessage(content=f"MEMORY_CONTEXT:\n{mem_summary}"))
        for msg in messages:
            role = msg.get("role", "").lower()
            content = msg.get("content", "")
            if role == "system":
                msg_objs.append(SystemMessage(content=content))
            elif role == "user":
                msg_objs.append(HumanMessage(content=content))
            elif role in ("assistant", "ai"):
                msg_objs.append(AIMessage(content=content))
            else:
                raise ValueError(f"Unknown message role: {role}")
        if file_ids:
            try:
                if os.getenv("AF_FORCE_ASSISTANTS_FOR_FILES", "").strip().lower() in ("1", "true", "yes", "on"):
                    raise RuntimeError("Forced Assistants path via AF_FORCE_ASSISTANTS_FOR_FILES")
                reply, meta = self._chat_via_openai_responses(messages=messages, mem_summary=mem_summary, file_ids=file_ids, vector_store_id=vector_store_id)
                if additional:
                    return reply, meta
                return reply
            except Exception as e:
                msg = str(e)
                if isinstance(e, TypeError) and "unexpected keyword argument 'attachments'" in msg:
                    logger.info(f"Responses API attachments not supported by installed OpenAI SDK: {msg}")
                else:
                    logger.exception(f"Responses API chat failed: {msg}")
                raise e

        init = {"messages": msg_objs}

        t_invoke = time.perf_counter()
        _t0 = time.perf_counter()
        responses = self.supervisor.invoke(init, config=config)  # noqa
        _dur_ms = (time.perf_counter() - _t0) * 1000.0
        logger.info(f"Supervisor.invoke completed in {_dur_ms:.1f} ms")
        reply = responses['messages'][-1].content
        invoke_ms = int((time.perf_counter() - t_invoke) * 1000)
        logger.info(f"timing: invoke_ms={invoke_ms} chat_msgs={len(messages)} reply_chars={len(str(reply))}")
        if additional:
            logger.info(f"chat completed with additional output: reply={reply}")
            return reply, responses
        logger.info(f"chat completed: reply={reply}")
        return reply

    def upload_file(self, file_path: str):
        pass

    def _ensure_oa_client(self) -> OpenAI:
        if self._oa_client is None:
            self._oa_client = OpenAI()
        return self._oa_client

    def _ensure_assistant(self) -> str:
        if self._assistant_id:
            return self._assistant_id
        client = self._ensure_oa_client()
        model = os.getenv("AF_ASSISTANTS_MODEL") or os.getenv("OPENAI_ASSISTANTS_MODEL") or "gpt-4o"
        name = os.getenv("AF_ASSISTANT_NAME", "Supervisor")
        base_instructions = self.base_prompt or "You are an AI assistant."
        assistant = client.beta.assistants.create(
            name=name,
            instructions=base_instructions,
            model=model,
            tools=[{"type": "file_search"}],  # noqa
        )
        self._assistant_id = assistant.id
        logger.info(f"Assistants API: created assistant id={assistant.id} model={model}")
        return assistant.id

    def _chat_via_openai_responses(self, *, messages: list[dict], mem_summary: str | None, file_ids: list[str], vector_store_id: str = None):
        client = self._ensure_oa_client()
        model = os.getenv("AF_RESPONSES_MODEL") or os.getenv("OPENAI_RESPONSES_MODEL") or "gpt-5-mini"

        input_msgs: list[dict] = []
        inst_chunks: list[str] = []
        if self.base_prompt:
            inst_chunks.append(self.base_prompt)
        if mem_summary:
            summary = mem_summary if len(mem_summary) <= 200_000 else mem_summary[:200_000]
            input_msgs.append({
                "role": "system",
                "content": [{"type": "input_text", "text": f"MEMORY_CONTEXT:\n{summary}"}]
            })
        for m in messages:
            role = (m.get("role") or "").lower()
            content = str(m.get("content", ""))
            if role == "system":
                inst_chunks.append(content)
            elif role in ("user", "assistant"):
                input_msgs.append({
                    "role": role,
                    "content": [{"type": "input_text", "text": content}]
                })
            else:
                raise ValueError(f"Unknown message role for Responses API: {role}")
        use_file_search = bool(vector_store_id)
        tools: list[dict[str, Any]] = (
            [{"type": "file_search", "vector_store_ids": [vector_store_id]}]
            if use_file_search
            else []
        )
        
        t0 = time.perf_counter()
        attachments = None
        norm_ids: list[str] = []
        if file_ids:
            for fid in (file_ids or []):
                s = str(fid)
                m = re.search(r"(file-[A-Za-z0-9][A-Za-z0-9_-]*)", s)
                if m:
                    norm_ids.append(m.group(1))
                else:
                    logger.warning(f"Responses: skipping unrecognised file id format: {s!r}")
            seen = set()
            norm_ids = [x for x in norm_ids if not (x in seen or seen.add(x))]
            if norm_ids and use_file_search:
                attach_tools = [{"type": "file_search", "vector_store_ids": [vector_store_id]}]
                attachments = [{"file_id": fid, "tools": attach_tools} for fid in norm_ids]
        logger.debug(
            "Responses API call: model=%s tools=%d attachments=%d msgs=%d",
            model,
            len(tools or []),
            len(attachments or []),
            len(input_msgs)
        )
        base_kwargs = dict(
            model=model,
            input=input_msgs if input_msgs else messages[-1].get("content", ""),
            **({"instructions": "\n\n".join(inst_chunks)} if inst_chunks else {})
        )
        if vector_store_id:
            base_kwargs["tools"] = [{"type": "file_search", "vector_store_ids": [vector_store_id]}]

        def _embed_files_into_input():
            added = 0
            for fid in norm_ids:
                try:
                    try:
                        meta = client.files.retrieve(fid)
                    except Exception:  # noqa
                        meta = None
                    name = getattr(meta, "filename", None) or getattr(meta, "name", None) or fid
                    try:
                        r = client.files.content(fid)
                        raw = getattr(r, "read", None) and r.read() or getattr(r, "content", None)
                    except Exception:  # noqa
                        raw = None
                    text = None
                    if isinstance(raw, (bytes, bytearray)) and len(raw) > 0:
                        class _FileLike:
                            def __init__(self, data: bytes, filename: str):
                                self._data = data
                                self.filename = filename
                            def read(self):
                                return self._data
                        try:
                            text = ingest_document(_FileLike(raw, name))  # noqa
                        except Exception:  # noqa
                            text = None
                    if not text:
                        size = len(raw) if isinstance(raw, (bytes, bytearray)) else 0
                        text = f"[attachment unavailable or binary-only: {name} size={size} bytes]"
                    input_msgs.append({
                        "role": "system",
                        "content": [{"type": "input_text", "text": f"ATTACHED FILE: {name}\n\n{text}"}]
                    })
                    added += 1
                except Exception:  # noqa
                    continue
            return added

        inline_injected = False
        if norm_ids and not use_file_search:
            inline_injected = _embed_files_into_input() > 0

        try:
            if vector_store_id:
                resp = client.responses.create(**base_kwargs)
            elif norm_ids:
                try:
                    resp = client.responses.create(**base_kwargs, tool_resources={"file_search": {"file_ids": norm_ids}})  # noqa
                except Exception:
                    resp = client.responses.create(**base_kwargs, attachments=attachments) if attachments else client.responses.create(**base_kwargs)
            else:
                resp = client.responses.create(**base_kwargs)
        except TypeError:
            try:
                if use_file_search and norm_ids:
                    resp = client.responses.create(**base_kwargs, tool_resources={"file_search": {"file_ids": norm_ids}})  # noqa
                else:
                    raise
            except Exception:  # noqa
                if inline_injected or _embed_files_into_input() > 0:
                    resp = client.responses.create(model=model, input=input_msgs, tools=tools, **({"instructions": "\n\n".join(inst_chunks)} if inst_chunks else {}))  # noqa
                else:
                    raise
        except Exception as _e:
            s = str(_e)
            if ("attachments" in s) or ("tool_resources" in s) or ("vector_store_ids" in s):
                try:
                    if use_file_search and norm_ids:
                        resp = client.responses.create(**base_kwargs, tool_resources={"file_search": {"file_ids": norm_ids}})  # noqa
                    else:
                        raise
                except Exception:  # noqa
                    if inline_injected or _embed_files_into_input() > 0:
                        resp = client.responses.create(model=model, input=input_msgs, tools=tools, **({"instructions": "\n\n".join(inst_chunks)} if inst_chunks else {}))  # noqa
                    else:
                        raise
            else:
                raise
        dt_ms = int((time.perf_counter() - t0) * 1000)

        try:
            reply_text = getattr(resp, "output_text", None)
        except Exception:  # noqa
            reply_text = None
        if not reply_text:
            try:
                chunks = []
                for item in getattr(resp, "output", []) or []:
                    for part in getattr(item, "content", []) or []:
                        t = getattr(part, "type", None)
                        if t in ("output_text", "text"):
                            text_obj = getattr(part, "text", None)
                            val = getattr(text_obj, "value", None) if text_obj is not None else None
                            if not val:
                                val = str(getattr(part, "text", ""))
                            if val:
                                chunks.append(str(val))
                if chunks:
                    reply_text = "\n".join(chunks)
            except Exception:  # noqa
                pass
        if not reply_text:
            reply_text = str(getattr(resp, "output", "")) or ""

        logger.info(
            "Responses chat completed: time_ms=%d chars=%d files=%d model=%s",
            dt_ms,
            len(reply_text or ""),
            len(file_ids or []),
            model,
        )
        meta = {
            "api": "responses",
            "model": model,
            "time_ms": dt_ms,
        }
        return reply_text, meta


def wait_for_vector_store_file_ready(client, vector_store_id: str, file_id: str, timeout_s: int = 1200, poll_s: float = 1.5):
    import time
    t0 = time.time()
    while True:
        files_page = client.vector_stores.files.list(vector_store_id=vector_store_id, limit=100)
        items = getattr(files_page, "data", []) or []
        status = None
        for it in items:
            if getattr(it, "id", None) == file_id:
                status = getattr(it, "status", None) or getattr(it, "state", None)
                break
        if status == "completed":
            return
        if status == "failed":
            raise RuntimeError(f"Vector store indexing failed for file {file_id}")
        if time.time() - t0 > timeout_s:
            raise TimeoutError(f"Timed out waiting for vector store to index file {file_id}")
        time.sleep(poll_s)