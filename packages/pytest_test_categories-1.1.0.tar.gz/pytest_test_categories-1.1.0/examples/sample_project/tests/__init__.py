"""Test suite for sample_project demonstrating test categorization."""

from __future__ import annotations
