from __future__ import annotations


class DescribeTestInfrastructure:
    def it_runs_a_test(self) -> None:
        assert True
