import filecmp
import os
import shutil
import sys

from setuptools import Extension, setup
from numpy import get_include


BASE_DIR = os.path.dirname(__file__)
THIRDPARTY_DIR = os.path.join(BASE_DIR, "thirdparty")
CEW_DIR = os.path.join(BASE_DIR, "aeneas", "cew")
IS_WINDOWS = sys.platform.startswith("win")
IS_LINUX = sys.platform.startswith("linux")
IS_OSX = sys.platform == "darwin"
IS_64BITS = sys.maxsize > 2**32

TRUE_VALUES = ["1", "true", "True", "YES", "yes", "on", "ON"]
WITHOUT_CEW = os.getenv("AENEAS_WITH_CEW", "True") not in TRUE_VALUES
FORCE_CEW = os.getenv("AENEAS_FORCE_CEW", "False") in TRUE_VALUES
USE_ESPEAKNG = os.getenv("AENEAS_USE_ESPEAKNG", "True") in TRUE_VALUES


def _copy_file(src, dst):
    if not os.path.exists(src):
        print(f"[WARN] Required file not found: {src}")
        return False
    if os.path.exists(dst) and filecmp.cmp(src, dst, shallow=False):
        return True
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    shutil.copyfile(src, dst)
    return True


def prepare_cew_speak_lib():
    """
    Ensure speak_lib.h matches the requested eSpeak implementation.
    """

    header_name = "speak-ng_lib.h" if USE_ESPEAKNG else "speak_lib.h"
    header_src = os.path.join(THIRDPARTY_DIR, header_name)
    header_dst = os.path.join(CEW_DIR, "speak_lib.h")
    if _copy_file(header_src, header_dst):
        return True
    print("[WARN] Unable to prepare speak_lib.h, eSpeak bindings may fail.")
    return False


def prepare_cew_for_windows():
    """
    Copy the required eSpeak libraries/DLLs for Windows builds.
    """

    if not IS_WINDOWS:
        return True

    try:
        if USE_ESPEAKNG:
            lib_src = os.path.join(
                THIRDPARTY_DIR,
                "libespeak-ng-x64.lib" if IS_64BITS else "libespeak-ng-x86.lib",
            )
            lib_dst = os.path.join(BASE_DIR, "espeak-ng.lib")
            if not _copy_file(lib_src, lib_dst):
                return False
            dll_src_paths = [
                r"C:\Program Files\eSpeak NG\libespeak-ng.dll",
                r"C:\Program Files (x86)\eSpeak NG\libespeak-ng.dll",
            ]
            dll_dst = os.path.join(CEW_DIR, "libespeak-ng.dll")
        else:
            lib_src = os.path.join(THIRDPARTY_DIR, "espeak.lib")
            lib_dst = os.path.join(BASE_DIR, "espeak.lib")
            if not _copy_file(lib_src, lib_dst):
                return False
            dll_src_paths = [
                r"C:\Program Files\eSpeak\espeak_sapi.dll",
                r"C:\Program Files (x86)\eSpeak\espeak_sapi.dll",
            ]
            dll_dst = os.path.join(CEW_DIR, "espeak.dll")

        if not os.path.exists(dll_dst):
            for candidate in dll_src_paths:
                if os.path.exists(candidate):
                    shutil.copyfile(candidate, dll_dst)
                    break
        return True
    except Exception as exc:  # pragma: no cover - best effort copy
        print(f"[WARN] Unexpected exception while preparing cew for Windows: {exc}")
        return False


def get_espeak_lib():
    return "espeak-ng" if USE_ESPEAKNG else "espeak"

# prepare Extension objects
EXTENSION_CDTW = Extension(
    name="aeneas.cdtw.cdtw",
    sources=[
        "aeneas/cdtw/cdtw_py.c",
        "aeneas/cdtw/cdtw_func.c",
        "aeneas/cint/cint.c"
    ],
    include_dirs=[
        get_include()
    ]
)
EXTENSION_CMFCC = Extension(
    name="aeneas.cmfcc.cmfcc",
    sources=[
        "aeneas/cmfcc/cmfcc_py.c",
        "aeneas/cmfcc/cmfcc_func.c",
        "aeneas/cwave/cwave_func.c",
        "aeneas/cint/cint.c"
    ],
    include_dirs=[
        get_include()
    ]
)
cew_library_dirs = [THIRDPARTY_DIR] if IS_WINDOWS else []
EXTENSION_CEW = Extension(
    name="aeneas.cew.cew",
    sources=[
        "aeneas/cew/cew_py.c",
        "aeneas/cew/cew_func.c"
    ],
    include_dirs=[
        get_include(),
    ],
    library_dirs=cew_library_dirs,
    libraries=[
        get_espeak_lib()
    ]
)
EXTENSION_CFW = Extension(
    name="aeneas.cfw.cfw",
    sources=[
        "aeneas/cfw/cfw_py.cc",
        "aeneas/cfw/cfw_func.cc"
    ],
    include_dirs=[
        "aeneas/cfw/festival",
        "aeneas/cfw/speech_tools"
    ],
    libraries=[
        "Festival",
        "estools",
        "estbase",
        "eststring",
    ]
)

EXTENSIONS = [
    EXTENSION_CDTW,
    EXTENSION_CMFCC,
]

if not IS_WINDOWS:
    EXTENSIONS.append(EXTENSION_CFW)

def _should_build_cew():
    if WITHOUT_CEW and not FORCE_CEW:
        print("[INFO] Skipping cew extension (AENEAS_WITH_CEW is false).")
        return False
    if not prepare_cew_speak_lib():
        return False
    if IS_WINDOWS:
        return prepare_cew_for_windows()
    return True


if _should_build_cew():
    EXTENSIONS.append(EXTENSION_CEW)
else:
    print("[WARN] cew extension will not be built.")


setup(
    name="aeneas-ng",
    ext_modules=EXTENSIONS
)
