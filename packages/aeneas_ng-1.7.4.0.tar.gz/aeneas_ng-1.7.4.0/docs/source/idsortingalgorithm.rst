idsortingalgorithm
==================

.. automodule:: aeneas.idsortingalgorithm
    :members:
