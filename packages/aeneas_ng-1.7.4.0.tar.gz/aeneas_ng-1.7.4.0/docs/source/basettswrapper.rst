basettswrapper
==============

.. automodule:: aeneas.ttswrappers.basettswrapper
    :members:
