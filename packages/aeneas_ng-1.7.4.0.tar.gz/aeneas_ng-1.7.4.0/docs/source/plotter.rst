plotter
=======

.. automodule:: aeneas.plotter
    :members:
