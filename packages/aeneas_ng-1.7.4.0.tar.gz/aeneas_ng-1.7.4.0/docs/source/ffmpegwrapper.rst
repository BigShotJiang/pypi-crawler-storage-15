ffmpegwrapper
=============

.. automodule:: aeneas.ffmpegwrapper
    :members:
