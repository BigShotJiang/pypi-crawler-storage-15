vad
===

.. automodule:: aeneas.vad
    :members:
