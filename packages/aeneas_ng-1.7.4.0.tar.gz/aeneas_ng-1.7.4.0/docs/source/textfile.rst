textfile
========

.. automodule:: aeneas.textfile
    :members:
