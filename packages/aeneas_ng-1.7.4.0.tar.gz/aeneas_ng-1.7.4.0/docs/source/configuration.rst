configuration
=============

.. automodule:: aeneas.configuration
    :members:
