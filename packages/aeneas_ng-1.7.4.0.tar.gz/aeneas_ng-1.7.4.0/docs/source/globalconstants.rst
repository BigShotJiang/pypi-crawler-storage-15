globalconstants
===============

.. automodule:: aeneas.globalconstants
    :members:
