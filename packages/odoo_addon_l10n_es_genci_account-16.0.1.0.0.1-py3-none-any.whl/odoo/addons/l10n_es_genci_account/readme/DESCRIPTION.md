This module integrates the GENCI system into Odoo accounting, automatically applying the GENCI environmental rate on invoice lines where applicable.
