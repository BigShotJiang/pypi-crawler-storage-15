"""
Nothing to see here, this is a dummy module. Django won't wire us up to migration signals without it.
"""
