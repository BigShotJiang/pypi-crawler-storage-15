def get_input(prompt=""):
    return input(prompt + "\n\033[;32m>>>\033[0m ")

