import React from "react"
import ReactDOM from "react-dom"
import AutoPlay from './App'

ReactDOM.render(
  <React.StrictMode>
    <AutoPlay />
  </React.StrictMode>,
  document.getElementById("root")
)
