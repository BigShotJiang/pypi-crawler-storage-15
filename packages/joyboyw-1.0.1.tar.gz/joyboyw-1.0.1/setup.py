from setuptools import setup
setup(name='joyboyw',version='1.0.1',packages=['filter'],python_requires='>=3.6')
