export const TRANSLATOR_DOMAIN = 'jupyterlab-judge';
export const BROWSER_NAME = 'judgebrowser';
export const JUDGE_HIDDEN_FOLDER_NAME = '.jce-judge';
export const PLUGIN_ID = 'jupyterlab-judge';
