"""
DockerWorker - Docker containerized execution worker.

This module implements the DockerWorker class for executing HEC-RAS in
Docker containers using Rocky Linux 8 with native HEC-RAS 6.6 Linux binaries.

Workflow:
    1. Preprocess plan on Windows host (creates .tmp.hdf files)
    2. Execute simulation in Linux Docker container
    3. Copy results back to project folder

Requirements:
    pip install ras-commander[remote-docker]
    # or: pip install docker
"""

import shutil
import uuid
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Optional, Any

from .RasWorker import RasWorker
from ..LoggingConfig import get_logger
from ..Decorators import log_call

logger = get_logger(__name__)


def check_docker_dependencies():
    """
    Check if docker is available, raise clear error if not.

    This function is called lazily only when Docker functionality is actually used.
    """
    try:
        import docker
        return docker
    except ImportError:
        raise ImportError(
            "Docker worker requires docker.\n"
            "Install with: pip install ras-commander[remote-docker]\n"
            "Or: pip install docker"
        )


@dataclass
class DockerWorker(RasWorker):
    """
    Docker containerized HEC-RAS execution worker.

    Uses Rocky Linux 8 container with native HEC-RAS 6.6 Linux binaries.
    Requires two-step workflow:
        1. Preprocess on Windows (creates .tmp.hdf files)
        2. Execute simulation in Linux container

    Attributes:
        docker_image: Docker image name/tag (e.g., "hecras:6.6")
        docker_host: Docker daemon URL (None for local, or "tcp://host:2375")
        container_input_path: Mount point for project files in container
        container_output_path: Mount point for results in container
        container_script_path: Path to run_ras.sh in container
        max_runtime_minutes: Timeout for simulation (default 480 = 8 hours)
        preprocess_on_host: Whether to run preprocessing on Windows host first
        cpu_limit: CPU limit for container (e.g., "4" or "0.5")
        memory_limit: Memory limit (e.g., "8g", "4096m")

    Example:
        >>> worker = init_docker_worker(
        ...     docker_image="hecras:6.6",
        ...     cores_total=8,
        ...     cores_per_plan=4,
        ...     preprocess_on_host=True
        ... )
    """

    # Docker configuration
    docker_image: str = None
    docker_host: Optional[str] = None

    # Container paths (Linux paths)
    container_input_path: str = "/app/input"
    container_output_path: str = "/app/output"
    container_script_path: str = "/app/scripts/core_execution/run_ras.sh"

    # Execution configuration
    max_runtime_minutes: int = 480
    preprocess_on_host: bool = True

    # Resource limits
    cpu_limit: Optional[str] = None
    memory_limit: Optional[str] = None

    # Worker configuration
    process_priority: str = "low"
    queue_priority: int = 0
    cores_total: Optional[int] = None
    cores_per_plan: int = 4
    max_parallel_plans: Optional[int] = None

    # Staging directory for file operations
    staging_directory: Optional[str] = None

    def __post_init__(self):
        """Validate Docker worker configuration."""
        super().__post_init__()
        self.worker_type = "docker"

        if not self.docker_image:
            raise ValueError("docker_image is required for DockerWorker")

        # Calculate parallel capacity
        if self.cores_total is not None and self.cores_per_plan:
            self.max_parallel_plans = max(1, self.cores_total // self.cores_per_plan)
        elif self.max_parallel_plans is None:
            self.max_parallel_plans = 1

        # Set default staging directory
        if self.staging_directory is None:
            import tempfile
            self.staging_directory = tempfile.gettempdir()

        logger.debug(f"DockerWorker initialized: image={self.docker_image}, "
                    f"host={self.docker_host or 'local'}, "
                    f"max_parallel={self.max_parallel_plans}")


@log_call
def init_docker_worker(**kwargs) -> DockerWorker:
    """
    Initialize and validate a Docker worker.

    Args:
        docker_image: Docker image with HEC-RAS Linux (required, e.g., "hecras:6.6")
        docker_host: Docker daemon URL (optional, default: local)
        worker_id: Custom worker ID (auto-generated if not provided)
        cores_total: Total CPU cores available for this worker
        cores_per_plan: CPU cores to allocate per plan
        max_runtime_minutes: Simulation timeout (default: 480)
        preprocess_on_host: Run Windows preprocessing first (default: True)
        cpu_limit: Container CPU limit
        memory_limit: Container memory limit (e.g., "8g")
        **kwargs: Additional DockerWorker parameters

    Returns:
        DockerWorker: Validated worker instance

    Raises:
        ImportError: If docker package not installed
        ValueError: If validation fails
        docker.errors.DockerException: If Docker daemon unreachable

    Example:
        >>> worker = init_docker_worker(
        ...     docker_image="hecras:6.6",
        ...     cores_total=8,
        ...     cores_per_plan=4
        ... )
    """
    docker = check_docker_dependencies()

    kwargs['worker_type'] = 'docker'

    # Default ras_exe_path for Linux container
    if 'ras_exe_path' not in kwargs:
        kwargs['ras_exe_path'] = '/app/bin/RasUnsteady'

    worker = DockerWorker(**kwargs)

    # Verify Docker daemon connectivity
    try:
        if worker.docker_host:
            client = docker.DockerClient(base_url=worker.docker_host)
        else:
            client = docker.from_env()

        client.ping()
        logger.info(f"Docker daemon connected: {worker.docker_host or 'local'}")

        # Check if image exists
        try:
            client.images.get(worker.docker_image)
            logger.info(f"Docker image found: {worker.docker_image}")
        except docker.errors.ImageNotFound:
            logger.warning(f"Docker image not found: {worker.docker_image}")
            logger.warning("Image must be built or pulled before execution")

        client.close()

    except docker.errors.DockerException as e:
        logger.error(f"Cannot connect to Docker daemon: {e}")
        raise

    logger.info(f"DockerWorker initialized:")
    logger.info(f"  Image: {worker.docker_image}")
    logger.info(f"  Host: {worker.docker_host or 'local'}")
    logger.info(f"  Preprocess on host: {worker.preprocess_on_host}")
    logger.info(f"  Max parallel plans: {worker.max_parallel_plans}")
    logger.info(f"  Timeout: {worker.max_runtime_minutes} minutes")

    return worker


def _extract_geometry_number(project_path: Path, plan_number: str) -> Optional[str]:
    """
    Extract geometry file number from plan file.

    HEC-RAS plan files reference geometry files with "Geom File=gXX" syntax.
    The geometry number is DIFFERENT from the plan number.

    Args:
        project_path: Path to project folder
        plan_number: Plan number (e.g., "01")

    Returns:
        Geometry number as string (e.g., "13") or None if not found
    """
    plan_files = list(project_path.glob(f"*.p{plan_number}"))
    if not plan_files:
        return None

    plan_file = plan_files[0]
    try:
        with open(plan_file, 'r', encoding='utf-8', errors='ignore') as f:
            for line in f:
                if line.strip().startswith("Geom File="):
                    geom_ref = line.split('=')[1].strip()
                    if geom_ref.startswith('g'):
                        return geom_ref[1:]
        return None
    except Exception as e:
        logger.error(f"Error reading plan file {plan_file}: {e}")
        return None


def _preprocess_plan_for_linux(
    ras_obj,
    plan_number: str,
    project_staging: Path,
    stability_timeout: int = 10,
    max_wait: int = 120
) -> bool:
    """
    Preprocess a plan on Windows to create files needed for Linux execution.

    This runs HEC-RAS briefly on Windows to generate:
    - .tmp.hdf file (preprocessed geometry and initial conditions)
    - .b file (binary geometry)
    - .x file (execution file)

    Args:
        ras_obj: RasPrj object
        plan_number: Plan number to preprocess
        project_staging: Path to staged project copy
        stability_timeout: Seconds to wait for file stability
        max_wait: Maximum seconds to wait

    Returns:
        bool: True if preprocessing succeeded
    """
    try:
        # Import here to avoid circular imports
        from ..RasPrj import init_ras_project
        from ..RasGeo import RasGeo
        from ..RasPlan import RasPlan
        from ..RasCmdr import RasCmdr

        # Initialize the staged project
        temp_ras = init_ras_project(str(project_staging), ras_obj.ras_version)
        project_name = temp_ras.project_name

        logger.info(f"Preprocessing plan {plan_number} for Linux execution...")

        # Clear geometry preprocessor files
        logger.debug("Clearing geometry preprocessor files...")
        RasGeo.clear_geompre_files(plan_files=plan_number, ras_object=temp_ras)

        # Extract geometry number
        geometry_number = _extract_geometry_number(project_staging, plan_number)
        if not geometry_number:
            logger.error(f"Could not extract geometry number for plan {plan_number}")
            return False

        logger.info(f"Plan {plan_number} uses geometry {geometry_number}")

        # Clear existing HDF/binary files to force regeneration
        for pattern in [f"*.p{plan_number}.hdf", f"*.p{plan_number}.tmp.hdf",
                       f"*.b{plan_number}", f"*.x{geometry_number}"]:
            for f in project_staging.glob(pattern):
                try:
                    f.unlink()
                    logger.debug(f"Deleted: {f.name}")
                except:
                    pass

        # Set plan flags for preprocessing
        plan_file_path = project_staging / f"{project_name}.p{plan_number}"
        if plan_file_path.exists():
            RasPlan.update_run_flags(
                plan_number_or_path=str(plan_file_path),
                geometry_preprocessor=True,
                unsteady_flow_simulation=True,
                post_processor=True,
                ras_object=temp_ras
            )

        # Run computation (this will be terminated early)
        logger.info("Starting HEC-RAS preprocessing (early termination)...")

        # Start the computation
        success = RasCmdr.compute_plan(
            plan_number=plan_number,
            ras_object=temp_ras,
            clear_geompre=False,  # Already cleared
            num_cores=1
        )

        # Check if .tmp.hdf was created
        tmp_hdf = project_staging / f"{project_name}.p{plan_number}.tmp.hdf"
        hdf = project_staging / f"{project_name}.p{plan_number}.hdf"

        if tmp_hdf.exists():
            logger.info(f"Preprocessing complete: {tmp_hdf.name} ({tmp_hdf.stat().st_size / 1024 / 1024:.1f} MB)")
            return True
        elif hdf.exists():
            logger.info(f"HDF file exists: {hdf.name} ({hdf.stat().st_size / 1024 / 1024:.1f} MB)")
            return True

        logger.error("Preprocessing did not create HDF file")
        return False

    except Exception as e:
        logger.error(f"Preprocessing failed: {e}", exc_info=True)
        return False


@log_call
def execute_docker_plan(
    worker: DockerWorker,
    plan_number: str,
    ras_obj,
    num_cores: int,
    clear_geompre: bool,
    sub_worker_id: int = 1,
    autoclean: bool = True
) -> bool:
    """
    Execute a HEC-RAS plan in a Linux Docker container.

    Two-step workflow:
        1. Preprocess on Windows host (if preprocess_on_host=True)
        2. Run simulation in Linux container

    Args:
        worker: DockerWorker instance
        plan_number: Plan number to execute (e.g., "01")
        ras_obj: RasPrj object with project information
        num_cores: Number of cores for simulation
        clear_geompre: Whether to clear geometry preprocessor files
        sub_worker_id: Sub-worker identifier for parallel execution
        autoclean: Remove staging files after completion

    Returns:
        bool: True if execution succeeded, False otherwise
    """
    docker = check_docker_dependencies()

    project_folder = Path(ras_obj.project_folder)
    project_name = ras_obj.project_name

    logger.info(f"Starting Docker execution: plan {plan_number}, sub-worker {sub_worker_id}")

    # Create staging directory
    staging_base = Path(worker.staging_directory)
    staging_folder = staging_base / f"ras_docker_{project_name}_p{plan_number}_sw{sub_worker_id}_{uuid.uuid4().hex[:8]}"

    input_staging = staging_folder / "input"
    output_staging = staging_folder / "output"

    try:
        staging_folder.mkdir(parents=True, exist_ok=True)
        input_staging.mkdir(parents=True, exist_ok=True)
        output_staging.mkdir(parents=True, exist_ok=True)
        logger.debug(f"Created staging: {staging_folder}")

        # Copy project to staging (flat structure - files directly in input)
        logger.info(f"Copying project to staging...")
        for item in project_folder.iterdir():
            if item.is_file():
                shutil.copy2(item, input_staging / item.name)
            elif item.is_dir():
                shutil.copytree(item, input_staging / item.name, dirs_exist_ok=True)

        # Step 1: Preprocess on Windows (if enabled)
        if worker.preprocess_on_host:
            if not _preprocess_plan_for_linux(ras_obj, plan_number, input_staging):
                logger.error("Windows preprocessing failed")
                return False

        # Extract geometry number
        geometry_number = _extract_geometry_number(input_staging, plan_number)
        if not geometry_number:
            logger.error(f"Could not extract geometry number for plan {plan_number}")
            return False

        logger.info(f"Plan {plan_number} uses geometry {geometry_number}")

        # Step 2: Run in Docker container
        if worker.docker_host:
            client = docker.DockerClient(base_url=worker.docker_host)
        else:
            client = docker.from_env()

        # Volume mounts - convert Windows paths to Docker-compatible format
        input_path = str(input_staging).replace('\\', '/')
        output_path = str(output_staging).replace('\\', '/')

        volumes = {
            input_path: {'bind': worker.container_input_path, 'mode': 'rw'},
            output_path: {'bind': worker.container_output_path, 'mode': 'rw'},
        }

        # Environment variables
        environment = {
            'MAX_RUNTIME_MINUTES': str(worker.max_runtime_minutes),
            'GEOMETRY_NUMBER': geometry_number,
        }

        # Container configuration
        container_kwargs = {
            'image': worker.docker_image,
            'command': [worker.container_script_path, plan_number],
            'volumes': volumes,
            'environment': environment,
            'detach': True,
            'remove': False,
        }

        if worker.cpu_limit:
            container_kwargs['nano_cpus'] = int(float(worker.cpu_limit) * 1e9)
        if worker.memory_limit:
            container_kwargs['mem_limit'] = worker.memory_limit

        logger.info(f"Starting container: {worker.docker_image}")
        container = client.containers.run(**container_kwargs)
        container_id = container.short_id
        logger.info(f"Container started: {container_id}")

        # Wait for completion
        timeout_seconds = worker.max_runtime_minutes * 60
        start_time = time.time()

        try:
            result = container.wait(timeout=timeout_seconds)
            exit_code = result.get('StatusCode', -1)
            elapsed = time.time() - start_time

            logger.info(f"Container finished in {elapsed:.1f}s, exit code {exit_code}")

            logs = container.logs(stdout=True, stderr=True).decode('utf-8', errors='replace')
            if exit_code != 0:
                logger.error(f"Container logs:\n{logs}")
            else:
                logger.debug(f"Container logs:\n{logs}")

        except Exception as e:
            logger.error(f"Container execution failed: {e}")
            try:
                container.kill()
            except:
                pass
            return False
        finally:
            try:
                container.remove()
            except:
                pass
            client.close()

        if exit_code != 0:
            logger.error(f"Simulation failed with exit code {exit_code}")
            return False

        # Copy results back
        # Look for HDF results in both output and input staging
        result_patterns = [
            f"{project_name}.p{plan_number}*.hdf",
            f"{project_name}.p{plan_number}.tmp.hdf",
        ]

        result_files = []
        for pattern in result_patterns:
            result_files.extend(output_staging.glob(pattern))
            result_files.extend(input_staging.glob(pattern))

        # Remove duplicates
        result_files = list(set(result_files))

        if not result_files:
            logger.error(f"No HDF results found")
            return False

        for result_file in result_files:
            dest_file = project_folder / result_file.name
            logger.info(f"Copying result: {result_file.name}")
            shutil.copy2(result_file, dest_file)

        # Copy log files
        for log_pattern in ["*.log", "*.computeMsgs.txt", "ras_execution.log"]:
            for log_file in output_staging.glob(log_pattern):
                shutil.copy2(log_file, project_folder / log_file.name)
            for log_file in input_staging.glob(log_pattern):
                if not (project_folder / log_file.name).exists():
                    shutil.copy2(log_file, project_folder / log_file.name)

        logger.info(f"Docker execution completed for plan {plan_number}")
        return True

    except Exception as e:
        logger.error(f"Docker execution error: {e}", exc_info=True)
        return False

    finally:
        if autoclean and staging_folder.exists():
            try:
                shutil.rmtree(staging_folder, ignore_errors=True)
                logger.debug(f"Cleaned up staging")
            except:
                pass
        elif not autoclean:
            logger.info(f"Preserving staging: {staging_folder}")
