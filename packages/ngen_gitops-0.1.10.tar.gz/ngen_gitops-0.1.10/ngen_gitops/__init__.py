"""ngen-gitops - GitOps CLI and web server for Bitbucket operations."""

__version__ = "0.1.10"
__author__ = "ngen-gitops contributors"
__description__ = "GitOps CLI and web server for Bitbucket operations"
