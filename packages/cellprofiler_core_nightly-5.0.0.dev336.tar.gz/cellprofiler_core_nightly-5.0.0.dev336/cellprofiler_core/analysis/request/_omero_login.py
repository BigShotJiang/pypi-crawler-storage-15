from ...utilities.zmq.communicable.request import AnalysisRequest


class OmeroLogin(AnalysisRequest):
    pass
