from ...utilities.zmq.communicable.request import AnalysisRequest


class Display(AnalysisRequest):
    pass
