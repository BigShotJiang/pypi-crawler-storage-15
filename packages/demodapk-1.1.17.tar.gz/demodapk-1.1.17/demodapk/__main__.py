"""
DemodAPK: __main__.py
"""

from demodapk.cli import main

if __name__ == "__main__":
    main()
