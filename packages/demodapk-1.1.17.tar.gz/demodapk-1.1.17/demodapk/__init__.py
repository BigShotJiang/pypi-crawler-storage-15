"""
DemodAPK is a Python tool for modifying and editing decoded APK files,
based on APKEditor. It works like an automatic script, running shell commands
and modifying resources according to JSON configuration settings.
"""

__version__ = "1.1.17"
