"""The dynamic (import-based) backend for autodoc."""
