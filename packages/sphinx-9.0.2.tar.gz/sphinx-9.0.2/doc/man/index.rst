Command-line tools
==================

These are the applications provided as part of Sphinx.

Core applications
-----------------

.. toctree::
   :maxdepth: 3

   sphinx-quickstart
   sphinx-build

Additional applications
-----------------------

.. toctree::
   :maxdepth: 3

   sphinx-apidoc
   sphinx-autogen
