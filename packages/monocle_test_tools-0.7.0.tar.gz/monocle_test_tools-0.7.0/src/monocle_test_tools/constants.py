TEST_SCOPE_NAME:str = "test_name"
GIT_RUN_ID_ATTRIBUTE: str = "git.run.id"
GIT_WORKFLOW_NAME_ATTRIBUTE: str = "git.workflow.name"
GIT_COMMIT_HASH_ATTRIBUTE: str = "git.commit.hash"