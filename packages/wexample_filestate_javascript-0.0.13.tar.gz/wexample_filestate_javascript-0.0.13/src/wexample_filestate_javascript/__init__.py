"""Wexample FileState JavaScript package."""

from __future__ import annotations

__version__ = "0.0.6"
