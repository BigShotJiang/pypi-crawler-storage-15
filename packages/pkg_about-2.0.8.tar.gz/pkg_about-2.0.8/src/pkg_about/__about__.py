# Copyright (c) 2020 Adam Karpierz
# SPDX-License-Identifier: Zlib

__import__("_about", globals=globals(), level=1).about()
