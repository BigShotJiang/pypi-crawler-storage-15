from ch5mpy.array.array import H5Array

__all__ = ["H5Array"]
