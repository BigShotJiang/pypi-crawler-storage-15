# 🤖 Jws - 智能语音助手系统

## 项目简介

Jws 是一个类似钢铁侠中贾维斯（JARVIS）的智能语音助手系统，运行在 macOS 上，具有以下核心功能：

- 🎤 **语音识别**：听懂你说的话
- 🧠 **智能理解**：理解你的意图和指令
- ⚡ **系统控制**：在系统上所有app内执行操作
- 🔐 **最高权限**：具有除你之外的最高系统权限
- 🎯 **指示级操作**：你说什么，它就能做到什么

## 核心特性

### 1. 语音交互
- 实时语音识别
- 自然语言理解
- 语音反馈（TTS）

### 2. 系统控制
- 应用启动和切换
- 文件操作
- 系统设置控制
- GUI自动化

### 3. 智能助手
- 上下文理解
- 多轮对话
- 任务规划
- 自动化执行

## 技术栈

- **Python 3.9+** - 主要开发语言
- **SpeechRecognition** - 语音识别
- **pyttsx3 / gTTS** - 语音合成
- **AppleScript** - macOS 系统控制
- **PyAutoGUI** - GUI自动化
- **OpenAI API** (可选) - 高级NLP理解
- **macOS Accessibility API** - 系统权限

## 项目结构

```
Jws/
├── src/                    # 源代码
│   ├── core/              # 核心功能
│   │   ├── voice_recognition.py    # 语音识别
│   │   ├── command_parser.py       # 指令解析
│   │   ├── system_controller.py    # 系统控制
│   │   └── app_controller.py       # 应用控制
│   ├── utils/             # 工具函数
│   │   ├── audio.py      # 音频处理
│   │   └── permissions.py # 权限管理
│   └── main.py           # 主程序入口
├── config/                # 配置文件
│   └── settings.json     # 系统配置
├── requirements.txt       # 依赖包
├── setup.py              # 安装脚本
└── README.md             # 项目说明
```

## 快速开始

### 安装依赖

```bash
pip install -r requirements.txt
```

### 运行

```bash
python src/main.py
```

## 权限配置

Jws 需要以下 macOS 权限：
- ✅ 辅助功能权限（控制其他应用）
- ✅ 屏幕录制权限（GUI自动化）
- ✅ 麦克风权限（语音识别）
- ✅ 完全磁盘访问权限（文件操作）

## 使用示例

```
你: "打开Safari浏览器"
Jws: "正在打开Safari..."

你: "帮我写一封邮件给张三，主题是项目进度"
Jws: "正在打开邮件应用，准备编写邮件..."

你: "切换到Chrome，打开GitHub"
Jws: "已切换到Chrome，正在打开GitHub..."
```

## 开发计划

- [x] 项目初始化
- [ ] 语音识别模块
- [ ] 指令解析模块
- [ ] 系统控制模块
- [ ] 应用控制模块
- [ ] 权限管理
- [ ] 用户界面
- [ ] 配置系统

## 注意事项

⚠️ **安全提示**：
- Jws 具有系统最高权限，请妥善保管
- 建议设置启动密码或生物识别验证
- 定期更新和检查系统安全

## 许可证

MIT License

