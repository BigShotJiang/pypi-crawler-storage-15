# taranis-base-bot

Base repo for all taranis-bots

Defines the blueprint for the bot API, with routes:

- /
- /modelinfo
- /health

Import in the child bots
