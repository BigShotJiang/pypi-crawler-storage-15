"""Version information for MCP Memory Service."""

__version__ = "8.47.0"
