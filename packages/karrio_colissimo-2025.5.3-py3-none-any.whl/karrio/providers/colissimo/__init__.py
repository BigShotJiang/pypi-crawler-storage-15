from karrio.providers.colissimo.utils import Settings
from karrio.providers.colissimo.shipment import (
    parse_shipment_response,
    shipment_request,
)
from karrio.providers.colissimo.tracking import (
    parse_tracking_response,
    tracking_request,
)
