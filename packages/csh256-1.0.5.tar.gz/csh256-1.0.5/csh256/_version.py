"""Version information for CSH-256"""

__version__ = "1.0.5"
__author__ = "Ibrahim Hilal Aboukila"
__license__ = "MIT"
__description__ = "CSH-256: A hybrid password hashing algorithm with time-cost resistance"