# ApplicationMonitoringConfig

The prometheus monitoring config

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**port** | **int, none_type** | The port to access for metrics. If unset uses the application&#39;s port. | [optional] 
**path** | **str** | The path to scrape prometheus metrics from | [optional]  if omitted the server will use the default value of "/metrics"
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


