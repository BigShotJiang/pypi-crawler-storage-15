"""Version information for TestDino CLI"""

VERSION = "1.0.22"
