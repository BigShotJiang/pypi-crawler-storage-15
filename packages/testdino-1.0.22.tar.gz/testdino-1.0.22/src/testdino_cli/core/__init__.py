"""Core functionality module"""

__all__ = []
