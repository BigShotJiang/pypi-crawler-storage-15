"""
Setup script for testdino package.
For modern Python packaging, most configuration is in pyproject.toml
"""

from setuptools import setup

# Configuration is in pyproject.toml
setup()
