"""Strands integration for Bedrock AgentCore Memory."""
