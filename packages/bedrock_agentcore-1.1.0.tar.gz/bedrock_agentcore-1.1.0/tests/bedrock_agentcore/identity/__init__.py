"""Tests for Bedrock AgentCore identity module."""
