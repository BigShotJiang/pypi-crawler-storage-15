from .odd_even import is_even, is_odd
