"""Checkpoint processors module."""
