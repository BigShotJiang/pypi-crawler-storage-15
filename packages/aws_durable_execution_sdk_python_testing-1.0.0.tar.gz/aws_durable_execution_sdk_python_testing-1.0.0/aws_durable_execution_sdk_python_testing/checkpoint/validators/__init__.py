"""Checkpoint validation module."""
