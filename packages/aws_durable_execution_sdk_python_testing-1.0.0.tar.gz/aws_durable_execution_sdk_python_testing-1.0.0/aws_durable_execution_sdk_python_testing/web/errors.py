"""Error handling utilities for AWS Lambda Durable Functions web service.

This module is deprecated and will be removed. All error handling now uses
AWS-compliant exception classes directly.
"""

# This file is kept temporarily for backward compatibility during migration.
# All functionality has been moved to direct AWS exception usage.
