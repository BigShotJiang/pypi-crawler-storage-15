"""Utility functions for MCP server."""
