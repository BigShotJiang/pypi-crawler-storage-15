"""OpenBB MCP Server Models."""
