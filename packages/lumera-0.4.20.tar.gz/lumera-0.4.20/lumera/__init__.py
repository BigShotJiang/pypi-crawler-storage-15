"""
Lumera Agent SDK

This SDK provides helpers for agents running within the Lumera Notebook environment
to interact with the Lumera API and define dynamic user interfaces.
"""

from ._utils import (
    LumeraAPIError,
    RecordNotUniqueError,
    get_access_token,
    get_google_access_token,
    log_timed,
)

# Import key SDK helpers to expose them at the package root.
from .sdk import (
    CollectionField,
    HookReplayResult,
    create_collection,
    create_record,
    delete_collection,
    delete_record,
    get_collection,
    get_record,
    get_record_by_external_id,
    list_collections,
    list_records,
    query_sql,
    replay_hook,
    save_to_lumera,
    update_collection,
    update_record,
    upload_lumera_file,
    upsert_record,
)

# Define what `from lumera import *` imports.
__all__ = [
    "get_access_token",
    "save_to_lumera",
    "get_google_access_token",  # Kept for backwards compatibility
    "log_timed",
    "list_collections",
    "get_collection",
    "create_collection",
    "update_collection",
    "delete_collection",
    "list_records",
    "get_record",
    "get_record_by_external_id",
    "replay_hook",
    "query_sql",
    "run_agent",
    "upload_lumera_file",
    "create_record",
    "update_record",
    "upsert_record",
    "delete_record",
    "CollectionField",
    "HookReplayResult",
    "LumeraAPIError",
    "RecordNotUniqueError",
]
