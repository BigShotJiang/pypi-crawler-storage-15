"""Work item management including specs, validation, and CRUD operations."""
