"""Core functionality for Solokit including file operations, logging, and configuration."""
