# Expose the loader module
from . import pyglet_ldtk_loader as pyglet_ldtk_loader
