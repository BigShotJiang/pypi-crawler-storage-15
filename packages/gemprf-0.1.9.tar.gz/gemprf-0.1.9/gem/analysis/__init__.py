class my_class(object):
    pass




