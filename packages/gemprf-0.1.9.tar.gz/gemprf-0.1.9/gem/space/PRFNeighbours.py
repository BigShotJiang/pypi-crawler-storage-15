class PRFNeighbours(object):
    """description of class"""


