# c o n s p i r e

[![stable](https://img.shields.io/badge/docs-stable-blue)](https://conspire.readthedocs.io/en/stable)
[![latest](https://img.shields.io/badge/docs-latest-blue)](https://conspire.readthedocs.io/en/latest)
[![license](https://img.shields.io/github/license/mrbuche/conspire.py?color=blue)](https://github.com/mrbuche/conspire.py?tab=GPL-3.0-1-ov-file#GPL-3.0-1-ov-file)
[![release](https://img.shields.io/pypi/v/conspire?color=blue&label=release)](https://pypi.org/project/conspire)

The Python interface to [conspire](https://mrbuche.github.io/conspire).
