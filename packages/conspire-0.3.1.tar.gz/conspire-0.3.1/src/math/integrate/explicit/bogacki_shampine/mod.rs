super::explicit!(BogackiShampine);
