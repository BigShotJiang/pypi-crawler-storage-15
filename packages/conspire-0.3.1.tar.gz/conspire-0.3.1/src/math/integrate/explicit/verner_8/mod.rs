super::explicit!(Verner8);
