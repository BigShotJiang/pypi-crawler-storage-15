super::hyperelastic!(Gent, bulk_modulus, shear_modulus, extensibility,);
