# Cupid algo

poetry build

poetry publish --build

poetry config pypi-token.pypi <your_pypi_token>
