from enum import IntEnum

class TrainingType(IntEnum):
  STAMINA = 1
  STRENGTH = 2
  CRITICALRATING = 3
  DODGERATING = 4
  NONE = 0
