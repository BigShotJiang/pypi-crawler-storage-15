API Reference
=============

Top-level package
-----------------

.. automodule:: singlejson
   :members:
   :undoc-members:
   :show-inheritance:


File utilities
--------------

.. automodule:: singlejson.fileutils
   :members:
   :undoc-members:
   :show-inheritance:


Pooling
-------

.. automodule:: singlejson.pool
   :members:
   :undoc-members:
   :show-inheritance:

