"""Harmonize the stream mixins into a single helper."""

from __future__ import annotations

from .base import AssetWebSocketBase
from .commands import CommandStreamMixin
from .geofeatures import GeofeatureStreamMixin
from .settings import SettingsStreamMixin
from .system import SystemStreamMixin
from .telemetry import TelemetryStreamMixin
from .tracks import TrackStreamMixin


class AssetWebSocketClient(
    SystemStreamMixin,
    TelemetryStreamMixin,
    CommandStreamMixin,
    SettingsStreamMixin,
    TrackStreamMixin,
    GeofeatureStreamMixin,
    AssetWebSocketBase,
):
    """High-level helper that speaks the asset websocket protocol."""


__all__ = ["AssetWebSocketClient"]
