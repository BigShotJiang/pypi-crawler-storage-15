"""Geofeature stream mixin stubs."""

from __future__ import annotations


class GeofeatureStreamMixin:
    """Placeholder for geofeature streaming helpers."""

    async def publish_geofeature(self, *args, **kwargs):  # pragma: no cover - stub
        raise NotImplementedError("Geofeature streaming is not available in this build")
