"""Settings stream mixin stubs."""

from __future__ import annotations


class SettingsStreamMixin:
    """Placeholder for settings synchronization helpers."""

    async def update_settings(self, *args, **kwargs):  # pragma: no cover - stub
        raise NotImplementedError("Settings streaming is not available in this build")
