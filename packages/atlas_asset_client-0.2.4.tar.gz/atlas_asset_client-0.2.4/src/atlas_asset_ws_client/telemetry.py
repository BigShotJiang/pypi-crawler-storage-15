"""Telemetry stream mixin stubs."""

from __future__ import annotations


class TelemetryStreamMixin:
    """Placeholder for telemetry streaming helpers."""

    async def publish_telemetry(self, *args, **kwargs):  # pragma: no cover - stub
        raise NotImplementedError("Telemetry streaming is not available in this build")
