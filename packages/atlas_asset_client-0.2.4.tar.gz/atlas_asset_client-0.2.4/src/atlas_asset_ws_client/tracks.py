"""Track stream mixin stubs."""

from __future__ import annotations


class TrackStreamMixin:
    """Placeholder for track streaming helpers."""

    async def publish_track(self, *args, **kwargs):  # pragma: no cover - stub
        raise NotImplementedError("Track streaming is not available in this build")
