"""
setupEM package
A Python tool for EM setup using gds2palace.
"""

from .setupEM import main

__all__ = ["main"]
__version__ = "0.1.0"