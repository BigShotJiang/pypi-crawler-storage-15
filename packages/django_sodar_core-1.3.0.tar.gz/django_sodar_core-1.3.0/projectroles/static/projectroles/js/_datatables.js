/* Common helpers for DataTables */

let sodarDataTablesPaginate = {
  first: '&laquo; First',
  previous: '&lsaquo; Prev',
  next: 'Next &rsaquo;',
  last: 'Last &raquo;',
}
