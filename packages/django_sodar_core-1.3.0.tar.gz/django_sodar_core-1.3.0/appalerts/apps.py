from django.apps import AppConfig


class AppalertsConfig(AppConfig):
    name = 'appalerts'
