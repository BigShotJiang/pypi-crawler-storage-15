from django.apps import AppConfig


class SiteinfoConfig(AppConfig):
    name = 'siteinfo'
