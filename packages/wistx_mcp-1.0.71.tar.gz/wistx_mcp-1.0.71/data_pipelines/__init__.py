"""Data pipelines module."""

