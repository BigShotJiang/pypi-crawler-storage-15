# vytools: Tools for distributed continuous integration 

## Installation

```bash
pip install vytools
```
or often
```bash
pip3 install vytools
```
