# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ShowStackSetTemplateRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'client_request_id': 'str',
        'stack_set_name': 'str',
        'stack_set_id': 'str',
        'access_control_source_ips': 'list[str]',
        'access_control_source_vpc_ids': 'list[str]',
        'call_identity': 'str'
    }

    attribute_map = {
        'client_request_id': 'Client-Request-Id',
        'stack_set_name': 'stack_set_name',
        'stack_set_id': 'stack_set_id',
        'access_control_source_ips': 'access_control_source_ips',
        'access_control_source_vpc_ids': 'access_control_source_vpc_ids',
        'call_identity': 'call_identity'
    }

    def __init__(self, client_request_id=None, stack_set_name=None, stack_set_id=None, access_control_source_ips=None, access_control_source_vpc_ids=None, call_identity=None):
        r"""ShowStackSetTemplateRequest

        The model defined in huaweicloud sdk

        :param client_request_id: 用户指定的，对于此请求的唯一ID，用于定位某个请求，推荐使用UUID
        :type client_request_id: str
        :param stack_set_name: 资源栈集的名称。此名字在domain_id+region下应唯一，可以使用中文、大小写英文、数字、下划线、中划线。首字符需为中文或者英文，区分大小写。
        :type stack_set_name: str
        :param stack_set_id: 资源栈集（stack_set）的唯一ID。  此ID由资源编排服务在生成资源栈集的时候生成，为UUID。  由于资源栈集名称仅仅在同一时间下唯一，即用户允许先生成一个叫HelloWorld的资源栈集，删除，再重新创建一个同名资源栈集。  对于团队并行开发，用户可能希望确保，当前我操作的资源栈集就是我认为的那个，而不是其他队友删除后创建的同名资源栈集。因此，使用ID就可以做到强匹配。  资源编排服务保证每次创建的资源栈集所对应的ID都不相同，更新不会影响ID。如果给予的stack_set_id和当前资源栈集的ID不一致，则返回400
        :type stack_set_id: str
        :param access_control_source_ips: 允许访问资源栈集模板的source ip列表，source ip应是具有CIDR表示法且带有子网掩码的IPv4地址。
        :type access_control_source_ips: list[str]
        :param access_control_source_vpc_ids: 允许访问资源栈集模板的source vpc id列表， source vpc id应仅包含小写字母、数字或中划线。
        :type access_control_source_vpc_ids: list[str]
        :param call_identity: 仅支持资源栈集权限模式为SERVICE_MANAGED时指定该参数。用于指定用户是以组织管理账号还是成员账号中的服务委托管理员身份调用资源栈集。默认为SELF。  无论指定何种用户身份，创建或部署的资源栈集始终在组织管理账号名下。   * &#x60;SELF&#x60; - 以组织管理账号身份调用。   * &#x60;DELEGATED_ADMIN&#x60; - 以服务委托管理员身份调用。用户的华为云账号必须在组织中已经被注册为”资源编排资源栈集服务“的委托管理员。
        :type call_identity: str
        """
        
        

        self._client_request_id = None
        self._stack_set_name = None
        self._stack_set_id = None
        self._access_control_source_ips = None
        self._access_control_source_vpc_ids = None
        self._call_identity = None
        self.discriminator = None

        self.client_request_id = client_request_id
        self.stack_set_name = stack_set_name
        if stack_set_id is not None:
            self.stack_set_id = stack_set_id
        if access_control_source_ips is not None:
            self.access_control_source_ips = access_control_source_ips
        if access_control_source_vpc_ids is not None:
            self.access_control_source_vpc_ids = access_control_source_vpc_ids
        if call_identity is not None:
            self.call_identity = call_identity

    @property
    def client_request_id(self):
        r"""Gets the client_request_id of this ShowStackSetTemplateRequest.

        用户指定的，对于此请求的唯一ID，用于定位某个请求，推荐使用UUID

        :return: The client_request_id of this ShowStackSetTemplateRequest.
        :rtype: str
        """
        return self._client_request_id

    @client_request_id.setter
    def client_request_id(self, client_request_id):
        r"""Sets the client_request_id of this ShowStackSetTemplateRequest.

        用户指定的，对于此请求的唯一ID，用于定位某个请求，推荐使用UUID

        :param client_request_id: The client_request_id of this ShowStackSetTemplateRequest.
        :type client_request_id: str
        """
        self._client_request_id = client_request_id

    @property
    def stack_set_name(self):
        r"""Gets the stack_set_name of this ShowStackSetTemplateRequest.

        资源栈集的名称。此名字在domain_id+region下应唯一，可以使用中文、大小写英文、数字、下划线、中划线。首字符需为中文或者英文，区分大小写。

        :return: The stack_set_name of this ShowStackSetTemplateRequest.
        :rtype: str
        """
        return self._stack_set_name

    @stack_set_name.setter
    def stack_set_name(self, stack_set_name):
        r"""Sets the stack_set_name of this ShowStackSetTemplateRequest.

        资源栈集的名称。此名字在domain_id+region下应唯一，可以使用中文、大小写英文、数字、下划线、中划线。首字符需为中文或者英文，区分大小写。

        :param stack_set_name: The stack_set_name of this ShowStackSetTemplateRequest.
        :type stack_set_name: str
        """
        self._stack_set_name = stack_set_name

    @property
    def stack_set_id(self):
        r"""Gets the stack_set_id of this ShowStackSetTemplateRequest.

        资源栈集（stack_set）的唯一ID。  此ID由资源编排服务在生成资源栈集的时候生成，为UUID。  由于资源栈集名称仅仅在同一时间下唯一，即用户允许先生成一个叫HelloWorld的资源栈集，删除，再重新创建一个同名资源栈集。  对于团队并行开发，用户可能希望确保，当前我操作的资源栈集就是我认为的那个，而不是其他队友删除后创建的同名资源栈集。因此，使用ID就可以做到强匹配。  资源编排服务保证每次创建的资源栈集所对应的ID都不相同，更新不会影响ID。如果给予的stack_set_id和当前资源栈集的ID不一致，则返回400

        :return: The stack_set_id of this ShowStackSetTemplateRequest.
        :rtype: str
        """
        return self._stack_set_id

    @stack_set_id.setter
    def stack_set_id(self, stack_set_id):
        r"""Sets the stack_set_id of this ShowStackSetTemplateRequest.

        资源栈集（stack_set）的唯一ID。  此ID由资源编排服务在生成资源栈集的时候生成，为UUID。  由于资源栈集名称仅仅在同一时间下唯一，即用户允许先生成一个叫HelloWorld的资源栈集，删除，再重新创建一个同名资源栈集。  对于团队并行开发，用户可能希望确保，当前我操作的资源栈集就是我认为的那个，而不是其他队友删除后创建的同名资源栈集。因此，使用ID就可以做到强匹配。  资源编排服务保证每次创建的资源栈集所对应的ID都不相同，更新不会影响ID。如果给予的stack_set_id和当前资源栈集的ID不一致，则返回400

        :param stack_set_id: The stack_set_id of this ShowStackSetTemplateRequest.
        :type stack_set_id: str
        """
        self._stack_set_id = stack_set_id

    @property
    def access_control_source_ips(self):
        r"""Gets the access_control_source_ips of this ShowStackSetTemplateRequest.

        允许访问资源栈集模板的source ip列表，source ip应是具有CIDR表示法且带有子网掩码的IPv4地址。

        :return: The access_control_source_ips of this ShowStackSetTemplateRequest.
        :rtype: list[str]
        """
        return self._access_control_source_ips

    @access_control_source_ips.setter
    def access_control_source_ips(self, access_control_source_ips):
        r"""Sets the access_control_source_ips of this ShowStackSetTemplateRequest.

        允许访问资源栈集模板的source ip列表，source ip应是具有CIDR表示法且带有子网掩码的IPv4地址。

        :param access_control_source_ips: The access_control_source_ips of this ShowStackSetTemplateRequest.
        :type access_control_source_ips: list[str]
        """
        self._access_control_source_ips = access_control_source_ips

    @property
    def access_control_source_vpc_ids(self):
        r"""Gets the access_control_source_vpc_ids of this ShowStackSetTemplateRequest.

        允许访问资源栈集模板的source vpc id列表， source vpc id应仅包含小写字母、数字或中划线。

        :return: The access_control_source_vpc_ids of this ShowStackSetTemplateRequest.
        :rtype: list[str]
        """
        return self._access_control_source_vpc_ids

    @access_control_source_vpc_ids.setter
    def access_control_source_vpc_ids(self, access_control_source_vpc_ids):
        r"""Sets the access_control_source_vpc_ids of this ShowStackSetTemplateRequest.

        允许访问资源栈集模板的source vpc id列表， source vpc id应仅包含小写字母、数字或中划线。

        :param access_control_source_vpc_ids: The access_control_source_vpc_ids of this ShowStackSetTemplateRequest.
        :type access_control_source_vpc_ids: list[str]
        """
        self._access_control_source_vpc_ids = access_control_source_vpc_ids

    @property
    def call_identity(self):
        r"""Gets the call_identity of this ShowStackSetTemplateRequest.

        仅支持资源栈集权限模式为SERVICE_MANAGED时指定该参数。用于指定用户是以组织管理账号还是成员账号中的服务委托管理员身份调用资源栈集。默认为SELF。  无论指定何种用户身份，创建或部署的资源栈集始终在组织管理账号名下。   * `SELF` - 以组织管理账号身份调用。   * `DELEGATED_ADMIN` - 以服务委托管理员身份调用。用户的华为云账号必须在组织中已经被注册为”资源编排资源栈集服务“的委托管理员。

        :return: The call_identity of this ShowStackSetTemplateRequest.
        :rtype: str
        """
        return self._call_identity

    @call_identity.setter
    def call_identity(self, call_identity):
        r"""Sets the call_identity of this ShowStackSetTemplateRequest.

        仅支持资源栈集权限模式为SERVICE_MANAGED时指定该参数。用于指定用户是以组织管理账号还是成员账号中的服务委托管理员身份调用资源栈集。默认为SELF。  无论指定何种用户身份，创建或部署的资源栈集始终在组织管理账号名下。   * `SELF` - 以组织管理账号身份调用。   * `DELEGATED_ADMIN` - 以服务委托管理员身份调用。用户的华为云账号必须在组织中已经被注册为”资源编排资源栈集服务“的委托管理员。

        :param call_identity: The call_identity of this ShowStackSetTemplateRequest.
        :type call_identity: str
        """
        self._call_identity = call_identity

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ShowStackSetTemplateRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
