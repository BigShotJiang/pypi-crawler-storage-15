.. include:: ../../README.rst
   :end-before: .. substitutions

.. toctree::
   :hidden:

   Home <self>
   api
   cpp

.. |banner| image:: /_images/libSonataLogo.jpg
