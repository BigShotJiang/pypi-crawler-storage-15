"""Core functionality for MCP Vector Search."""
