# sage_setup: distribution = sagemath-lrslib
# delvewheel: patch

from sage.all__sagemath_polyhedra import *
