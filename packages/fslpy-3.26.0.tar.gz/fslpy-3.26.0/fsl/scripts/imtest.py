#!/usr/bin/env python
#
# imtest.py - Test whether an image file exists or not.
#
# Author: Paul McCarthy <pauldmccarthy@gmail.com>
#
"""The ``imtest`` script can be used to test whether an image file exists or
not, without having to know the file suffix (.nii, .nii.gz, etc).
"""


import os.path        as op
import                   sys
import fsl.utils.path as fslpath


# The lists below are defined in the
# fsl.data.image class, but are duplicated
# here for performance (to avoid import of
# nibabel/numpy/etc).
exts = ['.nii.gz',  '.nii',
        '.nii.zst', '.nii.bz2',
        '.img',     '.hdr',
        '.img.gz',  '.hdr.gz',
        '.img.zst', '.hdr.zst',
        '.img.bz2', '.hdr.bz2',
        '.mnc',     '.mnc.gz']
"""List of file extensions that are supported by ``imtest``.
"""

groups = [('.hdr',     '.img'),
          ('.hdr.gz',  '.img.gz'),
          ('.hdr.zst', '.img.zst'),
          ('.hdr.bz2', '.img.bz2')]
"""List of known image file groups (image/header file pairs). """


def imtest(path):
    """Returns ``True`` if the given image path exists, False otherwise. """

    path = fslpath.removeExt(path, exts)
    path = op.realpath(path)

    # getFileGroup will raise an error
    # if the image (including all
    # components - i.e. header and
    # image) does not exist
    try:
        fslpath.getFileGroup(path,
                             allowedExts=exts,
                             fileGroups=groups,
                             unambiguous=True)
        return True

    except fslpath.PathError:
        return False


def main(argv=None):
    """Test if an image path exists, and prints ``'1'`` if it does or ``'0'``
    if it doesn't.
    """

    if argv is None:
        argv = sys.argv[1:]

    # emulate old fslio/imtest - always return 0
    if len(argv) != 1:
        print('0')
        return 0

    if imtest(argv[0]):
        print('1')
    else:
        print('0')

    return 0


if __name__ == '__main__':
    sys.exit(main())
