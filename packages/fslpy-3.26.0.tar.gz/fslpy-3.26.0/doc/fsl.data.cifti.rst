``fsl.data.cifti``
==================

.. automodule:: fsl.data.cifti
    :members:
    :undoc-members:
    :show-inheritance:
