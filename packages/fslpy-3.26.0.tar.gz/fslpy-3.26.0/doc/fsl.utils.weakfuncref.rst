``fsl.utils.weakfuncref``
=========================

.. automodule:: fsl.utils.weakfuncref
    :members:
    :undoc-members:
    :show-inheritance:
