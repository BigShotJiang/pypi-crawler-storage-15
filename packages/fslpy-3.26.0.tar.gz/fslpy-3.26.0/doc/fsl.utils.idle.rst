``fsl.utils.idle``
==================

.. automodule:: fsl.utils.idle
    :members:
    :undoc-members:
    :show-inheritance:
