``fsl.data.melodicanalysis``
============================

.. automodule:: fsl.data.melodicanalysis
    :members:
    :undoc-members:
    :show-inheritance:
