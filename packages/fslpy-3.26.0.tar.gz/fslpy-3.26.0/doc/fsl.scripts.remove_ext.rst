``fsl.scripts.remove_ext``
==========================

.. automodule:: fsl.scripts.remove_ext
    :members:
    :undoc-members:
    :show-inheritance:
