``fsl.wrappers.eddy``
=====================

.. automodule:: fsl.wrappers.eddy
    :members:
    :undoc-members:
    :show-inheritance:
