``fsl.wrappers.first``
======================

.. automodule:: fsl.wrappers.first
    :members:
    :undoc-members:
    :show-inheritance:
