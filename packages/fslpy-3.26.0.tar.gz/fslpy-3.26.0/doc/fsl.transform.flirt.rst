``fsl.transform.flirt``
=======================

.. automodule:: fsl.transform.flirt
    :members:
    :undoc-members:
    :show-inheritance:
