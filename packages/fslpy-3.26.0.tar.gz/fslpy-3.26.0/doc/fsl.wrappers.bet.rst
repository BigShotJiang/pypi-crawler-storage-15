``fsl.wrappers.bet``
====================

.. automodule:: fsl.wrappers.bet
    :members:
    :undoc-members:
    :show-inheritance:
