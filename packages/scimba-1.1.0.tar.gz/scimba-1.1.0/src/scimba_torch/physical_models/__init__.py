"""Defines physical models."""
