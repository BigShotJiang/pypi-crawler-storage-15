"""Defines numerical solvers."""
