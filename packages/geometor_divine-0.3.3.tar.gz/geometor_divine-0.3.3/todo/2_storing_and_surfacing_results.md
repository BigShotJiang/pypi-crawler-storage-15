# 2. Storing and Surfacing Results

-   The analysis results (e.g., a list of golden sections, harmonic ranges) need to be stored in a structured way, likely associated with the `model` instance.
-   The results should be easily serializable so they can be sent to the `explorer` frontend via the API.
