"""The package entry point into the application."""

# insert demo code
