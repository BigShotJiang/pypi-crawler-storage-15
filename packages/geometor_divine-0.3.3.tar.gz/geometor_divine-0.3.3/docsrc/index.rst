GEOMETOR • divine
=================

An analysis engine for identifying golden sections and harmonic ranges.

.. include:: overview/intro.rst





indices
-------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
