
:navigation: footer
:order: 1

.. _about:


About GEOMETOR
==============


