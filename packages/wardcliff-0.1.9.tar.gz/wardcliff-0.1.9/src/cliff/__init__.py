"""Cliff - Multi-agent prediction market trading simulation."""

__version__ = "0.1.0"
