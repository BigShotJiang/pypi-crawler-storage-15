"""DataFrame adapters for Arc client."""
