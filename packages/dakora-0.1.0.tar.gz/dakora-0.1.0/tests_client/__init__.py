"""Tests for dakora SDK"""
