# grz-pydantic-models

Pydantic models of the BfArM GRZ metadata schema.