# Python 包打包与发布指南

本指南将指导您如何构建 `openlist-sdk` 并将其上传到 PyPI (Python Package Index)，以便其他用户可以通过 `pip install oplist-sdk` 安装。

## 1. 准备工作

### 1.1 注册 PyPI 账号
如果您还没有账号，请先注册：
- **PyPI (正式环境)**: [https://pypi.org/account/register/](https://pypi.org/account/register/)
- **TestPyPI (测试环境)**: [https://test.pypi.org/account/register/](https://test.pypi.org/account/register/)

> 建议先尝试上传到 TestPyPI 进行验证，确保一切正常后再发布到正式环境。

### 1.2 获取 API Token
在 PyPI 账号设置中，找到 "API tokens" 部分，创建一个新的 Token。
- 权限范围：选择 "Entire account" (对于新项目)。
- 保存好这个 Token (通常以 `pypi-` 开头)，后续上传时会用到。

### 1.3 安装构建工具
确保本地环境安装了必要的构建和上传工具：

```bash
# 安装构建和发布工具
pip install build twine
```

---

## 2. 构建项目

在项目根目录下运行以下命令，生成分发包：

```bash
python -m build
```

**构建成功后**：
您会看到一个 `dist/` 目录，里面包含两个文件：
- `openlist_sdk-0.4.0-py3-none-any.whl` (Wheel 包)
- `openlist_sdk-0.4.0.tar.gz` (源码包)

---

## 3. 上传发布

### 选项 A: 发布到 TestPyPI (推荐先做这一步)

```bash
python -m twine upload --repository testpypi dist/*
```

- **Username**: `__token__`
- **Password**: 您的 TestPyPI API Token (`pypi-...`)

**验证安装**：
上传成功后，尝试在一个新的虚拟环境中安装：
```bash
pip install -i https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ oplist-sdk
```

### 选项 B: 发布到 PyPI (正式发布)

```bash
python -m twine upload dist/*
```

- **Username**: `__token__`
- **Password**: 您的 PyPI API Token (`pypi-...`)

**验证安装**：
```bash
pip install oplist-sdk
```

---

## 4. 常见问题

### 版本冲突
如果您需要发布新版本，必须修改 `pyproject.toml` 中的 `version` 字段 (例如从 `0.4.0` 改为 `0.4.1`)，然后重新构建上传。PyPI 不允许覆盖已存在的版本。

### 文件遗漏
如果发现安装后缺少文件 (如 `README.md`)，请检查 `MANIFEST.in` 文件是否正确包含了这些文件。

### 依赖问题
依赖项在 `pyproject.toml` 的 `dependencies` 字段中定义。用户安装您的包时，pip 会自动安装这些依赖。

---

## 5. 项目配置备忘

- **项目名称**: `oplist-sdk` (在 `pyproject.toml` 中修改)
- **版本号**: `0.4.0`
- **作者信息**: 需要在 `pyproject.toml` 中更新您的名字和邮箱。
