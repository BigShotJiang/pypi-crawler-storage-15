2025-08-01 Version: 1.0.9
- Update API SendMessageToGlobe: add request parameters Type.


2024-12-10 Version: 1.0.8
- Update API SmsConversion: add param To.
- Update API SmsConversion: update param MessageId.


2024-10-17 Version: 1.0.7
- Update API BatchSendMessageToGlobe: add param ChannelId.


2024-08-01 Version: 1.0.6
- Update API SendMessageToGlobe: add param ChannelId.
- Update API SendMessageWithTemplate: add param ChannelId.


2024-03-11 Version: 1.0.5
- Generated python 2018-05-01 for Dysmsapi.

2023-06-27 Version: 1.0.4
- Fix empty RequestId return for QueryMessage and SendMessageWithTemplate.

2021-12-27 Version: 1.0.3
- Fix empty RequestId return for QueryMessage and SendMessageWithTemplate.

2021-09-18 Version: 1.0.2
- Fix auto code generation problem.

2021-09-18 Version: 1.0.1
- Fix auto code generation problem.

2021-09-18 Version: 1.0.0
- Init version of International SMS Service latest OpenAPI SDK.

