"""Tests for documentation generation."""
