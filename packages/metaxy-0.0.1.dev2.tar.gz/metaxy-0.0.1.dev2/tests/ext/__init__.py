"""Tests for metaxy.ext modules."""
