# LanceDB Metadata Store API

::: metaxy.metadata_store.lancedb
    options:
      members: false

<!-- dprint-ignore-start -->
::: metaxy.metadata_store.lancedb.LanceDBMetadataStore
    options:
      inherited_members: false
<!-- dprint-ignore-end -->
