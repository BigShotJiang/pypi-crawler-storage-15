# Ibis Metadata Store API

::: metaxy.metadata_store.ibis
    options:
      members: false

<!-- dprint-ignore-start -->
::: metaxy.metadata_store.ibis.IbisMetadataStore
    options:
      inherited_members: false
<!-- dprint-ignore-end -->
