# DuckDB Metadata Store API

::: metaxy.metadata_store.duckdb
    options:
      members: false

<!-- dprint-ignore-start -->
::: metaxy.metadata_store.duckdb.DuckDBMetadataStore
    options:
      inherited_members: false
<!-- dprint-ignore-end -->

::: metaxy.metadata_store.duckdb.ExtensionSpec

::: metaxy.metadata_store.duckdb.DuckLakeConfigInput

::: metaxy.metadata_store._ducklake_support.DuckLakeAttachmentConfig
