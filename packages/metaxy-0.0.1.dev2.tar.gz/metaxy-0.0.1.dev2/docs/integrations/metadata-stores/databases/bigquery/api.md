# BigQuery Metadata Store API

::: metaxy.metadata_store.bigquery
    options:
      members: false

<!-- dprint-ignore-start -->
::: metaxy.metadata_store.bigquery.BigQueryMetadataStore
    options:
      inherited_members: false
<!-- dprint-ignore-end -->
