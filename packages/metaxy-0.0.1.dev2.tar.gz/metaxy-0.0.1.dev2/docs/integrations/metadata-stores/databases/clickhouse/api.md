# ClickHouse Metadata Store API

::: metaxy.metadata_store.clickhouse
    options:
      members: false

<!-- dprint-ignore-start -->
::: metaxy.metadata_store.clickhouse.ClickHouseMetadataStore
    options:
      inherited_members: false
<!-- dprint-ignore-end -->
