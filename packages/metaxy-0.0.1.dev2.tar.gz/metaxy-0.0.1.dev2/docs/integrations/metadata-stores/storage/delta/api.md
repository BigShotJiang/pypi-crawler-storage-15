# Delta Lake Metadata Store API

::: metaxy.metadata_store.delta
    options:
      members: false

<!-- dprint-ignore-start -->
::: metaxy.metadata_store.delta.DeltaMetadataStore
    options:
      inherited_members: false
<!-- dprint-ignore-end -->
