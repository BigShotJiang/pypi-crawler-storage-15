# Delta Lake Configuration

<!-- dprint-ignore-start -->
::: metaxy-config
    class: metaxy.metadata_store.delta.DeltaMetadataStoreConfig
    path_prefix: stores.dev.config
    header_level: 2
<!-- dprint-ignore-end -->
