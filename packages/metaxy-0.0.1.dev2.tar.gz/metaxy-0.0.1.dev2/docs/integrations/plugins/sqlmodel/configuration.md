# SQLModel Configuration

<!-- dprint-ignore-start -->
::: metaxy-config
    class: metaxy.ext.sqlmodel.SQLModelPluginConfig
    path_prefix: ext.sqlmodel
    header_level: 2
<!-- dprint-ignore-end -->
