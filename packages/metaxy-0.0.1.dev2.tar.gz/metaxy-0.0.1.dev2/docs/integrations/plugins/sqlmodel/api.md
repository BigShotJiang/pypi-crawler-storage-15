# SQLModel API Reference

<!-- dprint-ignore-start -->
::: metaxy.ext.sqlmodel
    members: true
<!-- dprint-ignore-end -->
