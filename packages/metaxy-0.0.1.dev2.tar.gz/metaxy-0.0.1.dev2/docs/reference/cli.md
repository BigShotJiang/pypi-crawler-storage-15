# CLI Commands

This section provides a comprehensive reference for all Metaxy CLI commands.

!!! warning

    Some CLI commands are experimental (read: half-baked)

::: cyclopts
    module: metaxy.cli.app:app
    heading-level: 3
    recursive: true
    flatten-commands: false
    generate-toc: true
