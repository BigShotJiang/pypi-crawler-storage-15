# In-Memory Metadata Store

This one is mostly useful for testing.

## Configuration

::: metaxy-config
    class: metaxy.metadata_store.memory.InMemoryMetadataStoreConfig
    path_prefix: stores.dev.config
    header_level: 3

## API Reference

::: metaxy.InMemoryMetadataStore
    options:
      inherited_members: false
