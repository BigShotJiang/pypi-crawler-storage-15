# Metadata Store Exceptions

::: metaxy.metadata_store.exceptions
    members: true
