"""MkDocs plugin for displaying Metaxy configuration documentation."""

from __future__ import annotations

__all__: list[str] = []
