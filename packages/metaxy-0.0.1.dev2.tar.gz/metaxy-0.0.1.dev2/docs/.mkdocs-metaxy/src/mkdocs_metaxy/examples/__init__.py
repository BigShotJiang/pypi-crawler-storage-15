"""MkDocs plugin for displaying Metaxy example content."""

from __future__ import annotations

from mkdocs_metaxy.examples.plugin import MetaxyExamplesPlugin

__all__ = ["MetaxyExamplesPlugin"]
