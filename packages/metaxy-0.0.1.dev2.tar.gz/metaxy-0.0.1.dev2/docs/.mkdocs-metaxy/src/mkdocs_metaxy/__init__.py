"""MkDocs extensions and plugins for Metaxy documentation."""

from __future__ import annotations

__all__: list[str] = []
