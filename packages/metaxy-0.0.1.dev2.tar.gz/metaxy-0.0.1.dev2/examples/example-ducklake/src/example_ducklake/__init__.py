"""DuckLake example package.

The demo illustrates how to configure the typed DuckLake metadata store without
requiring access to a real DuckLake installation. See `demo.py` for details.
"""
