# Metaxy Examples

Each subdirectory is a fully functional Python project, as well as a Metaxy project (defines `metaxy.toml`).
Refer to each example's README.md for instructions on how to run it.
