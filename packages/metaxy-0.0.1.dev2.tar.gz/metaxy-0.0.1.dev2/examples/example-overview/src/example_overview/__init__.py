"""Overview example demonstrating video processing pipeline."""
