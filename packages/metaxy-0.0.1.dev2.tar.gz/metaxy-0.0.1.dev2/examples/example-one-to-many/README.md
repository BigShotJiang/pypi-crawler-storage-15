# One To Many

View the docs for this example [here](https://anam-org.github.io/metaxy/main/examples/one-to-many/).
