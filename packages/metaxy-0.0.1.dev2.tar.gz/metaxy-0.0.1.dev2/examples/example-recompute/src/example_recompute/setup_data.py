"""Setup data for recompute example.

For the recompute example, the parent computation creates the initial data,
so this script is a no-op placeholder.
"""

print("✓ Recompute example doesn't require separate data setup")
print("  Data will be created when running compute_parent.py")
