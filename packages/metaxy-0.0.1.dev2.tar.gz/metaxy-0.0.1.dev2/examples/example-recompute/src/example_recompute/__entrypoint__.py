"""Entrypoint for recompute example.

This module imports and registers the feature definitions.
"""

# Import features to register them with the active graph
from example_recompute import features  # noqa: F401
