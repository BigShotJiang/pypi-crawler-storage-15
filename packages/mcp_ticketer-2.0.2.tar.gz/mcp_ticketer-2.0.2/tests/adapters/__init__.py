"""Tests for adapter implementations."""
