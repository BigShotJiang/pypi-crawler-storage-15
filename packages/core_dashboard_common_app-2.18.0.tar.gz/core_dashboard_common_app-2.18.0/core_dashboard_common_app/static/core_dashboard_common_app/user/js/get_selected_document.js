/**
 * Get list of document selected
 * @returns {Array}
 */
getSelectedDocument = function () {
    return [$('.'+functional_object+'-id').val()];
};