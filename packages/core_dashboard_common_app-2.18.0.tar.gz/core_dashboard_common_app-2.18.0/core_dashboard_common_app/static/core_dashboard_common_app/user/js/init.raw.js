var functional_object = "{{data.document}}";
var menu = '{{data.menu}}' == "True";
