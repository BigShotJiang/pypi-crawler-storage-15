var openXMLFormUrl = "{% url 'core_curate_app_xml_text_editor_view' %}";
var openJSONFormUrl = "{% url 'core_curate_app_json_text_editor_view' %}";