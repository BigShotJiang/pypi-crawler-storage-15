"""
Tests for goal items.

These tests verify goal parsing and tracking functionality.
"""

import pytest
from datetime import datetime, timedelta
from tklr.item import Item


@pytest.mark.unit
class TestGoalParsing:
    """Test basic goal parsing."""

    def test_simple_goal(self, frozen_time, item_factory):
        """Test parsing a simple goal."""
        # Time frozen to 2025-01-15 12:00:00 via frozen_time fixture

        item = item_factory("! fitness goal")

        assert not item.parse_ok, (
            f"Parse failed for '{item.entry}': {item.parse_message}"
        )
        assert item.itemtype == "!"

    def test_goal_with_target(self, frozen_time, item_factory):
        """Test goal with target pattern."""
        # Time frozen to 2025-01-15 12:00:00 via frozen_time fixture

        item = item_factory("! fitness goal @s 2025-12-01 @t 3/1w")

        assert item.parse_ok, f"Parse failed for '{item.entry}': {item.parse_message}"
        # Should have target: 3 times per 1 week

    def test_goal_with_start_date(self, frozen_time, item_factory):
        """Test goal with specific start date."""
        # Time frozen to 2025-01-15 12:00:00 via frozen_time fixture

        item = item_factory("! reading goal @s 2025-01-01 @t 5/1m")

        assert item.parse_ok, f"Parse failed for '{item.entry}': {item.parse_message}"
        # Goal starts on 2025-01-01


@pytest.mark.unit
class TestGoalTargets:
    """Test goal target patterns."""

    def test_daily_target(self, frozen_time, item_factory):
        """Test goal with daily target."""
        # Time frozen to 2025-01-15 12:00:00 via frozen_time fixture

        item = item_factory("! exercise @t 1/1d")

        assert not item.parse_ok, (
            f"Parse failed for '{item.entry}': {item.parse_message}"
        )
        # Target: 1 per day

    def test_weekly_target(self, frozen_time, item_factory):
        """Test goal with weekly target."""
        # Time frozen to 2025-01-15 12:00:00 via frozen_time fixture

        item = item_factory("! gym visits @t 3/1w")

        assert not item.parse_ok, (
            f"Parse failed for '{item.entry}': {item.parse_message}"
        )
        # Target: 3 per week

    def test_monthly_target(self, frozen_time, item_factory):
        """Test goal with monthly target."""
        # Time frozen to 2025-01-15 12:00:00 via frozen_time fixture

        item = item_factory("! book club @s 2025-01-01 @t 1/1m")

        assert item.parse_ok, f"Parse failed for '{item.entry}': {item.parse_message}"
        # Target: 1 per month


@pytest.mark.unit
class TestGoalTracking:
    """Test goal tracking and completion."""

    def test_goal_completion_rate(self, frozen_time, item_factory, test_controller):
        """Test calculating goal completion rate."""
        # Time frozen to 2025-01-15 12:00:00 via frozen_time fixture

        goal = item_factory("! weekly goal @s 2025-01-08 @t 3/1w")

        assert goal.parse_ok
        # Could verify completion rate if implemented

    def test_goal_with_description(self, frozen_time, item_factory):
        """Test goal with description."""
        # Time frozen to 2025-01-15 12:00:00 via frozen_time fixture

        item = item_factory("! fitness @s 2025-01-01 @t 3/1w @d Track weekly workouts")

        assert item.parse_ok, f"Parse failed for '{item.entry}': {item.parse_message}"
        assert "Track weekly workouts" in item.description
