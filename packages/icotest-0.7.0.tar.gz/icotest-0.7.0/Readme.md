[documentation]: https://icotest.readthedocs.io

[![API Documentation](https://img.shields.io/readthedocs/icotest?label=Documentation)][documentation]

# ICOtest

Please take a look at the [online documentation][documentation].
