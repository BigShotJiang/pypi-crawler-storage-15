====================================
Contributors (alphabetic on surname)
====================================

DetectionOrientationCulture
===========================

* Thomas Duthoit - <thomas.duthoit@thalesgroup.com> - Thales Service Numerique
* Pauline Guntzburger - <pauline.guntzburger@thalesgroup.com> - Thales Service Numerique
* Vincent Lonjou - <vincent.lonjou@cnes.fr> - CNES


NightOsmRegistration
====================

* Erwin Bergsma <erwin.bergsma@cnes.fr> - CNES
* Vincent Delbar <vincent.delbar@latelescop.fr> - LaTeleScop
* Yannick Lasne <yannick.lasne@thalesgroup.com> - Thales Service Numerique
* Solange Lemai-Chenevier <Solange.Lemai-chenevier@cnes.fr> - CNES
* Quentin Leturgie <quentin.leturgie@thalesgroup.com> - Thales Service Numerique
* Camille Lhenry <camille.lhenry@latelescop.fr> - LaTeleScop

SunMapGeneration
================

* Thomas Duthoit - <thomas.duthoit@thalesgroup.com> - Thales Service Numerique
* Solange Lemai-Chenevier - <solange.lemai-chenevier@cnes.fr> - CNES

