"""Configuration files for HydrationSitePrediction (used via Hydra)."""
