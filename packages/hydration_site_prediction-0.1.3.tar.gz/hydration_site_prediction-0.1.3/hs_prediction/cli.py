"""
Simple command-line wrappers around the original training and inference scripts.

These functions just call the existing modules as if you had run:
    python -m training.train
    python -m inference.evaluation.evaluate_after_clustering
    ...
"""

import runpy


def train_location_model() -> None:
    """
    Train the hydration site location (or thermodynamics) model.

    This is equivalent to running:
        python -m training.train
    inside the repository.
    """
    runpy.run_module("training.train", run_name="__main__")


def evaluate_location_model() -> None:
    """
    Evaluate the location model after clustering.

    Equivalent to:
        python -m inference.evaluation.evaluate_after_clustering
    """
    runpy.run_module(
        "inference.evaluation.evaluate_after_clustering",
        run_name="__main__",
    )


def thermo_correlation_plots() -> None:
    """
    Create thermodynamics correlation plots (enthalpy/entropy vs ground truth).

    Equivalent to:
        python -m inference.visualization.thermodynamics.create_correlation_plots
    """
    runpy.run_module(
        "inference.visualization.thermodynamics.create_correlation_plots",
        run_name="__main__",
    )


def calculate_displaced_waters() -> None:
    """
    Compute desolvation free energies vs experimental binding affinities.

    Equivalent to:
        python -m inference.visualization.calculate_displaced_waters
    """
    runpy.run_module(
        "inference.visualization.calculate_displaced_waters",
        run_name="__main__",
    )


def predict_waters() -> None:
    """
    Predict hydration sites with associated enthalpy and entropy.

    Equivalent to:
        python -m inference.evaluation.predict_waters
    """
    runpy.run_module(
        "inference.evaluation.predict_waters",
        run_name="__main__",
    )
