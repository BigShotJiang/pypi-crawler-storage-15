# toolbox of goodies

## squirrel.py

simple commandline wrapper around credstash

## treeify.py

display items in an ascii tree format

## dig.py

simple tool to normalise a spreadsheet into an outline
also convert excel to markdown


