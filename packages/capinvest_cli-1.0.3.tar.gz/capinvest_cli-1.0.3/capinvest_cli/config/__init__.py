"""Core config init."""
