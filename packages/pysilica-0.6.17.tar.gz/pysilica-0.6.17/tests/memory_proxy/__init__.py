"""Tests for Memory Proxy service."""
