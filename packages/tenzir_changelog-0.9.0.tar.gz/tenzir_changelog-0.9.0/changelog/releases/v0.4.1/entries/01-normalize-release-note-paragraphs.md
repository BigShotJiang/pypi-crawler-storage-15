---
title: Normalize release note paragraphs
type: bugfix
authors:
- codex
created: 2025-10-27
---

GitHub release notes now collapse soft line breaks from entry bodies so paragraphs render as expected.
