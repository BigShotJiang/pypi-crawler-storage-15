---
title: Enforce release version verification
type: change
authors:
- codex
created: 2025-11-09
---

Post-publish CI now checks that the version installed from PyPI matches the
release tag, preventing stale artifacts.
