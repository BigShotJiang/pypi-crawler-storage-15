---
title: Order same-day entries by modification time
type: change
authors:
- mavam
- codex
created: 2025-10-21
---

Ensure CLI views and exports stay reverse chronological by breaking same-day ties with entry file modification times.
