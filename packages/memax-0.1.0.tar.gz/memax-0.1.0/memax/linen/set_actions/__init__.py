"""This module contains set-action-based (classical) recurrent layers.
Each RNN type gets its own file.
+ `memax.linen.set_actions.gru` provides the Gated Recurrent Unit layer.
"""