CPCReady
Copyright 2025 David CH.F (destroyer)
Este producto incluye software desarrollado por David CH.F (destroyer).
Todos los derechos reservados. La redistribución debe mantener este aviso de atribución.
Repositorio oficial: https://github.com/CPCReady

“Hazlo o no lo hagas…. pero no lo intentes”