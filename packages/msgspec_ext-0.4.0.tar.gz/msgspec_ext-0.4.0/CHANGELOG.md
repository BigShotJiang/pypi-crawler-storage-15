# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.4.0] - 2025-12-03

## [0.3.4] - 2025-12-02

## [0.3.3] - 2025-12-02

## [0.3.2] - 2025-12-02

### Changed
- Aligned all GitHub Actions workflows and configurations with msgtrace-sdk standards
- Added CodeQL security scanning workflow
- Added automatic PR labeling workflow (disabled for fork PRs)
- Added monthly pre-commit hook auto-update workflow
- Updated publish workflow to automatically create release tags

### Fixed
- Fixed publish workflow version extraction to use grep instead of Python import
- Disabled labeler workflow to prevent failures on fork PRs

## [0.3.1] - 2025-12-02

### Changed
- Added uv.lock for reproducible builds

## [0.3.0] - 2025-12-02

### Added
- Comprehensive benchmark suite with statistical analysis
- Support for nested configuration via environment variables
- Improved documentation with accurate performance claims

### Changed
- Moved benchmark files to dedicated `/benchmark` directory
- Updated performance benchmarks: 2.7x faster than pydantic-settings
- Enhanced benchmark with 10 runs and statistical validation

### Fixed
- Merge-bot workflow now correctly handles PR branch checkouts
- Lint and formatting issues in benchmark code

## [0.1.0] - 2025-01-15

### Added
- Initial release
- BaseSettings class for environment-based configuration
- .env file support via python-dotenv
- Type validation using msgspec
- Support for common types: str, int, float, bool, list
- Field prefixes and delimiters
- Case-sensitive/insensitive matching
- JSON schema generation
- Performance optimizations with bulk JSON decoding
