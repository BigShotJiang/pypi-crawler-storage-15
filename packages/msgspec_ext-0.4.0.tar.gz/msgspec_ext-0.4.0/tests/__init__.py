"""Test suite for msgspec-ext."""
