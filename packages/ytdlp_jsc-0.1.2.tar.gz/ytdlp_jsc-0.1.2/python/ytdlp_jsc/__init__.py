# Re-export from native module
from ytdlp_jsc.ytdlp_jsc import solve

__all__ = ["solve"]
