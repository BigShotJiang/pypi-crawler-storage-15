"""
Revenium OpenAI Middleware Examples

This package contains example scripts demonstrating how to use the Revenium middleware
with OpenAI and Azure OpenAI APIs.
"""

__version__ = "0.4.8"
