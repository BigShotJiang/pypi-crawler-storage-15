The `android:usesCleartextTraffic` attribute indicates whether the app intends to use cleartext network traffic, such as cleartext HTTP.

The default value for apps that target API level 27 or lower is "true". Apps that target API level 28 or higher default to "false".
