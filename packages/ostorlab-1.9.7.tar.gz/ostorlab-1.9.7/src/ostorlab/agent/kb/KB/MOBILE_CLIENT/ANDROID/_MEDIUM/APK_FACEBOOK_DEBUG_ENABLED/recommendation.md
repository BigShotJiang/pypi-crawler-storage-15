Disable debug logs before deploying your app to the public.

=== "Java"
	```java
	FacebookSdk.setIsDebugEnabled(false);
	```
