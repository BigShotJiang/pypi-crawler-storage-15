Android performs by default a full backup of applications including the private files stored on /data partition. The
Backup Manager service uploads those data to the user's Google Drive account.