List of all calls to methods that interact with the Bluetooth and BLE.
