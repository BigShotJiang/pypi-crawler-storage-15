"""
Core package - contains configuration, database, and utilities
"""
