"""
Middleware package for request/response processing
"""
