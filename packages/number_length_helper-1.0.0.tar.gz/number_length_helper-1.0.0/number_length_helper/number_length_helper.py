"""
=======================================================================
 Number Length Helper (Functional Version)
-----------------------------------------------------------------------
 Provides functions to calculate:
   - Integer digit length
   - Float digit length (excluding decimal)
   - Digits before decimal point
   - Digits after decimal point (precision-based)

 Usage:
    int_length(123)
    float_length(3.141)
    before_decimal_length(123.45)
    after_decimal_length(3.14159, precision=3)

 Author: Kishor Kumar K
=======================================================================
"""

# ------------------------------------------------------------
# 1. Integer Length
# ------------------------------------------------------------
def int_length(value: int) -> int:
    """
    Count digits of an integer.
    Example:
        123  -> 3
        -987 -> 3
        0    -> 1
    """
    n = abs(int(value))

    if n == 0:
        return 1

    count = 0
    while n > 0:
        n //= 10
        count += 1

    return count


# ------------------------------------------------------------
# 2. Float Full Length (digits only)
# ------------------------------------------------------------
def float_length(value: float) -> int:
    """
    Count all digits of a float (removes decimal point).
    Example:
        3.14 -> "314" -> 3
        -12.005 -> "12005" -> 5
    """
    return len(str(abs(value)).replace('.', ''))


# ------------------------------------------------------------
# 3. Digits Before Decimal
# ------------------------------------------------------------
def before_decimal_length(value: float) -> int:
    """
    Count digits before the decimal in a float.
    Example:
        123.45 -> 3
        0.003 -> 1
        -987.12 -> 3
    """
    int_part = abs(int(value))

    if int_part == 0:
        return 1

    count = 0
    while int_part > 0:
        int_part //= 10
        count += 1

    return count


# ------------------------------------------------------------
# 4. Digits After Decimal (precision-based)
# ------------------------------------------------------------
def after_decimal_length(value: float, precision: int = 5) -> int:
    """
    Count digits after the decimal point (limited by precision).
    Example:
        3.141592 -> precision=3 -> 3
        10.009 -> precision=5 -> 3
    """
    value = abs(value)
    frac = value - int(value)

    count = 0
    while frac > 0 and count < precision:
        frac *= 10
        frac -= int(frac)
        count += 1

    return count
