# Number Length Helper

A lightweight Python utility to calculate digit lengths of integers and floats.

## Features
- Count integer digits
- Count float digits
- Digits before decimal
- Digits after decimal (precision-limited)
- Pure Python, no dependencies

## Installation


```bash
pip install number-length-helper

## Usage

from number_length_helper import (
    int_length,
    float_length,
    before_decimal_length,
    after_decimal_length
)

print(int_length(12345))               # 5
print(float_length(3.1415))            # 5
print(before_decimal_length(33239.23)) # 5
print(after_decimal_length(9.23411, 4))# 4
