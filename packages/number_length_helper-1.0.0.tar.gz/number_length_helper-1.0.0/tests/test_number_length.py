import pytest
from number_length_helper.number_length_helper import (
    int_length,
    float_length,
    before_decimal_length,
    after_decimal_length
)

def test_int_length():
    assert int_length(0) == 1
    assert int_length(5) == 1
    assert int_length(12345) == 5
    assert int_length(-9876) == 4

def test_float_length():
    assert float_length(3.14) == 3
    assert float_length(-12.005) == 5
    assert float_length(0.007) == 3

def test_before_decimal_length():
    assert before_decimal_length(123.45) == 3
    assert before_decimal_length(-0.234) == 1
    assert before_decimal_length(0.0) == 1

def test_after_decimal_length():
    assert after_decimal_length(3.141592, precision=3) == 3
    assert after_decimal_length(9.23411, precision=5) == 5
    assert after_decimal_length(0.007, precision=5) == 3
