from setuptools import setup, find_packages

setup(
    name="number-length-helper",
    version="1.0.0",
    description="A Python utility to calculate digit lengths of integers and floats.",
    author="Kishor Kumar K",
    packages=find_packages(),
    python_requires=">=3.7",
    license="MIT",
)
