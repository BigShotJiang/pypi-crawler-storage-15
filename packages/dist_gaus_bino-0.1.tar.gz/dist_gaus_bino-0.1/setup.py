from setuptools import setup

setup(
    name="dist_gaus_bino",
    version="0.1",
    description="Gaussian distributions",
    packages=["dist_gaus_bino"],
    zip_safe=False,
)
