def is_even(n):
    return n % 2 == 0

def is_odd(n):
    return n % 2 != 0