"""
ANNA Protocol SDK - Python Client
Versão: 2.0.1 (com Filebase/IPFS + Encryption)

SDK oficial para interagir com o ANNA Protocol

NOVO na v2.0.1:
✅ Integração Filebase/IPFS para reasoning storage
✅ Encryption client-side (AES-256-GCM) para privacidade
✅ Estrutura pública/privada de reasoning
✅ Upload automático de reasoning encrypted para IPFS
✅ Métodos decrypt para owner visualizar

MANTÉM TUDO da v1.2.13:
✅ Métodos submit_attestation, register_identity, etc
✅ ABIs dos contratos
✅ Validações de security
✅ Backward compatibility total
"""

import json
import time
import os
import base64
import requests
from typing import Dict, Optional, List, Tuple, Any, Union
from dataclasses import dataclass, asdict
from enum import Enum
from web3 import Web3
from eth_account import Account
from eth_account.messages import encode_typed_data
import logging

# Cryptography imports para encryption (v2.0)
try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.backends import default_backend
    ENCRYPTION_AVAILABLE = True
except ImportError:
    ENCRYPTION_AVAILABLE = False
    print("⚠️  Cryptography not installed. Encryption features disabled.")
    print("   Install with: pip install cryptography")


# Configurar logging

# Configurar logging
logger = logging.getLogger(__name__)



# ============================================================
# CONFIGURAÃƒÆ’Ã¢â‚¬Â¡ÃƒÆ’Ã¢â‚¬Â¢ES E CONSTANTES
# ============================================================

NETWORKS = {
    "polygon-amoy": {
        "rpc": "https://rpc-amoy.polygon.technology/",
        "chain_id": 80002,
        "explorer": "https://www.oklink.com/amoy"
    },
    "polygon-mainnet": {
        "rpc": "https://polygon-rpc.com",
        "chain_id": 137,
        "explorer": "https://polygonscan.com"
    }
}

# Configuração Filebase/IPFS (v2.0)
FILEBASE_CONFIG = {
    "api_url": "https://api.filebase.io/v1/ipfs",
    "gateway": "https://ipfs.filebase.io/ipfs"
}

# ============================================================
# TIPOS E ENUMS
# ============================================================

class VerificationTier(Enum):
    """NÃƒÆ’Ã‚Â­veis de verificaÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o disponÃƒÆ’Ã‚Â­veis"""
    BASIC = "basic"
    STANDARD = "standard"
    PREMIUM = "premium"


class AttestationStatus(Enum):
    """Status possÃƒÆ’Ã‚Â­veis de uma attestation"""
    PENDING = "pending"
    VERIFIED = "verified"
    REJECTED = "rejected"
    CHALLENGED = "challenged"


@dataclass
class ReasoningStep:
    """Estrutura de um passo de raciocÃƒÆ’Ã‚Â­nio"""
    step_number: int
    description: str
    rationale: str


@dataclass
class Reasoning:
    """Estrutura completa de raciocÃƒÆ’Ã‚Â­nio"""
    input: str
    reasoning_steps: List[ReasoningStep]
    conclusion: str
    confidence: float
    
    def to_dict(self) -> Dict:
        """Converte para dicionÃƒÆ’Ã‚Â¡rio"""
        return {
            "input": self.input,
            "reasoning_steps": [
                {
                    "step_number": step.step_number,
                    "description": step.description,
                    "rationale": step.rationale
                }
                for step in self.reasoning_steps
            ],
            "conclusion": self.conclusion,
            "confidence": self.confidence
        }


@dataclass
class Metadata:
    """
    Metadados estruturados para attestations
    Permite rastreabilidade bidirecional entre sistemas externos e ANNA
    
    Exemplo:
        metadata = Metadata(
            external_id="PROC-2024-12345",
            document_type="contrato_locacao",
            client_name="JoÃƒÆ’Ã‚Â£o Silva",
            system_origin="LegalTech Pro v2.0",
            custom_fields={"valor": "R$ 2.500,00", "prazo": "12 meses"}
        )
    """
    external_id: Optional[str] = None          # ID do sistema externo (processo, contrato, etc)
    document_type: Optional[str] = None        # Tipo do documento
    client_name: Optional[str] = None          # Nome do cliente
    system_origin: Optional[str] = None        # Sistema de origem
    custom_fields: Optional[Dict[str, Any]] = None  # Campos adicionais customizados
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionÃƒÆ’Ã‚Â¡rio, removendo valores None"""
        data = asdict(self)
        return {k: v for k, v in data.items() if v is not None}
    
    def to_json(self) -> str:
        """Converte para string JSON compacta"""
        return json.dumps(self.to_dict(), ensure_ascii=False, separators=(',', ':'))
    
    @classmethod
    def from_json(cls, json_str: str) -> 'Metadata':
        """Cria Metadata a partir de string JSON"""
        data = json.loads(json_str)
        return cls(**data)
    
    def validate(self, max_size: int = 500) -> bool:
        """
        Valida se os metadados estÃƒÆ’Ã‚Â£o dentro dos limites
        
        Args:
            max_size: Tamanho mÃƒÆ’Ã‚Â¡ximo em caracteres (default: 500)
            
        Returns:
            True se vÃƒÆ’Ã‚Â¡lido
            
        Raises:
            ValueError se exceder o tamanho mÃƒÆ’Ã‚Â¡ximo
        """
        json_str = self.to_json()
        if len(json_str) > max_size:
            raise ValueError(
                f"Metadados muito grandes: {len(json_str)} caracteres "
                f"(mÃƒÆ’Ã‚Â¡ximo: {max_size}). Considere usar campos mais concisos."
            )
        return True


@dataclass
class AttestationResult:
    """Resultado de uma attestation"""
    attestation_id: str
    tx_hash: str
    status: AttestationStatus
    timestamp: int
    explorer_url: str
    verified: bool = False
    score: Optional[int] = None
    verifier: Optional[str] = None
    verification_time: Optional[int] = None
    metadata: Optional[Metadata] = None  # NOVO: metadados da attestation




# ============================================================
# ESTRUTURAS v2.0 (Public/Private Reasoning)
# ============================================================

@dataclass
class PublicReasoning:
    """
    Parte PÚBLICA do reasoning (não criptografada)
    Visível para qualquer um que consultar a attestation
    """
    attestation_id: str
    timestamp: int
    conclusion: str  # "approved" ou "rejected"
    confidence_score: float  # 0.0 a 1.0
    risk_level: str  # "low", "medium", "high"
    version: str = "2.0-encrypted"
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class PrivateReasoning:
    """
    Parte PRIVADA do reasoning (será criptografada)
    Somente owner pode decriptar e visualizar
    """
    steps: List['DetailedReasoningStep']
    ai_model: str
    processing_time: str
    raw_input: Optional[str] = None
    additional_metadata: Optional[Dict[str, Any]] = None
    
    def to_dict(self) -> Dict[str, Any]:
        data = {
            "steps": [asdict(step) for step in self.steps],
            "ai_model": self.ai_model,
            "processing_time": self.processing_time
        }
        if self.raw_input:
            data["raw_input"] = self.raw_input
        if self.additional_metadata:
            data["additional_metadata"] = self.additional_metadata
        return data


@dataclass
class DetailedReasoningStep:
    """
    Um passo individual detalhado no processo de raciocínio da IA
    NOVO em v2.0 - quebra a black box da AI!
    """
    step: int
    action: str
    input: Dict[str, Any]
    analysis: str
    ai_reasoning: str
    score: int
    confidence: float
    result: str


@dataclass
class EncryptedData:
    """Dados criptografados com nonce (v2.0)"""
    nonce: str  # hex
    ciphertext: str  # hex


@dataclass
class FullReasoning:
    """
    Estrutura completa de reasoning (pública + privada) v2.0
    """
    public: PublicReasoning
    private_encrypted: EncryptedData
    ipfs_cid: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "public": self.public.to_dict(),
            "private_encrypted": {
                "nonce": self.private_encrypted.nonce,
                "ciphertext": self.private_encrypted.ciphertext
            },
            "version": "2.0-encrypted"
        }


@dataclass
class Identity:
    """Identidade de um agente"""
    agent_id: int
    did: str
    address: str
    model_type: str
    model_version: str
    specializations: List[str]
    creation_time: int
    token_uri: Optional[str] = None



# ============================================================
# FILEBASE CLIENT (IPFS) - v2.0
# ============================================================

class FilebaseClient:
    """Cliente para interagir com Filebase/IPFS via S3 (v2.0.1)"""
    
    def __init__(self, api_key: str, api_secret: str, bucket_name: str = "anna-protocol"):
        """
        Inicializa cliente Filebase usando S3-compatible API
        
        Args:
            api_key: Filebase Access Key ID
            api_secret: Filebase Secret Access Key
            bucket_name: Nome do bucket (deve existir no Filebase)
        """
        self.api_key = api_key
        self.api_secret = api_secret
        self.bucket_name = bucket_name
        
        # Tentar importar boto3
        try:
            import boto3
            from botocore.client import Config
            
            # Configurar cliente S3 para Filebase
            self.s3 = boto3.client(
                's3',
                endpoint_url='https://s3.filebase.com',
                aws_access_key_id=api_key,
                aws_secret_access_key=api_secret,
                config=Config(signature_version='s3v4')
            )
            
            logger.info(f"✅ Filebase S3 client initialized (bucket: {bucket_name})")
            
        except ImportError:
            raise Exception(
                "boto3 required for Filebase. Install with: pip install boto3"
            )
        except Exception as e:
            logger.error(f"❌ Failed to initialize Filebase client: {e}")
            raise
    
    def upload_json(self, data: Dict[str, Any], filename: Optional[str] = None) -> str:
        """
        Faz upload de JSON para Filebase/IPFS via S3
        
        Returns:
            Filename/key do objeto (pode ser usado como CID)
        """
        if not filename:
            filename = f"reasoning_{int(time.time())}.json"
        
        json_data = json.dumps(data, ensure_ascii=False, indent=2)
        
        try:
            # Upload para S3/Filebase
            self.s3.put_object(
                Bucket=self.bucket_name,
                Key=filename,
                Body=json_data.encode('utf-8'),
                ContentType='application/json',
                Metadata={
                    'anna-protocol': 'v2.0.1',
                    'content-type': 'reasoning'
                }
            )
            
            logger.info(f"✅ Uploaded to Filebase: {filename}")
            
            # Retornar filename como identificador
            return filename
            
        except Exception as e:
            logger.error(f"❌ Filebase upload failed: {e}")
            raise Exception(f"Failed to upload to Filebase: {e}")
    
    def get_url(self, cid: str) -> str:
        """Retorna URL do S3/Filebase"""
        return f"https://{self.bucket_name}.s3.filebase.com/{cid}"
    
    def fetch(self, cid: str) -> Dict[str, Any]:
        """Baixa dados do Filebase via S3"""
        try:
            response = self.s3.get_object(
                Bucket=self.bucket_name,
                Key=cid
            )
            
            content = response['Body'].read().decode('utf-8')
            return json.loads(content)
            
        except Exception as e:
            logger.error(f"❌ Failed to fetch from Filebase: {e}")
            raise Exception(f"Failed to fetch {cid}: {e}")


# ============================================================
# ENCRYPTION ENGINE - v2.0
# ============================================================

class EncryptionEngine:
    """
    Engine de criptografia para reasoning privado (v2.0)
    Usa AES-256-GCM (authenticated encryption)
    """
    
    @staticmethod
    def derive_key(
        owner_private_key: str,
        attestation_id: str,
        iterations: int = 100000
    ) -> bytes:
        """Deriva chave de encryption usando PBKDF2"""
        if not ENCRYPTION_AVAILABLE:
            raise Exception("Cryptography library not installed. Install with: pip install cryptography")
        
        # Remove '0x' prefix se existir
        if owner_private_key.startswith('0x'):
            owner_private_key = owner_private_key[2:]
        
        password = bytes.fromhex(owner_private_key)
        salt = f"anna-v2-{attestation_id}".encode('utf-8')
        
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=iterations,
            backend=default_backend()
        )
        
        key = kdf.derive(password)
        return key
    
    @staticmethod
    def encrypt(
        plaintext_data: Dict[str, Any],
        owner_private_key: str,
        attestation_id: str
    ) -> EncryptedData:
        """Criptografa dados usando AES-256-GCM"""
        if not ENCRYPTION_AVAILABLE:
            raise Exception("Cryptography library not installed")
        
        key = EncryptionEngine.derive_key(owner_private_key, attestation_id)
        aesgcm = AESGCM(key)
        nonce = os.urandom(12)
        plaintext = json.dumps(plaintext_data, ensure_ascii=False).encode('utf-8')
        ciphertext = aesgcm.encrypt(nonce, plaintext, None)
        
        return EncryptedData(
            nonce=nonce.hex(),
            ciphertext=ciphertext.hex()
        )
    
    @staticmethod
    def decrypt(
        encrypted_data: EncryptedData,
        owner_private_key: str,
        attestation_id: str
    ) -> Dict[str, Any]:
        """Decripta dados (só funciona com private key correta)"""
        if not ENCRYPTION_AVAILABLE:
            raise Exception("Cryptography library not installed")
        
        try:
            key = EncryptionEngine.derive_key(owner_private_key, attestation_id)
            aesgcm = AESGCM(key)
            nonce = bytes.fromhex(encrypted_data.nonce)
            ciphertext = bytes.fromhex(encrypted_data.ciphertext)
            plaintext = aesgcm.decrypt(nonce, ciphertext, None)
            return json.loads(plaintext.decode('utf-8'))
        except Exception as e:
            logger.error(f"❌ Decryption failed: {e}")
            raise Exception(
                "Decryption failed. Possible reasons: "
                "wrong private key, corrupted data, or tampered ciphertext"
            )


# ============================================================
# CLIENTE PRINCIPAL
# ============================================================

class ANNAClient:
    """Cliente principal do ANNA Protocol SDK"""
    
    # PadrÃƒÆ’Ã‚Âµes proibidos (sincronizado com verifier.py)
    FORBIDDEN_PATTERNS = [
        "ignore previous instructions",
        "ignore all instructions",
        "jailbreak",
        "bypass",
        "hack",
        "disable safety",
        "ignore guidelines",
        "forget everything",
        "new instructions",
        "system prompt",
        "override"
    ]
    
    # Limites de tamanho (anti-spam)
    MIN_REASONING_SIZE = 100      # bytes
    MAX_REASONING_SIZE = 50000    # 50 KB
    MAX_METADATA_SIZE = 500       # 500 caracteres para metadados
    
    # Threshold de aprovaÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o Tier 1
    TIER1_PASS_THRESHOLD = 60     # Score mÃƒÆ’Ã‚Â­nimo (0-100)
    
    def __init__(
        self,
        private_key: str,
        network: str = "polygon-amoy",
        identity_contract: Optional[str] = None,
        attestation_contract: Optional[str] = None,
        reputation_contract: Optional[str] = None,
        # NOVO v2.0: Filebase/IPFS
        filebase_api_key: Optional[str] = None,
        filebase_api_secret: Optional[str] = None,
        filebase_bucket: str = "anna-protocol"  # NOVO v2.0.1
    ):
        """Inicializa o cliente ANNA v2.0.1"""
        if network not in NETWORKS:
            raise ValueError(f"Network inválida. Use: {list(NETWORKS.keys())}")
        
        self.network = network
        self.network_config = NETWORKS[network]
        self.w3 = Web3(Web3.HTTPProvider(self.network_config["rpc"]))
        
        if not self.w3.is_connected():
            raise ConnectionError(f"Não foi possível conectar ao RPC: {self.network_config['rpc']}")
        
        self.account = Account.from_key(private_key)
        self.address = self.account.address
        self.private_key = private_key  # NOVO v2.0: guardar para encryption
        
        # NOVO v2.0.1: Inicializa Filebase client (S3) se credenciais fornecidas
        if filebase_api_key and filebase_api_secret:
            self.filebase = FilebaseClient(
                api_key=filebase_api_key,
                api_secret=filebase_api_secret,
                bucket_name=filebase_bucket
            )
            logger.info("✅ IPFS storage enabled (Filebase S3)")
        else:
            self.filebase = None
            logger.info("ℹ️  IPFS storage disabled (no Filebase credentials)")
        
        self.identity_contract = identity_contract
        self.attestation_contract = attestation_contract
        self.reputation_contract = reputation_contract
        
        self._load_abis()
        
        if self.identity_contract:
            self.identity = self.w3.eth.contract(
                address=Web3.to_checksum_address(self.identity_contract),
                abi=self.identity_abi
            )
        
        if self.attestation_contract:
            self.attestation = self.w3.eth.contract(
                address=Web3.to_checksum_address(self.attestation_contract),
                abi=self.attestation_abi
            )
        
        if self.reputation_contract:
            self.reputation = self.w3.eth.contract(
                address=Web3.to_checksum_address(self.reputation_contract),
                abi=self.reputation_abi
            )
    
    def _load_abis(self):
        """Carrega ABIs dos contratos"""
        self.identity_abi = [
            {
                "inputs": [
                    {"name": "agentAddress", "type": "address"},
                    {"name": "did", "type": "string"},
                    {"name": "modelType", "type": "string"},
                    {"name": "modelVersion", "type": "string"},
                    {"name": "specializations", "type": "string[]"}
                ],
                "name": "registerAgent",
                "outputs": [{"name": "", "type": "uint256"}],
                "stateMutability": "nonpayable",
                "type": "function"
            },
            {
                "inputs": [{"name": "agentAddress", "type": "address"}],
                "name": "agentIdByAddress",
                "outputs": [{"name": "", "type": "uint256"}],
                "stateMutability": "view",
                "type": "function"
            }
        ]
        
        self.attestation_abi = [
            {
                "inputs": [
                    {"name": "contentHash", "type": "bytes32"},
                    {"name": "reasoningHash", "type": "bytes32"},
                    {"name": "modelVersion", "type": "string"},
                    {"name": "category", "type": "string"},
                    {"name": "timestamp", "type": "uint256"},
                    {"name": "signature", "type": "bytes"}
                ],
                "name": "submitAttestation",
                "outputs": [{"name": "", "type": "bytes32"}],
                "stateMutability": "nonpayable",
                "type": "function"
            },
            {
                "inputs": [{"name": "", "type": "bytes32"}],
                "name": "attestations",
                "outputs": [
                    {"name": "contentHash", "type": "bytes32"},
                    {"name": "reasoningHash", "type": "bytes32"},
                    {"name": "agent", "type": "address"},
                    {"name": "modelVersion", "type": "string"},
                    {"name": "timestamp", "type": "uint256"},
                    {"name": "status", "type": "uint8"},
                    {"name": "consistencyScore", "type": "uint256"},
                    {"name": "verifier", "type": "address"},
                    {"name": "verificationTime", "type": "uint256"},
                    {"name": "category", "type": "string"},
                    {"name": "txHash", "type": "bytes32"}  # âœ… NOVO v1.2.10
                ],
                "stateMutability": "view",
                "type": "function"
            },
            {
                "inputs": [
                    {"name": "attestationId", "type": "bytes32"},
                    {"name": "txHash", "type": "bytes32"}
                ],
                "name": "setAttestationTxHash",  # âœ… NOVO v1.2.10
                "outputs": [],
                "stateMutability": "nonpayable",
                "type": "function"
            }
        ]
        
        self.reputation_abi = [
            {
                "inputs": [{"name": "", "type": "address"}],
                "name": "reputationScore",
                "outputs": [{"name": "", "type": "uint256"}],
                "stateMutability": "view",
                "type": "function"
            }
        ]
    
    def _validate_reasoning(self, reasoning: Union[str, Reasoning]) -> str:
        """
        Valida o raciocÃƒÆ’Ã‚Â­nio antes de enviar
        
        Args:
            reasoning: String JSON ou objeto Reasoning
            
        Returns:
            String JSON validada
            
        Raises:
            ValueError: Se a validaÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o falhar
        """
        # Converter para string se for objeto Reasoning
        if isinstance(reasoning, Reasoning):
            reasoning_str = json.dumps(reasoning.to_dict())
        else:
            reasoning_str = reasoning
        
        # Verificar se ÃƒÆ’Ã‚Â© JSON vÃƒÆ’Ã‚Â¡lido
        try:
            reasoning_obj = json.loads(reasoning_str)
        except json.JSONDecodeError as e:
            raise ValueError(f"Reasoning invÃƒÆ’Ã‚Â¡lido (nÃƒÆ’Ã‚Â£o ÃƒÆ’Ã‚Â© JSON): {e}")
        
        # Verificar tamanho
        reasoning_bytes = reasoning_str.encode('utf-8')
        if len(reasoning_bytes) < self.MIN_REASONING_SIZE:
            raise ValueError(
                f"Reasoning muito curto: {len(reasoning_bytes)} bytes "
                f"(mÃƒÆ’Ã‚Â­nimo: {self.MIN_REASONING_SIZE})"
            )
        
        if len(reasoning_bytes) > self.MAX_REASONING_SIZE:
            raise ValueError(
                f"Reasoning muito longo: {len(reasoning_bytes)} bytes "
                f"(mÃƒÆ’Ã‚Â¡ximo: {self.MAX_REASONING_SIZE})"
            )
        
        # Verificar padrÃƒÆ’Ã‚Âµes proibidos
        reasoning_lower = reasoning_str.lower()
        for pattern in self.FORBIDDEN_PATTERNS:
            if pattern in reasoning_lower:
                raise ValueError(f"PadrÃƒÆ’Ã‚Â£o proibido detectado: '{pattern}'")
        
        # Tier 1: verificar campos obrigatÃƒÆ’Ã‚Â³rios bÃƒÆ’Ã‚Â¡sicos
        required_fields = ["input", "conclusion"]
        for field in required_fields:
            if field not in reasoning_obj:
                raise ValueError(f"Campo obrigatÃƒÆ’Ã‚Â³rio ausente: '{field}'")
        
        return reasoning_str
    
    def _set_attestation_txhash(
        self,
        attestation_id: bytes,
        tx_hash: str,
        wait_for_confirmation: bool = True
    ) -> Optional[str]:
        """
        Registra transaction hash on-chain (NOVO v1.2.6)
        
        Este mÃ©todo Ã© chamado automaticamente apÃ³s submitAttestation().
        FAIL-SAFE: Se contrato nÃ£o suportar (v1.1), apenas retorna None.
        
        Args:
            attestation_id: ID da attestation (bytes32)
            tx_hash: Transaction hash da criaÃ§Ã£o (string hex)
            wait_for_confirmation: Se deve aguardar confirmaÃ§Ã£o
            
        Returns:
            Transaction hash do setAttestationTxHash ou None se falhar
        """
        try:
            # Verificar se mÃ©todo existe (contrato v1.2+)
            if not hasattr(self.attestation.functions, 'setAttestationTxHash'):
                logger.debug("Contract does not support setAttestationTxHash (v1.1)")
                return None
            
            # Converter attestation_id para bytes32 se necessÃ¡rio
            if isinstance(attestation_id, str):
                if attestation_id.startswith('0x'):
                    attestation_id = bytes.fromhex(attestation_id[2:])
                else:
                    attestation_id = bytes.fromhex(attestation_id)
            
            # Converter tx_hash para bytes32
            if tx_hash.startswith('0x'):
                tx_hash_bytes = bytes.fromhex(tx_hash[2:])
            else:
                tx_hash_bytes = bytes.fromhex(tx_hash)
            
            logger.info(f"ðŸ“ Registering txHash on-chain: {tx_hash[:16]}...")
            
            # Chamar setAttestationTxHash
            tx = self.attestation.functions.setAttestationTxHash(
                attestation_id,
                tx_hash_bytes
            ).build_transaction({
                'from': self.address,
                'nonce': self.w3.eth.get_transaction_count(self.address),
                'gas': 100000,
                'gasPrice': self.w3.eth.gas_price
            })
            
            signed_tx = self.account.sign_transaction(tx)
            set_tx_hash = self.w3.eth.send_raw_transaction(signed_tx.raw_transaction)
            set_tx_hash_hex = set_tx_hash.hex()
            
            if wait_for_confirmation:
                receipt = self.w3.eth.wait_for_transaction_receipt(set_tx_hash)
                if receipt['status'] != 1:
                    logger.warning(f"âš ï¸  setAttestationTxHash failed: {set_tx_hash_hex}")
                    return None
                logger.info(f"âœ… TxHash registered on-chain: {set_tx_hash_hex[:16]}...")
            
            return set_tx_hash_hex
            
        except Exception as e:
            # FAIL-SAFE: NÃ£o quebrar se setAttestationTxHash falhar
            logger.warning(f"âš ï¸  Could not set txHash on-chain: {e}")
            return None
    
    def submit_attestation(
        self,
        content: str,
        reasoning: Union[str, Reasoning],
        model_version: str = "claude-sonnet-4-20250514",
        category: str = "general",
        wait_for_confirmation: bool = True,
        store_txhash: bool = True  # NOVO v1.2.6
    ) -> AttestationResult:
        """
        Submete uma attestation ao ANNA Protocol
        
        Args:
            content: ConteÃƒÆ’Ã‚Âºdo gerado pelo agente
            reasoning: RaciocÃƒÆ’Ã‚Â­nio (string JSON ou objeto Reasoning)
            model_version: VersÃƒÆ’Ã‚Â£o do modelo
            category: Categoria da attestation
            wait_for_confirmation: Se deve esperar confirmaÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o da transaÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o
            
        Returns:
            AttestationResult com informaÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Âµes da attestation
            
        Raises:
            ValueError: Se a validaÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o falhar
            Exception: Se a transaÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o falhar
        """
        if not self.attestation_contract:
            raise ValueError("EndereÃƒÆ’Ã‚Â§o do contrato Attestation nÃƒÆ’Ã‚Â£o configurado")
        
        # Validar reasoning
        reasoning_str = self._validate_reasoning(reasoning)
        
        # Calcular hashes
        content_hash = Web3.keccak(text=content)
        reasoning_hash = Web3.keccak(text=reasoning_str)
        
        # Preparar timestamp e assinatura
        timestamp = int(time.time())
        
        message_hash = Web3.solidity_keccak(
            ['bytes32', 'bytes32', 'address', 'uint256'],
            [content_hash, reasoning_hash, self.address, timestamp]
        )
        
        encoded_data = encode_typed_data(
            domain_data={
                'name': 'ANNA Protocol',
                'version': '1',
                'chainId': self.network_config['chain_id'],
                'verifyingContract': self.attestation_contract
            },
            message_types={
                'Attestation': [
                    {'name': 'contentHash', 'type': 'bytes32'},
                    {'name': 'reasoningHash', 'type': 'bytes32'},
                    {'name': 'agent', 'type': 'address'},
                    {'name': 'modelVersion', 'type': 'string'},
                    {'name': 'timestamp', 'type': 'uint256'},
                    {'name': 'category', 'type': 'string'}
                ]
            },
            message_data={
                'contentHash': content_hash,
                'reasoningHash': reasoning_hash,
                'agent': self.address,
                'modelVersion': model_version,
                'timestamp': timestamp,
                'category': category
            }
        )
        
        signature = self.account.sign_message(encoded_data).signature
        
        tx = self.attestation.functions.submitAttestation(
            content_hash,
            reasoning_hash,
            model_version,
            category,
            timestamp,
            signature
        ).build_transaction({
            'from': self.address,
            'nonce': self.w3.eth.get_transaction_count(self.address),
            'gas': 500000,
            'gasPrice': self.w3.eth.gas_price
        })
        
        signed_tx = self.account.sign_transaction(tx)
        tx_hash = self.w3.eth.send_raw_transaction(signed_tx.raw_transaction)
        tx_hash_hex = tx_hash.hex()
        
        # IMPORTANTE: attestation_id deve vir do EVENTO, nÃ£o de cÃ¡lculo local!
        # O cÃ¡lculo local pode divergir do que o contrato emite
        attestation_id = None
        
        if wait_for_confirmation:
            receipt = self.w3.eth.wait_for_transaction_receipt(tx_hash)
            if receipt['status'] != 1:
                revert_reason = "Unknown"
                try:
                    from web3.datastructures import AttributeDict
                    failed_tx = self.w3.eth.get_transaction(tx_hash)
                    # Converter para AttributeDict para eth.call funcionar
                    tx_dict = AttributeDict({
                        'from': failed_tx['from'],
                        'to': failed_tx['to'],
                        'data': failed_tx['input'],
                        'value': failed_tx.get('value', 0),
                        'gas': failed_tx.get('gas', 300000)
                    })
                    self.w3.eth.call(tx_dict, receipt['blockNumber'])
                except Exception as e: 
                    revert_reason = str(e)
                raise Exception(f"TransaÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o falhou!\nRevert reason: {revert_reason}\nTX hash: {tx_hash.hex()}")
            
            # âœ… CORRETO v1.2.11: Extrair attestation_id do EVENTO
            # Evento AttestationSubmitted tem o ID correto em topic[1]
            try:
                for log in receipt['logs']:
                    if log['address'].lower() == self.attestation_contract.lower():
                        if len(log['topics']) >= 2:
                            # topic[0] = event signature
                            # topic[1] = attestationId (indexed)
                            attestation_id = log['topics'][1].hex()
                            logger.info(f"ðŸ“‹ Attestation ID extraÃ­do do evento: {attestation_id[:20]}...")
                            break
            except Exception as e:
                logger.warning(f"âš ï¸  NÃ£o conseguiu extrair ID do evento: {e}")
                # Fallback para cÃ¡lculo local (menos confiÃ¡vel)
                attestation_id = Web3.solidity_keccak(
                    ['bytes32', 'bytes32', 'address', 'uint256'],
                    [content_hash, reasoning_hash, self.address, timestamp]
                ).hex()
            
            # NOVO v1.2.11: Salvar txHash on-chain com ID CORRETO do evento
            if store_txhash and attestation_id:
                self._set_attestation_txhash(
                    attestation_id=attestation_id,
                    tx_hash=tx_hash_hex,
                    wait_for_confirmation=True
                )
        else:
            # Se nÃ£o esperar confirmaÃ§Ã£o, usar cÃ¡lculo local (menos confiÃ¡vel)
            attestation_id = Web3.solidity_keccak(
                ['bytes32', 'bytes32', 'address', 'uint256'],
                [content_hash, reasoning_hash, self.address, timestamp]
            ).hex()
        
        explorer_url = f"{self.network_config['explorer']}/tx/{tx_hash_hex}"
        
        return AttestationResult(
            attestation_id=attestation_id,
            tx_hash=tx_hash_hex,
            status=AttestationStatus.PENDING,
            timestamp=timestamp,
            explorer_url=explorer_url
        )
    
    def submit_attestation_with_metadata(
        self,
        content: str,
        reasoning: Union[str, Reasoning],
        metadata: Metadata,
        model_version: str = "claude-sonnet-4-20250514",
        wait_for_confirmation: bool = True,
        store_txhash: bool = True  # NOVO v1.2.6
    ) -> AttestationResult:
        """
        Submete uma attestation com metadados estruturados
        
        MÃƒÆ’Ã‚Â©todo conveniente que facilita o envio de attestations com rastreabilidade.
        Os metadados sÃƒÆ’Ã‚Â£o armazenados no campo 'category' como JSON.
        
        Exemplo de uso:
            metadata = Metadata(
                external_id="PROC-2024-12345",
                document_type="contrato_locacao",
                client_name="JoÃƒÆ’Ã‚Â£o Silva",
                system_origin="LegalTech Pro",
                custom_fields={"valor": "R$ 2.500,00"}
            )
            
            result = client.submit_attestation_with_metadata(
                content=contract_text,
                reasoning=ai_reasoning,
                metadata=metadata
            )
            
            # Guardar no banco local
            db.save({
                "processo_id": "PROC-2024-12345",
                "anna_attestation_id": result.attestation_id
            })
        
        Args:
            content: ConteÃƒÆ’Ã‚Âºdo gerado pelo agente
            reasoning: RaciocÃƒÆ’Ã‚Â­nio (string JSON ou objeto Reasoning)
            metadata: Objeto Metadata com informaÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Âµes estruturadas
            model_version: VersÃƒÆ’Ã‚Â£o do modelo
            wait_for_confirmation: Se deve esperar confirmaÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o da transaÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o
            
        Returns:
            AttestationResult com informaÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Âµes da attestation e metadados
            
        Raises:
            ValueError: Se a validaÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o falhar
            Exception: Se a transaÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o falhar
        """
        # Validar metadados
        metadata.validate(max_size=self.MAX_METADATA_SIZE)
        
        # Converter metadados para JSON
        category = metadata.to_json()
        
        # Submeter attestation normalmente
        result = self.submit_attestation(
            content=content,
            reasoning=reasoning,
            model_version=model_version,
            category=category,
            wait_for_confirmation=wait_for_confirmation,
            store_txhash=store_txhash  # NOVO v1.2.7: passar parÃ¢metro
        )
        
        # Adicionar metadados ao resultado
        result.metadata = metadata
        
        return result
    
    def register_identity(
        self,
        model_type: str,
        model_version: str,
        specializations: List[str],
        wait_for_confirmation: bool = True
    ) -> Identity:
        """Registra a identidade do agente"""
        if not self.identity_contract:
            raise ValueError("EndereÃƒÆ’Ã‚Â§o do contrato Identity nÃƒÆ’Ã‚Â£o configurado")
        
        agent_id = self.identity.functions.agentIdByAddress(self.address).call()
        if agent_id != 0:
            raise ValueError(f"Agente jÃƒÆ’Ã‚Â¡ registrado com ID: {agent_id}")
        
        # Generate DID
        did = f"did:anna:{self.address.lower()}"
        
        tx = self.identity.functions.registerAgent(
            self.address,      # agentAddress
            did,               # did
            model_type,        # modelType
            model_version,     # modelVersion
            specializations    # specializations
        ).build_transaction({
            'from': self.address,
            'nonce': self.w3.eth.get_transaction_count(self.address),
            'gas': 500000,  # Increased gas limit for safety
            'gasPrice': self.w3.eth.gas_price
        })
        
        signed_tx = self.account.sign_transaction(tx)
        tx_hash = self.w3.eth.send_raw_transaction(signed_tx.raw_transaction)
        
        if wait_for_confirmation:
            receipt = self.w3.eth.wait_for_transaction_receipt(tx_hash)
            if receipt['status'] != 1:
                raise Exception("TransaÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o falhou")
        
        agent_id = self.identity.functions.agentIdByAddress(self.address).call()
        
        return Identity(
            agent_id=agent_id if wait_for_confirmation else 0,
            did=did,
            address=self.address,
            model_type=model_type,
            model_version=model_version,
            specializations=specializations,
            creation_time=int(time.time())
        )
    
    def get_attestation(self, attestation_id: str) -> Dict[str, Any]:
        """
        Busca informaÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Âµes de uma attestation
        
        Se o campo category contiver JSON com metadados estruturados,
        eles serÃƒÆ’Ã‚Â£o automaticamente parseados.
        """
        if not self.attestation_contract:
            raise ValueError("EndereÃƒÆ’Ã‚Â§o do contrato Attestation nÃƒÆ’Ã‚Â£o configurado")
        
        attestation_data = self.attestation.functions.attestations(attestation_id).call()
        
        # Tentar parsear metadados do category
        category = attestation_data[9]
        metadata = None
        try:
            metadata = Metadata.from_json(category)
        except (json.JSONDecodeError, TypeError):
            # Se nÃƒÆ’Ã‚Â£o for JSON vÃƒÆ’Ã‚Â¡lido, category ÃƒÆ’Ã‚Â© string simples
            pass
        
        return {
            "content_hash": attestation_data[0].hex(),
            "reasoning_hash": attestation_data[1].hex(),
            "agent": attestation_data[2],
            "model_version": attestation_data[3],
            "timestamp": attestation_data[4],
            "status": AttestationStatus(attestation_data[5]),
            "consistency_score": attestation_data[6],
            "verifier": attestation_data[7],
            "verification_time": attestation_data[8],
            "category": category,
            "metadata": metadata  # NOVO: metadados parseados (ou None)
        }
    
    def wait_for_verification(
        self,
        attestation_id: str,
        timeout: int = 60,
        poll_interval: int = 5
    ) -> AttestationResult:
        """Aguarda a verificaÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o de uma attestation"""
        start_time = time.time()
        
        while time.time() - start_time < timeout:
            attestation = self.get_attestation(attestation_id)
            
            if attestation["status"] != AttestationStatus.PENDING:
                return AttestationResult(
                    attestation_id=attestation_id,
                    tx_hash="",
                    status=attestation["status"],
                    timestamp=attestation["timestamp"],
                    explorer_url=f"{self.network_config['explorer']}/address/{self.attestation_contract}",
                    verified=attestation["status"] == AttestationStatus.VERIFIED,
                    score=attestation["consistency_score"],
                    verifier=attestation["verifier"],
                    verification_time=attestation["verification_time"],
                    metadata=attestation.get("metadata")  # NOVO: incluir metadados
                )
            
            time.sleep(poll_interval)
        
        raise TimeoutError(f"VerificaÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o nÃƒÆ’Ã‚Â£o concluÃƒÆ’Ã‚Â­da em {timeout}s")
    
    def get_reputation(self, agent_address: Optional[str] = None) -> int:
        """Busca o score de reputaÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o de um agente"""
        if not self.reputation_contract:
            raise ValueError("EndereÃƒÆ’Ã‚Â§o do contrato Reputation nÃƒÆ’Ã‚Â£o configurado")
        
        address = agent_address or self.address
        score = self.reputation.functions.reputationScore(address).call()
        return score
    

    
    # ============================================================
    # MÉTODOS v2.0 (Filebase + Encryption)
    # ============================================================
    
    def create_attestation_v2(
        self,
        public_reasoning: PublicReasoning,
        private_reasoning: PrivateReasoning,
        metadata: Optional[Metadata] = None,
        wait_for_confirmation: bool = True
    ) -> AttestationResult:
        """
        Cria attestation com reasoning encrypted (versão 2.0)
        
        Fluxo:
        1. Gera ID temporário
        2. Encrypta reasoning privado
        3. Faz upload do reasoning completo para IPFS
        4. Submete attestation para blockchain com IPFS CID
        5. Retorna resultado
        """
        if not self.filebase:
            raise Exception(
                "IPFS storage not configured. "
                "Provide filebase_api_key and filebase_api_secret"
            )
        
        if not self.attestation_contract:
            raise ValueError("Attestation contract not configured")
        
        logger.info("🔄 Creating attestation v2.0...")
        
        # 1. Gera attestation ID temporário
        temp_id = Web3.keccak(
            text=f"{self.address}-{int(time.time())}"
        ).hex()
        
        public_reasoning.attestation_id = temp_id
        
        # 2. Encrypta reasoning privado
        logger.info("🔐 Encrypting private reasoning...")
        encrypted_private = EncryptionEngine.encrypt(
            private_reasoning.to_dict(),
            self.private_key,
            temp_id
        )
        
        # 3. Monta estrutura completa
        full_reasoning = FullReasoning(
            public=public_reasoning,
            private_encrypted=encrypted_private
        )
        
        # 4. Upload para IPFS
        logger.info("📤 Uploading to IPFS...")
        ipfs_cid = self.filebase.upload_json(
            full_reasoning.to_dict(),
            filename=f"reasoning_{temp_id[:8]}.json"
        )
        
        full_reasoning.ipfs_cid = ipfs_cid
        
        # 5. Usa método submit_attestation() existente
        # Converte reasoning para formato compatível
        reasoning_for_submission = json.dumps({
            "ipfs_cid": ipfs_cid,
            "public": public_reasoning.to_dict(),
            "version": "2.0-encrypted"
        })
        
        # Conteúdo público para hash
        content = json.dumps(public_reasoning.to_dict(), sort_keys=True)
        
        # Usa category para metadados ou conclusion
        category = metadata.to_json() if metadata else public_reasoning.conclusion
        
        # Chama método submit_attestation() existente
        result = self.submit_attestation(
            content=content,
            reasoning=reasoning_for_submission,
            category=category,
            wait_for_confirmation=wait_for_confirmation
        )
        
        # Atualiza resultado com dados IPFS
        result.ipfs_cid = ipfs_cid  # type: ignore
        result.ipfs_url = self.filebase.get_url(ipfs_cid)  # type: ignore
        
        logger.info(f"✅ Attestation v2.0 created!")
        logger.info(f"   TX Hash: {result.tx_hash}")
        logger.info(f"   IPFS CID: {ipfs_cid}")
        
        return result
    
    def decrypt_reasoning(
        self,
        attestation_id: str,
        ipfs_cid: Optional[str] = None
    ) -> PrivateReasoning:
        """
        Decripta reasoning de uma attestation
        Só funciona se a wallet atual for a owner
        
        Args:
            attestation_id: ID da attestation
            ipfs_cid: CID do IPFS (se já conhecido)
            
        Returns:
            PrivateReasoning decriptado
        """
        if not self.filebase:
            raise Exception("IPFS storage not configured")
        
        if not ipfs_cid:
            # Buscar IPFS CID do reasoning on-chain
            attestation = self.get_attestation(attestation_id)
            reasoning_data = json.loads(attestation.get("reasoning", "{}"))
            ipfs_cid = reasoning_data.get("ipfs_cid")
            
            if not ipfs_cid:
                raise Exception("IPFS CID not found in attestation")
        
        # Baixa reasoning do IPFS
        logger.info(f"📥 Fetching reasoning from IPFS: {ipfs_cid}")
        full_data = self.filebase.fetch(ipfs_cid)
        
        # Extrai encrypted data
        encrypted_data = EncryptedData(
            nonce=full_data["private_encrypted"]["nonce"],
            ciphertext=full_data["private_encrypted"]["ciphertext"]
        )
        
        # Decripta
        logger.info("🔓 Decrypting private reasoning...")
        decrypted_dict = EncryptionEngine.decrypt(
            encrypted_data,
            self.private_key,
            attestation_id
        )
        
        # Reconstrói DetailedReasoningSteps
        steps = [
            DetailedReasoningStep(**step_data)
            for step_data in decrypted_dict["steps"]
        ]
        
        return PrivateReasoning(
            steps=steps,
            ai_model=decrypted_dict["ai_model"],
            processing_time=decrypted_dict["processing_time"],
            raw_input=decrypted_dict.get("raw_input"),
            additional_metadata=decrypted_dict.get("additional_metadata")
        )

    def get_balance(self) -> float:
        """Retorna o saldo de MATIC da wallet"""
        balance_wei = self.w3.eth.get_balance(self.address)
        return self.w3.from_wei(balance_wei, 'ether')
    
    def get_identity(self, address: Optional[str] = None) -> Optional[Dict]:
        """Busca informaÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Âµes de identidade de um agente"""
        if not self.identity_contract:
            raise ValueError("EndereÃƒÆ’Ã‚Â§o do contrato Identity nÃƒÆ’Ã‚Â£o configurado")
        
        addr = address or self.address
        agent_id = self.identity.functions.agentIdByAddress(addr).call()
        
        if agent_id == 0:
            return None
        
        return {
            "agent_id": agent_id,
            "did": f"did:anna:{addr.lower()}",
            "address": addr
        }


# ============================================================
# HELPER FUNCTIONS
# ============================================================

def create_reasoning(
    input_text: str,
    steps: List[Tuple[str, str]],
    conclusion: str,
    confidence: float
) -> Reasoning:
    """Helper para criar objeto Reasoning facilmente"""
    reasoning_steps = [
        ReasoningStep(i + 1, desc, rat)
        for i, (desc, rat) in enumerate(steps)
    ]
    
    return Reasoning(
        input=input_text,
        reasoning_steps=reasoning_steps,
        conclusion=conclusion,
        confidence=confidence
    )


def create_metadata(
    external_id: str,
    document_type: str,
    **kwargs
) -> Metadata:
    """
    Helper para criar objeto Metadata facilmente
    
    Exemplo:
        metadata = create_metadata(
            external_id="PROC-2024-12345",
            document_type="contrato",
            client_name="JoÃƒÆ’Ã‚Â£o Silva",
            custom_fields={"valor": "R$ 2.500,00"}
        )
    """
    return Metadata(
        external_id=external_id,
        document_type=document_type,
        **kwargs
    )


def calculate_content_hash(content: str) -> str:
    """Calcula hash Keccak256 de um conteÃƒÆ’Ã‚Âºdo"""
    return Web3.keccak(text=content).hex()


# ============================================================
# EXCEÃƒÆ’Ã¢â‚¬Â¡ÃƒÆ’Ã¢â‚¬Â¢ES CUSTOMIZADAS
# ============================================================

class ANNAError(Exception):
    """Erro base do SDK"""
    pass


class IdentityNotFoundError(ANNAError):
    """Agente nÃƒÆ’Ã‚Â£o tem identidade registrada"""
    pass


class AttestationNotFoundError(ANNAError):
    """Attestation nÃƒÆ’Ã‚Â£o encontrada"""
    pass


class VerificationTimeoutError(ANNAError):
    """Timeout aguardando verificaÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o"""
    pass


class MetadataValidationError(ANNAError):
    """Erro na validaÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o de metadados"""
    pass


# ============================================================
# VERSÃƒÆ’Ã†â€™O DO SDK
# ============================================================

__version__ = "2.0.1"
__author__ = "ANNA Protocol Team"
__license__ = "MIT"