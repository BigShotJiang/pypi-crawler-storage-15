=============
Release Notes
=============

-----
0.1.1
-----

Released: 2025-10-02

*  **Bug Fixes**

   *  Remove Python 3.12+ f-string quote reuse (lockss-pybasic is Python 3.9+).

-----
0.1.0
-----

Released: 2025-07-01

Initial release, including:

*  ``cliutil``

*  ``errorutil``

*  ``fileutil``

*  ``outpututil``
