# Claim

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**action** | **str** | Action is the action taken in the space.  e.g. get, list Can be comma separated list or * | [optional] 
**scope** | **str** | Scope is the object space.  e.g. machines Can be comma separated list or * | [optional] 
**specific** | **str** | Specific is the id of the object in the object space.  e.g. machine uuid Can be comma separated list or * | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


