# PoolResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**allocated** | **bool** | Allocated status of the machine | [optional] 
**name** | **str** | Name of the machine | [optional] 
**status** | [**PoolStatus**](PoolStatus.md) |  | [optional] 
**uuid** | **str** | UUID of the machine | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


