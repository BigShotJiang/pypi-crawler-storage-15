# /// script
# requires-python = ">=3.10"
# dependencies = [
#   "requests<3",
# ]
# ///