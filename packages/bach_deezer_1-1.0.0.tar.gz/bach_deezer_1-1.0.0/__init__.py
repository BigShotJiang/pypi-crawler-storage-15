"""MCP Server for Deezer 1"""
