from pathlib import Path

Pathlist = Path | list[Path]
Intlist = int | list[int]
Strbool = str | bool
Strpath = str | Path
Strlist = str | list[str]
Strint = str | int
