import logging

LOGGER = logging.getLogger('uwsgify')
