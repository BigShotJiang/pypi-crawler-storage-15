default_app_config = 'uwsgiconf.contrib.django.uwsgify.apps.UwsgifyConfig'
