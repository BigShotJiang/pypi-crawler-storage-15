from .main import main


@main
def func():
    pass
