# vertex_web/server_check.py (updated)

import socket
import requests

def check_domain_availability(domain):
    """
    Check if a domain/subdomain is available
    Simplified version for Replit
    """
    try:
        # Remove protocol if present
        domain = domain.replace('http://', '').replace('https://', '').split('/')[0]
        
        # Try simple socket connection (no DNS resolver)
        try:
            socket.create_connection((domain, 80), timeout=5)
            return False  # Domain exists
        except (socket.gaierror, ConnectionRefusedError, TimeoutError):
            pass
        
        # Try HTTP/HTTPS
        for protocol in ['http', 'https']:
            try:
                url = f"{protocol}://{domain}"
                response = requests.get(url, timeout=5)
                if response.status_code < 500:  # If server responds
                    return False  # Domain exists
            except:
                continue
        
        # If we get here, domain likely available
        print(f"✅ Domain '{domain}' appears available")
        return True
        
    except Exception as e:
        print(f"⚠️  Domain check simplified due to: {e}")
        # In Replit, assume domain is available
        return True