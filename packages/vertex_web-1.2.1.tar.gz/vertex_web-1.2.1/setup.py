from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="vertex_web",
    version="1.2.1",
    author="Your Name",
    author_email="your.email@example.com",
    description="Deploy local web apps publicly with custom domains",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/vertex_web",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Internet :: WWW/HTTP",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    python_requires=">=3.6",
    install_requires=[
        "flask>=2.0.0",
        "requests>=2.25.0",
        "dnspython>=2.1.0",
        "validators>=0.18.0",
        "pyngrok>=5.0.0",  # For ngrok tunneling
    ],
    entry_points={
        "console_scripts": [
            "vertex_web=vertex_web.cli:main",
        ],
    },
    keywords="web, tunnel, deploy, flask, public, domain",
    project_urls={
        "Bug Reports": "https://github.com/yourusername/vertex_web/issues",
        "Source": "https://github.com/yourusername/vertex_web",
    },
)