# Vertex Web 🌐

Deploy local Flask apps publicly with custom domains in one command!

## Installation
```bash
pip install vertex_web