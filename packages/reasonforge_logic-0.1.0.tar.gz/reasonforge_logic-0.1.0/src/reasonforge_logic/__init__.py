"""ReasonForge Logic - Symbolic AI and Formal Logic
MCP server with 13 tools for logic and knowledge systems."""
__version__ = "0.1.0"
