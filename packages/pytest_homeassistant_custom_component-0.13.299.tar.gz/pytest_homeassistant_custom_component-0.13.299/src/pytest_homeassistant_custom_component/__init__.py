"""
Tests for Home Assistant.

This file is originally from homeassistant/core and modified by pytest-homeassistant-custom-component.
"""
