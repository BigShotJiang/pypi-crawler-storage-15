Release History
===============

0.1.3 (2022-12-08)
------------------

- Fix compatibility with MLFlow v2.0.1 #3

0.1.2 (2020-03-12)
------------------

- Fix compatibility with Comet Python SDK v3.1.1. #2
- Fix support for unicode project notes in Python 2. #1

0.1.1 (2020-02-17)
------------------

-   Fix package URL in metadata.

0.1.0 (2020-02-12)
------------------

-   First release on PyPI.
