========
Contents
========

.. toctree::
   :maxdepth: 2

   readme
   installation
   usage
   reference/index
   contributing
   authors
   changelog
   View on GitHub <https://github.com/BAMresearch/jupyter-analysis-tools>

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
