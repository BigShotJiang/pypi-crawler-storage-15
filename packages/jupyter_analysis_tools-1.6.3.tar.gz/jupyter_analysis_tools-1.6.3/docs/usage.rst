=====
Usage
=====

To use Jupyter Analysis Tools in a project::

	import jupyter_analysis_tools
