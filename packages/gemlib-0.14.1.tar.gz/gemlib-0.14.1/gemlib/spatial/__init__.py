"""Spatial utility functions"""

from .sp_dist import pdist, sparse_pdist

__all__ = ["pdist", "sparse_pdist"]
