"""Experimental MCMC samplers

The samplers contained in this sub-module are experimental.
They are not checked for test coverage.  Use at your own
risk.
"""
