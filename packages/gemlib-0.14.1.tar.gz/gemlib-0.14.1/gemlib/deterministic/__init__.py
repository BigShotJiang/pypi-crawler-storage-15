"""Deterministic model functions

This module provides functions required for deterministic
state transition modelling, such as ordinary differential
equation solvers.  See each module member for detailed documentation.
"""

from gemlib.deterministic.ode_model import ode_model

__all__ = ["ode_model"]
