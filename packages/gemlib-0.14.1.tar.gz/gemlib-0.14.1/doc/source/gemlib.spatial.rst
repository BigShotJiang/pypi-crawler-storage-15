﻿gemlib.spatial
==============

.. automodule:: gemlib.spatial

.. currentmodule:: gemlib.spatial

.. autosummary::
   :toctree: generated/

   pdist
   sparse_pdist
