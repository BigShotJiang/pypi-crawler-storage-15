﻿gemlib.deterministic
====================

.. automodule:: gemlib.deterministic

.. currentmodule:: gemlib.deterministic

.. autosummary::
   :toctree: generated/

   ode_model
