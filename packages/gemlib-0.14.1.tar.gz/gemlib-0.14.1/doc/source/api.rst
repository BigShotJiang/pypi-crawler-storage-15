API reference
=============

.. autosummary::
   :toctree:

   gemlib.deterministic
   gemlib.distributions
   gemlib.mcmc
   gemlib.spatial
   
 
