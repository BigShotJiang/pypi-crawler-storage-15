﻿gemlib.distributions
====================

.. automodule:: gemlib.distributions

Stochastic State transition models
----------------------------------

The state transition model classes are used to implement models in which
individuals are considered to transition between a finite set of mutually-
exclusive states.


.. currentmodule:: gemlib.distributions
		   
.. autosummary::
   :toctree: generated/
   :template: stm_class.rst

   ContinuousTimeStateTransitionModel
   DiscreteTimeStateTransitionModel


   
