# VIASCKDE Index

![PyPI - Version](https://img.shields.io/pypi/v/viasckde.svg)
![PyPI - Downloads](https://img.shields.io/pypi/dm/viasckde.svg)
![License](https://img.shields.io/badge/license-MIT-green.svg)

**VIASCKDE** is a novel internal cluster validity index for arbitrary-shaped clusters based on Kernel Density Estimation (KDE).

---

## Motivation

The VIASCKDE Index was proposed in:

> *"VIASCKDE Index: A Novel Internal Cluster Validity Index for Arbitrary Shaped Clusters Based on Kernel Density Estimation"*  
> by **Ali Şenol**

The index evaluates clustering quality regardless of cluster shape by computing **compactness** and **separation** at the *point level* rather than relying on centroids.

---

## Installation

```bash
pip install viasckde
Usage Example
python
Copy code
from viasckde import viasckde_score

# X: 2D or n-D data array (NumPy-like)
# labels: predicted cluster labels
score = viasckde_score(X, labels)
print("VIASCKDE Score:", score)
Parameters
Parameter	Description
X	Dataset, 
𝑋
=
{
𝑥
1
,
.
.
.
,
𝑥
𝑛
}
∈
𝑅
𝑑
X={x 
1
​
 ,...,x 
n
​
 }∈R 
d
 
labels	Cluster labels (array-like)
kernel	KDE kernel — default: gaussian
bandwidth	KDE bandwidth — default: 0.05

Recommended values:

Kernel: gaussian

Bandwidth: 0.05

Output Range
The VIASCKDE score lies in [-1, +1], where:

+1 → best clustering

-1 → worst clustering

Citation
If you use VIASCKDE in your research, please cite:

Ali Şenol, “VIASCKDE Index: A Novel Internal Cluster Validity Index for Arbitrary-Shaped Clusters Based on the Kernel Density Estimation”,
Computational Intelligence and Neuroscience, vol. 2022, Article ID 4059302, 20 pages, 2022.
https://doi.org/10.1155/2022/4059302

BibTeX
bibtex
Copy code
@article{csenol2022viasckde,
  title={VIASCKDE Index: A Novel Internal Cluster Validity Index for Arbitrary-Shaped Clusters Based on the Kernel Density Estimation},
  author={{\c{S}}enol, Ali},
  journal={Computational Intelligence and Neuroscience},
  volume={2022},
  number={1},
  pages={4059302},
  year={2022},
  publisher={Wiley Online Library}
}
License & Author
Author: Assoc. Prof. Dr. Ali Şenol
Computer Engineering Department, Tarsus University

License: MIT