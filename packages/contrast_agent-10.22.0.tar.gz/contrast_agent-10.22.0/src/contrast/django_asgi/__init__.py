# Copyright © 2025 Contrast Security, Inc.
# See https://www.contrastsecurity.com/enduser-terms-0317a for more details.
from .middleware import DjangoASGIMiddleware as ContrastMiddleware  # noqa
