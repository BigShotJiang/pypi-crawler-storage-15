from imports import *
# Build DATABASE_URL from env vars
env_vars = [
    "ABSTRACT_DATABASE_USER",
    "ABSTRACT_DATABASE_PORT",
    "ABSTRACT_DATABASE_DBNAME",
    "ABSTRACT_DATABASE_HOST",
    "ABSTRACT_DATABASE_PASSWORD",
]

input(get_env_path("ABSTRACT_DATABASE_USER"))
def safe_get_env(key):
    val = get_env_value(key)
    return val if val is not None else ""
engine=None
metadta=None
VIDEOSTABLE=None

env_js = {v.split("_")[-1]: safe_get_env(v) for v in env_vars}
env_js["HOST"] = env_js.get("HOST") or "23.126.105.154"

DATABASE_URL = (
    f"postgresql://{env_js['USER']}:{env_js['PASSWORD']}@"
    f"{env_js['HOST']}:{env_js['PORT']}/{env_js['DBNAME']}"
)
input(DATABASE_URL)
video_url = "https://www.youtube.com/watch?v=mIMMZQJ1H6E&list=RDmIMMZQJ1H6E&start_radio=https://www.youtube.com/watch?v=SeqaTKZOCRs"
result = get_pipeline_data(video_url)
input(result)
