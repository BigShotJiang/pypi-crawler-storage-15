from ..imports import *
from .routes import *
def get_text(
    *args,
    text=None,
    url=None,
    file_path=None,
    audio_path=None,
    video_url=None,
    video_path=None,
    video_id=None,
    data_url=None,
    **kwargs
):
    # 1. Explicit text
    if text:
        if video_id:
            db_upsert(video_id, {"text": text})
        return text

    # 2. Audio/video → whisper
    if audio_path or video_url or video_path:
        text = get_whisper_text(
            *args,
            audio_path=audio_path,
            video_url=video_url,
            video_path=video_path,
            **kwargs
        )
        if video_id and text:
            db_upsert(video_id, {"whisper": {"text": text}})
        return text

    # 3. URL / file ingestion
    if url or file_path:
        filename = None
        if file_path:
            basename = os.path.basename(file_path)
            filename, ext = os.path.splitext(basename)
        else:
            domain = urlManager(url).domain
            logger.info(domain)
            filename, ext = os.path.splitext(domain)
            basename = f"{filename}.json"

        save_file = os.path.join(DEFAULT_DOCUMENTS_ROOT, basename)
        text = get_soup_text(url) or read_file_as_text(file_path)

        # Mirror in registry as cache
        info = get_infoRegistry().add_file(
            file_path=file_path or save_file,
            url=url,
            video_id=video_id,
            data_url=data_url
        )
        safe_dump_to_file(data={filename: text}, file_path=save_file)

        # DB as single source of truth
        if video_id and text:
            db_upsert(video_id, {"info": info, "text": text})

        if text and info.get("text_path"):
            write_to_file(info["text_path"], text)
        return text

    # 4. Last chance → DB only
    if video_id:
        rec = db_get(video_id)
        if rec and rec.info:
            return rec.info.get("text")

    return None
MODULE_DEFAULTS = {
    "whisper": {
        "path": "/mnt/24T/hugging_face/modules/whisper_base",
        "id": "openai/whisper-base",
        "name":"whisper"
    },
    "keybert": {
        "path": "/mnt/24T/hugging_face/modules/all_minilm_l6_v2",
        "id": "sentence-transformers/all-MiniLM-L6-v2",
        "name": "keybert"
    },
    "summarizer": {
        "path": "/mnt/24T/hugging_face/modules/text_summarization",
        "id": "Falconsai/text_summarization",
        "name": "summarizer"
    },
    "flan": {
        "path": "/mnt/24T/hugging_face/modules/flan_t5_xl",
        "id": "google/flan-t5-xl",
        "name": "flan"
    },
    "bigbird": {
        "path": "/mnt/24T/hugging_face/modules/led_large_16384",
        "id": "allenai/led-large-16384",
        "name": "bigbird"
    },
    "deepcoder": {
        "path": "/mnt/24T/hugging_face/modules/DeepCoder-14B",
        "id": "agentica-org/DeepCoder-14B-Preview",
        "name": "deepcoder"
    },
    "huggingface": {
        "path": "/mnt/24T/hugging_face/modules/hugging_face_models",
        "id": "huggingface/hub",
        "name": "hugging_face_models"
    },
    "zerosearch": {
        "path": "/mnt/24T/hugging_face/modules/ZeroSearch_dataset",
        "id": "ZeroSearch/dataset",
        "name": "ZeroSearch"
    }
}
DEFAULT_PATHS = {
    "whisper": MODULE_DEFAULTS.get("whisper"),
    "keybert": MODULE_DEFAULTS.get("keybert"),
    "summarizer": MODULE_DEFAULTS.get("summarizer"),
    "flan": MODULE_DEFAULTS.get("flan"),
    "bigbird": MODULE_DEFAULTS.get("bigbird"),
    "deepcoder": MODULE_DEFAULTS.get("deepcoder"),
    "huggingface": MODULE_DEFAULTS.get("huggingface"),
    "zerosearch": MODULE_DEFAULTS.get("zerosearch")
}
