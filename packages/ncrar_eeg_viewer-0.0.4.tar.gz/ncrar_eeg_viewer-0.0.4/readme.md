EEG plotter for Biosemi data collected at the NCRAR
