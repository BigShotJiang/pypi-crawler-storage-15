from .jobs import JobsResource
from .backends import BackendsResource

__all__ = [
    "JobsResource",
    "BackendsResource",
]
