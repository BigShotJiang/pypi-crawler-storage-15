2025-06-12 Version: 3.1.15
- Generated python 2019-11-11 for clickhouse.

2025-06-11 Version: 3.1.14
- Update API DescribeDBClusterAttribute: add response parameters Body.DBCluster.AppointmentElectZookeeperDisableWrite.
- Update API DescribeDBClusterAttribute: add response parameters Body.DBCluster.AppointmentElectZookeeperTime.
- Update API DescribeDBClusterAttribute: add response parameters Body.DBCluster.AppointmentRestartNodeList.
- Update API DescribeDBClusterAttribute: add response parameters Body.DBCluster.AppointmentRestartNodeTime.


2025-02-07 Version: 3.1.13
- Update API DescribeTransferHistory: update response param.
- Update API TransferVersion: add param SourceClusterName.
- Update API TransferVersion: add param SourceShards.


2024-10-11 Version: 3.1.12
- Update API DescribeDBClusters: update response param.
- Update API ModifyDBCluster: add param DisableWriteWindows.
- Update API ModifyDBCluster: update param ResourceOwnerId.


2024-08-12 Version: 3.1.11
- Update API DescribeDBClusters: update response param.
- Update API DescribeTransferHistory: update response param.
- Update API TransferVersion: add param DisableWriteWindows.


2024-05-20 Version: 3.1.10
- Update API CreateDBInstance: add param AutoRenew.
- Update API DescribeDBClusterAttribute: update response param.
- Update API ModifyDBCluster: update param DBClusterId.


2024-02-21 Version: 3.1.9
- Update API CreateDBInstance: add param AutoRenew.


2024-02-04 Version: 3.1.8
- Update API CreateDBInstanceupdate VSwitchBak param.
update VSwitchBak2 param.
- Update API ModifyDBClusteradd DbNodeStorageType param.
update DBClusterId param.


2023-12-25 Version: 3.1.7
- Generated python 2019-11-11 for clickhouse.

2023-12-08 Version: 3.1.6
- Generated python 2019-11-11 for clickhouse.

2023-11-07 Version: 3.1.5
- Generated python 2019-11-11 for clickhouse.

2022-04-06 Version: 3.1.4
- Clickhouse add restore.

2022-03-24 Version: 3.1.3
- Clickhouse add restore.

2022-03-23 Version: 3.1.2
- Clickhouse add restore.

2022-03-03 Version: 3.1.1
- Clickhouse modify return parameter for describeAttributed.

2022-01-19 Version: 3.1.0
- Clickhouse go sdk.

2021-11-26 Version: 2.1.0
- For test.

2021-05-31 Version: 2.0.2
- For test.

2021-04-23 Version: 2.0.1
- For test.

