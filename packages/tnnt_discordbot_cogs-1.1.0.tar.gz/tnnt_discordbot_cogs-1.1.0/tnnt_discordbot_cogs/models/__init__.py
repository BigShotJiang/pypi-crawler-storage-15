"""
Initialization file for the models package.
"""

# flake8: noqa

# Terra Nanotech Discordbot Cogs
from tnnt_discordbot_cogs.models import permission, setting
