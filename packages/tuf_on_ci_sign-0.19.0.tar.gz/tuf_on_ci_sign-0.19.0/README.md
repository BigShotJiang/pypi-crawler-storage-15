### TUF-on-CI Signing tools

This package contains the signing tools for
[TUF-on-CI](https://github.com/theupdateframework/tuf-on-ci). Please see
TUF-on-CI README for usage.
