#!/bin/sh
curl -O http://www.unicode.org/Public/UNIDATA/UnicodeData.txt
curl -O http://www.unicode.org/Public/UNIDATA/Blocks.txt
curl -O http://www.unicode.org/Public/UNIDATA/Scripts.txt
curl -O https://raw.githubusercontent.com/adobe-type-tools/agl-aglfn/master/aglfn.txt
