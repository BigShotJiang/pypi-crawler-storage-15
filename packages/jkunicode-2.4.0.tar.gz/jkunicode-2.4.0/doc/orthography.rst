Orthography Information
=======================

The Unicode CLDR data has three categories of character support for each orthography: basic, optional, and punctuation.

.. automodule:: jkUnicode.orthography
   :members:
