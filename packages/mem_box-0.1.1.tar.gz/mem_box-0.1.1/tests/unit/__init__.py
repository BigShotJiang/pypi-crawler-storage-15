"""Unit tests for Memory Box."""
