"""Integration tests for Memory Box."""
