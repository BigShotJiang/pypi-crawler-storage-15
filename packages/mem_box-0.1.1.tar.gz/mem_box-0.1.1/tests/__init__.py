"""Tests for Memory Box."""
