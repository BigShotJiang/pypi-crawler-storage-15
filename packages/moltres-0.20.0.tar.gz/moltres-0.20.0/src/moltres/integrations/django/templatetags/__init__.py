"""Django template tags for Moltres."""
