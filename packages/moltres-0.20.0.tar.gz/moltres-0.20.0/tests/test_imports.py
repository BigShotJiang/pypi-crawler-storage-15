"""Basic smoke tests for the scaffolding stage."""


def test_can_import_package():
    import moltres  # noqa: F401
