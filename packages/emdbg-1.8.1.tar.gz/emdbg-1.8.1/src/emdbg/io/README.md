# Input/Output Devices

This module provides scriptable access to digital and analog Input/Output (IO)
devices, such as logic analyzers and waveform generators.
These may also be custom devices that perform specific tasks.

