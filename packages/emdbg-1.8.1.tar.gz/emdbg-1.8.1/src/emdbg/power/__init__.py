# Copyright (c) 2023, Auterion AG
# SPDX-License-Identifier: BSD-3-Clause

"""
.. include:: README.md
"""

from .yocto import relay as yocto_relay
