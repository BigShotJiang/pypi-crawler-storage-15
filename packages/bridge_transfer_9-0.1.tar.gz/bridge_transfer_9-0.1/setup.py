
from setuptools import setup
setup(
    name="bridge_transfer_9",
    version="0.1", 
    py_modules=["carrier"],
)
