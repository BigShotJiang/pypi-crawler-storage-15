# CapInvest Index Extension

The Index extension provides global and european index data access for the CapInvest Platform.

 


