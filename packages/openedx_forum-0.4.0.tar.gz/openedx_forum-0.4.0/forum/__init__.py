"""
Openedx forum app.
"""

__version__ = "0.4.0"
