import requests
from django.http import JsonResponse
from django.conf import settings

class AgentGateMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response
        
        # CONFIGURATION
        self.bank_url = getattr(settings, 'AGENT_GATE_BANK_URL', 'http://127.0.0.1:8000')
        self.price = getattr(settings, 'AGENT_GATE_PRICE', 1) 
        
        # YOUR IDENTITY (The Merchant)
        self.api_key = getattr(settings, 'AGENT_GATE_API_KEY', None)

        # LIST OF BOTS TO CHARGE
        # Defaults to common AI scrapers. Can be overridden in settings.py.
        self.paid_bots = getattr(settings, 'AGENT_GATE_PAID_BOTS', [
            'GPTBot',        # OpenAI
            'ClaudeBot',     # Anthropic
            'CCBot',         # Common Crawl
            'Google-Extended', # Google Gemini training data
            'FacebookBot',   # Meta Llama
            'Bytespider',    # ByteDance
            'Amazonbot',     # Amazon
        ])

        if not self.api_key:
            print("WARNING: Agent Gate is missing AGENT_GATE_API_KEY. You won't get paid for these requests!")

    def __call__(self, request):
        # 1. DETECT USER AGENT (Bot vs Human)
        user_agent = request.headers.get('User-Agent', '').lower()
        
        is_ai_agent = False
        for bot in self.paid_bots:
            if bot.lower() in user_agent:
                is_ai_agent = True
                break
        
        # 2. IF HUMAN, LET THEM PASS (FREE)
        if not is_ai_agent:
            return self.get_response(request)

        # =========================================================
        # IF WE REACH HERE, IT IS A PAID BOT. CHARGE THEM.
        # =========================================================

        # 3. CHECK FOR VISITOR KEY (The Customer)
        visitor_key = request.headers.get("X-Api-Key")
        
        if not visitor_key:
            return JsonResponse({
                "error": "AI Agent Detected. Payment Required.",
                "message": f"This content is free for humans but paid for {user_agent}.",
                "portal_url": f"{self.bank_url}"
            }, status=401)

        # 4. EXECUTE TRANSFER (Call the Bank)
        try:
            response = requests.post(
                f"{self.bank_url}/api/spend/",
                json={'amount': self.price},
                headers={
                    'X-Customer-Key': visitor_key, # Who pays
                    'X-Merchant-Key': self.api_key # Who gets paid (YOU)
                },
                timeout=3.0
            )
            
            if response.status_code == 200:
                # Success! Payment accepted.
                return self.get_response(request)
            
            elif response.status_code == 402:
                # Insufficient Funds
                data = response.json()
                return JsonResponse({
                    "error": "Insufficient Credits",
                    "balance": data.get('balance'),
                    "top_up_url": data.get('portal_url')
                }, status=402)
                
            else:
                return JsonResponse({"error": "Payment Bank Error"}, status=502)

        except requests.exceptions.RequestException:
             return JsonResponse({"error": "Payment System Unavailable"}, status=503)