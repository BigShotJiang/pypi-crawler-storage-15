# RLIB – AI Helper Library

RLIB is a lightweight Python library that provides helper functions
for AI-related tasks such as generating responses, summarizing text,
and formatting outputs.

## Installation

```bash
pip install RLIB
