import sys
sys.path.append(".")         # can find version in . by pytest
sys.path.append("./flashcam")  # can find version from Jupyter
#from version import __version__
# try:
#     from flashcam.version import __version__
# except:
#    print("")
