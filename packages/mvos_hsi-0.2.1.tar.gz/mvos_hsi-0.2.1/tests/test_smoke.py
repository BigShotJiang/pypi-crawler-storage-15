def test_import():
    import mvos_hsi
