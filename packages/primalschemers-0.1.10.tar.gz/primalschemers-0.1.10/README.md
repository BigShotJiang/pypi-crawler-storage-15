# PrimalSchemers

This is the rust library for digestion and thermo calculations for PrimalScheme3. This is not a standalone tool.


