---
name: foobar
---
# Examples

{{data}}
