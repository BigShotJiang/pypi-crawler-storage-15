from .output import Output as Output

from .residual_output import ResidualOutput as ResidualOutput
