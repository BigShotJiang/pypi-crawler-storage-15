# Copyright 2023 Luminary Cloud, Inc. All Rights Reserved.
from setuptools import setup

if __name__ == "__main__":
    setup()
