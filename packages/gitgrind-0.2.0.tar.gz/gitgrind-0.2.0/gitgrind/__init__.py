"""
gitgrind

a tool to search the far reaches of git repositories for data
"""

__version__ = "0.1.0"
__author__ = 'Kurt Godwin'
