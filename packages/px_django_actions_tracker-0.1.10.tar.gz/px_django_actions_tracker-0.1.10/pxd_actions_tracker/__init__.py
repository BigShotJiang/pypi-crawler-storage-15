__version__ = '0.1.10'

VERSION = tuple(__version__.split('.'))
