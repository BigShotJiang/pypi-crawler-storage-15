"""Testing infrastructure for OmniMCP."""
