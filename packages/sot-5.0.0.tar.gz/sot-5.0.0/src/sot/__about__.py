from datetime import datetime

__version__ = "5.0.0"
__current_year__ = datetime.now().year
