"""Disk TUI subcommand for SOT."""
