"""
WEAC - Weak Layer Anticrack Nucleation Model
"""

__version__ = "3.0.2"
