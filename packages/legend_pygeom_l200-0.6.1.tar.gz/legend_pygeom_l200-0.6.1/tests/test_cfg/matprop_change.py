from __future__ import annotations

from pygeomoptics.tpb import tpb_refractive_index

tpb_refractive_index.replace_implementation(lambda: 1234)
