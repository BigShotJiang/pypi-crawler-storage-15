  - [NextERP Romania](https://www.nexterp.ro):
      - Fekete Mihai \<<feketemihai@nexterp.ro>\>
      - Alexandru Teodor \<<teodoralexandru@nexterp.ro>\>
  - [Terrabit](https://www.terrabit.ro):
      - Dorin Hongu \<<dhongu@gmail.com>\>

Do not contact contributors directly about support or help with
technical issues.
