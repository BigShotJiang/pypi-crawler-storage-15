"""
threefive.version
from the cli tool run: threefive version
"""

MAJOR = 3
MINOR = 0
MINI = 65

version = f"{MAJOR}.{MINOR}.{MINI}"
