from rest_framework.routers import DefaultRouter

rest_router = DefaultRouter(trailing_slash=False)
singleton_urls = []
