default_app_config = "headless.rest.apps.DjangoHeadlessRestConfig"
