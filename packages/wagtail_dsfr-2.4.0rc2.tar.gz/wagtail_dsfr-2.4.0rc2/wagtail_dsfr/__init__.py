default_app_config = "wagtail_dsfr.apps.WagtailDsfrAppConfig"
