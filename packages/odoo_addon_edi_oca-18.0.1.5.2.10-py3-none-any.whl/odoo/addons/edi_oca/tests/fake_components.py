# ruff: noqa: F401
from odoo.addons.edi_component_oca.tests.fake_components import (
    FakeComponentMixin,
    FakeConfigurationListener,
    FakeInputProcess,
    FakeInputReceive,
    FakeInputValidate,
    FakeOutputChecker,
    FakeOutputGenerator,
    FakeOutputSender,
    FakeOutputValidate,
)
