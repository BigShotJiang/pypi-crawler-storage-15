from cg.meta.workflow.microsalt.quality_controller.quality_controller import (
    MicroSALTQualityController,
)
