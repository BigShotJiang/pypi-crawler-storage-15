"""Tests for myosdk."""
