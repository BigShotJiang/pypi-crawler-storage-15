"""Unit tests for merging module."""
