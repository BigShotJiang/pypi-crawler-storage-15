# TODO: use numba
