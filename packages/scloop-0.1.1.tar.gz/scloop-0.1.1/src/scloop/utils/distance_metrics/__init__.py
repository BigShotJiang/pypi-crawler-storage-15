from .frechet import compute_loop_frechet
