from x import a.
from x import a.b
from x import a, b.c, d, e.f, g
