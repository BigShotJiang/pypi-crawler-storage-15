# parse_options: {"target-version": "3.13"}
t"{hey}"
t'{there}'
t"""what's
happening?"""
