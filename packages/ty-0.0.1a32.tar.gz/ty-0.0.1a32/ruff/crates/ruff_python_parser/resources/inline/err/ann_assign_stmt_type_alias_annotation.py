a: type X = int
lambda: type X = int
