zip((x for x in range(10)), (y for y in range(10)))
sum(x for x in range(10))
sum((x for x in range(10)),)
