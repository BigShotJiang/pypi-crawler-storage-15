# parse_options: {"target-version": "3.12"}
f"{1:""}"  # this is a ParseError on all versions
