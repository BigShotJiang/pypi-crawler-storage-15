[(a := 0) for a in range(0)]
{(a := 0) for a in range(0)}
{(a := 0): val for a in range(0)}
{key: (a := 0) for a in range(0)}
((a := 0) for a in range(0))
[[(a := 0)] for a in range(0)]
[(a := 0) for b in range (0) for a in range(0)]
[(a := 0) for a in range (0) for b in range(0)]
[((a := 0), (b := 1)) for a in range (0) for b in range(0)]
