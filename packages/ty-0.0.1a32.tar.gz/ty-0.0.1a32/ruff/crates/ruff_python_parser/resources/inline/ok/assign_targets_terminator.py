x = y = z = 1; a, b
x = y = z = 1
a, b
