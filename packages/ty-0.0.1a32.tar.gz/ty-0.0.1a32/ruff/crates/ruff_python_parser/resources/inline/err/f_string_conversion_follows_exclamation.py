f"{x! s}"
t"{x! s}"
f"{x! z}"
