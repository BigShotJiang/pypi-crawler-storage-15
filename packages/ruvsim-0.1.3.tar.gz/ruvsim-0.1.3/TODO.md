# TODO — ModelSim CLI API

1. find command w/ nets [X]
2. getting drivers [X]
3. examine cmd [X]
4. run cmd [X]
5. dataset commands []
6. add dataflow|memory|watch []
7. breakpoints (bp, step, disablebp, enablebp) []
8. classinfo commands []
9. rest of find commands (infiles, insource)
10. force command []
11. mem commands []
12. radix commands []
13. restart command []
14. resume command []
15. simstats commands []
16. virtual commands []

