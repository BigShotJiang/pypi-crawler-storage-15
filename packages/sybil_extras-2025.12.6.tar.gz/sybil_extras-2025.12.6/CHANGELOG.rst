Changelog
=========

Next
----

2025.12.06
----------

* Add ``AttributeGroupedSourceParser`` for grouping MDX code blocks by attribute values (e.g., ``group="example1"``), following Docusaurus conventions.

2025.12.05.1
------------

2025.12.05
----------

2025.12.04.1
------------

* Add MDX markup language support (code blocks with attributes, custom skips, and grouping helpers).

2025.12.04
----------

* Add ``BlockAccumulatorEvaluator``.
* Add ``languages`` module with ``MarkupLanguage`` dataclass and predefined instances (``MYST``, ``RESTRUCTUREDTEXT``, ``MARKDOWN``).

2025.11.19
----------

2025.11.08
----------

2025.04.07
----------

2025.04.03
----------

* Add ``NoOpEvaluator``.
* Support Python 3.10.

2025.03.27
----------

* Rename ``GroupedCodeBlockParser`` to ``GroupedSourceParser``.

2025.02.27.1
------------

* Add option in ``GroupedCodeBlockParser`` to not pad the groups.

2025.02.25
----------

* Support unescaped directives for ``GroupedCodeBlockParser``.

2025.02.19
----------

* Use the custom skip directive's directive name in parsing errors.

2025.02.18.1
------------

2025.02.18
----------

* Re-add support for Python 3.10.

2025.02.16.1
------------

2025.02.16
----------

* Drop support for Python 3.10.
* Add ``GroupedCodeBlockParser`` for parsing groups of code blocks.

2025.01.11
----------

2024.12.26
----------
