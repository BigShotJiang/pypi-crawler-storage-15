"""
Unit tests for friTap Python components.

These tests focus on testing individual functions and classes
in isolation with mocked dependencies.
"""