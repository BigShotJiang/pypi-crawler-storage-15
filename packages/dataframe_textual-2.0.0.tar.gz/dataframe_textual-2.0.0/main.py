#!/usr/bin/env python
"""Entry point for DataFrameViewer."""

from dataframe_textual.__main__ import main

if __name__ == "__main__":
    main()
