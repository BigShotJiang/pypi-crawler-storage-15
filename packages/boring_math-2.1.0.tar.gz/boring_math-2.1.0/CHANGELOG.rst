CHANGELOG
=========

Daddy's boring math library
---------------------------

Changelog moved: CHANGELOG.rst -> CHANGELOG.md
