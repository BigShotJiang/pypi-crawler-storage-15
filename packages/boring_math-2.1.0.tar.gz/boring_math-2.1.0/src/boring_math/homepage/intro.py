"""
Daddy's Boring Math Projects
============================

A collection of the my mathematical hobby projects.

The name "Daddy's Boring Math Library" was suggested by my then
13 year old daughter Mary.

"""
