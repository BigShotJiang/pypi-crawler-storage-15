"""
The overall effort's name is
`Boring Math <https://pypi.org/project/boring-math/>`_.

- It is a collection of my mathematical hobby projects.
- Each project's name begins with *"boring-math-"* on PyPI and GitHub.
- Each project implements a top-level package in the ``boring_math`` Python namespace.
- Here are all the Boring Math projects on `PyPI and GitHub
  <https://github.com/grscheller/boring-math/blob/main/README.md>`_.

"""
