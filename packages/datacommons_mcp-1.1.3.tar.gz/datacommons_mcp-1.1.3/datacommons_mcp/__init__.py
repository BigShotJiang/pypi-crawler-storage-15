"""
DataCommons MCP Server Package
"""

from .version import __version__  # noqa: F401
