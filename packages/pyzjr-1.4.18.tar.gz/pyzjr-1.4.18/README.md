# pyzjr

<h1 align="center">
<img src="https://github.com/Auorui/AI-Learning-Materials/blob/main/webbg/%E5%86%B0%E7%BA%A2%E8%8C%B6.png" width="300">
</h1><br>

[![Downloads](https://static.pepy.tech/badge/pyzjr)](https://pepy.tech/project/pyzjr)
[![Downloads](https://static.pepy.tech/badge/pyzjr/month)](https://pepy.tech/project/pyzjr)
[![Downloads](https://static.pepy.tech/badge/pyzjr/week)](https://pepy.tech/project/pyzjr)

This is a package that has been patched for excellent third-party libraries such as opencv and pytorch.

All useful functional functions written by individuals

I will also integrate algorithms I have previously written

## Installation

https://pypi.org/project/pyzjr/

https://github.com/Auorui/pyzjr (I want stars ⭐ hhh)

https://www.writebug.com/code/ae41e81c-adef-11ee-830a-0242ac140019/#

## Update log
`1.4.0` This will be a new version, which has removed many useless functions and reassigned each function appropriately.

## Note
I have taken the postgraduate entrance examination, and if I can pass this year, I will continue to deepen my knowledge in this field



