# Project Map: pdfsmith

*Generated: 2025-11-26*

## Quick Overview

- **Type**: Python Library (PDF processing)
- **Purpose**: Unified API for 15 PDF-to-Markdown backends
- **Primary Language**: Python 3.10+
- **Build Tool**: Hatch
- **Package Manager**: uv
- **License**: MIT

## Architecture

### Design Pattern: Strategy Pattern with Lazy Loading

```
pdfsmith/
├── api.py          # Public API: parse(), parse_async(), available_backends()
├── cli.py          # CLI: pdfsmith parse, pdfsmith backends
├── config.py       # Configuration loading (YAML-based)
└── backends/
    ├── registry.py # BackendInfo + BACKEND_REGISTRY (lazy loading)
    └── *_backend.py # Individual backend implementations
```

### Key Design Decisions

1. **Lazy Loading**: Backends only imported when used (via `loader` callables)
2. **Backend Registry**: Central `BACKEND_REGISTRY` dict maps names to `BackendInfo`
3. **Auto-Selection**: `DEFAULT_PREFERENCE` list orders backends by quality
4. **Weight Categories**: light, medium, heavy, commercial
5. **Zero Dependencies**: Core package has no deps; backends installed as extras

## Directory Structure

### Source Code (`src/pdfsmith/`)
- `__init__.py` - Public exports: parse, parse_async, available_backends, get_backend
- `api.py` - Core API implementation with backend auto-selection
- `cli.py` - argparse-based CLI with `parse` and `backends` subcommands
- `config.py` - YAML config loader for backend options

### Backends (`src/pdfsmith/backends/`)

**Open Source - Light (6)**:
- `pypdf_backend.py` - Pure Python, lightweight
- `pdfplumber_backend.py` - Excellent for tables
- `pymupdf_backend.py` - Fast MuPDF bindings
- `pdfminer_backend.py` - Mature text extraction
- `pypdfium2_backend.py` - Chrome's PDF engine

**Open Source - Medium (4)**:
- `pymupdf4llm_backend.py` - LLM-optimized output
- `unstructured_backend.py` - Document processing
- `kreuzberg_backend.py` - Rust-based with OCR
- `extractous_backend.py` - Rust extraction

**Open Source - Heavy (2)**:
- `docling_backend.py` - IBM's deep learning (best quality)
- `marker_backend.py` - Academic papers/LaTeX

**Commercial (4)**:
- `aws_textract_backend.py` - AWS OCR service
- `azure_document_intelligence_backend.py` - Azure AI
- `google_document_ai_backend.py` - Google Cloud
- `databricks_backend.py` - SQL warehouse integration

### Configuration (`config/`)
YAML files for backend-specific options:
- `docling.yaml`, `kreuzberg.yaml`, `marker.yaml`
- `pdfplumber.yaml`, `pymupdf4llm.yaml`, `unstructured.yaml`

### Tests (`tests/`)
- `test_api.py` - Core API tests
- `test_backends.py` - Backend implementation tests
- `test_commercial_backends.py` - Commercial backend mocks
- `integration/` - Full integration tests with credentials

## Key Files

| File | Purpose |
|------|---------|
| `src/pdfsmith/api.py:82-109` | Main `parse()` function |
| `src/pdfsmith/api.py:112-139` | Async `parse_async()` function |
| `src/pdfsmith/backends/registry.py:48-55` | `BaseBackend` interface |
| `src/pdfsmith/backends/registry.py:136-243` | `BACKEND_REGISTRY` definition |

## API Surface

### Public Functions

```python
# Main parsing function
def parse(pdf_path: str | Path, *, backend: str | None = None) -> str

# Async variant
async def parse_async(pdf_path: str | Path, *, backend: str | None = None) -> str

# List available backends
def available_backends() -> list[BackendInfo]

# Get specific backend instance
def get_backend(name: str | None = None) -> BaseBackend
```

### BackendInfo Dataclass

```python
@dataclass
class BackendInfo:
    name: str           # Backend identifier
    description: str    # Human-readable description
    package: str        # PyPI package name
    weight: str         # "light" | "medium" | "heavy" | "commercial"
    loader: Callable    # Lazy loader function

    def is_available() -> bool    # Check if installed
    def get_instance() -> Backend # Get singleton instance
```

## Development Workflow

### Commands
```bash
# Install with dev dependencies
uv pip install -e ".[dev,recommended]"

# Run tests
pytest

# Type checking
mypy src/pdfsmith

# Linting
ruff check src tests
ruff format src tests

# Pre-commit hooks
pre-commit run --all-files
```

### Adding a New Backend

1. Create `src/pdfsmith/backends/{name}_backend.py`
2. Implement `class {Name}Backend(BaseBackend)` with `parse()` method
3. Add `_load_{name}()` function in `registry.py`
4. Add entry to `BACKEND_REGISTRY` dict
5. Add optional dependency in `pyproject.toml`
6. Update `DEFAULT_PREFERENCE` if open-source

## Patterns & Conventions

- **Backend Interface**: All backends extend `BaseBackend` with `parse(pdf_path) -> str`
- **Availability Check**: Use `AVAILABLE` module constant for import checks
- **Error Handling**: Raise `ImportError` for missing deps, propagate backend errors
- **Async Support**: Optional `parse_async()` method, fallback to executor
- **Configuration**: YAML files in `config/` loaded by backend if needed

## Current Work in Progress

Based on git status, active development includes:
- Commercial backends implementation (AWS, Azure, Google, Databricks)
- Configuration system (`src/pdfsmith/config.py`)
- Backend registry updates for commercial services
- Documentation updates for commercial backends
