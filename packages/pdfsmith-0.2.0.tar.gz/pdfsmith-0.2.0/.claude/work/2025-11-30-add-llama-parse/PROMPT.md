# Add LlamaParse Backend to pdfsmith

## Overview

Add LlamaParse as a commercial backend to pdfsmith. LlamaParse is LlamaIndex's GenAI-native document parsing cloud service that uses LLMs to convert PDFs to markdown.

## API Key for Testing

```
LLAMA_CLOUD_API_KEY=llx-cmXWGDEyfiwugS6DOyVHBkAPwhaesbYTe6hUOMYucZVRTozZ
```

Free tier: 1,000 pages/day, 7,000 pages/week - sufficient for integration tests.

## LlamaParse Details

**Package**: `llama-parse` (PyPI)
**Docs**: https://docs.llamaindex.ai/en/stable/llama_cloud/llama_parse/
**API Key Portal**: https://cloud.llamaindex.ai/api-key

**Pricing (credits per page)**:
- Basic (no AI): 1 credit = $0.001/page
- Cost-effective: 3 credits = $0.003/page (recommended default)
- Agentic: 10 credits = $0.01/page
- Premium: 90 credits = $0.09/page

**API Limits**:
- Max file size: 100 MB
- Concurrent requests vary by plan

## Implementation Requirements

### 1. Create Backend File

Create `src/pdfsmith/backends/llamaparse_backend.py` following the existing pattern:

```python
"""LlamaParse backend for pdfsmith.

LlamaParse is LlamaIndex's GenAI-native document parsing service using LLMs.

Requirements:
    - llama-parse

Configuration:
    Set LLAMA_CLOUD_API_KEY environment variable.
    Get your key from: https://cloud.llamaindex.ai/api-key

Cost: $0.003 per page (cost-effective mode, default)
Free tier: 1,000 pages/day, 7,000 pages/week
"""

from pathlib import Path
import os

try:
    from llama_parse import LlamaParse
    AVAILABLE = True
except ImportError:
    AVAILABLE = False

from pdfsmith.backends.registry import BaseBackend


class LlamaParseBackend(BaseBackend):
    """LlamaParse backend for pdfsmith."""

    name = "llamaparse"

    def __init__(self, parsing_mode: str = "cost_effective") -> None:
        """Initialize LlamaParse backend.

        Args:
            parsing_mode: One of 'fast', 'cost_effective', 'agentic', 'premium'
        """
        if not AVAILABLE:
            raise ImportError(
                "llama-parse is required. Install with: pip install llama-parse"
            )

        api_key = os.getenv("LLAMA_CLOUD_API_KEY")
        if not api_key:
            raise ValueError(
                "LLAMA_CLOUD_API_KEY environment variable must be set. "
                "Get your key from https://cloud.llamaindex.ai/api-key"
            )

        self.client = LlamaParse(
            api_key=api_key,
            result_type="markdown",
            verbose=False,
        )

    def parse(self, pdf_path: Path) -> str:
        """Parse PDF to markdown using LlamaParse.

        Args:
            pdf_path: Path to PDF file

        Returns:
            Markdown text
        """
        if not pdf_path.exists():
            raise FileNotFoundError(f"PDF not found: {pdf_path}")

        # LlamaParse returns list of Document objects
        documents = self.client.load_data(str(pdf_path))

        # Combine document texts
        parts = []
        for doc in documents:
            if hasattr(doc, "text") and doc.text:
                parts.append(doc.text.strip())
            elif hasattr(doc, "content") and doc.content:
                parts.append(doc.content.strip())

        if not parts:
            return ""

        return "\n\n".join(parts)
```

### 2. Update Registry

In `src/pdfsmith/backends/registry.py`:

1. Add loader function:
```python
def _load_llamaparse():
    from pdfsmith.backends.llamaparse_backend import LlamaParseBackend
    return LlamaParseBackend
```

2. Add to BACKEND_REGISTRY:
```python
"llamaparse": BackendInfo(
    name="llamaparse",
    description="LlamaIndex LlamaParse, GenAI-native document parsing",
    package="llama-parse",
    weight="commercial",
    loader=_load_llamaparse,
),
```

### 3. Update pyproject.toml

Add optional dependency:
```toml
llamaparse = ["llama-parse>=0.6"]
```

### 4. Integration Test

Create `tests/backends/test_llamaparse_backend.py`:

```python
"""Integration tests for LlamaParse backend."""

import os
import pytest
from pathlib import Path

# Skip if no API key
pytestmark = pytest.mark.skipif(
    not os.getenv("LLAMA_CLOUD_API_KEY"),
    reason="LLAMA_CLOUD_API_KEY not set"
)


def test_llamaparse_simple_pdf(tmp_path):
    """Test LlamaParse with a simple PDF."""
    from pdfsmith.backends.llamaparse_backend import LlamaParseBackend

    backend = LlamaParseBackend()

    # Use a test PDF from the test fixtures
    test_pdf = Path(__file__).parent.parent / "fixtures" / "simple.pdf"
    if not test_pdf.exists():
        pytest.skip("Test fixture not found")

    result = backend.parse(test_pdf)

    assert isinstance(result, str)
    assert len(result) > 0


def test_llamaparse_missing_api_key(monkeypatch):
    """Test error when API key is missing."""
    monkeypatch.delenv("LLAMA_CLOUD_API_KEY", raising=False)

    from pdfsmith.backends.llamaparse_backend import LlamaParseBackend

    with pytest.raises(ValueError, match="LLAMA_CLOUD_API_KEY"):
        LlamaParseBackend()
```

## Reference Implementation

See the full implementation in pdf-bench:
`/home/stefan/applied-ai/pdf-bench/pdf_bench/systems/llamaparse_parser.py`

Key differences from pdf-bench:
- pdfsmith uses `parse(pdf_path) -> str` (returns markdown string)
- pdf-bench uses `parse(pdf_path, output_dir) -> Path` (writes to file)
- pdfsmith doesn't track costs (simpler interface)

## Testing Commands

```bash
# Set API key
export LLAMA_CLOUD_API_KEY="llx-cmXWGDEyfiwugS6DOyVHBkAPwhaesbYTe6hUOMYucZVRTozZ"

# Install dependency
uv pip install llama-parse

# Run integration test
uv run pytest tests/backends/test_llamaparse_backend.py -v

# Quick manual test
uv run python -c "
from pdfsmith import parse
result = parse('test.pdf', backend='llamaparse')
print(result[:500])
"
```

## Acceptance Criteria

1. `LlamaParseBackend` class in `backends/llamaparse_backend.py`
2. Registered in `BACKEND_REGISTRY` with weight="commercial"
3. Optional dependency in pyproject.toml
4. Integration test that runs with API key
5. Works via main API: `parse(pdf, backend='llamaparse')`
