# Backend Configuration Guide

pdfsmith supports flexible configuration for each PDF parsing backend. This allows you to tune parsers for your specific use case - whether optimizing for speed, accuracy, or handling special document types like scanned PDFs.

## Configuration Sources

Configuration is loaded from multiple sources, in order of precedence:

1. **Constructor arguments** - Passed directly when creating a backend
2. **Environment variables** - `PDFSMITH_<BACKEND>_<OPTION>` or `<BACKEND>_<OPTION>`
3. **Project config** - `.pdfsmith/<backend>.yaml` in working directory
4. **User config** - `~/.config/pdfsmith/<backend>.yaml`
5. **Built-in defaults**

## Quick Start

Copy a config template to your project:

```bash
# Create project config directory
mkdir -p .pdfsmith

# Copy and customize docling config
cp path/to/pdfsmith/config/docling.yaml .pdfsmith/
```

Or use environment variables:

```bash
export DOCLING_OCR=true
export DOCLING_DEVICE=cuda
python my_script.py
```

## Backend Configuration Reference

### Docling (Heavy, Highest Quality)

**Source**: [github.com/docling-project/docling](https://github.com/docling-project/docling)

IBM's document understanding library with deep learning models.

| Option | Default | Description |
|--------|---------|-------------|
| `do_ocr` | `false` | Enable OCR for scanned documents |
| `do_table_structure` | `true` | Enable table structure extraction |
| `num_threads` | `4` | CPU threads for processing |
| `device` | `auto` | Device: auto, cpu, cuda, mps |

**Resource Requirements**:
- Without OCR: 2-4GB RAM, 2-5 sec/doc
- With OCR: 8-12GB RAM, 30-60 sec/doc (GPU recommended)

---

### Marker (Heavy, Academic Focus)

**Source**: [github.com/VikParuchuri/marker](https://github.com/VikParuchuri/marker)

Deep learning PDF to markdown, excellent for academic papers.

| Option | Default | Description |
|--------|---------|-------------|
| `use_llm` | `false` | Use LLM for quality improvement |
| `batch_size` | `4` | Pages to process in batch |
| `languages` | `["en"]` | Languages to detect |
| `force_ocr` | `false` | Force OCR even for text PDFs |

**Resource Requirements**: 4-8GB RAM, 10-30 sec/doc, GPU recommended

---

### PDFPlumber (Light, Table Expert)

**Source**: [github.com/jsvine/pdfplumber](https://github.com/jsvine/pdfplumber)

Precise text positioning and excellent table extraction.

| Option | Default | Description |
|--------|---------|-------------|
| `table_settings.vertical_strategy` | `lines` | Table detection method |
| `table_settings.snap_tolerance` | `3` | Line alignment tolerance |
| `x_tolerance` | `3` | Character spacing tolerance |
| `layout` | `false` | Preserve visual layout |

**Resource Requirements**: <1GB RAM, 1-2 sec/doc, no GPU

**Full documentation**: [Table Extraction Settings](https://github.com/jsvine/pdfplumber#table-extraction-settings)

---

### Unstructured (Medium, Versatile)

**Source**: [github.com/Unstructured-IO/unstructured](https://github.com/Unstructured-IO/unstructured)

Document processing for LLM applications with multiple strategies.

| Option | Default | Description |
|--------|---------|-------------|
| `strategy` | `fast` | fast, hi_res, ocr_only, auto |
| `ocr_languages` | `["eng"]` | Tesseract language codes |
| `include_page_breaks` | `true` | Include page break elements |
| `infer_table_structure` | `true` | Detect table structure |

**Resource Requirements**:
- fast: <1GB RAM, 1-3 sec/doc
- hi_res: 2-4GB RAM, 10-30 sec/doc

---

### Kreuzberg (Medium, Fast OCR)

**Source**: [github.com/henryiii/kreuzberg](https://github.com/henryiii/kreuzberg)

Rust-based extraction with optional Tesseract OCR.

| Option | Default | Description |
|--------|---------|-------------|
| `ocr_enabled` | `false` | Enable Tesseract OCR |
| `ocr_language` | `eng` | Tesseract language code |
| `preserve_layout` | `true` | Preserve text layout |

**Resource Requirements**: <1GB RAM (without OCR), 1-2 sec/doc

---

### PyMuPDF4LLM (Light, LLM Optimized)

**Source**: [github.com/pymupdf/RAG](https://github.com/pymupdf/RAG)

PyMuPDF optimized for LLM consumption with markdown output.

| Option | Default | Description |
|--------|---------|-------------|
| `page_chunks` | `false` | Include page markers |
| `write_images` | `false` | Embed images as data URIs |

**Resource Requirements**: <1GB RAM, <1 sec/doc, no GPU

---

## OCR Capability Summary

| Backend | OCR Support | OCR Engine | Notes |
|---------|-------------|------------|-------|
| docling | ✅ Yes | EasyOCR | GPU recommended |
| marker | ✅ Yes | Built-in | GPU recommended |
| unstructured | ✅ Yes | Tesseract | hi_res/ocr_only strategies |
| kreuzberg | ✅ Yes | Tesseract | Requires Tesseract install |
| pdfplumber | ❌ No | - | Text-based PDFs only |
| pymupdf | ❌ No | - | Text-based PDFs only |
| pymupdf4llm | ❌ No | - | Text-based PDFs only |
| pypdf | ❌ No | - | Text-based PDFs only |

## Choosing a Backend

**For text-based PDFs (contracts, reports, web-generated)**:
- **Speed priority**: pymupdf, pypdf
- **Table extraction**: pdfplumber
- **LLM applications**: pymupdf4llm

**For scanned/image PDFs**:
- **Quality priority**: docling (with OCR), marker
- **Speed priority**: kreuzberg, unstructured (hi_res)
- **Budget/CPU only**: unstructured (ocr_only), kreuzberg

**For academic papers**:
- marker (best for complex layouts, equations)
- docling (good general quality)

## Environment Variables

All backends support environment variable configuration:

```bash
# Docling
export DOCLING_OCR=true
export DOCLING_DEVICE=cuda
export DOCLING_THREADS=8

# Marker
export MARKER_USE_LLM=false
export MARKER_BATCH_SIZE=2

# Unstructured
export UNSTRUCTURED_STRATEGY=hi_res

# Kreuzberg
export KREUZBERG_OCR_ENABLED=true
```
