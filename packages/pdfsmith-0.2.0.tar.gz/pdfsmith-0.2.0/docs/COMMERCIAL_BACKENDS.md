# Commercial Backend Configuration Guide

This guide covers setup and usage of pdfsmith's commercial PDF parsing backends.

## Quick Comparison

| Backend | Provider | Cost | Page Limit | File Size | Best For |
|---------|----------|------|------------|-----------|----------|
| AWS Textract | AWS | $1.50/1k pages | 3,000 (sync) | 10 MB | High-accuracy OCR, AWS ecosystem |
| Azure Document Intelligence | Microsoft | $1.50/1k pages | No limit | 500 MB | Enterprise documents, Microsoft stack |
| Google Document AI | Google Cloud | $1.50/1k pages | 15 (sync) | 20 MB | Multi-language, GCP ecosystem |
| Databricks | Databricks | ~$3/1k pages | Varies | N/A | SQL workflows, data pipelines |

## AWS Textract

AWS Textract provides machine learning-based OCR and text extraction.

### Installation

```bash
pip install pdfsmith[aws]
```

This installs:
- `boto3` - AWS SDK
- `pymupdf` - For multi-page PDF handling

### Environment Variables

**Required:**
- `AWS_ACCESS_KEY_ID` - AWS access key
- `AWS_SECRET_ACCESS_KEY` - AWS secret key

**Optional:**
- `AWS_REGION` - AWS region (default: `us-east-1`)
- `AWS_PROFILE` - Use named AWS profile instead of keys

### Usage Example

```python
import os
from pdfsmith import parse

# Method 1: Access key credentials
os.environ["AWS_ACCESS_KEY_ID"] = "AKIAIOSFODNN7EXAMPLE"
os.environ["AWS_SECRET_ACCESS_KEY"] = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
os.environ["AWS_REGION"] = "us-west-2"

markdown = parse("document.pdf", backend="aws_textract")

# Method 2: AWS profile
os.environ["AWS_PROFILE"] = "my-profile"
markdown = parse("document.pdf", backend="aws_textract")
```

### CLI Usage

```bash
export AWS_ACCESS_KEY_ID=AKIAIOSFODNN7EXAMPLE
export AWS_SECRET_ACCESS_KEY=wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY
export AWS_REGION=us-west-2

pdfsmith parse document.pdf -b aws_textract -o output.md
```

### Limitations

- **File size**: 10 MB maximum (synchronous API)
- **Page count**: 3,000 pages maximum
- **Multi-page handling**: Single-page PDFs sent directly; multi-page converted to PNG internally
- **Cost**: $1.50 per 1,000 pages (DetectDocumentText API)

### Troubleshooting

**Error: "An error occurred (InvalidParameterException)"**
- Check file size < 10 MB
- Ensure PDF is not corrupted
- Verify region supports Textract (most regions do)

**Error: "Unable to locate credentials"**
- Set `AWS_ACCESS_KEY_ID` and `AWS_SECRET_ACCESS_KEY`
- Or configure AWS CLI: `aws configure`
- Or use IAM role if running on EC2/ECS

**Error: "Rate exceeded"**
- Textract has API rate limits
- Implement exponential backoff
- Consider AWS support for limit increases

### Cost Estimation

```python
# 100 pages × $1.50 / 1,000 = $0.15
pages = 100
cost_usd = pages * 1.50 / 1000
print(f"Estimated cost: ${cost_usd:.4f}")
```

### Further Reading

- [AWS Textract Documentation](https://docs.aws.amazon.com/textract/)
- [DetectDocumentText API](https://docs.aws.amazon.com/textract/latest/dg/API_DetectDocumentText.html)
- [AWS Pricing](https://aws.amazon.com/textract/pricing/)

---

## Azure Document Intelligence

Azure Document Intelligence (formerly Form Recognizer) provides OCR and document understanding.

### Installation

```bash
pip install pdfsmith[azure]
```

This installs:
- `azure-ai-documentintelligence` - Azure SDK

### Environment Variables

**Required:**
- `AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT` - Service endpoint URL
- `AZURE_DOCUMENT_INTELLIGENCE_KEY` - API key

**Format:**
```bash
# Endpoint format
https://<your-resource-name>.cognitiveservices.azure.com/
```

### Setup in Azure Portal

1. Create Azure subscription (if needed)
2. Search for "Document Intelligence" in Azure Portal
3. Click "Create"
4. Choose pricing tier (F0 free tier available)
5. After creation, go to "Keys and Endpoint"
6. Copy Endpoint and Key 1

### Usage Example

```python
import os
from pdfsmith import parse

os.environ["AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT"] = (
    "https://my-doc-intel.cognitiveservices.azure.com/"
)
os.environ["AZURE_DOCUMENT_INTELLIGENCE_KEY"] = "your-32-char-key-here"

markdown = parse("document.pdf", backend="azure_document_intelligence")
```

### CLI Usage

```bash
export AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT="https://my-doc-intel.cognitiveservices.azure.com/"
export AZURE_DOCUMENT_INTELLIGENCE_KEY="your-key-here"

pdfsmith parse document.pdf -b azure_document_intelligence -o output.md
```

### Limitations

- **File size**: 500 MB maximum
- **Page count**: No hard limit (API handles large documents)
- **Model**: Uses `prebuilt-read` model (optimized for text extraction)
- **Cost**: $1.50 per 1,000 pages

### Troubleshooting

**Error: "Endpoint not found"**
- Verify endpoint URL format includes `https://` and trailing `/`
- Check resource name matches Azure portal

**Error: "Invalid API key"**
- Regenerate key in Azure portal
- Ensure no extra spaces in key string
- Try Key 2 if Key 1 fails

**Error: "Operation returned an invalid status code 'Forbidden'"**
- Check Azure subscription is active
- Verify billing is enabled
- Check resource region availability

**Error: "File too large"**
- Azure has 500 MB limit
- Split large PDFs if needed

### Cost Estimation

```python
# 1,000 pages × $1.50 / 1,000 = $1.50
pages = 1000
cost_usd = pages * 1.50 / 1000
print(f"Estimated cost: ${cost_usd:.2f}")
```

### Further Reading

- [Azure Document Intelligence Documentation](https://learn.microsoft.com/en-us/azure/ai-services/document-intelligence/)
- [Read Model](https://learn.microsoft.com/en-us/azure/ai-services/document-intelligence/concept-read)
- [Pricing](https://azure.microsoft.com/en-us/pricing/details/ai-document-intelligence/)

---

## Google Document AI

Google Cloud Document AI provides advanced document understanding and OCR.

### Installation

```bash
pip install pdfsmith[google]
```

This installs:
- `google-cloud-documentai` - Google Cloud SDK
- `google-cloud-storage` - For batch processing (future)

### Environment Variables

**Required:**
- `GOOGLE_APPLICATION_CREDENTIALS` - Path to service account JSON file
- `GOOGLE_CLOUD_PROJECT` - GCP project ID
- `GOOGLE_DOCUMENT_AI_PROCESSOR_ID` - Processor ID

**Optional:**
- `GOOGLE_CLOUD_LOCATION` - Processor location (default: `us`)

### Setup in Google Cloud Console

#### 1. Create GCP Project

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create new project or select existing
3. Note your Project ID

#### 2. Enable Document AI API

1. Go to "APIs & Services" > "Library"
2. Search for "Document AI API"
3. Click "Enable"

#### 3. Create Service Account

1. Go to "IAM & Admin" > "Service Accounts"
2. Click "Create Service Account"
3. Give it a name (e.g., `pdfsmith-service`)
4. Grant role: "Document AI API User"
5. Click "Create Key" > JSON
6. Download JSON file (keep secure!)

#### 4. Create Processor

1. Go to Document AI > "Processors"
2. Click "Create Processor"
3. Choose "Document OCR"
4. Select region (e.g., `us`, `eu`)
5. Copy Processor ID from URL or details page

### Usage Example

```python
import os
from pdfsmith import parse

# Set credentials
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "/path/to/service-account-key.json"
os.environ["GOOGLE_CLOUD_PROJECT"] = "my-project-id"
os.environ["GOOGLE_DOCUMENT_AI_PROCESSOR_ID"] = "abc123def456"
os.environ["GOOGLE_CLOUD_LOCATION"] = "us"  # Optional

markdown = parse("document.pdf", backend="google_document_ai")
```

### CLI Usage

```bash
export GOOGLE_APPLICATION_CREDENTIALS="/path/to/service-account-key.json"
export GOOGLE_CLOUD_PROJECT="my-project-id"
export GOOGLE_DOCUMENT_AI_PROCESSOR_ID="abc123def456"

pdfsmith parse document.pdf -b google_document_ai -o output.md
```

### Limitations

- **Synchronous API**: 15 pages maximum
- **File size**: 20 MB maximum (synchronous)
- **Batch processing**: Not yet implemented (use pdf-bench for >15 pages)
- **Cost**: $1.50 per 1,000 pages

### Troubleshooting

**Error: "GOOGLE_APPLICATION_CREDENTIALS must be set"**
- Download service account JSON from GCP console
- Set environment variable to absolute path

**Error: "GOOGLE_DOCUMENT_AI_PROCESSOR_ID must be set"**
- Create OCR processor in Document AI console
- Copy processor ID from URL: `projects/.../locations/.../processors/{PROCESSOR_ID}`

**Error: "PDF has X pages. Synchronous API limited to 15 pages."**
- Use Google Cloud Storage + batch processing
- Or split PDF into <15 page chunks
- Future: pdfsmith will support batch processing

**Error: "INVALID_ARGUMENT: Invalid PDF"**
- Ensure PDF is not corrupted
- Check file is actually PDF (not renamed image)
- Try opening in PDF reader first

### Cost Estimation

```python
# 500 pages × $1.50 / 1,000 = $0.75
pages = 500
cost_usd = pages * 1.50 / 1000
print(f"Estimated cost: ${cost_usd:.2f}")
```

### Further Reading

- [Document AI Documentation](https://cloud.google.com/document-ai/docs)
- [OCR Processor](https://cloud.google.com/document-ai/docs/processors-list#processor_doc-ocr)
- [Pricing](https://cloud.google.com/document-ai/pricing)

---

## Databricks

Databricks provides document parsing via SQL warehouse using the `ai_parse_document` function.

### Installation

```bash
pip install pdfsmith[databricks]
```

This installs:
- `databricks-sdk` - Databricks SDK

### Environment Variables

**Required:**
- `DATABRICKS_HOST` - Workspace URL
- `DATABRICKS_CLIENT_ID` - OAuth M2M client ID
- `DATABRICKS_CLIENT_SECRET` - OAuth M2M client secret

**Optional:**
- `DATABRICKS_WAREHOUSE_ID` - SQL warehouse ID (auto-detected if not set)

**Format:**
```bash
# Host format
https://<workspace-id>.cloud.databricks.com
```

### Setup in Databricks Workspace

#### 1. Create Service Principal

1. Go to Workspace > Settings > Identity and Access
2. Click "Service Principals" tab
3. Click "Add Service Principal"
4. Give it a name (e.g., `pdfsmith-service`)
5. Copy the Application ID (this is your CLIENT_ID)

#### 2. Create OAuth Secret

1. Click on your service principal
2. Go to "OAuth secrets" tab
3. Click "Generate secret"
4. Copy the secret immediately (shown only once!)

#### 3. Grant Permissions

1. Go to SQL Warehouses
2. Select your warehouse (or create serverless warehouse)
3. Go to "Permissions"
4. Add service principal with "Can use" permission

#### 4. Get Warehouse ID (Optional)

1. Go to SQL Warehouses
2. Click on warehouse name
3. Copy ID from URL: `/sql/warehouses/{WAREHOUSE_ID}`
4. Or leave unset for auto-detection (prefers serverless)

### Usage Example

```python
import os
from pdfsmith import parse

os.environ["DATABRICKS_HOST"] = "https://dbc-abc123-def456.cloud.databricks.com"
os.environ["DATABRICKS_CLIENT_ID"] = "your-client-id"
os.environ["DATABRICKS_CLIENT_SECRET"] = "your-client-secret"
# Optional: let pdfsmith auto-detect warehouse
# os.environ["DATABRICKS_WAREHOUSE_ID"] = "warehouse-id"

markdown = parse("document.pdf", backend="databricks")
```

### CLI Usage

```bash
export DATABRICKS_HOST="https://dbc-abc123-def456.cloud.databricks.com"
export DATABRICKS_CLIENT_ID="your-client-id"
export DATABRICKS_CLIENT_SECRET="your-client-secret"

pdfsmith parse document.pdf -b databricks -o output.md
```

### Limitations

- **Authentication**: OAuth M2M only (service principal)
- **Warehouse required**: Must have SQL warehouse with ai_parse_document enabled
- **Cost**: ~$3 per 1,000 pages (estimated, varies by warehouse type)
- **Regional availability**: Check Databricks documentation for availability

### Troubleshooting

**Error: "DATABRICKS_HOST must be set"**
- Copy full workspace URL from Databricks portal
- Include `https://` prefix
- Format: `https://<workspace-id>.cloud.databricks.com`

**Error: "DATABRICKS_CLIENT_ID and DATABRICKS_CLIENT_SECRET must be set"**
- Create service principal in workspace
- Generate OAuth secret (one-time display)
- Store secret securely

**Error: "No SQL warehouses found"**
- Create serverless SQL warehouse in workspace
- Or classic SQL warehouse
- Grant service principal "Can use" permission

**Error: "Databricks SQL execution failed"**
- Check warehouse is running (start if needed)
- Verify service principal has permissions
- Check SQL warehouse size is adequate

### Cost Estimation

```python
# Cost depends on DBU consumption
# Rough estimate: ~$3 per 1,000 pages
pages = 1000
estimated_cost_usd = pages * 3.00 / 1000
print(f"Estimated cost: ${estimated_cost_usd:.2f}")
print("Note: Actual cost varies by warehouse type and region")
```

### Further Reading

- [Databricks SQL Documentation](https://docs.databricks.com/sql/index.html)
- [ai_parse_document Function](https://docs.databricks.com/sql/language-manual/functions/ai_parse_document.html)
- [Service Principals](https://docs.databricks.com/administration-guide/users-groups/service-principals.html)

---

## General Tips

### Security Best Practices

1. **Never commit credentials** to version control
2. **Use environment files**: Create `.env` file (add to `.gitignore`)
3. **Rotate keys regularly**: Change API keys periodically
4. **Use minimal permissions**: Service accounts should have least privilege
5. **Monitor usage**: Set up billing alerts in cloud consoles

### Environment File Example

Create `.env` file:

```bash
# AWS
AWS_ACCESS_KEY_ID=your-key
AWS_SECRET_ACCESS_KEY=your-secret
AWS_REGION=us-east-1

# Azure
AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT=https://your-resource.cognitiveservices.azure.com/
AZURE_DOCUMENT_INTELLIGENCE_KEY=your-key

# Google Cloud
GOOGLE_APPLICATION_CREDENTIALS=/path/to/service-account.json
GOOGLE_CLOUD_PROJECT=your-project-id
GOOGLE_DOCUMENT_AI_PROCESSOR_ID=your-processor-id

# Databricks
DATABRICKS_HOST=https://your-workspace.cloud.databricks.com
DATABRICKS_CLIENT_ID=your-client-id
DATABRICKS_CLIENT_SECRET=your-secret
```

Load with Python:

```python
from pathlib import Path
from dotenv import load_dotenv

# Load .env file
load_dotenv()

# Now use pdfsmith
from pdfsmith import parse
markdown = parse("document.pdf", backend="aws_textract")
```

Install `python-dotenv`:

```bash
pip install python-dotenv
```

### Cost Optimization

1. **Cache results**: Don't re-parse same documents
2. **Use open-source first**: Try lightweight parsers before commercial
3. **Batch processing**: Group documents to reduce API calls
4. **Monitor spending**: Set up billing alerts
5. **Choose right backend**: Match backend capabilities to your needs

### Performance Comparison

Based on pdf-bench benchmarks (353 documents):

| Backend | Avg Speed | Quality | Cost/1k pages |
|---------|-----------|---------|---------------|
| AWS Textract | Fast | High | $1.50 |
| Azure Document Intelligence | Fast | High | $1.50 |
| Google Document AI | Fast | Very High | $1.50 |
| Databricks | Medium | High | ~$3.00 |

**Recommendation**: Start with Google Document AI for best quality, or AWS if already in AWS ecosystem.

### Multi-Backend Strategy

```python
from pdfsmith import parse, available_backends

def smart_parse(pdf_path):
    """Try backends in order of preference."""
    preferences = [
        "docling",  # Best open-source
        "google_document_ai",  # Best commercial
        "aws_textract",  # Fallback commercial
        "pymupdf4llm",  # Lightweight fallback
    ]

    available = {b.name for b in available_backends()}

    for backend in preferences:
        if backend in available:
            try:
                return parse(pdf_path, backend=backend)
            except Exception as e:
                print(f"{backend} failed: {e}")
                continue

    raise RuntimeError("All backends failed")

# Usage
markdown = smart_parse("document.pdf")
```

---

## Getting Help

- **pdfsmith Issues**: [GitHub Issues](https://github.com/applied-artificial-intelligence/pdfsmith/issues)
- **Provider Support**:
  - AWS: [AWS Support](https://aws.amazon.com/support/)
  - Azure: [Azure Support](https://azure.microsoft.com/support/)
  - Google Cloud: [GCP Support](https://cloud.google.com/support)
  - Databricks: [Databricks Support](https://docs.databricks.com/support/index.html)
