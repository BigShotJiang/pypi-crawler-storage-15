# pdfsmith

PDF to Markdown conversion library with 15 backend support.

## Project Understanding
@.claude/PROJECT_MAP.md

## Development Commands

```bash
# Test
pytest tests/

# Type check
mypy src/pdfsmith

# Lint
ruff check src tests

# Format
ruff format src tests
```

## Key Patterns

- **Strategy Pattern**: Backends implement `BaseBackend.parse(pdf_path) -> str`
- **Lazy Loading**: Backends only imported when used via registry loaders
- **Auto-Selection**: Best available backend chosen from `DEFAULT_PREFERENCE`
