"""Tests for pdfsmith."""
