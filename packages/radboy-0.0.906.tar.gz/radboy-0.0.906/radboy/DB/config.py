SEARCH_TABLES=['Entry','Expiry','PairCollection','DisplayItem','Glossary','EntryRating','TouchStamp','SystemPreference','Billing','RecieptEntry','AdditionalExpenseOrFee','RepackList','RepackItem','ClipBoord','DateMetrics','PH','DayLog']
#
