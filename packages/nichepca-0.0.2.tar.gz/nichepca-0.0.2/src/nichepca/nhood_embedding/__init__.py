from ._aggr import aggregate

__all__ = [
    "aggregate",
]
