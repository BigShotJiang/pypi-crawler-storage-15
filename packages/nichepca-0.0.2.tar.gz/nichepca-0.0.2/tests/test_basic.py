import nichepca


def test_package_has_version():
    assert nichepca.__version__ is not None
