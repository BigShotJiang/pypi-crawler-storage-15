# API

```{eval-rst}
.. autosummary::
    :toctree: generated
    :recursive:
    :nosignatures:

    nichepca.workflows
    nichepca.clustering
    nichepca.graph_construction
    nichepca.nhood_embedding
    nichepca.utils
```
