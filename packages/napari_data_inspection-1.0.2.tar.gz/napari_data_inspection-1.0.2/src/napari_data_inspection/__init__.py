__version__ = "1.0.2"
from napari_data_inspection.data_inspection._widget import DataInspectionWidget

__all__ = ("DataInspectionWidget",)
