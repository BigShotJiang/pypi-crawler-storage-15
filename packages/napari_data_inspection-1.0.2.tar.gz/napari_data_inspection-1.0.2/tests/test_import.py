def test_import():
    import napari_data_inspection
