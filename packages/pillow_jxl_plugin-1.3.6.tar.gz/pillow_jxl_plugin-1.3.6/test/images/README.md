## License about test sample images
- Most of sample images are copied from [`libjxl/testdata`](https://github.com/libjxl/testdata/tree/main) with **CC-BY-4.0 license**
- `bench.png` is a photo taken by myself, with **CC-BY-SA-4.0 license**
- `62AHB.jpg` is copied from [Stackoverflow](https://stackoverflow.com/questions/31865743/pil-pillow-decode-icc-profile-information), with [**CC-BY-SA-4.0 license**](https://stackoverflow.com/help/licensing)
