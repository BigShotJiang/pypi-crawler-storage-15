## Basic Dimensional Math Package

Use common functions for calculating kpis in dimensional/process manufacturing