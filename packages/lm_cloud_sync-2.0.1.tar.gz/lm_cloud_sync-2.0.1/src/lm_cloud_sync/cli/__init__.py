"""CLI entry point for lm-cloud-sync."""

from lm_cloud_sync.cli.main import main

__all__ = ["main"]
