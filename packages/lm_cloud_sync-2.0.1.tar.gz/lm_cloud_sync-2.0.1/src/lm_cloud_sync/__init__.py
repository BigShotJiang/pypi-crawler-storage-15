"""LM Cloud Sync - Multi-cloud automation for LogicMonitor integrations."""

__version__ = "2.0.0"
