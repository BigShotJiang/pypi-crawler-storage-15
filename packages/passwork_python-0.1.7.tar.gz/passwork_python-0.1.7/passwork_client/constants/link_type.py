class LinkType:
    SingleUse = 'single_use'
    Reusable = 'reusable'