"""Plotly Dash UI application for viewing and analyzing retrieval evaluation results."""

