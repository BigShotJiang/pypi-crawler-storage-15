from .apertium import Apertium
