"""Image scales fallback for Plone 5"""
