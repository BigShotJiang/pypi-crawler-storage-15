# spytify

A minimalistic Spotify API wrapper.