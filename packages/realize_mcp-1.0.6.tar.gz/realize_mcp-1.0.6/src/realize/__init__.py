"""Realize API client and authentication."""

from realize._version import __version__

__all__ = ["__version__"] 