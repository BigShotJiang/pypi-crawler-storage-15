from .config import Config
config = Config()