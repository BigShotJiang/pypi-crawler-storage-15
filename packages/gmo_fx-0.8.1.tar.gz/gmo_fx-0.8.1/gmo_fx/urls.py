BASE_URL_PUBLIC = "https://forex-api.coin.z.com/public/v1"
