"""Command-line interface for MCP Ticketer."""

from .main import app

__all__ = ["app"]
