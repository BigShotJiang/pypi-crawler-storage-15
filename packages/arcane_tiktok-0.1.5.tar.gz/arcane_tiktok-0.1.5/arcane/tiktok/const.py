TIKTOK_SERVER_URL = "https://business-api.tiktok.com/open_api/v1.3"
TIKTOK_OAUTH_CREDENTIALS_KIND = "tiktok-oauth-credentials"
