"""Version information for gac package."""

__version__ = "3.8.2"
