from enum import Enum

__NAMESPACE__ = "http://ns.editeur.org/onix/3.0/reference"


class CurrencyZoneRefname(Enum):
    CURRENCY_ZONE = "CurrencyZone"
