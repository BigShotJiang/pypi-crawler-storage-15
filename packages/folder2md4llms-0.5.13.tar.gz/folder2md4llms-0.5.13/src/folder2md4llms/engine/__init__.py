"""Smart anti-truncation engine module."""

from .smart_engine import SmartAntiTruncationEngine

__all__ = ["SmartAntiTruncationEngine"]
