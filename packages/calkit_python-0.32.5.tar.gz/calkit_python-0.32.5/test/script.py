print("Hello from script.py")

with open("test.txt", "w") as f:
    f.write("This is test output")
