
from typing import Any, Dict

Attrs = Dict[str, Any]
