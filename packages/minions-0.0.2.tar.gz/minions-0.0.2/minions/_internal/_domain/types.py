from typing import TypeVar

T_Event = TypeVar("T_Event") # pipeline event
T_Ctx = TypeVar("T_Ctx")     # minion workflow context