# LangChain Trigger Server

Framework for developing triggers for use in the LangSmith Agent Builder