"""Built-in trigger templates for the LangChain Triggers Framework."""

from .cron_trigger import cron_trigger

__all__ = [
    "cron_trigger",
]
