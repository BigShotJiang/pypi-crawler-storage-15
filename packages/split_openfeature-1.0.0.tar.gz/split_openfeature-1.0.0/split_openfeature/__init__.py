from split_openfeature.split_provider import SplitProvider
import warnings
warnings.warn("deprecated", DeprecationWarning)