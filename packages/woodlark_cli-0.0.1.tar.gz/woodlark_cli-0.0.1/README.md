# woodlark-cli

[![PyPI - Version](https://img.shields.io/pypi/v/woodlark-cli.svg)](https://pypi.org/project/woodlark-cli)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/woodlark-cli.svg)](https://pypi.org/project/woodlark-cli)

---

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install woodlark-cli
```

## License

`woodlark-cli` is distributed under the terms of the [Apache-2.0](https://spdx.org/licenses/Apache-2.0.html) license.
