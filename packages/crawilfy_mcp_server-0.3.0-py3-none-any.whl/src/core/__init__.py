"""Core engine components."""



