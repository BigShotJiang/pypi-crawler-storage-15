"""Session and credential management."""



