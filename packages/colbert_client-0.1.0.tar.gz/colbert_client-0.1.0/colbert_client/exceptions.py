"""
Exception classes for ColBERT Client SDK.
"""


class ColBERTClientError(Exception):
    """Base exception for all ColBERT client errors."""
    pass


class ColBERTConnectionError(ColBERTClientError):
    """Raised when connection to the server fails."""
    pass


class ColBERTServerError(ColBERTClientError):
    """Raised when the server returns an error."""
    
    def __init__(self, message: str, status_code: str | None = None):
        super().__init__(message)
        self.status_code = status_code


class ColBERTTimeoutError(ColBERTClientError):
    """Raised when a request times out."""
    pass


class ColBERTValidationError(ColBERTClientError):
    """Raised when input validation fails."""
    pass
