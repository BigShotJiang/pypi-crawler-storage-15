# odd-even-utils

A simple Python library for checking whether a number is odd or even.

## Installation

```bash
pip install odd-even-utils
