from .server import run as main

__all__ = ["main"]
