from typing import Literal

TTSLangs = Literal["eng", "spa", "fra", "ger", "hin"]
