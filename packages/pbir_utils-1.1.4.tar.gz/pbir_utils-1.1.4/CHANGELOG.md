### Fixed
- Refactored `set_first_page_as_active`, `remove_empty_pages`, and `report_wireframe_visualizer` to rely on IDs from `page.json`/`visual.json` instead of folder names, ensuring robustness when folders are renamed.
