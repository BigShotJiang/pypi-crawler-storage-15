"""
djinsight - Django/Wagtail analytics package for real-time page view tracking.
"""

__version__ = "0.1.8"
__author__ = "MDigital"
__email__ = "kontakt@mdigital.com.pl"
__license__ = "MIT"

default_app_config = "djinsight.apps.DjInsightConfig"
