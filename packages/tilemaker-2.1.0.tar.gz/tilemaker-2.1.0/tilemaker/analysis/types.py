from .histogram import HistogramProduct

SLUG_TO_TYPE = {"hist": HistogramProduct}

AnalysisType = HistogramProduct
