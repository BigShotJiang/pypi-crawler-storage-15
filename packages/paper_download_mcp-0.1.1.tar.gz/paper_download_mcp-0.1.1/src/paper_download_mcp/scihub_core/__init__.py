"""Core scihub-cli functionality (copied from scihub-cli project)."""
