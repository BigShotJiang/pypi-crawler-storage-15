"""
Multi-source paper download system.
"""

from .base import PaperSource

__all__ = ['PaperSource']
