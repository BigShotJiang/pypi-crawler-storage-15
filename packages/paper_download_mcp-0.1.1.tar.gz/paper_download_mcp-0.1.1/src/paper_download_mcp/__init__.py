"""Paper Download MCP Server - Download academic papers via MCP protocol."""

__version__ = "0.1.0"
