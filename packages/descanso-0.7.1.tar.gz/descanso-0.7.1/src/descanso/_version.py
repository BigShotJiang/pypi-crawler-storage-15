# This file auto generated!
# DO NOT EDIT MANUALLY!

version: str = "0.7.1"
__version__: str = "0.7.1"

commit_hash: str = "g0df19d916f82171ed2866a54d0907c2501511078"
version_timestamp: str = "2025-12-06 16:20:37.460808+00:00"

tag: str = "0.7.1"
branch: str = "HEAD"
commit_date: str = "2025-12-06"
commit_count_since_tag: int = 0
