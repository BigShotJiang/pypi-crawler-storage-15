I used the followinfg link for reference
https://medium.com/analytics-vidhya/how-to-create-a-python-library-7d5aea80cc3f

### Legend

**Status Indicators:**

- ![TO DO](https://img.shields.io/badge/Status-TO_DO-red) Complete the documentation
- ![ONGOING](https://img.shields.io/badge/Status-ONGOING-yellow) Tasks that are currently being worked on.
- ![DONE](https://img.shields.io/badge/Status-DONE-green) Set up the repository

# Library Development Progress

XmiManager is currently able to read the following entities from the JSON File

| Entity Name               | Status                                                         |
| ------------------------- | -------------------------------------------------------------- |
| StructuralModel           | ![TO DO](https://img.shields.io/badge/Status-TO_DO-red)        |
| StructuralPointConnection | ![DONE](https://img.shields.io/badge/Status-DONE-green)        |
| StructuralCurveMember     | ![DONE](https://img.shields.io/badge/Status-DONE-green)        |
| StructuralSurfaceMember   | ![DONE](https://img.shields.io/badge/Status-DONE-green)        |
| StructuralMaterial        | ![DONE](https://img.shields.io/badge/Status-DONE-green)        |
| StructuralCrossSection    | ![DONE](https://img.shields.io/badge/Status-DONE-green)        |
| StructuralUnit            | ![ONGOING](https://img.shields.io/badge/Status-ONGOING-yellow) |


testing