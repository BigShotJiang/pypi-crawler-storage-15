"""Entry point for python -m docks."""

from docks.cli import app

if __name__ == "__main__":
    app()
