"""Docks CLI - Command-line interface for Docks evaluation platform."""

__version__ = "0.1.0"
