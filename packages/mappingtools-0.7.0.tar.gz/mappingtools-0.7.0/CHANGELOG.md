## v0.7.0 (2025-12-06)

### Feat

- enhance `strictify` to support Mapping and Iterable handling in value conversion

### Fix

- reorder imports in `strictify.py` for PEP 8 compliance

## v0.6.0 (2025-10-26)

### Fix

- update type hint for atomic_operations method to use DictOperation

### Refactor

- move UTC import to compatibility module for cross-version support

## v0.5.0 (2025-08-31)

## v0.4.1 (2025-08-31)

## v0.4.0 (2025-03-25)

## v0.3.1 (2025-01-20)

## v0.3.0 (2025-01-18)

## v0.2.2 (2024-10-18)

## v0.2.1 (2024-10-18)

## v0.2.0 (2024-08-04)

## v0.1.0 (2024-07-29)

## v0.0.5 (2024-07-25)

## v0.0.4 (2024-07-24)

## v0.0.3 (2024-07-24)

## v0.0.2 (2024-07-24)

## v0.0.1 (2024-07-23)
