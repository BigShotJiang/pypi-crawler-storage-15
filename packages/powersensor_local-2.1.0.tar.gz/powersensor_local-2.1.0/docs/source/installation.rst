Installation
============

From PyPI
---------

.. code-block:: bash

   pip install powersensor_local

From Source
-----------

.. code-block:: bash

   git clone https://github.com/yourusername/powersensor_local.git
   cd powersensor_local
   pip install -e .

Development Installation
------------------------

.. code-block:: bash

   git clone https://github.com/yourusername/powersensor_local.git
   cd powersensor_local
   pip install -e ".[docs]"
