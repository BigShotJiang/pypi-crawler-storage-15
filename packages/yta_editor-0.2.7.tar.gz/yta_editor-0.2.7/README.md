# Youtube Autonomous Main Editor

The main Editor that works using PyAv and OpenGL.

Based on `pyav` and `opengl`.