﻿sf\_quant.data.load\_exposures
==============================

.. currentmodule:: sf_quant.data

.. autofunction:: load_exposures