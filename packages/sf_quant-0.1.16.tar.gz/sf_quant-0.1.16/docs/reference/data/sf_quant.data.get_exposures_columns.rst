﻿sf\_quant.data.get\_exposures\_columns
======================================

.. currentmodule:: sf_quant.data

.. autofunction:: get_exposures_columns