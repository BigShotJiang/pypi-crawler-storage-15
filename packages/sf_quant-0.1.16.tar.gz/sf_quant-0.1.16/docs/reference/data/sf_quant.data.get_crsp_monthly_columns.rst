﻿sf\_quant.data.get\_crsp\_monthly\_columns
==========================================

.. currentmodule:: sf_quant.data

.. autofunction:: get_crsp_monthly_columns