Backtester
==========

.. automodule:: sf_quant.backtester
   :no-members:
   :no-undoc-members:
   :no-imported-members:

.. currentmodule:: sf_quant.backtester

.. autosummary::
   :toctree: backtester
   :nosignatures:

   backtest_sequential
   backtest_parallel