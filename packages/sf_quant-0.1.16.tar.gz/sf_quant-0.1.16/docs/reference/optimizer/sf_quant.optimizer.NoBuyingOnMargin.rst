﻿sf\_quant.optimizer.NoBuyingOnMargin
====================================

.. currentmodule:: sf_quant.optimizer

.. autoclass:: NoBuyingOnMargin

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~NoBuyingOnMargin.__init__
   
   

   
   
   