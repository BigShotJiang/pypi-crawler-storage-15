# collectiontools [![collectiontools](https://github.com/tillahoffmann/collectiontools/actions/workflows/build.yml/badge.svg)](https://github.com/tillahoffmann/collectiontools/actions/workflows/build.yml)

This package implements functions to handle [`collections`](https://docs.python.org/3/library/collections.html) efficiently.
