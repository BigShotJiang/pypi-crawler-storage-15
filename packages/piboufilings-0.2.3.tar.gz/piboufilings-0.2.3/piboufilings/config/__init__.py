"""
Configuration package for piboufilings.
"""

from .settings import * 