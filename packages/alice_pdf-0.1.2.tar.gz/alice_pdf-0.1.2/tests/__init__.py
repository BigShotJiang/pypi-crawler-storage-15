"""Tests for alice-pdf package."""
