"""Alice PDF - Extract tables from PDFs using Mistral OCR."""

__version__ = "0.1.2"
