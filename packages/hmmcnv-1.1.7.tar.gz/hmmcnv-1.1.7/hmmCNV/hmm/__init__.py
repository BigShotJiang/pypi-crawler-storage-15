"""Init for hmm."""

from __future__ import absolute_import
from .hmm import forward_backward, viterbi
from .hmm import get_include

# This is extracted automatically by the top-level setup.py.
__version__ = '0.1.0'