"""Init for mylibrary."""
from __future__ import absolute_import
from .hmmCNV import hmmCNV

# This is extracted automatically by the top-level setup.py.
__version__ = '1.1.7'