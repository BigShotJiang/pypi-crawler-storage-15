"""CapInvest Platform API Utils."""
