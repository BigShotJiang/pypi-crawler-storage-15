def isNaN(num):
    '''
    The usual way to test for a NaN is to see if it's equal to itself
    :param num:
    :return: bool
    '''
    return num != num

