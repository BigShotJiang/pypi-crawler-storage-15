# License

Copyright © 2025 Kodo / The Willum Corporation. All Rights Reserved.

## Terms

This software and its source code are proprietary to Kodo / The Willum Corporation.

### You MAY:
- ✅ Use this software for personal, educational, and internal business purposes
- ✅ View and study the source code
- ✅ Fork and modify for personal use
- ✅ Submit contributions (which become property of the copyright holder)

### You MAY NOT:
- ❌ Sell, sublicense, or commercially distribute this software
- ❌ Offer this software as a hosted/managed service
- ❌ Remove or alter copyright notices
- ❌ Use the Kodo or Willum Corporation name/branding without permission

### Attribution
Any use of this software must include attribution to Kodo / The Willum Corporation.

### No Warranty
THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

---

For commercial licensing inquiries, contact: support@kodo.dev
