
from setuptools import setup, find_packages

VERSION = "0.1.2"

f = open('README.md', 'r')
LONG_DESCRIPTION = f.read()
f.close()

setup(
    name='koci',
    version=VERSION,
    description='Kodo CI - Universal CI/CD Pipeline Tool',
    long_description=LONG_DESCRIPTION,
    long_description_content_type='text/markdown',
    author='Kodo / The Willum Corporation',
    author_email='support@kodo.dev',
    url='https://github.com/kodo/koci',
    license='Proprietary',
    packages=find_packages(exclude=['ez_setup', 'tests*']),
    package_data={'koci': ['templates/*']},
    include_package_data=True,
    entry_points="""
        [console_scripts]
        koci = koci.main:main
    """,
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'License :: Other/Proprietary License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Topic :: Software Development :: Build Tools',
    ],
)
