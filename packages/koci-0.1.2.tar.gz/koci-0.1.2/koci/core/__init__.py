"""
koci Core Module

Contains the core data models, parser, and expression evaluator.
"""

from .models import (
    Pipeline,
    Stage,
    Job,
    Step,
    Service,
    Artifact,
    MatrixConfig,
    ReportConfig,
    CoverageConfig,
    StepType,
    JobStatus,
)
from .parser import (
    PipelineParser,
    parse_pipeline,
    parse_pipeline_string,
    ParserError,
    ValidationError,
)
from .expressions import (
    ExecutionContext,
    evaluate_when,
    evaluate_if,
    evaluate_condition,
    ExpressionError,
)
from .reports import (
    JUnitParser,
    CoverageParser,
    JUnitResult,
    CoverageResult,
    ReportResult,
    parse_reports,
)
from .exc import KociError

__all__ = [
    # Models
    'Pipeline',
    'Stage',
    'Job',
    'Step',
    'Service',
    'Artifact',
    'MatrixConfig',
    'ReportConfig',
    'CoverageConfig',
    'StepType',
    'JobStatus',
    # Parser
    'PipelineParser',
    'parse_pipeline',
    'parse_pipeline_string',
    'ParserError',
    'ValidationError',
    # Expressions
    'ExecutionContext',
    'evaluate_when',
    'evaluate_if',
    'evaluate_condition',
    'ExpressionError',
    # Reports
    'JUnitParser',
    'CoverageParser',
    'JUnitResult',
    'CoverageResult',
    'ReportResult',
    'parse_reports',
    # Exceptions
    'KociError',
]
