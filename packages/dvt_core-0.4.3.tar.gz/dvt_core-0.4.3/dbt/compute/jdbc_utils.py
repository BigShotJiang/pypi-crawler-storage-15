"""
JDBC Utilities for Spark Engine

Provides utilities for converting dbt adapter credentials to JDBC configurations
and helpers for optimizing parallel reads via partitioning.

This module enables DVT to bypass memory bottlenecks by using Spark JDBC connectors
to read data directly from source databases into Spark workers (distributed).

Architecture:
- Maps adapter credentials → JDBC URL + properties
- Auto-detects optimal partition columns for parallel reads
- Estimates partition bounds for efficient data distribution
"""

from typing import Dict, Optional, Tuple

from dbt.adapters.base import BaseAdapter
from dbt.adapters.contracts.connection import Credentials
from dbt_common.exceptions import DbtRuntimeError


# JDBC driver class mapping for common database types
JDBC_DRIVER_MAPPING = {
    "postgres": "org.postgresql.Driver",
    "postgresql": "org.postgresql.Driver",
    "mysql": "com.mysql.cj.jdbc.Driver",
    "snowflake": "net.snowflake.client.jdbc.SnowflakeDriver",
    "redshift": "com.amazon.redshift.jdbc.Driver",
    "bigquery": "com.simba.googlebigquery.jdbc.Driver",
    "sqlserver": "com.microsoft.sqlserver.jdbc.SQLServerDriver",
    "mssql": "com.microsoft.sqlserver.jdbc.SQLServerDriver",
    "oracle": "oracle.jdbc.OracleDriver",
    "db2": "com.ibm.db2.jcc.DB2Driver",
    "teradata": "com.teradata.jdbc.TeraDriver",
}


def build_jdbc_config(credentials: Credentials) -> Tuple[str, Dict[str, str]]:
    """
    Build JDBC configuration from dbt adapter credentials.

    Converts adapter-specific credentials to JDBC URL and connection properties
    that can be used by Spark JDBC connectors.

    :param credentials: dbt adapter credentials object
    :returns: Tuple of (jdbc_url, jdbc_properties)
    :raises DbtRuntimeError: If adapter type is not supported or credentials are invalid

    Example:
        >>> from dbt.adapters.postgres import PostgresCredentials
        >>> creds = PostgresCredentials(
        ...     host="localhost",
        ...     port=5432,
        ...     user="analytics",
        ...     password="secret",
        ...     database="warehouse",
        ...     schema="public"
        ... )
        >>> url, props = build_jdbc_config(creds)
        >>> print(url)
        jdbc:postgresql://localhost:5432/warehouse
        >>> print(props)
        {'user': 'analytics', 'password': 'secret', 'driver': 'org.postgresql.Driver'}
    """
    adapter_type = credentials.type.lower()

    # Check if adapter type is supported
    if adapter_type not in JDBC_DRIVER_MAPPING:
        raise DbtRuntimeError(
            f"JDBC connectivity not supported for adapter type '{adapter_type}'. "
            f"Supported types: {', '.join(JDBC_DRIVER_MAPPING.keys())}"
        )

    # Build JDBC URL and properties based on adapter type
    if adapter_type in ("postgres", "postgresql"):
        return _build_postgres_jdbc_config(credentials)
    elif adapter_type == "mysql":
        return _build_mysql_jdbc_config(credentials)
    elif adapter_type == "snowflake":
        return _build_snowflake_jdbc_config(credentials)
    elif adapter_type == "redshift":
        return _build_redshift_jdbc_config(credentials)
    elif adapter_type == "bigquery":
        return _build_bigquery_jdbc_config(credentials)
    elif adapter_type in ("sqlserver", "mssql"):
        return _build_sqlserver_jdbc_config(credentials)
    elif adapter_type == "oracle":
        return _build_oracle_jdbc_config(credentials)
    else:
        raise DbtRuntimeError(
            f"JDBC configuration builder not implemented for adapter type '{adapter_type}'"
        )


def _build_postgres_jdbc_config(credentials: Credentials) -> Tuple[str, Dict[str, str]]:
    """Build JDBC config for PostgreSQL."""
    creds_dict = credentials.to_dict()

    host = creds_dict.get("host", "localhost")
    port = creds_dict.get("port", 5432)
    database = creds_dict.get("database")
    user = creds_dict.get("user")
    password = creds_dict.get("password", "")

    if not database:
        raise DbtRuntimeError("PostgreSQL credentials missing required field: database")
    if not user:
        raise DbtRuntimeError("PostgreSQL credentials missing required field: user")

    jdbc_url = f"jdbc:postgresql://{host}:{port}/{database}"

    jdbc_properties = {
        "user": user,
        "password": password,
        "driver": JDBC_DRIVER_MAPPING["postgres"],
    }

    # Optional: Add SSL configuration if present
    if creds_dict.get("sslmode"):
        jdbc_properties["ssl"] = "true" if creds_dict["sslmode"] != "disable" else "false"

    return jdbc_url, jdbc_properties


def _build_mysql_jdbc_config(credentials: Credentials) -> Tuple[str, Dict[str, str]]:
    """Build JDBC config for MySQL."""
    creds_dict = credentials.to_dict()

    host = creds_dict.get("host", "localhost")
    port = creds_dict.get("port", 3306)
    database = creds_dict.get("database")
    user = creds_dict.get("user")
    password = creds_dict.get("password", "")

    if not database:
        raise DbtRuntimeError("MySQL credentials missing required field: database")
    if not user:
        raise DbtRuntimeError("MySQL credentials missing required field: user")

    jdbc_url = f"jdbc:mysql://{host}:{port}/{database}"

    jdbc_properties = {
        "user": user,
        "password": password,
        "driver": JDBC_DRIVER_MAPPING["mysql"],
    }

    return jdbc_url, jdbc_properties


def _build_snowflake_jdbc_config(credentials: Credentials) -> Tuple[str, Dict[str, str]]:
    """Build JDBC config for Snowflake."""
    creds_dict = credentials.to_dict()

    account = creds_dict.get("account")
    user = creds_dict.get("user")
    password = creds_dict.get("password", "")
    database = creds_dict.get("database")
    warehouse = creds_dict.get("warehouse")
    schema = creds_dict.get("schema", "public")

    if not account:
        raise DbtRuntimeError("Snowflake credentials missing required field: account")
    if not user:
        raise DbtRuntimeError("Snowflake credentials missing required field: user")

    # Snowflake JDBC URL format
    jdbc_url = f"jdbc:snowflake://{account}.snowflakecomputing.com/"

    jdbc_properties = {
        "user": user,
        "password": password,
        "driver": JDBC_DRIVER_MAPPING["snowflake"],
        # Disable Arrow format (use JSON) to avoid Java 21 module access issues
        # Arrow format requires sun.misc.Unsafe which is restricted in Java 21
        "jdbc_query_result_format": "JSON",
    }

    # Add optional properties
    if database:
        jdbc_properties["db"] = database
    if warehouse:
        jdbc_properties["warehouse"] = warehouse
    if schema:
        jdbc_properties["schema"] = schema

    return jdbc_url, jdbc_properties


def _build_redshift_jdbc_config(credentials: Credentials) -> Tuple[str, Dict[str, str]]:
    """Build JDBC config for Amazon Redshift."""
    creds_dict = credentials.to_dict()

    host = creds_dict.get("host")
    port = creds_dict.get("port", 5439)
    database = creds_dict.get("database")
    user = creds_dict.get("user")
    password = creds_dict.get("password", "")

    if not host:
        raise DbtRuntimeError("Redshift credentials missing required field: host")
    if not database:
        raise DbtRuntimeError("Redshift credentials missing required field: database")
    if not user:
        raise DbtRuntimeError("Redshift credentials missing required field: user")

    jdbc_url = f"jdbc:redshift://{host}:{port}/{database}"

    jdbc_properties = {
        "user": user,
        "password": password,
        "driver": JDBC_DRIVER_MAPPING["redshift"],
    }

    return jdbc_url, jdbc_properties


def _build_bigquery_jdbc_config(credentials: Credentials) -> Tuple[str, Dict[str, str]]:
    """Build JDBC config for Google BigQuery."""
    creds_dict = credentials.to_dict()

    project = creds_dict.get("project")
    dataset = creds_dict.get("dataset") or creds_dict.get("schema")

    if not project:
        raise DbtRuntimeError("BigQuery credentials missing required field: project")

    # BigQuery JDBC URL format
    jdbc_url = "jdbc:bigquery://https://www.googleapis.com/bigquery/v2:443"

    jdbc_properties = {
        "ProjectId": project,
        "driver": JDBC_DRIVER_MAPPING["bigquery"],
    }

    if dataset:
        jdbc_properties["DefaultDataset"] = dataset

    # Handle authentication
    # BigQuery typically uses service account JSON or OAuth
    if creds_dict.get("keyfile"):
        jdbc_properties["OAuthType"] = "0"  # Service account
        jdbc_properties["OAuthServiceAcctEmail"] = creds_dict.get("client_email", "")
        jdbc_properties["OAuthPvtKeyPath"] = creds_dict["keyfile"]

    return jdbc_url, jdbc_properties


def _build_sqlserver_jdbc_config(credentials: Credentials) -> Tuple[str, Dict[str, str]]:
    """Build JDBC config for Microsoft SQL Server."""
    creds_dict = credentials.to_dict()

    host = creds_dict.get("host", "localhost")
    port = creds_dict.get("port", 1433)
    database = creds_dict.get("database")
    user = creds_dict.get("user")
    password = creds_dict.get("password", "")

    if not database:
        raise DbtRuntimeError("SQL Server credentials missing required field: database")
    if not user:
        raise DbtRuntimeError("SQL Server credentials missing required field: user")

    jdbc_url = f"jdbc:sqlserver://{host}:{port};databaseName={database}"

    jdbc_properties = {
        "user": user,
        "password": password,
        "driver": JDBC_DRIVER_MAPPING["sqlserver"],
    }

    return jdbc_url, jdbc_properties


def _build_oracle_jdbc_config(credentials: Credentials) -> Tuple[str, Dict[str, str]]:
    """Build JDBC config for Oracle Database."""
    creds_dict = credentials.to_dict()

    host = creds_dict.get("host", "localhost")
    port = creds_dict.get("port", 1521)
    database = creds_dict.get("database") or creds_dict.get("service_name")
    user = creds_dict.get("user")
    password = creds_dict.get("password", "")

    if not database:
        raise DbtRuntimeError("Oracle credentials missing required field: database/service_name")
    if not user:
        raise DbtRuntimeError("Oracle credentials missing required field: user")

    # Oracle thin driver format
    jdbc_url = f"jdbc:oracle:thin:@{host}:{port}:{database}"

    jdbc_properties = {
        "user": user,
        "password": password,
        "driver": JDBC_DRIVER_MAPPING["oracle"],
    }

    return jdbc_url, jdbc_properties


def auto_detect_partition_column(adapter: BaseAdapter, schema: str, table: str) -> Optional[str]:
    """
    Auto-detect the best column for partitioning parallel JDBC reads.

    Queries table metadata to find a suitable partition column. Prioritizes:
    1. Primary key columns (single column PKs only)
    2. Columns named 'id' or ending with '_id'
    3. Timestamp/date columns
    4. Integer columns

    :param adapter: dbt adapter to use for querying metadata
    :param schema: Schema/dataset name
    :param table: Table name
    :returns: Column name suitable for partitioning, or None if not found

    Example:
        >>> column = auto_detect_partition_column(adapter, "public", "users")
        >>> if column:
        ...     print(f"Using {column} for partitioning")
        ... else:
        ...     print("No suitable partition column found")
    """
    try:
        # Strategy 1: Check for primary key
        pk_column = _get_primary_key_column(adapter, schema, table)
        if pk_column:
            return pk_column

        # Strategy 2: Get all columns and look for ID-like columns
        columns = _get_table_columns(adapter, schema, table)

        # Look for ID columns (exact match or suffix)
        for col_name, col_type in columns:
            col_name_lower = col_name.lower()
            if col_name_lower == "id" or col_name_lower.endswith("_id"):
                # Check if it's an integer type
                if _is_integer_type(col_type):
                    return col_name

        # Strategy 3: Look for timestamp/date columns
        for col_name, col_type in columns:
            if _is_timestamp_type(col_type):
                return col_name

        # Strategy 4: Look for any integer column
        for col_name, col_type in columns:
            if _is_integer_type(col_type):
                return col_name

        # No suitable column found
        return None

    except Exception:
        # If metadata query fails, return None (caller can decide to read without partitioning)
        return None


def estimate_partition_bounds(
    adapter: BaseAdapter, schema: str, table: str, column: str
) -> Tuple[int, int]:
    """
    Estimate partition bounds (min/max) for a numeric partition column.

    Queries the table to get MIN and MAX values of the partition column,
    which are used by Spark JDBC to distribute reads across workers.

    :param adapter: dbt adapter to use for querying
    :param schema: Schema/dataset name
    :param table: Table name
    :param column: Partition column name
    :returns: Tuple of (lower_bound, upper_bound)
    :raises DbtRuntimeError: If query fails or column is not numeric

    Example:
        >>> lower, upper = estimate_partition_bounds(adapter, "public", "orders", "order_id")
        >>> print(f"Partition range: {lower} to {upper}")
        Partition range: 1 to 1000000
    """
    try:
        # Build qualified table name
        qualified_table = f"{schema}.{table}"

        # Query for min/max
        sql = f"SELECT MIN({column}) as min_val, MAX({column}) as max_val FROM {qualified_table}"

        # Execute via adapter
        response, result_table = adapter.execute(sql, auto_begin=False, fetch=True)

        if not result_table or len(result_table.rows) == 0:
            raise DbtRuntimeError(
                f"Failed to estimate partition bounds for {qualified_table}.{column}: "
                "Query returned no results"
            )

        row = result_table.rows[0]
        min_val = row[0]
        max_val = row[1]

        if min_val is None or max_val is None:
            raise DbtRuntimeError(
                f"Failed to estimate partition bounds for {qualified_table}.{column}: "
                "Column contains only NULL values"
            )

        # Convert to integers
        lower_bound = int(min_val)
        upper_bound = int(max_val)

        return lower_bound, upper_bound

    except Exception as e:
        raise DbtRuntimeError(
            f"Failed to estimate partition bounds for {schema}.{table}.{column}: {str(e)}"
        ) from e


# Helper functions for metadata queries


def _get_primary_key_column(adapter: BaseAdapter, schema: str, table: str) -> Optional[str]:
    """
    Get primary key column name (if single-column PK exists).

    Implementation is adapter-specific. Returns None if not implemented
    or if PK is composite.
    """
    adapter_type = adapter.type().lower()

    try:
        if adapter_type in ("postgres", "postgresql", "redshift"):
            # PostgreSQL/Redshift: Query information_schema
            sql = f"""
            SELECT a.attname
            FROM pg_index i
            JOIN pg_attribute a ON a.attrelid = i.indrelid AND a.attnum = ANY(i.indkey)
            WHERE i.indrelid = '{schema}.{table}'::regclass
            AND i.indisprimary
            """
            response, result = adapter.execute(sql, auto_begin=False, fetch=True)
            if result and len(result.rows) == 1:
                return result.rows[0][0]

        elif adapter_type == "mysql":
            # MySQL: Query information_schema
            sql = f"""
            SELECT COLUMN_NAME
            FROM information_schema.KEY_COLUMN_USAGE
            WHERE TABLE_SCHEMA = '{schema}'
            AND TABLE_NAME = '{table}'
            AND CONSTRAINT_NAME = 'PRIMARY'
            """
            response, result = adapter.execute(sql, auto_begin=False, fetch=True)
            if result and len(result.rows) == 1:
                return result.rows[0][0]

        # For other adapters or if query fails, return None
        return None

    except Exception:
        return None


def _get_table_columns(adapter: BaseAdapter, schema: str, table: str) -> list[Tuple[str, str]]:
    """
    Get list of (column_name, column_type) for a table.
    """
    adapter_type = adapter.type().lower()

    try:
        if adapter_type in ("postgres", "postgresql", "redshift"):
            sql = f"""
            SELECT column_name, data_type
            FROM information_schema.columns
            WHERE table_schema = '{schema}'
            AND table_name = '{table}'
            ORDER BY ordinal_position
            """
            response, result = adapter.execute(sql, auto_begin=False, fetch=True)
            return [(row[0], row[1]) for row in result.rows]

        elif adapter_type == "mysql":
            sql = f"""
            SELECT COLUMN_NAME, DATA_TYPE
            FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = '{schema}'
            AND TABLE_NAME = '{table}'
            ORDER BY ORDINAL_POSITION
            """
            response, result = adapter.execute(sql, auto_begin=False, fetch=True)
            return [(row[0], row[1]) for row in result.rows]

        else:
            # Fallback: Use LIMIT 0 query to get columns
            sql = f"SELECT * FROM {schema}.{table} LIMIT 0"
            response, result = adapter.execute(sql, auto_begin=False, fetch=True)
            # Return column names with unknown types
            return [(col, "unknown") for col in result.column_names]

    except Exception:
        return []


def _is_integer_type(sql_type: str) -> bool:
    """Check if SQL type is an integer type."""
    sql_type_upper = sql_type.upper()
    return any(
        int_type in sql_type_upper
        for int_type in ["INT", "INTEGER", "BIGINT", "SMALLINT", "SERIAL"]
    )


def _is_timestamp_type(sql_type: str) -> bool:
    """Check if SQL type is a timestamp/date type."""
    sql_type_upper = sql_type.upper()
    return any(time_type in sql_type_upper for time_type in ["TIMESTAMP", "DATETIME", "DATE"])
