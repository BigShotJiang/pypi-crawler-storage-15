"""
yu-pytools - Python tools for climate data analysis
"""

__version__ = "1.0.0"
__author__ = "YuHaoRan <yuhaoran251@mails.ucas.ac.cn>"

# 这里可以导入你的模块
from .etccdi import *