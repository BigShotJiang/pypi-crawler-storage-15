"""
EventImpact model - Event performance tracking for notification/monitor triggers.
"""

from datetime import datetime
from typing import Optional, Dict, Any
from sqlalchemy import (
    String, Numeric, DateTime, Index, text, func
)
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import Mapped, mapped_column
import uuid

from ..base import Base


class EventImpacts(Base):
    """
    Event Impact model for tracking price performance of triggered events.

    Records price changes at different time windows (t0, +30m, +4h, +24h)
    to support post-event analysis and strategy iteration.

    Corresponds to table: EventImpacts
    """

    __tablename__ = "EventImpacts"

    # Primary key
    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        server_default=text("gen_random_uuid()"),
        comment="Primary key UUID"
    )

    # === Source Information ===
    source_type: Mapped[str] = mapped_column(
        String(50),
        nullable=False,
        comment="Event source: news, twitter, manual"
    )
    source_id: Mapped[str] = mapped_column(
        String,
        nullable=False,
        comment="Reference to CryptoNews.id or AIAnalysisResult.id"
    )

    # === Token & Priority ===
    symbol: Mapped[str] = mapped_column(
        String(50),
        nullable=False,
        comment="Main token symbol (uppercase)"
    )
    priority: Mapped[str] = mapped_column(
        String(20),
        nullable=False,
        comment="Event priority: critical, high, medium, low"
    )

    # === Snapshot Configuration ===
    snapshot_config: Mapped[Optional[dict]] = mapped_column(
        JSONB,
        server_default=text("'{}'::jsonb"),
        comment='Sampling windows config: {"t0": "event_time", "t30m": 1800, "t4h": 14400}'
    )

    # === Price Snapshots ===
    price_t0: Mapped[Optional[float]] = mapped_column(
        Numeric(20, 8),
        comment="Price at event time (t0)"
    )
    price_30m: Mapped[Optional[float]] = mapped_column(
        Numeric(20, 8),
        comment="Price at t0 + 30 minutes"
    )
    price_4h: Mapped[Optional[float]] = mapped_column(
        Numeric(20, 8),
        comment="Price at t0 + 4 hours"
    )
    price_24h: Mapped[Optional[float]] = mapped_column(
        Numeric(20, 8),
        comment="Price at t0 + 24 hours"
    )

    # === Price Changes (Percentage) ===
    change_30m: Mapped[Optional[float]] = mapped_column(
        Numeric(10, 4),
        comment="Price change % at +30m: (price_30m - price_t0) / price_t0"
    )
    change_4h: Mapped[Optional[float]] = mapped_column(
        Numeric(10, 4),
        comment="Price change % at +4h"
    )
    change_24h: Mapped[Optional[float]] = mapped_column(
        Numeric(10, 4),
        comment="Price change % at +24h"
    )

    # === Volatility (Optional) ===
    vol_30m: Mapped[Optional[float]] = mapped_column(
        Numeric(10, 4),
        comment="30-minute volatility/amplitude (optional)"
    )

    # === Additional Context ===
    meta: Mapped[Optional[dict]] = mapped_column(
        JSONB,
        server_default=text("'{}'::jsonb"),
        comment='Additional context: filter_context, trading_recommendation summary, etc.'
    )

    # === Timestamps ===
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        nullable=False,
        server_default=func.now(),
        comment="Record creation time"
    )
    updated_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime,
        onupdate=func.now(),
        comment="Record update time"
    )

    # === Table constraints and indexes ===
    __table_args__ = (
        # Index for source lookup
        Index('idx_event_impact_source', 'source_type', 'source_id'),
        # Index for time-based queries
        Index('idx_event_impact_created_at', 'created_at'),
        # Index for priority filtering
        Index('idx_event_impact_priority', 'priority'),
        # Index for symbol lookup
        Index('idx_event_impact_symbol', 'symbol'),
        # Composite index for priority reports
        Index('idx_event_impact_priority_time', 'priority', 'created_at'),
        # GIN index for JSONB meta field
        Index('idx_event_impact_meta_gin', 'meta', postgresql_using='gin'),

        {'schema': 'public'}
    )

    def __repr__(self):
        return (
            f"<EventImpact(id={self.id}, "
            f"symbol={self.symbol}, "
            f"priority={self.priority}, "
            f"change_30m={self.change_30m})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert model to dictionary."""
        return {
            "id": str(self.id),
            "source_type": self.source_type,
            "source_id": self.source_id,
            "symbol": self.symbol,
            "priority": self.priority,
            "snapshot_config": self.snapshot_config or {},
            "price_t0": float(self.price_t0) if self.price_t0 is not None else None,
            "price_30m": float(self.price_30m) if self.price_30m is not None else None,
            "price_4h": float(self.price_4h) if self.price_4h is not None else None,
            "price_24h": float(self.price_24h) if self.price_24h is not None else None,
            "change_30m": float(self.change_30m) if self.change_30m is not None else None,
            "change_4h": float(self.change_4h) if self.change_4h is not None else None,
            "change_24h": float(self.change_24h) if self.change_24h is not None else None,
            "vol_30m": float(self.vol_30m) if self.vol_30m is not None else None,
            "meta": self.meta or {},
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }

    def calculate_change(self, price_current: float, price_base: Optional[float] = None) -> Optional[float]:
        """
        Calculate price change percentage.

        Args:
            price_current: Current price
            price_base: Base price (defaults to price_t0)

        Returns:
            Price change percentage or None
        """
        if price_base is None:
            price_base = self.price_t0

        if price_base is None or price_base == 0:
            return None

        return float((price_current - float(price_base)) / float(price_base))

    def is_positive_impact(self, threshold: float = 0.05) -> bool:
        """
        Check if event had positive price impact.

        Args:
            threshold: Minimum change threshold (default 5%)

        Returns:
            True if any time window shows positive impact above threshold
        """
        changes = [self.change_30m, self.change_4h, self.change_24h]
        return any(c is not None and float(c) > threshold for c in changes)

    def is_negative_impact(self, threshold: float = -0.05) -> bool:
        """
        Check if event had negative price impact.

        Args:
            threshold: Maximum change threshold (default -5%)

        Returns:
            True if any time window shows negative impact below threshold
        """
        changes = [self.change_30m, self.change_4h, self.change_24h]
        return any(c is not None and float(c) < threshold for c in changes)

    def get_max_impact(self) -> Optional[float]:
        """
        Get maximum absolute price change across all time windows.

        Returns:
            Maximum absolute change or None
        """
        changes = [
            abs(float(c)) for c in [self.change_30m, self.change_4h, self.change_24h]
            if c is not None
        ]
        return max(changes) if changes else None

    def has_complete_snapshot(self) -> bool:
        """
        Check if all price snapshots have been collected.

        Returns:
            True if all prices (t0, 30m, 4h, 24h) are available
        """
        return all([
            self.price_t0 is not None,
            self.price_30m is not None,
            self.price_4h is not None,
            self.price_24h is not None
        ])
