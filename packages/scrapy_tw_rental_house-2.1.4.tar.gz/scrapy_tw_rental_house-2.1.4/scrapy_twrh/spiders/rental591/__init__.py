from .rental591_spider import Rental591Spider
