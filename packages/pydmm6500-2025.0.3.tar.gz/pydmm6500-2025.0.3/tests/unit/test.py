

#
# Copilot generated test file for DMM6500 class
#


import os
import sys

import pytest
from unittest.mock import Mock, patch, MagicMock
# Add src to path to import pydmm6500
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../src')))

# Add src to path to import pydmm6500
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../src')))

from pydmm6500.dmm6500 import (
    DMM6500, Options, Function, InputImpedance, 
    RangeVoltageDC, RangeCurrentDC, ResistanceRange2W, 
    ResistanceRange4W, Screen
)


@pytest.fixture
def mock_visa():
    """Mock PyVISA ResourceManager and instrument."""
    with patch('pydmm6500.dmm6500.pyvisa.ResourceManager') as mock_rm:
        mock_instrument = MagicMock()
        mock_instrument.query.return_value = 'Keithley DMM6500\n'
        mock_rm.return_value.open_resource.return_value = mock_instrument
        yield mock_rm, mock_instrument


@pytest.fixture
def dmm(mock_visa):
    """Create DMM6500 instance with mocked VISA."""
    options = Options(
        name="TestDMM",
        ip="192.168.1.100",
        reset=False,
        debug=False
    )
    return DMM6500(options)


class TestDMM6500Initialization:
    """Test DMM6500 initialization and basic properties."""
    
    def test_init_with_reset_false(self, mock_visa):
        """Test initialization without reset."""
        mock_rm, mock_instrument = mock_visa
        options = Options(
            name="TestDMM",
            ip="192.168.1.100",
            reset=False,
            debug=False
        )
        dmm = DMM6500(options)
        
        assert dmm.name == "TestDMM"
        assert dmm._ip == "192.168.1.100"
        assert dmm._reset is False
        # Reset commands should NOT be called
        assert not any('*rst' in str(call) for call in mock_instrument.write.call_args_list)
    
    def test_init_with_reset_true(self, mock_visa):
        """Test initialization with reset."""
        mock_rm, mock_instrument = mock_visa
        options = Options(
            name="TestDMM",
            ip="192.168.1.100",
            reset=True,
            debug=False
        )
        dmm = DMM6500(options)
        
        # Reset commands should be called
        calls = [str(call) for call in mock_instrument.write.call_args_list]
        assert any('*rst' in call for call in calls)
        assert any('*cls' in call for call in calls)
    
    def test_init_defaults(self, dmm):
        """Test default values after initialization."""
        assert dmm.function is None
        assert dmm.range is None
        assert dmm.nplc is None
        assert dmm.count is None
        assert dmm.input_impedance == InputImpedance.AUTO
        assert dmm.aperture is None
        assert dmm.sample_rate is None


class TestFunctionProperty:
    """Test Function property setter and getter."""
    
    def test_set_valid_function(self, dmm):
        """Test setting valid function."""
        dmm.function = Function.VOLTAGE_DC
        assert dmm.function == Function.VOLTAGE_DC
    
    def test_set_all_functions(self, dmm):
        """Test setting all available functions."""
        for func in Function:
            dmm.function = func
            assert dmm.function == func
    
    def test_set_invalid_function_type(self, dmm):
        """Test setting invalid function type raises error."""
        with pytest.raises(AssertionError, match="Type error"):
            dmm.function = "VOLTAGE_DC"
    
    def test_set_invalid_function_value(self, dmm):
        """Test setting invalid function value raises error."""
        with pytest.raises(AssertionError, match="Type error"):
            dmm.function = 123


class TestRangeProperty:
    """Test Range property setter and getter."""
    
    def test_set_range_without_function_fails(self, dmm):
        """Test setting range without defining function first."""
        with pytest.raises(AssertionError, match="must be defined before use"):
            dmm.range = RangeVoltageDC.RANGE_10V
    
    def test_set_voltage_dc_range(self, dmm):
        """Test setting voltage DC range."""
        dmm.function = Function.VOLTAGE_DC
        dmm.range = RangeVoltageDC.RANGE_10V
        assert dmm.range == RangeVoltageDC.RANGE_10V
    
    def test_set_current_dc_range(self, dmm):
        """Test setting current DC range."""
        dmm.function = Function.CURRENT_DC
        dmm.range = RangeCurrentDC.RANGE_10mA
        assert dmm.range == RangeCurrentDC.RANGE_10mA
    
    def test_set_resistance_2w_range(self, dmm):
        """Test setting 2-wire resistance range."""
        dmm.function = Function.RESISTANCE_2W
        dmm.range = ResistanceRange2W.RANGE_10kOHM
        assert dmm.range == ResistanceRange2W.RANGE_10kOHM
    
    def test_set_resistance_4w_range(self, dmm):
        """Test setting 4-wire resistance range."""
        dmm.function = Function.RESISTANCE_4W
        dmm.range = ResistanceRange4W.RANGE_1OHM
        assert dmm.range == ResistanceRange4W.RANGE_1OHM
    
    def test_set_voltage_digitize_range(self, dmm):
        """Test setting voltage digitize range."""
        dmm.function = Function.VOLTAGE_DIGITIZE
        dmm.range = RangeVoltageDC.RANGE_100V
        assert dmm.range == RangeVoltageDC.RANGE_100V
    
    def test_set_current_digitize_range(self, dmm):
        """Test setting current digitize range."""
        dmm.function = Function.CURRENT_DIGITIZE
        dmm.range = RangeCurrentDC.RANGE_1A
        assert dmm.range == RangeCurrentDC.RANGE_1A
    
    def test_set_wrong_range_type_for_function(self, dmm):
        """Test setting wrong range type for function."""
        dmm.function = Function.VOLTAGE_DC
        with pytest.raises(AssertionError, match="Type error"):
            dmm.range = RangeCurrentDC.RANGE_10mA


class TestInputImpedanceProperty:
    """Test InputImpedance property setter and getter."""
    
    def test_set_impedance_without_function_fails(self, dmm):
        """Test setting impedance without defining voltage function first."""
        with pytest.raises(AssertionError, match="must be defined before use"):
            dmm.input_impedance = InputImpedance.MOHM10
    
    def test_set_impedance_with_voltage_dc(self, dmm):
        """Test setting impedance with VOLTAGE_DC function."""
        dmm.function = Function.VOLTAGE_DC
        dmm.input_impedance = InputImpedance.MOHM10
        assert dmm.input_impedance == InputImpedance.MOHM10
    
    def test_set_impedance_with_voltage_digitize(self, dmm):
        """Test setting impedance with VOLTAGE_DIGITIZE function."""
        dmm.function = Function.VOLTAGE_DIGITIZE
        dmm.input_impedance = InputImpedance.AUTO
        assert dmm.input_impedance == InputImpedance.AUTO
    
    def test_set_impedance_with_non_voltage_function_fails(self, dmm):
        """Test setting impedance with non-voltage function fails."""
        dmm.function = Function.CURRENT_DC
        with pytest.raises(AssertionError, match="only available for function"):
            dmm.input_impedance = InputImpedance.AUTO
    
    def test_set_invalid_impedance_type(self, dmm):
        """Test setting invalid impedance type raises error."""
        dmm.function = Function.VOLTAGE_DC
        with pytest.raises(AssertionError, match="Type error"):
            dmm.input_impedance = "AUTO"


class TestNPLCProperty:
    """Test NPLC property setter and getter."""
    
    def test_set_valid_nplc_float(self, dmm):
        """Test setting valid NPLC as float."""
        dmm.nplc = 1.5
        assert dmm.nplc == 1.5
    
    def test_set_valid_nplc_int(self, dmm):
        """Test setting valid NPLC as int."""
        dmm.nplc = 5
        assert dmm.nplc == 5
    
    def test_set_nplc_minimum(self, dmm):
        """Test setting NPLC at minimum boundary."""
        dmm.nplc = 0.0005
        assert dmm.nplc == 0.0005
    
    def test_set_nplc_maximum(self, dmm):
        """Test setting NPLC at maximum boundary."""
        dmm.nplc = 12
        assert dmm.nplc == 12
    
    def test_set_nplc_below_minimum_fails(self, dmm):
        """Test setting NPLC below minimum fails."""
        with pytest.raises(AssertionError, match="out of bounds"):
            dmm.nplc = 0.0001
    
    def test_set_nplc_above_maximum_fails(self, dmm):
        """Test setting NPLC above maximum fails."""
        with pytest.raises(AssertionError, match="out of bounds"):
            dmm.nplc = 13
    
    def test_set_nplc_invalid_type(self, dmm):
        """Test setting NPLC with invalid type fails."""
        with pytest.raises(AssertionError, match="Type error"):
            dmm.nplc = "1"


class TestCountProperty:
    """Test Count property setter and getter."""
    
    def test_set_valid_count(self, dmm):
        """Test setting valid count."""
        dmm.count = 100
        assert dmm.count == 100
    
    def test_set_count_minimum(self, dmm):
        """Test setting count at minimum boundary."""
        dmm.count = 1
        assert dmm.count == 1
    
    def test_set_count_maximum(self, dmm):
        """Test setting count at maximum boundary."""
        dmm.count = int(1e6)
        assert dmm.count == int(1e6)
    
    def test_set_count_below_minimum_fails(self, dmm):
        """Test setting count below minimum fails."""
        with pytest.raises(AssertionError, match="out of bounds"):
            dmm.count = 0
    
    def test_set_count_above_maximum_fails(self, dmm):
        """Test setting count above maximum fails."""
        with pytest.raises(AssertionError, match="out of bounds"):
            dmm.count = int(1e6) + 1
    
    def test_set_count_invalid_type(self, dmm):
        """Test setting count with invalid type fails."""
        with pytest.raises(AssertionError, match="Type error"):
            dmm.count = 100.5


class TestSampleRateProperty:
    """Test SampleRate property setter and getter."""
    
    def test_set_sample_rate_without_function_fails(self, dmm):
        """Test setting sample rate without defining digitize function first."""
        with pytest.raises(AssertionError, match="must be defined before use"):
            dmm.sample_rate = 100000
    
    def test_set_sample_rate_with_voltage_digitize(self, dmm):
        """Test setting sample rate with VOLTAGE_DIGITIZE function."""
        dmm.function = Function.VOLTAGE_DIGITIZE
        dmm.sample_rate = 100000
        assert dmm.sample_rate == 100000
    
    def test_set_sample_rate_with_current_digitize(self, dmm):
        """Test setting sample rate with CURRENT_DIGITIZE function."""
        dmm.function = Function.CURRENT_DIGITIZE
        dmm.sample_rate = 50000
        assert dmm.sample_rate == 50000
    
    def test_set_sample_rate_with_non_digitize_function_fails(self, dmm):
        """Test setting sample rate with non-digitize function fails."""
        dmm.function = Function.VOLTAGE_DC
        with pytest.raises(AssertionError, match="only available for digitize"):
            dmm.sample_rate = 100000
    
    def test_set_sample_rate_minimum(self, dmm):
        """Test setting sample rate at minimum boundary."""
        dmm.function = Function.VOLTAGE_DIGITIZE
        dmm.sample_rate = 1000
        assert dmm.sample_rate == 1000
    
    def test_set_sample_rate_maximum(self, dmm):
        """Test setting sample rate at maximum boundary."""
        dmm.function = Function.VOLTAGE_DIGITIZE
        dmm.sample_rate = 1000000
        assert dmm.sample_rate == 1000000
    
    def test_set_sample_rate_below_minimum_fails(self, dmm):
        """Test setting sample rate below minimum fails."""
        dmm.function = Function.VOLTAGE_DIGITIZE
        with pytest.raises(AssertionError, match="out of bounds"):
            dmm.sample_rate = 999
    
    def test_set_sample_rate_above_maximum_fails(self, dmm):
        """Test setting sample rate above maximum fails."""
        dmm.function = Function.VOLTAGE_DIGITIZE
        with pytest.raises(AssertionError, match="out of bounds"):
            dmm.sample_rate = 1000001


class TestApertureProperty:
    """Test Aperture property setter and getter."""
    
    def test_set_aperture_without_function_fails(self, dmm):
        """Test setting aperture without defining digitize function first."""
        with pytest.raises(AssertionError, match="must be defined before use"):
            dmm.aperture = 0.001
    
    def test_set_aperture_without_sample_rate_fails(self, dmm):
        """Test setting aperture without defining sample rate first."""
        dmm.function = Function.VOLTAGE_DIGITIZE
        with pytest.raises(AssertionError, match="must be defined before use"):
            dmm.aperture = 0.001
    
    def test_set_valid_aperture(self, dmm):
        """Test setting valid aperture."""
        dmm.function = Function.VOLTAGE_DIGITIZE
        dmm.sample_rate = 100000
        dmm.aperture = 0.00001
        assert dmm.aperture == 0.00001
    
    def test_set_aperture_minimum(self, dmm):
        """Test setting aperture at minimum boundary."""
        dmm.function = Function.VOLTAGE_DIGITIZE
        dmm.sample_rate = 100000
        dmm.aperture = 1e-6
        assert dmm.aperture == 1e-6
    
    def test_set_aperture_maximum(self, dmm):
        """Test setting aperture at maximum (1/sample_rate)."""
        dmm.function = Function.VOLTAGE_DIGITIZE
        dmm.sample_rate = 100000
        max_aperture = 1 / 100000
        dmm.aperture = max_aperture
        assert dmm.aperture == max_aperture
    
    def test_set_aperture_exceeds_max_fails(self, dmm):
        """Test setting aperture exceeding 1/sample_rate fails."""
        dmm.function = Function.VOLTAGE_DIGITIZE
        dmm.sample_rate = 100000
        with pytest.raises(AssertionError, match="out of bounds"):
            dmm.aperture = 1 / 100000 + 0.00001
    
    def test_set_aperture_below_minimum_fails(self, dmm):
        """Test setting aperture below minimum fails."""
        dmm.function = Function.VOLTAGE_DIGITIZE
        dmm.sample_rate = 100000
        with pytest.raises(AssertionError, match="out of bounds"):
            dmm.aperture = 0.5e-6


class TestConfigureMethod:
    """Test Configure method."""
    
    def test_configure_voltage_dc(self, dmm, mock_visa):
        """Test configure method with VOLTAGE_DC function."""
        mock_rm, mock_instrument = mock_visa
        dmm.function = Function.VOLTAGE_DC
        dmm.range = RangeVoltageDC.RANGE_10V
        dmm.nplc = 1
        dmm.count = 10
        dmm.input_impedance = InputImpedance.AUTO
        
        dmm.configure()
        
        # Verify SCPI commands were written
        calls = [str(call) for call in mock_instrument.write.call_args_list]
        assert any('voltage:dc' in call for call in calls)
        assert any('10' in call for call in calls)
        assert any('nplc' in call for call in calls)
    
    def test_configure_current_dc(self, dmm, mock_visa):
        """Test configure method with CURRENT_DC function."""
        mock_rm, mock_instrument = mock_visa
        dmm.function = Function.CURRENT_DC
        dmm.range = RangeCurrentDC.RANGE_1mA
        dmm.nplc = 1
        dmm.count = 5
        
        dmm.configure()
        
        # Verify SCPI commands were written
        calls = [str(call) for call in mock_instrument.write.call_args_list]
        assert any('current:dc' in call for call in calls)
    
    def test_configure_voltage_digitize(self, dmm, mock_visa):
        """Test configure method with VOLTAGE_DIGITIZE function."""
        mock_rm, mock_instrument = mock_visa
        dmm.function = Function.VOLTAGE_DIGITIZE
        dmm.range = RangeVoltageDC.RANGE_100V
        dmm.sample_rate = 100000
        dmm.aperture = 0.00001
        dmm.count = 1000
        
        dmm.configure()
        
        # Verify SCPI commands were written with digitize
        calls = [str(call) for call in mock_instrument.write.call_args_list]
        assert any('digitize' in call for call in calls)
        assert any('srate' in call for call in calls)
        assert any('aperture' in call for call in calls)
    
    def test_configure_resistance_4w(self, dmm, mock_visa):
        """Test configure method with RESISTANCE_4W function."""
        mock_rm, mock_instrument = mock_visa
        dmm.function = Function.RESISTANCE_4W
        dmm.range = ResistanceRange4W.RANGE_100OHM
        dmm.nplc = 10
        dmm.count = 20
        
        dmm.configure()
        
        # Verify SCPI commands were written
        calls = [str(call) for call in mock_instrument.write.call_args_list]
        assert any('fresistance' in call for call in calls)


class TestRetrieveBuffer:
    """Test retrieve_buffer method."""
    
    def test_retrieve_buffer_basic(self, dmm, mock_visa):
        """Test basic buffer retrieval."""
        mock_rm, mock_instrument = mock_visa
        
        # Mock the query responses
        mock_instrument.query_ascii_values.side_effect = [
            [1],  # start_index
            [10],  # end_index
            [1.0, 0.1, 100.5, 2.0, 0.2, 101.2, 3.0, 0.3, 102.1]  # buffer data (sec, frac, reading)
        ]
        
        timestamps, values = dmm.retrieve_buffer()
        
        # Verify timestamps are combined from seconds and fractional parts
        assert len(timestamps) == 3
        assert timestamps[0] == 1.1  # 1.0 + 0.1
        assert timestamps[1] == 2.2  # 2.0 + 0.2
        assert timestamps[2] == 3.3  # 3.0 + 0.3
        
        # Verify values
        assert len(values) == 3
        assert values == [100.5, 101.2, 102.1]
    
    def test_retrieve_buffer_custom_name(self, dmm, mock_visa):
        """Test buffer retrieval with custom buffer name."""
        mock_rm, mock_instrument = mock_visa
        mock_instrument.query_ascii_values.side_effect = [
            [1], [10], [0.0, 0.0, 50.0]
        ]
        
        timestamps, values = dmm.retrieve_buffer('custom_buffer')
        
        # Verify custom buffer name was used in query
        calls = [call for call in mock_instrument.query_ascii_values.call_args_list]
        assert any('custom_buffer' in str(call) for call in calls)


class TestEnums:
    """Test enum values and completeness."""
    
    def test_function_enum_values(self):
        """Test Function enum has all required values."""
        assert Function.VOLTAGE_DC.value == 'voltage:dc'
        assert Function.CURRENT_DC.value == 'current:dc'
        assert Function.RESISTANCE_2W.value == 'resistance'
        assert Function.RESISTANCE_4W.value == 'fresistance'
        assert Function.VOLTAGE_DIGITIZE.value == 'voltage'
        assert Function.CURRENT_DIGITIZE.value == 'current'
    
    def test_input_impedance_enum_values(self):
        """Test InputImpedance enum has all required values."""
        assert InputImpedance.MOHM10.value == 'MOHM10'
        assert InputImpedance.AUTO.value == 'AUTO'
    
    def test_range_voltage_dc_enum(self):
        """Test RangeVoltageDC enum values."""
        assert RangeVoltageDC.RANGE_AUTO.value == ':auto on'
        assert RangeVoltageDC.RANGE_10V.value == ' 10'
        assert RangeVoltageDC.RANGE_1000V.value == ' 1000'
    
    def test_range_current_dc_enum(self):
        """Test RangeCurrentDC enum values."""
        assert RangeCurrentDC.RANGE_AUTO.value == ':auto on'
        assert RangeCurrentDC.RANGE_1A.value == ' 1'
    
    def test_resistance_range_2w_enum(self):
        """Test ResistanceRange2W enum values."""
        assert ResistanceRange2W.RANGE_AUTO.value == ':auto on'
        assert ResistanceRange2W.RANGE_100MOHM.value == ' 100e6'
    
    def test_resistance_range_4w_enum(self):
        """Test ResistanceRange4W enum values."""
        assert ResistanceRange4W.RANGE_1OHM.value == ' 1'
        assert ResistanceRange4W.RANGE_100MOHM.value == ' 100e6'
    
    def test_screen_enum_values(self):
        """Test Screen enum values."""
        assert Screen.HOME.value == 'home'
        assert Screen.GRAPH.value == 'graph'
        assert Screen.READINGS.value == 'reading_table'


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
