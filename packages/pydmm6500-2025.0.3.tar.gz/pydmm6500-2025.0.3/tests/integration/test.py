
import os
import sys

# Add src to path to import pydmm6500
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../src')))

import pydmm6500.dmm6500 as dmm6500


if __name__ == "__main__":
    
    options = dmm6500.Options(
        name = "Test",
        ip = "192.168.1.213",
        reset = False,
        debug = True
    )
    
    dmm = dmm6500.DMM6500(options)
    
    dmm.function = dmm6500.Function.VOLTAGE_DC
    dmm.range = dmm6500.RangeVoltageDC.RANGE_10V
    dmm.input_impedance = dmm6500.InputImpedance.AUTO
    dmm.nplc = 1
    dmm.count = 15
    dmm.configure()
    
    v = dmm.measure()
    print(v)
    
    dmm.beep_triad()
