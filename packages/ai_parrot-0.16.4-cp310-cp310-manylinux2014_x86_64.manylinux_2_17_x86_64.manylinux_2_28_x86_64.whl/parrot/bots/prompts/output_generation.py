# parrot/prompts/output_generation.py

OUTPUT_SYSTEM_PROMPT = """

## Requested Output Format:
{output_mode}

"""
