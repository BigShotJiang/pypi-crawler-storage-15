﻿eegdash.features.extractors
===========================

.. automodule:: eegdash.features.extractors
   :members:
   :undoc-members:
   :show-inheritance:
   :member-order: bysource

   
   .. rubric:: Classes

   .. autosummary::
   
      BivariateFeature
      DirectedBivariateFeature
      FeatureExtractor
      MultivariateFeature
      TrainableFeature
      UnivariateFeature
   

