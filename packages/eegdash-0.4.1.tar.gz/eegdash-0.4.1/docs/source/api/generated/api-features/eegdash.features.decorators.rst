﻿eegdash.features.decorators
===========================

.. automodule:: eegdash.features.decorators
   :members:
   :undoc-members:
   :show-inheritance:
   :member-order: bysource

   
   .. rubric:: Module Attributes

   .. autosummary::
   
      univariate_feature
      multivariate_feature
   
   .. rubric:: Functions

   .. autosummary::
   
      bivariate_feature
   
   .. rubric:: Classes

   .. autosummary::
   
      FeatureKind
      FeaturePredecessor
   

