﻿eegdash.bids\_eeg\_metadata
===========================

.. automodule:: eegdash.bids_eeg_metadata
   :members:
   :undoc-members:
   :show-inheritance:
   :member-order: bysource

   
   .. rubric:: Functions

   .. autosummary::
   
      participants_row_for_subject
      participants_extras_from_tsv
      attach_participants_extras
      enrich_from_participants
   

