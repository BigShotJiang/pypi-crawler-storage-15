﻿eegdash.hbn
===========

.. automodule:: eegdash.hbn
   :members:
   :undoc-members:
   :show-inheritance:
   :member-order: bysource

   
   .. rubric:: Functions

   .. autosummary::
   
      build_trial_table
      annotate_trials_with_target
      add_aux_anchors
      add_extras_columns
      keep_only_recordings_with
   
   .. rubric:: Classes

   .. autosummary::
   
      hbn_ec_ec_reannotation
   

