﻿eegdash.const
=============

.. automodule:: eegdash.const
   :members:
   :undoc-members:
   :show-inheritance:
   :member-order: bysource

   
   .. rubric:: Module Attributes

   .. autosummary::
   
      ALLOWED_QUERY_FIELDS
      RELEASE_TO_OPENNEURO_DATASET_MAP
      SUBJECT_MINI_RELEASE_MAP
      config
   

