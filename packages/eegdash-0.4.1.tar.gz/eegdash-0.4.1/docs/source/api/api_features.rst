Feature API
===========

.. autosummary::
   :toctree: generated/api-features
   :recursive:

   eegdash.features
   eegdash.features.datasets
   eegdash.features.decorators
   eegdash.features.extractors
   eegdash.features.inspect
   eegdash.features.serialization
   eegdash.features.utils
   eegdash.features.feature_bank

