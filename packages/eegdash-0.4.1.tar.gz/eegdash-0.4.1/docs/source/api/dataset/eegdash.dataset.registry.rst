eegdash.dataset.registry module
===============================

.. automodule:: eegdash.dataset.registry
   :members:
   :noindex:
   :show-inheritance:
   :undoc-members:
