..
   This file is auto-generated during the Sphinx build.
   Do not edit by hand; changes will be overwritten.

eegdash.dataset.DS003490
========================

.. currentmodule:: eegdash.dataset

.. autoclass:: eegdash.dataset.DS003490
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :member-order: bysource

Dataset Information
-------------------

- **Dataset ID:** ``DS003490``
- **Summary:** Modality: Auditory | Type: Attention | Subjects: Parkinson's
- **Number of Subjects:** 50
- **Number of Recordings:** 75
- **Number of Tasks:** 1
- **Number of Channels:** 64
- **Sampling Frequencies:** 500
- **Total Duration (hours):** 12.76
- **Dataset Size:** 5.85 GB
- **OpenNeuro:** `ds003490 <https://openneuro.org/datasets/ds003490>`__
- **NeMAR:** `ds003490 <https://nemar.org/dataexplorer/detail?dataset_id=ds003490>`__

=========  =======  =======  ==========  ==========  =============  =======
dataset      #Subj    #Chan    #Classes    Freq(Hz)    Duration(H)  Size
=========  =======  =======  ==========  ==========  =============  =======
ds003490        50       64           1         500          12.76  5.85 GB
=========  =======  =======  ==========  ==========  =============  =======


Usage Example
-------------

.. code-block:: python

   from eegdash.dataset import DS003490

   dataset = DS003490(cache_dir="./data")

   print(f"Number of recordings: {len(dataset)}")

   if len(dataset):
       recording = dataset[0]
       raw = recording.load()
       print(f"Sampling rate: {raw.info['sfreq']} Hz")
       print(f"Channels: {len(raw.ch_names)}")


See Also
--------

* :class:`eegdash.dataset.EEGDashDataset`
* :mod:`eegdash.dataset`
* `OpenNeuro dataset page <https://openneuro.org/datasets/ds003490>`__
* `NeMAR dataset page <https://nemar.org/dataexplorer/detail?dataset_id=ds003490>`__

