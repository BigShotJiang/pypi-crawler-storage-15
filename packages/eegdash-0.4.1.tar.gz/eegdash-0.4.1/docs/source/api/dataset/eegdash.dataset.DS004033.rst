..
   This file is auto-generated during the Sphinx build.
   Do not edit by hand; changes will be overwritten.

eegdash.dataset.DS004033
========================

.. currentmodule:: eegdash.dataset

.. autoclass:: eegdash.dataset.DS004033
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :member-order: bysource

Dataset Information
-------------------

- **Dataset ID:** ``DS004033``
- **Summary:** Modality: Motor | Type: Motor
- **Number of Subjects:** 18
- **Number of Recordings:** 36
- **Number of Tasks:** 2
- **Number of Channels:** 64
- **Sampling Frequencies:** 500
- **Total Duration (hours):** 42.645
- **Dataset Size:** 19.81 GB
- **OpenNeuro:** `ds004033 <https://openneuro.org/datasets/ds004033>`__
- **NeMAR:** `ds004033 <https://nemar.org/dataexplorer/detail?dataset_id=ds004033>`__

=========  =======  =======  ==========  ==========  =============  ========
dataset      #Subj    #Chan    #Classes    Freq(Hz)    Duration(H)  Size
=========  =======  =======  ==========  ==========  =============  ========
ds004033        18       64           2         500         42.645  19.81 GB
=========  =======  =======  ==========  ==========  =============  ========


Usage Example
-------------

.. code-block:: python

   from eegdash.dataset import DS004033

   dataset = DS004033(cache_dir="./data")

   print(f"Number of recordings: {len(dataset)}")

   if len(dataset):
       recording = dataset[0]
       raw = recording.load()
       print(f"Sampling rate: {raw.info['sfreq']} Hz")
       print(f"Channels: {len(raw.ch_names)}")


See Also
--------

* :class:`eegdash.dataset.EEGDashDataset`
* :mod:`eegdash.dataset`
* `OpenNeuro dataset page <https://openneuro.org/datasets/ds004033>`__
* `NeMAR dataset page <https://nemar.org/dataexplorer/detail?dataset_id=ds004033>`__

