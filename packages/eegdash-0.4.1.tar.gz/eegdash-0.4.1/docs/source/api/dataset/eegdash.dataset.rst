eegdash.dataset package
=======================

.. automodule:: eegdash.dataset
   :members:
   :noindex:
   :show-inheritance:
   :undoc-members:

Submodules
----------

.. toctree::
   :maxdepth: 4

   eegdash.dataset.dataset
   eegdash.dataset.registry
