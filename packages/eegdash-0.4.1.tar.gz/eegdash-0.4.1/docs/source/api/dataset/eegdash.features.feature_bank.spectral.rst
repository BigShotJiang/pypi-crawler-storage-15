eegdash.features.feature\_bank.spectral module
==============================================

.. automodule:: eegdash.features.feature_bank.spectral
   :members:
   :noindex:
   :show-inheritance:
   :undoc-members:
