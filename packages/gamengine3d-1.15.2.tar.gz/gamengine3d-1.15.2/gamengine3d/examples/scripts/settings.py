from gamengine3d import Color, vector3d

cylinder_colors = [Color.light_red, Color.light_green, Color.light_blue, Color.light_yellow, Color.orange, Color.magenta]
num_cylinder_colors = len(cylinder_colors)

sphere_pos = vector3d(0, 1, 4)
