Examples
========

This folder contains examples for the disnake-compass library.
Note that the examples in this directory are, for the most part, without comments.

These same examples can be found with extra explanations in [disnake-compass' documentation](https:/disnake-compass.readthedocs.io/en/docs/examples).
