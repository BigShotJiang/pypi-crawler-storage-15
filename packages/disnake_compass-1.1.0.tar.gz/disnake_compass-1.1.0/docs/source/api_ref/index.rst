.. _api_ref:

disnake_compass
======================

.. automodule:: disnake_compass

Subpackages
-----------

.. toctree::
   :maxdepth: 1

   api </api_ref/api/index>
   impl </api_ref/impl/index>
   internal </api_ref/internal/index>


Submodules
----------

.. toctree::
   :maxdepth: 1

   fields </api_ref/fields>
