.. _internal:

disnake_compass.internal
===============================

.. automodule:: disnake_compass.internal

Submodules
----------

.. toctree::
   :maxdepth: 1

   di </api_ref/internal/di>
