.. currentmodule:: disnake_compass

DI Implementation
=====================

.. automodule:: disnake_compass.internal.di


Functions
---------

.. autofunction:: register_dependencies

.. autofunction:: reset_dependencies

.. autofunction:: resolve_dependency
