.. currentmodule:: disnake_compass.impl

User Parser Implementation
==========================

.. automodule:: disnake_compass.impl.parser.user


Classes
-------

.. attributetable:: disnake_compass.impl.parser.user.UserParser

.. autoclass:: disnake_compass.impl.parser.user.UserParser
    :members:

.. attributetable:: disnake_compass.impl.parser.user.MemberParser

.. autoclass:: disnake_compass.impl.parser.user.MemberParser
    :members:
