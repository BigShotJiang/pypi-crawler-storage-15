.. currentmodule:: disnake_compass.impl

Message Parser Implementation
=============================

.. automodule:: disnake_compass.impl.parser.message


Classes
-------

.. attributetable:: disnake_compass.impl.parser.message.PartialMessageParser

.. autoclass:: disnake_compass.impl.parser.message.PartialMessageParser
    :members:

.. attributetable:: disnake_compass.impl.parser.message.MessageParser

.. autoclass:: disnake_compass.impl.parser.message.MessageParser
    :members:
