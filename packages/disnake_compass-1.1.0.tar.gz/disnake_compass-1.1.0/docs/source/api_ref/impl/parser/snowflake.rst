.. currentmodule:: disnake_compass.impl

Snowflake Parser Implementation
===============================

.. automodule:: disnake_compass.impl.parser.snowflake


Classes
-------

.. attributetable:: disnake_compass.impl.parser.snowflake.SnowflakeParser

.. autoclass:: disnake_compass.impl.parser.snowflake.SnowflakeParser
    :members:
