.. currentmodule:: disnake_compass.impl

Enum Parser Implementation
==========================

.. automodule:: disnake_compass.impl.parser.enum


Classes
-------

.. attributetable:: disnake_compass.impl.parser.enum.EnumParser

.. autoclass:: disnake_compass.impl.parser.enum.EnumParser
    :members:


.. autoclass:: disnake_compass.impl.parser.enum.FlagParser
