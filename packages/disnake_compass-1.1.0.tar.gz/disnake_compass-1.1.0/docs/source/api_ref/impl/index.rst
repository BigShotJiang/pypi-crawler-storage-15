disnake_compass.impl
===========================

.. automodule:: disnake_compass.impl

Subpackages
-----------

.. toctree::
   :maxdepth: 1

   component </api_ref/impl/component/index>
   parser </api_ref/impl/parser/index>

Submodules
----------

.. toctree::
   :maxdepth: 1

   manager </api_ref/impl/manager>
   factory </api_ref/impl/factory>
