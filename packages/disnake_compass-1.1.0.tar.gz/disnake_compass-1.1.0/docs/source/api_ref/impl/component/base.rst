.. currentmodule:: disnake_compass

Rich Component Base Implementation
==================================

.. automodule:: disnake_compass.impl.component.base

Classes
-------

.. attributetable:: disnake_compass.impl.component.base.ComponentMeta

.. autoclass:: disnake_compass.impl.component.base.ComponentMeta
    :members:

.. attributetable:: disnake_compass.impl.component.base.ComponentBase

.. autoclass:: disnake_compass.impl.component.base.ComponentBase
    :members:
