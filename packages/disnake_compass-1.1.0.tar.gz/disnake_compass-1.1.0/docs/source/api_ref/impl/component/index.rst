disnake_compass.impl.component
=====================================

.. automodule:: disnake_compass.impl.component

Submodules
----------

.. toctree::
    :maxdepth: 1

    base </api_ref/impl/component/base>
    button </api_ref/impl/component/button>
    select </api_ref/impl/component/select>
