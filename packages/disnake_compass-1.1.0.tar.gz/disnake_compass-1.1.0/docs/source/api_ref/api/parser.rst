.. currentmodule:: disnake_compass

Parser API
==========

.. automodule:: disnake_compass.api.parser


Typing
------

.. autodata:: ParserType


Classes
-------

.. attributetable:: disnake_compass.api.parser.Parser

.. autoclass:: disnake_compass.api.parser.Parser
    :members:
