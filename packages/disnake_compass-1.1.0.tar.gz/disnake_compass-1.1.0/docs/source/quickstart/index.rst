Quickstart Guide
================

This brief guide walks you through everything you need to know to get started with disnake-compass.
For more detailed information on specific parts of the library, please refer to the :ref:`Api Reference <api_ref>`.

Please navigate the following sections to learn more.

.. toctree::
   :maxdepth: 1

   The Basics <basics>
