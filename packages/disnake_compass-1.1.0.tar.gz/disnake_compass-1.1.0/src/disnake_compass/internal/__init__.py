# pyright: reportImportCycles = false
# pyright: reportWildcardImportFromLibrary = false
# ^ This is a false positive as it is confused with site-packages' disnake.

"""Utilities mostly intended for internal use.

These may also be of help when creating custom implementations of protocols
detailed in ``disnake_compass.api``.
"""
