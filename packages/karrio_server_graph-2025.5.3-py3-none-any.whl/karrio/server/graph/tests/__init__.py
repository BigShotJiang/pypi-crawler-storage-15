import logging

logging.disable(logging.CRITICAL)

from karrio.server.graph.tests.test_templates import *
from karrio.server.graph.tests.test_carrier_connections import *
from karrio.server.graph.tests.test_user_info import *
from karrio.server.graph.tests.test_rate_sheets import *
from karrio.server.graph.tests.test_metafield import *
