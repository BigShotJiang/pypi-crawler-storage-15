from noetl.cli.ctl import cli_app


def main():
    cli_app()


if __name__ == "__main__":
    main()
