"""
Context API package - handles template rendering and execution context.
"""

from .endpoints import router

__all__ = ['router']
