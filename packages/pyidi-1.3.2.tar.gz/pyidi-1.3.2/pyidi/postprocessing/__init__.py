"""
A sub-module containing pyIDI post-processing functionality.
"""

from ._motion_magnification import mode_shape_magnification
from ._motion_magnification import animate