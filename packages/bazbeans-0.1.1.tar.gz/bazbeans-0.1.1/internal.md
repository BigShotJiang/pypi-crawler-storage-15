# Upload to PyPI

twine upload dist\bazbeans-0.1.0.tar.gz dist\bazbeans-0.1.0-py3-none-any.whl

- get the API Key from %HOME%\.pypirc
- it's also in ProtonDrive Secure Saves
- it's also in Proton Key Store

# Local Build

python3 -m build 