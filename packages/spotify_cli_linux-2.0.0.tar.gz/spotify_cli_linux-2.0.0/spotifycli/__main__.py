import sys
from .spotifycli import main
sys.exit(main())
