Release notes
=============

.. toctree::
   :maxdepth: 2

   notes
   old

.. note::

   For release notes (sparsely) kept prior to 1.0.0, look at the `releases page
   on GitHub <https://github.com/numpy/numpydoc/releases>`__.
