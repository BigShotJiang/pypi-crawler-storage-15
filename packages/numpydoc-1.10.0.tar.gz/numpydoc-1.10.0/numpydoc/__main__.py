"""
Implementing `python -m numpydoc` functionality
"""  # '.' omitted at end of docstring for testing purposes!

from .cli import main

raise SystemExit(main())
