"""MCP Git Analyzer Server - FastMCP implementation."""

from typing import Annotated, Literal
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from dataclasses import dataclass

from mcp.server.fastmcp import FastMCP, Context
from mcp.types import ToolAnnotations

from mcp_git_analyzer.db import Database
from mcp_git_analyzer.tools import GitTools, AnalysisTools, SearchTools, ReportTools, AlgorithmTools


@dataclass
class AppContext:
    """Application context with typed dependencies."""
    db: Database
    git: GitTools
    analysis: AnalysisTools
    search: SearchTools
    report: ReportTools
    algorithm: AlgorithmTools


# Lifespan context to manage database and tools
@asynccontextmanager
async def lifespan(server: FastMCP) -> AsyncIterator[AppContext]:
    """Initialize database and tools on startup."""
    db = Database()
    git_tools = GitTools(db)
    analysis_tools = AnalysisTools(db)
    search_tools = SearchTools(db)
    report_tools = ReportTools(db, analysis_tools, search_tools)
    algorithm_tools = AlgorithmTools(db)
    
    yield AppContext(
        db=db,
        git=git_tools,
        analysis=analysis_tools,
        search=search_tools,
        report=report_tools,
        algorithm=algorithm_tools
    )


# Server instructions for AI assistants
SERVER_INSTRUCTIONS = """
## MCP Git Analyzer - Usage Guidelines

### Recommended Workflow
1. `clone_repo` → Clone target repository
2. `analyze_repo` → Parse and extract all symbols/patterns
3. `get_repo_summary` or `generate_report` → Get overview
4. `list_symbols`, `find_patterns`, `list_algorithms` → Explore specifics
5. `get_file_analysis`, `inspect_symbol` → Deep dive into details

### CRITICAL: Number/Count Rules
- ALWAYS use exact values from `statistics` fields in responses
- NEVER estimate with "50+", "약 40개" - use actual counts
- Example: If `statistics.total_functions` is 47, say "47개의 함수"

### Response Structure (for porting/migration tasks)
Your response MUST include these sections in order:

1. **원본 라이브러리 기능 요약** (Source Library Summary)
   - List actual functions/symbols from `list_symbols` or `get_file_analysis`
   - Show file-by-file breakdown with exact function names
   - Include signatures from `symbols[].signature` field

2. **설계/아키텍처** (Design/Architecture)  
   - Map source files to target modules
   - Use patterns from `find_patterns` results

3. **마이그레이션 로드맵** (Migration Roadmap)
   - Phased plan based on actual code structure

### Verbatim Fields (MUST show in response)
- `symbols[].name` and `symbols[].signature` from `get_file_analysis`
- `algorithms[].symbol_name` from `list_algorithms`
- `statistics.*` counts from `analyze_repo`
- `source_code` from `inspect_symbol` when discussing implementation

### For Detailed Guidelines
Read resource: `guidelines://tool-usage`
""".strip()


# Initialize MCP server
mcp = FastMCP(
    "Git Analyzer",
    lifespan=lifespan,
    instructions=SERVER_INSTRUCTIONS
)


# ============================================================================
# Git Management Tools
# ============================================================================

@mcp.tool(
    annotations=ToolAnnotations(
        title="Clone Repository",
        readOnlyHint=False,
        idempotentHint=True,
        openWorldHint=True
    )
)
def clone_repo(
    url: Annotated[str, "Git repository URL (HTTPS or SSH)"],
    branch: Annotated[str | None, "Branch to checkout (default: repository's default branch)"] = None,
    ctx: Context = None
) -> dict:
    """
    Clone a Git repository for analysis.
    
    Downloads the repository to local storage and registers it in the database.
    Use this before analyzing a repository.
    """
    git: GitTools = ctx.request_context.lifespan_context.git
    return git.clone_repo(url, branch)


@mcp.tool(
    annotations=ToolAnnotations(
        title="List Repositories",
        readOnlyHint=True,
        idempotentHint=True
    )
)
def list_repos(ctx: Context = None) -> dict:
    """
    List all registered repositories.
    
    Returns all repositories that have been cloned, along with their
    analysis status and basic statistics.
    """
    git: GitTools = ctx.request_context.lifespan_context.git
    return git.list_repos()


@mcp.tool(
    annotations=ToolAnnotations(
        title="Get Repository File Tree",
        readOnlyHint=True,
        idempotentHint=True
    )
)
def get_repo_tree(
    repo_id: Annotated[int, "Repository ID from list_repos"],
    max_depth: Annotated[int, "Maximum directory depth to show"] = 3,
    ctx: Context = None
) -> dict:
    """
    Get the file structure of a repository.
    
    Returns a tree view of directories and files with language detection.
    Useful for understanding project organization.
    """
    git: GitTools = ctx.request_context.lifespan_context.git
    return git.get_repo_tree(repo_id, max_depth)


@mcp.tool(
    annotations=ToolAnnotations(
        title="Delete Repository",
        readOnlyHint=False,
        destructiveHint=True,
        idempotentHint=True
    )
)
def delete_repo(
    repo_id: Annotated[int, "Repository ID to delete"],
    delete_files: Annotated[bool, "Also delete cloned files from disk"] = False,
    ctx: Context = None
) -> dict:
    """
    Delete a repository from the database.
    
    Removes the repository record and all associated analysis data.
    Optionally deletes the cloned files from disk.
    """
    git: GitTools = ctx.request_context.lifespan_context.git
    return git.delete_repo(repo_id, delete_files)


# ============================================================================
# Analysis Tools
# ============================================================================

@mcp.tool(
    annotations=ToolAnnotations(
        title="Analyze Repository",
        readOnlyHint=False,
        idempotentHint=True
    )
)
async def analyze_repo(
    repo_id: Annotated[int, "Repository ID to analyze"],
    languages: Annotated[list[str] | None, "Languages to analyze (default: all supported)"] = None,
    include_call_graph: Annotated[bool, "Extract function call graph (optional, slower)"] = False,
    ctx: Context = None
) -> dict:
    """
    Analyze all files in a repository.
    
    Parses source code to extract:
    - Functions, classes, and methods with signatures
    - Docstrings and documentation
    - Import statements and dependencies
    - Algorithm and design patterns
    - Function call graph (optional)
    
    Results are stored in the database for future queries.
    """
    analysis: AnalysisTools = ctx.request_context.lifespan_context.analysis
    
    # Report progress
    msg = f"Starting analysis of repository {repo_id}"
    if include_call_graph:
        msg += " (with call graph extraction)"
    await ctx.info(msg)
    
    result = analysis.analyze_repo(repo_id, languages, include_call_graph)
    
    if result.get("status") == "success":
        stats = result.get("statistics", {})
        msg = f"Completed: {stats.get('analyzed_files', 0)} files, {stats.get('total_symbols', 0)} symbols"
        if include_call_graph:
            msg += f", {stats.get('total_calls', 0)} calls"
        await ctx.info(msg)
    
    return result


@mcp.tool(
    annotations=ToolAnnotations(
        title="Get File Analysis",
        readOnlyHint=True,
        idempotentHint=True
    )
)
def get_file_analysis(
    repo_id: Annotated[int, "Repository ID"],
    file_path: Annotated[str, "Relative path to file within repository"],
    ctx: Context = None
) -> dict:
    """
    Get detailed analysis for a specific file.
    
    Returns all extracted symbols, imports, and detected patterns
    for the specified file.
    """
    analysis: AnalysisTools = ctx.request_context.lifespan_context.analysis
    return analysis.get_file_analysis(repo_id, file_path)


@mcp.tool(
    annotations=ToolAnnotations(
        title="Get Symbol Details",
        readOnlyHint=True,
        idempotentHint=True
    )
)
def get_symbol_details(
    symbol_name: Annotated[str, "Name of the symbol (function, class, method)"],
    repo_id: Annotated[int | None, "Repository ID to limit search"] = None,
    ctx: Context = None
) -> dict:
    """
    Get detailed information about a symbol.
    
    Returns signature, docstring, parameters, location, and any
    detected patterns associated with the symbol.
    """
    analysis: AnalysisTools = ctx.request_context.lifespan_context.analysis
    return analysis.get_symbol_details(symbol_name, repo_id)


@mcp.tool(
    annotations=ToolAnnotations(
        title="Get Repository Summary",
        readOnlyHint=True,
        idempotentHint=True
    )
)
def get_repo_summary(
    repo_id: Annotated[int, "Repository ID"],
    ctx: Context = None
) -> dict:
    """
    Get comprehensive summary of a repository's analysis.
    
    Returns:
    - Language breakdown with line counts
    - Symbol counts by type
    - Top detected patterns
    - Most used imports/dependencies
    - Key classes and their methods
    """
    analysis: AnalysisTools = ctx.request_context.lifespan_context.analysis
    return analysis.get_repo_summary(repo_id)


@mcp.tool(
    annotations=ToolAnnotations(
        title="Get Public API",
        readOnlyHint=True,
        idempotentHint=True
    )
)
def get_public_api(
    repo_id: Annotated[int, "Repository ID"],
    include_fields: Annotated[bool, "Include struct/class field definitions"] = True,
    include_methods: Annotated[bool, "Include method definitions for classes"] = True,
    file_path: Annotated[str | None, "Optional file path to limit scope"] = None,
    ctx: Context = None
) -> dict:
    """
    Extract public API surface from a repository.
    
    Specifically designed for porting analysis: extracts only exported/public
    symbols (functions, structs, classes) with their signatures, fields, and
    method definitions.
    
    Returns:
    - functions: Exported function signatures with parameters and return types
    - types: Structs, classes, interfaces with their field definitions
    - constants: Exported constants and static values
    
    IMPORTANT: Use this output verbatim for porting analysis. Do not hallucinate
    additional APIs that are not in the returned data.
    """
    analysis: AnalysisTools = ctx.request_context.lifespan_context.analysis
    return analysis.get_public_api(repo_id, include_fields, include_methods, file_path)


# ============================================================================
# Search Tools
# ============================================================================

@mcp.tool(
    annotations=ToolAnnotations(
        title="Search Code",
        readOnlyHint=True,
        idempotentHint=True
    )
)
def search_code(
    query: Annotated[str, "Search query (supports: AND, OR, NOT, 'phrase', prefix*)"],
    search_type: Annotated[Literal["all", "function", "class", "method"], "Filter by symbol type"] = "all",
    repo_id: Annotated[int | None, "Repository ID to limit search"] = None,
    limit: Annotated[int, "Maximum results to return"] = 20,
    ctx: Context = None
) -> dict:
    """
    Search symbols using full-text search.
    
    Searches across function/class/method names, signatures, and docstrings.
    Use this to find specific functionality in the codebase.
    """
    search: SearchTools = ctx.request_context.lifespan_context.search
    return search.search_code(query, search_type, repo_id, limit)


@mcp.tool(
    annotations=ToolAnnotations(
        title="Find Patterns",
        readOnlyHint=True,
        idempotentHint=True
    )
)
def find_patterns(
    pattern_type: Annotated[Literal["algorithm", "design_pattern", "all"], "Type of pattern to find"] = "all",
    pattern_name: Annotated[str | None, "Specific pattern name (e.g., 'recursion', 'singleton')"] = None,
    repo_id: Annotated[int | None, "Repository ID to limit search"] = None,
    min_confidence: Annotated[float, "Minimum confidence threshold (0.0-1.0)"] = 0.5,
    ctx: Context = None
) -> dict:
    """
    Find detected algorithm and design patterns.
    
    Patterns include:
    - Algorithms: recursion, dynamic_programming, binary_search, graph_traversal, etc.
    - Design patterns: singleton, factory, decorator, iterator, context_manager
    
    Returns pattern locations with confidence scores and evidence.
    """
    search: SearchTools = ctx.request_context.lifespan_context.search
    return search.find_patterns(pattern_type, pattern_name, repo_id, min_confidence)


@mcp.tool(
    annotations=ToolAnnotations(
        title="Find Imports",
        readOnlyHint=True,
        idempotentHint=True
    )
)
def find_imports(
    module: Annotated[str | None, "Module name to search for (partial match)"] = None,
    repo_id: Annotated[int | None, "Repository ID to limit search"] = None,
    include_relative: Annotated[bool, "Include relative imports"] = False,
    limit: Annotated[int, "Maximum results to return"] = 50,
    ctx: Context = None
) -> dict:
    """
    Find import statements across the codebase.
    
    Useful for understanding dependencies and how modules are used.
    Returns import locations and a summary of most-used modules.
    """
    search: SearchTools = ctx.request_context.lifespan_context.search
    return search.find_imports(module, repo_id, include_relative, limit)


@mcp.tool(
    annotations=ToolAnnotations(
        title="List Symbols",
        readOnlyHint=True,
        idempotentHint=True
    )
)
def list_symbols(
    repo_id: Annotated[int, "Repository ID"],
    symbol_type: Annotated[Literal["function", "class", "method", "all"], "Filter by symbol type"] = "all",
    file_path: Annotated[str | None, "Filter by specific file path"] = None,
    visibility: Annotated[Literal["public", "private", "all"], "Filter by visibility (public/private/all)"] = "all",
    limit: Annotated[int, "Maximum results to return"] = 100,
    group_by_file: Annotated[bool, "Group results by file path for easier reading"] = False,
    ctx: Context = None
) -> dict:
    """
    List all symbols in a repository.
    
    Returns a comprehensive list of functions, classes, and methods
    with their signatures, locations, and visibility status.
    
    Use visibility='public' to filter for exported/public API only.
    Use group_by_file=True to get results organized by file for porting analysis.
    """
    search: SearchTools = ctx.request_context.lifespan_context.search
    return search.list_symbols(repo_id, symbol_type, file_path, visibility, limit, group_by_file)


@mcp.tool(
    annotations=ToolAnnotations(
        title="Inspect Symbol",
        readOnlyHint=True,
        idempotentHint=True
    )
)
def inspect_symbol(
    repo_id: Annotated[int, "Repository ID"],
    symbol_name: Annotated[str, "Name of the symbol to inspect"],
    include_source: Annotated[bool, "Include actual source code snippet"] = True,
    context_lines: Annotated[int, "Extra lines of context around symbol (0-10)"] = 0,
    ctx: Context = None
) -> dict:
    """
    Get detailed information about a specific symbol including source code.
    
    This tool provides complete symbol details with the actual source code
    for accurate analysis. Use this when you need to see implementation
    details, not just signatures.
    
    Returns:
    - Full signature, parameters, return type
    - Docstring and documentation
    - Actual source code (when include_source=True)
    - Child symbols (methods for classes)
    - Associated patterns
    
    IMPORTANT: Use the source_code field verbatim when discussing implementation.
    """
    search: SearchTools = ctx.request_context.lifespan_context.search
    return search.inspect_symbol(repo_id, symbol_name, include_source, context_lines)


# ============================================================================
# Call Graph Tools
# ============================================================================

@mcp.tool(
    annotations=ToolAnnotations(
        title="Get Call Graph",
        readOnlyHint=True,
        idempotentHint=True
    )
)
def get_call_graph(
    repo_id: Annotated[int, "Repository ID"],
    symbol_name: Annotated[str | None, "Focus on specific function/method (shows calls to/from it)"] = None,
    depth: Annotated[int, "Maximum traversal depth from target symbol"] = 3,
    direction: Annotated[Literal["callers", "callees", "both"], "Direction to traverse"] = "both",
    output_format: Annotated[Literal["json", "mermaid"], "Output format"] = "json",
    ctx: Context = None
) -> dict:
    """
    Get function call graph for a repository.
    
    Shows which functions call which other functions.
    Can focus on a specific symbol to see its callers and/or callees.
    
    Requires: Run analyze_repo with include_call_graph=True first.
    
    Output formats:
    - json: Structured data with nodes and edges
    - mermaid: Flowchart diagram for visualization
    """
    analysis: AnalysisTools = ctx.request_context.lifespan_context.analysis
    return analysis.get_call_graph(repo_id, symbol_name, depth, direction, output_format)


@mcp.tool(
    annotations=ToolAnnotations(
        title="Find Callers",
        readOnlyHint=True,
        idempotentHint=True
    )
)
def find_callers(
    symbol_name: Annotated[str, "Name of the function or method to find callers of"],
    repo_id: Annotated[int | None, "Repository ID to limit search"] = None,
    ctx: Context = None
) -> dict:
    """
    Find all callers of a specific function or method.
    
    Returns a list of all places where this function is called,
    with file paths and line numbers.
    
    Requires: Run analyze_repo with include_call_graph=True first.
    """
    analysis: AnalysisTools = ctx.request_context.lifespan_context.analysis
    return analysis.find_callers(symbol_name, repo_id)


@mcp.tool(
    annotations=ToolAnnotations(
        title="Find Callees",
        readOnlyHint=True,
        idempotentHint=True
    )
)
def find_callees(
    symbol_name: Annotated[str, "Name of the function or method"],
    repo_id: Annotated[int, "Repository ID"],
    ctx: Context = None
) -> dict:
    """
    Find all functions called by a specific function or method.
    
    Returns a list of all function calls made within this function,
    with line numbers and whether they are external/resolved.
    
    Requires: Run analyze_repo with include_call_graph=True first.
    """
    analysis: AnalysisTools = ctx.request_context.lifespan_context.analysis
    return analysis.find_callees(symbol_name, repo_id)


# ============================================================================
# Report Generation Tools
# ============================================================================

@mcp.tool(
    annotations=ToolAnnotations(
        title="Generate Report",
        readOnlyHint=True,
        idempotentHint=True
    )
)
def generate_report(
    repo_id: Annotated[int, "Repository ID"],
    report_type: Annotated[
        Literal["summary", "detailed", "dependencies", "architecture", "porting_analysis"],
        "Type of report: summary (overview), detailed (all data), dependencies (imports), architecture (classes + call graph), porting_analysis (for migration planning)"
    ] = "summary",
    output_format: Annotated[
        Literal["json", "markdown", "html"],
        "Output format for the report"
    ] = "markdown",
    save_path: Annotated[str | None, "Optional file path to save the report (adds extension automatically)"] = None,
    ctx: Context = None
) -> dict:
    """
    Generate an analysis report for a repository.
    
    Report types:
    - summary: High-level overview with key statistics, top patterns, key classes
    - detailed: Full analysis with all symbols, patterns, imports, and call graph
    - dependencies: Focus on external/internal dependencies and import analysis
    - architecture: Class hierarchy, file distribution, and Mermaid call graph
    - porting_analysis: File-by-file symbol listing with exact counts for migration planning
    
    Output formats:
    - json: Structured data for programmatic use
    - markdown: Human-readable with tables and formatting
    - html: Styled HTML with Mermaid diagram support
    
    If save_path is provided, the report is saved to that location.
    
    Response Integration (for porting_analysis):
        Use files_analysis[].symbols[] verbatim in your response.
        Use statistics.* for exact counts - NEVER estimate.
    """
    report: ReportTools = ctx.request_context.lifespan_context.report
    return report.generate_report(repo_id, report_type, output_format, save_path)


# ============================================================================
# Algorithm Analysis Tools
# ============================================================================

@mcp.tool(
    annotations=ToolAnnotations(
        title="Extract Algorithms",
        readOnlyHint=False,
        idempotentHint=True
    )
)
async def extract_algorithms(
    repo_id: Annotated[int, "Repository ID to extract algorithms from"],
    min_lines: Annotated[int, "Minimum line count for extraction (default: 5)"] = 5,
    force_reextract: Annotated[bool, "Re-extract even if already exists"] = False,
    ctx: Context = None
) -> dict:
    """
    Extract and analyze all algorithms from a repository.
    
    Analyzes functions and methods to compute:
    - Complexity metrics (cyclomatic, nesting depth, loops, conditionals)
    - AST-based structural hash for duplicate detection
    - Static category classification (sorting, searching, graph, dp, math, etc.)
    
    Requires: Run analyze_repo first to populate symbols.
    """
    algorithm: AlgorithmTools = ctx.request_context.lifespan_context.algorithm
    
    await ctx.info(f"Extracting algorithms from repository {repo_id}...")
    result = algorithm.extract_algorithms(repo_id, min_lines, force_reextract)
    
    if result.get("status") == "success":
        stats = result.get("statistics", {})
        await ctx.info(f"Extracted {stats.get('extracted', 0)} algorithms")
    
    return result


@mcp.tool(
    annotations=ToolAnnotations(
        title="Get LLM Analysis Prompt",
        readOnlyHint=True,
        idempotentHint=True
    )
)
def get_llm_analysis_prompt(
    algorithm_id: Annotated[int, "Algorithm ID to get prompt for"],
    ctx: Context = None
) -> dict:
    """
    Get the standard LLM analysis prompt for an algorithm.
    
    Returns a structured prompt with the algorithm's source code.
    The client should:
    1. Call their LLM with the returned 'prompt' field
    2. Parse the LLM's JSON response
    3. Save the result using save_llm_analysis
    
    The prompt asks for: purpose, category, time/space complexity,
    use cases, and potential improvements.
    """
    algorithm: AlgorithmTools = ctx.request_context.lifespan_context.algorithm
    return algorithm.get_llm_analysis_prompt(algorithm_id)


@mcp.tool(
    annotations=ToolAnnotations(
        title="Save LLM Analysis",
        readOnlyHint=False,
        idempotentHint=True
    )
)
def save_llm_analysis(
    algorithm_id: Annotated[int, "Algorithm ID to save analysis for"],
    analysis: Annotated[str, "LLM analysis result as JSON string with: purpose, category, time_complexity, space_complexity, use_cases, improvements"],
    ctx: Context = None
) -> dict:
    """
    Save LLM analysis results for an algorithm.
    
    Expected JSON structure:
    {
        "purpose": "Description of what the algorithm does",
        "category": "sorting|searching|graph|dp|math|string|tree|io|other",
        "time_complexity": {"notation": "O(...)", "explanation": "..."},
        "space_complexity": {"notation": "O(...)", "explanation": "..."},
        "use_cases": ["case1", "case2"],
        "improvements": ["improvement1", "improvement2"]
    }
    """
    algorithm: AlgorithmTools = ctx.request_context.lifespan_context.algorithm
    return algorithm.save_llm_analysis(algorithm_id, analysis)


@mcp.tool(
    annotations=ToolAnnotations(
        title="Save Algorithm Embedding",
        readOnlyHint=False,
        idempotentHint=True
    )
)
def save_algorithm_embedding(
    algorithm_id: Annotated[int, "Algorithm ID to save embedding for"],
    embedding: Annotated[list[float], "Embedding vector as list of floats"],
    model_name: Annotated[str, "Name of the embedding model used (e.g., 'text-embedding-3-small')"],
    ctx: Context = None
) -> dict:
    """
    Save an embedding vector for an algorithm.
    
    The client should generate the embedding using their preferred model
    (e.g., OpenAI text-embedding-3-small, Cohere embed-v3, etc.) and
    provide it here for similarity search.
    """
    algorithm: AlgorithmTools = ctx.request_context.lifespan_context.algorithm
    return algorithm.save_embedding(algorithm_id, embedding, model_name)


@mcp.tool(
    annotations=ToolAnnotations(
        title="Find Similar Algorithms",
        readOnlyHint=True,
        idempotentHint=True
    )
)
def find_similar_algorithms(
    algorithm_id: Annotated[int, "Algorithm ID to find similar algorithms for"],
    method: Annotated[Literal["hash", "embedding", "both"], "Comparison method"] = "both",
    threshold: Annotated[float, "Similarity threshold for embedding search (0.0-1.0)"] = 0.8,
    limit: Annotated[int, "Maximum results"] = 20,
    ctx: Context = None
) -> dict:
    """
    Find algorithms similar to the specified algorithm.
    
    Methods:
    - hash: Find structurally identical algorithms (exact AST match)
    - embedding: Find semantically similar algorithms using embeddings
    - both: Combine hash and embedding results
    
    Requires: Embeddings must be saved first for embedding-based search.
    """
    algorithm: AlgorithmTools = ctx.request_context.lifespan_context.algorithm
    return algorithm.find_similar(algorithm_id, method, threshold, limit)


@mcp.tool(
    annotations=ToolAnnotations(
        title="Get Algorithm",
        readOnlyHint=True,
        idempotentHint=True
    )
)
def get_algorithm(
    algorithm_id: Annotated[int, "Algorithm ID to retrieve"],
    ctx: Context = None
) -> dict:
    """
    Get detailed information about an algorithm.
    
    Returns complete algorithm details including:
    - Source code (original and normalized)
    - Complexity metrics
    - Static and LLM categories
    - LLM analysis results (if available)
    - Embedding status
    """
    algorithm: AlgorithmTools = ctx.request_context.lifespan_context.algorithm
    return algorithm.get_algorithm(algorithm_id)


@mcp.tool(
    annotations=ToolAnnotations(
        title="List Algorithms",
        readOnlyHint=True,
        idempotentHint=True
    )
)
def list_algorithms(
    repo_id: Annotated[int, "Repository ID"],
    category: Annotated[str | None, "Filter by category (sorting, searching, graph, dp, math, string, tree, io, other)"] = None,
    category_type: Annotated[Literal["static", "llm", "any"], "Which category to filter by"] = "static",
    min_complexity: Annotated[int | None, "Minimum cyclomatic complexity"] = None,
    limit: Annotated[int, "Maximum results"] = 100,
    ctx: Context = None
) -> dict:
    """
    List algorithms in a repository with optional filters.
    
    Filters:
    - category: Filter by algorithm category
    - category_type: Use 'static' (auto-detected), 'llm' (LLM-determined), or 'any'
    - min_complexity: Filter by minimum cyclomatic complexity
    
    Returns algorithm list with category summary.
    """
    algorithm: AlgorithmTools = ctx.request_context.lifespan_context.algorithm
    return algorithm.list_algorithms(repo_id, category, category_type, min_complexity, limit)


@mcp.tool(
    annotations=ToolAnnotations(
        title="Search Algorithms",
        readOnlyHint=True,
        idempotentHint=True
    )
)
def search_algorithms(
    query: Annotated[str, "Search query (supports FTS5 operators: AND, OR, NOT, 'phrase', prefix*)"],
    repo_id: Annotated[int | None, "Optional repository ID filter"] = None,
    limit: Annotated[int, "Maximum results"] = 20,
    ctx: Context = None
) -> dict:
    """
    Search algorithms using full-text search.
    
    Searches in source code and LLM analysis.
    Use this to find algorithms by keywords, patterns, or descriptions.
    """
    algorithm: AlgorithmTools = ctx.request_context.lifespan_context.algorithm
    return algorithm.search_algorithms(query, repo_id, limit)


@mcp.tool(
    annotations=ToolAnnotations(
        title="Build Similarity Index",
        readOnlyHint=False,
        idempotentHint=True
    )
)
def build_similarity_index(
    repo_id: Annotated[int | None, "Optional repository ID to limit index (None for all repos)"] = None,
    index_type: Annotated[Literal["flat", "ivf", "hnsw"], "Index type: flat (exact), ivf (fast), hnsw (best quality/speed)"] = "flat",
    ctx: Context = None
) -> dict:
    """
    Build ANN index for fast embedding similarity search.
    
    This significantly improves performance for large datasets (>1000 embeddings).
    Must be called before using find_similar_algorithms with embedding method.
    
    Index types:
    - flat: Exact search, slower but most accurate (recommended for <10K embeddings)
    - ivf: Inverted file index, faster approximate search (good for 10K-1M embeddings)
    - hnsw: Hierarchical NSW graph, best quality/speed tradeoff (recommended for >100K)
    
    The index is kept in memory and should be rebuilt after adding new embeddings.
    
    Requires: FAISS library (pip install faiss-cpu numpy)
    """
    algorithm: AlgorithmTools = ctx.request_context.lifespan_context.algorithm
    return algorithm.build_similarity_index(repo_id, index_type)


@mcp.tool(
    annotations=ToolAnnotations(
        title="Reduce Embedding Dimensions",
        readOnlyHint=False,
        destructiveHint=True,
        idempotentHint=False
    )
)
def reduce_embedding_dimensions(
    target_dimension: Annotated[int, "Target dimension (must be < current dimension)"],
    repo_id: Annotated[int | None, "Optional repository ID to limit reduction (None for all repos)"] = None,
    method: Annotated[Literal["pca"], "Reduction method (currently only PCA supported)"] = "pca",
    ctx: Context = None
) -> dict:
    """
    Reduce embedding dimensions for storage/performance optimization.
    
    Uses PCA to reduce dimensionality while preserving maximum variance.
    Benefits:
    - Reduces storage size (e.g., 768 -> 128 dimensions = 83% reduction)
    - Improves search speed
    - Can reduce noise in embeddings
    
    Warning: This modifies embeddings in the database. Consider backing up first.
    The operation cannot be reversed without regenerating embeddings.
    
    Returns variance retention statistics to help assess quality loss.
    
    Requires: scikit-learn library (pip install scikit-learn)
    """
    algorithm: AlgorithmTools = ctx.request_context.lifespan_context.algorithm
    return algorithm.reduce_embedding_dimensions(repo_id, target_dimension, method)


# ============================================================================
# Resources
# ============================================================================

@mcp.resource("repo://{repo_id}/summary")
def get_repo_summary_resource(repo_id: int, ctx: Context = None) -> str:
    """Get repository analysis summary as a resource."""
    analysis: AnalysisTools = ctx.request_context.lifespan_context.analysis
    result = analysis.get_repo_summary(int(repo_id))
    
    if result.get("status") != "success":
        return f"Error: {result.get('message', 'Unknown error')}"
    
    # Format as readable text
    repo = result.get("repository", {})
    lines = [
        f"# Repository: {repo.get('name', 'Unknown')}",
        f"URL: {repo.get('url', 'N/A')}",
        f"Last analyzed: {repo.get('last_analyzed', 'Never')}",
        "",
        "## Language Breakdown",
    ]
    
    for lang in result.get("languages", []):
        lines.append(f"- {lang['language']}: {lang['file_count']} files, {lang['total_lines']} lines")
    
    lines.extend(["", "## Symbol Counts"])
    for stype, count in result.get("symbol_counts", {}).items():
        lines.append(f"- {stype}: {count}")
    
    lines.extend(["", "## Top Patterns"])
    for pattern in result.get("top_patterns", []):
        lines.append(f"- {pattern['pattern_type']}/{pattern['pattern_name']}: {pattern['count']} occurrences")
    
    lines.extend(["", "## Top Dependencies"])
    for imp in result.get("top_imports", [])[:10]:
        lines.append(f"- {imp['module']}: {imp['count']} uses")
    
    return "\n".join(lines)


@mcp.resource("guidelines://tool-usage")
def get_tool_usage_guidelines() -> str:
    """
    Detailed tool usage guidelines for AI assistants.
    
    Read this resource when you need comprehensive guidance on how to
    integrate tool results into responses.
    """
    return '''
# MCP Git Analyzer - Detailed Tool Usage Guidelines

## Tool Categories & When to Use

### 1. Repository Setup Tools
| Tool | Purpose | Key Output Fields |
|------|---------|-------------------|
| `clone_repo` | Download repository | `repo_id` (use for subsequent calls) |
| `list_repos` | See available repos | `repositories[].id`, `repositories[].name` |
| `get_repo_tree` | View file structure | `tree` (nested structure) |

### 2. Analysis Tools
| Tool | Purpose | Key Output Fields |
|------|---------|-------------------|
| `analyze_repo` | Full repository parse | `statistics.total_functions`, `statistics.total_classes`, `patterns[]` |
| `get_file_analysis` | Single file details | `symbols[]` (MUST show these), `imports[]`, `patterns[]` |
| `get_repo_summary` | Quick overview | `symbol_counts`, `languages[]`, `top_patterns[]` |
| `get_public_api` | Porting analysis | `functions[]`, `types[]` - USE VERBATIM |

### 3. Search Tools  
| Tool | Purpose | Key Output Fields |
|------|---------|-------------------|
| `list_symbols` | Find functions/classes | `results[].name`, `results[].signature` |
| `find_patterns` | Detect design patterns | `results[].pattern_type`, `results[].evidence` |
| `find_imports` | Dependency analysis | `results[].module`, `results[].count` |
| `inspect_symbol` | Deep dive | `symbol.source_code` - USE VERBATIM |

### 4. Algorithm Tools
| Tool | Purpose | Key Output Fields |
|------|---------|-------------------|
| `extract_algorithms` | Parse algorithms | `statistics.categories` |
| `list_algorithms` | Browse algorithms | `algorithms[].symbol_name`, `category_summary` |
| `get_algorithm_detail` | Full details | `algorithm.source_code`, `complexity_metrics` |

### 5. Report Tools
| Tool | Purpose | Key Output Fields |
|------|---------|-------------------|
| `generate_report` | Comprehensive report | Depends on `report_type` |

---

## Field Usage Rules

### MUST Include Verbatim
These fields contain factual data that MUST appear in your response as-is:

```
analyze_repo:
  - statistics.total_files → "총 N개 파일"
  - statistics.total_functions → "N개의 함수"
  - statistics.total_classes → "N개의 클래스"

get_file_analysis:
  - symbols[].name → List each function/class name
  - symbols[].signature → Show actual signatures
  - symbols[].parameters → Detail parameters

list_algorithms:
  - algorithms[].symbol_name → List algorithm names
  - category_summary → Show category distribution

inspect_symbol:
  - symbol.source_code → Quote actual code
```

### NEVER Estimate
❌ Wrong: "약 50개의 함수", "50+ functions", "numerous functions"
✅ Correct: "47개의 함수" (from statistics.total_functions)

---

## Response Templates

### For Porting/Migration Analysis

```markdown
## 1. 원본 라이브러리 분석

### 파일별 함수 목록
[From get_file_analysis for each file]

**header1.h** (N개 함수)
- `function1(param1: type, param2: type) -> return_type`
- `function2(...)`

**header2.h** (M개 함수)  
- ...

### 통계
- 총 파일 수: [statistics.total_files]
- 총 함수 수: [statistics.total_functions]
- 총 클래스 수: [statistics.total_classes]

### 알고리즘 패턴
[From list_algorithms.category_summary]
- math: N개
- sorting: M개
- ...

## 2. 타겟 언어 설계

[Based on actual file/function mapping]

| 원본 파일 | 타겟 모듈 | 함수 수 |
|-----------|-----------|---------|
| header1.h | module1.rs | N |
| header2.h | module2.rs | M |

## 3. 마이그레이션 로드맵

[Phased plan based on actual dependencies from find_imports]
```

### For Code Review/Understanding

```markdown
## 코드 구조 분석

### 핵심 컴포넌트
[From list_symbols with type="class"]

1. **ClassName** (`file.py:L10-50`)
   - 역할: [from docstring]
   - 메서드: N개
   
### 주요 패턴
[From find_patterns]

- Pattern1: N회 발견 (files: ...)
- Pattern2: M회 발견

### 의존성
[From find_imports]
- External: package1 (N uses), package2 (M uses)
- Internal: module1 → module2
```

---

## Common Mistakes to Avoid

1. **Ignoring tool output**: You called the tool but didn\'t use the data
2. **Estimating counts**: Always use exact numbers from statistics
3. **Generic descriptions**: Use actual function names, not "various utility functions"
4. **Missing signatures**: Show `signature` field, not just `name`
5. **Skipping source code**: When discussing implementation, quote `source_code`

---

## Quick Reference: Output → Response Mapping

```
Tool Called                    → Must Include in Response
─────────────────────────────────────────────────────────
analyze_repo                   → Exact counts from statistics
get_file_analysis(file.h)      → List of symbols[].name + signature
list_symbols                   → results[].name grouped logically
find_patterns                  → Pattern names + evidence
list_algorithms                → Algorithm names + categories
extract_algorithms             → Category distribution
inspect_symbol                 → source_code in code block
generate_report("porting_analysis") → Complete structured output
```
'''.strip()


# ============================================================================
# Prompts (Templates for AI assistants)
# ============================================================================

@mcp.prompt()
def porting_plan(
    source_repo: str,
    target_language: str,
    analysis_results: str
) -> str:
    """
    Generate a structured porting plan from analysis results.
    
    Use this prompt template after analyzing a repository to ensure
    the response includes all required sections with actual data.
    
    Args:
        source_repo: Name of the source repository
        target_language: Target programming language (e.g., "Rust", "Go")
        analysis_results: JSON string from analyze_repo or generate_report
    """
    return f'''
Based on the analysis of **{source_repo}**, create a porting plan to **{target_language}**.

## Analysis Data (USE THIS DATA VERBATIM)
```json
{analysis_results}
```

## Required Response Structure

### 1. 원본 라이브러리 기능 요약 (Source Library Summary)
- List ALL functions from the analysis data above
- Show exact function signatures
- Group by file/module
- Include exact counts (do NOT estimate)

### 2. {target_language} 크레이트/패키지 설계
- Map each source file to target module
- Define public API based on actual functions
- Note any patterns detected

### 3. 마이그레이션 로드맵
- Phase 1: Core functionality (list specific functions)
- Phase 2: Extended features
- Phase 3: Optimization & testing

### Rules
- Every function name must come from the analysis data
- Every count must be exact from statistics
- Do not add functions that don\'t exist in the source
'''


# ============================================================================
# Entry Point
# ============================================================================

def main():
    """Run the MCP server."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
