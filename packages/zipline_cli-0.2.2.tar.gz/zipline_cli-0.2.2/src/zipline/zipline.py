import argparse
import io
import mimetypes
import os
import re
import secrets
import string
import sys
from importlib.metadata import version
from pathlib import Path
from typing import IO, Any, Dict, List, Optional, TextIO

import requests
from decouple import config
from dotenv import find_dotenv, load_dotenv


class ZipURL(object):
    """
    Zipline URL Object
    :param file_url: Zipline File Display URL
    """

    __slots__ = ["url", "raw"]

    def __init__(self, file_url: str):
        self.url: str = file_url
        self.raw: str = self._get_raw(file_url)

    def __repr__(self):
        return f"<url={self.url} raw={self.raw}>"

    def __str__(self):
        return self.url

    @staticmethod
    def _get_raw(url: str) -> str:
        try:
            s = url.split("/", 4)
            return f"{s[0]}//{s[2]}/r/{s[4]}"
        except Exception:  # noqa
            return ""


class Zipline(object):
    """
    Zipline Python API
    :param base_url: Zipline URL
    :param kwargs: Zipline Headers
    """

    # noinspection SpellCheckingInspection
    allowed_headers = [
        # zipline v3
        "format",
        "image_compression_percent",
        "expires_at",
        "password",
        "zws",
        "embed",
        "max_views",
        "uploadtext",
        "authorization",
        "no_json",
        "x_zipline_filename",
        "original_name",
        "override_domain",
        # zipline v4
        "x-zipline-deletes-at",
        "x-zipline-format",
        "x-zipline-image-compression-percent",
        "x-zipline-password",
        "x-zipline-max-views",
        "x-zipline-no-json",
        "x-zipline-original-name",
        "x-zipline-folder",
        "x-zipline-filename",
        "x-zipline-domain",
        "x-zipline-file-extension",
    ]

    def __init__(self, url: str, **kwargs):
        self.base_url: str = url.rstrip("/")
        self._headers: Dict[str, str] = {}
        for header, value in kwargs.items():
            if header.lower() not in self.allowed_headers:
                continue
            if value is None:
                continue
            key = header.replace("_", "-").title()
            self._headers[key] = str(value)

    def send_file(self, file_name: str, file_object: IO, overrides: Optional[dict] = None) -> ZipURL:
        """
        Upload File to Zipline
        :param file_name: Name of File for files tuple
        :param file_object: File to Upload
        :param overrides: Header Overrides
        :return: File URL
        """
        url = self.base_url + "/api/upload"

        path = Path(file_name)
        if not path.is_file():
            raise ValueError(f"Not a File: {path.resolve()}")

        mime_type = get_type(path)
        # print(f"mime_type: {mime_type}")
        files = {"file": (file_name, file_object, mime_type)}
        headers = self._headers | overrides if overrides else self._headers
        r = requests.post(url, headers=headers, files=files)  # nosec
        r.raise_for_status()
        data = r.json()["files"][0]
        if isinstance(data, dict):
            return ZipURL(data["url"])
        elif isinstance(data, list):
            return ZipURL(data[0])
        else:
            return ZipURL(data)


def get_type(file_path: Path) -> str:
    # Deprecated since version 3.13: Passing a file path instead of URL is soft deprecated. Use guess_file_type() for this.
    # https://docs.python.org/3/library/mimetypes.html#mimetypes.guess_type
    mime_type, _ = mimetypes.guess_type(file_path, strict=False)
    if mime_type:
        return mime_type
    return magic_type(file_path)


def magic_type(file_path: Path) -> str:  # NOSONAR
    try:
        with open(file_path, "rb") as file:
            chunk = file.read(512)
        # print(chunk)
        if chunk[0:3] == b"\xff\xd8\xff" or chunk[6:10] in (b"JFIF", b"Exif"):
            return "image/jpeg"
        elif chunk.startswith(b"\x89\x50\x4e\x47\x0d\x0a\x1a\x0a"):
            return "image/png"
        elif chunk.startswith(b"RIFF") and chunk[8:12] == b"WEBP":
            return "image/webp"
        elif chunk.startswith((b"\x47\x49\x46\x38\x37\x61", b"\x47\x49\x46\x38\x39\x61")):
            return "image/gif"
        elif chunk.startswith(b"\x66\x74\x79\x70\x68\x65\x69\x63\x66\x74\79\70\6d"):
            return "image/heic"
        elif chunk.startswith(b"\x00\x00\x01\x00"):
            return "image/ico"

        elif chunk[3:11] in (b"\x66\x74\x79\x70\x4d\x53\x4e\x56", b"\x66\x74\x79\x70\x69\x73\x6f\x6d"):
            return "video/mp4"
        elif chunk[4:12] == b"ftypisom" or chunk[4:12] == b"ftypMSNV" or chunk[4:12] == b"ftypmp42":
            return "video/mp4"
        elif chunk.startswith(b"\x1a\x45\xdf\xa3"):
            return "video/x-matroska"
        elif chunk.startswith(b"\x6d\x6f\x6f\x76"):
            return "video/quicktime"

        elif chunk.startswith((b"\xff\xfb", b"\xff\xfb", b"\xff\xfb", b"\x49\x44\x33")):
            return "audio/mp3"
        elif chunk.startswith(b"RIFF") and chunk[8:12] == b"WAVE":
            return "audio/wav"
        elif chunk.startswith(b"OggS"):
            return "application/ogg"

        chunk.decode("utf-8")
        return "text/plain"
    except UnicodeDecodeError:
        return "application/octet-stream"


def format_output(filename: str, url: ZipURL) -> str:
    """
    Format URL Output
    :param filename: Original or File Name
    :param url: ZipURL to Format
    :return: Formatted Output
    """
    zipline_format = config("ZIPLINE_FORMAT", "{filename}\n{url}\n{raw_url}")
    return zipline_format.format(filename=filename, url=url, raw_url=url.raw)


def gen_rand(length: int = 4) -> str:
    """
    Generate Random Streng
    :param length: Length of String
    :return: Random String
    """
    r = "".join(secrets.choice(string.ascii_letters) for _ in range(length))
    return "".join(r)


def get_default(
    values: List[str],
    default: Optional[Any] = None,
    cast: type = str,
    pre: str = "ZIPLINE_",
    suf: str = "",
) -> Optional[str]:
    """
    Get Default Environment Variable from List of values
    :param values: List of Values to Check
    :param default: Default Value if None
    :param cast: Type to Cast Value
    :param pre: Environment Variable Prefix
    :param suf: Environment Variable Suffix
    :return: Environment Variable or None
    """
    for value in values:
        result = config(f"{pre}{value.upper()}{suf}", "", cast)
        if result:
            return result
    return default


def setup(env_file: Path) -> None:
    print("Setting up Environment File...")
    url = input("Zipline URL: ").strip()
    token = input("Zipline Authorization Token: ").strip()
    if not url or not token:
        raise ValueError("Missing URL or Token.")
    output = f"ZIPLINE_URL={url}\nZIPLINE_TOKEN={token}\n"
    embed = input("Enabled Embed? [Yes]/No: ").strip()
    if not embed or embed.lower() not in ["n", "o", "no", "noo"]:
        output += "ZIPLINE_EMBED=true\n"
    expire = input("Default Expire? [Blank for None]: ").strip().lower()
    if expire:
        match = re.search(r"^(\d+)(?:ms|s|m|h|d|w|y)$", expire)
        if not match:
            print(f"Warning: invalid expire format: {expire}. See --help")
        else:
            output += f"ZIPLINE_EXPIRE={expire}\n"
    with open(env_file, "w") as f:
        f.write(output)
    print(f"Setup Complete. Variables Saved to: {env_file}")
    sys.exit(0)


def run() -> None:
    zipline_file = ".zipline"
    env_file = Path(os.path.expanduser("~")) / zipline_file
    dotenv_path = env_file if os.path.isfile(env_file) else find_dotenv(filename=zipline_file)
    env = load_dotenv(dotenv_path=dotenv_path)

    parser = argparse.ArgumentParser(description="Zipline CLI.")
    parser.add_argument("files", metavar="Files", type=str, nargs="*", help="Files to Upload.")
    parser.add_argument("-s", "--setup", action="store_true", default=False, help="run the interactive setup")
    parser.add_argument("-i", "--info", action="store_true", help="show application information")
    parser.add_argument("-V", "--version", action="store_true", help="show the installed version")
    parser.add_argument("-u", "--url", type=str, default=get_default(["url"]), help="Zipline URL")
    parser.add_argument(
        "-a",
        "-t",
        "--authorization",
        "--token",
        type=str,
        default=get_default(["token", "authorization"]),
        help="Zipline Access Token for Authorization or ZIPLINE_TOKEN",
    )
    parser.add_argument(
        "-e",
        "-x",
        "--expires_at",
        "--expire",
        type=str,
        default=get_default(["expire", "expire_at"]),
        help="Ex: 1d, 2w. See: https://zipline.diced.sh/docs/guides/upload-options#image-expiration",
    )
    parser.add_argument(
        "--embed", action="store_true", default=get_default(["embed"], False, bool), help="Enable Embeds on Uploads."
    )
    args = parser.parse_args()

    if args.version:
        print(version("zipline-cli"))
        return

    if args.info:
        print(f"Zipline Version:  {version('zipline-cli')}")
        print(f"Config File:      {env_file.absolute()}")
        print(f"Server URL:       {config('ZIPLINE_URL', '')}")
        print(f"Token (ends in):  {config('ZIPLINE_TOKEN', '')[-10:]}")
        print(f"Expire:           {config('ZIPLINE_EXPIRE', '')}")
        print(f"Embed:            {config('ZIPLINE_EMBED', '')}")
        zipline_format = config("ZIPLINE_FORMAT", "{url}\n{raw_url}")
        print(f"URL Format::\n{zipline_format}")
        return

    if args.setup:
        setup(env_file)

    if not env and not args.url and not args.authorization and not os.path.isfile(env_file):
        env_file.touch()
        print("First Run Detected, Entering Setup.")
        setup(env_file)

    if not args.url:
        parser.print_help()
        raise ValueError("Missing URL. Use --setup or specify --url")

    if not args.authorization:
        parser.print_help()
        raise ValueError("Missing Token. Use --setup or specify --token")

    if args.expires_at:
        args.expires_at = args.expires_at.strip().lower()
        match = re.search(r"^(\d+)(?:ms|s|m|h|d|w|y)$", args.expires_at)
        if not match:
            parser.print_help()
            raise ValueError(f"Invalid Expire Format: {args.expires_at}.")

    zipline = Zipline(**vars(args))

    if not args.files:
        content: str = sys.stdin.read().rstrip("\n") + "\n"
        text_f: TextIO = io.StringIO(content)
        name = f"{gen_rand(8)}.txt"
        url: ZipURL = zipline.send_file(name, text_f)
        print(format_output(name, url))
        sys.exit(0)

    exit_code = 1
    for name in args.files:
        if not os.path.isfile(name):
            print(f"Warning: File Not Found: {name}")
            continue
        # mode: Literal["r", "rb"] = get_mode(name)
        with open(name, "rb") as f:
            # name, ext = os.path.splitext(os.path.basename(filename))
            # ext = f'.{ext}' if ext else ''
            # name = f'{name}-{gen_rand(8)}{ext}'
            # url: str = zipline.send_file(name, f)
            zip_url: ZipURL = zipline.send_file(name, f)
            print(format_output(name, zip_url))
            exit_code = 0
    sys.exit(exit_code)


def main() -> None:
    try:
        run()
    except KeyboardInterrupt:
        sys.exit(1)
    except Exception as error:
        print("\nError: {}".format(str(error)))
        sys.exit(1)


if __name__ == "__main__":
    main()
