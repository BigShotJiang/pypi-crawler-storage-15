# greetuser

A simple Python package that asks for your name and greets you.

## Usage
pip install rishabh-greetuser

```python
from greetuser import greet_user

greet_user()

```
![Architecture](./docs/Images/1.png)

### CICD Pipeline
## Before triggering pipeline:
The version is 0.0.7, below is the images for reference: -
![Architecture](./docs/Images/2.png)
![Architecture](./docs/Images/3.png)
![Architecture](./docs/Images/4.png)

## After triggering pipeline:
The version upgrades to 0.0.8, below is the images for reference: -
![Architecture](./docs/Images/5.png)
![Architecture](./docs/Images/6.png)
![Architecture](./docs/Images/7.png)