1. Markdown cheat sheet: https://www.markdownguide.org/cheat-sheet/
2. Upload to PyPI: https://www.youtube.com/watch?v=7FcX9uWDuIQ
3. Create PyPI account: https://pypi.org/account/register/
4. geoprepare on PyPI: https://pypi.org/project/geoprepare/
