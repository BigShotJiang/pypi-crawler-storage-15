#!/usr/bin/env python

"""Tests for `geoprepare` package."""


import unittest

from geoprepare import geodownload


class TestGeoprepare(unittest.TestCase):
    """Tests for `geoprepare` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
