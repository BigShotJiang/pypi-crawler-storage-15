"""Async client for Hegel amplifiers with push + command support."""

from __future__ import annotations

import asyncio
import logging
import re
from collections import deque
from dataclasses import dataclass
from typing import Any, Callable, Optional

_LOGGER = logging.getLogger(__name__)

CR = "\r"


@dataclass
class HegelStateUpdate:
    """Represents a state update from a Hegel device."""

    power: Optional[bool] = None
    volume: Optional[float] = None
    mute: Optional[bool] = None
    input: Optional[int] = None
    reset: Optional[str] = None

    def has_changes(self) -> bool:
        """Check if this update contains any changes."""
        return any(
            [
                self.power is not None,
                self.volume is not None,
                self.mute is not None,
                self.input is not None,
                self.reset is not None,
            ]
        )


def parse_reply_message(reply: str) -> HegelStateUpdate:
    """Parse a single reply/push message and return state changes.

    Args:
        reply: Raw reply string from the Hegel device

    Returns:
        HegelStateUpdate with parsed changes
    """
    update = HegelStateUpdate()

    if reply.startswith("-p."):
        update.power = reply.endswith(".1")
    elif reply.startswith("-v."):
        m = re.findall(r"-v\.(\d+)", reply)
        if m:
            level = int(m[-1])
            update.volume = max(0.0, min(1.0, level / 100.0))
    elif reply.startswith("-m."):
        # -m.1 means muted, -m.0 unmuted
        update.mute = "1" in reply and "0" not in reply
    elif reply.startswith("-i."):
        inp = None
        for n in range(1, 21):
            if f".{n}" in reply:
                inp = n
        update.input = inp
    elif reply.startswith("-r.") or reply.startswith("-reset"):
        update.reset = reply

    return update


def apply_state_changes(
    state: dict[str, Any],
    update: HegelStateUpdate,
    logger: Optional[logging.Logger] = None,
    source: str = "reply",
):
    """Apply parsed changes to the state dictionary.

    Args:
        state: State dictionary to update
        update: HegelStateUpdate containing the changes
        logger: Optional logger for debug output
        source: Source of the update (for logging)
    """
    if logger is None:
        logger = _LOGGER

    if update.power is not None:
        logger.debug("[%s] Power parse: %s", source, update.power)
        state["power"] = update.power

    if update.volume is not None:
        logger.debug("[%s] Volume parse: %s", source, update.volume)
        state["volume"] = update.volume

    if update.mute is not None:
        logger.debug("[%s] Mute parse: %s", source, update.mute)
        state["mute"] = update.mute

    if update.input is not None:
        logger.debug("[%s] Input parse: %s", source, update.input)
        state["input"] = update.input

    if update.reset is not None:
        logger.info("[%s] Reset/other message: %s", source, update.reset)
        state["reset"] = update.reset


class HegelClient:
    """Async client for Hegel amplifiers with push + command support."""

    def __init__(self, host: str, port: int = 50001):
        self._host = host
        self._port = port
        self._reader: asyncio.StreamReader | None = None
        self._writer: asyncio.StreamWriter | None = None
        # small lock to protect writer/connection operations only
        self._write_lock = asyncio.Lock()

        # Lifecycle
        self._stopping = False
        self._listen_task: asyncio.Task | None = None
        self._manager_task: asyncio.Task | None = None
        self._connected_event = asyncio.Event()
        # prevent concurrent connect attempts
        self._reconnect_lock = asyncio.Lock()

        # Pending commands: FIFO futures consumers will fulfill
        self._pending: deque[asyncio.Future[str]] = deque()

        # Push callback
        self._on_push: Optional[Callable[[str], None]] = None

    # ------------------------------------------------------------------ #
    # Public API
    # ------------------------------------------------------------------ #

    async def start(self) -> None:
        """Start connection manager (runs forever until stop())."""
        async with self._reconnect_lock:
            # Prevent multiple concurrent manager tasks with lock protection
            if self._manager_task and not self._manager_task.done():
                _LOGGER.debug("Connection manager already running — skipping start()")
                return

            self._stopping = False
            self._manager_task = asyncio.create_task(self._manage_connection())
            _LOGGER.debug("Connection manager started")

    async def stop(self) -> None:
        """Stop everything and close the connection."""
        self._stopping = True
        if self._manager_task:
            self._manager_task.cancel()
            try:
                await self._manager_task
            except asyncio.CancelledError:
                pass
            self._manager_task = None
        await self._close_connection()

    def add_push_callback(self, callback: Callable[[str], None]) -> None:
        """Register callback for push messages."""
        self._on_push = callback

    async def send(
        self, command: str, expect_reply: bool = True, timeout: float = 5.0
    ) -> Optional[HegelStateUpdate]:
        """Send command and optionally wait for reply.

        Important: we only hold the _write_lock for writer access and pending append.
        Waiting for reply is done outside the lock to avoid deadlocks with the reader.

        Returns:
            If expect_reply=True: HegelStateUpdate with parsed state changes from the device response
            If expect_reply=False: None
        """
        # normalize line ending: Hegel uses CR
        if not command.endswith(CR):
            command_to_send = command + CR
        else:
            command_to_send = command

        # ensure connected and write under lock
        await self.ensure_connected()
        fut: asyncio.Future[str] | None = None
        async with self._write_lock:
            if expect_reply:
                fut = asyncio.get_event_loop().create_future()
                self._pending.append(fut)

            try:
                assert self._writer is not None
                _LOGGER.debug("TX: %s", command_to_send.strip())
                self._writer.write(command_to_send.encode())
                await self._writer.drain()
            except Exception as err:
                _LOGGER.error("Send failed: %s", err)
                # cleanup future
                if fut and not fut.done():
                    fut.set_exception(err)
                # close connection and raise so callers know
                await self._close_connection()
                raise

        # if caller didn't expect reply, return immediately
        if not fut:
            return None

        # wait for future outside the write lock
        try:
            raw_reply = await asyncio.wait_for(fut, timeout=timeout)
            # Parse the raw reply into structured changes
            return parse_reply_message(raw_reply)
        except asyncio.TimeoutError:
            _LOGGER.warning("Timeout waiting for reply to %s", command.strip())
            if not fut.done():
                fut.set_exception(asyncio.TimeoutError())
            raise

    async def ensure_connected(self, timeout: float = 5.0) -> None:
        """Wait until connected (or fail after timeout).

        If not connected, this will trigger a connect attempt.
        Uses a reconnect lock to avoid concurrent connect attempts.
        """
        if not self._connected_event.is_set():
            # start a connect if not already in progress
            async with self._reconnect_lock:
                # double check under lock
                if not self._connected_event.is_set():
                    # only start manager if it's not already running
                    if not self._manager_task or self._manager_task.done():
                        # if manager not running, start it through start() method
                        # which has proper duplicate protection
                        await self.start()
                    # If manager is already running, just wait for the connection event
                    # The manager will handle connection attempts with proper backoff
        try:
            await asyncio.wait_for(self._connected_event.wait(), timeout=timeout)
        except asyncio.TimeoutError:
            raise TimeoutError("Timeout waiting for connection")

    # ------------------------------------------------------------------ #
    # Connection Management
    # ------------------------------------------------------------------ #

    async def _manage_connection(self) -> None:
        """Keep the connection alive with reconnect/backoff.

        This manager will try to keep a connection open. It opens the connection
        and then waits for the listen task to exit (which happens on disconnect).
        If the listen task exits or open fails, it will retry with exponential
        backoff.
        """
        backoff = 1.0
        max_backoff = 60.0

        while not self._stopping:
            try:
                await self._open_connection()
                backoff = 1.0  # reset backoff
                if self._listen_task:
                    await self._listen_task  # normal exit when disconnected
            except asyncio.CancelledError:
                break
            except Exception as err:
                _LOGGER.warning(
                    "Connection attempt failed: %s — retrying in %.1fs", err, backoff
                )
                await asyncio.sleep(backoff)
                backoff = min(max_backoff, backoff * 2)

        _LOGGER.debug("Connection manager exiting")

    async def _open_connection(self) -> None:
        """Open TCP connection and start listener."""
        # avoid racing open if already connected
        if self._writer and not self._writer.is_closing():
            return
        _LOGGER.debug("Opening connection to %s:%s", self._host, self._port)
        try:
            self._reader, self._writer = await asyncio.open_connection(
                self._host, self._port
            )
        except Exception as err:
            # failed to connect — ensure state is clear and re-raise for manager to backoff
            self._connected_event.clear()
            _LOGGER.debug("Open connection failed: %s", err)
            raise

        self._connected_event.set()
        _LOGGER.info("Connected to Hegel at %s:%s", self._host, self._port)

        # cancel previous listen task if any (shouldn't normally be running)
        if self._listen_task and not self._listen_task.done():
            self._listen_task.cancel()
            try:
                await self._listen_task
            except asyncio.CancelledError:
                pass

        self._listen_task = asyncio.create_task(self._listen_loop())

    async def _close_connection(self) -> None:
        """Close TCP connection and cleanup."""
        # clear event immediately so callers know we are disconnected
        self._connected_event.clear()

        # cancel listener and await it
        if self._listen_task:
            self._listen_task.cancel()
            try:
                await self._listen_task
            except asyncio.CancelledError:
                pass
            self._listen_task = None

        # close writer
        if self._writer:
            try:
                self._writer.close()
                await self._writer.wait_closed()
            except Exception:
                pass

        self._reader = None
        self._writer = None

        # Fail all pending futures
        while self._pending:
            fut = self._pending.popleft()
            if not fut.done():
                try:
                    fut.set_exception(ConnectionError("Connection closed"))
                except Exception:
                    pass

    # ------------------------------------------------------------------ #
    # Listening / Routing
    # ------------------------------------------------------------------ #

    async def _listen_loop(self) -> None:
        """Background reader loop to handle both replies and push updates."""
        try:
            assert self._reader is not None
            while not self._reader.at_eof() and not self._stopping:
                try:
                    line = await self._reader.readuntil(separator=b"\r")
                except (
                    asyncio.IncompleteReadError,
                    ConnectionResetError,
                    OSError,
                ) as err:
                    # connection closed/RESET by peer — break and allow manager to reconnect
                    _LOGGER.error("Listen loop failed: %s", err)
                    break

                msg = line.decode(errors="ignore").strip()

                # If there is a pending future, fulfill the oldest one.
                handled = False
                if self._pending:
                    fut = self._pending.popleft()
                    if not fut.done():
                        fut.set_result(msg)
                        _LOGGER.debug("RX (reply): %s", msg)
                        handled = True

                # Push messages are delivered via callback
                if not handled:
                    _LOGGER.debug("RX (push): %s", msg)
                    if self._on_push:
                        try:
                            self._on_push(msg)
                        except Exception as err:
                            _LOGGER.error("Push callback failed: %s", err)

        except asyncio.CancelledError:
            # task cancelled — exit gracefully
            pass
        except Exception as err:
            _LOGGER.exception("Unexpected error in listen loop: %s", err)
        finally:
            # ensure connection closed and pending futures are failed
            await self._close_connection()
