2025-07-22 Version: 1.2.0
- Support API GetOrderSummaryForPartner.


2025-05-21 Version: 1.1.0
- Support API GetPlatformUserInfoForPartner.


2025-05-20 Version: 1.0.4
- Generated python 2021-01-18 for mseap.

2021-03-15 Version: 1.0.3
- Supported image quality check for certificate.
- Supported ocr for certificate.

2021-03-15 Version: 1.0.2
- Supported image quality check for certificate.
- Supported ocr for certificate.

2021-03-12 Version: 1.0.1
- Supported image quality check for certificate.
- Supported ocr for certificate.

2021-03-08 Version: 1.0.0
- Supported image quality check for certificate.
- Supported ocr for certificate.

