Parse output
============

.. automodule:: lab.parser
