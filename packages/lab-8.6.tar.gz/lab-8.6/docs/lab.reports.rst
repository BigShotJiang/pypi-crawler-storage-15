:mod:`lab.reports` -- Make reports
==================================

.. autofunction:: lab.reports.arithmetic_mean
.. autofunction:: lab.reports.geometric_mean

.. autoclass:: lab.reports.Attribute
   :members: __new__

.. autoclass:: lab.reports.Report
   :members: __call__, get_markup, get_text, write

.. autoclass:: lab.reports.filter.FilterReport
