#: Lab version number. A "+" is appended to all non-tagged revisions.
__version__ = "8.6"
