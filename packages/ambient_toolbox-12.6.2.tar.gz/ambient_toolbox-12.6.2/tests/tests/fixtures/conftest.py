"""Pytest configuration for fixture tests."""

from ambient_toolbox.tests.fixtures.block_external_requests import block_external_requests

__all__ = ["block_external_requests"]
