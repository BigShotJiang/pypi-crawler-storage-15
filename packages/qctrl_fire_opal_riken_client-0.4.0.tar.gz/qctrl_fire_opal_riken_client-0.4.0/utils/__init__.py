"""Fire Opal client utilities. Do not modify."""
