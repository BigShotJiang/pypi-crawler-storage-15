"""tests Admin file."""

from django.contrib import admin

# Register your tests models here.
