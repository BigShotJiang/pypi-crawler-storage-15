from .delimited import PushDelimited

__all__ = ["PushDelimited"]
