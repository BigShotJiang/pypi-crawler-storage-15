__all__ = [
        "Index"
]

from .main import Index

del main
