"""Widgets related to icat / drac"""
