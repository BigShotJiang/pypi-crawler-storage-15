# grokhelper

Simple Python wrapper for Grok API by xAI.

## Installation
```bash
pip install grokhelper