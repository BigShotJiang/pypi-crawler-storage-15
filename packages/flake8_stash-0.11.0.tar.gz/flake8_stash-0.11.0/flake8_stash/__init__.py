"""A collection of flake8 checks."""

__version__ = "0.11.0"
