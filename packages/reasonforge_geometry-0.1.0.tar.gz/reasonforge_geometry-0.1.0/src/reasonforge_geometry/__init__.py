"""ReasonForge Geometry - Vector/Tensor Calculus and Visualization
MCP server with 15 tools for geometry, GR, and visualization."""
__version__ = "0.1.0"
