from lingxingapi.api import API
from lingxingapi import errors

__all__ = [
    "API",
    "errors",
]
