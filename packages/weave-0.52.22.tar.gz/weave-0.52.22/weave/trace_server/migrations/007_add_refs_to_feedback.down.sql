ALTER TABLE feedback 
    DROP COLUMN annotation_ref,
    DROP COLUMN runnable_ref,
    DROP COLUMN call_ref,
    DROP COLUMN trigger_ref;
