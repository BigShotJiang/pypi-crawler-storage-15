DROP TABLE IF EXISTS calls_merged_stats;
DROP VIEW IF EXISTS calls_merged_stats_view;

DROP TABLE IF EXISTS object_versions_stats;
DROP VIEW IF EXISTS object_versions_stats_view;

DROP TABLE IF EXISTS table_rows_stats;
DROP VIEW IF EXISTS table_rows_stats_view;

DROP TABLE IF EXISTS files_stats;
DROP VIEW IF EXISTS files_stats_view;

DROP TABLE IF EXISTS feedback_stats;
DROP VIEW IF EXISTS feedback_stats_view;
