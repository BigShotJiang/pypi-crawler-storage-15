"""SQLBench - A multi-database SQL workbench."""

__version__ = "0.1.0"
