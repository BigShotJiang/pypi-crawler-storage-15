## 14.0.1.0.0

The module name has been changed from edi to edi_oca.

## 18.0.1.4.0

Components dependancy has been removed and set on a new dependant module `edi_component_oca`.
Module `edi_oca` has been_renamed to `edi_core_oca`.
