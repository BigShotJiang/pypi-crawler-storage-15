# CalColNumericOperation


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**** | [**[CalColExpression]**](CalColExpression.md) |  | [optional] 
**** | [**[CalColExpression]**](CalColExpression.md) |  | [optional] 
**** | [**[CalColExpression]**](CalColExpression.md) |  | [optional] 
**** | [**[CalColExpression]**](CalColExpression.md) |  | [optional] 
**** | [**[CalColExpression]**](CalColExpression.md) |  | [optional] 
**ln** | [**[CalColExpression]**](CalColExpression.md) |  | [optional] 
**sin** | [**[CalColExpression]**](CalColExpression.md) |  | [optional] 
**cos** | [**[CalColExpression]**](CalColExpression.md) |  | [optional] 
**tan** | [**[CalColExpression]**](CalColExpression.md) |  | [optional] 
**asin** | [**[CalColExpression]**](CalColExpression.md) |  | [optional] 
**acos** | [**[CalColExpression]**](CalColExpression.md) |  | [optional] 
**atan** | [**[CalColExpression]**](CalColExpression.md) |  | [optional] 
**sinh** | [**[CalColExpression]**](CalColExpression.md) |  | [optional] 
**cosh** | [**[CalColExpression]**](CalColExpression.md) |  | [optional] 
**tanh** | [**[CalColExpression]**](CalColExpression.md) |  | [optional] 
**asinh** | [**[CalColExpression]**](CalColExpression.md) |  | [optional] 
**acosh** | [**[CalColExpression]**](CalColExpression.md) |  | [optional] 
**atanh** | [**[CalColExpression]**](CalColExpression.md) |  | [optional] 
**abs** | [**[CalColExpression]**](CalColExpression.md) |  | [optional] 
**sqrt** | [**[CalColExpression]**](CalColExpression.md) |  | [optional] 
**sum** | [**[CalColExpression]**](CalColExpression.md) |  | [optional] 
**product** | [**[CalColExpression]**](CalColExpression.md) |  | [optional] 
**min** | [**[CalColExpression]**](CalColExpression.md) |  | [optional] 
**max** | [**[CalColExpression]**](CalColExpression.md) |  | [optional] 
**avg** | [**[CalColExpression]**](CalColExpression.md) |  | [optional] 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


