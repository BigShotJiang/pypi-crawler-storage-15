# DRDataTypes

The types of data that can be selected. `dataset` means the base dataset. `optimize` means the optimize results for the dataset. `suggest-additional` means the suggest-additional results for the dataset. Any combination of three can be selected.

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **[str]** | The types of data that can be selected. &#x60;dataset&#x60; means the base dataset. &#x60;optimize&#x60; means the optimize results for the dataset. &#x60;suggest-additional&#x60; means the suggest-additional results for the dataset. Any combination of three can be selected. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


