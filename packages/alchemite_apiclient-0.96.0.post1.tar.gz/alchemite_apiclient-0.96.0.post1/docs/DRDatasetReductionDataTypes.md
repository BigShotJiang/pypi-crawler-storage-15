# DRDatasetReductionDataTypes


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**reduction_data_types** | [**DRDataTypes**](DRDataTypes.md) |  | 
**column_type** | **str** | The type of the columns being reduced. Reduction can be done on all descriptor columns, all target columns, or all columns in the data. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


