"""Detectors library for various languages and frameworks"""
