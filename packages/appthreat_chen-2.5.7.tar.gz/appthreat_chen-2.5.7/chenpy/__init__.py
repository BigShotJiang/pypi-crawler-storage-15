"""This project offers a high level python library to interact with a chen server"""
