# Copyright (c) 2024 Fernando Libedinsky
# Product: IAToolkit Enterprise
#
# IAToolkit Enterprise is commercial, proprietary software.
# Unauthorized copying, modification, distribution, or use of this software,
# via any medium, is strictly prohibited unless explicitly permitted by the
# Enterprise License Agreement provided to the customer.
#
# This file is part of the IAToolkit Enterprise Edition and may not be
# redistributed as open-source. For licensing information, refer to:
# ENTERPRISE_LICENSE


import logging
from flask import request, jsonify, url_for
from iatoolkit.views.base_login_view import BaseLoginView
from iat_enterprise.services.corporate_auth_service import CorporateAuthService
from injector import inject
from iatoolkit.services.profile_service import ProfileService
from iatoolkit.services.auth_service import AuthService
from iatoolkit.services.query_service import QueryService
from iatoolkit.services.branding_service import BrandingService
from iatoolkit.services.configuration_service import ConfigurationService
from iatoolkit.services.prompt_service import PromptService
from iatoolkit.services.i18n_service import I18nService
from iatoolkit.common.util import Utility
from iatoolkit.services.jwt_service import JWTService


class CorporateLoginView(BaseLoginView):
    """
    Handles login for corporate users via API (Enterprise Implementation).
    """

    @inject
    def __init__(self,
                 corp_auth_service: CorporateAuthService,

                 # Dependencies for BaseLoginView
                 profile_service: ProfileService,
                 auth_service: AuthService,
                 jwt_service: JWTService,
                 branding_service: BrandingService,
                 prompt_service: PromptService,
                 config_service: ConfigurationService,
                 query_service: QueryService,
                 i18n_service: I18nService,
                 utility: Utility):

        # Initialize the parent class with its required dependencies
        super().__init__(
            profile_service=profile_service,
            auth_service=auth_service,
            jwt_service=jwt_service,
            branding_service=branding_service,
            prompt_service=prompt_service,
            config_service=config_service,
            query_service=query_service,
            i18n_service=i18n_service,
            utility=utility
        )
        # Initialize our specific dependency
        self.corp_auth_service = corp_auth_service

    def post(self, company_short_name: str):
        # Authenticate the API call.
        auth_result = self.auth_service.verify()
        if not auth_result.get("success"):
            return jsonify(auth_result), auth_result.get("status_code")

        company = self.profile_service.get_company_by_short_name(company_short_name)
        if not company:
            return jsonify({"error": f"company not found: {company_short_name}"}), 404

        user_identifier = auth_result.get('user_identifier')

        # verify the login and register the user profile in the context
        try:
            self.corp_auth_service.login(
                company=company,
                user_identifier=user_identifier
            )
        except Exception as e:
            return jsonify({"error": str(e)}), 403


        # Create a redeem_token for create session at the end of the process
        redeem_token = self.jwt_service.generate_chat_jwt(
            company_short_name=company_short_name,
            user_identifier=user_identifier,
            expires_delta_seconds=300
        )

        if not redeem_token:
            return jsonify({"error": "error generating reedem token for external login."}), 403

        # Define URL to call when slow path is finished
        target_url = url_for('finalize_with_token',
                             company_short_name=company_short_name,
                             token=redeem_token,
                             _external=True)

        # Delegate the path decision to the centralized logic.
        try:
            return self._handle_login_path(company_short_name, user_identifier, target_url, redeem_token)
        except Exception as e:
            logging.exception(f"Error processing external login path for {company_short_name}/{user_identifier}: {e}")
            return jsonify({"error": f"Internal server error while starting chat. {str(e)}"}), 500


class RedeemTokenApiView(BaseLoginView):
    # IMPORTANT: This endpoint is important used by chat_main.js
    # to redeem a chat token generated in CorporateLoginView.
    # The token is transformed into a valid IAToolkit session
    def post(self, company_short_name: str):
        data = request.get_json()
        if not data or 'token' not in data:
            return jsonify({"error": "missing validation token in api-view"}), 400

        # get the token and validate with auth service
        token = data.get('token')
        redeem_result = self.auth_service.redeem_token_for_session(
            company_short_name=company_short_name,
            token=token
        )

        if not redeem_result['success']:
            return {"error": redeem_result['error']}, 401

        return {"status": "ok"}, 200