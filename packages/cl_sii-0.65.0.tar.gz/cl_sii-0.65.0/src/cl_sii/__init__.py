"""
cl-sii Python lib
=================

"""

__version__ = '0.65.0'
