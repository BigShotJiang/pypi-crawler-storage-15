Decorators
==========

.. automodule:: yapw.decorators
