__all__ = ["__version__"]

# Single-source version for the package.
# Update this value when releasing.
__version__ = "1.5.1"
