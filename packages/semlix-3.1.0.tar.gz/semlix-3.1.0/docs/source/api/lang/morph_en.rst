========================
``lang.morph_en`` module
========================

.. automodule:: semlix.lang.morph_en

.. autofunction:: variations
