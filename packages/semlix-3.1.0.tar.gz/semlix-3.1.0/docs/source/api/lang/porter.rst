======================
``lang.porter`` module
======================

.. automodule:: semlix.lang.porter

.. autofunction:: stem
