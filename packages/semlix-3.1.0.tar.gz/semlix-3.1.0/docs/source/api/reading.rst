==================
``reading`` module
==================

.. automodule:: semlix.reading

Classes
=======

.. autoclass:: IndexReader
    :members:

.. autoclass:: MultiReader

.. autoclass:: TermInfo
   :members:

Exceptions
==========

.. autoexception:: TermNotFound

