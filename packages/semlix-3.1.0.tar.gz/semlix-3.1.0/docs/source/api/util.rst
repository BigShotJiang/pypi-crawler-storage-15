===============
``util`` module
===============

.. automodule:: semlix.util
    :members:

