============================
``filedb.structfile`` module
============================

.. automodule:: semlix.filedb.structfile

Classes
=======

.. autoclass:: StructFile
    :members:

.. autoclass:: BufferFile
.. autoclass:: ChecksumFile
