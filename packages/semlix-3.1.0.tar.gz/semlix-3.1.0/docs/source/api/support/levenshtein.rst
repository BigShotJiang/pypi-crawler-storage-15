==============================
``support.levenshtein`` module
==============================

.. automodule:: semlix.support.levenshtein

.. autofunction:: relative

.. autofunction:: distance

