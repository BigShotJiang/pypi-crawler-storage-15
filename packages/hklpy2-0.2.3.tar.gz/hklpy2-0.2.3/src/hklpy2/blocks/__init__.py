"""
Blocks support Diffractometer Operations.

.. autosummary::

   ~configure
   ~constraints
   ~lattice
   ~reflection
   ~sample
"""
