.. _examples:

==========
Examples
==========

Example documents and notebooks to demonstrate |hklpy2|. The notebooks are
available for download from the source code website:
https://github.com/bluesky/hklpy2/docs/source/examples.

.. toctree::
   :glob:
   :hidden:

   examples/*
