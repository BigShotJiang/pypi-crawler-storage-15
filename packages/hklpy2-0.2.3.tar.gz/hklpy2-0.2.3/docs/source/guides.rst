.. _guides:

==========
Guides
==========

.. toctree::
   :glob:
   :hidden:

   guides/*

Guides, how-to documents, notebooks and tutorials.
