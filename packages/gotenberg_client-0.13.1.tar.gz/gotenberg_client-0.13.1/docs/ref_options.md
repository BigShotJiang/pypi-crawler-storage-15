# API Option Types

::: gotenberg_client.options.CookieJar
    handler: python

::: gotenberg_client.options.PageMarginsType
    handler: python

::: gotenberg_client.options.PageOrientation
    handler: python

::: gotenberg_client.options.PageSize
    handler: python

::: gotenberg_client.options.MeasurementUnitType
    handler: python

::: gotenberg_client.options.Measurement
    handler: python
