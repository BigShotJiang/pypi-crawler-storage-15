# API Modules

::: gotenberg_client._chromium.SyncChromiumApi
    handler: python

::: gotenberg_client._chromium.AsyncChromiumApi
    handler: python

::: gotenberg_client._libreoffice.SyncLibreOfficeApi
    handler: python

::: gotenberg_client._libreoffice.AsyncLibreOfficeApi
    handler: python

::: gotenberg_client._pdfa_ua.SyncPdfAApi
    handler: python

::: gotenberg_client._pdfa_ua.AsyncPdfAApi
    handler: python

::: gotenberg_client._pdfmetadata.SyncPdfMetadataApi
    handler: python

::: gotenberg_client._pdfmetadata.AsyncPdfMetadataApi
    handler: python

::: gotenberg_client._merge.SyncMergePdfsApi
    handler: python

::: gotenberg_client._merge.AsyncMergePdfsApi
    handler: python

::: gotenberg_client._others.SyncSplitApi
    handler: python

::: gotenberg_client._others.AyncSplitApi
    handler: python

::: gotenberg_client._others.SyncFlattenApi
    handler: python

::: gotenberg_client._others.AyncFlattenApi
    handler: python

::: gotenberg_client._health.SyncHealthCheckApi
    handler: python

::: gotenberg_client._health.AsyncHealthCheckApi
    handler: python
