# API Errors

::: gotenberg_client.BaseClientError
    handler: python

::: gotenberg_client.CannotExtractHereError
    handler: python

::: gotenberg_client.InvalidPdfRevisionError
    handler: python

::: gotenberg_client.MaxRetriesExceededError
    handler: python

::: gotenberg_client.NegativeWaitDurationError
    handler: python
