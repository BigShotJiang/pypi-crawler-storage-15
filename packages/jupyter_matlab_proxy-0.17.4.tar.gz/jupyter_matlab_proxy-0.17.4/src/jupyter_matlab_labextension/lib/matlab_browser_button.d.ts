import { JupyterFrontEndPlugin } from '@jupyterlab/application';
export declare const matlabToolbarButtonPlugin: JupyterFrontEndPlugin<void>;
