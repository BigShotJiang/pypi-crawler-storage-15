# NullFox Encrypter 🦊🔥

A lightweight Lua script encryption module created by NullF🦊X.

## Features
- XOR + Base64 encryption
- Fast and simple
- Works on any file

## Usage