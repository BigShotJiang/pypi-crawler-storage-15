## Briefcase Automation

This package provides Briefcase plugins to facilitate automation in CI.

This package is internal to Briefcase's own development and is not needed to create, develop, or distribute apps created with Briefcase.

### Bootstraps

There are bootstrap plugins for each GUI toolkit; each allows for Briefcase to create a project using the toolkit but when the project's app runs, the app automatically exits after a few seconds.
