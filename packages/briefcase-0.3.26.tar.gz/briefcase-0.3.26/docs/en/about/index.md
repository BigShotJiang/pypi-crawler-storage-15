# About Briefcase { #about }

Various details about Briefcase as a project.

* [Frequently asked questions][frequently-asked-questions] - Answers to common questions about using Briefcase.
* [Success stories][success-stories] - Examples of app built with Briefcase.
* [Release history][release-history] - A list of changes made in each release.
