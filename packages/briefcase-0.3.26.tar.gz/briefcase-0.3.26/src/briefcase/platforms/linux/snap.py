# A Snap implementation would go here!
