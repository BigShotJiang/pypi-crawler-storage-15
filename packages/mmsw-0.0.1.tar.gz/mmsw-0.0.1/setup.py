from setuptools import setup, find_packages

setup(
    name='mmsw',
    version='0.0.1',
    description='Matilo (C) Deep-Learning Model Serving Worker Module',
    author='ryuvsken',
    author_email='ryuvskendev@gmail.com',
    url='https://github.com/ryuvsken',
    install_requires=['sqlalchemy', 'pymysql', 'requests',],
    packages=find_packages(exclude=[]),
    keywords=['Deep-Learning', 'Model Serving', 'Matilo'],
    python_requires='>=3.11',
    package_data={},
    zip_safe=False,
    classifiers=[
        'Programming Language :: Python :: 3.11',
    ],
)
