from .profiling import memray_profiling

__all__ = ["memray_profiling"]
