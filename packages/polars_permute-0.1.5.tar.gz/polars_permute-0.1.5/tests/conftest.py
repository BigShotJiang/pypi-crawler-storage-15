import polars_permute  # noqa: F401
