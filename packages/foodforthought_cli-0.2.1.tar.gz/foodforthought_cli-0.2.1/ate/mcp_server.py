#!/usr/bin/env python3
"""
FoodforThought MCP Server - Model Context Protocol server for Cursor IDE
Exposes FoodforThought CLI capabilities as MCP tools

Installation:
    pip install -r requirements-mcp.txt

Usage:
    python -m ate.mcp_server

Or configure in Cursor's mcp.json:
    {
      "mcpServers": {
        "foodforthought": {
          "command": "python",
          "args": ["-m", "ate.mcp_server"],
          "env": {
            "ATE_API_URL": "https://kindly.fyi/api",
            "ATE_API_KEY": "${env:ATE_API_KEY}"
          }
        }
      }
    }
"""

import asyncio
import json
import os
import sys
from typing import Any, Dict, List, Optional
from pathlib import Path

# Import the existing CLI client
from ate.cli import ATEClient

# MCP SDK imports - using standard MCP Python SDK pattern
try:
    from mcp.server import Server
    from mcp.server.stdio import stdio_server
    from mcp.types import (
        Tool,
        TextContent,
        Resource,
        Prompt,
        PromptArgument,
    )
except ImportError:
    try:
        # Alternative import path for some MCP SDK versions
        from mcp import Server, stdio_server
        from mcp.types import Tool, TextContent, Resource, Prompt, PromptArgument
    except ImportError:
        # Fallback if MCP SDK not available - provide helpful error
        print(
            "Error: MCP SDK not installed. Install with: pip install mcp",
            file=sys.stderr,
        )
        sys.exit(1)

# Initialize MCP server
server = Server("foodforthought")

# Initialize ATE client
client = ATEClient()


# ============================================================================
# Tool Definitions
# ============================================================================

def get_repository_tools() -> List[Tool]:
    """Repository management tools"""
    return [
        Tool(
            name="ate_init",
            description="Initialize a new FoodforThought repository for robot skills",
            inputSchema={
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "description": "Repository name",
                    },
                    "description": {
                        "type": "string",
                        "description": "Repository description",
                    },
                    "visibility": {
                        "type": "string",
                        "enum": ["public", "private"],
                        "description": "Repository visibility",
                        "default": "public",
                    },
                },
                "required": ["name"],
            },
        ),
        Tool(
            name="ate_clone",
            description="Clone a FoodforThought repository to local directory",
            inputSchema={
                "type": "object",
                "properties": {
                    "repo_id": {
                        "type": "string",
                        "description": "Repository ID to clone",
                    },
                    "target_dir": {
                        "type": "string",
                        "description": "Target directory (optional)",
                    },
                },
                "required": ["repo_id"],
            },
        ),
        Tool(
            name="ate_list_repositories",
            description="List available FoodforThought repositories",
            inputSchema={
                "type": "object",
                "properties": {
                    "search": {
                        "type": "string",
                        "description": "Search query",
                    },
                    "robot_model": {
                        "type": "string",
                        "description": "Filter by robot model",
                    },
                    "limit": {
                        "type": "number",
                        "description": "Maximum number of results",
                        "default": 20,
                    },
                },
            },
        ),
        Tool(
            name="ate_get_repository",
            description="Get details of a specific repository",
            inputSchema={
                "type": "object",
                "properties": {
                    "repo_id": {
                        "type": "string",
                        "description": "Repository ID",
                    },
                },
                "required": ["repo_id"],
            },
        ),
    ]


def get_robot_tools() -> List[Tool]:
    """Robot profile tools"""
    return [
        Tool(
            name="ate_list_robots",
            description="List available robot profiles",
            inputSchema={
                "type": "object",
                "properties": {
                    "search": {
                        "type": "string",
                        "description": "Search query",
                    },
                    "category": {
                        "type": "string",
                        "description": "Filter by category",
                    },
                    "limit": {
                        "type": "number",
                        "description": "Maximum number of results",
                        "default": 20,
                    },
                },
            },
        ),
        Tool(
            name="ate_get_robot",
            description="Get details of a specific robot profile",
            inputSchema={
                "type": "object",
                "properties": {
                    "robot_id": {
                        "type": "string",
                        "description": "Robot profile ID",
                    },
                },
                "required": ["robot_id"],
            },
        ),
    ]


def get_compatibility_tools() -> List[Tool]:
    """Skill compatibility and adaptation tools"""
    return [
        Tool(
            name="ate_check_transfer",
            description="Check skill transfer compatibility between two robot models",
            inputSchema={
                "type": "object",
                "properties": {
                    "source_robot": {
                        "type": "string",
                        "description": "Source robot model name",
                    },
                    "target_robot": {
                        "type": "string",
                        "description": "Target robot model name",
                    },
                    "skill_id": {
                        "type": "string",
                        "description": "Optional skill ID to check",
                    },
                    "min_score": {
                        "type": "number",
                        "description": "Minimum compatibility score threshold (0.0-1.0)",
                        "default": 0.0,
                    },
                },
                "required": ["source_robot", "target_robot"],
            },
        ),
        Tool(
            name="ate_adapt",
            description="Generate adaptation plan for transferring skills between robots",
            inputSchema={
                "type": "object",
                "properties": {
                    "source_robot": {
                        "type": "string",
                        "description": "Source robot model",
                    },
                    "target_robot": {
                        "type": "string",
                        "description": "Target robot model",
                    },
                    "repo_id": {
                        "type": "string",
                        "description": "Repository ID to adapt",
                    },
                    "analyze_only": {
                        "type": "boolean",
                        "description": "Only show compatibility analysis",
                        "default": True,
                    },
                },
                "required": ["source_robot", "target_robot"],
            },
        ),
    ]


def get_skill_tools() -> List[Tool]:
    """Skill data tools"""
    return [
        Tool(
            name="ate_pull",
            description="Pull skill data for training in various formats (JSON, RLDS, LeRobot)",
            inputSchema={
                "type": "object",
                "properties": {
                    "skill_id": {
                        "type": "string",
                        "description": "Skill ID to pull",
                    },
                    "robot": {
                        "type": "string",
                        "description": "Filter by robot model",
                    },
                    "format": {
                        "type": "string",
                        "enum": ["json", "rlds", "lerobot"],
                        "description": "Output format",
                        "default": "json",
                    },
                    "output": {
                        "type": "string",
                        "description": "Output directory",
                        "default": "./data",
                    },
                },
                "required": ["skill_id"],
            },
        ),
        Tool(
            name="ate_upload",
            description="Upload demonstration videos for community labeling",
            inputSchema={
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Path to video file",
                    },
                    "robot": {
                        "type": "string",
                        "description": "Robot model in the video",
                    },
                    "task": {
                        "type": "string",
                        "description": "Task being demonstrated",
                    },
                    "project": {
                        "type": "string",
                        "description": "Project ID to associate with",
                    },
                },
                "required": ["path", "robot", "task"],
            },
        ),
    ]


def get_parts_tools() -> List[Tool]:
    """Hardware parts management tools"""
    return [
        Tool(
            name="ate_parts_list",
            description="List available hardware parts in the catalog",
            inputSchema={
                "type": "object",
                "properties": {
                    "category": {
                        "type": "string",
                        "enum": ["gripper", "sensor", "actuator", "controller", 
                                "end-effector", "camera", "lidar", "force-torque"],
                        "description": "Filter by part category",
                    },
                    "manufacturer": {
                        "type": "string",
                        "description": "Filter by manufacturer",
                    },
                    "search": {
                        "type": "string",
                        "description": "Search by name or part number",
                    },
                },
            },
        ),
        Tool(
            name="ate_parts_check",
            description="Check part compatibility requirements for a skill",
            inputSchema={
                "type": "object",
                "properties": {
                    "skill_id": {
                        "type": "string",
                        "description": "Skill ID to check parts for",
                    },
                },
                "required": ["skill_id"],
            },
        ),
        Tool(
            name="ate_parts_require",
            description="Add a part dependency to a skill",
            inputSchema={
                "type": "object",
                "properties": {
                    "part_id": {
                        "type": "string",
                        "description": "Part ID to require",
                    },
                    "skill_id": {
                        "type": "string",
                        "description": "Skill ID",
                    },
                    "version": {
                        "type": "string",
                        "description": "Minimum version",
                        "default": "1.0.0",
                    },
                    "required": {
                        "type": "boolean",
                        "description": "Mark as required (not optional)",
                        "default": False,
                    },
                },
                "required": ["part_id", "skill_id"],
            },
        ),
        Tool(
            name="ate_deps_audit",
            description="Audit and verify all dependencies are compatible for a skill",
            inputSchema={
                "type": "object",
                "properties": {
                    "skill_id": {
                        "type": "string",
                        "description": "Skill ID (optional, uses current repo if not specified)",
                    },
                },
            },
        ),
    ]


def get_generate_tools() -> List[Tool]:
    """Skill generation tools"""
    return [
        Tool(
            name="ate_generate",
            description="Generate skill scaffolding from a natural language task description",
            inputSchema={
                "type": "object",
                "properties": {
                    "description": {
                        "type": "string",
                        "description": "Natural language task description (e.g., 'pick up box and place on pallet')",
                    },
                    "robot": {
                        "type": "string",
                        "description": "Target robot model",
                        "default": "ur5",
                    },
                    "output": {
                        "type": "string",
                        "description": "Output directory for generated files",
                        "default": "./new-skill",
                    },
                },
                "required": ["description"],
            },
        ),
    ]


def get_workflow_tools() -> List[Tool]:
    """Workflow composition tools"""
    return [
        Tool(
            name="ate_workflow_validate",
            description="Validate a workflow YAML file for skill composition",
            inputSchema={
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Path to workflow YAML file",
                    },
                },
                "required": ["path"],
            },
        ),
        Tool(
            name="ate_workflow_run",
            description="Run a skill workflow/pipeline",
            inputSchema={
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Path to workflow YAML file",
                    },
                    "sim": {
                        "type": "boolean",
                        "description": "Run in simulation mode",
                        "default": True,
                    },
                    "dry_run": {
                        "type": "boolean",
                        "description": "Show execution plan without running",
                        "default": False,
                    },
                },
                "required": ["path"],
            },
        ),
        Tool(
            name="ate_workflow_export",
            description="Export workflow to other formats (ROS2 launch, JSON)",
            inputSchema={
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Path to workflow YAML file",
                    },
                    "format": {
                        "type": "string",
                        "enum": ["ros2", "json"],
                        "description": "Export format",
                        "default": "ros2",
                    },
                    "output": {
                        "type": "string",
                        "description": "Output file path",
                    },
                },
                "required": ["path"],
            },
        ),
    ]


def get_team_tools() -> List[Tool]:
    """Team collaboration tools"""
    return [
        Tool(
            name="ate_team_create",
            description="Create a new team for collaboration",
            inputSchema={
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "description": "Team name",
                    },
                    "description": {
                        "type": "string",
                        "description": "Team description",
                    },
                },
                "required": ["name"],
            },
        ),
        Tool(
            name="ate_team_list",
            description="List teams you belong to",
            inputSchema={
                "type": "object",
                "properties": {},
            },
        ),
        Tool(
            name="ate_team_invite",
            description="Invite a user to a team",
            inputSchema={
                "type": "object",
                "properties": {
                    "email": {
                        "type": "string",
                        "description": "Email of user to invite",
                    },
                    "team": {
                        "type": "string",
                        "description": "Team slug",
                    },
                    "role": {
                        "type": "string",
                        "enum": ["owner", "admin", "member", "viewer"],
                        "description": "Role to assign",
                        "default": "member",
                    },
                },
                "required": ["email", "team"],
            },
        ),
        Tool(
            name="ate_team_share",
            description="Share a skill with a team",
            inputSchema={
                "type": "object",
                "properties": {
                    "skill_id": {
                        "type": "string",
                        "description": "Skill ID to share",
                    },
                    "team": {
                        "type": "string",
                        "description": "Team slug",
                    },
                },
                "required": ["skill_id", "team"],
            },
        ),
    ]


def get_data_tools() -> List[Tool]:
    """Dataset management tools"""
    return [
        Tool(
            name="ate_data_upload",
            description="Upload sensor data or demonstration logs for a skill",
            inputSchema={
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Path to data directory or file",
                    },
                    "skill": {
                        "type": "string",
                        "description": "Associated skill ID",
                    },
                    "stage": {
                        "type": "string",
                        "enum": ["raw", "annotated", "skill-abstracted", "production"],
                        "description": "Data stage",
                        "default": "raw",
                    },
                },
                "required": ["path", "skill"],
            },
        ),
        Tool(
            name="ate_data_list",
            description="List datasets for a skill",
            inputSchema={
                "type": "object",
                "properties": {
                    "skill": {
                        "type": "string",
                        "description": "Filter by skill ID",
                    },
                    "stage": {
                        "type": "string",
                        "description": "Filter by data stage",
                    },
                },
            },
        ),
        Tool(
            name="ate_data_promote",
            description="Promote a dataset to the next stage in the pipeline",
            inputSchema={
                "type": "object",
                "properties": {
                    "dataset_id": {
                        "type": "string",
                        "description": "Dataset ID",
                    },
                    "to_stage": {
                        "type": "string",
                        "enum": ["annotated", "skill-abstracted", "production"],
                        "description": "Target stage",
                    },
                },
                "required": ["dataset_id", "to_stage"],
            },
        ),
        Tool(
            name="ate_data_export",
            description="Export a dataset in various formats",
            inputSchema={
                "type": "object",
                "properties": {
                    "dataset_id": {
                        "type": "string",
                        "description": "Dataset ID",
                    },
                    "format": {
                        "type": "string",
                        "enum": ["json", "rlds", "lerobot", "hdf5"],
                        "description": "Export format",
                        "default": "rlds",
                    },
                    "output": {
                        "type": "string",
                        "description": "Output directory",
                        "default": "./export",
                    },
                },
                "required": ["dataset_id"],
            },
        ),
    ]


def get_deploy_tools() -> List[Tool]:
    """Deployment management tools"""
    return [
        Tool(
            name="ate_deploy",
            description="Deploy skills to a robot",
            inputSchema={
                "type": "object",
                "properties": {
                    "robot_type": {
                        "type": "string",
                        "description": "Robot type to deploy to",
                    },
                    "repo_id": {
                        "type": "string",
                        "description": "Repository ID (uses current repo if not specified)",
                    },
                },
                "required": ["robot_type"],
            },
        ),
        Tool(
            name="ate_deploy_config",
            description="Deploy skills using a deployment configuration file (supports hybrid edge/cloud)",
            inputSchema={
                "type": "object",
                "properties": {
                    "config_path": {
                        "type": "string",
                        "description": "Path to deploy.yaml configuration",
                    },
                    "target": {
                        "type": "string",
                        "description": "Target fleet or robot",
                    },
                    "dry_run": {
                        "type": "boolean",
                        "description": "Show deployment plan without executing",
                        "default": False,
                    },
                },
                "required": ["config_path", "target"],
            },
        ),
        Tool(
            name="ate_deploy_status",
            description="Check deployment status for a fleet or robot",
            inputSchema={
                "type": "object",
                "properties": {
                    "target": {
                        "type": "string",
                        "description": "Target fleet or robot",
                    },
                },
                "required": ["target"],
            },
        ),
    ]


def get_test_tools() -> List[Tool]:
    """Testing and validation tools"""
    return [
        Tool(
            name="ate_test",
            description="Test skills in simulation (Gazebo, MuJoCo, PyBullet, Webots)",
            inputSchema={
                "type": "object",
                "properties": {
                    "environment": {
                        "type": "string",
                        "enum": ["gazebo", "mujoco", "pybullet", "webots"],
                        "description": "Simulation environment",
                        "default": "pybullet",
                    },
                    "robot": {
                        "type": "string",
                        "description": "Robot model to test with",
                    },
                    "local": {
                        "type": "boolean",
                        "description": "Run simulation locally",
                        "default": False,
                    },
                },
            },
        ),
        Tool(
            name="ate_validate",
            description="Run safety and compliance validation checks",
            inputSchema={
                "type": "object",
                "properties": {
                    "checks": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Safety checks to run (collision, speed, workspace, force, all)",
                        "default": ["all"],
                    },
                    "strict": {
                        "type": "boolean",
                        "description": "Use strict validation (fail on warnings)",
                        "default": False,
                    },
                },
            },
        ),
        Tool(
            name="ate_benchmark",
            description="Run performance benchmarks on skills",
            inputSchema={
                "type": "object",
                "properties": {
                    "type": {
                        "type": "string",
                        "enum": ["speed", "accuracy", "robustness", "efficiency", "all"],
                        "description": "Benchmark type",
                        "default": "all",
                    },
                    "trials": {
                        "type": "number",
                        "description": "Number of trials",
                        "default": 10,
                    },
                    "compare": {
                        "type": "string",
                        "description": "Compare with baseline repository ID",
                    },
                },
            },
        ),
    ]


@server.list_tools()
async def list_tools() -> List[Tool]:
    """List all available MCP tools"""
    tools = []
    tools.extend(get_repository_tools())
    tools.extend(get_robot_tools())
    tools.extend(get_compatibility_tools())
    tools.extend(get_skill_tools())
    tools.extend(get_parts_tools())
    tools.extend(get_generate_tools())
    tools.extend(get_workflow_tools())
    tools.extend(get_team_tools())
    tools.extend(get_data_tools())
    tools.extend(get_deploy_tools())
    tools.extend(get_test_tools())
    return tools


# ============================================================================
# Tool Handlers
# ============================================================================

def capture_output(func, *args, **kwargs):
    """Capture printed output from a function"""
    import io
    import contextlib
    
    f = io.StringIO()
    with contextlib.redirect_stdout(f):
        try:
            result = func(*args, **kwargs)
        except SystemExit:
            pass  # CLI functions may call sys.exit
    return f.getvalue()


@server.call_tool()
async def call_tool(name: str, arguments: Dict[str, Any]) -> List[TextContent]:
    """Handle tool calls"""
    try:
        # Repository tools
        if name == "ate_init":
            result = client.init(
                arguments["name"],
                arguments.get("description", ""),
                arguments.get("visibility", "public"),
            )
            return [
                TextContent(
                    type="text",
                    text=f"Repository created successfully!\nID: {result['repository']['id']}\nName: {result['repository']['name']}",
                )
            ]

        elif name == "ate_clone":
            output = capture_output(
                client.clone,
                arguments["repo_id"], 
                arguments.get("target_dir")
            )
            return [TextContent(type="text", text=output or f"Repository cloned successfully")]

        elif name == "ate_list_repositories":
            params = {}
            if arguments.get("search"):
                params["search"] = arguments["search"]
            if arguments.get("robot_model"):
                params["robotModel"] = arguments["robot_model"]
            params["limit"] = arguments.get("limit", 20)

            response = client._request("GET", "/repositories", params=params)
            repos = response.get("repositories", [])

            result_text = f"Found {len(repos)} repositories:\n\n"
            for repo in repos[:10]:
                result_text += f"- {repo['name']} (ID: {repo['id']})\n"
                if repo.get("description"):
                    result_text += f"  {repo['description'][:100]}...\n"

            return [TextContent(type="text", text=result_text)]

        elif name == "ate_get_repository":
            response = client._request("GET", f"/repositories/{arguments['repo_id']}")
            repo = response.get("repository", {})

            result_text = f"Repository: {repo.get('name', 'Unknown')}\n"
            result_text += f"ID: {repo.get('id', 'Unknown')}\n"
            result_text += f"Description: {repo.get('description', 'No description')}\n"
            result_text += f"Visibility: {repo.get('visibility', 'unknown')}\n"

            return [TextContent(type="text", text=result_text)]

        # Robot tools
        elif name == "ate_list_robots":
            params = {}
            if arguments.get("search"):
                params["search"] = arguments["search"]
            if arguments.get("category"):
                params["category"] = arguments["category"]
            params["limit"] = arguments.get("limit", 20)

            response = client._request("GET", "/robots/profiles", params=params)
            robots = response.get("profiles", [])

            result_text = f"Found {len(robots)} robot profiles:\n\n"
            for robot in robots[:10]:
                result_text += f"- {robot['modelName']} by {robot['manufacturer']} (ID: {robot['id']})\n"
                if robot.get("description"):
                    result_text += f"  {robot['description'][:100]}...\n"

            return [TextContent(type="text", text=result_text)]

        elif name == "ate_get_robot":
            response = client._request("GET", f"/robots/profiles/{arguments['robot_id']}")
            robot = response.get("profile", {})

            result_text = f"Robot: {robot.get('modelName', 'Unknown')}\n"
            result_text += f"Manufacturer: {robot.get('manufacturer', 'Unknown')}\n"
            result_text += f"Category: {robot.get('category', 'Unknown')}\n"
            result_text += f"Description: {robot.get('description', 'No description')}\n"

            return [TextContent(type="text", text=result_text)]

        # Compatibility tools
        elif name == "ate_check_transfer":
            output = capture_output(
                client.check_transfer,
                arguments.get("skill_id"),
                arguments["source_robot"],
                arguments["target_robot"],
                arguments.get("min_score", 0.0)
            )
            return [TextContent(type="text", text=output)]

        elif name == "ate_adapt":
            output = capture_output(
                client.adapt,
                arguments["source_robot"],
                arguments["target_robot"],
                arguments.get("repo_id"),
                arguments.get("analyze_only", True)
            )
            return [TextContent(type="text", text=output)]

        # Skill tools
        elif name == "ate_pull":
            output = capture_output(
                client.pull,
                arguments["skill_id"],
                arguments.get("robot"),
                arguments.get("format", "json"),
                arguments.get("output", "./data")
            )
            return [TextContent(type="text", text=output)]

        elif name == "ate_upload":
            output = capture_output(
                client.upload,
                arguments["path"],
                arguments["robot"],
                arguments["task"],
                arguments.get("project")
            )
            return [TextContent(type="text", text=output)]

        # Parts tools
        elif name == "ate_parts_list":
            output = capture_output(
                client.parts_list,
                arguments.get("category"),
                arguments.get("manufacturer"),
                arguments.get("search")
            )
            return [TextContent(type="text", text=output)]

        elif name == "ate_parts_check":
            output = capture_output(
                client.parts_check,
                arguments["skill_id"]
            )
            return [TextContent(type="text", text=output)]

        elif name == "ate_parts_require":
            output = capture_output(
                client.parts_require,
                arguments["part_id"],
                arguments["skill_id"],
                arguments.get("version", "1.0.0"),
                arguments.get("required", False)
            )
            return [TextContent(type="text", text=output)]

        elif name == "ate_deps_audit":
            output = capture_output(
                client.deps_audit,
                arguments.get("skill_id")
            )
            return [TextContent(type="text", text=output)]

        # Generate tools
        elif name == "ate_generate":
            output = capture_output(
                client.generate,
                arguments["description"],
                arguments.get("robot", "ur5"),
                arguments.get("output", "./new-skill")
            )
            return [TextContent(type="text", text=output)]

        # Workflow tools
        elif name == "ate_workflow_validate":
            output = capture_output(
                client.workflow_validate,
                arguments["path"]
            )
            return [TextContent(type="text", text=output)]

        elif name == "ate_workflow_run":
            output = capture_output(
                client.workflow_run,
                arguments["path"],
                arguments.get("sim", True),
                arguments.get("dry_run", False)
            )
            return [TextContent(type="text", text=output)]

        elif name == "ate_workflow_export":
            output = capture_output(
                client.workflow_export,
                arguments["path"],
                arguments.get("format", "ros2"),
                arguments.get("output")
            )
            return [TextContent(type="text", text=output)]

        # Team tools
        elif name == "ate_team_create":
            output = capture_output(
                client.team_create,
                arguments["name"],
                arguments.get("description")
            )
            return [TextContent(type="text", text=output)]

        elif name == "ate_team_list":
            output = capture_output(client.team_list)
            return [TextContent(type="text", text=output)]

        elif name == "ate_team_invite":
            output = capture_output(
                client.team_invite,
                arguments["email"],
                arguments["team"],
                arguments.get("role", "member")
            )
            return [TextContent(type="text", text=output)]

        elif name == "ate_team_share":
            output = capture_output(
                client.team_share,
                arguments["skill_id"],
                arguments["team"]
            )
            return [TextContent(type="text", text=output)]

        # Data tools
        elif name == "ate_data_upload":
            output = capture_output(
                client.data_upload,
                arguments["path"],
                arguments["skill"],
                arguments.get("stage", "raw")
            )
            return [TextContent(type="text", text=output)]

        elif name == "ate_data_list":
            output = capture_output(
                client.data_list,
                arguments.get("skill"),
                arguments.get("stage")
            )
            return [TextContent(type="text", text=output)]

        elif name == "ate_data_promote":
            output = capture_output(
                client.data_promote,
                arguments["dataset_id"],
                arguments["to_stage"]
            )
            return [TextContent(type="text", text=output)]

        elif name == "ate_data_export":
            output = capture_output(
                client.data_export,
                arguments["dataset_id"],
                arguments.get("format", "rlds"),
                arguments.get("output", "./export")
            )
            return [TextContent(type="text", text=output)]

        # Deploy tools
        elif name == "ate_deploy":
            output = capture_output(
                client.deploy,
                arguments["robot_type"],
                arguments.get("repo_id")
            )
            return [TextContent(type="text", text=output)]

        elif name == "ate_deploy_config":
            output = capture_output(
                client.deploy_config,
                arguments["config_path"],
                arguments["target"],
                arguments.get("dry_run", False)
            )
            return [TextContent(type="text", text=output)]

        elif name == "ate_deploy_status":
            output = capture_output(
                client.deploy_status,
                arguments["target"]
            )
            return [TextContent(type="text", text=output)]

        # Test tools
        elif name == "ate_test":
            output = capture_output(
                client.test,
                arguments.get("environment", "pybullet"),
                arguments.get("robot"),
                arguments.get("local", False)
            )
            return [TextContent(type="text", text=output)]

        elif name == "ate_validate":
            output = capture_output(
                client.validate,
                arguments.get("checks", ["all"]),
                arguments.get("strict", False),
                None  # files
            )
            return [TextContent(type="text", text=output)]

        elif name == "ate_benchmark":
            output = capture_output(
                client.benchmark,
                arguments.get("type", "all"),
                arguments.get("trials", 10),
                arguments.get("compare")
            )
            return [TextContent(type="text", text=output)]

        else:
            return [
                TextContent(
                    type="text",
                    text=f"Unknown tool: {name}",
                )
            ]

    except Exception as e:
        return [
            TextContent(
                type="text",
                text=f"Error executing tool {name}: {str(e)}",
            )
        ]


# ============================================================================
# Resources
# ============================================================================

@server.list_resources()
async def list_resources() -> List[Resource]:
    """List available resources"""
    return [
        Resource(
            uri="repository://*",
            name="Repository",
            description="Access FoodforThought repository details",
            mimeType="application/json",
        ),
        Resource(
            uri="robot://*",
            name="Robot Profile",
            description="Access robot profile details",
            mimeType="application/json",
        ),
        Resource(
            uri="skill://*",
            name="Skill",
            description="Access skill/artifact details",
            mimeType="application/json",
        ),
        Resource(
            uri="part://*",
            name="Hardware Part",
            description="Access hardware part details",
            mimeType="application/json",
        ),
        Resource(
            uri="workflow://*",
            name="Workflow",
            description="Access workflow definition",
            mimeType="application/yaml",
        ),
        Resource(
            uri="team://*",
            name="Team",
            description="Access team details",
            mimeType="application/json",
        ),
    ]


@server.read_resource()
async def read_resource(uri: str) -> str:
    """Read a resource"""
    if uri.startswith("repository://"):
        repo_id = uri.replace("repository://", "")
        response = client._request("GET", f"/repositories/{repo_id}")
        return json.dumps(response.get("repository", {}), indent=2)
    elif uri.startswith("robot://"):
        robot_id = uri.replace("robot://", "")
        response = client._request("GET", f"/robots/profiles/{robot_id}")
        return json.dumps(response.get("profile", {}), indent=2)
    elif uri.startswith("skill://"):
        skill_id = uri.replace("skill://", "")
        response = client._request("GET", f"/skills/{skill_id}")
        return json.dumps(response.get("skill", {}), indent=2)
    elif uri.startswith("part://"):
        part_id = uri.replace("part://", "")
        response = client._request("GET", f"/parts/{part_id}")
        return json.dumps(response.get("part", {}), indent=2)
    elif uri.startswith("team://"):
        team_slug = uri.replace("team://", "")
        response = client._request("GET", f"/teams/{team_slug}")
        return json.dumps(response.get("team", {}), indent=2)
    else:
        raise ValueError(f"Unknown resource URI: {uri}")


# ============================================================================
# Prompts
# ============================================================================

@server.list_prompts()
async def list_prompts() -> List[Prompt]:
    """List available prompts"""
    return [
        Prompt(
            name="create_skill",
            description="Guided workflow for creating a new robot skill from scratch",
            arguments=[
                PromptArgument(
                    name="robot_model",
                    description="Target robot model",
                    required=True,
                ),
                PromptArgument(
                    name="task_description",
                    description="Natural language description of the skill/task",
                    required=True,
                ),
            ],
        ),
        Prompt(
            name="adapt_skill",
            description="Guided workflow for adapting a skill between different robots",
            arguments=[
                PromptArgument(
                    name="source_robot",
                    description="Source robot model",
                    required=True,
                ),
                PromptArgument(
                    name="target_robot",
                    description="Target robot model",
                    required=True,
                ),
                PromptArgument(
                    name="repository_id",
                    description="Repository ID to adapt",
                    required=True,
                ),
            ],
        ),
        Prompt(
            name="setup_workflow",
            description="Create a multi-skill workflow/pipeline",
            arguments=[
                PromptArgument(
                    name="task_description",
                    description="Description of the overall task",
                    required=True,
                ),
                PromptArgument(
                    name="robot",
                    description="Target robot model",
                    required=True,
                ),
            ],
        ),
        Prompt(
            name="deploy_skill",
            description="Deploy a skill to production robots",
            arguments=[
                PromptArgument(
                    name="skill_id",
                    description="Skill ID to deploy",
                    required=True,
                ),
                PromptArgument(
                    name="target",
                    description="Target fleet or robot",
                    required=True,
                ),
            ],
        ),
        Prompt(
            name="debug_compatibility",
            description="Debug why a skill isn't transferring well between robots",
            arguments=[
                PromptArgument(
                    name="source_robot",
                    description="Source robot model",
                    required=True,
                ),
                PromptArgument(
                    name="target_robot",
                    description="Target robot model",
                    required=True,
                ),
                PromptArgument(
                    name="skill_id",
                    description="Skill ID having issues",
                    required=True,
                ),
            ],
        ),
    ]


@server.get_prompt()
async def get_prompt(name: str, arguments: Dict[str, Any]) -> List[TextContent]:
    """Get prompt content"""
    if name == "create_skill":
        return [
            TextContent(
                type="text",
                text=f"""# Create a Robot Skill for {arguments.get('robot_model', 'your robot')}

## Task: {arguments.get('task_description', 'Not specified')}

### Steps:

1. **Generate Scaffolding**
   Use `ate_generate` to create skill files from your task description:
   - This creates skill.yaml, main.py, test_skill.py, and README.md

2. **Review Generated Files**
   - Check skill.yaml for correct parameters
   - Implement the TODO sections in main.py

3. **Add Part Dependencies**
   Use `ate_parts_list` to find required hardware, then `ate_parts_require` to add dependencies

4. **Test in Simulation**
   Use `ate_test` with environment="pybullet" to validate the skill

5. **Run Safety Validation**
   Use `ate_validate` with checks=["collision", "speed", "workspace", "force"]

6. **Upload Demonstrations**
   Use `ate_upload` to submit demo videos for community labeling

7. **Check Transfer Compatibility**
   Use `ate_check_transfer` to see which other robots can use this skill
""",
            )
        ]
    
    elif name == "adapt_skill":
        return [
            TextContent(
                type="text",
                text=f"""# Adapt Skill from {arguments.get('source_robot')} to {arguments.get('target_robot')}

## Repository: {arguments.get('repository_id')}

### Steps:

1. **Check Compatibility**
   Use `ate_check_transfer` to get the compatibility score and adaptation type

2. **Generate Adaptation Plan**
   Use `ate_adapt` to see what changes are needed:
   - Kinematic adaptations
   - Sensor mappings
   - Code modifications

3. **Review Requirements**
   - Check if new parts are needed with `ate_parts_check`
   - Verify hardware compatibility

4. **Apply Adaptations**
   Based on the adaptation type:
   - **Direct**: No changes needed
   - **Parametric**: Adjust configuration values
   - **Retrain**: Collect new demonstrations
   - **Manual**: Significant code changes required

5. **Test Adapted Skill**
   Use `ate_test` with robot="{arguments.get('target_robot')}"

6. **Validate Safety**
   Use `ate_validate` with strict=true for production deployment
""",
            )
        ]
    
    elif name == "setup_workflow":
        return [
            TextContent(
                type="text",
                text=f"""# Create Multi-Skill Workflow

## Task: {arguments.get('task_description', 'Not specified')}
## Robot: {arguments.get('robot', 'Not specified')}

### Steps:

1. **Define Workflow Steps**
   Create a workflow.yaml file with your skill pipeline:
   ```yaml
   name: My Workflow
   version: 1.0.0
   robot:
     model: {arguments.get('robot', 'ur5')}
   steps:
     - id: step1
       skill: perception/detect-object
     - id: step2
       skill: manipulation/pick
       depends_on: [step1]
   ```

2. **Validate Workflow**
   Use `ate_workflow_validate` to check for errors

3. **Test in Simulation**
   Use `ate_workflow_run` with sim=true

4. **Dry Run**
   Use `ate_workflow_run` with dry_run=true to see execution plan

5. **Export for Production**
   Use `ate_workflow_export` with format="ros2" for ROS2 launch file
""",
            )
        ]
    
    elif name == "deploy_skill":
        return [
            TextContent(
                type="text",
                text=f"""# Deploy Skill to Production

## Skill: {arguments.get('skill_id')}
## Target: {arguments.get('target')}

### Pre-Deployment Checklist:

1. **Audit Dependencies**
   Use `ate_deps_audit` to verify all parts are available

2. **Run Validation**
   Use `ate_validate` with strict=true

3. **Benchmark Performance**
   Use `ate_benchmark` to ensure acceptable performance

4. **Check Deployment Config**
   Create deploy.yaml for hybrid edge/cloud deployment if needed

### Deployment Steps:

1. **Dry Run**
   Use `ate_deploy_config` with dry_run=true to preview

2. **Deploy**
   Use `ate_deploy` or `ate_deploy_config` to push to target

3. **Monitor Status**
   Use `ate_deploy_status` to check deployment health
""",
            )
        ]
    
    elif name == "debug_compatibility":
        return [
            TextContent(
                type="text",
                text=f"""# Debug Skill Transfer Compatibility

## Source: {arguments.get('source_robot')}
## Target: {arguments.get('target_robot')}
## Skill: {arguments.get('skill_id')}

### Diagnostic Steps:

1. **Get Compatibility Score**
   Use `ate_check_transfer` to see overall compatibility

2. **Check Score Breakdown**
   Look at individual scores:
   - Kinematic score: Joint configurations, workspace overlap
   - Sensor score: Camera, force/torque sensor compatibility
   - Compute score: Processing power requirements

3. **Review Part Requirements**
   Use `ate_parts_check` to see required hardware for the skill

4. **Compare Robot Profiles**
   Use `ate_get_robot` for both source and target to compare specs

5. **Generate Adaptation Plan**
   Use `ate_adapt` to get specific recommendations

### Common Issues:

- **Low Kinematic Score**: Check joint limits, reach, payload
- **Low Sensor Score**: Missing cameras or sensors
- **Low Compute Score**: Target robot has less processing power
- **Impossible Transfer**: Fundamentally incompatible hardware
""",
            )
        ]
    
    else:
        return [TextContent(type="text", text=f"Unknown prompt: {name}")]


async def main():
    """Main entry point for MCP server"""
    # Run the server using stdio transport
    stdin, stdout = stdio_server()
    await server.run(
        stdin, stdout, server.create_initialization_options()
    )


if __name__ == "__main__":
    asyncio.run(main())
