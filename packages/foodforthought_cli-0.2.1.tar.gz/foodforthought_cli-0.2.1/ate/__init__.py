"""FoodforThought CLI (ATE) - GitHub-like interface for robotics repositories"""

__version__ = "0.2.1"

