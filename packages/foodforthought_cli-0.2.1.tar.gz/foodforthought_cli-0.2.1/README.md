# FoodforThought CLI

GitHub-like CLI tool for the FoodforThought robotics repository platform.

## Installation

```bash
pip install foodforthought-cli
```

Or install from source:

```bash
cd foodforthought-cli
pip install -e .
```

## Configuration

Set environment variables:

```bash
export ATE_API_URL="https://kindly.fyi/api"
export ATE_API_KEY="your-api-key-here"
```

## Usage

### Initialize a repository

```bash
ate init my-robot-skill -d "A skill for my robot" -v public
```

### Clone a repository

```bash
ate clone <repository-id>
```

### Create a commit

```bash
ate commit -m "Add new control algorithm"
```

### Push to remote

```bash
ate push -b main
```

### Deploy to robot

```bash
ate deploy unitree-r1
```

## Commands

### Repository Management
- `ate init <name>` - Initialize a new repository
- `ate clone <repo-id>` - Clone a repository
- `ate commit -m <message>` - Create a commit
- `ate push [-b <branch>]` - Push commits to remote

### Skill Pipeline
- `ate pull <skill-id> [--robot <robot>] [--format json|rlds|lerobot] [--output ./data]` - Pull skill data for training
- `ate upload <video-path> --robot <robot> --task <task> [--project <id>]` - Upload demonstrations for labeling
- `ate check-transfer --from <source-robot> --to <target-robot> [--skill <id>]` - Check skill transfer compatibility
- `ate labeling-status <job-id>` - Check labeling job status

### Deployment & Testing
- `ate deploy <robot-type>` - Deploy to a robot (e.g., unitree-r1)
- `ate test [-e gazebo|mujoco|pybullet|webots] [-r robot]` - Test skills in simulation
- `ate benchmark [-t speed|accuracy|robustness|efficiency|all]` - Run performance benchmarks
- `ate adapt <source-robot> <target-robot>` - Adapt skills between robots

### Safety & Validation
- `ate validate [-c collision|speed|workspace|force|all]` - Validate safety and compliance
- `ate stream [start|stop|status] [-s sensors...]` - Stream sensor data

## Cursor IDE Integration (MCP)

FoodforThought CLI supports Model Context Protocol (MCP) for integration with Cursor IDE.

### Installation

1. Install MCP dependencies:
   ```bash
   pip install -r requirements-mcp.txt
   ```

2. Get your MCP configuration from the [FoodforThought homepage](https://kindly.fyi/foodforthought)

3. Place `mcp.json` in `~/.cursor/mcp.json` (global) or `.cursor/mcp.json` (project)

4. Set your `ATE_API_KEY` environment variable

5. Restart Cursor

### Available MCP Tools

- `ate_init` - Initialize a new repository
- `ate_clone` - Clone a repository
- `ate_list_repositories` - List available repositories
- `ate_list_robots` - List robot profiles
- `ate_compatibility` - Check skill compatibility between robots
- `ate_adapt` - Generate adaptation plans for skills

See the [MCP documentation](https://cursor.com/docs/context/mcp) for more information.

