"""Integrations for external logging services."""

from netrun_logging.integrations.azure_insights import configure_azure_insights

__all__ = ["configure_azure_insights"]
