"""
Defines constants representing different modification modes for codemod operations.
"""

PREPEND = 0
APPEND = 1
REPLACE = 2
