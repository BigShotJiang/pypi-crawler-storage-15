# bqapi


Current package build to the [local PyPi package](https://gitlab.com/viqi/bisque/bisque05/bisque/-/packages) via [.gitlab-ci.yml](../.gitlab-ci.yml) is *only* used by [ai_trainer module](https://gitlab.com/viqi/analysis/ai_trainer).  Bisque stable build is done on drop.


## Versioning
Versioning uses setuptools-scm modified to look for a git tag in the format `bqapi-v<x.x.x.x>`, eg:


`bqapi-v0.5.10.7`
