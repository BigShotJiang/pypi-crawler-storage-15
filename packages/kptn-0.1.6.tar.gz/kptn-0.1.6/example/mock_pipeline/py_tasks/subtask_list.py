from kptn.util.pipeline_config import PipelineConfig


def subtask_list(pipeline_config: PipelineConfig) -> list[str]:
    return ["T1", "T2"]
