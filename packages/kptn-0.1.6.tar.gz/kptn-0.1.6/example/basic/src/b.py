
def b():
  print("This is _b_")