# gitro

Git Remote Open.

## Usage

Open your current repository with `uvx gitro`.
Or install `gitro` with `python -m pip install gitro` and call `gitro`.
