"A WeakAuras Companion port for shellfolk."

from __future__ import annotations

NAME = __spec__.parent
