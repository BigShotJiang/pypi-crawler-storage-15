"""
drpy.batch: a module for batch processing.
"""

from .core import CCDDataList

__all__ = ['CCDDataList']