"""
drpy.image: a toolkit to reduce image data.
"""

from .core import concatenate

__all__ = ['concatenate']