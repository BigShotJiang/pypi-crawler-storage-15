from django.apps import AppConfig


class ChangeformActionsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "changeform_actions"
