Module blaxel.core.mcp.client
=============================

Functions
---------

`remove_request_params(url: str) ‑> str`
:   

`websocket_client(url: str, headers: dict[str, typing.Any] | None = None, timeout: float = 30)`
:   Client transport for WebSocket.
    
    The `timeout` parameter controls connection timeout.