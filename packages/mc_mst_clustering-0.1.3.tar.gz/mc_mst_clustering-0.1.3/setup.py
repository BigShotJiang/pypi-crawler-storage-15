from setuptools import setup, find_packages

setup(
    name="mc-mst-clustering",
    version="0.1.3",  # Incremented version for PyPI
    author="Ali Şenol",
    author_email="alisenol@tarsus.edu.tr",
    description="MCMSTClustering: Minimum-cost MST based clustering algorithm",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/senolali/MCMSTClustering",
    packages=find_packages(include=["mc_mst_clustering", "mc_mst_clustering.*"]),
    include_package_data=True,
    python_requires=">=3.8",
    install_requires=[
        "numpy>=1.20",
        "scipy>=1.10",
        "scikit-learn>=1.2",
        "matplotlib>=3.7",
        "seaborn>=0.12"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent"
    ]
)
