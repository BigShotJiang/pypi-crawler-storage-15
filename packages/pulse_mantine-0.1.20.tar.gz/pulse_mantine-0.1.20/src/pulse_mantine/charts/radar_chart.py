from typing import Any

import pulse as ps


@ps.react_component("RadarChart", "@mantine/charts")
def RadarChart(key: str | None = None, **props: Any): ...
