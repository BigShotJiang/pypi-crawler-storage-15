from typing import Any

import pulse as ps


@ps.react_component("DonutChart", "@mantine/charts")
def DonutChart(key: str | None = None, **props: Any): ...
