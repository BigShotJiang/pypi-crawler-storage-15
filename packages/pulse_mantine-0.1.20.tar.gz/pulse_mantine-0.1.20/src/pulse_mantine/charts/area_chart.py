from typing import Any

import pulse as ps


@ps.react_component("AreaChart", "@mantine/charts")
def AreaChart(key: str | None = None, **props: Any): ...
