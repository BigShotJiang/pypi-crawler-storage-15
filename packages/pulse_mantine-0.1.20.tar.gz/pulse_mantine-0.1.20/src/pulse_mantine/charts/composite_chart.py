from typing import Any

import pulse as ps


@ps.react_component("CompositeChart", "@mantine/charts")
def CompositeChart(key: str | None = None, **props: Any): ...
