from typing import Any

import pulse as ps


@ps.react_component("Day", "pulse-mantine")
def Day(key: str | None = None, **props: Any): ...
