from typing import Any

import pulse as ps


@ps.react_component("Month", "pulse-mantine")
def Month(key: str | None = None, **props: Any): ...
