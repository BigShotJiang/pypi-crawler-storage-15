from typing import Any

import pulse as ps


@ps.react_component("WeekdaysRow", "pulse-mantine")
def WeekdaysRow(key: str | None = None, **props: Any): ...
