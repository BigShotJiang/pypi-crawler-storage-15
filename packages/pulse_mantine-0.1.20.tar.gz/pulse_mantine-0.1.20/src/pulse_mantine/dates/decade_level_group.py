from typing import Any

import pulse as ps


@ps.react_component("DecadeLevelGroup", "pulse-mantine")
def DecadeLevelGroup(key: str | None = None, **props: Any): ...
