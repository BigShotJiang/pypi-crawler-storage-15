from typing import Any

import pulse as ps


@ps.react_component("FileInput", "pulse-mantine")
def FileInput(*children: ps.Child, key: str | None = None, **props: Any): ...
