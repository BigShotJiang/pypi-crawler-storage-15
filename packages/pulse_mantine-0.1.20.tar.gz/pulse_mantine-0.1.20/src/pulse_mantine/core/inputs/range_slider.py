from typing import Any

import pulse as ps


@ps.react_component("RangeSlider", "pulse-mantine")
def RangeSlider(*children: ps.Child, key: str | None = None, **props: Any): ...
