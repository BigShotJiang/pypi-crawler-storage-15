from typing import Any

import pulse as ps


@ps.react_component("TextInput", "pulse-mantine")
def TextInput(*children: ps.Child, key: str | None = None, **props: Any): ...
