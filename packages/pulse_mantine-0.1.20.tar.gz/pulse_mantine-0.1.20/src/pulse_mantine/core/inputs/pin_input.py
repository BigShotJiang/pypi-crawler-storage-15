from typing import Any

import pulse as ps


@ps.react_component("PinInput", "pulse-mantine")
def PinInput(key: str | None = None, **props: Any): ...
