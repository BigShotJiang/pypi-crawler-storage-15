from typing import Any

import pulse as ps


@ps.react_component("Rating", "pulse-mantine")
def Rating(key: str | None = None, **props: Any): ...
