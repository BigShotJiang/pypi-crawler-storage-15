from typing import Any

import pulse as ps


@ps.react_component("Mark", "@mantine/core")
def Mark(*children: ps.Child, key: str | None = None, **props: Any): ...
