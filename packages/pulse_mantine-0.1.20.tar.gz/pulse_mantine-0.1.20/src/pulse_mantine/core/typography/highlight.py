from typing import Any

import pulse as ps


@ps.react_component("Highlight", "@mantine/core")
def Highlight(key: str | None = None, **props: Any): ...
