from typing import Any

import pulse as ps


@ps.react_component("Typography", "@mantine/core")
def Typography(key: str | None = None, **props: Any): ...
