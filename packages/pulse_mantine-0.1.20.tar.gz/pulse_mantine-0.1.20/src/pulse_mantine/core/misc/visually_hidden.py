from typing import Any

import pulse as ps


@ps.react_component("VisuallyHidden", "@mantine/core")
def VisuallyHidden(*children: ps.Child, key: str | None = None, **props: Any): ...
