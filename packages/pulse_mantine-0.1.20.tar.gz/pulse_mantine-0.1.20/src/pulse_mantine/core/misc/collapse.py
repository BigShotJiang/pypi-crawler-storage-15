from typing import Any

import pulse as ps


@ps.react_component("Collapse", "@mantine/core")
def Collapse(*children: ps.Child, key: str | None = None, **props: Any): ...
