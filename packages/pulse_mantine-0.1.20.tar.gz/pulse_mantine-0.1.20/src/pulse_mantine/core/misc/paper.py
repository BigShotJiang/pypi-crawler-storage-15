from typing import Any

import pulse as ps


@ps.react_component("Paper", "@mantine/core")
def Paper(*children: ps.Child, key: str | None = None, **props: Any): ...
