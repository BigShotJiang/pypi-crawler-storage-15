from typing import Any

import pulse as ps


@ps.react_component("TagsInput", "@mantine/core")
def TagsInput(key: str | None = None, **props: Any): ...
