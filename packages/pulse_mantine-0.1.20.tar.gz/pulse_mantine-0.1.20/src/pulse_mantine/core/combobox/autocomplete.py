from typing import Any

import pulse as ps


@ps.react_component("Autocomplete", "@mantine/core")
def Autocomplete(key: str | None = None, **props: Any): ...
