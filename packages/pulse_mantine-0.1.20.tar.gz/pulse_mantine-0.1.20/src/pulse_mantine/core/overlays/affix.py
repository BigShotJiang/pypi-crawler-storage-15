from typing import Any

import pulse as ps


@ps.react_component("Affix", "@mantine/core")
def Affix(*children: ps.Child, key: str | None = None, **props: Any): ...
