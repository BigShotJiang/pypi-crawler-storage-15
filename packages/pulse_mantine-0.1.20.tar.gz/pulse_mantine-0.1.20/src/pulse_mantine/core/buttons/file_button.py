from typing import Any

import pulse as ps


@ps.react_component("FileButton", "@mantine/core")
def FileButton(*children: ps.Child, key: str | None = None, **props: Any): ...
