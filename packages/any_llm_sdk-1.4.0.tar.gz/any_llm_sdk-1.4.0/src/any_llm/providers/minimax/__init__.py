from .minimax import MinimaxProvider

__all__ = ["MinimaxProvider"]
