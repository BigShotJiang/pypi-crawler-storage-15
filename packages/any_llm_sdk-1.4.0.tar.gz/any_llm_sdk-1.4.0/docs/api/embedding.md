## Embedding

::: any_llm.api.embedding
::: any_llm.api.aembedding
