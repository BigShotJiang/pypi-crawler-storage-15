## Completion

::: any_llm.api.completion
::: any_llm.api.acompletion
