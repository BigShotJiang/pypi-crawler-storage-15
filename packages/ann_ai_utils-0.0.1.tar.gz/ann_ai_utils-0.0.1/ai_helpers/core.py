def get_response(prompt):
    return f"[STUB] You asked: {prompt}"

def format_response(text):
    return text.strip()
