# ai_helpers

Simple helper functions for AI projects.

## Usage
```python
from ai_helpers import get_response
print(get_response("Hello"))
