# Bulk API Client (`Client`)

::: anaplan_sdk.Client

<style>
    [data-md-component="toc"] li:first-of-type{
        display:  none!important;
    }
</style>
