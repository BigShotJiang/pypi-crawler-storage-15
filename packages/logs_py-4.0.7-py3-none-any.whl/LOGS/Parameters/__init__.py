"""
This package is written for the LOGS Repository.

It's objects can be used to write your own dataset parser.

License:
Permission to use this libraray and all of its contents is
strictly permitted to the Signals Company.
"""

from .Color import *
from .ParameterBase import *
from .ParameterElement import *
