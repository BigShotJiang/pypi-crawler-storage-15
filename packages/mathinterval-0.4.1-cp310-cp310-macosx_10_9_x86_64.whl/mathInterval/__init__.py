from ._mathInterval import *
from ._mathInterval import __doc__
