"""CLI entry point for Obra Client."""

import json
import os
import sys
import time
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.prompt import Prompt

from obra_client import __version__
from obra_client.api_client import APIClient
from obra_client.config import (
    DEFAULT_API_BASE_URL,
    DEFAULT_AUTH_METHOD,
    DEFAULT_MODEL,
    DEFAULT_PROVIDER,
    FIREBASE_API_KEY,
    LLM_AUTH_METHODS,
    LLM_PROVIDERS,
    PRIVACY_VERSION,
    TERMS_VERSION,
    clear_firebase_auth,
    get_auth_provider,
    get_firebase_uid,
    get_llm_config,
    get_llm_display,
    get_refresh_token,
    get_user_email,
    is_authenticated,
    is_terms_accepted,
    load_config,
    needs_reacceptance,
    save_config,
    save_firebase_auth,
    save_terms_acceptance,
    set_llm_config,
)
from obra_client.exceptions import (
    APIError,
    AuthenticationError,
    ConfigurationError,
    ExecutionError,
    TermsNotAcceptedError,
)
from obra_client.executor import ClaudeCodeExecutor
from obra_client.legal import get_terms_summary
from obra_client.prompt_enricher import PromptEnricher
from obra_client.session_manager import SessionManager

app = typer.Typer(
    name="obra-client",
    help="Obra SaaS Client - LLM Proxy with prompt enrichment for Cloud Functions orchestration",
    add_completion=False,
)

console = Console()


def require_config() -> dict:
    """Load configuration and verify it exists.

    Returns:
        Configuration dictionary

    Raises:
        ConfigurationError: If config file doesn't exist or is invalid
    """
    from obra_client.config import CONFIG_PATH

    config = load_config()
    if not config:
        raise ConfigurationError(
            f"Configuration file not found: {CONFIG_PATH}\n"
            "Run 'obra-client setup' to create it."
        )
    return config


def require_terms_accepted() -> None:
    """Check if terms have been accepted, exit if not.

    This is a HARD STOP GATE - commands cannot proceed without terms acceptance.

    Raises:
        typer.Exit: If terms not accepted (exit code 1)
    """
    if not is_terms_accepted():
        console.print("\n[red]Terms not accepted.[/red]")
        console.print("Run 'obra-client setup' first to accept the Beta Terms.")
        raise typer.Exit(1)

    # Check for version mismatch (re-acceptance needed)
    if needs_reacceptance():
        console.print("\n[yellow]Terms have been updated (v{TERMS_VERSION}).[/yellow]")
        console.print("Run 'obra-client setup' to accept the updated terms.")
        raise typer.Exit(1)


@app.command()
def setup() -> None:
    """Run first-time setup with REQUIRED terms acceptance.

    This command MUST be run before using any other obra-client commands.
    It performs these steps:

    1. Terms Acceptance (REQUIRED): Display and accept Beta Terms + Privacy Policy
    2. Authentication: Sign in with Firebase Auth (Google or GitHub OAuth)
    3. LLM Configuration: Configure implementation LLM settings

    The terms acceptance is a legal requirement - you cannot use obra-client
    without accepting the terms.

    Creates ~/.obra/client-config.yaml with configuration and acceptance state.
    """
    from obra_client.auth import (
        login_with_browser,
        save_auth,
        verify_beta_access,
    )
    from obra_client.config import CONFIG_PATH

    console.print(f"\n[bold]OBRA CLIENT SETUP[/bold] [dim]v{__version__}[/dim]")
    console.print("=" * 70)

    # Check if already set up
    existing_config = load_config()
    existing_acceptance = is_terms_accepted()
    already_authenticated = is_authenticated()

    if existing_config and existing_acceptance and already_authenticated:
        console.print(f"\n[green]✓[/green] Configuration exists: {CONFIG_PATH}")
        console.print(f"[green]✓[/green] Terms v{TERMS_VERSION} already accepted")
        console.print(f"[green]✓[/green] Signed in as: {get_user_email()}")
        console.print("\n[dim]To reconfigure, delete ~/.obra/client-config.yaml and run setup again.[/dim]")
        raise typer.Exit(0)

    # Check if re-acceptance needed (version change)
    if needs_reacceptance():
        console.print("\n[yellow]Terms have been updated. Re-acceptance required.[/yellow]")

    # =========================================================================
    # STEP 1: Terms Acceptance (REQUIRED - HARD STOP GATE)
    # =========================================================================
    if not existing_acceptance or needs_reacceptance():
        console.print("\n[bold red]STEP 1: TERMS ACCEPTANCE (REQUIRED)[/bold red]")
        console.print("-" * 70)
        console.print()

        # Display Plain Language Summary
        terms_summary = get_terms_summary()
        console.print(Panel(
            terms_summary,
            title="[bold red]PLAIN LANGUAGE SUMMARY[/bold red]",
            border_style="red",
        ))

        console.print()
        console.print("[bold]Full documents:[/bold]")
        console.print("  Terms:   [link=https://obra.dev/terms]https://obra.dev/terms[/link]")
        console.print("  Privacy: [link=https://obra.dev/privacy]https://obra.dev/privacy[/link]")
        console.print()
        console.print("[dim]Tip: Open these URLs in your browser before accepting.[/dim]")
        console.print()

        # Display acceptance confirmations (12 items from BETA_TERMS.md v2.1)
        console.print("[bold]BY TYPING \"I ACCEPT\", YOU CONFIRM THAT:[/bold]")
        console.print()
        confirmations = [
            "You have had the OPPORTUNITY TO READ the full terms and UNDERSTAND they are legally binding",
            "You AGREE to be legally bound by all terms",
            "You are using this as an INDIVIDUAL on personal equipment",
            "You are NOT using any Employer Systems or corporate equipment",
            "You are NOT using this for any business or organizational purpose",
            "You MEET all requirements in Section 3 (Tester Representations)",
            "You ACCEPT all risks described in Section 15 (Assumption of Risk)",
            "You AGREE to BINDING ARBITRATION (Section 23, with exceptions)",
            "You WAIVE your right to participate in class actions (Section 25)",
            "You WAIVE your right to a jury trial (Section 25)",
            "You UNDERSTAND certain provisions survive termination (Section 21)",
            "You had OPPORTUNITY TO CONSULT WITH LEGAL COUNSEL before accepting",
        ]
        for i, conf in enumerate(confirmations, 1):
            console.print(f"  [bold]{i:2}.[/bold] {conf}")

        console.print()
        console.print("[bold yellow]Type \"I ACCEPT\" to accept all terms, or \"EXIT\" to abort.[/bold yellow]")
        console.print()

        # Get user input
        user_input = typer.prompt("Your response").strip()

        if user_input.upper() == "EXIT":
            console.print("\n[dim]Setup aborted. You must accept the terms to use obra-client.[/dim]")
            raise typer.Exit(0)

        if user_input.upper() != "I ACCEPT":
            console.print("\n[red]Invalid response. You must type exactly \"I ACCEPT\" to proceed.[/red]")
            console.print("[dim]Run 'obra setup' again to retry.[/dim]")
            raise typer.Exit(1)

        console.print("\n[green]✓[/green] Terms acceptance recorded")

        # Save terms acceptance LOCALLY (will be registered with server after auth)
        save_terms_acceptance(TERMS_VERSION, PRIVACY_VERSION)
        console.print(f"[green]✓[/green] Local acceptance cache saved (v{TERMS_VERSION})")
    else:
        console.print(f"\n[green]✓[/green] Terms v{TERMS_VERSION} already accepted")

    # =========================================================================
    # STEP 2: Firebase Authentication
    # =========================================================================
    console.print("\n[bold]STEP 2: AUTHENTICATION[/bold]")
    console.print("-" * 70)

    if already_authenticated:
        email = get_user_email()
        console.print(f"\n[green]✓[/green] Already signed in as: {email}")
        auth_result = None
    else:
        console.print("\n[dim]Sign in with your Google or GitHub account.[/dim]")
        console.print("[dim]Your email must be on the beta allowlist.[/dim]")
        console.print()
        console.print("[bold]Opening browser for authentication...[/bold]")
        console.print("[dim]Waiting for authentication (timeout: 5 minutes)...[/dim]\n")

        try:
            # Perform browser OAuth
            auth_result = login_with_browser(timeout=300)

            console.print(f"[green]✓[/green] Signed in as: {auth_result.email}")
            console.print(f"[dim]  Provider: {auth_result.auth_provider}[/dim]")

            # Verify beta access
            console.print("\n[bold]Verifying beta access...[/bold]")

            try:
                verify_beta_access(auth_result.id_token, DEFAULT_API_BASE_URL)
                console.print(f"[green]✓[/green] Beta access verified")
            except AuthenticationError as e:
                console.print(f"\n[red]✗ Access denied:[/red] {e}")
                console.print("\n[dim]Your authentication succeeded, but you don't have beta access.[/dim]")
                console.print("[dim]Contact the Obra team to request access.[/dim]")
                raise typer.Exit(1)

            # Save authentication
            save_auth(auth_result)
            console.print(f"[green]✓[/green] Authentication saved")

        except AuthenticationError as e:
            console.print(f"\n[red]✗ Authentication failed:[/red] {e}")
            raise typer.Exit(1)

        except TimeoutError as e:
            console.print(f"\n[red]✗ Timeout:[/red] {e}")
            console.print("[dim]The browser sign-in was not completed in time.[/dim]")
            raise typer.Exit(1)

        except Exception as e:
            console.print(f"\n[red]✗ Unexpected error:[/red] {e}")
            raise typer.Exit(1)

    # =========================================================================
    # STEP 3: Register Terms Acceptance with Server
    # =========================================================================
    console.print("\n[bold]STEP 3: VERIFICATION[/bold]")
    console.print("-" * 70)

    # Initialize basic config
    config = load_config()
    config["api_base_url"] = DEFAULT_API_BASE_URL
    config["firebase_api_key"] = FIREBASE_API_KEY
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    save_config(config)

    try:
        # Create authenticated API client
        api_client = APIClient(
            base_url=DEFAULT_API_BASE_URL,
            auth_token=config.get("auth_token"),
            refresh_token=config.get("refresh_token"),
            firebase_api_key=FIREBASE_API_KEY,
        )

        # Check health
        health = api_client.health_check()
        console.print(f"[green]✓[/green] API reachable (status: {health['status']})")

        # Check version
        version_info = api_client.get_version()
        console.print(f"[green]✓[/green] API version: {version_info['api_version']}")

        # Check client compatibility
        min_version = version_info.get("min_client_version", "0.1.0")
        if __version__ < min_version:
            console.print(
                f"\n[yellow]⚠ Warning: Client version ({__version__}) "
                f"below minimum ({min_version})[/yellow]"
            )
            console.print("[dim]Consider: pip install --upgrade obra-client[/dim]")

        # Register terms acceptance with server
        console.print("\n[bold]Registering terms acceptance with server...[/bold]")
        server_logged = api_client.log_terms_acceptance(
            terms_version=TERMS_VERSION,
            privacy_version=PRIVACY_VERSION,
            client_version=__version__,
            source="cli_setup",
            user_id=get_firebase_uid(),
            email=get_user_email(),
        )
        if server_logged:
            console.print("[green]✓[/green] Terms acceptance registered with server")
        else:
            console.print("[yellow]⚠[/yellow] Could not register terms acceptance with server")
            console.print("[dim]Local acceptance is saved. Server registration will be retried on next use.[/dim]")

    except APIError as e:
        console.print(f"[yellow]⚠[/yellow] Could not verify API: {e}")
        console.print("[dim]You can still use the client, check API URL if issues persist.[/dim]")

    # =========================================================================
    # STEP 4: LLM Configuration
    # =========================================================================
    console.print("\n[bold]STEP 4: LLM CONFIGURATION[/bold]")
    console.print("-" * 70)
    console.print()
    console.print("[dim]Obra uses two LLMs:[/dim]")
    console.print("[dim]  • Orchestrator: Plans and coordinates tasks (server-side)[/dim]")
    console.print("[dim]  • Implementation: Executes code changes (local)[/dim]")
    console.print()

    # Configure both roles
    env_vars_needed = set()
    oauth_logins_needed = set()

    for role in ["orchestrator", "implementation"]:
        role_display = role.capitalize()
        console.print(f"\n[bold cyan]━━━ {role_display} LLM ━━━[/bold cyan]")
        console.print()

        # Step 1: Provider selection
        console.print("[bold]1. Select Provider:[/bold]")
        provider_keys = list(LLM_PROVIDERS.keys())
        for i, key in enumerate(provider_keys, 1):
            info = LLM_PROVIDERS[key]
            default_marker = " [green](recommended)[/green]" if key == DEFAULT_PROVIDER else ""
            console.print(f"   {i}. {info['name']}{default_marker} - {info['description']}")

        provider_choice = typer.prompt(
            f"   Select (1-{len(provider_keys)})",
            default="1",
        )

        try:
            provider_idx = int(provider_choice) - 1
            if provider_idx < 0 or provider_idx >= len(provider_keys):
                provider_idx = 0
            selected_provider = provider_keys[provider_idx]
        except ValueError:
            selected_provider = DEFAULT_PROVIDER

        provider_info = LLM_PROVIDERS[selected_provider]

        # Step 2: Auth method selection
        console.print()
        console.print("[bold]2. Select Auth Method:[/bold]")
        auth_keys = list(LLM_AUTH_METHODS.keys())
        for i, key in enumerate(auth_keys, 1):
            info = LLM_AUTH_METHODS[key]
            default_marker = " [green](recommended)[/green]" if key == "oauth" else ""
            console.print(f"   {i}. {info['name']}{default_marker}")
            console.print(f"      [dim]{info['description']}[/dim]")
            if key == "api_key":
                console.print(f"      [yellow]{info['note']}[/yellow]")

        auth_choice = typer.prompt(
            f"   Select (1-{len(auth_keys)})",
            default="1",
        )

        try:
            auth_idx = int(auth_choice) - 1
            if auth_idx < 0 or auth_idx >= len(auth_keys):
                auth_idx = 0
            selected_auth = auth_keys[auth_idx]
        except ValueError:
            selected_auth = DEFAULT_AUTH_METHOD

        # Step 3: Model selection (only for API Key auth)
        if selected_auth == "oauth":
            # OAuth users get "default" automatically - simplest path
            selected_model = "default"
            console.print()
            console.print("   [green]✓[/green] Model: default (provider's optimal choice)")
            console.print("   [dim]OAuth uses the provider's recommended model automatically.[/dim]")
        else:
            # API Key users can choose their model
            console.print()
            console.print("[bold]3. Select Model:[/bold]")

            models = provider_info["models"]
            for i, model in enumerate(models, 1):
                if model == "default":
                    console.print(f"   {i}. default - Provider's optimal choice")
                else:
                    console.print(f"   {i}. {model}")

            model_choice = typer.prompt(
                f"   Select (1-{len(models)})",
                default="1",
            )

            try:
                model_idx = int(model_choice) - 1
                if model_idx < 0 or model_idx >= len(models):
                    model_idx = 0
                selected_model = models[model_idx]
            except ValueError:
                selected_model = DEFAULT_MODEL

        # Save config for this role
        set_llm_config(role, selected_provider, selected_auth, selected_model)

        # Track auth requirements
        if selected_auth == "oauth":
            # OAuth uses browser-based login
            cli = provider_info.get("cli", "claude")
            oauth_logins_needed.add((provider_info["name"], cli))
        else:
            # API Key auth needs env var
            api_key_env = provider_info.get("api_key_env_var")
            if api_key_env:
                env_vars_needed.add(api_key_env)

        # Show confirmation
        console.print()
        console.print(f"   [green]✓[/green] {role_display}: {get_llm_display(role)}")

    # =========================================================================
    # Complete
    # =========================================================================
    console.print("\n" + "=" * 70)
    console.print("[bold green]SETUP COMPLETE[/bold green]")
    console.print("=" * 70)

    # Show auth requirements
    if oauth_logins_needed:
        console.print("\n[bold]OAuth Login Required:[/bold]")
        console.print("  [dim]Run these commands to authenticate (browser-based):[/dim]")
        for provider_name, cli in sorted(oauth_logins_needed):
            console.print(f"  {cli} --login          # {provider_name}")

    if env_vars_needed:
        console.print("\n[bold]API Key Required:[/bold]")
        console.print("  [dim]Set these environment variables:[/dim]")
        for env_var in sorted(env_vars_needed):
            console.print(f"  export {env_var}='your-api-key'")  # pragma: allowlist secret

    console.print()
    console.print("[bold]LLM Configuration Summary:[/bold]")
    console.print(f"  Orchestrator:    {get_llm_display('orchestrator')}")
    console.print(f"  Implementation:  {get_llm_display('implementation')}")

    console.print("\n[bold]Quick Start (Human Users):[/bold]")
    console.print("  obra-client interactive          # Start REPL for iterative work")
    console.print("  obra-client orchestrate \"task\"   # One-shot task execution")
    console.print("  obra-client health-check         # Verify installation")

    console.print("\n[bold]For LLM Agents (Claude Code, etc.):[/bold]")
    console.print("  obra-client docs onboarding      # Agent setup guide")
    console.print("  obra-client docs examples        # Usage patterns & templates")
    console.print()
    console.print("  [dim]Hint: Have your LLM agent run 'obra-client docs onboarding'[/dim]")
    console.print("  [dim]to read the getting-started guide before orchestrating tasks.[/dim]")

    console.print("\n[bold]Troubleshooting:[/bold]")
    console.print("  obra-client health-check         # Diagnose issues")
    console.print("  obra-client version              # Check compatibility")

    console.print(f"\n[dim]Config saved to: {CONFIG_PATH}[/dim]")
    console.print("[dim]To reconfigure: delete config file and run 'obra-client setup' again[/dim]")


@app.command()
def orchestrate(
    objective: str,
    project_dir: Optional[str] = None,
    task_type: str = "feature",
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show detailed debug output"),
) -> None:
    """Start orchestration session with Cloud Functions.

    Args:
        objective: Task objective (e.g., "Add user authentication")
        project_dir: Project directory (default: current directory)
        task_type: Type of task (feature, bug_fix, refactor, etc.)
        verbose: Show detailed debug output including server responses

    Example:
        obra-client orchestrate "Add rate limiting to API"
        obra-client orchestrate "Fix login bug" --task-type bug_fix
        obra-client orchestrate "Add feature" --verbose
    """
    # HARD STOP GATE: Require terms acceptance
    require_terms_accepted()

    try:
        # Load configuration
        config = require_config()

        # Determine project directory
        working_dir = Path(project_dir or os.getcwd()).resolve()

        if not working_dir.exists():
            console.print(f"[red]❌ Project directory not found: {working_dir}[/red]")
            raise typer.Exit(1)

        console.print(f"\n[bold]🚀 Starting Orchestration[/bold]")
        console.print(f"[dim]Objective:[/dim] {objective}")
        console.print(f"[dim]Project:[/dim] {working_dir}")
        console.print(f"[dim]Type:[/dim] {task_type}\n")

        # Initialize components
        # Use from_config() to enable automatic token refresh
        api_client = APIClient.from_config()

        enricher = PromptEnricher()

        executor = ClaudeCodeExecutor(
            claude_code_path=config.get("claude_code_path"),
        )

        session_manager = SessionManager()

        # Step 1: Start orchestration session
        console.print("[bold]📡 Contacting server...[/bold]")

        session_response = api_client.orchestrate(
            user_id=config["user_id"],
            project_id=config.get("project_id", "default"),
            working_dir=str(working_dir),
            objective=objective,
            task_type=task_type,
        )

        session_id = session_response["session_id"]
        base_prompt = session_response["base_prompt"]

        console.print(f"[green]✓[/green] Session created: [dim]{session_id}[/dim]\n")

        if verbose:
            console.print("[dim]─── Server Response ───[/dim]")
            console.print(f"[dim]  Status: {session_response.get('status', 'N/A')}[/dim]")
            console.print(f"[dim]  Base prompt: {len(base_prompt)} chars[/dim]")
            if session_response.get("metadata"):
                console.print(f"[dim]  Metadata: {json.dumps(session_response['metadata'], indent=2)}[/dim]")
            console.print("[dim]───────────────────────[/dim]\n")

        # Save checkpoint for resume capability
        session_manager.save_checkpoint(
            session_id=session_id,
            objective=objective,
            task_type=task_type,
            project_dir=str(working_dir),
            iteration=1,
            status="active",
        )

        # Orchestration loop
        iteration = 1
        max_iterations = 20  # Safety limit

        while iteration <= max_iterations:
            iteration_start = time.time()
            console.print(f"[bold]🔄 Iteration {iteration}[/bold]")

            # Step 2: Enrich prompt with local context
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                task = progress.add_task("Enriching prompt with local context...", total=None)
                enriched_prompt = enricher.enrich_prompt(base_prompt, str(working_dir))
                progress.update(task, completed=True)

            console.print(f"[green]✓[/green] Prompt enriched (~{len(enriched_prompt)} chars)\n")

            if verbose:
                console.print(f"[dim]  Base prompt: {len(base_prompt)} chars[/dim]")
                console.print(f"[dim]  Enriched prompt: {len(enriched_prompt)} chars[/dim]")
                console.print(f"[dim]  Context added: +{len(enriched_prompt) - len(base_prompt)} chars[/dim]")

            # Step 3: Execute LLM
            console.print("[bold]🤖 Executing with Claude Code...[/bold]")

            result = executor.execute(
                prompt=enriched_prompt,
                working_dir=working_dir,
            )

            if not result.success:
                console.print(f"[red]❌ LLM execution failed (exit code {result.exit_code})[/red]")
                console.print(f"[dim]{result.stderr}[/dim]")

                # Submit failure to server
                api_client.llm_result(
                    session_id=session_id,
                    result=result.stdout or result.stderr,
                    status="failure",
                )
                raise typer.Exit(1)

            console.print(f"[green]✓[/green] LLM execution complete\n")

            # Step 4: Submit result to server
            console.print("[bold]📤 Submitting result...[/bold]")

            server_response = api_client.llm_result(
                session_id=session_id,
                result=result.stdout,
                status="success",
            )

            action = server_response["action"]
            iteration_time = time.time() - iteration_start

            if verbose:
                console.print("[dim]─── Server Response ───[/dim]")
                console.print(f"[dim]  Action: {action}[/dim]")
                console.print(f"[dim]  Iteration: {server_response.get('iteration', 'N/A')}[/dim]")
                if server_response.get("feedback"):
                    console.print(f"[dim]  Feedback: {server_response['feedback']}[/dim]")
                if action == "continue" and server_response.get("base_prompt"):
                    console.print(f"[dim]  Next prompt: {len(server_response['base_prompt'])} chars[/dim]")
                console.print(f"[dim]  Iteration time: {iteration_time:.1f}s[/dim]")
                console.print("[dim]───────────────────────[/dim]")

            # Handle server response
            if action == "complete":
                console.print("\n[bold green]✨ Task completed successfully![/bold green]")
                console.print(f"[dim]{server_response.get('message', '')}[/dim]")
                if verbose:
                    console.print(f"[dim]Total iterations: {iteration}[/dim]")
                # Clear checkpoint on successful completion
                session_manager.clear_checkpoint()
                raise typer.Exit(0)

            elif action == "continue":
                # Server wants another iteration
                base_prompt = server_response["base_prompt"]
                console.print(f"[yellow]→[/yellow] Continuing to iteration {iteration + 1}...\n")
                iteration += 1
                # Update checkpoint with new iteration
                session_manager.update_iteration(iteration)

            elif action == "error":
                console.print(f"\n[red]❌ Server error:[/red] {server_response.get('message', 'Unknown error')}")
                raise typer.Exit(1)

            else:
                console.print(f"\n[red]❌ Unknown server action:[/red] {action}")
                raise typer.Exit(1)

        # Max iterations reached
        console.print(f"\n[yellow]⚠️  Maximum iterations ({max_iterations}) reached[/yellow]")
        console.print("[dim]Task may be incomplete. Check session status.[/dim]")
        raise typer.Exit(1)

    except ConfigurationError as e:
        console.print(f"\n[red]❌ Configuration Error:[/red] {e}")
        if hasattr(e, 'recovery') and e.recovery:
            console.print(f"[cyan]💡 Recovery:[/cyan] {e.recovery}")
        raise typer.Exit(1)

    except TermsNotAcceptedError as e:
        # Server rejected request because terms not accepted
        # This can happen if local cache is out of sync or terms version changed
        console.print(f"\n[red]❌ Terms Not Accepted:[/red] {e}")
        console.print(f"[bold]{e.action}[/bold]")
        if e.required_version:
            console.print(f"[dim]Required version: {e.required_version}[/dim]")
        console.print(f"[dim]Terms: {e.terms_url}[/dim]")
        # Clear local cache since it's out of sync
        from obra_client.config import clear_terms_acceptance
        clear_terms_acceptance()
        raise typer.Exit(1)

    except APIError as e:
        console.print(f"\n[red]❌ API Error:[/red] {e}")
        if e.status_code:
            console.print(f"[dim]Status code: {e.status_code}[/dim]")
        if hasattr(e, 'recovery') and e.recovery:
            console.print(f"[cyan]💡 Recovery:[/cyan] {e.recovery}")
        raise typer.Exit(1)

    except ExecutionError as e:
        console.print(f"\n[red]❌ Execution Error:[/red] {e}")
        if hasattr(e, 'recovery') and e.recovery:
            console.print(f"[cyan]💡 Recovery:[/cyan] {e.recovery}")
        raise typer.Exit(1)

    except KeyboardInterrupt:
        console.print("\n\n[yellow]⚠️  Interrupted by user[/yellow]")
        console.print(f"[dim]Session {session_id} is still active on server[/dim]")
        console.print(f"[dim]Resume with: obra-client resume {session_id}[/dim]")
        raise typer.Exit(130)

    except typer.Exit:
        # Re-raise typer.Exit without treating it as an error
        # (typer.Exit inherits from RuntimeError, so it's caught by Exception)
        raise

    except Exception as e:
        console.print(f"\n[red]❌ Unexpected Error:[/red] {e}")
        raise typer.Exit(1)


@app.command()
def status(session_id: str) -> None:
    """Query orchestration session status.

    Args:
        session_id: Session ID from /orchestrate call

    Example:
        obra-client status abc123-def456-ghi789
    """
    # HARD STOP GATE: Require terms acceptance
    require_terms_accepted()

    try:
        config = require_config()

        # Use from_config() to enable automatic token refresh
        api_client = APIClient.from_config()

        console.print(f"\n[bold]📊 Session Status[/bold]")
        console.print(f"[dim]Session ID:[/dim] {session_id}\n")

        response = api_client.get_status(session_id)

        console.print(f"[bold]Status:[/bold] {response['status']}")
        console.print(f"[bold]Iteration:[/bold] {response['current_iteration']}")
        console.print(f"[bold]Objective:[/bold] {response['objective']}")
        console.print(f"[bold]Type:[/bold] {response['task_type']}")

        raise typer.Exit(0)

    except ConfigurationError as e:
        console.print(f"\n[red]❌ Configuration Error:[/red] {e}")
        raise typer.Exit(1)

    except APIError as e:
        console.print(f"\n[red]❌ API Error:[/red] {e}")
        raise typer.Exit(1)


@app.command()
def resume(session_id: Optional[str] = None) -> None:
    """Resume interrupted orchestration session.

    Args:
        session_id: Session ID to resume (optional, will use last checkpoint if not provided)

    Example:
        obra-client resume                    # Resume last session
        obra-client resume abc123-def456      # Resume specific session
    """
    # HARD STOP GATE: Require terms acceptance
    require_terms_accepted()

    try:
        config = require_config()
        session_manager = SessionManager()

        # Load checkpoint
        checkpoint = session_manager.load_checkpoint()

        if not checkpoint:
            console.print("[yellow]⚠️  No saved session found[/yellow]")
            console.print("[dim]Run 'obra-client orchestrate' to start a new session[/dim]")
            raise typer.Exit(1)

        # Use provided session_id or checkpoint's session_id
        target_session_id = session_id or checkpoint.session_id

        # Initialize API client
        # Use from_config() to enable automatic token refresh
        api_client = APIClient.from_config()

        # Check if session can be resumed
        console.print(f"\n[bold]🔄 Resuming Session[/bold]")
        console.print(f"[dim]Session ID:[/dim] {target_session_id}")
        console.print(f"[dim]Objective:[/dim] {checkpoint.objective}")
        console.print(f"[dim]Last Iteration:[/dim] {checkpoint.iteration}\n")

        # Verify session is still active
        try:
            status_response = api_client.get_status(target_session_id)

            if status_response["status"] != "active":
                console.print(
                    f"[yellow]⚠️  Session is {status_response['status']}, cannot resume[/yellow]"
                )
                session_manager.clear_checkpoint()
                raise typer.Exit(1)

        except APIError as e:
            console.print(f"[red]❌ Session not found on server:[/red] {e}")
            session_manager.clear_checkpoint()
            raise typer.Exit(1)

        # Ask user to confirm resume
        confirm = typer.confirm("Resume this session?", default=True)
        if not confirm:
            console.print("[dim]Resume cancelled[/dim]")
            raise typer.Exit(0)

        console.print("[green]✓[/green] Resuming session...\n")

        # Get continuation prompt from server
        console.print("[bold]📡 Fetching continuation prompt...[/bold]")
        resume_response = api_client.resume(target_session_id)

        base_prompt = resume_response["base_prompt"]
        iteration = resume_response.get("iteration", checkpoint.iteration)

        console.print(f"[green]✓[/green] Got continuation prompt (iteration {iteration})\n")

        # Initialize executor and enricher
        enricher = PromptEnricher()
        executor = ClaudeCodeExecutor(
            claude_code_path=config.get("claude_code_path"),
        )

        # Get working directory from checkpoint
        working_dir = Path(checkpoint.project_dir).resolve()

        # Orchestration loop (same as orchestrate command)
        max_iterations = 20  # Safety limit

        while iteration <= max_iterations:
            iteration_start = time.time()
            console.print(f"[bold]🔄 Iteration {iteration}[/bold]")

            # Enrich prompt with local context
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                task = progress.add_task("Enriching prompt with local context...", total=None)
                enriched_prompt = enricher.enrich_prompt(base_prompt, str(working_dir))
                progress.update(task, completed=True)

            console.print(f"[green]✓[/green] Prompt enriched (~{len(enriched_prompt)} chars)\n")

            # Execute LLM
            console.print("[bold]🤖 Executing with Claude Code...[/bold]")

            result = executor.execute(
                prompt=enriched_prompt,
                working_dir=working_dir,
            )

            if not result.success:
                console.print(f"[red]❌ LLM execution failed (exit code {result.exit_code})[/red]")
                console.print(f"[dim]{result.stderr}[/dim]")

                # Submit failure to server
                api_client.llm_result(
                    session_id=target_session_id,
                    result=result.stdout or result.stderr,
                    status="failure",
                )
                raise typer.Exit(1)

            console.print(f"[green]✓[/green] LLM execution complete\n")

            # Submit result to server
            console.print("[bold]📤 Submitting result...[/bold]")

            server_response = api_client.llm_result(
                session_id=target_session_id,
                result=result.stdout,
                status="success",
            )

            action = server_response["action"]
            iteration_time = time.time() - iteration_start

            console.print(f"[dim]  Iteration time: {iteration_time:.1f}s[/dim]")

            # Handle server response
            if action == "complete":
                console.print("\n[bold green]✨ Task completed successfully![/bold green]")
                console.print(f"[dim]{server_response.get('message', '')}[/dim]")
                # Clear checkpoint on successful completion
                session_manager.clear_checkpoint()
                raise typer.Exit(0)

            elif action == "continue":
                # Server wants another iteration
                base_prompt = server_response["base_prompt"]
                console.print(f"[yellow]→[/yellow] Continuing to iteration {iteration + 1}...\n")
                iteration += 1
                # Update checkpoint with new iteration
                session_manager.update_iteration(iteration)

            elif action == "error":
                console.print(f"\n[red]❌ Server error:[/red] {server_response.get('message', 'Unknown error')}")
                raise typer.Exit(1)

            else:
                console.print(f"\n[red]❌ Unknown server action:[/red] {action}")
                raise typer.Exit(1)

        # Max iterations reached
        console.print(f"\n[yellow]⚠️  Maximum iterations ({max_iterations}) reached[/yellow]")
        console.print("[dim]Task may be incomplete. Check session status.[/dim]")
        raise typer.Exit(1)

    except ConfigurationError as e:
        console.print(f"\n[red]❌ Configuration Error:[/red] {e}")
        if hasattr(e, 'recovery') and e.recovery:
            console.print(f"[cyan]💡 Recovery:[/cyan] {e.recovery}")
        raise typer.Exit(1)

    except TermsNotAcceptedError as e:
        # Server rejected request because terms not accepted
        console.print(f"\n[red]❌ Terms Not Accepted:[/red] {e}")
        console.print(f"[bold]{e.action}[/bold]")
        if e.required_version:
            console.print(f"[dim]Required version: {e.required_version}[/dim]")
        console.print(f"[dim]Terms: {e.terms_url}[/dim]")
        from obra_client.config import clear_terms_acceptance
        clear_terms_acceptance()
        raise typer.Exit(1)

    except APIError as e:
        console.print(f"\n[red]❌ API Error:[/red] {e}")
        if e.status_code:
            console.print(f"[dim]Status code: {e.status_code}[/dim]")
        if hasattr(e, 'recovery') and e.recovery:
            console.print(f"[cyan]💡 Recovery:[/cyan] {e.recovery}")
        raise typer.Exit(1)

    except ExecutionError as e:
        console.print(f"\n[red]❌ Execution Error:[/red] {e}")
        if hasattr(e, 'recovery') and e.recovery:
            console.print(f"[cyan]💡 Recovery:[/cyan] {e.recovery}")
        raise typer.Exit(1)

    except KeyboardInterrupt:
        console.print("\n\n[yellow]⚠️  Interrupted by user[/yellow]")
        console.print(f"[dim]Session {target_session_id} is still active on server[/dim]")
        console.print(f"[dim]Resume with: obra-client resume {target_session_id}[/dim]")
        raise typer.Exit(130)

    except typer.Exit:
        # Re-raise typer.Exit without treating it as an error
        raise

    except Exception as e:
        console.print(f"\n[red]❌ Unexpected Error:[/red] {e}")
        raise typer.Exit(1)


@app.command()
def version() -> None:
    """Display Obra Client version and check server compatibility."""
    # HARD STOP GATE: Require terms acceptance
    require_terms_accepted()

    console.print(f"[bold]Obra Client[/bold] v{__version__}\n")

    try:
        config = require_config()

        # Use from_config() to enable automatic token refresh
        api_client = APIClient.from_config()

        console.print("[bold]Checking server compatibility...[/bold]")
        server_version = api_client.get_version()

        console.print(f"[green]✓[/green] Server API Version: {server_version['api_version']}")
        console.print(f"[dim]Min Client Version:[/dim] {server_version['min_client_version']}")
        console.print(f"[dim]Features:[/dim] {', '.join(server_version['features'])}")

    except ConfigurationError as e:
        error_msg = str(e)
        if "not found" in error_msg.lower() and "config" in error_msg.lower():
            console.print("[yellow]⚠️  No configuration found[/yellow]")
            console.print("[dim]Run 'obra setup' to configure.[/dim]")
        elif "Not authenticated" in error_msg or "expired" in error_msg.lower():
            console.print(f"[red]❌ Authentication failed[/red]")
            console.print("[dim]Run 'obra login' to sign in again.[/dim]")
            console.print(f"\n[dim]Details: {error_msg}[/dim]")
        else:
            console.print(f"[yellow]⚠️  Configuration error:[/yellow] {error_msg}")
            console.print("[dim]Run 'obra setup' to reconfigure.[/dim]")

    except TermsNotAcceptedError as e:
        console.print(f"[red]❌ Terms not accepted[/red]")
        console.print("[dim]Delete config and run 'obra-client setup' to accept terms.[/dim]")

    except APIError as e:
        console.print(f"[red]❌ Server unreachable:[/red] {e}")

    raise typer.Exit(0)


@app.command(name="health-check")
def health_check() -> None:
    """Verify Obra installation and configuration.

    Checks:
        - Python version (>= 3.12)
        - Configuration file validity
        - API/Database connectivity
        - Claude Code CLI availability

    Example:
        obra-client health-check
    """
    # HARD STOP GATE: Require terms acceptance
    require_terms_accepted()

    import shutil
    import subprocess

    console.print("\n[bold]🏥 Obra Health Check[/bold]")
    console.print("=" * 50)

    all_passed = True

    # Check 1: Python Version
    console.print("\n[bold]1. Python Version[/bold]")
    python_version = sys.version_info
    version_str = f"{python_version.major}.{python_version.minor}.{python_version.micro}"

    if python_version >= (3, 12):
        console.print(f"   [green]✓[/green] Python {version_str}")
    else:
        console.print(f"   [red]✗[/red] Python {version_str} (requires 3.12+)")
        console.print(f"   [dim]→ Upgrade Python: https://www.python.org/downloads/[/dim]")
        all_passed = False

    # Check 2: Configuration
    console.print("\n[bold]2. Configuration[/bold]")
    try:
        config = load_config()

        # Validate required fields (Firebase auth uses firebase_uid instead of license_key)
        required_fields = ["firebase_uid", "auth_token"]
        missing_fields = [f for f in required_fields if not config.get(f)]

        if missing_fields:
            console.print(f"   [red]✗[/red] Not authenticated")
            console.print(f"   [dim]→ Run: obra login[/dim]")
            all_passed = False
        else:
            console.print("   [green]✓[/green] Authentication valid")

    except ConfigurationError as e:
        console.print(f"   [red]✗[/red] Config error: {e}")
        console.print(f"   [dim]→ Run: obra-client setup[/dim]")
        all_passed = False

    # Check 3: API/Database Connectivity
    console.print("\n[bold]3. API/Database Connectivity[/bold]")
    try:
        config = load_config()

        # Create API client without auth for health check
        api_client = APIClient(
            base_url=config["api_base_url"],
            auth_token=None,
        )

        # Check health endpoint
        health = api_client.health_check()

        if health.get("status") == "healthy":
            console.print(f"   [green]✓[/green] API reachable (Firestore: {health.get('firestore', 'unknown')})")
        else:
            console.print(f"   [yellow]⚠[/yellow] API status: {health.get('status', 'unknown')}")
            all_passed = False

    except ConfigurationError:
        console.print("   [yellow]⚠[/yellow] Skipped (no config)")
        all_passed = False

    except APIError as e:
        console.print(f"   [red]✗[/red] API unreachable: {e}")
        console.print(f"   [dim]→ Check network connection and API URL[/dim]")
        all_passed = False

    except Exception as e:
        console.print(f"   [red]✗[/red] Connection error: {e}")
        console.print(f"   [dim]→ Verify API base URL in config[/dim]")
        all_passed = False

    # Check 4: Claude Code CLI
    console.print("\n[bold]4. Claude Code CLI[/bold]")
    try:
        config = load_config()
        claude_code_path = config.get("claude_code_path") or "claude-code"

        # Check if Claude Code is in PATH or at specified location
        if shutil.which(claude_code_path):
            # Try to get version
            try:
                result = subprocess.run(
                    [claude_code_path, "--version"],
                    capture_output=True,
                    text=True,
                    timeout=5,
                    check=False,
                )

                if result.returncode == 0:
                    version_output = result.stdout.strip() or result.stderr.strip()
                    console.print(f"   [green]✓[/green] Claude Code found ({version_output})")
                else:
                    console.print(f"   [green]✓[/green] Claude Code found at: {shutil.which(claude_code_path)}")

            except subprocess.TimeoutExpired:
                console.print(f"   [yellow]⚠[/yellow] Claude Code found but --version timed out")

        else:
            console.print(f"   [yellow]⚠[/yellow] Claude Code not found in PATH")
            console.print(f"   [dim]→ Install: https://docs.anthropic.com/claude-code[/dim]")
            console.print(f"   [dim]→ Or specify path in config: claude_code_path[/dim]")
            all_passed = False

    except ConfigurationError:
        console.print("   [yellow]⚠[/yellow] Skipped (no config)")
        all_passed = False

    # Summary
    console.print("\n" + "=" * 50)

    if all_passed:
        console.print("[bold green]✨ All checks passed![/bold green]")
        console.print("\n[dim]Your Obra installation is ready to use.[/dim]")
        console.print("[dim]Next: obra-client orchestrate \"your task\"[/dim]")
        raise typer.Exit(0)
    else:
        console.print("[bold yellow]⚠  Some checks failed[/bold yellow]")
        console.print("\n[dim]Fix the issues above, then run health-check again.[/dim]")
        raise typer.Exit(1)


# =============================================================================
# Firebase Auth Commands (EPIC-AUTH-MIGRATION-001)
# =============================================================================


@app.command()
def login() -> None:
    """Sign in with Firebase Auth (Google or GitHub OAuth).

    Opens your browser to complete OAuth sign-in. After authentication,
    verifies your email is on the beta allowlist.

    Example:
        obra login
    """
    from obra_client.auth import (
        login_with_browser,
        save_auth,
        verify_beta_access,
    )

    console.print(f"\n[bold]OBRA LOGIN[/bold] [dim]v{__version__}[/dim]")
    console.print("=" * 50)

    # Check if already authenticated
    if is_authenticated():
        email = get_user_email()
        console.print(f"\n[yellow]Already signed in as:[/yellow] {email}")
        console.print("[dim]Run 'obra logout' first to sign in with a different account.[/dim]")

        reauth = typer.confirm("Sign in again?", default=False)
        if not reauth:
            raise typer.Exit(0)

    console.print("\n[bold]Opening browser for authentication...[/bold]")
    console.print("[dim]Complete sign-in in the browser window.[/dim]")
    console.print("[dim]Waiting for authentication (timeout: 5 minutes)...[/dim]\n")

    try:
        # Perform browser OAuth
        auth_result = login_with_browser(timeout=300)

        console.print(f"[green]✓[/green] Signed in as: {auth_result.email}")
        console.print(f"[dim]  Provider: {auth_result.auth_provider}[/dim]")

        # Verify beta access
        console.print("\n[bold]Verifying beta access...[/bold]")

        config = load_config()
        api_base_url = config.get("api_base_url", DEFAULT_API_BASE_URL)

        try:
            access_info = verify_beta_access(auth_result.id_token, api_base_url)
            console.print(f"[green]✓[/green] Beta access verified")
        except AuthenticationError as e:
            console.print(f"\n[red]✗ Access denied:[/red] {e}")
            console.print("\n[dim]Your authentication succeeded, but you don't have beta access.[/dim]")
            console.print("[dim]Contact the Obra team to request access.[/dim]")
            raise typer.Exit(1)

        # Save authentication
        save_auth(auth_result)
        console.print(f"[green]✓[/green] Authentication saved")

        console.print("\n[bold green]Login successful![/bold green]")
        console.print()
        console.print("[bold]Next steps:[/bold]")
        console.print("  obra whoami              # View your account info")
        console.print("  obra interactive         # Start interactive mode")
        console.print("  obra orchestrate \"task\"  # Run a task")

    except AuthenticationError as e:
        console.print(f"\n[red]✗ Authentication failed:[/red] {e}")
        raise typer.Exit(1)

    except TimeoutError as e:
        console.print(f"\n[red]✗ Timeout:[/red] {e}")
        console.print("[dim]The browser sign-in was not completed in time.[/dim]")
        raise typer.Exit(1)

    except Exception as e:
        console.print(f"\n[red]✗ Unexpected error:[/red] {e}")
        raise typer.Exit(1)


@app.command()
def logout() -> None:
    """Sign out and clear stored credentials.

    Removes stored Firebase authentication tokens from the config file.

    Example:
        obra logout
    """
    from obra_client.auth import clear_auth

    if not is_authenticated():
        console.print("\n[dim]Not currently signed in.[/dim]")
        raise typer.Exit(0)

    email = get_user_email()

    confirm = typer.confirm(f"Sign out from {email}?", default=True)
    if not confirm:
        console.print("[dim]Cancelled.[/dim]")
        raise typer.Exit(0)

    clear_auth()
    console.print(f"\n[green]✓[/green] Signed out from {email}")
    console.print("[dim]Run 'obra login' to sign in again.[/dim]")


@app.command()
def whoami() -> None:
    """Show current authentication status.

    Displays your current sign-in status, email, and auth provider.

    Example:
        obra whoami
    """
    console.print(f"\n[bold]OBRA ACCOUNT[/bold] [dim]v{__version__}[/dim]")
    console.print("=" * 50)

    if not is_authenticated():
        console.print("\n[yellow]Not signed in.[/yellow]")
        console.print("[dim]Run 'obra login' to sign in.[/dim]")
        raise typer.Exit(0)

    # Get auth info
    firebase_uid = get_firebase_uid()
    email = get_user_email()
    provider = get_auth_provider()

    # Get config for additional info
    config = load_config()
    auth_timestamp = config.get("auth_timestamp", "Unknown")
    display_name = config.get("display_name")

    console.print()
    console.print(f"[bold]Email:[/bold]    {email}")
    if display_name:
        console.print(f"[bold]Name:[/bold]     {display_name}")
    console.print(f"[bold]Provider:[/bold] {provider}")
    console.print(f"[bold]User ID:[/bold]  [dim]{firebase_uid}[/dim]")
    console.print(f"[bold]Signed in:[/bold] [dim]{auth_timestamp[:19] if len(auth_timestamp) > 19 else auth_timestamp}[/dim]")

    # Check terms acceptance
    if is_terms_accepted():
        console.print(f"[bold]Terms:[/bold]    [green]Accepted (v{TERMS_VERSION})[/green]")
    else:
        console.print(f"[bold]Terms:[/bold]    [yellow]Not accepted[/yellow]")

    console.print()
    console.print("[dim]Commands:[/dim]")
    console.print("  obra logout     # Sign out")
    console.print("  obra login      # Sign in with different account")


def _run_orchestration(
    objective: str,
    working_dir: Path,
    task_type: str,
    config: dict,
    verbose: bool = False,
) -> tuple[bool, Optional[str], Optional[str]]:
    """Run orchestration and return result (for REPL use).

    Returns:
        Tuple of (success, session_id, error_message)
    """
    try:
        # Initialize components
        api_client = APIClient.from_config()
        enricher = PromptEnricher()
        executor = ClaudeCodeExecutor(claude_code_path=config.get("claude_code_path"))
        session_manager = SessionManager()

        # Start orchestration session
        console.print("[bold]📡 Contacting server...[/bold]")

        session_response = api_client.orchestrate(
            user_id=config["user_id"],
            project_id=config.get("project_id", "default"),
            working_dir=str(working_dir),
            objective=objective,
            task_type=task_type,
        )

        session_id = session_response["session_id"]
        base_prompt = session_response["base_prompt"]

        console.print(f"[green]✓[/green] Session created: [dim]{session_id}[/dim]\n")

        # Save checkpoint
        session_manager.save_checkpoint(
            session_id=session_id,
            objective=objective,
            task_type=task_type,
            project_dir=str(working_dir),
            iteration=1,
            status="active",
        )

        # Orchestration loop
        iteration = 1
        max_iterations = 20

        while iteration <= max_iterations:
            console.print(f"[bold]🔄 Iteration {iteration}[/bold]")

            # Enrich prompt
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                task = progress.add_task("Enriching prompt...", total=None)
                enriched_prompt = enricher.enrich_prompt(base_prompt, str(working_dir))
                progress.update(task, completed=True)

            console.print(f"[green]✓[/green] Prompt enriched (~{len(enriched_prompt)} chars)\n")

            # Execute LLM
            console.print("[bold]🤖 Executing with Claude Code...[/bold]")
            result = executor.execute(prompt=enriched_prompt, working_dir=working_dir)

            if not result.success:
                console.print(f"[red]❌ LLM execution failed[/red]")
                api_client.llm_result(
                    session_id=session_id,
                    result=result.stdout or result.stderr,
                    status="failure",
                )
                return False, session_id, "LLM execution failed"

            console.print(f"[green]✓[/green] LLM execution complete\n")

            # Submit result
            console.print("[bold]📤 Submitting result...[/bold]")
            server_response = api_client.llm_result(
                session_id=session_id,
                result=result.stdout,
                status="success",
            )

            action = server_response["action"]

            if action == "complete":
                console.print("\n[bold green]✨ Task completed successfully![/bold green]")
                session_manager.clear_checkpoint()
                return True, session_id, None

            elif action == "continue":
                base_prompt = server_response["base_prompt"]
                console.print(f"[yellow]→[/yellow] Continuing to iteration {iteration + 1}...\n")
                iteration += 1
                session_manager.update_iteration(iteration)

            elif action == "error":
                msg = server_response.get("message", "Unknown error")
                console.print(f"\n[red]❌ Server error:[/red] {msg}")
                return False, session_id, msg

            else:
                console.print(f"\n[red]❌ Unknown action:[/red] {action}")
                return False, session_id, f"Unknown action: {action}"

        console.print(f"\n[yellow]⚠️  Max iterations ({max_iterations}) reached[/yellow]")
        return False, session_id, "Max iterations reached"

    except ConfigurationError as e:
        console.print(f"\n[red]❌ Configuration Error:[/red] {e}")
        return False, None, str(e)

    except TermsNotAcceptedError as e:
        console.print(f"\n[red]❌ Terms Not Accepted:[/red] {e}")
        from obra_client.config import clear_terms_acceptance
        clear_terms_acceptance()
        return False, None, str(e)

    except APIError as e:
        console.print(f"\n[red]❌ API Error:[/red] {e}")
        return False, None, str(e)

    except ExecutionError as e:
        console.print(f"\n[red]❌ Execution Error:[/red] {e}")
        return False, None, str(e)

    except KeyboardInterrupt:
        console.print("\n[yellow]⚠️  Interrupted[/yellow]")
        return False, None, "Interrupted by user"


def _repl_help() -> None:
    """Show REPL help with SaaS-specific information."""
    console.print("\n[bold]━━━ OBRA INTERACTIVE REPL ━━━[/bold]")
    console.print()

    # Commands section
    console.print("[bold]Available Commands:[/bold]")
    console.print("  [cyan]/help[/cyan]           Show this help message")
    console.print("  [cyan]/status[/cyan]         Show current/last session status")
    console.print("  [cyan]/session[/cyan]        Show session info and recovery options")
    console.print("  [cyan]/history[/cyan]        Show command history")
    console.print("  [cyan]/project[/cyan] [path] Show or change working directory")
    console.print("  [cyan]/llm[/cyan] [model]    Show or switch LLM (sonnet/opus/haiku)")
    console.print("  [cyan]/clear[/cyan]          Clear screen")
    console.print("  [cyan]/exit[/cyan]           Exit interactive mode")
    console.print()

    # Orchestration section
    console.print("[bold]Orchestration:[/bold]")
    console.print("  Type any text without / prefix to orchestrate a task.")
    console.print("  Example: [dim]Add user authentication[/dim]")
    console.print()

    # SaaS Session Model explanation
    console.print("[bold]SaaS Session Model:[/bold]")
    console.print("  Sessions are managed by Cloud Functions, not locally.")
    console.print()
    console.print("  [dim]• Sessions auto-expire after 1 hour of inactivity[/dim]")
    console.print("  [dim]• Server decides when iterations are complete[/dim]")
    console.print("  [dim]• Your code never leaves your machine (Two-Tier Prompting)[/dim]")
    console.print("  [dim]• Checkpoints are automatic - no manual saving needed[/dim]")
    console.print()

    # Key differences from CLI
    console.print("[bold]Differences from Standalone CLI:[/bold]")
    console.print("  [yellow]Not available here:[/yellow]")
    console.print("    [dim]• /pause[/dim] - Sessions auto-suspend instead")
    console.print("    [dim]• /budget[/dim] - Budget is server-managed")
    console.print("    [dim]• /checkpoint[/dim] - Checkpoints are automatic")
    console.print()
    console.print("  [green]Use command line instead:[/green]")
    console.print("    [dim]• obra-client resume[/dim] - Resume interrupted session")
    console.print("    [dim]• obra-client status <id>[/dim] - Check specific session")
    console.print()

    # Quick tips
    console.print("[bold]Quick Tips:[/bold]")
    console.print("  • /llm opus → Switch to Claude Opus for complex tasks")
    console.print("  • /llm haiku → Switch to Claude Haiku for simple tasks")
    console.print("  • /project ~/other → Change working directory")
    console.print()


# =============================================================================
# Config Commands
# =============================================================================

config_app = typer.Typer(help="Configuration management commands")
app.add_typer(config_app, name="config")


@config_app.command(name="llm")
def config_llm(
    role: Optional[str] = typer.Argument(None, help="Role to configure: orch[estrator] or imp[lementation]"),
    model: Optional[str] = typer.Option(None, "--model", "-m", help="Model to use (default, sonnet, opus, haiku)"),
) -> None:
    """Show or set LLM configuration.

    Without arguments, shows current LLM configuration for both roles.
    With role argument, interactively configure that role.

    Examples:
        obra-client config llm              # Show current config
        obra-client config llm orch         # Configure orchestrator
        obra-client config llm imp          # Configure implementation
        obra-client config llm orch -m opus # Quick set orchestrator model
    """
    # HARD STOP GATE: Require terms acceptance
    require_terms_accepted()

    if role is None:
        # Show current configuration
        console.print("\n[bold]LLM Configuration[/bold]")
        console.print("-" * 50)

        console.print()
        console.print("[bold]Orchestrator:[/bold]")
        console.print(f"  {get_llm_display('orchestrator')}")

        console.print()
        console.print("[bold]Implementation:[/bold]")
        console.print(f"  {get_llm_display('implementation')}")

        console.print()
        console.print("[bold]Available Providers:[/bold]")
        for key, info in LLM_PROVIDERS.items():
            console.print(f"  • {info['name']}: {info['description']}")
            console.print(f"    [dim]Models: {', '.join(info['models'])}[/dim]")

        console.print()
        console.print("[dim]Usage:[/dim]")
        console.print("  obra-client config llm orch    # Configure orchestrator")
        console.print("  obra-client config llm imp     # Configure implementation")
        console.print("  obra-client config llm orch -m opus  # Quick set model")
        return

    # Normalize role name
    role_normalized = role.lower()
    if role_normalized.startswith("orch"):
        role_key = "orchestrator"
    elif role_normalized.startswith("imp"):
        role_key = "implementation"
    else:
        console.print(f"[red]❌ Unknown role: {role}[/red]")
        console.print("[dim]Valid: orch[estrator], imp[lementation][/dim]")
        raise typer.Exit(1)

    # Quick model set if -m provided
    if model:
        llm_config = get_llm_config()
        role_config = llm_config.get(role_key, {})
        provider = role_config.get("provider", DEFAULT_PROVIDER)
        auth_method = role_config.get("auth_method", DEFAULT_AUTH_METHOD)

        provider_info = LLM_PROVIDERS.get(provider, {})
        if model not in provider_info.get("models", []):
            console.print(f"[red]❌ Invalid model: {model}[/red]")
            console.print(f"[dim]Valid for {provider}: {', '.join(provider_info['models'])}[/dim]")
            raise typer.Exit(1)

        try:
            set_llm_config(role_key, provider, auth_method, model)
            console.print(f"[green]✓[/green] {role_key.capitalize()}: {get_llm_display(role_key)}")
        except ValueError as e:
            console.print(f"[red]❌ {e}[/red]")
            raise typer.Exit(1)
        return

    # Interactive configuration
    console.print(f"\n[bold]Configure {role_key.capitalize()} LLM[/bold]")
    console.print("-" * 40)

    # Provider
    console.print("\n[bold]Provider:[/bold]")
    provider_keys = list(LLM_PROVIDERS.keys())
    for i, key in enumerate(provider_keys, 1):
        info = LLM_PROVIDERS[key]
        console.print(f"  {i}. {info['name']} - {info['description']}")

    provider_choice = typer.prompt("Select", default="1")
    try:
        provider_idx = int(provider_choice) - 1
        selected_provider = provider_keys[max(0, min(provider_idx, len(provider_keys)-1))]
    except ValueError:
        selected_provider = DEFAULT_PROVIDER

    # Auth method
    console.print("\n[bold]Auth Method:[/bold]")
    console.print("  1. OAuth (Flat Rate) [green](recommended)[/green]")
    console.print("  2. API Key (Token Billing) [yellow]⚠️ untested[/yellow]")

    auth_choice = typer.prompt("Select", default="1")
    selected_auth = "oauth" if auth_choice == "1" else "api_key"

    # Model
    provider_info = LLM_PROVIDERS[selected_provider]
    console.print("\n[bold]Model:[/bold]")
    if selected_auth == "oauth":
        console.print("  [green]'default' strongly recommended for OAuth[/green]")

    for i, m in enumerate(provider_info["models"], 1):
        rec = " [green](recommended)[/green]" if m == "default" and selected_auth == "oauth" else ""
        console.print(f"  {i}. {m}{rec}")

    model_choice = typer.prompt("Select", default="1")
    try:
        model_idx = int(model_choice) - 1
        selected_model = provider_info["models"][max(0, min(model_idx, len(provider_info["models"])-1))]
    except ValueError:
        selected_model = DEFAULT_MODEL

    try:
        set_llm_config(role_key, selected_provider, selected_auth, selected_model)
        console.print(f"\n[green]✓[/green] {role_key.capitalize()}: {get_llm_display(role_key)}")
    except ValueError as e:
        console.print(f"[red]❌ {e}[/red]")
        raise typer.Exit(1)


@config_app.command(name="show")
def config_show() -> None:
    """Show local client configuration settings."""
    # HARD STOP GATE: Require terms acceptance
    require_terms_accepted()

    config = load_config()

    console.print("\n[bold]Obra Client Configuration (Local)[/bold]")
    console.print("-" * 50)

    # Authentication settings
    console.print("\n[bold]Authentication:[/bold]")
    email = config.get('user_email', 'Not signed in')
    firebase_uid = config.get('firebase_uid')
    auth_provider = config.get('auth_provider', 'Unknown')
    if firebase_uid:
        console.print(f"  Email:     {email}")
        console.print(f"  Provider:  {auth_provider}")
        console.print(f"  User ID:   [dim]{firebase_uid[:20]}...[/dim]")
    else:
        console.print(f"  Status:    [yellow]Not signed in[/yellow]")
        console.print(f"  [dim]→ Run: obra login[/dim]")
    console.print(f"  API URL:   [dim]{config.get('api_base_url', DEFAULT_API_BASE_URL)}[/dim]")

    # LLM settings
    console.print()
    console.print("[bold]LLM:[/bold]")
    console.print(f"  Orchestrator:    {get_llm_display('orchestrator')}")
    console.print(f"  Implementation:  {get_llm_display('implementation')}")

    # Terms
    terms = config.get("terms_accepted", {})
    console.print()
    console.print("[bold]Terms:[/bold]")
    console.print(f"  Version:  {terms.get('version', 'Not accepted')}")
    console.print(f"  Accepted: {terms.get('accepted_at', 'Never')[:19] if terms.get('accepted_at') else 'Never'}")

    console.print()
    console.print(f"[dim]Config file: {CONFIG_PATH}[/dim]")
    console.print()
    console.print("[dim]For SaaS feature config: obra-client config saas[/dim]")


# =============================================================================
# SaaS Configuration Commands (FEAT-SAAS-CONFIG-001)
# =============================================================================


@config_app.command(name="saas")
def config_saas_show() -> None:
    """Show SaaS configuration (preset, overrides, feature flags).

    Displays your server-side configuration including:
    - Current preset (e.g., beta-tester-default, standard)
    - Your custom overrides
    - Key feature states (enabled/disabled)

    Example:
        obra-client config saas
    """
    # HARD STOP GATE: Require terms acceptance
    require_terms_accepted()

    try:
        api_client = APIClient.from_config()
        console.print("\n[bold]📡 Fetching SaaS configuration...[/bold]")

        config_data = api_client.get_user_config()

        console.print("\n[bold]SaaS Configuration[/bold]")
        console.print("=" * 50)

        # Preset
        console.print(f"\n[bold]Preset:[/bold] {config_data.get('preset', 'unknown')}")

        # Overrides
        overrides = config_data.get('overrides', {})
        if overrides:
            console.print("\n[bold]Your Overrides:[/bold]")
            for path, value in overrides.items():
                console.print(f"  {path} = {value}")
        else:
            console.print("\n[bold]Overrides:[/bold] [dim]None (using preset defaults)[/dim]")

        # Key features from resolved config
        resolved = config_data.get('resolved', {})
        features = resolved.get('features', {})

        console.print("\n[bold]Key Features:[/bold]")

        # Quality Automation
        qa = features.get('quality_automation', {})
        qa_enabled = qa.get('enabled', False)
        console.print(f"  Quality Automation: {'[green]enabled[/green]' if qa_enabled else '[dim]disabled[/dim]'}")
        if qa_enabled:
            agents = qa.get('agents', {})
            console.print(f"    • RCA Agent: {'✓' if agents.get('rca_agent') else '✗'}")
            console.print(f"    • Code Review: {'✓' if agents.get('code_review') else '✗'}")
            console.print(f"    • Security Audit: {'✓' if agents.get('security_audit') else '✗'}")

        # Performance Control / Budgets
        pc = features.get('performance_control', {})
        budgets = pc.get('budgets', {})
        budgets_enabled = budgets.get('enabled', False)
        console.print(f"  Budget Controls: {'[green]enabled[/green]' if budgets_enabled else '[dim]disabled[/dim]'}")

        # Advanced Planning
        ap = features.get('advanced_planning', {})
        ap_enabled = ap.get('enabled', False)
        console.print(f"  Advanced Planning: {'[green]enabled[/green]' if ap_enabled else '[dim]disabled[/dim]'}")

        # Documentation Governance
        dg = features.get('documentation_governance', {})
        dg_enabled = dg.get('enabled', False)
        console.print(f"  Doc Governance: {'[green]enabled[/green]' if dg_enabled else '[dim]disabled[/dim]'}")

        console.print("\n[bold]Commands:[/bold]")
        console.print("  obra-client config set <path> <value>  # Change a setting")
        console.print("  obra-client config preset list         # List available presets")
        console.print("  obra-client config preset use <name>   # Switch presets")
        console.print("  obra-client config reset               # Reset to default")

    except ConfigurationError as e:
        console.print(f"\n[red]❌ Configuration Error:[/red] {e}")
        raise typer.Exit(1)

    except APIError as e:
        console.print(f"\n[red]❌ API Error:[/red] {e}")
        raise typer.Exit(1)


@config_app.command(name="set")
def config_saas_set(
    path: str = typer.Argument(..., help="Dot-notation path (e.g., features.performance_control.budgets.enabled)"),
    value: str = typer.Argument(..., help="Value to set (true/false for booleans, or string/number)"),
) -> None:
    """Set a SaaS configuration override.

    Use dot-notation to specify the path to the setting.
    Changes are persisted on the server and apply immediately.

    Examples:
        obra-client config set features.performance_control.budgets.enabled true
        obra-client config set features.quality_automation.agents.security_audit true
        obra-client config set features.quality_automation.agents.rca_agent false
    """
    # HARD STOP GATE: Require terms acceptance
    require_terms_accepted()

    try:
        api_client = APIClient.from_config()

        # Parse value (handle booleans, numbers, strings)
        parsed_value: any
        value_lower = value.lower()
        if value_lower == 'true':
            parsed_value = True
        elif value_lower == 'false':
            parsed_value = False
        elif value.isdigit():
            parsed_value = int(value)
        elif value.replace('.', '', 1).isdigit():
            parsed_value = float(value)
        else:
            parsed_value = value

        console.print(f"\n[bold]Setting:[/bold] {path} = {parsed_value}")

        result = api_client.update_user_config(overrides={path: parsed_value})

        console.print(f"[green]✓[/green] Configuration updated")
        console.print(f"[dim]Preset: {result.get('preset')}[/dim]")

        # Show the override was applied
        overrides = result.get('overrides', {})
        if path in overrides:
            console.print(f"[dim]Override active: {path} = {overrides[path]}[/dim]")

    except ConfigurationError as e:
        console.print(f"\n[red]❌ Configuration Error:[/red] {e}")
        raise typer.Exit(1)

    except APIError as e:
        console.print(f"\n[red]❌ API Error:[/red] {e}")
        if "invalid_preset" in str(e):
            console.print("[dim]Use 'obra-client config preset list' to see available presets[/dim]")
        raise typer.Exit(1)


@config_app.command(name="reset")
def config_saas_reset(
    overrides_only: bool = typer.Option(False, "--overrides-only", "-o", help="Only clear overrides, keep preset"),
) -> None:
    """Reset SaaS configuration to defaults.

    By default, resets both preset and overrides to beta-tester-default.
    Use --overrides-only to keep current preset but clear custom overrides.

    Examples:
        obra-client config reset              # Full reset to default preset
        obra-client config reset --overrides-only  # Clear overrides only
    """
    # HARD STOP GATE: Require terms acceptance
    require_terms_accepted()

    try:
        api_client = APIClient.from_config()

        if overrides_only:
            console.print("\n[bold]Clearing all overrides...[/bold]")
            result = api_client.update_user_config(clear_overrides=True)
            console.print(f"[green]✓[/green] Overrides cleared")
            console.print(f"[dim]Preset remains: {result.get('preset')}[/dim]")
        else:
            console.print("\n[bold]Resetting to default configuration...[/bold]")
            result = api_client.update_user_config(preset="beta-tester-default", clear_overrides=True)
            console.print(f"[green]✓[/green] Configuration reset to beta-tester-default")

    except ConfigurationError as e:
        console.print(f"\n[red]❌ Configuration Error:[/red] {e}")
        raise typer.Exit(1)

    except APIError as e:
        console.print(f"\n[red]❌ API Error:[/red] {e}")
        raise typer.Exit(1)


# Preset management sub-app
preset_app = typer.Typer(help="Preset management commands")
config_app.add_typer(preset_app, name="preset")


@preset_app.command(name="list")
def config_preset_list() -> None:
    """List available configuration presets.

    Shows all presets you can switch to, with descriptions.

    Example:
        obra-client config preset list
    """
    # HARD STOP GATE: Require terms acceptance
    require_terms_accepted()

    try:
        api_client = APIClient.from_config()
        console.print("\n[bold]📡 Fetching available presets...[/bold]")

        result = api_client.list_presets()
        presets = result.get('presets', [])

        console.print("\n[bold]Available Presets[/bold]")
        console.print("=" * 60)

        for preset in presets:
            name = preset.get('name', 'unknown')
            desc = preset.get('description', '')
            recommended = preset.get('recommended', False)
            rec_for = preset.get('recommended_for', '')

            # Format name with recommendation marker
            name_display = f"[bold]{name}[/bold]"
            if recommended:
                name_display += " [green]★ recommended[/green]"
            elif rec_for:
                name_display += f" [cyan]({rec_for})[/cyan]"

            console.print(f"\n{name_display}")
            if desc:
                console.print(f"  [dim]{desc}[/dim]")

            personas = preset.get('target_personas', [])
            if personas:
                console.print(f"  [dim]For: {', '.join(personas)}[/dim]")

        console.print("\n[bold]Usage:[/bold]")
        console.print("  obra-client config preset use <name>   # Switch to a preset")
        console.print("  obra-client config preset show <name>  # View preset details")

    except ConfigurationError as e:
        console.print(f"\n[red]❌ Configuration Error:[/red] {e}")
        raise typer.Exit(1)

    except APIError as e:
        console.print(f"\n[red]❌ API Error:[/red] {e}")
        raise typer.Exit(1)


@preset_app.command(name="use")
def config_preset_use(
    name: str = typer.Argument(..., help="Preset name to switch to"),
    keep_overrides: bool = typer.Option(False, "--keep-overrides", "-k", help="Keep current overrides"),
) -> None:
    """Switch to a different configuration preset.

    When switching presets, overrides are cleared by default to give you
    a clean slate. Use --keep-overrides to preserve your custom settings.

    Examples:
        obra-client config preset use standard
        obra-client config preset use minimal --keep-overrides
    """
    # HARD STOP GATE: Require terms acceptance
    require_terms_accepted()

    try:
        api_client = APIClient.from_config()

        console.print(f"\n[bold]Switching to preset: {name}[/bold]")

        result = api_client.update_user_config(
            preset=name,
            clear_overrides=not keep_overrides
        )

        console.print(f"[green]✓[/green] Switched to preset: {result.get('preset')}")

        if keep_overrides:
            overrides = result.get('overrides', {})
            if overrides:
                console.print(f"[dim]Kept {len(overrides)} override(s)[/dim]")
        else:
            console.print("[dim]Overrides cleared[/dim]")

        console.print("\n[dim]Run 'obra-client config saas' to see new configuration[/dim]")

    except ConfigurationError as e:
        console.print(f"\n[red]❌ Configuration Error:[/red] {e}")
        raise typer.Exit(1)

    except APIError as e:
        console.print(f"\n[red]❌ API Error:[/red] {e}")
        if "invalid_preset" in str(e).lower():
            console.print("[dim]Use 'obra-client config preset list' to see available presets[/dim]")
        raise typer.Exit(1)


@preset_app.command(name="show")
def config_preset_show(
    name: str = typer.Argument(..., help="Preset name to view"),
) -> None:
    """Show details of a specific preset.

    Displays the full feature configuration for a preset
    without applying it.

    Example:
        obra-client config preset show minimal
    """
    # HARD STOP GATE: Require terms acceptance
    require_terms_accepted()

    try:
        api_client = APIClient.from_config()
        console.print(f"\n[bold]📡 Fetching preset: {name}[/bold]")

        # Get list of presets to find the one we want
        result = api_client.list_presets()
        presets = result.get('presets', [])

        preset = next((p for p in presets if p.get('name') == name), None)
        if not preset:
            console.print(f"[red]❌ Preset not found: {name}[/red]")
            console.print("[dim]Use 'obra-client config preset list' to see available presets[/dim]")
            raise typer.Exit(1)

        console.print(f"\n[bold]Preset: {name}[/bold]")
        console.print("=" * 50)

        desc = preset.get('description', '')
        if desc:
            console.print(f"\n[dim]{desc}[/dim]")

        personas = preset.get('target_personas', [])
        if personas:
            console.print(f"\n[bold]Target Users:[/bold] {', '.join(personas)}")

        rec_for = preset.get('recommended_for', '')
        if rec_for:
            console.print(f"[bold]Recommended For:[/bold] {rec_for}")

        setup_time = preset.get('setup_time_target', '')
        if setup_time:
            console.print(f"[bold]Setup Time:[/bold] {setup_time}")

        console.print("\n[dim]To switch to this preset:[/dim]")
        console.print(f"  obra-client config preset use {name}")

    except ConfigurationError as e:
        console.print(f"\n[red]❌ Configuration Error:[/red] {e}")
        raise typer.Exit(1)

    except APIError as e:
        console.print(f"\n[red]❌ API Error:[/red] {e}")
        raise typer.Exit(1)


@app.command()
def interactive() -> None:
    """Start interactive orchestration mode.

    Interactive mode provides a REPL-like interface for orchestration,
    allowing you to iteratively work through development tasks with
    real-time feedback.

    Commands:
        /help      Show available commands
        /status    Show last session status
        /session   Show session info and recovery options
        /history   Show command history
        /project   Show or change working directory
        /llm       Show or switch LLM (sonnet/opus/haiku)
        /clear     Clear screen
        /exit      Exit interactive mode

    Example:
        obra-client interactive
    """
    # HARD STOP GATE: Require terms acceptance
    require_terms_accepted()

    try:
        config = require_config()
    except ConfigurationError as e:
        console.print(f"\n[red]❌ Configuration Error:[/red] {e}")
        raise typer.Exit(1)

    # State
    working_dir = Path.cwd().resolve()
    history: list[str] = []
    last_session_id: Optional[str] = None
    last_objective: Optional[str] = None
    last_success: Optional[bool] = None

    # Welcome banner
    console.print()
    console.print(f"[bold]OBRA INTERACTIVE MODE[/bold] [dim]v{__version__}[/dim]")
    console.print("═" * 70)
    console.print(f"[dim]Project:[/dim] {working_dir}")
    console.print("[dim]Type objectives to orchestrate, or /help for commands.[/dim]")
    console.print()

    # Main REPL loop
    while True:
        try:
            # Get input
            user_input = Prompt.ask("[bold cyan]obra[/bold cyan]")
            user_input = user_input.strip()

            # Skip empty input
            if not user_input:
                continue

            # Add to history
            history.append(user_input)

            # Handle commands
            if user_input.startswith("/"):
                cmd_parts = user_input[1:].split(maxsplit=1)
                cmd = cmd_parts[0].lower()
                cmd_arg = cmd_parts[1] if len(cmd_parts) > 1 else None

                if cmd in ("exit", "quit", "q"):
                    console.print("\n[dim]Goodbye![/dim]")
                    break

                elif cmd == "help":
                    _repl_help()

                elif cmd == "clear":
                    console.clear()
                    console.print(f"[bold]OBRA INTERACTIVE MODE[/bold] [dim]v{__version__}[/dim]")
                    console.print("═" * 70)

                elif cmd == "status":
                    if last_session_id:
                        status_str = "[green]completed[/green]" if last_success else "[red]failed[/red]"
                        console.print(f"\n[bold]Last Session:[/bold]")
                        console.print(f"  Session ID: [dim]{last_session_id}[/dim]")
                        console.print(f"  Objective: {last_objective}")
                        console.print(f"  Status: {status_str}")
                        console.print()
                    else:
                        console.print("\n[dim]No session yet. Run an orchestration first.[/dim]\n")

                elif cmd == "session":
                    # Show session info and recovery options (S3.T2c)
                    console.print()
                    console.print("[bold]━━━ SESSION INFO ━━━[/bold]")
                    console.print()
                    if last_session_id:
                        status_str = "[green]completed[/green]" if last_success else "[red]failed[/red]"
                        console.print("[bold]Current Session:[/bold]")
                        console.print(f"  ID: [cyan]{last_session_id}[/cyan]")
                        console.print(f"  Objective: {last_objective}")
                        console.print(f"  Status: {status_str}")
                        console.print()
                        console.print("[bold]Recovery Options:[/bold]")
                        if not last_success:
                            console.print(f"  [green]Resume:[/green] obra-client resume --session-id {last_session_id}")
                            console.print("  [dim]↳ Continue from last checkpoint[/dim]")
                        console.print(f"  [yellow]Query:[/yellow]  obra-client status --session-id {last_session_id}")
                        console.print("  [dim]↳ Get detailed status from server[/dim]")
                    else:
                        console.print("[dim]No active session.[/dim]")
                        console.print()
                        console.print("[bold]To start:[/bold]")
                        console.print("  Type any objective text (without / prefix)")
                        console.print("  Example: [dim]Add user authentication[/dim]")
                    console.print()
                    console.print("[bold]SaaS Session Notes:[/bold]")
                    console.print("  • Sessions auto-expire after 1 hour of inactivity")
                    console.print("  • Server manages checkpoints automatically")
                    console.print("  • Your code never leaves your machine")
                    console.print()

                elif cmd == "history":
                    if history:
                        console.print("\n[bold]Command History:[/bold]")
                        for i, h in enumerate(history[-10:], 1):
                            console.print(f"  {i}. {h}")
                        console.print()
                    else:
                        console.print("\n[dim]No history yet.[/dim]\n")

                elif cmd == "project":
                    if cmd_arg:
                        new_path = Path(cmd_arg).expanduser().resolve()
                        if new_path.exists() and new_path.is_dir():
                            working_dir = new_path
                            console.print(f"[green]✓[/green] Project directory: {working_dir}")
                        else:
                            console.print(f"[red]❌ Directory not found:[/red] {cmd_arg}")
                    else:
                        console.print(f"[bold]Project:[/bold] {working_dir}")

                elif cmd == "llm":
                    # Handle /llm command for quick model switching
                    if not cmd_arg:
                        # Show current config
                        console.print()
                        console.print("[bold]LLM Configuration:[/bold]")
                        console.print(f"  Orchestrator:    {get_llm_display('orchestrator')}")
                        console.print(f"  Implementation:  {get_llm_display('implementation')}")
                        console.print()
                        console.print("[dim]Quick switch (applies to both):[/dim]")
                        console.print("  /llm sonnet   → Switch to Sonnet")
                        console.print("  /llm opus     → Switch to Opus")
                        console.print("  /llm haiku    → Switch to Haiku")
                        console.print("  /llm default  → Use provider defaults")
                        console.print()
                        console.print("[dim]Full config: obra-client config llm[/dim]")
                        console.print()
                    else:
                        # Quick switch shortcuts for common models
                        arg_lower = cmd_arg.lower().strip()

                        # Valid model shortcuts
                        valid_models = ["default", "sonnet", "opus", "haiku"]
                        if arg_lower not in valid_models:
                            console.print(f"[red]❌ Unknown model: {cmd_arg}[/red]")
                            console.print(f"[dim]Valid: {', '.join(valid_models)}[/dim]")
                            continue

                        try:
                            # Update both roles with the new model
                            for role in ["orchestrator", "implementation"]:
                                llm_config = get_llm_config()
                                role_config = llm_config.get(role, {})
                                provider = role_config.get("provider", DEFAULT_PROVIDER)
                                auth_method = role_config.get("auth_method", DEFAULT_AUTH_METHOD)
                                set_llm_config(role, provider, auth_method, arg_lower)

                            console.print(f"[green]✓[/green] Model set to: {arg_lower}")
                            console.print(f"    Orchestrator:    {get_llm_display('orchestrator')}")
                            console.print(f"    Implementation:  {get_llm_display('implementation')}")
                        except ValueError as e:
                            console.print(f"[red]❌ {e}[/red]")

                else:
                    console.print(f"[red]Unknown command:[/red] /{cmd}")
                    console.print("[dim]Type /help for available commands.[/dim]")

            else:
                # Treat as orchestration objective
                console.print()
                success, session_id, error = _run_orchestration(
                    objective=user_input,
                    working_dir=working_dir,
                    task_type="feature",
                    config=config,
                )
                last_session_id = session_id
                last_objective = user_input
                last_success = success
                console.print()

        except KeyboardInterrupt:
            console.print("\n[dim]Use /exit to quit.[/dim]")
            continue

        except EOFError:
            # Ctrl+D
            console.print("\n[dim]Goodbye![/dim]")
            break

    raise typer.Exit(0)


# Create docs sub-app for documentation commands
docs_app = typer.Typer(
    name="docs",
    help="View bundled documentation and guides.",
)
app.add_typer(docs_app, name="docs")


@docs_app.command(name="onboarding")
def docs_onboarding() -> None:
    """Display agent onboarding documentation.

    Shows the getting-started guide for using obra-client,
    including setup instructions and key commands.

    Example:
        obra-client docs onboarding
    """
    # HARD STOP GATE: Require terms acceptance
    require_terms_accepted()

    from obra_client.docs import get_onboarding

    console.print(get_onboarding())


@docs_app.command(name="examples")
def docs_examples() -> None:
    """Display usage examples and common workflows.

    Shows copy-paste examples for common Obra operations
    and best practices.

    Example:
        obra-client docs examples
    """
    # HARD STOP GATE: Require terms acceptance
    require_terms_accepted()

    from obra_client.docs import get_usage_examples

    console.print(get_usage_examples())


@docs_app.command(name="terms")
def docs_terms() -> None:
    """Display full Beta Software Agreement.

    Shows the complete terms and conditions for using Obra.

    Example:
        obra-client docs terms
    """
    # Note: terms display does NOT require acceptance gate
    # Users should be able to read terms before deciding

    from obra_client.legal import get_full_terms

    console.print(get_full_terms())


if __name__ == "__main__":
    app()
