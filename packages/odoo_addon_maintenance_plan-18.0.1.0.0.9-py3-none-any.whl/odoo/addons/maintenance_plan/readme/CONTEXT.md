Despite Odoo's built-in recurrence functionality included in the maintenance
requests themselves (since 17.0), this module could be needed for some reasons:
- Odoo implementation is javascript only
- Some companies already work with the existing "Maintenance Plan" workflow
- Some modules are depending on this one

For reference, this module was initially set deprecated when migrated to 17.0:
https://github.com/OCA/maintenance/pull/414#issuecomment-2668929617
