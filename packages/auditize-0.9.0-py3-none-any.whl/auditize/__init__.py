# Shortcut for ASGI server, the entrypoint is: auditize:asgi
from .app import app_factory as asgi

__all__ = ("asgi",)
