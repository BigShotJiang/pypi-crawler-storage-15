Runtime Errors
--------------

.. currentmodule:: pyhmmer.errors

.. autoexception:: UnexpectedError(RuntimeError)
   :special-members: __init__
   :members:

.. autoexception:: EaselError(RuntimeError)
   :special-members: __init__
   :members:

.. autoexception:: ServerError(RuntimeError)
   :special-members: __init__
   :members:
