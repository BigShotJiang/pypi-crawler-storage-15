Iterative Searches
==================

.. autoclass:: pyhmmer.plan7.IterativeSearch
    :special-members: __init__
    :members:

.. autoclass:: pyhmmer.plan7.IterationResult
    :special-members: __init__
    :members: