Results
=======

.. autoclass:: pyhmmer.plan7.TopHits
   :special-members: __init__
   :members:

.. autoclass:: pyhmmer.plan7.Hit
   :special-members: __init__
   :members:

.. autoclass:: pyhmmer.plan7.Domains
   :special-members: __init__
   :members:

.. autoclass:: pyhmmer.plan7.Domain
   :special-members: __init__
   :members:

.. autoclass:: pyhmmer.plan7.Alignment
   :special-members: __init__
   :members: