Parsers
=======

.. autoclass:: pyhmmer.plan7.HMMFile
   :special-members: __init__
   :members:

.. autoclass:: pyhmmer.plan7.HMMPressedFile
   :special-members: __init__
   :members: