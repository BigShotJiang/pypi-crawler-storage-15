Profile Searches
================

.. autofunction:: pyhmmer.hmmer.hmmsearch(queries, sequences, cpus=0, callback=None, backend="threading", parallel=None, **options)

.. autofunction:: pyhmmer.hmmer.hmmscan(queries, profiles, cpus=0, callback=None, background=None, backend="threading", **options)
