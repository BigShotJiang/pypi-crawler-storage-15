Sequence Searches
=================

.. autofunction:: pyhmmer.hmmer.phmmer(queries, sequences, cpus=0, callback=None, builder=None, backend="threading", **options)

.. autofunction:: pyhmmer.hmmer.nhmmer(queries, sequences, cpus=0, callback=None, builder=None, backend="threading", **options)
