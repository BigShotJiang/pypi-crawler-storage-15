Sequence
========

.. autoclass:: pyhmmer.easel.Sequence
   :members:

.. autoclass:: pyhmmer.easel.TextSequence
   :special-members: __init__
   :members:
   :inherited-members:
   :exclude-members: sample

   .. automethod:: pyhmmer.easel.TextSequence.sample

.. autoclass:: pyhmmer.easel.DigitalSequence
   :special-members: __init__
   :members:
   :inherited-members:
   :exclude-members: sample

   .. automethod:: pyhmmer.easel.DigitalSequence.sample