Blocks
======

.. autoclass:: pyhmmer.easel.SequenceBlock
   :members:

.. autoclass:: pyhmmer.easel.TextSequenceBlock(SequenceBlock)
   :members:
   :special-members: __init__
   :inherited-members:

.. autoclass:: pyhmmer.easel.DigitalSequenceBlock(SequenceBlock)
   :members:
   :special-members: __init__
   :inherited-members: