Data Structures
===============

.. autoclass:: pyhmmer.easel.Bitfield
   :special-members: __init__
   :members:

.. autoclass:: pyhmmer.easel.KeyHash
   :special-members: __init__
   :members: