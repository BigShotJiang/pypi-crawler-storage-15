Client
======

.. autoclass:: pyhmmer.daemon.Client
   :special-members: __init__
   :members:

.. autoclass:: pyhmmer.daemon.IterativeSearch
   :special-members: __init__
   :members: