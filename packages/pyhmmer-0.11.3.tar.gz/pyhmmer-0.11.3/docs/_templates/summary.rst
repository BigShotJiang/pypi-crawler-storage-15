{{ name }}
{{ underline }}

.. currentmodule:: {{ module }}

.. autoclass:: {{ name }}
   :inherited-members:
   :members:
