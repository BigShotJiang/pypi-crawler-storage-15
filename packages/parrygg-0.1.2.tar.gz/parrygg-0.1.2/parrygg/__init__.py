"""parrygg - Python gRPC client for parry.gg API"""

__version__ = "0.1.2"
