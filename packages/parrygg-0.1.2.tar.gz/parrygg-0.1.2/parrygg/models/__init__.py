"""Protocol buffer models for parry.gg API"""
