from setuptools import setup

setup(
    name="parrygg-dev",
    install_requires=[
        "grpcio-tools>=1.50.0",
        "protobuf>=4.21.0"
    ]
)