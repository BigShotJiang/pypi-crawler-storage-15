<img src="/tff/docs/images/tf-small.png" align="left"/>

# Text-Fabric-Factory

[![Project Status: Active – The project has reached a stable, usable state and is being actively developed.](https://www.repostatus.org/badges/latest/active.svg)](https://www.repostatus.org/#active)

All about Text-Fabric-Factory is in the
[docs](https://annotation.github.io/text-fabric-factory/tff).

This package depends on
[text-fabric](https://github.com/annotation/text-fabric).

Create/convert/adapt/enrich text-fabric datasets.
