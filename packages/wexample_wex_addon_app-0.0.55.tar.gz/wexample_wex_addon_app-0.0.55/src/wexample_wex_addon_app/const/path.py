from __future__ import annotations

from pathlib import Path

# filestate: python-constant-sort
APP_PATH_EXAMPLES: Path = Path("examples")
APP_PATH_LICENSE: Path = Path("LICENSE")
APP_PATH_README: Path = Path("README.md")
APP_PATH_TEST: Path = Path("tests")
