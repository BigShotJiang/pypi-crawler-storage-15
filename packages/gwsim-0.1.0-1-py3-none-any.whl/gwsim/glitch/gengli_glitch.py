"""
Simulators for Gengli glitches in gravitational wave data.
"""
from __future__ import annotations

import gengli
import numpy as np
from gwpy.timeseries import TimeSeries
from gwsim.glitches.base import GlitchSimulator


class GengliGlitchSimulator(GlitchSimulator):
    """Simulate Gengli glitches in gravitational wave data.

    Gengli glitches are characterized by a specific time-frequency morphology
    often observed in gravitational wave detectors. This simulator generates
    synthetic Gengli glitches based on predefined parameters.

    Parameters
    ----------
    amplitude : float
        The peak amplitude of the glitch.
    frequency : float
        The central frequency of the glitch in Hz.
    duration : float
        The duration of the glitch in seconds.
    phase : float
        The initial phase of the glitch in radians.
    """

    def __init__(
        self,
        detector_label: str,
        sampling_frequency: float,
        duration: float,
        start_time: float = 0,
        max_samples: int | None = None,
        seed: int | None = None,
        detectors: list[str] | None = None,
        power_spectral_density_files: list[str] | None = None,
        population_files: list[str] | None = None,
        **kwargs,
    ):
        """Initialize the Gengli glitch simulator.
        
        Args:
            detector_label: A label to retrieve the detector-specific generative model for glitches.
            sampling_frequency: Sampling frequency of the glitches in Hz.
            duration: Duration of each glitch segment in seconds.
            start_time: Start time of the first glitch segment in GPS seconds. Default is 0
            max_samples: Maximum number of samples to generate. None means infinite.
            seed: Seed for the random number generator. If None, the RNG is not initialized.
            detectors: List of detector names. Default is None.
            **kwargs: Additional arguments absorbed by subclasses and mixins.
        """
        super().__init__(
            sampling_frequency=sampling_frequency,
            duration=duration,
            start_time=start_time,
            max_samples=max_samples,
            seed=seed,
            detectors=detectors,
            **kwargs,
        )
        
        self._glitch_simulator = gengli.glitch_generator(detector=detector_label)
        self.power_spectral_density_files = power_spectral_density_files or []
        self.population_files = population_files or []
        
        # Check whether the length of detectors, power_spectral_density_files, and population_files match
        if detectors is not None:
            num_detectors = len(detectors)
            if len(self.power_spectral_density_files) not in [0, num_detectors]:
                raise ValueError("Length of power_spectral_density_files must be 0 or match number of detectors.")
            if len(self.population_files) not in [0, num_detectors]:
                raise ValueError("Length of population_files must be 0 or match number of detectors.")
        else:
            if len(self.power_spectral_density_files) > 1:
                raise ValueError("Multiple power_spectral_density_files provided but detectors is None.")
            if len(self.population_files) > 1:
                raise ValueError("Multiple population_files provided but detectors is None.")
            
        # Initialize the data segments
        self._data_segments = []

    def simulate(self, *arg, **kwargs) -> np.ndarray:
        """Generate the Gengli glitch signal.

        Parameters
        ----------
        time_array : numpy.ndarray
            Array of time values at which to evaluate the glitch.

        Returns
        -------
        numpy.ndarray
            The simulated Gengli glitch signal.
        """
        self._glitch_simulator.get_glitch(seed=self.rng.integers(0, 2**32 - 1), snr=snr, srate=self.sampling_frequency)
        
        return glitch_signal