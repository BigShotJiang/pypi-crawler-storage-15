"""YAML serialization utilities for numpy arrays."""

from __future__ import annotations

import base64
import yaml
from typing import Any, Union
import numpy as np


# Custom YAML representer for binary data
def binary_representer(dumper, data):
    """Represent binary data with !!binary tag."""
    return dumper.represent_scalar('!!binary', data)


class BinaryData(str):
    """String subclass to mark binary data for YAML serialization."""
    pass


# Add representer for BinaryData
yaml.add_representer(BinaryData, binary_representer)


def numpy_array_to_yaml(array: np.ndarray) -> dict[str, Any]:
    """Convert a numpy array to a YAML-serializable dictionary.

    Uses base64 encoding with !!binary tag for all arrays.

    Args:
        array: Numpy array to serialize.

    Returns:
        Dictionary containing base64-encoded array data, dtype, and shape.
    """
    # Convert to bytes and encode as base64
    bytes_data = array.tobytes()
    encoded_data = base64.b64encode(bytes_data).decode('ascii')

    return {
        "data": BinaryData(encoded_data),
        "dtype": str(array.dtype),
        "shape": list(array.shape),
        "encoding": "base64",
    }


def yaml_to_numpy_array(data: dict[str, Any]) -> np.ndarray:
    """Convert a YAML dictionary back to a numpy array.

    Expects base64-encoded data format.

    Args:
        data: Dictionary containing base64-encoded array data, dtype, and shape.

    Returns:
        Reconstructed numpy array.

    Raises:
        ValueError: If required keys are missing or data is invalid.
    """
    if "data" not in data or "dtype" not in data or "shape" not in data:
        raise ValueError("YAML data must contain 'data', 'dtype', and 'shape' keys")

    if data.get("encoding") != "base64":
        raise ValueError("Expected base64 encoding in YAML data")

    dtype = np.dtype(data["dtype"])
    shape = tuple(data["shape"])

    # Handle both BinaryData objects and regular strings
    data_str = str(data["data"])

    # Decode base64 data
    decoded_bytes = base64.b64decode(data_str)
    array = np.frombuffer(decoded_bytes, dtype=dtype).reshape(shape)

    return array


def save_numpy_arrays_to_yaml(
    arrays: dict[str, np.ndarray],
    filepath: str,
    **yaml_kwargs
) -> None:
    """Save multiple numpy arrays to a YAML file.

    Args:
        arrays: Dictionary mapping names to numpy arrays.
        filepath: Path to save the YAML file.
        **yaml_kwargs: Additional arguments passed to yaml.dump.
    """
    yaml_data = {}
    for name, array in arrays.items():
        yaml_data[name] = numpy_array_to_yaml(array)

    with open(filepath, 'w') as f:
        yaml.dump(yaml_data, f, default_flow_style=False, **yaml_kwargs)


def load_numpy_arrays_from_yaml(filepath: str) -> dict[str, np.ndarray]:
    """Load multiple numpy arrays from a YAML file.

    Args:
        filepath: Path to the YAML file.

    Returns:
        Dictionary mapping names to numpy arrays.
    """
    with open(filepath, 'r') as f:
        yaml_data = yaml.safe_load(f)

    arrays = {}
    for name, data in yaml_data.items():
        arrays[name] = yaml_to_numpy_array(data)

    return arrays


# Example usage and convenience functions
def save_array_to_yaml(array: np.ndarray, filepath: str, **yaml_kwargs) -> None:
    """Save a single numpy array to a YAML file.

    Args:
        array: Numpy array to save.
        filepath: Path to save the YAML file.
        **yaml_kwargs: Additional arguments passed to yaml.dump.
    """
    yaml_data = numpy_array_to_yaml(array)
    with open(filepath, 'w') as f:
        yaml.dump(yaml_data, f, default_flow_style=False, **yaml_kwargs)


def load_array_from_yaml(filepath: str) -> np.ndarray:
    """Load a single numpy array from a YAML file.

    Args:
        filepath: Path to the YAML file.

    Returns:
        Numpy array.
    """
    with open(filepath, 'r') as f:
        yaml_data = yaml.safe_load(f)

    return yaml_to_numpy_array(yaml_data)