"""Base Waveform Class for Gravitational Wave Simulations."""

from __future__ import annotations

import importlib
import inspect
from typing import Callable

from gwsim.data.timeseries.timeseries import TimeSeries


class WaveformModel:
    """Base Waveform class for gravitational wave simulations."""

    def __init__(self, time_domain_source_model: str | Callable, waveform_arguments: dict | None = None):
        """Initialize the Waveform with a time-domain source model.

        Specification of the time-domain source model:
        1. It should return a dictionary with keys 'plus' and 'cross' corresponding to the

        Args:
            time_domain_source_model: A string specifying the module path to the time-domain source model function,
                or a callable function that generates the waveform polarizations.
            waveform_arguments: Additional arguments to pass to the time-domain source model.
        """

        if isinstance(time_domain_source_model, str):
            self.time_domain_source_model = self._import_time_domain_source_model(time_domain_source_model)
        else:
            if not inspect.isfunction(time_domain_source_model):
                raise ValueError("time_domain_source_model must be a function or a string path to a function.")
            self.time_domain_source_model: Callable = time_domain_source_model
        self.waveform_arguments = waveform_arguments or {}

    def _import_time_domain_source_model(self, model_path: str) -> Callable:
        """Dynamically import a time-domain source model given its module path.

        Args:
            model_path: The dot-separated module path to the time-domain source model.
        Returns:
            The imported time-domain source model object.
        """
        module_path, function_name = model_path.rsplit(".", 1)
        module = importlib.import_module(module_path)
        model_function = getattr(module, function_name)
        if not inspect.isfunction(model_function):
            raise ImportError(f"{function_name} is not a function in module {module_path}.")
        return model_function

    def generate_polarizations(self, **parameters) -> dict[str, TimeSeries]:
        """Generate the plus and cross polarizations using the time-domain source model.

        Args:
            **params: Parameters to pass to the time-domain source model.
        Returns:
            A dictionary containing the plus and cross polarizations as TimeSeries objects.
        """
        polarizations: dict[str, object] = self.time_domain_source_model(**parameters, **self.waveform_arguments)
        
        
        return polarizations
