
from setuptools import setup
setup(
    name="bridge_transfer",
    version="0.0.4",
    py_modules=["carrier"],
)
