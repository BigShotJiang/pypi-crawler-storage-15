import statmake.cli

if __name__ == "__main__":
    statmake.cli.main()
