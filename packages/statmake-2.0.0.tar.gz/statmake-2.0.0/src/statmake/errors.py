class Error(Exception):
    """Base exception."""


class StylespaceError(Error):
    """Represents a consistency error in Stylespaces."""
