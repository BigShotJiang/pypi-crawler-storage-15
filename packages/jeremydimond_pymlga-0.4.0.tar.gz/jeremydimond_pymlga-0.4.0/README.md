# pymlga

Version: 0.4.0

Python machine learning by genetic algorithm

