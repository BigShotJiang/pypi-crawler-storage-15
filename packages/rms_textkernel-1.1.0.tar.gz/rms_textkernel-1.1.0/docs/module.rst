``textkernel`` Module
=====================

.. automodule:: textkernel
    :member-order: bysource
    :members:
    :undoc-members:
