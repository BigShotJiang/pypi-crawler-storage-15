Examples: Group Properties
==========================

This folder showcases how to compute advanced properties derived from the
refractive index, such as the group index and the group velocity. These metrics
are useful when analysing pulse propagation in dispersive materials.
