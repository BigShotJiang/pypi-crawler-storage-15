Examples: Utility Functions
===========================

This folder contains examples demonstrating the various utility functions provided by the `PyOptik.utils` module.
These utilities are designed to facilitate common tasks such as managing directories, downloading necessary data, and creating custom material definitions.
The examples provided here aim to help you leverage these utilities effectively in your workflows.
