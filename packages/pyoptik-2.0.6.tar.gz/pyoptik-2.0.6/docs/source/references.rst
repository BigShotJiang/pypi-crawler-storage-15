References
==========

All data comes from `refractiveindex.info <https://refractiveindex.info>`_ website.
