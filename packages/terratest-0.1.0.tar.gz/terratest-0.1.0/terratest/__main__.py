from terratest.cli.main import app

def main():
    """Entry point para la aplicación terratest."""
    app()

if __name__ == "__main__":
    main()
