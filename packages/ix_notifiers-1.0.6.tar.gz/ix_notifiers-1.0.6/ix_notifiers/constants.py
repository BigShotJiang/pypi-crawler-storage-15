#!/usr/bin/env python3
# -*- coding: utf-8 -*-
""" Constants declarations """

# These get overwritten at build time. See build.sh
VERSION = '1.0.6'
BUILD = '2192680282'
NAME = 'ix-notifiers'
