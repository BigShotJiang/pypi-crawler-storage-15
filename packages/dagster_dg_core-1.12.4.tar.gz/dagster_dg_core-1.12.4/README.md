# dagster-dg-core

Core libraries for the `dagster-dg-cli` and `create-dagster` packages.
