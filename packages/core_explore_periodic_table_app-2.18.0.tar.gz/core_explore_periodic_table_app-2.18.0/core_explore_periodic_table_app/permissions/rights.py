""" Rights for core explore periodic table app
"""

EXPLORE_PERIODIC_TABLE_CONTENT_TYPE = "core_explore_periodic_table_app"
EXPLORE_PERIODIC_TABLE_ACCESS = "access_explore_periodic_table"
