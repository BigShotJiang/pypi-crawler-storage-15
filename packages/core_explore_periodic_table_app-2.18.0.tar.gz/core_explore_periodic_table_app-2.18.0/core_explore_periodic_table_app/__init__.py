""" Run the Init app
"""

default_app_config = (
    "core_explore_periodic_table_app.apps.CoreExplorePeriodicTableAppConfig"
)
