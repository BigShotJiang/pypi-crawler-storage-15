let persistentQueryUrl = "{% url 'core_explore_periodic_table_get_persistent_query_url' %}";
let persistentRenameQueryUrl = "{% url 'core_explore_periodic_table_app_rest_persistent_query_periodic_table_detail' 'queryId' %}";
let persistentQueryRestUrl = "{% url 'core_explore_periodic_table_app_rest_persistent_query_periodic_table_detail' 'queryId' %}";