"""CLI package for async-task-q."""

from .main import main

__all__ = ["main"]
