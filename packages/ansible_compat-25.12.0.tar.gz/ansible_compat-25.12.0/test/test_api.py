"""Tests for ansible_compat package."""


def test_placeholder() -> None:
    """Placeholder test."""
