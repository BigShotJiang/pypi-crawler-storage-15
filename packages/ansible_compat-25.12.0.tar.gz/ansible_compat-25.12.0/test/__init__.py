"""Tests for ansible_compat package."""
