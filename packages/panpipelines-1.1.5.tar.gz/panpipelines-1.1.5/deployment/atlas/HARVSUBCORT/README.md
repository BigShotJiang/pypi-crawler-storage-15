## Harvard Subcortical Atlas

### Source
HarvardOxford-sub-maxprob-thr25-1mm.nii.gz from fsl v6074


### Processing

The file HarvardOxford-Subcortical.xml was editted to create HarvardOxford-Subcortical_index.txt with just the roi labels