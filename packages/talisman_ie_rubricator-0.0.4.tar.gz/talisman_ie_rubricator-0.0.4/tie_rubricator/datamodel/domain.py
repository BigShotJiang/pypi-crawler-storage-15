__all__ = [
    'RUBRIC', 'RUBRICATOR_ID', 'RUBRIC_ID', 'STR_VALUE'
]

from tie_domain.domain._synthetic._category import RUBRIC, RUBRICATOR_ID, RUBRIC_ID
from tie_domain.domain._synthetic._common import STR_VALUE
