# jupyter_notebook_config.py
c.NotebookApp.server_extensions = [
    'ai_proxy'
]