"""Configuration widget definitions for modal UI."""

from typing import Dict, Any, List
import logging

logger = logging.getLogger(__name__)


class ConfigWidgetDefinitions:
    """Defines which config values get which widgets in the modal."""

    @staticmethod
    def get_available_plugins() -> List[Dict[str, Any]]:
        """Get list of available plugins for configuration.

        Returns:
            List of plugin information dictionaries.
        """
        plugins = []

        # Define known plugins with their descriptions
        known_plugins = {
            "enhanced_input": {
                "name": "Enhanced Input",
                "description": "Bordered input boxes with Unicode characters"
            },
            "system_commands": {
                "name": "System Commands",
                "description": "Core system commands (/help, /config, /status)"
            },
            "hook_monitoring": {
                "name": "Hook Monitoring",
                "description": "Monitor and debug hook system activity"
            },
            "query_enhancer": {
                "name": "Query Enhancer",
                "description": "Enhance and optimize user queries"
            },
            "workflow_enforcement": {
                "name": "Workflow Enforcement",
                "description": "Enforce specific workflow patterns"
            },
            "fullscreen": {
                "name": "Fullscreen Effects",
                "description": "Fullscreen visual effects and animations"
            }
        }

        # Create plugin widgets
        for plugin_id, info in known_plugins.items():
            plugins.append({
                "type": "checkbox",
                "label": info["name"],
                "config_path": f"plugins.{plugin_id}.enabled",
                "help": info["description"]
            })

        return plugins

    @staticmethod
    def get_config_modal_definition() -> Dict[str, Any]:
        """Get the complete modal definition for /config command.

        Returns:
            Dictionary defining the modal layout and widgets.
        """
        # Get plugin widgets
        plugin_widgets = ConfigWidgetDefinitions.get_available_plugins()

        return {
            "title": "System Configuration",
            "footer": "↑↓/PgUp/PgDn navigate • Enter toggle • Ctrl+S save • Esc cancel",
            "width": 80,  # 80% of screen width
            "height": 20,
            "sections": [
                {
                    "title": "Terminal Settings",
                    "widgets": [
                        {
                            "type": "slider",
                            "label": "Render FPS",
                            "config_path": "terminal.render_fps",
                            "min_value": 1,
                            "max_value": 60,
                            "step": 1,
                            "help": "Terminal refresh rate (1-60 FPS)"
                        },
                        {
                            "type": "slider",
                            "label": "Status Lines",
                            "config_path": "terminal.status_lines",
                            "min_value": 1,
                            "max_value": 10,
                            "step": 1,
                            "help": "Number of status lines to display"
                        },
                        {
                            "type": "dropdown",
                            "label": "Thinking Effect",
                            "config_path": "terminal.thinking_effect",
                            "options": ["shimmer", "pulse", "wave", "none"],
                            "help": "Visual effect for thinking animations"
                        },
                        {
                            "type": "slider",
                            "label": "Shimmer Speed",
                            "config_path": "terminal.shimmer_speed",
                            "min_value": 1,
                            "max_value": 10,
                            "step": 1,
                            "help": "Speed of shimmer animation effect"
                        },
                        {
                            "type": "checkbox",
                            "label": "Enable Render Cache",
                            "config_path": "terminal.render_cache_enabled",
                            "help": "Cache renders to reduce unnecessary terminal I/O when idle"
                        }
                    ]
                },
                {
                    "title": "Input Settings",
                    "widgets": [
                        {
                            "type": "checkbox",
                            "label": "Ctrl+C Exit",
                            "config_path": "input.ctrl_c_exit",
                            "help": "Allow Ctrl+C to exit application"
                        },
                        {
                            "type": "checkbox",
                            "label": "Backspace Enabled",
                            "config_path": "input.backspace_enabled",
                            "help": "Enable backspace key for text editing"
                        },
                        {
                            "type": "slider",
                            "label": "History Limit",
                            "config_path": "input.history_limit",
                            "min_value": 10,
                            "max_value": 1000,
                            "step": 10,
                            "help": "Maximum number of history entries"
                        }
                    ]
                },
                {
                    "title": "LLM Settings",
                    "widgets": [
                        {
                            "type": "text_input",
                            "label": "API URL",
                            "config_path": "core.llm.api_url",
                            "placeholder": "http://localhost:1234",
                            "help": "LLM API endpoint URL"
                        },
                        {
                            "type": "text_input",
                            "label": "Model",
                            "config_path": "core.llm.model",
                            "placeholder": "qwen/qwen3-4b",
                            "help": "LLM model identifier"
                        },
                        {
                            "type": "slider",
                            "label": "Temperature",
                            "config_path": "core.llm.temperature",
                            "min_value": 0.0,
                            "max_value": 2.0,
                            "step": 0.1,
                            "help": "Creativity/randomness of responses (0.0-2.0)"
                        },
                        {
                            "type": "slider",
                            "label": "Max History",
                            "config_path": "core.llm.max_history",
                            "min_value": 10,
                            "max_value": 200,
                            "step": 10,
                            "help": "Maximum conversation history entries"
                        },
                        {
                            "type": "checkbox",
                            "label": "Show Session Banner",
                            "config_path": "core.llm.system_prompt.show_session_banner",
                            "help": "Display session context banner on startup"
                        }
                    ]
                },
                {
                    "title": "Application Settings",
                    "widgets": [
                        {
                            "type": "text_input",
                            "label": "Application Name",
                            "config_path": "application.name",
                            "placeholder": "Kollabor CLI",
                            "help": "Display name for the application"
                        },
                        {
                            "type": "text_input",
                            "label": "Version",
                            "config_path": "application.version",
                            "placeholder": "1.0.0",
                            "help": "Current application version"
                        }
                    ]
                },
                {
                    "title": "Plugin Settings",
                    "widgets": plugin_widgets
                },
                {
                    "title": "Enhanced Input Plugin",
                    "widgets": [
                        {
                            "type": "dropdown",
                            "label": "Box Style",
                            "config_path": "plugins.enhanced_input.style",
                            "options": ["rounded", "square", "double", "thick", "thin"],
                            "help": "Visual style of the input box border"
                        },
                        {
                            "type": "text_input",
                            "label": "Width",
                            "config_path": "plugins.enhanced_input.width",
                            "placeholder": "auto",
                            "help": "Box width (auto, pixels, or percentage)"
                        },
                        {
                            "type": "text_input",
                            "label": "Placeholder Text",
                            "config_path": "plugins.enhanced_input.placeholder",
                            "placeholder": "Type your message here...",
                            "help": "Text shown when input is empty"
                        },
                        {
                            "type": "checkbox",
                            "label": "Show Placeholder",
                            "config_path": "plugins.enhanced_input.show_placeholder",
                            "help": "Display placeholder text when input is empty"
                        },
                        {
                            "type": "slider",
                            "label": "Min Width",
                            "config_path": "plugins.enhanced_input.min_width",
                            "min_value": 20,
                            "max_value": 200,
                            "step": 10,
                            "help": "Minimum box width in characters"
                        },
                        {
                            "type": "slider",
                            "label": "Max Width",
                            "config_path": "plugins.enhanced_input.max_width",
                            "min_value": 40,
                            "max_value": 300,
                            "step": 10,
                            "help": "Maximum box width in characters"
                        },
                        {
                            "type": "checkbox",
                            "label": "Randomize Style",
                            "config_path": "plugins.enhanced_input.randomize_style",
                            "help": "Randomly change box style periodically"
                        },
                        {
                            "type": "slider",
                            "label": "Randomize Interval",
                            "config_path": "plugins.enhanced_input.randomize_interval",
                            "min_value": 1.0,
                            "max_value": 60.0,
                            "step": 1.0,
                            "help": "Seconds between style randomizations"
                        },
                        {
                            "type": "checkbox",
                            "label": "Dynamic Sizing",
                            "config_path": "plugins.enhanced_input.dynamic_sizing",
                            "help": "Automatically resize box based on content"
                        },
                        {
                            "type": "slider",
                            "label": "Min Height",
                            "config_path": "plugins.enhanced_input.min_height",
                            "min_value": 1,
                            "max_value": 20,
                            "step": 1,
                            "help": "Minimum box height in lines"
                        },
                        {
                            "type": "slider",
                            "label": "Max Height",
                            "config_path": "plugins.enhanced_input.max_height",
                            "min_value": 3,
                            "max_value": 50,
                            "step": 1,
                            "help": "Maximum box height in lines"
                        },
                        {
                            "type": "checkbox",
                            "label": "Wrap Text",
                            "config_path": "plugins.enhanced_input.wrap_text",
                            "help": "Enable text wrapping in input box"
                        },
                        {
                            "type": "slider",
                            "label": "Cursor Blink Rate",
                            "config_path": "plugins.enhanced_input.cursor_blink_rate",
                            "min_value": 0.1,
                            "max_value": 2.0,
                            "step": 0.1,
                            "help": "Cursor blink speed in seconds"
                        },
                        {
                            "type": "checkbox",
                            "label": "Show Status",
                            "config_path": "plugins.enhanced_input.show_status",
                            "help": "Display status information below input box"
                        }
                    ]
                },
                {
                    "title": "Hook Monitoring Plugin",
                    "widgets": [
                        {
                            "type": "checkbox",
                            "label": "Debug Logging",
                            "config_path": "plugins.hook_monitoring.debug_logging",
                            "help": "Enable detailed debug logging for hooks"
                        },
                        {
                            "type": "checkbox",
                            "label": "Show Status",
                            "config_path": "plugins.hook_monitoring.show_status",
                            "help": "Display hook monitoring status"
                        },
                        {
                            "type": "slider",
                            "label": "Hook Timeout",
                            "config_path": "plugins.hook_monitoring.hook_timeout",
                            "min_value": 1,
                            "max_value": 30,
                            "step": 1,
                            "help": "Timeout for hook execution in seconds"
                        },
                        {
                            "type": "checkbox",
                            "label": "Log All Events",
                            "config_path": "plugins.hook_monitoring.log_all_events",
                            "help": "Log every hook event"
                        },
                        {
                            "type": "checkbox",
                            "label": "Log Event Data",
                            "config_path": "plugins.hook_monitoring.log_event_data",
                            "help": "Include event data in logs"
                        },
                        {
                            "type": "checkbox",
                            "label": "Log Performance",
                            "config_path": "plugins.hook_monitoring.log_performance",
                            "help": "Log performance metrics for hooks"
                        },
                        {
                            "type": "checkbox",
                            "label": "Log Failures Only",
                            "config_path": "plugins.hook_monitoring.log_failures_only",
                            "help": "Only log failed hook executions"
                        },
                        {
                            "type": "slider",
                            "label": "Performance Threshold",
                            "config_path": "plugins.hook_monitoring.performance_threshold_ms",
                            "min_value": 10,
                            "max_value": 1000,
                            "step": 10,
                            "help": "Performance warning threshold in milliseconds"
                        },
                        {
                            "type": "slider",
                            "label": "Max Error Log Size",
                            "config_path": "plugins.hook_monitoring.max_error_log_size",
                            "min_value": 10,
                            "max_value": 500,
                            "step": 10,
                            "help": "Maximum error log entries to keep"
                        },
                        {
                            "type": "checkbox",
                            "label": "Enable Plugin Discovery",
                            "config_path": "plugins.hook_monitoring.enable_plugin_discovery",
                            "help": "Automatically discover new plugins"
                        },
                        {
                            "type": "slider",
                            "label": "Discovery Interval",
                            "config_path": "plugins.hook_monitoring.discovery_interval",
                            "min_value": 5,
                            "max_value": 300,
                            "step": 5,
                            "help": "Plugin discovery interval in seconds"
                        },
                        {
                            "type": "checkbox",
                            "label": "Auto Analyze Capabilities",
                            "config_path": "plugins.hook_monitoring.auto_analyze_capabilities",
                            "help": "Automatically analyze plugin capabilities"
                        },
                        {
                            "type": "checkbox",
                            "label": "Enable Service Registration",
                            "config_path": "plugins.hook_monitoring.enable_service_registration",
                            "help": "Register monitoring services with event bus"
                        },
                        {
                            "type": "checkbox",
                            "label": "Register Performance Service",
                            "config_path": "plugins.hook_monitoring.register_performance_service",
                            "help": "Register performance monitoring service"
                        },
                        {
                            "type": "checkbox",
                            "label": "Register Health Service",
                            "config_path": "plugins.hook_monitoring.register_health_service",
                            "help": "Register health monitoring service"
                        },
                        {
                            "type": "checkbox",
                            "label": "Register Metrics Service",
                            "config_path": "plugins.hook_monitoring.register_metrics_service",
                            "help": "Register metrics collection service"
                        },
                        {
                            "type": "checkbox",
                            "label": "Enable Cross Plugin Communication",
                            "config_path": "plugins.hook_monitoring.enable_cross_plugin_communication",
                            "help": "Allow plugins to communicate with each other"
                        },
                        {
                            "type": "slider",
                            "label": "Message History Limit",
                            "config_path": "plugins.hook_monitoring.message_history_limit",
                            "min_value": 5,
                            "max_value": 100,
                            "step": 5,
                            "help": "Maximum message history entries"
                        },
                        {
                            "type": "checkbox",
                            "label": "Auto Respond to Health Checks",
                            "config_path": "plugins.hook_monitoring.auto_respond_to_health_checks",
                            "help": "Automatically respond to health check requests"
                        },
                        {
                            "type": "slider",
                            "label": "Health Check Interval",
                            "config_path": "plugins.hook_monitoring.health_check_interval",
                            "min_value": 10,
                            "max_value": 300,
                            "step": 10,
                            "help": "Health check interval in seconds"
                        },
                        {
                            "type": "slider",
                            "label": "Memory Threshold MB",
                            "config_path": "plugins.hook_monitoring.memory_threshold_mb",
                            "min_value": 10,
                            "max_value": 500,
                            "step": 10,
                            "help": "Memory usage warning threshold in MB"
                        },
                        {
                            "type": "slider",
                            "label": "Performance Degradation Threshold",
                            "config_path": "plugins.hook_monitoring.performance_degradation_threshold",
                            "min_value": 0.05,
                            "max_value": 0.5,
                            "step": 0.05,
                            "help": "Performance degradation warning threshold"
                        },
                        {
                            "type": "checkbox",
                            "label": "Collect Plugin Metrics",
                            "config_path": "plugins.hook_monitoring.collect_plugin_metrics",
                            "help": "Collect detailed metrics for all plugins"
                        },
                        {
                            "type": "slider",
                            "label": "Metrics Retention Hours",
                            "config_path": "plugins.hook_monitoring.metrics_retention_hours",
                            "min_value": 1,
                            "max_value": 168,
                            "step": 1,
                            "help": "How long to retain metrics data (hours)"
                        },
                        {
                            "type": "checkbox",
                            "label": "Detailed Performance Tracking",
                            "config_path": "plugins.hook_monitoring.detailed_performance_tracking",
                            "help": "Enable detailed performance tracking"
                        },
                        {
                            "type": "checkbox",
                            "label": "Enable Health Dashboard",
                            "config_path": "plugins.hook_monitoring.enable_health_dashboard",
                            "help": "Show health monitoring dashboard"
                        },
                        {
                            "type": "slider",
                            "label": "Dashboard Update Interval",
                            "config_path": "plugins.hook_monitoring.dashboard_update_interval",
                            "min_value": 1,
                            "max_value": 60,
                            "step": 1,
                            "help": "Dashboard refresh interval in seconds"
                        },
                        {
                            "type": "checkbox",
                            "label": "Show Plugin Interactions",
                            "config_path": "plugins.hook_monitoring.show_plugin_interactions",
                            "help": "Display plugin interaction information"
                        },
                        {
                            "type": "checkbox",
                            "label": "Show Service Usage",
                            "config_path": "plugins.hook_monitoring.show_service_usage",
                            "help": "Display service usage statistics"
                        }
                    ]
                },
                {
                    "title": "Query Enhancer Plugin",
                    "widgets": [
                        {
                            "type": "checkbox",
                            "label": "Show Status",
                            "config_path": "plugins.query_enhancer.show_status",
                            "help": "Display query enhancement status"
                        },
                        {
                            "type": "text_input",
                            "label": "Fast Model API URL",
                            "config_path": "plugins.query_enhancer.fast_model.api_url",
                            "placeholder": "http://localhost:1234",
                            "help": "API URL for fast enhancement model"
                        },
                        {
                            "type": "text_input",
                            "label": "Fast Model",
                            "config_path": "plugins.query_enhancer.fast_model.model",
                            "placeholder": "qwen3-0.6b",
                            "help": "Model name for query enhancement"
                        },
                        {
                            "type": "slider",
                            "label": "Fast Model Temperature",
                            "config_path": "plugins.query_enhancer.fast_model.temperature",
                            "min_value": 0.0,
                            "max_value": 1.0,
                            "step": 0.1,
                            "help": "Creativity level for enhancement (0.0-1.0)"
                        },
                        {
                            "type": "slider",
                            "label": "Fast Model Timeout",
                            "config_path": "plugins.query_enhancer.fast_model.timeout",
                            "min_value": 1,
                            "max_value": 30,
                            "step": 1,
                            "help": "Timeout for enhancement requests (seconds)"
                        },
                        {
                            "type": "slider",
                            "label": "Max Query Length",
                            "config_path": "plugins.query_enhancer.max_length",
                            "min_value": 100,
                            "max_value": 2000,
                            "step": 50,
                            "help": "Maximum enhanced query length"
                        },
                        {
                            "type": "slider",
                            "label": "Min Query Length",
                            "config_path": "plugins.query_enhancer.min_query_length",
                            "min_value": 1,
                            "max_value": 50,
                            "step": 1,
                            "help": "Minimum query length to enhance"
                        },
                        {
                            "type": "checkbox",
                            "label": "Performance Tracking",
                            "config_path": "plugins.query_enhancer.performance_tracking",
                            "help": "Track enhancement performance metrics"
                        }
                    ]
                },
                {
                    "title": "Workflow Enforcement",
                    "widgets": [
                        {
                            "type": "checkbox",
                            "label": "Require Tool Calls",
                            "config_path": "workflow_enforcement.require_tool_calls",
                            "help": "Require workflows to include tool calls"
                        },
                        {
                            "type": "slider",
                            "label": "Confirmation Timeout",
                            "config_path": "workflow_enforcement.confirmation_timeout",
                            "min_value": 30,
                            "max_value": 600,
                            "step": 30,
                            "help": "Workflow confirmation timeout (seconds)"
                        },
                        {
                            "type": "checkbox",
                            "label": "Auto Start Workflows",
                            "config_path": "workflow_enforcement.auto_start_workflows",
                            "help": "Automatically start detected workflows"
                        },
                        {
                            "type": "checkbox",
                            "label": "Show Progress in Status",
                            "config_path": "workflow_enforcement.show_progress_in_status",
                            "help": "Display workflow progress in status bar"
                        }
                    ]
                }
            ],
            "actions": [
                {
                    "key": "Ctrl+S",
                    "label": "Save",
                    "action": "save",
                    "style": "primary"
                },
                {
                    "key": "Escape",
                    "label": "Cancel",
                    "action": "cancel",
                    "style": "secondary"
                }
            ]
        }

    @staticmethod
    def create_widgets_from_definition(config_service, definition: Dict[str, Any]) -> List[Any]:
        """Create widget instances from modal definition.

        Args:
            config_service: ConfigService for reading current values.
            definition: Modal definition dictionary.

        Returns:
            List of instantiated widgets.
        """
        widgets = []

        try:
            from .widgets.checkbox import CheckboxWidget
            from .widgets.dropdown import DropdownWidget
            from .widgets.text_input import TextInputWidget
            from .widgets.slider import SliderWidget

            widget_classes = {
                "checkbox": CheckboxWidget,
                "dropdown": DropdownWidget,
                "text_input": TextInputWidget,
                "slider": SliderWidget
            }

            for section in definition.get("sections", []):
                for widget_def in section.get("widgets", []):
                    widget_type = widget_def["type"]
                    widget_class = widget_classes.get(widget_type)

                    if not widget_class:
                        logger.error(f"Unknown widget type: {widget_type}")
                        continue

                    # Get current value from config
                    config_path = widget_def["config_path"]
                    current_value = config_service.get(config_path)

                    # Create widget with configuration
                    widget = widget_class(
                        label=widget_def["label"],
                        config_path=config_path,
                        help_text=widget_def.get("help", ""),
                        current_value=current_value,
                        **{k: v for k, v in widget_def.items()
                           if k not in ["type", "label", "config_path", "help"]}
                    )

                    widgets.append(widget)
                    logger.debug(f"Created {widget_type} widget for {config_path}")

        except Exception as e:
            logger.error(f"Error creating widgets from definition: {e}")

        logger.info(f"Created {len(widgets)} widgets from definition")
        return widgets

    @staticmethod
    def get_widget_navigation_info() -> Dict[str, str]:
        """Get navigation key information for modal help.

        Returns:
            Dictionary mapping keys to their descriptions.
        """
        return {
            "↑↓": "Navigate between widgets",
            "←→": "Adjust slider values / Navigate dropdown options",
            "Enter": "Toggle checkbox / Open dropdown / Edit text",
            "Space": "Toggle checkbox",
            "Tab": "Next widget",
            "Shift+Tab": "Previous widget",
            "Ctrl+S": "Save all changes",
            "Escape": "Cancel and exit without saving"
        }