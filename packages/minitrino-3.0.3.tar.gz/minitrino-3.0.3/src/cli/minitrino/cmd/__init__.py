"""Minitrino CLI commands package."""
