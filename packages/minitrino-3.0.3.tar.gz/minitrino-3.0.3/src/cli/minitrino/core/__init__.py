"""Core Minitrino functionality."""
