"""Command executor (subprocess; container) machinery."""
