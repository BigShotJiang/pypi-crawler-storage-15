"""
Tima - Activity Timer
A desktop productivity timer that cycles through your projects.
"""

__version__ = "1.0.0"
__author__ = "Tima Developer"

from tima_timer.app import main

__all__ = ['main']
