# ocrd

> API and CLI for ocrd

See [generated self-documentation of API and CLI](https://ocr-d.de/core/)

See also: https://github.com/OCR-D/core
