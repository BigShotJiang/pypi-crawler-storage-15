# ocrd_network

> OCR-D framework - web API

See also: https://github.com/OCR-D/core
