

def calcular(a, b, operador):
    """
    Realiza una operación aritmética entre dos números.

    operadores: '+', '-', '*', '/'
    """
    if operador == '+':
        return a + b
    elif operador == '-':
        return a - b
    elif operador == '*':
        return a * b
    elif operador == '/':
        if b == 0:
            raise ZeroDivisionError("No se puede dividir entre cero")
        return a / b
    else:
        raise ValueError(f"Operador no soportado: {operador}")
