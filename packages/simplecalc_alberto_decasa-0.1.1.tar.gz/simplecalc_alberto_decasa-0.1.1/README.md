
# simplecalc

Pequeño paquete que expone una función `calcular(a, b, operador)` para
realizar operaciones de suma, resta, multiplicación y división.

## Uso

```python
from simplecalc-alberto.decasa import calcular

print(calcular(2, 3, '+'))  # 5
