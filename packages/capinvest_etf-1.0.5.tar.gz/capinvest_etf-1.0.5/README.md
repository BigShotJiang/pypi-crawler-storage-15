# ETF data extension for CapInvest SDK

This extension provides a set of commands for ETF data retrieval.

 