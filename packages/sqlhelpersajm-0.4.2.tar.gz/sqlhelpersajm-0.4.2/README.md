# <u>SQLHelpersAJM</u>
### <i>classes meant to streamline interaction with multiple different flavors of SQL database including MSSQL, SQLite, and PostgresSQL</i>


classes meant to streamline interaction with multiple different flavors of SQL database including MSSQL, SQLite, and PostgresSQL