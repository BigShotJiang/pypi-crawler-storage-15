from arraylake.cli.main import app

app(prog_name="arraylake")
