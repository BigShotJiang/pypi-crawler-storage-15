#!/bin/bash

cd src/tests
python3 -m unittest discover
