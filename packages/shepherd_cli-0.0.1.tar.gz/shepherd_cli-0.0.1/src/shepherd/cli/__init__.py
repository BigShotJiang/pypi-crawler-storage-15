"""CLI package for Shepherd."""
