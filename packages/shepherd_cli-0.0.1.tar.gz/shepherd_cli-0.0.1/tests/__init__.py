"""Tests for Shepherd CLI."""
