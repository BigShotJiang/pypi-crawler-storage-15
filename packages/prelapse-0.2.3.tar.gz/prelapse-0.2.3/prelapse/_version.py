# This file is generated on release from pyproject.toml by setuptools_scm.
# Do not modify this file manually.
__version__ = 'v0.2.3'
