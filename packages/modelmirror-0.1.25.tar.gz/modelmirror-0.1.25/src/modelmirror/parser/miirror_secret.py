from dataclasses import dataclass


@dataclass
class MirrorSecret:
    value: str
