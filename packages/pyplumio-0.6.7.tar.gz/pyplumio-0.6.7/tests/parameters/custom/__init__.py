"""Contains tests for the custom parameters module."""
