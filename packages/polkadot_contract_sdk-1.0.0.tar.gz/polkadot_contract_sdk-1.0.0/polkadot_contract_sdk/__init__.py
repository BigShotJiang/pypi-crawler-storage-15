"""
Polkadot Smart Contract SDK
A simple SDK for deploying and interacting with smart contracts
"""

__version__ = "1.0.0"

