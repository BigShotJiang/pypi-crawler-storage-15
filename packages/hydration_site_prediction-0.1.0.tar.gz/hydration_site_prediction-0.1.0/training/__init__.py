"""Training scripts for hydration site and thermodynamics models."""
