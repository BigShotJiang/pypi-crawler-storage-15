class Pys:
    __slots__ = ()