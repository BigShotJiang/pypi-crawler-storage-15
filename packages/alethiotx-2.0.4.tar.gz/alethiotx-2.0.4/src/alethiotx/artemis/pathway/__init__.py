from .genes import get, load

__all__ = ['get', 'load']