"""
PyEventBT
Documentation: https://pyeventbt.com
GitHub: https://github.com/marticastany/pyeventbt

Author: Marti Castany
Copyright (c) 2025 Marti Castany
Licensed under the Apache License, Version 2.0
"""

from .core.configurations.signal_engine_configurations import *
from .signal_engines.signal_ma_crossover import SignalMACrossover