"""Tests for msn-weather-wrapper."""
