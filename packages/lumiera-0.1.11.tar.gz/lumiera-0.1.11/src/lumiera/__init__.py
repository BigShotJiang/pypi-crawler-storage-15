# src/lumiera/__init__.py

from .cli import main

# (Optional) In future, add more subcommands like:
# from .backup.jobs import cli as backup_cli
# main.add_command(backup_cli)
