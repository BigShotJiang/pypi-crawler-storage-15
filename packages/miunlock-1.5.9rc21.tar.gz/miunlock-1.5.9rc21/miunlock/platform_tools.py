import os
import subprocess
import platform
import shutil
import urllib.request
import zipfile
import stat
from pathlib import Path

def run_command(command):
    full_command = f"yes | {command}"
    result = subprocess.run(full_command, shell=True)
    return result.returncode == 0

def main(PREFIX):
    
    if not run_command("yes | apt update"):
        return {'error': 'update failed'}

    if not run_command("yes | apt upgrade"):
        return {'error': 'upgrade failed'}

    if not run_command("yes | apt install coreutils gnupg curl"):
        return {'error': 'install packages failed'}

    repo_file = f"{PREFIX}/etc/apt/sources.list.d/termux-adb.list"

    if not os.path.isfile(repo_file):
        os.makedirs(f"{PREFIX}/etc/apt/sources.list.d", exist_ok=True)
        with open(repo_file, 'w') as f:
            f.write("deb https://nohajc.github.io termux extras\n")
        
        gpg_path = f"{PREFIX}/etc/apt/trusted.gpg.d/nohajc.gpg"
        result = subprocess.run(
            f"curl -fsSL -o {gpg_path} https://nohajc.github.io/nohajc.gpg",
            shell=True
        )
        if result.returncode != 0:
            return {'error': 'curl GPG key failed'}
        
        if not run_command("yes | apt update"):
            return {'error': 'update after repo add failed'}

    if not run_command("yes | apt install termux-adb"):
        return {'error': 'install termux-adb failed'}

    fastboot_path = f"{PREFIX}/bin/termux-fastboot"
    
    if os.path.isfile(fastboot_path):
        return fastboot_path
    else:
        return {'error': 'termux-fastboot not found'}


s = platform.system()

def check_fastboot():

    if s == "Linux" and os.path.exists("/data/data/com.termux"):      
        if not os.path.exists("/data/data/com.termux.api"):
            return {"error": "com.termux.api app is not installed\nPlease install it first"}
        
        PREFIX = os.environ.get('PREFIX', '/data/data/com.termux/files/usr')
        fastboot_path = f"{PREFIX}/bin/termux-fastboot"
        
        if not os.path.isfile(fastboot_path):
            result = main(PREFIX)
            return result
        
        return fastboot_path
    
    cmd = shutil.which("fastboot")        
    if cmd is not None:
        return cmd
    
    tools_dir = Path.home() / ".android-tools" / "platform-tools"
    print(f"Tools directory: {tools_dir}")
    fastboot_path = tools_dir / "fastboot"
    
    if s == "Windows":
        fastboot_path = tools_dir / "fastboot.exe"
    
    if fastboot_path.exists():
        return str(fastboot_path)
    
    print("\nDownloading platform-tools...\n")
    url = f"https://dl.google.com/android/repository/platform-tools-latest-{s}.zip"
    
    tools_dir.parent.mkdir(parents=True, exist_ok=True)
    
    zip_path = tools_dir.parent / "platform-tools.zip"
    
    try:
        urllib.request.urlretrieve(url, str(zip_path))
        
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(str(tools_dir.parent))
        
        zip_path.unlink()
        
        if s in ["Linux", "Darwin"]:
            st = os.stat(fastboot_path)
            os.chmod(fastboot_path, st.st_mode | stat.S_IEXEC)
        
        return str(fastboot_path)
    
    except Exception as e:
        return {"error": f"Failed to download platform-tools: {str(e)}"}