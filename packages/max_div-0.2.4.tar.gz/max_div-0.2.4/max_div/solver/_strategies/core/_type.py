from __future__ import annotations

from enum import StrEnum


class StrategyType(StrEnum):
    INITIALIZATION = "INITIALIZATION"
    OPTIMIZATION = "OPTIMIZATION"
