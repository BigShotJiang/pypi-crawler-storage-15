from setuptools import setup, find_packages

setup(name='hu2',
      version='0.0.11',
      author='huzhe666',
      author_email='huzhe666@live.com',
      description='a small tool of python',
      long_description='<p>no time write the document</p>',
      packages=find_packages()
      )
