"""
Tests for mtsespy
"""

from concurrent.futures import ProcessPoolExecutor
from time import sleep
from math import log2

import pytest

import mtsespy as mts


@pytest.fixture(autouse=True)
def reinit():
    mts.reinitialize()


@pytest.mark.wheel
def test_register_and_deregister_client():
    client = mts.register_client()
    mts.deregister_client(client)


@pytest.mark.wheel
def test_register_and_deregister_master():
    mts.register_master()
    mts.deregister_master()


@pytest.mark.wheel
def test_can_register_master():
    assert mts.can_register_master()


def test_note_to_frequency():
    with mts.Client() as c:
        f = mts.note_to_frequency(c, 69, 0)
    assert f == 440.0


def test_note_to_frequency_with_master_1():
    with mts.Master():
        with mts.Client() as c:
            f = mts.note_to_frequency(c, 69, 0)
    assert f == 440.0


def test_note_to_frequency_with_master_2():
    with mts.Master():
        mts.set_note_tuning(441.0, 69)
    with mts.Master():
        with mts.Client() as c:
            f = mts.note_to_frequency(c, 69, 0)
    assert f == 440.0


def test_note_to_frequency_with_master_and_reinitialize():
    with mts.Master():
        mts.set_note_tuning(441.0, 69)
    mts.reinitialize()
    with mts.Master():
        with mts.Client() as c:
            f = mts.note_to_frequency(c, 69, 0)
    assert f == 440.0


def test_note_to_frequency_after_master():
    with mts.Master():
        mts.set_note_tuning(441.0, 69)
    with mts.Client() as c:
        f = mts.note_to_frequency(c, 69, 0)
    assert f == 440.0


def test_retuning_in_semitones():
    with mts.Client() as c:
        semitones = mts.retuning_in_semitones(c, 69, 0)
    assert semitones == 0.0


def test_retuning_in_semitones_2():
    with mts.Master():
        mts.set_note_tuning(440 * 2 ** (1 / 24), 69)
        with mts.Client() as c:
            semitones = mts.retuning_in_semitones(c, 69, 0)
    assert abs(semitones - 0.5) <= 1e-6


def test_retuning_as_ratio():
    with mts.Client() as c:
        ratio = mts.retuning_as_ratio(c, 69, 0)
    assert ratio == 1.0


def test_retuning_as_ratio_2():
    retune_ratio = 25 / 24
    with mts.Master():
        mts.set_note_tuning(440 * retune_ratio, 69)
        with mts.Client() as c:
            ratio = mts.retuning_as_ratio(c, 69, 0)
    assert abs(ratio - retune_ratio) < 1e-6


def test_master_context_manager():
    """
    Test that client pulls master's new frequency if used within Master context.
    """
    with mts.Master():
        mts.set_note_tuning(441.0, 69)
        with mts.Client() as c:
            f = mts.note_to_frequency(c, 69, 0)
    assert f == 441.0


def test_master_context_manager_2():
    """
    Test that client pulls default frequency if used outside Master context.
    """
    with mts.Master():
        mts.set_note_tuning(441.0, 69)
    with mts.Client() as c:
        f = mts.note_to_frequency(c, 69, 0)
    assert f == 440.0


def test_master_exists_error():
    with pytest.raises(mts.MasterExistsError):
        with mts.Master():
            with mts.Master():
                pass


def test_set_note_tunings():
    frequencies = list(range(128))
    with mts.Master():
        mts.set_note_tunings(frequencies)
        with mts.Client() as c:
            client_frequencies = [mts.note_to_frequency(c, i, 0) for i in range(128)]
    assert frequencies == client_frequencies


def test_has_ipc():
    assert mts.has_ipc()


def test_get_num_clients():
    with mts.Master():
        assert mts.get_num_clients() == 0
        with mts.Client():
            assert mts.get_num_clients() == 1
            with mts.Client():
                assert mts.get_num_clients() == 2
            assert mts.get_num_clients() == 1
        assert mts.get_num_clients() == 0


def test_reinitialize():
    assert mts.can_register_master()
    mts.register_master()
    assert not mts.can_register_master()
    mts.reinitialize()
    assert mts.can_register_master()


def test_reinitialize_2():
    mts.register_client()
    assert mts.get_num_clients() == 1
    mts.reinitialize()
    assert mts.get_num_clients() == 0


def test_get_scale_name():
    with mts.Client() as c:
        name = mts.get_scale_name(c)
    assert name == "12-TET"


def test_set_scale_name():
    with mts.Master():
        mts.set_scale_name("foo")
        with mts.Client() as c:
            name = mts.get_scale_name(c)
    assert name == "foo"


def test_should_filter_note():
    with mts.Client() as c:
        should_filter = mts.should_filter_note(c, 69, 0)
    assert not should_filter


def test_filter_note():
    with mts.Master():
        mts.filter_note(True, 69, 0)
        with mts.Client() as c:
            should_filter = mts.should_filter_note(c, 69, 0)
    assert should_filter


def test_clear_note_filter():
    with mts.Master():
        mts.filter_note(True, 69, 0)
        mts.clear_note_filter()
        with mts.Client() as c:
            should_filter = mts.should_filter_note(c, 69, 0)
    assert not should_filter


def test_set_multi_channel_note_tuning():
    with mts.Master():
        mts.set_multi_channel(True, 0)
        mts.set_multi_channel_note_tuning(441.0, 69, 0)
        with mts.Client() as c:
            f = mts.note_to_frequency(c, 69, 0)
    assert f == 441.0


def test_set_multi_channel_note_tuning_2():
    with mts.Master():
        mts.set_multi_channel(False, 0)
        mts.set_multi_channel_note_tuning(441.0, 69, 0)
        with mts.Client() as c:
            f = mts.note_to_frequency(c, 69, 0)
    assert f == 440.0


def test_set_multi_channel_note_tunings():
    frequencies = list(range(128))
    with mts.Master():
        mts.set_multi_channel(True, 0)
        mts.set_multi_channel_note_tunings(frequencies, 0)
        with mts.Client() as c:
            client_frequencies = [mts.note_to_frequency(c, i, 0) for i in range(128)]
    assert frequencies == client_frequencies


def test_set_multi_channel_note_tunings_2():
    frequencies = list(range(128))
    with mts.Master():
        mts.set_multi_channel(False, 0)
        mts.set_multi_channel_note_tunings(frequencies, 0)
        with mts.Client() as c:
            client_frequencies = [mts.note_to_frequency(c, i, 0) for i in range(128)]
    assert frequencies != client_frequencies


def test_filter_note_multi_channel():
    with mts.Master():
        mts.set_multi_channel(True, 1)
        mts.filter_note_multi_channel(True, 69, 1)
        with mts.Client() as c:
            should_filter = mts.should_filter_note(c, 69, 1)
    assert should_filter


def test_clear_note_filter_multi_channel():
    with mts.Master():
        mts.set_multi_channel(True, 1)
        mts.filter_note_multi_channel(True, 69, 1)
        mts.clear_note_filter_multi_channel(1)
        with mts.Client() as c:
            should_filter = mts.should_filter_note(c, 69, 1)
    assert not should_filter


def test_clear_note_filter_multi_channel_2():
    with mts.Master():
        mts.set_multi_channel(True, 1)
        mts.filter_note_multi_channel(True, 69, 1)
        mts.clear_note_filter_multi_channel(0)
        with mts.Client() as c:
            should_filter = mts.should_filter_note(c, 69, 1)
    assert should_filter


def test_has_master():
    with mts.Master():
        with mts.Client() as c:
            does_have_master = mts.has_master(c)
    assert does_have_master


def test_has_master_2():
    with mts.Client() as c:
        does_have_master = mts.has_master(c)
    assert not does_have_master


def test_frequency_to_note():
    with mts.Client() as c:
        note = mts.frequency_to_note(c, 441.0, 0)
    assert note == 69


def test_frequency_to_note_2():
    with mts.Master():
        mts.set_note_tuning(441.0, 80)
        with mts.Client() as c:
            note = mts.frequency_to_note(c, 441.0, 0)
    assert note == 80


def test_frequency_to_note_and_channel():
    with mts.Client() as c:
        note, channel = mts.frequency_to_note_and_channel(c, 441.0)
    assert note == 69
    assert channel == 0


def test_frequency_to_note_and_channel_2():
    with mts.Master():
        mts.set_note_tuning(441.0, 80)
        with mts.Client() as c:
            note, channel = mts.frequency_to_note_and_channel(c, 441.0)
    assert note == 80
    assert channel == 0


def test_frequency_to_note_and_channel_3():
    with mts.Master():
        mts.set_multi_channel(True, 1)
        mts.set_multi_channel_note_tuning(441.0, 80, 1)
        with mts.Client() as c:
            note, channel = mts.frequency_to_note_and_channel(c, 441.0)
    assert note == 80
    assert channel == 1


def test_parse_midi_data():
    # MTS sysex message to tune midi note 69 up a quarter tone
    msg = bytes.fromhex("F0 7F 00 08 02 00 01" + "45" + "45 40 00" + "F7")
    with mts.Client() as c:
        f_before = mts.note_to_frequency(c, 69, 0)
        mts.parse_midi_data(c, msg)
        f_after = mts.note_to_frequency(c, 69, 0)
    assert f_before == 440.0
    assert abs(f_after - 440.0 * 2 ** (1 / 24)) < 1e-3


def master_function():
    with mts.Master():
        mts.set_note_tuning(441.0, 69)
        sleep(1)


def client_function():
    with mts.Client() as c:
        sleep(0.5)
        f = mts.note_to_frequency(c, 69, 0)
    return f


def test_ipc():
    """
    Test that a frequency set in one process is picked up in another.

    This is mainly a test of IPC in the libMTS.so library.
    """
    with ProcessPoolExecutor() as executor:
        client_task = executor.submit(client_function)
        master_task = executor.submit(master_function)
        assert master_task.result() is None
        assert client_task.result() == 441.0


def test_client_should_update_library():
    with mts.Client() as c:
        should_update = mts.client_should_update_library(c)
    assert not should_update


def test_get_period_ratio():
    with mts.Client() as c:
        period_ratio = mts.get_period_ratio(c)
    assert period_ratio == 2.0


def test_get_period_semitones():
    with mts.Client() as c:
        period_semitones = mts.get_period_semitones(c)
    assert period_semitones == 12.0


def test_get_map_size():
    with mts.Client() as c:
        map_size = mts.get_map_size(c)
    assert map_size == -1


def test_get_map_start_key():
    with mts.Client() as c:
        map_start_key = mts.get_map_start_key(c)
    assert map_start_key == -1


def test_get_ref_key():
    with mts.Client() as c:
        ref_key = mts.get_ref_key(c)
    assert ref_key == -1


def test_has_received_mts_sysex_1():
    with mts.Client() as c:
        has_received = mts.has_received_mts_sysex(c)
    assert not has_received


def test_has_received_mts_sysex_2():
    # MTS sysex message to tune midi note 69 up a quarter tone
    msg = bytes.fromhex("F0 7F 00 08 02 00 01" + "45" + "45 40 00" + "F7")
    with mts.Client() as c:
        has_received_before = mts.has_received_mts_sysex(c)
        mts.parse_midi_data(c, msg)
        has_received_after = mts.has_received_mts_sysex(c)
    assert not has_received_before
    assert has_received_after


def test_has_received_mts_sysex_3():
    # Invalid MTS sysex message
    msg = bytes.fromhex("F1 7F 00 08 02 00 01" + "45" + "45 40 00" + "F7")
    with mts.Client() as c:
        has_received_before = mts.has_received_mts_sysex(c)
        mts.parse_midi_data(c, msg)
        has_received_after = mts.has_received_mts_sysex(c)
    assert not has_received_before
    assert not has_received_after


def test_master_should_update_library():
    with mts.Master():
        should_update = mts.master_should_update_library()
    assert not should_update


def test_set_period_ratio():
    with mts.Master():
        mts.set_period_ratio(3.0)
        with mts.Client() as c:
            period_ratio = mts.get_period_ratio(c)
    assert period_ratio == 3.0


def test_get_period_semitones_2():
    with mts.Master():
        mts.set_period_ratio(3.0)
        with mts.Client() as c:
            period_semitones = mts.get_period_semitones(c)
    assert abs(period_semitones - 12 * log2(3)) < 1e-14


def test_set_map_size():
    with mts.Master():
        mts.set_map_size(22)
        with mts.Client() as c:
            map_size = mts.get_map_size(c)
    assert map_size == 22


def test_set_map_start_key():
    with mts.Master():
        mts.set_map_start_key(60)
        with mts.Client() as c:
            start_key = mts.get_map_start_key(c)
    assert start_key == 60


def test_set_ref_key():
    with mts.Master():
        mts.set_ref_key(69)
        with mts.Client() as c:
            start_key = mts.get_ref_key(c)
    assert start_key == 69
