"""CapInvest Econometrics Extension."""
