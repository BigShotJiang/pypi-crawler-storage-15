An ipywidget image widget for astronomical purposes

Package Install
---------------

**Prerequisites**
- [node](http://nodejs.org/)

```bash
npm install --save bqplot-image-gl
```
