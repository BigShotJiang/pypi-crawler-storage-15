import json
import os

from cvsx2mvsx.models.internal.entry import InternalEntry
from cvsx2mvsx.models.internal.segment import InternalSegment
from cvsx2mvsx.models.internal.segmentation import (
    InternalMeshSegmentation,
    InternalSegmentation,
    InternalVolumeSegmentation,
)
from cvsx2mvsx.models.internal.volume import InternalVolume
from cvsx2mvsx.models.mvsx.states import MVSXEntry
from cvsx2mvsx.models.stories.model import (
    SceneAsset,
    SceneData,
    Story,
    StoryContainer,
    StoryMetadata,
)


class StoriesTransformer:
    def __init__(self, internal_entry: InternalEntry) -> None:
        self._internal_entry = internal_entry

    def run(self) -> MVSXEntry:
        assets = self._collect_all_assets()
        global_code = self._get_global_code()

        scenes: list[SceneData] = []
        for timeframe in self._internal_entry.timeframes.values():
            scene_code = ""
            for volume in timeframe.volumes.values():
                scene_code += "/* Volumes */\n"
                scene_code += self.add_volume_to_scene_code(volume)
            for segmentation in timeframe.segmentations.values():
                scene_code += "\n/* Segmentations */\n"
                if segmentation.kind == "volume":
                    scene_code += self._add_volume_segmentation_to_scene_code(
                        segmentation
                    )
                elif segmentation.kind == "mesh":
                    scene_code += self._add_mesh_segmentation_to_scene_code(
                        segmentation
                    )
                elif segmentation.kind == "geometric":
                    scene_code += self._add_geometric_segmentation_to_scene_code(
                        segmentation
                    )
            scene = SceneData(
                id=str(timeframe.timeframe_id),
                header=f"Timeframe {timeframe.timeframe_id}",
                key=f"timeframe-{timeframe.timeframe_id}",
                description="",
                javascript=scene_code,
            )
            scenes.append(scene)

        metadata = StoryMetadata(
            title=self._internal_entry.name or "Converted Volumes & Segmentations",
        )

        story = Story(
            metadata=metadata,
            javascript=global_code,
            scenes=scenes,
            assets=assets,
        )
        return StoryContainer(story=story)

    def _collect_all_assets(self) -> list[SceneAsset]:
        assets: list[SceneAsset] = []
        for timeframe in self._internal_entry.timeframes.values():
            for volume in timeframe.volumes.values():
                asset = self._create_volume_asset(volume)
                # for segmentation in timeframe.segmentations.values():
                #     if segmentation.kind == "volume":
                #         asset = self._add_volume_segmentation_asset(segmentation)
                assets.append(asset)
        return assets

    def _create_volume_asset(self, volume: InternalVolume) -> SceneAsset:
        source_filepath = os.path.join(
            self._internal_entry.assets_directory, volume.source_filepath
        )
        with open(source_filepath, "rb") as f:
            content = f.read()
            return SceneAsset(name=volume.source_filepath, content=content)

    def _create_volume_segmentation_asset(
        self,
        assets: list[SceneAsset],
        volume: InternalVolume,
    ) -> None:
        pass

    def _get_global_code(self) -> None:
        global_code = ""
        for timeframe in self._internal_entry.timeframes.values():
            for segmentation in timeframe.segmentations.values():
                if segmentation.kind == "mesh":
                    global_code += self._get_mesh_segmentation_code(segmentation)
        return global_code

    def _get_mesh_segmentation_code(
        self,
        segmentation: InternalMeshSegmentation,
    ) -> None:
        code = ""

        for segment in segmentation.segments.values():
            source_filepath = os.path.join(
                self._internal_entry.assets_directory, segment.source_filepath
            )
            with open(source_filepath, "r") as f:
                data = f.read()
            variable = self._get_segment_variable_name(segment)
            code += f"""
const {variable} = {data}
"""

        return code

    def add_volume_to_scene_code(self, volume: InternalVolume) -> str:
        if volume.kind == "isosurface":
            code = f"""
// Volume "{volume.channel_id}"
builder.download({{
    url: "{volume.source_filepath}"
}}).parse({{
    format: "bcif"
}}).volume({{
    channel_id: "{volume.channel_id}"
}}).representation({{
    type: "isosurface",
    relative_isovalue: {volume.relative_isovalue}
}}).color({{
    color: "{volume.color}",
}}).opacity({{
    opacity: {volume.opacity},
}})
"""
        else:
            code = f"""
builder.download({{
    url: "{volume.source_filepath}"
}}).parse({{
    format: "bcif"
}}).volume({{
    channel_id: "{volume.channel_id}"
}}).representation({{
    type: "grid_slice",
    relative_isovalue: {volume.relative_isovalue},
    dimension: "{volume.dimension}",
    absolute_index: 0
}}).color({{
    color: "{volume.color}",
}}).opacity({{
    opacity: {volume.opacity},
}})
"""
        return code

    def _add_volume_segmentation_to_scene_code(
        self,
        segmentation: InternalVolumeSegmentation,
    ) -> str:
        pass

    def _add_mesh_segmentation_to_scene_code(
        self,
        segmentation: InternalVolumeSegmentation,
    ) -> str:
        code = ""
        for segment in segmentation.segments.values():
            variable = self._get_segment_variable_name(segment)
            code += f"""
// Mesh segmentation '{segment.segmentation_id}', segment '{segment.segment_id}'
builder.primitives({{
    color: "{segment.color}",
    opacity: {segment.opacity},
    tooltip: {json.dumps(self.get_segment_tooltip(segment))},
    instances: [{list(segment.instance)}]
}}).mesh({{
    vertices: {variable}.vertices,
    indices: {variable}.indices,
    triangle_groups: {variable}.triangle_groups
}})
"""
        return code

    def _add_geometric_segmentation_to_scene_code(
        self,
        segmentation: InternalVolumeSegmentation,
    ) -> str:
        opacity = segmentation.opacity if segmentation.opacity else "undefined"
        code = f"""
// Geometric segmentation '{segmentation.segmentation_id}'
builder.primitives({{
    opacity: {opacity},
}})
"""
        for segment in segmentation.segments.values():
            code += self._add_geometric_segment_to_scene_code(segment)
        return code

    def _add_geometric_segment_to_scene_code(self, segment: InternalSegment) -> None:
        code = "// Segment '{segment.segment_id}'\n"
        if segment.kind == "mesh":
            code += f"""
.mesh({{
    vertices: {segment.vertices.ravel().tolist()},
    indices: {segment.indices.ravel().tolist()},
    triangle_groups: {segment.triangle_groups.ravel().tolist()},
    color: '{segment.color}',
    tooltip: {json.dumps(self.get_segment_tooltip(segment))},
}})
"""
        elif segment.kind == "ellipsoid":
            code += f""".ellipsoid({{
    center: {list(segment.center)},
    major_axis: {list(segment.major_axis)},
    minor_axis: {list(segment.minor_axis)},
    radius: {segment.radius},
    color: '{segment.color}',
    tooltip: {json.dumps(self.get_segment_tooltip(segment))},
}})
"""
        elif segment.kind == "sphere":
            code += f""".sphere({{
    center: {list(segment.center)},
    radius: {segment.radius},
    color: '{segment.color}',
    tooltip: {json.dumps(self.get_segment_tooltip(segment))},
}})
"""
        elif segment.kind == "box":
            code += f""".box({{
    center: {list(segment.center)},
    extent: {list(segment.extent)},
    color: '{segment.color}',
    tooltip: {json.dumps(self.get_segment_tooltip(segment))},
}})
"""
        elif segment.kind == "tube":
            code += f""".tube({{
    start: {list(segment.start)},
    end: {list(segment.end)},
    radius: {segment.radius},
    color: '{segment.color}',
    tooltip: {json.dumps(self.get_segment_tooltip(segment))},
}})
"""
        return code

    def get_segment_tooltip(self, segment: InternalSegment) -> str:
        segmentation_id = segment.segmentation_id
        segment_id = segment.segment_id
        return f"Segmentation: {segmentation_id}\n\nSegment: {segment_id}"

    def get_segmentation_tooltip(self, segmentation: InternalSegmentation) -> str:
        segmentation_id = segmentation.segmentation_id
        return f"Segmentation: {segmentation_id}"

    def _get_segment_variable_name(self, segment: InternalSegment) -> str:
        kind = segment.kind
        t_id = segment.timeframe_id
        s_id = segment.segmentation_id
        ss_id = segment.segment_id
        return f"{kind}_{t_id}_{s_id}_{ss_id}"
