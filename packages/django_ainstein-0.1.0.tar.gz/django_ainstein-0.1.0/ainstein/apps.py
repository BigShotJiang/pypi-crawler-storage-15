from django.apps import AppConfig


class AinsteinConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ainstein'
