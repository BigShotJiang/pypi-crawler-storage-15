"""
Skills module for Claude Agent.

Skills are domain-specific prompt extensions appended to the system prompt
when the user's message matches certain keywords.

References:
- https://github.com/anthropics/claude-code/blob/main/plugins/frontend-design/
- https://github.com/anthropics/claude-cookbooks/blob/main/coding/prompting_for_frontend_aesthetics.ipynb
"""

# =============================================================================
# Skill Content
# =============================================================================

FRONTEND_DESIGN = """
## SKILL: Frontend Design

Create distinctive, production-grade frontend interfaces with high design quality. Generate creative, polished code that avoids generic AI aesthetics.

### Design Thinking

Before coding, commit to a bold aesthetic direction:
- **Purpose**: What problem does this interface solve? Who uses it?
- **Tone**: Pick an extreme: brutally minimal, maximalist chaos, retro-futuristic, luxury/refined, playful/toy-like, brutalist/raw, art deco/geometric, soft/pastel, etc.
- **Differentiation**: What makes this unforgettable?

Bold maximalism and refined minimalism both work - the key is intentionality, not intensity.

### Aesthetics Guidelines

- **Typography**: Avoid generic fonts (Arial, Inter, Roboto). Use high contrast pairings. Apply extreme weight variations (100/200 vs 800/900). Good sources: JetBrains Mono, Playfair Display, Clash Display, Satoshi.
- **Color & Theme**: Use CSS variables. Dominant colors with sharp accents outperform timid palettes. Lock in specific themes (solarpunk, brutalist, art deco).
- **Motion**: Prioritize CSS-only. One well-orchestrated page load with staggered reveals (animation-delay) beats scattered micro-interactions.
- **Spatial Composition**: Unexpected layouts. Asymmetry. Overlap. Grid-breaking elements.
- **Backgrounds**: Create depth beyond solid colors. Layer gradients, noise textures, geometric patterns.

Avoid: overused fonts (Inter, Roboto, Space Grotesk), purple gradients on white, predictable layouts."""


# =============================================================================
# Skill Registry: name -> (keywords, content)
# =============================================================================

SKILLS = {
    "frontend-design": {
        "keywords": [
            "html",
            "css",
            "frontend",
            "front-end",
            "ui",
            "component",
            "webpage",
            "website",
            "web app",
            "webapp",
            "landing page",
            "interface",
            "dashboard",
            "layout",
            "tailwind",
            "bootstrap",
        ],
        "content": FRONTEND_DESIGN,
    },
}


# =============================================================================
# Matching Functions
# =============================================================================


def get_matching_skills(user_message: str) -> tuple[str, list[str]]:
    """
    Return matching skill content and names in a single pass.

    Returns:
        tuple of (concatenated content, list of skill names)
    """
    if not user_message:
        return "", []

    message_lower = user_message.lower()
    matched_content = []
    matched_names = []

    for name, skill in SKILLS.items():
        if any(kw in message_lower for kw in skill["keywords"]):
            matched_content.append(skill["content"])
            matched_names.append(name)

    return "\n".join(matched_content), matched_names
