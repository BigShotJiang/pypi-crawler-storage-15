"""
Claude Agent SDK Hooks for permission handling and tool control.

This module implements PreToolUse and PostToolUse hooks for:
- Permission-based tool gating (human-in-the-loop)
- Tool execution logging
- Dangerous operation blocking

The permission flow:
1. PreToolUse hook fires before tool execution
2. Hook checks if tool requires approval
3. If approval needed, emits permission_request event and waits
4. User approves/denies via frontend
5. Hook returns allow/deny decision
6. SDK either executes tool or returns denial to agent
"""

import asyncio
import logging
import uuid
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from ainstein.tools.code import TOOLS_REQUIRING_APPROVAL as CODE_TOOLS_REQUIRING_APPROVAL
from ainstein.tools.uv_code import TOOLS_REQUIRING_APPROVAL as UV_TOOLS_REQUIRING_APPROVAL


# Combine all tools that require approval
TOOLS_REQUIRING_APPROVAL = CODE_TOOLS_REQUIRING_APPROVAL + UV_TOOLS_REQUIRING_APPROVAL


logger = logging.getLogger(__name__)


# SDK built-in tools that should be BLOCKED (use our MCP tools instead)
# These are dangerous because they have direct filesystem/shell access
BLOCKED_SDK_TOOLS = [
    "Bash",
    "Read",
    "Write",
    "Edit",
    "Glob",
    "Grep",
    "MultiEdit",
]


@dataclass
class HookContext:
    """Context passed to hook callbacks."""

    tool_use_id: str | None = None


@dataclass
class PermissionManager:
    """
    Manages permission requests and responses for human-in-the-loop approval.

    This replaces the old threading-based permission system with an async-friendly
    approach that integrates with the SDK's hook system.

    Thread-safety: The submit_response() method is called from Django's sync context
    (different thread) while the Future lives in the stream's async loop. We use
    loop.call_soon_threadsafe() to safely set the result across threads.
    """

    # Pending permission requests: request_id -> {"future": Future, "loop": EventLoop}
    pending_requests: dict[str, dict] = field(default_factory=dict)

    # Callback to emit SSE events to frontend
    emit_callback: Callable[[dict], None] | None = None

    # Callback to emit tool events to frontend (for all tools including built-in)
    tool_event_callback: Callable[[dict], None] | None = None

    async def request_permission(
        self,
        tool_name: str,
        tool_input: dict,
        timeout: float = 300.0,
    ) -> tuple[bool, str | None]:
        """
        Request user permission for a tool execution.

        Args:
            tool_name: Name of the tool requiring permission
            tool_input: The tool's input arguments
            timeout: Maximum time to wait for response (default 5 minutes)

        Returns:
            Tuple of (approved: bool, reason: str | None)
        """
        request_id = str(uuid.uuid4())

        # Create future for this request - store both future AND loop for thread-safe access
        loop = asyncio.get_running_loop()
        future = loop.create_future()
        self.pending_requests[request_id] = {"future": future, "loop": loop}

        # Build permission request message
        description = tool_input.get("description", f"Execute {tool_name}")

        # Emit permission request event if callback is set
        if self.emit_callback:
            self.emit_callback(
                {
                    "type": "permission_request",
                    "request_id": request_id,
                    "tool_name": tool_name,
                    "message": f"Tool '{tool_name}' requires your approval",
                    "action": description,
                    "tool_input": tool_input,
                }
            )

        logger.info(f"Permission requested for {tool_name}, request_id={request_id}")

        try:
            # Wait for user response with timeout
            approved, reason = await asyncio.wait_for(future, timeout=timeout)
            logger.info(f"Permission {request_id}: approved={approved}, reason={reason}")
            return approved, reason

        except TimeoutError:
            logger.warning(f"Permission request {request_id} timed out")
            return False, "Permission request timed out"

        finally:
            # Cleanup
            self.pending_requests.pop(request_id, None)

    def submit_response(self, request_id: str, approved: bool, reason: str | None = None) -> bool:
        """
        Submit user's permission response.

        Thread-safe: Uses loop.call_soon_threadsafe() to set the Future result
        from Django's sync context into the stream's async event loop.

        Args:
            request_id: The permission request ID
            approved: True if user approved, False if denied
            reason: Optional reason for denial

        Returns:
            True if request was found and response submitted
        """
        request_data = self.pending_requests.get(request_id)
        if not request_data:
            logger.warning(f"Permission request {request_id} not found")
            return False

        future = request_data["future"]
        loop = request_data["loop"]

        if not future.done():
            # Thread-safe: schedule set_result on the correct event loop
            loop.call_soon_threadsafe(future.set_result, (approved, reason))
            logger.info(f"Permission response submitted: {request_id} -> {approved}")
            return True

        return False

    def emit_tool_event(self, event_type: str, tool_name: str, tool_use_id: str | None, data: dict) -> None:
        """
        Emit a tool event to the frontend.

        Args:
            event_type: "tool_use_start" or "tool_use_end"
            tool_name: Name of the tool being used
            tool_use_id: Unique ID for this tool use
            data: Additional event data (input summary or result summary)
        """
        if self.tool_event_callback:
            self.tool_event_callback(
                {
                    "type": event_type,
                    "tool_name": tool_name,
                    "tool_use_id": tool_use_id,
                    **data,
                }
            )


# Global permission manager instance (set per-request in views.py)
permission_manager: PermissionManager | None = None


def set_permission_manager(manager: PermissionManager) -> None:
    """Set the global permission manager for the current request."""
    global permission_manager
    permission_manager = manager


def get_permission_manager() -> PermissionManager | None:
    """Get the current permission manager."""
    return permission_manager


def _hook_allow(reason: str = "") -> dict[str, Any]:
    """
    Return format for explicit ALLOW decision.

    Per SDK docs: https://code.claude.com/docs/en/hooks
    - "allow" bypasses the permission system
    - The reason displays to the user but not Claude
    """
    return {
        "hookSpecificOutput": {
            "hookEventName": "PreToolUse",
            "permissionDecision": "allow",
            "permissionDecisionReason": reason,
        }
    }


def _hook_deny(reason: str) -> dict[str, Any]:
    """
    Return format for DENY decision.

    Per SDK docs: https://code.claude.com/docs/en/hooks
    - "deny" prevents tool execution
    - The reason appears to Claude (so it can adjust behavior)
    """
    return {
        "hookSpecificOutput": {
            "hookEventName": "PreToolUse",
            "permissionDecision": "deny",
            "permissionDecisionReason": reason,
        }
    }


def _hook_continue() -> dict[str, Any]:
    """
    Return format for CONTINUE (proceed to rules evaluation).

    Per SDK docs: https://code.claude.com/docs/en/hooks
    - Empty dict means "continue" to next permission check
    - Used when hook has no opinion on this tool
    """
    return {}


async def pre_tool_permission_hook(
    input_data: dict[str, Any],
    tool_use_id: str | None,
    context: Any,
) -> dict[str, Any]:
    """
    PreToolUse hook that handles permission-based tool gating.

    This hook:
    1. BLOCKS dangerous SDK built-in tools (Bash, Read, Write, etc.)
    2. Checks if the tool requires permission
    3. If yes, requests user approval via SSE
    4. Waits for user response
    5. Returns allow/deny decision to SDK

    Return format (per SDK docs):
    - allow: {"hookSpecificOutput": {"permissionDecision": "allow", ...}}
    - deny: {"hookSpecificOutput": {"permissionDecision": "deny", ...}}
    - continue: {} (empty dict, proceed to rules evaluation)

    Args:
        input_data: Contains 'tool_name' and 'tool_input'
        tool_use_id: Unique ID for this tool use
        context: HookContext from SDK

    Returns:
        Hook decision dict per SDK specification
    """
    tool_name = input_data.get("tool_name", "")

    # BLOCK dangerous SDK built-in tools - these bypass our storage security
    if tool_name in BLOCKED_SDK_TOOLS:
        logger.warning(f"Blocked disallowed SDK tool: {tool_name}")
        deny_reason = f"Tool '{tool_name}' is not allowed. Use the storage_* or page_* tools instead."

        # Emit denied event so frontend shows proper state (not stuck on "Running")
        manager = get_permission_manager()
        if manager:
            manager.emit_tool_event(
                "tool_use_end",
                tool_name,
                tool_use_id,
                {"denied": True, "reason": deny_reason},
            )

        return _hook_deny(deny_reason)

    # Extract the actual tool name from MCP format (mcp__app__tool_name -> tool_name)
    if tool_name.startswith("mcp__app__"):
        tool_name = tool_name.replace("mcp__app__", "")

    # Check if this tool requires permission
    if tool_name not in TOOLS_REQUIRING_APPROVAL:
        # No opinion on this tool - continue to next check
        return _hook_continue()

    logger.info(f"Tool {tool_name} requires permission, requesting approval...")

    # Get the permission manager for this request
    manager = get_permission_manager()
    if not manager:
        logger.error("No permission manager available, denying by default")
        return _hook_deny("Permission system not available")

    # Request permission from user
    tool_input = input_data.get("tool_input", {})
    approved, reason = await manager.request_permission(tool_name, tool_input)

    if approved:
        logger.info(f"Tool {tool_name} approved by user")
        return _hook_allow("User approved")

    # User denied - emit denied event so frontend shows proper state
    deny_reason = reason or "User denied permission"
    manager.emit_tool_event(
        "tool_use_end",
        tool_name,
        tool_use_id,
        {"denied": True, "reason": deny_reason},
    )

    logger.info(f"Tool {tool_name} denied: {deny_reason}")
    return _hook_deny(deny_reason)


def summarize_tool_input(tool_input: dict) -> dict:
    """Create a summary of tool input, truncating long values."""
    input_summary = {}
    for key, value in tool_input.items():
        if isinstance(value, str) and len(value) > 100:
            input_summary[key] = f"{value[:100]}..."
        elif isinstance(value, (list, dict)) and len(str(value)) > 100:
            input_summary[key] = f"<{type(value).__name__} len={len(value)}>"
        else:
            input_summary[key] = value
    return input_summary


def normalize_tool_name(tool_name: str) -> str:
    """Extract actual tool name from MCP format."""
    if tool_name.startswith("mcp__app__"):
        return tool_name.replace("mcp__app__", "")
    return tool_name


async def pre_tool_logger(
    input_data: dict[str, Any],
    tool_use_id: str | None,
    context: Any,
) -> dict[str, Any]:
    """
    PreToolUse hook for logging and emitting tool invocation events.

    Logs tool name and summarized input before execution.
    Also emits SSE event for frontend to display tool usage.
    """
    raw_tool_name = input_data.get("tool_name", "unknown")
    tool_name = normalize_tool_name(raw_tool_name)
    tool_input = input_data.get("tool_input", {})

    # Create a summary of the input (truncate long values)
    input_summary = summarize_tool_input(tool_input)

    logger.info(f"[TOOL] {tool_name} <- {input_summary}")

    # Emit SSE event for frontend
    manager = get_permission_manager()
    if manager:
        manager.emit_tool_event(
            "tool_use_start",
            tool_name,
            tool_use_id,
            {"input": input_summary},
        )

    return {}


def format_tool_result(tool_name: str, tool_result: dict | str | None) -> tuple[bool, str]:
    """
    Format tool result with tool-specific formatting for better readability.

    Returns:
        Tuple of (is_error, formatted_summary)
    """
    if tool_result is None:
        return False, "<no result>"

    # Extract raw text from result
    raw_text = ""
    is_error = False

    if isinstance(tool_result, str):
        raw_text = tool_result
    elif isinstance(tool_result, dict):
        is_error = tool_result.get("is_error", False)
        content = tool_result.get("content")
        if content:
            if isinstance(content, str):
                raw_text = content
            elif isinstance(content, list) and len(content) > 0:
                first = content[0]
                if isinstance(first, dict):
                    raw_text = first.get("text", "") or first.get("content", "") or str(first)
                else:
                    raw_text = str(first)
            else:
                raw_text = str(content)
        else:
            for key in ("text", "output", "result", "message", "data"):
                if key in tool_result:
                    raw_text = str(tool_result[key])
                    break

    if not raw_text:
        return is_error, "<empty result>"

    # Tool-specific formatting
    tool_lower = tool_name.lower()

    if tool_lower == "grep":
        lines = raw_text.strip().split("\n")
        if len(lines) == 1 and ":" in lines[0]:
            # Single match - show file:line summary
            parts = lines[0].split(":", 2)
            if len(parts) >= 2:
                file_name = parts[0].split("\\")[-1].split("/")[-1]
                return is_error, f"{file_name}:{parts[1]}"
        return is_error, f"Found {len(lines)} matches"

    if tool_lower == "glob":
        lines = [line for line in raw_text.strip().split("\n") if line.strip()]
        return is_error, f"Found {len(lines)} files"

    if tool_lower == "read":
        lines = raw_text.split("\n")
        return is_error, f"Read {len(lines)} lines"

    if tool_lower in ("edit", "multiedit"):
        return is_error, "File edited"

    if tool_lower == "write":
        return is_error, f"Wrote {len(raw_text)} bytes"

    if tool_lower == "bash":
        # Show first non-empty line
        for line in raw_text.split("\n"):
            line = line.strip()
            if line:
                return is_error, line[:80] + "..." if len(line) > 80 else line
        return is_error, "Completed"

    if tool_lower == "task":
        # Agent task - show first line
        first_line = raw_text.split("\n")[0].strip()
        return is_error, first_line[:80] + "..." if len(first_line) > 80 else first_line

    # Default: truncate raw text
    return is_error, raw_text[:100] + "..." if len(raw_text) > 100 else raw_text


async def post_tool_logger(
    input_data: dict[str, Any],
    tool_use_id: str | None,
    context: Any,
) -> dict[str, Any]:
    """
    PostToolUse hook for logging and emitting tool completion events.

    Logs tool name and result summary after execution.
    Also emits SSE event for frontend to display tool result.
    """
    raw_tool_name = input_data.get("tool_name", "unknown")
    tool_name = normalize_tool_name(raw_tool_name)
    # SDK uses "tool_response" not "tool_result"
    tool_result = input_data.get("tool_response") or input_data.get("tool_result")

    # Format result with tool-specific formatting
    is_error, summary = format_tool_result(tool_name, tool_result)

    if is_error:
        logger.warning(f"[TOOL] {tool_name} -> ERROR: {summary}")
    else:
        logger.info(f"[TOOL] {tool_name} -> OK: {summary}")

    # Emit SSE event for frontend
    manager = get_permission_manager()
    if manager:
        manager.emit_tool_event(
            "tool_use_end",
            tool_name,
            tool_use_id,
            {"is_error": is_error, "summary": summary},
        )

    return {}


def create_hook_matchers() -> dict:
    """
    Create hook configuration for AinsteinOptions.

    Hooks are executed in order:
    - PreToolUse: pre_tool_logger (logs input), pre_tool_permission_hook (checks permissions)
    - PostToolUse: post_tool_logger (logs result)

    Returns:
        Dict mapping hook events to HookMatcher configurations
    """
    # Import here to avoid circular imports
    try:
        from claude_agent_sdk import HookMatcher  # noqa: PLC0415
    except ImportError:
        logger.warning("HookMatcher not available in SDK, using dict format")
        # Fallback to dict format if HookMatcher not available
        return {
            "PreToolUse": [
                {
                    "matcher": None,  # Match all tools
                    "hooks": [pre_tool_logger, pre_tool_permission_hook],
                    "timeout": 300,  # 5 minute timeout for permission
                }
            ],
            "PostToolUse": [
                {
                    "matcher": None,
                    "hooks": [post_tool_logger],
                    "timeout": 30,
                }
            ],
        }

    return {
        "PreToolUse": [
            HookMatcher(
                matcher=None,  # Match all tools
                hooks=[pre_tool_logger, pre_tool_permission_hook],
                timeout=300,  # 5 minute timeout for permission
            )
        ],
        "PostToolUse": [
            HookMatcher(
                matcher=None,
                hooks=[post_tool_logger],
                timeout=30,
            )
        ],
    }
