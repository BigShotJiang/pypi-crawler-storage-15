"""
Management command to test .page file block operations.

Usage:
    python manage.py test_page_prompt                    # Run all block operation tests
    python manage.py test_page_prompt --prompt "..."     # Run custom prompt
    python manage.py test_page_prompt --test create      # Run specific test
    python manage.py test_page_prompt --list             # List available tests
"""

import asyncio
import json
import uuid

import djclick as click
from django.contrib.auth import get_user_model
from django.core.files.storage import storages

from ainstein.models import AiProject
from ainstein.services import AinsteinService, EventType


# Test definitions: each test has a sequence of prompts and expected outcomes
# Note: verify functions receive (storage, project_folder) and must construct full paths
BLOCK_TESTS = {
    "create": {
        "name": "Create Initial Page",
        "description": "Create a .page file with multiple block types",
        "prompts": [
            "Create a page called 'test-doc' with a heading 'My Document', a paragraph 'This is the first paragraph.', and a bullet list with items: Apple, Banana, Cherry",
        ],
        "verify": lambda storage, folder: verify_blocks_exist(storage, f"{folder}/test-doc.page", min_blocks=5),
    },
    "append": {
        "name": "Append Block at End",
        "description": "Add a new block at the end of the file",
        "setup": "Create a page called 'append-test' with heading 'Test Doc' and paragraph 'First paragraph'",
        "prompts": [
            "Add a new paragraph at the end of 'append-test.page' with text 'This was appended at the end'",
        ],
        "verify": lambda storage, folder: verify_last_block_contains(
            storage, f"{folder}/append-test.page", "appended at the end"
        ),
    },
    "prepend": {
        "name": "Insert Block at Top",
        "description": "Add a new block at the beginning of the file",
        "setup": "Create a page called 'prepend-test' with paragraph 'Original first paragraph'",
        "prompts": [
            "Insert a heading 'NEW TITLE' at the very beginning of 'prepend-test.page' (before all existing content)",
        ],
        "verify": lambda storage, folder: verify_first_block_contains(
            storage, f"{folder}/prepend-test.page", "NEW TITLE"
        ),
    },
    "insert_after": {
        "name": "Insert After Specific Block",
        "description": "Insert a block after a specific existing block",
        "setup": "Create a page called 'insert-test' with: heading 'Title', paragraph 'Para 1', paragraph 'Para 2', paragraph 'Para 3'",
        "prompts": [
            "Read 'insert-test.page' to see the block IDs",
            "Insert a new paragraph 'INSERTED PARAGRAPH' after the block containing 'Para 1' in 'insert-test.page'",
        ],
        "verify": lambda storage, folder: verify_block_order(
            storage, f"{folder}/insert-test.page", ["Para 1", "INSERTED"]
        ),
    },
    "update_text": {
        "name": "Update Block Text",
        "description": "Replace text in an existing block",
        "setup": "Create a page called 'update-test' with paragraph 'The quick brown fox jumps over the lazy dog'",
        "prompts": [
            "Read 'update-test.page' to get the block ID",
            "Replace the text in the paragraph block of 'update-test.page' with 'The slow red cat walks under the active dog'",
        ],
        "verify": lambda storage, folder: verify_block_contains(storage, f"{folder}/update-test.page", "slow red cat"),
    },
    "delete_block": {
        "name": "Delete Block",
        "description": "Remove a specific block from the file",
        "setup": "Create a page called 'delete-test' with: paragraph 'Keep this', paragraph 'DELETE ME', paragraph 'Keep this too'",
        "prompts": [
            "Read 'delete-test.page' to see the blocks",
            "Delete the block containing 'DELETE ME' from 'delete-test.page'",
        ],
        "verify": lambda storage, folder: verify_block_not_contains(storage, f"{folder}/delete-test.page", "DELETE ME"),
    },
    "move_block": {
        "name": "Move Block",
        "description": "Move a block from one position to another",
        "setup": "Create a page called 'move-test' with: paragraph 'First', paragraph 'Second', paragraph 'Third'",
        "prompts": [
            "Read 'move-test.page' to see the block IDs",
            "Move the block containing 'Third' to be the first block in 'move-test.page'",
        ],
        "verify": lambda storage, folder: verify_first_block_contains(storage, f"{folder}/move-test.page", "Third"),
    },
    "complex": {
        "name": "Complex Multi-Operation",
        "description": "Perform multiple operations in sequence",
        "prompts": [
            "Create a page called 'complex-test' with heading 'Shopping List'",
            "Add bullet items to 'complex-test.page': Milk, Eggs, Bread",
            "Add a heading 'Notes' at the end of 'complex-test.page'",
            "Add a paragraph 'Remember to check expiry dates' after the 'Notes' heading",
        ],
        "verify": lambda storage, folder: verify_blocks_exist(storage, f"{folder}/complex-test.page", min_blocks=6),
    },
    "table": {
        "name": "Create Table Block",
        "description": "Create a .page file with a properly formatted table block",
        "prompts": [
            "Create a page called 'table-test' with a heading 'Product Comparison' and a table with 3 columns (Product, Price, Rating) and 3 data rows: (iPhone, $999, 4.5), (Pixel, $899, 4.3), (Galaxy, $949, 4.4)",
        ],
        "verify": lambda storage, folder: verify_table_block(storage, f"{folder}/table-test.page"),
    },
}


def get_storage():
    """Get the agent storage backend."""
    return storages["agent"]


def read_page_blocks(storage, path):
    """Read and parse blocks from a .page file."""
    if not storage.exists(path):
        return None
    with storage.open(path, 'rb') as f:
        content = f.read().decode('utf-8')
    try:
        return json.loads(content)
    except json.JSONDecodeError:
        return None


def get_block_text(block):
    """Extract text content from a block."""
    content = block.get("content")
    if not content:
        return ""

    # Handle table blocks (content is a tableContent object, not an array)
    if block.get("type") == "table" and isinstance(content, dict):
        rows = content.get("rows", [])
        if rows and rows[0].get("cells"):
            # Get first row's first cell text
            first_cell = rows[0]["cells"][0] if rows[0]["cells"] else []
            if first_cell and isinstance(first_cell, list) and first_cell:
                first_item = first_cell[0]
                if isinstance(first_item, dict):
                    return f"[table: {first_item.get('text', '')}...]"
        return "[table]"

    # Handle regular blocks (content is an array of inline content)
    if not isinstance(content, list):
        return ""

    texts = []
    for item in content:
        if isinstance(item, dict) and item.get("type") == "text":
            texts.append(item.get("text", ""))
    return " ".join(texts)


def verify_blocks_exist(storage, path, min_blocks=1):
    """Verify that the file exists and has at least min_blocks blocks."""
    blocks = read_page_blocks(storage, path)
    if blocks is None:
        return False, f"File not found or invalid JSON: {path}"
    if len(blocks) < min_blocks:
        return False, f"Expected at least {min_blocks} blocks, got {len(blocks)}"
    return True, f"Found {len(blocks)} blocks"


def verify_block_contains(storage, path, text):
    """Verify that any block contains the specified text."""
    blocks = read_page_blocks(storage, path)
    if blocks is None:
        return False, f"File not found: {path}"
    for block in blocks:
        if text.lower() in get_block_text(block).lower():
            return True, f"Found text '{text}' in block"
    return False, f"Text '{text}' not found in any block"


def verify_block_not_contains(storage, path, text):
    """Verify that no block contains the specified text."""
    blocks = read_page_blocks(storage, path)
    if blocks is None:
        return False, f"File not found: {path}"
    for block in blocks:
        if text.lower() in get_block_text(block).lower():
            return False, f"Text '{text}' still exists in block"
    return True, f"Text '{text}' successfully removed"


def verify_first_block_contains(storage, path, text):
    """Verify that the first block contains the specified text."""
    blocks = read_page_blocks(storage, path)
    if blocks is None:
        return False, f"File not found: {path}"
    if not blocks:
        return False, "No blocks in file"
    first_text = get_block_text(blocks[0])
    if text.lower() in first_text.lower():
        return True, f"First block contains '{text}'"
    return False, f"First block is '{first_text}', expected '{text}'"


def verify_last_block_contains(storage, path, text):
    """Verify that the last block contains the specified text."""
    blocks = read_page_blocks(storage, path)
    if blocks is None:
        return False, f"File not found: {path}"
    if not blocks:
        return False, "No blocks in file"
    last_text = get_block_text(blocks[-1])
    if text.lower() in last_text.lower():
        return True, f"Last block contains '{text}'"
    return False, f"Last block is '{last_text}', expected '{text}'"


def verify_block_order(storage, path, texts_in_order):
    """Verify that blocks appear in the specified order."""
    blocks = read_page_blocks(storage, path)
    if blocks is None:
        return False, f"File not found: {path}"

    block_texts = [get_block_text(b).lower() for b in blocks]
    last_idx = -1

    for text in texts_in_order:
        found = False
        for i, bt in enumerate(block_texts):
            if text.lower() in bt and i > last_idx:
                last_idx = i
                found = True
                break
        if not found:
            return False, f"Text '{text}' not found in expected order"

    return True, f"Blocks appear in correct order: {texts_in_order}"


def verify_table_block(storage, path):
    """Verify that a valid table block exists in the file."""
    blocks = read_page_blocks(storage, path)
    if blocks is None:
        return False, f"File not found: {path}"
    if not isinstance(blocks, list):
        return False, f"Expected list of blocks, got {type(blocks).__name__}"

    for block in blocks:
        if not isinstance(block, dict):
            continue
        if block.get("type") == "table":
            content = block.get("content")
            if not content:
                return False, "Table block has no content"
            if content.get("type") != "tableContent":
                return False, f"Table content type is '{content.get('type')}', expected 'tableContent'"
            rows = content.get("rows")
            if not rows or not isinstance(rows, list):
                return False, "Table has no rows or rows is not a list"
            if len(rows) < 2:
                return False, f"Table has only {len(rows)} row(s), expected at least 2 (header + data)"
            # Check first row has cells
            first_row = rows[0]
            if not first_row.get("cells") or not isinstance(first_row["cells"], list):
                return False, "First row has no cells array"
            # Check cells are arrays of inline content
            for i, cell in enumerate(first_row["cells"]):
                if not isinstance(cell, list):
                    return False, f"Cell {i} is not an array (got {type(cell).__name__})"
            return True, f"Valid table with {len(rows)} rows and {len(first_row['cells'])} columns"

    return False, "No table block found in file"


def truncate_for_display(value, max_len=80):
    """Truncate a value for display purposes."""
    if isinstance(value, str):
        value = value.replace('\n', ' ').replace('\r', '')
        if len(value) > max_len:
            return value[:max_len] + "..."
        return value
    return str(value)


async def run_prompt(service, prompt, verbose=True):
    """Run a single prompt and collect results."""
    tool_calls = []
    text_output = []

    async for event in service.chat(prompt):
        if event.type == EventType.TOOL_START:
            tool_name = event.data.get("tool", "Unknown")
            args_summary = event.data.get("args_summary", "")
            full_args = event.data.get("args", {})
            tool_calls.append({"tool": tool_name, "args": full_args or args_summary})

            if verbose:
                click.secho("    [TOOL] ", fg="magenta", nl=False)
                click.secho(tool_name, fg="magenta", bold=True, nl=False)
                click.echo(f"({args_summary})")

                # Show full args for transparency
                if full_args:
                    for key, value in full_args.items():
                        display_value = truncate_for_display(value)
                        click.secho(f"           {key}: ", fg="blue", nl=False)
                        click.echo(display_value)

        elif event.type == EventType.TOOL_RESULT:
            summary = event.data.get("summary", "")
            if verbose:
                click.secho("    [RESULT] ", fg="cyan", nl=False)
                click.echo(summary)

        elif event.type == EventType.TOOL_ERROR:
            error = event.data.get("error", "")
            tool_name = event.data.get("tool", "")
            if verbose:
                click.secho("    [ERROR] ", fg="red", nl=False)
                click.echo(f"{tool_name}: {error}")

        elif event.type == EventType.AGENT_TEXT:
            text = event.data.get("text", "")
            if text:
                text_output.append(text)
                if verbose:
                    click.echo(text, nl=False)

    if verbose and text_output:
        click.echo()

    return tool_calls, "".join(text_output)


async def run_test(test_key, test_config, project_folder, storage, verbose=True):
    """Run a single test with setup, prompts, and verification."""
    click.secho(f"\n{'─' * 60}", fg="blue")
    click.secho(f"Test: {test_config['name']}", fg="blue", bold=True)
    click.secho(f"Description: {test_config['description']}", fg="blue")
    click.secho(f"{'─' * 60}", fg="blue")

    async with AinsteinService(
        project_folder=project_folder,
        output_mode="stream",
    ) as service:
        # Run setup if present
        if "setup" in test_config:
            click.secho("\n  [SETUP]", fg="yellow", bold=True)
            click.echo(f"  {test_config['setup']}")
            await run_prompt(service, test_config["setup"], verbose=verbose)

        # Run test prompts
        for i, prompt in enumerate(test_config["prompts"], 1):
            click.secho(f"\n  [STEP {i}]", fg="yellow", bold=True)
            click.echo(f"  {prompt}")
            await run_prompt(service, prompt, verbose=verbose)

    # Run verification
    click.secho("\n  [VERIFY]", fg="yellow", bold=True)
    if "verify" in test_config:
        success, message = test_config["verify"](storage, project_folder)
        if success:
            click.secho(f"  ✓ PASS: {message}", fg="green", bold=True)
        else:
            click.secho(f"  ✗ FAIL: {message}", fg="red", bold=True)
        return success

    click.secho("  ⚠ No verification defined", fg="yellow")
    return True


def list_page_files(storage, project_folder):
    """List all .page files in the project folder."""
    try:
        _, files = storage.listdir(project_folder)
        return [f for f in files if f.endswith('.page')]
    except Exception:
        return []


def show_page_contents(storage, project_folder):
    """Show contents of all .page files."""
    page_files = list_page_files(storage, project_folder)
    if not page_files:
        click.secho("No .page files found", fg="yellow")
        return

    for filename in page_files:
        path = f"{project_folder}/{filename}"
        blocks = read_page_blocks(storage, path)
        click.secho(f"\n📄 {filename}", fg="cyan", bold=True)
        if blocks and isinstance(blocks, list):
            for i, block in enumerate(blocks):
                if not isinstance(block, dict):
                    click.echo(f"  [{i}] (invalid block)")
                    continue
                block_type = block.get("type", "?")
                block_id = block.get("id", "?")
                text = get_block_text(block)[:60]
                click.echo(f"  [{i}] {block_type} (id={block_id}): {text}...")
        else:
            click.secho("  (empty or invalid)", fg="yellow")


@click.command()
@click.option("--prompt", "-p", default=None, help="Custom prompt to send to the agent")
@click.option("--test", "-t", default=None, help="Run specific test (use --list to see available)")
@click.option("--list", "-l", "list_tests", is_flag=True, help="List available tests")
@click.option("--all", "-a", "run_all", is_flag=True, help="Run all tests")
@click.option("--project-id", "-i", type=int, default=None, help="Project ID to use")
@click.option("--keep", "-k", is_flag=True, help="Keep temp project after test (don't delete)")
@click.option("--verbose", is_flag=True, default=True, help="Show detailed output")
@click.option("--show", "-s", is_flag=True, help="Show .page file contents after test")
def command(prompt, test, list_tests, run_all, project_id, keep, verbose, show):
    """Test .page file block operations."""

    # List available tests
    if list_tests:
        click.secho("\nAvailable Tests:", fg="cyan", bold=True)
        click.secho("=" * 50, fg="cyan")
        for key, config in BLOCK_TESTS.items():
            click.secho(f"\n  {key}", fg="green", bold=True)
            click.echo(f"    {config['name']}")
            click.echo(f"    {config['description']}")
        click.echo()
        return

    click.secho(f"\n{'=' * 60}", fg="cyan")
    click.secho("Testing .page File Block Operations", fg="cyan", bold=True)
    click.secho(f"{'=' * 60}", fg="cyan")

    # Get or create project
    if project_id:
        project = AiProject.objects.get(id=project_id)
        click.secho(f"Using project: {project.name} (ID: {project.id})", fg="blue")
        created_project = False
    else:
        User = get_user_model()
        user = User.objects.filter(is_staff=True).first()
        if not user:
            click.secho("Error: No staff user found to create test project", fg="red")
            return

        unique_id = uuid.uuid4().hex[:8]
        project = AiProject.objects.create(
            user=user,
            name=f"Test Page Blocks {unique_id}",
            slug=f"test-page-blocks-{unique_id}",
        )
        click.secho(f"Created temp project: {project.name} (ID: {project.id})", fg="blue")
        created_project = True

    project_folder = project.folder_path
    storage = get_storage()

    # Custom prompt mode
    if prompt:

        async def run_custom():
            click.secho(f"\nPrompt: {prompt}", fg="yellow")
            click.secho("-" * 40, fg="green")

            async with AinsteinService(
                project_folder=project_folder,
                output_mode="stream",
            ) as service:
                await run_prompt(service, prompt, verbose=True)

        asyncio.run(run_custom())

    # Run specific test
    elif test:
        if test not in BLOCK_TESTS:
            click.secho(f"Unknown test: {test}", fg="red")
            click.echo(f"Available: {', '.join(BLOCK_TESTS.keys())}")
            return

        asyncio.run(run_test(test, BLOCK_TESTS[test], project_folder, storage, verbose))

    # Run all tests
    elif run_all:
        results = {}
        for test_key, test_config in BLOCK_TESTS.items():
            results[test_key] = asyncio.run(run_test(test_key, test_config, project_folder, storage, verbose))

        # Summary
        click.secho(f"\n{'=' * 60}", fg="cyan")
        click.secho("Test Summary", fg="cyan", bold=True)
        click.secho(f"{'=' * 60}", fg="cyan")

        passed = sum(1 for r in results.values() if r)
        failed = len(results) - passed

        for test_key, success in results.items():
            status = "✓ PASS" if success else "✗ FAIL"
            color = "green" if success else "red"
            click.secho(f"  {status}: {BLOCK_TESTS[test_key]['name']}", fg=color)

        click.echo()
        click.secho(f"Results: {passed} passed, {failed} failed", fg="green" if failed == 0 else "red", bold=True)

    else:
        # Default: run create test
        asyncio.run(run_test("create", BLOCK_TESTS["create"], project_folder, storage, verbose))

    # Show .page file contents
    if show:
        click.secho(f"\n{'=' * 60}", fg="cyan")
        click.secho("Page File Contents", fg="cyan", bold=True)
        click.secho(f"{'=' * 60}", fg="cyan")
        show_page_contents(storage, project_folder)

    # Clean up
    if created_project and not keep:
        project.delete()
        click.secho("\nCleaned up temp project", fg="blue")
    elif keep:
        click.secho(f"\nKept project: {project.name} (ID: {project.id})", fg="blue")
