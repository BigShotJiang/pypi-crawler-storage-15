"""
Test UV Code Execution tool with OpenRouter API.

Usage:
    python manage.py test_uv_code
    python manage.py test_uv_code --prompt "Tell me a joke"
"""

import asyncio

import djclick as click

from ainstein.tools.base import ToolContext
from ainstein.tools.uv_code import create_uv_code_tools


CODE = '''# /// script
# dependencies = ["openrouter"]
# ///
import os
from openrouter import OpenRouter

with OpenRouter(api_key=os.environ["OPENROUTER_API_KEY"]) as client:
    resp = client.chat.send(
        model="openai/gpt-4o-mini",
        messages=[{{"role": "user", "content": "{prompt}"}}],
    )
    data = dict(resp)

    for choice in data.get("choices", []):
        print(choice.message.content)

    if usage := data.get("usage"):
        print()
        print(f"Tokens: {{int(usage.prompt_tokens)}} + {{int(usage.completion_tokens)}} = {{int(usage.total_tokens)}}")
'''


class MockService:
    def emit(self, event):
        pass


class MockStorage:
    pass


@click.command()
@click.option("--prompt", "-p", default="Give me a pun about programming")
def command(prompt):
    """Test uv_execute_code with OpenRouter API."""
    click.secho(f"\nPrompt: {prompt}\n", fg="cyan")

    ctx = ToolContext(
        service=MockService(),
        storage=MockStorage(),
        project_folder="",
        max_limit=1000,
        file_mtimes={},
        is_cancelled=lambda: False,
    )

    tools = create_uv_code_tools(ctx)
    tool = next(t for t in tools if t.name == "uv_execute_code")

    result = asyncio.run(
        tool.handler(
            {
                "code": CODE.format(prompt=prompt),
                "description": "OpenRouter test",
            }
        )
    )

    for content in result.get("content", []):
        if content.get("type") == "text":
            click.echo(content.get("text", ""))
