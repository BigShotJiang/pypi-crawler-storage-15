"""
Test Claude Agent API endpoints.

Usage:
    python manage.py test_ainstein_api
    python manage.py test_ainstein_api --username admin
    python manage.py test_ainstein_api --skip-stream
"""

from decimal import Decimal

import djclick as click
from django.contrib.auth import get_user_model

from ainstein.models import AiConversation, AiConversationMessage
from ainstein.views import stream_events_sync


User = get_user_model()


def success(msg):
    click.secho(f"  ✓ {msg}", fg="green")


def error(msg):
    click.secho(f"  ✗ {msg}", fg="red")


def info(msg):
    click.secho(f"  → {msg}", fg="cyan")


@click.command()
@click.option("--username", default=None, help="Username to use for tests (default: first staff user)")
@click.option("--skip-stream", is_flag=True, help="Skip the streaming endpoint test")
@click.option("--cleanup", is_flag=True, help="Delete test conversation after tests")
def command(username, skip_stream, cleanup):
    """Test Claude Agent API endpoints."""
    click.secho("\n=== Claude Agent API Tests ===\n", fg="white", bold=True)

    # Get test user
    if username:
        try:
            user = User.objects.get(username=username)
        except User.DoesNotExist:
            error(f"User '{username}' not found")
            return
    else:
        user = User.objects.filter(is_staff=True).first()
        if not user:
            error("No staff user found. Create one or specify --username")
            return

    info(f"Using user: {user.username}")

    results = {"passed": 0, "failed": 0}
    test_conversation_id = None

    # =========================================================================
    # Test 1: Create Conversation
    # =========================================================================
    click.secho("\n1. Testing conversation creation...", fg="yellow")
    try:
        conversation = AiConversation.objects.create(
            user=user,
            title="Test Conversation",
        )
        test_conversation_id = conversation.id
        success(f"Created conversation id={conversation.id}")
        results["passed"] += 1
    except Exception as e:
        error(f"Failed to create conversation: {e}")
        results["failed"] += 1
        return

    # =========================================================================
    # Test 2: Add User Message
    # =========================================================================
    click.secho("\n2. Testing add_message (user)...", fg="yellow")
    try:
        msg = conversation.add_message("user", "Hello, this is a test message")
        assert msg is not None, "Message should be returned"
        assert msg.role == "user", "Role should be 'user'"
        assert msg.content == "Hello, this is a test message", "Content mismatch"
        assert conversation.message_count == 1, f"Expected 1 message, got {conversation.message_count}"
        success(f"Added user message id={msg.id}")
        results["passed"] += 1
    except Exception as e:
        error(f"Failed to add user message: {e}")
        results["failed"] += 1

    # =========================================================================
    # Test 3: Add Assistant Message with Metadata
    # =========================================================================
    click.secho("\n3. Testing add_message (assistant with metadata)...", fg="yellow")
    try:
        metadata = {"events": ['{"type": "agent_text", "text": "Test response"}']}
        msg = conversation.add_message("assistant", "Test response from assistant", metadata)
        assert msg is not None, "Message should be returned"
        assert msg.role == "assistant", "Role should be 'assistant'"
        assert msg.metadata == metadata, "Metadata mismatch"
        assert conversation.message_count == 2, f"Expected 2 messages, got {conversation.message_count}"
        success(f"Added assistant message id={msg.id} with metadata")
        results["passed"] += 1
    except Exception as e:
        error(f"Failed to add assistant message: {e}")
        results["failed"] += 1

    # =========================================================================
    # Test 4: Title Generation
    # =========================================================================
    click.secho("\n4. Testing title generation...", fg="yellow")
    try:
        conv2 = AiConversation.objects.create(user=user)
        assert conv2.title == "", "Title should be empty initially"
        conv2.add_message("user", "What is the meaning of life?")
        conv2.refresh_from_db()
        assert conv2.title != "", "Title should be generated from first user message"
        success(f"Title generated: '{conv2.title}'")
        conv2.delete()
        results["passed"] += 1
    except Exception as e:
        error(f"Failed title generation test: {e}")
        results["failed"] += 1

    # =========================================================================
    # Test 5: Get Messages List
    # =========================================================================
    click.secho("\n5. Testing get_messages_list...", fg="yellow")
    try:
        messages = conversation.get_messages_list()
        assert len(messages) == 2, f"Expected 2 messages, got {len(messages)}"
        assert messages[0]["role"] == "user", "First message should be user"
        assert messages[1]["role"] == "assistant", "Second message should be assistant"
        assert "id" in messages[0], "Message should have id"
        assert "created" in messages[0], "Message should have created timestamp"
        success(f"Retrieved {len(messages)} messages with correct structure")
        results["passed"] += 1
    except Exception as e:
        error(f"Failed get_messages_list test: {e}")
        results["failed"] += 1

    # =========================================================================
    # Test 6: Session ID Update
    # =========================================================================
    click.secho("\n6. Testing session_id update...", fg="yellow")
    try:
        assert conversation.session_id is None, "Session ID should be None initially"
        conversation.session_id = "test_session_123"
        conversation.save(update_fields=["session_id"])
        conversation.refresh_from_db()
        assert conversation.session_id == "test_session_123", "Session ID not saved"
        success(f"Session ID updated: {conversation.session_id}")
        results["passed"] += 1
    except Exception as e:
        error(f"Failed session_id test: {e}")
        results["failed"] += 1

    # =========================================================================
    # Test 7: Cost Update
    # =========================================================================
    click.secho("\n7. Testing cost update...", fg="yellow")
    try:
        initial_cost = conversation.total_cost_usd
        conversation.add_cost(0.0123, input_tokens=100, output_tokens=50)
        assert conversation.total_cost_usd == initial_cost + Decimal("0.0123"), "Cost not updated correctly"
        assert conversation.total_input_tokens == 100, "Input tokens not updated"
        assert conversation.total_output_tokens == 50, "Output tokens not updated"
        success(
            f"Cost updated: ${conversation.total_cost_usd} ({conversation.total_input_tokens}/{conversation.total_output_tokens} tokens)"
        )
        results["passed"] += 1
    except Exception as e:
        error(f"Failed cost update test: {e}")
        results["failed"] += 1

    # =========================================================================
    # Test 8: Message Ordering
    # =========================================================================
    click.secho("\n8. Testing message ordering...", fg="yellow")
    try:
        # Add more messages
        conversation.add_message("user", "Second user message")
        conversation.add_message("assistant", "Second assistant response")

        messages = list(conversation.messages.all())
        assert len(messages) == 4, f"Expected 4 messages, got {len(messages)}"

        # Check ordering by created timestamp
        for i in range(len(messages) - 1):
            assert messages[i].created <= messages[i + 1].created, "Messages not ordered by created"

        success("Messages correctly ordered (4 total)")
        results["passed"] += 1
    except Exception as e:
        error(f"Failed message ordering test: {e}")
        results["failed"] += 1

    # =========================================================================
    # Test 9: Conversation Queryset
    # =========================================================================
    click.secho("\n9. Testing conversation queryset...", fg="yellow")
    try:
        user_conversations = AiConversation.objects.filter(user=user)
        assert user_conversations.exists(), "User should have conversations"

        # Test ordering (most recent first)
        convs = list(user_conversations)
        for i in range(len(convs) - 1):
            assert convs[i].modified >= convs[i + 1].modified, "Conversations not ordered by modified desc"

        success(f"User has {user_conversations.count()} conversations, correctly ordered")
        results["passed"] += 1
    except Exception as e:
        error(f"Failed conversation queryset test: {e}")
        results["failed"] += 1

    # =========================================================================
    # Test 10: Cascade Delete
    # =========================================================================
    click.secho("\n10. Testing cascade delete...", fg="yellow")
    try:
        # Create a conversation with messages
        conv_to_delete = AiConversation.objects.create(user=user, title="To Delete")
        conv_to_delete.add_message("user", "Message 1")
        conv_to_delete.add_message("assistant", "Response 1")
        msg_ids = list(conv_to_delete.messages.values_list("id", flat=True))

        # Delete conversation
        conv_to_delete.delete()

        # Verify messages were deleted
        remaining = AiConversationMessage.objects.filter(id__in=msg_ids).count()
        assert remaining == 0, f"Expected 0 messages after cascade delete, got {remaining}"

        success("Messages cascade deleted with conversation")
        results["passed"] += 1
    except Exception as e:
        error(f"Failed cascade delete test: {e}")
        results["failed"] += 1

    # =========================================================================
    # Test 11: Stream Function (if not skipped)
    # =========================================================================
    if not skip_stream:
        click.secho("\n11. Testing stream_events_sync (basic)...", fg="yellow")
        try:
            # Just test that the function exists and can be called
            # We won't actually run the full stream as it requires Claude API
            assert callable(stream_events_sync), "stream_events_sync should be callable"
            success("stream_events_sync function is available")
            results["passed"] += 1
        except Exception as e:
            error(f"Failed stream test: {e}")
            results["failed"] += 1
    else:
        info("Skipping stream endpoint test (--skip-stream)")

    # =========================================================================
    # Cleanup
    # =========================================================================
    if cleanup and test_conversation_id:
        click.secho("\n12. Cleaning up test data...", fg="yellow")
        try:
            AiConversation.objects.filter(id=test_conversation_id).delete()
            success("Test conversation deleted")
        except Exception as e:
            error(f"Failed cleanup: {e}")

    # =========================================================================
    # Summary
    # =========================================================================
    click.secho("\n" + "=" * 40, fg="white")
    click.secho(f"Tests passed: {results['passed']}", fg="green", bold=True)
    click.secho(f"Tests failed: {results['failed']}", fg="red" if results["failed"] > 0 else "white", bold=True)
    click.secho("=" * 40 + "\n", fg="white")

    if results["failed"] > 0:
        raise SystemExit(1)
