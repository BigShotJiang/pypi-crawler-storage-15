"""
Test that LLM agent generates code using OpenRouter with correct model IDs.

Usage:
    python manage.py test_code_generation
    python manage.py test_code_generation --dry-run
"""

import asyncio

import djclick as click

from ainstein.events import EventType
from ainstein.services import AinsteinService


USER_PROMPT = "Write python code to ask gpt-5 what is 2+2"

EXPECTED_PATTERNS = [
    "openrouter",
    "# /// script",
    "dependencies",
]


def success(msg):
    click.secho(f"  ✓ {msg}", fg="green")


def error(msg):
    click.secho(f"  ✗ {msg}", fg="red")


def info(msg):
    click.secho(f"  → {msg}", fg="cyan")


@click.command()
@click.option("--dry-run", is_flag=True, help="Show expected output without calling the agent")
def command(dry_run):
    """Test that code generation uses OpenRouter with correct model IDs."""
    click.secho("\n=== Code Generation Test ===\n", fg="white", bold=True)

    click.secho(f"User: {USER_PROMPT}\n", fg="cyan")

    if dry_run:
        click.secho("Expected patterns in generated code:", fg="yellow")
        for pattern in EXPECTED_PATTERNS:
            click.echo(f"  - {pattern}")

        click.secho("\nThe agent should generate code like:", fg="yellow")
        click.echo('''
# /// script
# dependencies = ["openrouter"]
# ///
import os
from openrouter import OpenRouter

with OpenRouter(api_key=os.environ["OPENROUTER_API_KEY"]) as client:
    resp = client.chat.send(
        model="openai/gpt-4o",
        messages=[{"role": "user", "content": "what is 2+2"}],
    )
    ...
''')
        return

    # Run the agent in events mode to capture output
    info("Calling agent...")

    service = AinsteinService(output_mode="events")
    response_text = ""

    async def run():
        nonlocal response_text
        async for event in service.chat(USER_PROMPT):
            if event.type == EventType.AGENT_TEXT:
                response_text += event.data.get("text", "")

    asyncio.run(run())

    click.secho("\n" + "=" * 60, fg="white")
    click.secho("Generated Response:", fg="yellow")
    click.secho("=" * 60, fg="white")
    click.echo(response_text)

    click.secho("\n" + "=" * 60, fg="white")
    click.secho("Checking patterns:", fg="yellow")

    # Check for expected patterns
    all_passed = True
    for pattern in EXPECTED_PATTERNS:
        if pattern.lower() in response_text.lower():
            success(f"Found: {pattern}")
        else:
            error(f"Missing: {pattern}")
            all_passed = False

    click.secho("\n" + "=" * 60, fg="white")
    if all_passed:
        click.secho("✓ All patterns found!", fg="green", bold=True)
    else:
        click.secho("✗ Some patterns missing", fg="red", bold=True)
