"""
Test Remote Code Execution with file uploads.

Tests the remote_code_with_files tool by uploading files from an AiConversation's
project storage to Anthropic's sandboxed execution environment.

Usage:
    python manage.py test_remote_code --conversation-id 94
    python manage.py test_remote_code --conversation-id 94 --list-files
    python manage.py test_remote_code --conversation-id 94 --file latest_show.json --code "import json; data = json.load(open('latest_show.json')); print(len(data))"
"""

import asyncio
import traceback

import djclick as click
from django.contrib.auth import get_user_model
from django.core.files.storage import storages

from ainstein.models import AiConversation
from ainstein.tools.base import ToolContext
from ainstein.tools.remote_code import create_remote_code_tools


User = get_user_model()


def success(msg):
    click.secho(f"  ✓ {msg}", fg="green")


def error(msg):
    click.secho(f"  ✗ {msg}", fg="red")


def info(msg):
    click.secho(f"  → {msg}", fg="cyan")


def warning(msg):
    click.secho(f"  ~ {msg}", fg="yellow")


class MockService:
    """Mock service that captures emitted events."""

    def __init__(self):
        self.events = []

    def emit(self, event):
        self.events.append(event)
        # Print tool events for visibility
        if hasattr(event, "event_type"):
            info(f"Event: {event.event_type.value} - {event.data}")


def list_project_files(storage, project_folder: str) -> list[str]:
    """Recursively list all files in a project folder."""
    files = []

    def walk_dir(path: str):
        try:
            dirs, filenames = storage.listdir(path)
            for filename in filenames:
                files.append(f"{path}/{filename}")
            for dirname in dirs:
                walk_dir(f"{path}/{dirname}")
        except FileNotFoundError:
            pass

    walk_dir(project_folder)
    return files


@click.command()
@click.option("--conversation-id", "-c", type=int, required=True, help="AiConversation ID to test with")
@click.option("--list-files", "-l", is_flag=True, help="List files in project storage")
@click.option("--file", "-f", "file_paths", multiple=True, help="File path(s) to upload (relative to project)")
@click.option("--code", type=str, help="Python code to execute")
@click.option("--script", "-s", type=str, help="Script file to execute (relative to project)")
@click.option("--data", "-d", type=str, help="Data file to load (relative to project)")
def command(conversation_id, list_files, file_paths, code, script, data):
    """Test remote code execution with files from AiConversation project."""
    click.secho("\n=== Remote Code Execution Test ===\n", fg="white", bold=True)

    # Get conversation
    try:
        conversation = AiConversation.objects.select_related("project").get(id=conversation_id)
        success(f"Found conversation: {conversation}")
    except AiConversation.DoesNotExist:
        error(f"Conversation #{conversation_id} not found")
        return

    # Check project
    if not conversation.project:
        error("Conversation has no project assigned")
        return

    project = conversation.project
    info(f"Project: {project.name} (folder: {project.folder_path})")

    # Get storage
    storage = storages["agent"]

    # List files if requested
    if list_files:
        click.secho("\nFiles in project storage:", fg="yellow")
        files = list_project_files(storage, project.folder_path)
        if files:
            for f in files:
                # Show relative path from project folder
                rel_path = f.replace(f"{project.folder_path}/", "")
                size = storage.size(f) if storage.exists(f) else 0
                click.echo(f"    {rel_path} ({size:,} bytes)")
        else:
            warning("No files found in project storage")
        return

    # Build file list
    files_to_upload = list(file_paths)

    # Add script and data files if specified
    if script:
        files_to_upload.append(script)
    if data:
        files_to_upload.append(data)

    # If no code provided but script is, read script content
    if not code and script:
        script_path = f"{project.folder_path}/{script}"
        if storage.exists(script_path):
            with storage.open(script_path, "rb") as f:
                code = f.read().decode("utf-8")
            info(f"Loaded script from: {script}")
        else:
            error(f"Script not found: {script}")
            return

    if not code:
        error("No code provided. Use --code or --script")
        click.echo("\nExamples:")
        click.echo('  --code "import json; print(json.load(open(\'data.json\')))"')
        click.echo("  --script analyze.py --data input.json")
        return

    if not files_to_upload:
        warning("No files specified. Use --file, --script, or --data to upload files.")
        click.echo("Running code without file uploads...")

    # Verify files exist
    for fp in files_to_upload:
        full_path = f"{project.folder_path}/{fp}"
        if not storage.exists(full_path):
            error(f"File not found: {fp}")
            return
        size = storage.size(full_path)
        info(f"Will upload: {fp} ({size:,} bytes)")

    # Create tool context
    mock_service = MockService()
    ctx = ToolContext(
        service=mock_service,
        storage=storage,
        project_folder=project.folder_path,
        max_limit=1000,
        file_mtimes={},
        is_cancelled=lambda: False,
    )

    # Create tools
    tools = create_remote_code_tools(ctx)

    # Find the right tool by name (SdkMcpTool has .name and .handler attributes)
    tool_name = "remote_code_with_files" if files_to_upload else "remote_code_execution"

    tool_obj = next((t for t in tools if t.name == tool_name), None)

    if not tool_obj:
        error(f"Tool '{tool_name}' not found")
        info(f"Available tools: {[t.name for t in tools]}")
        return

    tool_func = tool_obj.handler  # Get the actual async handler function

    # Execute
    click.secho(f"\nExecuting {tool_name}...", fg="yellow")
    click.secho("-" * 60, fg="white")

    if files_to_upload:
        args = {
            "file_paths": files_to_upload,
            "code": code,
            "description": f"Test execution with {len(files_to_upload)} file(s)",
        }
    else:
        args = {
            "code": code,
            "description": "Test execution",
        }

    # Show code preview
    code_preview = code[:500] + "..." if len(code) > 500 else code
    click.secho(f"\nCode:\n{code_preview}\n", fg="cyan")

    # Run async function
    try:
        result = asyncio.run(tool_func(args))

        click.secho("-" * 60, fg="white")

        if result.get("is_error"):
            error("Execution failed")
            for content in result.get("content", []):
                if content.get("type") == "text":
                    click.secho(content.get("text", ""), fg="red")
        else:
            success("Execution completed")
            for content in result.get("content", []):
                if content.get("type") == "text":
                    click.echo(content.get("text", ""))

    except Exception as e:
        error(f"Error: {type(e).__name__}: {e}")
        traceback.print_exc()

    click.echo()
