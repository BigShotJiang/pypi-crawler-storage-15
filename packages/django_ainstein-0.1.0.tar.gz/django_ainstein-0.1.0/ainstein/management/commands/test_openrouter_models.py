"""
Test OpenRouter models lookup tool.

Usage:
    python manage.py test_openrouter_models
    python manage.py test_openrouter_models --search "claude"
    python manage.py test_openrouter_models --search "gpt-4" --capability tools
"""

import asyncio

import djclick as click

from ainstein.tools.base import ToolContext
from ainstein.tools.uv_code import create_uv_code_tools


class MockService:
    def emit(self, event):
        pass


class MockStorage:
    pass


@click.command()
@click.option("--search", "-s", default="gpt-5", help="Search term for model lookup")
@click.option("--capability", "-c", default="", help="Filter by capability (tools, vision)")
def command(search, capability):
    """Test openrouter_models tool."""
    click.secho("\n=== OpenRouter Models Lookup ===\n", fg="white", bold=True)
    click.secho(f"Search: {search}", fg="cyan")
    if capability:
        click.secho(f"Capability: {capability}", fg="cyan")

    ctx = ToolContext(
        service=MockService(),
        storage=MockStorage(),
        project_folder="",
        max_limit=1000,
        file_mtimes={},
        is_cancelled=lambda: False,
    )

    tools = create_uv_code_tools(ctx)
    tool = next(t for t in tools if t.name == "openrouter_models")

    click.secho("\nFetching models...\n", fg="yellow")

    result = asyncio.run(
        tool.handler(
            {
                "search": search,
                "capability": capability,
            }
        )
    )

    for content in result.get("content", []):
        if content.get("type") == "text":
            click.echo(content.get("text", ""))
