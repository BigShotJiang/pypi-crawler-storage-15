"""
Test UV Sandbox tool with pre-installed data science libraries.

Usage:
    python manage.py test_uv_sandbox
    python manage.py test_uv_sandbox --code "import pandas as pd; print(pd.__version__)"
"""

import asyncio

import djclick as click

from ainstein.tools.base import ToolContext
from ainstein.tools.uv_code import create_uv_code_tools


CODE = '''
import pandas as pd
import numpy as np
import matplotlib
import seaborn as sns
import scipy
import sklearn

print("=== UV Sandbox Test ===")
print(f"pandas: {pd.__version__}")
print(f"numpy: {np.__version__}")
print(f"matplotlib: {matplotlib.__version__}")
print(f"seaborn: {sns.__version__}")
print(f"scipy: {scipy.__version__}")
print(f"sklearn: {sklearn.__version__}")

# Quick data analysis test
df = pd.DataFrame({
    'x': np.random.randn(100),
    'y': np.random.randn(100),
})
print(f"\\nDataFrame shape: {df.shape}")
print(f"Mean x: {df['x'].mean():.4f}")
print(f"Correlation: {df['x'].corr(df['y']):.4f}")
'''


class MockService:
    def emit(self, event):
        pass


class MockStorage:
    pass


@click.command()
@click.option("--code", "-c", default=None, help="Custom Python code to execute")
def command(code):
    """Test uv_sandbox with pre-installed data science libraries."""
    click.secho("\n=== UV Sandbox Test ===\n", fg="white", bold=True)

    test_code = code or CODE

    ctx = ToolContext(
        service=MockService(),
        storage=MockStorage(),
        project_folder="",
        max_limit=1000,
        file_mtimes={},
        is_cancelled=lambda: False,
    )

    tools = create_uv_code_tools(ctx)
    tool = next(t for t in tools if t.name == "uv_sandbox")

    click.secho("Executing in sandbox...\n", fg="yellow")

    result = asyncio.run(
        tool.handler(
            {
                "code": test_code,
                "description": "Sandbox test",
            }
        )
    )

    for content in result.get("content", []):
        if content.get("type") == "text":
            click.echo(content.get("text", ""))
