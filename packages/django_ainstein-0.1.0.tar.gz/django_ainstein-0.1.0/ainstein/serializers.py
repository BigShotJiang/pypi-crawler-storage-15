"""
Claude Agent Serializers

DRF serializers for AI projects, conversations, and messages.
"""

from rest_framework import serializers

from .models import AiConversation, AiConversationMessage, AiProject


class AiConversationMessageSerializer(serializers.ModelSerializer):
    """Serializer for individual conversation messages."""

    class Meta:
        model = AiConversationMessage
        fields = ["id", "role", "content", "metadata", "created"]
        read_only_fields = ["id", "created"]


class AiConversationListSerializer(serializers.ModelSerializer):
    """Serializer for conversation list (minimal data)."""

    last_message = serializers.SerializerMethodField()
    message_count = serializers.IntegerField(read_only=True)

    class Meta:
        model = AiConversation
        fields = [
            "id",
            "title",
            "project_id",
            "message_count",
            "total_cost_usd",
            "total_input_tokens",
            "total_output_tokens",
            "last_message",
            "created",
            "modified",
        ]

    def get_last_message(self, obj):
        last_message = obj.messages.order_by("-created").first()
        if last_message:
            content = last_message.content.strip()
            return content[:80] + ("..." if len(content) > 80 else "")
        return ""


class AiConversationSerializer(serializers.ModelSerializer):
    """Serializer for conversation detail view."""

    messages = AiConversationMessageSerializer(many=True, read_only=True)
    message_count = serializers.IntegerField(read_only=True)
    project_name = serializers.CharField(source="project.name", read_only=True, allow_null=True)

    class Meta:
        model = AiConversation
        fields = [
            "id",
            "title",
            "project_id",
            "project_name",
            "session_id",
            "messages",
            "message_count",
            "total_cost_usd",
            "total_input_tokens",
            "total_output_tokens",
            "created",
            "modified",
        ]
        read_only_fields = [
            "id",
            "session_id",
            "message_count",
            "total_cost_usd",
            "total_input_tokens",
            "total_output_tokens",
            "created",
            "modified",
        ]


class AiConversationCreateSerializer(serializers.ModelSerializer):
    """Serializer for creating a new conversation."""

    project_name = serializers.CharField(source="project.name", read_only=True, allow_null=True)

    class Meta:
        model = AiConversation
        fields = [
            "id",
            "title",
            "project_id",
            "project_name",
            "session_id",
            "total_cost_usd",
            "created",
            "modified",
        ]
        read_only_fields = ["id", "session_id", "total_cost_usd", "created", "modified"]


class AiProjectListSerializer(serializers.ModelSerializer):
    """Serializer for project list view."""

    conversation_count = serializers.IntegerField(read_only=True)
    file_count = serializers.SerializerMethodField()
    is_owner = serializers.SerializerMethodField()
    owner_name = serializers.SerializerMethodField()
    last_activity = serializers.DateTimeField(read_only=True, allow_null=True)

    class Meta:
        model = AiProject
        fields = [
            "id",
            "name",
            "slug",
            "description",
            "is_shared",
            "is_owner",
            "owner_name",
            "conversation_count",
            "file_count",
            "folder_path",
            "created",
            "modified",
            "last_activity",
        ]

    def get_file_count(self, obj):
        return len(obj.list_files())

    def get_is_owner(self, obj):
        request = self.context.get("request")
        if request and request.user:
            return obj.user_id == request.user.id
        return False

    def get_owner_name(self, obj):
        return obj.user.get_full_name() or obj.user.username


class AiProjectSerializer(serializers.ModelSerializer):
    """Serializer for project detail view."""

    conversation_count = serializers.IntegerField(read_only=True)
    is_owner = serializers.SerializerMethodField()
    owner_name = serializers.SerializerMethodField()
    files = serializers.SerializerMethodField()

    class Meta:
        model = AiProject
        fields = [
            "id",
            "name",
            "slug",
            "description",
            "is_shared",
            "is_owner",
            "owner_name",
            "conversation_count",
            "folder_path",
            "files",
            "created",
            "modified",
        ]
        read_only_fields = ["id", "slug", "folder_path", "created", "modified"]

    def get_is_owner(self, obj):
        request = self.context.get("request")
        if request and request.user:
            return obj.user_id == request.user.id
        return False

    def get_owner_name(self, obj):
        return obj.user.get_full_name() or obj.user.username

    def get_files(self, obj):
        return obj.list_files()


class AiProjectCreateSerializer(serializers.ModelSerializer):
    """Serializer for creating a new project."""

    class Meta:
        model = AiProject
        fields = ["name", "description", "is_shared"]


# Request/Response serializers for custom actions


class AddMessageSerializer(serializers.Serializer):
    """Serializer for adding a message to a conversation."""

    role = serializers.ChoiceField(choices=["user", "assistant", "system"], default="user")
    content = serializers.CharField()
    metadata = serializers.JSONField(required=False, allow_null=True)


class UpdateCostSerializer(serializers.Serializer):
    """Serializer for updating conversation cost."""

    cost = serializers.DecimalField(max_digits=12, decimal_places=8)
    input_tokens = serializers.IntegerField(required=False, default=0)
    output_tokens = serializers.IntegerField(required=False, default=0)


class SetSessionSerializer(serializers.Serializer):
    """Serializer for setting session ID."""

    session_id = serializers.CharField()


class StreamMessageSerializer(serializers.Serializer):
    """Serializer for stream request."""

    message = serializers.CharField()
    conversation_id = serializers.IntegerField(required=False, allow_null=True)


class CancelStreamSerializer(serializers.Serializer):
    """Serializer for cancel stream request."""

    stream_id = serializers.CharField()


class PermissionResponseSerializer(serializers.Serializer):
    """Serializer for permission response from user."""

    request_id = serializers.CharField(help_text="Unique ID for the permission request")
    approved = serializers.BooleanField(help_text="Whether the user approved the action")


class FileContentSerializer(serializers.Serializer):
    """Serializer for file content response."""

    path = serializers.CharField()
    content = serializers.CharField()
    size = serializers.IntegerField()


class FileWriteSerializer(serializers.Serializer):
    """Serializer for file write request."""

    path = serializers.CharField(required=False)
    content = serializers.CharField()


class FolderCreateSerializer(serializers.Serializer):
    """Serializer for folder creation request."""

    path = serializers.CharField()


class FileListItemSerializer(serializers.Serializer):
    """Serializer for file list item."""

    name = serializers.CharField()
    path = serializers.CharField()
    type = serializers.ChoiceField(choices=["file", "directory"])
    size = serializers.IntegerField(required=False)


class ImprovePromptSerializer(serializers.Serializer):
    """Serializer for improve prompt request."""

    prompt = serializers.CharField(help_text="The prompt text to improve")


class ImprovedPromptSerializer(serializers.Serializer):
    """Serializer for improve prompt response."""

    improved_prompt = serializers.CharField(help_text="The improved prompt text")
