from django.contrib import admin

from .models import (
    AiAuditLog,
    AiCodeExecution,
    AiConversation,
    AiConversationMessage,
    AiCostLimit,
    AiProject,
    AiRateLimitTracker,
    AiScript,
    AiVisualization,
    AiWorkflow,
    AiWorkflowRun,
)


class AiConversationMessageInline(admin.TabularInline):
    model = AiConversationMessage
    extra = 0
    fields = ("role", "subtype", "content", "cost_usd", "duration_ms", "is_error", "created")
    readonly_fields = ("role", "subtype", "content", "cost_usd", "duration_ms", "is_error", "created")
    can_delete = False
    show_change_link = True

    def has_add_permission(self, request, obj=None):
        return False


@admin.register(AiProject)
class AiProjectAdmin(admin.ModelAdmin):
    list_display = ("id", "name", "slug", "user", "conversation_count", "is_shared", "modified")
    list_filter = ("is_shared", "user", "created", "modified")
    search_fields = ("name", "slug", "description")
    readonly_fields = ("external_id", "folder_path", "conversation_count", "created", "modified")
    ordering = ("-modified",)


@admin.register(AiConversation)
class AiConversationAdmin(admin.ModelAdmin):
    list_display = (
        "id",
        "title",
        "user",
        "project",
        "message_count",
        "total_cost_usd",
        "total_input_tokens",
        "total_output_tokens",
        "session_id",
        "modified",
    )
    list_filter = ("user", "project", "created", "modified")
    search_fields = ("title", "session_id")
    readonly_fields = (
        "session_id",
        "message_count",
        "total_cost_usd",
        "total_input_tokens",
        "total_output_tokens",
        "created",
        "modified",
    )
    ordering = ("-modified",)
    inlines = [AiConversationMessageInline]


@admin.register(AiConversationMessage)
class AiConversationMessageAdmin(admin.ModelAdmin):
    list_display = (
        "id",
        "conversation",
        "role",
        "subtype",
        "content_preview",
        "cost_usd",
        "duration_ms",
        "is_error",
        "created",
    )
    list_filter = ("role", "subtype", "is_error", "created")
    search_fields = ("content",)
    readonly_fields = (
        "conversation",
        "role",
        "content",
        "metadata",
        "subtype",
        "duration_ms",
        "duration_api_ms",
        "is_error",
        "num_turns",
        "cost_usd",
        "usage",
        "created",
        "modified",
    )
    ordering = ("-created",)

    def content_preview(self, obj):
        return obj.content[:100] + "..." if len(obj.content) > 100 else obj.content

    content_preview.short_description = "Content"


@admin.register(AiWorkflow)
class AiWorkflowAdmin(admin.ModelAdmin):
    list_display = ("id", "name", "user", "project", "is_active", "run_count", "modified")
    list_filter = ("is_active", "trigger", "user", "created", "modified")
    search_fields = ("name", "description")
    readonly_fields = ("run_count", "created", "modified")
    ordering = ("-modified",)


@admin.register(AiWorkflowRun)
class AiWorkflowRunAdmin(admin.ModelAdmin):
    list_display = ("id", "workflow", "user", "status", "started_at", "completed_at")
    list_filter = ("status", "started_at", "completed_at")
    search_fields = ("workflow__name",)
    readonly_fields = (
        "workflow",
        "user",
        "status",
        "started_at",
        "completed_at",
        "input_data",
        "output_data",
        "step_results",
        "error_message",
        "created",
        "modified",
    )
    ordering = ("-created",)


@admin.register(AiRateLimitTracker)
class AiRateLimitTrackerAdmin(admin.ModelAdmin):
    list_display = ("id", "user", "request_count", "token_count", "window_start")
    list_filter = ("window_start",)
    search_fields = ("user__username",)
    readonly_fields = ("user", "request_count", "token_count", "window_start")
    ordering = ("-window_start",)


@admin.register(AiVisualization)
class AiVisualizationAdmin(admin.ModelAdmin):
    list_display = ("id", "title", "chart_type", "project", "conversation", "created")
    list_filter = ("chart_type", "created")
    search_fields = ("title", "description")
    readonly_fields = ("created", "modified")
    ordering = ("-created",)


@admin.register(AiCostLimit)
class AiCostLimitAdmin(admin.ModelAdmin):
    list_display = ("id", "project", "daily_limit", "monthly_limit", "daily_usage", "monthly_usage")
    list_filter = ("created", "modified")
    search_fields = ("project__name",)
    readonly_fields = ("daily_usage", "monthly_usage", "total_usage", "created", "modified")
    ordering = ("-modified",)


@admin.register(AiScript)
class AiScriptAdmin(admin.ModelAdmin):
    list_display = ("id", "name", "slug", "version", "project", "is_public", "modified")
    list_filter = ("is_public", "created", "modified")
    search_fields = ("name", "slug", "description")
    readonly_fields = ("created", "modified")
    ordering = ("-modified",)


@admin.register(AiAuditLog)
class AiAuditLogAdmin(admin.ModelAdmin):
    list_display = ("id", "user", "action", "tool_name", "success", "timestamp")
    list_filter = ("action", "success", "timestamp")
    search_fields = ("user__username", "action", "tool_name", "description")
    readonly_fields = (
        "id",
        "user",
        "project",
        "conversation",
        "action",
        "tool_name",
        "description",
        "request_data",
        "response_summary",
        "success",
        "error_message",
        "duration_ms",
        "contains_sensitive_data",
        "ip_address",
        "timestamp",
    )
    ordering = ("-timestamp",)


@admin.register(AiCodeExecution)
class AiCodeExecutionAdmin(admin.ModelAdmin):
    list_display = ("id", "conversation", "language", "status", "duration_ms", "created")
    list_filter = ("language", "status", "created")
    search_fields = ("code", "purpose")
    readonly_fields = (
        "conversation",
        "message",
        "language",
        "code",
        "purpose",
        "status",
        "started_at",
        "completed_at",
        "duration_ms",
        "stdout",
        "stderr",
        "error_message",
        "generated_files",
        "created",
        "modified",
    )
    ordering = ("-created",)
