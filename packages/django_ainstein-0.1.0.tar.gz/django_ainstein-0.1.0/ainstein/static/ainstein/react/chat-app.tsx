// Claude Agent Chat App - React + shadcn/ui
// This TSX file is designed to run in-browser via esm.sh CDN imports

import React, { useState, useEffect, useRef, useCallback } from 'https://esm.sh/react@18'
import { createRoot } from 'https://esm.sh/react-dom@18/client'

// Types
interface Message {
  id: number
  role: 'user' | 'assistant' | 'system'
  content: string
  metadata?: {
    events?: EventData[]
    cancelled?: boolean
  }
  created?: string
}

interface EventData {
  type: 'text' | 'tool'
  text?: string
  tool?: string
  args?: string
  result?: string
  sql?: string
  data_preview?: Record<string, unknown>[]
}

interface Conversation {
  id: number
  title: string
  message_count: number
  total_cost: string
  created: string
  modified: string
}

interface StreamEvent {
  type: string
  text?: string
  tool?: string
  args_summary?: string
  summary?: string
  sql?: string
  rows?: unknown[]
  stream_id?: string
  session_id?: string
  message?: string
  cost?: number
  total_cost?: number
  duration?: string
  lines?: string[]
}

// =============================================================================
// UI Components (shadcn-inspired, inline styles for no-build)
// =============================================================================

const Button: React.FC<{
  children: React.ReactNode
  onClick?: () => void
  disabled?: boolean
  variant?: 'default' | 'destructive' | 'outline' | 'ghost'
  size?: 'default' | 'sm' | 'icon'
  className?: string
  title?: string
}> = ({ children, onClick, disabled, variant = 'default', size = 'default', className = '', title }) => {
  const baseStyles: React.CSSProperties = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: '6px',
    fontWeight: 500,
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.5 : 1,
    transition: 'all 0.2s',
    fontFamily: 'inherit',
    border: 'none',
  }

  const variantStyles: Record<string, React.CSSProperties> = {
    default: { background: 'var(--accent-cyan)', color: 'var(--bg-tertiary)' },
    destructive: { background: 'var(--accent-red)', color: 'white' },
    outline: { background: 'transparent', border: '1px solid var(--border-color)', color: 'var(--text-secondary)' },
    ghost: { background: 'transparent', color: 'var(--text-muted)' },
  }

  const sizeStyles: Record<string, React.CSSProperties> = {
    default: { padding: '12px 24px', fontSize: '13px' },
    sm: { padding: '8px 16px', fontSize: '12px' },
    icon: { padding: '8px', width: '32px', height: '32px' },
  }

  return (
    <button
      onClick={onClick}
      disabled={disabled}
      title={title}
      style={{ ...baseStyles, ...variantStyles[variant], ...sizeStyles[size] }}
      className={className}
    >
      {children}
    </button>
  )
}

const Textarea: React.FC<{
  value: string
  onChange: (value: string) => void
  onKeyDown?: (e: React.KeyboardEvent) => void
  placeholder?: string
  disabled?: boolean
  ref?: React.Ref<HTMLTextAreaElement>
}> = React.forwardRef(({ value, onChange, onKeyDown, placeholder, disabled }, ref) => {
  const textareaRef = useRef<HTMLTextAreaElement>(null)
  const combinedRef = (ref as React.RefObject<HTMLTextAreaElement>) || textareaRef

  useEffect(() => {
    if (combinedRef.current) {
      combinedRef.current.style.height = 'auto'
      combinedRef.current.style.height = Math.min(combinedRef.current.scrollHeight, 200) + 'px'
    }
  }, [value])

  return (
    <textarea
      ref={combinedRef}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      onKeyDown={onKeyDown}
      placeholder={placeholder}
      disabled={disabled}
      style={{
        flex: 1,
        background: 'var(--bg-tertiary)',
        border: '1px solid var(--border-color)',
        borderRadius: '6px',
        padding: '12px 16px',
        color: 'var(--text-primary)',
        fontFamily: 'inherit',
        fontSize: '13px',
        resize: 'none',
        minHeight: '44px',
        maxHeight: '200px',
        outline: 'none',
      }}
    />
  )
})

const ScrollArea: React.FC<{
  children: React.ReactNode
  className?: string
  onScroll?: (e: React.UIEvent<HTMLDivElement>) => void
  ref?: React.Ref<HTMLDivElement>
}> = React.forwardRef(({ children, className, onScroll }, ref) => (
  <div
    ref={ref}
    onScroll={onScroll}
    className={className}
    style={{
      flex: 1,
      overflowY: 'auto',
      padding: '20px',
      fontSize: '13px',
      lineHeight: 1.6,
    }}
  >
    {children}
  </div>
))

// =============================================================================
// Icons (inline SVG components)
// =============================================================================

const Icons = {
  Send: () => (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z" />
    </svg>
  ),
  Stop: () => (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
      <rect x="6" y="6" width="12" height="12" rx="2" />
    </svg>
  ),
  Copy: () => (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <rect x="9" y="9" width="13" height="13" rx="2" />
      <path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1" />
    </svg>
  ),
  Check: () => (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <polyline points="20 6 9 17 4 12" />
    </svg>
  ),
  Edit: () => (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M17 3a2.85 2.85 0 114 4L7.5 20.5 2 22l1.5-5.5L17 3z" />
    </svg>
  ),
  Plus: () => (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <line x1="12" y1="5" x2="12" y2="19" />
      <line x1="5" y1="12" x2="19" y2="12" />
    </svg>
  ),
  Trash: () => (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M3 6h18M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2" />
    </svg>
  ),
  Zap: () => (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
      <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" />
    </svg>
  ),
  Loader: () => (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ animation: 'spin 1s linear infinite' }}>
      <circle cx="12" cy="12" r="10" strokeOpacity="0.25" />
      <path d="M12 2a10 10 0 0110 10" strokeLinecap="round" />
    </svg>
  ),
}

// =============================================================================
// Message Components
// =============================================================================

const UserMessage: React.FC<{
  message: Message
  onCopy: (text: string) => void
  onReplay: (messageId: number, content: string) => void
}> = ({ message, onCopy, onReplay }) => {
  const [copied, setCopied] = useState(false)

  const handleCopy = () => {
    onCopy(message.content)
    setCopied(true)
    setTimeout(() => setCopied(false), 1500)
  }

  return (
    <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: '16px' }}>
      <div>
        <div
          style={{
            background: 'var(--bg-tertiary)',
            border: '1px solid var(--border-color)',
            borderRadius: '16px 16px 4px 16px',
            padding: '12px 16px',
            maxWidth: '620px',
            color: 'var(--text-primary)',
            whiteSpace: 'pre-wrap',
            wordBreak: 'break-word',
          }}
        >
          {message.content}
        </div>
        <div style={{ display: 'flex', gap: '8px', marginTop: '8px', justifyContent: 'flex-end', opacity: 0.5 }}>
          <Button variant="ghost" size="icon" onClick={() => onReplay(message.id, message.content)} title="Edit & Resend">
            <Icons.Edit />
          </Button>
          <Button variant="ghost" size="icon" onClick={handleCopy} title="Copy">
            {copied ? <Icons.Check /> : <Icons.Copy />}
          </Button>
        </div>
      </div>
    </div>
  )
}

const ToolCard: React.FC<{ event: EventData }> = ({ event }) => {
  const [collapsed, setCollapsed] = useState(false)

  return (
    <div
      style={{
        background: 'var(--bg-secondary)',
        border: '1px solid var(--border-color)',
        borderRadius: '8px',
        margin: '12px 0',
        overflow: 'hidden',
      }}
    >
      <div
        onClick={() => setCollapsed(!collapsed)}
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
          padding: '10px 14px',
          background: 'var(--bg-tertiary)',
          borderBottom: collapsed ? 'none' : '1px solid var(--border-color)',
          cursor: 'pointer',
        }}
      >
        <span style={{ color: 'var(--accent-orange)' }}><Icons.Zap /></span>
        <span style={{ color: 'var(--accent-orange)', fontWeight: 600, fontSize: '12px' }}>{event.tool}</span>
        {event.args && <span style={{ color: 'var(--text-muted)', fontSize: '12px' }}>({event.args})</span>}
        <span style={{ marginLeft: 'auto', color: 'var(--text-muted)', fontSize: '10px' }}>{collapsed ? '▶' : '▼'}</span>
      </div>
      {!collapsed && (
        <div style={{ padding: '10px 14px' }}>
          {event.sql && (
            <div
              style={{
                background: 'var(--bg-tertiary)',
                borderRadius: '4px',
                padding: '8px 12px',
                marginBottom: '8px',
                fontSize: '11px',
                color: 'var(--text-muted)',
                whiteSpace: 'pre-wrap',
                overflow: 'auto',
              }}
            >
              {event.sql}
            </div>
          )}
          {event.data_preview && event.data_preview.length > 0 && (
            <div style={{ fontSize: '11px', marginBottom: '8px' }}>
              {event.data_preview.slice(0, 5).map((row, i) => (
                <div key={i} style={{ color: 'var(--text-muted)', padding: '4px 0', borderBottom: '1px solid var(--border-color)' }}>
                  {Object.entries(row).map(([k, v]) => `${k}=${v}`).join(', ')}
                </div>
              ))}
              {event.data_preview.length > 5 && (
                <div style={{ color: 'var(--text-muted)', fontStyle: 'italic', paddingTop: '4px' }}>
                  ... and {event.data_preview.length - 5} more rows
                </div>
              )}
            </div>
          )}
          {event.result && (
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: 'var(--text-secondary)', fontSize: '12px' }}>
              <span style={{ color: 'var(--accent-green)' }}>✓</span>
              <span>{event.result}</span>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

const AssistantMessage: React.FC<{
  message: Message
  onCopy: (text: string) => void
}> = ({ message, onCopy }) => {
  const [copied, setCopied] = useState(false)

  const handleCopy = () => {
    onCopy(message.content)
    setCopied(true)
    setTimeout(() => setCopied(false), 1500)
  }

  const formatText = (text: string) => {
    let html = text
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
      .replace(/\*([^*]+)\*/g, '<em>$1</em>')
      .replace(/`([^`]+)`/g, '<code style="background:var(--bg-tertiary);padding:2px 6px;border-radius:4px;font-size:12px;color:var(--accent-orange)">$1</code>')
      .replace(/^### (.+)$/gm, '<h4 style="margin:16px 0 8px;font-size:13px">$1</h4>')
      .replace(/^## (.+)$/gm, '<h3 style="margin:16px 0 8px;font-size:15px">$1</h3>')
      .replace(/^- (.+)$/gm, '<div style="padding-left:16px">• $1</div>')
      .replace(/\n/g, '<br>')
    return html
  }

  const events = message.metadata?.events || []

  return (
    <div style={{ marginBottom: '24px' }}>
      {events.map((event, index) => {
        if (event.type === 'text' && event.text) {
          return (
            <div
              key={index}
              style={{ color: 'var(--text-primary)', lineHeight: 1.7, marginBottom: '12px' }}
              dangerouslySetInnerHTML={{ __html: formatText(event.text) }}
            />
          )
        } else if (event.type === 'tool') {
          return <ToolCard key={index} event={event} />
        }
        return null
      })}
      {events.length === 0 && message.content && (
        <div
          style={{ color: 'var(--text-primary)', lineHeight: 1.7 }}
          dangerouslySetInnerHTML={{ __html: formatText(message.content) }}
        />
      )}
      {message.metadata?.cancelled && (
        <div style={{ color: 'var(--accent-yellow)', fontSize: '11px', marginTop: '8px' }}>
          ⚠ Response stopped by user
        </div>
      )}
      <div style={{ display: 'flex', gap: '8px', marginTop: '8px', opacity: 0.5 }}>
        <Button variant="ghost" size="icon" onClick={handleCopy} title="Copy">
          {copied ? <Icons.Check /> : <Icons.Copy />}
        </Button>
      </div>
    </div>
  )
}

const StreamingMessage: React.FC<{ text: string }> = ({ text }) => (
  <div style={{ color: 'var(--text-primary)', lineHeight: 1.7, whiteSpace: 'pre-wrap' }}>
    {text}
    <span style={{ animation: 'pulse 1s infinite', opacity: 0.7 }}>▌</span>
  </div>
)

const LoadingIndicator: React.FC = () => (
  <div style={{ color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '8px', padding: '16px 0' }}>
    <Icons.Loader />
    <span>Thinking...</span>
  </div>
)

// =============================================================================
// Sidebar Component
// =============================================================================

const Sidebar: React.FC<{
  conversations: Conversation[]
  currentConversationId: number | null
  onSelectConversation: (id: number) => void
  onNewChat: () => void
  onDeleteConversation: (id: number) => void
  tools: { name: string; description: string }[]
  examples: string[]
  onExampleClick: (prompt: string) => void
}> = ({
  conversations,
  currentConversationId,
  onSelectConversation,
  onNewChat,
  onDeleteConversation,
  tools,
  examples,
  onExampleClick,
}) => (
  <aside
    style={{
      width: '280px',
      background: 'var(--bg-secondary)',
      borderRight: '1px solid var(--border-color)',
      padding: '16px',
      overflowY: 'auto',
      flexShrink: 0,
      display: 'flex',
      flexDirection: 'column',
    }}
  >
    <h3 style={{ fontSize: '11px', textTransform: 'uppercase', letterSpacing: '1px', color: 'var(--text-muted)', marginBottom: '12px' }}>
      Recent Conversations
    </h3>
    <ul style={{ listStyle: 'none', marginBottom: '24px' }}>
      {conversations.length === 0 ? (
        <li style={{ color: 'var(--text-muted)', fontSize: '11px', padding: '8px', textAlign: 'center' }}>
          No conversations yet
        </li>
      ) : (
        conversations.map((conv) => (
          <li
            key={conv.id}
            onClick={() => onSelectConversation(conv.id)}
            style={{
              fontSize: '12px',
              padding: '8px 10px',
              borderRadius: '4px',
              cursor: 'pointer',
              color: conv.id === currentConversationId ? 'var(--text-primary)' : 'var(--text-secondary)',
              background: conv.id === currentConversationId ? 'var(--bg-tertiary)' : 'transparent',
              border: conv.id === currentConversationId ? '1px solid var(--accent-cyan)' : '1px solid transparent',
              marginBottom: '4px',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}
          >
            <span style={{ flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {conv.title || 'Untitled'}
            </span>
            <button
              onClick={(e) => { e.stopPropagation(); onDeleteConversation(conv.id) }}
              style={{
                opacity: 0.5,
                color: 'var(--accent-red)',
                background: 'none',
                border: 'none',
                cursor: 'pointer',
                padding: '2px 6px',
              }}
            >
              <Icons.Trash />
            </button>
          </li>
        ))
      )}
    </ul>

    <h3 style={{ fontSize: '11px', textTransform: 'uppercase', letterSpacing: '1px', color: 'var(--text-muted)', marginBottom: '12px' }}>
      Available Tools
    </h3>
    <ul style={{ listStyle: 'none', marginBottom: '24px' }}>
      {tools.map((tool) => (
        <li key={tool.name} style={{ fontSize: '12px', padding: '6px 8px', borderRadius: '4px' }}>
          <span style={{ color: 'var(--accent-orange)' }}>{tool.name}</span>
          <div style={{ color: 'var(--text-muted)', fontSize: '11px', marginTop: '2px' }}>{tool.description}</div>
        </li>
      ))}
    </ul>

    <h3 style={{ fontSize: '11px', textTransform: 'uppercase', letterSpacing: '1px', color: 'var(--text-muted)', marginBottom: '12px' }}>
      Example Prompts
    </h3>
    <ul style={{ listStyle: 'none' }}>
      {examples.map((prompt, i) => (
        <li
          key={i}
          onClick={() => onExampleClick(prompt)}
          style={{
            fontSize: '12px',
            padding: '8px 10px',
            borderRadius: '4px',
            cursor: 'pointer',
            color: 'var(--text-secondary)',
            border: '1px solid transparent',
            marginBottom: '4px',
          }}
        >
          {prompt}
        </li>
      ))}
    </ul>
  </aside>
)

// =============================================================================
// Main Chat App Component
// =============================================================================

interface ChatAppProps {
  apiBaseUrl: string
  tools: { name: string; description: string }[]
  examples: string[]
}

const ChatApp: React.FC<ChatAppProps> = ({ apiBaseUrl, tools, examples }) => {
  // State
  const [conversations, setConversations] = useState<Conversation[]>([])
  const [currentConversationId, setCurrentConversationId] = useState<number | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [inputValue, setInputValue] = useState('')
  const [isProcessing, setIsProcessing] = useState(false)
  const [streamingText, setStreamingText] = useState('')
  const [currentStreamId, setCurrentStreamId] = useState<string | null>(null)

  // Refs
  const scrollRef = useRef<HTMLDivElement>(null)
  const abortControllerRef = useRef<AbortController | null>(null)
  const shouldAutoScroll = useRef(true)

  // URL helpers
  const getConversationIdFromUrl = () => {
    const params = new URLSearchParams(window.location.search)
    const id = params.get('c')
    return id ? parseInt(id) : null
  }

  const setConversationIdInUrl = (id: number | null) => {
    const url = new URL(window.location.href)
    if (id) {
      url.searchParams.set('c', String(id))
    } else {
      url.searchParams.delete('c')
    }
    window.history.pushState({}, '', url)
  }

  // API calls
  const loadConversationList = async () => {
    try {
      const res = await fetch(`${apiBaseUrl}/conversations/`)
      const data = await res.json()
      setConversations(data.conversations || [])
    } catch (e) {
      console.error('Failed to load conversations:', e)
    }
  }

  const createConversation = async () => {
    try {
      const res = await fetch(`${apiBaseUrl}/conversations/create/`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({}),
      })
      const data = await res.json()
      setCurrentConversationId(data.id)
      setConversationIdInUrl(data.id)
      await loadConversationList()
      return data.id
    } catch (e) {
      console.error('Failed to create conversation:', e)
      return null
    }
  }

  const loadConversation = async (id: number, updateUrl = true) => {
    try {
      const res = await fetch(`${apiBaseUrl}/conversations/${id}/`)
      if (!res.ok) {
        setConversationIdInUrl(null)
        setCurrentConversationId(null)
        return
      }
      const data = await res.json()
      setCurrentConversationId(data.id)
      if (updateUrl) setConversationIdInUrl(data.id)
      setMessages(data.messages || [])
      await loadConversationList()
    } catch (e) {
      console.error('Failed to load conversation:', e)
    }
  }

  const deleteConversation = async (id: number) => {
    if (!confirm('Delete this conversation?')) return
    try {
      await fetch(`${apiBaseUrl}/conversations/${id}/delete/`, { method: 'DELETE' })
      if (currentConversationId === id) {
        setCurrentConversationId(null)
        setConversationIdInUrl(null)
        setMessages([])
      }
      await loadConversationList()
    } catch (e) {
      console.error('Failed to delete conversation:', e)
    }
  }

  const replayMessage = async (messageId: number, content: string) => {
    if (isProcessing || !currentConversationId) return
    if (!confirm('This will delete this message and all messages after it. Continue?')) return

    try {
      const res = await fetch(`${apiBaseUrl}/conversations/${currentConversationId}/replay/${messageId}/`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      })
      if (!res.ok) throw new Error('Failed to replay')
      const data = await res.json()
      await loadConversation(currentConversationId, false)
      setInputValue(data.message_content || content)
    } catch (e) {
      console.error('Replay error:', e)
      alert('Failed to replay message')
    }
  }

  // Stop generation
  const stopGeneration = async () => {
    if (!currentStreamId) return
    try {
      await fetch(`${apiBaseUrl}/stream/cancel/`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ stream_id: currentStreamId }),
      })
      abortControllerRef.current?.abort()
    } catch (e) {
      console.error('Stop error:', e)
    }
  }

  // Send message
  const sendMessage = async () => {
    const message = inputValue.trim()
    if (!message || isProcessing) return

    let convId = currentConversationId
    if (!convId) {
      convId = await createConversation()
      if (!convId) return
    }

    setIsProcessing(true)
    setInputValue('')
    setStreamingText('')
    shouldAutoScroll.current = true

    // Optimistically add user message to UI
    const tempUserMsg: Message = { id: Date.now(), role: 'user', content: message }
    setMessages((prev) => [...prev, tempUserMsg])

    abortControllerRef.current = new AbortController()

    try {
      const res = await fetch(`${apiBaseUrl}/stream/`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message, conversation_id: convId }),
        signal: abortControllerRef.current.signal,
      })

      if (!res.ok) throw new Error(`HTTP ${res.status}`)

      const reader = res.body!.getReader()
      const decoder = new TextDecoder()
      let buffer = ''
      let accumulatedText = ''
      const events: EventData[] = []
      let currentTool: EventData | null = null

      while (true) {
        const { done, value } = await reader.read()
        if (done) break

        buffer += decoder.decode(value, { stream: true })
        const lines = buffer.split('\n')
        buffer = lines.pop() || ''

        for (const line of lines) {
          if (!line.startsWith('data: ')) continue
          try {
            const event: StreamEvent = JSON.parse(line.slice(6))

            switch (event.type) {
              case 'stream_id':
                setCurrentStreamId(event.stream_id || null)
                break

              case 'agent_text':
                if (event.text) {
                  accumulatedText += event.text.replace(/\x1B\[[0-9;]*[a-zA-Z]/g, '')
                  setStreamingText(accumulatedText)
                }
                break

              case 'tool_start':
                // Finalize text if any
                if (accumulatedText) {
                  events.push({ type: 'text', text: accumulatedText })
                  accumulatedText = ''
                  setStreamingText('')
                }
                currentTool = {
                  type: 'tool',
                  tool: event.tool,
                  args: event.args_summary,
                }
                events.push(currentTool)
                break

              case 'tool_result':
                if (currentTool) currentTool.result = event.summary
                break

              case 'sql':
                if (currentTool) currentTool.sql = event.sql
                break

              case 'data_preview':
                if (currentTool && event.rows) currentTool.data_preview = event.rows as Record<string, unknown>[]
                break

              case 'step_done':
              case 'done':
              case 'cancelled':
                // Finalize
                if (accumulatedText) {
                  events.push({ type: 'text', text: accumulatedText })
                }
                setStreamingText('')
                break
            }
          } catch (e) {
            console.error('Parse error:', e)
          }
        }
      }

      // Reload to get server-saved messages
      await loadConversation(convId, false)
      await loadConversationList()

    } catch (e: any) {
      if (e.name === 'AbortError') {
        // User cancelled
      } else {
        console.error('Stream error:', e)
      }
    } finally {
      setIsProcessing(false)
      setCurrentStreamId(null)
      setStreamingText('')
      abortControllerRef.current = null
    }
  }

  // Auto-scroll
  useEffect(() => {
    if (shouldAutoScroll.current && scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [messages, streamingText])

  // Init
  useEffect(() => {
    loadConversationList()
    const urlId = getConversationIdFromUrl()
    if (urlId) loadConversation(urlId)
  }, [])

  // Copy helper
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
  }

  // New chat
  const startNewChat = () => {
    setCurrentConversationId(null)
    setConversationIdInUrl(null)
    setMessages([])
    setInputValue('')
  }

  // Handle keyboard
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      sendMessage()
    }
    if (e.key === 'Escape' && isProcessing) {
      stopGeneration()
    }
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh', background: 'var(--bg-primary)', color: 'var(--text-primary)' }}>
      {/* Header */}
      <header
        style={{
          background: 'var(--bg-secondary)',
          borderBottom: '1px solid var(--border-color)',
          padding: '12px 20px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          <h1 style={{ fontSize: '16px', fontWeight: 600, color: 'var(--accent-cyan)', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="12" cy="12" r="10" />
              <path d="M12 16v-4M12 8h.01" />
            </svg>
            Claude Agent
          </h1>
          <Button variant="outline" size="sm" onClick={startNewChat}>
            <Icons.Plus /> New Chat
          </Button>
        </div>
        <div style={{ fontSize: '12px', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '6px' }}>
          <span
            style={{
              width: '8px',
              height: '8px',
              borderRadius: '50%',
              background: isProcessing ? 'var(--accent-yellow)' : 'var(--accent-green)',
            }}
          />
          {isProcessing ? 'Processing...' : 'Ready'}
        </div>
      </header>

      {/* Main */}
      <div style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
        <Sidebar
          conversations={conversations}
          currentConversationId={currentConversationId}
          onSelectConversation={(id) => loadConversation(id)}
          onNewChat={startNewChat}
          onDeleteConversation={deleteConversation}
          tools={tools}
          examples={examples}
          onExampleClick={setInputValue}
        />

        <main style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
          <ScrollArea ref={scrollRef}>
            {messages.length === 0 && !streamingText && (
              <div style={{ color: 'var(--text-muted)' }}>
                Welcome to Claude Agent. Type a message below or click an example prompt to get started.
              </div>
            )}
            {messages.map((msg) =>
              msg.role === 'user' ? (
                <UserMessage key={msg.id} message={msg} onCopy={copyToClipboard} onReplay={replayMessage} />
              ) : (
                <AssistantMessage key={msg.id} message={msg} onCopy={copyToClipboard} />
              )
            )}
            {isProcessing && !streamingText && <LoadingIndicator />}
            {streamingText && <StreamingMessage text={streamingText} />}
          </ScrollArea>

          {/* Input */}
          <div style={{ background: 'var(--bg-secondary)', borderTop: '1px solid var(--border-color)', padding: '16px 20px' }}>
            <div style={{ display: 'flex', gap: '12px', alignItems: 'flex-end' }}>
              <Textarea
                value={inputValue}
                onChange={setInputValue}
                onKeyDown={handleKeyDown}
                placeholder="Ask Claude something..."
                disabled={isProcessing}
              />
              {isProcessing ? (
                <Button variant="destructive" onClick={stopGeneration}>
                  <Icons.Stop /> Stop
                </Button>
              ) : (
                <Button onClick={sendMessage} disabled={!inputValue.trim()}>
                  <Icons.Send /> Send
                </Button>
              )}
            </div>
          </div>
        </main>
      </div>

      {/* Global styles */}
      <style>{`
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.3; }
        }
        :root {
          --bg-primary: #1e1e2e;
          --bg-secondary: #181825;
          --bg-tertiary: #11111b;
          --text-primary: #cdd6f4;
          --text-secondary: #a6adc8;
          --text-muted: #6c7086;
          --accent-cyan: #89dceb;
          --accent-green: #a6e3a1;
          --accent-red: #f38ba8;
          --accent-yellow: #f9e2af;
          --accent-orange: #fab387;
          --accent-blue: #89b4fa;
          --border-color: #313244;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
          font-family: 'JetBrains Mono', 'Fira Code', 'SF Mono', Consolas, monospace;
          background: var(--bg-primary);
          color: var(--text-primary);
        }
        ::-webkit-scrollbar { width: 8px; }
        ::-webkit-scrollbar-track { background: var(--bg-tertiary); }
        ::-webkit-scrollbar-thumb { background: var(--border-color); border-radius: 4px; }
      `}</style>
    </div>
  )
}

// =============================================================================
// Export and Mount
// =============================================================================

export { ChatApp }

// Auto-mount if container exists
declare global {
  interface Window {
    AINSTEIN_CONFIG?: {
      apiBaseUrl: string
      tools: { name: string; description: string }[]
      examples: string[]
    }
  }
}

const container = document.getElementById('claude-agent-root')
if (container && window.AINSTEIN_CONFIG) {
  const root = createRoot(container)
  root.render(
    <ChatApp
      apiBaseUrl={window.AINSTEIN_CONFIG.apiBaseUrl}
      tools={window.AINSTEIN_CONFIG.tools}
      examples={window.AINSTEIN_CONFIG.examples}
    />
  )
}
