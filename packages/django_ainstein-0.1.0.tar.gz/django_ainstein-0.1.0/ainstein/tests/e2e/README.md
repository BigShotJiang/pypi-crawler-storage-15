# Claude Agent E2E Tests

End-to-end tests for the Claude Agent frontend using Playwright.

## Prerequisites

1. Install Playwright and pytest-playwright:

   ```bash
   pip install pytest-playwright
   playwright install chromium
   ```

2. Start the Django development server:

   ```bash
   python manage.py runserver 0.0.0.0:8706
   ```

3. Set environment variables (optional):

   ```bash
   export TEST_BASE_URL=http://localhost:8706
   export TEST_USERNAME=admin
   export TEST_PASSWORD=admin
   export TEST_HEADLESS=true
   export TEST_SLOW_MO=0
   ```

## Running Tests

### Run all E2E tests:

```bash
cd webapp/claude_agent/tests/e2e
pytest
```

### Run specific test categories:

```bash
# Conversation tests
pytest -m conversation

# Tool execution tests
pytest -m tool

# Permission dialog tests
pytest -m permission

# Streaming tests
pytest -m streaming
```

### Run in headed mode (see browser):

```bash
TEST_HEADLESS=false pytest
```

### Run with slow motion (for debugging):

```bash
TEST_SLOW_MO=500 pytest
```

### Run a specific test file:

```bash
pytest test_conversation.py
pytest test_tool_approval.py
pytest test_permission_dialog.py
```

### Run a specific test:

```bash
pytest test_conversation.py::TestConversationBasics::test_conversation_page_loads
```

## Test Structure

- `conftest.py` - Shared fixtures and configuration
- `test_conversation.py` - Basic conversation flow tests
- `test_tool_approval.py` - Tool execution and state tests
- `test_permission_dialog.py` - Permission dialog interaction tests

## Writing New Tests

1. Use the `agent_helpers` fixture for authenticated page with helpers
2. Use the `authenticated_page` fixture for basic auth
3. Add appropriate markers (`@pytest.mark.conversation`, etc.)
4. Use `expect()` for assertions (Playwright's built-in)

Example:

```python
@pytest.mark.conversation
def test_my_new_test(agent_helpers):
    helpers = agent_helpers
    helpers.send_message("Hello")
    expect(helpers.page.locator('[data-role="assistant"]')).to_be_visible()
```

## Troubleshooting

- **Tests timing out**: Increase `TIMEOUT` in conftest.py
- **Login failing**: Check TEST_USERNAME and TEST_PASSWORD
- **Elements not found**: Verify data-testid attributes in frontend code
- **SSE not working**: Ensure Django server is running with proper streaming support
