"""
E2E tests for Claude Agent conversation flow

Tests the basic conversation functionality including:
- Sending messages
- Receiving streaming responses
- Viewing conversation history
- Creating new conversations
"""

import pytest
from playwright.sync_api import Page, expect

from .conftest import AGENT_PATH, BASE_URL, PageHelpers


@pytest.mark.conversation
class TestConversationBasics:
    """Basic conversation flow tests."""

    def test_conversation_page_loads(self, authenticated_page: Page):
        """Test that the conversation page loads correctly."""
        page = authenticated_page
        page.goto(f"{BASE_URL}{AGENT_PATH}")

        # Check for main UI elements
        expect(page.locator('textarea[placeholder*="message"]')).to_be_visible()

    def test_empty_state_shows_welcome(self, authenticated_page: Page):
        """Test that empty conversation shows welcome message."""
        page = authenticated_page
        page.goto(f"{BASE_URL}{AGENT_PATH}")

        # Should show empty state or welcome message
        # (Adjust selector based on actual UI)
        expect(page.locator("body")).to_contain_text("Claude")

    def test_message_input_accepts_text(self, authenticated_page: Page):
        """Test that message input accepts and displays text."""
        page = authenticated_page
        page.goto(f"{BASE_URL}{AGENT_PATH}")

        input_field = page.locator('textarea[placeholder*="message"]')
        input_field.fill("Hello, Claude!")

        expect(input_field).to_have_value("Hello, Claude!")


@pytest.mark.conversation
@pytest.mark.streaming
class TestMessageStreaming:
    """Tests for SSE streaming behavior."""

    def test_message_shows_streaming_indicator(self, agent_helpers: PageHelpers):
        """Test that sending a message shows streaming indicator."""
        helpers = agent_helpers

        # Send message without waiting for completion
        input_field = helpers.page.locator('textarea[placeholder*="message"]')
        input_field.fill("Say hello in one word")

        send_button = helpers.page.locator('button[type="submit"]')
        send_button.click()

        # Should show processing state
        expect(helpers.page.locator('[data-testid="streaming-indicator"]')).to_be_visible(timeout=5000)

    def test_streaming_response_appears_incrementally(self, agent_helpers: PageHelpers):
        """Test that response text appears incrementally during streaming."""
        helpers = agent_helpers

        helpers.send_message("Count from 1 to 5", wait_for_response=False)

        # Wait for some streaming text to appear
        response = helpers.page.locator('[data-role="assistant"]:last-of-type')
        expect(response).to_be_visible(timeout=30000)

        # Content should be non-empty
        expect(response).not_to_be_empty()

    def test_response_completes_successfully(self, agent_helpers: PageHelpers):
        """Test that response completes and streaming stops."""
        helpers = agent_helpers

        helpers.send_message("Say 'test complete' and nothing else")

        # After completion, streaming indicator should be gone
        expect(helpers.page.locator('[data-testid="streaming-indicator"]')).not_to_be_visible(timeout=60000)


@pytest.mark.conversation
class TestConversationHistory:
    """Tests for conversation history and persistence."""

    def test_messages_persist_after_refresh(self, agent_helpers: PageHelpers):
        """Test that messages persist after page refresh."""
        helpers = agent_helpers

        # Send a message
        helpers.send_message("Remember this: UNIQUE_TEST_STRING_12345")

        # Refresh the page
        helpers.page.reload()
        helpers.page.wait_for_load_state("networkidle")

        # Message should still be visible
        expect(helpers.page.locator("body")).to_contain_text("UNIQUE_TEST_STRING_12345")

    def test_user_message_displayed_correctly(self, agent_helpers: PageHelpers):
        """Test that user messages are displayed with correct styling."""
        helpers = agent_helpers

        test_message = "This is my test message"
        helpers.send_message(test_message)

        # Find user message
        user_messages = helpers.page.locator('[data-role="user"]')
        expect(user_messages.last).to_contain_text(test_message)

    def test_assistant_message_displayed_correctly(self, agent_helpers: PageHelpers):
        """Test that assistant messages are displayed with correct styling."""
        helpers = agent_helpers

        helpers.send_message("Respond with exactly: ASSISTANT_RESPONSE_TEST")

        # Find assistant message
        assistant_messages = helpers.page.locator('[data-role="assistant"]')
        expect(assistant_messages.last).to_be_visible()
        expect(assistant_messages.last).not_to_be_empty()


@pytest.mark.conversation
class TestConversationNavigation:
    """Tests for conversation list and navigation."""

    def test_new_conversation_button_works(self, authenticated_page: Page):
        """Test that new conversation button creates empty conversation."""
        page = authenticated_page
        page.goto(f"{BASE_URL}{AGENT_PATH}")

        # Click new conversation button (adjust selector)
        new_button = page.locator('[data-testid="new-conversation"]')
        if new_button.is_visible():
            new_button.click()

            # Should show empty state
            expect(page.locator('[data-role="user"]')).to_have_count(0)

    def test_conversation_list_shows_history(self, agent_helpers: PageHelpers):
        """Test that conversation list shows previous conversations."""
        helpers = agent_helpers

        # Send a message to create conversation
        helpers.send_message("Test message for history")

        # Check conversation list (adjust selector based on UI)
        conv_list = helpers.page.locator('[data-testid="conversation-list"]')
        if conv_list.is_visible():
            expect(conv_list.locator('[data-testid="conversation-item"]')).to_have_count(lambda n: n >= 1)


@pytest.mark.conversation
class TestErrorHandling:
    """Tests for error handling in conversations."""

    def test_network_error_shows_message(self, authenticated_page: Page):
        """Test that network errors display user-friendly message."""
        page = authenticated_page
        page.goto(f"{BASE_URL}{AGENT_PATH}")

        # Simulate network issue by blocking API calls
        page.route("**/stream/**", lambda route: route.abort("failed"))

        input_field = page.locator('textarea[placeholder*="message"]')
        input_field.fill("Test message")

        send_button = page.locator('button[type="submit"]')
        send_button.click()

        # Should show error message
        expect(page.locator('[data-testid="error-message"]')).to_be_visible(timeout=10000)

    def test_can_retry_after_error(self, authenticated_page: Page):
        """Test that user can retry after an error."""
        page = authenticated_page
        page.goto(f"{BASE_URL}{AGENT_PATH}")

        # First, cause an error
        page.route("**/stream/**", lambda route: route.abort("failed"))

        input_field = page.locator('textarea[placeholder*="message"]')
        input_field.fill("Test message")
        page.locator('button[type="submit"]').click()

        # Wait for error
        page.wait_for_selector('[data-testid="error-message"]', timeout=10000)

        # Remove the route block
        page.unroute("**/stream/**")

        # Try again
        input_field.fill("Retry message")
        page.locator('button[type="submit"]').click()

        # Should work now (or at least attempt)
        expect(page.locator('[data-testid="streaming-indicator"]')).to_be_visible(timeout=5000)
