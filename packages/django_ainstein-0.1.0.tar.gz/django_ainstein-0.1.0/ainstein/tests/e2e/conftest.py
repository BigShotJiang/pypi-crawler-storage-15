"""
Pytest configuration for Claude Agent Playwright E2E tests

These tests verify the full conversation flow, tool execution,
and permission handling in the Claude Agent frontend.
"""

import os
from collections.abc import Generator

import pytest
from playwright.sync_api import Browser, BrowserContext, Page, Playwright


# Test configuration
BASE_URL = os.environ.get("TEST_BASE_URL", "http://localhost:8706")
AGENT_PATH = os.environ.get("TEST_AGENT_PATH", "/ainstein/staff/p/")
HEADLESS = os.environ.get("TEST_HEADLESS", "true").lower() == "true"
SLOW_MO = int(os.environ.get("TEST_SLOW_MO", "0"))

BROWSER_OPTIONS = {
    "headless": HEADLESS,
    "slow_mo": SLOW_MO,
}

VIEWPORT = {"width": 1280, "height": 720}
TIMEOUT = 30000  # 30 seconds default timeout


@pytest.fixture(scope="session")
def browser(playwright: Playwright) -> Generator[Browser]:
    """Launch browser for the test session."""
    browser = playwright.chromium.launch(**BROWSER_OPTIONS)
    yield browser
    browser.close()


@pytest.fixture(scope="function")
def context(browser: Browser) -> Generator[BrowserContext]:
    """Create a new browser context for each test."""
    context = browser.new_context(
        viewport=VIEWPORT,
        ignore_https_errors=True,
    )
    context.set_default_timeout(TIMEOUT)
    yield context
    context.close()


@pytest.fixture(scope="function")
def page(context: BrowserContext) -> Generator[Page]:
    """Create a new page for each test."""
    page = context.new_page()
    yield page
    page.close()


@pytest.fixture(scope="function")
def authenticated_page(page: Page) -> Page:
    """
    Return a page that is authenticated as a staff user.
    Assumes the Django dev server is running with test auth enabled.
    """
    # Navigate to admin login
    page.goto(f"{BASE_URL}/admin/login/")

    # Fill in test credentials (adjust for your test environment)
    page.fill('input[name="username"]', os.environ.get("TEST_USERNAME", "admin"))
    page.fill('input[name="password"]', os.environ.get("TEST_PASSWORD", "admin"))
    page.click('button[type="submit"]')

    # Wait for redirect
    page.wait_for_url(f"{BASE_URL}/admin/**")

    return page


@pytest.fixture(scope="function")
def ainstein_page(authenticated_page: Page) -> Page:
    """Navigate to Claude Agent conversation page."""
    page = authenticated_page

    # Navigate to Claude Agent
    page.goto(f"{BASE_URL}{AGENT_PATH}")

    # Wait for React app to load
    page.wait_for_selector('[data-testid="conversation-view"]', timeout=10000)

    return page


def pytest_configure(config):
    """Configure pytest with custom markers."""
    config.addinivalue_line("markers", "conversation: mark test as conversation flow test")
    config.addinivalue_line("markers", "tool: mark test as tool execution test")
    config.addinivalue_line("markers", "permission: mark test as permission handling test")
    config.addinivalue_line("markers", "streaming: mark test as SSE streaming test")


class PageHelpers:
    """Helper methods for interacting with Claude Agent UI."""

    def __init__(self, page: Page):
        self.page = page
        self.base_url = BASE_URL

    def send_message(self, text: str, wait_for_response: bool = True) -> None:
        """Send a message in the chat."""
        # Find input field
        input_field = self.page.locator('textarea[placeholder*="message"]')
        input_field.fill(text)

        # Click send button
        send_button = self.page.locator('button[type="submit"]')
        send_button.click()

        if wait_for_response:
            # Wait for assistant response
            self.page.wait_for_selector('[data-role="assistant"]:last-of-type', timeout=60000)

    def wait_for_tool_completion(self, tool_name: str = None, timeout: int = 30000) -> None:
        """Wait for a tool to complete execution."""
        if tool_name:
            selector = f'[data-tool-name="{tool_name}"] [data-state="completed"]'
        else:
            selector = '[data-testid="tool"] [data-state="completed"]:last-of-type'

        self.page.wait_for_selector(selector, timeout=timeout)

    def wait_for_permission_dialog(self, timeout: int = 30000) -> None:
        """Wait for permission dialog to appear."""
        self.page.wait_for_selector('[data-testid="permission-dialog"]', timeout=timeout)

    def approve_permission(self) -> None:
        """Click approve button in permission dialog."""
        self.page.click('[data-testid="permission-approve"]')

    def deny_permission(self) -> None:
        """Click deny button in permission dialog."""
        self.page.click('[data-testid="permission-deny"]')

    def get_messages(self) -> list:
        """Get all messages in the conversation."""
        messages = self.page.locator('[data-role]').all()
        return [
            {
                "role": msg.get_attribute("data-role"),
                "content": msg.text_content(),
            }
            for msg in messages
        ]

    def get_tool_cards(self) -> list:
        """Get all tool cards in the conversation."""
        tools = self.page.locator('[data-testid="tool"]').all()
        return [
            {
                "name": tool.locator('[data-testid="tool-name"]').text_content(),
                "state": tool.get_attribute("data-state"),
            }
            for tool in tools
        ]


@pytest.fixture
def helpers(page: Page) -> PageHelpers:
    """Provide helper methods for page interaction."""
    return PageHelpers(page)


@pytest.fixture
def agent_helpers(ainstein_page: Page) -> PageHelpers:
    """Provide helper methods for authenticated agent page."""
    return PageHelpers(ainstein_page)
