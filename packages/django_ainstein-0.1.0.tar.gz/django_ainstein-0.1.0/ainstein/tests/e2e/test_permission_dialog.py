"""
E2E tests for Claude Agent permission dialog flow

Tests permission handling for sensitive operations:
- Permission dialog appearance
- Approve/deny actions
- Tool state after permission response
- Dangerous operation warnings
"""

import pytest
from playwright.sync_api import expect

from .conftest import PageHelpers


@pytest.mark.permission
class TestPermissionDialogAppearance:
    """Tests for permission dialog display."""

    def test_permission_dialog_appears_for_code_execution(self, agent_helpers: PageHelpers):
        """Test that permission dialog appears for code execution."""
        helpers = agent_helpers

        # Try to execute code that requires approval
        helpers.send_message("Execute this Python code: print('Hello from Python')", wait_for_response=False)

        # Permission dialog should appear
        expect(helpers.page.locator('[data-testid="permission-dialog"]')).to_be_visible(timeout=30000)

    def test_permission_dialog_shows_tool_details(self, agent_helpers: PageHelpers):
        """Test that permission dialog shows the tool being requested."""
        helpers = agent_helpers

        helpers.send_message("Run this bash command: ls -la", wait_for_response=False)

        dialog = helpers.page.locator('[data-testid="permission-dialog"]')
        expect(dialog).to_be_visible(timeout=30000)

        # Should show what tool is requesting permission
        expect(dialog).to_contain_text("Bash")

    def test_permission_dialog_shows_action_description(self, agent_helpers: PageHelpers):
        """Test that permission dialog describes the action."""
        helpers = agent_helpers

        helpers.send_message("Execute Python: import os; print(os.getcwd())", wait_for_response=False)

        dialog = helpers.page.locator('[data-testid="permission-dialog"]')
        expect(dialog).to_be_visible(timeout=30000)

        # Should contain description of what will be executed
        expect(dialog.locator('[data-testid="permission-message"]')).not_to_be_empty()


@pytest.mark.permission
class TestPermissionApproval:
    """Tests for approving permissions."""

    def test_approve_allows_tool_execution(self, agent_helpers: PageHelpers):
        """Test that approving permission allows tool to execute."""
        helpers = agent_helpers

        helpers.send_message("Execute Python: print('APPROVAL_TEST_OUTPUT')", wait_for_response=False)

        # Wait for permission dialog
        dialog = helpers.page.locator('[data-testid="permission-dialog"]')
        expect(dialog).to_be_visible(timeout=30000)

        # Click approve
        helpers.page.click('[data-testid="permission-approve"]')

        # Dialog should close
        expect(dialog).not_to_be_visible()

        # Tool should complete
        expect(helpers.page.locator('[data-testid="tool"] >> text=Completed')).to_be_visible(timeout=60000)

    def test_approval_shows_tool_result(self, agent_helpers: PageHelpers):
        """Test that approved tool shows its result."""
        helpers = agent_helpers

        helpers.send_message("Execute Python: print('RESULT_VISIBLE_TEST')", wait_for_response=False)

        dialog = helpers.page.locator('[data-testid="permission-dialog"]')
        expect(dialog).to_be_visible(timeout=30000)

        helpers.page.click('[data-testid="permission-approve"]')

        # Result should contain the output
        expect(helpers.page.locator("body")).to_contain_text("RESULT_VISIBLE_TEST", timeout=60000)


@pytest.mark.permission
class TestPermissionDenial:
    """Tests for denying permissions."""

    def test_deny_blocks_tool_execution(self, agent_helpers: PageHelpers):
        """Test that denying permission blocks tool execution."""
        helpers = agent_helpers

        helpers.send_message("Execute Python: print('SHOULD_NOT_EXECUTE')", wait_for_response=False)

        dialog = helpers.page.locator('[data-testid="permission-dialog"]')
        expect(dialog).to_be_visible(timeout=30000)

        # Click deny
        helpers.page.click('[data-testid="permission-deny"]')

        # Dialog should close
        expect(dialog).not_to_be_visible()

        # Tool should show denied state
        expect(helpers.page.locator('[data-testid="tool"] >> text=Denied')).to_be_visible(timeout=30000)

    def test_denied_tool_does_not_show_output(self, agent_helpers: PageHelpers):
        """Test that denied tool does not show execution output."""
        helpers = agent_helpers

        helpers.send_message("Execute Python: print('SECRET_SHOULD_NOT_APPEAR')", wait_for_response=False)

        dialog = helpers.page.locator('[data-testid="permission-dialog"]')
        expect(dialog).to_be_visible(timeout=30000)

        helpers.page.click('[data-testid="permission-deny"]')

        # The secret string should NOT appear in output
        expect(helpers.page.locator("body")).not_to_contain_text("SECRET_SHOULD_NOT_APPEAR")

    def test_deny_allows_conversation_to_continue(self, agent_helpers: PageHelpers):
        """Test that denying permission allows conversation to continue."""
        helpers = agent_helpers

        helpers.send_message("Execute Python: print('test')", wait_for_response=False)

        dialog = helpers.page.locator('[data-testid="permission-dialog"]')
        expect(dialog).to_be_visible(timeout=30000)

        helpers.page.click('[data-testid="permission-deny"]')

        # Should be able to send another message
        helpers.send_message("What's 2 + 2?")

        # Should get a response
        expect(helpers.page.locator('[data-role="assistant"]').last).not_to_be_empty()


@pytest.mark.permission
class TestAwaitingApprovalState:
    """Tests for the 'awaiting approval' tool state."""

    def test_tool_shows_awaiting_approval_state(self, agent_helpers: PageHelpers):
        """Test that tool shows awaiting approval state while waiting."""
        helpers = agent_helpers

        helpers.send_message("Execute bash: echo 'waiting'", wait_for_response=False)

        # Tool should show awaiting approval state
        expect(helpers.page.locator('[data-testid="tool"] >> text=Awaiting Approval')).to_be_visible(timeout=30000)

    def test_awaiting_approval_state_transitions_on_approve(self, agent_helpers: PageHelpers):
        """Test that awaiting approval state transitions to running/completed on approve."""
        helpers = agent_helpers

        helpers.send_message("Execute Python: print('transition test')", wait_for_response=False)

        # Wait for awaiting approval state
        tool = helpers.page.locator('[data-testid="tool"]').last
        expect(tool.locator('text=Awaiting Approval')).to_be_visible(timeout=30000)

        # Approve
        helpers.page.click('[data-testid="permission-approve"]')

        # Should transition to completed
        expect(tool.locator('text=Completed')).to_be_visible(timeout=60000)

    def test_awaiting_approval_state_transitions_on_deny(self, agent_helpers: PageHelpers):
        """Test that awaiting approval state transitions to denied on deny."""
        helpers = agent_helpers

        helpers.send_message("Execute bash: echo 'deny test'", wait_for_response=False)

        # Wait for awaiting approval state
        tool = helpers.page.locator('[data-testid="tool"]').last
        expect(tool.locator('text=Awaiting Approval')).to_be_visible(timeout=30000)

        # Deny
        helpers.page.click('[data-testid="permission-deny"]')

        # Should transition to denied
        expect(tool.locator('text=Denied')).to_be_visible(timeout=30000)


@pytest.mark.permission
class TestMultiplePermissionRequests:
    """Tests for handling multiple permission requests."""

    def test_sequential_permission_requests(self, agent_helpers: PageHelpers):
        """Test handling multiple sequential permission requests."""
        helpers = agent_helpers

        helpers.send_message("First run Python: print('first'), then run bash: echo 'second'", wait_for_response=False)

        # First permission dialog
        dialog = helpers.page.locator('[data-testid="permission-dialog"]')
        expect(dialog).to_be_visible(timeout=30000)

        # Approve first
        helpers.page.click('[data-testid="permission-approve"]')

        # Wait for second dialog (if applicable)
        helpers.page.wait_for_timeout(2000)

        if dialog.is_visible():
            # Approve second
            helpers.page.click('[data-testid="permission-approve"]')

        # Both tools should complete
        expect(helpers.page.locator('[data-testid="tool"] >> text=Completed').first).to_be_visible(timeout=60000)


@pytest.mark.permission
class TestPermissionDialogAccessibility:
    """Tests for permission dialog accessibility."""

    def test_dialog_has_focus_trap(self, agent_helpers: PageHelpers):
        """Test that dialog traps focus when open."""
        helpers = agent_helpers

        helpers.send_message("Execute Python: print('focus test')", wait_for_response=False)

        dialog = helpers.page.locator('[data-testid="permission-dialog"]')
        expect(dialog).to_be_visible(timeout=30000)

        # Tab should cycle within dialog
        helpers.page.keyboard.press("Tab")
        focused = helpers.page.evaluate(
            "document.activeElement.closest('[data-testid=\"permission-dialog\"]') !== null"
        )
        assert focused, "Focus should be trapped within dialog"

    def test_dialog_can_be_closed_with_escape(self, agent_helpers: PageHelpers):
        """Test that escape key denies and closes dialog."""
        helpers = agent_helpers

        helpers.send_message("Execute bash: echo 'escape test'", wait_for_response=False)

        dialog = helpers.page.locator('[data-testid="permission-dialog"]')
        expect(dialog).to_be_visible(timeout=30000)

        # Press escape
        helpers.page.keyboard.press("Escape")

        # Dialog should close (treated as deny)
        expect(dialog).not_to_be_visible()
