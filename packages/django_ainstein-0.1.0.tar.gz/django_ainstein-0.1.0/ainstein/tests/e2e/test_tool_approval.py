"""
E2E tests for Claude Agent tool execution and approval flow

Tests tool-related functionality including:
- Tool cards displaying during execution
- Tool states (running, completed, error, denied)
- Tool output display
- Automatic tool execution
"""

import pytest
from playwright.sync_api import expect

from .conftest import PageHelpers


@pytest.mark.tool
class TestToolCardDisplay:
    """Tests for tool card UI display."""

    def test_tool_card_appears_during_execution(self, agent_helpers: PageHelpers):
        """Test that tool card appears when tool is called."""
        helpers = agent_helpers

        # Send a message that triggers a tool
        helpers.send_message("List the files in the current directory", wait_for_response=False)

        # Tool card should appear
        expect(helpers.page.locator('[data-testid="tool"]')).to_be_visible(timeout=30000)

    def test_tool_card_shows_tool_name(self, agent_helpers: PageHelpers):
        """Test that tool card displays the tool name."""
        helpers = agent_helpers

        helpers.send_message("Read the contents of any file", wait_for_response=False)

        # Wait for tool card
        tool_card = helpers.page.locator('[data-testid="tool"]').first
        expect(tool_card).to_be_visible(timeout=30000)

        # Tool name should be visible
        tool_name = tool_card.locator('[data-testid="tool-name"]')
        expect(tool_name).to_be_visible()
        expect(tool_name).not_to_be_empty()


@pytest.mark.tool
class TestToolStates:
    """Tests for tool state transitions."""

    def test_tool_shows_running_state(self, agent_helpers: PageHelpers):
        """Test that tool shows running state during execution."""
        helpers = agent_helpers

        helpers.send_message("Execute a command that takes a moment", wait_for_response=False)

        # Should show running state
        expect(helpers.page.locator('[data-testid="tool"] >> text=Running')).to_be_visible(timeout=30000)

    def test_tool_shows_completed_state(self, agent_helpers: PageHelpers):
        """Test that tool shows completed state after success."""
        helpers = agent_helpers

        helpers.send_message("What's 2 + 2?")

        # Should eventually show completed state for any tools used
        tools = helpers.page.locator('[data-testid="tool"]')
        if tools.count() > 0:
            expect(tools.last.locator('text=Completed')).to_be_visible(timeout=60000)

    def test_tool_shows_error_state_on_failure(self, agent_helpers: PageHelpers):
        """Test that tool shows error state when execution fails."""
        helpers = agent_helpers

        # Try to trigger an error (e.g., reading non-existent file)
        helpers.send_message("Read the file /nonexistent/path/to/file.txt")

        # Tool should show error state
        tool_card = helpers.page.locator('[data-testid="tool"]').last
        # Either error state or error message in output
        expect(tool_card.locator('text=Error')).to_be_visible(timeout=60000)


@pytest.mark.tool
class TestToolOutput:
    """Tests for tool output display."""

    def test_tool_output_is_displayed(self, agent_helpers: PageHelpers):
        """Test that tool output is shown in the tool card."""
        helpers = agent_helpers

        # Run a SQL query to get predictable output
        helpers.send_message("Run a SQL query: SELECT 1 as test_column")

        # Tool output should be visible
        tool_card = helpers.page.locator('[data-testid="tool"]').last
        expect(tool_card.locator('[data-testid="tool-output"]')).to_be_visible(timeout=60000)

    def test_tool_stats_are_displayed(self, agent_helpers: PageHelpers):
        """Test that tool execution stats are shown."""
        helpers = agent_helpers

        # Run a query that returns rows
        helpers.send_message("Query the database for any table with at least one row")

        # Stats badges should appear
        tool_card = helpers.page.locator('[data-testid="tool"]').last
        # Look for time or row count badges
        stats_section = tool_card.locator('[data-testid="tool-stats"]')
        if stats_section.is_visible():
            expect(stats_section).not_to_be_empty()

    def test_tool_diff_is_displayed_for_writes(self, agent_helpers: PageHelpers):
        """Test that diff is shown for file write operations."""
        helpers = agent_helpers

        # Create/modify a file
        helpers.send_message("Create a file called test_e2e.txt with 'Hello World' content")

        # Diff should be visible
        tool_card = helpers.page.locator('[data-testid="tool"]').last
        diff_section = tool_card.locator('[data-testid="tool-diff"]')
        if diff_section.is_visible():
            # Should show additions
            expect(diff_section.locator('text=+')).to_be_visible()


@pytest.mark.tool
class TestToolCollapsible:
    """Tests for tool card expand/collapse behavior."""

    def test_tool_card_can_be_expanded(self, agent_helpers: PageHelpers):
        """Test that tool card can be expanded to show details."""
        helpers = agent_helpers

        helpers.send_message("Show me the current time")

        # Find tool card
        tool_card = helpers.page.locator('[data-testid="tool"]').last
        expect(tool_card).to_be_visible(timeout=60000)

        # Click to expand (if collapsed by default)
        trigger = tool_card.locator('[data-testid="tool-trigger"]')
        if trigger.is_visible():
            trigger.click()

            # Content should be visible
            expect(tool_card.locator('[data-testid="tool-content"]')).to_be_visible()

    def test_tool_card_remembers_expanded_state(self, agent_helpers: PageHelpers):
        """Test that tool card expansion state is preserved."""
        helpers = agent_helpers

        helpers.send_message("What's today's date?")

        tool_card = helpers.page.locator('[data-testid="tool"]').last
        trigger = tool_card.locator('[data-testid="tool-trigger"]')

        if trigger.is_visible():
            # Expand the card
            trigger.click()

            # Send another message
            helpers.send_message("Thanks!")

            # Previous tool should still be expanded
            expect(tool_card.locator('[data-testid="tool-content"]')).to_be_visible()


@pytest.mark.tool
class TestMultipleTools:
    """Tests for handling multiple tool calls."""

    def test_multiple_tools_displayed_in_order(self, agent_helpers: PageHelpers):
        """Test that multiple tool calls are displayed in execution order."""
        helpers = agent_helpers

        # Trigger multiple tool calls
        helpers.send_message("First read the contents of package.json, then list all Python files")

        # Multiple tool cards should appear
        tools = helpers.page.locator('[data-testid="tool"]')
        expect(tools).to_have_count(lambda n: n >= 1, timeout=60000)

    def test_chain_of_tools_completes_correctly(self, agent_helpers: PageHelpers):
        """Test that a chain of tools all complete successfully."""
        helpers = agent_helpers

        helpers.send_message("Query the database for projects, then read the first project's folder")

        # All tools should complete
        helpers.page.wait_for_timeout(5000)  # Allow time for tools to complete

        tools = helpers.page.locator('[data-testid="tool"]')
        for i in range(tools.count()):
            tool = tools.nth(i)
            # Should not be stuck in running state
            expect(tool.locator('text=Running')).not_to_be_visible(timeout=60000)
