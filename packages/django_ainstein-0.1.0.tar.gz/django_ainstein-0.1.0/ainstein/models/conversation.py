"""AiConversation and AiConversationMessage models."""

from decimal import Decimal

from django.conf import settings
from django.db import models
from django_extensions.db.models import TimeStampedModel


class AiConversation(TimeStampedModel):
    """
    Stores Claude Agent conversation metadata.
    Messages are stored in the related AiConversationMessage model.
    """

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="ai_conversations",
    )
    project = models.ForeignKey(
        "ainstein.AiProject",
        on_delete=models.CASCADE,
        related_name="conversations",
        null=True,
        blank=True,
        help_text="Project this conversation belongs to",
    )
    title = models.CharField(max_length=255, blank=True, default="")
    session_id = models.CharField(
        max_length=255,
        unique=True,
        null=True,
        blank=True,
        help_text="Claude SDK session identifier (set after first message)",
    )
    # Cumulative cost tracking (USD)
    total_cost_usd = models.DecimalField(
        max_digits=12,
        decimal_places=8,
        default=0,
        help_text="Cumulative total cost in USD for all messages",
    )
    # Cumulative token usage
    total_input_tokens = models.PositiveIntegerField(default=0)
    total_output_tokens = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["-modified"]
        verbose_name = "AI Conversation"
        verbose_name_plural = "AI Conversations"

    def __str__(self):
        return f"{self.title or 'Untitled'} ({self.messages.count()} messages)"

    @property
    def message_count(self):
        return self.messages.count()

    def add_message(self, role: str, content: str, metadata: dict = None):
        """Add a message to the conversation."""
        message = AiConversationMessage.objects.create(
            conversation=self,
            role=role,
            content=content,
            metadata=metadata or {},
        )

        # Generate title from first user message
        if not self.title and role == "user":
            self.title = content[:50] + ("..." if len(content) > 50 else "")
            self.save(update_fields=["title", "modified"])

        return message

    def get_messages_list(self):
        """Get messages as a list of dicts for API response."""
        return list(self.messages.values("id", "role", "content", "metadata", "created").order_by("created"))

    def add_cost(self, cost_usd: float, input_tokens: int = 0, output_tokens: int = 0):
        """Add cost and token usage to cumulative totals."""
        from django.db.models import F

        AiConversation.objects.filter(pk=self.pk).update(
            total_cost_usd=F("total_cost_usd") + Decimal(str(cost_usd)),
            total_input_tokens=F("total_input_tokens") + input_tokens,
            total_output_tokens=F("total_output_tokens") + output_tokens,
        )
        self.refresh_from_db()


class AiConversationMessage(TimeStampedModel):
    """Individual message in a conversation with ResultMessage metrics."""

    ROLE_CHOICES = [
        ("user", "User"),
        ("assistant", "Assistant"),
        ("system", "System"),
    ]

    SUBTYPE_CHOICES = [
        ("user_input", "User Input"),
        ("assistant_response", "Assistant Response"),
        ("tool_result", "Tool Result"),
        ("error", "Error"),
        ("system", "System"),
    ]

    conversation = models.ForeignKey(
        AiConversation,
        on_delete=models.CASCADE,
        related_name="messages",
    )
    role = models.CharField(max_length=20, choices=ROLE_CHOICES)
    content = models.TextField()
    metadata = models.JSONField(default=dict, blank=True, help_text="Additional data like HTML rendering")

    # ResultMessage tracking fields
    subtype = models.CharField(
        max_length=30,
        choices=SUBTYPE_CHOICES,
        blank=True,
        default="",
        help_text="Message subtype from ResultMessage",
    )
    duration_ms = models.PositiveIntegerField(
        default=0,
        help_text="Total duration in milliseconds",
    )
    duration_api_ms = models.PositiveIntegerField(
        default=0,
        help_text="API call duration in milliseconds",
    )
    is_error = models.BooleanField(
        default=False,
        help_text="Whether this message represents an error",
    )
    num_turns = models.PositiveIntegerField(
        default=0,
        help_text="Number of conversation turns",
    )
    cost_usd = models.DecimalField(
        max_digits=12,
        decimal_places=8,
        null=True,
        blank=True,
        help_text="Cost in USD for this message",
    )
    usage = models.JSONField(
        default=dict,
        blank=True,
        help_text="Token usage breakdown {input_tokens, output_tokens, cache_read_input_tokens, etc.}",
    )

    class Meta:
        ordering = ["created"]
        verbose_name = "Message"
        verbose_name_plural = "Messages"

    def __str__(self):
        preview = self.content[:50] + "..." if len(self.content) > 50 else self.content
        return f"{self.role}: {preview}"

    def update_from_result(
        self,
        subtype: str = "",
        duration_ms: int = 0,
        duration_api_ms: int = 0,
        is_error: bool = False,
        num_turns: int = 0,
        cost_usd: float = None,
        usage: dict = None,
    ):
        """Update message with ResultMessage data and update conversation totals."""
        self.subtype = subtype
        self.duration_ms = duration_ms
        self.duration_api_ms = duration_api_ms
        self.is_error = is_error
        self.num_turns = num_turns
        if cost_usd is not None:
            self.cost_usd = Decimal(str(cost_usd))
        if usage:
            self.usage = usage
        self.save()

        # Update conversation cumulative cost
        if cost_usd and cost_usd > 0:
            input_tokens = usage.get("input_tokens", 0) if usage else 0
            output_tokens = usage.get("output_tokens", 0) if usage else 0
            self.conversation.add_cost(cost_usd, input_tokens, output_tokens)
