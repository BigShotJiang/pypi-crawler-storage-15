"""AiCostLimit model - cost limits per project."""

from decimal import Decimal

from django.db import models
from django.utils import timezone
from django_extensions.db.models import TimeStampedModel


class AiCostLimit(TimeStampedModel):
    """
    Cost limits per project.
    Tracks spending and enforces limits.
    """

    project = models.OneToOneField(
        "ainstein.AiProject",
        on_delete=models.CASCADE,
        related_name="cost_limit",
    )

    # Limits
    daily_limit = models.DecimalField(
        max_digits=10,
        decimal_places=4,
        default=Decimal("10.00"),
        help_text="Daily cost limit in USD",
    )
    monthly_limit = models.DecimalField(
        max_digits=10,
        decimal_places=4,
        default=Decimal("100.00"),
        help_text="Monthly cost limit in USD",
    )

    # Usage tracking
    daily_usage = models.DecimalField(max_digits=10, decimal_places=6, default=Decimal("0"))
    monthly_usage = models.DecimalField(max_digits=10, decimal_places=6, default=Decimal("0"))
    total_usage = models.DecimalField(max_digits=12, decimal_places=6, default=Decimal("0"))

    # Reset tracking
    daily_reset_date = models.DateField(default=timezone.localdate)
    monthly_reset_date = models.DateField(default=timezone.localdate)

    # Alerts
    alert_threshold = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=Decimal("0.80"),
        help_text="Alert when usage exceeds this percentage (0.80 = 80%)",
    )
    alert_sent_daily = models.BooleanField(default=False)
    alert_sent_monthly = models.BooleanField(default=False)

    class Meta:
        verbose_name = "Cost Limit"
        verbose_name_plural = "Cost Limits"

    def __str__(self):
        return f"{self.project.name} - ${self.daily_usage}/{self.daily_limit} daily"

    def check_and_add_cost(self, cost: Decimal) -> tuple[bool, str]:
        """
        Check if cost is within limits and add it.
        Returns (allowed, reason).
        """
        today = timezone.now().date()

        # Reset daily if needed
        if self.daily_reset_date < today:
            self.daily_usage = Decimal("0")
            self.daily_reset_date = today
            self.alert_sent_daily = False

        # Reset monthly if needed
        if self.monthly_reset_date.month != today.month or self.monthly_reset_date.year != today.year:
            self.monthly_usage = Decimal("0")
            self.monthly_reset_date = today
            self.alert_sent_monthly = False

        # Check limits
        if self.daily_usage + cost > self.daily_limit:
            return False, f"Daily cost limit exceeded: ${self.daily_limit}"

        if self.monthly_usage + cost > self.monthly_limit:
            return False, f"Monthly cost limit exceeded: ${self.monthly_limit}"

        # Add cost
        self.daily_usage += cost
        self.monthly_usage += cost
        self.total_usage += cost
        self.save()

        return True, ""

    @classmethod
    def get_or_create_for_project(cls, project) -> "AiCostLimit":
        """Get or create cost limit for project."""
        cost_limit, _ = cls.objects.get_or_create(project=project)
        return cost_limit
