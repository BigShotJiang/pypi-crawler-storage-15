"""AiWorkflow and AiWorkflowRun models - workflow automation."""

import uuid

from django.conf import settings
from django.db import models
from django_extensions.db.models import TimeStampedModel


class AiWorkflow(TimeStampedModel):
    """
    Workflow template for multi-step automation.
    Defines a sequence of operations to execute.
    """

    TRIGGER_CHOICES = [
        ("manual", "Manual"),
        ("schedule", "Scheduled"),
        ("webhook", "Webhook"),
        ("file_upload", "File Upload"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=255)
    slug = models.SlugField(max_length=255)
    description = models.TextField(blank=True, default="")

    # Ownership
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="ai_workflows",
    )
    project = models.ForeignKey(
        "ainstein.AiProject",
        on_delete=models.CASCADE,
        related_name="workflows",
    )

    # Workflow definition
    steps = models.JSONField(
        default=list,
        help_text="List of workflow steps [{tool, args, output_var}, ...]",
    )
    trigger = models.CharField(max_length=20, choices=TRIGGER_CHOICES, default="manual")

    # Scheduling (for trigger='schedule')
    schedule_cron = models.CharField(
        max_length=100,
        blank=True,
        default="",
        help_text="Cron expression for scheduled workflows",
    )
    next_run = models.DateTimeField(null=True, blank=True)
    last_run = models.DateTimeField(null=True, blank=True)

    # Status
    is_active = models.BooleanField(default=True)
    run_count = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["-modified"]
        unique_together = [["user", "project", "slug"]]
        verbose_name = "AI Workflow"
        verbose_name_plural = "AI Workflows"

    def __str__(self):
        return f"{self.name} ({len(self.steps)} steps)"


class AiWorkflowRun(TimeStampedModel):
    """Record of a workflow execution."""

    STATUS_CHOICES = [
        ("pending", "Pending"),
        ("running", "Running"),
        ("completed", "Completed"),
        ("failed", "Failed"),
        ("cancelled", "Cancelled"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    workflow = models.ForeignKey(
        AiWorkflow,
        on_delete=models.CASCADE,
        related_name="runs",
    )
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="workflow_runs",
    )

    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="pending")
    started_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)

    # Execution details
    input_data = models.JSONField(default=dict, blank=True)
    output_data = models.JSONField(default=dict, blank=True)
    step_results = models.JSONField(
        default=list,
        blank=True,
        help_text="Results from each step",
    )
    error_message = models.TextField(blank=True, default="")
    current_step = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["-created"]
        verbose_name = "Workflow Run"
        verbose_name_plural = "Workflow Runs"

    def __str__(self):
        return f"{self.workflow.name} - {self.status}"
