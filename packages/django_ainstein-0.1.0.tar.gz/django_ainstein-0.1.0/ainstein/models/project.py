"""AiProject model - manages project storage and file operations."""

import os
import uuid
from functools import cached_property

from django.conf import settings
from django.core.files.base import ContentFile
from django.core.files.storage import storages
from django.db import models
from django_extensions.db.models import TimeStampedModel


def get_agent_storage():
    """Get the agent storage backend."""
    return storages["agent"]


def generate_external_id():
    """Generate a unique external ID for projects."""
    return uuid.uuid4().hex[:16]


class AiProjectManager(models.Manager):
    """Manager for AiProject with business logic methods."""

    def get_or_create_default(self, user):
        """Get or create the default project for a user."""
        project = self.filter(user=user).order_by("created").first()
        if project:
            return project
        return self.create(
            user=user,
            name="Default Project",
            slug=f"default-{user.id}",
            description="Default project for AI conversations",
        )


class NamespacedStorage:
    """Storage wrapper that prefixes all paths with a namespace."""

    def __init__(self, storage, prefix: str):
        self.storage = storage
        self.prefix = prefix.rstrip("/")

    def _path(self, name: str) -> str:
        """Sanitize and prefix the path."""
        # Remove null bytes and normalize
        clean = name.replace("\x00", "").strip()
        normalized = os.path.normpath(clean).replace("\\", "/")

        # Remove leading slashes and traversal components
        while normalized.startswith("/") or normalized.startswith("../"):
            normalized = normalized.lstrip("/").removeprefix("../")
        if normalized == "..":
            normalized = ""

        return f"{self.prefix}/{normalized}" if normalized else self.prefix

    def exists(self, name: str) -> bool:
        return self.storage.exists(self._path(name))

    def open(self, name: str, mode: str = "rb"):
        return self.storage.open(self._path(name), mode)

    def save(self, name: str, content) -> str:
        return self.storage.save(self._path(name), content)

    def delete(self, name: str):
        return self.storage.delete(self._path(name))

    def listdir(self, path: str = ""):
        return self.storage.listdir(self._path(path))

    def size(self, name: str) -> int:
        return self.storage.size(self._path(name))

    @property
    def location(self):
        return self.storage.location


class AiProject(TimeStampedModel):
    """
    AI Project that groups conversations and manages file storage.
    Each project has its own folder for storing files created during conversations.
    """

    external_id = models.CharField(
        max_length=32,
        unique=True,
        editable=False,
        default=generate_external_id,
        help_text="Unique identifier for storage folder",
    )
    name = models.CharField(max_length=255)
    slug = models.SlugField(max_length=255, unique=True)
    description = models.TextField(blank=True, default="")
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="ai_projects",
    )
    is_shared = models.BooleanField(
        default=False,
        help_text="Shared projects are visible to all team members",
    )

    objects = AiProjectManager()

    class Meta:
        ordering = ["-modified"]
        verbose_name = "AI Project"
        verbose_name_plural = "AI Projects"

    def __str__(self):
        return self.name

    @cached_property
    def storage(self):
        """Get the namespaced storage backend for this project."""
        return NamespacedStorage(storages["agent"], f"projects/{self.external_id}")

    @property
    def folder_path(self):
        """Get the project's folder path in storage."""
        return self.storage.prefix

    def get_full_path(self, relative_path: str) -> str:
        """Get full storage path from project-relative path (delegates to storage)."""
        return self.storage._path(relative_path)

    @property
    def conversation_count(self):
        return self.conversations.count()

    def read_file(self, path: str) -> str:
        """Read a file from the project folder."""
        if not self.storage.exists(path):
            raise FileNotFoundError(f"File not found: {path}")
        with self.storage.open(path, "rb") as f:
            return f.read().decode("utf-8", errors="replace")

    def write_file(self, path: str, content: str) -> int:
        """Write a file to the project folder. Returns size in bytes."""
        if self.storage.exists(path):
            self.storage.delete(path)
        self.storage.save(path, ContentFile(content.encode("utf-8")))
        return len(content)

    def file_exists(self, path: str) -> bool:
        """Check if a file exists in the project folder."""
        return self.storage.exists(path)

    def delete_file(self, path: str) -> bool:
        """Delete a file from the project folder."""
        if self.storage.exists(path):
            self.storage.delete(path)
            return True
        return False

    def create_folder(self, path: str) -> bool:
        """Create a folder in the project directory."""
        full_path = os.path.join(self.storage.location, self.storage._path(path))
        os.makedirs(full_path, exist_ok=True)
        return True

    def save_file(self, filename: str, content) -> str:
        """Save a file with a unique name. Returns the saved file path."""
        ext = os.path.splitext(filename)[1]
        unique_name = f"{uuid.uuid4().hex}{ext}"
        return self.storage.save(unique_name, content)

    def list_files(self) -> list:
        """List all files in the project's root folder."""
        try:
            dirs, files = self.storage.listdir("")
            return files
        except FileNotFoundError:
            return []
