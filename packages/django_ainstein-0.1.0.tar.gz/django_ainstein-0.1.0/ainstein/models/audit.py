"""AiAuditLog model - security audit logging."""

import uuid

from django.conf import settings
from django.db import models
from django.utils import timezone


class AiAuditLog(models.Model):
    """
    Audit log for all tool executions.
    Records who did what, when, and the result.
    """

    ACTION_CHOICES = [
        ("tool_call", "Tool Call"),
        ("file_read", "File Read"),
        ("file_write", "File Write"),
        ("file_delete", "File Delete"),
        ("query", "Database Query"),
        ("export", "Data Export"),
        ("code_exec", "Code Execution"),
        ("workflow_run", "Workflow Run"),
        ("permission_grant", "Permission Grant"),
        ("permission_deny", "Permission Deny"),
        ("rate_limit", "Rate Limited"),
        ("cost_limit", "Cost Limited"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    timestamp = models.DateTimeField(default=timezone.now, db_index=True)

    # Who
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        related_name="ai_audit_logs",
    )
    project = models.ForeignKey(
        "ainstein.AiProject",
        on_delete=models.SET_NULL,
        null=True,
        related_name="audit_logs",
    )
    conversation = models.ForeignKey(
        "ainstein.AiConversation",
        on_delete=models.SET_NULL,
        null=True,
        related_name="audit_logs",
    )

    # What
    action = models.CharField(max_length=30, choices=ACTION_CHOICES, db_index=True)
    tool_name = models.CharField(max_length=100, blank=True, default="")
    description = models.TextField(blank=True, default="")

    # Details
    request_data = models.JSONField(
        default=dict,
        blank=True,
        help_text="Sanitized request parameters",
    )
    response_summary = models.TextField(
        blank=True,
        default="",
        help_text="Summary of the response",
    )

    # Result
    success = models.BooleanField(default=True)
    error_message = models.TextField(blank=True, default="")
    duration_ms = models.PositiveIntegerField(default=0)

    # Security flags
    contains_sensitive_data = models.BooleanField(
        default=False,
        help_text="Flag if sensitive data was detected",
    )
    ip_address = models.GenericIPAddressField(null=True, blank=True)

    class Meta:
        ordering = ["-timestamp"]
        verbose_name = "Audit Log"
        verbose_name_plural = "Audit Logs"
        indexes = [
            models.Index(fields=["user", "-timestamp"]),
            models.Index(fields=["project", "-timestamp"]),
            models.Index(fields=["action", "-timestamp"]),
        ]

    def __str__(self):
        return f"{self.timestamp} - {self.user} - {self.action}"

    @classmethod
    def log(
        cls,
        action: str,
        user=None,
        project=None,
        conversation=None,
        tool_name: str = "",
        description: str = "",
        request_data: dict = None,
        response_summary: str = "",
        success: bool = True,
        error_message: str = "",
        duration_ms: int = 0,
        contains_sensitive_data: bool = False,
        ip_address: str = None,
    ) -> "AiAuditLog":
        """Create an audit log entry."""
        return cls.objects.create(
            action=action,
            user=user,
            project=project,
            conversation=conversation,
            tool_name=tool_name,
            description=description,
            request_data=request_data or {},
            response_summary=response_summary,
            success=success,
            error_message=error_message,
            duration_ms=duration_ms,
            contains_sensitive_data=contains_sensitive_data,
            ip_address=ip_address,
        )
