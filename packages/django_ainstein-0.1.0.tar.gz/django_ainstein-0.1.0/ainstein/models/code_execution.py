"""AiCodeExecution model - tracks remote code execution calls."""

import uuid

from django.db import models
from django_extensions.db.models import TimeStampedModel


class AiCodeExecution(TimeStampedModel):
    """
    Track remote code execution calls via Anthropic's code execution API.
    Links to conversation messages and stores execution details.
    """

    STATUS_CHOICES = [
        ("pending", "Pending"),
        ("running", "Running"),
        ("completed", "Completed"),
        ("failed", "Failed"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)

    # Link to conversation
    message = models.ForeignKey(
        "ainstein.AiConversationMessage",
        on_delete=models.CASCADE,
        related_name="code_executions",
        null=True,
        blank=True,
        help_text="Message that triggered this execution",
    )
    conversation = models.ForeignKey(
        "ainstein.AiConversation",
        on_delete=models.CASCADE,
        related_name="code_executions",
        help_text="Conversation this execution belongs to",
    )

    # Execution details
    code = models.TextField(help_text="The code that was executed")
    language = models.CharField(max_length=20, default="python")
    purpose = models.CharField(
        max_length=255,
        blank=True,
        default="",
        help_text="Brief description (e.g., 'Generate bar chart')",
    )

    # Status tracking
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="pending")
    started_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    duration_ms = models.PositiveIntegerField(default=0)

    # API response tracking
    api_request_id = models.CharField(
        max_length=255,
        blank=True,
        default="",
        help_text="Anthropic API request ID",
    )
    file_ids = models.JSONField(
        default=list,
        blank=True,
        help_text="List of file IDs returned by the API",
    )

    # Output
    stdout = models.TextField(blank=True, default="")
    stderr = models.TextField(blank=True, default="")
    error_message = models.TextField(blank=True, default="")

    # Generated files (stored in project storage)
    generated_files = models.JSONField(
        default=list,
        blank=True,
        help_text="List of {filename, path, size, mime_type}",
    )

    # Cost tracking
    input_tokens = models.PositiveIntegerField(default=0)
    output_tokens = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["-created"]
        verbose_name = "Code Execution"
        verbose_name_plural = "Code Executions"
        indexes = [
            models.Index(fields=["conversation", "-created"]),
            models.Index(fields=["status"]),
        ]

    def __str__(self):
        return f"{self.purpose or 'Code execution'} - {self.status}"

    @property
    def is_complete(self):
        return self.status in ("completed", "failed")

    def mark_running(self):
        """Mark execution as running."""
        from django.utils import timezone

        self.status = "running"
        self.started_at = timezone.now()
        self.save(update_fields=["status", "started_at", "modified"])

    def mark_completed(self, stdout: str = "", file_ids: list = None, generated_files: list = None):
        """Mark execution as completed successfully."""
        from django.utils import timezone

        self.status = "completed"
        self.completed_at = timezone.now()
        self.stdout = stdout
        if file_ids:
            self.file_ids = file_ids
        if generated_files:
            self.generated_files = generated_files
        if self.started_at:
            self.duration_ms = int((self.completed_at - self.started_at).total_seconds() * 1000)
        self.save()

    def mark_failed(self, error_message: str, stderr: str = ""):
        """Mark execution as failed."""
        from django.utils import timezone

        self.status = "failed"
        self.completed_at = timezone.now()
        self.error_message = error_message
        self.stderr = stderr
        if self.started_at:
            self.duration_ms = int((self.completed_at - self.started_at).total_seconds() * 1000)
        self.save()

    def add_generated_file(self, filename: str, path: str, size: int, mime_type: str = ""):
        """Add a generated file to the list."""
        self.generated_files.append(
            {
                "filename": filename,
                "path": path,
                "size": size,
                "mime_type": mime_type or self.guess_mime_type(filename),
            }
        )
        self.save(update_fields=["generated_files", "modified"])

    @staticmethod
    def guess_mime_type(filename: str) -> str:
        """Guess MIME type from filename."""
        ext = filename.lower().split(".")[-1] if "." in filename else ""
        mime_map = {
            "png": "image/png",
            "jpg": "image/jpeg",
            "jpeg": "image/jpeg",
            "gif": "image/gif",
            "svg": "image/svg+xml",
            "pdf": "application/pdf",
            "csv": "text/csv",
            "json": "application/json",
            "txt": "text/plain",
            "html": "text/html",
        }
        return mime_map.get(ext, "application/octet-stream")
