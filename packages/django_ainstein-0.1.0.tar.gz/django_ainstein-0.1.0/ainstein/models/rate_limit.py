"""AiRateLimitTracker model - rate limiting tracking."""

from django.conf import settings
from django.db import models
from django.utils import timezone

from ainstein.conf import get_settings as get_agent_settings


class AiRateLimitTracker(models.Model):
    """
    Track API usage for rate limiting.
    Uses sliding window algorithm.
    """

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="rate_limit_trackers",
    )
    window_start = models.DateTimeField(default=timezone.now)
    request_count = models.PositiveIntegerField(default=0)
    token_count = models.PositiveIntegerField(default=0)

    # Per-minute tracking
    requests_this_minute = models.PositiveIntegerField(default=0)
    minute_start = models.DateTimeField(default=timezone.now)

    class Meta:
        verbose_name = "Rate Limit Tracker"
        verbose_name_plural = "Rate Limit Trackers"

    def __str__(self):
        return f"{self.user} - {self.request_count} requests"

    def check_and_increment(self, tokens: int = 0) -> tuple[bool, str]:
        """
        Check if request is allowed and increment counters.
        Returns (allowed, reason).
        """
        agent_settings = get_agent_settings()
        now = timezone.now()

        # Reset minute counter if needed
        if (now - self.minute_start).total_seconds() >= 60:
            self.minute_start = now
            self.requests_this_minute = 0

        # Reset hourly window if needed
        if (now - self.window_start).total_seconds() >= 3600:
            self.window_start = now
            self.request_count = 0
            self.token_count = 0

        # Check limits
        max_per_minute = getattr(agent_settings, "RATE_LIMIT_PER_MINUTE", 30)
        max_per_hour = getattr(agent_settings, "RATE_LIMIT_PER_HOUR", 500)
        max_tokens_per_hour = getattr(agent_settings, "RATE_LIMIT_TOKENS_PER_HOUR", 100000)

        if self.requests_this_minute >= max_per_minute:
            return False, f"Rate limit exceeded: {max_per_minute} requests per minute"

        if self.request_count >= max_per_hour:
            return False, f"Rate limit exceeded: {max_per_hour} requests per hour"

        if self.token_count + tokens > max_tokens_per_hour:
            return False, f"Token limit exceeded: {max_tokens_per_hour} tokens per hour"

        # Increment counters
        self.requests_this_minute += 1
        self.request_count += 1
        self.token_count += tokens
        self.save()

        return True, ""

    @classmethod
    def get_or_create_for_user(cls, user) -> "AiRateLimitTracker":
        """Get or create tracker for user."""
        tracker, _ = cls.objects.get_or_create(user=user)
        return tracker
