"""AiScript model - reusable script library for workflow automation."""

import uuid

from django.conf import settings
from django.db import models
from django_extensions.db.models import TimeStampedModel


class AiScript(TimeStampedModel):
    """
    Reusable script library for workflow automation.
    Scripts can be versioned and shared across projects.
    """

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=255)
    slug = models.SlugField(max_length=255)
    description = models.TextField(blank=True, default="")
    code = models.TextField(help_text="Python code to execute")
    version = models.PositiveIntegerField(default=1)

    # Ownership
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="ai_scripts",
    )
    project = models.ForeignKey(
        "ainstein.AiProject",
        on_delete=models.CASCADE,
        related_name="scripts",
        null=True,
        blank=True,
        help_text="Project-specific script, or null for global",
    )

    # Script metadata
    input_schema = models.JSONField(
        default=dict,
        blank=True,
        help_text="JSON schema for expected input files/parameters",
    )
    output_schema = models.JSONField(
        default=dict,
        blank=True,
        help_text="JSON schema for output format",
    )
    tags = models.JSONField(
        default=list,
        blank=True,
        help_text="Tags for categorization",
    )

    # Sharing
    is_public = models.BooleanField(
        default=False,
        help_text="Public scripts are visible to all users",
    )

    class Meta:
        ordering = ["-modified"]
        unique_together = [["user", "slug", "version"]]
        verbose_name = "AI Script"
        verbose_name_plural = "AI Scripts"

    def __str__(self):
        return f"{self.name} v{self.version}"

    def create_new_version(self, code: str, description: str = None) -> "AiScript":
        """Create a new version of this script."""
        return AiScript.objects.create(
            name=self.name,
            slug=self.slug,
            description=description or self.description,
            code=code,
            version=self.version + 1,
            user=self.user,
            project=self.project,
            input_schema=self.input_schema,
            output_schema=self.output_schema,
            tags=self.tags,
            is_public=self.is_public,
        )

    @classmethod
    def get_latest_version(cls, user, slug, project=None):
        """Get the latest version of a script by slug."""
        qs = cls.objects.filter(user=user, slug=slug)
        if project:
            qs = qs.filter(project=project)
        return qs.order_by("-version").first()
