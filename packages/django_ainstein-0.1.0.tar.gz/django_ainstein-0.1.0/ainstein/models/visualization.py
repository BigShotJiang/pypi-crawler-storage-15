"""AiVisualization model - store generated visualizations."""

import uuid

from django.db import models
from django_extensions.db.models import TimeStampedModel


class AiVisualization(TimeStampedModel):
    """
    Store generated visualizations (charts, graphs).
    """

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    project = models.ForeignKey(
        "ainstein.AiProject",
        on_delete=models.CASCADE,
        related_name="visualizations",
    )
    conversation = models.ForeignKey(
        "ainstein.AiConversation",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="visualizations",
    )

    # Visualization metadata
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True, default="")
    chart_type = models.CharField(
        max_length=50,
        default="line",
        help_text="Type: line, bar, scatter, pie, heatmap, etc.",
    )

    # Storage
    image_path = models.CharField(
        max_length=500,
        blank=True,
        default="",
        help_text="Path to PNG image in storage",
    )
    svg_path = models.CharField(
        max_length=500,
        blank=True,
        default="",
        help_text="Path to SVG in storage",
    )
    html_path = models.CharField(
        max_length=500,
        blank=True,
        default="",
        help_text="Path to interactive HTML (Plotly)",
    )

    # Source data
    source_code = models.TextField(
        blank=True,
        default="",
        help_text="Python code that generated this visualization",
    )
    data_summary = models.JSONField(
        default=dict,
        blank=True,
        help_text="Summary of data used",
    )

    class Meta:
        ordering = ["-created"]
        verbose_name = "Visualization"
        verbose_name_plural = "Visualizations"

    def __str__(self):
        return f"{self.title} ({self.chart_type})"
