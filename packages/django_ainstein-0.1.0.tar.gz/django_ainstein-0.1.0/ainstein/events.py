"""
Event types and permission handling for Claude Agent.

This module provides:
- EventType: Enum of all event types
- Event: Dataclass representing an event
- Permission request/response system for human-in-the-loop
"""

import json
import logging
import threading
from dataclasses import dataclass
from dataclasses import field as dataclass_field
from enum import Enum

from django.core.serializers.json import DjangoJSONEncoder


logger = logging.getLogger(__name__)


# =============================================================================
# Event Types
# =============================================================================


class EventType(str, Enum):
    STEP_START = "step_start"
    STEP_DONE = "step_done"
    AGENT_TEXT = "agent_text"
    THINKING_BLOCK_START = "thinking_block_start"  # Marks start of a new thinking block
    AGENT_THINKING = "agent_thinking"  # Chain-of-thought / reasoning content
    TOOL_START = "tool_start"
    TOOL_RESULT = "tool_result"
    TOOL_ERROR = "tool_error"
    SQL = "sql"
    DATA_PREVIEW = "data_preview"
    DIFF = "diff"
    ERROR = "error"
    SESSION_ID = "session_id"
    PERMISSION_REQUEST = "permission_request"


@dataclass
class Event:
    type: EventType
    data: dict = dataclass_field(default_factory=dict)

    def to_dict(self) -> dict:
        return {"type": self.type.value, **self.data}

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), cls=DjangoJSONEncoder)


# =============================================================================
# Permission Request System (Human-in-the-Loop)
# =============================================================================

# Global registry for pending permission requests
# Key: request_id, Value: {"event": threading.Event, "approved": bool | None}
pending_permissions: dict[str, dict] = {}
permissions_lock = threading.Lock()


def request_permission(request_id: str, timeout: float = 300.0) -> bool:
    """
    Wait for user permission response.

    Args:
        request_id: Unique identifier for this permission request
        timeout: Maximum time to wait in seconds (default 5 minutes)

    Returns:
        True if approved, False if denied or timeout
    """
    event = threading.Event()
    with permissions_lock:
        pending_permissions[request_id] = {"event": event, "approved": None}

    # Wait for user response
    got_response = event.wait(timeout=timeout)

    with permissions_lock:
        result = pending_permissions.pop(request_id, {})
        approved = result.get("approved", False)

    if not got_response:
        logger.warning(f"Permission request {request_id} timed out")
        return False

    return approved


def submit_permission_response(request_id: str, approved: bool) -> bool:
    """
    Submit user's permission response.

    Args:
        request_id: The permission request ID
        approved: True if user approved, False if denied

    Returns:
        True if request was found and response submitted, False otherwise
    """
    with permissions_lock:
        if request_id not in pending_permissions:
            logger.warning(f"Permission request {request_id} not found")
            return False

        pending_permissions[request_id]["approved"] = approved
        pending_permissions[request_id]["event"].set()
        return True
