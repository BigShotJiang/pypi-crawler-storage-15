"""
Claude Agent Views

Provides a CLI-like web interface for interacting with the Claude Agent SDK.
Uses Server-Sent Events (SSE) for real-time streaming of agent responses.

Views follow DRF ViewSet pattern with OpenapiMixin for schema generation.
"""

import asyncio
import json
import logging
import queue
import threading
import uuid
from datetime import date, datetime
from decimal import Decimal

from asgiref.sync import sync_to_async
from django.contrib.admin.views.decorators import staff_member_required
from django.db.models import Max, Q
from django.db.models.functions import Coalesce
from django.http import StreamingHttpResponse
from django.shortcuts import get_object_or_404
from django.utils.decorators import method_decorator
from django.utils.text import slugify
from django.views.generic import TemplateView
from rest_framework import permissions, viewsets
from rest_framework.response import Response

from util.open_api_util import (
    ActionRequest,
    OpenapiMixin,
    OpenApiResponse,
    detail_action,
    list_action,
    register_open_api,
)
from util.view_set_util import DetailSerializer, DisablePagination

from .hooks import get_permission_manager
from .models import AiConversation, AiConversationMessage, AiProject
from .serializers import (
    AddMessageSerializer,
    AiConversationCreateSerializer,
    AiConversationListSerializer,
    AiConversationSerializer,
    AiProjectCreateSerializer,
    AiProjectListSerializer,
    AiProjectSerializer,
    CancelStreamSerializer,
    FileListItemSerializer,
    ImprovedPromptSerializer,
    ImprovePromptSerializer,
    PermissionResponseSerializer,
    SetSessionSerializer,
    StreamMessageSerializer,
    UpdateCostSerializer,
)
from .services import AinsteinService, EventType, improve_prompt, submit_permission_response


logger = logging.getLogger(__name__)

# Track active streams for cancellation
# Key: stream_id, Value: {"cancelled": bool, "thread": Thread}
active_streams = {}


CHAT_CONTEXT = {
    "title": "Claude Agent",
    "available_tools": [
        {"name": "django_list_models", "description": "List all available Django models"},
        {"name": "django_describe_model", "description": "Get field information for a model"},
        {"name": "django_query", "description": "Query a model with filters"},
        {"name": "django_aggregate", "description": "Run aggregate functions (count, sum, avg, etc.)"},
        {"name": "django_raw_sql", "description": "Execute raw SQL queries (SELECT only)"},
        {"name": "execute_code", "description": "Execute Python code (requires approval)"},
        {"name": "storage_read", "description": "Read a file from storage"},
        {"name": "storage_write", "description": "Write/create a file in storage"},
        {"name": "storage_delete", "description": "Delete a file from storage"},
        {"name": "storage_list", "description": "List files and directories"},
        {"name": "storage_exists", "description": "Check if a file exists"},
    ],
    "example_prompts": [
        "List all available Django models",
        "What's the rlsbb.Show with the most episodes?",
        "Get aggregate statistics for all models",
        "Write a summary report to analysis.txt",
    ],
}


# =============================================================================
# Permission Classes
# =============================================================================


class IsStaffUser(permissions.BasePermission):
    """Only allow staff users."""

    def has_permission(self, request, view):
        return request.user and request.user.is_staff


# =============================================================================
# Template Views
# =============================================================================


@method_decorator(staff_member_required, name="dispatch")
class AinsteinView(TemplateView):
    """
    Main Insight Agent SPA view.

    Serves the React application for both projects dashboard and conversation pages.
    The React Router handles client-side routing.
    """

    template_name = "ainstein/agent-app.html"

    def get_context_data(self, **kwargs):
        from django.urls import reverse

        context = super().get_context_data(**kwargs)

        # Derive URLs from projects_page which is at /ainstein/staff/p/
        # API is at /ainstein/v1/
        page_base_url = reverse("ainstein:projects_page").rstrip("/")  # /ainstein/staff/p
        api_base_url = page_base_url.rsplit("/staff/", 1)[0] + "/v1/"  # /ainstein/v1/

        context.update(
            {
                "api_base_url": api_base_url,
                "page_base_url": page_base_url,
                **CHAT_CONTEXT,
            }
        )

        # If viewing a specific conversation, validate access and set context
        conversation_id = self.kwargs.get("conversation_id")
        if conversation_id:
            conversation = get_object_or_404(AiConversation, id=conversation_id, user=self.request.user)
            context["title"] = f"Conversation - {conversation.title or 'Untitled'}"
            context["conversation_id"] = conversation_id
        else:
            context["title"] = "Insight Agent"

        return context


# =============================================================================
# Helper Functions
# =============================================================================


def make_json_serializable(obj):
    """Convert non-JSON-serializable objects to serializable types."""
    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    if isinstance(obj, Decimal):
        return float(obj)
    if isinstance(obj, dict):
        return {k: make_json_serializable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [make_json_serializable(item) for item in obj]
    return obj


def stream_events_sync(
    message: str, conversation_id: int = None, resume_session_id: str = None, stream_id: str = None, user=None
):
    """
    Sync generator that streams SSE events using a background thread.

    This approach runs the entire async operation in a dedicated thread with its own
    event loop, using a queue to stream events back to the main thread in real-time.
    """
    event_queue = queue.Queue()
    SENTINEL = object()
    stream_id = stream_id or str(uuid.uuid4())

    save_complete_event = threading.Event()
    stream_state = {
        "cancelled": False,
        "save_complete": save_complete_event,
        "service": None,  # Will be set when service is created
        "loop": None,  # Event loop for interrupt
    }
    active_streams[stream_id] = stream_state

    def is_cancelled():
        return stream_state.get("cancelled", False)

    def run_async_in_thread():
        logger.info(f"[Stream {stream_id}] Starting async thread")
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        stream_state["loop"] = loop  # Store loop for interrupt

        async def process():
            was_cancelled = False
            try:
                logger.info(f"[Stream {stream_id}] Process started, message: {message[:50]}...")
                conversation = None
                project = None
                project_folder = None
                if conversation_id:
                    try:
                        conversation = await sync_to_async(
                            lambda: AiConversation.objects.select_related("project").get(id=conversation_id)
                        )()
                        logger.info(f"[Stream {stream_id}] Loaded conversation {conversation_id}")
                        old_title = conversation.title
                        # Cache project before refresh_from_db clears the cache
                        project = conversation.project
                        if project:
                            project_folder = project.folder_path
                            logger.info(f"[Stream {stream_id}] Project folder: {project_folder}")
                        user_msg = await sync_to_async(conversation.add_message)("user", message)
                        logger.info(f"[Stream {stream_id}] Added user message to conversation")
                        # Send user message ID so frontend can update temp ID
                        event_queue.put(f'data: {{"type": "user_message_saved", "message_id": {user_msg.id}}}\n\n')
                        # Refresh to get updated title (this clears related object cache)
                        await sync_to_async(conversation.refresh_from_db)()
                        # Send title update event if title was set from first message
                        if conversation.title and conversation.title != old_title:
                            event_queue.put(
                                f'data: {{"type": "title_updated", "title": {json.dumps(conversation.title)}}}\n\n'
                            )
                    except AiConversation.DoesNotExist:
                        logger.warning(f"[Stream {stream_id}] Conversation {conversation_id} not found")

                events_list = []
                current_tool = None
                session_id = None
                step_cost = 0.0
                result_data = None  # ResultMessage data for saving to DB

                project_id = project.id if project else None
                logger.info(f"[Stream {stream_id}] Creating AinsteinService, resume_session_id={resume_session_id}")
                async with AinsteinService(
                    output_mode="events",
                    resume_session_id=resume_session_id,
                    project_folder=project_folder,
                    project_id=project_id,  # Pass project ID for building URLs
                    sse_queue=event_queue,  # Pass queue for immediate event streaming
                    is_cancelled=is_cancelled,  # Pass cancellation check to tools
                    user=user,  # Django User for tool context
                    project=project,  # AiProject for tool context
                    conversation=conversation,  # AiConversation for tool context
                ) as service:
                    stream_state["service"] = service  # Store service for interrupt
                    logger.info(f"[Stream {stream_id}] AinsteinService initialized, starting chat")
                    async for event in service.chat(message):
                        # Log events with useful details (skip noisy agent_text)
                        event_type = event.type.value
                        if event_type == "tool_start":
                            tool_name = event.data.get("tool", "?")
                            args_summary = event.data.get("args_summary", "")
                            logger.debug(f"[Stream {stream_id}] Tool: {tool_name}({args_summary})")
                        elif event_type == "tool_result":
                            summary = event.data.get("summary", "")
                            logger.debug(f"[Stream {stream_id}] Result: {summary}")
                        elif event_type == "tool_error":
                            error = event.data.get("error", "")
                            logger.warning(f"[Stream {stream_id}] Tool error: {error}")
                        elif event_type not in ("agent_text", "agent_thinking", "data_preview"):
                            logger.debug(f"[Stream {stream_id}] Event: {event_type}")
                        if is_cancelled():
                            was_cancelled = True
                            logger.info(f"Stream {stream_id} cancelled by user")
                            break

                        data = event.to_json()
                        event_queue.put(f"data: {data}\n\n")

                        event_data = event.data

                        if event_type == "agent_text" and event_data.get("text"):
                            text = event_data["text"]
                            if events_list and events_list[-1].get("type") == "text":
                                events_list[-1]["text"] += text
                            else:
                                events_list.append({"type": "text", "text": text})

                        if event_type == "thinking_block_start":
                            # Start a new thinking block - don't merge with previous
                            events_list.append({"type": "thinking", "text": ""})

                        if event_type == "agent_thinking" and event_data.get("text"):
                            # Chain-of-thought reasoning - aggregate into current thinking block
                            text = event_data["text"]
                            # Find the most recent thinking block or create one
                            if events_list and events_list[-1].get("type") == "thinking":
                                events_list[-1]["text"] += text
                            else:
                                events_list.append({"type": "thinking", "text": text})

                        if event_type == "tool_start":
                            current_tool = {
                                "type": "tool",
                                "tool": event_data.get("tool", ""),
                                "args": event_data.get("args_summary", ""),
                                # Store full input dict so frontend can display tool parameters
                                # (e.g., code for create_chart) after page refresh.
                                "input": event_data.get("args"),
                                "result": None,
                                "error": None,
                                "sql": None,
                                "diff": None,
                                "data_preview": None,
                                "stats": None,
                            }
                            events_list.append(current_tool)

                        if event_type == "tool_result" and current_tool:
                            # Match frontend logic: if stats exist but no summary, use "Done"
                            summary = event_data.get("summary", event_data.get("result", ""))
                            if not summary and event_data.get("stats"):
                                summary = "Done"
                            current_tool["result"] = summary
                            stats = event_data.get("stats")
                            if stats:
                                current_tool["stats"] = stats
                                logger.info(
                                    f"[Stream {stream_id}] Tool '{current_tool.get('tool')}' result with stats: {stats}"
                                )
                            if event_data.get("denied"):
                                current_tool["denied"] = True

                        if event_type == "tool_error":
                            error_msg = event_data.get("error", "Unknown error")
                            tool_name = event_data.get("tool", "Tool")
                            if current_tool:
                                current_tool["error"] = error_msg
                            else:
                                # Tool error without a preceding tool_start
                                events_list.append(
                                    {
                                        "type": "tool",
                                        "tool": tool_name,
                                        "args": "",
                                        "input": None,
                                        "result": None,
                                        "error": error_msg,
                                        "sql": None,
                                        "diff": None,
                                        "data_preview": None,
                                        "stats": None,
                                    }
                                )

                        if event_type == "sql" and current_tool:
                            current_tool["sql"] = event_data.get("sql", "")

                        if event_type == "diff" and current_tool:
                            current_tool["diff"] = event_data.get("lines", [])

                        if event_type == "data_preview" and current_tool:
                            rows = event_data.get("rows", [])
                            current_tool["data_preview"] = make_json_serializable(rows)

                        if event_type == "session_id" and event_data.get("session_id"):
                            session_id = event_data["session_id"]

                        if event_type == "step_done":
                            if event_data.get("cost"):
                                step_cost += event_data["cost"]
                            # Capture ResultMessage data for saving to DB
                            if event_data.get("result"):
                                result_data = event_data["result"]

                    # Also process events that were emitted directly to SSE queue (tracked internally)
                    for queued_event in service.event_queue:
                        event_type = queued_event.type.value
                        event_data = queued_event.data

                        if event_type == "tool_start":
                            current_tool = {
                                "type": "tool",
                                "tool": event_data.get("tool", ""),
                                "args": event_data.get("args_summary", ""),
                                # Store full input dict so frontend can display tool parameters
                                # (e.g., code for create_chart) after page refresh.
                                "input": event_data.get("args"),
                                "result": None,
                                "error": None,
                                "sql": None,
                                "diff": None,
                                "data_preview": None,
                                "stats": None,
                            }
                            events_list.append(current_tool)

                        if event_type == "tool_result" and current_tool:
                            # Match frontend logic: if stats exist but no summary, use "Done"
                            summary = event_data.get("summary", event_data.get("result", ""))
                            if not summary and event_data.get("stats"):
                                summary = "Done"
                            current_tool["result"] = summary
                            stats = event_data.get("stats")
                            if stats:
                                current_tool["stats"] = stats
                                logger.info(
                                    f"[Stream {stream_id}] Tool '{current_tool.get('tool')}' result with stats: {stats}"
                                )
                            if event_data.get("denied"):
                                current_tool["denied"] = True

                        if event_type == "tool_error":
                            error_msg = event_data.get("error", "Unknown error")
                            tool_name = event_data.get("tool", "Tool")
                            if current_tool:
                                current_tool["error"] = error_msg
                            else:
                                events_list.append(
                                    {
                                        "type": "tool",
                                        "tool": tool_name,
                                        "args": "",
                                        "input": None,
                                        "result": None,
                                        "error": error_msg,
                                        "sql": None,
                                        "diff": None,
                                        "data_preview": None,
                                        "stats": None,
                                    }
                                )

                        if event_type == "sql" and current_tool:
                            current_tool["sql"] = event_data.get("sql", "")

                        if event_type == "diff" and current_tool:
                            current_tool["diff"] = event_data.get("lines", [])

                        if event_type == "data_preview" and current_tool:
                            rows = event_data.get("rows", [])
                            current_tool["data_preview"] = make_json_serializable(rows)

                if conversation and events_list:
                    text_parts = [e["text"] for e in events_list if e["type"] == "text"]
                    thinking_parts = [e["text"] for e in events_list if e["type"] == "thinking"]
                    assistant_content = "\n".join(text_parts) if text_parts else "Response"
                    if was_cancelled:
                        assistant_content += "\n\n[Response stopped by user]"
                    metadata = {"events": events_list, "cancelled": was_cancelled} if events_list else {}
                    if thinking_parts:
                        metadata["thinking"] = "\n".join(thinking_parts)
                    assistant_msg = await sync_to_async(conversation.add_message)(
                        "assistant", assistant_content, metadata
                    )

                    # Update message with ResultMessage metrics
                    if result_data:
                        await sync_to_async(assistant_msg.update_from_result)(
                            subtype=result_data.get("subtype", ""),
                            duration_ms=result_data.get("duration_ms", 0),
                            duration_api_ms=result_data.get("duration_api_ms", 0),
                            is_error=result_data.get("is_error", False),
                            num_turns=result_data.get("num_turns", 0),
                            cost_usd=result_data.get("cost_usd"),
                            usage=result_data.get("usage"),
                        )

                    # Signal that save is complete (for cancel endpoint to wait on)
                    save_complete_event.set()

                    if session_id and not conversation.session_id:
                        conversation.session_id = session_id
                        await sync_to_async(conversation.save)(update_fields=["session_id", "modified"])

                logger.info(f"[Stream {stream_id}] Chat completed, events_list length: {len(events_list)}")

                if was_cancelled:
                    event_queue.put(f"data: {json.dumps({'type': 'cancelled'})}\n\n")
                else:
                    event_queue.put(f"data: {json.dumps({'type': 'done'})}\n\n")
                    logger.info(f"[Stream {stream_id}] Sent done event")

            except Exception as e:
                logger.exception(f"[Stream {stream_id}] Claude Agent streaming error: {e}")
                error_event = {"type": EventType.ERROR.value, "message": str(e)}
                event_queue.put(f"data: {json.dumps(error_event)}\n\n")
            finally:
                event_queue.put(SENTINEL)
                active_streams.pop(stream_id, None)
                logger.info(f"[Stream {stream_id}] Process finished, sentinel sent")

        try:
            loop.run_until_complete(process())
        except Exception as e:
            logger.exception(f"[Stream {stream_id}] Error running event loop: {e}")
        finally:
            loop.close()
            logger.info(f"[Stream {stream_id}] Event loop closed")

    logger.info(f"[Stream {stream_id}] Starting background thread")
    thread = threading.Thread(target=run_async_in_thread, daemon=True)
    thread.start()
    logger.info(f"[Stream {stream_id}] Thread started, yielding stream_id event")

    yield f"data: {json.dumps({'type': 'stream_id', 'stream_id': stream_id})}\n\n"
    logger.info(f"[Stream {stream_id}] First yield done, entering main loop")

    while True:
        try:
            event = event_queue.get(timeout=120)
            if event is SENTINEL:
                logger.info(f"[Stream {stream_id}] Received SENTINEL, ending stream")
                break
            yield event
        except queue.Empty:
            logger.warning(f"[Stream {stream_id}] Queue timeout after 120s")
            yield f"data: {json.dumps({'type': EventType.ERROR.value, 'message': 'Request timeout'})}\n\n"
            break


# =============================================================================
# DRF ViewSets
# =============================================================================


class AiConversationViewSet(viewsets.ModelViewSet, OpenapiMixin):
    """
    ViewSet for AI Conversations.
    Provides CRUD operations and custom actions for managing conversations.
    """

    queryset = AiConversation.objects.all()
    serializer_class = AiConversationSerializer
    permission_classes = [IsStaffUser]
    pagination_class = DisablePagination

    def get_queryset(self):
        queryset = super().get_queryset().filter(user=self.request.user)
        project_id = self.request.query_params.get("project_id")
        if project_id:
            queryset = queryset.filter(project_id=project_id)

        if self.action in ["list", "retrieve"]:
            return queryset.prefetch_related("messages")
        return queryset

    def get_serializer_class(self):
        if self.action == "list":
            return AiConversationListSerializer
        if self.action == "create":
            return AiConversationCreateSerializer
        return AiConversationSerializer

    @register_open_api()
    def list(self, request, *args, **kwargs):
        queryset = self.filter_queryset(self.get_queryset())
        serializer = self.get_serializer(queryset, many=True)
        return Response({"conversations": serializer.data})

    @register_open_api()
    def retrieve(self, request, *args, **kwargs):
        return super().retrieve(request, *args, **kwargs)

    @register_open_api()
    def create(self, request, *args, **kwargs):
        title = request.data.get("title", "")
        project_id = request.data.get("project_id")

        if project_id:
            project = get_object_or_404(AiProject, id=project_id, user=request.user)
        else:
            project = AiProject.objects.get_or_create_default(request.user)

        conversation = AiConversation.objects.create(
            user=request.user,
            project=project,
            title=title,
        )
        serializer = AiConversationCreateSerializer(conversation, context={"request": request})
        return Response(serializer.data)

    @register_open_api()
    def destroy(self, request, *args, **kwargs):
        return super().destroy(request, *args, **kwargs)

    @detail_action(
        ActionRequest(method="POST", serializer_class=AddMessageSerializer),
        open_api_response=OpenApiResponse(serializer_class=DetailSerializer),
    )
    def add_message(self, request, pk, payload):
        """Add a message to a conversation."""
        conversation = self.get_object()
        role = payload.get("role", "user")
        content = payload["content"]

        message = conversation.add_message(
            role=role,
            content=content,
            metadata=payload.get("metadata"),
        )

        # Set title from first user message if not already set
        if not conversation.title and role == "user" and content:
            conversation.title = content[:100].strip()
            if len(content) > 100:
                conversation.title = conversation.title.rsplit(" ", 1)[0] + "..."
            conversation.save(update_fields=["title", "modified"])

        return {
            "id": conversation.id,
            "message_id": message.id,
            "message_count": conversation.message_count,
            "title": conversation.title,
        }

    @detail_action(
        ActionRequest(method="POST", serializer_class=UpdateCostSerializer),
        open_api_response=OpenApiResponse(serializer_class=DetailSerializer),
    )
    def update_cost(self, request, pk, payload):
        """Update the total cost for a conversation."""
        conversation = self.get_object()
        cost = Decimal(str(payload.get("cost", 0)))
        input_tokens = payload.get("input_tokens", 0)
        output_tokens = payload.get("output_tokens", 0)
        conversation.add_cost(float(cost), input_tokens, output_tokens)
        return {"id": conversation.id, "total_cost_usd": str(conversation.total_cost_usd)}

    @detail_action(
        ActionRequest(method="POST", serializer_class=SetSessionSerializer),
        open_api_response=OpenApiResponse(serializer_class=DetailSerializer),
    )
    def set_session(self, request, pk, payload):
        """Set the session_id for a conversation."""
        conversation = self.get_object()
        session_id = payload.get("session_id")
        if session_id and not conversation.session_id:
            conversation.session_id = session_id
            conversation.save(update_fields=["session_id", "modified"])
        return {"id": conversation.id, "session_id": conversation.session_id}

    @detail_action(
        ActionRequest(method="POST"),
        open_api_response=OpenApiResponse(serializer_class=DetailSerializer),
    )
    def replay_from(self, request, pk, message_id=None):
        """Delete all messages from (and including) a specific message for replay."""
        conversation = self.get_object()
        # Get message_id from URL kwargs or request data
        msg_id = message_id or request.data.get("message_id")
        message = get_object_or_404(AiConversationMessage, id=msg_id, conversation=conversation)

        message_content = message.content
        messages_to_delete = conversation.messages.filter(created__gte=message.created)
        deleted_count = messages_to_delete.count()
        messages_to_delete.delete()
        conversation.save(update_fields=["modified"])

        return {
            "success": True,
            "message_content": message_content,
            "deleted_count": deleted_count,
            "remaining_messages": conversation.message_count,
        }


class AiProjectViewSet(viewsets.ModelViewSet, OpenapiMixin):
    """
    ViewSet for AI Projects.
    Provides CRUD operations and file management.
    """

    queryset = AiProject.objects.all()
    serializer_class = AiProjectSerializer
    permission_classes = [IsStaffUser]
    pagination_class = DisablePagination

    def get_queryset(self):
        # Annotate with last_activity and sort_date (falls back to created if no conversations)
        queryset = (
            super()
            .get_queryset()
            .annotate(
                last_activity=Max("conversations__messages__created"),
                sort_date=Coalesce(Max("conversations__messages__created"), "created"),
            )
        )

        # Filter by is_shared query param
        is_shared = self.request.query_params.get("is_shared")
        if is_shared is not None:
            is_shared_bool = is_shared.lower() in ("true", "1", "yes")
            if is_shared_bool:
                # Shared projects visible to all
                queryset = queryset.filter(is_shared=True)
            else:
                # Private projects - only user's own
                queryset = queryset.filter(user=self.request.user, is_shared=False)
        else:
            # No filter - user's own projects + shared projects
            queryset = queryset.filter(Q(user=self.request.user) | Q(is_shared=True))

        # Order by most recent activity, falling back to creation date
        return queryset.order_by("-sort_date").distinct()

    def get_serializer_class(self):
        if self.action == "list":
            return AiProjectListSerializer
        if self.action == "create":
            return AiProjectCreateSerializer
        return AiProjectSerializer

    @register_open_api()
    def list(self, request, *args, **kwargs):
        return super().list(request, *args, **kwargs)

    @register_open_api()
    def retrieve(self, request, *args, **kwargs):
        return super().retrieve(request, *args, **kwargs)

    @register_open_api()
    def create(self, request, *args, **kwargs):
        name = request.data.get("name", "").strip()
        description = request.data.get("description", "")
        is_shared = request.data.get("is_shared", False)

        if not name:
            return Response({"error": "Project name is required"}, status=400)

        # Generate unique slug
        base_slug = slugify(name)
        slug = base_slug
        counter = 1
        while AiProject.objects.filter(slug=slug).exists():
            slug = f"{base_slug}-{counter}"
            counter += 1

        project = AiProject.objects.create(
            user=request.user,
            name=name,
            slug=slug,
            description=description,
            is_shared=is_shared,
        )
        serializer = AiProjectSerializer(project, context={"request": request})
        return Response(serializer.data)

    @register_open_api()
    def partial_update(self, request, *args, **kwargs):
        # Only owners can update
        instance = self.get_object()
        if instance.user_id != request.user.id:
            return Response({"error": "Only the owner can update this project"}, status=403)
        return super().partial_update(request, *args, **kwargs)

    @register_open_api()
    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        if instance.user_id != request.user.id:
            return Response({"error": "Only the owner can delete this project"}, status=403)
        return super().destroy(request, *args, **kwargs)

    @detail_action(
        ActionRequest(method="GET"),
        open_api_response=OpenApiResponse(serializer_class=FileListItemSerializer),
    )
    def files(self, request, pk):
        """List all files in a project's storage folder recursively."""
        project = self.get_object()
        storage = project.storage
        # Build the base URL for file access from current request path
        # /ainstein/v1/projects/26/files/ -> /ainstein/v1/projects/26/file/
        base_url = request.build_absolute_uri(request.path.replace("/files/", "/file/"))

        def list_files_recursive(path=""):
            files = []
            try:
                dirs, file_names = storage.listdir(path)
                for d in sorted(dirs):
                    dir_path = f"{path}/{d}" if path else d
                    files.append({"name": d, "path": dir_path, "type": "directory"})
                    files.extend(list_files_recursive(dir_path))
                for f in sorted(file_names):
                    file_path = f"{path}/{f}" if path else f
                    try:
                        size = storage.size(file_path)
                    except Exception:
                        size = 0
                    file_info = {
                        "name": f,
                        "path": file_path,
                        "type": "file",
                        "size": size,
                        "url": f"{base_url}{file_path}",
                    }
                    files.append(file_info)
            except FileNotFoundError:
                pass
            return files

        files = list_files_recursive()
        return Response({"files": files, "project_path": project.folder_path})

    def read_file_content(self, storage, path):
        """
        Read file content from storage.
        Returns tuple: (content, content_type, is_binary, file_obj_or_none)
        For binary files, returns (None, content_type, True, file_obj)
        For text files, returns (content_string, content_type, False, None)
        """
        import mimetypes

        content_type, _ = mimetypes.guess_type(path)
        # Binary type prefixes
        binary_prefixes = ["image/", "audio/", "video/", "application/pdf", "application/octet-stream"]
        # Specific binary types (Office docs, archives, etc.)
        binary_exact = [
            "application/vnd.openxmlformats-officedocument",  # .xlsx, .docx, .pptx
            "application/vnd.ms-excel",  # .xls
            "application/vnd.ms-powerpoint",  # .ppt
            "application/msword",  # .doc
            "application/zip",
            "application/x-zip-compressed",
            "application/gzip",
            "application/x-tar",
            "application/x-rar-compressed",
            "application/x-7z-compressed",
        ]
        is_binary = content_type and (
            any(content_type.startswith(t) for t in binary_prefixes)
            or any(content_type.startswith(t) for t in binary_exact)
        )

        if is_binary:
            file_obj = storage.open(path, "rb")
            return None, content_type, True, file_obj

        with storage.open(path, "rb") as f:
            raw_content = f.read()
        try:
            content = raw_content.decode("utf-8")
        except UnicodeDecodeError:
            content = raw_content.decode("latin-1")

        return content, content_type, False, None

    def file(self, request, pk, file_path="", raw=False):
        """
        Unified file endpoint: GET/POST/PUT/DELETE on /projects/<id>/file/<path>

        - GET: Read file content (add ?raw=1 for raw content without wrapper)
        - POST: Create new file or folder (folder if path ends with /)
        - PUT: Update existing file or rename/move file
        - DELETE: Delete file or folder
        """
        import json

        from django.http import FileResponse, HttpResponse

        project = self.get_object()
        storage = project.storage
        path = file_path

        if not path:
            return Response({"error": "File path is required"}, status=400)

        # Check for raw parameter (from query string or passed directly)
        is_raw = raw or request.query_params.get("raw") in ("1", "true")

        # GET - Read file
        if request.method == "GET":
            try:
                if not storage.exists(path):
                    return Response({"error": "File not found"}, status=404)

                content, content_type, is_binary, file_obj = self.read_file_content(storage, path)

                if is_binary:
                    response = FileResponse(file_obj, content_type=content_type or "application/octet-stream")
                    response["Content-Disposition"] = f'inline; filename="{path.split("/")[-1]}"'
                    return response

                # Raw mode: return content directly without wrapper
                if is_raw:
                    if path.endswith(".json"):
                        try:
                            parsed = json.loads(content)
                            return Response(parsed)
                        except json.JSONDecodeError:
                            return HttpResponse(content, content_type="text/plain")
                    return HttpResponse(content, content_type=content_type or "text/plain")

                # Standard mode: return wrapped response
                return Response({"path": path, "content": content, "size": storage.size(path)})
            except Exception as e:
                return Response({"error": str(e)}, status=500)

        # POST - Create new file or folder
        if request.method == "POST":
            try:
                # Check if file/folder already exists
                if storage.exists(path):
                    return Response({"error": "File or folder already exists"}, status=409)

                # Create folder if path ends with /
                if path.endswith("/"):
                    folder_path = path.rstrip("/")
                    project.create_folder(folder_path)
                    return Response({"created": True, "path": folder_path, "type": "folder"}, status=201)

                # Create file
                content = request.data.get("content", "")
                size = project.write_file(path, content)
                return Response({"path": path, "content": content, "size": size, "type": "file"}, status=201)
            except Exception as e:
                return Response({"error": str(e)}, status=500)

        # PUT - Update file or rename/move
        if request.method == "PUT":
            try:
                new_path = request.data.get("new_path")

                # Rename/move if new_path provided
                if new_path:
                    if not storage.exists(path):
                        return Response({"error": "Source file not found"}, status=404)
                    if storage.exists(new_path):
                        return Response({"error": "Destination already exists"}, status=409)

                    # Read and write to new location, then delete old
                    storage.save(new_path, storage.open(path, "rb"))
                    storage.delete(path)
                    return Response({"path": new_path, "old_path": path, "renamed": True})

                # Update file content
                if not storage.exists(path):
                    return Response({"error": "File not found"}, status=404)
                content = request.data.get("content", "")
                size = project.write_file(path, content)
                return Response({"path": path, "content": content, "size": size, "updated": True})
            except Exception as e:
                return Response({"error": str(e)}, status=500)

        # DELETE - Delete file or folder
        if request.method == "DELETE":
            try:
                if not storage.exists(path):
                    return Response({"error": "File not found"}, status=404)
                storage.delete(path)
                return Response({"deleted": True, "path": path})
            except Exception as e:
                return Response({"error": str(e)}, status=500)

        return Response({"error": "Method not allowed"}, status=405)

    def raw_file(self, request, pk, file_path=""):
        """
        Raw file endpoint: GET /projects/<id>/raw-file/<path>
        Convenience alias that calls file() with raw=True.
        """
        return self.file(request, pk, file_path, raw=True)


class AgentStreamViewSet(viewsets.GenericViewSet, OpenapiMixin):
    """
    ViewSet for Agent streaming operations.
    Handles SSE streaming and stream cancellation.
    """

    permission_classes = [IsStaffUser]
    serializer_class = DetailSerializer

    @list_action(
        ActionRequest(method="POST", serializer_class=StreamMessageSerializer),
        open_api_response=OpenApiResponse(serializer_class=DetailSerializer),
    )
    def stream(self, request, payload):
        """
        SSE endpoint for streaming Claude Agent responses.
        Returns Server-Sent Events stream.
        """
        message = payload.get("message", "").strip()
        conversation_id = payload.get("conversation_id")

        if not message:
            return Response({"error": "Message is required"}, status=400)

        # Get session_id from conversation to resume (only if it exists)
        resume_session_id = None
        if conversation_id:
            try:
                conversation = AiConversation.objects.get(id=conversation_id, user=request.user)
                if conversation.session_id:
                    resume_session_id = conversation.session_id
                    logger.info(f"Resuming conversation {conversation_id} with session_id: {resume_session_id}")
                else:
                    logger.info(f"New conversation {conversation_id} (no session_id yet)")
            except AiConversation.DoesNotExist:
                pass

        response = StreamingHttpResponse(
            stream_events_sync(
                message, conversation_id=conversation_id, resume_session_id=resume_session_id, user=request.user
            ),
            content_type="text/event-stream",
        )
        response["Cache-Control"] = "no-cache"
        response["X-Accel-Buffering"] = "no"
        return response

    @list_action(
        ActionRequest(method="POST", serializer_class=CancelStreamSerializer),
        open_api_response=OpenApiResponse(serializer_class=DetailSerializer),
    )
    def cancel(self, request, payload):
        """Cancel an active stream using SDK interrupt and wait for save to complete."""
        stream_id = payload.get("stream_id")

        if not stream_id:
            return Response({"error": "stream_id is required"}, status=400)

        if stream_id in active_streams:
            stream_state = active_streams[stream_id]
            stream_state["cancelled"] = True
            logger.info(f"Cancelling stream {stream_id}...")

            # Try to use SDK's interrupt() for proper cleanup
            service = stream_state.get("service")
            loop = stream_state.get("loop")
            if service and loop:
                try:
                    # Schedule interrupt on the stream's event loop
                    future = asyncio.run_coroutine_threadsafe(service.interrupt(), loop)
                    future.result(timeout=5.0)  # Wait up to 5 seconds for interrupt
                    logger.info(f"Stream {stream_id} interrupted via SDK")
                except Exception as e:
                    logger.warning(f"SDK interrupt failed for {stream_id}: {e}")

            # Wait for save to complete (with timeout to avoid hanging)
            save_complete = stream_state.get("save_complete")
            if save_complete:
                saved = save_complete.wait(timeout=10.0)  # 10 second timeout
                if saved:
                    logger.info(f"Stream {stream_id} save completed")
                else:
                    logger.warning(f"Stream {stream_id} save timed out")

            return {"success": True, "message": "Stream cancelled"}
        return {"success": False, "message": "Stream not found or already completed"}

    @list_action(
        ActionRequest(method="POST", serializer_class=PermissionResponseSerializer),
        open_api_response=OpenApiResponse(serializer_class=DetailSerializer),
    )
    def permission(self, request, payload):
        """Submit user response for a permission request.

        Supports both:
        - Legacy: Threading-based permission system via submit_permission_response
        - New: Hooks-based async permission system via PermissionManager
        """

        request_id = payload.get("request_id")
        approved = payload.get("approved")
        reason = payload.get("reason")  # Optional denial reason

        if not request_id:
            return Response({"error": "request_id is required"}, status=400)

        # Try new hooks-based permission manager first
        manager = get_permission_manager()
        if manager:
            success = manager.submit_response(request_id, approved, reason)
            if success:
                logger.info(f"Permission {request_id} {'approved' if approved else 'denied'} (hooks)")
                return {"success": True, "approved": approved}

        # Fall back to legacy threading-based system
        success = submit_permission_response(request_id, approved)
        if success:
            logger.info(f"Permission {request_id} {'approved' if approved else 'denied'} (legacy)")
            return {"success": True, "approved": approved}

        return {"success": False, "message": "Permission request not found or already processed"}

    @list_action(
        ActionRequest(method="GET"),
        open_api_response=OpenApiResponse(serializer_class=DetailSerializer),
    )
    def status(self, request):
        """Get the current status of the Claude Agent service."""
        return {
            "status": "ready",
            "model": "claude-haiku-4-5-20251001",
            "tools": [
                "django_list_models",
                "django_describe_model",
                "django_query",
                "django_aggregate",
                "django_raw_sql",
                "execute_code",
                "storage_read",
                "storage_write",
                "storage_delete",
                "storage_list",
                "storage_exists",
            ],
            "tools_requiring_approval": ["execute_code"],
        }

    @list_action(
        ActionRequest(method="POST", serializer_class=ImprovePromptSerializer),
        open_api_response=OpenApiResponse(serializer_class=ImprovedPromptSerializer),
    )
    def improve_prompt(self, request, payload):
        """Improve a user's prompt using Claude to make it more effective."""
        prompt = payload.get("prompt", "").strip()

        if not prompt:
            return Response({"error": "prompt is required"}, status=400)

        try:
            improved = improve_prompt(prompt)
            return {"improved_prompt": improved}
        except Exception as e:
            logger.exception(f"Error improving prompt: {e}")
            return Response({"error": str(e)}, status=500)


# =============================================================================
# View Aliases
# =============================================================================

ainstein_view = AinsteinView.as_view()
