"""
Claude Agent Service - Event-based Django Integration

Provides MCP tools for Claude to interact with Django ORM.
Supports both CLI output (print) and web streaming (yield events).

Usage:
    # CLI mode (prints to console)
    service = AinsteinService()
    async for event in service.chat("What models are available?"):
        pass  # Events are printed automatically

    # Web mode (yield events for SSE)
    service = AinsteinService(output_mode="events")
    async for event in service.chat("What models are available?"):
        yield f"data: {json.dumps(event)}\n\n"
"""

import json
import logging
import time
from collections.abc import AsyncGenerator

from claude_agent_sdk import (
    AssistantMessage,
    ClaudeAgentOptions,
    ClaudeSDKClient,
    ResultMessage,
    SystemMessage,
    TextBlock,
    ThinkingBlock,
    create_sdk_mcp_server,
)
from claude_agent_sdk.types import StreamEvent
from django.core.files.storage import Storage, storages

from ainstein.conf import get_sdk_builtin_tools, get_settings
from ainstein.events import Event, EventType, submit_permission_response
from ainstein.hooks import (
    PermissionManager,
    create_hook_matchers,
    set_permission_manager,
)
from ainstein.model_registry import get_model_registry
from ainstein.prompts import DEFAULT_MAX_LIMIT, DEFAULT_MODEL, SYSTEM_PROMPT
from ainstein.skills import get_matching_skills
from ainstein.tools import ALL_TOOL_NAMES, ToolContext, create_all_tools
from ainstein.utils import format_duration


logger = logging.getLogger(__name__)


# Re-export for backwards compatibility
__all__ = [
    "AinsteinService",
    "Event",
    "EventType",
    "improve_prompt",
    "submit_permission_response",
]


# =============================================================================
# Dark Theme Colors (ANSI escape codes for CLI)
# =============================================================================


class C:
    """Dark theme friendly ANSI colors."""

    RESET = "\033[0m"
    BOLD = "\033[1m"
    RED = "\033[91m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    BLUE = "\033[94m"
    CYAN = "\033[96m"
    WHITE = "\033[97m"
    GRAY = "\033[38;5;245m"
    ORANGE = "\033[38;5;208m"


# =============================================================================
# Prompt Improvement
# =============================================================================


def improve_prompt(prompt: str) -> str:
    """
    Use Claude Haiku via OpenRouter to improve a user's prompt.
    Includes available Django models for typo correction.
    Returns the improved prompt text.
    """
    from ainstein.prompts import IMPROVE_PROMPT_SYSTEM
    from ainstein.tools.django_tools import list_available_models
    from util.open_router_client import claude_haiku_helper

    # Get available models for context
    try:
        models = list_available_models()
        model_names = [f"{m['app']}.{m['model']}" for m in models]
        models_context = f"\n\nAvailable models (use for typo correction): {', '.join(model_names)}"
    except Exception:
        models_context = ""

    system_prompt = IMPROVE_PROMPT_SYSTEM + models_context

    response = claude_haiku_helper.chat_completion(
        prompt=f"Improve this prompt:\n\n{prompt}",
        prompt_sys=system_prompt,
        max_tokens=1024,
    )

    return claude_haiku_helper.get_message(response).strip()


# =============================================================================
# Claude Agent Service
# =============================================================================


class AinsteinService:
    """
    Event-based Claude Agent service for Django.

    Supports two output modes:
    - "cli": Prints colored output to console (default)
    - "events": Yields Event objects for web streaming
    """

    def __init__(
        self,
        storage: Storage = None,
        model: str = None,
        system_prompt: str = None,
        output_mode: str = "cli",
        resume_session_id: str = None,
        project_folder: str = None,
        project_id: int = None,  # Database ID for building URLs
        sse_queue=None,  # Thread-safe queue for SSE streaming
        is_cancelled: callable = None,  # Callback to check if cancelled by user
        user=None,  # Django User instance
        project=None,  # AiProject instance
        conversation=None,  # AiConversation instance
    ):
        # Load settings
        self.settings = get_settings()

        # Use provided values, then settings, then defaults
        self.model = model or self.settings.MODEL or DEFAULT_MODEL
        self.custom_system_prompt = system_prompt  # User-provided override, if any
        self.output_mode = output_mode
        self.resume_session_id = resume_session_id
        self.project_folder = project_folder  # e.g. "projects/abc123" - all file ops are sandboxed here
        self.project_id = project_id  # Database ID for building URLs
        self.sse_queue = sse_queue  # Direct queue for immediate event streaming
        self.is_cancelled = is_cancelled or (lambda: False)  # Default: never cancelled
        self.user = user  # Django User instance
        self.project = project  # AiProject instance
        self.conversation = conversation  # AiConversation instance

        # Get storage from settings or parameter
        if storage is None:
            storage_backend = self.settings.STORAGE_BACKEND or "agent"
            self.storage = storages[storage_backend]
        else:
            self.storage = storage

        # Session state
        self.client = None
        self.options = None
        self.stats = {
            "total_cost": 0.0,
            "total_time": 0.0,
            "message_count": 0,
        }

        # Event queue for tools to emit events (fallback when no SSE queue)
        self.event_queue: list[Event] = []

        # Permission manager for human-in-the-loop approval
        self.permission_manager = PermissionManager(
            emit_callback=self._emit_permission_event,
            tool_event_callback=self._emit_tool_event,
        )

    def emit(self, event: Event):
        """Emit an event.

        If sse_queue is set, push directly to the SSE stream (for immediate delivery).
        Also tracks event internally for conversation history.
        """
        if self.output_mode == "cli":
            self.print_event(event)
        elif self.sse_queue is not None:
            # Push directly to SSE queue for immediate streaming
            # This ensures events reach the frontend even during blocking operations
            data = event.to_json()
            self.sse_queue.put(f"data: {data}\n\n")
            # Also track internally for conversation history (skip transient permission events)
            if event.type != EventType.PERMISSION_REQUEST:
                self.event_queue.append(event)
        else:
            self.event_queue.append(event)

    def _emit_permission_event(self, event_data: dict):
        """Emit a permission request event to the frontend."""
        if self.sse_queue is not None:
            self.sse_queue.put(f"data: {json.dumps(event_data)}\n\n")

    def _emit_tool_event(self, event_data: dict):
        """Emit a tool use event to the frontend (for all tools including built-in).

        Hook events are added to event_queue so they get:
        1. Yielded via flush_events() in chat() loop
        2. Sent to SSE by views.py
        3. Processed for DB persistence by views.py

        We do NOT send directly to SSE here to avoid duplicates.
        """
        # Map hook event types to our internal Event types and add to queue
        # They'll be yielded via flush_events() and sent to SSE by views.py
        event_type = event_data.get("type", "")
        if event_type == "tool_use_start":
            self.event_queue.append(
                Event(
                    EventType.TOOL_START,
                    {
                        "tool": event_data.get("tool_name", ""),
                        "args_summary": str(event_data.get("input", {})),
                        "args": event_data.get("input", {}),
                    },
                )
            )
        elif event_type == "tool_use_end":
            self.event_queue.append(
                Event(
                    EventType.TOOL_RESULT,
                    {
                        "summary": event_data.get("summary", ""),
                        "is_error": event_data.get("is_error", False),
                        "denied": event_data.get("denied", False),
                    },
                )
            )
        else:
            # For other event types (like permission), send directly to SSE
            if self.sse_queue is not None:
                self.sse_queue.put(f"data: {json.dumps(event_data)}\n\n")

    def submit_permission_response(self, request_id: str, approved: bool, reason: str = None) -> bool:
        """Submit user's permission response."""
        return self.permission_manager.submit_response(request_id, approved, reason)

    async def interrupt(self):
        """
        Interrupt the current streaming operation.

        Uses the SDK's native interrupt() method for proper cleanup.
        This should be called from the cancel endpoint.
        """
        if self.client:
            try:
                await self.client.interrupt()
                logger.info("Client interrupted successfully")
            except Exception as e:
                logger.error(f"Error interrupting client: {e}")

    def _build_system_prompt(self, user_message: str = "") -> str:
        """
        Build the system prompt with dynamic bearings and skills.

        Bearings provide environmental context about available data models,
        helping the agent understand what business data it can query.
        Reference: https://www.anthropic.com/engineering/effective-harnesses-for-long-running-agents

        Skills are domain-specific prompt extensions that get appended when
        the user's message matches certain keywords.
        """
        # If custom prompt provided, use it directly
        if self.custom_system_prompt:
            return self.custom_system_prompt

        try:
            registry = get_model_registry()
            bearings = registry.get_bearings()
        except Exception as e:
            logger.warning(f"Failed to get model bearings: {e}")
            bearings = ""

        bearings_section = (
            f"""

## BEARINGS (Environmental Context)

The following data models are available for business intelligence discovery.
Use these to help create executive summaries, discover insights, and understand customers.

{bearings}

When asked about business data, customers, or analytics:
1. Use django_list_models to see available data with row counts
2. Use django_describe_model to understand field structure
3. Use django_query or django_raw_sql to extract insights
"""
            if bearings
            else ""
        )

        # Get matching skills based on user message
        skills_section, skill_names = get_matching_skills(user_message)
        if skill_names:
            logger.info(f"Activated skills: {skill_names}")

        return SYSTEM_PROMPT + bearings_section + skills_section

    def print_event(self, event: Event):
        """Print event to console with colors."""
        t = event.type
        d = event.data

        if t == EventType.STEP_START:
            prompt = d.get("prompt", "")[:60]
            ellipsis = "..." if len(d.get("prompt", "")) > 60 else ""
            print(f"\n{C.BOLD}╭─ Step {d.get('step')}: {prompt}{ellipsis}{C.RESET}")

        elif t == EventType.STEP_DONE:
            duration = d.get("duration", "")
            cost = d.get("cost", 0)
            total = d.get("total_cost", 0)
            print(f"{C.BOLD}╰─ ✓ Done in {duration} │ Step: ${cost:.4f} │ Total: ${total:.4f}{C.RESET}")

        elif t == EventType.AGENT_TEXT:
            print()
            lines = d.get("text", "").split("\n")
            for i, line in enumerate(lines):
                if line.strip():
                    prefix = "● " if i == 0 else "  "
                    print(f"     {C.WHITE}{prefix}{line}{C.RESET}", flush=True)

        elif t == EventType.AGENT_THINKING:
            # Chain-of-thought reasoning - display in a distinct style
            print()
            lines = d.get("text", "").split("\n")
            for i, line in enumerate(lines):
                if line.strip():
                    prefix = "💭 " if i == 0 else "   "
                    print(f"     {C.GRAY}{prefix}{line}{C.RESET}", flush=True)

        elif t == EventType.TOOL_START:
            tool_name = d.get("tool", "")
            args_str = d.get("args_summary", "")
            print(f"     {C.ORANGE}● {tool_name}({args_str}){C.RESET}")

        elif t == EventType.TOOL_RESULT:
            summary = d.get("summary", "")
            print(f"       ⎿  {summary}")

        elif t == EventType.TOOL_ERROR:
            error = d.get("error", "")
            print(f"     {C.RED}✗ {d.get('tool', '')} - {error}{C.RESET}")

        elif t == EventType.SQL:
            sql = d.get("sql", "")
            for line in sql.strip().split("\n"):
                if line.strip():
                    print(f"       {C.GRAY}{line.strip()}{C.RESET}")

        elif t == EventType.DATA_PREVIEW:
            rows = d.get("rows", [])
            for row in rows[:5]:
                row_str = ", ".join(f"{k}={v}" for k, v in row.items()) if isinstance(row, dict) else str(row)
                print(f"       {C.GRAY}  {row_str}{C.RESET}")
            if len(rows) > 5:
                print(f"       {C.GRAY}  ... and {len(rows) - 5} more rows{C.RESET}")

        elif t == EventType.DIFF:
            for line in d.get("lines", []):
                if line.startswith("+"):
                    print(f"       {C.GREEN}{line}{C.RESET}")
                elif line.startswith("-"):
                    print(f"       {C.RED}{line}{C.RESET}")
                else:
                    print(f"       {line}")

        elif t == EventType.ERROR:
            print(f"     {C.RED}✗ Error: {d.get('message', '')}{C.RESET}")

    def flush_events(self) -> list[Event]:
        """Get and clear queued events."""
        events = self.event_queue
        self.event_queue = []
        return events

    def create_tools(self):
        """
        Create MCP tools with event emission.

        Uses the modular tool factory functions from ainstein.tools.
        All tools receive a ToolContext containing service, storage, and config.
        """
        max_limit = self.settings.MAX_SQL_LIMIT or DEFAULT_MAX_LIMIT

        ctx = ToolContext(
            service=self,
            storage=self.storage,
            project_folder=self.project_folder,
            max_limit=max_limit,
            file_mtimes={},
            project_id=self.project_id,
            is_cancelled=self.is_cancelled,
            user=self.user,
            project=self.project,
            conversation=self.conversation,
        )

        return create_all_tools(ctx)

    async def initialize(self, resume_session_id: str = None, user_message: str = ""):
        """Initialize the Claude client and MCP server.

        Args:
            resume_session_id: Optional session ID to resume a previous conversation.
                              The SDK will automatically load conversation history.
            user_message: The user's first message, used to detect skills to activate.
        """
        if resume_session_id:
            logger.info(f"Initializing AinsteinService with resume session_id: {resume_session_id}")
        else:
            logger.info("Initializing AinsteinService (new session)")

        # Set the global permission manager for hooks to use
        set_permission_manager(self.permission_manager)

        tools = self.create_tools()

        server = create_sdk_mcp_server(name="app", tools=tools)

        # Combine SDK built-in tools (from config) with our MCP tools
        allowed_tools = get_sdk_builtin_tools() + [f"mcp__app__{name}" for name in ALL_TOOL_NAMES]

        # Create hook matchers for permission handling
        hooks = create_hook_matchers()

        # Build system prompt with skills based on user message
        system_prompt = self._build_system_prompt(user_message)

        self.options = ClaudeAgentOptions(
            model=self.model,
            system_prompt=system_prompt,
            mcp_servers={"app": server},
            allowed_tools=allowed_tools,
            resume=resume_session_id,  # Resume session if provided
            include_partial_messages=True,  # Enable token-by-token streaming
            max_thinking_tokens=10000,  # Enable chain-of-thought reasoning
            hooks=hooks,  # PreToolUse/PostToolUse hooks for permissions
        )

        logger.info(f"ClaudeAgentOptions created with resume={resume_session_id}, hooks enabled")

        self.client = ClaudeSDKClient(options=self.options)
        await self.client.__aenter__()
        logger.info("ClaudeSDKClient initialized successfully")

    async def close(self):
        """Close the Claude client."""
        if self.client:
            await self.client.__aexit__(None, None, None)
            self.client = None

    async def chat(self, message: str, resume_session_id: str = None) -> AsyncGenerator[Event]:
        """
        Send a message and yield events as they occur.

        Args:
            message: The user's message
            resume_session_id: Optional session ID to resume a previous conversation.
                              When provided, the SDK loads the full conversation history.

        Usage:
            # New conversation (session_id will be emitted)
            async for event in service.chat("List all models"):
                print(event.to_json())

            # Resume existing conversation
            async for event in service.chat("Continue", resume_session_id="session_abc123"):
                print(event.to_json())
        """
        if not self.client:
            await self.initialize(resume_session_id=resume_session_id, user_message=message)

        self.stats["message_count"] += 1
        step_num = self.stats["message_count"]

        # Emit step start
        start_event = Event(EventType.STEP_START, {"step": step_num, "prompt": message})
        if self.output_mode == "cli":
            self.print_event(start_event)
        else:
            yield start_event

        start_time = time.time()

        # Send the query
        logger.debug(f"Sending query: {message[:100]}...")
        await self.client.query(message)
        logger.debug("Query sent, waiting for response...")

        step_cost = 0.0
        session_id = None
        has_streamed_text = False  # Track if we've already streamed text (avoid duplicates)
        has_streamed_thinking = False  # Track if we've already streamed thinking

        async for msg in self.client.receive_response():
            # Log message types (except noisy StreamEvent)
            msg_type = type(msg).__name__
            if msg_type != "StreamEvent":
                logger.debug(f"Received message type: {msg_type}")

            # Flush any events from tool calls (these were queued by emit())
            for event in self.flush_events():
                yield event

            # Capture session_id from init message (session_id is in msg.data for SystemMessage)
            if isinstance(msg, SystemMessage) and msg.subtype == "init":
                session_id = msg.data.get("session_id")
                logger.info(f"Received SystemMessage init with session_id: {session_id}")
                if session_id:
                    event = Event(EventType.SESSION_ID, {"session_id": session_id})
                    if self.output_mode == "cli":
                        self.print_event(event)
                    else:
                        yield event

            elif isinstance(msg, StreamEvent):
                # Handle streaming text deltas (token-by-token)
                stream_event = msg.event
                event_type = stream_event.get("type", "")

                # content_block_start marks the beginning of a new content block
                if event_type == "content_block_start":
                    content_block = stream_event.get("content_block", {})
                    block_type = content_block.get("type", "")

                    if block_type == "thinking":
                        # Emit event to signal start of a new thinking block
                        event = Event(EventType.THINKING_BLOCK_START, {})
                        if self.output_mode == "cli":
                            print("\n💭 ", end="", flush=True)
                        else:
                            yield event

                # content_block_delta contains incremental text or thinking
                elif event_type == "content_block_delta":
                    delta = stream_event.get("delta", {})
                    delta_type = delta.get("type", "")

                    if delta_type == "thinking_delta":
                        # Chain-of-thought reasoning (streaming)
                        thinking = delta.get("thinking", "")
                        if thinking:
                            has_streamed_thinking = True
                            event = Event(EventType.AGENT_THINKING, {"text": thinking})
                            if self.output_mode == "cli":
                                print(thinking, end="", flush=True)
                            else:
                                yield event

                    elif delta_type == "text_delta":
                        text = delta.get("text", "")
                        if text:
                            has_streamed_text = True
                            event = Event(EventType.AGENT_TEXT, {"text": text})
                            if self.output_mode == "cli":
                                print(text, end="", flush=True)  # Print without newline for streaming
                            else:
                                yield event

            elif isinstance(msg, AssistantMessage):
                # Full message (when not streaming or final message)
                for block in msg.content:
                    if isinstance(block, ThinkingBlock):
                        # Skip if we've already streamed this thinking (avoid duplicates)
                        if has_streamed_thinking:
                            continue
                        thinking = block.thinking.strip() if hasattr(block, "thinking") else ""
                        if thinking:
                            event = Event(EventType.AGENT_THINKING, {"text": thinking})
                            if self.output_mode == "cli":
                                self.print_event(event)
                            else:
                                yield event

                    elif isinstance(block, TextBlock):
                        # Skip if we've already streamed this text (avoid duplicates)
                        if has_streamed_text:
                            continue
                        text = block.text.strip()
                        if text:
                            event = Event(EventType.AGENT_TEXT, {"text": text})
                            if self.output_mode == "cli":
                                self.print_event(event)
                            else:
                                yield event

                # Reset streaming flags for next message
                has_streamed_text = False
                has_streamed_thinking = False

            elif isinstance(msg, ResultMessage):
                step_cost = msg.total_cost_usd or 0.0
                self.stats["total_cost"] += step_cost
                # Store full ResultMessage data for saving to DB
                self.stats["last_result"] = {
                    "subtype": msg.subtype,
                    "duration_ms": msg.duration_ms,
                    "duration_api_ms": msg.duration_api_ms,
                    "is_error": msg.is_error,
                    "num_turns": msg.num_turns,
                    "cost_usd": msg.total_cost_usd,
                    "usage": msg.usage,
                }
                # Also get session_id from ResultMessage if not already captured
                if not session_id and msg.session_id:
                    session_id = msg.session_id
                    event = Event(EventType.SESSION_ID, {"session_id": session_id})
                    if self.output_mode == "cli":
                        self.print_event(event)
                    else:
                        yield event

        # Flush remaining events
        for event in self.flush_events():
            yield event

        elapsed = time.time() - start_time
        self.stats["total_time"] += elapsed

        # Emit step done with ResultMessage data for DB storage
        step_done_data = {
            "step": step_num,
            "duration": format_duration(elapsed),
            "cost": step_cost,
            "total_cost": self.stats["total_cost"],
        }
        # Include ResultMessage metrics if available
        if "last_result" in self.stats:
            step_done_data["result"] = self.stats["last_result"]
            del self.stats["last_result"]  # Clear for next step
        done_event = Event(EventType.STEP_DONE, step_done_data)
        if self.output_mode == "cli":
            self.print_event(done_event)
        else:
            yield done_event

    async def __aenter__(self):
        # Don't initialize here - let chat() do lazy initialization with user message
        # This allows skill detection based on the first message
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()
