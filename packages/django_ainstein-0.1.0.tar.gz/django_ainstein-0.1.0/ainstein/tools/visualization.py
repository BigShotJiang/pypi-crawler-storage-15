"""
Data Visualization Tools using UV execution.

Tools for generating charts and visualizations using uv run.
Automatically handles matplotlib backend, saves to temp, and copies to project storage.
"""

import logging
import os
import tempfile
import uuid
from typing import Any

from asgiref.sync import sync_to_async
from claude_agent_sdk import tool
from django.core.files.base import ContentFile
from django.urls import reverse

from ainstein.tools.base import ToolContext
from ainstein.tools.uv_code import SANDBOX_DEPS, run_uv_script


logger = logging.getLogger(__name__)


def create_visualization_tools(ctx: ToolContext) -> list:
    """Create data visualization tools."""

    @tool(
        "create_chart",
        """Generate a chart/visualization and save it to project storage.

This tool automatically:
- Sets up matplotlib non-interactive backend
- Runs code via `uv run` with automatic dependency installation
- Saves the generated image to project storage
- Returns the storage path for the image

Include PEP 723 dependencies header. Use OUTPUT_FILE for the output filename.

Example:
```python
# /// script
# dependencies = ["matplotlib", "pandas"]
# ///
import matplotlib.pyplot as plt
import pandas as pd

data = {'Category': ['A', 'B', 'C'], 'Value': [10, 20, 15]}
df = pd.DataFrame(data)

plt.figure(figsize=(10, 6))
plt.bar(df['Category'], df['Value'])
plt.title('Sales by Category')
plt.savefig(OUTPUT_FILE, dpi=150, bbox_inches='tight')
```

Args:
    code: Python code with PEP 723 dependencies. Use OUTPUT_FILE variable for savefig path.
    filename: Output filename (e.g., "sales_chart.png"). Defaults to auto-generated name.""",
        {
            "code": str,
            "filename": str,
        },
    )
    async def create_chart(args: dict[str, Any]) -> dict[str, Any]:
        """Generate a chart and save to project storage."""
        code = args.get("code", "")
        filename = args.get("filename", "") or f"chart_{uuid.uuid4().hex[:8]}.png"

        if not code.strip():
            return ctx.error("CreateChart", "No code provided")

        if ctx.is_cancelled():
            return ctx.success("Chart creation cancelled")

        # Ensure filename has image extension
        if not filename.lower().endswith((".png", ".jpg", ".jpeg", ".svg", ".pdf")):
            filename += ".png"

        # Create temp directory for output
        with tempfile.TemporaryDirectory() as temp_dir:
            output_path = os.path.join(temp_dir, filename)

            # Add default PEP 723 header if not present - use sandbox deps
            if "# /// script" not in code:
                deps = list(SANDBOX_DEPS)
                if "plotly" in code.lower():
                    deps.extend(["plotly", "kaleido"])
                if "networkx" in code.lower():
                    deps.append("networkx")
                deps_str = ", ".join(f'"{d}"' for d in deps)
                code = f"# /// script\n# dependencies = [{deps_str}]\n# ///\n{code}"

            # Prepare code with matplotlib backend and OUTPUT_FILE
            prepared_code = _prepare_chart_code(code, output_path)

            # Write to temp script file
            script_path = os.path.join(temp_dir, "chart_script.py")
            with open(script_path, "w", encoding="utf-8") as f:
                f.write(prepared_code)

            # Run the script
            stdout, stderr, return_code = await run_uv_script(script_path, timeout=120)

            # Filter uv noise from stderr
            if stderr:
                filtered_stderr = [
                    line
                    for line in stderr.split("\n")
                    if line.strip()
                    and not any(
                        skip in line.lower()
                        for skip in ["downloading", "installed", "resolved", "prepared", "audited", "packages in"]
                    )
                ]
                stderr = "\n".join(filtered_stderr)

            if return_code != 0:
                error_msg = stderr or stdout or "Unknown error"
                return ctx.error("CreateChart", f"Chart generation failed:\n{error_msg}")

            # Check if output file was created
            if not os.path.exists(output_path):
                return ctx.error(
                    "CreateChart",
                    f"No image file was generated. Make sure to use plt.savefig(OUTPUT_FILE)\n\nOutput:\n{stdout}",
                )

            # Read the generated image
            with open(output_path, "rb") as f:
                image_bytes = f.read()

            # Save to project storage
            storage_path = ctx.resolve_path(filename)
            if ctx.storage.exists(storage_path):
                ctx.storage.delete(storage_path)
            ctx.storage.save(storage_path, ContentFile(image_bytes))

            # Record in AiVisualization model
            try:
                from ainstein.models import AiVisualization

                # Detect chart type from code
                chart_type = "unknown"
                code_lower = code.lower()
                if any(p in code_lower for p in ["plt.bar", "px.bar", ".barplot", ".bar(", "barh("]):
                    chart_type = "bar"
                elif any(p in code_lower for p in ["plt.plot", "px.line", ".lineplot", ".line("]):
                    chart_type = "line"
                elif any(p in code_lower for p in ["plt.scatter", "px.scatter", ".scatterplot", ".scatter("]):
                    chart_type = "scatter"
                elif any(p in code_lower for p in ["plt.pie", "px.pie", ".pie("]):
                    chart_type = "pie"
                elif any(p in code_lower for p in ["plt.hist", "px.histogram", ".histplot", ".hist("]):
                    chart_type = "histogram"
                elif any(p in code_lower for p in ["heatmap", ".imshow("]):
                    chart_type = "heatmap"
                elif any(p in code_lower for p in [".boxplot", "px.box", ".box("]):
                    chart_type = "box"
                elif any(p in code_lower for p in [".violinplot", "px.violin"]):
                    chart_type = "violin"
                elif any(p in code_lower for p in [".pairplot", "px.scatter_matrix"]):
                    chart_type = "pairplot"
                elif "plotly" in code_lower:
                    chart_type = "plotly"

                # Extract title from code if present
                title = filename.rsplit(".", 1)[0]
                if "plt.title(" in code or "title=" in code:
                    import re

                    title_match = re.search(r'(?:plt\.title|title=)\s*\(\s*[\'"]([^\'"]+)[\'"]', code)
                    if title_match:
                        title = title_match.group(1)

                await sync_to_async(AiVisualization.objects.create)(
                    project=ctx.project,
                    conversation=ctx.conversation,
                    title=title,
                    chart_type=chart_type,
                    image_path=filename,
                    source_code=code,
                )
            except Exception as e:
                logger.warning(f"Failed to save visualization record: {e}")

            # Emit tool result with stats and image URL for UI
            # Use reverse() to generate URL dynamically - avoids hardcoded paths that break
            # when the app is mounted at different URL prefixes (e.g., /ainstein/ vs /api/claude-agent/)
            image_url = reverse("ainstein:project-raw-file", kwargs={"pk": ctx.project.id, "file_path": filename})
            ctx.tool_result(
                stats={
                    "size": len(image_bytes),
                    "chart_type": chart_type,
                    "filename": filename,
                    "image_url": image_url,
                },
                summary=f"Chart: {filename}",
            )

            result_parts = [f"Chart saved to: {filename} ({len(image_bytes):,} bytes)"]
            if stdout.strip():
                result_parts.append(f"\nOutput:\n{stdout.strip()}")

            return ctx.success("\n".join(result_parts))

    @tool(
        "list_chart_types",
        "List supported chart types and example code snippets.",
        {},
    )
    async def list_chart_types(args: dict[str, Any]) -> dict[str, Any]:
        """List available chart types with examples."""
        chart_info = """# Chart Types & Examples

## Bar Chart
```python
# /// script
# dependencies = ["matplotlib"]
# ///
import matplotlib.pyplot as plt
plt.bar(['A', 'B', 'C'], [10, 20, 15])
plt.title('Bar Chart')
plt.savefig(OUTPUT_FILE)
```

## Line Chart
```python
# /// script
# dependencies = ["matplotlib"]
# ///
import matplotlib.pyplot as plt
plt.plot([1, 2, 3, 4], [10, 20, 25, 30], marker='o')
plt.title('Line Chart')
plt.savefig(OUTPUT_FILE)
```

## Pie Chart
```python
# /// script
# dependencies = ["matplotlib"]
# ///
import matplotlib.pyplot as plt
plt.pie([30, 20, 50], labels=['A', 'B', 'C'], autopct='%1.1f%%')
plt.title('Pie Chart')
plt.savefig(OUTPUT_FILE)
```

## Scatter Plot
```python
# /// script
# dependencies = ["matplotlib"]
# ///
import matplotlib.pyplot as plt
plt.scatter([1, 2, 3, 4], [10, 15, 13, 17])
plt.title('Scatter Plot')
plt.savefig(OUTPUT_FILE)
```

## Heatmap (seaborn)
```python
# /// script
# dependencies = ["matplotlib", "seaborn", "pandas", "numpy"]
# ///
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
data = np.random.rand(5, 5)
sns.heatmap(data, annot=True)
plt.savefig(OUTPUT_FILE)
```

## Plotly (static export)
```python
# /// script
# dependencies = ["plotly", "kaleido"]
# ///
import plotly.express as px
fig = px.bar(x=['A', 'B', 'C'], y=[10, 20, 15])
fig.write_image(OUTPUT_FILE)
```

## Notes
- Always use `OUTPUT_FILE` for the output path
- Include all dependencies in the `# /// script` header
- For plotly static images, include `kaleido` dependency
"""
        return ctx.success(chart_info)

    @tool(
        "quick_chart",
        """Generate a chart from inline data with minimal code.

Args:
    data: Dict with column data, e.g. {"category": ["A", "B"], "value": [10, 20]}
    chart_type: 'bar', 'line', 'scatter', 'pie', 'histogram'
    title: Chart title
    x_column: Column for x-axis (default: first column)
    y_column: Column for y-axis (default: second column)
    filename: Output filename (optional)""",
        {
            "data": dict,
            "chart_type": str,
            "title": str,
            "x_column": str,
            "y_column": str,
            "filename": str,
        },
    )
    async def quick_chart(args: dict[str, Any]) -> dict[str, Any]:
        """Generate a quick chart from data."""
        import json

        data = args.get("data", {})
        chart_type = args.get("chart_type", "bar")
        title = args.get("title", "Chart")
        x_column = args.get("x_column", "")
        y_column = args.get("y_column", "")
        filename = args.get("filename", "") or f"chart_{uuid.uuid4().hex[:8]}.png"

        if not data:
            return ctx.error("QuickChart", "No data provided")

        # Get column names
        columns = list(data.keys())
        if not x_column:
            x_column = columns[0] if columns else "x"
        if not y_column:
            y_column = columns[1] if len(columns) > 1 else columns[0]

        data_json = json.dumps(data)

        code = f'''# /// script
# dependencies = ["matplotlib", "pandas"]
# ///
import matplotlib.pyplot as plt
import pandas as pd

data = {data_json}
df = pd.DataFrame(data)

plt.figure(figsize=(10, 6))

if "{chart_type}" == "line":
    plt.plot(df["{x_column}"], df["{y_column}"], marker='o')
elif "{chart_type}" == "bar":
    plt.bar(df["{x_column}"], df["{y_column}"])
elif "{chart_type}" == "scatter":
    plt.scatter(df["{x_column}"], df["{y_column}"])
elif "{chart_type}" == "pie":
    plt.pie(df["{y_column}"], labels=df["{x_column}"], autopct='%1.1f%%')
elif "{chart_type}" == "histogram":
    plt.hist(df["{y_column}"], bins=20, edgecolor='black')

plt.title("{title}")
plt.xlabel("{x_column}")
plt.ylabel("{y_column}")
plt.tight_layout()
plt.savefig(OUTPUT_FILE, dpi=150, bbox_inches='tight')
'''

        return await create_chart({"code": code, "filename": filename})

    return [create_chart, list_chart_types, quick_chart]


def _prepare_chart_code(code: str, output_path: str) -> str:
    """Prepare chart code with matplotlib backend and OUTPUT_FILE variable."""
    lines = code.split("\n")

    # Find where to insert the setup code (after PEP 723 header)
    insert_idx = 0
    for i, line in enumerate(lines):
        if line.strip() == "# ///":
            insert_idx = i + 1
            break

    # Setup code to insert - matplotlib backend and OUTPUT_FILE
    setup_lines = [
        "import matplotlib; matplotlib.use('Agg')",
        f"OUTPUT_FILE = r'{output_path}'",
    ]

    # Insert setup code
    for j, setup_line in enumerate(setup_lines):
        lines.insert(insert_idx + j, setup_line)

    return "\n".join(lines)
