"""
Multi-Model Support Tools (Phase 9.4).

Tools for model selection, routing, and cost optimization.
"""

import logging
from typing import Any

from claude_agent_sdk import tool

from ainstein.tools.base import ToolContext


logger = logging.getLogger(__name__)

# Model definitions with capabilities and pricing
AVAILABLE_MODELS = {
    "claude-opus-4-5-20251101": {
        "name": "Claude Opus 4.5",
        "tier": "opus",
        "context_window": 200000,
        "max_output": 32000,
        "input_cost_per_mtok": 15.00,
        "output_cost_per_mtok": 75.00,
        "capabilities": ["complex_reasoning", "creative_writing", "code_generation", "analysis", "long_context"],
        "best_for": ["Complex multi-step reasoning", "Creative tasks", "Detailed analysis"],
        "speed": "slow",
    },
    "claude-sonnet-4-5-20250929": {
        "name": "Claude Sonnet 4.5",
        "tier": "sonnet",
        "context_window": 200000,
        "max_output": 16000,
        "input_cost_per_mtok": 3.00,
        "output_cost_per_mtok": 15.00,
        "capabilities": ["reasoning", "code_generation", "analysis", "writing", "tool_use"],
        "best_for": ["General tasks", "Code assistance", "Analysis"],
        "speed": "medium",
    },
    "claude-haiku-4-5-20251001": {
        "name": "Claude Haiku 4.5",
        "tier": "haiku",
        "context_window": 200000,
        "max_output": 8192,
        "input_cost_per_mtok": 0.80,
        "output_cost_per_mtok": 4.00,
        "capabilities": ["quick_tasks", "simple_code", "summarization", "classification"],
        "best_for": ["Quick responses", "Simple tasks", "High volume"],
        "speed": "fast",
    },
}

# Task type to recommended model mapping
TASK_MODEL_ROUTING = {
    "code_execution": "claude-haiku-4-5-20251001",
    "code_review": "claude-sonnet-4-5-20250929",
    "complex_analysis": "claude-opus-4-5-20251101",
    "creative_writing": "claude-opus-4-5-20251101",
    "data_transformation": "claude-haiku-4-5-20251001",
    "summarization": "claude-haiku-4-5-20251001",
    "question_answering": "claude-sonnet-4-5-20250929",
    "debugging": "claude-sonnet-4-5-20250929",
    "documentation": "claude-sonnet-4-5-20250929",
    "planning": "claude-opus-4-5-20251101",
    "simple_query": "claude-haiku-4-5-20251001",
}


def estimate_cost(model_id: str, input_tokens: int, output_tokens: int) -> float:
    """Estimate cost for a model call."""
    model = AVAILABLE_MODELS.get(model_id)
    if not model:
        return 0.0

    input_cost = (input_tokens / 1_000_000) * model["input_cost_per_mtok"]
    output_cost = (output_tokens / 1_000_000) * model["output_cost_per_mtok"]
    return input_cost + output_cost


def recommend_model(task_type: str, input_length: int = 0, priority: str = "balanced") -> str:
    """
    Recommend a model based on task type and constraints.

    Args:
        task_type: Type of task
        input_length: Approximate input token count
        priority: 'cost', 'quality', or 'balanced'
    """
    # Get base recommendation
    base_model = TASK_MODEL_ROUTING.get(task_type, "claude-sonnet-4-5-20250929")

    if priority == "cost":
        # Always use cheapest that can handle the task
        return "claude-haiku-4-5-20251001"
    if priority == "quality":
        # Use opus for complex tasks, sonnet otherwise
        if task_type in ["complex_analysis", "creative_writing", "planning"]:
            return "claude-opus-4-5-20251101"
        return "claude-sonnet-4-5-20250929"
    # Balanced - use the task-specific recommendation
    return base_model


def create_model_routing_tools(ctx: ToolContext) -> list:
    """Create model routing and selection tools."""

    @tool(
        "recommend_model",
        """Get a model recommendation for a specific task.

Args:
    task_type: Type of task (code_execution, code_review, complex_analysis, etc.)
    input_tokens: Estimated input token count
    priority: 'cost', 'quality', or 'balanced'
""",
        {
            "task_type": str,
            "input_tokens": int,
            "priority": str,
        },
    )
    async def recommend_model_tool(args: dict[str, Any]) -> dict[str, Any]:
        """Get model recommendation."""
        task_type = args.get("task_type", "general")
        input_tokens = args.get("input_tokens", 1000)
        priority = args.get("priority", "balanced")

        ctx.tool_start("RecommendModel", f"Recommending for {task_type}", {})

        recommended = recommend_model(task_type, input_tokens, priority)
        model_info = AVAILABLE_MODELS.get(recommended, {})

        # Estimate costs for comparison
        output_estimate = min(input_tokens, model_info.get("max_output", 4096))

        result = "# Model Recommendation\n\n"
        result += f"**Task Type:** {task_type}\n"
        result += f"**Priority:** {priority}\n"
        result += f"**Input Tokens:** ~{input_tokens:,}\n\n"

        result += f"## Recommended: {model_info.get('name', recommended)}\n\n"
        result += f"- Model ID: `{recommended}`\n"
        result += f"- Tier: {model_info.get('tier', 'unknown').upper()}\n"
        result += f"- Speed: {model_info.get('speed', 'unknown')}\n\n"

        result += "## Cost Comparison\n\n"
        result += "| Model | Est. Cost |\n"
        result += "|-------|----------|\n"

        for model_id, info in AVAILABLE_MODELS.items():
            est_cost = estimate_cost(model_id, input_tokens, output_estimate)
            marker = " ← Recommended" if model_id == recommended else ""
            result += f"| {info['name']} | ${est_cost:.4f}{marker} |\n"

        ctx.tool_result(summary=model_info.get("name", recommended))
        return ctx.success(result)

    @tool(
        "estimate_cost",
        """Estimate the cost of a model call.

Args:
    model_id: Model to use (or 'auto' for recommendation)
    input_tokens: Number of input tokens
    output_tokens: Expected output tokens
""",
        {
            "model_id": str,
            "input_tokens": int,
            "output_tokens": int,
        },
    )
    async def estimate_cost_tool(args: dict[str, Any]) -> dict[str, Any]:
        """Estimate cost."""
        model_id = args.get("model_id", "claude-sonnet-4-5-20250929")
        input_tokens = args.get("input_tokens", 1000)
        output_tokens = args.get("output_tokens", 1000)

        ctx.tool_start("EstimateCost", f"Estimating for {model_id}", {})

        if model_id == "auto":
            model_id = "claude-sonnet-4-5-20250929"

        model_info = AVAILABLE_MODELS.get(model_id)
        if not model_info:
            return ctx.error("EstimateCost", f"Unknown model: {model_id}")

        cost = estimate_cost(model_id, input_tokens, output_tokens)

        result = "# Cost Estimate\n\n"
        result += f"**Model:** {model_info['name']}\n"
        result += f"**Input Tokens:** {input_tokens:,}\n"
        result += f"**Output Tokens:** {output_tokens:,}\n\n"

        input_cost = (input_tokens / 1_000_000) * model_info["input_cost_per_mtok"]
        output_cost = (output_tokens / 1_000_000) * model_info["output_cost_per_mtok"]

        result += "## Breakdown\n\n"
        result += f"- Input: ${input_cost:.6f}\n"
        result += f"- Output: ${output_cost:.6f}\n"
        result += f"- **Total: ${cost:.6f}**\n\n"

        # Compare with other models
        result += "## Comparison\n\n"
        result += "| Model | Cost | Savings |\n"
        result += "|-------|------|--------|\n"

        for mid, info in AVAILABLE_MODELS.items():
            alt_cost = estimate_cost(mid, input_tokens, output_tokens)
            savings = cost - alt_cost
            savings_pct = (savings / cost * 100) if cost > 0 else 0
            marker = " ← Selected" if mid == model_id else ""
            result += (
                f"| {info['name']} | ${alt_cost:.6f} | {'+' if savings >= 0 else ''}{savings_pct:.1f}%{marker} |\n"
            )

        ctx.tool_result(summary=f"${cost:.6f}")
        return ctx.success(result)

    @tool(
        "set_model_preference",
        """Set model preference for the current session.

Args:
    model_id: Preferred model ID
    auto_route: Enable automatic task-based routing
    cost_priority: Prioritize cost over quality (0.0-1.0)
""",
        {
            "model_id": str,
            "auto_route": bool,
            "cost_priority": float,
        },
    )
    async def set_model_preference(args: dict[str, Any]) -> dict[str, Any]:
        """Set model preference."""
        model_id = args.get("model_id", "")
        auto_route = args.get("auto_route", True)
        cost_priority = args.get("cost_priority", 0.5)

        ctx.tool_start("SetModelPreference", "Setting preferences", {})

        if model_id and model_id not in AVAILABLE_MODELS:
            return ctx.error("SetModelPreference", f"Unknown model: {model_id}")

        # Store preferences (would typically go in session/project settings)

        result = "# Model Preferences Updated\n\n"

        if model_id:
            model_info = AVAILABLE_MODELS[model_id]
            result += f"- **Preferred Model:** {model_info['name']}\n"
        else:
            result += "- **Preferred Model:** Auto-select\n"

        result += f"- **Auto Routing:** {'Enabled' if auto_route else 'Disabled'}\n"
        result += f"- **Cost Priority:** {cost_priority * 100:.0f}%\n"

        if auto_route:
            result += "\nWith auto-routing enabled, the system will:\n"
            result += "- Use Haiku for simple/quick tasks\n"
            result += "- Use Sonnet for general tasks\n"
            result += "- Use Opus for complex reasoning\n"

        ctx.tool_result(summary="Preferences set")
        return ctx.success(result)

    return [recommend_model_tool, estimate_cost_tool, set_model_preference]
