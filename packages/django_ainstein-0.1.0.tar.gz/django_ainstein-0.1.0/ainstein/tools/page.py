"""
Page file tools for BlockNote JSON operations.

Provides tools for creating, reading, editing, and managing .page files
which store BlockNote JSON block data.

References:
- Block types: https://www.blocknotejs.org/docs/features/blocks
- Manipulation: https://www.blocknotejs.org/docs/foundations/manipulating-content
- Editor API: https://www.blocknotejs.org/docs/reference/editor/manipulating-content

Built-in block types:
- paragraph: Text content
- heading: Headers (level 1-3)
- bulletListItem: Unordered list item
- numberedListItem: Ordered list item
- checkListItem: Checkbox item
- codeBlock: Code with syntax highlighting
- table: Table with rows/cells
- image: Image with URL
- video: Video embed
- audio: Audio embed
- file: File attachment

Tools:
- page_write: Create/update .page file with BlockNote JSON blocks
- markdown_to_blocks: Convert markdown to JSON blocks
- page_read: Read file and list blocks with IDs
- page_append: Append JSON blocks to end
- page_insert: Insert JSON blocks at index
- page_update: Update block type, props, or content by ID
- page_delete: Delete blocks by ID
- page_move: Move block to new position
- page_nest: Indent block (make child of previous sibling)
- page_unnest: Outdent block (move to parent level)
"""

import json
import logging
import re
import uuid
from typing import Any

from claude_agent_sdk import tool

from ainstein.tools.base import ToolContext, make_block


logger = logging.getLogger(__name__)


def text_to_blocks(text: str, is_cancelled: callable = None) -> list:
    """Convert markdown-like text to BlockNote blocks.

    Args:
        text: Markdown-like text to convert
        is_cancelled: Optional callback to check if operation was cancelled.
                      Checked every 100 lines to allow early exit.
    """
    blocks = []
    lines = text.split("\n")
    i = 0

    while i < len(lines):
        # Check cancellation every 100 lines to allow early exit
        if is_cancelled and i > 0 and i % 100 == 0 and is_cancelled():
            break

        line = lines[i]
        block_id = uuid.uuid4().hex[:8]

        if not line.strip():
            i += 1
            continue

        # Code block
        if line.strip().startswith("```"):
            lang = line.strip()[3:].strip() or "text"
            code_lines = []
            i += 1
            while i < len(lines) and not lines[i].strip().startswith("```"):
                code_lines.append(lines[i])
                i += 1
            i += 1
            blocks.append(make_block(block_id, "codeBlock", "\n".join(code_lines), {"language": lang}))
            continue

        # Headings
        if match := re.match(r"^(#{1,3})\s+(.+)$", line):
            blocks.append(make_block(block_id, "heading", match.group(2).strip(), {"level": len(match.group(1))}))
            i += 1
            continue

        # Checklist (- [ ] or - [x])
        if match := re.match(r"^[\-\*]\s+\[([ xX])\]\s+(.+)$", line):
            checked = match.group(1).lower() == "x"
            blocks.append(make_block(block_id, "checkListItem", match.group(2).strip(), {"checked": checked}))
            i += 1
            continue

        # Bullet list
        if match := re.match(r"^[\-\*]\s+(.+)$", line):
            blocks.append(make_block(block_id, "bulletListItem", match.group(1).strip()))
            i += 1
            continue

        # Numbered list
        if match := re.match(r"^\d+\.\s+(.+)$", line):
            blocks.append(make_block(block_id, "numberedListItem", match.group(1).strip()))
            i += 1
            continue

        # Paragraph (default)
        blocks.append(make_block(block_id, "paragraph", line))
        i += 1

    return blocks or [make_block(uuid.uuid4().hex[:8], "paragraph", "")]


def ensure_page_ext(path: str) -> str:
    """Ensure path has .page extension."""
    return path if path.endswith(".page") else path + ".page"


def read_page_blocks(ctx, path: str) -> list:
    """Read page file and return blocks array."""
    data = ctx.read_json(path)
    return data if isinstance(data, list) else []


def write_page_blocks(ctx, path: str, blocks: list) -> None:
    """Write page file as pure blocks array."""
    ctx.write_json(path, blocks)


def create_page_tools(ctx: ToolContext) -> list:
    """Create all page file tools."""

    @tool(
        "page_write",
        "Create/update a .page file with BlockNote JSON blocks array",
        {"path": str, "blocks": list},
    )
    async def page_write(args: dict[str, Any]) -> dict[str, Any]:
        user_path = ensure_page_ext(args["path"])
        blocks = args["blocks"]

        # Handle case where blocks is passed as JSON string
        if isinstance(blocks, str):
            try:
                blocks = json.loads(blocks)
            except json.JSONDecodeError as e:
                return ctx.error("PageWrite", f"Invalid JSON in blocks: {e}")

        try:
            path = ctx.resolve_path(user_path)
            is_update = ctx.storage.exists(path)

            # Pure blocks array format
            write_page_blocks(ctx, path, blocks)

            action = "Updated" if is_update else "Created"
            ctx.tool_start(f"Page{action}", user_path, {"path": user_path, "blocks": blocks})
            ctx.tool_result(stats={"blocks": len(blocks)})
            return ctx.success(f"{action}: {user_path} ({len(blocks)} blocks)")
        except Exception as e:
            logger.exception(f"page_write error: {e}")
            return ctx.error("PageWrite", str(e))

    @tool(
        "markdown_to_blocks",
        "Convert markdown text to BlockNote JSON blocks (for use with page_write)",
        {"markdown": str},
    )
    async def markdown_to_blocks(args: dict[str, Any]) -> dict[str, Any]:
        markdown_text = args["markdown"]

        try:
            # Pass is_cancelled to allow early exit during block conversion
            blocks = text_to_blocks(markdown_text, is_cancelled=ctx.is_cancelled)

            ctx.tool_start("MarkdownToBlocks", f"{len(markdown_text)} chars", {"markdown": markdown_text})
            ctx.tool_result(stats={"blocks": len(blocks)})

            # Return the blocks as JSON for the agent to use with page_write
            return ctx.success(json.dumps(blocks, indent=2))
        except Exception as e:
            logger.exception(f"markdown_to_blocks error: {e}")
            return ctx.error("MarkdownToBlocks", str(e))

    @tool(
        "page_append",
        "Append JSON blocks to end of .page file",
        {"path": str, "blocks": list},
    )
    async def page_append(args: dict[str, Any]) -> dict[str, Any]:
        user_path = args["path"]
        new_blocks = args["blocks"]

        # Handle case where blocks is passed as JSON string
        if isinstance(new_blocks, str):
            try:
                new_blocks = json.loads(new_blocks)
            except json.JSONDecodeError as e:
                return ctx.error("PageAppend", f"Invalid JSON in blocks: {e}")

        result = ctx.require_file("PageAppend", user_path)
        if isinstance(result, dict):
            return result
        path = result

        blocks = read_page_blocks(ctx, path)
        blocks.extend(new_blocks)
        write_page_blocks(ctx, path, blocks)

        ctx.tool_start("PageAppend", user_path, {"path": user_path, "blocks": new_blocks})
        ctx.tool_result(stats={"blocks": len(new_blocks)})
        return ctx.success(f"Appended {len(new_blocks)} blocks to {user_path}")

    @tool(
        "page_insert",
        "Insert JSON blocks at position in .page file",
        {"path": str, "index": int, "blocks": list},
    )
    async def page_insert(args: dict[str, Any]) -> dict[str, Any]:
        user_path, index = args["path"], args["index"]
        new_blocks = args["blocks"]

        # Handle case where blocks is passed as JSON string
        if isinstance(new_blocks, str):
            try:
                new_blocks = json.loads(new_blocks)
            except json.JSONDecodeError as e:
                return ctx.error("PageInsert", f"Invalid JSON in blocks: {e}")

        result = ctx.require_file("PageInsert", user_path)
        if isinstance(result, dict):
            return result
        path = result

        blocks = read_page_blocks(ctx, path)
        for i, block in enumerate(new_blocks):
            blocks.insert(index + i, block)
        write_page_blocks(ctx, path, blocks)

        args_data = {"path": user_path, "index": index, "blocks": new_blocks}
        ctx.tool_start("PageInsert", f"{user_path} at index {index}", args_data)
        ctx.tool_result(stats={"blocks": len(new_blocks)})
        return ctx.success(f"Inserted {len(new_blocks)} blocks at index {index}")

    @tool(
        "page_update",
        "Update a block's type, props, or content by ID",
        {"path": str, "block_id": str, "type": str, "props": dict, "content": Any},
    )
    async def page_update(args: dict[str, Any]) -> dict[str, Any]:
        user_path = args["path"]
        block_id = args["block_id"]
        new_type = args.get("type")
        new_props = args.get("props")
        new_content = args.get("content")

        result = ctx.require_file("PageUpdate", user_path)
        if isinstance(result, dict):
            return result
        path = result

        blocks = read_page_blocks(ctx, path)

        def update_block(block_list):
            for block in block_list:
                if block.get("id") == block_id:
                    if new_type:
                        block["type"] = new_type
                    if new_props:
                        block["props"] = {**block.get("props", {}), **new_props}
                    if new_content is not None:
                        if isinstance(new_content, str):
                            block["content"] = [{"type": "text", "text": new_content, "styles": {}}]
                        else:
                            block["content"] = new_content
                    return True
                if update_block(block.get("children", [])):
                    return True
            return False

        if not update_block(blocks):
            return ctx.error("PageUpdate", f"block not found: {block_id}")

        write_page_blocks(ctx, path, blocks)
        changes = []
        if new_type:
            changes.append(f"type={new_type}")
        if new_props:
            changes.append(f"props={list(new_props.keys())}")
        if new_content is not None:
            changes.append("content")
        args_data = {
            "path": user_path,
            "block_id": block_id,
            "type": new_type,
            "props": new_props,
            "content": new_content,
        }
        ctx.tool_start("PageUpdate", f"{user_path} block={block_id}", args_data)
        ctx.tool_result(summary=f"Updated: {', '.join(changes)}")
        return ctx.success(f"Updated block {block_id}: {', '.join(changes)}")

    @tool("page_delete", "Delete blocks by ID from .page file", {"path": str, "block_ids": list})
    async def page_delete(args: dict[str, Any]) -> dict[str, Any]:
        user_path, block_ids = args["path"], args["block_ids"]
        result = ctx.require_file("PageDelete", user_path)
        if isinstance(result, dict):
            return result
        path = result

        blocks = read_page_blocks(ctx, path)
        original_count = len(blocks)
        blocks = [b for b in blocks if b.get("id") not in block_ids]
        deleted_count = original_count - len(blocks)
        write_page_blocks(ctx, path, blocks)

        args_data = {"path": user_path, "block_ids": block_ids}
        ctx.tool_start("PageDelete", f"{user_path} ({len(block_ids)} blocks)", args_data)
        ctx.tool_result(stats={"deleted": deleted_count, "remaining": len(blocks)})
        return ctx.success(f"Deleted {deleted_count} blocks from {user_path}")

    @tool("page_read", "Read .page file and list blocks with IDs", {"path": str})
    async def page_read(args: dict[str, Any]) -> dict[str, Any]:
        user_path = args["path"]
        result = ctx.require_file("PageRead", user_path)
        if isinstance(result, dict):
            return result
        path = result

        blocks = read_page_blocks(ctx, path)
        summary = []
        for i, block in enumerate(blocks):
            block_id = block.get("id", "?")
            block_type = block.get("type", "?")
            texts = [c.get("text", "") for c in block.get("content", []) if c.get("type") == "text"]
            preview = " ".join(texts)[:50]
            summary.append(f"[{i}] {block_type} (id={block_id}): {preview}...")

        ctx.tool_start("PageRead", user_path, {"path": user_path})
        ctx.tool_result(stats={"blocks": len(blocks)})

        result_text = f"File: {user_path}\n"
        result_text += f"Blocks: {len(blocks)}\n\n" + "\n".join(summary)
        result_text += f"\n\nFull JSON:\n{json.dumps(blocks, indent=2)}"
        return ctx.success(result_text)

    @tool("page_move", "Move a block to a new position by ID", {"path": str, "block_id": str, "new_index": int})
    async def page_move(args: dict[str, Any]) -> dict[str, Any]:
        user_path, block_id, new_index = args["path"], args["block_id"], args["new_index"]
        result = ctx.require_file("PageMove", user_path)
        if isinstance(result, dict):
            return result
        path = result

        blocks = read_page_blocks(ctx, path)
        original_index = None
        for i, block in enumerate(blocks):
            if block.get("id") == block_id:
                original_index = i
                break

        if original_index is None:
            return ctx.error("PageMove", f"block not found: {block_id}")

        block_to_move = blocks.pop(original_index)
        new_index = min(new_index, len(blocks)) if new_index > original_index else max(0, new_index)
        blocks.insert(new_index, block_to_move)
        write_page_blocks(ctx, path, blocks)

        args_data = {"path": user_path, "block_id": block_id, "new_index": new_index}
        ctx.tool_start("PageMove", f"{user_path} block={block_id} → index {new_index}", args_data)
        ctx.tool_result(summary=f"Moved from index {original_index} → {new_index}")
        return ctx.success(f"Moved block {block_id} from index {original_index} to {new_index}")

    @tool("page_nest", "Indent block (make it a child of the previous block)", {"path": str, "block_id": str})
    async def page_nest(args: dict[str, Any]) -> dict[str, Any]:
        user_path, block_id = args["path"], args["block_id"]
        result = ctx.require_file("PageNest", user_path)
        if isinstance(result, dict):
            return result
        path = result

        blocks = read_page_blocks(ctx, path)

        def find_and_nest(block_list, parent_list=None, parent_idx=None):
            for i, block in enumerate(block_list):
                if block.get("id") == block_id:
                    if i == 0:
                        return None, "Cannot nest first block (no previous sibling)"
                    prev_block = block_list[i - 1]
                    block_to_nest = block_list.pop(i)
                    if "children" not in prev_block:
                        prev_block["children"] = []
                    prev_block["children"].append(block_to_nest)
                    return prev_block.get("id"), None
                result_id, err = find_and_nest(block.get("children", []), block_list, i)
                if result_id or err:
                    return result_id, err
            return None, None

        parent_id, error = find_and_nest(blocks)
        if error:
            return ctx.error("PageNest", error)
        if not parent_id:
            return ctx.error("PageNest", f"block not found: {block_id}")

        write_page_blocks(ctx, path, blocks)
        args_data = {"path": user_path, "block_id": block_id}
        ctx.tool_start("PageNest", f"{user_path} block={block_id}", args_data)
        ctx.tool_result(summary=f"Nested under block {parent_id}")
        return ctx.success(f"Nested block {block_id} under {parent_id}")

    @tool("page_unnest", "Outdent block (move from children to parent level)", {"path": str, "block_id": str})
    async def page_unnest(args: dict[str, Any]) -> dict[str, Any]:
        user_path, block_id = args["path"], args["block_id"]
        result = ctx.require_file("PageUnnest", user_path)
        if isinstance(result, dict):
            return result
        path = result

        blocks = read_page_blocks(ctx, path)

        def find_and_unnest(block_list, parent_list=None, parent_idx=None):
            for i, block in enumerate(block_list):
                children = block.get("children", [])
                for j, child in enumerate(children):
                    if child.get("id") == block_id:
                        unnested = children.pop(j)
                        block_list.insert(i + 1, unnested)
                        return True, None
                    found, err = find_and_unnest([child], children, j)
                    if found:
                        return True, None
            return False, None

        found, _ = find_and_unnest(blocks)
        if not found:
            # Check if it's a top-level block (can't unnest)
            for block in blocks:
                if block.get("id") == block_id:
                    return ctx.error("PageUnnest", "Block is already at top level")
            return ctx.error("PageUnnest", f"block not found: {block_id}")

        write_page_blocks(ctx, path, blocks)
        args_data = {"path": user_path, "block_id": block_id}
        ctx.tool_start("PageUnnest", f"{user_path} block={block_id}", args_data)
        ctx.tool_result(summary="Moved to parent level")
        return ctx.success(f"Unnested block {block_id} to parent level")

    return [
        page_write,
        markdown_to_blocks,
        page_append,
        page_insert,
        page_update,
        page_delete,
        page_read,
        page_move,
        page_nest,
        page_unnest,
    ]
