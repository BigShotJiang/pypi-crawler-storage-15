"""
UV-based code execution tools for Claude Agent.

Executes Python code using `uv run`. The agent includes PEP 723 inline script
metadata at the top of the code to specify dependencies.

Example code format:
    # /// script
    # dependencies = ["requests", "pandas>=2.0"]
    # ///
    import requests
    import pandas as pd
    ...
"""

import asyncio
import contextlib
import logging
import os
import shutil
import tempfile
from typing import Any

from asgiref.sync import sync_to_async
from claude_agent_sdk import tool

from ainstein.tools.base import ToolContext


logger = logging.getLogger(__name__)

TOOLS_REQUIRING_APPROVAL = [
    "uv_execute_code",
    "uv_sandbox",
]

# Environment variables needed for networking on Windows
NETWORK_ENV_VARS = (
    "PATH",
    "SystemRoot",
    "SYSTEMROOT",
    "TEMP",
    "TMP",
    "USERPROFILE",
    "APPDATA",
    "LOCALAPPDATA",
    "HOMEDRIVE",
    "HOMEPATH",
    "HTTP_PROXY",
    "HTTPS_PROXY",
    "NO_PROXY",
    "UV_INDEX_URL",
    "UV_EXTRA_INDEX_URL",
    "SSL_CERT_FILE",
    "SSL_CERT_DIR",
)

# API key environment variables to pass through
API_KEY_ENV_VARS = ("OPENROUTER_API_KEY",)


def build_sandbox_env() -> dict[str, str]:
    """Build environment dict for sandboxed subprocess with networking support."""
    env = {}
    for key in NETWORK_ENV_VARS + API_KEY_ENV_VARS:
        if key in os.environ:
            env[key] = os.environ[key]
    return env


async def run_uv_script(script_path: str, timeout: int = 120) -> tuple[str, str, int]:
    """Run a Python script using uv run."""
    uv_path = shutil.which("uv")
    if not uv_path:
        return "", "uv not found in PATH", 1

    env = build_sandbox_env()

    try:
        process = await asyncio.create_subprocess_exec(
            uv_path,
            "run",
            script_path,
            env=env,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=tempfile.gettempdir(),
        )

        try:
            stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=timeout)
            return (
                stdout.decode("utf-8", errors="replace"),
                stderr.decode("utf-8", errors="replace"),
                process.returncode or 0,
            )
        except TimeoutError:
            process.kill()
            await process.wait()
            return "", f"Execution timed out after {timeout} seconds", 124

    except Exception as e:
        return "", f"Failed to execute: {e}", 1


async def fetch_openrouter_models(supported_parameters: str = None):
    """Fetch available models from OpenRouter API using the SDK."""
    from openrouter import OpenRouter

    async with OpenRouter() as client:
        return await client.models.list_async(supported_parameters=supported_parameters)


# Default sandbox dependencies (common data science & utility libraries)
SANDBOX_DEPS = [
    # Data Science
    "pandas",
    "numpy",
    "scipy",
    "scikit-learn",
    "statsmodels",
    # Visualization
    "matplotlib",
    "seaborn",
    # File Processing
    "pyarrow",
    "openpyxl",
    "xlsxwriter",
    "xlrd",
    "pillow",
    "python-pptx",
    "python-docx",
    "pypdf",
    "pdfplumber",
    "reportlab",
    # Math & Computing
    "sympy",
    "mpmath",
    # Utilities
    "tqdm",
    "python-dateutil",
    "pytz",
    "joblib",
]


def create_uv_code_tools(ctx: ToolContext) -> list:
    """Create UV-based code execution tools."""

    @tool(
        "uv_sandbox",
        """Execute Python code in a sandboxed environment with common data science libraries pre-configured.

This tool automatically includes these dependencies:
- Data Science: pandas, numpy, scipy, scikit-learn, statsmodels
- Visualization: matplotlib, seaborn
- File Processing: pyarrow, openpyxl, xlsxwriter, xlrd, pillow, python-pptx, python-docx, pypdf, pdfplumber, reportlab
- Math & Computing: sympy, mpmath
- Utilities: tqdm, python-dateutil, pytz, joblib

No need to include a PEP 723 header - dependencies are auto-added.
For additional packages not in the list above, use uv_execute_code instead.

Example:
```python
import pandas as pd
import numpy as np

df = pd.DataFrame({'x': np.random.randn(100)})
print(df.describe())
```

REQUIRES USER APPROVAL.""",
        {
            "code": str,
            "description": str,
        },
    )
    async def uv_sandbox(args: dict[str, Any]) -> dict[str, Any]:
        """Execute Python code with pre-configured sandbox dependencies."""
        code = args.get("code", "")
        description = args.get("description", "Execute Python code in sandbox")

        if not code.strip():
            return ctx.error("UvSandbox", "No code provided")

        if ctx.is_cancelled():
            ctx.tool_start("UvSandbox", "Cancelled", {"description": description})
            ctx.tool_result(summary="Cancelled")
            return ctx.success("Code execution cancelled by user")

        ctx.tool_start("UvSandbox", description, {"code": code, "description": description})

        # Create execution record
        execution = None
        try:
            from ainstein.models import AiCodeExecution

            execution = await sync_to_async(AiCodeExecution.objects.create)(
                conversation=ctx.conversation,
                code=code,
                language="python",
                purpose=description[:255] if description else "UV sandbox execution",
            )
            await sync_to_async(execution.mark_running)()
        except Exception as e:
            logger.warning(f"Failed to create execution record: {e}")

        # Build PEP 723 header with sandbox deps
        deps_str = ", ".join(f'"{d}"' for d in SANDBOX_DEPS)
        full_code = f"# /// script\n# dependencies = [{deps_str}]\n# ///\n{code}"

        temp_file = None
        try:
            with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False, encoding="utf-8") as f:
                f.write(full_code)
                temp_file = f.name

            stdout, stderr, return_code = await run_uv_script(temp_file)

            output_parts = []

            if stdout:
                output_parts.append(f"Output:\n{stdout.rstrip()}")

            # Filter stderr to remove uv's package installation messages
            filtered_stderr = ""
            if stderr:
                filtered = [
                    line
                    for line in stderr.split("\n")
                    if line.strip()
                    and not any(
                        skip in line.lower()
                        for skip in ["downloading", "installed", "resolved", "prepared", "audited", "packages in"]
                    )
                ]
                if filtered:
                    filtered_stderr = "\n".join(filtered)
                    output_parts.append(f"Stderr:\n{filtered_stderr}")

            if return_code != 0:
                output_parts.append(f"Exit code: {return_code}")
                ctx.tool_result(summary=f"Error (exit {return_code})")
                # Record failure
                if execution:
                    await sync_to_async(execution.mark_failed)(
                        error_message="\n\n".join(output_parts) if output_parts else "Unknown error",
                        stderr=filtered_stderr,
                    )
                return ctx.error("UvSandbox", "\n\n".join(output_parts) if output_parts else "Unknown error")

            if not output_parts:
                output_parts.append("Code executed successfully (no output)")

            # Record success
            if execution:
                await sync_to_async(execution.mark_completed)(stdout=stdout)

            ctx.tool_result(summary="Done")
            return ctx.success("\n\n".join(output_parts))

        except Exception as e:
            if execution:
                await sync_to_async(execution.mark_failed)(error_message=str(e))
            raise

        finally:
            if temp_file and os.path.exists(temp_file):
                with contextlib.suppress(OSError):
                    os.unlink(temp_file)

    @tool(
        "uv_execute_code",
        """Execute Python code using uv run with automatic dependency installation.

The code MUST include PEP 723 inline script metadata at the top to specify dependencies:

# /// script
# dependencies = ["requests", "pandas>=2.0"]
# ///
import requests
...

The code runs in an isolated environment with network access.
API keys (OPENAI_API_KEY, ANTHROPIC_API_KEY, OPENROUTER_API_KEY, etc.) are available via os.environ.

REQUIRES USER APPROVAL.""",
        {
            "code": str,
            "description": str,
        },
    )
    async def uv_execute_code(args: dict[str, Any]) -> dict[str, Any]:
        """Execute Python code with uv run."""
        code = args.get("code", "")
        description = args.get("description", "Execute Python code")

        if not code.strip():
            return ctx.error("UvExecute", "No code provided")

        if ctx.is_cancelled():
            ctx.tool_start("UvExecute", "Cancelled", {"description": description})
            ctx.tool_result(summary="Cancelled")
            return ctx.success("Code execution cancelled by user")

        ctx.tool_start("UvExecute", description, {"code": code, "description": description})

        # Create execution record
        execution = None
        try:
            from ainstein.models import AiCodeExecution

            execution = await sync_to_async(AiCodeExecution.objects.create)(
                conversation=ctx.conversation,
                code=code,
                language="python",
                purpose=description[:255] if description else "UV code execution",
            )
            await sync_to_async(execution.mark_running)()
        except Exception as e:
            logger.warning(f"Failed to create execution record: {e}")

        temp_file = None
        try:
            with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False, encoding="utf-8") as f:
                f.write(code)
                temp_file = f.name

            stdout, stderr, return_code = await run_uv_script(temp_file)

            output_parts = []

            if stdout:
                output_parts.append(f"Output:\n{stdout.rstrip()}")

            # Filter stderr to remove uv's package installation messages
            filtered_stderr = ""
            if stderr:
                filtered = [
                    line
                    for line in stderr.split("\n")
                    if line.strip()
                    and not any(
                        skip in line.lower()
                        for skip in ["downloading", "installed", "resolved", "prepared", "audited", "packages in"]
                    )
                ]
                if filtered:
                    filtered_stderr = "\n".join(filtered)
                    output_parts.append(f"Stderr:\n{filtered_stderr}")

            if return_code != 0:
                output_parts.append(f"Exit code: {return_code}")
                ctx.tool_result(summary=f"Error (exit {return_code})")
                # Record failure
                if execution:
                    await sync_to_async(execution.mark_failed)(
                        error_message="\n\n".join(output_parts) if output_parts else "Unknown error",
                        stderr=filtered_stderr,
                    )
                return ctx.error("UvExecute", "\n\n".join(output_parts) if output_parts else "Unknown error")

            if not output_parts:
                output_parts.append("Code executed successfully (no output)")

            # Record success
            if execution:
                await sync_to_async(execution.mark_completed)(stdout=stdout)

            ctx.tool_result(summary="Done")
            return ctx.success("\n\n".join(output_parts))

        except Exception as e:
            if execution:
                await sync_to_async(execution.mark_failed)(error_message=str(e))
            raise

        finally:
            if temp_file and os.path.exists(temp_file):
                with contextlib.suppress(OSError):
                    os.unlink(temp_file)

    @tool(
        "openrouter_models",
        """Search OpenRouter for available LLM models.

Use this to find the correct model ID before generating code that calls an LLM.
Returns model IDs, names, and pricing info.

Parameters:
  - search: Text to search in model ID/name (e.g., "gpt-4", "claude", "gemini")
  - capability: Filter by capability - "tools" (function calling) or "vision" (image input)""",
        {
            "search": str,
            "capability": str,
        },
    )
    async def openrouter_models(args: dict[str, Any]) -> dict[str, Any]:
        """Search OpenRouter models."""
        search = args.get("search", "").lower()
        capability = args.get("capability", "")

        ctx.tool_start("OpenRouterModels", f"Search: {search}", {"search": search, "capability": capability})

        try:
            response = await fetch_openrouter_models(supported_parameters=capability if capability else None)
            models = response.data or []

            # Filter by search term
            if search:
                models = [m for m in models if search in (m.id or "").lower() or search in (m.name or "").lower()]

            if not models:
                ctx.tool_result(summary="No matches")
                return ctx.success(f"No models found matching '{search}'")

            # Format results
            lines = []
            for m in models[:20]:  # Limit to 20 results
                model_id = m.id or ""
                name = m.name or ""
                pricing = m.pricing
                prompt_cost = float(pricing.prompt or 0) * 1_000_000 if pricing else 0
                completion_cost = float(pricing.completion or 0) * 1_000_000 if pricing else 0
                lines.append(f"- {model_id}: {name} (${prompt_cost:.2f}/${completion_cost:.2f} per 1M tokens)")

            ctx.tool_result(summary=f"{len(models)} models")
            return ctx.success(f"Found {len(models)} models:\n" + "\n".join(lines))

        except Exception as e:
            ctx.tool_result(summary="Error")
            return ctx.error("OpenRouterModels", str(e))

    return [uv_sandbox, uv_execute_code, openrouter_models]
