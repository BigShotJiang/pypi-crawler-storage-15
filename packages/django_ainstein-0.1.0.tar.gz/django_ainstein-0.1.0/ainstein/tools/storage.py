"""
Storage tools for file operations.

Provides tools for reading, writing, deleting, listing, and moving files
in the configured Django storage backend.
"""

import difflib
import json
import logging
import os
from typing import Any

from claude_agent_sdk import tool
from django.core.files.base import ContentFile

from ainstein.events import Event, EventType
from ainstein.tools.base import ToolContext


logger = logging.getLogger(__name__)


def create_storage_tools(ctx: ToolContext) -> list:
    """Create all storage-related tools."""

    @tool("storage_read", "Read a file from storage", {"path": str})
    async def storage_read(args: dict[str, Any]) -> dict[str, Any]:
        user_path = args["path"]
        result = ctx.require_file("Read", user_path)
        if isinstance(result, dict):
            return result
        path = result

        ctx.file_mtimes[path] = ctx.get_mtime(path)
        content = ctx.read_file(path)

        ctx.tool_start("Read", user_path, {"path": user_path})
        ctx.tool_result(stats={"lines": len(content.splitlines()), "size_bytes": len(content)})
        return ctx.success(content)

    @tool("storage_write", "Write/create a file in storage", {"path": str, "content": str})
    async def storage_write(args: dict[str, Any]) -> dict[str, Any]:
        user_path, content = args["path"], args["content"]

        # Check cancellation before expensive write operation
        if ctx.is_cancelled():
            logger.info(f"storage_write cancelled before write: {user_path}")
            # Emit tool events so cancelled state is saved properly
            ctx.tool_start("Write", user_path, {"path": user_path})
            ctx.tool_result(summary="Cancelled")
            return ctx.success("Operation cancelled by user")

        try:
            path = ctx.resolve_path(user_path)
            is_update = ctx.storage.exists(path)

            # Check for external modification conflict
            if is_update:
                current_mtime = ctx.get_mtime(path)
                last_known = ctx.file_mtimes.get(path)
                if last_known is not None and current_mtime != last_known:
                    ctx.file_mtimes[path] = current_mtime
                    return ctx.error("Write", f"CONFLICT: {user_path} was modified externally")

            old_content = ctx.read_file(path) if is_update else ""
            ctx.write_file(path, content)
            ctx.file_mtimes[path] = ctx.get_mtime(path)

            action = "Update" if is_update else "Write"
            ctx.tool_start(action, user_path, {"path": user_path, "content": content})

            if is_update:
                diff = list(
                    difflib.unified_diff(
                        old_content.splitlines(),
                        content.splitlines(),
                        fromfile=f"a/{user_path}",
                        tofile=f"b/{user_path}",
                        lineterm="",
                    )
                )
                additions = sum(1 for line in diff if line.startswith("+") and not line.startswith("+++"))
                removals = sum(1 for line in diff if line.startswith("-") and not line.startswith("---"))
                ctx.tool_result(stats={"additions": additions, "removals": removals, "size_bytes": len(content)})
                if diff:
                    ctx.emit(Event(EventType.DIFF, {"lines": diff}))
            else:
                ctx.tool_result(stats={"lines": len(content.splitlines()), "size_bytes": len(content)})

            return ctx.success(f"Written: {user_path} ({len(content)} bytes)\n\nCurrent content:\n{content}")

        except Exception as e:
            logger.exception(f"storage_write error: {e}")
            return ctx.error("Write", str(e))

    @tool("storage_delete", "Delete a file from storage", {"path": str})
    async def storage_delete(args: dict[str, Any]) -> dict[str, Any]:
        user_path = args["path"]
        result = ctx.require_file("Delete", user_path)
        if isinstance(result, dict):
            return result
        path = result

        old_lines = len(ctx.read_file(path).splitlines())
        ctx.storage.delete(path)
        ctx.file_mtimes.pop(path, None)

        ctx.tool_start("Delete", user_path, {"path": user_path})
        ctx.tool_result(stats={"lines": old_lines})
        return ctx.success(f"Deleted: {user_path}")

    @tool("storage_list", "List files and directories in storage", {"path": str})
    async def storage_list(args: dict[str, Any]) -> dict[str, Any]:
        user_path = args.get("path", "")
        path = ctx.resolve_path(user_path)
        dirs, files = ctx.storage.listdir(path)

        ctx.tool_start("List", user_path or "/", {"path": user_path})
        ctx.tool_result(stats={"files": len(files), "dirs": len(dirs)})
        return ctx.success(json.dumps({"directories": dirs, "files": files}, indent=2))

    @tool("storage_exists", "Check if a file exists in storage", {"path": str})
    async def storage_exists(args: dict[str, Any]) -> dict[str, Any]:
        user_path = args["path"]
        path = ctx.resolve_path(user_path)
        exists = ctx.storage.exists(path)
        status = "exists" if exists else "not found"

        ctx.tool_start("Exists", user_path, {"path": user_path})
        ctx.tool_result(summary=status)
        return ctx.success(f"{user_path}: {status}")

    @tool("storage_move", "Move/rename a file in storage", {"source": str, "destination": str})
    async def storage_move(args: dict[str, Any]) -> dict[str, Any]:
        user_source, user_dest = args["source"], args["destination"]
        source_path = ctx.resolve_path(user_source)
        dest_path = ctx.resolve_path(user_dest)

        if not ctx.storage.exists(source_path):
            return ctx.error("Move", f"source not found: {user_source}")
        if ctx.storage.exists(dest_path):
            return ctx.error("Move", f"destination exists: {user_dest}")

        # Read, save to dest, delete source
        with ctx.storage.open(source_path, "rb") as f:
            content = f.read()
        ctx.storage.save(dest_path, ContentFile(content))
        ctx.storage.delete(source_path)
        ctx.file_mtimes.pop(source_path, None)
        ctx.file_mtimes[dest_path] = ctx.get_mtime(dest_path)

        ctx.tool_start("Move", f"{user_source} → {user_dest}", {"source": user_source, "destination": user_dest})
        ctx.tool_result(stats={"size_bytes": len(content)})
        return ctx.success(f"Moved: {user_source} → {user_dest}")

    @tool("storage_delete_folder", "Delete an empty folder from storage", {"path": str})
    async def storage_delete_folder(args: dict[str, Any]) -> dict[str, Any]:
        user_path = args["path"]
        path = ctx.resolve_path(user_path)

        try:
            dirs, files = ctx.storage.listdir(path)
        except FileNotFoundError:
            return ctx.error("DeleteFolder", f"not found: {user_path}")

        if files or dirs:
            return ctx.error("DeleteFolder", f"folder not empty: {user_path} ({len(files)} files, {len(dirs)} subdirs)")

        try:
            if hasattr(ctx.storage, "path"):
                os.rmdir(ctx.storage.path(path))
            # For S3/cloud storage, empty folders don't really exist

            ctx.tool_start("DeleteFolder", user_path, {"path": user_path})
            ctx.tool_result(summary="Deleted")
            return ctx.success(f"Deleted folder: {user_path}")
        except OSError as e:
            return ctx.error("DeleteFolder", str(e))

    @tool(
        "get_file_url",
        "Get the API URL for a project file. Use this when generating HTML/JS that needs to fetch project files. "
        "Returns both the standard URL (wrapped response) and raw URL (direct content).",
        {"path": str, "raw": bool},
    )
    async def get_file_url(args: dict[str, Any]) -> dict[str, Any]:
        """
        Get the full API URL for accessing a project file.

        Args:
            path: File path relative to project root (e.g., "data.json", "assets/image.png")
            raw: If True, return URL for raw content (no wrapper). Default: True for JSON/text files.

        Returns:
            JSON with url, raw_url, and path fields.
        """
        from django.urls import reverse

        user_path = args["path"]
        use_raw = args.get("raw", True)  # Default to raw for most use cases

        if not ctx.project_id:
            return ctx.error("get_file_url", "No project context available")

        # Build URLs using Django reverse
        # Note: reverse gives us relative URLs, which work for same-origin requests
        file_url = reverse("ainstein:project-file", kwargs={"pk": ctx.project_id, "file_path": user_path})
        raw_file_url = reverse("ainstein:project-raw-file", kwargs={"pk": ctx.project_id, "file_path": user_path})

        recommended_url = raw_file_url if use_raw else file_url

        ctx.tool_start("get_file_url", user_path, {"path": user_path, "raw": use_raw})
        ctx.tool_result(summary=recommended_url)

        result = {
            "path": user_path,
            "url": file_url,
            "raw_url": raw_file_url,
            "recommended": recommended_url,
        }
        return ctx.success(json.dumps(result, indent=2))

    @tool(
        "storage_edit",
        "Edit a file by replacing a specific string with new content. "
        "The old_string must match exactly (including whitespace/indentation). "
        "Use replace_all=true to replace all occurrences.",
        {"path": str, "old_string": str, "new_string": str, "replace_all": bool},
    )
    async def storage_edit(args: dict[str, Any]) -> dict[str, Any]:
        """
        Edit a file by replacing old_string with new_string.

        Args:
            path: File path relative to project root
            old_string: Exact string to find and replace
            new_string: Replacement string
            replace_all: If True, replace all occurrences. Default: False (replace first only)

        Returns:
            Success message with number of replacements made.
        """
        user_path = args["path"]
        old_string = args["old_string"]
        new_string = args["new_string"]
        replace_all = args.get("replace_all", False)

        result = ctx.require_file("storage_edit", user_path)
        if isinstance(result, dict):
            return result
        path = result

        # Check for external modification conflict
        current_mtime = ctx.get_mtime(path)
        last_known = ctx.file_mtimes.get(path)
        if last_known is not None and current_mtime != last_known:
            ctx.file_mtimes[path] = current_mtime
            return ctx.error("storage_edit", f"CONFLICT: {user_path} was modified externally. Read it again first.")

        content = ctx.read_file(path)

        # Check if old_string exists
        if old_string not in content:
            return ctx.error(
                "storage_edit", f"String not found in {user_path}. Make sure it matches exactly including whitespace."
            )

        # Perform replacement
        if replace_all:
            count = content.count(old_string)
            new_content = content.replace(old_string, new_string)
        else:
            count = 1
            new_content = content.replace(old_string, new_string, 1)

        # Write back
        ctx.write_file(path, new_content)
        ctx.file_mtimes[path] = ctx.get_mtime(path)

        ctx.tool_start("Edit", user_path, {"path": user_path, "replacements": count})
        ctx.tool_result(stats={"replacements": count, "size_bytes": len(new_content)})

        return ctx.success(f"Edited {user_path}: {count} replacement(s) made")

    @tool(
        "storage_grep",
        "Search for a pattern in files. Returns matching lines with file paths and line numbers. "
        "Supports regex patterns. Use glob to filter which files to search.",
        {"pattern": str, "path": str, "glob": str},
    )
    async def storage_grep(args: dict[str, Any]) -> dict[str, Any]:
        """
        Search for a pattern across files in storage.

        Args:
            pattern: Regex pattern to search for
            path: Directory to search in (default: project root)
            glob: File pattern to match (e.g., "*.py", "*.js"). Default: all files

        Returns:
            Matching lines with file:line_number:content format.
        """
        import fnmatch
        import re

        pattern = args["pattern"]
        search_path = args.get("path", "")
        file_glob = args.get("glob", "*")

        try:
            regex = re.compile(pattern, re.IGNORECASE)
        except re.error as e:
            return ctx.error("storage_grep", f"Invalid regex pattern: {e}")

        base_path = ctx.resolve_path(search_path)
        matches = []
        files_searched = 0
        max_matches = 100  # Limit results

        def search_dir(dir_path, rel_prefix=""):
            nonlocal files_searched
            try:
                dirs, files = ctx.storage.listdir(dir_path)
            except FileNotFoundError:
                return

            for filename in files:
                if len(matches) >= max_matches:
                    return

                if not fnmatch.fnmatch(filename, file_glob):
                    continue

                file_path = f"{dir_path}/{filename}" if dir_path else filename
                rel_path = f"{rel_prefix}/{filename}" if rel_prefix else filename

                try:
                    content = ctx.read_file(file_path)
                    files_searched += 1

                    for line_num, line in enumerate(content.splitlines(), 1):
                        if regex.search(line):
                            matches.append(f"{rel_path}:{line_num}: {line.strip()[:100]}")
                            if len(matches) >= max_matches:
                                return
                except Exception:
                    continue  # Skip binary/unreadable files

            for dirname in dirs:
                if len(matches) >= max_matches:
                    return
                subdir = f"{dir_path}/{dirname}" if dir_path else dirname
                sub_rel = f"{rel_prefix}/{dirname}" if rel_prefix else dirname
                search_dir(subdir, sub_rel)

        search_dir(base_path, search_path)

        ctx.tool_start("Grep", f"'{pattern}' in {search_path or '/'}", {"pattern": pattern, "glob": file_glob})
        ctx.tool_result(stats={"matches": len(matches), "files": files_searched})

        if not matches:
            return ctx.success(f"No matches found for '{pattern}' in {files_searched} files")

        result = "\n".join(matches)
        if len(matches) >= max_matches:
            result += f"\n... (limited to {max_matches} matches)"

        return ctx.success(result)

    return [
        storage_read,
        storage_write,
        storage_delete,
        storage_list,
        storage_exists,
        storage_move,
        storage_delete_folder,
        get_file_url,
        storage_edit,
        storage_grep,
    ]
