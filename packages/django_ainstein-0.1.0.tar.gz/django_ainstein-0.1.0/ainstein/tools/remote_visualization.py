"""
Data Visualization Tools (Phase 9.1).

Tools for generating charts and visualizations using the remote code execution sandbox.
Captures matplotlib/plotly output as images.
"""

import logging
import uuid
from typing import Any

from claude_agent_sdk import tool

from ainstein.tools.base import ToolContext


logger = logging.getLogger(__name__)


def create_visualization_tools(ctx: ToolContext) -> list:
    """Create data visualization tools."""

    @tool(
        "create_chart",
        """Generate a chart/visualization using matplotlib or plotly.

The code runs in Anthropic's remote sandbox with full data science libraries.
Charts are automatically saved as PNG images to the project storage.

Supported chart types:
- line, bar, scatter, pie, histogram, heatmap, box, violin
- Any matplotlib or plotly chart

The sandbox has: pandas, numpy, matplotlib, seaborn, plotly, scipy, sklearn

Example code for matplotlib:
```python
import matplotlib.pyplot as plt
import pandas as pd

df = pd.read_csv('data.csv')
plt.figure(figsize=(10, 6))
plt.bar(df['category'], df['value'])
plt.title('Sales by Category')
plt.savefig('output.png', dpi=150, bbox_inches='tight')
```

Example code for plotly:
```python
import plotly.express as px
import pandas as pd

df = pd.read_csv('data.csv')
fig = px.bar(df, x='category', y='value', title='Sales by Category')
fig.write_image('output.png')
```
""",
        {
            "code": str,
            "title": str,
            "chart_type": str,
            "output_filename": str,
            "data_files": list,
        },
    )
    async def create_chart(args: dict[str, Any]) -> dict[str, Any]:
        """Generate a chart using remote code execution."""
        code = args.get("code", "")
        title = args.get("title", "Chart")
        chart_type = args.get("chart_type", "custom")
        output_filename = args.get("output_filename", "chart.png")
        data_files = args.get("data_files", [])

        if not code.strip():
            return ctx.error("CreateChart", "No code provided")

        if ctx.is_cancelled():
            return ctx.success("Chart creation cancelled")

        ctx.tool_start("CreateChart", f"Generating {chart_type} chart: {title}", {"chart_type": chart_type})

        # Ensure output filename has a valid image extension
        valid_extensions = (".png", ".jpg", ".jpeg", ".svg", ".pdf")
        if not output_filename.lower().endswith(valid_extensions):
            output_filename += ".png"

        # Wrap code to ensure output is saved
        wrapped_code = f'''
import matplotlib
matplotlib.use('Agg')  # Non-interactive backend
import matplotlib.pyplot as plt

# User code
{code}

# Ensure figure is saved
if plt.get_fignums():
    plt.savefig('{output_filename}', dpi=150, bbox_inches='tight', facecolor='white')
    plt.close('all')
    print(f"Chart saved to {output_filename}")
'''

        # Use remote code execution
        try:
            import anthropic

            from ainstein.conf import get_anthropic_api_key, get_code_execution_model

            client = anthropic.Anthropic(api_key=get_anthropic_api_key())

            # Upload data files if provided
            content = []
            uploaded_files = []

            if data_files:
                for file_path in data_files:
                    full_path = ctx.resolve_path(file_path)
                    if ctx.storage.exists(full_path):
                        with ctx.storage.open(full_path, "rb") as f:
                            file_content = f.read()

                        import io

                        file_obj = io.BytesIO(file_content)
                        file_obj.name = file_path.split("/")[-1]

                        uploaded = client.beta.files.upload(file=file_obj)
                        uploaded_files.append(uploaded.id)
                        content.append({"type": "container_upload", "file_id": uploaded.id})

            # Add the code execution request
            file_list = "\n".join(f"- {f}" for f in data_files) if data_files else "None"
            content.insert(
                0,
                {
                    "type": "text",
                    "text": f"Execute this Python code to generate a chart. Available files:\n{file_list}\n\n```python\n{wrapped_code}\n```",
                },
            )

            # Execute
            response = client.beta.messages.create(
                model=get_code_execution_model(),
                max_tokens=4096,
                betas=["code-execution-2025-08-25", "files-api-2025-04-14"],
                tools=[{"type": "code_execution_20250825", "name": "code_execution"}],
                messages=[{"role": "user", "content": content}],
            )

            # Process response and extract file IDs and text
            result_text = ""
            file_ids = []

            for block in response.content:
                if hasattr(block, "type"):
                    if block.type == "text":
                        result_text += block.text + "\n"
                    # Handle bash code execution results (contains file_id for generated files)
                    elif block.type == "bash_code_execution_tool_result":
                        if hasattr(block, "content"):
                            content_item = block.content
                            if hasattr(content_item, "type") and content_item.type == "bash_code_execution_result":
                                if hasattr(content_item, "stdout") and content_item.stdout:
                                    result_text += f"Output: {content_item.stdout}\n"
                                if hasattr(content_item, "content"):
                                    for file_item in content_item.content:
                                        if hasattr(file_item, "file_id"):
                                            file_ids.append(file_item.file_id)
                    # Also check for server_tool_use results (alternative response format)
                    elif block.type == "server_tool_use":
                        pass  # Tool invocation, not result
                    elif hasattr(block, "content"):
                        # Generic content extraction
                        for item in getattr(block, "content", []) or []:
                            if hasattr(item, "file_id"):
                                file_ids.append(item.file_id)

            logger.info(f"Code execution response: file_ids={file_ids}, result_text={result_text[:200]}")

            # Download generated files using Files API
            image_bytes = None
            for file_id in file_ids:
                try:
                    file_metadata = client.beta.files.retrieve_metadata(file_id)
                    logger.info(f"Found file: {file_metadata.filename}")

                    # Check if this is an image file
                    if file_metadata.filename.endswith(('.png', '.jpg', '.jpeg', '.gif', '.svg', '.pdf')):
                        file_content = client.beta.files.download(file_id)
                        # Read the file content
                        chunks = []
                        for chunk in file_content.iter_bytes():
                            chunks.append(chunk)
                        image_bytes = b"".join(chunks)
                        output_filename = file_metadata.filename
                        break
                except Exception as e:
                    logger.warning(f"Failed to download file {file_id}: {e}")

            # Save image to storage if we got one
            if image_bytes:
                output_path = ctx.resolve_path(output_filename)

                if ctx.storage.exists(output_path):
                    ctx.storage.delete(output_path)

                from django.core.files.base import ContentFile

                ctx.storage.save(output_path, ContentFile(image_bytes))

                # Build the image URL for frontend display using reverse()
                from django.urls import reverse

                image_url = None
                if ctx.project_id:
                    image_url = (
                        reverse("aiproject-read-file", kwargs={"pk": ctx.project_id}) + f"?path={output_filename}"
                    )

                ctx.tool_result(
                    summary="Chart created",
                    stats={
                        "filename": output_filename,
                        "size": len(image_bytes),
                        "chart_type": chart_type,
                        "image_url": image_url,
                    },
                )

                return ctx.success(f"Chart saved to {output_filename} ({len(image_bytes):,} bytes)\n\n{result_text}")
            ctx.tool_result(summary="No image generated")
            return ctx.error("CreateChart", f"No image was generated. Output:\n{result_text}")

        except Exception as e:
            logger.exception("Chart creation failed")
            ctx.tool_result(summary="Error")
            return ctx.error("CreateChart", f"Error: {type(e).__name__}: {e}")

    @tool(
        "list_chart_types",
        "List supported chart types and example code snippets.",
        {},
    )
    async def list_chart_types(args: dict[str, Any]) -> dict[str, Any]:
        """List available chart types with examples."""
        chart_info = """# Supported Chart Types

## Matplotlib Charts

### Line Chart
```python
plt.plot(x, y)
plt.title('Line Chart')
```

### Bar Chart
```python
plt.bar(categories, values)
plt.title('Bar Chart')
```

### Scatter Plot
```python
plt.scatter(x, y, c=colors, s=sizes)
plt.title('Scatter Plot')
```

### Pie Chart
```python
plt.pie(sizes, labels=labels, autopct='%1.1f%%')
plt.title('Pie Chart')
```

### Histogram
```python
plt.hist(data, bins=30)
plt.title('Histogram')
```

### Heatmap (with seaborn)
```python
import seaborn as sns
sns.heatmap(correlation_matrix, annot=True)
```

## Plotly Charts (Interactive)

### Interactive Line
```python
import plotly.express as px
fig = px.line(df, x='date', y='value')
fig.write_image('output.png')
```

### Interactive Bar
```python
fig = px.bar(df, x='category', y='value', color='group')
fig.write_image('output.png')
```

### Sunburst
```python
fig = px.sunburst(df, path=['region', 'country'], values='sales')
fig.write_image('output.png')
```

## Data Science Visualizations

### Correlation Matrix
```python
import seaborn as sns
corr = df.corr()
sns.heatmap(corr, annot=True, cmap='coolwarm')
```

### Distribution Plot
```python
import seaborn as sns
sns.histplot(data=df, x='value', kde=True)
```

### Box Plot
```python
import seaborn as sns
sns.boxplot(data=df, x='category', y='value')
```

## Available Libraries
- matplotlib, seaborn, plotly
- pandas, numpy, scipy
- sklearn (for ML visualizations)
"""
        return ctx.success(chart_info)

    @tool(
        "quick_chart",
        """Generate a quick chart from a data file without writing code.

Automatically analyzes the data and creates an appropriate visualization.

Args:
    data_file: Path to CSV or JSON file
    chart_type: 'auto', 'line', 'bar', 'scatter', 'pie', 'histogram', 'heatmap'
    x_column: Column for x-axis (optional, auto-detected)
    y_column: Column for y-axis (optional, auto-detected)
    title: Chart title (optional)
""",
        {
            "data_file": str,
            "chart_type": str,
            "x_column": str,
            "y_column": str,
            "title": str,
        },
    )
    async def quick_chart(args: dict[str, Any]) -> dict[str, Any]:
        """Generate a quick chart from data file."""
        data_file = args.get("data_file", "")
        chart_type = args.get("chart_type", "auto")
        x_column = args.get("x_column", "")
        y_column = args.get("y_column", "")
        title = args.get("title", "")

        if not data_file:
            return ctx.error("QuickChart", "No data_file provided")

        # Check file exists
        full_path = ctx.resolve_path(data_file)
        if not ctx.storage.exists(full_path):
            return ctx.error("QuickChart", f"File not found: {data_file}")

        ctx.tool_start("QuickChart", f"Creating {chart_type} chart from {data_file}", {})

        # Generate output filename
        output_filename = f"chart_{uuid.uuid4().hex[:8]}.png"

        # Build auto-detection code
        code = f'''
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load data
df = pd.read_csv('{data_file.split("/")[-1]}') if '{data_file}'.endswith('.csv') else pd.read_json('{data_file.split("/")[-1]}')

print(f"Data shape: {{df.shape}}")
print(f"Columns: {{list(df.columns)}}")

# Determine columns
x_col = '{x_column}' if '{x_column}' else df.columns[0]
y_col = '{y_column}' if '{y_column}' else (df.select_dtypes(include=['number']).columns[0] if len(df.select_dtypes(include=['number']).columns) > 0 else df.columns[1])

chart_type = '{chart_type}'
title = '{title}' if '{title}' else f'{{y_col}} by {{x_col}}'

plt.figure(figsize=(12, 6))

if chart_type == 'auto':
    # Auto-detect best chart type
    if df[x_col].dtype == 'object' or df[x_col].nunique() < 20:
        chart_type = 'bar'
    elif 'date' in x_col.lower() or 'time' in x_col.lower():
        chart_type = 'line'
    else:
        chart_type = 'scatter'

if chart_type == 'line':
    plt.plot(df[x_col], df[y_col], marker='o', linewidth=2, markersize=4)
elif chart_type == 'bar':
    if df[x_col].nunique() > 20:
        df_plot = df.groupby(x_col)[y_col].sum().nlargest(20)
        plt.barh(df_plot.index, df_plot.values)
    else:
        plt.bar(df[x_col], df[y_col])
        plt.xticks(rotation=45, ha='right')
elif chart_type == 'scatter':
    plt.scatter(df[x_col], df[y_col], alpha=0.6)
elif chart_type == 'pie':
    plt.pie(df[y_col], labels=df[x_col], autopct='%1.1f%%')
elif chart_type == 'histogram':
    plt.hist(df[y_col], bins=30, edgecolor='black')
elif chart_type == 'heatmap':
    numeric_df = df.select_dtypes(include=['number'])
    sns.heatmap(numeric_df.corr(), annot=True, cmap='coolwarm', center=0)

plt.title(title, fontsize=14, fontweight='bold')
plt.xlabel(x_col)
plt.ylabel(y_col)
plt.tight_layout()
plt.savefig('{output_filename}', dpi=150, bbox_inches='tight', facecolor='white')
print(f"Chart saved: {output_filename}")
'''

        # Reuse create_chart with generated code
        return await create_chart(
            {
                "code": code,
                "title": title or f"Chart from {data_file}",
                "chart_type": chart_type,
                "output_filename": output_filename,
                "data_files": [data_file],
            }
        )

    return [create_chart, list_chart_types, quick_chart]
