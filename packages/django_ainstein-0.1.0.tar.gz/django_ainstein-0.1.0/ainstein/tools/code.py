"""
Code execution tools for Claude Agent.

Provides a sandboxed Python code execution tool that REQUIRES user approval
before execution. This is a potentially dangerous tool - always require
human-in-the-loop permission.
"""

import io
import logging
import traceback
from contextlib import redirect_stderr, redirect_stdout, suppress
from typing import Any

from claude_agent_sdk import tool

from ainstein.tools.base import ToolContext


logger = logging.getLogger(__name__)

# Tools that require explicit user approval before execution
TOOLS_REQUIRING_APPROVAL = [
    "execute_code",
]


def create_code_tools(ctx: ToolContext) -> list:
    """Create code execution tools."""

    @tool(
        "execute_code",
        "Execute Python code in a sandboxed environment. REQUIRES USER APPROVAL.",
        {"code": str, "description": str},
    )
    async def execute_code(args: dict[str, Any]) -> dict[str, Any]:
        """
        Execute Python code with safety restrictions.

        This tool is gated by PreToolUse hooks - the SDK will pause execution
        and wait for user approval before this tool runs.

        Args:
            code: Python code to execute
            description: Brief description of what the code does (for approval dialog)

        Returns:
            Output from code execution or error message
        """
        code = args.get("code", "")
        description = args.get("description", "Execute Python code")

        if not code.strip():
            return ctx.error("Execute", "No code provided")

        # Check cancellation before execution
        if ctx.is_cancelled():
            ctx.tool_start("Execute", "Cancelled", {"description": description})
            ctx.tool_result(summary="Cancelled")
            return ctx.success("Code execution cancelled by user")

        ctx.tool_start("Execute", description, {"code": code, "description": description})

        # Capture stdout/stderr
        stdout_capture = io.StringIO()
        stderr_capture = io.StringIO()

        # Restricted globals - no file system, network, or dangerous operations
        restricted_globals = {
            "__builtins__": {
                # Safe builtins only
                "print": print,
                "len": len,
                "range": range,
                "enumerate": enumerate,
                "zip": zip,
                "map": map,
                "filter": filter,
                "sorted": sorted,
                "reversed": reversed,
                "list": list,
                "dict": dict,
                "set": set,
                "tuple": tuple,
                "str": str,
                "int": int,
                "float": float,
                "bool": bool,
                "sum": sum,
                "min": min,
                "max": max,
                "abs": abs,
                "round": round,
                "isinstance": isinstance,
                "type": type,
                "hasattr": hasattr,
                "getattr": getattr,
                "setattr": setattr,
                "any": any,
                "all": all,
                "format": format,
                "repr": repr,
                "chr": chr,
                "ord": ord,
                "hex": hex,
                "bin": bin,
                "oct": oct,
                "pow": pow,
                "divmod": divmod,
                "Exception": Exception,
                "ValueError": ValueError,
                "TypeError": TypeError,
                "KeyError": KeyError,
                "IndexError": IndexError,
                "AttributeError": AttributeError,
                "RuntimeError": RuntimeError,
                "StopIteration": StopIteration,
                "True": True,
                "False": False,
                "None": None,
            }
        }

        # Pre-import safe modules
        import collections  # noqa: PLC0415
        import datetime  # noqa: PLC0415
        import functools  # noqa: PLC0415
        import itertools  # noqa: PLC0415
        import json  # noqa: PLC0415
        import math  # noqa: PLC0415
        import random  # noqa: PLC0415
        import re  # noqa: PLC0415
        import statistics  # noqa: PLC0415
        import string  # noqa: PLC0415

        # Safe modules that can be imported
        safe_modules = {
            "json": json,
            "math": math,
            "random": random,
            "re": re,
            "datetime": datetime,
            "collections": collections,
            "itertools": itertools,
            "functools": functools,
            "statistics": statistics,
            "string": string,
        }

        # Add pre-imported modules to globals
        restricted_globals.update(safe_modules)

        # Create safe __import__ that only allows approved modules
        def safe_import(name, globals=None, locals=None, fromlist=(), level=0):
            if name in safe_modules:
                return safe_modules[name]
            raise ImportError(
                f"Import of '{name}' is not allowed. Available modules: {', '.join(sorted(safe_modules.keys()))}"
            )

        restricted_globals["__builtins__"]["__import__"] = safe_import

        result_value = None
        error_msg = None

        try:
            with redirect_stdout(stdout_capture), redirect_stderr(stderr_capture):
                # Execute with timeout would be ideal, but for now just execute
                # Note: In production, add resource limits (memory, CPU, time)
                exec(code, restricted_globals)

                # Try to get the last expression value
                # This is a simplified approach - compile and eval last expression
                lines = code.strip().split("\n")
                if lines:
                    last_line = lines[-1].strip()
                    # If last line looks like an expression (not assignment/statement)
                    if (
                        last_line
                        and not any(
                            last_line.startswith(kw)
                            for kw in ["if ", "for ", "while ", "def ", "class ", "import ", "from ", "try:", "with "]
                        )
                        and "=" not in last_line.split("#")[0]
                    ):
                        with suppress(Exception):
                            result_value = eval(last_line, restricted_globals)

        except Exception as e:
            error_msg = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
            logger.warning(f"Code execution error: {error_msg}")

        stdout_output = stdout_capture.getvalue()
        stderr_output = stderr_capture.getvalue()

        # Build result
        output_parts = []

        if stdout_output:
            output_parts.append(f"Output:\n{stdout_output}")

        if stderr_output:
            output_parts.append(f"Stderr:\n{stderr_output}")

        if result_value is not None:
            output_parts.append(f"Result: {repr(result_value)}")

        if error_msg:
            output_parts.append(f"Error:\n{error_msg}")
            ctx.tool_result(summary="Error")
            return ctx.error("Execute", "\n\n".join(output_parts) if output_parts else error_msg)

        if not output_parts:
            output_parts.append("Code executed successfully (no output)")

        ctx.tool_result(summary="Done")
        return ctx.success("\n\n".join(output_parts))

    return [execute_code]
