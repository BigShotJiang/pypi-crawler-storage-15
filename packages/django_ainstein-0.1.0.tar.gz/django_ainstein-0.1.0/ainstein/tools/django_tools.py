"""
Django database tools for ORM operations.

Provides tools for listing models, querying data, running aggregations,
executing raw SQL, and exporting query results.
"""

import csv
import io
import json
import logging
import re
import time
import uuid
from typing import Any

from asgiref.sync import sync_to_async
from claude_agent_sdk import tool
from django.apps import apps
from django.core.serializers.json import DjangoJSONEncoder
from django.db import connection
from django.db.models import Avg, Count, Max, Min, Sum

from ainstein.events import Event, EventType, request_permission
from ainstein.model_registry import get_model_registry
from ainstein.tools.base import ToolContext
from ainstein.utils import fix_dict_arg, fix_list_arg, get_all_django_app_labels


logger = logging.getLogger(__name__)

# Keys that should never be allowed in filters (could be used for attacks)
DANGEROUS_FILTER_KEYS = {"delete", "update", "save", "create", "bulk_create", "bulk_update"}


def validate_filters(filters, context: str) -> tuple[bool, str]:
    """Validate filter dict for dangerous keys."""
    if not filters:
        return True, ""
    if not isinstance(filters, dict):
        return False, f"{context} must be a dict"
    for key in filters:
        key_lower = str(key).lower()
        if any(dangerous in key_lower for dangerous in DANGEROUS_FILTER_KEYS):
            return False, f"Dangerous key '{key}' not allowed"
    return True, ""


def get_model(app_label: str, model_name: str):
    """Get Django model by app_label and model_name."""
    try:
        return apps.get_model(app_label, model_name)
    except LookupError:
        return None


def list_available_models(filter_app: str = None, app_labels: list[str] = None) -> list[dict]:
    """
    List available Django models with their record counts.

    Args:
        filter_app: Optional app label to filter by
        app_labels: Optional list of allowed app labels

    Returns:
        List of dicts with app, model, table, count keys
    """
    registry = get_model_registry()
    cached_models = registry.list_models(filter_app if filter_app else None)

    if app_labels:
        cached_models = [m for m in cached_models if m.app_label in app_labels]

    models_info = []
    for model_info in cached_models:
        count = registry.get_model_count(model_info.app_label, model_info.model_name)
        models_info.append(
            {
                "app": model_info.app_label,
                "model": model_info.model_name,
                "table": model_info.table_name,
                "count": count or 0,
            }
        )
    return models_info


def serialize_queryset(qs, fields: list[str] = None, limit: int = 100, is_cancelled: callable = None) -> list[dict]:
    """Serialize a queryset to a list of dicts.

    Args:
        qs: Django QuerySet to serialize
        fields: Optional list of field names to include
        limit: Maximum number of rows to return
        is_cancelled: Optional callback to check if operation was cancelled.
                      Checked every 100 rows to allow early exit.
    """
    if fields:
        return list(qs.values(*fields)[:limit])
    results = []
    for i, obj in enumerate(qs[:limit]):
        # Check cancellation every 100 rows to allow early exit
        if is_cancelled and i > 0 and i % 100 == 0 and is_cancelled():
            logger.info(f"serialize_queryset cancelled at row {i}")
            break

        data = {}
        for field in obj._meta.get_fields():
            if hasattr(field, "attname"):
                value = getattr(obj, field.attname, None)
                try:
                    json.dumps(value, cls=DjangoJSONEncoder)
                    data[field.attname] = value
                except (TypeError, ValueError):
                    data[field.attname] = str(value)
        results.append(data)
    return results


def create_django_tools(ctx: ToolContext) -> list:
    """
    Create all Django database tools.

    Args:
        ctx: ToolContext with storage, emit, resolve_path, max_limit, etc.

    Returns:
        List of tool functions ready for MCP server registration.
    """
    # Get allowed app labels
    app_labels = get_all_django_app_labels()

    @tool("django_list_models", "List all available Django models", {"app_label": str})
    async def django_list_models(args: dict[str, Any]) -> dict[str, Any]:
        filter_app = args.get("app_label", "")

        models_info = await sync_to_async(
            lambda: list_available_models(filter_app, app_labels), thread_sensitive=True
        )()
        response_json = json.dumps(models_info, indent=2)

        ctx.tool_start("ListModels", filter_app or "all")
        ctx.tool_result(stats={"rows": len(models_info), "size_bytes": len(response_json)})
        ctx.emit(
            Event(EventType.DATA_PREVIEW, {"rows": [{"table": m["table"], "count": m["count"]} for m in models_info]})
        )

        return ctx.success(response_json)

    @tool("django_describe_model", "Get field information for a Django model", {"app_label": str, "model_name": str})
    async def django_describe_model(args: dict[str, Any]) -> dict[str, Any]:
        app_label, model_name = args["app_label"], args["model_name"]

        # Use cached model info from registry
        registry = get_model_registry()
        model_info = registry.describe_model(app_label, model_name)

        if not model_info:
            return ctx.error("DescribeModel", f"not found: {app_label}.{model_name}")

        # Convert cached field info to response format
        fields_info = []
        for field in model_info.fields:
            field_data = {"name": field.name, "type": field.field_type}
            if field.max_length:
                field_data["max_length"] = field.max_length
            if field.nullable is not None:
                field_data["nullable"] = field.nullable
            if field.related_to:
                field_data["related_to"] = field.related_to
            fields_info.append(field_data)

        result = {
            "app": app_label,
            "model": model_name,
            "table": model_info.table_name,
            "fields": fields_info,
        }
        response_json = json.dumps(result, indent=2)

        ctx.tool_start("DescribeModel", f"{app_label}.{model_name}")
        ctx.tool_result(stats={"fields": len(fields_info)})

        return ctx.success(response_json)

    @tool(
        "django_query",
        "Query a Django model with optional filters. Large queries require user approval.",
        {
            "app_label": str,
            "model_name": str,
            "filters": dict,
            "exclude": dict,
            "order_by": list,
            "fields": list,
            "limit": int,
        },
    )
    async def django_query(args: dict[str, Any]) -> dict[str, Any]:
        app_label, model_name = args["app_label"], args["model_name"]
        requested_limit = args.get("limit") or 100

        filters = fix_dict_arg(args.get("filters"))
        exclude = fix_dict_arg(args.get("exclude"))
        order_by = fix_list_arg(args.get("order_by"))
        fields = fix_list_arg(args.get("fields"))

        # Check if requested limit exceeds max - requires human approval
        if requested_limit > ctx.max_limit:
            permission_request_id = str(uuid.uuid4())
            ctx.tool_start("Query", f"{app_label}.{model_name}")
            ctx.emit(
                Event(
                    EventType.PERMISSION_REQUEST,
                    {
                        "request_id": permission_request_id,
                        "message": f"Query requests {requested_limit:,} rows (limit is {ctx.max_limit:,})",
                        "action": f"Execute large query on {app_label}.{model_name}",
                        "rows_requested": requested_limit,
                        "rows_limit": ctx.max_limit,
                    },
                )
            )

            approved = await sync_to_async(request_permission, thread_sensitive=False)(
                permission_request_id, timeout=300.0
            )
            if not approved:
                ctx.tool_result(summary="Query denied by user")
                return ctx.success("Query execution denied by user.")

            limit = requested_limit
        else:
            limit = min(requested_limit, ctx.max_limit)

        model = get_model(app_label, model_name)
        if not model:
            return ctx.error("Query", f"not found: {app_label}.{model_name}")

        for f, filter_ctx in [(filters, "filters"), (exclude, "exclude")]:
            if f:
                valid, err = validate_filters(f, filter_ctx)
                if not valid:
                    return ctx.error("Query", f"security: {err}")

        try:
            start_time = time.time()

            def _query():
                qs = model.objects.all()
                if filters:
                    qs = qs.filter(**filters)
                if exclude:
                    qs = qs.exclude(**exclude)
                if order_by:
                    qs = qs.order_by(*order_by)
                if fields:
                    qs = qs.values(*fields)

                sql = str(qs[:limit].query)
                total_count = qs.count()
                # Pass is_cancelled to allow early exit during serialization
                results = (
                    list(qs[:limit]) if fields else serialize_queryset(qs, None, limit, is_cancelled=ctx.is_cancelled)
                )
                return total_count, results, sql

            total_count, results, sql = await sync_to_async(_query, thread_sensitive=True)()
            execution_time_ms = int((time.time() - start_time) * 1000)

            response = {
                "total_count": total_count,
                "returned": len(results),
                "execution_time_ms": execution_time_ms,
                "results": results,
            }
            response_json = json.dumps(response, indent=2, cls=DjangoJSONEncoder)

            ctx.tool_start("Query", f"{app_label}.{model_name}")
            ctx.tool_result(
                stats={
                    "time_ms": execution_time_ms,
                    "size_bytes": len(response_json),
                    "rows": len(results),
                    "total_rows": total_count,
                }
            )
            ctx.emit(Event(EventType.SQL, {"sql": sql}))
            ctx.emit(Event(EventType.DATA_PREVIEW, {"rows": results}))

            return ctx.success(response_json)

        except Exception as e:
            return ctx.error("Query", str(e))

    @tool(
        "django_export_query",
        "Export query results directly to CSV or JSON file. Use this for large exports instead of django_query.",
        {
            "app_label": str,
            "model_name": str,
            "path": str,
            "format": str,  # "json" (default) or "csv"
            "filters": dict,
            "exclude": dict,
            "fields": list,
            "order_by": list,
            "limit": int,
        },
    )
    async def django_export_query(args: dict[str, Any]) -> dict[str, Any]:
        """Export query results directly to a file in storage (CSV or JSON)."""
        app_label, model_name = args["app_label"], args["model_name"]
        user_path = args["path"]
        export_format = (args.get("format") or "json").lower()
        filters = fix_dict_arg(args.get("filters"))
        exclude = fix_dict_arg(args.get("exclude"))
        fields = fix_list_arg(args.get("fields"))
        order_by = fix_list_arg(args.get("order_by"))
        limit = args.get("limit") or 10000

        if export_format not in ("csv", "json"):
            return ctx.error("Export", "format must be 'csv' or 'json'")

        # Add appropriate extension if not present
        if export_format == "csv" and not user_path.endswith(".csv"):
            user_path += ".csv"
        elif export_format == "json" and not user_path.endswith(".json"):
            user_path += ".json"

        model = get_model(app_label, model_name)
        if not model:
            return ctx.error("Export", f"not found: {app_label}.{model_name}")

        # Validate filters for security
        for f in [filters, exclude]:
            if f:
                valid, err = validate_filters(f, "filters")
                if not valid:
                    return ctx.error("Export", f"security: {err}")

        try:
            ctx.tool_start("Export", f"{app_label}.{model_name} → {user_path}")
            start_time = time.time()

            def _export():
                qs = model.objects.all()
                if filters:
                    qs = qs.filter(**filters)
                if exclude:
                    qs = qs.exclude(**exclude)
                if order_by:
                    qs = qs.order_by(*order_by)

                # Get field names
                if fields:
                    field_names = fields
                    qs = qs.values(*fields)
                else:
                    field_names = [f.name for f in model._meta.get_fields() if hasattr(f, "column")]

                total_count = qs.count()
                results = list(qs[:limit].values(*field_names)) if not fields else list(qs[:limit])
                return field_names, results, total_count

            field_names, results, total_count = await sync_to_async(_export, thread_sensitive=True)()
            execution_time_ms = int((time.time() - start_time) * 1000)

            # Check cancellation after query but before file generation
            if ctx.is_cancelled():
                logger.info(f"django_export_query cancelled after query: {user_path}")
                # Emit result so tool card shows "Cancelled" instead of "Running"
                ctx.tool_result(summary="Cancelled")
                return ctx.success("Export cancelled by user")

            # Generate file content
            if export_format == "csv":
                output = io.StringIO()
                writer = csv.DictWriter(output, fieldnames=field_names, extrasaction="ignore")
                writer.writeheader()
                writer.writerows(results)
                content = output.getvalue()
            else:
                content = json.dumps(results, indent=2, cls=DjangoJSONEncoder)

            # Save to storage using DRY helper
            ctx.write_file(ctx.resolve_path(user_path), content)

            ctx.tool_result(
                stats={
                    "time_ms": execution_time_ms,
                    "rows": len(results),
                    "total_rows": total_count,
                    "cols": len(field_names),
                    "size_bytes": len(content),
                }
            )

            return ctx.success(
                f"Exported {len(results):,} rows to {user_path} ({len(content):,} bytes)\n"
                f"Columns: {', '.join(field_names)}\n"
                f"Total available: {total_count:,} rows"
            )

        except Exception as e:
            return ctx.error("Export", str(e))

    @tool(
        "django_aggregate",
        "Run aggregate functions on a Django model",
        {
            "app_label": str,
            "model_name": str,
            "aggregates": dict,
            "filters": dict,
            "group_by": list,
        },
    )
    async def django_aggregate(args: dict[str, Any]) -> dict[str, Any]:
        app_label, model_name = args["app_label"], args["model_name"]
        aggregates = fix_dict_arg(args.get("aggregates"))
        filters = fix_dict_arg(args.get("filters"))
        group_by = fix_list_arg(args.get("group_by"))

        model = get_model(app_label, model_name)
        if not model:
            return ctx.error("Aggregate", f"not found: {app_label}.{model_name}")

        if filters:
            valid, err = validate_filters(filters, "filters")
            if not valid:
                return ctx.error("Aggregate", f"security: {err}")

        if isinstance(aggregates, str):
            aggregates = {"total": {"func": aggregates, "field": "id"}}
        if not aggregates:
            aggregates = {"total": {"func": "count", "field": "id"}}

        try:

            def _aggregate():
                qs = model.objects.all()
                if filters:
                    qs = qs.filter(**filters)

                agg_funcs = {"count": Count, "sum": Sum, "avg": Avg, "max": Max, "min": Min}
                agg_expressions = {}

                for name, spec in aggregates.items():
                    if isinstance(spec, str):
                        agg_expressions[name] = Count(spec)
                    elif isinstance(spec, dict):
                        func_name = spec.get("func", "count").lower()
                        field = spec.get("field", "id")
                        if func_name in agg_funcs:
                            agg_expressions[name] = agg_funcs[func_name](field)

                if group_by:
                    agg_qs = qs.values(*group_by).annotate(**agg_expressions)
                    return list(agg_qs), str(agg_qs.query)

                agg_parts = []
                for name, spec in aggregates.items():
                    if isinstance(spec, str):
                        agg_parts.append(f"COUNT({spec}) AS {name}")
                    elif isinstance(spec, dict):
                        func = spec.get("func", "count").upper()
                        field = spec.get("field", "id")
                        agg_parts.append(f"{func}({field}) AS {name}")
                sql = f"SELECT {', '.join(agg_parts)} FROM {model._meta.db_table}"
                return qs.aggregate(**agg_expressions), sql

            results, sql = await sync_to_async(_aggregate, thread_sensitive=True)()
            response_json = json.dumps(results, indent=2, cls=DjangoJSONEncoder)

            ctx.tool_start("Aggregate", f"{app_label}.{model_name}")
            ctx.tool_result(stats={"rows": len(aggregates), "size_bytes": len(response_json)})
            ctx.emit(Event(EventType.SQL, {"sql": sql}))
            preview_rows = [results] if isinstance(results, dict) else results
            ctx.emit(Event(EventType.DATA_PREVIEW, {"rows": preview_rows}))

            return ctx.success(response_json)

        except Exception as e:
            return ctx.error("Aggregate", str(e))

    @tool(
        "django_raw_sql",
        "Execute a raw SQL query (SELECT only). Large queries require user approval.",
        {"sql": str, "params": list},
    )
    async def django_raw_sql(args: dict[str, Any]) -> dict[str, Any]:
        sql = args["sql"].strip()
        params = fix_list_arg(args.get("params"))
        sql_upper = sql.upper()

        # Extract LIMIT from SQL if present
        limit_match = re.search(r"\bLIMIT\s+(\d+)", sql_upper)
        requested_limit = int(limit_match.group(1)) if limit_match else None

        # Check if requested limit exceeds max - requires human approval
        if requested_limit and requested_limit > ctx.max_limit:
            permission_request_id = str(uuid.uuid4())
            ctx.tool_start("RawSQL", "")
            ctx.emit(Event(EventType.SQL, {"sql": sql}))
            ctx.emit(
                Event(
                    EventType.PERMISSION_REQUEST,
                    {
                        "request_id": permission_request_id,
                        "message": f"Query requests {requested_limit:,} rows (limit is {ctx.max_limit:,})",
                        "action": "Execute large SQL query",
                        "rows_requested": requested_limit,
                        "rows_limit": ctx.max_limit,
                    },
                )
            )

            approved = await sync_to_async(request_permission, thread_sensitive=False)(
                permission_request_id, timeout=300.0
            )
            if not approved:
                ctx.tool_result(summary="Query denied by user")
                return ctx.success("Query execution denied by user.")

            effective_limit = requested_limit
        else:
            effective_limit = min(requested_limit, ctx.max_limit) if requested_limit else ctx.max_limit

        if not sql_upper.startswith("SELECT"):
            ctx.emit(Event(EventType.SQL, {"sql": sql}))
            return ctx.error("RawSQL", "only SELECT allowed")

        dangerous_keywords = [
            "INSERT",
            "UPDATE",
            "DELETE",
            "DROP",
            "ALTER",
            "CREATE",
            "TRUNCATE",
            "EXEC",
            "EXECUTE",
            "GRANT",
            "REVOKE",
            "COMMIT",
            "ROLLBACK",
        ]
        for keyword in dangerous_keywords:
            if re.search(rf"\b{keyword}\b", sql_upper):
                ctx.emit(Event(EventType.SQL, {"sql": sql}))
                return ctx.error("RawSQL", f"dangerous keyword '{keyword}'")

        if ";" in sql and sql_upper.split(";")[1].strip():
            ctx.emit(Event(EventType.SQL, {"sql": sql}))
            return ctx.error("RawSQL", "multiple statements not allowed")

        try:
            start_time = time.time()

            def _raw_sql():
                with connection.cursor() as cursor:
                    cursor.execute(sql, params)
                    columns = [col[0] for col in cursor.description]
                    all_rows = cursor.fetchall()
                    results = [dict(zip(columns, row, strict=False)) for row in all_rows[:effective_limit]]
                return columns, results, len(all_rows)

            columns, results, total_rows = await sync_to_async(_raw_sql, thread_sensitive=True)()
            execution_time_ms = int((time.time() - start_time) * 1000)

            response = {
                "columns": columns,
                "row_count": len(results),
                "total_rows": total_rows,
                "execution_time_ms": execution_time_ms,
                "truncated": total_rows > len(results),
                "results": results,
            }
            response_json = json.dumps(response, indent=2, cls=DjangoJSONEncoder)

            ctx.tool_start("RawSQL", "")
            ctx.tool_result(
                stats={
                    "time_ms": execution_time_ms,
                    "cols": len(columns),
                    "rows": len(results),
                    "total_rows": total_rows,
                }
            )
            ctx.emit(Event(EventType.SQL, {"sql": sql}))
            ctx.emit(Event(EventType.DATA_PREVIEW, {"rows": results}))

            return ctx.success(response_json)

        except Exception as e:
            return ctx.error("RawSQL", str(e))

    return [
        django_list_models,
        django_describe_model,
        django_query,
        django_export_query,
        django_aggregate,
        django_raw_sql,
    ]
