"""
Tool base classes and utilities.

This module provides:
- ToolContext: Context object passed to all tools with storage, emit, etc.
- Helper functions for common tool patterns (DRY)
"""

import json
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from claude_agent_sdk import tool
from django.core.files.base import ContentFile

from ainstein.events import Event, EventType


class CancelledError(Exception):
    """Raised when a tool operation is cancelled by user."""

    pass


@dataclass
class ToolContext:
    """
    Context object passed to tool factory functions.

    Provides access to:
    - service: The AinsteinService instance (for emit())
    - storage: Django file storage backend
    - project_folder: Base path for project files
    - project_id: Database ID of the project (for building URLs)
    - max_limit: Maximum query limit from settings
    - file_mtimes: Dict tracking file modification times for conflict detection
    - is_cancelled: Callback to check if stream was cancelled by user
    - user: The Django User instance making the request
    - project: The AiProject instance (if any)
    - conversation: The AiConversation instance (if any)

    Tools should access user/project/conversation directly from ctx, not via ctx.service.
    """

    service: Any  # AinsteinService - avoid circular import
    storage: Any  # Django Storage
    project_folder: str
    max_limit: int
    file_mtimes: dict[str, float]
    project_id: int | None = None  # Database ID for building URLs
    is_cancelled: Callable[[], bool] = lambda: False  # Default: never cancelled
    user: Any = None  # Django User instance
    project: Any = None  # AiProject instance
    conversation: Any = None  # AiConversation instance

    def check_cancelled(self) -> None:
        """Raise CancelledError if stream was cancelled. Tools should call this before expensive ops."""
        if self.is_cancelled():
            raise CancelledError("Operation cancelled by user")

    def emit(self, event: Any) -> None:
        """Emit an event through the service."""
        self.service.emit(event)

    def resolve_path(self, path: str) -> str:
        """Resolve path to be within project folder."""
        if not self.project_folder:
            return path
        path = path.lstrip("/")
        if ".." in path:
            raise ValueError("Path traversal not allowed")
        return f"{self.project_folder}/{path}"

    def get_mtime(self, path: str) -> float | None:
        """Get file modification time, or None if file doesn't exist."""
        if self.storage.exists(path):
            return self.storage.get_modified_time(path).timestamp()
        return None

    # =========================================================================
    # DRY Helpers - Common tool response patterns
    # =========================================================================

    def error(self, tool_name: str, message: str) -> dict[str, Any]:
        """Emit error event and return error response."""
        self.emit(Event(EventType.TOOL_ERROR, {"tool": tool_name, "error": message}))
        return {"content": [{"type": "text", "text": f"Error: {message}"}], "is_error": True}

    def success(self, text: str) -> dict[str, Any]:
        """Return a success response."""
        return {"content": [{"type": "text", "text": text}]}

    def tool_start(self, tool_name: str, summary: str, args: dict = None) -> None:
        """Emit tool start event."""
        self.emit(
            Event(
                EventType.TOOL_START,
                {
                    "tool": tool_name,
                    "args_summary": summary,
                    "args": args or {},
                },
            )
        )

    def tool_result(self, stats: dict = None, summary: str = None) -> None:
        """Emit tool result event."""
        data = {}
        if stats:
            data["stats"] = stats
        if summary:
            data["summary"] = summary
        self.emit(Event(EventType.TOOL_RESULT, data))

    def require_file(self, tool_name: str, user_path: str) -> str | dict:
        """
        Check file exists and return resolved path, or error response.

        Usage:
            result = ctx.require_file("Read", user_path)
            if isinstance(result, dict):
                return result  # Error response
            path = result  # Resolved path
        """
        path = self.resolve_path(user_path)
        if not self.storage.exists(path):
            return self.error(tool_name, f"not found: {user_path}")
        return path

    def read_file(self, path: str) -> str:
        """Read file content as UTF-8 string."""
        with self.storage.open(path, "rb") as f:
            return f.read().decode("utf-8", errors="replace")

    def write_file(self, path: str, content: str | bytes) -> None:
        """Write content to file (overwrites if exists)."""
        if self.storage.exists(path):
            self.storage.delete(path)
        if isinstance(content, str):
            content = content.encode("utf-8")
        self.storage.save(path, ContentFile(content))

    def read_json(self, path: str) -> Any:
        """Read and parse JSON file."""
        return json.loads(self.read_file(path))

    def write_json(self, path: str, data: Any) -> None:
        """Write data as formatted JSON."""
        self.write_file(path, json.dumps(data, indent=2))


def register_tool(name: str, description: str, params: dict) -> Callable:
    """
    Decorator that wraps the SDK's @tool and stores the tool name.

    Usage:
        @register_tool("my_tool", "Description", {"param": str})
        async def my_tool(ctx: ToolContext, args: dict) -> dict:
            ...

    The wrapped function will have a `_tool_name` attribute for later retrieval.
    """

    def decorator(func: Callable) -> Callable:
        wrapped = tool(name, description, params)(func)
        wrapped._tool_name = name
        return wrapped

    return decorator


# =========================================================================
# BlockNote helpers (for .page files)
# =========================================================================

DEFAULT_BLOCK_PROPS = {"textColor": "default", "backgroundColor": "default", "textAlignment": "left"}


def make_block(block_id: str, block_type: str, text: str, extra_props: dict = None) -> dict:
    """Create a BlockNote block with standard structure."""
    props = DEFAULT_BLOCK_PROPS.copy()
    if extra_props:
        props.update(extra_props)
    return {
        "id": block_id,
        "type": block_type,
        "props": props,
        "content": [{"type": "text", "text": text, "styles": {}}] if text else [],
        "children": [],
    }
