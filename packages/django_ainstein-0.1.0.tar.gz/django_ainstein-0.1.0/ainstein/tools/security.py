"""
Security Enhancement Tools (Phase 9.6).

Tools for audit logging, rate limiting, cost tracking, and sensitive data detection.
"""

import logging
import re
import time
from decimal import Decimal
from typing import Any

from claude_agent_sdk import tool

from ainstein.tools.base import ToolContext


logger = logging.getLogger(__name__)

# Patterns for sensitive data detection
SENSITIVE_PATTERNS = [
    (r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b", "email"),
    (r"\b\d{3}[-.]?\d{3}[-.]?\d{4}\b", "phone"),
    (r"\b\d{3}[-]?\d{2}[-]?\d{4}\b", "ssn"),
    (r"\b(?:\d{4}[-\s]?){3}\d{4}\b", "credit_card"),
    (r"\b(?:sk-|pk_|rk_)[a-zA-Z0-9]{20,}\b", "api_key"),
    (r"\bpassword\s*[=:]\s*['\"][^'\"]+['\"]", "password"),
    (r"\b(?:bearer|token)\s+[a-zA-Z0-9._-]+\b", "auth_token"),
    (r"\b(?:aws_access_key_id|aws_secret_access_key)\s*[=:]\s*['\"]?[A-Za-z0-9/+=]+", "aws_key"),
]


def detect_sensitive_data(text: str) -> list[dict]:
    """Detect sensitive data patterns in text."""
    findings = []
    for pattern, data_type in SENSITIVE_PATTERNS:
        matches = re.findall(pattern, text, re.IGNORECASE)
        if matches:
            findings.append(
                {
                    "type": data_type,
                    "count": len(matches),
                    "sample": matches[0][:10] + "..." if len(matches[0]) > 10 else matches[0],
                }
            )
    return findings


def create_security_tools(ctx: ToolContext) -> list:
    """Create security enhancement tools."""

    @tool(
        "audit_log_query",
        """Query the audit log for tool executions and actions.

Args:
    action: Filter by action type (tool_call, file_read, file_write, etc.)
    user_id: Filter by user ID
    days: Number of days to look back (default: 7)
    limit: Max results (default: 100)
    include_errors: Include failed actions
""",
        {
            "action": str,
            "user_id": int,
            "days": int,
            "limit": int,
            "include_errors": bool,
        },
    )
    async def audit_log_query(args: dict[str, Any]) -> dict[str, Any]:
        """Query audit logs."""
        from datetime import timedelta

        from django.utils import timezone

        from ainstein.models import AiAuditLog

        action = args.get("action", "")
        user_id = args.get("user_id")
        days = args.get("days", 7)
        limit = args.get("limit", 100)
        include_errors = args.get("include_errors", True)

        ctx.tool_start("AuditLogQuery", "Querying audit logs", {"action": action, "days": days})

        try:
            # Build query
            since = timezone.now() - timedelta(days=days)
            logs = AiAuditLog.objects.filter(timestamp__gte=since)

            if action:
                logs = logs.filter(action=action)

            if user_id:
                logs = logs.filter(user_id=user_id)

            if not include_errors:
                logs = logs.filter(success=True)

            # Get project filter
            project = ctx.project
            if project:
                logs = logs.filter(project=project)

            logs = logs.order_by("-timestamp")[:limit]

            ctx.tool_result(summary=f"{logs.count()} entries")

            if not logs.exists():
                return ctx.success("No audit log entries found.")

            result = "# Audit Log\n\n"
            for log in logs:
                status = "✓" if log.success else "✗"
                result += f"## {status} {log.action} - {log.timestamp.strftime('%Y-%m-%d %H:%M:%S')}\n"
                result += f"- Tool: {log.tool_name or 'N/A'}\n"
                result += f"- User: {log.user.username if log.user else 'N/A'}\n"
                result += f"- Duration: {log.duration_ms}ms\n"
                if log.description:
                    result += f"- Description: {log.description[:100]}\n"
                if not log.success and log.error_message:
                    result += f"- Error: {log.error_message[:100]}\n"
                if log.contains_sensitive_data:
                    result += "- ⚠️ Contains sensitive data\n"
                result += "\n"

            return ctx.success(result)

        except Exception as e:
            logger.exception("Audit log query failed")
            ctx.tool_result(summary="Error")
            return ctx.error("AuditLogQuery", f"Error: {e}")

    @tool(
        "check_rate_limit",
        """Check current rate limit status for the user.

Returns:
- Requests this minute
- Requests this hour
- Tokens used this hour
- Remaining quota
""",
        {},
    )
    async def check_rate_limit(args: dict[str, Any]) -> dict[str, Any]:
        """Check rate limit status."""
        from ainstein.conf import get_settings
        from ainstein.models import AiRateLimitTracker

        ctx.tool_start("CheckRateLimit", "Checking rate limits", {})

        try:
            user = ctx.user
            settings = get_settings()

            tracker = AiRateLimitTracker.get_or_create_for_user(user)

            max_per_minute = getattr(settings, "RATE_LIMIT_PER_MINUTE", 30)
            max_per_hour = getattr(settings, "RATE_LIMIT_PER_HOUR", 500)
            max_tokens = getattr(settings, "RATE_LIMIT_TOKENS_PER_HOUR", 100000)

            result = f"""# Rate Limit Status

## Per Minute
- Used: {tracker.requests_this_minute}/{max_per_minute}
- Remaining: {max_per_minute - tracker.requests_this_minute}

## Per Hour
- Requests: {tracker.request_count}/{max_per_hour}
- Tokens: {tracker.token_count:,}/{max_tokens:,}

## Remaining
- Requests: {max_per_hour - tracker.request_count}
- Tokens: {max_tokens - tracker.token_count:,}
"""

            ctx.tool_result(summary="OK")
            return ctx.success(result)

        except Exception as e:
            logger.exception("Rate limit check failed")
            ctx.tool_result(summary="Error")
            return ctx.error("CheckRateLimit", f"Error: {e}")

    @tool(
        "check_cost_limit",
        """Check cost limit status for the current project.

Returns:
- Daily usage and limit
- Monthly usage and limit
- Total usage
- Alert thresholds
""",
        {},
    )
    async def check_cost_limit(args: dict[str, Any]) -> dict[str, Any]:
        """Check cost limit status."""
        from ainstein.models import AiCostLimit

        ctx.tool_start("CheckCostLimit", "Checking cost limits", {})

        try:
            project = ctx.project

            if not project:
                return ctx.error("CheckCostLimit", "No project selected")

            cost_limit = AiCostLimit.get_or_create_for_project(project)

            daily_pct = (cost_limit.daily_usage / cost_limit.daily_limit * 100) if cost_limit.daily_limit else 0
            monthly_pct = (cost_limit.monthly_usage / cost_limit.monthly_limit * 100) if cost_limit.monthly_limit else 0

            alert_pct = float(cost_limit.alert_threshold * 100)

            result = f"""# Cost Limit Status - {project.name}

## Daily
- Used: ${cost_limit.daily_usage:.4f} / ${cost_limit.daily_limit:.2f}
- Percentage: {daily_pct:.1f}%
- Remaining: ${cost_limit.daily_limit - cost_limit.daily_usage:.4f}
{"- ⚠️ ALERT: Approaching daily limit" if daily_pct >= alert_pct else ""}

## Monthly
- Used: ${cost_limit.monthly_usage:.4f} / ${cost_limit.monthly_limit:.2f}
- Percentage: {monthly_pct:.1f}%
- Remaining: ${cost_limit.monthly_limit - cost_limit.monthly_usage:.4f}
{"- ⚠️ ALERT: Approaching monthly limit" if monthly_pct >= alert_pct else ""}

## Total All Time
- ${cost_limit.total_usage:.4f}

## Settings
- Alert threshold: {alert_pct:.0f}%
"""

            ctx.tool_result(summary="OK")
            return ctx.success(result)

        except Exception as e:
            logger.exception("Cost limit check failed")
            ctx.tool_result(summary="Error")
            return ctx.error("CheckCostLimit", f"Error: {e}")

    @tool(
        "set_cost_limit",
        """Set cost limits for the current project.

Args:
    daily_limit: Daily cost limit in USD
    monthly_limit: Monthly cost limit in USD
    alert_threshold: Alert when usage exceeds this percentage (0.0-1.0)
""",
        {
            "daily_limit": float,
            "monthly_limit": float,
            "alert_threshold": float,
        },
    )
    async def set_cost_limit(args: dict[str, Any]) -> dict[str, Any]:
        """Set cost limits."""
        from ainstein.models import AiCostLimit

        daily_limit = args.get("daily_limit")
        monthly_limit = args.get("monthly_limit")
        alert_threshold = args.get("alert_threshold")

        ctx.tool_start("SetCostLimit", "Setting cost limits", {})

        try:
            project = ctx.project

            if not project:
                return ctx.error("SetCostLimit", "No project selected")

            cost_limit = AiCostLimit.get_or_create_for_project(project)

            updates = []
            if daily_limit is not None:
                cost_limit.daily_limit = Decimal(str(daily_limit))
                updates.append(f"Daily limit: ${daily_limit:.2f}")

            if monthly_limit is not None:
                cost_limit.monthly_limit = Decimal(str(monthly_limit))
                updates.append(f"Monthly limit: ${monthly_limit:.2f}")

            if alert_threshold is not None:
                if not 0 <= alert_threshold <= 1:
                    return ctx.error("SetCostLimit", "alert_threshold must be between 0 and 1")
                cost_limit.alert_threshold = Decimal(str(alert_threshold))
                updates.append(f"Alert threshold: {alert_threshold * 100:.0f}%")

            cost_limit.save()

            ctx.tool_result(summary="Updated")
            return ctx.success("Cost limits updated:\n- " + "\n- ".join(updates))

        except Exception as e:
            logger.exception("Set cost limit failed")
            ctx.tool_result(summary="Error")
            return ctx.error("SetCostLimit", f"Error: {e}")

    @tool(
        "scan_sensitive_data",
        """Scan a file for sensitive data patterns.

Detects:
- Email addresses
- Phone numbers
- SSN patterns
- Credit card numbers
- API keys
- Passwords in code
- Auth tokens

Args:
    file_path: Path to file to scan
    redact: If true, create a redacted copy
""",
        {
            "file_path": str,
            "redact": bool,
        },
    )
    async def scan_sensitive_data(args: dict[str, Any]) -> dict[str, Any]:
        """Scan file for sensitive data."""
        file_path = args.get("file_path", "")
        redact = args.get("redact", False)

        if not file_path:
            return ctx.error("ScanSensitiveData", "file_path is required")

        ctx.tool_start("ScanSensitiveData", f"Scanning {file_path}", {})

        try:
            full_path = ctx.resolve_path(file_path)
            if not ctx.storage.exists(full_path):
                return ctx.error("ScanSensitiveData", f"File not found: {file_path}")

            content = ctx.read_file(full_path)
            findings = detect_sensitive_data(content)

            ctx.tool_result(
                summary=f"{len(findings)} types found" if findings else "Clean",
                stats={"findings": len(findings)},
            )

            if not findings:
                return ctx.success(f"No sensitive data detected in {file_path}")

            result = f"# Sensitive Data Scan: {file_path}\n\n"
            result += f"⚠️ Found {len(findings)} types of sensitive data:\n\n"

            for finding in findings:
                result += f"- **{finding['type']}**: {finding['count']} occurrence(s)\n"
                result += f"  Sample: `{finding['sample']}`\n"

            if redact:
                # Create redacted copy
                redacted = content
                for pattern, data_type in SENSITIVE_PATTERNS:
                    redacted = re.sub(pattern, f"[REDACTED_{data_type.upper()}]", redacted, flags=re.IGNORECASE)

                redacted_path = file_path.rsplit(".", 1)
                if len(redacted_path) > 1:
                    redacted_file = f"{redacted_path[0]}_redacted.{redacted_path[1]}"
                else:
                    redacted_file = f"{file_path}_redacted"

                ctx.write_file(ctx.resolve_path(redacted_file), redacted)
                result += f"\n✓ Redacted copy saved to: {redacted_file}"

            return ctx.success(result)

        except Exception as e:
            logger.exception("Sensitive data scan failed")
            ctx.tool_result(summary="Error")
            return ctx.error("ScanSensitiveData", f"Error: {e}")

    @tool(
        "security_report",
        """Generate a security report for the project.

Includes:
- Recent audit log summary
- Rate limit usage
- Cost usage
- Sensitive data warnings
- Permission grants/denies
""",
        {
            "days": int,
        },
    )
    async def security_report(args: dict[str, Any]) -> dict[str, Any]:
        """Generate security report."""
        from datetime import timedelta

        from django.db.models import Count
        from django.utils import timezone

        from ainstein.models import AiAuditLog, AiCostLimit, AiRateLimitTracker

        days = args.get("days", 7)

        ctx.tool_start("SecurityReport", f"Generating {days}-day report", {})

        try:
            user = ctx.user
            project = ctx.project
            since = timezone.now() - timedelta(days=days)

            result = "# Security Report\n\n"
            result += f"Period: Last {days} days\n"
            result += f"Generated: {timezone.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"

            # Audit log summary
            if project:
                logs = AiAuditLog.objects.filter(project=project, timestamp__gte=since)

                action_counts = logs.values("action").annotate(count=Count("id")).order_by("-count")

                result += "## Activity Summary\n\n"
                total = logs.count()
                errors = logs.filter(success=False).count()
                sensitive = logs.filter(contains_sensitive_data=True).count()

                result += f"- Total actions: {total}\n"
                result += f"- Errors: {errors}\n"
                result += f"- Sensitive data flags: {sensitive}\n\n"

                if action_counts:
                    result += "### By Action Type\n"
                    for ac in action_counts[:10]:
                        result += f"- {ac['action']}: {ac['count']}\n"
                    result += "\n"

            # Rate limit status
            tracker = AiRateLimitTracker.get_or_create_for_user(user)
            result += "## Rate Limit Usage\n\n"
            result += f"- Requests this hour: {tracker.request_count}\n"
            result += f"- Tokens this hour: {tracker.token_count:,}\n\n"

            # Cost status
            if project:
                cost_limit = AiCostLimit.get_or_create_for_project(project)
                result += "## Cost Usage\n\n"
                result += f"- Daily: ${cost_limit.daily_usage:.4f} / ${cost_limit.daily_limit:.2f}\n"
                result += f"- Monthly: ${cost_limit.monthly_usage:.4f} / ${cost_limit.monthly_limit:.2f}\n"
                result += f"- Total: ${cost_limit.total_usage:.4f}\n\n"

            # Permission summary
            if project:
                grants = logs.filter(action="permission_grant").count()
                denies = logs.filter(action="permission_deny").count()

                result += "## Permission Decisions\n\n"
                result += f"- Grants: {grants}\n"
                result += f"- Denies: {denies}\n\n"

            # Recommendations
            result += "## Recommendations\n\n"

            if errors > total * 0.1:
                result += "- ⚠️ High error rate detected. Review failed operations.\n"

            if sensitive > 0:
                result += "- ⚠️ Sensitive data detected in operations. Review audit logs.\n"

            if project:
                daily_pct = float(cost_limit.daily_usage / cost_limit.daily_limit * 100)
                if daily_pct > 80:
                    result += "- ⚠️ Approaching daily cost limit.\n"

            if not result.endswith("Recommendations\n\n"):
                pass  # Has recommendations
            else:
                result += "- ✓ No issues detected.\n"

            ctx.tool_result(summary="Generated")
            return ctx.success(result)

        except Exception as e:
            logger.exception("Security report failed")
            ctx.tool_result(summary="Error")
            return ctx.error("SecurityReport", f"Error: {e}")

    return [
        audit_log_query,
        check_rate_limit,
        check_cost_limit,
        set_cost_limit,
        scan_sensitive_data,
        security_report,
    ]


# =============================================================================
# Audit Logging Decorator
# =============================================================================


def audit_tool_call(tool_name: str):
    """Decorator to automatically log tool calls to audit log."""

    def decorator(func):
        async def wrapper(args: dict[str, Any], ctx: ToolContext) -> dict[str, Any]:
            from ainstein.models import AiAuditLog

            start_time = time.time()

            try:
                result = await func(args)
                duration_ms = int((time.time() - start_time) * 1000)

                # Check for sensitive data in args
                args_str = str(args)
                findings = detect_sensitive_data(args_str)

                AiAuditLog.log(
                    action="tool_call",
                    user=ctx.user if hasattr(ctx, "service") else None,
                    project=ctx.project if hasattr(ctx, "service") else None,
                    tool_name=tool_name,
                    request_data=args,
                    success=not result.get("is_error", False),
                    duration_ms=duration_ms,
                    contains_sensitive_data=bool(findings),
                )

                return result

            except Exception as e:
                duration_ms = int((time.time() - start_time) * 1000)

                AiAuditLog.log(
                    action="tool_call",
                    user=ctx.user if hasattr(ctx, "service") else None,
                    project=ctx.project if hasattr(ctx, "service") else None,
                    tool_name=tool_name,
                    request_data=args,
                    success=False,
                    error_message=str(e),
                    duration_ms=duration_ms,
                )
                raise

        return wrapper

    return decorator
