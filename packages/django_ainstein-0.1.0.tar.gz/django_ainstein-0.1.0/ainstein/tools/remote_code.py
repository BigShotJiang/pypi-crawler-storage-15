"""
Remote Code Execution Tool using Anthropic's Code Execution API.

Uses the anthropic Python package (https://pypi.org/project/anthropic/) to call
Claude's sandboxed code execution environment.

Reference: https://platform.claude.com/docs/en/agents-and-tools/tool-use/code-execution-tool

The execution environment includes:
- Python 3.11 with pre-installed data science libraries
- pandas, numpy, scipy, matplotlib, scikit-learn
- seaborn, plotly, sympy, networkx, and more

Key features:
- 5GB RAM, 5GB disk space
- Isolated container (no internet access)
- Container persists for 30 days
- First 50 hours/day free, then $0.05/hour

File Upload Support:
- Use remote_code_with_files to upload files from storage to the sandbox
- Supports CSV, Excel, JSON, images, and more
- Files are uploaded via Anthropic's Files API
"""

import io
import logging
import os
from typing import Any

import anthropic
from claude_agent_sdk import tool

from ainstein.conf import get_anthropic_api_key, get_code_execution_model
from ainstein.tools.base import ToolContext


logger = logging.getLogger(__name__)

# Beta headers for code execution and files API
CODE_EXECUTION_BETA = "code-execution-2025-08-25"
FILES_API_BETA = "files-api-2025-04-14"


def create_remote_code_tools(ctx: ToolContext) -> list:
    """Create remote code execution tools using the anthropic package."""

    # Persistent container ID for session continuity
    container_id_cache: dict[str, str] = {}

    @tool(
        "remote_code_execution",
        """Execute Python code in Anthropic's secure cloud sandbox.

This is a REMOTE execution environment with:
- Python 3.11 with data science libraries (pandas, numpy, scipy, sklearn, matplotlib, etc.)
- 5GB RAM, 5GB disk space
- Isolated container (no internet access)
- Container persists across calls in the same session

Use this for:
- Data analysis and visualization
- Complex calculations
- Processing files (CSV, Excel, JSON)
- Machine learning experiments

The code runs in a separate secure environment, not on the local system.""",
        {
            "code": str,
            "description": str,
        },
    )
    async def remote_code_execution(args: dict[str, Any]) -> dict[str, Any]:
        """
        Execute Python code in Anthropic's cloud sandbox.

        Uses the anthropic package to call the beta code execution API.
        See: https://pypi.org/project/anthropic/

        Args:
            code: Python code to execute
            description: Brief description of what the code does

        Returns:
            Execution result with stdout, stderr, and any generated files
        """
        code = args.get("code", "")
        description = args.get("description", "Execute Python code remotely")

        if not code.strip():
            return ctx.error("RemoteCode", "No code provided")

        if ctx.is_cancelled():
            ctx.tool_start("RemoteCode", "Cancelled", {"description": description})
            ctx.tool_result(summary="Cancelled")
            return ctx.success("Remote code execution cancelled by user")

        ctx.tool_start("RemoteCode", description, {"code": code[:200] + "..." if len(code) > 200 else code})

        try:
            # Create Anthropic client with API key from Django settings
            # https://pypi.org/project/anthropic/
            client = anthropic.Anthropic(api_key=get_anthropic_api_key())

            # Build messages - ask Claude to execute the code
            messages = [
                {
                    "role": "user",
                    "content": f"Execute this Python code and return the results:\n\n```python\n{code}\n```\n\nProvide the output, any errors, and describe what happened.",
                }
            ]

            # Build API call kwargs
            api_kwargs = {
                "model": get_code_execution_model(),
                "max_tokens": 4096,
                "betas": [CODE_EXECUTION_BETA],
                "tools": [
                    {
                        "type": "code_execution_20250825",
                        "name": "code_execution",
                    }
                ],
                "messages": messages,
            }

            # Include container_id if we have one from previous execution
            session_key = "default"  # Could be made configurable per project
            if session_key in container_id_cache:
                api_kwargs["container"] = container_id_cache[session_key]

            # Call the API with code execution tool enabled
            # Uses client.beta.messages.create() for beta features
            response = client.beta.messages.create(**api_kwargs)

            # Process the response content blocks
            result_parts = []
            has_error = False

            for block in response.content:
                if hasattr(block, "type"):
                    if block.type == "text":
                        result_parts.append(block.text)
                    elif block.type == "tool_use":
                        # Tool use block - Claude is using the code execution tool
                        if hasattr(block, "input"):
                            tool_input = block.input
                            if isinstance(tool_input, dict) and "code" in tool_input:
                                result_parts.append(f"Executed code:\n{tool_input['code'][:500]}")
                    elif block.type == "code_execution_result":
                        # This is the actual execution result
                        # Response includes: stdout, stderr, return_code
                        if hasattr(block, "stdout") and block.stdout:
                            result_parts.append(f"Output:\n{block.stdout}")
                        if hasattr(block, "stderr") and block.stderr:
                            result_parts.append(f"Stderr:\n{block.stderr}")
                            has_error = True
                        if hasattr(block, "return_code") and block.return_code != 0:
                            result_parts.append(f"Return code: {block.return_code}")
                            has_error = True

            # Store container_id for session persistence (containers persist 30 days)
            if hasattr(response, "container") and response.container:
                container_id_cache[session_key] = response.container.id
                logger.info(f"Container ID cached: {response.container.id}")

            # Build final result
            result_text = "\n\n".join(result_parts) if result_parts else "Code executed (no output)"

            ctx.tool_result(summary="Error" if has_error else "Done")

            if has_error:
                return ctx.error("RemoteCode", result_text)
            return ctx.success(result_text)

        except anthropic.APIError as e:
            error_msg = f"API Error: {e}"
            logger.error(error_msg)
            ctx.tool_result(summary="API Error")
            return ctx.error("RemoteCode", error_msg)

        except Exception as e:
            error_msg = f"Error: {type(e).__name__}: {e}"
            logger.exception("Remote code execution failed")
            ctx.tool_result(summary="Error")
            return ctx.error("RemoteCode", error_msg)

    @tool(
        "remote_code_packages",
        "List available packages in the remote code execution environment.",
        {},
    )
    async def remote_code_packages(args: dict[str, Any]) -> dict[str, Any]:
        """List pre-installed packages in the remote environment."""
        packages_info = """# Remote Code Execution Environment

## Python Version
Python 3.11.12

## Pre-installed Packages

### Data Science
- pandas, numpy, scipy, statsmodels
- scikit-learn, xgboost, lightgbm

### Visualization
- matplotlib, seaborn, plotly

### Math & Science
- sympy (symbolic math)
- networkx (graphs)

### Image Processing
- pillow, opencv-python

### File Handling
- openpyxl, xlrd (Excel)
- lxml, beautifulsoup4 (HTML/XML)

### Machine Learning
- torch (PyTorch)
- tensorflow

## Limitations
- No internet access (isolated sandbox)
- 5GB RAM, 5GB disk space
- Container persists for 30 days
"""
        return ctx.success(packages_info)

    @tool(
        "remote_code_with_files",
        """Execute Python code in Anthropic's cloud sandbox WITH file uploads.

Use this when you need to analyze files from storage (CSV, Excel, JSON, images, etc.).
Files are uploaded to the sandbox via Anthropic's Files API.

The sandbox has NO internet access - it cannot download files or install packages.
Files must be uploaded from storage using this tool.

Args:
    file_paths: List of file paths from storage to upload (e.g., ["data.csv", "config.json"])
    code: Python code to execute (files will be available at their original filenames)
    description: Brief description of what the code does

Example:
    file_paths: ["sales_data.csv"]
    code: "import pandas as pd; df = pd.read_csv('sales_data.csv'); print(df.describe())"
    description: Analyze sales data statistics""",
        {
            "file_paths": list,
            "code": str,
            "description": str,
        },
    )
    async def remote_code_with_files(args: dict[str, Any]) -> dict[str, Any]:
        """
        Execute Python code with files uploaded from storage to the sandbox.

        This tool:
        1. Reads files from our Django storage
        2. Uploads them to Anthropic's Files API
        3. Executes code with those files available in the sandbox
        """
        file_paths = args.get("file_paths", [])
        code = args.get("code", "")
        description = args.get("description", "Execute code with files")

        if not code.strip():
            return ctx.error("RemoteCodeFiles", "No code provided")

        if not file_paths:
            return ctx.error(
                "RemoteCodeFiles",
                "No file_paths provided. Use remote_code_execution for code without files.",
            )

        if ctx.is_cancelled():
            ctx.tool_start("RemoteCodeFiles", "Cancelled", {"description": description})
            ctx.tool_result(summary="Cancelled")
            return ctx.success("Remote code execution cancelled by user")

        ctx.tool_start(
            "RemoteCodeFiles",
            description,
            {"files": file_paths, "code": code[:200] + "..." if len(code) > 200 else code},
        )

        try:
            # Create Anthropic client
            client = anthropic.Anthropic(api_key=get_anthropic_api_key())

            # Upload files from storage to Anthropic Files API
            uploaded_files = []
            for file_path in file_paths:
                # Build full path within project folder
                full_path = f"{ctx.project_folder}/{file_path}" if ctx.project_folder else file_path

                # Read file from storage
                try:
                    with ctx.storage.open(full_path, "rb") as f:
                        file_content = f.read()
                except FileNotFoundError:
                    return ctx.error("RemoteCodeFiles", f"File not found in storage: {file_path}")
                except Exception as e:
                    return ctx.error("RemoteCodeFiles", f"Error reading file {file_path}: {e}")

                # Get filename for the sandbox
                filename = os.path.basename(file_path)

                # Upload to Anthropic Files API
                file_obj = io.BytesIO(file_content)
                file_obj.name = filename

                try:
                    uploaded = client.beta.files.upload(file=file_obj)
                    uploaded_files.append(
                        {
                            "file_id": uploaded.id,
                            "filename": filename,
                            "original_path": file_path,
                        }
                    )
                    logger.info(f"Uploaded {filename} to Anthropic Files API: {uploaded.id}")
                except Exception as e:
                    return ctx.error("RemoteCodeFiles", f"Failed to upload {filename}: {e}")

            # Build message content with file references
            file_list = "\n".join(f"- {f['filename']}" for f in uploaded_files)
            content = [
                {
                    "type": "text",
                    "text": f"Execute this Python code. The following files have been uploaded and are available:\n\n{file_list}\n\n```python\n{code}\n```\n\nExecute the code and return the results.",
                },
            ]

            # Add container_upload blocks for each file
            for f in uploaded_files:
                content.append({"type": "container_upload", "file_id": f["file_id"]})

            messages = [{"role": "user", "content": content}]

            # Build API call with both beta headers
            api_kwargs = {
                "model": get_code_execution_model(),
                "max_tokens": 4096,
                "betas": [CODE_EXECUTION_BETA, FILES_API_BETA],
                "tools": [{"type": "code_execution_20250825", "name": "code_execution"}],
                "messages": messages,
            }

            # Include container_id for session persistence
            session_key = "default"
            if session_key in container_id_cache:
                api_kwargs["container"] = container_id_cache[session_key]

            # Execute
            response = client.beta.messages.create(**api_kwargs)

            # Process response
            result_parts = []
            has_error = False

            for block in response.content:
                if hasattr(block, "type"):
                    if block.type == "text":
                        result_parts.append(block.text)
                    elif block.type == "tool_use":
                        if hasattr(block, "input"):
                            tool_input = block.input
                            if isinstance(tool_input, dict) and "code" in tool_input:
                                result_parts.append(f"Executed code:\n{tool_input['code'][:500]}")
                    elif block.type == "code_execution_result":
                        if hasattr(block, "stdout") and block.stdout:
                            result_parts.append(f"Output:\n{block.stdout}")
                        if hasattr(block, "stderr") and block.stderr:
                            result_parts.append(f"Stderr:\n{block.stderr}")
                            has_error = True
                        if hasattr(block, "return_code") and block.return_code != 0:
                            result_parts.append(f"Return code: {block.return_code}")
                            has_error = True

            # Cache container ID
            if hasattr(response, "container") and response.container:
                container_id_cache[session_key] = response.container.id
                logger.info(f"Container ID cached: {response.container.id}")

            # Build result
            result_text = "\n\n".join(result_parts) if result_parts else "Code executed (no output)"

            ctx.tool_result(summary="Error" if has_error else "Done")

            if has_error:
                return ctx.error("RemoteCodeFiles", result_text)
            return ctx.success(result_text)

        except anthropic.APIError as e:
            error_msg = f"API Error: {e}"
            logger.error(error_msg)
            ctx.tool_result(summary="API Error")
            return ctx.error("RemoteCodeFiles", error_msg)

        except Exception as e:
            error_msg = f"Error: {type(e).__name__}: {e}"
            logger.exception("Remote code with files failed")
            ctx.tool_result(summary="Error")
            return ctx.error("RemoteCodeFiles", error_msg)

    return [remote_code_execution, remote_code_packages, remote_code_with_files]
