"""
Claude Agent Tools Package.

This module provides all MCP tools for Claude Agent:
- Storage tools: File operations (read, write, delete, list, move)
- Page tools: BlockNote JSON file operations
- Django tools: Database queries and exports

Usage:
    from ainstein.tools import create_all_tools, ToolContext

    ctx = ToolContext(
        service=service,
        storage=storage,
        project_folder="my_project",
        max_limit=1000,
        file_mtimes={}
    )
    tools = create_all_tools(ctx)
"""

from ainstein.tools.advanced_export import create_advanced_export_tools
from ainstein.tools.base import ToolContext, register_tool
from ainstein.tools.code import create_code_tools
from ainstein.tools.django_tools import create_django_tools
from ainstein.tools.model_routing import create_model_routing_tools
from ainstein.tools.page import create_page_tools
from ainstein.tools.remote_code import create_remote_code_tools
from ainstein.tools.security import create_security_tools
from ainstein.tools.storage import create_storage_tools
from ainstein.tools.uv_code import TOOLS_REQUIRING_APPROVAL, create_uv_code_tools
from ainstein.tools.visualization import create_visualization_tools
from ainstein.tools.workflow import create_workflow_tools


# Tool names for each category (useful for documentation and server setup)
STORAGE_TOOL_NAMES = [
    "storage_read",
    "storage_write",
    "storage_delete",
    "storage_list",
    "storage_exists",
    "storage_move",
    "storage_delete_folder",
    "get_file_url",
    "storage_edit",
    "storage_grep",
]

PAGE_TOOL_NAMES = [
    "page_write",
    "markdown_to_blocks",
    "page_read",
    "page_append",
    "page_insert",
    "page_update",
    "page_delete",
    "page_move",
    "page_nest",
    "page_unnest",
]

DJANGO_TOOL_NAMES = [
    "django_list_models",
    "django_describe_model",
    "django_query",
    "django_export_query",
    "django_aggregate",
    "django_raw_sql",
]

CODE_TOOL_NAMES = [
    "execute_code",
]

UV_CODE_TOOL_NAMES = [
    "uv_execute_code",
    "uv_sandbox",
    "openrouter_models",
]

REMOTE_CODE_TOOL_NAMES = [
    "remote_code_execution",
    "remote_code_packages",
    "remote_code_with_files",
]

VISUALIZATION_TOOL_NAMES = [
    "create_chart",
    "list_chart_types",
    "quick_chart",
]

WORKFLOW_TOOL_NAMES = [
    "script_save",
    "script_list",
    "script_run",
    "workflow_create",
    "workflow_run",
    "workflow_list",
]

ADVANCED_EXPORT_TOOL_NAMES = [
    "export_excel",
    "export_pdf",
    "process_image",
    "convert_data_format",
]

SECURITY_TOOL_NAMES = [
    "audit_log_query",
    "check_rate_limit",
    "check_cost_limit",
    "set_cost_limit",
    "scan_sensitive_data",
    "security_report",
]

MODEL_ROUTING_TOOL_NAMES = [
    "recommend_model",
    "estimate_cost",
    "set_model_preference",
]

# CODE_TOOL_NAMES excluded - restricted sandbox, no external deps
# REMOTE_CODE_TOOL_NAMES excluded - use UV_CODE_TOOL_NAMES instead
ALL_TOOL_NAMES = (
    STORAGE_TOOL_NAMES
    + PAGE_TOOL_NAMES
    + DJANGO_TOOL_NAMES
    + UV_CODE_TOOL_NAMES
    + VISUALIZATION_TOOL_NAMES
    + WORKFLOW_TOOL_NAMES
    + ADVANCED_EXPORT_TOOL_NAMES
    + SECURITY_TOOL_NAMES
    + MODEL_ROUTING_TOOL_NAMES
)


def create_all_tools(ctx: ToolContext) -> list:
    """
    Create all tools for the Claude Agent MCP server.

    This is the main entry point for tool creation. It aggregates tools from
    all modules (storage, page, django) into a single list.

    Args:
        ctx: ToolContext containing service, storage, and configuration.

    Returns:
        List of all tool functions ready for MCP server registration.

    Example:
        ctx = ToolContext(
            service=my_service,
            storage=storages["agent_files"],
            project_folder="project_123",
            max_limit=1000,
            file_mtimes={}
        )
        tools = create_all_tools(ctx)
        server = create_sdk_mcp_server(name="app", tools=tools)
    """
    tools = []
    tools.extend(create_storage_tools(ctx))
    tools.extend(create_page_tools(ctx))
    tools.extend(create_django_tools(ctx))
    # create_code_tools disabled - restricted sandbox, no external deps
    # create_remote_code_tools disabled - use uv_execute_code instead
    tools.extend(create_uv_code_tools(ctx))
    # Phase 9 tools
    tools.extend(create_visualization_tools(ctx))
    tools.extend(create_workflow_tools(ctx))
    tools.extend(create_advanced_export_tools(ctx))
    tools.extend(create_security_tools(ctx))
    tools.extend(create_model_routing_tools(ctx))
    return tools


__all__ = [
    # Main factory function
    "create_all_tools",
    # Context and utilities
    "ToolContext",
    "register_tool",
    # Individual factory functions (for selective tool creation)
    "create_storage_tools",
    "create_page_tools",
    "create_django_tools",
    "create_code_tools",
    "create_uv_code_tools",
    "create_remote_code_tools",
    # Phase 9 factory functions
    "create_visualization_tools",
    "create_workflow_tools",
    "create_advanced_export_tools",
    "create_security_tools",
    "create_model_routing_tools",
    # Tool name lists
    "STORAGE_TOOL_NAMES",
    "PAGE_TOOL_NAMES",
    "DJANGO_TOOL_NAMES",
    "CODE_TOOL_NAMES",
    "UV_CODE_TOOL_NAMES",
    "REMOTE_CODE_TOOL_NAMES",
    "VISUALIZATION_TOOL_NAMES",
    "WORKFLOW_TOOL_NAMES",
    "ADVANCED_EXPORT_TOOL_NAMES",
    "SECURITY_TOOL_NAMES",
    "MODEL_ROUTING_TOOL_NAMES",
    "ALL_TOOL_NAMES",
    # Permission-related
    "TOOLS_REQUIRING_APPROVAL",
]
