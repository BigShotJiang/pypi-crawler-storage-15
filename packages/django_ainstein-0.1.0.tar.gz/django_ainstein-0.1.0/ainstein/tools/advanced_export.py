"""
Advanced File Handling Tools (Phase 9.3).

Tools for Excel export, PDF generation, and image processing.
"""

import io
import json
import logging
from typing import Any

from claude_agent_sdk import tool
from django.core.files.base import ContentFile

from ainstein.tools.base import ToolContext


logger = logging.getLogger(__name__)


def create_advanced_export_tools(ctx: ToolContext) -> list:
    """Create advanced file handling tools."""

    @tool(
        "export_excel",
        """Export data to Excel (.xlsx) format.

Supports multiple sheets, formatting, and formulas.

Args:
    data: Dict mapping sheet names to data (list of dicts or 2D list)
    path: Output file path (auto-adds .xlsx)
    title: Workbook title
    column_widths: Dict of column name -> width (optional)
    freeze_panes: Freeze rows/cols, e.g., "A2" freezes first row

Example:
    data = {
        "Sales": [{"Product": "A", "Revenue": 100}, {"Product": "B", "Revenue": 200}],
        "Summary": [["Total", 300], ["Average", 150]]
    }
""",
        {
            "data": dict,
            "path": str,
            "title": str,
            "column_widths": dict,
            "freeze_panes": str,
        },
    )
    async def export_excel(args: dict[str, Any]) -> dict[str, Any]:
        """Export data to Excel format."""
        try:
            import openpyxl
            from openpyxl.styles import Alignment, Font, PatternFill
            from openpyxl.utils import get_column_letter
        except ImportError:
            return ctx.error("ExportExcel", "openpyxl not installed. Run: pip install openpyxl")

        data = args.get("data", {})
        path = args.get("path", "export.xlsx")
        title = args.get("title", "Export")
        column_widths = args.get("column_widths", {})
        freeze_panes = args.get("freeze_panes", "A2")

        # Handle case where data is passed as JSON string
        if isinstance(data, str):
            try:
                data = json.loads(data)
            except json.JSONDecodeError:
                return ctx.error("ExportExcel", "Invalid data format - expected dict or JSON string")

        if not data:
            return ctx.error("ExportExcel", "No data provided")

        # Ensure data is a dict with sheet_name -> sheet_data
        if not isinstance(data, dict):
            return ctx.error(
                "ExportExcel", f"Data must be a dict mapping sheet names to data, got {type(data).__name__}"
            )

        if not path.endswith(".xlsx"):
            path += ".xlsx"

        ctx.tool_start("ExportExcel", f"Exporting to {path}", {"sheets": len(data)})

        try:
            wb = openpyxl.Workbook()
            wb.title = title

            # Remove default sheet
            if "Sheet" in wb.sheetnames:
                del wb["Sheet"]

            # Header style
            header_font = Font(bold=True, color="FFFFFF")
            header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
            header_alignment = Alignment(horizontal="center", vertical="center")

            for sheet_name, sheet_data in data.items():
                ws = wb.create_sheet(title=sheet_name[:31])  # Excel limit

                if not sheet_data:
                    continue

                # Handle list of dicts
                if isinstance(sheet_data[0], dict):
                    headers = list(sheet_data[0].keys())

                    # Write headers
                    for col, header in enumerate(headers, 1):
                        cell = ws.cell(row=1, column=col, value=header)
                        cell.font = header_font
                        cell.fill = header_fill
                        cell.alignment = header_alignment

                    # Write data
                    for row_idx, row_data in enumerate(sheet_data, 2):
                        for col_idx, header in enumerate(headers, 1):
                            ws.cell(row=row_idx, column=col_idx, value=row_data.get(header))

                    # Set column widths
                    for col_idx, header in enumerate(headers, 1):
                        width = column_widths.get(header, max(len(str(header)) + 2, 12))
                        ws.column_dimensions[get_column_letter(col_idx)].width = width

                # Handle 2D list
                elif isinstance(sheet_data[0], (list, tuple)):
                    for row_idx, row_data in enumerate(sheet_data, 1):
                        for col_idx, value in enumerate(row_data, 1):
                            cell = ws.cell(row=row_idx, column=col_idx, value=value)
                            if row_idx == 1:
                                cell.font = header_font
                                cell.fill = header_fill

                # Freeze panes
                if freeze_panes:
                    ws.freeze_panes = freeze_panes

            # Save to bytes
            buffer = io.BytesIO()
            wb.save(buffer)
            buffer.seek(0)
            excel_bytes = buffer.read()

            # Save to storage
            full_path = ctx.resolve_path(path)
            if ctx.storage.exists(full_path):
                ctx.storage.delete(full_path)
            ctx.storage.save(full_path, ContentFile(excel_bytes))

            ctx.tool_result(
                summary="Exported",
                stats={
                    "path": path,
                    "sheets": len(data),
                    "size": len(excel_bytes),
                },
            )

            return ctx.success(f"Excel file saved to {path} ({len(excel_bytes):,} bytes, {len(data)} sheets)")

        except Exception as e:
            logger.exception("Excel export failed")
            ctx.tool_result(summary="Error")
            return ctx.error("ExportExcel", f"Error: {e}")

    @tool(
        "export_pdf",
        """Generate a PDF document from text or HTML content.

Args:
    content: Text or HTML content to convert
    path: Output file path (auto-adds .pdf)
    title: Document title
    format: 'text', 'html', or 'markdown'
    page_size: 'letter', 'a4', 'legal'
    orientation: 'portrait' or 'landscape'
""",
        {
            "content": str,
            "path": str,
            "title": str,
            "format": str,
            "page_size": str,
            "orientation": str,
        },
    )
    async def export_pdf(args: dict[str, Any]) -> dict[str, Any]:
        """Generate a PDF document."""
        try:
            from reportlab.lib.pagesizes import A4, LETTER, landscape, legal
            from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
            from reportlab.lib.units import inch
            from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer
        except ImportError:
            return ctx.error("ExportPDF", "reportlab not installed. Run: pip install reportlab")

        content = args.get("content", "")
        path = args.get("path", "document.pdf")
        title = args.get("title", "Document")
        content_format = args.get("format", "text")
        page_size = args.get("page_size", "letter")
        orientation = args.get("orientation", "portrait")

        if not content:
            return ctx.error("ExportPDF", "No content provided")

        if not path.endswith(".pdf"):
            path += ".pdf"

        ctx.tool_start("ExportPDF", f"Generating PDF: {path}", {"format": content_format})

        try:
            # Determine page size
            size_map = {"letter": LETTER, "a4": A4, "legal": legal}
            page = size_map.get(page_size.lower(), LETTER)

            if orientation.lower() == "landscape":
                page = landscape(page)

            # Create PDF
            buffer = io.BytesIO()
            doc = SimpleDocTemplate(
                buffer,
                pagesize=page,
                rightMargin=0.75 * inch,
                leftMargin=0.75 * inch,
                topMargin=0.75 * inch,
                bottomMargin=0.75 * inch,
            )

            styles = getSampleStyleSheet()
            story = []

            # Add title
            title_style = ParagraphStyle(
                "CustomTitle",
                parent=styles["Heading1"],
                fontSize=18,
                spaceAfter=20,
            )
            story.append(Paragraph(title, title_style))
            story.append(Spacer(1, 12))

            # Process content based on format
            if content_format == "markdown":
                # Simple markdown processing
                lines = content.split("\n")
                for line in lines:
                    if line.startswith("# "):
                        story.append(Paragraph(line[2:], styles["Heading1"]))
                    elif line.startswith("## "):
                        story.append(Paragraph(line[3:], styles["Heading2"]))
                    elif line.startswith("### "):
                        story.append(Paragraph(line[4:], styles["Heading3"]))
                    elif line.startswith("- "):
                        story.append(Paragraph(f"• {line[2:]}", styles["Normal"]))
                    elif line.strip():
                        story.append(Paragraph(line, styles["Normal"]))
                    else:
                        story.append(Spacer(1, 6))

            elif content_format == "html":
                # Basic HTML support through reportlab
                story.append(Paragraph(content, styles["Normal"]))

            else:
                # Plain text
                for line in content.split("\n"):
                    if line.strip():
                        story.append(Paragraph(line, styles["Normal"]))
                    else:
                        story.append(Spacer(1, 6))

            # Build PDF
            doc.build(story)
            buffer.seek(0)
            pdf_bytes = buffer.read()

            # Save to storage
            full_path = ctx.resolve_path(path)
            if ctx.storage.exists(full_path):
                ctx.storage.delete(full_path)
            ctx.storage.save(full_path, ContentFile(pdf_bytes))

            ctx.tool_result(
                summary="Generated",
                stats={
                    "path": path,
                    "size": len(pdf_bytes),
                    "pages": "1+",
                },
            )

            return ctx.success(f"PDF saved to {path} ({len(pdf_bytes):,} bytes)")

        except Exception as e:
            logger.exception("PDF generation failed")
            ctx.tool_result(summary="Error")
            return ctx.error("ExportPDF", f"Error: {e}")

    @tool(
        "process_image",
        """Process an image file (resize, convert, compress).

Args:
    input_path: Source image file
    output_path: Destination file path
    operations: List of operations to apply:
        - {"type": "resize", "width": 800, "height": 600}
        - {"type": "resize", "max_dimension": 1024}
        - {"type": "convert", "format": "png"}
        - {"type": "compress", "quality": 85}
        - {"type": "grayscale"}
        - {"type": "rotate", "degrees": 90}
        - {"type": "crop", "left": 0, "top": 0, "right": 100, "bottom": 100}
""",
        {
            "input_path": str,
            "output_path": str,
            "operations": list,
        },
    )
    async def process_image(args: dict[str, Any]) -> dict[str, Any]:
        """Process an image file."""
        try:
            from PIL import Image
        except ImportError:
            return ctx.error("ProcessImage", "Pillow not installed. Run: pip install Pillow")

        input_path = args.get("input_path", "")
        output_path = args.get("output_path", "")
        operations = args.get("operations", [])

        if not input_path:
            return ctx.error("ProcessImage", "input_path is required")

        if not output_path:
            output_path = input_path

        ctx.tool_start("ProcessImage", f"Processing {input_path}", {"operations": len(operations)})

        try:
            # Read input image
            full_input = ctx.resolve_path(input_path)
            if not ctx.storage.exists(full_input):
                return ctx.error("ProcessImage", f"Image not found: {input_path}")

            with ctx.storage.open(full_input, "rb") as f:
                img = Image.open(f)
                img.load()  # Force load before closing file

            original_size = img.size
            original_format = img.format

            # Apply operations
            for op in operations:
                op_type = op.get("type", "")

                if op_type == "resize":
                    if "max_dimension" in op:
                        max_dim = op["max_dimension"]
                        ratio = min(max_dim / img.width, max_dim / img.height)
                        if ratio < 1:
                            new_size = (int(img.width * ratio), int(img.height * ratio))
                            img = img.resize(new_size, Image.Resampling.LANCZOS)
                    else:
                        width = op.get("width", img.width)
                        height = op.get("height", img.height)
                        img = img.resize((width, height), Image.Resampling.LANCZOS)

                elif op_type == "grayscale":
                    img = img.convert("L")

                elif op_type == "rotate":
                    degrees = op.get("degrees", 0)
                    img = img.rotate(degrees, expand=True)

                elif op_type == "crop":
                    left = op.get("left", 0)
                    top = op.get("top", 0)
                    right = op.get("right", img.width)
                    bottom = op.get("bottom", img.height)
                    img = img.crop((left, top, right, bottom))

            # Determine output format
            output_format = original_format or "PNG"
            for op in operations:
                if op.get("type") == "convert":
                    output_format = op.get("format", output_format).upper()

            # Get compression quality
            quality = 95
            for op in operations:
                if op.get("type") == "compress":
                    quality = op.get("quality", 85)

            # Ensure correct extension
            ext_map = {"JPEG": ".jpg", "PNG": ".png", "GIF": ".gif", "WEBP": ".webp"}
            expected_ext = ext_map.get(output_format, f".{output_format.lower()}")
            if not output_path.lower().endswith(expected_ext):
                output_path = output_path.rsplit(".", 1)[0] + expected_ext

            # Save to bytes
            buffer = io.BytesIO()
            save_kwargs = {}
            if output_format in ("JPEG", "WEBP"):
                save_kwargs["quality"] = quality
            if img.mode == "RGBA" and output_format == "JPEG":
                img = img.convert("RGB")

            img.save(buffer, format=output_format, **save_kwargs)
            buffer.seek(0)
            img_bytes = buffer.read()

            # Save to storage
            full_output = ctx.resolve_path(output_path)
            if ctx.storage.exists(full_output):
                ctx.storage.delete(full_output)
            ctx.storage.save(full_output, ContentFile(img_bytes))

            ctx.tool_result(
                summary="Processed",
                stats={
                    "input": input_path,
                    "output": output_path,
                    "original_size": f"{original_size[0]}x{original_size[1]}",
                    "new_size": f"{img.width}x{img.height}",
                    "file_size": len(img_bytes),
                },
            )

            return ctx.success(
                f"Image processed: {output_path}\n"
                f"Original: {original_size[0]}x{original_size[1]}\n"
                f"New: {img.width}x{img.height}\n"
                f"Size: {len(img_bytes):,} bytes"
            )

        except Exception as e:
            logger.exception("Image processing failed")
            ctx.tool_result(summary="Error")
            return ctx.error("ProcessImage", f"Error: {e}")

    @tool(
        "convert_data_format",
        """Convert data between formats (JSON, CSV, YAML, XML).

Args:
    input_path: Source file
    output_path: Destination file
    input_format: 'json', 'csv', 'yaml', 'xml' (auto-detected from extension if not provided)
    output_format: 'json', 'csv', 'yaml', 'xml' (auto-detected from extension if not provided)
""",
        {
            "input_path": str,
            "output_path": str,
            "input_format": str,
            "output_format": str,
        },
    )
    async def convert_data_format(args: dict[str, Any]) -> dict[str, Any]:
        """Convert data between formats."""
        import csv

        input_path = args.get("input_path", "")
        output_path = args.get("output_path", "")
        input_format = args.get("input_format", "")
        output_format = args.get("output_format", "")

        if not input_path or not output_path:
            return ctx.error("ConvertFormat", "input_path and output_path are required")

        # Auto-detect formats from extensions
        if not input_format:
            ext = input_path.rsplit(".", 1)[-1].lower()
            input_format = {"json": "json", "csv": "csv", "yaml": "yaml", "yml": "yaml", "xml": "xml"}.get(ext, "json")

        if not output_format:
            ext = output_path.rsplit(".", 1)[-1].lower()
            output_format = {"json": "json", "csv": "csv", "yaml": "yaml", "yml": "yaml", "xml": "xml"}.get(ext, "json")

        ctx.tool_start("ConvertFormat", f"Converting {input_format} to {output_format}", {})

        try:
            # Read input
            full_input = ctx.resolve_path(input_path)
            if not ctx.storage.exists(full_input):
                return ctx.error("ConvertFormat", f"File not found: {input_path}")

            content = ctx.read_file(full_input)

            # Parse input
            if input_format == "json":
                data = json.loads(content)
            elif input_format == "csv":
                reader = csv.DictReader(io.StringIO(content))
                data = list(reader)
            elif input_format == "yaml":
                try:
                    import yaml

                    data = yaml.safe_load(content)
                except ImportError:
                    return ctx.error("ConvertFormat", "PyYAML not installed")
            elif input_format == "xml":
                try:
                    import xmltodict

                    data = xmltodict.parse(content)
                except ImportError:
                    return ctx.error("ConvertFormat", "xmltodict not installed")
            else:
                return ctx.error("ConvertFormat", f"Unsupported input format: {input_format}")

            # Generate output
            if output_format == "json":
                output = json.dumps(data, indent=2, default=str)
            elif output_format == "csv":
                if isinstance(data, list) and data and isinstance(data[0], dict):
                    buffer = io.StringIO()
                    writer = csv.DictWriter(buffer, fieldnames=data[0].keys())
                    writer.writeheader()
                    writer.writerows(data)
                    output = buffer.getvalue()
                else:
                    return ctx.error("ConvertFormat", "CSV output requires list of dicts")
            elif output_format == "yaml":
                try:
                    import yaml

                    output = yaml.dump(data, default_flow_style=False)
                except ImportError:
                    return ctx.error("ConvertFormat", "PyYAML not installed")
            elif output_format == "xml":
                try:
                    import xmltodict

                    if not isinstance(data, dict):
                        data = {"root": {"item": data}}
                    output = xmltodict.unparse(data, pretty=True)
                except ImportError:
                    return ctx.error("ConvertFormat", "xmltodict not installed")
            else:
                return ctx.error("ConvertFormat", f"Unsupported output format: {output_format}")

            # Save output
            full_output = ctx.resolve_path(output_path)
            ctx.write_file(full_output, output)

            ctx.tool_result(
                summary="Converted",
                stats={
                    "input": input_path,
                    "output": output_path,
                    "input_format": input_format,
                    "output_format": output_format,
                },
            )

            return ctx.success(f"Converted {input_path} ({input_format}) to {output_path} ({output_format})")

        except Exception as e:
            logger.exception("Format conversion failed")
            ctx.tool_result(summary="Error")
            return ctx.error("ConvertFormat", f"Error: {e}")

    return [export_excel, export_pdf, process_image, convert_data_format]
