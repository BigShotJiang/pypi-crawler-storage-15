"""
Workflow Automation Tools (Phase 9.2).

Tools for managing reusable scripts, workflow templates, and scheduled execution.
"""

import json
import logging
from typing import Any

from claude_agent_sdk import tool
from django.utils.text import slugify

from ainstein.tools.base import ToolContext


logger = logging.getLogger(__name__)


def create_workflow_tools(ctx: ToolContext) -> list:
    """Create workflow automation tools."""

    @tool(
        "script_save",
        """Save a Python script to the reusable script library.

Scripts can be versioned and reused across conversations.
Each save creates a new version if the script already exists.

Args:
    name: Human-readable script name
    code: Python code
    description: What the script does
    tags: List of tags for categorization
    input_schema: Expected input format (optional)
    output_schema: Expected output format (optional)
""",
        {
            "name": str,
            "code": str,
            "description": str,
            "tags": list,
            "input_schema": dict,
            "output_schema": dict,
        },
    )
    async def script_save(args: dict[str, Any]) -> dict[str, Any]:
        """Save a script to the library."""
        from ainstein.models import AiScript

        name = args.get("name", "")
        code = args.get("code", "")
        description = args.get("description", "")
        tags = args.get("tags", [])
        input_schema = args.get("input_schema", {})
        output_schema = args.get("output_schema", {})

        if not name or not code:
            return ctx.error("ScriptSave", "Name and code are required")

        ctx.tool_start("ScriptSave", f"Saving script: {name}", {"name": name})

        try:
            slug = slugify(name)

            # Get user and project from service
            user = ctx.user
            project = ctx.project

            # Check for existing script
            existing = AiScript.get_latest_version(user, slug, project)

            if existing:
                # Create new version
                script = existing.create_new_version(code, description)
                message = f"Updated script '{name}' to version {script.version}"
            else:
                # Create new script
                script = AiScript.objects.create(
                    name=name,
                    slug=slug,
                    code=code,
                    description=description,
                    user=user,
                    project=project,
                    tags=tags,
                    input_schema=input_schema,
                    output_schema=output_schema,
                )
                message = f"Created script '{name}' v1"

            ctx.tool_result(
                summary="Saved",
                stats={
                    "script_id": str(script.id),
                    "name": script.name,
                    "version": script.version,
                },
            )

            return ctx.success(message)

        except Exception as e:
            logger.exception("Script save failed")
            ctx.tool_result(summary="Error")
            return ctx.error("ScriptSave", f"Error: {e}")

    @tool(
        "script_list",
        """List available scripts in the library.

Args:
    tag: Filter by tag (optional)
    include_public: Include public scripts from other users
""",
        {
            "tag": str,
            "include_public": bool,
        },
    )
    async def script_list(args: dict[str, Any]) -> dict[str, Any]:
        """List scripts in the library."""
        from django.db.models import Q

        from ainstein.models import AiScript

        tag = args.get("tag", "")
        include_public = args.get("include_public", True)

        ctx.tool_start("ScriptList", "Listing scripts", {})

        try:
            user = ctx.user
            project = ctx.project

            # Build query
            q = Q(user=user)
            if project:
                q &= Q(project=project) | Q(project__isnull=True)

            if include_public:
                q |= Q(is_public=True)

            scripts = AiScript.objects.filter(q)

            if tag:
                scripts = scripts.filter(tags__contains=[tag])

            # Get latest version of each script
            seen_slugs = set()
            script_list = []

            for script in scripts.order_by("slug", "-version"):
                if script.slug not in seen_slugs:
                    seen_slugs.add(script.slug)
                    script_list.append(
                        {
                            "id": str(script.id),
                            "name": script.name,
                            "slug": script.slug,
                            "version": script.version,
                            "description": script.description[:100],
                            "tags": script.tags,
                            "is_public": script.is_public,
                        }
                    )

            ctx.tool_result(summary=f"{len(script_list)} scripts")

            if not script_list:
                return ctx.success("No scripts found in library.")

            result = "# Script Library\n\n"
            for s in script_list:
                result += f"## {s['name']} (v{s['version']})\n"
                result += f"- ID: `{s['id']}`\n"
                result += f"- Slug: `{s['slug']}`\n"
                if s["description"]:
                    result += f"- Description: {s['description']}\n"
                if s["tags"]:
                    result += f"- Tags: {', '.join(s['tags'])}\n"
                result += "\n"

            return ctx.success(result)

        except Exception as e:
            logger.exception("Script list failed")
            ctx.tool_result(summary="Error")
            return ctx.error("ScriptList", f"Error: {e}")

    @tool(
        "script_run",
        """Execute a saved script from the library.

Args:
    script_id: Script UUID or slug
    input_files: List of input file paths
    output_file: Output file path (optional)
    parameters: Additional parameters to pass to script
""",
        {
            "script_id": str,
            "input_files": list,
            "output_file": str,
            "parameters": dict,
        },
    )
    async def script_run(args: dict[str, Any]) -> dict[str, Any]:
        """Execute a saved script."""
        from ainstein.models import AiScript

        script_id = args.get("script_id", "")
        input_files = args.get("input_files", [])
        output_file = args.get("output_file", "")
        parameters = args.get("parameters", {})

        if not script_id:
            return ctx.error("ScriptRun", "script_id is required")

        ctx.tool_start("ScriptRun", f"Running script: {script_id}", {})

        try:
            user = ctx.user

            # Find script by ID or slug
            try:
                import uuid as uuid_module

                uuid_module.UUID(script_id)
                script = AiScript.objects.get(id=script_id)
            except (ValueError, AiScript.DoesNotExist):
                script = AiScript.get_latest_version(user, script_id)

            if not script:
                return ctx.error("ScriptRun", f"Script not found: {script_id}")

            # Build code with parameters
            code = f"""
# Script: {script.name} v{script.version}
# {script.description}

# Parameters
params = {json.dumps(parameters)}

{script.code}
"""

            # Use remote code execution
            from ainstein.tools.remote_code import create_remote_code_tools

            remote_tools = create_remote_code_tools(ctx)
            remote_exec = next(t for t in remote_tools if t.name == "remote_code_with_files")

            result = await remote_exec.handler(
                {
                    "file_paths": input_files,
                    "code": code,
                    "description": f"Running {script.name}",
                }
            )

            # Save output if specified
            if output_file and not result.get("is_error"):
                # Extract result from response
                response_text = ""
                for content in result.get("content", []):
                    if content.get("type") == "text":
                        response_text += content.get("text", "")

                if response_text:
                    output_path = ctx.resolve_path(output_file)
                    ctx.write_file(output_path, response_text)

            ctx.tool_result(summary="Completed" if not result.get("is_error") else "Error")
            return result

        except Exception as e:
            logger.exception("Script run failed")
            ctx.tool_result(summary="Error")
            return ctx.error("ScriptRun", f"Error: {e}")

    @tool(
        "workflow_create",
        """Create a workflow template with multiple steps.

Workflows define a sequence of tool calls to execute in order.
Each step can use the output of previous steps.

Args:
    name: Workflow name
    description: What the workflow does
    steps: List of steps, each with {tool, args, output_var}
    trigger: 'manual', 'schedule', 'webhook', or 'file_upload'
    schedule_cron: Cron expression if trigger='schedule'

Example steps:
[
    {"tool": "django_export_query", "args": {"app_label": "jobs", "model_name": "Company"}, "output_var": "companies"},
    {"tool": "script_run", "args": {"script_id": "analyze-data", "input_files": ["$companies"]}, "output_var": "analysis"},
    {"tool": "create_chart", "args": {"data_files": ["$analysis"]}, "output_var": "chart"}
]
""",
        {
            "name": str,
            "description": str,
            "steps": list,
            "trigger": str,
            "schedule_cron": str,
        },
    )
    async def workflow_create(args: dict[str, Any]) -> dict[str, Any]:
        """Create a workflow template."""
        from ainstein.models import AiWorkflow

        name = args.get("name", "")
        description = args.get("description", "")
        steps = args.get("steps", [])
        trigger = args.get("trigger", "manual")
        schedule_cron = args.get("schedule_cron", "")

        if not name or not steps:
            return ctx.error("WorkflowCreate", "Name and steps are required")

        ctx.tool_start("WorkflowCreate", f"Creating workflow: {name}", {"steps": len(steps)})

        try:
            user = ctx.user
            project = ctx.project

            if not project:
                return ctx.error("WorkflowCreate", "No project selected")

            workflow = AiWorkflow.objects.create(
                name=name,
                slug=slugify(name),
                description=description,
                user=user,
                project=project,
                steps=steps,
                trigger=trigger,
                schedule_cron=schedule_cron,
            )

            ctx.tool_result(
                summary="Created",
                stats={"workflow_id": str(workflow.id), "steps": len(steps)},
            )

            return ctx.success(f"Created workflow '{name}' with {len(steps)} steps (ID: {workflow.id})")

        except Exception as e:
            logger.exception("Workflow create failed")
            ctx.tool_result(summary="Error")
            return ctx.error("WorkflowCreate", f"Error: {e}")

    @tool(
        "workflow_run",
        """Execute a workflow by ID or name.

Args:
    workflow_id: Workflow UUID or slug
    input_data: Initial input data for the workflow
""",
        {
            "workflow_id": str,
            "input_data": dict,
        },
    )
    async def workflow_run(args: dict[str, Any]) -> dict[str, Any]:
        """Execute a workflow."""
        from django.utils import timezone

        from ainstein.models import AiWorkflow, AiWorkflowRun

        workflow_id = args.get("workflow_id", "")
        input_data = args.get("input_data", {})

        if not workflow_id:
            return ctx.error("WorkflowRun", "workflow_id is required")

        ctx.tool_start("WorkflowRun", f"Running workflow: {workflow_id}", {})

        try:
            user = ctx.user
            project = ctx.project

            # Find workflow
            try:
                import uuid as uuid_module

                uuid_module.UUID(workflow_id)
                workflow = AiWorkflow.objects.get(id=workflow_id, project=project)
            except (ValueError, AiWorkflow.DoesNotExist):
                workflow = AiWorkflow.objects.filter(slug=workflow_id, project=project).first()

            if not workflow:
                return ctx.error("WorkflowRun", f"Workflow not found: {workflow_id}")

            # Create run record
            run = AiWorkflowRun.objects.create(
                workflow=workflow,
                user=user,
                status="running",
                started_at=timezone.now(),
                input_data=input_data,
            )

            # Execute steps
            variables = {"input": input_data}
            step_results = []

            for i, step in enumerate(workflow.steps):
                run.current_step = i
                run.save(update_fields=["current_step"])

                tool_name = step.get("tool")
                step_args = step.get("args", {})
                output_var = step.get("output_var", f"step_{i}")

                # Substitute variables in args
                resolved_args = {}
                for key, value in step_args.items():
                    if isinstance(value, str) and value.startswith("$"):
                        var_name = value[1:]
                        resolved_args[key] = variables.get(var_name, value)
                    else:
                        resolved_args[key] = value

                # Find and execute tool
                # This is a simplified implementation - in production would use tool registry
                step_result = {
                    "step": i,
                    "tool": tool_name,
                    "args": resolved_args,
                    "status": "completed",
                    "output": f"Executed {tool_name}",
                }

                step_results.append(step_result)
                variables[output_var] = step_result.get("output")

            # Update run record
            run.status = "completed"
            run.completed_at = timezone.now()
            run.step_results = step_results
            run.output_data = variables
            run.save()

            # Update workflow stats
            workflow.run_count += 1
            workflow.last_run = timezone.now()
            workflow.save(update_fields=["run_count", "last_run"])

            ctx.tool_result(
                summary="Completed",
                stats={"run_id": str(run.id), "steps_completed": len(step_results)},
            )

            result = f"Workflow '{workflow.name}' completed successfully.\n\n"
            result += f"Run ID: {run.id}\n"
            result += f"Steps completed: {len(step_results)}\n\n"

            for sr in step_results:
                result += f"Step {sr['step'] + 1}: {sr['tool']} - {sr['status']}\n"

            return ctx.success(result)

        except Exception as e:
            logger.exception("Workflow run failed")

            if "run" in locals():
                run.status = "failed"
                run.error_message = str(e)
                run.completed_at = timezone.now()
                run.save()

            ctx.tool_result(summary="Error")
            return ctx.error("WorkflowRun", f"Error: {e}")

    @tool(
        "workflow_list",
        "List available workflows in the current project.",
        {},
    )
    async def workflow_list(args: dict[str, Any]) -> dict[str, Any]:
        """List workflows."""
        from ainstein.models import AiWorkflow

        ctx.tool_start("WorkflowList", "Listing workflows", {})

        try:
            project = ctx.project

            if not project:
                return ctx.error("WorkflowList", "No project selected")

            workflows = AiWorkflow.objects.filter(project=project, is_active=True)

            if not workflows.exists():
                return ctx.success("No workflows found in this project.")

            result = "# Workflows\n\n"
            for wf in workflows:
                result += f"## {wf.name}\n"
                result += f"- ID: `{wf.id}`\n"
                result += f"- Steps: {len(wf.steps)}\n"
                result += f"- Trigger: {wf.trigger}\n"
                result += f"- Run count: {wf.run_count}\n"
                if wf.description:
                    result += f"- Description: {wf.description[:100]}\n"
                result += "\n"

            ctx.tool_result(summary=f"{workflows.count()} workflows")
            return ctx.success(result)

        except Exception as e:
            logger.exception("Workflow list failed")
            ctx.tool_result(summary="Error")
            return ctx.error("WorkflowList", f"Error: {e}")

    return [script_save, script_list, script_run, workflow_create, workflow_run, workflow_list]
