"""
Integration tests for Phase 9 features.

Tests cover:
- 9.1 Data Visualization
- 9.2 Workflow Automation
- 9.3 Advanced File Handling
- 9.4 Multi-Model Support
- 9.6 Security Enhancements
"""

from decimal import Decimal
from unittest.mock import MagicMock

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.utils import timezone

from ainstein.conf import get_settings
from ainstein.models import (
    AiAuditLog,
    AiCodeExecution,
    AiConversation,
    AiCostLimit,
    AiProject,
    AiRateLimitTracker,
    AiScript,
    AiVisualization,
    AiWorkflow,
    AiWorkflowRun,
)
from ainstein.tools import (
    ADVANCED_EXPORT_TOOL_NAMES,
    ALL_TOOL_NAMES,
    MODEL_ROUTING_TOOL_NAMES,
    SECURITY_TOOL_NAMES,
    VISUALIZATION_TOOL_NAMES,
    WORKFLOW_TOOL_NAMES,
    create_all_tools,
)
from ainstein.tools.advanced_export import create_advanced_export_tools
from ainstein.tools.base import ToolContext
from ainstein.tools.model_routing import (
    AVAILABLE_MODELS,
    TASK_MODEL_ROUTING,
    create_model_routing_tools,
    estimate_cost,
    recommend_model,
)
from ainstein.tools.security import create_security_tools, detect_sensitive_data
from ainstein.tools.visualization import create_visualization_tools
from ainstein.tools.workflow import create_workflow_tools


User = get_user_model()


class Phase9ModelTests(TestCase):
    """Tests for Phase 9 Django models."""

    @classmethod
    def setUpTestData(cls):
        cls.user = User.objects.create_user(username="testuser", password="testpass")
        cls.project = AiProject.objects.create(
            name="Test Project",
            slug="test-project",
            user=cls.user,
        )
        cls.conversation = AiConversation.objects.create(
            user=cls.user,
            project=cls.project,
            title="Test Conversation",
        )

    # =========================================================================
    # 9.2 Workflow Automation Model Tests
    # =========================================================================

    def test_script_creation(self):
        """Test AiScript model creation."""
        script = AiScript.objects.create(
            name="Test Script",
            slug="test-script",
            code="print('Hello World')",
            description="A test script",
            user=self.user,
            project=self.project,
            tags=["test", "demo"],
        )
        self.assertEqual(script.name, "Test Script")
        self.assertEqual(script.version, 1)
        self.assertEqual(script.tags, ["test", "demo"])

    def test_script_versioning(self):
        """Test AiScript version creation."""
        script = AiScript.objects.create(
            name="Versioned Script",
            slug="versioned-script",
            code="# Version 1",
            user=self.user,
        )

        # Create new version
        new_version = script.create_new_version("# Version 2", "Updated description")

        self.assertEqual(new_version.version, 2)
        self.assertEqual(new_version.code, "# Version 2")
        self.assertEqual(new_version.slug, script.slug)

    def test_script_get_latest_version(self):
        """Test getting latest version of a script."""
        for i in range(1, 4):
            AiScript.objects.create(
                name="Multi Version",
                slug="multi-version",
                code=f"# Version {i}",
                version=i,
                user=self.user,
            )

        latest = AiScript.get_latest_version(self.user, "multi-version")
        self.assertEqual(latest.version, 3)

    def test_workflow_creation(self):
        """Test AiWorkflow model creation."""
        workflow = AiWorkflow.objects.create(
            name="Test Workflow",
            slug="test-workflow",
            description="A test workflow",
            user=self.user,
            project=self.project,
            steps=[
                {"tool": "storage_read", "args": {"path": "test.txt"}, "output_var": "data"},
                {"tool": "remote_code_execution", "args": {"code": "print(data)"}, "output_var": "result"},
            ],
            trigger="manual",
        )
        self.assertEqual(workflow.name, "Test Workflow")
        self.assertEqual(len(workflow.steps), 2)
        self.assertEqual(workflow.run_count, 0)

    def test_workflow_run_creation(self):
        """Test AiWorkflowRun model creation."""
        workflow = AiWorkflow.objects.create(
            name="Run Test Workflow",
            slug="run-test-workflow",
            user=self.user,
            project=self.project,
            steps=[{"tool": "test", "args": {}}],
        )

        run = AiWorkflowRun.objects.create(
            workflow=workflow,
            user=self.user,
            status="running",
            started_at=timezone.now(),
            input_data={"key": "value"},
        )

        self.assertEqual(run.status, "running")
        self.assertEqual(run.input_data, {"key": "value"})

    # =========================================================================
    # 9.6 Security Enhancement Model Tests
    # =========================================================================

    def test_audit_log_creation(self):
        """Test AiAuditLog model creation."""
        log = AiAuditLog.log(
            action="tool_call",
            user=self.user,
            project=self.project,
            tool_name="storage_read",
            description="Read file test.txt",
            request_data={"path": "test.txt"},
            response_summary="Read 100 bytes",
            success=True,
            duration_ms=50,
        )

        self.assertEqual(log.action, "tool_call")
        self.assertEqual(log.tool_name, "storage_read")
        self.assertTrue(log.success)
        self.assertEqual(log.duration_ms, 50)

    def test_audit_log_with_sensitive_data(self):
        """Test audit log with sensitive data flag."""
        log = AiAuditLog.log(
            action="file_read",
            user=self.user,
            tool_name="storage_read",
            contains_sensitive_data=True,
        )
        self.assertTrue(log.contains_sensitive_data)

    def test_rate_limit_tracker(self):
        """Test AiRateLimitTracker model."""
        tracker = AiRateLimitTracker.get_or_create_for_user(self.user)

        # Check initial state
        self.assertEqual(tracker.request_count, 0)
        self.assertEqual(tracker.token_count, 0)

    def test_rate_limit_check_and_increment(self):
        """Test rate limit checking and incrementing."""
        tracker = AiRateLimitTracker.get_or_create_for_user(self.user)

        # Should allow first request
        allowed, reason = tracker.check_and_increment(tokens=100)
        self.assertTrue(allowed)
        self.assertEqual(reason, "")
        self.assertEqual(tracker.request_count, 1)
        self.assertEqual(tracker.token_count, 100)

    def test_cost_limit_creation(self):
        """Test AiCostLimit model creation."""
        cost_limit = AiCostLimit.get_or_create_for_project(self.project)

        self.assertEqual(cost_limit.daily_limit, Decimal("10.00"))
        self.assertEqual(cost_limit.monthly_limit, Decimal("100.00"))
        self.assertEqual(cost_limit.daily_usage, Decimal("0"))

    def test_cost_limit_check_and_add(self):
        """Test cost limit checking and adding."""
        cost_limit = AiCostLimit.get_or_create_for_project(self.project)

        # Should allow cost within limits
        allowed, reason = cost_limit.check_and_add_cost(Decimal("1.00"))
        self.assertTrue(allowed)
        self.assertEqual(cost_limit.daily_usage, Decimal("1.00"))
        self.assertEqual(cost_limit.monthly_usage, Decimal("1.00"))
        self.assertEqual(cost_limit.total_usage, Decimal("1.00"))

    def test_cost_limit_exceeded(self):
        """Test cost limit being exceeded."""
        cost_limit = AiCostLimit.objects.create(
            project=AiProject.objects.create(
                name="Limited Project",
                slug="limited-project",
                user=self.user,
            ),
            daily_limit=Decimal("1.00"),
            monthly_limit=Decimal("10.00"),
        )

        # First cost should succeed
        allowed, _ = cost_limit.check_and_add_cost(Decimal("0.50"))
        self.assertTrue(allowed)

        # Second cost should fail (would exceed daily limit)
        allowed, reason = cost_limit.check_and_add_cost(Decimal("0.60"))
        self.assertFalse(allowed)
        self.assertIn("Daily cost limit exceeded", reason)

    # =========================================================================
    # 9.1 Data Visualization Model Tests
    # =========================================================================

    def test_visualization_creation(self):
        """Test AiVisualization model creation."""
        viz = AiVisualization.objects.create(
            project=self.project,
            conversation=self.conversation,
            title="Sales Chart",
            description="Monthly sales data",
            chart_type="bar",
            image_path="charts/sales_chart.png",
            source_code="plt.bar(x, y)",
            data_summary={"rows": 100, "columns": ["month", "sales"]},
        )

        self.assertEqual(viz.title, "Sales Chart")
        self.assertEqual(viz.chart_type, "bar")
        self.assertEqual(viz.data_summary["rows"], 100)

    # =========================================================================
    # Code Execution Model Tests
    # =========================================================================

    def test_code_execution_creation(self):
        """Test AiCodeExecution model creation."""
        execution = AiCodeExecution.objects.create(
            conversation=self.conversation,
            code="print('Hello World')",
            language="python",
            purpose="Test execution",
        )

        self.assertEqual(execution.code, "print('Hello World')")
        self.assertEqual(execution.language, "python")
        self.assertEqual(execution.status, "pending")
        self.assertFalse(execution.is_complete)

    def test_code_execution_mark_running(self):
        """Test marking execution as running."""
        execution = AiCodeExecution.objects.create(
            conversation=self.conversation,
            code="print('test')",
        )

        execution.mark_running()

        self.assertEqual(execution.status, "running")
        self.assertIsNotNone(execution.started_at)

    def test_code_execution_mark_completed(self):
        """Test marking execution as completed."""
        execution = AiCodeExecution.objects.create(
            conversation=self.conversation,
            code="print('test')",
        )
        execution.mark_running()

        execution.mark_completed(
            stdout="Hello World\n",
            generated_files=[{"filename": "output.png", "path": "output.png", "size": 1024}],
        )

        self.assertEqual(execution.status, "completed")
        self.assertTrue(execution.is_complete)
        self.assertIsNotNone(execution.completed_at)
        self.assertEqual(execution.stdout, "Hello World\n")
        self.assertEqual(len(execution.generated_files), 1)
        self.assertGreater(execution.duration_ms, 0)

    def test_code_execution_mark_failed(self):
        """Test marking execution as failed."""
        execution = AiCodeExecution.objects.create(
            conversation=self.conversation,
            code="raise Exception('error')",
        )
        execution.mark_running()

        execution.mark_failed(
            error_message="Exception: error",
            stderr="Traceback...",
        )

        self.assertEqual(execution.status, "failed")
        self.assertTrue(execution.is_complete)
        self.assertEqual(execution.error_message, "Exception: error")
        self.assertEqual(execution.stderr, "Traceback...")

    def test_code_execution_add_generated_file(self):
        """Test adding generated files."""
        execution = AiCodeExecution.objects.create(
            conversation=self.conversation,
            code="# generate file",
        )

        execution.add_generated_file("chart.png", "charts/chart.png", 2048)

        self.assertEqual(len(execution.generated_files), 1)
        self.assertEqual(execution.generated_files[0]["filename"], "chart.png")
        self.assertEqual(execution.generated_files[0]["mime_type"], "image/png")

    def test_code_execution_guess_mime_type(self):
        """Test MIME type guessing."""
        self.assertEqual(AiCodeExecution.guess_mime_type("chart.png"), "image/png")
        self.assertEqual(AiCodeExecution.guess_mime_type("data.csv"), "text/csv")
        self.assertEqual(AiCodeExecution.guess_mime_type("report.pdf"), "application/pdf")
        self.assertEqual(AiCodeExecution.guess_mime_type("unknown.xyz"), "application/octet-stream")


class ModelRoutingTests(TestCase):
    """Tests for Phase 9.4 Multi-Model Support."""

    def test_available_models_structure(self):
        """Test AVAILABLE_MODELS has correct structure."""
        required_keys = [
            "name",
            "tier",
            "context_window",
            "max_output",
            "input_cost_per_mtok",
            "output_cost_per_mtok",
            "capabilities",
            "best_for",
            "speed",
        ]

        for model_id, info in AVAILABLE_MODELS.items():
            for key in required_keys:
                self.assertIn(key, info, f"Model {model_id} missing key {key}")

    def test_estimate_cost(self):
        """Test cost estimation for different models."""
        # Test Haiku (cheapest)
        haiku_cost = estimate_cost("claude-haiku-4-5-20251001", 1000, 1000)
        self.assertGreater(haiku_cost, 0)

        # Test Sonnet (mid-tier)
        sonnet_cost = estimate_cost("claude-sonnet-4-5-20250929", 1000, 1000)
        self.assertGreater(sonnet_cost, haiku_cost)

        # Test Opus (most expensive)
        opus_cost = estimate_cost("claude-opus-4-5-20251101", 1000, 1000)
        self.assertGreater(opus_cost, sonnet_cost)

    def test_estimate_cost_unknown_model(self):
        """Test cost estimation returns 0 for unknown model."""
        cost = estimate_cost("unknown-model", 1000, 1000)
        self.assertEqual(cost, 0.0)

    def test_recommend_model_by_task(self):
        """Test model recommendations for different task types."""
        # Code execution should recommend Haiku
        model = recommend_model("code_execution")
        self.assertEqual(model, "claude-haiku-4-5-20251001")

        # Complex analysis should recommend Opus
        model = recommend_model("complex_analysis")
        self.assertEqual(model, "claude-opus-4-5-20251101")

        # Code review should recommend Sonnet
        model = recommend_model("code_review")
        self.assertEqual(model, "claude-sonnet-4-5-20250929")

    def test_recommend_model_cost_priority(self):
        """Test model recommendation with cost priority."""
        # Cost priority should always recommend Haiku
        model = recommend_model("complex_analysis", priority="cost")
        self.assertEqual(model, "claude-haiku-4-5-20251001")

    def test_recommend_model_quality_priority(self):
        """Test model recommendation with quality priority."""
        # Quality priority for complex tasks should recommend Opus
        model = recommend_model("complex_analysis", priority="quality")
        self.assertEqual(model, "claude-opus-4-5-20251101")

        # Quality priority for simple tasks should recommend Sonnet
        model = recommend_model("simple_query", priority="quality")
        self.assertEqual(model, "claude-sonnet-4-5-20250929")

    def test_task_model_routing_completeness(self):
        """Test all task types have valid model mappings."""
        for task_type, model_id in TASK_MODEL_ROUTING.items():
            self.assertIn(
                model_id,
                AVAILABLE_MODELS,
                f"Task '{task_type}' mapped to unknown model '{model_id}'",
            )


class SecurityDetectionTests(TestCase):
    """Tests for Phase 9.6 sensitive data detection."""

    def get_types_found(self, matches):
        """Helper to get types from detect_sensitive_data results."""
        return [m["type"] for m in matches]

    def test_email_detection(self):
        """Test email pattern detection."""
        text = "Contact us at test@example.com for more info."
        matches = detect_sensitive_data(text)
        types = self.get_types_found(matches)

        self.assertIn("email", types)
        email_match = next(m for m in matches if m["type"] == "email")
        self.assertEqual(email_match["count"], 1)

    def test_phone_detection(self):
        """Test phone number pattern detection."""
        text = "Call us at 555-123-4567 or 555-987-6543."
        matches = detect_sensitive_data(text)
        types = self.get_types_found(matches)

        self.assertIn("phone", types)

    def test_ssn_detection(self):
        """Test SSN pattern detection."""
        text = "SSN: 123-45-6789"
        matches = detect_sensitive_data(text)
        types = self.get_types_found(matches)

        self.assertIn("ssn", types)
        ssn_match = next(m for m in matches if m["type"] == "ssn")
        self.assertEqual(ssn_match["count"], 1)

    def test_credit_card_detection(self):
        """Test credit card pattern detection."""
        text = "Card number: 4111 1111 1111 1111"
        matches = detect_sensitive_data(text)
        types = self.get_types_found(matches)

        self.assertIn("credit_card", types)

    def test_api_key_detection(self):
        """Test API key pattern detection."""
        # Pattern requires sk-/pk_/rk_ prefix with 20+ chars after
        text = "API_KEY=sk-live1234567890abcdefghij"
        matches = detect_sensitive_data(text)
        types = self.get_types_found(matches)

        self.assertIn("api_key", types)

    def test_password_detection(self):
        """Test password pattern detection."""
        text = 'password="secret123"'
        matches = detect_sensitive_data(text)
        types = self.get_types_found(matches)

        self.assertIn("password", types)

    def test_auth_token_detection(self):
        """Test authentication token detection."""
        text = "Authorization: Bearer abc123xyz456token"
        matches = detect_sensitive_data(text)
        types = self.get_types_found(matches)

        self.assertIn("auth_token", types)

    def test_no_false_positives(self):
        """Test that normal text doesn't trigger detection."""
        text = "This is a normal sentence without any sensitive information."
        matches = detect_sensitive_data(text)

        self.assertEqual(len(matches), 0)


class ConfigurationTests(TestCase):
    """Tests for Phase 9 configuration settings."""

    def test_rate_limit_settings_exist(self):
        """Test rate limit settings are present."""
        settings = get_settings()
        self.assertTrue(hasattr(settings, "RATE_LIMIT_ENABLED"))
        self.assertTrue(hasattr(settings, "RATE_LIMIT_WINDOW_SECONDS"))
        self.assertTrue(hasattr(settings, "RATE_LIMIT_MAX_REQUESTS"))
        self.assertTrue(hasattr(settings, "RATE_LIMIT_MAX_TOKENS"))

    def test_cost_limit_settings_exist(self):
        """Test cost limit settings are present."""
        settings = get_settings()
        self.assertTrue(hasattr(settings, "COST_LIMIT_ENABLED"))
        self.assertTrue(hasattr(settings, "DEFAULT_DAILY_COST_LIMIT"))
        self.assertTrue(hasattr(settings, "DEFAULT_MONTHLY_COST_LIMIT"))

    def test_audit_log_settings_exist(self):
        """Test audit log settings are present."""
        settings = get_settings()
        self.assertTrue(hasattr(settings, "AUDIT_LOG_ENABLED"))
        self.assertTrue(hasattr(settings, "AUDIT_LOG_RETENTION_DAYS"))

    def test_visualization_settings_exist(self):
        """Test visualization settings are present."""
        settings = get_settings()
        self.assertTrue(hasattr(settings, "CHART_DEFAULT_DPI"))
        self.assertTrue(hasattr(settings, "CHART_MAX_DATA_POINTS"))

    def test_multi_model_settings_exist(self):
        """Test multi-model settings are present."""
        settings = get_settings()
        self.assertTrue(hasattr(settings, "DEFAULT_MODEL_PRIORITY"))
        self.assertTrue(hasattr(settings, "AUTO_MODEL_ROUTING"))

    def test_settings_validation(self):
        """Test settings validation works."""
        settings = get_settings()
        errors = settings.validate()
        # Should only fail on missing API key in test environment
        self.assertTrue(len(errors) == 0 or all("ANTHROPIC_API_KEY" in e for e in errors))


class ToolIntegrationTests(TestCase):
    """Integration tests for Phase 9 tools."""

    @classmethod
    def setUpTestData(cls):
        cls.user = User.objects.create_user(username="tooluser", password="testpass")
        cls.project = AiProject.objects.create(
            name="Tool Test Project",
            slug="tool-test-project",
            user=cls.user,
        )

    def create_mock_context(self):
        """Create a mock ToolContext for testing."""
        mock_service = MagicMock()
        mock_service.user = self.user
        mock_service.project = self.project

        mock_storage = MagicMock()
        mock_storage.exists.return_value = True
        mock_storage.open.return_value.__enter__ = MagicMock(return_value=MagicMock(read=lambda: b"test data"))
        mock_storage.open.return_value.__exit__ = MagicMock(return_value=False)

        ctx = MagicMock(spec=ToolContext)
        ctx.service = mock_service
        ctx.storage = mock_storage
        ctx.project_folder = f"projects/{self.project.external_id}"
        ctx.resolve_path = lambda p: f"{ctx.project_folder}/{p}"
        ctx.is_cancelled.return_value = False
        ctx.success = lambda msg: {"is_error": False, "content": [{"type": "text", "text": msg}]}
        ctx.error = lambda name, msg: {"is_error": True, "content": [{"type": "text", "text": f"Error: {msg}"}]}
        ctx.tool_start = MagicMock()
        ctx.tool_result = MagicMock()

        return ctx

    def test_model_routing_tools_creation(self):
        """Test model routing tools can be created."""
        ctx = self.create_mock_context()
        tools = create_model_routing_tools(ctx)

        self.assertEqual(len(tools), 4)
        tool_names = [t.name for t in tools]
        self.assertIn("list_models", tool_names)
        self.assertIn("recommend_model", tool_names)
        self.assertIn("estimate_cost", tool_names)
        self.assertIn("set_model_preference", tool_names)

    def test_security_tools_creation(self):
        """Test security tools can be created."""
        ctx = self.create_mock_context()
        tools = create_security_tools(ctx)

        self.assertEqual(len(tools), 6)
        tool_names = [t.name for t in tools]
        self.assertIn("audit_log_query", tool_names)
        self.assertIn("check_rate_limit", tool_names)
        self.assertIn("check_cost_limit", tool_names)
        self.assertIn("set_cost_limit", tool_names)
        self.assertIn("scan_sensitive_data", tool_names)
        self.assertIn("security_report", tool_names)

    def test_visualization_tools_creation(self):
        """Test visualization tools can be created."""
        ctx = self.create_mock_context()
        tools = create_visualization_tools(ctx)

        self.assertEqual(len(tools), 3)
        tool_names = [t.name for t in tools]
        self.assertIn("create_chart", tool_names)
        self.assertIn("list_chart_types", tool_names)
        self.assertIn("quick_chart", tool_names)

    def test_workflow_tools_creation(self):
        """Test workflow tools can be created."""
        ctx = self.create_mock_context()
        tools = create_workflow_tools(ctx)

        self.assertEqual(len(tools), 6)
        tool_names = [t.name for t in tools]
        self.assertIn("script_save", tool_names)
        self.assertIn("script_list", tool_names)
        self.assertIn("script_run", tool_names)
        self.assertIn("workflow_create", tool_names)
        self.assertIn("workflow_run", tool_names)
        self.assertIn("workflow_list", tool_names)

    def test_advanced_export_tools_creation(self):
        """Test advanced export tools can be created."""
        ctx = self.create_mock_context()
        tools = create_advanced_export_tools(ctx)

        self.assertEqual(len(tools), 4)
        tool_names = [t.name for t in tools]
        self.assertIn("export_excel", tool_names)
        self.assertIn("export_pdf", tool_names)
        self.assertIn("process_image", tool_names)
        self.assertIn("convert_data_format", tool_names)


class AllToolsRegistrationTests(TestCase):
    """Test that all Phase 9 tools are properly registered."""

    def test_all_tools_exported(self):
        """Test all Phase 9 tool names are in ALL_TOOL_NAMES."""
        # Check all Phase 9 tool names are included
        for name in VISUALIZATION_TOOL_NAMES:
            self.assertIn(name, ALL_TOOL_NAMES, f"Missing {name} from ALL_TOOL_NAMES")

        for name in WORKFLOW_TOOL_NAMES:
            self.assertIn(name, ALL_TOOL_NAMES, f"Missing {name} from ALL_TOOL_NAMES")

        for name in ADVANCED_EXPORT_TOOL_NAMES:
            self.assertIn(name, ALL_TOOL_NAMES, f"Missing {name} from ALL_TOOL_NAMES")

        for name in SECURITY_TOOL_NAMES:
            self.assertIn(name, ALL_TOOL_NAMES, f"Missing {name} from ALL_TOOL_NAMES")

        for name in MODEL_ROUTING_TOOL_NAMES:
            self.assertIn(name, ALL_TOOL_NAMES, f"Missing {name} from ALL_TOOL_NAMES")

    def test_create_all_tools_includes_phase9(self):
        """Test create_all_tools includes Phase 9 tools."""
        # Create minimal mock context
        ctx = MagicMock()
        ctx.service = MagicMock()
        ctx.user = MagicMock()
        ctx.project = MagicMock()
        ctx.conversation = MagicMock()
        ctx.storage = MagicMock()
        ctx.project_folder = "test"
        ctx.resolve_path = lambda p: f"test/{p}"
        ctx.is_cancelled.return_value = False
        ctx.success = lambda msg: {"is_error": False, "content": [{"type": "text", "text": msg}]}
        ctx.error = lambda name, msg: {"is_error": True, "content": [{"type": "text", "text": msg}]}
        ctx.tool_start = MagicMock()
        ctx.tool_result = MagicMock()

        tools = create_all_tools(ctx)
        tool_names = [t.name for t in tools]

        # Verify Phase 9 tools are present
        self.assertIn("create_chart", tool_names)
        self.assertIn("script_save", tool_names)
        self.assertIn("export_excel", tool_names)
        self.assertIn("audit_log_query", tool_names)
        self.assertIn("list_models", tool_names)
