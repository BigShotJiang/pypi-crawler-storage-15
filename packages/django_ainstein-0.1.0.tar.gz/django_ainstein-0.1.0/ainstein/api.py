"""
Insight Agent API Router

Dedicated router for Insight Agent with cookie-based authentication.
"""

from rest_framework import routers

from ainstein.views import (
    AgentStreamViewSet,
    AiConversationViewSet,
    AiProjectViewSet,
)


# Create and configure the router
ainstein_router = routers.DefaultRouter()
ainstein_router.register(r"conversations", AiConversationViewSet, basename="aiconversation")
ainstein_router.register(r"projects", AiProjectViewSet, basename="aiproject")
ainstein_router.register(r"stream", AgentStreamViewSet, basename="agent-stream")
