"""
Django Model Registry - Singleton cache for model metadata.

This registry caches Django model information (models, fields, relationships)
at process startup. Used to provide "bearings" to AI agents - environmental
context about available data models for business intelligence discovery.

Reference: https://www.anthropic.com/engineering/effective-harnesses-for-long-running-agents
"""

import logging
import threading
from dataclasses import dataclass, field
from typing import Optional

from django.apps import apps


logger = logging.getLogger(__name__)


@dataclass
class FieldInfo:
    """Information about a Django model field."""

    name: str
    field_type: str
    max_length: int | None = None
    nullable: bool = False
    related_to: str | None = None
    is_primary_key: bool = False
    is_foreign_key: bool = False
    help_text: str = ""


@dataclass
class ModelInfo:
    """Information about a Django model."""

    app_label: str
    model_name: str
    table_name: str
    verbose_name: str
    verbose_name_plural: str
    fields: list[FieldInfo] = field(default_factory=list)
    row_count: int | None = None

    @property
    def full_name(self) -> str:
        return f"{self.app_label}.{self.model_name}"


class DjangoModelRegistry:
    """
    Singleton registry that caches Django model metadata.

    Thread-safe singleton that loads and caches all model information
    on first access. Provides fast lookups for model and field info
    without repeated Django introspection.

    Usage:
        registry = DjangoModelRegistry()
        models = registry.list_models()
        fields = registry.describe_model("jobs", "company")
        bearings = registry.get_bearings()
    """

    _instance: Optional["DjangoModelRegistry"] = None
    _lock = threading.Lock()
    _initialized = False

    def __new__(cls) -> "DjangoModelRegistry":
        if cls._instance is None:
            with cls._lock:
                # Double-check locking pattern
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        # Only initialize once
        if DjangoModelRegistry._initialized:
            return

        with DjangoModelRegistry._lock:
            if DjangoModelRegistry._initialized:
                return

            self.models: dict[str, ModelInfo] = {}
            self.app_labels: set[str] = set()
            self._load_models()
            DjangoModelRegistry._initialized = True

    def _load_models(self) -> None:
        """Load all Django models into the cache."""
        logger.info("DjangoModelRegistry: Loading models into cache...")
        for model in apps.get_models():
            meta = model._meta
            app_label = meta.app_label
            model_name = meta.model_name

            # Skip Django internal models
            if app_label in ("contenttypes", "sessions", "admin"):
                continue

            self.app_labels.add(app_label)

            # Extract field information
            fields = []
            for django_field in meta.get_fields():
                field_info = FieldInfo(
                    name=django_field.name,
                    field_type=django_field.__class__.__name__,
                )

                # Optional attributes
                if hasattr(django_field, "max_length") and django_field.max_length:
                    field_info.max_length = django_field.max_length

                if hasattr(django_field, "null"):
                    field_info.nullable = django_field.null

                if hasattr(django_field, "primary_key"):
                    field_info.is_primary_key = django_field.primary_key

                if hasattr(django_field, "help_text") and django_field.help_text:
                    field_info.help_text = str(django_field.help_text)

                if hasattr(django_field, "related_model") and django_field.related_model:
                    related_meta = django_field.related_model._meta
                    field_info.related_to = f"{related_meta.app_label}.{related_meta.model_name}"
                    field_info.is_foreign_key = True

                fields.append(field_info)

            model_info = ModelInfo(
                app_label=app_label,
                model_name=model_name,
                table_name=meta.db_table,
                verbose_name=str(meta.verbose_name),
                verbose_name_plural=str(meta.verbose_name_plural),
                fields=fields,
            )

            self.models[f"{app_label}.{model_name}"] = model_info

        logger.info(f"DjangoModelRegistry: Cached {len(self.models)} models from {len(self.app_labels)} apps")

    def list_models(self, app_label: str | None = None) -> list[ModelInfo]:
        """
        List all cached models, optionally filtered by app label.

        Args:
            app_label: Optional app label to filter by

        Returns:
            List of ModelInfo objects
        """
        if app_label:
            result = [m for m in self.models.values() if m.app_label == app_label]
            logger.debug(f"DjangoModelRegistry: Cache hit - list_models(app={app_label}) -> {len(result)} models")
            return result
        logger.debug(f"DjangoModelRegistry: Cache hit - list_models() -> {len(self.models)} models")
        return list(self.models.values())

    def describe_model(self, app_label: str, model_name: str) -> ModelInfo | None:
        """
        Get detailed information about a specific model.

        Args:
            app_label: The Django app label
            model_name: The model name

        Returns:
            ModelInfo object or None if not found
        """
        key = f"{app_label}.{model_name}"
        result = self.models.get(key)
        if result:
            logger.debug(f"DjangoModelRegistry: Cache hit - describe_model({key}) -> {len(result.fields)} fields")
        else:
            logger.debug(f"DjangoModelRegistry: Cache miss - describe_model({key})")
        return result

    def get_model_count(self, app_label: str, model_name: str) -> int | None:
        """
        Get live row count for a model (not cached).

        Args:
            app_label: The Django app label
            model_name: The model name

        Returns:
            Row count or None if model not found
        """
        try:
            model = apps.get_model(app_label, model_name)
            return model.objects.count()
        except LookupError:
            return None

    def get_bearings(self, app_labels: list[str] | None = None) -> str:
        """
        Generate "bearings" text for AI agent system prompts.

        Bearings provide environmental context about available data models,
        helping agents understand what business data they can query.

        Args:
            app_labels: Optional list of app labels to include. If None, uses
                       a default set of business-relevant apps.

        Returns:
            Formatted markdown string describing available models
        """
        # Default to business-relevant apps if not specified
        if app_labels is None:
            app_labels = ["jobs", "products", "compare", "rlsbb", "que"]

        # Filter to only requested apps that exist
        relevant_apps = [a for a in app_labels if a in self.app_labels]

        if not relevant_apps:
            return "No business models available."

        lines = ["## Available Data Models", ""]

        for app in sorted(relevant_apps):
            app_models = self.list_models(app)
            if not app_models:
                continue

            lines.append(f"### {app.title()} App")
            lines.append("")

            for model in sorted(app_models, key=lambda m: m.model_name):
                # Get key fields (exclude reverse relations and internal fields)
                key_fields = [f for f in model.fields if not f.field_type.endswith("Rel") and f.name != "id"][
                    :8
                ]  # Limit to 8 most important fields

                field_names = ", ".join(f.name for f in key_fields)
                lines.append(f"- **{model.model_name}** ({model.verbose_name}): {field_names}")

            lines.append("")

        return "\n".join(lines)

    def get_relationships(self) -> list[dict]:
        """
        Get all foreign key relationships between models.

        Returns:
            List of relationship dictionaries with from_model, to_model, field
        """
        relationships = []
        for model_info in self.models.values():
            for field_info in model_info.fields:
                if field_info.is_foreign_key and field_info.related_to:
                    relationships.append(
                        {
                            "from_model": model_info.full_name,
                            "to_model": field_info.related_to,
                            "field": field_info.name,
                        }
                    )
        return relationships

    def to_dict(self, app_label: str | None = None) -> dict:
        """
        Export registry to dictionary format.

        Args:
            app_label: Optional app label to filter by

        Returns:
            Dictionary with models and their fields
        """
        models = self.list_models(app_label)
        return {
            "models": [
                {
                    "app": m.app_label,
                    "model": m.model_name,
                    "table": m.table_name,
                    "verbose_name": m.verbose_name,
                    "fields": [
                        {
                            "name": f.name,
                            "type": f.field_type,
                            "nullable": f.nullable,
                            "related_to": f.related_to,
                        }
                        for f in m.fields
                        if not f.field_type.endswith("Rel")  # Exclude reverse relations
                    ],
                }
                for m in models
            ]
        }


# Convenience function to get the singleton instance
def get_model_registry() -> DjangoModelRegistry:
    """Get the singleton DjangoModelRegistry instance."""
    return DjangoModelRegistry()
