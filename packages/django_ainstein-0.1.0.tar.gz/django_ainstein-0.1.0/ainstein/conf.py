"""
Claude Agent Configuration

Settings can be configured in Django settings.py under AINSTEIN dict:

AINSTEIN = {
    "ANTHROPIC_API_KEY": "sk-ant-...",  # Required: Anthropic API key
    "MODEL": "claude-haiku-4-5-20251001",  # Default model for agent
    "CODE_EXECUTION_MODEL": "claude-haiku-4-5-20251001",  # Model for remote code execution
    "MAX_TOKENS": 4096,  # Max tokens per response
    "STORAGE_BACKEND": "agent",  # Django storage backend name
    "MAX_SQL_LIMIT": 1000,  # Max rows for SQL queries
    "SCRIPT_TIMEOUT": 30,  # Default script timeout in seconds
    "SCRIPT_MAX_TIMEOUT": 60,  # Maximum allowed script timeout
    "ALLOWED_SCRIPT_MODULES": ["json", "csv", "math", "datetime", "collections", "re"],
    # SDK built-in tools to allow (Bash/Read/Write/Edit/Glob/Grep disabled - use storage_* instead)
    "SDK_BUILTIN_TOOLS": ["WebFetch", "WebSearch", "Task", "TodoWrite", "NotebookEdit"],
}

Or via environment variables (prefixed with AINSTEIN_):
- AINSTEIN_ANTHROPIC_API_KEY
- AINSTEIN_MODEL
- etc.
"""

import os
from dataclasses import dataclass, field
from typing import Any

from django.conf import settings


@dataclass
class AinsteinSettings:
    """Configuration for Claude Agent app."""

    # API Configuration
    ANTHROPIC_API_KEY: str = ""
    MODEL: str = "claude-haiku-4-5-20251001"
    CODE_EXECUTION_MODEL: str = "claude-haiku-4-5-20251001"  # Model for code_execution_20250825 tool
    MAX_TOKENS: int = 4096

    # Storage Configuration
    STORAGE_BACKEND: str = "agent"

    # Query Limits
    MAX_SQL_LIMIT: int = 1000

    # Script Execution
    SCRIPT_TIMEOUT: int = 30
    SCRIPT_MAX_TIMEOUT: int = 60
    ALLOWED_SCRIPT_MODULES: list = field(
        default_factory=lambda: ["json", "csv", "math", "datetime", "collections", "re"]
    )

    # Export Configuration
    DEFAULT_EXPORT_FORMAT: str = "json"  # "json" or "csv"

    # SDK Built-in Tools
    # Note: Bash/Read/Write/Edit/Glob/Grep disabled - use storage_* tools instead
    SDK_BUILTIN_TOOLS: list = field(
        default_factory=lambda: ["WebFetch", "WebSearch", "Task", "TodoWrite", "NotebookEdit"]
    )

    # Rate Limiting (Phase 9.6)
    RATE_LIMIT_ENABLED: bool = True
    RATE_LIMIT_WINDOW_SECONDS: int = 60  # Sliding window duration
    RATE_LIMIT_MAX_REQUESTS: int = 100  # Max requests per window
    RATE_LIMIT_MAX_TOKENS: int = 500000  # Max tokens per window

    # Cost Limits (Phase 9.6)
    COST_LIMIT_ENABLED: bool = True
    DEFAULT_DAILY_COST_LIMIT: float = 10.0  # USD per day per project
    DEFAULT_MONTHLY_COST_LIMIT: float = 100.0  # USD per month per project

    # Audit Logging (Phase 9.6)
    AUDIT_LOG_ENABLED: bool = True
    AUDIT_LOG_RETENTION_DAYS: int = 90  # Days to retain audit logs

    # Security Scanning (Phase 9.6)
    SENSITIVE_DATA_SCAN_ENABLED: bool = True
    SENSITIVE_DATA_PATTERNS: list = field(
        default_factory=lambda: [
            "email",
            "phone",
            "ssn",
            "credit_card",
            "api_key",
            "password",
            "auth_token",
        ]
    )

    # Visualization (Phase 9.1)
    CHART_DEFAULT_DPI: int = 150
    CHART_MAX_DATA_POINTS: int = 10000

    # Multi-Model (Phase 9.4)
    DEFAULT_MODEL_PRIORITY: str = "balanced"  # "cost", "quality", or "balanced"
    AUTO_MODEL_ROUTING: bool = True

    def __post_init__(self):
        """Load settings from Django settings and environment variables."""
        # Get settings dict from Django settings
        django_settings = getattr(settings, "AINSTEIN", {})

        # For each field, check Django settings first, then env vars
        for field_name in self.__dataclass_fields__:
            # Check Django settings
            if field_name in django_settings:
                setattr(self, field_name, django_settings[field_name])
            else:
                # Check environment variable
                env_key = f"AINSTEIN_{field_name}"
                env_value = os.environ.get(env_key)
                if env_value is not None:
                    # Convert to appropriate type
                    field_type = self.__dataclass_fields__[field_name].type
                    setattr(self, field_name, self._convert_type(env_value, field_type))

    def _convert_type(self, value: str, target_type: Any) -> Any:
        """Convert string value to target type."""
        if target_type is int:
            return int(value)
        if target_type is float:
            return float(value)
        if target_type is bool:
            return value.lower() in ("true", "1", "yes")
        if target_type is list:
            return [x.strip() for x in value.split(",")]
        return value

    def validate(self) -> list[str]:
        """Validate configuration and return list of errors."""
        errors = []

        if not self.ANTHROPIC_API_KEY:
            errors.append(
                "ANTHROPIC_API_KEY is required. Set AINSTEIN['ANTHROPIC_API_KEY'] "
                "in settings.py or AINSTEIN_ANTHROPIC_API_KEY environment variable."
            )

        if self.SCRIPT_TIMEOUT > self.SCRIPT_MAX_TIMEOUT:
            errors.append(
                f"SCRIPT_TIMEOUT ({self.SCRIPT_TIMEOUT}) cannot exceed SCRIPT_MAX_TIMEOUT ({self.SCRIPT_MAX_TIMEOUT})"
            )

        if self.DEFAULT_EXPORT_FORMAT not in ("json", "csv"):
            errors.append(f"DEFAULT_EXPORT_FORMAT must be 'json' or 'csv', got '{self.DEFAULT_EXPORT_FORMAT}'")

        if self.DEFAULT_MODEL_PRIORITY not in ("cost", "quality", "balanced"):
            errors.append(
                f"DEFAULT_MODEL_PRIORITY must be 'cost', 'quality', or 'balanced', got '{self.DEFAULT_MODEL_PRIORITY}'"
            )

        if self.DEFAULT_DAILY_COST_LIMIT < 0:
            errors.append(f"DEFAULT_DAILY_COST_LIMIT must be non-negative, got {self.DEFAULT_DAILY_COST_LIMIT}")

        if self.DEFAULT_MONTHLY_COST_LIMIT < 0:
            errors.append(f"DEFAULT_MONTHLY_COST_LIMIT must be non-negative, got {self.DEFAULT_MONTHLY_COST_LIMIT}")

        return errors

    def is_valid(self) -> bool:
        """Check if configuration is valid."""
        return len(self.validate()) == 0


# Singleton instance - lazy loaded
_settings_instance = None


def get_settings() -> AinsteinSettings:
    """Get the Claude Agent settings singleton."""
    global _settings_instance
    if _settings_instance is None:
        _settings_instance = AinsteinSettings()
    return _settings_instance


def reload_settings() -> AinsteinSettings:
    """Reload settings (useful for testing)."""
    global _settings_instance
    _settings_instance = AinsteinSettings()
    return _settings_instance


# Convenience accessors
def get_anthropic_api_key() -> str:
    """Get the Anthropic API key."""
    return get_settings().ANTHROPIC_API_KEY


def get_model() -> str:
    """Get the default model."""
    return get_settings().MODEL


def get_storage_backend() -> str:
    """Get the storage backend name."""
    return get_settings().STORAGE_BACKEND


def get_max_sql_limit() -> int:
    """Get the maximum SQL query limit."""
    return get_settings().MAX_SQL_LIMIT


def get_code_execution_model() -> str:
    """Get the model for remote code execution (code_execution_20250825 tool)."""
    return get_settings().CODE_EXECUTION_MODEL


def get_sdk_builtin_tools() -> list[str]:
    """Get the list of allowed SDK built-in tools."""
    return get_settings().SDK_BUILTIN_TOOLS


# Phase 9.6 - Security accessors
def is_rate_limit_enabled() -> bool:
    """Check if rate limiting is enabled."""
    return get_settings().RATE_LIMIT_ENABLED


def get_rate_limit_config() -> dict:
    """Get rate limit configuration."""
    s = get_settings()
    return {
        "enabled": s.RATE_LIMIT_ENABLED,
        "window_seconds": s.RATE_LIMIT_WINDOW_SECONDS,
        "max_requests": s.RATE_LIMIT_MAX_REQUESTS,
        "max_tokens": s.RATE_LIMIT_MAX_TOKENS,
    }


def is_cost_limit_enabled() -> bool:
    """Check if cost limiting is enabled."""
    return get_settings().COST_LIMIT_ENABLED


def get_default_cost_limits() -> dict:
    """Get default cost limit configuration."""
    s = get_settings()
    return {
        "daily": s.DEFAULT_DAILY_COST_LIMIT,
        "monthly": s.DEFAULT_MONTHLY_COST_LIMIT,
    }


def is_audit_log_enabled() -> bool:
    """Check if audit logging is enabled."""
    return get_settings().AUDIT_LOG_ENABLED


def get_audit_log_retention_days() -> int:
    """Get audit log retention period in days."""
    return get_settings().AUDIT_LOG_RETENTION_DAYS


def is_sensitive_data_scan_enabled() -> bool:
    """Check if sensitive data scanning is enabled."""
    return get_settings().SENSITIVE_DATA_SCAN_ENABLED


def get_sensitive_data_patterns() -> list[str]:
    """Get list of sensitive data pattern types to scan for."""
    return get_settings().SENSITIVE_DATA_PATTERNS


# Phase 9.4 - Multi-model accessors
def get_default_model_priority() -> str:
    """Get default model selection priority."""
    return get_settings().DEFAULT_MODEL_PRIORITY


def is_auto_model_routing_enabled() -> bool:
    """Check if automatic model routing is enabled."""
    return get_settings().AUTO_MODEL_ROUTING


# Phase 9.1 - Visualization accessors
def get_chart_default_dpi() -> int:
    """Get default DPI for chart images."""
    return get_settings().CHART_DEFAULT_DPI


def get_chart_max_data_points() -> int:
    """Get maximum data points for charts."""
    return get_settings().CHART_MAX_DATA_POINTS
