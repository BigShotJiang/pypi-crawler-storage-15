/// <reference types="vitest/config" />
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react-swc';
import path from 'path';
import { fileURLToPath } from 'node:url';
import { storybookTest } from '@storybook/addon-vitest/vitest-plugin';
import { playwright } from '@vitest/browser-playwright';
import { visualizer } from 'rollup-plugin-visualizer';
const dirname = typeof __dirname !== 'undefined' ? __dirname : path.dirname(fileURLToPath(import.meta.url));

// More info at: https://storybook.js.org/docs/next/writing-tests/integrations/vitest-addon
export default defineConfig({
  plugins: [
    react(),
    visualizer({
      filename: 'bundle-stats.txt',
      template: 'list',
      gzipSize: true,
    }),
  ],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
      // Replace emoji-mart data with empty stub to save ~549KB
      // BlockNote's emoji picker is disabled via emojiPicker: false
      '@emoji-mart/data': path.resolve(__dirname, './src/lib/emoji-mart-stub.ts'),
    }
  },
  build: {
    outDir: '../static/ainstein/dist',
    emptyOutDir: true,
    chunkSizeWarningLimit: 5000,
    minify: 'esbuild',
    rollupOptions: {
      input: {
        main: path.resolve(__dirname, 'index.html')
      },
      output: {
        entryFileNames: 'js/[name].js',
        // Single bundle - admin tool with low traffic
        manualChunks: undefined,
        inlineDynamicImports: true,
        assetFileNames: assetInfo => {
          if (assetInfo.name?.endsWith('.css')) {
            return 'css/[name][extname]';
          }
          return 'assets/[name][extname]';
        }
      }
    }
  },
  base: '/static/ainstein/dist/',
  test: {
    projects: [
      // Unit tests with jsdom
      {
        extends: true,
        test: {
          name: 'unit',
          environment: 'jsdom',
          include: ['src/**/*.test.{ts,tsx}'],
          exclude: ['src/**/*.stories.test.{ts,tsx}'],
          globals: true,
          setupFiles: ['./src/test/setup.ts'],
        }
      },
      // Storybook tests with browser
      {
        extends: true,
        plugins: [
          // The plugin will run tests for the stories defined in your Storybook config
          // See options at: https://storybook.js.org/docs/next/writing-tests/integrations/vitest-addon#storybooktest
          storybookTest({
            configDir: path.join(dirname, '.storybook')
          })
        ],
        test: {
          name: 'storybook',
          browser: {
            enabled: true,
            headless: true,
            provider: playwright({}),
            instances: [{
              browser: 'chromium'
            }]
          },
          setupFiles: ['.storybook/vitest.setup.ts']
        }
      }
    ]
  }
});