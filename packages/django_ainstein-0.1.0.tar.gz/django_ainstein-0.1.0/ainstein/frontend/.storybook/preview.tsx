import React from 'react'
import type { Preview } from '@storybook/react-vite'
import { TooltipProvider } from '../src/components/ui/tooltip'
import '../src/index.css'

const preview: Preview = {
  parameters: {
    controls: {
      matchers: {
        color: /(background|color)$/i,
        date: /Date$/i,
      },
    },
    backgrounds: {
      disable: true,
    },
    layout: 'fullscreen',
  },
  decorators: [
    (Story) => (
      <TooltipProvider>
        <div className="dark bg-background text-foreground min-h-screen p-6">
          <Story />
        </div>
      </TooltipProvider>
    ),
  ],
};

export default preview;
