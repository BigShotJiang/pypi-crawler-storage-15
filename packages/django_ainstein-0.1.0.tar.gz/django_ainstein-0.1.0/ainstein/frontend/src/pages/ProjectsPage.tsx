/**
 * ProjectsPage
 *
 * Main projects dashboard with project list, file tree, file viewer, and conversations.
 */

import { useNavigate } from "react-router-dom";
import { Folder, MessageSquare, Globe, Lock, Sparkles } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  ResizablePanelGroup,
  ResizablePanel,
  ResizableHandle,
} from "@/components/ui/resizable";
import { PromptInputProvider } from "@/components/ai-elements/prompt-input";
import { FileTree } from "@/components/file-tree";
import { FileViewer } from "@/components/editors/FileViewer";
import {
  ProjectGroup,
  ConversationItem,
  ChatInputWithSuggestions,
} from "@/components/projects";
import { useProjects, useProjectConversations, useFiles, useImprovePrompt } from "@/hooks";
import type { Project } from "@/types";

// Storage key for panel sizes
const PANEL_STORAGE_KEY = "projects-panel-sizes";

export function ProjectsPage() {
  const navigate = useNavigate();
  const apiBaseUrl = (window as any).APP_CONFIG?.apiBaseUrl || "/ainstein/v1/";

  // Hooks
  const {
    sharedProjects,
    privateProjects,
    currentProjectId,
    currentProject,
    expandedGroups,
    loading,
    handleSelectProject,
    toggleGroup,
    createProject,
    deleteProject,
  } = useProjects({ apiBaseUrl });

  const {
    conversations,
    isCreatingChat,
    createConversation,
    deleteConversation,
  } = useProjectConversations({ apiBaseUrl, projectId: currentProjectId });

  const {
    files,
    selectedFile,
    fileContent,
    isSelectedDirectory,
    handleSelectFile,
  } = useFiles({ apiBaseUrl, projectId: currentProjectId });

  const { improvePrompt, isImproving } = useImprovePrompt({ apiBaseUrl });

  // Placeholder handlers (TODO: implement modals)
  const handleProjectSettings = (project: Project) => {
    console.log("TODO: Project settings for:", project.name);
  };

  const handleProjectInstructions = (project: Project) => {
    console.log("TODO: Add instructions for:", project.name);
  };

  // Check if there are no projects at all
  const hasNoProjects = !loading && sharedProjects.length === 0 && privateProjects.length === 0;

  // Empty state - show welcome UI when no projects exist
  if (hasNoProjects) {
    return (
      <div className="flex h-screen bg-sidebar" data-testid="projects-page" data-state="empty">
        {/* Left Sidebar - Projects (empty state) */}
        <aside className="w-[232px] bg-sidebar flex flex-col shrink-0">
          <div className="p-5">
            <h1 className="text-lg font-semibold text-accent">django-insight-ai</h1>
          </div>

          <ScrollArea className="flex-1">
            <ProjectGroup
              title="Shared Projects"
              icon={<Globe className="h-3 w-3" />}
              projects={[]}
              currentProjectId={null}
              isExpanded={expandedGroups.shared}
              onToggle={() => toggleGroup("shared")}
              onSelectProject={handleSelectProject}
              onDeleteProject={deleteProject}
              onSettingsProject={handleProjectSettings}
              onInstructionsProject={handleProjectInstructions}
              onCreateProject={(name) => createProject(name, true)}
            />

            <ProjectGroup
              title="My Projects"
              icon={<Lock className="h-3 w-3" />}
              projects={[]}
              currentProjectId={null}
              isExpanded={expandedGroups.private}
              onToggle={() => toggleGroup("private")}
              onSelectProject={handleSelectProject}
              onDeleteProject={deleteProject}
              onSettingsProject={handleProjectSettings}
              onInstructionsProject={handleProjectInstructions}
              onCreateProject={(name) => createProject(name, false)}
            />
          </ScrollArea>
        </aside>

        {/* Welcome Content */}
        <div className="flex-1 flex items-center justify-center p-8">
          <div className="max-w-lg text-center">
            <div className="mb-6">
              <Sparkles className="h-12 w-12 mx-auto text-accent opacity-80" />
            </div>
            <h2 className="text-2xl font-semibold text-foreground mb-3">
              Welcome to Django Insight AI
            </h2>
            <p className="text-muted-foreground mb-8">
              Start a conversation to analyze data, generate visualizations, or get help with your projects.
              A default project will be created automatically.
            </p>
            <div className="max-w-md mx-auto">
              <PromptInputProvider>
                <ChatInputWithSuggestions
                  projectName="New Project"
                  isCreatingChat={isCreatingChat}
                  onSubmit={createConversation}
                  onImprovePrompt={improvePrompt}
                  isImproving={isImproving}
                />
              </PromptInputProvider>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-sidebar" data-testid="projects-page">
      {/* Left Sidebar - Projects */}
      <aside className="w-[232px] bg-sidebar flex flex-col shrink-0" data-testid="projects-sidebar">
        <div className="p-5">
          <h1 className="text-lg font-semibold text-accent">django-insight-ai</h1>
        </div>

        <ScrollArea className="flex-1">
          <ProjectGroup
            title="Shared Projects"
            icon={<Globe className="h-3 w-3" />}
            projects={sharedProjects}
            currentProjectId={currentProjectId}
            isExpanded={expandedGroups.shared}
            onToggle={() => toggleGroup("shared")}
            onSelectProject={handleSelectProject}
            onDeleteProject={deleteProject}
            onSettingsProject={handleProjectSettings}
            onInstructionsProject={handleProjectInstructions}
            onCreateProject={(name) => createProject(name, true)}
          />

          <ProjectGroup
            title="My Projects"
            icon={<Lock className="h-3 w-3" />}
            projects={privateProjects}
            currentProjectId={currentProjectId}
            isExpanded={expandedGroups.private}
            onToggle={() => toggleGroup("private")}
            onSelectProject={handleSelectProject}
            onDeleteProject={deleteProject}
            onSettingsProject={handleProjectSettings}
            onInstructionsProject={handleProjectInstructions}
            onCreateProject={(name) => createProject(name, false)}
          />
        </ScrollArea>
      </aside>

      {/* Content Area */}
      <ResizablePanelGroup
        direction="horizontal"
        autoSaveId={PANEL_STORAGE_KEY}
        className="flex-1 pt-2 pr-2 pb-2"
      >
        {/* File Tree */}
        <ResizablePanel defaultSize={15} minSize={10} maxSize={30}>
          <aside className="h-full bg-card flex flex-col">
            <div className="px-4 py-3 text-[11px] uppercase tracking-wider text-muted-foreground">
              Project Files
            </div>
            <ScrollArea className="flex-1 px-2">
              {currentProject ? (
                files.length > 0 ? (
                  <FileTree
                    files={files}
                    selectedFile={selectedFile}
                    onSelectFile={handleSelectFile}
                  />
                ) : (
                  <div className="text-muted-foreground text-xs p-3 text-center">
                    No files
                  </div>
                )
              ) : (
                <div className="text-muted-foreground text-xs p-3 text-center">
                  Select a project
                </div>
              )}
            </ScrollArea>
          </aside>
        </ResizablePanel>

        <ResizableHandle />

        {/* File Viewer */}
        <ResizablePanel defaultSize={50} minSize={20}>
          <div className="h-full flex flex-col bg-card border-x border-border">
            {currentProjectId && (
              <FileViewer
                filePath={selectedFile}
                content={fileContent?.content ?? null}
                error={fileContent?.error}
                isDirectory={isSelectedDirectory}
                projectId={currentProjectId}
                apiBaseUrl={apiBaseUrl}
              />
            )}
          </div>
        </ResizablePanel>

        <ResizableHandle />

        {/* Conversations */}
        <ResizablePanel defaultSize={35} minSize={20} maxSize={50}>
          <aside className="h-full flex flex-col bg-card rounded-r-md">
            <header className="px-4 py-3 bg-card">
              <div className="flex items-center gap-3">
                <Folder className="h-4 w-4 text-muted-foreground" />
                <h2 className="text-sm font-semibold text-foreground truncate">
                  {currentProject ? currentProject.name : "Select a Project"}
                </h2>
              </div>
            </header>

            {currentProject && (
              <div className="p-4 border-b border-border">
                <PromptInputProvider>
                  <ChatInputWithSuggestions
                    projectName={currentProject.name}
                    isCreatingChat={isCreatingChat}
                    onSubmit={createConversation}
                    onImprovePrompt={improvePrompt}
                    isImproving={isImproving}
                  />
                </PromptInputProvider>
              </div>
            )}

            <ScrollArea className="flex-1 px-4 py-3">
              {loading ? (
                <div className="text-muted-foreground text-center p-10" data-testid="loading-indicator">Loading...</div>
              ) : !currentProject ? (
                <div className="text-muted-foreground text-center p-10">
                  Select a project to view conversations
                </div>
              ) : conversations.length === 0 ? (
                <div className="text-center py-16 text-muted-foreground" data-testid="empty-conversations">
                  <MessageSquare className="h-8 w-8 mx-auto mb-4 opacity-50" />
                  <p>No conversations yet. Start a new one!</p>
                </div>
              ) : (
                <div data-testid="conversation-list">
                  {conversations.map((c) => (
                    <ConversationItem
                      key={c.id}
                      conversation={c}
                      onSelect={(id) => navigate(`/c/${id}`)}
                      onDelete={deleteConversation}
                    />
                  ))}
                </div>
              )}
            </ScrollArea>
          </aside>
        </ResizablePanel>
      </ResizablePanelGroup>
    </div>
  );
}
