/**
 * ConversationPage
 *
 * Main conversation interface with file tree, file viewer, and chat.
 * Uses extracted hooks for state management.
 */

import { useEffect, useRef, useCallback, useState } from "react";
import { useParams, useSearchParams } from "react-router-dom";
import { ArrowLeft, FilePlus, FolderPlus, Edit2, FileText, MessageSquare, Columns, Maximize2, Minimize2, X, AlertTriangle } from "lucide-react";
import { Link } from "react-router-dom";
import { BreadcrumbNav } from "@/components/breadcrumb-nav";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { DataTable } from "@/components/ui/data-table";
import {
  ResizablePanelGroup,
  ResizablePanel,
  ResizableHandle,
} from "@/components/ui/resizable";
import { FileTree } from "@/components/file-tree";
import { ChatInput, EditableInput } from "@/components/chat";
import { FileViewer } from "@/components/editors/FileViewer";
import {
  Conversation,
  ConversationContent,
  ConversationScrollButton,
  Message,
  MessageContent,
  Response,
  Tool,
  ToolHeader,
  ToolContent,
  ToolInput,
  ToolOutput,
  ToolDenied,
  ToolDiff,
  ToolCard,
  PermissionDialog,
  type ToolState,
} from "@/components/ai";
import {
  ChainOfThought,
  ChainOfThoughtHeader,
  ChainOfThoughtContent,
  ChainOfThoughtStep,
} from "@/components/ai-elements/chain-of-thought";
import { PromptInputProvider } from "@/components/ai-elements/prompt-input";
import { cn, getCsrfToken } from "@/lib/utils";
import { useConversation, useFiles, useStreaming, useImprovePrompt } from "@/hooks";
import type { MessageData, StreamingToolEvent, ChainStep } from "@/types";

// Storage key for panel sizes (namespaced for conversation page)
const PANEL_STORAGE_KEY = "conversation-panel-sizes";

// ============================================================================
// Helper Functions
// ============================================================================

/** Get the folder path for creating new files/folders based on selection */
function getSelectedFolderPath(
  selectedFile: string | null,
  files: { path: string; type: "file" | "directory" }[]
): string {
  if (!selectedFile) return "";

  // Check if selected item is a directory
  const selectedItem = files.find((f) => f.path === selectedFile);
  if (selectedItem?.type === "directory") {
    return selectedFile;
  }

  // It's a file - get parent folder
  const lastSlash = selectedFile.lastIndexOf("/");
  return lastSlash > 0 ? selectedFile.substring(0, lastSlash) : "";
}

// ============================================================================
// Inline Components (could be extracted to components/conversation/ later)
// ============================================================================

/** Tool card for streaming state (during response generation) */
function StreamingToolCard({ event }: { event: StreamingToolEvent }) {
  const state: ToolState = event.denied
    ? "denied"
    : event.awaitingApproval
      ? "approval-requested"
      : event.result || event.stats || event.data_preview
        ? "completed"
        : "running";
  const hasDataPreview = event.data_preview && event.data_preview.length > 0;

  let outputContent: React.ReactNode = null;
  if (hasDataPreview) {
    outputContent = <DataTable data={event.data_preview!} />;
  } else if (event.result) {
    outputContent = event.result;
  }

  return (
    <Tool defaultOpen={true} className="my-3">
      <ToolHeader toolName={event.tool} state={state} />
      <ToolContent>
        {(event.args || event.sql) && (
          <ToolInput input={event.sql || { args: event.args }} toolName={event.tool} />
        )}
        {event.denied ? (
          <ToolDenied message="Tool execution was denied by user" />
        ) : (
          <>
            {(outputContent || event.stats) && <ToolOutput output={outputContent} stats={event.stats} />}
            <ToolDiff diff={event.diff} />
          </>
        )}
      </ToolContent>
    </Tool>
  );
}

/** User message bubble with inline edit action (ChatGPT-style) */
function UserMessageComponent({
  message,
  onReplay,
  isProcessing,
  onImprovePrompt,
  isImproving,
}: {
  message: MessageData;
  onReplay: (id: number, content: string) => void;
  isProcessing: boolean;
  onImprovePrompt?: (prompt: string) => Promise<string | null>;
  isImproving?: boolean;
}) {
  const [isEditing, setIsEditing] = useState(false);
  const [editContent, setEditContent] = useState(message.content);

  const handleEdit = () => {
    setEditContent(message.content);
    setIsEditing(true);
  };

  const handleCancel = () => {
    setIsEditing(false);
    setEditContent(message.content);
  };

  const handleSend = () => {
    if (editContent.trim()) {
      onReplay(message.id, editContent.trim());
      setIsEditing(false);
    }
  };

  if (isEditing) {
    return (
      <Message from="user">
        <div className="w-full max-w-[600px]">
          <EditableInput
            value={editContent}
            onChange={setEditContent}
            onSubmit={handleSend}
            onCancel={handleCancel}
            placeholder="Edit your message..."
            onImprovePrompt={onImprovePrompt}
            isImproving={isImproving}
          />
        </div>
      </Message>
    );
  }

  return (
    <Message from="user" data-testid="user-message" data-message-id={message.id}>
      <div>
        <MessageContent className="rounded-lg rounded-tr-sm">
          <div className="whitespace-pre-wrap">{message.content}</div>
        </MessageContent>
        <div className="flex gap-2 mt-1 justify-end opacity-0 group-hover:opacity-70 hover:!opacity-100 transition-opacity">
          <Button
            variant="ghost"
            size="icon"
            className="h-6 w-6"
            onClick={handleEdit}
            title="Edit & Resend"
            disabled={isProcessing}
          >
            <Edit2 className="h-3 w-3" />
          </Button>
        </div>
      </div>
    </Message>
  );
}

/** Assistant message with thinking and tools in ChainOfThought, text as response */
function AssistantMessageComponent({ message }: { message: MessageData }) {
  const events = message.metadata?.events || [];

  // Separate chain steps (thinking + tools) from text (final answer)
  const chainSteps: Array<{ type: "thinking" | "tool"; event: any; index: number }> = [];
  const textParts: string[] = [];

  events.forEach((event, index) => {
    if (event.type === "thinking" && event.text) {
      chainSteps.push({ type: "thinking", event, index });
    } else if (event.type === "tool") {
      chainSteps.push({ type: "tool", event, index });
    } else if (event.type === "text" && event.text) {
      textParts.push(event.text);
    }
  });

  const hasChain = chainSteps.length > 0;
  const hasText = textParts.length > 0;

  return (
    <>
      {/* Chain of Thought: thinking + tools */}
      {hasChain && (
        <div className="w-full mb-2">
          <ChainOfThought>
            <ChainOfThoughtHeader />
            <ChainOfThoughtContent>
              {chainSteps.map((step) => (
                step.type === "thinking" ? (
                  <ChainOfThoughtStep key={`thinking-${step.index}`} status="complete" label={step.event.text} />
                ) : (
                  <div key={`tool-${step.index}`} className="my-2">
                    <ToolCard event={step.event} />
                  </div>
                )
              ))}
            </ChainOfThoughtContent>
          </ChainOfThought>
        </div>
      )}

      {/* Final text response */}
      {hasText && (
        <Message from="assistant" data-testid="assistant-message" data-message-id={message.id}>
          <div className="w-full">
            <MessageContent className="rounded-lg rounded-bl-sm">
              <Response>{textParts.join("\n\n")}</Response>
            </MessageContent>
          </div>
        </Message>
      )}

      {/* Fallback for messages without events */}
      {events.length === 0 && message.content && (
        <Message from="assistant" data-testid="assistant-message" data-message-id={message.id}>
          <div className="w-full">
            <MessageContent className="rounded-lg rounded-bl-sm">
              <Response>{message.content}</Response>
            </MessageContent>
          </div>
        </Message>
      )}

      {/* Cancelled indicator */}
      {message.metadata?.cancelled && (
        <div className="text-yellow-400 text-xs mt-2 ml-2">
          ⚠ Response stopped by user
        </div>
      )}
    </>
  );
}

/** Streaming message with chain steps (thinking + tools unified) */
function StreamingMessageComponent({
  text,
  chainSteps,
}: {
  text: string;
  chainSteps: ChainStep[];
}) {
  const hasChain = chainSteps.length > 0;
  const lastStep = chainSteps[chainSteps.length - 1];
  const isLastStepActive = !text && lastStep?.type === "thinking";

  return (
    <>
      {/* Chain of Thought: thinking + tools */}
      {hasChain && (
        <div className="w-full mb-2">
          <ChainOfThought>
            <ChainOfThoughtHeader />
            <ChainOfThoughtContent>
              {chainSteps.map((step, index) => {
                const isLast = index === chainSteps.length - 1;

                if (step.type === "thinking") {
                  if (!step.text.trim()) return null;
                  const status = isLast && isLastStepActive ? "active" : "complete";
                  const label = isLast && isLastStepActive ? (
                    <>{step.text}<span className="animate-pulse opacity-70">▌</span></>
                  ) : step.text;
                  return (
                    <ChainOfThoughtStep key={step.id} status={status} label={label} />
                  );
                } else {
                  // Tool step - render directly without wrapping in ChainOfThoughtStep
                  return (
                    <div key={step.id} className="my-2">
                      <StreamingToolCard event={step.event} />
                    </div>
                  );
                }
              })}
            </ChainOfThoughtContent>
          </ChainOfThought>
        </div>
      )}

      {/* Final text response (the answer) */}
      {text ? (
        <Message from="assistant">
          <div className="w-full">
            <MessageContent className="rounded-lg rounded-bl-sm">
              <Response parseIncompleteMarkdown={true}>{text}</Response>
              <span className="animate-pulse opacity-70">▌</span>
            </MessageContent>
          </div>
        </Message>
      ) : !hasChain && (
        <Message from="assistant">
          <div className="w-full">
            <MessageContent className="rounded-lg rounded-bl-sm">
              <span className="animate-pulse opacity-70">▌</span>
            </MessageContent>
          </div>
        </Message>
      )}
    </>
  );
}

/** Animated loading indicator */
function LoadingIndicator() {
  return (
    <Message from="assistant">
      <MessageContent className="bg-card/50 backdrop-blur-sm px-4 py-3 rounded-2xl rounded-bl-sm">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 bg-accent rounded-full animate-pulse" style={{ animationDelay: "0ms" }} />
          <span className="w-2 h-2 bg-accent rounded-full animate-pulse" style={{ animationDelay: "300ms" }} />
          <span className="w-2 h-2 bg-accent rounded-full animate-pulse" style={{ animationDelay: "600ms" }} />
        </div>
      </MessageContent>
    </Message>
  );
}

// ============================================================================
// Main Component
// ============================================================================

export function ConversationPage() {
  const { conversationId } = useParams<{ conversationId: string }>();
  const [searchParams, setSearchParams] = useSearchParams();
  const initialMessage = searchParams.get("message") || "";
  const apiBaseUrl = (window as any).APP_CONFIG?.apiBaseUrl || "/ainstein/v1/";

  // Refs
  const initialMessageSentRef = useRef(false);

  // View mode state (persisted to localStorage)
  type ViewMode = "file" | "chat" | "hybrid";
  type WidthMode = "fixed" | "flex";

  const [viewMode, setViewMode] = useState<ViewMode>(() => {
    const saved = localStorage.getItem("conversationViewMode");
    return (saved as ViewMode) || "hybrid";
  });

  const [widthMode, setWidthMode] = useState<WidthMode>(() => {
    const saved = localStorage.getItem("conversationWidthMode");
    return (saved as WidthMode) || "fixed";
  });

  const handleViewModeChange = (value: string) => {
    if (value) {
      setViewMode(value as ViewMode);
      localStorage.setItem("conversationViewMode", value);
    }
  };

  const handleWidthModeChange = (value: string) => {
    if (value) {
      setWidthMode(value as WidthMode);
      localStorage.setItem("conversationWidthMode", value);
    }
  };

  // Hooks
  const {
    conversation,
    project,
    messages,
    setMessages,
    loadConversation,
    loadProject,
    updateTitle,
  } = useConversation({ apiBaseUrl });

  const {
    files,
    selectedFile,
    fileContent,
    isSelectedDirectory,
    selectedFileRef,
    handleSelectFile,
    loadFiles,
    loadFileContent,
    deleteFile,
    createFile,
    createFolder,
  } = useFiles({ apiBaseUrl, projectId: conversation?.project_id ?? null });

  // Callback to add temporary message
  const handleAddMessage = useCallback((msg: MessageData) => {
    setMessages((prev) => [...prev, msg]);
  }, [setMessages]);

  // Callback to update a message's ID (temp -> real from server)
  const handleUpdateMessageId = useCallback((tempId: number, realId: number) => {
    setMessages((prev) => prev.map(msg =>
      msg.id === tempId ? { ...msg, id: realId } : msg
    ));
  }, [setMessages]);

  const {
    isProcessing,
    isStopping,
    streamingText,
    streamingChainSteps,
    pendingPermission,
    permissionState,
    streamError,
    sendMessage,
    stopGeneration,
    handlePermissionResponse,
    clearStreamError,
  } = useStreaming({
    apiBaseUrl,
    conversationId: conversationId!,
    projectId: conversation?.project_id ?? null,
    onFilesRefresh: loadFiles,
    onFileContentRefresh: loadFileContent,
    selectedFileRef,
    onAddMessage: handleAddMessage,
    onUpdateMessageId: handleUpdateMessageId,
    onTitleUpdate: updateTitle,
  });

  const { improvePrompt, isImproving } = useImprovePrompt({ apiBaseUrl });

  // Replay a message (delete it and subsequent messages, then send edited content)
  const replayMessage = useCallback(async (messageId: number, content: string) => {
    if (isProcessing) return;

    try {
      const res = await fetch(
        `${apiBaseUrl}conversations/${conversationId}/replay_from/`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "X-CSRFToken": getCsrfToken(),
          },
          body: JSON.stringify({ message_id: messageId }),
        }
      );
      if (!res.ok) throw new Error("Failed to replay");
      await loadConversation(conversationId!);
      // Send the edited message
      sendMessage(content);
    } catch (e) {
      console.error("Replay error:", e);
    }
  }, [isProcessing, apiBaseUrl, conversationId, loadConversation, sendMessage]);

  // Initial load
  useEffect(() => {
    const init = async () => {
      const conv = await loadConversation(conversationId!);
      if (conv?.project_id) {
        await loadProject(conv.project_id);
        await loadFiles(conv.project_id);
      }
    };
    init();
  }, [conversationId, loadConversation, loadProject, loadFiles]);

  // Send initial message from URL param
  useEffect(() => {
    if (initialMessage && conversation && !initialMessageSentRef.current && !isProcessing) {
      initialMessageSentRef.current = true;
      setSearchParams({}, { replace: true });
      setTimeout(() => sendMessage(initialMessage), 100);
    }
  }, [conversation, initialMessage, isProcessing, setSearchParams, sendMessage]);

  // Determine if streaming content should show (prevent duplicates)
  const lastMessageIsAssistant = messages.length > 0 && messages[messages.length - 1]?.role === "assistant";
  const showLoadingIndicator = isProcessing && !streamingText && streamingChainSteps.length === 0 && !lastMessageIsAssistant;
  const showStreamingContent = isProcessing && (streamingText || streamingChainSteps.length > 0) && !lastMessageIsAssistant;

  // Get the selected folder path for creating new files/folders
  const selectedFolderPath = getSelectedFolderPath(selectedFile, files);

  return (
    <div className="flex flex-col h-screen bg-background" data-testid="conversation-view">
      {/* Header */}
      <header className="px-4 py-2.5 flex items-center gap-3 bg-card shrink-0" data-testid="conversation-header">
        <Link to="/" className="text-muted-foreground hover:text-foreground transition-colors">
          <ArrowLeft className="h-5 w-5" />
        </Link>

        {/* Breadcrumb: My/Shared > Project > Conversation */}
        <BreadcrumbNav
          project={project}
          conversation={conversation}
          apiBaseUrl={apiBaseUrl}
          isShared={project?.is_shared}
        />
        {isProcessing && (
          <span className="text-xs text-accent shrink-0" data-testid="streaming-indicator">typing...</span>
        )}
        <div className="flex items-center gap-3">
          {/* Width Mode Toggle (only in file/chat modes) */}
          {viewMode !== "hybrid" && (
            <ToggleGroup type="single" value={widthMode} onValueChange={handleWidthModeChange} size="sm">
              <ToggleGroupItem value="fixed" aria-label="Fixed width" title="Fixed width (720px)">
                <Minimize2 className="h-4 w-4" />
              </ToggleGroupItem>
              <ToggleGroupItem value="flex" aria-label="Full width" title="Full width">
                <Maximize2 className="h-4 w-4" />
              </ToggleGroupItem>
            </ToggleGroup>
          )}

          {/* View Mode Toggle */}
          <ToggleGroup type="single" value={viewMode} onValueChange={handleViewModeChange} size="sm">
            <ToggleGroupItem value="file" aria-label="File view" title="File view">
              <FileText className="h-4 w-4" />
            </ToggleGroupItem>
            <ToggleGroupItem value="hybrid" aria-label="Hybrid view" title="Hybrid view">
              <Columns className="h-4 w-4" />
            </ToggleGroupItem>
            <ToggleGroupItem value="chat" aria-label="Chat view" title="Chat view">
              <MessageSquare className="h-4 w-4" />
            </ToggleGroupItem>
          </ToggleGroup>

          <span className={cn("w-2.5 h-2.5 rounded-full", isProcessing ? "bg-yellow-400 animate-pulse" : "bg-accent")} />
        </div>
      </header>

      {/* Main Content */}
      <div className="flex-1 overflow-hidden">
        {/* Chat-only mode */}
        {viewMode === "chat" && (
          <div className="h-full flex flex-col bg-background">
            <div className={cn(
              "flex-1 flex flex-col min-h-0 w-full",
              widthMode === "fixed" && "max-w-[720px] mx-auto",
              "border-x border-border"
            )}>
              <Conversation className="flex-1">
                {/* Stream Error Notification */}
                {streamError && (
                  <div className="mx-4 mt-4 p-3 bg-amber-500/10 border border-amber-500/30 rounded-lg flex items-start gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-500 shrink-0 mt-0.5" />
                    <div className="flex-1 text-sm text-amber-200">
                      <p className="font-medium">Connection Interrupted</p>
                      <p className="text-amber-300/80 mt-1">{streamError}</p>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6 text-amber-400 hover:text-amber-300 hover:bg-amber-500/20"
                      onClick={clearStreamError}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                )}
                <ConversationContent className="p-5 text-sm">
                  {messages.length === 0 && !streamingText && (
                    <div className="text-muted-foreground">
                      Welcome to Claude Agent. Type a message below to get started.
                    </div>
                  )}
                  {messages.map((msg) =>
                    msg.role === "user" ? (
                      <UserMessageComponent key={msg.id} message={msg} onReplay={replayMessage} isProcessing={isProcessing} onImprovePrompt={improvePrompt} isImproving={isImproving} />
                    ) : (
                      <AssistantMessageComponent key={msg.id} message={msg} />
                    )
                  )}
                  {showLoadingIndicator && <LoadingIndicator />}
                  {showStreamingContent && (
                    <StreamingMessageComponent text={streamingText} chainSteps={streamingChainSteps} />
                  )}
                  {pendingPermission && (
                    <div className="px-4 py-2">
                      <PermissionDialog
                        request={pendingPermission}
                        state={permissionState}
                        onApprove={() => handlePermissionResponse(true)}
                        onDeny={() => handlePermissionResponse(false)}
                      />
                    </div>
                  )}
                </ConversationContent>
                <ConversationScrollButton />
              </Conversation>

              <PromptInputProvider>
                <ChatInput
                  onSend={sendMessage}
                  onStop={stopGeneration}
                  isProcessing={isProcessing}
                  isStopping={isStopping}
                  focusKey={conversationId}
                  onImprovePrompt={improvePrompt}
                  isImproving={isImproving}
                />
              </PromptInputProvider>
            </div>
          </div>
        )}

        {/* File-only mode with resizable panels */}
        {viewMode === "file" && (
          <ResizablePanelGroup
            direction="horizontal"
            autoSaveId={`${PANEL_STORAGE_KEY}-file`}
            className="h-full"
          >
            {/* File Tree */}
            <ResizablePanel defaultSize={15} minSize={10} maxSize={30}>
              <aside className="h-full bg-card flex flex-col">
                <div className="px-4 py-2 flex items-center justify-between">
                  <span className="text-[11px] uppercase tracking-wider text-muted-foreground">Project Files</span>
                  <div className="flex gap-1">
                    <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => createFile(selectedFolderPath)} title="New File">
                      <FilePlus className="h-3.5 w-3.5" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => createFolder(selectedFolderPath)} title="New Folder">
                      <FolderPlus className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>
                <ScrollArea className="flex-1 px-2" orientation="both">
                  <FileTree
                    files={files}
                    selectedFile={selectedFile}
                    onSelectFile={handleSelectFile}
                    onDeleteFile={deleteFile}
                    onCreateFile={createFile}
                    onCreateFolder={createFolder}
                    label=""
                  />
                </ScrollArea>
              </aside>
            </ResizablePanel>

            <ResizableHandle />

            {/* File Viewer */}
            <ResizablePanel defaultSize={85} minSize={40}>
              <div className="h-full flex flex-col bg-card">
                <div className={cn(
                  "flex-1 flex flex-col min-h-0 w-full",
                  widthMode === "fixed" && "max-w-[720px] mx-auto"
                )}>
                  {conversation?.project_id && (
                    <FileViewer
                      filePath={selectedFile}
                      content={fileContent?.content ?? null}
                      error={fileContent?.error}
                      isDirectory={isSelectedDirectory}
                      projectId={conversation.project_id}
                      apiBaseUrl={apiBaseUrl}
                      onDelete={deleteFile}
                    />
                  )}
                </div>
              </div>
            </ResizablePanel>
          </ResizablePanelGroup>
        )}

        {/* Hybrid mode with resizable panels */}
        {viewMode === "hybrid" && (
          <ResizablePanelGroup
            direction="horizontal"
            autoSaveId={`${PANEL_STORAGE_KEY}-hybrid`}
            className="h-full"
          >
            {/* File Tree */}
            <ResizablePanel defaultSize={15} minSize={10} maxSize={25}>
              <aside className="h-full bg-card flex flex-col">
                <div className="px-4 py-2 flex items-center justify-between">
                  <span className="text-[11px] uppercase tracking-wider text-muted-foreground">Project Files</span>
                  <div className="flex gap-1">
                    <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => createFile(selectedFolderPath)} title="New File">
                      <FilePlus className="h-3.5 w-3.5" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => createFolder(selectedFolderPath)} title="New Folder">
                      <FolderPlus className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>
                <ScrollArea className="flex-1 px-2" orientation="both">
                  <FileTree
                    files={files}
                    selectedFile={selectedFile}
                    onSelectFile={handleSelectFile}
                    onDeleteFile={deleteFile}
                    onCreateFile={createFile}
                    onCreateFolder={createFolder}
                    label=""
                  />
                </ScrollArea>
              </aside>
            </ResizablePanel>

            <ResizableHandle />

            {/* File Viewer */}
            <ResizablePanel defaultSize={45} minSize={20}>
              <div className="h-full flex flex-col bg-card border-x border-border">
                {conversation?.project_id && (
                  <FileViewer
                    filePath={selectedFile}
                    content={fileContent?.content ?? null}
                    error={fileContent?.error}
                    isDirectory={isSelectedDirectory}
                    projectId={conversation.project_id}
                    apiBaseUrl={apiBaseUrl}
                    onDelete={deleteFile}
                  />
                )}
              </div>
            </ResizablePanel>

            <ResizableHandle />

            {/* Chat */}
            <ResizablePanel defaultSize={40} minSize={25} maxSize={60}>
              <aside className="h-full flex flex-col bg-background">
                <Conversation className="flex-1">
                  {/* Stream Error Notification */}
                  {streamError && (
                    <div className="mx-4 mt-4 p-3 bg-amber-500/10 border border-amber-500/30 rounded-lg flex items-start gap-3">
                      <AlertTriangle className="h-5 w-5 text-amber-500 shrink-0 mt-0.5" />
                      <div className="flex-1 text-sm text-amber-200">
                        <p className="font-medium">Connection Interrupted</p>
                        <p className="text-amber-300/80 mt-1">{streamError}</p>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6 text-amber-400 hover:text-amber-300 hover:bg-amber-500/20"
                        onClick={clearStreamError}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  )}
                  <ConversationContent className="p-5 text-sm">
                    {messages.length === 0 && !streamingText && (
                      <div className="text-muted-foreground">
                        Welcome to Claude Agent. Type a message below to get started.
                      </div>
                    )}
                    {messages.map((msg) =>
                      msg.role === "user" ? (
                        <UserMessageComponent key={msg.id} message={msg} onReplay={replayMessage} isProcessing={isProcessing} onImprovePrompt={improvePrompt} isImproving={isImproving} />
                      ) : (
                        <AssistantMessageComponent key={msg.id} message={msg} />
                      )
                    )}
                    {showLoadingIndicator && <LoadingIndicator />}
                    {showStreamingContent && (
                      <StreamingMessageComponent text={streamingText} chainSteps={streamingChainSteps} />
                    )}
                    {pendingPermission && (
                      <div className="px-4 py-2">
                        <PermissionDialog
                          request={pendingPermission}
                          state={permissionState}
                          onApprove={() => handlePermissionResponse(true)}
                          onDeny={() => handlePermissionResponse(false)}
                        />
                      </div>
                    )}
                  </ConversationContent>
                  <ConversationScrollButton />
                </Conversation>

                <PromptInputProvider>
                  <ChatInput
                    onSend={sendMessage}
                    onStop={stopGeneration}
                    isProcessing={isProcessing}
                    isStopping={isStopping}
                    focusKey={conversationId}
                    onImprovePrompt={improvePrompt}
                    isImproving={isImproving}
                  />
                </PromptInputProvider>
              </aside>
            </ResizablePanel>
          </ResizablePanelGroup>
        )}
      </div>
    </div>
  );
}
