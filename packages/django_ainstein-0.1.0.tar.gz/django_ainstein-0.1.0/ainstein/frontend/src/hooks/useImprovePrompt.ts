/**
 * useImprovePrompt Hook
 *
 * Hook for improving prompts via the backend API.
 */

import { useState, useCallback } from "react";
import { getCsrfToken } from "@/lib/utils";

interface UseImprovePromptOptions {
  apiBaseUrl: string;
}

interface UseImprovePromptReturn {
  improvePrompt: (prompt: string) => Promise<string | null>;
  isImproving: boolean;
  error: string | null;
}

export function useImprovePrompt({ apiBaseUrl }: UseImprovePromptOptions): UseImprovePromptReturn {
  const [isImproving, setIsImproving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const improvePrompt = useCallback(async (prompt: string): Promise<string | null> => {
    if (!prompt.trim()) {
      return null;
    }

    setIsImproving(true);
    setError(null);

    try {
      const response = await fetch(`${apiBaseUrl}stream/improve_prompt/`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-CSRFToken": getCsrfToken(),
        },
        body: JSON.stringify({ prompt }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to improve prompt");
      }

      const data = await response.json();
      return data.improved_prompt;
    } catch (e) {
      const errorMessage = e instanceof Error ? e.message : "Failed to improve prompt";
      setError(errorMessage);
      console.error("Failed to improve prompt:", e);
      return null;
    } finally {
      setIsImproving(false);
    }
  }, [apiBaseUrl]);

  return {
    improvePrompt,
    isImproving,
    error,
  };
}
