/**
 * Tests for useStreaming hook
 *
 * Tests initialization, state management, and error handling.
 * Note: SSE streaming behavior is better tested in E2E tests.
 */

import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { renderHook, act } from '@testing-library/react';
import { useStreaming } from './useStreaming';

// Mock getCsrfToken
vi.mock('@/lib/utils', () => ({
  getCsrfToken: () => 'test-csrf-token',
}));

describe('useStreaming', () => {
  const defaultOptions = {
    apiBaseUrl: '/api/',
    conversationId: '123',
    projectId: 1,
    onAddMessage: vi.fn(),
  };

  beforeEach(() => {
    vi.clearAllMocks();
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  describe('initialization', () => {
    it('starts with empty state', () => {
      const { result } = renderHook(() => useStreaming(defaultOptions));

      expect(result.current.inputValue).toBe('');
      expect(result.current.isProcessing).toBe(false);
      expect(result.current.isStopping).toBe(false);
      expect(result.current.streamingText).toBe('');
      expect(result.current.streamingChainSteps).toEqual([]);
      expect(result.current.pendingPermission).toBeNull();
      expect(result.current.permissionState).toBe('pending');
      expect(result.current.streamError).toBeNull();
    });

    it('allows setting input value', () => {
      const { result } = renderHook(() => useStreaming(defaultOptions));

      act(() => {
        result.current.setInputValue('Hello');
      });

      expect(result.current.inputValue).toBe('Hello');
    });
  });

  describe('sendMessage', () => {
    it('does not send empty messages', async () => {
      const fetchSpy = vi.spyOn(global, 'fetch');
      const { result } = renderHook(() => useStreaming(defaultOptions));

      await act(async () => {
        await result.current.sendMessage();
      });

      expect(fetchSpy).not.toHaveBeenCalled();
    });

    it('does not send whitespace-only messages', async () => {
      const fetchSpy = vi.spyOn(global, 'fetch');
      const { result } = renderHook(() => useStreaming(defaultOptions));

      act(() => {
        result.current.setInputValue('   ');
      });

      await act(async () => {
        await result.current.sendMessage();
      });

      expect(fetchSpy).not.toHaveBeenCalled();
    });
  });

  describe('sendMessageWithText', () => {
    it('does not send empty text', async () => {
      const fetchSpy = vi.spyOn(global, 'fetch');
      const { result } = renderHook(() => useStreaming(defaultOptions));

      await act(async () => {
        await result.current.sendMessageWithText('');
      });

      expect(fetchSpy).not.toHaveBeenCalled();
    });

    it('trims whitespace from message', async () => {
      const fetchSpy = vi.spyOn(global, 'fetch').mockRejectedValue(new Error('Network'));
      const onAddMessage = vi.fn();
      const { result } = renderHook(() =>
        useStreaming({ ...defaultOptions, onAddMessage })
      );

      await act(async () => {
        await result.current.sendMessageWithText('  Padded message  ');
      });

      // Check user message was added with trimmed content
      const userCall = onAddMessage.mock.calls.find(
        (call) => call[0].role === 'user'
      );
      expect(userCall[0].content).toBe('Padded message');
    });
  });

  describe('error handling', () => {
    it('sets stream error on connection failure', async () => {
      vi.spyOn(global, 'fetch').mockRejectedValue(new TypeError('Failed to fetch'));

      const { result } = renderHook(() => useStreaming(defaultOptions));

      await act(async () => {
        await result.current.sendMessageWithText('Test');
      });

      expect(result.current.streamError).toContain('Connection lost');
    });

    it('clears stream error with clearStreamError', async () => {
      vi.spyOn(global, 'fetch').mockRejectedValue(new TypeError('Failed to fetch'));

      const { result } = renderHook(() => useStreaming(defaultOptions));

      await act(async () => {
        await result.current.sendMessageWithText('Test');
      });

      expect(result.current.streamError).not.toBeNull();

      act(() => {
        result.current.clearStreamError();
      });

      expect(result.current.streamError).toBeNull();
    });

    it('does not set error on abort', async () => {
      const error = new Error('Aborted');
      error.name = 'AbortError';

      vi.spyOn(global, 'fetch').mockRejectedValue(error);

      const { result } = renderHook(() => useStreaming(defaultOptions));

      await act(async () => {
        await result.current.sendMessageWithText('Test');
      });

      expect(result.current.streamError).toBeNull();
    });
  });

  describe('permission handling', () => {
    it('handlePermissionResponse does nothing without pending permission', async () => {
      const fetchSpy = vi.spyOn(global, 'fetch');
      const { result } = renderHook(() => useStreaming(defaultOptions));

      await act(async () => {
        await result.current.handlePermissionResponse(true);
      });

      // Should not make any API calls
      expect(fetchSpy).not.toHaveBeenCalled();
    });
  });

  describe('stopGeneration', () => {
    it('sets isStopping state', async () => {
      const { result } = renderHook(() => useStreaming(defaultOptions));

      await act(async () => {
        await result.current.stopGeneration();
      });

      expect(result.current.isStopping).toBe(true);
    });
  });

  describe('message creation', () => {
    it('adds user message on send', async () => {
      vi.spyOn(global, 'fetch').mockRejectedValue(new Error('Network'));
      const onAddMessage = vi.fn();
      const { result } = renderHook(() =>
        useStreaming({ ...defaultOptions, onAddMessage })
      );

      await act(async () => {
        await result.current.sendMessageWithText('Hello');
      });

      expect(onAddMessage).toHaveBeenCalled();
      const userCall = onAddMessage.mock.calls.find(
        (call) => call[0].role === 'user'
      );
      expect(userCall).toBeDefined();
      expect(userCall[0].content).toBe('Hello');
    });

    it('clears input after starting send', async () => {
      vi.spyOn(global, 'fetch').mockImplementation(
        () => new Promise(() => {}) // Never resolves
      );
      const { result } = renderHook(() => useStreaming(defaultOptions));

      act(() => {
        result.current.setInputValue('Test message');
      });

      // Start sending (don't await - just trigger)
      act(() => {
        result.current.sendMessage();
      });

      // Input should be cleared immediately
      expect(result.current.inputValue).toBe('');
    });
  });

  describe('callbacks', () => {
    it('calls onTitleUpdate when title_updated event would be received', () => {
      const onTitleUpdate = vi.fn();
      const { result } = renderHook(() =>
        useStreaming({ ...defaultOptions, onTitleUpdate })
      );

      // Just verify the callback is passed correctly
      expect(result.current).toBeDefined();
      // Actual title update is tested via E2E
    });
  });
});

// Note: Full SSE streaming behavior including:
// - agent_text events
// - tool_start/tool_result events
// - thinking_block_start/agent_thinking events
// - permission_request events
// - diff, sql, data_preview events
// are better tested in E2E tests where real SSE connections work correctly.
