/**
 * useStreaming Hook
 *
 * Handles SSE streaming for chat messages, tool execution, and permissions.
 *
 * ============================================================================
 * ARCHITECTURE: WHY WE DON'T RELOAD CONVERSATION AFTER STREAMING
 * ============================================================================
 *
 * PROBLEM (BUG FIXED):
 * Previously, after streaming completed we called loadConversation() to sync with
 * the server. This caused built-in tool events (Grep, Bash, Read, etc.) to DISAPPEAR
 * because:
 * 1. These events are captured during streaming and added to the temp message
 * 2. Server only saves MCP tool events, NOT Claude's built-in tools
 * 3. loadConversation() calls setMessages(serverData.messages) which overwrites
 *    our temp message that has the built-in tool events
 *
 * SOLUTION:
 * After streaming completes, we:
 * 1. Build a MessageData from streaming content (includes ALL tool events)
 * 2. Add it via onAddMessage (appends to messages array)
 * 3. ONLY refresh files (not conversation) using projectId directly
 * 4. Never call loadConversation after streaming
 *
 * DATA FLOW:
 * ┌─────────────────────────────────────────────────────────────────────────┐
 * │ Streaming Phase                                                          │
 * │ SSE events → accumulate in chainSteps/streamingText → UI shows live     │
 * │                                                                          │
 * │ FILE TREE REFRESH (during streaming):                                    │
 * │ When file-modifying tools (Write, Delete, PageCreate, etc.) complete,   │
 * │ onFilesRefresh is called immediately so new files appear in the tree.   │
 * └─────────────────────────────────────────────────────────────────────────┘
 *                                      ↓
 * ┌─────────────────────────────────────────────────────────────────────────┐
 * │ Stream End                                                               │
 * │ 1. buildAssistantMessage(chainSteps, text) → MessageData with events    │
 * │ 2. onAddMessage(msg) → append to messages (keeps built-in tool events!) │
 * │ 3. Clear streaming state (text, chainSteps)                             │
 * └─────────────────────────────────────────────────────────────────────────┘
 *                                      ↓
 * ┌─────────────────────────────────────────────────────────────────────────┐
 * │ Background Sync                                                          │
 * │ 1. onFilesRefresh(projectId) → refresh file tree (final sync)           │
 * │ 2. onFileContentRefresh() → refresh current file content                │
 * │ ❌ NO loadConversation() - would overwrite temp message!                 │
 * └─────────────────────────────────────────────────────────────────────────┘
 *
 * TOOL EVENT TYPES:
 * - MCP Tools (django_*, storage_*, page_*): Saved server-side, use tool_start/tool_result
 * - Built-in Tools (Grep, Bash, Read, etc.): NOT saved, use tool_use_start/tool_use_end
 *
 * The conversation syncs properly on:
 * - Page load (loadConversation in useEffect)
 * - User replay action (intentional reload)
 *
 * KEY DESIGN DECISIONS:
 * 1. Streaming content is shown in real-time via streamingText/streamingChainSteps state
 * 2. On stream end (done/cancel/abort), content is converted to a MessageData and added
 *    to the messages list IMMEDIATELY - we don't wait for server reload
 * 3. Server sync happens in background after content is shown
 * 4. Cancel is instant - we mark cancelled via ref, abort, and show content in finally block
 *
 * This approach ensures:
 * - No flash of empty content between stream end and reload
 * - Cancel shows partial response immediately
 * - User sees content without waiting for server roundtrip
 * - Built-in tool events (Grep, Bash, etc.) are preserved
 */

import { useState, useCallback, useRef } from "react";
import type { StreamingToolEvent, ChainStep, MessageData, MessageEvent } from "@/types";
import type { PermissionRequest, PermissionState } from "@/components/ai";
import { getCsrfToken } from "@/lib/utils";

/**
 * Convert streaming content to a MessageData object.
 *
 * WHY THIS EXISTS:
 * Previously, we would discard streaming content and reload from the server after
 * stream completion. This caused a flash where content would disappear and reappear,
 * and on cancel, the partial response wouldn't show until refresh.
 *
 * Now we convert streaming content directly to a message, showing it immediately
 * without waiting for the server. The server save happens in the background.
 */
function buildAssistantMessage(
  chainSteps: ChainStep[],
  finalText: string,
  cancelled: boolean
): MessageData {
  // Build events array from chain steps
  const events: MessageEvent[] = [];

  for (const step of chainSteps) {
    if (step.type === "thinking" && step.text.trim()) {
      events.push({ type: "thinking", text: step.text });
    } else if (step.type === "tool") {
      events.push({
        type: "tool",
        tool: step.event.tool,
        args: step.event.args,
        input: step.event.input,
        sql: step.event.sql,
        diff: step.event.diff,
        result: step.event.result || undefined,
        stats: step.event.stats,
        data_preview: step.event.data_preview,
        denied: step.event.denied,
      });
    }
  }

  // Add any remaining text after the chain (the final answer)
  if (finalText) {
    events.push({ type: "text", text: finalText });
  }

  // Build content string from text events
  let content = finalText || "Response";
  if (cancelled) {
    content += "\n\n[Response stopped by user]";
  }

  // Join all thinking blocks for the single thinking field (backwards compat)
  const allThinking = chainSteps
    .filter((s): s is ChainStep & { type: "thinking" } => s.type === "thinking" && !!s.text.trim())
    .map(s => s.text)
    .join("\n\n");

  return {
    id: Date.now(),
    role: "assistant",
    content,
    metadata: { events, cancelled, thinking: allThinking || undefined },
  };
}

interface UseStreamingOptions {
  apiBaseUrl: string;
  conversationId: string;
  /** Project ID for file refresh (avoids reloading conversation) */
  projectId: number | null;
  /** Called after streaming to refresh files */
  onFilesRefresh?: (projectId: number) => Promise<void>;
  /** Called to refresh specific file content */
  onFileContentRefresh?: (filePath: string, projectId: number) => Promise<void>;
  /** Ref to current selected file path */
  selectedFileRef?: React.RefObject<string | null>;
  /** Callback to add temporary user message */
  onAddMessage: (message: MessageData) => void;
  /** Callback to update a message's ID (temp -> real) */
  onUpdateMessageId?: (tempId: number, realId: number) => void;
  /** Callback when conversation title is updated */
  onTitleUpdate?: (title: string) => void;
}

interface UseStreamingReturn {
  isProcessing: boolean;
  isStopping: boolean;
  streamingText: string;
  streamingChainSteps: ChainStep[];
  pendingPermission: PermissionRequest | null;
  permissionState: PermissionState;
  /** Error message when stream disconnects unexpectedly (e.g., server restart) */
  streamError: string | null;
  sendMessage: (text: string) => Promise<void>;
  stopGeneration: () => Promise<void>;
  handlePermissionResponse: (approved: boolean) => Promise<void>;
  /** Clear the stream error */
  clearStreamError: () => void;
}

export function useStreaming({
  apiBaseUrl,
  conversationId,
  projectId,
  onFilesRefresh,
  onFileContentRefresh,
  selectedFileRef,
  onAddMessage,
  onUpdateMessageId,
  onTitleUpdate,
}: UseStreamingOptions): UseStreamingReturn {
  const [isProcessing, setIsProcessing] = useState(false);
  const [isStopping, setIsStopping] = useState(false);
  const [streamingText, setStreamingText] = useState("");
  const [streamingChainSteps, setStreamingChainSteps] = useState<ChainStep[]>([]);
  const [currentStreamId, setCurrentStreamId] = useState<string | null>(null);
  const [pendingPermission, setPendingPermission] = useState<PermissionRequest | null>(null);
  const [permissionState, setPermissionState] = useState<PermissionState>("pending");
  const [streamError, setStreamError] = useState<string | null>(null);

  const abortControllerRef = useRef<AbortController | null>(null);
  /**
   * Track if stream was cancelled by user.
   * WHY A REF: When abort() is called, we don't receive the "cancelled" event from server.
   * The ref allows stopGeneration to mark cancellation before abort, and the finally block
   * reads it to know whether to show "[Response stopped by user]".
   */
  const wasCancelledRef = useRef(false);

  const sendMessage = useCallback(async (messageText: string) => {
    if (!messageText.trim() || isProcessing) return;

    const message = messageText.trim();
    setIsProcessing(true);
    setStreamingText("");
    setStreamingChainSteps([]);
    setStreamError(null); // Clear any previous error
    wasCancelledRef.current = false;

    // Add temporary user message (will be updated with real ID from server)
    const tempUserMsgId = Date.now();
    const tempUserMsg: MessageData = {
      id: tempUserMsgId,
      role: "user",
      content: message,
    };
    onAddMessage(tempUserMsg);

    abortControllerRef.current = new AbortController();

    /**
     * IMPORTANT: These variables are declared OUTSIDE the try block.
     * WHY: They need to be accessible in the finally block for building the message.
     * If declared inside try, they'd be block-scoped and cause ReferenceError in finally.
     */
    let accumulatedText = "";
    let chainSteps: ChainStep[] = [];
    let currentThinkingId: number | null = null;

    try {
      const res = await fetch(`${apiBaseUrl}stream/stream/`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-CSRFToken": getCsrfToken(),
        },
        body: JSON.stringify({
          message,
          conversation_id: Number(conversationId),
        }),
        signal: abortControllerRef.current.signal,
      });

      if (!res.ok) throw new Error(`HTTP ${res.status}`);

      const reader = res.body!.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let pendingTool: StreamingToolEvent | null = null;

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";

        for (const line of lines) {
          if (!line.startsWith("data: ")) continue;
          try {
            const event = JSON.parse(line.slice(6));

            switch (event.type) {
              case "stream_id":
                setCurrentStreamId(event.stream_id || null);
                break;

              case "title_updated":
                if (event.title && onTitleUpdate) {
                  onTitleUpdate(event.title);
                }
                break;

              case "user_message_saved":
                // Update temp user message ID with real database ID
                if (event.message_id && onUpdateMessageId) {
                  onUpdateMessageId(tempUserMsgId, event.message_id);
                }
                break;

              case "agent_text":
                if (event.text) {
                  accumulatedText += event.text.replace(/\x1B\[[0-9;]*[a-zA-Z]/g, "");
                  setStreamingText(accumulatedText);
                }
                break;

              case "thinking_block_start": {
                // Start a new thinking step in the chain
                currentThinkingId = Date.now();
                const newStep: ChainStep = { type: "thinking", id: currentThinkingId, text: "" };
                chainSteps = [...chainSteps, newStep];
                setStreamingChainSteps(chainSteps);
                break;
              }

              case "agent_thinking":
                // Append to current thinking step
                if (event.text) {
                  const cleanText = event.text.replace(/\x1B\[[0-9;]*[a-zA-Z]/g, "");
                  if (currentThinkingId === null) {
                    // No block started yet, create one
                    currentThinkingId = Date.now();
                    chainSteps = [...chainSteps, { type: "thinking", id: currentThinkingId, text: cleanText }];
                  } else {
                    // Append to the current thinking step
                    chainSteps = chainSteps.map(step =>
                      step.type === "thinking" && step.id === currentThinkingId
                        ? { ...step, text: step.text + cleanText }
                        : step
                    );
                  }
                  setStreamingChainSteps(chainSteps);
                }
                break;

              case "tool_start": {
                const eventTool = event.tool || "Tool";
                const eventArgs = event.args_summary || "";

                // Deduplicate tool events to prevent multiple cards for the same operation
                const existingToolStep = chainSteps.find(s =>
                  s.type === "tool" && (
                    (!s.event.result && !s.event.denied) ||
                    (s.event.tool === eventTool && s.event.args === eventArgs)
                  )
                );

                if (existingToolStep && existingToolStep.type === "tool") {
                  pendingTool = existingToolStep.event;
                  break;
                }

                // End current thinking (new step will be tool)
                currentThinkingId = null;

                const toolEvent: StreamingToolEvent = {
                  id: Date.now(),
                  tool: eventTool,
                  args: eventArgs,
                  input: event.input,
                  result: null,
                };
                pendingTool = toolEvent;

                const toolStep: ChainStep = { type: "tool", id: toolEvent.id, event: toolEvent };
                chainSteps = [...chainSteps, toolStep];
                setStreamingChainSteps(chainSteps);

                // Reset accumulated text (any text after tools is the final answer)
                accumulatedText = "";
                setStreamingText("");
                break;
              }

              case "tool_result": {
                if (pendingTool) {
                  const updatedTool = {
                    ...pendingTool,
                    result: event.stats ? "Done" : (event.summary || "Done"),
                    stats: event.stats,
                    denied: event.denied || false,
                  };
                  chainSteps = chainSteps.map(step =>
                    step.type === "tool" && step.id === pendingTool!.id
                      ? { ...step, event: updatedTool }
                      : step
                  );
                  setStreamingChainSteps(chainSteps);

                  // Refresh file tree when file-modifying tools complete
                  const fileModifyingTools = [
                    // Storage tools
                    "Write", "Update", "Delete", "Move", "DeleteFolder",
                    // Visualization
                    "CreateChart", "QuickChart",
                    // Page tools
                    "PageWrite", "PageCreate", "PageAppend", "PageInsert", "PageReplace", "PageDelete", "PageMove",
                    // Export tools
                    "ExportExcel", "ExportPDF", "ProcessImage", "ConvertFormat", "Export",
                    // Remote code (both single-file and multi-file variants)
                    "RemoteCode", "RemoteCodeFiles",
                  ];
                  if (fileModifyingTools.includes(pendingTool.tool) && projectId && onFilesRefresh) {
                    // Fire and forget - don't await, just refresh in background
                    onFilesRefresh(projectId).catch(() => {});
                  }

                  pendingTool = null;
                }
                break;
              }

              case "sql":
                if (chainSteps.length > 0) {
                  const lastToolStep = [...chainSteps].reverse().find(s => s.type === "tool");
                  if (lastToolStep && lastToolStep.type === "tool") {
                    chainSteps = chainSteps.map(step =>
                      step.id === lastToolStep.id
                        ? { ...step, event: { ...lastToolStep.event, sql: event.sql } }
                        : step
                    );
                    setStreamingChainSteps(chainSteps);
                  }
                }
                break;

              case "data_preview":
                if (chainSteps.length > 0) {
                  const lastToolStep = [...chainSteps].reverse().find(s => s.type === "tool");
                  if (lastToolStep && lastToolStep.type === "tool") {
                    chainSteps = chainSteps.map(step =>
                      step.id === lastToolStep.id
                        ? { ...step, event: { ...lastToolStep.event, data_preview: event.rows } }
                        : step
                    );
                    setStreamingChainSteps(chainSteps);
                  }
                }
                break;

              case "diff":
                if (chainSteps.length > 0) {
                  const lastToolStep = [...chainSteps].reverse().find(s => s.type === "tool");
                  if (lastToolStep && lastToolStep.type === "tool") {
                    chainSteps = chainSteps.map(step =>
                      step.id === lastToolStep.id
                        ? { ...step, event: { ...lastToolStep.event, diff: event.lines } }
                        : step
                    );
                    setStreamingChainSteps(chainSteps);
                  }
                }
                break;

              case "permission_request": {
                setPendingPermission({
                  request_id: event.request_id,
                  message: event.message,
                  action: event.action,
                  tool_name: event.tool_name,
                  tool_input: event.tool_input,
                  rows_requested: event.rows_requested,
                  rows_limit: event.rows_limit,
                });
                setPermissionState("pending");

                // Update the most recent tool to show "awaiting approval" state
                const toolName = event.tool_name || "";
                const lastToolStep = [...chainSteps].reverse().find(
                  s => s.type === "tool" && s.event.tool === toolName && !s.event.result
                );
                if (lastToolStep && lastToolStep.type === "tool") {
                  chainSteps = chainSteps.map(step =>
                    step.id === lastToolStep.id
                      ? { ...step, event: { ...lastToolStep.event, awaitingApproval: true } }
                      : step
                  );
                  setStreamingChainSteps(chainSteps);
                }
                break;
              }

              // Handle ALL tool usage (including Claude's built-in tools like Grep, Read, etc.)
              case "tool_use_start": {
                const toolName = event.tool_name || "Tool";
                const toolUseId = event.tool_use_id;

                // Skip MCP app tools (they use tool_start/tool_result events)
                if (toolName.startsWith("mcp__app__") || toolName.startsWith("storage_") ||
                    toolName.startsWith("django_") || toolName.startsWith("page_") ||
                    toolName === "execute_code") {
                  break;
                }

                // End current thinking (new step will be tool)
                currentThinkingId = null;

                const toolEvent: StreamingToolEvent = {
                  id: toolUseId || Date.now(),
                  tool: toolName,
                  args: JSON.stringify(event.input || {}),
                  input: event.input,
                  result: null,
                };
                pendingTool = toolEvent;

                const toolStep: ChainStep = { type: "tool", id: toolEvent.id, event: toolEvent };
                chainSteps = [...chainSteps, toolStep];
                setStreamingChainSteps(chainSteps);

                // Reset accumulated text (any text after tools is the final answer)
                accumulatedText = "";
                setStreamingText("");
                break;
              }

              case "tool_use_end": {
                const toolName = event.tool_name || "";

                // Skip MCP app tools
                if (toolName.startsWith("mcp__app__") || toolName.startsWith("storage_") ||
                    toolName.startsWith("django_") || toolName.startsWith("page_") ||
                    toolName === "execute_code") {
                  break;
                }

                // Find the matching pending tool by tool_use_id or most recent
                const targetId = event.tool_use_id;
                const toolStep = targetId
                  ? chainSteps.find(s => s.type === "tool" && s.id === targetId)
                  : [...chainSteps].reverse().find(s => s.type === "tool" && !s.event.result);

                if (toolStep && toolStep.type === "tool") {
                  // Handle denied, error, or success cases
                  const isDenied = event.denied === true;
                  const isError = event.is_error === true;
                  const resultText = isDenied
                    ? (event.reason || "Tool execution denied")
                    : isError
                      ? `Error: ${event.summary}`
                      : (event.summary || "Done");

                  const updatedTool = {
                    ...toolStep.event,
                    result: resultText,
                    denied: isDenied,
                  };
                  chainSteps = chainSteps.map(step =>
                    step.id === toolStep.id
                      ? { ...step, event: updatedTool }
                      : step
                  );
                  setStreamingChainSteps(chainSteps);
                }
                pendingTool = null;
                break;
              }

              case "done":
                // Stream completed normally
                break;

              case "cancelled":
                // Stream was cancelled by user
                wasCancelledRef.current = true;
                break;
            }
          } catch (e) {
            console.error("Parse error:", e);
          }
        }
      }
    } catch (e: unknown) {
      if (e instanceof Error && e.name !== "AbortError") {
        console.error("Stream error:", e);
        // Detect connection/network errors (server restart, network issues)
        const errorMessage = e.message?.toLowerCase() || "";
        const isConnectionError =
          errorMessage.includes("failed to fetch") ||
          errorMessage.includes("network") ||
          errorMessage.includes("stream closed") ||
          errorMessage.includes("connection") ||
          e.name === "TypeError"; // fetch throws TypeError on network failure

        if (isConnectionError && !wasCancelledRef.current) {
          setStreamError("Connection lost. The server may have restarted. Your partial response has been preserved.");
        }
      }
    } finally {
      setCurrentStreamId(null);
      abortControllerRef.current = null;

      /**
       * IMPORTANT: Clear streaming UI FIRST, then add message.
       * WHY ORDER MATTERS: If we add message first and something fails,
       * the streaming UI (pulsating cursor) would persist. By clearing first,
       * we ensure the streaming UI is always removed even if message add fails.
       */
      const finalChainSteps = [...chainSteps];
      const finalText = accumulatedText;
      const wasCancelled = wasCancelledRef.current;

      // Clear streaming state immediately to stop pulsating cursor
      setStreamingText("");
      setStreamingChainSteps([]);

      /**
       * Convert streamed content to a message and add it.
       * WHY: Previously we discarded streaming content and reloaded from server.
       * This caused issues:
       * 1. On cancel, partial response wouldn't show until manual refresh
       * 2. Flash of empty content while waiting for reload
       */
      const hasContent = finalChainSteps.length > 0 || finalText;
      if (hasContent) {
        const assistantMsg = buildAssistantMessage(finalChainSteps, finalText, wasCancelled);
        onAddMessage(assistantMsg);
      }

      /**
       * Background sync: Refresh files after stream completes.
       *
       * SKIP CONVERSATION RELOAD: We already have the content from streaming.
       * Reloading would overwrite our temp message (which has built-in tool events
       * like Grep/Bash that aren't saved server-side). Just refresh files instead.
       *
       * The conversation will sync properly on next page load or user interaction.
       */
      if (wasCancelled) {
        setIsProcessing(false);
        setIsStopping(false);
      } else {
        // Just refresh files, don't reload conversation (preserves tool events)
        if (projectId && onFilesRefresh) {
          onFilesRefresh(projectId)
            .then(() => {
              const filePath = selectedFileRef?.current;
              if (filePath && onFileContentRefresh) {
                return onFileContentRefresh(filePath, projectId);
              }
            })
            .finally(() => {
              setIsProcessing(false);
            });
        } else {
          setIsProcessing(false);
        }
      }
    }
  }, [
    isProcessing,
    apiBaseUrl,
    conversationId,
    projectId,
    onAddMessage,
    onFilesRefresh,
    onFileContentRefresh,
    selectedFileRef,
    onTitleUpdate,
  ]);

  const stopGeneration = useCallback(async () => {
    /**
     * Mark as cancelled and stopping BEFORE sending cancel request.
     * WHY: These flags are read by the finally block after abort.
     */
    wasCancelledRef.current = true;
    setIsStopping(true);

    /**
     * AWAIT cancel request to ensure server saves the partial response.
     * WHY: If we fire-and-forget, user might refresh before save completes,
     * and the message would be lost. By awaiting, we guarantee persistence.
     */
    if (currentStreamId) {
      try {
        await fetch(`${apiBaseUrl}stream/cancel/`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "X-CSRFToken": getCsrfToken(),
          },
          body: JSON.stringify({ stream_id: currentStreamId }),
        });
      } catch {
        // Ignore errors - still abort below
      }
    }

    /**
     * Abort AFTER cancel completes.
     * WHY: Server has now saved the partial response. The abort triggers
     * the finally block which shows the temp message. No reload needed
     * since we already ensured persistence above.
     */
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
  }, [currentStreamId, apiBaseUrl]);

  const handlePermissionResponse = useCallback(async (approved: boolean) => {
    if (!pendingPermission) return;

    setPermissionState("approving");
    try {
      const res = await fetch(`${apiBaseUrl}stream/permission/`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-CSRFToken": getCsrfToken(),
        },
        body: JSON.stringify({
          request_id: pendingPermission.request_id,
          approved,
        }),
      });

      if (res.ok) {
        setPendingPermission(null);
        setPermissionState("pending");
      }
    } catch (e) {
      console.error("Permission response error:", e);
      setPendingPermission(null);
      setPermissionState("pending");
    }
  }, [apiBaseUrl, pendingPermission]);

  const clearStreamError = useCallback(() => {
    setStreamError(null);
  }, []);

  return {
    isProcessing,
    isStopping,
    streamingText,
    streamingChainSteps,
    pendingPermission,
    permissionState,
    streamError,
    sendMessage,
    stopGeneration,
    handlePermissionResponse,
    clearStreamError,
  };
}
