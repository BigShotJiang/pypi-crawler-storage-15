/**
 * useConversation Hook
 *
 * Manages conversation and message state with API loading.
 */

import { useState, useCallback } from "react";
import type { ConversationData, MessageData, ProjectData } from "@/types";

interface UseConversationOptions {
  apiBaseUrl: string;
}

interface UseConversationReturn {
  conversation: ConversationData | null;
  project: ProjectData | null;
  messages: MessageData[];
  setMessages: React.Dispatch<React.SetStateAction<MessageData[]>>;
  loadConversation: (conversationId: string) => Promise<ConversationData | undefined>;
  loadProject: (projectId: number) => Promise<void>;
  updateTitle: (title: string) => void;
}

export function useConversation({ apiBaseUrl }: UseConversationOptions): UseConversationReturn {
  const [conversation, setConversation] = useState<ConversationData | null>(null);
  const [project, setProject] = useState<ProjectData | null>(null);
  const [messages, setMessages] = useState<MessageData[]>([]);

  const loadConversation = useCallback(async (conversationId: string): Promise<ConversationData | undefined> => {
    try {
      const res = await fetch(`${apiBaseUrl}conversations/${conversationId}/`);
      const data = await res.json();
      setConversation(data);
      setMessages(data.messages || []);
      return data;
    } catch (e) {
      console.error("Failed to load conversation:", e);
    }
  }, [apiBaseUrl]);

  const loadProject = useCallback(async (projectId: number): Promise<void> => {
    try {
      const res = await fetch(`${apiBaseUrl}projects/${projectId}/`);
      const data = await res.json();
      setProject(data);
    } catch (e) {
      console.error("Failed to load project:", e);
    }
  }, [apiBaseUrl]);

  const updateTitle = useCallback((title: string) => {
    setConversation(prev => prev ? { ...prev, title } : null);
  }, []);

  return {
    conversation,
    project,
    messages,
    setMessages,
    loadConversation,
    loadProject,
    updateTitle,
  };
}
