/**
 * useProjects Hook
 *
 * Manages project list state, selection, and CRUD operations.
 */

import { useState, useCallback, useEffect, useRef } from "react";
import { useSearchParams } from "react-router-dom";
import type { Project, ProjectGroupState } from "@/types";
import { getCsrfToken } from "@/lib/utils";

interface UseProjectsOptions {
  apiBaseUrl: string;
}

interface UseProjectsReturn {
  sharedProjects: Project[];
  privateProjects: Project[];
  currentProjectId: number | null;
  currentProject: Project | undefined;
  expandedGroups: ProjectGroupState;
  loading: boolean;
  handleSelectProject: (projectId: number) => void;
  toggleGroup: (group: "shared" | "private") => void;
  loadProjects: () => Promise<{ shared: Project[]; private: Project[] }>;
  createProject: (name: string, isShared: boolean) => Promise<void>;
  deleteProject: (id: number) => Promise<void>;
}

export function useProjects({ apiBaseUrl }: UseProjectsOptions): UseProjectsReturn {
  const [searchParams, setSearchParams] = useSearchParams();
  const [sharedProjects, setSharedProjects] = useState<Project[]>([]);
  const [privateProjects, setPrivateProjects] = useState<Project[]>([]);
  const [currentProjectId, setCurrentProjectId] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [expandedGroups, setExpandedGroups] = useState<ProjectGroupState>({
    shared: true,
    private: true,
  });

  const isInitialLoadRef = useRef(true);

  // Sort projects by last_activity, falling back to created date (most recent first)
  const sortByActivity = (projects: Project[]): Project[] => {
    return [...projects].sort((a, b) => {
      // Use last_activity if available, otherwise fall back to created date
      const aDate = a.last_activity || a.created;
      const bDate = b.last_activity || b.created;
      if (!aDate && !bDate) return 0;
      if (!aDate) return 1;
      if (!bDate) return -1;
      return new Date(bDate).getTime() - new Date(aDate).getTime();
    });
  };

  const loadProjects = useCallback(async (): Promise<{ shared: Project[]; private: Project[] }> => {
    try {
      const [sharedRes, privateRes] = await Promise.all([
        fetch(`${apiBaseUrl}projects/?is_shared=true`),
        fetch(`${apiBaseUrl}projects/?is_shared=false`),
      ]);
      const shared = sortByActivity(await sharedRes.json() || []);
      const priv = sortByActivity(await privateRes.json() || []);
      setSharedProjects(shared);
      setPrivateProjects(priv);
      return { shared, private: priv };
    } catch (e) {
      console.error("Failed to load projects:", e);
      return { shared: [], private: [] };
    }
  }, [apiBaseUrl]);

  const handleSelectProject = useCallback((projectId: number) => {
    setCurrentProjectId(projectId);
    setSearchParams((prev) => {
      const newParams = new URLSearchParams(prev);
      newParams.set("project", String(projectId));
      // Clear file selection when changing projects
      newParams.delete("file");
      return newParams;
    }, { replace: false });
  }, [setSearchParams]);

  const toggleGroup = useCallback((group: "shared" | "private") => {
    setExpandedGroups((prev) => ({ ...prev, [group]: !prev[group] }));
  }, []);

  const createProject = useCallback(async (name: string, isShared: boolean): Promise<void> => {
    const res = await fetch(`${apiBaseUrl}projects/`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-CSRFToken": getCsrfToken(),
      },
      body: JSON.stringify({ name, is_shared: isShared }),
    });
    const data = await res.json();
    if (data.error) {
      console.error("Failed to create project:", data.error);
      throw new Error(data.error);
    }
    await loadProjects();
    setCurrentProjectId(data.id);
    setSearchParams({ project: String(data.id) }, { replace: false });
  }, [apiBaseUrl, loadProjects, setSearchParams]);

  const deleteProject = useCallback(async (id: number): Promise<void> => {
    try {
      await fetch(`${apiBaseUrl}projects/${id}/`, {
        method: "DELETE",
        headers: { "X-CSRFToken": getCsrfToken() },
      });
      const { shared, private: priv } = await loadProjects();
      if (currentProjectId === id) {
        const allProjects = [...shared, ...priv];
        const newProject = allProjects.length > 0 ? allProjects[0] : null;
        setCurrentProjectId(newProject?.id ?? null);
        if (newProject) {
          setSearchParams({ project: String(newProject.id) }, { replace: false });
        }
      }
    } catch (e) {
      console.error("Failed to delete project:", e);
    }
  }, [apiBaseUrl, currentProjectId, loadProjects, setSearchParams]);

  // Initial load
  useEffect(() => {
    const init = async () => {
      setLoading(true);
      const { shared, private: priv } = await loadProjects();
      const allProjects = [...shared, ...priv];

      if (allProjects.length > 0) {
        // Check URL for project ID first
        const projectFromUrl = searchParams.get("project");
        if (projectFromUrl) {
          const urlProjectId = parseInt(projectFromUrl, 10);
          const urlProject = allProjects.find((p) => p.id === urlProjectId);
          if (urlProject) {
            setCurrentProjectId(urlProject.id);
            setLoading(false);
            return;
          }
        }

        // Fall back to default selection: projects are already sorted by activity,
        // prefer one with activity, then first
        const projectWithActivity = allProjects.find((p) => p.last_activity);
        const selectedProject = projectWithActivity || allProjects[0];
        setCurrentProjectId(selectedProject.id);
        setSearchParams({ project: String(selectedProject.id) }, { replace: true });
      }
      setLoading(false);
    };
    init();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // Sync URL project param to state (for browser back/forward navigation)
  useEffect(() => {
    if (isInitialLoadRef.current) {
      isInitialLoadRef.current = false;
      return;
    }
    const projectFromUrl = searchParams.get("project");
    if (projectFromUrl) {
      const urlProjectId = parseInt(projectFromUrl, 10);
      if (urlProjectId !== currentProjectId) {
        setCurrentProjectId(urlProjectId);
      }
    }
  }, [searchParams, currentProjectId]);

  const currentProject = [...sharedProjects, ...privateProjects].find(
    (p) => p.id === currentProjectId
  );

  return {
    sharedProjects,
    privateProjects,
    currentProjectId,
    currentProject,
    expandedGroups,
    loading,
    handleSelectProject,
    toggleGroup,
    loadProjects,
    createProject,
    deleteProject,
  };
}
