/**
 * useProjectConversations Hook
 *
 * Manages conversation list state and CRUD operations for a project.
 */

import { useState, useCallback, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import type { Conversation } from "@/types";
import { getCsrfToken } from "@/lib/utils";

interface UseProjectConversationsOptions {
  apiBaseUrl: string;
  projectId: number | null;
}

interface UseProjectConversationsReturn {
  conversations: Conversation[];
  isCreatingChat: boolean;
  loadConversations: (projectId: number) => Promise<void>;
  createConversation: (initialMessage?: string) => Promise<void>;
  deleteConversation: (id: number) => Promise<void>;
}

export function useProjectConversations({
  apiBaseUrl,
  projectId,
}: UseProjectConversationsOptions): UseProjectConversationsReturn {
  const navigate = useNavigate();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [isCreatingChat, setIsCreatingChat] = useState(false);

  const loadConversations = useCallback(async (pid: number): Promise<void> => {
    try {
      const res = await fetch(`${apiBaseUrl}conversations/?project_id=${pid}`);
      const data = await res.json();
      setConversations(data.conversations || []);
    } catch (e) {
      console.error("Failed to load conversations:", e);
    }
  }, [apiBaseUrl]);

  const createConversation = useCallback(async (initialMessage = ""): Promise<void> => {
    if (isCreatingChat) return;

    setIsCreatingChat(true);
    try {
      const body: Record<string, unknown> = {};
      if (projectId) {
        body.project_id = projectId;
      }
      const res = await fetch(`${apiBaseUrl}conversations/`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-CSRFToken": getCsrfToken(),
        },
        body: JSON.stringify(body),
      });
      const data = await res.json();
      const path = `/c/${data.id}`;
      if (initialMessage.trim()) {
        navigate(`${path}?message=${encodeURIComponent(initialMessage.trim())}`);
      } else {
        navigate(path);
      }
    } catch (e) {
      console.error("Failed to create conversation:", e);
      setIsCreatingChat(false);
    }
  }, [apiBaseUrl, projectId, isCreatingChat, navigate]);

  const deleteConversation = useCallback(async (id: number): Promise<void> => {
    try {
      await fetch(`${apiBaseUrl}conversations/${id}/`, {
        method: "DELETE",
        headers: { "X-CSRFToken": getCsrfToken() },
      });
      if (projectId) await loadConversations(projectId);
    } catch (e) {
      console.error("Failed to delete conversation:", e);
    }
  }, [apiBaseUrl, projectId, loadConversations]);

  // Load conversations when project changes
  useEffect(() => {
    if (projectId) {
      loadConversations(projectId);
    } else {
      setConversations([]);
    }
  }, [projectId, loadConversations]);

  return {
    conversations,
    isCreatingChat,
    loadConversations,
    createConversation,
    deleteConversation,
  };
}
