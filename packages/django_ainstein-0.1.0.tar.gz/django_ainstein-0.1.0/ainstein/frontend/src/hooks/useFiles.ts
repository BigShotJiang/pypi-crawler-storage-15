/**
 * useFiles Hook
 *
 * Manages file tree state and file operations (read, write, delete, create).
 */

import { useState, useCallback, useEffect, useRef } from "react";
import { useSearchParams } from "react-router-dom";
import type { FileItem } from "@/components/file-tree";
import type { FileContentData } from "@/types";
import { getCsrfToken } from "@/lib/utils";

interface UseFilesOptions {
  apiBaseUrl: string;
  projectId: number | null;
}

interface UseFilesReturn {
  files: FileItem[];
  selectedFile: string | null;
  fileContent: FileContentData | null;
  isSelectedDirectory: boolean;
  selectedFileRef: React.RefObject<string | null>;
  handleSelectFile: (filePath: string | null) => void;
  loadFiles: (projectId: number) => Promise<void>;
  loadFileContent: (filePath: string, projectId?: number) => Promise<void>;
  deleteFile: (filePath: string) => Promise<void>;
  createFile: (folderPath: string) => Promise<void>;
  createFolder: (parentPath: string) => Promise<void>;
}

export function useFiles({ apiBaseUrl, projectId }: UseFilesOptions): UseFilesReturn {
  const [searchParams, setSearchParams] = useSearchParams();
  const [files, setFiles] = useState<FileItem[]>([]);
  const [selectedFile, setSelectedFile] = useState<string | null>(null);
  const [fileContent, setFileContent] = useState<FileContentData | null>(null);
  const selectedFileRef = useRef<string | null>(null);

  // Handler for file selection that updates both state and URL
  const handleSelectFile = useCallback((filePath: string | null) => {
    setSelectedFile(filePath);
    if (filePath) {
      setSearchParams((prev) => {
        const newParams = new URLSearchParams(prev);
        newParams.set("file", filePath);
        return newParams;
      }, { replace: false });
    } else {
      setSearchParams((prev) => {
        const newParams = new URLSearchParams(prev);
        newParams.delete("file");
        return newParams;
      }, { replace: false });
    }
  }, [setSearchParams]);

  const loadFiles = useCallback(async (pid: number): Promise<void> => {
    try {
      const res = await fetch(`${apiBaseUrl}projects/${pid}/files/`);
      const data = await res.json();
      setFiles(data.files || []);
    } catch (e) {
      console.error("Failed to load files:", e);
    }
  }, [apiBaseUrl]);

  const loadFileContent = useCallback(async (filePath: string, pid?: number, fileList?: FileItem[]): Promise<void> => {
    const targetProjectId = pid || projectId;
    if (!targetProjectId) return;

    // Check if the path is a directory - don't try to load content
    const currentFiles = fileList || files;
    const fileItem = currentFiles.find(f => f.path === filePath);
    if (fileItem?.type === "directory") {
      setFileContent(null);
      return;
    }

    // Check if file is binary (images, PDFs, Office docs) - these are loaded directly by FileViewer
    const ext = filePath.split(".").pop()?.toLowerCase() || "";
    const binaryExtensions = [
      // Images
      "png", "jpg", "jpeg", "gif", "webp", "bmp", "tiff", "svg", "ico",
      // Documents
      "pdf",
      // Modern Office (Office Open XML)
      "docx", "xlsx", "pptx",
      // Legacy Office (binary formats)
      "doc", "xls", "ppt",
    ];
    if (binaryExtensions.includes(ext)) {
      // For binary files, just set path info - FileViewer will load the content directly
      setFileContent({ path: filePath, content: "", size: 0 });
      return;
    }

    try {
      const res = await fetch(
        `${apiBaseUrl}projects/${targetProjectId}/file/${filePath}`
      );
      const data = await res.json();
      setFileContent(data);
    } catch (e) {
      console.error("Failed to load file:", e);
      setFileContent({
        path: filePath,
        content: "",
        size: 0,
        error: "Failed to load file",
      });
    }
  }, [apiBaseUrl, projectId, files]);

  const deleteFile = useCallback(async (filePath: string): Promise<void> => {
    if (!projectId) return;
    try {
      const res = await fetch(
        `${apiBaseUrl}projects/${projectId}/file/${filePath}`,
        {
          method: "DELETE",
          headers: { "X-CSRFToken": getCsrfToken() },
        }
      );
      if (res.ok) {
        await loadFiles(projectId);
        if (selectedFile === filePath) {
          setSelectedFile(null);
          setFileContent(null);
        }
      } else {
        const data = await res.json();
        console.error("Failed to delete file:", data.error);
      }
    } catch (e) {
      console.error("Failed to delete file:", e);
    }
  }, [apiBaseUrl, projectId, selectedFile, loadFiles]);

  const createFile = useCallback(async (folderPath: string): Promise<void> => {
    if (!projectId) return;

    const fileName = prompt("Enter file name:", "new_file.page");
    if (!fileName) return;

    const fullPath = folderPath ? `${folderPath}/${fileName}` : fileName;

    try {
      const res = await fetch(`${apiBaseUrl}projects/${projectId}/file/${fullPath}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-CSRFToken": getCsrfToken(),
        },
        body: JSON.stringify({ content: "" }),
      });

      if (res.ok) {
        await loadFiles(projectId);
        setSelectedFile(fullPath);
      } else {
        const data = await res.json();
        console.error("Failed to create file:", data.error);
      }
    } catch (e) {
      console.error("Failed to create file:", e);
    }
  }, [apiBaseUrl, projectId, loadFiles]);

  const createFolder = useCallback(async (parentPath: string): Promise<void> => {
    if (!projectId) return;

    const folderName = prompt("Enter folder name:", "new_folder");
    if (!folderName) return;

    const fullPath = parentPath ? `${parentPath}/${folderName}/` : `${folderName}/`;

    try {
      // POST to path ending with / creates a folder
      const res = await fetch(`${apiBaseUrl}projects/${projectId}/file/${fullPath}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-CSRFToken": getCsrfToken(),
        },
        body: JSON.stringify({}),
      });

      if (res.ok) {
        await loadFiles(projectId);
      } else {
        const data = await res.json();
        console.error("Failed to create folder:", data.error);
      }
    } catch (e) {
      console.error("Failed to create folder:", e);
    }
  }, [apiBaseUrl, projectId, loadFiles]);

  // Load files when projectId changes
  useEffect(() => {
    if (projectId) {
      loadFiles(projectId);
    } else {
      setFiles([]);
    }
  }, [projectId, loadFiles]);

  // Load file content when selection changes
  useEffect(() => {
    if (selectedFile) {
      setFileContent(null); // Clear old content first to show loading state
      if (projectId) {
        loadFileContent(selectedFile);
      }
    } else {
      setFileContent(null);
    }
  }, [selectedFile, projectId, loadFileContent]);

  // Keep ref in sync with state
  useEffect(() => {
    selectedFileRef.current = selectedFile;
  }, [selectedFile]);

  // Sync URL file param to state (for browser back/forward navigation)
  useEffect(() => {
    const fileFromUrl = searchParams.get("file");
    if (fileFromUrl && fileFromUrl !== selectedFile) {
      setSelectedFile(fileFromUrl);
    } else if (!fileFromUrl && selectedFile) {
      // URL has no file param but we have a selection - clear it
      setSelectedFile(null);
    }
  }, [searchParams, selectedFile]);

  // Check if selected file is a directory
  const isSelectedDirectory = selectedFile
    ? files.find(f => f.path === selectedFile)?.type === "directory"
    : false;

  return {
    files,
    selectedFile,
    fileContent,
    isSelectedDirectory,
    selectedFileRef,
    handleSelectFile,
    loadFiles,
    loadFileContent,
    deleteFile,
    createFile,
    createFolder,
  };
}
