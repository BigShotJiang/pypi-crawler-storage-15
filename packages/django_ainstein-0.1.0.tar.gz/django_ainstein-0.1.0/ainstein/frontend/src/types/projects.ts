/**
 * Project Types
 *
 * Type definitions for projects and conversations on the ProjectsPage.
 */

// Re-export FileContentData for convenience (DRY - single source of truth)
export type { FileContentData } from "./conversation";

/**
 * Project entity from the API.
 */
export interface Project {
  id: number;
  name: string;
  slug: string;
  is_shared: boolean;
  is_owner: boolean;
  owner_name?: string;
  conversation_count: number;
  file_count: number;
  last_activity?: string;
}

/**
 * Conversation summary for project listing.
 */
export interface Conversation {
  id: number;
  title: string;
  modified: string;
  last_message?: string;
}

/**
 * Expanded state for project groups.
 */
export interface ProjectGroupState {
  shared: boolean;
  private: boolean;
}
