/**
 * Conversation Types
 *
 * Centralized type definitions for conversation-related data structures.
 * Used by ConversationPage and its associated hooks.
 */

import type { ToolEvent, ToolStats } from "@/components/ai";

// ============================================================================
// Message Event Types
// ============================================================================

/** Tool invocation event within a message */
export interface MessageToolEvent extends ToolEvent {
  type: "tool";
}

/** Text content event within a message */
export interface TextEvent {
  type: "text";
  text: string;
}

/** Thinking/chain-of-thought event within a message */
export interface ThinkingEvent {
  type: "thinking";
  text: string;
}

/** Union of all message event types */
export type MessageEvent = MessageToolEvent | TextEvent | ThinkingEvent;

// ============================================================================
// Data Models
// ============================================================================

/** Message data from the API */
export interface MessageData {
  id: number;
  role: "user" | "assistant";
  content: string;
  metadata?: {
    events?: MessageEvent[];
    cancelled?: boolean;
    thinking?: string;
  };
}

/** Conversation data from the API */
export interface ConversationData {
  id: number;
  title: string;
  project_id: number | null;
  messages: MessageData[];
}

/** Project data from the API */
export interface ProjectData {
  id: number;
  name: string;
  slug: string;
  is_shared?: boolean;
}

/** File content data from the API */
export interface FileContentData {
  path: string;
  content: string;
  size: number;
  error?: string;
}

// ============================================================================
// Streaming Types
// ============================================================================

/** Tool event during streaming (before message is saved) */
export interface StreamingToolEvent {
  id: number;
  tool: string;
  args: string;
  input?: Record<string, unknown>;
  sql?: string;
  diff?: string[];
  result: string | null;
  stats?: ToolStats;
  data_preview?: Record<string, unknown>[];
  denied?: boolean;
  awaitingApproval?: boolean;
}

/** A step in the chain of thought - either thinking or a tool call */
export type ChainStep =
  | { type: "thinking"; id: number; text: string }
  | { type: "tool"; id: number; event: StreamingToolEvent };

// Re-export ToolStats for convenience
export type { ToolStats };
