import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { ProjectsPage } from "./pages/ProjectsPage";
import { ConversationPage } from "./pages/ConversationPage";
import { Toaster } from "@/components/ui/sonner";

// Get base path for router from Django config
// This is the URL path where the app is served, not the API URL
const getBasePath = () => {
  const pageBaseUrl = (window as any).APP_CONFIG?.pageBaseUrl;
  if (!pageBaseUrl) {
    throw new Error("APP_CONFIG.pageBaseUrl is not configured");
  }
  return pageBaseUrl.replace(/\/$/, "");
};

export function App() {
  const basePath = getBasePath();

  return (
    <>
      <BrowserRouter basename={basePath}>
        <Routes>
          <Route path="/" element={<ProjectsPage />} />
          <Route path="/c/:conversationId" element={<ConversationPage />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
      <Toaster />
    </>
  );
}
