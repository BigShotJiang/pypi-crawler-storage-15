import type { Meta, StoryObj } from '@storybook/react';
import { FileViewer } from '../editors/FileViewer';

const meta: Meta<typeof FileViewer> = {
  title: 'Components/FileViewer',
  component: FileViewer,
  parameters: {
    layout: 'padded',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof FileViewer>;

// Sample content for different file types
const typescriptContent = `import { useState, useEffect } from 'react';

interface User {
  id: number;
  name: string;
  email: string;
}

export function useUser(userId: number) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function fetchUser() {
      try {
        const response = await fetch(\`/api/users/\${userId}\`);
        if (!response.ok) throw new Error('Failed to fetch user');
        const data = await response.json();
        setUser(data);
      } catch (e) {
        setError(e instanceof Error ? e.message : 'Unknown error');
      } finally {
        setLoading(false);
      }
    }

    fetchUser();
  }, [userId]);

  return { user, loading, error };
}`;

const jsonContent = `{
  "name": "my-awesome-project",
  "version": "1.0.0",
  "description": "A sample project",
  "main": "src/index.ts",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "test": "vitest",
    "lint": "eslint src/"
  },
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0"
  },
  "devDependencies": {
    "typescript": "^5.0.0",
    "vite": "^5.0.0"
  }
}`;

const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My App</title>
  <style>
    body {
      font-family: system-ui, sans-serif;
      margin: 0;
      padding: 20px;
      background: #f5f5f5;
    }
    .container {
      max-width: 800px;
      margin: 0 auto;
      background: white;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    h1 { color: #333; }
    p { color: #666; line-height: 1.6; }
  </style>
</head>
<body>
  <div class="container">
    <h1>Welcome to My App</h1>
    <p>This is a sample HTML file that can be previewed.</p>
  </div>
</body>
</html>`;

const cssContent = `.container {
  display: flex;
  flex-direction: column;
  gap: 1rem;
  padding: 1.5rem;
  max-width: 1200px;
  margin: 0 auto;
}

.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem 0;
  border-bottom: 1px solid #e5e7eb;
}

.button {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 0.5rem 1rem;
  font-size: 0.875rem;
  font-weight: 500;
  border-radius: 0.375rem;
  transition: all 0.2s;
}

.button-primary {
  background-color: #3b82f6;
  color: white;
}

.button-primary:hover {
  background-color: #2563eb;
}`;

const markdownContent = `# Project Documentation

## Overview

This project is a modern web application built with React and TypeScript.

## Features

- **Fast Development**: Hot module replacement for instant feedback
- **Type Safety**: Full TypeScript support
- **Modern Tooling**: Vite, ESLint, and Prettier configured

## Getting Started

\`\`\`bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
\`\`\`

## Project Structure

\`\`\`
src/
├── components/    # Reusable UI components
├── hooks/         # Custom React hooks
├── pages/         # Page components
├── utils/         # Utility functions
└── index.tsx      # Entry point
\`\`\`

## Contributing

Please read our contributing guidelines before submitting a PR.`;

const pythonContent = `from typing import List, Optional
from dataclasses import dataclass
from datetime import datetime

@dataclass
class Task:
    id: int
    title: str
    description: Optional[str] = None
    completed: bool = False
    created_at: datetime = datetime.now()

class TaskManager:
    def __init__(self):
        self.tasks: List[Task] = []
        self._next_id = 1

    def add_task(self, title: str, description: Optional[str] = None) -> Task:
        task = Task(
            id=self._next_id,
            title=title,
            description=description
        )
        self.tasks.append(task)
        self._next_id += 1
        return task

    def complete_task(self, task_id: int) -> bool:
        for task in self.tasks:
            if task.id == task_id:
                task.completed = True
                return True
        return False

    def get_pending_tasks(self) -> List[Task]:
        return [t for t in self.tasks if not t.completed]

if __name__ == "__main__":
    manager = TaskManager()
    manager.add_task("Learn Python", "Complete the tutorial")
    manager.add_task("Build project")
    print(f"Pending tasks: {len(manager.get_pending_tasks())}")`;

// Wrapper component for stories
function FileViewerDemo({ filePath, content, error }: { filePath: string | null; content: string | null; error?: string }) {
  return (
    <div className="h-[500px] w-full max-w-4xl border rounded-lg overflow-hidden">
      <FileViewer
        filePath={filePath}
        content={content}
        error={error}
        projectId={1}
        apiBaseUrl="/ainstein/v1/"
        onContentChange={(c) => console.log('Content changed:', c.slice(0, 50) + '...')}
        onDelete={(path) => console.log('Delete:', path)}
      />
    </div>
  );
}

export const TypeScriptFile: Story = {
  render: () => (
    <FileViewerDemo
      filePath="src/hooks/useUser.ts"
      content={typescriptContent}
    />
  ),
};

export const JSONFile: Story = {
  render: () => (
    <FileViewerDemo
      filePath="package.json"
      content={jsonContent}
    />
  ),
};

export const HTMLFile: Story = {
  render: () => (
    <FileViewerDemo
      filePath="public/index.html"
      content={htmlContent}
    />
  ),
};

export const CSSFile: Story = {
  render: () => (
    <FileViewerDemo
      filePath="src/styles/main.css"
      content={cssContent}
    />
  ),
};

export const MarkdownFile: Story = {
  render: () => (
    <FileViewerDemo
      filePath="README.md"
      content={markdownContent}
    />
  ),
};

export const PythonFile: Story = {
  render: () => (
    <FileViewerDemo
      filePath="src/task_manager.py"
      content={pythonContent}
    />
  ),
};

export const NoFileSelected: Story = {
  render: () => (
    <FileViewerDemo
      filePath={null}
      content={null}
    />
  ),
};

export const LoadingState: Story = {
  render: () => (
    <FileViewerDemo
      filePath="src/loading.ts"
      content={null}
    />
  ),
};

export const ErrorState: Story = {
  render: () => (
    <FileViewerDemo
      filePath="src/missing-file.ts"
      content={null}
      error="File not found: The requested file does not exist or has been deleted."
    />
  ),
};

export const LongFilePath: Story = {
  render: () => (
    <FileViewerDemo
      filePath="src/features/authentication/components/forms/LoginForm.tsx"
      content={typescriptContent}
    />
  ),
};

export const EmptyFile: Story = {
  render: () => (
    <FileViewerDemo
      filePath="src/empty.ts"
      content=""
    />
  ),
};

// Stories demonstrating preview mode functionality
export const HTMLWithPreviewToggle: Story = {
  render: () => (
    <div className="space-y-4">
      <p className="text-sm text-muted-foreground">
        Click the Code/Preview toggle buttons in the header to switch between viewing the raw HTML and the rendered preview.
      </p>
      <FileViewerDemo
        filePath="public/index.html"
        content={htmlContent}
      />
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story: 'HTML files have a Code/Preview toggle in the header. Click the Eye icon to see the rendered HTML.',
      },
    },
  },
};

export const MarkdownWithPreviewToggle: Story = {
  render: () => (
    <div className="space-y-4">
      <p className="text-sm text-muted-foreground">
        Click the Code/Preview toggle buttons to switch between raw markdown and the rendered preview using BlockNote.
      </p>
      <FileViewerDemo
        filePath="README.md"
        content={markdownContent}
      />
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story: 'Markdown files have a Code/Preview toggle. Preview mode uses BlockNote.js to render the markdown with rich formatting.',
      },
    },
  },
};
