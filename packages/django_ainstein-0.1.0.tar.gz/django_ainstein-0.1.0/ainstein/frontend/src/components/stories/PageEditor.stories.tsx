import type { Meta, StoryObj } from '@storybook/react';
import { PageEditor } from '../editors/PageEditor';
import { useState } from 'react';
import { Block } from '@blocknote/core';

// Helper to serialize blocks to JSON
function serializePageContent(blocks: Block[]): string {
  return JSON.stringify(blocks, null, 2);
}

// Helper to parse page content
function parsePageContent(content: string): Block[] {
  if (!content || !content.trim()) return [];
  try {
    const parsed = JSON.parse(content);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

const meta: Meta<typeof PageEditor> = {
  title: 'Components/PageEditor',
  component: PageEditor,
  parameters: {
    layout: 'padded',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof PageEditor>;

// Sample content for different scenarios
const emptyContent: Block[] = [];

const simpleContent: Block[] = [
  {
    id: 'block-1',
    type: 'heading',
    props: { level: 1 },
    content: [{ type: 'text', text: 'Welcome to the Page Editor' }],
    children: [],
  } as Block,
  {
    id: 'block-2',
    type: 'paragraph',
    props: {},
    content: [{ type: 'text', text: 'This is a simple paragraph with some text content.' }],
    children: [],
  } as Block,
];

const richContent: Block[] = [
  {
    id: 'block-1',
    type: 'heading',
    props: { level: 1 },
    content: [{ type: 'text', text: 'Project Documentation' }],
    children: [],
  } as Block,
  {
    id: 'block-2',
    type: 'paragraph',
    props: {},
    content: [
      { type: 'text', text: 'This document outlines the ' },
      { type: 'text', text: 'key features', styles: { bold: true } },
      { type: 'text', text: ' of our application.' },
    ],
    children: [],
  } as Block,
  {
    id: 'block-3',
    type: 'heading',
    props: { level: 2 },
    content: [{ type: 'text', text: 'Features' }],
    children: [],
  } as Block,
  {
    id: 'block-4',
    type: 'bulletListItem',
    props: {},
    content: [{ type: 'text', text: 'Real-time collaboration' }],
    children: [],
  } as Block,
  {
    id: 'block-5',
    type: 'bulletListItem',
    props: {},
    content: [{ type: 'text', text: 'Rich text editing with formatting' }],
    children: [],
  } as Block,
  {
    id: 'block-6',
    type: 'bulletListItem',
    props: {},
    content: [{ type: 'text', text: 'Auto-save functionality' }],
    children: [],
  } as Block,
  {
    id: 'block-7',
    type: 'heading',
    props: { level: 2 },
    content: [{ type: 'text', text: 'Getting Started' }],
    children: [],
  } as Block,
  {
    id: 'block-8',
    type: 'numberedListItem',
    props: {},
    content: [{ type: 'text', text: 'Install the dependencies' }],
    children: [],
  } as Block,
  {
    id: 'block-9',
    type: 'numberedListItem',
    props: {},
    content: [{ type: 'text', text: 'Configure your environment' }],
    children: [],
  } as Block,
  {
    id: 'block-10',
    type: 'numberedListItem',
    props: {},
    content: [{ type: 'text', text: 'Start the development server' }],
    children: [],
  } as Block,
];

const codeContent: Block[] = [
  {
    id: 'block-1',
    type: 'heading',
    props: { level: 1 },
    content: [{ type: 'text', text: 'Code Example' }],
    children: [],
  } as Block,
  {
    id: 'block-2',
    type: 'paragraph',
    props: {},
    content: [{ type: 'text', text: 'Here is an example function:' }],
    children: [],
  } as Block,
  {
    id: 'block-3',
    type: 'codeBlock',
    props: { language: 'typescript' },
    content: [{ type: 'text', text: 'function greet(name: string): string {\n  return `Hello, ${name}!`;\n}' }],
    children: [],
  } as Block,
];

// Wrapper component with state management
function PageEditorDemo({
  initialContent,
  readOnly = false,
}: {
  initialContent: Block[];
  readOnly?: boolean;
}) {
  const [content, setContent] = useState<Block[]>(initialContent);

  const handleChange = (blocks: Block[]) => {
    setContent(blocks);
    console.log('Content changed:', blocks.length, 'blocks');
  };

  const handleSave = async (blocks: Block[]) => {
    console.log('Saving content:', serializePageContent(blocks).slice(0, 100) + '...');
  };

  return (
    <div className="h-[500px] w-full max-w-4xl border rounded-lg overflow-hidden bg-card">
      <PageEditor
        initialContent={content}
        onChange={handleChange}
        onSave={handleSave}
        readOnly={readOnly}
      />
    </div>
  );
}

export const Empty: Story = {
  render: () => <PageEditorDemo initialContent={emptyContent} />,
};

export const SimpleContent: Story = {
  render: () => <PageEditorDemo initialContent={simpleContent} />,
};

export const RichContent: Story = {
  render: () => <PageEditorDemo initialContent={richContent} />,
};

export const WithCodeBlock: Story = {
  render: () => <PageEditorDemo initialContent={codeContent} />,
};

export const ReadOnly: Story = {
  render: () => <PageEditorDemo initialContent={richContent} readOnly />,
};

// Test the parsePageContent helper
export const ParsedFromString: Story = {
  render: () => {
    const jsonString = JSON.stringify(simpleContent, null, 2);
    const parsed = parsePageContent(jsonString);
    return <PageEditorDemo initialContent={parsed} />;
  },
};

// Test parsing plain text (non-JSON)
export const ParsedFromPlainText: Story = {
  render: () => {
    const plainText = 'This is plain text that will be converted to a paragraph block.';
    const parsed = parsePageContent(plainText);
    return <PageEditorDemo initialContent={parsed} />;
  },
};
