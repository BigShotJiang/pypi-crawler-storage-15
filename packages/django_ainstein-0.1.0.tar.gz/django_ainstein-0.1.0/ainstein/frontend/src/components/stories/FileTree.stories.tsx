import type { Meta, StoryObj } from '@storybook/react';
import { FileTree, type FileItem } from '../file-tree';
import { useState } from 'react';

const meta: Meta<typeof FileTree> = {
  title: 'Components/FileTree',
  component: FileTree,
  parameters: {
    layout: 'padded',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof FileTree>;

// Sample file structures
const simpleFiles: FileItem[] = [
  { name: 'src', path: 'src', type: 'directory' },
  { name: 'index.tsx', path: 'src/index.tsx', type: 'file' },
  { name: 'App.tsx', path: 'src/App.tsx', type: 'file' },
  { name: 'styles.css', path: 'src/styles.css', type: 'file' },
  { name: 'package.json', path: 'package.json', type: 'file' },
  { name: 'README.md', path: 'README.md', type: 'file' },
];

const projectFiles: FileItem[] = [
  // Root files
  { name: 'package.json', path: 'package.json', type: 'file' },
  { name: 'tsconfig.json', path: 'tsconfig.json', type: 'file' },
  { name: 'README.md', path: 'README.md', type: 'file' },
  { name: '.gitignore', path: '.gitignore', type: 'file' },

  // src directory
  { name: 'src', path: 'src', type: 'directory' },
  { name: 'index.tsx', path: 'src/index.tsx', type: 'file' },
  { name: 'App.tsx', path: 'src/App.tsx', type: 'file' },

  // components directory
  { name: 'components', path: 'src/components', type: 'directory' },
  { name: 'Button.tsx', path: 'src/components/Button.tsx', type: 'file' },
  { name: 'Input.tsx', path: 'src/components/Input.tsx', type: 'file' },
  { name: 'Card.tsx', path: 'src/components/Card.tsx', type: 'file' },

  // hooks directory
  { name: 'hooks', path: 'src/hooks', type: 'directory' },
  { name: 'useAuth.ts', path: 'src/hooks/useAuth.ts', type: 'file' },
  { name: 'useApi.ts', path: 'src/hooks/useApi.ts', type: 'file' },

  // utils directory
  { name: 'utils', path: 'src/utils', type: 'directory' },
  { name: 'helpers.ts', path: 'src/utils/helpers.ts', type: 'file' },
  { name: 'constants.ts', path: 'src/utils/constants.ts', type: 'file' },

  // pages directory
  { name: 'pages', path: 'src/pages', type: 'directory' },
  { name: 'Home.tsx', path: 'src/pages/Home.tsx', type: 'file' },
  { name: 'About.tsx', path: 'src/pages/About.tsx', type: 'file' },
  { name: 'Dashboard.tsx', path: 'src/pages/Dashboard.tsx', type: 'file' },

  // public directory
  { name: 'public', path: 'public', type: 'directory' },
  { name: 'favicon.ico', path: 'public/favicon.ico', type: 'file' },
  { name: 'index.html', path: 'public/index.html', type: 'file' },
];

const deeplyNestedFiles: FileItem[] = [
  { name: 'src', path: 'src', type: 'directory' },
  { name: 'features', path: 'src/features', type: 'directory' },
  { name: 'auth', path: 'src/features/auth', type: 'directory' },
  { name: 'components', path: 'src/features/auth/components', type: 'directory' },
  { name: 'LoginForm.tsx', path: 'src/features/auth/components/LoginForm.tsx', type: 'file' },
  { name: 'SignupForm.tsx', path: 'src/features/auth/components/SignupForm.tsx', type: 'file' },
  { name: 'hooks', path: 'src/features/auth/hooks', type: 'directory' },
  { name: 'useAuth.ts', path: 'src/features/auth/hooks/useAuth.ts', type: 'file' },
  { name: 'useSession.ts', path: 'src/features/auth/hooks/useSession.ts', type: 'file' },
  { name: 'index.ts', path: 'src/features/auth/index.ts', type: 'file' },

  { name: 'dashboard', path: 'src/features/dashboard', type: 'directory' },
  { name: 'components', path: 'src/features/dashboard/components', type: 'directory' },
  { name: 'Stats.tsx', path: 'src/features/dashboard/components/Stats.tsx', type: 'file' },
  { name: 'Chart.tsx', path: 'src/features/dashboard/components/Chart.tsx', type: 'file' },
  { name: 'index.ts', path: 'src/features/dashboard/index.ts', type: 'file' },
];

// Interactive wrapper for selection state
function FileTreeWithSelection({ files, ...props }: { files: FileItem[] } & Partial<React.ComponentProps<typeof FileTree>>) {
  const [selectedFile, setSelectedFile] = useState<string | null>(null);

  return (
    <div className="w-64 border rounded-lg bg-card">
      <FileTree
        files={files}
        selectedFile={selectedFile}
        onSelectFile={setSelectedFile}
        {...props}
      />
    </div>
  );
}

export const Default: Story = {
  render: () => <FileTreeWithSelection files={simpleFiles} />,
};

export const ProjectStructure: Story = {
  render: () => <FileTreeWithSelection files={projectFiles} />,
};

export const DeeplyNested: Story = {
  render: () => <FileTreeWithSelection files={deeplyNestedFiles} />,
};

export const WithActions: Story = {
  render: () => (
    <FileTreeWithSelection
      files={projectFiles}
      onDeleteFile={(path) => console.log('Delete:', path)}
      onCreateFile={(folderPath) => console.log('Create file in:', folderPath)}
      onCreateFolder={(folderPath) => console.log('Create folder in:', folderPath)}
    />
  ),
};

export const CustomLabel: Story = {
  render: () => <FileTreeWithSelection files={simpleFiles} label="Project Files" />,
};

export const NoLabel: Story = {
  render: () => <FileTreeWithSelection files={simpleFiles} label="" />,
};

export const Empty: Story = {
  render: () => <FileTreeWithSelection files={[]} />,
};

export const PreselectedFile: Story = {
  render: () => {
    const [selectedFile, setSelectedFile] = useState<string | null>('src/App.tsx');

    return (
      <div className="w-64 border rounded-lg bg-card">
        <FileTree
          files={projectFiles}
          selectedFile={selectedFile}
          onSelectFile={setSelectedFile}
        />
      </div>
    );
  },
};

export const MultipleTreesComparison: Story = {
  render: () => (
    <div className="flex gap-4">
      <div className="w-64 border rounded-lg bg-card">
        <FileTree
          files={simpleFiles}
          selectedFile={null}
          onSelectFile={() => {}}
          label="Simple Project"
        />
      </div>
      <div className="w-64 border rounded-lg bg-card">
        <FileTree
          files={deeplyNestedFiles}
          selectedFile={null}
          onSelectFile={() => {}}
          label="Feature-based"
        />
      </div>
    </div>
  ),
};

// Auto-expand stories
export const AutoExpandToNestedFile: Story = {
  name: 'Auto-Expand: Deeply Nested File',
  render: () => {
    // Pre-select a deeply nested file - folders should auto-expand
    const [selectedFile, setSelectedFile] = useState<string | null>(
      'src/features/auth/components/LoginForm.tsx'
    );

    return (
      <div className="w-64 border rounded-lg bg-card">
        <FileTree
          files={deeplyNestedFiles}
          selectedFile={selectedFile}
          onSelectFile={setSelectedFile}
          label="Auto-expanded to LoginForm.tsx"
        />
      </div>
    );
  },
};

export const AutoExpandOnFileChange: Story = {
  name: 'Auto-Expand: Dynamic File Selection',
  render: () => {
    const [selectedFile, setSelectedFile] = useState<string | null>(null);

    const nestedFilePaths = [
      'src/features/auth/components/LoginForm.tsx',
      'src/features/auth/hooks/useAuth.ts',
      'src/features/dashboard/components/Stats.tsx',
      'src/features/auth/components/SignupForm.tsx',
    ];

    return (
      <div className="space-y-4">
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setSelectedFile(null)}
            className="px-3 py-1 text-sm rounded bg-secondary hover:bg-secondary/80"
          >
            Clear Selection
          </button>
          {nestedFilePaths.map((path) => (
            <button
              key={path}
              onClick={() => setSelectedFile(path)}
              className={`px-3 py-1 text-sm rounded ${
                selectedFile === path
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-secondary hover:bg-secondary/80'
              }`}
            >
              {path.split('/').pop()}
            </button>
          ))}
        </div>
        <div className="text-sm text-muted-foreground">
          Selected: {selectedFile || 'None'}
        </div>
        <div className="w-64 border rounded-lg bg-card">
          <FileTree
            files={deeplyNestedFiles}
            selectedFile={selectedFile}
            onSelectFile={setSelectedFile}
            label="Click buttons to auto-expand"
          />
        </div>
      </div>
    );
  },
};

export const AutoExpandURLSimulation: Story = {
  name: 'Auto-Expand: URL Navigation Simulation',
  render: () => {
    const [selectedFile, setSelectedFile] = useState<string | null>(null);
    const [urlParam, setUrlParam] = useState('');

    // Simulate URL navigation
    const handleNavigate = () => {
      if (urlParam.trim()) {
        setSelectedFile(urlParam.trim());
      }
    };

    return (
      <div className="space-y-4">
        <div className="flex gap-2">
          <input
            type="text"
            value={urlParam}
            onChange={(e) => setUrlParam(e.target.value)}
            placeholder="Enter file path (e.g., src/features/auth/hooks/useAuth.ts)"
            className="flex-1 px-3 py-2 text-sm border rounded bg-background"
          />
          <button
            onClick={handleNavigate}
            className="px-4 py-2 text-sm rounded bg-primary text-primary-foreground hover:bg-primary/90"
          >
            Navigate
          </button>
        </div>
        <div className="text-xs text-muted-foreground">
          Try: src/features/auth/components/LoginForm.tsx
        </div>
        <div className="w-72 border rounded-lg bg-card">
          <FileTree
            files={deeplyNestedFiles}
            selectedFile={selectedFile}
            onSelectFile={setSelectedFile}
            label="Files"
          />
        </div>
      </div>
    );
  },
};
