import type { Meta, StoryObj } from '@storybook/react';
import { MarkdownViewer } from '../editors/MarkdownViewer';

const meta: Meta<typeof MarkdownViewer> = {
  title: 'Components/Editors/MarkdownViewer',
  component: MarkdownViewer,
  parameters: {
    layout: 'padded',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof MarkdownViewer>;

// Sample markdown content
const basicMarkdown = `# Hello World

This is a simple markdown document.

## Features

- Bullet point 1
- Bullet point 2
- Bullet point 3

## Code Example

\`\`\`javascript
console.log('Hello, World!');
\`\`\`
`;

const richMarkdown = `# Project Documentation

## Overview

This project is a modern web application built with **React** and *TypeScript*.

## Features

- **Fast Development**: Hot module replacement for instant feedback
- **Type Safety**: Full TypeScript support
- **Modern Tooling**: Vite, ESLint, and Prettier configured

## Getting Started

### Installation

\`\`\`bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
\`\`\`

### Configuration

Create a \`.env\` file with the following:

\`\`\`env
API_URL=https://api.example.com
DEBUG=true
\`\`\`

## Project Structure

\`\`\`
src/
├── components/    # Reusable UI components
├── hooks/         # Custom React hooks
├── pages/         # Page components
├── utils/         # Utility functions
└── index.tsx      # Entry point
\`\`\`

## API Reference

| Endpoint | Method | Description |
|----------|--------|-------------|
| /api/users | GET | List all users |
| /api/users/:id | GET | Get user by ID |
| /api/users | POST | Create new user |

## Contributing

Please read our [contributing guidelines](CONTRIBUTING.md) before submitting a PR.

---

*Last updated: January 2025*
`;

const headingsMarkdown = `# Heading 1

## Heading 2

### Heading 3

#### Heading 4

##### Heading 5

###### Heading 6

Regular paragraph text here.
`;

const listsMarkdown = `# Lists Examples

## Unordered List

- Item 1
- Item 2
  - Nested item 2.1
  - Nested item 2.2
- Item 3

## Ordered List

1. First item
2. Second item
   1. Nested item 2.1
   2. Nested item 2.2
3. Third item

## Checklist

- [ ] Task 1 (unchecked)
- [x] Task 2 (checked)
- [ ] Task 3 (unchecked)
`;

const codeBlocksMarkdown = `# Code Examples

## Inline Code

Use \`const\` for constants and \`let\` for variables.

## JavaScript

\`\`\`javascript
function greet(name) {
  return \`Hello, \${name}!\`;
}

const message = greet('World');
console.log(message);
\`\`\`

## Python

\`\`\`python
def greet(name: str) -> str:
    return f"Hello, {name}!"

message = greet("World")
print(message)
\`\`\`

## TypeScript

\`\`\`typescript
interface User {
  id: number;
  name: string;
  email: string;
}

function getUser(id: number): Promise<User> {
  return fetch(\`/api/users/\${id}\`).then(res => res.json());
}
\`\`\`
`;

// Wrapper component for consistent sizing
function MarkdownViewerDemo({ content }: { content: string }) {
  return (
    <div className="h-[500px] w-full max-w-4xl border rounded-lg overflow-hidden bg-background">
      <MarkdownViewer content={content} />
    </div>
  );
}

export const Basic: Story = {
  render: () => <MarkdownViewerDemo content={basicMarkdown} />,
  parameters: {
    docs: {
      description: {
        story: 'Basic markdown with headings, lists, and code blocks.',
      },
    },
  },
};

export const RichContent: Story = {
  render: () => <MarkdownViewerDemo content={richMarkdown} />,
  parameters: {
    docs: {
      description: {
        story: 'Rich markdown content with various formatting, tables, and code blocks.',
      },
    },
  },
};

export const Headings: Story = {
  render: () => <MarkdownViewerDemo content={headingsMarkdown} />,
  parameters: {
    docs: {
      description: {
        story: 'All heading levels (h1-h6) rendered with proper styling.',
      },
    },
  },
};

export const Lists: Story = {
  render: () => <MarkdownViewerDemo content={listsMarkdown} />,
  parameters: {
    docs: {
      description: {
        story: 'Various list types: unordered, ordered, and checklists.',
      },
    },
  },
};

export const CodeBlocks: Story = {
  render: () => <MarkdownViewerDemo content={codeBlocksMarkdown} />,
  parameters: {
    docs: {
      description: {
        story: 'Code blocks with different language syntax highlighting.',
      },
    },
  },
};

export const EmptyContent: Story = {
  render: () => <MarkdownViewerDemo content="" />,
  parameters: {
    docs: {
      description: {
        story: 'How the viewer handles empty markdown content.',
      },
    },
  },
};

export const PlainText: Story = {
  render: () => (
    <MarkdownViewerDemo content="This is just plain text without any markdown formatting." />
  ),
  parameters: {
    docs: {
      description: {
        story: 'Plain text without markdown formatting is rendered as a paragraph.',
      },
    },
  },
};
