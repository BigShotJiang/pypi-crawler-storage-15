import { useState, useEffect, useMemo, useCallback, useRef } from "react";
import { File, Folder, ChevronRight, Plus, Trash2, FolderPlus, FilePlus, MoreVertical } from "lucide-react";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export interface FileItem {
  name: string;
  path: string;
  type: "file" | "directory";
  size?: number;
  children?: FileItem[];
}

interface FileTreeCallbacks {
  onDeleteFile?: (path: string) => void;
  onCreateFile?: (folderPath: string) => void;
  onCreateFolder?: (folderPath: string) => void;
}

interface TreeProps {
  item: FileItem;
  selectedFile: string | null;
  focusedPath: string | null;
  onSelectFile: (path: string) => void;
  onFocusPath: (path: string) => void;
  callbacks?: FileTreeCallbacks;
  level?: number;
  expandedPaths: Set<string>;
  onToggleExpand: (path: string) => void;
}

function Tree({ item, selectedFile, focusedPath, onSelectFile, onFocusPath, callbacks, level = 0, expandedPaths, onToggleExpand }: TreeProps) {
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const isDir = item.type === "directory";
  const isSelected = selectedFile === item.path;
  const isFocused = focusedPath === item.path;
  const isExpanded = expandedPaths.has(item.path);
  const paddingLeft = level * 12;

  if (!isDir) {
    return (
      <>
        <div
          data-path={item.path}
          className={cn(
            "group/file relative flex items-center gap-2 px-2 py-1.5 pr-8 text-sm cursor-pointer rounded-sm hover:bg-accent/50 whitespace-nowrap",
            isSelected && !isFocused && "bg-accent/40 text-accent-foreground",
            isFocused && "bg-accent text-accent-foreground ring-1 ring-accent-foreground/20"
          )}
          style={{ paddingLeft: `${paddingLeft + 24}px` }}
          onClick={() => {
            onFocusPath(item.path);
            onSelectFile(item.path);
          }}
        >
          <File className="h-4 w-4 shrink-0 text-muted-foreground" />
          <span className="truncate">{item.name}</span>
          {callbacks?.onDeleteFile && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button
                  className="absolute right-1 top-1/2 -translate-y-1/2 h-6 w-6 flex items-center justify-center rounded opacity-0 group-hover/file:opacity-100 hover:bg-accent transition-opacity"
                  onClick={(e) => e.stopPropagation()}
                >
                  <MoreVertical className="h-3.5 w-3.5" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem
                  className="text-destructive focus:text-destructive"
                  onClick={() => setDeleteDialogOpen(true)}
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>

        <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete file</AlertDialogTitle>
              <AlertDialogDescription>
                Are you sure you want to delete "{item.name}"? This action cannot be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                onClick={() => callbacks?.onDeleteFile?.(item.path)}
              >
                Delete
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </>
    );
  }

  return (
    <Collapsible
      className="group/collapsible"
      open={isExpanded}
      onOpenChange={() => onToggleExpand(item.path)}
    >
      <div
        data-path={item.path}
        className={cn(
          "group/folder relative flex items-center rounded-sm",
          isSelected && !isFocused && "bg-accent/40",
          isFocused && "bg-accent ring-1 ring-accent-foreground/20"
        )}
        style={{ paddingLeft: `${paddingLeft}px` }}
      >
        <CollapsibleTrigger asChild>
          <button
            className="flex items-center gap-1 px-2 py-1.5 text-sm cursor-pointer rounded-sm hover:bg-accent/50 flex-1 whitespace-nowrap"
            onClick={() => {
              onFocusPath(item.path);
              onSelectFile(item.path);
            }}
          >
            <ChevronRight className={cn(
              "h-4 w-4 shrink-0 transition-transform",
              isExpanded && "rotate-90"
            )} />
            <Folder className="h-4 w-4 shrink-0 text-muted-foreground" />
            <span className="truncate">{item.name}</span>
          </button>
        </CollapsibleTrigger>
        {(callbacks?.onCreateFile || callbacks?.onCreateFolder) && (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="absolute right-1 h-5 w-5 opacity-0 group-hover/folder:opacity-100"
                onClick={(e) => e.stopPropagation()}
              >
                <Plus className="h-3 w-3" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              {callbacks?.onCreateFile && (
                <DropdownMenuItem onClick={() => callbacks.onCreateFile!(item.path)}>
                  <FilePlus className="h-4 w-4 mr-2" />
                  New File
                </DropdownMenuItem>
              )}
              {callbacks?.onCreateFolder && (
                <DropdownMenuItem onClick={() => callbacks.onCreateFolder!(item.path)}>
                  <FolderPlus className="h-4 w-4 mr-2" />
                  New Folder
                </DropdownMenuItem>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        )}
      </div>
      <CollapsibleContent>
        {item.children?.map((child) => (
          <Tree
            key={child.path}
            item={child}
            selectedFile={selectedFile}
            focusedPath={focusedPath}
            onSelectFile={onSelectFile}
            onFocusPath={onFocusPath}
            callbacks={callbacks}
            level={level + 1}
            expandedPaths={expandedPaths}
            onToggleExpand={onToggleExpand}
          />
        ))}
      </CollapsibleContent>
    </Collapsible>
  );
}

interface FileTreeProps {
  files: FileItem[];
  selectedFile: string | null;
  onSelectFile: (path: string) => void;
  onDeleteFile?: (path: string) => void;
  onCreateFile?: (folderPath: string) => void;
  onCreateFolder?: (folderPath: string) => void;
  label?: string;
}

// Helper to get all parent paths for a file path
function getParentPaths(filePath: string): string[] {
  const parts = filePath.split("/");
  const parents: string[] = [];
  for (let i = 1; i < parts.length; i++) {
    parents.push(parts.slice(0, i).join("/"));
  }
  return parents;
}

export function FileTree({
  files,
  selectedFile,
  onSelectFile,
  onDeleteFile,
  onCreateFile,
  onCreateFolder,
  label = "Files",
}: FileTreeProps) {
  const [expandedPaths, setExpandedPaths] = useState<Set<string>>(new Set());
  const [focusedPath, setFocusedPath] = useState<string | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const callbacks: FileTreeCallbacks = {
    onDeleteFile,
    onCreateFile,
    onCreateFolder,
  };

  // Build tree structure from flat file list
  const tree = useMemo(() => {
    const buildTree = (items: FileItem[]): FileItem[] => {
      const map = new Map<string, FileItem>();
      const roots: FileItem[] = [];

      // First pass: create all nodes
      items.forEach((item) => {
        map.set(item.path, { ...item, children: [] });
      });

      // Second pass: build parent-child relationships
      items.forEach((item) => {
        const node = map.get(item.path)!;
        const lastSlash = item.path.lastIndexOf("/");

        if (lastSlash === -1) {
          // Root level item
          roots.push(node);
        } else {
          const parentPath = item.path.substring(0, lastSlash);
          const parent = map.get(parentPath);
          if (parent) {
            parent.children = parent.children || [];
            parent.children.push(node);
          } else {
            // Parent not in map, treat as root
            roots.push(node);
          }
        }
      });

      // Sort: directories first, then alphabetically
      const sortItems = (items: FileItem[]): FileItem[] => {
        return items.sort((a, b) => {
          if (a.type !== b.type) {
            return a.type === "directory" ? -1 : 1;
          }
          return a.name.localeCompare(b.name);
        }).map((item) => ({
          ...item,
          children: item.children ? sortItems(item.children) : undefined,
        }));
      };

      return sortItems(roots);
    };

    return buildTree(files);
  }, [files]);

  // Get flat list of visible paths for keyboard navigation
  const visiblePaths = useMemo(() => {
    const paths: string[] = [];
    const traverse = (items: FileItem[]) => {
      for (const item of items) {
        paths.push(item.path);
        if (item.type === "directory" && expandedPaths.has(item.path) && item.children) {
          traverse(item.children);
        }
      }
    };
    traverse(tree);
    return paths;
  }, [tree, expandedPaths]);

  // Auto-expand to selected file when it changes
  useEffect(() => {
    if (selectedFile) {
      const parents = getParentPaths(selectedFile);
      setExpandedPaths((prev) => {
        const newSet = new Set(prev);
        // Expand all parent folders
        parents.forEach((p) => newSet.add(p));
        // If selected item is a directory, expand it too
        const selectedItem = files.find(f => f.path === selectedFile);
        if (selectedItem?.type === "directory") {
          newSet.add(selectedFile);
        }
        return newSet;
      });
    }
  }, [selectedFile, files]);

  const handleToggleExpand = (path: string) => {
    setExpandedPaths((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(path)) {
        newSet.delete(path);
      } else {
        newSet.add(path);
      }
      return newSet;
    });
  };

  // Keyboard navigation handler
  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (visiblePaths.length === 0) return;

    const currentIndex = focusedPath ? visiblePaths.indexOf(focusedPath) : -1;

    switch (e.key) {
      case "ArrowDown": {
        e.preventDefault();
        const nextIndex = currentIndex < visiblePaths.length - 1 ? currentIndex + 1 : 0;
        const nextPath = visiblePaths[nextIndex];
        setFocusedPath(nextPath);
        onSelectFile(nextPath);
        // Auto-expand directories
        const nextItem = files.find(f => f.path === nextPath);
        if (nextItem?.type === "directory" && !expandedPaths.has(nextPath)) {
          handleToggleExpand(nextPath);
        }
        break;
      }
      case "ArrowUp": {
        e.preventDefault();
        const prevIndex = currentIndex > 0 ? currentIndex - 1 : visiblePaths.length - 1;
        const prevPath = visiblePaths[prevIndex];
        setFocusedPath(prevPath);
        onSelectFile(prevPath);
        // Auto-expand directories
        const prevItem = files.find(f => f.path === prevPath);
        if (prevItem?.type === "directory" && !expandedPaths.has(prevPath)) {
          handleToggleExpand(prevPath);
        }
        break;
      }
      case "Enter":
      case " ": {
        e.preventDefault();
        if (focusedPath) {
          onSelectFile(focusedPath);
        }
        break;
      }
      case "ArrowRight": {
        e.preventDefault();
        if (focusedPath) {
          // Find item to check if directory
          const item = files.find(f => f.path === focusedPath);
          if (item?.type === "directory" && !expandedPaths.has(focusedPath)) {
            handleToggleExpand(focusedPath);
          }
        }
        break;
      }
      case "ArrowLeft": {
        e.preventDefault();
        if (focusedPath) {
          // Find item to check if directory
          const item = files.find(f => f.path === focusedPath);
          if (item?.type === "directory" && expandedPaths.has(focusedPath)) {
            handleToggleExpand(focusedPath);
          } else {
            // Navigate to parent
            const parentPath = focusedPath.substring(0, focusedPath.lastIndexOf("/"));
            if (parentPath && visiblePaths.includes(parentPath)) {
              setFocusedPath(parentPath);
              onSelectFile(parentPath);
            }
          }
        }
        break;
      }
    }
  }, [focusedPath, visiblePaths, onSelectFile, files, expandedPaths]);

  // Clear focus when clicking outside
  const handleBlur = useCallback(() => {
    // Delay to allow click events to fire first
    setTimeout(() => {
      if (!containerRef.current?.contains(document.activeElement)) {
        setFocusedPath(null);
      }
    }, 0);
  }, []);

  return (
    <div
      ref={containerRef}
      className="text-sm outline-none"
      tabIndex={0}
      onKeyDown={handleKeyDown}
      onBlur={handleBlur}
      onFocus={() => {
        // Set initial focus to selected file or first item
        if (!focusedPath && visiblePaths.length > 0) {
          setFocusedPath(selectedFile || visiblePaths[0]);
        }
      }}
    >
      {label && (
        <div className="flex items-center justify-between px-2 py-1">
          <span className="text-xs uppercase tracking-wider text-muted-foreground font-medium">
            {label}
          </span>
          <div className="flex gap-1">
            {onCreateFile && (
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6"
                onClick={() => onCreateFile("")}
                title="New File"
              >
                <FilePlus className="h-3.5 w-3.5" />
              </Button>
            )}
            {onCreateFolder && (
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6"
                onClick={() => onCreateFolder("")}
                title="New Folder"
              >
                <FolderPlus className="h-3.5 w-3.5" />
              </Button>
            )}
          </div>
        </div>
      )}
      <div>
        {tree.length === 0 ? (
          <div className="text-muted-foreground p-4 text-center text-sm">
            No files in project
          </div>
        ) : (
          tree.map((item) => (
            <Tree
              key={item.path}
              item={item}
              selectedFile={selectedFile}
              focusedPath={focusedPath}
              onSelectFile={onSelectFile}
              onFocusPath={setFocusedPath}
              callbacks={callbacks}
              expandedPaths={expandedPaths}
              onToggleExpand={handleToggleExpand}
            />
          ))
        )}
      </div>
    </div>
  );
}
