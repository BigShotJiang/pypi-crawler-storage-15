import { MarkdownRenderer } from "./markdown-renderer";
import { StreamingToolCard } from "./tool-card";

interface StreamingToolEvent {
  id: number;
  tool: string;
  args: string;
  textBefore: string;
  result: string | null;
}

interface StreamingMessageProps {
  text: string;
  toolEvents: StreamingToolEvent[];
}

export function StreamingMessage({ text, toolEvents }: StreamingMessageProps) {
  return (
    <div className="text-foreground leading-relaxed mb-6">
      {/* Render tool events with their preceding text */}
      {toolEvents.map((toolEvent) => (
        <div key={toolEvent.id}>
          {toolEvent.textBefore && (
            <div className="mb-3">
              <MarkdownRenderer content={toolEvent.textBefore} />
            </div>
          )}
          <StreamingToolCard
            tool={toolEvent.tool}
            args={toolEvent.args}
            result={toolEvent.result}
          />
        </div>
      ))}

      {/* Render current streaming text (after all tools) */}
      {text && (
        <span>
          <MarkdownRenderer content={text} />
        </span>
      )}

      {/* Cursor */}
      <span className="animate-pulse-cursor opacity-70">▌</span>
    </div>
  );
}

export type { StreamingToolEvent };
