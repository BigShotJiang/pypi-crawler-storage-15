/**
 * ImprovePromptButton Component
 *
 * Button group with "Improve" and "Undo" buttons for prompt enhancement.
 */

import { useState, useCallback, useEffect } from "react";
import { Sparkles, Undo2, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface ImprovePromptButtonProps {
  value: string;
  onChange: (value: string) => void;
  onImprove: (prompt: string) => Promise<string | null>;
  isImproving: boolean;
  disabled?: boolean;
  className?: string;
}

export function ImprovePromptButton({
  value,
  onChange,
  onImprove,
  isImproving,
  disabled = false,
  className,
}: ImprovePromptButtonProps) {
  const [previousValue, setPreviousValue] = useState<string | null>(null);

  // Clear undo state when input is cleared (e.g., on submit)
  useEffect(() => {
    if (!value.trim()) {
      setPreviousValue(null);
    }
  }, [value]);

  const handleImprove = useCallback(async () => {
    if (!value.trim() || isImproving) return;

    // Store current value for undo
    setPreviousValue(value);

    const improved = await onImprove(value);
    if (improved) {
      onChange(improved);
    } else {
      // If improvement failed, clear the previous value so undo isn't shown
      setPreviousValue(null);
    }
  }, [value, isImproving, onImprove, onChange]);

  const handleUndo = useCallback(() => {
    if (previousValue !== null) {
      onChange(previousValue);
      setPreviousValue(null);
    }
  }, [previousValue, onChange]);

  const canUndo = previousValue !== null && !isImproving;
  const canImprove = value.trim().length > 0 && !disabled;

  return (
    <div className={cn("flex items-center gap-0.5", className)}>
      <Button
        type="button"
        variant="ghost"
        size="sm"
        onClick={handleImprove}
        disabled={!canImprove || isImproving}
        className={cn(
          "h-7 px-2 text-xs gap-1",
          canImprove && !isImproving
            ? "text-accent hover:text-accent hover:bg-accent/10"
            : "text-muted-foreground",
          canUndo && "rounded-r-none"
        )}
        title="Improve prompt with AI"
      >
        {isImproving ? (
          <Loader2 className="h-3 w-3 animate-spin" />
        ) : (
          <Sparkles className="h-3 w-3" />
        )}
        <span>Improve</span>
      </Button>
      {canUndo && (
        <Button
          type="button"
          variant="ghost"
          size="sm"
          onClick={handleUndo}
          className="h-7 px-2 text-xs gap-1 text-accent hover:text-accent hover:bg-accent/10 rounded-l-none border-l border-accent/30"
          title="Undo improvement"
        >
          <Undo2 className="h-3 w-3" />
        </Button>
      )}
    </div>
  );
}
