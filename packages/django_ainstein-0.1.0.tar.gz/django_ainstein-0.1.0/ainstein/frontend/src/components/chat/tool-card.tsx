import { useState } from "react";
import { Zap, ChevronDown, ChevronRight, Loader2, Check } from "lucide-react";
import { cn } from "@/lib/utils";

interface ToolEvent {
  type: string;
  tool?: string;
  args?: string;
  result?: string;
  text?: string;
  sql?: string;
  data_preview?: Record<string, unknown>[];
}

interface ToolCardProps {
  event: ToolEvent;
}

export function ToolCard({ event }: ToolCardProps) {
  const [collapsed, setCollapsed] = useState(false);

  return (
    <div className="bg-secondary border border-border rounded-lg my-3 overflow-hidden">
      <div
        onClick={() => setCollapsed(!collapsed)}
        className={cn(
          "flex items-center gap-2 px-3 py-2.5 bg-muted cursor-pointer",
          !collapsed && "border-b border-border"
        )}
      >
        <Zap className="h-3.5 w-3.5 text-orange-400 fill-orange-400" />
        <span className="text-orange-400 font-semibold text-xs">{event.tool}</span>
        {event.args && (
          <span className="text-muted-foreground text-xs">({event.args})</span>
        )}
        <span className="ml-auto text-muted-foreground text-[10px]">
          {collapsed ? <ChevronRight className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
        </span>
      </div>

      {!collapsed && (
        <div className="p-3">
          {event.sql && (
            <div className="bg-muted rounded p-2 mb-2 text-[11px] text-muted-foreground whitespace-pre-wrap overflow-auto">
              {event.sql}
            </div>
          )}

          {event.data_preview && event.data_preview.length > 0 && (
            <div className="text-[11px] mb-2">
              {event.data_preview.slice(0, 5).map((row, i) => (
                <div
                  key={i}
                  className="text-muted-foreground py-1 border-b border-border"
                >
                  {Object.entries(row)
                    .map(([k, v]) => `${k}=${v}`)
                    .join(", ")}
                </div>
              ))}
              {event.data_preview.length > 5 && (
                <div className="text-muted-foreground italic pt-1">
                  ... and {event.data_preview.length - 5} more rows
                </div>
              )}
            </div>
          )}

          {event.result && (
            <div className="flex items-center gap-1.5 text-secondary-foreground text-xs">
              <Check className="h-3 w-3 text-green-400" />
              <span>{event.result}</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

interface StreamingToolCardProps {
  tool: string;
  args: string;
  result: string | null;
}

export function StreamingToolCard({ tool, args, result }: StreamingToolCardProps) {
  return (
    <div className="bg-secondary border border-border rounded-lg my-3 overflow-hidden">
      <div className="flex items-center gap-2 px-3 py-2.5 bg-muted">
        <Zap className="h-3.5 w-3.5 text-orange-400 fill-orange-400" />
        <span className="text-orange-400 font-semibold text-xs">{tool}</span>
        {args && <span className="text-muted-foreground text-xs">({args})</span>}
        {result ? (
          <span className="ml-auto flex items-center gap-1.5 text-green-400 text-xs">
            <Check className="h-3 w-3" />
            <span>{result}</span>
          </span>
        ) : (
          <Loader2 className="ml-auto h-3.5 w-3.5 animate-spin text-muted-foreground" />
        )}
      </div>
    </div>
  );
}

export type { ToolEvent };
