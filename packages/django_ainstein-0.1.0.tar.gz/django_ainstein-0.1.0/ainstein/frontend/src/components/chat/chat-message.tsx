import { useState } from "react";
import { Copy, Check, Pencil } from "lucide-react";
import { Button } from "@/components/ui/button";
import { MarkdownRenderer } from "./markdown-renderer";
import { ToolCard, type ToolEvent } from "./tool-card";

interface Message {
  id: number;
  role: "user" | "assistant" | "system";
  content: string;
  metadata?: {
    events?: ToolEvent[];
    cancelled?: boolean;
  };
}

interface UserMessageProps {
  message: Message;
  onReplay?: (id: number, content: string) => void;
}

export function UserMessage({ message, onReplay }: UserMessageProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(message.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <div className="flex justify-end mb-4">
      <div className="max-w-[620px]">
        <div className="bg-muted border border-border rounded-2xl rounded-br-sm px-4 py-3 text-foreground whitespace-pre-wrap break-words">
          {message.content}
        </div>
        <div className="flex gap-1 mt-2 justify-end opacity-50 hover:opacity-100 transition-opacity">
          {onReplay && (
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7"
              onClick={() => onReplay(message.id, message.content)}
              title="Edit & Resend"
            >
              <Pencil className="h-3.5 w-3.5" />
            </Button>
          )}
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7"
            onClick={handleCopy}
            title="Copy"
          >
            {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
          </Button>
        </div>
      </div>
    </div>
  );
}

interface AssistantMessageProps {
  message: Message;
}

export function AssistantMessage({ message }: AssistantMessageProps) {
  const [copied, setCopied] = useState(false);
  const events = message.metadata?.events || [];

  const handleCopy = () => {
    navigator.clipboard.writeText(message.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <div className="mb-6">
      {events.map((event, index) => {
        if (event.type === "text" && event.text) {
          return (
            <div key={index} className="text-foreground leading-relaxed mb-3">
              <MarkdownRenderer content={event.text} />
            </div>
          );
        } else if (event.type === "tool") {
          return <ToolCard key={index} event={event} />;
        }
        return null;
      })}

      {events.length === 0 && message.content && (
        <div className="text-foreground leading-relaxed">
          <MarkdownRenderer content={message.content} />
        </div>
      )}

      {message.metadata?.cancelled && (
        <div className="text-yellow-400 text-[11px] mt-2">
          ⚠ Response stopped by user
        </div>
      )}

      <div className="flex gap-1 mt-2 opacity-50 hover:opacity-100 transition-opacity">
        <Button
          variant="ghost"
          size="icon"
          className="h-7 w-7"
          onClick={handleCopy}
          title="Copy"
        >
          {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
        </Button>
      </div>
    </div>
  );
}

export type { Message };
