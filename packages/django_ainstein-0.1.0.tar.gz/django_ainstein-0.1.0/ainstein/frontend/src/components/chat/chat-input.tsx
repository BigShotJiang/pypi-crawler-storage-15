/**
 * ChatInput Component
 *
 * Chat input using ai-elements PromptInput with stop/send controls.
 * Uses PromptInputController for state - parent must wrap in PromptInputProvider
 * and use usePromptInputController() to set/clear input.
 */

import { useRef, useCallback, useEffect } from "react";
import { Square, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  PromptInput,
  PromptInputTextarea,
  PromptInputFooter,
  PromptInputTools,
  PromptInputSubmit,
  usePromptInputController,
} from "@/components/ai-elements/prompt-input";
import { ImprovePromptButton } from "./improve-prompt-button";

interface ChatInputProps {
  onSend: (message: string) => void;
  onStop?: () => void;
  isProcessing: boolean;
  isStopping?: boolean;
  placeholder?: string;
  /** Key that triggers focus when changed (e.g., conversationId) */
  focusKey?: string;
  /** Callback to improve the prompt - enables the improve button when provided */
  onImprovePrompt?: (prompt: string) => Promise<string | null>;
  /** Whether the prompt is currently being improved */
  isImproving?: boolean;
}

export function ChatInput({
  onSend,
  onStop,
  isProcessing,
  isStopping = false,
  placeholder = "Type a message...",
  focusKey,
  onImprovePrompt,
  isImproving = false,
}: ChatInputProps) {
  const { textInput } = usePromptInputController();
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const wasStoppingRef = useRef(false);

  // Focus input when focusKey changes (e.g., conversation switch)
  useEffect(() => {
    if (focusKey) {
      const timer = setTimeout(() => {
        textareaRef.current?.focus();
      }, 100);
      return () => clearTimeout(timer);
    }
  }, [focusKey]);

  // Refocus input after stopping completes
  useEffect(() => {
    if (wasStoppingRef.current && !isStopping && !isProcessing) {
      textareaRef.current?.focus();
      wasStoppingRef.current = false;
    }
    if (isStopping) {
      wasStoppingRef.current = true;
    }
  }, [isStopping, isProcessing]);

  // Handle Escape key to stop generation (document-level to not interfere with textarea)
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape" && isProcessing && onStop) {
        onStop();
      }
    };
    document.addEventListener("keydown", handleEscape);
    return () => document.removeEventListener("keydown", handleEscape);
  }, [isProcessing, onStop]);

  const handleSubmit = useCallback(() => {
    if (isProcessing && onStop) {
      onStop();
    } else if (!isProcessing && textInput.value.trim()) {
      const message = textInput.value.trim();
      textInput.clear();
      onSend(message);
    }
  }, [isProcessing, onStop, onSend, textInput]);

  return (
    <div onClick={() => textareaRef.current?.focus()} className="cursor-text p-3">
      <PromptInput
        onSubmit={handleSubmit}
        className="rounded-lg border border-border bg-card"
      >
        <PromptInputTextarea
          ref={textareaRef}
          placeholder={placeholder}
          disabled={isStopping || isImproving}
          className="min-h-[52px] rounded-lg resize-none border-0 bg-transparent focus-visible:ring-0"
          data-testid="message-input"
        />
        <PromptInputFooter className="p-2 pt-0">
          <PromptInputTools>
            {onImprovePrompt && (
              <ImprovePromptButton
                value={textInput.value}
                onChange={(newValue) => textInput.setInput(newValue)}
                onImprove={onImprovePrompt}
                isImproving={isImproving}
                disabled={isStopping}
              />
            )}
          </PromptInputTools>
          {isProcessing ? (
            <Button
              type="button"
              variant="destructive"
              size="icon"
              onClick={(e) => {
                e.preventDefault();
                onStop?.();
              }}
              disabled={isStopping}
              className="shrink-0 h-[32px] w-[32px] rounded-md"
              data-testid="stop-button"
            >
              {isStopping ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Square className="h-4 w-4 fill-current" />
              )}
            </Button>
          ) : (
            <PromptInputSubmit
              disabled={!textInput.value.trim() || isImproving}
              status="ready"
              data-testid="send-button"
            />
          )}
        </PromptInputFooter>
      </PromptInput>
    </div>
  );
}
