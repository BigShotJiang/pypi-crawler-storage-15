// Legacy exports - kept for backward compatibility
export { UserMessage, AssistantMessage, type Message } from "./chat-message";
export { StreamingMessage, type StreamingToolEvent } from "./streaming-message";
export { LoadingIndicator } from "./loading-indicator";
export { ToolCard, StreamingToolCard, type ToolEvent } from "./tool-card";
export { MarkdownRenderer } from "./markdown-renderer";

// Main exports
export { ChatInput } from "./chat-input";
export { EditableInput } from "./editable-input";
export { ImprovePromptButton } from "./improve-prompt-button";
