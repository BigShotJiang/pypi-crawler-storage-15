/**
 * EditableInput Component
 *
 * Reusable input component with optional improve prompt functionality.
 * Used by both ChatInput (main input) and inline edit dialogs.
 */

import { useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { ImprovePromptButton } from "./improve-prompt-button";
import { cn } from "@/lib/utils";

interface EditableInputProps {
  value: string;
  onChange: (value: string) => void;
  onSubmit: () => void;
  onCancel?: () => void;
  placeholder?: string;
  disabled?: boolean;
  autoFocus?: boolean;
  /** Callback to improve the prompt - enables the improve button when provided */
  onImprovePrompt?: (prompt: string) => Promise<string | null>;
  /** Whether the prompt is currently being improved */
  isImproving?: boolean;
  /** Submit button text */
  submitLabel?: string;
  /** Cancel button text */
  cancelLabel?: string;
  className?: string;
}

export function EditableInput({
  value,
  onChange,
  onSubmit,
  onCancel,
  placeholder = "Type a message...",
  disabled = false,
  autoFocus = true,
  onImprovePrompt,
  isImproving = false,
  submitLabel = "Send",
  cancelLabel = "Cancel",
  className,
}: EditableInputProps) {
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Auto-resize textarea and focus when mounted
  useEffect(() => {
    if (autoFocus && textareaRef.current) {
      textareaRef.current.focus();
    }
  }, [autoFocus]);

  // Auto-resize on content change
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
      textareaRef.current.style.height = `${textareaRef.current.scrollHeight}px`;
    }
  }, [value]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      if (value.trim() && !isImproving) {
        onSubmit();
      }
    } else if (e.key === "Escape" && onCancel) {
      onCancel();
    }
  };

  const isDisabled = disabled || isImproving;
  const canSubmit = value.trim().length > 0 && !isDisabled;

  return (
    <div className={cn("bg-secondary rounded-lg p-3 input-focus-glow", className)}>
      <textarea
        ref={textareaRef}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onKeyDown={handleKeyDown}
        className="w-full bg-transparent resize-none outline-none text-foreground min-h-[60px]"
        placeholder={placeholder}
        disabled={isDisabled}
      />
      <div className="flex justify-between items-center mt-3">
        <div>
          {onImprovePrompt && (
            <ImprovePromptButton
              value={value}
              onChange={onChange}
              onImprove={onImprovePrompt}
              isImproving={isImproving}
              disabled={disabled}
            />
          )}
        </div>
        <div className="flex gap-2">
          {onCancel && (
            <Button
              variant="ghost"
              size="sm"
              onClick={onCancel}
              disabled={isImproving}
            >
              {cancelLabel}
            </Button>
          )}
          <Button
            size="sm"
            onClick={onSubmit}
            disabled={!canSubmit}
            className="bg-accent hover:bg-accent/90 text-accent-foreground"
          >
            {submitLabel}
          </Button>
        </div>
      </div>
    </div>
  );
}
