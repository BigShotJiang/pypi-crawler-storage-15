/**
 * Image component with fullscreen dialog support
 */

import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogTitle,
} from "@/components/ui/dialog";
import { cn } from "@/lib/utils";
import { MaximizeIcon } from "lucide-react";
import type { ComponentProps } from "react";

export type ImageWithFullscreenProps = Omit<ComponentProps<"img">, "onClick"> & {
  /** Title shown in fullscreen dialog */
  title?: string;
};

export const ImageWithFullscreen = ({
  className,
  title,
  alt,
  ...props
}: ImageWithFullscreenProps) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <div className="relative group">
        <img
          className={cn("cursor-pointer", className)}
          alt={alt}
          onClick={() => setIsOpen(true)}
          {...props}
        />
        <button
          onClick={() => setIsOpen(true)}
          className="absolute top-2 right-2 p-1.5 rounded-md bg-black/50 text-white opacity-0 group-hover:opacity-100 transition-opacity hover:bg-black/70"
          aria-label="View fullscreen"
        >
          <MaximizeIcon className="size-4" />
        </button>
      </div>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-[90vw] max-h-[90vh] p-2">
          <DialogTitle className="sr-only">{title || alt || "Image"}</DialogTitle>
          <img
            src={props.src}
            alt={alt}
            className="max-w-full max-h-[85vh] object-contain mx-auto"
          />
        </DialogContent>
      </Dialog>
    </>
  );
};
