/**
 * Tests for DataTable component
 */

import { describe, it, expect, vi } from 'vitest';
import { render, screen, within } from '@/test/utils';
import userEvent from '@testing-library/user-event';
import { DataTable, formatters } from './data-table';

// Sample test data
const sampleData = [
  { id: 1, name: 'Alice', age: 30, active: true },
  { id: 2, name: 'Bob', age: 25, active: false },
  { id: 3, name: 'Charlie', age: 35, active: true },
];

const largeData = Array.from({ length: 50 }, (_, i) => ({
  id: i + 1,
  name: `User ${i + 1}`,
  value: i * 100,
}));

describe('DataTable', () => {
  describe('rendering', () => {
    it('renders table with data', () => {
      render(<DataTable data={sampleData} />);

      expect(screen.getByText('Alice')).toBeInTheDocument();
      expect(screen.getByText('Bob')).toBeInTheDocument();
      expect(screen.getByText('Charlie')).toBeInTheDocument();
    });

    it('renders empty state when no data', () => {
      render(<DataTable data={[]} />);

      expect(screen.getByText('No results')).toBeInTheDocument();
    });

    it('auto-generates columns from data keys', () => {
      render(<DataTable data={sampleData} />);

      // Column headers should be visible
      expect(screen.getByText('id')).toBeInTheDocument();
      expect(screen.getByText('name')).toBeInTheDocument();
      expect(screen.getByText('age')).toBeInTheDocument();
      expect(screen.getByText('active')).toBeInTheDocument();
    });

    it('renders null values with muted styling', () => {
      const dataWithNull = [{ id: 1, name: null }];
      render(<DataTable data={dataWithNull} />);

      expect(screen.getByText('null')).toBeInTheDocument();
    });

    it('renders boolean values as strings', () => {
      render(<DataTable data={sampleData} />);

      // Use getAllByText since 'true' appears multiple times (2 rows with active=true)
      const trueValues = screen.getAllByText('true');
      const falseValues = screen.getAllByText('false');

      expect(trueValues.length).toBeGreaterThanOrEqual(1);
      expect(falseValues.length).toBeGreaterThanOrEqual(1);
    });

    it('renders object values as JSON strings', () => {
      const dataWithObject = [{ id: 1, meta: { key: 'value' } }];
      render(<DataTable data={dataWithObject} />);

      expect(screen.getByText('{"key":"value"}')).toBeInTheDocument();
    });

    it('applies custom className', () => {
      const { container } = render(
        <DataTable data={sampleData} className="custom-table-class" />
      );

      expect(container.querySelector('.custom-table-class')).toBeInTheDocument();
    });
  });

  describe('sorting', () => {
    it('sorts column ascending on first click', async () => {
      const user = userEvent.setup();
      render(<DataTable data={sampleData} />);

      // Click on name column header to sort
      const nameHeader = screen.getByText('name');
      await user.click(nameHeader);

      // Get all name cells (excluding header)
      const rows = screen.getAllByRole('row').slice(1); // Skip header row
      const names = rows.map(row => {
        const cells = within(row).getAllByRole('cell');
        return cells[1]?.textContent; // name is second column
      });

      // Should be sorted alphabetically ascending
      expect(names).toEqual(['Alice', 'Bob', 'Charlie']);
    });

    it('sorts column descending on second click', async () => {
      const user = userEvent.setup();
      render(<DataTable data={sampleData} />);

      const nameHeader = screen.getByText('name');

      // Click twice for descending
      await user.click(nameHeader);
      await user.click(nameHeader);

      const rows = screen.getAllByRole('row').slice(1);
      const names = rows.map(row => {
        const cells = within(row).getAllByRole('cell');
        return cells[1]?.textContent;
      });

      // Should be sorted alphabetically descending
      expect(names).toEqual(['Charlie', 'Bob', 'Alice']);
    });

    it('shows sort indicator icons', async () => {
      const user = userEvent.setup();
      const { container } = render(<DataTable data={sampleData} />);

      // Initially should show unsorted icon (ArrowUpDown)
      expect(container.querySelectorAll('.opacity-50').length).toBeGreaterThan(0);

      // Click to sort
      const nameHeader = screen.getByText('name');
      await user.click(nameHeader);

      // Should now have a sorting indicator (no opacity-50 on sorted column)
    });
  });

  describe('pagination', () => {
    it('shows pagination controls', () => {
      render(<DataTable data={largeData} defaultPageSize={10} />);

      expect(screen.getByText('Rows per page')).toBeInTheDocument();
      expect(screen.getByText('1-10 of 50')).toBeInTheDocument();
    });

    it('navigates to next page', async () => {
      const user = userEvent.setup();
      render(<DataTable data={largeData} defaultPageSize={10} />);

      // Click next page
      const nextButton = screen.getByText('›');
      await user.click(nextButton);

      expect(screen.getByText('11-20 of 50')).toBeInTheDocument();
    });

    it('navigates to previous page', async () => {
      const user = userEvent.setup();
      render(<DataTable data={largeData} defaultPageSize={10} />);

      // Go to page 2, then back
      const nextButton = screen.getByText('›');
      await user.click(nextButton);

      const prevButton = screen.getByText('‹');
      await user.click(prevButton);

      expect(screen.getByText('1-10 of 50')).toBeInTheDocument();
    });

    it('disables previous button on first page', () => {
      render(<DataTable data={largeData} defaultPageSize={10} />);

      const prevButton = screen.getByText('‹');
      expect(prevButton).toBeDisabled();
    });

    it('disables next button on last page', async () => {
      const user = userEvent.setup();
      render(<DataTable data={largeData} defaultPageSize={25} />);

      // Navigate to last page
      const nextButton = screen.getByText('›');
      await user.click(nextButton);

      expect(nextButton).toBeDisabled();
    });

    // Note: Radix Select component has jsdom compatibility issues (hasPointerCapture)
    // This test is skipped in favor of E2E testing
    it.skip('changes page size via select', async () => {
      const user = userEvent.setup();
      render(<DataTable data={largeData} defaultPageSize={25} pageSizeOptions={[5, 10, 25]} />);

      // Open the page size select
      const trigger = screen.getByRole('combobox');
      await user.click(trigger);

      // Select 5 rows per page
      const option = screen.getByRole('option', { name: '5' });
      await user.click(option);

      // Should show 5 rows
      expect(screen.getByText('1-5 of 50')).toBeInTheDocument();
    });

    it('shows page indicator', () => {
      render(<DataTable data={largeData} defaultPageSize={10} />);

      // Should show "1 / 5" for page 1 of 5
      expect(screen.getByText('1 / 5')).toBeInTheDocument();
    });

    it('hides pagination buttons when only one page', () => {
      render(<DataTable data={sampleData} defaultPageSize={10} />);

      // Should not show prev/next buttons
      expect(screen.queryByText('‹')).not.toBeInTheDocument();
      expect(screen.queryByText('›')).not.toBeInTheDocument();
    });
  });

  describe('layout modes', () => {
    it('renders with rounded border in default mode', () => {
      const { container } = render(<DataTable data={sampleData} />);

      expect(container.querySelector('.rounded-md')).toBeInTheDocument();
    });

    it('renders with flex layout in fillHeight mode', () => {
      const { container } = render(<DataTable data={sampleData} fillHeight={true} />);

      expect(container.querySelector('.flex.flex-col')).toBeInTheDocument();
    });

    it('applies maxVisibleRows height constraint', () => {
      const { container } = render(
        <DataTable data={largeData} maxVisibleRows={5} defaultPageSize={50} />
      );

      // Should have a max-height style applied
      const scrollContainer = container.querySelector('.overflow-auto');
      expect(scrollContainer).toHaveStyle({ maxHeight: expect.any(String) });
    });
  });

  describe('custom columns', () => {
    it('uses provided columns instead of auto-generating', () => {
      const customColumns = [
        {
          accessorKey: 'name',
          header: 'Full Name',
          cell: ({ getValue }: { getValue: () => unknown }) => `Name: ${getValue()}`,
        },
      ];

      render(<DataTable data={sampleData} columns={customColumns as any} />);

      expect(screen.getByText('Full Name')).toBeInTheDocument();
      expect(screen.getByText('Name: Alice')).toBeInTheDocument();
    });
  });
});

describe('formatters', () => {
  describe('date formatter', () => {
    it('formats valid date string', () => {
      const result = formatters.date('2024-01-15');
      // Date parsing may vary by timezone, just check it contains expected parts
      expect(result).toMatch(/2024/);
      expect(result).toMatch(/1[45]/); // 14 or 15 depending on timezone
    });

    it('formats Date object', () => {
      const result = formatters.date(new Date(2024, 0, 15));
      expect(result).toMatch(/1\/15\/2024/);
    });

    it('returns original value for invalid date', () => {
      const result = formatters.date('not a date');
      expect(result).toBe('not a date');
    });
  });

  describe('datetime formatter', () => {
    it('formats date with time', () => {
      const result = formatters.datetime('2024-01-15T14:30:00');
      expect(result).toContain('2024');
    });

    it('returns original value for invalid datetime', () => {
      const result = formatters.datetime('invalid');
      expect(result).toBe('invalid');
    });
  });

  describe('number formatter', () => {
    it('formats number with thousands separator', () => {
      const result = formatters.number(1234567);
      expect(result).toBe('1,234,567');
    });

    it('formats string number', () => {
      const result = formatters.number('9999');
      expect(result).toBe('9,999');
    });
  });

  describe('currency formatter', () => {
    it('formats as USD currency', () => {
      const result = formatters.currency(1234.56);
      expect(result).toBe('$1,234.56');
    });

    it('handles negative amounts', () => {
      const result = formatters.currency(-500);
      expect(result).toMatch(/-?\$500\.00/);
    });
  });

  describe('percent formatter', () => {
    it('formats decimal as percentage', () => {
      const result = formatters.percent(0.75);
      expect(result).toBe('75.0%');
    });

    it('formats small decimals', () => {
      const result = formatters.percent(0.0123);
      expect(result).toBe('1.2%');
    });
  });
});

describe('DataTable with columnFormats', () => {
  it('applies formatters to specified columns', () => {
    const data = [
      { name: 'Product A', price: 1234.5, discount: 0.15 },
    ];

    render(
      <DataTable
        data={data}
        columnFormats={{
          price: 'currency',
          discount: 'percent',
        }}
      />
    );

    expect(screen.getByText('$1,234.50')).toBeInTheDocument();
    expect(screen.getByText('15.0%')).toBeInTheDocument();
  });

  it('handles date formatting in columns', () => {
    const data = [
      { event: 'Meeting', date: '2024-06-15' },
    ];

    render(
      <DataTable
        data={data}
        columnFormats={{
          date: 'date',
        }}
      />
    );

    // Date formatting varies by timezone, check for 2024 and month 6
    expect(screen.getByText(/6\/1[45]\/2024/)).toBeInTheDocument();
  });
});
