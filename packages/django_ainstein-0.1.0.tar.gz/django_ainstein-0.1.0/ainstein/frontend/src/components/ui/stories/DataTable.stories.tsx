import type { Meta, StoryObj } from '@storybook/react';
import { DataTable } from '../data-table';

const meta: Meta<typeof DataTable> = {
  title: 'UI/DataTable',
  component: DataTable,
  parameters: {
    layout: 'padded',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof DataTable>;

// Sample SQL query results
const userQueryResults = [
  { id: 1, name: 'John Doe', email: 'john@example.com', status: 'active', created_at: '2024-01-15' },
  { id: 2, name: 'Jane Smith', email: 'jane@example.com', status: 'active', created_at: '2024-01-16' },
  { id: 3, name: 'Bob Wilson', email: 'bob@example.com', status: 'inactive', created_at: '2024-01-17' },
  { id: 4, name: 'Alice Brown', email: 'alice@example.com', status: 'active', created_at: '2024-01-18' },
  { id: 5, name: 'Charlie Davis', email: 'charlie@example.com', status: 'pending', created_at: '2024-01-19' },
];

const orderQueryResults = [
  { order_id: 1001, customer: 'John Doe', total: 150.00, items: 3, status: 'shipped' },
  { order_id: 1002, customer: 'Jane Smith', total: 89.99, items: 1, status: 'delivered' },
  { order_id: 1003, customer: 'Bob Wilson', total: 245.50, items: 5, status: 'processing' },
  { order_id: 1004, customer: 'Alice Brown', total: 32.00, items: 2, status: 'shipped' },
];

const aggregateResults = [
  { category: 'Electronics', count: 1250, revenue: 125000.00, avg_price: 100.00 },
  { category: 'Clothing', count: 3200, revenue: 96000.00, avg_price: 30.00 },
  { category: 'Books', count: 890, revenue: 13350.00, avg_price: 15.00 },
  { category: 'Home & Garden', count: 450, revenue: 45000.00, avg_price: 100.00 },
];

export const UserQuery: Story = {
  args: {
    data: userQueryResults,
  },
};

export const OrderQuery: Story = {
  args: {
    data: orderQueryResults,
  },
};

export const AggregateQuery: Story = {
  args: {
    data: aggregateResults,
  },
};

export const WithPagination: Story = {
  args: {
    data: [
      ...userQueryResults,
      { id: 6, name: 'Diana Prince', email: 'diana@example.com', status: 'active', created_at: '2024-01-20' },
      { id: 7, name: 'Bruce Wayne', email: 'bruce@example.com', status: 'active', created_at: '2024-01-21' },
      { id: 8, name: 'Clark Kent', email: 'clark@example.com', status: 'inactive', created_at: '2024-01-22' },
      { id: 9, name: 'Peter Parker', email: 'peter@example.com', status: 'active', created_at: '2024-01-23' },
      { id: 10, name: 'Tony Stark', email: 'tony@example.com', status: 'active', created_at: '2024-01-24' },
      { id: 11, name: 'Steve Rogers', email: 'steve@example.com', status: 'active', created_at: '2024-01-25' },
      { id: 12, name: 'Natasha Romanoff', email: 'natasha@example.com', status: 'active', created_at: '2024-01-26' },
    ],
    defaultPageSize: 5,
  },
};

export const WithNullValues: Story = {
  args: {
    data: [
      { id: 1, name: 'John Doe', email: 'john@example.com', phone: null },
      { id: 2, name: 'Jane Smith', email: null, phone: '555-1234' },
      { id: 3, name: null, email: 'unknown@example.com', phone: null },
    ],
  },
};

export const WithBooleans: Story = {
  args: {
    data: [
      { id: 1, name: 'Feature A', enabled: true, beta: false },
      { id: 2, name: 'Feature B', enabled: false, beta: true },
      { id: 3, name: 'Feature C', enabled: true, beta: true },
    ],
  },
};

export const WithNestedObjects: Story = {
  args: {
    data: [
      { id: 1, name: 'Item 1', metadata: { tags: ['new', 'featured'], count: 5 } },
      { id: 2, name: 'Item 2', metadata: { tags: ['sale'], count: 12 } },
      { id: 3, name: 'Item 3', metadata: { tags: [], count: 0 } },
    ],
  },
};

export const EmptyResults: Story = {
  args: {
    data: [],
  },
};

export const SingleRow: Story = {
  args: {
    data: [
      { count: 42, total: 1337.50, avg: 31.84 },
    ],
  },
};

export const WideTable: Story = {
  args: {
    data: [
      {
        id: 1,
        first_name: 'John',
        last_name: 'Doe',
        email: 'john@example.com',
        phone: '555-1234',
        address: '123 Main St',
        city: 'New York',
        state: 'NY',
        zip: '10001',
        country: 'USA',
        created_at: '2024-01-15',
        updated_at: '2024-01-20',
      },
      {
        id: 2,
        first_name: 'Jane',
        last_name: 'Smith',
        email: 'jane@example.com',
        phone: '555-5678',
        address: '456 Oak Ave',
        city: 'Los Angeles',
        state: 'CA',
        zip: '90001',
        country: 'USA',
        created_at: '2024-01-16',
        updated_at: '2024-01-21',
      },
    ],
  },
};
