/**
 * DataTable Component
 *
 * A flexible data table with sorting, pagination, and multiple layout modes.
 *
 * LAYOUT MODES:
 *
 * 1. fillHeight={false} (DEFAULT) - Content-sized mode
 *    - Table sizes to its content
 *    - Has rounded border
 *    - Use for: ToolCard, inline displays, cards
 *    - Optional: maxVisibleRows to limit height with scrollbar
 *
 * 2. fillHeight={true} - Full-height mode
 *    - Fills parent container height
 *    - Requires parent to have defined height (h-full, h-screen, etc.)
 *    - Sticky header stays visible while scrolling
 *    - Use for: FileViewer, full-page tables
 *    - IMPORTANT: Parent must have height constraint or table won't display correctly
 *
 * COMMON ISSUES:
 * - Table not showing: Check if parent has height when using fillHeight={true}
 * - Scrollbars not appearing: Ensure no nested overflow-auto containers
 * - Sticky header not working: Don't wrap in ScrollArea component
 */

import {
  ColumnDef,
  flexRender,
  getCoreRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  SortingState,
  useReactTable,
} from "@tanstack/react-table";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { useMemo, useState } from "react";
import { ArrowUpDown, ArrowUp, ArrowDown } from "lucide-react";

// Row height constants for calculating maxVisibleRows height
const ROW_HEIGHT = 32; // px - matches py-1.5 padding + content
const HEADER_HEIGHT = 40; // px - header row height

// Value formatters for common data types
export type FormatterType = "date" | "datetime" | "number" | "currency" | "percent";

export const formatters: Record<FormatterType, (value: unknown) => string> = {
  date: (v) => {
    const date = v instanceof Date ? v : new Date(v as string | number);
    return isNaN(date.getTime()) ? String(v) : new Intl.DateTimeFormat("en-US").format(date);
  },
  datetime: (v) => {
    const date = v instanceof Date ? v : new Date(v as string | number);
    return isNaN(date.getTime())
      ? String(v)
      : new Intl.DateTimeFormat("en-US", { timeStyle: "short", dateStyle: "medium" }).format(date);
  },
  number: (v) => new Intl.NumberFormat("en-US").format(Number(v)),
  currency: (v) => new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(Number(v)),
  percent: (v) => new Intl.NumberFormat("en-US", { style: "percent", minimumFractionDigits: 1 }).format(Number(v)),
};

interface DataTableProps<TData> {
  data: TData[];
  columns?: ColumnDef<TData, unknown>[];
  className?: string;
  defaultPageSize?: number;
  pageSizeOptions?: number[];
  /**
   * When true, fills parent height with sticky header (for FileViewer).
   * When false, sizes to content (for ToolCard, inline use).
   * @default false
   */
  fillHeight?: boolean;
  /**
   * Maximum visible rows before scrollbar appears.
   * Only applies when fillHeight={false}.
   * Use for compact displays like ToolCard (e.g., maxVisibleRows={5}).
   */
  maxVisibleRows?: number;
  /**
   * Column formatters for auto-generated columns.
   * Maps column name to formatter type.
   * @example { created_at: "datetime", price: "currency", count: "number" }
   */
  columnFormats?: Record<string, FormatterType>;
}


/**
 * Generic DataTable that can auto-generate columns from data.
 * See file header for layout mode documentation.
 */
export function DataTable<TData extends Record<string, unknown>>({
  data,
  columns: providedColumns,
  className,
  defaultPageSize = 25,
  pageSizeOptions = [5, 25, 50, 100],
  fillHeight = false,
  maxVisibleRows,
  columnFormats,
}: DataTableProps<TData>) {
  const [sorting, setSorting] = useState<SortingState>([]);

  // Auto-generate columns from data keys if not provided
  const columns = useMemo(() => {
    if (providedColumns) return providedColumns;

    if (data.length === 0) return [];

    // Get all unique keys from all rows
    const keys = new Set<string>();
    data.forEach((row) => {
      Object.keys(row).forEach((key) => keys.add(key));
    });

    return Array.from(keys).map((key) => ({
      accessorKey: key,
      header: ({ column }) => {
        const sorted = column.getIsSorted();
        return (
          <button
            className="flex items-center gap-1 hover:text-foreground transition-colors"
            onClick={() => column.toggleSorting(sorted === "asc")}
          >
            {key}
            {sorted === "asc" ? (
              <ArrowUp className="size-3" />
            ) : sorted === "desc" ? (
              <ArrowDown className="size-3" />
            ) : (
              <ArrowUpDown className="size-3 opacity-50" />
            )}
          </button>
        );
      },
      cell: ({ getValue }: { getValue: () => unknown }) => {
        const value = getValue();
        if (value === null || value === undefined) return <span className="text-muted-foreground">null</span>;
        if (typeof value === "boolean") return value ? "true" : "false";
        if (typeof value === "object") return JSON.stringify(value);
        // Apply formatter if specified for this column
        const formatterType = columnFormats?.[key];
        if (formatterType && formatters[formatterType]) {
          return formatters[formatterType](value);
        }
        return String(value);
      },
    })) as ColumnDef<TData, unknown>[];
  }, [data, providedColumns, columnFormats]);

  const table = useReactTable({
    data,
    columns,
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getSortedRowModel: getSortedRowModel(),
    onSortingChange: setSorting,
    state: {
      sorting,
    },
    initialState: {
      pagination: {
        pageSize: defaultPageSize,
      },
    },
  });

  if (data.length === 0) {
    return (
      <div className="text-center py-4 text-muted-foreground text-sm">
        No results
      </div>
    );
  }

  const { pageIndex, pageSize } = table.getState().pagination;
  const totalRows = data.length;
  const startRow = pageIndex * pageSize + 1;
  const endRow = Math.min((pageIndex + 1) * pageSize, totalRows);
  const pageCount = table.getPageCount();

  // Calculate max height for content-sized mode with maxVisibleRows
  const maxScrollHeight = maxVisibleRows
    ? HEADER_HEIGHT + (maxVisibleRows * ROW_HEIGHT)
    : undefined;

  const tableContent = (
    <Table>
      {/*
        Sticky header only works in fillHeight mode because it needs
        a scrolling ancestor with defined height. In content-sized mode,
        the container expands to fit content so sticky has no effect.
      */}
      <TableHeader className={fillHeight ? "sticky top-0 bg-background z-10" : ""}>
        {table.getHeaderGroups().map((headerGroup) => (
          <TableRow key={headerGroup.id}>
            {headerGroup.headers.map((header) => (
              <TableHead key={header.id} className="text-xs font-semibold">
                {header.isPlaceholder
                  ? null
                  : flexRender(
                      header.column.columnDef.header,
                      header.getContext()
                    )}
              </TableHead>
            ))}
          </TableRow>
        ))}
      </TableHeader>
      <TableBody>
        {table.getRowModel().rows.map((row) => (
          <TableRow key={row.id}>
            {row.getVisibleCells().map((cell) => (
              <TableCell key={cell.id} className="text-xs py-1.5">
                {flexRender(cell.column.columnDef.cell, cell.getContext())}
              </TableCell>
            ))}
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );

  return (
    <div className={cn(fillHeight ? "flex flex-col h-full" : "rounded-md border", className)}>
      {fillHeight ? (
        /**
         * FULL-HEIGHT MODE (fillHeight={true})
         *
         * Uses absolute positioning to create a properly constrained scroll container.
         * This ensures:
         * - Scrollbars appear at container edges, not content bottom
         * - Sticky header works correctly
         * - Both horizontal and vertical scrolling work
         *
         * Structure: relative wrapper -> absolute container -> overflow-auto
         * The min-h-0 is crucial for flex children to allow shrinking.
         */
        <div className="flex-1 relative min-h-0">
          <div className="absolute inset-0 overflow-auto">
            {tableContent}
          </div>
        </div>
      ) : (
        /**
         * CONTENT-SIZED MODE (fillHeight={false}, default)
         *
         * Table sizes to its content. If maxVisibleRows is set,
         * limits height and shows scrollbar for overflow.
         * Used in ToolCard and other inline contexts.
         */
        <div
          className="overflow-auto"
          style={maxScrollHeight ? { maxHeight: maxScrollHeight } : undefined}
        >
          {tableContent}
        </div>
      )}

      {/* Pagination footer - always visible at bottom */}
      <div className="flex items-center justify-between px-3 py-2 border-t bg-muted/30">
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground">Rows per page</span>
          <Select
            value={String(pageSize)}
            onValueChange={(value) => table.setPageSize(Number(value))}
          >
            <SelectTrigger className="h-7 w-16 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {pageSizeOptions.map((size) => (
                <SelectItem key={size} value={String(size)} className="text-xs">
                  {size}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="flex items-center gap-4">
          <span className="text-xs text-muted-foreground">
            {startRow}-{endRow} of {totalRows}
          </span>

          {pageCount > 1 && (
            <div className="flex items-center gap-1">
              <button
                className="h-7 w-7 flex items-center justify-center rounded border text-xs disabled:opacity-50 disabled:cursor-not-allowed hover:bg-muted"
                onClick={() => table.previousPage()}
                disabled={!table.getCanPreviousPage()}
              >
                ‹
              </button>
              <span className="text-xs text-muted-foreground px-2">
                {pageIndex + 1} / {pageCount}
              </span>
              <button
                className="h-7 w-7 flex items-center justify-center rounded border text-xs disabled:opacity-50 disabled:cursor-not-allowed hover:bg-muted"
                onClick={() => table.nextPage()}
                disabled={!table.getCanNextPage()}
              >
                ›
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
