/**
 * Message components for AI chat interfaces
 * Based on ai-sdk.dev/elements/components/message
 */

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";
import {
  ChevronLeftIcon,
  ChevronRightIcon,
  CopyIcon,
  FileIcon,
  RefreshCwIcon,
  ThumbsDownIcon,
  ThumbsUpIcon,
  XIcon,
} from "lucide-react";
import type { ComponentProps, HTMLAttributes, ReactNode } from "react";
import {
  createContext,
  useContext,
  useState,
  useCallback,
  memo,
} from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import remarkMath from "remark-math";
import rehypeKatex from "rehype-katex";
import { CodeBlock, CodeBlockCopyButton } from "./code-block";

export type MessageRole = "user" | "assistant" | "system";

export type MessageProps = HTMLAttributes<HTMLDivElement> & {
  from?: MessageRole;
};

export const Message = ({ className, from = "assistant", ...props }: MessageProps) => (
  <div
    className={cn(
      "group flex w-full items-end justify-end gap-2 py-1.5",
      from === "user"
        ? "is-user"
        : "is-assistant flex-row-reverse justify-end",
      "[&>div]:max-w-[85%]",
      className
    )}
    {...props}
  />
);

export type MessageContentProps = HTMLAttributes<HTMLDivElement>;

export const MessageContent = ({
  children,
  className,
  ...props
}: MessageContentProps) => (
  <div
    className={cn(
      "flex flex-col gap-2 overflow-hidden rounded-lg px-3 py-2 text-foreground text-sm",
      // User messages - WhatsApp green with rounded corners (no bottom-right)
      "group-[.is-user]:bg-primary group-[.is-user]:text-primary-foreground group-[.is-user]:rounded-br-sm",
      // Assistant messages - dark gray with rounded corners (no bottom-left)
      "group-[.is-assistant]:bg-secondary group-[.is-assistant]:text-foreground group-[.is-assistant]:rounded-bl-sm",
      className
    )}
    {...props}
  >
    <div>{children}</div>
  </div>
);

export type MessageAvatarProps = ComponentProps<typeof Avatar> & {
  src?: string;
  name?: string;
};

export const MessageAvatar = ({
  src,
  name,
  className,
  ...props
}: MessageAvatarProps) => (
  <Avatar
    className={cn("size-8 ring ring-1 ring-border", className)}
    {...props}
  >
    {src && <AvatarImage alt="" className="mt-0 mb-0" src={src} />}
    <AvatarFallback>{name?.slice(0, 2) || "ME"}</AvatarFallback>
  </Avatar>
);

// MessageResponse - Renders markdown content with GFM support
export type MessageResponseProps = HTMLAttributes<HTMLDivElement> & {
  children?: string;
  parseIncompleteMarkdown?: boolean;
};

export const MessageResponse = memo(({
  className,
  children,
  parseIncompleteMarkdown = true,
  ...props
}: MessageResponseProps) => {
  if (!children) return null;

  // Handle incomplete markdown during streaming
  const content = parseIncompleteMarkdown
    ? completeIncompleteMarkdown(children)
    : children;

  return (
    <div
      className={cn(
        "prose prose-sm dark:prose-invert max-w-none",
        "prose-p:leading-relaxed prose-pre:p-0",
        "prose-headings:font-semibold",
        className
      )}
      {...props}
    >
      <ReactMarkdown
        remarkPlugins={[remarkGfm, remarkMath]}
        rehypePlugins={[rehypeKatex]}
        components={{
          code({ className, children, ...codeProps }) {
            const match = /language-(\w+)/.exec(className || "");
            const isInline = !match;
            const code = String(children).replace(/\n$/, "");

            if (isInline) {
              return (
                <code
                  className="rounded bg-muted px-1 py-0.5 font-mono text-sm"
                  {...codeProps}
                >
                  {children}
                </code>
              );
            }

            return (
              <CodeBlock code={code} language={match?.[1] || "text"}>
                <CodeBlockCopyButton />
              </CodeBlock>
            );
          },
          pre({ children }) {
            return <>{children}</>;
          },
        }}
      >
        {content}
      </ReactMarkdown>
    </div>
  );
});

MessageResponse.displayName = "MessageResponse";

// Helper to complete incomplete markdown during streaming
function completeIncompleteMarkdown(text: string): string {
  // Count backticks for code blocks
  const codeBlockMatches = text.match(/```/g);
  if (codeBlockMatches && codeBlockMatches.length % 2 !== 0) {
    text += "\n```";
  }

  // Complete incomplete inline code
  const inlineCodeMatches = text.match(/(?<!`)`(?!`)/g);
  if (inlineCodeMatches && inlineCodeMatches.length % 2 !== 0) {
    text += "`";
  }

  return text;
}

// MessageActions - Container for action buttons
export type MessageActionsProps = HTMLAttributes<HTMLDivElement>;

export const MessageActions = ({
  className,
  children,
  ...props
}: MessageActionsProps) => (
  <div
    className={cn(
      "flex items-center gap-1 opacity-0 transition-opacity group-hover:opacity-100",
      className
    )}
    {...props}
  >
    {children}
  </div>
);

// MessageAction - Individual action button with tooltip
export type MessageActionProps = ComponentProps<typeof Button> & {
  tooltip?: string;
  label?: string;
};

export const MessageAction = ({
  className,
  tooltip,
  label,
  children,
  ...props
}: MessageActionProps) => {
  const button = (
    <Button
      className={cn("size-7", className)}
      size="icon"
      variant="ghost"
      aria-label={label}
      {...props}
    >
      {children}
    </Button>
  );

  if (tooltip) {
    return (
      <Tooltip>
        <TooltipTrigger asChild>{button}</TooltipTrigger>
        <TooltipContent>{tooltip}</TooltipContent>
      </Tooltip>
    );
  }

  return button;
};

// Pre-built action buttons
export const MessageCopyAction = ({ onCopy, ...props }: MessageActionProps & { onCopy?: () => void }) => (
  <MessageAction tooltip="Copy" onClick={onCopy} {...props}>
    <CopyIcon className="size-3.5" />
  </MessageAction>
);

export const MessageRetryAction = ({ onRetry, ...props }: MessageActionProps & { onRetry?: () => void }) => (
  <MessageAction tooltip="Retry" onClick={onRetry} {...props}>
    <RefreshCwIcon className="size-3.5" />
  </MessageAction>
);

export const MessageLikeAction = ({ onLike, ...props }: MessageActionProps & { onLike?: () => void }) => (
  <MessageAction tooltip="Like" onClick={onLike} {...props}>
    <ThumbsUpIcon className="size-3.5" />
  </MessageAction>
);

export const MessageDislikeAction = ({ onDislike, ...props }: MessageActionProps & { onDislike?: () => void }) => (
  <MessageAction tooltip="Dislike" onClick={onDislike} {...props}>
    <ThumbsDownIcon className="size-3.5" />
  </MessageAction>
);

// MessageBranch - Manages multiple response versions
type MessageBranchContextType = {
  branch: number;
  setBranch: (branch: number) => void;
  totalBranches: number;
};

const MessageBranchContext = createContext<MessageBranchContextType>({
  branch: 0,
  setBranch: () => {},
  totalBranches: 1,
});

export type MessageBranchProps = HTMLAttributes<HTMLDivElement> & {
  defaultBranch?: number;
  onBranchChange?: (branchIndex: number) => void;
  totalBranches?: number;
};

export const MessageBranch = ({
  className,
  defaultBranch = 0,
  onBranchChange,
  totalBranches = 1,
  children,
  ...props
}: MessageBranchProps) => {
  const [branch, setBranchState] = useState(defaultBranch);

  const setBranch = useCallback(
    (newBranch: number) => {
      setBranchState(newBranch);
      onBranchChange?.(newBranch);
    },
    [onBranchChange]
  );

  return (
    <MessageBranchContext.Provider value={{ branch, setBranch, totalBranches }}>
      <div className={cn("", className)} {...props}>
        {children}
      </div>
    </MessageBranchContext.Provider>
  );
};

export type MessageBranchContentProps = HTMLAttributes<HTMLDivElement> & {
  branchIndex: number;
  children: ReactNode;
};

export const MessageBranchContent = ({
  className,
  branchIndex,
  children,
  ...props
}: MessageBranchContentProps) => {
  const { branch } = useContext(MessageBranchContext);

  if (branch !== branchIndex) return null;

  return (
    <div className={cn("", className)} {...props}>
      {children}
    </div>
  );
};

export type MessageBranchSelectorProps = HTMLAttributes<HTMLDivElement>;

export const MessageBranchSelector = ({
  className,
  ...props
}: MessageBranchSelectorProps) => {
  const { branch, setBranch, totalBranches } = useContext(MessageBranchContext);

  if (totalBranches <= 1) return null;

  return (
    <div className={cn("flex items-center gap-1 text-xs text-muted-foreground", className)} {...props}>
      <Button
        size="icon"
        variant="ghost"
        className="size-6"
        onClick={() => setBranch(Math.max(0, branch - 1))}
        disabled={branch === 0}
      >
        <ChevronLeftIcon className="size-3" />
      </Button>
      <span>
        {branch + 1} / {totalBranches}
      </span>
      <Button
        size="icon"
        variant="ghost"
        className="size-6"
        onClick={() => setBranch(Math.min(totalBranches - 1, branch + 1))}
        disabled={branch === totalBranches - 1}
      >
        <ChevronRightIcon className="size-3" />
      </Button>
    </div>
  );
};

// MessageAttachments - Container for file attachments
export type MessageAttachmentsProps = HTMLAttributes<HTMLDivElement>;

export const MessageAttachments = ({
  className,
  children,
  ...props
}: MessageAttachmentsProps) => (
  <div className={cn("flex flex-wrap gap-2", className)} {...props}>
    {children}
  </div>
);

export type FileUIPart = {
  type: "file";
  name: string;
  mimeType: string;
  url?: string;
};

export type MessageAttachmentProps = HTMLAttributes<HTMLDivElement> & {
  data?: FileUIPart;
  onRemove?: () => void;
};

export const MessageAttachment = ({
  className,
  data,
  onRemove,
  children,
  ...props
}: MessageAttachmentProps) => {
  const isImage = data?.mimeType?.startsWith("image/");

  return (
    <div
      className={cn(
        "group/attachment relative flex items-center gap-2 rounded-md border bg-muted/50 p-2",
        className
      )}
      {...props}
    >
      {data ? (
        isImage && data.url ? (
          <img
            src={data.url}
            alt={data.name}
            className="size-10 rounded object-cover"
          />
        ) : (
          <>
            <FileIcon className="size-4 text-muted-foreground" />
            <span className="text-xs truncate max-w-[100px]">{data.name}</span>
          </>
        )
      ) : (
        children
      )}
      {onRemove && (
        <Button
          size="icon"
          variant="ghost"
          className="absolute -top-1 -right-1 size-5 opacity-0 group-hover/attachment:opacity-100"
          onClick={onRemove}
        >
          <XIcon className="size-3" />
        </Button>
      )}
    </div>
  );
};
