/**
 * Tests for Tool component
 *
 * Tests all tool states, stats display, and special rendering modes
 */

import { describe, it, expect } from 'vitest';
import { render, screen } from '@/test/utils';
import {
  Tool,
  ToolHeader,
  ToolContent,
  ToolInput,
  ToolOutput,
  ToolDenied,
  ToolDiff,
  ToolCard,
  type ToolEvent,
  type ToolStats,
} from './tool';

describe('Tool', () => {
  it('renders as a collapsible container', () => {
    render(
      <Tool data-testid="tool">
        <ToolHeader toolName="test_tool" state="running" />
        <ToolContent>Content</ToolContent>
      </Tool>
    );

    expect(screen.getByTestId('tool')).toBeInTheDocument();
  });

  it('can be opened and closed', async () => {
    const { container } = render(
      <Tool defaultOpen={false}>
        <ToolHeader toolName="test_tool" state="running" />
        <ToolContent>Hidden Content</ToolContent>
      </Tool>
    );

    // Content should be hidden initially
    expect(container.querySelector('[data-state="closed"]')).toBeInTheDocument();
  });
});

describe('ToolHeader', () => {
  // Helper to render header in Tool context (required for Collapsible)
  const renderHeader = (toolName: string, state: string) => {
    return render(
      <Tool>
        <ToolHeader toolName={toolName} state={state as import('./tool').ToolState} />
        <ToolContent>Content</ToolContent>
      </Tool>
    );
  };

  it('displays tool name', () => {
    renderHeader('django_raw_sql', 'running');
    expect(screen.getByText('django_raw_sql')).toBeInTheDocument();
  });

  it('shows Running state with spinner', () => {
    renderHeader('test', 'running');
    expect(screen.getByText('Running')).toBeInTheDocument();
  });

  it('shows Completed state with checkmark', () => {
    renderHeader('test', 'completed');
    expect(screen.getByText('Completed')).toBeInTheDocument();
  });

  it('shows Error state', () => {
    renderHeader('test', 'error');
    expect(screen.getByText('Error')).toBeInTheDocument();
  });

  it('shows Denied state', () => {
    renderHeader('test', 'denied');
    expect(screen.getByText('Denied')).toBeInTheDocument();
  });

  it('shows Pending state', () => {
    renderHeader('test', 'pending');
    expect(screen.getByText('Pending')).toBeInTheDocument();
  });

  it('shows Awaiting Approval state', () => {
    renderHeader('test', 'approval-requested');
    expect(screen.getByText('Awaiting Approval')).toBeInTheDocument();
  });

  it('shows Responded state', () => {
    renderHeader('test', 'approval-responded');
    expect(screen.getByText('Responded')).toBeInTheDocument();
  });

  // Legacy state mapping
  it('maps input-streaming to Pending', () => {
    renderHeader('test', 'input-streaming');
    expect(screen.getByText('Pending')).toBeInTheDocument();
  });

  it('maps input-available to Running', () => {
    renderHeader('test', 'input-available');
    expect(screen.getByText('Running')).toBeInTheDocument();
  });

  it('maps output-available to Completed', () => {
    renderHeader('test', 'output-available');
    expect(screen.getByText('Completed')).toBeInTheDocument();
  });

  it('maps output-error to Error', () => {
    renderHeader('test', 'output-error');
    expect(screen.getByText('Error')).toBeInTheDocument();
  });

  it('maps output-denied to Denied', () => {
    renderHeader('test', 'output-denied');
    expect(screen.getByText('Denied')).toBeInTheDocument();
  });
});

describe('ToolInput', () => {
  it('renders nothing when input is undefined', () => {
    const { container } = render(<ToolInput />);
    expect(container.firstChild).toBeNull();
  });

  it('displays string input', () => {
    render(<ToolInput input="SELECT * FROM users" toolName="django_raw_sql" />);
    expect(screen.getByText(/SELECT/)).toBeInTheDocument();
  });

  it('displays object input as JSON', () => {
    render(<ToolInput input={{ path: '/test.txt' }} />);
    expect(screen.getByText(/path/)).toBeInTheDocument();
  });

  it('shows Parameters heading', () => {
    render(<ToolInput input={{ test: 'value' }} />);
    expect(screen.getByText('Parameters')).toBeInTheDocument();
  });
});

describe('ToolOutput', () => {
  it('renders nothing when no output or error', () => {
    const { container } = render(<ToolOutput />);
    expect(container.firstChild).toBeNull();
  });

  it('displays text output', () => {
    render(<ToolOutput output="Query completed successfully" />);
    expect(screen.getByText('Query completed successfully')).toBeInTheDocument();
  });

  it('displays error text with error styling', () => {
    render(<ToolOutput errorText="Connection failed" />);
    expect(screen.getByText('Error')).toBeInTheDocument();
    expect(screen.getByText('Connection failed')).toBeInTheDocument();
  });

  it('shows Result heading for normal output', () => {
    render(<ToolOutput output="Done" />);
    expect(screen.getByText('Result')).toBeInTheDocument();
  });

  // Stats badges
  it('displays time stats', () => {
    const stats: ToolStats = { time_ms: 150 };
    render(<ToolOutput output="Done" stats={stats} />);
    expect(screen.getByText('150ms')).toBeInTheDocument();
  });

  it('displays row count', () => {
    const stats: ToolStats = { rows: 100 };
    render(<ToolOutput output="Done" stats={stats} />);
    expect(screen.getByText('100 rows')).toBeInTheDocument();
  });

  it('displays row count with total', () => {
    const stats: ToolStats = { rows: 50, total_rows: 1000 };
    render(<ToolOutput output="Done" stats={stats} />);
    expect(screen.getByText('50 of 1,000 rows')).toBeInTheDocument();
  });

  it('displays column count', () => {
    const stats: ToolStats = { cols: 5 };
    render(<ToolOutput output="Done" stats={stats} />);
    expect(screen.getByText('5 cols')).toBeInTheDocument();
  });

  it('displays file and dir counts', () => {
    const stats: ToolStats = { files: 10, dirs: 3 };
    render(<ToolOutput output="Done" stats={stats} />);
    expect(screen.getByText('10 files')).toBeInTheDocument();
    expect(screen.getByText('3 dirs')).toBeInTheDocument();
  });

  it('displays line count', () => {
    const stats: ToolStats = { lines: 500 };
    render(<ToolOutput output="Done" stats={stats} />);
    expect(screen.getByText('500 lines')).toBeInTheDocument();
  });

  it('displays additions and removals', () => {
    const stats: ToolStats = { additions: 10, removals: 5 };
    render(<ToolOutput output="Done" stats={stats} />);
    expect(screen.getByText('+10')).toBeInTheDocument();
    expect(screen.getByText('-5')).toBeInTheDocument();
  });

  it('displays size in bytes', () => {
    const stats: ToolStats = { size_bytes: 1024 };
    render(<ToolOutput output="Done" stats={stats} />);
    expect(screen.getByText('1KB')).toBeInTheDocument();
  });

  it('displays chart type', () => {
    const stats: ToolStats = { chart_type: 'bar' };
    render(<ToolOutput output="Done" stats={stats} />);
    expect(screen.getByText('bar')).toBeInTheDocument();
  });

  it('displays image when image_url provided', () => {
    const stats: ToolStats = { image_url: '/api/raw-file/chart.png', filename: 'chart.png' };
    render(<ToolOutput stats={stats} />);
    const img = screen.getByRole('img');
    expect(img).toHaveAttribute('src', '/api/raw-file/chart.png');
    expect(img).toHaveAttribute('alt', 'chart.png');
  });
});

describe('ToolDenied', () => {
  it('displays default denied message', () => {
    render(<ToolDenied />);
    expect(screen.getByText('Tool execution was denied')).toBeInTheDocument();
  });

  it('displays custom denied message', () => {
    render(<ToolDenied message="User rejected the operation" />);
    expect(screen.getByText('User rejected the operation')).toBeInTheDocument();
  });
});

describe('ToolDiff', () => {
  it('renders nothing when diff is empty', () => {
    const { container } = render(<ToolDiff diff={[]} />);
    expect(container.firstChild).toBeNull();
  });

  it('renders nothing when diff is undefined', () => {
    const { container } = render(<ToolDiff />);
    expect(container.firstChild).toBeNull();
  });

  it('displays Changes heading', () => {
    render(<ToolDiff diff={['+added line']} />);
    expect(screen.getByText('Changes')).toBeInTheDocument();
  });

  it('renders additions with green styling', () => {
    render(<ToolDiff diff={['+added line']} />);
    const line = screen.getByText('+added line');
    expect(line).toBeInTheDocument();
    // The colored div is an ancestor
    expect(line.closest('.text-green-400')).toBeInTheDocument();
  });

  it('renders removals with red styling', () => {
    render(<ToolDiff diff={['-removed line']} />);
    const line = screen.getByText('-removed line');
    expect(line).toBeInTheDocument();
    // The colored div is an ancestor
    expect(line.closest('.text-red-400')).toBeInTheDocument();
  });

  it('renders hunk headers with blue styling', () => {
    render(<ToolDiff diff={['@@ -1,3 +1,4 @@']} />);
    const line = screen.getByText('@@ -1,3 +1,4 @@');
    expect(line).toBeInTheDocument();
    // The colored div is an ancestor
    expect(line.closest('.text-blue-400')).toBeInTheDocument();
  });
});

describe('ToolCard', () => {
  it('shows running state when no result', () => {
    const event: ToolEvent = { tool: 'test_tool', result: undefined };
    render(<ToolCard event={event} />);
    expect(screen.getByText('Running')).toBeInTheDocument();
  });

  it('shows completed state when result exists', () => {
    const event: ToolEvent = { tool: 'test_tool', result: 'Done' };
    render(<ToolCard event={event} />);
    expect(screen.getByText('Completed')).toBeInTheDocument();
  });

  it('shows completed state when stats exist', () => {
    const event: ToolEvent = { tool: 'test_tool', stats: { rows: 10 } };
    render(<ToolCard event={event} />);
    expect(screen.getByText('Completed')).toBeInTheDocument();
  });

  it('shows denied state when denied flag is true', () => {
    const event: ToolEvent = { tool: 'Bash', denied: true };
    render(<ToolCard event={event} />);
    expect(screen.getByText('Denied')).toBeInTheDocument();
  });

  it('shows approval-requested state when awaitingApproval', () => {
    const event: ToolEvent = { tool: 'uv_execute_code', awaitingApproval: true };
    render(<ToolCard event={event} />);
    expect(screen.getByText('Awaiting Approval')).toBeInTheDocument();
  });

  it('shows error state when error exists', () => {
    const event: ToolEvent = { tool: 'test_tool', error: 'Connection failed' };
    render(<ToolCard event={event} />);
    // Error appears in header badge and as section heading
    expect(screen.getAllByText('Error').length).toBeGreaterThanOrEqual(1);
    expect(screen.getByText('Connection failed')).toBeInTheDocument();
  });

  it('displays tool name', () => {
    const event: ToolEvent = { tool: 'django_raw_sql' };
    render(<ToolCard event={event} />);
    expect(screen.getByText('django_raw_sql')).toBeInTheDocument();
  });

  it('displays input parameters', () => {
    const event: ToolEvent = {
      tool: 'storage_read',
      input: { path: '/test.txt' },
    };
    render(<ToolCard event={event} />);
    expect(screen.getByText('Parameters')).toBeInTheDocument();
  });

  it('displays SQL input for SQL tools', () => {
    const event: ToolEvent = {
      tool: 'django_raw_sql',
      sql: 'SELECT * FROM users',
    };
    render(<ToolCard event={event} />);
    expect(screen.getByText(/SELECT/)).toBeInTheDocument();
  });

  it('displays result output', () => {
    const event: ToolEvent = {
      tool: 'test_tool',
      result: 'Operation completed',
    };
    render(<ToolCard event={event} />);
    expect(screen.getByText('Operation completed')).toBeInTheDocument();
  });

  it('displays stats badges', () => {
    const event: ToolEvent = {
      tool: 'django_raw_sql',
      result: 'Done',
      stats: { rows: 50, cols: 3, time_ms: 25 },
    };
    render(<ToolCard event={event} />);
    expect(screen.getByText('50 rows')).toBeInTheDocument();
    expect(screen.getByText('3 cols')).toBeInTheDocument();
    expect(screen.getByText('25ms')).toBeInTheDocument();
  });

  it('displays denied message when denied', () => {
    const event: ToolEvent = { tool: 'Bash', denied: true };
    render(<ToolCard event={event} />);
    // Check for the denied status badge specifically
    expect(screen.getByText('Denied')).toBeInTheDocument();
  });

  it('displays diff when present', () => {
    const event: ToolEvent = {
      tool: 'storage_write',
      result: 'Done',
      diff: ['+new line', '-old line'],
    };
    render(<ToolCard event={event} />);
    expect(screen.getByText('Changes')).toBeInTheDocument();
    expect(screen.getByText('+new line')).toBeInTheDocument();
  });
});
