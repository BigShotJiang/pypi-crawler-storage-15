/**
 * Artifact component for displaying generated content like code, documents, or files
 * Based on ai-sdk.dev/elements/components/artifact
 */

import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { XIcon, type LucideIcon } from "lucide-react";
import type { ComponentProps, ReactNode } from "react";

// Main container
export type ArtifactProps = ComponentProps<"div">;

export const Artifact = ({ className, ...props }: ArtifactProps) => (
  <div
    className={cn(
      "flex flex-col overflow-hidden rounded-lg border bg-card text-card-foreground shadow-sm",
      className
    )}
    {...props}
  />
);

// Header section
export type ArtifactHeaderProps = ComponentProps<"div">;

export const ArtifactHeader = ({ className, ...props }: ArtifactHeaderProps) => (
  <div
    className={cn(
      "flex items-center justify-between gap-2 border-b bg-muted/50 px-4 py-2",
      className
    )}
    {...props}
  />
);

// Title
export type ArtifactTitleProps = ComponentProps<"h3">;

export const ArtifactTitle = ({ className, ...props }: ArtifactTitleProps) => (
  <h3
    className={cn("text-sm font-medium truncate", className)}
    {...props}
  />
);

// Description
export type ArtifactDescriptionProps = ComponentProps<"p">;

export const ArtifactDescription = ({
  className,
  ...props
}: ArtifactDescriptionProps) => (
  <p
    className={cn("text-xs text-muted-foreground", className)}
    {...props}
  />
);

// Actions container
export type ArtifactActionsProps = ComponentProps<"div">;

export const ArtifactActions = ({ className, ...props }: ArtifactActionsProps) => (
  <div className={cn("flex items-center gap-1", className)} {...props} />
);

// Individual action button
export type ArtifactActionProps = ComponentProps<typeof Button> & {
  tooltip?: string;
  label?: string;
  icon: LucideIcon;
};

export const ArtifactAction = ({
  tooltip,
  label,
  icon: Icon,
  className,
  ...props
}: ArtifactActionProps) => {
  const button = (
    <Button
      variant="ghost"
      size="icon"
      className={cn("h-7 w-7", className)}
      aria-label={label}
      {...props}
    >
      <Icon className="h-4 w-4" />
    </Button>
  );

  if (tooltip) {
    return (
      <Tooltip>
        <TooltipTrigger asChild>{button}</TooltipTrigger>
        <TooltipContent>{tooltip}</TooltipContent>
      </Tooltip>
    );
  }

  return button;
};

// Close button
export type ArtifactCloseProps = ComponentProps<typeof Button>;

export const ArtifactClose = ({ className, ...props }: ArtifactCloseProps) => (
  <Button
    variant="ghost"
    size="icon"
    className={cn("h-7 w-7", className)}
    {...props}
  >
    <XIcon className="h-4 w-4" />
  </Button>
);

// Content area
export type ArtifactContentProps = ComponentProps<"div">;

export const ArtifactContent = ({ className, ...props }: ArtifactContentProps) => (
  <div className={cn("flex-1 overflow-auto", className)} {...props} />
);

// Loading state
export type ArtifactLoadingProps = ComponentProps<"div">;

export const ArtifactLoading = ({ className, ...props }: ArtifactLoadingProps) => (
  <div
    className={cn(
      "flex items-center justify-center p-8 text-muted-foreground",
      className
    )}
    {...props}
  >
    <div className="animate-pulse">Loading...</div>
  </div>
);

// Error state
export type ArtifactErrorProps = ComponentProps<"div"> & {
  message?: string;
};

export const ArtifactError = ({
  className,
  message = "Failed to load content",
  children,
  ...props
}: ArtifactErrorProps) => (
  <div
    className={cn(
      "flex items-center justify-center p-8 text-destructive",
      className
    )}
    {...props}
  >
    {children || message}
  </div>
);

// Empty state
export type ArtifactEmptyProps = ComponentProps<"div"> & {
  message?: string;
};

export const ArtifactEmpty = ({
  className,
  message = "No content to display",
  children,
  ...props
}: ArtifactEmptyProps) => (
  <div
    className={cn(
      "flex items-center justify-center p-8 text-muted-foreground",
      className
    )}
    {...props}
  >
    {children || message}
  </div>
);
