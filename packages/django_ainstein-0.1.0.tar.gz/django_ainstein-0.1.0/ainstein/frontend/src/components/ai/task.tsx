/**
 * Task component for displaying AI workflow progress
 * Based on ai-sdk.dev/elements/components/task
 */

import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { cn } from "@/lib/utils";
import {
  CheckCircle2Icon,
  ChevronDownIcon,
  CircleIcon,
  FileIcon,
  ListTodoIcon,
  Loader2Icon,
  XCircleIcon,
} from "lucide-react";
import type { ComponentProps, HTMLAttributes } from "react";

// Task status types
export type TaskStatus = "pending" | "in-progress" | "completed" | "error";

// Task container
export type TaskProps = ComponentProps<typeof Collapsible>;

export const Task = ({ defaultOpen = true, className, ...props }: TaskProps) => (
  <Collapsible
    className={cn("rounded-md border", className)}
    defaultOpen={defaultOpen}
    {...props}
  />
);

// Task trigger with title and progress
export type TaskTriggerProps = ComponentProps<typeof CollapsibleTrigger> & {
  title?: string;
  completedCount?: number;
  totalCount?: number;
};

export const TaskTrigger = ({
  children,
  className,
  title = "Tasks",
  completedCount,
  totalCount,
  ...props
}: TaskTriggerProps) => (
  <CollapsibleTrigger
    className={cn(
      "group flex w-full items-center justify-between gap-2 p-3 hover:bg-muted/50",
      className
    )}
    {...props}
  >
    {children ?? (
      <>
        <div className="flex items-center gap-2">
          <ListTodoIcon className="size-4 text-muted-foreground" />
          <span className="text-sm font-medium">{title}</span>
          {completedCount !== undefined && totalCount !== undefined && (
            <span className="text-xs text-muted-foreground">
              ({completedCount}/{totalCount})
            </span>
          )}
        </div>
        <ChevronDownIcon className="size-4 text-muted-foreground transition-transform group-data-[state=open]:rotate-180" />
      </>
    )}
  </CollapsibleTrigger>
);

// Task content container
export type TaskContentProps = ComponentProps<typeof CollapsibleContent>;

export const TaskContent = ({
  children,
  className,
  ...props
}: TaskContentProps) => (
  <CollapsibleContent className={cn("", className)} {...props}>
    <div className="border-t px-3 py-2 space-y-1">{children}</div>
  </CollapsibleContent>
);

// Individual task item with status
export type TaskItemProps = HTMLAttributes<HTMLDivElement> & {
  status?: TaskStatus;
};

const statusIcons = {
  pending: <CircleIcon className="size-4 text-muted-foreground" />,
  "in-progress": <Loader2Icon className="size-4 text-blue-500 animate-spin" />,
  completed: <CheckCircle2Icon className="size-4 text-green-500" />,
  error: <XCircleIcon className="size-4 text-red-500" />,
};

export const TaskItem = ({
  children,
  className,
  status = "pending",
  ...props
}: TaskItemProps) => (
  <div
    className={cn(
      "flex items-start gap-2 py-1.5 text-sm",
      status === "completed" && "text-muted-foreground",
      className
    )}
    {...props}
  >
    <span className="mt-0.5 shrink-0">{statusIcons[status]}</span>
    <span className={cn(status === "completed" && "line-through")}>
      {children}
    </span>
  </div>
);

// File reference within task items
export type TaskItemFileProps = HTMLAttributes<HTMLSpanElement>;

export const TaskItemFile = ({
  children,
  className,
  ...props
}: TaskItemFileProps) => (
  <span
    className={cn(
      "inline-flex items-center gap-1 rounded-md border bg-muted/50 px-1.5 py-0.5 text-xs font-mono",
      className
    )}
    {...props}
  >
    <FileIcon className="size-3" />
    {children}
  </span>
);

// Task description for additional context
export type TaskItemDescriptionProps = HTMLAttributes<HTMLDivElement>;

export const TaskItemDescription = ({
  children,
  className,
  ...props
}: TaskItemDescriptionProps) => (
  <div
    className={cn("ml-6 text-xs text-muted-foreground", className)}
    {...props}
  >
    {children}
  </div>
);
