import type { Meta, StoryObj } from '@storybook/react';
import { Suggestions, Suggestion } from '../index';

const meta: Meta<typeof Suggestions> = {
  title: 'AI/Suggestion',
  component: Suggestions,
  parameters: {
    layout: 'padded',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof Suggestions>;

export const Default: Story = {
  render: () => (
    <Suggestions className="w-[500px]">
      <Suggestion
        suggestion="Tell me more"
        onClick={(s) => console.log('Clicked:', s)}
      />
      <Suggestion
        suggestion="Show examples"
        onClick={(s) => console.log('Clicked:', s)}
      />
      <Suggestion
        suggestion="Explain in detail"
        onClick={(s) => console.log('Clicked:', s)}
      />
    </Suggestions>
  ),
};

export const CodeSuggestions: Story = {
  render: () => (
    <Suggestions className="w-[600px]">
      <Suggestion
        suggestion="Write a unit test"
        onClick={(s) => console.log('Clicked:', s)}
      />
      <Suggestion
        suggestion="Add error handling"
        onClick={(s) => console.log('Clicked:', s)}
      />
      <Suggestion
        suggestion="Optimize performance"
        onClick={(s) => console.log('Clicked:', s)}
      />
      <Suggestion
        suggestion="Add documentation"
        onClick={(s) => console.log('Clicked:', s)}
      />
    </Suggestions>
  ),
};

export const QuerySuggestions: Story = {
  render: () => (
    <Suggestions className="w-[600px]">
      <Suggestion
        suggestion="Show users from last week"
        onClick={(s) => console.log('Clicked:', s)}
      />
      <Suggestion
        suggestion="Count by category"
        onClick={(s) => console.log('Clicked:', s)}
      />
      <Suggestion
        suggestion="Filter by status"
        onClick={(s) => console.log('Clicked:', s)}
      />
      <Suggestion
        suggestion="Export to CSV"
        onClick={(s) => console.log('Clicked:', s)}
      />
    </Suggestions>
  ),
};

export const ManySuggestions: Story = {
  render: () => (
    <Suggestions className="w-[500px]">
      <Suggestion suggestion="Option 1" onClick={(s) => console.log('Clicked:', s)} />
      <Suggestion suggestion="Option 2" onClick={(s) => console.log('Clicked:', s)} />
      <Suggestion suggestion="Option 3" onClick={(s) => console.log('Clicked:', s)} />
      <Suggestion suggestion="Option 4" onClick={(s) => console.log('Clicked:', s)} />
      <Suggestion suggestion="Option 5" onClick={(s) => console.log('Clicked:', s)} />
      <Suggestion suggestion="Option 6" onClick={(s) => console.log('Clicked:', s)} />
      <Suggestion suggestion="Option 7" onClick={(s) => console.log('Clicked:', s)} />
      <Suggestion suggestion="Option 8" onClick={(s) => console.log('Clicked:', s)} />
    </Suggestions>
  ),
};

export const LongSuggestions: Story = {
  render: () => (
    <Suggestions className="w-[600px]">
      <Suggestion
        suggestion="Show me all users who signed up in the last 30 days"
        onClick={(s) => console.log('Clicked:', s)}
      />
      <Suggestion
        suggestion="What's the average order value by region?"
        onClick={(s) => console.log('Clicked:', s)}
      />
      <Suggestion
        suggestion="Compare sales between Q1 and Q2"
        onClick={(s) => console.log('Clicked:', s)}
      />
    </Suggestions>
  ),
};

export const CustomChildren: Story = {
  render: () => (
    <Suggestions className="w-[500px]">
      <Suggestion
        suggestion="custom-1"
        onClick={(s) => console.log('Clicked:', s)}
      >
        <span className="flex items-center gap-2">
          <span>📊</span>
          <span>View Analytics</span>
        </span>
      </Suggestion>
      <Suggestion
        suggestion="custom-2"
        onClick={(s) => console.log('Clicked:', s)}
      >
        <span className="flex items-center gap-2">
          <span>📝</span>
          <span>Create Report</span>
        </span>
      </Suggestion>
      <Suggestion
        suggestion="custom-3"
        onClick={(s) => console.log('Clicked:', s)}
      >
        <span className="flex items-center gap-2">
          <span>⚙️</span>
          <span>Settings</span>
        </span>
      </Suggestion>
    </Suggestions>
  ),
};

export const SingleSuggestion: Story = {
  render: () => (
    <Suggestions className="w-[400px]">
      <Suggestion
        suggestion="Continue where I left off"
        onClick={(s) => console.log('Clicked:', s)}
      />
    </Suggestions>
  ),
};
