/**
 * PromptInput component for AI chat interfaces
 * Based on ai-sdk.dev/elements/components/prompt-input
 */

import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";
import {
  FileIcon,
  MicIcon,
  PaperclipIcon,
  SendIcon,
  SquareIcon,
  XIcon,
} from "lucide-react";
import type { ComponentProps, FormEvent, HTMLAttributes } from "react";
import {
  createContext,
  useContext,
  useState,
  useRef,
  useCallback,
  useEffect,
  forwardRef,
} from "react";

// Types
export type PromptInputMessage = {
  content: string;
  attachments?: File[];
};

type PromptInputContextType = {
  value: string;
  setValue: (value: string) => void;
  attachments: File[];
  addAttachment: (file: File) => void;
  removeAttachment: (index: number) => void;
  clearAttachments: () => void;
  isSubmitting: boolean;
  setIsSubmitting: (value: boolean) => void;
};

const PromptInputContext = createContext<PromptInputContextType | null>(null);

const usePromptInput = () => {
  const context = useContext(PromptInputContext);
  if (!context) {
    throw new Error("PromptInput components must be used within PromptInput");
  }
  return context;
};

// Hook for external access to attachments
export const usePromptInputAttachments = () => {
  const context = useContext(PromptInputContext);
  return {
    attachments: context?.attachments ?? [],
    addAttachment: context?.addAttachment ?? (() => {}),
    removeAttachment: context?.removeAttachment ?? (() => {}),
    clearAttachments: context?.clearAttachments ?? (() => {}),
  };
};

export type PromptInputProps = HTMLAttributes<HTMLFormElement> & {
  onSubmit?: (message: PromptInputMessage, event: FormEvent) => void;
  accept?: string;
  multiple?: boolean;
  maxFiles?: number;
  maxFileSize?: number;
  onError?: (error: Error) => void;
};

export const PromptInput = forwardRef<HTMLFormElement, PromptInputProps>(
  (
    {
      className,
      onSubmit,
      accept,
      multiple = true,
      maxFiles = 10,
      maxFileSize = 10 * 1024 * 1024, // 10MB
      onError,
      children,
      ...props
    },
    ref
  ) => {
    const [value, setValue] = useState("");
    const [attachments, setAttachments] = useState<File[]>([]);
    const [isSubmitting, setIsSubmitting] = useState(false);

    const addAttachment = useCallback(
      (file: File) => {
        if (file.size > maxFileSize) {
          onError?.(new Error(`File "${file.name}" exceeds maximum size`));
          return;
        }
        if (attachments.length >= maxFiles) {
          onError?.(new Error(`Maximum ${maxFiles} files allowed`));
          return;
        }
        setAttachments((prev) => [...prev, file]);
      },
      [attachments.length, maxFiles, maxFileSize, onError]
    );

    const removeAttachment = useCallback((index: number) => {
      setAttachments((prev) => prev.filter((_, i) => i !== index));
    }, []);

    const clearAttachments = useCallback(() => {
      setAttachments([]);
    }, []);

    const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
      e.preventDefault();
      if (!value.trim() && attachments.length === 0) return;

      onSubmit?.(
        {
          content: value,
          attachments: attachments.length > 0 ? attachments : undefined,
        },
        e
      );

      setValue("");
      clearAttachments();
    };

    return (
      <PromptInputContext.Provider
        value={{
          value,
          setValue,
          attachments,
          addAttachment,
          removeAttachment,
          clearAttachments,
          isSubmitting,
          setIsSubmitting,
        }}
      >
        <form
          ref={ref}
          className={cn(
            "relative flex flex-col rounded-lg border bg-background",
            className
          )}
          onSubmit={handleSubmit}
          {...props}
        >
          {children}
        </form>
      </PromptInputContext.Provider>
    );
  }
);

PromptInput.displayName = "PromptInput";

// Header for attachments display
export type PromptInputHeaderProps = HTMLAttributes<HTMLDivElement>;

export const PromptInputHeader = ({
  className,
  children,
  ...props
}: PromptInputHeaderProps) => {
  const { attachments } = usePromptInput();

  if (attachments.length === 0 && !children) return null;

  return (
    <div
      className={cn("flex flex-wrap gap-2 p-3 pb-0", className)}
      {...props}
    >
      {children}
    </div>
  );
};

// Body wrapper for textarea
export type PromptInputBodyProps = HTMLAttributes<HTMLDivElement>;

export const PromptInputBody = ({
  className,
  children,
  ...props
}: PromptInputBodyProps) => (
  <div className={cn("flex-1", className)} {...props}>
    {children}
  </div>
);

// Auto-resizing textarea
export type PromptInputTextareaProps = ComponentProps<typeof Textarea> & {
  minHeight?: number;
  maxHeight?: number;
};

export const PromptInputTextarea = forwardRef<
  HTMLTextAreaElement,
  PromptInputTextareaProps
>(
  (
    { className, minHeight = 56, maxHeight = 200, onKeyDown, ...props },
    ref
  ) => {
    const { value, setValue } = usePromptInput();
    const textareaRef = useRef<HTMLTextAreaElement | null>(null);

    const setRef = useCallback(
      (node: HTMLTextAreaElement | null) => {
        textareaRef.current = node;
        if (typeof ref === "function") {
          ref(node);
        } else if (ref) {
          ref.current = node;
        }
      },
      [ref]
    );

    // Auto-resize effect
    useEffect(() => {
      const textarea = textareaRef.current;
      if (!textarea) return;

      textarea.style.height = "auto";
      const newHeight = Math.min(
        Math.max(textarea.scrollHeight, minHeight),
        maxHeight
      );
      textarea.style.height = `${newHeight}px`;
    }, [value, minHeight, maxHeight]);

    const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
      // Submit on Enter (without Shift)
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        const form = e.currentTarget.form;
        if (form) {
          form.requestSubmit();
        }
      }
      onKeyDown?.(e);
    };

    return (
      <Textarea
        ref={setRef}
        className={cn(
          "resize-none border-0 shadow-none focus-visible:ring-0 px-3 py-3",
          className
        )}
        value={value}
        onChange={(e) => setValue(e.target.value)}
        onKeyDown={handleKeyDown}
        style={{ minHeight, maxHeight }}
        {...props}
      />
    );
  }
);

PromptInputTextarea.displayName = "PromptInputTextarea";

// Footer for tools and submit
export type PromptInputFooterProps = HTMLAttributes<HTMLDivElement>;

export const PromptInputFooter = ({
  className,
  children,
  ...props
}: PromptInputFooterProps) => (
  <div
    className={cn(
      "flex items-center justify-between gap-2 px-3 pb-3",
      className
    )}
    {...props}
  >
    {children}
  </div>
);

// Tools container
export type PromptInputToolsProps = HTMLAttributes<HTMLDivElement>;

export const PromptInputTools = ({
  className,
  children,
  ...props
}: PromptInputToolsProps) => (
  <div className={cn("flex items-center gap-1", className)} {...props}>
    {children}
  </div>
);

// Submit button
export type PromptInputSubmitProps = ComponentProps<typeof Button> & {
  status?: "idle" | "submitted" | "streaming";
};

export const PromptInputSubmit = ({
  className,
  status = "idle",
  children,
  ...props
}: PromptInputSubmitProps) => {
  const { value, attachments } = usePromptInput();
  const hasContent = value.trim() || attachments.length > 0;

  const icon =
    status === "streaming" ? (
      <SquareIcon className="size-4" />
    ) : (
      <SendIcon className="size-4" />
    );

  return (
    <Button
      type="submit"
      size="icon"
      disabled={!hasContent && status !== "streaming"}
      className={cn("shrink-0", className)}
      {...props}
    >
      {children ?? icon}
    </Button>
  );
};

// Attachment button with file input
export type PromptInputAttachButtonProps = ComponentProps<typeof Button> & {
  accept?: string;
  multiple?: boolean;
};

export const PromptInputAttachButton = ({
  className,
  accept,
  multiple = true,
  children,
  ...props
}: PromptInputAttachButtonProps) => {
  const { addAttachment } = usePromptInput();
  const inputRef = useRef<HTMLInputElement>(null);

  const handleClick = () => {
    inputRef.current?.click();
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    Array.from(files).forEach(addAttachment);
    e.target.value = "";
  };

  return (
    <>
      <input
        ref={inputRef}
        type="file"
        accept={accept}
        multiple={multiple}
        className="hidden"
        onChange={handleChange}
      />
      <Button
        type="button"
        size="icon"
        variant="ghost"
        className={cn("", className)}
        onClick={handleClick}
        {...props}
      >
        {children ?? <PaperclipIcon className="size-4" />}
      </Button>
    </>
  );
};

// Speech input button
export type PromptInputSpeechButtonProps = ComponentProps<typeof Button>;

export const PromptInputSpeechButton = ({
  className,
  children,
  ...props
}: PromptInputSpeechButtonProps) => {
  const { value, setValue } = usePromptInput();
  const [isListening, setIsListening] = useState(false);
  const valueRef = useRef(value);
  valueRef.current = value;

  const handleClick = () => {
    if (!("webkitSpeechRecognition" in window || "SpeechRecognition" in window)) {
      console.warn("Speech recognition not supported");
      return;
    }

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    const recognition = new SpeechRecognition();

    recognition.continuous = false;
    recognition.interimResults = false;

    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setValue(valueRef.current + transcript);
    };

    if (isListening) {
      recognition.stop();
    } else {
      recognition.start();
    }
  };

  return (
    <Button
      type="button"
      size="icon"
      variant="ghost"
      className={cn(isListening && "text-red-500", className)}
      onClick={handleClick}
      {...props}
    >
      {children ?? <MicIcon className="size-4" />}
    </Button>
  );
};

// Attachments display
export type PromptInputAttachmentsProps = HTMLAttributes<HTMLDivElement>;

export const PromptInputAttachments = ({
  className,
  ...props
}: PromptInputAttachmentsProps) => {
  const { attachments, removeAttachment } = usePromptInput();

  if (attachments.length === 0) return null;

  return (
    <div className={cn("flex flex-wrap gap-2", className)} {...props}>
      {attachments.map((file, index) => (
        <PromptInputAttachmentItem
          key={`${file.name}-${index}`}
          file={file}
          onRemove={() => removeAttachment(index)}
        />
      ))}
    </div>
  );
};

type PromptInputAttachmentItemProps = {
  file: File;
  onRemove: () => void;
};

const PromptInputAttachmentItem = ({
  file,
  onRemove,
}: PromptInputAttachmentItemProps) => {
  const [preview, setPreview] = useState<string | null>(null);
  const isImage = file.type.startsWith("image/");

  useEffect(() => {
    if (isImage) {
      const url = URL.createObjectURL(file);
      setPreview(url);
      return () => URL.revokeObjectURL(url);
    }
  }, [file, isImage]);

  return (
    <div className="group/attachment relative flex items-center gap-2 rounded-md border bg-muted/50 p-2">
      {isImage && preview ? (
        <img
          src={preview}
          alt={file.name}
          className="size-10 rounded object-cover"
        />
      ) : (
        <>
          <FileIcon className="size-4 text-muted-foreground" />
          <span className="text-xs truncate max-w-[100px]">{file.name}</span>
        </>
      )}
      <Button
        type="button"
        size="icon"
        variant="ghost"
        className="absolute -top-1 -right-1 size-5 opacity-0 group-hover/attachment:opacity-100"
        onClick={onRemove}
      >
        <XIcon className="size-3" />
      </Button>
    </div>
  );
};
