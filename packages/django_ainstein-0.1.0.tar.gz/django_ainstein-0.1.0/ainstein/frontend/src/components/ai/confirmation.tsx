import { Alert, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { AlertCircleIcon, CheckIcon, XIcon } from "lucide-react";
import type { ComponentProps, ReactNode } from "react";
import { createContext, useContext } from "react";

// Types for tool approval workflow
export type ConfirmationState =
  | "approval-requested"
  | "approval-responded"
  | "output-denied"
  | "output-available";

export type ConfirmationApproval = {
  toolName: string;
  message?: string;
};

type ConfirmationContextType = {
  state: ConfirmationState;
  approval?: ConfirmationApproval;
};

const ConfirmationContext = createContext<ConfirmationContextType>({
  state: "approval-requested",
});

const useConfirmation = () => useContext(ConfirmationContext);

export type ConfirmationProps = ComponentProps<typeof Alert> & {
  approval?: ConfirmationApproval;
  state?: ConfirmationState;
};

export const Confirmation = ({
  className,
  approval,
  state = "approval-requested",
  children,
  ...props
}: ConfirmationProps) => (
  <ConfirmationContext.Provider value={{ state, approval }}>
    <Alert
      className={cn(
        "my-4",
        state === "output-denied" && "border-destructive/50",
        className
      )}
      variant={state === "output-denied" ? "destructive" : "default"}
      {...props}
    >
      <AlertCircleIcon className="size-4" />
      {children}
    </Alert>
  </ConfirmationContext.Provider>
);

export type ConfirmationContentProps = ComponentProps<typeof AlertDescription>;

export const ConfirmationContent = ({
  className,
  children,
  ...props
}: ConfirmationContentProps) => (
  <AlertDescription className={cn("mt-1", className)} {...props}>
    {children}
  </AlertDescription>
);

export type ConfirmationRequestProps = ComponentProps<"div"> & {
  children?: ReactNode;
};

export const ConfirmationRequest = ({
  className,
  children,
  ...props
}: ConfirmationRequestProps) => {
  const { state, approval } = useConfirmation();

  if (state !== "approval-requested") {
    return null;
  }

  return (
    <div className={cn("", className)} {...props}>
      {children ?? (
        <p className="font-medium">
          {approval?.toolName
            ? `Allow ${approval.toolName} to run?`
            : "Tool execution requested"}
        </p>
      )}
      {approval?.message && (
        <p className="mt-1 text-muted-foreground">{approval.message}</p>
      )}
    </div>
  );
};

export type ConfirmationAcceptedProps = ComponentProps<"div">;

export const ConfirmationAccepted = ({
  className,
  children,
  ...props
}: ConfirmationAcceptedProps) => {
  const { state } = useConfirmation();

  if (state !== "approval-responded" && state !== "output-available") {
    return null;
  }

  return (
    <div className={cn("flex items-center gap-2", className)} {...props}>
      <CheckIcon className="size-4 text-green-500" />
      {children ?? <span>Approved</span>}
    </div>
  );
};

export type ConfirmationRejectedProps = ComponentProps<"div">;

export const ConfirmationRejected = ({
  className,
  children,
  ...props
}: ConfirmationRejectedProps) => {
  const { state } = useConfirmation();

  if (state !== "output-denied") {
    return null;
  }

  return (
    <div className={cn("flex items-center gap-2", className)} {...props}>
      <XIcon className="size-4" />
      {children ?? <span>Rejected</span>}
    </div>
  );
};

export type ConfirmationActionsProps = ComponentProps<"div">;

export const ConfirmationActions = ({
  className,
  children,
  ...props
}: ConfirmationActionsProps) => {
  const { state } = useConfirmation();

  if (state !== "approval-requested") {
    return null;
  }

  return (
    <div className={cn("mt-3 flex gap-2", className)} {...props}>
      {children}
    </div>
  );
};

export type ConfirmationActionProps = ComponentProps<typeof Button>;

export const ConfirmationAction = ({
  className,
  ...props
}: ConfirmationActionProps) => (
  <Button className={cn("", className)} size="sm" {...props} />
);
