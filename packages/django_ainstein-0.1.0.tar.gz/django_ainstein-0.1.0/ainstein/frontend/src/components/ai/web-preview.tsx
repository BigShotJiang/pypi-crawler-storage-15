/**
 * WebPreview component for displaying web content in an iframe
 * Based on ai-sdk.dev/elements/components/web-preview
 *
 * Useful for previewing generated HTML, web apps, or external URLs
 */

"use client";

import { Button } from "@/components/ui/button";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { Input } from "@/components/ui/input";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";
import {
  ChevronDownIcon,
  ExternalLinkIcon,
  RefreshCwIcon,
  TerminalIcon,
} from "lucide-react";
import type { ComponentProps, ReactNode } from "react";
import { createContext, useContext, useEffect, useState } from "react";

// Context for sharing state between WebPreview components
export type WebPreviewContextValue = {
  url: string;
  setUrl: (url: string) => void;
  consoleOpen: boolean;
  setConsoleOpen: (open: boolean) => void;
  refresh: () => void;
};

const WebPreviewContext = createContext<WebPreviewContextValue | null>(null);

export const useWebPreview = () => {
  const context = useContext(WebPreviewContext);
  if (!context) {
    throw new Error("WebPreview components must be used within a WebPreview");
  }
  return context;
};

// Main container
export type WebPreviewProps = ComponentProps<"div"> & {
  defaultUrl?: string;
  onUrlChange?: (url: string) => void;
};

export const WebPreview = ({
  className,
  children,
  defaultUrl = "",
  onUrlChange,
  ...props
}: WebPreviewProps) => {
  const [url, setUrl] = useState(defaultUrl);
  const [consoleOpen, setConsoleOpen] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);

  const handleUrlChange = (newUrl: string) => {
    setUrl(newUrl);
    onUrlChange?.(newUrl);
  };

  const refresh = () => setRefreshKey((k) => k + 1);

  const contextValue: WebPreviewContextValue = {
    url,
    setUrl: handleUrlChange,
    consoleOpen,
    setConsoleOpen,
    refresh,
  };

  return (
    <WebPreviewContext.Provider value={contextValue} key={refreshKey}>
      <div
        className={cn(
          "flex size-full flex-col rounded-lg border bg-card overflow-hidden",
          className
        )}
        {...props}
      >
        {children}
      </div>
    </WebPreviewContext.Provider>
  );
};

// Navigation bar with URL input and controls
export type WebPreviewNavigationProps = ComponentProps<"div">;

export const WebPreviewNavigation = ({
  className,
  children,
  ...props
}: WebPreviewNavigationProps) => (
  <div
    className={cn("flex items-center gap-2 border-b p-2 bg-muted/30", className)}
    {...props}
  >
    {children}
  </div>
);

// Navigation button with tooltip
export type WebPreviewNavigationButtonProps = ComponentProps<typeof Button> & {
  tooltip?: string;
};

export const WebPreviewNavigationButton = ({
  onClick,
  disabled,
  tooltip,
  children,
  className,
  ...props
}: WebPreviewNavigationButtonProps) => (
  <TooltipProvider>
    <Tooltip>
      <TooltipTrigger asChild>
        <Button
          className={cn("size-8 p-0", className)}
          disabled={disabled}
          onClick={onClick}
          size="icon"
          variant="ghost"
          {...props}
        >
          {children}
        </Button>
      </TooltipTrigger>
      {tooltip && (
        <TooltipContent>
          <p>{tooltip}</p>
        </TooltipContent>
      )}
    </Tooltip>
  </TooltipProvider>
);

// Refresh button
export type WebPreviewRefreshButtonProps = Omit<WebPreviewNavigationButtonProps, "children">;

export const WebPreviewRefreshButton = (props: WebPreviewRefreshButtonProps) => {
  const { refresh } = useWebPreview();
  return (
    <WebPreviewNavigationButton onClick={refresh} tooltip="Refresh" {...props}>
      <RefreshCwIcon className="size-4" />
    </WebPreviewNavigationButton>
  );
};

// Open in new tab button
export type WebPreviewOpenExternalButtonProps = Omit<WebPreviewNavigationButtonProps, "children">;

export const WebPreviewOpenExternalButton = (props: WebPreviewOpenExternalButtonProps) => {
  const { url } = useWebPreview();
  return (
    <WebPreviewNavigationButton
      onClick={() => url && window.open(url, "_blank")}
      tooltip="Open in new tab"
      disabled={!url}
      {...props}
    >
      <ExternalLinkIcon className="size-4" />
    </WebPreviewNavigationButton>
  );
};

// URL input
export type WebPreviewUrlProps = ComponentProps<typeof Input>;

export const WebPreviewUrl = ({
  value,
  onChange,
  onKeyDown,
  className,
  ...props
}: WebPreviewUrlProps) => {
  const { url, setUrl } = useWebPreview();
  const [inputValue, setInputValue] = useState(url);

  // Sync input value with context URL when it changes externally
  useEffect(() => {
    setInputValue(url);
  }, [url]);

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setInputValue(event.target.value);
    onChange?.(event);
  };

  const handleKeyDown = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === "Enter") {
      const target = event.target as HTMLInputElement;
      setUrl(target.value);
    }
    onKeyDown?.(event);
  };

  return (
    <Input
      className={cn("h-8 flex-1 text-sm font-mono", className)}
      onChange={onChange ?? handleChange}
      onKeyDown={handleKeyDown}
      placeholder="Enter URL..."
      value={value ?? inputValue}
      {...props}
    />
  );
};

// Iframe body
export type WebPreviewBodyProps = ComponentProps<"iframe"> & {
  loading?: ReactNode;
};

export const WebPreviewBody = ({
  className,
  loading,
  src,
  ...props
}: WebPreviewBodyProps) => {
  const { url } = useWebPreview();
  const [isLoading, setIsLoading] = useState(true);

  const effectiveUrl = src ?? url;

  return (
    <div className="relative flex-1 min-h-0">
      {isLoading && loading && (
        <div className="absolute inset-0 flex items-center justify-center bg-muted/50">
          {loading}
        </div>
      )}
      <iframe
        className={cn("size-full border-0", className)}
        sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-presentation"
        src={effectiveUrl || undefined}
        title="Web Preview"
        onLoad={() => setIsLoading(false)}
        {...props}
      />
    </div>
  );
};

// Console log type
export type ConsoleLog = {
  level: "log" | "warn" | "error" | "info";
  message: string;
  timestamp: Date;
};

// Console panel
export type WebPreviewConsoleProps = ComponentProps<"div"> & {
  logs?: ConsoleLog[];
};

export const WebPreviewConsole = ({
  className,
  logs = [],
  children,
  ...props
}: WebPreviewConsoleProps) => {
  const { consoleOpen, setConsoleOpen } = useWebPreview();

  return (
    <Collapsible
      className={cn("border-t", className)}
      onOpenChange={setConsoleOpen}
      open={consoleOpen}
      {...props}
    >
      <CollapsibleTrigger asChild>
        <Button
          className="flex w-full items-center justify-between rounded-none px-3 py-2 h-auto font-normal hover:bg-muted/50"
          variant="ghost"
        >
          <span className="flex items-center gap-2 text-sm">
            <TerminalIcon className="size-4" />
            Console
            {logs.length > 0 && (
              <span className="text-xs text-muted-foreground">
                ({logs.length})
              </span>
            )}
          </span>
          <ChevronDownIcon
            className={cn(
              "size-4 transition-transform duration-200",
              consoleOpen && "rotate-180"
            )}
          />
        </Button>
      </CollapsibleTrigger>
      <CollapsibleContent className="border-t bg-muted/30">
        <div className="max-h-48 overflow-y-auto p-2 font-mono text-xs space-y-1">
          {logs.length === 0 ? (
            <p className="text-muted-foreground py-2 text-center">
              No console output
            </p>
          ) : (
            logs.map((log, index) => (
              <div
                className={cn(
                  "flex gap-2 px-2 py-0.5 rounded",
                  log.level === "error" && "bg-red-500/10 text-red-500",
                  log.level === "warn" && "bg-yellow-500/10 text-yellow-600",
                  log.level === "info" && "bg-blue-500/10 text-blue-500",
                  log.level === "log" && "text-foreground"
                )}
                key={`${log.timestamp.getTime()}-${index}`}
              >
                <span className="text-muted-foreground shrink-0">
                  {log.timestamp.toLocaleTimeString()}
                </span>
                <span className="break-all">{log.message}</span>
              </div>
            ))
          )}
          {children}
        </div>
      </CollapsibleContent>
    </Collapsible>
  );
};

// Convenience component for a complete web preview
export type SimpleWebPreviewProps = {
  url: string;
  height?: number | string;
  showNavigation?: boolean;
  showConsole?: boolean;
  logs?: ConsoleLog[];
  className?: string;
};

export const SimpleWebPreview = ({
  url,
  height = 400,
  showNavigation = true,
  showConsole = false,
  logs = [],
  className,
}: SimpleWebPreviewProps) => (
  <WebPreview defaultUrl={url} className={className} style={{ height }}>
    {showNavigation && (
      <WebPreviewNavigation>
        <WebPreviewRefreshButton />
        <WebPreviewUrl />
        <WebPreviewOpenExternalButton />
      </WebPreviewNavigation>
    )}
    <WebPreviewBody />
    {showConsole && <WebPreviewConsole logs={logs} />}
  </WebPreview>
);
