import type { Meta, StoryObj } from '@storybook/react';
import {
  Queue,
  QueueSection,
  QueueSectionTrigger,
  QueueSectionLabel,
  QueueSectionContent,
  QueueList,
  QueueItem,
  QueueItemIndicator,
  QueueItemContent,
  QueueItemDescription,
  QueueItemActions,
  QueueItemAction,
  QueueItemAttachment,
  QueueItemImage,
  QueueItemFile,
} from '../index';
import { ListTodoIcon, TrashIcon, EditIcon, ClipboardIcon } from 'lucide-react';

const meta: Meta<typeof Queue> = {
  title: 'AI/Queue',
  component: Queue,
  parameters: {
    layout: 'padded',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof Queue>;

export const Default: Story = {
  render: () => (
    <Queue className="w-[400px]">
      <QueueSection>
        <QueueSectionTrigger>
          <QueueSectionLabel
            label="Todo Items"
            count={3}
            icon={<ListTodoIcon className="size-4" />}
          />
        </QueueSectionTrigger>
        <QueueSectionContent>
          <QueueList>
            <QueueItem>
              <QueueItemIndicator />
              <QueueItemContent>Review pull request #42</QueueItemContent>
            </QueueItem>
            <QueueItem>
              <QueueItemIndicator />
              <QueueItemContent>Update documentation</QueueItemContent>
            </QueueItem>
            <QueueItem>
              <QueueItemIndicator completed />
              <QueueItemContent completed>Fix bug in login flow</QueueItemContent>
            </QueueItem>
          </QueueList>
        </QueueSectionContent>
      </QueueSection>
    </Queue>
  ),
};

export const WithDescriptions: Story = {
  render: () => (
    <Queue className="w-[400px]">
      <QueueSection>
        <QueueSectionTrigger>
          <QueueSectionLabel label="Project Tasks" count={4} />
        </QueueSectionTrigger>
        <QueueSectionContent>
          <QueueList>
            <QueueItem>
              <QueueItemIndicator />
              <div className="flex-1">
                <QueueItemContent>Implement user authentication</QueueItemContent>
                <QueueItemDescription>Add OAuth2 support with Google and GitHub providers</QueueItemDescription>
              </div>
            </QueueItem>
            <QueueItem>
              <QueueItemIndicator />
              <div className="flex-1">
                <QueueItemContent>Set up CI/CD pipeline</QueueItemContent>
                <QueueItemDescription>Configure GitHub Actions for automated testing and deployment</QueueItemDescription>
              </div>
            </QueueItem>
            <QueueItem>
              <QueueItemIndicator completed />
              <div className="flex-1">
                <QueueItemContent completed>Create database schema</QueueItemContent>
                <QueueItemDescription completed>Define tables for users, posts, and comments</QueueItemDescription>
              </div>
            </QueueItem>
          </QueueList>
        </QueueSectionContent>
      </QueueSection>
    </Queue>
  ),
};

export const WithActions: Story = {
  render: () => (
    <Queue className="w-[400px]">
      <QueueSection>
        <QueueSectionTrigger>
          <QueueSectionLabel label="Messages" count={2} />
        </QueueSectionTrigger>
        <QueueSectionContent>
          <QueueList>
            <QueueItem>
              <QueueItemIndicator />
              <QueueItemContent>Schedule team meeting for next week</QueueItemContent>
              <QueueItemActions>
                <QueueItemAction title="Edit">
                  <EditIcon className="size-3" />
                </QueueItemAction>
                <QueueItemAction title="Delete">
                  <TrashIcon className="size-3" />
                </QueueItemAction>
              </QueueItemActions>
            </QueueItem>
            <QueueItem>
              <QueueItemIndicator />
              <QueueItemContent>Prepare quarterly report</QueueItemContent>
              <QueueItemActions>
                <QueueItemAction title="Copy">
                  <ClipboardIcon className="size-3" />
                </QueueItemAction>
                <QueueItemAction title="Delete">
                  <TrashIcon className="size-3" />
                </QueueItemAction>
              </QueueItemActions>
            </QueueItem>
          </QueueList>
        </QueueSectionContent>
      </QueueSection>
    </Queue>
  ),
};

export const WithAttachments: Story = {
  render: () => (
    <Queue className="w-[400px]">
      <QueueSection>
        <QueueSectionTrigger>
          <QueueSectionLabel label="Files to Review" count={2} />
        </QueueSectionTrigger>
        <QueueSectionContent>
          <QueueList>
            <QueueItem>
              <QueueItemIndicator />
              <div className="flex-1">
                <QueueItemContent>Design mockups for homepage</QueueItemContent>
                <QueueItemAttachment>
                  <QueueItemImage src="https://picsum.photos/seed/1/100/100" alt="Preview" />
                  <QueueItemImage src="https://picsum.photos/seed/2/100/100" alt="Preview" />
                </QueueItemAttachment>
              </div>
            </QueueItem>
            <QueueItem>
              <QueueItemIndicator />
              <div className="flex-1">
                <QueueItemContent>Project documentation</QueueItemContent>
                <QueueItemAttachment>
                  <QueueItemFile>requirements.pdf</QueueItemFile>
                  <QueueItemFile>architecture.md</QueueItemFile>
                </QueueItemAttachment>
              </div>
            </QueueItem>
          </QueueList>
        </QueueSectionContent>
      </QueueSection>
    </Queue>
  ),
};

export const MultipleSections: Story = {
  render: () => (
    <Queue className="w-[400px]">
      <QueueSection>
        <QueueSectionTrigger>
          <QueueSectionLabel label="In Progress" count={2} />
        </QueueSectionTrigger>
        <QueueSectionContent>
          <QueueList>
            <QueueItem>
              <QueueItemIndicator />
              <QueueItemContent>Refactor authentication module</QueueItemContent>
            </QueueItem>
            <QueueItem>
              <QueueItemIndicator />
              <QueueItemContent>Add unit tests for API endpoints</QueueItemContent>
            </QueueItem>
          </QueueList>
        </QueueSectionContent>
      </QueueSection>

      <QueueSection defaultOpen={false}>
        <QueueSectionTrigger>
          <QueueSectionLabel label="Completed" count={3} />
        </QueueSectionTrigger>
        <QueueSectionContent>
          <QueueList>
            <QueueItem>
              <QueueItemIndicator completed />
              <QueueItemContent completed>Set up project structure</QueueItemContent>
            </QueueItem>
            <QueueItem>
              <QueueItemIndicator completed />
              <QueueItemContent completed>Configure linting and formatting</QueueItemContent>
            </QueueItem>
            <QueueItem>
              <QueueItemIndicator completed />
              <QueueItemContent completed>Create initial database models</QueueItemContent>
            </QueueItem>
          </QueueList>
        </QueueSectionContent>
      </QueueSection>
    </Queue>
  ),
};

export const Collapsed: Story = {
  render: () => (
    <Queue className="w-[400px]">
      <QueueSection defaultOpen={false}>
        <QueueSectionTrigger>
          <QueueSectionLabel label="Archived Tasks" count={5} />
        </QueueSectionTrigger>
        <QueueSectionContent>
          <QueueList>
            <QueueItem>
              <QueueItemIndicator completed />
              <QueueItemContent completed>Old task 1</QueueItemContent>
            </QueueItem>
            <QueueItem>
              <QueueItemIndicator completed />
              <QueueItemContent completed>Old task 2</QueueItemContent>
            </QueueItem>
          </QueueList>
        </QueueSectionContent>
      </QueueSection>
    </Queue>
  ),
};
