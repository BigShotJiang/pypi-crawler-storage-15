import type { Meta, StoryObj } from '@storybook/react';
import {
  Task,
  TaskTrigger,
  TaskContent,
  TaskItem,
  TaskItemFile,
  TaskItemDescription,
} from '../index';

const meta: Meta<typeof Task> = {
  title: 'AI/Task',
  component: Task,
  parameters: {
    layout: 'padded',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof Task>;

export const Default: Story = {
  render: () => (
    <Task className="w-[400px]">
      <TaskTrigger title="Implementation Tasks" completedCount={2} totalCount={5} />
      <TaskContent>
        <TaskItem status="completed">Create database schema</TaskItem>
        <TaskItem status="completed">Set up API routes</TaskItem>
        <TaskItem status="in-progress">Implement authentication</TaskItem>
        <TaskItem status="pending">Add unit tests</TaskItem>
        <TaskItem status="pending">Deploy to production</TaskItem>
      </TaskContent>
    </Task>
  ),
};

export const AllStatuses: Story = {
  render: () => (
    <Task className="w-[400px]">
      <TaskTrigger title="Task Status Examples" />
      <TaskContent>
        <TaskItem status="pending">Pending task - not started yet</TaskItem>
        <TaskItem status="in-progress">In progress - currently working on this</TaskItem>
        <TaskItem status="completed">Completed task - finished successfully</TaskItem>
        <TaskItem status="error">Error task - something went wrong</TaskItem>
      </TaskContent>
    </Task>
  ),
};

export const WithFiles: Story = {
  render: () => (
    <Task className="w-[400px]">
      <TaskTrigger title="File Modifications" completedCount={1} totalCount={3} />
      <TaskContent>
        <TaskItem status="completed">
          Update <TaskItemFile>src/components/Button.tsx</TaskItemFile>
        </TaskItem>
        <TaskItem status="in-progress">
          Create <TaskItemFile>src/hooks/useAuth.ts</TaskItemFile>
        </TaskItem>
        <TaskItem status="pending">
          Modify <TaskItemFile>src/pages/index.tsx</TaskItemFile>
        </TaskItem>
      </TaskContent>
    </Task>
  ),
};

export const WithDescriptions: Story = {
  render: () => (
    <Task className="w-[400px]">
      <TaskTrigger title="Feature Implementation" completedCount={1} totalCount={4} />
      <TaskContent>
        <TaskItem status="completed">Define data models</TaskItem>
        <TaskItemDescription>Created User, Post, and Comment models</TaskItemDescription>

        <TaskItem status="in-progress">Build API endpoints</TaskItem>
        <TaskItemDescription>Working on CRUD operations for posts</TaskItemDescription>

        <TaskItem status="pending">Create frontend components</TaskItem>
        <TaskItemDescription>Need to build PostList and PostDetail components</TaskItemDescription>

        <TaskItem status="pending">Write integration tests</TaskItem>
        <TaskItemDescription>Cover all API endpoints with tests</TaskItemDescription>
      </TaskContent>
    </Task>
  ),
};

export const InProgress: Story = {
  render: () => (
    <Task className="w-[400px]">
      <TaskTrigger title="Running Analysis" completedCount={2} totalCount={4} />
      <TaskContent>
        <TaskItem status="completed">Fetching data from API</TaskItem>
        <TaskItem status="completed">Parsing response</TaskItem>
        <TaskItem status="in-progress">Processing records</TaskItem>
        <TaskItem status="pending">Generating report</TaskItem>
      </TaskContent>
    </Task>
  ),
};

export const AllCompleted: Story = {
  render: () => (
    <Task className="w-[400px]">
      <TaskTrigger title="Completed Tasks" completedCount={4} totalCount={4} />
      <TaskContent>
        <TaskItem status="completed">Initialize project</TaskItem>
        <TaskItem status="completed">Set up dependencies</TaskItem>
        <TaskItem status="completed">Configure build tools</TaskItem>
        <TaskItem status="completed">Create initial components</TaskItem>
      </TaskContent>
    </Task>
  ),
};

export const WithError: Story = {
  render: () => (
    <Task className="w-[400px]">
      <TaskTrigger title="Deployment Pipeline" completedCount={2} totalCount={4} />
      <TaskContent>
        <TaskItem status="completed">Build application</TaskItem>
        <TaskItem status="completed">Run unit tests</TaskItem>
        <TaskItem status="error">Deploy to staging</TaskItem>
        <TaskItemDescription>Failed: Connection timeout to staging server</TaskItemDescription>
        <TaskItem status="pending">Run smoke tests</TaskItem>
      </TaskContent>
    </Task>
  ),
};

export const Collapsed: Story = {
  render: () => (
    <Task className="w-[400px]" defaultOpen={false}>
      <TaskTrigger title="Previous Tasks" completedCount={5} totalCount={5} />
      <TaskContent>
        <TaskItem status="completed">Task 1</TaskItem>
        <TaskItem status="completed">Task 2</TaskItem>
        <TaskItem status="completed">Task 3</TaskItem>
        <TaskItem status="completed">Task 4</TaskItem>
        <TaskItem status="completed">Task 5</TaskItem>
      </TaskContent>
    </Task>
  ),
};

export const MultipleTasks: Story = {
  render: () => (
    <div className="space-y-4 w-[400px]">
      <Task>
        <TaskTrigger title="Phase 1: Setup" completedCount={3} totalCount={3} />
        <TaskContent>
          <TaskItem status="completed">Initialize repository</TaskItem>
          <TaskItem status="completed">Configure environment</TaskItem>
          <TaskItem status="completed">Install dependencies</TaskItem>
        </TaskContent>
      </Task>

      <Task>
        <TaskTrigger title="Phase 2: Development" completedCount={1} totalCount={3} />
        <TaskContent>
          <TaskItem status="completed">Create base components</TaskItem>
          <TaskItem status="in-progress">Implement business logic</TaskItem>
          <TaskItem status="pending">Add styling</TaskItem>
        </TaskContent>
      </Task>

      <Task defaultOpen={false}>
        <TaskTrigger title="Phase 3: Testing" completedCount={0} totalCount={2} />
        <TaskContent>
          <TaskItem status="pending">Write unit tests</TaskItem>
          <TaskItem status="pending">Perform QA testing</TaskItem>
        </TaskContent>
      </Task>
    </div>
  ),
};
