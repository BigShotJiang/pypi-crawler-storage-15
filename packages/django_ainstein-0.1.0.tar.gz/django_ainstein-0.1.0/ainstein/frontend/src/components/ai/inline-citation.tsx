/**
 * Inline Citation component for displaying citations within text
 * Based on ai-sdk.dev/elements/components/inline-citation
 *
 * Simplified version that uses HoverCard for citation previews
 */

"use client";

import { Badge } from "@/components/ui/badge";
import {
  HoverCard,
  HoverCardContent,
  HoverCardTrigger,
} from "@/components/ui/hover-card";
import { cn } from "@/lib/utils";
import { ExternalLinkIcon, QuoteIcon } from "lucide-react";
import type { ComponentProps, ReactNode } from "react";

// Main inline citation wrapper
export type InlineCitationProps = ComponentProps<"span">;

export const InlineCitation = ({
  className,
  ...props
}: InlineCitationProps) => (
  <span
    className={cn("group inline items-center gap-1", className)}
    {...props}
  />
);

// Text that has a citation reference
export type InlineCitationTextProps = ComponentProps<"span">;

export const InlineCitationText = ({
  className,
  ...props
}: InlineCitationTextProps) => (
  <span
    className={cn("transition-colors group-hover:bg-accent rounded px-0.5", className)}
    {...props}
  />
);

// Citation badge that triggers the hover card
export type InlineCitationBadgeProps = ComponentProps<typeof Badge> & {
  sources: string[];
};

export const InlineCitationBadge = ({
  sources,
  className,
  ...props
}: InlineCitationBadgeProps) => {
  const hostname = sources[0] ? new URL(sources[0]).hostname : "unknown";
  const extraCount = sources.length > 1 ? ` +${sources.length - 1}` : "";

  return (
    <HoverCardTrigger asChild>
      <Badge
        className={cn("ml-1 cursor-pointer rounded-full text-xs", className)}
        variant="secondary"
        {...props}
      >
        {hostname}{extraCount}
      </Badge>
    </HoverCardTrigger>
  );
};

// HoverCard wrapper for citation
export type InlineCitationCardProps = ComponentProps<typeof HoverCard>;

export const InlineCitationCard = (props: InlineCitationCardProps) => (
  <HoverCard closeDelay={100} openDelay={200} {...props} />
);

// Citation card body/content
export type InlineCitationCardBodyProps = ComponentProps<typeof HoverCardContent>;

export const InlineCitationCardBody = ({
  className,
  ...props
}: InlineCitationCardBodyProps) => (
  <HoverCardContent
    className={cn("w-80 p-0", className)}
    side="top"
    {...props}
  />
);

// Individual source info in citation
export type InlineCitationSourceProps = ComponentProps<"div"> & {
  title?: string;
  url?: string;
  description?: string;
};

export const InlineCitationSource = ({
  title,
  url,
  description,
  className,
  children,
  ...props
}: InlineCitationSourceProps) => (
  <div className={cn("p-3 space-y-2", className)} {...props}>
    {title && (
      <h4 className="font-medium text-sm leading-tight line-clamp-2">{title}</h4>
    )}
    {url && (
      <a
        href={url}
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors"
      >
        <ExternalLinkIcon className="size-3" />
        <span className="truncate">{new URL(url).hostname}</span>
      </a>
    )}
    {description && (
      <p className="text-sm text-muted-foreground line-clamp-3 leading-relaxed">
        {description}
      </p>
    )}
    {children}
  </div>
);

// Quote block within citation
export type InlineCitationQuoteProps = ComponentProps<"blockquote">;

export const InlineCitationQuote = ({
  children,
  className,
  ...props
}: InlineCitationQuoteProps) => (
  <blockquote
    className={cn(
      "flex gap-2 border-l-2 border-muted pl-3 text-sm text-muted-foreground italic",
      className
    )}
    {...props}
  >
    <QuoteIcon className="size-4 shrink-0 mt-0.5 opacity-50" />
    <span>{children}</span>
  </blockquote>
);

// Convenience component for a complete inline citation
export type CitationProps = {
  text: ReactNode;
  sources: Array<{
    url: string;
    title?: string;
    description?: string;
    quote?: string;
  }>;
  className?: string;
};

export const Citation = ({ text, sources, className }: CitationProps) => {
  if (!sources || sources.length === 0) {
    return <span className={className}>{text}</span>;
  }

  const firstSource = sources[0];

  return (
    <InlineCitation className={className}>
      <InlineCitationCard>
        <InlineCitationText>{text}</InlineCitationText>
        <InlineCitationBadge sources={sources.map(s => s.url)} />
        <InlineCitationCardBody>
          <InlineCitationSource
            title={firstSource.title}
            url={firstSource.url}
            description={firstSource.description}
          >
            {firstSource.quote && (
              <InlineCitationQuote>{firstSource.quote}</InlineCitationQuote>
            )}
          </InlineCitationSource>
          {sources.length > 1 && (
            <div className="border-t px-3 py-2 text-xs text-muted-foreground">
              +{sources.length - 1} more source{sources.length > 2 ? "s" : ""}
            </div>
          )}
        </InlineCitationCardBody>
      </InlineCitationCard>
    </InlineCitation>
  );
};
