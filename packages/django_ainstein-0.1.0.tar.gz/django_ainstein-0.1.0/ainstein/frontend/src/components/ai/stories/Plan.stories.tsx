import type { Meta, StoryObj } from '@storybook/react';
import {
  Plan,
  PlanHeader,
  PlanTitle,
  PlanDescription,
  PlanTrigger,
  PlanContent,
  PlanFooter,
  PlanAction,
} from '../index';
import { Button } from '@/components/ui/button';

const meta: Meta<typeof Plan> = {
  title: 'AI/Plan',
  component: Plan,
  parameters: {
    layout: 'padded',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof Plan>;

export const Default: Story = {
  render: () => (
    <Plan className="w-[500px]">
      <PlanHeader>
        <div>
          <PlanTitle>Refactoring Plan</PlanTitle>
          <PlanDescription>Steps to improve code quality</PlanDescription>
        </div>
        <PlanTrigger />
      </PlanHeader>
      <PlanContent>
        <ol className="list-decimal list-inside space-y-2 text-sm">
          <li>Extract common utilities into a shared module</li>
          <li>Add TypeScript interfaces for all API responses</li>
          <li>Replace class components with functional components</li>
          <li>Add unit tests for critical functions</li>
          <li>Update documentation</li>
        </ol>
      </PlanContent>
      <PlanFooter className="justify-end gap-2">
        <Button variant="outline" size="sm">Cancel</Button>
        <Button size="sm">Execute Plan</Button>
      </PlanFooter>
    </Plan>
  ),
};

export const Streaming: Story = {
  render: () => (
    <Plan className="w-[500px]" isStreaming>
      <PlanHeader>
        <div>
          <PlanTitle />
          <PlanDescription />
        </div>
        <PlanTrigger />
      </PlanHeader>
      <PlanContent>
        <div className="space-y-2">
          <div className="h-4 w-3/4 animate-pulse rounded bg-muted" />
          <div className="h-4 w-1/2 animate-pulse rounded bg-muted" />
          <div className="h-4 w-2/3 animate-pulse rounded bg-muted" />
        </div>
      </PlanContent>
    </Plan>
  ),
};

export const Collapsed: Story = {
  render: () => (
    <Plan className="w-[500px]" defaultOpen={false}>
      <PlanHeader>
        <div>
          <PlanTitle>Database Migration Plan</PlanTitle>
          <PlanDescription>5 steps to migrate to PostgreSQL</PlanDescription>
        </div>
        <PlanTrigger />
      </PlanHeader>
      <PlanContent>
        <ol className="list-decimal list-inside space-y-2 text-sm">
          <li>Backup existing SQLite database</li>
          <li>Create PostgreSQL schema</li>
          <li>Migrate data using pgloader</li>
          <li>Update connection strings</li>
          <li>Verify data integrity</li>
        </ol>
      </PlanContent>
    </Plan>
  ),
};

export const WithActions: Story = {
  render: () => (
    <Plan className="w-[500px]">
      <PlanHeader>
        <div>
          <PlanTitle>Feature Implementation</PlanTitle>
          <PlanDescription>Add user authentication</PlanDescription>
        </div>
        <PlanAction>
          <Button variant="ghost" size="sm">Edit</Button>
        </PlanAction>
      </PlanHeader>
      <PlanContent>
        <ul className="space-y-2 text-sm">
          <li className="flex items-center gap-2">
            <span className="text-green-500">✓</span>
            Create user model
          </li>
          <li className="flex items-center gap-2">
            <span className="text-green-500">✓</span>
            Add registration endpoint
          </li>
          <li className="flex items-center gap-2">
            <span className="text-blue-500 animate-spin">◌</span>
            Implement JWT tokens
          </li>
          <li className="flex items-center gap-2">
            <span className="text-muted-foreground">○</span>
            Add login endpoint
          </li>
          <li className="flex items-center gap-2">
            <span className="text-muted-foreground">○</span>
            Create auth middleware
          </li>
        </ul>
      </PlanContent>
      <PlanFooter className="text-xs text-muted-foreground">
        2 of 5 steps completed
      </PlanFooter>
    </Plan>
  ),
};

export const MultiplePlans: Story = {
  render: () => (
    <div className="space-y-4 w-[500px]">
      <Plan>
        <PlanHeader>
          <div>
            <PlanTitle>Phase 1: Setup</PlanTitle>
            <PlanDescription>Initialize project structure</PlanDescription>
          </div>
          <PlanTrigger />
        </PlanHeader>
        <PlanContent>
          <p className="text-sm text-green-500">Completed</p>
        </PlanContent>
      </Plan>

      <Plan>
        <PlanHeader>
          <div>
            <PlanTitle>Phase 2: Development</PlanTitle>
            <PlanDescription>Build core features</PlanDescription>
          </div>
          <PlanTrigger />
        </PlanHeader>
        <PlanContent>
          <p className="text-sm text-blue-500">In Progress (60%)</p>
        </PlanContent>
      </Plan>

      <Plan defaultOpen={false}>
        <PlanHeader>
          <div>
            <PlanTitle>Phase 3: Testing</PlanTitle>
            <PlanDescription>QA and bug fixes</PlanDescription>
          </div>
          <PlanTrigger />
        </PlanHeader>
        <PlanContent>
          <p className="text-sm text-muted-foreground">Not started</p>
        </PlanContent>
      </Plan>
    </div>
  ),
};
