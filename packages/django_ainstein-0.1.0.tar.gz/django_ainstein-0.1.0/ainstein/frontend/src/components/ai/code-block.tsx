import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { CheckIcon, CopyIcon } from "lucide-react";
import type { ComponentProps, HTMLAttributes, ReactNode } from "react";
import { createContext, useContext, useState, useEffect, memo } from "react";
import { codeToHtml, normalizeLanguage } from "@/lib/shiki.bundle";

type CodeBlockContextType = {
  code: string;
};

const CodeBlockContext = createContext<CodeBlockContextType>({
  code: "",
});

export type CodeBlockProps = HTMLAttributes<HTMLDivElement> & {
  code?: string;
  language?: string;
  showLineNumbers?: boolean;
  wordWrap?: boolean;
  children?: ReactNode;
};

export const CodeBlock = memo(({
  code = "",
  language = "text",
  showLineNumbers = false,
  wordWrap = true,
  className,
  children,
  ...props
}: CodeBlockProps) => {
  const [highlightedHtml, setHighlightedHtml] = useState<string>("");
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    let isMounted = true;
    setIsLoading(true);

    const highlight = async () => {
      try {
        // Normalize language to a supported one (falls back to bash)
        const normalizedLang = normalizeLanguage(language);
        const html = await codeToHtml(code, {
          lang: normalizedLang,
          theme: "github-dark",
        });

        if (isMounted) {
          setHighlightedHtml(html);
          setIsLoading(false);
        }
      } catch (error) {
        // Fallback to plain text if highlighting fails
        if (isMounted) {
          setHighlightedHtml(`<pre><code>${escapeHtml(code)}</code></pre>`);
          setIsLoading(false);
        }
      }
    };

    highlight();

    return () => {
      isMounted = false;
    };
  }, [code, language]);

  return (
    <CodeBlockContext.Provider value={{ code }}>
      <div
        className={cn(
          "code-block relative w-full rounded-md border bg-muted/50",
          showLineNumbers && "show-line-numbers",
          className
        )}
        {...props}
      >
        <div className="relative h-full">
          {isLoading ? (
            <pre className={cn(
              "p-4 font-mono text-sm",
              wordWrap && "whitespace-pre-wrap break-words"
            )}>
              <code>{code}</code>
            </pre>
          ) : (
            <div
              className={cn(
                "[&_pre]:m-0 [&_pre]:p-4 [&_pre]:bg-transparent [&_code]:font-mono [&_code]:text-sm",
                wordWrap
                  ? "[&_pre]:whitespace-pre-wrap [&_pre]:break-words [&_code]:whitespace-pre-wrap [&_code]:break-words"
                  : "overflow-x-auto"
              )}
              dangerouslySetInnerHTML={{ __html: highlightedHtml }}
            />
          )}
          {children && (
            <div className="absolute top-2 right-2 flex items-center gap-2">
              {children}
            </div>
          )}
        </div>
      </div>
    </CodeBlockContext.Provider>
  );
});

CodeBlock.displayName = "CodeBlock";

function escapeHtml(text: string): string {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

export type CodeBlockCopyButtonProps = ComponentProps<typeof Button> & {
  onCopy?: () => void;
  onError?: (error: Error) => void;
  timeout?: number;
};

export const CodeBlockCopyButton = ({
  onCopy,
  onError,
  timeout = 2000,
  children,
  className,
  ...props
}: CodeBlockCopyButtonProps) => {
  const [isCopied, setIsCopied] = useState(false);
  const { code } = useContext(CodeBlockContext);

  const copyToClipboard = async () => {
    if (typeof window === "undefined" || !navigator.clipboard?.writeText) {
      onError?.(new Error("Clipboard API not available"));
      return;
    }

    try {
      await navigator.clipboard.writeText(code);
      setIsCopied(true);
      onCopy?.();
      setTimeout(() => setIsCopied(false), timeout);
    } catch (error) {
      onError?.(error as Error);
    }
  };

  const Icon = isCopied ? CheckIcon : CopyIcon;

  return (
    <Button
      className={cn("shrink-0", className)}
      onClick={copyToClipboard}
      size="icon"
      variant="ghost"
      {...props}
    >
      {children ?? <Icon size={14} />}
    </Button>
  );
};
