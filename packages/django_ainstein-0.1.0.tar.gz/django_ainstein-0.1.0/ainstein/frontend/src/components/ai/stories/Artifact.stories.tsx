import type { Meta, StoryObj } from '@storybook/react';
import {
  Artifact,
  ArtifactHeader,
  ArtifactTitle,
  ArtifactDescription,
  ArtifactActions,
  ArtifactAction,
  ArtifactClose,
  ArtifactContent,
  ArtifactLoading,
  ArtifactError,
  ArtifactEmpty,
  CodeBlock,
} from '../index';
import { CopyIcon, DownloadIcon, ExternalLinkIcon } from 'lucide-react';

const meta: Meta<typeof Artifact> = {
  title: 'AI/Artifact',
  component: Artifact,
  parameters: {
    layout: 'padded',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof Artifact>;

export const Default: Story = {
  render: () => (
    <Artifact className="w-[600px]">
      <ArtifactHeader>
        <div>
          <ArtifactTitle>Generated Code</ArtifactTitle>
          <ArtifactDescription>Python script for data processing</ArtifactDescription>
        </div>
        <ArtifactActions>
          <ArtifactAction icon={CopyIcon} tooltip="Copy to clipboard" />
          <ArtifactAction icon={DownloadIcon} tooltip="Download file" />
          <ArtifactClose />
        </ArtifactActions>
      </ArtifactHeader>
      <ArtifactContent className="p-4">
        <CodeBlock
          language="python"
          code={`def process_data(data: list) -> dict:
    """Process and aggregate data."""
    result = {}
    for item in data:
        key = item.get('category')
        if key not in result:
            result[key] = []
        result[key].append(item['value'])
    return result`}
        />
      </ArtifactContent>
    </Artifact>
  ),
};

export const WithDocument: Story = {
  render: () => (
    <Artifact className="w-[600px]">
      <ArtifactHeader>
        <div>
          <ArtifactTitle>README.md</ArtifactTitle>
          <ArtifactDescription>Project documentation</ArtifactDescription>
        </div>
        <ArtifactActions>
          <ArtifactAction icon={ExternalLinkIcon} tooltip="Open in editor" />
          <ArtifactClose />
        </ArtifactActions>
      </ArtifactHeader>
      <ArtifactContent className="p-4 prose prose-invert prose-sm max-w-none">
        <h1>Project Title</h1>
        <p>A brief description of what this project does and who it's for.</p>
        <h2>Installation</h2>
        <pre><code>npm install my-project</code></pre>
        <h2>Usage</h2>
        <p>Import and use the component in your React application.</p>
      </ArtifactContent>
    </Artifact>
  ),
};

export const Loading: Story = {
  render: () => (
    <Artifact className="w-[600px]">
      <ArtifactHeader>
        <div>
          <ArtifactTitle>Generating...</ArtifactTitle>
        </div>
        <ArtifactClose />
      </ArtifactHeader>
      <ArtifactContent>
        <ArtifactLoading />
      </ArtifactContent>
    </Artifact>
  ),
};

export const Error: Story = {
  render: () => (
    <Artifact className="w-[600px]">
      <ArtifactHeader>
        <div>
          <ArtifactTitle>Failed to Generate</ArtifactTitle>
        </div>
        <ArtifactClose />
      </ArtifactHeader>
      <ArtifactContent>
        <ArtifactError message="Unable to generate content. Please try again." />
      </ArtifactContent>
    </Artifact>
  ),
};

export const Empty: Story = {
  render: () => (
    <Artifact className="w-[600px]">
      <ArtifactHeader>
        <div>
          <ArtifactTitle>Preview</ArtifactTitle>
        </div>
        <ArtifactClose />
      </ArtifactHeader>
      <ArtifactContent>
        <ArtifactEmpty message="No content generated yet" />
      </ArtifactContent>
    </Artifact>
  ),
};

export const MultipleArtifacts: Story = {
  render: () => (
    <div className="space-y-4 w-[600px]">
      <Artifact>
        <ArtifactHeader>
          <ArtifactTitle>Component.tsx</ArtifactTitle>
          <ArtifactActions>
            <ArtifactAction icon={CopyIcon} tooltip="Copy" />
          </ArtifactActions>
        </ArtifactHeader>
        <ArtifactContent className="p-4">
          <CodeBlock
            language="typescript"
            code={`export const Button = ({ children }: { children: React.ReactNode }) => (
  <button className="px-4 py-2 bg-blue-500 rounded">{children}</button>
);`}
          />
        </ArtifactContent>
      </Artifact>

      <Artifact>
        <ArtifactHeader>
          <ArtifactTitle>styles.css</ArtifactTitle>
          <ArtifactActions>
            <ArtifactAction icon={CopyIcon} tooltip="Copy" />
          </ArtifactActions>
        </ArtifactHeader>
        <ArtifactContent className="p-4">
          <CodeBlock
            language="css"
            code={`.button {
  padding: 0.5rem 1rem;
  background-color: #3b82f6;
  border-radius: 0.25rem;
}`}
          />
        </ArtifactContent>
      </Artifact>
    </div>
  ),
};
