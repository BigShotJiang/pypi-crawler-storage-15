/**
 * Permission Dialog component for human-in-the-loop confirmation
 * Displays when a tool requires user approval before execution
 * Design based on ai-sdk.dev/elements/components/confirmation
 */

import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Loader2 } from "lucide-react";

export interface PermissionRequest {
  request_id: string;
  message: string;
  action: string;
  tool_name?: string;
  tool_input?: Record<string, unknown>;
  rows_requested?: number;
  rows_limit?: number;
}

export type PermissionState = "pending" | "approving" | "approved" | "denied";

export interface PermissionDialogProps {
  request: PermissionRequest;
  state: PermissionState;
  onApprove: () => void;
  onDeny: () => void;
  className?: string;
}

export const PermissionDialog = ({
  request,
  state,
  onApprove,
  onDeny,
  className,
}: PermissionDialogProps) => {
  const isPending = state === "pending";
  const isApproving = state === "approving";
  const isApproved = state === "approved";
  const isDenied = state === "denied";

  return (
    <div
      className={cn(
        "rounded-xl border border-border bg-card p-4",
        isApproved && "border-green-500/30 bg-green-500/5",
        isDenied && "border-red-500/30 bg-red-500/5",
        className
      )}
      data-testid="permission-dialog"
      data-state={state}
    >
      <div className="space-y-4">
        <div className="space-y-2">
          <p className="text-sm text-foreground font-medium">
            {request.tool_name ? `Tool: ${request.tool_name}` : request.action}
          </p>
          <p className="text-sm text-muted-foreground" data-testid="permission-message">
            {request.message}
          </p>
          {request.tool_input?.code && (
            <pre className="rounded bg-muted p-3 font-mono text-xs overflow-x-auto max-h-48 overflow-y-auto">
              {String(request.tool_input.code)}
            </pre>
          )}
          {request.rows_requested && request.rows_limit && (
            <p className="text-xs text-muted-foreground">
              Requesting {request.rows_requested.toLocaleString()} rows (limit: {request.rows_limit.toLocaleString()})
            </p>
          )}
          <p className="text-sm text-foreground mt-2">
            Do you approve this action?
          </p>
        </div>

        {(isPending || isApproving) && (
          <div className="flex items-center justify-end gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={onDeny}
              disabled={isApproving}
              className="h-8 px-4"
              data-testid="permission-deny"
            >
              Reject
            </Button>
            <Button
              size="sm"
              onClick={onApprove}
              disabled={isApproving}
              className="h-8 px-4 bg-primary hover:bg-primary/90"
              data-testid="permission-approve"
            >
              {isApproving ? (
                <>
                  <Loader2 className="mr-2 h-3 w-3 animate-spin" />
                  Approving...
                </>
              ) : (
                "Approve"
              )}
            </Button>
          </div>
        )}

        {isApproved && (
          <p className="text-sm text-green-500">Action approved</p>
        )}

        {isDenied && (
          <p className="text-sm text-red-500">Action rejected</p>
        )}
      </div>
    </div>
  );
};
