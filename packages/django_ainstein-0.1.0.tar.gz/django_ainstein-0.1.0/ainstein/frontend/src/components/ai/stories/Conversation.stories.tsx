import type { Meta, StoryObj } from '@storybook/react';
import {
  Conversation,
  ConversationContent,
  ConversationEmptyState,
  Message,
  MessageContent,
  Response,
} from '../index';
import { BotIcon, SparklesIcon } from 'lucide-react';

const meta: Meta<typeof Conversation> = {
  title: 'AI/Conversation',
  component: Conversation,
  parameters: {
    layout: 'fullscreen',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof Conversation>;

export const Empty: Story = {
  render: () => (
    <div className="h-[400px]">
      <Conversation>
        <ConversationContent>
          <ConversationEmptyState
            title="Welcome to Claude"
            description="Ask me anything to get started"
          />
        </ConversationContent>
      </Conversation>
    </div>
  ),
};

export const CustomEmptyState: Story = {
  render: () => (
    <div className="h-[400px]">
      <Conversation>
        <ConversationContent>
          <ConversationEmptyState
            title="Database Assistant"
            description="I can help you query and analyze your data"
            icon={
              <div className="rounded-full bg-primary/10 p-4">
                <SparklesIcon className="size-8 text-primary" />
              </div>
            }
          />
        </ConversationContent>
      </Conversation>
    </div>
  ),
};

export const WithMessages: Story = {
  render: () => (
    <div className="h-[500px]">
      <Conversation>
        <ConversationContent className="space-y-4 p-4">
          <Message from="user">
            <MessageContent className="rounded-lg rounded-tr-sm">
              <div>How do I create a React component?</div>
            </MessageContent>
          </Message>

          <Message from="assistant">
            <MessageContent className="rounded-lg rounded-bl-sm">
              <Response>
{`Here's a simple example of a React functional component:

\`\`\`tsx
const MyComponent = ({ name }: { name: string }) => {
  return <div>Hello, {name}!</div>;
};
\`\`\`

You can use it like this: \`<MyComponent name="World" />\``}
              </Response>
            </MessageContent>
          </Message>

          <Message from="user">
            <MessageContent className="rounded-lg rounded-tr-sm">
              <div>How do I add state to it?</div>
            </MessageContent>
          </Message>

          <Message from="assistant">
            <MessageContent className="rounded-lg rounded-bl-sm">
              <Response>
{`Use the \`useState\` hook:

\`\`\`tsx
import { useState } from 'react';

const Counter = () => {
  const [count, setCount] = useState(0);

  return (
    <button onClick={() => setCount(c => c + 1)}>
      Count: {count}
    </button>
  );
};
\`\`\``}
              </Response>
            </MessageContent>
          </Message>
        </ConversationContent>
      </Conversation>
    </div>
  ),
};

export const LongConversation: Story = {
  render: () => (
    <div className="h-[400px]">
      <Conversation>
        <ConversationContent className="space-y-4 p-4">
          {Array.from({ length: 10 }, (_, i) => (
            <div key={i} className="space-y-4">
              <Message from="user">
                <MessageContent className="rounded-lg rounded-tr-sm">
                  <div>Question {i + 1}: How does this work?</div>
                </MessageContent>
              </Message>
              <Message from="assistant">
                <MessageContent className="rounded-lg rounded-bl-sm">
                  <Response>{`This is the response to question ${i + 1}. The conversation auto-scrolls to the latest message.`}</Response>
                </MessageContent>
              </Message>
            </div>
          ))}
        </ConversationContent>
      </Conversation>
    </div>
  ),
};
