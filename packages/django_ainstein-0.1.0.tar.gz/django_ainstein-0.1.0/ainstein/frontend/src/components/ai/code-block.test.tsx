/**
 * Tests for CodeBlock component
 */

import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { render, screen, waitFor } from '@/test/utils';
import { CodeBlock, CodeBlockCopyButton } from './code-block';

// Mock the shiki bundle
vi.mock('@/lib/shiki.bundle', () => ({
  codeToHtml: vi.fn().mockImplementation(async (code: string) => {
    return `<pre><code class="shiki">${code}</code></pre>`;
  }),
  normalizeLanguage: vi.fn().mockImplementation((lang: string) => lang || 'text'),
}));

describe('CodeBlock', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('rendering', () => {
    it('renders code content', async () => {
      render(<CodeBlock code="const x = 1;" language="javascript" />);

      await waitFor(() => {
        expect(screen.getByText('const x = 1;')).toBeInTheDocument();
      });
    });

    it('renders with default language when not specified', async () => {
      render(<CodeBlock code="hello world" />);

      await waitFor(() => {
        expect(screen.getByText('hello world')).toBeInTheDocument();
      });
    });

    it('renders children in absolute positioned container', async () => {
      render(
        <CodeBlock code="test code">
          <button>Copy</button>
        </CodeBlock>
      );

      expect(screen.getByRole('button', { name: 'Copy' })).toBeInTheDocument();
    });

    it('applies custom className', async () => {
      const { container } = render(
        <CodeBlock code="test" className="custom-class" />
      );

      expect(container.querySelector('.custom-class')).toBeInTheDocument();
    });

    it('applies show-line-numbers class when showLineNumbers is true', async () => {
      const { container } = render(
        <CodeBlock code="test" showLineNumbers={true} />
      );

      expect(container.querySelector('.show-line-numbers')).toBeInTheDocument();
    });
  });

  describe('loading state', () => {
    it('shows raw code initially before highlighting', () => {
      render(<CodeBlock code="initial code" language="javascript" />);

      // Should show the code in a pre/code element during loading
      expect(screen.getByText('initial code')).toBeInTheDocument();
    });
  });

  describe('word wrap', () => {
    it('applies whitespace-pre-wrap by default', async () => {
      const { container } = render(<CodeBlock code="long code line" />);

      // Wait for highlighting to complete
      await waitFor(() => {
        const wrapper = container.querySelector('[class*="whitespace-pre-wrap"]');
        expect(wrapper).toBeInTheDocument();
      });
    });

    it('applies overflow-x-auto when wordWrap is false', async () => {
      const { container } = render(<CodeBlock code="long code line" wordWrap={false} />);

      // Wait for highlighting to complete
      await waitFor(() => {
        const wrapper = container.querySelector('.overflow-x-auto');
        expect(wrapper).toBeInTheDocument();
      });
    });
  });

  describe('error handling', () => {
    it('falls back to plain text on highlighting error', async () => {
      const { codeToHtml } = await import('@/lib/shiki.bundle');
      vi.mocked(codeToHtml).mockRejectedValueOnce(new Error('Highlight failed'));

      render(<CodeBlock code="<script>alert('test')</script>" language="html" />);

      // Should show escaped HTML as fallback
      await waitFor(() => {
        const codeElement = screen.getByText((content) =>
          content.includes('&lt;script&gt;') || content.includes("<script>alert('test')</script>")
        );
        expect(codeElement).toBeInTheDocument();
      });
    });
  });
});

describe('CodeBlockCopyButton', () => {
  const originalClipboard = navigator.clipboard;

  beforeEach(() => {
    vi.clearAllMocks();
    // Mock clipboard API
    Object.assign(navigator, {
      clipboard: {
        writeText: vi.fn().mockResolvedValue(undefined),
      },
    });
  });

  afterEach(() => {
    // Restore original clipboard
    Object.assign(navigator, { clipboard: originalClipboard });
    vi.useRealTimers();
  });

  it('renders copy button with icon', () => {
    render(
      <CodeBlock code="test code">
        <CodeBlockCopyButton />
      </CodeBlock>
    );

    const button = screen.getByRole('button');
    expect(button).toBeInTheDocument();
  });

  it('copies code to clipboard on click', async () => {
    const onCopy = vi.fn();
    render(
      <CodeBlock code="code to copy">
        <CodeBlockCopyButton onCopy={onCopy} />
      </CodeBlock>
    );

    const button = screen.getByRole('button');
    button.click();

    await waitFor(() => {
      expect(navigator.clipboard.writeText).toHaveBeenCalledWith('code to copy');
      expect(onCopy).toHaveBeenCalled();
    });
  });

  it('shows check icon after copying', async () => {
    render(
      <CodeBlock code="test">
        <CodeBlockCopyButton timeout={100} />
      </CodeBlock>
    );

    const button = screen.getByRole('button');
    button.click();

    // Wait for copy to complete
    await waitFor(() => {
      expect(navigator.clipboard.writeText).toHaveBeenCalled();
    });

    // Just verify the copy happened - icon state change is visual
  });

  it('calls onError when clipboard API fails', async () => {
    const error = new Error('Copy failed');
    vi.mocked(navigator.clipboard.writeText).mockRejectedValueOnce(error);

    const onError = vi.fn();
    render(
      <CodeBlock code="test">
        <CodeBlockCopyButton onError={onError} />
      </CodeBlock>
    );

    const button = screen.getByRole('button');
    button.click();

    await waitFor(() => {
      expect(onError).toHaveBeenCalledWith(error);
    });
  });

  it('calls onError when clipboard API is not available', async () => {
    // Remove clipboard API
    Object.assign(navigator, { clipboard: undefined });

    const onError = vi.fn();
    render(
      <CodeBlock code="test">
        <CodeBlockCopyButton onError={onError} />
      </CodeBlock>
    );

    const button = screen.getByRole('button');
    button.click();

    await waitFor(() => {
      expect(onError).toHaveBeenCalledWith(expect.any(Error));
    });
  });

  it('renders custom children instead of icon', () => {
    render(
      <CodeBlock code="test">
        <CodeBlockCopyButton>Custom Copy Text</CodeBlockCopyButton>
      </CodeBlock>
    );

    expect(screen.getByText('Custom Copy Text')).toBeInTheDocument();
  });

  it('applies custom className', () => {
    render(
      <CodeBlock code="test">
        <CodeBlockCopyButton className="custom-btn-class" />
      </CodeBlock>
    );

    const button = screen.getByRole('button');
    expect(button).toHaveClass('custom-btn-class');
  });
});

describe('escapeHtml (via error fallback)', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('escapes HTML special characters in fallback mode', async () => {
    const { codeToHtml } = await import('@/lib/shiki.bundle');
    vi.mocked(codeToHtml).mockRejectedValueOnce(new Error('Highlight failed'));

    const testCode = '<div class="test">&</div>';
    const { container } = render(
      <CodeBlock code={testCode} language="html" />
    );

    // Wait for fallback to be applied
    await waitFor(() => {
      const html = container.innerHTML;
      // Should contain escaped entities or raw code in pre/code
      expect(
        html.includes('&amp;lt;') || // Double escaped
        html.includes('&lt;') ||      // Single escaped
        html.includes(testCode) // Raw in pre/code
      ).toBe(true);
    });
  });
});
