/**
 * Queue component for displaying message lists and todos
 * Based on ai-sdk.dev/elements/components/queue
 */

import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { cn } from "@/lib/utils";
import {
  CheckCircle2Icon,
  ChevronDownIcon,
  CircleIcon,
  FileIcon,
} from "lucide-react";
import type { ComponentProps, HTMLAttributes, ReactNode } from "react";

// Queue container
export type QueueProps = HTMLAttributes<HTMLDivElement>;

export const Queue = ({ className, children, ...props }: QueueProps) => (
  <div className={cn("flex flex-col gap-2", className)} {...props}>
    {children}
  </div>
);

// Collapsible section
export type QueueSectionProps = ComponentProps<typeof Collapsible>;

export const QueueSection = ({
  className,
  defaultOpen = true,
  children,
  ...props
}: QueueSectionProps) => (
  <Collapsible
    className={cn("rounded-md border", className)}
    defaultOpen={defaultOpen}
    {...props}
  >
    {children}
  </Collapsible>
);

// Section trigger button
export type QueueSectionTriggerProps = ComponentProps<typeof CollapsibleTrigger>;

export const QueueSectionTrigger = ({
  className,
  children,
  ...props
}: QueueSectionTriggerProps) => (
  <CollapsibleTrigger
    className={cn(
      "group flex w-full items-center justify-between p-3 hover:bg-muted/50",
      className
    )}
    {...props}
  >
    {children}
    <ChevronDownIcon className="size-4 text-muted-foreground transition-transform group-data-[state=open]:rotate-180" />
  </CollapsibleTrigger>
);

// Section label with optional count and icon
export type QueueSectionLabelProps = HTMLAttributes<HTMLSpanElement> & {
  label?: string;
  count?: number;
  icon?: ReactNode;
};

export const QueueSectionLabel = ({
  className,
  label,
  count,
  icon,
  children,
  ...props
}: QueueSectionLabelProps) => (
  <span
    className={cn("flex items-center gap-2 text-sm font-medium", className)}
    {...props}
  >
    {icon}
    {label ?? children}
    {count !== undefined && (
      <span className="rounded-full bg-muted px-2 py-0.5 text-xs text-muted-foreground">
        {count}
      </span>
    )}
  </span>
);

// Section content
export type QueueSectionContentProps = ComponentProps<typeof CollapsibleContent>;

export const QueueSectionContent = ({
  className,
  children,
  ...props
}: QueueSectionContentProps) => (
  <CollapsibleContent className={cn("", className)} {...props}>
    <div className="border-t">{children}</div>
  </CollapsibleContent>
);

// Scrollable list
export type QueueListProps = ComponentProps<typeof ScrollArea>;

export const QueueList = ({
  className,
  children,
  ...props
}: QueueListProps) => (
  <ScrollArea className={cn("max-h-[300px]", className)} {...props}>
    <ul className="divide-y">{children}</ul>
  </ScrollArea>
);

// Individual item
export type QueueItemProps = HTMLAttributes<HTMLLIElement>;

export const QueueItem = ({
  className,
  children,
  ...props
}: QueueItemProps) => (
  <li
    className={cn(
      "group flex items-start gap-3 p-3 hover:bg-muted/30",
      className
    )}
    {...props}
  >
    {children}
  </li>
);

// Completion indicator
export type QueueItemIndicatorProps = HTMLAttributes<HTMLSpanElement> & {
  completed?: boolean;
};

export const QueueItemIndicator = ({
  className,
  completed = false,
  ...props
}: QueueItemIndicatorProps) => (
  <span
    className={cn("mt-0.5 shrink-0", className)}
    {...props}
  >
    {completed ? (
      <CheckCircle2Icon className="size-4 text-green-500" />
    ) : (
      <CircleIcon className="size-4 text-muted-foreground" />
    )}
  </span>
);

// Item content
export type QueueItemContentProps = HTMLAttributes<HTMLSpanElement> & {
  completed?: boolean;
};

export const QueueItemContent = ({
  className,
  completed = false,
  children,
  ...props
}: QueueItemContentProps) => (
  <span
    className={cn(
      "flex-1 text-sm",
      completed && "text-muted-foreground line-through",
      className
    )}
    {...props}
  >
    {children}
  </span>
);

// Item description
export type QueueItemDescriptionProps = HTMLAttributes<HTMLDivElement> & {
  completed?: boolean;
};

export const QueueItemDescription = ({
  className,
  completed = false,
  children,
  ...props
}: QueueItemDescriptionProps) => (
  <div
    className={cn(
      "text-xs text-muted-foreground",
      completed && "line-through",
      className
    )}
    {...props}
  >
    {children}
  </div>
);

// Hover-revealed actions
export type QueueItemActionsProps = HTMLAttributes<HTMLDivElement>;

export const QueueItemActions = ({
  className,
  children,
  ...props
}: QueueItemActionsProps) => (
  <div
    className={cn(
      "flex items-center gap-1 opacity-0 transition-opacity group-hover:opacity-100",
      className
    )}
    {...props}
  >
    {children}
  </div>
);

// Action button
export type QueueItemActionProps = Omit<
  ComponentProps<typeof Button>,
  "variant" | "size"
>;

export const QueueItemAction = ({
  className,
  children,
  ...props
}: QueueItemActionProps) => (
  <Button
    variant="ghost"
    size="icon"
    className={cn("size-6", className)}
    {...props}
  >
    {children}
  </Button>
);

// Attachment container
export type QueueItemAttachmentProps = HTMLAttributes<HTMLDivElement>;

export const QueueItemAttachment = ({
  className,
  children,
  ...props
}: QueueItemAttachmentProps) => (
  <div
    className={cn(
      "mt-2 flex flex-wrap gap-2",
      className
    )}
    {...props}
  >
    {children}
  </div>
);

// Image display
export type QueueItemImageProps = HTMLAttributes<HTMLImageElement> &
  React.ImgHTMLAttributes<HTMLImageElement>;

export const QueueItemImage = ({
  className,
  ...props
}: QueueItemImageProps) => (
  <img
    className={cn("size-16 rounded-md object-cover", className)}
    {...props}
  />
);

// File indicator
export type QueueItemFileProps = HTMLAttributes<HTMLSpanElement>;

export const QueueItemFile = ({
  className,
  children,
  ...props
}: QueueItemFileProps) => (
  <span
    className={cn(
      "inline-flex items-center gap-1 rounded-md border bg-muted/50 px-2 py-1 text-xs",
      className
    )}
    {...props}
  >
    <FileIcon className="size-3" />
    {children}
  </span>
);
