import { cn } from "@/lib/utils";
import { Spinner } from "@/components/ui/spinner";
import type { HTMLAttributes } from "react";

export type LoaderProps = HTMLAttributes<HTMLDivElement> & {
  size?: "sm" | "md" | "lg";
};

// Size mappings for the spinner
const sizeClasses = {
  sm: "size-4",
  md: "size-6",
  lg: "size-8",
};

export const LoaderIcon = ({
  className,
  size = "md",
  ...props
}: HTMLAttributes<SVGSVGElement> & { size?: "sm" | "md" | "lg" | number }) => {
  // Handle numeric size for backward compatibility
  const sizeClass = typeof size === "number"
    ? undefined
    : sizeClasses[size];

  return (
    <Spinner
      className={cn(sizeClass, className)}
      style={typeof size === "number" ? { width: size, height: size } : undefined}
      {...props}
    />
  );
};

export const Loader = ({ className, size = "md", ...props }: LoaderProps) => (
  <div
    className={cn("flex items-center justify-center", className)}
    {...props}
  >
    <LoaderIcon size={size} />
  </div>
);

// Re-export Spinner for direct use
export { Spinner } from "@/components/ui/spinner";
