/**
 * Tests for Sources component
 *
 * Tests collapsible sources display for web search results
 */

import { describe, it, expect } from 'vitest';
import { render, screen } from '@/test/utils';
import userEvent from '@testing-library/user-event';
import {
  Sources,
  SourcesTrigger,
  SourcesContent,
  Source,
  SourcesList,
} from './sources';

describe('Sources', () => {
  it('renders as a collapsible container', () => {
    render(
      <Sources data-testid="sources">
        <SourcesTrigger count={3} />
        <SourcesContent>Content</SourcesContent>
      </Sources>
    );

    expect(screen.getByTestId('sources')).toBeInTheDocument();
  });
});

describe('SourcesTrigger', () => {
  it('displays source count singular', () => {
    render(
      <Sources>
        <SourcesTrigger count={1} />
        <SourcesContent>Content</SourcesContent>
      </Sources>
    );
    expect(screen.getByText('Used 1 source')).toBeInTheDocument();
  });

  it('displays source count plural', () => {
    render(
      <Sources>
        <SourcesTrigger count={5} />
        <SourcesContent>Content</SourcesContent>
      </Sources>
    );
    expect(screen.getByText('Used 5 sources')).toBeInTheDocument();
  });

  it('shows book icon', () => {
    const { container } = render(
      <Sources>
        <SourcesTrigger count={3} />
        <SourcesContent>Content</SourcesContent>
      </Sources>
    );
    // Lucide icons render as SVG
    expect(container.querySelector('svg')).toBeInTheDocument();
  });
});

describe('SourcesContent', () => {
  it('renders children', () => {
    render(
      <Sources defaultOpen>
        <SourcesTrigger count={1} />
        <SourcesContent>
          <div data-testid="content">Test Content</div>
        </SourcesContent>
      </Sources>
    );

    expect(screen.getByTestId('content')).toBeInTheDocument();
  });
});

describe('Source', () => {
  it('renders as a link', () => {
    render(<Source href="https://example.com" title="Example Site" />);
    const link = screen.getByRole('link');
    expect(link).toHaveAttribute('href', 'https://example.com');
  });

  it('opens in new tab', () => {
    render(<Source href="https://example.com" title="Example Site" />);
    const link = screen.getByRole('link');
    expect(link).toHaveAttribute('target', '_blank');
    expect(link).toHaveAttribute('rel', 'noopener noreferrer');
  });

  it('displays title', () => {
    render(<Source href="https://example.com" title="Example Site" />);
    expect(screen.getByText('Example Site')).toBeInTheDocument();
  });

  it('displays description when provided', () => {
    render(
      <Source
        href="https://example.com"
        title="Example Site"
        description="This is a description of the source"
      />
    );
    expect(screen.getByText('This is a description of the source')).toBeInTheDocument();
  });

  it('extracts and displays hostname', () => {
    render(<Source href="https://docs.example.com/path/to/page" title="Example" />);
    expect(screen.getByText('docs.example.com')).toBeInTheDocument();
  });

  it('falls back to href when no title', () => {
    render(<Source href="https://example.com" />);
    expect(screen.getByText('https://example.com')).toBeInTheDocument();
  });
});

describe('SourcesList', () => {
  const mockSources = [
    { url: 'https://example.com', title: 'Example Site' },
    { url: 'https://docs.test.com', title: 'Test Docs', description: 'Documentation' },
    { url: 'https://api.service.com', title: 'API Reference' },
  ];

  it('renders nothing when sources is empty', () => {
    const { container } = render(<SourcesList sources={[]} />);
    expect(container.firstChild).toBeNull();
  });

  it('renders nothing when sources is undefined', () => {
    const { container } = render(<SourcesList sources={undefined as unknown as []} />);
    expect(container.firstChild).toBeNull();
  });

  it('displays correct source count', () => {
    render(<SourcesList sources={mockSources} />);
    expect(screen.getByText('Used 3 sources')).toBeInTheDocument();
  });

  it('is collapsed by default', async () => {
    render(<SourcesList sources={mockSources} />);
    // Sources should not be visible initially
    expect(screen.queryByText('Example Site')).not.toBeInTheDocument();
  });

  it('can be opened by default', () => {
    render(<SourcesList sources={mockSources} defaultOpen />);
    expect(screen.getByText('Example Site')).toBeInTheDocument();
    expect(screen.getByText('Test Docs')).toBeInTheDocument();
  });

  it('expands when trigger is clicked', async () => {
    const user = userEvent.setup();
    render(<SourcesList sources={mockSources} />);

    // Click to expand
    await user.click(screen.getByText('Used 3 sources'));

    // Sources should now be visible
    expect(screen.getByText('Example Site')).toBeInTheDocument();
    expect(screen.getByText('Test Docs')).toBeInTheDocument();
    expect(screen.getByText('API Reference')).toBeInTheDocument();
  });

  it('displays source descriptions', async () => {
    const user = userEvent.setup();
    render(<SourcesList sources={mockSources} />);

    await user.click(screen.getByText('Used 3 sources'));

    expect(screen.getByText('Documentation')).toBeInTheDocument();
  });

  it('renders all sources as links', async () => {
    const user = userEvent.setup();
    render(<SourcesList sources={mockSources} />);

    await user.click(screen.getByText('Used 3 sources'));

    const links = screen.getAllByRole('link');
    expect(links).toHaveLength(3);
    expect(links[0]).toHaveAttribute('href', 'https://example.com');
    expect(links[1]).toHaveAttribute('href', 'https://docs.test.com');
    expect(links[2]).toHaveAttribute('href', 'https://api.service.com');
  });
});

describe('Sources integration', () => {
  it('works with custom trigger content', () => {
    render(
      <Sources>
        <SourcesTrigger count={2}>
          <span data-testid="custom-trigger">Custom Trigger</span>
        </SourcesTrigger>
        <SourcesContent>Content</SourcesContent>
      </Sources>
    );

    expect(screen.getByTestId('custom-trigger')).toBeInTheDocument();
  });

  it('works with custom source content', () => {
    render(
      <Sources defaultOpen>
        <SourcesTrigger count={1} />
        <SourcesContent>
          <Source href="https://example.com">
            <span data-testid="custom-source">Custom Source Content</span>
          </Source>
        </SourcesContent>
      </Sources>
    );

    expect(screen.getByTestId('custom-source')).toBeInTheDocument();
  });
});
