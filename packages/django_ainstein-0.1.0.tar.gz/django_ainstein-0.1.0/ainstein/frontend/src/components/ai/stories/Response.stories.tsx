import type { Meta, StoryObj } from '@storybook/react';
import { Response } from '../index';

const meta: Meta<typeof Response> = {
  title: 'AI/Response',
  component: Response,
  parameters: {
    layout: 'padded',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof Response>;

export const Default: Story = {
  render: () => (
    <div className="w-[600px]">
      <Response>
{`Here's a simple example of how to create a React component:

\`\`\`tsx
const HelloWorld = ({ name }: { name: string }) => {
  return <div>Hello, {name}!</div>;
};
\`\`\`

You can use this component like this: \`<HelloWorld name="World" />\``}
      </Response>
    </div>
  ),
};

export const WithHeadings: Story = {
  render: () => (
    <div className="w-[600px]">
      <Response>
{`# Main Title

This is an introduction paragraph.

## Section One

Some content for section one.

### Subsection

More detailed content here.

## Section Two

Another section with different content.`}
      </Response>
    </div>
  ),
};

export const WithLists: Story = {
  render: () => (
    <div className="w-[600px]">
      <Response>
{`Here are the steps to get started:

1. Install the dependencies
2. Configure your environment
3. Run the development server
4. Start building!

Key features include:

- Fast hot reloading
- TypeScript support
- Built-in routing
- API routes`}
      </Response>
    </div>
  ),
};

export const WithTable: Story = {
  render: () => (
    <div className="w-[600px]">
      <Response>
{`Here's a comparison of different frameworks:

| Framework | Language | Stars | License |
|-----------|----------|-------|---------|
| React | JavaScript | 200k+ | MIT |
| Vue | JavaScript | 200k+ | MIT |
| Angular | TypeScript | 85k+ | MIT |
| Svelte | JavaScript | 70k+ | MIT |

Each framework has its own strengths and use cases.`}
      </Response>
    </div>
  ),
};

export const WithBlockquote: Story = {
  render: () => (
    <div className="w-[600px]">
      <Response>
{`Here's an important quote to remember:

> The best way to predict the future is to invent it.
>
> — Alan Kay

This mindset is essential for innovation in software development.`}
      </Response>
    </div>
  ),
};

export const WithInlineCode: Story = {
  render: () => (
    <div className="w-[600px]">
      <Response>
{`To install the package, run \`npm install react-query\` in your terminal.

The \`useQuery\` hook accepts a \`queryKey\` and a \`queryFn\`. The \`queryKey\` should be a unique identifier for the data, while \`queryFn\` is the function that fetches the data.

You can also use \`useMutation\` for data modifications.`}
      </Response>
    </div>
  ),
};

export const WithLinks: Story = {
  render: () => (
    <div className="w-[600px]">
      <Response>
{`For more information, check out these resources:

- [React Documentation](https://react.dev)
- [TypeScript Handbook](https://www.typescriptlang.org/docs/)
- [MDN Web Docs](https://developer.mozilla.org)

You can also find the source code on [GitHub](https://github.com).`}
      </Response>
    </div>
  ),
};

export const MultipleCodeBlocks: Story = {
  render: () => (
    <div className="w-[600px]">
      <Response>
{`Here's how to implement a simple API endpoint:

First, create the route handler:

\`\`\`typescript
import { NextResponse } from 'next/server';

export async function GET(request: Request) {
  const data = await fetchData();
  return NextResponse.json(data);
}
\`\`\`

Then, call it from your component:

\`\`\`tsx
const MyComponent = () => {
  const { data, isLoading } = useQuery({
    queryKey: ['data'],
    queryFn: () => fetch('/api/data').then(res => res.json())
  });

  if (isLoading) return <div>Loading...</div>;

  return <div>{JSON.stringify(data)}</div>;
};
\`\`\`

That's all you need to get started!`}
      </Response>
    </div>
  ),
};

export const ComplexMarkdown: Story = {
  render: () => (
    <div className="w-[600px]">
      <Response>
{`# Getting Started with Our API

Welcome to our API documentation. This guide will help you get started quickly.

## Authentication

All API requests require authentication. Include your API key in the header:

\`\`\`bash
curl -H "Authorization: Bearer YOUR_API_KEY" https://api.example.com/v1/users
\`\`\`

## Endpoints

### GET /users

Returns a list of users.

| Parameter | Type | Description |
|-----------|------|-------------|
| limit | number | Max results (default: 10) |
| offset | number | Pagination offset |

### POST /users

Creates a new user.

\`\`\`json
{
  "name": "John Doe",
  "email": "john@example.com"
}
\`\`\`

## Error Handling

> **Note:** All errors return a consistent format with \`code\` and \`message\` fields.

Example error response:

\`\`\`json
{
  "code": "INVALID_REQUEST",
  "message": "The email field is required"
}
\`\`\`

---

For more help, visit our [support page](https://example.com/support).`}
      </Response>
    </div>
  ),
};

export const WithMath: Story = {
  render: () => (
    <div className="w-[600px]">
      <Response>
{`The quadratic formula is used to find the roots of a quadratic equation:

$$x = \\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}$$

For example, to solve $x^2 + 5x + 6 = 0$:

- $a = 1$, $b = 5$, $c = 6$
- Discriminant: $b^2 - 4ac = 25 - 24 = 1$
- Solutions: $x = -2$ or $x = -3$`}
      </Response>
    </div>
  ),
};
