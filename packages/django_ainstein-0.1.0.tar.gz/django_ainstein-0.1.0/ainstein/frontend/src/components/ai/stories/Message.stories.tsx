import type { Meta, StoryObj } from '@storybook/react';
import {
  Message,
  MessageContent,
  Response,
  Reasoning,
  ReasoningTrigger,
  ReasoningContent,
  ToolCard,
} from '../index';

const meta: Meta<typeof Message> = {
  title: 'AI/Message',
  component: Message,
  parameters: {
    layout: 'padded',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof Message>;

export const UserMessage: Story = {
  render: () => (
    <Message from="user">
      <MessageContent className="rounded-lg rounded-tr-sm">
        <div className="whitespace-pre-wrap">
          Can you help me write a SQL query to find all users who signed up in the last 30 days?
        </div>
      </MessageContent>
    </Message>
  ),
};

export const AssistantMessage: Story = {
  render: () => (
    <Message from="assistant">
      <MessageContent className="rounded-lg rounded-bl-sm">
        <Response>
{`Sure! Here's a SQL query to find users who signed up in the last 30 days:

\`\`\`sql
SELECT * FROM users WHERE created_at >= NOW() - INTERVAL '30 days';
\`\`\`

This query uses PostgreSQL's interval syntax. Let me know if you need it adapted for a different database!`}
        </Response>
      </MessageContent>
    </Message>
  ),
};

export const AssistantWithTool: Story = {
  render: () => (
    <div className="space-y-2">
      <Message from="assistant">
        <MessageContent className="rounded-lg rounded-bl-sm">
          <Response>Let me query the database to find recent users:</Response>
        </MessageContent>
      </Message>

      <ToolCard
        event={{
          tool: "Query",
          sql: "SELECT id, name, email, created_at FROM users WHERE created_at >= NOW() - INTERVAL '30 days' ORDER BY created_at DESC LIMIT 10",
          data_preview: [
            { id: 1234, name: 'John Doe', email: 'john@example.com', created_at: '2024-11-25' },
            { id: 1235, name: 'Jane Smith', email: 'jane@example.com', created_at: '2024-11-24' },
            { id: 1236, name: 'Bob Wilson', email: 'bob@example.com', created_at: '2024-11-23' },
          ],
          result: "3 rows returned",
        }}
      />

      <Message from="assistant">
        <MessageContent className="rounded-lg rounded-bl-sm">
          <Response>Found **3 users** who signed up in the last 30 days.</Response>
        </MessageContent>
      </Message>
    </div>
  ),
};

export const WithReasoning: Story = {
  render: () => (
    <Message from="assistant">
      <Reasoning defaultOpen>
        <ReasoningTrigger>View reasoning</ReasoningTrigger>
        <ReasoningContent>
{`The user wants to find recent signups. I should:

1. Use a date comparison with created_at field
2. Consider timezone handling
3. Add ORDER BY for chronological results
4. Limit results to avoid overwhelming output`}
        </ReasoningContent>
      </Reasoning>
      <MessageContent className="rounded-lg rounded-bl-sm">
        <Response>Here's an optimized query for finding recent signups with proper indexing hints.</Response>
      </MessageContent>
    </Message>
  ),
};

export const Conversation: Story = {
  render: () => (
    <div className="space-y-4">
      <Message from="user">
        <MessageContent className="rounded-lg rounded-tr-sm">
          <div>What tables do we have in the jobs app?</div>
        </MessageContent>
      </Message>

      <ToolCard
        event={{
          tool: "django_list_models",
          input: { app_label: "jobs" },
          result: "Company, Contact, CompanyOpportunity, CompanyInteraction, FileResource",
        }}
      />

      <Message from="assistant">
        <MessageContent className="rounded-lg rounded-bl-sm">
          <Response>
{`The jobs app has 5 models:

- **Company** - Stores company information
- **Contact** - People at companies
- **CompanyOpportunity** - Job opportunities
- **CompanyInteraction** - Communication logs
- **FileResource** - Attached files`}
          </Response>
        </MessageContent>
      </Message>

      <Message from="user">
        <MessageContent className="rounded-lg rounded-tr-sm">
          <div>Show me the last 5 companies added</div>
        </MessageContent>
      </Message>

      <ToolCard
        event={{
          tool: "Query",
          sql: "SELECT id, name, website, created FROM jobs_company ORDER BY created DESC LIMIT 5",
          data_preview: [
            { id: 42, name: 'Acme Corp', website: 'acme.com', created: '2024-11-27' },
            { id: 41, name: 'TechStart Inc', website: 'techstart.io', created: '2024-11-26' },
            { id: 40, name: 'DataFlow LLC', website: 'dataflow.com', created: '2024-11-25' },
          ],
          result: "3 rows returned",
        }}
      />
    </div>
  ),
};

export const MarkdownFeatures: Story = {
  render: () => (
    <Message from="assistant">
      <MessageContent className="rounded-lg rounded-bl-sm">
        <Response>
{`# Markdown Features Demo

## Text Formatting

This is **bold text** and this is *italic text*. You can also use ~~strikethrough~~.

## Lists

### Ordered List
1. First item
2. Second item
3. Third item

### Unordered List
- Item A
- Item B
- Item C

## Code

Inline \`code\` looks like this.

\`\`\`python
def hello_world():
    print("Hello, World!")
\`\`\`

## Tables

| Name | Role | Status |
|------|------|--------|
| Alice | Engineer | Active |
| Bob | Designer | Active |
| Carol | Manager | Away |

## Blockquote

> This is a blockquote. It can span multiple lines and contain **formatted** text.

## Links

Check out [Anthropic](https://anthropic.com) for more info.`}
        </Response>
      </MessageContent>
    </Message>
  ),
};

export const StreamingMessage: Story = {
  render: () => (
    <Message from="assistant">
      <MessageContent className="rounded-lg rounded-bl-sm">
        <Response parseIncompleteMarkdown={true}>
{`I'm currently analyzing your request. Here's what I've found so far:

1. The database contains **`}
        </Response>
        <span className="animate-pulse opacity-70">▌</span>
      </MessageContent>
    </Message>
  ),
};
