/**
 * Plan component for displaying AI-generated execution plans
 * Based on ai-sdk.dev/elements/components/plan
 */

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
  CardAction,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { cn } from "@/lib/utils";
import { ChevronDownIcon } from "lucide-react";
import type { ComponentProps } from "react";
import { createContext, useContext } from "react";

type PlanContextType = {
  isStreaming: boolean;
};

const PlanContext = createContext<PlanContextType>({
  isStreaming: false,
});

const usePlan = () => useContext(PlanContext);

export type PlanProps = ComponentProps<typeof Collapsible> & {
  isStreaming?: boolean;
};

export const Plan = ({
  className,
  isStreaming = false,
  defaultOpen = true,
  children,
  ...props
}: PlanProps) => (
  <PlanContext.Provider value={{ isStreaming }}>
    <Collapsible defaultOpen={defaultOpen} {...props}>
      <Card className={cn("w-full", className)}>{children}</Card>
    </Collapsible>
  </PlanContext.Provider>
);

export type PlanHeaderProps = ComponentProps<typeof CardHeader>;

export const PlanHeader = ({
  className,
  children,
  ...props
}: PlanHeaderProps) => (
  <CardHeader
    className={cn("flex flex-row items-center justify-between space-y-0", className)}
    {...props}
  >
    {children}
  </CardHeader>
);

export type PlanTitleProps = Omit<ComponentProps<typeof CardTitle>, "children"> & {
  children?: string;
};

export const PlanTitle = ({
  className,
  children,
  ...props
}: PlanTitleProps) => {
  const { isStreaming } = usePlan();

  return (
    <CardTitle className={cn("text-base", className)} {...props}>
      {isStreaming && !children ? (
        <span className="inline-block h-5 w-32 animate-pulse rounded bg-muted" />
      ) : (
        children
      )}
    </CardTitle>
  );
};

export type PlanDescriptionProps = Omit<ComponentProps<typeof CardDescription>, "children"> & {
  children?: string;
};

export const PlanDescription = ({
  className,
  children,
  ...props
}: PlanDescriptionProps) => {
  const { isStreaming } = usePlan();

  return (
    <CardDescription className={cn("", className)} {...props}>
      {isStreaming && !children ? (
        <span className="inline-block h-4 w-48 animate-pulse rounded bg-muted" />
      ) : (
        children
      )}
    </CardDescription>
  );
};

export type PlanTriggerProps = ComponentProps<typeof CollapsibleTrigger>;

export const PlanTrigger = ({
  className,
  children,
  ...props
}: PlanTriggerProps) => (
  <CollapsibleTrigger asChild {...props}>
    {children ?? (
      <Button variant="ghost" size="sm" className={cn("", className)}>
        <ChevronDownIcon className="size-4 transition-transform group-data-[state=open]:rotate-180" />
      </Button>
    )}
  </CollapsibleTrigger>
);

export type PlanContentProps = ComponentProps<typeof CardContent>;

export const PlanContent = ({
  className,
  children,
  ...props
}: PlanContentProps) => (
  <CollapsibleContent>
    <CardContent className={cn("", className)} {...props}>
      {children}
    </CardContent>
  </CollapsibleContent>
);

export type PlanFooterProps = ComponentProps<typeof CardFooter>;

export const PlanFooter = ({
  className,
  children,
  ...props
}: PlanFooterProps) => (
  <CardFooter className={cn("", className)} {...props}>
    {children}
  </CardFooter>
);

export type PlanActionProps = ComponentProps<typeof CardAction>;

export const PlanAction = ({
  className,
  children,
  ...props
}: PlanActionProps) => (
  <CardAction className={cn("", className)} {...props}>
    {children}
  </CardAction>
);
