import type { Meta, StoryObj } from '@storybook/react';
import { CodeBlock, CodeBlockCopyButton } from '../index';

const meta: Meta<typeof CodeBlock> = {
  title: 'AI/CodeBlock',
  component: CodeBlock,
  parameters: {
    layout: 'padded',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof CodeBlock>;

export const SQL: Story = {
  args: {
    language: 'sql',
    code: `SELECT
  u.id,
  u.name,
  COUNT(o.id) as order_count,
  SUM(o.total) as total_spent
FROM users u
LEFT JOIN orders o ON u.id = o.user_id
WHERE u.created_at >= '2024-01-01'
GROUP BY u.id, u.name
ORDER BY total_spent DESC
LIMIT 10;`,
  },
};

export const JSON: Story = {
  args: {
    language: 'json',
    code: `{
  "query": "SELECT COUNT(*) FROM users",
  "params": ["2024-01-01"],
  "database": "analytics",
  "options": {
    "timeout": 30000,
    "cache": true
  }
}`,
  },
};

export const TypeScript: Story = {
  args: {
    language: 'typescript',
    code: `interface User {
  id: number;
  name: string;
  email: string;
  createdAt: Date;
}

async function fetchUsers(): Promise<User[]> {
  const response = await fetch('/api/users');
  return response.json();
}`,
  },
};

export const Python: Story = {
  args: {
    language: 'python',
    code: `from django.db import models

class Company(models.Model):
    name = models.CharField(max_length=255)
    website = models.URLField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name`,
  },
};

export const Bash: Story = {
  args: {
    language: 'bash',
    code: `#!/bin/bash
cd /app
npm install
npm run build
echo "Build completed successfully"`,
  },
};

export const WithCopyButton: Story = {
  render: () => (
    <CodeBlock
      language="sql"
      code={`SELECT * FROM users WHERE active = true;`}
    >
      <CodeBlockCopyButton />
    </CodeBlock>
  ),
};

export const WithLineNumbers: Story = {
  args: {
    language: 'typescript',
    showLineNumbers: true,
    code: `import { useState, useEffect } from 'react';

function useDebounce<T>(value: T, delay: number): T {
  const [debouncedValue, setDebouncedValue] = useState<T>(value);

  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);

    return () => clearTimeout(timer);
  }, [value, delay]);

  return debouncedValue;
}`,
  },
};

export const PlainText: Story = {
  args: {
    language: 'text',
    code: `This is plain text without any syntax highlighting.
It can be useful for showing raw output or logs.
Line 3 of the output.`,
  },
};
