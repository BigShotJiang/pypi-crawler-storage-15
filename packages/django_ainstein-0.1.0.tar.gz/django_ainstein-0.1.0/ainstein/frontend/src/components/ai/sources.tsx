/**
 * Sources component for displaying web search results
 * Based on ai-sdk.dev/elements/components/sources
 */

"use client";

import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { cn } from "@/lib/utils";
import { BookOpenIcon, ChevronDownIcon, ExternalLinkIcon } from "lucide-react";
import type { ComponentProps } from "react";

export type SourcesProps = ComponentProps<typeof Collapsible>;

export const Sources = ({ className, ...props }: SourcesProps) => (
  <Collapsible
    className={cn("not-prose mb-4 text-primary text-sm", className)}
    {...props}
  />
);

export type SourcesTriggerProps = ComponentProps<typeof CollapsibleTrigger> & {
  count: number;
};

export const SourcesTrigger = ({
  className,
  count,
  children,
  ...props
}: SourcesTriggerProps) => (
  <CollapsibleTrigger
    className={cn("group flex items-center gap-2 hover:underline", className)}
    {...props}
  >
    {children ?? (
      <>
        <BookOpenIcon className="size-4" />
        <span className="font-medium">Used {count} source{count !== 1 ? "s" : ""}</span>
        <ChevronDownIcon className="size-4 transition-transform group-data-[state=open]:rotate-180" />
      </>
    )}
  </CollapsibleTrigger>
);

export type SourcesContentProps = ComponentProps<typeof CollapsibleContent>;

export const SourcesContent = ({
  className,
  ...props
}: SourcesContentProps) => (
  <CollapsibleContent
    className={cn(
      "mt-3 flex w-fit flex-col gap-2",
      "data-[state=closed]:fade-out-0 data-[state=closed]:slide-out-to-top-2 data-[state=open]:slide-in-from-top-2 outline-none data-[state=closed]:animate-out data-[state=open]:animate-in",
      className
    )}
    {...props}
  />
);

export type SourceProps = ComponentProps<"a"> & {
  title?: string;
  description?: string;
};

export const Source = ({
  href,
  title,
  description,
  children,
  className,
  ...props
}: SourceProps) => (
  <a
    className={cn(
      "group/source flex items-start gap-2 rounded-md p-2 hover:bg-muted/50 transition-colors",
      className
    )}
    href={href}
    rel="noopener noreferrer"
    target="_blank"
    {...props}
  >
    {children ?? (
      <>
        <ExternalLinkIcon className="size-4 mt-0.5 shrink-0 text-muted-foreground group-hover/source:text-foreground" />
        <div className="flex flex-col gap-0.5 min-w-0">
          <span className="font-medium text-sm truncate group-hover/source:underline">
            {title || href}
          </span>
          {description && (
            <span className="text-xs text-muted-foreground line-clamp-2">
              {description}
            </span>
          )}
          {href && (
            <span className="text-xs text-muted-foreground truncate">
              {new URL(href).hostname}
            </span>
          )}
        </div>
      </>
    )}
  </a>
);

// Convenience component for a complete sources list
export type SourcesListProps = ComponentProps<"div"> & {
  sources: Array<{
    url: string;
    title?: string;
    description?: string;
  }>;
  defaultOpen?: boolean;
};

export const SourcesList = ({
  sources,
  defaultOpen = false,
  className,
  ...props
}: SourcesListProps) => {
  if (!sources || sources.length === 0) return null;

  return (
    <div className={className} {...props}>
      <Sources defaultOpen={defaultOpen}>
        <SourcesTrigger count={sources.length} />
        <SourcesContent>
          {sources.map((source, i) => (
            <Source
              key={i}
              href={source.url}
              title={source.title}
              description={source.description}
            />
          ))}
        </SourcesContent>
      </Sources>
    </div>
  );
};
