import type { Meta, StoryObj } from '@storybook/react';
import {
  PromptInput,
  PromptInputHeader,
  PromptInputBody,
  PromptInputTextarea,
  PromptInputFooter,
  PromptInputTools,
  PromptInputSubmit,
  PromptInputAttachButton,
  PromptInputSpeechButton,
  PromptInputAttachments,
} from '../index';

const meta: Meta<typeof PromptInput> = {
  title: 'AI/PromptInput',
  component: PromptInput,
  parameters: {
    layout: 'padded',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof PromptInput>;

export const Default: Story = {
  render: () => (
    <PromptInput
      className="w-[500px]"
      onSubmit={(message) => console.log('Submitted:', message)}
    >
      <PromptInputBody>
        <PromptInputTextarea placeholder="Type your message..." />
      </PromptInputBody>
      <PromptInputFooter>
        <PromptInputTools>
          <PromptInputAttachButton />
        </PromptInputTools>
        <PromptInputSubmit />
      </PromptInputFooter>
    </PromptInput>
  ),
};

export const WithAllTools: Story = {
  render: () => (
    <PromptInput
      className="w-[500px]"
      onSubmit={(message) => console.log('Submitted:', message)}
    >
      <PromptInputHeader>
        <PromptInputAttachments />
      </PromptInputHeader>
      <PromptInputBody>
        <PromptInputTextarea placeholder="Ask me anything..." />
      </PromptInputBody>
      <PromptInputFooter>
        <PromptInputTools>
          <PromptInputAttachButton accept="image/*,.pdf,.doc,.docx" />
          <PromptInputSpeechButton />
        </PromptInputTools>
        <PromptInputSubmit />
      </PromptInputFooter>
    </PromptInput>
  ),
};

export const Streaming: Story = {
  render: () => (
    <PromptInput className="w-[500px]">
      <PromptInputBody>
        <PromptInputTextarea placeholder="Type your message..." />
      </PromptInputBody>
      <PromptInputFooter>
        <PromptInputTools>
          <PromptInputAttachButton />
        </PromptInputTools>
        <PromptInputSubmit status="streaming" />
      </PromptInputFooter>
    </PromptInput>
  ),
};

export const Minimal: Story = {
  render: () => (
    <PromptInput
      className="w-[500px]"
      onSubmit={(message) => console.log('Submitted:', message)}
    >
      <PromptInputBody>
        <PromptInputTextarea placeholder="Message..." />
      </PromptInputBody>
      <PromptInputFooter className="justify-end">
        <PromptInputSubmit />
      </PromptInputFooter>
    </PromptInput>
  ),
};

export const FullWidth: Story = {
  render: () => (
    <PromptInput
      className="w-full"
      onSubmit={(message) => console.log('Submitted:', message)}
    >
      <PromptInputHeader>
        <PromptInputAttachments />
      </PromptInputHeader>
      <PromptInputBody>
        <PromptInputTextarea
          placeholder="Describe what you'd like to build..."
          minHeight={80}
          maxHeight={300}
        />
      </PromptInputBody>
      <PromptInputFooter>
        <PromptInputTools>
          <PromptInputAttachButton />
          <PromptInputSpeechButton />
        </PromptInputTools>
        <PromptInputSubmit />
      </PromptInputFooter>
    </PromptInput>
  ),
};

export const CodeAssistant: Story = {
  render: () => (
    <PromptInput
      className="w-[600px]"
      onSubmit={(message) => console.log('Submitted:', message)}
    >
      <PromptInputBody>
        <PromptInputTextarea
          placeholder="Describe the code you want to generate..."
          className="font-mono"
        />
      </PromptInputBody>
      <PromptInputFooter>
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <span>Press Enter to send</span>
          <span>•</span>
          <span>Shift+Enter for new line</span>
        </div>
        <PromptInputSubmit />
      </PromptInputFooter>
    </PromptInput>
  ),
};
