import type { Meta, StoryObj } from '@storybook/react';
import {
  Confirmation,
  ConfirmationContent,
  ConfirmationRequest,
  ConfirmationAccepted,
  ConfirmationRejected,
  ConfirmationActions,
  ConfirmationAction,
} from '../index';

const meta: Meta<typeof Confirmation> = {
  title: 'AI/Confirmation',
  component: Confirmation,
  parameters: {
    layout: 'padded',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof Confirmation>;

export const ApprovalRequested: Story = {
  render: () => (
    <Confirmation
      state="approval-requested"
      approval={{
        toolName: "execute_code",
        message: "This will run Python code in your environment",
      }}
    >
      <ConfirmationContent>
        <ConfirmationRequest />
        <ConfirmationActions>
          <ConfirmationAction variant="default">Allow</ConfirmationAction>
          <ConfirmationAction variant="outline">Deny</ConfirmationAction>
        </ConfirmationActions>
      </ConfirmationContent>
    </Confirmation>
  ),
};

export const Approved: Story = {
  render: () => (
    <Confirmation
      state="approval-responded"
      approval={{
        toolName: "execute_code",
      }}
    >
      <ConfirmationContent>
        <ConfirmationAccepted>Tool execution approved</ConfirmationAccepted>
      </ConfirmationContent>
    </Confirmation>
  ),
};

export const Rejected: Story = {
  render: () => (
    <Confirmation
      state="output-denied"
      approval={{
        toolName: "delete_files",
      }}
    >
      <ConfirmationContent>
        <ConfirmationRejected>Tool execution denied by user</ConfirmationRejected>
      </ConfirmationContent>
    </Confirmation>
  ),
};

export const DatabaseWrite: Story = {
  render: () => (
    <Confirmation
      state="approval-requested"
      approval={{
        toolName: "database_write",
        message: "This will modify 15 records in the users table",
      }}
    >
      <ConfirmationContent>
        <ConfirmationRequest />
        <ConfirmationActions>
          <ConfirmationAction variant="default">Allow Write</ConfirmationAction>
          <ConfirmationAction variant="outline">Cancel</ConfirmationAction>
        </ConfirmationActions>
      </ConfirmationContent>
    </Confirmation>
  ),
};

export const FileSystemAccess: Story = {
  render: () => (
    <Confirmation
      state="approval-requested"
      approval={{
        toolName: "read_file",
        message: "Access to /home/user/documents/config.json",
      }}
    >
      <ConfirmationContent>
        <ConfirmationRequest>
          <p className="font-medium">Allow file system access?</p>
          <p className="text-sm text-muted-foreground mt-1">
            The assistant wants to read a configuration file.
          </p>
        </ConfirmationRequest>
        <ConfirmationActions>
          <ConfirmationAction variant="default">Allow Once</ConfirmationAction>
          <ConfirmationAction variant="secondary">Always Allow</ConfirmationAction>
          <ConfirmationAction variant="outline">Deny</ConfirmationAction>
        </ConfirmationActions>
      </ConfirmationContent>
    </Confirmation>
  ),
};

export const MultipleStates: Story = {
  render: () => (
    <div className="space-y-4">
      <Confirmation state="approval-requested" approval={{ toolName: "shell_command" }}>
        <ConfirmationContent>
          <ConfirmationRequest />
          <ConfirmationActions>
            <ConfirmationAction variant="default">Allow</ConfirmationAction>
            <ConfirmationAction variant="outline">Deny</ConfirmationAction>
          </ConfirmationActions>
        </ConfirmationContent>
      </Confirmation>

      <Confirmation state="approval-responded" approval={{ toolName: "read_file" }}>
        <ConfirmationContent>
          <ConfirmationAccepted />
        </ConfirmationContent>
      </Confirmation>

      <Confirmation state="output-denied" approval={{ toolName: "delete_database" }}>
        <ConfirmationContent>
          <ConfirmationRejected />
        </ConfirmationContent>
      </Confirmation>
    </div>
  ),
};
