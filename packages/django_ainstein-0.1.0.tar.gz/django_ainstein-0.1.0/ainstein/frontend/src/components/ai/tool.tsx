/**
 * Tool component for displaying tool invocation details
 * Based on ai-sdk.dev/elements/components/tool
 */

import { Badge } from "@/components/ui/badge";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { DataTable } from "@/components/ui/data-table";
import { ImageWithFullscreen } from "@/components/ui/image-fullscreen";
import { cn } from "@/lib/utils";
import {
  BanIcon,
  CheckCircle2Icon,
  ChevronDownIcon,
  CircleIcon,
  ClockIcon,
  Loader2Icon,
  WrenchIcon,
  XCircleIcon,
} from "lucide-react";
import type { ComponentProps, ReactNode } from "react";
import { CodeBlock } from "./code-block";

// Tool state types matching AI SDK's ToolUIPart
export type ToolState =
  | "pending"
  | "running"
  | "completed"
  | "error"
  | "denied"
  // AI SDK v6 approval states
  | "approval-requested"
  | "approval-responded"
  // Legacy states for backwards compatibility
  | "input-streaming"
  | "input-available"
  | "output-available"
  | "output-error"
  | "output-denied";

// Tool type (function call vs result)
export type ToolType = "tool-invocation" | "tool-result";

export type ToolProps = ComponentProps<typeof Collapsible>;

export const Tool = ({ className, defaultOpen, ...props }: ToolProps) => (
  <Collapsible
    className={cn("not-prose mb-4 w-full rounded-md border", className)}
    defaultOpen={defaultOpen}
    data-testid="tool"
    {...props}
  />
);

export type ToolHeaderProps = ComponentProps<typeof CollapsibleTrigger> & {
  toolName?: string;
  type?: ToolType;
  state?: ToolState;
};

// Normalize legacy states to new states
const normalizeState = (state: ToolState): ToolState => {
  const legacyMapping: Record<string, ToolState> = {
    "input-streaming": "pending",
    "input-available": "running",
    "output-available": "completed",
    "output-error": "error",
    "output-denied": "denied",
  };
  return legacyMapping[state] || state;
};

const getStatusConfig = (state: ToolState) => {
  const normalizedState = normalizeState(state);

  const config = {
    pending: {
      label: "Pending",
      icon: <CircleIcon className="size-3" />,
      variant: "secondary" as const,
    },
    running: {
      label: "Running",
      icon: <Loader2Icon className="size-3 animate-spin" />,
      variant: "secondary" as const,
    },
    completed: {
      label: "Completed",
      icon: <CheckCircle2Icon className="size-3 text-green-500" />,
      variant: "secondary" as const,
    },
    error: {
      label: "Error",
      icon: <XCircleIcon className="size-3 text-red-500" />,
      variant: "destructive" as const,
    },
    denied: {
      label: "Denied",
      icon: <BanIcon className="size-3 text-orange-500" />,
      variant: "secondary" as const,
    },
    // AI SDK v6 approval states
    "approval-requested": {
      label: "Awaiting Approval",
      icon: <ClockIcon className="size-3 text-yellow-500" />,
      variant: "secondary" as const,
    },
    "approval-responded": {
      label: "Responded",
      icon: <CheckCircle2Icon className="size-3 text-blue-500" />,
      variant: "secondary" as const,
    },
  };

  return config[normalizedState as keyof typeof config] || config.pending;
};

export const ToolHeader = ({
  className,
  toolName,
  type,
  state = "pending",
  ...props
}: ToolHeaderProps) => {
  const statusConfig = getStatusConfig(state);

  return (
    <CollapsibleTrigger
      className={cn(
        "group flex w-full items-center justify-between gap-4 p-3 hover:bg-muted/50",
        className
      )}
      data-testid="tool-trigger"
      {...props}
    >
      <div className="flex items-center gap-2">
        <WrenchIcon className="size-4 text-muted-foreground" />
        <span className="font-medium text-sm" data-testid="tool-name">{toolName || "Tool"}</span>
        <Badge className="rounded-full text-xs gap-1" variant={statusConfig.variant} data-testid="tool-status">
          {statusConfig.icon}
          {statusConfig.label}
        </Badge>
      </div>
      <ChevronDownIcon className="size-4 text-muted-foreground transition-transform group-data-[state=open]:rotate-180" />
    </CollapsibleTrigger>
  );
};

export type ToolContentProps = ComponentProps<typeof CollapsibleContent>;

export const ToolContent = ({ className, ...props }: ToolContentProps) => (
  <CollapsibleContent
    className={cn(
      "data-[state=closed]:fade-out-0 data-[state=closed]:slide-out-to-top-2 data-[state=open]:slide-in-from-top-2 text-popover-foreground outline-none data-[state=closed]:animate-out data-[state=open]:animate-in",
      className
    )}
    data-testid="tool-content"
    {...props}
  />
);

export type ToolInputProps = ComponentProps<"div"> & {
  input?: Record<string, unknown> | string;
  toolName?: string;
};

// Tool name to language mapping
const TOOL_LANGUAGE_MAP: Record<string, string> = {
  // SQL tools
  RawSQL: "sql",
  Query: "sql",
  django_raw_sql: "sql",
  raw_sql: "sql",
  // Shell tools
  Bash: "bash",
  bash: "bash",
  shell: "bash",
  // Python tools
  python: "python",
  Python: "python",
};

// Detect language from content when tool name isn't mapped
const detectLanguageFromContent = (content: string): string => {
  const trimmed = content.trim();

  // SQL detection - check for common SQL keywords at start
  if (/^(SELECT|INSERT|UPDATE|DELETE|CREATE|ALTER|DROP|WITH|EXPLAIN)\b/i.test(trimmed)) {
    return "sql";
  }

  // JSON detection - starts with { or [
  if (trimmed.startsWith("{") || trimmed.startsWith("[")) {
    return "json";
  }

  // Python detection
  if (/^(def |import |from |class |async def |@)/.test(trimmed)) {
    return "python";
  }

  // Bash detection - common shell patterns
  if (/^(cd |ls |grep |cat |echo |export |source |\.\/|#!)/.test(trimmed)) {
    return "bash";
  }

  // Default fallback
  return "json";
};

// Get the appropriate language for syntax highlighting
const getInputLanguage = (toolName: string | undefined, content: string): string => {
  // First, check tool name mapping
  if (toolName && TOOL_LANGUAGE_MAP[toolName]) {
    return TOOL_LANGUAGE_MAP[toolName];
  }

  // Fall back to content detection
  return detectLanguageFromContent(content);
};

// Simple SQL formatter - breaks single-line SQL into multiple lines
const formatSQL = (sql: string): string => {
  // If already multi-line, return as-is
  if (sql.includes('\n')) {
    return sql;
  }

  // SQL keywords that should start a new line
  const majorKeywords = [
    'SELECT', 'FROM', 'WHERE', 'AND', 'OR', 'ORDER BY', 'GROUP BY',
    'HAVING', 'LIMIT', 'OFFSET', 'JOIN', 'LEFT JOIN', 'RIGHT JOIN',
    'INNER JOIN', 'OUTER JOIN', 'FULL JOIN', 'CROSS JOIN', 'ON',
    'INSERT INTO', 'VALUES', 'UPDATE', 'SET', 'DELETE FROM',
    'CREATE TABLE', 'ALTER TABLE', 'DROP TABLE', 'CREATE INDEX',
    'UNION', 'UNION ALL', 'EXCEPT', 'INTERSECT', 'WITH', 'AS'
  ];

  let formatted = sql.trim();

  // Add newlines before major keywords (case-insensitive)
  majorKeywords.forEach(keyword => {
    // Match keyword with word boundaries, case-insensitive
    const regex = new RegExp(`\\s+(${keyword})\\b`, 'gi');
    formatted = formatted.replace(regex, `\n$1`);
  });

  // Clean up any double newlines
  formatted = formatted.replace(/\n\s*\n/g, '\n');

  return formatted.trim();
};

export const ToolInput = ({ className, input, toolName, ...props }: ToolInputProps) => {
  if (!input) return null;

  let code = typeof input === "string" ? input : JSON.stringify(input, null, 2);
  const language = getInputLanguage(toolName, code);

  // Auto-format SQL if it's a single line
  if (language === "sql") {
    code = formatSQL(code);
  }

  return (
    <div className={cn("space-y-2 overflow-hidden px-4 pt-4", className)} {...props}>
      <h4 className="font-medium text-muted-foreground text-xs uppercase tracking-wide">
        Parameters
      </h4>
      <CodeBlock code={code} language={language} />
    </div>
  );
};

// Stats from tool execution
export interface ToolStats {
  // Common
  time_ms?: number;
  size_bytes?: number;
  // Data tools
  rows?: number;
  total_rows?: number;
  cols?: number;
  fields?: number;
  // File tools
  lines?: number;
  additions?: number;
  removals?: number;
  files?: number;
  dirs?: number;
  // Page tools
  blocks?: number;
  deleted?: number;
  remaining?: number;
  // Visualization tools
  image_url?: string;
  filename?: string;
  chart_type?: string;
  size?: number;
}

export type ToolOutputProps = ComponentProps<"div"> & {
  output?: ReactNode;
  errorText?: string;
  stats?: ToolStats;
  diff?: string[];
};

// Format bytes to human readable
const formatBytes = (bytes: number): string => {
  if (bytes < 1024) return `${bytes}B`;
  if (bytes < 1024 * 1024) return `${Math.floor(bytes / 1024)}KB`;
  return `${Math.floor(bytes / (1024 * 1024))}MB`;
};

// Format number with commas
const formatNumber = (n: number): string => n.toLocaleString();

export const ToolOutput = ({
  className,
  output,
  errorText,
  stats,
  ...props
}: ToolOutputProps) => {
  // Check if we have an image to display
  const hasImage = stats?.image_url;

  if (!(output || errorText || hasImage)) {
    return null;
  }

  // Build stat badges from structured data
  const statBadges: string[] = [];
  if (stats) {
    // Time always first
    if (stats.time_ms !== undefined) statBadges.push(`${stats.time_ms}ms`);
    // Size (generic or size_bytes)
    if (stats.size_bytes !== undefined) statBadges.push(formatBytes(stats.size_bytes));
    else if (stats.size !== undefined) statBadges.push(formatBytes(stats.size));
    // Chart type (for visualizations)
    if (stats.chart_type !== undefined) statBadges.push(stats.chart_type);
    // Columns (for SQL)
    if (stats.cols !== undefined) statBadges.push(`${stats.cols} cols`);
    // Fields (for describe model)
    if (stats.fields !== undefined) statBadges.push(`${stats.fields} fields`);
    // Files and dirs (for list)
    if (stats.files !== undefined) statBadges.push(`${stats.files} files`);
    if (stats.dirs !== undefined) statBadges.push(`${stats.dirs} dirs`);
    // Blocks (for page tools)
    if (stats.blocks !== undefined) statBadges.push(`${stats.blocks} blocks`);
    // Additions/removals (for file edits)
    if (stats.additions !== undefined) statBadges.push(`+${stats.additions}`);
    if (stats.removals !== undefined) statBadges.push(`-${stats.removals}`);
    // Deleted/remaining (for page delete)
    if (stats.deleted !== undefined && stats.remaining !== undefined) {
      statBadges.push(`${stats.deleted} deleted, ${stats.remaining} remaining`);
    }
    // Lines (for file operations)
    if (stats.lines !== undefined) statBadges.push(`${formatNumber(stats.lines)} lines`);
    // Rows with total (for data queries)
    if (stats.rows !== undefined && stats.total_rows !== undefined) {
      statBadges.push(`${formatNumber(stats.rows)} of ${formatNumber(stats.total_rows)} rows`);
    } else if (stats.rows !== undefined) {
      statBadges.push(`${formatNumber(stats.rows)} rows`);
    }
  }

  return (
    <div className={cn("space-y-2 p-4 pt-4", className)} data-testid="tool-output" {...props}>
      <div className="flex items-center justify-between">
        <h4 className="font-medium text-muted-foreground text-xs uppercase tracking-wide">
          {errorText ? "Error" : "Result"}
        </h4>
        {statBadges.length > 0 && (
          <div className="flex items-center gap-1.5">
            {statBadges.map((stat, i) => (
              <Badge key={i} variant="secondary" className="text-[10px] font-normal px-1.5 py-0">
                {stat}
              </Badge>
            ))}
          </div>
        )}
      </div>
      {/* Image preview for visualization tools */}
      {hasImage && (
        <div className="rounded-md overflow-hidden bg-muted/30 p-2">
          <ImageWithFullscreen
            src={stats.image_url}
            alt={stats.filename || "Generated chart"}
            title={stats.filename}
            className="max-w-full h-auto rounded-md"
            loading="lazy"
          />
        </div>
      )}
      {/* Text output (skip if we showed an image and output is just "Chart created" etc) */}
      {(output || errorText) && !(hasImage && typeof output === "string" && output.includes("Chart")) && (
        <div
          className={cn(
            "overflow-x-auto rounded-md p-3 text-xs [&_table]:w-full",
            errorText
              ? "bg-destructive/[0.02] text-red-400"
              : "bg-muted/50 text-foreground"
          )}
        >
          {errorText && <div>{errorText}</div>}
          {output && <div>{output}</div>}
        </div>
      )}
    </div>
  );
};

// Denied message for when tool execution is rejected
export type ToolDeniedProps = ComponentProps<"div"> & {
  message?: string;
};

export const ToolDenied = ({
  className,
  message = "Tool execution was denied",
  ...props
}: ToolDeniedProps) => (
  <div className={cn("p-4 pt-0", className)} {...props}>
    <div className="flex items-center gap-2 rounded-md bg-yellow-500/10 p-3 text-sm text-yellow-600 dark:text-yellow-400">
      <BanIcon className="size-4" />
      {message}
    </div>
  </div>
);

// Diff display for file modifications
export type ToolDiffProps = ComponentProps<"div"> & {
  diff?: string[];
};

export const ToolDiff = ({ className, diff, ...props }: ToolDiffProps) => {
  if (!diff || diff.length === 0) return null;

  return (
    <div className={cn("space-y-2 px-4 pb-4", className)} data-testid="tool-diff" {...props}>
      <h4 className="font-medium text-muted-foreground text-xs uppercase tracking-wide">
        Changes
      </h4>
      <div className="overflow-x-auto rounded-md bg-muted/50 text-xs font-mono">
        {diff.map((line, i) => {
          // Skip the header lines (---, +++)
          if (line.startsWith("---") || line.startsWith("+++")) {
            return (
              <div key={i} className="px-3 py-0.5 text-muted-foreground">
                {line}
              </div>
            );
          }
          // Hunk header (@@)
          if (line.startsWith("@@")) {
            return (
              <div key={i} className="px-3 py-0.5 text-blue-400 bg-blue-500/10">
                {line}
              </div>
            );
          }
          // Addition
          if (line.startsWith("+")) {
            return (
              <div key={i} className="px-3 py-0.5 text-green-400 bg-green-500/10">
                {line}
              </div>
            );
          }
          // Removal
          if (line.startsWith("-")) {
            return (
              <div key={i} className="px-3 py-0.5 text-red-400 bg-red-500/10">
                {line}
              </div>
            );
          }
          // Context line
          return (
            <div key={i} className="px-3 py-0.5 text-foreground">
              {line}
            </div>
          );
        })}
      </div>
    </div>
  );
};

// ToolCard - Complete tool component that handles all rendering logic
export interface ToolEvent {
  type?: "tool";
  tool: string;
  args?: string;
  input?: Record<string, unknown>;
  sql?: string;
  data_preview?: Record<string, unknown>[];
  diff?: string[];
  result?: string;
  stats?: ToolStats;
  error?: string;
  denied?: boolean;
  awaitingApproval?: boolean;
}

export type ToolCardProps = ComponentProps<"div"> & {
  event: ToolEvent;
  defaultOpen?: boolean;
};

export const ToolCard = ({ event, defaultOpen = true, className, ...props }: ToolCardProps) => {
  // Determine state from event
  const state: ToolState = event.denied
    ? "denied"
    : event.awaitingApproval
      ? "approval-requested"
      : event.error
        ? "error"
        : event.result || event.data_preview || event.stats
          ? "completed"
          : "running";

  // Build output content
  let outputContent: ReactNode = null;
  const dataPreview = event.data_preview;
  const hasDataPreview = dataPreview && dataPreview.length > 0;

  if (hasDataPreview) {
    // Show max 5 rows in ToolCard, with scrollbar for more
    outputContent = <DataTable data={dataPreview} maxVisibleRows={5} />;
  } else if (event.result) {
    outputContent = event.result;
  }

  // Determine input - prefer sql, then input object, then args
  const inputData = event.sql || event.input || (event.args ? { args: event.args } : undefined);

  return (
    <div className={className} {...props}>
      <Tool defaultOpen={defaultOpen}>
        <ToolHeader toolName={event.tool} state={state} />
        <ToolContent>
          {inputData && (
            <ToolInput
              input={inputData}
              toolName={event.tool}
            />
          )}
          {event.denied ? (
            <ToolDenied message="Tool execution was denied by user" />
          ) : (
            <>
              <ToolOutput output={outputContent} errorText={event.error} stats={event.stats} />
              <ToolDiff diff={event.diff} />
            </>
          )}
        </ToolContent>
      </Tool>
    </div>
  );
};
