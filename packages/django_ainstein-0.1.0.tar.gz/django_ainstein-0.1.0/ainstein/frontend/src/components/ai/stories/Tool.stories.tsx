import type { Meta, StoryObj } from '@storybook/react';
import {
  Tool,
  ToolHeader,
  ToolContent,
  ToolInput,
  ToolOutput,
  ToolDenied,
  ToolCard,
  type ToolEvent,
} from '../index';

const meta: Meta<typeof ToolCard> = {
  title: 'AI/Tool',
  component: ToolCard,
  parameters: {
    layout: 'padded',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof ToolCard>;

// ToolCard Stories - Using the complete component

export const Pending: Story = {
  args: {
    event: {
      tool: "database_query",
      input: {
        query: "SELECT * FROM users WHERE active = true",
        limit: 10
      },
    },
  },
};

export const Running: Story = {
  args: {
    event: {
      tool: "database_query",
      input: {
        query: "SELECT COUNT(*) FROM users WHERE created_at >= ?",
        params: ["2024-01-01"],
        database: "analytics"
      },
    },
  },
};

export const Completed: Story = {
  args: {
    event: {
      tool: "database_query",
      input: {
        query: "SELECT id, name, email FROM users LIMIT 5",
      },
      data_preview: [
        { id: 1, name: 'John Doe', email: 'john@example.com' },
        { id: 2, name: 'Jane Smith', email: 'jane@example.com' },
        { id: 3, name: 'Bob Wilson', email: 'bob@example.com' },
      ],
      result: "3 rows returned",
    },
  },
};

export const Error: Story = {
  args: {
    event: {
      tool: "database_query",
      input: {
        query: "SELECT COUNT(*) FROM users WHERE created_at >= ?",
        params: ["2024-01-01"],
        database: "analytics"
      },
      error: "Connection timeout: Unable to reach database server",
    },
  },
};

export const Denied: Story = {
  args: {
    event: {
      tool: "database_query",
      input: {
        query: "DELETE FROM users WHERE id = 1",
      },
      denied: true,
    },
  },
};

// SQL Tool Examples
export const RawSQL: Story = {
  args: {
    event: {
      tool: "RawSQL",
      sql: `SELECT
  u.id,
  u.name,
  COUNT(o.id) as order_count,
  SUM(o.total) as total_spent
FROM users u
LEFT JOIN orders o ON u.id = o.user_id
WHERE u.created_at >= '2024-01-01'
GROUP BY u.id, u.name
ORDER BY total_spent DESC
LIMIT 10`,
      data_preview: [
        { id: 1, name: 'John Doe', order_count: 15, total_spent: 1250.00 },
        { id: 2, name: 'Jane Smith', order_count: 8, total_spent: 890.50 },
        { id: 3, name: 'Bob Wilson', order_count: 12, total_spent: 720.00 },
      ],
      result: "10 rows returned",
    },
  },
};

export const Query: Story = {
  args: {
    event: {
      tool: "Query",
      sql: `SELECT "rlsbb_show"."id" AS "id", "rlsbb_show"."title" AS "title", "rlsbb_show"."created" AS "created"
FROM rlsbb_show
WHERE title ILIKE '%friends%'
ORDER BY created DESC`,
      data_preview: [
        { id: 7478, title: '1000-lb Best Friends', created: '2024-10-23' },
        { id: 2607, title: '1000-lb Sisters', created: '2023-12-23' },
      ],
      result: "2 rows returned",
    },
  },
};

// Single-line SQL that gets auto-formatted
export const SingleLineSQL: Story = {
  args: {
    event: {
      tool: "Query",
      sql: `SELECT "rlsbb_show"."id", "rlsbb_show"."title", "rlsbb_show"."hash" FROM "rlsbb_show" ORDER BY "rlsbb_show"."id" DESC LIMIT 10`,
      data_preview: [
        { id: 7500, title: 'The Office', hash: 'abc123' },
        { id: 7499, title: 'Parks and Recreation', hash: 'def456' },
        { id: 7498, title: 'Brooklyn Nine-Nine', hash: 'ghi789' },
      ],
      result: "10 rows returned",
    },
  },
};

// Complex single-line SQL with JOINs
export const ComplexSingleLineSQL: Story = {
  args: {
    event: {
      tool: "RawSQL",
      sql: `SELECT u.id, u.name, u.email, COUNT(o.id) as order_count, SUM(o.total) as total_spent FROM users u LEFT JOIN orders o ON u.id = o.user_id WHERE u.created_at >= '2024-01-01' AND u.status = 'active' GROUP BY u.id, u.name, u.email HAVING COUNT(o.id) > 0 ORDER BY total_spent DESC LIMIT 25`,
      data_preview: [
        { id: 1, name: 'John Doe', email: 'john@example.com', order_count: 15, total_spent: 1250.00 },
        { id: 2, name: 'Jane Smith', email: 'jane@example.com', order_count: 8, total_spent: 890.50 },
      ],
      result: "25 rows returned",
    },
  },
};

// Bash Tool Example
export const BashTool: Story = {
  args: {
    event: {
      tool: "Bash",
      args: "cd /app && npm run build",
      result: "Build completed successfully in 8.4s",
    },
  },
};

// JSON Input Example
export const JsonInput: Story = {
  args: {
    event: {
      tool: "api_request",
      input: {
        method: "POST",
        url: "https://api.example.com/users",
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer token123"
        },
        body: {
          name: "John Doe",
          email: "john@example.com"
        }
      },
      result: '{"id": 123, "status": "created"}',
    },
  },
};

// Large Data Preview
export const LargeDataPreview: Story = {
  args: {
    event: {
      tool: "Query",
      sql: "SELECT * FROM users LIMIT 15",
      data_preview: Array.from({ length: 15 }, (_, i) => ({
        id: i + 1,
        name: `User ${i + 1}`,
        email: `user${i + 1}@example.com`,
        status: i % 3 === 0 ? 'active' : i % 3 === 1 ? 'inactive' : 'pending',
        created_at: `2024-01-${String(i + 1).padStart(2, '0')}`,
      })),
      result: "15 rows returned",
    },
  },
};

// Multiple Tools
export const MultipleTools: Story = {
  render: () => (
    <div className="space-y-4">
      <ToolCard
        event={{
          tool: "django_list_models",
          input: { app_label: "jobs" },
          result: "Found 5 models: Company, Contact, Opportunity, Interaction, FileResource",
        }}
      />
      <ToolCard
        event={{
          tool: "Query",
          sql: "SELECT * FROM jobs_company WHERE active = true",
        }}
      />
      <ToolCard
        event={{
          tool: "RawSQL",
          sql: "DELETE FROM users WHERE id = 1",
          error: "Only SELECT statements are allowed",
        }}
      />
    </div>
  ),
};

// Collapsed State
export const Collapsed: Story = {
  args: {
    event: {
      tool: "database_query",
      input: { query: "SELECT * FROM users" },
      result: "100 rows returned",
    },
    defaultOpen: false,
  },
};

// Primitive Components (for advanced usage)
export const PrimitiveComponents: Story = {
  render: () => (
    <Tool defaultOpen>
      <ToolHeader toolName="custom_tool" state="completed" />
      <ToolContent>
        <ToolInput
          toolName="custom_tool"
          input={{
            customParam: "value",
            nested: { key: "value" }
          }}
        />
        <ToolOutput output="Custom output content" />
      </ToolContent>
    </Tool>
  ),
};
