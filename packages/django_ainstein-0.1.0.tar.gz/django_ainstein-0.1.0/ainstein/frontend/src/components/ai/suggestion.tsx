/**
 * Suggestion component for displaying clickable suggestions
 * Based on ai-sdk.dev/elements/components/suggestion
 */

import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import type { ComponentProps, HTMLAttributes } from "react";

// Suggestions container with vertical scroll and wrapping
export type SuggestionsProps = HTMLAttributes<HTMLDivElement>;

export const Suggestions = ({
  className,
  children,
  ...props
}: SuggestionsProps) => (
  <div
    className={cn(
      "w-full max-h-28 overflow-y-auto",
      className
    )}
    {...props}
  >
    <div className="flex flex-wrap gap-2">{children}</div>
  </div>
);

// Individual suggestion button
export type SuggestionProps = Omit<ComponentProps<typeof Button>, "onClick"> & {
  suggestion: string;
  onClick?: (suggestion: string) => void;
};

export const Suggestion = ({
  className,
  suggestion,
  onClick,
  children,
  ...props
}: SuggestionProps) => (
  <Button
    variant="outline"
    size="sm"
    className={cn(
      "shrink-0 rounded-full",
      className
    )}
    onClick={() => onClick?.(suggestion)}
    {...props}
  >
    {children ?? suggestion}
  </Button>
);
