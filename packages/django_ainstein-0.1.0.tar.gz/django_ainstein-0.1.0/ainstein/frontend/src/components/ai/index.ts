/**
 * AI Components - Based on ai-sdk.dev/elements
 */

// CodeBlock - Syntax highlighting with Shiki
export { CodeBlock, CodeBlockCopyButton } from "./code-block";
export type { CodeBlockProps, CodeBlockCopyButtonProps } from "./code-block";

// Response - Markdown rendering (keeping for backwards compatibility)
export { Response } from "./response";
export type { ResponseProps } from "./response";

// Loader - Spinning loader for loading states
export { Loader, LoaderIcon } from "./loader";
export type { LoaderProps } from "./loader";

// Confirmation - Tool execution approval workflow
export {
  Confirmation,
  ConfirmationContent,
  ConfirmationRequest,
  ConfirmationAccepted,
  ConfirmationRejected,
  ConfirmationActions,
  ConfirmationAction,
} from "./confirmation";
export type {
  ConfirmationProps,
  ConfirmationContentProps,
  ConfirmationRequestProps,
  ConfirmationAcceptedProps,
  ConfirmationRejectedProps,
  ConfirmationActionsProps,
  ConfirmationActionProps,
  ConfirmationState,
  ConfirmationApproval,
} from "./confirmation";

// Conversation - Auto-scrolling chat container
export {
  Conversation,
  ConversationContent,
  ConversationEmptyState,
  ConversationScrollButton,
} from "./conversation";
export type {
  ConversationProps,
  ConversationContentProps,
  ConversationEmptyStateProps,
  ConversationScrollButtonProps,
} from "./conversation";

// Message - Chat message display with actions and branching
export {
  Message,
  MessageContent,
  MessageAvatar,
  MessageResponse,
  MessageActions,
  MessageAction,
  MessageCopyAction,
  MessageRetryAction,
  MessageLikeAction,
  MessageDislikeAction,
  MessageBranch,
  MessageBranchContent,
  MessageBranchSelector,
  MessageAttachments,
  MessageAttachment,
} from "./message";
export type {
  MessageProps,
  MessageContentProps,
  MessageAvatarProps,
  MessageRole,
  MessageResponseProps,
  MessageActionsProps,
  MessageActionProps,
  MessageBranchProps,
  MessageBranchContentProps,
  MessageBranchSelectorProps,
  MessageAttachmentsProps,
  MessageAttachmentProps,
  FileUIPart,
} from "./message";

// Reasoning - Collapsible AI reasoning display
export {
  Reasoning,
  ReasoningTrigger,
  ReasoningContent,
  useReasoningContext,
} from "./reasoning";
export type {
  ReasoningProps,
  ReasoningTriggerProps,
  ReasoningContentProps,
} from "./reasoning";

// Plan - Collapsible execution plan display
export {
  Plan,
  PlanHeader,
  PlanTitle,
  PlanDescription,
  PlanTrigger,
  PlanContent,
  PlanFooter,
  PlanAction,
} from "./plan";
export type {
  PlanProps,
  PlanHeaderProps,
  PlanTitleProps,
  PlanDescriptionProps,
  PlanTriggerProps,
  PlanContentProps,
  PlanFooterProps,
  PlanActionProps,
} from "./plan";

// PromptInput - User input with file attachments
export {
  PromptInput,
  PromptInputHeader,
  PromptInputBody,
  PromptInputTextarea,
  PromptInputFooter,
  PromptInputTools,
  PromptInputSubmit,
  PromptInputAttachButton,
  PromptInputSpeechButton,
  PromptInputAttachments,
  usePromptInputAttachments,
} from "./prompt-input";
export type {
  PromptInputProps,
  PromptInputHeaderProps,
  PromptInputBodyProps,
  PromptInputTextareaProps,
  PromptInputFooterProps,
  PromptInputToolsProps,
  PromptInputSubmitProps,
  PromptInputAttachButtonProps,
  PromptInputSpeechButtonProps,
  PromptInputAttachmentsProps,
  PromptInputMessage,
} from "./prompt-input";

// Queue - Message lists and todos
export {
  Queue,
  QueueSection,
  QueueSectionTrigger,
  QueueSectionLabel,
  QueueSectionContent,
  QueueList,
  QueueItem,
  QueueItemIndicator,
  QueueItemContent,
  QueueItemDescription,
  QueueItemActions,
  QueueItemAction,
  QueueItemAttachment,
  QueueItemImage,
  QueueItemFile,
} from "./queue";
export type {
  QueueProps,
  QueueSectionProps,
  QueueSectionTriggerProps,
  QueueSectionLabelProps,
  QueueSectionContentProps,
  QueueListProps,
  QueueItemProps,
  QueueItemIndicatorProps,
  QueueItemContentProps,
  QueueItemDescriptionProps,
  QueueItemActionsProps,
  QueueItemActionProps,
  QueueItemAttachmentProps,
  QueueItemImageProps,
  QueueItemFileProps,
} from "./queue";

// Suggestion - Clickable suggestion buttons
export { Suggestions, Suggestion } from "./suggestion";
export type { SuggestionsProps, SuggestionProps } from "./suggestion";

// Task - Collapsible task lists with status indicators
export {
  Task,
  TaskTrigger,
  TaskContent,
  TaskItem,
  TaskItemFile,
  TaskItemDescription,
} from "./task";
export type {
  TaskProps,
  TaskTriggerProps,
  TaskContentProps,
  TaskItemProps,
  TaskItemFileProps,
  TaskItemDescriptionProps,
  TaskStatus,
} from "./task";

// Tool - Tool execution display with state indicators
export {
  Tool,
  ToolHeader,
  ToolContent,
  ToolInput,
  ToolOutput,
  ToolDenied,
  ToolDiff,
  ToolCard,
} from "./tool";
export type {
  ToolProps,
  ToolHeaderProps,
  ToolContentProps,
  ToolInputProps,
  ToolOutputProps,
  ToolDeniedProps,
  ToolDiffProps,
  ToolCardProps,
  ToolEvent,
  ToolStats,
  ToolState,
  ToolType,
} from "./tool";

// Artifact - Container for displaying generated content
export {
  Artifact,
  ArtifactHeader,
  ArtifactTitle,
  ArtifactDescription,
  ArtifactActions,
  ArtifactAction,
  ArtifactClose,
  ArtifactContent,
  ArtifactLoading,
  ArtifactError,
  ArtifactEmpty,
} from "./artifact";
export type {
  ArtifactProps,
  ArtifactHeaderProps,
  ArtifactTitleProps,
  ArtifactDescriptionProps,
  ArtifactActionsProps,
  ArtifactActionProps,
  ArtifactCloseProps,
  ArtifactContentProps,
  ArtifactLoadingProps,
  ArtifactErrorProps,
  ArtifactEmptyProps,
} from "./artifact";

// PermissionDialog - Human-in-the-loop confirmation for tool execution
export { PermissionDialog } from "./permission-dialog";
export type {
  PermissionDialogProps,
  PermissionRequest,
  PermissionState,
} from "./permission-dialog";

// Sources - Display web search results
export {
  Sources,
  SourcesTrigger,
  SourcesContent,
  Source,
  SourcesList,
} from "./sources";
export type {
  SourcesProps,
  SourcesTriggerProps,
  SourcesContentProps,
  SourceProps,
  SourcesListProps,
} from "./sources";

// InlineCitation - Inline citation with hover cards
export {
  InlineCitation,
  InlineCitationText,
  InlineCitationBadge,
  InlineCitationCard,
  InlineCitationCardBody,
  InlineCitationSource,
  InlineCitationQuote,
  Citation,
} from "./inline-citation";
export type {
  InlineCitationProps,
  InlineCitationTextProps,
  InlineCitationBadgeProps,
  InlineCitationCardProps,
  InlineCitationCardBodyProps,
  InlineCitationSourceProps,
  InlineCitationQuoteProps,
  CitationProps,
} from "./inline-citation";

// WebPreview - Iframe preview for web content
export {
  WebPreview,
  WebPreviewNavigation,
  WebPreviewNavigationButton,
  WebPreviewRefreshButton,
  WebPreviewOpenExternalButton,
  WebPreviewUrl,
  WebPreviewBody,
  WebPreviewConsole,
  SimpleWebPreview,
  useWebPreview,
} from "./web-preview";
export type {
  WebPreviewProps,
  WebPreviewNavigationProps,
  WebPreviewNavigationButtonProps,
  WebPreviewRefreshButtonProps,
  WebPreviewOpenExternalButtonProps,
  WebPreviewUrlProps,
  WebPreviewBodyProps,
  WebPreviewConsoleProps,
  SimpleWebPreviewProps,
  WebPreviewContextValue,
  ConsoleLog,
} from "./web-preview";
