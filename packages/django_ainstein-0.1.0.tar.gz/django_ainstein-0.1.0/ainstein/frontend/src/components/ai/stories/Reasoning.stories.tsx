import type { Meta, StoryObj } from '@storybook/react';
import { Reasoning, ReasoningTrigger, ReasoningContent } from '../index';

const meta: Meta<typeof Reasoning> = {
  title: 'AI/Reasoning',
  component: Reasoning,
  parameters: {
    layout: 'padded',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof Reasoning>;

export const Default: Story = {
  render: () => (
    <div className="w-[500px]">
      <Reasoning defaultOpen duration={5}>
        <ReasoningTrigger />
        <ReasoningContent>
{`I need to analyze this problem step by step:

1. First, let's identify the key requirements
2. Then, consider the data structures needed
3. Finally, implement the solution

The user wants to find all users who have made purchases in the last 30 days. I'll need to join the users and orders tables.`}
        </ReasoningContent>
      </Reasoning>
    </div>
  ),
};

export const Streaming: Story = {
  render: () => (
    <div className="w-[500px]">
      <Reasoning isStreaming defaultOpen>
        <ReasoningTrigger />
        <ReasoningContent>
{`Analyzing the request...

The user is asking for a complex query that involves multiple tables. Let me think through the approach:

- Need to consider performance implications
- Should use appropriate indexes
- Must handle edge cases...`}
        </ReasoningContent>
      </Reasoning>
    </div>
  ),
};

export const Collapsed: Story = {
  render: () => (
    <div className="w-[500px]">
      <Reasoning defaultOpen={false} duration={12}>
        <ReasoningTrigger />
        <ReasoningContent>
{`This content is hidden by default. Click the trigger to expand.

The reasoning shows the AI's thought process as it works through the problem.`}
        </ReasoningContent>
      </Reasoning>
    </div>
  ),
};

export const LongReasoning: Story = {
  render: () => (
    <div className="w-[500px]">
      <Reasoning defaultOpen duration={45}>
        <ReasoningTrigger />
        <ReasoningContent>
{`This is a complex problem that requires careful consideration of multiple factors.

## Step 1: Understanding the Requirements

The user wants to implement a recommendation system. Let me break this down:

- **Data Collection**: We need user behavior data
- **Feature Engineering**: Extract meaningful features
- **Model Selection**: Choose appropriate algorithm

## Step 2: Technical Approach

I'll consider several approaches:

1. Collaborative filtering
2. Content-based filtering
3. Hybrid approach

## Step 3: Implementation Plan

\`\`\`python
def get_recommendations(user_id):
    # Get user preferences
    preferences = get_user_preferences(user_id)

    # Calculate similarity scores
    scores = calculate_similarity(preferences)

    # Return top recommendations
    return sorted(scores, reverse=True)[:10]
\`\`\`

This approach should provide good results while maintaining reasonable performance.`}
        </ReasoningContent>
      </Reasoning>
    </div>
  ),
};

export const CustomTrigger: Story = {
  render: () => (
    <div className="w-[500px]">
      <Reasoning defaultOpen duration={8}>
        <ReasoningTrigger title="Analysis Process" />
        <ReasoningContent>
{`Custom trigger text can help users understand what type of reasoning is being shown.

In this case, we're analyzing the user's query to provide the most relevant response.`}
        </ReasoningContent>
      </Reasoning>
    </div>
  ),
};

export const WithCodeBlocks: Story = {
  render: () => (
    <div className="w-[500px]">
      <Reasoning defaultOpen duration={15}>
        <ReasoningTrigger />
        <ReasoningContent>
{`Let me trace through the code execution:

First, the function is called with these parameters:

\`\`\`javascript
const result = processData({
  items: [1, 2, 3, 4, 5],
  filter: x => x > 2,
  transform: x => x * 2
});
\`\`\`

The execution flow:
1. Filter removes items <= 2, leaving [3, 4, 5]
2. Transform multiplies each by 2: [6, 8, 10]
3. Result is returned as [6, 8, 10]

This matches the expected output.`}
        </ReasoningContent>
      </Reasoning>
    </div>
  ),
};
