import type { Meta, StoryObj } from '@storybook/react';
import { Loader, LoaderIcon } from '../index';

const meta: Meta<typeof Loader> = {
  title: 'AI/Loader',
  component: Loader,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof Loader>;

export const Default: Story = {
  render: () => <Loader />,
};

export const Small: Story = {
  render: () => <Loader size={16} />,
};

export const Large: Story = {
  render: () => <Loader size={48} />,
};

export const WithText: Story = {
  render: () => (
    <div className="flex items-center gap-2">
      <Loader size={20} />
      <span className="text-muted-foreground">Loading...</span>
    </div>
  ),
};

export const IconOnly: Story = {
  render: () => <LoaderIcon size={24} />,
};

export const CustomColor: Story = {
  render: () => <LoaderIcon size={24} className="text-primary" />,
};

export const InButton: Story = {
  render: () => (
    <button className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-md" disabled>
      <LoaderIcon size={16} />
      Processing...
    </button>
  ),
};

export const Sizes: Story = {
  render: () => (
    <div className="flex items-center gap-8">
      <div className="text-center">
        <Loader size={16} />
        <p className="text-xs text-muted-foreground mt-2">16px</p>
      </div>
      <div className="text-center">
        <Loader size={24} />
        <p className="text-xs text-muted-foreground mt-2">24px</p>
      </div>
      <div className="text-center">
        <Loader size={32} />
        <p className="text-xs text-muted-foreground mt-2">32px</p>
      </div>
      <div className="text-center">
        <Loader size={48} />
        <p className="text-xs text-muted-foreground mt-2">48px</p>
      </div>
    </div>
  ),
};
