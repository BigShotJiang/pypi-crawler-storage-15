import type { Meta, StoryObj } from "@storybook/react";
import { PromptInputProvider } from "@/components/ai-elements/prompt-input";
import { ChatInputWithSuggestions } from "./chat-input-with-suggestions";

const meta: Meta<typeof ChatInputWithSuggestions> = {
  title: "Projects/ChatInputWithSuggestions",
  component: ChatInputWithSuggestions,
  parameters: {
    layout: "centered",
  },
  tags: ["autodocs"],
  argTypes: {
    onSubmit: { action: "submitted" },
  },
  decorators: [
    (Story) => (
      <PromptInputProvider>
        <div className="w-[500px]">
          <Story />
        </div>
      </PromptInputProvider>
    ),
  ],
};

export default meta;
type Story = StoryObj<typeof ChatInputWithSuggestions>;

export const Default: Story = {
  args: {
    projectName: "My Project",
    isCreatingChat: false,
  },
};

export const Creating: Story = {
  args: {
    projectName: "My Project",
    isCreatingChat: true,
  },
};

export const LongProjectName: Story = {
  args: {
    projectName: "My Very Long Project Name That Might Overflow",
    isCreatingChat: false,
  },
};

export const ShortProjectName: Story = {
  args: {
    projectName: "Dev",
    isCreatingChat: false,
  },
};
