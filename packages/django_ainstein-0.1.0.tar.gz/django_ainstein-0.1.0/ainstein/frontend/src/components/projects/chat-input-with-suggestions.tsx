/**
 * ChatInputWithSuggestions Component
 *
 * Chat input with suggestion chips for starting new conversations.
 */

import { useRef, useCallback } from "react";
import {
  PromptInput,
  PromptInputTextarea,
  PromptInputFooter,
  PromptInputSubmit,
  usePromptInputController,
} from "@/components/ai-elements/prompt-input";
import { Suggestions, Suggestion } from "@/components/ai/suggestion";
import { ImprovePromptButton } from "@/components/chat/improve-prompt-button";

interface ChatInputWithSuggestionsProps {
  projectName: string;
  isCreatingChat: boolean;
  onSubmit: (message: string) => void;
  onImprovePrompt?: (prompt: string) => Promise<string | null>;
  isImproving?: boolean;
}

export function ChatInputWithSuggestions({
  projectName,
  isCreatingChat,
  onSubmit,
  onImprovePrompt,
  isImproving = false,
}: ChatInputWithSuggestionsProps) {
  const { textInput } = usePromptInputController();
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleSuggestionClick = (suggestion: string) => {
    textInput.setInput(suggestion);
    // Focus textarea after setting input and move cursor to end
    setTimeout(() => {
      textareaRef.current?.focus();
      textareaRef.current?.setSelectionRange(suggestion.length, suggestion.length);
    }, 0);
  };

  const handleImproveChange = useCallback((value: string) => {
    textInput.setInput(value);
  }, [textInput]);

  return (
    <>
      <div onClick={() => textareaRef.current?.focus()} className="cursor-text">
        <PromptInput
          onSubmit={(message) => {
            if (message.text.trim()) {
              onSubmit(message.text);
            }
          }}
          className="rounded-2xl bg-muted/50 input-focus-glow"
        >
          <PromptInputTextarea
            ref={textareaRef}
            placeholder={`Start a new chat in ${projectName}...`}
            disabled={isCreatingChat || isImproving}
            className="min-h-12 rounded-2xl resize-none border-0 bg-transparent focus-visible:ring-0"
          />
          <PromptInputFooter className="p-2 pt-0">
            {onImprovePrompt ? (
              <ImprovePromptButton
                value={textInput.value}
                onChange={handleImproveChange}
                onImprove={onImprovePrompt}
                isImproving={isImproving}
                disabled={isCreatingChat}
              />
            ) : (
              <div />
            )}
            <PromptInputSubmit
              disabled={isCreatingChat || isImproving}
              status={isCreatingChat ? "submitted" : "ready"}
            />
          </PromptInputFooter>
        </PromptInput>
      </div>

      <Suggestions className="mt-4">
        <Suggestion
          suggestion="Analyze my Django models and create summary charts"
          onClick={handleSuggestionClick}
          disabled={!!textInput.value}
        />
        <Suggestion
          suggestion="Create an interactive HTML dashboard for my data"
          onClick={handleSuggestionClick}
          disabled={!!textInput.value}
        />
        <Suggestion
          suggestion="Export data to Excel with formatting"
          onClick={handleSuggestionClick}
          disabled={!!textInput.value}
        />
        <Suggestion
          suggestion="Run statistical analysis on a model"
          onClick={handleSuggestionClick}
          disabled={!!textInput.value}
        />
        <Suggestion
          suggestion="Generate visualization charts for my data"
          onClick={handleSuggestionClick}
          disabled={!!textInput.value}
        />
        <Suggestion
          suggestion="List and describe available models"
          onClick={handleSuggestionClick}
          disabled={!!textInput.value}
        />
        <Suggestion
          suggestion="Create a summary of files in the project"
          onClick={handleSuggestionClick}
          disabled={!!textInput.value}
        />
        <Suggestion
          suggestion="Write and execute Python code"
          onClick={handleSuggestionClick}
          disabled={!!textInput.value}
        />
      </Suggestions>
    </>
  );
}
