/**
 * ProjectItem Component
 *
 * Displays a single project in the sidebar with dropdown menu actions.
 */

import { useState } from "react";
import {
  Folder,
  Trash2,
  MoreVertical,
  Settings,
  FileText,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { cn } from "@/lib/utils";
import type { Project } from "@/types";

interface ProjectItemProps {
  project: Project;
  isSelected: boolean;
  onSelect: (id: number) => void;
  onDelete: (id: number) => void;
  onSettings: (project: Project) => void;
  onInstructions: (project: Project) => void;
}

export function ProjectItem({
  project,
  isSelected,
  onSelect,
  onDelete,
  onSettings,
  onInstructions,
}: ProjectItemProps) {
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);

  return (
    <>
    <div
      onClick={() => onSelect(project.id)}
      className={cn(
        "py-3 px-4 cursor-pointer mb-1 flex justify-between items-start relative",
        isSelected ? "bg-card" : "hover:bg-card/50"
      )}
    >
      <div className="flex-1">
        <div className="flex items-center gap-2 mb-1">
          <Folder className="size-4 min-w-4 min-h-4 flex-shrink-0 text-muted-foreground" />
          <span
            className={cn(
              "font-medium",
              isSelected ? "text-foreground" : "text-secondary-foreground"
            )}
          >
            {project.name}
          </span>
          {project.is_shared && (
            <span className="text-[10px] text-accent" title="Shared with team">
              🌐
            </span>
          )}
        </div>
        {!project.is_owner && (
          <div className="text-[11px] text-muted-foreground">
            by {project.owner_name}
          </div>
        )}
        <div className="text-[11px] text-muted-foreground mt-1">
          {project.conversation_count} conversations · {project.file_count} files
        </div>
      </div>

      {project.is_owner && (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button
              onClick={(e) => e.stopPropagation()}
              className="p-1.5 rounded-md transition-colors hover:bg-muted data-[state=open]:bg-muted"
            >
              <MoreVertical className="h-4 w-4 text-muted-foreground" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-48 font-sans">
            <DropdownMenuItem
              onClick={(e) => {
                e.stopPropagation();
                onSettings(project);
              }}
            >
              <Settings className="h-4 w-4 mr-2" />
              Project settings
            </DropdownMenuItem>
            <DropdownMenuItem
              onClick={(e) => {
                e.stopPropagation();
                onInstructions(project);
              }}
            >
              <FileText className="h-4 w-4 mr-2" />
              Add instructions
            </DropdownMenuItem>
            <DropdownMenuItem
              onClick={(e) => {
                e.stopPropagation();
                setDeleteDialogOpen(true);
              }}
              className="text-destructive focus:text-destructive"
            >
              <Trash2 className="h-4 w-4 mr-2" />
              Delete project
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      )}
    </div>

    <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Delete project</AlertDialogTitle>
          <AlertDialogDescription>
            Are you sure you want to delete "{project.name}" and all its conversations? This action cannot be undone.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Cancel</AlertDialogCancel>
          <AlertDialogAction
            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            onClick={() => onDelete(project.id)}
          >
            Delete
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
    </>
  );
}
