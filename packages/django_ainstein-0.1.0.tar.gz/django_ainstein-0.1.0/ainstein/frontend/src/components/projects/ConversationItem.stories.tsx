import type { Meta, StoryObj } from "@storybook/react";
import { ConversationItem } from "./conversation-item";

const meta: Meta<typeof ConversationItem> = {
  title: "Projects/ConversationItem",
  component: ConversationItem,
  parameters: {
    layout: "centered",
  },
  tags: ["autodocs"],
  argTypes: {
    onSelect: { action: "selected" },
    onDelete: { action: "deleted" },
  },
  decorators: [
    (Story) => (
      <div className="w-[400px]">
        <Story />
      </div>
    ),
  ],
};

export default meta;
type Story = StoryObj<typeof ConversationItem>;

const now = new Date();
const today = now.toISOString();
const yesterday = new Date(now.getTime() - 86400000).toISOString();
const lastWeek = new Date(now.getTime() - 604800000).toISOString();

export const Default: Story = {
  args: {
    conversation: {
      id: 1,
      title: "Help with React hooks",
      modified: today,
      last_message: "Thanks, that worked perfectly!",
    },
  },
};

export const Today: Story = {
  args: {
    conversation: {
      id: 2,
      title: "Database optimization",
      modified: today,
      last_message: "Can you help me optimize this SQL query?",
    },
  },
};

export const Yesterday: Story = {
  args: {
    conversation: {
      id: 3,
      title: "API Design Review",
      modified: yesterday,
      last_message: "The REST endpoints look good, but consider...",
    },
  },
};

export const OlderDate: Story = {
  args: {
    conversation: {
      id: 4,
      title: "Project setup",
      modified: lastWeek,
      last_message: "Here are the commands to initialize the project.",
    },
  },
};

export const NoTitle: Story = {
  args: {
    conversation: {
      id: 5,
      title: "",
      modified: today,
      last_message: "Hello, can you help me?",
    },
  },
};

export const NoLastMessage: Story = {
  args: {
    conversation: {
      id: 6,
      title: "New conversation",
      modified: today,
      last_message: "",
    },
  },
};

export const LongTitle: Story = {
  args: {
    conversation: {
      id: 7,
      title: "This is a very long conversation title that should be truncated when it exceeds the available width",
      modified: today,
      last_message: "Short message",
    },
  },
};

export const LongMessage: Story = {
  args: {
    conversation: {
      id: 8,
      title: "Code Review",
      modified: today,
      last_message: "This is a very long last message that demonstrates how the text truncation works when the content exceeds the available space in the component layout area.",
    },
  },
};

export const List: Story = {
  render: () => (
    <div className="space-y-2">
      <ConversationItem
        conversation={{
          id: 1,
          title: "Help with React hooks",
          modified: today,
          last_message: "Thanks, that worked perfectly!",
        }}
        onSelect={() => {}}
        onDelete={() => {}}
      />
      <ConversationItem
        conversation={{
          id: 2,
          title: "Database optimization",
          modified: yesterday,
          last_message: "Can you help me optimize this SQL query?",
        }}
        onSelect={() => {}}
        onDelete={() => {}}
      />
      <ConversationItem
        conversation={{
          id: 3,
          title: "Project setup",
          modified: lastWeek,
          last_message: "Here are the commands to initialize the project.",
        }}
        onSelect={() => {}}
        onDelete={() => {}}
      />
    </div>
  ),
};
