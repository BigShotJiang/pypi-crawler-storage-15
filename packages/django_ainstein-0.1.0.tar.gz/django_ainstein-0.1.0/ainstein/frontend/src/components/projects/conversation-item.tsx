/**
 * ConversationItem Component
 *
 * Displays a single conversation in the list with delete action.
 */

import { useState } from "react";
import { Trash2 } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import type { Conversation } from "@/types";

interface ConversationItemProps {
  conversation: Conversation;
  onSelect: (id: number) => void;
  onDelete: (id: number) => void;
}

function formatDate(dateStr: string): string {
  const date = new Date(dateStr);
  const now = new Date();
  const diff = now.getTime() - date.getTime();
  if (diff < 86400000) return "Today";
  if (diff < 172800000) return "Yesterday";
  return date.toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

export function ConversationItem({
  conversation,
  onSelect,
  onDelete,
}: ConversationItemProps) {
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);

  return (
    <>
      <div
        onClick={() => onSelect(conversation.id)}
        className="p-3 px-4 bg-secondary rounded-lg mb-2 cursor-pointer transition-colors hover:bg-secondary/80"
        data-testid="conversation-item"
        data-conversation-id={conversation.id}
      >
        <div className="flex justify-between items-center mb-1.5">
          <span className="font-semibold text-foreground text-sm flex-1 truncate">
            {conversation.title || "Untitled Conversation"}
          </span>
          <div className="flex items-center gap-2 shrink-0">
            <span className="text-xs text-muted-foreground">
              {formatDate(conversation.modified)}
            </span>
            <button
              onClick={(e) => {
                e.stopPropagation();
                setDeleteDialogOpen(true);
              }}
              className="opacity-40 hover:opacity-100 text-destructive p-0.5"
            >
              <Trash2 className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
        <div className="text-[13px] text-muted-foreground truncate">
          {conversation.last_message || "No messages yet"}
        </div>
      </div>

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete conversation</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this conversation? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => onDelete(conversation.id)}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
