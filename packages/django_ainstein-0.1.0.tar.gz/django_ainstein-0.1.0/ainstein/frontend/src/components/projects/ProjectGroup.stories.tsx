import type { Meta, StoryObj } from "@storybook/react";
import { Globe, Lock } from "lucide-react";
import { ProjectGroup } from "./project-group";

const meta: Meta<typeof ProjectGroup> = {
  title: "Projects/ProjectGroup",
  component: ProjectGroup,
  parameters: {
    layout: "centered",
  },
  tags: ["autodocs"],
  argTypes: {
    onToggle: { action: "toggled" },
    onSelectProject: { action: "projectSelected" },
    onDeleteProject: { action: "projectDeleted" },
    onSettingsProject: { action: "projectSettings" },
    onInstructionsProject: { action: "projectInstructions" },
    onCreateProject: { action: "projectCreated" },
  },
  decorators: [
    (Story) => (
      <div className="w-[240px] bg-sidebar">
        <Story />
      </div>
    ),
  ],
};

export default meta;
type Story = StoryObj<typeof ProjectGroup>;

const sampleProjects = [
  {
    id: 1,
    name: "Frontend App",
    slug: "frontend-app",
    is_shared: false,
    is_owner: true,
    conversation_count: 12,
    file_count: 5,
  },
  {
    id: 2,
    name: "Backend API",
    slug: "backend-api",
    is_shared: false,
    is_owner: true,
    conversation_count: 8,
    file_count: 3,
  },
  {
    id: 3,
    name: "Documentation",
    slug: "documentation",
    is_shared: false,
    is_owner: true,
    conversation_count: 3,
    file_count: 10,
  },
];

const sharedProjects = [
  {
    id: 4,
    name: "Team Project",
    slug: "team-project",
    is_shared: true,
    is_owner: true,
    conversation_count: 25,
    file_count: 8,
  },
  {
    id: 5,
    name: "Client Work",
    slug: "client-work",
    is_shared: true,
    is_owner: false,
    owner_name: "Alice Smith",
    conversation_count: 7,
    file_count: 2,
  },
];

export const PrivateExpanded: Story = {
  args: {
    title: "My Projects",
    icon: <Lock className="h-3 w-3" />,
    projects: sampleProjects,
    currentProjectId: 1,
    isExpanded: true,
    onCreateProject: async (name) => {
      console.log("Creating project:", name);
    },
  },
};

export const PrivateCollapsed: Story = {
  args: {
    title: "My Projects",
    icon: <Lock className="h-3 w-3" />,
    projects: sampleProjects,
    currentProjectId: null,
    isExpanded: false,
    onCreateProject: async (name) => {
      console.log("Creating project:", name);
    },
  },
};

export const SharedExpanded: Story = {
  args: {
    title: "Shared Projects",
    icon: <Globe className="h-3 w-3" />,
    projects: sharedProjects,
    currentProjectId: 4,
    isExpanded: true,
    onCreateProject: async (name) => {
      console.log("Creating shared project:", name);
    },
  },
};

export const EmptyGroup: Story = {
  args: {
    title: "Shared Projects",
    icon: <Globe className="h-3 w-3" />,
    projects: [],
    currentProjectId: null,
    isExpanded: true,
    onCreateProject: async (name) => {
      console.log("Creating project:", name);
    },
  },
};

export const ManyProjects: Story = {
  args: {
    title: "My Projects",
    icon: <Lock className="h-3 w-3" />,
    projects: Array.from({ length: 10 }, (_, i) => ({
      id: i + 1,
      name: `Project ${i + 1}`,
      slug: `project-${i + 1}`,
      is_shared: false,
      is_owner: true,
      conversation_count: Math.floor(Math.random() * 50),
      file_count: Math.floor(Math.random() * 20),
    })),
    currentProjectId: 3,
    isExpanded: true,
    onCreateProject: async (name) => {
      console.log("Creating project:", name);
    },
  },
};
