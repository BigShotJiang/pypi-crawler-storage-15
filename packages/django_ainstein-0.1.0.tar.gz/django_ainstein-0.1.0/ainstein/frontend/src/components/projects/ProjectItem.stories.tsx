import type { Meta, StoryObj } from "@storybook/react";
import { ProjectItem } from "./project-item";

const meta: Meta<typeof ProjectItem> = {
  title: "Projects/ProjectItem",
  component: ProjectItem,
  parameters: {
    layout: "centered",
  },
  tags: ["autodocs"],
  argTypes: {
    onSelect: { action: "selected" },
    onDelete: { action: "deleted" },
    onSettings: { action: "settings" },
    onInstructions: { action: "instructions" },
  },
};

export default meta;
type Story = StoryObj<typeof ProjectItem>;

const baseProject = {
  id: 1,
  name: "My Project",
  slug: "my-project",
  is_shared: false,
  is_owner: true,
  conversation_count: 5,
  file_count: 3,
};

export const Default: Story = {
  args: {
    project: baseProject,
    isSelected: false,
  },
};

export const Selected: Story = {
  args: {
    project: baseProject,
    isSelected: true,
  },
};

export const SharedProject: Story = {
  args: {
    project: { ...baseProject, is_shared: true, name: "Team Project" },
    isSelected: false,
  },
};

export const NotOwner: Story = {
  args: {
    project: {
      ...baseProject,
      is_owner: false,
      is_shared: true,
      owner_name: "John Doe",
      name: "Shared With Me",
    },
    isSelected: false,
  },
};

export const ManyConversations: Story = {
  args: {
    project: { ...baseProject, conversation_count: 127 },
    isSelected: false,
  },
};

export const NoConversations: Story = {
  args: {
    project: { ...baseProject, conversation_count: 0 },
    isSelected: false,
  },
};

export const LongName: Story = {
  args: {
    project: {
      ...baseProject,
      name: "This is a very long project name that might overflow",
    },
    isSelected: false,
  },
};
