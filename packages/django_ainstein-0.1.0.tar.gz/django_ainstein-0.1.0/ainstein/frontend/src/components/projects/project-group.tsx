/**
 * ProjectGroup Component
 *
 * Collapsible group of projects with create popover.
 */

import { useState } from "react";
import { ChevronRight, ChevronDown, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { ProjectItem } from "./project-item";
import type { Project } from "@/types";

interface ProjectGroupProps {
  title: string;
  icon: React.ReactNode;
  projects: Project[];
  currentProjectId: number | null;
  isExpanded: boolean;
  onToggle: () => void;
  onSelectProject: (id: number) => void;
  onDeleteProject: (id: number) => void;
  onSettingsProject: (project: Project) => void;
  onInstructionsProject: (project: Project) => void;
  onCreateProject: (name: string) => Promise<void>;
}

export function ProjectGroup({
  title,
  icon,
  projects,
  currentProjectId,
  isExpanded,
  onToggle,
  onSelectProject,
  onDeleteProject,
  onSettingsProject,
  onInstructionsProject,
  onCreateProject,
}: ProjectGroupProps) {
  const [popoverOpen, setPopoverOpen] = useState(false);
  const [newName, setNewName] = useState("");
  const [isCreating, setIsCreating] = useState(false);

  const handleCreate = async () => {
    if (!newName.trim() || isCreating) return;
    setIsCreating(true);
    try {
      await onCreateProject(newName.trim());
      setNewName("");
      setPopoverOpen(false);
    } finally {
      setIsCreating(false);
    }
  };

  return (
    <div className="mb-4 pt-4">
      <div className="flex items-center justify-between mb-2 group px-4">
        <button
          onClick={onToggle}
          className="flex items-center gap-2 text-[11px] uppercase tracking-wider text-accent hover:text-accent/80 transition-colors"
        >
          {isExpanded ? (
            <ChevronDown className="h-3 w-3" />
          ) : (
            <ChevronRight className="h-3 w-3" />
          )}
          {icon}
          <span>{title}</span>
        </button>
        <Popover open={popoverOpen} onOpenChange={setPopoverOpen}>
          <PopoverTrigger asChild>
            <button
              className="p-1 rounded hover:bg-muted transition-colors opacity-60 hover:opacity-100"
              title={`Add ${title.toLowerCase().includes('shared') ? 'shared' : 'private'} project`}
            >
              <Plus className="h-3.5 w-3.5 text-accent" />
            </button>
          </PopoverTrigger>
          <PopoverContent className="w-64 font-sans" align="end" side="bottom">
            <div className="space-y-3">
              <h4 className="font-medium text-sm">New Project</h4>
              <input
                type="text"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") handleCreate();
                  if (e.key === "Escape") setPopoverOpen(false);
                }}
                placeholder="Project name..."
                autoFocus
                className="w-full px-3 py-2 text-sm bg-background border border-border rounded-md text-foreground outline-none focus:ring-1 focus:ring-accent"
              />
              <div className="flex gap-2">
                <Button
                  size="sm"
                  onClick={handleCreate}
                  disabled={!newName.trim() || isCreating}
                  className="flex-1"
                >
                  {isCreating ? "Creating..." : "Create"}
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setPopoverOpen(false)}
                >
                  Cancel
                </Button>
              </div>
            </div>
          </PopoverContent>
        </Popover>
      </div>
      {isExpanded && (
        <div>
          {projects.length === 0 ? (
            <div className="text-muted-foreground text-xs p-3 text-center">
              No projects
            </div>
          ) : (
            projects.map((p) => (
              <ProjectItem
                key={p.id}
                project={p}
                isSelected={p.id === currentProjectId}
                onSelect={onSelectProject}
                onDelete={onDeleteProject}
                onSettings={onSettingsProject}
                onInstructions={onInstructionsProject}
              />
            ))
          )}
        </div>
      )}
    </div>
  );
}
