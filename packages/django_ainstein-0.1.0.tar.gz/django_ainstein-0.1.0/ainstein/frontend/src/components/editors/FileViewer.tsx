import { useState, useCallback, useEffect, Suspense } from "react";
import { FileIcon, Copy, Download, Eye, Code2, Save, MoreVertical, Trash2, FileText } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { toast } from "sonner";
import {
  Artifact,
  ArtifactHeader,
  ArtifactTitle,
  ArtifactActions,
  ArtifactAction,
  ArtifactContent,
  ArtifactError,
  ArtifactEmpty,
} from "@/components/ai";
import { getEditorForFile } from "./index";
import { MarkdownViewer } from "./MarkdownViewer";
import { DataViewer } from "./DataViewer";
import { getCsrfToken } from "@/lib/utils";

interface FileViewerProps {
  filePath: string | null;
  content: string | null;
  error?: string;
  isDirectory?: boolean;
  projectId: number;
  apiBaseUrl: string;
  onContentChange?: (content: string) => void;
  onDelete?: (path: string) => void;
}

// Helper to check if file is HTML
function isHtmlFile(filename: string): boolean {
  const ext = filename.split(".").pop()?.toLowerCase() || "";
  return ["html", "htm"].includes(ext);
}

// Helper to check if file is Markdown
function isMarkdownFile(filename: string): boolean {
  const ext = filename.split(".").pop()?.toLowerCase() || "";
  return ["md", "markdown"].includes(ext);
}

// Helper to check if file is CSV
function isCsvFile(filename: string): boolean {
  const ext = filename.split(".").pop()?.toLowerCase() || "";
  return ext === "csv";
}

// Helper to check if file is JSON
function isJsonFile(filename: string): boolean {
  const ext = filename.split(".").pop()?.toLowerCase() || "";
  return ext === "json";
}

// Helper to check if file is an image (use native img tag)
function isImageFile(filename: string): boolean {
  const ext = filename.split(".").pop()?.toLowerCase() || "";
  return ["png", "jpg", "jpeg", "gif", "webp", "bmp", "tiff", "svg", "ico"].includes(ext);
}

// Helper to check if file is an Office document or PDF (show download option)
function isDocumentFile(filename: string): boolean {
  const ext = filename.split(".").pop()?.toLowerCase() || "";
  return ["pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx"].includes(ext);
}

// Get human-readable file type name
function getFileTypeName(filename: string): string {
  const ext = filename.split(".").pop()?.toLowerCase() || "";
  const typeNames: Record<string, string> = {
    pdf: "PDF Document",
    doc: "Word Document (Legacy)",
    docx: "Word Document",
    xls: "Excel Spreadsheet (Legacy)",
    xlsx: "Excel Spreadsheet",
    ppt: "PowerPoint Presentation (Legacy)",
    pptx: "PowerPoint Presentation",
  };
  return typeNames[ext] || ext.toUpperCase();
}

// Pretty-print JSON content
function formatJsonContent(content: string): string {
  try {
    const parsed = JSON.parse(content);
    return JSON.stringify(parsed, null, 2);
  } catch {
    return content; // Return as-is if not valid JSON
  }
}

// Helper to check if file has preview mode (HTML, Markdown, CSV, or JSON)
function hasPreviewMode(filename: string): boolean {
  return isHtmlFile(filename) || isMarkdownFile(filename) || isCsvFile(filename) || isJsonFile(filename);
}

export function FileViewer({
  filePath,
  content,
  error,
  isDirectory,
  projectId,
  apiBaseUrl,
  onContentChange,
  onDelete,
}: FileViewerProps) {
  const STORAGE_KEY = "fileViewer.preferPreview";

  // Initialize preview mode from localStorage (default to false/source)
  const getInitialPreviewMode = useCallback((path: string | null): boolean => {
    if (!path) return false;
    const filename = path.split("/").pop() || "";
    // Only use stored preference if file supports preview
    if (!hasPreviewMode(filename)) return false;
    try {
      return localStorage.getItem(STORAGE_KEY) === "true";
    } catch {
      return false;
    }
  }, []);

  const [previewMode, setPreviewMode] = useState(() => getInitialPreviewMode(filePath));
  const [isSaving, setIsSaving] = useState(false);
  const [showSaved, setShowSaved] = useState(false);
  const [localContent, setLocalContent] = useState<string | null>(null);
  const [savedContent, setSavedContent] = useState<string | null>(null); // Track last saved content
  const [autoSave, setAutoSave] = useState(true);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [loadingFile, setLoadingFile] = useState<string | null>(null);

  // Handle preview mode toggle - save to localStorage
  const handlePreviewModeChange = useCallback((isPreview: boolean) => {
    setPreviewMode(isPreview);
    try {
      localStorage.setItem(STORAGE_KEY, String(isPreview));
    } catch {
      // Ignore localStorage errors
    }
  }, []);

  // Track file path changes to show loading state
  useEffect(() => {
    if (filePath) {
      setLoadingFile(filePath);
      // Set preview mode based on localStorage preference (if file supports it)
      setPreviewMode(getInitialPreviewMode(filePath));
    }
    setLocalContent(null);
    setSavedContent(null);
  }, [filePath, getInitialPreviewMode]);

  // Clear loading state when content arrives for the current file
  useEffect(() => {
    if (content !== null && loadingFile === filePath) {
      setLoadingFile(null);
    }
  }, [content, filePath, loadingFile]);

  // Show loading if we're waiting for content for the selected file
  const isLoading = filePath !== null && (loadingFile === filePath || content === null);

  // Use local content if modified, otherwise use prop
  const displayContent = localContent ?? content;
  // Has changes if local content differs from both original prop and last saved content
  const hasChanges = localContent !== null && localContent !== content && localContent !== savedContent;

  const handleContentChange = useCallback((newContent: string) => {
    setLocalContent(newContent);
    setShowSaved(false);  // Hide "saved" when user starts editing
    onContentChange?.(newContent);
  }, [onContentChange]);

  const handleSave = useCallback(async (contentToSave: string) => {
    if (!filePath || !contentToSave || isSaving) {
      return;
    }

    setIsSaving(true);
    try {
      const res = await fetch(
        `${apiBaseUrl}projects/${projectId}/file/${filePath}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            "X-CSRFToken": getCsrfToken(),
          },
          body: JSON.stringify({ content: contentToSave }),
        }
      );

      if (!res.ok) throw new Error("Failed to save");

      // Track what we saved so hasChanges becomes false
      setSavedContent(contentToSave);

      // Show "saved" indicator briefly
      setShowSaved(true);
      setTimeout(() => setShowSaved(false), 2000);
    } catch (e) {
      console.error("Save error:", e);
      toast.error("Failed to save file");
    } finally {
      setIsSaving(false);
    }
  }, [filePath, projectId, apiBaseUrl, isSaving]);

  const handleCopy = useCallback(() => {
    if (displayContent) {
      navigator.clipboard.writeText(displayContent);
    }
  }, [displayContent]);

  const handleDownload = useCallback(() => {
    if (displayContent && filePath) {
      const filename = filePath.split("/").pop() || "file";
      const blob = new Blob([displayContent], { type: "text/plain" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      a.click();
      URL.revokeObjectURL(url);
    }
  }, [displayContent, filePath]);

  const handleDelete = useCallback(() => {
    if (filePath && onDelete) {
      setShowDeleteDialog(true);
    }
  }, [filePath, onDelete]);

  const confirmDelete = useCallback(() => {
    if (filePath && onDelete) {
      onDelete(filePath);
      setShowDeleteDialog(false);
    }
  }, [filePath, onDelete]);

  if (!filePath || isDirectory) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <ArtifactEmpty message="Select a file from the left panel to view its contents" />
      </div>
    );
  }

  // Normalize path separators for cross-platform compatibility
  const normalizedPath = filePath.replace(/\\/g, "/");
  const filename = normalizedPath.split("/").pop() || "";
  const isHtml = isHtmlFile(filename);
  const isMarkdown = isMarkdownFile(filename);
  const isCsv = isCsvFile(filename);
  const isJson = isJsonFile(filename);
  const isImage = isImageFile(filename);
  const isDocument = isDocumentFile(filename);
  const editorEntry = getEditorForFile(filename);
  const EditorComponent = editorEntry.component;

  // Build file URL for binary files (images, documents)
  // Use raw-file endpoint for proper binary download
  const fileUrl = (isImage || isDocument)
    ? `${apiBaseUrl}projects/${projectId}/raw-file/${normalizedPath}`
    : null;

  return (
    <Artifact className="h-full flex flex-col">
      <ArtifactHeader>
          <div className="flex items-center gap-2 min-w-0">
            <FileIcon className="h-4 w-4 shrink-0 text-muted-foreground" />
            <ArtifactTitle>{filename}</ArtifactTitle>
            {isSaving ? (
              <span className="text-xs text-blue-400">• saving...</span>
            ) : hasChanges ? (
              <span className="text-xs text-yellow-500">• modified</span>
            ) : showSaved ? (
              <span className="text-xs text-green-400 animate-fade-out">• saved</span>
            ) : null}
          </div>
          <ArtifactActions>
          {hasChanges && displayContent && (
            <ArtifactAction
              icon={Save}
              tooltip={isSaving ? "Saving..." : "Save changes"}
              onClick={() => handleSave(displayContent)}
            />
          )}
          {/* Preview/Code toggle for HTML, Markdown, CSV, JSON files */}
          {hasPreviewMode(filename) && (
            <ToggleGroup
              type="single"
              value={previewMode ? "preview" : "code"}
              onValueChange={(value) => {
                if (value) handlePreviewModeChange(value === "preview");
              }}
              size="sm"
            >
              <ToggleGroupItem value="code" aria-label="View Code">
                <Code2 className="h-4 w-4" />
              </ToggleGroupItem>
              <ToggleGroupItem value="preview" aria-label="Preview">
                <Eye className="h-4 w-4" />
              </ToggleGroupItem>
            </ToggleGroup>
          )}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-7 w-7">
                <MoreVertical className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <div className="flex items-center justify-between px-2 py-1.5">
                <span className="text-sm">Auto-save</span>
                <Switch
                  checked={autoSave}
                  onCheckedChange={setAutoSave}
                />
              </div>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleCopy}>
                <Copy className="h-4 w-4 mr-2" />
                Copy Content
              </DropdownMenuItem>
              <DropdownMenuItem onClick={handleDownload}>
                <Download className="h-4 w-4 mr-2" />
                Download
              </DropdownMenuItem>
              {onDelete && (
                <>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    className="text-destructive focus:text-destructive"
                    onClick={handleDelete}
                  >
                    <Trash2 className="h-4 w-4 mr-2" />
                    Delete
                  </DropdownMenuItem>
                </>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        </ArtifactActions>
      </ArtifactHeader>
      <ArtifactContent className="flex-1 min-h-0">
        {error ? (
          <ArtifactError message={error} />
        ) : isImage && fileUrl ? (
          // Use native img tag for images
          <div className="h-full w-full flex items-center justify-center bg-[#1a1a1a] overflow-auto p-4">
            <img
              src={fileUrl}
              alt={filename}
              className="max-w-full max-h-full object-contain"
              onError={(e) => {
                (e.target as HTMLImageElement).style.display = "none";
                console.error("Failed to load image:", fileUrl);
              }}
            />
          </div>
        ) : isDocument && fileUrl ? (
          // PDF and Office documents: show download option (like Notion)
          <div className="h-full w-full flex flex-col items-center justify-center bg-[#1a1a1a] gap-4 p-8">
            <FileText className="h-16 w-16 text-muted-foreground" />
            <div className="text-center">
              <h3 className="text-lg font-medium text-foreground mb-1">{getFileTypeName(filename)}</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Download to view this document
              </p>
              <a
                href={fileUrl}
                download={filename}
                className="inline-flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 transition-colors"
              >
                <Download className="h-4 w-4" />
                Download {filename}
              </a>
            </div>
          </div>
        ) : isLoading ? (
          <div className="p-4 text-muted-foreground">Loading...</div>
        ) : displayContent !== null ? (
          // Preview modes for specific file types
          isHtml && previewMode ? (
            <iframe
              srcDoc={displayContent}
              className="w-full h-full bg-white border-0"
              sandbox="allow-scripts allow-same-origin"
              title="HTML Preview"
            />
          ) : isMarkdown && previewMode ? (
            <div className="h-full overflow-auto p-4">
              <MarkdownViewer content={displayContent} />
            </div>
          ) : (isCsv || isJson) && previewMode ? (
            <div className="h-full overflow-hidden">
              <DataViewer content={displayContent} fileType={isCsv ? "csv" : "json"} className="h-full" fillHeight />
            </div>
          ) : (
            // Unified editor for all file types
            <Suspense fallback={<div className="p-4 text-muted-foreground">Loading editor...</div>}>
              <EditorComponent
                content={isJson ? formatJsonContent(displayContent) : displayContent}
                filename={filename}
                onChange={handleContentChange}
                onSave={handleSave}
                readOnly={false}
                autoSave={autoSave}
              />
            </Suspense>
          )
        ) : (
          <div className="p-4 text-muted-foreground">Loading...</div>
        )}
      </ArtifactContent>

      {/* Delete confirmation dialog */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete file?</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{filename}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Artifact>
  );
}
