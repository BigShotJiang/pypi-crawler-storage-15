import { useEffect, useState } from "react";
import { useCreateBlockNote } from "@blocknote/react";
import { BlockNoteView } from "@blocknote/mantine";
import "@blocknote/mantine/style.css";

interface MarkdownViewerProps {
  content: string;
}

/**
 * MarkdownViewer renders markdown content using BlockNote in read-only mode.
 * It converts markdown to BlockNote blocks and displays them with proper formatting.
 */
export function MarkdownViewer({ content }: MarkdownViewerProps) {
  const [isLoading, setIsLoading] = useState(true);

  // Create editor instance - will be used for markdown parsing and display
  const editor = useCreateBlockNote();

  // Parse markdown to blocks when content changes
  useEffect(() => {
    let cancelled = false;

    async function parseMarkdown() {
      setIsLoading(true);
      try {
        // Use BlockNote's markdown parser
        const parsedBlocks = await editor.tryParseMarkdownToBlocks(content);
        if (!cancelled) {
          // Replace editor content with parsed blocks
          editor.replaceBlocks(editor.document, parsedBlocks);
        }
      } catch (error) {
        console.error("Failed to parse markdown:", error);
        // Fallback: insert raw content - let BlockNote handle it
        if (!cancelled) {
          editor.insertBlocks(
            [{ type: "paragraph", content: content }],
            editor.document[0],
            "before"
          );
        }
      } finally {
        if (!cancelled) {
          setIsLoading(false);
        }
      }
    }

    parseMarkdown();

    return () => {
      cancelled = true;
    };
  }, [content, editor]);

  if (isLoading) {
    return (
      <div className="p-4 text-muted-foreground">
        Loading preview...
      </div>
    );
  }

  return (
    <div className="bn-viewer h-full">
      <BlockNoteView
        editor={editor}
        editable={false}
        theme="dark"
        sideMenu={false}
      />
    </div>
  );
}

