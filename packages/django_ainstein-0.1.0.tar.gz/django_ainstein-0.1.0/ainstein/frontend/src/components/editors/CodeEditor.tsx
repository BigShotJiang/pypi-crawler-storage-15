import { useCallback, useEffect, useRef } from "react";
import CodeMirror, { ReactCodeMirrorRef } from "@uiw/react-codemirror";
import { javascript } from "@codemirror/lang-javascript";
import { python } from "@codemirror/lang-python";
import { html } from "@codemirror/lang-html";
import { css } from "@codemirror/lang-css";
import { json } from "@codemirror/lang-json";
import { markdown } from "@codemirror/lang-markdown";
import { sql } from "@codemirror/lang-sql";
import { xml } from "@codemirror/lang-xml";
import { yaml } from "@codemirror/lang-yaml";
import { EditorView } from "@codemirror/view";
import { Extension } from "@codemirror/state";
import { indentUnit } from "@codemirror/language";
import { syntaxHighlighting, HighlightStyle } from "@codemirror/language";
import { tags } from "@lezer/highlight";

// Detect indentation from file content
function detectIndent(content: string): string {
  const lines = content.split("\n");
  for (const line of lines) {
    const match = line.match(/^(\s+)\S/);
    if (match) {
      const indent = match[1];
      // Return tabs immediately
      if (indent.startsWith("\t")) {
        return "\t";
      }
      // Skip single space (often JSDoc/comment artifacts like " * ")
      // Look for 2+ spaces which indicates actual code indentation
      if (indent.length >= 2) {
        return indent;
      }
    }
  }
  return "    "; // Default to 4 spaces
}

// Map file extensions to CodeMirror language extensions
const LANGUAGE_EXTENSIONS: Record<string, () => Extension> = {
  // JavaScript/TypeScript
  js: javascript,
  jsx: () => javascript({ jsx: true }),
  ts: () => javascript({ typescript: true }),
  tsx: () => javascript({ jsx: true, typescript: true }),
  mjs: javascript,
  cjs: javascript,
  // Web
  html: html,
  htm: html,
  css: css,
  scss: css,
  sass: css,
  less: css,
  // Data
  json: json,
  yaml: yaml,
  yml: yaml,
  xml: xml,
  toml: yaml, // Close enough
  // Python
  py: python,
  pyw: python,
  pyi: python,
  // SQL
  sql: sql,
  // Markdown
  md: markdown,
  markdown: markdown,
  // Shell (use basic - no dedicated extension)
  sh: () => [],
  bash: () => [],
  zsh: () => [],
};

function getLanguageExtension(filename: string): Extension {
  const ext = filename.split(".").pop()?.toLowerCase() || "";
  const langFn = LANGUAGE_EXTENSIONS[ext];
  if (langFn) {
    return langFn();
  }
  return []; // No language extension for unknown types
}

// WhatsApp Dark Theme
const darkTheme = EditorView.theme({
  "&": {
    backgroundColor: "#0b141a", // --background
    height: "100%",
  },
  ".cm-content": {
    fontFamily: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace",
    fontSize: "13px",
    padding: "16px 0",
    caretColor: "#e9edef",
  },
  ".cm-line": {
    padding: "0 16px",
  },
  ".cm-gutters": {
    backgroundColor: "#111b21", // --card (sidebar background)
    borderRight: "1px solid #2a3942",
    color: "#8696a0", // --muted-foreground
  },
  ".cm-lineNumbers .cm-gutterElement": {
    padding: "0 8px 0 12px",
  },
  ".cm-activeLineGutter": {
    backgroundColor: "#202c33", // --secondary
    color: "#e9edef",
  },
  ".cm-activeLine": {
    backgroundColor: "#202c33", // --secondary
  },
  ".cm-selectionBackground": {
    backgroundColor: "rgba(0, 168, 132, 0.25) !important", // --accent with transparency
  },
  "&.cm-focused .cm-selectionBackground": {
    backgroundColor: "rgba(0, 168, 132, 0.35) !important",
  },
  ".cm-cursor": {
    borderLeftColor: "#e9edef", // --foreground
    borderLeftWidth: "2px",
  },
  ".cm-matchingBracket": {
    backgroundColor: "rgba(0, 168, 132, 0.3)",
    outline: "1px solid #00a884",
  },
  ".cm-searchMatch": {
    backgroundColor: "rgba(255, 193, 7, 0.3)",
    borderRadius: "2px",
  },
  ".cm-searchMatch.cm-searchMatch-selected": {
    backgroundColor: "rgba(255, 193, 7, 0.5)",
  },
  // Fold gutter
  ".cm-foldGutter": {
    width: "12px",
  },
  ".cm-foldGutter .cm-gutterElement": {
    color: "#8696a0",
  },
  // Scrollbar styling
  ".cm-scroller": {
    overflow: "auto",
  },
  ".cm-scroller::-webkit-scrollbar": {
    width: "6px",
    height: "6px",
  },
  ".cm-scroller::-webkit-scrollbar-track": {
    background: "#24292e",
  },
  ".cm-scroller::-webkit-scrollbar-thumb": {
    backgroundColor: "rgba(128, 134, 139, 0.4)",
    borderRadius: "3px",
  },
  ".cm-scroller::-webkit-scrollbar-thumb:hover": {
    backgroundColor: "rgba(128, 134, 139, 0.6)",
  },
  // Tooltip styling
  ".cm-tooltip": {
    backgroundColor: "#202c33",
    border: "1px solid #2a3942",
    borderRadius: "6px",
  },
  ".cm-tooltip-autocomplete": {
    "& > ul > li": {
      padding: "4px 8px",
    },
    "& > ul > li[aria-selected]": {
      backgroundColor: "#00a884",
      color: "#e9edef",
    },
  },
}, { dark: true });

// Complete syntax highlighting theme
const customHighlightStyle = HighlightStyle.define([
  // Variables, parameters, properties - WHITE
  { tag: tags.variableName, color: "#e9edef" },
  { tag: tags.definition(tags.variableName), color: "#e9edef" },
  { tag: tags.local(tags.variableName), color: "#e9edef" },
  { tag: tags.propertyName, color: "#e9edef" },
  { tag: tags.attributeName, color: "#e9edef" },
  // Keywords - purple
  { tag: tags.keyword, color: "#c792ea" },
  { tag: tags.controlKeyword, color: "#c792ea" },
  { tag: tags.definitionKeyword, color: "#c792ea" },
  { tag: tags.moduleKeyword, color: "#c792ea" },
  { tag: tags.operatorKeyword, color: "#c792ea" },
  // Functions - blue
  { tag: tags.function(tags.variableName), color: "#82aaff" },
  { tag: tags.function(tags.propertyName), color: "#82aaff" },
  // Strings - green
  { tag: tags.string, color: "#c3e88d" },
  { tag: tags.special(tags.string), color: "#c3e88d" },
  // Numbers - orange
  { tag: tags.number, color: "#f78c6c" },
  { tag: tags.integer, color: "#f78c6c" },
  { tag: tags.float, color: "#f78c6c" },
  // Comments - gray
  { tag: tags.comment, color: "#637777" },
  { tag: tags.lineComment, color: "#637777" },
  { tag: tags.blockComment, color: "#637777" },
  { tag: tags.docComment, color: "#637777" },
  // Types/classes - yellow
  { tag: tags.typeName, color: "#ffcb6b" },
  { tag: tags.className, color: "#ffcb6b" },
  { tag: tags.namespace, color: "#ffcb6b" },
  // Operators and punctuation - cyan
  { tag: tags.operator, color: "#89ddff" },
  { tag: tags.punctuation, color: "#89ddff" },
  { tag: tags.bracket, color: "#89ddff" },
  { tag: tags.angleBracket, color: "#89ddff" },
  { tag: tags.squareBracket, color: "#89ddff" },
  { tag: tags.paren, color: "#89ddff" },
  { tag: tags.brace, color: "#89ddff" },
  // Boolean, null, self - coral/orange
  { tag: tags.bool, color: "#f78c6c" },
  { tag: tags.null, color: "#f78c6c" },
  { tag: tags.self, color: "#f07178" },
  // Atoms/constants
  { tag: tags.atom, color: "#f78c6c" },
  { tag: tags.constant(tags.variableName), color: "#f78c6c" },
  // Regex
  { tag: tags.regexp, color: "#89ddff" },
  // Meta/annotations
  { tag: tags.meta, color: "#ffcb6b" },
  { tag: tags.annotation, color: "#ffcb6b" },
]);
const customHighlighting = syntaxHighlighting(customHighlightStyle);

interface CodeEditorProps {
  content: string;
  filename: string;
  onChange?: (content: string) => void;
  onSave?: (content: string) => void;
  readOnly?: boolean;
  autoSave?: boolean;
  autoSaveDelay?: number;
  className?: string;
}

export function CodeEditor({
  content,
  filename,
  onChange,
  onSave,
  readOnly = false,
  autoSave = true,
  autoSaveDelay = 1000,
  className,
}: CodeEditorProps) {
  const editorRef = useRef<ReactCodeMirrorRef>(null);
  const autoSaveTimerRef = useRef<NodeJS.Timeout | null>(null);
  const lastSavedContentRef = useRef<string>(content);

  // Clear auto-save timer on unmount
  useEffect(() => {
    return () => {
      if (autoSaveTimerRef.current) {
        clearTimeout(autoSaveTimerRef.current);
      }
    };
  }, []);

  // Reset saved content reference when filename changes (new file loaded)
  useEffect(() => {
    lastSavedContentRef.current = content;
  }, [filename]); // Only reset on file change, not content change

  const handleChange = useCallback(
    (value: string) => {
      onChange?.(value);

      // Auto-save logic
      if (autoSave && onSave && !readOnly) {
        // Clear existing timer
        if (autoSaveTimerRef.current) {
          clearTimeout(autoSaveTimerRef.current);
        }

        // Set new timer
        autoSaveTimerRef.current = setTimeout(() => {
          // Only save if content actually changed from last save
          if (value !== lastSavedContentRef.current) {
            onSave(value);
            lastSavedContentRef.current = value;
          }
        }, autoSaveDelay);
      }
    },
    [onChange, onSave, autoSave, autoSaveDelay, readOnly]
  );

  // Ctrl+S / Cmd+S handler
  const handleKeyDown = useCallback(
    (event: KeyboardEvent) => {
      if ((event.ctrlKey || event.metaKey) && event.key === "s") {
        event.preventDefault();
        if (onSave && !readOnly) {
          const currentContent = editorRef.current?.view?.state.doc.toString() || content;
          onSave(currentContent);
          lastSavedContentRef.current = currentContent;
        }
      }
    },
    [onSave, readOnly, content]
  );

  // Add keyboard listener
  useEffect(() => {
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [handleKeyDown]);

  const languageExtension = getLanguageExtension(filename);

  return (
    <div className={`h-full w-full bg-[#0b141a] ${className || ""}`}>
      <CodeMirror
        ref={editorRef}
        value={content}
        onChange={handleChange}
        theme="none"
        extensions={[
          languageExtension,
          darkTheme,
          customHighlighting,
          indentUnit.of(detectIndent(content)),
        ]}
        readOnly={readOnly}
        basicSetup={{
          lineNumbers: true,
          highlightActiveLineGutter: true,
          highlightActiveLine: true,
          foldGutter: true,
          dropCursor: true,
          allowMultipleSelections: true,
          indentOnInput: true,
          bracketMatching: true,
          closeBrackets: true,
          autocompletion: true,
          rectangularSelection: true,
          crosshairCursor: false,
          highlightSelectionMatches: true,
          searchKeymap: true,
        }}
        height="100%"
        style={{ height: "100%" }}
      />
    </div>
  );
}
