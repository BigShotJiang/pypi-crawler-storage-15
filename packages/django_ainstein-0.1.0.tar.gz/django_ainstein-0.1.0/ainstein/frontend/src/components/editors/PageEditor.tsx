import { useEffect, useRef, useCallback } from "react";
import { useCreateBlockNote, SideMenu, SideMenuController, DragHandleMenu, RemoveBlockItem, BlockColorsItem, useBlockNoteEditor, useComponentsContext } from "@blocknote/react";
import type { DragHandleMenuProps } from "@blocknote/react";
import { BlockNoteView } from "@blocknote/mantine";
import { Block, BlockNoteSchema, defaultBlockSpecs } from "@blocknote/core";
import { Plugin, PluginKey } from "prosemirror-state";
import { Decoration, DecorationSet } from "prosemirror-view";
import "@blocknote/mantine/style.css";

// Custom "Turn Into" menu item component following BlockNote docs pattern
function TurnIntoItem({
  block,
  type,
  typeProps,
  children
}: {
  block: DragHandleMenuProps["block"];
  type: string;
  typeProps?: Record<string, any>;
  children: React.ReactNode;
}) {
  const editor = useBlockNoteEditor();
  const Components = useComponentsContext()!;

  return (
    <Components.Generic.Menu.Item
      onClick={() => editor.updateBlock(block, { type: type as any, props: typeProps })}
    >
      {children}
    </Components.Generic.Menu.Item>
  );
}

// Menu divider component
function MenuDivider() {
  const Components = useComponentsContext()!;
  return <Components.Generic.Menu.Divider />;
}

// Menu label component
function MenuLabel({ children }: { children: React.ReactNode }) {
  const Components = useComponentsContext()!;
  return <Components.Generic.Menu.Label>{children}</Components.Generic.Menu.Label>;
}

// Custom drag handle menu with "Turn into" options
// Defined outside component to avoid rendering issues per BlockNote docs
const CustomDragHandleMenu = (props: DragHandleMenuProps) => (
  <DragHandleMenu {...props}>
    <RemoveBlockItem {...props}>Delete</RemoveBlockItem>
    <BlockColorsItem {...props}>Colors</BlockColorsItem>
    <MenuDivider />
    <MenuLabel>Turn into</MenuLabel>
    <TurnIntoItem block={props.block} type="paragraph">Text</TurnIntoItem>
    <TurnIntoItem block={props.block} type="heading" typeProps={{ level: 1 }}>Heading 1</TurnIntoItem>
    <TurnIntoItem block={props.block} type="heading" typeProps={{ level: 2 }}>Heading 2</TurnIntoItem>
    <TurnIntoItem block={props.block} type="heading" typeProps={{ level: 3 }}>Heading 3</TurnIntoItem>
    <MenuDivider />
    <TurnIntoItem block={props.block} type="bulletListItem">Bullet List</TurnIntoItem>
    <TurnIntoItem block={props.block} type="numberedListItem">Numbered List</TurnIntoItem>
    <TurnIntoItem block={props.block} type="checkListItem">Check List</TurnIntoItem>
    <MenuDivider />
    <TurnIntoItem block={props.block} type="codeBlock">Code</TurnIntoItem>
    <TurnIntoItem block={props.block} type="quote">Quote</TurnIntoItem>
  </DragHandleMenu>
);

// Create schema with all default blocks
const schema = BlockNoteSchema.create({
  blockSpecs: {
    ...defaultBlockSpecs,
  },
});

// Plugin key for cursor line highlight
const cursorLinePluginKey = new PluginKey("cursorLineHighlight");

// Create a ProseMirror plugin that highlights the current line/block
function createCursorLinePlugin() {
  return new Plugin({
    key: cursorLinePluginKey,
    state: {
      init() {
        return { hasFocus: false };
      },
      apply(tr, value) {
        const focusMeta = tr.getMeta("focus");
        const blurMeta = tr.getMeta("blur");
        if (focusMeta) return { hasFocus: true };
        if (blurMeta) return { hasFocus: false };
        return value;
      },
    },
    props: {
      handleDOMEvents: {
        focus(view) {
          const tr = view.state.tr.setMeta("focus", true);
          view.dispatch(tr);
          return false;
        },
        blur(view) {
          const tr = view.state.tr.setMeta("blur", true);
          view.dispatch(tr);
          return false;
        },
      },
      decorations(state) {
        const pluginState = cursorLinePluginKey.getState(state);
        if (!pluginState?.hasFocus) {
          return DecorationSet.empty;
        }

        const { selection, doc } = state;
        const { $from } = selection;

        // Find the block node containing the cursor
        // Walk up from the cursor position to find the nearest block
        let depth = $from.depth;
        while (depth > 0) {
          const node = $from.node(depth);
          // Check if this is a block-level node (paragraph, heading, etc.)
          if (node.isBlock) {
            const start = $from.before(depth);
            const end = $from.after(depth);

            return DecorationSet.create(doc, [
              Decoration.node(start, end, {
                class: "cursor-line-highlight",
              }),
            ]);
          }
          depth--;
        }

        return DecorationSet.empty;
      },
    },
  });
}

interface PageEditorProps {
  initialContent: Block[];
  onChange?: (blocks: Block[]) => void;
  onSave?: (blocks: Block[]) => Promise<void>;
  readOnly?: boolean;
  autoSave?: boolean;
  autoSaveMs?: number;
}

export function PageEditor({
  initialContent,
  onChange,
  onSave,
  readOnly = false,
  autoSave = true,
  autoSaveMs = 500,
}: PageEditorProps) {
  const saveTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const pendingBlocksRef = useRef<Block[] | null>(null);
  const pluginAddedRef = useRef(false);

  // Create editor with initial content and schema
  // Disable emoji picker to reduce bundle size (~549KB saved)
  // Enable advanced table features
  const editor = useCreateBlockNote({
    schema,
    initialContent: initialContent.length > 0 ? initialContent : undefined,
    emojiPicker: false,
    tables: {
      splitCells: true,
      cellBackgroundColor: true,
      cellTextColor: true,
      headers: true,
    },
  });

  // Add cursor line highlight plugin to the underlying ProseMirror editor
  useEffect(() => {
    if (pluginAddedRef.current) return;

    // Access the underlying Tiptap/ProseMirror editor
    const pmEditor = editor._tiptapEditor;
    if (pmEditor) {
      // Register the plugin
      pmEditor.registerPlugin(createCursorLinePlugin());
      pluginAddedRef.current = true;
    }

    return () => {
      // Cleanup: unregister plugin if needed
      if (pluginAddedRef.current && editor._tiptapEditor) {
        try {
          editor._tiptapEditor.unregisterPlugin(cursorLinePluginKey);
        } catch {
          // Plugin might already be unregistered
        }
      }
    };
  }, [editor]);

  // Debounced save function - simple approach: capture blocks, save after delay
  const debouncedSave = useCallback(
    (blocks: Block[]) => {
      if (!onSave || !autoSave) {
        return;
      }

      // Store blocks to save (make a copy to avoid mutation issues)
      pendingBlocksRef.current = JSON.parse(JSON.stringify(blocks));

      // Clear existing timeout
      if (saveTimeoutRef.current) {
        clearTimeout(saveTimeoutRef.current);
      }

      // Set new timeout
      saveTimeoutRef.current = setTimeout(async () => {
        const blocksToSave = pendingBlocksRef.current;
        if (blocksToSave) {
          await onSave(blocksToSave);
        }
      }, autoSaveMs);
    },
    [onSave, autoSave, autoSaveMs]
  );

  // Handle content changes
  const handleChange = useCallback(() => {
    const blocks = editor.document;
    onChange?.(blocks);
    debouncedSave(blocks);
  }, [editor, onChange, debouncedSave]);

  // Cleanup timeout on unmount
  useEffect(() => {
    return () => {
      if (saveTimeoutRef.current) {
        clearTimeout(saveTimeoutRef.current);
      }
    };
  }, []);

  return (
    <div className="bn-viewer h-full flex flex-col pl-12">
      {/* BlockNote editor */}
      <div className="flex-1 min-h-0 overflow-auto">
        <BlockNoteView
          editor={editor}
          editable={!readOnly}
          onChange={handleChange}
          theme="dark"
          sideMenu={false}
        >
          <SideMenuController
            sideMenu={(props) => (
              <SideMenu {...props} dragHandleMenu={CustomDragHandleMenu} />
            )}
          />
        </BlockNoteView>
      </div>
    </div>
  );
}

