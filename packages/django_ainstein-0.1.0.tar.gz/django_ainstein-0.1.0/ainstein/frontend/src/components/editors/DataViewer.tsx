/**
 * DataViewer Component
 *
 * Renders CSV or JSON content as a sortable, paginated DataTable.
 * Used in FileViewer for preview mode of data files.
 *
 * USAGE:
 * - In FileViewer (full height): <DataViewer ... fillHeight />
 * - Standalone (content-sized): <DataViewer ... />
 *
 * The fillHeight prop is passed through to DataTable.
 * See data-table.tsx for layout mode documentation.
 */

import { useMemo } from "react";
import { DataTable } from "@/components/ui/data-table";

interface DataViewerProps {
  content: string;
  fileType: "csv" | "json";
  className?: string;
  /**
   * When true, fills parent height with sticky header.
   * Pass this when used in FileViewer or other full-height contexts.
   * @default false
   */
  fillHeight?: boolean;
}

export function DataViewer({ content, fileType, className, fillHeight }: DataViewerProps) {
  const { data, error } = useMemo(() => {
    if (fileType === "csv") {
      return { data: parseCSV(content), error: null };
    }
    if (fileType === "json") {
      return parseJSON(content);
    }
    return { data: null, error: "Unsupported file type" };
  }, [content, fileType]);

  if (error) {
    return (
      <div className="p-4 text-destructive">
        <p className="font-medium">Failed to parse {fileType.toUpperCase()}</p>
        <p className="text-sm text-muted-foreground mt-1">{error}</p>
      </div>
    );
  }

  if (!data || data.length === 0) {
    return (
      <div className="p-4 text-muted-foreground">
        No data to display
      </div>
    );
  }

  return (
    <div className="h-full" style={{ backgroundColor: "#24292e" }}>
      <DataTable data={data} className={className} fillHeight={fillHeight} />
    </div>
  );
}

/**
 * Parse CSV content into array of objects.
 * Uses first row as headers.
 */
function parseCSV(content: string): Record<string, unknown>[] | null {
  try {
    const lines = content.trim().split("\n");
    if (lines.length < 1) return null;

    // Parse header row
    const headers = parseCSVRow(lines[0]);
    if (!headers || headers.length === 0) return null;

    // If only header row, return empty array
    if (lines.length === 1) return [];

    // Parse data rows
    const rows: Record<string, unknown>[] = [];
    for (let i = 1; i < lines.length; i++) {
      const values = parseCSVRow(lines[i]);
      if (!values) continue;

      const row: Record<string, unknown> = {};
      headers.forEach((header, idx) => {
        row[header] = values[idx] ?? null;
      });
      rows.push(row);
    }

    return rows;
  } catch {
    return null;
  }
}

/**
 * Parse a single CSV row, handling quoted values.
 */
function parseCSVRow(line: string): string[] | null {
  if (!line.trim()) return null;

  const result: string[] = [];
  let current = "";
  let inQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    const nextChar = line[i + 1];

    if (inQuotes) {
      if (char === '"' && nextChar === '"') {
        // Escaped quote
        current += '"';
        i++;
      } else if (char === '"') {
        // End of quoted field
        inQuotes = false;
      } else {
        current += char;
      }
    } else {
      if (char === '"') {
        inQuotes = true;
      } else if (char === ",") {
        result.push(current.trim());
        current = "";
      } else {
        current += char;
      }
    }
  }

  result.push(current.trim());
  return result;
}

/**
 * Parse JSON content into array of objects for DataTable.
 * Handles arrays and single objects.
 */
function parseJSON(content: string): { data: Record<string, unknown>[] | null; error: string | null } {
  try {
    const parsed = JSON.parse(content);

    // Array of objects
    if (Array.isArray(parsed)) {
      if (parsed.length === 0) return { data: [], error: null };
      if (typeof parsed[0] === "object" && parsed[0] !== null) {
        return { data: parsed, error: null };
      }
      // Array of primitives - wrap each in an object
      return {
        data: parsed.map((value, index) => ({ index, value })),
        error: null,
      };
    }

    // Single object - wrap in array
    if (typeof parsed === "object" && parsed !== null) {
      return { data: [parsed], error: null };
    }

    // Primitive value
    return { data: [{ value: parsed }], error: null };
  } catch (e) {
    return { data: null, error: e instanceof Error ? e.message : "Invalid JSON" };
  }
}
