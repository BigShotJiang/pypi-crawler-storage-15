import { ComponentType, useState, useEffect } from "react";
import { Block } from "@blocknote/core";

// Editor component props interface
export interface EditorProps {
  content: string;
  filename: string;
  onChange?: (content: string) => void;
  onSave?: (content: string) => Promise<void>;
  readOnly?: boolean;
  autoSave?: boolean;
}

// Registry entry type
interface EditorRegistryEntry {
  component: ComponentType<EditorProps>;
  label: string;
  icon?: string;
}

// Lazy-loaded CodeEditor wrapper (default for all code files)
function CodeEditorWrapper({ content, filename, onChange, onSave, readOnly, autoSave = true }: EditorProps) {
  const [module, setModule] = useState<{
    CodeEditor: ComponentType<any>;
  } | null>(null);

  useEffect(() => {
    import("./CodeEditor").then((m) => {
      setModule({ CodeEditor: m.CodeEditor });
    });
  }, []);

  if (!module) {
    return <div className="p-4 text-muted-foreground">Loading editor...</div>;
  }

  const { CodeEditor } = module;

  return (
    <CodeEditor
      content={content}
      filename={filename}
      onChange={onChange}
      onSave={onSave}
      readOnly={readOnly}
      autoSave={autoSave}
      className="h-full"
    />
  );
}

// Parse page content - pure BlockNote blocks array
function parsePageBlocks(content: string): Block[] {
  if (!content || !content.trim()) {
    return [];
  }

  try {
    const parsed = JSON.parse(content);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

// Serialize blocks to pure array format
function serializePageBlocks(blocks: Block[]): string {
  return JSON.stringify(blocks, null, 2);
}

// Lazy-loaded PageEditor wrapper
function PageEditorWrapper(props: EditorProps) {
  const { content, filename, onChange, onSave, readOnly, autoSave = true } = props;
  const [module, setModule] = useState<{
    PageEditor: ComponentType<any>;
  } | null>(null);

  // Track initial content for this file session
  const [initialContent, setInitialContent] = useState(() => parsePageBlocks(content));

  useEffect(() => {
    import("./PageEditor").then((m) => {
      setModule({ PageEditor: m.PageEditor });
    });
  }, []);

  // Only reset editor when filename changes (new file loaded)
  useEffect(() => {
    setInitialContent(parsePageBlocks(content));
  }, [filename]);

  if (!module) {
    return <div className="p-4 text-muted-foreground">Loading editor...</div>;
  }

  const { PageEditor } = module;

  const handleChange = (newBlocks: Block[]) => {
    const serialized = serializePageBlocks(newBlocks);
    onChange?.(serialized);
  };

  const handleSave = async (newBlocks: Block[]) => {
    if (onSave) {
      const serialized = serializePageBlocks(newBlocks);
      await onSave(serialized);
    }
  };

  return (
    <PageEditor
      key={filename}
      initialContent={initialContent}
      onChange={handleChange}
      onSave={handleSave}
      readOnly={readOnly}
      autoSave={autoSave}
    />
  );
}

// File Editor Registry - maps extensions to editor components
const editorRegistry: Record<string, EditorRegistryEntry> = {
  ".page": {
    component: PageEditorWrapper,
    label: "Page Editor",
    icon: "file-text",
  },
};

// Get the extension from a filename
export function getFileExtension(filename: string): string {
  const lastDot = filename.lastIndexOf(".");
  if (lastDot === -1) return "";
  return filename.slice(lastDot).toLowerCase();
}

// Get editor component for a file
export function getEditorForFile(filename: string): EditorRegistryEntry {
  const ext = getFileExtension(filename);
  return editorRegistry[ext] || {
    component: CodeEditorWrapper,
    label: "Code Editor",
    icon: "file-code",
  };
}

// Check if a file has a specialized editor
export function hasSpecializedEditor(filename: string): boolean {
  const ext = getFileExtension(filename);
  return ext in editorRegistry;
}

// Export for use in file viewers
export { editorRegistry };
