/**
 * BreadcrumbNav Component
 *
 * Breadcrumb navigation with dropdowns for switching projects and conversations.
 * Format: My/Shared > Project Name ▼ > Conversation Title ▼
 */

import { useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { ChevronRight, ChevronDown } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import type { ProjectData, ConversationData } from "@/types";

interface Project {
  id: number;
  name: string;
  is_shared: boolean;
}

interface Conversation {
  id: number;
  title: string;
}

interface BreadcrumbNavProps {
  project: ProjectData | null;
  conversation: ConversationData | null;
  apiBaseUrl: string;
  isShared?: boolean;
}

export function BreadcrumbNav({
  project,
  conversation,
  apiBaseUrl,
  isShared = false,
}: BreadcrumbNavProps) {
  const navigate = useNavigate();
  const [projects, setProjects] = useState<Project[]>([]);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [projectsLoading, setProjectsLoading] = useState(false);
  const [conversationsLoading, setConversationsLoading] = useState(false);

  const fetchProjects = useCallback(async () => {
    if (projectsLoading) return;
    setProjectsLoading(true);
    try {
      const shared = isShared ? "true" : "false";
      const res = await fetch(`${apiBaseUrl}projects/?is_shared=${shared}`);
      const data = await res.json();
      // API returns array directly (DisablePagination)
      setProjects(Array.isArray(data) ? data : []);
    } catch (e) {
      console.error("Failed to fetch projects:", e);
    } finally {
      setProjectsLoading(false);
    }
  }, [apiBaseUrl, isShared, projectsLoading]);

  const fetchConversations = useCallback(async () => {
    if (!project?.id || conversationsLoading) return;
    setConversationsLoading(true);
    try {
      const res = await fetch(`${apiBaseUrl}conversations/?project_id=${project.id}`);
      const data = await res.json();
      // API returns {conversations: [...]}
      setConversations(Array.isArray(data.conversations) ? data.conversations : []);
    } catch (e) {
      console.error("Failed to fetch conversations:", e);
    } finally {
      setConversationsLoading(false);
    }
  }, [apiBaseUrl, project?.id, conversationsLoading]);

  const handleProjectClick = (projectId: number) => {
    navigate(`/?project=${projectId}`);
  };

  const handleConversationClick = (conversationId: number) => {
    navigate(`/c/${conversationId}`);
  };

  return (
    <nav className="flex items-center gap-1.5 flex-1 min-w-0 text-sm">
      {/* My/Shared label */}
      <span className="text-muted-foreground shrink-0">
        {isShared ? "Shared" : "My"}
      </span>
      <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0" />

      {/* Project dropdown */}
      <DropdownMenu onOpenChange={(open) => open && fetchProjects()}>
        <DropdownMenuTrigger className="flex items-center gap-1 text-muted-foreground hover:text-foreground transition-colors max-w-[150px] cursor-pointer">
          <span className="truncate">{project?.name || "Select Project"}</span>
          <ChevronDown className="h-3 w-3 shrink-0" />
        </DropdownMenuTrigger>
        <DropdownMenuContent align="start" className="max-h-[300px] overflow-y-auto">
          {projectsLoading ? (
            <DropdownMenuItem disabled>Loading...</DropdownMenuItem>
          ) : projects.length === 0 ? (
            <DropdownMenuItem disabled>No projects</DropdownMenuItem>
          ) : (
            projects.map((p) => (
              <DropdownMenuItem
                key={p.id}
                onClick={() => handleProjectClick(p.id)}
                className={p.id === project?.id ? "bg-accent" : ""}
              >
                {p.name}
              </DropdownMenuItem>
            ))
          )}
        </DropdownMenuContent>
      </DropdownMenu>
      <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0" />

      {/* Conversation dropdown */}
      <DropdownMenu onOpenChange={(open) => open && fetchConversations()}>
        <DropdownMenuTrigger className="flex items-center gap-1 text-foreground font-medium max-w-[200px] cursor-pointer">
          <span className="truncate">{conversation?.title || "New Conversation"}</span>
          <ChevronDown className="h-3 w-3 shrink-0" />
        </DropdownMenuTrigger>
        <DropdownMenuContent align="start" className="max-h-[300px] overflow-y-auto">
          {conversationsLoading ? (
            <DropdownMenuItem disabled>Loading...</DropdownMenuItem>
          ) : conversations.length === 0 ? (
            <DropdownMenuItem disabled>No conversations</DropdownMenuItem>
          ) : (
            conversations.map((c) => (
              <DropdownMenuItem
                key={c.id}
                onClick={() => handleConversationClick(c.id)}
                className={c.id === conversation?.id ? "bg-accent" : ""}
              >
                {c.title || "Untitled"}
              </DropdownMenuItem>
            ))
          )}
        </DropdownMenuContent>
      </DropdownMenu>
    </nav>
  );
}
