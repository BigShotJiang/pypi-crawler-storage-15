/**
 * Test utilities for React component testing
 */

import { render, type RenderOptions } from '@testing-library/react';
import { type ReactElement, type ReactNode } from 'react';
import { BrowserRouter } from 'react-router-dom';

/**
 * Custom render that wraps components with necessary providers
 */
function customRender(
  ui: ReactElement,
  options?: Omit<RenderOptions, 'wrapper'>
) {
  const Wrapper = ({ children }: { children: ReactNode }) => (
    <BrowserRouter>{children}</BrowserRouter>
  );

  return render(ui, { wrapper: Wrapper, ...options });
}

// Re-export everything from testing-library
export * from '@testing-library/react';
export { default as userEvent } from '@testing-library/user-event';

// Override render with custom render
export { customRender as render };

/**
 * Helper to create mock tool events for testing
 */
export function createMockToolEvent(overrides: Record<string, unknown> = {}) {
  return {
    id: Date.now(),
    tool: 'test_tool',
    args: '{}',
    result: null,
    ...overrides,
  };
}

/**
 * Helper to create mock streaming tool events
 */
export function createMockStreamingToolEvent(overrides: Record<string, unknown> = {}) {
  return {
    id: Date.now(),
    tool: 'test_tool',
    args: '{}',
    input: {},
    result: null,
    stats: undefined,
    data_preview: undefined,
    denied: false,
    awaitingApproval: false,
    ...overrides,
  };
}

/**
 * Helper to wait for async state updates
 */
export async function waitForStateUpdate() {
  await new Promise(resolve => setTimeout(resolve, 0));
}
