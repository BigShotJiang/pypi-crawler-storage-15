"""Argument parsing and fixing utilities for tool parameters."""

import json


def fix_dict_arg(val) -> dict:
    """
    Convert various input formats to a dict.

    Handles:
    - None, "none", "null" -> {}
    - JSON string -> parsed dict
    - Already a dict -> return as-is
    """
    if not val or val == "none" or val == "null":
        return {}
    if isinstance(val, str):
        try:
            parsed = json.loads(val)
            return parsed if isinstance(parsed, dict) else {}
        except json.JSONDecodeError:
            return {}
    return val if isinstance(val, dict) else {}


def fix_list_arg(val) -> list:
    """
    Convert various input formats to a list.

    Handles:
    - None, empty -> []
    - Comma-separated string -> split list
    - JSON array string -> parsed list
    - Single string -> [string]
    - Already a list -> return as-is (with nested parsing if needed)
    """
    if not val:
        return []
    if isinstance(val, str):
        if "," in val and not val.startswith("["):
            return [x.strip() for x in val.split(",")]
        if val.startswith("["):
            try:
                return json.loads(val)
            except json.JSONDecodeError:
                pass
        return [val]
    if isinstance(val, list) and len(val) == 1 and isinstance(val[0], str):
        if "," in val[0] and not val[0].startswith("["):
            return [x.strip() for x in val[0].split(",")]
        if val[0].startswith("["):
            try:
                return json.loads(val[0])
            except json.JSONDecodeError:
                pass
    return val if isinstance(val, list) else []
