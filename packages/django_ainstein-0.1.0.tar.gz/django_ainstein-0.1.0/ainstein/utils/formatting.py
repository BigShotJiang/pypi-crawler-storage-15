"""Formatting utilities for display output."""


def format_bytes(num_bytes: int) -> str:
    """Format bytes as human-readable string (B, KB, MB)."""
    if num_bytes < 1024:
        return f"{num_bytes}B"
    if num_bytes < 1024 * 1024:
        return f"{num_bytes // 1024}KB"
    return f"{num_bytes // (1024 * 1024)}MB"


def format_duration(seconds: float) -> str:
    """Format duration as human-readable string (ms, s, m)."""
    if seconds < 1:
        return f"{seconds * 1000:.0f}ms"
    if seconds < 60:
        return f"{seconds:.1f}s"
    mins = int(seconds // 60)
    secs = seconds % 60
    return f"{mins}m {secs:.0f}s"


def truncate_content(content: str, max_len: int = 50) -> str:
    """Truncate content for display, showing beginning and indicating if truncated."""
    if not content:
        return "(empty)"
    # Replace newlines with spaces for compact display
    content = content.replace("\n", " ").replace("\r", "")
    if len(content) <= max_len:
        return content
    return content[:max_len] + "..."
