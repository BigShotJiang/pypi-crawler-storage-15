"""Django-specific utilities."""

from django.apps import apps


def get_all_django_app_labels() -> list[str]:
    """
    Get all user-defined Django app labels.

    Excludes:
    - Django built-in apps (django.*)
    - Third-party apps in site-packages
    - Common third-party apps (rest_framework, corsheaders, debug_toolbar)
    """
    return [
        config.label
        for config in apps.get_app_configs()
        if not config.name.startswith(("django.", "rest_framework", "corsheaders", "debug_toolbar"))
        and "site-packages" not in getattr(config.module, "__file__", "")
    ]
