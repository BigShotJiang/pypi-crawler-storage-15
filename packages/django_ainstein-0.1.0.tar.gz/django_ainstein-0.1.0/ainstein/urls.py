"""
Insight Agent URLs

Provides both API and staff view URLs.
Mount at: /ainstein/
"""

from django.urls import include, path

from . import views
from .api import ainstein_router


app_name = "ainstein"

# Custom file endpoint view
file_view = views.AiProjectViewSet.as_view(
    {
        "get": "file",
        "post": "file",
        "put": "file",
        "delete": "file",
    }
)

# Raw file endpoint view (returns content directly without wrapper)
raw_file_view = views.AiProjectViewSet.as_view({"get": "raw_file"})

urlpatterns = [
    # API endpoints (v1)
    path("v1/", include(ainstein_router.urls)),
    # Custom file endpoint: /v1/projects/<id>/file/<path>
    path("v1/projects/<int:pk>/file/<path:file_path>", file_view, name="project-file"),
    # Raw file endpoint: /v1/projects/<id>/raw-file/<path> (returns content directly)
    path("v1/projects/<int:pk>/raw-file/<path:file_path>", raw_file_view, name="project-raw-file"),
    # Staff views (React SPA)
    path("staff/p/", views.ainstein_view, name="projects_page"),
    path("staff/p/c/<int:conversation_id>/", views.ainstein_view, name="conversation_page"),
    path("staff/p/<path:path>", views.ainstein_view, name="projects_page_catchall"),
]
