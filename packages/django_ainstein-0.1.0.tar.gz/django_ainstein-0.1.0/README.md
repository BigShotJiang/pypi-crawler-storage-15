# Django AInstein

An AI agent that learns your schema and helps you reason about your data.

A reusable Django app powered by Anthropic's Claude that provides an intelligent agent for interacting with your Django application.

## Features

- **Claude Integration**: Built on Anthropic's Claude SDK for powerful AI capabilities
- **Django ORM Tools**: Query models, analyze data, and generate insights
- **File Management**: Create and edit files within project sandboxes
- **Code Execution**: Safe code execution in isolated environments
- **React Frontend**: Modern chat interface with streaming support
- **Extensible Tools**: Add custom tools for your specific use case

## Installation

```bash
pip install django-ainstein
```

## Quick Start

1. Add to your `INSTALLED_APPS`:

```python
INSTALLED_APPS = [
    ...
    'ainstein',
]
```

2. Add URL configuration:

```python
urlpatterns = [
    ...
    path('ainstein/', include('ainstein.urls')),
]
```

3. Configure settings:

```python
AINSTEIN = {
    "ANTHROPIC_API_KEY": "your-api-key",
    "DEFAULT_MODEL": "claude-sonnet-4-20250514",
}
```

4. Run migrations:

```bash
python manage.py migrate ainstein
```

## Configuration

| Setting | Description | Default |
|---------|-------------|---------|
| `ANTHROPIC_API_KEY` | Your Anthropic API key | Required |
| `DEFAULT_MODEL` | Claude model to use | `claude-sonnet-4-20250514` |
| `MAX_TOKENS` | Maximum response tokens | `16000` |
| `TEMPERATURE` | Response temperature | `1` |

## Development

```bash
# Clone the repository
git clone https://github.com/harpb/django-ainstein.git
cd django-ainstein

# Install dependencies
pip install -e ".[dev]"

# Run tests
pytest
```

## License

MIT License - see [LICENSE](LICENSE) for details.
