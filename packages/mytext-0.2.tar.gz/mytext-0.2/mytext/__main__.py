# -*- coding: utf-8 -*-
"""mytext main."""
from .functions import main

if __name__ == "__main__":
    main()
