from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from typing import List
import uvicorn


class ConnectionManager:
    def __init__(self):
        self.active: List[WebSocket] = []

    async def connect(self, ws: WebSocket):
        await ws.accept()
        self.active.append(ws)

    def disconnect(self, ws: WebSocket):
        self.active.remove(ws)

    async def broadcast(self, msg: str):
        # 并发推送，断开自动忽略
        import asyncio
        await asyncio.gather(
            *(ws.send_text(msg) for ws in self.active.copy()),
            return_exceptions=True
        )


if __name__ == "__main__":    
    app = FastAPI()
    
    manager = ConnectionManager()

    @app.websocket("/chat")
    async def websocket_chat(ws: WebSocket):
        await manager.connect(ws)
        await manager.broadcast(f"👤 有人加入群聊，当前在线 {len(manager.active)}")
        try:
            while True:
                data = await ws.receive_text()
                await manager.broadcast(f"消息：{data}")
        except WebSocketDisconnect:
            manager.disconnect(ws)
            await manager.broadcast(f"👋 有人离开，当前在线 {len(manager.active)}")
        
    uvicorn.run(app, host="0.0.0.0", port=8000)