"""
NC1709 CLI - A Local-First AI Developer Assistant
Version: 1.7.0
Author: NC1709 Team
License: MIT
"""

__version__ = "1.8.0"
__author__ = "NC1709 Team"

from .cli import main

__all__ = ["main"]
