def main():
	print("Hello from core!")


if __name__ == "__main__":
	main()
