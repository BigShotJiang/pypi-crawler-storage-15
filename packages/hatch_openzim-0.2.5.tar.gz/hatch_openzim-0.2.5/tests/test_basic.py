from hatch_openzim.__about__ import __version__


def test_dummy():
    assert __version__
