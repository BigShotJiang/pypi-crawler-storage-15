"""
base
"""


def main():
    """
    Main entrypoint for command-line use of manager
    :return:
    """
    from .manager import main

    main()
