# **4. docs/api_reference.md**
```markdown
# API Reference

## Inspector

```python
inspect(fn, *args, **kwargs) -> (result, Trace)
