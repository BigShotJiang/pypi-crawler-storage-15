# **2. Installation

```bash
pip install mrs-inspector
