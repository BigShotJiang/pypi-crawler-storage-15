# **1. mrs-inspector

Modular Reasoning Scaffold — Inspector

A minimal reasoning trace and module-state capture utility.

This package provides:

- state logging
- transition capture
- JSON trace export
- optional graph construction

See `installation.md` and `usage.md` for examples.
