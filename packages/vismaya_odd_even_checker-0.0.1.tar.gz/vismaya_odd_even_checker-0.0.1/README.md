# odd-even-checker

A simple Python library to check whether a number is odd or even.

## Installation

```bash
pip install odd-even-checker