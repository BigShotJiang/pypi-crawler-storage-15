"""Crawler orchestration and execution components."""

