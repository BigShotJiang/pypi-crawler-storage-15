"""API layer for ScrapyRT-compatible endpoints."""

