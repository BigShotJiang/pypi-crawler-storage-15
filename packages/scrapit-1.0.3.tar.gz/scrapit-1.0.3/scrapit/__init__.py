"""ScrapyRT-compatible FastAPI wrapper for Scrapy spiders."""

__version__ = "1.0.3"
