# sage_setup: distribution = sagemath-gap-pkg-cddinterface

from sage.all__sagemath_gap_pkg_cddinterface import *
