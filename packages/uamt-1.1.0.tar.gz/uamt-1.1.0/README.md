# uamt

The Ultimate Android App Modding Tool
run with UAMT or uamt

Author: UAMT