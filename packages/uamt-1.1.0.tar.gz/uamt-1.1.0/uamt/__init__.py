# __init__.py
"""uamt package."""
from .UAMT import *
__version__="1.1.0"