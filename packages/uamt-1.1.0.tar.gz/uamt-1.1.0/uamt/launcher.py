
import sys
from . import UAMT

def run():
    try:
        if hasattr(UAMT, 'main'):
            UAMT.main()
    except KeyboardInterrupt:
        pass
    except Exception as e:
        print(f"Error: {e}")
