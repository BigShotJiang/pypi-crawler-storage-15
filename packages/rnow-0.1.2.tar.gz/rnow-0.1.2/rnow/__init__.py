"""
ReinforceNow CLI - Command-line interface for ReinforceNow RLHF platform.
"""

__version__ = "0.8.2"
