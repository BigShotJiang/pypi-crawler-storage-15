#!/usr/bin/env python
"""Entry point for running rnow as a module."""

from rnow.cli.main import main

if __name__ == "__main__":
    main()
