# Google Keyword Insight1 MCP Server

[English](./README_EN.md) | 简体中文 | [繁體中文](./README_ZH-TW.md)

用于访问 Google Keyword Insight1 API 的 MCP 服务器。

## 🚀 使用 EMCP 平台快速体验

**[EMCP](https://sit-emcp.kaleido.guru)** 是一个强大的 MCP 服务器管理平台，让您无需手动配置即可快速使用各种 MCP 服务器！

### 快速开始：

1. 🌐 访问 **[EMCP 平台](https://sit-emcp.kaleido.guru)**
2. 📝 注册并登录账号
3. 🎯 进入 **MCP 广场**，浏览所有可用的 MCP 服务器
4. 🔍 搜索或找到本服务器（`bach-google_keyword_insight1`）
5. 🎉 点击 **"安装 MCP"** 按钮
6. ✅ 完成！即可在您的应用中使用

### EMCP 平台优势：

- ✨ **零配置**：无需手动编辑配置文件
- 🎨 **可视化管理**：图形界面轻松管理所有 MCP 服务器
- 🔐 **安全可靠**：统一管理 API 密钥和认证信息
- 🚀 **一键安装**：MCP 广场提供丰富的服务器选择
- 📊 **使用统计**：实时查看服务调用情况

立即访问 **[EMCP 平台](https://sit-emcp.kaleido.guru)** 开始您的 MCP 之旅！


---

## 简介

这是一个 MCP 服务器，用于访问 Google Keyword Insight1 API。

- **PyPI 包名**: `bach-google_keyword_insight1`
- **版本**: 1.0.0
- **传输协议**: stdio


## 安装

### 从 PyPI 安装:

```bash
pip install bach-google_keyword_insight1
```

### 从源码安装:

```bash
pip install -e .
```

## 运行

### 方式 1: 使用 uvx（推荐，无需安装）

```bash
# 运行（uvx 会自动安装并运行）
uvx --from bach-google_keyword_insight1 bach_google_keyword_insight1

# 或指定版本
uvx --from bach-google_keyword_insight1@latest bach_google_keyword_insight1
```

### 方式 2: 直接运行（开发模式）

```bash
python server.py
```

### 方式 3: 安装后作为命令运行

```bash
# 安装
pip install bach-google_keyword_insight1

# 运行（命令名使用下划线）
bach_google_keyword_insight1
```

## 配置

### API 认证

此 API 需要认证。请设置环境变量:

```bash
export API_KEY="your_api_key_here"
```

### 环境变量

| 变量名 | 说明 | 必需 |
|--------|------|------|
| `API_KEY` | API 密钥 | 是 |
| `PORT` | 不适用 | 否 |
| `HOST` | 不适用 | 否 |



### 在 Cursor 中使用

编辑 Cursor MCP 配置文件 `~/.cursor/mcp.json`:


```json
{
  "mcpServers": {
    "bach-google_keyword_insight1": {
      "command": "uvx",
      "args": ["--from", "bach-google_keyword_insight1", "bach_google_keyword_insight1"],
      "env": {
        "API_KEY": "your_api_key_here"
      }
    }
  }
}
```

### 在 Claude Desktop 中使用

编辑 Claude Desktop 配置文件 `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "bach-google_keyword_insight1": {
      "command": "uvx",
      "args": ["--from", "bach-google_keyword_insight1", "bach_google_keyword_insight1"],
      "env": {
        "API_KEY": "your_api_key_here"
      }
    }
  }
}
```


## 可用工具

此服务器提供以下工具:


### `global_results_by_url`

Fetch global keyword suggestions and metrics based on a provided URL.  Parameters:  url (required): The URL for which you want global keyword suggestions. lang (required): Two digit code for language.

**端点**: `GET /globalurl/`


**参数**:

- `url` (string) *必需*: Example value: rapidapi.com

- `lang` (string) *必需*: Example value: en

- `min_search_vol` (number): The min_search_vol query parameter sets a minimum search volume threshold. It accepts an integer value, and only those keywords with a search volume equal to or greater than the specified value are included in the results.

- `intent` (string): Accepted values: informational navigational commercial transactional

- `return_intent` (string): Example value: 



---


### `global_results_by_keyword`

Retrieve global keyword suggestions and metrics by providing a keyword.  Parameters:  keyword (required): The target keyword for which you want global suggestions. lang (required): Two digit code for language.

**端点**: `GET /globalkey/`


**参数**:

- `keyword` (string) *必需*: Example value: Sustainable Living

- `lang` (string) *必需*: Example value: en

- `mode` (string): The mode query parameter allows you to specify the filtering criteria for keyword suggestions. It can take one of two values: exact or all exact- Use this mode when you need the API to return only those keyword suggestions that exactly match the searched keyword and excluding any suggestions that do not contain the exact match. all - This is the default mode, where the API returns all keyword suggestions.

- `min_search_vol` (number): The min_search_vol query parameter sets a minimum search volume threshold. It accepts an integer value, and only those keywords with a search volume equal to or greater than the specified value are included in the results.

- `intent` (string): Accepted values: informational navigational commercial transactional

- `return_intent` (string): Example value: 



---


### `keyword_research_by_url`

Receive keyword suggestions and metrics based on a given URL and location.  Parameters:  url (required): The URL for which you want keyword suggestions. location (required): The location or region to refine keyword suggestions. lang (required): Two digit code for language.  Consult API About page for available Country Codes and Language Codes

**端点**: `GET /urlkeysuggest/`


**参数**:

- `url` (string) *必需*: Example value: rapidapi.com

- `location` (string) *必需*: Example value: US

- `lang` (string) *必需*: Example value: en

- `min_search_vol` (number): The min_search_vol query parameter sets a minimum search volume threshold. It accepts an integer value, and only those keywords with a search volume equal to or greater than the specified value are included in the results.

- `intent` (string): Accepted values: informational navigational commercial transactional

- `return_intent` (string): Example value: 



---


### `keyword_research`

Get keyword suggestions and related metrics by providing a specific keyword and location.  Parameters:  keyword (required): The target keyword for which you want suggestions. location (required): The location or region to refine keyword suggestions. lang (required): Two digit code for language.  Consult API About page for available Country Codes and Language Codes

**端点**: `GET /keysuggest/`


**参数**:

- `keyword` (string) *必需*: Example value: Sustainable Living

- `location` (string) *必需*: Example value: US

- `lang` (string) *必需*: Example value: en

- `mode` (string): The mode query parameter allows you to specify the filtering criteria for keyword suggestions. It can take one of two values: exact or all exact- Use this mode when you need the API to return only those keyword suggestions that exactly match the searched keyword and excluding any suggestions that do not contain the exact match. all - This is the default mode, where the API returns all keyword suggestions.

- `min_search_vol` (number): The min_search_vol query parameter sets a minimum search volume threshold. It accepts an integer value, and only those keywords with a search volume equal to or greater than the specified value are included in the results.

- `intent` (string): Accepted values: informational navigational commercial transactional

- `return_intent` (string): Example value: 



---


### `top_keyword`

This endpoint helps identify high-potential keywords (opportunity keywords) for targeted SEO and marketing strategies.

**端点**: `GET /topkeys/`


**参数**:

- `keyword` (string) *必需*: Example value: Sustainable Living

- `location` (string) *必需*: Example value: US

- `lang` (string) *必需*: Example value: en

- `num` (number): The num parameter specifies the number of top keywords to retrieve. By default, the endpoint returns the top 10 keywords, but users can adjust this value to fetch a custom number of results based on their needs.



---


### `get_languages`

Get all available languages with code

**端点**: `GET /languages/`



---


### `get_locations`

Get all available country locations with codes

**端点**: `GET /locations/`



---



## 技术栈

- **传输协议**: stdio
- **HTTP 客户端**: httpx


## 许可证

MIT License - 详见 [LICENSE](./LICENSE) 文件。

## 开发

此服务器由 [API-to-MCP](https://github.com/BACH-AI-Tools/api-to-mcp) 工具生成。

版本: 1.0.0
