#!/usr/bin/env python3
"""Test script to verify MCP server tools"""
import sys
import json

# Add parent directory to path
sys.path.insert(0, '/home/lysander-z-f-q/PycharmProjects/sj_ai_patent')

from mcp_server.server import mcp

print("=" * 60)
print("MCP Server Tool Verification")
print("=" * 60)

# Try to get the tool list
try:
    # FastMCP stores tools in different ways depending on version
    # Let's try multiple approaches
    
    if hasattr(mcp, 'list_tools'):
        print("\nFound list_tools method")
        tools = mcp.list_tools()
        print(f"Tools: {tools}")
    
    if hasattr(mcp, '_tool_manager'):
        print("\nFound _tool_manager")
        tool_manager = mcp._tool_manager
        if hasattr(tool_manager, '_tools'):
            tools = tool_manager._tools
            print(f"Number of tools registered: {len(tools)}")
            for name, tool in tools.items():
                print(f"  - {name}")
        else:
            print("  No _tools attribute in tool_manager")
    
    if hasattr(mcp, 'tools'):
        print("\nFound tools attribute")
        print(f"Tools: {mcp.tools}")
    
    # Print all attributes
    print("\nAll MCP object attributes:")
    for attr in dir(mcp):
        if not attr.startswith('_'):
            print(f"  - {attr}")
            
except Exception as e:
    print(f"Error: {e}")
    import traceback
    traceback.print_exc()

print("=" * 60)
