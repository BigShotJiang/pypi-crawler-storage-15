## Contributing to Caustics

Thank you for your interest in contributing to `caustics`! We welcome
contributions from the community to help improve our project.

To get started, please refer to our
[online documentation](https://caustics.readthedocs.io/en/latest/contributing.html)
for detailed guidelines on how to contribute to `caustics`.

We appreciate your contributions and look forward to your involvement in making
`caustics` even better!
