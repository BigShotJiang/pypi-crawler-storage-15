
Examples
========

Here we present a few examples of analysis done with ``caustics``. There will hopefully be one that is close to your use case and so can act as a good starting point.
