import pandas as pd
import os
def stat_df(df):
    stats = []
    for col in df.columns:
        stats.append((col, df[col].nunique(),df[col].isnull().sum()*100/df.shape[0],df[col].min(),df[col].max(),
                    df[col].value_counts(normalize=True,dropna=False).values[0]*100,df[col].dtype))
    stats_df = pd.DataFrame(stats, columns=['特征','唯一数数量','缺失值占比','最小值','最大值','最多数占比','类型'])
    stats_df.sort_values('缺失值占比',ascending=False)
    return stats_df

def write(filename):
    doc = '''
import pandas as pd
import numpy as np
import lightgbm as lgb
import xgboost as xgb
from catboost import CatBoostClassifier
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import roc_auc_score
warnings.filterwarnings('ignore')

def cv_model(train_x,train_y,test_x,clf_name='lgb'):
    kfold=7
    seeds=[2122]
    train=np.zeros(train_x.shape[0])
    test=np.zeros(test_x.shape[0])
    val_roc_auc=[]
    test_list=[]
    for seed in seeds:
        kf=StratifiedKFold(n_splits=kfold,shuffle=True,random_state=seed)
        for i, (trn_index,val_index) in enumerate(kf.split(train_x,train_y)):
            trn_x,trn_y,val_x,val_y=train_x.iloc[trn_index],train_y.iloc[trn_index],train_x.iloc[val_index],train_y.iloc[val_index]
            if clf_name=='lgb':
                trn_matrix=lgb.Dataset(trn_x,label=trn_y)
                val_matrix=lgb.Dataset(val_x,label=val_y)
                params={
                    'objective':'binary',
                    'max_depth':3,
                    'num_leaves':10,
                    'feature_fraction':0.7,
                    'bagging_fraction':0.8,
                    'bagging_freq':1,
                    'seed':seed,
                    'objective':'binary',
                    'metric':'auc',
                    'lambda_l1':1,
                    'lambda_l2':1,
                    'nthread':5,
                    'min_data_in_leaf':20,
                    'min_child_weight':1,
                    'min_gain_to_split':0.02,
                    'learning_rate':0.02,'nthread': 28,
                    'verbose': -1,
                }
                # params = {
                # 'boosting_type': 'gbdt',
                # 'objective': 'binary',
                # 'metric': 'auc',
                # 'min_child_weight':5,
                # 'max_depth': 4,
                # 'num_leaves': 2 ** 5-5,
                # 'lambda_l2': 1,
                # 'lambda_l1': 1,
                # 'min_gain_to_split': 0.02,
                # 'feature_fraction': 0.65,
                # 'bagging_fraction': 0.8,
                # 'bagging_freq': 1,
                # 'learning_rate': 0.02,
                # 'seed': 2122,#2122,
                # 'nthread': 28,
                # 'n_jobs': 24,
                # 'silent': True,
                # 'verbose': -1,
                # 'num_threads':8,
                # 'min_data_in_leaf': 20
                # }
                callbacks=[lgb.log_evaluation(200),lgb.early_stopping(600)]
                model=lgb.train(params,trn_matrix,8000,callbacks=callbacks,valid_sets=[trn_matrix,val_matrix])
                val_pred=model.predict(val_x,num_itreration=model.best_iteration)
                test_pred=model.predict(test_x,num_itreration=model.best_iteration)
            elif clf_name=='xgb':
                trn_matrix=xgb.DMatrix(trn_x,label=trn_y)
                val_matrix=xgb.DMatrix(val_x,label=val_y)
                params={
                    'objective':'binary:logistic',
                    'eval_metric':'auc',
                    'eta':0.02,
                    'max_depth':4,
                    'lambda':5,
                    'gamma':5,
                    'tree_method':'exact',
                    'min_child_weight':5,
                    'subsample':0.7,
                    'colsample_bytree':0.7,
                    'colsample_bylevel':0.8,
                    'seed':seed,
                    'nthread':36
                }
                wl=[(trn_matrix,'trn'),(val_matrix,'val')]
                model=xgb.train(params,trn_matrix,8000,evals=wl,early_stopping_rounds=600,verbose_eval=500)
                val_pred=model.predict(val_matrix,iteration_range=(0,1+model.best_iteration))
                test_pred=model.predict(xgb.DMatrix(test_x),iteration_range=(0,1+model.best_iteration))
            else:
                params={
                    'l2_leaf_reg':5,
                    'depth':3,
                    'learning_rate':0.02,
                    'max_ctr_complexity':3,
                    'bootstrap_type':'Bernoulli',
                    'grow_policy':'Depthwise',
                    'random_state':seed,
                    'eval_metric':'AUC',
                    'early_stopping_rounds':600
                }
                model=CatBoostClassifier(iterations=8000,**params)
                model.fit(trn_x,trn_y,eval_set=(val_x,val_y),verbose_eval=500)
                val_pred=model.predict_proba(val_x)[:,1]
                test_pred=model.predict_proba(test_x)[:,1]
            val_roc_auc.append(roc_auc_score(val_y,val_pred))
            train[val_index]=val_pred
            test_list.append(test_pred)
            print(f'val_roc_auc:{val_roc_auc}')
        print(f'val_roc_auc:{np.mean(val_roc_auc)}')
        test=np.mean(test_list,axis=0)
        return train,test

def lgb_model_1(x_train, y_train, x_test):
    lgb_train, lgb_test = cv_model(x_train, y_train, x_test, "lgb")
    return lgb_train, lgb_test
def xgb_model_1(x_train, y_train, x_test):
    xgb_train, xgb_test = cv_model(x_train, y_train, x_test, "xgb")
    return  xgb_train, xgb_test

def cat_model_1(x_train, y_train, x_test):
    cat_train, cat_test = cv_model(x_train, y_train, x_test, "cat")
    return cat_train, cat_test
    '''
    with open(filename,'w') as f:
        f.write(doc)

def write_ipynb(filename):
    doc = '''
{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "4a686221",
   "metadata": {},
   "outputs": [],
   "source": [
    "%run function.ipynb\n",
    "import pandas as pd\n",
    "import numpy as np\n",
    "import lightgbm as lgb\n",
    "import xgboost as xgb\n",
    "from catboost import CatBoostRegressor,CatBoostClassifier\n",
    "\n",
    "from sklearn.model_selection import KFold\n",
    "from sklearn.metrics import roc_auc_score\n",
    "import warnings\n",
    "import os\n",
    "from sklearn.preprocessing import LabelEncoder\n",
    "from function import *\n",
    "from lightgbm import log_evaluation, early_stopping\n",
    "warnings.filterwarnings('ignore')"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "11167c2b",
   "metadata": {},
   "outputs": [],
   "source": [
    "from sklearn.preprocessing import MinMaxScaler\n",
    "dic_dtype = {\n",
    "    'zip_code':'str'\n",
    "}\n",
    "df_train=pd.read_csv('../input/train/train.csv', dtype=dic_dtype)\n",
    "df_test=pd.read_csv('../inpupt/testab/testab.csv', dtype=dic_dtype)\n",
    "\n",
    "df_all = pd.concat([df_train, df_test])\n",
    "df_0 = df_all[df_all['term'] == 12].copy()\n",
    "df_1 = df_all[df_all['term'] > 12].copy()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "949d3c9d",
   "metadata": {},
   "outputs": [],
   "source": [
    "def prepro_0(df):\n",
    "    \n",
    "    df_tmp = df.copy()\n",
    "\n",
    "    tim_fea=['issue_time','record_time','history_time']\n",
    "    for fea in tim_fea:\n",
    "        df_tmp[fea] = pd.to_datetime(df_tmp[fea], unit='s')\n",
    "\n",
    "    df_tmp['zip_2'] = df_tmp['zip_code'].str[:2]\n",
    "    df_tmp['zip_4'] = df_tmp['zip_code'].str[:4]\n",
    "    df_tmp['level_1'] = df_tmp['level'].str[0]\n",
    "   \n",
    "    # # add\n",
    "    # df_tmp['level_title'] = df_tmp['level'] + \"_\" + df_tmp['title'].astype('str')\n",
    "    # df_tmp['level_career'] = df_tmp['level'] + \"_\" + df_tmp['career'].astype('str')\n",
    "    # df_tmp['level_syndicated'] = df_tmp['level'] + \"_\" + df_tmp['syndicated'].astype('str')\n",
    "\n",
    "    for col in ['zip_2','zip_4','level_1','level']:#,'level_title','level_career','level_syndicated']:\n",
    "        enc = LabelEncoder()\n",
    "        df_tmp[col] = enc.fit_transform(df_tmp[col])\n",
    "\n",
    "    df_tmp['balance_accounts_ratio'] = df_tmp['balance'] / df_tmp['balance_accounts']\n",
    "    df_tmp['balance_loan_ratio'] = df_tmp['balance'] / df_tmp['loan']\n",
    "\n",
    "    df_tmp['passed_term'] = (df_tmp['record_time'].dt.to_period('M') - df_tmp['issue_time'].dt.to_period('M')).apply(lambda x: 0 if x.n<0 else x.n)\n",
    "    df_tmp['rest_term'] = df_tmp['term'] - df_tmp['passed_term']\n",
    "    df_tmp['interest_all'] = df_tmp['loan'] * df_tmp['interest_rate'] * df_tmp['rest_term'] / 100\n",
    "\n",
    "    df_tmp['balance_loan_diff'] = df_tmp['balance'] - df_tmp['loan']\n",
    "    \n",
    "    df_tmp = df_tmp.drop(['passed_term','rest_term'], axis=1)\n",
    "\n",
    "\n",
    "\n",
    "    return df_tmp\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "f54a98fc",
   "metadata": {},
   "outputs": [],
   "source": [
    "def prepro_1(df):\n",
    "    tim_fea=['issue_time','record_time','history_time']\n",
    "\n",
    "    # # add\n",
    "    # df['level_title'] = df['level'] + \"_\" + df['title'].astype('str')\n",
    "    # df['level_career'] = df['level'] + \"_\" + df['career'].astype('str')\n",
    "    # df['level_syndicated'] = df['level'] + \"_\" + df['syndicated'].astype('str')\n",
    "\n",
    "    # for col in ['level_title','level_career','level_syndicated']:\n",
    "    #     enc = LabelEncoder()\n",
    "    #     df[col] = enc.fit_transform(df[col])\n",
    "\n",
    "    df['zip_code']=df['zip_code'].astype(int)\n",
    "    df['zip_code_2']=df['zip_code'].apply(lambda x: int(str(x)[:2]))\n",
    "    df['zip_code_3']=df['zip_code'].apply(lambda x: int(str(x)[:3]))\n",
    "    df['zip_code_4']=df['zip_code'].apply(lambda x: int(str(x)[:4]))\n",
    "    \n",
    "    for fea in tim_fea:\n",
    "        df[fea] = pd.to_datetime(df[fea], unit='s')\n",
    "    df['level_1'] = df['level'].str[0]\n",
    "    ## 处理类别特征\n",
    "    def trans_level(x):\n",
    "        dic_level={'A':0,'B':1,'C':2,'D':3,'E':4}\n",
    "        return 6*dic_level[x[0]]+int(x[1])\n",
    "    df['level']=df['level'].apply(lambda x: trans_level(x))\n",
    "    \n",
    "    dic_level={'A':0,'B':1,'C':2,'D':3,'E':4}\n",
    "    df['level_1'] = df['level_1'].map(dic_level)\n",
    "\n",
    "\n",
    "    ## 业务特征\n",
    "    df['diff_issue_record']=(df['issue_time']-df['record_time']).dt.days\n",
    "    df['diff_issue_record']=df['diff_issue_record'].apply(lambda x: x if x>0 else 0)\n",
    "    \n",
    "\n",
    "    df['diff_issue_his']=(df['issue_time']-df['history_time']).dt.days\n",
    "    df['diff_issue_his']=df['diff_issue_his'].apply(lambda x: abs(x))\n",
    "    \n",
    "    df['diff_record_his']=(df['record_time']-df['history_time']).dt.days\n",
    "    df['diff_record_his']=df['diff_record_his'].apply(lambda x: abs(x))\n",
    "\n",
    "   \n",
    "    df['record_time_month'] = df['record_time'].dt.month\n",
    "    df['record_time_year'] = df['record_time'].dt.year\n",
    "\n",
    "    df['issue_day_of_week'] = df['issue_time'].dt.dayofweek \n",
    "    df['issue_day_of_month'] = df['issue_time'].dt.day\n",
    "    df['issue_month'] = df['issue_time'].dt.month\n",
    "    df['issue_time_year'] = df['issue_time'].dt.year\n",
    "    df['history_time_month'] = df['history_time'].dt.month\n",
    "    df['history_time_year'] = df['history_time'].dt.year\n",
    "\n",
    "    # 计算活跃账户比例\n",
    "    df['active_account_ratio'] = df['balance_accounts'] / df['total_accounts']\n",
    "    df['active_account_ratio'] = df['active_account_ratio'].replace([np.inf, -np.inf], np.nan).fillna(-1)\n",
    "    df['intereat_mean']=df['interest_rate']/df['term']\n",
    "    df['balance_ratio']=df['balance']/(df['balance_accounts']+1e-5)\n",
    "    df['balance_loan_ratio']=df['balance']/(df['loan']+1e-5)\n",
    "    \n",
    "    # 计算信用额度使用率\n",
    "    df['credit_utilization'] = df['loan'] / df['balance_limit']\n",
    "    df['credit_utilization'] = df['credit_utilization'].replace([np.inf, -np.inf], np.nan).fillna(-1)  # 处理除零错误\n",
    "    ##计算月供\n",
    "    def calculate_monthly_payment(row):\n",
    "        loan_amount = row['loan']\n",
    "        annual_rate = row['interest_rate']\n",
    "        term_months = row['term']  # 假设term是月数\n",
    "        if term_months == 0:\n",
    "            return 0\n",
    "        monthly_rate = annual_rate / 12 / 100 \n",
    "        if monthly_rate == 0:\n",
    "            return loan_amount / term_months\n",
    "        else:\n",
    "            return loan_amount * monthly_rate * (1 + monthly_rate)**term_months / ((1 + monthly_rate)**term_months - 1)\n",
    "\n",
    "    df['monthly_payment'] = df.apply(calculate_monthly_payment, axis=1)\n",
    "    df['payment_to_balance_ratio'] = df['monthly_payment'] / df['balance']\n",
    "    df['payment_to_balance_ratio'] = df['payment_to_balance_ratio'].replace([np.inf, -np.inf], np.nan).fillna(-1)\n",
    "\n",
    "    df['zip_mean'] = df.groupby(['zip_code','term'])['interest_rate'].transform('mean')\n",
    "    df['level_mean'] = df.groupby(['level','term'])['interest_rate'].transform('mean')\n",
    "    return df\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "2c9d7826",
   "metadata": {},
   "outputs": [],
   "source": [
    "df_train_statement=pd.read_csv('../input/train/train_bank_statement.csv')\n",
    "df_test_statement=pd.read_csv('../input/testab/testab_bank_statement.csv')\n",
    "\n",
    "df_train_base=pd.read_csv('../input/train/train.csv')\n",
    "df_test_base=pd.read_csv('../input/testab/testab.csv')\n",
    "\n",
    "df_train_statement=df_train_statement.merge(df_train_base,on='id',how='left')\n",
    "df_test_statement=df_test_statement.merge(df_test_base,on='id',how='left')\n",
    "\n",
    "\n",
    "tim_fea=['time','issue_time','record_time','history_time']\n",
    "for fea in tim_fea:\n",
    "    df_train_statement[fea] = pd.to_datetime(df_train_statement[fea], unit='s')\n",
    "    df_test_statement[fea] = pd.to_datetime(df_test_statement[fea], unit='s')\n",
    "\n",
    "\n",
    "def fe_statement_0(df):\n",
    "    df['signed_amount'] = df['amount'] * np.where(df['direction'] == 0, 1, -1)\n",
    "    df['day_of_week'] = df['time'].dt.dayofweek\n",
    "    df['is_weekend'] = df['day_of_week'].isin([0,1,2,3,4]).astype(int)\n",
    "\n",
    "    mask=(df.direction==0)&((df.time-df.issue_time).dt.days.abs()>=50)\n",
    "    aggregations = {\n",
    "        'amount': ['sum'],\n",
    "    }\n",
    "    base_stats_1= df[mask].groupby('id').agg(aggregations)\n",
    "    base_stats_1.columns = ['base_stats_1_'.join(col).strip() for col in base_stats_1.columns.values]\n",
    "\n",
    "\n",
    "    \n",
    "    # 基础统计\n",
    "    aggregations = {\n",
    "        'amount': ['sum', 'median', 'max', 'min', 'count', 'std','skew'],\n",
    "        'signed_amount': ['sum'],\n",
    "    }\n",
    "   \n",
    "    base_stats = df.groupby('id').agg(aggregations)\n",
    "    base_stats.columns = ['_'.join(col).strip() for col in base_stats.columns.values]\n",
    "    \n",
    "    # 流入流出统计\n",
    "    in_stats = df[df['direction'] == 0].groupby('id').agg({\n",
    "        'amount': ['sum', 'median', 'max', 'min', 'count', 'std','skew'],\n",
    "    })\n",
    "    in_stats.columns = ['in_' + '_'.join(col).strip() for col in in_stats.columns.values]\n",
    "    \n",
    "    out_stats = df[df['direction'] == 1].groupby('id').agg({\n",
    "        'amount': ['sum', 'median', 'max', 'min', 'count', 'std','skew'],\n",
    "    })\n",
    "    out_stats.columns = ['out_' + '_'.join(col).strip() for col in out_stats.columns.values]\n",
    "    \n",
    "    # 时间相关特征\n",
    "    time_stats = df.groupby('id').agg({\n",
    "        'time': ['min', 'max', 'count']\n",
    "    })\n",
    "    time_stats.columns = [ '_'.join(col).strip() for col in time_stats.columns.values]\n",
    "    \n",
    "    # 计算交易活跃度特征\n",
    "    time_stats['time_span_days'] = (time_stats['time_max'] - time_stats['time_min']).dt.days\n",
    "    time_stats['trx_frequency'] = time_stats['time_count'] / (time_stats['time_span_days']+1e-5)\n",
    "    \n",
    "    # 计算交易间隔时间特征\n",
    "    df = df.sort_values(['id', 'time'])\n",
    "    df['time_diff'] = df.groupby('id')['time'].diff().dt.total_seconds() / 3600 \n",
    "    time_diff_stats = df.groupby('id')['time_diff'].agg(['mean', 'std', 'max','min','skew'])\n",
    "    time_diff_stats.columns = ['time_diff_' + '_'.join(col).strip() for col in time_diff_stats.columns.values]\n",
    "\n",
    "\n",
    "    # 合并所有特征\n",
    "    result = base_stats\n",
    "    result = result.join(in_stats, how='left')\n",
    "    result = result.join(out_stats, how='left')\n",
    "    result = result.join(time_stats, how='left')\n",
    "    result = result.join(time_diff_stats, how='left')\n",
    "    result = result.join(base_stats_1, how='left')\n",
    "\n",
    "    \n",
    "    # 计算比率特征\n",
    "    result['in_out_ratio'] = result['in_amount_sum'] / result['out_amount_sum']\n",
    "    result['net_flow_ratio'] = result['signed_amount_sum'] / (result['in_amount_sum'] + result['out_amount_sum'])\n",
    "    result['count_ratio'] = result['in_amount_count'] / (result['out_amount_count'] + 1e-5)\n",
    "    # 填充NaN值\n",
    "    result = result.fillna(0)\n",
    "    \n",
    "    return result"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "a0cc5d26",
   "metadata": {},
   "outputs": [],
   "source": [
    "def fe_statement_1(df): \n",
    "    df = df.sort_values(['id', 'time']).reset_index(drop=True)\n",
    "    df['amount_diff_7'] = df['amount'].diff(periods=7)\n",
    "    df['amount_diff_14'] = df['amount'].diff(periods=14)\n",
    "    df['direction_diff'] = df['direction'].diff(periods=1)\n",
    "\n",
    "    df['signed_amount'] = df['amount'] * np.where(df['direction'] == 0, 1, -1)\n",
    "    mask=(df.direction==0)&((df.time-df.record_time).dt.days.abs()>=50)\n",
    "    aggregations = {\n",
    "        'amount': ['sum'],\n",
    "        'direction':['sum']\n",
    "    }\n",
    "    base_stats_1= df[mask].groupby('id').agg(aggregations)\n",
    "    base_stats_1.columns = ['base_stats_1_'.join(col).strip() for col in base_stats_1.columns.values]\n",
    "    \n",
    "    # 基础统计\n",
    "    aggregations = {\n",
    "        'amount': ['sum', 'median', 'max', 'min', 'count', 'std','skew'],\n",
    "        'signed_amount': ['sum'],\n",
    "        # 'amount_diff_7':['sum', 'median', 'max', 'min','std'],\n",
    "        # 'amount_diff_14':['sum', 'median', 'max', 'min','std']\n",
    "        'direction_diff':['sum', 'median','std']\n",
    "    }\n",
    "    \n",
    "    \n",
    "    base_stats = df.groupby('id').agg(aggregations)\n",
    "    base_stats.columns = ['_'.join(col).strip() for col in base_stats.columns.values]\n",
    "    \n",
    "    # 流入流出统计\n",
    "    in_stats = df[df['direction'] == 0].groupby('id').agg({\n",
    "        'amount': ['sum', 'median', 'max', 'min', 'count', 'std','skew'],\n",
    "        # 'amount_diff_7':['sum', 'median', 'max', 'min','std'],\n",
    "        # 'amount_diff_14':['sum', 'median', 'max', 'min','std']\n",
    "    })\n",
    "    in_stats.columns = ['in_' + '_'.join(col).strip() for col in in_stats.columns.values]\n",
    "    \n",
    "    out_stats = df[df['direction'] == 1].groupby('id').agg({\n",
    "        'amount': ['sum', 'median', 'max', 'min', 'count', 'std','skew'],\n",
    "        # 'amount_diff_7':['sum', 'median', 'max', 'min','std'],\n",
    "        # 'amount_diff_14':['sum', 'median', 'max', 'min','std']\n",
    "    })\n",
    "    out_stats.columns = ['out_' + '_'.join(col).strip() for col in out_stats.columns.values]\n",
    "    \n",
    "    #分金额类型统计\n",
    "    bin_stats = df[(df['amount']>10)].groupby('id').agg({\n",
    "        'amount': ['sum', 'median', 'max', 'min', 'count', 'std','skew'],\n",
    "    })\n",
    "    bin_stats.columns = ['bin_' + '_'.join(col).strip() for col in bin_stats.columns.values]\n",
    "\n",
    "    # 时间相关特征\n",
    "    time_stats = df.groupby('id').agg({\n",
    "        'time': ['min', 'max', 'count']\n",
    "    })\n",
    "    time_stats.columns = [ '_'.join(col).strip() for col in time_stats.columns.values]\n",
    "    \n",
    "    # 计算交易活跃度特征\n",
    "    time_stats['time_span_days'] = (time_stats['time_max'] - time_stats['time_min']).dt.days\n",
    "    time_stats['trx_frequency'] = time_stats['time_count'] / (time_stats['time_span_days']+1e-5)\n",
    "\n",
    "    # 计算交易间隔时间特征\n",
    "    df = df.sort_values(['id', 'time'])\n",
    "    df['time_diff'] = df.groupby('id')['time'].diff().dt.total_seconds() / 3600 \n",
    "    time_diff_stats = df.groupby('id')['time_diff'].agg(['mean', 'std', 'max','min','skew'])\n",
    "    time_diff_stats.columns = ['time_diff_' + '_'.join(col).strip() for col in time_diff_stats.columns.values]\n",
    "\n",
    "    # df['time_diff'] = df.groupby('id')['time'].diff().dt.total_seconds() / 3600 \n",
    "    # time_diff_stats_1 = df.groupby('id')['time_diff'].agg(['median'])\n",
    "    # time_diff_stats_1.columns = ['time_diff_7_' + '_'.join(col).strip() for col in time_diff_stats_1.columns.values]\n",
    "\n",
    "    # 合并所有特征\n",
    "    result = base_stats\n",
    "    result = result.join(in_stats, how='left')\n",
    "    result = result.join(out_stats, how='left')\n",
    "    result = result.join(time_stats, how='left')\n",
    "    result = result.join(time_diff_stats, how='left')\n",
    "    # result = result.join(time_diff_stats_1, how='left')\n",
    "    result = result.join(base_stats_1, how='left')\n",
    "    result = result.join(bin_stats, how='left')\n",
    "    # result = result.join(bin_stats_1, how='left')\n",
    "\n",
    "    # 计算比率特征\n",
    "    result['in_out_ratio'] = result['in_amount_sum'] / result['out_amount_sum']\n",
    "    result['net_flow_ratio'] = result['signed_amount_sum'] / (result['in_amount_sum'] + result['out_amount_sum'])\n",
    "    result['count_ratio'] = result['in_amount_count'] / (result['out_amount_count'] + 1e-5)\n",
    "\n",
    "    # 填充NaN值\n",
    "    result = result.fillna(0)\n",
    "    # result=result.drop(['time_max','time_min'],axis=1)\n",
    "    \n",
    "    return result"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "b3a7ca4c",
   "metadata": {},
   "outputs": [],
   "source": [
    "df_train_statement_0 = fe_statement_0(df_train_statement)\n",
    "df_train_statement_1 = fe_statement_1(df_train_statement)\n",
    "\n",
    "df_test_statement_0 = fe_statement_0(df_test_statement)\n",
    "df_test_statement_1 = fe_statement_1(df_test_statement)\n",
    "df_base_0=prepro_0(df_0)\n",
    "df_base_1=prepro_1(df_1)\n",
    "\n",
    "import datetime\n",
    "tim_fea=['issue_time','record_time','history_time']\n",
    "for fea in tim_fea:\n",
    "    startdate = datetime.datetime.strptime('1970-01-16', '%Y-%m-%d')\n",
    "    df_base_1[fea+'_trans'] = df_base_1[fea].apply(lambda x: (x - startdate).days)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "8b8cd1ea",
   "metadata": {},
   "outputs": [],
   "source": [
    "df_train_0 = df_base_0[~df_base_0['label'].isna()]\n",
    "df_test_0 = df_base_0[df_base_0['label'].isna()]\n",
    "\n",
    "df_train_1 = df_base_1[~df_base_1['label'].isna()]\n",
    "df_test_1 = df_base_1[df_base_1['label'].isna()]\n",
    "\n",
    "# lstm_fea=pd.read_csv('lstm_fea.csv')\n",
    "# df_train_0 = df_train_0.merge(lstm_fea,on='id',how='left')\n",
    "# df_test_0 = df_test_0.merge(lstm_fea,on='id',how='left')\n",
    "\n",
    "df_train_0 = df_train_0.merge(df_train_statement_0, on='id', how='left').fillna(0)\n",
    "df_test_0 = df_test_0.merge(df_test_statement_0, on='id', how='left').fillna(0)\n",
    "\n",
    "df_train_1 = df_train_1.merge(df_train_statement_1, on='id', how='left').fillna(-1)\n",
    "df_test_1 = df_test_1.merge(df_test_statement_1, on='id', how='left').fillna(-1)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "89d3c106",
   "metadata": {},
   "outputs": [],
   "source": [
    "\n",
    "def fe_cross_0(df):\n",
    "    df[['time_max']]=df[['time_max']].astype('datetime64[ns]')\n",
    "    df[['time_min']]=df[['time_min']].astype('datetime64[ns]')\n",
    "    df['mark1']=(df['record_time']-df['time_min']).dt.days\n",
    "    df['mark2']=(df['issue_time']-df['time_min']).dt.days\n",
    "    df['in_amount_sum/loan']=(df['in_amount_sum'])/df['loan']\n",
    "    df['out_amount_sum/loan']=df['out_amount_sum']/df['loan']\n",
    "    df['time_max']=df['time_max'].dt.strftime('%Y%m%d').astype(int)\n",
    "    df['time_min']=df['time_min'].dt.strftime('%Y%m%d').astype(int)\n",
    "    df.drop(['time_max','time_min','record_time','issue_time'],axis=1,inplace=True)\n",
    "    return df\n",
    "\n",
    "def fe_cross_1(df):\n",
    "    df[['time_max']]=df[['time_max']].astype('datetime64[ns]')\n",
    "    df['mark']=(df['record_time']-df['time_max']).dt.days\n",
    "    df['in_amount_sum/loan']=(df['in_amount_sum'])/df['loan']\n",
    "    df['out_amount_sum/loan']=df['out_amount_sum']/df['loan']\n",
    "    df['monthly_payment/loan']=df['in_amount_sum']/(df['monthly_payment']-df['loan']/df['term'])\n",
    "    \n",
    "    df.drop(['time_max','time_min','record_time'],axis=1,inplace=True)\n",
    "    return df"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "01d0255b",
   "metadata": {},
   "outputs": [],
   "source": [
    "df_train_0 = fe_cross_0(df_train_0)\n",
    "df_test_0 = fe_cross_0(df_test_0)\n",
    "\n",
    "df_train_1 = fe_cross_1(df_train_1)\n",
    "df_test_1 = fe_cross_1(df_test_1)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "ee4e4e33",
   "metadata": {},
   "outputs": [],
   "source": [
    "\n",
    "\n",
    "exclude_cols = ['new_id','id','label','issue_time','record_time','history_time']\n",
    "features_0 = [x for x in df_train_0.columns if x not in exclude_cols]\n",
    "features_1 = [x for x in df_train_1.columns if x not in exclude_cols]\n",
    "\n",
    "## 筛选特征\n",
    "\n",
    "drop_features0=['interest_all', 'balance_limit', 'mark2', 'mark1']\n",
    "drop_features1=['credit_utilization', 'monthly_payment', 'diff_record_his', 'balance']\n",
    "# 准备特征和标签\n",
    "features = [f for f in df_train.columns if f not in ['id', 'label']]\n",
    "drop_df0=['term','syndicated','installment','zip_2','zip_code']\n",
    "features_0 = [f for f in features_0 if f not in drop_df0 and f not in drop_features0]\n",
    "\n",
    "drop_df1=['diff_issue_record','id_trans']\n",
    "tmp=['credit_utilization', 'monthly_payment', 'diff_record_his','monthly_payment/loan', 'balance', 'time_diff_mean', 'trx_frequency']\n",
    "features_1 = [f for f in features_1 if f not in drop_df1 and f not in tmp]\n",
    "\n",
    "train_0 = df_train_0[features_0]\n",
    "train_1 = df_train_1[features_1]\n",
    "test_0 = df_test_0[features_0]\n",
    "test_1 = df_test_1[features_1]\n",
    "\n",
    "y_0 = df_train_0['label']\n",
    "y_1 = df_train_1['label']\n",
    "test_0.shape, test_1.shape,train_0.shape,train_1.shape"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "64591b5a",
   "metadata": {},
   "outputs": [],
   "source": [
    "lgb_oof_0, lgb_prediction_0 = lgb_model_1(train_0,y_0,test_0)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "4b306208",
   "metadata": {},
   "outputs": [],
   "source": [
    "lgb_oof_1, lgb_prediction_1 = lgb_model_1(train_1,y_1,test_1)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "27e3ca4a",
   "metadata": {},
   "outputs": [],
   "source": [
    "roc_auc_score(y_1, lgb_oof_1)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "f6a737ec",
   "metadata": {},
   "outputs": [],
   "source": [
    "roc_auc_score(y_0, lgb_oof_0), roc_auc_score(y_1, lgb_oof_1)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "f0017134",
   "metadata": {},
   "outputs": [],
   "source": [
    "lgb_oof = np.vstack((lgb_oof_0.reshape(-1,1), lgb_oof_1.reshape(-1,1)))\n",
    "y = pd.concat([y_0, y_1])\n",
    "roc_auc_score(y, lgb_oof)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "20126b39",
   "metadata": {},
   "outputs": [],
   "source": [
    "xgb_oof_0, xgb_prediction_0 = xgb_model_1(train_0,y_0,test_0)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "fbe00096",
   "metadata": {},
   "outputs": [],
   "source": [
    "xgb_oof_1, xgb_prediction_1 = xgb_model_1(train_1,y_1,test_1)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "bf757bf2",
   "metadata": {},
   "outputs": [],
   "source": [
    "roc_auc_score(y_0, xgb_oof_0), roc_auc_score(y_1, xgb_oof_1)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "91eec785",
   "metadata": {},
   "outputs": [],
   "source": [
    "xgb_oof = np.vstack((xgb_oof_0.reshape(-1,1), xgb_oof_1.reshape(-1,1)))\n",
    "y = pd.concat([y_0, y_1])\n",
    "roc_auc_score(y, xgb_oof)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "2156c623",
   "metadata": {},
   "outputs": [],
   "source": [
    "cat_oof_0, cat_prediction_0 = cat_model_1(train_0,y_0,test_0)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "2ce0d531",
   "metadata": {},
   "outputs": [],
   "source": [
    "cat_oof_1, cat_prediction_1 = cat_model_1(train_1,y_1,test_1)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "d695beb6",
   "metadata": {},
   "outputs": [],
   "source": [
    "roc_auc_score(y_0, cat_oof_0), roc_auc_score(y_1, cat_oof_1)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "404e45d3",
   "metadata": {},
   "outputs": [],
   "source": [
    "cat_oof = np.vstack((cat_oof_0.reshape(-1,1), cat_oof_1.reshape(-1,1)))\n",
    "y = pd.concat([y_0, y_1])\n",
    "roc_auc_score(y, cat_oof)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "72ee466b",
   "metadata": {},
   "outputs": [],
   "source": [
    "roc_auc_score(y, (lgb_oof+cat_oof+xgb_oof)/3)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "2f816a13",
   "metadata": {},
   "outputs": [],
   "source": [
    "def simple_weight_optimization(pred1, pred2, pred3, true_labels):\n",
    "    from scipy.optimize import minimize\n",
    "    \n",
    "    def simple_objective(weights):\n",
    "        weights = np.abs(weights)\n",
    "        weights = weights / np.sum(weights)\n",
    "        weighted_pred = weights[0]*pred1 + weights[1]*pred2 + weights[2]*pred3\n",
    "        return -roc_auc_score(true_labels, weighted_pred)\n",
    "    \n",
    "    # 初始均匀权重\n",
    "    initial_weights = np.array([0.4, 0.2, 0.4])\n",
    "    \n",
    "    result = minimize(simple_objective, initial_weights, method='Nelder-Mead')\n",
    "    \n",
    "    optimal_weights = np.abs(result.x)\n",
    "    optimal_weights = optimal_weights / np.sum(optimal_weights)\n",
    "    \n",
    "    weighted_pred = optimal_weights[0]*pred1 + optimal_weights[1]*pred2 + optimal_weights[2]*pred3\n",
    "    best_auc = roc_auc_score(true_labels, weighted_pred)\n",
    "    \n",
    "    return optimal_weights, best_auc\n",
    "simple_weight_optimization(lgb_oof,xgb_oof,cat_oof,y)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "379855e0",
   "metadata": {},
   "outputs": [],
   "source": [
    "df_0 = pd.DataFrame({'id':df_test_0['id'], 'lgb':lgb_prediction_0, 'xgb':xgb_prediction_0, 'cat':cat_prediction_0})\n",
    "df_1 = pd.DataFrame({'id':df_test_1['id'], 'lgb':lgb_prediction_1, 'xgb':xgb_prediction_1,'cat':cat_prediction_1})\n",
    "df = pd.concat([df_0,df_1])"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "883e3a0e",
   "metadata": {},
   "outputs": [],
   "source": [
    "df['lgb_rank'] = df['lgb'].rank(pct=True,ascending=True)\n",
    "df['cat_rank'] = df['cat'].rank(pct=True,ascending=True)\n",
    "df['xgb_rank'] = df['xgb'].rank(pct=True,ascending=True)\n",
    "df['label']=(df['lgb_rank']+df['cat_rank']+df['xgb_rank'])/3\n",
    "df[['id', 'label']].to_csv('bagging_rank_67733.csv', index=False)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "d00476d9",
   "metadata": {},
   "outputs": [],
   "source": [
    "df_test=pd.read_csv('../input/testab/testab.csv', dtype=dic_dtype)\n",
    "df_id = df_test[df_test['term'] > 12].id.values"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "6f7eaf56",
   "metadata": {},
   "outputs": [],
   "source": [
    "def get_stack(oof_1, oof_2, pred_1, pred_2,model_name):\n",
    "    o_1 = pd.DataFrame({'id':df_train_0['id'],'term':0, model_name:oof_1})\n",
    "    o_2 = pd.DataFrame({'id':df_train_1['id'],'term':1, model_name:oof_2})\n",
    "    oof = pd.concat([o_1,o_2],axis=0).reset_index(drop=True)\n",
    "    \n",
    "    p_1 = pd.DataFrame({'id':df_test_0['id'],'term':0, model_name:pred_1})\n",
    "    p_2 = pd.DataFrame({'id':df_test_1['id'],'term':1, model_name:pred_2})\n",
    "    pred = pd.concat([p_1,p_2]).reset_index(drop=True)\n",
    "    return oof, pred\n",
    "\n",
    "df_lgb_oof, df_lgb_pred = get_stack(lgb_oof_0, lgb_oof_1, lgb_prediction_0, lgb_prediction_1,'lgb')\n",
    "df_xgb_oof, df_xgb_pred = get_stack(xgb_oof_0, xgb_oof_1, xgb_prediction_0, xgb_prediction_1,'xgb')\n",
    "df_ctb_oof, df_ctb_pred = get_stack(cat_oof_0, cat_oof_1, cat_prediction_0, cat_prediction_1,'ctb')\n",
    "\n",
    "df_train_stack = df_lgb_oof.merge(df_xgb_oof, on=['id','term']).merge(df_ctb_oof, on=['id','term'])\n",
    "df_test_stack = df_lgb_pred.merge(df_xgb_pred, on=['id','term']).merge(df_ctb_pred, on=['id','term'])\n",
    "\n",
    "df_train_stack.shape, df_test_stack.shape\n",
    "df_label = df_train[['id','label']]\n",
    "df_train_stack = df_train_stack.merge(df_label, on='id')\n",
    "y = df_train_stack.pop('label')\n",
    "features = [x for x in df_train_stack.columns if x not in ['id','label']]\n",
    "oof_stack, pred_stack = lgb_model_1(df_train_stack[features],y,df_test_stack[features])\n",
    "stack_auc = roc_auc_score(y, oof_stack)\n",
    "score = str(stack_auc)[2:8]\n",
    "print('stack auc',stack_auc)\n",
    "\n",
    "res = pd.DataFrame({'id':df_test_stack['id'], 'label':1-pred_stack})\n",
    "res.to_csv(f'stack_result_{score}.csv', index=False)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "86188457",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "zhb",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.11.6"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}

'''
    with open(filename,'w') as f:
        f.write(doc)

current_dir = "/home/workspace/output"
function_file = os.path.join(current_dir,"function.py")
code_file = os.path.join(current_dir, "train.ipynb")
write(function_file)
write_ipynb(code_file)