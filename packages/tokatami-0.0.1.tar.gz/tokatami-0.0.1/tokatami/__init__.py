"""Tokatami - Python bindings for Tokatami."""

from tokatami.wrapper import hello

__version__ = "0.0.1"
__all__ = ["hello"]
