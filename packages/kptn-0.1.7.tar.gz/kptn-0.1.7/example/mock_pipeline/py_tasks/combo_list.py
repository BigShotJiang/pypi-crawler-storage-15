from kptn.util.pipeline_config import PipelineConfig


def combo_list(pipeline_config: PipelineConfig) -> list[str]:
    return [
        ("T1", "1"),
        ("T2", "2")
    ]
