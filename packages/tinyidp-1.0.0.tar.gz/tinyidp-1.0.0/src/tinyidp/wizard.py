"""
Interactive configuration wizard using dialog.

Requires: pip install tinyidp[wizard]
System requirement: dialog (brew install dialog / apt install dialog)
"""

import os
import sys


def check_dialog_available():
    """Check if dialog is available."""
    try:
        from dialog import Dialog
        # Also check if dialog binary is installed
        d = Dialog(dialog="dialog")
        return True
    except ImportError:
        print("Error: pythondialog not installed.")
        print("Install with: pip install tinyidp[wizard]")
        return False
    except Exception as e:
        print(f"Error: dialog utility not found on system.")
        print("Install with:")
        print("  macOS:  brew install dialog")
        print("  Ubuntu: sudo apt install dialog")
        print("  Fedora: sudo dnf install dialog")
        return False


def run_wizard(config_dir: str = "./config") -> bool:
    """Run the interactive configuration wizard."""
    if not check_dialog_available():
        return False

    from dialog import Dialog

    d = Dialog(dialog="dialog", autowidgetsize=True)
    d.set_background_title("TinyIDP Configuration Wizard")

    # Welcome screen
    code = d.msgbox(
        "Welcome to TinyIDP Setup!\n\n"
        "This wizard will help you configure your Identity Provider.\n\n"
        "Press OK to continue.",
        title="TinyIDP Setup",
        width=60,
        height=12
    )

    if code != d.OK:
        return False

    # Server configuration
    code, values = d.form(
        "Server Configuration",
        [
            ("Host:", 1, 1, "0.0.0.0", 1, 20, 30, 50),
            ("Port:", 2, 1, "8000", 2, 20, 10, 10),
            ("Issuer URL:", 3, 1, "http://localhost:8000", 3, 20, 40, 100),
            ("Audience:", 4, 1, "my-app", 4, 20, 30, 50),
        ],
        title="Server Settings",
        width=70,
        height=15
    )

    if code != d.OK:
        return False

    host, port, issuer, audience = values

    # OAuth Client configuration
    code, values = d.form(
        "OAuth Client Configuration\n\nConfigure the default OAuth2 client:",
        [
            ("Client ID:", 1, 1, "demo-client", 1, 20, 30, 50),
            ("Client Secret:", 2, 1, "demo-secret", 2, 20, 30, 100),
            ("Description:", 3, 1, "Default client", 3, 20, 40, 100),
        ],
        title="OAuth Client",
        width=70,
        height=13
    )

    if code != d.OK:
        return False

    client_id, client_secret, client_desc = values

    # Admin user configuration
    code, values = d.form(
        "Admin User Configuration\n\nConfigure the administrator account:",
        [
            ("Username:", 1, 1, "admin", 1, 20, 30, 50),
            ("Password:", 2, 1, "admin", 2, 20, 30, 100),
            ("Email:", 3, 1, "admin@example.org", 3, 20, 40, 100),
        ],
        title="Admin User",
        width=70,
        height=13
    )

    if code != d.OK:
        return False

    admin_user, admin_pass, admin_email = values

    # Token settings
    code, expiry = d.inputbox(
        "Token expiration in minutes:",
        init="60",
        title="Token Settings",
        width=50,
        height=10
    )

    if code != d.OK:
        return False

    # Config directory
    code, config_path = d.inputbox(
        "Configuration directory path:",
        init=config_dir,
        title="Config Location",
        width=60,
        height=10
    )

    if code != d.OK:
        return False

    # Confirmation
    summary = f"""Configuration Summary:

Server:
  Host: {host}
  Port: {port}
  Issuer: {issuer}
  Audience: {audience}

OAuth Client:
  Client ID: {client_id}
  Client Secret: {'*' * len(client_secret)}

Admin User:
  Username: {admin_user}
  Password: {'*' * len(admin_pass)}
  Email: {admin_email}

Token Expiry: {expiry} minutes
Config Path: {config_path}

Create this configuration?"""

    code = d.yesno(summary, title="Confirm", width=60, height=25)

    if code != d.OK:
        d.msgbox("Configuration cancelled.", title="Cancelled", width=40, height=7)
        return False

    # Create configuration
    try:
        _create_config(
            config_path=config_path,
            host=host,
            port=port,
            issuer=issuer,
            audience=audience,
            client_id=client_id,
            client_secret=client_secret,
            client_desc=client_desc,
            admin_user=admin_user,
            admin_pass=admin_pass,
            admin_email=admin_email,
            token_expiry=expiry,
        )

        d.msgbox(
            f"Configuration created successfully!\n\n"
            f"Files created in: {os.path.abspath(config_path)}\n\n"
            f"To start TinyIDP:\n"
            f"  tinyidp --config {config_path}\n\n"
            f"Or:\n"
            f"  TINYIDP_CONFIG_DIR={config_path} tinyidp",
            title="Success!",
            width=60,
            height=15
        )
        return True

    except Exception as e:
        d.msgbox(f"Error creating configuration:\n\n{str(e)}", title="Error", width=60, height=12)
        return False


def _create_config(
    config_path: str,
    host: str,
    port: str,
    issuer: str,
    audience: str,
    client_id: str,
    client_secret: str,
    client_desc: str,
    admin_user: str,
    admin_pass: str,
    admin_email: str,
    token_expiry: str,
) -> None:
    """Create configuration files."""
    os.makedirs(config_path, exist_ok=True)
    os.makedirs(os.path.join(config_path, "keys"), exist_ok=True)

    # users.yaml
    users_yaml = f"""# TinyIDP Users Configuration
# Generated by TinyIDP Wizard

users:
  {admin_user}:
    password: "{admin_pass}"
    email: "{admin_email}"
    identity_class: "INTERNAL"
    entitlements:
      - "ADMIN_ACCESS"
      - "USER_MANAGEMENT"
    roles:
      - "USER"
      - "ADMIN"
    tenant: "default"
    source_acl:
      - "ACL_READ"
      - "ACL_WRITE"

default_user: "{admin_user}"
"""

    with open(os.path.join(config_path, "users.yaml"), "w") as f:
        f.write(users_yaml)

    # settings.yaml
    settings_yaml = f"""# TinyIDP Settings Configuration
# Generated by TinyIDP Wizard

server:
  host: "{host}"
  port: {port}

oauth:
  issuer: "{issuer}"
  audience: "{audience}"
  token_expiry_minutes: {token_expiry}
  clients:
    - client_id: "{client_id}"
      client_secret: "{client_secret}"
      description: "{client_desc}"

saml:
  entity_id: "{issuer}/saml"
  sso_url: "{issuer}/saml/sso"
  default_acs_url: "http://localhost:8080/login/saml2/sso/tinyidp"

authority_prefixes:
  roles: "ROLE_"
  identity_class: "IDENTITY_"
  entitlements: "ENT_"
"""

    with open(os.path.join(config_path, "settings.yaml"), "w") as f:
        f.write(settings_yaml)


if __name__ == "__main__":
    run_wizard()
