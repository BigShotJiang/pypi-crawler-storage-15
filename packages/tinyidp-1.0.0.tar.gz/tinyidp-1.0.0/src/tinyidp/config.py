"""
Configuration management for TinyIDP.
Loads settings and users from YAML files.
"""

import os
import yaml
import logging
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from pathlib import Path

logger = logging.getLogger(__name__)


@dataclass
class User:
    """Represents a user in the system."""
    username: str
    password: str
    email: str = ""
    identity_class: Optional[str] = None
    entitlements: List[str] = field(default_factory=list)
    roles: List[str] = field(default_factory=list)
    tenant: str = "default"
    source_acl: List[str] = field(default_factory=list)
    # Dynamic custom attributes - any key/value pairs
    attributes: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        result = {
            "username": self.username,
            "email": self.email,
            "identity_class": self.identity_class,
            "entitlements": self.entitlements,
            "roles": self.roles,
            "tenant": self.tenant,
            "source_acl": self.source_acl,
            "attributes": self.attributes,
        }
        return result


@dataclass
class OAuthClient:
    """Represents an OAuth client."""
    client_id: str
    client_secret: str
    description: str = ""


@dataclass
class Settings:
    """Application settings."""
    # Server
    host: str = "0.0.0.0"
    port: int = 8000
    debug: bool = False

    # OAuth
    issuer: str = "http://localhost:8000"
    audience: str = "default"
    token_expiry_minutes: int = 60
    clients: List[OAuthClient] = field(default_factory=list)

    # SAML
    saml_entity_id: str = "http://localhost:8000/saml"
    saml_sso_url: str = "http://localhost:8000/saml/sso"
    default_acs_url: str = "http://localhost:8080/login/saml2/sso/samlIdp"

    # JWT
    jwt_algorithm: str = "RS256"
    keys_dir: str = "./keys"

    # Authority prefixes
    authority_prefixes: Dict[str, str] = field(default_factory=dict)

    # Allowed identity classes
    allowed_identity_classes: List[str] = field(default_factory=list)

    # Session
    secret_key: str = "dev-secret-key-change-in-production"

    # Logging
    log_level: str = "INFO"
    log_token_requests: bool = True
    log_saml_requests: bool = True


class ConfigManager:
    """Manages configuration loading and access."""

    def __init__(self, config_dir: Optional[str] = None):
        self.config_dir = Path(config_dir or self._find_config_dir())
        self.settings: Settings = Settings()
        self.users: Dict[str, User] = {}
        self.default_user: str = "admin"
        self._load_config()

    def _find_config_dir(self) -> str:
        """Find the config directory."""
        # Check environment variable
        if env_dir := os.getenv("TINYIDP_CONFIG_DIR", os.getenv("MOCK_IDP_CONFIG_DIR")):
            return env_dir

        # Check common locations
        candidates = [
            Path("./config"),
            Path("../config"),
            Path(__file__).parent.parent.parent.parent / "config",
        ]

        for candidate in candidates:
            if candidate.exists() and (candidate / "settings.yaml").exists():
                return str(candidate)

        # Default to ./config
        return "./config"

    def _load_config(self):
        """Load all configuration files."""
        self._load_settings()
        self._load_users()
        logger.info(f"Loaded configuration from {self.config_dir}")
        logger.info(f"Loaded {len(self.users)} users")

    def _load_settings(self):
        """Load settings from settings.yaml."""
        settings_file = self.config_dir / "settings.yaml"

        if not settings_file.exists():
            logger.warning(f"Settings file not found: {settings_file}, using defaults")
            self._set_default_settings()
            return

        with open(settings_file, "r") as f:
            data = yaml.safe_load(f) or {}

        server = data.get("server", {})
        oauth = data.get("oauth", {})
        saml = data.get("saml", {})
        jwt_config = data.get("jwt", {})
        session = data.get("session", {})
        logging_config = data.get("logging", {})

        # Parse OAuth clients
        clients = []
        for client_data in oauth.get("clients", []):
            clients.append(OAuthClient(
                client_id=client_data.get("client_id", ""),
                client_secret=client_data.get("client_secret", ""),
                description=client_data.get("description", ""),
            ))

        self.settings = Settings(
            # Server
            host=server.get("host", "0.0.0.0"),
            port=server.get("port", 8000),
            debug=server.get("debug", False),
            # OAuth
            issuer=oauth.get("issuer", "http://localhost:8000"),
            audience=oauth.get("audience", "default"),
            token_expiry_minutes=oauth.get("token_expiry_minutes", 60),
            clients=clients,
            # SAML
            saml_entity_id=saml.get("entity_id", "http://localhost:8000/saml"),
            saml_sso_url=saml.get("sso_url", "http://localhost:8000/saml/sso"),
            default_acs_url=saml.get("default_acs_url", "http://localhost:8080/login/saml2/sso/samlIdp"),
            # JWT
            jwt_algorithm=jwt_config.get("algorithm", "RS256"),
            keys_dir=jwt_config.get("keys_dir", "./keys"),
            # Authority prefixes
            authority_prefixes=data.get("authority_prefixes", {}),
            # Allowed identity classes
            allowed_identity_classes=data.get("allowed_identity_classes", []),
            # Session
            secret_key=session.get("secret_key", "dev-secret-key-change-in-production"),
            # Logging
            log_level=logging_config.get("level", "INFO"),
            log_token_requests=logging_config.get("log_token_requests", True),
            log_saml_requests=logging_config.get("log_saml_requests", True),
        )

    def _set_default_settings(self):
        """Set default settings with demo client."""
        self.settings = Settings(
            clients=[OAuthClient("demo-client", "demo-secret", "Default demo client")],
            authority_prefixes={
                "roles": "ROLE_",
                "identity_class": "IDENTITY_",
                "entitlements": "ENT_",
            },
            allowed_identity_classes=["INTERNAL", "EXTERNAL", "PARTNER", "SERVICE"],
        )

    def _load_users(self):
        """Load users from users.yaml."""
        users_file = self.config_dir / "users.yaml"

        if not users_file.exists():
            logger.warning(f"Users file not found: {users_file}, using defaults")
            self._set_default_users()
            return

        with open(users_file, "r") as f:
            data = yaml.safe_load(f) or {}

        self.default_user = data.get("default_user", "admin")

        for username, user_data in data.get("users", {}).items():
            # Extract known fields
            known_fields = {
                "password", "email", "identity_class", "entitlements",
                "roles", "tenant", "source_acl", "attributes"
            }

            # Get explicit attributes or collect unknown fields as attributes
            attributes = user_data.get("attributes", {})

            # Any field not in known_fields becomes an attribute (for backward compatibility)
            for key, value in user_data.items():
                if key not in known_fields and key not in attributes:
                    attributes[key] = value

            self.users[username] = User(
                username=username,
                password=user_data.get("password", ""),
                email=user_data.get("email", f"{username}@example.org"),
                identity_class=user_data.get("identity_class"),
                entitlements=user_data.get("entitlements", []),
                roles=user_data.get("roles", ["USER"]),
                tenant=user_data.get("tenant", "default"),
                source_acl=user_data.get("source_acl", []),
                attributes=attributes,
            )

    def _set_default_users(self):
        """Set default users."""
        self.users = {
            "admin": User(
                username="admin",
                password="admin",
                email="admin@example.org",
                identity_class="INTERN",
                roles=["USER", "ADMIN"],
                tenant="default",
            ),
        }

    def get_user(self, username: str) -> Optional[User]:
        """Get a user by username."""
        return self.users.get(username)

    def authenticate(self, username: str, password: str) -> Optional[User]:
        """Authenticate a user."""
        user = self.get_user(username)
        if user and user.password == password:
            return user
        return None

    def check_client(self, client_id: str, client_secret: str) -> bool:
        """Check client credentials."""
        for client in self.settings.clients:
            if client.client_id == client_id and client.client_secret == client_secret:
                return True
        return False

    def get_client(self, client_id: str) -> Optional[OAuthClient]:
        """Get a client by ID."""
        for client in self.settings.clients:
            if client.client_id == client_id:
                return client
        return None

    def reload(self):
        """Reload configuration from files."""
        self._load_config()
        logger.info("Configuration reloaded")

    def save(self):
        """Save current configuration to YAML files."""
        self._save_users()
        self._save_settings()
        logger.info(f"Configuration saved to {self.config_dir}")

    def _save_users(self):
        """Save users to users.yaml."""
        users_file = self.config_dir / "users.yaml"

        users_data = {}
        for username, user in self.users.items():
            user_dict = {
                "password": user.password,
                "email": user.email,
                "roles": user.roles,
                "tenant": user.tenant,
            }
            if user.identity_class:
                user_dict["identity_class"] = user.identity_class
            if user.entitlements:
                user_dict["entitlements"] = user.entitlements
            if user.source_acl:
                user_dict["source_acl"] = user.source_acl
            if user.attributes:
                user_dict["attributes"] = user.attributes
            users_data[username] = user_dict

        data = {
            "users": users_data,
            "default_user": self.default_user,
        }

        with open(users_file, "w") as f:
            yaml.dump(data, f, default_flow_style=False, sort_keys=False)

    def _save_settings(self):
        """Save settings to settings.yaml."""
        settings_file = self.config_dir / "settings.yaml"

        clients_data = []
        for client in self.settings.clients:
            clients_data.append({
                "client_id": client.client_id,
                "client_secret": client.client_secret,
                "description": client.description,
            })

        data = {
            "server": {
                "host": self.settings.host,
                "port": self.settings.port,
            },
            "oauth": {
                "issuer": self.settings.issuer,
                "audience": self.settings.audience,
                "token_expiry_minutes": self.settings.token_expiry_minutes,
                "clients": clients_data,
            },
            "saml": {
                "entity_id": self.settings.saml_entity_id,
                "sso_url": self.settings.saml_sso_url,
                "default_acs_url": self.settings.default_acs_url,
            },
            "authority_prefixes": self.settings.authority_prefixes,
        }

        if self.settings.allowed_identity_classes:
            data["allowed_identity_classes"] = self.settings.allowed_identity_classes

        with open(settings_file, "w") as f:
            yaml.dump(data, f, default_flow_style=False, sort_keys=False)


# Global config instance
_config: Optional[ConfigManager] = None


def get_config() -> ConfigManager:
    """Get the global config instance."""
    global _config
    if _config is None:
        _config = ConfigManager()
    return _config


def init_config(config_dir: Optional[str] = None) -> ConfigManager:
    """Initialize the global config instance."""
    global _config
    _config = ConfigManager(config_dir)
    return _config
