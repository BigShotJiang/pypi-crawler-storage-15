# Hubble Demo Script

This will enable you to flash a pre-determined set of boards and provision them with your credentials.