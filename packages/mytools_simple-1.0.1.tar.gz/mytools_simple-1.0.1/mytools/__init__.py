"""My Tools - Collection of useful functions"""

__version__ = "1.0.1"

from .utils import *
