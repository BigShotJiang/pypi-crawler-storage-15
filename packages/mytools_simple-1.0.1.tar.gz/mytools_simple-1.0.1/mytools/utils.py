"""Useful utility functions"""

def greet(name):
    """Greet someone
    
    Args:
        name (str): Person's name
    
    Returns:
        str: Greeting message
    """
    return f"Hello, {name}!"


def add(a, b):
    """Add two numbers
    
    Args:
        a (int/float): First number
        b (int/float): Second number
    
    Returns:
        int/float: Sum
    """
    return a + b


def subtract(a, b):
    """Subtract two numbers
    
    Args:
        a (int/float): First number
        b (int/float): Second number
    
    Returns:
        int/float: Difference
    """
    return a - b


def multiply(a, b):
    """Multiply two numbers
    
    Args:
        a (int/float): First number
        b (int/float): Second number
    
    Returns:
        int/float: Product
    """
    return a * b


def divide(a, b):
    """Divide two numbers
    
    Args:
        a (int/float): First number
        b (int/float): Second number
    
    Returns:
        float: Quotient
    
    Raises:
        ValueError: If b is zero
    """
    if b == 0:
        raise ValueError("Cannot divide by zero!")
    return a / b


def reverse_string(text):
    """Reverse a string
    
    Args:
        text (str): Any string
    
    Returns:
        str: Reversed string
    """
    return text[::-1]


def to_uppercase(text):
    """Convert string to uppercase
    
    Args:
        text (str): Any string
    
    Returns:
        str: Uppercase string
    """
    return text.upper()


def to_lowercase(text):
    """Convert string to lowercase
    
    Args:
        text (str): Any string
    
    Returns:
        str: Lowercase string
    """
    return text.lower()


def count_words(text):
    """Count words in a string
    
    Args:
        text (str): Any string
    
    Returns:
        int: Number of words
    """
    return len(text.split())


def is_even(number):
    """Check if a number is even
    
    Args:
        number (int): Any integer
    
    Returns:
        bool: True if even, False otherwise
    """
    return number % 2 == 0


def factorial(n):
    """Calculate factorial
    
    Args:
        n (int): Non-negative integer
    
    Returns:
        int: Factorial of n
    
    Raises:
        ValueError: If n is negative
    """
    if n < 0:
        raise ValueError("Factorial is only defined for non-negative numbers!")
    if n == 0 or n == 1:
        return 1
    result = 1
    for i in range(2, n + 1):
        result *= i
    return result


def is_palindrome(text):
    """Check if a string is a palindrome
    
    Args:
        text (str): Any string
    
    Returns:
        bool: True if palindrome, False otherwise
    """
    clean_text = text.lower().replace(" ", "")
    return clean_text == clean_text[::-1]


def celsius_to_fahrenheit(celsius):
    """Convert Celsius to Fahrenheit
    
    Args:
        celsius (float): Temperature in Celsius
    
    Returns:
        float: Temperature in Fahrenheit
    """
    return (celsius * 9/5) + 32


def fahrenheit_to_celsius(fahrenheit):
    """Convert Fahrenheit to Celsius
    
    Args:
        fahrenheit (float): Temperature in Fahrenheit
    
    Returns:
        float: Temperature in Celsius
    """
    return (fahrenheit - 32) * 5/9
