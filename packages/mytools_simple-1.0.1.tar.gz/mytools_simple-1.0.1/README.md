# MyTools

A simple collection of useful Python utility functions.

## Installation
```bash
pip install mytools-simple
```

## Usage
```python
from mytools import greet, add, reverse_string, factorial

# Greet someone
print(greet("John"))  # Hello, John!

# Math operations
print(add(5, 3))  # 8
print(multiply(4, 7))  # 28

# String operations
print(reverse_string("Python"))  # nohtyP
print(to_uppercase("hello"))  # HELLO

# Other functions
print(factorial(5))  # 120
print(is_palindrome("racecar"))  # True
print(celsius_to_fahrenheit(100))  # 212.0
```

## Available Functions

### Math Operations
- `add(a, b)` - Add two numbers
- `subtract(a, b)` - Subtract two numbers
- `multiply(a, b)` - Multiply two numbers
- `divide(a, b)` - Divide two numbers
- `factorial(n)` - Calculate factorial

### String Operations
- `greet(name)` - Greet someone
- `reverse_string(text)` - Reverse a string
- `to_uppercase(text)` - Convert to uppercase
- `to_lowercase(text)` - Convert to lowercase
- `count_words(text)` - Count words in string
- `is_palindrome(text)` - Check if palindrome

### Number Operations
- `is_even(number)` - Check if even

### Temperature Conversion
- `celsius_to_fahrenheit(celsius)` - Convert C to F
- `fahrenheit_to_celsius(fahrenheit)` - Convert F to C

## License

MIT
