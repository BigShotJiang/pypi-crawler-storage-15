__version__ = "2025.4.2"  # noqa: W292
