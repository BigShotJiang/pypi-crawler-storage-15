import numpy as np
import shapely as sp
import gdsfactory as gf # 有字体后可以不用
from dataclasses import dataclass, field
from .shape.trace import getLineLength, getAngleLine, getShiftPoint, getPoints
from .shape import pad, pad_mask, padlarge, padlarge_mask, tline_taper, tline_taper_mask, via, cpw, move, rotate
from .cell import Cell, tsv, crossover

try:
    import pandas as pd
except ImportError:
    pass

@dataclass
class RouteConfig:
    mainlayer:str = 'METB'
    masklayer:str = 'MASKB'
    vialayer:str = 'ViaB'
    tinlayer:str = 'TINB'
    cpw_w:float = 2
    cpw_s:float = 4
    cpw_style:str = 'round'
    bend_radius:float = 50
    cpw_existence:bool = True
    mask_existence:bool = True
    taper_length:float = 20
    start_type:str = 'pad'
    pad_start_ir:float = 30
    pad_start_or:float = 50
    pad_start_px:float = 50
    pad_start_style:str = 'round'
    via_start_existence:bool = True
    via_start_width:float = 40
    via_start_heigth:float = 40
    via_start_radius:float = 0
    via_start_dw:float = 0
    via_start_dh:float = 0
    via_start_style:str = 'round'
    via_start_gnd_d:float = 0
    via_start_tin_w:float = 0
    end_type:str = 'pad'
    pad_end_ir:float = 30
    pad_end_or:float = 50
    pad_end_px:float = 50
    pad_end_style:str = 'round'
    via_end_existence:bool = True
    via_end_width:float = 28
    via_end_heigth:float = 10
    via_end_radius:float = 0
    via_end_dw:float = 0
    via_end_dh:float = 20
    via_end_style:str = 'round'
    via_end_gnd_d:float = 0
    via_end_tin_w:float = 0
    cpw_ab_existence:bool = False
    cpw_ab_simu:bool = False
    cpw_ab_d0:float = 2
    cpw_ab_d1:float = 4
    cpw_ab_h0:float = 6
    cpw_ab_h1:float = 3
    cpw_ab_interval:float = 50
    cpw_ab_startcut_num:float = 1
    cpw_ab_endcut_num:float = 1

    def set_main_start(self,start_type,inner_r = 30,outer_r = 50,port_x = 50,style = 'round',taper_length = 20):
        self.start_type = start_type # 'pad' or 'taper' or None
        self.pad_start_ir = inner_r
        self.pad_start_or = outer_r
        self.pad_start_px = port_x
        self.pad_start_style = style
        self.taper_length = taper_length

    def set_via_start(self,existence,width:float=40,heigth:float=40,radius:float=0,dw:float=0,dh:float=0,style:str='round'):
        self.via_start_existence = existence
        self.via_start_width = width
        self.via_start_heigth = heigth
        self.via_start_radius = radius
        self.via_start_dw = dw
        self.via_start_dh = dh
        self.via_start_style = 'round'

    def set_main_end(self,end_type,inner_r = 30,outer_r = 50,port_x = 50,style = 'round'):
        self.end_type = end_type # 'pad' or 'padlarge' or None
        self.pad_end_ir = inner_r
        self.pad_end_or = outer_r
        self.pad_end_px = port_x
        self.pad_end_style = style

    def set_via_end(self,existence,width:float=40,heigth:float=40,radius:float=0,dw:float=0,dh:float=0,style:str='round'):
        self.via_end_existence = existence
        self.via_end_width = width
        self.via_end_heigth = heigth
        self.via_end_radius = radius
        self.via_end_dw = dw
        self.via_end_dh = dh
        self.via_end_style = 'round'

    def generate_cell(self,line:list[tuple[float,float]],route_cell:Cell|None=None,kwargs:dict=None) -> Cell:
        if isinstance(route_cell,Cell):
            cell = route_cell
        else:
            cell = Cell('route')
        startcut = 0
        endcut = 0
        if self.start_type == 'pad':
            cell.add_polygon(pad(self.pad_start_ir,self.pad_start_or,self.cpw_w,self.cpw_s,self.pad_start_px,
                                    angle=getAngleLine(line[:2])/np.pi*180,xoff=line[0][0],yoff=line[0][1],style=self.pad_start_style),self.mainlayer)
            startcut = self.pad_start_px
            if self.mask_existence:
                cell.add_polygon(pad_mask(self.pad_start_ir,self.pad_start_or,self.cpw_w,self.cpw_s,self.pad_start_px,
                                    angle=getAngleLine(line[:2])/np.pi*180,xoff=line[0][0],yoff=line[0][1],style=self.pad_start_style),self.masklayer)
        elif self.start_type == 'taper':
            cell.add_polygon(tline_taper(**kwargs,w2=self.cpw_w,s2=self.cpw_s,length=self.taper_length,
                                            angle=getAngleLine(line[:2])/np.pi*180,xoff=line[0][0],yoff=line[0][1]),self.mainlayer)
            startcut = self.taper_length
            if self.mask_existence:
                cell.add_polygon(tline_taper_mask(**kwargs,w2=self.cpw_w,s2=self.cpw_s,length=self.taper_length,
                                            angle=getAngleLine(line[:2])/np.pi*180,xoff=line[0][0],yoff=line[0][1]),self.masklayer)
        elif self.start_type == 'padlarge':
            cell.add_polygon(padlarge(self.pad_start_ir,self.pad_start_or,self.cpw_w,self.cpw_s,self.pad_start_px,
                                    angle=getAngleLine(line[:2])/np.pi*180,xoff=line[0][0],yoff=line[0][1]),self.mainlayer)
            startcut = self.pad_start_px
            if self.mask_existence:
                cell.add_polygon(padlarge_mask(self.pad_start_ir,self.pad_start_or,self.cpw_w,self.cpw_s,self.pad_start_px,
                                    angle=getAngleLine(line[:2])/np.pi*180,xoff=line[0][0],yoff=line[0][1]),self.masklayer)
                
        if self.end_type == 'pad':
            cell.add_polygon(pad(self.pad_end_ir,self.pad_end_or,self.cpw_w,self.cpw_s,self.pad_end_px,
                                    angle=getAngleLine(line[-2:])/np.pi*180+180,xoff=line[-1][0],yoff=line[-1][1],style=self.pad_end_style),self.mainlayer)
            endcut = self.pad_end_px
            if self.mask_existence:
                cell.add_polygon(pad_mask(self.pad_end_ir,self.pad_end_or,self.cpw_w,self.cpw_s,self.pad_end_px,
                                    angle=getAngleLine(line[-2:])/np.pi*180+180,xoff=line[-1][0],yoff=line[-1][1],style=self.pad_end_style),self.masklayer)
        elif self.end_type == 'padlarge':
            cell.add_polygon(padlarge(self.pad_end_ir,self.pad_end_or,self.cpw_w,self.cpw_s,self.pad_end_px,
                                    angle=getAngleLine(line[-2:])/np.pi*180+180,xoff=line[-1][0],yoff=line[-1][1]),self.mainlayer)
            endcut = self.pad_end_px
            if self.mask_existence:
                cell.add_polygon(padlarge_mask(self.pad_end_ir,self.pad_end_or,self.cpw_w,self.cpw_s,self.pad_end_px,
                                    angle=getAngleLine(line[-2:])/np.pi*180+180,xoff=line[-1][0],yoff=line[-1][1]),self.masklayer)

        if self.via_start_existence:
            if self.via_start_style == 'round':
                via_start = tsv(self.via_start_width,self.via_start_heigth,self.via_start_radius,self.via_start_dw,self.via_start_dh,
                                self.via_start_gnd_d,self.via_start_tin_w,self.via_start_tin_w,self.vialayer,self.tinlayer)
                cell.add_ref(via_start).rotate(getAngleLine(line[:2])/np.pi*180).move([line[0][0],line[0][1]])
            else:
                cell.add_polygon(via(self.via_start_width,self.via_start_heigth,self.via_start_radius,self.via_start_dw,self.via_start_dh,
                                        angle=getAngleLine(line[:2])/np.pi*180,xoff=line[0][0],yoff=line[0][1],style=self.via_start_style),self.vialayer)
            
        if self.via_end_existence:
            if self.via_end_style == 'round':
                via_end = tsv(self.via_end_width,self.via_end_heigth,self.via_end_radius,self.via_end_dw,self.via_end_dh,
                                self.via_end_gnd_d,self.via_end_tin_w,self.via_end_tin_w,self.vialayer,self.tinlayer)
                cell.add_ref(via_end).rotate(getAngleLine(line[-2:])/np.pi*180+180).move([line[-1][0],line[-1][1]])
            else:
                cell.add_polygon(via(self.via_end_width,self.via_end_heigth,self.via_end_radius,self.via_end_dw,self.via_end_dh,
                                        angle=getAngleLine(line[-2:])/np.pi*180+180,xoff=line[-1][0],yoff=line[-1][1],style=self.via_end_style),self.vialayer)
    
        if self.cpw_existence:
            cell.add_polygon(cpw(self.cpw_w,self.cpw_s,line,self.bend_radius,style=self.cpw_style,startcut=startcut,endcut=endcut),self.mainlayer)
            if self.mask_existence:
                cell.add_polygon(cpw(self.cpw_w+self.cpw_s/2,0,line,self.bend_radius,style=self.cpw_style,startcut=startcut,endcut=endcut),self.masklayer)
        
        if self.cpw_ab_existence:
            crossover_cell = crossover(self.cpw_w*2+self.cpw_s,self.cpw_ab_d0,self.cpw_ab_d1,self.cpw_ab_h0,self.cpw_ab_h1,self.cpw_ab_simu)
            wirex,wirey  = ([p[0] for p in line],[p[1] for p in line])
            points = getPoints(wirex,wirey,interval=self.cpw_ab_interval,radius=self.bend_radius)
            if self.cpw_ab_endcut_num > 0:
                points = points[self.cpw_ab_startcut_num:-self.cpw_ab_endcut_num]
            else:
                points = points[self.cpw_ab_startcut_num:]
            for point in points:
                cell.add_ref(crossover_cell).rotate(point[1]/np.pi*180).move(point[0])
                
        return cell

@dataclass
class Route:
    type:str #比特，耦合器或者读取
    internal_port:tuple[float,float] #内部端口坐标，根据坐标索引编号
    external_port:tuple[float,float] #外部端口坐标，根据坐标索引编号
    internal_name:str = '' #内部端口名
    external_name:str = '' #外部端口名
    lines:list[list[tuple[float,float]]] = field(default_factory=list)
    configs:list[RouteConfig] = field(default_factory=list)
    length:float = 0

    def add_line_config(self,line:list[tuple[float,float]],config:RouteConfig):
        self.lines.append(line)
        self.configs.append(config)
        self.length += getLineLength(line,config.bend_radius)

    def add_lines_configs(self,lines:list[list[tuple[float,float]]],configs:list[RouteConfig]):
        self.lines.extend(lines)
        self.configs.extend(configs)
        for line,config in zip(lines,configs):
            self.length += getLineLength(line,config.bend_radius)

    def generate_cell(self,net_cell:Cell|None = None):
        if isinstance(net_cell,Cell):
            cell = net_cell
        else:
            cell = Cell('route')
        cpw_w_last = 2
        cpw_s_last = 4
        for line,config in zip(self.lines,self.configs):
            config.generate_cell(line,cell,{'w1':cpw_w_last,'w2':cpw_s_last})
            cpw_w_last = config.cpw_w
            cpw_s_last = config.cpw_s
        return cell

    def set_name(self,pose_dx,pose_dy,pose_xlist,pose_ylist,pose_names,pose_message):
        pose_flag = 0      
        if pose_message == 'pad':
            for k in range(len(pose_xlist)):
                if abs(self.external_port[0] - pose_xlist[k]) < pose_dx and abs(self.external_port[1] - pose_ylist[k]) < pose_dy:
                    self.external_name = pose_names[k]
                    pose_flag = 1
                    break
        else:
            for k in range(len(pose_xlist)):
                if abs(self.internal_port[0] - pose_xlist[k]) < pose_dx and abs(self.internal_port[1] - pose_ylist[k]) < pose_dy:
                    self.internal_name = pose_names[k]
                    pose_flag = 1
                    break
        if pose_flag == 0:
            print(f'Error! Can\'t find {pose_message} port name at {self.internal_port}.')

    def update_type(self):
        if 'or' in self.type:
            if self.internal_name[0] in 'ABCD':
                self.type = 'coupler'
            else:
                self.type = 'qubit'

@dataclass
class RouteNet:
    routelist:list[Route] = field(default_factory=list)
    netlist:list = field(default_factory=list)

    def add_route(self,route:Route):
        self.routelist.append(route)

    def generate_cell(self) -> Cell:
        net_cell = Cell('route_net')
        for rt in self.routelist:
            rt.generate_cell(net_cell)
        return net_cell

    def set_netlist(self,qc_dx,qc_dy,qc_xlist,qc_ylist,qc_names,
                    ro_dx,ro_dy,ro_xlist,ro_ylist,ro_names,
                    pad_dx,pad_dy,pad_xlist,pad_ylist,pad_names):
        for rt in self.routelist:
            if rt.type == 'readout':
                rt.set_name(ro_dx,ro_dy,ro_xlist,ro_ylist,ro_names,'readout')
            else:
                rt.set_name(qc_dx,qc_dy,qc_xlist,qc_ylist,qc_names,'qubit and coupler')
            rt.set_name(pad_dx,pad_dy,pad_xlist,pad_ylist,pad_names,'pad')
            rt.update_type()

        # 建立网表并查重，遍历列表中的每个字符串
        self.netlist = [[rt.internal_name,rt.external_name,rt.type,rt.internal_port,rt.external_port,rt.length] for rt in self.routelist]
        count_dict = {}
        for elem in self.netlist:
            for string in elem[:2]:
                # 如果字符串已经在字典中，增加其计数，否则，将字符串添加到字典中，并设置其计数为1
                if string in count_dict:
                    count_dict[string] += 1
                else:
                    count_dict[string] = 1
        # 遍历字典中的每个条目,如果计数大于1，说明字符串是重复的
        for string, count in count_dict.items():
            if count > 1:
                print(f'Error! Net name {string} appears {count} times.')

    def export_netlist(self,excelname = 'netlist.xlsx'):
        df = pd.DataFrame(
            {
                "internal_name": [elem[0] for elem in self.netlist],
                "external_name": [elem[1] for elem in self.netlist],
                "line_type": [elem[2] for elem in self.netlist],
                "internal_port": [np.round(elem[3]) for elem in self.netlist],
                "external_port": [np.round(elem[4]) for elem in self.netlist],
                "wire_length": [np.round(elem[5]) for elem in self.netlist],
            }
        )
        df.to_excel(excelname, index=False)

    def export_netmap2d(self,excelname = 'netmap2d.xlsx',interval=1400):
        external_port_x = [elem[4][0] for elem in self.netlist]
        external_port_y = [elem[4][1] for elem in self.netlist]
        external_port_xmin = min(external_port_x)
        external_port_xmax = max(external_port_x)
        external_port_ymin = min(external_port_y)
        external_port_ymax = max(external_port_y)
        x_num = int(np.round((external_port_xmax-external_port_xmin)/interval)) + 1
        y_num = int(np.round((external_port_ymax-external_port_ymin)/interval)) + 1
        data = [[[] for x in range(x_num)] for y in range(y_num)]
        for elem in self.netlist:
            data[y_num - 1 - int(np.round((elem[4][1]-external_port_ymin)/interval))][int(np.round((elem[4][0]-external_port_xmin)/interval))] = elem[2]
        df = pd.DataFrame(data)
        df.to_excel(excelname, index=False)

    def add_route_mark(self,excludelayerlist,fontlayer,fontsize=20,routeavoid=10,dbuffer=30,interval=400,radius=50,grid_size=1e-3,correct = 0):
        print("start adding route mark")
        import time
        time_1 = time.time()
        validpolygons = []
        for excludelayer in excludelayerlist:
            polygons = self.get_polygons(by_spec=excludelayer,as_shapely=True)
            validpolygons.extend([polygon.buffer(0) for polygon in polygons])
        unionpolygons = sp.unary_union(validpolygons, grid_size=grid_size)

        time_2 = time.time()
        print('get merging cost time:',round(time_2-time_1,2),'s')

        mark_cell_whole =  Cell('wire_mark')

        routenum = len(self.routelist)
        routeindex = 0
        for route in self.routelist:
            for trace in route.traces:
                if trace.type == 2:
                    mark_cell = Cell('wire_mark_'+route.internal_name)
                    wirex,wirey  = ([p[0] for p in trace.line],[p[1] for p in trace.line])
                    points = getPoints(wirex,wirey,interval=interval,radius=radius)
                    nomarkzone = unionpolygons.intersection(sp.LineString(trace.line).buffer(routeavoid+dbuffer))
                    id = 1
                    for point in points:
                        # print(f"{id}:{point}:{getShiftPoint(point,2*dbuffer)}+{getShiftPoint(point,-2*dbuffer)}")
                        # 文字
                        point1 = getShiftPoint(point,routeavoid+fontsize*0.1)
                        polygon1 = move(rotate(sp.box(0,0,fontsize*0.65*3,fontsize),point[1]/np.pi*180,origin = (0,0)),point1[0],point1[1])

                        if not nomarkzone.touches(polygon1):
                            if correct:
                                unionpolygons = sp.unary_union([polygon1,unionpolygons], grid_size=grid_size)
                            text1 = gf.components.text_freetype(text = route.internal_name, size = fontsize, layer = fontlayer)
                            mark_cell.add_ref(text1).rotate(point[1]/np.pi*180).move(point1)
                        # 文字编号
                        point2 = getShiftPoint(point,-fontsize-routeavoid)
                        polygon2 = move(rotate(sp.box(0,0,fontsize*0.65*2,fontsize),point[1]/np.pi*180,origin = (0,0)),point2[0],point2[1])
                        if not nomarkzone.touches(polygon2):
                            if correct:
                                unionpolygons = sp.unary_union([polygon2,unionpolygons], grid_size=grid_size)
                            text2 = gf.components.text_freetype(text = str(id), size = fontsize, layer = fontlayer)
                            mark_cell.add_ref(text2).rotate(point[1]/np.pi*180).move(point2)
                        id = id + 1
                        
            # 收集图形，更新unionpolygons
            mark_cell_whole.add_ref(mark_cell)
            print(f"route_mark {routeindex}/{routenum}")
            routeindex = routeindex + 1

        self.add_ref(mark_cell_whole)
        return unionpolygons
    
    def export_route_mark(self,interval=400,radius=50,export_file = 'texts.json'):
        import json
        texts = []
        for route in self.routelist:
            for trace in route.traces:
                if trace.type == 2:
                    wirex,wirey  = ([p[0] for p in trace.line],[p[1] for p in trace.line])
                    points = getPoints(wirex,wirey,interval=interval,radius=radius)
                    id = 0
                    for point in points:
                        id = id + 1
                        texts.append([point[0][0]*1e3,point[0][1]*1e3,route.internal_name,id])
        fid=open(export_file,'w')
        json.dump(texts,fid)
        fid.close()

