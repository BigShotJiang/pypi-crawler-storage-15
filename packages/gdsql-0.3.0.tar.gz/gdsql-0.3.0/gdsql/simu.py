def singleton(class_):
    instances = {}
    def wrapper(*args, **kwargs):
        if class_ not in instances:
            instances[class_] = class_(*args, **kwargs)
        return instances[class_]
    return wrapper

@singleton
class MatlabEngine:
    def __init__(self):
        print("Loading matlab engine...")
        import matlab.engine
        self.eng = matlab.engine.start_matlab()

def sonnet_build_from_cell(c,cellsize,freqstart,freqstop,freqabs,output_file,output_folder='gdssimu',type='ab'):
    eng = MatlabEngine().eng
    c.write_flatten_gds(output_file,output_folder)
    if type == 'ab':
        _ = eng.gdstoson_ab(cellsize,freqstart,freqstop,freqabs,output_file,output_folder)
    elif type == 'fc':
        _ = eng.gdstoson_fc(cellsize,freqstart,freqstop,freqabs,output_file,output_folder)
    elif type == 'fc2':
        _ = eng.gdstoson_fc2(cellsize,freqstart,freqstop,freqabs,output_file,output_folder)
    elif type == 'rfsquid':
        _ = eng.gdstoson_tsv(cellsize,freqstart,freqstop,freqabs,output_file,output_folder)

def sonnet_build_from_file(cellsize,freqstart,freqstop,freqabs,gdsname,gdsfolder = None):
    eng = MatlabEngine().eng
    if gdsfolder:
        _ = eng.gdstoson_ab(cellsize,freqstart,freqstop,freqabs,gdsname,gdsfolder)
    else:
        _ = eng.gdstoson_ab(cellsize,freqstart,freqstop,freqabs,gdsname)

def ansys_assign_edge_from_position(design,position,name,excite_type = 'Source',terminal_type = 'I'):
    from pyaedt.modules.Boundary import BoundaryObject
    from collections import OrderedDict

    edge_id = design.modeler.get_edgeid_from_position(position)
    net_name = design.modeler.get_bodynames_from_position(position)

    props = OrderedDict({"Edges": [edge_id]})
    if terminal_type == 'I':
        props["TerminalType"] = "UniformCurrent"
    else:
        props["TerminalType"] = "ConstantVoltage"
    props["Net"] = net_name[0]
    bound = BoundaryObject(design, name, props, excite_type)
    if bound.create():
        design._boundaries[bound.name] = bound

def ansys_assign_face_from_position(design,position,name,excite_type = 'Source',terminal_type = 'I'):
    from pyaedt.modules.Boundary import BoundaryObject
    from collections import OrderedDict

    face_id = design.modeler.get_faceid_from_position(position)
    net_name = design.modeler.get_bodynames_from_position(position)

    if len(net_name) > 0:
        props = OrderedDict({"Faces": [face_id]})
        if terminal_type == 'I':
            props["TerminalType"] = "UniformCurrent"
        else:
            props["TerminalType"] = "ConstantVoltage"
        props["Net"] = net_name[0]
        bound = BoundaryObject(design, name, props, excite_type)
        if bound.create():
            design._boundaries[bound.name] = bound

def ansys_reconstruct_signal_sheet(design,signal_num:int):
    sheet_list = [element for element in design.modeler.sheet_names if f'signal{signal_num}_' in element]
    unite_obj = design.modeler.unite(sheet_list)
    separate_obj = design.modeler.separate_bodies(unite_obj)
    return separate_obj

def ansys_get_upper_faces_from_object(obj):
    all_faces = obj.faces
    bottom_face = obj.bottom_face_z
    return [face for face in all_faces if face != bottom_face]

def ansys_save_qmatrix(design,freq):
    import time
    timestamp = time.strftime("%y%m%d-%H%M%S")
    matrix_file_name = f'qmatrix_{timestamp}.csv'

    design.export_matrix_data(file_name=matrix_file_name,problem_type='C',freq=freq,c_unit='fF',matrix_type='Maxwell')
    from qiskit_metal.analyses.quantization.lumped_capacitive import readin_q3d_matrix
    df_cmat, units, design_variation, df_cond = readin_q3d_matrix(matrix_file_name,False)
    return df_cmat

__all__ = ['sonnet_build_from_cell',
           'sonnet_build_from_file',
           'ansys_assign_edge_from_position',
           'ansys_assign_face_from_position',
           'ansys_reconstruct_signal_sheet',
           'ansys_get_upper_faces_from_object',
           'ansys_save_qmatrix']