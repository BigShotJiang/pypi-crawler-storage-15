from __future__ import annotations

import uuid
from collections.abc import Callable
from pathlib import Path
import os

import gdstk
import numpy as np
import orjson
from omegaconf import OmegaConf

from gdsfactory.cell import cell_import_gds
from gdsfactory.component import CellSettings, Info
from gdsfactory.component_reference import ComponentReference
from gdsfactory.config import logger

from gdsfactory.constants import _glyph, _indent, _width
from gdsfactory.typings import Coordinate, LayerSpec, LayerSpecs

import gdsfactory as gf
import shapely as sp
from shapely import Point, Polygon
from shapely.prepared import prep
from shapely.ops import split, clip_by_rect

from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
from functools import partial

from .shape import via, split_polygon

class Cell(gf.Component):            
    def add_polygon(self, points, layer="METB", vertex_num = 4000, iscell = False, cellname: str = "Unnamed"):
        pdklayer = gf.pdk.get_layer(str.upper(layer)) if isinstance(layer, str) else layer
        if vertex_num > 0:
            polygon_list = split_polygon(points,vertex_num)
        else:
            polygon_list = [points]
        if iscell:
            c = Cell(cellname)
            for polygon in polygon_list:
                gf.Component.add_polygon(c, polygon, pdklayer)
            self.add_ref(c)
            return c
        else:
            return [gf.Component.add_polygon(self, polygon, pdklayer) for polygon in polygon_list]
                 
    def add_port(self,pose_x,pose_y,size_x,size_y,text,termlayer="TERM",textlayer="TEXT"):
        self.add_polygon(sp.box(pose_x-size_x/2,pose_y-size_y/2,pose_x+size_x/2,pose_y+size_y/2),layer=termlayer)
        self.add_label(text=text,position=(pose_x, pose_y),layer=textlayer)

    def get_layer_shape(self,layer):
        pdklayer = gf.pdk.get_layer(str.upper(layer)) if isinstance(layer, str) else layer
        polygons = self.get_polygons(by_spec=pdklayer,as_shapely=True)
        validpolygons = [polygon.buffer(0) for polygon in polygons]
        return sp.unary_union(validpolygons, grid_size=1e-3)

    def add_pad_text(self,xlist,ylist,names,size,layer,dx=0,dy=0):
        c = Cell('Text')
        for x,y,name in zip(xlist,ylist,names):
            c << gf.components.text(text=name, size=size, position=[x+dx, y+dy], justify='left', layer=layer)
        self.add_ref(c)
    
    def add_holes(self,xmin,ymin,xmax,ymax,excludelayerlist,layer="METB",hole_length=2,hole_interval=20,dbuffer=16,method = 2):
        if method == 1:
            validpolygons = []
            for excludelayer in excludelayerlist:
                polygons = self.get_polygons(by_spec=excludelayer,as_shapely=True)
                validpolygons.extend([polygon.buffer(dbuffer) for polygon in polygons])

            unionpolygons = sp.unary_union(validpolygons, grid_size=1e-3)

            hole_cell = Cell('hole')

            for hole_x in np.arange(xmin,xmax,hole_interval):
                holezone = sp.box(hole_x-(hole_length+1)/2,ymin,hole_x+(hole_length+1)/2,ymax) - unionpolygons
                for hole_y in np.arange(ymin,ymax,hole_interval):
                    new_hole = holezone.intersection(sp.box(hole_x-hole_length/2,hole_y-hole_length/2,hole_x+hole_length/2,hole_y+hole_length/2))
                    if new_hole.area > 0.5:
                        hole_cell.add_polygon(new_hole,layer)

        elif method == 2:
            validpolygons = []
            for excludelayer in excludelayerlist:
                polygons = self.get_polygons(by_spec=excludelayer,as_shapely=True)
                validpolygons.extend([polygon.buffer(dbuffer+hole_length/2) for polygon in polygons])

            unionpolygons = sp.unary_union(validpolygons)

            hole_cell = Cell('hole_all')

            new_hole_cell = Cell('hole')
            new_hole_cell.add_polygon(sp.box(-hole_length/2,-hole_length/2,hole_length/2,hole_length/2),layer)

            holepoints = [sp.Point(hole_x,hole_y) for hole_x in np.arange(xmin,xmax,hole_interval) for hole_y in np.arange(ymin,ymax,hole_interval)]
            
            prepared_polygon = prep(unionpolygons)

            hits = filter(lambda x:prepared_polygon.contains(x) == False, holepoints)
            truepoints = list(hits)
            for points in truepoints:
                hole_cell.add_ref(new_hole_cell).move([points.x,points.y])

        else:
            polygons = []
            for excludelayer in excludelayerlist:
                polygons.extend(self.get_polygons(by_spec=excludelayer,as_shapely=True))
    
            split_x = np.arange(xmin+hole_interval/2,xmax-hole_interval/2,hole_interval)
            split_line = []
            for k in range(len(split_x)):
                if k%2 == 0:
                    split_line.extend([(split_x[k],ymin-1),(split_x[k],ymax+1)])
                else:
                    split_line.extend([(split_x[k],ymax+1),(split_x[k],ymin-1)])

            split_result = split(sp.MultiPolygon(polygons), sp.LineString(split_line))

            polygon_nums = sp.get_num_geometries(split_result)
            polygon_sort_list = [[] for k in range(len(split_x)+1)]
            for k in range(polygon_nums):
                polygon = sp.get_geometry(split_result,k)
                polygon_sort_list[int((polygon.bounds[0] - (xmin-hole_interval/2))/hole_interval)].append(polygon)
            polygon_union_list = []
            for polygon_sort in polygon_sort_list:
                polygon_union_list.append(sp.unary_union(polygon_sort).buffer(dbuffer))

            hole_cell = Cell('hole_all')

            k = 0
            for hole_x in np.arange(xmin,xmax,hole_interval):
                holezone = sp.box(hole_x-(hole_length+1)/2,ymin,hole_x+(hole_length+1)/2,ymax) - polygon_union_list[k]
                k = k + 1
                for hole_y in np.arange(ymin,ymax,hole_interval):
                    new_hole = holezone.intersection(sp.box(hole_x-hole_length/2,hole_y-hole_length/2,hole_x+hole_length/2,hole_y+hole_length/2))
                    if new_hole.area > 0.5:
                        hole_cell.add_polygon(new_hole,layer)
        
        return hole_cell

    def add_gndvias(self,xmin,ymin,xmax,ymax,excludelayerlist,via_cell,via_width,via_interval,dbuffer=16,show_auxiliary_layer=False,method = 3) -> Cell:
        if method == 1:
            validpolygons = []
            for excludelayer in excludelayerlist:
                polygons = self.get_polygons(by_spec=excludelayer,as_shapely=True)
                validpolygons.extend([polygon.buffer() for polygon in polygons])

            unionpolygons = sp.unary_union(validpolygons, grid_size=1e-3)

            whole_cell = Cell('gndvia')

            for via_x in np.arange(xmin,xmax,via_interval):
                noviazone = unionpolygons.intersection(sp.box(via_x-(via_width+1)/2,ymin,via_x+(via_width+1)/2,ymax))
                if show_auxiliary_layer and noviazone.area > 0:
                    whole_cell.add_polygon(noviazone,'HOLE')
                if noviazone.area > 0:
                    for via_y in np.arange(ymin,ymax,via_interval):
                        if noviazone.distance(sp.Point(via_x,via_y)) > via_width/2:
                            whole_cell.add_ref(via_cell).move([via_x,via_y])
                else:
                    for via_y in np.arange(ymin,ymax,via_interval):
                        whole_cell.add_ref(via_cell).move([via_x,via_y])
        
        elif method == 2:
            validpolygons = []
            for excludelayer in excludelayerlist:
                polygons = self.get_polygons(by_spec=excludelayer,as_shapely=True)
                validpolygons.extend([polygon.buffer(dbuffer+via_width/2) for polygon in polygons])

            unionpolygons = sp.unary_union(validpolygons, grid_size=1e-3)
            viapoints = [sp.Point(via_x,via_y) for via_x in np.arange(xmin,xmax,via_interval) for via_y in np.arange(ymin,ymax,via_interval)]
            prepared_polygon = prep(unionpolygons)

            hits = filter(lambda x:prepared_polygon.contains(x) == False, viapoints)
            truepoints = list(hits)
            whole_cell = Cell('gndvia')
            for points in truepoints:
                whole_cell.add_ref(via_cell).move([points.x,points.y])

        elif method == 3:
            polygons = []
            for excludelayer in excludelayerlist:
                polygons.extend(self.get_polygons(by_spec=excludelayer,as_shapely=True))
    
            total_bound = sp.total_bounds(polygons)
            split_x = np.arange(xmin+via_interval/2,xmax-via_interval/2,via_interval)
            split_line = []
            for k in range(len(split_x)):
                if k%2 == 0:
                    split_line.extend([(split_x[k],total_bound[1]-1),(split_x[k],total_bound[3]+1)])
                else:
                    split_line.extend([(split_x[k],total_bound[3]+1),(split_x[k],total_bound[1]-1)])

            split_result = split(sp.MultiPolygon(polygons), sp.LineString(split_line))

            polygon_nums = sp.get_num_geometries(split_result)
            polygon_sort_list = [[] for k in range(len(split_x)+1)]
            for k in range(polygon_nums):
                polygon = sp.get_geometry(split_result,k)
                polygon_sort_list[int((polygon.bounds[0] - (xmin-via_interval/2))/via_interval)].append(polygon)
            polygon_union_list = []
            for polygon_sort in polygon_sort_list:
                polygon_union_list.append(sp.unary_union(polygon_sort))

            whole_cell = Cell('gndvia')

            k = 0
            for via_x in np.arange(xmin,xmax,via_interval):
                unionpolygons = polygon_union_list[k]
                k = k + 1
                noviazone = unionpolygons.intersection(sp.box(via_x-(via_width+1)/2,ymin,via_x+(via_width+1)/2,ymax))
                if show_auxiliary_layer and noviazone.area > 0:
                    whole_cell.add_polygon(noviazone,'HOLE')
                if noviazone.area > 0:
                    for via_y in np.arange(ymin,ymax,via_interval):
                        if noviazone.distance(sp.Point(via_x,via_y)) > via_width/2 + dbuffer:
                            whole_cell.add_ref(via_cell).move([via_x,via_y])
                else:
                    for via_y in np.arange(ymin,ymax,via_interval):
                        whole_cell.add_ref(via_cell).move([via_x,via_y])
        else:
            polygons = []
            for excludelayer in excludelayerlist:
                polygons.extend(self.get_polygons(by_spec=excludelayer,as_shapely=True))
    
            total_bound = sp.total_bounds(polygons)
            split_x = np.arange(xmin+via_interval/2,xmax-via_interval/2,via_interval)
            split_line = []
            for k in range(len(split_x)):
                if k%2 == 0:
                    split_line.extend([(split_x[k],total_bound[1]-1),(split_x[k],total_bound[3]+1)])
                else:
                    split_line.extend([(split_x[k],total_bound[3]+1),(split_x[k],total_bound[1]-1)])

            split_result = split(sp.MultiPolygon(polygons), sp.LineString(split_line))

            polygon_nums = sp.get_num_geometries(split_result)
            polygon_sort_list = [[] for k in range(len(split_x)+1)]
            for k in range(polygon_nums):
                polygon = sp.get_geometry(split_result,k)
                polygon_sort_list[int((polygon.bounds[0] - (xmin-via_interval/2))/via_interval)].append(polygon)

            via_x_list = np.arange(xmin,xmax,via_interval)

            whole_cell = Cell('gndvia')

            via_detect_partial = partial(via_detect,ymin = ymin,ymax = ymax,via_width = via_width,via_interval = via_interval,dbuffer = dbuffer)
            if method == 4:
                via_result = parallel_thread(via_detect_partial,polygon_sort_list,via_x_list)
            else:
                via_result = parallel_process(via_detect_partial,polygon_sort_list,via_x_list)

            for sublist in via_result:
                for via_x,via_y in sublist:
                    whole_cell.add_ref(via_cell).move([via_x,via_y])
        return whole_cell
    
    def add_bumps(self,xmin,ymin,xmax,ymax,excludelayerlist,bump_cell,bump_width,bump_interval,dbuffer=16,method=2,return_list_only:bool=False) -> Cell|list[tuple[float,float]]:
        validpolygons = []
        for excludelayer in excludelayerlist:
            polygons = self.get_polygons(by_spec=excludelayer,as_shapely=True)
            validpolygons.extend(polygons)

        if method == 1:
            split_result = split(sp.MultiPolygon(validpolygons), sp.LineString([(xmin,ymin),(xmax,ymin),(xmax,ymax),(xmin,ymax),(xmin,ymin)]))
            polygon_nums = sp.get_num_geometries(split_result)
            region = []
            for k in range(polygon_nums):
                polygon = sp.get_geometry(split_result,k)
                if polygon.bounds[0] >= xmin and polygon.bounds[1] >= ymin and polygon.bounds[2] <= xmax and polygon.bounds[3] <= ymax:
                    region.append(polygon)
        else:
            region = clip_by_rect(sp.MultiPolygon(validpolygons),xmin,ymin,xmax,ymax)

        unionpolygons = sp.unary_union(region)
        bump_region = sp.box(xmin,ymin,xmax,ymax) - unionpolygons
        polygon_list = get_boundary_polygon([bump_region],bump_interval,bump_width,bump_interval/2+dbuffer)
        point_list = get_boundary_point(polygon_list,bump_interval)
        opt_point_list = get_pruned_point(point_list,bump_interval*0.8)

        if return_list_only:
            return opt_point_list
        
        whole_cell = Cell('bumps')
        for point in opt_point_list:
            whole_cell.add_ref(bump_cell).move(point)

        return whole_cell
    
    def add_cell_text(self,cell,x,y,add_text,text_size,text_dx,text_dy,text_layer):
        self.add_ref(cell).move([x,y])
        if add_text:
            self.add_ref(text(str(x)+'\n'+str(y),text_size,(x+text_dx,y+text_dy),layer=text_layer))

    def auto_wafer(self,wafer_radius,chipsize_x,chipsize_y,chip_xshift=0,chip_yshift=0,cutgap=140,fontlayer="METB",isfontcorner=True,fontsize=200,fontgap_x=400,fontgap_y=400,text_format='num'):
        '''
            text_format  = 'num' -> 1,2,3,...
                        or 'alpha' -> a1,a2,....
                        or 'ratio' -> 1/x,2/x,...
        '''
        num_x = int(np.floor(2*wafer_radius/chipsize_x))
        num_y = int(np.floor(2*wafer_radius/chipsize_y))

        chip_array = [sp.box(x*chipsize_x,y*(chipsize_y),(x+1)*chipsize_x,(y+1)*chipsize_y) for y in range(num_y) for x in range(num_x)]

        half_num_x = np.floor(num_x/2)
        half_num_y = np.floor(num_y/2)

        wafer_list = [sp.Point((half_num_x+x/2)*chipsize_x,(half_num_y+y/2)*chipsize_y).buffer(wafer_radius) for y in range(2) for x in range(2)]

        chip_array_valid = [[] for k in range(4)]

        for wafer,chip_valid in zip(wafer_list,chip_array_valid):
            for chip in chip_array:
                if chip.within(wafer):
                    chip_valid.append(chip)

        chip_num = [len(chip_valid) for chip_valid in chip_array_valid]
        index = np.argmax(chip_num)
        chip_list = chip_array_valid[index]
        wafer = wafer_list[index]

        shift_point = wafer.centroid
        chip_center_list = [sp.affinity.translate(chip.centroid,xoff=-shift_point.x, yoff=-shift_point.y) for chip in chip_list]
        
        chipboard = Cell('chipboard')
        chipboard.add_ref(self).move([chip_xshift,chip_yshift])
        if cutgap > 0:
            cutbox = sp.box(-(chipsize_x+cutgap)/2,-(chipsize_y+cutgap)/2,(chipsize_x+cutgap)/2,(chipsize_y+cutgap)/2) - sp.box(-(chipsize_x-cutgap)/2,-(chipsize_y-cutgap)/2,(chipsize_x-cutgap)/2,(chipsize_y-cutgap)/2)
            chipboard.add_polygon(cutbox,fontlayer)
        
        wafer_cell = Cell('wafer')
        if text_format == 'num':
            id = 1
        elif text_format == 'ratio':
            id = 1
            id_num = len(chip_list) 
        else:
            min_chip_x = chip_center_list[0].x
            max_chip_y = chip_center_list[0].y
            for chip_xy in chip_center_list:
                if chip_xy.x < min_chip_x:
                    min_chip_x = chip_xy.x
                if chip_xy.y > max_chip_y:
                    max_chip_y = chip_xy.y
        fontshift_x = chipsize_x/2-fontgap_x
        fontshift_y = chipsize_y/2-fontgap_y
        for chip_xy in chip_center_list:
            wafer_cell.add_ref(chipboard).move([chip_xy.x,chip_xy.y])
            if text_format == 'num':
                text = gf.components.text(text = str(id), size = fontsize, justify = 'center', layer = fontlayer)
                id = id + 1
            elif text_format == 'ratio':
                text = gf.components.text(text = str(id)+'/'+str(id_num), size = fontsize, justify = 'center', layer = fontlayer)
                id = id + 1
            else:
                chip_label = chr(int((max_chip_y - chip_xy.y)/chipsize_x)+65) + str(int((chip_xy.x - min_chip_x)/chipsize_x)+1)
                text = gf.components.text(text = chip_label, size = fontsize, justify = 'center', layer = fontlayer)
            if isfontcorner:
                wafer_cell.add_ref(text).move([chip_xy.x+fontshift_x,chip_xy.y+fontshift_y])
                wafer_cell.add_ref(text).move([chip_xy.x+fontshift_x,chip_xy.y-fontshift_y-fontsize])
                wafer_cell.add_ref(text).move([chip_xy.x-fontshift_x,chip_xy.y+fontshift_y])
                wafer_cell.add_ref(text).move([chip_xy.x-fontshift_x,chip_xy.y-fontshift_y-fontsize])
            else:
                wafer_cell.add_ref(text).move([chip_xy.x,chip_xy.y+fontshift_y])
                wafer_cell.add_ref(text).rotate(90).move([chip_xy.x-fontshift_x,chip_xy.y])
                wafer_cell.add_ref(text).rotate(180).move([chip_xy.x,chip_xy.y-fontshift_y])
                wafer_cell.add_ref(text).rotate(270).move([chip_xy.x+fontshift_x,chip_xy.y])

        return wafer_cell

    def show_with(self,another_cell):
        c = Cell(self.name+another_cell.name)
        c.add_ref(self)
        c.add_ref(another_cell)
        c.show()

    def write_flatten_gds(self,output_file,output_folder='gdsflattened'):
        
        flatten_cell = self.flatten()
        flatten_cell.write_gds(os.path.join(output_folder,output_file))

    def add_crossover_axy(self,crossover,axy):
        for angle,x,y in axy:
             self.add_ref(crossover).rotate(angle).move((x,y))


def via_detect(polygon_sort,via_x,ymin,ymax,via_width,via_interval,dbuffer):
    result = []
    unionpolygons = sp.unary_union(polygon_sort)
    noviazone = unionpolygons.intersection(sp.box(via_x-(via_width+1)/2,ymin,via_x+(via_width+1)/2,ymax))

    if noviazone.area > 0:
        for via_y in np.arange(ymin,ymax,via_interval):
            if noviazone.distance(sp.Point(via_x,via_y)) > via_width/2 + dbuffer:
                result.append((via_x,via_y))
    else:
        for via_y in np.arange(ymin,ymax,via_interval):
            result.append((via_x,via_y))
    
    return result

def parallel_thread(func,data1,data2):
    with ThreadPoolExecutor() as executor:
        results = list(executor.map(func, data1, data2))
    return results

def parallel_process(func,data1,data2):
    with ProcessPoolExecutor() as executor:
        results = list(executor.map(func, data1, data2))
    return results

def get_boundary_polygon(polygons_list:list[Polygon],bump_interval:float,bump_width:float,margin:float=0) -> list[Polygon]:
    proper_polygon_list = []
    for polygons in polygons_list:
        polygon_num = sp.get_num_geometries(polygons)
        for k in range(polygon_num):
            polygon = sp.get_geometry(polygons,k)
            if margin > 0:
                polygon = polygon.buffer(-margin)
            # if sp.get_num_interior_rings(polygon) > 0:
            #     proper_polygon = polygon.buffer(-bump_interval/2).buffer(bump_interval/2)
            # else:
            # polygon_exterior = sp.get_exterior_ring(polygon)
            # proper_polygon = polygon.intersection(sp.Polygon(polygon_exterior).buffer(-bump_width/2).buffer(bump_width/2))
            proper_polygon = polygon
            proper_polygon_num = sp.get_num_geometries(proper_polygon)
            for kk in range(proper_polygon_num):
                proper_polygon_in = sp.get_geometry(proper_polygon,kk)
                if proper_polygon_in.area > 0:
                    proper_polygon_list.append(proper_polygon_in)
    smaller_polygon_list = []
    for polygon in proper_polygon_list:
        polygon_exterior = sp.get_exterior_ring(polygon)
        smaller_polygon = polygon.intersection(sp.Polygon(polygon_exterior).buffer(-bump_interval))
        if smaller_polygon.area > 0:
            smaller_polygon_list.append(smaller_polygon)
    if len(smaller_polygon_list) > 0:
        return proper_polygon_list+get_boundary_polygon(smaller_polygon_list,bump_interval,bump_width)
    else:
        return proper_polygon_list
    
def get_boundary_point(polygons_list:list[Polygon],bump_interval:float,precise_num:float=5) -> list[Point]:
    '''
        bigger precise_num needs longer process time
    '''
    point_list_all = []
    for polygon in polygons_list:
        ring = sp.segmentize(sp.get_exterior_ring(polygon),bump_interval/precise_num)
        points_num = sp.get_num_points(ring)
        point_list = [sp.get_point(ring,0)]
        for k in range(1,points_num):
            point = sp.get_point(ring,k)
            if sp.distance(point_list[-1],point) > bump_interval and sp.distance(point_list[0],point) > bump_interval:
                point_list.append(point)
        point_list_all.extend(point_list)
    return point_list_all

def get_pruned_point(points, d) -> list[tuple[float,float]]:
    from scipy.spatial import KDTree
    if isinstance(points[0],Point):
        points_list = [(p.x,p.y) for p in points]
    else:
        points_list = points
    # 构建kd树
    tree = KDTree(points_list)

    indices_list2 = []
    indices_list3 = []

    # 遍历每一个点
    for point in points_list:
        # 查询距离小于d的点
        indices = tree.query_ball_point(point, d)
        
        # 如果找到了这样的点，就删除这个点
        if len(indices) > 2:
            indices_list3.append(indices)
        elif len(indices) > 1:
            indices_list2.append(indices)

    delete_index_list = []
    
    if len(indices_list3) > 0:
        for indices in indices_list3:
            delete_index_list.append(find_nearest_point_index(points_list,indices))
    else:
        for indices in indices_list2:
            delete_index_list.append(indices[1])

    if len(delete_index_list) > 0:
        new_points = np.delete(points_list,delete_index_list, axis=0)
    else:
        new_points = points_list
        
    if len(indices_list3) > 0:
        return get_pruned_point(new_points,d)
    else:
        return new_points

def find_nearest_point_index(points,point_indices):
    # 初始化距离之和为无穷大
    min_distance_sum = float('inf')
    nearest_point_index = None

    # 遍历每一个点
    for i in point_indices:
        # 计算当前点到其它所有点的距离之和
        distance_sum = sum(np.linalg.norm(np.array(points[i]) - np.array(points[j])) for j in point_indices if i != j)

        # 如果当前点的距离之和小于最小距离之和，更新最小距离之和和最近的点
        if distance_sum < min_distance_sum:
            min_distance_sum = distance_sum
            nearest_point_index = i

    # 返回距离之和最小的点
    return nearest_point_index

@gf.cell
def crossover(
    w:float,
    d0:float,
    d1:float,
    h0:float,
    h1:float,
    simu:bool=False
) -> Cell:
    ''' Return a crossover cell

    Args:
        w: wire width
        d0: SiO2 width equals (w+d0*2)
        d1: Metal width equals (w+d1*2)
        h0: SiO2 along wire length
        h1: Metal along wire length
    '''
    c = Cell()
    if simu:
        c.add_polygon(via(h1,h1,style='mitre',yoff=(w+h1)/2+d0),"AB0")
        c.add_polygon(via(h1,h1,style='mitre',yoff=-(w+h1)/2-d0),"AB0")
        c.add_polygon(via(h1,w+h1*2+d0*2,style='mitre'),"AB1")
    else:
        c.add_polygon(via(h0,w+d0*2,style='mitre'),"AB0")
        c.add_polygon(via(h1,w+d1*2),"AB1")
    return c

@gf.cell
def bump(
    ubm_width:float,
    in_width:float,
    ubm_radius:float=0,
    in_radius:float=0,
    ubm_style:str='mitre',
    in_style:str='mitre'
) -> Cell:
    c = Cell()
    c.add_polygon(via(ubm_width,ubm_width,ubm_radius,style=ubm_style),'UBM')
    c.add_polygon(via(in_width,in_width,in_radius,style=in_style),'IN')
    return c

@gf.cell
def tsv(
    width:float,
    heigth:float,
    radius:float=0,
    dw:float=0,
    dh:float=0,
    gnd_d:float=0,
    tin_w:float=0,
    tin_h:float=0,
    via_layer = 'VIAB',
    tin_layer = 'TINB',
    via_style = 'round',
    tin_style = 'round'
) -> Cell:
    c = Cell()
    c.add_polygon(via(width,heigth,radius,dw,dh,style=via_style),via_layer)
    if tin_w > 0:
        if tin_h > 0:
            c.add_polygon(via(tin_w,tin_h,style=tin_style),tin_layer)
        else:
            c.add_polygon(via(tin_w,tin_w,style=tin_style),tin_layer)
    if gnd_d > 0:
        c2 = Cell()
        c2.add_ref(c)
        c2.add_array(c,2,2,(gnd_d*2,gnd_d*2)).move([-gnd_d,-gnd_d])
        return c2
    else:
        return c

@gf.cell
def text(
    text: str = "abcd",
    size: float = 10.0,
    position: Coordinate = (0, 0),
    justify: str = "left",
    layer: LayerSpec = "METB",
    layers: LayerSpecs | None = None,
) -> Cell:
    """Text shapes.

    Args:
        text: string.
        size: in um.
        position: x, y position.
        justify: left, right, center.
        layer: for the text.
        layers: optional for duplicating the text.
    """
    scaling = size / 1000
    xoffset = position[0]
    yoffset = position[1]
    t = Cell()
    layers = layers or [layer]

    for line in text.split("\n"):
        label = gf.Component()
        for c in line:
            ascii_val = ord(c)
            if c == " ":
                xoffset += 500 * scaling
            elif 33 <= ascii_val <= 126:
                for poly in _glyph[ascii_val]:
                    xpts = np.array(poly)[:, 0] * scaling
                    ypts = np.array(poly)[:, 1] * scaling
                    for layer in layers:
                        label.add_polygon([xpts + xoffset, ypts + yoffset], layer=layer)
                xoffset += (_width[ascii_val] + _indent[ascii_val]) * scaling
            else:
                raise ValueError(f"No character with ascii value {ascii_val!r}")
        t.add_ref(label)
        yoffset -= 1500 * scaling
        xoffset = position[0]
    justify = justify.lower()
    for label in t.references:
        if justify == "left":
            label.xmin = position[0]
        elif justify == "right":
            label.xmax = position[0]
        elif justify == "center":
            label.move(origin=label.center, destination=position, axis="x")
        else:
            raise ValueError(
                f"justify = {justify!r} not in ('center', 'right', 'left')"
            )
    return t.flatten()

@cell_import_gds
def import_gds(
    gdspath: str | Path,
    cellname: str | None = None,
    gdsdir: str | Path | None = None,
    read_metadata: bool = False,
    read_metadata_json: bool = False,
    keep_name_short: bool = False,
    unique_names: bool = False,
    max_name_length: int = 250,
    post_process: Callable[..., None] | None = None,
    **kwargs,
) -> Cell:
    """Returns a Component from a GDS file.

    appends $ with a number to the name if the cell name is on CACHE

    Args:
        gdspath: path of GDS file.
        cellname: cell of the name to import. None imports top cell.
        gdsdir: optional GDS directory.
        read_metadata: loads metadata (ports, settings) if it exists in YAML format.
        read_metadata_json: loads metadata (ports, settings) if it exists in JSON format.
        keep_name_short: appends a hash to a shortened component name.
        unique_names: appends $ with a number to the name if the cell name is on CACHE. \
                This avoids name collisions when importing multiple times the same cell name.
        max_name_length: maximum length of the name.
        post_process: function to post process the component after importing.
        kwargs: extra to add to component.info (polarization, wavelength ...).
    """
    gdspath = Path(gdsdir) / Path(gdspath) if gdsdir else Path(gdspath)
    if not gdspath.exists():
        raise FileNotFoundError(f"No file {str(gdspath)!r} found")

    metadata_filepath = gdspath.with_suffix(".yml")
    metadata_json_filepath = gdspath.with_suffix(".json")

    if gdspath.suffix.lower() == ".gds":
        gdsii_lib = gdstk.read_gds(str(gdspath))
    elif gdspath.suffix.lower() == ".oas":
        gdsii_lib = gdstk.read_oas(str(gdspath))
    else:
        raise ValueError(f"gdspath.suffix {gdspath.suffix!r} not .gds or .oas")

    top_level_cells = gdsii_lib.top_level()
    top_cellnames = [c.name for c in top_level_cells]

    if not top_cellnames:
        raise ValueError(f"no top cells found in {str(gdspath)!r}")

    D_list = []
    cell_name_to_component = {}
    cell_to_component = {}

    # create a new cell for each gdstk Cell
    for c in gdsii_lib.cells:
        D = Cell()
        D._cell = c
        name = f"{c.name}_{uuid.uuid4().hex[:8]}" if unique_names else c.name

        if not keep_name_short:
            max_name_length = 10000000000000
        D.rename(name, cache=unique_names, max_name_length=max_name_length)

        cell_name_to_component[c.name] = D
        cell_to_component[c] = D
        D_list += [D]

    cellnames = list(cell_name_to_component.keys())
    if cellname:
        if cellname not in cell_name_to_component:
            raise ValueError(
                f"cell {cellname!r} is not in file {gdspath} with cells {cellnames}"
            )
    elif len(top_level_cells) == 1:
        cellname = top_level_cells[0].name
    elif len(top_level_cells) > 1:
        raise ValueError(
            f"import_gds() There are multiple top-level cells in {gdspath!r}, "
            f"you must specify `cellname` to select of one of them among {cellnames}"
        )

    # create a new ComponentReference for each gdstk CellReference
    for c, D in cell_to_component.items():
        for e in c.references:
            ref_device = cell_to_component[e.cell]
            ref = ComponentReference(
                component=ref_device,
                origin=e.origin,
                rotation=e.rotation,
                magnification=e.magnification,
                x_reflection=e.x_reflection,
                columns=e.repetition.columns or 1,
                rows=e.repetition.rows or 1,
                spacing=e.repetition.spacing,
                v1=e.repetition.v1,
                v2=e.repetition.v2,
            )
            D._register_reference(ref)
            D._references.append(ref)
            ref._reference = e

    component = cell_name_to_component[cellname]

    if read_metadata and metadata_filepath.exists():
        logger.info(f"Read YAML metadata from {metadata_filepath}")
        metadata = OmegaConf.load(metadata_filepath)

        if "settings" in metadata:
            settings = OmegaConf.to_container(metadata.settings)
            if settings:
                component.settings = CellSettings(**settings)
        if "info" in metadata:
            info = OmegaConf.to_container(metadata.info)
            if info:
                component.info = Info(**info)
        if "function" in metadata:
            component.function_name = metadata.function
        if "module" in metadata:
            component.module = metadata.module

        if "ports" in metadata:
            for port_name, port in metadata.ports.items():
                if port_name not in component.ports:
                    component.add_port(
                        name=port_name,
                        center=np.array(port.center, dtype="float64"),
                        width=port.width,
                        orientation=port.orientation,
                        layer=tuple(port.layer),
                        port_type=port.port_type,
                    )

    if read_metadata_json and metadata_json_filepath.exists():
        logger.info(f"Read JSON metadata from {metadata_json_filepath}")
        metadata = orjson.loads(open(metadata_json_filepath, "rb").read())

        if "settings" in metadata:
            if metadata.get("settings", {}):
                component.settings = CellSettings(**metadata["settings"])

        if "info" in metadata:
            if metadata["info"]:
                component.info = Info(**metadata["info"])
        if "function" in metadata:
            component.function_name = metadata["function"]
        if "module" in metadata:
            component.module = metadata["module"]

        if "ports" in metadata:
            for port_name, port in metadata["ports"].items():
                if port_name not in component.ports:
                    component.add_port(
                        name=port_name,
                        center=np.array(port["center"], dtype="float64"),
                        width=port["width"],
                        orientation=port["orientation"],
                        layer=tuple(port["layer"]),
                        port_type=port["port_type"],
                    )

    for k, v in kwargs.items():
        component.info[k] = v
    component.imported_gds = True
    if post_process:
        post_process(component)
    return component

def find_consecutive_ones(lst):
    result = []
    start = None
    length = 0
    for i, num in enumerate(lst):
        if num == 1:
            if start is None:
                start = i
            length += 1
        elif num == 0 and start is not None:
            result.append((start, length))
            start = None
            length = 0
    if start is not None:
        result.append((start, length))
    return result

@gf.cell
def from_image(
    image_path: str | Path,
    nm_per_pixel: int = 20,
    layer: str | tuple[int, int] = 'METB',
    threshold: float = 0.5,
    invert: bool = True
) -> Cell:
    """Returns Component from a png image.

    Args:
        image_path: jpg/png file path.
        nm_per_pixel: scale_factor.
        layer: layer tuple to output gds.
        threshold: value along which to find contours in the array.
        invert: invert the mask. True by default.
    """
    import matplotlib.pyplot as plt

    # Load the image using matplotlib
    img = plt.imread(image_path)

    if len(img.shape) == 3:
        img = 0.2989 * img[:, :, 0] + 0.5870 * img[:, :, 1] + 0.1140 * img[:, :, 2]

    # Convert image to numpy array (in fact, plt.imread already returns a numpy array)
    img_array = np.array(img)

    threshold_v = max(max(img_array.tolist())) * threshold

    cell = Cell()
    for k in range(img_array.shape[0]):
        if invert:
            tlist = find_consecutive_ones(img_array[k] > threshold_v)
        else:
            tlist = find_consecutive_ones(img_array[k] < threshold_v)
        for telem in tlist:
            cell.add_polygon(sp.box(telem[0]*1e-3*nm_per_pixel,-k*1e-3*nm_per_pixel,(telem[0]+telem[1])*1e-3*nm_per_pixel,(-k-1)*1e-3*nm_per_pixel),layer)

    return cell