import plotly.graph_objects as go

class Viewer:
    def __init__(self):
        self.point_xlist = []
        self.point_ylist = []
        self.point_namelist = []
        self.line_xlist = []
        self.line_ylist = []
        self.line_namelist = []
        self.line_colorlist = []

    def add_points(self,xlist:list,ylist:list,pointname:str):
        self.point_xlist.append(xlist)
        self.point_ylist.append(ylist)
        self.point_namelist.append(pointname)

    def add_lines(self,wirex:list,wirey:list,wirename:str,wirecolor:str='green'):
        self.line_xlist.append(wirex)
        self.line_ylist.append(wirey)
        self.line_namelist.append(wirename)
        self.line_colorlist.append(wirecolor)

    def show(self,autosize=False, width=1200, height=800):
        datapoint = [go.Scatter(x=self.point_xlist[k], y=self.point_ylist[k], mode='markers', name=self.point_namelist[k]) for k in range(len(self.point_namelist))]
        dataline = [go.Scatter(x=self.line_xlist[k], y=self.line_ylist[k], mode='lines', name=self.line_namelist[k],line=dict(color=self.line_colorlist[k])) for k in range(len(self.line_namelist))]
        fig = go.Figure(data=dataline+datapoint)
        fig.update_yaxes(scaleanchor="x", scaleratio=1)
        fig.update_xaxes(scaleanchor="y", scaleratio=1)
        fig.update_layout(autosize=autosize, width=width, height=height)
        fig.show()
