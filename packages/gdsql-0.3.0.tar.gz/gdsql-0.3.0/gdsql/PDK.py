from gdsfactory import Pdk
from gdsfactory.technology import (
    LayerLevel,
    LayerStack,
    LayerView,
    LayerViews,
    LayerMap,
)
from gdsfactory.typings import Layer

class LayerMapFabA(LayerMap):
    TINB: Layer = (1, 0)
    METB: Layer = (2, 0)
    AB0: Layer = (3, 0)
    AB1: Layer = (4, 0)
    UBM: Layer = (5, 0)
    IN: Layer = (6, 0)
    SPACER: Layer = (7, 0)
    VIAT: Layer = (8, 0)
    TINT: Layer = (9, 0)
    METT: Layer = (10, 0)
    VIAB: Layer = (11, 0)
    MET0: Layer = (12, 0)
    VIA0: Layer = (13, 0)
    MET1: Layer = (14, 0)
    VIA1: Layer = (15, 0)
    MET2: Layer = (16, 0)
    VIA2: Layer = (17, 0)
    MET3: Layer = (18, 0)
    VIA3: Layer = (19, 0)
    MET4: Layer = (20, 0)
    UBMR: Layer = (21, 0)
    INR: Layer = (22, 0)
    BE: Layer = (23, 0)
    ALO: Layer = (24, 0)
    CE: Layer = (25, 0)
    VIA05: Layer = (26, 0)
    WL: Layer = (27, 0)
    PDAU: Layer = (28, 0)
    NTINB: Layer = (31, 0)
    NTINT: Layer = (32, 0)
    NVIA0: Layer = (33, 0)
    NVIA1: Layer = (34, 0)
    NVIA2: Layer = (35, 0)
    NVIA3: Layer = (36, 0)
    PMMA: Layer = (51, 0)
    MMA: Layer = (52, 0)
    TERM: Layer = (81, 0)
    TEXT: Layer = (82, 0)
    HOLE: Layer = (83, 0)
    WG: Layer = (84, 0)
    MASKT: Layer = (10, 1)
    MASKB: Layer = (2, 1)
    MASK0: Layer = (12, 1)
    MASK1: Layer = (14, 1)
    MASK2: Layer = (16, 1)
    MASK3: Layer = (18, 1)
    MASK4: Layer = (20, 1)
    
深蓝色="#000080"
鲜绿色="#00FF00"
橙色="#FFA500"
紫色="#800080"
靛蓝色="#4B0082"
红色="#FF0000"
浅绿色="#90EE90"
棕色="#8B4513"
粉红色="#FFC0CB"
银色="#C0C0C0"
金色="#FFD700"
天蓝色="#87CEEB"
黄色="#FFFF00"
绿色="#008000"
蓝色="#0000FF"
灰色="#808080"
青色="#00FFFF"
橄榄色="#808000"
巧克力色="#D2691E"
玫瑰红="#FF69B4"
海绿色="#20B2AA"
蓝紫色="#8A2BE2"
橙红色="#FF4500"
浅蓝色="#ADD8E6"
橙黄色="#FF8C00"
深绿色="#006400"
蓝绿色="#008080"
卡其色="#F0E68C"
褐色="#A52A2A"
蓝灰色="#778899"
粉红紫色="#FF1493"
黑鲑鱼色="#E9967A"
三文鱼色="#FA8072"
淡鲑鱼色="#FFA07A"
暗金棒色="#B8860B"

class FabALayerViews(LayerViews):
    TINB: LayerView = LayerView(color=深蓝色)
    METB: LayerView = LayerView(color=鲜绿色)
    AB0: LayerView = LayerView(color=橙色)
    AB1: LayerView = LayerView(color=紫色)
    UBM: LayerView = LayerView(color=靛蓝色)
    IN: LayerView = LayerView(color=红色)
    SPACER: LayerView = LayerView(color=浅绿色)
    VIAT: LayerView = LayerView(color=棕色)
    TINT: LayerView = LayerView(color=粉红色)
    METT: LayerView = LayerView(color=银色)
    VIAB: LayerView = LayerView(color=金色)
    MET0: LayerView = LayerView(color=天蓝色)
    VIA0: LayerView = LayerView(color=黄色)
    MET1: LayerView = LayerView(color=绿色)
    VIA1: LayerView = LayerView(color=蓝色)
    MET2: LayerView = LayerView(color=灰色)
    VIA2: LayerView = LayerView(color=青色)
    MET3: LayerView = LayerView(color=橄榄色)
    VIA3: LayerView = LayerView(color=巧克力色)
    MET4: LayerView = LayerView(color=玫瑰红)
    UBMR: LayerView = LayerView(color=海绿色)
    INR: LayerView = LayerView(color=蓝紫色)
    BE: LayerView = LayerView(color=橙红色)
    ALO: LayerView = LayerView(color=浅蓝色)
    CE: LayerView = LayerView(color=橙黄色)
    VIA05: LayerView = LayerView(color=深绿色)
    WL: LayerView = LayerView(color=蓝绿色)
    PDAU: LayerView = LayerView(color=卡其色)
    NTINB: LayerView = LayerView(color=褐色)
    NTINT: LayerView = LayerView(color=蓝灰色)
    NVIA0: LayerView = LayerView(color=粉红紫色)
    NVIA1: LayerView = LayerView(color=黑鲑鱼色)
    NVIA2: LayerView = LayerView(color=三文鱼色)
    NVIA3: LayerView = LayerView(color=淡鲑鱼色)
    PMMA: LayerView = LayerView(color=暗金棒色)
    MMA: LayerView = LayerView(color=暗金棒色)
    TERM: LayerView = LayerView(color=暗金棒色)
    TEXT: LayerView = LayerView(color=暗金棒色)
    WG: LayerView = LayerView(color=暗金棒色)

# The LayerStack uses the GDS layers to generate a representation of the chip after fabrication.
nm = 1e-3

def get_layer_stack_faba(
    thickness_wg: float = 220 * nm,
    thickness_slab_deep_etch: float = 90 * nm,
    thickness_slab_shallow_etch: float = 150 * nm,
    sidewall_angle_wg: float = 10,
    thickness_clad: float = 3.0,
    thickness_nitride: float = 350 * nm,
    thickness_ge: float = 500 * nm,
    gap_silicon_to_nitride: float = 100 * nm,
    zmin_heater: float = 1.1,
    zmin_metal1: float = 1.1,
    thickness_metal1: float = 700 * nm,
    zmin_metal2: float = 2.3,
    thickness_metal2: float = 700 * nm,
    zmin_metal3: float = 3.2,
    thickness_metal3: float = 2000 * nm,
    substrate_thickness: float = 10.0,
    box_thickness: float = 3.0,
    undercut_thickness: float = 5.0,
) -> LayerStack:
    """Returns generic LayerStack.

    based on paper https://www.degruyter.com/document/doi/10.1515/nanoph-2013-0034/html

    Args:
        thickness_wg: waveguide thickness in um.
        thickness_slab_deep_etch: for deep etched slab.
        thickness_shallow_etch: thickness for the etch.
        sidewall_angle_wg: waveguide side angle.
        thickness_clad: cladding thickness in um.
        thickness_nitride: nitride thickness in um.
        thickness_ge: germanium thickness.
        gap_silicon_to_nitride: distance from silicon to nitride in um.
        zmin_heater: TiN heater.
        zmin_metal1: metal1.
        thickness_metal1: metal1 thickness.
        zmin_metal2: metal2.
        thickness_metal2: metal2 thickness.
        zmin_metal3: metal3.
        thickness_metal3: metal3 thickness.
        substrate_thickness: substrate thickness in um.
        box_thickness: bottom oxide thickness in um.
        undercut_thickness: thickness of the silicon undercut.
    """

    thickness_deep_etch = thickness_wg - thickness_slab_deep_etch
    thickness_shallow_etch = thickness_wg - thickness_slab_shallow_etch

    return LayerStack(
        layers=dict(
            substrate=LayerLevel(
                layer=LAYER.BE,
                thickness=substrate_thickness,
                zmin=-substrate_thickness - box_thickness,
                material="si",
                mesh_order=101,
                background_doping={"concentration": "1E14", "ion": "Boron"},
                orientation="100",
            ),
            box=LayerLevel(
                layer=LAYER.WAFER,
                thickness=box_thickness,
                zmin=-box_thickness,
                material="sio2",
                mesh_order=9,
            ),
            core=LayerLevel(
                layer=LAYER.WG,
                thickness=thickness_wg,
                zmin=0.0,
                material="si",
                mesh_order=2,
                sidewall_angle=sidewall_angle_wg,
                width_to_z=0.5,
                background_doping_concentration=1e14,
                background_doping_ion="Boron",
                orientation="100",
                info={"active": True},
            ),
            shallow_etch=LayerLevel(
                layer=LAYER.SHALLOW_ETCH,
                thickness=thickness_shallow_etch,
                zmin=0.0,
                material="si",
                mesh_order=1,
                layer_type="etch",
                into=["core"],
                derived_layer=LAYER.SLAB150,
            ),
            deep_etch=LayerLevel(
                layer=LAYER.DEEP_ETCH,
                thickness=thickness_deep_etch,
                zmin=0.0,
                material="si",
                mesh_order=1,
                layer_type="etch",
                into=["core"],
                derived_layer=LAYER.SLAB90,
            ),
            clad=LayerLevel(
                # layer=LAYER.WGCLAD,
                layer=LAYER.WAFER,
                zmin=0.0,
                material="sio2",
                thickness=thickness_clad,
                mesh_order=10,
            ),
            slab150=LayerLevel(
                layer=LAYER.SLAB150,
                thickness=150e-3,
                zmin=0,
                material="si",
                mesh_order=3,
            ),
            slab90=LayerLevel(
                layer=LAYER.SLAB90,
                thickness=thickness_slab_deep_etch,
                zmin=0.0,
                material="si",
                mesh_order=2,
            ),
            nitride=LayerLevel(
                layer=LAYER.WGN,
                thickness=thickness_nitride,
                zmin=thickness_wg + gap_silicon_to_nitride,
                material="sin",
                mesh_order=2,
            ),
            ge=LayerLevel(
                layer=LAYER.GE,
                thickness=thickness_ge,
                zmin=thickness_wg,
                material="ge",
                mesh_order=1,
            ),
            undercut=LayerLevel(
                layer=LAYER.UNDERCUT,
                thickness=-undercut_thickness,
                zmin=-box_thickness,
                material="air",
                z_to_bias=(
                    [0, 0.3, 0.6, 0.8, 0.9, 1],
                    [-0, -0.5, -1, -1.5, -2, -2.5],
                ),
                mesh_order=1,
            ),
            via_contact=LayerLevel(
                layer=LAYER.VIAC,
                thickness=zmin_metal1 - thickness_slab_deep_etch,
                zmin=thickness_slab_deep_etch,
                material="Aluminum",
                mesh_order=1,
                sidewall_angle=-10,
                width_to_z=0,
            ),
            metal1=LayerLevel(
                layer=LAYER.M1,
                thickness=thickness_metal1,
                zmin=zmin_metal1,
                material="Aluminum",
                mesh_order=2,
            ),
            heater=LayerLevel(
                layer=LAYER.HEATER,
                thickness=750e-3,
                zmin=zmin_heater,
                material="TiN",
                mesh_order=2,
            ),
            via1=LayerLevel(
                layer=LAYER.VIA1,
                thickness=zmin_metal2 - (zmin_metal1 + thickness_metal1),
                zmin=zmin_metal1 + thickness_metal1,
                material="Aluminum",
                mesh_order=1,
            ),
            metal2=LayerLevel(
                layer=LAYER.M2,
                thickness=thickness_metal2,
                zmin=zmin_metal2,
                material="Aluminum",
                mesh_order=2,
            ),
            via2=LayerLevel(
                layer=LAYER.VIA2,
                thickness=zmin_metal3 - (zmin_metal2 + thickness_metal2),
                zmin=zmin_metal2 + thickness_metal2,
                material="Aluminum",
                mesh_order=1,
            ),
            metal3=LayerLevel(
                layer=LAYER.M3,
                thickness=thickness_metal3,
                zmin=zmin_metal3,
                material="Aluminum",
                mesh_order=2,
            ),
        )
    )

LAYER = LayerMapFabA()
LAYER_VIEWS = FabALayerViews(layer_map=dict(LAYER))
# LAYER_STACK = get_layer_stack_faba()

def get_PDK():
    PDK = Pdk(
        name="FabA",
        layers=dict(LAYER),
        layer_views=LAYER_VIEWS,
        # layer_stack=LAYER_STACK
        )
    return PDK