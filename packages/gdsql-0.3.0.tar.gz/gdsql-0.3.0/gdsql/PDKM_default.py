import numpy as np
from dataclasses import dataclass, field
from shapely import Polygon
from .cell import Cell, crossover, text, tsv, import_gds, from_image
from .shape import (via, rectangle, capacitor_cg, capacitor_square, capacitor_interdigited_narrow, capacitor_interdigited_squared, 
                cpw, strip, tline, magic_T, shape_union, flip_x, flip_y, move, rotate, embeded, snake_rgl, snake_rgls, 
                pocket_c, pocket_c_mask, snake_port, snake_port2, octagon, clip_by_rect, trace, jj_nb_area, pad_square, pad_square_empty, cross)
from .qlibrary import MLibrary
import os
import gdsfactory as gf
import time
from .version import __version__

mark_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)),'mark')

@dataclass
class MarkDemo(MLibrary):
    gds_name:str = 'demo.gds'
    layer_change:bool = False
    layer:str|tuple[int,int] = 'METB'
    layer_mask:str|tuple[int,int] = 'MASKB'
    position_x:list[float] = field(default_factory=lambda: [24000,-24000,24000,-24000])
    position_y:list[float] = field(default_factory=lambda: [24000,24000,-24000,-24000])
    text_size:int = 40
    text_dx:float = 300
    text_dy:float = 300

    def generate_cell(self):
        pdklayer = gf.pdk.get_layer(str.upper(self.layer)) if isinstance(self.layer, str) else self.layer
        gdspath = os.path.join(mark_dir,self.gds_name)
        c = import_gds(gdspath)
        if self.layer_change:
            return gf.geometry.union(c, by_layer=False, layer=pdklayer)
        return c

    def group_cell(self,add_mask=False,add_text=False):
        group = Cell('MarkDemo')
        cell = self.generate_cell()
        for x,y in zip(self.position_x,self.position_y):
            group.add_ref(cell).move([x,y])
            if add_text:
                group.add_ref(text(str(x)+'\n'+str(y),self.text_size,(x+self.text_dx,y+self.text_dy),layer=self.layer))
        return group

@dataclass
class MarkLogo(MLibrary):
    image_name:str = 'ustc.png'
    nm_per_pixel:int = 20
    layer:str|tuple[int,int] = 'METB'
    layer_mask:str|tuple[int,int] = 'maskB'
    threshold:float = 0.5
    invert:bool = True
    position_x:list[float] = field(default_factory=lambda: [-24000])
    position_y:list[float] = field(default_factory=lambda: [0])

    def generate_cell(self):
        imagepath = os.path.join(mark_dir,self.image_name)
        c = from_image(imagepath,self.nm_per_pixel,self.layer,self.threshold,self.invert)
        return c

    def group_cell(self,add_mask=False):
        group = Cell('MarkLogo')
        cell = self.generate_cell()
        for x,y in zip(self.position_x,self.position_y):
            group.add_ref(cell).move([x,y])
        return group

@dataclass
class MarkVersion(MLibrary):
    layout_name:str = 'Test'
    layout_version:str = 'v1'
    layout_authors:str = 'ABC'
    title_position:tuple[float,float] = (0,0)
    title_size:float = 200
    authors_position:tuple[float,float] = (0,-200)
    authors_size:float = 100
    gdsql_position:tuple[float,float] = (0,-350)
    gdsql_size:float = 100
    add_logo:bool = True
    logo_image:str = 'ustc.png'
    logo_nm_per_pixel:int = 500
    logo_threshold:float = 0.5
    logo_invert:bool = True
    logo_position:tuple[float,float] = (-800,250)
    layer:str|tuple[int,int] = 'METB'
    layer_mask:str|tuple[int,int] = 'MASKB'
    position_x:list[float] = field(default_factory=lambda: [-18000])
    position_y:list[float] = field(default_factory=lambda: [200])

    def generate_cell(self):
        c = Cell('MarkVersion')
        text_title = f'{self.layout_name}_{self.layout_version}_{time.strftime("%y%m%d", time.localtime())}'
        text_authors = f'designed by {self.layout_authors}'
        text_gdsql = f'edited by gdsql {__version__}'
        cell_title = text(text_title,self.title_size,layer=self.layer)
        cell_authors = text(text_authors,self.authors_size,layer=self.layer)
        cell_gdsql = text(text_gdsql,self.gdsql_size,layer=self.layer)

        c.add_polygon(move(rectangle(0,-0.3*self.title_size,0.8*len(text_title)*self.title_size,self.title_size),xoff=self.title_position[0],yoff=self.title_position[1]),self.layer_mask)
        c.add_ref(cell_title).move(self.title_position)
        c.add_polygon(move(rectangle(0,-0.3*self.authors_size,0.8*len(text_authors)*self.authors_size,self.authors_size),xoff=self.authors_position[0],yoff=self.authors_position[1]),self.layer_mask)
        c.add_ref(cell_authors).move(self.authors_position)
        c.add_polygon(move(rectangle(0,-0.3*self.gdsql_size,0.8*len(text_gdsql)*self.gdsql_size,self.gdsql_size),xoff=self.gdsql_position[0],yoff=self.gdsql_position[1]),self.layer_mask)
        c.add_ref(cell_gdsql).move(self.gdsql_position)
        if self.add_logo:
            imagepath = os.path.join(mark_dir,self.logo_image)
            logo = from_image(imagepath,self.logo_nm_per_pixel,self.layer,self.logo_threshold,self.logo_invert)
            logo_shape = logo.get_layer_shape(self.layer)
            c.add_polygon(move(logo_shape.minimum_rotated_rectangle,xoff=self.logo_position[0],yoff=self.logo_position[1]),self.layer_mask)
            c.add_ref(logo).move(self.logo_position)
        return c
    
    def group_cell(self):
        group = Cell('MarksVersion')
        cell = self.generate_cell()
        for x,y in zip(self.position_x,self.position_y):
            group.add_ref(cell).move([x,y])
        return group

@dataclass
class MarkAlignmentFC(MLibrary):
    block1_w:float = 100
    block1_h:float = 100
    block1_x:float = 100
    block1_y:float = 100
    block2_w:float = 100
    block2_h:float = 50
    block2_x:float = 300
    block2_y:float = 75
    layer:str|tuple[int,int] = 'MET1'
    layer_mask:str|tuple[int,int] = 'mask1'
    mark_x:float = 24342
    mark_y:float = 24342
    mark_gap:float = -1013
    text_size:int = 40
    text_dx:float = 200
    text_dy:float = 300

    def generate_cell(self):
        c = Cell('MarkAlignmentFC')
        block1 = via(self.block1_w,self.block1_h,xoff=self.block1_x,yoff=self.block1_y,style='mitre')
        block2 = via(self.block2_w,self.block2_h,xoff=self.block2_x,yoff=self.block2_y,style='mitre')
        block1s = flip_y(flip_x(block1,origin=(0,0),duplicate=True),origin=(0,0),duplicate=True)
        block2s = flip_y(flip_x(block2,origin=(0,0),duplicate=True),origin=(0,0),duplicate=True)
        c.add_polygon(block1s,layer=self.layer)
        c.add_polygon(block2s,layer=self.layer)
        c.add_polygon(rotate(block2s,90),layer=self.layer)
        return c

    def group_cell(self,add_text=False):
        group = Cell('MarkAlignmentsFC')
        cell = self.generate_cell()
        for x in [-self.mark_x,self.mark_x]:
            for y in [-self.mark_y,self.mark_y]:
                group.add_cell_text(cell,x,y,add_text,self.text_size,self.text_dx,self.text_dy,self.layer)
                if x > 0:
                    if y > 0:
                        group.add_cell_text(cell,x+self.mark_gap,y,add_text,self.text_size,self.text_dx,self.text_dy,self.layer)
                        group.add_cell_text(cell,x,y+self.mark_gap,add_text,self.text_size,self.text_dx,self.text_dy,self.layer)
                    else:
                        group.add_cell_text(cell,x+self.mark_gap,y,add_text,self.text_size,self.text_dx,self.text_dy,self.layer)
                        group.add_cell_text(cell,x,y-self.mark_gap,add_text,self.text_size,self.text_dx,self.text_dy,self.layer)
                else:
                    if y > 0:
                        group.add_cell_text(cell,x-self.mark_gap,y,add_text,self.text_size,self.text_dx,self.text_dy,self.layer)
                        group.add_cell_text(cell,x,y+self.mark_gap,add_text,self.text_size,self.text_dx,self.text_dy,self.layer)
                    else:
                        group.add_cell_text(cell,x-self.mark_gap,y,add_text,self.text_size,self.text_dx,self.text_dy,self.layer)
                        group.add_cell_text(cell,x,y-self.mark_gap,add_text,self.text_size,self.text_dx,self.text_dy,self.layer)

        return group

@dataclass
class MarkAlignmentFC2c(MLibrary):
    width_1:float = 2
    width_2:float = 4
    gap:float = 0.5
    box_a:float = 42
    box_a2:float = 180
    layer_b:str|tuple[int,int] = 'METB'
    layer_t:str|tuple[int,int] = 'METT'
    layer_b_mask:str|tuple[int,int] = 'maskB'
    layer_t_mask:str|tuple[int,int] = 'maskT'
    position_x:list[float] = field(default_factory=lambda: [11200,-11200,11200,-11200])
    position_y:list[float] = field(default_factory=lambda: [9800,9800,-9800,-9800])
    text_size:int = 20
    text_dx:float = 60
    text_dy:float = 60

    def generate_cell(self):
        c_b = Cell('MarkAlignmentFC_bottom')
        c_t = Cell('MarkAlignmentFC_top')
        bar1 = via(self.box_a,self.width_1,style='mitre')
        bar2 = via(self.width_2,self.box_a,xoff=self.box_a/2+self.width_2/2,style='mitre')
        bar3 = via((self.box_a2-self.box_a)/2,self.width_2,xoff=(self.box_a2+self.box_a)/4,style='mitre')
        
        bar23 = shape_union([bar2,bar3])
        bar23fc = flip_x(bar23,origin=(0,0),duplicate=True)
        bar23fcr = rotate(bar23fc,90)
        frame1_bottom = shape_union([bar23fc,bar23fcr])
        frame2_bottom = shape_union([bar1,rotate(bar1,90)])
        
        c_b.add_polygon(frame1_bottom,layer=self.layer_b)
        c_b.add_polygon(frame2_bottom,layer=self.layer_b)

        block1 = rectangle(self.width_1/2+self.gap,self.width_1/2+self.gap,self.box_a/2-self.gap,self.box_a/2-self.gap)
        block2 = rectangle(self.width_2+self.box_a/2,self.width_2/2+self.gap,self.box_a2/2,self.width_2/2*3+self.gap)
        block3 = rectangle(self.width_2/2+self.gap,self.width_2+self.box_a/2,self.width_2/2*3+self.gap,self.box_a2/2)
        block_union = shape_union([block1,block2,block3])
        block_all = flip_y(flip_x(block_union,origin=(0,0),duplicate=True),origin=(0,0),duplicate=True)

        c_t.add_polygon(block_all,layer=self.layer_t)

        mask_shape = via(self.box_a2,self.box_a2,style='mitre')
        c_b.add_polygon(mask_shape,layer=self.layer_b_mask)
        c_t.add_polygon(mask_shape,layer=self.layer_t_mask)
        return [c_b,c_t]

    def group_cell(self,add_text=False):
        group_b = Cell('MarkAlignmentsFC_bottom')
        group_t = Cell('MarkAlignmentsFC_top')
        [c_b,c_t] = self.generate_cell()
        for x,y in zip(self.position_x,self.position_y):
            group_b.add_cell_text(c_b,x,y,add_text,self.text_size,self.text_dx,self.text_dy,self.layer_b)
            group_t.add_cell_text(c_t,x,y,add_text,self.text_size,self.text_dx,self.text_dy,self.layer_t)
        return [group_b,group_t]

@dataclass
class MarkAlignmentTSV(MLibrary):
    via_radius:float = 5
    via_dx:list[float] = field(default_factory=lambda: [30,70,120,180,250,330])
    layer_via:str|tuple[int,int] = 'viab'
    layer_others:list[str] = field(default_factory=lambda: ['metb','met0'])
    layer_mask:str|tuple[int,int] = 'maskb'
    position_x:list[float] = field(default_factory=lambda: [44000,42000,42000,44000,42000,42000,-44000,-42000,-42000,-44000,-42000,-42000,0,54000,0,-54000])
    position_y:list[float] = field(default_factory=lambda: [52000,52000,54000,-52000,-52000,-54000,52000,52000,54000,-52000,-52000,-54000,54000,0,-54000,0])

    def generate_cell(self):
        c = Cell('MarkAlignmentTSV')
        circle = via(self.via_radius*2,self.via_radius*2)
        circle_list1 = [move(circle,xoff=dx) for dx in self.via_dx]
        circle_list2 = [move(circle,xoff=dx,yoff=dx) for dx in self.via_dx]
        circle_union = shape_union(circle_list1+circle_list2)
        circle_union2 = rotate(circle_union,90,origin=(0,0))
        circle_union3 = rotate(circle_union,180,origin=(0,0))
        circle_union4 = rotate(circle_union,270,origin=(0,0))
        circle_union_all = shape_union([circle,circle_union,circle_union2,circle_union3,circle_union4])
        c.add_polygon(circle_union_all,layer=self.layer_via)
 
        bar_0 = via(self.via_radius*2,self.via_radius*2,style='mitre')
        bar_list = []
        for k, dx in enumerate(self.via_dx):
            if k == 0:
                bar_list.append(rectangle(dx/2,-dx-self.via_radius,dx+self.via_radius,dx+self.via_radius))
            else:
                bar_list.append(rectangle((dx+self.via_dx[k-1])/2,-dx-self.via_radius,dx+self.via_radius,dx+self.via_radius))
        
        bar_union = shape_union(bar_list)
        frame = flip_x(bar_union,origin=(0,0),duplicate=True)
        frame2 = rotate(frame,90)
        frame_union = shape_union([bar_0,frame,frame2])

        for layer in self.layer_others:
            c.add_polygon(frame_union,layer)
        return c

    def group_cell(self):
        group = Cell('MarkAlignmentsTSV')
        cell = self.generate_cell()
        for x,y in zip(self.position_x,self.position_y):
            group.add_ref(cell).move([x,y])
        return group

@dataclass
class MarkAlignmentCross(MLibrary):
    length_base:float = 600
    width_base:float = 10
    gap_delta:float = 2
    block_w:float = 1200
    block_h:float = 600
    block_r:float = 4
    block_dx:float = 1000
    cross_gap:float = 3000
    cross_x:float = 43000
    cross_y:float = 53000
    via_radius:float = 5
    layer_list:list[str] = field(default_factory=lambda: ['viab','tinb','metb'])
    foolproof_circle_r:float = 600
    foolproof_circle_dx:float = 1500

    def generate_cell(self):
        c = Cell('MarkAlignmentCross')
        for k in range(len(self.layer_list)):
            c.add_polygon(cross(self.length_base+self.gap_delta*k*2,self.width_base+self.gap_delta*k*2),layer=self.layer_list[k])

        block = Cell('MarkAlignmentCrossB')
        block_shape = via(self.block_w,self.block_h,self.block_r,xoff=self.block_dx)
        block_shape_flip = flip_x(block_shape,origin=(0,0),duplicate=True)
        block_shape_union = shape_union([block_shape_flip,rotate(block_shape_flip,90)])

        for k in range(1,len(self.layer_list)):
            block.add_polygon(block_shape_union,layer=self.layer_list[k])

        fpc = Cell('MarkAlignmentCrossFP')
        fpc_shape = via(self.foolproof_circle_r*2,self.foolproof_circle_r*2,
                        xoff=-self.cross_x-self.foolproof_circle_dx,yoff=self.cross_y+self.foolproof_circle_dx)
        for k in range(1,len(self.layer_list)):
            fpc.add_polygon(fpc_shape,layer=self.layer_list[k])
        
        return [c,block,fpc]

    def group_cell(self):
        group = Cell('MarkAlignmentsCross')
        [cell,block,fpc] = self.generate_cell()
        group.add_ref(fpc)
        for x in [-self.cross_x,self.cross_x]:
            for y in [-self.cross_y,self.cross_y]:
                group.add_ref(cell).move([x,y])
                group.add_ref(block).move([x,y])
                if x > 0:
                    if y > 0:
                        group.add_ref(cell).move([x+self.cross_gap,y])
                        group.add_ref(cell).move([x,y+self.cross_gap])
                    else:
                        group.add_ref(cell).move([x+self.cross_gap,y])
                        group.add_ref(cell).move([x,y-self.cross_gap])
                else:
                    if y > 0:
                        group.add_ref(cell).move([x-self.cross_gap,y])
                        group.add_ref(cell).move([x,y+self.cross_gap])
                    else:
                        group.add_ref(cell).move([x-self.cross_gap,y])
                        group.add_ref(cell).move([x,y-self.cross_gap])
        return group
    
@dataclass
class MarkAlignmentSpacer(MLibrary):
    radius:float = 25
    interval:float = 100
    layer:str|tuple[int,int] = 'SPACER'
    left_x_start:float = -11300
    left_x_end:float = -11000
    left_y_start:float = -9000
    left_y_end:float = 9000
    right_x_start:float = 11000
    right_x_end:float = 11300
    right_y_start:float = -9000
    right_y_end:float = 9000
    
    def generate_cell(self):
        c = Cell('MarkAlignmentSpacer')
        c.add_polygon(via(self.radius*2,self.radius*2),layer=self.layer)
        return c

    def group_cell(self,add_text=False):
        group = Cell('MarkAlignmentsSpacer')
        cell = self.generate_cell()
        for x in np.arange(self.left_x_start+self.radius,self.left_x_end-self.radius,self.interval):
            for y in np.arange(self.left_y_start+self.radius,self.left_y_end-self.radius,self.interval):
                group.add_ref(cell).move([x,y])
        for x in np.arange(self.right_x_start+self.radius,self.right_x_end-self.radius,self.interval):
            for y in np.arange(self.right_y_start+self.radius,self.right_y_end-self.radius,self.interval):
                group.add_ref(cell).move([x,y])
        return group
    
__all__ = ['MarkDemo',
           'MarkLogo',
           'MarkVersion',
           'MarkAlignmentFC',
           'MarkAlignmentFC2c',
           'MarkAlignmentTSV',
           'MarkAlignmentCross',
           'MarkAlignmentSpacer']