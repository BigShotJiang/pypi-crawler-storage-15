from abc import ABC, abstractmethod
from copy import copy

class QLibrary(ABC): 
    def clone(self):
        return copy(self)
    
    @abstractmethod
    def generate_shape(self):
        pass

    @abstractmethod
    def generate_mask(self):
        pass
    
    @abstractmethod
    def generate_cell(self):
        pass

    @abstractmethod
    def simulate_cell(self):
        pass

class MLibrary(ABC):
    def clone(self):
        return copy(self)
    
    @abstractmethod
    def generate_cell(self):
        pass

    @abstractmethod
    def group_cell(self):
        pass