import numpy as np
import shapely as sp
from shapely import Point, LineString, Polygon
from shapely.ops import clip_by_rect, split
from . import trace
from .basic import move,rotate,flip_x,flip_y,shape_union,embeded,exterior,rectangle,octagon,easy_polygon,split_polygon

def anyshape():
	pass