import numpy as np
import shapely as sp
from shapely import Point, LineString, Polygon
from . import trace
from .basic import move,rotate,flip_x,flip_y,shape_union,strip,tline,cpw_cavity

def filter_sector(l,w,s,theta,r) -> Polygon:
    angles = np.linspace((np.pi-theta)/2,(np.pi+theta)/2,32)
    x = [0]+[np.cos(angle)*r for angle in angles]
    y = [0]+[np.sin(angle)*r for angle in angles]
    sector_in = Polygon(zip(x,y))

    angles = np.linspace((np.pi-theta)/2-np.arcsin(w/(w+r)),(np.pi+theta)/2+np.arcsin(w/(w+r)),32)
    x = [0]+[np.cos(angle)*(r+w) for angle in angles]
    y = [-w/np.sin(theta/2)]+[np.sin(angle)*(r+w) for angle in angles]
    sector_out = Polygon(zip(x,y))

    tran_in = Polygon(zip((-l/2,l/2,l/2,-l/2),(-s/2,-s/2,s/2,s/2)))
    tran_out = Polygon(zip((-l/2,l/2,l/2,-l/2),(-s/2-w,-s/2-w,s/2+w,s/2+w)))

    sector = sector_out-sector_in-tran_in
    tran = tran_out-tran_in-sector_in

    output = sp.union(sector,tran)
    return output

def filter_stub(l,w,s,sw,ss,so,l1,l2,isSingle) -> Polygon:
    stub1_in = Polygon(zip((-ss/2,ss/2,ss/2,l2-ss/2,l2-ss/2,-ss/2),(0,0,s/2+w+l1-ss,s/2+w+l1-ss,s/2+w+l1,s/2+w+l1)))
    stub1_out = Polygon(zip((-ss/2-sw,ss/2+sw,ss/2+sw,l2-ss/2+so,l2-ss/2+so,-ss/2-sw),(0,0,s/2+w+l1-ss-sw,s/2+w+l1-ss-sw,s/2+w+l1+sw,s/2+w+l1+sw)))

    tran_in = Polygon(zip((-l/2,l/2,l/2,-l/2),(-s/2,-s/2,s/2,s/2)))
    tran_out = Polygon(zip((-l/2,l/2,l/2,-l/2),(-s/2-w,-s/2-w,s/2+w,s/2+w)))

    stub1 = stub1_out - stub1_in - tran_in
    tran = tran_out-tran_in-stub1_in

    polylist = []
    if not isSingle:
        stub2_in = sp.affinity.scale(stub1_in, yfact=-1, origin=(0,0))
        stub2_out = sp.affinity.scale(stub1_out, yfact=-1, origin=(0,0))

        stub2 = stub2_out - stub2_in - tran_in
        tran = tran - stub2_in
        polylist.append(stub2)
    polylist.extend([stub1,tran])

    output = sp.unary_union(polylist)
    return output

def snake_hb(w,s,len_total,len_parallel,len_start,bend_radius,startgap=0,endgap=0,flip_x = False,flip_y = False,xoff = 0,yoff = 0) -> Polygon:
    t1 = trace.snake_hb(len_total,len_parallel,len_start,bend_radius,flip_x,flip_y,xoff,yoff)
    return cpw_cavity(w,s,t1,radius=bend_radius,angle=0,xoff=0,yoff=0,style='round',startgap=startgap,endgap=endgap)

def snake_port(w,s,start_point,end_point,length,radius,starth,endh,turnup = True) -> Polygon:
    t1 = trace.snake_port(start_point,end_point,length,radius,starth,endh,turnup = turnup)
    return tline(w,s,t1,radius=radius,angle=0,xoff=0,yoff=0,style='round',startcut = 0,endcut = 0)
    
def snake_port2(w,s,start_point,end_point,length,radius,starth,endh,turnlength) -> Polygon:
    t1 = trace.snake_port2(start_point,end_point,length,radius,starth,endh,turnlength)
    return tline(w,s,t1,radius=radius,angle=0,xoff=0,yoff=0,style='round',startcut = 0,endcut = 0)

def snake_port3(w,s,start_point,end_point,length,radius,starth,endh,turnlength) -> Polygon:
    t1 = trace.snake_port3(start_point,end_point,length,radius,starth,endh,turnlength)
    return tline(w,s,t1,radius=radius,angle=0,xoff=0,yoff=0,style='round',startcut = 0,endcut = 0)

def inductor_long(s,length,parallelnum,bendh,starth,turnup = True,x_now = 0,y_now = 0) -> Polygon:
    points = trace.inductor_long(length,parallelnum,bendh,starth,turnup,x_now,y_now)
    line = LineString(points)
    output = line.buffer(s/2,cap_style='flat',join_style='bevel')
    return output

def inductor_loop(s,length,sgap,sbox,starth,endh,x_now = 0,y_now = 0) -> Polygon:
    points = trace.inductor_loop(length,sgap,sbox,starth,endh,x_now = 0,y_now = 0)
    line = LineString(points)
    output = line.buffer(s/2,cap_style='flat',join_style='bevel')
    return output


def snake_rgl(w,s,turn_r,len_r,len_gl,len_to_gl,len_to_capa,num_turn_half,end_y=None,printDif = False) -> Polygon:
    if end_y == None:
        len_cav = (len_r-(len_to_gl-turn_r)-(len_to_capa-turn_r)-turn_r*np.pi*(num_turn_half+1)+turn_r)/(num_turn_half+0.5) + turn_r * 2
        len_cav = np.floor(len_cav/2)*2
        end_y = len_cav/2
    else:
        
        if num_turn_half%2 == 0:
            len_cav = (len_r-(len_to_gl-turn_r)-(len_to_capa-turn_r)-turn_r*np.pi*(num_turn_half+1) - (end_y-turn_r*2))/num_turn_half + turn_r * 2
        else:
            len_cav = (len_r-(len_to_gl-turn_r)-(len_to_capa-turn_r)-turn_r*np.pi*(num_turn_half+1) + end_y)/(num_turn_half+1) + turn_r * 2
        len_cav = np.floor(len_cav/2)*2
    
    line_1 = [(0,0),(len_to_gl,0)]
    x_now = len_to_gl
    y_now = 0
    for k in range(num_turn_half):
        if k%2 == 0:
            line_1.extend([(x_now,y_now+len_cav),(x_now+2*turn_r,y_now+len_cav)])
        else: 
            line_1.extend([(x_now,y_now),(x_now+2*turn_r,y_now)])
        x_now = x_now+2*turn_r
    line_1.extend([(x_now,end_y),(x_now+len_to_capa,end_y)])

    if printDif:
        [cav_1,len_r_draw] = tline(w,s,line_1,radius=turn_r,startcut=s/2,returnLength=True)
        print(f'len_rl:{len_r_draw}-{len_r}={len_r_draw-len_r}')
    else:
        cav_1= tline(w,s,line_1,radius=turn_r,startcut=s/2)

    magicT_1 = magic_T(w,s,0,0,1)

    if len_gl < len_cav:
        line_gl = [(0,0),(0,len_gl)]
    else:
        len_gap = turn_r * 3.5 + (w*2+s)/4
        len_cav_gl = len_cav - len_gap
        num_div, len_mod = divmod((len_gl - turn_r - len_gap), (len_cav_gl - 2*turn_r + turn_r * np.pi))

        num_turn_gl1, num_mod = [int(ii) for ii in divmod(num_div, 2)]

        line_gl = [(0,0),(0,len_gap)]

        x_now = 0
        y_now = len_gap
        for k in range(num_turn_gl1):
            line_gl.extend([(x_now,y_now+len_cav_gl),(x_now-turn_r*2,y_now+len_cav_gl),(x_now-turn_r*2,y_now),(x_now-turn_r*4,y_now)])
            x_now = x_now-turn_r*4
        if num_mod == 1:
            line_gl.extend([(x_now,y_now+len_cav_gl),(x_now-turn_r*2,y_now+len_cav_gl),(x_now-turn_r*2,y_now+len_cav_gl-len_mod-turn_r)])
            x_now = x_now-turn_r*2
        else:
            line_gl.extend([(x_now,y_now+len_mod)])

    if printDif:
        [cav_gl,len_gl_draw] = tline(w,s,line_gl,radius=turn_r,startcut=s/2,returnLength=True)
        print(f'len_gl:{len_gl_draw}-{len_gl}={len_gl_draw-len_gl}')
    else:
        cav_gl = tline(w,s,line_gl,radius=turn_r,startcut=s/2)

    output = sp.unary_union([cav_1,magicT_1,cav_gl])
    return output

def snake_rgls(w,s,turn_r_capa,turn_r_gl,len_r,len_gl,len_to_capa,len_to_gl,gl_flip = False) -> Polygon:
    len_s = len_r - len_to_capa - np.round(np.pi*turn_r_capa) + turn_r_capa
    len_gs = len_gl - np.round(np.pi/2*turn_r_gl) - len_to_gl

    line_points = [(0,0),(len_s,0),(len_s,-turn_r_capa*2),(len_s+turn_r_capa+len_to_capa,-turn_r_capa*2)]

    ky = -1 if gl_flip else 1

    if len_gs > 0:
        line_points2 = [(0,ky*(s/2+w)),(0,ky*(s/2+w+len_to_gl+turn_r_gl)),(turn_r_gl+len_gs,ky*(s/2+w+len_to_gl+turn_r_gl))]
    else:
        line_points2 = [(0,ky*(s/2+w)),(0,ky*(s/2+w+len_gl))]

    if gl_flip:
        output = shape_union([tline(w,s,line_points,radius=turn_r_capa,startcut = s/2),
                            tline(w,s,line_points2,radius=turn_r_gl),
                            flip_y(magic_T(w,s,0,0,len_to_gl),(0,0))])
    else:
        output = shape_union([tline(w,s,line_points,radius=turn_r_capa,startcut = s/2),
                            tline(w,s,line_points2,radius=turn_r_gl),
                            magic_T(w,s,0,0,len_to_gl)])
    return output

def snake_cavity(cav_width,len_to_qubit,len_to_filter,len_to_gap,len_tune,len_cav,len_tail,num_turn,turn_r,xoff=0,yoff=0) -> Polygon:
    line1 = [(0,0),(0,-len_to_qubit),(-len_to_filter,-len_to_qubit),(-len_to_filter,-len_to_qubit-len_to_gap)]
    cav_line1 = tline(cav_width,cav_width*2,line1,radius = turn_r)
    cav_line1to2 = strip(cav_width,[(-len_to_filter+cav_width*3/2,-len_to_qubit-len_to_gap+cav_width),
                                       (-len_to_filter+cav_width*3/2,-len_to_qubit-len_to_gap-cav_width*3)])
    line2 = [(-len_to_filter,-len_to_qubit-len_to_gap-cav_width*2),
                (-len_to_filter,-len_to_qubit-len_to_gap-cav_width*2-len_to_gap),
                (len_tune,-len_to_qubit-len_to_gap-cav_width*2-len_to_gap)]
    x_now = len_tune
    y_now = -len_to_qubit-len_to_gap-cav_width*2-len_to_gap
    for k in range(num_turn):
        line2.extend([(x_now+len_cav/2,y_now),
                        (x_now+len_cav/2,y_now-turn_r*2),
                        (x_now-len_cav/2,y_now-turn_r*2),
                        (x_now-len_cav/2,y_now-turn_r*4)])
        y_now = y_now - turn_r*4
    line2.append((x_now+len_tail,y_now))
    cav_line2 = tline(cav_width,cav_width*2,line2,radius = turn_r)
    output = sp.unary_union([cav_line1,cav_line1to2,cav_line2])
    return move(output,xoff,yoff)

def magic_T(w_horizontal,s_horizontal,len_left,len_right,len_up,w_vertical=None,s_vertical=None,angle=0,xoff=0,yoff=0) -> Polygon:
    if w_vertical == None:
        w_vertical = w_horizontal
    if s_vertical == None:
        s_vertical = s_horizontal
    if len_left == 0:
        line_LL = [(-w_vertical/2-s_vertical/2,s_horizontal/2),
                    (-w_vertical/2-s_vertical/2,w_horizontal/2+s_horizontal/2+len_up)]
        dlen_left = w_vertical/2
    else:
        line_LL = [(-len_left-w_vertical/2-s_vertical/2,w_horizontal/2+s_horizontal/2),
                    (-w_vertical/2-s_vertical/2,w_horizontal/2+s_horizontal/2),
                    (-w_vertical/2-s_vertical/2,w_horizontal/2+s_horizontal/2+len_up)]
        dlen_left = len_left
    if len_right == 0:
        line_RL = [(w_vertical/2+s_vertical/2,s_horizontal/2),
                    (w_vertical/2+s_vertical/2,w_horizontal/2+s_horizontal/2+len_up)]
        dlen_right =  w_vertical/2
    else:
        line_RL = [(len_right+w_vertical/2+s_vertical/2,w_horizontal/2+s_horizontal/2),
                    (w_vertical/2+s_vertical/2,w_horizontal/2+s_horizontal/2),
                    (w_vertical/2+s_vertical/2,w_horizontal/2+s_horizontal/2+len_up)]
        dlen_right = len_right
    strip_LL = strip(w_horizontal,line_LL,style='mitre')
    strip_RL = strip(w_horizontal,line_RL,style='mitre')
    strip_DL = strip(w_horizontal,[(-dlen_left-w_vertical/2-s_vertical/2,-w_horizontal/2-s_horizontal/2),
                                (dlen_right+w_vertical/2+s_vertical/2,-w_horizontal/2-s_horizontal/2)
                                ],style='mitre')
    output = sp.unary_union([strip_LL,strip_RL,strip_DL])
    return move(rotate(output,angle,origin=(0,0)),xoff,yoff)
