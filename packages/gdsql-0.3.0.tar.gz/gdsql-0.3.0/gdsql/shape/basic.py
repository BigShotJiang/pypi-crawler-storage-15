import numpy as np
import shapely as sp
from shapely import Point, LineString, Polygon
from shapely.ops import clip_by_rect, split
from . import trace

def move(polygon:Polygon,xoff=0.0,yoff=0.0) -> Polygon:
    if abs(xoff) > 0 or abs(yoff) > 0:
        return sp.affinity.translate(polygon,xoff=xoff,yoff=yoff)
    else:
        return polygon
    
def rotate(polygon:Polygon,angle,origin = 'center') -> Polygon:
    if abs(angle) > 0:
        return sp.affinity.rotate(polygon,angle = angle,origin = origin)
    else:
        return polygon
    
def flip_x(polygon:Polygon,origin = 'center',duplicate = False) -> Polygon:
    output = sp.affinity.scale(polygon, xfact=-1.0, origin=origin)
    if duplicate:
        return sp.unary_union([polygon,output])
    else:
        return output

def flip_y(polygon:Polygon,origin = 'center',duplicate = False) -> Polygon:
    output = sp.affinity.scale(polygon, yfact=-1.0, origin=origin)
    if duplicate:
        return sp.unary_union([polygon,output])
    else:
        return output
    
def scale(polygon:Polygon,factor:float) -> Polygon:
    output = sp.affinity.scale(polygon, xfact=factor, yfact=factor)
    return output

def shape_union(polygons:list[Polygon]) -> Polygon:
    return sp.unary_union(polygons)

def embeded(polygonlist:Polygon | list[Polygon],dminx=0,dminy=0,dmaxx=0,dmaxy=0) -> Polygon | list[Polygon]:
    bound = sp.total_bounds(polygonlist)
    box = sp.box(bound[0]-dminx,bound[1]-dminy,bound[2]+dmaxx,bound[3]+dmaxy)
    if isinstance(polygonlist,list):
        return [box-polygon for polygon in polygonlist]
    else:
        return box-polygonlist
    
def exterior(polygon:Polygon) -> Polygon:
    return Polygon(sp.get_exterior_ring(polygon))

def easy_polygon(line:list[tuple[float,float]]) -> Polygon:
    return Polygon(line)

def split_polygon(polygon:Polygon,vertex_num=4000) -> list[Polygon]:
    result_polygon = []
    if isinstance(polygon,list) or isinstance(polygon,np.ndarray):
        polygon = Polygon(polygon)
    else:
        origin_polygon_nums = sp.get_num_geometries(polygon)
        for kk in range(origin_polygon_nums):
            origin_polygon = sp.get_geometry(polygon,kk)
            if sp.get_num_coordinates(origin_polygon) > vertex_num:
                bounds = origin_polygon.bounds
                xmin = np.round(bounds[0])
                ymin = np.round(bounds[1])
                xmax = np.round(bounds[2])
                ymax = np.round(bounds[3])
                if ymax - ymin > xmax - xmin:
                    split_line = LineString([(xmin-1,(ymax + ymin)/2),(xmax+1,(ymax + ymin)/2)])
                else:
                    split_line = LineString([((xmax + xmin)/2,ymin-1),((xmax + xmin)/2,ymax+1)])

                split_result = split(origin_polygon,split_line)

                polygon_nums = sp.get_num_geometries(split_result)
                for k in range(polygon_nums):
                    polygon_a = sp.get_geometry(split_result,k)
                    result_polygon.extend(split_polygon(polygon_a,vertex_num))
            else:
                result_polygon.append(origin_polygon)
    return result_polygon

def via(width:float,heigth:float,radius:float=0,dw:float=0,dh:float=0,angle:float=0,xoff:float=0,yoff:float=0,style:str='round') -> Polygon:
    if style == 'round':
        if radius == 0:
            if width > heigth:
                r = heigth/2
                p1 = LineString([(-width/2+r,0),(width/2-r,0)])
            elif width < heigth:
                r = width/2
                p1 = LineString([(0,-heigth/2+r),(0,heigth/2-r)])
            else:
                r = heigth/2
                p1 = Point(0,0)
        else:
            r = radius
            p1 = sp.box(-width/2+r,-heigth/2+r,width/2-r,heigth/2-r)
        p1list = [move(p1,dw/2*k,dh/2*kk) for k in [1,-1] for kk in [1,-1]]
        p1s = sp.unary_union(p1list)
        output = p1s.buffer(r)
    else:
        p1 = sp.box(-width/2,-heigth/2,width/2,heigth/2)
        p1list = [move(p1,dw/2*k,dh/2*kk) for k in [1,-1] for kk in [1,-1]]
        output = sp.unary_union(p1list)
    return move(rotate(output,angle,(0,0)),xoff,yoff)

def rectangle(xmin,ymin,xmax,ymax) -> Polygon:
    return sp.box(xmin,ymin,xmax,ymax)

def octagon(width,heigth,width_narrow,heigth_narrow,angle=0,xoff=0,yoff=0) -> Polygon:
    output = sp.convex_hull(sp.unary_union([sp.box(-width/2,-heigth_narrow/2,width/2,heigth_narrow/2),sp.box(-width_narrow/2,-heigth/2,width_narrow/2,heigth/2)]))
    return move(rotate(output,angle),xoff,yoff)

def hexagon(width,angle=0,xoff=0,yoff=0) -> Polygon:
    aw = width/2
    ah = width/2*np.sqrt(3)
    output = Polygon([(-aw,-ah),(aw,-ah),(width,0),(aw,ah),(-aw,ah),(-width,0)])
    return move(rotate(output,angle),xoff,yoff)

def cross(length,width,angle=0,xoff=0,yoff=0) -> Polygon:
    box1 = sp.box(-length/2,-width/2,length/2,width/2)
    box2 = sp.box(-width/2,-length/2,width/2,length/2)
    output = sp.unary_union([box1,box2])
    return move(rotate(output,angle),xoff,yoff)

def strip(s,line,radius=50,angle=0,xoff=0,yoff=0,style='round',startcut=0,endcut=0,returnLength = False) -> Polygon | list[Polygon,float]:
    return tline(s/2,0,line,radius,angle,xoff,yoff,style,startcut,endcut,returnLength)

def cpw(w,s,line,radius=50,angle=0,xoff=0,yoff=0,style='round',startcut = 0,endcut = 0,returnLength = False) -> Polygon | list[Polygon,float]:
    return tline(w,s,line,radius,angle,xoff,yoff,style,startcut,endcut,returnLength)
    
def tline(w,s,line,radius=50,angle=0,xoff=0,yoff=0,style='round',startcut=0,endcut=0,returnLength = False) -> Polygon | list[Polygon,float]:
    if startcut != 0:
        legrate = 1 - startcut/trace.getDistanceLine(line[:2])
        line_start = (line[1][0]+(line[0][0]-line[1][0])*legrate,line[1][1]+(line[0][1]-line[1][1])*legrate)
    else:
        line_start = line[0]
    if endcut != 0:
        legrate = 1 - endcut/trace.getDistanceLine(line[-2:])
        line_end = (line[-2][0]+(line[-1][0]-line[-2][0])*legrate,line[-2][1]+(line[-1][1]-line[-2][1])*legrate)
    else:
        line_end = line[-1]
    localline = [line_start]+line[1:-1]+[line_end]
    if style == 'round':
        wirex,wirey  = ([p[0] for p in localline],[p[1] for p in localline])
        [wireSequence,wireLength] = trace.getSequence(wirex,wirey,0,radius=radius)
        coords = []

        x_0 = wirex[0]
        y_0 = wirey[0]
        angle_0 = wireSequence[0]
        coords.append((x_0,y_0))
        x_0 = x_0 + wireSequence[1]*np.cos(angle_0)
        y_0 = y_0 + wireSequence[1]*np.sin(angle_0)
        coords.append((x_0,y_0))

        for kk in range(1,int(len(wireSequence)/2)):
            npoints=int(abs(wireSequence[2*kk]/np.pi*180/10))+2
            if wireSequence[2*kk] > 0:
                x_c = x_0 - radius * np.sin(angle_0)
                y_c = y_0 + radius * np.cos(angle_0)
                x_0 = x_c + radius * np.sin(angle_0+wireSequence[2*kk])
                y_0 = y_c - radius * np.cos(angle_0+wireSequence[2*kk])
                for theta in range(npoints+1):
                    coords.append((x_c + radius*np.sin(angle_0+theta*wireSequence[2*kk]/npoints),y_c - radius*np.cos(angle_0+theta*wireSequence[2*kk]/npoints)))
            else:
                x_c = x_0 + radius * np.sin(angle_0)
                y_c = y_0 - radius * np.cos(angle_0)
                x_0 = x_c - radius * np.sin(angle_0+wireSequence[2*kk])
                y_0 = y_c + radius * np.cos(angle_0+wireSequence[2*kk])
                for theta in range(npoints+1):
                    coords.append((x_c - radius*np.sin(angle_0+theta*wireSequence[2*kk]/npoints),y_c + radius*np.cos(angle_0+theta*wireSequence[2*kk]/npoints)))
            angle_0 = angle_0 + wireSequence[2*kk]
            x_0 = x_0 + wireSequence[2*kk+1]*np.cos(angle_0)
            y_0 = y_0 + wireSequence[2*kk+1]*np.sin(angle_0)
            coords.append((x_0,y_0))
        linestring = LineString(coords)
        if s == 0:
            output = linestring.buffer(w,cap_style='flat')
        else:
            output = linestring.buffer(s/2+w,cap_style='flat') - linestring.buffer(s/2,cap_style='square')
    else:
        linestring = LineString(localline)
        if s == 0:
            output = linestring.buffer(w,cap_style='flat',join_style='mitre')
        else:
            output = linestring.buffer(s/2+w,cap_style='flat',join_style='mitre') - linestring.buffer(s/2,cap_style='square',join_style='mitre')
        wireLength = 0
        for k in range(1,len(localline)):
            wireLength = wireLength + trace.getDistanceLine(localline[k-1:k+1])
    if returnLength:
        return [move(rotate(output,angle),xoff,yoff),wireLength+startcut+endcut]
    else:
        return move(rotate(output,angle),xoff,yoff)
    
def tline_taper(w1,s1,w2,s2,length,angle=0,xoff=0,yoff=0) -> Polygon:
    if s1 == 0 and s2 == 0:
        output = Polygon(zip((0,length,length,0),(-w1,-w2,w2,w1)))
    else:
        p1 = Polygon(zip((0,length,length,0),(-w1-s1/2,-w2-s2/2,-s2/2,-s1/2)))
        p2 = Polygon(zip((0,length,length,0),(w1+s1/2,w2+s2/2,s2/2,s1/2)))
        output = sp.unary_union([p1,p2])
    return move(rotate(output,angle,origin=(0,0)),xoff,yoff)

def tline_taper_mask(w1,s1,w2,s2,length,angle=0,xoff=0,yoff=0) -> Polygon:
    output = Polygon(zip((0,length,length,0),(-w1,-w2,w2+s2/2,w1+s1/2)))
    return move(rotate(output,angle,origin=(0,0)),xoff,yoff)

def cpw_cavity(w,s,line,radius=50,angle=0,xoff=0,yoff=0,style='round',startgap = 0,endgap = 0) -> Polygon:
    if startgap != 0:
        legrate = 1 - startgap/trace.getDistanceLine(line[:2])
        line_start = (line[1][0]+(line[0][0]-line[1][0])*legrate,line[1][1]+(line[0][1]-line[1][1])*legrate)
    else:
        line_start = line[0]
    if endgap != 0:
        legrate = 1 - endgap/trace.getDistanceLine(line[-2:])
        line_end = (line[-2][0]+(line[-1][0]-line[-2][0])*legrate,line[-2][1]+(line[-1][1]-line[-2][1])*legrate)
    else:
        line_end = line[-1]
    localline = [line_start]+line[1:-1]+[line_end]
    if style == 'round':
        wirex,wirey  = ([p[0] for p in localline],[p[1] for p in localline])
        [wireSequence,wireLength] = trace.getSequence(wirex,wirey,0,radius=radius)
        coords = []

        x_0 = wirex[0]
        y_0 = wirey[0]
        angle_0 = wireSequence[0]
        coords.append((x_0,y_0))
        x_0 = x_0 + wireSequence[1]*np.cos(angle_0)
        y_0 = y_0 + wireSequence[1]*np.sin(angle_0)
        coords.append((x_0,y_0))

        for kk in range(1,int(len(wireSequence)/2)):
            npoints=int(abs(wireSequence[2*kk]/np.pi*180/10))+2
            if wireSequence[2*kk] > 0:
                x_c = x_0 - radius * np.sin(angle_0)
                y_c = y_0 + radius * np.cos(angle_0)
                x_0 = x_c + radius * np.sin(angle_0+wireSequence[2*kk])
                y_0 = y_c - radius * np.cos(angle_0+wireSequence[2*kk])
                for theta in range(npoints+1):
                    coords.append((x_c + radius*np.sin(angle_0+theta*wireSequence[2*kk]/npoints),y_c - radius*np.cos(angle_0+theta*wireSequence[2*kk]/npoints)))
            else:
                x_c = x_0 + radius * np.sin(angle_0)
                y_c = y_0 - radius * np.cos(angle_0)
                x_0 = x_c - radius * np.sin(angle_0+wireSequence[2*kk])
                y_0 = y_c + radius * np.cos(angle_0+wireSequence[2*kk])
                for theta in range(npoints+1):
                    coords.append((x_c - radius*np.sin(angle_0+theta*wireSequence[2*kk]/npoints),y_c + radius*np.cos(angle_0+theta*wireSequence[2*kk]/npoints)))
            angle_0 = angle_0 + wireSequence[2*kk]
            x_0 = x_0 + wireSequence[2*kk+1]*np.cos(angle_0)
            y_0 = y_0 + wireSequence[2*kk+1]*np.sin(angle_0)
            coords.append((x_0,y_0))
        linestring = LineString(coords)
        output = linestring.buffer(s/2+w,cap_style='flat') - linestring.buffer(s/2,cap_style='square')
    else:
        linestring = LineString(localline)
        output = linestring.buffer(s/2+w,cap_style='flat',join_style='mitre') - linestring.buffer(s/2,cap_style='square',join_style='mitre')
    if startgap != 0:
        startgap_shape = LineString([line[0],line_start]).buffer(s/2+w,cap_style='flat')
        output = sp.unary_union([output,startgap_shape])
    if endgap != 0:
        endgap_shape = LineString([line_end,line[-1]]).buffer(s/2+w,cap_style='flat')
        output = sp.unary_union([output,endgap_shape])
    return move(rotate(output,angle),xoff,yoff)