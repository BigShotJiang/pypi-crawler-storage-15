import numpy as np
import shapely as sp
from shapely import Point, LineString, Polygon
from . import trace
from .basic import move,rotate,flip_x,flip_y,exterior,rectangle,cpw,strip,tline_taper,tline_taper_mask

def pocket(pad_width,pad_heigth,pad_gap,pad_ground_l,pad_ground_h,angle = 0.0,xoff = 0.0,yoff = 0.0,pad_radius = 0.0,style = 'round') -> Polygon:
    if style == 'round':
        if abs(pad_radius) > 0:
            mid_radius = pad_radius
            c1 = sp.box(-pad_width/2+mid_radius,pad_gap/2+mid_radius,pad_width/2-mid_radius,pad_gap/2+pad_heigth-mid_radius)
            c2 = sp.box(-pad_width/2+mid_radius,-(pad_gap/2+pad_heigth)+mid_radius,pad_width/2-mid_radius,-pad_gap/2-mid_radius)
        else:
            mid_radius = pad_heigth/2
            c1 = LineString([(-pad_width/2+mid_radius,(pad_gap+pad_heigth)/2),(pad_width/2-mid_radius,(pad_gap+pad_heigth)/2)])
            c2 = LineString([(-pad_width/2+mid_radius,-(pad_gap+pad_heigth)/2),(pad_width/2-mid_radius,-(pad_gap+pad_heigth)/2)])
    else:
        mid_radius = 0
        c1 = sp.box(-pad_width/2,pad_gap/2,pad_width/2,pad_gap/2+pad_heigth)
        c2 = sp.box(-pad_width/2,-(pad_gap/2+pad_heigth),pad_width/2,-pad_gap/2)
    pad1 = c1.buffer(mid_radius,cap_style='round')
    pad2 = c2.buffer(mid_radius,cap_style='round')
    box = sp.box(-pad_width/2-pad_ground_l,-pad_gap/2-pad_heigth-pad_ground_h,pad_width/2+pad_ground_l,pad_gap/2+pad_heigth+pad_ground_h)
    output = box - pad1 - pad2
    return move(rotate(output,angle,(0,0)),xoff,yoff)

def pocket_c(pad_width,pad_heigth,pad_gap,pad_ground_l,pad_ground_h,
             coupler_width,coupler_heigth,coupler_cdx,coupler_cdy,coupler_s,
             angle = 0.0,xoff = 0.0,yoff = 0.0,pad_radius = 0.0,style = 'round') -> Polygon:
    if style == 'round':
        if abs(pad_radius) > 0:
            mid_radius = pad_radius
            c1 = sp.box(-pad_width/2+mid_radius,pad_gap/2+mid_radius,pad_width/2-mid_radius,pad_gap/2+pad_heigth-mid_radius)
            c2 = sp.box(-pad_width/2+mid_radius,-(pad_gap/2+pad_heigth)+mid_radius,pad_width/2-mid_radius,-pad_gap/2-mid_radius)
        else:
            mid_radius = pad_heigth/2
            c1 = LineString([(-pad_width/2+mid_radius,(pad_gap+pad_heigth)/2),(pad_width/2-mid_radius,(pad_gap+pad_heigth)/2)])
            c2 = LineString([(-pad_width/2+mid_radius,-(pad_gap+pad_heigth)/2),(pad_width/2-mid_radius,-(pad_gap+pad_heigth)/2)])
    else:
        mid_radius = 0
        c1 = sp.box(-pad_width/2,pad_gap/2,pad_width/2,pad_gap/2+pad_heigth)
        c2 = sp.box(-pad_width/2,-(pad_gap/2+pad_heigth),pad_width/2,-pad_gap/2)

    coupler_cdx = abs(coupler_cdx)
    coupler_cdy = abs(coupler_cdy)
    coupler1 = sp.unary_union([sp.box(coupler_cdx-coupler_width/2,coupler_cdy+coupler_s/2-coupler_heigth,coupler_cdx+coupler_width/2,coupler_cdy+coupler_s/2),
                               sp.box(coupler_cdx,coupler_cdy-coupler_s/2,pad_width/2+pad_ground_l,coupler_cdy+coupler_s/2)])
    coupler2 = flip_x(coupler1,(0,0),True)
    coupler4 = flip_y(coupler2,(0,0),True)

    pad1 = c1.buffer(mid_radius,cap_style='round')
    pad2 = c2.buffer(mid_radius,cap_style='round')
    box = sp.box(-pad_width/2-pad_ground_l,-pad_gap/2-pad_heigth-pad_ground_h,pad_width/2+pad_ground_l,pad_gap/2+pad_heigth+pad_ground_h)
    output = box - pad1 - pad2 - coupler4
    return move(rotate(output,angle,(0,0)),xoff,yoff)

def pocket_c_mask(pad_width,pad_heigth,pad_gap,pad_ground_l,pad_ground_h,
             coupler_width,coupler_heigth,coupler_cdx,coupler_cdy,coupler_s,
             angle = 0.0,xoff = 0.0,yoff = 0.0,pad_radius = 0.0,style = 'round') -> Polygon:
    output = rectangle(-pad_width/2-pad_ground_l,-pad_heigth-pad_gap/2-pad_ground_h,
                                    pad_width/2+pad_ground_l,pad_heigth+pad_gap/2+pad_ground_h)
    return move(rotate(output,angle,(0,0)),xoff,yoff)

def pad(inner_r,outer_r,cpw_w,cpw_s,port_x,points = 24,angle = 0.0,xoff = 0.0,yoff = 0.0,style = 'round') -> Polygon:           
    if style == 'round':
        coords = []
        for theta in range(points+1):
            coords.append([inner_r*np.cos(theta*np.pi/points+np.pi/2),inner_r*np.sin(theta*np.pi/points+np.pi/2)])
        for theta in range(1,points+1):
            coords.append([(port_x)*theta/points,-((inner_r-cpw_s/2)*np.cos(theta*np.pi/points)+(inner_r-cpw_s/2))/2-cpw_s/2])
        for theta in range(points,0,-1):
            coords.append([(port_x)*theta/points,-((outer_r-cpw_w-cpw_s/2)*np.cos(theta*np.pi/points)+(outer_r-cpw_w-cpw_s/2))/2-cpw_w-cpw_s/2])
        for theta in range(points,0,-1):
            coords.append([outer_r*np.cos(theta*np.pi/points+np.pi/2),outer_r*np.sin(theta*np.pi/points+np.pi/2)])
        for theta in range(points+1):
            coords.append([(port_x)*theta/points,((outer_r-cpw_w-cpw_s/2)*np.cos(theta*np.pi/points)+(outer_r-cpw_w-cpw_s/2))/2+cpw_w+cpw_s/2])
        for theta in range(points,0,-1):
            coords.append([(port_x)*theta/points,((inner_r-cpw_s/2)*np.cos(theta*np.pi/points)+(inner_r-cpw_s/2))/2+cpw_s/2])
    else:
        coords = [[port_x,cpw_s/2],
                    [port_x,cpw_s/2+cpw_w],
                    [inner_r,outer_r],
                    [-outer_r,outer_r],
                    [-outer_r,-outer_r],
                    [inner_r,-outer_r],
                    [port_x,-cpw_s/2-cpw_w],
                    [port_x,-cpw_s/2],
                    [inner_r,-inner_r],
                    [-inner_r,-inner_r],
                    [-inner_r,inner_r],
                    [inner_r,inner_r],
                    [port_x,cpw_s/2]]
    output = Polygon(coords)
    return move(rotate(output,angle,(0,0)),xoff,yoff)

def pad_mask(inner_r,outer_r,cpw_w,cpw_s,port_x,points = 24,angle = 0.0,xoff = 0.0,yoff = 0.0,style = 'round') -> Polygon:           
    if style == 'round':
        coords = []
        # for theta in range(points+1):
        #     coords.append([inner_r*np.cos(theta*np.pi/points+np.pi/2),inner_r*np.sin(theta*np.pi/points+np.pi/2)])
        # for theta in range(1,points+1):
        #     coords.append([(port_x)*theta/points,-((inner_r-cpw_s/2)*np.cos(theta*np.pi/points)+(inner_r-cpw_s/2))/2-cpw_s/2])
        for theta in range(points,0,-1):
            coords.append([(port_x)*theta/points,-((outer_r-cpw_w-cpw_s/2)*np.cos(theta*np.pi/points)+(outer_r-cpw_w-cpw_s/2))/2-cpw_w-cpw_s/2])
        for theta in range(points,0,-1):
            coords.append([outer_r*np.cos(theta*np.pi/points+np.pi/2),outer_r*np.sin(theta*np.pi/points+np.pi/2)])
        for theta in range(points+1):
            coords.append([(port_x)*theta/points,((outer_r-cpw_w-cpw_s/2)*np.cos(theta*np.pi/points)+(outer_r-cpw_w-cpw_s/2))/2+cpw_w+cpw_s/2])
        # for theta in range(points,0,-1):
        #     coords.append([(port_x)*theta/points,((inner_r-cpw_s/2)*np.cos(theta*np.pi/points)+(inner_r-cpw_s/2))/2+cpw_s/2])
    else:
        coords = [
                    [port_x,cpw_s/2+cpw_w],
                    [inner_r,outer_r],
                    [-outer_r,outer_r],
                    [-outer_r,-outer_r],
                    [inner_r,-outer_r],
                    [port_x,-cpw_s/2-cpw_w],
                    ]
    output = Polygon(coords)
    return move(rotate(output,angle,(0,0)),xoff,yoff)

def padlarge(inner_r,outer_r,cpw_w,cpw_s,inner_p,angle = 0.0,xoff = 0.0,yoff = 0.0) -> Polygon:           
    arm = LineString([(0,0),(inner_p,0)])
    pad = Point(0,0).buffer(outer_r) - Point(0,0).buffer(inner_r) - arm.buffer(cpw_s/2)
    armshape = arm.buffer(cpw_s/2+cpw_w,cap_style='flat') - arm.buffer(cpw_s/2,cap_style='square') - Point(0,0).buffer(inner_r)
    output = sp.union(pad,armshape)
    return move(rotate(output,angle,(0,0)),xoff,yoff)

def padlarge_mask(inner_r,outer_r,cpw_w,cpw_s,inner_p,angle = 0.0,xoff = 0.0,yoff = 0.0) -> Polygon:           
    arm = LineString([(0,0),(inner_p,0)])
    pad = Point(0,0).buffer(outer_r)
    armshape = arm.buffer(cpw_s/2+cpw_w,cap_style='flat')
    output = sp.union(pad,armshape)
    return move(rotate(output,angle,(0,0)),xoff,yoff)

def pad_square(box_w,box_h,sgap,port_s,angle = 0.0,xoff = 0.0,yoff = 0.0) -> Polygon:
    box = sp.box(-box_w/2,-box_h/2,box_w/2,box_h/2) - sp.box(-box_w/2+sgap,-box_h/2+sgap,box_w/2-sgap,box_h/2-sgap)
    output = box - sp.box(box_w/2-sgap,-port_s/2,box_w/2,port_s/2)
    return move(rotate(output,angle,(0,0)),xoff,yoff)
    
def pad_square_empty(box_w,box_h,sgap,port_s,port_w,angle = 0.0,xoff = 0.0,yoff = 0.0) -> Polygon:
    box = sp.box(-box_w/2,-box_h/2,box_w/2,box_h/2) - sp.box(-box_w/2+sgap,-box_h/2+sgap,box_w/2-sgap,box_h/2-sgap)
    box2 = sp.box(-box_w/2+sgap+port_s,-box_h/2+sgap+port_s,box_w/2-sgap-port_s,box_h/2-sgap-port_s)
    port = sp.box(box_w/2-sgap,-port_w/2-port_s,box_w/2,port_w/2+port_s)
    port2 = sp.box(box_w/2-sgap-port_s,-port_w/2,box_w/2,port_w/2)
    output = sp.unary_union([box-port,box2,port2])
    return move(rotate(output,angle,(0,0)),xoff,yoff)

def jj_nb_area(box_w,box_h,line_t_s,line_t_y,line_t_x1,line_t_x2,line_b_s,line_b_y,line_b_x1,line_b_x2,angle = 0.0,xoff = 0.0,yoff = 0.0) -> Polygon:
    box = sp.box(-box_w/2,-box_h/2,box_w/2,box_h/2)
    line_t = sp.box(line_t_x1,line_t_y-line_t_s/2,line_t_x2,line_t_y+line_t_s/2)
    line_b = sp.box(line_b_x1,line_b_y-line_b_s/2,line_b_x2,line_b_y+line_b_s/2)
    output = box - line_t - line_b
    return move(rotate(output,angle,(0,0)),xoff,yoff)

def magic_T(w_horizontal,s_horizontal,len_left,len_right,len_up,w_vertical=None,s_vertical=None,angle=0,xoff=0,yoff=0) -> Polygon:
    if w_vertical == None:
        w_vertical = w_horizontal
    if s_vertical == None:
        s_vertical = s_horizontal
    if len_left == 0:
        line_LL = [(-w_vertical/2-s_vertical/2,s_horizontal/2),
                    (-w_vertical/2-s_vertical/2,w_horizontal/2+s_horizontal/2+len_up)]
        dlen_left = w_vertical/2
    else:
        line_LL = [(-len_left-w_vertical/2-s_vertical/2,w_horizontal/2+s_horizontal/2),
                    (-w_vertical/2-s_vertical/2,w_horizontal/2+s_horizontal/2),
                    (-w_vertical/2-s_vertical/2,w_horizontal/2+s_horizontal/2+len_up)]
        dlen_left = len_left
    if len_right == 0:
        line_RL = [(w_vertical/2+s_vertical/2,s_horizontal/2),
                    (w_vertical/2+s_vertical/2,w_horizontal/2+s_horizontal/2+len_up)]
        dlen_right =  w_vertical/2
    else:
        line_RL = [(len_right+w_vertical/2+s_vertical/2,w_horizontal/2+s_horizontal/2),
                    (w_vertical/2+s_vertical/2,w_horizontal/2+s_horizontal/2),
                    (w_vertical/2+s_vertical/2,w_horizontal/2+s_horizontal/2+len_up)]
        dlen_right = len_right
    strip_LL = strip(w_horizontal,line_LL,style='mitre')
    strip_RL = strip(w_horizontal,line_RL,style='mitre')
    strip_DL = strip(w_horizontal,[(-dlen_left-w_vertical/2-s_vertical/2,-w_horizontal/2-s_horizontal/2),
                                (dlen_right+w_vertical/2+s_vertical/2,-w_horizontal/2-s_horizontal/2)
                                ],style='mitre')
    output = sp.unary_union([strip_LL,strip_RL,strip_DL])
    return move(rotate(output,angle,origin=(0,0)),xoff,yoff)

def capacitor_square(width,height,gap,cav_s,angle=0,xoff=0,yoff=0) -> Polygon:
    cap_in = sp.box(-width/2,-height/2,width/2,height/2)
    cap_out = sp.box(-width/2-gap,-height/2-gap,width/2+gap,height/2+gap)
    cap_cut = sp.box(-cav_s,-height/2-gap,cav_s,-height/2)
    output = cap_out-cap_in-cap_cut
    return move(rotate(output,angle,(0,0)),xoff,yoff)

def capacitor_interdigited(w,s,w_mid,s_mid,len_narrow,len_mid,num,gap,len_left=0,len_right=0,angle=0,xoff=0,yoff=0) -> Polygon:
    line_t1 = tline_taper(w_mid,s_mid,w,s,len_narrow,xoff=len_mid/2)
    line_t2 = tline_taper(w,s,w_mid,s_mid,len_narrow,xoff=-len_mid/2-len_narrow)
    line_c = cpw(w_mid,s_mid,[(-len_mid/2,0),(len_mid/2,0)])
    gap_d = (s_mid - gap*(num-1))/num+gap
    x_left = -len_mid/2+gap/2
    x_right = len_mid/2-gap/2
    y_now = -s_mid/2-gap/2
    line = []
    for k in range(num):
        if k%2 == 0:
            line.extend([(x_left,y_now),(x_left,y_now+gap_d)])
        else:
            line.extend([(x_right,y_now),(x_right,y_now+gap_d)])
        y_now = y_now+gap_d
    line_s = strip(gap,line,style='mitre')
    output = sp.unary_union([line_t1,line_t2,line_c,line_s])
    if len_left > 0:
        line_cl = cpw(w,s,[(-len_mid/2-len_narrow-len_left,0),(-len_mid/2-len_narrow,0)])
        output = sp.unary_union([output,line_cl])
    if len_right > 0:
        line_cr = cpw(w,s,[(len_mid/2+len_narrow,0),(len_mid/2+len_narrow+len_right,0)])
        output = sp.unary_union([output,line_cr])
    return move(rotate(output,angle),xoff,yoff)

def capacitor_cg(overlap,cg_margin,cg_width,cg_add,q_capa_large,q_capa_median,q_capa_small,cav_w,cav_s,angle,xoff=0.0,yoff=0.0) -> Polygon:
    pad_L=Polygon([
                    (-q_capa_large/2-cg_margin-cg_width,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w-overlap),
                    (-q_capa_large/2-cg_margin-cg_width,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w),
                    (-q_capa_large/2-cg_margin,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w),
                    (-q_capa_large/2-cg_margin,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w-overlap),
    ])
    pad_LL=Polygon([
                    (-q_capa_large/2-cg_margin,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w),
                    (-q_capa_large/2-cg_margin,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin),
                    (-q_capa_large/2-q_capa_small-q_capa_median-cg_margin+(cav_s/2)*2**0.5,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin),
                    (-q_capa_large/2-q_capa_small-q_capa_median-cg_margin+(cav_s/2)*2**0.5,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w),
    ])
    pad_B=Polygon([
                    (-q_capa_large/2-cg_margin,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w-overlap),
                    (-q_capa_large/2-cg_margin,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w-overlap+(cg_width)*2**0.5),
                    (q_capa_large/2+cg_margin,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w-overlap+(cg_width)*2**0.5+q_capa_large+cg_margin*2),
                    (q_capa_large/2+cg_margin,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w-overlap+q_capa_large+cg_margin*2),
    ])
    pad_R=Polygon([
                    (q_capa_large/2+cg_margin,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w-overlap+q_capa_large+cg_margin*2),
                    (q_capa_large/2+cg_margin+cg_width,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w-overlap+q_capa_large+cg_margin*2+cg_width),
                    (q_capa_large/2+cg_margin+cg_width,-q_capa_large/2-q_capa_small-q_capa_median),
                    (q_capa_large/2+cg_margin,-q_capa_large/2-q_capa_small-q_capa_median),
    ])
    pad_RT=Polygon([
                    (q_capa_large/2+cg_margin,-q_capa_large/2-q_capa_small-q_capa_median),
                    (q_capa_large/2+cg_margin+cg_width,-q_capa_large/2-q_capa_small-q_capa_median),
                    (q_capa_large/2+cg_margin+cg_width-q_capa_median,-q_capa_large/2-q_capa_small),
                    (q_capa_large/2+cg_margin+cg_width-q_capa_median,-q_capa_large/2-q_capa_small-cg_width),
    ])
    pad_T=Polygon([
                    (q_capa_large/2+cg_margin+cg_width-q_capa_median,-q_capa_large/2-q_capa_small-cg_width),
                    (q_capa_large/2+cg_margin+cg_width-q_capa_median,-q_capa_large/2-q_capa_small),
                    (-q_capa_large/2-q_capa_small-cg_width,-q_capa_large/2-q_capa_small),
                    (-q_capa_large/2-q_capa_small-cg_width,-q_capa_large/2-q_capa_small-cg_width),
    ])
    add_L=Polygon([
                    (-q_capa_large/2-cg_margin-cg_width,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w-overlap),
                    (-q_capa_large/2-cg_margin-cg_width,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w-overlap-cg_add),
                    (-q_capa_large/2-cg_margin,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w-overlap-cg_add),
                    (-q_capa_large/2-cg_margin,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w-overlap),
    ])
    add_B=Polygon([
                    (-q_capa_large/2-cg_margin,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w-overlap-cg_add),
                    (-q_capa_large/2-cg_margin,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w-overlap+(cg_width)*2**0.5-cg_add),
                    (q_capa_large/2+cg_margin,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w-overlap+(cg_width)*2**0.5+q_capa_large+cg_margin*2-cg_add),
                    (q_capa_large/2+cg_margin,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w-overlap+q_capa_large+cg_margin*2-cg_add),
    ])
    add_R=Polygon([
                    (q_capa_large/2+cg_margin,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w-overlap+q_capa_large+cg_margin*2),
                    (q_capa_large/2+cg_margin+cg_width,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w-overlap+q_capa_large+cg_margin*2+cg_width),
                    (q_capa_large/2+cg_margin+cg_width,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w-overlap+q_capa_large+cg_margin*2+cg_width-cg_add),
                    (q_capa_large/2+cg_margin,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w-overlap+q_capa_large+cg_margin*2-cg_add),
    ])
    cg1 = sp.unary_union([pad_L, pad_LL, pad_R, pad_T, pad_RT, add_L, add_B, add_R])
    cg2 = sp.affinity.scale(sp.affinity.rotate(sp.unary_union([pad_L, pad_LL, pad_B, pad_R, pad_T, pad_RT]),angle=90,origin=(0,0)),xfact=-1,origin=(0,0))
    output = sp.unary_union([cg1,cg2])
    return move(rotate(output,angle,origin=(0,0)),xoff,yoff)

def capacitor_cg_mask(overlap,cg_margin,cg_width,cg_add,q_capa_large,q_capa_median,q_capa_small,cav_w,cav_s,angle,xoff=0.0,yoff=0.0) -> Polygon:
    cav_s = 0
    pad_L=Polygon([
                    (-q_capa_large/2-cg_margin-cg_width,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w-overlap),
                    (-q_capa_large/2-cg_margin-cg_width,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w),
                    (-q_capa_large/2-cg_margin,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w),
                    (-q_capa_large/2-cg_margin,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w-overlap),
    ])
    pad_LL=Polygon([
                    (-q_capa_large/2-cg_margin,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w),
                    (-q_capa_large/2-cg_margin,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin),
                    (-q_capa_large/2-q_capa_small-q_capa_median-cg_margin+(cav_s/2)*2**0.5,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin),
                    (-q_capa_large/2-q_capa_small-q_capa_median-cg_margin+(cav_s/2)*2**0.5,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w),
    ])
    pad_B=Polygon([
                    (-q_capa_large/2-cg_margin,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w-overlap),
                    (-q_capa_large/2-cg_margin,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w-overlap+(cg_width)*2**0.5),
                    (q_capa_large/2+cg_margin,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w-overlap+(cg_width)*2**0.5+q_capa_large+cg_margin*2),
                    (q_capa_large/2+cg_margin,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w-overlap+q_capa_large+cg_margin*2),
    ])
    pad_R=Polygon([
                    (q_capa_large/2+cg_margin,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w-overlap+q_capa_large+cg_margin*2),
                    (q_capa_large/2+cg_margin+cg_width,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w-overlap+q_capa_large+cg_margin*2+cg_width),
                    (q_capa_large/2+cg_margin+cg_width,-q_capa_large/2-q_capa_small-q_capa_median),
                    (q_capa_large/2+cg_margin,-q_capa_large/2-q_capa_small-q_capa_median),
    ])
    pad_RT=Polygon([
                    (q_capa_large/2+cg_margin,-q_capa_large/2-q_capa_small-q_capa_median),
                    (q_capa_large/2+cg_margin+cg_width,-q_capa_large/2-q_capa_small-q_capa_median),
                    (q_capa_large/2+cg_margin+cg_width-q_capa_median,-q_capa_large/2-q_capa_small),
                    (q_capa_large/2+cg_margin+cg_width-q_capa_median,-q_capa_large/2-q_capa_small-cg_width),
    ])
    pad_T=Polygon([
                    (q_capa_large/2+cg_margin+cg_width-q_capa_median,-q_capa_large/2-q_capa_small-cg_width),
                    (q_capa_large/2+cg_margin+cg_width-q_capa_median,-q_capa_large/2-q_capa_small),
                    (-q_capa_large/2-q_capa_small-cg_width,-q_capa_large/2-q_capa_small),
                    (-q_capa_large/2-q_capa_small-cg_width,-q_capa_large/2-q_capa_small-cg_width),
    ])
    add_L=Polygon([
                    (-q_capa_large/2-cg_margin-cg_width,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w-overlap),
                    (-q_capa_large/2-cg_margin-cg_width,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w-overlap-cg_add),
                    (-q_capa_large/2-cg_margin,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w-overlap-cg_add),
                    (-q_capa_large/2-cg_margin,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w-overlap),
    ])
    add_B=Polygon([
                    (-q_capa_large/2-cg_margin,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w-overlap-cg_add),
                    (-q_capa_large/2-cg_margin,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w-overlap+(cg_width)*2**0.5-cg_add),
                    (q_capa_large/2+cg_margin,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w-overlap+(cg_width)*2**0.5+q_capa_large+cg_margin*2-cg_add),
                    (q_capa_large/2+cg_margin,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w-overlap+q_capa_large+cg_margin*2-cg_add),
    ])
    add_R=Polygon([
                    (q_capa_large/2+cg_margin,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w-overlap+q_capa_large+cg_margin*2),
                    (q_capa_large/2+cg_margin+cg_width,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w-overlap+q_capa_large+cg_margin*2+cg_width),
                    (q_capa_large/2+cg_margin+cg_width,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w-overlap+q_capa_large+cg_margin*2+cg_width-cg_add),
                    (q_capa_large/2+cg_margin,-q_capa_large/2-q_capa_small-q_capa_median-cg_margin-cav_w-overlap+q_capa_large+cg_margin*2-cg_add),
    ])
    cg1 = sp.unary_union([pad_L, pad_LL, pad_R, pad_T, pad_RT, add_L, add_B, add_R])
    cg2 = sp.affinity.scale(sp.affinity.rotate(sp.unary_union([pad_L, pad_LL, pad_B, pad_R, pad_T, pad_RT]),angle=90,origin=(0,0)),xfact=-1,origin=(0,0))
    output = exterior(sp.unary_union([cg1,cg2]))
    return move(rotate(output,angle,origin=(0,0)),xoff,yoff)

def capacitor_interdigited_squared(cav_w,cav_s,len_capa,finger_num,finger_gap,finger_width,capa_gap_width,capa_palm_width,len_left=0,len_right=0,angle=0,xoff=0,yoff=0) -> Polygon:
    capa_w = capa_gap_width
    capa_s = finger_gap*(finger_num-1)+finger_width*finger_num

    line_h = cpw(capa_w,capa_s,[(-len_capa/2-capa_palm_width-capa_gap_width,0),(len_capa/2+capa_palm_width+capa_gap_width,0)])

    line_v1 = cpw(capa_w,len_capa+capa_palm_width*2,[(0,capa_s/2+capa_gap_width),(0,cav_s/2)])
    line_v2 = cpw(capa_w,len_capa+capa_palm_width*2,[(0,-capa_s/2-capa_gap_width),(0,-cav_s/2)])

    gap_d = finger_width+finger_gap
    x_left = -len_capa/2+finger_gap/2
    x_right = len_capa/2-finger_gap/2
    y_now = -capa_s/2 - finger_gap/2
    line = []
    for k in range(finger_num):
        if k%2 == 0:
            line.extend([(x_left,y_now),(x_left,y_now+gap_d)])
        else:
            line.extend([(x_right,y_now),(x_right,y_now+gap_d)])
        y_now = y_now+gap_d
    line_s = strip(finger_gap,line,style='mitre')
    output = sp.unary_union([line_h,line_v1,line_v2,line_s])
    if len_left > 0:
        line_cl = cpw(cav_w,cav_s,[(-len_capa/2-capa_palm_width-capa_gap_width-len_left,0),(-len_capa/2-capa_palm_width-capa_gap_width,0)])
        output = sp.unary_union([output,line_cl])
    if len_right > 0:
        line_cr = cpw(cav_w,cav_s,[(len_capa/2+capa_palm_width+capa_gap_width,0),(len_capa/2+capa_palm_width+capa_gap_width+len_right,0)])
        output = sp.unary_union([output,line_cr])
    return move(rotate(output,angle),xoff,yoff)

def capacitor_interdigited_squared_mask(cav_w,cav_s,len_capa,finger_num,finger_gap,finger_width,capa_gap_width,capa_palm_width,len_left=0,len_right=0,angle=0,xoff=0,yoff=0) -> Polygon:
    capa_w = capa_gap_width
    capa_s = finger_gap*(finger_num-1)+finger_width*finger_num

    output = sp.box(-len_capa/2-capa_palm_width-capa_gap_width,-capa_s/2-capa_gap_width,len_capa/2+capa_palm_width+capa_gap_width,capa_s/2+capa_gap_width)
    if len_left > 0:
        line_cl = cpw(cav_w+cav_s/2,0,[(-len_capa/2-capa_palm_width-capa_gap_width-len_left,0),(-len_capa/2-capa_palm_width-capa_gap_width,0)])
        output = sp.unary_union([output,line_cl])
    if len_right > 0:
        line_cr = cpw(cav_w+cav_s/2,0,[(len_capa/2+capa_palm_width+capa_gap_width,0),(len_capa/2+capa_palm_width+capa_gap_width+len_right,0)])
        output = sp.unary_union([output,line_cr])
    return move(rotate(output,angle),xoff,yoff)

def capacitor_interdigited_narrow(cav_w,cav_s,len_capa,finger_num,finger_gap,finger_width,capa_gap_width,finger_margin,len_narrow,len_left=0,len_right=0,angle=0,xoff=0,yoff=0) -> Polygon:
    capa_w = capa_gap_width+finger_margin
    capa_s = finger_gap*(finger_num-1)+finger_width*finger_num

    capa_w2 = capa_gap_width
    capa_s2 = finger_gap*(finger_num-1)+finger_width*finger_num+finger_margin*2

    line_h = cpw(capa_w,capa_s,[(-len_capa/2,0),(len_capa/2,0)])

    line_t1 = tline_taper(cav_w,cav_s,capa_w2,capa_s2,len_narrow,xoff=-len_narrow-len_capa/2)
    line_t2 = tline_taper(cav_w,cav_s,capa_w2,capa_s2,len_narrow,angle=180,xoff=len_narrow+len_capa/2)

    gap_d = finger_width+finger_gap
    x_left = -len_capa/2+finger_gap/2
    x_right = len_capa/2-finger_gap/2
    y_now = -capa_s/2 - finger_gap/2
    line = []
    for k in range(finger_num):
        if k%2 == 0:
            line.extend([(x_left,y_now),(x_left,y_now+gap_d)])
        else:
            line.extend([(x_right,y_now),(x_right,y_now+gap_d)])
        y_now = y_now+gap_d
    line_s = strip(finger_gap,line,style='mitre')
    output = sp.unary_union([line_h,line_t1,line_t2,line_s])
    if len_left > 0:
        line_cl = cpw(cav_w,cav_s,[(-len_capa/2-len_narrow-len_left,0),(-len_capa/2-len_narrow,0)])
        output = sp.unary_union([output,line_cl])
    if len_right > 0:
        line_cr = cpw(cav_w,cav_s,[(len_capa/2+len_narrow,0),(len_capa/2+len_narrow+len_right,0)])
        output = sp.unary_union([output,line_cr])
    return move(rotate(output,angle),xoff,yoff)

def capacitor_interdigited_narrow_mask(cav_w,cav_s,len_capa,finger_num,finger_gap,finger_width,capa_gap_width,finger_margin,len_narrow,len_left=0,len_right=0,angle=0,xoff=0,yoff=0) -> Polygon:
    capa_w = capa_gap_width+finger_margin
    capa_s = finger_gap*(finger_num-1)+finger_width*finger_num

    capa_w2 = capa_gap_width
    capa_s2 = finger_gap*(finger_num-1)+finger_width*finger_num+finger_margin*2

    line_h = cpw(capa_w+capa_s/2,0,[(-len_capa/2,0),(len_capa/2,0)])

    line_t1 = tline_taper_mask(cav_w,cav_s,capa_w2,capa_s2,len_narrow,xoff=-len_narrow-len_capa/2)
    line_t2 = tline_taper_mask(cav_w,cav_s,capa_w2,capa_s2,len_narrow,angle=180,xoff=len_narrow+len_capa/2)

    output = sp.unary_union([line_h,line_t1,line_t2])
    if len_left > 0:
        line_cl = cpw(cav_w,cav_s,[(-len_capa/2-len_narrow-len_left,0),(-len_capa/2-len_narrow,0)])
        output = sp.unary_union([output,line_cl])
    if len_right > 0:
        line_cr = cpw(cav_w,cav_s,[(len_capa/2+len_narrow,0),(len_capa/2+len_narrow+len_right,0)])
        output = sp.unary_union([output,line_cr])
    return move(rotate(output,angle),xoff,yoff)
