import numpy as np

def snake_hb(len_total,len_parallel,len_start,bend_radius,flip_x = False,flip_y = False,xoff = 0,yoff = 0):
    length_rest = len_total - len_start - bend_radius*np.pi/2
    kx = -1 if flip_x else 1
    ky = -1 if flip_y else 1

    points = [(xoff,yoff),(xoff,yoff+ky*len_start)]

    x_now = xoff
    y_now = yoff+ky*len_start + ky*bend_radius

    turn_num = 0
    turn_dx = kx*(len_parallel+2*bend_radius)
    while length_rest > len_parallel+bend_radius*np.pi:
        if turn_num%2 == 0:
            points.extend([(x_now,y_now),(x_now+turn_dx,y_now)])
            x_now = x_now+turn_dx
        else:
            points.extend([(x_now,y_now),(x_now-turn_dx,y_now)])
            x_now = x_now-turn_dx
        turn_num = turn_num + 1
        y_now = y_now+ky*bend_radius*2 
        length_rest = length_rest - (len_parallel+bend_radius*np.pi)
    if length_rest > 0:
        if turn_num%2 == 0:
            points.extend([(x_now,y_now),(x_now+kx*(length_rest+bend_radius),y_now)])
            x_now = x_now+kx*(length_rest+bend_radius)
        else:
            points.extend([(x_now,y_now),(x_now-kx*(length_rest+bend_radius),y_now)])
            x_now = x_now-kx*(length_rest+bend_radius)
        length_rest = 0
    return points

def snake2(length,parallel,bendradius,starth,turnleft = True,x_now = 0,y_now = 0):
    length_rest = length - starth - bendradius*np.pi/2
    if turnleft:
        points = [(x_now,y_now),(x_now-starth,y_now)]
        x_now = x_now -starth
    else:
        points = [(x_now,y_now),(x_now+starth,y_now)]
        x_now = x_now +starth
    y_now = y_now  + bendradius * 2
    
    while length_rest > parallel+bendradius*np.pi:
        if turnleft:
            turnleft = False
            points.extend([(x_now,y_now),(x_now+parallel,y_now)])
            x_now = x_now+parallel
        else:
            turnleft = True
            points.extend([(x_now,y_now),(x_now-parallel,y_now)])
            x_now = x_now-parallel
        y_now = y_now+bendradius*2 
        length_rest = length_rest - (parallel+bendradius*np.pi)
    if length_rest > 0:
        if turnleft:
            points.extend([(x_now,y_now),(x_now+length_rest,y_now)])
            x_now = x_now+length_rest
        else:
            points.extend([(x_now,y_now),(x_now-length_rest,y_now)])
            x_now = x_now-length_rest
        length_rest = 0
    return points

def snake_port(start_point,end_point,length,radius,starth,endh,turnup = True):
    bendnum = int(np.floor((abs(start_point[0]-end_point[0])-starth-endh)/(2*radius)))
    bendrest = abs(start_point[0]-end_point[0])-starth-endh - bendnum*2*radius
    endh_new = bendrest + endh
    length_rest = length - starth - endh_new - radius*np.pi*bendnum
    y_mid = (start_point[1]+end_point[1])/2
    if bendnum%2 == 1:
        parallel = length_rest/bendnum
    else:
        if turnup:
            parallel = (length_rest+(start_point[1]-end_point[1]))/bendnum
        else:
            parallel = (length_rest-(start_point[1]-end_point[1]))/bendnum
    
    parallel_radius = parallel + 2*radius

    if end_point[0] > start_point[0]:
        x_now = start_point[0] + starth
        x_increase = 2*radius
    else:
        x_now = start_point[0] - starth
        x_increase = -2*radius

    points = [start_point,(x_now,start_point[1])]
    y_up = y_mid+parallel_radius/2
    y_down = y_mid-parallel_radius/2

    for bendindex in range(bendnum):
        if turnup:
            turnup = False
            points.extend([(x_now,y_up),(x_now+x_increase,y_up)])
            x_now = x_now+x_increase
        else:
            turnup = True
            points.extend([(x_now,y_down),(x_now+x_increase,y_down)])
            x_now = x_now+x_increase
    
    points.extend([(x_now,end_point[1]),end_point])

    return points

def snake_port2(start_point,end_point,length,radius,starth,endh,turnlength):
    bendnum = int(np.floor((abs(start_point[1]-end_point[1])-starth-endh)/(2*radius)))
    if bendnum%2 == 1:
        bendnum = bendnum - 1
    bendrest = abs(start_point[0]-end_point[0])-starth-endh - bendnum*2*radius
    endh_new = bendrest + endh
    length_rest = length - starth - endh_new - turnlength*2 - (bendnum+1)*np.pi*radius

    parallel = length_rest/bendnum
    parallel_radius = parallel + 2*radius

    x_mid = (start_point[0]+end_point[0])/2
    x_right = x_mid+parallel_radius/2
    x_left = x_mid-parallel_radius/2

    x_now = start_point[0] + radius + turnlength
    y_now = start_point[1] - radius*2 - starth
    points = [start_point,(x_now,start_point[1]),(x_now,y_now),(x_left,y_now)]

    y_now = y_now - 2*radius
    for bendindex in range(bendnum//2-1):
        points.extend([(x_left,y_now),(x_right,y_now),(x_right,y_now-2*radius),(x_left,y_now-2*radius)])
        y_now = y_now - 4*radius
    
    points.extend([(x_left,end_point[1]),end_point])

    return points

def snake_port3(start_point,end_point,length,radius,starth,endh,turnlength):
    bendnum = int(np.floor((abs(start_point[1]-end_point[1])-starth-endh)/(2*radius)))
    if bendnum%2 == 0:
        bendnum = bendnum - 1
    bendrest = abs(start_point[0]-end_point[0])-starth-endh - bendnum*2*radius
    endh_new = bendrest + endh
    length_rest = length - starth - endh_new - turnlength*2 - (bendnum+1)*np.pi*radius

    parallel = length_rest/bendnum
    parallel_radius = parallel + 2*radius

    x_mid = 0
    x_right = x_mid+parallel_radius/2
    x_left = x_mid-parallel_radius/2

    x_now = start_point[0] + radius + turnlength
    y_now = start_point[1] - radius*2 - starth
    points = [start_point,(x_now,start_point[1]),(x_now,y_now),(x_left,y_now)]

    y_now = y_now - 2*radius
    for bendindex in range(bendnum//2-1):
        points.extend([(x_left,y_now),(x_right,y_now),(x_right,y_now-2*radius),(x_left,y_now-2*radius)])
        y_now = y_now - 4*radius
    
    points.extend([(x_left,y_now),(x_right,y_now),(x_right,end_point[1]),end_point])

    return points

def loop(length,sgap,sbox,starth,endh,x_now = 0,y_now = 0):
    length_rest = length - starth - endh
    loopth = 0
    while(length_rest > 4*sbox):
        loopth = loopth+1
        length_rest = length_rest - sbox-sgap*((loopth+2)//2)
    
    length_rest = length_rest - sgap
    if length_rest < 0:
        print('length_rest < 0')
    
    boxth = 0
    while(length_rest > sbox):
        boxth = boxth + 1
        length_rest = length_rest - sbox
    
    if boxth == 0:
        points = [(sbox/2 - starth,sbox/2-length_rest),(sbox/2,sbox/2-length_rest),(sbox/2,sbox/2+sgap)]
    elif boxth == 1:
        points = [(sbox/2-length_rest,-sbox/2 + starth),(sbox/2-length_rest,-sbox/2),(sbox/2,-sbox/2),(sbox/2,sbox/2+sgap)]
    elif boxth == 2:
        points = [(-sbox/2 + starth,-sbox/2+length_rest),(-sbox/2,-sbox/2+length_rest),(-sbox/2,-sbox/2),(sbox/2,-sbox/2),(sbox/2,sbox/2+sgap)]
    else:
        points = [(-sbox/2+length_rest,sbox/2-starth),(-sbox/2+length_rest,sbox/2),(-sbox/2,sbox/2),(-sbox/2,-sbox/2),(sbox/2,-sbox/2),(sbox/2,sbox/2+sgap)]

    for loop in range(loopth):
        if loop%4 == 0:
            points.append((-sbox/2-sgap*(loop//4+1),sbox/2+sgap*(loop//4+1)))
        elif loop%4 == 1:
            points.append((-sbox/2-sgap*(loop//4+1),-sbox/2-sgap*(loop//4+1)))
        elif loop%4 == 2:
            points.append((sbox/2+sgap*(loop//4+1),-sbox/2-sgap*(loop//4+1)))
        else:
            points.append((sbox/2+sgap*(loop//4+1),sbox/2+sgap*(loop//4+2)))

    return points

def loop2(sgap,loopnum,outx,outy,centerx,centery,x_now = 0,y_now = 0):
    points = [(x_now,y_now)]
    dx_now = outx
    dy_now = outy
    for k in range(loopnum):
        points.extend([(x_now,y_now+dy_now),(x_now+dx_now,y_now+dy_now),(x_now+dx_now,y_now+sgap),(x_now+sgap,y_now+sgap)])
        dx_now = dx_now - 2*sgap
        dy_now = dy_now - 2*sgap
        x_now = x_now + sgap
        y_now = y_now + sgap
    points.extend([(x_now,centery),(centerx,centery)])
    return points

def inductor_long(length,parallelnum,bendh,starth,turnup = True,x_now = 0,y_now = 0):
    parallel = (length-starth*2)/(parallelnum+1)-bendh
    
    points = [(x_now,y_now),(x_now+starth,y_now)]
    x_now = x_now + starth
    if turnup:
        y_now = y_now+parallel/2
        points.append((x_now,y_now))
        turnup = False
    else:
        y_now = y_now-parallel/2
        points.append((x_now,y_now))
        turnup = True
    for k in range(parallelnum):
        if turnup:
            x_now = x_now+bendh
            points.extend([(x_now,y_now),(x_now,y_now+parallel)])
            y_now = y_now+parallel
            turnup = False
        else:
            x_now = x_now+bendh
            points.extend([(x_now,y_now),(x_now,y_now-parallel)])
            y_now = y_now-parallel
            turnup = True
    x_now = x_now + bendh
    if turnup:
        points.extend([(x_now,y_now),(x_now,y_now+parallel/2),(x_now+starth,y_now+parallel/2)])
    else:
        points.extend([(x_now,y_now),(x_now,y_now-parallel/2),(x_now+starth,y_now-parallel/2)])
    
    return points

def inductor_loop(length,sgap,sbox,starth,endh,x_now = 0,y_now = 0):
    length_rest = length - starth - endh
    loopth = 0
    while(length_rest > 4*sbox):
        loopth = loopth+1
        length_rest = length_rest - sbox-sgap*((loopth+2)//2)
    
    length_rest = length_rest - sgap
    if length_rest < 0:
        print('length_rest < 0')
    
    boxth = 0
    while(length_rest > sbox):
        boxth = boxth + 1
        length_rest = length_rest - sbox
    
    if boxth == 0:
        points = [(sbox/2 - starth,sbox/2-length_rest),(sbox/2,sbox/2-length_rest),(sbox/2,sbox/2+sgap)]
    elif boxth == 1:
        points = [(sbox/2-length_rest,-sbox/2 + starth),(sbox/2-length_rest,-sbox/2),(sbox/2,-sbox/2),(sbox/2,sbox/2+sgap)]
    elif boxth == 2:
        points = [(-sbox/2 + starth,-sbox/2+length_rest),(-sbox/2,-sbox/2+length_rest),(-sbox/2,-sbox/2),(sbox/2,-sbox/2),(sbox/2,sbox/2+sgap)]
    else:
        points = [(-sbox/2+length_rest,sbox/2-starth),(-sbox/2+length_rest,sbox/2),(-sbox/2,sbox/2),(-sbox/2,-sbox/2),(sbox/2,-sbox/2),(sbox/2,sbox/2+sgap)]

    for loop in range(loopth):
        if loop%4 == 0:
            points.append((-sbox/2-sgap*(loop//4+1),sbox/2+sgap*(loop//4+1)))
        elif loop%4 == 1:
            points.append((-sbox/2-sgap*(loop//4+1),-sbox/2-sgap*(loop//4+1)))
        elif loop%4 == 2:
            points.append((sbox/2+sgap*(loop//4+1),-sbox/2-sgap*(loop//4+1)))
        else:
            points.append((sbox/2+sgap*(loop//4+1),sbox/2+sgap*(loop//4+2)))

    return points

def inductor_loop_dual(box_w,box_h,sgap,top_dx,top_starth,top_endh,bot_dx,bot_starth,bot_endh,loop_half_num):
    points_t = [(-box_w/2+top_dx,box_h/2+top_starth),(-box_w/2+top_dx,box_h/2)]
    points_b = [(box_w/2-bot_dx,-box_h/2-bot_starth),(box_w/2-bot_dx,-box_h/2)]
    
    for loop in range(loop_half_num):
        if loop%2 == 0:
            points_t.extend([(-box_w/2+sgap*(loop),box_h/2-sgap*(loop)),(-box_w/2+sgap*(loop),-box_h/2+sgap*(loop+1))])
            points_b.extend([(box_w/2-sgap*(loop),-box_h/2+sgap*(loop)),(box_w/2-sgap*(loop),box_h/2-sgap*(loop+1))])
        else:
            points_t.extend([(box_w/2-sgap*(loop),-box_h/2+sgap*(loop)),(box_w/2-sgap*(loop),box_h/2-sgap*(loop+1))])
            points_b.extend([(-box_w/2+sgap*(loop),box_h/2-sgap*(loop)),(-box_w/2+sgap*(loop),-box_h/2+sgap*(loop+1))])

    loop = loop + 1
    if loop%2 == 0:
        points_t.extend([(0,box_h/2-sgap*(loop)),(0,box_h/2-sgap*(loop)-top_endh)])
        points_b.extend([(0,-box_h/2+sgap*(loop)),(0,-box_h/2+sgap*(loop)+bot_endh)])
    else:
        points_t.extend([(0,-box_h/2+sgap*(loop)),(0,-box_h/2+sgap*(loop)+top_endh)])
        points_b.extend([(0,box_h/2-sgap*(loop)),(0,box_h/2-sgap*(loop)-bot_endh)])

    return [points_t,points_b]

def getSignalArray(border_x,border_y,interval,center_x = None,center_y = None):
    if center_x:
        space_x = np.linspace((1-border_x)/2+border_x/2-center_x,(border_x-1)/2+border_x/2-center_x,border_x)
    else:
        space_x = np.linspace((1-border_x)/2,(border_x-1)/2,border_x)
    if center_y:
        space_y = np.linspace((1-border_y)/2+border_y/2-center_y,(border_y-1)/2+border_y/2-center_y,border_y)
    else:
        space_y = np.linspace((1-border_y)/2,(border_y-1)/2,border_y)
    space_x1 = np.linspace(1,1,border_x)
    space_y1 = np.linspace(1,1,border_y)
    sx = interval*np.kron(space_x,space_y1)
    sy = interval*np.kron(space_x1,space_y)
    sindex = []
    for k in range(border_x):
        for kk in range(border_y-1,-1,-1):
            sindex.append((k,kk))
    return [sx,sy,sindex]

def getGroundArray(border_x,border_y,interval,center_x = None,center_y = None,isfull = 0):
    if center_x:
        space_x = np.linspace((1-border_x)/2+border_x/2-center_x,(border_x-1)/2+border_x/2-center_x,border_x)
        space_xh = np.linspace(1-border_x/2+border_x/2-center_x-isfull,border_x/2+border_x/2-center_x-1+isfull,border_x-1+isfull*2)
    else:
        space_x = np.linspace((1-border_x)/2,(border_x-1)/2,border_x)
        space_xh = np.linspace(1-border_x/2-isfull,border_x/2-1+isfull,border_x-1+isfull*2)
    if center_y:
        space_y = np.linspace((1-border_y)/2+border_y/2-center_y,(border_y-1)/2+border_y/2-center_y,border_y)
        space_yh = np.linspace(1-border_y/2+border_y/2-center_y-isfull,border_y/2+border_y/2-center_y-1+isfull,border_y-1+isfull*2)
    else:
        space_y = np.linspace((1-border_y)/2,(border_y-1)/2,border_y)
        space_yh = np.linspace(1-border_y/2-isfull,border_y/2-1+isfull,border_y-1+isfull*2)

    space_x1 = np.linspace(1,1,border_x)
    space_y1 = np.linspace(1,1,border_y)

    space_xm1 = np.linspace(1,1,border_x-1+isfull*2)
    space_ym1 = np.linspace(1,1,border_y-1+isfull*2)

    gx_0 = interval*np.kron(space_xh,space_ym1)
    gy_0 = interval*np.kron(space_xm1,space_yh) 
    
    gx_1 = interval*np.kron(space_xh,space_y1)
    gy_1 = interval*np.kron(space_xm1,space_y)
    
    gx_2 = interval*np.kron(space_x,space_ym1)
    gy_2 = interval*np.kron(space_x1,space_yh)
    
    gx = np.append(np.append(gx_0,gx_1),gx_2)
    gy = np.append(np.append(gy_0,gy_1),gy_2)

    return [gx,gy]

def getHexagonalArray(border_a:int,interval:float,angle:float=0,cut_out:bool=False):
    hx = []
    hy = []
    interval_height = interval/2*np.sqrt(3)
    if not cut_out:
        hx.append(0)
        hy.append(0)
    for k in range(1,border_a):
        if cut_out:
            if k%2 == 0:
                hx_add = interval * 2 * np.linspace(-k/4+1/2,k/4-1/2,k//2)
                hy_add = - k * np.linspace(interval_height,interval_height,k//2)
            else:
                hx_add = interval * np.linspace(-k/2,k/2-1,k)
                hy_add = - k * np.linspace(interval_height,interval_height,k)
        else:
            hx_add = interval * np.linspace(-k/2,k/2-1,k)
            hy_add = - k * np.linspace(interval_height,interval_height,k)

        for kk in range(6):
            [rx,ry] = xyrotate(hx_add,hy_add,angle+60*kk)
            hx.extend(rx)
            hy.extend(ry)

    return [hx,hy]

def xyrotate(nx,ny,theta):
    theta = -theta/180*np.pi
    rx = np.array(nx)*np.cos(theta) + np.array(ny)*np.sin(theta)
    ry = np.array(ny)*np.cos(theta) - np.array(nx)*np.sin(theta)
    return [rx,ry]

def xysortx(rx,ry):
    xmin = np.min(rx)
    xmax = np.max(rx)
    interval = xmax - xmin
    # 计算最小间隔
    for k in range(len(rx)):
        for kk in range(k+1,len(rx)):
            if np.abs(rx[k] - rx[kk]) < interval and np.abs(rx[k] - rx[kk]) > 1:
                interval = np.abs(rx[k] - rx[kk])
    xnum = int(np.round((xmax-xmin)/interval)) + 1
    xlist = np.linspace(xmin,xmax,xnum)
    xcell = [[] for k in range(xnum)]
    for k in range(len(rx)):
        xcell[int(np.round((rx[k]-xmin)/interval))].append(ry[k])
    xcell = [np.sort(xcell[k]).tolist() for k in range(xnum)]
    # 删除空列表
    k_null = []
    for k in range(xnum):
        if len(xcell[k]) == 0:
            k_null.append(k)
    xlist = xlist.tolist()
    for kk in range(len(k_null)):
        xlist.pop(k_null[kk]-kk)
        xcell.pop(k_null[kk]-kk)
    return [xlist,xcell]

def get_port(list_a,list_au,list_b,list_bu,list_bandwidth):
    list_ab = [np.sort(np.append(list_a[k][0],list_b[k][0])) for k in range(8)]
    list_abx = [[list_ab[k][0]] for k in range(8)]
    for k in range(8):
        for kk in range(1,len(list_ab[k])):
            if list_ab[k][kk] - list_abx[k][-1] > list_bandwidth:
                list_abx[k].append(list_ab[k][kk])
    # 生成切割线的y列表
    list_aby = [[[] for kk in range(len(list_abx[k]))] for k in range(8)]
    # 计算原生输入点的y列表
    list_pti = [[[] for kk in range(len(list_abx[k]))] for k in range(8)]
    # 计算原生输出点的y列表
    list_pto = [[[] for kk in range(len(list_abx[k]))] for k in range(8)]
    for k in range(8):
        for kk in range(len(list_a[k][0])):
            for kkk in range(len(list_abx[k])):
                if list_a[k][0][kk] >= list_abx[k][-(1+kkk)]:
                    list_aby[k][-(1+kkk)].extend(list_a[k][1][kk])
                    break
        for kk in range(len(list_au[k][0])):
            for kkk in range(len(list_abx[k])):
                if list_au[k][0][kk] >= list_abx[k][-(1+kkk)]:
                    list_pti[k][-(1+kkk)].extend(list_au[k][1][kk])
                    break
        for kk in range(len(list_b[k][0])):
            for kkk in range(len(list_abx[k])):
                if list_b[k][0][kk] >= list_abx[k][-(1+kkk)]:
                    list_aby[k][-(1+kkk)].extend(list_b[k][1][kk])
                    break
        for kk in range(len(list_bu[k][0])):
            for kkk in range(len(list_abx[k])):
                if list_bu[k][0][kk] >= list_abx[k][-(1+kkk)]:
                    list_pto[k][-(1+kkk)].extend(list_bu[k][1][kk])
                    break
        for kk in range(len(list_abx[k])):
            list_aby[k][kk] = np.sort(list_aby[k][kk]).tolist()
    
    return [list_abx,list_aby,list_pti,list_pto]

def get_wire(list_abx,list_pti,list_pto,margin_w,cutline,list_au = None,list_bu = None):
    def float2int(arr):
        idx = len(arr)
        output = arr
        for k in range(idx-1):
            current = output[k]
            tt = np.round(current)
            output[k] = tt
            rest = current - tt
            output[k+1] = output[k+1] + rest
        output = np.round(output)
        return output.tolist()
    list_count = [[0 for kk in range(len(list_abx[k]))] for k in range(8)]
    for k in range(8):
        for kk in range(len(list_abx[k])):
            list_count[k][kk] = len(list_pti[k][kk-1])+list_count[k][kk-1]-len(list_pto[k][kk]) if kk > 0 else 0
    cutpnum = [[[np.floor((cutline[k][kk][kkk][1]-cutline[k][kk][kkk][0])/margin_w) for kkk in range(len(cutline[k][kk]))] \
                for kk in range(len(cutline[k]))] for k in range(8)]
    cutpnumoc = [[float2int(np.array(cutpnum[k][kk])/sum(cutpnum[k][kk])*list_count[k][kk]) \
                if sum(cutpnum[k][kk]) > 0 else [] for kk in range(len(cutpnum[k]))] for k in range(8)]
    # 计算切割点，未来开发检测ptc间距是否满足大于margin_w
    list_ptc = [[[] for kk in range(len(cutline[k]))] for k in range(8)]
    for k in range(8):
        for kk in range(len(cutpnumoc[k])):
            for kkk in range(len(cutpnumoc[k][kk])):
                if cutpnumoc[k][kk][kkk] > 0:
                    temp = np.linspace(cutline[k][kk][kkk][0],cutline[k][kk][kkk][1],int(cutpnumoc[k][kk][kkk])+2) 
                    list_ptc[k][kk].extend(temp[1:-1])
    # 检验点数是否相等
    # for k in range(8):
    #     for kk in range(len(list_abx[k])-1):
    #         if len(list_pti[k][kk])+len(list_ptc[k][kk]) != len(list_pto[k][kk+1])+len(list_ptc[k][kk+1]):
    #             print(k,kk,len(list_pti[k][kk]),len(list_ptc[k][kk]),len(list_pto[k][kk+1]),len(list_ptc[k][kk+1]))
    # 利用切割点，连点成线
    linkhead = [[np.sort(list_pti[k][kk]+list_ptc[k][kk]) \
                for kk in range(len(list_abx[k])-1) ] for k in range(8)]
    linktail = [[np.sort(list_pto[k][kk+1]+list_ptc[k][kk+1]) \
                for kk in range(len(list_abx[k])-1) ] for k in range(8)]
    wirex = [[] for k in range(8)]
    wirey = [[] for k in range(8)]
    for k in range(8):
        for kk in range(len(list_abx[k])-1):
            for kkk in range(len(list_pti[k][kk])):
                xlink = [list_abx[k][kk]]
                ylink = [list_pti[k][kk][kkk]]
                for kkkk in range(kk,len(list_abx[k])-1):
                    temp = np.where(ylink[-1] == linkhead[k][kkkk])[0].tolist()
                    if len(temp) > 0:
                        ylink.append(linktail[k][kkkk][temp[0]])
                        xlink.append(list_abx[k][kkkk+1])
                    else:
                        break
                # 处理晶格不匹配时的位移
                if list_au:
                    if len(np.where(xlink[0] == list_au[k][0])[0].tolist()) == 0:
                        for kkkk in range(len(list_au[k][0])):
                            if list_au[k][0][kkkk] >= xlink[0]:
                                xlink[0] = list_au[k][0][kkkk]
                                break
                    if len(np.where(xlink[-1] == list_bu[k][0])[0].tolist()) == 0:
                        for kkkk in range(len(list_bu[k][0])):
                            if list_bu[k][0][kkkk] >= xlink[-1]:
                                xlink[-1] = list_bu[k][0][kkkk]
                                break
                wirex[k].append(xlink)
                wirey[k].append(ylink)
    return [wirex,wirey]

def wire_chamfer(xlist,ylist,chamfer):
    wirex = [xlist[0]]
    wirey = [ylist[0]]
    for kkk in range(1,len(xlist)-1):
        wirex.extend([xlist[kkk]-chamfer/2,xlist[kkk]+chamfer/2])
        wirey.extend([ylist[kkk],ylist[kkk]])
    wirex.append(xlist[-1])
    wirey.append(ylist[-1])
    return [wirex,wirey]

def wiredivide3(xlist,ylist,dstart = 250,dend = 350):
    legrate = 1 - dstart/getDistance(xlist[:2],ylist[:2])
    if legrate < 0:
        print('error:dstart too long in wiredivide3')
    p_start_x = xlist[1]+(xlist[0]-xlist[1])*legrate
    p_start_y = ylist[1]+(ylist[0]-ylist[1])*legrate
    legrate = 1 - dend/getDistance(xlist[-2:],ylist[-2:])
    if legrate < 0:
        print('error:dend too long in wiredivide3')
    p_end_x = xlist[-2]+(xlist[-1]-xlist[-2])*legrate
    p_end_y = ylist[-2]+(ylist[-1]-ylist[-2])*legrate
    line1 = [(xlist[0],ylist[0]),(p_start_x,p_start_y)]
    line2 = [(p_start_x,p_start_y)] + list(zip(xlist[1:-1],ylist[1:-1])) + [(p_end_x,p_end_y)]
    line3 = [(p_end_x,p_end_y),(xlist[-1],ylist[-1])]
    return [line1,line2,line3]

def wireAdjustAngle(xlist,ylist,dstart = 100,start_angle=0,dend = 100,end_angle=0):
    legrate = 1 - dstart/getDistance(xlist[:2],ylist[:2])
    if legrate < 0:
        print('error:dstart too long in wireAdjustAngle')
    start_angle0 = getAngle(xlist[:2],ylist[:2])/np.pi*180
    start_angle1 = np.around((start_angle0-start_angle)/90)*90+start_angle
    start_mid_x = xlist[0]+dstart*np.cos(start_angle1/180*np.pi)
    start_mid_y = ylist[0]+dstart*np.sin(start_angle1/180*np.pi)

    legrate = 1 - dend/getDistance(xlist[-2:],ylist[-2:])
    if legrate < 0:
        print('error:dend too long in wireAdjustAngle')

    end_angle0 = getAngle(xlist[-2:],ylist[-2:])/np.pi*180
    end_angle1 = np.around((end_angle0-end_angle)/90)*90+end_angle
    end_mid_x = xlist[-1]-dend*np.cos(end_angle1/180*np.pi)
    end_mid_y = ylist[-1]-dend*np.sin(end_angle1/180*np.pi)

    line = [(xlist[0],ylist[0]),(start_mid_x,start_mid_y)]+ list(zip(xlist[1:-1],ylist[1:-1])) + [(end_mid_x,end_mid_y),(xlist[-1],ylist[-1])]
    return line
        
def pointdivide3(point_x,point_y,p1_dx=100,p1_dy=300,p2_dx=-100,p2_dy=300):
    line1 = [(point_x,point_y),(point_x+p1_dx,point_y+p1_dy)]
    line2 = [(point_x+p1_dx,point_y+p1_dy),(point_x+p2_dx,point_y+p2_dy)]
    line3 = [(point_x+p2_dx,point_y+p2_dy),(point_x,point_y)]
    return [line1,line2,line3]

def pointdivide3vertical(point_x,point_y,p1_dx=100,p1_dy=300,p2_dx=-100,p2_dy=300):
    p3_dx = (p1_dy*p2_dy*(p1_dy-p2_dy)+p2_dy*p1_dx**2-p1_dy*p2_dx**2)/(p1_dx*p2_dy-p1_dy*p2_dx)
    p3_dy = (p1_dx*p2_dx*(p1_dx-p2_dx)+p2_dx*p1_dy**2-p1_dx*p2_dy**2)/(p1_dy*p2_dx-p1_dx*p2_dy)

    line1 = [(point_x,point_y),(point_x+p1_dx,point_y+p1_dy)]
    line2 = [(point_x+p1_dx,point_y+p1_dy),(point_x+p3_dx,point_y+p3_dy),(point_x+p2_dx,point_y+p2_dy)]
    line3 = [(point_x+p2_dx,point_y+p2_dy),(point_x,point_y)]
    return [line1,line2,line3]


def getDistance(xlist,ylist) -> float:
    return np.sqrt((xlist[0]-xlist[1])**2+(ylist[0]-ylist[1])**2)

def getDistanceLine(line) -> float:
    '''
        line = [(x0,y0),(x1,y1)]
    '''
    return np.sqrt((line[1][0]-line[0][0])**2+(line[1][1]-line[0][1])**2)

def getAngle(xlist,ylist) -> float:
    return np.angle(xlist[1]-xlist[0]+1j*(ylist[1]-ylist[0]))

def getAngleLine(line) -> float:
    '''
        line = [(x0,y0),(x1,y1)]
    '''
    return np.angle(line[1][0]-line[0][0]+1j*(line[1][1]-line[0][1]))

def getAngleDif(xlist,ylist) -> float:
    output = np.angle(xlist[2]-xlist[1]+1j*(ylist[2]-ylist[1])) \
            - np.angle(xlist[1]-xlist[0]+1j*(ylist[1]-ylist[0]))
    if np.abs(output) > np.pi:
        if output < 0:
            output = output + 2*np.pi
        else:
            output = output - 2*np.pi
    return output

def getSequence(wirex,wirey,wireid,radius = 50,anglestyle = 'pi'):
    wirelength = len(wirex)-1
    output = np.zeros(wirelength*2)
    if anglestyle == 'pi':
        output[0] = np.angle(wirex[1]-wirex[0]+1j*(wirey[1]-wirey[0]))
    else:
        output[0] = np.angle(wirex[1]-wirex[0]+1j*(wirey[1]-wirey[0]))/np.pi*180
    output[1] = getDistance(wirex[:2],wirey[:2])
    for k in range(1,wirelength):
        output[2*k] = getAngleDif(wirex[k-1:k+2],wirey[k-1:k+2])
        output[2*k+1] = getDistance(wirex[k:k+2],wirey[k:k+2])
    decrease = [0]+[np.abs(radius * np.tan(output[2*k]/2)) for k in range(1,wirelength)] + [0]
    for k in range(wirelength):
        output[2*k+1] = output[2*k+1] - decrease[k] - decrease[k+1]
        output[2*k+1] = output[2*k+1]
        if output[2*k+1] < 0:
            print("%d error in (%f,%f)"%(wireid,wirex[k],wirey[k]))
    outputLength = output[1]
    for k in range(1,wirelength):
        outputLength = outputLength + radius * abs(output[2*k]) + output[2*k+1]
        if anglestyle == 'pi':
            output[2*k] = output[2*k]
        else:
            output[2*k] = output[2*k]/np.pi*180
    return [output,outputLength]

def getLineLength(line,radius):
    wirex,wirey  = ([p[0] for p in line],[p[1] for p in line])
    [_,LineLength] = getSequence(wirex,wirey,0,radius)
    return LineLength

# 得到中心点序列
def getPointLine(startx,starty,theta,line,arcshift,lbuffer,interval,endbuffer=0):
    npoint = np.floor((line+lbuffer-endbuffer)/interval)
    if npoint > 0:
        temp = np.arange(1,npoint+1,1)
        pointx = startx + (arcshift-lbuffer)*np.cos(theta) + interval*np.cos(theta)*temp
        pointy = starty + (arcshift-lbuffer)*np.sin(theta) + interval*np.sin(theta)*temp
        points_orientation = [[(pointx[k],pointy[k]),theta] for k in range(len(pointx))]
    else:
        points_orientation = []
    lbuffer = line + lbuffer - npoint*interval
    return [points_orientation,lbuffer]

def getPointArc(startx,starty,theta,radius,angle,lbuffer,interval):
    arcshift = np.tan(np.abs(angle)/2)*radius
    npoint = np.floor((radius*np.abs(angle)+lbuffer)/interval)
    if npoint > 0:
        temp1 = np.arange(1,npoint+1,1)
        if angle > 0:
            centerx = startx+arcshift*np.cos(theta)+radius*np.cos(theta+np.pi/2)
            centery = starty+arcshift*np.sin(theta)+radius*np.sin(theta+np.pi/2)
            temp2 = theta-angle+np.pi*3/2-lbuffer/radius
            pointx = centerx + radius * np.cos(temp2+interval/radius*temp1)
            pointy = centery + radius * np.sin(temp2+interval/radius*temp1)
            points_orientation = [[(pointx[k],pointy[k]),temp2+interval/radius*temp1[k]+np.pi/2] for k in range(len(pointx))]
        else:
            centerx = startx+arcshift*np.cos(theta)+radius*np.cos(theta-np.pi/2)
            centery = starty+arcshift*np.sin(theta)+radius*np.sin(theta-np.pi/2)
            temp2 = theta+np.pi/2-angle+lbuffer/radius
            pointx = centerx + radius * np.cos(temp2-interval/radius*temp1)
            pointy = centery + radius * np.sin(temp2-interval/radius*temp1)
            points_orientation = [[(pointx[k],pointy[k]),temp2-interval/radius*temp1[k]-np.pi/2] for k in range(len(pointx))]
    else:
        points_orientation = []
    lbuffer = radius*np.abs(angle)+lbuffer - npoint*interval
    return [points_orientation,lbuffer,arcshift]

def getPoints(wirex,wirey,interval=400,radius=50) -> list[tuple[float,float],float]:
    [wireSequence,_] = getSequence(wirex,wirey,0,radius = radius)
    wirelength = len(wirex)-1
    [points_orientation,lbuffer] = getPointLine(wirex[0],wirey[0],wireSequence[0],wireSequence[1],0,interval/2,interval)
    for k in range(1,wirelength-1):
        [points_orientation_new,lbuffer,arcshift] = getPointArc(wirex[k],wirey[k],getAngle(wirex[k:k+2],wirey[k:k+2]),radius,wireSequence[2*k],lbuffer,interval)
        points_orientation.extend(points_orientation_new)
        [points_orientation_new,lbuffer] = getPointLine(wirex[k],wirey[k],getAngle(wirex[k:k+2],wirey[k:k+2]),wireSequence[2*k+1],arcshift,lbuffer,interval)
        points_orientation.extend(points_orientation_new)
    k = wirelength-1
    if k > 0:
        [points_orientation_new,lbuffer,arcshift] = getPointArc(wirex[k],wirey[k],getAngle(wirex[k:k+2],wirey[k:k+2]),radius,wireSequence[2*k],lbuffer,interval)
        points_orientation.extend(points_orientation_new)
        [points_orientation_new,lbuffer] = getPointLine(wirex[k],wirey[k],getAngle(wirex[k:k+2],wirey[k:k+2]),wireSequence[2*k+1],arcshift,lbuffer,interval,interval/4)
        points_orientation.extend(points_orientation_new)
    return points_orientation

def getShiftPoint(point_orientation,shift):
    return (point_orientation[0][0]+shift*np.cos(point_orientation[1]+np.pi/2),point_orientation[0][1]+shift*np.sin(point_orientation[1]+np.pi/2))

def P2dB(p,data_type = 'p'):
    if data_type == 'p':
        return 10*np.log10(p)
    else:
        return 20*np.log10(p)

def dB2P(p,data_type = 'p'):
    if data_type == 'p':
        return 10**(p/10)
    else:
        return 10**(p/20)