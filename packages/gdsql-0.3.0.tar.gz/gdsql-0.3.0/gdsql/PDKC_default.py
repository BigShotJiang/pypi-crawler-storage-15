import numpy as np
from dataclasses import dataclass, field
from shapely import Polygon
from .cell import Cell, crossover, text, tsv
from .shape import (via, rectangle, capacitor_cg, capacitor_square, capacitor_interdigited_narrow, capacitor_interdigited_squared, 
                cpw, strip, tline, magic_T, shape_union, flip_x, flip_y, move, rotate, embeded, snake_rgl, snake_rgls, 
                pocket_c, pocket_c_mask, snake_port, snake_port2, octagon, clip_by_rect, trace, jj_nb_area, pad_square, pad_square_empty)
from .qlibrary import QLibrary

@dataclass
class ReadCavityHex(QLibrary):
    # 整体坐标
    flip_y:bool = False
    q_portx:float = 0
    q_porty:float = 0
    # 滤波器耦合端口相对坐标与形貌
    flt_dx:float = -174
    flt_dy:float = -423
    flt_w:float = 8
    flt_s:float = 16
    capa_len:float = 60
    capa_num:int = 11
    capa_finger_gap:float = 4
    capa_finger_width:float = 4
    capa_gap_width:float = 10
    capa_palm_width:float = 8
    etch_depth:float = 0
    # 比特耦合端口相对坐标与形貌
    cg_dy:float = -87-40
    cg_overlap:float = 165
    cg_width:float = 4
    cg_margin:float = 4
    cg_add:float = 120
    q_capa_large:float = 26
    q_capa_median:float = 28
    q_capa_small:float = 20
    # 读取腔形貌
    cav_w:float = 4
    cav_s:float = 8
    turn_r:float = 16
    len_to_capa:float = 16
    len_to_gap:float = 50
    len_total:float = 4200
    len_tail:float = 100
    len_solder:float = 80
    num_turn_half:int = 15
    
    def generate_shape(self) ->list[Polygon,list]:

        self.flt_dx = -abs(self.flt_dx)
        self.flt_dy = -abs(self.flt_dy)
        self.cg_dy = -abs(self.cg_dy)

        len_to_filter = 0 - self.flt_dx - self.cav_w - self.cav_s/2
        len_to_qubit = self.cg_dy - self.flt_dy - self.turn_r
        len_to_T = len_to_filter-self.len_to_capa*2-self.capa_gap_width*2-self.capa_palm_width*2-self.capa_len

        cav_cg = capacitor_square(200,90,self.cg_margin,self.cav_s,yoff=45+self.cg_dy)
        
        line1 = [(0,self.cg_dy),(0,self.cg_dy-len_to_qubit-self.turn_r),(0-len_to_T,self.cg_dy-len_to_qubit-self.turn_r)]
        
        [cav_line1,len1] = cpw(self.cav_w,self.cav_s,line1,radius = self.turn_r,endcut=self.cav_s/2,returnLength=True)
        
        x_now = 0-len_to_T
        y_now = self.cg_dy-len_to_qubit-self.turn_r

        magicT_0 = magic_T(self.cav_w,self.cav_s,0,0,self.len_to_capa,angle=180,xoff = x_now,yoff=y_now)
        
        cav_capa = capacitor_interdigited_squared(self.cav_w,self.cav_s,self.capa_len,self.capa_num,self.capa_finger_gap,self.capa_finger_width,self.capa_gap_width,self.capa_palm_width,
                                              len_left=self.len_to_capa,len_right=self.len_to_capa,angle=180,xoff=x_now-self.capa_gap_width-self.capa_palm_width-self.capa_len/2-self.len_to_capa-self.cav_w-self.cav_s/2,yoff=y_now)
        
        if self.etch_depth > 0:
            cav_capa = cav_capa.buffer(self.etch_depth)

        len_tune = len_to_filter - len_to_T - self.len_solder
        len_tune = np.floor(len_tune)
        len_cav = (self.len_total - self.len_tail - len_to_qubit - np.pi*self.turn_r - (len_to_T-self.turn_r) - self.len_to_gap - self.cav_s/2 + len_tune - self.turn_r - np.pi*self.turn_r*self.num_turn_half)/self.num_turn_half + 2*self.turn_r
        len_cav = np.floor(len_cav)

        line2 = [(x_now,y_now),
                    (x_now,y_now-self.len_to_gap-self.turn_r-self.cav_w),
                    (x_now+len_cav-len_tune,y_now-self.len_to_gap-self.turn_r-self.cav_w)]
        x_now = x_now+len_cav-len_tune
        y_now = y_now-self.len_to_gap-self.turn_r-self.cav_w
        for k in range(self.num_turn_half-1):
            if k%2 == 0:
                line2.extend([(x_now,y_now-self.turn_r*2),
                            (x_now-len_cav,y_now-self.turn_r*2)])
            else:
                line2.extend([(x_now-len_cav,y_now-self.turn_r*2),
                            (x_now,y_now-self.turn_r*2)])
            y_now = y_now - self.turn_r*2
        if self.num_turn_half%2 == 0:
            line2.extend([(x_now-len_cav,y_now-self.turn_r*2),(x_now-len_cav+self.len_tail+self.turn_r,y_now-self.turn_r*2)])
        else:
            line2.extend([(x_now,y_now-self.turn_r*2),(x_now-self.len_tail-self.turn_r,y_now-self.turn_r*2)])
        [cav_line2,len2] = cpw(self.cav_w,self.cav_s,line2,radius = self.turn_r,startcut=self.cav_s,returnLength=True)

        # print(f'len_total:{len1+len2}-{self.len_total}={len1+len2-self.len_total}')
 
        cav_shape = shape_union([cav_line1,magicT_0,cav_line2,cav_cg,cav_capa])

        if self.flip_y:
            cav_shape = flip_y(cav_shape,origin=(0,0))
            self.flt_dy = abs(self.flt_dy)

        cav_shape = move(cav_shape,xoff=self.q_portx,yoff=self.q_porty)

        if self.flip_y:
            ab_axy = [
                    (0,np.round(cav_line2.centroid.x/2)*2+self.q_portx,-(y_now-self.turn_r*2+12*self.turn_r*(ii+1/3))+self.q_porty) for ii in range(self.num_turn_half//4)
                    ]+[
                    (0,cav_capa.centroid.x+self.capa_len/2+self.capa_palm_width+self.capa_gap_width+self.len_to_capa/2+self.q_portx,-cav_capa.centroid.y+self.q_porty),
                    (0,cav_capa.centroid.x-self.capa_len/2-self.capa_palm_width-self.capa_gap_width-self.len_to_capa/2+self.q_portx,-cav_capa.centroid.y+self.q_porty)
                    ]
        else:
            ab_axy = [
                    (0,np.round(cav_line2.centroid.x/2)*2+self.q_portx,y_now-self.turn_r*2+12*self.turn_r*(ii+1/3)+self.q_porty) for ii in range(self.num_turn_half//4)
                    ]+[
                    (0,cav_capa.centroid.x+self.capa_len/2+self.capa_palm_width+self.capa_gap_width+self.len_to_capa/2+self.q_portx,cav_capa.centroid.y+self.q_porty),
                    (0,cav_capa.centroid.x-self.capa_len/2-self.capa_palm_width-self.capa_gap_width-self.len_to_capa/2+self.q_portx,cav_capa.centroid.y+self.q_porty)
                    ]
        return [cav_shape,ab_axy]
    
    def generate_mask(self) -> Polygon:
        self.flt_dx = -abs(self.flt_dx)
        self.flt_dy = -abs(self.flt_dy)
        self.cg_dy = -abs(self.cg_dy)

        len_to_filter = 0 - self.flt_dx - self.cav_w - self.cav_s/2
        len_to_qubit = self.cg_dy - self.flt_dy - self.turn_r
        len_to_T = len_to_filter-self.len_to_capa*2-self.capa_gap_width*2-self.capa_palm_width*2-self.capa_len

        cav_cg = via(200+self.cg_width*2,90+self.cg_width*2,yoff=45+self.cg_dy,style='mitre')
        
        line1 = [(0,self.cg_dy),(0,self.cg_dy-len_to_qubit-self.turn_r),(0-len_to_T,self.cg_dy-len_to_qubit-self.turn_r)]
        
        [cav_line1,len1] = tline(self.cav_w+self.cav_s/2,0,line1,radius = self.turn_r,endcut=self.cav_s/2,returnLength=True)
        
        x_now = 0-len_to_T
        y_now = self.cg_dy-len_to_qubit-self.turn_r

        magicT_0 = magic_T(self.cav_w+self.cav_s/2,0,0,0,self.len_to_capa,angle=180,xoff = x_now,yoff=y_now)
        
        cav_capa = shape_union([via(self.capa_len+self.capa_gap_width*2+self.capa_palm_width*2,self.capa_finger_width*self.capa_num+self.capa_finger_gap*(self.capa_num-1)+self.capa_gap_width*2,
                                xoff=x_now-self.capa_gap_width-self.capa_palm_width-self.capa_len/2-self.len_to_capa-self.cav_w-self.cav_s/2,yoff=y_now,style='mitre'),
                                via(self.capa_len+(self.capa_gap_width+self.capa_palm_width+self.len_to_capa)*2,self.cav_w*2+self.cav_s,
                                xoff=x_now-self.capa_gap_width-self.capa_palm_width-self.capa_len/2-self.len_to_capa-self.cav_w-self.cav_s/2,yoff=y_now,style='mitre')])
        
        len_tune = len_to_filter - len_to_T - self.len_solder
        len_tune = np.floor(len_tune)
        len_cav = (self.len_total - self.len_tail - len_to_qubit - np.pi*self.turn_r - (len_to_T-self.turn_r) - self.len_to_gap - self.cav_s/2 + len_tune - self.turn_r - np.pi*self.turn_r*self.num_turn_half)/self.num_turn_half + 2*self.turn_r
        len_cav = np.floor(len_cav)

        line2 = [(x_now,y_now),
                    (x_now,y_now-self.len_to_gap-self.turn_r-self.cav_w),
                    (x_now+len_cav-len_tune,y_now-self.len_to_gap-self.turn_r-self.cav_w)]
        x_now = x_now+len_cav-len_tune
        y_now = y_now-self.len_to_gap-self.turn_r-self.cav_w
        for k in range(self.num_turn_half-1):
            if k%2 == 0:
                line2.extend([(x_now,y_now-self.turn_r*2),
                            (x_now-len_cav,y_now-self.turn_r*2)])
            else:
                line2.extend([(x_now-len_cav,y_now-self.turn_r*2),
                            (x_now,y_now-self.turn_r*2)])
            y_now = y_now - self.turn_r*2
        if self.num_turn_half%2 == 0:
            line2.extend([(x_now-len_cav,y_now-self.turn_r*2),(x_now-len_cav+self.len_tail+self.turn_r,y_now-self.turn_r*2)])
        else:
            line2.extend([(x_now,y_now-self.turn_r*2),(x_now-self.len_tail-self.turn_r,y_now-self.turn_r*2)])
        [cav_line2,len2] = tline(self.cav_w+self.cav_s/2,0,line2,radius = self.turn_r,startcut=self.cav_s,returnLength=True)

        # print(f'len_total:{len1+len2}-{self.len_total}={len1+len2-self.len_total}')
 
        cav_shape = shape_union([cav_line1,magicT_0,cav_line2,cav_cg,cav_capa])

        if self.flip_y:
            cav_shape = flip_y(cav_shape,origin=(0,0))
            self.flt_dy = abs(self.flt_dy)

        cav_shape = move(cav_shape,xoff=self.q_portx,yoff=self.q_porty)

        return cav_shape
    
    def generate_cell(self,add_mask=True) -> Cell:
        cavity = Cell('cavity')
        [cav_shape,ab_axy] = self.generate_shape()
        cavity.add_polygon(cav_shape,"METB")

        if add_mask:
            cav_mask = self.generate_mask()
            cavity.add_polygon(cav_mask,'MASKB')

        ab = crossover(self.cav_s+self.cav_w*2,2,4,6,3,False)
        cavity.add_crossover_axy(ab,ab_axy)

        return cavity
    
    def simulate_cell(self, cavity_list = None) -> Cell:
        cavity = Cell('cavity')
        [cav_shape,ab_axy] = self.generate_shape()

        tline_x = self.q_portx + self.flt_dx - self.flt_w - self.flt_s/2
        tline_y_min = cav_shape.bounds[1] - 40
        tline_y_max = cav_shape.bounds[3] + 40

        tline = cpw(self.flt_w,self.flt_s,[(tline_x,tline_y_min),(tline_x,tline_y_max)])

        simu_shape = shape_union([tline,cav_shape])
        cavity.add_polygon(embeded(simu_shape,40,0,40,0),"METB")

        ab_cav = crossover(self.cav_s+self.cav_w*2,2,4,6,3,True)
        cavity.add_crossover_axy(ab_cav,ab_axy)

        ab_axy2 = [
                (90,tline_x,self.q_porty + self.flt_dy + 2*self.turn_r),
                (90,tline_x,self.q_porty + self.flt_dy - 2*self.turn_r)
                ]
        
        ab_flt = crossover(self.flt_s+self.flt_w*2,2,4,6,3,True)
        cavity.add_crossover_axy(ab_flt,ab_axy2)

        return cavity

    def simulate_c2qubit(self, qubit = None) -> Cell:
        cav_cg = capacitor_cg(self.cg_overlap,self.cg_margin,self.cg_width,self.cg_add,self.q_capa_large,
                                 self.q_capa_median,self.q_capa_small,self.cav_w,self.cav_s,angle=0)
        portx = -self.q_capa_large / 2 - self.q_capa_small - self.q_capa_median - self.cg_margin + self.cav_w / 2**0.5
        porty = -self.q_capa_large / 2 - self.q_capa_small - self.q_capa_median - self.cg_margin + self.cav_w / 2**0.5
        port = cpw(self.cav_w,self.cav_s,[(portx,porty),(portx-self.cav_w * 5*2**0.5,porty-self.cav_w * 5*2**0.5)])
        port_end = via(self.cav_w,self.cav_w*2+self.cav_s,style='mitre',angle=45,xoff=portx-self.cav_w * 5*2**0.5,yoff=porty-self.cav_w * 5*2**0.5)
        box = rectangle(-650,-650,650,650)
        c = Cell()
        c.add_polygon(box - cav_cg - port - port_end,"METB")
        c.add_label('port',(portx-self.cav_w * 4.75*2**0.5,porty-self.cav_w * 4.75*2**0.5))
        return c

    def simulate_c2filter(self, ecth = False) -> Cell:
        cav_capa = capacitor_interdigited_squared(self.cav_w,self.cav_s,self.capa_len,self.capa_num,self.capa_finger_gap,self.capa_finger_width,self.capa_gap_width,self.capa_palm_width,
                                              len_left=self.len_to_capa,len_right=self.len_to_capa)

        if ecth and self.etch_depth > 0:
            cav_capa = cav_capa.buffer(self.etch_depth)

        c = Cell()
        c.add_polygon(embeded(cav_capa,0,50,0,50),"METB")
        ab = crossover(self.cav_s+self.cav_w*2,2,4,6,3,True)
        ab_axy = [
                (0,cav_capa.centroid.x-self.capa_len/2-self.capa_palm_width-self.capa_gap_width-self.len_to_capa/2,cav_capa.centroid.y),
                (0,cav_capa.centroid.x+self.capa_len/2+self.capa_palm_width+self.capa_gap_width+self.len_to_capa/2,cav_capa.centroid.y)
                ]
        c.add_crossover_axy(ab,ab_axy)
        c.add_label('port',(c.xmin,0))
        c.add_label('port',(c.xmax,0))
        return c

@dataclass
class ReadFilterHex(QLibrary):
    flip_y:bool = False
    ri_portx:float = 0
    ri_porty:float = 0
    ro_portx:float = None
    ro_porty:float = None
    len_to_box:float = 150
    len_rl1:float = 4366
    len_rl2:float = 4954
    len_rl3:float = 10490-400-300
    len_rl3_d:float = 140
    len_rl3_r:float = 80
    len_gl1:float = 882
    len_gl2:float = 226
    len_gl3:float = 36
    len_to_gl:float = 18
    len_to_capa:float = 30
    num_turn_rl1:float = 6
    num_turn_rl2:float = 6
    capa_num:int = 11
    capa_len:float = 63
    len_narrow:float = 50
    turn_r:float = 26
    flt_w:float = 8
    flt_s:float = 16
    etch_depth:float = 0
    
    def generate_shape(self) -> list[Polygon,list]:

        line1 = snake_rgl(self.flt_w,self.flt_s,self.turn_r,self.len_rl1,self.len_gl1+self.flt_s/2,self.len_to_gl+self.turn_r+self.flt_s/2,self.len_to_capa+self.turn_r,self.num_turn_rl1*2,printDif=False)

        line1_rightx = line1.bounds[2]
        line1_righty = (line1.bounds[1]+line1.bounds[3])/2

        cav_capa = capacitor_interdigited_narrow(self.flt_w,self.flt_s,self.capa_len,self.capa_num,4,4,24,6,self.len_narrow,len_left=0,len_right=0,xoff=line1.bounds[2] +self.len_narrow+self.capa_len/2,yoff=line1_righty)
        if self.etch_depth > 0:
            cav_capa = cav_capa.buffer(self.etch_depth)

        line2 = move(flip_x(snake_rgl(self.flt_w,self.flt_s,self.turn_r,self.len_rl2,self.len_gl2+self.flt_s/2,self.len_to_gl+self.turn_r+self.flt_s/2,self.len_to_capa+self.turn_r,self.num_turn_rl2*2+1,line1_righty,printDif=False)),xoff=line1_rightx+self.flt_s/2+self.flt_w+self.len_narrow*2+self.capa_len)

        line2_rightx = line2.bounds[2]
        line2_centery = (line2.bounds[1]+line2.bounds[3])/2

        line3_rest = np.round(self.len_rl3 - self.len_rl3_d - np.pi*self.len_rl3_r)

        line3_points = [(line2_rightx,0),
                   (line2_rightx+self.len_rl3_d+self.len_rl3_r,0),
                   (line2_rightx+self.len_rl3_d+self.len_rl3_r,-self.len_rl3_r*2),
                   (line2_rightx+self.len_rl3_d-line3_rest,-self.len_rl3_r*2)]
        
        line3 = cpw(self.flt_w,self.flt_s,line3_points,radius=self.len_rl3_r,endcut=self.flt_s/2)

        line3_T = magic_T(self.flt_w,self.flt_s,0,0,self.len_gl3-self.flt_w/2,angle=180,xoff=line2_rightx+self.len_rl3_d-line3_rest,yoff=-self.len_rl3_r*2)

        filter_shape = rotate(shape_union([line1,line2,line3,line3_T,cav_capa]),90,origin=(0,0))

        xoff=self.ri_portx
        yoff=self.ri_porty
        self.ro_portx = self.len_rl3_r*2
        self.ro_porty = line2_rightx+self.len_rl3_d-line3_rest

        ab_axy_temp = [
            (0, -line1_righty, 0)
        ] + [
            (0, -line1_righty, (self.len_to_gl + self.flt_s/2 + self.turn_r * (6 * ii + 5))) for ii in range(self.num_turn_rl1 - 2)
        ] + [
            (0, -line2_centery, (line2_rightx - self.flt_s/2 - self.flt_w*2 - self.len_to_gl - self.turn_r * (6 * ii + 1))) for ii in range(self.num_turn_rl2 - 1)
        ] + [
            (90, -cav_capa.centroid.y, (cav_capa.bounds[0]-self.len_to_capa/2)),
            (90, -cav_capa.centroid.y, (cav_capa.bounds[2]+self.len_to_capa/2))]

        ab_axy = []

        if self.flip_y:
            filter_shape = flip_y(filter_shape,origin=(0,0))
            self.ro_portx = self.ro_portx + xoff
            self.ro_porty = -self.ro_porty + yoff
            for a,x,y in ab_axy_temp:
                a2 = a
                x2 = x + xoff
                y2 = -y + yoff
                ab_axy.append((a2,x2,y2))
        else:
            self.ro_portx = self.ro_portx + xoff
            self.ro_porty = self.ro_porty + yoff
            for a,x,y in ab_axy_temp:
                a2 = a
                x2 = x + xoff
                y2 = y + yoff
                ab_axy.append((a2,x2,y2))
        
        filter_shape = move(filter_shape,xoff=xoff,yoff=yoff)

        return [filter_shape,ab_axy]
        
    def generate_mask(self) -> Polygon:

        line1 = snake_rgl(self.flt_w+self.flt_s/2,0,self.turn_r,self.len_rl1,self.len_gl1+self.flt_s/2,self.len_to_gl+self.turn_r+self.flt_s/2,self.len_to_capa+self.turn_r,self.num_turn_rl1*2,printDif=False)

        line1_rightx = line1.bounds[2]
        line1_righty = (line1.bounds[1]+line1.bounds[3])/2

        cav_capa = octagon(self.len_narrow*2+self.capa_len,144,self.capa_len,self.flt_w*2+self.flt_s,
                        xoff=line1.bounds[2] +self.len_narrow+self.capa_len/2,yoff=line1_righty)

        line2 = move(flip_x(snake_rgl(self.flt_w+self.flt_s/2,0,self.turn_r,self.len_rl2,self.len_gl2+self.flt_s/2,self.len_to_gl+self.turn_r+self.flt_s/2,self.len_to_capa+self.turn_r,self.num_turn_rl2*2+1,line1_righty,printDif=False)),xoff=line1_rightx+self.flt_s/2+self.flt_w+self.len_narrow*2+self.capa_len)

        line2_rightx = line2.bounds[2]
        line2_centery = (line2.bounds[1]+line2.bounds[3])/2

        line3_rest = np.round(self.len_rl3 - self.len_rl3_d - np.pi*self.len_rl3_r)

        line3_points = [(line2_rightx,0),
                   (line2_rightx+self.len_rl3_d+self.len_rl3_r,0),
                   (line2_rightx+self.len_rl3_d+self.len_rl3_r,-self.len_rl3_r*2),
                   (line2_rightx+self.len_rl3_d-line3_rest,-self.len_rl3_r*2)]
        
        line3 = tline(self.flt_w+self.flt_s/2,0,line3_points,radius=self.len_rl3_r,endcut=self.flt_s/2)

        line3_T = magic_T(self.flt_w+self.flt_s/2,0,0,0,self.len_gl3-self.flt_w/2,angle=180,xoff=line2_rightx+self.len_rl3_d-line3_rest,yoff=-self.len_rl3_r*2)

        filter_shape = rotate(shape_union([line1,line2,line3,line3_T,cav_capa]),90,origin=(0,0))

        xoff=self.ri_portx
        yoff=self.ri_porty
        self.ro_portx = self.len_rl3_r*2
        self.ro_porty = line2_rightx+self.len_rl3_d-line3_rest

        if self.flip_y:
            filter_shape = flip_y(filter_shape,origin=(0,0))
            self.ro_portx = self.ro_portx + xoff
            self.ro_porty = -self.ro_porty + yoff
        else:
            self.ro_portx = self.ro_portx + xoff
            self.ro_porty = self.ro_porty + yoff
  
        filter_shape = move(filter_shape,xoff=xoff,yoff=yoff)

        return filter_shape
    
    def generate_cell(self,cavity_list: None | list[ReadCavityHex] = None,add_mask = True) -> Cell:

        if cavity_list:
            self.ri_portx = cavity_list[0].q_portx + cavity_list[0].flt_dx - self.flt_w - self.flt_s/2 - self.len_rl3_r*2
            self.ro_portx = self.ri_portx + self.len_rl3_r*2

        [filter_shape,ab_axy] = self.generate_shape()
        ab_flt = crossover(self.flt_s+self.flt_w*2,2,4,6,3,False)
        
        filter = Cell('filter')
        filter.add_crossover_axy(ab_flt,ab_axy)
        
        if cavity_list:
            for cavity in cavity_list:
                ab_cav = crossover(cavity.cav_s+cavity.cav_w*2,2,4,6,3,False)
                [cavity_shape,cav_axy] = cavity.generate_shape()

                # 增加读取腔
                filter.add_polygon(cavity_shape,'METB')
                filter.add_crossover_axy(ab_cav,cav_axy)
                if add_mask:
                    cav_mask = cavity.generate_mask()
                    filter.add_polygon(cav_mask,'MASKB')

                # 增加filter上的crossover
                flt_axy = [(90,cavity.q_portx+cavity.flt_dx-cavity.flt_w-cavity.flt_s/2,cavity.q_porty+cavity.flt_dy+2*cavity.turn_r),
                            (90,cavity.q_portx+cavity.flt_dx-cavity.flt_w-cavity.flt_s/2,cavity.q_porty+cavity.flt_dy-2*cavity.turn_r)]

                filter.add_crossover_axy(ab_flt,flt_axy)

                # 改变filter的图形
                filter_shape = filter_shape - rectangle(cavity.q_portx+cavity.flt_dx-cavity.flt_w-cavity.flt_s/2,
                                                        cavity.q_porty+cavity.flt_dy-cavity.cav_s/2,
                                                        cavity.q_portx+cavity.flt_dx+cavity.flt_w,
                                                        cavity.q_porty+cavity.flt_dy+cavity.cav_s/2)

        filter.add_polygon(filter_shape,"METB")

        if add_mask:
            filter_mask = self.generate_mask()
            filter.add_polygon(filter_mask,'MASKB')

        return filter
    
    def simulate_cell(self,cavity_list: None | list[ReadCavityHex] = None) -> Cell:

        if cavity_list:
            self.ri_portx = cavity_list[0].q_portx + cavity_list[0].flt_dx - self.flt_w - self.flt_s/2 - self.len_rl3_r*2
            self.ro_portx = self.ri_portx + self.len_rl3_r*2

        [filter_shape,ab_axy] = self.generate_shape()
        ab_flt = crossover(self.flt_s+self.flt_w*2,2,4,6,3,True)
        
        filter = Cell('filter')
        filter.add_crossover_axy(ab_flt,ab_axy)

        cavity_shape_list = []

        if cavity_list:
            for cavity in cavity_list:
                ab_cav = crossover(cavity.cav_s+cavity.cav_w*2,2,4,6,3,True)
                [cavity_shape,cav_axy] = cavity.generate_shape()

                # 增加读取腔
                cavity_shape_list.append(cavity_shape)
                filter.add_crossover_axy(ab_cav,cav_axy)

                # 增加filter上的crossover
                flt_axy = [(90,cavity.q_portx+cavity.flt_dx-cavity.flt_w-cavity.flt_s/2,cavity.q_porty+cavity.flt_dy+2*cavity.turn_r),
                            (90,cavity.q_portx+cavity.flt_dx-cavity.flt_w-cavity.flt_s/2,cavity.q_porty+cavity.flt_dy-2*cavity.turn_r)]

                filter.add_crossover_axy(ab_flt,flt_axy)

                # 改变filter的图形
                filter_shape = filter_shape - rectangle(cavity.q_portx+cavity.flt_dx-cavity.flt_w-cavity.flt_s/2,
                                                        cavity.q_porty+cavity.flt_dy-cavity.cav_s/2,
                                                        cavity.q_portx+cavity.flt_dx+cavity.flt_w,
                                                        cavity.q_porty+cavity.flt_dy+cavity.cav_s/2)

        if self.flip_y:
            line_to_top = cpw(self.flt_w,self.flt_s,[(self.ro_portx,self.ro_porty),(self.ro_portx,self.ro_porty+self.len_to_box)],startcut=self.flt_s/2)
            line_to_down = cpw(self.flt_w,self.flt_s,[(self.ri_portx,self.ri_porty),(self.ri_portx,self.ri_porty+2*self.len_to_box),(filter_shape.bounds[0]-self.len_to_box,self.ri_porty+2*self.len_to_box)],startcut=self.flt_s/2)
            filter_shape = shape_union(cavity_shape_list+[filter_shape,line_to_top,line_to_down])
            filter.add_polygon(embeded(filter_shape,0,self.len_to_box,self.len_to_box,0),"METB")
        else:
            line_to_top = cpw(self.flt_w,self.flt_s,[(self.ri_portx,self.ri_porty),(self.ri_portx,self.ri_porty-2*self.len_to_box),(filter_shape.bounds[0]-self.len_to_box,self.ri_porty-2*self.len_to_box)],startcut=self.flt_s/2)
            line_to_down = cpw(self.flt_w,self.flt_s,[(self.ro_portx,self.ro_porty),(self.ro_portx,self.ro_porty-self.len_to_box)],startcut=self.flt_s/2)
            filter_shape = shape_union(cavity_shape_list+[filter_shape,line_to_top,line_to_down])
            filter.add_polygon(embeded(filter_shape,0,0,self.len_to_box,self.len_to_box),"METB")

        return filter

@dataclass
class JJManhattan(QLibrary):
    jj_center_x:float = 0
    jj_width:float = 0.1
    jj_rootw:float = 0.14
    jj_dy_px:float = -4
    jj_dy_py:float = 8
    jj_dy_lr:float = -6
    jj_dy_ll:float = -14
    jj_dx_px:float = -10
    jj_dx_py:float = -2
    jj_dx_lr:float = 5
    jj_dx_ll:float = 9
    patch_width:float = 0.14
    patch_len1:float = 2
    patch_len2:float = 2
    patch_dy_list:list[float] = field(default_factory=lambda: [-1,-2])
    patch_dx_list:list[float] = field(default_factory=lambda: [1,2])
    squid:bool = True
    jj_area_Txmin:float = -6
    jj_area_Txmax:float = 6
    jj_area_Tymin:float = 4
    jj_area_Tymax:float = 16
    jj_area_Bymin:float = -16
    jj_area_Bymax:float = 0
    jj_area_Bylem:float = -8
    jj_area_Bxlen:float = 22
    jj_area_Bxmid:float = 12
        
    def generate_shape(self) -> Polygon:
        jj_vr = strip(self.jj_rootw,[(self.jj_dy_px,self.jj_dy_py),(self.jj_dy_px,self.jj_dy_py+self.jj_dy_lr)])
        jj_v = strip(self.jj_width,[(self.jj_dy_px,self.jj_dy_py),(self.jj_dy_px,self.jj_dy_py+self.jj_dy_ll)])
        jj_hr = strip(self.jj_rootw,[(self.jj_dx_px,self.jj_dx_py),(self.jj_dx_px+self.jj_dx_lr,self.jj_dx_py)])
        jj_h = strip(self.jj_width,[(self.jj_dx_px,self.jj_dx_py),(self.jj_dx_px+self.jj_dx_ll,self.jj_dx_py)])
        shape_mma = [jj_hr,jj_vr,jj_v,jj_h]
  
        patch_point = []
        for dy in self.patch_dy_list:
            patch_point.append((jj_v.centroid.x,jj_v.bounds[3]+dy))
        for dx in self.patch_dx_list:
            patch_point.append((jj_h.bounds[0]+dx,jj_h.centroid.y))
        
        if self.squid:
            jj_v_2 = flip_x(jj_v,origin=(self.jj_center_x,0))
            jj_h_2 = flip_x(jj_h,origin=(self.jj_center_x,0))
            jj_vr_2 = flip_x(jj_vr,origin=(self.jj_center_x,0))
            jj_hr_2 = flip_x(jj_hr,origin=(self.jj_center_x,0))
            shape_mma = shape_mma + [jj_hr_2,jj_vr_2,jj_v_2,jj_h_2]
            for dy in self.patch_dy_list:
                patch_point.append((jj_v_2.centroid.x,jj_v_2.bounds[3]+dy))
            for dx in self.patch_dx_list:
                patch_point.append((jj_h_2.bounds[2]-dx,jj_h_2.centroid.y))

        shape_patch = [strip(self.patch_width,[(pt[0]-self.patch_len2/1.414,pt[1]-self.patch_len2/1.414),(pt[0]+self.patch_len1/1.414,pt[1]+self.patch_len1/1.414)]) for pt in patch_point]
        shape_jj = shape_union(shape_mma+shape_patch)
        return shape_jj
    
    def generate_shape_mq(self) -> Polygon:
        qubit_j_T = rectangle(self.jj_area_Txmin,self.jj_area_Tymin,self.jj_area_Txmax,self.jj_area_Tymax)
        qubit_j_B1 = rectangle(-self.jj_area_Bxlen/2,self.jj_area_Bymin,-self.jj_area_Bxmid/2,self.jj_area_Bymax)
        qubit_j_B2 = flip_x(qubit_j_B1,origin=(0,0))
        qubit_j_B3 = rectangle(-self.jj_area_Bxmid/2,self.jj_area_Bymin,self.jj_area_Bxmid/2,self.jj_area_Bylem)
        return shape_union([qubit_j_T,qubit_j_B1,qubit_j_B2,qubit_j_B3])
    
    def generate_cell(self) -> Cell:
        shape_jj = self.generate_shape()
        shape_mq = self.generate_shape_mq()
        c = Cell()
        c.add_polygon(shape_jj,'MMA')
        c.add_polygon(embeded(shape_mq,20,0,20,0),'METT')
        return c

    def generate_mask(self):
        return super().generate_mask()
    
    def simulate_cell(self):
        return super().simulate_cell()

@dataclass
class QubitCouplerArrayHex(QLibrary):
    q_portx:float = 0
    q_porty:float = 0
    q_row:float = 21
    q_col:float = 54
    q_interval:float = 1400
    q_pad_width:float = 360
    q_pad_heigth:float = 140
    q_pad_gap:float = 20
    q_pad_ground_l:float = 32
    q_pad_ground_h:float = 70
    q_coupler_width:float = 80
    q_coupler_heigth:float = 20
    q_coupler_cdx:float = 100
    q_coupler_cdy:float = 180
    coupler_s:float = 8
    coupler_w:float = 4
    coupler_radius:float = 28
    c_length:float = 10500

    def generate_shape(self,type:str) -> list[Polygon]:
        if type == 'qubit':
            shape_qubit = pocket_c(self.q_pad_width,
                                    self.q_pad_heigth,
                                    self.q_pad_gap,
                                    self.q_pad_ground_l,
                                    self.q_pad_ground_h,
                                    self.q_coupler_width,
                                    self.q_coupler_heigth,
                                    self.q_coupler_cdx,
                                    self.q_coupler_cdy,
                                    self.coupler_s)
            jj_axy = [(0,0,0)]
            return [shape_qubit,jj_axy]
        else:
            shape_htc = snake_port(self.coupler_w,self.coupler_s,(self.q_coupler_cdx+self.q_coupler_width/2,self.q_coupler_cdy),
                                (self.q_interval-(self.q_coupler_cdx+self.q_coupler_width/2),-self.q_coupler_cdy),self.c_length,self.coupler_radius,300,300)
            shape_hbc = snake_port(self.coupler_w,self.coupler_s,(self.q_coupler_cdx+self.q_coupler_width/2,-self.q_coupler_cdy),
                                (self.q_interval-(self.q_coupler_cdx+self.q_coupler_width/2),self.q_coupler_cdy),self.c_length,self.coupler_radius,300,300,turnup=False)

            ratio = 0.95
            shape_hlc = shape_union([snake_port(self.coupler_w,self.coupler_s,(self.q_coupler_cdx+self.q_coupler_width/2,self.q_coupler_cdy),(self.q_interval,600),self.c_length*ratio ,self.coupler_radius,300,300),
                                    snake_port(self.coupler_w,self.coupler_s,(self.q_interval,600),(2*self.q_interval-(self.q_coupler_cdx+self.q_coupler_width/2),self.q_coupler_cdy),self.c_length*(1-ratio),self.coupler_radius,1000,100,turnup=False)])
            
            ratio = 0.05
            shape_hrc = shape_union([snake_port(self.coupler_w,self.coupler_s,(self.q_coupler_cdx+self.q_coupler_width/2,self.q_coupler_cdy),(self.q_interval,600),self.c_length*ratio ,self.coupler_radius,100,1000),
                                    snake_port(self.coupler_w,self.coupler_s,(self.q_interval,600),(2*self.q_interval-(self.q_coupler_cdx+self.q_coupler_width/2),self.q_coupler_cdy),self.c_length*(1-ratio),self.coupler_radius,300,300,turnup=False)])
            
            shape_vc = snake_port2(self.coupler_w,self.coupler_s,(self.q_coupler_cdx+self.q_coupler_width/2,-self.q_coupler_cdy),
                                (-(self.q_coupler_cdx+self.q_coupler_width/2),-self.q_interval+self.q_coupler_cdy),self.c_length,self.coupler_radius,50,50,self.q_interval/2-480)

            return [shape_htc,shape_hbc,shape_hlc,shape_hrc,shape_vc]
        
    def generate_mask(self,type:str) -> list[Polygon]:
        if type == 'qubit':
            shape_qubit = pocket_c_mask(self.q_pad_width,
                                    self.q_pad_heigth,
                                    self.q_pad_gap,
                                    self.q_pad_ground_l,
                                    self.q_pad_ground_h,
                                    self.q_coupler_width,
                                    self.q_coupler_heigth,
                                    self.q_coupler_cdx,
                                    self.q_coupler_cdy,
                                    self.coupler_s)
            jj_axy = [(0,0,0)]
            return [shape_qubit]
        else:
            shape_htc = snake_port(self.coupler_w+self.coupler_s/2,0,(self.q_coupler_cdx+self.q_coupler_width/2,self.q_coupler_cdy),
                                (self.q_interval-(self.q_coupler_cdx+self.q_coupler_width/2),-self.q_coupler_cdy),self.c_length,self.coupler_radius,300,300)
            shape_hbc = snake_port(self.coupler_w+self.coupler_s/2,0,(self.q_coupler_cdx+self.q_coupler_width/2,-self.q_coupler_cdy),
                                (self.q_interval-(self.q_coupler_cdx+self.q_coupler_width/2),self.q_coupler_cdy),self.c_length,self.coupler_radius,300,300,turnup=False)

            ratio = 0.95
            shape_hlc = shape_union([snake_port(self.coupler_w+self.coupler_s/2,0,(self.q_coupler_cdx+self.q_coupler_width/2,self.q_coupler_cdy),(self.q_interval,600),self.c_length*ratio ,self.coupler_radius,300,300),
                                    snake_port(self.coupler_w+self.coupler_s/2,0,(self.q_interval,600),(2*self.q_interval-(self.q_coupler_cdx+self.q_coupler_width/2),self.q_coupler_cdy),self.c_length*(1-ratio),self.coupler_radius,1000,100,turnup=False)])
            
            ratio = 0.05
            shape_hrc = shape_union([snake_port(self.coupler_w+self.coupler_s/2,0,(self.q_coupler_cdx+self.q_coupler_width/2,self.q_coupler_cdy),(self.q_interval,600),self.c_length*ratio ,self.coupler_radius,100,1000),
                                    snake_port(self.coupler_w+self.coupler_s/2,0,(self.q_interval,600),(2*self.q_interval-(self.q_coupler_cdx+self.q_coupler_width/2),self.q_coupler_cdy),self.c_length*(1-ratio),self.coupler_radius,300,300,turnup=False)])
            
            shape_vc = snake_port2(self.coupler_w+self.coupler_s/2,0,(self.q_coupler_cdx+self.q_coupler_width/2,-self.q_coupler_cdy),
                                (-(self.q_coupler_cdx+self.q_coupler_width/2),-self.q_interval+self.q_coupler_cdy),self.c_length,self.coupler_radius,50,50,self.q_interval/2-480)

            return [shape_htc,shape_hbc,shape_hlc,shape_hrc,shape_vc]

    def generate_cell(self,jj_list:list[tuple[JJManhattan,int,int,int,int]] = None,add_mask:bool = True,jj_info:bool = False) -> Cell:

        [shape_qubit,jj_axy] = self.generate_shape('qubit')
        [shape_htc,shape_hbc,shape_hlc,shape_hrc,shape_vc] = self.generate_shape('coupler')

        self.q_portx = -(self.q_col-1)*self.q_interval/2
        self.q_porty = -(self.q_row-1)*self.q_interval/2
        chip_cell = Cell()

        if add_mask:
            [mask_qubit] = self.generate_mask('qubit')

        if jj_list:
            for jjm,col0,col1,row0,row1 in jj_list:
                qubit_cell = Cell('qubit')
                shape_jj = jjm.generate_shape()
                for a,x,y in jj_axy:
                    qubit_cell.add_polygon(move(rotate(shape_jj,a),x,y),"MMA")
                shape_mq = jjm.generate_shape_mq()
                qubit_cell.add_polygon(shape_qubit - shape_mq,"METT")
                if add_mask:
                    qubit_cell.add_polygon(mask_qubit,'MASKT')
                chip_cell.add_array(qubit_cell,columns=col1-col0+1,rows=row1-row0+1,spacing=(self.q_interval,self.q_interval)).move([self.q_portx+(col0-1)*self.q_interval,self.q_porty+(row0-1)*self.q_interval])
                if jj_info:
                    text_cell = text(str(int(jjm.jj_width*1000)),30,'METT')
                    chip_cell.add_array(text_cell,columns=col1-col0+1,rows=row1-row0+1,spacing=(self.q_interval,self.q_interval)).move([self.q_portx+(col0-1)*self.q_interval+280,self.q_porty+(row0-1)*self.q_interval])
        else:
            qubit_cell = Cell('qubit')
            qubit_cell.add_polygon(shape_qubit,"METT")
            if add_mask:
                qubit_cell.add_polygon(mask_qubit,'MASKT')
            chip_cell.add_array(qubit_cell,columns=self.q_col,rows=self.q_row,spacing=(self.q_interval,self.q_interval)).move([self.q_portx,self.q_porty])
        
        coupler_ht = Cell('coupler_ht')
        coupler_ht.add_polygon(shape_htc,"METT")

        coupler_hb = Cell('coupler_hb')
        coupler_hb.add_polygon(shape_hbc,"METT")

        coupler_hl = Cell('coupler_hl')
        coupler_hl.add_polygon(shape_hlc,"METT")

        coupler_hr = Cell('coupler_hr')
        coupler_hr.add_polygon(shape_hrc,"METT")
   
        coupler_v = Cell('coupler_v')
        coupler_v.add_polygon(shape_vc,"METT")

        if add_mask:
            [mask_htc,mask_hbc,mask_hlc,mask_hrc,mask_vc] = self.generate_mask('coupler')
            coupler_ht.add_polygon(mask_htc,'MASKT')
            coupler_hb.add_polygon(mask_hbc,'MASKT')
            coupler_hl.add_polygon(mask_hlc,'MASKT')
            coupler_hr.add_polygon(mask_hrc,'MASKT')
            coupler_v.add_polygon(mask_vc,'MASKT')

        for list_y in range(self.q_row):
            for list_x in range(self.q_col):
                if list_y == 0:
                    if list_x < self.q_col-1:
                        if list_x%5 == 4:
                            chip_cell.add_ref(coupler_hl).move([self.q_interval*list_x+self.q_portx,self.q_interval*list_y+self.q_porty])
                        elif list_x%5 != 0:
                            chip_cell.add_ref(coupler_ht).move([self.q_interval*list_x+self.q_portx,self.q_interval*list_y+self.q_porty])
                elif list_y == self.q_row-1:
                    if (list_y%2 == 0 and list_x < self.q_col-2) or (list_y%2 == 1 and list_x > 0 and list_x < self.q_col-1):
                        if list_y%2 == 0:
                            if list_x%5 == 4:
                                chip_cell.add_ref(coupler_hl).move([self.q_interval*list_x+self.q_portx,self.q_interval*list_y+self.q_porty])
                            else:
                                chip_cell.add_ref(coupler_ht).move([self.q_interval*list_x+self.q_portx,self.q_interval*list_y+self.q_porty])
                            if list_x%5 == 0:
                                chip_cell.add_ref(coupler_v).move([self.q_interval*list_x+self.q_portx,self.q_interval*list_y+self.q_porty])
                        else:
                            if list_x%5 == 2:
                                chip_cell.add_ref(coupler_hl).move([self.q_interval*list_x+self.q_portx,self.q_interval*list_y+self.q_porty])
                            else:
                                chip_cell.add_ref(coupler_ht).move([self.q_interval*list_x+self.q_portx,self.q_interval*list_y+self.q_porty])
                            if list_x%5 == 3:
                                chip_cell.add_ref(coupler_v).move([self.q_interval*list_x+self.q_portx,self.q_interval*list_y+self.q_porty])
                else:
                    if list_y%2 == 0:
                        if list_x < self.q_col-1:
                            if list_x%5 == 4:
                                chip_cell.add_ref(coupler_hl).move([self.q_interval*list_x+self.q_portx,self.q_interval*list_y+self.q_porty])
                            else:
                                chip_cell.add_ref(coupler_ht).move([self.q_interval*list_x+self.q_portx,self.q_interval*list_y+self.q_porty])
                        if list_x%5 == 0:
                            chip_cell.add_ref(coupler_v).move([self.q_interval*list_x+self.q_portx,self.q_interval*list_y+self.q_porty])
                    else:
                        if list_x < self.q_col-1:
                            if list_x%5 == 2 and list_x < self.q_col-2:
                                chip_cell.add_ref(coupler_hr).move([self.q_interval*list_x+self.q_portx,self.q_interval*list_y+self.q_porty])
                            if list_x%5 == 4:
                                chip_cell.add_ref(coupler_ht).move([self.q_interval*list_x+self.q_portx,self.q_interval*list_y+self.q_porty])
                            elif list_x%5 != 3:
                                chip_cell.add_ref(coupler_hb).move([self.q_interval*list_x+self.q_portx,self.q_interval*list_y+self.q_porty])
                        if list_x%5 == 3:
                            chip_cell.add_ref(coupler_v).move([self.q_interval*list_x+self.q_portx,self.q_interval*list_y+self.q_porty])
        return chip_cell
    
    def simulate_cell(self,box_margin = 0,coupler_index=0,read_cavity:list[ReadCavityHex]|None=None) -> Cell:
        '''
            include coupler
        '''
        [shape_qubit,jj_axy] = self.generate_shape('qubit')
        [shape_htc,shape_hbc,shape_hlc,shape_hrc,shape_vc] = self.generate_shape('coupler')
        if coupler_index == 0:
            shape_all = shape_union([shape_qubit,shape_htc,move(shape_qubit,xoff=self.q_interval)])
        elif coupler_index == 1:
            shape_all = shape_union([shape_qubit,shape_hbc,move(shape_qubit,xoff=self.q_interval)])
        elif coupler_index == 2:
            shape_all = shape_union([shape_qubit,shape_hlc,move(shape_qubit,xoff=2*self.q_interval)])
        elif coupler_index == 3:
            shape_all = shape_union([shape_qubit,shape_hrc,move(shape_qubit,xoff=2*self.q_interval)])
        else:
            shape_all = shape_union([shape_qubit,shape_vc,move(shape_qubit,yoff=-self.q_interval)])

        c = Cell()
        if box_margin > 0:
            embeded_qubit = embeded(shape_all,box_margin,box_margin,box_margin,box_margin)
        else:
            embeded_qubit = embeded(shape_all,100,100,100,100)

        c.add_polygon(embeded_qubit,'METT')

        if isinstance(read_cavity,list):
            [shape_cavity_1,_] = read_cavity[0].generate_shape()
            [shape_cavity_2,_] = read_cavity[0].generate_shape()
            embeded_region = embeded_qubit.bounds

            if coupler_index == 0:
                read_cavity_all = shape_union([shape_cavity_1,move(shape_cavity_2,xoff=self.q_interval)])
            elif coupler_index == 1:
                read_cavity_all = shape_union([shape_cavity_1,move(shape_cavity_2,xoff=self.q_interval)])
            elif coupler_index == 2:
                read_cavity_all = shape_union([shape_cavity_1,move(shape_cavity_2,xoff=2*self.q_interval)])
            elif coupler_index == 3:
                read_cavity_all = shape_union([shape_cavity_1,move(shape_cavity_2,xoff=2*self.q_interval)])
            else:
                read_cavity_all = shape_union([shape_cavity_1,move(shape_cavity_2,yoff=-self.q_interval)])

            clip_cavity = clip_by_rect(read_cavity_all,embeded_region[0],embeded_region[1],embeded_region[2],embeded_region[3])
            embeded_cavity = rectangle(embeded_region[0],embeded_region[1],embeded_region[2],embeded_region[3]) - clip_cavity
            c.add_polygon(embeded_cavity,'METB')

        return c
    
    def simulate_qubit(self,box_margin = 0,read_cavity:ReadCavityHex|None=None) -> Cell:
        '''
            exclude coupler
        '''
        [shape_qubit,jj_axy] = self.generate_shape('qubit')
        open_pad = via(self.coupler_s+self.coupler_w*2,self.coupler_s+self.coupler_w*2,
                       xoff=self.q_pad_width/2+self.q_pad_ground_l,yoff=self.q_coupler_cdy,style='mitre')
        shape_qubit = shape_union([shape_qubit,open_pad])
        c = Cell()
        if box_margin > 0:
            embeded_qubit = embeded(shape_qubit,box_margin,box_margin,box_margin,box_margin)
            
        else:
            embeded_qubit = embeded(shape_qubit,100,100,100,100)
        c.add_polygon(embeded_qubit,'METT')

        if isinstance(read_cavity,ReadCavityHex):
            [shape_cavity,_] = read_cavity.generate_shape()
            embeded_region = embeded_qubit.bounds
            clip_cavity = clip_by_rect(shape_cavity,embeded_region[0],embeded_region[1],embeded_region[2],embeded_region[3])
            embeded_cavity = rectangle(embeded_region[0],embeded_region[1],embeded_region[2],embeded_region[3]) - clip_cavity
            c.add_polygon(embeded_cavity,'METB')
        
        return c
    
@dataclass
class RFSquid(QLibrary):
    cpw_w:float = 3
    cpw_s:float = 3
    cpw_control_end_h:float = 66
    pad_w:float = 36
    pad_h:float = 50
    pad_side_dx:float = 60
    loop_box_w:float = 166
    loop_box_h:float = 166
    loop_top_shift_x:float = 20
    loop_top_start_h:float = 50
    loop_top_end_h:float = 40
    loop_bot_shift_x:float = 20
    loop_bot_start_h:float = 20
    loop_bot_end_h:float = 5
    loop_half_num:int = 4
    tsv_w:float = 10
    tsv_dw:float = 15
    tsv_tin_w:float = 40
    tsv_tin_h:float = 25
    tsv_gnd_dx:float = 42
    tsv_gnd_dy:float = 30
    tsv_gnd_a:float = 90
    jj_w:float = 60
    jj_h:float = 46
    jj_line_t_s:float = 3
    jj_line_t_dy:float = 18
    jj_line_t_x1:float = -25
    jj_line_t_x2:float = 30
    jj_line_b_s:float = 3
    jj_line_b_dy:float = -18
    jj_line_b_x1:float = -25
    jj_line_b_x2:float = 30
    squid_x:float = 80
    squid_y:float = -80
    squid_w:float = 46
    squid_h:float = 46
    simu_box:float = 20

    def generate_shape(self) -> list[Polygon]:
        [t1,t2] = trace.inductor_loop_dual(self.loop_box_w,self.loop_box_h,self.cpw_w+self.cpw_s,self.loop_top_shift_x,
                                           self.loop_top_start_h,self.loop_top_end_h,self.loop_bot_shift_x,self.loop_bot_start_h,
                                           self.loop_bot_end_h,self.loop_half_num)

        t2tojj = [(self.jj_w/2,t2[0][1]),t2[0]]

        jj_area = jj_nb_area(self.jj_w,self.jj_h,self.jj_line_t_s,self.jj_line_t_dy,
                             self.jj_line_t_x1,self.jj_line_t_x2,self.jj_line_b_s,self.jj_line_b_dy,
                             self.jj_line_b_x1,self.jj_line_b_x2,yoff=t2[0][1]-self.jj_line_t_dy)

        cpw_top = cpw(self.cpw_w,self.cpw_s,t1,style='mitre')
        cpw_bot = cpw(self.cpw_w,self.cpw_s,t2tojj+t2,style='mitre')

        if self.loop_half_num%2 == 0:
            pad_top = pad_square(self.pad_w,self.pad_h,self.cpw_w,self.cpw_s,90,yoff=t1[-1][1]-self.pad_w/2)
            pad_bot = pad_square(self.pad_w,self.pad_h,self.cpw_w,self.cpw_s,-90,yoff=t2[-1][1]+self.pad_w/2)
            pad_top_fc = pad_square(self.pad_h,self.pad_w,self.cpw_w,self.cpw_s,yoff=t1[-1][1]-self.pad_w/2)
            tsv_axy = [(0,0,t1[-1][1]-self.pad_w/2),(0,0,t2[-1][1]+self.pad_w/2),(90,self.pad_side_dx,t2[0][1]-(self.jj_line_t_dy-self.jj_line_b_dy)),
                       (self.tsv_gnd_a,self.tsv_gnd_dx,self.tsv_gnd_dy+t1[-1][1]-self.pad_w/2),
                       (self.tsv_gnd_a,-self.tsv_gnd_dx,self.tsv_gnd_dy+t1[-1][1]-self.pad_w/2),
                       (self.tsv_gnd_a,self.tsv_gnd_dx,-self.tsv_gnd_dy+t1[-1][1]-self.pad_w/2),
                       (self.tsv_gnd_a,-self.tsv_gnd_dx,-self.tsv_gnd_dy+t1[-1][1]-self.pad_w/2)]
        else:
            pad_top = pad_square(self.pad_w,self.pad_h,self.cpw_w,self.cpw_s,-90,yoff=t1[-1][1]+self.pad_w/2)
            pad_bot = pad_square(self.pad_w,self.pad_h,self.cpw_w,self.cpw_s,90,yoff=t2[-1][1]-self.pad_w/2)
            pad_top_fc = pad_square(self.pad_h,self.pad_w,self.cpw_w,self.cpw_s,yoff=t1[-1][1]+self.pad_w/2)
            tsv_axy = [(0,0,t1[-1][1]+self.pad_w/2),(0,0,t2[-1][1]-self.pad_w/2),(90,self.pad_side_dx,t2[0][1]-(self.jj_line_t_dy-self.jj_line_b_dy)),
                       (self.tsv_gnd_a,self.tsv_gnd_dx,self.tsv_gnd_dy+t1[-1][1]+self.pad_w/2),
                       (self.tsv_gnd_a,-self.tsv_gnd_dx,self.tsv_gnd_dy+t1[-1][1]+self.pad_w/2),
                       (self.tsv_gnd_a,self.tsv_gnd_dx,-self.tsv_gnd_dy+t1[-1][1]+self.pad_w/2),
                       (self.tsv_gnd_a,-self.tsv_gnd_dx,-self.tsv_gnd_dy+t1[-1][1]+self.pad_w/2)]

        pad_side = pad_square(self.pad_w,self.pad_h,self.cpw_w,self.cpw_s,180,xoff=self.pad_side_dx,yoff=t2[0][1]-(self.jj_line_t_dy-self.jj_line_b_dy))
        cpw_side = cpw(self.cpw_w,self.cpw_s,[(self.jj_w/2,t2[0][1]-(self.jj_line_t_dy-self.jj_line_b_dy)),(self.pad_side_dx-self.pad_w/2,t2[0][1]-(self.jj_line_t_dy-self.jj_line_b_dy))],style='mitre')

        squid_area = pad_square_empty(self.squid_w,self.squid_h,self.cpw_w,self.cpw_s,self.cpw_w,angle=180,xoff=self.squid_x,yoff=self.squid_y)

        t_bot_fc = [(0,t2[-1][1]),(0,self.squid_y+(self.cpw_w+self.cpw_s)/2),(self.squid_x-self.squid_w/2,self.squid_y+(self.cpw_w+self.cpw_s)/2)]

        t_bot_side = [(self.squid_x-self.squid_w/2,self.squid_y-(self.cpw_w+self.cpw_s)/2),
                      (0,self.squid_y-(self.cpw_w+self.cpw_s)/2),(0,t2[0][1]-(self.jj_line_t_dy-self.jj_line_b_dy)),
                      (self.pad_side_dx-self.pad_w/2,t2[0][1]-(self.jj_line_t_dy-self.jj_line_b_dy))]

        cpw_bot_fc = cpw(self.cpw_w,self.cpw_s,t_bot_fc,style='mitre')

        cpw_bot_side = cpw(self.cpw_w,self.cpw_s,t_bot_side,style='mitre')

        t_top_fc = [(self.pad_h/2,t1[-1][1]-self.pad_w/2),(self.squid_x-self.squid_w/2+self.cpw_w+self.cpw_s/2,t1[-1][1]-self.pad_w/2),
                    (self.squid_x-self.squid_w/2+self.cpw_w+self.cpw_s/2,self.squid_y+self.squid_w/2+self.cpw_s/2),
                    (self.squid_x+self.squid_w/2-self.cpw_w-self.cpw_s/2,self.squid_y+self.squid_w/2+self.cpw_s/2),
                    (self.squid_x+self.squid_w/2-self.cpw_w-self.cpw_s/2,self.squid_y+self.squid_w/2+self.cpw_s/2+self.cpw_control_end_h)]

        cpw_top_fc = cpw(self.cpw_w,self.cpw_s,t_top_fc,style='mitre')

        shape_jj = shape_union([cpw_top,cpw_bot,cpw_side,pad_top,pad_bot,pad_side,jj_area])
        shape_squid = shape_union([squid_area,pad_top_fc,pad_bot,pad_side,cpw_bot_fc,cpw_bot_side,cpw_top_fc])

        return [shape_jj,shape_squid,tsv_axy]

    def generate_mask(self):
        pass
    
    def generate_cell(self):
        [shape_jj,shape_squid,tsv_axy] = self.generate_shape()

        c = Cell()
        c.add_polygon(shape_jj,layer='MET0',vertex_num=20)

        c.add_polygon(shape_squid,layer='METB')

        my_tsv = tsv(self.tsv_w,self.tsv_w,dw=self.tsv_dw,tin_w=self.tsv_tin_w,tin_h=self.tsv_tin_h)
        for a,x,y in tsv_axy:
            c.add_ref(my_tsv).rotate(a).move([x,y])

        return c

    def simulate_cell(self):
        [shape_jj,shape_squid,tsv_axy] = self.generate_shape()

        [embed_jj,embed_squid] = embeded([shape_jj,shape_squid],dminx=self.simu_box,dmaxx=self.simu_box,dminy=self.simu_box)
        c = Cell()
        c.add_polygon(embed_jj,layer='MET0',vertex_num=20)
        c.add_polygon(embed_squid,layer='METB',vertex_num=20)

        my_tsv = tsv(self.tsv_w,self.tsv_w,dw=self.tsv_dw)
        for a,x,y in tsv_axy:
            c.add_ref(my_tsv).rotate(a).move([x,y])

        return c
    
__all__ = ['ReadCavityHex',
           'ReadFilterHex',
           'JJManhattan',
           'QubitCouplerArrayHex',
           'RFSquid']