# GDSQL 0.3.0
GDSQL（GDSII Quantum Layout）是基于gdsfactory[v7]的封装，相比之前的sqc-painter，绘制版图的速度提升超过100x，且无须依赖KLayout。

针对超导量子芯片版图绘制，提供了常用的图形库，包含CPW控制线、TSV、量子比特、短路谐振器、开路谐振器、RF-SQUID，目标是支持千比特版图的绘制。

通过图形库，可以快速生成仿真用的gds文件，用于SONNET、ANSYS、InductEX仿真，已开发SONNET、ANSYS部分自动化仿真功能。

## 安装说明

需要安装`gdsfactory`，该包是画图功能最基础的依赖，推荐在Anaconda环境下安装，python=3.11。
> [注意] 目前`gdsfactory`官方更新到v8，但发现其PDK相关内容与`gdsql`不兼容，而且不支持`shapely`图形作为`Cell`的输入，需要替换成klayout格式，即shape模块需要全部重写。因此较长一段时间内仍用v7版本。

![structure](docs/images/dependency_structure.png)

根据需要的功能，可选择性地安装以下的包：
- `pandas`, `openpyxl`： 网表导出功能。
- `plotly`, `nbformat`： 在jupyter notebook内预览布线路径功能。
- `klive`：可快捷传输版图到klayout内查看，需要在klayout内安装`klive[v0.3.2]`插件，在`Tools -> Manage Packages`搜索插件名字进行安装，该插件只支持v0.28.17及以上版本的klayout。

```bash
conda create -n gdsql-env python=3.11
activate gdsql-env
pip install gdsfactory==7.27.1
pip install pandas openpyxl plotly nbformat
```

## 使用说明

先通过`gq.Cell`建立画图单元，然后添加`gq.cpw`，`gq.pad`，`gq.via`等图形，并指定图层名称或者图层编号。

图层名称和图层编号的映射关系见PKD说明。
在任何一个需要指定图层的函数里，图层名称和图层编号可以混用。
比如下面2种写法的效果相同：
```python
c.add_polygon(gq.via(40,40),(11,0))
c.add_polygon(gq.via(40,40),"ViaB")
```

>[注意] GDSQL 仍处于试验阶段，预计会在不通知的情况下更改 API（尽管我们会尽量减少更改！）。[详细说明请见此处](https://github.com/SQCEDA/gdsql/tree/master/docs)

### 基础方法
通过手动拼接画图，cpw图形只需要设定途径点和转弯半径，就能自动转弯

```python
import gdsql as gq
c = gq.Cell()
c.add_polygon(gq.cpw(2,4,[(0,0),(200,0),(0,200),(200,200)],radius=50,startcut=50,endcut=50),"METB")
c.add_polygon(gq.pad(30,50,2,4,50),"METB")
c.add_polygon(gq.via(40,40),"ViaB")
c.add_polygon(gq.pad(30,50,2,4,50,angle=180,xoff=200,yoff=200),"METB")
c.add_polygon(gq.via(28,10,dh=20,angle=180,xoff=200,yoff=200),"ViaB")
c.write_gds("demo.gds")  # write it to a GDS file. You can open it in klayout.
c.show()  # show it in klayout
c.plot()  # plot it in jupyter notebook
```
### 高级方法
通过已配置好的画图参数`gq.RouteConfig`画图

```python
import gdsql as gq
route_config = gq.RouteConfig(cpw_ab_existence=True,cpw_ab_simu=True)
line = [(0,0),(200,0),(0,200),(200,200)]
c = route_config.generate_cell(line)
c.plot()
```
### 导出方式

导出加工用版图时直接用`write_gds`，可以保留cell结构，减小文件体积。

如果想要用sonnet或者inductEX进行仿真，建议用`write_flatten_gds`。

```python
c.write_flatten_gds('flattend demo.gds') # export flattened cell
c.write_gds('demo.gds') # export unflattened cell
```

![生成图形](docs/images/demo_crossover.png)

### 默认PDK

内置默认PDK，包含图层名称和图层编号，图层颜色的映射信息。

```python
LAYER_VIEWS = gq.PDK.layer_views
c = LAYER_VIEWS.preview_layerset()
c.plot()
```

![图层颜色示意](docs/images/layerview.png)