# Haso Payment Extension: Data Aggregation Redirect Flow

This app provides order related data to the Haso Payment extension when plugged-in to project zero.

## Installation

Add the package to requirements.txt file and install it via pip:

    pip install haso-payment

## Configuration

### 1. Adding App
Include the following lines in your `omnife_base.settings` file:

```python
INSTALLED_APPS.append('haso_payment')

PZ_SERVICE_CLASS = "omnife.core.service.Service"

HASO_EXTENSION_CONF = {
    "default": { # Payment Option Slug / Use default for one payment option
        "extension_url": "https://your-haso-pe-extension.url",
        "hash_key": "your-haso-pe-extension-hash-key"
    }
}
```

### Explanation of Settings

| Setting Name                                              | Description                                              |
|-----------------------------------------------------------|----------------------------------------------------------|
| `HASO_EXTENSION_CONF[payment_option_slug][extension_url]` | The URL where the Payment extension is hosted. |
| `HASO_EXTENSION_CONF[payment_option_slug][hash_key]`      | A secret key used for security.                          |

### 2. Add URL Pattern
Add url pattern to `omnife_base.urls` like below:
```python
urlpatterns = [
    # ...
    path('payment-gateway/haso/', include('haso_payment.urls')),
]
```

## Running Tests

    python -m unittest discover

## Python Version Compatibility

This package is compatible with the following Python versions:
  - Python 3.9
  - Python 3.13
