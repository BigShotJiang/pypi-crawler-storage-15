class PaymentFlowException(Exception):
    pass
