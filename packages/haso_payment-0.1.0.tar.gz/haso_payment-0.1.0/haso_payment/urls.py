from django.urls import path

from haso_payment.views import HasoPaymentView


urlpatterns = [
    path("", HasoPaymentView.as_view(), name="haso-payment"),
]
