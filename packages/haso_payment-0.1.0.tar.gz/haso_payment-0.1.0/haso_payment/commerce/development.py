import logging
from json import JSONDecodeError

from rest_framework import status

from django.http import Http404

logger = logging.getLogger(__name__)


class Service:
    def get(self, *args, **kwargs):
        import requests
        url = "http://127.0.0.1:8080/orders/checkout/?page=OrderNotePage"
        payload = "payment_option=1"
        headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; '
                          'rv:145.0) Gecko/20100101 Firefox/145.0',
            'Accept': '*/*',
            'Accept-Language': 'tr-TR,tr;q=0.8,en-US;q=0.5,en;q=0.3',
            'Accept-Encoding': 'gzip, deflate, br, zstd',
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'X-CSRFToken': 'wkBvkCf9ZhT7lLABe9rC1LhlCCOPDFe87Su'
                           'P7C7PEKFSoDTWq8xn7fnO5Uuo5tVQ',
            'X-Requested-With': 'XMLHttpRequest',
            'Origin': 'http://127.0.0.1:8080',
            'Connection': 'keep-alive',
            'Referer': 'http://127.0.0.1:8080/orders/checkout/',
            'Cookie': 'csrftoken=wkBvkCf9ZhT7lLABe9rC1LhlCCOPDFe87SuP7C7PEKF'
                      'SoDTWq8xn7fnO5Uuo5tVQ; ajs_user_id=%221%22; '
                      'ajs_group_id=null; ajs_anonymous_id=%226209b60c-'
                      'd483-4720-8711-5664b22d4c31%22; _ga_699NE13B0K=GS1.'
                      '1.1742571140.2.0.1742571140.0.0.0; _ga=GA1.1.152892'
                      '07.1742565415; sessionid=g1khv2qs2s1bqgmzmd49jvz8fg8ji9'
                      'na; csrftoken=4sJgF3mJW13zGgpPr5RjreZC5CsR3JkW; sessi'
                      'onid=c7ubsczbns438pk3itz8lqg8feqe9x1g',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'same-origin',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache'
        }
        response = requests.request(
            "GET", url, headers=headers, data=payload
        )
        return response

    def normalize_response(self, response):
        from django.http.response import HttpResponseRedirect
        from rest_framework.response import Response

        if response.status_code == status.HTTP_404_NOT_FOUND:
            raise Http404()

        if response.is_redirect:
            url = response.headers["location"]
            if url.rfind("format") > 0:
                url = url[:url.rfind("format")]
            return HttpResponseRedirect(url, status=response.status_code)

        acceptable_statuses = [status.HTTP_429_TOO_MANY_REQUESTS]

        if (
                response.status_code > status.HTTP_406_NOT_ACCEPTABLE
                and response.status_code not in acceptable_statuses
        ):
            response.raise_for_status()

        if response.status_code == status.HTTP_204_NO_CONTENT:
            return Response(status=status.HTTP_204_NO_CONTENT)

        data = self.normalize(response)

        return Response(data=data, status=response.status_code)

    @staticmethod
    def normalize(response):
        data = {}
        if response.content:
            try:
                data = response.json()
            except JSONDecodeError:
                data = {"content": response.content}
        return data
