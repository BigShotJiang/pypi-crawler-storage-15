from django import forms


class HasoPaymentForm(forms.Form):
    data = forms.CharField()
