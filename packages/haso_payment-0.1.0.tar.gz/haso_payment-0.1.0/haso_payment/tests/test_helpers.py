from django.test import SimpleTestCase
from haso_payment.helpers import generate_salt, generate_hash

from mock.mock import patch


class TestGenerateSalt(SimpleTestCase):
    def test_default_length(self):
        salt = generate_salt()
        assert len(salt) == 10

    def test_custom_length(self):
        salt = generate_salt(length=8)
        assert len(salt) == 8

    def test_deterministic_length(self):
        salt1 = generate_salt(length=12)
        salt2 = generate_salt(length=12)
        assert len(salt1) == 12
        assert len(salt2) == 12
        assert salt1 != salt2

    def test_zero_length(self):
        salt = generate_salt(length=0)
        assert len(salt) == 10

    def test_negative_length(self):
        salt = generate_salt(length=-5)
        assert len(salt) == 10


class TestGenerateHash(SimpleTestCase):
    def test_generate_hash(self):
        salt = "0x000000"
        session_id = "test_session_id"
        hash_key = "your-extension-hash-key"
        expected_hash = (
            "4fcc67a18bb0fffd1d2b45e1f2797658432fa3bf94e188615bc26f2adcd96ca9"
            "665111fdbd72ee1a6faf9a92614ae86b8006b7720f61e9707f40ba579adffaec"
        )
        generated_hash = generate_hash(
            salt=salt, session_id=session_id, hash_key=hash_key
        )

        assert generated_hash == expected_hash

    @patch("secrets.token_hex")
    def test_generate_salt(self, mock_token_hex):
        generate_salt()
        mock_token_hex.assert_called_once()
