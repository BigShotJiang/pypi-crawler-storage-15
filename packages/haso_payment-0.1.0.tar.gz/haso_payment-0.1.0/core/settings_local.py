from core.settings import INSTALLED_APPS

INSTALLED_APPS.append('haso_payment')

PZ_SERVICE_CLASS = "haso_payment.commerce.development.Service"

HASO_EXTENSION_URL = "https://your-extension.url"
HASO_HASH_SECRET_KEY = "your-extension-hash-key"

HASO_EXTENSION_CONF = {
    "default": {
        "extension_url": HASO_EXTENSION_URL,
        "hash_key": HASO_HASH_SECRET_KEY,
    }
}
HASO_EXTENSION_CONF = {
    "default": {
        "extension_url": "https://your-extension.url",
        "hash_key": "your-extension-hash-key",
    }
}
