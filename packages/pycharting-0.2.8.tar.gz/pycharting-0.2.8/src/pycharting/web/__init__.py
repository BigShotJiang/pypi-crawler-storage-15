"""Web interface for PyCharting."""
