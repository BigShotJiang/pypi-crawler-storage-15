from usdm_excel.base_manager import BaseManager


class CTVersionManager(BaseManager):
    pass
