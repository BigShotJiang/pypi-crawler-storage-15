class SoAColumnRows:
    NAME_ROW = 0
    DESCRIPTION_ROW = 1
    LABEL_ROW = 2
    TYPE_ROW = 3
    DEFAULT_ROW = 4
    CONDITIONS_ROW = 5
    EPOCH_ROW = 6
    ENCOUNTER_ROW = 7
    TIMELINE_ROW = 8  # Optional row, pushes other rows down by one.

    HEADER_ROW = 8
    FIRST_ACTIVITY_ROW = 9

    ACTIVITY_COL = 0
    CHILD_ACTIVITY_COL = 1
    BC_COL = 2
    FIRST_VISIT_COL = 3
