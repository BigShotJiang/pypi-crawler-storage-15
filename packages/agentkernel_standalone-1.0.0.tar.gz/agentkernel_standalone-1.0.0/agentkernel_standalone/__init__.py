"""AgentKernel Standalone - A standalone multi-agent system framework."""

__version__ = "1.0.0"

