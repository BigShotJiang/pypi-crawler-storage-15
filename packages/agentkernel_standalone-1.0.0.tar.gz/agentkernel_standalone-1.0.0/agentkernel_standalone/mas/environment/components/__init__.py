from .relation import RelationComponent
from .space import SpaceComponent

__all__ = [
    "RelationComponent",
    "SpaceComponent",
]
