"""
CodeGraphMCPServer - Test Suite
===============================

テストパッケージ。
pytest でテストを実行します。
"""
