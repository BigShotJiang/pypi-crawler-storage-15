# Test Fixtures Directory
# =======================
#
# このディレクトリにはテスト用のサンプルファイルを配置します。
#
# 構造:
# - python/     ... Pythonサンプルコード
# - typescript/ ... TypeScriptサンプルコード  
# - rust/       ... Rustサンプルコード
# - mixed/      ... 複数言語を含むプロジェクト
