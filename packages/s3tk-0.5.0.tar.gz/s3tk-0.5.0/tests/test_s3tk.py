class TestS3tk(object):
    def test_works(self):
        assert True
