This directory is for language support plugins.

Currently supports:
* Biblebooks abbreviations

## Biblebooks abbreviations

Filename should be [lang].biblebooks (eg ml.biblebooks)

It should contain lines like:
```commandline
"1": ("ഉൽപ", "ഉൽപത്തി"),
"ഉല്.": "1", 
```

See BibleBooks.py for more examples
