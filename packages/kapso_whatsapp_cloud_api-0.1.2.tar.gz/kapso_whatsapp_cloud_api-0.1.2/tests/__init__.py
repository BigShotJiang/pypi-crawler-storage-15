"""Test suite for kapso-whatsapp SDK."""
