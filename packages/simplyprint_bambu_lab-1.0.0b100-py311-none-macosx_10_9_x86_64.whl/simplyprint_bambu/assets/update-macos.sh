#!/bin/sh

bash -c "$(curl -fsSL https://download.simplyprint.io/bambu/install-macos.sh)"
