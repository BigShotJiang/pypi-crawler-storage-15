systemctl restart simplyprint-bambu-lab.service
