
class DoCleanException(Exception):
    """Base exception class for DoClean-related errors."""
    pass