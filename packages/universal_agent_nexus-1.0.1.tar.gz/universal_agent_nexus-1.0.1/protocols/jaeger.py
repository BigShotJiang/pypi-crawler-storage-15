"""Jaeger tracing stub."""

def configure(exporter: dict) -> None:
    raise NotImplementedError("configure is not implemented yet")
