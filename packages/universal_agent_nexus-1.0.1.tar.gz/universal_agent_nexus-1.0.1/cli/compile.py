"""Compile manifest to adapter output."""

def main():
    raise NotImplementedError("compile CLI not implemented yet")


if __name__ == "__main__":
    main()
