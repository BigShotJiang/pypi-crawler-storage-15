"""Validate adapter compatibility."""

def main():
    raise NotImplementedError("validate CLI not implemented yet")


if __name__ == "__main__":
    main()
