"""Operator controller for UAA CRDs."""

def reconcile(resource: dict) -> None:
    raise NotImplementedError("reconcile is not implemented yet")
