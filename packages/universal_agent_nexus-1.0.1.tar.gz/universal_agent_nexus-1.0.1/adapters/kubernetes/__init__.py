"""Kubernetes operator adapter."""
