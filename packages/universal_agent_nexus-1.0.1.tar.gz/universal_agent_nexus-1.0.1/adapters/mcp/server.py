"""Expose UAA graph as an MCP server."""

def start_server(manifest: dict) -> None:
    raise NotImplementedError("start_server is not implemented yet")
