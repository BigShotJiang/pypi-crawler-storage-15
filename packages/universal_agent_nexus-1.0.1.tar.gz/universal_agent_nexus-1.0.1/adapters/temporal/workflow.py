"""Compile UAA graphs into Temporal workflows."""

def build_workflow(manifest: dict):
    raise NotImplementedError("build_workflow is not implemented yet")
