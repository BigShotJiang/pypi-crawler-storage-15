"""Checkpoint conversion helpers."""

def to_task(checkpoint: dict) -> dict:
    raise NotImplementedError("to_task is not implemented yet")
