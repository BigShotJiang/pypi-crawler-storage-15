"""Conversation state mapping."""

def map_thread(state: dict) -> dict:
    raise NotImplementedError("map_thread is not implemented yet")
