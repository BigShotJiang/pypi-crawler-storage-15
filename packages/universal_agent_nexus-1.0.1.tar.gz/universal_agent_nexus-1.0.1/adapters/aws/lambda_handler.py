"""Lambda entry point for AWS adapter."""

def handler(event, context):
    raise NotImplementedError("handler is not implemented yet")
