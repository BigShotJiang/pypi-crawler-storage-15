def test_latency():
    assert True
