def test_aws_e2e():
    assert True
