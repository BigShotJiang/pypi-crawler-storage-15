# Note that this file is generated during install.
__version__ = '0.9.0'
