"""
Properties that are loaded into the aiohttp request context.
"""

HEA_WSTL_BUILDER = 'HEA_wstl_document'
