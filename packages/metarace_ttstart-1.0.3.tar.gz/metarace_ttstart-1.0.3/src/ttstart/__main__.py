# SPDX-License-Identifier: MIT
import sys
from . import main

sys.exit(main())
