"""Async HTTP client for Atlas Command."""

from __future__ import annotations

from datetime import datetime
from typing import Any, BinaryIO, Mapping, Optional, Union

import httpx

from .components import (
    EntityComponents,
    TaskComponents,
    components_to_dict,
)


class AtlasCommandHttpClient:
    """Minimal async HTTP client for Atlas Command's REST API."""

    def __init__(
        self,
        base_url: str,
        *,
        token: Optional[str] = None,
        timeout: float = 10.0,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._token = token
        self._client: httpx.AsyncClient | None = httpx.AsyncClient(
            base_url=self._base_url,
            timeout=timeout,
            transport=transport,
        )

    async def __aenter__(self) -> "AtlasCommandHttpClient":
        return self

    async def __aexit__(self, *exc_info: object) -> None:
        await self.aclose()

    async def aclose(self) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    @property
    def _http(self) -> httpx.AsyncClient:
        if self._client is None:
            raise RuntimeError("Client is closed")
        return self._client

    def _headers(self) -> dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if self._token:
            headers["Authorization"] = f"Bearer {self._token}"
        return headers

    async def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        response = await self._http.request(method, path, headers=self._headers(), **kwargs)
        response.raise_for_status()
        if response.content:
            return response.json()
        return None

    def _multipart_headers(self) -> dict[str, str]:
        headers: dict[str, str] = {}
        if self._token:
            headers["Authorization"] = f"Bearer {self._token}"
        return headers

    async def _multipart_request(
        self,
        path: str,
        *,
        files: dict[str, Any],
        data: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        response = await self._http.post(
            path, headers=self._multipart_headers(), files=files, data=data
        )
        response.raise_for_status()
        if response.content:
            return response.json()
        return {}

    # Entities -----------------------------------------------------------------

    async def list_entities(self, *, limit: int = 100, offset: int = 0) -> list[dict[str, Any]]:
        return await self._request("GET", "/entities", params={"limit": limit, "offset": offset})

    async def get_entity(self, entity_id: str) -> dict[str, Any]:
        return await self._request("GET", f"/entities/{entity_id}")

    async def get_entity_by_alias(self, alias: str) -> dict[str, Any]:
        return await self._request("GET", f"/entities/alias/{alias}")

    async def create_entity(
        self,
        *,
        entity_id: str,
        entity_type: str,
        alias: str,
        subtype: str,
        components: Optional[Union[EntityComponents, Mapping[str, Any]]] = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "entity_id": entity_id,
            "entity_type": entity_type,
            "alias": alias,
            "subtype": subtype,
            "components": components_to_dict(components),
        }
        return await self._request("POST", "/entities", json=payload)

    async def update_entity(
        self,
        entity_id: str,
        *,
        components: Optional[Union[EntityComponents, Mapping[str, Any]]] = None,
        subtype: Optional[str] = None,
    ) -> dict[str, Any]:
        if components is None and subtype is None:
            raise ValueError("update_entity requires at least one of: components, subtype")
        payload: dict[str, Any] = {}
        if components is not None:
            payload["components"] = components_to_dict(components)
        if subtype is not None:
            payload["subtype"] = subtype
        return await self._request("PATCH", f"/entities/{entity_id}", json=payload)

    async def delete_entity(self, entity_id: str) -> None:
        await self._request("DELETE", f"/entities/{entity_id}")

    async def update_entity_telemetry(
        self,
        entity_id: str,
        *,
        latitude: Optional[float] = None,
        longitude: Optional[float] = None,
        altitude_m: Optional[float] = None,
        speed_m_s: Optional[float] = None,
        heading_deg: Optional[float] = None,
    ) -> dict[str, Any]:
        payload = {
            "latitude": latitude,
            "longitude": longitude,
            "altitude_m": altitude_m,
            "speed_m_s": speed_m_s,
            "heading_deg": heading_deg,
        }
        return await self._request("PATCH", f"/entities/{entity_id}/telemetry", json=payload)

    # Tasks --------------------------------------------------------------------

    async def list_tasks(
        self, *, status: Optional[str] = None, limit: int = 25
    ) -> list[dict[str, Any]]:
        params: dict[str, Any] = {"limit": limit}
        if status:
            params["status"] = status
        return await self._request("GET", "/tasks", params=params)

    async def get_task(self, task_id: str) -> dict[str, Any]:
        return await self._request("GET", f"/tasks/{task_id}")

    async def create_task(
        self,
        *,
        task_id: str,
        status: str = "pending",
        entity_id: Optional[str] = None,
        components: Optional[Union[TaskComponents, Mapping[str, Any]]] = None,
        extra: Optional[Mapping[str, Any]] = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "task_id": task_id,
            "status": status,
        }
        if entity_id is not None:
            payload["entity_id"] = entity_id
        if components is not None:
            payload["components"] = components_to_dict(components)
        if extra is not None:
            payload["extra"] = extra
        return await self._request("POST", "/tasks", json=payload)

    async def update_task(
        self,
        task_id: str,
        *,
        status: Optional[str] = None,
        entity_id: Optional[str] = None,
        components: Optional[Union[TaskComponents, Mapping[str, Any]]] = None,
        extra: Optional[Mapping[str, Any]] = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {}
        if status is not None:
            payload["status"] = status
        if entity_id is not None:
            payload["entity_id"] = entity_id
        if components is not None:
            payload["components"] = components_to_dict(components)
        if extra is not None:
            payload["extra"] = extra
        return await self._request("PATCH", f"/tasks/{task_id}", json=payload)

    async def delete_task(self, task_id: str) -> None:
        await self._request("DELETE", f"/tasks/{task_id}")

    async def get_tasks_by_entity(
        self, entity_id: str, *, status: Optional[str] = None, limit: int = 25
    ) -> list[dict]:
        params: dict[str, Any] = {"limit": limit}
        if status:
            params["status"] = status
        return await self._request("GET", f"/entities/{entity_id}/tasks", params=params)

    async def start_task(self, task_id: str) -> dict[str, Any]:
        return await self._request("POST", f"/tasks/{task_id}/start", json={})

    async def complete_task(self, task_id: str) -> dict[str, Any]:
        return await self._request("POST", f"/tasks/{task_id}/complete", json={})

    async def fail_task(
        self,
        task_id: str,
        *,
        error_message: Optional[str] = None,
        error_details: Optional[Mapping[str, Any]] = None,
    ) -> dict[str, Any]:
        return await self._request(
            "POST",
            f"/tasks/{task_id}/fail",
            json={"error_message": error_message, "error_details": error_details},
        )

    # Objects ------------------------------------------------------------------

    async def list_objects(
        self,
        *,
        content_type: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[dict[str, Any]]:
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if content_type:
            params["content_type"] = content_type
        return await self._request("GET", "/objects", params=params)

    async def get_object(self, object_id: str) -> dict[str, Any]:
        return await self._request("GET", f"/objects/{object_id}")

    async def create_object(
        self,
        file: bytes | BinaryIO,
        *,
        object_id: str,
        usage_hint: Optional[str] = None,
        referenced_by: Optional[list[dict[str, Any]]] = None,
    ) -> dict[str, Any]:
        filename = (
            getattr(file, "name", "upload.bin")
            if not isinstance(file, (bytes, bytearray))
            else "upload.bin"
        )
        files = {"file": (filename, file)}
        data = {"object_id": object_id}
        if usage_hint:
            data["usage_hint"] = usage_hint

        stored = await self._multipart_request("/objects/upload", files=files, data=data)

        stored_object_id = stored.get("object_id")
        if referenced_by:
            if not stored_object_id:
                raise RuntimeError(
                    "AtlasCommandHttpClient.create_object expected the upload response to include "
                    "an object_id before attaching references."
                )
            for reference in referenced_by:
                await self.add_object_reference(
                    stored_object_id,
                    entity_id=reference.get("entity_id"),
                    task_id=reference.get("task_id"),
                )

        return stored

    async def update_object(
        self,
        object_id: str,
        *,
        usage_hints: Optional[list[str]] = None,
        referenced_by: Optional[list[dict[str, Any]]] = None,
    ) -> dict[str, Any]:
        payload = {"usage_hints": usage_hints, "referenced_by": referenced_by}
        return await self._request("PATCH", f"/objects/{object_id}", json=payload)

    async def delete_object(self, object_id: str) -> None:
        await self._request("DELETE", f"/objects/{object_id}")

    async def get_objects_by_entity(
        self, entity_id: str, *, limit: int = 50
    ) -> list[dict[str, Any]]:
        return await self._request("GET", f"/entities/{entity_id}/objects", params={"limit": limit})

    async def get_objects_by_task(self, task_id: str, *, limit: int = 50) -> list[dict[str, Any]]:
        return await self._request("GET", f"/tasks/{task_id}/objects", params={"limit": limit})

    async def add_object_reference(
        self,
        object_id: str,
        *,
        entity_id: Optional[str] = None,
        task_id: Optional[str] = None,
    ) -> dict[str, Any]:
        payload = {"entity_id": entity_id, "task_id": task_id}
        return await self._request("POST", f"/objects/{object_id}/references", json=payload)

    async def remove_object_reference(
        self,
        object_id: str,
        *,
        entity_id: Optional[str] = None,
        task_id: Optional[str] = None,
    ) -> dict[str, Any]:
        payload = {"entity_id": entity_id, "task_id": task_id}
        return await self._request("DELETE", f"/objects/{object_id}/references", json=payload)

    async def find_orphaned_objects(self, *, limit: int = 100) -> list[dict[str, Any]]:
        return await self._request("GET", "/objects/orphaned", params={"limit": limit})

    async def get_object_references(self, object_id: str) -> dict[str, Any]:
        return await self._request("GET", f"/objects/{object_id}/references/info")

    async def validate_object_references(self, object_id: str) -> list[dict[str, Any]]:
        return await self._request("GET", f"/objects/{object_id}/references/validate")

    async def cleanup_object_references(self, object_id: str) -> dict[str, Any]:
        return await self._request("POST", f"/objects/{object_id}/references/cleanup")

    # Queries ------------------------------------------------------------------

    async def get_changed_since(
        self,
        since: datetime | str,
        *,
        limit_per_type: Optional[int] = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"since": since}
        if limit_per_type:
            params["limit_per_type"] = limit_per_type
        return await self._request("GET", "/queries/changed-since", params=params)

    async def get_full_dataset(
        self,
        *,
        entity_limit: Optional[int] = None,
        task_limit: Optional[int] = None,
        object_limit: Optional[int] = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {}
        if entity_limit:
            params["entity_limit"] = entity_limit
        if task_limit:
            params["task_limit"] = task_limit
        if object_limit:
            params["object_limit"] = object_limit
        return await self._request("GET", "/queries/full", params=params or None)
