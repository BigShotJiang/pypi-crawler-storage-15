from typing import List, TypedDict

class OCRResult(TypedDict):
    """OCR 识别结果"""
    text: str
    confidence: float
    x: int
    y: int
    ex: int
    ey: int
    width: int
    height: int
    centerX: int
    centerY: int
    angle: float
    orientation: int

def loadV5(maxSideLen: int = 640) -> bool:
    """加载 PP-OCRv5 模型（maxSideLen 默认 640）"""
    return True

def recognize(
    input: str,
    x: int = 0,
    y: int = 0,
    ex: int = 0,
    ey: int = 0,
    confidenceThreshold: float = 0.6,
) -> List[OCRResult]:
    """执行 OCR 识别（返回 OCRResult 列表）

    参数默认值:
      x/y/ex/ey: 0（全屏）
      confidenceThreshold: 0.6
    """
    return []

def free() -> None:
    """释放模型资源"""
    return None
