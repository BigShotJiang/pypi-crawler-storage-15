from typing import List, Optional, Literal, Union


class HIDKey:
    """HID 按键常量映射。

    用于组合键发送：可通过 hidKey.COMMAND、hidKey.LEFT_CTRL 等取得修饰键代码，
    也支持字典访问 hidKey["COMMAND"] 与直接传入字符串名称（如 "COMMAND"）。
    示例：
        from kuaijs import hid
        hid.sendKey([hid.hidKey.COMMAND, "c"])    # 复制（点属性）
        hid.sendKey([hid.hidKey["COMMAND"], "c"])  # 复制（字典）
        hid.sendKey(["COMMAND", "v"])             # 粘贴（字符串键名）
    """

    COMMAND = 0
    LEFT_CTRL = 0
    LEFT_SHIFT = 0
    LEFT_ALT = 0
    RIGHT_CTRL = 0
    RIGHT_SHIFT = 0
    RIGHT_ALT = 0
    UP_ARROW = 0
    DOWN_ARROW = 0
    LEFT_ARROW = 0
    RIGHT_ARROW = 0
    SPACE = 0
    BACKSPACE = 0
    TAB = 0
    RETURN = 0
    ESC = 0
    INSERT = 0
    DELETE = 0
    PAGE_UP = 0
    PAGE_DOWN = 0
    HOME = 0
    END = 0
    CAPS_LOCK = 0
    F1 = 0
    F2 = 0
    F3 = 0
    F4 = 0
    F5 = 0
    F6 = 0
    F7 = 0
    F8 = 0
    F9 = 0
    F10 = 0
    F11 = 0
    F12 = 0

    def __getitem__(self, key: str) -> int:
        return getattr(self, key, 0)


hidKey = HIDKey()


def setJitterValue(value: int) -> None: ...


def resetPosition(orientation: Literal["PORTRAIT", "LANDSCAPE"] = "PORTRAIT") -> None:
    """重置坐标系方向

    参数:
      orientation: 屏幕方向（PORTRAIT/LANDSCAPE）
    """
    return None


def click(x: int, y: int, duration: int = 10, jitter: bool = False) -> bool:
    """点击指定坐标

    参数:
      x/y: 坐标
      duration: 按下时长（毫秒，默认 10ms）
      jitter: 是否启用抖动（默认 False）
    返回:
      bool: 是否成功
    """
    return True


def clickRandom(x1: int, y1: int, x2: int, y2: int, duration: int = 20) -> bool:
    """随机点击指定矩形区域

    参数:
      x1/y1/x2/y2: 矩形区域坐标
      duration: 按下时长（毫秒，默认 20ms）
    返回:
      bool: 是否成功
    """
    return True


def doubleClick(
    x: int, y: int, duration: int = 20, interval: int = 20, jitter: bool = False
) -> bool:
    """双击指定坐标

    参数:
      duration: 每次按下时长（毫秒，默认 20ms）
      interval: 两次点击间隔（毫秒，默认 20ms）
      jitter: 是否启用抖动（默认 False）
    """
    return True


def doubleClickRandom(
    x1: int, y1: int, x2: int, y2: int, duration: int = 20, interval: int = 20
) -> bool:
    """随机双击矩形区域"""
    return True


def swipe(
    x: int, y: int, ex: int, ey: int, jitter: bool = False, steps: int = 6
) -> bool:
    """直线滑动

    参数:
      jitter: 是否启用抖动（默认 False）
      steps: 轨迹点数量（默认 6）
    """
    return True


def swipeCurve(
    startX: int, startY: int, midX: int, midY: int, endX: int, endY: int
) -> bool:
    """3 点曲线滑动"""
    return True


def homeScreen() -> bool:
    """回主页（Command+H）"""
    return True


def inputSimple(text: str) -> bool:
    """输入简单文本（英文及可输入键）"""
    return True


def space() -> bool:
    """空格键"""
    return True


def backspace() -> bool:
    """删除键"""
    return True


def enter() -> bool:
    """回车键"""
    return True


def sendKey(keys: List[Union[int, str]]) -> bool:
    """发送组合按键（支持数字或字符）"""
    return True


def copyText() -> bool:
    """复制文本（Command+C）"""
    return True


def pasteText() -> bool:
    """粘贴文本（Command+V）"""
    return True


def back() -> bool:
    """返回（Tab+B）"""
    return True


def recent() -> bool:
    """APP 切换器"""
    return True


def lock() -> bool:
    """锁屏"""
    return True


def unlock() -> bool:
    """解锁"""
    return True


def openURL(url: str) -> bool:
    """打开 URL"""
    return True


def openApp(name: str) -> bool:
    """打开 App"""
    return True


def takeMeToFront() -> bool:
    """切到前台"""
    return True


def currentAppInfo() -> Optional[dict]:
    """当前应用信息（仅 iOS18+）"""
    return None


def setClipboard(text: str) -> bool:
    """设置剪贴板"""
    return True


def getClipboard() -> str:
    """获取剪贴板"""
    return ""


def customButton(button: int) -> bool:
    """执行自定义按钮（1-11）"""
    return True
