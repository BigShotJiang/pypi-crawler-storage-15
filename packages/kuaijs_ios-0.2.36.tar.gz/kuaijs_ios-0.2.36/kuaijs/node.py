from typing import Any, Dict, List, Optional, Union, TypedDict

class SelectorParams(TypedDict, total=False):
    """节点选择器参数"""
    maxDepth: Optional[int]

class NodeBounds(TypedDict):
    x: int
    y: int
    width: int
    height: int
    centerX: int
    centerY: int

class NodeInfo:
    id: str = ""
    label: str = ""
    type: str = ""
    value: str = ""
    title: str = ""
    visible: bool = False
    enabled: bool = False
    accessible: bool = False
    bounds: NodeBounds = {"x": 0, "y": 0, "width": 0, "height": 0, "centerX": 0, "centerY": 0}
    depth: int = 0
    index: int = 0
    parentId: str = ""
    childCount: int = 0

    def clickCenter(self) -> bool: return True
    def clickRandom(self) -> bool: return True
    def parent(self) -> Optional["NodeInfo"]: return None
    def child(self, index: int) -> Optional["NodeInfo"]: return None
    def allChildren(self) -> List["NodeInfo"]: return []
    def siblings(self) -> List["NodeInfo"]: return []
    def previousSiblings(self) -> List["NodeInfo"]: return []
    def nextSiblings(self) -> List["NodeInfo"]: return []
    def toJSON(self) -> Dict[str, Any]: return {}

class NodeSelector:
    def clearSelector(self) -> "NodeSelector": return self
    def loadNode(self, timeout: int = 5000) -> "NodeSelector": return self
    def xml(self, timeout: int = 5000) -> Optional[str]: return None
    def getNodeInfo(self, timeout: int = 5000) -> List[NodeInfo]: return []
    def getOneNodeInfo(self, timeout: int = 5000) -> Optional[NodeInfo]: return None
    def xpath(self, path: str) -> "NodeSelector": return self
    def label(self, label: str) -> "NodeSelector": return self
    def labelMatch(self, match: str) -> "NodeSelector": return self
    def title(self, title: str) -> "NodeSelector": return self
    def titleMatch(self, match: str) -> "NodeSelector": return self
    def type(self, type_title: str) -> "NodeSelector": return self
    def typeMatch(self, match: str) -> "NodeSelector": return self
    def value(self, value: str) -> "NodeSelector": return self
    def valueMatch(self, match: str) -> "NodeSelector": return self
    def enabled(self, flag: bool) -> "NodeSelector": return self
    def accessible(self, flag: bool) -> "NodeSelector": return self
    def visible(self, flag: bool) -> "NodeSelector": return self
    def index(self, idx: int) -> "NodeSelector": return self
    def depth(self, d: int) -> "NodeSelector": return self
    def childCount(self, childCount: Union[int, str]) -> "NodeSelector": return self
    def bounds(self, x: int, y: int, width: int, height: int) -> "NodeSelector": return self

def createNodeSelector(params: Optional[SelectorParams] = None) -> NodeSelector:
    """创建节点选择器

    参数:
      params: maxDepth 最大层级深度默认 50
    返回:
      NodeSelector: 链式选择器
    """
    return NodeSelector()
