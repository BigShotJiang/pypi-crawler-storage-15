from typing import Optional, TypedDict


class HotUpdateOptions(TypedDict, total=False):
    """热更新检查参数"""

    url: Optional[str]
    version: Optional[int]
    timeout: Optional[int]


class HotUpdateResponse(TypedDict):
    """热更新响应数据"""

    download_url: str
    version: int
    download_timeout: int
    dialog: bool
    msg: str
    force: bool
    md5: Optional[str]


class HotUpdateResult(TypedDict):
    """热更新检查结果"""

    needUpdate: bool
    error: Optional[str]
    data: Optional[HotUpdateResponse]


class InstallResult(TypedDict):
    """安装结果"""

    updated: bool
    error: Optional[str]


def checkUpdate(options: Optional[HotUpdateOptions] = None) -> HotUpdateResult:
    """检查更新

    参数:
      options: 检查参数（url/version/timeout）
    返回:
      HotUpdateResult: needUpdate/data/error
    """
    return {"needUpdate": False, "error": None, "data": None}


def downloadAndInstall() -> InstallResult:
    """下载并安装更新（执行成功会自动重启脚本）"""
    return {"updated": False, "error": None}


def getCurrentVersion() -> int:
    """获取当前应用版本号（数字）"""
    return 0
