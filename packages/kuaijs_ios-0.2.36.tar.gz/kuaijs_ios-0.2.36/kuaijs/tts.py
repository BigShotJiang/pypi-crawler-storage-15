from typing import List, TypedDict

class VoiceInfo(TypedDict):
    """语音信息"""
    identifier: str
    name: str
    language: str
    quality: int

def speak(text: str, rate: float = 0.5, pitch: float = 1.0, volume: float = 1.0, language: str = "zh-CN") -> bool:
    """播放文本转语音（5 参数版本）

    参数默认值:
      rate: 0.5
      pitch: 1.0
      volume: 1.0
      language: "zh-CN"
    """
    return True

def waitEnd() -> None:
    """等待当前语音播放结束"""
    return None

def stop() -> None:
    """停止当前播放"""
    return None

def isSpeaking() -> bool:
    """是否正在播放"""
    return False

def getAvailableVoices() -> List[VoiceInfo]:
    """获取可用的语音列表"""
    return []

def setVoice(voiceIdentifier: str) -> bool:
    """设置语音（identifier）"""
    return True

def free() -> None:
    """释放 TTS 资源"""
    return None
