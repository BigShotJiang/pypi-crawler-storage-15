from typing import List, Optional, TypedDict


class OCRResult(TypedDict):
    """OCR 识别结果"""

    text: str
    confidence: float
    x: int
    y: int
    ex: int
    ey: int
    width: int
    height: int
    centerX: int
    centerY: int


def recognize(
    input: str,
    x: int = 0,
    y: int = 0,
    ex: int = 0,
    ey: int = 0,
    languages: Optional[List[str]] = None,
) -> List[OCRResult]:
    """OCR 识别（Apple Vision）

    参数默认值:
      x/y/ex/ey: 0
      languages: ["zh-Hans", "en-US"]
    返回:
      List[OCRResult]: 文本、置信度与位置信息列表
    """
    return []


def recognizeNumbers(
    input: str,
    x: int = 0,
    y: int = 0,
    ex: int = 0,
    ey: int = 0,
) -> List[OCRResult]:
    """仅识别数字（过滤非数字，保留 0-9 . , - +）

    参数默认值:
      x/y/ex/ey: 0
    返回:
      同 recognize
    """
    return []


def findText(
    input: str,
    texts: List[str],
    x: int = 0,
    y: int = 0,
    ex: int = 0,
    ey: int = 0,
    languages: Optional[List[str]] = None,
) -> List[OCRResult]:
    """查找指定文本位置

    参数默认值:
      x/y/ex/ey: 0
      languages: ["zh-Hans", "en-US"]
    返回:
      List[OCRResult]: 匹配文本的位置信息列表
    """
    return []
