from bluer_objects.README.items import ImageItems

from bluer_sbc.README.designs.anchor import image_template

items = ImageItems(
    {
        image_template.format("03.png"): "",
        image_template.format("20251204_144037.jpg"): "",
    }
)
