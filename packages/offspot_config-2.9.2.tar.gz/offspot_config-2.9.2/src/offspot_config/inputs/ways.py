WAYS = ("direct", "base64", "bztar", "gztar", "tar", "xztar", "zip")
