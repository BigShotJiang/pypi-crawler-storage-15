from types import SimpleNamespace

import click

from ._version import __version__
from .add_plugins import add_plugins
from .session import Session

_unspecified = object()


@add_plugins
@click.group(
    context_settings={"help_option_names": ["-h", "--help"]},
    # invoke_without_command=True,
)
@click.version_option(version=__version__, prog_name="tgzr")
@click.option(
    "-c",
    "--cwd",
    default=None,
    help="Path to look for config (defaults to current directory).",
)
@click.option(
    "-n", "--config-name", help='Name of the config to load (default=".tgzr")'
)
@click.option("-v", "--verbose", is_flag=True, flag_value="", help="Chatty mode.")
@click.option(
    "--quite",
    is_flag=True,
    flag_value="",
    help="Quite mode (cancels --verbose).",
)
@click.pass_context
def tgzr_cli(
    ctx,
    cwd: str | None = None,
    config_name: str | None = None,
    verbose: bool | None = None,
    quite: bool | None = None,
):
    session = Session()
    if config_name is not None:
        session._config_filename = config_name

    if cwd is None:
        cwd = "."

    config_path = session.set_home(cwd, ensure_config_found=False)
    if config_path is None:
        click.echo(
            f'No config found at "{cwd}" and ancestors, home is {session.home} and config is default.'
        )
    else:
        click.echo(f'Config file found, home set to "{session.home}"')

    # f*cking flags :sob:
    if verbose == "":
        verbose = True
    if quite == "":
        quite = True

    if quite:
        verbose = False

    if verbose is not None and verbose != session.config.verbose:
        print("Settings verbose mode:", bool(verbose))
        session.config.verbose = verbose

    ctx.obj = SimpleNamespace()
    ctx.obj.session = session
