from pathlib import Path

import click
import rich

from tgzr.cli.session import Session


def install_plugin(group: click.Group):
    group.add_command(config)


@click.group(help="Manage tgzr cli configs.")
def config():
    pass


@config.command()
@click.pass_context
def show(ctx):
    session: Session = ctx.obj.session
    rich.print(session.config)


@config.command()
@click.pass_context
@click.option("-o", "--output", help='The file to save. Defaults to "home/.tgzr".')
@click.option("--force", is_flag=True)
def save(ctx, output: Path | None = None, force: bool = False):
    session: Session = ctx.obj.session

    try:
        session.write_config_file(output, allow_overwrite=force)
    except FileExistsError as err:
        click.echo(f"File {err} already exists! (Use --force to allow overwrite.)")
