def external_impure() -> None:
    pass
