# noqa: D100

extensions = [
    "atsphinx.bulma",
]
html_theme = "bulma-basic"
