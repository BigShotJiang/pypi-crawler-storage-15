==============
atsphinx-bulma
==============

Bluma using suite for Sphinx.

Overview
========

This is Sphinx extension for Bulma users.
You can improve your documentation with Bulma by this.

Providing features
==================

* Component translators
* Basic theme
* Widgets for template

Getting started
===============

.. code:: console

   pip install atsphinx-bulma

Refs
====

* `Bulma <https://bulma.io/>`_
