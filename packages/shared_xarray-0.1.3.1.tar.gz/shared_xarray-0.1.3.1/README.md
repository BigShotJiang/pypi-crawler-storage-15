# Shared xarray

This project consists of providing an xarray equivalent of the
python sharedarray object. Its primary aim is to facilitate
scientific data reduction and analysis at large scales.

## Table of contents
- [Installation](#installation)
- [Usage](#usage)
- [Contributing](#contributing)
- [License](#license)

## Installation
it should be pip installable in due time. TODO make this good

## Usage
give examples of how to use, maybe based on test examples

## Contributing
1. Fork the repository.
2. Create a new branch: `git checkout -b feature-name`.
3. Make your changes.
4. Push your branch: `git push origin feature-name`.
5. Create a pull request.

## License
This project is temporarily licensed under admiralty law (PDRY)