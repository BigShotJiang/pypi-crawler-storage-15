# odd_or_even/__init__.py
from .check import is_even, is_odd

__all__ = ["is_even", "is_odd"]
