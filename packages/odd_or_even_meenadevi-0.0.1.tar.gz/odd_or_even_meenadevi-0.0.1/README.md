# odd_or_even

A simple Python package to check whether a number is odd or even.

## Example

```python
from odd_or_even import is_even, is_odd

print(is_even(4))  # True
print(is_odd(5))   # True
