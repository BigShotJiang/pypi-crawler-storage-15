v0.5.0
======

- Integrate EUSC regions

v0.4.0
======

- Cast regions list to a set to remove duplicates

v0.3.0
======

- Update spec to build for one version of python

v0.2.0
======

- Migrate spec build to python 3.11
- Update vcrpy cassettes to 3.11 format
- Update compatible python versions

v0.1.2
======

- Fix python conditional in spec file using sle version.

v0.1.1
======

- Fix python conditional in spec file. Use a macro that exists in all
  python-rpm-macros versions.

v0.1.0
======

- Add config and additional regions options. This allows for the addition
  of custom regions in each partition.
- Revert to using a Python style changes file.

v0.0.4
======
  
- Add rpm-macros to build requirements in spec.

v0.0.3
======

- Add README content.
- Add packaging artifacts for OBS.

v0.0.2
======

- Fix lru_cache bug. maxsize was not optional before python 3.8.

v0.0.1
======

- Initial release.
