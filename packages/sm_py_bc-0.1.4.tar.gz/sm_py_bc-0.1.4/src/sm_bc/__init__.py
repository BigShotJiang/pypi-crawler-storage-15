"""SM-PY-BC: Chinese Cryptography Standards (SM2/SM3/SM4) in Pure Python"""

__version__ = "0.1.4"
__author__ = "sm-py-bc Contributors"
__license__ = "MIT"
