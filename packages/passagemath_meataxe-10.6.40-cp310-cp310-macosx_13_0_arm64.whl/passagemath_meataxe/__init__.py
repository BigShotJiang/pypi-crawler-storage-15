# sage_setup: distribution = sagemath-meataxe

from sage.all__sagemath_meataxe import *
