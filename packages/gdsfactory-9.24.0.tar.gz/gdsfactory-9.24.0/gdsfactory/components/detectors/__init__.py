from gdsfactory.components.detectors.detector_ge import (
    ge_detector_straight_si_contacts,
)

__all__ = ["ge_detector_straight_si_contacts"]
