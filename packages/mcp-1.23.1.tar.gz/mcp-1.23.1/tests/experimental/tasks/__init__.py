"""Tests for MCP task support."""
