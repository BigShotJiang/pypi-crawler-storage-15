"""Allow running the module with python -m."""

from . import main

if __name__ == "__main__":
    main()
