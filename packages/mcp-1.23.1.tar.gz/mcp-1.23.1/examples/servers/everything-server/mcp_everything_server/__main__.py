"""CLI entry point for the MCP Everything Server."""

from .server import main

if __name__ == "__main__":
    main()
