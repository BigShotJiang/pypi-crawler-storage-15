from django.apps import AppConfig


class DjangoNitroMailerConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "django_nitro_mailer"
    verbose_name = "Django Nitro Mailer"
