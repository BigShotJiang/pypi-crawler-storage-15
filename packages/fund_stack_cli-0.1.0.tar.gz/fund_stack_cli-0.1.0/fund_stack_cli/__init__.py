"""
FundStack CLI Package.
"""

from .cli import handle_user_choice

def main():
    handle_user_choice()
