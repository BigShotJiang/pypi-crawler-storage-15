from typing import TypeVar

_HttpResponse = TypeVar('_HttpResponse')
_Cookies = TypeVar('_Cookies')
_Tokens = TypeVar('_Tokens')
