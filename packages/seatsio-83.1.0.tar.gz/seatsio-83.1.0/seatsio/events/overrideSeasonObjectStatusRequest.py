class OverrideSeasonObjectStatusRequest:
    def __init__(self, objects):
        self.objects = objects
