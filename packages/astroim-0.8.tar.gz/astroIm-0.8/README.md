# astroIm
The astroIm package provides some functions for manipulating fits files, and some convenience wrappers for astropy functions. 
