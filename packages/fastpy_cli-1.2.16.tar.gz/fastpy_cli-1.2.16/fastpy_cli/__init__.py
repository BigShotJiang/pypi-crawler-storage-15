"""Fastpy CLI - Create production-ready FastAPI projects."""

__version__ = "1.2.16"
__author__ = "Vutia Enterprise"
__email__ = "hello@ve.ke"
