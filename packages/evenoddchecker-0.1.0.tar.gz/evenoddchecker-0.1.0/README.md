# evenoddchecker
A simple Python package to check if a number is odd or even.
