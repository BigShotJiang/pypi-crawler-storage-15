"""Todo CLI - A simple command-line to-do list application."""

__version__ = "0.1.0"

from .todo import main

__all__ = ["main"]
