DEFAULT_PROFILE_KEY = "x-mycelium-profile"

DEFAULT_EMAIL_KEY = "x-mycelium-email"

DEFAULT_SCOPE_KEY = "x-mycelium-scope"

DEFAULT_MYCELIUM_ROLE_KEY = "x-mycelium-role"

DEFAULT_REQUEST_ID_KEY = "x-mycelium-request-id"

DEFAULT_CONNECTION_STRING_KEY = "x-mycelium-connection-string"

DEFAULT_TENANT_ID_KEY = "x-mycelium-tenant-id"
