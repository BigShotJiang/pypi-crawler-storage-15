from .plugin import RuffPlugin


def ruff() -> RuffPlugin:
    return RuffPlugin()
