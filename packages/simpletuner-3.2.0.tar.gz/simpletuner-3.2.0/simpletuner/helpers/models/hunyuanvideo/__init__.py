# HunyuanVideo 1.5 integration for SimpleTuner.
