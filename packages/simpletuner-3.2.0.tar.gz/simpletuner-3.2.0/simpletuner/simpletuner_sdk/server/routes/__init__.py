"""Routes for SimpleTuner server."""

# Expose commonly patched submodules for compatibility with legacy imports.
from . import webui_state  # noqa: F401

__all__ = ["webui_state"]
