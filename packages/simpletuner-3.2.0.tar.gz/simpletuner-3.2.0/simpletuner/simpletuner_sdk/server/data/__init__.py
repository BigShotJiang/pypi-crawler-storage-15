"""Static data utilities for SimpleTuner server."""
