from .config import CTGANPremiumConfig

__all__ = ["CTGANPremiumConfig"]
