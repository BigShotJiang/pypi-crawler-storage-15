from .factory import CTGANFactory
from .api import CTGANAPI

__all__ = ["CTGANFactory", "CTGANAPI"]
