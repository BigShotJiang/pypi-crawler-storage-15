from .generator import CTGANGenerator
from .discriminator import CTGANDiscriminator

__all__ = ["CTGANGenerator", "CTGANDiscriminator"]
