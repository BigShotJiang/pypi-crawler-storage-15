from .trainer import CTGANTrainer

__all__ = ["CTGANTrainer"]
