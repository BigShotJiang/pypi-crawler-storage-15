"""
Configuration module for TabuDiff
"""

from .config import TabuDiffConfig

__all__ = ["TabuDiffConfig"]
