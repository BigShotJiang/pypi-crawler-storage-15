"""Premium samplers package."""

from .sampler import PremiumDiffusionSampler

__all__ = ['PremiumDiffusionSampler']
