"""Premium trainers package."""

from .trainer import TabuDiffPremiumTrainer

__all__ = ['TabuDiffPremiumTrainer']
