"""Copula core package."""

from .copula_core import CopulaCore

__all__ = ['CopulaCore']
