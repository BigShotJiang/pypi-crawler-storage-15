"""Copula-based synthetic data generation."""

from .utils.api import CopulaAPI

__all__ = ['CopulaAPI']
