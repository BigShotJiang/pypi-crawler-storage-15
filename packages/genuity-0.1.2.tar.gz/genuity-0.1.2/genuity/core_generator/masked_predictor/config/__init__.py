# Configuration module for masked predictor
