sed 's/\s*$//' oillibnorway.csv > oillibnorway.cleaned

