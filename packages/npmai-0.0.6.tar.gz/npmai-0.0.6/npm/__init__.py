__version__ = "0.0.6"
from .npmai import GeminiAIMode, Gemini, ChatGPT, Grok, Perplexity, Image, Mistral
