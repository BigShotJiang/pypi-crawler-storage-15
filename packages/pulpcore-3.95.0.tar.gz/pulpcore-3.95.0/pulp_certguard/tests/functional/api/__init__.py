"""Tests that communicate with certguard plugin via the v3 API."""
