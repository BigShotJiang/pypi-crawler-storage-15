# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

"""Shim exposing qsharp.estimator as qdk.estimator."""

from qsharp.estimator import *  # pyright: ignore[reportWildcardImportFromLibrary]
