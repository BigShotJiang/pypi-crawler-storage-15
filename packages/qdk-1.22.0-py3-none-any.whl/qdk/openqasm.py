# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

"""Shim exposing qsharp.openqasm as qdk.openqasm."""

from qsharp.openqasm import *  # pyright: ignore[reportWildcardImportFromLibrary]
