#
# Simple compatibility stub for older scripts that use greatfet.peripherals.
#

# Pull in all of our interfaces, and make them available under the peripherals namespace..
from .interfaces import *
