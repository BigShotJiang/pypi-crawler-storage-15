#
# This file is part of GreatFET.
#

class GreatFETProgrammer(object):
    """ Base class for components that use Interfaces to program other devices. """

