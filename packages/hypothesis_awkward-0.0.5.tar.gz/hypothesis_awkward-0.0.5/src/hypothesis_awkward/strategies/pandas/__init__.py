__all__ = ['dicts_for_dataframe']

from .dict_ import dicts_for_dataframe
