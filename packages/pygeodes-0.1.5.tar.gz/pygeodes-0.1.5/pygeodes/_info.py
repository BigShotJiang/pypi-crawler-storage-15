version = "v0.1.5"
name = "pygeodes"
description = "A Python client for Geodes APIs"
author = "CNES"
