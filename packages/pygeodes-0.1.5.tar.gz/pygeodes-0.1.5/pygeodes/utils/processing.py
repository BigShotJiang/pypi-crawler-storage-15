from dataclasses import dataclass


@dataclass
class Processing:
    pass


@dataclass
class Process:
    pass
