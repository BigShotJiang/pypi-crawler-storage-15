# AutoSubSync resources package
