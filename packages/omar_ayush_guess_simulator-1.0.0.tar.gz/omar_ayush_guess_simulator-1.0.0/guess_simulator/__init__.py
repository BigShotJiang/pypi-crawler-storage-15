"""
Probability-Guided Number Guessing Simulator

A production-grade CLI application for playing number guessing games
with intelligent probability-based hints and comprehensive game tracking.
"""

__version__ = "1.0.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"
