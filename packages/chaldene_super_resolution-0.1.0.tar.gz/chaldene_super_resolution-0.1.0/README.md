# super_resolution

The test image, part of code in super_resolution folder are from https://github.com/Luchixiang/EMDiffuse

To explore the usage interactively, please click
[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/drive/1qcEOErglYt9N9gZZLAez-Um7agn-5FVj?usp=sharing)
