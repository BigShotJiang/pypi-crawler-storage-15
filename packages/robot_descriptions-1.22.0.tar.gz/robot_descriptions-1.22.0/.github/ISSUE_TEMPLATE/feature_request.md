---
name: 💡 Feature request
about: Suggest an idea to improve Upkie
title: ''
labels: 'enhancement'
assignees: ''

---

# Current limitation

Please describe the problem that the proposed feature would address. For instance: "I'm always frustrated when..."

# Proposed solution

Describe (as concisely as possible) the solution you'd like.

Do you have screenshots or sketches to illustrate it?

# Additional context

Describe any additional context, alternatives you can think of, ...
