# The formula_helpers module has been deprecated since X.X.X,
# and will be removed in the future.
#
# The helpers have been moved to the commons module.
#
# The following are transitional imports to ensure non-breaking changes.
# Could be deprecated in the next major release.

from openfisca_core.commons import average_rate, marginal_rate  # noqa: F401
