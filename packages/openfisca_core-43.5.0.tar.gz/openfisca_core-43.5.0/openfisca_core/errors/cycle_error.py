class CycleError(Exception):
    """Simulation error."""
