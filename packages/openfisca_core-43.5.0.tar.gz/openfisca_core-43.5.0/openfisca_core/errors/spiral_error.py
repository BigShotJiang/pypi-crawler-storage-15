class SpiralError(Exception):
    """Simulation error."""
