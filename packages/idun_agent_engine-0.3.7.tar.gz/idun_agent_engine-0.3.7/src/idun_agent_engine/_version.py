"""Version information for Idun Agent Engine."""

__version__ = "0.3.7"
