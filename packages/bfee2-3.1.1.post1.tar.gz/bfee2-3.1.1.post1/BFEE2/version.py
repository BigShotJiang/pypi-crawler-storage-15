__VERSION__ = '3.1.1.post1'
__NAMD_VERSION__ = '3.0.1'
__GMX_VERSION__ = '2024'

