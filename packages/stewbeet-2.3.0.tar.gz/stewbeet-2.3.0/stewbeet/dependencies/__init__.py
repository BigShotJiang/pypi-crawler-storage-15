
# Imports
from stouputils.io import get_root_path

from .bookshelf import *

# This folder path
OFFICIAL_LIBS_PATH: str = get_root_path(__file__)

