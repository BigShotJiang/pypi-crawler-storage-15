"""MCP package for igloo-mcp.

This package contains MCP-specific utilities, exceptions, and tool implementations.
"""

from __future__ import annotations

__all__: list[str] = []
