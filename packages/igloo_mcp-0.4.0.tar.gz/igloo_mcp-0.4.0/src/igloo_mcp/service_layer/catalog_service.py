"""Catalog service for service layer."""

from igloo_mcp.catalog.catalog_service import CatalogService

__all__ = ["CatalogService"]
