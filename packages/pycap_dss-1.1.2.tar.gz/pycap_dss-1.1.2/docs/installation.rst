============
Installation
============

Install your cloned local version using command line::

    $ pip install -e .

Alternatively, latest release versions are available on pip and conda-forge

