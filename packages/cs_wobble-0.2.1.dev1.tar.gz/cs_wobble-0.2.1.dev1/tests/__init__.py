# Tests package for {{PROJECT_NAME}}
# This package contains unittest-based tests compatible with the future wobble testing framework
