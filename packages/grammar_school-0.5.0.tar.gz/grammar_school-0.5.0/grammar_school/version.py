"""Version information for Grammar School."""

__version__ = "0.5.0"
