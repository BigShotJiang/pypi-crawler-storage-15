# Normalization
