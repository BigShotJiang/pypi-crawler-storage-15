from django.urls import path
from .views import erd_view, graph_models_view, ApiSchemaGenerator, DashboardApiSchemaGenerator
from drf_spectacular.views import SpectacularAPIView, SpectacularSwaggerView, SpectacularRedocView
from django.contrib.auth.decorators import login_required

urlpatterns = [
    path('doc/api/schema', login_required(SpectacularAPIView.as_view(generator_class=ApiSchemaGenerator)), name='api_schema'),
    path('doc/api/redoc', login_required(SpectacularRedocView.as_view(url_name='api_schema')), name='doc/api/redoc'),
    path('doc/api/swagger', login_required(SpectacularSwaggerView.as_view(url_name='api_schema')), name='doc/api/swagger'),

    path('doc/dashboard/api/schema', login_required(SpectacularAPIView.as_view(generator_class=DashboardApiSchemaGenerator)), name='dashboard_api_schema'),
    path('doc/dashboard/api/redoc', login_required(SpectacularRedocView.as_view(url_name='dashboard_api_schema')), name='doc/dashboard/api/redoc'),
    path('doc/dashboard/api/swagger', login_required(SpectacularSwaggerView.as_view(url_name='dashboard_api_schema')), name='doc/dashboard/api/swagger'),

    path('doc/erd.<ext>', erd_view, name='doc/erd'),
    path('doc/models.<ext>', graph_models_view, name='doc/models'),
]


