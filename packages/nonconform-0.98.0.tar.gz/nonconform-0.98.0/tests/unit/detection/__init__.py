"""Unit tests for detection module."""
