def main():
    print("Hello from hivekit!")


if __name__ == "__main__":
    main()
