# DICOM Medical Sequential Images to Video Converter

A simple script to convert DICOM medical sequential images to video.

Just run it by executing the following command:

```sh
uvx dicom-to-video
```
