"""
koci - Universal CI Definition Tool

Run CI pipelines locally and export to any CI platform.
"""

from .core.version import get_version

__version__ = get_version()

__all__ = ['__version__']
