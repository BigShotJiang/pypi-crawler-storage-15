"""
koci Templates Module

Jinja2 templates for output rendering.
"""
