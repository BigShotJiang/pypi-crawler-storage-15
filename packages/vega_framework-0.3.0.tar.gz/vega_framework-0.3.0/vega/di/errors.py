"""Dependency Injection errors"""


class DependencyInjectionError(Exception):
    """Custom exception for dependency injection errors."""
    pass
