# Changelog

## [0.1.14] - 2025-12-02
- Updated connector definition (YAML version 0.0.1)
- Source commit: 7153780a
- SDK version: 0.1.0

## [0.1.13] - 2025-12-02
- Updated connector definition (YAML version 0.0.1)
- Source commit: 01f71cad
- SDK version: 0.1.0

## [0.1.12] - 2025-12-02
- Updated connector definition (YAML version 0.0.4)
- Source commit: 236db7f0
- SDK version: 0.1.0

## [0.1.11] - 2025-12-02
- Updated connector definition (YAML version 0.0.3)
- Source commit: 4c17f060
- SDK version: 0.1.0

## [0.1.10] - 2025-12-02
- Updated connector definition (YAML version 0.0.3)
- Source commit: cd499acd
- SDK version: 0.1.0

## [0.1.9] - 2025-12-02
- Updated connector definition (YAML version 0.0.3)
- Source commit: 64df6a87
- SDK version: 0.1.0

## [0.1.8] - 2025-12-02
- Updated connector definition (YAML version 0.0.1)
- Source commit: f34b246f
- SDK version: 0.1.0

## [0.1.7] - 2025-12-02
- Updated connector definition (YAML version 0.0.1)
- Source commit: b261c3a2
- SDK version: 0.1.0

## [0.1.6] - 2025-11-27
- Updated connector definition (YAML version 0.0.1)
- Source commit: 702fd446
- SDK version: 0.1.0

## [0.1.5] - 2025-11-27
- Updated connector definition (YAML version 0.0.1)
- Source commit: d656a4a2
- SDK version: 0.1.0

## [0.1.4] - 2025-11-27
- Updated connector definition (YAML version 0.0.1)
- Source commit: 9afac212
- SDK version: 0.1.0

## [0.1.3] - 2025-11-27
- Updated connector definition (YAML version 0.0.1)
- Source commit: 9afac212
- SDK version: 0.1.0

## [0.1.2] - 2025-11-27
- Updated connector definition (YAML version 0.0.1)
- Source commit: c1700e5e
- SDK version: 0.1.0
- YAML version: 0.0.1

## [0.1.1] - 2025-11-26
- Updated connector definition (YAML version 0.0.1)
- Source commit: 5a3bf104
- SDK version: 0.1.0
- YAML version: 0.0.1

## [0.1.0] - 2025-11-26
- Updated connector definition (YAML version 0.0.1)
- Source commit: 5a3bf104
- SDK version: 0.1.0
- YAML version: 0.0.1
