//! NumPy-like array utilities.
//!
//! License: BSD 3-Clause (see LICENSE file in this directory)

mod array;

pub use array::*;
