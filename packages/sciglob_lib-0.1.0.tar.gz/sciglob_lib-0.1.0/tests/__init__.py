"""Tests for SciGlob library."""

