"""xRegistry generator module."""
