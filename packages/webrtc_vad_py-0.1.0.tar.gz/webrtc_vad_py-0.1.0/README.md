# webrtc-vad-py

webrtc-vad-py wrapper for trimming speech clips
