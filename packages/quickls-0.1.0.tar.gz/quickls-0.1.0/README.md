# qls — Quick Listing Server

QLS is a prettier directory browser built on top of Python's built-in http.server.

## Install

pip install qls

## use

python -m qls [port]
