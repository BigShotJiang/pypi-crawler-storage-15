"""
🚀 Universal LangChain Tracker for VeriskGO
Handles ALL LangChain versions, ALL Bedrock Models (Claude, Llama, Titan)
and ALL LCEL pipelines (invoke / ainvoke / generate / agenerate).

It intercepts:
    BaseChatModel._generate   (sync)
    BaseChatModel._agenerate  (async)

Which ALWAYS receive the FULL ChatGeneration object
BEFORE parsers strip metadata.

This guarantees correct token + cost extraction — ALWAYS.
"""

import time
import functools
import traceback
import inspect
import contextvars
from typing import Any, Optional, Dict, cast

from .trace_manager import TraceManager, serialize_value, calculate_cost


# =====================================================================
# CONTEXT FOR STORING USAGE
# =====================================================================

_last_lc_usage: contextvars.ContextVar[
    Optional[Dict[str, Any]]
] = contextvars.ContextVar("last_lc_usage", default=None)


# =====================================================================
# UNIVERSAL TOKEN EXTRACTOR
# =====================================================================

def _extract_metadata_from_result(result: Any) -> Optional[Dict[str, Any]]:
    """
    Extract token metadata from ANY LangChain result object.

    Supports:
        ChatGeneration
        GenerationChunk
        BaseMessage
        LCEL internal structures
        ANY model: Claude, Llama, Titan, etc.
    """

    candidates = []

    # 1. Try top-level fields
    for field in ["generation_info", "response_metadata", "raw", "additional_kwargs"]:
        meta = getattr(result, field, None)
        if isinstance(meta, dict):
            candidates.append(meta)

    # 2. Try nested BaseMessage (newer LangChain)
    msg = getattr(result, "message", None)
    if msg:
        for field in ["response_metadata", "additional_kwargs"]:
            meta = getattr(msg, field, None)
            if isinstance(meta, dict):
                candidates.append(meta)

    # 3. Try generations list (older LC chains)
    gens = getattr(result, "generations", None)
    if isinstance(gens, list) and gens:
        g = gens[0]
        meta = getattr(g, "generation_info", None)
        if isinstance(meta, dict):
            candidates.append(meta)

    if not candidates:
        return None

    merged = {}
    for c in candidates:
        merged.update(c)

    # Normalize token keys
    input_tokens = (
        merged.get("input_tokens")
        or merged.get("inputTokens")
        or merged.get("prompt_tokens")
        or merged.get("promptTokens")
        or merged.get("tokens_in")
        or 0
    )

    output_tokens = (
        merged.get("output_tokens")
        or merged.get("outputTokens")
        or merged.get("completion_tokens")
        or merged.get("completionTokens")
        or merged.get("tokens_out")
        or 0
    )

    return {
        "input_tokens": int(input_tokens),
        "output_tokens": int(output_tokens),
        "total_tokens": int(input_tokens) + int(output_tokens),
    }


# =====================================================================
# PATCH LangChain UNIVERSAL GENERATE FUNCTIONS
# =====================================================================

def _patch_langchain_generate():
    """
    Patch BaseChatModel._generate and BaseChatModel._agenerate.
    These methods ALWAYS receive the full generation object.

    This works for ALL LangChain versions:
      - <=0.1.x
      - 0.2.x
      - 0.3.x
      - 1.x+
    """

    try:
        from langchain_core.language_models.chat_models import BaseChatModel
    except Exception:
        # older version
        pass

    # Patch sync _generate()
    original_generate = getattr(BaseChatModel, "_generate", None)
    if callable(original_generate):

        def patched_generate(self, *args, **kwargs):
            result = cast(Any, original_generate)(self, *args, **kwargs)

            meta = _extract_metadata_from_result(result)
            if meta:
                _last_lc_usage.set(meta)

            return result

        setattr(BaseChatModel, "_generate", patched_generate)

    # Patch async _agenerate()
    original_agenerate = getattr(BaseChatModel, "_agenerate", None)
    if callable(original_agenerate):

        async def patched_agenerate(self, *args, **kwargs):
            result = await cast(Any, original_agenerate)(
                self, *args, **kwargs
            )

            meta = _extract_metadata_from_result(result)
            if meta:
                _last_lc_usage.set(meta)

            return result

        setattr(BaseChatModel, "_agenerate", patched_agenerate)


# Execute patch at import
_patch_langchain_generate()


# =====================================================================
# BUILD OUTPUT + COST DETAILS
# =====================================================================

def _build_output(result: Any, model_id: str, latency: int):
    usage = _last_lc_usage.get() or {
        "input_tokens": 0,
        "output_tokens": 0,
        "total_tokens": 0
    }

    cost = calculate_cost(usage)

    if isinstance(result, tuple):
        text = result[0]
    elif isinstance(result, str):
        text = result
    else:
        text = serialize_value(result)

    return {
        "status": "success",
        "model": model_id,
        "latency_ms": latency,
        "output": {"text": text},
        "usage": usage,
        "usage_details": usage,
        "cost": cost,
        "cost_details": cost,
    }


# =====================================================================
# DECORATOR: track_langchain
# =====================================================================

def track_langchain(name: str = "langchain_call", *, model_id: str = "", tags=None):

    def decorator(func):
        is_async = inspect.iscoroutinefunction(func)

        # Async wrapper
        async def async_wrapper(*args, **kwargs):
            if not TraceManager.has_active_trace():
                return await func(*args, **kwargs)

            span_id = TraceManager.start_span(
                name,
                input_data={"args": serialize_value(args),
                            "kwargs": serialize_value(kwargs)},
                tags=tags
            )

            start = time.time()
            try:
                result = await func(*args, **kwargs)
            except Exception as e:
                TraceManager.end_span(span_id, {
                    "status": "error",
                    "error": str(e),
                    "stacktrace": traceback.format_exc()
                })
                raise

            latency = int((time.time() - start) * 1000)
            TraceManager.end_span(span_id, _build_output(result, model_id, latency))
            return result

        # Sync wrapper
        def sync_wrapper(*args, **kwargs):
            if not TraceManager.has_active_trace():
                return func(*args, **kwargs)

            span_id = TraceManager.start_span(
                name,
                input_data={"args": serialize_value(args),
                            "kwargs": serialize_value(kwargs)},
                tags=tags
            )

            start = time.time()
            try:
                result = func(*args, **kwargs)
            except Exception as e:
                TraceManager.end_span(span_id, {
                    "status": "error",
                    "error": str(e),
                    "stacktrace": traceback.format_exc()
                })
                raise

            latency = int((time.time() - start) * 1000)
            TraceManager.end_span(span_id, _build_output(result, model_id, latency))
            return result

        return functools.wraps(func)(async_wrapper if is_async else sync_wrapper)

    return decorator
