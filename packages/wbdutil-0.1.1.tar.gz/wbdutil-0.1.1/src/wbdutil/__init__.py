# The version number, in the form major.minor.patch
__VERSION__ = "0.1.1"

# The name of the module
MODULE_NAME = "wbdutil"

# The name of the command line interface.
CLI_NAME = "wbdutil"
