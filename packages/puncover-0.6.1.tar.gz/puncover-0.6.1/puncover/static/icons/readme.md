Icons from this folder are copied or derived from

 - https://github.com/Microsoft/vscode (MIT License)
