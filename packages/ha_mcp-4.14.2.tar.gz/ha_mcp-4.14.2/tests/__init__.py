"""Home Assistant MCP Server Tests."""
