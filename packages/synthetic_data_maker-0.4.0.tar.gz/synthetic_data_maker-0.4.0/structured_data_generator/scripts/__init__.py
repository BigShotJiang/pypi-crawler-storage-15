"""
CLI and automation scripts
"""
