from .apertium import Apertium, ApertiumNotInstalledError
