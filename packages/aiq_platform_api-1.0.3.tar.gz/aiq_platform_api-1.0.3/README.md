# AttackIQ Platform API

> ⚠️ **Beta** - Under active development. APIs subject to change. Feedback: rajesh.sharma@attackiq.com | Access: Request invite to AttackIQ GitHub.

Tools for interacting with the AttackIQ Platform API:
- **Python SDK** (`aiq-platform-api`) - Async library for Python applications
- **CLI** (`aiq`) - Command-line interface

---

## Python SDK

Install from PyPI:

```bash
pip install aiq-platform-api
```

### Usage

```python
import asyncio
from aiq_platform_api import AttackIQClient, Scenarios, Assets

async def main():
    async with AttackIQClient(
        "https://your-platform.attackiq.com",
        "your-api-token"
    ) as client:
        # Search scenarios
        result = await Scenarios.search_scenarios(client, query="powershell", limit=10)
        print(f"Found {result['count']} scenarios")

        # List assets
        async for asset in Assets.get_assets(client, limit=5):
            print(asset["hostname"])

asyncio.run(main())
```

### Environment Variables

```bash
export ATTACKIQ_PLATFORM_URL="https://your-platform-url.attackiq.com"
export ATTACKIQ_PLATFORM_API_TOKEN="your-api-token"
```

---

## CLI

#### Quick Install (Recommended)

**Public repo:**
```bash
curl -sSL https://raw.githubusercontent.com/AttackIQ/aiq-platform-api/main/install.sh | bash
```

**Private repo (with token):**
```bash
GITHUB_TOKEN="your_token_here" bash -c \
  'curl -sSL -H "Authorization: Bearer $GITHUB_TOKEN" -H "Accept: application/vnd.github.v3.raw" \
   https://api.github.com/repos/AttackIQ/aiq-platform-api/contents/install.sh | bash'
```

This auto-detects your OS and architecture, downloads the latest release, and installs to `/usr/local/bin`.

To create a token: GitHub → Settings → Developer settings → Personal access tokens → Fine-grained tokens → Generate with `Contents: Read-only` permission for this repo.

#### Manual Download

Download the appropriate binary for your system from [GitHub Releases](https://github.com/AttackIQ/aiq-platform-api/releases/latest):

| OS | Architecture | Download |
|----|--------------|----------|
| Linux | x86_64 | `aiq_*_linux_amd64.tar.gz` |
| Linux | ARM64 | `aiq_*_linux_arm64.tar.gz` |
| macOS | Intel | `aiq_*_darwin_amd64.tar.gz` |
| macOS | Apple Silicon | `aiq_*_darwin_arm64.tar.gz` |
| Windows | x86_64 | `aiq_*_windows_amd64.zip` |
| Windows | ARM64 | `aiq_*_windows_arm64.zip` |

**Linux/macOS:**
```bash
# Download (replace URL with your OS/arch)
curl -LO https://github.com/AttackIQ/aiq-platform-api/releases/latest/download/aiq_VERSION_linux_amd64.tar.gz

# Extract
tar xzf aiq_*.tar.gz

# Move to PATH
sudo mv aiq /usr/local/bin/

# Verify
aiq --version
```

**Windows (PowerShell):**
```powershell
# Download
Invoke-WebRequest -Uri "https://github.com/AttackIQ/aiq-platform-api/releases/latest/download/aiq_VERSION_windows_amd64.zip" -OutFile aiq.zip

# Extract
Expand-Archive aiq.zip -DestinationPath .

# Add to PATH or move to a directory in PATH
```

#### Build from Source

Requires Go 1.22+:

```bash
go build -o aiq ./cmd/aiq
```

#### Install via Go

```bash
go install github.com/attackiq/aiq-cli/cmd/aiq@latest
```

### Usage

```bash
# List available commands
aiq --help

# List assessments
aiq assessments list

# Search assets
aiq assets search --query "hostname"

# Get scenario details
aiq scenarios get --scenario-id "abc123"
```

### Shell Completion

The CLI supports shell completion for bash, zsh, fish, and PowerShell.

#### Bash

**Current session:**
```bash
source <(aiq completion bash)
```

**Permanent installation:**
```bash
# Linux
aiq completion bash | sudo tee /etc/bash_completion.d/aiq

# macOS
aiq completion bash > $(brew --prefix)/etc/bash_completion.d/aiq
```

#### Zsh

**Current session:**
```bash
source <(aiq completion zsh)
```

**Permanent installation:**
```bash
# Add to ~/.zshrc
echo "source <(aiq completion zsh)" >> ~/.zshrc

# Or install to completions directory
aiq completion zsh > "${fpath[1]}/_aiq"
```

#### Fish

**Permanent installation:**
```bash
aiq completion fish | source

# Or save to completions directory
aiq completion fish > ~/.config/fish/completions/aiq.fish
```

#### PowerShell

**Current session:**
```powershell
aiq completion powershell | Out-String | Invoke-Expression
```

**Permanent installation:**
Add the following to your PowerShell profile:
```powershell
aiq completion powershell | Out-String | Invoke-Expression
```

## Contributing

We welcome feedback and contributions! For detailed contribution guidelines, please see [CONTRIBUTING.md](CONTRIBUTING.md).

Quick ways to contribute:
- Open issues for bugs or feature requests
- Submit pull requests
- Provide feedback on the API design

## License

MIT License - See LICENSE file for details