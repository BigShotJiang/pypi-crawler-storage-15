"""
core package for the Ultimate RVC project.

This package contains modules for managing date and settings as well as
generating audio using RVC based methods.

"""
