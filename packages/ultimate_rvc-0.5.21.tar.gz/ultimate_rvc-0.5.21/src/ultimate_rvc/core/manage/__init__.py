"""
Package which defines modules that facilitate managing settings and
data.
"""
