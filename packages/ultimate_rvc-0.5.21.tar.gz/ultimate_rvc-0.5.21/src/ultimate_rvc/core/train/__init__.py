"""
Package which exposes definitions facilitating the training of voice
conversion models.
"""
