from primalscheme3.cli import cli

if __name__ == "__main__":
    cli()
