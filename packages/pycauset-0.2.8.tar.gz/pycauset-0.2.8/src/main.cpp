#include <iostream>

int main() {
    std::cout << "pycauset Initialized" << std::endl;
    return 0;
}
