
`pycauset` provides efficient implementations for matrix operations, mirroring `numpy` semantics where appropriate but optimized for the specific matrix structures (e.g., triangular, bit-packed) used in causal analysis.

## Matrix Multiplication (`matmul`)

Matrix multiplication is performed using the [[pycauset.matmul]](A, B) function.

### Supported Types
Matrix multiplication is supported for all combinations of matrix types. The return type depends on the operands:

| Operand A | Operand B | Result Type |
| :--- | :--- | :--- |
| [[pycauset.FloatMatrix]] (Dense) | Any | [[pycauset.FloatMatrix]] |
| Any | [[pycauset.FloatMatrix]] (Dense) | [[pycauset.FloatMatrix]] |
| [[pycauset.TriangularFloatMatrix]] | Triangular (Any) | [[pycauset.TriangularFloatMatrix]] |
| Triangular (Any) | [[pycauset.TriangularFloatMatrix]] | [[pycauset.TriangularFloatMatrix]] |
| [[pycauset.IntegerMatrix]] | [[pycauset.IntegerMatrix]] or [[pycauset.TriangularBitMatrix]] | [[pycauset.IntegerMatrix]] |
| [[pycauset.TriangularBitMatrix]] | [[pycauset.IntegerMatrix]] | [[pycauset.IntegerMatrix]] |
| [[pycauset.TriangularBitMatrix]] | [[pycauset.TriangularBitMatrix]] | [[pycauset.IntegerMatrix]] |
| [[pycauset.DenseBitMatrix]] | [[pycauset.DenseBitMatrix]] | [[pycauset.IntegerMatrix]] |

**Note on [[pycauset.IntegerMatrix]]**: In `pycauset`, [[pycauset.IntegerMatrix]] is a **dense** matrix storing 32-bit integers. It is the standard return type for discrete matrix multiplications (like path counting).

### Syntax
```python
import pycauset as pc

# A and B can be of any supported type
C = pc.matmul(A, B)
```

### Return Value
See the table above. The system automatically promotes types to the most general required structure (Dense > TriangularFloat > Integer > Bit).

### Implementation Details
The implementation uses memory-mapped files to handle large matrices without loading them entirely into RAM.
- **Triangular Matrices**: Uses a row-addition algorithm that exploits the strictly upper triangular structure. For each row $i$ of $A$, it accumulates rows $k$ of $B$ where $A_{ik} \neq 0$.
- **Dense Matrices**: Uses a row-wise accumulation (IKJ) algorithm optimized for row-major storage.
- **Mixed Types**: When multiplying mixed types (e.g., [[pycauset.TriangularBitMatrix]] * [[pycauset.FloatMatrix]]), the operation is optimized to use the sparse structure of the triangular matrix while producing a dense result, avoiding full expansion of the sparse matrix before multiplication.
- **Scalar Multiplication**: Scalar factors are handled lazily and are correctly propagated during matrix multiplication ($C.scalar = A.scalar \times B.scalar$).

This approach ensures that operations are performed chunk-wise (row-wise), respecting memory constraints.

## Element-wise Multiplication

Element-wise multiplication is performed using the standard multiplication operator `*`.

### Syntax
```python
# A and B can be any matrix type (TriangularBitMatrix, TriangularFloatMatrix, etc.)
C = A * B
```

### Semantics
-   $C_{ij} = A_{ij} \times B_{ij}$
-   For [[pycauset.TriangularBitMatrix]], this is equivalent to a bitwise AND operation ($1 \times 1 = 1$, others $0$).
-   Returns a new matrix of the same type as the operands.

## Scalar Multiplication

Scalar multiplication is supported for all matrix types and is highly optimized.

### Syntax
```python
# A is any matrix
B = A * 5.0
C = 0.5 * A
```

### Lazy Evaluation
`pycauset` uses **lazy evaluation** for scalar multiplication:
-   The operation is $O(1)$.
-   It does **not** iterate over the matrix data.
-   Instead, it updates an internal `scalar` field in the matrix object.
-   When elements are accessed (e.g., via `get_element_as_double` or converted to numpy), the stored value is multiplied by this scalar on the fly.
-   If you perform `C = pc.matmul(A, B)`, the resulting matrix will inherit the product of the scalars: `C.scalar = A.scalar * B.scalar`.

## Vector-Matrix Multiplication

`pycauset` supports multiplication between matrices and vectors using the `@` operator.

*   **Matrix @ Vector**: `M @ v` returns a column vector ($M \times v$).
*   **Vector @ Matrix**: `v.T @ M` returns a row vector ($v^T \times M$).

See the [[Vector Guide#Transposition & Matrix Operations]] for more details on transposition and vector operations.