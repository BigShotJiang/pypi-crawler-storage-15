# pycauset.I

```python
class pycauset.I(n: int, backing_file: str = "")
```

Alias for [[pycauset.IdentityMatrix]].

## Usage

```python
# Create a 1000x1000 identity matrix
identity = pycauset.I(1000)
```
