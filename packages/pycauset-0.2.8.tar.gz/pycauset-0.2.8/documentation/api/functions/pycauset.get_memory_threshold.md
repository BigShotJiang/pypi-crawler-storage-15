# pycauset.get_memory_threshold

```python
pycauset.get_memory_threshold() -> int
```

Get the current memory threshold in bytes.

## Returns

*   **int**: The current threshold in bytes.
