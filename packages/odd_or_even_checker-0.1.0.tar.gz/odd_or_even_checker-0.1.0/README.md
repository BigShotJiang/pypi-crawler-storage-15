# odd-or-even-checker

A minimal Python package to check whether a number is odd or even.

## Installation
```
pip install odd-or-even-checker
```

## Usage
```python
from odd_or_even import check_number
print(check_number(10))  # even
print(check_number(7))   # odd
```
