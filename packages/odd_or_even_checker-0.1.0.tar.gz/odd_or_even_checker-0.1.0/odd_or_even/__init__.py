def check(n):
    if n % 2 == 0:
        return "even"
    else:
        return "odd"
