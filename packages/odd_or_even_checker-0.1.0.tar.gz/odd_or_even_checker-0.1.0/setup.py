from setuptools import setup, find_packages

setup(
    name="odd_or_even_checker",
    version="0.1.0",
    description="Simple odd-or-even checker package",
    author="Tony",
    packages=find_packages(),
    python_requires=">=3.6",
)
