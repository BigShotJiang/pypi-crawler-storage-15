import json


def bool_to_str(value: bool | None) -> str | None:
    """Convert a boolean value to a string representation."""
    if value is True:
        return "1"
    elif value is False:
        return "N"
    return None  # Return None for None


def ensure_json_string(data) -> str:
    """Convert data to JSON string, validating format."""
    if isinstance(data, dict):
        return json.dumps(data)
    elif isinstance(data, str):
        # Validate JSON string
        try:
            json.loads(data)
            return data
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON string: {e}")
    else:
        raise TypeError(f"Expected dict or str, got {type(data).__name__}")
