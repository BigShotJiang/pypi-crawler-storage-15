HUMAN = "human"
MACHINE = "machine"
