"""The lean workflow automation framework for machines with heart."""

from . import _version

__version__ = _version.version
VERSION = _version.version_tuple
