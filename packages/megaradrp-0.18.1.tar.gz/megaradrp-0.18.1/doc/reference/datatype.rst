==================================================================
:mod:`megaradrp.datatype` --- MEGARA types of data
==================================================================


.. automodule:: megaradrp.datatype
    :members:
    :undoc-members:

