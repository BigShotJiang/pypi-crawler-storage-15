
==================================================================
:mod:`megaradrp.ntypes` --- MEGARA data types
==================================================================

.. module:: megaradrp.ntypes
   :synopsis:  Data types
