
==================================================================
:mod:`megaradrp.processing` --- Processing functions
==================================================================

.. module:: megaradrp.processsing
   :synopsis:  Processing functions

================================================
:mod:`megaradrp.processing.wavecalibration` ---
================================================

.. automodule:: megaradrp.processing.wavecalibration
   :members:
