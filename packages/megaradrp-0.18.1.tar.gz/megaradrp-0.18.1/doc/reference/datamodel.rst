
==================================================================
:mod:`megaradrp.datamodel` --- MEGARA datamodel
==================================================================


.. automodule:: megaradrp.datamodel
    :members:
    :undoc-members:
