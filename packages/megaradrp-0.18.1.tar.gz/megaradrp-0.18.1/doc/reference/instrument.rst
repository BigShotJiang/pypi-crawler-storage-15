
====================================================
:mod:`megaradrp.instrument` --- Static configuration
====================================================

.. module:: megaradrp.instrument
   :synopsis:  Static configuration


.. automodule:: megaradrp.instrument.components
   :members:

.. automodule:: megaradrp.instrument.configs
   :members:

.. automodule:: megaradrp.instrument.focalplane
   :members:
