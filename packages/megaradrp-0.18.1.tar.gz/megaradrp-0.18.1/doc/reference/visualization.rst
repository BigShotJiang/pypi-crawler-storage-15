
==================================================================
:mod:`megaradrp.visualization` --- MEGARA visualization
==================================================================

.. module:: megaradrp.visualization
   :synopsis:  MEGARA visualization

.. autofunction::  megaradrp.visualization.hexplot