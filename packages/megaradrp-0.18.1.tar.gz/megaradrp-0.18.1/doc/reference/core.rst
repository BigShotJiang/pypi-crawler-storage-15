
:mod:`megaradrp.core` --- Base classes for processing
=====================================================

.. module:: megaradrp.core
   :synopsis:  Base classes


.. autoclass:: megaradrp.core.recipe.MegaraBaseRecipe
     :members:
     :inherited-members:
     :undoc-members:
