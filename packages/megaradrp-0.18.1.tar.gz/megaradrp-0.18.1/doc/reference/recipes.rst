
=========================================================
:mod:`megaradrp.recipes` --- Reduction Recipes for MEGARA
=========================================================

.. module:: megaradrp.recipes
   :synopsis:  Reduction Recipes for MEGARA
