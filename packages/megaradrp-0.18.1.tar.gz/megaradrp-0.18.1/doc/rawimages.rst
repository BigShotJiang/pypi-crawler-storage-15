
Raw Image data products
=======================

Readout modes
*************
TBD

Image types
***********
TBD

Bias
----

Dark
----

Flat
----

Object
------

