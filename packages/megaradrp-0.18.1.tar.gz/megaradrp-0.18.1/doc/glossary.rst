
.. _glossary:

Glossary 
=========

.. glossary::
   :sorted:

   observing mode
    One of the prescribed ways of observing with an instrument

   recipe
    A software object that processes the data obtained with
    a given observing mode of the instrument

   DRP
    Data Reduction Pipeline

   DFP
    Data Factory Pipeline

