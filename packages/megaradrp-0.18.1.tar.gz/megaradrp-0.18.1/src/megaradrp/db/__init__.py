


import megaradrp.db.model
import megaradrp.db.control  # noqa: F401


def load_db():
    print('load db')
