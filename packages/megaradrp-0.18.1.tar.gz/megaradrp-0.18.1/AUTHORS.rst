MEGARA Data Reduction Pipeline
==============================

Primary authors:

 * Sergio Pascual <sergiopr@fis.ucm.es>
 * Nicolas Cardiel <cardiel@fis.ucm.es>
 * Pablo Picazo <papicazo@ucm.es>
