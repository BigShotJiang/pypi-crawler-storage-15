"""
UCUP Plugin System

This package contains example plugins and utilities for extending UCUP.
"""

__version__ = "0.1.0"
