"""Core functionality for PyCharting."""
