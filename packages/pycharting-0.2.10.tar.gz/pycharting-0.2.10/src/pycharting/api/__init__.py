"""API endpoints for PyCharting."""
