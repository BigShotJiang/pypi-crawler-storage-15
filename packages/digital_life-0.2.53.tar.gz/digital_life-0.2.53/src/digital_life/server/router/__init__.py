from .biography import router as biography_router
from .chat import router as chat_router
from .digital_avatar import router as avatar_router
from .memorycard import router as memory_card_router
from .user import router as user_router
from .recommend import router as recommended_router
