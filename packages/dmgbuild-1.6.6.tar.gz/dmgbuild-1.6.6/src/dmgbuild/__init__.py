from .core import build_dmg

__version__ = "1.6.6"

__all__ = ["__version__", "build_dmg"]
