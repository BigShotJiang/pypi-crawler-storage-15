class NetworkException(Exception):
    pass


class ApiException(Exception):
    pass
