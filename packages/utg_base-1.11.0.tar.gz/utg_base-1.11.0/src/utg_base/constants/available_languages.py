AVAILABLE_LANGUAGES = [
    'uz',
    'ru',
    'crl'
]
