"""Tests for ragi package."""
