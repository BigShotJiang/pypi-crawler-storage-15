"""Version information for kittylog."""

__version__ = "2.11.0"
