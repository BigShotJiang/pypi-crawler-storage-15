# Copyright (C) [2025] Eduardo Antonio Ferrera Rodríguez
#
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation, either version 3 of the License, or any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY. See the COPYING file for more details.

# fonts.py
from typing import Optional
from pathlib import Path
import re

class CreateFont:
   
    
    def __init__(self, family: str, p: str = None, h1: str = None, h2: str = None, h3: str = None):
        self.css_path = Path("style.css")
        self.styles_to_insert = {}
        
        self.styles_to_insert['body'] = {'font-family': family}
        
        tag_map = {'p': p, 'h1': h1, 'h2': h2, 'h3': h3}
        for tag, size in tag_map.items():
            if size:
                if tag not in self.styles_to_insert:
                    self.styles_to_insert[tag] = {}
                self.styles_to_insert[tag]['font-size'] = size
                
        self.write()


    def _update_content(self, css_content: str, selector: str, properties: dict) -> str:
   
        pattern = re.compile(rf'({re.escape(selector)}\s*\{{)([^}}]*?)(\}})', re.DOTALL)
        
        new_properties_css = "".join([f"\n    {prop}: {value};" for prop, value in properties.items()])
        
        match = pattern.search(css_content)

        if match:
            start_block = match.group(1)
            inner_content = match.group(2).strip()
            end_block = match.group(3)
            if inner_content:
                new_inner_content = inner_content + new_properties_css + "\n"
            else:
                new_inner_content = new_properties_css.lstrip() 
            
            new_block = f"{start_block}{new_inner_content}{end_block}"
            
            return css_content.replace(match.group(0), new_block, 1)

        else:
            new_block = f"\n\n{selector} {{" + new_properties_css + "\n}"
            return css_content + new_block
            
    
    def write(self):
        
        try:
            if self.css_path.exists():
                with open(self.css_path, 'r', encoding='utf-8') as f:
                    content = f.read()
            else:
                content = ""
                
        except Exception as e:
            print(f"Error reading/accessing CSS file: {e}")
            return
            
        modified_content = content
        
        # Iterate through all configured selectors to update the content
        for selector, properties in self.styles_to_insert.items():
            modified_content = self._update_content(modified_content, selector, properties)
            
        # Write the modified content back to the file
        try:
            with open(self.css_path, 'w', encoding='utf-8') as f:
                f.write(modified_content.strip())
            print(f"Font styles applied successfully to {self.css_path}.")
        except Exception as e:
            print(f"Error writing to CSS file: {e}")






class HeaderFont(CreateFont):
    def __init__(self, family: Optional[str] = None, p: Optional[str] = None,
                 h1: Optional[str] = None, h2: Optional[str] = None, h3: Optional[str] = None):

        # Ensure at least one argument is provided
        if not any([family, p, h1, h2, h3]):
            raise TypeError("HeaderFont requires at least one argument: family, p, h1, h2, or h3.")

        # Call parent init to initialize base attributes (css_path, etc.)
        super().__init__(family="Arial")  # temporary dummy family, will override

        # Build actual selectors
        self.styles_to_insert = {}
        if family:
            self.styles_to_insert["header"] = {"font-family": family}

        tag_map = {"p": p, "h1": h1, "h2": h2, "h3": h3}
        for tag, size in tag_map.items():
            if size:
                self.styles_to_insert[f"header > {tag}"] = {"font-size": size}

        # Write styles using parent's method
        self.write()


class MainFont(CreateFont):
    def __init__(self, family: Optional[str] = None, p: Optional[str] = None,
                 h1: Optional[str] = None, h2: Optional[str] = None, h3: Optional[str] = None):

        if not any([family, p, h1, h2, h3]):
            raise TypeError("MainFont requires at least one argument: family, p, h1, h2, or h3.")

        # Initialize parent attributes
        super().__init__(family="Arial")  # dummy value

        # Build actual selectors
        self.styles_to_insert = {}
        if family:
            self.styles_to_insert["main"] = {"font-family": family}

        tag_map = {"p": p, "h1": h1, "h2": h2, "h3": h3}
        for tag, size in tag_map.items():
            if size:
                self.styles_to_insert[f"main > {tag}"] = {"font-size": size}

        self.write()


class FooterFont(CreateFont):
    def __init__(self, family: Optional[str] = None, p: Optional[str] = None,
                 h1: Optional[str] = None, h2: Optional[str] = None, h3: Optional[str] = None):

        if not any([family, p, h1, h2, h3]):
            raise TypeError("FooterFont requires at least one argument: family, p, h1, h2, or h3.")

        # Initialize parent attributes
        super().__init__(family="Arial")  # dummy value

        # Build actual selectors
        self.styles_to_insert = {}
        if family:
            self.styles_to_insert["footer"] = {"font-family": family}

        tag_map = {"p": p, "h1": h1, "h2": h2, "h3": h3}
        for tag, size in tag_map.items():
            if size:
                self.styles_to_insert[f"footer > {tag}"] = {"font-size": size}

        self.write()
