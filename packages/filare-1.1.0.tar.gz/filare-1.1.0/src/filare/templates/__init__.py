# Package marker for template assets shipped with Filare.
