from skyvern.forge.sdk.prompting import PromptEngine

# Initialize the prompt engine
prompt_engine = PromptEngine("skyvern")
