from skyvern.cli.commands import cli_app

if __name__ == "__main__":
    cli_app()  # type: ignore
