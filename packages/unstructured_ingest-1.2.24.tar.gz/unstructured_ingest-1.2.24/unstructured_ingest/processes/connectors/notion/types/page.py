# https://developers.notion.com/reference/page
from dataclasses import dataclass, fields
from typing import Optional

from unstructured_ingest.processes.connectors.notion.interfaces import FromJSONMixin
from unstructured_ingest.processes.connectors.notion.types.file import FileObject
from unstructured_ingest.processes.connectors.notion.types.parent import Parent
from unstructured_ingest.processes.connectors.notion.types.user import PartialUser


@dataclass
class Page(FromJSONMixin):
    id: str
    created_time: str
    created_by: PartialUser
    last_edited_time: str
    last_edited_by: PartialUser
    archived: bool
    in_trash: bool
    properties: dict
    parent: Parent
    url: str
    public_url: str
    request_id: Optional[str] = None
    object: str = "page"
    icon: Optional[FileObject] = None
    cover: Optional[FileObject] = None

    @classmethod
    def from_dict(cls, data: dict):
        data = data.copy()  # Don't modify the original
        created_by = data.pop("created_by")
        last_edited_by = data.pop("last_edited_by")
        icon = data.pop("icon")
        cover = data.pop("cover")
        parent = data.pop("parent")

        # Filter data to only include fields that exist in the dataclass
        filtered_data = {
            k: v for k, v in data.items() if k in {field.name for field in fields(cls)}
        }

        page = cls(
            created_by=PartialUser.from_dict(created_by),
            last_edited_by=PartialUser.from_dict(last_edited_by),
            icon=FileObject.from_dict(icon) if icon else None,
            cover=FileObject.from_dict(cover) if cover else None,
            parent=Parent.from_dict(parent),
            **filtered_data,
        )

        return page
