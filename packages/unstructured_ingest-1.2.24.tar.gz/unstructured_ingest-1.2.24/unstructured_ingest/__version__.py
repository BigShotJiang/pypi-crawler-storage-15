__version__ = "1.2.24"  # pragma: no cover
