VERSION = "0.3.11"

# this will be templated during the build
GIT_COMMIT = "7cffe54f8b960931055ae20f5983b4ea34515eff"
