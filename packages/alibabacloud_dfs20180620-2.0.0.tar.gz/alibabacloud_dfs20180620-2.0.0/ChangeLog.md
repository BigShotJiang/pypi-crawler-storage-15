2024-04-07 Version: 1.0.2
- Update API AttachVscMountPoint: update param InstanceIds.
- Update API CreateVscMountPoint: update param InstanceIds.
- Update API DetachVscMountPoint: update param InstanceIds.


2024-03-29 Version: 1.0.1
- Update API AttachVscMountPoint: update param InstanceIds.
- Update API AttachVscMountPoint: update param VscIds.
- Update API CreateUserGroupsMapping: update response param.
- Update API CreateVscMountPoint: update param InstanceIds.
- Update API DetachVscMountPoint: update param InstanceIds.
- Update API DetachVscMountPoint: update param VscIds.


2022-05-06 Version: 1.0.0
- Initial release.

