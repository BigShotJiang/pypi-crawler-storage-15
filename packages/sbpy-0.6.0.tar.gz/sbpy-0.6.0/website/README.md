# sbpy website

This website is hosted on firebase. 

# How to

## Initial setup
Requires: node.js

  1. `npm install -g firebase-tools`.
  
  2. `firebase login`.
  
## Update content

  1. Make changes.
  
  2. Test serving locally with `firebase serve`.
  
  3. Make changes...test...changes...test.
  
  4. Commit to repo.
  
  5. Deploy with `firebase deploy`.
