*************
API Reference
*************

sbpy.data
---------

Classes
^^^^^^^
.. automodsumm:: sbpy.data
   :classes-only:

..
   Functions
   ^^^^^^^^^
   .. automodsumm:: sbpy.data
      :functions-only:

   Variables
   ^^^^^^^^^
   .. automodsumm:: sbpy.data
      :variables-only:

      
sbpy.activity
-------------

Classes
^^^^^^^
.. automodsumm:: sbpy.activity
   :classes-only:

Functions
^^^^^^^^^
.. automodsumm:: sbpy.activity
   :functions-only:

..
   Variables
   ^^^^^^^^^
   .. automodsumm:: sbpy.activity
      :variables-only:


sbpy.photometry
---------------

Classes
^^^^^^^
.. automodsumm:: sbpy.photometry
   :classes-only:

Functions
^^^^^^^^^
.. automodsumm:: sbpy.photometry
   :functions-only:

Variables
^^^^^^^^^
.. automodsumm:: sbpy.photometry
   :variables-only:
      
      
sbpy.spectroscopy
-----------------

Classes
^^^^^^^
.. automodsumm:: sbpy.spectroscopy
   :classes-only:

..
   Functions
   ^^^^^^^^^
   .. automodsumm:: sbpy.spectroscopy
      :functions-only:

   Variables
   ^^^^^^^^^
   .. automodsumm:: sbpy.spectroscopy
      :variables-only:


sbpy.bib
--------

Classes
^^^^^^^
.. automodsumm:: sbpy.bib
   :classes-only:

Functions
^^^^^^^^^
.. automodsumm:: sbpy.bib
   :functions-only:

..
   Variables
   ^^^^^^^^^
   .. automodsumm:: sbpy.bib
      :variables-only:
   

sbpy.exceptions
---------------

Classes
^^^^^^^
.. automodsumm:: sbpy.exceptions
   :classes-only:

..
   Functions
   ^^^^^^^^^
   .. automodsumm:: sbpy.exceptions
      :functions-only:

   Variables
   ^^^^^^^^^
   .. automodsumm:: sbpy.exceptions
      :variables-only:


sbpy.units
----------

..
   Classes
   ^^^^^^^
   .. automodsumm:: sbpy.units
      :classes-only:

Functions
^^^^^^^^^
.. automodsumm:: sbpy.units
   :functions-only:

Variables
^^^^^^^^^
.. automodsumm:: sbpy.units
   :variables-only:

      
sbpy.utils
----------

..
   Classes
   ^^^^^^^
   .. automodsumm:: sbpy.utils
      :classes-only:

Functions
^^^^^^^^^
.. automodsumm:: sbpy.utils
   :functions-only:

..
   Variables
   ^^^^^^^^^
   .. automodsumm:: sbpy.utils
      :variables-only:

