Utilities Module (`sbpy.utils`)
===============================

Introduction
------------

`~sbpy.utils` provides common non-package specific utility functions.


Reference/API
-------------
.. automodapi:: sbpy.utils
    :no-heading:
