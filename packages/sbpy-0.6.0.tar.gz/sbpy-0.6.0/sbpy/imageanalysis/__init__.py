"""
SBPy Module for small image analysis
"""

from .core import *
