# Licensed under a 3-clause BSD style license - see LICENSE.rst

__all__ = ["zaa_fit"]

import numpy as np
from typing import Optional
from astropy.modeling import models, fitting


def zaa_fit(
    size: np.ndarray,
    x: np.ndarray,
    y: np.ndarray,
    *,
    x_unc: Optional[np.ndarray] = None,
    y_unc: Optional[np.ndarray] = None,
):
    """Extrapolate multi-aperture astrometry to a size of 0.

    The method assumes Cartesian geometry.


    Parameters
    ----------
    size : `~numpy.ndarray`
        Size of the aperture.  The measurement does not matter (e.g., radius
        versus diameter).

    x : `~numpy.ndarray`
        First astrometric coordinate.

    y : `~numpy.ndarray`
        Second astrometric coordinate.

    x_unc : `~numpy.ndarray`, optional
        Weight the x measurements by `x_unc**-2`.

    y_unc : `~numpy.ndarray`, optional
        Weight the y measurements by `y_unc**-2`.


    Returns
    -------
    x0 : float
        The x value for an aperture size of 0.

    y0 : float
        The y value for an aperture size of 0.

    x0_unc : float or ``None``
        The uncertainty on ``x0`` if ``x_unc`` was provided.

    y0_unc : float or ``None``
        The uncertainty on ``y0`` if ``y_unc`` was provided.

    """
