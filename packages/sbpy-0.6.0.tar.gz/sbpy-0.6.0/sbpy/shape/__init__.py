"""
SBPy Module for small body shapes
"""

from .core import *
