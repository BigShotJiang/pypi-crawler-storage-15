"""
SBPy Module for observation planning
"""

from .core import *
