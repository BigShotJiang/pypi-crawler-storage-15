Contributing to sbpy
====================

sbpy is a community project and so the community is invited to
contribute to the project by testing its functionality and providing
or modifying code. For details on how to contribute, we refer to the
[guidelines for
contributions](https://sbpy.readthedocs.io/en/latest/contributing.html).