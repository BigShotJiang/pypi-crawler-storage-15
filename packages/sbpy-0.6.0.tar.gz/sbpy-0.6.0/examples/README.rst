Example Gallery
===============

A variety of short examples show-casing the functionality of `sbpy`.

Activity
--------
* `Estimating coma continuum emission`_
* `Haser model`_




 .. _Estimating coma continuum emission: activity/estimating-coma-continuum.ipynb
 .. _Haser model: activity/haser-model.ipynb

 
 
