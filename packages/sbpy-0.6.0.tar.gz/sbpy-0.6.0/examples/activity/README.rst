activity
--------

Examples demonstrating the `activity` module.

