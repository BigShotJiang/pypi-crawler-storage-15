raise NotImplementedError("Faiss backend not implemented yet.")
