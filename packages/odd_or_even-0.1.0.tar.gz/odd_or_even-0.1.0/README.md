# Odd or Even

A simple Python library to check if a number is odd or even.

## Installation

You can install the library via pip:

```bash
pip install odd-or-even


#usage
from odd_or_even import is_odd, is_even

print(is_odd(5))  # True
print(is_even(10))  # True
