"""
GeoPFA modeling software.
"""
import numpy as np
np.seterr(all='ignore')
