"""
GeoPFA modeling software.
"""

import numpy as np

np.seterr(all="ignore")

from ._version import __version__
