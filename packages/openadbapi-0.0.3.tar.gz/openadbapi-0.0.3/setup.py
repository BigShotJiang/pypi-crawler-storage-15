import re
from pathlib import Path
from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
	long_description = fh.read() 

' read version '
def get_version():
	content = Path("src/openadbapi/__init__.py").read_text()
	return re.search(r'__version__ = "([^"]+)"', content).group(1)
	
setup(
	name='openadbapi',
	version=get_version(),
	author='Christian Schwatke',
	author_email='christian.schwatke@tum.de', 
	license="MIT",
	license_files=[], 
	packages=find_packages(where="src"),
	package_dir={"": "src"},
	url='https://gitlab.lrz.de/openadb/python3-openadbapi',
	description='OpenADB-API',
	long_description=long_description,
	long_description_content_type="text/markdown", 
	include_package_data=True,
	package_data={},
	install_requires=[],
	scripts=[]
)

