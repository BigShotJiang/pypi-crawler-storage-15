"""
Dango CLI module

Provides command-line interface for Dango data platform.
"""
