"""
Dango Templates Module

Contains Jinja2 templates for project generation.
"""
