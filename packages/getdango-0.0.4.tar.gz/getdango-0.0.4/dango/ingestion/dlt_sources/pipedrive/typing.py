from typing import List, Dict, Any


TDataPage = List[Dict[str, Any]]
