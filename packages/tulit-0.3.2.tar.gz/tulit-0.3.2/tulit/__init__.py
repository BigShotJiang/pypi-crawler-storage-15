"""
This package provides functions to send a SPARQL query to the SPARQL endpoint of the Publications Office of the European Union (CELLAR),
retrieve the results, and store them in a JSON file.
"""