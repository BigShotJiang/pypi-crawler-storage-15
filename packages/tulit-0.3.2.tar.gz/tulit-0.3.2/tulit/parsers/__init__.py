"""
This subpackage provides classes and functions to parse a given file and extract the text within it.
"""