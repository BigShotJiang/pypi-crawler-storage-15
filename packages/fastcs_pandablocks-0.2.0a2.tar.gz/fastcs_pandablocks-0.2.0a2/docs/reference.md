# Reference

Technical reference material including APIs and release notes.

```{toctree}
:maxdepth: 1
:glob:

API <_api/fastcs_pandablocks>
genindex
Release Notes <https://github.com/PandABlocks/fastcs-PandABlocks/releases>
```
