from sqlalchemy_utils import UUIDType

from zou.app import db
from zou.app.models.serializer import SerializerMixin
from zou.app.models.base import BaseMixin
from zou.app.utils import fields


class AttachmentFile(db.Model, BaseMixin, SerializerMixin):
    """
    Describes a file which is attached to a comment.
    """

    name = db.Column(db.String(250))
    size = db.Column(db.Integer(), default=1)
    extension = db.Column(db.String(6))
    mimetype = db.Column(db.String(255))
    comment_id = db.Column(
        UUIDType(binary=False),
        db.ForeignKey("comment.id"),
        index=True,
        nullable=True,
    )
    reply_id = db.Column(
        UUIDType(binary=False),
        nullable=True,
    )
    chat_message_id = db.Column(
        UUIDType(binary=False),
        db.ForeignKey("chat_message.id"),
        index=True,
        nullable=True,
    )

    def __repr__(self):
        return "<AttachmentFile %s>" % self.id

    def present(self):
        return fields.serialize_dict(
            {
                "id": self.id,
                "name": self.name,
                "extension": self.extension,
                "size": self.size,
            }
        )

    @classmethod
    def create_from_import(cls, data):
        data.pop("type", None)
        data.pop("comment", None)
        data.pop("chat_message", None)
        previous_data = cls.get(data["id"])
        if previous_data is None:
            return cls.create(**data)
        else:
            previous_data.update(data)
            return previous_data
