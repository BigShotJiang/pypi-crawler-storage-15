import apsw
import re, os
from nicegui import ui, app
from biblemategui import BIBLEMATEGUI_DATA


def resource_indexes(gui=None, bt=None, b=1, c=1, v=1, **_):

    # --- CONFIGURATION ---
    DB_FILE = os.path.join(BIBLEMATEGUI_DATA, 'indexes2.sqlite')

    # Define your tables, their display titles, and their icons
    TABLE_CONFIG = {
        "Bible People": {
            "table": "exlbp", 
            "icon": "groups"        # Icon for people/groups
        },
        "Bible Locations": {
            "table": "exlbl", 
            "icon": "place"         # Icon for maps/locations
        },
        "Bible Topics": {
            "table": "exlbt", 
            "icon": "category"      # Icon for topics/categories
        },
        "Dictionaries": {
            "table": "dictionaries", 
            "icon": "menu_book"     # Icon for definitions/books
        },
        "Encyclopedia": {
            "table": "encyclopedia", 
            "icon": "local_library" # Icon for deep knowledge/library
        }
    }

    def fetch_data(table_name: str, book_id: int, chapter: int, verse: int):
        """
        Connects to SQLite and retrieves information for the specific verse.
        """
        try:
            with apsw.Connection(DB_FILE) as connection:
                cursor = connection.cursor()
                query = f"SELECT Information FROM {table_name} WHERE Book=? AND Chapter=? AND Verse=?"
                cursor.execute(query, (book_id, chapter, verse))
                rows = cursor.fetchall()
                return "\n\n".join([row[0] for row in rows]) if rows else None
        except Exception as e:
            return f"Error querying database: {str(e)}"

    # --- UI LAYOUT ---
    with ui.column().classes('w-full max-w-3xl mx-auto p-4 gap-6'):
        
        '''# Header
        with ui.row().classes('items-center gap-2'):
            ui.icon('auto_stories', size='3em', color='primary')
            ui.label('BibleMate AI Resource Index').classes('text-3xl font-bold text-slate-700')

        # Search Area
        with ui.card().classes('w-full p-6 bg-slate-50'):
            ui.label('Search a Verse').classes('text-sm font-bold text-slate-500 uppercase')
            
            with ui.row().classes('w-full items-start gap-2'):
                ref_input = ui.input(placeholder='e.g. John 3:16') \
                    .classes('w-full text-lg') \
                    .props('outlined clearable') \
                    .on('keydown.enter', lambda: search_action())
                
                search_btn = ui.button(icon='search', on_click=lambda: search_action()) \
                    .classes('h-14 aspect-square')'''

        # Results Container
        results_container = ui.column().classes('w-full gap-4')

    async def search_action(book_id, chapter, verse):
        """
        Orchestrates the search logic: 
        1. Validate input
        2. Clear previous results
        3. Query DB
        4. Render Expansion panels
        """
        #query_text = ref_input.value
        #parsed = parse_reference(query_text)
        
        if not parsed:
            ui.notify('Invalid format. Use "Book Chapter:Verse" (e.g., John 3:16)', type='warning')
            return

        book_id, chapter, verse = parsed
        
        # Clear UI and show loading spinner
        results_container.clear()
        
        with results_container:
            spinner = ui.spinner('dots', size='lg').classes('self-center')
            
            # Run IO-bound DB operations
            results = {}
            for title, config in TABLE_CONFIG.items():
                data = await run.io_bound(fetch_data, config['table'], book_id, chapter, verse)
                results[title] = data

            spinner.delete()
            
            ui.label(f"Resources for {query_text.title()}") \
                .classes('text-xl font-semibold text-slate-600 mb-2')

            # --- RENDER EXPANSIONS ---
            found_any = False
            
            for title, config in TABLE_CONFIG.items():
                content = results.get(title)
                
                # Check if this should be open by default
                is_open = (title == "Bible Topics")
                
                # Create the Expansion with specific icon
                with ui.expansion(title, icon=config['icon'], value=is_open) \
                        .classes('w-full bg-white border rounded-lg shadow-sm') \
                        .props('header-class="font-bold text-lg text-primary"'):
                    
                    if content:
                        ui.html(content, sanitize=False).classes('p-4 text-slate-800')
                        found_any = True
                    else:
                        ui.label('No entries found for this category.') \
                            .classes('p-4 text-slate-400 italic')

            if not found_any:
                ui.notify('No data found in any index for this verse.', type='info')
        
    search_action(43,3,16)
