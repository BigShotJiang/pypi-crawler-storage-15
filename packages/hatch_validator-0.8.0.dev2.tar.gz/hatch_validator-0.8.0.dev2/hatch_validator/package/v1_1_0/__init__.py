"""Schema validators and resolvers for version 1.1.0.

This package contains the concrete implementations of schema validators
and dependency resolvers specific to schema version 1.1.0.
"""
