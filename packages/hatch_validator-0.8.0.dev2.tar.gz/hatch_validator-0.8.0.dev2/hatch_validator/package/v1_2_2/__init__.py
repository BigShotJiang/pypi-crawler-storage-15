"""Schema validation package for v1.2.2.

This package contains the validator and strategies for schema version 1.2.2,
which introduces conda package manager support for Python dependencies.
"""

