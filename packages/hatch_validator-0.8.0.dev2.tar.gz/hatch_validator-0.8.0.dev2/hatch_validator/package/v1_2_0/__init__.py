"""Schema validation package for v1.2.0.

This package contains the validator and strategies for schema version 1.2.0.
"""
