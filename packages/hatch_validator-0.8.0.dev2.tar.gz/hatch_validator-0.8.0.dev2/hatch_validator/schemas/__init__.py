"""Schema-related utilities and version-specific validators.

This package contains schema handling utilities and the version-specific
validation implementations organized by schema version.
"""
