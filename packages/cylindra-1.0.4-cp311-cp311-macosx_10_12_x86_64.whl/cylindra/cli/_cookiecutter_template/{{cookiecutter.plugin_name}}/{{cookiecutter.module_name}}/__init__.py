from .core import my_plugin_function

__version__ = "0.1.0"
__all__ = ["my_plugin_function"]
