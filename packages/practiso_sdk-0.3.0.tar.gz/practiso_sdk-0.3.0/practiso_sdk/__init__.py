def google():
    import practiso_sdk.google as g
    return g