# univi/models/__init__.py

from .univi import UniVIMultiModalVAE

__all__ = ["UniVIMultiModalVAE"]
