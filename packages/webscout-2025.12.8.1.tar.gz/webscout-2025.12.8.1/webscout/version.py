__version__ = "2025.12.8.1"
__prog__ = "webscout"
