# This file marks the directory as a Python package.
# Static imports for all AISEARCH provider modules

# Provider implementations
from webscout.Provider.AISEARCH.PERPLEXED_search import PERPLEXED
from webscout.Provider.AISEARCH.Perplexity import Perplexity
from webscout.Provider.AISEARCH.genspark_search import Genspark
from webscout.Provider.AISEARCH.iask_search import IAsk
from webscout.Provider.AISEARCH.monica_search import Monica
from webscout.Provider.AISEARCH.stellar_search import Stellar
from webscout.Provider.AISEARCH.webpilotai_search import webpilotai

# List of all exported names
__all__ = [
    "PERPLEXED",
    "Perplexity",
    "Genspark",
    "IAsk",
    "Monica",
    "Stellar",
    "webpilotai",
]
