# This file marks the directory as a Python package.
# Static imports for all Provider modules
from webscout.Provider.ai4chat import AI4Chat
from webscout.Provider.akashgpt import AkashGPT
from webscout.Provider.Algion import Algion
from webscout.Provider.Andi import AndiSearch
from webscout.Provider.Apriel import Apriel
from webscout.Provider.cerebras import Cerebras
from webscout.Provider.ChatGPTClone import ChatGPTClone
from webscout.Provider.ChatSandbox import ChatSandbox
from webscout.Provider.ClaudeOnline import ClaudeOnline
from webscout.Provider.cleeai import Cleeai
from webscout.Provider.Cohere import Cohere
from webscout.Provider.DeepAI import DeepAI
from webscout.Provider.Deepinfra import DeepInfra
from webscout.Provider.elmo import Elmo
from webscout.Provider.ExaAI import ExaAI
from webscout.Provider.ExaChat import ExaChat
from webscout.Provider.Flowith import Flowith
from webscout.Provider.Gemini import GEMINI
from webscout.Provider.geminiapi import GEMINIAPI
from webscout.Provider.GeminiProxy import GeminiProxy
from webscout.Provider.GithubChat import GithubChat
from webscout.Provider.Gradient import Gradient
from webscout.Provider.Groq import GROQ
from webscout.Provider.HeckAI import HeckAI
from webscout.Provider.IBM import IBM
from webscout.Provider.Jadve import JadveOpenAI
from webscout.Provider.julius import Julius
from webscout.Provider.K2Think import K2Think
from webscout.Provider.Koboldai import KOBOLDAI
from webscout.Provider.learnfastai import LearnFast
from webscout.Provider.llama3mitril import Llama3Mitril
from webscout.Provider.llmchat import LLMChat
from webscout.Provider.llmchatco import LLMChatCo
from webscout.Provider.meta import Meta
from webscout.Provider.Nemotron import NEMOTRON
from webscout.Provider.Netwrck import Netwrck
from webscout.Provider.oivscode import oivscode
from webscout.Provider.Openai import OPENAI
from webscout.Provider.OpenGPT import OpenGPT
from webscout.Provider.Perplexitylabs import PerplexityLabs
from webscout.Provider.PI import PiAI
from webscout.Provider.QwenLM import QwenLM
from webscout.Provider.Sambanova import Sambanova
from webscout.Provider.searchchat import SearchChatAI
from webscout.Provider.sonus import SonusAI
from webscout.Provider.TeachAnything import TeachAnything
from webscout.Provider.TextPollinationsAI import TextPollinationsAI
from webscout.Provider.TogetherAI import TogetherAI
from webscout.Provider.toolbaz import Toolbaz
from webscout.Provider.turboseek import TurboSeek
from webscout.Provider.TwoAI import TwoAI
from webscout.Provider.typefully import TypefullyAI
from webscout.Provider.TypliAI import TypliAI
from webscout.Provider.Venice import Venice
from webscout.Provider.VercelAI import VercelAI
from webscout.Provider.WiseCat import WiseCat
from webscout.Provider.WrDoChat import WrDoChat
from webscout.Provider.x0gpt import X0GPT
from webscout.Provider.yep import YEPCHAT

# List of all exported names
__all__ = [
    "OPENAI",
    "AI4Chat",
    "AkashGPT",
    "Algion",
    "AndiSearch",
    "Apriel",
    "Cerebras",
    "ChatGPTClone",
    "ChatSandbox",
    "ClaudeOnline",
    "Cleeai",
    "Cohere",
    "DeepAI",
    "DeepInfra",
    "Elmo",
    "ExaAI",
    "ExaChat",
    "Flowith",
    "GEMINI",
    "GEMINIAPI",
    "GeminiProxy",
    "GithubChat",
    "Gradient",
    "GROQ",
    "HeckAI",
    "IBM",
    "JadveOpenAI",
    "Julius",
    "K2Think",
    "KOBOLDAI",
    "LearnFast",
    "Llama3Mitril",
    "LLMChat",
    "LLMChatCo",
    "Meta",
    "NEMOTRON",
    "Netwrck",
    "oivscode",
    "OpenGPT",
    "PerplexityLabs",
    "PiAI",
    "QwenLM",
    "Sambanova",
    "SearchChatAI",
    "SonusAI",
    "TeachAnything",
    "TextPollinationsAI",
    "TogetherAI",
    "Toolbaz",
    "TurboSeek",
    "TwoAI",
    "TypefullyAI",
    "TypliAI",
    "Venice",
    "VercelAI",
    "WiseCat",
    "WrDoChat",
    "X0GPT",
    "YEPCHAT",
]
