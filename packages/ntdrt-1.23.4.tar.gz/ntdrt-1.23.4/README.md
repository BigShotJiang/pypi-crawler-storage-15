My own utils
