# tests/test_smarttimer.py

from io import StringIO
from smarttimer import time_block, benchmark, measure, compare, TimingContext, profile_memory


def test_time_block_prints_output():
    buf = StringIO()

    with time_block("test-block", output=buf):
        x = sum(range(1000))

    out = buf.getvalue()
    assert "test-block" in out
    assert "smarttimer" in out
    assert "took" in out


def test_benchmark_decorator():
    buf = StringIO()

    @benchmark(output=buf)
    def add(a, b):
        return a + b

    result = add(2, 3)
    assert result == 5

    out = buf.getvalue()
    assert "add took" in out


def test_measure_repeats_and_returns():
    buf = StringIO()

    def inc(x):
        return x + 1

    result, total = measure(inc, 1, repeats=5, output=buf)
    assert result == 2
    assert total > 0

    out = buf.getvalue()
    assert "ran 5x" in out


def test_timing_context():
    with TimingContext() as timer:
        sum(range(1000))
    
    assert timer.elapsed is not None
    assert timer.elapsed > 0


def test_compare_functions():
    def func1():
        return sum(range(100))
    
    def func2():
        return sum(i for i in range(100))
    
    results = compare(func1, func2, repeats=3)
    assert len(results) == 2
    assert "func1" in results
    assert "func2" in results
    assert "mean" in results["func1"]


def test_measure_with_warmup():
    buf = StringIO()
    
    def simple_func():
        return sum(range(10))
    
    result, total = measure(simple_func, repeats=3, warmup=1, output=buf)
    assert result == 45
    assert total > 0