def smart_ass():
    print("(_E=MC2_)")