def tight_ass():
    print("(!)")