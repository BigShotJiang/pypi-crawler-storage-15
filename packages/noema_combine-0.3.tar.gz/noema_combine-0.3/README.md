# NOEMA_Combine
Python functions to handle NOEMA and 30-m data.

It includes functions to process stand-alone 30-m and NOEMA data, as well as, functions to prepare 30-m data for combination with NOEMA.


Credits
-------
-------

This is developed by:
* Jaime E Pineda ([@jpinedaf](http://github.com/jpinedaf))
