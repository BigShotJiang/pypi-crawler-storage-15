# edu_difficulty_rank

`edu_difficulty_rank` is a Python library for **scientific difficulty estimation** and
**skill profiling** of educational questions.

It:

- Analyses question text (from plain text or later from PDFs).
- Computes a **difficulty level** from 1–10 using an explicit mathematical rubric.
- Assigns a **skill profile**:
  - memory
  - numerical
  - reasoning
  - language
- Is designed to act as a **gatekeeper** around AI APIs, allowing only questions
  in a desired difficulty band to be used in quizzes or exams.

## Quick example (planned API)

```python
from edu_difficulty_rank import DifficultyScorer

scorer = DifficultyScorer(subject="math", grade=9)

question = "A particle starts from rest and moves with constant acceleration..."
profile = scorer.score(question)

print(profile.level)           # integer 1–10
print(profile.skills.reasoning)
print(profile.skills.numerical)

