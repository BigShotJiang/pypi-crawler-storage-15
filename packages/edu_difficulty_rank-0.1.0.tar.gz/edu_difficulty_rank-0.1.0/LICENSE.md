# edu_difficulty_rank License

Copyright (c) 2025, Nilanjan Panda

All rights reserved.

## 1. Grant of Permission (Non-Commercial Use)

You are allowed to use, copy, and modify this software **for personal,
research, and academic purposes only**, without any fee, provided that:

- This copyright notice and the text of this license are included in all
  copies or substantial portions of the software.
- Any research output (papers, reports, theses, presentations) that makes
  substantial use of this library must acknowledge:

  > "This work uses the `edu_difficulty_rank` library by Nilanjan Panda."

## 2. Commercial Use

Any use of this software for **commercial purposes** (including but not
limited to paid products, SaaS platforms, commercial tutoring systems,
or internal tools used to generate revenue) **requires a separate written
agreement** with the author:

- Contact: `npanda@iitb.ac.in`

Without such an agreement, commercial use is **not permitted**.

## 3. No Warranty

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT.
IN NO EVENT SHALL THE AUTHOR OR COPYRIGHT HOLDER BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR
THE USE OR OTHER DEALINGS IN THE SOFTWARE.

## 4. No Liability for Generated Content

If this software is used together with large language models (LLMs) to
generate questions or educational content, the author is not responsible
for:

- the correctness, safety, or fairness of generated content,
- any educational, psychological, or legal consequences arising from the
  use of such content.

The responsibility for reviewing and validating all generated material
lies entirely with the user.

