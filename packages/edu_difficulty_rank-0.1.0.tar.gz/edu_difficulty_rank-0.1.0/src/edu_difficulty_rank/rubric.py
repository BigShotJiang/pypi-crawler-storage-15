from __future__ import annotations
from dataclasses import dataclass
from typing import Dict
import math


def _sigmoid(x: float) -> float:
    """Logistic function σ(x) = 1 / (1 + e^{-x})."""
    return 1.0 / (1.0 + math.exp(-x))


@dataclass
class DifficultyRubric:
    """
    Mathematical rubric mapping normalized features -> difficulty in [1, 10].

    Features (all expected in [0, 1]):

        len_norm            : normalized question length (tokens)
        math_density        : density of math symbols / digits
        reasoning_markers   : presence of reasoning words ("why", "explain", etc.)
        memory_markers      : presence of recall words ("define", "state", etc.)
        negation_flag       : 0/1 if tricky negation appears ("NOT", "EXCEPT")
        steps_estimate      : estimated conceptual steps
        language_complexity : proxy for reading complexity

    We compute:

        z = w · x + b
        difficulty_cont = 1 + 9 * σ(z)

    and then:

        level = round(difficulty_cont)
    """

    # weights – initial hand-tuned values, later can be learned from data
    w_len: float = 0.8
    w_math: float = 1.1
    w_reasoning: float = 1.4
    w_memory: float = -0.4
    w_negation: float = 0.6
    w_steps: float = 1.3
    w_lang: float = 0.7
    bias: float = -1.0

    def difficulty_from_features(self, feats: Dict[str, float]) -> float:
        x_len = feats.get("len_norm", 0.0)
        x_math = feats.get("math_density", 0.0)
        x_reason = feats.get("reasoning_markers", 0.0)
        x_mem = feats.get("memory_markers", 0.0)
        x_neg = feats.get("negation_flag", 0.0)
        x_steps = feats.get("steps_estimate", 0.0)
        x_lang = feats.get("language_complexity", 0.0)

        z = (
            self.w_len * x_len
            + self.w_math * x_math
            + self.w_reasoning * x_reason
            + self.w_memory * x_mem
            + self.w_negation * x_neg
            + self.w_steps * x_steps
            + self.w_lang * x_lang
            + self.bias
        )

        d_cont = 1.0 + 9.0 * _sigmoid(z)
        # clamp numerically into [1, 10]
        if d_cont < 1.0:
            d_cont = 1.0
        if d_cont > 10.0:
            d_cont = 10.0
        return float(d_cont)

    def level_from_features(self, feats: Dict[str, float]) -> int:
        d_cont = self.difficulty_from_features(feats)
        level = int(round(d_cont))
        if level < 1:
            level = 1
        if level > 10:
            level = 10
        return level


@dataclass
class SkillRubric:
    """
    Maps features -> 4 skill scores in [0, 1]:

        memory     ~ recall & definition load
        numerical  ~ numeric / symbolic manipulation
        reasoning  ~ logical / multi-step thinking
        language   ~ reading / phrasing complexity

    Each is σ(w · x + b) with interpretable coefficients, so this can later
    be fitted to labeled data.
    """

    # memory
    mem_w_memory: float = 1.3
    mem_w_reasoning: float = -0.3
    mem_w_len: float = 0.2
    mem_bias: float = -0.1

    # numerical
    num_w_math: float = 1.5
    num_w_steps: float = 0.8
    num_w_reasoning: float = 0.3
    num_bias: float = -0.2

    # reasoning
    rea_w_reasoning: float = 1.6
    rea_w_steps: float = 0.9
    rea_w_negation: float = 0.4
    rea_bias: float = -0.3

    # language
    lan_w_lang: float = 1.4
    lan_w_len: float = 0.5
    lan_w_negation: float = 0.2
    lan_bias: float = -0.4

    def skills_from_features(self, feats: Dict[str, float]) -> Dict[str, float]:
        x_len = feats.get("len_norm", 0.0)
        x_math = feats.get("math_density", 0.0)
        x_reason = feats.get("reasoning_markers", 0.0)
        x_mem = feats.get("memory_markers", 0.0)
        x_neg = feats.get("negation_flag", 0.0)
        x_steps = feats.get("steps_estimate", 0.0)
        x_lang = feats.get("language_complexity", 0.0)

        # memory: recall + length, reduced if heavily reasoning based
        z_mem = (
            self.mem_w_memory * x_mem
            + self.mem_w_len * x_len
            + self.mem_w_reasoning * x_reason
            + self.mem_bias
        )
        memory = _sigmoid(z_mem)

        # numerical: math density + steps + some reasoning
        z_num = (
            self.num_w_math * x_math
            + self.num_w_steps * x_steps
            + self.num_w_reasoning * x_reason
            + self.num_bias
        )
        numerical = _sigmoid(z_num)

        # reasoning: reasoning markers + steps + negation
        z_rea = (
            self.rea_w_reasoning * x_reason
            + self.rea_w_steps * x_steps
            + self.rea_w_negation * x_neg
            + self.rea_bias
        )
        reasoning = _sigmoid(z_rea)

        # language: complexity + length + negation
        z_lan = (
            self.lan_w_lang * x_lang
            + self.lan_w_len * x_len
            + self.lan_w_negation * x_neg
            + self.lan_bias
        )
        language = _sigmoid(z_lan)

        return {
            "memory": float(memory),
            "numerical": float(numerical),
            "reasoning": float(reasoning),
            "language": float(language),
        }

