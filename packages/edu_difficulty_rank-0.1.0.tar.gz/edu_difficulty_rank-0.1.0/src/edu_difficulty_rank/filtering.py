from __future__ import annotations
from typing import Iterable, List, Tuple

from .difficulty_scorer import DifficultyScorer
from .target_profile import TargetProfile
from .schemas import QuestionProfile


def filter_questions(
    questions: Iterable[str],
    scorer: DifficultyScorer,
    target: TargetProfile,
) -> List[Tuple[str, QuestionProfile]]:
    """
    Score each question and return only those that match the target profile.

    Returns a list of (question_text, profile) pairs.
    """
    results: List[Tuple[str, QuestionProfile]] = []

    for q in questions:
        q = q.strip()
        if not q:
            continue
        profile = scorer.score(q)
        if target.matches(profile):
            results.append((q, profile))

    return results

