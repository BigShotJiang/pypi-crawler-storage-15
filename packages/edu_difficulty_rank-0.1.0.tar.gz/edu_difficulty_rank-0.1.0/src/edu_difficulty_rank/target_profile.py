from __future__ import annotations
from dataclasses import dataclass
from typing import Tuple, Optional

from .schemas import QuestionProfile


Range = Tuple[float, float]


def _clamp_range(r: Optional[Range], lo: float = 0.0, hi: float = 1.0) -> Optional[Range]:
    if r is None:
        return None
    a, b = r
    a = max(lo, min(hi, a))
    b = max(lo, min(hi, b))
    if a > b:
        a, b = b, a
    return (a, b)


@dataclass
class TargetProfile:
    """
    Desired difficulty and skill band for a question.

    level_min, level_max : integer range in [1, 10]
    Each skill can be constrained by a continuous range [0, 1].
      If a skill_*_range is None, it is not constrained.
    """

    level_min: int = 1
    level_max: int = 10

    memory_range: Optional[Range] = None
    numerical_range: Optional[Range] = None
    reasoning_range: Optional[Range] = None
    language_range: Optional[Range] = None

    def __post_init__(self) -> None:
        if self.level_min < 1:
            self.level_min = 1
        if self.level_max > 10:
            self.level_max = 10
        if self.level_min > self.level_max:
            self.level_min, self.level_max = self.level_max, self.level_min

        self.memory_range = _clamp_range(self.memory_range)
        self.numerical_range = _clamp_range(self.numerical_range)
        self.reasoning_range = _clamp_range(self.reasoning_range)
        self.language_range = _clamp_range(self.language_range)

    def _in_range(self, value: float, r: Optional[Range]) -> bool:
        if r is None:
            return True
        a, b = r
        return (value >= a) and (value <= b)

    def matches(self, profile: QuestionProfile) -> bool:
        """
        Check if a given QuestionProfile satisfies this target.
        """
        if profile.level < self.level_min or profile.level > self.level_max:
            return False

        s = profile.skills

        if not self._in_range(s.memory, self.memory_range):
            return False
        if not self._in_range(s.numerical, self.numerical_range):
            return False
        if not self._in_range(s.reasoning, self.reasoning_range):
            return False
        if not self._in_range(s.language, self.language_range):
            return False

        return True

