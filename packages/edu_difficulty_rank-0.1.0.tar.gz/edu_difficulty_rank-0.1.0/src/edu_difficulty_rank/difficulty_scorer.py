from __future__ import annotations
from typing import Dict, Optional

from .feature_extractor import FeatureExtractor
from .rubric import DifficultyRubric, SkillRubric
from .schemas import SkillProfile, QuestionProfile


class DifficultyScorer:
    """
    High-level scorer: given question text, return a QuestionProfile.

    This class connects:
        text -> features -> difficulty + skills

    It is fully deterministic given the current rubrics. Later you can
    replace the rubrics with learned parameters or IRT-based models.
    """

    def __init__(
        self,
        subject: str = "generic",
        grade: Optional[int] = None,
        feature_extractor: Optional[FeatureExtractor] = None,
        difficulty_rubric: Optional[DifficultyRubric] = None,
        skill_rubric: Optional[SkillRubric] = None,
    ):
        self.subject = subject
        self.grade = grade
        self.fe = feature_extractor or FeatureExtractor()
        self.d_rubric = difficulty_rubric or DifficultyRubric()
        self.s_rubric = skill_rubric or SkillRubric()

    def score(self, question_text: str, meta: Optional[Dict] = None) -> QuestionProfile:
        """
        Compute the QuestionProfile for the given question text.
        """
        feats = self.fe.extract(question_text)
        d_cont = self.d_rubric.difficulty_from_features(feats)
        level = self.d_rubric.level_from_features(feats)

        skill_scores = self.s_rubric.skills_from_features(feats)
        skills = SkillProfile(
            memory=skill_scores["memory"],
            numerical=skill_scores["numerical"],
            reasoning=skill_scores["reasoning"],
            language=skill_scores["language"],
        )

        return QuestionProfile(
            level=level,
            difficulty_cont=d_cont,
            skills=skills,
            raw_features=feats,
            meta=meta or {},
        )

