from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any, Optional


@dataclass
class SkillProfile:
    """
    Continuous skill scores in [0, 1] for each dimension.
    """
    memory: float
    numerical: float
    reasoning: float
    language: float


@dataclass
class QuestionProfile:
    """
    Full profile of a question: difficulty level + skills + raw features.
    """
    level: int                  # integer 1–10
    difficulty_cont: float      # continuous difficulty in [1, 10]
    skills: SkillProfile
    raw_features: Dict[str, float]
    meta: Optional[Dict[str, Any]] = None

