from __future__ import annotations
from typing import List, Optional
import pdfplumber
import regex as re


def extract_text_from_pdf(path: str, max_pages: Optional[int] = None) -> str:
    """
    Extract plain text from a PDF file.

    Parameters
    ----------
    path : str
        Path to the PDF file.
    max_pages : Optional[int]
        If given, only the first `max_pages` pages are read.

    Returns
    -------
    str
        Concatenated text of selected pages.
    """
    chunks: List[str] = []
    with pdfplumber.open(path) as pdf:
        n_pages = len(pdf.pages)
        limit = n_pages if max_pages is None else min(max_pages, n_pages)
        for i in range(limit):
            page = pdf.pages[i]
            text = page.extract_text() or ""
            chunks.append(text)

    return "\n\n".join(chunks)


class PDFQuestionExtractor:
    """
    Very simple PDF question extractor.

    For now:
      - we extract all text,
      - compress whitespace,
      - split on '?' (end-of-question heuristic),
      - filter out very short fragments.

    Later, you can extend this to:
      - detect MCQ options (A), (B), (C), etc.
      - separate examples vs exercises,
      - per-chapter extraction.
    """

    def __init__(
        self,
        min_chars: int = 20,
        max_pages: Optional[int] = None,
    ):
        self.min_chars = min_chars
        self.max_pages = max_pages

    def extract_questions(self, path: str) -> List[str]:
        raw = extract_text_from_pdf(path, max_pages=self.max_pages)
        # Replace newlines by spaces for easier splitting
        text = re.sub(r"\s+", " ", raw).strip()

        if not text:
            return []

        # naive split on '?'
        parts = text.split("?")
        questions: List[str] = []
        for part in parts:
            candidate = part.strip()
            if len(candidate) < self.min_chars:
                continue
            # add the '?' back as it is part of the question
            questions.append(candidate + "?")

        return questions

