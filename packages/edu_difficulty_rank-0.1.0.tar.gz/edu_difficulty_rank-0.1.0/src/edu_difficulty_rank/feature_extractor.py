from __future__ import annotations
from typing import Dict, List
import regex as re


_REASONING_WORDS = [
    "why", "explain", "justify", "prove", "show that", "reason", "infer",
    "conclude", "hence", "therefore", "deduce",
]

_MEMORY_WORDS = [
    "define", "state", "list", "name", "write", "mention", "what is",
]

_NEGATION_PATTERNS = [
    r"\bNOT\b", r"\bEXCEPT\b", r"\bincorrect\b", r"\bfalse\b", r"\bNOT TRUE\b",
]

# digits and common math symbols
_MATH_CHARS = r"0-9\+\-\*/=<>√πΣθ∑∞∫%°"


class FeatureExtractor:
    """
    Extract numerical features from a question string.

    All outputs are roughly normalized to [0, 1]. Later, scaling can be
    replaced by data-driven calibration.
    """

    def __init__(self, max_tokens: int = 80, max_steps: int = 6):
        self.max_tokens = max_tokens
        self.max_steps = max_steps

    def _tokenize(self, text: str) -> List[str]:
        text = re.sub(r"\s+", " ", text.strip())
        if not text:
            return []
        return text.split(" ")

    def _count_reasoning_markers(self, text: str) -> int:
        lower = text.lower()
        count = 0
        for w in _REASONING_WORDS:
            if w in lower:
                count += 1
        return count

    def _count_memory_markers(self, text: str) -> int:
        lower = text.lower()
        count = 0
        for w in _MEMORY_WORDS:
            if w in lower:
                count += 1
        return count

    def _negation_flag(self, text: str) -> int:
        upper = text.upper()
        for pat in _NEGATION_PATTERNS:
            if re.search(pat, upper):
                return 1
        return 0

    def _math_density(self, text: str) -> float:
        if not text:
            return 0.0
        math_chars = re.findall(f"[{_MATH_CHARS}]", text)
        return len(math_chars) / float(len(text))

    def _language_complexity(self, text: str) -> float:
        """
        Simple proxy: combine mean token length and type-token ratio.
        """
        tokens = self._tokenize(text)
        if not tokens:
            return 0.0

        lengths = [len(t) for t in tokens]
        mean_len = sum(lengths) / float(len(lengths))

        vocab_size = len(set(tokens))
        ttr = vocab_size / float(len(tokens))  # type-token ratio in (0,1]

        # normalize mean_len relative to [3, 10]
        mean_len_norm = (mean_len - 3.0) / (10.0 - 3.0)
        if mean_len_norm < 0.0:
            mean_len_norm = 0.0
        if mean_len_norm > 1.0:
            mean_len_norm = 1.0

        return 0.5 * mean_len_norm + 0.5 * ttr

    def _estimate_steps(self, text: str) -> float:
        """
        Heuristic: connectors like 'and then', 'hence', 'first', etc. -> more steps.
        """
        lower = text.lower()
        connectors = [
            "and then", "then", "after that", "hence", "therefore",
            "first", "second", "finally", "steps", "using", "based on",
        ]
        count = 0
        for c in connectors:
            if c in lower:
                count += 1
        steps = 1 + count  # at least one step
        steps_norm = steps / float(self.max_steps)
        if steps_norm > 1.0:
            steps_norm = 1.0
        return steps_norm

    def extract(self, text: str) -> Dict[str, float]:
        tokens = self._tokenize(text)
        n_tokens = len(tokens)
        if n_tokens == 0:
            len_norm = 0.0
        else:
            len_norm = n_tokens / float(self.max_tokens)
            if len_norm > 1.0:
                len_norm = 1.0

        reasoning_count = self._count_reasoning_markers(text)
        memory_count = self._count_memory_markers(text)

        reasoning_markers = reasoning_count / 3.0
        if reasoning_markers > 1.0:
            reasoning_markers = 1.0

        memory_markers = memory_count / 3.0
        if memory_markers > 1.0:
            memory_markers = 1.0

        neg_flag = float(self._negation_flag(text))
        math_density = self._math_density(text)
        lang_complexity = self._language_complexity(text)
        steps_estimate = self._estimate_steps(text)

        return {
            "len_norm": float(len_norm),
            "math_density": float(math_density),
            "reasoning_markers": float(reasoning_markers),
            "memory_markers": float(memory_markers),
            "negation_flag": float(neg_flag),
            "language_complexity": float(lang_complexity),
            "steps_estimate": float(steps_estimate),
        }

