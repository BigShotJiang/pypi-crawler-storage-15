from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, List, Optional, Dict, Any
import json

from .difficulty_scorer import DifficultyScorer
from .target_profile import TargetProfile
from .pdf_loader import extract_text_from_pdf


# LLMClient: takes a prompt string and returns a raw text response (e.g. JSON string)
LLMClient = Callable[[str], str]


@dataclass
class GenerationConfig:
    """
    Configuration for question generation.

    Attributes
    ----------
    model_name : str
        For your own logging / debugging only.
    max_attempts : int
        Maximum number of LLM calls per generate_from_pdf() call.
        This is a hard cap on token cost.
    n_candidates_per_call : int
        Ask the LLM to return this many candidate questions per call.
    max_context_chars : int
        Maximum number of characters of PDF text to include in the prompt.
    """

    model_name: str = "unknown-model"
    max_attempts: int = 2
    n_candidates_per_call: int = 5
    max_context_chars: int = 4000


class QuestionGenerator:
    """
    Question generator that respects a TargetProfile.

    Pipeline:
      - reads context from a PDF,
      - builds a strict prompt including:
          * difficulty rubric (1–10),
          * skill dimensions,
          * target difficulty & skill bands,
          * JSON-only output format,
      - calls an injected LLM client (OpenAI/Gemini wrapper that YOU provide),
      - parses the returned JSON,
      - scores each question locally using DifficultyScorer (scientific rubric),
      - accepts only those that satisfy TargetProfile.

    This class is API-agnostic: it does not know about OpenAI, Gemini, etc.
    You pass a callable:  llm_client(prompt: str) -> str
    """

    def __init__(
        self,
        llm_client: LLMClient,
        scorer: DifficultyScorer,
        config: Optional[GenerationConfig] = None,
    ):
        self.llm_client = llm_client
        self.scorer = scorer
        self.config = config or GenerationConfig()

    def _build_prompt(
        self,
        context_text: str,
        target: TargetProfile,
        n_candidates: int,
    ) -> str:
        """
        Build a strict instruction prompt for the LLM.

        We explicitly define:
          - difficulty levels 1–10,
          - skill dimensions,
          - the target bands,
          - output format (JSON array only).
        """

        # Truncate context to avoid huge tokens
        if len(context_text) > self.config.max_context_chars:
            context_text = context_text[: self.config.max_context_chars]

        target_desc = {
            "level_min": target.level_min,
            "level_max": target.level_max,
            "memory_range": target.memory_range,
            "numerical_range": target.numerical_range,
            "reasoning_range": target.reasoning_range,
            "language_range": target.language_range,
        }

        rubric_text = """
You are an expert question-setter and psychometrics researcher.

We use a 1–10 difficulty scale:

1–2 : Direct factual recall, single-step, no reasoning.
3–4 : Simple application of a single formula or definition.
5–6 : Multi-step reasoning or combination of 2 ideas, moderate complexity.
7–8 : Non-obvious insight, comparison, or tricky conceptual twist, several steps.
9–10: Very challenging, almost olympiad-level, deep multi-step reasoning.

Skills (scored in [0,1]):

- memory: how much the question depends on recalling precise definitions or facts.
- numerical: how much numeric / algebraic manipulation is required.
- reasoning: how much logical multi-step or conceptual reasoning is required.
- language: how complex the wording and reading load is.

You must:
1. Read the provided CONTEXT text (from a chapter PDF).
2. Create well-posed questions that can be answered using ONLY this context
   and standard prior knowledge for the specified grade.
3. For each question, internally estimate its difficulty level (1–10)
   and its skill profile (memory, numerical, reasoning, language in [0,1]).
4. You MUST adjust or discard any question that does not fall inside the
   requested difficulty and skill bands, and only output questions that you
   believe match the target.

Output format:
- Return ONLY a valid JSON array of objects, with no extra commentary.
- Each object has keys:
    "question"        : string
    "estimated_level" : integer 1–10
    "skills"          : object with keys "memory", "numerical",
                        "reasoning", "language" all in [0,1].
"""

        prompt = f"""
CONTEXT (from PDF):
\"\"\"{context_text}\"\"\"

TARGET PROFILE (approximate bands):
{json.dumps(target_desc, indent=2)}

TASK:
Generate {n_candidates} candidate questions that:
  - are based on the CONTEXT,
  - approximately satisfy the TARGET PROFILE.

Return ONLY a valid JSON array, like:

[
  {{
    "question": "...",
    "estimated_level": 5,
    "skills": {{
      "memory": 0.3,
      "numerical": 0.8,
      "reasoning": 0.6,
      "language": 0.4
    }}
  }},
  ...
]

Do not include any text before or after the JSON.

{rubric_text}
"""
        return prompt

    def generate_from_pdf(
        self,
        pdf_path: str,
        target: TargetProfile,
        n_questions: int = 1,
        max_pages: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        """
        Generate questions from a PDF that satisfy the target profile.

        Returns
        -------
        List[Dict[str, Any]]
            Each dict has:
              - "question_text": str
              - "profile": QuestionProfile (local scientific scoring)
              - "llm_metadata": dict with keys "estimated_level", "skills" (from LLM)
        """
        context_text = extract_text_from_pdf(pdf_path, max_pages=max_pages)
        if not context_text.strip():
            raise ValueError(f"No text extracted from PDF: {pdf_path}")

        accepted: List[Dict[str, Any]] = []
        attempts = 0

        while len(accepted) < n_questions and attempts < self.config.max_attempts:
            attempts += 1
            prompt = self._build_prompt(
                context_text=context_text,
                target=target,
                n_candidates=self.config.n_candidates_per_call,
            )

            raw = self.llm_client(prompt)

            # Try to parse JSON
            try:
                data = json.loads(raw)
            except json.JSONDecodeError:
                # LLM did not return valid JSON; skip this attempt
                continue

            if not isinstance(data, list):
                continue

            for obj in data:
                if not isinstance(obj, dict):
                    continue
                q_text = obj.get("question", "").strip()
                if not q_text:
                    continue

                # Local scoring using our deterministic rubric
                profile = self.scorer.score(q_text)

                # Check scientifically if it matches the target
                if target.matches(profile):
                    accepted.append(
                        {
                            "question_text": q_text,
                            "profile": profile,
                            "llm_metadata": {
                                "estimated_level": obj.get("estimated_level", None),
                                "skills": obj.get("skills", None),
                            },
                        }
                    )
                    if len(accepted) >= n_questions:
                        break

        return accepted

