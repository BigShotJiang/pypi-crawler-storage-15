from __future__ import annotations
import argparse
import sys

from .difficulty_scorer import DifficultyScorer


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="edu-diff-score",
        description="Score educational questions for difficulty and skill profile.",
    )
    parser.add_argument(
        "question",
        nargs="?",
        help="Question text to score. If omitted, read from stdin.",
    )
    parser.add_argument(
        "--subject",
        default="generic",
        help="Subject name (e.g. physics, math, chemistry). Default: generic.",
    )
    parser.add_argument(
        "--grade",
        type=int,
        default=None,
        help="Grade / class level (e.g. 8, 9, 10, 11, 12). Optional.",
    )

    args = parser.parse_args(argv)

    if args.question:
        question_text = args.question
    else:
        # Read from stdin if no positional argument
        data = sys.stdin.read().strip()
        if not data:
            print("No question provided. Pass as argument or via stdin.", file=sys.stderr)
            return 1
        question_text = data

    scorer = DifficultyScorer(subject=args.subject, grade=args.grade)
    profile = scorer.score(question_text)

    print("Question:")
    print(question_text)
    print()
    print(f"Subject: {args.subject}  Grade: {args.grade}")
    print(f"Level (1–10): {profile.level:.0f}")
    print(f"Continuous difficulty: {profile.difficulty_cont:.2f}")
    print()
    print("Skills (0–1):")
    print(f"  memory    : {profile.skills.memory:.2f}")
    print(f"  numerical : {profile.skills.numerical:.2f}")
    print(f"  reasoning : {profile.skills.reasoning:.2f}")
    print(f"  language  : {profile.skills.language:.2f}")
    print()
    print("Raw features:")
    for k, v in profile.raw_features.items():
        print(f"  {k:20s} = {v:.3f}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())

