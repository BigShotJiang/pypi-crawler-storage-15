from edu_difficulty_rank import (
    DifficultyScorer,
    TargetProfile,
    filter_questions,
    FeatureExtractor,
)


def test_feature_extractor_basic():
    fe = FeatureExtractor()
    text = "Define kinetic energy and write its SI unit."
    feats = fe.extract(text)

    # All expected keys present
    for key in [
        "len_norm",
        "math_density",
        "reasoning_markers",
        "memory_markers",
        "negation_flag",
        "language_complexity",
        "steps_estimate",
    ]:
        assert key in feats

    # Values are in [0,1] or 0/1 where appropriate
    assert 0.0 <= feats["len_norm"] <= 1.0
    assert 0.0 <= feats["math_density"] <= 1.0
    assert 0.0 <= feats["reasoning_markers"] <= 1.0
    assert 0.0 <= feats["memory_markers"] <= 1.0
    assert feats["negation_flag"] in (0.0, 1.0)
    assert 0.0 <= feats["language_complexity"] <= 1.0
    assert 0.0 <= feats["steps_estimate"] <= 1.0


def test_difficulty_ordering():
    scorer = DifficultyScorer()

    q_easy = "Define kinetic energy and write its SI unit."
    q_medium = (
        "A particle starts from rest and moves with constant acceleration. "
        "After 5 s it has travelled 40 m. Calculate its acceleration and final velocity."
    )
    q_reasoning = (
        "A car and a truck start from the same point. The car moves with uniform speed "
        "while the truck accelerates. Explain which vehicle will be ahead after a long time and why."
    )

    p_easy = scorer.score(q_easy)
    p_med = scorer.score(q_medium)
    p_reason = scorer.score(q_reasoning)

    # Sanity: reasoning question should not be easier than pure definition
    assert p_reason.difficulty_cont >= p_easy.difficulty_cont

    # Medium numeric question should be between them or close
    assert p_med.difficulty_cont >= p_easy.difficulty_cont - 1.0
    assert p_med.difficulty_cont <= p_reason.difficulty_cont + 1.0


def test_target_profile_filtering():
    scorer = DifficultyScorer()

    questions = [
        "Define kinetic energy and write its SI unit.",
        "A particle starts from rest and moves with constant acceleration. "
        "After 5 s it has travelled 40 m. Calculate its acceleration and final velocity.",
        "A car and a truck start from the same point. The car moves with uniform speed "
        "while the truck accelerates. Explain which vehicle will be ahead after a long time and why.",
    ]

    target = TargetProfile(
        level_min=5,
        level_max=8,
        reasoning_range=(0.6, 1.0),
    )

    matched = filter_questions(questions, scorer, target)

    # At least one question should satisfy high reasoning target
    assert len(matched) >= 1

    # All matched questions should have reasoning >= 0.6
    for _, profile in matched:
        assert 0.6 <= profile.skills.reasoning <= 1.0
        assert target.level_min <= profile.level <= target.level_max

