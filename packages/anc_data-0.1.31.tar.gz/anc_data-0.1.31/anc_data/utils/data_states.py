class EndOfIteration:
    pass
