def add(a: int, b: int) -> int:
    """Return sum of a and b."""
    print("Hello from awesome_tatsu_math!")
    return a + b
