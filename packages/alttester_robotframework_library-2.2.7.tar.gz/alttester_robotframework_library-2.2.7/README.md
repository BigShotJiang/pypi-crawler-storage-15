# AltTesterLibrary for Robot Framework


## Installation

AltTesterLibrary can be installed using `pip` - http://pip-installer.org:

    `pip install alttester-robotframework-library`

You can also install it from the source distribution by running:

    `python setup.py install`


## Usage

Import the library:

    *** Settings ***
    Library          AltTesterLibrary
