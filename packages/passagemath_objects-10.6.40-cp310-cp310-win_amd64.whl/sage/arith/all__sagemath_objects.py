# sage_setup: distribution = sagemath-objects
# The presence of this file ensures that sage_setup for sagemath-objects
# considers this directory as a namespace package

from sage.arith.power import generic_power as power
