"""Tests for multi-agentic examples."""

