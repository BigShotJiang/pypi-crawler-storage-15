"""Test suite for synqed-samples examples."""

