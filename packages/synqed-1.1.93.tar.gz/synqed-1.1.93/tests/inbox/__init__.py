"""
Tests for inbox-based multi-agent messaging system.
"""

