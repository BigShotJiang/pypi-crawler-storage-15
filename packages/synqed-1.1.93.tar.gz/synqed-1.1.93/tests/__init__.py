"""
Test suite for Synqed.
"""

