"""Command handlers for CLI commands.

Each handler encapsulates the CLI parsing and execution logic for a specific command.
"""
