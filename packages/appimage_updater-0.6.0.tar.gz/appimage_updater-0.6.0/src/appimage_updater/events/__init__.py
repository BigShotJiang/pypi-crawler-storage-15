"""Event system for progress reporting and notifications."""
