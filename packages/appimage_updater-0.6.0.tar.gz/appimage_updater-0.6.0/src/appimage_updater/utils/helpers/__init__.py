"""Helper classes for complex operations."""
