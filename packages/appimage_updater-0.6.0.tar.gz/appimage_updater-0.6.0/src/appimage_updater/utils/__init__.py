"""Utility modules for AppImage Updater.

This package contains:
- logging_config: Logging configuration and setup
- version_utils: Version comparison and parsing utilities
- helpers/: Various helper utilities
"""
