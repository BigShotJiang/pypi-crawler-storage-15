"""AppImage updater package."""
