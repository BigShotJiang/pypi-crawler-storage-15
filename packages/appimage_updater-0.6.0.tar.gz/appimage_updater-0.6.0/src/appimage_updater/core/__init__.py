"""Core business logic modules.

This package contains the core business logic for AppImage Updater including
downloading, version checking, system information, and data models.
"""
