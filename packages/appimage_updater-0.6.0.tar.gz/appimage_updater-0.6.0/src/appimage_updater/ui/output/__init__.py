"""Output system for AppImage Updater.

This module provides a pluggable output system with support for multiple formats
including Rich console output, plain text, JSON, and HTML.
"""
