"""Service layer for AppImage Updater business logic."""
