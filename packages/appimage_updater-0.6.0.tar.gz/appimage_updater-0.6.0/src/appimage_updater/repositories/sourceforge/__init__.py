"""SourceForge repository support for AppImage Updater."""
