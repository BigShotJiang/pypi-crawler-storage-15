"""GitHub integration modules.

This package contains all GitHub-related functionality including
authentication, API client, and repository implementation.
"""
