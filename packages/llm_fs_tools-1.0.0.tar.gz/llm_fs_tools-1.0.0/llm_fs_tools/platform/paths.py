"""
Platform-specific path handling.
"""
