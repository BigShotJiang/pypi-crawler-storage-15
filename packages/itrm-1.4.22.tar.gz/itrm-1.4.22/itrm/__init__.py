from itrm.itrm import *
from itrm.itrm import __doc__
