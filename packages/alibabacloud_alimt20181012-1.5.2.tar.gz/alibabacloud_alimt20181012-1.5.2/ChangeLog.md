2025-07-16 Version: 1.5.1
- Generated python 2018-10-12 for alimt.

2025-05-08 Version: 1.5.0
- Support API GetDetectLanguageVpc.


2025-01-17 Version: 1.4.0
- Support API TranslateSearch.
- Update API Translate: update param SourceText.
- Update API TranslateImage: update response param.


2024-06-06 Version: 1.3.0
- Support API GetBatchTranslateByVPC.
- Support API TranslateGeneralVpc.


2024-06-06 Version: 1.2.2
- Update API GetDetectLanguage: update response param.
- Update API TranslateECommerce: update response param.


2023-10-20 Version: 1.2.1
- Generated python 2018-10-12 for alimt.

2023-08-12 Version: 1.2.0
- Generated python 2018-10-12 for alimt.

2023-07-12 Version: 1.1.1
sdk增加字段

2023-04-11 Version: 1.1.0
- Add image batch translate API.

2023-04-11 Version: 1.0.4
- Update Core .

2022-10-14 Version: 1.0.3
- Generated python 2018-10-12 for alimt.

2021-11-15 Version: 1.0.2
- Add Ext parameter to image translation API.

2021-05-18 Version: 1.0.1
- Generated python 2018-10-12 for alimt.

2020-12-29 Version: 1.0.0
- AMP Version Change.

