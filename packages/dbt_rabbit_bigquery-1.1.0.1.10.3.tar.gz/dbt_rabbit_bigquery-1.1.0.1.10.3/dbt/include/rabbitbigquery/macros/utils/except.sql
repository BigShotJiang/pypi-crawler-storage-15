{% macro rabbitbigquery__except() %}

    except distinct

{% endmacro %}
