{% macro rabbitbigquery__intersect() %}

    intersect distinct

{% endmacro %}
