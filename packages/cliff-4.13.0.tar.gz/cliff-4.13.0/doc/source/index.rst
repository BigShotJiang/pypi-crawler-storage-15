=======================================================
 cliff -- Command Line Interface Formulation Framework
=======================================================

cliff is a framework for building command line programs. It uses
plugins to define sub-commands, output formatters, and other
extensions.

.. toctree::
   :maxdepth: 2

   install/index
   user/index
   reference/index
   contributors/index


.. rubric:: Indices and tables

* :ref:`genindex`
* :ref:`search`
