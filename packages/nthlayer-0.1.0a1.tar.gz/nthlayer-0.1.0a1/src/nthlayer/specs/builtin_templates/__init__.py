"""Built-in service templates for NthLayer."""
