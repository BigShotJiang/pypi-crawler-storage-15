"""Huxly 2.0 � Professional PC Utility with AI-Powered Notifications"""
__version__ = "2.0.0"
__author__ = "Tyora Inc."
__email__ = "support@tyora.io"
__company__ = "Tyora"

