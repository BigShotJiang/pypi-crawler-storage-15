from setuptools import setup, find_packages

setup(
    name="eshopbox-sdk",
    packages=find_packages(),
    python_requires=">=3.8",
)
