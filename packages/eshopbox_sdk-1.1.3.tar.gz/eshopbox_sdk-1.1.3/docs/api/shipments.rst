Shipments API
=============

.. module:: eshopbox.api.shipments

Overview
--------

The ``ShipmentsAPI`` module manages shipment creation, tracking, and labels.

.. autoclass:: eshopbox.api.shipments.ShipmentsAPI
   :members:
   :undoc-members:
   :show-inheritance:
