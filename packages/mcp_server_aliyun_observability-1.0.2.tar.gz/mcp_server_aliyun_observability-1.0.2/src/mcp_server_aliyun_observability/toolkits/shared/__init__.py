"""
Shared toolkits for PaaS and DoAI layers

This module contains tools that are shared between PaaS and DoAI layers,
but not needed by the IaaS layer.
"""