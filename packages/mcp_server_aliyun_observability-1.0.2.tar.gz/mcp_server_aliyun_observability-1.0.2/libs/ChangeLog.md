2025-04-01 Version: 1.1.5
- Generated python 2015-04-01 for Sts.

2023-10-11 Version: 1.1.4
- Generated python 2015-04-01 for Sts.

2023-03-02 Version: 1.1.3
- Publish AssumeRole API With ExternalId Parameter.

2022-09-05 Version: 1.1.2
- Generated python 2015-04-01 for Sts.

2022-03-26 Version: 1.1.1
- Generated python 2015-04-01 for Sts.

2021-09-29 Version: 1.1.0
- Supported AssumeRoleWithOIDC.

2021-07-27 Version: 1.0.1
- Generated python 2015-04-01 for Sts.

2020-12-30 Version: 1.0.0
- AMP Version Change.

2020-12-30 Version: 1.0.0
- AMP Version Change.

