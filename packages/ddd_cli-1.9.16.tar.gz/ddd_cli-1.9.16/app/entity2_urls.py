
from django.urls import path

from . import entity2_views

app_name = "app"

urlpatterns = [

    path('', entity2_views.entity2_list, name="index"),  # ← Esta es la URL por defecto    
    path('entity2-list/', entity2_views.entity2_list, name="entity2_list"),
    path('entity2-create/', entity2_views.entity2_create, name="entity2_create"),
    path('entity2-edit/<int:id>', entity2_views.entity2_edit, name="entity2_edit"),
    path('entity2-detail/<int:id>', entity2_views.entity2_detail, name="entity2_detail"),
    path('entity2-delete/<int:id>', entity2_views.entity2_delete, name="entity2_delete"),    

]
