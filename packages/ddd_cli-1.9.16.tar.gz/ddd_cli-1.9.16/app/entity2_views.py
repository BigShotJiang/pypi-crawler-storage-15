
from django.shortcuts import render, redirect
from django.contrib import messages
from django.http import HttpResponse
from .utils.filter_dict import clean_dict_of_keys

# importa las excepciones personalizadas
from .domain.entity2_exceptions import (
    Entity2ValueError,
    Entity2ValidationError,
    Entity2AlreadyExistsError,
    Entity2NotFoundError,
    Entity2OperationNotAllowedError,
    Entity2PermissionError
)

# importa las excepciones de repositorio
from .infrastructure.exceptions import (
    ConnectionDataBaseError,
    RepositoryError
)

# Importar formularios específicos de la entidad
from app.entity2_forms import (
    Entity2CreateForm, 
    Entity2EditGetForm, 
    Entity2EditPostForm, 
    Entity2ViewForm
)

# Importar servicios específicos del dominio
from app.services.entity2_service import Entity2Service


def entity2_list(request):
    """
    Vista genérica para mostrar una lista de todas las instancias de entity2.
    """

    entity2List = [] #inicialize list

    # Obtener la lista del repositorio
    try:
        entity2List = Entity2Service().list()

    except (Entity2ValueError) as e:
        messages.error(request,  str(e))
    except (ConnectionDataBaseError, RepositoryError) as e:
        messages.error(request, "There was an error accessing the database or repository: " + str(e))
    except Exception as e:
        messages.error(request, "An unexpected error occurred: " + str(e))

    # Renderizar la plantilla con la lista
    return render(request, 'app/entity2_web_list.html', {
        'entity2List': entity2List
    })


def entity2_count_all(request):
    """
    Vista genérica para contar todas las instancias de entity2.
    """

    count = 0

    # Obtener el conteo del repositorio
    try:
        count = Entity2Service().count_all()

    except (Entity2ValueError) as e:
        messages.error(request,  str(e))
    except (ConnectionDataBaseError, RepositoryError) as e:
        messages.error(request, "There was an error accessing the database or repository: " + str(e))
    except Exception as e:
        messages.error(request, "An unexpected error occurred: " + str(e))

    # Retornar el conteo como respuesta HTTP
    return HttpResponse(f"Total entity2 count: {count}")


def entity2_create(request):
    """
    Vista genérica para crear una nueva instancia de entity2 utilizando un servicio.
    """

    if request.method == "POST":

        # Validar los datos del formulario
        form = Entity2CreateForm(request.POST, request.FILES)

        if form.is_valid():
            try:        
                form_data = form.cleaned_data

                # Obtener el ID de la entidad relacionada si existe
                external_id = request.POST.get('external_id', None)

                # Obtener la lista de ids de externals seleccionadas
                externals_ids = form_data.get('externals', [])

                # LLamar al servicio de creación
                Entity2Service().create(data=form_data, external_id=external_id, externals=externals_ids)

                # Mostrar mensaje de éxito y redirigir
                messages.success(request, f"Successfully created entity2")
                return redirect('app:entity2_list')

            except Entity2AlreadyExistsError as e:
                messages.error(request, "Already Exists Error: " + str(e))
            except (Entity2ValueError, Entity2ValidationError) as e:
                form.add_error(None, "Validation Error: " + str(e))
            except (ConnectionDataBaseError, RepositoryError) as e:
                messages.error(request, "There was an error accessing the database or repository: " + str(e))
            except Exception as e:
                messages.error(request, "An unexpected error occurred: " + str(e))
        else:
            messages.error(request, "There were errors in the form. Please correct them")

    # request.method == "GET":
    else:
        # Formulario vacío para solicitudes GET
        form = Entity2CreateForm()

    # Renderizar la plantilla con el formulario
    return render(request, 'app/entity2_web_create.html', {'form': form}) 


def entity2_edit(request, id=None):
    """
    Vista genérica para editar una instancia existente de entity2 utilizando un servicio.
    """

    if id is None:
        # Redireccion si no se proporciona un ID
        return redirect('app:entity2_list')

    try:
        # Obtener los datos de la entidad desde el servicio
        entity2 = Entity2Service().retrieve(entity_id=id)

    except Entity2NotFoundError as e:
        messages.error(request,  "Not Found Error: " + str(e))
        return redirect('app:entity2_list')
    except Entity2ValueError as e:
        messages.error(request,  "Value Error: " + str(e))
        return redirect('app:entity2_list')
    except (ConnectionDataBaseError, RepositoryError) as e:
        messages.error(request, "There was an error accessing the database or repository: " + str(e))
        return redirect('app:entity2_list')
    except Exception as e:
        messages.error(request, "An unexpected error occurred: " + str(e))
        return redirect('app:entity2_list')

    if request.method == "POST":

        # Validar los datos del formulario
        form = Entity2EditPostForm(request.POST, request.FILES)

        if form.is_valid():
            try:
                form_data = form.cleaned_data            
                
                # obtenemos del request los campos especiales del formulario
                # ejemplo: password = request.POST.get('password', None)
                # ejemplo: photo = request.FILES.get('photo', None)
                # y los enviamos como parametros al servicio de actualizacion

                # Obtener el ID de la entidad relacionada si existe
                external_id = request.POST.get('external_id', None)

                # Obtener la lista de ids de externals seleccionadas
                externals_ids = form_data.get('externals', [])         
                
                # Limpiar los campos no actualizables del diccionario de datos
                form_data = clean_dict_of_keys(form_data, keys=Entity2EditPostForm.ENTITY_NOT_UPDATABLE_FIELDS)

                # LLamar al servicio de actualización
                Entity2Service().update(entity_id=id, data=form_data, external_id=external_id, externals=externals_ids)

                # Mostrar mensaje de éxito
                messages.success(request, f"Successfully updated entity2")

                # Redireccionar a la lista de entity2s
                return redirect('app:entity2_list')

            except Entity2NotFoundError as e:
                messages.error(request,  "Not Found Error: " + str(e))                
            except (Entity2ValueError, Entity2ValidationError) as e:
                form.add_error(None, "Validation Error: " + str(e))
            except (ConnectionDataBaseError, RepositoryError) as e:
                messages.error(request, "There was an error accessing the database or repository: " + str(e))
            except Exception as e:
                messages.error(request, "An unexpected error occurred: " + str(e))

        else:
            messages.error(request, "There were errors in the form. Please correct them")

    # request.method == "GET":
    else:  
        # Initialize the form with existing data
        form = Entity2EditGetForm(initial={
            'id': entity2.get('id'),
            'attributeName': entity2.get('attributeName'),
            'attributeEmail': entity2.get('attributeEmail')
        })

    # Renderizar la plantilla con el formulario
    return render(request, 'app/entity2_web_edit.html', {'form': form})


def entity2_detail(request, id=None):
    """
    Vista genérica para mostrar los detalles de una instancia específica de entity2.
    """
    if id is None:
        return redirect('app:entity2_list')

    try:
        # Obtener los datos de la entidad desde el servicio
        entity2 = Entity2Service().retrieve(entity_id=id)

    except Entity2NotFoundError as e:
        messages.error(request,  "Not Found Error: " + str(e))        
        return redirect('app:entity2_list')
    except Entity2ValueError as e:
        messages.error(request,  str(e))
        return redirect('app:entity2_list')
    except (ConnectionDataBaseError, RepositoryError) as e:
        messages.error(request, "There was an error accessing the database or repository: " + str(e))
        return redirect('app:entity2_list')
    except Exception as e:
        messages.error(request, "An unexpected error occurred: " + str(e))
        return redirect('app:entity2_list')

    # Renderizar la plantilla con el formulario de vista
    form = Entity2ViewForm(initial={
        'attributeName': entity2.get('attributeName'),
        'attributeEmail': entity2.get('attributeEmail')
    })

    return render(request, 'app/entity2_web_detail.html', {'form': form})


def entity2_delete(request, id=None):
    """
    Vista genérica para eliminar una instancia existente de entity2 utilizando un servicio.
    """
    if id is None:
        messages.error(request, "Non Valid id to delete")
        return redirect('app:entity2_list')

    try:
        # LLamar al servicio de eliminación
        Entity2Service().delete(entity_id=id)
        messages.success(request, f"Successfully deleted entity2")

    except Entity2NotFoundError as e:
        messages.error(request,  "Not Found Error: " + str(e))             
    except (Entity2ValueError, Entity2ValidationError) as e:
        messages.error(request,  "Validation Error: " + str(e))
    except (ConnectionDataBaseError, RepositoryError) as e:
        messages.error(request, "There was an error accessing the database or repository: " + str(e))
    except Exception as e:
        messages.error(request, "An unexpected error occurred: " + str(e))

    return redirect('app:entity2_list')

