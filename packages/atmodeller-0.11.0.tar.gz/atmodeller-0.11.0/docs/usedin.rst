.. _UsedInFile:

Used In
=======

If you use *Atmodeller* in your research, we'd be happy to include a link to your work here. Feel free to send us a reference or DOI.

*Atmodeller* has been used in the following studies:

1. :cite:t:`BTT25`
   
2. :cite:t:`Cherubim2025`

3. :cite:t:`Hakim2025`