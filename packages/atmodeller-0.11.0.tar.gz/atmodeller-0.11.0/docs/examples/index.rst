Examples
========

.. toctree::
   :maxdepth: 1

   basic_usage
   iteration
   geological_outgassing
   gas_mixing
   atmosphere
   fugacity_crisis