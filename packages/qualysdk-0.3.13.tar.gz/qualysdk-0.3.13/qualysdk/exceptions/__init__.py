"""
Exceptions for qualysdk.
"""

from .Exceptions import *
