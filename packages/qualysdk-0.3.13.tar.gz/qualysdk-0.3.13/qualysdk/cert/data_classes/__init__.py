"""
Certificate View dataclasses
"""

from .Certificate import Certificate
