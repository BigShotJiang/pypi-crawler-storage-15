from enum import Enum

__NAMESPACE__ = "http://ns.editeur.org/onix/3.0/reference"


class ColgroupValign(Enum):
    TOP = "top"
    MIDDLE = "middle"
    BOTTOM = "bottom"
    BASELINE = "baseline"
