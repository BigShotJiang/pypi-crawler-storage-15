from enum import Enum

__NAMESPACE__ = "http://ns.editeur.org/onix/3.0/reference"


class ContributorPlaceRelatorRefname(Enum):
    CONTRIBUTOR_PLACE_RELATOR = "ContributorPlaceRelator"
