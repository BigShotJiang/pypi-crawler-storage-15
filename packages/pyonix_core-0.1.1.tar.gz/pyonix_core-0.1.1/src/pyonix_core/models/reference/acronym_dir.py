from enum import Enum

__NAMESPACE__ = "http://ns.editeur.org/onix/3.0/reference"


class AcronymDir(Enum):
    LTR = "ltr"
    RTL = "rtl"
