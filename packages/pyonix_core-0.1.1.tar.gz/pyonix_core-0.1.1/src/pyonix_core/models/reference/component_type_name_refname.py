from enum import Enum

__NAMESPACE__ = "http://ns.editeur.org/onix/3.0/reference"


class ComponentTypeNameRefname(Enum):
    COMPONENT_TYPE_NAME = "ComponentTypeName"
