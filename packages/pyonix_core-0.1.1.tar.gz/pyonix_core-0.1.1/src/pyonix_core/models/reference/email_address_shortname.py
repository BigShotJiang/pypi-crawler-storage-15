from enum import Enum

__NAMESPACE__ = "http://ns.editeur.org/onix/3.0/reference"


class EmailAddressShortname(Enum):
    J272 = "j272"
