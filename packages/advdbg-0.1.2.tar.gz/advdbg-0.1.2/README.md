# Advanced Debugger

Minimalist, colorful, configurable debug logger for Python.

## Why Advanced Debugger?

- 👨‍💻 Simple console logging of actions.
- 🕐 Debug with time specifying for one minute
- 🗄️ Takes only few lines for much debugs.

## Examples

Define debug category:
dbgVar = AdvDEBUG.define('title of your debug')

Print something:
dbgVar.output('Text to debug!')
OR
dbgVar('Text to debug!')

Returns:
[title of your debug at DATE AND TIME] Text to debug!

Configure existing category:
dbgVar.cfg(title='REQUEST')

BEFORE: title of your debug
AFTER: REQUEST

## Change Log: v0.1.2

- Added types of output
- Added check

## LICENSE

This module licensed with MIT

## Installation

```bash
pip install advdbg