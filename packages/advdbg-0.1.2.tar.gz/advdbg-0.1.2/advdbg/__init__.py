'''
Welcome to Advanced Debug.
Licensed with MIT
'''

__version__ = '0.1.0'

from datetime import datetime

class AdvDEBUG:
	def __init__(self, title='DEBUG', activated=False, notify=False):
		self.title = title
		self.activated = False
		self._defed = False
		self.notify = notify
		
	@classmethod
	def define(cls, title='DEBUG', activated=True, notify=False):
		'''Defines your debug category.
		:param title: Title of your category
		:param activated: Toggle availability of category
		:param notify: Toggles notification if category is not activated'''
		inst = cls(title, activated, notify)
		inst.title = title
		inst.activated = True
		inst.notify = notify
		return inst
		
	def cfg(self, activated=None, title=None, notify=True):
		'''Configure existing category'''
		if activated is not None:
			self.activated = activated
			if self.activated is False:
				self.notify = notify
		elif title is not None:
			self.title = title
		return self
		
	def output(self, text):
		"""Print debug information
		
		:param text: Text to show"""
		if self.activated:
			print(f'[\033[95m{self.title} at {datetime.now().strftime('%D, %H:%M:%S')}\033[0m] {text}')
		elif self.notify:
			print(f'Notification from {self.title}: Tryed to output when disactivated.\n\033[93mTip: \033[0mIf you are did not want to saw these notifications, turn off NOTIFY property with using notify=False')
		else:
			return
			
	def __call__(self, text):
		self.output(text)