"""
oiiai - 简单的 AI 模型调用工具包

提供模型列表获取和模型调用功能。
"""

from .fetchModelList import (
    FetchBase,
    FetchZhipu,
    FetchOpenRouter,
    FetchModelScope,
    FetchSiliconFlow,
    FetchIFlow,
)

__all__ = [
    # 模型列表获取
    "FetchBase",
    "FetchZhipu",
    "FetchOpenRouter",
    "FetchModelScope",
    "FetchSiliconFlow",
    "FetchIFlow",
]