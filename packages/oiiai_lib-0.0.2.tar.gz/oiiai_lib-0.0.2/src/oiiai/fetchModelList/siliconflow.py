import requests
import os
from typing import List
from .base import FetchBase


class FetchSiliconFlow(FetchBase):
    @property
    def provider(self) -> str:
        return "siliconflow"

    def fetch_models(self) -> List[str]:
        url = "https://api.siliconflow.cn/v1/models"
        api_key = os.getenv("SILICONFLOW_API_KEY")
        if not api_key:
            print("SILICONFLOW_API_KEY environment variable is not set.")
            return []

        headers = {"Authorization": f"Bearer {api_key}"}

        try:
            response = requests.get(url, headers=headers)
            response.raise_for_status()  # 触发 HTTP 错误异常
            data = response.json()
            # Assume API directly returns list of model IDs or in 'data' field
            # Adjust according to actual API response structure
            if isinstance(data, dict) and "data" in data and isinstance(data["data"], list):
                return [model["id"] for model in data["data"]]
            elif isinstance(data, list):
                return data
            else:
                print(f"SiliconFlow API returned unexpected format: {data}")
                return []
        except requests.exceptions.RequestException as e:
            print(f"Error fetching models from SiliconFlow: {e}")
            return []
