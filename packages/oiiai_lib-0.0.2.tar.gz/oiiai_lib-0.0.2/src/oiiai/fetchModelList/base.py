"""
Model list fetching base class
"""

from abc import ABC, abstractmethod
from typing import List


class FetchBase(ABC):
    """Model list fetching base class"""

    @property
    @abstractmethod
    def provider(self) -> str:
        """Provider identifier, such as 'zhipu', 'openrouter'"""
        pass

    @abstractmethod
    def fetch_models(self) -> List[str]:
        """Fetch model list from remote"""
        pass
