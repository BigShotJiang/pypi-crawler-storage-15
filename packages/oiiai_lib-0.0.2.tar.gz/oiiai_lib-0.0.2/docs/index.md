# oiiai 文档

oiiai 是一个简单的 AI 模型调用工具包，提供模型列表获取和模型调用功能。

## 安装

```bash
pip install oiiai-lib
```

## 快速开始

```python
from oiiai import (
    FetchZhipu,
    FetchOpenRouter,
    FetchModelScope,
    FetchSiliconFlow,
    FetchIFlow,
)

# 获取可用模型列表

# 从智谱 AI 获取模型列表
zhipu_fetcher = FetchZhipu()
zhipu_models = zhipu_fetcher.fetch_models()
print(f"智谱 AI 可用模型: {len(zhipu_models)} 个")

# 从 OpenRouter 获取模型列表
openrouter_fetcher = FetchOpenRouter(api_key="your-api-key")
openrouter_models = openrouter_fetcher.fetch_models()
print(f"OpenRouter 可用模型: {len(openrouter_models)} 个")

# 从 ModelScope 获取模型列表
modelscope_fetcher = FetchModelScope()
modelscope_models = modelscope_fetcher.fetch_models()
print(f"ModelScope 可用模型: {len(modelscope_models)} 个")

# 从 SiliconFlow 获取模型列表
siliconflow_fetcher = FetchSiliconFlow()
siliconflow_models = siliconflow_fetcher.fetch_models()
print(f"SiliconFlow 可用模型: {len(siliconflow_models)} 个")

# 从 IFlow 获取模型列表
iflow_fetcher = FetchIFlow()
iflow_models = iflow_fetcher.fetch_models()
print(f"IFlow 可用模型: {len(iflow_models)} 个")
```

## 模块文档

- [fetchModelList](./fetchModelList.md) - 模型列表获取

## 支持的提供商

| 提供商 | 模型获取 | 说明 |
|--------|----------|------|
| 智谱 AI | ✅ FetchZhipu | 从官方文档页面解析模型列表 |
| OpenRouter | ✅ FetchOpenRouter | 通过 API 获取模型列表 |
| ModelScope | ✅ FetchModelScope | 通过 API 获取模型列表 |
| SiliconFlow | ✅ FetchSiliconFlow | 通过 API 获取模型列表 |
| IFlow | ✅ FetchIFlow | 通过 API 获取模型列表 |
