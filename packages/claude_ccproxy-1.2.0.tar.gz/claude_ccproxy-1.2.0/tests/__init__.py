"""Tests for ccproxy."""
