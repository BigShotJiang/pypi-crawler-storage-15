# Alt Screen Toggle

<img width="800" src="./altscreen-toggle.gif" />
