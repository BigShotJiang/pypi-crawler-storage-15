# Text Inputs

<img width="800" src="./textinputs.gif" />
