# Split Editors

<img width="800" src="./split-editors.gif" />
