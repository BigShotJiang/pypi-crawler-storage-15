# Paginator

<img width="800" src="./paginator.gif" />
