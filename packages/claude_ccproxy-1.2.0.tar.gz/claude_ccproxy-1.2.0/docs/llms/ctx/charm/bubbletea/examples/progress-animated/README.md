# Animated Progress

<img width="800" src="./progress-animated.gif" />
