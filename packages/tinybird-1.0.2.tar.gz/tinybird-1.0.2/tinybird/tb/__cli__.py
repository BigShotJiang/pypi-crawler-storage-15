
__name__ = 'tinybird'
__description__ = 'Tinybird Command Line Tool'
__url__ = 'https://www.tinybird.co/docs/forward/commands'
__author__ = 'Tinybird'
__author_email__ = 'support@tinybird.co'
__version__ = '1.0.2'
__revision__ = 'f183ff4'
