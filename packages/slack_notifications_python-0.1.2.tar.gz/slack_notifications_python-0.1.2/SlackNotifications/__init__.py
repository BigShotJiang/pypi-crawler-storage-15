from ._version import __version__ as version

__version__ = version
