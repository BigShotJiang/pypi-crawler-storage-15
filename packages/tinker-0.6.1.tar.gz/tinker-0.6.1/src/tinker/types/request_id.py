from typing_extensions import TypeAlias

__all__ = ["RequestID"]

RequestID: TypeAlias = str
