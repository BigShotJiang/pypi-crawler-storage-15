# iml-query

A Python library for parsing, querying, and manipulating [IML (Imandra Modeling Language)](https://docs.imandra.ai/imandrax/) files.
