'read and scale data file for fish csc 9/29/92

PRINT "read fish data file for model fish calculations"
PRINT "The fish model is constructed of short cylinders"
PRINT "data files are for fish body (flesh) and swimbladder"
PRINT "Although we expect the fish to scale, individual animals"
PRINT "can be put in the arrays"
PRINT"---data files contain headers and identifiers"
PRINT"   fish flesh density, gas density and sound speeds are in"
PRINT"   scattering prgms."

DIM xfb(50),zufb(50),zlfb(50),wfb(50), xsb(50),zusb(50),zlsb(50),wsb(50)
sF = 1: pi = 4*ATN(1): lcnvm = .001 : vcnvm = 1E-09
fbd = 1050 :'kg/m^3

 'words for file
words1$ = "caudal fish length mm ="
words2$ = "fish mass g ="
words5$ = "fish body"
words6$ = "swimbladder"
words7$ =  "x, z-upper, z-lower, width"

20 PRINT"menu"
PRINT"  enter 'ef' to enter file"
PRINT"        'df' to read default file"
PRINT"        'rf' to read old file"
PRINT"        's' to scale fish to new length"
PRINT"        'c' to compute volume and mass"
PRINT"        'g'  to graph  file"
PRINT"        'mf' to make file"
PRINT"        'q'  to quit"

INPUT q$
IF q$ = "ef" GOTO 100
IF q$ = "df" GOTO 800
IF q$ = "rf" GOTO 2000
IF q$ = "c" GOTO 600
IF q$ = "s" GOTO 700
IF q$ = "g" GOTO 300
IF q$ = "mf" GOTO 200
IF q$ = "q" GOTO 1000
GOTO 20

100 PRINT
PRINT "make file called ";:INPUT name1$
PRINT"enter data"
PRINT"fish type";: INPUT ftype$
PRINT"caudal fish length mm =";: INPUT fL
PRINT"fish mass g =";: INPUT mfb
PRINT
PRINT"fish body"
PRINT"enter number of samples 0-> N =";:INPUT Nfb
PRINT " enter x, z-upper, z-lower, width"

FOR n = 0 TO Nfb
   PRINT n;:INPUT xfb(n),zufb(n),zlfb(n),wfb(n)
NEXT n
PRINT
PRINT"fish swimbladder"
PRINT"enter number of samples 0-> N =";:INPUT Nsb
PRINT " enter x, z-upper, z-lower, width"

FOR n = 0 TO Nsb
   PRINT n;:INPUT xsb(n),zusb(n),zlsb(n),wsb(n)
NEXT n
PRINT
PRINT"enter any comments-- use quotes ";:INPUT words8$
GOTO 20

200 ' make file. chose tt and kk to give 0.1 mm
tt = 10: kk = 10
PRINT "file in prgm ";name1$
PRINT "file read ";name2$
PRINT "name new file";:INPUT name1$
 OPEN name1$ FOR OUTPUT AS #1
 WRITE #1, ftype$
 WRITE #1, words1$,sL
 WRITE #1, words2$,mfb
 WRITE #1,Nfb
 WRITE #1,words7$
 WRITE #1,words5$
 FOR n = 0 TO Nfb
    WRITE #1,INT(tt*sF*xfb(n))/kk,INT(tt*sF*zufb(n))/kk,INT(tt*sF*zlfb(n))/kk,INT(tt*sF*wfb(n))/kk
 NEXT n
 
 WRITE #1, words6$
  WRITE #1, Nsb
  FOR n = 0 TO Nsb
    WRITE #1,INT(tt*sF*xsb(n))/kk,INT(tt*sF*zusb(n))/kk,INT(tt*sF*zlsb(n))/kk,INT(tt*sF*wsb(n))/kk
 NEXT n
 
 WRITE #1,words8$
 
 CLOSE #1
 GOTO 20
 
300  G0 = 20: G1 = 460: G2 = 20: G3 = 260: '   PLOT WINDOW LIMITS X,Y
 XS = (G1-G0)/fL
 YS = XS
 z0 = G3/3
 zw = 3*G3/4
 
 CLS         : ' CLS clears the screen
SCREEN 9 'mode for drawing

LINE (G0,G2) - (G1,G2)
LINE (G0,G3) - (G1,G3)
LINE (G0,G2) - (G0,G3)
LINE (G1,G2) - (G1,G3)

' plot upper side fish body
 FOR n = 0 TO Nfb-1       
         xp = sF*xfb(n) * XS +G0
         xp1 = sF*xfb(n+1) * XS +G0
          zp = z0-sF*zufb(n) *YS
          zp1 = z0-sF*zufb(n+1) *YS
         LINE (xp,zp) - (xp1,zp1)
 NEXT n
 'plot lower side
  FOR n = 0 TO Nfb-1       
         xp = sF*xfb(n) * XS +G0
         xp1 = sF*xfb(n+1) * XS +G0
          zp = z0-sF*zlfb(n) *YS
          zp1 = z0-sF*zlfb(n+1) *YS
         LINE (xp,zp) - (xp1,zp1)
 NEXT n

 ' plot upper side swimbladder
 FOR n = 0 TO Nsb-1       
         xp = sF*xsb(n) * XS +G0
         xp1 = sF*xsb(n+1) * XS + G0
          zp = z0-sF*zusb(n) *YS
          zp1 = z0-sF*zusb(n+1) *YS
         LINE (xp,zp) - (xp1,zp1)
 NEXT n

 'plot lower side
  FOR n = 0 TO Nsb-1
         xp = sF*xsb(n)* XS +G0
         xp1 = sF*xsb(n+1) * XS +G0
          zp = z0-sF*zlsb(n) *YS
          zp1 = z0-sF*zlsb(n+1) *YS
         LINE (xp,zp) - (xp1,zp1)
 NEXT n
'plot top view--------------------
' plot  fish body
 FOR n = 0 TO Nfb-1
         xp = sF*xfb(n) * XS +G0
         xp1 = sF*xfb(n+1) * XS +G0
          zp = zw-sF*wfb(n) *YS/2
          zp1 = zw-sF*wfb(n+1) *YS/2
         LINE (xp,zp) - (xp1,zp1)
 NEXT n
 'plot other side
  FOR n = 0 TO Nfb-1
         xp = sF*xfb(n) * XS +G0
         xp1 = sF*xfb(n+1) * XS +G0
          zp = zw+sF*wfb(n) *YS/2
          zp1 = zw+sF*wfb(n+1) *YS/2
         LINE (xp,zp) - (xp1,zp1)
 NEXT n

 ' plot top view side swimbladder
 FOR n = 0 TO Nsb-1
         xp = sF*xsb(n) * XS +G0
         xp1 = sF*xsb(n+1) * XS + G0
          zp = zw-sF*wsb(n) *YS/2
          zp1 = zw-sF*wsb(n+1) *YS/2
         LINE (xp,zp) - (xp1,zp1)
 NEXT n

 'plot other side
  FOR n = 0 TO Nsb-1
         xp = sF*xsb(n)* XS +G0
         xp1 = sF*xsb(n+1) * XS +G0
          zp = sF*zw+wsb(n) *YS/2
          zp1 = sF*zw+wsb(n+1) *YS/2
         LINE (xp,zp) - (xp1,zp1)
 NEXT n

'print file names etc
txt$ = name1$ + "-" + ftype$ + " fish L =" + STR$(fL)
_PRINTSTRING (G0, 280), txt$
INPUT q$

  330 'end of graph operation
 pic$ = PICTURE$ 
INPUT q$

     ' make pict file
 PRINT "make a PICT file, y or n ?";:INPUT pf$
 IF pf$ = "y"  GOTO 340

   CLS    :REM clear screen and clean pict memory

   GOTO 20

340 'make pict file

_PRINTSTRING (50, 25), "Enter name for image file:"
LOCATE 1, 30
INPUT pictFile$
_SAVEIMAGE pictFile$

 
  CLS    :REM clear screen and clean pict memory
 
GOTO 20

600 'compute volumes and mass
' xfb(50),zufb(50),zlfb(50),wfb(50), xsb(50),zusb(50),zlsb(50),wsb(50)
' deltaV = pi*(z0^2*dx + b*z0*dx^2 + b^2*dx^3/3)*vcnvm , mm -> m

vsb = 0 :vfb = 0
FOR n = 0 TO Nsb-1
    z0 = sF*(zusb(n)-zlsb(n))/2
    z1 = sF*(zusb(n+1)-zlsb(n+1))/2
    y0 = sF*wsb(n)/2
    y1 = sF*wsb(n+1)/2
    dx = sF*(xsb(n+1)-xsb(n))
    zb = (z1-z0)/dx
    yb = (y1-y0)/dx
    vv = pi*(z0*y0*dx + (zb*y0+yb*z0)*dx^2/2 + zb*yb*dx^3/3 )
   vsb = vsb+vv*vcnvm
NEXT n

FOR n = 0 TO Nfb-1
    z0 = sF*(zufb(n)-zlfb(n))/2
    z1 = sF*(zufb(n+1)-zlfb(n+1))/2
    y0 = sF*wfb(n)/2
    y1 = sF*wfb(n+1)/2
    dx = sF*(xfb(n+1)-xfb(n))
    zb = (z1-z0)/dx
    yb = (y1-y0)/dx
    vv = pi*(z0*y0*dx + (zb*y0+yb*z0)*dx^2/2 + zb*yb*dx^3/3)
   vfb = vfb+vv*vcnvm
NEXT n

massf = (vfb-vsb)*fd
PRINT " fish volume = "; INT(vfb*1000000!); " cm^3"
PRINT " swimbladder = "; INT(vsb*1000000!); " cm^3"
PRINT"        using flesh density =";fd;" kg/m^3"
PRINT " mass fish = "; INT(massf*1000!); " g"
PRINT " meas mass = "; mfb; " g"
GOTO 20

700 ' scale fish
PRINT"xfb(Nfb) =";xfb(Nfb)
PRINT "fish length ="; fL
PRINT "input new scale length";:INPUT sL
sF = sL/xfb(Nfb)
GOTO 20

800 name1$ = "horne cod D"

ftype$ = "cod D, CL 380/TL 412mm/544g"
 fL = 380  :' caudal length
 sL = 380
 mfb = 544
 fd = 1050 :sbd = 124
 cfb = 1578:csb = 345

    Nfb = 10
' enter x, z-upper, z-lower, width

 xfb(0)=0:    zufb(0)=5:  zlfb(0)=-10: wfb(0)=20
 xfb(1)=41:   zufb(1)=20: zlfb(1)=-25: wfb(1)=45
 xfb(2)=83:   zufb(2)=30: zlfb(2)=-30: wfb(2)=57
 xfb(3)=124:  zufb(3)=30: zlfb(3)=-45: wfb(3)=60
 xfb(4)=165:  zufb(4)=27: zlfb(4)=-47: wfb(4)=49
 xfb(5)=206:  zufb(5)=23: zlfb(5)=-40: wfb(5)=35
 xfb(6)=247:  zufb(6)=15: zlfb(6)=-29: wfb(6)=23
 xfb(7)=290:  zufb(7)=10: zlfb(7)=-20: wfb(7)=12
 xfb(8)=330:  zufb(8)=7:  zlfb(8)=-16: wfb(8)=7
 xfb(9)=370:  zufb(9)=5:  zlfb(9)=-13: wfb(9)=3
 xfb(10)=380: zufb(10)=0: zlfb(10)=-5: wfb(10)=1

' swimbladder 
    Nsb = 5
xsb(0)=103: zusb(0)=-2:  zlsb(0)=-10:  wsb(0)=11
xsb(1)=125: zusb(1)=-2:  zlsb(1)=-16: wsb(1)=25
xsb(2)=144: zusb(2)=-3:  zlsb(2)=-20: wsb(2)=23
xsb(3)=165: zusb(3)=-6:  zlsb(3)=-23: wsb(3)=18
xsb(4)=186: zusb(4)=-10: zlsb(4)=-21: wsb(4)=14
xsb(5)=206: zusb(5)=-16: zlsb(5)=-19: wsb(5)=7
 
 words8$ ="from john horne soft x=rays of cod. total length 412 mm/cL 380"
 
PRINT" Horne data on cod"
PRINT" cod    total length    caudal length     mass"
PRINT" A       177 mm                172                   48 g"
PRINT" B        156                  148                   43"
PRINT" C        344                  323                  286"
PRINT" D        412                  380                  544"
PRINT" E         804                 ----                4685"

GOTO 20

 
2000 ' read data file in 'fish data file maker' format
PRINT"read file ";:INPUT name2$
  OPEN name2$ FOR INPUT AS #2
 INPUT #2, ftype$
 INPUT #2, words1$,fL
 INPUT #2, words2$,mfb
 INPUT #2,Nfb
 INPUT #2,words7$
 INPUT #2,words5$
 
 FOR j = 0 TO Nfb
    INPUT #2,xfb(j),zufb(j),zlfb(j),wfb(j)
 NEXT j
 
 INPUT #2, words6$
 
  INPUT #2, Nsb
  FOR j = 0 TO Nsb
    INPUT #2,xsb(j),zusb(j),zlsb(j),wsb(j)
 NEXT j
 
 INPUT #2,words8$
 CLOSE #2
GOTO 20

1000 END
