from .core import is_even, is_odd, check
