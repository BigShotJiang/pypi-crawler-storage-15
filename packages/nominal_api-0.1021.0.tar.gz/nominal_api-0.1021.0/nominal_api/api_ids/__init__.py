# coding=utf-8
from .._impl import (
    api_ids_WorkspaceId as WorkspaceId,
)

__all__ = [
    'WorkspaceId',
]

