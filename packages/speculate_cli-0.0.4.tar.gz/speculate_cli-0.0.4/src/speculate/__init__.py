# Speculate CLI package
