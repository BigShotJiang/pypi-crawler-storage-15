# --------------------------------------------------------------------------------
# Copyright (c) 2025 Zehao Yang
#
# Author: Zehao Yang
#
# This module implements feature engineering functions:
# • Adding various features based on trade and reference exchange-market pairs
# --------------------------------------------------------------------------------


import _ext.feature as _feature


DEFAULT_FEATURE_PARAMS_DICT = {
    'time': [],
    'macd': [],
    'rsi': [],
    'price_move_range': [],
    'price_trend': [],
    'price_volume_corr': [],
    'ohlcv': [],
    'volatility': [],
    'high_low_time': [],
    'volume': [],
    'basis': [],
    'fixedstart': [],
    'funding': [],
    'index': [],
}


def add_features(features_map, feature_params_dict):
    return _feature.add_features(features_map, feature_params_dict)