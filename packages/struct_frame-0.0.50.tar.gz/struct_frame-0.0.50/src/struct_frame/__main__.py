#!/usr/bin/env python3
# kate: replace-tabs on; indent-width 4;


from struct_frame import main

if __name__ == '__main__':
    main()
