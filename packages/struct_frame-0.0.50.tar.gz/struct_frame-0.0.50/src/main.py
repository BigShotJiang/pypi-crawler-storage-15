import struct_frame

struct_frame.main()
