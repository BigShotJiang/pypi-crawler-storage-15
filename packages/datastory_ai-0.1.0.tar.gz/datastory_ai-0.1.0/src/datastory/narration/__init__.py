"""Narration modules for DataStory."""

from .generator import NarrativeGenerator

__all__ = ["NarrativeGenerator"]
