"""Configuration management for DataStory."""

__all__ = []
