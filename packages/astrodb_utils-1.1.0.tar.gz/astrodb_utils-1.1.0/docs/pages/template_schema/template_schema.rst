###########################
The AstroDB Template schema
###########################

.. toctree::
   :glob:
   :maxdepth: 2

   main_tables/index.rst
   data_tables/index.rst
   lookup_tables/index.rst