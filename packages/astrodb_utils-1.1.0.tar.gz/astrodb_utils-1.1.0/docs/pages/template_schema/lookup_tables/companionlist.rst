CompanionList
###############

.. seealso::
    :doc:`../data_tables/companion_relationships`
        Documentation on the Companion Relationships table


Table Documentation
===================
.. _source: https://github.com/astrodbtoolkit/astrodb-template-db/blob/main/docs/schema/CompanionList.md

The below table is built directly from the schema and is
included here from the `astrodb-template-db` documentation: `source`_.

.. mdinclude:: ../astrodb-template-db/docs/schema/CompanionList.md
