*************
Data tables
*************
These tables are examples and can be removed as needed.
Helper functions in the `astrodb_utils` package are 
designed to help with adding data to these tables.
Additional tables can be added using these as templates.

.. toctree::
   :glob:
   :titlesonly:
   :maxdepth: 1

   *