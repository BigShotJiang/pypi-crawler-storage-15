ProperMotions
#############

Table Documentation
===================
.. _source: https://github.com/astrodbtoolkit/astrodb-template-db/blob/main/docs/schema/ProperMotions.md

The below table is built directly from the schema and is
included here from the `astrodb-template-db` documentation: `source`_.

.. mdinclude:: ../astrodb-template-db/docs/schema/ProperMotions.md
