CompanionParameters
###################

.. seealso::

    :doc:`../lookup_tables/parameterlist`
        Documentation for the ParamaterList table

    :doc:`companion_relationships`
        Documentation for the CompanionRelationships table
       

Table Documentation
====================
.. _source: https://github.com/astrodbtoolkit/astrodb-template-db/blob/main/docs/schema/CompanionParameters.md

The below table is built directly from the schema and is
included here from the `astrodb-template-db` documentation: `source`_.

.. mdinclude:: ../astrodb-template-db/docs/schema/CompanionParameters.md