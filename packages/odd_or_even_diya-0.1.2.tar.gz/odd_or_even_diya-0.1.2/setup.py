from setuptools import setup, find_packages

setup(
    name="odd-or-even-diya",
    version="0.1.2",  # ⬅️ change this
    description="A simple library to check if a number is odd or even",
    author="Diya George",
    packages=find_packages(),
    python_requires=">=3.7",
)
