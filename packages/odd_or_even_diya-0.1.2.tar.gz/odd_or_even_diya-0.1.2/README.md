# odd-or-even-diya

A tiny Python library to check if a number is odd or even.

## Installation

```bash
pip install odd-or-even-diya
