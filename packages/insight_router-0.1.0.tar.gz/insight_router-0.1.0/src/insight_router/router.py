import os

import httpx
from fastapi import Request, HTTPException, UploadFile, APIRouter
from fastapi.responses import Response

router = APIRouter(prefix="/insight", tags=["insight"])

HOST = os.getenv("GPU_HOST", "http://10.8.2.139")
V1_PORT = os.getenv("V1_PORT", "8060")
V2_PORT = os.getenv("V2_PORT", "8066")


# 通用的请求转发函数
async def forward_request(request: Request, path: str):
    version = request.url.path.split('/')[1]
    port = V1_PORT if version == 'v1' else V2_PORT
    url = f"{HOST}:{port}/{path}"

    # 处理请求头
    headers = dict(request.headers)
    headers.pop("host", None)  # 移除 host 头，避免冲突

    # 处理查询参数
    params = dict(request.query_params)

    # 初始化请求体参数
    request_data = {
        "data": None,
        "files": None,
        "json": None
    }

    content_type = headers.get("content-type", "").lower()

    # 处理 multipart/form-data
    if content_type.startswith("multipart/form-data"):
        form_data = await request.form()
        multipart_items = []
        for key, value in form_data.items():
            if isinstance(value, UploadFile):
                file_content = await value.read()
                multipart_items.append((key, (value.filename, file_content)))
            else:
                # 普通表单字段也作为multipart的一部分
                multipart_items.append((key, (None, str(value))))
        request_data["files"] = multipart_items

    # 处理 application/json
    elif content_type == "application/json":
        request_data["json"] = await request.json()

    # 处理其他内容类型（如 application/x-www-form-urlencoded）
    else:
        if request.method in ("POST", "PUT", "PATCH"):
            body = await request.body()
            if body:
                request_data["data"] = body

    # 转发请求
    async with httpx.AsyncClient(timeout=60) as client:
        try:
            response = await client.request(
                method=request.method,
                url=url,
                headers=headers,
                params=params,
                **request_data
            )
            response.raise_for_status()
        except httpx.HTTPStatusError as e:
            raise HTTPException(status_code=e.response.status_code, detail=str(e))
        except httpx.RequestError as e:
            raise HTTPException(status_code=500, detail=f"连接目标服务失败: {str(e)}")

    # 返回响应
    return Response(
        content=response.content,
        status_code=response.status_code,
        headers=dict(response.headers)
    )


@router.api_route("/v1/{path:path}", methods=["GET", "POST", "PUT", "DELETE", "PATCH"])
@router.api_route("/v2/{path:path}", methods=["GET", "POST", "PUT", "DELETE", "PATCH"])
async def forward_v1_v2(request: Request, path: str):
    return await forward_request(request, path)
