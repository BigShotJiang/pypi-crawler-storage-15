"""Tests for SLURM historical usage functionality using slurm-emulator."""
