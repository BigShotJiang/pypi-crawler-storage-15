from dyngle.command import DyngleCommand


class NullCommand(DyngleCommand):

    name = "null"
