# -*- coding: utf-8 -*-
"""LTA: A Python CLI for Lipid Traffic Analysis.

Attributes
----------
__version__ : str
    The version number,
    specified in the form 'major.minor.patch'
"""
__version__ = "3.5.2"
