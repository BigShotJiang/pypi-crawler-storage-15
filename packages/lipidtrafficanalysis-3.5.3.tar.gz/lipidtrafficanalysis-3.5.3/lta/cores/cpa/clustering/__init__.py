"""Clustering submodule for the CPA (Cluster Pattern Analysis)."""
