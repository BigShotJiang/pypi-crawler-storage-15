"""
A Python library for manipulating, plotting and computing with polyhedral and ellipsoidal sets.
"""

__version__ = "0.0.5"

# ruff: noqa
#
from .polyhedron import *
from .ellipsoid import *
from .plotting import plot_polytope, plot_ellipsoid
