# Geomin

Python library for manipulating, plotting and computing with polyhedral
and ellipsoidal sets. It is a relatively thin wrapper around
Pycddlib, including some utility functions for convenience.

## Installation

(The following assume you have already created a Python virtual environment)

**Option 1.** Install directly from PyPI:

```sh
pip install geomin
```

This does assume some prerequisites for `pycddlib` have already been installed.
See [their documentation](https://pycddlib.readthedocs.io/en/latest/quickstart.html)
for more information.

**Option 2.** Clone the repo and from within its root, run

```sh
pip install .
```

## Usage

### Creation of polytopes

#### From inequalities

Use the `Polyhedron.from_inequalities` method to build a polyhedron $X$ from
a system of linear inequalities

$$
X = \{ x \in \mathbb{R}^n \mid H x \le h \}.
$$

For example, to represent the system

$$
\begin{cases}
x_1 \ge -1 \\
x_2 \ge -1 \\
x_1 + x_2 \le 1
\end{cases}
$$

You would write

```python
import geomin as gp
import numpy as np

H = np.vstack([-np.eye(2), np.ones((1,2))])
h = np.array([1., 1., 1.])
poly = gp.Polyhedron.from_inequalities(H, h)

```

#### From vertices

Alternatively, a polyhedron can be constructed as the convex hull of a list
of vertices.

```python
import geomin as gp
import numpy as np

verts = np.array([(0, 0), (1, 0), (0, 1)])
poly = gp.Polyhedron.from_generators(verts)
```

### Creation of ellipsoids

An ellipsoid created as `gp.Ellipsoid(Q, c)` represents

$$
\{ x: (x - c)^\top Q (x - c) \leq 1 \}.
$$

The argument $c$ is optional and is assumed to be $0$ by default.

## Plotting

We provide some functions for easy plotting of sets, built on Matplotlib.
Check the [examples](https://github.com/kul-optec/geomin/tree/main/examples) folder for more.


```python
import matplotlib.pyplot as plt

# basic usage
plot_polytope(poly)

# Or with some styling
plt.figure()

plot_polytope(
    poly,
    color="tab:green",  # base color
    alpha=0.5,          # transparency
)

plt.show()
```
