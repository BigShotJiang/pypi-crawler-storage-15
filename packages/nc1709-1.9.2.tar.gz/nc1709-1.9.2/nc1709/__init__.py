"""
NC1709 CLI - A Local-First AI Developer Assistant
Version: 1.9.1
Author: NC1709 Team
License: MIT
"""

__version__ = "1.9.2"
__author__ = "NC1709 Team"

from .cli import main

__all__ = ["main"]
