#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @time    : 2021/6/11 10:50
# @Project : riboParser
# @Script  : __init__.py.py
# @Version : python 3.8.5
# @Author  : Rensc
# @E-mail  : rensc0718@163.com
