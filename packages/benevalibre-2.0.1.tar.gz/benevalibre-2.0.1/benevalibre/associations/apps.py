from django.apps import AppConfig


class BenevalibreAssociationsConfig(AppConfig):
    name = "benevalibre.associations"
    verbose_name = "Associations"
