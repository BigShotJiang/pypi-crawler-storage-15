from django.apps import AppConfig


class BenevalibreAccountsConfig(AppConfig):
    name = "benevalibre.accounts"
    verbose_name = "Comptes utilisat⋅eurs⋅rices"
