from django.apps import AppConfig


class BenevaloConfig(AppConfig):
    name = "benevalibre.deprecated.benevalo"
    verbose_name = "Benevalo"
