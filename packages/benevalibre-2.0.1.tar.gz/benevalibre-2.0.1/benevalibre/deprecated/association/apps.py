from django.apps import AppConfig


class AssociationConfig(AppConfig):
    name = "benevalibre.deprecated.association"
    verbose_name = "Association"
