from django.apps import AppConfig


class InstanceConfig(AppConfig):
    name = "benevalibre.deprecated.instance"
    verbose_name = "Instance"
