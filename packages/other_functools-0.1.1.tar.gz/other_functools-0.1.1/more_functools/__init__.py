"""More higher order functions and operations on callable objects for Python."""

import typing as t
from functools import wraps

__all__ = ["expand_into_args"]


R = t.TypeVar("R")


def expand_into_args(func: t.Callable[..., R]) -> t.Callable[[t.Iterable], R]:
    """Decorator that converts a function taking multiple positional arguments into one
    that takes a single iterable and unpacks it.

    Args:
        func: The function to be decorated. It should accept multiple positional
            arguments.

    Returns:
        A wrapper function that takes a single iterable argument and expands it into
        separate positional arguments when calling the decorated function.

    Raises:
        TypeError: If the provided argument is not an iterable.

    Example:

        >>> @expand_into_args
        ... def add(a, b):
        ...     return a + b
        >>> add([2, 3])
        5

        This is roughly equivalent to:

        >>> def add(args):
        ...     a, b = args  # This part is handled by the decorator
        ...     return a + b

    """

    @wraps(func)
    def wrapper(arg: t.Iterable, /) -> R:
        if not isinstance(arg, t.Iterable):
            raise TypeError(f"Argument must be an iterable, got {type(arg)!r} instead.")
        return func(*arg)

    return wrapper
