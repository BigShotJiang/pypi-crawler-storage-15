# other-functools

More higher order functions and operations on callable objects for Python.

## Installation

You can install the package via pip:

```bash
pip install other-functools
```

## Documentation

### `expand_into_args`

A decorator that expands an iterable argument into individual arguments for the decorated function.

```python
from more_functools import expand_into_args

@expand_into_args
def add(a: int, b: int) -> int:
    return a + b

result = add((2, 3))
print(result)  # Output: 5
```

#### Known Issues

May cause errors in linting tools that do not recognize decorators altering function signatures.
