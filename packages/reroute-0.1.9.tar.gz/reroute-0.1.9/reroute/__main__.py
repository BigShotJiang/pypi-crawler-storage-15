"""
REROUTE CLI Entry Point

Allows running the CLI with: python -m reroute
"""

from reroute.cli.main import main

if __name__ == '__main__':
    main()
