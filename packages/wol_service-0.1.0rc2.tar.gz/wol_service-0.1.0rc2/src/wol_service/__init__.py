def main() -> None:
    print("Hello from wol-service!")
