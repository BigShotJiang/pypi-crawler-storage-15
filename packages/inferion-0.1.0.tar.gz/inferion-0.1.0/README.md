# Inferion

A flexible inference framework for large language models.

## Installation

```bash
pip install inferion
```

With provider support:

```bash
pip install inferion[openai]
pip install inferion[anthropic]
pip install inferion[all]
```

## Quick Start

```python
from inferion import InferionEngine, InferionConfig

config = InferionConfig(model="gpt-4")
engine = InferionEngine(config)

response = await engine.generate("Hello, world!")
print(response)
```

## Status

This package is currently in pre-alpha. Full implementation coming soon.

## License

Apache-2.0
