"""Data ingestion module for CSV parsing and validation."""

