"""API module for FastAPI backend service."""
