## Changelog 

### Improved

- [alpha] When creating a ResourceViewMapping, Toolkit now allows
characters such as `.`, `[`, and `]` in the mapping