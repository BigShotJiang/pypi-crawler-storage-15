from .core.log import LogManager

logger = LogManager.GetLogger(log_name="astrbot")
