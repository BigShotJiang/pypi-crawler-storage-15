"""Lazy evaluation utilities for typed-ffmpeg."""
