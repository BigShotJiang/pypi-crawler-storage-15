"""FFmpeg compilation utilities package."""
