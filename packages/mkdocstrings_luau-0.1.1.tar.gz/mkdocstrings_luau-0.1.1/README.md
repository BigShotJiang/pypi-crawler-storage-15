# mkdocstrings-luau

[![ci](https://github.com/ryanlua/mkdocstrings-luau/workflows/ci/badge.svg)](https://github.com/ryanlua/mkdocstrings-luau/actions?query=workflow%3Aci)
[![documentation](https://img.shields.io/badge/docs-mkdocs-708FCC.svg?style=flat)](https://ryanlua.github.io/mkdocstrings-luau/)
[![pypi version](https://img.shields.io/pypi/v/mkdocstrings-luau.svg)](https://pypi.org/project/mkdocstrings-luau/)
[![gitter](https://img.shields.io/badge/matrix-chat-4DB798.svg?style=flat)](https://app.gitter.im/#/room/#mkdocstrings-luau:gitter.im)

A Luau handler for mkdocstrings.

## Installation

```bash
pip install mkdocstrings-luau
```


