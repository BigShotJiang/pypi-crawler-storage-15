from django.apps import AppConfig


class KMUHelperConfig(AppConfig):
    name = "kmuhelper"
    verbose_name = "KMUHelper"

    default_auto_field = "django.db.models.AutoField"
