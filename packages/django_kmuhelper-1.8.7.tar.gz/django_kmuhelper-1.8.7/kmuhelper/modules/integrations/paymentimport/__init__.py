"""A module to help importing payment data from camt.054 files"""
