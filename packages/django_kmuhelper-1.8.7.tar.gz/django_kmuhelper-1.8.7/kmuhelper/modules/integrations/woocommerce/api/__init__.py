from .customers import WCCustomersAPI
from .general import WCGeneralAPI
from .orders import WCOrdersAPI
from .product_categories import WCProductCategoriesAPI
from .products import WCProductsAPI
