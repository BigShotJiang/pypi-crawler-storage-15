# Important

The code in this folder has not been created by me. It is a copy
from [django-multi-email-field](https://github.com/fle/django-multi-email-field).

## Reason

Reason for this copy is that `ugettext_lazy` has been deprecated for quite a while now but
the [pull request](https://github.com/fle/django-multi-email-field/pull/20) replacing it with `gettext_lazy` hasn't been
merged yet. It also even seems like the original author hasn't been on GitHub for years.

## Original authors

    * Created by `Florent Lebreton <https://github.com/fle/>`
    * Maintained by `Makina Corpus <https://github.com/makinacorpus/>`
