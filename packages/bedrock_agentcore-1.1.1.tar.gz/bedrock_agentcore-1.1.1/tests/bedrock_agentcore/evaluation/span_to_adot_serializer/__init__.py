"""Tests for span_to_adot_serializer package."""
