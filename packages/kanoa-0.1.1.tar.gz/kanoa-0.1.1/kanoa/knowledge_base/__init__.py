"""Knowledge base components for kanoa."""
