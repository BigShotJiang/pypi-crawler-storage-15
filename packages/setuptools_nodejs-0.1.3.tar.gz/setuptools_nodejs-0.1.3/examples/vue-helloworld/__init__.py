"""
Tests for setuptools-nodejs.
"""
