"""
Test package for setuptools-nodejs integration.
"""

__version__ = "0.1.0"
