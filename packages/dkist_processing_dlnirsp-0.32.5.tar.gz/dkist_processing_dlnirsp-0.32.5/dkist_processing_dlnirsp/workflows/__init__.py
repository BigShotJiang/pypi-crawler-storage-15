"""Package containing workflows (AKA pipelines) for processing DLNIRSP data."""

from dkist_processing_dlnirsp.config import dkist_processing_dlnirsp_configurations
