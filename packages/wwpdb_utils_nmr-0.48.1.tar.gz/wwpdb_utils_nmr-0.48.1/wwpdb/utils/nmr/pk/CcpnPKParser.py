# Generated from CcpnPKParser.g4 by ANTLR 4.13.0
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,41,344,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,1,0,3,0,22,8,0,1,0,1,0,1,0,1,0,5,0,28,
        8,0,10,0,12,0,31,9,0,1,0,1,0,1,1,3,1,36,8,1,1,1,3,1,39,8,1,1,1,1,
        1,1,1,1,1,1,1,1,1,1,1,1,1,3,1,49,8,1,1,1,3,1,52,8,1,1,1,3,1,55,8,
        1,1,1,3,1,58,8,1,1,1,3,1,61,8,1,1,1,3,1,64,8,1,1,1,3,1,67,8,1,1,
        1,3,1,70,8,1,1,1,3,1,73,8,1,1,1,1,1,4,1,77,8,1,11,1,12,1,78,1,2,
        3,2,82,8,2,1,2,3,2,85,8,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,
        2,3,2,97,8,2,1,2,3,2,100,8,2,1,2,3,2,103,8,2,1,2,3,2,106,8,2,1,2,
        3,2,109,8,2,1,2,3,2,112,8,2,1,2,5,2,115,8,2,10,2,12,2,118,9,2,1,
        2,1,2,1,3,3,3,123,8,3,1,3,3,3,126,8,3,1,3,1,3,1,3,1,3,1,3,1,3,1,
        3,1,3,1,3,1,3,1,3,1,3,3,3,140,8,3,1,3,3,3,143,8,3,1,3,3,3,146,8,
        3,1,3,3,3,149,8,3,1,3,3,3,152,8,3,1,3,3,3,155,8,3,1,3,3,3,158,8,
        3,1,3,3,3,161,8,3,1,3,3,3,164,8,3,1,3,3,3,167,8,3,1,3,1,3,4,3,171,
        8,3,11,3,12,3,172,1,4,3,4,176,8,4,1,4,3,4,179,8,4,1,4,1,4,1,4,1,
        4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,3,4,195,8,4,1,4,3,4,198,
        8,4,1,4,3,4,201,8,4,1,4,3,4,204,8,4,1,4,3,4,207,8,4,1,4,3,4,210,
        8,4,1,4,3,4,213,8,4,1,4,5,4,216,8,4,10,4,12,4,219,9,4,1,4,1,4,1,
        5,3,5,224,8,5,1,5,3,5,227,8,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,
        5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,3,5,245,8,5,1,5,3,5,248,8,5,1,5,3,
        5,251,8,5,1,5,3,5,254,8,5,1,5,3,5,257,8,5,1,5,3,5,260,8,5,1,5,3,
        5,263,8,5,1,5,3,5,266,8,5,1,5,3,5,269,8,5,1,5,3,5,272,8,5,1,5,3,
        5,275,8,5,1,5,1,5,4,5,279,8,5,11,5,12,5,280,1,6,3,6,284,8,6,1,6,
        3,6,287,8,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,
        1,6,1,6,1,6,1,6,1,6,3,6,307,8,6,1,6,3,6,310,8,6,1,6,3,6,313,8,6,
        1,6,3,6,316,8,6,1,6,3,6,319,8,6,1,6,3,6,322,8,6,1,6,3,6,325,8,6,
        1,6,3,6,328,8,6,1,6,5,6,331,8,6,10,6,12,6,334,9,6,1,6,1,6,1,7,1,
        7,1,8,1,8,1,9,1,9,1,9,0,0,10,0,2,4,6,8,10,12,14,16,18,0,11,2,0,2,
        2,17,17,3,0,4,5,18,18,22,22,2,0,19,19,23,23,2,0,3,3,26,26,2,0,18,
        18,22,22,1,1,14,14,2,0,20,20,24,24,2,0,5,5,18,18,2,0,21,21,25,25,
        2,0,6,8,11,11,2,0,6,8,11,12,407,0,21,1,0,0,0,2,35,1,0,0,0,4,81,1,
        0,0,0,6,122,1,0,0,0,8,175,1,0,0,0,10,223,1,0,0,0,12,283,1,0,0,0,
        14,337,1,0,0,0,16,339,1,0,0,0,18,341,1,0,0,0,20,22,5,14,0,0,21,20,
        1,0,0,0,21,22,1,0,0,0,22,29,1,0,0,0,23,28,3,2,1,0,24,28,3,6,3,0,
        25,28,3,10,5,0,26,28,5,14,0,0,27,23,1,0,0,0,27,24,1,0,0,0,27,25,
        1,0,0,0,27,26,1,0,0,0,28,31,1,0,0,0,29,27,1,0,0,0,29,30,1,0,0,0,
        30,32,1,0,0,0,31,29,1,0,0,0,32,33,5,0,0,1,33,1,1,0,0,0,34,36,5,1,
        0,0,35,34,1,0,0,0,35,36,1,0,0,0,36,38,1,0,0,0,37,39,7,0,0,0,38,37,
        1,0,0,0,38,39,1,0,0,0,39,48,1,0,0,0,40,41,7,1,0,0,41,42,7,2,0,0,
        42,43,5,26,0,0,43,49,5,27,0,0,44,45,7,3,0,0,45,46,5,27,0,0,46,47,
        7,4,0,0,47,49,7,2,0,0,48,40,1,0,0,0,48,44,1,0,0,0,49,51,1,0,0,0,
        50,52,5,30,0,0,51,50,1,0,0,0,51,52,1,0,0,0,52,54,1,0,0,0,53,55,5,
        31,0,0,54,53,1,0,0,0,54,55,1,0,0,0,55,57,1,0,0,0,56,58,5,32,0,0,
        57,56,1,0,0,0,57,58,1,0,0,0,58,60,1,0,0,0,59,61,5,33,0,0,60,59,1,
        0,0,0,60,61,1,0,0,0,61,63,1,0,0,0,62,64,5,36,0,0,63,62,1,0,0,0,63,
        64,1,0,0,0,64,66,1,0,0,0,65,67,5,37,0,0,66,65,1,0,0,0,66,67,1,0,
        0,0,67,69,1,0,0,0,68,70,5,38,0,0,69,68,1,0,0,0,69,70,1,0,0,0,70,
        72,1,0,0,0,71,73,5,39,0,0,72,71,1,0,0,0,72,73,1,0,0,0,73,74,1,0,
        0,0,74,76,5,41,0,0,75,77,3,4,2,0,76,75,1,0,0,0,77,78,1,0,0,0,78,
        76,1,0,0,0,78,79,1,0,0,0,79,3,1,0,0,0,80,82,5,6,0,0,81,80,1,0,0,
        0,81,82,1,0,0,0,82,84,1,0,0,0,83,85,5,6,0,0,84,83,1,0,0,0,84,85,
        1,0,0,0,85,96,1,0,0,0,86,87,3,14,7,0,87,88,3,14,7,0,88,89,5,11,0,
        0,89,90,5,11,0,0,90,97,1,0,0,0,91,92,5,11,0,0,92,93,5,11,0,0,93,
        94,3,14,7,0,94,95,3,14,7,0,95,97,1,0,0,0,96,86,1,0,0,0,96,91,1,0,
        0,0,97,99,1,0,0,0,98,100,3,16,8,0,99,98,1,0,0,0,99,100,1,0,0,0,100,
        102,1,0,0,0,101,103,3,16,8,0,102,101,1,0,0,0,102,103,1,0,0,0,103,
        105,1,0,0,0,104,106,3,14,7,0,105,104,1,0,0,0,105,106,1,0,0,0,106,
        108,1,0,0,0,107,109,3,14,7,0,108,107,1,0,0,0,108,109,1,0,0,0,109,
        111,1,0,0,0,110,112,3,14,7,0,111,110,1,0,0,0,111,112,1,0,0,0,112,
        116,1,0,0,0,113,115,3,18,9,0,114,113,1,0,0,0,115,118,1,0,0,0,116,
        114,1,0,0,0,116,117,1,0,0,0,117,119,1,0,0,0,118,116,1,0,0,0,119,
        120,7,5,0,0,120,5,1,0,0,0,121,123,5,1,0,0,122,121,1,0,0,0,122,123,
        1,0,0,0,123,125,1,0,0,0,124,126,7,0,0,0,125,124,1,0,0,0,125,126,
        1,0,0,0,126,139,1,0,0,0,127,128,7,1,0,0,128,129,7,2,0,0,129,130,
        7,6,0,0,130,131,5,26,0,0,131,132,5,27,0,0,132,140,5,28,0,0,133,134,
        7,3,0,0,134,135,5,27,0,0,135,136,5,28,0,0,136,137,7,7,0,0,137,138,
        7,2,0,0,138,140,7,6,0,0,139,127,1,0,0,0,139,133,1,0,0,0,140,142,
        1,0,0,0,141,143,5,30,0,0,142,141,1,0,0,0,142,143,1,0,0,0,143,145,
        1,0,0,0,144,146,5,31,0,0,145,144,1,0,0,0,145,146,1,0,0,0,146,148,
        1,0,0,0,147,149,5,32,0,0,148,147,1,0,0,0,148,149,1,0,0,0,149,151,
        1,0,0,0,150,152,5,33,0,0,151,150,1,0,0,0,151,152,1,0,0,0,152,154,
        1,0,0,0,153,155,5,34,0,0,154,153,1,0,0,0,154,155,1,0,0,0,155,157,
        1,0,0,0,156,158,5,36,0,0,157,156,1,0,0,0,157,158,1,0,0,0,158,160,
        1,0,0,0,159,161,5,37,0,0,160,159,1,0,0,0,160,161,1,0,0,0,161,163,
        1,0,0,0,162,164,5,38,0,0,163,162,1,0,0,0,163,164,1,0,0,0,164,166,
        1,0,0,0,165,167,5,39,0,0,166,165,1,0,0,0,166,167,1,0,0,0,167,168,
        1,0,0,0,168,170,5,41,0,0,169,171,3,8,4,0,170,169,1,0,0,0,171,172,
        1,0,0,0,172,170,1,0,0,0,172,173,1,0,0,0,173,7,1,0,0,0,174,176,5,
        6,0,0,175,174,1,0,0,0,175,176,1,0,0,0,176,178,1,0,0,0,177,179,5,
        6,0,0,178,177,1,0,0,0,178,179,1,0,0,0,179,194,1,0,0,0,180,181,3,
        14,7,0,181,182,3,14,7,0,182,183,3,14,7,0,183,184,5,11,0,0,184,185,
        5,11,0,0,185,186,5,11,0,0,186,195,1,0,0,0,187,188,5,11,0,0,188,189,
        5,11,0,0,189,190,5,11,0,0,190,191,3,14,7,0,191,192,3,14,7,0,192,
        193,3,14,7,0,193,195,1,0,0,0,194,180,1,0,0,0,194,187,1,0,0,0,195,
        197,1,0,0,0,196,198,3,16,8,0,197,196,1,0,0,0,197,198,1,0,0,0,198,
        200,1,0,0,0,199,201,3,16,8,0,200,199,1,0,0,0,200,201,1,0,0,0,201,
        203,1,0,0,0,202,204,3,14,7,0,203,202,1,0,0,0,203,204,1,0,0,0,204,
        206,1,0,0,0,205,207,3,14,7,0,206,205,1,0,0,0,206,207,1,0,0,0,207,
        209,1,0,0,0,208,210,3,14,7,0,209,208,1,0,0,0,209,210,1,0,0,0,210,
        212,1,0,0,0,211,213,3,14,7,0,212,211,1,0,0,0,212,213,1,0,0,0,213,
        217,1,0,0,0,214,216,3,18,9,0,215,214,1,0,0,0,216,219,1,0,0,0,217,
        215,1,0,0,0,217,218,1,0,0,0,218,220,1,0,0,0,219,217,1,0,0,0,220,
        221,7,5,0,0,221,9,1,0,0,0,222,224,5,1,0,0,223,222,1,0,0,0,223,224,
        1,0,0,0,224,226,1,0,0,0,225,227,7,0,0,0,226,225,1,0,0,0,226,227,
        1,0,0,0,227,244,1,0,0,0,228,229,7,1,0,0,229,230,7,2,0,0,230,231,
        7,6,0,0,231,232,7,8,0,0,232,233,5,26,0,0,233,234,5,27,0,0,234,235,
        5,28,0,0,235,245,5,29,0,0,236,237,7,3,0,0,237,238,5,27,0,0,238,239,
        5,28,0,0,239,240,5,29,0,0,240,241,7,7,0,0,241,242,7,2,0,0,242,243,
        7,6,0,0,243,245,7,8,0,0,244,228,1,0,0,0,244,236,1,0,0,0,245,247,
        1,0,0,0,246,248,5,30,0,0,247,246,1,0,0,0,247,248,1,0,0,0,248,250,
        1,0,0,0,249,251,5,31,0,0,250,249,1,0,0,0,250,251,1,0,0,0,251,253,
        1,0,0,0,252,254,5,32,0,0,253,252,1,0,0,0,253,254,1,0,0,0,254,256,
        1,0,0,0,255,257,5,33,0,0,256,255,1,0,0,0,256,257,1,0,0,0,257,259,
        1,0,0,0,258,260,5,34,0,0,259,258,1,0,0,0,259,260,1,0,0,0,260,262,
        1,0,0,0,261,263,5,35,0,0,262,261,1,0,0,0,262,263,1,0,0,0,263,265,
        1,0,0,0,264,266,5,36,0,0,265,264,1,0,0,0,265,266,1,0,0,0,266,268,
        1,0,0,0,267,269,5,37,0,0,268,267,1,0,0,0,268,269,1,0,0,0,269,271,
        1,0,0,0,270,272,5,38,0,0,271,270,1,0,0,0,271,272,1,0,0,0,272,274,
        1,0,0,0,273,275,5,39,0,0,274,273,1,0,0,0,274,275,1,0,0,0,275,276,
        1,0,0,0,276,278,5,41,0,0,277,279,3,12,6,0,278,277,1,0,0,0,279,280,
        1,0,0,0,280,278,1,0,0,0,280,281,1,0,0,0,281,11,1,0,0,0,282,284,5,
        6,0,0,283,282,1,0,0,0,283,284,1,0,0,0,284,286,1,0,0,0,285,287,5,
        6,0,0,286,285,1,0,0,0,286,287,1,0,0,0,287,306,1,0,0,0,288,289,3,
        14,7,0,289,290,3,14,7,0,290,291,3,14,7,0,291,292,3,14,7,0,292,293,
        5,11,0,0,293,294,5,11,0,0,294,295,5,11,0,0,295,296,5,11,0,0,296,
        307,1,0,0,0,297,298,5,11,0,0,298,299,5,11,0,0,299,300,5,11,0,0,300,
        301,5,11,0,0,301,302,3,14,7,0,302,303,3,14,7,0,303,304,3,14,7,0,
        304,305,3,14,7,0,305,307,1,0,0,0,306,288,1,0,0,0,306,297,1,0,0,0,
        307,309,1,0,0,0,308,310,3,16,8,0,309,308,1,0,0,0,309,310,1,0,0,0,
        310,312,1,0,0,0,311,313,3,16,8,0,312,311,1,0,0,0,312,313,1,0,0,0,
        313,315,1,0,0,0,314,316,3,14,7,0,315,314,1,0,0,0,315,316,1,0,0,0,
        316,318,1,0,0,0,317,319,3,14,7,0,318,317,1,0,0,0,318,319,1,0,0,0,
        319,321,1,0,0,0,320,322,3,14,7,0,321,320,1,0,0,0,321,322,1,0,0,0,
        322,324,1,0,0,0,323,325,3,14,7,0,324,323,1,0,0,0,324,325,1,0,0,0,
        325,327,1,0,0,0,326,328,3,14,7,0,327,326,1,0,0,0,327,328,1,0,0,0,
        328,332,1,0,0,0,329,331,3,18,9,0,330,329,1,0,0,0,331,334,1,0,0,0,
        332,330,1,0,0,0,332,333,1,0,0,0,333,335,1,0,0,0,334,332,1,0,0,0,
        335,336,7,5,0,0,336,13,1,0,0,0,337,338,7,9,0,0,338,15,1,0,0,0,339,
        340,7,9,0,0,340,17,1,0,0,0,341,342,7,10,0,0,342,19,1,0,0,0,72,21,
        27,29,35,38,48,51,54,57,60,63,66,69,72,78,81,84,96,99,102,105,108,
        111,116,122,125,139,142,145,148,151,154,157,160,163,166,172,175,
        178,194,197,200,203,206,209,212,217,223,226,244,247,250,253,256,
        259,262,265,268,271,274,280,283,286,306,309,312,315,318,321,324,
        327,332
    ]

class CcpnPKParser ( Parser ):

    grammarFileName = "CcpnPKParser.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'Number'", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "'Position F2'", 
                     "'Position F3'", "'Position F4'", "<INVALID>", "'Shift F2'", 
                     "'Shift F3'", "'Shift F4'", "<INVALID>", "'Assign F2'", 
                     "'Assign F3'", "'Assign F4'", "'Height'", "'Volume'", 
                     "'Line Width F1 (Hz)'", "'Line Width F2 (Hz)'", "'Line Width F3 (Hz)'", 
                     "'Line Width F4 (Hz)'", "'Merit'", "'Details'", "'Fit Method'", 
                     "'Vol. Method'" ]

    symbolicNames = [ "<INVALID>", "Num", "Id", "Assign_F1", "Position_F1", 
                      "Shift_F1", "Integer", "Float", "Real", "EXCLM_COMMENT", 
                      "SMCLN_COMMENT", "Simple_name", "Any_name", "SPACE", 
                      "RETURN", "SECTION_COMMENT", "LINE_COMMENT", "Id_", 
                      "Position_F1_", "Position_F2", "Position_F3", "Position_F4", 
                      "Shift_F1_", "Shift_F2", "Shift_F3", "Shift_F4", "Assign_F1_", 
                      "Assign_F2", "Assign_F3", "Assign_F4", "Height", "Volume", 
                      "Line_width_F1", "Line_width_F2", "Line_width_F3", 
                      "Line_width_F4", "Merit", "Details", "Fit_method", 
                      "Vol_method", "SPACE_VARS", "RETURN_VARS" ]

    RULE_ccpn_pk = 0
    RULE_peak_list_2d = 1
    RULE_peak_2d = 2
    RULE_peak_list_3d = 3
    RULE_peak_3d = 4
    RULE_peak_list_4d = 5
    RULE_peak_4d = 6
    RULE_position = 7
    RULE_number = 8
    RULE_note = 9

    ruleNames =  [ "ccpn_pk", "peak_list_2d", "peak_2d", "peak_list_3d", 
                   "peak_3d", "peak_list_4d", "peak_4d", "position", "number", 
                   "note" ]

    EOF = Token.EOF
    Num=1
    Id=2
    Assign_F1=3
    Position_F1=4
    Shift_F1=5
    Integer=6
    Float=7
    Real=8
    EXCLM_COMMENT=9
    SMCLN_COMMENT=10
    Simple_name=11
    Any_name=12
    SPACE=13
    RETURN=14
    SECTION_COMMENT=15
    LINE_COMMENT=16
    Id_=17
    Position_F1_=18
    Position_F2=19
    Position_F3=20
    Position_F4=21
    Shift_F1_=22
    Shift_F2=23
    Shift_F3=24
    Shift_F4=25
    Assign_F1_=26
    Assign_F2=27
    Assign_F3=28
    Assign_F4=29
    Height=30
    Volume=31
    Line_width_F1=32
    Line_width_F2=33
    Line_width_F3=34
    Line_width_F4=35
    Merit=36
    Details=37
    Fit_method=38
    Vol_method=39
    SPACE_VARS=40
    RETURN_VARS=41

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.0")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class Ccpn_pkContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(CcpnPKParser.EOF, 0)

        def RETURN(self, i:int=None):
            if i is None:
                return self.getTokens(CcpnPKParser.RETURN)
            else:
                return self.getToken(CcpnPKParser.RETURN, i)

        def peak_list_2d(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CcpnPKParser.Peak_list_2dContext)
            else:
                return self.getTypedRuleContext(CcpnPKParser.Peak_list_2dContext,i)


        def peak_list_3d(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CcpnPKParser.Peak_list_3dContext)
            else:
                return self.getTypedRuleContext(CcpnPKParser.Peak_list_3dContext,i)


        def peak_list_4d(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CcpnPKParser.Peak_list_4dContext)
            else:
                return self.getTypedRuleContext(CcpnPKParser.Peak_list_4dContext,i)


        def getRuleIndex(self):
            return CcpnPKParser.RULE_ccpn_pk

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCcpn_pk" ):
                listener.enterCcpn_pk(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCcpn_pk" ):
                listener.exitCcpn_pk(self)




    def ccpn_pk(self):

        localctx = CcpnPKParser.Ccpn_pkContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_ccpn_pk)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 21
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,0,self._ctx)
            if la_ == 1:
                self.state = 20
                self.match(CcpnPKParser.RETURN)


            self.state = 29
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 71712830) != 0):
                self.state = 27
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
                if la_ == 1:
                    self.state = 23
                    self.peak_list_2d()
                    pass

                elif la_ == 2:
                    self.state = 24
                    self.peak_list_3d()
                    pass

                elif la_ == 3:
                    self.state = 25
                    self.peak_list_4d()
                    pass

                elif la_ == 4:
                    self.state = 26
                    self.match(CcpnPKParser.RETURN)
                    pass


                self.state = 31
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 32
            self.match(CcpnPKParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Peak_list_2dContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def RETURN_VARS(self):
            return self.getToken(CcpnPKParser.RETURN_VARS, 0)

        def Num(self):
            return self.getToken(CcpnPKParser.Num, 0)

        def Height(self):
            return self.getToken(CcpnPKParser.Height, 0)

        def Volume(self):
            return self.getToken(CcpnPKParser.Volume, 0)

        def Line_width_F1(self):
            return self.getToken(CcpnPKParser.Line_width_F1, 0)

        def Line_width_F2(self):
            return self.getToken(CcpnPKParser.Line_width_F2, 0)

        def Merit(self):
            return self.getToken(CcpnPKParser.Merit, 0)

        def Details(self):
            return self.getToken(CcpnPKParser.Details, 0)

        def Fit_method(self):
            return self.getToken(CcpnPKParser.Fit_method, 0)

        def Vol_method(self):
            return self.getToken(CcpnPKParser.Vol_method, 0)

        def peak_2d(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CcpnPKParser.Peak_2dContext)
            else:
                return self.getTypedRuleContext(CcpnPKParser.Peak_2dContext,i)


        def Id(self):
            return self.getToken(CcpnPKParser.Id, 0)

        def Id_(self):
            return self.getToken(CcpnPKParser.Id_, 0)

        def Assign_F1_(self):
            return self.getToken(CcpnPKParser.Assign_F1_, 0)

        def Assign_F2(self):
            return self.getToken(CcpnPKParser.Assign_F2, 0)

        def Position_F1(self):
            return self.getToken(CcpnPKParser.Position_F1, 0)

        def Shift_F1(self):
            return self.getToken(CcpnPKParser.Shift_F1, 0)

        def Position_F1_(self):
            return self.getToken(CcpnPKParser.Position_F1_, 0)

        def Shift_F1_(self):
            return self.getToken(CcpnPKParser.Shift_F1_, 0)

        def Position_F2(self):
            return self.getToken(CcpnPKParser.Position_F2, 0)

        def Shift_F2(self):
            return self.getToken(CcpnPKParser.Shift_F2, 0)

        def Assign_F1(self):
            return self.getToken(CcpnPKParser.Assign_F1, 0)

        def getRuleIndex(self):
            return CcpnPKParser.RULE_peak_list_2d

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPeak_list_2d" ):
                listener.enterPeak_list_2d(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPeak_list_2d" ):
                listener.exitPeak_list_2d(self)




    def peak_list_2d(self):

        localctx = CcpnPKParser.Peak_list_2dContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_peak_list_2d)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 35
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==1:
                self.state = 34
                self.match(CcpnPKParser.Num)


            self.state = 38
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==2 or _la==17:
                self.state = 37
                _la = self._input.LA(1)
                if not(_la==2 or _la==17):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()


            self.state = 48
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [4, 5, 18, 22]:
                self.state = 40
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 4456496) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 41
                _la = self._input.LA(1)
                if not(_la==19 or _la==23):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 42
                self.match(CcpnPKParser.Assign_F1_)
                self.state = 43
                self.match(CcpnPKParser.Assign_F2)
                pass
            elif token in [3, 26]:
                self.state = 44
                _la = self._input.LA(1)
                if not(_la==3 or _la==26):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 45
                self.match(CcpnPKParser.Assign_F2)
                self.state = 46
                _la = self._input.LA(1)
                if not(_la==18 or _la==22):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 47
                _la = self._input.LA(1)
                if not(_la==19 or _la==23):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                pass
            else:
                raise NoViableAltException(self)

            self.state = 51
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==30:
                self.state = 50
                self.match(CcpnPKParser.Height)


            self.state = 54
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==31:
                self.state = 53
                self.match(CcpnPKParser.Volume)


            self.state = 57
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==32:
                self.state = 56
                self.match(CcpnPKParser.Line_width_F1)


            self.state = 60
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==33:
                self.state = 59
                self.match(CcpnPKParser.Line_width_F2)


            self.state = 63
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==36:
                self.state = 62
                self.match(CcpnPKParser.Merit)


            self.state = 66
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==37:
                self.state = 65
                self.match(CcpnPKParser.Details)


            self.state = 69
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==38:
                self.state = 68
                self.match(CcpnPKParser.Fit_method)


            self.state = 72
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==39:
                self.state = 71
                self.match(CcpnPKParser.Vol_method)


            self.state = 74
            self.match(CcpnPKParser.RETURN_VARS)
            self.state = 76 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 75
                self.peak_2d()
                self.state = 78 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 2496) != 0)):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Peak_2dContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def RETURN(self):
            return self.getToken(CcpnPKParser.RETURN, 0)

        def EOF(self):
            return self.getToken(CcpnPKParser.EOF, 0)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(CcpnPKParser.Integer)
            else:
                return self.getToken(CcpnPKParser.Integer, i)

        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CcpnPKParser.NumberContext)
            else:
                return self.getTypedRuleContext(CcpnPKParser.NumberContext,i)


        def position(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CcpnPKParser.PositionContext)
            else:
                return self.getTypedRuleContext(CcpnPKParser.PositionContext,i)


        def note(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CcpnPKParser.NoteContext)
            else:
                return self.getTypedRuleContext(CcpnPKParser.NoteContext,i)


        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(CcpnPKParser.Simple_name)
            else:
                return self.getToken(CcpnPKParser.Simple_name, i)

        def getRuleIndex(self):
            return CcpnPKParser.RULE_peak_2d

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPeak_2d" ):
                listener.enterPeak_2d(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPeak_2d" ):
                listener.exitPeak_2d(self)




    def peak_2d(self):

        localctx = CcpnPKParser.Peak_2dContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_peak_2d)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 81
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,15,self._ctx)
            if la_ == 1:
                self.state = 80
                self.match(CcpnPKParser.Integer)


            self.state = 84
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,16,self._ctx)
            if la_ == 1:
                self.state = 83
                self.match(CcpnPKParser.Integer)


            self.state = 96
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,17,self._ctx)
            if la_ == 1:
                self.state = 86
                self.position()
                self.state = 87
                self.position()
                self.state = 88
                self.match(CcpnPKParser.Simple_name)
                self.state = 89
                self.match(CcpnPKParser.Simple_name)
                pass

            elif la_ == 2:
                self.state = 91
                self.match(CcpnPKParser.Simple_name)
                self.state = 92
                self.match(CcpnPKParser.Simple_name)
                self.state = 93
                self.position()
                self.state = 94
                self.position()
                pass


            self.state = 99
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,18,self._ctx)
            if la_ == 1:
                self.state = 98
                self.number()


            self.state = 102
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,19,self._ctx)
            if la_ == 1:
                self.state = 101
                self.number()


            self.state = 105
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,20,self._ctx)
            if la_ == 1:
                self.state = 104
                self.position()


            self.state = 108
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,21,self._ctx)
            if la_ == 1:
                self.state = 107
                self.position()


            self.state = 111
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,22,self._ctx)
            if la_ == 1:
                self.state = 110
                self.position()


            self.state = 116
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 6592) != 0):
                self.state = 113
                self.note()
                self.state = 118
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 119
            _la = self._input.LA(1)
            if not(_la==-1 or _la==14):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Peak_list_3dContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def RETURN_VARS(self):
            return self.getToken(CcpnPKParser.RETURN_VARS, 0)

        def Num(self):
            return self.getToken(CcpnPKParser.Num, 0)

        def Height(self):
            return self.getToken(CcpnPKParser.Height, 0)

        def Volume(self):
            return self.getToken(CcpnPKParser.Volume, 0)

        def Line_width_F1(self):
            return self.getToken(CcpnPKParser.Line_width_F1, 0)

        def Line_width_F2(self):
            return self.getToken(CcpnPKParser.Line_width_F2, 0)

        def Line_width_F3(self):
            return self.getToken(CcpnPKParser.Line_width_F3, 0)

        def Merit(self):
            return self.getToken(CcpnPKParser.Merit, 0)

        def Details(self):
            return self.getToken(CcpnPKParser.Details, 0)

        def Fit_method(self):
            return self.getToken(CcpnPKParser.Fit_method, 0)

        def Vol_method(self):
            return self.getToken(CcpnPKParser.Vol_method, 0)

        def peak_3d(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CcpnPKParser.Peak_3dContext)
            else:
                return self.getTypedRuleContext(CcpnPKParser.Peak_3dContext,i)


        def Id(self):
            return self.getToken(CcpnPKParser.Id, 0)

        def Id_(self):
            return self.getToken(CcpnPKParser.Id_, 0)

        def Assign_F1_(self):
            return self.getToken(CcpnPKParser.Assign_F1_, 0)

        def Assign_F2(self):
            return self.getToken(CcpnPKParser.Assign_F2, 0)

        def Assign_F3(self):
            return self.getToken(CcpnPKParser.Assign_F3, 0)

        def Position_F1(self):
            return self.getToken(CcpnPKParser.Position_F1, 0)

        def Shift_F1(self):
            return self.getToken(CcpnPKParser.Shift_F1, 0)

        def Position_F1_(self):
            return self.getToken(CcpnPKParser.Position_F1_, 0)

        def Shift_F1_(self):
            return self.getToken(CcpnPKParser.Shift_F1_, 0)

        def Position_F2(self):
            return self.getToken(CcpnPKParser.Position_F2, 0)

        def Shift_F2(self):
            return self.getToken(CcpnPKParser.Shift_F2, 0)

        def Position_F3(self):
            return self.getToken(CcpnPKParser.Position_F3, 0)

        def Shift_F3(self):
            return self.getToken(CcpnPKParser.Shift_F3, 0)

        def Assign_F1(self):
            return self.getToken(CcpnPKParser.Assign_F1, 0)

        def getRuleIndex(self):
            return CcpnPKParser.RULE_peak_list_3d

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPeak_list_3d" ):
                listener.enterPeak_list_3d(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPeak_list_3d" ):
                listener.exitPeak_list_3d(self)




    def peak_list_3d(self):

        localctx = CcpnPKParser.Peak_list_3dContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_peak_list_3d)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 122
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==1:
                self.state = 121
                self.match(CcpnPKParser.Num)


            self.state = 125
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==2 or _la==17:
                self.state = 124
                _la = self._input.LA(1)
                if not(_la==2 or _la==17):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()


            self.state = 139
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [4, 5, 18, 22]:
                self.state = 127
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 4456496) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 128
                _la = self._input.LA(1)
                if not(_la==19 or _la==23):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 129
                _la = self._input.LA(1)
                if not(_la==20 or _la==24):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 130
                self.match(CcpnPKParser.Assign_F1_)
                self.state = 131
                self.match(CcpnPKParser.Assign_F2)
                self.state = 132
                self.match(CcpnPKParser.Assign_F3)
                pass
            elif token in [3, 26]:
                self.state = 133
                _la = self._input.LA(1)
                if not(_la==3 or _la==26):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 134
                self.match(CcpnPKParser.Assign_F2)
                self.state = 135
                self.match(CcpnPKParser.Assign_F3)
                self.state = 136
                _la = self._input.LA(1)
                if not(_la==5 or _la==18):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 137
                _la = self._input.LA(1)
                if not(_la==19 or _la==23):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 138
                _la = self._input.LA(1)
                if not(_la==20 or _la==24):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                pass
            else:
                raise NoViableAltException(self)

            self.state = 142
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==30:
                self.state = 141
                self.match(CcpnPKParser.Height)


            self.state = 145
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==31:
                self.state = 144
                self.match(CcpnPKParser.Volume)


            self.state = 148
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==32:
                self.state = 147
                self.match(CcpnPKParser.Line_width_F1)


            self.state = 151
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==33:
                self.state = 150
                self.match(CcpnPKParser.Line_width_F2)


            self.state = 154
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==34:
                self.state = 153
                self.match(CcpnPKParser.Line_width_F3)


            self.state = 157
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==36:
                self.state = 156
                self.match(CcpnPKParser.Merit)


            self.state = 160
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==37:
                self.state = 159
                self.match(CcpnPKParser.Details)


            self.state = 163
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==38:
                self.state = 162
                self.match(CcpnPKParser.Fit_method)


            self.state = 166
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==39:
                self.state = 165
                self.match(CcpnPKParser.Vol_method)


            self.state = 168
            self.match(CcpnPKParser.RETURN_VARS)
            self.state = 170 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 169
                self.peak_3d()
                self.state = 172 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 2496) != 0)):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Peak_3dContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def RETURN(self):
            return self.getToken(CcpnPKParser.RETURN, 0)

        def EOF(self):
            return self.getToken(CcpnPKParser.EOF, 0)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(CcpnPKParser.Integer)
            else:
                return self.getToken(CcpnPKParser.Integer, i)

        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CcpnPKParser.NumberContext)
            else:
                return self.getTypedRuleContext(CcpnPKParser.NumberContext,i)


        def position(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CcpnPKParser.PositionContext)
            else:
                return self.getTypedRuleContext(CcpnPKParser.PositionContext,i)


        def note(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CcpnPKParser.NoteContext)
            else:
                return self.getTypedRuleContext(CcpnPKParser.NoteContext,i)


        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(CcpnPKParser.Simple_name)
            else:
                return self.getToken(CcpnPKParser.Simple_name, i)

        def getRuleIndex(self):
            return CcpnPKParser.RULE_peak_3d

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPeak_3d" ):
                listener.enterPeak_3d(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPeak_3d" ):
                listener.exitPeak_3d(self)




    def peak_3d(self):

        localctx = CcpnPKParser.Peak_3dContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_peak_3d)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 175
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,37,self._ctx)
            if la_ == 1:
                self.state = 174
                self.match(CcpnPKParser.Integer)


            self.state = 178
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,38,self._ctx)
            if la_ == 1:
                self.state = 177
                self.match(CcpnPKParser.Integer)


            self.state = 194
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,39,self._ctx)
            if la_ == 1:
                self.state = 180
                self.position()
                self.state = 181
                self.position()
                self.state = 182
                self.position()
                self.state = 183
                self.match(CcpnPKParser.Simple_name)
                self.state = 184
                self.match(CcpnPKParser.Simple_name)
                self.state = 185
                self.match(CcpnPKParser.Simple_name)
                pass

            elif la_ == 2:
                self.state = 187
                self.match(CcpnPKParser.Simple_name)
                self.state = 188
                self.match(CcpnPKParser.Simple_name)
                self.state = 189
                self.match(CcpnPKParser.Simple_name)
                self.state = 190
                self.position()
                self.state = 191
                self.position()
                self.state = 192
                self.position()
                pass


            self.state = 197
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,40,self._ctx)
            if la_ == 1:
                self.state = 196
                self.number()


            self.state = 200
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,41,self._ctx)
            if la_ == 1:
                self.state = 199
                self.number()


            self.state = 203
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,42,self._ctx)
            if la_ == 1:
                self.state = 202
                self.position()


            self.state = 206
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,43,self._ctx)
            if la_ == 1:
                self.state = 205
                self.position()


            self.state = 209
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,44,self._ctx)
            if la_ == 1:
                self.state = 208
                self.position()


            self.state = 212
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,45,self._ctx)
            if la_ == 1:
                self.state = 211
                self.position()


            self.state = 217
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 6592) != 0):
                self.state = 214
                self.note()
                self.state = 219
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 220
            _la = self._input.LA(1)
            if not(_la==-1 or _la==14):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Peak_list_4dContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def RETURN_VARS(self):
            return self.getToken(CcpnPKParser.RETURN_VARS, 0)

        def Num(self):
            return self.getToken(CcpnPKParser.Num, 0)

        def Height(self):
            return self.getToken(CcpnPKParser.Height, 0)

        def Volume(self):
            return self.getToken(CcpnPKParser.Volume, 0)

        def Line_width_F1(self):
            return self.getToken(CcpnPKParser.Line_width_F1, 0)

        def Line_width_F2(self):
            return self.getToken(CcpnPKParser.Line_width_F2, 0)

        def Line_width_F3(self):
            return self.getToken(CcpnPKParser.Line_width_F3, 0)

        def Line_width_F4(self):
            return self.getToken(CcpnPKParser.Line_width_F4, 0)

        def Merit(self):
            return self.getToken(CcpnPKParser.Merit, 0)

        def Details(self):
            return self.getToken(CcpnPKParser.Details, 0)

        def Fit_method(self):
            return self.getToken(CcpnPKParser.Fit_method, 0)

        def Vol_method(self):
            return self.getToken(CcpnPKParser.Vol_method, 0)

        def peak_4d(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CcpnPKParser.Peak_4dContext)
            else:
                return self.getTypedRuleContext(CcpnPKParser.Peak_4dContext,i)


        def Id(self):
            return self.getToken(CcpnPKParser.Id, 0)

        def Id_(self):
            return self.getToken(CcpnPKParser.Id_, 0)

        def Assign_F1_(self):
            return self.getToken(CcpnPKParser.Assign_F1_, 0)

        def Assign_F2(self):
            return self.getToken(CcpnPKParser.Assign_F2, 0)

        def Assign_F3(self):
            return self.getToken(CcpnPKParser.Assign_F3, 0)

        def Assign_F4(self):
            return self.getToken(CcpnPKParser.Assign_F4, 0)

        def Position_F1(self):
            return self.getToken(CcpnPKParser.Position_F1, 0)

        def Shift_F1(self):
            return self.getToken(CcpnPKParser.Shift_F1, 0)

        def Position_F1_(self):
            return self.getToken(CcpnPKParser.Position_F1_, 0)

        def Shift_F1_(self):
            return self.getToken(CcpnPKParser.Shift_F1_, 0)

        def Position_F2(self):
            return self.getToken(CcpnPKParser.Position_F2, 0)

        def Shift_F2(self):
            return self.getToken(CcpnPKParser.Shift_F2, 0)

        def Position_F3(self):
            return self.getToken(CcpnPKParser.Position_F3, 0)

        def Shift_F3(self):
            return self.getToken(CcpnPKParser.Shift_F3, 0)

        def Position_F4(self):
            return self.getToken(CcpnPKParser.Position_F4, 0)

        def Shift_F4(self):
            return self.getToken(CcpnPKParser.Shift_F4, 0)

        def Assign_F1(self):
            return self.getToken(CcpnPKParser.Assign_F1, 0)

        def getRuleIndex(self):
            return CcpnPKParser.RULE_peak_list_4d

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPeak_list_4d" ):
                listener.enterPeak_list_4d(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPeak_list_4d" ):
                listener.exitPeak_list_4d(self)




    def peak_list_4d(self):

        localctx = CcpnPKParser.Peak_list_4dContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_peak_list_4d)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 223
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==1:
                self.state = 222
                self.match(CcpnPKParser.Num)


            self.state = 226
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==2 or _la==17:
                self.state = 225
                _la = self._input.LA(1)
                if not(_la==2 or _la==17):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()


            self.state = 244
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [4, 5, 18, 22]:
                self.state = 228
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 4456496) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 229
                _la = self._input.LA(1)
                if not(_la==19 or _la==23):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 230
                _la = self._input.LA(1)
                if not(_la==20 or _la==24):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 231
                _la = self._input.LA(1)
                if not(_la==21 or _la==25):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 232
                self.match(CcpnPKParser.Assign_F1_)
                self.state = 233
                self.match(CcpnPKParser.Assign_F2)
                self.state = 234
                self.match(CcpnPKParser.Assign_F3)
                self.state = 235
                self.match(CcpnPKParser.Assign_F4)
                pass
            elif token in [3, 26]:
                self.state = 236
                _la = self._input.LA(1)
                if not(_la==3 or _la==26):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 237
                self.match(CcpnPKParser.Assign_F2)
                self.state = 238
                self.match(CcpnPKParser.Assign_F3)
                self.state = 239
                self.match(CcpnPKParser.Assign_F4)
                self.state = 240
                _la = self._input.LA(1)
                if not(_la==5 or _la==18):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 241
                _la = self._input.LA(1)
                if not(_la==19 or _la==23):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 242
                _la = self._input.LA(1)
                if not(_la==20 or _la==24):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 243
                _la = self._input.LA(1)
                if not(_la==21 or _la==25):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                pass
            else:
                raise NoViableAltException(self)

            self.state = 247
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==30:
                self.state = 246
                self.match(CcpnPKParser.Height)


            self.state = 250
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==31:
                self.state = 249
                self.match(CcpnPKParser.Volume)


            self.state = 253
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==32:
                self.state = 252
                self.match(CcpnPKParser.Line_width_F1)


            self.state = 256
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==33:
                self.state = 255
                self.match(CcpnPKParser.Line_width_F2)


            self.state = 259
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==34:
                self.state = 258
                self.match(CcpnPKParser.Line_width_F3)


            self.state = 262
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==35:
                self.state = 261
                self.match(CcpnPKParser.Line_width_F4)


            self.state = 265
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==36:
                self.state = 264
                self.match(CcpnPKParser.Merit)


            self.state = 268
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==37:
                self.state = 267
                self.match(CcpnPKParser.Details)


            self.state = 271
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==38:
                self.state = 270
                self.match(CcpnPKParser.Fit_method)


            self.state = 274
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==39:
                self.state = 273
                self.match(CcpnPKParser.Vol_method)


            self.state = 276
            self.match(CcpnPKParser.RETURN_VARS)
            self.state = 278 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 277
                self.peak_4d()
                self.state = 280 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 2496) != 0)):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Peak_4dContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def RETURN(self):
            return self.getToken(CcpnPKParser.RETURN, 0)

        def EOF(self):
            return self.getToken(CcpnPKParser.EOF, 0)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(CcpnPKParser.Integer)
            else:
                return self.getToken(CcpnPKParser.Integer, i)

        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CcpnPKParser.NumberContext)
            else:
                return self.getTypedRuleContext(CcpnPKParser.NumberContext,i)


        def position(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CcpnPKParser.PositionContext)
            else:
                return self.getTypedRuleContext(CcpnPKParser.PositionContext,i)


        def note(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CcpnPKParser.NoteContext)
            else:
                return self.getTypedRuleContext(CcpnPKParser.NoteContext,i)


        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(CcpnPKParser.Simple_name)
            else:
                return self.getToken(CcpnPKParser.Simple_name, i)

        def getRuleIndex(self):
            return CcpnPKParser.RULE_peak_4d

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPeak_4d" ):
                listener.enterPeak_4d(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPeak_4d" ):
                listener.exitPeak_4d(self)




    def peak_4d(self):

        localctx = CcpnPKParser.Peak_4dContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_peak_4d)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 283
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,61,self._ctx)
            if la_ == 1:
                self.state = 282
                self.match(CcpnPKParser.Integer)


            self.state = 286
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,62,self._ctx)
            if la_ == 1:
                self.state = 285
                self.match(CcpnPKParser.Integer)


            self.state = 306
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,63,self._ctx)
            if la_ == 1:
                self.state = 288
                self.position()
                self.state = 289
                self.position()
                self.state = 290
                self.position()
                self.state = 291
                self.position()
                self.state = 292
                self.match(CcpnPKParser.Simple_name)
                self.state = 293
                self.match(CcpnPKParser.Simple_name)
                self.state = 294
                self.match(CcpnPKParser.Simple_name)
                self.state = 295
                self.match(CcpnPKParser.Simple_name)
                pass

            elif la_ == 2:
                self.state = 297
                self.match(CcpnPKParser.Simple_name)
                self.state = 298
                self.match(CcpnPKParser.Simple_name)
                self.state = 299
                self.match(CcpnPKParser.Simple_name)
                self.state = 300
                self.match(CcpnPKParser.Simple_name)
                self.state = 301
                self.position()
                self.state = 302
                self.position()
                self.state = 303
                self.position()
                self.state = 304
                self.position()
                pass


            self.state = 309
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,64,self._ctx)
            if la_ == 1:
                self.state = 308
                self.number()


            self.state = 312
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,65,self._ctx)
            if la_ == 1:
                self.state = 311
                self.number()


            self.state = 315
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,66,self._ctx)
            if la_ == 1:
                self.state = 314
                self.position()


            self.state = 318
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,67,self._ctx)
            if la_ == 1:
                self.state = 317
                self.position()


            self.state = 321
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,68,self._ctx)
            if la_ == 1:
                self.state = 320
                self.position()


            self.state = 324
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,69,self._ctx)
            if la_ == 1:
                self.state = 323
                self.position()


            self.state = 327
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,70,self._ctx)
            if la_ == 1:
                self.state = 326
                self.position()


            self.state = 332
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 6592) != 0):
                self.state = 329
                self.note()
                self.state = 334
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 335
            _la = self._input.LA(1)
            if not(_la==-1 or _la==14):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PositionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Float(self):
            return self.getToken(CcpnPKParser.Float, 0)

        def Real(self):
            return self.getToken(CcpnPKParser.Real, 0)

        def Integer(self):
            return self.getToken(CcpnPKParser.Integer, 0)

        def Simple_name(self):
            return self.getToken(CcpnPKParser.Simple_name, 0)

        def getRuleIndex(self):
            return CcpnPKParser.RULE_position

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPosition" ):
                listener.enterPosition(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPosition" ):
                listener.exitPosition(self)




    def position(self):

        localctx = CcpnPKParser.PositionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_position)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 337
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 2496) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NumberContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Float(self):
            return self.getToken(CcpnPKParser.Float, 0)

        def Real(self):
            return self.getToken(CcpnPKParser.Real, 0)

        def Integer(self):
            return self.getToken(CcpnPKParser.Integer, 0)

        def Simple_name(self):
            return self.getToken(CcpnPKParser.Simple_name, 0)

        def getRuleIndex(self):
            return CcpnPKParser.RULE_number

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumber" ):
                listener.enterNumber(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumber" ):
                listener.exitNumber(self)




    def number(self):

        localctx = CcpnPKParser.NumberContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_number)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 339
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 2496) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NoteContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Float(self):
            return self.getToken(CcpnPKParser.Float, 0)

        def Real(self):
            return self.getToken(CcpnPKParser.Real, 0)

        def Integer(self):
            return self.getToken(CcpnPKParser.Integer, 0)

        def Simple_name(self):
            return self.getToken(CcpnPKParser.Simple_name, 0)

        def Any_name(self):
            return self.getToken(CcpnPKParser.Any_name, 0)

        def getRuleIndex(self):
            return CcpnPKParser.RULE_note

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNote" ):
                listener.enterNote(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNote" ):
                listener.exitNote(self)




    def note(self):

        localctx = CcpnPKParser.NoteContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_note)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 341
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 6592) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





