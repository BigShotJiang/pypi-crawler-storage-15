# Generated from NmrViewNPKParser.g4 by ANTLR 4.13.0
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,37,480,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,1,0,3,0,38,8,0,1,0,1,0,1,
        0,1,0,1,0,1,0,1,0,1,0,5,0,48,8,0,10,0,12,0,51,9,0,1,0,1,0,1,1,1,
        1,1,1,1,1,1,1,3,1,60,8,1,1,1,5,1,63,8,1,10,1,12,1,66,9,1,1,1,1,1,
        4,1,70,8,1,11,1,12,1,71,1,1,5,1,75,8,1,10,1,12,1,78,9,1,1,1,4,1,
        81,8,1,11,1,12,1,82,1,1,1,1,4,1,87,8,1,11,1,12,1,88,1,1,1,1,4,1,
        93,8,1,11,1,12,1,94,1,2,4,2,98,8,2,11,2,12,2,99,1,3,1,3,1,3,1,3,
        1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,3,3,120,
        8,3,1,3,1,3,3,3,124,8,3,1,3,4,3,127,8,3,11,3,12,3,128,1,4,1,4,1,
        4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,
        4,3,4,150,8,4,1,4,4,4,153,8,4,11,4,12,4,154,1,4,1,4,1,5,1,5,1,5,
        1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,
        1,5,1,5,1,5,1,5,1,5,1,5,3,5,184,8,5,1,5,1,5,3,5,188,8,5,1,5,4,5,
        191,8,5,11,5,12,5,192,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,
        6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,3,
        6,221,8,6,1,6,4,6,224,8,6,11,6,12,6,225,1,6,1,6,1,7,1,7,1,7,1,7,
        1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,
        1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,3,7,262,8,7,1,7,
        1,7,3,7,266,8,7,1,7,4,7,269,8,7,11,7,12,7,270,1,8,1,8,1,8,1,8,1,
        8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,
        8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,3,8,306,8,8,1,
        8,4,8,309,8,8,11,8,12,8,310,1,8,1,8,1,9,1,9,1,9,1,9,1,9,1,9,1,9,
        1,9,1,9,1,9,1,9,1,9,3,9,327,8,9,1,9,1,9,3,9,331,8,9,1,9,4,9,334,
        8,9,11,9,12,9,335,1,10,1,10,1,10,1,10,1,10,1,10,1,10,1,10,1,10,1,
        10,1,10,1,10,1,10,3,10,351,8,10,1,10,4,10,354,8,10,11,10,12,10,355,
        1,10,1,10,1,11,1,11,1,11,1,11,1,11,1,11,1,11,1,11,1,11,1,11,1,11,
        1,11,1,11,1,11,1,11,1,11,3,11,376,8,11,1,11,1,11,3,11,380,8,11,1,
        11,4,11,383,8,11,11,11,12,11,384,1,12,1,12,1,12,1,12,1,12,1,12,1,
        12,1,12,1,12,1,12,1,12,1,12,1,12,1,12,1,12,1,12,1,12,3,12,404,8,
        12,1,12,4,12,407,8,12,11,12,12,12,408,1,12,1,12,1,13,1,13,1,13,1,
        13,1,13,1,13,1,13,1,13,1,13,1,13,1,13,1,13,1,13,1,13,1,13,1,13,1,
        13,1,13,1,13,1,13,3,13,433,8,13,1,13,1,13,3,13,437,8,13,1,13,4,13,
        440,8,13,11,13,12,13,441,1,14,1,14,1,14,1,14,1,14,1,14,1,14,1,14,
        1,14,1,14,1,14,1,14,1,14,1,14,1,14,1,14,1,14,1,14,1,14,1,14,1,14,
        3,14,465,8,14,1,14,4,14,468,8,14,11,14,12,14,469,1,14,1,14,1,15,
        1,15,1,16,1,16,1,17,1,17,1,17,0,0,18,0,2,4,6,8,10,12,14,16,18,20,
        22,24,26,28,30,32,34,0,4,1,1,10,10,2,0,30,31,34,34,2,0,3,3,8,8,2,
        0,2,3,8,8,508,0,37,1,0,0,0,2,54,1,0,0,0,4,97,1,0,0,0,6,101,1,0,0,
        0,8,130,1,0,0,0,10,158,1,0,0,0,12,194,1,0,0,0,14,229,1,0,0,0,16,
        272,1,0,0,0,18,314,1,0,0,0,20,337,1,0,0,0,22,359,1,0,0,0,24,386,
        1,0,0,0,26,412,1,0,0,0,28,443,1,0,0,0,30,473,1,0,0,0,32,475,1,0,
        0,0,34,477,1,0,0,0,36,38,5,10,0,0,37,36,1,0,0,0,37,38,1,0,0,0,38,
        49,1,0,0,0,39,48,3,2,1,0,40,48,3,6,3,0,41,48,3,10,5,0,42,48,3,14,
        7,0,43,48,3,18,9,0,44,48,3,22,11,0,45,48,3,26,13,0,46,48,5,10,0,
        0,47,39,1,0,0,0,47,40,1,0,0,0,47,41,1,0,0,0,47,42,1,0,0,0,47,43,
        1,0,0,0,47,44,1,0,0,0,47,45,1,0,0,0,47,46,1,0,0,0,48,51,1,0,0,0,
        49,47,1,0,0,0,49,50,1,0,0,0,50,52,1,0,0,0,51,49,1,0,0,0,52,53,5,
        0,0,1,53,1,1,0,0,0,54,55,5,1,0,0,55,56,5,14,0,0,56,57,5,15,0,0,57,
        59,5,16,0,0,58,60,5,17,0,0,59,58,1,0,0,0,59,60,1,0,0,0,60,64,1,0,
        0,0,61,63,5,33,0,0,62,61,1,0,0,0,63,66,1,0,0,0,64,62,1,0,0,0,64,
        65,1,0,0,0,65,67,1,0,0,0,66,64,1,0,0,0,67,69,3,4,2,0,68,70,5,33,
        0,0,69,68,1,0,0,0,70,71,1,0,0,0,71,69,1,0,0,0,71,72,1,0,0,0,72,76,
        1,0,0,0,73,75,5,30,0,0,74,73,1,0,0,0,75,78,1,0,0,0,76,74,1,0,0,0,
        76,77,1,0,0,0,77,80,1,0,0,0,78,76,1,0,0,0,79,81,5,33,0,0,80,79,1,
        0,0,0,81,82,1,0,0,0,82,80,1,0,0,0,82,83,1,0,0,0,83,84,1,0,0,0,84,
        86,3,4,2,0,85,87,5,33,0,0,86,85,1,0,0,0,87,88,1,0,0,0,88,86,1,0,
        0,0,88,89,1,0,0,0,89,90,1,0,0,0,90,92,3,4,2,0,91,93,5,33,0,0,92,
        91,1,0,0,0,93,94,1,0,0,0,94,92,1,0,0,0,94,95,1,0,0,0,95,3,1,0,0,
        0,96,98,3,30,15,0,97,96,1,0,0,0,98,99,1,0,0,0,99,97,1,0,0,0,99,100,
        1,0,0,0,100,5,1,0,0,0,101,102,5,18,0,0,102,103,5,19,0,0,103,104,
        5,20,0,0,104,105,5,21,0,0,105,106,5,22,0,0,106,107,5,23,0,0,107,
        108,5,24,0,0,108,109,5,18,0,0,109,110,5,19,0,0,110,111,5,20,0,0,
        111,112,5,21,0,0,112,113,5,22,0,0,113,114,5,23,0,0,114,115,5,24,
        0,0,115,116,5,25,0,0,116,117,5,26,0,0,117,119,5,27,0,0,118,120,5,
        28,0,0,119,118,1,0,0,0,119,120,1,0,0,0,120,121,1,0,0,0,121,123,5,
        29,0,0,122,124,5,10,0,0,123,122,1,0,0,0,123,124,1,0,0,0,124,126,
        1,0,0,0,125,127,3,8,4,0,126,125,1,0,0,0,127,128,1,0,0,0,128,126,
        1,0,0,0,128,129,1,0,0,0,129,7,1,0,0,0,130,131,5,2,0,0,131,132,5,
        8,0,0,132,133,3,34,17,0,133,134,3,34,17,0,134,135,3,34,17,0,135,
        136,5,8,0,0,136,137,3,32,16,0,137,138,5,8,0,0,138,139,5,8,0,0,139,
        140,3,34,17,0,140,141,3,34,17,0,141,142,3,34,17,0,142,143,5,8,0,
        0,143,144,3,32,16,0,144,145,5,8,0,0,145,146,3,34,17,0,146,147,3,
        34,17,0,147,149,5,2,0,0,148,150,5,8,0,0,149,148,1,0,0,0,149,150,
        1,0,0,0,150,152,1,0,0,0,151,153,5,2,0,0,152,151,1,0,0,0,153,154,
        1,0,0,0,154,152,1,0,0,0,154,155,1,0,0,0,155,156,1,0,0,0,156,157,
        7,0,0,0,157,9,1,0,0,0,158,159,5,18,0,0,159,160,5,19,0,0,160,161,
        5,20,0,0,161,162,5,21,0,0,162,163,5,22,0,0,163,164,5,23,0,0,164,
        165,5,24,0,0,165,166,5,18,0,0,166,167,5,19,0,0,167,168,5,20,0,0,
        168,169,5,21,0,0,169,170,5,22,0,0,170,171,5,23,0,0,171,172,5,24,
        0,0,172,173,5,18,0,0,173,174,5,19,0,0,174,175,5,20,0,0,175,176,5,
        21,0,0,176,177,5,22,0,0,177,178,5,23,0,0,178,179,5,24,0,0,179,180,
        5,25,0,0,180,181,5,26,0,0,181,183,5,27,0,0,182,184,5,28,0,0,183,
        182,1,0,0,0,183,184,1,0,0,0,184,185,1,0,0,0,185,187,5,29,0,0,186,
        188,5,10,0,0,187,186,1,0,0,0,187,188,1,0,0,0,188,190,1,0,0,0,189,
        191,3,12,6,0,190,189,1,0,0,0,191,192,1,0,0,0,192,190,1,0,0,0,192,
        193,1,0,0,0,193,11,1,0,0,0,194,195,5,2,0,0,195,196,5,8,0,0,196,197,
        3,34,17,0,197,198,3,34,17,0,198,199,3,34,17,0,199,200,5,8,0,0,200,
        201,3,32,16,0,201,202,5,8,0,0,202,203,5,8,0,0,203,204,3,34,17,0,
        204,205,3,34,17,0,205,206,3,34,17,0,206,207,5,8,0,0,207,208,3,32,
        16,0,208,209,5,8,0,0,209,210,5,8,0,0,210,211,3,34,17,0,211,212,3,
        34,17,0,212,213,3,34,17,0,213,214,5,8,0,0,214,215,3,32,16,0,215,
        216,5,8,0,0,216,217,3,34,17,0,217,218,3,34,17,0,218,220,5,2,0,0,
        219,221,5,8,0,0,220,219,1,0,0,0,220,221,1,0,0,0,221,223,1,0,0,0,
        222,224,5,2,0,0,223,222,1,0,0,0,224,225,1,0,0,0,225,223,1,0,0,0,
        225,226,1,0,0,0,226,227,1,0,0,0,227,228,7,0,0,0,228,13,1,0,0,0,229,
        230,5,18,0,0,230,231,5,19,0,0,231,232,5,20,0,0,232,233,5,21,0,0,
        233,234,5,22,0,0,234,235,5,23,0,0,235,236,5,24,0,0,236,237,5,18,
        0,0,237,238,5,19,0,0,238,239,5,20,0,0,239,240,5,21,0,0,240,241,5,
        22,0,0,241,242,5,23,0,0,242,243,5,24,0,0,243,244,5,18,0,0,244,245,
        5,19,0,0,245,246,5,20,0,0,246,247,5,21,0,0,247,248,5,22,0,0,248,
        249,5,23,0,0,249,250,5,24,0,0,250,251,5,18,0,0,251,252,5,19,0,0,
        252,253,5,20,0,0,253,254,5,21,0,0,254,255,5,22,0,0,255,256,5,23,
        0,0,256,257,5,24,0,0,257,258,5,25,0,0,258,259,5,26,0,0,259,261,5,
        27,0,0,260,262,5,28,0,0,261,260,1,0,0,0,261,262,1,0,0,0,262,263,
        1,0,0,0,263,265,5,29,0,0,264,266,5,10,0,0,265,264,1,0,0,0,265,266,
        1,0,0,0,266,268,1,0,0,0,267,269,3,16,8,0,268,267,1,0,0,0,269,270,
        1,0,0,0,270,268,1,0,0,0,270,271,1,0,0,0,271,15,1,0,0,0,272,273,5,
        2,0,0,273,274,5,8,0,0,274,275,3,34,17,0,275,276,3,34,17,0,276,277,
        3,34,17,0,277,278,5,8,0,0,278,279,3,32,16,0,279,280,5,8,0,0,280,
        281,5,8,0,0,281,282,3,34,17,0,282,283,3,34,17,0,283,284,3,34,17,
        0,284,285,5,8,0,0,285,286,3,32,16,0,286,287,5,8,0,0,287,288,5,8,
        0,0,288,289,3,34,17,0,289,290,3,34,17,0,290,291,3,34,17,0,291,292,
        5,8,0,0,292,293,3,32,16,0,293,294,5,8,0,0,294,295,5,8,0,0,295,296,
        3,34,17,0,296,297,3,34,17,0,297,298,3,34,17,0,298,299,5,8,0,0,299,
        300,3,32,16,0,300,301,5,8,0,0,301,302,3,34,17,0,302,303,3,34,17,
        0,303,305,5,2,0,0,304,306,5,8,0,0,305,304,1,0,0,0,305,306,1,0,0,
        0,306,308,1,0,0,0,307,309,5,2,0,0,308,307,1,0,0,0,309,310,1,0,0,
        0,310,308,1,0,0,0,310,311,1,0,0,0,311,312,1,0,0,0,312,313,7,0,0,
        0,313,17,1,0,0,0,314,315,5,18,0,0,315,316,5,19,0,0,316,317,5,20,
        0,0,317,318,5,21,0,0,318,319,5,18,0,0,319,320,5,19,0,0,320,321,5,
        20,0,0,321,322,5,21,0,0,322,323,5,25,0,0,323,324,5,26,0,0,324,326,
        5,27,0,0,325,327,5,28,0,0,326,325,1,0,0,0,326,327,1,0,0,0,327,328,
        1,0,0,0,328,330,5,29,0,0,329,331,5,10,0,0,330,329,1,0,0,0,330,331,
        1,0,0,0,331,333,1,0,0,0,332,334,3,20,10,0,333,332,1,0,0,0,334,335,
        1,0,0,0,335,333,1,0,0,0,335,336,1,0,0,0,336,19,1,0,0,0,337,338,5,
        2,0,0,338,339,5,8,0,0,339,340,3,34,17,0,340,341,3,34,17,0,341,342,
        3,34,17,0,342,343,5,8,0,0,343,344,3,34,17,0,344,345,3,34,17,0,345,
        346,3,34,17,0,346,347,3,34,17,0,347,348,3,34,17,0,348,350,5,2,0,
        0,349,351,5,8,0,0,350,349,1,0,0,0,350,351,1,0,0,0,351,353,1,0,0,
        0,352,354,5,2,0,0,353,352,1,0,0,0,354,355,1,0,0,0,355,353,1,0,0,
        0,355,356,1,0,0,0,356,357,1,0,0,0,357,358,7,0,0,0,358,21,1,0,0,0,
        359,360,5,18,0,0,360,361,5,19,0,0,361,362,5,20,0,0,362,363,5,21,
        0,0,363,364,5,18,0,0,364,365,5,19,0,0,365,366,5,20,0,0,366,367,5,
        21,0,0,367,368,5,18,0,0,368,369,5,19,0,0,369,370,5,20,0,0,370,371,
        5,21,0,0,371,372,5,25,0,0,372,373,5,26,0,0,373,375,5,27,0,0,374,
        376,5,28,0,0,375,374,1,0,0,0,375,376,1,0,0,0,376,377,1,0,0,0,377,
        379,5,29,0,0,378,380,5,10,0,0,379,378,1,0,0,0,379,380,1,0,0,0,380,
        382,1,0,0,0,381,383,3,24,12,0,382,381,1,0,0,0,383,384,1,0,0,0,384,
        382,1,0,0,0,384,385,1,0,0,0,385,23,1,0,0,0,386,387,5,2,0,0,387,388,
        5,8,0,0,388,389,3,34,17,0,389,390,3,34,17,0,390,391,3,34,17,0,391,
        392,5,8,0,0,392,393,3,34,17,0,393,394,3,34,17,0,394,395,3,34,17,
        0,395,396,5,8,0,0,396,397,3,34,17,0,397,398,3,34,17,0,398,399,3,
        34,17,0,399,400,3,34,17,0,400,401,3,34,17,0,401,403,5,2,0,0,402,
        404,5,8,0,0,403,402,1,0,0,0,403,404,1,0,0,0,404,406,1,0,0,0,405,
        407,5,2,0,0,406,405,1,0,0,0,407,408,1,0,0,0,408,406,1,0,0,0,408,
        409,1,0,0,0,409,410,1,0,0,0,410,411,7,0,0,0,411,25,1,0,0,0,412,413,
        5,18,0,0,413,414,5,19,0,0,414,415,5,20,0,0,415,416,5,21,0,0,416,
        417,5,18,0,0,417,418,5,19,0,0,418,419,5,20,0,0,419,420,5,21,0,0,
        420,421,5,18,0,0,421,422,5,19,0,0,422,423,5,20,0,0,423,424,5,21,
        0,0,424,425,5,18,0,0,425,426,5,19,0,0,426,427,5,20,0,0,427,428,5,
        21,0,0,428,429,5,25,0,0,429,430,5,26,0,0,430,432,5,27,0,0,431,433,
        5,28,0,0,432,431,1,0,0,0,432,433,1,0,0,0,433,434,1,0,0,0,434,436,
        5,29,0,0,435,437,5,10,0,0,436,435,1,0,0,0,436,437,1,0,0,0,437,439,
        1,0,0,0,438,440,3,28,14,0,439,438,1,0,0,0,440,441,1,0,0,0,441,439,
        1,0,0,0,441,442,1,0,0,0,442,27,1,0,0,0,443,444,5,2,0,0,444,445,5,
        8,0,0,445,446,3,34,17,0,446,447,3,34,17,0,447,448,3,34,17,0,448,
        449,5,8,0,0,449,450,3,34,17,0,450,451,3,34,17,0,451,452,3,34,17,
        0,452,453,5,8,0,0,453,454,3,34,17,0,454,455,3,34,17,0,455,456,3,
        34,17,0,456,457,5,8,0,0,457,458,3,34,17,0,458,459,3,34,17,0,459,
        460,3,34,17,0,460,461,3,34,17,0,461,462,3,34,17,0,462,464,5,2,0,
        0,463,465,5,8,0,0,464,463,1,0,0,0,464,465,1,0,0,0,465,467,1,0,0,
        0,466,468,5,2,0,0,467,466,1,0,0,0,468,469,1,0,0,0,469,467,1,0,0,
        0,469,470,1,0,0,0,470,471,1,0,0,0,471,472,7,0,0,0,472,29,1,0,0,0,
        473,474,7,1,0,0,474,31,1,0,0,0,475,476,7,2,0,0,476,33,1,0,0,0,477,
        478,7,3,0,0,478,35,1,0,0,0,41,37,47,49,59,64,71,76,82,88,94,99,119,
        123,128,149,154,183,187,192,220,225,261,265,270,305,310,326,330,
        335,350,355,375,379,384,403,408,432,436,441,464,469
    ]

class NmrViewNPKParser ( Parser ):

    grammarFileName = "NmrViewNPKParser.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'label'", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "'dataset'", "'sw'", "'sf'", "'condition'", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "'vol'", "'int'", 
                     "'stat'", "'comment'", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "'\\n'" ]

    symbolicNames = [ "<INVALID>", "Label", "Integer", "Float", "Real", 
                      "SHARP_COMMENT", "EXCLM_COMMENT", "SMCLN_COMMENT", 
                      "Simple_name", "SPACE", "RETURN", "L_brace", "SECTION_COMMENT", 
                      "LINE_COMMENT", "Dataset", "Sw", "Sf", "Condition", 
                      "L_name", "P_name", "W_name", "B_name", "E_name", 
                      "J_name", "U_name", "Vol", "Int", "Stat", "Comment", 
                      "Flag0", "Simple_name_LA", "Float_LA", "SPACE_LA", 
                      "SINGLE_NL_LA", "ENCLOSE_DATA_LA", "Any_name", "SPACE_CM", 
                      "R_brace" ]

    RULE_nmrview_npk = 0
    RULE_data_label = 1
    RULE_labels = 2
    RULE_peak_list_2d = 3
    RULE_peak_2d = 4
    RULE_peak_list_3d = 5
    RULE_peak_3d = 6
    RULE_peak_list_4d = 7
    RULE_peak_4d = 8
    RULE_peak_list_wo_eju_2d = 9
    RULE_peak_wo_eju_2d = 10
    RULE_peak_list_wo_eju_3d = 11
    RULE_peak_wo_eju_3d = 12
    RULE_peak_list_wo_eju_4d = 13
    RULE_peak_wo_eju_4d = 14
    RULE_label = 15
    RULE_jcoupling = 16
    RULE_number = 17

    ruleNames =  [ "nmrview_npk", "data_label", "labels", "peak_list_2d", 
                   "peak_2d", "peak_list_3d", "peak_3d", "peak_list_4d", 
                   "peak_4d", "peak_list_wo_eju_2d", "peak_wo_eju_2d", "peak_list_wo_eju_3d", 
                   "peak_wo_eju_3d", "peak_list_wo_eju_4d", "peak_wo_eju_4d", 
                   "label", "jcoupling", "number" ]

    EOF = Token.EOF
    Label=1
    Integer=2
    Float=3
    Real=4
    SHARP_COMMENT=5
    EXCLM_COMMENT=6
    SMCLN_COMMENT=7
    Simple_name=8
    SPACE=9
    RETURN=10
    L_brace=11
    SECTION_COMMENT=12
    LINE_COMMENT=13
    Dataset=14
    Sw=15
    Sf=16
    Condition=17
    L_name=18
    P_name=19
    W_name=20
    B_name=21
    E_name=22
    J_name=23
    U_name=24
    Vol=25
    Int=26
    Stat=27
    Comment=28
    Flag0=29
    Simple_name_LA=30
    Float_LA=31
    SPACE_LA=32
    SINGLE_NL_LA=33
    ENCLOSE_DATA_LA=34
    Any_name=35
    SPACE_CM=36
    R_brace=37

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.0")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class Nmrview_npkContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(NmrViewNPKParser.EOF, 0)

        def RETURN(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.RETURN)
            else:
                return self.getToken(NmrViewNPKParser.RETURN, i)

        def data_label(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewNPKParser.Data_labelContext)
            else:
                return self.getTypedRuleContext(NmrViewNPKParser.Data_labelContext,i)


        def peak_list_2d(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewNPKParser.Peak_list_2dContext)
            else:
                return self.getTypedRuleContext(NmrViewNPKParser.Peak_list_2dContext,i)


        def peak_list_3d(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewNPKParser.Peak_list_3dContext)
            else:
                return self.getTypedRuleContext(NmrViewNPKParser.Peak_list_3dContext,i)


        def peak_list_4d(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewNPKParser.Peak_list_4dContext)
            else:
                return self.getTypedRuleContext(NmrViewNPKParser.Peak_list_4dContext,i)


        def peak_list_wo_eju_2d(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewNPKParser.Peak_list_wo_eju_2dContext)
            else:
                return self.getTypedRuleContext(NmrViewNPKParser.Peak_list_wo_eju_2dContext,i)


        def peak_list_wo_eju_3d(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewNPKParser.Peak_list_wo_eju_3dContext)
            else:
                return self.getTypedRuleContext(NmrViewNPKParser.Peak_list_wo_eju_3dContext,i)


        def peak_list_wo_eju_4d(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewNPKParser.Peak_list_wo_eju_4dContext)
            else:
                return self.getTypedRuleContext(NmrViewNPKParser.Peak_list_wo_eju_4dContext,i)


        def getRuleIndex(self):
            return NmrViewNPKParser.RULE_nmrview_npk

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNmrview_npk" ):
                listener.enterNmrview_npk(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNmrview_npk" ):
                listener.exitNmrview_npk(self)




    def nmrview_npk(self):

        localctx = NmrViewNPKParser.Nmrview_npkContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_nmrview_npk)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 37
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,0,self._ctx)
            if la_ == 1:
                self.state = 36
                self.match(NmrViewNPKParser.RETURN)


            self.state = 49
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 263170) != 0):
                self.state = 47
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
                if la_ == 1:
                    self.state = 39
                    self.data_label()
                    pass

                elif la_ == 2:
                    self.state = 40
                    self.peak_list_2d()
                    pass

                elif la_ == 3:
                    self.state = 41
                    self.peak_list_3d()
                    pass

                elif la_ == 4:
                    self.state = 42
                    self.peak_list_4d()
                    pass

                elif la_ == 5:
                    self.state = 43
                    self.peak_list_wo_eju_2d()
                    pass

                elif la_ == 6:
                    self.state = 44
                    self.peak_list_wo_eju_3d()
                    pass

                elif la_ == 7:
                    self.state = 45
                    self.peak_list_wo_eju_4d()
                    pass

                elif la_ == 8:
                    self.state = 46
                    self.match(NmrViewNPKParser.RETURN)
                    pass


                self.state = 51
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 52
            self.match(NmrViewNPKParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Data_labelContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Label(self):
            return self.getToken(NmrViewNPKParser.Label, 0)

        def Dataset(self):
            return self.getToken(NmrViewNPKParser.Dataset, 0)

        def Sw(self):
            return self.getToken(NmrViewNPKParser.Sw, 0)

        def Sf(self):
            return self.getToken(NmrViewNPKParser.Sf, 0)

        def labels(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewNPKParser.LabelsContext)
            else:
                return self.getTypedRuleContext(NmrViewNPKParser.LabelsContext,i)


        def Condition(self):
            return self.getToken(NmrViewNPKParser.Condition, 0)

        def SINGLE_NL_LA(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.SINGLE_NL_LA)
            else:
                return self.getToken(NmrViewNPKParser.SINGLE_NL_LA, i)

        def Simple_name_LA(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.Simple_name_LA)
            else:
                return self.getToken(NmrViewNPKParser.Simple_name_LA, i)

        def getRuleIndex(self):
            return NmrViewNPKParser.RULE_data_label

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterData_label" ):
                listener.enterData_label(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitData_label" ):
                listener.exitData_label(self)




    def data_label(self):

        localctx = NmrViewNPKParser.Data_labelContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_data_label)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 54
            self.match(NmrViewNPKParser.Label)
            self.state = 55
            self.match(NmrViewNPKParser.Dataset)
            self.state = 56
            self.match(NmrViewNPKParser.Sw)
            self.state = 57
            self.match(NmrViewNPKParser.Sf)
            self.state = 59
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==17:
                self.state = 58
                self.match(NmrViewNPKParser.Condition)


            self.state = 64
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==33:
                self.state = 61
                self.match(NmrViewNPKParser.SINGLE_NL_LA)
                self.state = 66
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 67
            self.labels()
            self.state = 69 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 68
                    self.match(NmrViewNPKParser.SINGLE_NL_LA)

                else:
                    raise NoViableAltException(self)
                self.state = 71 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,5,self._ctx)

            self.state = 76
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==30:
                self.state = 73
                self.match(NmrViewNPKParser.Simple_name_LA)
                self.state = 78
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 80 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 79
                self.match(NmrViewNPKParser.SINGLE_NL_LA)
                self.state = 82 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==33):
                    break

            self.state = 84
            self.labels()
            self.state = 86 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 85
                self.match(NmrViewNPKParser.SINGLE_NL_LA)
                self.state = 88 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==33):
                    break

            self.state = 90
            self.labels()
            self.state = 92 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 91
                self.match(NmrViewNPKParser.SINGLE_NL_LA)
                self.state = 94 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==33):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LabelsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def label(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewNPKParser.LabelContext)
            else:
                return self.getTypedRuleContext(NmrViewNPKParser.LabelContext,i)


        def getRuleIndex(self):
            return NmrViewNPKParser.RULE_labels

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLabels" ):
                listener.enterLabels(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLabels" ):
                listener.exitLabels(self)




    def labels(self):

        localctx = NmrViewNPKParser.LabelsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_labels)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 97 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 96
                self.label()
                self.state = 99 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 20401094656) != 0)):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Peak_list_2dContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.L_name)
            else:
                return self.getToken(NmrViewNPKParser.L_name, i)

        def P_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.P_name)
            else:
                return self.getToken(NmrViewNPKParser.P_name, i)

        def W_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.W_name)
            else:
                return self.getToken(NmrViewNPKParser.W_name, i)

        def B_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.B_name)
            else:
                return self.getToken(NmrViewNPKParser.B_name, i)

        def E_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.E_name)
            else:
                return self.getToken(NmrViewNPKParser.E_name, i)

        def J_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.J_name)
            else:
                return self.getToken(NmrViewNPKParser.J_name, i)

        def U_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.U_name)
            else:
                return self.getToken(NmrViewNPKParser.U_name, i)

        def Vol(self):
            return self.getToken(NmrViewNPKParser.Vol, 0)

        def Int(self):
            return self.getToken(NmrViewNPKParser.Int, 0)

        def Stat(self):
            return self.getToken(NmrViewNPKParser.Stat, 0)

        def Flag0(self):
            return self.getToken(NmrViewNPKParser.Flag0, 0)

        def Comment(self):
            return self.getToken(NmrViewNPKParser.Comment, 0)

        def RETURN(self):
            return self.getToken(NmrViewNPKParser.RETURN, 0)

        def peak_2d(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewNPKParser.Peak_2dContext)
            else:
                return self.getTypedRuleContext(NmrViewNPKParser.Peak_2dContext,i)


        def getRuleIndex(self):
            return NmrViewNPKParser.RULE_peak_list_2d

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPeak_list_2d" ):
                listener.enterPeak_list_2d(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPeak_list_2d" ):
                listener.exitPeak_list_2d(self)




    def peak_list_2d(self):

        localctx = NmrViewNPKParser.Peak_list_2dContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_peak_list_2d)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 101
            self.match(NmrViewNPKParser.L_name)
            self.state = 102
            self.match(NmrViewNPKParser.P_name)
            self.state = 103
            self.match(NmrViewNPKParser.W_name)
            self.state = 104
            self.match(NmrViewNPKParser.B_name)
            self.state = 105
            self.match(NmrViewNPKParser.E_name)
            self.state = 106
            self.match(NmrViewNPKParser.J_name)
            self.state = 107
            self.match(NmrViewNPKParser.U_name)
            self.state = 108
            self.match(NmrViewNPKParser.L_name)
            self.state = 109
            self.match(NmrViewNPKParser.P_name)
            self.state = 110
            self.match(NmrViewNPKParser.W_name)
            self.state = 111
            self.match(NmrViewNPKParser.B_name)
            self.state = 112
            self.match(NmrViewNPKParser.E_name)
            self.state = 113
            self.match(NmrViewNPKParser.J_name)
            self.state = 114
            self.match(NmrViewNPKParser.U_name)
            self.state = 115
            self.match(NmrViewNPKParser.Vol)
            self.state = 116
            self.match(NmrViewNPKParser.Int)
            self.state = 117
            self.match(NmrViewNPKParser.Stat)
            self.state = 119
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==28:
                self.state = 118
                self.match(NmrViewNPKParser.Comment)


            self.state = 121
            self.match(NmrViewNPKParser.Flag0)
            self.state = 123
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==10:
                self.state = 122
                self.match(NmrViewNPKParser.RETURN)


            self.state = 126 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 125
                self.peak_2d()
                self.state = 128 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==2):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Peak_2dContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.Integer)
            else:
                return self.getToken(NmrViewNPKParser.Integer, i)

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.Simple_name)
            else:
                return self.getToken(NmrViewNPKParser.Simple_name, i)

        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewNPKParser.NumberContext)
            else:
                return self.getTypedRuleContext(NmrViewNPKParser.NumberContext,i)


        def jcoupling(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewNPKParser.JcouplingContext)
            else:
                return self.getTypedRuleContext(NmrViewNPKParser.JcouplingContext,i)


        def RETURN(self):
            return self.getToken(NmrViewNPKParser.RETURN, 0)

        def EOF(self):
            return self.getToken(NmrViewNPKParser.EOF, 0)

        def getRuleIndex(self):
            return NmrViewNPKParser.RULE_peak_2d

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPeak_2d" ):
                listener.enterPeak_2d(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPeak_2d" ):
                listener.exitPeak_2d(self)




    def peak_2d(self):

        localctx = NmrViewNPKParser.Peak_2dContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_peak_2d)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 130
            self.match(NmrViewNPKParser.Integer)
            self.state = 131
            self.match(NmrViewNPKParser.Simple_name)
            self.state = 132
            self.number()
            self.state = 133
            self.number()
            self.state = 134
            self.number()
            self.state = 135
            self.match(NmrViewNPKParser.Simple_name)
            self.state = 136
            self.jcoupling()
            self.state = 137
            self.match(NmrViewNPKParser.Simple_name)
            self.state = 138
            self.match(NmrViewNPKParser.Simple_name)
            self.state = 139
            self.number()
            self.state = 140
            self.number()
            self.state = 141
            self.number()
            self.state = 142
            self.match(NmrViewNPKParser.Simple_name)
            self.state = 143
            self.jcoupling()
            self.state = 144
            self.match(NmrViewNPKParser.Simple_name)
            self.state = 145
            self.number()
            self.state = 146
            self.number()
            self.state = 147
            self.match(NmrViewNPKParser.Integer)
            self.state = 149
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==8:
                self.state = 148
                self.match(NmrViewNPKParser.Simple_name)


            self.state = 152 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 151
                self.match(NmrViewNPKParser.Integer)
                self.state = 154 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==2):
                    break

            self.state = 156
            _la = self._input.LA(1)
            if not(_la==-1 or _la==10):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Peak_list_3dContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.L_name)
            else:
                return self.getToken(NmrViewNPKParser.L_name, i)

        def P_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.P_name)
            else:
                return self.getToken(NmrViewNPKParser.P_name, i)

        def W_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.W_name)
            else:
                return self.getToken(NmrViewNPKParser.W_name, i)

        def B_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.B_name)
            else:
                return self.getToken(NmrViewNPKParser.B_name, i)

        def E_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.E_name)
            else:
                return self.getToken(NmrViewNPKParser.E_name, i)

        def J_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.J_name)
            else:
                return self.getToken(NmrViewNPKParser.J_name, i)

        def U_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.U_name)
            else:
                return self.getToken(NmrViewNPKParser.U_name, i)

        def Vol(self):
            return self.getToken(NmrViewNPKParser.Vol, 0)

        def Int(self):
            return self.getToken(NmrViewNPKParser.Int, 0)

        def Stat(self):
            return self.getToken(NmrViewNPKParser.Stat, 0)

        def Flag0(self):
            return self.getToken(NmrViewNPKParser.Flag0, 0)

        def Comment(self):
            return self.getToken(NmrViewNPKParser.Comment, 0)

        def RETURN(self):
            return self.getToken(NmrViewNPKParser.RETURN, 0)

        def peak_3d(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewNPKParser.Peak_3dContext)
            else:
                return self.getTypedRuleContext(NmrViewNPKParser.Peak_3dContext,i)


        def getRuleIndex(self):
            return NmrViewNPKParser.RULE_peak_list_3d

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPeak_list_3d" ):
                listener.enterPeak_list_3d(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPeak_list_3d" ):
                listener.exitPeak_list_3d(self)




    def peak_list_3d(self):

        localctx = NmrViewNPKParser.Peak_list_3dContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_peak_list_3d)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 158
            self.match(NmrViewNPKParser.L_name)
            self.state = 159
            self.match(NmrViewNPKParser.P_name)
            self.state = 160
            self.match(NmrViewNPKParser.W_name)
            self.state = 161
            self.match(NmrViewNPKParser.B_name)
            self.state = 162
            self.match(NmrViewNPKParser.E_name)
            self.state = 163
            self.match(NmrViewNPKParser.J_name)
            self.state = 164
            self.match(NmrViewNPKParser.U_name)
            self.state = 165
            self.match(NmrViewNPKParser.L_name)
            self.state = 166
            self.match(NmrViewNPKParser.P_name)
            self.state = 167
            self.match(NmrViewNPKParser.W_name)
            self.state = 168
            self.match(NmrViewNPKParser.B_name)
            self.state = 169
            self.match(NmrViewNPKParser.E_name)
            self.state = 170
            self.match(NmrViewNPKParser.J_name)
            self.state = 171
            self.match(NmrViewNPKParser.U_name)
            self.state = 172
            self.match(NmrViewNPKParser.L_name)
            self.state = 173
            self.match(NmrViewNPKParser.P_name)
            self.state = 174
            self.match(NmrViewNPKParser.W_name)
            self.state = 175
            self.match(NmrViewNPKParser.B_name)
            self.state = 176
            self.match(NmrViewNPKParser.E_name)
            self.state = 177
            self.match(NmrViewNPKParser.J_name)
            self.state = 178
            self.match(NmrViewNPKParser.U_name)
            self.state = 179
            self.match(NmrViewNPKParser.Vol)
            self.state = 180
            self.match(NmrViewNPKParser.Int)
            self.state = 181
            self.match(NmrViewNPKParser.Stat)
            self.state = 183
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==28:
                self.state = 182
                self.match(NmrViewNPKParser.Comment)


            self.state = 185
            self.match(NmrViewNPKParser.Flag0)
            self.state = 187
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==10:
                self.state = 186
                self.match(NmrViewNPKParser.RETURN)


            self.state = 190 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 189
                self.peak_3d()
                self.state = 192 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==2):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Peak_3dContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.Integer)
            else:
                return self.getToken(NmrViewNPKParser.Integer, i)

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.Simple_name)
            else:
                return self.getToken(NmrViewNPKParser.Simple_name, i)

        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewNPKParser.NumberContext)
            else:
                return self.getTypedRuleContext(NmrViewNPKParser.NumberContext,i)


        def jcoupling(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewNPKParser.JcouplingContext)
            else:
                return self.getTypedRuleContext(NmrViewNPKParser.JcouplingContext,i)


        def RETURN(self):
            return self.getToken(NmrViewNPKParser.RETURN, 0)

        def EOF(self):
            return self.getToken(NmrViewNPKParser.EOF, 0)

        def getRuleIndex(self):
            return NmrViewNPKParser.RULE_peak_3d

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPeak_3d" ):
                listener.enterPeak_3d(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPeak_3d" ):
                listener.exitPeak_3d(self)




    def peak_3d(self):

        localctx = NmrViewNPKParser.Peak_3dContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_peak_3d)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 194
            self.match(NmrViewNPKParser.Integer)
            self.state = 195
            self.match(NmrViewNPKParser.Simple_name)
            self.state = 196
            self.number()
            self.state = 197
            self.number()
            self.state = 198
            self.number()
            self.state = 199
            self.match(NmrViewNPKParser.Simple_name)
            self.state = 200
            self.jcoupling()
            self.state = 201
            self.match(NmrViewNPKParser.Simple_name)
            self.state = 202
            self.match(NmrViewNPKParser.Simple_name)
            self.state = 203
            self.number()
            self.state = 204
            self.number()
            self.state = 205
            self.number()
            self.state = 206
            self.match(NmrViewNPKParser.Simple_name)
            self.state = 207
            self.jcoupling()
            self.state = 208
            self.match(NmrViewNPKParser.Simple_name)
            self.state = 209
            self.match(NmrViewNPKParser.Simple_name)
            self.state = 210
            self.number()
            self.state = 211
            self.number()
            self.state = 212
            self.number()
            self.state = 213
            self.match(NmrViewNPKParser.Simple_name)
            self.state = 214
            self.jcoupling()
            self.state = 215
            self.match(NmrViewNPKParser.Simple_name)
            self.state = 216
            self.number()
            self.state = 217
            self.number()
            self.state = 218
            self.match(NmrViewNPKParser.Integer)
            self.state = 220
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==8:
                self.state = 219
                self.match(NmrViewNPKParser.Simple_name)


            self.state = 223 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 222
                self.match(NmrViewNPKParser.Integer)
                self.state = 225 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==2):
                    break

            self.state = 227
            _la = self._input.LA(1)
            if not(_la==-1 or _la==10):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Peak_list_4dContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.L_name)
            else:
                return self.getToken(NmrViewNPKParser.L_name, i)

        def P_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.P_name)
            else:
                return self.getToken(NmrViewNPKParser.P_name, i)

        def W_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.W_name)
            else:
                return self.getToken(NmrViewNPKParser.W_name, i)

        def B_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.B_name)
            else:
                return self.getToken(NmrViewNPKParser.B_name, i)

        def E_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.E_name)
            else:
                return self.getToken(NmrViewNPKParser.E_name, i)

        def J_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.J_name)
            else:
                return self.getToken(NmrViewNPKParser.J_name, i)

        def U_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.U_name)
            else:
                return self.getToken(NmrViewNPKParser.U_name, i)

        def Vol(self):
            return self.getToken(NmrViewNPKParser.Vol, 0)

        def Int(self):
            return self.getToken(NmrViewNPKParser.Int, 0)

        def Stat(self):
            return self.getToken(NmrViewNPKParser.Stat, 0)

        def Flag0(self):
            return self.getToken(NmrViewNPKParser.Flag0, 0)

        def Comment(self):
            return self.getToken(NmrViewNPKParser.Comment, 0)

        def RETURN(self):
            return self.getToken(NmrViewNPKParser.RETURN, 0)

        def peak_4d(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewNPKParser.Peak_4dContext)
            else:
                return self.getTypedRuleContext(NmrViewNPKParser.Peak_4dContext,i)


        def getRuleIndex(self):
            return NmrViewNPKParser.RULE_peak_list_4d

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPeak_list_4d" ):
                listener.enterPeak_list_4d(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPeak_list_4d" ):
                listener.exitPeak_list_4d(self)




    def peak_list_4d(self):

        localctx = NmrViewNPKParser.Peak_list_4dContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_peak_list_4d)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 229
            self.match(NmrViewNPKParser.L_name)
            self.state = 230
            self.match(NmrViewNPKParser.P_name)
            self.state = 231
            self.match(NmrViewNPKParser.W_name)
            self.state = 232
            self.match(NmrViewNPKParser.B_name)
            self.state = 233
            self.match(NmrViewNPKParser.E_name)
            self.state = 234
            self.match(NmrViewNPKParser.J_name)
            self.state = 235
            self.match(NmrViewNPKParser.U_name)
            self.state = 236
            self.match(NmrViewNPKParser.L_name)
            self.state = 237
            self.match(NmrViewNPKParser.P_name)
            self.state = 238
            self.match(NmrViewNPKParser.W_name)
            self.state = 239
            self.match(NmrViewNPKParser.B_name)
            self.state = 240
            self.match(NmrViewNPKParser.E_name)
            self.state = 241
            self.match(NmrViewNPKParser.J_name)
            self.state = 242
            self.match(NmrViewNPKParser.U_name)
            self.state = 243
            self.match(NmrViewNPKParser.L_name)
            self.state = 244
            self.match(NmrViewNPKParser.P_name)
            self.state = 245
            self.match(NmrViewNPKParser.W_name)
            self.state = 246
            self.match(NmrViewNPKParser.B_name)
            self.state = 247
            self.match(NmrViewNPKParser.E_name)
            self.state = 248
            self.match(NmrViewNPKParser.J_name)
            self.state = 249
            self.match(NmrViewNPKParser.U_name)
            self.state = 250
            self.match(NmrViewNPKParser.L_name)
            self.state = 251
            self.match(NmrViewNPKParser.P_name)
            self.state = 252
            self.match(NmrViewNPKParser.W_name)
            self.state = 253
            self.match(NmrViewNPKParser.B_name)
            self.state = 254
            self.match(NmrViewNPKParser.E_name)
            self.state = 255
            self.match(NmrViewNPKParser.J_name)
            self.state = 256
            self.match(NmrViewNPKParser.U_name)
            self.state = 257
            self.match(NmrViewNPKParser.Vol)
            self.state = 258
            self.match(NmrViewNPKParser.Int)
            self.state = 259
            self.match(NmrViewNPKParser.Stat)
            self.state = 261
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==28:
                self.state = 260
                self.match(NmrViewNPKParser.Comment)


            self.state = 263
            self.match(NmrViewNPKParser.Flag0)
            self.state = 265
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==10:
                self.state = 264
                self.match(NmrViewNPKParser.RETURN)


            self.state = 268 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 267
                self.peak_4d()
                self.state = 270 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==2):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Peak_4dContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.Integer)
            else:
                return self.getToken(NmrViewNPKParser.Integer, i)

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.Simple_name)
            else:
                return self.getToken(NmrViewNPKParser.Simple_name, i)

        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewNPKParser.NumberContext)
            else:
                return self.getTypedRuleContext(NmrViewNPKParser.NumberContext,i)


        def jcoupling(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewNPKParser.JcouplingContext)
            else:
                return self.getTypedRuleContext(NmrViewNPKParser.JcouplingContext,i)


        def RETURN(self):
            return self.getToken(NmrViewNPKParser.RETURN, 0)

        def EOF(self):
            return self.getToken(NmrViewNPKParser.EOF, 0)

        def getRuleIndex(self):
            return NmrViewNPKParser.RULE_peak_4d

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPeak_4d" ):
                listener.enterPeak_4d(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPeak_4d" ):
                listener.exitPeak_4d(self)




    def peak_4d(self):

        localctx = NmrViewNPKParser.Peak_4dContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_peak_4d)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 272
            self.match(NmrViewNPKParser.Integer)
            self.state = 273
            self.match(NmrViewNPKParser.Simple_name)
            self.state = 274
            self.number()
            self.state = 275
            self.number()
            self.state = 276
            self.number()
            self.state = 277
            self.match(NmrViewNPKParser.Simple_name)
            self.state = 278
            self.jcoupling()
            self.state = 279
            self.match(NmrViewNPKParser.Simple_name)
            self.state = 280
            self.match(NmrViewNPKParser.Simple_name)
            self.state = 281
            self.number()
            self.state = 282
            self.number()
            self.state = 283
            self.number()
            self.state = 284
            self.match(NmrViewNPKParser.Simple_name)
            self.state = 285
            self.jcoupling()
            self.state = 286
            self.match(NmrViewNPKParser.Simple_name)
            self.state = 287
            self.match(NmrViewNPKParser.Simple_name)
            self.state = 288
            self.number()
            self.state = 289
            self.number()
            self.state = 290
            self.number()
            self.state = 291
            self.match(NmrViewNPKParser.Simple_name)
            self.state = 292
            self.jcoupling()
            self.state = 293
            self.match(NmrViewNPKParser.Simple_name)
            self.state = 294
            self.match(NmrViewNPKParser.Simple_name)
            self.state = 295
            self.number()
            self.state = 296
            self.number()
            self.state = 297
            self.number()
            self.state = 298
            self.match(NmrViewNPKParser.Simple_name)
            self.state = 299
            self.jcoupling()
            self.state = 300
            self.match(NmrViewNPKParser.Simple_name)
            self.state = 301
            self.number()
            self.state = 302
            self.number()
            self.state = 303
            self.match(NmrViewNPKParser.Integer)
            self.state = 305
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==8:
                self.state = 304
                self.match(NmrViewNPKParser.Simple_name)


            self.state = 308 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 307
                self.match(NmrViewNPKParser.Integer)
                self.state = 310 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==2):
                    break

            self.state = 312
            _la = self._input.LA(1)
            if not(_la==-1 or _la==10):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Peak_list_wo_eju_2dContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.L_name)
            else:
                return self.getToken(NmrViewNPKParser.L_name, i)

        def P_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.P_name)
            else:
                return self.getToken(NmrViewNPKParser.P_name, i)

        def W_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.W_name)
            else:
                return self.getToken(NmrViewNPKParser.W_name, i)

        def B_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.B_name)
            else:
                return self.getToken(NmrViewNPKParser.B_name, i)

        def Vol(self):
            return self.getToken(NmrViewNPKParser.Vol, 0)

        def Int(self):
            return self.getToken(NmrViewNPKParser.Int, 0)

        def Stat(self):
            return self.getToken(NmrViewNPKParser.Stat, 0)

        def Flag0(self):
            return self.getToken(NmrViewNPKParser.Flag0, 0)

        def Comment(self):
            return self.getToken(NmrViewNPKParser.Comment, 0)

        def RETURN(self):
            return self.getToken(NmrViewNPKParser.RETURN, 0)

        def peak_wo_eju_2d(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewNPKParser.Peak_wo_eju_2dContext)
            else:
                return self.getTypedRuleContext(NmrViewNPKParser.Peak_wo_eju_2dContext,i)


        def getRuleIndex(self):
            return NmrViewNPKParser.RULE_peak_list_wo_eju_2d

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPeak_list_wo_eju_2d" ):
                listener.enterPeak_list_wo_eju_2d(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPeak_list_wo_eju_2d" ):
                listener.exitPeak_list_wo_eju_2d(self)




    def peak_list_wo_eju_2d(self):

        localctx = NmrViewNPKParser.Peak_list_wo_eju_2dContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_peak_list_wo_eju_2d)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 314
            self.match(NmrViewNPKParser.L_name)
            self.state = 315
            self.match(NmrViewNPKParser.P_name)
            self.state = 316
            self.match(NmrViewNPKParser.W_name)
            self.state = 317
            self.match(NmrViewNPKParser.B_name)
            self.state = 318
            self.match(NmrViewNPKParser.L_name)
            self.state = 319
            self.match(NmrViewNPKParser.P_name)
            self.state = 320
            self.match(NmrViewNPKParser.W_name)
            self.state = 321
            self.match(NmrViewNPKParser.B_name)
            self.state = 322
            self.match(NmrViewNPKParser.Vol)
            self.state = 323
            self.match(NmrViewNPKParser.Int)
            self.state = 324
            self.match(NmrViewNPKParser.Stat)
            self.state = 326
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==28:
                self.state = 325
                self.match(NmrViewNPKParser.Comment)


            self.state = 328
            self.match(NmrViewNPKParser.Flag0)
            self.state = 330
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==10:
                self.state = 329
                self.match(NmrViewNPKParser.RETURN)


            self.state = 333 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 332
                self.peak_wo_eju_2d()
                self.state = 335 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==2):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Peak_wo_eju_2dContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.Integer)
            else:
                return self.getToken(NmrViewNPKParser.Integer, i)

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.Simple_name)
            else:
                return self.getToken(NmrViewNPKParser.Simple_name, i)

        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewNPKParser.NumberContext)
            else:
                return self.getTypedRuleContext(NmrViewNPKParser.NumberContext,i)


        def RETURN(self):
            return self.getToken(NmrViewNPKParser.RETURN, 0)

        def EOF(self):
            return self.getToken(NmrViewNPKParser.EOF, 0)

        def getRuleIndex(self):
            return NmrViewNPKParser.RULE_peak_wo_eju_2d

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPeak_wo_eju_2d" ):
                listener.enterPeak_wo_eju_2d(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPeak_wo_eju_2d" ):
                listener.exitPeak_wo_eju_2d(self)




    def peak_wo_eju_2d(self):

        localctx = NmrViewNPKParser.Peak_wo_eju_2dContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_peak_wo_eju_2d)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 337
            self.match(NmrViewNPKParser.Integer)
            self.state = 338
            self.match(NmrViewNPKParser.Simple_name)
            self.state = 339
            self.number()
            self.state = 340
            self.number()
            self.state = 341
            self.number()
            self.state = 342
            self.match(NmrViewNPKParser.Simple_name)
            self.state = 343
            self.number()
            self.state = 344
            self.number()
            self.state = 345
            self.number()
            self.state = 346
            self.number()
            self.state = 347
            self.number()
            self.state = 348
            self.match(NmrViewNPKParser.Integer)
            self.state = 350
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==8:
                self.state = 349
                self.match(NmrViewNPKParser.Simple_name)


            self.state = 353 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 352
                self.match(NmrViewNPKParser.Integer)
                self.state = 355 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==2):
                    break

            self.state = 357
            _la = self._input.LA(1)
            if not(_la==-1 or _la==10):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Peak_list_wo_eju_3dContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.L_name)
            else:
                return self.getToken(NmrViewNPKParser.L_name, i)

        def P_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.P_name)
            else:
                return self.getToken(NmrViewNPKParser.P_name, i)

        def W_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.W_name)
            else:
                return self.getToken(NmrViewNPKParser.W_name, i)

        def B_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.B_name)
            else:
                return self.getToken(NmrViewNPKParser.B_name, i)

        def Vol(self):
            return self.getToken(NmrViewNPKParser.Vol, 0)

        def Int(self):
            return self.getToken(NmrViewNPKParser.Int, 0)

        def Stat(self):
            return self.getToken(NmrViewNPKParser.Stat, 0)

        def Flag0(self):
            return self.getToken(NmrViewNPKParser.Flag0, 0)

        def Comment(self):
            return self.getToken(NmrViewNPKParser.Comment, 0)

        def RETURN(self):
            return self.getToken(NmrViewNPKParser.RETURN, 0)

        def peak_wo_eju_3d(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewNPKParser.Peak_wo_eju_3dContext)
            else:
                return self.getTypedRuleContext(NmrViewNPKParser.Peak_wo_eju_3dContext,i)


        def getRuleIndex(self):
            return NmrViewNPKParser.RULE_peak_list_wo_eju_3d

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPeak_list_wo_eju_3d" ):
                listener.enterPeak_list_wo_eju_3d(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPeak_list_wo_eju_3d" ):
                listener.exitPeak_list_wo_eju_3d(self)




    def peak_list_wo_eju_3d(self):

        localctx = NmrViewNPKParser.Peak_list_wo_eju_3dContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_peak_list_wo_eju_3d)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 359
            self.match(NmrViewNPKParser.L_name)
            self.state = 360
            self.match(NmrViewNPKParser.P_name)
            self.state = 361
            self.match(NmrViewNPKParser.W_name)
            self.state = 362
            self.match(NmrViewNPKParser.B_name)
            self.state = 363
            self.match(NmrViewNPKParser.L_name)
            self.state = 364
            self.match(NmrViewNPKParser.P_name)
            self.state = 365
            self.match(NmrViewNPKParser.W_name)
            self.state = 366
            self.match(NmrViewNPKParser.B_name)
            self.state = 367
            self.match(NmrViewNPKParser.L_name)
            self.state = 368
            self.match(NmrViewNPKParser.P_name)
            self.state = 369
            self.match(NmrViewNPKParser.W_name)
            self.state = 370
            self.match(NmrViewNPKParser.B_name)
            self.state = 371
            self.match(NmrViewNPKParser.Vol)
            self.state = 372
            self.match(NmrViewNPKParser.Int)
            self.state = 373
            self.match(NmrViewNPKParser.Stat)
            self.state = 375
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==28:
                self.state = 374
                self.match(NmrViewNPKParser.Comment)


            self.state = 377
            self.match(NmrViewNPKParser.Flag0)
            self.state = 379
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==10:
                self.state = 378
                self.match(NmrViewNPKParser.RETURN)


            self.state = 382 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 381
                self.peak_wo_eju_3d()
                self.state = 384 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==2):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Peak_wo_eju_3dContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.Integer)
            else:
                return self.getToken(NmrViewNPKParser.Integer, i)

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.Simple_name)
            else:
                return self.getToken(NmrViewNPKParser.Simple_name, i)

        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewNPKParser.NumberContext)
            else:
                return self.getTypedRuleContext(NmrViewNPKParser.NumberContext,i)


        def RETURN(self):
            return self.getToken(NmrViewNPKParser.RETURN, 0)

        def EOF(self):
            return self.getToken(NmrViewNPKParser.EOF, 0)

        def getRuleIndex(self):
            return NmrViewNPKParser.RULE_peak_wo_eju_3d

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPeak_wo_eju_3d" ):
                listener.enterPeak_wo_eju_3d(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPeak_wo_eju_3d" ):
                listener.exitPeak_wo_eju_3d(self)




    def peak_wo_eju_3d(self):

        localctx = NmrViewNPKParser.Peak_wo_eju_3dContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_peak_wo_eju_3d)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 386
            self.match(NmrViewNPKParser.Integer)
            self.state = 387
            self.match(NmrViewNPKParser.Simple_name)
            self.state = 388
            self.number()
            self.state = 389
            self.number()
            self.state = 390
            self.number()
            self.state = 391
            self.match(NmrViewNPKParser.Simple_name)
            self.state = 392
            self.number()
            self.state = 393
            self.number()
            self.state = 394
            self.number()
            self.state = 395
            self.match(NmrViewNPKParser.Simple_name)
            self.state = 396
            self.number()
            self.state = 397
            self.number()
            self.state = 398
            self.number()
            self.state = 399
            self.number()
            self.state = 400
            self.number()
            self.state = 401
            self.match(NmrViewNPKParser.Integer)
            self.state = 403
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==8:
                self.state = 402
                self.match(NmrViewNPKParser.Simple_name)


            self.state = 406 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 405
                self.match(NmrViewNPKParser.Integer)
                self.state = 408 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==2):
                    break

            self.state = 410
            _la = self._input.LA(1)
            if not(_la==-1 or _la==10):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Peak_list_wo_eju_4dContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.L_name)
            else:
                return self.getToken(NmrViewNPKParser.L_name, i)

        def P_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.P_name)
            else:
                return self.getToken(NmrViewNPKParser.P_name, i)

        def W_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.W_name)
            else:
                return self.getToken(NmrViewNPKParser.W_name, i)

        def B_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.B_name)
            else:
                return self.getToken(NmrViewNPKParser.B_name, i)

        def Vol(self):
            return self.getToken(NmrViewNPKParser.Vol, 0)

        def Int(self):
            return self.getToken(NmrViewNPKParser.Int, 0)

        def Stat(self):
            return self.getToken(NmrViewNPKParser.Stat, 0)

        def Flag0(self):
            return self.getToken(NmrViewNPKParser.Flag0, 0)

        def Comment(self):
            return self.getToken(NmrViewNPKParser.Comment, 0)

        def RETURN(self):
            return self.getToken(NmrViewNPKParser.RETURN, 0)

        def peak_wo_eju_4d(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewNPKParser.Peak_wo_eju_4dContext)
            else:
                return self.getTypedRuleContext(NmrViewNPKParser.Peak_wo_eju_4dContext,i)


        def getRuleIndex(self):
            return NmrViewNPKParser.RULE_peak_list_wo_eju_4d

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPeak_list_wo_eju_4d" ):
                listener.enterPeak_list_wo_eju_4d(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPeak_list_wo_eju_4d" ):
                listener.exitPeak_list_wo_eju_4d(self)




    def peak_list_wo_eju_4d(self):

        localctx = NmrViewNPKParser.Peak_list_wo_eju_4dContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_peak_list_wo_eju_4d)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 412
            self.match(NmrViewNPKParser.L_name)
            self.state = 413
            self.match(NmrViewNPKParser.P_name)
            self.state = 414
            self.match(NmrViewNPKParser.W_name)
            self.state = 415
            self.match(NmrViewNPKParser.B_name)
            self.state = 416
            self.match(NmrViewNPKParser.L_name)
            self.state = 417
            self.match(NmrViewNPKParser.P_name)
            self.state = 418
            self.match(NmrViewNPKParser.W_name)
            self.state = 419
            self.match(NmrViewNPKParser.B_name)
            self.state = 420
            self.match(NmrViewNPKParser.L_name)
            self.state = 421
            self.match(NmrViewNPKParser.P_name)
            self.state = 422
            self.match(NmrViewNPKParser.W_name)
            self.state = 423
            self.match(NmrViewNPKParser.B_name)
            self.state = 424
            self.match(NmrViewNPKParser.L_name)
            self.state = 425
            self.match(NmrViewNPKParser.P_name)
            self.state = 426
            self.match(NmrViewNPKParser.W_name)
            self.state = 427
            self.match(NmrViewNPKParser.B_name)
            self.state = 428
            self.match(NmrViewNPKParser.Vol)
            self.state = 429
            self.match(NmrViewNPKParser.Int)
            self.state = 430
            self.match(NmrViewNPKParser.Stat)
            self.state = 432
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==28:
                self.state = 431
                self.match(NmrViewNPKParser.Comment)


            self.state = 434
            self.match(NmrViewNPKParser.Flag0)
            self.state = 436
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==10:
                self.state = 435
                self.match(NmrViewNPKParser.RETURN)


            self.state = 439 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 438
                self.peak_wo_eju_4d()
                self.state = 441 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==2):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Peak_wo_eju_4dContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.Integer)
            else:
                return self.getToken(NmrViewNPKParser.Integer, i)

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(NmrViewNPKParser.Simple_name)
            else:
                return self.getToken(NmrViewNPKParser.Simple_name, i)

        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NmrViewNPKParser.NumberContext)
            else:
                return self.getTypedRuleContext(NmrViewNPKParser.NumberContext,i)


        def RETURN(self):
            return self.getToken(NmrViewNPKParser.RETURN, 0)

        def EOF(self):
            return self.getToken(NmrViewNPKParser.EOF, 0)

        def getRuleIndex(self):
            return NmrViewNPKParser.RULE_peak_wo_eju_4d

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPeak_wo_eju_4d" ):
                listener.enterPeak_wo_eju_4d(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPeak_wo_eju_4d" ):
                listener.exitPeak_wo_eju_4d(self)




    def peak_wo_eju_4d(self):

        localctx = NmrViewNPKParser.Peak_wo_eju_4dContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_peak_wo_eju_4d)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 443
            self.match(NmrViewNPKParser.Integer)
            self.state = 444
            self.match(NmrViewNPKParser.Simple_name)
            self.state = 445
            self.number()
            self.state = 446
            self.number()
            self.state = 447
            self.number()
            self.state = 448
            self.match(NmrViewNPKParser.Simple_name)
            self.state = 449
            self.number()
            self.state = 450
            self.number()
            self.state = 451
            self.number()
            self.state = 452
            self.match(NmrViewNPKParser.Simple_name)
            self.state = 453
            self.number()
            self.state = 454
            self.number()
            self.state = 455
            self.number()
            self.state = 456
            self.match(NmrViewNPKParser.Simple_name)
            self.state = 457
            self.number()
            self.state = 458
            self.number()
            self.state = 459
            self.number()
            self.state = 460
            self.number()
            self.state = 461
            self.number()
            self.state = 462
            self.match(NmrViewNPKParser.Integer)
            self.state = 464
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==8:
                self.state = 463
                self.match(NmrViewNPKParser.Simple_name)


            self.state = 467 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 466
                self.match(NmrViewNPKParser.Integer)
                self.state = 469 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==2):
                    break

            self.state = 471
            _la = self._input.LA(1)
            if not(_la==-1 or _la==10):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LabelContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Float_LA(self):
            return self.getToken(NmrViewNPKParser.Float_LA, 0)

        def Simple_name_LA(self):
            return self.getToken(NmrViewNPKParser.Simple_name_LA, 0)

        def ENCLOSE_DATA_LA(self):
            return self.getToken(NmrViewNPKParser.ENCLOSE_DATA_LA, 0)

        def getRuleIndex(self):
            return NmrViewNPKParser.RULE_label

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLabel" ):
                listener.enterLabel(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLabel" ):
                listener.exitLabel(self)




    def label(self):

        localctx = NmrViewNPKParser.LabelContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_label)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 473
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 20401094656) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class JcouplingContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Float(self):
            return self.getToken(NmrViewNPKParser.Float, 0)

        def Simple_name(self):
            return self.getToken(NmrViewNPKParser.Simple_name, 0)

        def getRuleIndex(self):
            return NmrViewNPKParser.RULE_jcoupling

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterJcoupling" ):
                listener.enterJcoupling(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitJcoupling" ):
                listener.exitJcoupling(self)




    def jcoupling(self):

        localctx = NmrViewNPKParser.JcouplingContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_jcoupling)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 475
            _la = self._input.LA(1)
            if not(_la==3 or _la==8):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NumberContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Float(self):
            return self.getToken(NmrViewNPKParser.Float, 0)

        def Integer(self):
            return self.getToken(NmrViewNPKParser.Integer, 0)

        def Simple_name(self):
            return self.getToken(NmrViewNPKParser.Simple_name, 0)

        def getRuleIndex(self):
            return NmrViewNPKParser.RULE_number

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumber" ):
                listener.enterNumber(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumber" ):
                listener.exitNumber(self)




    def number(self):

        localctx = NmrViewNPKParser.NumberContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_number)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 477
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 268) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





