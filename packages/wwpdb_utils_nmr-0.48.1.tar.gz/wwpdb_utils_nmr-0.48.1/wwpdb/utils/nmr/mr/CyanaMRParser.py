# Generated from CyanaMRParser.g4 by ANTLR 4.13.0
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,60,648,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,26,
        2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,31,2,32,7,32,2,33,
        7,33,2,34,7,34,2,35,7,35,2,36,7,36,2,37,7,37,2,38,7,38,2,39,7,39,
        2,40,7,40,2,41,7,41,2,42,7,42,2,43,7,43,2,44,7,44,2,45,7,45,2,46,
        7,46,2,47,7,47,2,48,7,48,2,49,7,49,2,50,7,50,2,51,7,51,1,0,1,0,4,
        0,107,8,0,11,0,12,0,108,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,
        1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,
        1,0,5,0,138,8,0,10,0,12,0,141,9,0,1,0,1,0,1,1,1,1,5,1,147,8,1,10,
        1,12,1,150,9,1,1,1,1,1,1,2,4,2,155,8,2,11,2,12,2,156,1,3,1,3,1,3,
        1,3,1,3,1,3,1,3,1,3,3,3,167,8,3,1,3,3,3,170,8,3,1,3,3,3,173,8,3,
        1,3,3,3,176,8,3,1,3,3,3,179,8,3,1,4,4,4,182,8,4,11,4,12,4,183,1,
        5,1,5,1,5,1,5,1,5,1,5,3,5,192,8,5,1,5,1,5,1,5,3,5,197,8,5,1,5,3,
        5,200,8,5,1,6,4,6,203,8,6,11,6,12,6,204,1,6,1,6,1,6,4,6,210,8,6,
        11,6,12,6,211,1,7,1,7,1,7,1,7,1,7,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,
        8,1,8,1,8,1,8,3,8,230,8,8,1,9,4,9,233,8,9,11,9,12,9,234,1,9,1,9,
        1,9,4,9,240,8,9,11,9,12,9,241,1,10,1,10,1,10,1,10,1,10,1,11,1,11,
        1,11,1,11,1,11,1,11,1,11,1,11,1,12,4,12,258,8,12,11,12,12,12,259,
        1,13,1,13,1,13,3,13,265,8,13,1,13,1,13,1,13,1,13,1,13,1,13,1,13,
        4,13,274,8,13,11,13,12,13,275,1,14,4,14,279,8,14,11,14,12,14,280,
        1,15,1,15,1,15,3,15,286,8,15,1,15,1,15,1,15,1,15,1,15,1,15,1,15,
        1,15,4,15,296,8,15,11,15,12,15,297,1,16,4,16,301,8,16,11,16,12,16,
        302,1,17,1,17,1,17,3,17,308,8,17,1,17,1,17,1,17,1,17,1,17,1,17,1,
        17,1,17,1,17,4,17,319,8,17,11,17,12,17,320,1,18,4,18,324,8,18,11,
        18,12,18,325,1,19,1,19,1,19,1,19,3,19,332,8,19,1,19,1,19,1,19,1,
        19,1,19,1,19,4,19,340,8,19,11,19,12,19,341,1,20,4,20,345,8,20,11,
        20,12,20,346,1,21,1,21,1,21,1,21,3,21,353,8,21,1,21,1,21,1,21,1,
        21,1,21,1,21,1,21,4,21,362,8,21,11,21,12,21,363,1,22,4,22,367,8,
        22,11,22,12,22,368,1,23,1,23,1,23,1,23,3,23,375,8,23,1,23,1,23,1,
        23,1,23,1,23,1,23,1,23,1,23,4,23,385,8,23,11,23,12,23,386,1,24,4,
        24,390,8,24,11,24,12,24,391,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,
        25,1,25,1,26,4,26,404,8,26,11,26,12,26,405,1,27,1,27,1,27,1,27,1,
        27,1,27,1,27,1,27,1,27,1,27,3,27,418,8,27,1,27,3,27,421,8,27,1,27,
        3,27,424,8,27,1,27,3,27,427,8,27,1,27,3,27,430,8,27,1,28,4,28,433,
        8,28,11,28,12,28,434,1,29,1,29,1,29,1,29,1,29,1,29,1,29,1,29,1,29,
        1,29,3,29,447,8,29,1,29,3,29,450,8,29,1,29,3,29,453,8,29,1,29,3,
        29,456,8,29,1,29,3,29,459,8,29,1,30,4,30,462,8,30,11,30,12,30,463,
        1,31,1,31,1,31,1,31,1,31,1,31,1,31,1,31,1,31,1,31,3,31,476,8,31,
        1,31,3,31,479,8,31,1,31,3,31,482,8,31,1,31,3,31,485,8,31,1,31,3,
        31,488,8,31,1,32,4,32,491,8,32,11,32,12,32,492,1,33,1,33,1,33,1,
        33,1,33,1,33,1,33,3,33,502,8,33,1,33,1,33,1,33,3,33,507,8,33,1,33,
        3,33,510,8,33,1,34,4,34,513,8,34,11,34,12,34,514,1,35,1,35,1,35,
        1,35,1,35,1,35,3,35,523,8,35,1,35,3,35,526,8,35,1,35,3,35,529,8,
        35,1,35,3,35,532,8,35,1,35,3,35,535,8,35,1,36,1,36,1,36,1,37,1,37,
        1,37,3,37,543,8,37,1,37,1,37,1,37,3,37,548,8,37,1,37,1,37,1,37,3,
        37,553,8,37,1,37,1,37,1,37,3,37,558,8,37,1,37,1,37,1,37,1,38,1,38,
        1,38,1,38,1,38,1,38,1,39,1,39,1,39,1,39,1,40,1,40,5,40,575,8,40,
        10,40,12,40,578,9,40,1,40,1,40,1,41,1,41,1,42,1,42,5,42,586,8,42,
        10,42,12,42,589,9,42,1,42,1,42,1,43,1,43,1,43,1,43,1,44,1,44,1,44,
        3,44,600,8,44,1,44,1,44,4,44,604,8,44,11,44,12,44,605,1,45,1,45,
        1,45,1,45,4,45,612,8,45,11,45,12,45,613,1,45,1,45,1,46,1,46,1,46,
        3,46,621,8,46,1,46,1,46,4,46,625,8,46,11,46,12,46,626,1,47,1,47,
        1,47,1,47,1,47,4,47,634,8,47,11,47,12,47,635,1,47,1,47,1,48,1,48,
        1,49,1,49,1,50,1,50,1,51,1,51,1,51,0,0,52,0,2,4,6,8,10,12,14,16,
        18,20,22,24,26,28,30,32,34,36,38,40,42,44,46,48,50,52,54,56,58,60,
        62,64,66,68,70,72,74,76,78,80,82,84,86,88,90,92,94,96,98,100,102,
        0,8,1,1,35,35,2,0,2,2,26,28,1,0,9,10,2,0,54,54,56,56,1,0,2,4,2,0,
        2,2,26,27,1,0,26,28,2,0,1,1,26,28,712,0,139,1,0,0,0,2,144,1,0,0,
        0,4,154,1,0,0,0,6,158,1,0,0,0,8,181,1,0,0,0,10,185,1,0,0,0,12,202,
        1,0,0,0,14,213,1,0,0,0,16,218,1,0,0,0,18,232,1,0,0,0,20,243,1,0,
        0,0,22,248,1,0,0,0,24,257,1,0,0,0,26,261,1,0,0,0,28,278,1,0,0,0,
        30,282,1,0,0,0,32,300,1,0,0,0,34,304,1,0,0,0,36,323,1,0,0,0,38,327,
        1,0,0,0,40,344,1,0,0,0,42,348,1,0,0,0,44,366,1,0,0,0,46,370,1,0,
        0,0,48,389,1,0,0,0,50,393,1,0,0,0,52,403,1,0,0,0,54,407,1,0,0,0,
        56,432,1,0,0,0,58,436,1,0,0,0,60,461,1,0,0,0,62,465,1,0,0,0,64,490,
        1,0,0,0,66,494,1,0,0,0,68,512,1,0,0,0,70,516,1,0,0,0,72,536,1,0,
        0,0,74,539,1,0,0,0,76,562,1,0,0,0,78,568,1,0,0,0,80,572,1,0,0,0,
        82,581,1,0,0,0,84,583,1,0,0,0,86,592,1,0,0,0,88,596,1,0,0,0,90,607,
        1,0,0,0,92,617,1,0,0,0,94,628,1,0,0,0,96,639,1,0,0,0,98,641,1,0,
        0,0,100,643,1,0,0,0,102,645,1,0,0,0,104,138,5,5,0,0,105,107,5,6,
        0,0,106,105,1,0,0,0,107,108,1,0,0,0,108,106,1,0,0,0,108,109,1,0,
        0,0,109,138,1,0,0,0,110,138,3,2,1,0,111,138,3,4,2,0,112,138,3,24,
        12,0,113,138,3,28,14,0,114,138,3,32,16,0,115,138,3,36,18,0,116,138,
        3,40,20,0,117,138,3,44,22,0,118,138,3,48,24,0,119,138,3,52,26,0,
        120,138,3,56,28,0,121,138,3,60,30,0,122,138,3,8,4,0,123,138,3,64,
        32,0,124,138,3,12,6,0,125,138,3,18,9,0,126,138,3,68,34,0,127,138,
        3,72,36,0,128,138,3,74,37,0,129,138,3,76,38,0,130,138,3,78,39,0,
        131,138,3,80,40,0,132,138,3,82,41,0,133,138,3,84,42,0,134,138,3,
        86,43,0,135,138,3,88,44,0,136,138,3,92,46,0,137,104,1,0,0,0,137,
        106,1,0,0,0,137,110,1,0,0,0,137,111,1,0,0,0,137,112,1,0,0,0,137,
        113,1,0,0,0,137,114,1,0,0,0,137,115,1,0,0,0,137,116,1,0,0,0,137,
        117,1,0,0,0,137,118,1,0,0,0,137,119,1,0,0,0,137,120,1,0,0,0,137,
        121,1,0,0,0,137,122,1,0,0,0,137,123,1,0,0,0,137,124,1,0,0,0,137,
        125,1,0,0,0,137,126,1,0,0,0,137,127,1,0,0,0,137,128,1,0,0,0,137,
        129,1,0,0,0,137,130,1,0,0,0,137,131,1,0,0,0,137,132,1,0,0,0,137,
        133,1,0,0,0,137,134,1,0,0,0,137,135,1,0,0,0,137,136,1,0,0,0,138,
        141,1,0,0,0,139,137,1,0,0,0,139,140,1,0,0,0,140,142,1,0,0,0,141,
        139,1,0,0,0,142,143,5,0,0,1,143,1,1,0,0,0,144,148,5,8,0,0,145,147,
        5,33,0,0,146,145,1,0,0,0,147,150,1,0,0,0,148,146,1,0,0,0,148,149,
        1,0,0,0,149,151,1,0,0,0,150,148,1,0,0,0,151,152,7,0,0,0,152,3,1,
        0,0,0,153,155,3,6,3,0,154,153,1,0,0,0,155,156,1,0,0,0,156,154,1,
        0,0,0,156,157,1,0,0,0,157,5,1,0,0,0,158,159,3,98,49,0,159,160,3,
        100,50,0,160,161,3,102,51,0,161,162,3,98,49,0,162,163,3,100,50,0,
        163,164,3,102,51,0,164,166,3,96,48,0,165,167,3,96,48,0,166,165,1,
        0,0,0,166,167,1,0,0,0,167,169,1,0,0,0,168,170,3,96,48,0,169,168,
        1,0,0,0,169,170,1,0,0,0,170,172,1,0,0,0,171,173,3,96,48,0,172,171,
        1,0,0,0,172,173,1,0,0,0,173,175,1,0,0,0,174,176,3,96,48,0,175,174,
        1,0,0,0,175,176,1,0,0,0,176,178,1,0,0,0,177,179,3,96,48,0,178,177,
        1,0,0,0,178,179,1,0,0,0,179,7,1,0,0,0,180,182,3,10,5,0,181,180,1,
        0,0,0,182,183,1,0,0,0,183,181,1,0,0,0,183,184,1,0,0,0,184,9,1,0,
        0,0,185,186,3,98,49,0,186,187,3,100,50,0,187,188,3,100,50,0,188,
        189,3,96,48,0,189,191,3,96,48,0,190,192,3,96,48,0,191,190,1,0,0,
        0,191,192,1,0,0,0,192,196,1,0,0,0,193,194,5,11,0,0,194,195,5,12,
        0,0,195,197,5,2,0,0,196,193,1,0,0,0,196,197,1,0,0,0,197,199,1,0,
        0,0,198,200,5,13,0,0,199,198,1,0,0,0,199,200,1,0,0,0,200,11,1,0,
        0,0,201,203,3,14,7,0,202,201,1,0,0,0,203,204,1,0,0,0,204,202,1,0,
        0,0,204,205,1,0,0,0,205,209,1,0,0,0,206,210,5,5,0,0,207,210,3,2,
        1,0,208,210,3,16,8,0,209,206,1,0,0,0,209,207,1,0,0,0,209,208,1,0,
        0,0,210,211,1,0,0,0,211,209,1,0,0,0,211,212,1,0,0,0,212,13,1,0,0,
        0,213,214,5,2,0,0,214,215,3,96,48,0,215,216,3,96,48,0,216,217,7,
        1,0,0,217,15,1,0,0,0,218,219,3,98,49,0,219,220,3,100,50,0,220,221,
        3,100,50,0,221,222,3,98,49,0,222,223,3,100,50,0,223,224,3,100,50,
        0,224,225,3,96,48,0,225,226,3,96,48,0,226,227,3,96,48,0,227,229,
        5,2,0,0,228,230,3,96,48,0,229,228,1,0,0,0,229,230,1,0,0,0,230,17,
        1,0,0,0,231,233,3,20,10,0,232,231,1,0,0,0,233,234,1,0,0,0,234,232,
        1,0,0,0,234,235,1,0,0,0,235,239,1,0,0,0,236,240,5,5,0,0,237,240,
        3,2,1,0,238,240,3,22,11,0,239,236,1,0,0,0,239,237,1,0,0,0,239,238,
        1,0,0,0,240,241,1,0,0,0,241,239,1,0,0,0,241,242,1,0,0,0,242,19,1,
        0,0,0,243,244,5,2,0,0,244,245,3,96,48,0,245,246,3,96,48,0,246,247,
        7,1,0,0,247,21,1,0,0,0,248,249,3,98,49,0,249,250,3,100,50,0,250,
        251,3,100,50,0,251,252,3,96,48,0,252,253,3,96,48,0,253,254,3,96,
        48,0,254,255,5,2,0,0,255,23,1,0,0,0,256,258,3,26,13,0,257,256,1,
        0,0,0,258,259,1,0,0,0,259,257,1,0,0,0,259,260,1,0,0,0,260,25,1,0,
        0,0,261,262,3,98,49,0,262,264,3,100,50,0,263,265,3,2,1,0,264,263,
        1,0,0,0,264,265,1,0,0,0,265,273,1,0,0,0,266,267,3,100,50,0,267,268,
        3,98,49,0,268,269,3,100,50,0,269,270,3,100,50,0,270,271,3,96,48,
        0,271,274,1,0,0,0,272,274,3,2,1,0,273,266,1,0,0,0,273,272,1,0,0,
        0,274,275,1,0,0,0,275,273,1,0,0,0,275,276,1,0,0,0,276,27,1,0,0,0,
        277,279,3,30,15,0,278,277,1,0,0,0,279,280,1,0,0,0,280,278,1,0,0,
        0,280,281,1,0,0,0,281,29,1,0,0,0,282,283,3,98,49,0,283,285,3,100,
        50,0,284,286,3,2,1,0,285,284,1,0,0,0,285,286,1,0,0,0,286,295,1,0,
        0,0,287,288,3,100,50,0,288,289,3,98,49,0,289,290,3,100,50,0,290,
        291,3,100,50,0,291,292,3,96,48,0,292,293,3,96,48,0,293,296,1,0,0,
        0,294,296,3,2,1,0,295,287,1,0,0,0,295,294,1,0,0,0,296,297,1,0,0,
        0,297,295,1,0,0,0,297,298,1,0,0,0,298,31,1,0,0,0,299,301,3,34,17,
        0,300,299,1,0,0,0,301,302,1,0,0,0,302,300,1,0,0,0,302,303,1,0,0,
        0,303,33,1,0,0,0,304,305,3,98,49,0,305,307,3,100,50,0,306,308,3,
        2,1,0,307,306,1,0,0,0,307,308,1,0,0,0,308,318,1,0,0,0,309,310,3,
        100,50,0,310,311,3,98,49,0,311,312,3,100,50,0,312,313,3,100,50,0,
        313,314,3,96,48,0,314,315,3,96,48,0,315,316,3,96,48,0,316,319,1,
        0,0,0,317,319,3,2,1,0,318,309,1,0,0,0,318,317,1,0,0,0,319,320,1,
        0,0,0,320,318,1,0,0,0,320,321,1,0,0,0,321,35,1,0,0,0,322,324,3,38,
        19,0,323,322,1,0,0,0,324,325,1,0,0,0,325,323,1,0,0,0,325,326,1,0,
        0,0,326,37,1,0,0,0,327,328,3,98,49,0,328,329,3,100,50,0,329,331,
        3,100,50,0,330,332,3,2,1,0,331,330,1,0,0,0,331,332,1,0,0,0,332,339,
        1,0,0,0,333,334,3,98,49,0,334,335,3,100,50,0,335,336,3,100,50,0,
        336,337,3,96,48,0,337,340,1,0,0,0,338,340,3,2,1,0,339,333,1,0,0,
        0,339,338,1,0,0,0,340,341,1,0,0,0,341,339,1,0,0,0,341,342,1,0,0,
        0,342,39,1,0,0,0,343,345,3,42,21,0,344,343,1,0,0,0,345,346,1,0,0,
        0,346,344,1,0,0,0,346,347,1,0,0,0,347,41,1,0,0,0,348,349,3,98,49,
        0,349,350,3,100,50,0,350,352,3,100,50,0,351,353,3,2,1,0,352,351,
        1,0,0,0,352,353,1,0,0,0,353,361,1,0,0,0,354,355,3,98,49,0,355,356,
        3,100,50,0,356,357,3,100,50,0,357,358,3,96,48,0,358,359,3,96,48,
        0,359,362,1,0,0,0,360,362,3,2,1,0,361,354,1,0,0,0,361,360,1,0,0,
        0,362,363,1,0,0,0,363,361,1,0,0,0,363,364,1,0,0,0,364,43,1,0,0,0,
        365,367,3,46,23,0,366,365,1,0,0,0,367,368,1,0,0,0,368,366,1,0,0,
        0,368,369,1,0,0,0,369,45,1,0,0,0,370,371,3,98,49,0,371,372,3,100,
        50,0,372,374,3,100,50,0,373,375,3,2,1,0,374,373,1,0,0,0,374,375,
        1,0,0,0,375,384,1,0,0,0,376,377,3,98,49,0,377,378,3,100,50,0,378,
        379,3,100,50,0,379,380,3,96,48,0,380,381,3,96,48,0,381,382,3,96,
        48,0,382,385,1,0,0,0,383,385,3,2,1,0,384,376,1,0,0,0,384,383,1,0,
        0,0,385,386,1,0,0,0,386,384,1,0,0,0,386,387,1,0,0,0,387,47,1,0,0,
        0,388,390,3,50,25,0,389,388,1,0,0,0,390,391,1,0,0,0,391,389,1,0,
        0,0,391,392,1,0,0,0,392,49,1,0,0,0,393,394,7,2,0,0,394,395,3,100,
        50,0,395,396,3,98,49,0,396,397,3,100,50,0,397,398,3,100,50,0,398,
        399,3,98,49,0,399,400,3,100,50,0,400,401,3,96,48,0,401,51,1,0,0,
        0,402,404,3,54,27,0,403,402,1,0,0,0,404,405,1,0,0,0,405,403,1,0,
        0,0,405,406,1,0,0,0,406,53,1,0,0,0,407,408,5,2,0,0,408,409,3,100,
        50,0,409,410,3,100,50,0,410,411,3,100,50,0,411,412,5,2,0,0,412,413,
        3,100,50,0,413,414,3,100,50,0,414,415,3,100,50,0,415,417,3,96,48,
        0,416,418,3,96,48,0,417,416,1,0,0,0,417,418,1,0,0,0,418,420,1,0,
        0,0,419,421,3,96,48,0,420,419,1,0,0,0,420,421,1,0,0,0,421,423,1,
        0,0,0,422,424,3,96,48,0,423,422,1,0,0,0,423,424,1,0,0,0,424,426,
        1,0,0,0,425,427,3,96,48,0,426,425,1,0,0,0,426,427,1,0,0,0,427,429,
        1,0,0,0,428,430,3,96,48,0,429,428,1,0,0,0,429,430,1,0,0,0,430,55,
        1,0,0,0,431,433,3,58,29,0,432,431,1,0,0,0,433,434,1,0,0,0,434,432,
        1,0,0,0,434,435,1,0,0,0,435,57,1,0,0,0,436,437,3,100,50,0,437,438,
        5,2,0,0,438,439,3,100,50,0,439,440,3,100,50,0,440,441,3,100,50,0,
        441,442,5,2,0,0,442,443,3,100,50,0,443,444,3,100,50,0,444,446,3,
        96,48,0,445,447,3,96,48,0,446,445,1,0,0,0,446,447,1,0,0,0,447,449,
        1,0,0,0,448,450,3,96,48,0,449,448,1,0,0,0,449,450,1,0,0,0,450,452,
        1,0,0,0,451,453,3,96,48,0,452,451,1,0,0,0,452,453,1,0,0,0,453,455,
        1,0,0,0,454,456,3,96,48,0,455,454,1,0,0,0,455,456,1,0,0,0,456,458,
        1,0,0,0,457,459,3,96,48,0,458,457,1,0,0,0,458,459,1,0,0,0,459,59,
        1,0,0,0,460,462,3,62,31,0,461,460,1,0,0,0,462,463,1,0,0,0,463,461,
        1,0,0,0,463,464,1,0,0,0,464,61,1,0,0,0,465,466,3,100,50,0,466,467,
        3,100,50,0,467,468,5,2,0,0,468,469,3,100,50,0,469,470,3,100,50,0,
        470,471,3,100,50,0,471,472,5,2,0,0,472,473,3,100,50,0,473,475,3,
        96,48,0,474,476,3,96,48,0,475,474,1,0,0,0,475,476,1,0,0,0,476,478,
        1,0,0,0,477,479,3,96,48,0,478,477,1,0,0,0,478,479,1,0,0,0,479,481,
        1,0,0,0,480,482,3,96,48,0,481,480,1,0,0,0,481,482,1,0,0,0,482,484,
        1,0,0,0,483,485,3,96,48,0,484,483,1,0,0,0,484,485,1,0,0,0,485,487,
        1,0,0,0,486,488,3,96,48,0,487,486,1,0,0,0,487,488,1,0,0,0,488,63,
        1,0,0,0,489,491,3,66,33,0,490,489,1,0,0,0,491,492,1,0,0,0,492,490,
        1,0,0,0,492,493,1,0,0,0,493,65,1,0,0,0,494,495,3,100,50,0,495,496,
        5,2,0,0,496,497,3,100,50,0,497,498,3,100,50,0,498,499,3,96,48,0,
        499,501,3,96,48,0,500,502,3,96,48,0,501,500,1,0,0,0,501,502,1,0,
        0,0,502,506,1,0,0,0,503,504,5,11,0,0,504,505,5,12,0,0,505,507,5,
        2,0,0,506,503,1,0,0,0,506,507,1,0,0,0,507,509,1,0,0,0,508,510,5,
        13,0,0,509,508,1,0,0,0,509,510,1,0,0,0,510,67,1,0,0,0,511,513,3,
        70,35,0,512,511,1,0,0,0,513,514,1,0,0,0,514,512,1,0,0,0,514,515,
        1,0,0,0,515,69,1,0,0,0,516,517,3,98,49,0,517,518,3,100,50,0,518,
        519,3,100,50,0,519,520,3,100,50,0,520,522,3,96,48,0,521,523,3,96,
        48,0,522,521,1,0,0,0,522,523,1,0,0,0,523,525,1,0,0,0,524,526,3,96,
        48,0,525,524,1,0,0,0,525,526,1,0,0,0,526,528,1,0,0,0,527,529,3,96,
        48,0,528,527,1,0,0,0,528,529,1,0,0,0,529,531,1,0,0,0,530,532,3,96,
        48,0,531,530,1,0,0,0,531,532,1,0,0,0,532,534,1,0,0,0,533,535,3,96,
        48,0,534,533,1,0,0,0,534,535,1,0,0,0,535,71,1,0,0,0,536,537,5,14,
        0,0,537,538,5,15,0,0,538,73,1,0,0,0,539,542,5,16,0,0,540,541,5,36,
        0,0,541,543,5,40,0,0,542,540,1,0,0,0,542,543,1,0,0,0,543,544,1,0,
        0,0,544,547,5,42,0,0,545,546,5,38,0,0,546,548,5,40,0,0,547,545,1,
        0,0,0,547,548,1,0,0,0,548,549,1,0,0,0,549,552,5,41,0,0,550,551,5,
        37,0,0,551,553,5,40,0,0,552,550,1,0,0,0,552,553,1,0,0,0,553,554,
        1,0,0,0,554,557,5,42,0,0,555,556,5,39,0,0,556,558,5,40,0,0,557,555,
        1,0,0,0,557,558,1,0,0,0,558,559,1,0,0,0,559,560,5,41,0,0,560,561,
        5,44,0,0,561,75,1,0,0,0,562,563,5,17,0,0,563,564,3,100,50,0,564,
        565,3,98,49,0,565,566,3,100,50,0,566,567,3,98,49,0,567,77,1,0,0,
        0,568,569,5,18,0,0,569,570,5,46,0,0,570,571,5,48,0,0,571,79,1,0,
        0,0,572,576,5,19,0,0,573,575,5,50,0,0,574,573,1,0,0,0,575,578,1,
        0,0,0,576,574,1,0,0,0,576,577,1,0,0,0,577,579,1,0,0,0,578,576,1,
        0,0,0,579,580,5,52,0,0,580,81,1,0,0,0,581,582,5,21,0,0,582,83,1,
        0,0,0,583,587,5,20,0,0,584,586,5,50,0,0,585,584,1,0,0,0,586,589,
        1,0,0,0,587,585,1,0,0,0,587,588,1,0,0,0,588,590,1,0,0,0,589,587,
        1,0,0,0,590,591,5,52,0,0,591,85,1,0,0,0,592,593,5,22,0,0,593,594,
        5,46,0,0,594,595,5,48,0,0,595,87,1,0,0,0,596,597,5,23,0,0,597,599,
        3,100,50,0,598,600,3,2,1,0,599,598,1,0,0,0,599,600,1,0,0,0,600,603,
        1,0,0,0,601,604,3,90,45,0,602,604,3,2,1,0,603,601,1,0,0,0,603,602,
        1,0,0,0,604,605,1,0,0,0,605,603,1,0,0,0,605,606,1,0,0,0,606,89,1,
        0,0,0,607,608,5,24,0,0,608,609,5,56,0,0,609,611,5,57,0,0,610,612,
        5,56,0,0,611,610,1,0,0,0,612,613,1,0,0,0,613,611,1,0,0,0,613,614,
        1,0,0,0,614,615,1,0,0,0,615,616,5,59,0,0,616,91,1,0,0,0,617,618,
        5,23,0,0,618,620,3,100,50,0,619,621,3,2,1,0,620,619,1,0,0,0,620,
        621,1,0,0,0,621,624,1,0,0,0,622,625,3,94,47,0,623,625,3,2,1,0,624,
        622,1,0,0,0,624,623,1,0,0,0,625,626,1,0,0,0,626,624,1,0,0,0,626,
        627,1,0,0,0,627,93,1,0,0,0,628,629,5,25,0,0,629,630,7,3,0,0,630,
        633,5,57,0,0,631,632,5,56,0,0,632,634,5,55,0,0,633,631,1,0,0,0,634,
        635,1,0,0,0,635,633,1,0,0,0,635,636,1,0,0,0,636,637,1,0,0,0,637,
        638,5,59,0,0,638,95,1,0,0,0,639,640,7,4,0,0,640,97,1,0,0,0,641,642,
        7,5,0,0,642,99,1,0,0,0,643,644,7,6,0,0,644,101,1,0,0,0,645,646,7,
        7,0,0,646,103,1,0,0,0,88,108,137,139,148,156,166,169,172,175,178,
        183,191,196,199,204,209,211,229,234,239,241,259,264,273,275,280,
        285,295,297,302,307,318,320,325,331,339,341,346,352,361,363,368,
        374,384,386,391,405,417,420,423,426,429,434,446,449,452,455,458,
        463,475,478,481,484,487,492,501,506,509,514,522,525,528,531,534,
        542,547,552,557,576,587,599,603,605,613,620,624,626,635
    ]

class CyanaMRParser ( Parser ):

    grammarFileName = "CyanaMRParser.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "'NOEUPP'", "'NOELOW'", "'TYPE'", "<INVALID>", 
                     "'OR'", "'SSBOND'", "<INVALID>", "'HBOND'", "'LINK'", 
                     "<INVALID>", "'VAR'", "'UNSET'", "<INVALID>", "'PRINT'", 
                     "'RESIDUE'", "'MAPPING'", "'AMBIG'", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "'ATOM1'", "'ATOM2'", "'RESIDUE1'", "'RESIDUE2'" ]

    symbolicNames = [ "<INVALID>", "Ambig_code", "Integer", "Float", "Float_DecimalComma", 
                      "Orientation_header", "Tensor_header", "SMCLN_COMMENT", 
                      "COMMENT", "NoeUpp", "NoeLow", "Type", "Equ_op", "Or", 
                      "Ssbond", "Ssbond_resids", "Hbond", "Link", "Atom_stereo", 
                      "Var", "Unset", "SetVar", "Print", "Residue", "Mapping", 
                      "Ambig", "Capital_integer", "Integer_capital", "Simple_name", 
                      "SPACE", "ENCLOSE_COMMENT", "SECTION_COMMENT", "LINE_COMMENT", 
                      "Any_name", "SPACE_CM", "RETURN_CM", "Atom1", "Atom2", 
                      "Residue1", "Residue2", "Equ_op_HB", "Integer_HB", 
                      "Simple_name_HB", "SPACE_HB", "RETURN_HB", "LINE_COMMENT_HB", 
                      "Double_quote_string", "SPACE_PR", "RETURN_PR", "LINE_COMMENT_PR", 
                      "Simple_name_VA", "SPACE_VA", "RETURN_VA", "LINE_COMMENT_VA", 
                      "Ambig_code_MP", "Integer_MP", "Simple_name_MP", "Equ_op_MP", 
                      "SPACE_MP", "RETURN_MP", "LINE_COMMENT_MP" ]

    RULE_cyana_mr = 0
    RULE_comment = 1
    RULE_distance_restraints = 2
    RULE_distance_restraint = 3
    RULE_torsion_angle_restraints = 4
    RULE_torsion_angle_restraint = 5
    RULE_rdc_restraints = 6
    RULE_rdc_parameter = 7
    RULE_rdc_restraint = 8
    RULE_pcs_restraints = 9
    RULE_pcs_parameter = 10
    RULE_pcs_restraint = 11
    RULE_fixres_distance_restraints = 12
    RULE_fixres_distance_restraint = 13
    RULE_fixresw_distance_restraints = 14
    RULE_fixresw_distance_restraint = 15
    RULE_fixresw2_distance_restraints = 16
    RULE_fixresw2_distance_restraint = 17
    RULE_fixatm_distance_restraints = 18
    RULE_fixatm_distance_restraint = 19
    RULE_fixatmw_distance_restraints = 20
    RULE_fixatmw_distance_restraint = 21
    RULE_fixatmw2_distance_restraints = 22
    RULE_fixatmw2_distance_restraint = 23
    RULE_qconvr_distance_restraints = 24
    RULE_qconvr_distance_restraint = 25
    RULE_distance_w_chain_restraints = 26
    RULE_distance_w_chain_restraint = 27
    RULE_distance_w_chain2_restraints = 28
    RULE_distance_w_chain2_restraint = 29
    RULE_distance_w_chain3_restraints = 30
    RULE_distance_w_chain3_restraint = 31
    RULE_torsion_angle_w_chain_restraints = 32
    RULE_torsion_angle_w_chain_restraint = 33
    RULE_cco_restraints = 34
    RULE_cco_restraint = 35
    RULE_ssbond_macro = 36
    RULE_hbond_macro = 37
    RULE_link_statement = 38
    RULE_stereoassign_macro = 39
    RULE_declare_variable = 40
    RULE_set_variable = 41
    RULE_unset_variable = 42
    RULE_print_macro = 43
    RULE_unambig_atom_name_mapping = 44
    RULE_mapping_list = 45
    RULE_ambig_atom_name_mapping = 46
    RULE_ambig_list = 47
    RULE_number = 48
    RULE_gen_res_num = 49
    RULE_gen_simple_name = 50
    RULE_gen_atom_name = 51

    ruleNames =  [ "cyana_mr", "comment", "distance_restraints", "distance_restraint", 
                   "torsion_angle_restraints", "torsion_angle_restraint", 
                   "rdc_restraints", "rdc_parameter", "rdc_restraint", "pcs_restraints", 
                   "pcs_parameter", "pcs_restraint", "fixres_distance_restraints", 
                   "fixres_distance_restraint", "fixresw_distance_restraints", 
                   "fixresw_distance_restraint", "fixresw2_distance_restraints", 
                   "fixresw2_distance_restraint", "fixatm_distance_restraints", 
                   "fixatm_distance_restraint", "fixatmw_distance_restraints", 
                   "fixatmw_distance_restraint", "fixatmw2_distance_restraints", 
                   "fixatmw2_distance_restraint", "qconvr_distance_restraints", 
                   "qconvr_distance_restraint", "distance_w_chain_restraints", 
                   "distance_w_chain_restraint", "distance_w_chain2_restraints", 
                   "distance_w_chain2_restraint", "distance_w_chain3_restraints", 
                   "distance_w_chain3_restraint", "torsion_angle_w_chain_restraints", 
                   "torsion_angle_w_chain_restraint", "cco_restraints", 
                   "cco_restraint", "ssbond_macro", "hbond_macro", "link_statement", 
                   "stereoassign_macro", "declare_variable", "set_variable", 
                   "unset_variable", "print_macro", "unambig_atom_name_mapping", 
                   "mapping_list", "ambig_atom_name_mapping", "ambig_list", 
                   "number", "gen_res_num", "gen_simple_name", "gen_atom_name" ]

    EOF = Token.EOF
    Ambig_code=1
    Integer=2
    Float=3
    Float_DecimalComma=4
    Orientation_header=5
    Tensor_header=6
    SMCLN_COMMENT=7
    COMMENT=8
    NoeUpp=9
    NoeLow=10
    Type=11
    Equ_op=12
    Or=13
    Ssbond=14
    Ssbond_resids=15
    Hbond=16
    Link=17
    Atom_stereo=18
    Var=19
    Unset=20
    SetVar=21
    Print=22
    Residue=23
    Mapping=24
    Ambig=25
    Capital_integer=26
    Integer_capital=27
    Simple_name=28
    SPACE=29
    ENCLOSE_COMMENT=30
    SECTION_COMMENT=31
    LINE_COMMENT=32
    Any_name=33
    SPACE_CM=34
    RETURN_CM=35
    Atom1=36
    Atom2=37
    Residue1=38
    Residue2=39
    Equ_op_HB=40
    Integer_HB=41
    Simple_name_HB=42
    SPACE_HB=43
    RETURN_HB=44
    LINE_COMMENT_HB=45
    Double_quote_string=46
    SPACE_PR=47
    RETURN_PR=48
    LINE_COMMENT_PR=49
    Simple_name_VA=50
    SPACE_VA=51
    RETURN_VA=52
    LINE_COMMENT_VA=53
    Ambig_code_MP=54
    Integer_MP=55
    Simple_name_MP=56
    Equ_op_MP=57
    SPACE_MP=58
    RETURN_MP=59
    LINE_COMMENT_MP=60

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.0")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class Cyana_mrContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(CyanaMRParser.EOF, 0)

        def Orientation_header(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Orientation_header)
            else:
                return self.getToken(CyanaMRParser.Orientation_header, i)

        def comment(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.CommentContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.CommentContext,i)


        def distance_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Distance_restraintsContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Distance_restraintsContext,i)


        def fixres_distance_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Fixres_distance_restraintsContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Fixres_distance_restraintsContext,i)


        def fixresw_distance_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Fixresw_distance_restraintsContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Fixresw_distance_restraintsContext,i)


        def fixresw2_distance_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Fixresw2_distance_restraintsContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Fixresw2_distance_restraintsContext,i)


        def fixatm_distance_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Fixatm_distance_restraintsContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Fixatm_distance_restraintsContext,i)


        def fixatmw_distance_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Fixatmw_distance_restraintsContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Fixatmw_distance_restraintsContext,i)


        def fixatmw2_distance_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Fixatmw2_distance_restraintsContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Fixatmw2_distance_restraintsContext,i)


        def qconvr_distance_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Qconvr_distance_restraintsContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Qconvr_distance_restraintsContext,i)


        def distance_w_chain_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Distance_w_chain_restraintsContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Distance_w_chain_restraintsContext,i)


        def distance_w_chain2_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Distance_w_chain2_restraintsContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Distance_w_chain2_restraintsContext,i)


        def distance_w_chain3_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Distance_w_chain3_restraintsContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Distance_w_chain3_restraintsContext,i)


        def torsion_angle_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Torsion_angle_restraintsContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Torsion_angle_restraintsContext,i)


        def torsion_angle_w_chain_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Torsion_angle_w_chain_restraintsContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Torsion_angle_w_chain_restraintsContext,i)


        def rdc_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Rdc_restraintsContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Rdc_restraintsContext,i)


        def pcs_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Pcs_restraintsContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Pcs_restraintsContext,i)


        def cco_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Cco_restraintsContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Cco_restraintsContext,i)


        def ssbond_macro(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Ssbond_macroContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Ssbond_macroContext,i)


        def hbond_macro(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Hbond_macroContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Hbond_macroContext,i)


        def link_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Link_statementContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Link_statementContext,i)


        def stereoassign_macro(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Stereoassign_macroContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Stereoassign_macroContext,i)


        def declare_variable(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Declare_variableContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Declare_variableContext,i)


        def set_variable(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Set_variableContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Set_variableContext,i)


        def unset_variable(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Unset_variableContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Unset_variableContext,i)


        def print_macro(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Print_macroContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Print_macroContext,i)


        def unambig_atom_name_mapping(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Unambig_atom_name_mappingContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Unambig_atom_name_mappingContext,i)


        def ambig_atom_name_mapping(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Ambig_atom_name_mappingContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Ambig_atom_name_mappingContext,i)


        def Tensor_header(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Tensor_header)
            else:
                return self.getToken(CyanaMRParser.Tensor_header, i)

        def getRuleIndex(self):
            return CyanaMRParser.RULE_cyana_mr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCyana_mr" ):
                listener.enterCyana_mr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCyana_mr" ):
                listener.exitCyana_mr(self)




    def cyana_mr(self):

        localctx = CyanaMRParser.Cyana_mrContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_cyana_mr)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 139
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 486492004) != 0):
                self.state = 137
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
                if la_ == 1:
                    self.state = 104
                    self.match(CyanaMRParser.Orientation_header)
                    pass

                elif la_ == 2:
                    self.state = 106 
                    self._errHandler.sync(self)
                    _alt = 1
                    while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                        if _alt == 1:
                            self.state = 105
                            self.match(CyanaMRParser.Tensor_header)

                        else:
                            raise NoViableAltException(self)
                        self.state = 108 
                        self._errHandler.sync(self)
                        _alt = self._interp.adaptivePredict(self._input,0,self._ctx)

                    pass

                elif la_ == 3:
                    self.state = 110
                    self.comment()
                    pass

                elif la_ == 4:
                    self.state = 111
                    self.distance_restraints()
                    pass

                elif la_ == 5:
                    self.state = 112
                    self.fixres_distance_restraints()
                    pass

                elif la_ == 6:
                    self.state = 113
                    self.fixresw_distance_restraints()
                    pass

                elif la_ == 7:
                    self.state = 114
                    self.fixresw2_distance_restraints()
                    pass

                elif la_ == 8:
                    self.state = 115
                    self.fixatm_distance_restraints()
                    pass

                elif la_ == 9:
                    self.state = 116
                    self.fixatmw_distance_restraints()
                    pass

                elif la_ == 10:
                    self.state = 117
                    self.fixatmw2_distance_restraints()
                    pass

                elif la_ == 11:
                    self.state = 118
                    self.qconvr_distance_restraints()
                    pass

                elif la_ == 12:
                    self.state = 119
                    self.distance_w_chain_restraints()
                    pass

                elif la_ == 13:
                    self.state = 120
                    self.distance_w_chain2_restraints()
                    pass

                elif la_ == 14:
                    self.state = 121
                    self.distance_w_chain3_restraints()
                    pass

                elif la_ == 15:
                    self.state = 122
                    self.torsion_angle_restraints()
                    pass

                elif la_ == 16:
                    self.state = 123
                    self.torsion_angle_w_chain_restraints()
                    pass

                elif la_ == 17:
                    self.state = 124
                    self.rdc_restraints()
                    pass

                elif la_ == 18:
                    self.state = 125
                    self.pcs_restraints()
                    pass

                elif la_ == 19:
                    self.state = 126
                    self.cco_restraints()
                    pass

                elif la_ == 20:
                    self.state = 127
                    self.ssbond_macro()
                    pass

                elif la_ == 21:
                    self.state = 128
                    self.hbond_macro()
                    pass

                elif la_ == 22:
                    self.state = 129
                    self.link_statement()
                    pass

                elif la_ == 23:
                    self.state = 130
                    self.stereoassign_macro()
                    pass

                elif la_ == 24:
                    self.state = 131
                    self.declare_variable()
                    pass

                elif la_ == 25:
                    self.state = 132
                    self.set_variable()
                    pass

                elif la_ == 26:
                    self.state = 133
                    self.unset_variable()
                    pass

                elif la_ == 27:
                    self.state = 134
                    self.print_macro()
                    pass

                elif la_ == 28:
                    self.state = 135
                    self.unambig_atom_name_mapping()
                    pass

                elif la_ == 29:
                    self.state = 136
                    self.ambig_atom_name_mapping()
                    pass


                self.state = 141
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 142
            self.match(CyanaMRParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CommentContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def COMMENT(self):
            return self.getToken(CyanaMRParser.COMMENT, 0)

        def RETURN_CM(self):
            return self.getToken(CyanaMRParser.RETURN_CM, 0)

        def EOF(self):
            return self.getToken(CyanaMRParser.EOF, 0)

        def Any_name(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Any_name)
            else:
                return self.getToken(CyanaMRParser.Any_name, i)

        def getRuleIndex(self):
            return CyanaMRParser.RULE_comment

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComment" ):
                listener.enterComment(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComment" ):
                listener.exitComment(self)




    def comment(self):

        localctx = CyanaMRParser.CommentContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_comment)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 144
            self.match(CyanaMRParser.COMMENT)
            self.state = 148
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==33:
                self.state = 145
                self.match(CyanaMRParser.Any_name)
                self.state = 150
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 151
            _la = self._input.LA(1)
            if not(_la==-1 or _la==35):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Distance_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def distance_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Distance_restraintContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Distance_restraintContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_distance_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDistance_restraints" ):
                listener.enterDistance_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDistance_restraints" ):
                listener.exitDistance_restraints(self)




    def distance_restraints(self):

        localctx = CyanaMRParser.Distance_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_distance_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 154 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 153
                    self.distance_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 156 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,4,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Distance_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def gen_res_num(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Gen_res_numContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Gen_res_numContext,i)


        def gen_simple_name(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Gen_simple_nameContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Gen_simple_nameContext,i)


        def gen_atom_name(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Gen_atom_nameContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Gen_atom_nameContext,i)


        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.NumberContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.NumberContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_distance_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDistance_restraint" ):
                listener.enterDistance_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDistance_restraint" ):
                listener.exitDistance_restraint(self)




    def distance_restraint(self):

        localctx = CyanaMRParser.Distance_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_distance_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 158
            self.gen_res_num()
            self.state = 159
            self.gen_simple_name()
            self.state = 160
            self.gen_atom_name()
            self.state = 161
            self.gen_res_num()
            self.state = 162
            self.gen_simple_name()
            self.state = 163
            self.gen_atom_name()
            self.state = 164
            self.number()
            self.state = 166
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,5,self._ctx)
            if la_ == 1:
                self.state = 165
                self.number()


            self.state = 169
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,6,self._ctx)
            if la_ == 1:
                self.state = 168
                self.number()


            self.state = 172
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,7,self._ctx)
            if la_ == 1:
                self.state = 171
                self.number()


            self.state = 175
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,8,self._ctx)
            if la_ == 1:
                self.state = 174
                self.number()


            self.state = 178
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,9,self._ctx)
            if la_ == 1:
                self.state = 177
                self.number()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Torsion_angle_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def torsion_angle_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Torsion_angle_restraintContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Torsion_angle_restraintContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_torsion_angle_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTorsion_angle_restraints" ):
                listener.enterTorsion_angle_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTorsion_angle_restraints" ):
                listener.exitTorsion_angle_restraints(self)




    def torsion_angle_restraints(self):

        localctx = CyanaMRParser.Torsion_angle_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_torsion_angle_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 181 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 180
                    self.torsion_angle_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 183 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,10,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Torsion_angle_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def gen_res_num(self):
            return self.getTypedRuleContext(CyanaMRParser.Gen_res_numContext,0)


        def gen_simple_name(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Gen_simple_nameContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Gen_simple_nameContext,i)


        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.NumberContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.NumberContext,i)


        def Type(self):
            return self.getToken(CyanaMRParser.Type, 0)

        def Equ_op(self):
            return self.getToken(CyanaMRParser.Equ_op, 0)

        def Integer(self):
            return self.getToken(CyanaMRParser.Integer, 0)

        def Or(self):
            return self.getToken(CyanaMRParser.Or, 0)

        def getRuleIndex(self):
            return CyanaMRParser.RULE_torsion_angle_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTorsion_angle_restraint" ):
                listener.enterTorsion_angle_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTorsion_angle_restraint" ):
                listener.exitTorsion_angle_restraint(self)




    def torsion_angle_restraint(self):

        localctx = CyanaMRParser.Torsion_angle_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_torsion_angle_restraint)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 185
            self.gen_res_num()
            self.state = 186
            self.gen_simple_name()
            self.state = 187
            self.gen_simple_name()
            self.state = 188
            self.number()
            self.state = 189
            self.number()
            self.state = 191
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,11,self._ctx)
            if la_ == 1:
                self.state = 190
                self.number()


            self.state = 196
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==11:
                self.state = 193
                self.match(CyanaMRParser.Type)
                self.state = 194
                self.match(CyanaMRParser.Equ_op)
                self.state = 195
                self.match(CyanaMRParser.Integer)


            self.state = 199
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==13:
                self.state = 198
                self.match(CyanaMRParser.Or)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Rdc_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def rdc_parameter(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Rdc_parameterContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Rdc_parameterContext,i)


        def Orientation_header(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Orientation_header)
            else:
                return self.getToken(CyanaMRParser.Orientation_header, i)

        def comment(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.CommentContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.CommentContext,i)


        def rdc_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Rdc_restraintContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Rdc_restraintContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_rdc_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRdc_restraints" ):
                listener.enterRdc_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRdc_restraints" ):
                listener.exitRdc_restraints(self)




    def rdc_restraints(self):

        localctx = CyanaMRParser.Rdc_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_rdc_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 202 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 201
                    self.rdc_parameter()

                else:
                    raise NoViableAltException(self)
                self.state = 204 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,14,self._ctx)

            self.state = 209 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 209
                    self._errHandler.sync(self)
                    token = self._input.LA(1)
                    if token in [5]:
                        self.state = 206
                        self.match(CyanaMRParser.Orientation_header)
                        pass
                    elif token in [8]:
                        self.state = 207
                        self.comment()
                        pass
                    elif token in [2, 26, 27]:
                        self.state = 208
                        self.rdc_restraint()
                        pass
                    else:
                        raise NoViableAltException(self)


                else:
                    raise NoViableAltException(self)
                self.state = 211 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,16,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Rdc_parameterContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Integer)
            else:
                return self.getToken(CyanaMRParser.Integer, i)

        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.NumberContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.NumberContext,i)


        def Capital_integer(self):
            return self.getToken(CyanaMRParser.Capital_integer, 0)

        def Integer_capital(self):
            return self.getToken(CyanaMRParser.Integer_capital, 0)

        def Simple_name(self):
            return self.getToken(CyanaMRParser.Simple_name, 0)

        def getRuleIndex(self):
            return CyanaMRParser.RULE_rdc_parameter

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRdc_parameter" ):
                listener.enterRdc_parameter(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRdc_parameter" ):
                listener.exitRdc_parameter(self)




    def rdc_parameter(self):

        localctx = CyanaMRParser.Rdc_parameterContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_rdc_parameter)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 213
            self.match(CyanaMRParser.Integer)
            self.state = 214
            self.number()
            self.state = 215
            self.number()
            self.state = 216
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 469762052) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Rdc_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def gen_res_num(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Gen_res_numContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Gen_res_numContext,i)


        def gen_simple_name(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Gen_simple_nameContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Gen_simple_nameContext,i)


        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.NumberContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.NumberContext,i)


        def Integer(self):
            return self.getToken(CyanaMRParser.Integer, 0)

        def getRuleIndex(self):
            return CyanaMRParser.RULE_rdc_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRdc_restraint" ):
                listener.enterRdc_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRdc_restraint" ):
                listener.exitRdc_restraint(self)




    def rdc_restraint(self):

        localctx = CyanaMRParser.Rdc_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_rdc_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 218
            self.gen_res_num()
            self.state = 219
            self.gen_simple_name()
            self.state = 220
            self.gen_simple_name()
            self.state = 221
            self.gen_res_num()
            self.state = 222
            self.gen_simple_name()
            self.state = 223
            self.gen_simple_name()
            self.state = 224
            self.number()
            self.state = 225
            self.number()
            self.state = 226
            self.number()
            self.state = 227
            self.match(CyanaMRParser.Integer)
            self.state = 229
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,17,self._ctx)
            if la_ == 1:
                self.state = 228
                self.number()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Pcs_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def pcs_parameter(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Pcs_parameterContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Pcs_parameterContext,i)


        def Orientation_header(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Orientation_header)
            else:
                return self.getToken(CyanaMRParser.Orientation_header, i)

        def comment(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.CommentContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.CommentContext,i)


        def pcs_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Pcs_restraintContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Pcs_restraintContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_pcs_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPcs_restraints" ):
                listener.enterPcs_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPcs_restraints" ):
                listener.exitPcs_restraints(self)




    def pcs_restraints(self):

        localctx = CyanaMRParser.Pcs_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_pcs_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 232 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 231
                    self.pcs_parameter()

                else:
                    raise NoViableAltException(self)
                self.state = 234 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,18,self._ctx)

            self.state = 239 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 239
                    self._errHandler.sync(self)
                    token = self._input.LA(1)
                    if token in [5]:
                        self.state = 236
                        self.match(CyanaMRParser.Orientation_header)
                        pass
                    elif token in [8]:
                        self.state = 237
                        self.comment()
                        pass
                    elif token in [2, 26, 27]:
                        self.state = 238
                        self.pcs_restraint()
                        pass
                    else:
                        raise NoViableAltException(self)


                else:
                    raise NoViableAltException(self)
                self.state = 241 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,20,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Pcs_parameterContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Integer)
            else:
                return self.getToken(CyanaMRParser.Integer, i)

        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.NumberContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.NumberContext,i)


        def Capital_integer(self):
            return self.getToken(CyanaMRParser.Capital_integer, 0)

        def Integer_capital(self):
            return self.getToken(CyanaMRParser.Integer_capital, 0)

        def Simple_name(self):
            return self.getToken(CyanaMRParser.Simple_name, 0)

        def getRuleIndex(self):
            return CyanaMRParser.RULE_pcs_parameter

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPcs_parameter" ):
                listener.enterPcs_parameter(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPcs_parameter" ):
                listener.exitPcs_parameter(self)




    def pcs_parameter(self):

        localctx = CyanaMRParser.Pcs_parameterContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_pcs_parameter)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 243
            self.match(CyanaMRParser.Integer)
            self.state = 244
            self.number()
            self.state = 245
            self.number()
            self.state = 246
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 469762052) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Pcs_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def gen_res_num(self):
            return self.getTypedRuleContext(CyanaMRParser.Gen_res_numContext,0)


        def gen_simple_name(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Gen_simple_nameContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Gen_simple_nameContext,i)


        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.NumberContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.NumberContext,i)


        def Integer(self):
            return self.getToken(CyanaMRParser.Integer, 0)

        def getRuleIndex(self):
            return CyanaMRParser.RULE_pcs_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPcs_restraint" ):
                listener.enterPcs_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPcs_restraint" ):
                listener.exitPcs_restraint(self)




    def pcs_restraint(self):

        localctx = CyanaMRParser.Pcs_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_pcs_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 248
            self.gen_res_num()
            self.state = 249
            self.gen_simple_name()
            self.state = 250
            self.gen_simple_name()
            self.state = 251
            self.number()
            self.state = 252
            self.number()
            self.state = 253
            self.number()
            self.state = 254
            self.match(CyanaMRParser.Integer)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Fixres_distance_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def fixres_distance_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Fixres_distance_restraintContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Fixres_distance_restraintContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_fixres_distance_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFixres_distance_restraints" ):
                listener.enterFixres_distance_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFixres_distance_restraints" ):
                listener.exitFixres_distance_restraints(self)




    def fixres_distance_restraints(self):

        localctx = CyanaMRParser.Fixres_distance_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_fixres_distance_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 257 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 256
                    self.fixres_distance_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 259 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,21,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Fixres_distance_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def gen_res_num(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Gen_res_numContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Gen_res_numContext,i)


        def gen_simple_name(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Gen_simple_nameContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Gen_simple_nameContext,i)


        def comment(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.CommentContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.CommentContext,i)


        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.NumberContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.NumberContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_fixres_distance_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFixres_distance_restraint" ):
                listener.enterFixres_distance_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFixres_distance_restraint" ):
                listener.exitFixres_distance_restraint(self)




    def fixres_distance_restraint(self):

        localctx = CyanaMRParser.Fixres_distance_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_fixres_distance_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 261
            self.gen_res_num()
            self.state = 262
            self.gen_simple_name()
            self.state = 264
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,22,self._ctx)
            if la_ == 1:
                self.state = 263
                self.comment()


            self.state = 273 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 273
                    self._errHandler.sync(self)
                    token = self._input.LA(1)
                    if token in [26, 27, 28]:
                        self.state = 266
                        self.gen_simple_name()
                        self.state = 267
                        self.gen_res_num()
                        self.state = 268
                        self.gen_simple_name()
                        self.state = 269
                        self.gen_simple_name()
                        self.state = 270
                        self.number()
                        pass
                    elif token in [8]:
                        self.state = 272
                        self.comment()
                        pass
                    else:
                        raise NoViableAltException(self)


                else:
                    raise NoViableAltException(self)
                self.state = 275 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,24,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Fixresw_distance_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def fixresw_distance_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Fixresw_distance_restraintContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Fixresw_distance_restraintContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_fixresw_distance_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFixresw_distance_restraints" ):
                listener.enterFixresw_distance_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFixresw_distance_restraints" ):
                listener.exitFixresw_distance_restraints(self)




    def fixresw_distance_restraints(self):

        localctx = CyanaMRParser.Fixresw_distance_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_fixresw_distance_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 278 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 277
                    self.fixresw_distance_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 280 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,25,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Fixresw_distance_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def gen_res_num(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Gen_res_numContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Gen_res_numContext,i)


        def gen_simple_name(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Gen_simple_nameContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Gen_simple_nameContext,i)


        def comment(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.CommentContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.CommentContext,i)


        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.NumberContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.NumberContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_fixresw_distance_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFixresw_distance_restraint" ):
                listener.enterFixresw_distance_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFixresw_distance_restraint" ):
                listener.exitFixresw_distance_restraint(self)




    def fixresw_distance_restraint(self):

        localctx = CyanaMRParser.Fixresw_distance_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_fixresw_distance_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 282
            self.gen_res_num()
            self.state = 283
            self.gen_simple_name()
            self.state = 285
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,26,self._ctx)
            if la_ == 1:
                self.state = 284
                self.comment()


            self.state = 295 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 295
                    self._errHandler.sync(self)
                    token = self._input.LA(1)
                    if token in [26, 27, 28]:
                        self.state = 287
                        self.gen_simple_name()
                        self.state = 288
                        self.gen_res_num()
                        self.state = 289
                        self.gen_simple_name()
                        self.state = 290
                        self.gen_simple_name()
                        self.state = 291
                        self.number()
                        self.state = 292
                        self.number()
                        pass
                    elif token in [8]:
                        self.state = 294
                        self.comment()
                        pass
                    else:
                        raise NoViableAltException(self)


                else:
                    raise NoViableAltException(self)
                self.state = 297 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,28,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Fixresw2_distance_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def fixresw2_distance_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Fixresw2_distance_restraintContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Fixresw2_distance_restraintContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_fixresw2_distance_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFixresw2_distance_restraints" ):
                listener.enterFixresw2_distance_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFixresw2_distance_restraints" ):
                listener.exitFixresw2_distance_restraints(self)




    def fixresw2_distance_restraints(self):

        localctx = CyanaMRParser.Fixresw2_distance_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_fixresw2_distance_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 300 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 299
                    self.fixresw2_distance_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 302 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,29,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Fixresw2_distance_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def gen_res_num(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Gen_res_numContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Gen_res_numContext,i)


        def gen_simple_name(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Gen_simple_nameContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Gen_simple_nameContext,i)


        def comment(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.CommentContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.CommentContext,i)


        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.NumberContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.NumberContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_fixresw2_distance_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFixresw2_distance_restraint" ):
                listener.enterFixresw2_distance_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFixresw2_distance_restraint" ):
                listener.exitFixresw2_distance_restraint(self)




    def fixresw2_distance_restraint(self):

        localctx = CyanaMRParser.Fixresw2_distance_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_fixresw2_distance_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 304
            self.gen_res_num()
            self.state = 305
            self.gen_simple_name()
            self.state = 307
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,30,self._ctx)
            if la_ == 1:
                self.state = 306
                self.comment()


            self.state = 318 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 318
                    self._errHandler.sync(self)
                    token = self._input.LA(1)
                    if token in [26, 27, 28]:
                        self.state = 309
                        self.gen_simple_name()
                        self.state = 310
                        self.gen_res_num()
                        self.state = 311
                        self.gen_simple_name()
                        self.state = 312
                        self.gen_simple_name()
                        self.state = 313
                        self.number()
                        self.state = 314
                        self.number()
                        self.state = 315
                        self.number()
                        pass
                    elif token in [8]:
                        self.state = 317
                        self.comment()
                        pass
                    else:
                        raise NoViableAltException(self)


                else:
                    raise NoViableAltException(self)
                self.state = 320 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,32,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Fixatm_distance_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def fixatm_distance_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Fixatm_distance_restraintContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Fixatm_distance_restraintContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_fixatm_distance_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFixatm_distance_restraints" ):
                listener.enterFixatm_distance_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFixatm_distance_restraints" ):
                listener.exitFixatm_distance_restraints(self)




    def fixatm_distance_restraints(self):

        localctx = CyanaMRParser.Fixatm_distance_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_fixatm_distance_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 323 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 322
                    self.fixatm_distance_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 325 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,33,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Fixatm_distance_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def gen_res_num(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Gen_res_numContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Gen_res_numContext,i)


        def gen_simple_name(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Gen_simple_nameContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Gen_simple_nameContext,i)


        def comment(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.CommentContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.CommentContext,i)


        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.NumberContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.NumberContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_fixatm_distance_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFixatm_distance_restraint" ):
                listener.enterFixatm_distance_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFixatm_distance_restraint" ):
                listener.exitFixatm_distance_restraint(self)




    def fixatm_distance_restraint(self):

        localctx = CyanaMRParser.Fixatm_distance_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_fixatm_distance_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 327
            self.gen_res_num()
            self.state = 328
            self.gen_simple_name()
            self.state = 329
            self.gen_simple_name()
            self.state = 331
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,34,self._ctx)
            if la_ == 1:
                self.state = 330
                self.comment()


            self.state = 339 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 339
                    self._errHandler.sync(self)
                    token = self._input.LA(1)
                    if token in [2, 26, 27]:
                        self.state = 333
                        self.gen_res_num()
                        self.state = 334
                        self.gen_simple_name()
                        self.state = 335
                        self.gen_simple_name()
                        self.state = 336
                        self.number()
                        pass
                    elif token in [8]:
                        self.state = 338
                        self.comment()
                        pass
                    else:
                        raise NoViableAltException(self)


                else:
                    raise NoViableAltException(self)
                self.state = 341 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,36,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Fixatmw_distance_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def fixatmw_distance_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Fixatmw_distance_restraintContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Fixatmw_distance_restraintContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_fixatmw_distance_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFixatmw_distance_restraints" ):
                listener.enterFixatmw_distance_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFixatmw_distance_restraints" ):
                listener.exitFixatmw_distance_restraints(self)




    def fixatmw_distance_restraints(self):

        localctx = CyanaMRParser.Fixatmw_distance_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_fixatmw_distance_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 344 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 343
                    self.fixatmw_distance_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 346 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,37,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Fixatmw_distance_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def gen_res_num(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Gen_res_numContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Gen_res_numContext,i)


        def gen_simple_name(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Gen_simple_nameContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Gen_simple_nameContext,i)


        def comment(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.CommentContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.CommentContext,i)


        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.NumberContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.NumberContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_fixatmw_distance_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFixatmw_distance_restraint" ):
                listener.enterFixatmw_distance_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFixatmw_distance_restraint" ):
                listener.exitFixatmw_distance_restraint(self)




    def fixatmw_distance_restraint(self):

        localctx = CyanaMRParser.Fixatmw_distance_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_fixatmw_distance_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 348
            self.gen_res_num()
            self.state = 349
            self.gen_simple_name()
            self.state = 350
            self.gen_simple_name()
            self.state = 352
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,38,self._ctx)
            if la_ == 1:
                self.state = 351
                self.comment()


            self.state = 361 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 361
                    self._errHandler.sync(self)
                    token = self._input.LA(1)
                    if token in [2, 26, 27]:
                        self.state = 354
                        self.gen_res_num()
                        self.state = 355
                        self.gen_simple_name()
                        self.state = 356
                        self.gen_simple_name()
                        self.state = 357
                        self.number()
                        self.state = 358
                        self.number()
                        pass
                    elif token in [8]:
                        self.state = 360
                        self.comment()
                        pass
                    else:
                        raise NoViableAltException(self)


                else:
                    raise NoViableAltException(self)
                self.state = 363 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,40,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Fixatmw2_distance_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def fixatmw2_distance_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Fixatmw2_distance_restraintContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Fixatmw2_distance_restraintContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_fixatmw2_distance_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFixatmw2_distance_restraints" ):
                listener.enterFixatmw2_distance_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFixatmw2_distance_restraints" ):
                listener.exitFixatmw2_distance_restraints(self)




    def fixatmw2_distance_restraints(self):

        localctx = CyanaMRParser.Fixatmw2_distance_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_fixatmw2_distance_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 366 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 365
                    self.fixatmw2_distance_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 368 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,41,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Fixatmw2_distance_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def gen_res_num(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Gen_res_numContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Gen_res_numContext,i)


        def gen_simple_name(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Gen_simple_nameContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Gen_simple_nameContext,i)


        def comment(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.CommentContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.CommentContext,i)


        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.NumberContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.NumberContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_fixatmw2_distance_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFixatmw2_distance_restraint" ):
                listener.enterFixatmw2_distance_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFixatmw2_distance_restraint" ):
                listener.exitFixatmw2_distance_restraint(self)




    def fixatmw2_distance_restraint(self):

        localctx = CyanaMRParser.Fixatmw2_distance_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_fixatmw2_distance_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 370
            self.gen_res_num()
            self.state = 371
            self.gen_simple_name()
            self.state = 372
            self.gen_simple_name()
            self.state = 374
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,42,self._ctx)
            if la_ == 1:
                self.state = 373
                self.comment()


            self.state = 384 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 384
                    self._errHandler.sync(self)
                    token = self._input.LA(1)
                    if token in [2, 26, 27]:
                        self.state = 376
                        self.gen_res_num()
                        self.state = 377
                        self.gen_simple_name()
                        self.state = 378
                        self.gen_simple_name()
                        self.state = 379
                        self.number()
                        self.state = 380
                        self.number()
                        self.state = 381
                        self.number()
                        pass
                    elif token in [8]:
                        self.state = 383
                        self.comment()
                        pass
                    else:
                        raise NoViableAltException(self)


                else:
                    raise NoViableAltException(self)
                self.state = 386 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,44,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Qconvr_distance_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def qconvr_distance_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Qconvr_distance_restraintContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Qconvr_distance_restraintContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_qconvr_distance_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterQconvr_distance_restraints" ):
                listener.enterQconvr_distance_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitQconvr_distance_restraints" ):
                listener.exitQconvr_distance_restraints(self)




    def qconvr_distance_restraints(self):

        localctx = CyanaMRParser.Qconvr_distance_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_qconvr_distance_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 389 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 388
                    self.qconvr_distance_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 391 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,45,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Qconvr_distance_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def gen_simple_name(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Gen_simple_nameContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Gen_simple_nameContext,i)


        def gen_res_num(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Gen_res_numContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Gen_res_numContext,i)


        def number(self):
            return self.getTypedRuleContext(CyanaMRParser.NumberContext,0)


        def NoeUpp(self):
            return self.getToken(CyanaMRParser.NoeUpp, 0)

        def NoeLow(self):
            return self.getToken(CyanaMRParser.NoeLow, 0)

        def getRuleIndex(self):
            return CyanaMRParser.RULE_qconvr_distance_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterQconvr_distance_restraint" ):
                listener.enterQconvr_distance_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitQconvr_distance_restraint" ):
                listener.exitQconvr_distance_restraint(self)




    def qconvr_distance_restraint(self):

        localctx = CyanaMRParser.Qconvr_distance_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_qconvr_distance_restraint)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 393
            _la = self._input.LA(1)
            if not(_la==9 or _la==10):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 394
            self.gen_simple_name()
            self.state = 395
            self.gen_res_num()
            self.state = 396
            self.gen_simple_name()
            self.state = 397
            self.gen_simple_name()
            self.state = 398
            self.gen_res_num()
            self.state = 399
            self.gen_simple_name()
            self.state = 400
            self.number()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Distance_w_chain_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def distance_w_chain_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Distance_w_chain_restraintContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Distance_w_chain_restraintContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_distance_w_chain_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDistance_w_chain_restraints" ):
                listener.enterDistance_w_chain_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDistance_w_chain_restraints" ):
                listener.exitDistance_w_chain_restraints(self)




    def distance_w_chain_restraints(self):

        localctx = CyanaMRParser.Distance_w_chain_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_distance_w_chain_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 403 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 402
                    self.distance_w_chain_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 405 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,46,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Distance_w_chain_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Integer)
            else:
                return self.getToken(CyanaMRParser.Integer, i)

        def gen_simple_name(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Gen_simple_nameContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Gen_simple_nameContext,i)


        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.NumberContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.NumberContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_distance_w_chain_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDistance_w_chain_restraint" ):
                listener.enterDistance_w_chain_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDistance_w_chain_restraint" ):
                listener.exitDistance_w_chain_restraint(self)




    def distance_w_chain_restraint(self):

        localctx = CyanaMRParser.Distance_w_chain_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_distance_w_chain_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 407
            self.match(CyanaMRParser.Integer)
            self.state = 408
            self.gen_simple_name()
            self.state = 409
            self.gen_simple_name()
            self.state = 410
            self.gen_simple_name()
            self.state = 411
            self.match(CyanaMRParser.Integer)
            self.state = 412
            self.gen_simple_name()
            self.state = 413
            self.gen_simple_name()
            self.state = 414
            self.gen_simple_name()
            self.state = 415
            self.number()
            self.state = 417
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,47,self._ctx)
            if la_ == 1:
                self.state = 416
                self.number()


            self.state = 420
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,48,self._ctx)
            if la_ == 1:
                self.state = 419
                self.number()


            self.state = 423
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,49,self._ctx)
            if la_ == 1:
                self.state = 422
                self.number()


            self.state = 426
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,50,self._ctx)
            if la_ == 1:
                self.state = 425
                self.number()


            self.state = 429
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,51,self._ctx)
            if la_ == 1:
                self.state = 428
                self.number()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Distance_w_chain2_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def distance_w_chain2_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Distance_w_chain2_restraintContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Distance_w_chain2_restraintContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_distance_w_chain2_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDistance_w_chain2_restraints" ):
                listener.enterDistance_w_chain2_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDistance_w_chain2_restraints" ):
                listener.exitDistance_w_chain2_restraints(self)




    def distance_w_chain2_restraints(self):

        localctx = CyanaMRParser.Distance_w_chain2_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_distance_w_chain2_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 432 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 431
                    self.distance_w_chain2_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 434 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,52,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Distance_w_chain2_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def gen_simple_name(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Gen_simple_nameContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Gen_simple_nameContext,i)


        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Integer)
            else:
                return self.getToken(CyanaMRParser.Integer, i)

        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.NumberContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.NumberContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_distance_w_chain2_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDistance_w_chain2_restraint" ):
                listener.enterDistance_w_chain2_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDistance_w_chain2_restraint" ):
                listener.exitDistance_w_chain2_restraint(self)




    def distance_w_chain2_restraint(self):

        localctx = CyanaMRParser.Distance_w_chain2_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_distance_w_chain2_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 436
            self.gen_simple_name()
            self.state = 437
            self.match(CyanaMRParser.Integer)
            self.state = 438
            self.gen_simple_name()
            self.state = 439
            self.gen_simple_name()
            self.state = 440
            self.gen_simple_name()
            self.state = 441
            self.match(CyanaMRParser.Integer)
            self.state = 442
            self.gen_simple_name()
            self.state = 443
            self.gen_simple_name()
            self.state = 444
            self.number()
            self.state = 446
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,53,self._ctx)
            if la_ == 1:
                self.state = 445
                self.number()


            self.state = 449
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,54,self._ctx)
            if la_ == 1:
                self.state = 448
                self.number()


            self.state = 452
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,55,self._ctx)
            if la_ == 1:
                self.state = 451
                self.number()


            self.state = 455
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,56,self._ctx)
            if la_ == 1:
                self.state = 454
                self.number()


            self.state = 458
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,57,self._ctx)
            if la_ == 1:
                self.state = 457
                self.number()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Distance_w_chain3_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def distance_w_chain3_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Distance_w_chain3_restraintContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Distance_w_chain3_restraintContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_distance_w_chain3_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDistance_w_chain3_restraints" ):
                listener.enterDistance_w_chain3_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDistance_w_chain3_restraints" ):
                listener.exitDistance_w_chain3_restraints(self)




    def distance_w_chain3_restraints(self):

        localctx = CyanaMRParser.Distance_w_chain3_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 60, self.RULE_distance_w_chain3_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 461 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 460
                    self.distance_w_chain3_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 463 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,58,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Distance_w_chain3_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def gen_simple_name(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Gen_simple_nameContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Gen_simple_nameContext,i)


        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Integer)
            else:
                return self.getToken(CyanaMRParser.Integer, i)

        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.NumberContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.NumberContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_distance_w_chain3_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDistance_w_chain3_restraint" ):
                listener.enterDistance_w_chain3_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDistance_w_chain3_restraint" ):
                listener.exitDistance_w_chain3_restraint(self)




    def distance_w_chain3_restraint(self):

        localctx = CyanaMRParser.Distance_w_chain3_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 62, self.RULE_distance_w_chain3_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 465
            self.gen_simple_name()
            self.state = 466
            self.gen_simple_name()
            self.state = 467
            self.match(CyanaMRParser.Integer)
            self.state = 468
            self.gen_simple_name()
            self.state = 469
            self.gen_simple_name()
            self.state = 470
            self.gen_simple_name()
            self.state = 471
            self.match(CyanaMRParser.Integer)
            self.state = 472
            self.gen_simple_name()
            self.state = 473
            self.number()
            self.state = 475
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,59,self._ctx)
            if la_ == 1:
                self.state = 474
                self.number()


            self.state = 478
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,60,self._ctx)
            if la_ == 1:
                self.state = 477
                self.number()


            self.state = 481
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,61,self._ctx)
            if la_ == 1:
                self.state = 480
                self.number()


            self.state = 484
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,62,self._ctx)
            if la_ == 1:
                self.state = 483
                self.number()


            self.state = 487
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,63,self._ctx)
            if la_ == 1:
                self.state = 486
                self.number()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Torsion_angle_w_chain_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def torsion_angle_w_chain_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Torsion_angle_w_chain_restraintContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Torsion_angle_w_chain_restraintContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_torsion_angle_w_chain_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTorsion_angle_w_chain_restraints" ):
                listener.enterTorsion_angle_w_chain_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTorsion_angle_w_chain_restraints" ):
                listener.exitTorsion_angle_w_chain_restraints(self)




    def torsion_angle_w_chain_restraints(self):

        localctx = CyanaMRParser.Torsion_angle_w_chain_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 64, self.RULE_torsion_angle_w_chain_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 490 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 489
                    self.torsion_angle_w_chain_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 492 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,64,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Torsion_angle_w_chain_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def gen_simple_name(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Gen_simple_nameContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Gen_simple_nameContext,i)


        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Integer)
            else:
                return self.getToken(CyanaMRParser.Integer, i)

        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.NumberContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.NumberContext,i)


        def Type(self):
            return self.getToken(CyanaMRParser.Type, 0)

        def Equ_op(self):
            return self.getToken(CyanaMRParser.Equ_op, 0)

        def Or(self):
            return self.getToken(CyanaMRParser.Or, 0)

        def getRuleIndex(self):
            return CyanaMRParser.RULE_torsion_angle_w_chain_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTorsion_angle_w_chain_restraint" ):
                listener.enterTorsion_angle_w_chain_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTorsion_angle_w_chain_restraint" ):
                listener.exitTorsion_angle_w_chain_restraint(self)




    def torsion_angle_w_chain_restraint(self):

        localctx = CyanaMRParser.Torsion_angle_w_chain_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 66, self.RULE_torsion_angle_w_chain_restraint)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 494
            self.gen_simple_name()
            self.state = 495
            self.match(CyanaMRParser.Integer)
            self.state = 496
            self.gen_simple_name()
            self.state = 497
            self.gen_simple_name()
            self.state = 498
            self.number()
            self.state = 499
            self.number()
            self.state = 501
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,65,self._ctx)
            if la_ == 1:
                self.state = 500
                self.number()


            self.state = 506
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==11:
                self.state = 503
                self.match(CyanaMRParser.Type)
                self.state = 504
                self.match(CyanaMRParser.Equ_op)
                self.state = 505
                self.match(CyanaMRParser.Integer)


            self.state = 509
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==13:
                self.state = 508
                self.match(CyanaMRParser.Or)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Cco_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def cco_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Cco_restraintContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Cco_restraintContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_cco_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCco_restraints" ):
                listener.enterCco_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCco_restraints" ):
                listener.exitCco_restraints(self)




    def cco_restraints(self):

        localctx = CyanaMRParser.Cco_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 68, self.RULE_cco_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 512 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 511
                    self.cco_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 514 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,68,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Cco_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def gen_res_num(self):
            return self.getTypedRuleContext(CyanaMRParser.Gen_res_numContext,0)


        def gen_simple_name(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Gen_simple_nameContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Gen_simple_nameContext,i)


        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.NumberContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.NumberContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_cco_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCco_restraint" ):
                listener.enterCco_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCco_restraint" ):
                listener.exitCco_restraint(self)




    def cco_restraint(self):

        localctx = CyanaMRParser.Cco_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 70, self.RULE_cco_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 516
            self.gen_res_num()
            self.state = 517
            self.gen_simple_name()
            self.state = 518
            self.gen_simple_name()
            self.state = 519
            self.gen_simple_name()
            self.state = 520
            self.number()
            self.state = 522
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,69,self._ctx)
            if la_ == 1:
                self.state = 521
                self.number()


            self.state = 525
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,70,self._ctx)
            if la_ == 1:
                self.state = 524
                self.number()


            self.state = 528
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,71,self._ctx)
            if la_ == 1:
                self.state = 527
                self.number()


            self.state = 531
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,72,self._ctx)
            if la_ == 1:
                self.state = 530
                self.number()


            self.state = 534
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,73,self._ctx)
            if la_ == 1:
                self.state = 533
                self.number()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Ssbond_macroContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Ssbond(self):
            return self.getToken(CyanaMRParser.Ssbond, 0)

        def Ssbond_resids(self):
            return self.getToken(CyanaMRParser.Ssbond_resids, 0)

        def getRuleIndex(self):
            return CyanaMRParser.RULE_ssbond_macro

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSsbond_macro" ):
                listener.enterSsbond_macro(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSsbond_macro" ):
                listener.exitSsbond_macro(self)




    def ssbond_macro(self):

        localctx = CyanaMRParser.Ssbond_macroContext(self, self._ctx, self.state)
        self.enterRule(localctx, 72, self.RULE_ssbond_macro)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 536
            self.match(CyanaMRParser.Ssbond)
            self.state = 537
            self.match(CyanaMRParser.Ssbond_resids)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Hbond_macroContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Hbond(self):
            return self.getToken(CyanaMRParser.Hbond, 0)

        def Simple_name_HB(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Simple_name_HB)
            else:
                return self.getToken(CyanaMRParser.Simple_name_HB, i)

        def Integer_HB(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Integer_HB)
            else:
                return self.getToken(CyanaMRParser.Integer_HB, i)

        def RETURN_HB(self):
            return self.getToken(CyanaMRParser.RETURN_HB, 0)

        def Atom1(self):
            return self.getToken(CyanaMRParser.Atom1, 0)

        def Equ_op_HB(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Equ_op_HB)
            else:
                return self.getToken(CyanaMRParser.Equ_op_HB, i)

        def Residue1(self):
            return self.getToken(CyanaMRParser.Residue1, 0)

        def Atom2(self):
            return self.getToken(CyanaMRParser.Atom2, 0)

        def Residue2(self):
            return self.getToken(CyanaMRParser.Residue2, 0)

        def getRuleIndex(self):
            return CyanaMRParser.RULE_hbond_macro

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterHbond_macro" ):
                listener.enterHbond_macro(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitHbond_macro" ):
                listener.exitHbond_macro(self)




    def hbond_macro(self):

        localctx = CyanaMRParser.Hbond_macroContext(self, self._ctx, self.state)
        self.enterRule(localctx, 74, self.RULE_hbond_macro)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 539
            self.match(CyanaMRParser.Hbond)
            self.state = 542
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==36:
                self.state = 540
                self.match(CyanaMRParser.Atom1)
                self.state = 541
                self.match(CyanaMRParser.Equ_op_HB)


            self.state = 544
            self.match(CyanaMRParser.Simple_name_HB)
            self.state = 547
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==38:
                self.state = 545
                self.match(CyanaMRParser.Residue1)
                self.state = 546
                self.match(CyanaMRParser.Equ_op_HB)


            self.state = 549
            self.match(CyanaMRParser.Integer_HB)
            self.state = 552
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==37:
                self.state = 550
                self.match(CyanaMRParser.Atom2)
                self.state = 551
                self.match(CyanaMRParser.Equ_op_HB)


            self.state = 554
            self.match(CyanaMRParser.Simple_name_HB)
            self.state = 557
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==39:
                self.state = 555
                self.match(CyanaMRParser.Residue2)
                self.state = 556
                self.match(CyanaMRParser.Equ_op_HB)


            self.state = 559
            self.match(CyanaMRParser.Integer_HB)
            self.state = 560
            self.match(CyanaMRParser.RETURN_HB)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Link_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Link(self):
            return self.getToken(CyanaMRParser.Link, 0)

        def gen_simple_name(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Gen_simple_nameContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Gen_simple_nameContext,i)


        def gen_res_num(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Gen_res_numContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Gen_res_numContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_link_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLink_statement" ):
                listener.enterLink_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLink_statement" ):
                listener.exitLink_statement(self)




    def link_statement(self):

        localctx = CyanaMRParser.Link_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 76, self.RULE_link_statement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 562
            self.match(CyanaMRParser.Link)
            self.state = 563
            self.gen_simple_name()
            self.state = 564
            self.gen_res_num()
            self.state = 565
            self.gen_simple_name()
            self.state = 566
            self.gen_res_num()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Stereoassign_macroContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Atom_stereo(self):
            return self.getToken(CyanaMRParser.Atom_stereo, 0)

        def Double_quote_string(self):
            return self.getToken(CyanaMRParser.Double_quote_string, 0)

        def RETURN_PR(self):
            return self.getToken(CyanaMRParser.RETURN_PR, 0)

        def getRuleIndex(self):
            return CyanaMRParser.RULE_stereoassign_macro

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStereoassign_macro" ):
                listener.enterStereoassign_macro(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStereoassign_macro" ):
                listener.exitStereoassign_macro(self)




    def stereoassign_macro(self):

        localctx = CyanaMRParser.Stereoassign_macroContext(self, self._ctx, self.state)
        self.enterRule(localctx, 78, self.RULE_stereoassign_macro)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 568
            self.match(CyanaMRParser.Atom_stereo)
            self.state = 569
            self.match(CyanaMRParser.Double_quote_string)
            self.state = 570
            self.match(CyanaMRParser.RETURN_PR)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Declare_variableContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Var(self):
            return self.getToken(CyanaMRParser.Var, 0)

        def RETURN_VA(self):
            return self.getToken(CyanaMRParser.RETURN_VA, 0)

        def Simple_name_VA(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Simple_name_VA)
            else:
                return self.getToken(CyanaMRParser.Simple_name_VA, i)

        def getRuleIndex(self):
            return CyanaMRParser.RULE_declare_variable

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDeclare_variable" ):
                listener.enterDeclare_variable(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDeclare_variable" ):
                listener.exitDeclare_variable(self)




    def declare_variable(self):

        localctx = CyanaMRParser.Declare_variableContext(self, self._ctx, self.state)
        self.enterRule(localctx, 80, self.RULE_declare_variable)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 572
            self.match(CyanaMRParser.Var)
            self.state = 576
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==50:
                self.state = 573
                self.match(CyanaMRParser.Simple_name_VA)
                self.state = 578
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 579
            self.match(CyanaMRParser.RETURN_VA)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Set_variableContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def SetVar(self):
            return self.getToken(CyanaMRParser.SetVar, 0)

        def getRuleIndex(self):
            return CyanaMRParser.RULE_set_variable

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSet_variable" ):
                listener.enterSet_variable(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSet_variable" ):
                listener.exitSet_variable(self)




    def set_variable(self):

        localctx = CyanaMRParser.Set_variableContext(self, self._ctx, self.state)
        self.enterRule(localctx, 82, self.RULE_set_variable)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 581
            self.match(CyanaMRParser.SetVar)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Unset_variableContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Unset(self):
            return self.getToken(CyanaMRParser.Unset, 0)

        def RETURN_VA(self):
            return self.getToken(CyanaMRParser.RETURN_VA, 0)

        def Simple_name_VA(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Simple_name_VA)
            else:
                return self.getToken(CyanaMRParser.Simple_name_VA, i)

        def getRuleIndex(self):
            return CyanaMRParser.RULE_unset_variable

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUnset_variable" ):
                listener.enterUnset_variable(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUnset_variable" ):
                listener.exitUnset_variable(self)




    def unset_variable(self):

        localctx = CyanaMRParser.Unset_variableContext(self, self._ctx, self.state)
        self.enterRule(localctx, 84, self.RULE_unset_variable)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 583
            self.match(CyanaMRParser.Unset)
            self.state = 587
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==50:
                self.state = 584
                self.match(CyanaMRParser.Simple_name_VA)
                self.state = 589
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 590
            self.match(CyanaMRParser.RETURN_VA)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Print_macroContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Print(self):
            return self.getToken(CyanaMRParser.Print, 0)

        def Double_quote_string(self):
            return self.getToken(CyanaMRParser.Double_quote_string, 0)

        def RETURN_PR(self):
            return self.getToken(CyanaMRParser.RETURN_PR, 0)

        def getRuleIndex(self):
            return CyanaMRParser.RULE_print_macro

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrint_macro" ):
                listener.enterPrint_macro(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrint_macro" ):
                listener.exitPrint_macro(self)




    def print_macro(self):

        localctx = CyanaMRParser.Print_macroContext(self, self._ctx, self.state)
        self.enterRule(localctx, 86, self.RULE_print_macro)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 592
            self.match(CyanaMRParser.Print)
            self.state = 593
            self.match(CyanaMRParser.Double_quote_string)
            self.state = 594
            self.match(CyanaMRParser.RETURN_PR)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Unambig_atom_name_mappingContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Residue(self):
            return self.getToken(CyanaMRParser.Residue, 0)

        def gen_simple_name(self):
            return self.getTypedRuleContext(CyanaMRParser.Gen_simple_nameContext,0)


        def comment(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.CommentContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.CommentContext,i)


        def mapping_list(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Mapping_listContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Mapping_listContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_unambig_atom_name_mapping

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUnambig_atom_name_mapping" ):
                listener.enterUnambig_atom_name_mapping(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUnambig_atom_name_mapping" ):
                listener.exitUnambig_atom_name_mapping(self)




    def unambig_atom_name_mapping(self):

        localctx = CyanaMRParser.Unambig_atom_name_mappingContext(self, self._ctx, self.state)
        self.enterRule(localctx, 88, self.RULE_unambig_atom_name_mapping)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 596
            self.match(CyanaMRParser.Residue)
            self.state = 597
            self.gen_simple_name()
            self.state = 599
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,80,self._ctx)
            if la_ == 1:
                self.state = 598
                self.comment()


            self.state = 603 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 603
                    self._errHandler.sync(self)
                    token = self._input.LA(1)
                    if token in [24]:
                        self.state = 601
                        self.mapping_list()
                        pass
                    elif token in [8]:
                        self.state = 602
                        self.comment()
                        pass
                    else:
                        raise NoViableAltException(self)


                else:
                    raise NoViableAltException(self)
                self.state = 605 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,82,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Mapping_listContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Mapping(self):
            return self.getToken(CyanaMRParser.Mapping, 0)

        def Simple_name_MP(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Simple_name_MP)
            else:
                return self.getToken(CyanaMRParser.Simple_name_MP, i)

        def Equ_op_MP(self):
            return self.getToken(CyanaMRParser.Equ_op_MP, 0)

        def RETURN_MP(self):
            return self.getToken(CyanaMRParser.RETURN_MP, 0)

        def getRuleIndex(self):
            return CyanaMRParser.RULE_mapping_list

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMapping_list" ):
                listener.enterMapping_list(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMapping_list" ):
                listener.exitMapping_list(self)




    def mapping_list(self):

        localctx = CyanaMRParser.Mapping_listContext(self, self._ctx, self.state)
        self.enterRule(localctx, 90, self.RULE_mapping_list)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 607
            self.match(CyanaMRParser.Mapping)
            self.state = 608
            self.match(CyanaMRParser.Simple_name_MP)
            self.state = 609
            self.match(CyanaMRParser.Equ_op_MP)
            self.state = 611 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 610
                self.match(CyanaMRParser.Simple_name_MP)
                self.state = 613 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==56):
                    break

            self.state = 615
            self.match(CyanaMRParser.RETURN_MP)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Ambig_atom_name_mappingContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Residue(self):
            return self.getToken(CyanaMRParser.Residue, 0)

        def gen_simple_name(self):
            return self.getTypedRuleContext(CyanaMRParser.Gen_simple_nameContext,0)


        def comment(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.CommentContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.CommentContext,i)


        def ambig_list(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaMRParser.Ambig_listContext)
            else:
                return self.getTypedRuleContext(CyanaMRParser.Ambig_listContext,i)


        def getRuleIndex(self):
            return CyanaMRParser.RULE_ambig_atom_name_mapping

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAmbig_atom_name_mapping" ):
                listener.enterAmbig_atom_name_mapping(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAmbig_atom_name_mapping" ):
                listener.exitAmbig_atom_name_mapping(self)




    def ambig_atom_name_mapping(self):

        localctx = CyanaMRParser.Ambig_atom_name_mappingContext(self, self._ctx, self.state)
        self.enterRule(localctx, 92, self.RULE_ambig_atom_name_mapping)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 617
            self.match(CyanaMRParser.Residue)
            self.state = 618
            self.gen_simple_name()
            self.state = 620
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,84,self._ctx)
            if la_ == 1:
                self.state = 619
                self.comment()


            self.state = 624 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 624
                    self._errHandler.sync(self)
                    token = self._input.LA(1)
                    if token in [25]:
                        self.state = 622
                        self.ambig_list()
                        pass
                    elif token in [8]:
                        self.state = 623
                        self.comment()
                        pass
                    else:
                        raise NoViableAltException(self)


                else:
                    raise NoViableAltException(self)
                self.state = 626 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,86,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Ambig_listContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Ambig(self):
            return self.getToken(CyanaMRParser.Ambig, 0)

        def Equ_op_MP(self):
            return self.getToken(CyanaMRParser.Equ_op_MP, 0)

        def RETURN_MP(self):
            return self.getToken(CyanaMRParser.RETURN_MP, 0)

        def Simple_name_MP(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Simple_name_MP)
            else:
                return self.getToken(CyanaMRParser.Simple_name_MP, i)

        def Ambig_code_MP(self):
            return self.getToken(CyanaMRParser.Ambig_code_MP, 0)

        def Integer_MP(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaMRParser.Integer_MP)
            else:
                return self.getToken(CyanaMRParser.Integer_MP, i)

        def getRuleIndex(self):
            return CyanaMRParser.RULE_ambig_list

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAmbig_list" ):
                listener.enterAmbig_list(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAmbig_list" ):
                listener.exitAmbig_list(self)




    def ambig_list(self):

        localctx = CyanaMRParser.Ambig_listContext(self, self._ctx, self.state)
        self.enterRule(localctx, 94, self.RULE_ambig_list)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 628
            self.match(CyanaMRParser.Ambig)
            self.state = 629
            _la = self._input.LA(1)
            if not(_la==54 or _la==56):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 630
            self.match(CyanaMRParser.Equ_op_MP)
            self.state = 633 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 631
                self.match(CyanaMRParser.Simple_name_MP)
                self.state = 632
                self.match(CyanaMRParser.Integer_MP)
                self.state = 635 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==56):
                    break

            self.state = 637
            self.match(CyanaMRParser.RETURN_MP)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NumberContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Float(self):
            return self.getToken(CyanaMRParser.Float, 0)

        def Float_DecimalComma(self):
            return self.getToken(CyanaMRParser.Float_DecimalComma, 0)

        def Integer(self):
            return self.getToken(CyanaMRParser.Integer, 0)

        def getRuleIndex(self):
            return CyanaMRParser.RULE_number

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumber" ):
                listener.enterNumber(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumber" ):
                listener.exitNumber(self)




    def number(self):

        localctx = CyanaMRParser.NumberContext(self, self._ctx, self.state)
        self.enterRule(localctx, 96, self.RULE_number)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 639
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 28) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Gen_res_numContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self):
            return self.getToken(CyanaMRParser.Integer, 0)

        def Capital_integer(self):
            return self.getToken(CyanaMRParser.Capital_integer, 0)

        def Integer_capital(self):
            return self.getToken(CyanaMRParser.Integer_capital, 0)

        def getRuleIndex(self):
            return CyanaMRParser.RULE_gen_res_num

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGen_res_num" ):
                listener.enterGen_res_num(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGen_res_num" ):
                listener.exitGen_res_num(self)




    def gen_res_num(self):

        localctx = CyanaMRParser.Gen_res_numContext(self, self._ctx, self.state)
        self.enterRule(localctx, 98, self.RULE_gen_res_num)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 641
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 201326596) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Gen_simple_nameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Simple_name(self):
            return self.getToken(CyanaMRParser.Simple_name, 0)

        def Capital_integer(self):
            return self.getToken(CyanaMRParser.Capital_integer, 0)

        def Integer_capital(self):
            return self.getToken(CyanaMRParser.Integer_capital, 0)

        def getRuleIndex(self):
            return CyanaMRParser.RULE_gen_simple_name

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGen_simple_name" ):
                listener.enterGen_simple_name(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGen_simple_name" ):
                listener.exitGen_simple_name(self)




    def gen_simple_name(self):

        localctx = CyanaMRParser.Gen_simple_nameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 100, self.RULE_gen_simple_name)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 643
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 469762048) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Gen_atom_nameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Simple_name(self):
            return self.getToken(CyanaMRParser.Simple_name, 0)

        def Capital_integer(self):
            return self.getToken(CyanaMRParser.Capital_integer, 0)

        def Integer_capital(self):
            return self.getToken(CyanaMRParser.Integer_capital, 0)

        def Ambig_code(self):
            return self.getToken(CyanaMRParser.Ambig_code, 0)

        def getRuleIndex(self):
            return CyanaMRParser.RULE_gen_atom_name

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGen_atom_name" ):
                listener.enterGen_atom_name(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGen_atom_name" ):
                listener.exitGen_atom_name(self)




    def gen_atom_name(self):

        localctx = CyanaMRParser.Gen_atom_nameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 102, self.RULE_gen_atom_name)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 645
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 469762050) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





