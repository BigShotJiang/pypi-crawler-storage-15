# Generated from RosettaMRParser.g4 by ANTLR 4.13.0
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,66,499,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,26,
        2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,31,2,32,7,32,2,33,
        7,33,2,34,7,34,2,35,7,35,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,
        1,0,1,0,1,0,1,0,1,0,5,0,88,8,0,10,0,12,0,91,9,0,1,0,1,0,1,1,1,1,
        5,1,97,8,1,10,1,12,1,100,9,1,1,1,1,1,1,2,4,2,105,8,2,11,2,12,2,106,
        1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,4,4,4,117,8,4,11,4,12,4,118,1,5,1,
        5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,6,4,6,131,8,6,11,6,12,6,132,1,7,
        1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,8,4,8,147,8,8,11,8,12,
        8,148,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,
        9,1,9,1,9,1,9,1,9,1,10,4,10,171,8,10,11,10,12,10,172,1,11,1,11,1,
        11,1,11,1,11,1,11,1,11,1,11,1,11,1,11,1,12,4,12,186,8,12,11,12,12,
        12,187,1,13,1,13,1,13,1,13,1,13,1,13,1,13,1,13,1,13,1,13,1,13,1,
        13,1,14,4,14,203,8,14,11,14,12,14,204,1,15,1,15,1,15,1,15,1,15,1,
        15,1,16,4,16,214,8,16,11,16,12,16,215,1,17,1,17,1,17,1,17,1,17,1,
        17,1,17,1,18,4,18,226,8,18,11,18,12,18,227,1,19,1,19,1,19,1,19,1,
        19,1,20,4,20,236,8,20,11,20,12,20,237,1,21,1,21,1,21,1,21,1,21,1,
        22,4,22,246,8,22,11,22,12,22,247,1,23,1,23,1,23,1,23,3,23,254,8,
        23,1,23,1,23,4,23,258,8,23,11,23,12,23,259,1,23,1,23,1,24,1,24,1,
        24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,3,24,274,8,24,1,25,1,25,1,
        25,1,25,1,25,1,25,1,25,1,25,1,25,3,25,285,8,25,1,25,1,25,5,25,289,
        8,25,10,25,12,25,292,9,25,1,25,1,25,1,25,1,25,1,25,1,25,3,25,300,
        8,25,1,25,1,25,5,25,304,8,25,10,25,12,25,307,9,25,1,25,1,25,1,25,
        1,25,1,25,1,25,1,25,3,25,316,8,25,1,25,1,25,5,25,320,8,25,10,25,
        12,25,323,9,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,
        1,25,1,25,1,25,4,25,338,8,25,11,25,12,25,339,1,25,1,25,1,25,1,25,
        1,25,1,25,3,25,348,8,25,1,25,1,25,1,25,1,25,1,25,1,25,4,25,356,8,
        25,11,25,12,25,357,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,
        1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,4,25,378,8,25,11,25,
        12,25,379,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,
        1,25,5,25,394,8,25,10,25,12,25,397,9,25,4,25,399,8,25,11,25,12,25,
        400,3,25,403,8,25,1,25,1,25,1,25,1,25,1,25,1,25,3,25,411,8,25,1,
        25,1,25,1,25,1,25,1,25,3,25,418,8,25,1,25,1,25,1,25,1,25,5,25,424,
        8,25,10,25,12,25,427,9,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,4,25,
        436,8,25,11,25,12,25,437,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,
        1,25,4,25,449,8,25,11,25,12,25,450,3,25,453,8,25,1,25,3,25,456,8,
        25,1,26,4,26,459,8,26,11,26,12,26,460,1,27,1,27,1,27,1,27,1,27,1,
        27,1,28,4,28,470,8,28,11,28,12,28,471,1,29,1,29,1,29,1,30,4,30,478,
        8,30,11,30,12,30,479,1,31,1,31,1,31,1,31,1,31,1,31,1,31,1,31,1,31,
        1,32,1,32,1,33,1,33,1,34,1,34,1,35,1,35,1,35,0,0,36,0,2,4,6,8,10,
        12,14,16,18,20,22,24,26,28,30,32,34,36,38,40,42,44,46,48,50,52,54,
        56,58,60,62,64,66,68,70,0,11,1,0,62,64,1,1,66,66,2,0,1,2,9,9,1,0,
        3,4,3,0,18,18,25,25,39,40,3,0,21,22,26,26,46,46,2,0,23,23,43,43,
        2,0,31,31,44,45,1,0,50,51,2,0,50,50,55,56,1,0,55,57,546,0,89,1,0,
        0,0,2,94,1,0,0,0,4,104,1,0,0,0,6,108,1,0,0,0,8,116,1,0,0,0,10,120,
        1,0,0,0,12,130,1,0,0,0,14,134,1,0,0,0,16,146,1,0,0,0,18,150,1,0,
        0,0,20,170,1,0,0,0,22,174,1,0,0,0,24,185,1,0,0,0,26,189,1,0,0,0,
        28,202,1,0,0,0,30,206,1,0,0,0,32,213,1,0,0,0,34,217,1,0,0,0,36,225,
        1,0,0,0,38,229,1,0,0,0,40,235,1,0,0,0,42,239,1,0,0,0,44,245,1,0,
        0,0,46,253,1,0,0,0,48,273,1,0,0,0,50,452,1,0,0,0,52,458,1,0,0,0,
        54,462,1,0,0,0,56,469,1,0,0,0,58,473,1,0,0,0,60,477,1,0,0,0,62,481,
        1,0,0,0,64,490,1,0,0,0,66,492,1,0,0,0,68,494,1,0,0,0,70,496,1,0,
        0,0,72,88,3,2,1,0,73,88,3,4,2,0,74,88,3,8,4,0,75,88,3,12,6,0,76,
        88,3,16,8,0,77,88,3,20,10,0,78,88,3,24,12,0,79,88,3,28,14,0,80,88,
        3,32,16,0,81,88,3,36,18,0,82,88,3,40,20,0,83,88,3,44,22,0,84,88,
        3,52,26,0,85,88,3,56,28,0,86,88,3,60,30,0,87,72,1,0,0,0,87,73,1,
        0,0,0,87,74,1,0,0,0,87,75,1,0,0,0,87,76,1,0,0,0,87,77,1,0,0,0,87,
        78,1,0,0,0,87,79,1,0,0,0,87,80,1,0,0,0,87,81,1,0,0,0,87,82,1,0,0,
        0,87,83,1,0,0,0,87,84,1,0,0,0,87,85,1,0,0,0,87,86,1,0,0,0,88,91,
        1,0,0,0,89,87,1,0,0,0,89,90,1,0,0,0,90,92,1,0,0,0,91,89,1,0,0,0,
        92,93,5,0,0,1,93,1,1,0,0,0,94,98,5,54,0,0,95,97,7,0,0,0,96,95,1,
        0,0,0,97,100,1,0,0,0,98,96,1,0,0,0,98,99,1,0,0,0,99,101,1,0,0,0,
        100,98,1,0,0,0,101,102,7,1,0,0,102,3,1,0,0,0,103,105,3,6,3,0,104,
        103,1,0,0,0,105,106,1,0,0,0,106,104,1,0,0,0,106,107,1,0,0,0,107,
        5,1,0,0,0,108,109,7,2,0,0,109,110,3,70,35,0,110,111,3,68,34,0,111,
        112,3,70,35,0,112,113,3,68,34,0,113,114,3,50,25,0,114,7,1,0,0,0,
        115,117,3,10,5,0,116,115,1,0,0,0,117,118,1,0,0,0,118,116,1,0,0,0,
        118,119,1,0,0,0,119,9,1,0,0,0,120,121,7,3,0,0,121,122,3,70,35,0,
        122,123,3,68,34,0,123,124,3,70,35,0,124,125,3,68,34,0,125,126,3,
        70,35,0,126,127,3,68,34,0,127,128,3,50,25,0,128,11,1,0,0,0,129,131,
        3,14,7,0,130,129,1,0,0,0,131,132,1,0,0,0,132,130,1,0,0,0,132,133,
        1,0,0,0,133,13,1,0,0,0,134,135,5,5,0,0,135,136,3,70,35,0,136,137,
        3,68,34,0,137,138,3,70,35,0,138,139,3,68,34,0,139,140,3,70,35,0,
        140,141,3,68,34,0,141,142,3,70,35,0,142,143,3,68,34,0,143,144,3,
        50,25,0,144,15,1,0,0,0,145,147,3,18,9,0,146,145,1,0,0,0,147,148,
        1,0,0,0,148,146,1,0,0,0,148,149,1,0,0,0,149,17,1,0,0,0,150,151,5,
        6,0,0,151,152,3,70,35,0,152,153,3,68,34,0,153,154,3,70,35,0,154,
        155,3,68,34,0,155,156,3,70,35,0,156,157,3,68,34,0,157,158,3,70,35,
        0,158,159,3,68,34,0,159,160,3,70,35,0,160,161,3,68,34,0,161,162,
        3,70,35,0,162,163,3,68,34,0,163,164,3,70,35,0,164,165,3,68,34,0,
        165,166,3,70,35,0,166,167,3,68,34,0,167,168,3,50,25,0,168,19,1,0,
        0,0,169,171,3,22,11,0,170,169,1,0,0,0,171,172,1,0,0,0,172,170,1,
        0,0,0,172,173,1,0,0,0,173,21,1,0,0,0,174,175,5,7,0,0,175,176,3,70,
        35,0,176,177,3,68,34,0,177,178,3,70,35,0,178,179,3,68,34,0,179,180,
        3,64,32,0,180,181,3,64,32,0,181,182,3,64,32,0,182,183,3,50,25,0,
        183,23,1,0,0,0,184,186,3,26,13,0,185,184,1,0,0,0,186,187,1,0,0,0,
        187,185,1,0,0,0,187,188,1,0,0,0,188,25,1,0,0,0,189,190,5,8,0,0,190,
        191,3,70,35,0,191,192,3,68,34,0,192,193,3,70,35,0,193,194,3,70,35,
        0,194,195,3,70,35,0,195,196,5,50,0,0,196,197,3,64,32,0,197,198,3,
        64,32,0,198,199,3,64,32,0,199,200,3,50,25,0,200,27,1,0,0,0,201,203,
        3,30,15,0,202,201,1,0,0,0,203,204,1,0,0,0,204,202,1,0,0,0,204,205,
        1,0,0,0,205,29,1,0,0,0,206,207,5,10,0,0,207,208,3,70,35,0,208,209,
        3,68,34,0,209,210,5,57,0,0,210,211,3,50,25,0,211,31,1,0,0,0,212,
        214,3,34,17,0,213,212,1,0,0,0,214,215,1,0,0,0,215,213,1,0,0,0,215,
        216,1,0,0,0,216,33,1,0,0,0,217,218,5,11,0,0,218,219,3,68,34,0,219,
        220,3,70,35,0,220,221,5,50,0,0,221,222,5,50,0,0,222,223,3,50,25,
        0,223,35,1,0,0,0,224,226,3,38,19,0,225,224,1,0,0,0,226,227,1,0,0,
        0,227,225,1,0,0,0,227,228,1,0,0,0,228,37,1,0,0,0,229,230,5,12,0,
        0,230,231,3,68,34,0,231,232,3,68,34,0,232,233,3,64,32,0,233,39,1,
        0,0,0,234,236,3,42,21,0,235,234,1,0,0,0,236,237,1,0,0,0,237,235,
        1,0,0,0,237,238,1,0,0,0,238,41,1,0,0,0,239,240,5,13,0,0,240,241,
        3,68,34,0,241,242,5,57,0,0,242,243,3,64,32,0,243,43,1,0,0,0,244,
        246,3,46,23,0,245,244,1,0,0,0,246,247,1,0,0,0,247,245,1,0,0,0,247,
        248,1,0,0,0,248,45,1,0,0,0,249,254,5,14,0,0,250,254,5,15,0,0,251,
        252,5,16,0,0,252,254,5,50,0,0,253,249,1,0,0,0,253,250,1,0,0,0,253,
        251,1,0,0,0,254,257,1,0,0,0,255,258,3,48,24,0,256,258,3,46,23,0,
        257,255,1,0,0,0,257,256,1,0,0,0,258,259,1,0,0,0,259,257,1,0,0,0,
        259,260,1,0,0,0,260,261,1,0,0,0,261,262,5,17,0,0,262,47,1,0,0,0,
        263,274,3,6,3,0,264,274,3,10,5,0,265,274,3,14,7,0,266,274,3,18,9,
        0,267,274,3,22,11,0,268,274,3,26,13,0,269,274,3,30,15,0,270,274,
        3,34,17,0,271,274,3,38,19,0,272,274,3,42,21,0,273,263,1,0,0,0,273,
        264,1,0,0,0,273,265,1,0,0,0,273,266,1,0,0,0,273,267,1,0,0,0,273,
        268,1,0,0,0,273,269,1,0,0,0,273,270,1,0,0,0,273,271,1,0,0,0,273,
        272,1,0,0,0,274,49,1,0,0,0,275,276,7,4,0,0,276,277,3,66,33,0,277,
        278,3,66,33,0,278,453,1,0,0,0,279,280,5,27,0,0,280,281,3,66,33,0,
        281,282,3,66,33,0,282,284,3,66,33,0,283,285,3,66,33,0,284,283,1,
        0,0,0,284,285,1,0,0,0,285,290,1,0,0,0,286,289,5,57,0,0,287,289,3,
        66,33,0,288,286,1,0,0,0,288,287,1,0,0,0,289,292,1,0,0,0,290,288,
        1,0,0,0,290,291,1,0,0,0,291,453,1,0,0,0,292,290,1,0,0,0,293,294,
        5,19,0,0,294,295,3,66,33,0,295,296,3,66,33,0,296,297,3,66,33,0,297,
        299,3,66,33,0,298,300,3,66,33,0,299,298,1,0,0,0,299,300,1,0,0,0,
        300,305,1,0,0,0,301,304,5,57,0,0,302,304,3,66,33,0,303,301,1,0,0,
        0,303,302,1,0,0,0,304,307,1,0,0,0,305,303,1,0,0,0,305,306,1,0,0,
        0,306,453,1,0,0,0,307,305,1,0,0,0,308,309,5,20,0,0,309,310,3,66,
        33,0,310,311,3,66,33,0,311,312,3,66,33,0,312,313,3,66,33,0,313,315,
        3,66,33,0,314,316,3,66,33,0,315,314,1,0,0,0,315,316,1,0,0,0,316,
        321,1,0,0,0,317,320,5,57,0,0,318,320,3,66,33,0,319,317,1,0,0,0,319,
        318,1,0,0,0,320,323,1,0,0,0,321,319,1,0,0,0,321,322,1,0,0,0,322,
        453,1,0,0,0,323,321,1,0,0,0,324,325,7,5,0,0,325,326,3,66,33,0,326,
        327,3,66,33,0,327,328,3,66,33,0,328,453,1,0,0,0,329,330,7,6,0,0,
        330,331,3,66,33,0,331,332,3,66,33,0,332,333,3,66,33,0,333,334,3,
        66,33,0,334,453,1,0,0,0,335,337,5,24,0,0,336,338,3,66,33,0,337,336,
        1,0,0,0,338,339,1,0,0,0,339,337,1,0,0,0,339,340,1,0,0,0,340,453,
        1,0,0,0,341,342,5,28,0,0,342,343,3,66,33,0,343,344,3,66,33,0,344,
        347,5,57,0,0,345,346,5,29,0,0,346,348,3,66,33,0,347,345,1,0,0,0,
        347,348,1,0,0,0,348,453,1,0,0,0,349,350,5,30,0,0,350,355,5,50,0,
        0,351,352,3,66,33,0,352,353,3,66,33,0,353,354,3,66,33,0,354,356,
        1,0,0,0,355,351,1,0,0,0,356,357,1,0,0,0,357,355,1,0,0,0,357,358,
        1,0,0,0,358,453,1,0,0,0,359,360,7,7,0,0,360,361,3,66,33,0,361,362,
        3,66,33,0,362,363,3,66,33,0,363,364,3,66,33,0,364,365,3,66,33,0,
        365,366,3,66,33,0,366,453,1,0,0,0,367,368,5,32,0,0,368,453,3,66,
        33,0,369,453,5,33,0,0,370,371,5,34,0,0,371,372,3,66,33,0,372,373,
        3,50,25,0,373,453,1,0,0,0,374,375,5,35,0,0,375,377,5,50,0,0,376,
        378,3,50,25,0,377,376,1,0,0,0,378,379,1,0,0,0,379,377,1,0,0,0,379,
        380,1,0,0,0,380,453,1,0,0,0,381,382,5,36,0,0,382,402,5,57,0,0,383,
        384,3,66,33,0,384,385,3,66,33,0,385,386,3,66,33,0,386,403,1,0,0,
        0,387,388,5,37,0,0,388,389,3,66,33,0,389,390,3,66,33,0,390,398,3,
        66,33,0,391,395,5,57,0,0,392,394,3,66,33,0,393,392,1,0,0,0,394,397,
        1,0,0,0,395,393,1,0,0,0,395,396,1,0,0,0,396,399,1,0,0,0,397,395,
        1,0,0,0,398,391,1,0,0,0,399,400,1,0,0,0,400,398,1,0,0,0,400,401,
        1,0,0,0,401,403,1,0,0,0,402,383,1,0,0,0,402,387,1,0,0,0,403,453,
        1,0,0,0,404,405,5,38,0,0,405,406,3,66,33,0,406,407,3,66,33,0,407,
        408,3,66,33,0,408,410,3,66,33,0,409,411,3,66,33,0,410,409,1,0,0,
        0,410,411,1,0,0,0,411,453,1,0,0,0,412,413,5,41,0,0,413,414,3,66,
        33,0,414,415,3,66,33,0,415,417,3,66,33,0,416,418,5,42,0,0,417,416,
        1,0,0,0,417,418,1,0,0,0,418,453,1,0,0,0,419,420,5,47,0,0,420,421,
        3,66,33,0,421,425,3,66,33,0,422,424,3,66,33,0,423,422,1,0,0,0,424,
        427,1,0,0,0,425,423,1,0,0,0,425,426,1,0,0,0,426,453,1,0,0,0,427,
        425,1,0,0,0,428,429,5,48,0,0,429,435,5,50,0,0,430,431,3,66,33,0,
        431,432,3,66,33,0,432,433,3,66,33,0,433,434,3,66,33,0,434,436,1,
        0,0,0,435,430,1,0,0,0,436,437,1,0,0,0,437,435,1,0,0,0,437,438,1,
        0,0,0,438,453,1,0,0,0,439,440,5,49,0,0,440,448,5,50,0,0,441,442,
        3,66,33,0,442,443,3,66,33,0,443,444,3,66,33,0,444,445,3,66,33,0,
        445,446,3,66,33,0,446,447,3,66,33,0,447,449,1,0,0,0,448,441,1,0,
        0,0,449,450,1,0,0,0,450,448,1,0,0,0,450,451,1,0,0,0,451,453,1,0,
        0,0,452,275,1,0,0,0,452,279,1,0,0,0,452,293,1,0,0,0,452,308,1,0,
        0,0,452,324,1,0,0,0,452,329,1,0,0,0,452,335,1,0,0,0,452,341,1,0,
        0,0,452,349,1,0,0,0,452,359,1,0,0,0,452,367,1,0,0,0,452,369,1,0,
        0,0,452,370,1,0,0,0,452,374,1,0,0,0,452,381,1,0,0,0,452,404,1,0,
        0,0,452,412,1,0,0,0,452,419,1,0,0,0,452,428,1,0,0,0,452,439,1,0,
        0,0,453,455,1,0,0,0,454,456,3,2,1,0,455,454,1,0,0,0,455,456,1,0,
        0,0,456,51,1,0,0,0,457,459,3,54,27,0,458,457,1,0,0,0,459,460,1,0,
        0,0,460,458,1,0,0,0,460,461,1,0,0,0,461,53,1,0,0,0,462,463,3,68,
        34,0,463,464,3,70,35,0,464,465,3,68,34,0,465,466,3,70,35,0,466,467,
        3,64,32,0,467,55,1,0,0,0,468,470,3,58,29,0,469,468,1,0,0,0,470,471,
        1,0,0,0,471,469,1,0,0,0,471,472,1,0,0,0,472,57,1,0,0,0,473,474,3,
        68,34,0,474,475,3,68,34,0,475,59,1,0,0,0,476,478,3,62,31,0,477,476,
        1,0,0,0,478,479,1,0,0,0,479,477,1,0,0,0,479,480,1,0,0,0,480,61,1,
        0,0,0,481,482,7,2,0,0,482,483,3,70,35,0,483,484,5,50,0,0,484,485,
        3,70,35,0,485,486,3,70,35,0,486,487,5,50,0,0,487,488,3,70,35,0,488,
        489,3,50,25,0,489,63,1,0,0,0,490,491,7,8,0,0,491,65,1,0,0,0,492,
        493,7,8,0,0,493,67,1,0,0,0,494,495,7,9,0,0,495,69,1,0,0,0,496,497,
        7,10,0,0,497,71,1,0,0,0,44,87,89,98,106,118,132,148,172,187,204,
        215,227,237,247,253,257,259,273,284,288,290,299,303,305,315,319,
        321,339,347,357,379,395,400,402,410,417,425,437,450,452,455,460,
        471,479
    ]

class RosettaMRParser ( Parser ):

    grammarFileName = "RosettaMRParser.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'AtomPair'", "'NamedAtomPair'", "'Angle'", 
                     "'NamedAngle'", "'Dihedral'", "'DihedralPair'", "'CoordinateConstraint'", 
                     "'LocalCoordinateConstraint'", "'AmbiguousNMRDistance'", 
                     "'SiteConstraint'", "'SiteConstraintResidues'", "'MinResidueAtomicDistance'", 
                     "'BigBin'", "'MultiConstraint'", "'AmbiguousConstraint'", 
                     "'KofNConstraint'", "'END'", "'CIRCULARHARMONIC'", 
                     "'PERIODICBOUNDED'", "'OFFSETPERIODICBOUNDED'", "'AMBERPERIODIC'", 
                     "'CHARMMPERIODIC'", "'CIRCULARSIGMOIDAL'", "'CIRCULARSPLINE'", 
                     "'HARMONIC'", "'FLAT_HARMONIC'", "'BOUNDED'", "'GAUSSIANFUNC'", 
                     "'WEIGHT'", "'SOGFUNC'", "'MIXTUREFUNC'", "'CONSTANTFUNC'", 
                     "'IDENTITY'", "'SCALARWEIGHTEDFUNC'", "'SUMFUNC'", 
                     "'SPLINE'", "'NONE'", "'FADE'", "'SIGMOID'", "'SQUARE_WELL'", 
                     "'SQUARE_WELL2'", "'DEGREES'", "'LINEAR_PENALTY'", 
                     "'KARPLUS'", "'SOEDINGFUNC'", "'TOPOUT'", "'ETABLE'", 
                     "'USOG'", "'SOG'" ]

    symbolicNames = [ "<INVALID>", "AtomPair", "NamedAtomPair", "Angle", 
                      "NamedAngle", "Dihedral", "DihedralPair", "CoordinateConstraint", 
                      "LocalCoordinateConstraint", "AmbiguousNMRDistance", 
                      "SiteConstraint", "SiteConstraintResidues", "MinResidueAtomicDistance", 
                      "BigBin", "MultiConstraint", "AmbiguousConstraint", 
                      "KofNConstraint", "END", "CIRCULARHARMONIC", "PERIODICBOUNDED", 
                      "OFFSETPERIODICBOUNDED", "AMBERPERIODIC", "CHARMMPERIODIC", 
                      "CIRCULARSIGMOIDAL", "CIRCULARSPLINE", "HARMONIC", 
                      "FLAT_HARMONIC", "BOUNDED", "GAUSSIANFUNC", "WEIGHT", 
                      "SOGFUNC", "MIXTUREFUNC", "CONSTANTFUNC", "IDENTITY", 
                      "SCALARWEIGHTEDFUNC", "SUMFUNC", "SPLINE", "NONE", 
                      "FADE", "SIGMOID", "SQUARE_WELL", "SQUARE_WELL2", 
                      "DEGREES", "LINEAR_PENALTY", "KARPLUS", "SOEDINGFUNC", 
                      "TOPOUT", "ETABLE", "USOG", "SOG", "Integer", "Float", 
                      "SHARP_COMMENT", "EXCLM_COMMENT", "COMMENT", "Capital_integer", 
                      "Integer_capital", "Simple_name", "SPACE", "ENCLOSE_COMMENT", 
                      "SECTION_COMMENT", "LINE_COMMENT", "Atom_pair_selection", 
                      "Atom_selection", "Any_name", "SPACE_CM", "RETURN_CM" ]

    RULE_rosetta_mr = 0
    RULE_comment = 1
    RULE_atom_pair_restraints = 2
    RULE_atom_pair_restraint = 3
    RULE_angle_restraints = 4
    RULE_angle_restraint = 5
    RULE_dihedral_restraints = 6
    RULE_dihedral_restraint = 7
    RULE_dihedral_pair_restraints = 8
    RULE_dihedral_pair_restraint = 9
    RULE_coordinate_restraints = 10
    RULE_coordinate_restraint = 11
    RULE_local_coordinate_restraints = 12
    RULE_local_coordinate_restraint = 13
    RULE_site_restraints = 14
    RULE_site_restraint = 15
    RULE_site_residues_restraints = 16
    RULE_site_residues_restraint = 17
    RULE_min_residue_atomic_distance_restraints = 18
    RULE_min_residue_atomic_distance_restraint = 19
    RULE_big_bin_restraints = 20
    RULE_big_bin_restraint = 21
    RULE_nested_restraints = 22
    RULE_nested_restraint = 23
    RULE_any_restraint = 24
    RULE_func_type_def = 25
    RULE_rdc_restraints = 26
    RULE_rdc_restraint = 27
    RULE_disulfide_bond_linkages = 28
    RULE_disulfide_bond_linkage = 29
    RULE_atom_pair_w_chain_restraints = 30
    RULE_atom_pair_w_chain_restraint = 31
    RULE_number = 32
    RULE_number_f = 33
    RULE_gen_res_num = 34
    RULE_gen_simple_name = 35

    ruleNames =  [ "rosetta_mr", "comment", "atom_pair_restraints", "atom_pair_restraint", 
                   "angle_restraints", "angle_restraint", "dihedral_restraints", 
                   "dihedral_restraint", "dihedral_pair_restraints", "dihedral_pair_restraint", 
                   "coordinate_restraints", "coordinate_restraint", "local_coordinate_restraints", 
                   "local_coordinate_restraint", "site_restraints", "site_restraint", 
                   "site_residues_restraints", "site_residues_restraint", 
                   "min_residue_atomic_distance_restraints", "min_residue_atomic_distance_restraint", 
                   "big_bin_restraints", "big_bin_restraint", "nested_restraints", 
                   "nested_restraint", "any_restraint", "func_type_def", 
                   "rdc_restraints", "rdc_restraint", "disulfide_bond_linkages", 
                   "disulfide_bond_linkage", "atom_pair_w_chain_restraints", 
                   "atom_pair_w_chain_restraint", "number", "number_f", 
                   "gen_res_num", "gen_simple_name" ]

    EOF = Token.EOF
    AtomPair=1
    NamedAtomPair=2
    Angle=3
    NamedAngle=4
    Dihedral=5
    DihedralPair=6
    CoordinateConstraint=7
    LocalCoordinateConstraint=8
    AmbiguousNMRDistance=9
    SiteConstraint=10
    SiteConstraintResidues=11
    MinResidueAtomicDistance=12
    BigBin=13
    MultiConstraint=14
    AmbiguousConstraint=15
    KofNConstraint=16
    END=17
    CIRCULARHARMONIC=18
    PERIODICBOUNDED=19
    OFFSETPERIODICBOUNDED=20
    AMBERPERIODIC=21
    CHARMMPERIODIC=22
    CIRCULARSIGMOIDAL=23
    CIRCULARSPLINE=24
    HARMONIC=25
    FLAT_HARMONIC=26
    BOUNDED=27
    GAUSSIANFUNC=28
    WEIGHT=29
    SOGFUNC=30
    MIXTUREFUNC=31
    CONSTANTFUNC=32
    IDENTITY=33
    SCALARWEIGHTEDFUNC=34
    SUMFUNC=35
    SPLINE=36
    NONE=37
    FADE=38
    SIGMOID=39
    SQUARE_WELL=40
    SQUARE_WELL2=41
    DEGREES=42
    LINEAR_PENALTY=43
    KARPLUS=44
    SOEDINGFUNC=45
    TOPOUT=46
    ETABLE=47
    USOG=48
    SOG=49
    Integer=50
    Float=51
    SHARP_COMMENT=52
    EXCLM_COMMENT=53
    COMMENT=54
    Capital_integer=55
    Integer_capital=56
    Simple_name=57
    SPACE=58
    ENCLOSE_COMMENT=59
    SECTION_COMMENT=60
    LINE_COMMENT=61
    Atom_pair_selection=62
    Atom_selection=63
    Any_name=64
    SPACE_CM=65
    RETURN_CM=66

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.0")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class Rosetta_mrContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(RosettaMRParser.EOF, 0)

        def comment(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.CommentContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.CommentContext,i)


        def atom_pair_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Atom_pair_restraintsContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Atom_pair_restraintsContext,i)


        def angle_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Angle_restraintsContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Angle_restraintsContext,i)


        def dihedral_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Dihedral_restraintsContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Dihedral_restraintsContext,i)


        def dihedral_pair_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Dihedral_pair_restraintsContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Dihedral_pair_restraintsContext,i)


        def coordinate_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Coordinate_restraintsContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Coordinate_restraintsContext,i)


        def local_coordinate_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Local_coordinate_restraintsContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Local_coordinate_restraintsContext,i)


        def site_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Site_restraintsContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Site_restraintsContext,i)


        def site_residues_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Site_residues_restraintsContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Site_residues_restraintsContext,i)


        def min_residue_atomic_distance_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Min_residue_atomic_distance_restraintsContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Min_residue_atomic_distance_restraintsContext,i)


        def big_bin_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Big_bin_restraintsContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Big_bin_restraintsContext,i)


        def nested_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Nested_restraintsContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Nested_restraintsContext,i)


        def rdc_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Rdc_restraintsContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Rdc_restraintsContext,i)


        def disulfide_bond_linkages(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Disulfide_bond_linkagesContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Disulfide_bond_linkagesContext,i)


        def atom_pair_w_chain_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Atom_pair_w_chain_restraintsContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Atom_pair_w_chain_restraintsContext,i)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_rosetta_mr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRosetta_mr" ):
                listener.enterRosetta_mr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRosetta_mr" ):
                listener.exitRosetta_mr(self)




    def rosetta_mr(self):

        localctx = RosettaMRParser.Rosetta_mrContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_rosetta_mr)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 89
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 127226689473347582) != 0):
                self.state = 87
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,0,self._ctx)
                if la_ == 1:
                    self.state = 72
                    self.comment()
                    pass

                elif la_ == 2:
                    self.state = 73
                    self.atom_pair_restraints()
                    pass

                elif la_ == 3:
                    self.state = 74
                    self.angle_restraints()
                    pass

                elif la_ == 4:
                    self.state = 75
                    self.dihedral_restraints()
                    pass

                elif la_ == 5:
                    self.state = 76
                    self.dihedral_pair_restraints()
                    pass

                elif la_ == 6:
                    self.state = 77
                    self.coordinate_restraints()
                    pass

                elif la_ == 7:
                    self.state = 78
                    self.local_coordinate_restraints()
                    pass

                elif la_ == 8:
                    self.state = 79
                    self.site_restraints()
                    pass

                elif la_ == 9:
                    self.state = 80
                    self.site_residues_restraints()
                    pass

                elif la_ == 10:
                    self.state = 81
                    self.min_residue_atomic_distance_restraints()
                    pass

                elif la_ == 11:
                    self.state = 82
                    self.big_bin_restraints()
                    pass

                elif la_ == 12:
                    self.state = 83
                    self.nested_restraints()
                    pass

                elif la_ == 13:
                    self.state = 84
                    self.rdc_restraints()
                    pass

                elif la_ == 14:
                    self.state = 85
                    self.disulfide_bond_linkages()
                    pass

                elif la_ == 15:
                    self.state = 86
                    self.atom_pair_w_chain_restraints()
                    pass


                self.state = 91
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 92
            self.match(RosettaMRParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CommentContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def COMMENT(self):
            return self.getToken(RosettaMRParser.COMMENT, 0)

        def RETURN_CM(self):
            return self.getToken(RosettaMRParser.RETURN_CM, 0)

        def EOF(self):
            return self.getToken(RosettaMRParser.EOF, 0)

        def Atom_pair_selection(self, i:int=None):
            if i is None:
                return self.getTokens(RosettaMRParser.Atom_pair_selection)
            else:
                return self.getToken(RosettaMRParser.Atom_pair_selection, i)

        def Atom_selection(self, i:int=None):
            if i is None:
                return self.getTokens(RosettaMRParser.Atom_selection)
            else:
                return self.getToken(RosettaMRParser.Atom_selection, i)

        def Any_name(self, i:int=None):
            if i is None:
                return self.getTokens(RosettaMRParser.Any_name)
            else:
                return self.getToken(RosettaMRParser.Any_name, i)

        def getRuleIndex(self):
            return RosettaMRParser.RULE_comment

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComment" ):
                listener.enterComment(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComment" ):
                listener.exitComment(self)




    def comment(self):

        localctx = RosettaMRParser.CommentContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_comment)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 94
            self.match(RosettaMRParser.COMMENT)
            self.state = 98
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while ((((_la - 62)) & ~0x3f) == 0 and ((1 << (_la - 62)) & 7) != 0):
                self.state = 95
                _la = self._input.LA(1)
                if not(((((_la - 62)) & ~0x3f) == 0 and ((1 << (_la - 62)) & 7) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 100
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 101
            _la = self._input.LA(1)
            if not(_la==-1 or _la==66):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Atom_pair_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def atom_pair_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Atom_pair_restraintContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Atom_pair_restraintContext,i)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_atom_pair_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAtom_pair_restraints" ):
                listener.enterAtom_pair_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAtom_pair_restraints" ):
                listener.exitAtom_pair_restraints(self)




    def atom_pair_restraints(self):

        localctx = RosettaMRParser.Atom_pair_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_atom_pair_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 104 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 103
                    self.atom_pair_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 106 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,3,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Atom_pair_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def gen_simple_name(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Gen_simple_nameContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Gen_simple_nameContext,i)


        def gen_res_num(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Gen_res_numContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Gen_res_numContext,i)


        def func_type_def(self):
            return self.getTypedRuleContext(RosettaMRParser.Func_type_defContext,0)


        def AtomPair(self):
            return self.getToken(RosettaMRParser.AtomPair, 0)

        def NamedAtomPair(self):
            return self.getToken(RosettaMRParser.NamedAtomPair, 0)

        def AmbiguousNMRDistance(self):
            return self.getToken(RosettaMRParser.AmbiguousNMRDistance, 0)

        def getRuleIndex(self):
            return RosettaMRParser.RULE_atom_pair_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAtom_pair_restraint" ):
                listener.enterAtom_pair_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAtom_pair_restraint" ):
                listener.exitAtom_pair_restraint(self)




    def atom_pair_restraint(self):

        localctx = RosettaMRParser.Atom_pair_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_atom_pair_restraint)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 108
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 518) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 109
            self.gen_simple_name()
            self.state = 110
            self.gen_res_num()
            self.state = 111
            self.gen_simple_name()
            self.state = 112
            self.gen_res_num()
            self.state = 113
            self.func_type_def()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Angle_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def angle_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Angle_restraintContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Angle_restraintContext,i)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_angle_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAngle_restraints" ):
                listener.enterAngle_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAngle_restraints" ):
                listener.exitAngle_restraints(self)




    def angle_restraints(self):

        localctx = RosettaMRParser.Angle_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_angle_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 116 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 115
                    self.angle_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 118 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,4,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Angle_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def gen_simple_name(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Gen_simple_nameContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Gen_simple_nameContext,i)


        def gen_res_num(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Gen_res_numContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Gen_res_numContext,i)


        def func_type_def(self):
            return self.getTypedRuleContext(RosettaMRParser.Func_type_defContext,0)


        def Angle(self):
            return self.getToken(RosettaMRParser.Angle, 0)

        def NamedAngle(self):
            return self.getToken(RosettaMRParser.NamedAngle, 0)

        def getRuleIndex(self):
            return RosettaMRParser.RULE_angle_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAngle_restraint" ):
                listener.enterAngle_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAngle_restraint" ):
                listener.exitAngle_restraint(self)




    def angle_restraint(self):

        localctx = RosettaMRParser.Angle_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_angle_restraint)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 120
            _la = self._input.LA(1)
            if not(_la==3 or _la==4):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 121
            self.gen_simple_name()
            self.state = 122
            self.gen_res_num()
            self.state = 123
            self.gen_simple_name()
            self.state = 124
            self.gen_res_num()
            self.state = 125
            self.gen_simple_name()
            self.state = 126
            self.gen_res_num()
            self.state = 127
            self.func_type_def()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Dihedral_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def dihedral_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Dihedral_restraintContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Dihedral_restraintContext,i)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_dihedral_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDihedral_restraints" ):
                listener.enterDihedral_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDihedral_restraints" ):
                listener.exitDihedral_restraints(self)




    def dihedral_restraints(self):

        localctx = RosettaMRParser.Dihedral_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_dihedral_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 130 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 129
                    self.dihedral_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 132 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,5,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Dihedral_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Dihedral(self):
            return self.getToken(RosettaMRParser.Dihedral, 0)

        def gen_simple_name(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Gen_simple_nameContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Gen_simple_nameContext,i)


        def gen_res_num(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Gen_res_numContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Gen_res_numContext,i)


        def func_type_def(self):
            return self.getTypedRuleContext(RosettaMRParser.Func_type_defContext,0)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_dihedral_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDihedral_restraint" ):
                listener.enterDihedral_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDihedral_restraint" ):
                listener.exitDihedral_restraint(self)




    def dihedral_restraint(self):

        localctx = RosettaMRParser.Dihedral_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_dihedral_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 134
            self.match(RosettaMRParser.Dihedral)
            self.state = 135
            self.gen_simple_name()
            self.state = 136
            self.gen_res_num()
            self.state = 137
            self.gen_simple_name()
            self.state = 138
            self.gen_res_num()
            self.state = 139
            self.gen_simple_name()
            self.state = 140
            self.gen_res_num()
            self.state = 141
            self.gen_simple_name()
            self.state = 142
            self.gen_res_num()
            self.state = 143
            self.func_type_def()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Dihedral_pair_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def dihedral_pair_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Dihedral_pair_restraintContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Dihedral_pair_restraintContext,i)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_dihedral_pair_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDihedral_pair_restraints" ):
                listener.enterDihedral_pair_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDihedral_pair_restraints" ):
                listener.exitDihedral_pair_restraints(self)




    def dihedral_pair_restraints(self):

        localctx = RosettaMRParser.Dihedral_pair_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_dihedral_pair_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 146 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 145
                    self.dihedral_pair_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 148 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,6,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Dihedral_pair_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def DihedralPair(self):
            return self.getToken(RosettaMRParser.DihedralPair, 0)

        def gen_simple_name(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Gen_simple_nameContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Gen_simple_nameContext,i)


        def gen_res_num(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Gen_res_numContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Gen_res_numContext,i)


        def func_type_def(self):
            return self.getTypedRuleContext(RosettaMRParser.Func_type_defContext,0)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_dihedral_pair_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDihedral_pair_restraint" ):
                listener.enterDihedral_pair_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDihedral_pair_restraint" ):
                listener.exitDihedral_pair_restraint(self)




    def dihedral_pair_restraint(self):

        localctx = RosettaMRParser.Dihedral_pair_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_dihedral_pair_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 150
            self.match(RosettaMRParser.DihedralPair)
            self.state = 151
            self.gen_simple_name()
            self.state = 152
            self.gen_res_num()
            self.state = 153
            self.gen_simple_name()
            self.state = 154
            self.gen_res_num()
            self.state = 155
            self.gen_simple_name()
            self.state = 156
            self.gen_res_num()
            self.state = 157
            self.gen_simple_name()
            self.state = 158
            self.gen_res_num()
            self.state = 159
            self.gen_simple_name()
            self.state = 160
            self.gen_res_num()
            self.state = 161
            self.gen_simple_name()
            self.state = 162
            self.gen_res_num()
            self.state = 163
            self.gen_simple_name()
            self.state = 164
            self.gen_res_num()
            self.state = 165
            self.gen_simple_name()
            self.state = 166
            self.gen_res_num()
            self.state = 167
            self.func_type_def()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Coordinate_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def coordinate_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Coordinate_restraintContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Coordinate_restraintContext,i)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_coordinate_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCoordinate_restraints" ):
                listener.enterCoordinate_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCoordinate_restraints" ):
                listener.exitCoordinate_restraints(self)




    def coordinate_restraints(self):

        localctx = RosettaMRParser.Coordinate_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_coordinate_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 170 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 169
                    self.coordinate_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 172 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,7,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Coordinate_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CoordinateConstraint(self):
            return self.getToken(RosettaMRParser.CoordinateConstraint, 0)

        def gen_simple_name(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Gen_simple_nameContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Gen_simple_nameContext,i)


        def gen_res_num(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Gen_res_numContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Gen_res_numContext,i)


        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.NumberContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.NumberContext,i)


        def func_type_def(self):
            return self.getTypedRuleContext(RosettaMRParser.Func_type_defContext,0)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_coordinate_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCoordinate_restraint" ):
                listener.enterCoordinate_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCoordinate_restraint" ):
                listener.exitCoordinate_restraint(self)




    def coordinate_restraint(self):

        localctx = RosettaMRParser.Coordinate_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_coordinate_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 174
            self.match(RosettaMRParser.CoordinateConstraint)
            self.state = 175
            self.gen_simple_name()
            self.state = 176
            self.gen_res_num()
            self.state = 177
            self.gen_simple_name()
            self.state = 178
            self.gen_res_num()
            self.state = 179
            self.number()
            self.state = 180
            self.number()
            self.state = 181
            self.number()
            self.state = 182
            self.func_type_def()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Local_coordinate_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def local_coordinate_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Local_coordinate_restraintContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Local_coordinate_restraintContext,i)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_local_coordinate_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLocal_coordinate_restraints" ):
                listener.enterLocal_coordinate_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLocal_coordinate_restraints" ):
                listener.exitLocal_coordinate_restraints(self)




    def local_coordinate_restraints(self):

        localctx = RosettaMRParser.Local_coordinate_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_local_coordinate_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 185 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 184
                    self.local_coordinate_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 187 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,8,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Local_coordinate_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LocalCoordinateConstraint(self):
            return self.getToken(RosettaMRParser.LocalCoordinateConstraint, 0)

        def gen_simple_name(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Gen_simple_nameContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Gen_simple_nameContext,i)


        def gen_res_num(self):
            return self.getTypedRuleContext(RosettaMRParser.Gen_res_numContext,0)


        def Integer(self):
            return self.getToken(RosettaMRParser.Integer, 0)

        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.NumberContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.NumberContext,i)


        def func_type_def(self):
            return self.getTypedRuleContext(RosettaMRParser.Func_type_defContext,0)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_local_coordinate_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLocal_coordinate_restraint" ):
                listener.enterLocal_coordinate_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLocal_coordinate_restraint" ):
                listener.exitLocal_coordinate_restraint(self)




    def local_coordinate_restraint(self):

        localctx = RosettaMRParser.Local_coordinate_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_local_coordinate_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 189
            self.match(RosettaMRParser.LocalCoordinateConstraint)
            self.state = 190
            self.gen_simple_name()
            self.state = 191
            self.gen_res_num()
            self.state = 192
            self.gen_simple_name()
            self.state = 193
            self.gen_simple_name()
            self.state = 194
            self.gen_simple_name()
            self.state = 195
            self.match(RosettaMRParser.Integer)
            self.state = 196
            self.number()
            self.state = 197
            self.number()
            self.state = 198
            self.number()
            self.state = 199
            self.func_type_def()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Site_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def site_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Site_restraintContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Site_restraintContext,i)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_site_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSite_restraints" ):
                listener.enterSite_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSite_restraints" ):
                listener.exitSite_restraints(self)




    def site_restraints(self):

        localctx = RosettaMRParser.Site_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_site_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 202 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 201
                    self.site_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 204 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,9,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Site_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def SiteConstraint(self):
            return self.getToken(RosettaMRParser.SiteConstraint, 0)

        def gen_simple_name(self):
            return self.getTypedRuleContext(RosettaMRParser.Gen_simple_nameContext,0)


        def gen_res_num(self):
            return self.getTypedRuleContext(RosettaMRParser.Gen_res_numContext,0)


        def Simple_name(self):
            return self.getToken(RosettaMRParser.Simple_name, 0)

        def func_type_def(self):
            return self.getTypedRuleContext(RosettaMRParser.Func_type_defContext,0)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_site_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSite_restraint" ):
                listener.enterSite_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSite_restraint" ):
                listener.exitSite_restraint(self)




    def site_restraint(self):

        localctx = RosettaMRParser.Site_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_site_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 206
            self.match(RosettaMRParser.SiteConstraint)
            self.state = 207
            self.gen_simple_name()
            self.state = 208
            self.gen_res_num()
            self.state = 209
            self.match(RosettaMRParser.Simple_name)
            self.state = 210
            self.func_type_def()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Site_residues_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def site_residues_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Site_residues_restraintContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Site_residues_restraintContext,i)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_site_residues_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSite_residues_restraints" ):
                listener.enterSite_residues_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSite_residues_restraints" ):
                listener.exitSite_residues_restraints(self)




    def site_residues_restraints(self):

        localctx = RosettaMRParser.Site_residues_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_site_residues_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 213 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 212
                    self.site_residues_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 215 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,10,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Site_residues_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def SiteConstraintResidues(self):
            return self.getToken(RosettaMRParser.SiteConstraintResidues, 0)

        def gen_res_num(self):
            return self.getTypedRuleContext(RosettaMRParser.Gen_res_numContext,0)


        def gen_simple_name(self):
            return self.getTypedRuleContext(RosettaMRParser.Gen_simple_nameContext,0)


        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(RosettaMRParser.Integer)
            else:
                return self.getToken(RosettaMRParser.Integer, i)

        def func_type_def(self):
            return self.getTypedRuleContext(RosettaMRParser.Func_type_defContext,0)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_site_residues_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSite_residues_restraint" ):
                listener.enterSite_residues_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSite_residues_restraint" ):
                listener.exitSite_residues_restraint(self)




    def site_residues_restraint(self):

        localctx = RosettaMRParser.Site_residues_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_site_residues_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 217
            self.match(RosettaMRParser.SiteConstraintResidues)
            self.state = 218
            self.gen_res_num()
            self.state = 219
            self.gen_simple_name()
            self.state = 220
            self.match(RosettaMRParser.Integer)
            self.state = 221
            self.match(RosettaMRParser.Integer)
            self.state = 222
            self.func_type_def()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Min_residue_atomic_distance_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def min_residue_atomic_distance_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Min_residue_atomic_distance_restraintContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Min_residue_atomic_distance_restraintContext,i)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_min_residue_atomic_distance_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMin_residue_atomic_distance_restraints" ):
                listener.enterMin_residue_atomic_distance_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMin_residue_atomic_distance_restraints" ):
                listener.exitMin_residue_atomic_distance_restraints(self)




    def min_residue_atomic_distance_restraints(self):

        localctx = RosettaMRParser.Min_residue_atomic_distance_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_min_residue_atomic_distance_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 225 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 224
                    self.min_residue_atomic_distance_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 227 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,11,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Min_residue_atomic_distance_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def MinResidueAtomicDistance(self):
            return self.getToken(RosettaMRParser.MinResidueAtomicDistance, 0)

        def gen_res_num(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Gen_res_numContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Gen_res_numContext,i)


        def number(self):
            return self.getTypedRuleContext(RosettaMRParser.NumberContext,0)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_min_residue_atomic_distance_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMin_residue_atomic_distance_restraint" ):
                listener.enterMin_residue_atomic_distance_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMin_residue_atomic_distance_restraint" ):
                listener.exitMin_residue_atomic_distance_restraint(self)




    def min_residue_atomic_distance_restraint(self):

        localctx = RosettaMRParser.Min_residue_atomic_distance_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_min_residue_atomic_distance_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 229
            self.match(RosettaMRParser.MinResidueAtomicDistance)
            self.state = 230
            self.gen_res_num()
            self.state = 231
            self.gen_res_num()
            self.state = 232
            self.number()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Big_bin_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def big_bin_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Big_bin_restraintContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Big_bin_restraintContext,i)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_big_bin_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBig_bin_restraints" ):
                listener.enterBig_bin_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBig_bin_restraints" ):
                listener.exitBig_bin_restraints(self)




    def big_bin_restraints(self):

        localctx = RosettaMRParser.Big_bin_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_big_bin_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 235 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 234
                    self.big_bin_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 237 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,12,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Big_bin_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def BigBin(self):
            return self.getToken(RosettaMRParser.BigBin, 0)

        def gen_res_num(self):
            return self.getTypedRuleContext(RosettaMRParser.Gen_res_numContext,0)


        def Simple_name(self):
            return self.getToken(RosettaMRParser.Simple_name, 0)

        def number(self):
            return self.getTypedRuleContext(RosettaMRParser.NumberContext,0)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_big_bin_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBig_bin_restraint" ):
                listener.enterBig_bin_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBig_bin_restraint" ):
                listener.exitBig_bin_restraint(self)




    def big_bin_restraint(self):

        localctx = RosettaMRParser.Big_bin_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_big_bin_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 239
            self.match(RosettaMRParser.BigBin)
            self.state = 240
            self.gen_res_num()
            self.state = 241
            self.match(RosettaMRParser.Simple_name)
            self.state = 242
            self.number()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Nested_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def nested_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Nested_restraintContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Nested_restraintContext,i)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_nested_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNested_restraints" ):
                listener.enterNested_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNested_restraints" ):
                listener.exitNested_restraints(self)




    def nested_restraints(self):

        localctx = RosettaMRParser.Nested_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_nested_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 245 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 244
                    self.nested_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 247 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,13,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Nested_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def END(self):
            return self.getToken(RosettaMRParser.END, 0)

        def MultiConstraint(self):
            return self.getToken(RosettaMRParser.MultiConstraint, 0)

        def AmbiguousConstraint(self):
            return self.getToken(RosettaMRParser.AmbiguousConstraint, 0)

        def any_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Any_restraintContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Any_restraintContext,i)


        def nested_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Nested_restraintContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Nested_restraintContext,i)


        def KofNConstraint(self):
            return self.getToken(RosettaMRParser.KofNConstraint, 0)

        def Integer(self):
            return self.getToken(RosettaMRParser.Integer, 0)

        def getRuleIndex(self):
            return RosettaMRParser.RULE_nested_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNested_restraint" ):
                listener.enterNested_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNested_restraint" ):
                listener.exitNested_restraint(self)




    def nested_restraint(self):

        localctx = RosettaMRParser.Nested_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_nested_restraint)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 253
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [14]:
                self.state = 249
                self.match(RosettaMRParser.MultiConstraint)
                pass
            elif token in [15]:
                self.state = 250
                self.match(RosettaMRParser.AmbiguousConstraint)
                pass
            elif token in [16]:
                self.state = 251
                self.match(RosettaMRParser.KofNConstraint)
                self.state = 252
                self.match(RosettaMRParser.Integer)
                pass
            else:
                raise NoViableAltException(self)

            self.state = 257 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 257
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]:
                    self.state = 255
                    self.any_restraint()
                    pass
                elif token in [14, 15, 16]:
                    self.state = 256
                    self.nested_restraint()
                    pass
                else:
                    raise NoViableAltException(self)

                self.state = 259 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 131070) != 0)):
                    break

            self.state = 261
            self.match(RosettaMRParser.END)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Any_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def atom_pair_restraint(self):
            return self.getTypedRuleContext(RosettaMRParser.Atom_pair_restraintContext,0)


        def angle_restraint(self):
            return self.getTypedRuleContext(RosettaMRParser.Angle_restraintContext,0)


        def dihedral_restraint(self):
            return self.getTypedRuleContext(RosettaMRParser.Dihedral_restraintContext,0)


        def dihedral_pair_restraint(self):
            return self.getTypedRuleContext(RosettaMRParser.Dihedral_pair_restraintContext,0)


        def coordinate_restraint(self):
            return self.getTypedRuleContext(RosettaMRParser.Coordinate_restraintContext,0)


        def local_coordinate_restraint(self):
            return self.getTypedRuleContext(RosettaMRParser.Local_coordinate_restraintContext,0)


        def site_restraint(self):
            return self.getTypedRuleContext(RosettaMRParser.Site_restraintContext,0)


        def site_residues_restraint(self):
            return self.getTypedRuleContext(RosettaMRParser.Site_residues_restraintContext,0)


        def min_residue_atomic_distance_restraint(self):
            return self.getTypedRuleContext(RosettaMRParser.Min_residue_atomic_distance_restraintContext,0)


        def big_bin_restraint(self):
            return self.getTypedRuleContext(RosettaMRParser.Big_bin_restraintContext,0)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_any_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAny_restraint" ):
                listener.enterAny_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAny_restraint" ):
                listener.exitAny_restraint(self)




    def any_restraint(self):

        localctx = RosettaMRParser.Any_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_any_restraint)
        try:
            self.state = 273
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [1, 2, 9]:
                self.enterOuterAlt(localctx, 1)
                self.state = 263
                self.atom_pair_restraint()
                pass
            elif token in [3, 4]:
                self.enterOuterAlt(localctx, 2)
                self.state = 264
                self.angle_restraint()
                pass
            elif token in [5]:
                self.enterOuterAlt(localctx, 3)
                self.state = 265
                self.dihedral_restraint()
                pass
            elif token in [6]:
                self.enterOuterAlt(localctx, 4)
                self.state = 266
                self.dihedral_pair_restraint()
                pass
            elif token in [7]:
                self.enterOuterAlt(localctx, 5)
                self.state = 267
                self.coordinate_restraint()
                pass
            elif token in [8]:
                self.enterOuterAlt(localctx, 6)
                self.state = 268
                self.local_coordinate_restraint()
                pass
            elif token in [10]:
                self.enterOuterAlt(localctx, 7)
                self.state = 269
                self.site_restraint()
                pass
            elif token in [11]:
                self.enterOuterAlt(localctx, 8)
                self.state = 270
                self.site_residues_restraint()
                pass
            elif token in [12]:
                self.enterOuterAlt(localctx, 9)
                self.state = 271
                self.min_residue_atomic_distance_restraint()
                pass
            elif token in [13]:
                self.enterOuterAlt(localctx, 10)
                self.state = 272
                self.big_bin_restraint()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Func_type_defContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def number_f(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Number_fContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Number_fContext,i)


        def BOUNDED(self):
            return self.getToken(RosettaMRParser.BOUNDED, 0)

        def PERIODICBOUNDED(self):
            return self.getToken(RosettaMRParser.PERIODICBOUNDED, 0)

        def OFFSETPERIODICBOUNDED(self):
            return self.getToken(RosettaMRParser.OFFSETPERIODICBOUNDED, 0)

        def CIRCULARSPLINE(self):
            return self.getToken(RosettaMRParser.CIRCULARSPLINE, 0)

        def GAUSSIANFUNC(self):
            return self.getToken(RosettaMRParser.GAUSSIANFUNC, 0)

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(RosettaMRParser.Simple_name)
            else:
                return self.getToken(RosettaMRParser.Simple_name, i)

        def SOGFUNC(self):
            return self.getToken(RosettaMRParser.SOGFUNC, 0)

        def Integer(self):
            return self.getToken(RosettaMRParser.Integer, 0)

        def CONSTANTFUNC(self):
            return self.getToken(RosettaMRParser.CONSTANTFUNC, 0)

        def IDENTITY(self):
            return self.getToken(RosettaMRParser.IDENTITY, 0)

        def SCALARWEIGHTEDFUNC(self):
            return self.getToken(RosettaMRParser.SCALARWEIGHTEDFUNC, 0)

        def func_type_def(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Func_type_defContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Func_type_defContext,i)


        def SUMFUNC(self):
            return self.getToken(RosettaMRParser.SUMFUNC, 0)

        def SPLINE(self):
            return self.getToken(RosettaMRParser.SPLINE, 0)

        def FADE(self):
            return self.getToken(RosettaMRParser.FADE, 0)

        def SQUARE_WELL2(self):
            return self.getToken(RosettaMRParser.SQUARE_WELL2, 0)

        def ETABLE(self):
            return self.getToken(RosettaMRParser.ETABLE, 0)

        def USOG(self):
            return self.getToken(RosettaMRParser.USOG, 0)

        def SOG(self):
            return self.getToken(RosettaMRParser.SOG, 0)

        def CIRCULARHARMONIC(self):
            return self.getToken(RosettaMRParser.CIRCULARHARMONIC, 0)

        def HARMONIC(self):
            return self.getToken(RosettaMRParser.HARMONIC, 0)

        def SIGMOID(self):
            return self.getToken(RosettaMRParser.SIGMOID, 0)

        def SQUARE_WELL(self):
            return self.getToken(RosettaMRParser.SQUARE_WELL, 0)

        def AMBERPERIODIC(self):
            return self.getToken(RosettaMRParser.AMBERPERIODIC, 0)

        def CHARMMPERIODIC(self):
            return self.getToken(RosettaMRParser.CHARMMPERIODIC, 0)

        def FLAT_HARMONIC(self):
            return self.getToken(RosettaMRParser.FLAT_HARMONIC, 0)

        def TOPOUT(self):
            return self.getToken(RosettaMRParser.TOPOUT, 0)

        def CIRCULARSIGMOIDAL(self):
            return self.getToken(RosettaMRParser.CIRCULARSIGMOIDAL, 0)

        def LINEAR_PENALTY(self):
            return self.getToken(RosettaMRParser.LINEAR_PENALTY, 0)

        def MIXTUREFUNC(self):
            return self.getToken(RosettaMRParser.MIXTUREFUNC, 0)

        def KARPLUS(self):
            return self.getToken(RosettaMRParser.KARPLUS, 0)

        def SOEDINGFUNC(self):
            return self.getToken(RosettaMRParser.SOEDINGFUNC, 0)

        def comment(self):
            return self.getTypedRuleContext(RosettaMRParser.CommentContext,0)


        def NONE(self):
            return self.getToken(RosettaMRParser.NONE, 0)

        def WEIGHT(self):
            return self.getToken(RosettaMRParser.WEIGHT, 0)

        def DEGREES(self):
            return self.getToken(RosettaMRParser.DEGREES, 0)

        def getRuleIndex(self):
            return RosettaMRParser.RULE_func_type_def

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFunc_type_def" ):
                listener.enterFunc_type_def(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFunc_type_def" ):
                listener.exitFunc_type_def(self)




    def func_type_def(self):

        localctx = RosettaMRParser.Func_type_defContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_func_type_def)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 452
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [18, 25, 39, 40]:
                self.state = 275
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 1649301258240) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 276
                self.number_f()
                self.state = 277
                self.number_f()
                pass
            elif token in [27]:
                self.state = 279
                self.match(RosettaMRParser.BOUNDED)
                self.state = 280
                self.number_f()
                self.state = 281
                self.number_f()
                self.state = 282
                self.number_f()
                self.state = 284
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,18,self._ctx)
                if la_ == 1:
                    self.state = 283
                    self.number_f()


                self.state = 290
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,20,self._ctx)
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt==1:
                        self.state = 288
                        self._errHandler.sync(self)
                        token = self._input.LA(1)
                        if token in [57]:
                            self.state = 286
                            self.match(RosettaMRParser.Simple_name)
                            pass
                        elif token in [50, 51]:
                            self.state = 287
                            self.number_f()
                            pass
                        else:
                            raise NoViableAltException(self)
                 
                    self.state = 292
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,20,self._ctx)

                pass
            elif token in [19]:
                self.state = 293
                self.match(RosettaMRParser.PERIODICBOUNDED)
                self.state = 294
                self.number_f()
                self.state = 295
                self.number_f()
                self.state = 296
                self.number_f()
                self.state = 297
                self.number_f()
                self.state = 299
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,21,self._ctx)
                if la_ == 1:
                    self.state = 298
                    self.number_f()


                self.state = 305
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,23,self._ctx)
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt==1:
                        self.state = 303
                        self._errHandler.sync(self)
                        token = self._input.LA(1)
                        if token in [57]:
                            self.state = 301
                            self.match(RosettaMRParser.Simple_name)
                            pass
                        elif token in [50, 51]:
                            self.state = 302
                            self.number_f()
                            pass
                        else:
                            raise NoViableAltException(self)
                 
                    self.state = 307
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,23,self._ctx)

                pass
            elif token in [20]:
                self.state = 308
                self.match(RosettaMRParser.OFFSETPERIODICBOUNDED)
                self.state = 309
                self.number_f()
                self.state = 310
                self.number_f()
                self.state = 311
                self.number_f()
                self.state = 312
                self.number_f()
                self.state = 313
                self.number_f()
                self.state = 315
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,24,self._ctx)
                if la_ == 1:
                    self.state = 314
                    self.number_f()


                self.state = 321
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,26,self._ctx)
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt==1:
                        self.state = 319
                        self._errHandler.sync(self)
                        token = self._input.LA(1)
                        if token in [57]:
                            self.state = 317
                            self.match(RosettaMRParser.Simple_name)
                            pass
                        elif token in [50, 51]:
                            self.state = 318
                            self.number_f()
                            pass
                        else:
                            raise NoViableAltException(self)
                 
                    self.state = 323
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,26,self._ctx)

                pass
            elif token in [21, 22, 26, 46]:
                self.state = 324
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 70368817577984) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 325
                self.number_f()
                self.state = 326
                self.number_f()
                self.state = 327
                self.number_f()
                pass
            elif token in [23, 43]:
                self.state = 329
                _la = self._input.LA(1)
                if not(_la==23 or _la==43):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 330
                self.number_f()
                self.state = 331
                self.number_f()
                self.state = 332
                self.number_f()
                self.state = 333
                self.number_f()
                pass
            elif token in [24]:
                self.state = 335
                self.match(RosettaMRParser.CIRCULARSPLINE)
                self.state = 337 
                self._errHandler.sync(self)
                _alt = 1
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt == 1:
                        self.state = 336
                        self.number_f()

                    else:
                        raise NoViableAltException(self)
                    self.state = 339 
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,27,self._ctx)

                pass
            elif token in [28]:
                self.state = 341
                self.match(RosettaMRParser.GAUSSIANFUNC)
                self.state = 342
                self.number_f()
                self.state = 343
                self.number_f()
                self.state = 344
                self.match(RosettaMRParser.Simple_name)
                self.state = 347
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==29:
                    self.state = 345
                    self.match(RosettaMRParser.WEIGHT)
                    self.state = 346
                    self.number_f()


                pass
            elif token in [30]:
                self.state = 349
                self.match(RosettaMRParser.SOGFUNC)
                self.state = 350
                self.match(RosettaMRParser.Integer)
                self.state = 355 
                self._errHandler.sync(self)
                _alt = 1
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt == 1:
                        self.state = 351
                        self.number_f()
                        self.state = 352
                        self.number_f()
                        self.state = 353
                        self.number_f()

                    else:
                        raise NoViableAltException(self)
                    self.state = 357 
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,29,self._ctx)

                pass
            elif token in [31, 44, 45]:
                self.state = 359
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 52778705616896) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 360
                self.number_f()
                self.state = 361
                self.number_f()
                self.state = 362
                self.number_f()
                self.state = 363
                self.number_f()
                self.state = 364
                self.number_f()
                self.state = 365
                self.number_f()
                pass
            elif token in [32]:
                self.state = 367
                self.match(RosettaMRParser.CONSTANTFUNC)
                self.state = 368
                self.number_f()
                pass
            elif token in [33]:
                self.state = 369
                self.match(RosettaMRParser.IDENTITY)
                pass
            elif token in [34]:
                self.state = 370
                self.match(RosettaMRParser.SCALARWEIGHTEDFUNC)
                self.state = 371
                self.number_f()
                self.state = 372
                self.func_type_def()
                pass
            elif token in [35]:
                self.state = 374
                self.match(RosettaMRParser.SUMFUNC)
                self.state = 375
                self.match(RosettaMRParser.Integer)
                self.state = 377 
                self._errHandler.sync(self)
                _alt = 1
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt == 1:
                        self.state = 376
                        self.func_type_def()

                    else:
                        raise NoViableAltException(self)
                    self.state = 379 
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,30,self._ctx)

                pass
            elif token in [36]:
                self.state = 381
                self.match(RosettaMRParser.SPLINE)
                self.state = 382
                self.match(RosettaMRParser.Simple_name)
                self.state = 402
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [50, 51]:
                    self.state = 383
                    self.number_f()
                    self.state = 384
                    self.number_f()
                    self.state = 385
                    self.number_f()
                    pass
                elif token in [37]:
                    self.state = 387
                    self.match(RosettaMRParser.NONE)
                    self.state = 388
                    self.number_f()
                    self.state = 389
                    self.number_f()
                    self.state = 390
                    self.number_f()
                    self.state = 398 
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    while True:
                        self.state = 391
                        self.match(RosettaMRParser.Simple_name)
                        self.state = 395
                        self._errHandler.sync(self)
                        _alt = self._interp.adaptivePredict(self._input,31,self._ctx)
                        while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                            if _alt==1:
                                self.state = 392
                                self.number_f() 
                            self.state = 397
                            self._errHandler.sync(self)
                            _alt = self._interp.adaptivePredict(self._input,31,self._ctx)

                        self.state = 400 
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)
                        if not (_la==57):
                            break

                    pass
                else:
                    raise NoViableAltException(self)

                pass
            elif token in [38]:
                self.state = 404
                self.match(RosettaMRParser.FADE)
                self.state = 405
                self.number_f()
                self.state = 406
                self.number_f()
                self.state = 407
                self.number_f()
                self.state = 408
                self.number_f()
                self.state = 410
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,34,self._ctx)
                if la_ == 1:
                    self.state = 409
                    self.number_f()


                pass
            elif token in [41]:
                self.state = 412
                self.match(RosettaMRParser.SQUARE_WELL2)
                self.state = 413
                self.number_f()
                self.state = 414
                self.number_f()
                self.state = 415
                self.number_f()
                self.state = 417
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==42:
                    self.state = 416
                    self.match(RosettaMRParser.DEGREES)


                pass
            elif token in [47]:
                self.state = 419
                self.match(RosettaMRParser.ETABLE)
                self.state = 420
                self.number_f()
                self.state = 421
                self.number_f()
                self.state = 425
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,36,self._ctx)
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt==1:
                        self.state = 422
                        self.number_f() 
                    self.state = 427
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,36,self._ctx)

                pass
            elif token in [48]:
                self.state = 428
                self.match(RosettaMRParser.USOG)
                self.state = 429
                self.match(RosettaMRParser.Integer)
                self.state = 435 
                self._errHandler.sync(self)
                _alt = 1
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt == 1:
                        self.state = 430
                        self.number_f()
                        self.state = 431
                        self.number_f()
                        self.state = 432
                        self.number_f()
                        self.state = 433
                        self.number_f()

                    else:
                        raise NoViableAltException(self)
                    self.state = 437 
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,37,self._ctx)

                pass
            elif token in [49]:
                self.state = 439
                self.match(RosettaMRParser.SOG)
                self.state = 440
                self.match(RosettaMRParser.Integer)
                self.state = 448 
                self._errHandler.sync(self)
                _alt = 1
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt == 1:
                        self.state = 441
                        self.number_f()
                        self.state = 442
                        self.number_f()
                        self.state = 443
                        self.number_f()
                        self.state = 444
                        self.number_f()
                        self.state = 445
                        self.number_f()
                        self.state = 446
                        self.number_f()

                    else:
                        raise NoViableAltException(self)
                    self.state = 450 
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,38,self._ctx)

                pass
            else:
                raise NoViableAltException(self)

            self.state = 455
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,40,self._ctx)
            if la_ == 1:
                self.state = 454
                self.comment()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Rdc_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def rdc_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Rdc_restraintContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Rdc_restraintContext,i)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_rdc_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRdc_restraints" ):
                listener.enterRdc_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRdc_restraints" ):
                listener.exitRdc_restraints(self)




    def rdc_restraints(self):

        localctx = RosettaMRParser.Rdc_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_rdc_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 458 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 457
                    self.rdc_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 460 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,41,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Rdc_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def gen_res_num(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Gen_res_numContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Gen_res_numContext,i)


        def gen_simple_name(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Gen_simple_nameContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Gen_simple_nameContext,i)


        def number(self):
            return self.getTypedRuleContext(RosettaMRParser.NumberContext,0)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_rdc_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRdc_restraint" ):
                listener.enterRdc_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRdc_restraint" ):
                listener.exitRdc_restraint(self)




    def rdc_restraint(self):

        localctx = RosettaMRParser.Rdc_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_rdc_restraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 462
            self.gen_res_num()
            self.state = 463
            self.gen_simple_name()
            self.state = 464
            self.gen_res_num()
            self.state = 465
            self.gen_simple_name()
            self.state = 466
            self.number()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Disulfide_bond_linkagesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def disulfide_bond_linkage(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Disulfide_bond_linkageContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Disulfide_bond_linkageContext,i)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_disulfide_bond_linkages

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDisulfide_bond_linkages" ):
                listener.enterDisulfide_bond_linkages(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDisulfide_bond_linkages" ):
                listener.exitDisulfide_bond_linkages(self)




    def disulfide_bond_linkages(self):

        localctx = RosettaMRParser.Disulfide_bond_linkagesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_disulfide_bond_linkages)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 469 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 468
                    self.disulfide_bond_linkage()

                else:
                    raise NoViableAltException(self)
                self.state = 471 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,42,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Disulfide_bond_linkageContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def gen_res_num(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Gen_res_numContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Gen_res_numContext,i)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_disulfide_bond_linkage

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDisulfide_bond_linkage" ):
                listener.enterDisulfide_bond_linkage(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDisulfide_bond_linkage" ):
                listener.exitDisulfide_bond_linkage(self)




    def disulfide_bond_linkage(self):

        localctx = RosettaMRParser.Disulfide_bond_linkageContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_disulfide_bond_linkage)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 473
            self.gen_res_num()
            self.state = 474
            self.gen_res_num()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Atom_pair_w_chain_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def atom_pair_w_chain_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Atom_pair_w_chain_restraintContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Atom_pair_w_chain_restraintContext,i)


        def getRuleIndex(self):
            return RosettaMRParser.RULE_atom_pair_w_chain_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAtom_pair_w_chain_restraints" ):
                listener.enterAtom_pair_w_chain_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAtom_pair_w_chain_restraints" ):
                listener.exitAtom_pair_w_chain_restraints(self)




    def atom_pair_w_chain_restraints(self):

        localctx = RosettaMRParser.Atom_pair_w_chain_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 60, self.RULE_atom_pair_w_chain_restraints)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 477 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 476
                    self.atom_pair_w_chain_restraint()

                else:
                    raise NoViableAltException(self)
                self.state = 479 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,43,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Atom_pair_w_chain_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def gen_simple_name(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RosettaMRParser.Gen_simple_nameContext)
            else:
                return self.getTypedRuleContext(RosettaMRParser.Gen_simple_nameContext,i)


        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(RosettaMRParser.Integer)
            else:
                return self.getToken(RosettaMRParser.Integer, i)

        def func_type_def(self):
            return self.getTypedRuleContext(RosettaMRParser.Func_type_defContext,0)


        def AtomPair(self):
            return self.getToken(RosettaMRParser.AtomPair, 0)

        def NamedAtomPair(self):
            return self.getToken(RosettaMRParser.NamedAtomPair, 0)

        def AmbiguousNMRDistance(self):
            return self.getToken(RosettaMRParser.AmbiguousNMRDistance, 0)

        def getRuleIndex(self):
            return RosettaMRParser.RULE_atom_pair_w_chain_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAtom_pair_w_chain_restraint" ):
                listener.enterAtom_pair_w_chain_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAtom_pair_w_chain_restraint" ):
                listener.exitAtom_pair_w_chain_restraint(self)




    def atom_pair_w_chain_restraint(self):

        localctx = RosettaMRParser.Atom_pair_w_chain_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 62, self.RULE_atom_pair_w_chain_restraint)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 481
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 518) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 482
            self.gen_simple_name()
            self.state = 483
            self.match(RosettaMRParser.Integer)
            self.state = 484
            self.gen_simple_name()
            self.state = 485
            self.gen_simple_name()
            self.state = 486
            self.match(RosettaMRParser.Integer)
            self.state = 487
            self.gen_simple_name()
            self.state = 488
            self.func_type_def()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NumberContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Float(self):
            return self.getToken(RosettaMRParser.Float, 0)

        def Integer(self):
            return self.getToken(RosettaMRParser.Integer, 0)

        def getRuleIndex(self):
            return RosettaMRParser.RULE_number

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumber" ):
                listener.enterNumber(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumber" ):
                listener.exitNumber(self)




    def number(self):

        localctx = RosettaMRParser.NumberContext(self, self._ctx, self.state)
        self.enterRule(localctx, 64, self.RULE_number)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 490
            _la = self._input.LA(1)
            if not(_la==50 or _la==51):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Number_fContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Float(self):
            return self.getToken(RosettaMRParser.Float, 0)

        def Integer(self):
            return self.getToken(RosettaMRParser.Integer, 0)

        def getRuleIndex(self):
            return RosettaMRParser.RULE_number_f

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumber_f" ):
                listener.enterNumber_f(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumber_f" ):
                listener.exitNumber_f(self)




    def number_f(self):

        localctx = RosettaMRParser.Number_fContext(self, self._ctx, self.state)
        self.enterRule(localctx, 66, self.RULE_number_f)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 492
            _la = self._input.LA(1)
            if not(_la==50 or _la==51):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Gen_res_numContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self):
            return self.getToken(RosettaMRParser.Integer, 0)

        def Integer_capital(self):
            return self.getToken(RosettaMRParser.Integer_capital, 0)

        def Capital_integer(self):
            return self.getToken(RosettaMRParser.Capital_integer, 0)

        def getRuleIndex(self):
            return RosettaMRParser.RULE_gen_res_num

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGen_res_num" ):
                listener.enterGen_res_num(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGen_res_num" ):
                listener.exitGen_res_num(self)




    def gen_res_num(self):

        localctx = RosettaMRParser.Gen_res_numContext(self, self._ctx, self.state)
        self.enterRule(localctx, 68, self.RULE_gen_res_num)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 494
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 109212290963734528) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Gen_simple_nameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Simple_name(self):
            return self.getToken(RosettaMRParser.Simple_name, 0)

        def Integer_capital(self):
            return self.getToken(RosettaMRParser.Integer_capital, 0)

        def Capital_integer(self):
            return self.getToken(RosettaMRParser.Capital_integer, 0)

        def getRuleIndex(self):
            return RosettaMRParser.RULE_gen_simple_name

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGen_simple_name" ):
                listener.enterGen_simple_name(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGen_simple_name" ):
                listener.exitGen_simple_name(self)




    def gen_simple_name(self):

        localctx = RosettaMRParser.Gen_simple_nameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 70, self.RULE_gen_simple_name)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 496
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 252201579132747776) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





