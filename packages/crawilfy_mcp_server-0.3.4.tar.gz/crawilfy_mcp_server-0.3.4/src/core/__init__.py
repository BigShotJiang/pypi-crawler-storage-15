"""Core engine components."""








