"""Session and credential management."""








