from setuptools import setup, find_packages

with open("Readme.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

with open("LICENSE", "r", encoding="utf-8") as fh:
    license_text = fh.read()

setup(
    name="watchman-agent-client",
    version="1.0.0",
    author="Watchman",
    author_email="support@watchman.bj",
    description='Agent pour collecter des informations système et les envoyer à une API centrale.',
    long_description=long_description,
    long_description_content_type='text/markdown',
    url="https://github.com/watchman/watchman-agent-client",
    project_urls={
        "Bug Tracker": "https://github.com/watchman/watchman-agent-client/issues",
        "Documentation": "https://github.com/watchman/watchman-agent-client#readme",
        "Source Code": "https://github.com/watchman/watchman-agent-client",
    },
    license="MIT",
    classifiers=[
        # Development Status
        "Development Status :: 4 - Beta",

        # Intended Audience
        "Intended Audience :: System Administrators",
        "Intended Audience :: Information Technology",

        # License
        "License :: OSI Approved :: MIT License",

        # Programming Language
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",

        # Operating Systems
        "Operating System :: OS Independent",
        "Operating System :: Microsoft :: Windows",
        "Operating System :: POSIX :: Linux",
        "Operating System :: MacOS",

        # Topics
        "Topic :: System :: Monitoring",
        "Topic :: System :: Systems Administration",
        "Topic :: System :: Hardware",
        "Topic :: System :: Networking :: Monitoring",
    ],
    keywords=[
        "inventory", "system-monitoring", "hardware-inventory",
        "software-inventory", "asset-management", "glpi-alternative",
        "system-information", "network-monitoring", "agent"
    ],
    include_package_data=True,
    packages=find_packages(exclude=["tests", "tests.*", "build", "dist", "env"]),
    python_requires='>=3.8',
    install_requires=[
        "psutil>=5.9.0",
        "requests>=2.28.0",
        "Flask>=2.3.0",
        "schedule>=1.2.0",
        "configparser>=5.3.0",
        "pywin32>=306; platform_system=='Windows'",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-cov>=4.0.0",
            "black>=23.0.0",
            "flake8>=6.0.0",
        ],
    },
    entry_points={
        'console_scripts': [
            'watchman-agent-client=agent.main:main',
        ],
    },
)
