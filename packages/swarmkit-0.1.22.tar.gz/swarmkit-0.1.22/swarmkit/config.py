"""Configuration types for SwarmKit SDK."""

from dataclasses import dataclass
from typing import Literal, Optional


AgentType = Literal['codex', 'claude', 'gemini', 'acp-gemini', 'acp-qwen', 'acp-claude', 'acp-codex']
ModelProvider = Literal['openai', 'anthropic', 'gemini', 'google', 'openrouter']
WorkspaceMode = Literal['knowledge', 'swe']
ReasoningEffort = Literal['low', 'medium', 'high']


@dataclass
class AgentConfig:
    """Agent configuration.

    Args:
        type: Agent type (codex, claude, gemini, acp-gemini, acp-qwen, acp-claude, acp-codex)
        provider: Model provider (optional - inferred when omitted)
        api_key: API key routed through the SwarmKit gateway (required; Claude can use oauth_token instead)
        oauth_token: OAuth token for Claude Code (optional - alternative to api_key for Claude only)
        model: Model name (optional - CLI uses its default if not specified)
        base_url: Custom API base URL (legacy; gateway mode ignores this)
        reasoning_effort: Reasoning effort for advanced models (optional - only Codex and acp-codex use it)
    """
    type: AgentType
    provider: Optional[ModelProvider] = None
    api_key: Optional[str] = None
    oauth_token: Optional[str] = None
    model: Optional[str] = None
    base_url: Optional[str] = None
    reasoning_effort: Optional[ReasoningEffort] = None


@dataclass
class E2BProvider:
    """E2B sandbox provider configuration.

    Args:
        api_key: E2B API key
        template_id: E2B template ID (optional - auto-selected based on agent type)
        timeout_ms: Sandbox timeout in milliseconds (default: 3600000 = 1 hour)
    """
    api_key: str
    template_id: Optional[str] = None
    timeout_ms: int = 3600000

    @property
    def type(self) -> Literal['e2b']:
        """Provider type."""
        return 'e2b'

    @property
    def config(self) -> dict:
        """Provider configuration dict."""
        result = {'apiKey': self.api_key}
        if self.template_id:
            result['templateId'] = self.template_id
        if self.timeout_ms:
            result['timeoutMs'] = self.timeout_ms
        return result


# Type alias for sandbox provider (extensible for future providers)
SandboxProvider = E2BProvider
