"""Main SwarmKit class for Python SDK."""

import asyncio
import base64
from typing import Any, AsyncGenerator, Callable, Dict, List, Optional, Union

from .bridge import BridgeManager, SandboxNotFoundError
from .config import AgentConfig, SandboxProvider, WorkspaceMode
from .events import Event, StdoutEvent, ContentEvent, StderrEvent, UpdateEvent, ErrorEvent, CompleteEvent
from .results import ExecuteResult, OutputFile


class SwarmKit:
    """SwarmKit agent orchestrator.

    Provides a Pythonic interface to the TypeScript SwarmKit SDK via JSON-RPC bridge.

    Example:
        >>> from swarmkit import SwarmKit, AgentConfig, E2BProvider
        >>>
        >>> swarmkit = SwarmKit(
        ...     config=AgentConfig(
        ...         type='codex',
        ...         api_key='sk-...',
        ...         model='gpt-5-codex'
        ...     ),
        ...     sandbox=E2BProvider(api_key='...')
        ... )
        >>>
        >>> async with swarmkit:
        ...     result = await swarmkit.run(prompt='Analyze data.csv')
        ...     files = await swarmkit.get_output_files()
    """

    def __init__(
        self,
        config: AgentConfig,
        sandbox: SandboxProvider,
        working_directory: str = '/home/user/workspace',
        workspace_mode: WorkspaceMode = 'knowledge',
        system_prompt: Optional[str] = None,
        context: Optional[Dict[str, Union[str, bytes]]] = None,
        files: Optional[Dict[str, Union[str, bytes]]] = None,
        mcp_servers: Optional[Dict[str, Any]] = None,
        secrets: Optional[Dict[str, str]] = None,
        sandbox_id: Optional[str] = None,
        session_tag_prefix: Optional[str] = None,
    ):
        """Initialize SwarmKit.

        Args:
            config: Agent configuration
            sandbox: Sandbox provider configuration
            working_directory: Working directory in sandbox (default: /home/user/workspace)
            workspace_mode: Workspace setup mode - 'knowledge' (creates output/context/scripts/temp folders + default prompt)
                          or 'swe' (clean workspace for cloned repos) (default: 'knowledge')
            system_prompt: Custom system prompt (appended to default in 'knowledge' mode, sole prompt in 'swe' mode)
            context: Files to upload to context/ folder on first run - { "filename.txt": "content" }
            files: Files to upload to working directory on first run - { "scripts/run.sh": "content" }
            mcp_servers: MCP server configurations
            secrets: Environment variables for sandbox
            sandbox_id: Existing sandbox ID to reconnect to
            session_tag_prefix: Optional semantic label for observability log files (e.g., 'experiment-7')
        """
        self.config = config
        self.sandbox = sandbox
        self.working_directory = working_directory
        self.workspace_mode = workspace_mode
        self.system_prompt = system_prompt
        self.context = context
        self.files = files
        self.mcp_servers = mcp_servers
        self.secrets = secrets
        self.sandbox_id = sandbox_id
        self.session_tag_prefix = session_tag_prefix

        self.bridge = BridgeManager()
        self._initialized = False
        self._internal_handlers_registered = False
        self._init_lock = asyncio.Lock()
        self._event_queue: asyncio.Queue[Event] = asyncio.Queue(maxsize=1000)

    async def _ensure_initialized(self):
        """Ensure bridge is started and agent is initialized."""
        async with self._init_lock:
            if self._initialized:
                return

            await self.bridge.start()

            # Prepare context dict for transport (with encoding metadata for binary)
            context_json = None
            if self.context:
                context_json = {}
                for name, content in self.context.items():
                    if isinstance(content, bytes):
                        context_json[name] = {
                            'data': base64.b64encode(content).decode('utf-8'),
                            'encoding': 'base64'
                        }
                    else:
                        context_json[name] = {'data': content, 'encoding': 'text'}

            # Prepare files dict for transport (with encoding metadata for binary)
            files_json = None
            if self.files:
                files_json = {}
                for path, content in self.files.items():
                    if isinstance(content, bytes):
                        files_json[path] = {
                            'data': base64.b64encode(content).decode('utf-8'),
                            'encoding': 'base64'
                        }
                    else:
                        files_json[path] = {'data': content, 'encoding': 'text'}

            # Detect if user registered stdout/stderr/content callbacks (enables fallback pattern)
            # IMPORTANT: Must check BEFORE registering internal handlers (line 128-131)
            # to distinguish user callbacks from internal queue handlers.
            # Subtract internal handlers if already registered (e.g., after kill() + re-run).
            internal_handler_count = 1 if self._internal_handlers_registered else 0
            has_user_stdout = len(self.bridge.event_callbacks.get('stdout', [])) > internal_handler_count
            has_user_stderr = len(self.bridge.event_callbacks.get('stderr', [])) > internal_handler_count
            has_user_content = len(self.bridge.event_callbacks.get('content', [])) > internal_handler_count

            # Initialize agent via bridge
            await self.bridge.call('initialize', {
                'agent_type': self.config.type,
                'provider': self.config.provider,
                'api_key': self.config.api_key,
                'oauth_token': self.config.oauth_token,
                'model': self.config.model,
                'base_url': self.config.base_url,
                'reasoning_effort': self.config.reasoning_effort,
                'sandbox_provider': {
                    'type': self.sandbox.type,
                    'config': self.sandbox.config,
                },
                'working_directory': self.working_directory,
                'workspace_mode': self.workspace_mode,
                'system_prompt': self.system_prompt,
                'context': context_json,
                'files': files_json,
                'mcp_servers': self.mcp_servers,
                'secrets': self.secrets,
                'sandbox_id': self.sandbox_id,
                'forward_stdout': has_user_stdout,
                'forward_stderr': has_user_stderr,
                'forward_content': has_user_content,
                'session_tag_prefix': self.session_tag_prefix,
            })

            # Forward bridge events to event queue for stream() method
            # Only register these internal handlers once to avoid duplicate emissions
            def _handle_complete(payload: Any):
                if not isinstance(payload, dict):
                    payload = {}

                exit_code = payload.get('exit_code')
                if exit_code is not None:
                    try:
                        exit_code = int(exit_code)
                    except (ValueError, TypeError):
                        exit_code = None

                status = payload.get('status', 'success')
                sandbox_id = payload.get('sandbox_id')
                error_message = payload.get('error')

                self._queue_event(
                    CompleteEvent(
                        status=status if status in ('success', 'error') else 'success',
                        exit_code=exit_code,
                        sandbox_id=sandbox_id,
                        error=error_message,
                    )
                )

            if not self._internal_handlers_registered:
                self.bridge.on('stdout', lambda data: self._queue_event(StdoutEvent(data=data)))
                self.bridge.on('content', lambda params: self._queue_event(
                    ContentEvent(update=params.get('update', {}), session_id=params.get('session_id'))
                ))
                self.bridge.on('stderr', lambda data: self._queue_event(StderrEvent(data=data)))
                self.bridge.on('update', lambda data: self._queue_event(UpdateEvent(data=data)))
                self.bridge.on('error', lambda error: self._queue_event(ErrorEvent(error=error)))
                self.bridge.on('complete', _handle_complete)
                self._internal_handlers_registered = True

            self._initialized = True

    def _queue_event(self, event: Event):
        """Queue event for async generator."""
        try:
            self._event_queue.put_nowait(event)
        except asyncio.QueueFull:
            # Log warning so users know events are being dropped
            import logging
            logging.warning(
                f"Event queue full (1000 items), dropping {event.__class__.__name__}. "
                "Consumer may not be reading from stream() fast enough."
            )

    def on(self, event_type: str, callback: Callable[[Any], None]):
        """Register event callback.

        Args:
            event_type: Event type ('stdout' | 'content' | 'stderr' | 'update' | 'error' | 'complete')
            callback: Callback function invoked with the event payload
                      (str for stdout/stderr/update/error, dict for content/complete)

        Example:
            >>> swarmkit.on('stdout', lambda data: print(data, end=''))
            >>> swarmkit.on('content', lambda event: print(event['update']['sessionUpdate']))
            >>> swarmkit.on('stderr', lambda data: print(f'[ERR] {data}', end=''))
        """
        self.bridge.on(event_type, callback)

    async def stream(self) -> AsyncGenerator[Event, None]:
        """Stream events as async generator.

        Yields:
            Event objects (StdoutEvent, ContentEvent, StderrEvent, UpdateEvent, ErrorEvent, CompleteEvent)

        Example:
            >>> async for event in swarmkit.stream():
            ...     match event.type:
            ...         case 'stdout':
            ...             print(event.data, end='')
            ...         case 'content':
            ...             print(event.update.get('sessionUpdate'))
            ...         case 'error':
            ...             print(f'Error: {event.error}')
            ...         case 'complete':
            ...             print(f'Finished with exit code {event.exit_code}')
        """
        while True:
            event = await self._event_queue.get()
            yield event

    async def run(
        self,
        prompt: str,
        history: Optional[List[Dict[str, str]]] = None,
        timeout_ms: Optional[int] = None,
    ) -> ExecuteResult:
        """Run AI-assisted task (agent decides and acts).

        Args:
            prompt: Task description
            history: Optional conversation history
            timeout_ms: Optional timeout in milliseconds (default: 1 hour)

        Returns:
            ExecuteResult with sandbox_id, exit_code, stdout, stderr

        Example:
            >>> result = await swarmkit.run(prompt='Analyze data and create report', timeout_ms=600000)
        """
        await self._ensure_initialized()

        params = {
            'prompt': prompt,
            'history': history,
        }
        if timeout_ms is not None:
            params['timeout_ms'] = timeout_ms

        response = await self.bridge.call('run', params)

        return ExecuteResult(
            sandbox_id=response['sandbox_id'],
            exit_code=response['exit_code'],
            stdout=response['stdout'],
            stderr=response['stderr'],
        )

    async def execute_command(
        self,
        command: str,
        timeout_ms: Optional[int] = None,
        background: bool = False,
    ) -> ExecuteResult:
        """Execute direct shell command.

        Args:
            command: Shell command to execute
            timeout_ms: Optional timeout in milliseconds (default: 1 hour)
            background: Run in background (default: False)

        Returns:
            ExecuteResult with sandbox_id, exit_code, stdout, stderr

        Example:
            >>> result = await swarmkit.execute_command(command='python script.py')
        """
        await self._ensure_initialized()

        response = await self.bridge.call('execute_command', {
            'command': command,
            'timeout_ms': timeout_ms,
            'background': background,
        })

        return ExecuteResult(
            sandbox_id=response['sandbox_id'],
            exit_code=response['exit_code'],
            stdout=response['stdout'],
            stderr=response['stderr'],
        )

    async def upload_context(
        self,
        files: Dict[str, Union[str, bytes]],
    ):
        """Upload files to context/ folder (runtime - immediate upload).

        Args:
            files: Dict mapping filename to content - { "filename.txt": "content", "data.json": jsonStr }

        Example:
            >>> await swarmkit.upload_context({
            ...     'spec.json': json.dumps(spec),
            ...     'readme.txt': 'Project documentation...',
            ... })
        """
        await self._ensure_initialized()

        # Convert to transport format with encoding metadata for binary
        files_json = {}
        for name, content in files.items():
            if isinstance(content, bytes):
                files_json[name] = {
                    'data': base64.b64encode(content).decode('utf-8'),
                    'encoding': 'base64'
                }
            else:
                files_json[name] = {'data': content, 'encoding': 'text'}

        await self.bridge.call('upload_context', {
            'files': files_json,
        })

    async def upload_files(
        self,
        files: Dict[str, Union[str, bytes]],
    ):
        """Upload files to working directory (runtime - immediate upload).

        Args:
            files: Dict mapping path to content - { "scripts/run.sh": "#!/bin/bash...", "data/input.csv": csvData }

        Example:
            >>> await swarmkit.upload_files({
            ...     'scripts/setup.sh': '#!/bin/bash\\necho hello',
            ...     'temp/cache.json': json.dumps(cache),
            ... })
        """
        await self._ensure_initialized()

        # Convert to transport format with encoding metadata for binary
        files_json = {}
        for path, content in files.items():
            if isinstance(content, bytes):
                files_json[path] = {
                    'data': base64.b64encode(content).decode('utf-8'),
                    'encoding': 'base64'
                }
            else:
                files_json[path] = {'data': content, 'encoding': 'text'}

        await self.bridge.call('upload_files', {
            'files': files_json,
        })

    async def get_output_files(self) -> List[OutputFile]:
        """Get files from output/ directory.

        Automatically filtered to files created/modified after the most recent
        execute_command() or run() call.

        Returns:
            List of OutputFile objects

        Example:
            >>> files = await swarmkit.get_output_files()
            >>> for file in files:
            ...     with open(f'./downloads/{file.name}', 'wb') as f:
            ...         content = file.content if isinstance(file.content, bytes) else file.content.encode()
            ...         f.write(content)
        """
        await self._ensure_initialized()

        response = await self.bridge.call('get_output_files')

        files = []
        for file_data in response:
            content = file_data['content']
            encoding = file_data.get('encoding')
            if encoding == 'base64':
                content = base64.b64decode(content)

            files.append(OutputFile(
                name=file_data['name'],
                path=file_data['path'],
                content=content,
                size=file_data['size'],
                modified_time=file_data['modified_time'],
            ))

        return files

    async def get_session(self) -> Optional[str]:
        """Get sandbox ID for reuse.

        Returns:
            Sandbox ID or None if not initialized

        Example:
            >>> sandbox_id = await swarmkit.get_session()
            >>> print(f'Sandbox ID: {sandbox_id}')
        """
        await self._ensure_initialized()
        return await self.bridge.call('get_session')

    async def set_session(self, session_id: str):
        """Change sandbox session.

        Args:
            session_id: New sandbox ID to connect to

        Example:
            >>> await swarmkit.set_session('existing-sandbox-id')
        """
        await self._ensure_initialized()
        await self.bridge.call('set_session', {
            'session_id': session_id,
        })

    async def pause(self):
        """Pause sandbox to save costs while preserving state.

        Example:
            >>> await swarmkit.pause()
        """
        await self._ensure_initialized()
        await self.bridge.call('pause')

    async def resume(self):
        """Resume paused sandbox.

        Example:
            >>> await swarmkit.resume()
        """
        await self._ensure_initialized()
        await self.bridge.call('resume')

    async def kill(self):
        """Terminate sandbox and release all resources.

        Example:
            >>> await swarmkit.kill()
        """
        await self._ensure_initialized()
        try:
            await self.bridge.call('kill')
        finally:
            # Always stop bridge even if RPC fails (e.g., sandbox already gone)
            await self.bridge.stop()
            self._initialized = False

    async def get_host(self, port: int) -> str:
        """Get public URL for sandbox port.

        Args:
            port: Port number to expose

        Returns:
            Public URL for the port

        Example:
            >>> url = await swarmkit.get_host(8000)
            >>> print(f'Server available at: {url}')
        """
        await self._ensure_initialized()
        response = await self.bridge.call('get_host', {
            'port': port,
        })
        return response['url']

    async def get_session_tag(self) -> Optional[str]:
        """Get the observability session tag.

        Returns the generated tag (e.g., 'my-prefix-a3f8b2c1') used for the
        log file in ~/.swarmkit/observability/sessions/

        Returns:
            Session tag or None if not initialized

        Example:
            >>> tag = await swarmkit.get_session_tag()
            >>> print(f'Log file tag: {tag}')
            'experiment-7-a3f8b2c1'
        """
        await self._ensure_initialized()
        return await self.bridge.call('get_session_tag')

    async def get_session_timestamp(self) -> Optional[str]:
        """Get the session start timestamp (ISO format).

        Returns:
            ISO timestamp when session was created or None if not initialized

        Example:
            >>> timestamp = await swarmkit.get_session_timestamp()
            >>> print(f'Session started: {timestamp}')
            '2025-01-15T10:30:45.123Z'
        """
        await self._ensure_initialized()
        return await self.bridge.call('get_session_timestamp')

    async def __aenter__(self):
        """Context manager entry."""
        try:
            await self._ensure_initialized()
            return self
        except Exception:
            # Cleanup bridge process if initialization fails
            await self.bridge.stop()
            raise

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - cleanup resources."""
        try:
            await self.kill()
        except Exception as e:
            import warnings
            warnings.warn(f"Error during cleanup: {e}", RuntimeWarning)
