"""
Flask application factory for TinyIDP.
"""

import logging
import os
from flask import Flask
from flask_cors import CORS

from .config import init_config, get_config
from .services import init_crypto_service
from .routes import oauth_bp, saml_bp, ui_bp, api_bp


def create_app(config_dir: str = None) -> Flask:
    """Create and configure the Flask application."""
    # Initialize configuration
    config = init_config(config_dir)
    settings = config.settings

    # Configure logging
    logging.basicConfig(
        level=getattr(logging, settings.log_level),
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )
    logger = logging.getLogger(__name__)

    # Initialize crypto service
    init_crypto_service(settings.keys_dir)

    # Create Flask app
    app = Flask(
        __name__,
        template_folder=os.path.join(os.path.dirname(__file__), "templates"),
        static_folder=os.path.join(os.path.dirname(__file__), "static"),
    )
    app.secret_key = settings.secret_key

    # Enable CORS for all routes (development mode)
    CORS(app, resources={r"/*": {"origins": "*"}})

    # Register blueprints
    app.register_blueprint(oauth_bp)
    app.register_blueprint(saml_bp)
    app.register_blueprint(ui_bp)
    app.register_blueprint(api_bp)

    # Health check at root for backward compatibility
    @app.route("/health")
    def health():
        from flask import jsonify
        return jsonify({"status": "ok"})

    logger.info(f"TinyIDP initialized")
    logger.info(f"  - Issuer: {settings.issuer}")
    logger.info(f"  - Users: {len(config.users)}")
    logger.info(f"  - OAuth Clients: {len(settings.clients)}")

    return app


def run_app(host: str = None, port: int = None, debug: bool = None, config_dir: str = None):
    """Run the Flask application."""
    app = create_app(config_dir)
    config = get_config()
    settings = config.settings

    app.run(
        host=host or settings.host,
        port=port or settings.port,
        debug=debug if debug is not None else settings.debug,
    )
