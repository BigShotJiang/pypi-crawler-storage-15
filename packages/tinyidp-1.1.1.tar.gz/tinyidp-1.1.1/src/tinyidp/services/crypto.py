"""
Cryptographic services for JWT and SAML signing.
"""

import os
import uuid
import base64
import logging
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional, Dict, Any, Tuple

from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.serialization import (
    Encoding,
    PrivateFormat,
    NoEncryption,
    PublicFormat,
)
from cryptography.hazmat.backends import default_backend
from cryptography import x509
from cryptography.x509.oid import NameOID

import jwt

logger = logging.getLogger(__name__)


class CryptoService:
    """Handles cryptographic operations for JWT and SAML."""

    def __init__(self, keys_dir: str = "./keys"):
        self.keys_dir = Path(keys_dir)
        self.priv_pem: bytes = b""
        self.pub_pem: bytes = b""
        self.kid: str = ""
        self.cert_pem: bytes = b""
        self._ensure_keys()

    def _ensure_keys(self):
        """Ensure RSA keys and certificate exist."""
        self.keys_dir.mkdir(parents=True, exist_ok=True)

        priv_path = self.keys_dir / "rsa_private.pem"
        pub_path = self.keys_dir / "rsa_public.pem"
        kid_path = self.keys_dir / "kid.txt"
        cert_path = self.keys_dir / "idp-cert.pem"

        new_generated = False

        if not (priv_path.exists() and pub_path.exists() and kid_path.exists()):
            logger.info("Generating new RSA key pair...")
            private_key = rsa.generate_private_key(
                public_exponent=65537,
                key_size=2048,
            )
            kid = uuid.uuid4().hex

            with open(priv_path, "wb") as f:
                f.write(
                    private_key.private_bytes(
                        encoding=Encoding.PEM,
                        format=PrivateFormat.PKCS8,
                        encryption_algorithm=NoEncryption(),
                    )
                )

            public_key = private_key.public_key()
            with open(pub_path, "wb") as f:
                f.write(
                    public_key.public_bytes(
                        encoding=Encoding.PEM,
                        format=PublicFormat.SubjectPublicKeyInfo,
                    )
                )

            with open(kid_path, "w") as f:
                f.write(kid)

            new_generated = True
            logger.info(f"Generated new key pair with KID: {kid}")

        # Load keys
        with open(priv_path, "rb") as f:
            self.priv_pem = f.read()
        with open(pub_path, "rb") as f:
            self.pub_pem = f.read()
        with open(kid_path, "r") as f:
            self.kid = f.read().strip()

        # Generate X.509 certificate if missing
        if not cert_path.exists() or new_generated:
            self._generate_certificate(cert_path)

        with open(cert_path, "rb") as f:
            self.cert_pem = f.read()

    def _generate_certificate(self, cert_path: Path):
        """Generate a self-signed X.509 certificate."""
        logger.info("Generating self-signed certificate...")

        private_key = serialization.load_pem_private_key(self.priv_pem, password=None)
        public_key = serialization.load_pem_public_key(self.pub_pem)

        subject = issuer = x509.Name(
            [
                x509.NameAttribute(NameOID.COUNTRY_NAME, "DE"),
                x509.NameAttribute(NameOID.ORGANIZATION_NAME, "TinyIDP"),
                x509.NameAttribute(NameOID.COMMON_NAME, "TinyIDP Self-Signed"),
            ]
        )

        cert = (
            x509.CertificateBuilder()
            .subject_name(subject)
            .issuer_name(issuer)
            .public_key(public_key)
            .serial_number(x509.random_serial_number())
            .not_valid_before(datetime.utcnow() - timedelta(days=1))
            .not_valid_after(datetime.utcnow() + timedelta(days=3650))
            .add_extension(
                x509.BasicConstraints(ca=True, path_length=None),
                critical=True,
            )
            .sign(private_key, hashes.SHA256())
        )

        with open(cert_path, "wb") as f:
            f.write(cert.public_bytes(Encoding.PEM))

        logger.info("Certificate generated successfully")

    def get_jwk(self) -> Dict[str, Any]:
        """Get the public key as a JWK."""
        public_key = serialization.load_pem_public_key(
            self.pub_pem, backend=default_backend()
        )

        if not isinstance(public_key, rsa.RSAPublicKey):
            raise ValueError("Public key is not RSA")

        numbers = public_key.public_numbers()

        def b64url_uint(i: int) -> str:
            b = i.to_bytes((i.bit_length() + 7) // 8, "big")
            return base64.urlsafe_b64encode(b).rstrip(b"=").decode("ascii")

        return {
            "kty": "RSA",
            "use": "sig",
            "kid": self.kid,
            "alg": "RS256",
            "n": b64url_uint(numbers.n),
            "e": b64url_uint(numbers.e),
        }

    def create_jwt(
        self,
        sub: str,
        issuer: str,
        audience: str,
        roles: list = None,
        tenant: str = None,
        extra: dict = None,
        exp_minutes: int = 60,
    ) -> str:
        """Create a signed JWT token."""
        now = datetime.now(timezone.utc)
        payload = {
            "jti": str(uuid.uuid4()),  # JWT ID for revocation support
            "iss": issuer,
            "sub": sub,
            "aud": audience,
            "iat": int(now.timestamp()),
            "nbf": int(now.timestamp()),
            "exp": int((now + timedelta(minutes=exp_minutes)).timestamp()),
        }

        if roles:
            payload["roles"] = roles
        if tenant:
            payload["tenant"] = tenant
        if extra and isinstance(extra, dict):
            payload.update(extra)

        headers = {"kid": self.kid, "alg": "RS256", "typ": "JWT"}
        token = jwt.encode(payload, self.priv_pem, algorithm="RS256", headers=headers)
        return token

    def verify_jwt(self, token: str, audience: str) -> Dict[str, Any]:
        """Verify and decode a JWT token."""
        try:
            # Use public key for verification
            payload = jwt.decode(
                token,
                self.pub_pem,
                algorithms=["RS256"],
                audience=audience,
                options={"verify_signature": True},
            )
            return payload
        except jwt.ExpiredSignatureError:
            raise ValueError("Token has expired")
        except jwt.InvalidTokenError as e:
            raise ValueError(f"Invalid token: {str(e)}")

    def get_certificate_base64(self) -> str:
        """Get the certificate in base64 format (without headers)."""
        lines = self.cert_pem.decode().splitlines()
        b64_lines = [line for line in lines if "-----" not in line]
        return "".join(b64_lines)

    def regenerate_keys(self):
        """Regenerate RSA keys and certificate."""
        import uuid

        priv_path = self.keys_dir / "rsa_private.pem"
        pub_path = self.keys_dir / "rsa_public.pem"
        kid_path = self.keys_dir / "kid.txt"
        cert_path = self.keys_dir / "idp-cert.pem"

        logger.info("Regenerating RSA key pair...")

        # Generate new keys
        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048,
        )
        kid = uuid.uuid4().hex

        # Write private key
        with open(priv_path, "wb") as f:
            f.write(
                private_key.private_bytes(
                    encoding=Encoding.PEM,
                    format=PrivateFormat.PKCS8,
                    encryption_algorithm=NoEncryption(),
                )
            )

        # Write public key
        public_key = private_key.public_key()
        with open(pub_path, "wb") as f:
            f.write(
                public_key.public_bytes(
                    encoding=Encoding.PEM,
                    format=PublicFormat.SubjectPublicKeyInfo,
                )
            )

        # Write KID
        with open(kid_path, "w") as f:
            f.write(kid)

        # Reload keys into memory
        with open(priv_path, "rb") as f:
            self.priv_pem = f.read()
        with open(pub_path, "rb") as f:
            self.pub_pem = f.read()
        self.kid = kid

        # Generate new certificate
        self._generate_certificate(cert_path)
        with open(cert_path, "rb") as f:
            self.cert_pem = f.read()

        logger.info(f"Regenerated key pair with new KID: {kid}")


# Global crypto service instance
_crypto_service: Optional[CryptoService] = None


def get_crypto_service(keys_dir: str = "./keys") -> CryptoService:
    """Get or create the global crypto service."""
    global _crypto_service
    if _crypto_service is None:
        _crypto_service = CryptoService(keys_dir)
    return _crypto_service


def init_crypto_service(keys_dir: str) -> CryptoService:
    """Initialize the global crypto service."""
    global _crypto_service
    _crypto_service = CryptoService(keys_dir)
    return _crypto_service
