def main() -> None:
    print("Hello from unique-mcp!")
