from . import module_l47 as l47m


class ModuleL47VE(l47m.ModuleL47):
    """
    This is a conceptual class of L47 test module on a VulcanVE tester.

    """
    ...
