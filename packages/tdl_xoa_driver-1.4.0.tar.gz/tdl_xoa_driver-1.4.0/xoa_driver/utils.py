#: Helper functions

from xoa_driver.internals.core.funcs import (
    apply,
    apply_iter,
)


__all__ = (
    "apply",
    "apply_iter",
)
