"""Integration tests for Trustable AI Workbench CLI."""
