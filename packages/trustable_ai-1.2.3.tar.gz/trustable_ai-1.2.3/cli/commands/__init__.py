"""CLI commands for Trustable AI Workbench."""
