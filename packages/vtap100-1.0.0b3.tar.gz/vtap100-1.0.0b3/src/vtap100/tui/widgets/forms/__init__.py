"""Form widgets for VTAP100 configuration sections."""
