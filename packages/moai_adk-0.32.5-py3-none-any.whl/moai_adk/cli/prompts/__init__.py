"""Interactive prompt module"""

from moai_adk.cli.prompts.init_prompts import prompt_project_setup

__all__ = ["prompt_project_setup"]
