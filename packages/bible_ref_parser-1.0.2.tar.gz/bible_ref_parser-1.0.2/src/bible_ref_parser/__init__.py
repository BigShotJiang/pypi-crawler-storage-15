"""
Public API for bible_ref_parser

This module exposes the simplest interface for developers:

    from bible_ref_parser import parse, expand, split, abbreviation_to_full

- parse() → returns (raw, split, expanded)
- expand() → expand a single reference (e.g., "jn3:16" → "John 3:16")
- split() → return component parts of a reference
- abbreviation_to_full → dict mapping abbreviations to full names
"""

# from .reference_parser import Extract_References
# from .bible_abbreviations import BibleAbbreviations
# from .reference_splitter import Reference_Splitter

# ---------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------
# _rs = Reference_Splitter()
# _abbrev = BibleAbbreviations()
# _er = Extract_References()

# ---------------------------------------------------------------------
# Public helper functions
# ---------------------------------------------------------------------
# def parse(ref: str):
#     """Expand a single reference to its full book name."""
#     return _er.parse(ref)

# def expand(ref: str):
#     """Expand a single reference to its full book name."""
#     return _rs.expand(ref)

# def split(ref: str):
#     """Split a reference into components (book, chapter, verse)."""
#     return _rs.split_reference(ref)

# def book_map():
#     """Expose the full abbreviation → book mapping."""
#     return _abbrev.abbreviation_to_full

# def abbreviation_to_full(abbrev: str):
#     return _abbrev.lookup(abbrev)


# __all__ = [
#     "parse",
#     "expand",
#     "split",
#     "book_map",
# ]




from .reference_parser import Extract_References
from .bible_abbreviations import BibleAbbreviations
from .reference_splitter import Reference_Splitter

er = Extract_References()
ab = BibleAbbreviations()
rs = Reference_Splitter()

def parse(ref):
    return er.parse(ref)

def expand(ref):
    return rs.expand(ref)

def split(ref):
    return rs.split_reference(ref)

def book_map():
    return ab.book_map

def lookup(abbrev):
    return ab.lookup(abbrev)

__all__ = [
    "parse",
    "expand",
    "split",
    "book_map",
    "lookup",
]