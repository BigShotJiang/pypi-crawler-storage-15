# verge_auth_sdk/__init__.py
"""
verge_auth_sdk package public API.
Exports:
 - add_central_auth(app)  -> middleware to attach to FastAPI app
 - get_secret(name)       -> secret retrieval helper
"""
from .middleware import add_central_auth
from .secret_loader import get_secret

__all__ = ["add_central_auth", "get_secret"]
