"""
AI Music Remixer - Intelligent music remixing with optional neural transitions
"""

__version__ = "3.0.0"

