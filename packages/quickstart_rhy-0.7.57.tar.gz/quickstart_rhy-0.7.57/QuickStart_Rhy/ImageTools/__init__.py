# coding=utf-8
"""
qs的图像处理库

Image processing library of QS
"""