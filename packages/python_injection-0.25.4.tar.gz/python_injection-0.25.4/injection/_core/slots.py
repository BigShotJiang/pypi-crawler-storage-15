class SlotKey[T]:
    __slots__ = ()
