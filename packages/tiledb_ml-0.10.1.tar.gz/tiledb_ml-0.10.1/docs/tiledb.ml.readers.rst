Readers
==================
   
Pytorch
-------------------------

.. automodule:: tiledb.ml.readers.pytorch
   :inherited-members:
   :undoc-members:
   :show-inheritance:
   :exclude-members: DeferredIterableIterDataPipe

Tensorflow
----------------------------

.. automodule:: tiledb.ml.readers.tensorflow
   :inherited-members:
   :undoc-members:
   :show-inheritance:

Types
-----------------------

.. automodule:: tiledb.ml.readers.types
   :inherited-members:
   :undoc-members:
