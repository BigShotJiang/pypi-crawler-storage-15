# References

- [EMQX REST API](https://docs.emqx.com/en/enterprise/v6.0/admin/api-docs.html#tag/Clients)
