import logging
from dataclasses import dataclass
from functools import lru_cache
from typing import TYPE_CHECKING, cast

import numpy as np
from rasterio.crs import CRS
from shapely.ops import unary_union

from glidergun._grid import Grid, con, grid
from glidergun._types import FeatureCollection
from glidergun._utils import get_geojson

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from glidergun._stack import Stack


@dataclass(frozen=True, repr=False, slots=True)
class SamResult:
    masks: list["SamMask"]
    overview: "Stack"

    def to_geojson(self, crs: int | CRS | None = 4326, smooth_factor: float = 0.0) -> FeatureCollection:
        """Convert SAM masks to a GeoJSON FeatureCollection.

        Args:
            crs: Target CRS for output polygons (default EPSG:4326).
            smooth_factor: Buffer-based smoothing factor applied to polygons.

        Returns:
            FeatureCollection: GeoJSON features with label and score properties.
        """
        return get_geojson(
            (m.to_polygon(crs, smooth_factor=smooth_factor), {"label": m.prompt, "score": m.score}) for m in self.masks
        )


@dataclass(frozen=True, slots=True)
class SamMask:
    prompt: str
    score: float
    mask: Grid

    def to_polygon(self, crs: int | CRS | None = None, smooth_factor: float = 0.0):
        """Extract the largest polygon from the binary mask (value==1).

        Args:
            crs: CRS to project polygons to; if None, stays in original CRS.
            smooth_factor: Fraction of cell size used to smooth geometry.

        Returns:
            shapely.geometry.Polygon: Largest polygon representing the mask.
        """
        m = self.mask.set_nan(0)
        if crs:
            m = m.project(crs)
        polygons = [polygon for polygon, value in m.to_polygons(smooth_factor=smooth_factor) if value == 1]
        return max(polygons, key=lambda p: p.area)


@dataclass(frozen=True)
class Sam:
    def sam3(self, *prompt: str, model=None, confidence_threshold: float = 0.5):
        """Run Segment Anything Model 3 (SAM 3) over the stack with text prompts.

        Args:
            prompt: One or more text prompts used for segmentation.
            model: Optional pre-built SAM 3 model; built and cached if None.
            confidence_threshold: Minimum confidence to accept a predicted mask.

        Returns:
            SamResult: Collection of masks and an overview visualization stack.
        """
        self = cast("Stack", self)

        import torch
        from sam3.model.sam3_image_processor import Sam3Processor

        if model is None:
            model = _build_sam3_model()

        processor = Sam3Processor(model, device=model.device, confidence_threshold=confidence_threshold)  # type: ignore
        rgb = np.stack([g.stretch(0, 255).type("uint8", 0).data for g in self.grids[:3]], axis=-1)
        tensor = torch.from_numpy(np.transpose(rgb, (2, 0, 1))).to(model.device)
        state = processor.set_image(tensor)

        masks = []
        big_mask = self.grids[0] * 0

        for p in prompt:
            output = processor.set_text_prompt(p, state)
            for m, s in zip(output["masks"].cpu().numpy(), output["scores"].cpu().numpy(), strict=True):
                g = grid(m[0], extent=self.extent, crs=self.crs)
                masks.append(SamMask(prompt=p, score=float(s), mask=g.clip(*g.set_nan(0).data_extent) == 1))
                big_mask += g

        overview = self.each(lambda g: con(big_mask > 0, g, g / 4)).type("uint8", 0)
        return SamResult(masks=masks, overview=overview)

    def sam3_geojson(
        self,
        *prompt: str,
        model=None,
        confidence_threshold: float = 0.5,
        tile_size: int = 400,
        smooth_factor: float = 0.0,
    ):
        """Run Segment Anything Model 3 (SAM 3) over tiles and merge mask polygons into GeoJSON.

        Tiles the input extent to handle large images, runs `sam3` on each
        tile, collects masks per prompt, merges polygons via unary union, and
        returns a FeatureCollection.

        Args:
            prompt: One or more text prompts used for segmentation.
            model: Optional pre-built SAM 3 model.
            confidence_threshold: Minimum confidence for accepting masks.
            tile_size: Tile size in cells for processing.
            smooth_factor: Smoothing factor applied when polygonizing masks.

        Returns:
            FeatureCollection: GeoJSON representing the merged prompt regions.
        """
        self = cast("Stack", self)
        g = self.grids[0]
        w, h = g.cell_size.x * tile_size, g.cell_size.y * tile_size
        d: dict[str, list[SamMask]] = {p: [] for p in prompt}
        tiles = list(self.extent.tiles(w, h))

        for i, tile in enumerate(tiles):
            logger.info(f"Processing tile {i + 1} of {len(tiles)}...")
            s = self.clip(*tile.buffer(w / 2, h / 2, w / 2, h / 2))
            r = s.sam3(*prompt, model=model, confidence_threshold=confidence_threshold)
            for m in r.masks:
                d[m.prompt].append(m)

        return get_geojson(
            (polygon, {"label": p})
            for p, masks in d.items()
            for polygon in unary_union([m.to_polygon(4326, smooth_factor) for m in masks]).geoms  # type: ignore
        )


@lru_cache(maxsize=1)
def _build_sam3_model():
    import os
    import site
    import urllib.request

    from huggingface_hub import HfFolder, login
    from sam3.model_builder import build_sam3_image_model

    dir = f"{site.getsitepackages()[0]}/assets"
    file = "bpe_simple_vocab_16e6.txt.gz"

    if not os.path.exists(f"{dir}/{file}"):
        os.makedirs(dir, exist_ok=True)
        url = f"https://raw.githubusercontent.com/facebookresearch/sam3/refs/heads/main/assets/{file}"
        urllib.request.urlretrieve(url, f"{dir}/{file}")

    if not HfFolder.get_token():
        login()

    return build_sam3_image_model()
