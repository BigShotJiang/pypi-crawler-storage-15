
This library provides a set of tools to identify features in astronomical spectra

Installation
============

The library can be installed directly from its PyPi_ project page running the command:

``pip install aspect-stable``

Development
===========

ASPECT is currently on an alpha release. Any comment/issue/request can be added as an issue on the github page.
Please commit to dev branch.

.. _PyPi: https://pypi.org/project/aspect-stable/