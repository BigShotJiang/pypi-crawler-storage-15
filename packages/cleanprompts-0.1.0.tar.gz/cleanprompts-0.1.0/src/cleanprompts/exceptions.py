from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from cleanprompts.types import Issue


class CleanPromptsError(Exception):
    """Base exception for CleanPrompts SDK."""

    pass


class ThreatDetectedError(CleanPromptsError):
    """Raised when on_threat='block' and threats are detected."""

    def __init__(self, issues: list["Issue"], severity: int) -> None:
        self.issues = issues
        self.severity = severity
        super().__init__(f"Threat detected with severity {severity}")


class APIError(CleanPromptsError):
    """Raised for API errors."""

    def __init__(self, message: str, status_code: int | None = None) -> None:
        self.message = message
        self.status_code = status_code
        super().__init__(message)


class RateLimitError(APIError):
    """Raised when rate limit is exceeded."""

    def __init__(self, retry_after: int | None = None) -> None:
        self.retry_after = retry_after
        super().__init__(
            f"Rate limit exceeded. Retry after {retry_after}s" if retry_after else "Rate limit exceeded",
            status_code=429,
        )


class AuthenticationError(APIError):
    """Raised for authentication failures."""

    def __init__(self) -> None:
        super().__init__("Invalid API key", status_code=401)
