"""CleanPrompts Python SDK - Protect AI apps from prompt injection."""

from cleanprompts.client import CleanPrompts
from cleanprompts.exceptions import (
    APIError,
    AuthenticationError,
    CleanPromptsError,
    RateLimitError,
    ThreatDetectedError,
)
from cleanprompts.types import Issue, SanitizeResult

__version__ = "0.1.0"

__all__ = [
    "CleanPrompts",
    "SanitizeResult",
    "Issue",
    "CleanPromptsError",
    "ThreatDetectedError",
    "APIError",
    "RateLimitError",
    "AuthenticationError",
]
