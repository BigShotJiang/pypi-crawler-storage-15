from __future__ import annotations

import logging
import os
from typing import TYPE_CHECKING

import httpx

from cleanprompts.exceptions import (
    APIError,
    AuthenticationError,
    RateLimitError,
    ThreatDetectedError,
)
from cleanprompts.types import Issue, OnThreat, SanitizeResult, Sensitivity

if TYPE_CHECKING:
    pass

logger = logging.getLogger("cleanprompts")

DEFAULT_BASE_URL = "https://api.cleanprompts.dev"


class CleanPrompts:
    """CleanPrompts SDK client for prompt sanitization."""

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str | None = None,
        default_sensitivity: Sensitivity = "balanced",
        default_on_threat: OnThreat = "clean",
        timeout: float = 30.0,
    ) -> None:
        self.api_key = api_key or os.environ.get("CLEANPROMPTS_API_KEY")
        if not self.api_key:
            raise ValueError(
                "API key required. Pass api_key or set CLEANPROMPTS_API_KEY environment variable."
            )

        self.base_url = (
            base_url
            or os.environ.get("CLEANPROMPTS_BASE_URL")
            or DEFAULT_BASE_URL
        )
        self.default_sensitivity = default_sensitivity
        self.default_on_threat = default_on_threat
        self.timeout = timeout

        self._sync_client: httpx.Client | None = None
        self._async_client: httpx.AsyncClient | None = None

    @property
    def _client(self) -> httpx.Client:
        if self._sync_client is None:
            self._sync_client = httpx.Client(
                base_url=self.base_url,
                headers={"X-API-Key": self.api_key},
                timeout=self.timeout,
            )
        return self._sync_client

    @property
    def _aclient(self) -> httpx.AsyncClient:
        if self._async_client is None:
            self._async_client = httpx.AsyncClient(
                base_url=self.base_url,
                headers={"X-API-Key": self.api_key},
                timeout=self.timeout,
            )
        return self._async_client

    def sanitize(
        self,
        text: str,
        *,
        sensitivity: Sensitivity | None = None,
        on_threat: OnThreat | None = None,
    ) -> SanitizeResult:
        """
        Sanitize a prompt for security threats.

        Args:
            text: The prompt text to sanitize
            sensitivity: Detection sensitivity (strict/balanced/permissive)
            on_threat: Behavior when threat detected (clean/block/log_only)

        Returns:
            SanitizeResult with cleaned text and detected issues

        Raises:
            ThreatDetectedError: When on_threat="block" and threats found
            AuthenticationError: When API key is invalid
            RateLimitError: When rate limit is exceeded
            APIError: For other API errors
        """
        sensitivity = sensitivity or self.default_sensitivity
        on_threat = on_threat or self.default_on_threat

        logger.debug(f"Sanitizing text ({len(text)} chars) with sensitivity={sensitivity}")

        try:
            response = self._client.post(
                "/api/v1/sanitize",
                json={"text": text, "sensitivity": sensitivity},
            )
        except httpx.RequestError as e:
            raise APIError(f"Request failed: {e}") from e

        self._handle_error_response(response)

        data = response.json()
        issues = [
            Issue(
                type=i["type"],
                description=i["description"],
                severity=i["severity"],
                details=i.get("details", {}),
            )
            for i in data.get("issues", [])
        ]

        severity = data.get("severity_overall", 0)
        blocked = False

        # Handle threat modes
        if issues and on_threat == "block":
            raise ThreatDetectedError(issues=issues, severity=severity)

        if on_threat == "log_only":
            if issues:
                logger.warning(f"Threats detected (severity={severity}): {issues}")
            cleaned = data["original"]
        else:
            cleaned = data["cleaned"]

        return SanitizeResult(
            original=data["original"],
            cleaned=cleaned,
            issues=issues,
            severity=severity,
            token_count_before=data.get("token_count_before", 0),
            token_count_after=data.get("token_count_after", 0),
            blocked=blocked,
        )

    async def async_sanitize(
        self,
        text: str,
        *,
        sensitivity: Sensitivity | None = None,
        on_threat: OnThreat | None = None,
    ) -> SanitizeResult:
        """
        Async version of sanitize.

        Args:
            text: The prompt text to sanitize
            sensitivity: Detection sensitivity (strict/balanced/permissive)
            on_threat: Behavior when threat detected (clean/block/log_only)

        Returns:
            SanitizeResult with cleaned text and detected issues
        """
        sensitivity = sensitivity or self.default_sensitivity
        on_threat = on_threat or self.default_on_threat

        logger.debug(f"Async sanitizing text ({len(text)} chars)")

        try:
            response = await self._aclient.post(
                "/api/v1/sanitize",
                json={"text": text, "sensitivity": sensitivity},
            )
        except httpx.RequestError as e:
            raise APIError(f"Request failed: {e}") from e

        self._handle_error_response(response)

        data = response.json()
        issues = [
            Issue(
                type=i["type"],
                description=i["description"],
                severity=i["severity"],
                details=i.get("details", {}),
            )
            for i in data.get("issues", [])
        ]

        severity = data.get("severity_overall", 0)
        blocked = False

        if issues and on_threat == "block":
            raise ThreatDetectedError(issues=issues, severity=severity)

        if on_threat == "log_only":
            if issues:
                logger.warning(f"Threats detected (severity={severity}): {issues}")
            cleaned = data["original"]
        else:
            cleaned = data["cleaned"]

        return SanitizeResult(
            original=data["original"],
            cleaned=cleaned,
            issues=issues,
            severity=severity,
            token_count_before=data.get("token_count_before", 0),
            token_count_after=data.get("token_count_after", 0),
            blocked=blocked,
        )

    def _handle_error_response(self, response: httpx.Response) -> None:
        if response.status_code == 401:
            raise AuthenticationError()

        if response.status_code == 429:
            retry_after = response.headers.get("Retry-After")
            raise RateLimitError(retry_after=int(retry_after) if retry_after else None)

        if response.status_code >= 400:
            try:
                detail = response.json().get("detail", response.text)
            except Exception:
                detail = response.text
            raise APIError(message=detail, status_code=response.status_code)

    def close(self) -> None:
        """Close the HTTP client."""
        if self._sync_client:
            self._sync_client.close()
            self._sync_client = None

    async def aclose(self) -> None:
        """Close the async HTTP client."""
        if self._async_client:
            await self._async_client.aclose()
            self._async_client = None

    def __enter__(self) -> "CleanPrompts":
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    async def __aenter__(self) -> "CleanPrompts":
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.aclose()
