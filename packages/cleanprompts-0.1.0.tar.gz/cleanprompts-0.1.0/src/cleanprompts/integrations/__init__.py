"""Framework integrations for CleanPrompts."""

# Deep integrations - import only when extras installed
try:
    from cleanprompts.integrations.openai import protect as protect_openai
except ImportError:
    protect_openai = None  # type: ignore

try:
    from cleanprompts.integrations.anthropic import protect as protect_anthropic
except ImportError:
    protect_anthropic = None  # type: ignore

try:
    from cleanprompts.integrations.langchain import CleanPromptsCallback, protect_chain
except ImportError:
    CleanPromptsCallback = None  # type: ignore
    protect_chain = None  # type: ignore

try:
    from cleanprompts.integrations.fastapi import CleanPromptsMiddleware
except ImportError:
    CleanPromptsMiddleware = None  # type: ignore

__all__ = [
    "protect_openai",
    "protect_anthropic",
    "CleanPromptsCallback",
    "protect_chain",
    "CleanPromptsMiddleware",
]
