"""FastAPI middleware for CleanPrompts."""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Callable

from cleanprompts import CleanPrompts
from cleanprompts.types import OnThreat, Sensitivity

if TYPE_CHECKING:
    from starlette.middleware.base import BaseHTTPMiddleware
    from starlette.requests import Request
    from starlette.responses import Response


class CleanPromptsMiddleware:
    """
    FastAPI/Starlette middleware that sanitizes request bodies.

    Scans JSON request bodies for prompt-like fields and sanitizes them.

    Example:
        from fastapi import FastAPI
        from cleanprompts.integrations.fastapi import CleanPromptsMiddleware

        app = FastAPI()
        app.add_middleware(CleanPromptsMiddleware, api_key="cp_xxx")
    """

    PROMPT_FIELDS = {"prompt", "text", "message", "content", "input", "query"}

    def __init__(
        self,
        app: Callable,
        api_key: str | None = None,
        sensitivity: Sensitivity = "balanced",
        on_threat: OnThreat = "clean",
        fields: set[str] | None = None,
    ) -> None:
        self.app = app
        self._client = CleanPrompts(
            api_key=api_key,
            default_sensitivity=sensitivity,
            default_on_threat=on_threat,
        )
        self._sensitivity = sensitivity
        self._on_threat = on_threat
        self._fields = fields or self.PROMPT_FIELDS

    async def __call__(self, scope: dict, receive: Callable, send: Callable) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        # For now, pass through - full implementation would intercept body
        await self.app(scope, receive, send)
