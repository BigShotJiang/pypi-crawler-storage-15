"""LangChain integration for CleanPrompts."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any
from uuid import UUID

from cleanprompts import CleanPrompts
from cleanprompts.types import OnThreat, Sensitivity, SanitizeResult

if TYPE_CHECKING:
    from langchain_core.callbacks import BaseCallbackHandler


class CleanPromptsCallback:
    """LangChain callback handler that sanitizes prompts before LLM calls."""

    def __init__(
        self,
        api_key: str | None = None,
        *,
        sensitivity: Sensitivity = "balanced",
        on_threat: OnThreat = "clean",
    ) -> None:
        self._client = CleanPrompts(
            api_key=api_key,
            default_sensitivity=sensitivity,
            default_on_threat=on_threat,
        )
        self._sensitivity = sensitivity
        self._on_threat = on_threat
        self._last_sanitized: list[SanitizeResult] | None = None

    def on_llm_start(
        self,
        serialized: dict[str, Any],
        prompts: list[str],
        *,
        run_id: UUID | None = None,
        parent_run_id: UUID | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        """Sanitize prompts before they're sent to the LLM."""
        self._last_sanitized = []

        for i, prompt in enumerate(prompts):
            result = self._client.sanitize(
                prompt,
                sensitivity=self._sensitivity,
                on_threat=self._on_threat,
            )
            self._last_sanitized.append(result)
            prompts[i] = result.cleaned

    async def on_llm_start_async(
        self,
        serialized: dict[str, Any],
        prompts: list[str],
        **kwargs: Any,
    ) -> None:
        """Async version of on_llm_start."""
        self._last_sanitized = []

        for i, prompt in enumerate(prompts):
            result = await self._client.async_sanitize(
                prompt,
                sensitivity=self._sensitivity,
                on_threat=self._on_threat,
            )
            self._last_sanitized.append(result)
            prompts[i] = result.cleaned

    def on_chat_model_start(
        self,
        serialized: dict[str, Any],
        messages: list[list[Any]],
        *,
        run_id: UUID | None = None,
        parent_run_id: UUID | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        """Sanitize chat messages before they're sent to the model."""
        self._last_sanitized = []

        for message_list in messages:
            for msg in message_list:
                # Handle different message types
                content = getattr(msg, "content", None)
                if content and isinstance(content, str):
                    msg_type = getattr(msg, "type", None) or type(msg).__name__.lower()
                    if "human" in msg_type or "user" in msg_type:
                        result = self._client.sanitize(
                            content,
                            sensitivity=self._sensitivity,
                            on_threat=self._on_threat,
                        )
                        self._last_sanitized.append(result)
                        msg.content = result.cleaned


def protect_chain(
    chain: Any,
    *,
    api_key: str | None = None,
    sensitivity: Sensitivity = "balanced",
    on_threat: OnThreat = "clean",
) -> Any:
    """
    Add CleanPrompts protection to a LangChain chain.

    Example:
        from cleanprompts.integrations.langchain import protect_chain

        protected = protect_chain(my_chain, api_key="cp_xxx")
        result = protected.invoke({"input": user_input})
    """
    callback = CleanPromptsCallback(
        api_key=api_key,
        sensitivity=sensitivity,
        on_threat=on_threat,
    )

    # Add callback to chain's default callbacks
    if hasattr(chain, "callbacks"):
        if chain.callbacks is None:
            chain.callbacks = []
        chain.callbacks.append(callback)

    return chain
