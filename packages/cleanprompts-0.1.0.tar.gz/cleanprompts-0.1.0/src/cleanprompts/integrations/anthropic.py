"""Anthropic integration for CleanPrompts."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, TypeVar

from cleanprompts import CleanPrompts
from cleanprompts.types import OnThreat, Sensitivity

if TYPE_CHECKING:
    from anthropic import Anthropic, AsyncAnthropic

T = TypeVar("T", bound="Anthropic | AsyncAnthropic")


class ProtectedAnthropic:
    """Wrapper around Anthropic client that sanitizes prompts."""

    def __init__(
        self,
        client: "Anthropic",
        *,
        api_key: str | None = None,
        sensitivity: Sensitivity = "balanced",
        on_threat: OnThreat = "clean",
    ) -> None:
        self._client = client
        self._cleanprompts_client = CleanPrompts(
            api_key=api_key,
            default_sensitivity=sensitivity,
            default_on_threat=on_threat,
        )
        self._sensitivity = sensitivity
        self._on_threat = on_threat

        self.messages = ProtectedMessages(self)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._client, name)


class ProtectedMessages:
    """Wrapper for messages that sanitizes content."""

    def __init__(self, protected: ProtectedAnthropic) -> None:
        self._protected = protected

    def create(self, **kwargs: Any) -> Any:
        messages = kwargs.get("messages", [])
        sanitized_messages = []

        for msg in messages:
            if msg.get("role") == "user" and isinstance(msg.get("content"), str):
                result = self._protected._cleanprompts_client.sanitize(
                    msg["content"],
                    sensitivity=self._protected._sensitivity,
                    on_threat=self._protected._on_threat,
                )
                sanitized_messages.append({**msg, "content": result.cleaned})
            else:
                sanitized_messages.append(msg)

        kwargs["messages"] = sanitized_messages
        return self._protected._client.messages.create(**kwargs)

    async def acreate(self, **kwargs: Any) -> Any:
        messages = kwargs.get("messages", [])
        sanitized_messages = []

        for msg in messages:
            if msg.get("role") == "user" and isinstance(msg.get("content"), str):
                result = await self._protected._cleanprompts_client.async_sanitize(
                    msg["content"],
                    sensitivity=self._protected._sensitivity,
                    on_threat=self._protected._on_threat,
                )
                sanitized_messages.append({**msg, "content": result.cleaned})
            else:
                sanitized_messages.append(msg)

        kwargs["messages"] = sanitized_messages
        return await self._protected._client.messages.create(**kwargs)


def protect(
    client: T,
    *,
    api_key: str | None = None,
    sensitivity: Sensitivity = "balanced",
    on_threat: OnThreat = "clean",
) -> T:
    """
    Wrap an Anthropic client to automatically sanitize prompts.

    Args:
        client: Anthropic or AsyncAnthropic client instance
        api_key: CleanPrompts API key
        sensitivity: Detection sensitivity
        on_threat: Behavior when threat detected

    Returns:
        Protected client that sanitizes all user messages

    Example:
        from anthropic import Anthropic
        from cleanprompts.integrations.anthropic import protect

        client = protect(Anthropic(), api_key="cp_xxx")
        response = client.messages.create(...)
    """
    return ProtectedAnthropic(
        client,  # type: ignore
        api_key=api_key,
        sensitivity=sensitivity,
        on_threat=on_threat,
    )  # type: ignore
