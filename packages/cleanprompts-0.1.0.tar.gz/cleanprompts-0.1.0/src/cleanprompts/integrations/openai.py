"""OpenAI integration for CleanPrompts."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, TypeVar

from cleanprompts import CleanPrompts
from cleanprompts.types import OnThreat, Sensitivity

if TYPE_CHECKING:
    from openai import AsyncOpenAI, OpenAI

T = TypeVar("T", bound="OpenAI | AsyncOpenAI")


class ProtectedOpenAI:
    """Wrapper around OpenAI client that sanitizes prompts."""

    def __init__(
        self,
        client: "OpenAI",
        *,
        api_key: str | None = None,
        sensitivity: Sensitivity = "balanced",
        on_threat: OnThreat = "clean",
    ) -> None:
        self._client = client
        self._cleanprompts_client = CleanPrompts(
            api_key=api_key,
            default_sensitivity=sensitivity,
            default_on_threat=on_threat,
        )
        self._sensitivity = sensitivity
        self._on_threat = on_threat

        # Wrap chat.completions
        self.chat = ProtectedChat(self)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._client, name)


class ProtectedChat:
    """Wrapper for chat namespace."""

    def __init__(self, protected: ProtectedOpenAI) -> None:
        self._protected = protected
        self.completions = ProtectedCompletions(protected)


class ProtectedCompletions:
    """Wrapper for chat.completions that sanitizes messages."""

    def __init__(self, protected: ProtectedOpenAI) -> None:
        self._protected = protected

    def create(self, **kwargs: Any) -> Any:
        messages = kwargs.get("messages", [])
        sanitized_messages = []

        for msg in messages:
            if msg.get("role") == "user" and isinstance(msg.get("content"), str):
                result = self._protected._cleanprompts_client.sanitize(
                    msg["content"],
                    sensitivity=self._protected._sensitivity,
                    on_threat=self._protected._on_threat,
                )
                sanitized_messages.append({**msg, "content": result.cleaned})
            else:
                sanitized_messages.append(msg)

        kwargs["messages"] = sanitized_messages
        return self._protected._client.chat.completions.create(**kwargs)

    async def acreate(self, **kwargs: Any) -> Any:
        messages = kwargs.get("messages", [])
        sanitized_messages = []

        for msg in messages:
            if msg.get("role") == "user" and isinstance(msg.get("content"), str):
                result = await self._protected._cleanprompts_client.async_sanitize(
                    msg["content"],
                    sensitivity=self._protected._sensitivity,
                    on_threat=self._protected._on_threat,
                )
                sanitized_messages.append({**msg, "content": result.cleaned})
            else:
                sanitized_messages.append(msg)

        kwargs["messages"] = sanitized_messages
        # For async OpenAI client
        return await self._protected._client.chat.completions.create(**kwargs)


def protect(
    client: T,
    *,
    api_key: str | None = None,
    sensitivity: Sensitivity = "balanced",
    on_threat: OnThreat = "clean",
) -> T:
    """
    Wrap an OpenAI client to automatically sanitize prompts.

    Args:
        client: OpenAI or AsyncOpenAI client instance
        api_key: CleanPrompts API key
        sensitivity: Detection sensitivity
        on_threat: Behavior when threat detected

    Returns:
        Protected client that sanitizes all user messages

    Example:
        from openai import OpenAI
        from cleanprompts.integrations.openai import protect

        client = protect(OpenAI(), api_key="cp_xxx")
        response = client.chat.completions.create(...)
    """
    return ProtectedOpenAI(
        client,  # type: ignore
        api_key=api_key,
        sensitivity=sensitivity,
        on_threat=on_threat,
    )  # type: ignore
