from dataclasses import dataclass, field
from typing import Any, Literal


@dataclass
class Issue:
    """A detected security issue in the prompt."""

    type: str
    description: str
    severity: int
    details: dict[str, Any] = field(default_factory=dict)


@dataclass
class SanitizeResult:
    """Result from sanitizing a prompt."""

    original: str
    cleaned: str
    issues: list[Issue]
    severity: int
    token_count_before: int
    token_count_after: int
    blocked: bool


Sensitivity = Literal["strict", "balanced", "permissive"]
OnThreat = Literal["clean", "block", "log_only"]
