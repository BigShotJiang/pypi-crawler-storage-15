import pytest
from pytest_httpx import HTTPXMock

from cleanprompts import CleanPrompts
from cleanprompts.exceptions import ThreatDetectedError


@pytest.mark.asyncio
async def test_async_sanitize_clean_text(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url="https://api.cleanprompts.dev/api/v1/sanitize",
        json={
            "original": "hello world",
            "cleaned": "hello world",
            "issues": [],
            "severity_overall": 0,
            "token_count_before": 2,
            "token_count_after": 2,
        },
    )

    client = CleanPrompts(api_key="cp_test")
    result = await client.async_sanitize("hello world")

    assert result.cleaned == "hello world"
    assert result.severity == 0
    await client.aclose()


@pytest.mark.asyncio
async def test_async_sanitize_with_threats(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url="https://api.cleanprompts.dev/api/v1/sanitize",
        json={
            "original": "bad input",
            "cleaned": "safe",
            "issues": [{"type": "injection", "description": "test", "severity": 80}],
            "severity_overall": 80,
            "token_count_before": 2,
            "token_count_after": 1,
        },
    )

    client = CleanPrompts(api_key="cp_test")
    result = await client.async_sanitize("bad input")

    assert result.severity == 80
    assert len(result.issues) == 1
    await client.aclose()


@pytest.mark.asyncio
async def test_async_sanitize_block_mode(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url="https://api.cleanprompts.dev/api/v1/sanitize",
        json={
            "original": "bad input",
            "cleaned": "safe",
            "issues": [{"type": "injection", "description": "test", "severity": 80}],
            "severity_overall": 80,
            "token_count_before": 2,
            "token_count_after": 1,
        },
    )

    client = CleanPrompts(api_key="cp_test")

    with pytest.raises(ThreatDetectedError):
        await client.async_sanitize("bad input", on_threat="block")

    await client.aclose()


@pytest.mark.asyncio
async def test_async_context_manager(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url="https://api.cleanprompts.dev/api/v1/sanitize",
        json={
            "original": "test",
            "cleaned": "test",
            "issues": [],
            "severity_overall": 0,
            "token_count_before": 1,
            "token_count_after": 1,
        },
    )

    async with CleanPrompts(api_key="cp_test") as client:
        result = await client.async_sanitize("test")
        assert result.cleaned == "test"
