import pytest
from unittest.mock import AsyncMock, MagicMock
from pytest_httpx import HTTPXMock


def test_protect_wraps_client():
    pytest.importorskip("openai")
    from openai import OpenAI
    from cleanprompts.integrations.openai import protect

    mock_openai = MagicMock(spec=OpenAI)
    protected = protect(mock_openai, api_key="cp_test")

    assert hasattr(protected, "chat")
    assert hasattr(protected, "_cleanprompts_client")


def test_protect_sanitizes_messages(httpx_mock: HTTPXMock):
    pytest.importorskip("openai")
    from openai import OpenAI
    from cleanprompts.integrations.openai import protect

    # Mock CleanPrompts API response
    httpx_mock.add_response(
        url="https://api.cleanprompts.dev/api/v1/sanitize",
        json={
            "original": "user input",
            "cleaned": "safe input",
            "issues": [],
            "severity_overall": 0,
            "token_count_before": 2,
            "token_count_after": 2,
        },
    )

    mock_openai = MagicMock(spec=OpenAI)
    mock_create = MagicMock(return_value={"choices": []})
    mock_openai.chat.completions.create = mock_create

    protected = protect(mock_openai, api_key="cp_test")

    protected.chat.completions.create(
        model="gpt-4",
        messages=[{"role": "user", "content": "user input"}]
    )

    # Verify the original client was called with sanitized content
    mock_create.assert_called_once()
    call_kwargs = mock_create.call_args.kwargs
    messages = call_kwargs["messages"]
    assert messages[0]["content"] == "safe input"  # Should be sanitized, not "user input"


@pytest.mark.asyncio
async def test_protect_async_sanitizes_messages(httpx_mock: HTTPXMock):
    pytest.importorskip("openai")
    from openai import AsyncOpenAI
    from cleanprompts.integrations.openai import protect

    # Mock CleanPrompts API response
    httpx_mock.add_response(
        url="https://api.cleanprompts.dev/api/v1/sanitize",
        json={
            "original": "user input",
            "cleaned": "safe input",
            "issues": [],
            "severity_overall": 0,
            "token_count_before": 2,
            "token_count_after": 2,
        },
    )

    mock_openai = MagicMock(spec=AsyncOpenAI)
    mock_create = AsyncMock(return_value={"choices": []})
    mock_openai.chat.completions.create = mock_create

    protected = protect(mock_openai, api_key="cp_test")

    await protected.chat.completions.acreate(
        model="gpt-4",
        messages=[{"role": "user", "content": "user input"}]
    )

    # Verify the original client was called with sanitized content
    mock_create.assert_called_once()
    call_kwargs = mock_create.call_args.kwargs
    messages = call_kwargs["messages"]
    assert messages[0]["content"] == "safe input"  # Should be sanitized, not "user input"
