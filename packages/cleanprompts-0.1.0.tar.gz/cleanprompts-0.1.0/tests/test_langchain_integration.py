import pytest
from unittest.mock import MagicMock
from pytest_httpx import HTTPXMock


def test_callback_handler_exists():
    pytest.importorskip("langchain_core")
    from cleanprompts.integrations.langchain import CleanPromptsCallback

    callback = CleanPromptsCallback(api_key="cp_test")
    assert hasattr(callback, "on_llm_start")


def test_callback_sanitizes_prompts(httpx_mock: HTTPXMock):
    pytest.importorskip("langchain_core")
    from cleanprompts.integrations.langchain import CleanPromptsCallback

    httpx_mock.add_response(
        url="https://api.cleanprompts.dev/api/v1/sanitize",
        json={
            "original": "test prompt",
            "cleaned": "safe prompt",
            "issues": [],
            "severity_overall": 0,
            "token_count_before": 2,
            "token_count_after": 2,
        },
    )

    callback = CleanPromptsCallback(api_key="cp_test")

    # Simulate LangChain calling on_llm_start
    prompts = ["test prompt"]
    result = callback.on_llm_start(
        serialized={},
        prompts=prompts,
    )

    # The callback should have sanitized the prompts
    assert callback._last_sanitized is not None
    # Verify the prompt was mutated in place to the sanitized version
    assert prompts[0] == "safe prompt"


def test_callback_sanitizes_multiple_prompts(httpx_mock: HTTPXMock):
    pytest.importorskip("langchain_core")
    from cleanprompts.integrations.langchain import CleanPromptsCallback

    # Mock multiple sanitization calls
    httpx_mock.add_response(
        url="https://api.cleanprompts.dev/api/v1/sanitize",
        json={
            "original": "prompt 1",
            "cleaned": "sanitized 1",
            "issues": [],
            "severity_overall": 0,
            "token_count_before": 2,
            "token_count_after": 2,
        },
    )
    httpx_mock.add_response(
        url="https://api.cleanprompts.dev/api/v1/sanitize",
        json={
            "original": "prompt 2",
            "cleaned": "sanitized 2",
            "issues": [{"type": "injection", "description": "test", "severity": 50}],
            "severity_overall": 50,
            "token_count_before": 2,
            "token_count_after": 2,
        },
    )

    callback = CleanPromptsCallback(api_key="cp_test")

    prompts = ["prompt 1", "prompt 2"]
    callback.on_llm_start(serialized={}, prompts=prompts)

    # Both prompts should be sanitized
    assert prompts[0] == "sanitized 1"
    assert prompts[1] == "sanitized 2"
    assert len(callback._last_sanitized) == 2


@pytest.mark.asyncio
async def test_async_callback_sanitizes_prompts(httpx_mock: HTTPXMock):
    pytest.importorskip("langchain_core")
    from cleanprompts.integrations.langchain import CleanPromptsCallback

    httpx_mock.add_response(
        url="https://api.cleanprompts.dev/api/v1/sanitize",
        json={
            "original": "async test",
            "cleaned": "async safe",
            "issues": [],
            "severity_overall": 0,
            "token_count_before": 2,
            "token_count_after": 2,
        },
    )

    callback = CleanPromptsCallback(api_key="cp_test")

    prompts = ["async test"]
    await callback.on_llm_start_async(serialized={}, prompts=prompts)

    assert prompts[0] == "async safe"
    assert callback._last_sanitized is not None


def test_chat_model_start_sanitizes_messages(httpx_mock: HTTPXMock):
    pytest.importorskip("langchain_core")
    from cleanprompts.integrations.langchain import CleanPromptsCallback

    httpx_mock.add_response(
        url="https://api.cleanprompts.dev/api/v1/sanitize",
        json={
            "original": "user message",
            "cleaned": "safe message",
            "issues": [],
            "severity_overall": 0,
            "token_count_before": 2,
            "token_count_after": 2,
        },
    )

    callback = CleanPromptsCallback(api_key="cp_test")

    # Mock message object
    class MockMessage:
        def __init__(self, content, msg_type="human"):
            self.content = content
            self.type = msg_type

    messages = [[MockMessage("user message", "human")]]
    callback.on_chat_model_start(serialized={}, messages=messages)

    # The message content should be sanitized
    assert messages[0][0].content == "safe message"


def test_protect_chain_adds_callback():
    pytest.importorskip("langchain_core")
    from cleanprompts.integrations.langchain import protect_chain

    # Mock chain object
    class MockChain:
        def __init__(self):
            self.callbacks = None

    chain = MockChain()
    protected = protect_chain(chain, api_key="cp_test")

    assert protected.callbacks is not None
    assert len(protected.callbacks) == 1
