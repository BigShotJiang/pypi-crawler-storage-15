import pytest
from cleanprompts.exceptions import (
    CleanPromptsError,
    ThreatDetectedError,
    APIError,
    RateLimitError,
    AuthenticationError,
)
from cleanprompts.types import Issue


def test_threat_detected_error():
    issues = [Issue(type="injection", description="test", severity=80)]
    error = ThreatDetectedError(issues=issues, severity=80)
    assert error.issues == issues
    assert error.severity == 80
    assert "Threat detected" in str(error)


def test_api_error():
    error = APIError(message="Server error", status_code=500)
    assert error.status_code == 500
    assert "Server error" in str(error)


def test_rate_limit_error():
    error = RateLimitError(retry_after=60)
    assert error.retry_after == 60
    assert "Rate limit" in str(error)


def test_authentication_error():
    error = AuthenticationError()
    assert "Invalid API key" in str(error)


def test_inheritance():
    assert issubclass(ThreatDetectedError, CleanPromptsError)
    assert issubclass(APIError, CleanPromptsError)
    assert issubclass(RateLimitError, APIError)
    assert issubclass(AuthenticationError, APIError)
