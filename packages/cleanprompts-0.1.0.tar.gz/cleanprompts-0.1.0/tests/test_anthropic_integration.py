import pytest
from unittest.mock import MagicMock
from pytest_httpx import HTTPXMock


def test_protect_wraps_anthropic_client():
    pytest.importorskip("anthropic")
    from anthropic import Anthropic
    from cleanprompts.integrations.anthropic import protect

    mock_anthropic = MagicMock(spec=Anthropic)
    protected = protect(mock_anthropic, api_key="cp_test")

    assert hasattr(protected, "messages")
    assert hasattr(protected, "_cleanprompts_client")


def test_protect_sanitizes_anthropic_messages(httpx_mock: HTTPXMock):
    """Test that protect() sanitizes user messages before sending to Anthropic."""
    pytest.importorskip("anthropic")
    from anthropic import Anthropic
    from cleanprompts.integrations.anthropic import protect

    # Mock CleanPrompts API response
    httpx_mock.add_response(
        url="https://api.cleanprompts.dev/api/v1/sanitize",
        json={
            "original": "user input",
            "cleaned": "safe input",
            "issues": [],
            "severity_overall": 0,
            "token_count_before": 2,
            "token_count_after": 2,
        },
    )

    mock_anthropic = MagicMock(spec=Anthropic)
    mock_anthropic.messages.create = MagicMock(return_value={"content": []})

    protected = protect(mock_anthropic, api_key="cp_test")

    protected.messages.create(
        model="claude-3-sonnet-20240229",
        max_tokens=100,
        messages=[{"role": "user", "content": "user input"}]
    )

    # Verify the original client was called
    assert mock_anthropic.messages.create.called

    # IMPORTANT: Verify that sanitization occurred by checking the actual call
    call_args = mock_anthropic.messages.create.call_args
    assert call_args is not None

    # Get the messages that were actually passed to the underlying client
    messages = call_args.kwargs.get("messages")
    assert messages is not None
    assert len(messages) == 1

    # The critical assertion: verify "safe input" was passed, NOT "user input"
    assert messages[0]["content"] == "safe input", "Expected sanitized content to be passed to Anthropic"
