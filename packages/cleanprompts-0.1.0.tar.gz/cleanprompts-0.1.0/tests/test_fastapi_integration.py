import pytest
from pytest_httpx import HTTPXMock


def test_middleware_exists():
    pytest.importorskip("fastapi")
    from cleanprompts.integrations.fastapi import CleanPromptsMiddleware

    assert CleanPromptsMiddleware is not None


def test_middleware_can_be_added():
    pytest.importorskip("fastapi")
    from fastapi import FastAPI
    from cleanprompts.integrations.fastapi import CleanPromptsMiddleware

    app = FastAPI()
    app.add_middleware(CleanPromptsMiddleware, api_key="cp_test")

    # Should not raise
    assert True
