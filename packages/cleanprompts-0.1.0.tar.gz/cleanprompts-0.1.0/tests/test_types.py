from cleanprompts.types import Issue, SanitizeResult


def test_issue_creation():
    issue = Issue(
        type="injection",
        description="Potential prompt injection detected",
        severity=80,
        details={"matched_text": "ignore previous"},
    )
    assert issue.type == "injection"
    assert issue.severity == 80
    assert issue.details["matched_text"] == "ignore previous"


def test_sanitize_result_creation():
    result = SanitizeResult(
        original="test input",
        cleaned="test input",
        issues=[],
        severity=0,
        token_count_before=2,
        token_count_after=2,
        blocked=False,
    )
    assert result.original == "test input"
    assert result.cleaned == "test input"
    assert result.severity == 0
    assert result.blocked is False


def test_sanitize_result_with_issues():
    issue = Issue(
        type="injection",
        description="Detected",
        severity=75,
    )
    result = SanitizeResult(
        original="bad input",
        cleaned="safe input",
        issues=[issue],
        severity=75,
        token_count_before=2,
        token_count_after=2,
        blocked=False,
    )
    assert len(result.issues) == 1
    assert result.issues[0].type == "injection"
