# Contributors to django_aws_ses

The `django_aws_ses` package was developed by the ZeeksGeeks team. We thank the following individuals for their contributions to this project:

## Core Contributors
- **Raymond Jessop** - Lead developer, architecture, testing, and AWS SES integration.
- **Isaac Jessop** -  Work on AWS Send Limits.

## How to Contribute
If you’d like to contribute to `django_aws_ses`, please see our [CONTRIBUTING.md](https://github.com/ZeeksGeeks/django_aws_ses/blob/master/CONTRIBUTING.md) file for guidelines or contact us at contact@zeeksgeeks.com.

Thank you to all contributors for making `django_aws_ses` possible!