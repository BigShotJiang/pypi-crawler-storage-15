from setuptools import setup  # type: ignore

setup()  # type: ignore
