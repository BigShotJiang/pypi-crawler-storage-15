"""Model Context Protocol adapter."""
