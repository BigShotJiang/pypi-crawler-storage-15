"""Temporal.io workflow adapter."""
