"""Tests for bridges module."""

