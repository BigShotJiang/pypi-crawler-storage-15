bayinx.vi package
=================

Submodules
----------

bayinx.vi.meanfield module
--------------------------

.. automodule:: bayinx.vi.meanfield
   :members:
   :show-inheritance:
   :undoc-members:

bayinx.vi.normalizing\_flow module
----------------------------------

.. automodule:: bayinx.vi.normalizing_flow
   :members:
   :show-inheritance:
   :undoc-members:

bayinx.vi.standard module
-------------------------

.. automodule:: bayinx.vi.standard
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: bayinx.vi
   :members:
   :show-inheritance:
   :undoc-members:
