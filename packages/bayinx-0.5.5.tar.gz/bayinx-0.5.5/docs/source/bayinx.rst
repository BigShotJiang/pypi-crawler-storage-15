bayinx package
==============

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   bayinx.constraints
   bayinx.core
   bayinx.dists
   bayinx.flows
   bayinx.nodes
   bayinx.vi

Submodules
----------

bayinx.ops module
-----------------

.. automodule:: bayinx.ops
   :members:
   :show-inheritance:
   :undoc-members:

bayinx.posterior module
-----------------------

.. automodule:: bayinx.posterior
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: bayinx
   :members:
   :show-inheritance:
   :undoc-members:
