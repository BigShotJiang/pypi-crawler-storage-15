bayinx.flows package
====================

Submodules
----------

bayinx.flows.diagaffine module
------------------------------

.. automodule:: bayinx.flows.diagaffine
   :members:
   :show-inheritance:
   :undoc-members:

bayinx.flows.fullaffine module
------------------------------

.. automodule:: bayinx.flows.fullaffine
   :members:
   :show-inheritance:
   :undoc-members:

bayinx.flows.lowrankaffine module
---------------------------------

.. automodule:: bayinx.flows.lowrankaffine
   :members:
   :show-inheritance:
   :undoc-members:

bayinx.flows.otflow module
--------------------------

.. automodule:: bayinx.flows.otflow
   :members:
   :show-inheritance:
   :undoc-members:

bayinx.flows.planar module
--------------------------

.. automodule:: bayinx.flows.planar
   :members:
   :show-inheritance:
   :undoc-members:

bayinx.flows.radial module
--------------------------

.. automodule:: bayinx.flows.radial
   :members:
   :show-inheritance:
   :undoc-members:

bayinx.flows.sylvester module
-----------------------------

.. automodule:: bayinx.flows.sylvester
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: bayinx.flows
   :members:
   :show-inheritance:
   :undoc-members:
