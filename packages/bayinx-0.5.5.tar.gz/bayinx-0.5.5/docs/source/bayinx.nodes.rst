bayinx.nodes package
====================

Submodules
----------

bayinx.nodes.continuous module
------------------------------

.. automodule:: bayinx.nodes.continuous
   :members:
   :show-inheritance:
   :undoc-members:

bayinx.nodes.observed module
----------------------------

.. automodule:: bayinx.nodes.observed
   :members:
   :show-inheritance:
   :undoc-members:

bayinx.nodes.stochastic module
------------------------------

.. automodule:: bayinx.nodes.stochastic
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: bayinx.nodes
   :members:
   :show-inheritance:
   :undoc-members:
