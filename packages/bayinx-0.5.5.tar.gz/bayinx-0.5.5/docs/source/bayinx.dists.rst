bayinx.dists package
====================

Submodules
----------

bayinx.dists.bernoulli module
-----------------------------

.. automodule:: bayinx.dists.bernoulli
   :members:
   :show-inheritance:
   :undoc-members:

bayinx.dists.binomial module
----------------------------

.. automodule:: bayinx.dists.binomial
   :members:
   :show-inheritance:
   :undoc-members:

bayinx.dists.exponential module
-------------------------------

.. automodule:: bayinx.dists.exponential
   :members:
   :show-inheritance:
   :undoc-members:

bayinx.dists.normal module
--------------------------

.. automodule:: bayinx.dists.normal
   :members:
   :show-inheritance:
   :undoc-members:

bayinx.dists.poisson module
---------------------------

.. automodule:: bayinx.dists.poisson
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: bayinx.dists
   :members:
   :show-inheritance:
   :undoc-members:
