from .bernoulli import Bernoulli as Bernoulli
from .binomial import Binomial as Binomial
from .exponential import Exponential as Exponential
from .normal import Normal as Normal
from .poisson import Poisson as Poisson
