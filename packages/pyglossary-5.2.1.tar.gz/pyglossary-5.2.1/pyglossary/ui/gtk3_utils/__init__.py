# mypy: ignore-errors
# do not sort these imports!
from gi.repository import Gtk as gtk  # noqa: I001
from gi.repository import Gdk as gdk  # noqa: I001

__all__ = ["gdk", "gtk"]
