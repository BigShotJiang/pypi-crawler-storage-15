This module adds the function to calculate commissions in sales orders.

Commission lines assigned to sales order lines will be passed to the
corresponding invoice lines.

Creating settlements directly from the sales order lines is outside the
scope of this module.

This module depends on the account_commission module.
