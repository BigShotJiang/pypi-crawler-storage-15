"""
The purpose of this simple test app is to compute Surface MSE
every 30 seconds of wits stream records. Note that this parameter
is only generated when the state is Drilling (either Rotary or Slide).
"""

from testcase.app.app_constants import constants  # noqa: F401
