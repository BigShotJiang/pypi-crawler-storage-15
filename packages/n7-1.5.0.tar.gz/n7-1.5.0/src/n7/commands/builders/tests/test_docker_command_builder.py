class TestDockerCommandBuilder:
    pass
