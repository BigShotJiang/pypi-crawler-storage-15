#!/usr/bin/env python
# -*- coding: utf-8 -*-

###############################################################################

METADATA_UNPROCESSED = "unprocessed"
METADATA_PROCESSED = "processed"
