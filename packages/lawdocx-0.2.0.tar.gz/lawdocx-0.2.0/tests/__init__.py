"""Tests for lawdocx."""
