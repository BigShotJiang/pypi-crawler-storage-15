"""lawdocx - Little tools for dealing with docx files, useful for lawyers and their LLMs."""

__version__ = "0.2.0"
