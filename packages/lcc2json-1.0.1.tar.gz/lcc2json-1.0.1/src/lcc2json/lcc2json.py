#!/usr/bin/env python3
"""Extract LCC (Library of Congress Classification) outlines from downloaded JSON files.

This script processes JSON files downloaded from id.loc.gov and produces
a unified LCC classification file (lcc.json).
"""

import argparse
import json
import re
from pathlib import Path

from pydantic import BaseModel, Field, ConfigDict, field_serializer


def _serialize_number(value: float) -> int | float:
    """Serialize a number, converting to int if it's a whole number."""
    if value == int(value):
        return int(value)
    return value


class Classification(BaseModel):
    """A single LCC classification entry."""

    model_config = ConfigDict(populate_by_name=True)

    id: str = ""
    parents: list[str] = Field(default_factory=list)
    prefix: str
    start: float
    stop: float
    subject: str

    @field_serializer("start", "stop")
    @staticmethod
    def serialize_numbers(value: float) -> int | float:
        """Serialize start/stop as int when they are whole numbers."""
        return _serialize_number(value)


# JSON-LD property URIs
MADS_AUTH_LABEL = "http://www.loc.gov/mads/rdf/v1#authoritativeLabel"
MADS_BROADER = "http://www.loc.gov/mads/rdf/v1#hasBroaderAuthority"
MADS_CODE = "http://www.loc.gov/mads/rdf/v1#code"
RDFS_LABEL = "http://www.w3.org/2000/01/rdf-schema#label"
RDF_TYPE = "@type"
LCC_CLASS_NUMBER = "http://id.loc.gov/ontologies/lcc#ClassNumber"
LCC_RANGE = "http://id.loc.gov/ontologies/lcc#Range"
CLASSIFICATION_BASE = "http://id.loc.gov/authorities/classification/"


def extract_id(uri: str) -> str:
    """Extract classification ID from a full URI.

    Args:
        uri: Full URI like "http://id.loc.gov/authorities/classification/AC999"

    Returns:
        Short ID like "AC999"
    """
    if uri.startswith(CLASSIFICATION_BASE):
        return uri[len(CLASSIFICATION_BASE) :]
    return uri


def parse_lcc_code(code: str) -> tuple[str, float, float] | None:
    """Parse an LCC code into prefix, start, and stop values.

    Args:
        code: The LCC code string (e.g., "AC999", "AC1-AC1100", "F1170.52").

    Returns:
        Tuple of (prefix, start, stop) or None if parsing fails.
    """
    # Remove brackets and parentheses from around the entire code
    working_code = code
    if working_code.startswith("[") and working_code.endswith("]"):
        working_code = working_code[1:-1]
    elif working_code.startswith("(") and working_code.endswith(")"):
        working_code = working_code[1:-1]

    # Extract prefix (letters at the start)
    prefix_match = re.match(r"^([A-Z]+)", working_code)
    if not prefix_match:
        return None
    prefix = prefix_match.group(1)

    # Get the rest after the prefix
    rest = working_code[len(prefix) :]

    # Handle range codes like "1-AC1100" or "1-1100"
    if "-" in rest:
        parts = rest.split("-")

        # Parse first part (number after prefix)
        first_match = re.match(r"^([0-9]+(?:\.[0-9]+)?)", parts[0])
        if not first_match:
            return None
        start = float(first_match.group(1))

        # Parse second part (may have prefix repeated or just number)
        second_part = parts[1]

        # Remove prefix if repeated (e.g., "AC1100" -> "1100")
        if second_part.startswith(prefix):
            second_part = second_part[len(prefix) :]

        # Handle decimal shorthand (e.g., ".52" means same integer + .52)
        if second_part.startswith("."):
            int_part = int(start)
            try:
                stop = float(str(int_part) + second_part)
            except ValueError:
                return None
        else:
            # Extract numeric portion
            second_match = re.match(r"^([0-9]+(?:\.[0-9]+)?)", second_part)
            if second_match:
                stop = float(second_match.group(1))
            else:
                stop = start

        # Ensure start <= stop
        if stop < start:
            start, stop = stop, start

        return prefix, start, stop
    else:
        # Single number (no range)
        num_match = re.match(r"^([0-9]+(?:\.[0-9]+)?)", rest)
        if num_match:
            num = float(num_match.group(1))
            return prefix, num, num
        return None


def get_label(item: dict) -> str:
    """Extract the subject label from a JSON-LD item.

    Prefers authoritativeLabel, falls back to rdfs:label.

    Args:
        item: JSON-LD item dictionary

    Returns:
        Subject label string
    """
    # Try authoritativeLabel first (short form)
    auth_labels = item.get(MADS_AUTH_LABEL, [])
    if auth_labels:
        return auth_labels[0].get("@value", "")

    # Fall back to rdfs:label (may be full breadcrumb)
    rdfs_labels = item.get(RDFS_LABEL, [])
    if rdfs_labels:
        label = rdfs_labels[0].get("@value", "")
        # If it's a breadcrumb path, extract the last part
        if "--" in label:
            return label.split("--")[-1].strip()
        return label

    return ""


def get_broader_ids(item: dict) -> list[str]:
    """Extract parent classification IDs from a JSON-LD item.

    Args:
        item: JSON-LD item dictionary

    Returns:
        List of parent classification IDs
    """
    broader = item.get(MADS_BROADER, [])
    parents = []
    for b in broader:
        uri = b.get("@id", "")
        if uri.startswith(CLASSIFICATION_BASE):
            parents.append(extract_id(uri))
    return parents


def is_classification_entry(item: dict) -> bool:
    """Check if a JSON-LD item is a classification entry.

    Args:
        item: JSON-LD item dictionary

    Returns:
        True if this is a classification entry
    """
    item_id = item.get("@id", "")
    if not item_id.startswith(CLASSIFICATION_BASE):
        return False

    # Must have a type
    types = item.get(RDF_TYPE, [])
    if not types:
        return False

    # Accept ClassNumber or Range types, or Authority/Concept with a label
    if LCC_CLASS_NUMBER in types or LCC_RANGE in types:
        return True

    # Also accept items that have labels (some entries use Authority/Concept type)
    if item.get(MADS_AUTH_LABEL) or item.get(RDFS_LABEL):
        return True

    return False


def process_json_file(json_path: Path) -> list[tuple[str, Classification]]:
    """Process a single JSON file and extract classifications.

    Args:
        json_path: Path to the JSON file

    Returns:
        List of (id, Classification) tuples
    """
    with open(json_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    classifications = []

    for item in data:
        if not is_classification_entry(item):
            continue

        # Extract ID
        item_id = extract_id(item.get("@id", ""))
        if not item_id:
            continue

        # Get subject label
        subject = get_label(item)
        if not subject:
            continue

        # Parse the code
        parsed = parse_lcc_code(item_id)
        if not parsed:
            continue

        prefix, start, stop = parsed

        # Get parent links
        parents = get_broader_ids(item)

        classifications.append(
            (
                item_id,
                Classification(
                    id=item_id,
                    parents=parents,
                    prefix=prefix,
                    start=start,
                    stop=stop,
                    subject=subject,
                ),
            )
        )

    return classifications


def main() -> None:
    """Main entry point for the script."""
    parser = argparse.ArgumentParser(
        description="Extract LCC outlines from downloaded JSON files."
    )
    parser.add_argument(
        "-i",
        "--input-dir",
        type=str,
        default="json",
        help="Directory containing JSON files (default: json)",
    )
    parser.add_argument(
        "-o",
        "--output",
        type=str,
        default="lcc.json",
        help="Output file path (default: lcc.json)",
    )
    parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="Enable verbose output",
    )
    parser.add_argument(
        "--ranges",
        action="store_true",
        help="Include start/stop/prefix range fields in output (larger file size)",
    )

    args = parser.parse_args()

    input_dir = Path(args.input_dir)
    if not input_dir.exists():
        print(f"Error: Input directory '{input_dir}' does not exist.")
        print("Run download_json.py first to download the JSON files.")
        return

    # Collect all classifications
    all_classifications: dict[str, list[Classification]] = {}
    seen_ids: set[str] = set()
    total_files = 0
    total_entries = 0

    # Process all JSON files
    json_files = sorted(input_dir.glob("*.json"))

    # Skip the root classification file (it's just an index)
    skip_files = {"classification.json"}

    for json_path in json_files:
        if json_path.name in skip_files:
            continue

        if args.verbose:
            print(f"Processing: {json_path.name}")

        total_files += 1

        try:
            classifications = process_json_file(json_path)
        except (json.JSONDecodeError, OSError) as e:
            print(f"Error processing {json_path}: {e}")
            continue

        for item_id, classification in classifications:
            # Skip duplicates (same ID might appear in multiple files)
            if item_id in seen_ids:
                continue
            seen_ids.add(item_id)

            prefix = classification.prefix
            if prefix not in all_classifications:
                all_classifications[prefix] = []
            all_classifications[prefix].append(classification)
            total_entries += 1

    # Sort entries within each prefix by start value
    for prefix in all_classifications:
        all_classifications[prefix].sort(key=lambda c: (c.start, c.stop))

    # Compute parent relationships based on numeric ranges
    # This is needed because range files don't include hasBroaderAuthority for embedded entries
    for prefix, classifications in all_classifications.items():
        for i, classification in enumerate(classifications):
            # Skip if we already have parents from the JSON data
            if classification.parents:
                continue

            # Find all valid parents (ranges that contain this entry)
            valid_parents = []
            for j, other in enumerate(classifications):
                # Can't be parent of itself
                if i == j:
                    continue

                # Parent must start at or before this entry
                if classification.start < other.start:
                    continue

                # Parent must end at or after this entry
                if classification.stop > other.stop:
                    continue

                # If same range, earlier entry is not a parent of later entry
                if (
                    classification.start == other.start
                    and classification.stop == other.stop
                    and j > i
                ):
                    continue

                valid_parents.append((other.start, other.stop, other.id))

            # Sort parents by start (ascending) then stop (descending) to get hierarchy
            valid_parents.sort(key=lambda x: (x[0], -x[1]))
            classification.parents = [p[2] for p in valid_parents]

    # Convert to serializable format
    if args.ranges:
        # Include all fields
        output_data = {
            prefix: [cls.model_dump() for cls in classifications]
            for prefix, classifications in sorted(all_classifications.items())
        }
    else:
        # Exclude start, stop, and prefix fields (prefix is redundant with id)
        exclude_fields = {"start", "stop", "prefix"}
        output_data = {
            prefix: [cls.model_dump(exclude=exclude_fields) for cls in classifications]
            for prefix, classifications in sorted(all_classifications.items())
        }

    # Write output
    output_path = Path(args.output)
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(output_data, f, indent=2)

    print(f"Processed {total_files} files")
    print(f"Extracted {total_entries} classification entries")
    print(f"Found {len(all_classifications)} unique prefixes")
    print(f"Output written to: {output_path}")


if __name__ == "__main__":
    main()
