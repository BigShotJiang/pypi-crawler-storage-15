# This file is generated. Do not modify by hand.
from enum import Enum


class StreamAxisType(Enum):
    """
    Denotes type of the stream axis.
    """

    PHYSICAL = 0
    LOCKSTEP = 1
