# This file is generated. Do not modify by hand.
from enum import Enum


class OscilloscopeDataSource(Enum):
    """
    Kind of channel to record in the Oscilloscope.
    """

    SETTING = 0
    IO = 1
