# This file is generated. Do not modify by hand.
from enum import Enum


class DeviceType(Enum):
    """
    Denotes type of an device and units it accepts.
    """

    UNKNOWN = 0
    LINEAR = 1
    ROTARY = 2
