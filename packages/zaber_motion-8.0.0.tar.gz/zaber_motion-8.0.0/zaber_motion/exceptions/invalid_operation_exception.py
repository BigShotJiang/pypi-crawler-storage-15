﻿# ===== THIS FILE IS GENERATED FROM A TEMPLATE ===== #
# ============== DO NOT EDIT DIRECTLY ============== #

from .motion_lib_exception import MotionLibException


class InvalidOperationException(MotionLibException):
    """
    Thrown when operation cannot be performed at given time or context.
    """
