﻿# ===== THIS FILE IS GENERATED FROM A TEMPLATE ===== #
# ============== DO NOT EDIT DIRECTLY ============== #

from .motion_lib_exception import MotionLibException


class InvalidCsvDataException(MotionLibException):
    """
    Thrown when CSV file cannot be parsed as expected.
    """
