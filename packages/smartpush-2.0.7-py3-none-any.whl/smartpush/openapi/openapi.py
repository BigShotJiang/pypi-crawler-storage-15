import random

from smartpush.base.request_base import OpenApiRequestBase
from smartpush.base.url_enum import URL


class OpenApi(OpenApiRequestBase):
    def __init__(self, event_id=None, *args, **kwargs):
        """初始化OpenApi，支持传入event_id"""
        super().__init__(*args, **kwargs)  # 调用父类初始化
        self.event_id = event_id  # 初始化event_id属性
        self.attrTypeList = ('STRING', 'BIGINT', 'BOOLEAN', 'DATE', 'DECIMAL')

    def get_attribute_type(self, _type=None):
        """
        返回一个数据类型('STRING', 'BIGINT', 'BOOLEAN', 'DATE', 'DECIMAL')
        :param _type:
        :return:
        """

        if _type is not None and _type in self.attrTypeList:
            return _type
        else:
            return random.choice(self.attrTypeList)

    def getEventMetaList(self, code=None, channel=None):
        """
        获取EventMeta数据
        :param code: 事件编码
        :param channel: 渠道类型
        :return: 请求结果
        """
        requestParam = {"pageModel": {"page": 1, "pageSize": 20}}
        # 正确的参数更新逻辑：有值才更新
        if channel:
            requestParam["channel"] = channel
        if code:
            requestParam["code"] = code
        result = self.request(
            URL.OpenApi.getEventMetaList.url,
            URL.OpenApi.getEventMetaList.method,
            data=requestParam
        )
        return result

    def getEventMetaById(self, eventCode):
        """
        获取事件详情
        :param eventCode: 事件编码
        :return: 请求结果
        """
        if not self.event_id:
            raise ValueError("event_id未初始化，请在实例化时传入")
        requestParam = {"id": self.event_id, "eventCode": eventCode}
        result = self.request(
            URL.OpenApi.getEventMetaById.url,
            URL.OpenApi.getEventMetaById.method,
            data=requestParam
        )
        return result

    def deleteEventMetaById(self, eventCode):
        """
        删除事件（根据ID）
        :param eventCode: 事件编码
        :return: 请求结果
        """
        if not self.event_id:
            raise ValueError("event_id未初始化，请在实例化时传入")
        requestParam = {"id": self.event_id, "eventCode": eventCode}
        result = self.request(
            URL.OpenApi.delEventMetaById.url,
            URL.OpenApi.delEventMetaById.method,
            data=requestParam
        )
        return result

    def editEventMeta(self, eventCode, eventName, eventChannel, channelMetaTabi, eventAttrs: list,
                      updateEventAttrs: list, deleteEventAttrs: list):
        if not self.event_id:
            raise ValueError("event_id未初始化，请在实例化时传入")
        requestParam = {
            "eventCode": eventCode,
            "eventName": eventName,
            "eventChannel": eventChannel,
            "eventAttrs": eventAttrs,
            "id": self.event_id,
            "channel": {
                "updateEventChannel": {
                    "channelMetaTabi": channelMetaTabi,
                    "channelCode": "eventChannel"
                }
            },
            "attrs": {
                "updateEventAttrs": updateEventAttrs,
                "deleteEventAttrs": deleteEventAttrs
            }
        }
        result = self.request(
            URL.OpenApi.editEventMeta.url,
            URL.OpenApi.editEventMeta.method,
            data=requestParam
        )
        return result

    def getEventChannel(self):
        # requestParam = {"id": self.event_id, "eventCode": eventCode}
        result = self.request(
            URL.OpenApi.getEventChannel.url,
            URL.OpenApi.getEventChannel.method,
        )
        return result

    def getEventAttr(self):
        result = self.request(
            URL.OpenApi.getEventAttr.url,
            URL.OpenApi.getEventAttr.method,
        )
        return result


class AssertOpenApi(OpenApi):
    def assert_event_create_success(self, code, channel, is_delete=True) -> str:
        """
        断言事件新增成功，并返回eventId
        :param code: 事件编码
        :param channel: 渠道类型
        :param is_delete: 是否删除事件
        :return: eventId
        """
        event_id = None
        try:
            result = self.getEventMetaList(code=code, channel=channel)
            # 安全获取数据，避免KeyError
            result_data = result.get("resultData", {})
            datas = result_data.get("datas", [])

            if not datas:
                raise AssertionError(f"未找到事件：code={code}, channel={channel}")
            matched_data = None
            for data in datas:
                if data.get("eventCode") == code and data.get("channelType") == channel:
                    matched_data = data
                    break
            if not matched_data:
                raise AssertionError(f"事件属性不匹配：code={code}, channel={channel}")

            # 断言关键属性
            assert matched_data.get("isMerchantEvent"), "isMerchantEvent应为True"
            event_id = matched_data.get("eventId")
            assert event_id, "eventId不存在"
            return event_id

        except Exception as e:
            raise AssertionError(f"事件新增断言失败：{str(e)}") from e
        finally:
            if is_delete and event_id:
                self.event_id = event_id
                self.deleteEventMetaById(code)
