class InvalidStingerStructure(Exception):
    pass
