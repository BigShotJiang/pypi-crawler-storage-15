class CraftLetCLI:
    pass
