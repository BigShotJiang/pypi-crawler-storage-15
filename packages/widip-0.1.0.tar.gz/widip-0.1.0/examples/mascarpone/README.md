# Crema di Mascarpone and Diagrammatic Reasoning

These examples come from Pawel Sobocinski's [blog post]. They are key to get a good understanding of Diagrammatic Reasoning before diving into Computing.

`colltoaction`'s talk in Spanish:
* https://youtu.be/cyz0SxU49Mc

[blog post]: https://graphicallinearalgebra.net/2015/05/06/crema-di-mascarpone-rules-of-the-game-part-2-and-diagrammatic-reasoning/
