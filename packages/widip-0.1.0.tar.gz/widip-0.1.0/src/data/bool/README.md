# Bool

The `bool` diagrams simply encode truth values.

For example the `and` truth table:

![](and.jpg)
