"""
Common library for grz applications.
"""

__version__ = "1.6.0"
