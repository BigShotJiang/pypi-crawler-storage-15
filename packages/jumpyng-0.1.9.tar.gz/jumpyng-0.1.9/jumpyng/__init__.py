"""
Lightweight helpers for processing and visualizing jumping experiment data.
"""

__all__ = []

# Keep version here so packaging stays single‑sourced.
__version__ = "0.1.9"
