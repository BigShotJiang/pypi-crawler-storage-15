"""Tests for FASRAT package."""
