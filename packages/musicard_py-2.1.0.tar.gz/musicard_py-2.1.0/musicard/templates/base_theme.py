"""
Musicard - A Python library for generating music card images
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, Union, Tuple
from PIL import Image, ImageDraw

class BaseTheme(ABC):
    """Abstract base class for all music card themes."""

    def __init__(self, width: int = 1200, height: int = 400):
        self.width = width
        self.height = height

    @abstractmethod
    def render(self, image: Image.Image, draw: ImageDraw.ImageDraw, data: Dict[str, Any]) -> None:
        """Render the theme on the image.

        Args:
            image: PIL Image to draw on
            draw: PIL ImageDraw object
            data: Dictionary containing theme-specific data
        """
        pass

    def get_default_data(self) -> Dict[str, Any]:
        """Get default data for the theme."""
        return {
            'name': 'Musicard',
            'author': 'By Unburn',
            'thumbnailImage': None,
            'progress': 0,
            'progressColor': '#FF7A00',
            'progressBarColor': '#5F2D00',
            'backgroundColor': '#070707',
            'nameColor': '#FF7A00',
            'authorColor': '#FFFFFF',
        }