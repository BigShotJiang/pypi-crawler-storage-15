"""
Text rendering utilities for Musicard
"""

from PIL import ImageDraw, ImageFont
from typing import Tuple, Union
import textwrap

def draw_text_with_shadow(draw: ImageDraw.ImageDraw,
                         text: str,
                         font: Union[ImageFont.FreeTypeFont, ImageFont.ImageFont],
                         color: str,
                         shadow_color: str,
                         position: Tuple[int, int],
                         shadow_offset: Tuple[int, int] = (2, 2)) -> None:
    """Draw text with a shadow.

    Args:
        draw: ImageDraw object
        text: Text to draw
        font: Font to use
        color: Text color
        shadow_color: Shadow color
        position: Text position (x, y)
        shadow_offset: Shadow offset (dx, dy)
    """
    x, y = position
    dx, dy = shadow_offset
    draw.text((x + dx, y + dy), text, font=font, fill=shadow_color)
    draw.text((x, y), text, font=font, fill=color)

def draw_text_centered(draw: ImageDraw.ImageDraw,
                      text: str,
                      font: Union[ImageFont.FreeTypeFont, ImageFont.ImageFont],
                      color: str,
                      position: Tuple[int, int]) -> None:
    """Draw centered text at the given position.

    Args:
        draw: ImageDraw object
        text: Text to draw
        font: Font to use
        color: Text color
        position: Center position (x, y)
    """
    bbox = draw.textbbox((0, 0), text, font=font)
    text_width = bbox[2] - bbox[0]
    text_height = bbox[3] - bbox[1]
    x = position[0] - text_width // 2
    y = position[1] - text_height // 2
    draw.text((x, y), text, font=font, fill=color)

def wrap_text(text: str,
             font: Union[ImageFont.FreeTypeFont, ImageFont.ImageFont],
             max_width: int) -> str:
    """Wrap text to fit within max_width.

    Args:
        text: Text to wrap
        font: Font to use
        max_width: Maximum width in pixels

    Returns:
        Wrapped text
    """
    lines = []
    words = text.split()
    current_line = ""
    for word in words:
        test_line = current_line + " " + word if current_line else word
        bbox = font.getbbox(test_line)
        if bbox[2] - bbox[0] <= max_width:
            current_line = test_line
        else:
            if current_line:
                lines.append(current_line)
            current_line = word
    if current_line:
        lines.append(current_line)
    return "\n".join(lines)

def fit_text_to_width(text: str,
                     font: Union[ImageFont.FreeTypeFont, ImageFont.ImageFont],
                     max_width: int,
                     max_length: int = 50) -> str:
    """Fit text to width by truncating if necessary.

    Args:
        text: Original text
        font: Font to use
        max_width: Maximum width in pixels
        max_length: Maximum character length

    Returns:
        Fitted text
    """
    if len(text) > max_length:
        text = text[:max_length - 3] + "..."

    bbox = font.getbbox(text)
    if bbox[2] - bbox[0] <= max_width:
        return text

    # Truncate until it fits
    while len(text) > 3 and font.getbbox(text)[2] - font.getbbox(text)[0] > max_width:
        text = text[:-1]

    return text[:-3] + "..." if len(text) > 3 else text