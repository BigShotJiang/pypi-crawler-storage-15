"""
Enhanced image utilities for Musicard
"""

import requests
from PIL import Image, ImageDraw, ImageFilter, ImageEnhance
from typing import Tuple, Optional, Union
import io
import math

def load_image(path_or_url: Union[str, bytes]) -> Image.Image:
    """Load an image from a local path, URL, or bytes.

    Args:
        path_or_url: Image path, URL, or bytes

    Returns:
        PIL Image object
    """
    if isinstance(path_or_url, bytes):
        return Image.open(io.BytesIO(path_or_url))
    elif isinstance(path_or_url, str):
        if path_or_url.startswith('http://') or path_or_url.startswith('https://'):
            response = requests.get(path_or_url, timeout=10)
            response.raise_for_status()
            return Image.open(io.BytesIO(response.content))
        else:
            return Image.open(path_or_url)
    else:
        raise ValueError("Invalid image source")

def resize_image(image: Image.Image, size: Tuple[int, int], maintain_aspect: bool = True) -> Image.Image:
    """Resize an image to the given size.

    Args:
        image: PIL Image
        size: Target size (width, height)
        maintain_aspect: Whether to maintain aspect ratio

    Returns:
        Resized PIL Image
    """
    if maintain_aspect:
        image.thumbnail(size, Image.Resampling.LANCZOS)
    else:
        image = image.resize(size, Image.Resampling.LANCZOS)
    return image

def create_gradient(size: Tuple[int, int],
                   start_color: Tuple[int, int, int],
                   end_color: Tuple[int, int, int],
                   direction: str = 'vertical') -> Image.Image:
    """Create a gradient image.

    Args:
        size: Image size (width, height)
        start_color: Starting RGB color
        end_color: Ending RGB color
        direction: 'vertical' or 'horizontal'

    Returns:
        Gradient PIL Image
    """
    width, height = size
    gradient = Image.new('RGB', size)
    pixels = gradient.load()

    if direction == 'vertical':
        for y in range(height):
            r = int(start_color[0] + (end_color[0] - start_color[0]) * y / height)
            g = int(start_color[1] + (end_color[1] - start_color[1]) * y / height)
            b = int(start_color[2] + (end_color[2] - start_color[2]) * y / height)
            for x in range(width):
                pixels[x, y] = (r, g, b)
    elif direction == 'horizontal':
        for x in range(width):
            r = int(start_color[0] + (end_color[0] - start_color[0]) * x / width)
            g = int(start_color[1] + (end_color[1] - start_color[1]) * x / width)
            b = int(start_color[2] + (end_color[2] - start_color[2]) * x / width)
            for y in range(height):
                pixels[x, y] = (r, g, b)

    return gradient

def create_rounded_mask(size: Tuple[int, int], radius: int) -> Image.Image:
    """Create a rounded rectangle mask.

    Args:
        size: Mask size
        radius: Corner radius

    Returns:
        Mask image
    """
    mask = Image.new('L', size, 0)
    draw = ImageDraw.Draw(mask)
    draw.rounded_rectangle((0, 0, size[0], size[1]), radius=radius, fill=255)
    return mask

def apply_mask(image: Image.Image, mask: Image.Image) -> Image.Image:
    """Apply a mask to an image.

    Args:
        image: Source image
        mask: Mask image

    Returns:
        Masked image
    """
    if image.mode != 'RGBA':
        image = image.convert('RGBA')
    image.putalpha(mask)
    return image

def adjust_brightness(image: Image.Image, factor: float) -> Image.Image:
    """Adjust image brightness.

    Args:
        image: PIL Image
        factor: Brightness factor (0.0 = black, 1.0 = original, >1.0 = brighter)

    Returns:
        Adjusted image
    """
    enhancer = ImageEnhance.Brightness(image)
    return enhancer.enhance(factor)

def blur_image(image: Image.Image, radius: float = 5.0) -> Image.Image:
    """Apply Gaussian blur to an image.

    Args:
        image: PIL Image
        radius: Blur radius

    Returns:
        Blurred image
    """
    return image.filter(ImageFilter.GaussianBlur(radius))

def draw_rounded_rectangle(draw: ImageDraw.ImageDraw,
                          xy: Tuple[int, int, int, int],
                          radius: int,
                          fill=None,
                          outline=None,
                          width: int = 1) -> None:
    """Draw a rounded rectangle.

    Args:
        draw: ImageDraw object
        xy: Rectangle coordinates (x1, y1, x2, y2)
        radius: Corner radius
        fill: Fill color
        outline: Outline color
        width: Outline width
    """
    x1, y1, x2, y2 = xy
    draw.rectangle([x1 + radius, y1, x2 - radius, y2], fill=fill, outline=outline, width=width)
    draw.rectangle([x1, y1 + radius, x2, y2 - radius], fill=fill, outline=outline, width=width)
    draw.ellipse([x1, y1, x1 + 2*radius, y1 + 2*radius], fill=fill, outline=outline, width=width)
    draw.ellipse([x2 - 2*radius, y1, x2, y1 + 2*radius], fill=fill, outline=outline, width=width)
    draw.ellipse([x1, y2 - 2*radius, x1 + 2*radius, y2], fill=fill, outline=outline, width=width)
    draw.ellipse([x2 - 2*radius, y2 - 2*radius, x2, y2], fill=fill, outline=outline, width=width)

def hex_to_rgb(hex_color: str) -> Tuple[int, int, int]:
    """Convert hex color to RGB tuple.

    Args:
        hex_color: Hex color string (e.g., '#FF0000')

    Returns:
        RGB tuple
    """
    hex_color = hex_color.lstrip('#')
    return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))

def rgb_to_hex(rgb: Tuple[int, int, int]) -> str:
    """Convert RGB tuple to hex color.

    Args:
        rgb: RGB tuple

    Returns:
        Hex color string
    """
    return f"#{rgb[0]:02x}{rgb[1]:02x}{rgb[2]:02x}"