"""
Musicard core package
"""

from .musicard import Musicard

__all__ = ['Musicard']