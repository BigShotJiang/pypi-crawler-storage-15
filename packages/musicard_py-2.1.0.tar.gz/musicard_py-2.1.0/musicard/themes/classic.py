from .base_theme import BaseTheme
from ..utils.images import load_image, resize_image, draw_rounded_rectangle
from ..utils.text import load_font, draw_text_with_shadow
from PIL import Image, ImageDraw, ImageFilter
import math

class ClassicTheme(BaseTheme):
    def render(self, image: Image.Image, draw: ImageDraw.ImageDraw, metadata: dict):
        # metadata: title, artist, thumbnail, progress, colors, etc.
        title = metadata.get('title', 'Musicard')
        artist = metadata.get('artist', 'By Unburn')
        progress = metadata.get('progress', 0.0)
        thumbnail_url = metadata.get('thumbnail')
        background_color = metadata.get('background_color', '#070707')
        progress_color = metadata.get('progress_color', '#FF7A00')
        progress_bar_color = metadata.get('progress_bar_color', '#5F2D00')
        name_color = metadata.get('name_color', '#FF7A00')
        author_color = metadata.get('author_color', '#FFFFFF')

        # Truncate text
        if len(title) > 18:
            title = title[:18] + '...'
        if len(artist) > 18:
            artist = artist[:18] + '...'

        # Load thumbnail
        if thumbnail_url:
            try:
                thumb = load_image(thumbnail_url)
                thumb = resize_image(thumb, (320, 320))
                image.paste(thumb, (image.width - 350, 20))
            except:
                # Default music icon
                pass

        # Background
        draw.rectangle([(0, 0), (image.width, image.height)], fill=background_color)

        # Progress bar
        bar_width = 800
        bar_height = 20
        bar_x = 50
        bar_y = image.height - 50
        # Background bar with rounded corners
        draw_rounded_rectangle(draw, (bar_x, bar_y, bar_x + bar_width, bar_y + bar_height), radius=10, fill=progress_bar_color)
        # Progress fill
        progress_width = int(bar_width * progress)
        if progress_width > 0:
            draw_rounded_rectangle(draw, (bar_x, bar_y, bar_x + progress_width, bar_y + bar_height), radius=10, fill=progress_color)
        # Circle at progress end
        if progress > 0:
            circle_x = bar_x + progress_width - 15
            circle_y = bar_y - 10
            draw.ellipse([circle_x, circle_y, circle_x + 30, circle_y + 30], fill=progress_color, outline=background_color, width=3)

        # Title with shadow
        title_font = load_font('PlusJakartaSans-ExtraBold.ttf', 80)
        draw_text_with_shadow(draw, title, title_font, name_color, '#000000', (50, 100))

        # Artist with shadow
        artist_font = load_font('PlusJakartaSans-Regular.ttf', 60)
        draw_text_with_shadow(draw, artist, artist_font, author_color, '#000000', (50, 200))