#!/usr/bin/env python3
"""
Musicard CLI tool for generating music cards from JSON or command line arguments.
"""

import argparse
import json
import sys
from pathlib import Path
from typing import Dict, Any

from musicard import Musicard

def load_config(json_path: Path) -> Dict[str, Any]:
    """Load configuration from JSON file."""
    with open(json_path, 'r') as f:
        return json.load(f)

def main():
    parser = argparse.ArgumentParser(
        description="Generate music card images",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  musicard generate --title "Song Title" --artist "Artist" --theme classic --output card.png
  musicard generate --config song.json --output card.png
  musicard themes  # List available themes
        """
    )

    subparsers = parser.add_subparsers(dest='command', help='Commands')

    # Generate command
    generate_parser = subparsers.add_parser('generate', help='Generate a music card')
    generate_parser.add_argument('--title', '-t', help='Song title')
    generate_parser.add_argument('--artist', '-a', help='Artist name')
    generate_parser.add_argument('--thumbnail', help='Thumbnail URL or path')
    generate_parser.add_argument('--progress', '-p', type=float, default=0, help='Progress (0-100)')
    generate_parser.add_argument('--theme', default='classic', help='Theme name')
    generate_parser.add_argument('--config', '-c', type=Path, help='JSON config file')
    generate_parser.add_argument('--output', '-o', required=True, help='Output file path')
    generate_parser.add_argument('--format', choices=['png', 'jpg', 'jpeg', 'svg'], default='png', help='Output format')
    generate_parser.add_argument('--width', type=int, default=1200, help='Image width')
    generate_parser.add_argument('--height', type=int, default=400, help='Image height')

    # Theme-specific options
    generate_parser.add_argument('--background-color', help='Background color')
    generate_parser.add_argument('--progress-color', help='Progress bar color')
    generate_parser.add_argument('--name-color', help='Title color')
    generate_parser.add_argument('--author-color', help='Artist color')

    # Batch command
    batch_parser = subparsers.add_parser('batch', help='Generate multiple cards from JSON array')
    batch_parser.add_argument('--input', '-i', type=Path, required=True, help='JSON file with card configurations')
    batch_parser.add_argument('--output-dir', '-o', default='output', help='Output directory')
    batch_parser.add_argument('--format', choices=['png', 'jpg', 'jpeg'], default='png', help='Output format')

    # Themes command
    themes_parser = subparsers.add_parser('themes', help='List available themes')

    args = parser.parse_args()

    if args.command == 'themes':
        card = Musicard()
        themes = card.get_available_themes()
        print("Available themes:")
        for theme in themes:
            print(f"  - {theme}")
        return

    if args.command == 'generate':
        # Load config from file or arguments
        config = {}
        if args.config:
            config = load_config(args.config)

        # Override with command line args
        if args.title:
            config['title'] = args.title
        if args.artist:
            config['artist'] = args.artist
        if args.thumbnail:
            config['thumbnailImage'] = args.thumbnail
        if args.progress is not None:
            config['progress'] = args.progress
        if args.theme:
            config['theme'] = args.theme
        if args.background_color:
            config['backgroundColor'] = args.background_color
        if args.progress_color:
            config['progressColor'] = args.progress_color
        if args.name_color:
            config['nameColor'] = args.name_color
        if args.author_color:
            config['authorColor'] = args.author_color

        # Validate required fields
        if not config.get('title'):
            print("Error: Title is required", file=sys.stderr)
            sys.exit(1)
        if not config.get('artist'):
            print("Error: Artist is required", file=sys.stderr)
            sys.exit(1)

        try:
            # Generate card
            card = Musicard(args.width, args.height)
            image = card.generate_card(**config)

            if args.format == 'svg':
                card.export_svg(image, config, args.output)
                print(f"SVG music card saved to {args.output}")
            else:
                card.save(image, args.output)
                print(f"Music card saved to {args.output}")

        except Exception as e:
            print(f"Error generating card: {e}", file=sys.stderr)
            sys.exit(1)

    elif args.command == 'batch':
        try:
            # Load batch configurations
            configs = load_config(args.input)
            if not isinstance(configs, list):
                print("Error: Batch input must be a JSON array", file=sys.stderr)
                sys.exit(1)

            card = Musicard()
            images = card.batch_generate(configs, args.output_dir)
            print(f"Generated {len(images)} cards in {args.output_dir}")

        except Exception as e:
            print(f"Error in batch generation: {e}", file=sys.stderr)
            sys.exit(1)

    else:
        parser.print_help()

if __name__ == '__main__':
    main()