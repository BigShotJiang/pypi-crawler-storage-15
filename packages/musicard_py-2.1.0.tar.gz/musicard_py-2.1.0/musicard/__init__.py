from .core.musicard import Musicard
# from .card import MusicCard  # Keep for backward compatibility - disabled for now

__version__ = "2.0.0"
__all__ = ["Musicard"]