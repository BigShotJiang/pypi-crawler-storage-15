# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.1.0] - 2025-01-01

### Added
- **SVG Export Support**: Export music cards as SVG files using `export_svg()` method
- **Caching System**: Intelligent caching for images, fonts, and generated cards using diskcache
- **Batch Processing**: Generate multiple cards at once with `batch_generate()` and `async_batch_generate()`
- **Theme Presets**: Save and load theme configurations as JSON presets
- **Enhanced CLI**: Support for SVG export, batch processing, and multiple formats
- **Multiple Output Formats**: Support for PNG, JPEG, and SVG export
- **Cache Management**: View cache statistics and clear cache via CLI and API

### Changed
- Updated dependencies to include cairosvg and diskcache
- Improved error handling and validation
- Enhanced documentation with new features

### Fixed
- Import issues and package structure improvements
- Better type hints throughout the codebase

## [2.0.0] - 2024-12-01

### Added
- Complete rewrite with 100% feature parity to musicard NPM package
- All 5 themes: Classic, Classic Pro, Dynamic, Mini, Upcoming
- Async support for card generation
- CLI tool for command-line usage
- Comprehensive test suite
- Type hints throughout

### Changed
- New modular architecture with separate core, templates, and utils
- Improved API design with better method names
- Enhanced font management system

### Removed
- Old MusicCard class (replaced with Musicard)

## [1.1.0] - 2024-11-01

### Added
- Initial release of musicard-py
- Support for three themes: Classic, Modern, and Mini
- MusicCard class for generating beautiful music card images
- Progress bar visualization with customizable colors
- Thumbnail image support (URLs and local paths)
- Customizable colors, sizes, and theme-specific options
- Easy-to-use API for Discord bots and other applications
- Asynchronous generation method (currently synchronous)
- Export to PNG bytes or save to file
- Comprehensive test suite
- Example scripts and documentation

### Features
- 🎨 Multiple Themes: Classic (dark, elegant), Modern (gradient), Mini (compact)
- 🖼️ Image Support: Load thumbnails from URLs or local files
- 📊 Progress Bars: Visual progress indicators
- 🎯 Simple API: Class-based interface
- 🔧 Customizable: Colors, sizes, fonts
- 📦 Lightweight: Minimal dependencies (Pillow + requests)
- ⚡ Fast: Generate images in milliseconds

### Credits
- Inspired by [unburn/musicard](https://github.com/unburn/musicard) JavaScript project