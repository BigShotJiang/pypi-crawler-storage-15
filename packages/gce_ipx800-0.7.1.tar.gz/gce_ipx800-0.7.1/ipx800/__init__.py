"""Module to control the IPX800 V4 device from GCE Electronics."""

from ipx800.ipx800 import ApiError, IPX800 as ipx800  # noqa


__version__ = "0.7.1"
