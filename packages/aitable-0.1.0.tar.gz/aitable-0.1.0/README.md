# AITable

Summarize any CSV file using ACC AI, including predictions and stylized summaries.

## Usage

```python
from AITable import Analyze

response = Analyze("my_data.csv")
print(response)
