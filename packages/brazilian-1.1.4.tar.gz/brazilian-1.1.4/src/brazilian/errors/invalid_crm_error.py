class InvalidCRMError(ValueError):
    """Exceção lançada quando um CPF inválido é tratado em modo estrito."""
    pass