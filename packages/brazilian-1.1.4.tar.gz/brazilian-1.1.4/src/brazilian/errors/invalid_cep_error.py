class InvalidCEPError(ValueError):
    pass