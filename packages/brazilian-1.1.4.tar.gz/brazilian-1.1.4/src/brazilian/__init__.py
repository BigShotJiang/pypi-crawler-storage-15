from .documents import CPF, CEP, CNPJ, CRM

__all__ = ["CPF", "CEP", "CNPJ", "CRM"]