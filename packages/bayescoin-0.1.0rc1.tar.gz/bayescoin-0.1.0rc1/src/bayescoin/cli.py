def main() -> None:
    print("Hello from bayescoin!")
