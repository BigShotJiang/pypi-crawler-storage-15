__all__ = ["__version__"]

from importlib import metadata

__version__ = metadata.version(__name__)
