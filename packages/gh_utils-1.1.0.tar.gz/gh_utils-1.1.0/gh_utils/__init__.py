__version__ = "1.1.0"
__app_name__ = "gh-utils"


class NotFoundError(Exception):
    pass
