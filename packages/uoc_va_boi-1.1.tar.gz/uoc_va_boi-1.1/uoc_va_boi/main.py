def uoc(a):
    i = 1
    dap_an = list()
    while i <= a:
        if a % i == 0:
            dap_an.append(i)
        i += 1
    return set(dap_an)

def boi(a, so_luong):
    i = 0
    dap_an = list()
    if 0 == so_luong:
        raise ValueError('Number cannot be used 0 or 1')
    while i <= so_luong:
        dap_an.append(i * a)
        i += 1
    return set(dap_an)
def uoc_chung(a, b):
    a1 = uoc(a)
    b1 = uoc(b)
    dap_an = a1.intersection(b1)
    return dap_an
def uoc_chung_max(a,b):
    dap_an = uoc_chung(a,b)
    return max(dap_an)
def boi_chung(a, b, so_luong):
    a1 = boi(a, so_luong)
    b1 = boi(b, so_luong)
    dap_an = a1.intersection(b1)
    return dap_an
def boi_chung_min(a,b,so_luong):
    dap_an = boi_chung(a,b,so_luong)
    dap_an.discard(0)
    return min(dap_an)
