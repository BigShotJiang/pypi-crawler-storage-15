from setuptools import setup
from setuptools import find_packages
setup(
    name='uoc-va-boi',
    version=1.1,
    description='Tính ươc và bội',
    packages=find_packages(),
    author='Ai xem tên'
)