# Dùng uoc-va-boi #
### Cách đùng nó:
> Bước 1:
 - Cài đặt
 ```python
   pip install uoc-va-boi
```
> Bước 2:
 - Gọi module
 ```python
    import uoc-va-boi
 ```
 > Bươc 3:
  - Dùng
 ```python
    import uoc-va-boi
    # Tìm Ươc của 12
    print(uoc-va-boi.uoc(12))
    # Tìm Ươc chung của 12, 10
    print(uoc-va-boi.uoc_chung(12, 10))
    # Tìm Ươc chung lớn nhất của 12, 10
    print(uoc-va-boi.uoc_chung_max(12, 10))
    # Tìm Bội của 12, biết số lượng là 10
    print(uoc-va-boi.boi(12, 10))
    # Tìm Bội chung của 12, 10; biết số lượng là 10
    print(uoc-va-boi.boi_chung(12, 10, 10))
    # Tìm Ươc chung lớn nhất của 12, 10; biết số lượng là 10
    print(uoc-va-boi.uoc_chung_min(12, 10, 10))
 ```
 > Kết Quả
 ```python
{1, 2, 3, 4, 6, 12}
{1, 2}
2
{0, 96, 36, 72, 12, 108, 120, 48, 84, 24, 60}
{0, 60}
60
```
### Các cấu trúc:
|Tên hàm        |Cấu trúc           |Ý nghĩa            |
|---------------|-------------------|-------------------|
|```uoc```      |uoc(a)             |```a```: là số cần tìm ước|
|```uoc_chung```|uoc_chung(a, b)    |```a```,```b```: là số cần tìm ƯC(a,b)|
|```uoc_chung_max```|uoc_chung_max(a,b)|```a```,```b```: là số cần tìm ƯCLN(a,b)|
|```boi```|boi(a, so_luong)|```a```:là số cần tìm bội, ```so_luong```: là số lượng bao nhieu|
|```boi_chung```|boi_chung(a,b, so_luong)|```a```,```b```:là số cần tìm BC(a,b), ```so_luong```: là số lượng bao nhieu|
|```boi_chung_min```|boi_chung_min(a,b, so_luong)|```a```,```b```:là số cần tìm BCNN(a,b), ```so_luong```: là số lượng bao nhieu|