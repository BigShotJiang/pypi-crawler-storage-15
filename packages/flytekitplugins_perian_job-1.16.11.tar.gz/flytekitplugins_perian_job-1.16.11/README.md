# Flytekit Perian Job Platform Plugin

Flyte Connector plugin for executing Flyte tasks on Perian Job Platform (perian.io).

See the [official docs page](https://perian.io/docs/flyte-getting-started) for more details.
