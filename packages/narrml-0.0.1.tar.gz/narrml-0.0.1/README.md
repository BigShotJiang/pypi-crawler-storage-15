# NarrML

Narrative Markup Language - The open data format for visual narratives.

**Coming soon.** This is a placeholder package to reserve the name.

Visit [scenium.ai](https://scenium.ai) for more information.
