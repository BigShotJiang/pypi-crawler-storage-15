"""
aiida_amber

A plugin for using Amber with AiiDA for molecular dymanics simulations.
"""

__version__ = "2.0.3"
