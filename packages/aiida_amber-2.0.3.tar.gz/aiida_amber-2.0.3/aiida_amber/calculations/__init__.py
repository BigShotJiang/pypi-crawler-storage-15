"""
aiida_amber

A plugin for using Amber with AiiDA for molecular dymanics simulations.
"""