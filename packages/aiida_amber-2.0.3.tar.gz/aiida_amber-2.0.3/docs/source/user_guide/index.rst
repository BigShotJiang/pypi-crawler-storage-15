==========
User guide
==========

.. toctree::
    :maxdepth: 3

    installation
    aiida_sessions
    aiida_cheatsheet
