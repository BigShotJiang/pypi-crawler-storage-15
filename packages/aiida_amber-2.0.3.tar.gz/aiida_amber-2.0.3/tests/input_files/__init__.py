""" Tests for the plugin."""
import os

TEST_DIR = os.path.dirname(os.path.realpath(__file__))
