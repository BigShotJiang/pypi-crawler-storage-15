# booklet

a minimal & tiny ssg for blogs & articles.

### how to use

1. install it using `pip install bookletssg`
2. initialize a project with `booklet init`
3. write whatever you want in `articles/`
4. build your blog using `booklet build`
5. upload `dist/` to your web!

### licensed under [MIT license](LICENSE)