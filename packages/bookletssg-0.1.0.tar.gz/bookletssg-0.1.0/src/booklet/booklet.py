import os
import json
from pathlib import Path
import markdown

THEME = """
body {
    font-family: sans-serif;
    max-width: 700px;
    margin: auto;
    padding: 2rem;
}
a   { color: #08f; }
"""

TEMPLATE_ARTICLE = """
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>{theme}</style>
    <title>{title}</title>
</head>
<body>
    <a href="/">go back</a>
    <h1>{title}</h1>
    <p>{author}</p>
    {content}
</body>
</html>
"""

TEMPLATE_INDEX = """
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>{theme}</style>
    <title>{site}</title>
</head>
<body>
    <h1>{site}</h1>
    <p>{author}</p>
    <ul>
        {articles}
    </ul>
</body>
</html>
"""


def md(s):
    return markdown.markdown(s)


def init():
    name = input("name: ").strip()
    author = input("author: ").strip()
    os.makedirs("articles", exist_ok=True)
    os.makedirs("dist", exist_ok=True)
    json.dump({"name": name, "author": author}, open("booklet.json", "w"), indent=2)


def build():
    cfg = json.load(open("booklet.json"))
    dist = Path("dist")
    dist.mkdir(exist_ok=True)
    links = []

    for f in Path("articles").iterdir():
        if not f.is_file():
            continue

        title = f.stem
        content = md(f.read_text())

        html = TEMPLATE_ARTICLE.format(
            theme=THEME, title=title, author=cfg["author"], content=content
        )

        (dist / f"{title}.html").write_text(html)
        links.append(f'<li><a href="{title}.html">{title}</a></li>')

    index = TEMPLATE_INDEX.format(
        theme=THEME, site=cfg["name"], author=cfg["author"], articles="\n".join(links)
    )

    (dist / "index.html").write_text(index)


def main():
    import sys

    cmds = {"init": init, "build": build}
    cmds.get(sys.argv[1], lambda: print("init | build"))()


if __name__ == "__main__":
    main()
