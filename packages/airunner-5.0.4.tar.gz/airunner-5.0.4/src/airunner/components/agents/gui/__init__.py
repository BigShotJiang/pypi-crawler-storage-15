"""Agent GUI components."""

__all__ = []
