# Copyright (C) Rendeiro Group, CeMM Research Center for Molecular Medicine of the Austrian Academy of Sciences
# All rights reserved.
#
# This software is distributed under the terms of the GNU General Public License v3 (GPLv3).
# See the LICENSE file for details.

"""Build CUDA extension for stainx if CUDA is available."""

import contextlib
import os
import re
import subprocess
import sys
from pathlib import Path
from typing import ClassVar

import torch
import torch.utils.cpp_extension as torch_cpp_ext
from setuptools import find_packages, setup
from setuptools.command.install import install
from torch.utils.cpp_extension import BuildExtension, CUDAExtension


def get_version_from_pyproject():
    """Read version from pyproject.toml (single source of truth)."""
    project_root = Path(__file__).parent
    pyproject_path = project_root / "pyproject.toml"
    with open(pyproject_path) as f:
        for line in f:
            if line.strip().startswith("version ="):
                match = re.search(r'version\s*=\s*["\']([^"\']+)["\']', line)
                if match:
                    return match.group(1)
    raise RuntimeError("Could not find version in pyproject.toml")


class CUDADeviceInfo:
    """Handles CUDA device detection and information retrieval."""

    def __init__(self):
        self.cuda_available = torch.cuda.is_available()
        if not self.cuda_available:
            print("CUDA device not available at build time. Will build for architectures specified in TORCH_CUDA_ARCH_LIST or common architectures.")
            self.device = None
            self.device_name = None
            self.device_capability = None
            # Use a default architecture for define_macros (actual archs come from TORCH_CUDA_ARCH_LIST)
            self.compute_capability = 75  # Default fallback
            return

        self.device = torch.cuda.current_device()
        self.device_name = torch.cuda.get_device_name(self.device)
        self.device_capability = torch.cuda.get_device_capability(self.device)
        self.compute_capability = self._detect_compute_capability()

    def _detect_compute_capability(self):
        """Detect compute capability from current device."""
        major, minor = torch.cuda.get_device_capability(self.device)
        return major * 10 + minor

    def print_info(self):
        """Print device information."""
        if self.cuda_available:
            print("Building CUDA extension...")
            print(f"Current device: {self.device_name}")
            print(f"Current CUDA capability: {self.device_capability}")
            print(f"Detected compute capability: {self.compute_capability}")
        else:
            print("Building CUDA extension (CUDA device not available at build time)...")
            if "TORCH_CUDA_ARCH_LIST" in os.environ:
                print(f"Using TORCH_CUDA_ARCH_LIST: {os.environ['TORCH_CUDA_ARCH_LIST']}")


class PyTorchVersionChecker:
    """Handles PyTorch version checking and validation."""

    MIN_MAJOR = 2
    MIN_MINOR = 0

    def __init__(self):
        self.version = torch.__version__
        self.major, self.minor = self._parse_version()

    def _parse_version(self):
        """Parse PyTorch version string."""
        m = re.match(r"^(\d+)\.(\d+)", self.version)
        if not m:
            raise RuntimeError(f"Cannot parse PyTorch version '{self.version}'")
        return tuple(map(int, m.groups()))

    def check(self):
        """Check if PyTorch version meets requirements."""
        print(f"PyTorch version: {self.version}")
        if self.major < self.MIN_MAJOR or (self.major == self.MIN_MAJOR and self.minor < self.MIN_MINOR):
            print(f"Warning: PyTorch version {self.version} may not be fully supported. Recommended: >= {self.MIN_MAJOR}.{self.MIN_MINOR}")


class NVCCFlagsManager:
    """Manages NVCC compilation flags."""

    UNWANTED_FLAGS: ClassVar[list[str]] = ["-D__CUDA_NO_HALF_OPERATORS__", "-D__CUDA_NO_HALF_CONVERSIONS__", "-D__CUDA_NO_BFLOAT16_CONVERSIONS__", "-D__CUDA_NO_HALF2_OPERATORS__"]

    BASE_FLAGS: ClassVar[list[str]] = ["--expt-relaxed-constexpr", "--use_fast_math", "-std=c++17", "-O3", "-DNDEBUG", "-Xcompiler", "-funroll-loops", "-Xcompiler", "-ffast-math", "-Xcompiler", "-finline-functions"]

    def __init__(self):
        self._remove_unwanted_flags()

    def _remove_unwanted_flags(self):
        """Remove unwanted PyTorch NVCC flags."""
        for flag in self.UNWANTED_FLAGS:
            with contextlib.suppress(ValueError):
                torch_cpp_ext.COMMON_NVCC_FLAGS.remove(flag)

    def get_architecture_flags(self, compute_capability):
        """Generate architecture-specific flags for the given compute capability."""
        flags = self.BASE_FLAGS.copy()

        # Format: compute_XX and sm_XX
        major = compute_capability // 10
        minor = compute_capability % 10
        compute_arch = f"compute_{major}{minor}"
        sm_arch = f"sm_{major}{minor}"

        flags.extend(["-gencode", f"arch={compute_arch},code={sm_arch}"])
        return flags


class CUDAExtensionBuilder:
    """Builds and configures the CUDA extension."""

    def __init__(self, project_root: Path):
        self.project_root = project_root
        self.csrc_dir = project_root / "src" / "stainx_cuda" / "csrc"
        self.device_info = CUDADeviceInfo()
        self.version_checker = PyTorchVersionChecker()
        self.flags_manager = NVCCFlagsManager()

    def build(self):
        """Build the CUDA extension configuration."""
        print("=" * 80)
        print("DEBUG: CUDAExtensionBuilder.build() called")
        print(f"DEBUG: torch.cuda.is_available() = {torch.cuda.is_available()}")
        print(f"DEBUG: CUDA_HOME = {os.environ.get('CUDA_HOME', 'NOT SET')}")
        print(f"DEBUG: CUDA_PATH = {os.environ.get('CUDA_PATH', 'NOT SET')}")

        # Always try to build CUDA extension
        # Check if PyTorch was built with CUDA support
        if not torch.cuda.is_available():
            print("DEBUG: CUDA not available in PyTorch. Returning empty list.")
            print("=" * 80)
            return []

        # Print device and version info
        self.device_info.print_info()
        self.version_checker.check()

        # Get architecture flags
        nvcc_flags = self.flags_manager.get_architecture_flags(self.device_info.compute_capability)
        print(f"DEBUG: nvcc_flags = {nvcc_flags}")

        # Define source files - use relative paths from setup.py directory
        source_files = ["bindings.cpp", "histogram_matching.cu", "reinhard.cu", "macenko.cu"]
        sources = [str(Path("src") / "stainx_cuda" / "csrc" / f) for f in source_files]
        print(f"DEBUG: source files = {sources}")

        # Check if source files exist
        for src in sources:
            exists = os.path.exists(src)
            print(f"DEBUG: {src} exists = {exists}")

        # Include directory - use relative path
        include_dir = str(Path("src") / "stainx_cuda" / "csrc")
        print(f"DEBUG: include_dir = {include_dir}")

        # Create extension - PyTorch's CUDAExtension should handle CUDA detection
        # Use "stainx_cuda.stainx_cuda" as the name
        # This creates a module that can be imported as "from stainx_cuda import stainx_cuda"
        print("DEBUG: Attempting to create CUDAExtension...")
        try:
            extension = CUDAExtension(
                name="stainx_cuda.stainx_cuda", sources=sources, include_dirs=[include_dir], define_macros=[("TARGET_CUDA_ARCH", str(self.device_info.compute_capability))], extra_compile_args={"cxx": ["-std=c++17", "-O3", "-DNDEBUG"], "nvcc": nvcc_flags}, extra_link_args=["-lcudart", "-lcublas", "-lcusolver"]
            )
            print("DEBUG: CUDAExtension created successfully!")
            print(f"DEBUG: Returning extension: {extension}")
            print("=" * 80)
            return [extension]
        except (OSError, RuntimeError) as e:
            print(f"DEBUG: Error creating CUDAExtension: {type(e).__name__}: {e}")
            if "CUDA_HOME" in str(e):
                print("DEBUG: CUDA_HOME error detected. Returning empty list.")
                print("=" * 80)
                return []
            print("DEBUG: Re-raising exception...")
            print("=" * 80)
            raise

    def get_build_ext_class(self):
        """Get the build extension class with ninja support."""
        use_ninja = os.environ.get("USE_NINJA", "true").lower() == "true"
        return BuildExtension.with_options(use_ninja=use_ninja)


class PostInstallCommand(install):
    """Post-installation hook to build CUDA extension after wheel installation."""

    def run(self):
        """Run the standard install, then build CUDA extension."""
        # Run the standard install
        install.run(self)

        # Build CUDA extension after installation
        print("\n" + "=" * 80)
        print("Building CUDA extension (if CUDA is available)...")
        print("=" * 80)

        # Check if CUDA is available
        if not torch.cuda.is_available():
            print("CUDA not available. Skipping CUDA extension build.")
            print("=" * 80)
            return

        # Find the installed stainx_cuda package location
        try:
            import stainx_cuda

            package_dir = Path(stainx_cuda.__file__).parent
            print(f"DEBUG: Found stainx_cuda at: {package_dir}")
        except (ImportError, AttributeError):
            print("Warning: Could not find installed stainx_cuda package.")
            print("=" * 80)
            return

        # Check if source files are available
        csrc_dir = package_dir / "csrc"
        if not csrc_dir.exists():
            print(f"Warning: CUDA source files not found at {csrc_dir}")
            print("CUDA extension cannot be built from wheel. Install from source to build CUDA extension.")
            print("=" * 80)
            return

        # Build the extension in-place in the installed location
        try:
            original_cwd = os.getcwd()
            project_root = Path(__file__).parent
            os.chdir(project_root)

            print(f"DEBUG: Building extension from: {project_root}")
            print(f"DEBUG: Source files location: {csrc_dir}")

            # Use setup.py build_ext --inplace
            result = subprocess.run([sys.executable, str(project_root / "setup.py"), "build_ext", "--inplace"], capture_output=True, text=True, cwd=str(project_root))

            if result.returncode == 0:
                print("✓ CUDA extension built successfully!")
                if result.stdout:
                    print(result.stdout)
            else:
                print("⚠ CUDA extension build failed:")
                if result.stdout:
                    print("STDOUT:", result.stdout)
                if result.stderr:
                    print("STDERR:", result.stderr)
                print("\nYou can still use the PyTorch backend.")

            os.chdir(original_cwd)
        except Exception as e:
            print(f"⚠ Error building CUDA extension: {e}")
            print("You can still use the PyTorch backend.")
            if os.environ.get("STAINX_DEBUG_BUILD"):
                import traceback

                traceback.print_exc()

        print("=" * 80)


# Automatically detect and set CUDA architectures
if "TORCH_CUDA_ARCH_LIST" not in os.environ:
    if torch.cuda.is_available():
        from torch import cuda

        arch_list = []
        for i in range(cuda.device_count()):
            capability = cuda.get_device_capability(i)
            arch = f"{capability[0]}.{capability[1]}"
            arch_list.append(arch)

        # Add PTX for the highest architecture for forward compatibility
        if arch_list:
            highest_arch = arch_list[-1]
            arch_list.append(f"{highest_arch}+PTX")

        os.environ["TORCH_CUDA_ARCH_LIST"] = ";".join(arch_list)
        print(f"Setting TORCH_CUDA_ARCH_LIST={os.environ['TORCH_CUDA_ARCH_LIST']}")
    else:
        # CUDA device not available, use common architectures for broader compatibility
        # These cover most modern GPUs (Volta, Turing, Ampere, Ada, Hopper)
        common_archs = ["7.0", "7.5", "8.0", "8.6", "8.9", "9.0"]
        # Add PTX for forward compatibility
        common_archs.append("9.0+PTX")
        os.environ["TORCH_CUDA_ARCH_LIST"] = ";".join(common_archs)
        print(f"CUDA device not available. Setting TORCH_CUDA_ARCH_LIST={os.environ['TORCH_CUDA_ARCH_LIST']}")

# Set PyTorch library path for runtime linking
torch_lib_path = os.path.join(os.path.dirname(torch.__file__), "lib")
if "LD_LIBRARY_PATH" not in os.environ:
    os.environ["LD_LIBRARY_PATH"] = torch_lib_path
else:
    os.environ["LD_LIBRARY_PATH"] = f"{torch_lib_path}:{os.environ['LD_LIBRARY_PATH']}"

# Main setup execution
print("=" * 80)
print("DEBUG: setup.py execution started")
print(f"DEBUG: __file__ = {__file__}")
print(f"DEBUG: Current working directory = {os.getcwd()}")

project_root = Path(__file__).parent
print(f"DEBUG: project_root = {project_root}")

builder = CUDAExtensionBuilder(project_root)
print("DEBUG: CUDAExtensionBuilder created")

extensions = builder.build()
print(f"DEBUG: builder.build() returned: {extensions}")
print(f"DEBUG: len(extensions) = {len(extensions) if extensions else 0}")

build_ext = builder.get_build_ext_class()
print(f"DEBUG: build_ext class = {build_ext}")
print("=" * 80)

# Package discovery - use find_packages to automatically discover all packages and subpackages
packages = find_packages(where="src")
# Ensure stainx_cuda is included even if it doesn't have __init__.py with Python code
if "stainx_cuda" not in packages:
    packages.append("stainx_cuda")

with open("README.md") as f:
    long_description = f.read()

setup_kwargs = {
    "packages": packages,
    "package_dir": {"": "src"},
    "zip_safe": False,
    "version": get_version_from_pyproject(),
    "description": "GPU-accelerated stain normalization",
    "author": "Samir Moustafa",
    "author_email": "smoustafa@cemm.oeaw.ac.at",
    "url": "https://github.com/rendeirolab/stainx",
    "long_description": long_description,
    "long_description_content_type": "text/markdown",
    "classifiers": ["Environment :: GPU :: NVIDIA CUDA", "Intended Audience :: Developers", "Intended Audience :: Healthcare Industry", "Intended Audience :: Science/Research", "Programming Language :: Python :: 3", "Topic :: Scientific/Engineering", "Topic :: Software Development"],
}

# Always include extension
# This ensures it's built during wheel creation and pip install from source
print("=" * 80)
print("DEBUG: Setting up ext_modules and cmdclass")
print(f"DEBUG: extensions = {extensions}")
print(f"DEBUG: extensions type = {type(extensions)}")
print(f"DEBUG: extensions is not None = {extensions is not None}")
print(f"DEBUG: extensions is truthy = {bool(extensions)}")

if extensions:
    setup_kwargs["ext_modules"] = extensions
    setup_kwargs["cmdclass"] = {"build_ext": build_ext, "install": PostInstallCommand}
    print(f"DEBUG: Added ext_modules with {len(extensions)} extension(s)")
    print("DEBUG: Added cmdclass with build_ext and PostInstallCommand")
else:
    print("DEBUG: No extensions to add (extensions is empty or None)")
    print("DEBUG: setup_kwargs will not include ext_modules")
    # Still add post-install hook to try building if CUDA becomes available
    setup_kwargs["cmdclass"] = {"install": PostInstallCommand}

print("DEBUG: Calling setup()...")
print("=" * 80)
setup(**setup_kwargs)
print("=" * 80)
print("DEBUG: setup() completed")
print("=" * 80)
