# CSET Workflow

A [cylc workflow](https://cylc.github.io/) for running
[CSET](https://github.com/MetOffice/CSET). The workflow's documentation can be
found at [metoffice.github.io/CSET](https://metoffice.github.io/CSET).
