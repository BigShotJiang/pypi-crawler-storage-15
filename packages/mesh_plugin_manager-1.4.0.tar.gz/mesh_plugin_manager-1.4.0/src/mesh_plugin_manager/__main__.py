"""Entry point for python -m mesh_plugin_manager."""

from mesh_plugin_manager.cli import main

if __name__ == "__main__":
    main()

