"""MCP Server for Exercises By Api Ninjas"""
