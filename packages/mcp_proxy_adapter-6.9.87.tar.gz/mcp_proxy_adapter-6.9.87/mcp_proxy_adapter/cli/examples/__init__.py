"""
CLI Examples Module

This module contains example scripts demonstrating CLI usage.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""
