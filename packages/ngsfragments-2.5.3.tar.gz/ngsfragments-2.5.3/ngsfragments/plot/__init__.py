"""Init for mylibrary."""
from .plot_plt import *
from .plot_bokeh import *