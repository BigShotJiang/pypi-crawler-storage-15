"""Init for mylibrary."""
from .coverage import *
from .wps import *
from .midpoint import *