"""Init for mylibrary."""
from .parse_sam.ReadSam import *
from .read_sam import *
from .read_fragments import *