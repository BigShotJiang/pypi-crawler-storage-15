# pysam versioning information
__version__ = "2.0.8"

# htslib versioning information
__htslib_version__ = "1.18"