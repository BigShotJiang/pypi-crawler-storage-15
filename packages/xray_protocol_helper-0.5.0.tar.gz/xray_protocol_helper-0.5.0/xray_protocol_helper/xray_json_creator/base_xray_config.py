BASE_XRAY_CONFIG = {
    "stats": {},
    "log": {"loglevel": "warning"},
    "policy": {
        "levels": {"8": {"handshake": 4, "connIdle": 300, "uplinkOnly": 1, "downlinkOnly": 1}},
        "system": {"statsOutboundUplink": True, "statsOutboundDownlink": True}
    },
    "inbounds": [
        {"tag": "socks", "port": 10808, "protocol": "socks",
         "settings": {"auth": "noauth", "udp": True, "userLevel": 8},
         "sniffing": {"enabled": True, "destOverride": ["http", "tls"]}},
        {"tag": "http", "port": 10809, "protocol": "http", "settings": {"userLevel": 8}}
    ],
    "outbounds": [
        {"tag": "proxy", "protocol": "vmess", "settings": {"vnext": [{"address": "v2ray.cool", "port": 10086, "users": [
            {"id": "a3482e88-686a-4a58-8126-99c9df64b7bf", "alterId": 0, "security": "auto", "level": 8}]}],
                                                           "servers": [{"address": "v2ray.cool", "method": "chacha20",
                                                                        "ota": False, "password": "123456",
                                                                        "port": 10086, "level": 8}]},
         "streamSettings": {"network": "tcp"}, "mux": {"enabled": False}},
        {"protocol": "freedom", "settings": {}, "tag": "direct"},
        {"protocol": "blackhole", "tag": "block", "settings": {"response": {"type": "http"}}}
    ],
    "routing": {"domainStrategy": "IPIfNonMatch", "rules": []},
    "dns": {"hosts": {}, "servers": []}
}
