"""
Library Analytics - A Python package for library management analytics
"""

__version__ = "0.1.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

from .analytics import LibraryAnalytics

__all__ = ['LibraryAnalytics']
