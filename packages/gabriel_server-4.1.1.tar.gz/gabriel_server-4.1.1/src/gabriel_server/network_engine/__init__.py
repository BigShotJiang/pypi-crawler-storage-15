"""Network engine module for Gabriel server."""

HEARTBEAT = b""
