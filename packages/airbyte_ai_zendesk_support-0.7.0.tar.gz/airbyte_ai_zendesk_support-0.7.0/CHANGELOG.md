# Changelog

## [0.7.0] - 2025-12-03
- Updated connector definition (YAML version 1.0.0)
- Source commit: 0ce38253
- SDK version: 0.1.0

## [0.6.0] - 2025-12-02
- Updated connector definition (YAML version 1.0.0)
- Source commit: c8e326d9
- SDK version: 0.1.0

## [0.5.0] - 2025-12-02
- Updated connector definition (YAML version 1.0.0)
- Source commit: ad0b961b
- SDK version: 0.1.0

## [0.4.0] - 2025-12-02
- Updated connector definition (YAML version 1.0.0)
- Source commit: 7153780a
- SDK version: 0.1.0

## [0.3.0] - 2025-12-02
- Updated connector definition (YAML version 1.0.0)
- Source commit: 01f71cad
- SDK version: 0.1.0

## [0.2.0] - 2025-12-02
- Updated connector definition (YAML version 1.0.0)
- Source commit: 4c17f060
- SDK version: 0.1.0

## [0.1.0] - 2025-12-02
- Updated connector definition (YAML version 1.0.0)
- Source commit: cd499acd
- SDK version: 0.1.0
