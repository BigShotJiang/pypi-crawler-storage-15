"""
core module for Conscious Bridge Law
"""
__version__ = "1.0.0"
