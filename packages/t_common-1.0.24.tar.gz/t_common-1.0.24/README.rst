===========================
Thoughtful common packages
===========================


.. image:: https://img.shields.io/pypi/v/t_common.svg
        :target: https://pypi.python.org/pypi/t-common

|

It contains most usable and important libs

|

Installation
------------

::

   python3 -m virtualenv venv
   source venv/bin/activate
   pip install t-common

|

Using Packages
--------------

::

    uv==0.8.6
    rpaframework==31.0.0
    tenacity==8.3.0
    ta-bitwarden-cli==0.14.0
    thoughtful>=2.2,<3.0
    python-docx==0.8.11
    retry==0.9.2
    pandas==2.1.3
    pillow==10.3.0
    Office365-REST-Python-Client==2.5.2
    setuptools>=65.5.1
    google-api-core==2.20.0
    google-api-python-client==2.122.0
    google-auth==2.28.2
    google-auth-httplib2==0.2.0
    google-auth-oauthlib==1.2.0
    ta-sites==0.5.4
    openpyxl==3.0.10
    numpy==1.26.1
    bugsnag==4.7.1
    t_bug_catcher==0.6.*
    ta-captcha-solver==0.3.7
    t-vault-manager==1.0.3
    cryptography==44.0.1


