The Descartes Labs Platform API and client has been discontinued and is no longer functional.

Please see [The EarthDaily EarthOne Platform Client](https:github.com/earthdaily/earthone-python) for the currently supported API and Client.
