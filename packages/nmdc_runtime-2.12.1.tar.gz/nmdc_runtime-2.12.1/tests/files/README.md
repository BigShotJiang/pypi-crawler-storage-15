# `tests/files`

This directory contains files used by the test suite.

The following files were moved from `metadata-translation/notebooks/data/` as part of an effort to retire the top-level `metadata-translation/` directory in July, 2025 (via commit `dfd86ade`):

- `changesheet-array-item-nested-attributes.tsv`
- `changesheet-update-pi-websites.tsv`
- `changesheet-without-separator3.tsv`
- `study-data1.json`
- `study-data2.json`
- `study-data3.json`

The following files were moved from `metadata-translation/examples` as part of that same effort (via commit `dfd86ade`), and then subsequently deleted altogether as part of a related effort—also in July, 2025 (via commit `c31199f0`)

- `study_test.json`

