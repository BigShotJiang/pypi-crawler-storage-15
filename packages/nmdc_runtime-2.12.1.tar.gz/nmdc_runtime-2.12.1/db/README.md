# Database

This directory contains files related to the MongoDB database managed by the Runtime.

It has the following subdirectories:

- `./migrations`: files related to migrating the MongoDB database
