rs.initiate()
