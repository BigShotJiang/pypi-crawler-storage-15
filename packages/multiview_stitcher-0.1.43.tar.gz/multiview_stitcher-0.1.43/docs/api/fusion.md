::: multiview_stitcher.fusion
    options:
      members:
        - fuse
