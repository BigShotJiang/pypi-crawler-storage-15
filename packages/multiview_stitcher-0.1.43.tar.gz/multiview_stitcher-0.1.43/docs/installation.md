# Installation

You can install `multiview-stitcher` via pip:

    pip install multiview-stitcher

To install latest development version:

    pip install git+https://github.com/multiview-stitcher/multiview-stitcher.git
