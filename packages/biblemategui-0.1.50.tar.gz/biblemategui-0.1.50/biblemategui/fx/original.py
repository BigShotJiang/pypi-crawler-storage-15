from nicegui import ui

def luW(event):
    # whatever we sent from the browser is available as event.args
    payload = event.args
    #print(type(payload))
    #print('Server received payload:', payload)
    #ui.notify(f"Server got: {payload}")
def bdbid(event):
    # whatever we sent from the browser is available as event.args
    payload = event.args
    #print(type(payload))
    #print('Server received payload:', payload)
    #ui.notify(f"Server got: {payload}")
def etcbcmorph(event):
    # whatever we sent from the browser is available as event.args
    payload = event.args
    #print(type(payload))
    #print('Server received payload:', payload)
    #ui.notify(f"Server got: {payload}")
def rmac(event):
    # whatever we sent from the browser is available as event.args
    payload = event.args
    #print(type(payload))
    #print('Server received payload:', payload)
    #ui.notify(f"Server got: {payload}")
def searchWord(event):
    # whatever we sent from the browser is available as event.args
    payload = event.args
    #print(type(payload))
    #print('Server received payload:', payload)
    #ui.notify(f"Server got: {payload}")
def searchLexicalEntry(event):
    # whatever we sent from the browser is available as event.args
    payload = event.args
    #print(type(payload))
    #print('Server received payload:', payload)
    #ui.notify(f"Server got: {payload}")