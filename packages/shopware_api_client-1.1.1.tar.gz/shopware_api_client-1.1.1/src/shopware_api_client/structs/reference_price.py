from shopware_api_client.structs.reference_price_definition import ReferencePriceDefinition


class ReferencePrice(ReferencePriceDefinition):
    price: float
