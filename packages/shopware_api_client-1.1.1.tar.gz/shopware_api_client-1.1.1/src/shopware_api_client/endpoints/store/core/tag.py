from shopware_api_client.models.tag import TagBase


class Tag(TagBase):
    pass
