from shopware_api_client.models.product_review import ProductReviewBase


class ProductReview(ProductReviewBase):
    pass
