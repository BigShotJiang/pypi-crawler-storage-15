from shopware_api_client.models.rule import RuleBase


class Rule(RuleBase):
    pass
