from shopware_api_client.models.locale import LocaleBase


class Locale(LocaleBase):
    pass
