from shopware_api_client.models.unit import UnitBase


class Unit(UnitBase):
    pass
