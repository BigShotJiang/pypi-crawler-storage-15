from shopware_api_client.models.customer_group import CustomerGroupBase


class CustomerGroup(CustomerGroupBase):
    pass
