from shopware_api_client.models.tax import TaxBase


class Tax(TaxBase):
    pass
