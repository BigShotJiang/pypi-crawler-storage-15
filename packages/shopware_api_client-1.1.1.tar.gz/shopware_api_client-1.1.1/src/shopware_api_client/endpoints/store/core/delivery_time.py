from shopware_api_client.models.delivery_time import DeliveryTimeBase


class DeliveryTime(DeliveryTimeBase):
    pass
