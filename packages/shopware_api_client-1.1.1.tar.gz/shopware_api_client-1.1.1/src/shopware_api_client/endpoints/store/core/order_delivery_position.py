from shopware_api_client.models.order_delivery_position import OrderDeliveryPositionBase


class OrderDeliveryPosition(OrderDeliveryPositionBase):
    pass
