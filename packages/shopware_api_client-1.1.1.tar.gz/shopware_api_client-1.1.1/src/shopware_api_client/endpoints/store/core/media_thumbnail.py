from shopware_api_client.models.media_thumbnail import MediaThumbnailBase


class MediaThumbnail(MediaThumbnailBase):
    pass
