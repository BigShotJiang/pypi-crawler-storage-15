from shopware_api_client.models.state_machine_state import StateMachineStateBase


class StateMachineState(StateMachineStateBase):
    pass
