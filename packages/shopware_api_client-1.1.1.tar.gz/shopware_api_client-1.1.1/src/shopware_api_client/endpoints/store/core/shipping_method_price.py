from shopware_api_client.models.shipping_method_price import ShippingMethodPriceBase


class ShippingMethodPrice(ShippingMethodPriceBase):
    pass
