from setuptools import setup, find_packages

setup(
    name="frextech_simulation",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[],
    author="Nkuranga",
    description="FrexTech's modular simulation engine",
)
