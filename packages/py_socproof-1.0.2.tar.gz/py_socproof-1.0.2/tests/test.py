import asyncio

from soc_proof import SocProofAPI

api = SocProofAPI(
    token="dd25aaf1327ecc04c20ab5ecba1ab139"
)


async def main():

    services = await api.load_services(language="ru")

    print(len(services))


asyncio.run(main())