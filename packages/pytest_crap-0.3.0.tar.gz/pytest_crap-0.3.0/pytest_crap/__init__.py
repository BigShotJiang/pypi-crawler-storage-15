"""pytest-crap plugin for calculating CRAP scores."""

from importlib.metadata import version

__version__ = version("pytest-crap")
