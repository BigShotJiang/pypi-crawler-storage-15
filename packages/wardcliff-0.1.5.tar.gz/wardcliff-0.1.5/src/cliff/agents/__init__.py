"""Agent implementations for Cliff."""
