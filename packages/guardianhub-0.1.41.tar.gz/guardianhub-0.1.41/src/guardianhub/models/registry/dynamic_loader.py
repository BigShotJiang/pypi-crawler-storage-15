from typing import Dict, Any, Type, Optional, List
from pydantic import BaseModel, create_model
from pydantic.fields import Field

_DYNAMIC_MODEL_CACHE: Dict[str, Type[BaseModel]] = {}

class DynamicModelBuilder:

    @staticmethod
    def load_from_schema(
        model_name: str,
        schema_json: Dict[str, Any]
    ) -> Type[BaseModel]:

        # 1: Cache
        if model_name in _DYNAMIC_MODEL_CACHE:
            return _DYNAMIC_MODEL_CACHE[model_name]

        # 2: Generate
        model = DynamicModelBuilder._create_model(model_name, schema_json)
        _DYNAMIC_MODEL_CACHE[model_name] = model
        return model

    @staticmethod
    def _create_model(
            model_name: str,
            schema: Dict[str, Any]
    ) -> Type[BaseModel]:
        properties = schema.get("properties", {})
        required_fields = schema.get("required", [])
        description = schema.get("description", "")

        model_fields = {}

        for field_name, field_schema in properties.items():
            field_type = DynamicModelBuilder._map_schema_to_type(field_schema)

            default_value = ...
            if field_name not in required_fields:
                default_value = field_schema.get("default", None)

            field_info = Field(
                default=default_value,
                description=field_schema.get("description", ""),
                title=field_schema.get("title", field_name),
                **{
                    k: v for k, v in field_schema.items()
                    if k not in ["type", "description", "title", "default"]
                }
            )
            model_fields[field_name] = (field_type, field_info)

        return create_model(
            model_name,
            __doc__=description,
            **model_fields
        )

    @staticmethod
    def _map_schema_to_type(schema: Dict[str, Any]):
        """Map JSON Schema types to Python."""
        t = schema.get("type")

        # If it has properties, it's an object
        if "properties" in schema:
            inner_model_name = schema.get("title", "NestedObject")
            return DynamicModelBuilder._create_model(inner_model_name, schema)

        # Primitive types
        if t == "string":
            return str
        if t == "number":
            return float
        if t == "integer":
            return int
        if t == "boolean":
            return bool

        # Array
        if t == "array":
            item_schema = schema.get("items", {})
            item_type = DynamicModelBuilder._map_schema_to_type(item_schema)
            return List[item_type]

        # Object
        if t == "object":
            inner_model_name = schema.get("title", "NestedObject")
            return DynamicModelBuilder._create_model(inner_model_name, schema)

        # Fallback
        return Any
