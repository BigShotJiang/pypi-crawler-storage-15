"""Formatters for converting tool outputs into human-friendly tables."""
