"""Core functionality for PhyTorch."""

from .result import FitResult

__all__ = ['FitResult']
