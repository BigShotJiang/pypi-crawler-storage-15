import { Step } from '../types';

export const STEPS_ORDER: Step[] = ['preparing', 'starting', 'done'];
