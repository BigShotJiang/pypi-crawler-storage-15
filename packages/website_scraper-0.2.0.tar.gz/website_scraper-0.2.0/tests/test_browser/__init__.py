"""Browser module tests."""

