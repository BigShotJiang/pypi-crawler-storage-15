"""Extractor module tests."""

