# Copyright (c) 2024, DeepLink. All rights reserved.
from torch import Tensor
from typing import Optional, Sequence, Union, Any, Tuple, Callable, Dict
