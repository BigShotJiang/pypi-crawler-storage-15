# Copyright (c) 2024, DeepLink. All rights reserved.
from dlinfer.utils.config import Config


config = Config(enable_graph_mode=False)
