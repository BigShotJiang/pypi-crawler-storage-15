# Copyright (c) 2024, DeepLink. All rights reserved.
import dlinfer.framework.transformers_ext
import dlinfer.framework.torch_npu_ext
from . import quants
from . import cudagraph
from . import device
