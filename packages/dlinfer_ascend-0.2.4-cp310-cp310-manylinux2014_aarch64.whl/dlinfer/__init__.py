# Copyright (c) 2024, DeepLink. All rights reserved.
import dlinfer.vendor as vendor

vendor.vendor_torch_init()
__version__ = "0.2.4"
