# CapInvest Technical Analysis Extension

This extension provides Technical Analysis  tools for the CapInvest Platform.

Features of the extension include various indicators and oscillators.

This extension works nicely with a companion `capinvest-charting` extension

 
 
