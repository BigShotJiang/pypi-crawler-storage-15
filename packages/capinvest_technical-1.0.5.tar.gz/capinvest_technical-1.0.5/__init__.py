"""CapInvest Technical Analysis Extension."""
