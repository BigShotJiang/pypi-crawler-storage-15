"""
cl-sii Python lib
=================

"""

__version__ = '0.66.0'
