# Release History

## 1.0.0b1 (2025-12-03)

### Other Changes

- Initial version