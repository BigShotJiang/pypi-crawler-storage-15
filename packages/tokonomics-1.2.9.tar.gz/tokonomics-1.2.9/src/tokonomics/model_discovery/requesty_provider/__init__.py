"""Requesty model info Provider."""

from tokonomics.model_discovery.requesty_provider.provider import RequestyProvider

__all__ = ["RequestyProvider"]
