"""Cohere model info Provider."""

from tokonomics.model_discovery.cohere_provider.provider import CohereProvider

__all__ = ["CohereProvider"]
