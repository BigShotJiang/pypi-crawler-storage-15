import vedo

vedo.settings.default_backend = "vtk"
vedo.settings.use_depth_peeling = False
