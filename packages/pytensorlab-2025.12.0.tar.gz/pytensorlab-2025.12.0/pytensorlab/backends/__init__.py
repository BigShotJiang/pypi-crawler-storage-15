"""Basic support for array backends."""
