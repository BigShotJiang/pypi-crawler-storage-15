"""
Command-line interface for SudoDog.
"""

from .main import main

__all__ = ['main']
