class OpenhabEvent:
    pass
