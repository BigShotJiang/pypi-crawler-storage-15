"""Resources package - API resource clients"""

from mogu_sdk.resources.wiki import WikiClient

__all__ = ["WikiClient"]
