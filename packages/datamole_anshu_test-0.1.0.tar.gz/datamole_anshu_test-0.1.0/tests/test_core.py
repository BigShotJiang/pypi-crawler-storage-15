import datamole.core as core

def test_init():

    instance = core.DataMole()

    assert instance is not None

