from ._cli import main

__all__: list[str] = ["main"]
