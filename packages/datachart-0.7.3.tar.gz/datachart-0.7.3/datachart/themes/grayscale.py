from ..typings import StyleAttrs
from ..constants import (
    LINE_STYLE,
    FONT_STYLE,
    FONT_WEIGHT,
    LINE_DRAW_STYLE,
    COLORS,
    LEGEND_LOCATION,
)

GREYSCALE_THEME: StyleAttrs = {
    # general color style
    "color_general_singular": COLORS.Greys,
    "color_general_multiple": [
        "#2C3E50",  # dark slate
        "#5D6D7E",  # medium gray
        "#85929E",  # light gray
        "#ABB2B9",  # lighter gray
        "#D5DBDB",  # very light gray
        "#34495E",  # charcoal
    ],
    "color_parallel_hue": [
        "#2C3E50",  # dark slate
        "#5D6D7E",  # medium gray
        "#85929E",  # light gray
        "#ABB2B9",  # lighter gray
        "#D5DBDB",  # very light gray
        "#34495E",  # charcoal
    ],
    # general font style
    "font_general_family": "sans-serif",
    "font_general_sansserif": ["Helvetica", "Arial"],
    "font_general_color": "#000000",
    "font_general_size": 10,
    "font_general_style": FONT_STYLE.NORMAL,
    "font_general_weight": FONT_WEIGHT.NORMAL,
    # title size style
    "font_title_size": 14,
    "font_title_color": "#000000",
    "font_title_style": FONT_STYLE.NORMAL,
    "font_title_weight": FONT_WEIGHT.NORMAL,
    # subtitle size style
    "font_subtitle_size": 10,
    "font_subtitle_color": "#000000",
    "font_subtitle_style": FONT_STYLE.NORMAL,
    "font_subtitle_weight": FONT_WEIGHT.NORMAL,
    # xlabel size style
    "font_xlabel_size": 9,
    "font_xlabel_color": "#000000",
    "font_xlabel_style": FONT_STYLE.NORMAL,
    "font_xlabel_weight": FONT_WEIGHT.NORMAL,
    # ylabel size style
    "font_ylabel_size": 9,
    "font_ylabel_color": "#000000",
    "font_ylabel_style": FONT_STYLE.NORMAL,
    "font_ylabel_weight": FONT_WEIGHT.NORMAL,
    # plot axes style
    "axes_spines_top_visible": True,
    "axes_spines_right_visible": True,
    "axes_spines_bottom_visible": True,
    "axes_spines_left_visible": True,
    "axes_spines_width": 0.8,
    "axes_spines_zorder": 100,
    "axes_ticks_length": 3,
    "axes_ticks_label_size": 8,
    # plot legend style
    "plot_legend_shadow": False,
    "plot_legend_frameon": True,
    "plot_legend_alignment": "left",
    "plot_legend_location": LEGEND_LOCATION.BEST,
    "plot_legend_font_size": 8,
    "plot_legend_title_size": 9,
    "plot_legend_label_color": "#000000",
    # plot area style
    "plot_area_alpha": 0.25,
    "plot_area_color": None,
    "plot_area_linewidth": 0,
    "plot_area_hatch": None,
    "plot_area_zorder": 3,
    # plot grid style
    "plot_grid_alpha": 0.5,
    "plot_grid_color": "#D5DBDB",
    "plot_grid_linewidth": 0.5,
    "plot_grid_linestyle": LINE_STYLE.SOLID,
    "plot_grid_zorder": 0,
    # plot line style
    "plot_line_color": None,
    "plot_line_style": LINE_STYLE.SOLID,
    "plot_line_marker": None,
    "plot_line_width": 1.5,
    "plot_line_alpha": 1.0,
    "plot_line_drawstyle": LINE_DRAW_STYLE.DEFAULT,
    "plot_line_zorder": 3,
    # plot bar style
    "plot_bar_color": None,
    "plot_bar_alpha": 0.9,
    "plot_bar_width": 0.8,
    "plot_bar_zorder": 3,
    "plot_bar_hatch": None,
    "plot_bar_edge_width": 0.8,
    "plot_bar_edge_color": "#000000",
    "plot_bar_error_color": "#000000",
    "plot_bar_value_fontsize": 8,
    "plot_bar_value_color": "#000000",
    "plot_bar_value_padding": 3,
    # plot hist style
    "plot_hist_color": None,
    "plot_hist_alpha": 0.9,
    "plot_hist_zorder": 3,
    "plot_hist_fill": None,
    "plot_hist_hatch": None,
    "plot_hist_type": "bar",
    "plot_hist_align": "mid",
    "plot_hist_edge_width": 0.8,
    "plot_hist_edge_color": "#000000",
    # plot vline style
    "plot_vline_color": "#5D6D7E",
    "plot_vline_style": LINE_STYLE.DASHED,
    "plot_vline_width": 1,
    "plot_vline_alpha": 0.7,
    # plot hline style
    "plot_hline_color": "#5D6D7E",
    "plot_hline_style": LINE_STYLE.DASHED,
    "plot_hline_width": 1,
    "plot_hline_alpha": 0.7,
    # plot heatmap style
    "plot_heatmap_cmap": COLORS.Greys,
    "plot_heatmap_alpha": 0.95,
    "plot_heatmap_font_size": 8,
    "plot_heatmap_font_color": "#000000",
    "plot_heatmap_font_style": FONT_STYLE.NORMAL,
    "plot_heatmap_font_weight": FONT_WEIGHT.NORMAL,
    # plot scatter style
    "plot_scatter_color": None,
    "plot_scatter_alpha": 0.75,
    "plot_scatter_size": 36,
    "plot_scatter_marker": "o",
    "plot_scatter_zorder": 3,
    "plot_scatter_edge_width": 0.5,
    "plot_scatter_edge_color": "#FFFFFF",
    # plot regression style
    "plot_regression_color": "#34495E",
    "plot_regression_alpha": 0.9,
    "plot_regression_width": 2,
    "plot_regression_style": LINE_STYLE.SOLID,
    "plot_regression_ci_alpha": 0.15,
    # plot parallel coords style
    "plot_parallel_color": None,
    "plot_parallel_alpha": 0.6,
    "plot_parallel_width": 1.2,
    "plot_parallel_style": LINE_STYLE.SOLID,
    "plot_parallel_marker": None,
    "plot_parallel_zorder": 1,
    "plot_parallel_axis_color": "#000000",
    "plot_parallel_axis_width": 1.5,
    "plot_parallel_axis_zorder": 2,
    "plot_parallel_tick_color": "#000000",
    "plot_parallel_tick_width": 1.5,
    "plot_parallel_tick_length": 0.02,
    "plot_parallel_tick_label_size": 7,
    "plot_parallel_tick_label_color": "#000000",
    "plot_parallel_tick_label_bg_color": "#FFFFFF",
    "plot_parallel_tick_label_bg_alpha": 0.8,
    "plot_parallel_dim_label_size": 8,
    "plot_parallel_dim_label_color": "#000000",
    "plot_parallel_dim_label_rotation": 0,
    "plot_parallel_dim_label_pad": 8,
    # plot box style
    "plot_box_color": None,
    "plot_box_alpha": 0.85,
    "plot_box_linewidth": 0.8,
    "plot_box_edgecolor": "#000000",
    "plot_box_outlier_marker": "o",
    "plot_box_outlier_size": 5,
    "plot_box_outlier_color": "#FFFFFF",
    "plot_box_outlier_edge_color": "#000000",
    "plot_box_median_color": "#E74C3C",
    "plot_box_median_linewidth": 2,
    "plot_box_whisker_linewidth": 0.8,
    "plot_box_cap_linewidth": 0.8,
    "plot_xticks_label_rotate": None,
    "plot_yticks_label_rotate": None,
}
