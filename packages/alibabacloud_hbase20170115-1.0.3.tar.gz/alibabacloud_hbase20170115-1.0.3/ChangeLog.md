2025-12-03 Version: 1.0.2
- Generated python 2017-01-15 for HBase.

2025-03-12 Version: 1.0.1
- Update API DescribeSubscriptionInitializeProgress: add param RegionId.
- Update API DescribeSubscriptionPerformance: add param RegionId.
- Update API DescribeSubscriptionPermission: add param RegionId.
- Update API DescribeSubscriptions: add param RegionId.
- Update API ModifySubscriptionDescription: add param RegionId.
- Update API ModifySubscriptionMapping: add param RegionId.
- Update API ModifySubscriptionPermission: add param RegionId.
- Update API ReleaseSubscription: add param RegionId.


2024-05-06 Version: 1.0.0
- Generated python 2017-01-15 for HBase.

