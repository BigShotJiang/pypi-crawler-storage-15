"""CapInvest Crypto Price Router."""
