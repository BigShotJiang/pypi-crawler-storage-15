# Crypto data extension for CapInvest Platform

This extension provides a set of commands for crypto data retrieval.

 
 
