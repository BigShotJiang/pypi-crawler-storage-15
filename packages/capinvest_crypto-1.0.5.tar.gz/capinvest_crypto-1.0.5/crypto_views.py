"""Views for the crypto Extension."""

from typing import TYPE_CHECKING, Any, Dict, Tuple

if TYPE_CHECKING:
    from capinvest_charting.core.capinvest_figure import (
        CapInvestFigure,
    )


class CryptoViews:
    """Crypto Views."""

    @staticmethod
    def crypto_price_historical(  # noqa: PLR0912
        **kwargs,
    ) -> Tuple["CapInvestFigure", Dict[str, Any]]:
        """Crypto Price Historical Chart."""
        # pylint: disable=import-outside-toplevel
        from capinvest_charting.charts.price_historical import price_historical

        return price_historical(**kwargs)
