"""CapInvest Crypto Extension."""
