"""Provides a command line interface to the calibration program."""
from sonarcal import controller

controller.main()
