import{H as i}from"./index.CaTUZe6Y.js";var n=0;function u(r){var t=++n;return i(r)+t}export{u};
