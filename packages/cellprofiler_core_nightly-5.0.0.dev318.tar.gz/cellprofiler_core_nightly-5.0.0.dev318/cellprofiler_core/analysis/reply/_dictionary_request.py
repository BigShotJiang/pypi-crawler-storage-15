from ...utilities.zmq.communicable.reply import Reply


class DictionaryRequest(Reply):
    pass
