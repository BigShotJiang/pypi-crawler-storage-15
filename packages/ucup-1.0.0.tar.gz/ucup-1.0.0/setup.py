#!/usr/bin/env python3
"""
UCUP Setup File
Enables editable installation for UCUP package
"""
from setuptools import setup

# Use pyproject.toml for all configuration
setup()
