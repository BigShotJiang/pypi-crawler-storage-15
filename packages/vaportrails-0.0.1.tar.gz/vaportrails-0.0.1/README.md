# vaportrails

Reserved namespace for the future **Vaportrails** developer flight recorder.

This package currently exists only to reserve the `vaportrails` name on PyPI
for an upcoming open-source release. No public, stable API is provided yet.
