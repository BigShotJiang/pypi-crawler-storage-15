"""
Placeholder package for the Vaportrails developer flight recorder.

This release only reserves the PyPI namespace `vaportrails`.
No public, stable API is exposed yet.
"""

__version__ = "0.0.1"
