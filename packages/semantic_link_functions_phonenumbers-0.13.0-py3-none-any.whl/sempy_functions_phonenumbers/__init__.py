from sempy_functions_phonenumbers._phonenumbers import is_phonenumber_dataframe, is_phonenumber_series

__all__ = [
    "is_phonenumber_dataframe",
    "is_phonenumber_series",
]
