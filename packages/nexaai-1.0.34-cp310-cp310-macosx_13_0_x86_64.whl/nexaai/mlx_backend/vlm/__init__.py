import logging

logging.getLogger("transformers").setLevel(logging.ERROR)
