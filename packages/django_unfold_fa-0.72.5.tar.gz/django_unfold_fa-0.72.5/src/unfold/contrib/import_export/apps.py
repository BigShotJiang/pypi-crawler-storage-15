from django.apps import AppConfig


class ImportExportConfig(AppConfig):
    name = "unfold.contrib.import_export"
    label = "unfold_importexport"
