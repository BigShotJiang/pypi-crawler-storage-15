API Client for Hx 3 Thermostats
===============================

Installing
----------

```shell
  $ pip install hx3
```
