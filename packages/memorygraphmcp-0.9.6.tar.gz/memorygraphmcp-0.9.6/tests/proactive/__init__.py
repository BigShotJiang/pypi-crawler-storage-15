"""
Tests for proactive features (Phase 7).
"""
