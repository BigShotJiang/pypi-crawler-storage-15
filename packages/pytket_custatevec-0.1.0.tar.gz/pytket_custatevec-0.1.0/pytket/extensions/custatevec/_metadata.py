__extension_version__ = "0.0.1"
__extension_name__ = "pytket-custatevec"
