Matplotlib Figures
------------------