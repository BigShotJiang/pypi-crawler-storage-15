Matplotlib Animations
---------------------