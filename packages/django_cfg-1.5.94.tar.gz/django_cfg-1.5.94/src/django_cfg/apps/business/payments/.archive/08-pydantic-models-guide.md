# Pydantic Models Guide

## Зачем Pydantic v2

**Pydantic** используется для валидации данных в service layer и provider layer.

**Преимущества**:
- Строгая типизация
- Автоматическая валидация
- Сериализация/десериализация
- JSON schema generation
- Отделение бизнес-логики от Django ORM

**Где используем**:
- ✅ Service layer (PaymentService, WithdrawalService)
- ✅ Provider layer (NowPaymentsProvider requests/responses)
- ✅ Configuration (NowPaymentsConfig)
- ❌ НЕ используем в Django models (там Django validation)
- ❌ НЕ используем в DRF serializers (там DRF validation)

## Архитектура слоев

```
Frontend (React/Vue)
    ↓
DRF Serializers (валидация API request/response)
    ↓
Django Views (routing, permissions)
    ↓
Service Layer (Pydantic models - бизнес-логика)
    ↓
Provider Layer (Pydantic models - external API)
    ↓
Django ORM Models (database)
```

## Основные Pydantic модели

### 1. Provider Models

```python
# payments/services/providers/models.py

from pydantic import BaseModel, Field, field_validator
from decimal import Decimal
from datetime import datetime
from typing import Optional

class PaymentRequest(BaseModel):
    """
    Request для создания платежа.
    Используется между Service → Provider.
    """
    amount_usd: Decimal = Field(ge=1, le=50000, description="Amount in USD")
    currency_code: str = Field(min_length=3, max_length=20)
    order_id: str = Field(min_length=10, max_length=100)
    description: Optional[str] = Field(None, max_length=500)
    customer_email: Optional[str] = None
    callback_url: Optional[str] = None
    cancel_url: Optional[str] = None

    @field_validator('currency_code')
    @classmethod
    def validate_currency_code(cls, v):
        """Ensure currency code is uppercase."""
        return v.upper()

    @field_validator('amount_usd')
    @classmethod
    def validate_amount(cls, v):
        """Validate amount has max 2 decimal places."""
        if v.as_tuple().exponent < -2:
            raise ValueError('Amount must have max 2 decimal places')
        return v


class ProviderResponse(BaseModel):
    """
    Response от провайдера.
    Универсальная модель для всех провайдеров.
    """
    success: bool
    provider_payment_id: Optional[str] = None
    status: Optional[str] = None
    wallet_address: Optional[str] = None
    amount: Optional[Decimal] = None
    actual_amount: Optional[Decimal] = None
    currency: Optional[str] = None
    transaction_hash: Optional[str] = None
    payment_url: Optional[str] = None
    expires_at: Optional[datetime] = None
    confirmations_count: int = 0
    error_message: Optional[str] = None
    error_code: Optional[str] = None
    raw_response: dict = Field(default_factory=dict)

    model_config = {
        'json_schema_extra': {
            'example': {
                'success': True,
                'provider_payment_id': '123456',
                'status': 'pending',
                'wallet_address': 'TXYZabc123...',
                'amount': '100.234567',
                'currency': 'USDTTRC20'
            }
        }
    }
```

### 2. Service Layer Models

```python
# payments/services/models.py

from pydantic import BaseModel, Field, ConfigDict
from decimal import Decimal
from typing import Optional
from uuid import UUID

class CreatePaymentRequest(BaseModel):
    """
    Request для создания платежа.
    Используется между View → Service.
    """
    user_id: int
    amount_usd: Decimal = Field(ge=1, le=50000)
    currency_code: str
    description: Optional[str] = None

    model_config = ConfigDict(frozen=True)  # immutable


class PaymentResult(BaseModel):
    """
    Result создания платежа.
    Возвращается из Service → View.
    """
    success: bool
    payment_id: Optional[UUID] = None
    pay_address: Optional[str] = None
    pay_amount: Optional[Decimal] = None
    qr_code_url: Optional[str] = None
    expires_at: Optional[datetime] = None
    error: Optional[str] = None


class ConfirmPaymentRequest(BaseModel):
    """Request для подтверждения платежа."""
    payment_id: UUID
    user_id: int

    model_config = ConfigDict(frozen=True)


class ConfirmResult(BaseModel):
    """Result подтверждения платежа."""
    success: bool
    payment_status: str
    transaction_id: Optional[UUID] = None
    balance_after: Optional[Decimal] = None
    message: str
```

### 3. Configuration Models

```python
# payments/services/providers/nowpayments/config.py

from pydantic import BaseModel, Field, SecretStr, HttpUrl, field_validator
from decimal import Decimal

class NowPaymentsConfig(BaseModel):
    """
    Configuration для NowPayments провайдера.
    Immutable, validated on creation.
    """
    api_key: SecretStr = Field(description="NowPayments API key")
    api_url: HttpUrl = Field(
        default='https://api.nowpayments.io/v1/',
        description="Base API URL"
    )
    sandbox: bool = Field(default=False, description="Use sandbox mode")
    timeout: int = Field(default=30, ge=5, le=120, description="Request timeout in seconds")

    # Limits
    min_amount_usd: Decimal = Field(default=Decimal('1.0'), ge=0)
    max_amount_usd: Decimal = Field(default=Decimal('50000.0'))

    # Expiration
    payment_expiration_minutes: int = Field(default=30, ge=10, le=120)

    model_config = ConfigDict(
        frozen=True,  # immutable
        validate_assignment=True,  # validate on change attempts
        str_strip_whitespace=True,
        extra='forbid'  # forbid extra fields
    )

    @field_validator('api_url')
    @classmethod
    def validate_api_url(cls, v):
        """Ensure URL ends with slash."""
        url_str = str(v)
        if not url_str.endswith('/'):
            url_str += '/'
        return url_str

    @property
    def is_production(self) -> bool:
        """Check if running in production mode."""
        return not self.sandbox
```

### 4. Withdrawal Models

```python
# payments/services/withdrawal/models.py

from pydantic import BaseModel, Field, field_validator
from decimal import Decimal
from uuid import UUID
from typing import Optional

class CreateWithdrawalRequest(BaseModel):
    """Request для создания вывода."""
    user_id: int
    amount_usd: Decimal = Field(ge=10, le=100000)
    currency_code: str
    wallet_address: str = Field(min_length=26, max_length=100)

    @field_validator('wallet_address')
    @classmethod
    def validate_wallet_address(cls, v, info):
        """Validate wallet address format."""
        from ..validators import WalletAddressValidator

        currency_code = info.data.get('currency_code', '')
        is_valid, error = WalletAddressValidator.validate(v, currency_code)

        if not is_valid:
            raise ValueError(error)

        return v

    model_config = ConfigDict(frozen=True)


class WithdrawalFees(BaseModel):
    """Расчет комиссий для вывода."""
    network_fee_usd: Decimal = Field(ge=0)
    service_fee_usd: Decimal = Field(ge=0)
    total_fee_usd: Decimal = Field(ge=0)
    final_amount_usd: Decimal = Field(ge=0)

    model_config = ConfigDict(frozen=True)

    def __str__(self):
        return (
            f"Network: ${self.network_fee_usd}, "
            f"Service: ${self.service_fee_usd}, "
            f"Total: ${self.total_fee_usd}, "
            f"You receive: ${self.final_amount_usd}"
        )
```

## Best Practices

### 1. Разделение моделей по слоям

```python
# ❌ ПЛОХО - одна модель для всего
class Payment(BaseModel):
    # Смешивание Django ORM полей и Pydantic
    pass

# ✅ ХОРОШО - разные модели для разных слоев
# Django ORM
class Payment(models.Model):
    # Database fields
    pass

# DRF Serializer
class PaymentSerializer(serializers.ModelSerializer):
    # API validation
    pass

# Pydantic
class CreatePaymentRequest(BaseModel):
    # Service layer validation
    pass
```

### 2. Immutable models для requests

```python
# ✅ ХОРОШО - frozen models
class CreatePaymentRequest(BaseModel):
    amount_usd: Decimal
    currency_code: str

    model_config = ConfigDict(frozen=True)

# Попытка изменить - ошибка
request = CreatePaymentRequest(amount_usd=100, currency_code='BTC')
request.amount_usd = 200  # ValidationError!
```

### 3. Использование Field для метаданных

```python
class PaymentRequest(BaseModel):
    amount_usd: Decimal = Field(
        ge=1,                          # greater or equal
        le=50000,                      # less or equal
        description="Payment amount",
        json_schema_extra={
            'example': 100.50
        }
    )

    currency_code: str = Field(
        min_length=3,
        max_length=20,
        pattern=r'^[A-Z0-9]+$',       # regex validation
        description="Currency code"
    )
```

### 4. Custom validators

```python
class PaymentRequest(BaseModel):
    amount_usd: Decimal
    currency_code: str

    @field_validator('currency_code')
    @classmethod
    def validate_currency(cls, v):
        """Validate currency exists in database."""
        from django_cfg.apps.payments.models import Currency

        if not Currency.objects.filter(code=v, is_active=True).exists():
            raise ValueError(f'Currency {v} is not supported')

        return v

    @model_validator(mode='after')
    def validate_amount_for_currency(self):
        """Cross-field validation."""
        # Check minimum amount for specific currency
        if self.currency_code == 'BTC' and self.amount_usd < 10:
            raise ValueError('Minimum amount for BTC is $10')

        return self
```

### 5. Error handling

```python
from pydantic import ValidationError

def create_payment(data: dict):
    """Create payment with Pydantic validation."""
    try:
        # Валидация через Pydantic
        request = CreatePaymentRequest(**data)

        # Бизнес-логика
        payment_service = PaymentService()
        result = payment_service.create_payment(request)

        return result

    except ValidationError as e:
        # Pydantic validation errors
        logger.error(f"Validation error: {e.json()}")

        # Convert to user-friendly messages
        errors = {}
        for error in e.errors():
            field = error['loc'][0]
            message = error['msg']
            errors[field] = message

        raise ValueError(f"Invalid data: {errors}")
```

## Примеры использования

### Service Layer

```python
# payments/services/payment_service.py

from typing import Optional
from pydantic import ValidationError
from .models import CreatePaymentRequest, PaymentResult, ConfirmResult
from .providers.registry import get_provider

class PaymentService:
    """Service для работы с платежами."""

    def create_payment(self, request: CreatePaymentRequest) -> PaymentResult:
        """
        Создать платеж.

        Args:
            request: Validated Pydantic model

        Returns:
            PaymentResult with payment data or error
        """
        try:
            # Get user
            user = User.objects.get(id=request.user_id)

            # Create payment in DB
            payment = Payment.objects.create(
                user=user,
                amount_usd=request.amount_usd,
                currency_code=request.currency_code,
                description=request.description or '',
                status='pending'
            )

            # Prepare provider request
            provider_request = PaymentRequest(
                amount_usd=request.amount_usd,
                currency_code=request.currency_code,
                order_id=payment.internal_payment_id,
                description=request.description
            )

            # Call provider
            provider = get_provider('nowpayments')
            provider_response = provider.create_payment(provider_request)

            if not provider_response.success:
                payment.status = 'failed'
                payment.save()

                return PaymentResult(
                    success=False,
                    error=provider_response.error_message
                )

            # Update payment with provider data
            payment.provider_payment_id = provider_response.provider_payment_id
            payment.pay_address = provider_response.wallet_address
            payment.pay_amount = provider_response.amount
            payment.expires_at = provider_response.expires_at
            payment.save()

            return PaymentResult(
                success=True,
                payment_id=payment.id,
                pay_address=payment.pay_address,
                pay_amount=payment.pay_amount,
                qr_code_url=payment.get_qr_code_url(),
                expires_at=payment.expires_at
            )

        except ValidationError as e:
            logger.error(f"Pydantic validation failed: {e}")
            return PaymentResult(
                success=False,
                error="Invalid request data"
            )

        except Exception as e:
            logger.exception("Payment creation failed")
            return PaymentResult(
                success=False,
                error=str(e)
            )
```

### View Layer

```python
# payments/api/views.py

from rest_framework.views import APIView
from rest_framework.response import Response
from ..services.payment_service import PaymentService
from ..services.models import CreatePaymentRequest
from .serializers import PaymentCreateSerializer, PaymentDetailSerializer

class PaymentCreateView(APIView):
    """Create new payment."""

    permission_classes = [IsAuthenticated]

    def post(self, request):
        """Create payment."""

        # DRF validation (API layer)
        serializer = PaymentCreateSerializer(data=request.data)
        if not serializer.is_valid():
            return Response({
                'success': False,
                'errors': serializer.errors
            }, status=400)

        # Create Pydantic request (Service layer)
        service_request = CreatePaymentRequest(
            user_id=request.user.id,
            **serializer.validated_data
        )

        # Call service
        payment_service = PaymentService()
        result = payment_service.create_payment(service_request)

        if not result.success:
            return Response({
                'success': False,
                'error': result.error
            }, status=500)

        # Serialize response
        payment = Payment.objects.get(id=result.payment_id)
        response_serializer = PaymentDetailSerializer(payment)

        return Response({
            'success': True,
            'payment': response_serializer.data
        }, status=201)
```

## Migration от payments_old

В `payments_old` используется много Pydantic моделей. Что взять:

### Что копируем:
- `services/providers/models/base.py` → базовые модели
- `services/providers/nowpayments/models.py` → NowPayments models
- `services/providers/nowpayments/config.py` → конфигурация

### Что упрощаем:
- Убираем webhook models (не нужны)
- Убираем сложные error models (используем простые exceptions)
- Убираем fallback models (один провайдер)

## Testing

```python
# tests/test_pydantic_models.py

import pytest
from decimal import Decimal
from pydantic import ValidationError
from payments.services.models import CreatePaymentRequest

def test_create_payment_request_valid():
    """Test valid payment request."""
    request = CreatePaymentRequest(
        user_id=1,
        amount_usd=Decimal('100.00'),
        currency_code='USDTTRC20'
    )

    assert request.user_id == 1
    assert request.amount_usd == Decimal('100.00')


def test_create_payment_request_invalid_amount():
    """Test invalid amount."""
    with pytest.raises(ValidationError) as exc_info:
        CreatePaymentRequest(
            user_id=1,
            amount_usd=Decimal('0.50'),  # too low
            currency_code='USDTTRC20'
        )

    errors = exc_info.value.errors()
    assert any('amount_usd' in str(e) for e in errors)


def test_payment_request_immutable():
    """Test that request is immutable."""
    request = CreatePaymentRequest(
        user_id=1,
        amount_usd=Decimal('100.00'),
        currency_code='USDTTRC20'
    )

    with pytest.raises(ValidationError):
        request.amount_usd = Decimal('200.00')
```

## Summary

**Pydantic v2 используется для**:
- ✅ Валидация данных между слоями
- ✅ Типизация service layer
- ✅ Provider requests/responses
- ✅ Configuration models
- ✅ Immutable DTOs

**НЕ используется для**:
- ❌ Django ORM models
- ❌ DRF serializers (у них своя валидация)
- ❌ Frontend data (используем DRF serializers)

**Преимущества**:
- Строгая типизация
- Автоматическая валидация
- Отделение слоев
- Лучшая поддержка IDE
- Генерация JSON schema
