# Navigator по payments_old

## Обзор

Этот документ - навигатор по `payments_old` кодовой базе. Используйте его как reference при имплементации нового `payments`.

## Структура payments_old

```
payments_old/
├── models/           → Django ORM модели
├── services/         → Бизнес-логика (Pydantic models)
├── views/            → API endpoints (DRF)
├── admin/            → Django admin
├── middleware/       → Middleware (webhook, API access)
├── signals/          → Django signals
├── tasks/            → Celery tasks
├── tests/            → Тесты
└── @docs/            → Документация
```

---

## Что брать из payments_old

### 1. Models (частично)

#### ✅ Берем и упрощаем

**`models/payments.py`** - `UniversalPayment`
```python
# Path: payments_old/models/payments.py:19
class UniversalPayment(UUIDTimestampedModel):
```

**Что взять**:
- Статусы (`PaymentStatus`)
- Провайдер enum (`PaymentProvider`)
- Основные поля (user, amount_usd, currency, pay_address, etc.)
- Properties (qr_data, explorer_link)
- Manager методы

**Что упростить**:
- Убрать лишние поля (callback_url, cancel_url, security_nonce)
- Упростить validation
- Убрать webhook_data поле

**Пример копирования**:
```python
# Копируем из payments_old/models/payments.py:27-36
class PaymentStatus(models.TextChoices):
    PENDING = "pending", "Pending"
    CONFIRMING = "confirming", "Confirming"
    CONFIRMED = "confirmed", "Confirmed"
    COMPLETED = "completed", "Completed"
    FAILED = "failed", "Failed"
    EXPIRED = "expired", "Expired"
    CANCELLED = "cancelled", "Cancelled"
    REFUNDED = "refunded", "Refunded"
```

---

**`models/balance.py`** - `UserBalance`, `Transaction`
```python
# Path: payments_old/models/balance.py:17
class UserBalance(models.Model):

# Path: payments_old/models/balance.py:137
class Transaction(UUIDTimestampedModel):
```

**Что взять**:
- Transaction model полностью
- UserBalance model со всеми полями
- Manager logic для расчета баланса

**Что упростить**:
- Убрать `reserved_usd` поле (не нужно)

---

**`models/currencies.py`** - `Currency`, `Network`
```python
# Path: payments_old/models/currencies.py:14
class Currency(TimestampedModel):

# Path: payments_old/models/currencies.py:130
class Network(TimestampedModel):
```

**Что взять**:
- Currency model (упрощенный)
- Network model (может не понадобиться, т.к. NowPayments имеет токен+сеть в одном коде)

**Что упростить**:
- Убрать ProviderCurrency модель (не нужна)
- Убрать методы provider configuration (слишком сложно)

---

#### ❌ НЕ берем

- `models/api_keys.py` - не нужны API keys
- `models/tariffs.py` - не нужны тарифы
- `models/subscriptions.py` - не нужны подписки

---

### 2. Services (адаптируем)

#### ✅ Берем и адаптируем

**`services/providers/base.py`** - `BaseProvider`
```python
# Path: payments_old/services/providers/base.py
class BaseProvider(ABC):
```

**Что взять**:
- Абстрактный интерфейс
- Методы `create_payment()`, `get_payment_status()`
- Базовую структуру

**Что упростить**:
- Убрать webhook validation методы
- Убрать health check методы
- Упростить error handling

---

**`services/providers/nowpayments/provider.py`** - `NowPaymentsProvider`
```python
# Path: payments_old/services/providers/nowpayments/provider.py:31
class NowPaymentsProvider(BaseProvider):
```

**Что взять**:
- STATUS_MAPPING (маппинг статусов)
- create_payment() метод
- get_payment_status() метод
- get_supported_currencies() метод

**Что упростить**:
- Убрать validate_webhook() метод
- Убрать health_check() метод
- Упростить error handling

**Ключевые части для копирования**:
```python
# STATUS_MAPPING (payments_old/services/providers/nowpayments/provider.py:35-45)
STATUS_MAPPING = {
    'waiting': 'pending',
    'confirming': 'processing',
    'confirmed': 'completed',
    'partially_paid': 'pending',
    'finished': 'completed',
    'failed': 'failed',
    'refunded': 'refunded',
    'expired': 'expired'
}

# create_payment() (payments_old/services/providers/nowpayments/provider.py:89-203)
def create_payment(self, request: PaymentRequest) -> ProviderResponse:
    # Логика создания платежа
    pass

# get_payment_status() (payments_old/services/providers/nowpayments/provider.py:205-264)
def get_payment_status(self, provider_payment_id: str) -> ProviderResponse:
    # Логика получения статуса
    pass
```

---

**`services/providers/nowpayments/config.py`** - `NowPaymentsConfig`
```python
# Path: payments_old/services/providers/nowpayments/config.py
class NowPaymentsConfig(BaseModel):
```

**Что взять**:
- Все поля конфигурации
- Валидаторы
- Константы (FEE_PERCENTAGE, MIN_AMOUNT, etc.)

**Копируем полностью**, это хорошая базовая конфигурация.

---

**`services/providers/nowpayments/parsers/parser.py`** - `NowPaymentsCurrencyParser`
```python
# Path: payments_old/services/providers/nowpayments/parsers/parser.py
class NowPaymentsCurrencyParser:
```

**Что взять**:
- parse_currency_code() метод
- generate_currency_name() метод
- Паттерны для парсинга (TRC20, ERC20, etc.)

**Это критично** - правильный парсинг `USDTTRC20` → (`USDT`, `TRC20`).

---

**`services/providers/models/`** - Pydantic модели
```python
# Path: payments_old/services/providers/models/base.py
class PaymentRequest(BaseModel):
class ProviderResponse(BaseModel):

# Path: payments_old/services/providers/models/universal.py
class UniversalCurrency(BaseModel):
```

**Что взять**:
- PaymentRequest - запрос к провайдеру
- ProviderResponse - ответ от провайдера
- UniversalCurrency - модель валюты
- CurrencySyncResult - результат синхронизации

**Копируем почти полностью**, это хорошие базовые модели.

---

**`services/providers/registry.py`** - `ProviderRegistry`
```python
# Path: payments_old/services/providers/registry.py
class ProviderRegistry:
```

**Что взять**:
- Базовую идею реестра
- get_provider() метод

**Что упростить**:
- Убрать health monitoring
- Убрать fallback logic
- Убрать circuit breaker
- Сделать простой singleton

---

#### ❌ НЕ берем

- `services/core/error_handler.py` (686 строк) - слишком сложно
- `services/core/fallback_service.py` - не нужен fallback
- `services/core/cache_service.py` - используем стандартный Django cache
- `services/security/` - избыточная безопасность

---

### 3. Views/API (адаптируем)

#### ✅ Берем идеи, переписываем

**`views/api/payment_views.py`** - Payment views
```python
# Path: payments_old/views/api/payment_views.py
```

**Что взять**:
- Структуру API endpoints
- Permission classes
- Serializer patterns

**Что переписать**:
- Упростить views (убрать лишние проверки)
- Убрать API key logic
- Убрать subscription logic

---

#### ❌ НЕ берем

- `views/api/webhook_views.py` - не нужны webhooks
- `views/api/api_key_views.py` - не нужны API keys
- `views/api/subscription_views.py` - не нужны subscriptions
- `views/overview/` - не нужен dashboard

---

### 4. Admin (частично)

**`admin/payment_admin.py`**
```python
# Path: payments_old/admin/payment_admin.py
@admin.register(UniversalPayment)
class UniversalPaymentAdmin(ModelAdmin):
```

**Что взять**:
- list_display поля
- list_filter filters
- search_fields
- Custom actions
- Inline classes

**Хороший пример** продвинутого Django admin.

---

### 5. Middleware (НЕ берем)

❌ `middleware/webhook_middleware.py` - не нужны webhooks
❌ `middleware/api_access_middleware.py` - не нужны API keys

---

### 6. Tests (идеи)

**`tests/providers/test_base_provider.py`**
**`tests/models/test_payments.py`**

**Что взять**:
- Структуру тестов
- Test fixtures
- Mock patterns для провайдера

---

## Workflow: Как использовать payments_old

### 1. Создание Payment model

```bash
# 1. Открыть payments_old/models/payments.py
# 2. Скопировать class UniversalPayment
# 3. Упростить:
#    - Убрать лишние поля
#    - Оставить основные (user, amount, currency, status, etc.)
# 4. Скопировать PaymentStatus choices
# 5. Скопировать properties (qr_data, explorer_link)
```

**Файлы для референса**:
- `payments_old/models/payments.py` (основная модель)
- `payments_old/models/base.py` (UUIDTimestampedModel)

---

### 2. Создание Transaction model

```bash
# 1. Открыть payments_old/models/balance.py
# 2. Скопировать class Transaction (строка 137)
# 3. Скопировать TransactionType choices
# 4. Скопировать Manager methods
```

---

### 3. Создание NowPayments Provider

```bash
# 1. Создать структуру:
#    payments/services/providers/nowpayments/

# 2. Скопировать файлы:
#    - config.py (полностью)
#    - models.py (Pydantic models)
#    - provider.py (основная логика)

# 3. Из provider.py взять:
#    - STATUS_MAPPING
#    - create_payment() метод
#    - get_payment_status() метод
#    - get_supported_currencies() метод

# 4. Убрать:
#    - validate_webhook()
#    - health_check()
#    - Сложный error handling
```

**Файлы для референса**:
- `payments_old/services/providers/nowpayments/provider.py`
- `payments_old/services/providers/nowpayments/config.py`
- `payments_old/services/providers/nowpayments/models.py`

---

### 4. Парсинг валют NowPayments

```bash
# 1. Открыть payments_old/services/providers/nowpayments/parsers/parser.py

# 2. Скопировать методы:
#    - parse_currency_code()  (USDTTRC20 → USDT + TRC20)
#    - generate_currency_name()

# 3. Скопировать паттерны:
#    payments_old/services/providers/nowpayments/parsers/data/patterns.py
```

**Это критично** для правильной работы с NowPayments!

---

### 5. Создание Service Layer

```bash
# 1. Создать payments/services/payment_service.py

# 2. Из payments_old НЕ копируем service layer
#    (он слишком сложный)

# 3. Пишем новый упрощенный сервис, используя:
#    - Pydantic models из payments_old/services/providers/models/
#    - Provider registry pattern
#    - Transaction atomic operations
```

---

## Quick Reference: Файлы payments_old

### Модели (Django ORM)
| Файл | Что брать |
|------|-----------|
| `models/payments.py:19` | UniversalPayment model |
| `models/balance.py:17` | UserBalance model |
| `models/balance.py:137` | Transaction model |
| `models/currencies.py:14` | Currency model |
| `models/base.py` | Base models (UUIDTimestampedModel) |

### Services (Pydantic)
| Файл | Что брать |
|------|-----------|
| `services/providers/base.py` | BaseProvider interface |
| `services/providers/nowpayments/provider.py` | NowPaymentsProvider |
| `services/providers/nowpayments/config.py` | NowPaymentsConfig |
| `services/providers/nowpayments/models.py` | Pydantic models |
| `services/providers/nowpayments/parsers/parser.py` | Currency parser |
| `services/providers/models/base.py` | PaymentRequest, ProviderResponse |
| `services/providers/models/universal.py` | UniversalCurrency |
| `services/providers/registry.py` | ProviderRegistry (упростить) |

### Admin
| Файл | Что брать |
|------|-----------|
| `admin/payment_admin.py` | Admin configuration |

### Managers
| Файл | Что брать |
|------|-----------|
| `models/managers/payment_managers.py` | PaymentManager |
| `models/managers/balance_managers.py` | UserBalanceManager, TransactionManager |

---

## Что НЕ смотреть

❌ **Игнорируем**:
- `@docs/` - старая документация (у нас новая в `@refactoring/`)
- `@progress/` - old progress reports
- `@providers/cryptapi/` - не нужен провайдер
- `@providers/cryptomus/` - не нужен провайдер
- `views/overview/` - не нужен dashboard
- `views/api/webhook_views.py` - не нужны webhooks
- `views/api/api_key_views.py` - не нужны API keys
- `views/api/subscription_views.py` - не нужны subscriptions
- `middleware/` - не нужны middleware
- `signals/` - не нужны signals (пока)
- `tasks/` - не нужны Celery tasks (пока)
- `services/core/error_handler.py` - слишком сложно
- `services/core/fallback_service.py` - не нужен
- `services/security/` - избыточно

---

## Чек-лист копирования

При копировании кода из `payments_old`:

1. ✅ Проверить что код актуален
2. ✅ Упростить если возможно
3. ✅ Убрать webhook logic
4. ✅ Убрать API key logic
5. ✅ Убрать subscription logic
6. ✅ Обновить imports
7. ✅ Обновить docstrings
8. ✅ Добавить type hints
9. ✅ Проверить Pydantic v2 syntax (если Pydantic model)
10. ✅ Написать тест

---

## Summary

**Используем payments_old как**:
- ✅ Reference для структуры models
- ✅ Готовый код NowPayments provider
- ✅ Примеры Pydantic models
- ✅ Currency parser logic
- ✅ Admin configuration patterns

**НЕ копируем слепо**:
- ❌ Webhook logic
- ❌ API keys system
- ❌ Subscription system
- ❌ Over-engineered services
- ❌ Complex middleware

**Workflow**:
1. Найти нужный файл в payments_old (используя эту навигацию)
2. Открыть файл и найти нужный class/method
3. Скопировать в payments/ (в соответствующую директорию)
4. Упростить код (убрать лишнее)
5. Обновить imports и синтаксис
6. Написать тест
7. Commit

Следуй документации `@refactoring/` для структуры нового приложения!
