# Flow Diagrams - Mermaid

Визуальные диаграммы процессов платежной системы.

## 1. Deposit Flow (Пополнение баланса)

```mermaid
sequenceDiagram
    actor User
    participant Frontend
    participant Backend
    participant NowPayments
    participant Database

    User->>Frontend: 1. Открывает страницу пополнения
    Frontend->>Backend: GET /api/v1/payments/currencies/
    Backend->>NowPayments: Получить список валют
    NowPayments-->>Backend: Список валют
    Backend-->>Frontend: {currencies: [...]}
    Frontend-->>User: Показать список валют

    User->>Frontend: 2. Выбирает валюту + вводит сумму
    Frontend->>Backend: POST /api/v1/payments/create/<br/>{amount_usd, currency_code}
    Backend->>Database: Создать запись Payment (pending)
    Backend->>NowPayments: POST /payment<br/>{price_amount, pay_currency}
    NowPayments-->>Backend: {payment_id, pay_address, pay_amount}
    Backend->>Database: Обновить Payment<br/>(provider_payment_id, pay_address)
    Backend-->>Frontend: {payment: {pay_address, qr_code, ...}}
    Frontend-->>User: Показать адрес + QR код

    User->>User: 3. Отправляет крипту<br/>из своего кошелька

    loop Polling каждые 10 секунд
        Frontend->>Backend: GET /payments/{id}/status/?refresh=true
        Backend->>NowPayments: GET /payment/{payment_id}
        NowPayments-->>Backend: {payment_status, ...}
        Backend->>Database: Обновить статус
        Backend-->>Frontend: {payment: {status, ...}}

        alt Status = completed
            Frontend-->>User: ✓ Платеж завершен!
        else Status = expired
            Frontend-->>User: ⏱ Время истекло
        else Status = pending
            Frontend-->>User: ⏳ Ожидание...
        end
    end

    User->>Frontend: 4. Нажимает "Я оплатил"
    Frontend->>Backend: POST /payments/{id}/confirm/
    Backend->>NowPayments: GET /payment/{payment_id}
    NowPayments-->>Backend: {payment_status: "finished"}

    alt Payment completed
        Backend->>Database: Создать Transaction (deposit)
        Backend->>Database: Пересчитать UserBalance
        Backend-->>Frontend: {success: true, transaction}
        Frontend-->>User: ✅ Баланс пополнен!
    else Payment pending
        Backend-->>Frontend: {success: false, message: "still pending"}
        Frontend-->>User: ⏳ Еще не подтверждено
    else Partial payment
        Backend->>Database: Пометить partially_paid
        Backend-->>Frontend: {success: false, message: "partial"}
        Frontend-->>User: ⚠️ Частичная оплата,<br/>свяжитесь с поддержкой
    end
```

---

## 2. Withdrawal Flow (Вывод средств)

```mermaid
sequenceDiagram
    actor User
    actor Admin
    participant Frontend
    participant Backend
    participant Database
    participant Email

    User->>Frontend: 1. Открывает страницу вывода
    Frontend->>Backend: GET /api/v1/payments/balance/
    Backend->>Database: Вычислить баланс из транзакций
    Backend-->>Frontend: {balance_usd: 250.00}
    Frontend-->>User: Показать доступный баланс

    User->>Frontend: 2. Вводит сумму, валюту, адрес
    Frontend->>Frontend: Показать расчет комиссий
    Note over Frontend: Amount: $100<br/>Network fee: $1<br/>Service fee: $2<br/>You receive: $97

    User->>Frontend: 3. Подтверждает вывод
    Frontend->>Backend: POST /withdrawals/create/<br/>{amount_usd, currency_code, wallet_address}
    Backend->>Backend: Валидировать адрес кошелька
    Backend->>Backend: Проверить баланс >= amount
    Backend->>Database: Создать WithdrawalRequest (pending)
    Backend->>Email: Уведомить админа
    Backend-->>Frontend: {withdrawal: {id, status: "pending"}}
    Frontend-->>User: ✓ Запрос создан,<br/>ожидайте одобрения

    Note over Admin,Email: Админ получает email

    Admin->>Backend: 4. Проверяет запрос в админке
    Admin->>Admin: Проверяет:<br/>- адрес валидный?<br/>- юзер не подозрительный?

    alt Одобрено
        Admin->>Backend: POST /admin/withdrawals/{id}/approve/
        Backend->>Database: Обновить статус (approved)
        Backend->>Email: Уведомить юзера
        Backend-->>Admin: {success: true}

        Admin->>Admin: 5. Отправляет крипту вручную<br/>(из hot wallet или биржи)
        Admin->>Admin: Получает tx hash

        Admin->>Backend: POST /admin/withdrawals/{id}/complete/<br/>{transaction_hash}
        Backend->>Database: Обновить статус (completed)
        Backend->>Database: Создать Transaction (withdrawal)
        Backend->>Database: Пересчитать UserBalance
        Backend->>Email: Уведомить юзера о завершении
        Backend-->>Admin: {success: true}

        User->>Frontend: 6. Проверяет статус
        Frontend->>Backend: GET /withdrawals/{id}/
        Backend-->>Frontend: {status: "completed", transaction_hash}
        Frontend-->>User: ✅ Вывод завершен!<br/>[Ссылка на explorer]

    else Отклонено
        Admin->>Backend: POST /admin/withdrawals/{id}/reject/<br/>{reason}
        Backend->>Database: Обновить статус (rejected)
        Backend->>Email: Уведомить юзера о причине
        Backend-->>Admin: {success: true}

        User->>Frontend: 6. Проверяет статус
        Frontend-->>User: ❌ Вывод отклонен:<br/>{rejection_reason}
    end
```

---

## 3. Payment State Machine

```mermaid
stateDiagram-v2
    [*] --> Pending: Create payment

    Pending --> Confirming: User paid
    Pending --> Expired: 30 min timeout
    Pending --> Cancelled: User cancels

    Confirming --> Confirmed: Blockchain confirms
    Confirming --> Failed: Confirmation failed

    Confirmed --> Completed: Final confirmation
    Confirmed --> PartiallyPaid: Amount mismatch

    Completed --> [*]: Success
    Failed --> [*]: Error
    Expired --> [*]: Timeout
    Cancelled --> [*]: User action
    PartiallyPaid --> [*]: Need support

    note right of Completed
        Transaction created
        Balance updated
    end note

    note right of PartiallyPaid
        Admin notification
        User contacts support
    end note
```

---

## 4. Withdrawal State Machine

```mermaid
stateDiagram-v2
    [*] --> Pending: User creates request

    Pending --> Approved: Admin approves
    Pending --> Rejected: Admin rejects
    Pending --> Cancelled: User cancels

    Approved --> Processing: Admin starts sending
    Processing --> Completed: Crypto sent + tx hash

    Completed --> [*]: Success
    Rejected --> [*]: Admin decision
    Cancelled --> [*]: User action

    note right of Approved
        Admin verified:
        - Wallet address
        - User identity
        - Sufficient balance
    end note

    note right of Completed
        Transaction created
        Balance deducted
        User notified
    end note
```

---

## 5. System Architecture

```mermaid
graph TB
    subgraph Frontend
        UI[React/Vue Frontend]
        API_Client[API Client]
    end

    subgraph Backend["Django Backend"]
        subgraph API["API Layer"]
            Views[DRF Views]
            Serializers[Serializers]
            Permissions[Permissions]
        end

        subgraph Services["Service Layer"]
            PaymentService[PaymentService]
            WithdrawalService[WithdrawalService]
            BalanceService[BalanceService]
        end

        subgraph Providers["Provider Layer"]
            Registry[ProviderRegistry]
            NowPayments[NowPaymentsProvider]
            Client[HTTP Client]
        end

        subgraph Models["Data Layer"]
            Payment[Payment Model]
            Transaction[Transaction Model]
            Withdrawal[WithdrawalRequest]
            Balance[UserBalance]
        end
    end

    subgraph External["External Services"]
        NPApi[NowPayments API]
        Database[(PostgreSQL)]
        Cache[(Redis Cache)]
    end

    UI --> API_Client
    API_Client --> Views
    Views --> Serializers
    Views --> Services
    Services --> Providers
    Services --> Models
    Providers --> Client
    Client --> NPApi
    Models --> Database
    Views --> Cache

    style Frontend fill:#e1f5ff
    style Backend fill:#fff4e1
    style External fill:#f0f0f0
```

---

## 6. Data Flow - Payment Creation

```mermaid
flowchart TD
    Start([User creates payment]) --> ValidateInput{Validate input}

    ValidateInput -->|Invalid| ErrorResponse[Return error 400]
    ValidateInput -->|Valid| CreateDB[Create Payment in DB<br/>status=pending]

    CreateDB --> CallProvider[Call NowPayments API<br/>POST /payment]

    CallProvider -->|Success| UpdateDB[Update Payment<br/>pay_address, pay_amount]
    CallProvider -->|Error| MarkFailed[Mark payment as failed]

    UpdateDB --> ReturnSuccess[Return payment data<br/>with QR code]
    MarkFailed --> ErrorResponse2[Return error 500]

    ReturnSuccess --> End([Frontend shows payment info])
    ErrorResponse --> End2([User sees error])
    ErrorResponse2 --> End2

    style Start fill:#90EE90
    style End fill:#90EE90
    style End2 fill:#FFB6C1
    style ErrorResponse fill:#FFB6C1
    style ErrorResponse2 fill:#FFB6C1
```

---

## 7. Data Flow - Payment Confirmation

```mermaid
flowchart TD
    Start([User clicks 'I paid']) --> CheckDB{Payment exists<br/>and belongs to user?}

    CheckDB -->|No| Error404[Return 404]
    CheckDB -->|Yes| CheckStatus{Status allows<br/>confirmation?}

    CheckStatus -->|Already completed| Error400[Return 400:<br/>already completed]
    CheckStatus -->|Expired| Error400_2[Return 400:<br/>expired]
    CheckStatus -->|OK| CallProvider[Query NowPayments<br/>GET /payment/{id}]

    CallProvider -->|API Error| ErrorAPI[Return 503:<br/>provider unavailable]
    CallProvider -->|Success| CheckProviderStatus{Provider status?}

    CheckProviderStatus -->|finished| CheckAmount{Amount OK?}
    CheckProviderStatus -->|waiting/confirming| ReturnPending[Return: still pending]
    CheckProviderStatus -->|failed| ReturnFailed[Return: payment failed]

    CheckAmount -->|< 95%| MarkPartial[Mark as partially_paid<br/>Notify admin]
    CheckAmount -->|95-100%| CreateTx[Create Transaction<br/>Update balance]
    CheckAmount -->|100%+| CreateTx

    MarkPartial --> ReturnPartial[Return: partial payment]
    CreateTx --> ReturnSuccess[Return: success]

    Error404 --> End([End])
    Error400 --> End
    Error400_2 --> End
    ErrorAPI --> End
    ReturnPending --> End
    ReturnFailed --> End
    ReturnPartial --> End
    ReturnSuccess --> End2([Balance updated!])

    style Start fill:#90EE90
    style End2 fill:#90EE90
    style Error404 fill:#FFB6C1
    style Error400 fill:#FFB6C1
    style Error400_2 fill:#FFB6C1
    style ErrorAPI fill:#FFB6C1
```

---

## 8. Balance Calculation (ORM-based)

```mermaid
flowchart LR
    A[GET /balance/] --> B[Query all user transactions]

    B --> C[Sum deposits<br/>type='deposit']
    B --> D[Sum withdrawals<br/>type='withdrawal']

    C --> E[Total Deposited]
    D --> F[Total Withdrawn]

    E --> G[Calculate:<br/>balance = deposits - withdrawals]
    F --> G

    G --> H[Return balance]

    style A fill:#e1f5ff
    style H fill:#90EE90
```

---

## 9. Polling Strategy (Exponential Backoff)

```mermaid
flowchart TD
    Start([Payment created]) --> Poll1[Poll #1: 10s delay]

    Poll1 --> Check1{Status?}
    Check1 -->|Completed| Success([✅ Show success])
    Check1 -->|Expired| Expired([⏱ Show expired])
    Check1 -->|Pending| Poll2[Poll #2: 10s delay]

    Poll2 --> Check2{Status?}
    Check2 -->|Completed| Success
    Check2 -->|Expired| Expired
    Check2 -->|Pending| Poll3[Poll #3: 15s delay]

    Poll3 --> Check3{Status?}
    Check3 -->|Completed| Success
    Check3 -->|Expired| Expired
    Check3 -->|Pending| Poll4[Poll #4: 20s delay]

    Poll4 --> Check4{Status?}
    Check4 -->|Completed| Success
    Check4 -->|Expired| Expired
    Check4 -->|Pending| Poll5[Poll #5: 30s delay]

    Poll5 --> Check5{Status?}
    Check5 -->|Completed| Success
    Check5 -->|Expired| Expired
    Check5 -->|Pending| PollN[Poll #N: 60s delay<br/>max interval]

    style Start fill:#90EE90
    style Success fill:#90EE90
    style Expired fill:#FFB6C1

    Note1["`Intervals increase:
    10s → 10s → 15s → 20s → 30s → 60s (max)`"]
```

---

## 10. Provider Registry Pattern

```mermaid
classDiagram
    class ProviderRegistry {
        -dict providers
        +get_provider(name: str) Provider
        +register_provider(name: str, provider: Provider)
    }

    class BaseProvider {
        <<interface>>
        +create_payment(request)
        +get_payment_status(payment_id)
        +get_supported_currencies()
    }

    class NowPaymentsProvider {
        -config: NowPaymentsConfig
        -client: HTTPClient
        +create_payment(request)
        +get_payment_status(payment_id)
        +get_supported_currencies()
    }

    class FutureProvider {
        +create_payment(request)
        +get_payment_status(payment_id)
        +get_supported_currencies()
    }

    ProviderRegistry --> BaseProvider
    BaseProvider <|-- NowPaymentsProvider
    BaseProvider <|-- FutureProvider

    class PaymentService {
        -registry: ProviderRegistry
        +create_payment(user, amount, currency)
        +confirm_payment(payment_id, user)
    }

    PaymentService --> ProviderRegistry
```

---

## Как использовать

1. **GitHub/GitLab** - mermaid рендерится автоматически в `.md` файлах
2. **VS Code** - установите расширение "Markdown Preview Mermaid Support"
3. **Online** - https://mermaid.live/ для редактирования и экспорта

## Обозначения

- **Зеленый** - успешное завершение
- **Красный** - ошибки
- **Синий** - процессы
- **Желтый** - ожидание/pending состояния

---

**Эти диаграммы можно использовать для:**
- Документации
- Презентаций команде
- Onboarding новых разработчиков
- Дизайна фронтенда
- Тестирования edge cases
