# Payments Refactoring Documentation

## Обзор

Эта директория содержит полный план рефакторинга приложения `payments_old` в новое упрощенное приложение `payments`.

## Цели рефакторинга

1. **Упростить архитектуру** - убрать избыточный код и оверинжиниринг
2. **Фокус на NowPayments** - один провайдер как primary (остальные потом)
3. **Убрать вебхуки** - использовать polling вместо webhook + ngrok
4. **Чистое API** - простые и понятные endpoints для фронтенда
5. **ORM-based баланс** - вычислять через транзакции вместо хранения

## Структура документации

### [00-refactoring-plan.md](./00-refactoring-plan.md)
**Общий план рефакторинга**

Содержит:
- Что убираем из payments_old (вебхуки, API keys, тарифы, etc.)
- Что сохраняем и адаптируем (модели, провайдер)
- Новую структуру приложения
- Пошаговый план выполнения

**Читать первым** для понимания общей картины.

---

### [01-api-specification.md](./01-api-specification.md)
**Спецификация API endpoints**

Содержит:
- Все API endpoints с примерами request/response
- Описание параметров и ответов
- Статусы платежей и транзакций
- Error codes
- Rate limiting

**Для frontend разработчиков** - полная спецификация API.

---

### [02-flow-description.md](./02-flow-description.md)
**Описание флоу платежей**

Содержит:
- Пошаговый флоу пополнения баланса
- Примеры кода для frontend и backend
- Обработка исключительных ситуаций
- Timing и security
- Диаграммы

**Для понимания бизнес-логики** работы с платежами.

---

### [03-nowpayments-integration.md](./03-nowpayments-integration.md)
**Интеграция с NowPayments**

Содержит:
- Особенности NowPayments API
- Парсинг валют (токен+сеть в одном коде)
- API endpoints провайдера
- Configuration и settings
- Error handling
- Testing в sandbox

**Для backend разработчиков** - детали работы с провайдером.

---

### [04-migration-guide.md](./04-migration-guide.md)
**Гайд по миграции**

Содержит:
- Стратегия миграции (параллельное приложение)
- Пошаговый план создания новой структуры
- Миграция моделей
- Миграция провайдера
- Создание API
- Тестирование
- Переключение
- Rollback план

**Для DevOps и backend** - как выполнить миграцию безопасно.

---

### [05-withdrawal-system.md](./05-withdrawal-system.md)
**Система выводов средств**

Содержит:
- Модель WithdrawalRequest
- API endpoints для выводов
- Manual withdrawal flow (admin обрабатывает вручную)
- Расчет комиссий
- Валидация адресов кошельков
- Security & rate limiting
- Frontend UI примеры

**Для полного функционала** - как юзеры могут выводить средства.

---

### [06-improvements-best-practices.md](./06-improvements-best-practices.md)
**Улучшения и Best Practices**

Содержит:
- Обработка partial payments (95% threshold)
- Retry logic для API (tenacity)
- Rate limiting для polling (exponential backoff)
- Улучшенная валидация адресов
- Idempotency middleware
- Error handling
- Structured logging

**Production-ready features** - что добавить для надежности.

---

## Quick Start

### 1. Прочитать документацию в порядке:

```
00-refactoring-plan.md            ← Начать здесь (общая картина)
   ↓
01-api-specification.md           ← API для фронтенда
   ↓
02-flow-description.md            ← Бизнес-логика
   ↓
03-nowpayments-integration.md    ← Детали провайдера
   ↓
04-migration-guide.md             ← Как мигрировать
   ↓
05-withdrawal-system.md           ← Система выводов
   ↓
06-improvements-best-practices.md ← Production improvements
   ↓
07-flow-diagrams.md               ← Mermaid диаграммы процессов
   ↓
08-pydantic-models-guide.md       ← Pydantic v2 guide (обязательно!)
   ↓
09-payments-old-navigator.md      ← Навигатор по payments_old
```

### 2. Начать имплементацию:

```bash
# Phase 1: Создать структуру
cd src/django_cfg/apps/
mkdir -p payments/{models,api,services,admin,tests}

# Phase 2: Создать модели (см. migration-guide.md)

# Phase 3: Адаптировать провайдер

# Phase 4: Создать API

# Phase 5: Тесты

# Phase 6: Миграция данных (если нужно)

# Phase 7: Переключение

# Phase 8: Cleanup
```

## Ключевые изменения

### Что убрали:
- ❌ Вебхуки (webhook_views.py, webhook_middleware.py)
- ❌ API Keys система (api_keys.py, api_access_middleware.py)
- ❌ Тарифы и подписки (tariffs.py, subscriptions.py)
- ❌ Избыточные сервисы (686-line error_handler.py, fallback_service.py)
- ❌ Несколько провайдеров (cryptapi, cryptomus)
- ❌ Overview dashboard

### Что упростили:
- ✅ UniversalPayment → Payment (меньше полей)
- ✅ ProviderRegistry (минималистичный)
- ✅ Error handling (простые исключения)
- ✅ Модель Currency (без ProviderCurrency)

### Что добавили:
- ✅ Простое API для фронтенда
- ✅ Polling вместо вебхуков
- ✅ ORM-based расчет баланса
- ✅ Поддержка частичной оплаты
- ✅ Кеширование списка валют (только прод)

## User Flow

```
1. Юзер запрашивает список валют
   GET /api/v1/payments/currencies/

2. Юзер выбирает валюту и сумму
   POST /api/v1/payments/create/
   → Получает адрес для оплаты + QR

3. Юзер отправляет крипту на адрес

4. Фронт делает polling статуса
   GET /api/v1/payments/{id}/status/?refresh=true
   (каждые 10 секунд)

5. Юзер нажимает "Я оплатил"
   POST /api/v1/payments/{id}/confirm/

6. Бэк проверяет в NowPayments:
   - Если completed → создает Transaction deposit
   - Если pending → возвращает "подождите"
   - Если partially_paid → "обратитесь в support"

7. Баланс обновляется (вычисляется через ORM)
   GET /api/v1/payments/balance/
```

## API Endpoints (краткий список)

### Платежи (Deposits)
| Method | Endpoint | Описание |
|--------|----------|----------|
| GET | `/currencies/` | Список валют (кешируется на проде) |
| POST | `/create/` | Создать платеж |
| GET | `/{id}/status/` | Статус платежа |
| POST | `/{id}/confirm/` | Подтвердить оплату |
| GET | `/` | Список платежей юзера |

### Выводы (Withdrawals)
| Method | Endpoint | Описание |
|--------|----------|----------|
| POST | `/withdrawals/create/` | Создать запрос на вывод |
| GET | `/withdrawals/` | Список выводов |
| GET | `/withdrawals/{id}/` | Детали вывода |
| POST | `/withdrawals/{id}/cancel/` | Отменить вывод |

### Баланс & Транзакции
| Method | Endpoint | Описание |
|--------|----------|----------|
| GET | `/balance/` | Баланс юзера |
| GET | `/transactions/` | История транзакций |

## Технологии

- **Framework**: Django 4.x
- **DRF**: Django REST Framework
- **Provider**: NowPayments
- **Database**: PostgreSQL
- **Cache**: Redis (для списка валют)
- **HTTP Client**: httpx
- **Validation**: Pydantic

## Estimates

- **Сложность**: Medium
- **Время**: ~8.5 дней
- **Риск**: Low (параллельная миграция)
- **Rollback**: Easy (feature flag)

## Next Steps

1. **Review документации** - прочитать все 4 файла
2. **Создать задачи в Jira/GitHub** - на основе migration guide
3. **Setup dev environment** - настроить NowPayments sandbox
4. **Start Phase 1** - создать структуру директорий
5. **Implement incrementally** - по фазам из migration guide
6. **Test thoroughly** - unit + integration tests
7. **Deploy to staging** - тестирование на staging
8. **Monitor & iterate** - мониторинг на production

## Questions?

Если есть вопросы по плану рефакторинга:
1. Проверь соответствующий .md файл
2. Посмотри примеры кода в документации
3. Проверь payments_old/ для референса
4. Задай вопрос в команде

## Contributors

- **Plan Author**: Claude (Reformer AI)
- **Based on**: payments_old codebase analysis
- **Date**: 2025-01-14
- **Version**: 1.0

---

**Happy refactoring! 🚀**
