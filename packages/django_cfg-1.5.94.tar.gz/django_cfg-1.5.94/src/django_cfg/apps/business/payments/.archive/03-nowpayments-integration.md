# NowPayments Integration

## Общая информация

**Провайдер**: NowPayments
**Документация**: https://documenter.getpostman.com/view/7907941/S1a32n38
**API Base URL**:
- Production: `https://api.nowpayments.io/v1/`
- Sandbox: `https://api-sandbox.nowpayments.io/v1/`

## Особенности NowPayments

### Токен+Сеть в одном коде

NowPayments использует комбинированные коды валют:
- `USDTTRC20` = USDT на сети TRC20 (Tron)
- `USDTERC20` = USDT на сети ERC20 (Ethereum)
- `USDTBSC` = USDT на сети BSC (Binance Smart Chain)
- `BTC` = Bitcoin (только одна сеть)

**Важно**: Каждая комбинация токен+сеть - это отдельная "валюта" в NowPayments API.

### Парсинг валют

Нужно корректно парсить provider_currency_code на:
- `base_currency` (USDT, BTC, ETH)
- `network` (TRC20, ERC20, BSC, Bitcoin)

Пример логики:
```python
def parse_currency_code(provider_code: str) -> tuple[str, str]:
    """
    Парсит код валюты NowPayments.

    USDTTRC20 -> ('USDT', 'TRC20')
    USDTERC20 -> ('USDT', 'ERC20')
    BTC -> ('BTC', 'Bitcoin')
    """
    code = provider_code.upper()

    # Известные паттерны сетей
    networks = ['TRC20', 'ERC20', 'BEP20', 'BSC', 'POLYGON', 'ARBITRUM', 'OPTIMISM']

    for network in networks:
        if code.endswith(network):
            base_currency = code[:-len(network)]
            return (base_currency, network)

    # Если нет сети в коде - значит это основная сеть
    # Например BTC, ETH, LTC
    network_map = {
        'BTC': 'Bitcoin',
        'ETH': 'Ethereum',
        'LTC': 'Litecoin',
        'DOGE': 'Dogecoin',
        'TRX': 'Tron'
    }

    return (code, network_map.get(code, code))
```

## API Endpoints

### 1. Получить список валют

```http
GET /v1/full-currencies
X-Api-Key: {API_KEY}
```

**Response**:
```json
{
  "currencies": [
    {
      "code": "USDTTRC20",
      "name": "Tether USD (TRC20)",
      "enable": true,
      "is_popular": true,
      "is_stable": true,
      "logo_url": "https://nowpayments.io/images/coins/usdt.svg",
      "network": "trc20",
      "ticker": "usdt",
      "priority": 100,
      "available_for_payment": true,
      "available_for_payout": true
    }
  ]
}
```

**Mapping к нашей модели**:
```python
UniversalCurrency(
    provider_currency_code='USDTTRC20',
    base_currency_code='USDT',
    network_code='TRC20',
    name='Tether USD (TRC20)',
    currency_type='crypto',
    is_enabled=True,
    is_popular=True,
    is_stable=True,
    logo_url='...',
    priority=100
)
```

### 2. Создать платеж

```http
POST /v1/payment
X-Api-Key: {API_KEY}
Content-Type: application/json

{
  "price_amount": 100.50,
  "price_currency": "USD",
  "pay_currency": "USDTTRC20",
  "order_id": "PAY_20250101120000_abcd1234",
  "order_description": "Deposit payment"
}
```

**Response**:
```json
{
  "payment_id": "5123456789",
  "payment_status": "waiting",
  "pay_address": "TXYZabc123456...",
  "price_amount": 100.50,
  "price_currency": "usd",
  "pay_amount": 100.234567,
  "pay_currency": "usdttrc20",
  "order_id": "PAY_20250101120000_abcd1234",
  "order_description": "Deposit payment",
  "created_at": "2025-01-01T12:00:00.000Z",
  "updated_at": "2025-01-01T12:00:00.000Z",
  "expiration_estimate_date": "2025-01-01T12:30:00.000Z"
}
```

**Mapping к нашей модели**:
```python
payment.provider_payment_id = response['payment_id']
payment.pay_address = response['pay_address']
payment.pay_amount = Decimal(str(response['pay_amount']))
payment.expires_at = parse_datetime(response['expiration_estimate_date'])
payment.provider_data = response  # полный ответ для отладки
```

### 3. Проверить статус платежа

```http
GET /v1/payment/{payment_id}
X-Api-Key: {API_KEY}
```

**Response**:
```json
{
  "payment_id": "5123456789",
  "payment_status": "finished",
  "pay_address": "TXYZabc123456...",
  "price_amount": 100.50,
  "price_currency": "usd",
  "pay_amount": 100.234567,
  "actually_paid": 100.234567,
  "pay_currency": "usdttrc20",
  "order_id": "PAY_20250101120000_abcd1234",
  "order_description": "Deposit payment",
  "purchase_id": "5123456789",
  "outcome_amount": 100.45,
  "outcome_currency": "usd",
  "payin_hash": "0xabcdef123456...",
  "created_at": "2025-01-01T12:00:00.000Z",
  "updated_at": "2025-01-01T12:15:00.000Z"
}
```

**Status mapping**:
```python
STATUS_MAPPING = {
    'waiting': 'pending',         # Ожидает оплаты
    'confirming': 'confirming',   # Идет подтверждение
    'confirmed': 'confirmed',     # Подтверждено (но еще не finished)
    'finished': 'completed',      # Завершено
    'failed': 'failed',          # Не удалось
    'refunded': 'refunded',      # Возврат
    'expired': 'expired',        # Истекло
    'partially_paid': 'partially_paid'  # Частичная оплата
}
```

**Mapping к нашей модели**:
```python
payment.status = STATUS_MAPPING.get(response['payment_status'], 'pending')
payment.transaction_hash = response.get('payin_hash')
payment.actual_amount_usd = response.get('outcome_amount')

# Если есть actually_paid - можем проверить частичную оплату
if response.get('actually_paid'):
    actually_paid_crypto = Decimal(str(response['actually_paid']))
    expected_crypto = payment.pay_amount

    if actually_paid_crypto < expected_crypto:
        payment.status = 'partially_paid'
```

## Provider Configuration

### Settings

```python
# settings/production.py
NOWPAYMENTS_CONFIG = {
    'api_key': env('NOWPAYMENTS_API_KEY'),
    'api_url': 'https://api.nowpayments.io/v1/',
    'sandbox': False,
    'min_amount_usd': 1.0,
    'max_amount_usd': 50000.0,
    'payment_expiration_minutes': 30
}

# settings/development.py
NOWPAYMENTS_CONFIG = {
    'api_key': env('NOWPAYMENTS_SANDBOX_API_KEY'),
    'api_url': 'https://api-sandbox.nowpayments.io/v1/',
    'sandbox': True,
    'min_amount_usd': 0.01,  # меньше для тестов
    'max_amount_usd': 10000.0,
    'payment_expiration_minutes': 10  # короче для тестов
}
```

### Environment variables

```bash
# Production
NOWPAYMENTS_API_KEY=your_production_api_key

# Development
NOWPAYMENTS_SANDBOX_API_KEY=your_sandbox_api_key
```

## Provider Implementation

### NowPaymentsConfig

```python
from pydantic import BaseModel, Field, SecretStr
from decimal import Decimal

class NowPaymentsConfig(BaseModel):
    """Configuration for NowPayments provider."""

    api_key: SecretStr
    api_url: str = Field(default='https://api.nowpayments.io/v1/')
    sandbox: bool = Field(default=False)
    timeout: int = Field(default=30)

    # Limits
    min_amount_usd: Decimal = Field(default=Decimal('1.0'))
    max_amount_usd: Decimal = Field(default=Decimal('50000.0'))

    # Expiration
    payment_expiration_minutes: int = Field(default=30)

    class Config:
        frozen = True  # immutable
```

### NowPaymentsProvider

```python
from typing import Optional
import httpx
from decimal import Decimal

class NowPaymentsProvider(BaseProvider):
    """NowPayments cryptocurrency payment provider."""

    name = 'nowpayments'

    STATUS_MAPPING = {
        'waiting': 'pending',
        'confirming': 'confirming',
        'confirmed': 'confirmed',
        'finished': 'completed',
        'failed': 'failed',
        'refunded': 'refunded',
        'expired': 'expired',
        'partially_paid': 'partially_paid'
    }

    def __init__(self, config: NowPaymentsConfig):
        self.config = config
        self.client = httpx.Client(
            base_url=config.api_url,
            timeout=config.timeout,
            headers={
                'x-api-key': config.api_key.get_secret_value()
            }
        )

    def get_supported_currencies(self) -> list[dict]:
        """Get list of supported currencies from NowPayments."""
        response = self.client.get('/full-currencies')
        response.raise_for_status()

        data = response.json()
        return data.get('currencies', [])

    def create_payment(self, request: PaymentRequest) -> ProviderResponse:
        """Create payment with NowPayments."""
        payload = {
            'price_amount': float(request.amount_usd),
            'price_currency': 'USD',
            'pay_currency': request.currency_code,
            'order_id': request.order_id,
            'order_description': request.description or f'Payment {request.order_id}'
        }

        try:
            response = self.client.post('/payment', json=payload)
            response.raise_for_status()

            data = response.json()

            return ProviderResponse(
                success=True,
                provider_payment_id=data['payment_id'],
                status=self.STATUS_MAPPING.get(data['payment_status'], 'pending'),
                wallet_address=data['pay_address'],
                amount=Decimal(str(data['pay_amount'])),
                currency=request.currency_code,
                expires_at=self._parse_datetime(data.get('expiration_estimate_date')),
                raw_response=data
            )

        except httpx.HTTPStatusError as e:
            error_message = self._extract_error_message(e.response)
            return ProviderResponse(
                success=False,
                error_message=error_message,
                raw_response=e.response.json() if e.response else {}
            )

        except Exception as e:
            return ProviderResponse(
                success=False,
                error_message=str(e)
            )

    def get_payment_status(self, provider_payment_id: str) -> ProviderResponse:
        """Get payment status from NowPayments."""
        try:
            response = self.client.get(f'/payment/{provider_payment_id}')
            response.raise_for_status()

            data = response.json()

            return ProviderResponse(
                success=True,
                provider_payment_id=provider_payment_id,
                status=self.STATUS_MAPPING.get(data['payment_status'], 'pending'),
                wallet_address=data.get('pay_address'),
                amount=Decimal(str(data['pay_amount'])),
                actual_amount=Decimal(str(data.get('outcome_amount', 0))),
                transaction_hash=data.get('payin_hash'),
                raw_response=data
            )

        except httpx.HTTPStatusError as e:
            error_message = self._extract_error_message(e.response)
            return ProviderResponse(
                success=False,
                error_message=error_message
            )

        except Exception as e:
            return ProviderResponse(
                success=False,
                error_message=str(e)
            )

    def _extract_error_message(self, response) -> str:
        """Extract user-friendly error message from response."""
        try:
            data = response.json()
            return data.get('message', 'Unknown error')
        except:
            return f'HTTP {response.status_code}: {response.text}'

    def _parse_datetime(self, dt_string: Optional[str]) -> Optional[datetime]:
        """Parse NowPayments datetime string."""
        if not dt_string:
            return None

        try:
            return datetime.fromisoformat(dt_string.replace('Z', '+00:00'))
        except:
            return None
```

## Error Handling

### Common Errors

| Status Code | Error | Handling |
|-------------|-------|----------|
| 401 | Invalid API key | Check configuration |
| 400 | Invalid currency | Validate currency exists |
| 400 | Amount too low | Check min amount |
| 400 | Amount too high | Check max amount |
| 404 | Payment not found | Handle gracefully |
| 429 | Rate limit exceeded | Retry with backoff |
| 500 | Server error | Retry or show error |

### Example error response:

```json
{
  "statusCode": 400,
  "message": "Currency INVALIDCOIN is not available",
  "error": "Bad Request"
}
```

## Rate Limits

- **Standard plan**: 60 requests/minute
- **Pro plan**: 300 requests/minute

**Recommendation**: Кешируем список валют на 30 минут, чтобы не бить API часто.

## Testing

### Sandbox

NowPayments предоставляет sandbox для тестирования:
- URL: `https://api-sandbox.nowpayments.io/v1/`
- API Key: получить на https://sandbox.nowpayments.io

### Test currencies

В sandbox доступны тестовые валюты:
- `USDTTRC20`
- `BTC`
- `ETH`
- и другие

### Test payments

В sandbox можно создавать тестовые платежи, которые автоматически переходят в статус `finished` через несколько минут.

## Best Practices

1. **Always use provider_currency_code**: Храним оригинальный код от NowPayments (USDTTRC20)
2. **Parse on display**: Парсим на base_currency + network только для отображения
3. **Cache currencies**: Кешируем список валют на 30 минут (только прод)
4. **Validate amounts**: Всегда проверяем min/max суммы
5. **Handle partial payments**: Проверяем `actually_paid` vs `pay_amount`
6. **Store raw responses**: Сохраняем полный ответ в `provider_data` для отладки
7. **Retry logic**: Используем retry для временных ошибок (500, 429)
8. **Timeout**: Устанавливаем разумный timeout (30 секунд)
9. **Error logging**: Логируем все ошибки с контекстом

## Migration from payments_old

1. Убираем `ProviderCurrency` модель - не нужна
2. `Currency.code` = provider_currency_code (USDTTRC20)
3. Добавляем `base_currency` и `network` как computed properties
4. Убираем вебхук обработку
5. Упрощаем provider interface
