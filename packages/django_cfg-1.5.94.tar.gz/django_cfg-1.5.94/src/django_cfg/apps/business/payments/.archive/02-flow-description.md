# Описание флоу платежей

## Основной флоу пополнения баланса

### Шаг 1: Получение списка доступных валют

**Фронтенд**:
```javascript
// Запрос списка валют при загрузке страницы
const response = await fetch('/api/v1/payments/currencies/', {
  credentials: 'include'
});

const data = await response.json();
// data.currencies - список доступных валют

// Фильтрация популярных стейблкоинов
const popularStables = data.currencies.filter(c => c.is_popular && c.is_stable);

// Отображаем в UI: USDT (TRC20), USDT (ERC20), USDC, etc.
```

**Бэкенд**:
```python
# GET /api/v1/payments/currencies/
class CurrencyListView(APIView):
    """
    Возвращает список валют из NowPayments.

    - На проде: кешируется на 30 минут (через drf-extensions cache mixin)
    - На деве: без кеша
    """

    @conditional_cache_response(timeout=1800, env='production')
    def get(self, request):
        # Получаем валюты из NowPayments
        provider = get_nowpayments_provider()
        currencies_response = provider.get_parsed_currencies()

        # Фильтрация по query params
        currencies = filter_currencies(
            currencies_response.currencies,
            is_enabled=request.GET.get('is_enabled'),
            is_popular=request.GET.get('is_popular'),
            is_stable=request.GET.get('is_stable')
        )

        serializer = CurrencySerializer(currencies, many=True)
        return Response({
            'success': True,
            'count': len(currencies),
            'currencies': serializer.data
        })
```

---

### Шаг 2: Создание платежа

**Фронтенд**:
```javascript
// Юзер вводит сумму и выбирает валюту
const paymentData = {
  amount_usd: 100.50,
  currency_code: 'USDTTRC20',  // выбранная валюта
  description: 'Пополнение баланса'
};

const response = await fetch('/api/v1/payments/create/', {
  method: 'POST',
  credentials: 'include',
  headers: {
    'Content-Type': 'application/json',
    'X-CSRFToken': getCsrfToken()
  },
  body: JSON.stringify(paymentData)
});

const result = await response.json();

if (result.success) {
  // Показываем юзеру адрес для оплаты
  const payment = result.payment;

  // Отображаем:
  // - QR код: payment.qr_code_url
  // - Адрес: payment.pay_address (копировать)
  // - Сумму к оплате: payment.pay_amount + payment.currency_code
  // - Ссылку на explorer: payment.explorer_link
  // - Время истечения: payment.expires_at

  // Сохраняем payment_id для дальнейшей проверки
  currentPaymentId = payment.id;

  // Начинаем polling статуса
  startStatusPolling(payment.id);
}
```

**Бэкенд**:
```python
# POST /api/v1/payments/create/
class PaymentCreateView(APIView):
    """Создание нового платежа."""

    permission_classes = [IsAuthenticated]

    def post(self, request):
        serializer = PaymentCreateSerializer(data=request.data)
        if not serializer.is_valid():
            return Response({
                'success': False,
                'error': serializer.errors
            }, status=400)

        # Создаем платеж через сервис
        payment_service = PaymentService()

        try:
            payment = payment_service.create_payment(
                user=request.user,
                amount_usd=serializer.validated_data['amount_usd'],
                currency_code=serializer.validated_data['currency_code'],
                description=serializer.validated_data.get('description', '')
            )

            # Возвращаем данные платежа
            response_serializer = PaymentDetailSerializer(payment)
            return Response({
                'success': True,
                'payment': response_serializer.data
            }, status=201)

        except PaymentError as e:
            logger.error(f"Payment creation failed: {e}")
            return Response({
                'success': False,
                'error': str(e)
            }, status=500)
```

**PaymentService**:
```python
class PaymentService:
    """Сервис для работы с платежами."""

    def create_payment(self, user, amount_usd, currency_code, description=''):
        """Создать платеж через NowPayments."""

        # Валидация суммы
        if amount_usd < 1.0 or amount_usd > 50000.0:
            raise PaymentError("Amount must be between 1.0 and 50000.0")

        # Валидация валюты
        currency = Currency.objects.filter(
            code=currency_code,
            is_active=True
        ).first()

        if not currency:
            raise PaymentError(f"Invalid currency: {currency_code}")

        with transaction.atomic():
            # Создаем запись платежа
            payment = UniversalPayment.objects.create(
                user=user,
                amount_usd=amount_usd,
                currency=currency,
                status='pending',
                provider='nowpayments',
                description=description
            )

            # Запрос к NowPayments
            provider = get_nowpayments_provider()

            provider_request = PaymentRequest(
                amount_usd=amount_usd,
                currency_code=currency_code,
                order_id=payment.internal_payment_id,
                description=description
            )

            provider_response = provider.create_payment(provider_request)

            if not provider_response.success:
                payment.status = 'failed'
                payment.save()
                raise PaymentError(provider_response.error_message)

            # Обновляем платеж данными от провайдера
            payment.provider_payment_id = provider_response.provider_payment_id
            payment.pay_address = provider_response.wallet_address
            payment.pay_amount = provider_response.amount
            payment.expires_at = provider_response.expires_at
            payment.provider_data = provider_response.raw_response
            payment.save()

            return payment
```

---

### Шаг 3: Отображение платежной информации

**Фронтенд** показывает юзеру:

1. **QR код** для сканирования (payment.qr_code_url)
2. **Адрес для оплаты** с кнопкой копирования
3. **Сумму к оплате** в криптовалюте (payment.pay_amount + currency)
4. **Сумму в USD** (payment.amount_usd)
5. **Таймер** до истечения платежа (30 минут)
6. **Ссылку на explorer** для проверки транзакции
7. **Кнопку "Я оплатил"**

**UI Example**:
```
┌──────────────────────────────────────┐
│  Оплатите 100.234567 USDT (TRC20)   │
│                                      │
│  ┌─────────────┐                    │
│  │             │  [Сканируйте QR]   │
│  │   QR CODE   │                    │
│  │             │                    │
│  └─────────────┘                    │
│                                      │
│  Адрес:                              │
│  TXYZabc123...  [Копировать]        │
│                                      │
│  Сумма: $100.50 USD                 │
│  К оплате: 100.234567 USDT (TRC20)  │
│                                      │
│  ⏱ Истекает через: 25:34            │
│                                      │
│  [Проверить в Explorer]              │
│                                      │
│  [✓ Я оплатил]                      │
└──────────────────────────────────────┘
```

**Automatic polling**:
```javascript
// Автоматическая проверка статуса каждые 10 секунд
function startStatusPolling(paymentId) {
  const pollInterval = setInterval(async () => {
    const response = await fetch(
      `/api/v1/payments/${paymentId}/status/?refresh=true`,
      { credentials: 'include' }
    );

    const data = await response.json();

    if (data.success) {
      const payment = data.payment;

      // Обновляем UI
      updatePaymentStatus(payment.status);

      // Если платеж завершен - останавливаем polling
      if (payment.status === 'completed') {
        clearInterval(pollInterval);
        showSuccessMessage('Платеж успешно подтвержден!');
        redirectToBalance();
      }

      // Если истек - останавливаем polling
      if (payment.status === 'expired') {
        clearInterval(pollInterval);
        showErrorMessage('Время платежа истекло');
      }
    }
  }, 10000); // каждые 10 секунд
}
```

---

### Шаг 4: Юзер оплачивает

Юзер отправляет криптовалюту на указанный адрес используя:
- Свой криптокошелек (Metamask, Trust Wallet, etc.)
- Биржу (Binance, etc.)
- Сканирование QR кода

**Важно**: Юзер должен отправить **точную** сумму, указанную в `pay_amount`.

---

### Шаг 5: Подтверждение оплаты

**Вариант A: Автоматическое (через polling)**

Фронт делает автоматический polling каждые 10 секунд:
```javascript
// GET /api/v1/payments/{id}/status/?refresh=true
// Бэк проверяет статус в NowPayments и обновляет в БД
```

**Вариант B: Ручное (юзер нажимает кнопку)**

Юзер нажимает "Я оплатил":
```javascript
const response = await fetch(
  `/api/v1/payments/${paymentId}/confirm/`,
  {
    method: 'POST',
    credentials: 'include',
    headers: { 'X-CSRFToken': getCsrfToken() }
  }
);

const result = await response.json();

if (result.success) {
  // Платеж подтвержден
  showSuccessMessage('Платеж успешно подтвержден!');
  showBalanceUpdate(result.transaction.balance_after);
  redirectToBalance();
} else {
  // Платеж еще не подтвержден
  showInfoMessage(result.message);
  // Продолжаем polling
}
```

**Бэкенд**:
```python
# POST /api/v1/payments/{id}/confirm/
class PaymentConfirmView(APIView):
    """Проверка и подтверждение оплаты."""

    permission_classes = [IsAuthenticated]

    def post(self, request, payment_id):
        payment_service = PaymentService()

        try:
            # Проверяем статус через провайдер
            result = payment_service.confirm_payment(
                payment_id=payment_id,
                user=request.user
            )

            if result.success:
                # Платеж подтвержден
                return Response({
                    'success': True,
                    'payment': PaymentDetailSerializer(result.payment).data,
                    'transaction': TransactionSerializer(result.transaction).data,
                    'message': 'Payment confirmed successfully'
                })
            else:
                # Платеж еще не подтвержден
                return Response({
                    'success': False,
                    'payment': PaymentDetailSerializer(result.payment).data,
                    'message': result.message
                })

        except PaymentError as e:
            return Response({
                'success': False,
                'error': str(e)
            }, status=400)
```

**PaymentService.confirm_payment()**:
```python
def confirm_payment(self, payment_id, user):
    """
    Проверить статус платежа и создать транзакцию если подтвержден.
    """

    # Получаем платеж с блокировкой
    with transaction.atomic():
        payment = UniversalPayment.objects.select_for_update().get(
            id=payment_id,
            user=user
        )

        # Проверка что платеж еще не завершен
        if payment.status == 'completed':
            raise PaymentError("Payment already completed")

        # Проверка что платеж не истек
        if payment.is_expired:
            payment.status = 'expired'
            payment.save()
            raise PaymentError("Payment has expired")

        # Запрос к провайдеру
        provider = get_nowpayments_provider()
        status_response = provider.get_payment_status(
            payment.provider_payment_id
        )

        if not status_response.success:
            raise PaymentError("Failed to check payment status")

        # Обновляем данные платежа
        old_status = payment.status
        new_status = status_response.status

        payment.status = new_status
        payment.transaction_hash = status_response.transaction_hash
        payment.confirmations_count = status_response.confirmations_count

        if status_response.actual_amount:
            payment.actual_amount_usd = float(status_response.actual_amount)

        payment.provider_data.update(status_response.raw_response)
        payment.save()

        # Если платеж завершен - создаем транзакцию пополнения
        if new_status == 'completed' and old_status != 'completed':
            # Проверка на частичную оплату
            if payment.actual_amount_usd and payment.actual_amount_usd < payment.amount_usd:
                payment.status = 'partially_paid'
                payment.save()

                return ConfirmResult(
                    success=False,
                    payment=payment,
                    message=f'Partial payment received: ${payment.actual_amount_usd} of ${payment.amount_usd}'
                )

            # Создаем транзакцию пополнения
            deposit_transaction = Transaction.objects.create(
                user=user,
                transaction_type='deposit',
                amount_usd=payment.amount_usd,
                payment_id=payment.internal_payment_id,
                description=f'Deposit from payment {payment.internal_payment_id}'
            )

            # Обновляем баланс (вычисляется через ORM)
            balance = UserBalance.objects.get_or_create_for_user(user)

            payment.completed_at = timezone.now()
            payment.save()

            return ConfirmResult(
                success=True,
                payment=payment,
                transaction=deposit_transaction,
                message='Payment confirmed successfully'
            )

        # Платеж еще в процессе
        return ConfirmResult(
            success=False,
            payment=payment,
            message='Payment is still pending. Please wait.'
        )
```

---

### Шаг 6: Обновление баланса

Баланс вычисляется через ORM менеджер:

```python
class UserBalanceManager(models.Manager):
    """Менеджер для вычисления баланса через транзакции."""

    def get_or_create_for_user(self, user):
        """Получить или создать баланс для юзера."""
        balance, created = self.get_or_create(user=user)

        # Пересчитываем баланс из транзакций
        transactions = Transaction.objects.filter(user=user)

        total_deposited = transactions.filter(
            transaction_type='deposit'
        ).aggregate(
            total=Sum('amount_usd')
        )['total'] or 0.0

        total_withdrawn = transactions.filter(
            transaction_type='withdrawal'
        ).aggregate(
            total=Sum('amount_usd')
        )['total'] or 0.0

        balance.balance_usd = total_deposited - abs(total_withdrawn)
        balance.total_deposited = total_deposited
        balance.total_spent = abs(total_withdrawn)
        balance.save()

        return balance
```

---

## Обработка исключительных ситуаций

### Частичная оплата (Partial Payment)

Если юзер отправил меньше запрошенной суммы:

```python
if payment.actual_amount_usd < payment.amount_usd:
    payment.status = 'partially_paid'
    payment.save()

    # НЕ создаем транзакцию пополнения
    # Юзер должен обратиться в support

    return {
        'success': False,
        'message': f'Partial payment: ${actual} of ${expected}. Contact support.'
    }
```

**UI**: Показываем сообщение юзеру обратиться в поддержку.

### Истечение срока платежа

Платежи истекают через 30 минут (настройка NowPayments):

```python
if payment.is_expired:
    payment.status = 'expired'
    payment.save()

    return {
        'success': False,
        'message': 'Payment has expired. Please create a new payment.'
    }
```

**UI**: Предлагаем создать новый платеж.

### Провайдер недоступен

Если NowPayments API недоступен:

```python
try:
    response = provider.get_payment_status(payment_id)
except ProviderError as e:
    logger.error(f"Provider unavailable: {e}")

    return {
        'success': False,
        'error': 'Payment provider is temporarily unavailable. Try again later.'
    }
```

**UI**: Показываем сообщение попробовать позже.

---

## Диаграмма флоу

```
[Фронт] Запрос валют
   ↓
[Бэк] Получение из NowPayments (с кешем на проде)
   ↓
[Фронт] Юзер выбирает валюту и сумму
   ↓
[Фронт] POST /payments/create/
   ↓
[Бэк] Создание записи в БД + запрос к NowPayments
   ↓
[Бэк] Возврат payment с адресом и QR
   ↓
[Фронт] Отображение платежной информации + запуск polling
   ↓
[Юзер] Отправляет крипту на адрес
   ↓
[Фронт] Автоматический polling GET /payments/{id}/status/?refresh=true
   ↓
[Бэк] Проверка в NowPayments + обновление в БД
   ↓
[Если completed]
   ↓
[Бэк] Создание транзакции deposit
   ↓
[Бэк] Пересчет баланса через ORM
   ↓
[Фронт] Показ успешного сообщения + редирект на баланс
```

## Timing

- **Polling interval**: 10 секунд
- **Payment expiration**: 30 минут
- **Cache TTL** (currencies): 30 минут (только прод)
- **Transaction confirmation**: зависит от сети (TRC20 ~1 минута, Bitcoin ~10 минут)

## Security

- CSRF токен для всех POST запросов
- Django session authentication
- Permission check: юзер может видеть только свои платежи
- Atomic transactions для предотвращения race conditions
- Идемпотентность: повторный confirm не создает дубликаты транзакций
