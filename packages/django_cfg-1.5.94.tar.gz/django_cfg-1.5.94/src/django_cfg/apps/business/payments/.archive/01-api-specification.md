# API Спецификация - Payments v2.0

## Общая информация

**Base URL**: `/api/v1/payments/`

**Authentication**: Django session auth (юзер должен быть залогинен)

**Content-Type**: `application/json`

**Cache**: Только список валют кешируется (и только на проде через DRF cache mixin)

## Endpoints

### 1. Получить список доступных токенов и сетей

```http
GET /api/v1/payments/currencies/
```

**Описание**: Возвращает список всех доступных криптовалют и сетей для оплаты из NowPayments.

**Authentication**: Required

**Query Parameters**:
- `is_enabled` (optional, boolean) - фильтр по активным валютам
- `is_popular` (optional, boolean) - фильтр по популярным валютам
- `is_stable` (optional, boolean) - фильтр по стейблкоинам

**Cache**:
- **Production**: кешируется на 30 минут через DRF cache mixin
- **Development**: без кеша

**Response 200 OK**:
```json
{
  "success": true,
  "count": 150,
  "currencies": [
    {
      "code": "USDTTRC20",
      "base_currency": "USDT",
      "network": "TRC20",
      "name": "Tether USD (TRC20)",
      "currency_type": "crypto",
      "is_enabled": true,
      "is_popular": true,
      "is_stable": true,
      "logo_url": "https://nowpayments.io/images/coins/usdt.svg",
      "priority": 100
    },
    {
      "code": "USDTERC20",
      "base_currency": "USDT",
      "network": "ERC20",
      "name": "Tether USD (ERC20)",
      "currency_type": "crypto",
      "is_enabled": true,
      "is_popular": true,
      "is_stable": true,
      "logo_url": "https://nowpayments.io/images/coins/usdt.svg",
      "priority": 90
    },
    {
      "code": "BTC",
      "base_currency": "BTC",
      "network": "Bitcoin",
      "name": "Bitcoin",
      "currency_type": "crypto",
      "is_enabled": true,
      "is_popular": true,
      "is_stable": false,
      "logo_url": "https://nowpayments.io/images/coins/btc.svg",
      "priority": 95
    }
  ]
}
```

**Response 401 Unauthorized**:
```json
{
  "success": false,
  "error": "Authentication required"
}
```

**Response 500 Internal Server Error**:
```json
{
  "success": false,
  "error": "Failed to fetch currencies from provider"
}
```

---

### 2. Создать платеж

```http
POST /api/v1/payments/create/
```

**Описание**: Создает новый платеж. Юзер указывает сумму в USD, выбирает токен+сеть. Бэк создает платеж в NowPayments и в БД.

**Authentication**: Required

**Request Body**:
```json
{
  "amount_usd": 100.50,
  "currency_code": "USDTTRC20",
  "description": "Пополнение баланса"
}
```

**Validation**:
- `amount_usd`: min=1.0, max=50000.0
- `currency_code`: должен быть в списке доступных валют
- `description`: optional, max_length=500

**Response 201 Created**:
```json
{
  "success": true,
  "payment": {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "internal_payment_id": "PAY_20250101120000_abcd1234",
    "status": "pending",
    "amount_usd": 100.50,
    "currency_code": "USDTTRC20",
    "pay_address": "TXYZabc123...",
    "pay_amount": "100.234567",
    "qr_code_url": "https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=TXYZabc123...",
    "explorer_link": "https://tronscan.org/#/address/TXYZabc123...",
    "expires_at": "2025-01-01T12:30:00Z",
    "created_at": "2025-01-01T12:00:00Z"
  }
}
```

**Response 400 Bad Request**:
```json
{
  "success": false,
  "error": "Invalid amount. Must be between 1.0 and 50000.0",
  "field": "amount_usd"
}
```

**Response 401 Unauthorized**:
```json
{
  "success": false,
  "error": "Authentication required"
}
```

**Response 500 Internal Server Error**:
```json
{
  "success": false,
  "error": "Provider error: NowPayments service is temporarily unavailable"
}
```

---

### 3. Получить статус платежа

```http
GET /api/v1/payments/{payment_id}/status/
```

**Описание**: Возвращает текущий статус платежа из БД и опционально обновляет его из NowPayments.

**Authentication**: Required

**Path Parameters**:
- `payment_id` (UUID) - ID платежа

**Query Parameters**:
- `refresh` (optional, boolean, default=false) - обновить статус из провайдера

**Response 200 OK** (payment pending):
```json
{
  "success": true,
  "payment": {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "internal_payment_id": "PAY_20250101120000_abcd1234",
    "status": "pending",
    "amount_usd": 100.50,
    "currency_code": "USDTTRC20",
    "pay_address": "TXYZabc123...",
    "pay_amount": "100.234567",
    "qr_code_url": "https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=TXYZabc123...",
    "explorer_link": "https://tronscan.org/#/address/TXYZabc123...",
    "transaction_hash": null,
    "confirmations_count": 0,
    "expires_at": "2025-01-01T12:30:00Z",
    "created_at": "2025-01-01T12:00:00Z"
  }
}
```

**Response 200 OK** (payment completed):
```json
{
  "success": true,
  "payment": {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "internal_payment_id": "PAY_20250101120000_abcd1234",
    "status": "completed",
    "amount_usd": 100.50,
    "actual_amount_usd": 100.50,
    "currency_code": "USDTTRC20",
    "pay_address": "TXYZabc123...",
    "pay_amount": "100.234567",
    "transaction_hash": "0xabcdef123456...",
    "confirmations_count": 20,
    "explorer_link": "https://tronscan.org/#/transaction/0xabcdef123456...",
    "completed_at": "2025-01-01T12:15:00Z",
    "created_at": "2025-01-01T12:00:00Z"
  }
}
```

**Response 404 Not Found**:
```json
{
  "success": false,
  "error": "Payment not found"
}
```

**Response 403 Forbidden**:
```json
{
  "success": false,
  "error": "You don't have permission to view this payment"
}
```

---

### 4. Подтвердить оплату

```http
POST /api/v1/payments/{payment_id}/confirm/
```

**Описание**: Юзер нажимает "Я оплатил" - бэк проверяет статус через NowPayments. Если оплата подтверждена, создается транзакция пополнения.

**Authentication**: Required

**Path Parameters**:
- `payment_id` (UUID) - ID платежа

**Response 200 OK** (payment confirmed):
```json
{
  "success": true,
  "payment": {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "status": "completed",
    "amount_usd": 100.50,
    "actual_amount_usd": 100.50,
    "transaction_hash": "0xabcdef123456...",
    "completed_at": "2025-01-01T12:15:00Z"
  },
  "transaction": {
    "id": "660e8400-e29b-41d4-a716-446655440001",
    "type": "deposit",
    "amount_usd": 100.50,
    "balance_after": 250.75,
    "created_at": "2025-01-01T12:15:00Z"
  },
  "message": "Payment confirmed successfully. Balance updated."
}
```

**Response 200 OK** (payment still pending):
```json
{
  "success": false,
  "payment": {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "status": "pending",
    "amount_usd": 100.50
  },
  "message": "Payment is still pending. Please wait or try again later."
}
```

**Response 200 OK** (partial payment):
```json
{
  "success": false,
  "payment": {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "status": "partially_paid",
    "amount_usd": 100.50,
    "actual_amount_usd": 50.25,
    "transaction_hash": "0xabcdef123456..."
  },
  "message": "Partial payment received. Expected: $100.50, received: $50.25. Please contact support."
}
```

**Response 404 Not Found**:
```json
{
  "success": false,
  "error": "Payment not found"
}
```

**Response 403 Forbidden**:
```json
{
  "success": false,
  "error": "You don't have permission to confirm this payment"
}
```

**Response 400 Bad Request**:
```json
{
  "success": false,
  "error": "Payment is already completed"
}
```

---

### 5. Получить баланс

```http
GET /api/v1/payments/balance/
```

**Описание**: Возвращает текущий баланс юзера. Баланс вычисляется через ORM агрегацию транзакций.

**Authentication**: Required

**Response 200 OK**:
```json
{
  "success": true,
  "balance": {
    "amount_usd": 250.75,
    "total_deposited": 500.00,
    "total_withdrawn": 249.25,
    "last_transaction_at": "2025-01-01T12:15:00Z"
  }
}
```

**Response 401 Unauthorized**:
```json
{
  "success": false,
  "error": "Authentication required"
}
```

---

### 6. Получить историю транзакций

```http
GET /api/v1/payments/transactions/
```

**Описание**: Возвращает историю транзакций пополнений и выводов.

**Authentication**: Required

**Query Parameters**:
- `type` (optional) - фильтр по типу (deposit, withdrawal)
- `limit` (optional, default=20, max=100) - количество записей
- `offset` (optional, default=0) - смещение для пагинации

**Response 200 OK**:
```json
{
  "success": true,
  "count": 45,
  "next": "/api/v1/payments/transactions/?limit=20&offset=20",
  "previous": null,
  "results": [
    {
      "id": "660e8400-e29b-41d4-a716-446655440001",
      "type": "deposit",
      "amount_usd": 100.50,
      "balance_after": 250.75,
      "description": "Deposit from payment PAY_20250101120000_abcd1234",
      "payment_id": "550e8400-e29b-41d4-a716-446655440000",
      "created_at": "2025-01-01T12:15:00Z"
    },
    {
      "id": "660e8400-e29b-41d4-a716-446655440002",
      "type": "withdrawal",
      "amount_usd": -50.00,
      "balance_after": 150.25,
      "description": "Withdrawal to wallet",
      "payment_id": null,
      "created_at": "2025-01-01T10:00:00Z"
    }
  ]
}
```

**Response 401 Unauthorized**:
```json
{
  "success": false,
  "error": "Authentication required"
}
```

---

### 7. Получить список платежей юзера

```http
GET /api/v1/payments/
```

**Описание**: Возвращает список всех платежей текущего юзера.

**Authentication**: Required

**Query Parameters**:
- `status` (optional) - фильтр по статусу (pending, completed, failed, expired)
- `limit` (optional, default=20, max=100)
- `offset` (optional, default=0)

**Response 200 OK**:
```json
{
  "success": true,
  "count": 12,
  "next": null,
  "previous": null,
  "results": [
    {
      "id": "550e8400-e29b-41d4-a716-446655440000",
      "internal_payment_id": "PAY_20250101120000_abcd1234",
      "status": "completed",
      "amount_usd": 100.50,
      "currency_code": "USDTTRC20",
      "created_at": "2025-01-01T12:00:00Z",
      "completed_at": "2025-01-01T12:15:00Z"
    },
    {
      "id": "550e8400-e29b-41d4-a716-446655440001",
      "internal_payment_id": "PAY_20250101100000_xyz789",
      "status": "expired",
      "amount_usd": 50.00,
      "currency_code": "BTC",
      "created_at": "2025-01-01T10:00:00Z",
      "expires_at": "2025-01-01T10:30:00Z"
    }
  ]
}
```

---

### 8. Создать запрос на вывод

```http
POST /api/v1/payments/withdrawals/create/
```

**Описание**: Создает запрос на вывод средств. Админ обработает вручную.

**Authentication**: Required

**Request Body**:
```json
{
  "amount_usd": 100.00,
  "currency_code": "USDTTRC20",
  "wallet_address": "TXYZabc123..."
}
```

**Validation**:
- `amount_usd`: min=10.0, max=current balance
- `currency_code`: должен быть в списке доступных валют
- `wallet_address`: валидный адрес кошелька для выбранной сети

**Response 201 Created**:
```json
{
  "success": true,
  "withdrawal": {
    "id": "770e8400-e29b-41d4-a716-446655440000",
    "amount_usd": 100.00,
    "currency_code": "USDTTRC20",
    "wallet_address": "TXYZabc123...",
    "status": "pending",
    "fees": {
      "network_fee": 1.00,
      "service_fee": 2.00,
      "total_fee": 3.00
    },
    "final_amount_usd": 97.00,
    "created_at": "2025-01-14T12:00:00Z"
  },
  "message": "Withdrawal request created. Awaiting admin approval."
}
```

**Response 400 Bad Request**:
```json
{
  "success": false,
  "error": "Insufficient balance. Available: $50.00, requested: $100.00"
}
```

---

### 9. Получить список выводов

```http
GET /api/v1/payments/withdrawals/
```

**Описание**: Возвращает список всех запросов на вывод текущего юзера.

**Authentication**: Required

**Query Parameters**:
- `status` (optional) - фильтр по статусу
- `limit` (optional, default=20, max=100)
- `offset` (optional, default=0)

**Response 200 OK**:
```json
{
  "success": true,
  "count": 3,
  "results": [
    {
      "id": "770e8400-e29b-41d4-a716-446655440000",
      "amount_usd": 100.00,
      "currency_code": "USDTTRC20",
      "wallet_address": "TXYZabc123...",
      "status": "completed",
      "transaction_hash": "0xabcdef...",
      "explorer_link": "https://tronscan.org/#/transaction/0xabcdef...",
      "final_amount_usd": 97.00,
      "created_at": "2025-01-14T12:00:00Z",
      "completed_at": "2025-01-14T13:00:00Z"
    }
  ]
}
```

---

### 10. Получить детали вывода

```http
GET /api/v1/payments/withdrawals/{id}/
```

**Response 200 OK**:
```json
{
  "success": true,
  "withdrawal": {
    "id": "770e8400-e29b-41d4-a716-446655440000",
    "amount_usd": 100.00,
    "currency_code": "USDTTRC20",
    "wallet_address": "TXYZabc123...",
    "status": "approved",
    "fees": {
      "network_fee": 1.00,
      "service_fee": 2.00,
      "total_fee": 3.00
    },
    "final_amount_usd": 97.00,
    "crypto_amount": "96.8",
    "created_at": "2025-01-14T12:00:00Z",
    "approved_at": "2025-01-14T12:30:00Z"
  }
}
```

---

### 11. Отменить вывод

```http
POST /api/v1/payments/withdrawals/{id}/cancel/
```

**Описание**: Отменить запрос на вывод (только если статус pending).

**Response 200 OK**:
```json
{
  "success": true,
  "withdrawal": {
    "id": "770e8400-e29b-41d4-a716-446655440000",
    "status": "cancelled"
  }
}
```

---

## Статусы платежей

| Status | Описание |
|--------|----------|
| `pending` | Платеж создан, ожидает оплаты |
| `confirming` | Оплата получена, идет подтверждение в блокчейне |
| `completed` | Платеж успешно завершен, баланс пополнен |
| `partially_paid` | Получена частичная оплата (меньше запрошенной суммы) |
| `failed` | Платеж не удался |
| `expired` | Истек срок действия платежа (30 минут) |
| `cancelled` | Платеж отменен юзером или админом |

## Типы транзакций

| Type | Описание |
|------|----------|
| `deposit` | Пополнение баланса (из успешного платежа) |
| `withdrawal` | Вывод средств |

## Статусы выводов

| Status | Описание |
|--------|----------|
| `pending` | Ожидает проверки администратором |
| `approved` | Одобрено, ожидает отправки |
| `processing` | В процессе отправки |
| `completed` | Завершено, средства отправлены |
| `rejected` | Отклонено администратором |
| `cancelled` | Отменено юзером |

## Error Codes

| Code | Message | HTTP Status |
|------|---------|-------------|
| `auth_required` | Authentication required | 401 |
| `permission_denied` | You don't have permission | 403 |
| `not_found` | Resource not found | 404 |
| `invalid_amount` | Invalid amount | 400 |
| `invalid_currency` | Invalid currency code | 400 |
| `payment_expired` | Payment has expired | 400 |
| `payment_completed` | Payment already completed | 400 |
| `provider_error` | Provider service error | 500 |
| `internal_error` | Internal server error | 500 |

## Rate Limiting

- **Anonymous users**: 10 requests/minute
- **Authenticated users**: 60 requests/minute
- **Premium users**: 300 requests/minute

## Notes

1. **Кеширование**: Только список валют кешируется на проде (30 минут)
2. **Баланс**: Вычисляется в реальном времени через ORM, не кешируется
3. **Polling**: Фронт может делать polling статуса каждые 5-10 секунд
4. **Expiration**: Платежи истекают через 30 минут (настройка провайдера)
5. **Partial payments**: Если юзер отправил меньше, статус "partially_paid", нужно обращаться в support
