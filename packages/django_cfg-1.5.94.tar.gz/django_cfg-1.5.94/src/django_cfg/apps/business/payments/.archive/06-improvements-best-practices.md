# Улучшения и Best Practices

## Обзор

Этот документ содержит важные улучшения базового функционала, которые нужно учесть при реализации.

## 1. Обработка частичных платежей (Partial Payments)

### Проблема
Из-за волатильности крипты юзер может отправить чуть меньше чем нужно (например, 99.95 USDT вместо 100 USDT).

### Решение

```python
# payments/services/payment_service.py

class PaymentService:

    PARTIAL_PAYMENT_THRESHOLD = Decimal('0.95')  # 95%

    def confirm_payment(self, payment_id, user):
        """Проверить и подтвердить платеж."""

        with transaction.atomic():
            payment = UniversalPayment.objects.select_for_update().get(
                id=payment_id,
                user=user
            )

            # ... проверка статуса ...

            # Запрос к провайдеру
            provider = get_nowpayments_provider()
            status_response = provider.get_payment_status(
                payment.provider_payment_id
            )

            # Обновляем данные
            payment.status = status_response.status
            payment.actual_amount_usd = status_response.actual_amount_usd
            payment.save()

            # Проверка завершения
            if payment.status == 'completed':
                return self._process_completed_payment(payment)

            return ConfirmResult(
                success=False,
                payment=payment,
                message='Payment is still pending'
            )

    def _process_completed_payment(self, payment):
        """Обработка завершенного платежа с учетом partial payments."""

        expected_amount = payment.amount_usd
        actual_amount = payment.actual_amount_usd or expected_amount

        # Вычисляем процент оплаты
        payment_ratio = actual_amount / expected_amount

        # Логика обработки частичной оплаты
        if payment_ratio < self.PARTIAL_PAYMENT_THRESHOLD:
            # Меньше 95% - слишком мало
            payment.status = 'partially_paid'
            payment.save()

            # Уведомление админа
            self._notify_admin_partial_payment(payment, actual_amount, expected_amount)

            return ConfirmResult(
                success=False,
                payment=payment,
                message=(
                    f'Partial payment received: ${actual_amount:.2f} of ${expected_amount:.2f}. '
                    f'Please contact support to resolve this issue.'
                )
            )

        elif payment_ratio < Decimal('1.0'):
            # 95-100% - close enough, засчитываем
            # Сохраняем разницу как "комиссию/потери"
            payment.fee_amount_usd = expected_amount - actual_amount
            payment.status = 'completed'
            payment.completed_at = timezone.now()
            payment.save()

            # Создаем транзакцию на фактическую сумму
            transaction = Transaction.objects.create(
                user=payment.user,
                transaction_type='deposit',
                amount_usd=actual_amount,
                payment_id=payment.internal_payment_id,
                description=f'Deposit from payment {payment.internal_payment_id}'
            )

            return ConfirmResult(
                success=True,
                payment=payment,
                transaction=transaction,
                message=f'Payment completed. Credited: ${actual_amount:.2f}'
            )

        else:
            # 100%+ - полная оплата или переплата
            payment.status = 'completed'
            payment.completed_at = timezone.now()
            payment.save()

            # Если переплата - кредитуем фактическую сумму
            credit_amount = min(actual_amount, expected_amount)  # или actual_amount если хотим зачислить переплату

            transaction = Transaction.objects.create(
                user=payment.user,
                transaction_type='deposit',
                amount_usd=credit_amount,
                payment_id=payment.internal_payment_id,
                description=f'Deposit from payment {payment.internal_payment_id}'
            )

            return ConfirmResult(
                success=True,
                payment=payment,
                transaction=transaction,
                message='Payment completed successfully'
            )

    def _notify_admin_partial_payment(self, payment, actual_amount, expected_amount):
        """Уведомление админа о частичной оплате."""
        from django.core.mail import mail_admins

        mail_admins(
            subject=f'Partial Payment Alert - {payment.internal_payment_id}',
            message=(
                f'User: {payment.user.username} ({payment.user.email})\n'
                f'Payment ID: {payment.internal_payment_id}\n'
                f'Expected: ${expected_amount:.2f}\n'
                f'Received: ${actual_amount:.2f}\n'
                f'Difference: ${(expected_amount - actual_amount):.2f}\n\n'
                f'Action required: Contact user or issue refund.'
            )
        )
```

### UI для partial payments

```javascript
// Frontend handling
if (!result.success && result.payment.status === 'partially_paid') {
  showAlert({
    type: 'warning',
    title: 'Partial Payment Received',
    message: result.message,
    actions: [
      { label: 'Contact Support', onClick: () => openSupportChat() },
      { label: 'View Details', onClick: () => showPaymentDetails(result.payment) }
    ]
  });
}
```

---

## 2. Retry Logic для NowPayments API

### Проблема
NowPayments API может быть временно недоступен или вернуть timeout.

### Решение

```python
# payments/services/providers/nowpayments/client.py

import httpx
from tenacity import (
    retry,
    stop_after_attempt,
    wait_exponential,
    retry_if_exception_type,
    retry_if_result
)

class NowPaymentsClient:
    """HTTP client для NowPayments с retry logic."""

    def __init__(self, config: NowPaymentsConfig):
        self.config = config
        self.client = httpx.Client(
            base_url=config.api_url,
            timeout=httpx.Timeout(30.0, connect=10.0),
            headers={
                'x-api-key': config.api_key.get_secret_value(),
                'Content-Type': 'application/json'
            }
        )

    def _is_retryable_status(response):
        """Проверка что статус подходит для retry."""
        return response is not None and response.status_code in [429, 500, 502, 503, 504]

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=10),
        retry=(
            retry_if_exception_type((httpx.TimeoutException, httpx.NetworkError)) |
            retry_if_result(_is_retryable_status)
        ),
        reraise=True
    )
    def get(self, endpoint: str, **kwargs):
        """GET request с автоматическим retry."""
        try:
            response = self.client.get(endpoint, **kwargs)

            # Для 429 (rate limit) делаем retry
            if response.status_code == 429:
                retry_after = int(response.headers.get('Retry-After', 60))
                logger.warning(f"Rate limit hit, waiting {retry_after}s")
                time.sleep(retry_after)
                return response  # Trigger retry

            response.raise_for_status()
            return response

        except httpx.TimeoutException as e:
            logger.warning(f"Request timeout for {endpoint}, retrying...")
            raise

        except httpx.NetworkError as e:
            logger.warning(f"Network error for {endpoint}, retrying...")
            raise

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=10),
        retry=(
            retry_if_exception_type((httpx.TimeoutException, httpx.NetworkError)) |
            retry_if_result(_is_retryable_status)
        ),
        reraise=True
    )
    def post(self, endpoint: str, **kwargs):
        """POST request с автоматическим retry."""
        try:
            response = self.client.post(endpoint, **kwargs)

            if response.status_code == 429:
                retry_after = int(response.headers.get('Retry-After', 60))
                logger.warning(f"Rate limit hit, waiting {retry_after}s")
                time.sleep(retry_after)
                return response

            response.raise_for_status()
            return response

        except httpx.TimeoutException as e:
            logger.warning(f"Request timeout for {endpoint}, retrying...")
            raise

        except httpx.NetworkError as e:
            logger.warning(f"Network error for {endpoint}, retrying...")
            raise
```

### Обработка в Provider

```python
# payments/services/providers/nowpayments/provider.py

class NowPaymentsProvider(BaseProvider):

    def create_payment(self, request: PaymentRequest) -> ProviderResponse:
        """Create payment with retry logic."""

        try:
            response = self.client.post('/payment', json={
                'price_amount': float(request.amount_usd),
                'price_currency': 'USD',
                'pay_currency': request.currency_code,
                'order_id': request.order_id,
                'order_description': request.description
            })

            data = response.json()

            return ProviderResponse(
                success=True,
                provider_payment_id=data['payment_id'],
                # ... остальные поля ...
            )

        except httpx.HTTPStatusError as e:
            # Non-retryable error (400, 401, 404, etc.)
            error_msg = self._extract_error_message(e.response)
            logger.error(f"NowPayments error: {error_msg}", extra={
                'status_code': e.response.status_code,
                'order_id': request.order_id
            })

            return ProviderResponse(
                success=False,
                error_message=error_msg
            )

        except (httpx.TimeoutException, httpx.NetworkError) as e:
            # Все retry исчерпаны
            logger.error(f"NowPayments unavailable after retries: {e}")

            return ProviderResponse(
                success=False,
                error_message='Payment provider is temporarily unavailable. Please try again later.'
            )

        except Exception as e:
            logger.exception("Unexpected error in NowPayments")

            return ProviderResponse(
                success=False,
                error_message='An unexpected error occurred. Please contact support.'
            )
```

---

## 3. Rate Limiting для Polling

### Проблема
Если много юзеров делают polling одновременно, можем упереться в rate limit NowPayments (60 req/min).

### Решение 1: Экспоненциальный backoff

```javascript
// Frontend: умный polling с backoff

class PaymentPoller {
  constructor(paymentId) {
    this.paymentId = paymentId;
    this.interval = 10000; // начинаем с 10 секунд
    this.maxInterval = 60000; // максимум 60 секунд
    this.backoffMultiplier = 1.5;
    this.pollCount = 0;
  }

  async start() {
    while (true) {
      try {
        const response = await fetch(
          `/api/v1/payments/${this.paymentId}/status/?refresh=true`
        );

        const data = await response.json();

        if (data.success) {
          this.updateUI(data.payment);

          // Если completed - останавливаем
          if (data.payment.status === 'completed') {
            this.onCompleted(data.payment);
            break;
          }

          // Если expired - останавливаем
          if (data.payment.status === 'expired') {
            this.onExpired(data.payment);
            break;
          }

          // Увеличиваем интервал после каждого запроса
          this.pollCount++;
          if (this.pollCount > 5) {
            this.interval = Math.min(
              this.interval * this.backoffMultiplier,
              this.maxInterval
            );
          }
        }

        // Ждем перед следующим запросом
        await this.sleep(this.interval);

      } catch (error) {
        console.error('Polling error:', error);
        // При ошибке увеличиваем интервал
        this.interval = Math.min(this.interval * 2, this.maxInterval);
        await this.sleep(this.interval);
      }
    }
  }

  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// Usage
const poller = new PaymentPoller(paymentId);
poller.start();
```

### Решение 2: Server-side кеширование статуса

```python
# payments/api/views.py

from django.core.cache import cache

class PaymentStatusView(APIView):
    """Get payment status with caching."""

    permission_classes = [IsAuthenticated]

    def get(self, request, payment_id):
        # Check permission
        payment = get_object_or_404(Payment, id=payment_id, user=request.user)

        refresh = request.GET.get('refresh', 'false').lower() == 'true'

        # Кеш на 5 секунд для reduce API calls
        cache_key = f'payment_status:{payment_id}'

        if not refresh:
            cached_status = cache.get(cache_key)
            if cached_status:
                return Response(cached_status)

        # Если нужен refresh или нет кеша - запрашиваем у провайдера
        if refresh and payment.status not in ['completed', 'expired', 'cancelled']:
            payment_service = PaymentService()
            try:
                # Обновляем статус из провайдера
                provider = get_nowpayments_provider()
                status_response = provider.get_payment_status(
                    payment.provider_payment_id
                )

                if status_response.success:
                    payment.status = status_response.status
                    payment.transaction_hash = status_response.transaction_hash
                    payment.actual_amount_usd = status_response.actual_amount_usd
                    payment.save()

            except Exception as e:
                logger.error(f"Failed to refresh payment status: {e}")
                # Возвращаем текущий статус из БД

        # Serialize response
        serializer = PaymentDetailSerializer(payment)
        response_data = {
            'success': True,
            'payment': serializer.data
        }

        # Кешируем на 5 секунд
        cache.set(cache_key, response_data, 5)

        return Response(response_data)
```

---

## 4. Улучшенная валидация адресов кошельков

```python
# payments/validators.py

import re
from decimal import Decimal

class WalletAddressValidator:
    """Валидация адресов криптокошельков."""

    @staticmethod
    def validate(address: str, currency_code: str) -> tuple[bool, str]:
        """
        Валидация адреса кошелька.

        Returns:
            (is_valid, error_message)
        """
        code = currency_code.upper()

        # Tron (TRC20) addresses
        if 'TRC20' in code or 'TRX' in code:
            return WalletAddressValidator._validate_tron(address)

        # Ethereum (ERC20) addresses
        if 'ERC20' in code or 'ETH' in code:
            return WalletAddressValidator._validate_ethereum(address)

        # BSC addresses
        if 'BSC' in code or 'BEP20' in code or 'BNB' in code:
            return WalletAddressValidator._validate_bsc(address)

        # Bitcoin addresses
        if code == 'BTC':
            return WalletAddressValidator._validate_bitcoin(address)

        # Fallback: basic validation
        if len(address) < 26:
            return False, "Wallet address is too short"

        if len(address) > 100:
            return False, "Wallet address is too long"

        return True, ""

    @staticmethod
    def _validate_tron(address: str) -> tuple[bool, str]:
        """Validate Tron address."""
        if not address.startswith('T'):
            return False, "Tron address must start with 'T'"

        if len(address) != 34:
            return False, "Tron address must be 34 characters"

        if not re.match(r'^T[1-9A-HJ-NP-Za-km-z]{33}$', address):
            return False, "Invalid Tron address format"

        return True, ""

    @staticmethod
    def _validate_ethereum(address: str) -> tuple[bool, str]:
        """Validate Ethereum address."""
        if not address.startswith('0x'):
            return False, "Ethereum address must start with '0x'"

        if len(address) != 42:
            return False, "Ethereum address must be 42 characters"

        if not re.match(r'^0x[0-9a-fA-F]{40}$', address):
            return False, "Invalid Ethereum address format"

        return True, ""

    @staticmethod
    def _validate_bsc(address: str) -> tuple[bool, str]:
        """Validate BSC address (same as Ethereum)."""
        return WalletAddressValidator._validate_ethereum(address)

    @staticmethod
    def _validate_bitcoin(address: str) -> tuple[bool, str]:
        """Validate Bitcoin address."""
        # P2PKH (starts with 1)
        # P2SH (starts with 3)
        # Bech32 (starts with bc1)

        if not address.startswith(('1', '3', 'bc1')):
            return False, "Invalid Bitcoin address format"

        if len(address) < 26 or len(address) > 62:
            return False, "Bitcoin address must be 26-62 characters"

        # Basic format check
        if address.startswith('bc1'):
            if not re.match(r'^bc1[a-z0-9]{39,59}$', address):
                return False, "Invalid Bitcoin Bech32 address"
        else:
            if not re.match(r'^[13][1-9A-HJ-NP-Za-km-z]{25,61}$', address):
                return False, "Invalid Bitcoin address"

        return True, ""


# Usage in service
class WithdrawalService:

    def create_withdrawal_request(self, user, amount_usd, currency_code, wallet_address):
        # Validate wallet address
        is_valid, error = WalletAddressValidator.validate(wallet_address, currency_code)

        if not is_valid:
            raise ValidationError(error)

        # ... continue ...
```

---

## 5. Idempotency для API requests

```python
# payments/middleware/idempotency.py

from django.core.cache import cache
from django.http import JsonResponse
import hashlib
import json

class IdempotencyMiddleware:
    """
    Middleware для идемпотентности POST запросов.

    Клиент отправляет Idempotency-Key header.
    Если запрос с таким ключом уже был обработан - возвращаем кешированный ответ.
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        # Только для POST запросов к платежам
        if request.method == 'POST' and '/api/v1/payments/' in request.path:
            idempotency_key = request.headers.get('Idempotency-Key')

            if idempotency_key:
                # Проверяем кеш
                cache_key = f'idempotency:{idempotency_key}'
                cached_response = cache.get(cache_key)

                if cached_response:
                    # Возвращаем кешированный ответ
                    return JsonResponse(
                        cached_response['data'],
                        status=cached_response['status']
                    )

                # Обрабатываем запрос
                response = self.get_response(request)

                # Кешируем успешный ответ на 24 часа
                if response.status_code in [200, 201]:
                    cache.set(cache_key, {
                        'data': json.loads(response.content),
                        'status': response.status_code
                    }, timeout=86400)  # 24 hours

                return response

        return self.get_response(request)
```

### Frontend usage

```javascript
// Generate idempotency key
import { v4 as uuidv4 } from 'uuid';

async function createPayment(data) {
  const idempotencyKey = uuidv4();

  const response = await fetch('/api/v1/payments/create/', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Idempotency-Key': idempotencyKey,
      'X-CSRFToken': getCsrfToken()
    },
    credentials: 'include',
    body: JSON.stringify(data)
  });

  return response.json();
}

// При повторной попытке (например, network error) -
// отправляем тот же idempotency key
// Получим тот же результат без создания дубликата
```

---

## 6. Improved Error Messages

```python
# payments/exceptions.py

class PaymentError(Exception):
    """Base payment error."""

    def __init__(self, message: str, code: str = None, user_message: str = None):
        self.message = message
        self.code = code or 'payment_error'
        self.user_message = user_message or message
        super().__init__(message)


class InsufficientBalanceError(PaymentError):
    """Insufficient balance for operation."""

    def __init__(self, required: Decimal, available: Decimal):
        super().__init__(
            message=f"Insufficient balance: required ${required}, available ${available}",
            code='insufficient_balance',
            user_message=f"Insufficient balance. You need ${required} but only have ${available}"
        )
        self.required = required
        self.available = available


class InvalidCurrencyError(PaymentError):
    """Invalid or unsupported currency."""

    def __init__(self, currency_code: str):
        super().__init__(
            message=f"Invalid currency: {currency_code}",
            code='invalid_currency',
            user_message=f"The currency '{currency_code}' is not supported"
        )
        self.currency_code = currency_code


class ProviderError(PaymentError):
    """Provider API error."""

    def __init__(self, provider: str, message: str, original_error: str = None):
        super().__init__(
            message=f"{provider} error: {message}",
            code='provider_error',
            user_message=f"Payment provider is experiencing issues: {message}"
        )
        self.provider = provider
        self.original_error = original_error


# Usage in views
@api_view(['POST'])
def payment_create_view(request):
    try:
        # ... create payment ...
        return Response({'success': True, 'payment': payment_data})

    except InsufficientBalanceError as e:
        return Response({
            'success': False,
            'error': e.user_message,
            'code': e.code,
            'details': {
                'required': float(e.required),
                'available': float(e.available)
            }
        }, status=400)

    except InvalidCurrencyError as e:
        return Response({
            'success': False,
            'error': e.user_message,
            'code': e.code
        }, status=400)

    except ProviderError as e:
        logger.error(f"Provider error: {e.message}", extra={
            'provider': e.provider,
            'original_error': e.original_error
        })

        return Response({
            'success': False,
            'error': e.user_message,
            'code': e.code
        }, status=503)

    except Exception as e:
        logger.exception("Unexpected error in payment creation")

        return Response({
            'success': False,
            'error': 'An unexpected error occurred. Please try again or contact support.',
            'code': 'internal_error'
        }, status=500)
```

---

## 7. Logging Best Practices

```python
# payments/logging.py

import logging
from functools import wraps

logger = logging.getLogger('payments')

def log_payment_operation(operation_name: str):
    """Decorator для логирования операций с платежами."""

    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            # Extract useful context
            context = {
                'operation': operation_name,
                'user_id': kwargs.get('user_id') or (args[1].id if len(args) > 1 else None),
            }

            logger.info(f"Starting {operation_name}", extra=context)

            try:
                result = func(*args, **kwargs)
                logger.info(f"Completed {operation_name}", extra={
                    **context,
                    'success': True
                })
                return result

            except Exception as e:
                logger.error(f"Failed {operation_name}: {e}", extra={
                    **context,
                    'success': False,
                    'error': str(e)
                })
                raise

        return wrapper
    return decorator


# Usage
class PaymentService:

    @log_payment_operation('create_payment')
    def create_payment(self, user, amount_usd, currency_code):
        # ... implementation ...
        pass

    @log_payment_operation('confirm_payment')
    def confirm_payment(self, payment_id, user):
        # ... implementation ...
        pass
```

---

## Summary

Эти улучшения решают основные проблемы:

1. ✅ **Partial payments** - засчитываем если > 95%, иначе support
2. ✅ **Retry logic** - автоматический retry при network errors и rate limits
3. ✅ **Rate limiting** - экспоненциальный backoff + server-side кеш
4. ✅ **Address validation** - proper validation для всех типов адресов
5. ✅ **Idempotency** - защита от дубликатов при повторных запросах
6. ✅ **Better errors** - понятные сообщения для юзеров
7. ✅ **Structured logging** - для отладки и мониторинга

Все эти улучшения можно добавлять постепенно, они не критичны для MVP но сильно улучшат production readiness.
