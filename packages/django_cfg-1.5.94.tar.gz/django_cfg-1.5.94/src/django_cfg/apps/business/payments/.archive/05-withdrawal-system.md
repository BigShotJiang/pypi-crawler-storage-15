# Система выводов средств

## Обзор

Механизм вывода средств позволяет юзерам выводить баланс на свои криптокошельки.

**Важно**: Выводы обрабатываются вручную администратором для безопасности. Автоматические выводы можно добавить позже.

## Типы выводов

### 1. Manual Withdrawal (v1.0 - MVP)
- Юзер создает запрос на вывод
- Администратор проверяет и одобряет
- Администратор отправляет крипту вручную
- Администратор подтверждает отправку с tx hash

### 2. Automatic Withdrawal (v2.0 - будущее)
- Интеграция с NowPayments Payouts API
- Автоматическая отправка криптовалюты
- Требует верификации юзера (KYC)

## Модели данных

### WithdrawalRequest

```python
# payments/models/withdrawal.py
from django.db import models
from django.contrib.auth import get_user_model
from decimal import Decimal
import uuid

User = get_user_model()

class WithdrawalRequest(models.Model):
    """Запрос на вывод средств."""

    class Status(models.TextChoices):
        PENDING = 'pending', 'Pending Review'
        APPROVED = 'approved', 'Approved'
        PROCESSING = 'processing', 'Processing'
        COMPLETED = 'completed', 'Completed'
        REJECTED = 'rejected', 'Rejected'
        CANCELLED = 'cancelled', 'Cancelled'

    # Identity
    id = models.UUIDField(primary_key=True, default=uuid.uuid4)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='withdrawal_requests')

    # Amount
    amount_usd = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        help_text="Amount to withdraw in USD"
    )

    # Crypto details
    currency_code = models.CharField(
        max_length=20,
        help_text="Cryptocurrency code (e.g., USDTTRC20, BTC)"
    )

    wallet_address = models.CharField(
        max_length=255,
        help_text="Destination wallet address"
    )

    # Calculated crypto amount (filled by admin before processing)
    crypto_amount = models.DecimalField(
        max_digits=20,
        decimal_places=8,
        null=True,
        blank=True,
        help_text="Amount in cryptocurrency"
    )

    # Status
    status = models.CharField(
        max_length=20,
        choices=Status.choices,
        default=Status.PENDING,
        db_index=True
    )

    # Transaction details (filled after processing)
    transaction_hash = models.CharField(
        max_length=256,
        blank=True,
        help_text="Blockchain transaction hash"
    )

    # Fees
    network_fee_usd = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=0,
        help_text="Network fee in USD"
    )

    service_fee_usd = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=0,
        help_text="Service fee in USD"
    )

    total_fee_usd = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=0,
        help_text="Total fees in USD"
    )

    # Final amount after fees
    final_amount_usd = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        help_text="Final amount after fees"
    )

    # Admin notes
    admin_notes = models.TextField(
        blank=True,
        help_text="Internal notes for admins"
    )

    rejection_reason = models.TextField(
        blank=True,
        help_text="Reason for rejection (visible to user)"
    )

    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    approved_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)

    # Relations
    approved_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='approved_withdrawals'
    )

    processed_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='processed_withdrawals'
    )

    class Meta:
        db_table = 'withdrawal_requests_v2'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['user', 'status']),
            models.Index(fields=['status', 'created_at']),
            models.Index(fields=['transaction_hash']),
        ]

    def __str__(self):
        return f"Withdrawal {self.id} - ${self.amount_usd} {self.status}"

    @property
    def explorer_link(self):
        """Generate blockchain explorer link."""
        if not self.transaction_hash:
            return None

        # Parse network from currency_code
        network = self._get_network()

        explorer_urls = {
            'TRC20': f'https://tronscan.org/#/transaction/{self.transaction_hash}',
            'ERC20': f'https://etherscan.io/tx/{self.transaction_hash}',
            'BTC': f'https://blockstream.info/tx/{self.transaction_hash}',
            'BSC': f'https://bscscan.com/tx/{self.transaction_hash}',
        }

        return explorer_urls.get(network)

    def _get_network(self):
        """Extract network from currency_code."""
        code = self.currency_code.upper()
        if 'TRC20' in code:
            return 'TRC20'
        elif 'ERC20' in code:
            return 'ERC20'
        elif 'BSC' in code or 'BEP20' in code:
            return 'BSC'
        elif code == 'BTC':
            return 'BTC'
        return None

    def calculate_fees(self):
        """Calculate fees for withdrawal."""
        # Network fees (примерные значения)
        network_fees = {
            'TRC20': Decimal('1.00'),   # ~1 USDT fee on Tron
            'ERC20': Decimal('15.00'),  # ~15 USDT fee on Ethereum
            'BSC': Decimal('0.50'),     # ~0.5 USDT fee on BSC
            'BTC': Decimal('10.00'),    # ~10 USD fee on Bitcoin
        }

        network = self._get_network()
        self.network_fee_usd = network_fees.get(network, Decimal('5.00'))

        # Service fee: 1% или минимум $2
        self.service_fee_usd = max(
            self.amount_usd * Decimal('0.01'),  # 1%
            Decimal('2.00')  # minimum $2
        )

        self.total_fee_usd = self.network_fee_usd + self.service_fee_usd
        self.final_amount_usd = self.amount_usd - self.total_fee_usd

        return {
            'network_fee': self.network_fee_usd,
            'service_fee': self.service_fee_usd,
            'total_fee': self.total_fee_usd,
            'final_amount': self.final_amount_usd
        }
```

## API Endpoints

### 1. Создать запрос на вывод

```http
POST /api/v1/payments/withdrawals/create/
```

**Request**:
```json
{
  "amount_usd": 100.00,
  "currency_code": "USDTTRC20",
  "wallet_address": "TXYZabc123..."
}
```

**Validation**:
- Минимальная сумма: $10
- Максимальная сумма: текущий баланс
- Валидация формата адреса кошелька
- Проверка что у юзера достаточно баланса

**Response 201 Created**:
```json
{
  "success": true,
  "withdrawal": {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "amount_usd": 100.00,
    "currency_code": "USDTTRC20",
    "wallet_address": "TXYZabc123...",
    "status": "pending",
    "fees": {
      "network_fee": 1.00,
      "service_fee": 2.00,
      "total_fee": 3.00
    },
    "final_amount_usd": 97.00,
    "created_at": "2025-01-14T12:00:00Z"
  },
  "message": "Withdrawal request created. Awaiting admin approval."
}
```

**Response 400 Bad Request**:
```json
{
  "success": false,
  "error": "Insufficient balance. Available: $50.00, requested: $100.00"
}
```

---

### 2. Получить список выводов

```http
GET /api/v1/payments/withdrawals/
```

**Query Parameters**:
- `status` (optional) - фильтр по статусу
- `limit` (default=20)
- `offset` (default=0)

**Response 200 OK**:
```json
{
  "success": true,
  "count": 5,
  "results": [
    {
      "id": "550e8400-e29b-41d4-a716-446655440000",
      "amount_usd": 100.00,
      "currency_code": "USDTTRC20",
      "wallet_address": "TXYZabc123...",
      "status": "completed",
      "transaction_hash": "0xabcdef...",
      "explorer_link": "https://tronscan.org/#/transaction/0xabcdef...",
      "fees": {
        "total_fee": 3.00
      },
      "final_amount_usd": 97.00,
      "created_at": "2025-01-14T12:00:00Z",
      "completed_at": "2025-01-14T13:00:00Z"
    }
  ]
}
```

---

### 3. Получить детали вывода

```http
GET /api/v1/payments/withdrawals/{id}/
```

**Response 200 OK**:
```json
{
  "success": true,
  "withdrawal": {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "amount_usd": 100.00,
    "currency_code": "USDTTRC20",
    "wallet_address": "TXYZabc123...",
    "status": "approved",
    "transaction_hash": null,
    "explorer_link": null,
    "fees": {
      "network_fee": 1.00,
      "service_fee": 2.00,
      "total_fee": 3.00
    },
    "final_amount_usd": 97.00,
    "crypto_amount": "96.8",
    "created_at": "2025-01-14T12:00:00Z",
    "approved_at": "2025-01-14T12:30:00Z",
    "completed_at": null
  }
}
```

---

### 4. Отменить вывод (юзер)

```http
POST /api/v1/payments/withdrawals/{id}/cancel/
```

Только для статуса `pending`.

**Response 200 OK**:
```json
{
  "success": true,
  "withdrawal": {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "status": "cancelled"
  },
  "message": "Withdrawal request cancelled"
}
```

**Response 400 Bad Request**:
```json
{
  "success": false,
  "error": "Cannot cancel withdrawal in status 'processing'"
}
```

## Admin API (для обработки выводов)

### 1. Одобрить вывод

```http
POST /api/v1/admin/withdrawals/{id}/approve/
```

**Request**:
```json
{
  "crypto_amount": 96.8,
  "admin_notes": "Verified wallet address"
}
```

**Response 200 OK**:
```json
{
  "success": true,
  "withdrawal": {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "status": "approved",
    "crypto_amount": "96.8",
    "approved_at": "2025-01-14T12:30:00Z"
  }
}
```

---

### 2. Отклонить вывод

```http
POST /api/v1/admin/withdrawals/{id}/reject/
```

**Request**:
```json
{
  "reason": "Invalid wallet address format"
}
```

**Response 200 OK**:
```json
{
  "success": true,
  "withdrawal": {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "status": "rejected",
    "rejection_reason": "Invalid wallet address format"
  }
}
```

---

### 3. Подтвердить отправку (после отправки крипты)

```http
POST /api/v1/admin/withdrawals/{id}/complete/
```

**Request**:
```json
{
  "transaction_hash": "0xabcdef123456...",
  "admin_notes": "Sent from main wallet"
}
```

**Response 200 OK**:
```json
{
  "success": true,
  "withdrawal": {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "status": "completed",
    "transaction_hash": "0xabcdef123456...",
    "completed_at": "2025-01-14T13:00:00Z"
  },
  "transaction": {
    "id": "660e8400-e29b-41d4-a716-446655440001",
    "type": "withdrawal",
    "amount_usd": -100.00,
    "balance_after": 150.00
  }
}
```

## Флоу вывода

### User Side:

```
1. Юзер открывает страницу вывода
   GET /api/v1/payments/balance/
   → Показываем доступный баланс

2. Юзер выбирает валюту и вводит сумму
   → Показываем калькуляцию комиссий:
     Amount: $100
     Network fee: $1
     Service fee: $2
     Total fee: $3
     You will receive: $97 (~96.8 USDT)

3. Юзер вводит адрес кошелька и подтверждает
   POST /api/v1/payments/withdrawals/create/

4. Статус меняется: pending → approved → processing → completed

5. Юзер получает уведомление когда completed
   + ссылка на explorer для проверки транзакции
```

### Admin Side:

```
1. Админ видит новый запрос в админке (status=pending)

2. Админ проверяет:
   - Валидность адреса кошелька
   - Баланс юзера
   - Историю юзера (нет ли подозрительной активности)

3. Админ одобряет:
   POST /api/v1/admin/withdrawals/{id}/approve/

   Или отклоняет:
   POST /api/v1/admin/withdrawals/{id}/reject/

4. Если одобрено - админ отправляет крипту вручную
   (из hot wallet или биржи)

5. Админ получает tx hash и подтверждает:
   POST /api/v1/admin/withdrawals/{id}/complete/

6. Создается Transaction withdrawal в БД
   Баланс юзера уменьшается
```

## Service Layer

```python
# payments/services/withdrawal_service.py
from decimal import Decimal
from django.db import transaction
from django.utils import timezone

class WithdrawalService:
    """Service для обработки выводов."""

    def create_withdrawal_request(self, user, amount_usd, currency_code, wallet_address):
        """Создать запрос на вывод."""

        # Validate amount
        if amount_usd < Decimal('10.00'):
            raise ValidationError("Minimum withdrawal amount is $10")

        # Check balance
        balance_service = BalanceService()
        balance = balance_service.get_user_balance(user)

        if balance['balance_usd'] < amount_usd:
            raise ValidationError(
                f"Insufficient balance. Available: ${balance['balance_usd']}, "
                f"requested: ${amount_usd}"
            )

        # Validate wallet address
        if not self._is_valid_wallet_address(wallet_address, currency_code):
            raise ValidationError("Invalid wallet address format")

        with transaction.atomic():
            # Create withdrawal request
            withdrawal = WithdrawalRequest.objects.create(
                user=user,
                amount_usd=amount_usd,
                currency_code=currency_code,
                wallet_address=wallet_address,
                status=WithdrawalRequest.Status.PENDING
            )

            # Calculate fees
            withdrawal.calculate_fees()
            withdrawal.save()

            return withdrawal

    def approve_withdrawal(self, withdrawal_id, admin_user, crypto_amount, admin_notes=''):
        """Одобрить вывод (admin action)."""

        with transaction.atomic():
            withdrawal = WithdrawalRequest.objects.select_for_update().get(
                id=withdrawal_id
            )

            if withdrawal.status != WithdrawalRequest.Status.PENDING:
                raise ValidationError(
                    f"Cannot approve withdrawal in status '{withdrawal.status}'"
                )

            withdrawal.status = WithdrawalRequest.Status.APPROVED
            withdrawal.crypto_amount = crypto_amount
            withdrawal.approved_by = admin_user
            withdrawal.approved_at = timezone.now()
            withdrawal.admin_notes = admin_notes
            withdrawal.save()

            return withdrawal

    def complete_withdrawal(self, withdrawal_id, admin_user, transaction_hash, admin_notes=''):
        """Подтвердить завершение вывода (admin action)."""

        with transaction.atomic():
            withdrawal = WithdrawalRequest.objects.select_for_update().get(
                id=withdrawal_id
            )

            if withdrawal.status not in [
                WithdrawalRequest.Status.APPROVED,
                WithdrawalRequest.Status.PROCESSING
            ]:
                raise ValidationError(
                    f"Cannot complete withdrawal in status '{withdrawal.status}'"
                )

            # Update withdrawal
            withdrawal.status = WithdrawalRequest.Status.COMPLETED
            withdrawal.transaction_hash = transaction_hash
            withdrawal.processed_by = admin_user
            withdrawal.completed_at = timezone.now()
            if admin_notes:
                withdrawal.admin_notes += f"\n{admin_notes}"
            withdrawal.save()

            # Create withdrawal transaction
            withdrawal_transaction = Transaction.objects.create(
                user=withdrawal.user,
                transaction_type=Transaction.Type.WITHDRAWAL,
                amount_usd=-withdrawal.amount_usd,  # negative for withdrawal
                payment_id=str(withdrawal.id),
                description=f"Withdrawal to {withdrawal.wallet_address} ({withdrawal.currency_code})"
            )

            # Update user balance (recalculate from transactions)
            balance = UserBalance.objects.get_or_create_for_user(withdrawal.user)
            balance.refresh_from_transactions()

            return withdrawal, withdrawal_transaction

    def _is_valid_wallet_address(self, address, currency_code):
        """Validate wallet address format."""
        code = currency_code.upper()

        # Tron (TRC20) addresses
        if 'TRC20' in code:
            return address.startswith('T') and len(address) == 34

        # Ethereum (ERC20) addresses
        if 'ERC20' in code or 'BSC' in code:
            return address.startswith('0x') and len(address) == 42

        # Bitcoin addresses
        if code == 'BTC':
            return (
                address.startswith(('1', '3', 'bc1')) and
                26 <= len(address) <= 62
            )

        # Default validation
        return len(address) >= 26
```

## Security & Validations

### 1. Rate Limiting
```python
# Max 3 withdrawal requests per day per user
if WithdrawalRequest.objects.filter(
    user=user,
    created_at__gte=timezone.now() - timedelta(days=1)
).count() >= 3:
    raise ValidationError("Maximum 3 withdrawal requests per day")
```

### 2. Suspicious Activity Detection
```python
# Flag suspicious withdrawals for manual review
if amount_usd > 1000:  # Large amount
    withdrawal.requires_kyc = True
    send_admin_alert("Large withdrawal request", withdrawal)

# New user
if user.date_joined > timezone.now() - timedelta(days=7):
    send_admin_alert("Withdrawal from new user", withdrawal)

# Different wallet each time
recent_withdrawals = WithdrawalRequest.objects.filter(
    user=user,
    status=WithdrawalRequest.Status.COMPLETED
).order_by('-completed_at')[:5]

wallet_addresses = set(w.wallet_address for w in recent_withdrawals)
if len(wallet_addresses) > 3:
    send_admin_alert("Multiple different wallets", withdrawal)
```

### 3. Wallet Address Whitelist (опционально)
```python
class UserWallet(models.Model):
    """Verified wallet addresses for user."""
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    currency_code = models.CharField(max_length=20)
    wallet_address = models.CharField(max_length=255)
    is_verified = models.BooleanField(default=False)
    verified_at = models.DateTimeField(null=True)

# Only allow withdrawals to verified wallets
if not UserWallet.objects.filter(
    user=user,
    wallet_address=wallet_address,
    is_verified=True
).exists():
    raise ValidationError("Please add and verify this wallet address first")
```

## Notifications

### Email to User:
```python
# On creation
send_email(
    user.email,
    subject="Withdrawal Request Received",
    template="withdrawal_created.html",
    context={'withdrawal': withdrawal}
)

# On approval
send_email(
    user.email,
    subject="Withdrawal Approved - Processing",
    template="withdrawal_approved.html",
    context={'withdrawal': withdrawal}
)

# On completion
send_email(
    user.email,
    subject="Withdrawal Completed",
    template="withdrawal_completed.html",
    context={
        'withdrawal': withdrawal,
        'explorer_link': withdrawal.explorer_link
    }
)
```

### Telegram/Slack to Admin:
```python
# New withdrawal request
send_admin_notification(
    f"💰 New withdrawal request\n"
    f"User: {user.username}\n"
    f"Amount: ${amount_usd}\n"
    f"Currency: {currency_code}\n"
    f"Address: {wallet_address}"
)
```

## Frontend UI

```javascript
// Withdrawal form with fee calculation
const WithdrawalForm = () => {
  const [amount, setAmount] = useState('');
  const [fees, setFees] = useState(null);

  // Calculate fees on amount change (debounced)
  useEffect(() => {
    if (amount >= 10) {
      calculateFees(amount, currencyCode).then(setFees);
    }
  }, [amount, currencyCode]);

  return (
    <div>
      <input
        type="number"
        value={amount}
        onChange={(e) => setAmount(e.target.value)}
        placeholder="Amount in USD"
      />

      {fees && (
        <div className="fee-breakdown">
          <div>Amount: ${amount}</div>
          <div>Network fee: ${fees.network_fee}</div>
          <div>Service fee: ${fees.service_fee}</div>
          <hr />
          <div><strong>You will receive: ${fees.final_amount}</strong></div>
          <div className="text-muted">
            ≈ {fees.crypto_amount} {currencyCode}
          </div>
        </div>
      )}

      <button onClick={handleSubmit}>
        Request Withdrawal
      </button>
    </div>
  );
};
```

## Testing

```python
class WithdrawalTest(TestCase):
    def test_create_withdrawal_success(self):
        user = User.objects.create_user(username='test')

        # Add balance
        Transaction.objects.create(
            user=user,
            transaction_type='deposit',
            amount_usd=200.00
        )

        service = WithdrawalService()
        withdrawal = service.create_withdrawal_request(
            user=user,
            amount_usd=100.00,
            currency_code='USDTTRC20',
            wallet_address='TXYZabc123...'
        )

        self.assertEqual(withdrawal.status, 'pending')
        self.assertEqual(withdrawal.final_amount_usd, Decimal('97.00'))

    def test_insufficient_balance(self):
        user = User.objects.create_user(username='test')

        service = WithdrawalService()

        with self.assertRaises(ValidationError):
            service.create_withdrawal_request(
                user=user,
                amount_usd=100.00,
                currency_code='USDTTRC20',
                wallet_address='TXYZabc123...'
            )
```

## Future Improvements

1. **Automatic withdrawals via NowPayments Payouts API**
2. **KYC verification для больших сумм**
3. **Wallet address verification (отправка test transaction)**
4. **Batch processing для массовых выводов**
5. **Dynamic fee calculation из реальных комиссий сети**
6. **Cold wallet integration для безопасности**
