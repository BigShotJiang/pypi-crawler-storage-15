# Migration Guide - payments_old → payments

## Стратегия миграции

Создаем новое приложение `payments` параллельно со старым `payments_old`.

**Преимущества**:
- Старое приложение продолжает работать
- Можно тестировать новое без риска
- Легко откатиться если что-то пойдет не так
- Постепенная миграция данных

## Phase 1: Создание новой структуры

### 1.1 Создать директории

```bash
cd src/django_cfg/apps/
mkdir -p payments/{models,api,services/providers/nowpayments,admin,tests,migrations}
touch payments/__init__.py
touch payments/apps.py
touch payments/urls.py
```

### 1.2 Настроить apps.py

```python
# payments/apps.py
from django.apps import AppConfig

class PaymentsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'django_cfg.apps.payments'
    verbose_name = 'Payments v2.0'
    label = 'payments_v2'  # чтобы не конфликтовать с payments_old

    def ready(self):
        # Import signals if needed
        pass
```

### 1.3 Добавить в INSTALLED_APPS

```python
# settings/base.py
INSTALLED_APPS = [
    # ...
    'django_cfg.apps.payments_old',  # оставляем пока
    'django_cfg.apps.payments',      # новое приложение
    # ...
]
```

## Phase 2: Миграция моделей

### 2.1 Упрощенные модели

Создаем упрощенные версии моделей из payments_old:

**payments/models/payment.py**:
```python
from django.db import models
from django.contrib.auth import get_user_model
from decimal import Decimal

User = get_user_model()

class Payment(models.Model):
    """Упрощенная модель платежа."""

    class Status(models.TextChoices):
        PENDING = 'pending', 'Pending'
        CONFIRMING = 'confirming', 'Confirming'
        COMPLETED = 'completed', 'Completed'
        PARTIALLY_PAID = 'partially_paid', 'Partially Paid'
        FAILED = 'failed', 'Failed'
        EXPIRED = 'expired', 'Expired'

    # Basic fields
    id = models.UUIDField(primary_key=True, default=uuid.uuid4)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='payments_v2')
    internal_payment_id = models.CharField(max_length=100, unique=True, db_index=True)

    # Amounts
    amount_usd = models.DecimalField(max_digits=10, decimal_places=2)
    actual_amount_usd = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)

    # Currency (provider code like USDTTRC20)
    currency_code = models.CharField(max_length=20)

    # Payment details
    pay_address = models.CharField(max_length=255, blank=True)
    pay_amount = models.DecimalField(max_digits=20, decimal_places=8, null=True, blank=True)

    # Provider
    provider = models.CharField(max_length=50, default='nowpayments')
    provider_payment_id = models.CharField(max_length=255, blank=True, db_index=True)
    provider_data = models.JSONField(default=dict, blank=True)

    # Status
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.PENDING)

    # Transaction
    transaction_hash = models.CharField(max_length=256, blank=True)
    confirmations_count = models.IntegerField(default=0)

    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    expires_at = models.DateTimeField(null=True, blank=True)

    # Description
    description = models.TextField(blank=True)

    class Meta:
        db_table = 'payments_v2'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['user', 'status']),
            models.Index(fields=['provider_payment_id']),
            models.Index(fields=['transaction_hash']),
        ]

    def __str__(self):
        return f"{self.internal_payment_id} - ${self.amount_usd}"
```

**payments/models/transaction.py**:
```python
class Transaction(models.Model):
    """Транзакции для расчета баланса."""

    class Type(models.TextChoices):
        DEPOSIT = 'deposit', 'Deposit'
        WITHDRAWAL = 'withdrawal', 'Withdrawal'

    id = models.UUIDField(primary_key=True, default=uuid.uuid4)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='transactions_v2')

    transaction_type = models.CharField(max_length=20, choices=Type.choices)
    amount_usd = models.DecimalField(max_digits=10, decimal_places=2)

    # Link to payment if deposit
    payment_id = models.CharField(max_length=100, blank=True, db_index=True)

    description = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'transactions_v2'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['user', 'created_at']),
            models.Index(fields=['transaction_type']),
        ]
```

**payments/models/balance.py**:
```python
from django.db.models import Sum

class UserBalanceManager(models.Manager):
    """Manager для вычисления баланса."""

    def get_balance_for_user(self, user):
        """Вычислить баланс из транзакций."""
        transactions = Transaction.objects.filter(user=user)

        deposits = transactions.filter(
            transaction_type=Transaction.Type.DEPOSIT
        ).aggregate(total=Sum('amount_usd'))['total'] or Decimal('0')

        withdrawals = transactions.filter(
            transaction_type=Transaction.Type.WITHDRAWAL
        ).aggregate(total=Sum('amount_usd'))['total'] or Decimal('0')

        return {
            'balance_usd': deposits - withdrawals,
            'total_deposited': deposits,
            'total_withdrawn': withdrawals
        }

class UserBalance(models.Model):
    """
    Баланс юзера (может быть пустая таблица или использоваться для кеширования).
    Основной источник правды - Transaction модель.
    """

    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='balance_v2')

    # Эти поля можно вычислять через ORM или кешировать
    balance_usd = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    total_deposited = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    total_withdrawn = models.DecimalField(max_digits=10, decimal_places=2, default=0)

    updated_at = models.DateTimeField(auto_now=True)

    objects = UserBalanceManager()

    class Meta:
        db_table = 'user_balances_v2'

    def refresh_from_transactions(self):
        """Пересчитать баланс из транзакций."""
        data = self.__class__.objects.get_balance_for_user(self.user)

        self.balance_usd = data['balance_usd']
        self.total_deposited = data['total_deposited']
        self.total_withdrawn = data['total_withdrawn']
        self.save()
```

### 2.2 Создать миграции

```bash
python manage.py makemigrations payments
python manage.py migrate payments
```

## Phase 3: Миграция провайдера

### 3.1 Скопировать и упростить NowPaymentsProvider

Из `payments_old/services/providers/nowpayments/` берем:
- `provider.py` (упрощаем)
- `config.py` (оставляем)
- `client.py` (упрощаем)

Убираем:
- вебхук обработку
- сложные парсеры
- фолбек логику

### 3.2 Создать минимальный Registry

```python
# payments/services/providers/registry.py
class ProviderRegistry:
    """Простой реестр провайдеров."""

    _instance = None
    _providers = {}

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def get_provider(self, name: str):
        """Get provider instance."""
        if name not in self._providers:
            if name == 'nowpayments':
                config = get_nowpayments_config()
                self._providers[name] = NowPaymentsProvider(config)
            else:
                raise ValueError(f"Unknown provider: {name}")

        return self._providers[name]

# Singleton instance
registry = ProviderRegistry()

def get_provider(name: str):
    """Get provider from registry."""
    return registry.get_provider(name)
```

## Phase 4: Создание API

### 4.1 Views

Создаем новые views в `payments/api/views.py`:

- `CurrencyListView`
- `PaymentCreateView`
- `PaymentStatusView`
- `PaymentConfirmView`
- `TransactionListView`
- `BalanceView`

### 4.2 Serializers

```python
# payments/api/serializers.py

class PaymentCreateSerializer(serializers.Serializer):
    amount_usd = serializers.DecimalField(max_digits=10, decimal_places=2, min_value=1.0, max_value=50000.0)
    currency_code = serializers.CharField(max_length=20)
    description = serializers.CharField(max_length=500, required=False, allow_blank=True)

class PaymentDetailSerializer(serializers.ModelSerializer):
    qr_code_url = serializers.SerializerMethodField()
    explorer_link = serializers.SerializerMethodField()

    class Meta:
        model = Payment
        fields = [
            'id', 'internal_payment_id', 'status',
            'amount_usd', 'currency_code',
            'pay_address', 'pay_amount',
            'qr_code_url', 'explorer_link',
            'transaction_hash', 'confirmations_count',
            'created_at', 'completed_at', 'expires_at'
        ]

    def get_qr_code_url(self, obj):
        if obj.pay_address:
            from urllib.parse import quote
            return f"https://api.qrserver.com/v1/create-qr-code/?size=200x200&data={quote(obj.pay_address)}"
        return None

    def get_explorer_link(self, obj):
        # Logic to generate explorer link based on currency/network
        return obj.get_explorer_link()
```

### 4.3 URLs

```python
# payments/urls.py
from django.urls import path
from .api import views

app_name = 'payments_v2'

urlpatterns = [
    # Currencies
    path('currencies/', views.CurrencyListView.as_view(), name='currency-list'),

    # Payments
    path('', views.PaymentListView.as_view(), name='payment-list'),
    path('create/', views.PaymentCreateView.as_view(), name='payment-create'),
    path('<uuid:payment_id>/status/', views.PaymentStatusView.as_view(), name='payment-status'),
    path('<uuid:payment_id>/confirm/', views.PaymentConfirmView.as_view(), name='payment-confirm'),

    # Balance & Transactions
    path('balance/', views.BalanceView.as_view(), name='balance'),
    path('transactions/', views.TransactionListView.as_view(), name='transaction-list'),
]
```

### 4.4 Подключить URLs

```python
# project/urls.py
urlpatterns = [
    # ...
    path('api/v1/payments/', include('django_cfg.apps.payments.urls')),
    # ...
]
```

## Phase 5: Тестирование

### 5.1 Unit тесты

```python
# payments/tests/test_models.py
class PaymentModelTest(TestCase):
    def test_create_payment(self):
        user = User.objects.create_user(username='test')
        payment = Payment.objects.create(
            user=user,
            amount_usd=Decimal('100.00'),
            currency_code='USDTTRC20',
            status=Payment.Status.PENDING
        )
        self.assertEqual(payment.status, Payment.Status.PENDING)
```

### 5.2 API тесты

```python
# payments/tests/test_api.py
class PaymentAPITest(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='test', password='test')
        self.client.force_authenticate(user=self.user)

    def test_create_payment(self):
        url = reverse('payments_v2:payment-create')
        data = {
            'amount_usd': '100.00',
            'currency_code': 'USDTTRC20'
        }
        response = self.client.post(url, data, format='json')
        self.assertEqual(response.status_code, 201)
        self.assertTrue(response.data['success'])
```

### 5.3 Provider тесты

```python
# payments/tests/test_provider.py
class NowPaymentsProviderTest(TestCase):
    def setUp(self):
        config = NowPaymentsConfig(
            api_key='test_key',
            sandbox=True
        )
        self.provider = NowPaymentsProvider(config)

    @patch('httpx.Client.get')
    def test_get_currencies(self, mock_get):
        mock_get.return_value.json.return_value = {
            'currencies': [
                {'code': 'USDTTRC20', 'name': 'USDT TRC20', 'enable': True}
            ]
        }

        currencies = self.provider.get_supported_currencies()
        self.assertEqual(len(currencies), 1)
```

## Phase 6: Миграция данных (опционально)

Если нужно мигрировать существующие данные из payments_old:

### 6.1 Management command

```python
# payments/management/commands/migrate_payments.py
from django.core.management.base import BaseCommand
from django_cfg.apps.payments_old.models import UniversalPayment as OldPayment
from django_cfg.apps.payments.models import Payment as NewPayment

class Command(BaseCommand):
    help = 'Migrate payments from payments_old to payments'

    def handle(self, *args, **options):
        old_payments = OldPayment.objects.all()

        for old in old_payments:
            # Создаем новый платеж с данными из старого
            new_payment = NewPayment(
                id=old.id,
                user=old.user,
                internal_payment_id=old.internal_payment_id,
                amount_usd=old.amount_usd,
                currency_code=old.currency.code if old.currency else '',
                pay_address=old.pay_address,
                pay_amount=old.pay_amount,
                provider=old.provider,
                provider_payment_id=old.provider_payment_id,
                status=old.status,
                transaction_hash=old.transaction_hash,
                created_at=old.created_at,
                completed_at=old.completed_at,
                expires_at=old.expires_at,
            )
            new_payment.save()

            self.stdout.write(f"Migrated payment {old.internal_payment_id}")

        self.stdout.write(self.style.SUCCESS(f"Migrated {old_payments.count()} payments"))
```

Запуск:
```bash
python manage.py migrate_payments
```

## Phase 7: Переключение

### 7.1 Фронтенд

Обновить фронтенд для использования нового API:
```javascript
// Старый API
const response = await fetch('/api/payments/payment/create/');

// Новый API
const response = await fetch('/api/v1/payments/create/');
```

### 7.2 Feature flag (опционально)

Можно использовать feature flag для постепенного переключения:

```python
# settings.py
PAYMENTS_V2_ENABLED = env.bool('PAYMENTS_V2_ENABLED', default=False)

# views
if settings.PAYMENTS_V2_ENABLED:
    from django_cfg.apps.payments.api.views import PaymentCreateView
else:
    from django_cfg.apps.payments_old.views.api import PaymentCreateView
```

## Phase 8: Удаление старого кода

После успешного переключения и тестирования:

### 8.1 Удалить payments_old

```bash
# Удаляем директорию
rm -rf src/django_cfg/apps/payments_old/

# Удаляем из INSTALLED_APPS
# settings/base.py
INSTALLED_APPS = [
    # 'django_cfg.apps.payments_old',  # удалено
    'django_cfg.apps.payments',
    # ...
]
```

### 8.2 Удалить старые миграции (если не нужны)

```bash
# Можно удалить старые миграции если данные уже мигрированы
rm -rf src/django_cfg/apps/payments_old/migrations/
```

### 8.3 Переименовать app label

Если хочется убрать `_v2` suffix:

```python
# payments/apps.py
class PaymentsConfig(AppConfig):
    # ...
    label = 'payments'  # было 'payments_v2'
```

И обновить related_name в моделях:
```python
user = models.ForeignKey(User, related_name='payments')  # было 'payments_v2'
```

## Rollback план

Если что-то пошло не так:

1. **Отключить новый API** - закомментировать в urls.py
2. **Вернуть фронтенд на старый API**
3. **Использовать feature flag** для быстрого переключения
4. **Бэкап БД** перед любыми необратимыми изменениями

## Checklist

- [ ] Создана новая структура директорий
- [ ] Созданы упрощенные модели
- [ ] Миграции применены
- [ ] Provider адаптирован
- [ ] API endpoints созданы
- [ ] Unit тесты написаны
- [ ] Integration тесты написаны
- [ ] Фронтенд обновлен
- [ ] Тестирование на dev окружении
- [ ] Тестирование на staging
- [ ] Deploy на production
- [ ] Мониторинг ошибок
- [ ] Миграция данных (если нужно)
- [ ] Удаление старого кода
- [ ] Документация обновлена

## Timing

- **Phase 1-2**: 1 день (структура и модели)
- **Phase 3**: 1 день (provider)
- **Phase 4**: 2 дня (API)
- **Phase 5**: 2 дня (тесты)
- **Phase 6**: 1 день (миграция данных - опционально)
- **Phase 7**: 1 день (переключение)
- **Phase 8**: 0.5 дня (cleanup)

**Total**: ~8.5 дней
