# План рефакторинга приложения payments

## Цель
Упростить и оптимизировать приложение платежей, убрать избыточный код, сфокусироваться на провайдере NowPayments, и создать простое API для фронтенда.

## Основные принципы
1. **Простота вместо сложности** - убираем оверкодинг
2. **Один провайдер** - фокус на NowPayments (другие потом)
3. **Без вебхуков и ngrok** - пользовательский флоу через polling
4. **Чистое API** - понятные ендпоинты для фронта
5. **ORM-based баланс** - вычисляем через транзакции, а не храним

## Что убираем из payments_old

### 1. Вебхуки и связанная инфраструктура
- ❌ `views/api/webhook_views.py` - UniversalWebhookView
- ❌ `services/webhook_handler.py`
- ❌ `middleware/webhook_middleware.py`
- ❌ Вся документация по ngrok и вебхукам
- ❌ IPN callback URL конфигурация

**Причина**: Вебхуки не нужны - юзер сам будет проверять статус оплаты.

### 2. API Keys система
- ❌ `models/api_keys.py` - APIKey модель
- ❌ `views/api/api_key_views.py`
- ❌ `middleware/api_access_middleware.py`
- ❌ API key валидация и создание

**Причина**: API ключи не нужны для нашего флоу.

### 3. Тарифная система
- ❌ `models/tariffs.py` - Tariff, UserTariff модели
- ❌ `models/subscriptions.py` - Subscription модели
- ❌ `views/api/subscription_views.py`
- ❌ Вся логика подписок и тарифов

**Причина**: Тарифы и подписки не нужны.

### 4. Избыточные сервисы
- ❌ `services/core/error_handler.py` (686 строк) - заменить на простые исключения
- ❌ `services/core/fallback_service.py` - фолбек провайдеров не нужен
- ❌ `services/core/cache_service.py` - оверкодинг, используем стандартный Django cache
- ❌ `services/security/security_service.py` - избыточная безопасность

**Причина**: Оверинжиниринг, заменяем на простые решения.

### 5. Лишние провайдеры
- ❌ `@providers/cryptapi/` - вся документация и примеры
- ❌ `@providers/cryptomus/` - вся документация и примеры
- ❌ `services/providers/cryptapi/` (если есть)
- ❌ `services/providers/cryptomus/` (если есть)

**Причина**: Оставляем только NowPayments как primary provider.

### 6. Overview dashboard
- ❌ `views/overview/` - dashboard views
- ❌ `templates/overview/` - dashboard templates
- ❌ `urls_admin.py` - админский dashboard

**Причина**: Будет свой фронтенд, админка Django достаточна.

### 7. Избыточная документация
- ❌ `@docs/` - большая часть документации устаревшая
- ❌ `@progress/` - старые progress reports
- Оставляем только ключевые референсы для провайдера

## Что сохраняем и адаптируем

### 1. Модели (упрощенные)
✅ **UniversalPayment** - основная модель платежа
- Убираем лишние поля
- Упрощаем статусы
- Фокус на крипто-платежи

✅ **UserBalance** - баланс юзера
- Но вычисляем через ORM менеджер на основе Transaction

✅ **Transaction** - транзакции пополнения/вывода
- Основная модель для расчета баланса
- Типы: deposit, withdrawal

✅ **Currency** - валюты
- Упрощаем, убираем ProviderCurrency
- NowPayments работает с собственными кодами валют (USDTTRC20, etc)

✅ **Network** - сети
- Но в NowPayments каждая валюта уже привязана к сети (например USDTTRC20)
- Возможно упростим или уберем совсем

### 2. Provider система (упрощенная)
✅ **NowPaymentsProvider** - единственный провайдер
- `services/providers/nowpayments/provider.py`
- `services/providers/nowpayments/config.py`
- Упростим интерфейс

✅ **ProviderRegistry** - но максимально упрощенный
- Только для NowPayments
- Без health checks и fallback логики

### 3. API Views (новые, упрощенные)
Создадим новые view с фокусом на нужный флоу:

✅ **CurrencyListView** - список доступных валют и сетей
✅ **PaymentCreateView** - создание платежа
✅ **PaymentStatusView** - проверка статуса
✅ **PaymentConfirmView** - подтверждение оплаты юзером
✅ **TransactionListView** - история транзакций
✅ **BalanceView** - текущий баланс (через ORM)

### 4. Менеджеры
✅ **PaymentManager** - для работы с платежами
✅ **TransactionManager** - для работы с транзакциями
✅ **UserBalanceManager** - вычисление баланса через агрегацию

## Новая структура приложения

```
payments/
├── __init__.py
├── apps.py
├── urls.py
│
├── models/
│   ├── __init__.py
│   ├── payment.py          # UniversalPayment (упрощенная)
│   ├── transaction.py      # Transaction (deposit/withdrawal)
│   ├── balance.py          # UserBalance (computed via ORM)
│   └── currency.py         # Currency, Network (упрощенные)
│
├── api/
│   ├── __init__.py
│   ├── views.py            # API views для фронта
│   ├── serializers.py      # DRF serializers
│   └── permissions.py      # Простые permissions
│
├── services/
│   ├── __init__.py
│   ├── payment_service.py  # Основной сервис для платежей
│   └── providers/
│       ├── __init__.py
│       ├── base.py         # BaseProvider (упрощенный)
│       ├── registry.py     # ProviderRegistry (упрощенный)
│       └── nowpayments/
│           ├── __init__.py
│           ├── provider.py # NowPaymentsProvider
│           ├── config.py   # Configuration
│           └── client.py   # API client
│
├── admin/
│   ├── __init__.py
│   └── payment_admin.py    # Django admin для платежей
│
├── migrations/
│   └── ...
│
├── tests/
│   ├── __init__.py
│   ├── test_models.py
│   ├── test_api.py
│   └── test_provider.py
│
└── @refactoring/           # Документация рефакторинга
    ├── 00-refactoring-plan.md       # Этот файл
    ├── 01-api-specification.md      # Спецификация API
    ├── 02-flow-description.md       # Описание флоу
    ├── 03-nowpayments-integration.md # Интеграция NowPayments
    └── 04-migration-guide.md        # Гайд миграции
```

## Пошаговый план выполнения

### Phase 1: Подготовка и очистка
1. Создать новую структуру директорий `payments/`
2. Скопировать базовые модели из `payments_old/`
3. Убрать лишние поля и упростить модели
4. Создать новые миграции

### Phase 2: Provider интеграция
1. Адаптировать NowPaymentsProvider под новые требования
2. Упростить BaseProvider интерфейс
3. Создать минималистичный ProviderRegistry
4. Убрать вебхук обработку

### Phase 3: API endpoints
1. Создать CurrencyListView с кешированием (только прод)
2. Создать PaymentCreateView
3. Создать PaymentStatusView
4. Создать PaymentConfirmView
5. Создать TransactionListView и BalanceView

### Phase 4: Business логика
1. Реализовать PaymentService
2. Реализовать логику проверки неполной оплаты
3. Реализовать создание Transaction при успешной оплате
4. Настроить ORM managers для баланса

### Phase 5: Admin и тесты
1. Создать упрощенный Django admin
2. Написать тесты для API
3. Написать тесты для провайдера
4. Написать интеграционные тесты

### Phase 6: Финализация
1. Документация API
2. Обновить settings для нового приложения
3. Создать management commands (если нужны)
4. Code review и оптимизация

## Следующие шаги
Переходим к детальному описанию каждого компонента:
- API спецификация
- Описание флоу платежей
- Детали интеграции NowPayments
- Гайд по миграции данных
