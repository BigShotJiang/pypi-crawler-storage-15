from ...utilities.zmq.communicable.request import AnalysisRequest


class DebugComplete(AnalysisRequest):
    pass
