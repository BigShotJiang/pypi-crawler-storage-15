class Progress:
    def __init__(self, counts):
        self.counts = counts
