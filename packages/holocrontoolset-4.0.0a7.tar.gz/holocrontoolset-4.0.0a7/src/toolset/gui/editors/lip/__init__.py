"""LIP file editor for the Holocron Toolset."""
from __future__ import annotations

from toolset.gui.editors.lip.lip_editor import LIPEditor

__all__ = ["LIPEditor"]
