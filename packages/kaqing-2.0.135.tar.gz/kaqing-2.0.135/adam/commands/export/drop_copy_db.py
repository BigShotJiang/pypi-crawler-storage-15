from adam.commands.command import Command
from adam.commands.export.export_databases import ExportDatabases
from adam.repl_state import ReplState
from adam.utils import log2
from adam.utils_sqlite import SQLite

class DropCopyDatabase(Command):
    COMMAND = 'drop copy database'

    # the singleton pattern
    def __new__(cls, *args, **kwargs):
        if not hasattr(cls, 'instance'): cls.instance = super(DropCopyDatabase, cls).__new__(cls)

        return cls.instance

    def __init__(self, successor: Command=None):
        super().__init__(successor)

    def command(self):
        return DropCopyDatabase.COMMAND

    def required(self):
        return [ReplState.C, ReplState.X]

    def run(self, cmd: str, state: ReplState):
        if not(args := self.args(cmd)):
            return super().run(cmd, state)

        state, args = self.apply_state(args, state)
        if not self.validate_state(state):
            return state

        if not len(args):
            if state.in_repl:
                log2('Database name is required.')
                log2()
            else:
                log2('* Database name is missing.')
                Command.display_help()

            return 'command-missing'

        session = args[0]
        ExportDatabases.drop_copy_dbs(session)
        SQLite.clear_cache()

        if state.export_session == session:
            state.export_session = None

        return state

    def completion(self, _: ReplState):
        return {}

    def help(self, _: ReplState):
        return f'{DropCopyDatabase.COMMAND} <copy-db-name>\t drop copy database'