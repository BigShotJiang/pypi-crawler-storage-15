from adam.commands.command import Command
from adam.commands.export.export_databases import ExportDatabases
from adam.repl_state import ReplState
from adam.utils_sqlite import SQLite

class DropCopyDatabases(Command):
    COMMAND = 'drop all copy databases'

    # the singleton pattern
    def __new__(cls, *args, **kwargs):
        if not hasattr(cls, 'instance'): cls.instance = super(DropCopyDatabases, cls).__new__(cls)

        return cls.instance

    def __init__(self, successor: Command=None):
        super().__init__(successor)

    def command(self):
        return DropCopyDatabases.COMMAND

    def required(self):
        return [ReplState.C, ReplState.X]

    def run(self, cmd: str, state: ReplState):
        if not(args := self.args(cmd)):
            return super().run(cmd, state)

        state, args = self.apply_state(args, state)
        if not self.validate_state(state):
            return state

        ExportDatabases.drop_copy_dbs()

        SQLite.clear_cache()

        state.export_session = None

        return state

    def completion(self, _: ReplState):
        return {}

    def help(self, _: ReplState):
        return f'{DropCopyDatabases.COMMAND}\t drop all copy databases'