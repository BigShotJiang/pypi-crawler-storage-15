from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
import time
import boto3

from adam.commands.cql.cql_utils import cassandra_table_names, run_cql
from adam.commands.export.utils_export import ExportSpec, ExportStatus, ExportTableSpec, GeneratorStream, ing
from adam.config import Config
from adam.repl_state import ReplState
from adam.utils import elapsed_time, log2
from adam.utils_athena import Athena
from adam.utils_k8s.cassandra_nodes import CassandraNodes
from adam.utils_k8s.pods import Pods

class AthenaExporter:
    LIKE = 'e%_%'

    def export_session_names(state: ReplState):
        # TODO implement
        return []

    def export_tables(args: list[str], state: ReplState, max_workers = 0, export_state = None, export_only = False, kind = 'export'):
        if kind == 'export' and not AthenaExporter.validate_s3_connectivity():
            log2('Exporting table is not available as no AWS credentials was provided. Please use copy command instead.')

            return []

        if not export_state:
            tables = []
            for status in ExportStatus.get_copy_status(state.sts, state.pod, state.namespace, state.export_session, True):
                tables.append(ExportTableSpec(status.keyspace, status.table))
            spec = ExportSpec(None, None, tables=tables)
        else:
            spec: ExportSpec = ExportSpec.parse_specs(' '.join(args))

        if not spec.keyspace:
            spec.keyspace = f'{state.namespace}_db'

        if not spec.tables:
            spec.tables = [ExportTableSpec.parse(t) for t in cassandra_table_names(state, keyspace=spec.keyspace)]

        if not max_workers:
            max_workers = Config().action_workers(kind, 8)

        if max_workers > 1 and len(spec.tables) > 1:
            log2(f'Executing on {len(spec.tables)} Cassandra tables in parallel...')
            start_time = time.time()
            try:
                with ThreadPoolExecutor(max_workers=max_workers) as executor:
                    futures = [executor.submit(AthenaExporter.export_table, table, state, True, consistency=spec.consistency, export_state=export_state, export_only=export_only) for table in spec.tables]
                    if len(futures) == 0:
                        return []

                return [future.result() for future in as_completed(futures)]
            finally:
                log2(f"{len(spec.tables)} parallel table export elapsed time: {elapsed_time(start_time)} with {max_workers} workers")
        else:
            return [AthenaExporter.export_table(table, state, multi_tables=len(spec.tables) > 1, consistency=spec.consistency, export_state=export_state, export_only=export_only) for table in spec.tables]

    def validate_s3_connectivity():
        try:
            s3 = boto3.client('s3')
            bucket = Config().get('export.bucket', 'c3.ops--qing')
            s3.head_bucket(Bucket=bucket)
            return True
        except:
            return False

    def export_table(spec: ExportTableSpec, state: ReplState, multi_tables = True, consistency: str = None):
        table, target_table, columns = AthenaExporter.resove_table_n_columns(spec, state)

        temp_dir = Config().get('export.temp_dir', '/c3/cassandra/tmp')
        db = state.export_session
        create_db = not db
        if create_db:
            db = f'e{datetime.now().strftime("%Y%m%d%H%M%S")[3:]}_{spec.keyspace}'
            state.export_session = db
        else:
            db = f"{db.split('_')[0]}_{spec.keyspace}"

        CassandraNodes.exec(state.pod, state.namespace, f'mkdir -p {temp_dir}/{db}', show_out=not multi_tables, shell='bash')
        csv_file = f'{temp_dir}/{db}/{table}.csv'
        succeeded = False
        try:
            suppress_ing_log = Config().is_debug() or multi_tables
            queries = []
            if consistency:
                queries.append(f'CONSISTENCY {consistency}')
            queries.append(f"COPY {spec.keyspace}.{table}({columns}) TO '{csv_file}' WITH HEADER = TRUE")
            ing(f'Dumping table {spec.keyspace}.{table}{f" with consistency {consistency}" if consistency else ""}',
                lambda: run_cql(state, ';'.join(queries), show_out=Config().is_debug()),
                suppress_log=suppress_ing_log)

            bucket = Config().get('export.bucket', 'c3.ops--qing')

            def upload_to_s3():
                bytes = Pods.read_file(state.pod, 'cassandra', state.namespace, csv_file)

                s3 = boto3.client('s3')
                s3.upload_fileobj(GeneratorStream(bytes), bucket, f'export/{db}/{spec.keyspace}/{target_table}/{table}.csv')

            ing(f'Uploading to S3', upload_to_s3, suppress_log=suppress_ing_log)

            def create_schema():
                query = f'CREATE DATABASE IF NOT EXISTS {db};'
                if Config().is_debug():
                    log2(query)
                Athena.query(query, 'default')

                query = f'DROP TABLE IF EXISTS {target_table};'
                if Config().is_debug():
                    log2(query)
                Athena.query(query, db)

                # columns = ', '.join([f'{h.strip(" ")} string' for h in header[0].split(',')])
                athena_columns = ', '.join([f'{c} string' for c in columns.split(',')])
                query = f'CREATE EXTERNAL TABLE IF NOT EXISTS {target_table}(\n' + \
                        f'    {athena_columns})\n' + \
                            "ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'\n" + \
                            'WITH SERDEPROPERTIES (\n' + \
                            '    "separatorChar" = ",",\n' + \
                            '    "quoteChar"     = "\\"")\n' + \
                        f"LOCATION 's3://{bucket}/export/{db}/{spec.keyspace}/{target_table}'\n" + \
                            'TBLPROPERTIES ("skip.header.line.count"="1");'
                if Config().is_debug():
                    log2(query)
                try:
                    Athena.query(query, db)
                except Exception as e:
                    log2(f'*** Failed query:\n{query}')
                    raise e

            ing(f"Creating database {db}" if create_db else f"Creating table {target_table}", create_schema, suppress_log=suppress_ing_log)

            succeeded = True
        except Exception as e:
            log2(e)
        finally:
            ing('Cleaning up temporary files',
                lambda: CassandraNodes.exec(state.pod, state.namespace, f'rm -rf {csv_file}', show_out=False, shell='bash'),
                suppress_log=suppress_ing_log)

        if succeeded:
            Athena.clear_cache()

            if not suppress_ing_log:
                query = f'select * from {target_table} limit 10'
                log2(query)
                Athena.run_query(query, db)

        return table