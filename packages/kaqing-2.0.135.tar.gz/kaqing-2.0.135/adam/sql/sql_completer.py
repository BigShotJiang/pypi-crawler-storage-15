import traceback
from typing import Callable

import sqlparse
from sqlparse.sql import Statement, Token

from adam.sql.term_completer import TermCompleter
from adam.utils_repl.automata_completer import AutomataCompleter
from adam.sql.sql_state_machine import AthenaStateMachine, CqlStateMachine, SqlStateMachine
from adam.utils_repl.state_machine import State

__all__ = [
    "SqlCompleter",
]

def default_columns(x: list[str]):
    return 'id,x.,y.,z.'.split(',')

def default_keyspaces():
    return []

class SqlCompleter(AutomataCompleter[Token]):
    def tokens(self, text: str) -> list[Token]:
        tokens = []

        stmts = sqlparse.parse(text)
        if not stmts:
            tokens = []
        else:
            statement: Statement = stmts[0]
            tokens = statement.tokens

        return tokens

    def __init__(self,
                 tables: Callable[[], list[str]],
                 dml: str = None,
                 columns: Callable[[list[str]], list[str]] = default_columns,
                 keyspaces: Callable[[], list[str]] = default_keyspaces,
                 partition_columns: Callable[[list[str]], list[str]] = lambda x: [],
                 table_props: Callable[[], dict[str,list[str]]] = lambda: [],
                 copies: Callable[[], list[str]] = lambda: [],
                 exports: Callable[[], list[str]] = lambda: [],
                 copy_sessions: Callable[[], list[str]] = lambda: [],
                 export_sessions: Callable[[], list[str]] = lambda: [],
                 variant = 'sql',
                 debug = False):
        machine = SqlStateMachine(debug=debug)
        if variant == 'cql':
            machine = CqlStateMachine(debug=debug)
        elif variant == 'athena':
            machine = AthenaStateMachine(debug=debug)
        super().__init__(machine, dml, debug)

        self.tables = tables
        self.columns = columns
        self.keyspaces = keyspaces
        self.partition_columns = partition_columns
        self.table_props = table_props
        self.copies = copies
        self.exports = exports
        self.copy_sessions = copy_sessions
        self.export_sessions = export_sessions
        self.variant = variant
        self.debug = debug

    def suggestions_completer(self, state: State, suggestions: str) -> list[str]:
        if not suggestions:
            return None

        terms = []
        for suggestion in suggestions.split(','):
            terms.extend(self._terms(state, suggestion))

        return TermCompleter(terms)

    def _terms(self, state: State, word: str) -> list[str]:
        terms = []

        if word == 'keyspaces':
            terms.extend(self.keyspaces())
        elif word == '`keyspaces`':
            terms.append('keyspaces')
        elif word == 'tables':
            terms.extend(self.tables())
        elif word == '`tables`':
            terms.append('tables')
        elif word == 'columns':
            if 'last_name' in state.context and (n := state.context['last_name']):
                if 'last_namespace' in state.context and (ns := state.context['last_namespace']):
                    n = f'{ns}.{n}'
                terms.extend(self.columns([n]))
            else:
                terms.extend(self.columns([]))
        elif word == 'partition-columns':
            terms.extend(self.partition_columns([]))
        elif word == 'table-props':
            terms.extend(self.table_props().keys())
        elif word == 'table-prop-values':
            if 'last_name' in state.context and state.context['last_name']:
                terms.extend(self.table_props()[state.context['last_name']])
        elif word == 'single':
            terms.append("'")
        elif word == 'comma':
            terms.append(",")
        elif word == 'copies':
            terms.extend(self.copies())
        elif word == 'exports':
            terms.extend(self.exports())
        elif word == 'copy_sessions':
            terms.extend(self.copy_sessions())
        elif word == 'export_sessions':
            terms.extend(self.export_sessions())
        else:
            terms.append(word)

        return terms

    def completions_for_nesting(self, dml: str = None):
        if dml:
            return {dml: SqlCompleter(self.tables, dml, columns=self.columns,
                                      keyspaces=self.keyspaces, partition_columns=self.partition_columns,
                                      table_props=self.table_props, copies=self.copies, exports=self.exports, variant=self.variant)}

        return {
            word: SqlCompleter(self.tables, word, columns=self.columns,
                               keyspaces=self.keyspaces, partition_columns=self.partition_columns,
                               table_props=self.table_props, copies=self.copies, exports=self.exports, copy_sessions=self.copy_sessions, export_sessions=self.export_sessions, variant=self.variant)
            for word in self.machine.suggestions[''].strip(' ').split(',')
        }

    def __str__(self):
        return f'{self.variant}, {self.first_term}'