# Gemini Configuration

This file documents preferences for interacting with the Gemini CLI in this
repository.

## GitHub Interaction

When interacting with GitHub, prefer the local `gh` command-line tool rather
than remote web APIs.
