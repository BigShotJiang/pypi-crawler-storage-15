"""Base source classes."""

from quantada.sources.base.source import DataSource

__all__ = [
    "DataSource",
]
