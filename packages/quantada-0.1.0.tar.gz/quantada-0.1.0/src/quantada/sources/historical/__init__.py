"""Historical data sources."""

from quantada.sources.historical.file_source import HistoricalDataSource

__all__ = [
    "HistoricalDataSource",
]
