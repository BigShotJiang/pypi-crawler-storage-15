"""Logging package."""

from quantada.logging.setup import get_logger

__all__ = [
    "get_logger",
]
