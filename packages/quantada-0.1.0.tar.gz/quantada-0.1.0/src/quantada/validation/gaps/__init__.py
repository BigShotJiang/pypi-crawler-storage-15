"""Gap detection and handling."""

from quantada.validation.gaps.detector import Gap, count_gaps, detect_gaps, has_gaps
from quantada.validation.gaps.handler import fill_gaps, remove_gaps

__all__ = [
    "Gap",
    "detect_gaps",
    "count_gaps",
    "has_gaps",
    "fill_gaps",
    "remove_gaps",
]
