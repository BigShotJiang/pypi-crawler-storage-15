"""Error handling package."""

from quantada.errors.base import ConfigurationError, QuantadaError
from quantada.errors.data import DataError, DataValidationError, InvalidDataFormat, NoDataFound
from quantada.errors.source import SourceError, SourceNotAvailable, SourceTimeout
from quantada.errors.store import StoreError, StoreReadError, StoreWriteError
from quantada.errors.validation import (
    PriceValidationError,
    TimestampValidationError,
    ValidationError,
    VolumeValidationError,
)

__all__ = [
    "QuantadaError",
    "ConfigurationError",
    "DataError",
    "NoDataFound",
    "InvalidDataFormat",
    "DataValidationError",
    "SourceError",
    "SourceNotAvailable",
    "SourceTimeout",
    "StoreError",
    "StoreWriteError",
    "StoreReadError",
    "ValidationError",
    "PriceValidationError",
    "VolumeValidationError",
    "TimestampValidationError",
]
