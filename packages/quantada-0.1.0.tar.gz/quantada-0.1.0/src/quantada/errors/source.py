"""Source-related exceptions."""

from quantada.errors.base import QuantadaError


class SourceError(QuantadaError):
    """Base class for data source errors."""

    pass


class SourceNotAvailable(SourceError):
    """Data source is not available."""

    pass


class SourceTimeout(SourceError):
    """Data source request timed out."""

    pass
