"""Data-related exceptions."""

from quantada.errors.base import QuantadaError


class DataError(QuantadaError):
    """Base class for data errors."""

    pass


class NoDataFound(DataError):
    """No data found for the given query."""

    pass


class InvalidDataFormat(DataError):
    """Data format is invalid."""

    pass


class DataValidationError(DataError):
    """Data validation failed."""

    pass
