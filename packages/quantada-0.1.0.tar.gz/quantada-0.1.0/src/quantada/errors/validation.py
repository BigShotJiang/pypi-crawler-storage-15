"""Validation-related exceptions."""

from quantada.errors.base import QuantadaError


class ValidationError(QuantadaError):
    """Base class for validation errors."""

    pass


class PriceValidationError(ValidationError):
    """Price validation failed."""

    pass


class VolumeValidationError(ValidationError):
    """Volume validation failed."""

    pass


class TimestampValidationError(ValidationError):
    """Timestamp validation failed."""

    pass
