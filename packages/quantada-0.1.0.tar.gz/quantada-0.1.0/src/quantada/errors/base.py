"""Base exception classes."""


class QuantadaError(Exception):
    """Base exception for all Quantada errors."""

    pass


class ConfigurationError(QuantadaError):
    """Configuration-related errors."""

    pass
