"""Configuration package."""

from quantada.config.manager import get_config

__all__ = [
    "get_config",
]
