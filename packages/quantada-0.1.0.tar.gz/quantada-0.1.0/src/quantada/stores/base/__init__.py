"""Base store classes."""

from quantada.stores.base.store import DataStore

__all__ = [
    "DataStore",
]
