This module integrates the migration data collected by `odoo_repository_migration`
in your Odoo projects, allowing to analyze their migrations.
