"""Python package for analysis and visualization of functional ultrasound imaging data.

This is a placeholder release to reserve the package name on PyPI.
The full package is currently in development and not yet publicly available.
"""

__version__ = "0.0.1"

raise ImportError(
    "ConfUSIus is currently in pre-alpha development and not yet publicly available. "
    "This package is a placeholder to reserve the name on PyPI."
)
