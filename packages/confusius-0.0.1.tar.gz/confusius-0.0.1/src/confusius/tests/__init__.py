"""Package-level tests for confusius."""
