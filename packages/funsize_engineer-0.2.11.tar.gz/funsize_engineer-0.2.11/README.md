# funsize-engineer

A personal calling card for Jessica Rudd, Staff Data Engineer at FanDuel.

## Quick Start

Run this single command in your terminal (requires Python installed):

```bash
python -m pip install funsize-engineer && python -m funsize_engineer
```

## Installation

### From PyPI (Production)

```bash
pip install funsize-engineer
```

### From TestPyPI (Testing)

If you want to test the latest development version from TestPyPI:

```bash
pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ funsize-engineer
```

> **Note:** The `--extra-index-url` flag is required to ensure dependencies (like `rich`) are installed from the main PyPI, as they may not be available on TestPyPI.

## Usage

Run the command:

```bash
funsize-engineer
```

Or import it in Python:

```python
import funsize_engineer
funsize_engineer.card()
```

## "npx-style" Usage

To run the card without installing it globally (similar to `npx`), you can use `pipx`:

```bash
pipx run funsize-engineer
```

## Development & Versioning

This package uses **automated versioning** with [setuptools-scm](https://github.com/pypa/setuptools-scm) based on git tags.

### Version Format

- **Production (main branch)**: Clean versions from git tags (e.g., `v0.2.0` → `0.2.0`)
- **Development (develop branch)**: Auto-generated dev versions (e.g., `0.1.2.dev3+g1a2b3c4`)

### Creating a Release

1. Merge your changes to the `main` branch
2. Create and push a git tag:
   ```bash
   git tag v0.2.0
   git push origin v0.2.0
   ```
3. GitHub Actions will automatically build and publish to PyPI

### Development Workflow

- Push to `develop` branch → Auto-publishes to TestPyPI with dev version
- Push to `main` branch with a tag → Auto-publishes to PyPI with stable version

No manual version bumping required! 🎉
