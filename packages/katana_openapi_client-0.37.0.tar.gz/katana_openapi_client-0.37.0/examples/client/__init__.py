"""
Example usage scripts for the Katana OpenAPI Client.

This directory contains various examples demonstrating different features
and usage patterns of the KatanaClient.

Examples:
- basic_usage.py: Basic client usage with automatic pagination
"""
