"""Setup configuration for SysMap (for backwards compatibility)."""

from setuptools import setup

# Configuration is in pyproject.toml
# This file is here for backwards compatibility only
setup()
