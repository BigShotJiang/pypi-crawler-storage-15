"""Core functionality for SysMap."""
